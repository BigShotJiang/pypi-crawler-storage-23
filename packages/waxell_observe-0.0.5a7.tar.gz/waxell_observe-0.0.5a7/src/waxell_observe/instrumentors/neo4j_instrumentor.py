"""Neo4j auto-instrumentor for waxell-observe.

Monkey-patches Neo4j Python driver Session.run and AsyncSession.run
methods to emit retrieval spans (for vector search queries) and tool
spans (for general Cypher queries).

Patched methods:
  - ``neo4j.Session.run``       (tool span for Cypher, retrieval span for vector)
  - ``neo4j.AsyncSession.run``  (tool span for Cypher, retrieval span for vector)

All wrapper code is wrapped in try/except -- never breaks the user's Neo4j calls.
"""

from __future__ import annotations

import logging
import re

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Patterns that indicate a vector search operation in Neo4j.
_VECTOR_PATTERNS = re.compile(
    r"db\.index\.vector\.queryNodes"
    r"|db\.index\.vector\.queryRelationships"
    r"|gds\.similarity"
    r"|vector\.queryNodes"
    r"|vector\.queryRelationships",
    re.IGNORECASE,
)

# Patterns that indicate a graph query (Cypher).  Practically all Neo4j
# queries are Cypher, so this is intentionally broad.
_GRAPH_PATTERNS = re.compile(
    r"\b(MATCH|CREATE|MERGE|DELETE|DETACH|SET|REMOVE|RETURN|WITH|UNWIND|CALL)\b",
    re.IGNORECASE,
)


def _is_vector_query(query: str) -> bool:
    """Return True if the Cypher query contains Neo4j vector search procedures."""
    if not query or not isinstance(query, str):
        return False
    return _VECTOR_PATTERNS.search(query) is not None


def _is_graph_query(query: str) -> bool:
    """Return True if the query contains standard Cypher keywords."""
    if not query or not isinstance(query, str):
        return False
    return _GRAPH_PATTERNS.search(query) is not None


class Neo4jInstrumentor(BaseInstrumentor):
    """Instrumentor for the Neo4j Python driver.

    Patches ``Session.run`` for sync queries and ``AsyncSession.run``
    for async queries.  Vector search queries (using
    ``db.index.vector.queryNodes`` etc.) get retrieval spans; all other
    Cypher queries get tool spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import neo4j  # noqa: F401
        except ImportError:
            logger.debug("neo4j package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Neo4j instrumentation")
            return False

        patched_any = False

        # --- Session.run (sync) ---
        try:
            wrapt.wrap_function_wrapper(
                "neo4j",
                "Session.run",
                _sync_run_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch neo4j Session.run: %s", exc)

        # --- AsyncSession.run (async, may not exist in older versions) ---
        try:
            wrapt.wrap_function_wrapper(
                "neo4j",
                "AsyncSession.run",
                _async_run_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch neo4j AsyncSession.run: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any neo4j Session methods")
            return False

        self._instrumented = True
        logger.debug("Neo4j instrumented (Session.run, AsyncSession.run)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore Session.run
        try:
            import neo4j

            session_cls = getattr(neo4j, "Session", None)
            if session_cls is not None:
                method = getattr(session_cls, "run", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    session_cls.run = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore AsyncSession.run
        try:
            import neo4j

            async_cls = getattr(neo4j, "AsyncSession", None)
            if async_cls is not None:
                method = getattr(async_cls, "run", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    async_cls.run = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Neo4j uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the Cypher query string from positional or keyword args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _truncate_query(query: str, max_len: int = 500) -> str:
    """Truncate a Cypher query for span labelling."""
    if len(query) > max_len:
        return query[:max_len] + "..."
    return query


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper
# ---------------------------------------------------------------------------


def _sync_run_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for neo4j Session.run -- instruments all Cypher queries."""
    query = _extract_query(args, kwargs)

    if _is_vector_query(query):
        return _sync_vector_path(wrapped, args, kwargs, query)
    else:
        return _sync_cypher_path(wrapped, args, kwargs, query)


def _sync_vector_path(wrapped, args, kwargs, query):
    """Handle vector search queries with a retrieval span."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)

    try:
        span = start_retrieval_span(query=query_preview, source="neo4j-vector")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "neo4j")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.operation", "vector_search")
        except Exception as attr_exc:
            logger.debug("Failed to set neo4j vector span attributes: %s", attr_exc)

        try:
            _record_neo4j_retrieval(query=query_preview)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_cypher_path(wrapped, args, kwargs, query):
    """Handle general Cypher queries with a tool span."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)

    try:
        span = start_tool_span(tool_name="neo4j.cypher", tool_type="database")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "neo4j")
            span.set_attribute("db.statement", query_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set neo4j cypher span attributes: %s", attr_exc)

        try:
            _record_neo4j_query(query=query_preview)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrapper
# ---------------------------------------------------------------------------


async def _async_run_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for neo4j AsyncSession.run -- instruments all Cypher queries."""
    query = _extract_query(args, kwargs)

    if _is_vector_query(query):
        return await _async_vector_path(wrapped, args, kwargs, query)
    else:
        return await _async_cypher_path(wrapped, args, kwargs, query)


async def _async_vector_path(wrapped, args, kwargs, query):
    """Handle async vector search queries with a retrieval span."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)

    try:
        span = start_retrieval_span(query=query_preview, source="neo4j-vector")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "neo4j")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.operation", "vector_search")
        except Exception as attr_exc:
            logger.debug("Failed to set neo4j async vector span attributes: %s", attr_exc)

        try:
            _record_neo4j_retrieval(query=query_preview)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_cypher_path(wrapped, args, kwargs, query):
    """Handle async general Cypher queries with a tool span."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)

    try:
        span = start_tool_span(tool_name="neo4j.cypher", tool_type="database")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "neo4j")
            span.set_attribute("db.statement", query_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set neo4j async cypher span attributes: %s", attr_exc)

        try:
            _record_neo4j_query(query=query_preview)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_neo4j_retrieval(
    query: str,
) -> None:
    """Record a Neo4j vector retrieval operation to the context path.

    Neo4j vector retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="neo4j-vector",
        )


def _record_neo4j_query(
    query: str,
) -> None:
    """Record a Neo4j Cypher query operation to the context path.

    Query operations are recorded as tool calls within an active WaxellContext.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name="neo4j.cypher",
            input={"query": query},
            tool_type="database",
        )
