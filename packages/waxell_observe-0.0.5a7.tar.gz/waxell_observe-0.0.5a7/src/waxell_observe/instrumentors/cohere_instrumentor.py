"""Cohere auto-instrumentor for waxell-observe.

Monkey-patches Cohere's V2 chat, embed, and rerank methods to emit
OTel spans and record to the Waxell HTTP API.

Cohere V2 response format:
  - ``response.usage.tokens.input_tokens`` / ``output_tokens``
  - ``response.finish_reason``
  - ``response.model`` (echoed back or from request)

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class CohereInstrumentor(BaseInstrumentor):
    """Instrumentor for the Cohere Python SDK (``cohere`` package).

    Patches V2 ``chat`` for both sync and async clients.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import cohere  # noqa: F401
        except ImportError:
            logger.debug("cohere package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Cohere instrumentation")
            return False

        patched = False

        # Cohere V2 client: cohere.v2.client.V2Client.chat
        try:
            wrapt.wrap_function_wrapper(
                "cohere.v2.client",
                "V2Client.chat",
                _sync_chat_wrapper,
            )
            patched = True
        except Exception:
            pass

        # Async V2: cohere.v2.async_client.AsyncV2Client.chat
        try:
            wrapt.wrap_function_wrapper(
                "cohere.v2.async_client",
                "AsyncV2Client.chat",
                _async_chat_wrapper,
            )
        except Exception:
            pass

        # Fallback: cohere.ClientV2.chat (newer SDK versions)
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "cohere",
                    "ClientV2.chat",
                    _sync_chat_wrapper,
                )
                patched = True
            except Exception:
                pass

        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "cohere",
                    "Client.chat",
                    _sync_chat_wrapper,
                )
                patched = True
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find Cohere chat methods to patch")
            return False

        # Patch embed methods
        for mod_path, cls_attr in [
            ("cohere.v2.client", "V2Client.embed"),
            ("cohere", "ClientV2.embed"),
            ("cohere", "Client.embed"),
        ]:
            try:
                wrapt.wrap_function_wrapper(mod_path, cls_attr, _sync_embed_wrapper)
                logger.debug("Cohere embed patched: %s.%s", mod_path, cls_attr)
                break
            except Exception:
                pass

        # Patch rerank methods
        for mod_path, cls_attr in [
            ("cohere.v2.client", "V2Client.rerank"),
            ("cohere", "ClientV2.rerank"),
            ("cohere", "Client.rerank"),
        ]:
            try:
                wrapt.wrap_function_wrapper(mod_path, cls_attr, _sync_rerank_wrapper)
                logger.debug("Cohere rerank patched: %s.%s", mod_path, cls_attr)
                break
            except Exception:
                pass

        self._instrumented = True
        logger.debug("Cohere chat/embed/rerank instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Try all known paths
        for mod_path, cls_name in [
            ("cohere.v2.client", "V2Client"),
            ("cohere.v2.async_client", "AsyncV2Client"),
            ("cohere", "ClientV2"),
            ("cohere", "Client"),
        ]:
            try:
                import importlib
                mod = importlib.import_module(mod_path)
                cls = getattr(mod, cls_name, None)
                if cls and hasattr(cls.chat, "__wrapped__"):
                    cls.chat = cls.chat.__wrapped__  # type: ignore[attr-defined]
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        logger.debug("Cohere chat uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _extract_cohere_usage(response):
    """Extract token counts from Cohere's response format."""
    tokens_in, tokens_out = 0, 0
    usage = getattr(response, "usage", None)
    if usage:
        # V2 format: usage.tokens.input_tokens
        tokens = getattr(usage, "tokens", None)
        if tokens:
            tokens_in = getattr(tokens, "input_tokens", 0) or 0
            tokens_out = getattr(tokens, "output_tokens", 0) or 0
        else:
            # Fallback: usage.input_tokens directly
            tokens_in = getattr(usage, "input_tokens", 0) or 0
            tokens_out = getattr(usage, "output_tokens", 0) or 0
    # Also check billed_units
    if tokens_in == 0:
        billed = getattr(getattr(response, "meta", None), "billed_units", None)
        if billed:
            tokens_in = getattr(billed, "input_tokens", 0) or 0
            tokens_out = getattr(billed, "output_tokens", 0) or 0
    return tokens_in, tokens_out


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Cohere chat."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        messages = kwargs.get("messages", [])
        guard_result = check_prompt(messages, model=kwargs.get("model", ""))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="cohere")
    except Exception:
        return wrapped(*args, **kwargs)

    if is_streaming:
        try:
            stream = wrapped(*args, **kwargs)
            try:
                from ._stream_wrappers import CohereSyncStreamWrapper
                return CohereSyncStreamWrapper(stream, span, model)
            except Exception:
                try:
                    span.end()
                except Exception:
                    pass
                return stream
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_cohere_usage(response)
            response_model = getattr(response, "model", model) or model
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            finish_reason = getattr(response, "finish_reason", "")
            finish_reasons = [finish_reason] if finish_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_cohere(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Cohere async chat."""
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        messages = kwargs.get("messages", [])
        guard_result = check_prompt(messages, model=kwargs.get("model", ""))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="cohere")
    except Exception:
        return await wrapped(*args, **kwargs)

    if is_streaming:
        try:
            stream = await wrapped(*args, **kwargs)
            try:
                from ._stream_wrappers import CohereAsyncStreamWrapper
                return CohereAsyncStreamWrapper(stream, span, model)
            except Exception:
                try:
                    span.end()
                except Exception:
                    pass
                return stream
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_cohere_usage(response)
            response_model = getattr(response, "model", model) or model
            cost = estimate_cost(response_model, tokens_in, tokens_out)

            finish_reason = getattr(response, "finish_reason", "")
            finish_reasons = [finish_reason] if finish_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_cohere(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_cohere(response, request_model: str, kwargs: dict) -> None:
    """Record a Cohere LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    tokens_in, tokens_out = _extract_cohere_usage(response)
    response_model = getattr(response, "model", request_model) or request_model
    cost = estimate_cost(response_model, tokens_in, tokens_out)

    messages = kwargs.get("messages", [])
    prompt_preview = ""
    if messages:
        first = messages[0]
        if isinstance(first, dict):
            prompt_preview = str(first.get("content", ""))[:500]
        else:
            prompt_preview = str(getattr(first, "content", str(first)))[:500]

    response_preview = ""
    # V2: response.message.content[0].text
    msg = getattr(response, "message", None)
    if msg:
        content = getattr(msg, "content", None)
        if content and isinstance(content, list) and len(content) > 0:
            text = getattr(content[0], "text", str(content[0]))
            response_preview = str(text)[:500]
    # Fallback: response.text
    if not response_preview:
        text = getattr(response, "text", "")
        if text:
            response_preview = str(text)[:500]

    call_data = {
        "model": response_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "chat",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)

    # Auto-capture tool calls
    try:
        msg = getattr(response, "message", None)
        tool_calls = getattr(msg, "tool_calls", None) if msg else None
        if tool_calls:
            ctx = _current_context.get()
            if ctx:
                for tc in tool_calls:
                    ctx.record_tool_call(
                        name=getattr(tc, "name", getattr(getattr(tc, "function", None), "name", "unknown")),
                        input=getattr(tc, "parameters", getattr(getattr(tc, "function", None), "arguments", "")),
                        tool_type="function",
                    )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Embed wrapper
# ---------------------------------------------------------------------------


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Cohere embed."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "embed-english-v3.0")
    texts = kwargs.get("texts", [])
    input_count = len(texts) if isinstance(texts, list) else 1

    try:
        span = start_embedding_span(model=model, provider_name="cohere", input_count=input_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Cohere embed response: response.meta.billed_units.input_tokens
            tokens = 0
            meta = getattr(response, "meta", None)
            if meta:
                billed = getattr(meta, "billed_units", None)
                if billed:
                    tokens = getattr(billed, "input_tokens", 0) or 0

            embeddings = getattr(response, "embeddings", None)
            dimensions = 0
            if embeddings:
                if isinstance(embeddings, list) and len(embeddings) > 0:
                    first = embeddings[0]
                    dimensions = len(first) if isinstance(first, list) else 0
                elif hasattr(embeddings, "float_") and embeddings.float_:
                    dimensions = len(embeddings.float_[0]) if embeddings.float_ else 0

            cost = estimate_embedding_cost(model, tokens, "cohere")
            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set embed span attributes: %s", attr_exc)
        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Rerank wrapper
# ---------------------------------------------------------------------------


def _sync_rerank_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Cohere rerank."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query = kwargs.get("query", "")
    model = kwargs.get("model", "rerank-v3.5")

    try:
        span = start_retrieval_span(query=query, source=f"cohere-rerank:{model}")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results = getattr(response, "results", [])
            span.set_attribute("waxell.rerank.model", model)
            span.set_attribute("waxell.rerank.results_count", len(results))
            if results:
                span.set_attribute("waxell.rerank.top_score", getattr(results[0], "relevance_score", 0.0))
            # Token usage from meta
            meta = getattr(response, "meta", None)
            if meta:
                billed = getattr(meta, "billed_units", None)
                if billed:
                    search_units = getattr(billed, "search_units", 0) or 0
                    span.set_attribute("waxell.rerank.search_units", search_units)
        except Exception as attr_exc:
            logger.debug("Failed to set rerank span attributes: %s", attr_exc)
        return response
    finally:
        span.end()
