"""Presidio PII auto-instrumentor for waxell-observe.

Monkey-patches presidio_analyzer.AnalyzerEngine.analyze and
presidio_anonymizer.AnonymizerEngine.anonymize to emit guardrail
evaluation spans tracking PII detection and anonymization.

SECURITY: No actual PII text is recorded in spans -- only entity types,
counts, and text length.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PresidioInstrumentor(BaseInstrumentor):
    """Instrumentor for Presidio (``presidio-analyzer`` / ``presidio-anonymizer``).

    Patches AnalyzerEngine.analyze and AnonymizerEngine.anonymize.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import presidio_analyzer  # noqa: F401
        except ImportError:
            logger.debug("presidio_analyzer not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Presidio instrumentation")
            return False

        patched = False

        # Patch AnalyzerEngine.analyze
        try:
            wrapt.wrap_function_wrapper(
                "presidio_analyzer",
                "AnalyzerEngine.analyze",
                _analyzer_analyze_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch AnalyzerEngine.analyze: %s", exc)

        # Patch AnonymizerEngine.anonymize (optional -- anonymizer may not be installed)
        try:
            wrapt.wrap_function_wrapper(
                "presidio_anonymizer",
                "AnonymizerEngine.anonymize",
                _anonymizer_anonymize_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch AnonymizerEngine.anonymize: %s", exc)

        if not patched:
            logger.debug("Could not find Presidio methods to patch")
            return False

        self._instrumented = True
        logger.debug("Presidio instrumented (AnalyzerEngine.analyze + AnonymizerEngine.anonymize)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore AnalyzerEngine.analyze
        try:
            from presidio_analyzer import AnalyzerEngine

            if hasattr(AnalyzerEngine.analyze, "__wrapped__"):
                AnalyzerEngine.analyze = AnalyzerEngine.analyze.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore AnonymizerEngine.anonymize
        try:
            from presidio_anonymizer import AnonymizerEngine

            if hasattr(AnonymizerEngine.anonymize, "__wrapped__"):
                AnonymizerEngine.anonymize = AnonymizerEngine.anonymize.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Presidio uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _analyzer_analyze_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``AnalyzerEngine.analyze`` -- PII detection."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_guardrail_span(
            guardrail_name="presidio_analyzer",
            framework="presidio",
        )
        span.set_attribute("waxell.guardrail.method", "analyze")
    except Exception:
        return wrapped(*args, **kwargs)

    # Record input text length (NOT the actual text -- security)
    try:
        text = kwargs.get("text") or (args[0] if args else None)
        if text and isinstance(text, str):
            span.set_attribute("waxell.guardrail.input_length", len(text))
    except Exception:
        pass

    # Record requested language
    try:
        language = kwargs.get("language") or (args[1] if len(args) > 1 else None)
        if language:
            span.set_attribute("waxell.guardrail.language", str(language))
    except Exception:
        pass

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_analyzer_result(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _anonymizer_anonymize_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``AnonymizerEngine.anonymize`` -- PII anonymization."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_guardrail_span(
            guardrail_name="presidio_anonymizer",
            framework="presidio",
        )
        span.set_attribute("waxell.guardrail.method", "anonymize")
    except Exception:
        return wrapped(*args, **kwargs)

    # Record input text length (NOT the actual text -- security)
    try:
        text = kwargs.get("text") or (args[0] if args else None)
        if text and isinstance(text, str):
            span.set_attribute("waxell.guardrail.input_length", len(text))
    except Exception:
        pass

    # Record number of analyzer results being anonymized
    try:
        analyzer_results = kwargs.get("analyzer_results") or (
            args[1] if len(args) > 1 else None
        )
        if analyzer_results is not None:
            try:
                span.set_attribute(
                    "waxell.guardrail.entities_to_anonymize", len(analyzer_results)
                )
            except Exception:
                pass
    except Exception:
        pass

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_anonymizer_result(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_analyzer_result(span, results) -> None:
    """Extract analyzer results and set span attributes.

    results is a list of RecognizerResult objects, each with:
    entity_type, start, end, score
    """
    from ..tracing.attributes import WaxellAttributes

    entity_types = []
    entity_count = 0

    try:
        if results and hasattr(results, "__len__"):
            entity_count = len(results)
            seen_types = set()
            for r in results:
                entity_type = getattr(r, "entity_type", None)
                if entity_type and entity_type not in seen_types:
                    seen_types.add(entity_type)
                    entity_types.append(entity_type)
    except Exception:
        pass

    # Determine pass/fail: flagged if any entities detected
    flagged = entity_count > 0

    try:
        span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, not flagged)
        span.set_attribute(
            WaxellAttributes.GUARDRAIL_ACTION,
            "fail" if flagged else "pass",
        )
        span.set_attribute("waxell.guardrail.entities_detected", entity_count)
        if entity_types:
            span.set_attribute(
                "waxell.guardrail.entity_types", ",".join(entity_types)
            )
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_presidio(
            method="analyze",
            flagged=flagged,
            entity_count=entity_count,
            entity_types=entity_types,
        )
    except Exception:
        pass


def _record_anonymizer_result(span, result) -> None:
    """Extract anonymizer results and set span attributes.

    result is an AnonymizerResult with text and items attributes.
    """
    from ..tracing.attributes import WaxellAttributes

    items_count = 0

    try:
        items = getattr(result, "items", None)
        if items and hasattr(items, "__len__"):
            items_count = len(items)
    except Exception:
        pass

    try:
        # Anonymization always passes (it transforms the text)
        span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, True)
        span.set_attribute(WaxellAttributes.GUARDRAIL_ACTION, "anonymize")
        span.set_attribute("waxell.guardrail.items_anonymized", items_count)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_presidio(
            method="anonymize",
            flagged=False,
            entity_count=items_count,
            entity_types=[],
        )
    except Exception:
        pass


def _record_http_presidio(
    method: str,
    flagged: bool,
    entity_count: int,
    entity_types: list,
) -> None:
    """Record a Presidio operation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"guardrail:presidio_{method}",
            output={
                "passed": not flagged,
                "action": "fail" if flagged else ("anonymize" if method == "anonymize" else "pass"),
                "method": method,
                "entity_count": entity_count,
                "entity_types": entity_types,
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
