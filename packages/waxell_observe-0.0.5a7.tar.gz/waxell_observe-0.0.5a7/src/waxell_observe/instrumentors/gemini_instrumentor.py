"""Google Gemini auto-instrumentor for waxell-observe.

Monkey-patches ``google.generativeai.GenerativeModel.generate_content``
and ``generate_content_async`` to emit OTel spans and record to the
Waxell HTTP API.  Also patches ``google.generativeai.embed_content``
to emit embedding spans.

Gemini response format:
  - ``response.usage_metadata.prompt_token_count``
  - ``response.usage_metadata.candidates_token_count``
  - ``response.candidates[0].finish_reason`` (enum)

Gemini embed_content response format:
  - ``response["embedding"]`` (single input) or ``response["embeddings"]`` (batch)

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GeminiInstrumentor(BaseInstrumentor):
    """Instrumentor for Google Generative AI (``google-generativeai`` package).

    Patches ``GenerativeModel.generate_content`` sync and async, and
    ``genai.embed_content`` for embedding instrumentation.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import google.generativeai  # noqa: F401
        except ImportError:
            logger.debug("google-generativeai not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Gemini instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "google.generativeai",
                "GenerativeModel.generate_content",
                _sync_generate_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch GenerativeModel.generate_content: %s", exc)
            return False

        try:
            wrapt.wrap_function_wrapper(
                "google.generativeai",
                "GenerativeModel.generate_content_async",
                _async_generate_wrapper,
            )
        except Exception:
            logger.debug("Async generate_content_async not found -- sync-only instrumentation")

        # Patch embed_content
        try:
            wrapt.wrap_function_wrapper(
                "google.generativeai",
                "embed_content",
                _sync_embed_wrapper,
            )
        except Exception:
            logger.debug("embed_content not found -- embedding instrumentation skipped")

        self._instrumented = True
        logger.debug("Gemini GenerativeModel instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import google.generativeai as genai

            if hasattr(genai.GenerativeModel.generate_content, "__wrapped__"):
                genai.GenerativeModel.generate_content = genai.GenerativeModel.generate_content.__wrapped__
            if hasattr(genai.GenerativeModel.generate_content_async, "__wrapped__"):
                genai.GenerativeModel.generate_content_async = genai.GenerativeModel.generate_content_async.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import google.generativeai as genai

            if hasattr(genai.embed_content, "__wrapped__"):
                genai.embed_content = genai.embed_content.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Gemini GenerativeModel uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_gemini_usage(response):
    """Extract token counts from Gemini response.usage_metadata."""
    tokens_in, tokens_out = 0, 0
    meta = getattr(response, "usage_metadata", None)
    if meta:
        tokens_in = getattr(meta, "prompt_token_count", 0) or 0
        tokens_out = getattr(meta, "candidates_token_count", 0) or 0
    return tokens_in, tokens_out


def _extract_model_name(instance):
    """Get the model name from the GenerativeModel instance."""
    return getattr(instance, "model_name", getattr(instance, "_model_name", "gemini-unknown"))


def _extract_finish_reason(response):
    """Extract finish reason from Gemini response."""
    try:
        candidates = getattr(response, "candidates", None)
        if candidates and len(candidates) > 0:
            reason = getattr(candidates[0], "finish_reason", None)
            if reason is not None:
                # finish_reason is an enum in Gemini SDK
                return str(reason.name) if hasattr(reason, "name") else str(reason)
    except Exception:
        pass
    return ""


def _extract_text(response):
    """Extract text content from Gemini response."""
    try:
        return response.text
    except (ValueError, AttributeError):
        try:
            candidates = getattr(response, "candidates", None)
            if candidates and len(candidates) > 0:
                parts = getattr(candidates[0].content, "parts", [])
                if parts:
                    return getattr(parts[0], "text", "")
        except Exception:
            pass
    return ""


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``GenerativeModel.generate_content``."""
    # --- Prompt guard ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        # Gemini takes contents as first positional arg or kwargs
        contents = args[0] if args else kwargs.get("contents", "")
        if isinstance(contents, str):
            messages = [{"role": "user", "content": contents}]
        elif isinstance(contents, list):
            messages = [{"role": "user", "content": str(c)} for c in contents]
        else:
            messages = [{"role": "user", "content": str(contents)}]

        guard_result = check_prompt(messages, model=_extract_model_name(instance))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = _extract_model_name(instance)
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="google")
    except Exception:
        return wrapped(*args, **kwargs)

    if is_streaming:
        try:
            stream = wrapped(*args, **kwargs)
            try:
                from ._stream_wrappers import GeminiSyncStreamWrapper
                return GeminiSyncStreamWrapper(stream, span, model)
            except Exception:
                try:
                    span.end()
                except Exception:
                    pass
                return stream
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_gemini_usage(response)
            cost = estimate_cost(model, tokens_in, tokens_out)
            finish_reason = _extract_finish_reason(response)
            finish_reasons = [finish_reason] if finish_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_gemini(response, model, args, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_generate_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``GenerativeModel.generate_content_async``."""
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        contents = args[0] if args else kwargs.get("contents", "")
        if isinstance(contents, str):
            messages = [{"role": "user", "content": contents}]
        elif isinstance(contents, list):
            messages = [{"role": "user", "content": str(c)} for c in contents]
        else:
            messages = [{"role": "user", "content": str(contents)}]

        guard_result = check_prompt(messages, model=_extract_model_name(instance))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
    except Exception:
        pass
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
        from ..cost import estimate_cost
    except Exception:
        return await wrapped(*args, **kwargs)

    model = _extract_model_name(instance)
    is_streaming = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="google")
    except Exception:
        return await wrapped(*args, **kwargs)

    if is_streaming:
        try:
            stream = await wrapped(*args, **kwargs)
            try:
                from ._stream_wrappers import GeminiAsyncStreamWrapper
                return GeminiAsyncStreamWrapper(stream, span, model)
            except Exception:
                try:
                    span.end()
                except Exception:
                    pass
                return stream
        except Exception as exc:
            try:
                _record_error(span, exc)
                span.end()
            except Exception:
                pass
            raise

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens_in, tokens_out = _extract_gemini_usage(response)
            cost = estimate_cost(model, tokens_in, tokens_out)
            finish_reason = _extract_finish_reason(response)
            finish_reasons = [finish_reason] if finish_reason else []

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_gemini(response, model, args, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_gemini(response, model: str, args: tuple, kwargs: dict) -> None:
    """Record a Gemini LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_cost

    tokens_in, tokens_out = _extract_gemini_usage(response)
    cost = estimate_cost(model, tokens_in, tokens_out)

    # Build prompt preview from contents arg
    prompt_preview = ""
    contents = args[0] if args else kwargs.get("contents", "")
    if isinstance(contents, str):
        prompt_preview = contents[:500]
    elif isinstance(contents, list):
        prompt_preview = str(contents[0])[:500] if contents else ""
    else:
        prompt_preview = str(contents)[:500]

    response_preview = _extract_text(response)[:500]

    call_data = {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "generate_content",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)

    # Auto-capture function calls + decisions from response
    try:
        candidates = getattr(response, "candidates", None)
        if candidates and len(candidates) > 0:
            parts = getattr(candidates[0].content, "parts", [])
            tool_calls = []
            for part in parts:
                fc = getattr(part, "function_call", None)
                if fc:
                    tool_calls.append({
                        "name": getattr(fc, "name", "unknown"),
                        "input": dict(getattr(fc, "args", {})),
                    })
            if tool_calls:
                from ._auto_decision import record_tool_decisions, extract_tool_names_from_request

                available = extract_tool_names_from_request(kwargs)
                record_tool_decisions(tool_calls=tool_calls, available_tools=available or None)
    except Exception:
        pass  # Never break user code


# ---------------------------------------------------------------------------
# Embedding wrappers
# ---------------------------------------------------------------------------


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``genai.embed_content``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "models/text-embedding-004")
    content = kwargs.get("content", args[0] if args else "")

    # Count inputs
    if isinstance(content, list):
        input_count = len(content)
    else:
        input_count = 1

    try:
        span = start_embedding_span(model=model, provider_name="google", input_count=input_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Gemini embed response is a dict:
            #   single: response["embedding"] is a list of floats
            #   batch:  response["embeddings"] is a list of lists
            if "embeddings" in response:
                dimensions = len(response["embeddings"][0]) if response["embeddings"] else 0
            else:
                dimensions = len(response.get("embedding", []))

            # Token count is not always available in Gemini embed response
            tokens = 0
            cost = estimate_embedding_cost(model, tokens, "google")

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_gemini_embed(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _record_http_gemini_embed(response, model: str, kwargs: dict) -> None:
    """Record a Gemini embedding call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector
    from ..cost import estimate_embedding_cost

    tokens = 0
    cost = estimate_embedding_cost(model, tokens, "google")

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "embeddings",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step("embedding:gemini", output=call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
