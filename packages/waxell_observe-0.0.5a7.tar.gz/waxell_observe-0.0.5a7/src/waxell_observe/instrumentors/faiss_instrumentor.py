"""FAISS auto-instrumentor for waxell-observe.

Monkey-patches FAISS's Index methods to emit OTel spans and record
to the Waxell HTTP API.

Patched methods:
  - faiss.Index.search  (retrieval span -- base class covers all index types)
  - faiss.Index.add     (step span -- tracking index build operations)

All wrapper code is wrapped in try/except -- never breaks the user's FAISS calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FAISSInstrumentor(BaseInstrumentor):
    """Instrumentor for the FAISS library (``faiss-cpu`` / ``faiss-gpu``).

    Patches ``faiss.Index.search`` for retrieval spans and
    ``faiss.Index.add`` for step spans.  The base-class patch covers
    all index subclasses (IndexFlatL2, IndexFlatIP, IndexIVFFlat, etc.).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import faiss  # noqa: F401
        except ImportError:
            logger.debug("faiss package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping FAISS instrumentation")
            return False

        patched = False

        # Patch Index.search (base class -- covers ALL index subclasses)
        try:
            wrapt.wrap_function_wrapper(
                "faiss",
                "Index.search",
                _search_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch faiss.Index.search: %s", exc)

        # Patch Index.add (vector insertion)
        try:
            wrapt.wrap_function_wrapper(
                "faiss",
                "Index.add",
                _add_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch faiss.Index.add: %s", exc)

        if not patched:
            logger.debug("Could not find any FAISS Index methods to patch")
            return False

        self._instrumented = True
        logger.debug("FAISS Index instrumented (search, add)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import faiss

            for method_name in ("search", "add"):
                try:
                    method = getattr(faiss.Index, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(faiss.Index, method_name, method.__wrapped__)
                except Exception:
                    pass
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("FAISS Index uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Index.search`` (nearest-neighbor retrieval).

    Args layout: index.search(query_vectors, k)
        query_vectors: numpy array of shape (nq, d)
        k: int, number of nearest neighbors
    Returns: (distances, indices) tuple of numpy arrays, each shape (nq, k)
    """
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract search parameters safely
    nq = 0
    k = 0
    dimension = 0
    ntotal = 0
    index_type = "Index"

    try:
        if args:
            query_vectors = args[0]
            if hasattr(query_vectors, "shape"):
                nq = int(query_vectors.shape[0])
            if len(args) > 1:
                k = int(args[1])
        k = int(kwargs.get("k", k))
    except Exception:
        pass

    try:
        if instance is not None:
            dimension = int(getattr(instance, "d", 0))
            ntotal = int(getattr(instance, "ntotal", 0))
            index_type = type(instance).__name__
    except Exception:
        pass

    try:
        span = start_retrieval_span(query="faiss.search", source="faiss")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.faiss.index_type", index_type)
            span.set_attribute("waxell.faiss.k", k)
            span.set_attribute("waxell.faiss.nq", nq)
            span.set_attribute("waxell.faiss.dimension", dimension)
            span.set_attribute("waxell.faiss.ntotal", ntotal)
            span.set_attribute("waxell.retrieval.results_count", nq * k)
        except Exception as attr_exc:
            logger.debug("Failed to set FAISS search span attributes: %s", attr_exc)

        try:
            _record_search(nq=nq, k=k, index_type=index_type, ntotal=ntotal)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _add_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Index.add`` (adding vectors to an index).

    Args layout: index.add(vectors)
        vectors: numpy array of shape (n, d)
    """
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    n_vectors = 0
    dimension = 0
    index_type = "Index"

    try:
        if args:
            vectors = args[0]
            if hasattr(vectors, "shape"):
                n_vectors = int(vectors.shape[0])
    except Exception:
        pass

    try:
        if instance is not None:
            dimension = int(getattr(instance, "d", 0))
            index_type = type(instance).__name__
    except Exception:
        pass

    try:
        span = start_step_span(step_name="faiss.add")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.faiss.index_type", index_type)
            span.set_attribute("waxell.faiss.n_vectors", n_vectors)
            span.set_attribute("waxell.faiss.dimension", dimension)
            span.set_attribute("waxell.faiss.operation", "add")
        except Exception as attr_exc:
            logger.debug("Failed to set FAISS add span attributes: %s", attr_exc)

        try:
            _record_add(n_vectors=n_vectors, index_type=index_type)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording helpers
# ---------------------------------------------------------------------------


def _record_search(nq: int, k: int, index_type: str, ntotal: int) -> None:
    """Record a FAISS search to the HTTP path (context or collector)."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query="faiss.search",
            source="faiss",
            results_count=nq * k,
        )


def _record_add(n_vectors: int, index_type: str) -> None:
    """Record a FAISS add operation to the context (if active)."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        try:
            ctx.record_step(
                "faiss.add",
                output={
                    "n_vectors": n_vectors,
                    "index_type": index_type,
                },
            )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
