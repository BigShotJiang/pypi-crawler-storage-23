"""Google Cloud Text-to-Speech auto-instrumentor for waxell-observe.

Monkey-patches Google Cloud TTS SDK methods to emit OTel step spans for
text-to-speech operations:
  - ``TextToSpeechClient.synthesize_speech``       -- sync
  - ``TextToSpeechAsyncClient.synthesize_speech``   -- async

The Google Cloud TTS Python SDK (``google-cloud-texttospeech``) accepts:
  - ``synthesis_input`` (SynthesisInput) -- contains text or ssml
  - ``voice`` (VoiceSelectionParams) -- language_code, name
  - ``audio_config`` (AudioConfig) -- audio_encoding, etc.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GoogleCloudTTSInstrumentor(BaseInstrumentor):
    """Instrumentor for the Google Cloud Text-to-Speech SDK.

    Patches ``TextToSpeechClient.synthesize_speech`` and
    ``TextToSpeechAsyncClient.synthesize_speech``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import google.cloud.texttospeech  # noqa: F401
        except ImportError:
            logger.debug("google-cloud-texttospeech package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Google Cloud TTS instrumentation")
            return False

        patched = False

        # Patch sync TextToSpeechClient.synthesize_speech
        try:
            wrapt.wrap_function_wrapper(
                "google.cloud.texttospeech_v1.services.text_to_speech",
                "TextToSpeechClient.synthesize_speech",
                _sync_synthesize_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Google Cloud TTS sync synthesize_speech: %s", exc)

        # Patch async TextToSpeechAsyncClient.synthesize_speech
        try:
            wrapt.wrap_function_wrapper(
                "google.cloud.texttospeech_v1.services.text_to_speech",
                "TextToSpeechAsyncClient.synthesize_speech",
                _async_synthesize_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Google Cloud TTS async synthesize_speech: %s", exc)

        if not patched:
            logger.debug("Could not find any Google Cloud TTS methods to patch")
            return False

        self._instrumented = True
        logger.debug("Google Cloud TTS instrumented (synthesize_speech, sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from google.cloud.texttospeech_v1.services import text_to_speech

            for cls_name in ("TextToSpeechClient", "TextToSpeechAsyncClient"):
                cls = getattr(text_to_speech, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "synthesize_speech", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "synthesize_speech", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Google Cloud TTS uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_synthesize_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Google Cloud ``TextToSpeechClient.synthesize_speech``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    language, voice_name, text_length, audio_encoding = _extract_params(args, kwargs)

    try:
        span = start_step_span(step_name="google_cloud.tts.synthesize")
        _set_request_attrs(span, language, voice_name, text_length, audio_encoding)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.google_cloud_tts.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call(
                "google_cloud.tts.synthesize", language, voice_name, text_length, latency
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_synthesize_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Google Cloud ``TextToSpeechAsyncClient.synthesize_speech``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    language, voice_name, text_length, audio_encoding = _extract_params(args, kwargs)

    try:
        span = start_step_span(step_name="google_cloud.tts.synthesize")
        _set_request_attrs(span, language, voice_name, text_length, audio_encoding)
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.google_cloud_tts.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call(
                "google_cloud.tts.synthesize", language, voice_name, text_length, latency
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Parameter extraction helpers
# ---------------------------------------------------------------------------


def _extract_params(args, kwargs) -> tuple:
    """Extract language, voice_name, text_length, audio_encoding from synthesize_speech args.

    The Google Cloud TTS SDK accepts these as keyword arguments or a request object:
      - synthesis_input (SynthesisInput) -- contains .text or .ssml
      - voice (VoiceSelectionParams) -- contains .language_code, .name
      - audio_config (AudioConfig) -- contains .audio_encoding
    """
    language = ""
    voice_name = ""
    text_length = 0
    audio_encoding = ""

    try:
        # Try to extract from a request object first (newer SDK style)
        request = kwargs.get("request", None)
        if request is None and args:
            # Could be positional
            request = args[0] if args else None

        if request is not None and not isinstance(request, dict):
            # Proto-style request object
            synthesis_input = getattr(request, "input", None) or getattr(
                request, "synthesis_input", None
            )
            voice = getattr(request, "voice", None)
            audio_config = getattr(request, "audio_config", None)
        elif isinstance(request, dict):
            synthesis_input = request.get("input") or request.get("synthesis_input")
            voice = request.get("voice")
            audio_config = request.get("audio_config")
        else:
            synthesis_input = kwargs.get("input") or kwargs.get("synthesis_input")
            voice = kwargs.get("voice")
            audio_config = kwargs.get("audio_config")

        # Extract text length from synthesis_input
        if synthesis_input is not None:
            text = ""
            if isinstance(synthesis_input, dict):
                text = synthesis_input.get("text", "") or synthesis_input.get("ssml", "")
            else:
                text = getattr(synthesis_input, "text", "") or getattr(
                    synthesis_input, "ssml", ""
                )
            text_length = len(str(text)) if text else 0

        # Extract voice params
        if voice is not None:
            if isinstance(voice, dict):
                language = voice.get("language_code", "")
                voice_name = voice.get("name", "")
            else:
                language = getattr(voice, "language_code", "")
                voice_name = getattr(voice, "name", "")

        # Extract audio encoding
        if audio_config is not None:
            if isinstance(audio_config, dict):
                audio_encoding = str(audio_config.get("audio_encoding", ""))
            else:
                enc = getattr(audio_config, "audio_encoding", "")
                # Enum values -- try to get the name
                audio_encoding = str(getattr(enc, "name", enc))
    except Exception:
        pass

    return str(language), str(voice_name), text_length, str(audio_encoding)


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_request_attrs(
    span, language: str, voice_name: str, text_length: int, audio_encoding: str
) -> None:
    """Set request attributes for a Google Cloud TTS span."""
    if language:
        span.set_attribute("waxell.google_cloud_tts.language", language)
    if voice_name:
        span.set_attribute("waxell.google_cloud_tts.voice_name", voice_name)
    if text_length:
        span.set_attribute("waxell.google_cloud_tts.text_length", text_length)
    if audio_encoding:
        span.set_attribute("waxell.google_cloud_tts.audio_encoding", audio_encoding)


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tts_call(
    task: str, language: str, voice_name: str, text_length: int, latency: float
) -> None:
    """Record a Google Cloud TTS call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": "google-cloud-tts",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[tts text_length={text_length} voice={voice_name} lang={language}]",
        "response_preview": f"[tts voice={voice_name} latency={latency * 1000:.0f}ms]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
