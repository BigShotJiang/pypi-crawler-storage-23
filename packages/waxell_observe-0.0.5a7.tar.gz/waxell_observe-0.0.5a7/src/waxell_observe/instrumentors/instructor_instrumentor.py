"""Instructor auto-instrumentor for waxell-observe.

Monkey-patches ``instructor.client.Instructor.create`` (and related methods)
to emit OTel spans and record to the Waxell HTTP API.

Instructor wraps OpenAI/Anthropic/etc. clients and adds structured output
via response_model validation with automatic retries.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class InstructorInstrumentor(BaseInstrumentor):
    """Instrumentor for Instructor (``instructor`` package).

    Patches Instructor.create and Instructor.create_partial.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import instructor  # noqa: F401
        except ImportError:
            logger.debug("instructor not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Instructor instrumentation")
            return False

        patched = False

        # Patch Instructor.create (sync structured extraction)
        try:
            wrapt.wrap_function_wrapper(
                "instructor.client",
                "Instructor.create",
                _create_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Instructor.create: %s", exc)

        # Patch Instructor.create_partial (streaming structured extraction)
        try:
            wrapt.wrap_function_wrapper(
                "instructor.client",
                "Instructor.create_partial",
                _create_partial_wrapper,
            )
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find Instructor methods to patch")
            return False

        self._instrumented = True
        logger.debug("Instructor instrumented (Instructor.create)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from instructor.client import Instructor

            if hasattr(Instructor.create, "__wrapped__"):
                Instructor.create = Instructor.create.__wrapped__
            if hasattr(getattr(Instructor, "create_partial", None), "__wrapped__"):
                Instructor.create_partial = Instructor.create_partial.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Instructor uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _create_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Instructor.create`` -- structured LLM extraction."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    response_model = kwargs.get("response_model", None)
    max_retries = kwargs.get("max_retries", 1)

    response_model_name = ""
    try:
        if response_model is not None:
            response_model_name = getattr(response_model, "__name__", str(response_model))
    except Exception:
        pass

    try:
        span = start_llm_span(model=str(model), provider_name="instructor")
        span.set_attribute("waxell.instructor.response_model", response_model_name)
        span.set_attribute("waxell.instructor.max_retries", max_retries)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.instructor.result_type", type(result).__name__)

            # Try to extract retry count from instructor metadata
            retry_count = getattr(result, "_raw_response", None)
            if hasattr(result, "__pydantic_extra__"):
                extra = result.__pydantic_extra__ or {}
                if "retries" in extra:
                    span.set_attribute("waxell.instructor.retry_count", extra["retries"])
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_instructor(result, str(model), response_model_name, max_retries)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _create_partial_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Instructor.create_partial`` -- streaming extraction."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    response_model = kwargs.get("response_model", None)

    response_model_name = ""
    try:
        if response_model is not None:
            response_model_name = getattr(response_model, "__name__", str(response_model))
    except Exception:
        pass

    try:
        span = start_llm_span(model=str(model), provider_name="instructor")
        span.set_attribute("waxell.instructor.response_model", response_model_name)
        span.set_attribute("waxell.instructor.mode", "partial")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_http_instructor(result, model: str, response_model_name: str, max_retries: int) -> None:
    """Record an Instructor call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"instructor.create:{response_model_name}",
        "prompt_preview": "",
        "response_preview": str(result)[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
