"""Deepgram auto-instrumentor for waxell-observe.

Monkey-patches Deepgram SDK methods to emit OTel step spans for
speech-to-text (STT) and text-to-speech (TTS) operations:
  - ``DeepgramClient.listen.rest.v1.transcribe_file``  -- file-based STT
  - ``DeepgramClient.listen.rest.v1.transcribe_url``   -- URL-based STT
  - ``DeepgramClient.listen.live``                     -- live streaming STT
  - ``DeepgramClient.speak.rest.v1.stream``            -- TTS

The Deepgram Python SDK (``deepgram-sdk``) returns typed response objects:
  STT responses:
    - ``response.results.channels[0].alternatives[0].transcript``
    - ``response.results.channels[0].alternatives[0].confidence``
    - ``response.results.channels[0].alternatives[0].words`` (list)
    - ``response.metadata.duration``
    - ``response.metadata.model_info``

  TTS responses:
    - Streaming bytes (audio content)
    - ``response.content_type``

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class DeepgramInstrumentor(BaseInstrumentor):
    """Instrumentor for the Deepgram Python SDK (``deepgram-sdk`` package).

    Patches STT methods (``transcribe_file``, ``transcribe_url``) and
    TTS methods (``speak.rest.v1.stream``).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import deepgram  # noqa: F401
        except ImportError:
            logger.debug("deepgram package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Deepgram instrumentation")
            return False

        patched = False

        # Patch listen.rest.v1.transcribe_file (sync)
        try:
            wrapt.wrap_function_wrapper(
                "deepgram.clients.listen.v1.rest",
                "ListenRESTClient.transcribe_file",
                _sync_transcribe_file_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Deepgram transcribe_file: %s", exc)

        # Patch listen.rest.v1.transcribe_url (sync)
        try:
            wrapt.wrap_function_wrapper(
                "deepgram.clients.listen.v1.rest",
                "ListenRESTClient.transcribe_url",
                _sync_transcribe_url_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Deepgram transcribe_url: %s", exc)

        # Patch async listen (transcribe_file)
        try:
            wrapt.wrap_function_wrapper(
                "deepgram.clients.listen.v1.rest",
                "AsyncListenRESTClient.transcribe_file",
                _async_transcribe_file_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Deepgram async transcribe_file: %s", exc)

        # Patch async listen (transcribe_url)
        try:
            wrapt.wrap_function_wrapper(
                "deepgram.clients.listen.v1.rest",
                "AsyncListenRESTClient.transcribe_url",
                _async_transcribe_url_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Deepgram async transcribe_url: %s", exc)

        # Patch speak.rest.v1.stream (sync TTS)
        try:
            wrapt.wrap_function_wrapper(
                "deepgram.clients.speak.v1.rest",
                "SpeakRESTClient.stream",
                _sync_speak_stream_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Deepgram speak stream: %s", exc)

        # Patch speak.rest.v1.stream (async TTS)
        try:
            wrapt.wrap_function_wrapper(
                "deepgram.clients.speak.v1.rest",
                "AsyncSpeakRESTClient.stream",
                _async_speak_stream_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Deepgram async speak stream: %s", exc)

        if not patched:
            logger.debug("Could not find any Deepgram methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "Deepgram instrumented (transcribe_file + transcribe_url + speak stream, sync + async)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from deepgram.clients.listen.v1 import rest as listen_rest

            for cls_name in ("ListenRESTClient", "AsyncListenRESTClient"):
                cls = getattr(listen_rest, cls_name, None)
                if cls is None:
                    continue
                for attr in ("transcribe_file", "transcribe_url"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        try:
            from deepgram.clients.speak.v1 import rest as speak_rest

            for cls_name in ("SpeakRESTClient", "AsyncSpeakRESTClient"):
                cls = getattr(speak_rest, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "stream", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "stream", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Deepgram uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Deepgram responses
# ---------------------------------------------------------------------------


def _extract_stt_data(response) -> dict:
    """Extract transcript, confidence, word count, duration from STT response."""
    data = {
        "transcript": "",
        "confidence": 0.0,
        "word_count": 0,
        "duration": 0.0,
        "model": "",
        "language": "",
    }

    if response is None:
        return data

    try:
        # Navigate: response.results.channels[0].alternatives[0]
        results = getattr(response, "results", None)
        if results is None and isinstance(response, dict):
            results = response.get("results")

        if results is not None:
            channels = getattr(results, "channels", None)
            if channels is None and isinstance(results, dict):
                channels = results.get("channels", [])
            if channels and len(channels) > 0:
                channel = channels[0]
                alternatives = getattr(channel, "alternatives", None)
                if alternatives is None and isinstance(channel, dict):
                    alternatives = channel.get("alternatives", [])
                if alternatives and len(alternatives) > 0:
                    alt = alternatives[0]
                    if isinstance(alt, dict):
                        data["transcript"] = alt.get("transcript", "")
                        data["confidence"] = alt.get("confidence", 0.0)
                        words = alt.get("words", [])
                    else:
                        data["transcript"] = getattr(alt, "transcript", "")
                        data["confidence"] = getattr(alt, "confidence", 0.0)
                        words = getattr(alt, "words", [])
                    if isinstance(words, list):
                        data["word_count"] = len(words)

        # Metadata: duration, model
        metadata = getattr(response, "metadata", None)
        if metadata is None and isinstance(response, dict):
            metadata = response.get("metadata")

        if metadata is not None:
            if isinstance(metadata, dict):
                data["duration"] = metadata.get("duration", 0.0)
                model_info = metadata.get("model_info", {})
                if isinstance(model_info, dict):
                    # model_info is keyed by model UUID
                    for _key, info in model_info.items():
                        if isinstance(info, dict):
                            data["model"] = info.get("name", "")
                            break
            else:
                data["duration"] = getattr(metadata, "duration", 0.0)
                model_info = getattr(metadata, "model_info", {})
                if isinstance(model_info, dict):
                    for _key, info in model_info.items():
                        name = info.get("name", "") if isinstance(info, dict) else getattr(info, "name", "")
                        if name:
                            data["model"] = name
                            break
    except Exception:
        pass

    return data


# ---------------------------------------------------------------------------
# STT Wrapper functions
# ---------------------------------------------------------------------------


def _sync_transcribe_file_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Deepgram ``ListenRESTClient.transcribe_file``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="deepgram.transcribe")
        span.set_attribute("waxell.deepgram.method", "transcribe_file")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_stt_data(response)
            _set_stt_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Deepgram STT span attributes: %s", attr_exc)

        try:
            _record_stt_call("deepgram.transcribe_file", data, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_transcribe_url_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Deepgram ``ListenRESTClient.transcribe_url``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="deepgram.transcribe")
        span.set_attribute("waxell.deepgram.method", "transcribe_url")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_stt_data(response)
            _set_stt_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Deepgram STT span attributes: %s", attr_exc)

        try:
            _record_stt_call("deepgram.transcribe_url", data, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_transcribe_file_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Deepgram ``AsyncListenRESTClient.transcribe_file``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="deepgram.transcribe")
        span.set_attribute("waxell.deepgram.method", "transcribe_file")
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_stt_data(response)
            _set_stt_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Deepgram async STT span attributes: %s", attr_exc)

        try:
            _record_stt_call("deepgram.transcribe_file", data, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_transcribe_url_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Deepgram ``AsyncListenRESTClient.transcribe_url``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="deepgram.transcribe")
        span.set_attribute("waxell.deepgram.method", "transcribe_url")
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_stt_data(response)
            _set_stt_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Deepgram async STT span attributes: %s", attr_exc)

        try:
            _record_stt_call("deepgram.transcribe_url", data, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# TTS Wrapper functions
# ---------------------------------------------------------------------------


def _sync_speak_stream_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Deepgram ``SpeakRESTClient.stream``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract text input from args/kwargs
    text = ""
    if args:
        source = args[0]
        if isinstance(source, dict):
            text = source.get("text", "")
        elif isinstance(source, str):
            text = source
    if not text:
        source = kwargs.get("source", {})
        if isinstance(source, dict):
            text = source.get("text", "")
        elif isinstance(source, str):
            text = source

    try:
        span = start_step_span(step_name="deepgram.speak")
        span.set_attribute("waxell.deepgram.method", "speak_stream")
        if text:
            span.set_attribute("waxell.deepgram.text_length", len(text))
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            _set_tts_span_attributes(span, text, kwargs, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Deepgram TTS span attributes: %s", attr_exc)

        try:
            _record_tts_call("deepgram.speak_stream", text, kwargs, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_speak_stream_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Deepgram ``AsyncSpeakRESTClient.stream``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    text = ""
    if args:
        source = args[0]
        if isinstance(source, dict):
            text = source.get("text", "")
        elif isinstance(source, str):
            text = source
    if not text:
        source = kwargs.get("source", {})
        if isinstance(source, dict):
            text = source.get("text", "")
        elif isinstance(source, str):
            text = source

    try:
        span = start_step_span(step_name="deepgram.speak")
        span.set_attribute("waxell.deepgram.method", "speak_stream")
        if text:
            span.set_attribute("waxell.deepgram.text_length", len(text))
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            _set_tts_span_attributes(span, text, kwargs, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Deepgram async TTS span attributes: %s", attr_exc)

        try:
            _record_tts_call("deepgram.speak_stream", text, kwargs, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_stt_span_attributes(span, data: dict, latency: float) -> None:
    """Set OTel span attributes for an STT operation."""
    if data["model"]:
        span.set_attribute("waxell.deepgram.model", data["model"])
    if data["language"]:
        span.set_attribute("waxell.deepgram.language", data["language"])
    if data["duration"]:
        span.set_attribute("waxell.deepgram.audio_duration", data["duration"])
    if data["transcript"]:
        span.set_attribute("waxell.deepgram.transcript_preview", data["transcript"][:500])
    span.set_attribute("waxell.deepgram.confidence", data["confidence"])
    span.set_attribute("waxell.deepgram.word_count", data["word_count"])
    span.set_attribute("waxell.deepgram.latency_ms", round(latency * 1000, 2))


def _set_tts_span_attributes(span, text: str, kwargs: dict, latency: float) -> None:
    """Set OTel span attributes for a TTS operation."""
    if text:
        span.set_attribute("waxell.deepgram.text_length", len(text))
    # Extract model from options
    options = kwargs.get("options", {})
    if isinstance(options, dict):
        model = options.get("model", "")
        encoding = options.get("encoding", "")
    else:
        model = getattr(options, "model", "")
        encoding = getattr(options, "encoding", "")
    if model:
        span.set_attribute("waxell.deepgram.model", str(model))
    if encoding:
        span.set_attribute("waxell.deepgram.encoding", str(encoding))
    span.set_attribute("waxell.deepgram.latency_ms", round(latency * 1000, 2))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_stt_call(task: str, data: dict, latency: float) -> None:
    """Record a Deepgram STT call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": data.get("model", "deepgram"),
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[audio duration={data.get('duration', 0):.1f}s]",
        "response_preview": str(data.get("transcript", ""))[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_tts_call(task: str, text: str, kwargs: dict, latency: float) -> None:
    """Record a Deepgram TTS call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": "deepgram-tts",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": str(text)[:500] if text else "",
        "response_preview": f"[tts latency={latency * 1000:.0f}ms]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
