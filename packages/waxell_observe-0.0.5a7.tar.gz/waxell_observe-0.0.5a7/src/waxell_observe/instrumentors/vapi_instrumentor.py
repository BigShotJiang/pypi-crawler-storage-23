"""Vapi voice AI auto-instrumentor for waxell-observe.

Monkey-patches ``vapi.Vapi.start``, ``vapi.Vapi.stop``, and call/assistant
creation methods to emit OTel spans and record to the Waxell HTTP API.

Vapi is a voice AI platform for building voice agents with real-time
speech processing, tool execution, and assistant configuration.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class VapiInstrumentor(BaseInstrumentor):
    """Instrumentor for the Vapi Python SDK (``vapi_python`` package).

    Patches ``Vapi.start``, ``Vapi.stop``, and call-related methods
    for call lifecycle tracking, assistant configuration, and tool
    execution observability.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import vapi  # noqa: F401
        except ImportError:
            logger.debug("vapi package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Vapi instrumentation")
            return False

        patched = False

        # Patch Vapi.start
        try:
            wrapt.wrap_function_wrapper(
                "vapi",
                "Vapi.start",
                _vapi_start_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch vapi.Vapi.start: %s", exc)

        # Patch Vapi.stop
        try:
            wrapt.wrap_function_wrapper(
                "vapi",
                "Vapi.stop",
                _vapi_stop_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch vapi.Vapi.stop: %s", exc)

        # Patch Vapi.send (tool/function call responses)
        try:
            wrapt.wrap_function_wrapper(
                "vapi",
                "Vapi.send",
                _vapi_send_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch vapi.Vapi.send: %s", exc)

        if not patched:
            logger.debug("Could not find Vapi methods to patch")
            return False

        self._instrumented = True
        logger.debug("Vapi instrumented (start + stop + send)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from vapi import Vapi

            for attr in ("start", "stop", "send"):
                method = getattr(Vapi, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(Vapi, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Vapi uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _vapi_start_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Vapi.start`` -- initiates a Vapi voice call."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract assistant/call configuration
    assistant_id = kwargs.get("assistant_id", "") or ""
    assistant = kwargs.get("assistant", None)
    phone_number_id = kwargs.get("phone_number_id", "") or ""

    call_name = f"vapi.call:{assistant_id or 'inline'}"

    try:
        span = start_agent_span(
            agent_name=call_name,
            workflow_name="vapi_voice_call",
        )
        span.set_attribute("waxell.agent.framework", "vapi")
        span.set_attribute("waxell.vapi.operation", "start_call")
        if assistant_id:
            span.set_attribute("waxell.vapi.assistant_id", str(assistant_id))
        if phone_number_id:
            span.set_attribute("waxell.vapi.phone_number_id", str(phone_number_id))

        # Extract assistant config details if inline assistant provided
        if assistant and isinstance(assistant, dict):
            model_info = assistant.get("model", {})
            if isinstance(model_info, dict):
                model_name = model_info.get("model", "")
                if model_name:
                    span.set_attribute("waxell.vapi.model", str(model_name))
                provider = model_info.get("provider", "")
                if provider:
                    span.set_attribute("waxell.vapi.provider", str(provider))
            first_message = assistant.get("firstMessage", "")
            if first_message:
                span.set_attribute("waxell.vapi.first_message_preview", str(first_message)[:200])
            voice = assistant.get("voice", {})
            if isinstance(voice, dict):
                voice_id = voice.get("voiceId", "")
                if voice_id:
                    span.set_attribute("waxell.vapi.voice_id", str(voice_id))

        # Store start time on instance for duration calculation
        try:
            instance._waxell_call_start = time.time()
        except Exception:
            pass
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_start_result_attributes(span, result, assistant_id)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _vapi_stop_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Vapi.stop`` -- ends a Vapi voice call."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="vapi.stop_call")
        span.set_attribute("waxell.agent.framework", "vapi")
        span.set_attribute("waxell.vapi.operation", "stop_call")

        # Calculate call duration if start time was recorded
        try:
            call_start = getattr(instance, "_waxell_call_start", None)
            if call_start:
                duration = time.time() - call_start
                span.set_attribute("waxell.vapi.call_duration_seconds", round(duration, 2))
        except Exception:
            pass
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_stop_result_attributes(span, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _vapi_send_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Vapi.send`` -- sends messages/tool results back to Vapi."""
    try:
        from ..tracing.spans import start_tool_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract message type and tool info
    message = kwargs.get("message", None) or (args[0] if args else None)
    tool_name = "vapi.send"
    if isinstance(message, dict):
        msg_type = message.get("type", "")
        if msg_type:
            tool_name = f"vapi.send:{msg_type}"

    try:
        span = start_tool_span(tool_name=tool_name)
        span.set_attribute("waxell.agent.framework", "vapi")
        span.set_attribute("waxell.vapi.operation", "send")

        if isinstance(message, dict):
            msg_type = message.get("type", "")
            if msg_type:
                span.set_attribute("waxell.vapi.message_type", str(msg_type))

            # Tool call response tracking
            tool_call_id = message.get("toolCallId", "")
            if tool_call_id:
                span.set_attribute("waxell.vapi.tool_call_id", str(tool_call_id))
            function_name = message.get("name", "")
            if function_name:
                span.set_attribute("waxell.vapi.function_name", str(function_name))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _set_start_result_attributes(span, result, assistant_id: str) -> None:
    """Set result attributes after Vapi.start."""
    try:
        # Result may contain call ID or status
        call_id = getattr(result, "id", None) or (
            result.get("id", "") if isinstance(result, dict) else ""
        )
        if call_id:
            span.set_attribute("waxell.vapi.call_id", str(call_id))

        status = getattr(result, "status", None) or (
            result.get("status", "") if isinstance(result, dict) else ""
        )
        if status:
            span.set_attribute("waxell.vapi.call_status", str(status))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "agent:vapi.call",
                output={"assistant_id": assistant_id, "call_id": str(call_id) if call_id else ""},
            )
    except Exception:
        pass


def _set_stop_result_attributes(span, result) -> None:
    """Set result attributes after Vapi.stop."""
    try:
        if isinstance(result, dict):
            transcript = result.get("transcript", "")
            if transcript:
                span.set_attribute("waxell.vapi.transcript_preview", str(transcript)[:200])
            cost = result.get("cost", None)
            if cost is not None:
                span.set_attribute("waxell.vapi.cost", float(cost))
            duration = result.get("duration", None)
            if duration is not None:
                span.set_attribute("waxell.vapi.duration", float(duration))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "step:vapi.stop_call",
                output={"operation": "stop_call"},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
