"""Amazon Neptune auto-instrumentor for waxell-observe.

Monkey-patches botocore BaseClient._make_api_call to intercept Neptune
query operations and emit retrieval spans.

Intercepted Neptune operations:
  - ``ExecuteGremlinQuery``         (retrieval span for Gremlin queries)
  - ``ExecuteOpenCypherQuery``      (retrieval span for openCypher queries)
  - ``ExecuteGremlinExplainQuery``  (retrieval span for Gremlin explain queries)

Only instruments calls where the service is ``neptunedata``.

All wrapper code is wrapped in try/except -- never breaks the user's Neptune calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Neptune operations that we instrument.
_NEPTUNE_OPERATIONS = frozenset({
    "ExecuteGremlinQuery",
    "ExecuteOpenCypherQuery",
    "ExecuteGremlinExplainQuery",
})


class NeptuneInstrumentor(BaseInstrumentor):
    """Instrumentor for Amazon Neptune via boto3/botocore.

    Patches ``botocore.client.BaseClient._make_api_call`` to detect
    Neptune ``neptunedata`` service calls and emit retrieval spans for
    query operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import botocore.client  # noqa: F401
        except ImportError:
            logger.debug("botocore package not installed -- skipping Neptune instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Neptune instrumentation")
            return False

        patched_any = False

        # --- BaseClient._make_api_call ---
        try:
            wrapt.wrap_function_wrapper(
                "botocore.client",
                "BaseClient._make_api_call",
                _sync_make_api_call_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch botocore BaseClient._make_api_call: %s", exc)

        if not patched_any:
            logger.debug("Could not patch botocore for Neptune instrumentation")
            return False

        self._instrumented = True
        logger.debug("Neptune instrumented (botocore BaseClient._make_api_call)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore BaseClient._make_api_call
        try:
            from botocore.client import BaseClient

            method = getattr(BaseClient, "_make_api_call", None)
            if method is not None and hasattr(method, "__wrapped__"):
                BaseClient._make_api_call = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Neptune uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_neptune_service(instance) -> bool:
    """Check if the botocore client instance is for the neptunedata service."""
    try:
        service_model = getattr(instance, "_service_model", None)
        if service_model is not None:
            service_name = getattr(service_model, "service_name", "")
            return service_name == "neptunedata"
    except Exception:
        pass
    return False


def _extract_query_string(operation_name: str, api_params: dict) -> str:
    """Extract the query string from Neptune API parameters."""
    try:
        if operation_name in ("ExecuteGremlinQuery", "ExecuteGremlinExplainQuery"):
            return str(api_params.get("gremlinQuery", ""))
        if operation_name == "ExecuteOpenCypherQuery":
            return str(api_params.get("openCypherQuery", ""))
    except Exception:
        pass
    return ""


def _truncate_query(query: str, max_len: int = 200) -> str:
    """Truncate a query string for span labelling."""
    if len(query) > max_len:
        return query[:max_len] + "..."
    return query


def _extract_result_count(response: dict) -> int:
    """Extract result count from a Neptune response."""
    try:
        # Gremlin responses
        if "result" in response:
            result = response["result"]
            if isinstance(result, dict) and "data" in result:
                data = result["data"]
                if isinstance(data, list):
                    return len(data)
        # OpenCypher responses
        if "results" in response:
            results = response["results"]
            if isinstance(results, list):
                return len(results)
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper
# ---------------------------------------------------------------------------


def _sync_make_api_call_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for botocore BaseClient._make_api_call -- instruments Neptune queries.

    Only intercepts calls to the ``neptunedata`` service for known query
    operations.  All other API calls pass through unmodified.
    """
    # Extract operation_name from args
    operation_name = args[0] if args else kwargs.get("operation_name", "")

    # Fast path: skip non-Neptune services or non-query operations
    if operation_name not in _NEPTUNE_OPERATIONS or not _is_neptune_service(instance):
        return wrapped(*args, **kwargs)

    api_params = args[1] if len(args) > 1 else kwargs.get("api_params", {})
    query = _extract_query_string(operation_name, api_params)

    return _sync_neptune_query_path(wrapped, args, kwargs, query, operation_name)


def _sync_neptune_query_path(wrapped, args, kwargs, query, operation_name):
    """Handle Neptune query operations with a retrieval span."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)

    try:
        span = start_retrieval_span(query=query_preview, source="neptune")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("db.system", "neptune")
            span.set_attribute("db.statement", query_preview)
            span.set_attribute("waxell.retrieval.source", "neptune")
            span.set_attribute("db.neptune.operation", operation_name)
            result_count = _extract_result_count(response)
            if result_count:
                span.set_attribute("db.neptune.result_count", result_count)
        except Exception as attr_exc:
            logger.debug("Failed to set neptune span attributes: %s", attr_exc)

        try:
            _record_neptune_retrieval(query=query_preview)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_neptune_retrieval(
    query: str,
) -> None:
    """Record a Neptune retrieval operation to the context path.

    Neptune retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="neptune",
        )
