"""OpenAI Moderation auto-instrumentor for waxell-observe.

Monkey-patches ``openai.resources.moderations.Moderations.create`` (sync)
and ``openai.resources.moderations.AsyncModerations.create`` (async) to
emit guardrail spans tracking content moderation results.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class OpenAIModerationInstrumentor(BaseInstrumentor):
    """Instrumentor for OpenAI Moderation API (``openai`` package).

    Patches Moderations.create (sync) and AsyncModerations.create (async).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import openai  # noqa: F401
        except ImportError:
            logger.debug("openai not installed -- skipping moderation instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt not installed -- skipping OpenAI Moderation instrumentation"
            )
            return False

        patched = False

        # Patch sync Moderations.create
        try:
            wrapt.wrap_function_wrapper(
                "openai.resources.moderations",
                "Moderations.create",
                _sync_moderation_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Moderations.create: %s", exc)

        # Patch async AsyncModerations.create
        try:
            wrapt.wrap_function_wrapper(
                "openai.resources.moderations",
                "AsyncModerations.create",
                _async_moderation_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch AsyncModerations.create: %s", exc)

        if not patched:
            logger.debug("Could not find OpenAI Moderation methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "OpenAI Moderation instrumented "
            "(Moderations.create + AsyncModerations.create)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from openai.resources.moderations import Moderations

            if hasattr(Moderations.create, "__wrapped__"):
                Moderations.create = Moderations.create.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from openai.resources.moderations import AsyncModerations

            if hasattr(AsyncModerations.create, "__wrapped__"):
                AsyncModerations.create = AsyncModerations.create.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("OpenAI Moderation uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_moderation_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Moderations.create``."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_guardrail_span(
            guardrail_name="openai_moderation",
            framework="openai",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_moderation_result(span, result, kwargs)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _async_moderation_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncModerations.create``."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_guardrail_span(
            guardrail_name="openai_moderation",
            framework="openai",
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_moderation_result(span, result, kwargs)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_moderation_result(span, result, kwargs: dict) -> None:
    """Extract moderation results and set span attributes.

    OpenAI moderation response structure:
    - result.id: str
    - result.model: str
    - result.results: list of ModerationResult
      - results[i].flagged: bool
      - results[i].categories: dict[str, bool]
      - results[i].category_scores: dict[str, float]
    """
    from ..tracing.attributes import WaxellAttributes

    flagged = False
    flagged_categories: list[str] = []
    max_score = 0.0
    model = ""

    # Extract model used
    try:
        model = getattr(result, "model", "") or ""
    except Exception:
        pass

    # Also check kwargs for model
    if not model:
        try:
            model = kwargs.get("model", "")
        except Exception:
            pass

    # Process results
    try:
        results_list = getattr(result, "results", [])
        if results_list:
            # Check all results (usually just one)
            for mod_result in results_list:
                try:
                    if getattr(mod_result, "flagged", False):
                        flagged = True
                except Exception:
                    pass

                # Extract flagged categories
                try:
                    categories = getattr(mod_result, "categories", None)
                    if categories is not None:
                        # categories can be a dict or an object with attributes
                        if isinstance(categories, dict):
                            cat_dict = categories
                        else:
                            # Object with bool attributes -- convert to dict
                            cat_dict = {}
                            try:
                                cat_dict = dict(categories)
                            except Exception:
                                try:
                                    cat_dict = vars(categories)
                                except Exception:
                                    pass
                        for cat_name, cat_val in cat_dict.items():
                            try:
                                if cat_val:
                                    flagged_categories.append(str(cat_name))
                            except Exception:
                                pass
                except Exception:
                    pass

                # Extract max category score
                try:
                    category_scores = getattr(mod_result, "category_scores", None)
                    if category_scores is not None:
                        if isinstance(category_scores, dict):
                            scores_dict = category_scores
                        else:
                            scores_dict = {}
                            try:
                                scores_dict = dict(category_scores)
                            except Exception:
                                try:
                                    scores_dict = vars(category_scores)
                                except Exception:
                                    pass
                        for score_val in scores_dict.values():
                            try:
                                fval = float(score_val)
                                if fval > max_score:
                                    max_score = fval
                            except (TypeError, ValueError):
                                pass
                except Exception:
                    pass
    except Exception:
        pass

    # Determine guardrail action
    passed = not flagged
    action = "pass" if passed else "flag"

    # Set span attributes
    try:
        span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, passed)
        span.set_attribute(WaxellAttributes.GUARDRAIL_ACTION, action)
        span.set_attribute("waxell.moderation.flagged", flagged)
        if flagged_categories:
            span.set_attribute(
                "waxell.moderation.categories", ",".join(flagged_categories)
            )
        if model:
            span.set_attribute("waxell.moderation.model", model)
        span.set_attribute("waxell.moderation.max_score", max_score)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_moderation(
            flagged, flagged_categories, max_score, model, passed, action
        )
    except Exception:
        pass


def _record_http_moderation(
    flagged: bool,
    flagged_categories: list[str],
    max_score: float,
    model: str,
    passed: bool,
    action: str,
) -> None:
    """Record an OpenAI moderation check to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "guardrail:openai_moderation",
            output={
                "passed": passed,
                "action": action,
                "flagged": flagged,
                "flagged_categories": flagged_categories,
                "max_score": max_score,
                "model": model,
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
