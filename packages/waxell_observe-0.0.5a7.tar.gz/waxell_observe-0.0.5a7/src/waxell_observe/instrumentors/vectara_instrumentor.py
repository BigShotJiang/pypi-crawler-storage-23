"""Vectara RAG-as-a-Service auto-instrumentor for waxell-observe.

Monkey-patches Vectara SDK client methods for querying, uploading, and
chat operations to emit retrieval and step spans.

Patched methods:
  - ``vectara.Vectara.query``       (retrieval span)
  - ``vectara.Vectara.upload``      (step span)
  - ``vectara.Vectara.chat``        (retrieval span)
  - ``vectara.Vectara.search``      (retrieval span)

All wrapper code is wrapped in try/except -- never breaks the user's Vectara calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class VectaraInstrumentor(BaseInstrumentor):
    """Instrumentor for Vectara RAG-as-a-Service.

    Patches ``Vectara.query``, ``Vectara.search``, ``Vectara.chat`` for
    retrieval spans, and ``Vectara.upload`` for step spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import vectara  # noqa: F401
        except ImportError:
            logger.debug("vectara package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Vectara instrumentation")
            return False

        patched_any = False

        # --- Vectara.query (retrieval span) ---
        try:
            wrapt.wrap_function_wrapper(
                "vectara",
                "Vectara.query",
                _sync_query_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch Vectara.query: %s", exc)

        # --- Vectara.search (retrieval span) ---
        try:
            wrapt.wrap_function_wrapper(
                "vectara",
                "Vectara.search",
                _sync_search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch Vectara.search: %s", exc)

        # --- Vectara.chat (retrieval span) ---
        try:
            wrapt.wrap_function_wrapper(
                "vectara",
                "Vectara.chat",
                _sync_chat_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch Vectara.chat: %s", exc)

        # --- Vectara.upload (step span for document upload) ---
        try:
            wrapt.wrap_function_wrapper(
                "vectara",
                "Vectara.upload",
                _sync_upload_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch Vectara.upload: %s", exc)

        # --- Vectara.upload_file (step span, alternative upload method) ---
        try:
            wrapt.wrap_function_wrapper(
                "vectara",
                "Vectara.upload_file",
                _sync_upload_file_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch Vectara.upload_file: %s", exc)

        # --- Try async variants if available ---
        try:
            wrapt.wrap_function_wrapper(
                "vectara",
                "Vectara.aquery",
                _async_query_wrapper,
            )
        except Exception:
            pass

        try:
            wrapt.wrap_function_wrapper(
                "vectara",
                "Vectara.achat",
                _async_chat_wrapper,
            )
        except Exception:
            pass

        if not patched_any:
            logger.debug("Could not patch any Vectara methods")
            return False

        self._instrumented = True
        logger.debug("Vectara instrumented (query, search, chat, upload)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import vectara

            vectara_cls = getattr(vectara, "Vectara", None)
            if vectara_cls is not None:
                for method_name in ("query", "search", "chat", "upload", "upload_file", "aquery", "achat"):
                    method = getattr(vectara_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(vectara_cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Vectara uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the query string from call args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _extract_corpus_key(args, kwargs) -> str:
    """Extract the corpus key from call args."""
    try:
        corpus_key = kwargs.get("corpus_key", kwargs.get("corpus_id", ""))
        if corpus_key:
            return str(corpus_key)
        # Check positional args (some methods take corpus_key as second arg)
        if len(args) > 1:
            return str(args[1])
    except Exception:
        pass
    return ""


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate a string for span labelling."""
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


def _extract_result_metadata(result) -> dict:
    """Extract metadata from a Vectara query/search result."""
    metadata = {}
    try:
        if result is None:
            return metadata

        # Result count
        if hasattr(result, "search_results") and isinstance(result.search_results, (list, tuple)):
            metadata["results_count"] = len(result.search_results)
        elif hasattr(result, "results") and isinstance(result.results, (list, tuple)):
            metadata["results_count"] = len(result.results)
        elif isinstance(result, (list, tuple)):
            metadata["results_count"] = len(result)

        # Score from first result
        search_results = getattr(result, "search_results", None) or getattr(result, "results", None)
        if search_results and isinstance(search_results, (list, tuple)) and len(search_results) > 0:
            first_result = search_results[0]
            if hasattr(first_result, "score"):
                metadata["top_score"] = float(first_result.score)

        # Summary/answer
        if hasattr(result, "summary"):
            summary = str(result.summary)
            metadata["summary_preview"] = _truncate(summary, max_len=200)
        elif hasattr(result, "answer"):
            answer = str(result.answer)
            metadata["summary_preview"] = _truncate(answer, max_len=200)

    except Exception:
        pass
    return metadata


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Vectara.query -- emits retrieval span."""
    query = _extract_query(args, kwargs)
    corpus_key = _extract_corpus_key(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="vectara")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_meta = _extract_result_metadata(result)
            span.set_attribute("waxell.retrieval.operation", "query")
            if corpus_key:
                span.set_attribute("waxell.retrieval.corpus_key", corpus_key)
            if "results_count" in result_meta:
                span.set_attribute("waxell.retrieval.results_count", result_meta["results_count"])
            if "top_score" in result_meta:
                span.set_attribute("waxell.retrieval.top_score", result_meta["top_score"])
            if "summary_preview" in result_meta:
                span.set_attribute("waxell.retrieval.summary_preview", result_meta["summary_preview"])
        except Exception as attr_exc:
            logger.debug("Failed to set Vectara query span attributes: %s", attr_exc)

        try:
            _record_vectara_retrieval(
                query=query_preview,
                operation="query",
                corpus_key=corpus_key,
                results_count=result_meta.get("results_count", 0),
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Vectara.search -- emits retrieval span."""
    query = _extract_query(args, kwargs)
    corpus_key = _extract_corpus_key(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="vectara")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_meta = _extract_result_metadata(result)
            span.set_attribute("waxell.retrieval.operation", "search")
            if corpus_key:
                span.set_attribute("waxell.retrieval.corpus_key", corpus_key)
            if "results_count" in result_meta:
                span.set_attribute("waxell.retrieval.results_count", result_meta["results_count"])
            if "top_score" in result_meta:
                span.set_attribute("waxell.retrieval.top_score", result_meta["top_score"])
        except Exception as attr_exc:
            logger.debug("Failed to set Vectara search span attributes: %s", attr_exc)

        try:
            _record_vectara_retrieval(
                query=query_preview,
                operation="search",
                corpus_key=corpus_key,
                results_count=result_meta.get("results_count", 0),
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Vectara.chat -- emits retrieval span."""
    query = _extract_query(args, kwargs)
    corpus_key = _extract_corpus_key(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="vectara")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_meta = _extract_result_metadata(result)
            span.set_attribute("waxell.retrieval.operation", "chat")
            if corpus_key:
                span.set_attribute("waxell.retrieval.corpus_key", corpus_key)
            if "results_count" in result_meta:
                span.set_attribute("waxell.retrieval.results_count", result_meta["results_count"])
            if "summary_preview" in result_meta:
                span.set_attribute("waxell.retrieval.summary_preview", result_meta["summary_preview"])
        except Exception as attr_exc:
            logger.debug("Failed to set Vectara chat span attributes: %s", attr_exc)

        try:
            _record_vectara_retrieval(
                query=query_preview,
                operation="chat",
                corpus_key=corpus_key,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_upload_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Vectara.upload -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    corpus_key = _extract_corpus_key(args, kwargs)

    try:
        span = start_step_span(step_name="vectara.upload")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectara.operation", "upload")
            if corpus_key:
                span.set_attribute("waxell.vectara.corpus_key", corpus_key)
        except Exception as attr_exc:
            logger.debug("Failed to set Vectara upload span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "vectara_upload",
                    output={"corpus_key": corpus_key},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_upload_file_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Vectara.upload_file -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    corpus_key = _extract_corpus_key(args, kwargs)
    file_path = ""
    try:
        if args:
            file_path = str(args[0]) if args[0] else ""
        else:
            file_path = str(kwargs.get("file_path", kwargs.get("file", "")))
    except Exception:
        pass

    try:
        span = start_step_span(step_name="vectara.upload_file")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectara.operation", "upload_file")
            if corpus_key:
                span.set_attribute("waxell.vectara.corpus_key", corpus_key)
            if file_path:
                span.set_attribute("waxell.vectara.file_path", _truncate(file_path, max_len=200))
        except Exception as attr_exc:
            logger.debug("Failed to set Vectara upload_file span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "vectara_upload_file",
                    output={"corpus_key": corpus_key, "file_path": file_path},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrappers
# ---------------------------------------------------------------------------


async def _async_query_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Vectara.aquery -- emits retrieval span."""
    query = _extract_query(args, kwargs)
    corpus_key = _extract_corpus_key(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="vectara")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_meta = _extract_result_metadata(result)
            span.set_attribute("waxell.retrieval.operation", "query")
            if corpus_key:
                span.set_attribute("waxell.retrieval.corpus_key", corpus_key)
            if "results_count" in result_meta:
                span.set_attribute("waxell.retrieval.results_count", result_meta["results_count"])
            if "top_score" in result_meta:
                span.set_attribute("waxell.retrieval.top_score", result_meta["top_score"])
            if "summary_preview" in result_meta:
                span.set_attribute("waxell.retrieval.summary_preview", result_meta["summary_preview"])
        except Exception as attr_exc:
            logger.debug("Failed to set Vectara async query span attributes: %s", attr_exc)

        try:
            _record_vectara_retrieval(
                query=query_preview,
                operation="query",
                corpus_key=corpus_key,
                results_count=result_meta.get("results_count", 0),
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Vectara.achat -- emits retrieval span."""
    query = _extract_query(args, kwargs)
    corpus_key = _extract_corpus_key(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="vectara")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_meta = _extract_result_metadata(result)
            span.set_attribute("waxell.retrieval.operation", "chat")
            if corpus_key:
                span.set_attribute("waxell.retrieval.corpus_key", corpus_key)
            if "results_count" in result_meta:
                span.set_attribute("waxell.retrieval.results_count", result_meta["results_count"])
            if "summary_preview" in result_meta:
                span.set_attribute("waxell.retrieval.summary_preview", result_meta["summary_preview"])
        except Exception as attr_exc:
            logger.debug("Failed to set Vectara async chat span attributes: %s", attr_exc)

        try:
            _record_vectara_retrieval(
                query=query_preview,
                operation="chat",
                corpus_key=corpus_key,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_vectara_retrieval(
    query: str,
    operation: str = "query",
    corpus_key: str = "",
    results_count: int = 0,
) -> None:
    """Record a Vectara retrieval operation to the context path.

    Vectara retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="vectara",
            results_count=results_count,
        )
