"""LocalAI auto-instrumentor for waxell-observe.

Monkey-patches the OpenAI Python client when used with a LocalAI backend.
LocalAI exposes an OpenAI-compatible API, so the ``openai`` SDK is used
with a custom ``base_url`` pointing to the LocalAI server.

Detection heuristic: the client's ``base_url`` contains common LocalAI
indicators (port 8080, "localai" in the URL).

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Common indicators that an OpenAI client is pointing at LocalAI
_LOCALAI_INDICATORS = ("localai", ":8080",)


class LocalAIInstrumentor(BaseInstrumentor):
    """Instrumentor for LocalAI via the OpenAI-compatible API.

    Patches ``openai.resources.chat.completions.Completions.create`` and
    ``openai.resources.embeddings.Embeddings.create`` when the client's
    base_url matches LocalAI patterns.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import openai  # noqa: F401
        except ImportError:
            logger.debug("openai package not installed -- skipping LocalAI instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping LocalAI instrumentation")
            return False

        patched = False

        # Patch sync chat completions
        try:
            wrapt.wrap_function_wrapper(
                "openai.resources.chat.completions",
                "Completions.create",
                _chat_completions_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch openai chat completions for LocalAI: %s", exc)

        # Patch async chat completions
        try:
            wrapt.wrap_function_wrapper(
                "openai.resources.chat.completions",
                "AsyncCompletions.create",
                _async_chat_completions_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch openai async chat completions for LocalAI: %s", exc)

        # Patch sync embeddings
        try:
            wrapt.wrap_function_wrapper(
                "openai.resources.embeddings",
                "Embeddings.create",
                _embeddings_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch openai embeddings for LocalAI: %s", exc)

        # Patch async embeddings
        try:
            wrapt.wrap_function_wrapper(
                "openai.resources.embeddings",
                "AsyncEmbeddings.create",
                _async_embeddings_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch openai async embeddings for LocalAI: %s", exc)

        if not patched:
            logger.debug("Could not find any OpenAI methods to patch for LocalAI")
            return False

        self._instrumented = True
        logger.debug("LocalAI instrumented (chat completions + embeddings via OpenAI client)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import openai.resources.chat.completions as chat_mod

            for attr in ("create",):
                for cls_name in ("Completions", "AsyncCompletions"):
                    cls = getattr(chat_mod, cls_name, None)
                    if cls is None:
                        continue
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        try:
            import openai.resources.embeddings as emb_mod

            for cls_name in ("Embeddings", "AsyncEmbeddings"):
                cls = getattr(emb_mod, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "create", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "create", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("LocalAI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Detection helpers
# ---------------------------------------------------------------------------


def _is_localai_client(instance) -> bool:
    """Check if the OpenAI client instance is pointed at a LocalAI server."""
    try:
        # Navigate from the resource to the client
        client = getattr(instance, "_client", None)
        if client is None:
            return False

        base_url = getattr(client, "base_url", None)
        if base_url is None:
            return False

        url_str = str(base_url).lower()
        return any(indicator in url_str for indicator in _LOCALAI_INDICATORS)
    except Exception:
        return False


def _extract_base_url(instance) -> str:
    """Extract the base_url from the client for logging."""
    try:
        client = getattr(instance, "_client", None)
        if client:
            return str(getattr(client, "base_url", ""))
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# Chat completions wrappers
# ---------------------------------------------------------------------------


def _chat_completions_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for chat completions.create -- only activates for LocalAI."""
    if not _is_localai_client(instance):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "localai-model")
    messages = kwargs.get("messages", [])
    temperature = kwargs.get("temperature")

    try:
        span = start_llm_span(model=model, provider_name="localai")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(result, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) or 0 if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) or 0 if usage else 0

            response_text = ""
            choices = getattr(result, "choices", [])
            if choices:
                message = getattr(choices[0], "message", None)
                if message:
                    response_text = str(getattr(message, "content", ""))[:500]

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)  # Local inference
            span.set_attribute("waxell.localai.base_url", _extract_base_url(instance))

            if temperature is not None:
                span.set_attribute(GenAIAttributes.REQUEST_TEMPERATURE, temperature)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_localai(result, model, messages, "chat.completions")
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_chat_completions_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for chat completions.create -- only activates for LocalAI."""
    if not _is_localai_client(instance):
        return await wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "localai-model")
    messages = kwargs.get("messages", [])
    temperature = kwargs.get("temperature")

    try:
        span = start_llm_span(model=model, provider_name="localai")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(result, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) or 0 if usage else 0
            tokens_out = getattr(usage, "completion_tokens", 0) or 0 if usage else 0

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
            span.set_attribute("waxell.localai.base_url", _extract_base_url(instance))

            if temperature is not None:
                span.set_attribute(GenAIAttributes.REQUEST_TEMPERATURE, temperature)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_localai(result, model, messages, "chat.completions")
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Embeddings wrappers
# ---------------------------------------------------------------------------


def _embeddings_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for embeddings.create -- only activates for LocalAI."""
    if not _is_localai_client(instance):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "localai-embedding")

    try:
        span = start_llm_span(model=model, provider_name="localai")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(result, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) or 0 if usage else 0

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
            span.set_attribute("waxell.localai.base_url", _extract_base_url(instance))
            span.set_attribute("waxell.localai.task", "embeddings")
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        return result
    finally:
        span.end()


async def _async_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for embeddings.create -- only activates for LocalAI."""
    if not _is_localai_client(instance):
        return await wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "localai-embedding")

    try:
        span = start_llm_span(model=model, provider_name="localai")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            usage = getattr(result, "usage", None)
            tokens_in = getattr(usage, "prompt_tokens", 0) or 0 if usage else 0

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
            span.set_attribute("waxell.localai.base_url", _extract_base_url(instance))
            span.set_attribute("waxell.localai.task", "embeddings")
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_localai(result, model: str, messages: list, task: str) -> None:
    """Record a LocalAI call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    usage = getattr(result, "usage", None)
    tokens_in = getattr(usage, "prompt_tokens", 0) or 0 if usage else 0
    tokens_out = getattr(usage, "completion_tokens", 0) or 0 if usage else 0

    # Extract prompt preview
    prompt_preview = ""
    if isinstance(messages, list) and messages:
        first = messages[0]
        if isinstance(first, dict):
            prompt_preview = str(first.get("content", ""))[:500]

    # Extract response preview
    response_preview = ""
    try:
        choices = getattr(result, "choices", [])
        if choices:
            message = getattr(choices[0], "message", None)
            if message:
                response_preview = str(getattr(message, "content", ""))[:500]
    except Exception:
        pass

    call_data = {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,
        "task": f"localai.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
