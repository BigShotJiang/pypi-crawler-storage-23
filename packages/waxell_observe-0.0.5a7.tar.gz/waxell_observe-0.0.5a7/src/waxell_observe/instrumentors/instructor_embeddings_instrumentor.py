"""Instructor Embeddings auto-instrumentor for waxell-observe.

Monkey-patches ``INSTRUCTOR.encode`` to emit embedding spans tracking
Instructor Embedding generation.

The ``InstructorEmbedding`` package provides instruction-aware text
embeddings. Unlike standard sentence-transformers, INSTRUCTOR models
accept (instruction, text) pairs as input. Since these run locally,
cost is always 0.0.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class InstructorEmbeddingsInstrumentor(BaseInstrumentor):
    """Instrumentor for the InstructorEmbedding library (``InstructorEmbedding`` package).

    Patches ``INSTRUCTOR.encode`` to emit embedding spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import InstructorEmbedding  # noqa: F401
        except ImportError:
            logger.debug("InstructorEmbedding package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Instructor Embeddings instrumentation")
            return False

        patched = False

        # Patch INSTRUCTOR.encode
        try:
            wrapt.wrap_function_wrapper(
                "InstructorEmbedding",
                "INSTRUCTOR.encode",
                _sync_encode_wrapper,
            )
            patched = True
            logger.debug("INSTRUCTOR.encode patched")
        except Exception as exc:
            logger.debug("Failed to patch INSTRUCTOR.encode: %s", exc)

        if not patched:
            logger.debug("Could not find INSTRUCTOR.encode method to patch")
            return False

        self._instrumented = True
        logger.debug("Instructor Embeddings instrumented (INSTRUCTOR.encode)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from InstructorEmbedding import INSTRUCTOR

            method = getattr(INSTRUCTOR, "encode", None)
            if method is not None and hasattr(method, "__wrapped__"):
                INSTRUCTOR.encode = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Instructor Embeddings uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from an INSTRUCTOR instance.

    INSTRUCTOR inherits from SentenceTransformer, so we try the
    same attribute paths.
    """
    try:
        card = getattr(instance, "model_card_data", None)
        if card is not None:
            name = getattr(card, "model_name", None) or getattr(card, "base_model", None)
            if name:
                return str(name)
    except Exception:
        pass

    try:
        name = getattr(instance, "_model_name", None)
        if name:
            return str(name)
    except Exception:
        pass

    try:
        first_module = instance[0]
        auto_model = getattr(first_module, "auto_model", None)
        if auto_model is not None:
            config = getattr(auto_model, "config", None)
            if config is not None:
                name = getattr(config, "name_or_path", None) or getattr(config, "_name_or_path", None)
                if name:
                    return str(name)
    except Exception:
        pass

    return "instructor-embedding"


def _extract_instruction(sentences) -> str:
    """Extract the instruction text from INSTRUCTOR-style input.

    INSTRUCTOR.encode() accepts inputs as a list of [instruction, text] pairs,
    e.g. [["Represent the query for retrieval:", "What is AI?"], ...].
    """
    if not isinstance(sentences, list) or len(sentences) == 0:
        return ""

    first = sentences[0]
    if isinstance(first, (list, tuple)) and len(first) >= 1:
        return str(first[0])[:200]

    return ""


def _count_inputs(sentences) -> int:
    """Count the number of input texts."""
    if isinstance(sentences, str):
        return 1
    if isinstance(sentences, list):
        return len(sentences)
    return 1


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_encode_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``INSTRUCTOR.encode``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model_name = _get_model_name(instance)

    # Extract sentences from args or kwargs
    sentences = args[0] if args else kwargs.get("sentences", [])
    input_count = _count_inputs(sentences)
    instruction = _extract_instruction(sentences)

    try:
        span = start_embedding_span(
            model=model_name,
            provider_name="instructor_embedding",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            import numpy as np

            if isinstance(result, np.ndarray):
                dimensions = result.shape[-1] if result.ndim > 1 else result.shape[0]
            elif isinstance(result, list):
                dimensions = len(result[0]) if result else 0
            else:
                dimensions = 0

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model_name)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)  # Local, free
            if instruction:
                span.set_attribute("waxell.embedding.instruction", instruction)
        except Exception as attr_exc:
            logger.debug("Failed to set Instructor embed span attributes: %s", attr_exc)

        try:
            _record_http_instructor_embed(model_name, input_count, instruction, dimensions)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_instructor_embed(
    model: str, input_count: int, instruction: str = "", dimensions: int = 0
) -> None:
    """Record an Instructor Embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    instr_preview = f", instruction='{instruction[:80]}'" if instruction else ""
    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "embedding:instructor",
        "prompt_preview": f"encode {input_count} text(s), dim={dimensions}{instr_preview}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
