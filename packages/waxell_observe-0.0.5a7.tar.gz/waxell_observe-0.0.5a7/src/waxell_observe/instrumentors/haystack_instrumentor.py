"""Haystack auto-instrumentor for waxell-observe.

Monkey-patches ``haystack.Pipeline.run`` (sync) and ``Pipeline.run_async``
(async, if available), as well as individual ``Component.run`` calls, to
emit OTel spans and record to the Waxell HTTP API.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class HaystackInstrumentor(BaseInstrumentor):
    """Instrumentor for the Haystack framework (``haystack-ai`` package).

    Patches Pipeline.run, Pipeline.run_async, and Component.run.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import haystack  # noqa: F401
        except ImportError:
            logger.debug("haystack not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Haystack instrumentation")
            return False

        patched = False

        # Patch Pipeline.run (sync entry point)
        try:
            wrapt.wrap_function_wrapper(
                "haystack.pipeline",
                "Pipeline.run",
                _pipeline_run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Pipeline.run: %s", exc)

        # Patch Pipeline.run_async (async entry point, may not exist)
        try:
            wrapt.wrap_function_wrapper(
                "haystack.pipeline",
                "Pipeline.run_async",
                _pipeline_run_async_wrapper,
            )
        except Exception:
            pass

        # Patch Component.run for individual component spans
        try:
            wrapt.wrap_function_wrapper(
                "haystack.core.component",
                "Component.run",
                _component_run_wrapper,
            )
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find Haystack Pipeline methods to patch")
            return False

        self._instrumented = True
        logger.debug("Haystack instrumented (Pipeline.run + Component.run)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import haystack.pipeline as pipeline_mod

            if hasattr(pipeline_mod.Pipeline.run, "__wrapped__"):
                pipeline_mod.Pipeline.run = pipeline_mod.Pipeline.run.__wrapped__
            if hasattr(getattr(pipeline_mod.Pipeline, "run_async", None), "__wrapped__"):
                pipeline_mod.Pipeline.run_async = pipeline_mod.Pipeline.run_async.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import haystack.core.component as comp_mod

            if hasattr(comp_mod.Component.run, "__wrapped__"):
                comp_mod.Component.run = comp_mod.Component.run.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Haystack uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _pipeline_run_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Pipeline.run``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    pipeline_name = getattr(instance, "name", None) or "haystack.pipeline"

    # Count components in the pipeline
    component_count = 0
    try:
        graph = getattr(instance, "graph", None)
        if graph:
            component_count = len(graph.nodes)
    except Exception:
        pass

    # Extract input keys
    input_keys = []
    try:
        data = kwargs.get("data", args[0] if args else {})
        if isinstance(data, dict):
            input_keys = list(data.keys())[:20]
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=pipeline_name,
            workflow_name="haystack_pipeline_run",
        )
        span.set_attribute("waxell.haystack.component_count", component_count)
        if input_keys:
            span.set_attribute("waxell.haystack.input_keys", input_keys)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_pipeline_result(result, pipeline_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _pipeline_run_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Pipeline.run_async``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    pipeline_name = getattr(instance, "name", None) or "haystack.pipeline"

    try:
        span = start_agent_span(
            agent_name=pipeline_name,
            workflow_name="haystack_pipeline_run_async",
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_pipeline_result(result, pipeline_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _component_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Component.run`` -- individual component execution."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    component_name = type(instance).__name__

    try:
        span = start_step_span(step_name=component_name)
        span.set_attribute("waxell.haystack.component_type", component_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    f"component:{component_name}",
                    output={"result_preview": str(result)[:200]},
                )
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_pipeline_result(result, pipeline_name: str) -> None:
    """Record pipeline execution result to context."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        output_keys = []
        try:
            if isinstance(result, dict):
                output_keys = list(result.keys())[:20]
        except Exception:
            pass
        ctx.record_step(
            "pipeline_complete",
            output={
                "pipeline": pipeline_name,
                "output_keys": output_keys,
                "result_preview": str(result)[:500],
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
