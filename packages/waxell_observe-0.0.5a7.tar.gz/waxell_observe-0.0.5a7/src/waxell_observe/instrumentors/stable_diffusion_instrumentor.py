"""Stable Diffusion (diffusers) auto-instrumentor for waxell-observe.

Monkey-patches ``StableDiffusionPipeline.__call__``,
``StableDiffusionXLPipeline.__call__``, and ``FluxPipeline.__call__``
from the HuggingFace ``diffusers`` library to emit OTel spans and record
to the Waxell HTTP API.

The diffusers library returns ``StableDiffusionPipelineOutput`` or
``ImagePipelineOutput`` objects with an ``images`` attribute containing
a list of PIL images.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class StableDiffusionInstrumentor(BaseInstrumentor):
    """Instrumentor for Stable Diffusion via HuggingFace diffusers.

    Patches ``StableDiffusionPipeline.__call__``,
    ``StableDiffusionXLPipeline.__call__``, and
    ``FluxPipeline.__call__`` for image generation observability.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import diffusers  # noqa: F401
        except ImportError:
            logger.debug("diffusers package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Stable Diffusion instrumentation")
            return False

        patched = False

        # Patch StableDiffusionPipeline.__call__
        try:
            wrapt.wrap_function_wrapper(
                "diffusers",
                "StableDiffusionPipeline.__call__",
                _sd_pipeline_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch StableDiffusionPipeline.__call__: %s", exc)

        # Patch StableDiffusionXLPipeline.__call__
        try:
            wrapt.wrap_function_wrapper(
                "diffusers",
                "StableDiffusionXLPipeline.__call__",
                _sdxl_pipeline_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch StableDiffusionXLPipeline.__call__: %s", exc)

        # Patch FluxPipeline.__call__
        try:
            wrapt.wrap_function_wrapper(
                "diffusers",
                "FluxPipeline.__call__",
                _flux_pipeline_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch FluxPipeline.__call__: %s", exc)

        if not patched:
            logger.debug("Could not find diffusers pipeline methods to patch")
            return False

        self._instrumented = True
        logger.debug("Stable Diffusion (diffusers) instrumented (SD + SDXL + Flux pipelines)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore StableDiffusionPipeline.__call__
        try:
            from diffusers import StableDiffusionPipeline

            if hasattr(getattr(StableDiffusionPipeline, "__call__", None), "__wrapped__"):
                StableDiffusionPipeline.__call__ = StableDiffusionPipeline.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore StableDiffusionXLPipeline.__call__
        try:
            from diffusers import StableDiffusionXLPipeline

            if hasattr(getattr(StableDiffusionXLPipeline, "__call__", None), "__wrapped__"):
                StableDiffusionXLPipeline.__call__ = StableDiffusionXLPipeline.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore FluxPipeline.__call__
        try:
            from diffusers import FluxPipeline

            if hasattr(getattr(FluxPipeline, "__call__", None), "__wrapped__"):
                FluxPipeline.__call__ = FluxPipeline.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Stable Diffusion (diffusers) uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sd_pipeline_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``StableDiffusionPipeline.__call__`` -- SD 1.x/2.x generation."""
    return _diffusers_generate_wrapper(
        wrapped, instance, args, kwargs,
        pipeline_type="stable_diffusion",
        span_name="diffusers.generate",
    )


def _sdxl_pipeline_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``StableDiffusionXLPipeline.__call__`` -- SDXL generation."""
    return _diffusers_generate_wrapper(
        wrapped, instance, args, kwargs,
        pipeline_type="stable_diffusion_xl",
        span_name="diffusers.generate",
    )


def _flux_pipeline_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``FluxPipeline.__call__`` -- Flux generation via diffusers."""
    return _diffusers_generate_wrapper(
        wrapped, instance, args, kwargs,
        pipeline_type="flux",
        span_name="diffusers.generate",
    )


def _diffusers_generate_wrapper(
    wrapped, instance, args, kwargs,
    pipeline_type: str,
    span_name: str,
):
    """Shared wrapper logic for all diffusers pipeline __call__ methods."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract generation parameters
    prompt = kwargs.get("prompt", "") or (args[0] if args else "")
    negative_prompt = kwargs.get("negative_prompt", "") or ""
    num_inference_steps = kwargs.get("num_inference_steps", None)
    guidance_scale = kwargs.get("guidance_scale", None)
    width = kwargs.get("width", None)
    height = kwargs.get("height", None)
    num_images = kwargs.get("num_images_per_prompt", 1) or 1
    seed = _extract_seed(kwargs)
    model_id = _extract_model_id(instance)

    try:
        span = start_step_span(step_name=span_name)
        span.set_attribute("waxell.agent.framework", "diffusers")
        span.set_attribute("waxell.diffusers.operation", "generate")
        span.set_attribute("waxell.diffusers.pipeline_type", pipeline_type)

        if model_id:
            span.set_attribute("waxell.diffusers.model_id", str(model_id))
        if prompt:
            prompt_str = str(prompt) if not isinstance(prompt, list) else str(prompt[0])
            span.set_attribute("waxell.diffusers.prompt_preview", prompt_str[:200])
        if negative_prompt:
            neg_str = str(negative_prompt) if not isinstance(negative_prompt, list) else str(negative_prompt[0])
            span.set_attribute("waxell.diffusers.negative_prompt_preview", neg_str[:200])
        if num_inference_steps is not None:
            span.set_attribute("waxell.diffusers.num_inference_steps", int(num_inference_steps))
        if guidance_scale is not None:
            span.set_attribute("waxell.diffusers.guidance_scale", float(guidance_scale))
        if width is not None:
            span.set_attribute("waxell.diffusers.width", int(width))
        if height is not None:
            span.set_attribute("waxell.diffusers.height", int(height))
        span.set_attribute("waxell.diffusers.num_images", int(num_images))
        if seed is not None:
            span.set_attribute("waxell.diffusers.seed", int(seed))
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            generation_time = time.time() - start_time
            span.set_attribute("waxell.diffusers.generation_time_seconds", round(generation_time, 2))
            _set_generation_result_attributes(span, result, model_id, pipeline_type)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_model_id(instance) -> str:
    """Extract the model ID from a diffusers pipeline instance."""
    try:
        # Pipeline instances often have a name_or_path from the config
        config = getattr(instance, "config", None)
        if config and isinstance(config, dict):
            model_id = config.get("_name_or_path", "")
            if model_id:
                return str(model_id)

        # Try the model name from the pipeline name_or_path directly
        name_or_path = getattr(instance, "name_or_path", None)
        if name_or_path:
            return str(name_or_path)

        # Fallback: use class name
        return type(instance).__name__
    except Exception:
        return "unknown"


def _extract_seed(kwargs) -> int | None:
    """Extract the random seed from generator kwargs."""
    try:
        generator = kwargs.get("generator", None)
        if generator is not None:
            # PyTorch generator has initial_seed()
            seed = getattr(generator, "initial_seed", None)
            if callable(seed):
                return int(seed())
    except Exception:
        pass
    return None


def _set_generation_result_attributes(span, result, model_id: str, pipeline_type: str) -> None:
    """Set result attributes for image generation."""
    num_images = 0
    try:
        images = getattr(result, "images", None)
        if images is not None:
            if isinstance(images, list):
                num_images = len(images)
            else:
                num_images = 1
            span.set_attribute("waxell.diffusers.output_images", num_images)

        # Check for NSFW detection
        nsfw_detected = getattr(result, "nsfw_content_detected", None)
        if nsfw_detected is not None and isinstance(nsfw_detected, list):
            nsfw_count = sum(1 for x in nsfw_detected if x)
            span.set_attribute("waxell.diffusers.nsfw_detected_count", nsfw_count)
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                "step:diffusers.generate",
                output={
                    "model_id": model_id,
                    "pipeline_type": pipeline_type,
                    "num_images": num_images,
                },
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
