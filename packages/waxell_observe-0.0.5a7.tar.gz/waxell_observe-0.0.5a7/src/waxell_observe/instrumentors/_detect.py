"""Detect which LLM libraries are installed in the current environment.

Pure ``try/except ImportError`` probing -- no external dependencies.
"""

from __future__ import annotations


def detect_installed_libraries() -> dict[str, bool]:
    """Return a dict mapping library name to whether it is importable.

    Checked libraries:
      - ``openai``          -- the OpenAI Python SDK
      - ``anthropic``       -- the Anthropic Python SDK
      - ``langchain``       -- LangChain (checks for ``langchain_core``)
      - ``litellm``         -- LiteLLM unified LLM gateway
      - ``groq``            -- Groq Python SDK
      - ``huggingface``     -- HuggingFace Hub (``huggingface_hub``)
    """
    results: dict[str, bool] = {}

    # OpenAI
    try:
        import openai  # noqa: F401

        results["openai"] = True
    except Exception:
        results["openai"] = False

    # Anthropic
    try:
        import anthropic  # noqa: F401

        results["anthropic"] = True
    except Exception:
        results["anthropic"] = False

    # LangChain (check for langchain_core which provides the callback interface)
    try:
        from langchain_core.callbacks import BaseCallbackHandler  # noqa: F401

        results["langchain"] = True
    except Exception:
        results["langchain"] = False

    # LiteLLM
    try:
        import litellm  # noqa: F401

        results["litellm"] = True
    except Exception:
        results["litellm"] = False

    # Groq
    try:
        import groq  # noqa: F401

        results["groq"] = True
    except Exception:
        results["groq"] = False

    # HuggingFace Hub
    try:
        import huggingface_hub  # noqa: F401

        results["huggingface"] = True
    except Exception:
        results["huggingface"] = False

    # Mistral AI
    try:
        import mistralai  # noqa: F401

        results["mistral"] = True
    except Exception:
        results["mistral"] = False

    # Cohere
    try:
        import cohere  # noqa: F401

        results["cohere"] = True
    except Exception:
        results["cohere"] = False

    # Google Gemini
    try:
        import google.generativeai  # noqa: F401

        results["gemini"] = True
    except Exception:
        results["gemini"] = False

    # AWS Bedrock (via botocore)
    try:
        import botocore.client  # noqa: F401

        results["bedrock"] = True
    except Exception:
        results["bedrock"] = False

    # Pinecone (catches Exception because pinecone-client raises Exception, not ImportError)
    try:
        import pinecone  # noqa: F401

        results["pinecone"] = True
    except Exception:
        results["pinecone"] = False

    # ChromaDB
    try:
        import chromadb  # noqa: F401

        results["chroma"] = True
    except Exception:
        results["chroma"] = False

    # Weaviate
    try:
        import weaviate  # noqa: F401

        results["weaviate"] = True
    except Exception:
        results["weaviate"] = False

    # Qdrant
    try:
        import qdrant_client  # noqa: F401

        results["qdrant"] = True
    except Exception:
        results["qdrant"] = False

    # CrewAI
    try:
        import crewai  # noqa: F401

        results["crewai"] = True
    except Exception:
        results["crewai"] = False

    # MCP
    try:
        import mcp.client.session  # noqa: F401

        results["mcp"] = True
    except Exception:
        results["mcp"] = False

    # Ollama
    try:
        import ollama  # noqa: F401

        results["ollama"] = True
    except Exception:
        results["ollama"] = False

    # Together AI (native SDK)
    try:
        import together  # noqa: F401

        results["together"] = True
    except Exception:
        results["together"] = False

    # Haystack
    try:
        import haystack  # noqa: F401

        results["haystack"] = True
    except Exception:
        results["haystack"] = False

    # DSPy
    try:
        import dspy  # noqa: F401

        results["dspy"] = True
    except Exception:
        results["dspy"] = False

    # LlamaIndex (llama-index-core or llama-index)
    try:
        _llamaindex_found = False
        for _mod in ("llama_index.core", "llama_index"):
            try:
                __import__(_mod)
                _llamaindex_found = True
                break
            except Exception:
                continue
        results["llamaindex"] = _llamaindex_found
    except Exception:
        results["llamaindex"] = False

    # PydanticAI
    try:
        import pydantic_ai  # noqa: F401

        results["pydanticai"] = True
    except Exception:
        results["pydanticai"] = False

    # Instructor
    try:
        import instructor  # noqa: F401

        results["instructor"] = True
    except Exception:
        results["instructor"] = False

    # OpenAI Agents SDK (package: openai-agents, import: agents)
    try:
        import agents  # noqa: F401

        results["openai_agents"] = True
    except Exception:
        results["openai_agents"] = False

    # AutoGen (autogen-agentchat)
    try:
        import autogen_agentchat  # noqa: F401

        results["autogen"] = True
    except Exception:
        results["autogen"] = False

    # Semantic Kernel
    try:
        import semantic_kernel  # noqa: F401

        results["semantic_kernel"] = True
    except Exception:
        results["semantic_kernel"] = False

    # Strands Agents
    try:
        import strands  # noqa: F401

        results["strands"] = True
    except Exception:
        results["strands"] = False

    # Google ADK
    try:
        import google.adk  # noqa: F401

        results["google_adk"] = True
    except Exception:
        results["google_adk"] = False

    # Bedrock Agents (uses same botocore as bedrock, but checks agent-runtime)
    try:
        import botocore.client  # noqa: F401

        results["bedrock_agents"] = True
    except Exception:
        results["bedrock_agents"] = False

    # Claude Agent SDK (very new, try multiple import paths)
    try:
        _found_claude_agents = False
        for _candidate in ("claude_agent", "anthropic.agent", "anthropic.agents", "anthropic_agents"):
            try:
                __import__(_candidate)
                _found_claude_agents = True
                break
            except Exception:
                continue
        results["claude_agents"] = _found_claude_agents
    except Exception:
        results["claude_agents"] = False

    # Milvus (PyMilvus)
    try:
        import pymilvus  # noqa: F401

        results["milvus"] = True
    except Exception:
        results["milvus"] = False

    # MongoDB (PyMongo -- for Atlas Vector Search)
    try:
        import pymongo  # noqa: F401

        results["mongodb_vector"] = True
    except Exception:
        results["mongodb_vector"] = False

    # Elasticsearch
    try:
        import elasticsearch  # noqa: F401

        results["elasticsearch"] = True
    except Exception:
        results["elasticsearch"] = False

    # pgvector (via psycopg2 or asyncpg)
    try:
        _pgvector_found = False
        for _mod in ("psycopg2", "asyncpg"):
            try:
                __import__(_mod)
                _pgvector_found = True
                break
            except Exception:
                continue
        results["pgvector"] = _pgvector_found
    except Exception:
        results["pgvector"] = False

    # Redis (redis-py with RediSearch vector support)
    try:
        import redis  # noqa: F401

        results["redis_vector"] = True
    except Exception:
        results["redis_vector"] = False

    # LanceDB
    try:
        import lancedb  # noqa: F401

        results["lancedb"] = True
    except Exception:
        results["lancedb"] = False

    # Neo4j (graph DB + vector search)
    try:
        import neo4j  # noqa: F401

        results["neo4j"] = True
    except Exception:
        results["neo4j"] = False

    # Mem0 (memory layer, package: mem0ai)
    try:
        import mem0  # noqa: F401

        results["mem0"] = True
    except Exception:
        results["mem0"] = False

    # Guardrails AI
    try:
        import guardrails  # noqa: F401

        results["guardrails_ai"] = True
    except Exception:
        results["guardrails_ai"] = False

    # NeMo Guardrails
    try:
        import nemoguardrails  # noqa: F401

        results["nemo_guardrails"] = True
    except Exception:
        results["nemo_guardrails"] = False

    # LLM Guard
    try:
        import llm_guard  # noqa: F401

        results["llm_guard"] = True
    except Exception:
        results["llm_guard"] = False

    # DeepEval
    try:
        import deepeval  # noqa: F401

        results["deepeval"] = True
    except Exception:
        results["deepeval"] = False

    # Sentence Transformers
    try:
        import sentence_transformers  # noqa: F401

        results["sentence_transformers"] = True
    except Exception:
        results["sentence_transformers"] = False

    # vLLM
    try:
        import vllm  # noqa: F401

        results["vllm"] = True
    except Exception:
        results["vllm"] = False

    # Voyage AI
    try:
        import voyageai  # noqa: F401

        results["voyage"] = True
    except Exception:
        results["voyage"] = False

    # Jina AI reranker
    try:
        _jina_found = False
        for _mod in ("jina_reranker", "jinareranker", "jina"):
            try:
                __import__(_mod)
                _jina_found = True
                break
            except Exception:
                continue
        results["jina"] = _jina_found
    except Exception:
        results["jina"] = False

    # RAGAS (evaluation framework)
    try:
        import ragas  # noqa: F401

        results["ragas"] = True
    except Exception:
        results["ragas"] = False

    # OpenAI Moderation (shares openai package)
    try:
        import openai.resources.moderations  # noqa: F401

        results["openai_moderation"] = True
    except Exception:
        results["openai_moderation"] = False

    # Agno (formerly Phidata)
    try:
        import agno  # noqa: F401

        results["agno"] = True
    except Exception:
        results["agno"] = False

    # smolagents (Hugging Face)
    try:
        import smolagents  # noqa: F401

        results["smolagents"] = True
    except Exception:
        results["smolagents"] = False

    # Nomic (embeddings)
    try:
        import nomic  # noqa: F401

        results["nomic"] = True
    except Exception:
        results["nomic"] = False

    # FastEmbed (Qdrant ONNX embeddings)
    try:
        import fastembed  # noqa: F401

        results["fastembed"] = True
    except Exception:
        results["fastembed"] = False

    # Voyage Rerank (shares voyageai package)
    try:
        import voyageai  # noqa: F401

        results["voyage_rerank"] = True
    except Exception:
        results["voyage_rerank"] = False

    # FAISS (Facebook vector search)
    try:
        import faiss  # noqa: F401

        results["faiss"] = True
    except Exception:
        results["faiss"] = False

    # Letta (formerly MemGPT)
    try:
        import letta  # noqa: F401

        results["letta"] = True
    except Exception:
        results["letta"] = False

    # Vertex AI (Google Cloud)
    try:
        import vertexai  # noqa: F401

        results["vertex_ai"] = True
    except Exception:
        results["vertex_ai"] = False

    # ── Phase 4B additions ──────────────────────────────────────────

    # AI21 Labs
    try:
        import ai21  # noqa: F401

        results["ai21"] = True
    except Exception:
        results["ai21"] = False

    # Lakera Guard
    try:
        _lakera_found = False
        for _mod in ("lakera_guard", "lakera"):
            try:
                __import__(_mod)
                _lakera_found = True
                break
            except Exception:
                continue
        results["lakera_guard"] = _lakera_found
    except Exception:
        results["lakera_guard"] = False

    # Presidio (PII detection)
    try:
        import presidio_analyzer  # noqa: F401

        results["presidio"] = True
    except Exception:
        results["presidio"] = False

    # Azure AI Content Safety
    try:
        from azure.ai.contentsafety import ContentSafetyClient  # noqa: F401

        results["azure_content_safety"] = True
    except Exception:
        results["azure_content_safety"] = False

    # FlashRank (lightweight reranker)
    try:
        import flashrank  # noqa: F401

        results["flashrank"] = True
    except Exception:
        results["flashrank"] = False

    # Zep (memory layer)
    try:
        import zep_python  # noqa: F401

        results["zep"] = True
    except Exception:
        results["zep"] = False

    # CAMEL (multi-agent role-playing)
    try:
        _camel_found = False
        for _mod in ("camel", "camel_ai"):
            try:
                __import__(_mod)
                _camel_found = True
                break
            except Exception:
                continue
        results["camel"] = _camel_found
    except Exception:
        results["camel"] = False

    # Composio (tool integration layer)
    try:
        import composio  # noqa: F401

        results["composio"] = True
    except Exception:
        results["composio"] = False

    # MixedBread (embeddings)
    try:
        _mixedbread_found = False
        for _mod in ("mixedbread_ai", "mixedbread"):
            try:
                __import__(_mod)
                _mixedbread_found = True
                break
            except Exception:
                continue
        results["mixedbread"] = _mixedbread_found
    except Exception:
        results["mixedbread"] = False

    # BGE (BAAI General Embedding + Reranker via FlagEmbedding)
    try:
        import FlagEmbedding  # noqa: F401

        results["bge"] = True
    except Exception:
        results["bge"] = False

    # ── Phase 5 additions ──────────────────────────────────────────

    # HuggingFace Transformers (local inference)
    try:
        import transformers  # noqa: F401

        results["transformers"] = True
    except Exception:
        results["transformers"] = False

    # OpenSearch
    try:
        import opensearchpy  # noqa: F401

        results["opensearch"] = True
    except Exception:
        results["opensearch"] = False

    # Marqo
    try:
        import marqo  # noqa: F401

        results["marqo"] = True
    except Exception:
        results["marqo"] = False

    # Turbopuffer
    try:
        import turbopuffer  # noqa: F401

        results["turbopuffer"] = True
    except Exception:
        results["turbopuffer"] = False

    # DashScope (Alibaba Cloud / Qwen)
    try:
        import dashscope  # noqa: F401

        results["dashscope"] = True
    except Exception:
        results["dashscope"] = False

    # IBM WatsonX
    try:
        import ibm_watsonx_ai  # noqa: F401

        results["watsonx"] = True
    except Exception:
        results["watsonx"] = False

    # SGLang
    try:
        import sglang  # noqa: F401

        results["sglang"] = True
    except Exception:
        results["sglang"] = False

    # llama.cpp (llama-cpp-python)
    try:
        import llama_cpp  # noqa: F401

        results["llamacpp"] = True
    except Exception:
        results["llamacpp"] = False

    # Firecrawl
    try:
        import firecrawl  # noqa: F401

        results["firecrawl"] = True
    except Exception:
        results["firecrawl"] = False

    # Crawl4AI
    try:
        import crawl4ai  # noqa: F401

        results["crawl4ai"] = True
    except Exception:
        results["crawl4ai"] = False

    # Pinecone Rerank (shares pinecone package)
    try:
        import pinecone  # noqa: F401

        results["pinecone_rerank"] = True
    except Exception:
        results["pinecone_rerank"] = False

    # CrossEncoder (shares sentence_transformers package)
    try:
        import sentence_transformers  # noqa: F401

        results["cross_encoder"] = True
    except Exception:
        results["cross_encoder"] = False

    # PolyGuard
    try:
        import polyguard  # noqa: F401

        results["polyguard"] = True
    except Exception:
        results["polyguard"] = False

    # ── Phase 6 additions ──────────────────────────────────────────

    # HuggingFace TGI (text_generation or huggingface_hub)
    try:
        _tgi_found = False
        for _mod in ("text_generation", "huggingface_hub"):
            try:
                __import__(_mod)
                _tgi_found = True
                break
            except Exception:
                continue
        results["huggingface_tgi"] = _tgi_found
    except Exception:
        results["huggingface_tgi"] = False

    # ExLlamaV2 (local inference)
    try:
        import exllamav2  # noqa: F401

        results["exllamav2"] = True
    except Exception:
        results["exllamav2"] = False

    # FalkorDB (graph DB)
    try:
        import falkordb  # noqa: F401

        results["falkordb"] = True
    except Exception:
        results["falkordb"] = False

    # ArangoDB (graph DB)
    try:
        import arango  # noqa: F401

        results["arangodb"] = True
    except Exception:
        results["arangodb"] = False

    # Memgraph (graph DB via GQLAlchemy)
    try:
        import gqlalchemy  # noqa: F401

        results["memgraph"] = True
    except Exception:
        results["memgraph"] = False

    # Amazon Neptune (graph DB, shares botocore with bedrock)
    try:
        import botocore.client  # noqa: F401

        results["neptune"] = True
    except Exception:
        results["neptune"] = False

    # Annoy (vector library)
    try:
        import annoy  # noqa: F401

        results["annoy"] = True
    except Exception:
        results["annoy"] = False

    # hnswlib (vector library)
    try:
        import hnswlib  # noqa: F401

        results["hnswlib"] = True
    except Exception:
        results["hnswlib"] = False

    # USearch (vector library)
    try:
        import usearch.index  # noqa: F401

        results["usearch"] = True
    except Exception:
        results["usearch"] = False

    # ScaNN (vector library)
    try:
        import scann  # noqa: F401

        results["scann"] = True
    except Exception:
        results["scann"] = False

    # Vespa (vector DB)
    try:
        import vespa  # noqa: F401

        results["vespa"] = True
    except Exception:
        results["vespa"] = False

    # DuckDB (vector search via SQL)
    try:
        import duckdb  # noqa: F401

        results["duckdb_vector"] = True
    except Exception:
        results["duckdb_vector"] = False

    # Cassandra (vector search via CQL)
    try:
        import cassandra  # noqa: F401

        results["cassandra_vector"] = True
    except Exception:
        results["cassandra_vector"] = False

    # ColBERT (reranker via RAGatouille)
    try:
        _colbert_found = False
        for _mod in ("ragatouille", "colbert"):
            try:
                __import__(_mod)
                _colbert_found = True
                break
            except Exception:
                continue
        results["colbert"] = _colbert_found
    except Exception:
        results["colbert"] = False

    # Braintrust (eval framework)
    try:
        import braintrust  # noqa: F401

        results["braintrust"] = True
    except Exception:
        results["braintrust"] = False

    # TruLens (eval framework)
    try:
        _trulens_found = False
        for _mod in ("trulens", "trulens_eval"):
            try:
                __import__(_mod)
                _trulens_found = True
                break
            except Exception:
                continue
        results["trulens"] = _trulens_found
    except Exception:
        results["trulens"] = False

    # Giskard (eval framework)
    try:
        import giskard  # noqa: F401

        results["giskard"] = True
    except Exception:
        results["giskard"] = False

    # Inspect AI (eval framework)
    try:
        import inspect_ai  # noqa: F401

        results["inspect_ai"] = True
    except Exception:
        results["inspect_ai"] = False

    # ControlFlow (agentic framework)
    try:
        import controlflow  # noqa: F401

        results["controlflow"] = True
    except Exception:
        results["controlflow"] = False

    # Llama Stack (agentic framework)
    try:
        _llama_stack_found = False
        for _mod in ("llama_stack_client", "llama_stack"):
            try:
                __import__(_mod)
                _llama_stack_found = True
                break
            except Exception:
                continue
        results["llama_stack"] = _llama_stack_found
    except Exception:
        results["llama_stack"] = False

    # LiveKit Agents (agentic framework)
    try:
        _livekit_found = False
        for _mod in ("livekit.agents", "livekit"):
            try:
                __import__(_mod)
                _livekit_found = True
                break
            except Exception:
                continue
        results["livekit_agents"] = _livekit_found
    except Exception:
        results["livekit_agents"] = False

    # Langroid (agentic framework)
    try:
        import langroid  # noqa: F401

        results["langroid"] = True
    except Exception:
        results["langroid"] = False

    # ── Phase 7 additions ──────────────────────────────────────────

    # Meta Llama (via llama-stack-client)
    try:
        import llama_stack_client  # noqa: F401

        results["meta_llama"] = True
    except Exception:
        results["meta_llama"] = False

    # SuperAGI
    try:
        import superagi  # noqa: F401

        results["superagi"] = True
    except Exception:
        results["superagi"] = False

    # Agency Swarm
    try:
        import agency_swarm  # noqa: F401

        results["agency_swarm"] = True
    except Exception:
        results["agency_swarm"] = False

    # Julep
    try:
        import julep  # noqa: F401

        results["julep"] = True
    except Exception:
        results["julep"] = False

    # Pipecat
    try:
        import pipecat  # noqa: F401

        results["pipecat"] = True
    except Exception:
        results["pipecat"] = False

    # Deepgram (voice/speech)
    try:
        import deepgram  # noqa: F401

        results["deepgram"] = True
    except Exception:
        results["deepgram"] = False

    # ElevenLabs (voice/speech)
    try:
        import elevenlabs  # noqa: F401

        results["elevenlabs"] = True
    except Exception:
        results["elevenlabs"] = False

    # AssemblyAI (voice/speech)
    try:
        import assemblyai  # noqa: F401

        results["assemblyai"] = True
    except Exception:
        results["assemblyai"] = False

    # Whisper.cpp (voice/speech)
    try:
        _whisper_cpp_found = False
        for _mod in ("pywhispercpp", "whispercpp"):
            try:
                __import__(_mod)
                _whisper_cpp_found = True
                break
            except Exception:
                continue
        results["whisper_cpp"] = _whisper_cpp_found
    except Exception:
        results["whisper_cpp"] = False

    # PlayHT (voice/speech)
    try:
        import pyht  # noqa: F401

        results["playht"] = True
    except Exception:
        results["playht"] = False

    # E5 embeddings (via sentence-transformers)
    try:
        import sentence_transformers  # noqa: F401

        results["e5"] = True
    except Exception:
        results["e5"] = False

    # Instructor Embeddings
    try:
        import InstructorEmbedding  # noqa: F401

        results["instructor_embeddings"] = True
    except Exception:
        results["instructor_embeddings"] = False

    # TEI (Text Embeddings Inference, via huggingface_hub)
    try:
        import huggingface_hub  # noqa: F401

        results["tei"] = True
    except Exception:
        results["tei"] = False

    # promptfoo (eval)
    try:
        import promptfoo  # noqa: F401

        results["promptfoo"] = True
    except Exception:
        results["promptfoo"] = False

    # Arize Phoenix (eval)
    try:
        import phoenix  # noqa: F401

        results["arize_phoenix"] = True
    except Exception:
        results["arize_phoenix"] = False

    # Opik (eval)
    try:
        import opik  # noqa: F401

        results["opik"] = True
    except Exception:
        results["opik"] = False

    # LangSmith (eval)
    try:
        import langsmith  # noqa: F401

        results["langsmith"] = True
    except Exception:
        results["langsmith"] = False

    # Langfuse (eval)
    try:
        import langfuse  # noqa: F401

        results["langfuse"] = True
    except Exception:
        results["langfuse"] = False

    # Vapi (voice platform)
    try:
        import vapi  # noqa: F401

        results["vapi"] = True
    except Exception:
        results["vapi"] = False

    # Retell AI (voice platform)
    try:
        import retell  # noqa: F401

        results["retell"] = True
    except Exception:
        results["retell"] = False

    # Stable Diffusion (image generation via diffusers)
    try:
        import diffusers  # noqa: F401

        results["stable_diffusion"] = True
    except Exception:
        results["stable_diffusion"] = False

    # Flux (image generation via diffusers or bfl)
    try:
        _flux_found = False
        for _mod in ("diffusers", "bfl"):
            try:
                __import__(_mod)
                _flux_found = True
                break
            except Exception:
                continue
        results["flux"] = _flux_found
    except Exception:
        results["flux"] = False

    # Fal AI (serverless inference)
    try:
        import fal_client  # noqa: F401

        results["fal"] = True
    except Exception:
        results["fal"] = False

    # Supabase (vector DB)
    try:
        import supabase  # noqa: F401

        results["supabase"] = True
    except Exception:
        results["supabase"] = False

    # SingleStore (vector DB)
    try:
        import singlestoredb  # noqa: F401

        results["singlestore"] = True
    except Exception:
        results["singlestore"] = False

    # GraphRAG (RAG)
    try:
        import graphrag  # noqa: F401

        results["graphrag"] = True
    except Exception:
        results["graphrag"] = False

    # LightRAG (RAG)
    try:
        import lightrag  # noqa: F401

        results["lightrag"] = True
    except Exception:
        results["lightrag"] = False

    # Pathway (RAG)
    try:
        import pathway  # noqa: F401

        results["pathway"] = True
    except Exception:
        results["pathway"] = False

    # RAGFlow (RAG)
    try:
        _ragflow_found = False
        for _mod in ("ragflow", "ragflow_sdk"):
            try:
                __import__(_mod)
                _ragflow_found = True
                break
            except Exception:
                continue
        results["ragflow"] = _ragflow_found
    except Exception:
        results["ragflow"] = False

    # R2R (RAG)
    try:
        import r2r  # noqa: F401

        results["r2r"] = True
    except Exception:
        results["r2r"] = False

    # Vectara (RAG)
    try:
        import vectara  # noqa: F401

        results["vectara"] = True
    except Exception:
        results["vectara"] = False

    # TensorRT-LLM (model serving)
    try:
        import tensorrt_llm  # noqa: F401

        results["tensorrt_llm"] = True
    except Exception:
        results["tensorrt_llm"] = False

    # Triton (model serving)
    try:
        _triton_found = False
        for _mod in ("tritonclient.http", "tritonclient.grpc"):
            try:
                __import__(_mod)
                _triton_found = True
                break
            except Exception:
                continue
        results["triton"] = _triton_found
    except Exception:
        results["triton"] = False

    # LocalAI (local inference via OpenAI-compatible)
    try:
        import openai  # noqa: F401

        results["localai"] = True
    except Exception:
        results["localai"] = False

    # llamafile (local inference via OpenAI-compatible)
    try:
        import openai  # noqa: F401

        results["llamafile"] = True
    except Exception:
        results["llamafile"] = False

    # BentoML (model serving)
    try:
        import bentoml  # noqa: F401

        results["bentoml"] = True
    except Exception:
        results["bentoml"] = False

    # A2A (Agent-to-Agent protocol)
    try:
        _a2a_found = False
        for _mod in ("a2a", "a2a_sdk"):
            try:
                __import__(_mod)
                _a2a_found = True
                break
            except Exception:
                continue
        results["a2a"] = _a2a_found
    except Exception:
        results["a2a"] = False

    # Computer Use (shares anthropic package)
    try:
        import anthropic  # noqa: F401

        results["computer_use"] = True
    except Exception:
        results["computer_use"] = False

    # ── Phase 8 additions ──────────────────────────────────────────

    # Google Cloud STT
    try:
        import google.cloud.speech  # noqa: F401

        results["google_cloud_stt"] = True
    except Exception:
        results["google_cloud_stt"] = False

    # Azure Speech (STT + TTS share the same package)
    try:
        import azure.cognitiveservices.speech  # noqa: F401

        results["azure_speech"] = True
        results["azure_tts"] = True
    except Exception:
        results["azure_speech"] = False
        results["azure_tts"] = False

    # AWS Transcribe (shares botocore with bedrock)
    try:
        import botocore.client  # noqa: F401

        results["aws_transcribe"] = True
    except Exception:
        results["aws_transcribe"] = False

    # Faster Whisper
    try:
        import faster_whisper  # noqa: F401

        results["faster_whisper"] = True
    except Exception:
        results["faster_whisper"] = False

    # Google Cloud TTS
    try:
        import google.cloud.texttospeech  # noqa: F401

        results["google_cloud_tts"] = True
    except Exception:
        results["google_cloud_tts"] = False

    # AWS Polly (shares botocore with bedrock)
    try:
        import botocore.client  # noqa: F401

        results["aws_polly"] = True
    except Exception:
        results["aws_polly"] = False

    # Cartesia
    try:
        import cartesia  # noqa: F401

        results["cartesia"] = True
    except Exception:
        results["cartesia"] = False

    # Coqui TTS
    try:
        import TTS  # noqa: F401

        results["coqui_tts"] = True
    except Exception:
        results["coqui_tts"] = False

    # Mirascope
    try:
        import mirascope  # noqa: F401

        results["mirascope"] = True
    except Exception:
        results["mirascope"] = False

    # Outlines
    try:
        import outlines  # noqa: F401

        results["outlines"] = True
    except Exception:
        results["outlines"] = False

    # Guidance
    try:
        import guidance  # noqa: F401

        results["guidance"] = True
    except Exception:
        results["guidance"] = False

    # Magentic
    try:
        import magentic  # noqa: F401

        results["magentic"] = True
    except Exception:
        results["magentic"] = False

    # LMQL
    try:
        import lmql  # noqa: F401

        results["lmql"] = True
    except Exception:
        results["lmql"] = False

    # Marvin
    try:
        import marvin  # noqa: F401

        results["marvin"] = True
    except Exception:
        results["marvin"] = False

    # Azure AI Inference
    try:
        from azure.ai.inference import ChatCompletionsClient  # noqa: F401

        results["azure_ai_inference"] = True
    except Exception:
        results["azure_ai_inference"] = False

    # E2B Code Interpreter
    try:
        import e2b_code_interpreter  # noqa: F401

        results["e2b"] = True
    except Exception:
        try:
            import e2b  # noqa: F401

            results["e2b"] = True
        except Exception:
            results["e2b"] = False

    # ScrapeGraphAI
    try:
        import scrapegraphai  # noqa: F401

        results["scrapegraphai"] = True
    except Exception:
        results["scrapegraphai"] = False

    return results
