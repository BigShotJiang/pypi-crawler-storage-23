"""TruLens auto-instrumentor for waxell-observe.

Monkey-patches ``trulens`` feedback evaluation and app wrapper entry points
to emit evaluation spans tracking feedback function names, score values,
and metric types.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class TruLensInstrumentor(BaseInstrumentor):
    """Instrumentor for the TruLens evaluation framework (``trulens`` package).

    Patches Feedback.evaluate() / Feedback.__call__() and TruBasicApp.main_call().
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import trulens  # noqa: F401
        except ImportError:
            try:
                import trulens_eval  # noqa: F401
            except ImportError:
                logger.debug("trulens not installed -- skipping instrumentation")
                return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping TruLens instrumentation")
            return False

        patched = False

        # Patch trulens.core.feedback.Feedback.evaluate
        try:
            wrapt.wrap_function_wrapper(
                "trulens.core.feedback",
                "Feedback.evaluate",
                _feedback_evaluate_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch trulens.core.feedback.Feedback.evaluate: %s", exc)

        # Try alternate: trulens.feedback.Feedback.__call__
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "trulens.feedback",
                    "Feedback.__call__",
                    _feedback_call_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch trulens.feedback.Feedback.__call__: %s", exc)

        # Try legacy trulens_eval path
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "trulens_eval.feedback",
                    "Feedback.__call__",
                    _feedback_call_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch trulens_eval.feedback.Feedback.__call__: %s", exc)

        # Patch TruBasicApp.main_call (app wrapper)
        try:
            wrapt.wrap_function_wrapper(
                "trulens.apps.basic",
                "TruBasicApp.main_call",
                _app_main_call_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch trulens.apps.basic.TruBasicApp.main_call: %s", exc)
            # Try legacy path
            try:
                wrapt.wrap_function_wrapper(
                    "trulens_eval.tru_basic_app",
                    "TruBasicApp.main_call",
                    _app_main_call_wrapper,
                )
            except Exception as exc2:
                logger.debug("Failed to patch trulens_eval TruBasicApp.main_call: %s", exc2)

        if not patched:
            logger.debug("Could not find TruLens methods to patch")
            return False

        self._instrumented = True
        logger.debug("TruLens instrumented (Feedback.evaluate + TruBasicApp.main_call)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Uninstrument Feedback.evaluate (trulens.core.feedback)
        try:
            from trulens.core.feedback import Feedback

            if hasattr(Feedback.evaluate, "__wrapped__"):
                Feedback.evaluate = Feedback.evaluate.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument Feedback.__call__ (trulens.feedback)
        try:
            from trulens.feedback import Feedback

            if hasattr(Feedback.__call__, "__wrapped__"):
                Feedback.__call__ = Feedback.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument trulens_eval path
        try:
            from trulens_eval.feedback import Feedback

            if hasattr(Feedback.__call__, "__wrapped__"):
                Feedback.__call__ = Feedback.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument TruBasicApp.main_call
        try:
            from trulens.apps.basic import TruBasicApp

            if hasattr(TruBasicApp.main_call, "__wrapped__"):
                TruBasicApp.main_call = TruBasicApp.main_call.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from trulens_eval.tru_basic_app import TruBasicApp

            if hasattr(TruBasicApp.main_call, "__wrapped__"):
                TruBasicApp.main_call = TruBasicApp.main_call.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("TruLens uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _feedback_evaluate_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Feedback.evaluate`` -- feedback function evaluation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    feedback_name = ""
    try:
        feedback_name = getattr(instance, "name", None) or type(instance).__name__
    except Exception:
        feedback_name = "UnknownFeedback"

    try:
        span = start_step_span(step_name="trulens.evaluate")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "trulens")
        span.set_attribute(WaxellAttributes.EVAL_METRIC_NAME, str(feedback_name))
        span.set_attribute("waxell.eval.metric", str(feedback_name))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_feedback_result(span, instance, result, feedback_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _feedback_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Feedback.__call__`` -- feedback function call."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    feedback_name = ""
    try:
        feedback_name = getattr(instance, "name", None) or type(instance).__name__
    except Exception:
        feedback_name = "UnknownFeedback"

    try:
        span = start_step_span(step_name="trulens.evaluate")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "trulens")
        span.set_attribute(WaxellAttributes.EVAL_METRIC_NAME, str(feedback_name))
        span.set_attribute("waxell.eval.metric", str(feedback_name))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_feedback_result(span, instance, result, feedback_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _app_main_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``TruBasicApp.main_call`` -- app wrapper."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    app_name = ""
    try:
        app_name = getattr(instance, "app_name", None) or getattr(instance, "app_id", None) or type(instance).__name__
    except Exception:
        app_name = "UnknownApp"

    try:
        span = start_step_span(step_name="trulens.app_call")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "trulens")
        span.set_attribute("waxell.eval.app_name", str(app_name))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_app_call(app_name, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_feedback_result(span, instance, result, feedback_name: str) -> None:
    """Extract feedback evaluation results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    score = None
    passed = False

    # TruLens feedback results can be a float, a tuple (score, metadata), or an object
    try:
        if isinstance(result, (int, float)):
            score = float(result)
        elif isinstance(result, tuple) and len(result) > 0:
            score = float(result[0])
        else:
            score = getattr(result, "score", None) or getattr(result, "result", None)
            if score is not None:
                score = float(score)
    except (TypeError, ValueError):
        pass

    try:
        threshold = getattr(instance, "threshold", None)
        if score is not None and threshold is not None:
            passed = score >= float(threshold)
        elif score is not None:
            passed = score >= 0.5
    except Exception:
        pass

    try:
        if score is not None:
            span.set_attribute(WaxellAttributes.EVAL_SCORE, float(score))
            span.set_attribute("waxell.eval.score", float(score))
        span.set_attribute(WaxellAttributes.EVAL_PASSED, passed)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_feedback(feedback_name, score, passed)
    except Exception:
        pass


def _record_http_feedback(feedback_name: str, score, passed: bool) -> None:
    """Record a feedback evaluation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"eval:trulens.feedback:{feedback_name}",
            output={
                "framework": "trulens",
                "metric": feedback_name,
                "score": float(score) if score is not None else None,
                "passed": passed,
            },
        )


def _record_http_app_call(app_name: str, result) -> None:
    """Record a TruLens app call to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:trulens.app_call",
            output={
                "framework": "trulens",
                "app_name": app_name,
                "result_preview": str(result)[:500],
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
