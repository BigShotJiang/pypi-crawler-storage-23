"""Base class for waxell-observe auto-instrumentors.

Defines the interface that all library-specific instrumentors must implement.
This module has NO OpenTelemetry imports at module level, so it can be
imported safely regardless of whether OTel is installed.
"""

from abc import ABC, abstractmethod


class BaseInstrumentor(ABC):
    """Abstract base class for library-specific instrumentors.

    Subclasses implement monkey-patching logic to intercept LLM SDK
    calls and emit spans/metrics.

    Each subclass maintains its own ``_instrumented`` guard to prevent
    double-patching.
    """

    _instrumented: bool = False

    @abstractmethod
    def instrument(self) -> bool:
        """Apply monkey-patches to the target library.

        Returns True if instrumentation was applied successfully,
        False if skipped (e.g. library not importable, already
        instrumented).
        """
        ...

    @abstractmethod
    def uninstrument(self) -> None:
        """Restore original (unpatched) methods on the target library."""
        ...

    @abstractmethod
    def is_instrumented(self) -> bool:
        """Return True if this instrumentor is currently active."""
        ...
