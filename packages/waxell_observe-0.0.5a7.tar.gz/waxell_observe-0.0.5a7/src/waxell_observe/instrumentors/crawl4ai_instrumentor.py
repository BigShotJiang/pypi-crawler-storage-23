"""Crawl4AI auto-instrumentor for waxell-observe.

Monkey-patches ``crawl4ai.async_web_crawler.AsyncWebCrawler`` methods to emit
OTel tool spans for web crawling operations commonly used in RAG pipelines:
  - ``arun``       -- single URL async crawl
  - ``arun_many``  -- batch async crawl (multiple URLs)

These are HTTP-based tool operations, not LLM calls, so all spans use
``start_tool_span()`` instead of ``start_llm_span()``.

Cost is tracked externally by Crawl4AI (open-source / self-hosted), so cost
is always 0.0 here.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class Crawl4AIInstrumentor(BaseInstrumentor):
    """Instrumentor for the Crawl4AI library (``crawl4ai`` package).

    Patches ``AsyncWebCrawler.arun`` and ``AsyncWebCrawler.arun_many``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import crawl4ai.async_web_crawler  # noqa: F401
        except ImportError:
            logger.debug("crawl4ai package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Crawl4AI instrumentation")
            return False

        patched = False

        # Patch arun
        try:
            wrapt.wrap_function_wrapper(
                "crawl4ai.async_web_crawler",
                "AsyncWebCrawler.arun",
                _arun_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch crawl4ai AsyncWebCrawler.arun: %s", exc)

        # Patch arun_many
        try:
            wrapt.wrap_function_wrapper(
                "crawl4ai.async_web_crawler",
                "AsyncWebCrawler.arun_many",
                _arun_many_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch crawl4ai AsyncWebCrawler.arun_many: %s", exc)

        if not patched:
            logger.debug("Could not find any Crawl4AI methods to patch")
            return False

        self._instrumented = True
        logger.debug("Crawl4AI AsyncWebCrawler instrumented (arun + arun_many)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import crawl4ai.async_web_crawler

            for attr in ("arun", "arun_many"):
                try:
                    method = getattr(crawl4ai.async_web_crawler.AsyncWebCrawler, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(
                            crawl4ai.async_web_crawler.AsyncWebCrawler,
                            attr,
                            method.__wrapped__,
                        )
                except (AttributeError, TypeError):
                    pass
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("Crawl4AI AsyncWebCrawler uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Crawl4AI responses
# ---------------------------------------------------------------------------


def _truncate_url(url: str, max_len: int = 200) -> str:
    """Truncate a URL for safe span attribute storage."""
    if not url or not isinstance(url, str):
        return ""
    return url[:max_len]


def _extract_content_length(response) -> int:
    """Extract the total content length from a CrawlResult.

    Crawl4AI results expose ``markdown``, ``html``, ``cleaned_html``, etc.
    We prefer ``markdown`` as the canonical content field.
    """
    if response is None:
        return 0

    try:
        # Object with attribute access (CrawlResult dataclass)
        for attr in ("markdown", "cleaned_html", "html", "text"):
            content = getattr(response, attr, None)
            if content and isinstance(content, str):
                return len(content)

        # Dict fallback
        if isinstance(response, dict):
            for key in ("markdown", "cleaned_html", "html", "text"):
                content = response.get(key, "")
                if content and isinstance(content, str):
                    return len(content)
    except Exception:
        pass

    return 0


def _extract_success(response) -> bool:
    """Extract the success flag from a CrawlResult."""
    if response is None:
        return False

    try:
        # CrawlResult has a ``success`` attribute
        success = getattr(response, "success", None)
        if success is not None:
            return bool(success)

        # Dict fallback
        if isinstance(response, dict):
            return bool(response.get("success", False))
    except Exception:
        pass

    return False


def _extract_url(args, kwargs) -> str:
    """Extract URL from arun args/kwargs."""
    url = ""
    if args:
        url = str(args[0]) if args[0] else ""
    url = kwargs.get("url", url)
    return url


def _extract_content_preview(response) -> str:
    """Extract a short content preview from a CrawlResult."""
    if response is None:
        return ""

    try:
        for attr in ("markdown", "cleaned_html", "html", "text"):
            content = getattr(response, attr, None)
            if content and isinstance(content, str):
                return content[:500]

        if isinstance(response, dict):
            for key in ("markdown", "cleaned_html", "html", "text"):
                content = response.get(key, "")
                if content and isinstance(content, str):
                    return content[:500]
    except Exception:
        pass

    return ""


# ---------------------------------------------------------------------------
# Async wrapper functions
# ---------------------------------------------------------------------------


async def _arun_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncWebCrawler.arun``."""
    url = _extract_url(args, kwargs)

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="crawl4ai.arun", tool_type="web_scraper")
        span.set_attribute("waxell.crawl4ai.url", _truncate_url(url))
        span.set_attribute("waxell.crawl4ai.method", "arun")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            success = _extract_success(response)
            content_length = _extract_content_length(response)
            span.set_attribute("waxell.crawl4ai.success", success)
            span.set_attribute("waxell.crawl4ai.content_length", content_length)
            span.set_attribute("waxell.crawl4ai.result_count", 1)
        except Exception:
            pass

        try:
            _record_tool_call(
                tool_name="crawl4ai.arun",
                url=url,
                response=response,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _arun_many_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AsyncWebCrawler.arun_many``."""
    # arun_many takes a list of URLs as the first arg
    urls = []
    if args:
        first_arg = args[0]
        if isinstance(first_arg, (list, tuple)):
            urls = [str(u) for u in first_arg]
    urls = kwargs.get("urls", urls)

    url_display = ", ".join(_truncate_url(u, 100) for u in urls[:5])
    if len(urls) > 5:
        url_display += f" ... (+{len(urls) - 5} more)"

    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_tool_span(tool_name="crawl4ai.arun_many", tool_type="web_scraper")
        span.set_attribute("waxell.crawl4ai.url", _truncate_url(url_display))
        span.set_attribute("waxell.crawl4ai.method", "arun_many")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            result_count = len(response) if isinstance(response, (list, tuple)) else 0
            span.set_attribute("waxell.crawl4ai.result_count", result_count)

            # Aggregate content length and success across all results
            total_content_length = 0
            all_success = True
            if isinstance(response, (list, tuple)):
                for result in response:
                    total_content_length += _extract_content_length(result)
                    if not _extract_success(result):
                        all_success = False

            span.set_attribute("waxell.crawl4ai.content_length", total_content_length)
            span.set_attribute("waxell.crawl4ai.success", all_success)
        except Exception:
            pass

        try:
            _record_tool_call(
                tool_name="crawl4ai.arun_many",
                url=url_display,
                response=response,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tool_call(
    tool_name: str,
    url: str,
    response,
) -> None:
    """Record a Crawl4AI tool call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    # Extract preview for single result or first result of batch
    preview = ""
    if isinstance(response, (list, tuple)) and response:
        preview = _extract_content_preview(response[0])
        result_count = len(response)
    else:
        preview = _extract_content_preview(response)
        result_count = 1 if response else 0

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        output = {}
        if result_count:
            output["result_count"] = result_count
        if preview:
            output["preview"] = preview

        ctx.record_tool_call(
            name=tool_name,
            input={"url": _truncate_url(url)},
            output=output,
            tool_type="web_scraper",
            status="ok",
        )
    else:
        # Fall back to collector with an LLM-call-shaped dict
        call_data = {
            "model": "crawl4ai",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost": 0.0,
            "task": tool_name,
            "prompt_preview": _truncate_url(url),
            "response_preview": preview,
        }
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
