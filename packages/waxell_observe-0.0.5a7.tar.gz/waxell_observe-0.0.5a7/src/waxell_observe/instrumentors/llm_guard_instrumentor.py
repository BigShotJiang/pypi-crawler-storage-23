"""LLM Guard auto-instrumentor for waxell-observe.

Monkey-patches llm_guard input/output scanner scan methods to emit
guardrail spans tracking content safety checks.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LLMGuardInstrumentor(BaseInstrumentor):
    """Instrumentor for LLM Guard (``llm_guard`` package).

    Patches input and output scanner base classes' scan() methods.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import llm_guard  # noqa: F401
        except ImportError:
            logger.debug("llm_guard not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping LLM Guard instrumentation")
            return False

        patched = False

        # Patch input scanner base class scan()
        try:
            wrapt.wrap_function_wrapper(
                "llm_guard.input_scanners.base",
                "Scanner.scan",
                _sync_input_scan_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch input Scanner.scan: %s", exc)

        # Patch output scanner base class scan()
        try:
            wrapt.wrap_function_wrapper(
                "llm_guard.output_scanners.base",
                "Scanner.scan",
                _sync_output_scan_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch output Scanner.scan: %s", exc)

        # Fallback: try alternate import paths for older llm_guard versions
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "llm_guard.input_scanners",
                    "Scanner.scan",
                    _sync_input_scan_wrapper,
                )
                patched = True
            except Exception:
                pass

        if not patched:
            logger.debug("Could not find LLM Guard methods to patch")
            return False

        self._instrumented = True
        logger.debug("LLM Guard instrumented (input/output Scanner.scan)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore input scanner
        try:
            from llm_guard.input_scanners.base import Scanner as InputScanner

            if hasattr(InputScanner.scan, "__wrapped__"):
                InputScanner.scan = InputScanner.scan.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Restore output scanner
        try:
            from llm_guard.output_scanners.base import Scanner as OutputScanner

            if hasattr(OutputScanner.scan, "__wrapped__"):
                OutputScanner.scan = OutputScanner.scan.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("LLM Guard uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_input_scan_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for input ``Scanner.scan`` -- input content safety scanning."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    scanner_name = type(instance).__name__

    try:
        span = start_guardrail_span(
            guardrail_name=f"llm_guard_input:{scanner_name}",
            framework="llm_guard",
        )
        span.set_attribute("waxell.guardrail.scanner", scanner_name)
        span.set_attribute("waxell.guardrail.scan_type", "input")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_scan_result(span, instance, result, scan_type="input")
        except Exception:
            pass
        return result
    finally:
        span.end()


def _sync_output_scan_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for output ``Scanner.scan`` -- output content safety scanning."""
    try:
        from ..tracing.spans import start_guardrail_span
    except Exception:
        return wrapped(*args, **kwargs)

    scanner_name = type(instance).__name__

    try:
        span = start_guardrail_span(
            guardrail_name=f"llm_guard_output:{scanner_name}",
            framework="llm_guard",
        )
        span.set_attribute("waxell.guardrail.scanner", scanner_name)
        span.set_attribute("waxell.guardrail.scan_type", "output")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_scan_result(span, instance, result, scan_type="output")
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_scan_result(span, instance, result, scan_type: str = "input") -> None:
    """Extract scan results and set span attributes.

    LLM Guard scanners return a tuple of (sanitized_output, is_valid, risk_score)
    or (sanitized_output, is_valid) depending on the version.
    """
    from ..tracing.attributes import WaxellAttributes

    passed = True
    action = "pass"
    scanner_name = type(instance).__name__

    try:
        if isinstance(result, tuple):
            if len(result) >= 2:
                sanitized_output = result[0]
                is_valid = result[1]
                passed = bool(is_valid)

                # Determine action based on result
                if passed:
                    action = "pass"
                else:
                    # If the output was modified, it was sanitized; otherwise blocked
                    # Check if input args are available to compare
                    action = "sanitize"

            if len(result) >= 3:
                risk_score = result[2]
                try:
                    span.set_attribute("waxell.guardrail.risk_score", float(risk_score))
                except Exception:
                    pass
        else:
            # Unexpected result type -- treat as pass
            passed = True
            action = "pass"
    except Exception:
        pass

    try:
        span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, passed)
        span.set_attribute(WaxellAttributes.GUARDRAIL_ACTION, action)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_scan(scanner_name, scan_type, passed, action)
    except Exception:
        pass


def _record_http_scan(scanner_name: str, scan_type: str, passed: bool, action: str) -> None:
    """Record an LLM Guard scan to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"guardrail:llm_guard_{scan_type}:{scanner_name}",
            output={
                "passed": passed,
                "action": action,
                "scanner": scanner_name,
                "scan_type": scan_type,
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
