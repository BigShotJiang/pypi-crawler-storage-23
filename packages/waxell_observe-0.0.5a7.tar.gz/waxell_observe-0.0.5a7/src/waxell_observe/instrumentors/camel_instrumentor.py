"""CAMEL auto-instrumentor for waxell-observe.

Monkey-patches ``camel.agents.ChatAgent.step`` and
``camel.societies.RolePlaying.step`` to emit OTel spans and record to
the Waxell HTTP API.

CAMEL is a multi-agent role-playing framework where ChatAgent handles
single agent interactions and RolePlaying orchestrates two-agent
conversations.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class CamelInstrumentor(BaseInstrumentor):
    """Instrumentor for the CAMEL framework (``camel-ai`` package).

    Patches ChatAgent.step and RolePlaying.step.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import camel  # noqa: F401
        except ImportError:
            logger.debug("camel not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping CAMEL instrumentation")
            return False

        patched = False

        # Patch ChatAgent.step (sync entry point)
        try:
            wrapt.wrap_function_wrapper(
                "camel.agents",
                "ChatAgent.step",
                _chat_agent_step_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch ChatAgent.step: %s", exc)

        # Patch ChatAgent.step_async (async entry point)
        try:
            wrapt.wrap_function_wrapper(
                "camel.agents",
                "ChatAgent.step_async",
                _chat_agent_step_async_wrapper,
            )
        except Exception:
            pass

        # Patch RolePlaying.step
        try:
            wrapt.wrap_function_wrapper(
                "camel.societies",
                "RolePlaying.step",
                _role_playing_step_wrapper,
            )
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find CAMEL methods to patch")
            return False

        self._instrumented = True
        logger.debug("CAMEL instrumented (ChatAgent.step + RolePlaying.step)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from camel.agents import ChatAgent

            if hasattr(ChatAgent.step, "__wrapped__"):
                ChatAgent.step = ChatAgent.step.__wrapped__
            if hasattr(getattr(ChatAgent, "step_async", None), "__wrapped__"):
                ChatAgent.step_async = ChatAgent.step_async.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from camel.societies import RolePlaying

            if hasattr(RolePlaying.step, "__wrapped__"):
                RolePlaying.step = RolePlaying.step.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("CAMEL uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _chat_agent_step_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``ChatAgent.step``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    agent_role = getattr(instance, "role_name", None) or "camel-agent"

    # Extract input message preview
    input_preview = ""
    try:
        if args:
            msg = args[0]
            content = getattr(msg, "content", None) or str(msg)
            input_preview = str(content)[:200]
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=agent_role,
            workflow_name="camel_chat_agent_step",
        )
        span.set_attribute("waxell.camel.agent_system", "camel")
        span.set_attribute("waxell.camel.agent_type", "chat_agent")
        span.set_attribute("waxell.camel.agent_name", agent_role)
        if input_preview:
            span.set_attribute("waxell.camel.input_preview", input_preview)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_chat_agent_result_attributes(span, result, agent_role)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _chat_agent_step_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``ChatAgent.step_async``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    agent_role = getattr(instance, "role_name", None) or "camel-agent"

    try:
        span = start_agent_span(
            agent_name=agent_role,
            workflow_name="camel_chat_agent_step_async",
        )
        span.set_attribute("waxell.camel.agent_system", "camel")
        span.set_attribute("waxell.camel.agent_type", "chat_agent")
        span.set_attribute("waxell.camel.agent_name", agent_role)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_chat_agent_result_attributes(span, result, agent_role)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _role_playing_step_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``RolePlaying.step``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    # RolePlaying has assistant_agent and user_agent with roles
    assistant_role = ""
    user_role = ""
    try:
        assistant_agent = getattr(instance, "assistant_agent", None)
        user_agent = getattr(instance, "user_agent", None)
        if assistant_agent:
            assistant_role = getattr(assistant_agent, "role_name", "assistant")
        if user_agent:
            user_role = getattr(user_agent, "role_name", "user")
    except Exception:
        pass

    session_name = f"role_playing:{assistant_role}+{user_role}" if assistant_role else "camel-role-playing"

    try:
        span = start_agent_span(
            agent_name=session_name,
            workflow_name="camel_role_playing_step",
        )
        span.set_attribute("waxell.camel.agent_system", "camel")
        span.set_attribute("waxell.camel.agent_type", "role_playing")
        span.set_attribute("waxell.camel.assistant_role", assistant_role)
        span.set_attribute("waxell.camel.user_role", user_role)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_role_playing_result_attributes(span, result, session_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _set_chat_agent_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span for a ChatAgent response."""
    # ChatAgentResponse has: msgs, terminated, info
    msgs = getattr(result, "msgs", None) or []
    terminated = getattr(result, "terminated", False)
    info = getattr(result, "info", None) or {}

    span.set_attribute("waxell.camel.output_message_count", len(msgs))
    span.set_attribute("waxell.camel.terminated", terminated)

    # Extract token usage from info if available
    try:
        usage = info.get("usage", None) if isinstance(info, dict) else None
        if usage:
            prompt_tokens = getattr(usage, "prompt_tokens", 0) or (
                usage.get("prompt_tokens", 0) if isinstance(usage, dict) else 0
            )
            completion_tokens = getattr(usage, "completion_tokens", 0) or (
                usage.get("completion_tokens", 0) if isinstance(usage, dict) else 0
            )
            if prompt_tokens:
                span.set_attribute("waxell.camel.prompt_tokens", prompt_tokens)
            if completion_tokens:
                span.set_attribute("waxell.camel.completion_tokens", completion_tokens)
    except Exception:
        pass

    # Record to context
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"camel:{agent_name}",
                output={
                    "message_count": len(msgs),
                    "terminated": terminated,
                },
            )
    except Exception:
        pass


def _set_role_playing_result_attributes(span, result, session_name: str) -> None:
    """Set result attributes on the span for a RolePlaying response."""
    # RolePlaying.step returns a tuple: (assistant_response, user_response)
    try:
        if isinstance(result, tuple) and len(result) >= 2:
            assistant_resp, user_resp = result[0], result[1]
            assistant_msgs = getattr(assistant_resp, "msgs", None) or []
            assistant_terminated = getattr(assistant_resp, "terminated", False)
            span.set_attribute("waxell.camel.assistant_message_count", len(assistant_msgs))
            span.set_attribute("waxell.camel.assistant_terminated", assistant_terminated)

            user_msgs = getattr(user_resp, "msgs", None) or []
            user_terminated = getattr(user_resp, "terminated", False)
            span.set_attribute("waxell.camel.user_message_count", len(user_msgs))
            span.set_attribute("waxell.camel.user_terminated", user_terminated)
    except Exception:
        pass

    # Record to context
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"camel_role_playing:{session_name}",
                output={"session": session_name},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
