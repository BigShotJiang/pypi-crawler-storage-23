"""R2R (SciPhi) auto-instrumentor for waxell-observe.

Monkey-patches R2R client methods for search, RAG, and document ingestion
to emit retrieval and step spans.

Patched methods:
  - ``r2r.R2RClient.search``             (retrieval span)
  - ``r2r.R2RClient.rag``                (retrieval span)
  - ``r2r.R2RClient.ingest_documents``   (step span)
  - ``r2r.R2RClient.ingest_files``       (step span)

All wrapper code is wrapped in try/except -- never breaks the user's R2R calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class R2rInstrumentor(BaseInstrumentor):
    """Instrumentor for R2R (SciPhi).

    Patches ``R2RClient.search`` and ``R2RClient.rag`` for retrieval spans,
    and ``R2RClient.ingest_documents`` / ``R2RClient.ingest_files`` for step spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import r2r  # noqa: F401
        except ImportError:
            logger.debug("r2r package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping R2R instrumentation")
            return False

        patched_any = False

        # --- R2RClient.search (sync retrieval) ---
        try:
            wrapt.wrap_function_wrapper(
                "r2r",
                "R2RClient.search",
                _sync_search_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch R2RClient.search: %s", exc)

        # --- R2RClient.rag (sync RAG retrieval) ---
        try:
            wrapt.wrap_function_wrapper(
                "r2r",
                "R2RClient.rag",
                _sync_rag_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch R2RClient.rag: %s", exc)

        # --- R2RClient.ingest_documents (sync ingest) ---
        try:
            wrapt.wrap_function_wrapper(
                "r2r",
                "R2RClient.ingest_documents",
                _sync_ingest_documents_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch R2RClient.ingest_documents: %s", exc)

        # --- R2RClient.ingest_files (sync file ingest) ---
        try:
            wrapt.wrap_function_wrapper(
                "r2r",
                "R2RClient.ingest_files",
                _sync_ingest_files_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch R2RClient.ingest_files: %s", exc)

        # --- Try async variants if available ---
        # R2R may provide async client or async methods
        try:
            wrapt.wrap_function_wrapper(
                "r2r",
                "R2RAsyncClient.search",
                _async_search_wrapper,
            )
        except Exception:
            pass

        try:
            wrapt.wrap_function_wrapper(
                "r2r",
                "R2RAsyncClient.rag",
                _async_rag_wrapper,
            )
        except Exception:
            pass

        if not patched_any:
            logger.debug("Could not patch any R2R methods")
            return False

        self._instrumented = True
        logger.debug("R2R instrumented (search, rag, ingest_documents, ingest_files)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import r2r

            # Restore R2RClient methods
            client_cls = getattr(r2r, "R2RClient", None)
            if client_cls is not None:
                for method_name in ("search", "rag", "ingest_documents", "ingest_files"):
                    method = getattr(client_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(client_cls, method_name, method.__wrapped__)

            # Restore R2RAsyncClient methods
            async_cls = getattr(r2r, "R2RAsyncClient", None)
            if async_cls is not None:
                for method_name in ("search", "rag"):
                    method = getattr(async_cls, method_name, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(async_cls, method_name, method.__wrapped__)

        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("R2R uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the query string from search/rag call args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate a string for span labelling."""
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


def _extract_search_settings(kwargs) -> dict:
    """Extract search settings from R2R call kwargs."""
    settings = {}
    try:
        search_settings = kwargs.get("search_settings") or kwargs.get("vector_search_settings")
        if search_settings is not None:
            if hasattr(search_settings, "search_limit"):
                settings["search_limit"] = int(search_settings.search_limit)
            if hasattr(search_settings, "use_hybrid_search"):
                settings["use_hybrid_search"] = bool(search_settings.use_hybrid_search)
            if hasattr(search_settings, "filters"):
                settings["has_filters"] = search_settings.filters is not None
            # Dict-style settings
            if isinstance(search_settings, dict):
                if "search_limit" in search_settings:
                    settings["search_limit"] = int(search_settings["search_limit"])
                if "use_hybrid_search" in search_settings:
                    settings["use_hybrid_search"] = bool(search_settings["use_hybrid_search"])
    except Exception:
        pass
    return settings


def _extract_result_count(result) -> int:
    """Extract the number of results from an R2R response."""
    try:
        if result is None:
            return 0
        # R2R results typically have a results list
        if hasattr(result, "results") and isinstance(result.results, (list, tuple)):
            return len(result.results)
        if isinstance(result, dict):
            results = result.get("results", [])
            if isinstance(results, (list, tuple)):
                return len(results)
        if isinstance(result, (list, tuple)):
            return len(result)
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for R2RClient.search -- emits retrieval span."""
    query = _extract_query(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)
    search_settings = _extract_search_settings(kwargs)

    try:
        span = start_retrieval_span(query=query_preview, source="r2r")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = _extract_result_count(result)
            span.set_attribute("waxell.retrieval.operation", "search")
            span.set_attribute("waxell.retrieval.results_count", results_count)
            if "search_limit" in search_settings:
                span.set_attribute("waxell.retrieval.search_limit", search_settings["search_limit"])
            if "use_hybrid_search" in search_settings:
                span.set_attribute("waxell.retrieval.use_hybrid_search", search_settings["use_hybrid_search"])
        except Exception as attr_exc:
            logger.debug("Failed to set R2R search span attributes: %s", attr_exc)

        try:
            _record_r2r_retrieval(
                query=query_preview,
                operation="search",
                results_count=results_count if "results_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_rag_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for R2RClient.rag -- emits retrieval span."""
    query = _extract_query(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)
    search_settings = _extract_search_settings(kwargs)

    try:
        span = start_retrieval_span(query=query_preview, source="r2r")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.retrieval.operation", "rag")
            if "search_limit" in search_settings:
                span.set_attribute("waxell.retrieval.search_limit", search_settings["search_limit"])
            if "use_hybrid_search" in search_settings:
                span.set_attribute("waxell.retrieval.use_hybrid_search", search_settings["use_hybrid_search"])

            # Extract document metadata from RAG result
            if result is not None:
                if hasattr(result, "search_results"):
                    results_count = _extract_result_count(result.search_results)
                    span.set_attribute("waxell.retrieval.results_count", results_count)
                if hasattr(result, "completion"):
                    answer_preview = _truncate(str(result.completion), max_len=200)
                    span.set_attribute("waxell.retrieval.answer_preview", answer_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set R2R rag span attributes: %s", attr_exc)

        try:
            _record_r2r_retrieval(query=query_preview, operation="rag")
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_ingest_documents_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for R2RClient.ingest_documents -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract document count
    doc_count = 0
    try:
        documents = args[0] if args else kwargs.get("documents", [])
        if isinstance(documents, (list, tuple)):
            doc_count = len(documents)
    except Exception:
        pass

    try:
        span = start_step_span(step_name="r2r.ingest_documents")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.r2r.operation", "ingest_documents")
            span.set_attribute("waxell.r2r.document_count", doc_count)
        except Exception as attr_exc:
            logger.debug("Failed to set R2R ingest_documents span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "r2r_ingest_documents",
                    output={"document_count": doc_count},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_ingest_files_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for R2RClient.ingest_files -- emits step span."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract file count
    file_count = 0
    try:
        files = args[0] if args else kwargs.get("file_paths", kwargs.get("files", []))
        if isinstance(files, (list, tuple)):
            file_count = len(files)
    except Exception:
        pass

    try:
        span = start_step_span(step_name="r2r.ingest_files")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.r2r.operation", "ingest_files")
            span.set_attribute("waxell.r2r.file_count", file_count)
        except Exception as attr_exc:
            logger.debug("Failed to set R2R ingest_files span attributes: %s", attr_exc)

        try:
            from ._context_var import _current_context

            ctx = _current_context.get()
            if ctx and ctx.run_id:
                ctx.record_step(
                    "r2r_ingest_files",
                    output={"file_count": file_count},
                )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrappers
# ---------------------------------------------------------------------------


async def _async_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for R2RAsyncClient.search -- emits retrieval span."""
    query = _extract_query(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate(query)
    search_settings = _extract_search_settings(kwargs)

    try:
        span = start_retrieval_span(query=query_preview, source="r2r")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = _extract_result_count(result)
            span.set_attribute("waxell.retrieval.operation", "search")
            span.set_attribute("waxell.retrieval.results_count", results_count)
            if "search_limit" in search_settings:
                span.set_attribute("waxell.retrieval.search_limit", search_settings["search_limit"])
        except Exception as attr_exc:
            logger.debug("Failed to set R2R async search span attributes: %s", attr_exc)

        try:
            _record_r2r_retrieval(
                query=query_preview,
                operation="search",
                results_count=results_count if "results_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


async def _async_rag_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for R2RAsyncClient.rag -- emits retrieval span."""
    query = _extract_query(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="r2r")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.retrieval.operation", "rag")
            if result is not None and hasattr(result, "search_results"):
                results_count = _extract_result_count(result.search_results)
                span.set_attribute("waxell.retrieval.results_count", results_count)
        except Exception as attr_exc:
            logger.debug("Failed to set R2R async rag span attributes: %s", attr_exc)

        try:
            _record_r2r_retrieval(query=query_preview, operation="rag")
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_r2r_retrieval(
    query: str,
    operation: str = "search",
    results_count: int = 0,
) -> None:
    """Record an R2R retrieval operation to the context path.

    R2R retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="r2r",
            results_count=results_count,
        )
