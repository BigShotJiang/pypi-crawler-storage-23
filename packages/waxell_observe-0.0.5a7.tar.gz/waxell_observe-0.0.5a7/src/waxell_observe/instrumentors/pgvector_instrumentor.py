"""pgvector auto-instrumentor for waxell-observe.

Monkey-patches psycopg2 and asyncpg cursor execute methods to detect
pgvector operations (using <-> operator or ivfflat/hnsw index queries)
and emit retrieval spans.

Patched methods:
  - ``psycopg2.extensions.cursor.execute``  (retrieval span, pgvector queries only)
  - ``asyncpg.connection.Connection.fetch``  (retrieval span, pgvector queries only)
  - ``asyncpg.connection.Connection.fetchrow``  (retrieval span, pgvector queries only)

Non-pgvector queries are passed through without any span creation.
All wrapper code is wrapped in try/except -- never breaks the user's database calls.
"""

from __future__ import annotations

import logging
import re

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Patterns that indicate a pgvector operation.
# Distance operators: <-> (L2), <=> (cosine), <#> (inner product)
# Index operator classes used in ORDER BY or index hints.
_PGVECTOR_PATTERNS = re.compile(
    r"<->|<=>|<#>"
    r"|vector_cosine_ops"
    r"|vector_l2_ops"
    r"|vector_ip_ops"
    r"|vector_cosine_distance"
    r"|vector_l2_distance"
    r"|vector_ip_distance",
    re.IGNORECASE,
)


def _is_pgvector_query(sql) -> bool:
    """Return True if the SQL string contains pgvector operators or index ops."""
    if not sql or not isinstance(sql, str):
        return False
    return _PGVECTOR_PATTERNS.search(sql) is not None


class PgvectorInstrumentor(BaseInstrumentor):
    """Instrumentor for pgvector operations via psycopg2 and asyncpg.

    Patches cursor execute methods and detects pgvector-specific SQL patterns.
    Only creates retrieval spans for queries that contain pgvector distance
    operators (``<->``, ``<=>``, ``<#>``) or pgvector index operator classes.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        # Check if at least one supported database driver is installed
        has_psycopg2 = False
        has_asyncpg = False

        try:
            import psycopg2  # noqa: F401
            has_psycopg2 = True
        except ImportError:
            pass

        try:
            import asyncpg  # noqa: F401
            has_asyncpg = True
        except ImportError:
            pass

        if not has_psycopg2 and not has_asyncpg:
            logger.debug("Neither psycopg2 nor asyncpg installed -- skipping pgvector instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping pgvector instrumentation")
            return False

        patched_any = False

        # --- psycopg2 sync cursor.execute ---
        if has_psycopg2:
            try:
                wrapt.wrap_function_wrapper(
                    "psycopg2.extensions",
                    "cursor.execute",
                    _sync_execute_wrapper,
                )
                patched_any = True
            except Exception as exc:
                logger.debug("Could not patch psycopg2 cursor.execute: %s", exc)

        # --- asyncpg Connection.fetch ---
        if has_asyncpg:
            try:
                wrapt.wrap_function_wrapper(
                    "asyncpg.connection",
                    "Connection.fetch",
                    _async_fetch_wrapper,
                )
                patched_any = True
            except Exception as exc:
                logger.debug("Could not patch asyncpg Connection.fetch: %s", exc)

            try:
                wrapt.wrap_function_wrapper(
                    "asyncpg.connection",
                    "Connection.fetchrow",
                    _async_fetchrow_wrapper,
                )
                patched_any = True
            except Exception as exc:
                logger.debug("Could not patch asyncpg Connection.fetchrow: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any psycopg2/asyncpg methods for pgvector")
            return False

        self._instrumented = True
        logger.debug("pgvector instrumented (psycopg2=%s, asyncpg=%s)", has_psycopg2, has_asyncpg)
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore psycopg2
        try:
            import psycopg2.extensions
            cursor_cls = psycopg2.extensions.cursor
            method = getattr(cursor_cls, "execute", None)
            if method is not None and hasattr(method, "__wrapped__"):
                cursor_cls.execute = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore asyncpg
        try:
            import asyncpg.connection
            conn_cls = asyncpg.connection.Connection
            for method_name in ("fetch", "fetchrow"):
                method = getattr(conn_cls, method_name, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(conn_cls, method_name, method.__wrapped__)  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("pgvector uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_query(args, kwargs) -> str:
    """Extract the SQL query string from positional or keyword args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", ""))


def _truncate_query(sql: str, max_len: int = 500) -> str:
    """Truncate SQL for span labelling."""
    if len(sql) > max_len:
        return sql[:max_len] + "..."
    return sql


def _detect_distance_op(sql: str) -> str:
    """Detect which pgvector distance operator is used."""
    if "<->" in sql:
        return "l2_distance"
    if "<=>" in sql:
        return "cosine_distance"
    if "<#>" in sql:
        return "inner_product"
    return "unknown"


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrapper (psycopg2)
# ---------------------------------------------------------------------------


def _sync_execute_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for psycopg2 cursor.execute -- only instruments pgvector queries."""
    query = _extract_query(args, kwargs)
    if not _is_pgvector_query(query):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)
    distance_op = _detect_distance_op(query)

    try:
        span = start_retrieval_span(query=query_preview, source="pgvector")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.retrieval.distance_op", distance_op)
            span.set_attribute("db.system", "postgresql")
            span.set_attribute("db.statement", query_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set pgvector execute span attributes: %s", attr_exc)

        try:
            _record_pgvector_retrieval(query=query_preview, distance_op=distance_op)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrappers (asyncpg)
# ---------------------------------------------------------------------------


async def _async_fetch_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for asyncpg Connection.fetch -- only instruments pgvector queries."""
    query = _extract_query(args, kwargs)
    if not _is_pgvector_query(query):
        return await wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)
    distance_op = _detect_distance_op(query)

    try:
        span = start_retrieval_span(query=query_preview, source="pgvector")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = len(response) if response is not None else 0
            span.set_attribute("waxell.retrieval.results_count", results_count)
            span.set_attribute("waxell.retrieval.distance_op", distance_op)
            span.set_attribute("db.system", "postgresql")
            span.set_attribute("db.statement", query_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set pgvector fetch span attributes: %s", attr_exc)

        try:
            _record_pgvector_retrieval(
                query=query_preview,
                distance_op=distance_op,
                results_count=results_count if 'results_count' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_fetchrow_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for asyncpg Connection.fetchrow -- only instruments pgvector queries."""
    query = _extract_query(args, kwargs)
    if not _is_pgvector_query(query):
        return await wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return await wrapped(*args, **kwargs)

    query_preview = _truncate_query(query)
    distance_op = _detect_distance_op(query)

    try:
        span = start_retrieval_span(query=query_preview, source="pgvector")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = 1 if response is not None else 0
            span.set_attribute("waxell.retrieval.results_count", results_count)
            span.set_attribute("waxell.retrieval.distance_op", distance_op)
            span.set_attribute("db.system", "postgresql")
            span.set_attribute("db.statement", query_preview)
        except Exception as attr_exc:
            logger.debug("Failed to set pgvector fetchrow span attributes: %s", attr_exc)

        try:
            _record_pgvector_retrieval(
                query=query_preview,
                distance_op=distance_op,
                results_count=results_count if 'results_count' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_pgvector_retrieval(
    query: str,
    distance_op: str,
    results_count: int = 0,
) -> None:
    """Record a pgvector retrieval operation to the context path.

    pgvector retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="pgvector",
            results_count=results_count,
        )
