"""Cartesia TTS auto-instrumentor for waxell-observe.

Monkey-patches Cartesia SDK methods to emit OTel step spans for
text-to-speech operations:
  - ``Cartesia.tts.bytes``       -- sync (returns audio bytes)
  - ``Cartesia.tts.sse``         -- sync streaming (server-sent events)
  - ``AsyncCartesia.tts.bytes``  -- async (if available)

The Cartesia Python SDK (``cartesia``) client methods accept:
  - ``model_id`` (str) -- the model to use
  - ``voice_id`` (str) -- the voice to use (or ``voice`` dict with ``id``)
  - ``transcript`` (str) -- input text to synthesize
  - ``output_format`` (dict) -- e.g. {"container": "raw", "encoding": "pcm_f32le", "sample_rate": 44100}

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class CartesiaInstrumentor(BaseInstrumentor):
    """Instrumentor for the Cartesia Python SDK (``cartesia`` package).

    Patches ``Cartesia.tts.bytes``, ``Cartesia.tts.sse``, and
    ``AsyncCartesia.tts.bytes`` (if available).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import cartesia  # noqa: F401
        except ImportError:
            logger.debug("cartesia package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Cartesia instrumentation")
            return False

        patched = False

        # Patch Cartesia.tts.bytes (sync)
        try:
            wrapt.wrap_function_wrapper(
                "cartesia.tts",
                "TTS.bytes",
                _sync_tts_bytes_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Cartesia TTS bytes: %s", exc)

        # Patch Cartesia.tts.sse (sync streaming)
        try:
            wrapt.wrap_function_wrapper(
                "cartesia.tts",
                "TTS.sse",
                _sync_tts_sse_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Cartesia TTS sse: %s", exc)

        # Patch AsyncCartesia.tts.bytes (async) -- if available
        try:
            wrapt.wrap_function_wrapper(
                "cartesia.tts",
                "AsyncTTS.bytes",
                _async_tts_bytes_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Cartesia async TTS bytes: %s", exc)

        # Patch AsyncCartesia.tts.sse (async streaming) -- if available
        try:
            wrapt.wrap_function_wrapper(
                "cartesia.tts",
                "AsyncTTS.sse",
                _async_tts_sse_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Cartesia async TTS sse: %s", exc)

        if not patched:
            logger.debug("Could not find any Cartesia TTS methods to patch")
            return False

        self._instrumented = True
        logger.debug("Cartesia TTS instrumented (bytes + sse, sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from cartesia import tts as tts_module

            for cls_name in ("TTS", "AsyncTTS"):
                cls = getattr(tts_module, cls_name, None)
                if cls is None:
                    continue
                for attr in ("bytes", "sse"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Cartesia TTS uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_tts_bytes_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Cartesia ``TTS.bytes``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_id, voice_id, text_length, output_format = _extract_params(args, kwargs)

    try:
        span = start_step_span(step_name="cartesia.tts.generate")
        _set_request_attrs(span, model_id, voice_id, text_length, output_format)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.cartesia.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("cartesia.tts.bytes", model_id, voice_id, text_length, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_tts_sse_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Cartesia ``TTS.sse`` (streaming)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    model_id, voice_id, text_length, output_format = _extract_params(args, kwargs)

    try:
        span = start_step_span(step_name="cartesia.tts.generate")
        _set_request_attrs(span, model_id, voice_id, text_length, output_format)
        span.set_attribute("waxell.cartesia.streaming", True)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.cartesia.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("cartesia.tts.sse", model_id, voice_id, text_length, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_tts_bytes_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Cartesia ``AsyncTTS.bytes``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model_id, voice_id, text_length, output_format = _extract_params(args, kwargs)

    try:
        span = start_step_span(step_name="cartesia.tts.generate")
        _set_request_attrs(span, model_id, voice_id, text_length, output_format)
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.cartesia.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("cartesia.tts.bytes", model_id, voice_id, text_length, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_tts_sse_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Cartesia ``AsyncTTS.sse`` (streaming)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model_id, voice_id, text_length, output_format = _extract_params(args, kwargs)

    try:
        span = start_step_span(step_name="cartesia.tts.generate")
        _set_request_attrs(span, model_id, voice_id, text_length, output_format)
        span.set_attribute("waxell.cartesia.streaming", True)
    except Exception:
        return await wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            span.set_attribute("waxell.cartesia.latency_ms", round(latency * 1000, 2))
        except Exception:
            pass

        try:
            _record_tts_call("cartesia.tts.sse", model_id, voice_id, text_length, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Parameter extraction helpers
# ---------------------------------------------------------------------------


def _extract_params(args, kwargs) -> tuple:
    """Extract model_id, voice_id, text_length, output_format from Cartesia TTS args.

    The Cartesia SDK methods typically accept keyword arguments:
      - model_id (str)
      - voice_id (str) or voice (dict with "id" key)
      - transcript (str) -- the text to synthesize
      - output_format (dict) -- e.g. {"container": "raw", ...}
    """
    model_id = ""
    voice_id = ""
    text_length = 0
    output_format = ""

    try:
        model_id = str(kwargs.get("model_id", ""))

        # voice_id can be a string or inside a voice dict
        voice_id = str(kwargs.get("voice_id", ""))
        if not voice_id:
            voice = kwargs.get("voice", None)
            if isinstance(voice, dict):
                voice_id = str(voice.get("id", ""))
            elif isinstance(voice, str):
                voice_id = voice

        transcript = kwargs.get("transcript", "")
        text_length = len(str(transcript)) if transcript else 0

        fmt = kwargs.get("output_format", None)
        if isinstance(fmt, dict):
            output_format = fmt.get("container", "")
            if not output_format:
                output_format = str(fmt)
        elif fmt is not None:
            output_format = str(fmt)
    except Exception:
        pass

    return str(model_id), str(voice_id), text_length, str(output_format)


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_request_attrs(
    span, model_id: str, voice_id: str, text_length: int, output_format: str
) -> None:
    """Set request attributes for a Cartesia TTS span."""
    if model_id:
        span.set_attribute("waxell.cartesia.model_id", model_id)
    if voice_id:
        span.set_attribute("waxell.cartesia.voice_id", voice_id)
    if text_length:
        span.set_attribute("waxell.cartesia.text_length", text_length)
    if output_format:
        span.set_attribute("waxell.cartesia.output_format", output_format)


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tts_call(
    task: str, model_id: str, voice_id: str, text_length: int, latency: float
) -> None:
    """Record a Cartesia TTS call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model_id or "cartesia-tts",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[tts text_length={text_length} voice={voice_id}]",
        "response_preview": f"[tts voice={voice_id} latency={latency * 1000:.0f}ms]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
