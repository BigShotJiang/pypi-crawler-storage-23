"""Shared data types for waxell-observe."""

from dataclasses import dataclass, field


@dataclass
class RunInfo:
    """Information about a started execution run."""

    run_id: str
    workflow_id: str
    started_at: str


@dataclass
class PolicyCheckResult:
    """Result of a policy check against the controlplane."""

    action: str  # "allow", "block", "warn", "throttle", "retry"
    reason: str = ""
    metadata: dict = field(default_factory=dict)
    evaluations: list = field(default_factory=list)

    @property
    def allowed(self) -> bool:
        return self.action in ("allow", "warn")

    @property
    def blocked(self) -> bool:
        return self.action in ("block", "throttle")

    @property
    def should_retry(self) -> bool:
        return self.action == "retry"


@dataclass
class RunCompleteResult:
    """Result from completing a run, including governance info."""

    run_id: str
    duration: float | None = None
    governance_action: str = "allow"
    governance_reason: str = ""
    retry_feedback: str = ""
    max_retries: int = 0

    @property
    def should_retry(self) -> bool:
        return self.governance_action == "retry"


@dataclass
class LlmCallInfo:
    """Information about an LLM API call."""

    model: str
    tokens_in: int
    tokens_out: int
    cost: float = 0.0
    task: str = ""
    prompt_preview: str = ""
    response_preview: str = ""


@dataclass
class PromptInfo:
    """A prompt version retrieved from the controlplane."""

    name: str
    version: int
    prompt_type: str  # "text" or "chat"
    content: object  # str for text, list[dict] for chat
    config: dict = field(default_factory=dict)
    labels: list = field(default_factory=list)

    def compile(self, **variables: str) -> object:
        """Render the prompt with template variables.

        Replaces ``{{variable}}`` placeholders in the content.
        For text prompts, returns a string.
        For chat prompts, returns a list of messages with variables replaced.
        """
        if isinstance(self.content, str):
            result = self.content
            for key, value in variables.items():
                result = result.replace("{{" + key + "}}", value)
            return result
        elif isinstance(self.content, list):
            messages = []
            for msg in self.content:
                rendered = dict(msg)
                if "content" in rendered and isinstance(rendered["content"], str):
                    for key, value in variables.items():
                        rendered["content"] = rendered["content"].replace(
                            "{{" + key + "}}", value
                        )
                messages.append(rendered)
            return messages
        return self.content


@dataclass
class PromptGuardResult:
    """Result of a prompt guard check before an LLM call."""

    passed: bool
    action: str = "allow"  # "allow", "warn", "block", "redact"
    violations: list[str] = field(default_factory=list)
    source: str = "local"  # "local", "server", "both"
    redacted_messages: list | None = None  # Only set when action="redact"
