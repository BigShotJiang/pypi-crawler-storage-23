"""Configuration for waxell-observe.

Resolution priority (highest to lowest):
1. Explicit constructor arguments
2. Global config (WaxellObserveClient.configure())
3. CLI config file (~/.waxell/config)
4. Environment variables (WAXELL_API_URL/WAXELL_API_KEY, WAX_API_URL/WAX_API_KEY)
"""

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_PATH = Path.home() / ".waxell" / "config"


@dataclass
class ObserveConfig:
    """Configuration for the Waxell Observe client."""

    api_url: str = ""
    api_key: str = ""
    otel_endpoint: str = ""
    debug: bool = False
    capture_content: bool = False
    prompt_guard: bool = False
    prompt_guard_server: bool = False
    prompt_guard_action: str = "block"  # "block", "warn", "redact"
    instrument_infra: bool = True
    infra_exclude: str = ""  # Comma-delimited list of libraries to exclude

    @classmethod
    def from_env(cls) -> "ObserveConfig":
        """Load configuration from environment variables."""
        return cls(
            api_url=os.environ.get(
                "WAXELL_API_URL", os.environ.get("WAX_API_URL", "")
            ),
            api_key=os.environ.get(
                "WAXELL_API_KEY", os.environ.get("WAX_API_KEY", "")
            ),
            otel_endpoint=os.environ.get("WAXELL_OTEL_ENDPOINT", ""),
            debug=os.environ.get("WAXELL_DEBUG", "").lower() in ("true", "1", "yes"),
            capture_content=os.environ.get("WAXELL_CAPTURE_CONTENT", "").lower()
            in ("true", "1", "yes"),
            prompt_guard=os.environ.get("WAXELL_PROMPT_GUARD", "").lower()
            in ("true", "1", "yes"),
            prompt_guard_server=os.environ.get(
                "WAXELL_PROMPT_GUARD_SERVER", ""
            ).lower()
            in ("true", "1", "yes"),
            prompt_guard_action=os.environ.get(
                "WAXELL_PROMPT_GUARD_ACTION", "block"
            ).lower(),
            instrument_infra=os.environ.get(
                "WAXELL_INSTRUMENT_INFRA", ""
            ).lower()
            not in ("false", "0", "no"),
            infra_exclude=os.environ.get("WAXELL_INFRA_EXCLUDE", ""),
        )

    @classmethod
    def from_cli_config(cls, config_path: Optional[Path] = None) -> "ObserveConfig":
        """Load configuration from CLI config file (~/.waxell/config)."""
        path = config_path or DEFAULT_CONFIG_PATH

        if not path.exists():
            return cls()

        try:
            import configparser

            config = configparser.ConfigParser()
            config.read(path)

            section = "default" if config.has_section("default") else (
                config.sections()[0] if config.sections() else None
            )

            if not section:
                return cls()

            return cls(
                api_url=config.get(section, "api_url", fallback=""),
                api_key=config.get(section, "api_key", fallback=""),
                otel_endpoint=config.get(section, "otel_endpoint", fallback=""),
                debug=config.get(section, "debug", fallback="").lower()
                in ("true", "1", "yes"),
                capture_content=config.get(
                    section, "capture_content", fallback=""
                ).lower()
                in ("true", "1", "yes"),
                prompt_guard=config.get(
                    section, "prompt_guard", fallback=""
                ).lower()
                in ("true", "1", "yes"),
                prompt_guard_server=config.get(
                    section, "prompt_guard_server", fallback=""
                ).lower()
                in ("true", "1", "yes"),
                prompt_guard_action=config.get(
                    section, "prompt_guard_action", fallback="block"
                ).lower(),
                instrument_infra=config.get(
                    section, "instrument_infra", fallback=""
                ).lower()
                not in ("false", "0", "no"),
                infra_exclude=config.get(
                    section, "infra_exclude", fallback=""
                ),
            )
        except Exception as e:
            logger.debug(f"Could not read CLI config from {path}: {e}")
            return cls()

    @property
    def is_configured(self) -> bool:
        """Check if the client is properly configured."""
        return bool(self.api_url and self.api_key)
