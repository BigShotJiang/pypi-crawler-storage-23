"""Errors raised by waxell-observe."""


class ObserveError(Exception):
    """Base error for waxell-observe."""

    pass


class PolicyViolationError(ObserveError):
    """Raised when a policy check blocks execution."""

    def __init__(self, message: str, policy_result=None):
        super().__init__(message)
        self.policy_result = policy_result


class ConfigurationError(ObserveError):
    """Raised when the client is not properly configured."""

    pass
