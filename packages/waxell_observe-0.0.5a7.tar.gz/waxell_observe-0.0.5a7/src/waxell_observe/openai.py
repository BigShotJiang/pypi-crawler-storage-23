"""Drop-in OpenAI wrapper with automatic Waxell instrumentation.

Usage::

    from waxell_observe.openai import openai

    # Every call is now automatically traced:
    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello!"}],
    )

This is equivalent to calling ``waxell.init()`` and then using the
``openai`` module normally, but scoped to a single import.
"""

from __future__ import annotations

import openai as _openai  # type: ignore[import-untyped]

from waxell_observe.instrumentors import instrument_all

# Instrument OpenAI on import — idempotent if already instrumented.
instrument_all(libraries=["openai"])

# Re-export the real module so callers get the (now-patched) openai.
openai = _openai

__all__ = ["openai"]
