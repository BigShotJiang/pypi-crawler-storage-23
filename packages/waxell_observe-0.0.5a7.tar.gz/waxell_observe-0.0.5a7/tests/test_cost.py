"""Unit tests for waxell_observe.cost.estimate_cost()."""

import pytest

from waxell_observe.cost import MODEL_COSTS, estimate_cost


class TestEstimateCost:
    def test_exact_match_gpt4o(self):
        """Exact match for gpt-4o model pricing."""
        cost = estimate_cost("gpt-4o", 1000, 500)
        expected = (1000 * 2.50 / 1_000_000) + (500 * 10.00 / 1_000_000)
        assert cost == pytest.approx(expected)

    def test_exact_match_claude_sonnet(self):
        """Exact match for claude-sonnet-4 model pricing."""
        cost = estimate_cost("claude-sonnet-4", 2000, 1000)
        expected = (2000 * 3.00 / 1_000_000) + (1000 * 15.00 / 1_000_000)
        assert cost == pytest.approx(expected)

    def test_prefix_match_versioned_model(self):
        """Versioned model name falls back to prefix match."""
        cost = estimate_cost("gpt-4o-2024-08-06", 1000, 500)
        expected = (1000 * 2.50 / 1_000_000) + (500 * 10.00 / 1_000_000)
        assert cost == pytest.approx(expected)

    def test_unknown_model_returns_zero(self):
        """Unknown model returns 0.0."""
        cost = estimate_cost("unknown-model-xyz", 1000, 500)
        assert cost == 0.0

    def test_zero_tokens(self):
        """Zero tokens returns 0.0 cost."""
        cost = estimate_cost("gpt-4o", 0, 0)
        assert cost == 0.0

    def test_all_known_models_have_costs(self):
        """Every model in MODEL_COSTS produces a non-zero cost for non-zero tokens (except free/local)."""
        _FREE_MODELS = {"vllm"}  # Local inference models with zero cost
        for model in MODEL_COSTS:
            cost = estimate_cost(model, 100, 100)
            if model in _FREE_MODELS:
                assert cost == 0.0, f"Free model {model} should have zero cost"
            else:
                assert cost > 0, f"Model {model} should have a positive cost"

    def test_prefix_match_prefers_longer_prefix(self):
        """gpt-4o-mini should match gpt-4o-mini, not gpt-4o."""
        cost_mini = estimate_cost("gpt-4o-mini", 1000, 500)
        expected_mini = (1000 * 0.15 / 1_000_000) + (500 * 0.60 / 1_000_000)
        assert cost_mini == pytest.approx(expected_mini)

        # Verify it did NOT use gpt-4o pricing
        cost_4o = estimate_cost("gpt-4o", 1000, 500)
        assert cost_mini != pytest.approx(cost_4o)
