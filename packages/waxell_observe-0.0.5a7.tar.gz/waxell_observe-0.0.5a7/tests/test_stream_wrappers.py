"""Tests for streaming token accumulation wrappers.

Verifies that OpenAI, Anthropic, Gemini, Cohere, and Bedrock stream wrappers:
  1. Proxy all chunks/events unchanged (transparent)
  2. Accumulate content from stream fragments
  3. Capture token usage data
  4. Record to OTel span on stream completion
  5. Support context manager protocol
  6. Never break on errors (all recording in try/except)
  7. Record to HTTP path (WaxellContext or collector)
"""

import asyncio
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Mock stream helpers
# ---------------------------------------------------------------------------


def _make_openai_chunks(
    texts=("Hello", " world"),
    prompt_tokens=10,
    completion_tokens=5,
    finish_reason="stop",
):
    """Build a list of mock OpenAI ChatCompletionChunk objects."""
    chunks = []
    for text in texts:
        delta = SimpleNamespace(content=text, role=None, tool_calls=None)
        choice = SimpleNamespace(delta=delta, finish_reason=None, index=0)
        chunk = SimpleNamespace(choices=[choice], usage=None)
        chunks.append(chunk)

    # Final chunk with finish_reason
    delta = SimpleNamespace(content=None, role=None, tool_calls=None)
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason, index=0)
    usage = SimpleNamespace(prompt_tokens=prompt_tokens, completion_tokens=completion_tokens)
    final_chunk = SimpleNamespace(choices=[choice], usage=usage)
    chunks.append(final_chunk)
    return chunks


def _make_anthropic_events(
    texts=("Hello", " world"),
    input_tokens=15,
    output_tokens=8,
    model="claude-sonnet-4-20250514",
    stop_reason="end_turn",
):
    """Build a list of mock Anthropic stream events."""
    events = []

    # message_start
    usage = SimpleNamespace(input_tokens=input_tokens)
    message = SimpleNamespace(usage=usage, model=model)
    events.append(SimpleNamespace(type="message_start", message=message))

    # content_block_start (optional, not processed)
    events.append(SimpleNamespace(type="content_block_start", index=0))

    # content_block_delta for each text part
    for text in texts:
        delta = SimpleNamespace(text=text, type="text_delta")
        events.append(SimpleNamespace(type="content_block_delta", delta=delta, index=0))

    # content_block_stop
    events.append(SimpleNamespace(type="content_block_stop", index=0))

    # message_delta with output tokens
    usage = SimpleNamespace(output_tokens=output_tokens)
    delta = SimpleNamespace(stop_reason=stop_reason)
    events.append(SimpleNamespace(type="message_delta", delta=delta, usage=usage))

    # message_stop
    events.append(SimpleNamespace(type="message_stop"))

    return events


def _make_gemini_chunks(
    texts=("Hello", " world"),
    prompt_token_count=10,
    candidates_token_count=5,
    finish_reason_name="STOP",
):
    """Build a list of mock Gemini GenerateContentResponse-like objects."""
    chunks = []
    for text in texts:
        chunk = SimpleNamespace(
            text=text,
            usage_metadata=None,
            candidates=[],
        )
        chunks.append(chunk)

    # Final chunk with usage and finish reason
    finish_reason = SimpleNamespace(name=finish_reason_name)
    candidate = SimpleNamespace(finish_reason=finish_reason)
    usage_meta = SimpleNamespace(
        prompt_token_count=prompt_token_count,
        candidates_token_count=candidates_token_count,
    )
    final_chunk = SimpleNamespace(
        text=None,
        usage_metadata=usage_meta,
        candidates=[candidate],
    )
    chunks.append(final_chunk)
    return chunks


def _make_cohere_events(
    texts=("Hello", " world"),
    input_tokens=12,
    output_tokens=6,
    finish_reason="COMPLETE",
):
    """Build a list of mock Cohere V2 stream events."""
    events = []

    # content-delta events
    for text in texts:
        content = SimpleNamespace(text=text)
        message = SimpleNamespace(content=content)
        delta = SimpleNamespace(message=message)
        events.append(SimpleNamespace(type="content-delta", delta=delta))

    # message-end event with usage
    billed_units = SimpleNamespace(input_tokens=input_tokens, output_tokens=output_tokens)
    usage = SimpleNamespace(billed_units=billed_units)
    end_delta = SimpleNamespace(finish_reason=finish_reason, usage=usage)
    events.append(SimpleNamespace(type="message-end", delta=end_delta))

    return events


def _make_bedrock_events(
    texts=("Hello", " world"),
    input_tokens=20,
    output_tokens=8,
    stop_reason="end_turn",
):
    """Build a list of mock Bedrock ConverseStream dict-keyed events."""
    events = []

    # contentBlockDelta events
    for text in texts:
        events.append({
            "contentBlockDelta": {
                "delta": {"text": text},
                "contentBlockIndex": 0,
            }
        })

    # messageStop event
    events.append({
        "messageStop": {"stopReason": stop_reason}
    })

    # metadata event with usage
    events.append({
        "metadata": {
            "usage": {
                "inputTokens": input_tokens,
                "outputTokens": output_tokens,
            }
        }
    })

    return events


class MockSyncStream:
    """Simulates a sync stream (iterable) with optional context manager."""

    def __init__(self, items):
        self._items = iter(items)
        self._entered = False
        self._exited = False

    def __iter__(self):
        return self

    def __next__(self):
        return next(self._items)

    def __enter__(self):
        self._entered = True
        return self

    def __exit__(self, *args):
        self._exited = True
        return None


class MockAsyncStream:
    """Simulates an async stream (async iterable) with async context manager."""

    def __init__(self, items):
        self._items = iter(items)
        self._entered = False
        self._exited = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            return next(self._items)
        except StopIteration:
            raise StopAsyncIteration

    async def __aenter__(self):
        self._entered = True
        return self

    async def __aexit__(self, *args):
        self._exited = True
        return None


# ---------------------------------------------------------------------------
# OpenAI sync stream wrapper tests
# ---------------------------------------------------------------------------


class TestOpenAISyncStreamWrapper:
    def test_yields_all_chunks_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        chunks = _make_openai_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        collected = list(wrapper)

        assert collected == chunks
        assert len(collected) == 3  # 2 content + 1 final

    def test_accumulates_content(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        chunks = _make_openai_chunks(texts=("Hello", " ", "world"))
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        list(wrapper)  # consume stream

        assert "".join(wrapper._content_parts) == "Hello world"

    def test_captures_usage_from_final_chunk(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        chunks = _make_openai_chunks(prompt_tokens=42, completion_tokens=17)
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        list(wrapper)

        assert wrapper._usage is not None
        assert wrapper._usage.prompt_tokens == 42
        assert wrapper._usage.completion_tokens == 17

    def test_records_span_attributes_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        chunks = _make_openai_chunks(prompt_tokens=100, completion_tokens=50)
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        list(wrapper)

        # Span should have been ended
        span.end.assert_called_once()

        # Span should have token attributes set
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.usage.input_tokens") == 100
        assert calls.get("gen_ai.usage.output_tokens") == 50
        assert calls.get("waxell.llm.input_tokens") == 100
        assert calls.get("waxell.llm.output_tokens") == 50
        assert calls.get("waxell.llm.total_tokens") == 150

    def test_context_manager_protocol(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        chunks = _make_openai_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        with wrapper as w:
            collected = list(w)

        assert mock_stream._entered
        assert mock_stream._exited
        assert len(collected) == 3
        span.end.assert_called_once()

    def test_finalize_only_once(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        chunks = _make_openai_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        # Consume via iteration (triggers finalize via StopIteration)
        with wrapper as w:
            list(w)
        # __exit__ also calls _on_stream_end, but finalized guard prevents double

        assert span.end.call_count == 1

    def test_captures_finish_reason(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        chunks = _make_openai_chunks(finish_reason="length")
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        list(wrapper)

        assert wrapper._finish_reason == "length"
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.response.finish_reasons") == ["length"]

    def test_no_usage_records_zero_tokens(self):
        """If no usage chunk is received, tokens default to 0."""
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        # Build chunks without usage on final chunk
        delta = SimpleNamespace(content="Hi", role=None, tool_calls=None)
        choice = SimpleNamespace(delta=delta, finish_reason="stop", index=0)
        chunk = SimpleNamespace(choices=[choice], usage=None)
        mock_stream = MockSyncStream([chunk])
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        list(wrapper)

        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("waxell.llm.input_tokens") == 0
        assert calls.get("waxell.llm.output_tokens") == 0

    def test_proxy_attribute_access(self):
        """Wrapper proxies attribute access to the underlying stream."""
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        mock_stream = MagicMock()
        mock_stream.response = SimpleNamespace(status_code=200)
        span = MagicMock()

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        assert wrapper.response.status_code == 200


# ---------------------------------------------------------------------------
# OpenAI async stream wrapper tests
# ---------------------------------------------------------------------------


class TestOpenAIAsyncStreamWrapper:
    def test_yields_all_chunks_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAIAsyncStreamWrapper

        chunks = _make_openai_chunks()
        mock_stream = MockAsyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAIAsyncStreamWrapper(mock_stream, span, "gpt-4o")

        async def consume():
            return [chunk async for chunk in wrapper]

        collected = asyncio.run(consume())
        assert collected == chunks

    def test_records_span_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAIAsyncStreamWrapper

        chunks = _make_openai_chunks(prompt_tokens=200, completion_tokens=100)
        mock_stream = MockAsyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAIAsyncStreamWrapper(mock_stream, span, "gpt-4o")

        async def consume():
            return [chunk async for chunk in wrapper]

        asyncio.run(consume())

        span.end.assert_called_once()
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("waxell.llm.total_tokens") == 300

    def test_async_context_manager(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAIAsyncStreamWrapper

        chunks = _make_openai_chunks()
        mock_stream = MockAsyncStream(chunks)
        span = MagicMock()

        wrapper = OpenAIAsyncStreamWrapper(mock_stream, span, "gpt-4o")

        async def consume():
            async with wrapper as w:
                return [chunk async for chunk in w]

        collected = asyncio.run(consume())
        assert mock_stream._entered
        assert mock_stream._exited
        assert len(collected) == 3


# ---------------------------------------------------------------------------
# Anthropic sync stream wrapper tests
# ---------------------------------------------------------------------------


class TestAnthropicSyncStreamWrapper:
    def test_yields_all_events_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        collected = list(wrapper)

        assert collected == events

    def test_captures_input_tokens_from_message_start(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events(input_tokens=500)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        list(wrapper)

        assert wrapper._input_tokens == 500

    def test_captures_output_tokens_from_message_delta(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events(output_tokens=250)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        list(wrapper)

        assert wrapper._output_tokens == 250

    def test_accumulates_content_from_deltas(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events(texts=("Once", " upon", " a", " time"))
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        list(wrapper)

        assert "".join(wrapper._content_parts) == "Once upon a time"

    def test_records_span_attributes_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events(input_tokens=100, output_tokens=50)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        list(wrapper)

        span.end.assert_called_once()
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.usage.input_tokens") == 100
        assert calls.get("gen_ai.usage.output_tokens") == 50
        assert calls.get("waxell.llm.total_tokens") == 150

    def test_captures_model_from_message_start(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events(model="claude-opus-4-20250514")
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        list(wrapper)

        # Model should be updated from message_start
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("waxell.llm.model") == "claude-opus-4-20250514"

    def test_captures_stop_reason(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events(stop_reason="max_tokens")
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        list(wrapper)

        assert wrapper._stop_reason == "max_tokens"
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.response.finish_reasons") == ["max_tokens"]

    def test_context_manager_protocol(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        with wrapper as w:
            collected = list(w)

        assert mock_stream._entered
        assert mock_stream._exited
        span.end.assert_called_once()


# ---------------------------------------------------------------------------
# Anthropic async stream wrapper tests
# ---------------------------------------------------------------------------


class TestAnthropicAsyncStreamWrapper:
    def test_yields_all_events_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicAsyncStreamWrapper

        events = _make_anthropic_events()
        mock_stream = MockAsyncStream(events)
        span = MagicMock()

        wrapper = AnthropicAsyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")

        async def consume():
            return [event async for event in wrapper]

        collected = asyncio.run(consume())
        assert collected == events

    def test_records_span_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicAsyncStreamWrapper

        events = _make_anthropic_events(input_tokens=300, output_tokens=150)
        mock_stream = MockAsyncStream(events)
        span = MagicMock()

        wrapper = AnthropicAsyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")

        async def consume():
            return [event async for event in wrapper]

        asyncio.run(consume())

        span.end.assert_called_once()
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("waxell.llm.total_tokens") == 450


# ---------------------------------------------------------------------------
# OpenAI stream_options injection test
# ---------------------------------------------------------------------------


class TestInjectStreamOptions:
    def test_injects_when_not_set(self):
        from waxell_observe.instrumentors.openai_instrumentor import _inject_stream_options

        kwargs = {"model": "gpt-4o", "stream": True}
        result = _inject_stream_options(kwargs)
        assert result["stream_options"] == {"include_usage": True}

    def test_preserves_existing_include_usage(self):
        from waxell_observe.instrumentors.openai_instrumentor import _inject_stream_options

        kwargs = {"stream_options": {"include_usage": False}}
        result = _inject_stream_options(kwargs)
        # Should NOT override explicit user setting
        assert result["stream_options"]["include_usage"] is False

    def test_adds_to_existing_dict(self):
        from waxell_observe.instrumentors.openai_instrumentor import _inject_stream_options

        kwargs = {"stream_options": {"other_option": True}}
        result = _inject_stream_options(kwargs)
        assert result["stream_options"]["include_usage"] is True
        assert result["stream_options"]["other_option"] is True

    def test_handles_non_dict_stream_options(self):
        from waxell_observe.instrumentors.openai_instrumentor import _inject_stream_options

        # If someone passes a non-dict (edge case), don't crash
        kwargs = {"stream_options": "invalid"}
        result = _inject_stream_options(kwargs)
        # Non-dict is left as-is
        assert result["stream_options"] == "invalid"


# ---------------------------------------------------------------------------
# HTTP dual-path recording from stream wrappers
# ---------------------------------------------------------------------------


class TestStreamHTTPRecording:
    def test_records_to_context_when_active(self):
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper
        from waxell_observe.instrumentors._context_var import _current_context

        chunks = _make_openai_chunks(prompt_tokens=10, completion_tokens=5)
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        mock_ctx = MagicMock()
        mock_ctx.run_id = "test-run-123"

        token = _current_context.set(mock_ctx)
        try:
            wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
            list(wrapper)
        finally:
            _current_context.reset(token)

        mock_ctx.record_llm_call.assert_called_once()
        call_kwargs = mock_ctx.record_llm_call.call_args
        assert call_kwargs[1]["model"] == "gpt-4o"
        assert call_kwargs[1]["tokens_in"] == 10
        assert call_kwargs[1]["tokens_out"] == 5

    def test_records_to_collector_when_no_context(self):
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper
        from waxell_observe.instrumentors._context_var import _current_context

        events = _make_anthropic_events(input_tokens=20, output_tokens=10)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        mock_collector = MagicMock()

        # Ensure no context is active
        token = _current_context.set(None)
        try:
            with patch(
                "waxell_observe.instrumentors._collector._collector",
                mock_collector,
            ):
                wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
                list(wrapper)
        finally:
            _current_context.reset(token)

        mock_collector.record_call.assert_called_once()
        call_data = mock_collector.record_call.call_args[0][0]
        assert call_data["tokens_in"] == 20
        assert call_data["tokens_out"] == 10


# ---------------------------------------------------------------------------
# Error resilience tests
# ---------------------------------------------------------------------------


class TestStreamErrorResilience:
    def test_span_error_does_not_break_stream(self):
        """If span.set_attribute raises, chunks are still yielded."""
        from waxell_observe.instrumentors._stream_wrappers import OpenAISyncStreamWrapper

        chunks = _make_openai_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()
        span.set_attribute.side_effect = Exception("OTel broken")

        wrapper = OpenAISyncStreamWrapper(mock_stream, span, "gpt-4o")
        collected = list(wrapper)

        # All chunks should still be yielded
        assert len(collected) == 3

    def test_finalize_error_does_not_propagate(self):
        """If _on_stream_end fails internally, no exception propagates."""
        from waxell_observe.instrumentors._stream_wrappers import AnthropicSyncStreamWrapper

        events = _make_anthropic_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()
        span.set_attribute.side_effect = Exception("boom")
        span.end.side_effect = Exception("double boom")

        wrapper = AnthropicSyncStreamWrapper(mock_stream, span, "claude-sonnet-4-20250514")
        # Should NOT raise
        collected = list(wrapper)
        assert len(collected) == len(events)


# ---------------------------------------------------------------------------
# Gemini sync stream wrapper tests
# ---------------------------------------------------------------------------


class TestGeminiSyncStreamWrapper:
    def test_yields_all_chunks_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        collected = list(wrapper)

        assert collected == chunks
        assert len(collected) == 3  # 2 content + 1 final

    def test_accumulates_content(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks(texts=("Hello", " ", "world"))
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        list(wrapper)

        assert "".join(wrapper._content_parts) == "Hello world"

    def test_captures_usage_from_final_chunk(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks(prompt_token_count=42, candidates_token_count=17)
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        list(wrapper)

        assert wrapper._tokens_in == 42
        assert wrapper._tokens_out == 17

    def test_records_span_attributes_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks(prompt_token_count=100, candidates_token_count=50)
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        list(wrapper)

        span.end.assert_called_once()
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.usage.input_tokens") == 100
        assert calls.get("gen_ai.usage.output_tokens") == 50
        assert calls.get("waxell.llm.input_tokens") == 100
        assert calls.get("waxell.llm.output_tokens") == 50
        assert calls.get("waxell.llm.total_tokens") == 150

    def test_context_manager_protocol(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        with wrapper as w:
            collected = list(w)

        assert mock_stream._entered
        assert mock_stream._exited
        assert len(collected) == 3
        span.end.assert_called_once()

    def test_finalize_only_once(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        with wrapper as w:
            list(w)

        assert span.end.call_count == 1

    def test_captures_finish_reason(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks(finish_reason_name="MAX_TOKENS")
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        list(wrapper)

        assert wrapper._finish_reason == "MAX_TOKENS"
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.response.finish_reasons") == ["MAX_TOKENS"]

    def test_proxy_attribute_access(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        mock_stream = MagicMock()
        mock_stream.resolve_count = 42
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        assert wrapper.resolve_count == 42

    def test_no_usage_records_zero_tokens(self):
        """If no usage metadata chunk is received, tokens default to 0."""
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        # Build chunk without usage
        chunk = SimpleNamespace(text="Hi", usage_metadata=None, candidates=[])
        mock_stream = MockSyncStream([chunk])
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        list(wrapper)

        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("waxell.llm.input_tokens") == 0
        assert calls.get("waxell.llm.output_tokens") == 0

    def test_ignores_unspecified_finish_reason(self):
        """FINISH_REASON_UNSPECIFIED is not recorded as a finish reason."""
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks(finish_reason_name="FINISH_REASON_UNSPECIFIED")
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        list(wrapper)

        assert wrapper._finish_reason == ""


# ---------------------------------------------------------------------------
# Gemini async stream wrapper tests
# ---------------------------------------------------------------------------


class TestGeminiAsyncStreamWrapper:
    def test_yields_all_chunks_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiAsyncStreamWrapper

        chunks = _make_gemini_chunks()
        mock_stream = MockAsyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiAsyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")

        async def consume():
            return [chunk async for chunk in wrapper]

        collected = asyncio.run(consume())
        assert collected == chunks

    def test_records_span_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiAsyncStreamWrapper

        chunks = _make_gemini_chunks(prompt_token_count=200, candidates_token_count=100)
        mock_stream = MockAsyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiAsyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")

        async def consume():
            return [chunk async for chunk in wrapper]

        asyncio.run(consume())

        span.end.assert_called_once()
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("waxell.llm.total_tokens") == 300

    def test_async_context_manager(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiAsyncStreamWrapper

        chunks = _make_gemini_chunks()
        mock_stream = MockAsyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiAsyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")

        async def consume():
            async with wrapper as w:
                return [chunk async for chunk in w]

        collected = asyncio.run(consume())
        assert mock_stream._entered
        assert mock_stream._exited
        assert len(collected) == 3

    def test_accumulates_content(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiAsyncStreamWrapper

        chunks = _make_gemini_chunks(texts=("Once", " upon", " a time"))
        mock_stream = MockAsyncStream(chunks)
        span = MagicMock()

        wrapper = GeminiAsyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")

        async def consume():
            return [chunk async for chunk in wrapper]

        asyncio.run(consume())
        assert "".join(wrapper._content_parts) == "Once upon a time"


# ---------------------------------------------------------------------------
# Cohere sync stream wrapper tests
# ---------------------------------------------------------------------------


class TestCohereSyncStreamWrapper:
    def test_yields_all_events_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        events = _make_cohere_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        collected = list(wrapper)

        assert collected == events
        assert len(collected) == 3  # 2 content-delta + 1 message-end

    def test_accumulates_content_from_deltas(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        events = _make_cohere_events(texts=("Once", " upon", " a", " time"))
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        list(wrapper)

        assert "".join(wrapper._content_parts) == "Once upon a time"

    def test_captures_usage_from_message_end(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        events = _make_cohere_events(input_tokens=500, output_tokens=250)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        list(wrapper)

        assert wrapper._tokens_in == 500
        assert wrapper._tokens_out == 250

    def test_records_span_attributes_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        events = _make_cohere_events(input_tokens=100, output_tokens=50)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        list(wrapper)

        span.end.assert_called_once()
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.usage.input_tokens") == 100
        assert calls.get("gen_ai.usage.output_tokens") == 50
        assert calls.get("waxell.llm.input_tokens") == 100
        assert calls.get("waxell.llm.output_tokens") == 50
        assert calls.get("waxell.llm.total_tokens") == 150

    def test_captures_finish_reason(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        events = _make_cohere_events(finish_reason="MAX_TOKENS")
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        list(wrapper)

        assert wrapper._finish_reason == "MAX_TOKENS"
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.response.finish_reasons") == ["MAX_TOKENS"]

    def test_context_manager_protocol(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        events = _make_cohere_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        with wrapper as w:
            collected = list(w)

        assert mock_stream._entered
        assert mock_stream._exited
        assert len(collected) == 3
        span.end.assert_called_once()

    def test_finalize_only_once(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        events = _make_cohere_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        with wrapper as w:
            list(w)

        assert span.end.call_count == 1

    def test_proxy_attribute_access(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        mock_stream = MagicMock()
        mock_stream.generation_id = "gen-abc123"
        span = MagicMock()

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        assert wrapper.generation_id == "gen-abc123"


# ---------------------------------------------------------------------------
# Cohere async stream wrapper tests
# ---------------------------------------------------------------------------


class TestCohereAsyncStreamWrapper:
    def test_yields_all_events_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereAsyncStreamWrapper

        events = _make_cohere_events()
        mock_stream = MockAsyncStream(events)
        span = MagicMock()

        wrapper = CohereAsyncStreamWrapper(mock_stream, span, "command-r-plus")

        async def consume():
            return [event async for event in wrapper]

        collected = asyncio.run(consume())
        assert collected == events

    def test_records_span_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereAsyncStreamWrapper

        events = _make_cohere_events(input_tokens=300, output_tokens=150)
        mock_stream = MockAsyncStream(events)
        span = MagicMock()

        wrapper = CohereAsyncStreamWrapper(mock_stream, span, "command-r-plus")

        async def consume():
            return [event async for event in wrapper]

        asyncio.run(consume())

        span.end.assert_called_once()
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("waxell.llm.total_tokens") == 450

    def test_async_context_manager(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereAsyncStreamWrapper

        events = _make_cohere_events()
        mock_stream = MockAsyncStream(events)
        span = MagicMock()

        wrapper = CohereAsyncStreamWrapper(mock_stream, span, "command-r-plus")

        async def consume():
            async with wrapper as w:
                return [event async for event in w]

        collected = asyncio.run(consume())
        assert mock_stream._entered
        assert mock_stream._exited
        assert len(collected) == 3

    def test_accumulates_content(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereAsyncStreamWrapper

        events = _make_cohere_events(texts=("Hello", " ", "world"))
        mock_stream = MockAsyncStream(events)
        span = MagicMock()

        wrapper = CohereAsyncStreamWrapper(mock_stream, span, "command-r-plus")

        async def consume():
            return [event async for event in wrapper]

        asyncio.run(consume())
        assert "".join(wrapper._content_parts) == "Hello world"


# ---------------------------------------------------------------------------
# Bedrock stream wrapper tests
# ---------------------------------------------------------------------------


class TestBedrockStreamWrapper:
    def test_yields_all_events_unchanged(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = _make_bedrock_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        collected = list(wrapper)

        assert collected == events
        assert len(collected) == 4  # 2 content + messageStop + metadata

    def test_accumulates_content_from_deltas(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = _make_bedrock_events(texts=("Once", " upon", " a", " time"))
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        list(wrapper)

        assert "".join(wrapper._content_parts) == "Once upon a time"

    def test_captures_usage_from_metadata(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = _make_bedrock_events(input_tokens=500, output_tokens=250)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        list(wrapper)

        assert wrapper._tokens_in == 500
        assert wrapper._tokens_out == 250

    def test_records_span_attributes_on_completion(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = _make_bedrock_events(input_tokens=100, output_tokens=50)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        list(wrapper)

        span.end.assert_called_once()
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.usage.input_tokens") == 100
        assert calls.get("gen_ai.usage.output_tokens") == 50
        assert calls.get("waxell.llm.input_tokens") == 100
        assert calls.get("waxell.llm.output_tokens") == 50
        assert calls.get("waxell.llm.total_tokens") == 150

    def test_captures_stop_reason(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = _make_bedrock_events(stop_reason="max_tokens")
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        list(wrapper)

        assert wrapper._finish_reason == "max_tokens"
        calls = {call.args[0]: call.args[1] for call in span.set_attribute.call_args_list}
        assert calls.get("gen_ai.response.finish_reasons") == ["max_tokens"]

    def test_context_manager_protocol(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = _make_bedrock_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        with wrapper as w:
            collected = list(w)

        assert mock_stream._entered
        assert mock_stream._exited
        assert len(collected) == 4
        span.end.assert_called_once()

    def test_finalize_only_once(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = _make_bedrock_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        with wrapper as w:
            list(w)

        assert span.end.call_count == 1

    def test_proxy_attribute_access(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        mock_stream = MagicMock()
        mock_stream.close = MagicMock()
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        wrapper.close()
        mock_stream.close.assert_called_once()

    def test_non_dict_event_ignored(self):
        """Non-dict events are yielded unchanged without processing."""
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = [
            "not-a-dict",
            {"contentBlockDelta": {"delta": {"text": "Hi"}}},
            {"metadata": {"usage": {"inputTokens": 5, "outputTokens": 3}}},
        ]
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        collected = list(wrapper)

        assert len(collected) == 3
        assert "".join(wrapper._content_parts) == "Hi"
        assert wrapper._tokens_in == 5

    def test_error_resilience(self):
        """If span operations raise, events are still yielded."""
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper

        events = _make_bedrock_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()
        span.set_attribute.side_effect = Exception("OTel broken")

        wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
        collected = list(wrapper)

        assert len(collected) == 4


# ---------------------------------------------------------------------------
# Cross-provider stream HTTP recording tests
# ---------------------------------------------------------------------------


class TestGeminiStreamHTTPRecording:
    def test_records_to_context_when_active(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper
        from waxell_observe.instrumentors._context_var import _current_context

        chunks = _make_gemini_chunks(prompt_token_count=10, candidates_token_count=5)
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()

        mock_ctx = MagicMock()
        mock_ctx.run_id = "test-run-gemini"

        token = _current_context.set(mock_ctx)
        try:
            wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
            list(wrapper)
        finally:
            _current_context.reset(token)

        mock_ctx.record_llm_call.assert_called_once()
        call_kwargs = mock_ctx.record_llm_call.call_args
        assert call_kwargs[1]["model"] == "gemini-1.5-pro"
        assert call_kwargs[1]["tokens_in"] == 10
        assert call_kwargs[1]["tokens_out"] == 5


class TestCohereStreamHTTPRecording:
    def test_records_to_context_when_active(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper
        from waxell_observe.instrumentors._context_var import _current_context

        events = _make_cohere_events(input_tokens=20, output_tokens=10)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        mock_ctx = MagicMock()
        mock_ctx.run_id = "test-run-cohere"

        token = _current_context.set(mock_ctx)
        try:
            wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
            list(wrapper)
        finally:
            _current_context.reset(token)

        mock_ctx.record_llm_call.assert_called_once()
        call_kwargs = mock_ctx.record_llm_call.call_args
        assert call_kwargs[1]["model"] == "command-r-plus"
        assert call_kwargs[1]["tokens_in"] == 20
        assert call_kwargs[1]["tokens_out"] == 10


class TestBedrockStreamHTTPRecording:
    def test_records_to_context_when_active(self):
        from waxell_observe.instrumentors._stream_wrappers import BedrockStreamWrapper
        from waxell_observe.instrumentors._context_var import _current_context

        events = _make_bedrock_events(input_tokens=30, output_tokens=15)
        mock_stream = MockSyncStream(events)
        span = MagicMock()

        mock_ctx = MagicMock()
        mock_ctx.run_id = "test-run-bedrock"

        token = _current_context.set(mock_ctx)
        try:
            wrapper = BedrockStreamWrapper(mock_stream, span, "anthropic.claude-3-sonnet")
            list(wrapper)
        finally:
            _current_context.reset(token)

        mock_ctx.record_llm_call.assert_called_once()
        call_kwargs = mock_ctx.record_llm_call.call_args
        assert call_kwargs[1]["model"] == "anthropic.claude-3-sonnet"
        assert call_kwargs[1]["tokens_in"] == 30
        assert call_kwargs[1]["tokens_out"] == 15


# ---------------------------------------------------------------------------
# Cross-provider stream error resilience tests
# ---------------------------------------------------------------------------


class TestGeminiStreamErrorResilience:
    def test_span_error_does_not_break_stream(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()
        span.set_attribute.side_effect = Exception("OTel broken")

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        collected = list(wrapper)

        assert len(collected) == 3

    def test_finalize_error_does_not_propagate(self):
        from waxell_observe.instrumentors._stream_wrappers import GeminiSyncStreamWrapper

        chunks = _make_gemini_chunks()
        mock_stream = MockSyncStream(chunks)
        span = MagicMock()
        span.set_attribute.side_effect = Exception("boom")
        span.end.side_effect = Exception("double boom")

        wrapper = GeminiSyncStreamWrapper(mock_stream, span, "gemini-1.5-pro")
        collected = list(wrapper)
        assert len(collected) == 3


class TestCohereStreamErrorResilience:
    def test_span_error_does_not_break_stream(self):
        from waxell_observe.instrumentors._stream_wrappers import CohereSyncStreamWrapper

        events = _make_cohere_events()
        mock_stream = MockSyncStream(events)
        span = MagicMock()
        span.set_attribute.side_effect = Exception("OTel broken")

        wrapper = CohereSyncStreamWrapper(mock_stream, span, "command-r-plus")
        collected = list(wrapper)

        assert len(collected) == 3
