"""
Type definitions for LiteSOC SDK

LiteSOC defines 26 standard security events across 5 categories.
These events are automatically enriched with Security Intelligence
including GeoIP, VPN/Tor/Proxy detection, and threat scoring.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union


# Event severity levels
class EventSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# =============================================================================
# 26 STANDARD EVENTS (Primary - Security Intelligence optimized)
# =============================================================================

# Authentication events (8 events)
AuthEvent = Literal[
    "auth.login_success",
    "auth.login_failed",
    "auth.logout",
    "auth.password_reset",
    "auth.mfa_enabled",
    "auth.mfa_disabled",
    "auth.session_expired",
    "auth.token_refreshed",
]

# Authorization events (4 events)
AuthzEvent = Literal[
    "authz.role_changed",
    "authz.permission_granted",
    "authz.permission_revoked",
    "authz.access_denied",
]

# Admin events (7 events)
AdminEvent = Literal[
    "admin.privilege_escalation",
    "admin.user_impersonation",
    "admin.settings_changed",
    "admin.api_key_created",
    "admin.api_key_revoked",
    "admin.user_suspended",
    "admin.user_deleted",
]

# Data events (3 events)
DataEvent = Literal[
    "data.bulk_delete",
    "data.sensitive_access",
    "data.export",
]

# Security events (4 events)
SecurityEvent = Literal[
    "security.suspicious_activity",
    "security.rate_limit_exceeded",
    "security.ip_blocked",
    "security.brute_force_detected",
]


# =============================================================================
# LEGACY/EXTENDED EVENTS (Backward Compatibility)
# =============================================================================

# Extended authentication events
LegacyAuthEvent = Literal[
    "auth.password_changed",
    "auth.password_reset_requested",
    "auth.password_reset_completed",
    "auth.mfa_challenge_success",
    "auth.mfa_challenge_failed",
    "auth.session_created",
    "auth.session_revoked",
    "auth.failed",
]

# User events
UserEvent = Literal[
    "user.created",
    "user.updated",
    "user.deleted",
    "user.email_changed",
    "user.email_verified",
    "user.phone_changed",
    "user.phone_verified",
    "user.profile_updated",
    "user.avatar_changed",
    "user.login_failed",
    "user.login.failed",
]

# Extended authorization events
LegacyAuthzEvent = Literal[
    "authz.role_assigned",
    "authz.role_removed",
    "authz.access_granted",
]

# Extended admin events
LegacyAdminEvent = Literal[
    "admin.invite_sent",
    "admin.invite_accepted",
    "admin.member_removed",
]

# Extended data events
LegacyDataEvent = Literal[
    "data.import",
    "data.bulk_update",
    "data.download",
    "data.upload",
    "data.shared",
    "data.unshared",
]

# Extended security events
LegacySecurityEvent = Literal[
    "security.ip_unblocked",
    "security.account_locked",
    "security.account_unlocked",
    "security.impossible_travel",
    "security.geo_anomaly",
]

# API events
ApiEvent = Literal[
    "api.key_used",
    "api.rate_limited",
    "api.error",
    "api.webhook_sent",
    "api.webhook_failed",
]

# Billing events
BillingEvent = Literal[
    "billing.subscription_created",
    "billing.subscription_updated",
    "billing.subscription_cancelled",
    "billing.payment_succeeded",
    "billing.payment_failed",
    "billing.invoice_created",
    "billing.invoice_paid",
]

# All event types (26 standard + legacy/extended + custom)
EventType = Union[
    # Primary 26 standard events
    AuthEvent,
    AuthzEvent,
    AdminEvent,
    DataEvent,
    SecurityEvent,
    # Extended/Legacy events
    LegacyAuthEvent,
    UserEvent,
    LegacyAuthzEvent,
    LegacyAdminEvent,
    LegacyDataEvent,
    LegacySecurityEvent,
    ApiEvent,
    BillingEvent,
    str,  # Allow custom events
]


@dataclass
class Actor:
    """Actor (user) information"""
    
    id: str
    email: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Optional[str]]:
        """Convert to dictionary for API payload"""
        return {"id": self.id, "email": self.email}


@dataclass
class TrackOptions:
    """Options for tracking an event"""
    
    actor: Optional[Union[Actor, str]] = None
    actor_email: Optional[str] = None
    user_ip: Optional[str] = None
    severity: Optional[EventSeverity] = None
    metadata: Optional[Dict[str, Any]] = None
    timestamp: Optional[Union[datetime, str]] = None


@dataclass
class QueuedEvent:
    """Internal event structure for the queue"""
    
    event: str
    actor: Optional[Dict[str, Optional[str]]]
    user_ip: Optional[str]
    metadata: Dict[str, Any]
    timestamp: str
    retry_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API payload"""
        return {
            "event": self.event,
            "actor": self.actor,
            "user_ip": self.user_ip,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
        }


@dataclass
class LiteSOCConfig:
    """SDK configuration options"""
    
    api_key: str
    endpoint: str = "https://www.litesoc.io/api/v1/collect"
    batching: bool = True
    batch_size: int = 10
    flush_interval: float = 5.0  # seconds
    debug: bool = False
    silent: bool = True
    timeout: float = 30.0  # seconds
