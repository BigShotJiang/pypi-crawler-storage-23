"""Add command - Add a new command to an existing package."""

from pathlib import Path

import click
from rich.console import Console
from rich.prompt import Confirm, IntPrompt
from rich.table import Table

from ..config import ConfigError, load_config
from ..lmod import find_package_versions
from ..singularity import add_command_symlink

console = Console()


@click.command(context_settings=dict(help_option_names=["-h", "--help"]))
@click.argument("package")
@click.argument("commands", nargs=-1)
@click.option(
    "-v",
    "--version",
    help="Add command to specific version (if not specified, adds to all versions)",
)
@click.option(
    "-f",
    "--cmd-file",
    "cmd_file",
    type=click.Path(exists=True, path_type=Path),
    help="File with list of commands (one per line, # for comments)",
)
@click.option(
    "-l",
    "--lmod-path",
    type=click.Path(path_type=Path),
    help="Path to LMOD Lua packages (overrides config)",
)
@click.option(
    "-b",
    "--bin-path",
    type=click.Path(path_type=Path),
    help="Path for binary wrappers (overrides config)",
)
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite existing command symlink",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be done without making changes",
)
@click.pass_context
def add(
    ctx: click.Context,
    package: str,
    commands: tuple[str, ...],
    version: str | None,
    cmd_file: Path | None,
    lmod_path: Path | None,
    bin_path: Path | None,
    force: bool,
    dry_run: bool,
) -> None:
    """
    Add one or more commands to an existing package.

    PACKAGE: Name of the package
    COMMANDS: One or more commands to add

    Examples:
        lmodify add kraken2 kraken2-build
        lmodify add kraken2 kraken2-build kraken2-inspect
        lmodify add kraken2 -f k2-commands.txt
        lmodify add kraken2 kraken2-build -f commands.txt --version 1.20.3
    """
    # Load config
    config_path = ctx.obj.get("config_path")
    try:
        config = load_config(config_path)
    except ConfigError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise click.Abort()

    # Use config paths if not overridden
    if lmod_path is None:
        lmod_path = config.lmod_path
    if bin_path is None:
        bin_path = config.bin_path

    # Combine commands from file and arguments
    all_commands = list(commands)
    if cmd_file is not None:
        try:
            file_commands = _read_commands_from_file(cmd_file)
            all_commands.extend(file_commands)
        except Exception as e:
            console.print(f"[red]Error reading command file:[/red] {e}")
            raise click.Abort()

    # Remove duplicates while preserving order
    seen = set()
    unique_commands = []
    for cmd in all_commands:
        if cmd not in seen:
            seen.add(cmd)
            unique_commands.append(cmd)

    # No commands provided — try bioconda auto-discovery
    if not unique_commands and cmd_file is None:
        discovered = _find_bioconda_commands(config.bioconda_bin_path, package, version)
        if discovered:
            unique_commands = discovered

    # Ensure at least one command is provided
    if not unique_commands:
        console.print("[red]Error:[/red] At least one command must be specified")
        console.print("Provide commands as arguments or use -f to load from a file")
        raise click.Abort()

    # Find package versions
    if version:
        versions = [version]
        # Verify version exists
        available = find_package_versions(lmod_path, package)
        if version not in available:
            console.print(
                f"[red]Error:[/red] Version {version} not found for package {package}"
            )
            console.print(f"Available versions: {', '.join(available)}")
            raise click.Abort()
    else:
        versions = find_package_versions(lmod_path, package)
        if not versions:
            console.print(f"[red]Error:[/red] Package not found: {package}")
            console.print("Run 'lmodify list' to see available packages.")
            raise click.Abort()

    # Display plan
    _display_add_plan(package, unique_commands, versions, bin_path)

    if dry_run:
        console.print("\n[yellow]Dry run - no changes made[/yellow]")
        return

    # Add commands to each version
    results = []
    for ver in versions:
        package_dir = bin_path / f"{package}__{ver}"

        for command in unique_commands:
            try:
                added = add_command_symlink(
                    bin_dir=package_dir,
                    command=command,
                    force=force,
                    dry_run=dry_run,
                )
                results.append((ver, command, added, None))
            except FileNotFoundError as e:
                results.append((ver, command, False, str(e)))
            except Exception as e:
                results.append((ver, command, False, str(e)))

    # Display results
    _display_results(package, results, force)


def _read_commands_from_file(cmd_file: Path) -> list[str]:
    """Read commands from a file, ignoring empty lines and comments."""
    commands = []
    with cmd_file.open("r") as f:
        for line in f:
            # Strip whitespace
            line = line.strip()
            # Skip empty lines and comments
            if line and not line.startswith("#"):
                commands.append(line)
    return commands


def _find_bioconda_commands(
    bioconda_bin_path: Path,
    package: str,
    version: str | None,
) -> list[str] | None:
    """Try to discover commands from bioconda_bin_path for a package.

    Returns a list of commands, or None if nothing was selected.
    """
    # Try exact match: {package}_{version}.txt
    if version:
        exact = bioconda_bin_path / f"{package}_{version}.txt"
        if exact.exists():
            commands = _read_commands_from_file(exact)
            console.print(
                f"[dim]Auto-detected {len(commands)} command(s) from {exact.name}[/dim]"
            )
            return commands

    # Glob for {package}_*.txt
    matches = sorted(bioconda_bin_path.glob(f"{package}_*.txt"))

    if not matches:
        return None

    if len(matches) == 1:
        chosen = matches[0]
        console.print(f"\n[dim]Found command file:[/dim] {chosen.name}\n")
        console.print(chosen.read_text())
        if Confirm.ask("Use this file?"):
            return _read_commands_from_file(chosen)
        return None

    # Multiple matches — let user pick
    console.print(f"\n[bold]Multiple command files found for '{package}':[/bold]\n")
    for i, match in enumerate(matches, 1):
        console.print(f"  [cyan]{i}.[/cyan] {match.name}")
    choice = IntPrompt.ask(
        f"Select a file (1-{len(matches)}, 0 to skip)",
        default=0,
    )
    if choice < 1 or choice > len(matches):
        return None
    chosen = matches[choice - 1]
    return _read_commands_from_file(chosen)


def _display_add_plan(
    package: str,
    commands: list[str],
    versions: list[str],
    bin_path: Path,
) -> None:
    """Display what will be added."""
    commands_str = ", ".join(f"'{cmd}'" for cmd in commands)
    console.print(f"\n[bold]Adding command(s) {commands_str} to {package}[/bold]\n")

    table = Table(show_header=True)
    table.add_column("Version", style="cyan")
    table.add_column("Commands", style="yellow")
    table.add_column("Bin Directory", style="dim")

    for version in versions:
        package_dir = bin_path / f"{package}__{version}"
        table.add_row(version, ", ".join(commands), str(package_dir))

    console.print(table)


def _display_results(
    package: str,
    results: list[tuple[str, str, bool, str | None]],
    force: bool,
) -> None:
    """Display results of adding commands."""
    console.print("\n[bold]Results:[/bold]\n")

    success_count = 0
    skip_count = 0
    error_count = 0

    for version, command, added, error in results:
        if error:
            console.print(f"  [red]✗[/red] {version}/{command}: {error}")
            error_count += 1
        elif added:
            console.print(f"  [green]✓[/green] {version}/{command}: Command added")
            success_count += 1
        else:
            console.print(
                f"  [yellow]•[/yellow] {version}/{command}: Command already exists (use --force to overwrite)"
            )
            skip_count += 1

    # Summary
    console.print()
    if success_count > 0:
        console.print(
            f"[green]Successfully added {success_count} command(s)[/green]"
        )
    if skip_count > 0:
        console.print(
            f"[yellow]Skipped {skip_count} command(s) (already exists)[/yellow]"
        )
    if error_count > 0:
        console.print(f"[red]Failed for {error_count} command(s)[/red]")
