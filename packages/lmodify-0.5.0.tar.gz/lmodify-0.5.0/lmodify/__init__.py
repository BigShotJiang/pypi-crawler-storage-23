"""lmodify - Create LMOD packages based on Singularity images."""

__version__ = "0.5.0"
