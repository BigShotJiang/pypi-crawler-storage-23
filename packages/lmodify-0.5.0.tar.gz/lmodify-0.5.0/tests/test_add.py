"""Tests for add command."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from lmodify.commands.add import _read_commands_from_file, add


class TestReadCommandsFromFile:
    """Tests for _read_commands_from_file helper function."""

    def test_read_simple_commands(self, tmp_path):
        """Test reading simple list of commands from file."""
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text("kraken2-build\nkraken2-inspect\nbracken")

        commands = _read_commands_from_file(cmd_file)

        assert commands == ["kraken2-build", "kraken2-inspect", "bracken"]

    def test_ignore_comments(self, tmp_path):
        """Test that lines starting with # are ignored."""
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text(
            "# This is a comment\n"
            "kraken2-build\n"
            "# Another comment\n"
            "kraken2-inspect\n"
            "## Double hash comment\n"
            "bracken"
        )

        commands = _read_commands_from_file(cmd_file)

        assert commands == ["kraken2-build", "kraken2-inspect", "bracken"]

    def test_ignore_empty_lines(self, tmp_path):
        """Test that empty lines are ignored."""
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text(
            "kraken2-build\n"
            "\n"
            "kraken2-inspect\n"
            "\n"
            "\n"
            "bracken"
        )

        commands = _read_commands_from_file(cmd_file)

        assert commands == ["kraken2-build", "kraken2-inspect", "bracken"]

    def test_strip_whitespace(self, tmp_path):
        """Test that leading/trailing whitespace is stripped."""
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text(
            "  kraken2-build  \n"
            "\tkraken2-inspect\t\n"
            "   bracken"
        )

        commands = _read_commands_from_file(cmd_file)

        assert commands == ["kraken2-build", "kraken2-inspect", "bracken"]

    def test_complex_file_format(self, tmp_path):
        """Test file with mix of commands, comments, empty lines, and whitespace."""
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text(
            "# Kraken2 commands\n"
            "kraken2-build\n"
            "kraken2-inspect\n"
            "\n"
            "# Bracken commands\n"
            "  bracken  \n"
            "bracken-build\n"
            "\n"
            "# End of file"
        )

        commands = _read_commands_from_file(cmd_file)

        assert commands == [
            "kraken2-build",
            "kraken2-inspect",
            "bracken",
            "bracken-build",
        ]

    def test_empty_file(self, tmp_path):
        """Test reading from empty file returns empty list."""
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text("")

        commands = _read_commands_from_file(cmd_file)

        assert commands == []

    def test_only_comments_and_empty_lines(self, tmp_path):
        """Test file with only comments and empty lines returns empty list."""
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text(
            "# Comment 1\n"
            "\n"
            "# Comment 2\n"
            "\n"
            "# Comment 3"
        )

        commands = _read_commands_from_file(cmd_file)

        assert commands == []

    def test_file_not_found(self, tmp_path):
        """Test that FileNotFoundError is raised for non-existent file."""
        cmd_file = tmp_path / "nonexistent.txt"

        with pytest.raises(FileNotFoundError):
            _read_commands_from_file(cmd_file)


class TestAddCommandWithFile:
    """Tests for add command using -f/--cmd-file option."""

    @pytest.fixture
    def mock_dependencies(self, tmp_path):
        """Mock dependencies for add command tests."""
        config_mock = MagicMock()
        config_mock.lmod_path = tmp_path / "lmod"
        config_mock.bin_path = tmp_path / "bin"

        return {
            "config": config_mock,
            "lmod_path": config_mock.lmod_path,
            "bin_path": config_mock.bin_path,
        }

    def test_add_commands_from_file(self, tmp_path, mock_dependencies):
        """Test adding commands from a file."""
        # Create command file
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text("kraken2-build\nkraken2-inspect")

        # Create mock package structure
        package_dir = mock_dependencies["bin_path"] / "kraken2__1.0.0"
        package_dir.mkdir(parents=True)

        runner = CliRunner()
        with patch("lmodify.commands.add.load_config") as mock_config:
            with patch("lmodify.commands.add.find_package_versions") as mock_find:
                with patch("lmodify.commands.add.add_command_symlink") as mock_add:
                    mock_config.return_value = mock_dependencies["config"]
                    mock_find.return_value = ["1.0.0"]
                    mock_add.return_value = True

                    result = runner.invoke(
                        add,
                        ["kraken2", "-f", str(cmd_file)],
                        obj={"config_path": None},
                    )

                    # Check that add_command_symlink was called for both commands
                    assert mock_add.call_count == 2
                    # Verify the commands were passed correctly
                    call_args = [call[1]["command"] for call in mock_add.call_args_list]
                    assert "kraken2-build" in call_args
                    assert "kraken2-inspect" in call_args

    def test_combine_file_and_cli_commands(self, tmp_path, mock_dependencies):
        """Test combining commands from file and CLI arguments."""
        # Create command file
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text("kraken2-build\nkraken2-inspect")

        runner = CliRunner()
        with patch("lmodify.commands.add.load_config") as mock_config:
            with patch("lmodify.commands.add.find_package_versions") as mock_find:
                with patch("lmodify.commands.add.add_command_symlink") as mock_add:
                    mock_config.return_value = mock_dependencies["config"]
                    mock_find.return_value = ["1.0.0"]
                    mock_add.return_value = True

                    result = runner.invoke(
                        add,
                        ["kraken2", "bracken", "-f", str(cmd_file)],
                        obj={"config_path": None},
                    )

                    # Should have 3 commands total
                    assert mock_add.call_count == 3
                    call_args = [call[1]["command"] for call in mock_add.call_args_list]
                    assert "bracken" in call_args
                    assert "kraken2-build" in call_args
                    assert "kraken2-inspect" in call_args

    def test_duplicate_commands_removed(self, tmp_path, mock_dependencies):
        """Test that duplicate commands are removed."""
        # Create command file with duplicate
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text("kraken2-build\nkraken2-inspect\nkraken2-build")

        runner = CliRunner()
        with patch("lmodify.commands.add.load_config") as mock_config:
            with patch("lmodify.commands.add.find_package_versions") as mock_find:
                with patch("lmodify.commands.add.add_command_symlink") as mock_add:
                    mock_config.return_value = mock_dependencies["config"]
                    mock_find.return_value = ["1.0.0"]
                    mock_add.return_value = True

                    result = runner.invoke(
                        add,
                        ["kraken2", "-f", str(cmd_file)],
                        obj={"config_path": None},
                    )

                    # Should only call add_command_symlink twice (duplicates removed)
                    assert mock_add.call_count == 2

    def test_file_with_comments_and_empty_lines(self, tmp_path, mock_dependencies):
        """Test that comments and empty lines are properly ignored."""
        # Create command file with comments
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text(
            "# Main commands\n"
            "kraken2-build\n"
            "\n"
            "# Inspection tool\n"
            "kraken2-inspect\n"
            "\n"
        )

        runner = CliRunner()
        with patch("lmodify.commands.add.load_config") as mock_config:
            with patch("lmodify.commands.add.find_package_versions") as mock_find:
                with patch("lmodify.commands.add.add_command_symlink") as mock_add:
                    mock_config.return_value = mock_dependencies["config"]
                    mock_find.return_value = ["1.0.0"]
                    mock_add.return_value = True

                    result = runner.invoke(
                        add,
                        ["kraken2", "-f", str(cmd_file)],
                        obj={"config_path": None},
                    )

                    assert mock_add.call_count == 2
                    call_args = [call[1]["command"] for call in mock_add.call_args_list]
                    assert "kraken2-build" in call_args
                    assert "kraken2-inspect" in call_args

    def test_empty_file_with_cli_command(self, tmp_path, mock_dependencies):
        """Test that CLI commands work even with empty file."""
        # Create empty command file
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text("# Only comments\n\n")

        runner = CliRunner()
        with patch("lmodify.commands.add.load_config") as mock_config:
            with patch("lmodify.commands.add.find_package_versions") as mock_find:
                with patch("lmodify.commands.add.add_command_symlink") as mock_add:
                    mock_config.return_value = mock_dependencies["config"]
                    mock_find.return_value = ["1.0.0"]
                    mock_add.return_value = True

                    result = runner.invoke(
                        add,
                        ["kraken2", "bracken", "-f", str(cmd_file)],
                        obj={"config_path": None},
                    )

                    # Should only add the CLI command
                    assert mock_add.call_count == 1
                    assert mock_add.call_args[1]["command"] == "bracken"

    def test_no_commands_error(self, tmp_path, mock_dependencies):
        """Test error when no commands provided (empty file, no CLI args)."""
        # Create empty command file
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text("")

        runner = CliRunner()
        with patch("lmodify.commands.add.load_config") as mock_config:
            mock_config.return_value = mock_dependencies["config"]

            result = runner.invoke(
                add,
                ["kraken2", "-f", str(cmd_file)],
                obj={"config_path": None},
            )

            assert result.exit_code != 0
            assert "At least one command must be specified" in result.output

    def test_dry_run_with_file(self, tmp_path, mock_dependencies):
        """Test --dry-run flag with command file."""
        # Create command file
        cmd_file = tmp_path / "commands.txt"
        cmd_file.write_text("kraken2-build\nkraken2-inspect")

        runner = CliRunner()
        with patch("lmodify.commands.add.load_config") as mock_config:
            with patch("lmodify.commands.add.find_package_versions") as mock_find:
                with patch("lmodify.commands.add.add_command_symlink") as mock_add:
                    mock_config.return_value = mock_dependencies["config"]
                    mock_find.return_value = ["1.0.0"]

                    result = runner.invoke(
                        add,
                        ["kraken2", "-f", str(cmd_file), "--dry-run"],
                        obj={"config_path": None},
                    )

                    # add_command_symlink should not be called in dry-run mode
                    assert mock_add.call_count == 0
                    assert "Dry run" in result.output
