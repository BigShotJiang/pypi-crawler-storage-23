"""CLI package for rastion."""

from rastion.cli.__main__ import main

__all__ = ["main"]
