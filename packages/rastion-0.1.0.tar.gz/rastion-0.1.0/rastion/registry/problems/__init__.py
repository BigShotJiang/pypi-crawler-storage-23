"""Bundled registry problem templates."""
