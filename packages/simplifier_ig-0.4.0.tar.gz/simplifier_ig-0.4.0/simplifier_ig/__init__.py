"""Simplifier.net IG CLI Tool — generate Implementation Guide structures."""

__version__ = "0.1.0"
