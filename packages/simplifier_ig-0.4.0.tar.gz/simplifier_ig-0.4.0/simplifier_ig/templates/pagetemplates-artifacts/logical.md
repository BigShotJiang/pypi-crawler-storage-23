---
topic: logical-{{ig-var: file-name }}
canonical: {{ig-var: StructureDefinition.url }}
expand: 2
buttons: yes
---

## {{page-title}}

  {{page:Resource-Meta-Table}}
  
  {{page:FQL-get-resource-description}}

  {{page:resource-view-logical}}
