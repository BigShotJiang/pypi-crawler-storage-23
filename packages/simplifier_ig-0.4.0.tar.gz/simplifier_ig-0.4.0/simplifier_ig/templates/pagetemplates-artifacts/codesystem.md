---
topic: codesystem-{{ig-var: file-name }}
canonical: {{ig-var: CodeSystem.url }}
expand: 2
---

## {{page-title}}

  {{page:Resource-Meta-Table}}
  
  {{page:FQL-get-resource-description}}

  {{page:resource-view-render}}
