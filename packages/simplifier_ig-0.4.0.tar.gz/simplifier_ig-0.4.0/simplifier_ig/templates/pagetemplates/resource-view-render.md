---
topic: resource-view-render
---

<tabs>
	<tab title="Rendered view">
	   {{render}}
	</tab>
	<tab title="JSON view">
       {{json}}
	</tab>
	<tab title="XML view">
      {{xml}}
	</tab>
	<tab title="Tree view">
      {{tree}}
	</tab>
	<tab title="Table view">
      {{table}}
	</tab>
</tabs>

