---
topic: fql-get-resource-description
---
<fql output="inline">
    for Resource
    where url=%canonical
    select description
</fql>