---
topic: fql-get-resource-base
---
<fql output="inline">
    for Resource
    where url=%canonical
    select baseDefinition
</fql>