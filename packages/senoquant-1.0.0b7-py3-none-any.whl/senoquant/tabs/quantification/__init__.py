"""Quantification tab modules."""
