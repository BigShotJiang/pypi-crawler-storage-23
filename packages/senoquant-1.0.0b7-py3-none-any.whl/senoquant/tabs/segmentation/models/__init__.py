"""Segmentation model definitions and storage."""

from .base import SenoQuantSegmentationModel

__all__ = ["SenoQuantSegmentationModel"]
