"""StarDist ONNX support utilities (vendored StarDist/CSBDeep + helpers)."""

