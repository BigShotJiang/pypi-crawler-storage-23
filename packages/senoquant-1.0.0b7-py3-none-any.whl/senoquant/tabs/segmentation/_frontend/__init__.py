"""Private frontend implementation modules for segmentation tab."""

