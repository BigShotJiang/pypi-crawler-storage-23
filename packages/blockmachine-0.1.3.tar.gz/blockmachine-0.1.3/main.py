"""Blockmachine CLI main entrypoint"""

import shutil
import subprocess

import typer
from rich.console import Console

from cli import settings
from cli.commands.miner import app as miner_app

app = typer.Typer(
    name="bm",
    help="Blockmachine CLI",
    no_args_is_help=True,
)

console = Console()


@app.callback()
def _global_options(
    testnet: bool = typer.Option(
        False, "--testnet", help="Use testnet (subnet 417)"
    ),
) -> None:
    if testnet:
        settings.set_network(settings.TESTNET)
        console.print("[yellow]Using testnet[/yellow]")


app.add_typer(miner_app, name="miner", help="Miner node management")


@app.command("update")
def update() -> None:
    """Update Blockmachine CLI to the latest version."""
    if shutil.which("uv"):
        cmd = ["uv", "tool", "upgrade", "blockmachine"]
    else:
        cmd = ["pip", "install", "--upgrade", "blockmachine"]

    console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")
    result = subprocess.run(cmd, check=False)

    if result.returncode != 0:
        console.print("[red]Update failed[/red]")
        raise typer.Exit(1)

    console.print("[green]Updated[/green]")


def main() -> None:
    """Main entry point"""
    app()


if __name__ == "__main__":
    main()
