"""CLI utility functions"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


def resolve_node_id(db_response: dict, id_or_alias: str) -> Optional[str]:
    """
    Resolve a node ID or alias to a node ID.

    Args:
        db_response: Response from nodes list API
        id_or_alias: Either a node UUID or an alias

    Returns:
        Node UUID string or None if not found
    """
    nodes = db_response.get("nodes", [])

    # First try exact ID match
    for node in nodes:
        if str(node.get("id")) == id_or_alias:
            return str(node["id"])

    # Then try alias match
    for node in nodes:
        if node.get("alias") == id_or_alias:
            return str(node["id"])

    return None


def format_timestamp(iso_string: Optional[str]) -> str:
    """Format an ISO timestamp for display"""
    if not iso_string:
        return "N/A"

    try:
        from datetime import datetime

        dt = datetime.fromisoformat(iso_string.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, AttributeError):
        return iso_string
