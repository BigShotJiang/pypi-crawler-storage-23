"""CLI configuration management — user state persisted to disk."""

import json
import logging
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

import jwt

from cli import settings

logger = logging.getLogger(__name__)

_jwks_client: jwt.PyJWKClient | None = None


def _get_jwks_client() -> jwt.PyJWKClient:
    global _jwks_client
    if _jwks_client is None:
        _jwks_client = jwt.PyJWKClient(settings.jwks_uri())
    return _jwks_client


@dataclass
class CLIConfig:
    """User state stored in ~/.blockmachine/config.json"""

    api_url: Optional[str] = None
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    token_expires_at: Optional[str] = None
    auth_url: Optional[str] = None
    client_id: Optional[str] = None
    active_miner_node: Optional[str] = None

    def __post_init__(self) -> None:
        if self.api_url is None:
            self.api_url = settings.api_url()
        if self.auth_url is None:
            self.auth_url = settings.auth_url()
        if self.client_id is None:
            self.client_id = settings.CLIENT_ID


def get_config_dir() -> Path:
    return Path.home() / ".blockmachine"


def get_config_path() -> Path:
    return get_config_dir() / "config.json"


def load_config() -> CLIConfig:
    """Load user config from disk, falling back to settings defaults."""
    config_path = get_config_path()

    if not config_path.exists():
        return CLIConfig()

    try:
        with open(config_path) as f:
            data = json.load(f)
            return CLIConfig(
                api_url=data.get("api_url", settings.api_url()),
                access_token=(data.get("access_token") or data.get("token")),
                refresh_token=data.get("refresh_token"),
                token_expires_at=data.get("token_expires_at"),
                auth_url=data.get("auth_url", settings.auth_url()),
                client_id=data.get("client_id", settings.CLIENT_ID),
                active_miner_node=data.get("active_miner_node"),
            )
    except (json.JSONDecodeError, IOError):
        return CLIConfig()


def save_config(config: CLIConfig) -> None:
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    config_path = get_config_path()
    with open(config_path, "w") as f:
        json.dump(asdict(config), f, indent=2)

    os.chmod(config_path, 0o600)


def _fetch_signing_key(token: str) -> jwt.PyJWK:
    """Fetch the signing key, retrying with a fresh JWKS client on failure."""
    global _jwks_client
    try:
        return _get_jwks_client().get_signing_key_from_jwt(token)
    except jwt.PyJWKClientError:
        logger.info("JWKS fetch failed, refreshing cached client")
        _jwks_client = None
        return _get_jwks_client().get_signing_key_from_jwt(token)


def validate_token(token: str) -> dict | None:
    """Validate a JWT against the JWKS and expected issuer."""
    try:
        signing_key = _fetch_signing_key(token)
        return jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=settings.auth_url(),
            audience=settings.AUDIENCE,
            options={"require": ["exp", "iss", "sub"]},
        )
    except jwt.ExpiredSignatureError:
        logger.debug("Token expired (JWT exp claim)")
        return None
    except jwt.InvalidIssuerError:
        logger.warning("Token issuer mismatch")
        return None
    except jwt.PyJWTError as e:
        logger.warning("JWT validation failed: %s", e)
        return None


def is_token_valid(config: CLIConfig) -> bool:
    """Check if the stored token is valid via JWT signature + issuer."""
    if not config.access_token:
        return False
    return validate_token(config.access_token) is not None


def clear_token(config: CLIConfig) -> CLIConfig:
    config.access_token = None
    config.refresh_token = None
    config.token_expires_at = None
    save_config(config)
    return config
