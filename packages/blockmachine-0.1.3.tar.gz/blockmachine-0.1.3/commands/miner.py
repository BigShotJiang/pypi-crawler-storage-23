"""Miner commands: node registration, secrets, and pricing"""

import getpass
import time
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from cli.client import RegistryClient
from cli import settings
from cli.commands.auth import check_status, device_login, do_logout
from cli.config import load_config, save_config
from cli.utils import format_timestamp, resolve_node_id

app = typer.Typer(help="Miner node management")
secret_app = typer.Typer(help="Secret management")
price_app = typer.Typer(help="Pricing management")

app.add_typer(secret_app, name="secret")
app.add_typer(price_app, name="price")

console = Console()

CHAIN = "tao"


def _get_alias(alias: Optional[str]) -> str:
    """Resolve alias from argument or active node context."""
    if alias:
        return alias
    config = load_config()
    if config.active_miner_node:
        return config.active_miner_node
    console.print(
        "[red]No node specified and no active node set.[/red]\n"
        "Run 'bm miner use <alias>' first."
    )
    raise typer.Exit(1)


def _resolve_node(client: RegistryClient, id_or_alias: str) -> str:
    """Resolve an alias or ID to a node UUID."""
    response = client.get("/nodes")
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code}")
        raise typer.Exit(1)
    node_id = resolve_node_id(response.json(), id_or_alias)
    if not node_id:
        console.print(f"[red]Node not found:[/red] {id_or_alias}")
        raise typer.Exit(1)
    return node_id


# ── Auth ─────────────────────────────────────────────────────────


@app.command("login")
def login(
    client_id: str = typer.Option(
        None, "--client-id", help="OAuth client ID"
    ),
    auth_url: str = typer.Option(
        None, "--auth-url", help="TaoStats auth URL"
    ),
    api_url: str = typer.Option(None, "--api-url", "-u", help="Registry API URL"),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Don't auto-open browser"
    ),
) -> None:
    """Login with miner scopes."""
    device_login(
        scopes=settings.miner_scopes(),
        client_id=client_id,
        auth_url=auth_url,
        api_url=api_url,
        no_browser=no_browser,
    )


@app.command("status")
def status() -> None:
    """Check authentication status."""
    check_status()


@app.command("logout")
def logout() -> None:
    """Clear stored authentication tokens."""
    do_logout()


# ── Node CRUD ────────────────────────────────────────────────────


@app.command("add")
def add(
    endpoint: str = typer.Option(None, "--endpoint", "-e", help="WSS endpoint URL"),
    alias: str = typer.Option(None, "--alias", "-a", help="Friendly name"),
    secret: str = typer.Option(None, "--secret", "-s", help="Bearer token secret"),
    price: str = typer.Option(None, "--price", "-p", help="USD per compute unit"),
) -> None:
    """Register a new miner node (interactive if flags omitted)."""
    if not endpoint:
        endpoint = typer.prompt("Endpoint (wss://...)")
    if not alias:
        default = _default_alias(endpoint)
        alias = typer.prompt("Alias", default=default)
    if not secret:
        secret = getpass.getpass("Secret: ")
    if not price:
        price = typer.prompt("Price (USD/CU)")

    if len(secret) < 16:
        console.print("[red]Secret must be at least 16 characters[/red]")
        raise typer.Exit(1)

    config = load_config()
    with RegistryClient(config) as client:
        node_id = _create_node(client, endpoint, alias)
        _set_node_secret(client, node_id, secret)
        _set_node_price(client, node_id, price)

    config.active_miner_node = alias
    save_config(config)

    console.print(f"\n[dim]Active node set to '{alias}'[/dim]")


def _default_alias(endpoint: str) -> str:
    """Derive a default alias from an endpoint URL."""
    host = endpoint.replace("wss://", "").replace("ws://", "")
    host = host.split(":")[0].split("/")[0]
    return f"tao-{host.replace('.', '-')}"


def _create_node(client: RegistryClient, endpoint: str, alias: str) -> str:
    """Register a node and return its ID."""
    response = client.post(
        "/nodes",
        json={"endpoint": endpoint, "chain": CHAIN, "alias": alias},
    )
    if response.status_code == 201:
        data = response.json()
        console.print(f"[green]Node registered:[/green] {data['id'][:8]}")
        return data["id"]
    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code == 409:
        detail = response.json().get("detail", "Alias already exists")
        console.print(f"[red]Conflict:[/red] {detail}")
        raise typer.Exit(1)
    console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
    raise typer.Exit(1)


def _set_node_secret(client: RegistryClient, node_id: str, secret: str) -> None:
    """Set the secret on a node."""
    response = client.post(
        f"/nodes/{node_id}/secret",
        json={"secret": secret, "rotate": False},
    )
    if response.status_code == 201:
        console.print("[green]Secret set[/green]")
        return
    console.print(
        f"[red]Failed to set secret:[/red] {response.status_code} - {response.text}"
    )
    raise typer.Exit(1)


def _set_node_price(client: RegistryClient, node_id: str, price: str) -> None:
    """Set the price on a node."""
    epoch_length_sec = 300 * 12
    epoch = int(time.time() / epoch_length_sec) + 1

    response = client.post(
        f"/nodes/{node_id}/price",
        json={
            "target_usd_per_cu": price,
            "effective_from_epoch": epoch,
        },
    )
    if response.status_code == 201:
        data = response.json()
        console.print(
            f"[green]Price set:[/green]"
            f" {data['target_usd_per_cu']} USD/CU"
            f" (epoch {data['effective_from_epoch']})"
        )
        return
    console.print(
        f"[red]Failed to set price:[/red] {response.status_code} - {response.text}"
    )
    raise typer.Exit(1)


@app.command("use")
def use(
    alias: str = typer.Argument(..., help="Node alias to set as active"),
) -> None:
    """Set the active miner node for subsequent commands."""
    config = load_config()
    config.active_miner_node = alias
    save_config(config)
    console.print(f"Active miner node: [bold]{alias}[/bold]")


@app.command("ls")
def ls() -> None:
    """List all miner nodes."""
    config = load_config()
    with RegistryClient(config) as client:
        response = client.get("/nodes")

    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    nodes = response.json().get("nodes", [])
    if not nodes:
        console.print("[dim]No nodes registered[/dim]")
        return

    active = config.active_miner_node
    table = Table(title="Miner Nodes")
    table.add_column("", width=1)
    table.add_column("Alias")
    table.add_column("Chain")
    table.add_column("Status")
    table.add_column("Endpoint")
    table.add_column("Last Seen")

    for node in nodes:
        status_color = {
            "active": "green",
            "pending": "yellow",
            "unreachable": "red",
            "suspended": "red",
        }.get(node["status"], "white")
        marker = "*" if node.get("alias") == active else ""

        table.add_row(
            marker,
            node.get("alias") or node["id"][:8],
            node["chain"],
            f"[{status_color}]{node['status']}[/{status_color}]",
            _truncate(node["endpoint"], 40),
            format_timestamp(node.get("last_seen_at")),
        )

    console.print(table)


def _truncate(text: str, length: int) -> str:
    if len(text) <= length:
        return text
    return text[:length] + "..."


@app.command("show")
def show(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show details of a miner node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}")

    if response.status_code == 404:
        console.print(f"[red]Node not found:[/red] {alias}")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    node = response.json()
    console.print(f"[bold]ID:[/bold] {node['id']}")
    console.print(f"[bold]Alias:[/bold] {node.get('alias') or '-'}")
    console.print(f"[bold]Chain:[/bold] {node['chain']}")
    console.print(f"[bold]Status:[/bold] {node['status']}")
    console.print(f"[bold]Endpoint:[/bold] {node['endpoint']}")
    console.print(f"[bold]Created:[/bold] {format_timestamp(node['created_at'])}")
    console.print(
        f"[bold]Last Seen:[/bold] {format_timestamp(node.get('last_seen_at'))}"
    )


@app.command("rm")
def rm(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Remove a miner node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)

        if not force:
            confirm = typer.confirm(f"Delete node {alias}?")
            if not confirm:
                console.print("[dim]Cancelled[/dim]")
                return

        response = client.delete(f"/nodes/{node_id}")

    if response.status_code == 204:
        console.print("[green]Node deleted[/green]")
        if config.active_miner_node == alias:
            config.active_miner_node = None
            save_config(config)
    elif response.status_code == 404:
        console.print(f"[red]Node not found:[/red] {alias}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@app.command("update")
def update(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    new_alias: str = typer.Option(None, "--alias", "-a", help="New alias"),
    endpoint: str = typer.Option(None, "--endpoint", "-e", help="New endpoint"),
) -> None:
    """Update a node's alias or endpoint."""
    alias = _get_alias(alias)

    if not new_alias and not endpoint:
        console.print(
            "[yellow]Nothing to update. Specify --alias or --endpoint[/yellow]"
        )
        return

    config = load_config()
    update_data: dict = {}
    if new_alias:
        update_data["alias"] = new_alias
    if endpoint:
        update_data["endpoint"] = endpoint

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.patch(f"/nodes/{node_id}", json=update_data)

    if response.status_code == 200:
        console.print("[green]Node updated[/green]")
        if new_alias and config.active_miner_node == alias:
            config.active_miner_node = new_alias
            save_config(config)
    elif response.status_code == 409:
        detail = response.json().get("detail", "Alias already exists")
        console.print(f"[red]Conflict:[/red] {detail}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


# ── Secrets ──────────────────────────────────────────────────────


@secret_app.command("set")
def secret_set(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    secret: str = typer.Option(
        None,
        "--secret",
        "-s",
        help="Secret value (will prompt if not provided)",
    ),
) -> None:
    """Set the bearer token secret for a node."""
    alias = _get_alias(alias)

    if not secret:
        secret = getpass.getpass("Enter secret: ")
        confirm = getpass.getpass("Confirm secret: ")
        if secret != confirm:
            console.print("[red]Secrets do not match[/red]")
            raise typer.Exit(1)

    if len(secret) < 16:
        console.print("[red]Secret must be at least 16 characters[/red]")
        raise typer.Exit(1)

    config = load_config()
    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.post(
            f"/nodes/{node_id}/secret",
            json={"secret": secret, "rotate": False},
        )

    if response.status_code == 201:
        data = response.json()
        console.print("[green]Secret set[/green]")
        console.print(f"[bold]Version:[/bold] {data['version']}")
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@secret_app.command("show")
def secret_show(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show secret metadata (not the secret itself)."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/secret")

    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    secrets = response.json().get("secrets", [])
    if not secrets:
        console.print("[dim]No secrets configured[/dim]")
        return

    table = Table(title="Secrets")
    table.add_column("Version")
    table.add_column("State")
    table.add_column("Created")

    for s in secrets:
        color = {"active": "green", "next": "yellow", "retired": "dim"}.get(
            s["state"], "white"
        )
        table.add_row(
            str(s["version"]),
            f"[{color}]{s['state']}[/{color}]",
            format_timestamp(s["created_at"]),
        )

    console.print(table)


@secret_app.command("promote")
def secret_promote(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Promote the 'next' secret to 'active'."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.post(f"/nodes/{node_id}/secret/promote")

    if response.status_code == 200:
        data = response.json()
        console.print("[green]Secret promoted[/green]")
        console.print(f"[bold]Version:[/bold] {data['version']}")
    else:
        detail = response.json().get("detail", response.text)
        console.print(f"[red]Error:[/red] {detail}")
        raise typer.Exit(1)


# ── Pricing ──────────────────────────────────────────────────────


@price_app.command("set")
def price_set(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    price: str = typer.Option(..., "--price", "-p", help="Target USD per compute unit"),
    epoch: int = typer.Option(
        None,
        "--epoch",
        "-e",
        help="Effective from epoch (default: next epoch)",
    ),
) -> None:
    """Set a price for a node."""
    alias = _get_alias(alias)

    if epoch is None:
        epoch_length_sec = 300 * 12
        epoch = int(time.time() / epoch_length_sec) + 1

    config = load_config()
    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.post(
            f"/nodes/{node_id}/price",
            json={
                "target_usd_per_cu": price,
                "effective_from_epoch": epoch,
            },
        )

    if response.status_code == 201:
        data = response.json()
        console.print(
            f"[green]Price set:[/green]"
            f" {data['target_usd_per_cu']} USD/CU"
            f" (epoch {data['effective_from_epoch']})"
        )
    elif response.status_code == 400:
        detail = response.json().get("detail", "Invalid request")
        console.print(f"[red]Error:[/red] {detail}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@price_app.command("show")
def price_show(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show the current price for a node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/price")

    if response.status_code == 200:
        data = response.json()
        console.print(f"[bold]Price:[/bold] {data['target_usd_per_cu']} USD/CU")
        console.print(
            f"[bold]Effective from epoch:[/bold] {data['effective_from_epoch']}"
        )
        console.print(f"[bold]Set at:[/bold] {format_timestamp(data['created_at'])}")
    elif response.status_code == 404:
        detail = response.json().get("detail", "Not found")
        if "No price" in detail:
            console.print("[dim]No price set for this node[/dim]")
        else:
            console.print(f"[red]Node not found:[/red] {alias}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@price_app.command("history")
def price_history(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show price history for a node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/price/history")

    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    prices = response.json().get("prices", [])
    if not prices:
        console.print("[dim]No price history[/dim]")
        return

    table = Table(title="Price History")
    table.add_column("Epoch")
    table.add_column("Price (USD/CU)")
    table.add_column("Set At")

    for p in prices:
        table.add_row(
            str(p["effective_from_epoch"]),
            p["target_usd_per_cu"],
            format_timestamp(p["created_at"]),
        )

    console.print(table)
