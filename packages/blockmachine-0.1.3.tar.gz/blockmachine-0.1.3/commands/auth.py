"""Authentication helpers for OAuth device flow"""

import time
import webbrowser

import httpx
import typer
from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner

from cli import settings
from cli.config import CLIConfig, load_config, save_config, validate_token

console = Console()


def device_login(
    scopes: list[str],
    client_id: str | None = None,
    auth_url: str | None = None,
    api_url: str | None = None,
    no_browser: bool = False,
) -> None:
    """Run the OAuth device code flow with the given scopes."""
    client_id = client_id or settings.CLIENT_ID
    auth_url = auth_url or settings.auth_url()

    config = load_config()
    config.client_id = client_id
    config.auth_url = auth_url
    if api_url:
        config.api_url = api_url

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                f"{auth_url}/v1/device/code",
                json={"client_id": client_id, "scopes": scopes},
            )
            response.raise_for_status()
            device_data = response.json()

            device_code = device_data["device_code"]
            user_code = device_data["user_code"]
            verification_uri = device_data["verification_uri"]
            interval = device_data.get("interval", 5)
            expires_in = device_data.get("expires_in", 900)

            verify_url = f"{verification_uri}?user_code={user_code}"

            console.print()
            console.print("[bold]To authenticate, visit:[/bold]")
            console.print(f"  [cyan]{verify_url}[/cyan]")
            console.print()
            console.print(f"[bold]Code:[/bold] [yellow]{user_code}[/yellow]")
            console.print()

            if not no_browser:
                try:
                    webbrowser.open(verify_url)
                    console.print("[dim]Browser opened automatically.[/dim]")
                except Exception:
                    console.print(
                        "[dim]Could not open browser. Please visit the URL above.[/dim]"
                    )

            _poll_for_token(
                client,
                config,
                auth_url,
                client_id,
                device_code,
                interval,
                expires_in,
            )

    except httpx.HTTPStatusError as e:
        console.print(
            f"[red]API error:[/red] {e.response.status_code} - {e.response.text}"
        )
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


def _poll_for_token(
    client: httpx.Client,
    config: CLIConfig,
    auth_url: str,
    client_id: str,
    device_code: str,
    interval: int,
    expires_in: int,
) -> None:
    """Poll the token endpoint until authorization completes."""
    deadline = time.time() + expires_in
    poll_interval = interval

    with Live(
        Spinner("dots", text="Waiting for browser authorization..."),
        console=console,
        transient=True,
    ):
        while time.time() < deadline:
            time.sleep(poll_interval)

            token_response = client.post(
                f"{auth_url}/v1/device/token",
                json={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": ("urn:ietf:params:oauth:grant-type:device_code"),
                },
            )

            if token_response.status_code == 200:
                _save_token_response(config, token_response.json())
                return

            error = _extract_error(token_response)
            if error == "authorization_pending":
                continue
            if error == "slow_down":
                poll_interval += 5
                continue
            if error == "expired_token":
                console.print("\n[red]Login timed out.[/red] Please try again.")
                raise typer.Exit(1)
            if error == "access_denied":
                console.print("\n[red]Login was denied.[/red]")
                raise typer.Exit(1)

            console.print(f"\n[red]Error:[/red] {error}")
            raise typer.Exit(1)

    console.print("\n[red]Login timed out.[/red] Please try again.")
    raise typer.Exit(1)


def _save_token_response(config: CLIConfig, token_data: dict) -> None:
    """Validate and persist a token response."""
    from datetime import datetime, timedelta, timezone

    access_token = token_data["access_token"]

    claims = validate_token(access_token)
    if claims is None:
        console.print(
            "\n[red]Token validation failed.[/red]"
            " The token issuer or signature is invalid."
        )
        raise typer.Exit(1)

    token_expires_in = token_data.get("expires_in", 3600)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=token_expires_in)

    config.access_token = access_token
    config.refresh_token = token_data.get("refresh_token")
    config.token_expires_at = expires_at.isoformat()
    save_config(config)

    console.print("\n[green]Login successful![/green]")
    exp_str = expires_at.strftime("%Y-%m-%d %H:%M:%S UTC")
    console.print(f"[dim]Token expires: {exp_str}[/dim]")

    scopes = claims.get("scopes", token_data.get("scopes", []))
    if scopes:
        console.print(f"[dim]Scopes: {', '.join(scopes)}[/dim]")


def _extract_error(response: httpx.Response) -> str:
    """Extract error string from a token endpoint response."""
    try:
        data = response.json()
        return data.get("error_description") or data.get("error", "")
    except Exception:
        return f"HTTP {response.status_code}"


def check_status() -> None:
    """Print current authentication status."""
    from cli.config import is_token_valid

    config = load_config()

    console.print(f"[bold]API URL:[/bold] {config.api_url}")
    console.print(f"[bold]Auth provider:[/bold] {config.auth_url}")
    console.print(f"[bold]Client ID:[/bold] {config.client_id}")

    if config.access_token:
        if is_token_valid(config):
            claims = validate_token(config.access_token)
            if claims:
                console.print(
                    f"[green]Token valid[/green]"
                    f" (issuer: {claims.get('iss', 'unknown')})"
                )
                scopes = claims.get("scopes", [])
                if scopes:
                    console.print(f"[dim]Scopes: {', '.join(scopes)}[/dim]")
                sub = claims.get("sub")
                if sub:
                    console.print(f"[dim]Subject: {sub}[/dim]")
        else:
            console.print("[yellow]Token expired or invalid[/yellow]")

        if config.refresh_token:
            console.print("[dim]Refresh token: available[/dim]")
        else:
            console.print("[dim]Refresh token: not available[/dim]")
    else:
        console.print("[red]Not logged in[/red]")


def do_logout() -> None:
    """Clear stored authentication tokens."""
    from cli.config import clear_token

    config = load_config()
    clear_token(config)
    console.print("[green]Logged out[/green]")
