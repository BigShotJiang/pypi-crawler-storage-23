"""Generators module for creating test samples."""

from mankinds_eval.generators.base import Generator

__all__ = ["Generator"]
