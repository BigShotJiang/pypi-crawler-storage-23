"""Command line interface for mankinds-eval."""

from mankinds_eval.cli.main import app, main

__all__ = ["app", "main"]
