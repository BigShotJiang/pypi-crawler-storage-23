"""Core module."""

from mankinds_eval.core.result import MethodResult
from mankinds_eval.core.sample import Sample

__all__ = ["MethodResult", "Sample"]
