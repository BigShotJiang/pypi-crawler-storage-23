# Changelog

All notable changes to CoSig will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0a1] - 2026-02-08

### Changed
- **Python 3.12+** — dropped Python 3.11 support; added Python 3.14 to CI matrix
- Fixed build system references from `app/` to `cosig/` (CI, Makefile, MANIFEST.in)
- Added PEP 561 `py.typed` marker file
- Removed standalone server mode references from documentation
- Rewrote configuration section to show `cosig.configure()` API
- Cleaned up README, QUICKSTART, KNOWN_ISSUES, and SECURITY docs

### Fixed
- CI workflow now lints and tests the correct `cosig/` package directory
- Coverage reporting targets `cosig/` instead of non-existent `app/`
- MANIFEST.in includes `cosig/` sources instead of `app/`
- Removed references to non-existent `register.html` and `test.html`

## [0.1.0a1] - 2024-12-23

### Alpha Release

This is the initial alpha release of CoSig. APIs may change in future releases.

**Status**: Early development - see [KNOWN_ISSUES.md](KNOWN_ISSUES.md) for current limitations.

### Added
- Initial release of CoSig decorator library for MCP servers
- BSD-3-Clause License
- `@require_approval()` decorator for FastMCP integration
- Hardware token (YubiKey, Touch ID, Windows Hello) authentication
- WebAuthn implementation with py_webauthn
- Plan hashing with SHA256 and canonical JSON
- State machine for plan lifecycle (PENDING → APPROVED → EXECUTED)
- Replay attack prevention with sign counter validation
- Append-only audit logging with hash chaining
- SQLite and PostgreSQL support via SQLAlchemy
- FastAPI integration with CORS support

### Security Features
- Cryptographic binding of challenges to plan hashes
- Unique plan hash constraint prevents replay attacks
- Challenge expiry (5-minute TTL)
- Sign counter validation to detect cloned authenticators

### Known Limitations
- FastMCP integration may have issues with complex tool signatures
- PostgreSQL support not fully tested in production
- Some browser compatibility issues (see KNOWN_ISSUES.md)
- Error handling could be improved
- No rate limiting on approval endpoints

[0.2.0a1]: https://github.com/skyforest/cosig/releases/tag/v0.2.0a1
[0.1.0a1]: https://github.com/skyforest/cosig/releases/tag/v0.1.0a1
