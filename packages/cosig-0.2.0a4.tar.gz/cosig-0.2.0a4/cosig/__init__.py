# Copyright (c) 2024, CoSig Contributors
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""CoSig - Hardware token approval for AI agent tool calls.

CoSig provides WebAuthn-enabled co-signing for sensitive operations,
ensuring human approval via hardware tokens (YubiKey, etc.) before
AI agents can execute protected tools.

Quick Start:

    from cosig import configure, require_approval

    # Configure to use CoSig cloud (or self-hosted instance)
    # api_key is your organization-level API key
    configure(
        api_url="https://api.cosig.io",
        api_key="sk-your-org-api-key",
    )

    # Use with FastMCP
    from fastmcp import FastMCP

    mcp = FastMCP("My Server")

    # Option 1: Pass username in decorator (for single-user tools)
    @mcp.tool()
    @require_approval(username="alice")
    async def delete_customer_data(customer_id: str) -> str:
        '''Delete customer PII - requires human co-signature'''
        await db.execute("DELETE FROM customers WHERE id = $1", customer_id)
        return f"Deleted {customer_id}"

    # Option 2: Pass username at runtime (for multi-user apps)
    @mcp.tool()
    @require_approval()
    async def delete_user(username: str, user_id: str) -> str:
        '''Username automatically extracted from function args'''
        await db.execute("DELETE FROM users WHERE id = $1", user_id)
        return f"Deleted {user_id}"

The decorator will:
1. Create an approval request in CoSig for the specified user
2. Raise ApprovalRequiredError with the approval URL
3. User approves via YubiKey tap on the CoSig dashboard
4. On retry, the tool executes successfully

For AI agents, use wait_for_approval=True to poll automatically:

    @mcp.tool()
    @require_approval(wait_for_approval=True)
    async def dangerous_operation(username: str, data: str) -> str:
        # Waits for approval, then executes automatically
        return perform_operation(data)
"""

from cosig.cloud_client import (
    ApprovalPendingError,
    CloudClientError,
    CoSigCloudClient,
    get_cloud_client,
)
from cosig.config import (
    ConfigurationError,
    CoSigConfig,
    configure,
    get_config,
)
from cosig.fastmcp_integration import ApprovalRequiredError, require_approval

__version__ = "0.2.0a1"

__all__ = [
    # FastMCP integration - main decorator
    "require_approval",
    "ApprovalRequiredError",
    # Configuration
    "configure",
    "get_config",
    "CoSigConfig",
    "ConfigurationError",
    # Cloud client (for advanced usage)
    "CoSigCloudClient",
    "get_cloud_client",
    "CloudClientError",
    "ApprovalPendingError",
    # Version
    "__version__",
]
