## 0.0.10 (2022-02-24)
### Fix

- Handled PipeError, such as when piping to head, for example.
