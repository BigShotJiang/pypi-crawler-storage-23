"""
This module contains package tests.
"""
