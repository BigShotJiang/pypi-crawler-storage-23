"""Tests for user_auth_client."""

import pytest
import requests
from unittest.mock import Mock, patch

from user_auth_client import AuthClient, SignupData, LoginData
from user_auth_client.exceptions import AuthClientError, AuthClientAuthError


@pytest.fixture
def client():
    return AuthClient(base_url="https://api.test.com")


def test_signup_success(client):
    with patch.object(client._session, "request") as req:
        req.return_value = Mock(status_code=200, content=b'{"id":"1","email":"a@b.c"}')
        req.return_value.json.return_value = {"id": "1", "email": "a@b.c"}
        result = client.signup(SignupData(email="a@b.c", password="secret"))
    assert result["email"] == "a@b.c"


def test_login_sets_token(client):
    with patch.object(client._session, "request") as req:
        req.return_value = Mock(status_code=200, content=b'{"access_token":"xyz"}')
        req.return_value.json.return_value = {"access_token": "xyz"}
        client.login(LoginData(email="a@b.c", password="secret"))
    assert client._token == "xyz"


def test_reset_password(client):
    with patch.object(client._session, "request") as req:
        req.return_value = Mock(status_code=200, content=b'{"ok":true}')
        req.return_value.json.return_value = {"ok": True}
        result = client.reset_password("a@b.c")
    assert result["ok"] is True


def test_get_profile(client):
    client.set_token("abc")
    with patch.object(client._session, "request") as req:
        req.return_value = Mock(status_code=200, content=b'{"id":"1","email":"a@b.c"}')
        req.return_value.json.return_value = {"id": "1", "email": "a@b.c"}
        profile = client.get_profile()
    assert profile.email == "a@b.c"
    assert profile.id == "1"


def test_401_raises_auth_error(client):
    with patch.object(client._session, "request") as req:
        req.return_value = Mock(status_code=401, content=b'{"error":"Unauthorized"}', reason="Unauthorized")
        req.return_value.json.return_value = {"error": "Unauthorized"}
        with pytest.raises(AuthClientAuthError) as exc:
            client.login(LoginData(email="a@b.c", password="wrong"))
    assert exc.value.status_code == 401
