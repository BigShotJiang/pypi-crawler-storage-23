"""Custom exceptions for the auth client."""

from typing import Optional


class AuthClientError(Exception):
    """Base exception for auth client errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class AuthClientConnectionError(AuthClientError):
    """Raised when the request fails due to connection/network issues."""


class AuthClientAuthError(AuthClientError):
    """Raised when authentication fails (e.g. invalid credentials, expired token)."""
