"""Flask integration for user_auth_client."""

from typing import Optional

from flask import g, request

from user_auth_client.client import AuthClient
from user_auth_client.exceptions import AuthClientAuthError
from user_auth_client.models import UserProfile
from user_auth_client._utils import get_bearer_token


def get_auth_client(
    base_url: str,
    timeout: float = 30.0,
    headers: Optional[dict] = None,
) -> AuthClient:
    """Build an AuthClient for use in Flask views."""
    return AuthClient(base_url=base_url, timeout=timeout, headers=headers)


def get_client_from_request(base_url: str, timeout: float = 30.0) -> AuthClient:
    """
    Build an AuthClient with the token from the current request's Authorization header.

    Usage:
        from flask import Flask
        from user_auth_client.flask import get_client_from_request

        app = Flask(__name__)
        app.config["AUTH_API_URL"] = "https://auth.example.com"

        @app.route("/profile")
        def profile():
            client = get_client_from_request(app.config["AUTH_API_URL"])
            return client.get_profile().raw
    """
    client = get_auth_client(base_url=base_url, timeout=timeout)
    token = get_bearer_token(request.headers.get("Authorization"))
    if token:
        client.set_token(token)
    return client


def get_current_user(base_url: str, timeout: float = 30.0) -> Optional[UserProfile]:
    """
    Return the current user profile from the request's Bearer token, or None if missing/invalid.

    Usage:
        from user_auth_client.flask import get_current_user

        @app.route("/me")
        def me():
            user = get_current_user(app.config["AUTH_API_URL"])
            if not user:
                return {"error": "Unauthorized"}, 401
            return {"email": user.email}
    """
    client = get_client_from_request(base_url=base_url, timeout=timeout)
    if not client._token:
        return None
    try:
        return client.get_profile()
    except AuthClientAuthError:
        return None


def init_app(app, url_key: str = "AUTH_API_URL", timeout: float = 30.0) -> None:
    """
    Register helpers on the Flask app so g.auth_client and g.current_user are available.

    Call in your app factory:
        from user_auth_client.flask import init_app
        init_app(app)

    Then in views:
        from flask import g
        profile = g.current_user  # set by before_request if Bearer present
    """
    base_url = app.config.get(url_key, "")
    if not base_url:
        return

    @app.before_request
    def _before_request() -> None:
        g.auth_client = get_auth_client(base_url=base_url, timeout=timeout)
        token = get_bearer_token(request.headers.get("Authorization"))
        if token:
            g.auth_client.set_token(token)
            try:
                g.current_user = g.auth_client.get_profile()
            except AuthClientAuthError:
                g.current_user = None
        else:
            g.current_user = None
