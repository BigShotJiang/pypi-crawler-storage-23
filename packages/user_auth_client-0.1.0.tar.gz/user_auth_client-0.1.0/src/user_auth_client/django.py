"""Django integration for user_auth_client."""

from typing import Optional

from user_auth_client.client import AuthClient
from user_auth_client.exceptions import AuthClientAuthError
from user_auth_client.models import UserProfile
from user_auth_client._utils import get_bearer_token


def get_auth_client(
    base_url: str,
    timeout: float = 30.0,
    headers: Optional[dict] = None,
) -> AuthClient:
    """
    Build an AuthClient for use in Django views.

    Prefer reading base_url from settings, e.g.:
        from django.conf import settings
        client = get_auth_client(getattr(settings, 'AUTH_API_URL', 'http://localhost:8000'))
    """
    return AuthClient(base_url=base_url, timeout=timeout, headers=headers)


def get_client_from_request(request, base_url: str, timeout: float = 30.0) -> AuthClient:
    """
    Build an AuthClient and set the token from the request's Authorization header.

    Usage in a view:
        from user_auth_client.django import get_client_from_request
        from django.conf import settings

        def my_view(request):
            client = get_client_from_request(request, settings.AUTH_API_URL)
            profile = client.get_profile()  # uses Bearer from request
    """
    client = get_auth_client(base_url=base_url, timeout=timeout)
    token = get_bearer_token(request.headers.get("Authorization") if hasattr(request, "headers") else request.META.get("HTTP_AUTHORIZATION"))
    if token:
        client.set_token(token)
    return client


def get_current_user(request, base_url: str, timeout: float = 30.0) -> Optional[UserProfile]:
    """
    Return the current user profile from the request's Bearer token, or None if missing/invalid.

    Usage:
        from user_auth_client.django import get_current_user
        from django.conf import settings

        def my_view(request):
            user = get_current_user(request, settings.AUTH_API_URL)
            if not user:
                return JsonResponse({"error": "Unauthorized"}, status=401)
            return JsonResponse({"email": user.email})
    """
    client = get_client_from_request(request, base_url=base_url, timeout=timeout)
    if not client._token:
        return None
    try:
        return client.get_profile()
    except AuthClientAuthError:
        return None
