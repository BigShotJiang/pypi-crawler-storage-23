"""User authentication client: signup, login, reset password, get profile."""

from user_auth_client.client import AuthClient
from user_auth_client.exceptions import (
    AuthClientError,
    AuthClientConnectionError,
    AuthClientAuthError,
)
from user_auth_client.models import UserProfile, SignupData, LoginData

__version__ = "0.1.0"
__all__ = [
    "AuthClient",
    "AuthClientError",
    "AuthClientConnectionError",
    "AuthClientAuthError",
    "UserProfile",
    "SignupData",
    "LoginData",
    "__version__",
]
