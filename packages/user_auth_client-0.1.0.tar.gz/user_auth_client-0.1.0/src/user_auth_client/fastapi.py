"""FastAPI integration for user_auth_client."""

from typing import Optional

from user_auth_client.client import AuthClient
from user_auth_client.exceptions import AuthClientAuthError
from user_auth_client.models import UserProfile
from user_auth_client._utils import get_bearer_token


def get_auth_client(
    base_url: str,
    timeout: float = 30.0,
    headers: Optional[dict] = None,
) -> AuthClient:
    """Build an AuthClient. Use with FastAPI dependency injection."""
    return AuthClient(base_url=base_url, timeout=timeout, headers=headers)


def auth_client_depends(base_url: str, timeout: float = 30.0):
    """
    Return a FastAPI Depends() that provides an AuthClient.

    Usage:
        from fastapi import Depends
        from user_auth_client.fastapi import auth_client_depends, get_current_user_depends

        app = FastAPI()
        get_client = auth_client_depends("https://auth.example.com")

        @app.get("/profile")
        def profile(client: AuthClient = Depends(get_client), user: UserProfile = Depends(get_current_user_depends("https://auth.example.com"))):
            return user.raw
    """
    from fastapi import Depends, Request

    def _get_client(request: Request) -> AuthClient:
        client = get_auth_client(base_url=base_url, timeout=timeout)
        auth = request.headers.get("Authorization")
        token = get_bearer_token(auth)
        if token:
            client.set_token(token)
        return client

    return Depends(_get_client)


def get_current_user_depends(base_url: str, timeout: float = 30.0):
    """
    Return a FastAPI Depends() that provides the current UserProfile from the Bearer token.
    Raises 401 if no/invalid token.
    """
    from fastapi import Depends, HTTPException, Request

    def _get_user(request: Request) -> UserProfile:
        client = get_auth_client(base_url=base_url, timeout=timeout)
        token = get_bearer_token(request.headers.get("Authorization"))
        if not token:
            raise HTTPException(status_code=401, detail="Missing or invalid authorization")
        client.set_token(token)
        try:
            return client.get_profile()
        except AuthClientAuthError as e:
            raise HTTPException(status_code=401, detail=str(e.message)) from e

    return Depends(_get_user)
