"""Data models for requests and responses."""

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SignupData:
    """Data required for user signup."""

    email: str
    password: str
    username: Optional[str] = None
    extra: Optional[dict[str, Any]] = None


@dataclass
class LoginData:
    """Data required for login."""

    email: str
    password: str


@dataclass
class UserProfile:
    """User profile returned by get_profile."""

    id: str
    email: str
    username: Optional[str] = None
    raw: Optional[dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "UserProfile":
        """Build UserProfile from API response dict."""
        return cls(
            id=str(data.get("id", "")),
            email=str(data.get("email", "")),
            username=data.get("username"),
            raw=data,
        )
