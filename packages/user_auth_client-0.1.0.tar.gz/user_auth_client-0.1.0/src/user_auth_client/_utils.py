"""Extract Bearer token from Authorization header."""

from typing import Optional


def get_bearer_token(authorization: Optional[str]) -> Optional[str]:
    """Return token from 'Bearer <token>' or None."""
    if not authorization or not isinstance(authorization, str):
        return None
    parts = authorization.strip().split()
    if len(parts) == 2 and parts[0].lower() == "bearer":
        return parts[1] or None
    return None
