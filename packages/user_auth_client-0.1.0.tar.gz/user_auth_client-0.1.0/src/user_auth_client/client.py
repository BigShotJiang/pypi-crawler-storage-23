"""HTTP client for user auth API: signup, login, reset password, get profile."""

from typing import Any, Optional

import requests

from user_auth_client.exceptions import (
    AuthClientError,
    AuthClientConnectionError,
    AuthClientAuthError,
)
from user_auth_client.models import LoginData, SignupData, UserProfile


class AuthClient:
    """
    Client for user authentication APIs.

    Configure with your API base URL and optional default headers.
    All methods return parsed JSON or raise AuthClientError subclasses.
    """

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
        headers: Optional[dict[str, str]] = None,
    ):
        """
        Args:
            base_url: Base URL of the auth API (e.g. https://api.example.com).
            timeout: Request timeout in seconds.
            headers: Optional default headers for every request.
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(headers or {})
        self._token: Optional[str] = None

    def _request(
        self,
        method: str,
        path: str,
        json: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}/{path.lstrip('/')}"
        h = dict(self._session.headers)
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        if headers:
            h.update(headers)
        try:
            resp = self._session.request(
                method, url, json=json, headers=h, timeout=self.timeout
            )
        except requests.RequestException as e:
            raise AuthClientConnectionError(str(e)) from e

        try:
            data = resp.json() if resp.content else {}
        except ValueError:
            data = {}

        if not resp.ok:
            msg = data.get("message") or data.get("error") or resp.reason or "Unknown error"
            if resp.status_code in (401, 403):
                raise AuthClientAuthError(msg, status_code=resp.status_code)
            raise AuthClientError(msg, status_code=resp.status_code)

        return data if isinstance(data, dict) else {"data": data}

    def set_token(self, token: str) -> None:
        """Set bearer token for authenticated requests (e.g. after login)."""
        self._token = token

    def clear_token(self) -> None:
        """Clear the stored bearer token."""
        self._token = None

    def signup(self, data: SignupData) -> dict[str, Any]:
        """
        Register a new user.

        Args:
            data: SignupData with email, password, optional username and extra.

        Returns:
            API response (typically user + token or success message).

        Raises:
            AuthClientError: On API or validation errors.
            AuthClientConnectionError: On network errors.
        """
        payload: dict[str, Any] = {
            "email": data.email,
            "password": data.password,
        }
        if data.username is not None:
            payload["username"] = data.username
        if data.extra:
            payload.update(data.extra)
        return self._request("POST", "/auth/signup", json=payload)

    def login(self, data: LoginData) -> dict[str, Any]:
        """
        Log in with email and password.

        Returns:
            API response (typically access_token and optionally user).
            Use set_token(response["access_token"]) if your API returns a token.

        Raises:
            AuthClientAuthError: On invalid credentials.
            AuthClientError: On other API errors.
            AuthClientConnectionError: On network errors.
        """
        payload = {"email": data.email, "password": data.password}
        result = self._request("POST", "/auth/login", json=payload)
        if "access_token" in result:
            self.set_token(result["access_token"])
        return result

    def reset_password(self, email: str) -> dict[str, Any]:
        """
        Request a password reset for the given email.

        Args:
            email: User email to send reset instructions to.

        Returns:
            API response (e.g. success message or confirmation).
        """
        return self._request(
            "POST", "/auth/reset-password", json={"email": email}
        )

    def get_profile(self) -> UserProfile:
        """
        Get the current user's profile (requires prior login/set_token).

        Returns:
            UserProfile with id, email, username and raw response.

        Raises:
            AuthClientAuthError: If not authenticated or token invalid.
        """
        data = self._request("GET", "/auth/profile")
        # Support both top-level user object and flat response
        user = data.get("user", data)
        return UserProfile.from_dict(user)
