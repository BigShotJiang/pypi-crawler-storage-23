"""
Tests for fred-toolkit

Basic tests to verify package functionality.
"""

import os
import pytest
from fred_toolkit import (
    FredTools,
    get_tool_definitions,
    get_tool_names,
    fred_browse,
    fred_search,
    fred_get_series,
)


def test_tool_definitions():
    """Test that tool definitions are returned correctly."""
    tools = get_tool_definitions()
    
    assert isinstance(tools, list)
    assert len(tools) == 3
    
    # Check structure
    for tool in tools:
        assert "type" in tool
        assert tool["type"] == "function"
        assert "function" in tool
        assert "name" in tool["function"]
        assert "description" in tool["function"]
        assert "parameters" in tool["function"]


def test_tool_names():
    """Test that tool names are returned correctly."""
    names = get_tool_names()
    
    assert names == ["fred_browse", "fred_search", "fred_get_series"]


def test_fred_tools_initialization():
    """Test FredTools initialization."""
    # Without API key (should not raise error at init)
    fred = FredTools()
    assert fred.api_key is None
    
    # With API key
    fred = FredTools(api_key="test-key")
    assert fred.api_key == "test-key"


def test_get_tool_definitions_method():
    """Test FredTools.get_tool_definitions() method."""
    fred = FredTools()
    tools = fred.get_tool_definitions()
    
    assert len(tools) == 3
    assert all(tool["type"] == "function" for tool in tools)


def test_get_tool_names_method():
    """Test FredTools.get_tool_names() method."""
    fred = FredTools()
    names = fred.get_tool_names()
    
    assert names == ["fred_browse", "fred_search", "fred_get_series"]


def test_execute_tool_unknown():
    """Test executing an unknown tool raises error."""
    fred = FredTools(api_key="test")
    
    with pytest.raises(ValueError, match="Unknown tool"):
        fred.execute_tool("unknown_tool", {})


@pytest.mark.skipif(not os.environ.get("FRED_API_KEY"), reason="FRED_API_KEY not set")
def test_fred_search_integration():
    """Integration test for fred_search (requires API key)."""
    result = fred_search(search_text="GDP", limit=5)
    
    assert "results" in result
    assert "total_results" in result
    assert isinstance(result["results"], list)


@pytest.mark.skipif(not os.environ.get("FRED_API_KEY"), reason="FRED_API_KEY not set")
def test_fred_get_series_integration():
    """Integration test for fred_get_series (requires API key)."""
    result = fred_get_series(series_id="GDP", limit=10)
    
    assert "series_id" in result
    assert result["series_id"] == "GDP"
    assert "data" in result
    assert isinstance(result["data"], list)


@pytest.mark.skipif(not os.environ.get("FRED_API_KEY"), reason="FRED_API_KEY not set")
def test_fred_browse_integration():
    """Integration test for fred_browse (requires API key)."""
    result = fred_browse(browse_type="categories")
    
    assert "categories" in result
    assert isinstance(result["categories"], list)


@pytest.mark.skipif(not os.environ.get("FRED_API_KEY"), reason="FRED_API_KEY not set")
def test_execute_tool_integration():
    """Integration test for execute_tool method."""
    fred = FredTools()
    
    # Test fred_search
    result = fred.execute_tool("fred_search", {"search_text": "unemployment", "limit": 3})
    assert "results" in result
    
    # Test fred_get_series
    result = fred.execute_tool("fred_get_series", {"series_id": "UNRATE", "limit": 5})
    assert result["series_id"] == "UNRATE"
    
    # Test fred_browse
    result = fred.execute_tool("fred_browse", {"browse_type": "categories"})
    assert "categories" in result


def test_tool_schema_structure():
    """Test that tool schemas have correct structure for OpenAI."""
    tools = get_tool_definitions()
    
    for tool in tools:
        func = tool["function"]
        params = func["parameters"]
        
        # Check required fields
        assert "type" in params
        assert params["type"] == "object"
        assert "properties" in params
        assert "required" in params
        
        # Check properties structure
        for prop_name, prop_def in params["properties"].items():
            assert "type" in prop_def
            assert "description" in prop_def


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
