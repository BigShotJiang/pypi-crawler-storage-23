"""
HTTP client for FRED API requests.

Handles all communication with the Federal Reserve Economic Data API.
"""

import os
from typing import Any, Dict, Optional
import httpx

BASE_URL = "https://api.stlouisfed.org/fred"


class FredAPIError(Exception):
    """Exception raised when FRED API returns an error."""
    
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"FRED API error ({status_code}): {message}")


async def make_request_async(
    endpoint: str,
    params: Optional[Dict[str, Any]] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Make an async request to the FRED API.
    
    Args:
        endpoint: API endpoint (e.g., 'series/observations')
        params: Query parameters
        api_key: FRED API key (falls back to FRED_API_KEY env var)
    
    Returns:
        JSON response from the API
    
    Raises:
        FredAPIError: If the API returns an error
    """
    key = api_key or os.environ.get("FRED_API_KEY")
    if not key:
        raise ValueError(
            "FRED API key is required. Pass api_key parameter or set FRED_API_KEY environment variable. "
            "Get your free API key at: https://fred.stlouisfed.org/docs/api/api_key.html"
        )
    
    query_params = dict(params) if params else {}
    query_params["api_key"] = key
    query_params["file_type"] = "json"
    
    url = f"{BASE_URL}/{endpoint}"
    
    async with httpx.AsyncClient() as client:
        response = await client.get(url, params=query_params, timeout=30.0)
        
        if not response.is_success:
            raise FredAPIError(response.status_code, response.text)
        
        return response.json()


def make_request(
    endpoint: str,
    params: Optional[Dict[str, Any]] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Make a synchronous request to the FRED API.
    
    Args:
        endpoint: API endpoint (e.g., 'series/observations')
        params: Query parameters
        api_key: FRED API key (falls back to FRED_API_KEY env var)
    
    Returns:
        JSON response from the API
    
    Raises:
        FredAPIError: If the API returns an error
    """
    key = api_key or os.environ.get("FRED_API_KEY")
    if not key:
        raise ValueError(
            "FRED API key is required. Pass api_key parameter or set FRED_API_KEY environment variable. "
            "Get your free API key at: https://fred.stlouisfed.org/docs/api/api_key.html"
        )
    
    query_params = dict(params) if params else {}
    query_params["api_key"] = key
    query_params["file_type"] = "json"
    
    url = f"{BASE_URL}/{endpoint}"
    
    with httpx.Client() as client:
        response = client.get(url, params=query_params, timeout=30.0)
        
        if not response.is_success:
            raise FredAPIError(response.status_code, response.text)
        
        return response.json()
