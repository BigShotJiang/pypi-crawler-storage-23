"""
fred-toolkit: FRED Economic Data Tools for LLM/Agent Integration

A Python package providing LLM-compatible tools for accessing 800,000+ 
Federal Reserve Economic Data (FRED) time series.

Example:
    >>> from fred_toolkit import FredTools
    >>> 
    >>> fred = FredTools(api_key="your-api-key")
    >>> 
    >>> # Get tool definitions for any LLM
    >>> tools = fred.get_tool_definitions()
    >>> 
    >>> # Execute tools by name (as LLM would call them)
    >>> result = fred.execute_tool("fred_search", {"search_text": "GDP"})
    >>> 
    >>> # Or use direct methods
    >>> data = fred.get_series("UNRATE")
"""

__version__ = "0.1.0"

from .client import FredTools
from .tools import get_tool_definitions, get_tool_names, get_tool_by_name, FRED_TOOLS
from .browse import fred_browse
from .search import fred_search, get_series_info
from .series import fred_get_series
from .request import FredAPIError

__all__ = [
    # Main client
    "FredTools",
    
    # Tool definitions
    "get_tool_definitions",
    "get_tool_names", 
    "get_tool_by_name",
    "FRED_TOOLS",
    
    # Individual tools
    "fred_browse",
    "fred_search",
    "fred_get_series",
    "get_series_info",
    
    # Exceptions
    "FredAPIError",
]
