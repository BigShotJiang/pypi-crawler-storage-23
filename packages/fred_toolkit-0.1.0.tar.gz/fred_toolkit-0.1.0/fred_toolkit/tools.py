"""
FRED Tool Definitions for LLM/Agent integration.

Provides OpenAI-compatible tool schemas that can be passed to any LLM
for function calling / tool use.
"""

from typing import Any, Dict, List


# Tool definitions in OpenAI function calling format
FRED_TOOLS: List[Dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "fred_browse",
            "description": (
                "Browse FRED's complete catalog through categories, releases, or sources. "
                "Use browse_type='categories' to explore the category tree, "
                "'releases' for data releases, 'sources' for data sources, "
                "'category_series' to get all series in a category, "
                "or 'release_series' to get all series in a release."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "browse_type": {
                        "type": "string",
                        "enum": ["categories", "releases", "sources", "category_series", "release_series"],
                        "description": "Type of browsing to perform"
                    },
                    "category_id": {
                        "type": "integer",
                        "description": "Category ID (for browsing subcategories or series within a category)"
                    },
                    "release_id": {
                        "type": "integer",
                        "description": "Release ID (for browsing series within a release)"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results (default: 50)",
                        "default": 50
                    },
                    "offset": {
                        "type": "integer",
                        "description": "Number of results to skip for pagination",
                        "default": 0
                    },
                    "order_by": {
                        "type": "string",
                        "description": "Field to order results by"
                    },
                    "sort_order": {
                        "type": "string",
                        "enum": ["asc", "desc"],
                        "description": "Sort order for results"
                    }
                },
                "required": ["browse_type"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "fred_search",
            "description": (
                "Search for FRED economic data series by keywords, tags, or filters. "
                "Use this to find series IDs for topics like unemployment, inflation, GDP, interest rates, etc."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "search_text": {
                        "type": "string",
                        "description": "Text to search for in series titles and descriptions"
                    },
                    "search_type": {
                        "type": "string",
                        "enum": ["full_text", "series_id"],
                        "description": "Type of search to perform"
                    },
                    "tag_names": {
                        "type": "string",
                        "description": "Comma-separated list of tag names to filter by"
                    },
                    "exclude_tag_names": {
                        "type": "string",
                        "description": "Comma-separated list of tag names to exclude"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results (default: 25, max: 1000)",
                        "default": 25
                    },
                    "offset": {
                        "type": "integer",
                        "description": "Number of results to skip for pagination",
                        "default": 0
                    },
                    "order_by": {
                        "type": "string",
                        "enum": [
                            "search_rank", "series_id", "title", "units", "frequency",
                            "seasonal_adjustment", "realtime_start", "realtime_end",
                            "last_updated", "observation_start", "observation_end", "popularity"
                        ],
                        "description": "Field to order results by"
                    },
                    "sort_order": {
                        "type": "string",
                        "enum": ["asc", "desc"],
                        "description": "Sort order for results"
                    },
                    "filter_variable": {
                        "type": "string",
                        "enum": ["frequency", "units", "seasonal_adjustment"],
                        "description": "Variable to filter by"
                    },
                    "filter_value": {
                        "type": "string",
                        "description": "Value to filter the variable by"
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "fred_get_series",
            "description": (
                "Retrieve data for any FRED series by its ID with support for transformations and date ranges. "
                "Common series: GDP (Gross Domestic Product), UNRATE (Unemployment Rate), "
                "CPIAUCSL (Consumer Price Index), FEDFUNDS (Federal Funds Rate), "
                "DGS10 (10-Year Treasury Rate), SP500 (S&P 500 Index)."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "series_id": {
                        "type": "string",
                        "description": "The FRED series ID (e.g., 'GDP', 'UNRATE', 'CPIAUCSL')"
                    },
                    "observation_start": {
                        "type": "string",
                        "description": "Start date for observations in YYYY-MM-DD format"
                    },
                    "observation_end": {
                        "type": "string",
                        "description": "End date for observations in YYYY-MM-DD format"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of observations to return"
                    },
                    "offset": {
                        "type": "integer",
                        "description": "Number of observations to skip"
                    },
                    "sort_order": {
                        "type": "string",
                        "enum": ["asc", "desc"],
                        "description": "Sort order of observations by date"
                    },
                    "units": {
                        "type": "string",
                        "enum": ["lin", "chg", "ch1", "pch", "pc1", "pca", "cch", "cca", "log"],
                        "description": (
                            "Data transformation: lin=levels (no transformation), "
                            "chg=change, ch1=change from year ago, pch=percent change, "
                            "pc1=percent change from year ago, pca=compounded annual rate, "
                            "cch=continuously compounded rate, log=natural log"
                        )
                    },
                    "frequency": {
                        "type": "string",
                        "enum": ["d", "w", "bw", "m", "q", "sa", "a"],
                        "description": (
                            "Frequency aggregation: d=daily, w=weekly, bw=biweekly, "
                            "m=monthly, q=quarterly, sa=semiannual, a=annual"
                        )
                    },
                    "aggregation_method": {
                        "type": "string",
                        "enum": ["avg", "sum", "eop"],
                        "description": "Aggregation method: avg=average, sum=sum, eop=end of period"
                    }
                },
                "required": ["series_id"]
            }
        }
    }
]


def get_tool_definitions() -> List[Dict[str, Any]]:
    """
    Get OpenAI-compatible tool definitions for all FRED tools.
    
    These can be passed directly to OpenAI, Anthropic, or any LLM
    that supports function calling.
    
    Returns:
        List of tool definitions in OpenAI function calling format
    
    Example:
        >>> from fred_toolkit import get_tool_definitions
        >>> tools = get_tool_definitions()
        >>> response = openai.chat.completions.create(
        ...     model="gpt-4",
        ...     messages=[{"role": "user", "content": "What's the unemployment rate?"}],
        ...     tools=tools
        ... )
    """
    return FRED_TOOLS.copy()


def get_tool_names() -> List[str]:
    """
    Get list of available tool names.
    
    Returns:
        List of tool names: ['fred_browse', 'fred_search', 'fred_get_series']
    """
    return [tool["function"]["name"] for tool in FRED_TOOLS]


def get_tool_by_name(name: str) -> Dict[str, Any]:
    """
    Get a specific tool definition by name.
    
    Args:
        name: Tool name (e.g., 'fred_search')
    
    Returns:
        Tool definition dictionary
    
    Raises:
        ValueError: If tool name is not found
    """
    for tool in FRED_TOOLS:
        if tool["function"]["name"] == name:
            return tool
    raise ValueError(f"Unknown tool: {name}. Available tools: {get_tool_names()}")
