"""
FRED Search API functions.

Provides search functionality for discovering FRED series.
"""

from typing import Any, Dict, List, Optional, Literal
from .request import make_request


def fred_search(
    search_text: Optional[str] = None,
    search_type: Optional[Literal["full_text", "series_id"]] = None,
    tag_names: Optional[str] = None,
    exclude_tag_names: Optional[str] = None,
    limit: int = 25,
    offset: int = 0,
    order_by: Optional[Literal[
        "search_rank", "series_id", "title", "units", "frequency",
        "seasonal_adjustment", "realtime_start", "realtime_end",
        "last_updated", "observation_start", "observation_end", "popularity"
    ]] = None,
    sort_order: Optional[Literal["asc", "desc"]] = None,
    filter_variable: Optional[Literal["frequency", "units", "seasonal_adjustment"]] = None,
    filter_value: Optional[str] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Search for FRED economic data series by keywords, tags, or filters.
    
    Args:
        search_text: Text to search for in series titles and descriptions
        search_type: Type of search ('full_text' or 'series_id')
        tag_names: Comma-separated list of tag names to filter by
        exclude_tag_names: Comma-separated list of tag names to exclude
        limit: Maximum number of results (default 25, max 1000)
        offset: Number of results to skip for pagination
        order_by: Field to order results by
        sort_order: Sort order ('asc' or 'desc')
        filter_variable: Filter by 'frequency', 'units', or 'seasonal_adjustment'
        filter_value: Value to filter the variable by
        api_key: FRED API key
    
    Returns:
        Dictionary with search results and metadata
    """
    params: Dict[str, Any] = {
        "limit": limit,
        "offset": offset
    }
    
    if search_text:
        params["search_text"] = search_text
    if search_type:
        params["search_type"] = search_type
    if tag_names:
        params["tag_names"] = tag_names
    if exclude_tag_names:
        params["exclude_tag_names"] = exclude_tag_names
    if order_by:
        params["order_by"] = order_by
    if sort_order:
        params["sort_order"] = sort_order
    if filter_variable:
        params["filter_variable"] = filter_variable
    if filter_value:
        params["filter_value"] = filter_value
    
    response = make_request("series/search", params, api_key)
    
    series_list = response.get("seriess", [])
    count = response.get("count", 0)
    
    return {
        "total_results": count,
        "showing": f"{offset + 1}-{min(offset + limit, count)}" if count > 0 else "0-0",
        "offset": offset,
        "limit": limit,
        "results": [
            {
                "id": s["id"],
                "title": s["title"],
                "units": s.get("units", ""),
                "frequency": s.get("frequency", ""),
                "seasonal_adjustment": s.get("seasonal_adjustment", ""),
                "observation_range": f"{s.get('observation_start', '')} to {s.get('observation_end', '')}",
                "last_updated": s.get("last_updated", ""),
                "popularity": s.get("popularity", 0),
                "notes": (s.get("notes", "") or "")[:200] + ("..." if len(s.get("notes", "") or "") > 200 else "")
            }
            for s in series_list
        ]
    }


def get_series_info(
    series_id: str,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Get metadata/info for a specific FRED series.
    
    Args:
        series_id: The FRED series ID
        api_key: FRED API key
    
    Returns:
        Dictionary with series metadata
    """
    params = {"series_id": series_id}
    
    response = make_request("series", params, api_key)
    
    series_list = response.get("seriess", [])
    if not series_list:
        raise ValueError(f"Series not found: {series_id}")
    
    s = series_list[0]
    
    return {
        "id": s["id"],
        "title": s["title"],
        "units": s.get("units", ""),
        "frequency": s.get("frequency", ""),
        "seasonal_adjustment": s.get("seasonal_adjustment", ""),
        "observation_range": f"{s.get('observation_start', '')} to {s.get('observation_end', '')}",
        "last_updated": s.get("last_updated", ""),
        "popularity": s.get("popularity", 0),
        "notes": s.get("notes", "")
    }
