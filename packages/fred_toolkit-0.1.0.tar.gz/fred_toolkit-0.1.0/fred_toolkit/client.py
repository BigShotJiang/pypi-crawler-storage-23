"""
FredTools - Main client class for FRED economic data.

Provides a unified interface for tool definitions and execution.
"""

import json
from typing import Any, Dict, List, Optional

from .tools import get_tool_definitions, get_tool_names, get_tool_by_name, FRED_TOOLS
from .browse import fred_browse
from .search import fred_search, get_series_info
from .series import fred_get_series


class FredTools:
    """
    Main client for accessing FRED economic data through LLM-compatible tools.
    
    This class provides:
    1. Tool definitions for LLM function calling
    2. Tool execution by name and arguments
    3. Direct method access for Pythonic usage
    
    Example:
        >>> from fred_toolkit import FredTools
        >>> 
        >>> # Initialize with API key
        >>> fred = FredTools(api_key="your-api-key")
        >>> 
        >>> # Get tool definitions for LLM
        >>> tools = fred.get_tool_definitions()
        >>> 
        >>> # Execute a tool (as LLM would call it)
        >>> result = fred.execute_tool("fred_search", {"search_text": "unemployment"})
        >>> 
        >>> # Or use directly
        >>> data = fred.get_series("GDP")
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize FredTools client.
        
        Args:
            api_key: FRED API key. If not provided, will use FRED_API_KEY 
                     environment variable.
        """
        self.api_key = api_key
    
    def get_tool_definitions(self) -> List[Dict[str, Any]]:
        """
        Get OpenAI-compatible tool definitions for all FRED tools.
        
        Returns:
            List of tool definitions ready to pass to an LLM
        """
        return get_tool_definitions()
    
    def get_tool_names(self) -> List[str]:
        """
        Get list of available tool names.
        
        Returns:
            List of tool names
        """
        return get_tool_names()
    
    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a tool by name with given arguments.
        
        This is the main method for LLM integration. When an LLM returns
        a tool call, pass the tool name and arguments here.
        
        Args:
            tool_name: Name of the tool to execute
            arguments: Dictionary of arguments for the tool
        
        Returns:
            Tool execution result as a dictionary
        
        Raises:
            ValueError: If tool name is unknown
        
        Example:
            >>> # LLM returns: {"name": "fred_get_series", "arguments": {"series_id": "GDP"}}
            >>> result = fred.execute_tool("fred_get_series", {"series_id": "GDP"})
        """
        # Add API key to arguments if not present
        args = dict(arguments)
        if "api_key" not in args:
            args["api_key"] = self.api_key
        
        if tool_name == "fred_browse":
            return fred_browse(**args)
        elif tool_name == "fred_search":
            return fred_search(**args)
        elif tool_name == "fred_get_series":
            return fred_get_series(**args)
        else:
            raise ValueError(f"Unknown tool: {tool_name}. Available tools: {get_tool_names()}")
    
    def execute_tool_json(self, tool_name: str, arguments_json: str) -> str:
        """
        Execute a tool with JSON string arguments, return JSON string result.
        
        Convenience method for when arguments come as JSON string from LLM.
        
        Args:
            tool_name: Name of the tool to execute
            arguments_json: JSON string of arguments
        
        Returns:
            JSON string of the result
        """
        arguments = json.loads(arguments_json)
        result = self.execute_tool(tool_name, arguments)
        return json.dumps(result, indent=2)
    
    # Direct access methods for Pythonic usage
    
    def browse(
        self,
        browse_type: str,
        category_id: Optional[int] = None,
        release_id: Optional[int] = None,
        limit: int = 50,
        offset: int = 0,
        order_by: Optional[str] = None,
        sort_order: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Browse FRED's catalog (categories, releases, sources).
        
        See fred_browse tool for full documentation.
        """
        return fred_browse(
            browse_type=browse_type,  # type: ignore
            category_id=category_id,
            release_id=release_id,
            limit=limit,
            offset=offset,
            order_by=order_by,
            sort_order=sort_order,  # type: ignore
            api_key=self.api_key
        )
    
    def search(
        self,
        search_text: Optional[str] = None,
        limit: int = 25,
        offset: int = 0,
        order_by: Optional[str] = None,
        sort_order: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Search for FRED series by keywords.
        
        See fred_search tool for full documentation.
        """
        return fred_search(
            search_text=search_text,
            limit=limit,
            offset=offset,
            order_by=order_by,  # type: ignore
            sort_order=sort_order,  # type: ignore
            api_key=self.api_key,
            **kwargs
        )
    
    def get_series(
        self,
        series_id: str,
        observation_start: Optional[str] = None,
        observation_end: Optional[str] = None,
        limit: Optional[int] = None,
        units: Optional[str] = None,
        frequency: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Get data for a FRED series.
        
        See fred_get_series tool for full documentation.
        """
        return fred_get_series(
            series_id=series_id,
            observation_start=observation_start,
            observation_end=observation_end,
            limit=limit,
            units=units,  # type: ignore
            frequency=frequency,  # type: ignore
            api_key=self.api_key,
            **kwargs
        )
    
    def get_series_info(self, series_id: str) -> Dict[str, Any]:
        """
        Get metadata for a FRED series (without observations).
        
        Args:
            series_id: The FRED series ID
        
        Returns:
            Series metadata dictionary
        """
        return get_series_info(series_id, self.api_key)
