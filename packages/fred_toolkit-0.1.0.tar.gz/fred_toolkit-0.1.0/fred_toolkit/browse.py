"""
FRED Browse API functions.

Provides comprehensive browsing of FRED categories, releases, and sources.
"""

from typing import Any, Dict, List, Optional, Literal
from .request import make_request


def browse_categories(
    category_id: Optional[int] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Browse FRED categories.
    
    Args:
        category_id: Optional category ID to get children of. 
                     If None, returns root categories.
        api_key: FRED API key
    
    Returns:
        Dictionary with categories list
    """
    endpoint = "category/children" if category_id else "category"
    params = {}
    
    if category_id:
        params["category_id"] = category_id
    
    response = make_request(endpoint, params, api_key)
    
    return {
        "categories": [
            {
                "id": cat["id"],
                "name": cat["name"],
                "parent_id": cat.get("parent_id", 0)
            }
            for cat in response.get("categories", [])
        ]
    }


def get_category_series(
    category_id: int,
    limit: int = 50,
    offset: int = 0,
    order_by: Optional[str] = None,
    sort_order: Optional[Literal["asc", "desc"]] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Get all series in a specific category.
    
    Args:
        category_id: Category ID to get series for
        limit: Maximum number of results (default 50)
        offset: Number of results to skip
        order_by: Field to order by
        sort_order: Sort order ('asc' or 'desc')
        api_key: FRED API key
    
    Returns:
        Dictionary with series list and metadata
    """
    params: Dict[str, Any] = {
        "category_id": category_id,
        "limit": limit,
        "offset": offset
    }
    
    if order_by:
        params["order_by"] = order_by
    if sort_order:
        params["sort_order"] = sort_order
    
    response = make_request("category/series", params, api_key)
    
    return {
        "category_id": category_id,
        "count": response.get("count", 0),
        "offset": response.get("offset", 0),
        "limit": response.get("limit", limit),
        "series": [
            {
                "id": s["id"],
                "title": s["title"],
                "units": s.get("units", ""),
                "frequency": s.get("frequency", ""),
                "seasonal_adjustment": s.get("seasonal_adjustment", ""),
                "observation_start": s.get("observation_start", ""),
                "observation_end": s.get("observation_end", ""),
                "popularity": s.get("popularity", 0)
            }
            for s in response.get("seriess", [])
        ]
    }


def browse_releases(
    limit: int = 50,
    offset: int = 0,
    order_by: Optional[str] = None,
    sort_order: Optional[Literal["asc", "desc"]] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Browse all FRED data releases.
    
    Args:
        limit: Maximum number of results (default 50)
        offset: Number of results to skip
        order_by: Field to order by
        sort_order: Sort order ('asc' or 'desc')
        api_key: FRED API key
    
    Returns:
        Dictionary with releases list
    """
    params: Dict[str, Any] = {
        "limit": limit,
        "offset": offset
    }
    
    if order_by:
        params["order_by"] = order_by
    if sort_order:
        params["sort_order"] = sort_order
    
    response = make_request("releases", params, api_key)
    
    return {
        "count": len(response.get("releases", [])),
        "releases": [
            {
                "id": r["id"],
                "name": r["name"],
                "press_release": r.get("press_release", False),
                "link": r.get("link", ""),
                "notes": r.get("notes", "")[:200] if r.get("notes") else ""
            }
            for r in response.get("releases", [])
        ]
    }


def get_release_series(
    release_id: int,
    limit: int = 50,
    offset: int = 0,
    order_by: Optional[str] = None,
    sort_order: Optional[Literal["asc", "desc"]] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Get all series in a specific release.
    
    Args:
        release_id: Release ID to get series for
        limit: Maximum number of results (default 50)
        offset: Number of results to skip
        order_by: Field to order by
        sort_order: Sort order ('asc' or 'desc')
        api_key: FRED API key
    
    Returns:
        Dictionary with series list and metadata
    """
    params: Dict[str, Any] = {
        "release_id": release_id,
        "limit": limit,
        "offset": offset
    }
    
    if order_by:
        params["order_by"] = order_by
    if sort_order:
        params["sort_order"] = sort_order
    
    response = make_request("release/series", params, api_key)
    
    return {
        "release_id": release_id,
        "count": response.get("count", 0),
        "offset": response.get("offset", 0),
        "limit": response.get("limit", limit),
        "series": [
            {
                "id": s["id"],
                "title": s["title"],
                "units": s.get("units", ""),
                "frequency": s.get("frequency", ""),
                "seasonal_adjustment": s.get("seasonal_adjustment", ""),
                "observation_start": s.get("observation_start", ""),
                "observation_end": s.get("observation_end", ""),
                "popularity": s.get("popularity", 0)
            }
            for s in response.get("seriess", [])
        ]
    }


def browse_sources(
    limit: int = 50,
    offset: int = 0,
    order_by: Optional[str] = None,
    sort_order: Optional[Literal["asc", "desc"]] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Browse all FRED data sources.
    
    Args:
        limit: Maximum number of results (default 50)
        offset: Number of results to skip
        order_by: Field to order by
        sort_order: Sort order ('asc' or 'desc')
        api_key: FRED API key
    
    Returns:
        Dictionary with sources list
    """
    params: Dict[str, Any] = {
        "limit": limit,
        "offset": offset
    }
    
    if order_by:
        params["order_by"] = order_by
    if sort_order:
        params["sort_order"] = sort_order
    
    response = make_request("sources", params, api_key)
    
    return {
        "count": len(response.get("sources", [])),
        "sources": [
            {
                "id": s["id"],
                "name": s["name"],
                "link": s.get("link", ""),
                "notes": s.get("notes", "")[:200] if s.get("notes") else ""
            }
            for s in response.get("sources", [])
        ]
    }


def fred_browse(
    browse_type: Literal["categories", "releases", "sources", "category_series", "release_series"],
    category_id: Optional[int] = None,
    release_id: Optional[int] = None,
    limit: int = 50,
    offset: int = 0,
    order_by: Optional[str] = None,
    sort_order: Optional[Literal["asc", "desc"]] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Browse FRED's complete catalog through categories, releases, or sources.
    
    This is the main entry point for the fred_browse tool.
    
    Args:
        browse_type: Type of browsing to perform:
            - 'categories': Browse category tree
            - 'releases': Browse data releases
            - 'sources': Browse data sources
            - 'category_series': Get series in a category
            - 'release_series': Get series in a release
        category_id: Category ID (required for 'categories' children and 'category_series')
        release_id: Release ID (required for 'release_series')
        limit: Maximum number of results (default 50)
        offset: Number of results to skip
        order_by: Field to order by
        sort_order: Sort order ('asc' or 'desc')
        api_key: FRED API key
    
    Returns:
        Dictionary with results based on browse_type
    """
    if browse_type == "categories":
        return browse_categories(category_id, api_key)
    
    elif browse_type == "category_series":
        if category_id is None:
            raise ValueError("category_id is required for category_series")
        return get_category_series(category_id, limit, offset, order_by, sort_order, api_key)
    
    elif browse_type == "releases":
        return browse_releases(limit, offset, order_by, sort_order, api_key)
    
    elif browse_type == "release_series":
        if release_id is None:
            raise ValueError("release_id is required for release_series")
        return get_release_series(release_id, limit, offset, order_by, sort_order, api_key)
    
    elif browse_type == "sources":
        return browse_sources(limit, offset, order_by, sort_order, api_key)
    
    else:
        raise ValueError(f"Invalid browse_type: {browse_type}")
