"""
FRED Series Data API functions.

Provides functionality for fetching series data and metadata.
"""

from typing import Any, Dict, List, Optional, Literal, Union
from .request import make_request
from .search import get_series_info


def fred_get_series(
    series_id: str,
    observation_start: Optional[str] = None,
    observation_end: Optional[str] = None,
    limit: Optional[int] = None,
    offset: Optional[int] = None,
    sort_order: Optional[Literal["asc", "desc"]] = None,
    units: Optional[Literal["lin", "chg", "ch1", "pch", "pc1", "pca", "cch", "cca", "log"]] = None,
    frequency: Optional[Literal[
        "d", "w", "bw", "m", "q", "sa", "a",
        "wef", "weth", "wew", "wetu", "wem", "wesu", "wesa", "bwew", "bwem"
    ]] = None,
    aggregation_method: Optional[Literal["avg", "sum", "eop"]] = None,
    output_type: Optional[int] = None,
    vintage_dates: Optional[str] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Retrieve data for any FRED series by its ID with support for transformations and date ranges.
    
    Args:
        series_id: The FRED series ID (e.g., 'GDP', 'UNRATE', 'CPIAUCSL')
        observation_start: Start date in YYYY-MM-DD format
        observation_end: End date in YYYY-MM-DD format
        limit: Maximum number of observations (max 100000)
        offset: Number of observations to skip
        sort_order: Sort order of observations by date ('asc' or 'desc')
        units: Data transformation:
            - 'lin': Levels (no transformation)
            - 'chg': Change from previous period
            - 'ch1': Change from year ago
            - 'pch': Percent change
            - 'pc1': Percent change from year ago
            - 'pca': Compounded annual rate of change
            - 'cch': Continuously compounded rate of change
            - 'cca': Continuously compounded annual rate of change
            - 'log': Natural log
        frequency: Frequency aggregation:
            - 'd': Daily
            - 'w': Weekly
            - 'bw': Biweekly
            - 'm': Monthly
            - 'q': Quarterly
            - 'sa': Semiannual
            - 'a': Annual
            - Plus various weekly ending variants
        aggregation_method: Method for frequency aggregation:
            - 'avg': Average
            - 'sum': Sum
            - 'eop': End of period
        output_type: Output format (1-4)
        vintage_dates: Vintage date(s) in YYYY-MM-DD format
        api_key: FRED API key
    
    Returns:
        Dictionary with series data and metadata
    """
    if not series_id:
        raise ValueError("series_id is required")
    
    params: Dict[str, Any] = {"series_id": series_id}
    
    if observation_start:
        params["observation_start"] = observation_start
    if observation_end:
        params["observation_end"] = observation_end
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    if sort_order:
        params["sort_order"] = sort_order
    if units:
        params["units"] = units
    if frequency:
        params["frequency"] = frequency
    if aggregation_method:
        params["aggregation_method"] = aggregation_method
    if output_type is not None:
        params["output_type"] = output_type
    if vintage_dates:
        params["vintage_dates"] = vintage_dates
    
    # Fetch the series observations
    response = make_request("series/observations", params, api_key)
    
    # Try to get series metadata
    series_info = None
    try:
        series_info = get_series_info(series_id, api_key)
    except Exception:
        pass  # Metadata is optional
    
    # Transform observations
    observations = response.get("observations", [])
    data = [
        {
            "date": obs["date"],
            "value": None if obs["value"] == "." else float(obs["value"])
        }
        for obs in observations
    ]
    
    return {
        "series_id": series_id,
        "title": series_info["title"] if series_info else f"FRED Series: {series_id}",
        "units": series_info["units"] if series_info else (f"Transformed ({units})" if units else "Value"),
        "frequency": series_info["frequency"] if series_info else "Unknown",
        "seasonal_adjustment": series_info["seasonal_adjustment"] if series_info else "Unknown",
        "observation_range": series_info["observation_range"] if series_info else f"{response.get('observation_start', '')} to {response.get('observation_end', '')}",
        "total_observations": response.get("count", len(data)),
        "data_offset": response.get("offset", 0),
        "data_limit": response.get("limit", len(data)),
        "source": "Federal Reserve Economic Data (FRED)",
        "notes": series_info["notes"] if series_info else None,
        "data": data
    }
