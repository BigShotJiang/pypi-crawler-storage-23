"""
Example usage of fred-toolkit with OpenAI.

This example demonstrates how to integrate fred-toolkit with an LLM
to build an economic data agent.
"""

import os
import json
from fred_toolkit import FredTools


def example_tool_definitions():
    """Example: Getting tool definitions."""
    print("=" * 60)
    print("Example 1: Getting Tool Definitions")
    print("=" * 60)
    
    fred = FredTools()
    tools = fred.get_tool_definitions()
    
    print(f"Number of tools: {len(tools)}")
    print("\nTool names:")
    for tool in tools:
        print(f"  - {tool['function']['name']}: {tool['function']['description'][:60]}...")
    
    print("\n")


def example_direct_usage():
    """Example: Direct usage without LLM."""
    print("=" * 60)
    print("Example 2: Direct Python Usage")
    print("=" * 60)
    
    # Check for API key
    api_key = os.environ.get("FRED_API_KEY")
    if not api_key:
        print("⚠️  Set FRED_API_KEY environment variable to run this example")
        print("   Get your free key at: https://fred.stlouisfed.org/docs/api/api_key.html")
        return
    
    fred = FredTools(api_key=api_key)
    
    # Search for series
    print("\n1. Searching for 'unemployment'...")
    results = fred.search("unemployment", limit=3)
    print(f"   Found {results['total_results']} results")
    for i, series in enumerate(results['results'][:3], 1):
        print(f"   {i}. {series['id']}: {series['title']}")
    
    # Get specific series
    print("\n2. Getting GDP data (last 5 observations)...")
    data = fred.get_series("GDP", limit=5)
    print(f"   Series: {data['title']}")
    print(f"   Units: {data['units']}")
    print("   Recent data:")
    for obs in data['data'][-5:]:
        print(f"     {obs['date']}: {obs['value']}")
    
    print("\n")


def example_llm_integration():
    """Example: Integration with OpenAI (conceptual)."""
    print("=" * 60)
    print("Example 3: LLM Integration Pattern")
    print("=" * 60)
    
    print("""
# Conceptual example (requires OpenAI API key)

import openai
from fred_toolkit import FredTools

fred = FredTools(api_key="your-fred-key")
client = openai.OpenAI()

# Get tool definitions
tools = fred.get_tool_definitions()

# User query
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "What's the current US unemployment rate?"}],
    tools=tools
)

# LLM decides to call fred_get_series
tool_call = response.choices[0].message.tool_calls[0]
print(f"LLM chose: {tool_call.function.name}")
print(f"With args: {tool_call.function.arguments}")

# Execute the tool
result = fred.execute_tool(
    tool_call.function.name,
    json.loads(tool_call.function.arguments)
)

# Send result back to LLM for final answer
messages = [
    {"role": "user", "content": "What's the current US unemployment rate?"},
    {"role": "assistant", "tool_calls": [tool_call]},
    {"role": "tool", "content": json.dumps(result), "tool_call_id": tool_call.id}
]

final_response = client.chat.completions.create(model="gpt-4", messages=messages)
print(final_response.choices[0].message.content)
# Output: "The current US unemployment rate is 4.1% as of January 2026..."
    """)
    
    print("\n")


def example_execute_tool():
    """Example: Executing tools by name."""
    print("=" * 60)
    print("Example 4: Execute Tool by Name")
    print("=" * 60)
    
    api_key = os.environ.get("FRED_API_KEY")
    if not api_key:
        print("⚠️  Set FRED_API_KEY environment variable to run this example")
        return
    
    fred = FredTools(api_key=api_key)
    
    # Simulate LLM tool call
    print("\nSimulating LLM calling: fred_search")
    result = fred.execute_tool(
        "fred_search",
        {"search_text": "inflation", "limit": 2}
    )
    print(f"Found {result['total_results']} results:")
    for series in result['results']:
        print(f"  - {series['id']}: {series['title']}")
    
    print("\n")


def main():
    """Run all examples."""
    print("\n")
    print("🔧 FRED Toolkit Examples")
    print("\n")
    
    example_tool_definitions()
    example_direct_usage()
    example_execute_tool()
    example_llm_integration()
    
    print("=" * 60)
    print("✅ Examples Complete!")
    print("=" * 60)
    print("\nFor more examples, see: https://github.com/yourusername/fred-toolkit")
    print("\n")


if __name__ == "__main__":
    main()
