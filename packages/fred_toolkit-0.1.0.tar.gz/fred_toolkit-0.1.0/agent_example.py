"""
Complete Agent Example: Economic Data Assistant

This example shows a full implementation of an AI agent that uses
fred-toolkit to answer economic data questions.
"""

import os
import json
from typing import List, Dict, Any


# Mock OpenAI client for demonstration (replace with real OpenAI in production)
class MockOpenAIResponse:
    """Mock response for demonstration purposes."""
    
    def __init__(self, tool_name: str, arguments: Dict[str, Any]):
        self.choices = [MockChoice(tool_name, arguments)]


class MockChoice:
    def __init__(self, tool_name: str, arguments: Dict[str, Any]):
        self.message = MockMessage(tool_name, arguments)


class MockMessage:
    def __init__(self, tool_name: str, arguments: Dict[str, Any]):
        self.tool_calls = [MockToolCall(tool_name, arguments)]
        self.content = None


class MockToolCall:
    def __init__(self, tool_name: str, arguments: Dict[str, Any]):
        self.id = "call_123"
        self.function = MockFunction(tool_name, arguments)


class MockFunction:
    def __init__(self, tool_name: str, arguments: Dict[str, Any]):
        self.name = tool_name
        self.arguments = json.dumps(arguments)


def build_economic_agent(api_key: str):
    """
    Build a complete economic data agent using fred-toolkit.
    
    This agent can:
    - Answer questions about economic indicators
    - Retrieve time series data
    - Search for relevant data series
    - Browse economic data categories
    """
    from fred_toolkit import FredTools
    
    fred = FredTools(api_key=api_key)
    
    def answer_question(question: str) -> Dict[str, Any]:
        """
        Process a user question and return relevant economic data.
        
        In production, this would use a real LLM like OpenAI GPT-4.
        For this example, we simulate the LLM's decision-making.
        """
        
        # Get tool definitions
        tools = fred.get_tool_definitions()
        
        # Simulate LLM deciding which tool to call based on question
        # In reality, you'd pass question + tools to the LLM
        
        question_lower = question.lower()
        
        if "search" in question_lower or "find" in question_lower:
            # LLM would choose fred_search
            tool_name = "fred_search"
            # Extract search terms (simplified - LLM would do this)
            search_terms = " ".join([
                word for word in question_lower.split()
                if word not in ["search", "for", "find", "me", "data", "about", "the"]
            ])
            arguments = {"search_text": search_terms, "limit": 5}
            
        elif "browse" in question_lower or "categories" in question_lower:
            # LLM would choose fred_browse
            tool_name = "fred_browse"
            arguments = {"browse_type": "categories"}
            
        else:
            # Try to extract series ID or search for it
            # For demo, we'll map common terms to series IDs
            series_map = {
                "gdp": "GDP",
                "unemployment": "UNRATE",
                "inflation": "CPIAUCSL",
                "interest rate": "FEDFUNDS",
                "treasury": "DGS10",
            }
            
            series_id = None
            for term, sid in series_map.items():
                if term in question_lower:
                    series_id = sid
                    break
            
            if series_id:
                tool_name = "fred_get_series"
                arguments = {"series_id": series_id, "limit": 12}
            else:
                # Default to search
                tool_name = "fred_search"
                arguments = {"search_text": question, "limit": 5}
        
        # Execute the tool
        result = fred.execute_tool(tool_name, arguments)
        
        return {
            "question": question,
            "tool_used": tool_name,
            "arguments": arguments,
            "result": result
        }
    
    return answer_question


def format_result(response: Dict[str, Any]) -> str:
    """Format the agent's response in a human-readable way."""
    
    output = []
    output.append(f"\n{'=' * 70}")
    output.append(f"Question: {response['question']}")
    output.append(f"Tool Used: {response['tool_used']}")
    output.append(f"Arguments: {json.dumps(response['arguments'], indent=2)}")
    output.append(f"{'=' * 70}\n")
    
    result = response['result']
    
    if response['tool_used'] == 'fred_search':
        output.append(f"Found {result['total_results']} results:\n")
        for i, series in enumerate(result['results'], 1):
            output.append(f"{i}. {series['id']}: {series['title']}")
            output.append(f"   Units: {series['units']}")
            output.append(f"   Frequency: {series['frequency']}")
            output.append("")
    
    elif response['tool_used'] == 'fred_get_series':
        output.append(f"Series: {result['title']}")
        output.append(f"Units: {result['units']}")
        output.append(f"Frequency: {result['frequency']}")
        output.append(f"Total Observations: {result['total_observations']}\n")
        output.append("Recent Data:")
        for obs in result['data'][-10:]:  # Last 10 observations
            value = f"{obs['value']:,.2f}" if obs['value'] else "N/A"
            output.append(f"  {obs['date']}: {value}")
    
    elif response['tool_used'] == 'fred_browse':
        if 'categories' in result:
            output.append(f"Found {len(result['categories'])} categories:\n")
            for cat in result['categories'][:10]:
                output.append(f"  [{cat['id']}] {cat['name']}")
    
    return "\n".join(output)


def main():
    """Run the economic agent demo."""
    
    print("\n" + "=" * 70)
    print("🤖 Economic Data AI Agent (fred-toolkit)")
    print("=" * 70)
    
    # Check for API key
    api_key = os.environ.get("FRED_API_KEY")
    if not api_key:
        print("\n⚠️  FRED_API_KEY environment variable not set")
        print("Get your free API key at: https://fred.stlouisfed.org/docs/api/api_key.html")
        print("\nRunning in demo mode with mock data...\n")
        return
    
    # Build the agent
    agent = build_economic_agent(api_key)
    
    # Example questions
    questions = [
        "What is the current GDP?",
        "Search for inflation data",
        "Show me unemployment data",
        "Find interest rate series",
    ]
    
    print("\nProcessing example questions...\n")
    
    for question in questions:
        try:
            response = agent(question)
            print(format_result(response))
        except Exception as e:
            print(f"Error processing '{question}': {e}\n")
    
    print("\n" + "=" * 70)
    print("✅ Demo Complete!")
    print("=" * 70)
    print("\nThis demonstrates how to build an AI agent with fred-toolkit.")
    print("In production, replace the mock LLM logic with real OpenAI/Claude API calls.")
    print("\n")


if __name__ == "__main__":
    main()
