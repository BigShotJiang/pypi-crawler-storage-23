from invoke.collection import Collection

from .code import ns_code

ns = Collection()
ns.add_collection(ns_code)
