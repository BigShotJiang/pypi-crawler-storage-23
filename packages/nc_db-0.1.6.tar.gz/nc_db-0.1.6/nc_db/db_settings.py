from pydantic_settings import BaseSettings, SettingsConfigDict


class DbSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="NC_", env_file=".env", extra="ignore")
    db_host: str
    db_port: int
    db_user: str
    db_password: str
    db_name: str
    db_schema: str
    db_pool_min: int = 1
    db_pool_max: int = 5

    @classmethod
    def from_env(cls):
        """
        This is a convenience method that prevents lint errors when variables are set from the environment.
        """
        return cls()  # type: ignore
