from typing import Annotated, TypeVar
from pydantic import BaseModel, Field

from nc_db.metadata.db_column import DbColumn


NEW_ID = -1

"""
A new entity should always be initialized with this value
"""


class Identifiable(BaseModel):
    """
    Represents the base properties needed to uniquely identify objects stored in the database
    """
    id: Annotated[int, DbColumn('INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY', True, True, True)] = Field(default=NEW_ID)


T = TypeVar('T', bound=Identifiable)
