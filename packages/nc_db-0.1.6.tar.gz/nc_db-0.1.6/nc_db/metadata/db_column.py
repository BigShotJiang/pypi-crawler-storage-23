from dataclasses import dataclass
from typing import Annotated, TypeAlias

# NOTE: This class should not have any dependencies on other nc-db modules.


@dataclass(frozen=True)
class DbColumn():
    """
    Description
    -----------
    Required for any attributes you wish to index/search in the database. Specifies indexes and column type.
    You can use pre-canned type aliases for convenience (IntDbIndex, StrDbIndex, etc.) or define your own.

    column_definition: Must be a valid postgres column definition ('INT', 'VARCHAR UNIQUE','INT GENERATED ALWAYS', etc.)

    Examples:
    ---------
    - Using Annotated for full customization
    class Foo():
        my_int: Annotated[int,DbIndex('BIGINT UNIQUE NOT NULL']

    - Using pre-canned type aliases for simple use cases
    class Foo():
        my_int: IntDbIndex
    """

    column_definition: str
    """
    The postgres column definition.
    Examples:
        'INT UNIQUE'
        'VARCHAR NOT NOLL'
        'INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY'
    """

    index: bool = False
    """
    Indicates whether an index should be created for this column.
    """

    auto_generated: bool = False
    """
    If set to TRUE, this attribute is ignored when saving to the DB. When
    retrieving, it's value will be set from the corresponding column in the DB.
    You MUST set GENERATED ALWAYS in your column descriprion if this is true.
    """

    primary_key: bool = False
    """
    If set to True, the nc-db library does not create an index for this column.
    This attribute is the primary key for the table--you MUST specify
    "PRIMARY KEY along with the type, etc in the column_definition."
    """


IntDbIndex: TypeAlias = Annotated[int, DbColumn('INT', True, False)]
BigIntDbIndex: TypeAlias = Annotated[int, DbColumn('BIGINT', True, False)]
StrDbIndex: TypeAlias = Annotated[str, DbColumn('TEXT', True, False)]
FloatDbIndex: TypeAlias = Annotated[float, DbColumn('FLOAT', True, False)]
