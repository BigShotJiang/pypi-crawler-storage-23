
from typing import Any, Dict, Type

# NOTE: This module should not have any dependencies on any other nc-db modules

VERSION = 1
VERSION_TABLE = 'db_version'
CLASS_REGISTRATION_TABLE = 'registered_classes'
CLASS_VERSION_DICT: Dict[Type[Any], int] = {}
ALLOW_SCHEMA_DRIFT: set[Type[Any]] = set()
