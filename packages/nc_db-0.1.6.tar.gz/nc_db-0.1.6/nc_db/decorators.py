from typing import Any, Type
from nc_db.metadata.nc_config import CLASS_VERSION_DICT, ALLOW_SCHEMA_DRIFT


def schema_version(version: int, allow_schema_drift: bool = False):
    """
    Specifies the schema version of the class.
    MUST be monotonically increasing.
    MUST be updated when any attributes with the DbColumn annotation are created/modified/deleted.
    May by updated for any other reason, causing class instances to be stored/retrieved from a new table.

    Parameters:
    version: The version of the schema
    allow_schema_drift: If True, errors will only be thrown when class/schema changes break functionality.
                        Default (recommended) is False which will throw errors when any changes are made to the class and the
                        schema_version isn't updated.
    """
    def decorator(cls: Type[Any]):
        CLASS_VERSION_DICT.update({cls: version})
        if allow_schema_drift:
            ALLOW_SCHEMA_DRIFT.update({cls: True})
        return cls
    return decorator
