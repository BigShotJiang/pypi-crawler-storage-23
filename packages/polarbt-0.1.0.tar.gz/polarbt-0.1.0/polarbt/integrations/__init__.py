"""Optional integrations with external libraries."""
