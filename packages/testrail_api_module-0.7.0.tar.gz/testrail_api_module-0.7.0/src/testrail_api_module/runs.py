"""
This module provides functionality for managing test runs in TestRail.
Test runs are used to execute test cases and track their results.
"""

from typing import Any

from .base import BaseAPI

__all__ = ["RunsAPI"]


class RunsAPI(BaseAPI):
    """
    API for managing TestRail test runs.

    This class provides methods to create, read, update, and manage test runs
    in TestRail, following the official TestRail API patterns.
    """

    def get_run(self, run_id: int) -> dict[str, Any]:
        """
        Get a test run by ID.

        Args:
            run_id: The ID of the test run to retrieve.

        Returns:
            Dict containing the test run data.

        Raises:
            TestRailAPIError: If the API request fails.

        Example:
            >>> run = api.runs.get_run(123)
            >>> print(f"Run: {run['name']}")
        """
        return self._get(f"get_run/{run_id}")

    def get_runs(
        self,
        project_id: int,
        suite_id: int | None = None,
        created_after: int | None = None,
        created_before: int | None = None,
        created_by: int | None = None,
        is_completed: bool | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[dict[str, Any]]:
        """
        Get all test runs for a project and optionally a specific suite.

        Args:
            project_id: The ID of the project to get test runs for.
            suite_id: Optional ID of the suite to get test runs for.
            created_after: Optional timestamp to filter runs created after this time.
            created_before: Optional timestamp to filter runs created before this time.
            created_by: Optional user ID to filter runs created by specific user.
            is_completed: Optional boolean to filter by completion status.
            limit: Optional limit on number of results to return.
            offset: Optional offset for pagination.

        Returns:
            List of dictionaries containing test run data.

        Raises:
            TestRailAPIError: If the API request fails.

        Example:
            >>> runs = api.runs.get_runs(project_id=1, suite_id=2)
            >>> for run in runs:
            ...     print(f"Run: {run['name']}")
        """
        params = {}
        if suite_id is not None:
            params["suite_id"] = suite_id
        if created_after is not None:
            params["created_after"] = created_after
        if created_before is not None:
            params["created_before"] = created_before
        if created_by is not None:
            params["created_by"] = created_by
        if is_completed is not None:
            params["is_completed"] = is_completed
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        return self._get(f"get_runs/{project_id}", params=params)

    def add_run(
        self,
        project_id: int,
        name: str,
        description: str | None = None,
        suite_id: int | None = None,
        milestone_id: int | None = None,
        assignedto_id: int | None = None,
        include_all: bool = True,
        case_ids: list[int] | None = None,
    ) -> dict[str, Any]:
        """
        Add a new test run.

        Args:
            project_id: The ID of the project to add the test run to.
            name: The name of the test run.
            description: Optional description of the test run.
            suite_id: Optional ID of the suite to add the test run to.
            milestone_id: Optional ID of the milestone to add the test run to.
            assignedto_id: Optional ID of the user to assign the test run to.
            include_all: Whether to include all test cases from the suite.
            case_ids: Optional list of test case IDs to include in the run.

        Returns:
            Dict containing the created test run data.

        Raises:
            TestRailAPIError: If the API request fails.

        Example:
            >>> run = api.runs.add_run(
            ...     project_id=1,
            ...     name="Test Run",
            ...     description="Automated test run",
            ...     suite_id=2,
            ...     include_all=True
            ... )
        """
        data = {"name": name, "include_all": include_all}

        # Add optional fields only if they are provided
        optional_fields = {
            "description": description,
            "suite_id": suite_id,
            "milestone_id": milestone_id,
            "assignedto_id": assignedto_id,
            "case_ids": case_ids,
        }

        for field, value in optional_fields.items():
            if value is not None:
                data[field] = value

        return self._post(f"add_run/{project_id}", data=data)

    def update_run(
        self,
        run_id: int,
        name: str | None = None,
        description: str | None = None,
        milestone_id: int | None = None,
        assignedto_id: int | None = None,
    ) -> dict[str, Any]:
        """
        Update a test run.

        Args:
            run_id: The ID of the test run to update.
            name: Optional new name for the test run.
            description: Optional new description for the test run.
            milestone_id: Optional new milestone ID.
            assignedto_id: Optional new assigned user ID.

        Returns:
            Dict containing the updated test run data.

        Raises:
            TestRailAPIError: If the API request fails.

        Example:
            >>> updated_run = api.runs.update_run(
            ...     run_id=123,
            ...     name="Updated Run Name",
            ...     assignedto_id=456
            ... )
        """
        data = {}

        # Add fields only if they are provided
        optional_fields = {
            "name": name,
            "description": description,
            "milestone_id": milestone_id,
            "assignedto_id": assignedto_id,
        }

        for field, value in optional_fields.items():
            if value is not None:
                data[field] = value

        return self._post(f"update_run/{run_id}", data=data)

    def close_run(self, run_id: int) -> dict[str, Any]:
        """
        Close a test run.

        Args:
            run_id: The ID of the test run to close.

        Returns:
            Dict containing the response data.

        Raises:
            TestRailAPIError: If the API request fails.

        Example:
            >>> result = api.runs.close_run(123)
        """
        return self._post(f"close_run/{run_id}")

    def delete_run(self, run_id: int) -> dict[str, Any]:
        """
        Delete a test run.

        Args:
            run_id: The ID of the test run to delete.

        Returns:
            Dict containing the response data.

        Raises:
            TestRailAPIError: If the API request fails.

        Example:
            >>> result = api.runs.delete_run(123)
        """
        return self._post(f"delete_run/{run_id}")
