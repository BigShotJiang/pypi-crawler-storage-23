import os
from typing import Dict, Tuple, Optional, List, Any

from itkwasm import (
    environment_dispatch,
    Image,
)

async def write_image_async(
    image: Image,
    serialized_image: str,
    information_only: bool = False,
    use_compression: bool = False,
) -> None:
    """Write an itk-wasm file format converted to an image file format

    :param image: Input image
    :type  image: Image

    :param serialized_image: Output image serialized in the file format.
    :type  serialized_image: str

    :param information_only: Only write image metadata -- do not write pixel data.
    :type  information_only: bool

    :param use_compression: Use compression in the written file
    :type  use_compression: bool
    """
    func = environment_dispatch("itkwasm_image_io", "write_image_async")
    await func(image, serialized_image, information_only=information_only, use_compression=use_compression)
    return

async def imwrite_async(
    image: Image,
    serialized_image: os.PathLike,
    information_only: bool = False,
    use_compression: bool = False,
) -> None:
    return await write_image_async(image, serialized_image, information_only=information_only, use_compression=use_compression)

imwrite_async.__doc__ = f"""{write_image_async.__doc__}
    Alias for write_image.
    """