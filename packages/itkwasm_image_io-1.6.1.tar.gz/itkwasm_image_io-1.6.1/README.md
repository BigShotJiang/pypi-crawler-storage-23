# itkwasm-image-io

[![PyPI version](https://badge.fury.io/py/itkwasm-image-io.svg)](https://badge.fury.io/py/itkwasm-image-io)

Input and output for scientific and medical image file formats.

## Installation

```sh
pip install itkwasm-image-io
```
