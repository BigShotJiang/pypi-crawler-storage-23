#!/bin/sh

# yaourt -G ultrastartdx-git
# cd ultrastardx-git
# makepkg -si

yay -S ultrastardx-git
