#!/bin/sh

git clone https://github.com/billchurch/webssh2.git
cd webssh2/app
npm install --production
npm start
