#!/bin/sh

git clone https://github.com/cli/cli.git gh-cli
cd gh-cli
make install
