# loaded by systemd

sudo apt update
sudo apt install build-essential -y
bash install ubuntu.mk
