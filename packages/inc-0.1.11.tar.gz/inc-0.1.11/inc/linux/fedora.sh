#!/bin/sh

sudo dnf install -y make
make -f fedora.mk install
