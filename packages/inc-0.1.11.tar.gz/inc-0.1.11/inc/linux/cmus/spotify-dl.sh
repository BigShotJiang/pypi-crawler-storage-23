#!/bin/sh

git clone https://github.com/invicnaper/spotify-dl.git
