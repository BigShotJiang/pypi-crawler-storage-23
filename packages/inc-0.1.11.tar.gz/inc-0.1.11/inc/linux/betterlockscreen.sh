#!/bin/sh

[ ! -d betterlockscreen ] && git clone https://github.com/pavanjadhaw/betterlockscreen
cd betterlockscreen
cp betterlockscreen ~/.local/bin/
