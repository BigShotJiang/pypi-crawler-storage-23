#!/bin/sh
# https://github.com/jwkvam/jupyterlab-vim

pip install --upgrade jupyterlab jupyterlab-git
