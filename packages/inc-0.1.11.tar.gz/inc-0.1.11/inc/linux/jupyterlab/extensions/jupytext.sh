#!/bin/sh
# jupyter labextension install @jupyter-widgets/jupyterlab-manager

jupyter labextension install jupyterlab-jupytext
