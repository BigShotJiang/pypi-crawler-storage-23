#!/bin/sh

# plotly
conda install -c conda-forge jupyterlab-plotly-extension
jupyter labextension install @jupyterlab/plotly-extension
