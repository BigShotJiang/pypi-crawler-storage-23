#!/bin/bash

conda create -n 36 python=3.6
conda activate 36
conda install -y ipykernel

conda create -n 27 python=2.7
conda activate 27
conda install -y ipykernel
