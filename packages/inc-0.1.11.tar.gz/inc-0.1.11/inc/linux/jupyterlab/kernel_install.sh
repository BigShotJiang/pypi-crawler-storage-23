#!/bin/bash

# conda install nb_conda_kernels

mkdir -p $HOME/.local/share/jupyter
cp -r kernels $HOME/.local/share/jupyter/
