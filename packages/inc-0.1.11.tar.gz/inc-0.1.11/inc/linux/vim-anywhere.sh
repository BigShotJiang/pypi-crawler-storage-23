#!/bin/sh

curl -fsSL https://raw.github.com/cknadler/vim-anywhere/master/install | bash
