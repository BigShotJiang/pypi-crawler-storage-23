#!/bin/bash

nix-env -iA nixpkgs.gitui
