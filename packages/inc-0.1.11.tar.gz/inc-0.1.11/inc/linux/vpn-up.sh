#!/bin/sh

sudo cp vpn-up /etc/NetworkManager/dispatcher.d/vpn-up
