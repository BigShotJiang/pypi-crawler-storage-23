#!/bin/sh

sudo apt install davmail
