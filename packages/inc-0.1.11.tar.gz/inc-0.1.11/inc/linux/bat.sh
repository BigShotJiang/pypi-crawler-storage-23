
cargo install --locked bat
