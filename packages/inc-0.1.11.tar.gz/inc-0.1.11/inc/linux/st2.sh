#!/bin/sh

git clone https://github.com/BrodieRobertson/st.git
cd st
make clean install
