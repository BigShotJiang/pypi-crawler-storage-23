#!/bin/sh
# presentation from the command line

git clone https://github.com/visit1985/mdp.git
cd mdp
make
sudo make install
