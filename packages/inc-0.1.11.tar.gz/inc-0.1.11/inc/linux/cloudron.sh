#!/bin/sh

npm install -g cloudron
