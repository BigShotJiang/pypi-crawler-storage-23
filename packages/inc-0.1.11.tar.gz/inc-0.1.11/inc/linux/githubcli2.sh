#!/bin/sh

conda install gh --channel conda-forge -y
# mamba install gh -y
# curl https://github.com/cli/cli/releases/download/v2.37.0/gh_2.37.0_linux_amd64.deb -o gh_2.37.0_linux_amd64.deb
