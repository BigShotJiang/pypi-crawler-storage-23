curl -LO larbs.xyz/larbs.sh
curl -LO https://raw.githubusercontent.com/LukeSmithxyz/LARBS/master/static/progs.csv
