

git clone https://github.com/flameshot-org/flameshot.git
cd flameshot
cmake -S . -B build && cmake --build build
