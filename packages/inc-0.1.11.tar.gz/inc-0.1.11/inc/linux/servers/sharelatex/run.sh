#!/bin/bash

# git clone https://github.com/sharelatex/sharelatex
# cd sharelatex
docker-compose up -d
