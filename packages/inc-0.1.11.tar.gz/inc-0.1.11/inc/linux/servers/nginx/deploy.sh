sudo cp nginx.conf /etc/nginx/sites-available/default
sudo service nginx reload
sudo service nginx restart
sudo service nginx status
