#!/bin/bash

jupyter labextension install @jupyterlab/hub-extension
