#!/bin/bash

conda install -c conda-forge jupyterhub
conda install notebook
conda install jupyterlab

# pip3 install jupyterhub
# pip3 install jupyterlab
# pip3 install jupyter
# jupyter labextension install @jupyterlab/hub-extension
