
https://github.com/mlshapiro/jupyterlab-flake8
pip install flake8
