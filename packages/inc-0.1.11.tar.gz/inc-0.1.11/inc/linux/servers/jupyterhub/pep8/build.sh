#!/bin/bash

npm install
npm run build
jupyter labextension install
