


https://ipython.readthedocs.io/en/latest/install/kernel_install.html
