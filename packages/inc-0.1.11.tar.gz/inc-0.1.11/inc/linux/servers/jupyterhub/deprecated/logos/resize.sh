#!/bin/bash
# convert luceda.png -resize 64x64 ipkiss3/logo-64x64.png
# convert luceda.png -resize 32x32 ipkiss3/logo-32x32.png

convert meep.png -resize 32x32 ../kernels_centos/meep/logo-32x32.png
convert meep.png -resize 64x64 ../kernels_centos/meep/logo-64x64.png
