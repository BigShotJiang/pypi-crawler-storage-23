
Links:

- https://opendreamkit.org/2018/10/17/jupyterhub-docker/
- https://the-littlest-jupyterhub.readthedocs.io/en/latest/topic/installer-actions.html#topic-installer-actions


conda install -c anaconda python=3.7
sudo tljh-config reload hub
