# Mediagoblin

Mediaglobin is a hosting video service, similar to Youtube that we internally host, to safely store our videos

Default user:

Add users `./bin/gmg adduser`

# References

- http://mediagoblin.readthedocs.io/en/stable/siteadmin/about.html
- http://mediagoblin.readthedocs.io/en/stable/siteadmin/deploying.html#drop-privileges-for-mediagoblin
- http://mediagoblin.readthedocs.io/en/stable/siteadmin/production-deployments.html
