
- https://hackernoon.com/setting-up-gitlab-jenkins-ci-with-docker-da74c67373ac
- https://github.com/dkaushik94/Gitlab-Jenkins
