#!/bin/bash

cp .python-gitlab.cfg ~
