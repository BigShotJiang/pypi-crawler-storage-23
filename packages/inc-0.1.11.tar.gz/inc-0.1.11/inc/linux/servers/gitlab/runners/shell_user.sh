#!/bin/sh

sudo useradd --comment "gitlab runner" --create-home gitlab-runner --shell /bin/bash
