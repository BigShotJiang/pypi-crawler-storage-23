
/etc/gitlab/gitlab.rb
