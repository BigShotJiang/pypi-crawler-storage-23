# Kubernetes cluster

Kubernetes manages a container cluster


kubectl get nodes
kubectl get services
kubectl apply -f aws-auth-cm.yaml


References:
- https://docs.aws.amazon.com/eks/latest/userguide/getting-started.html
- https://docs.aws.amazon.com/eks/latest/userguide/launch-workers.html
