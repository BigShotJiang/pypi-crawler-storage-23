#!/bin/sh
# https://docs.sandstorm.io/en/latest/guided-tour/#create-a-virtual-machine-in-amazon-ec2

curl https://install.sandstorm.io | bash
