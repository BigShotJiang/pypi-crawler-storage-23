

Terraform allows you to build infrastructure as code
