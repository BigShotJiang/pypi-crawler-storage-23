# Lutim

LUTIM (Lets upload that image) is an image server that hosts your images after you upload them
