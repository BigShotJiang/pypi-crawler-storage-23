#!/bin/bash
sudo add-apt-repository ppa:webupd8team/java
sudo apt-get install oracle-java7-installer
