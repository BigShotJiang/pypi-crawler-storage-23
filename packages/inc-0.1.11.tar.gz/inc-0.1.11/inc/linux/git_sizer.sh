
git clone https://github.com/github/git-sizer.git
cd git-sizer
