
curl -fsSL https://code-server.dev/install.sh | sh
