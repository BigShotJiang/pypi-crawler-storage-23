#!/bin/sh

rm -rf ~/.local/share/nvim
