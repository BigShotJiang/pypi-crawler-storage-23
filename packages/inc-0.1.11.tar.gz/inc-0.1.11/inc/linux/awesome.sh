#! /bin/bash

# awesome statusbar

git clone https://github.com/streetturtle/awesome-wm-widgets  ~/.config/awesome/
