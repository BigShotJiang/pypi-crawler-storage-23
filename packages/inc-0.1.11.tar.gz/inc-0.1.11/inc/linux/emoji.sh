
[ ! -d wofi-emoji ] && git clone https://github.com/Zeioth/wofi-emoji.git
ln -sf $PWD/wofi-emoji/wofi-emoji ~/.local/bin
