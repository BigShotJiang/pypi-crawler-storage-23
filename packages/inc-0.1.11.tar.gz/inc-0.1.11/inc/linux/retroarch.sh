#!/bin/sh
# console emulator

sudo pacman -Syu retroarch \
  mame \
  libretro-beetle-psx
