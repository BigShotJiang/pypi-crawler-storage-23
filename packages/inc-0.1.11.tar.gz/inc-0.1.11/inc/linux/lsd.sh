#!/bin/sh

cargo install lsd
