
sudo groupadd docker
sudo usermod -aG docker $USER
