#!/bin/sh

sudo zypper install -y git make
bash install suse.mk
