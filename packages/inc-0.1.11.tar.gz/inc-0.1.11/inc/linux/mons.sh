#!/bin/sh

git clone --recursive https://github.com/Ventto/mons.git
cd mons
sudo make install
