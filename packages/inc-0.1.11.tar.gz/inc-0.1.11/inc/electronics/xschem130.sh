#!/bin/sh

[ ! -d xschem_sky130 ] && git clone git@github.com:StefanSchippers/xschem_sky130.git
