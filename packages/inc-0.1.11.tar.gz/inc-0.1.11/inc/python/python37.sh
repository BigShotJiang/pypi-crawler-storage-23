mamba create -n "py37" python=3.7
