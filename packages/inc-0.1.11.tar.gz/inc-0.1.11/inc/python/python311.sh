mamba create -n "py311" python=3.11.4
