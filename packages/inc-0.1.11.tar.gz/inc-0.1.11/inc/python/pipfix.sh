#!/bin/sh

curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
