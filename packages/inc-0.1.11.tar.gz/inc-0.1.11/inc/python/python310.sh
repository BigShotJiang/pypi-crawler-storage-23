mamba create -n "py310" python=3.10
