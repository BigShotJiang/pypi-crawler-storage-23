#!/bin/sh

sudo ln -sf /usr/bin/python /usr/local/bin/python
