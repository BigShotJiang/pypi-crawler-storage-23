#!/bin/bash

# mkdir -p $HOME/.pip
# cp pip.conf $HOME/.pip/pip.conf
