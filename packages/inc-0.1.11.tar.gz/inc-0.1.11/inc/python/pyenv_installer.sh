#!/bin/sh

curl https://pyenv.run | bash
