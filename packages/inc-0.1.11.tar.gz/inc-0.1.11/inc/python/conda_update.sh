#!/bin/sh

conda update conda -y
conda update --all -y
