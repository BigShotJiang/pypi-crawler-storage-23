#!/bin/sh

echo "==> Installing Yarn (JavaScript package manager)..."

curl -o- -L https://yarnpkg.com/install.sh | bash

echo "==> Done! Yarn installed."
