#!/bin/sh

echo "==> Installing Nix package manager..."

curl -L https://nixos.org/nix/install | sh

echo "==> Done! Restart your shell to use Nix."
