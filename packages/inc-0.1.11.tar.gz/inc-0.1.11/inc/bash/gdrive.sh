#!/bin/sh

echo "==> Installing gdrive (Google Drive CLI)..."
echo "    https://github.com/gdrive-org/gdrive"

go get github.com/prasmussen/gdrive

echo "==> Done! gdrive installed."
