#!/bin/sh

echo "==> Installing Claude Code..."

npm install -g @anthropic-ai/claude-code

echo "==> Done! Run 'claude' to start Claude Code."
