__author__ = """Huu Hoa NGUYEN"""
__email__ = "huuhoa@gmail.com"
__version__ = '0.19.0'
__copyright__ = "Copyright (c) 2020-2025 Huu Hoa NGUYEN"
__license__ = "MIT License"
__description__ = "Render website to ebook to make it easier to read on devices"
