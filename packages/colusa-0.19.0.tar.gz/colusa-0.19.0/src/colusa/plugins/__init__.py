"""
Plugin architecture, based on decorators

References:
    1. https://play.pixelblaster.ro/blog/2017/12/18/a-quick-and-dirty-mini-plugin-system-for-python/
"""
