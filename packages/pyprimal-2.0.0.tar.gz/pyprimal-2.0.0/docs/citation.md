# Citation

If you use `pyprimal` in your research, please cite:

```bibtex
@article{li2018primal,
  title={The Parametric Simplex Method for Sparse Learning},
  author={Li, Zichong and Shen, Qianli and Zhao, Tuo},
  year={2018}
}
```

## Software

```bibtex
@software{pyprimal,
  title={pyprimal: Parametric Simplex Method for Sparse Learning},
  author={Li, Zichong and Shen, Qianli and Zhao, Tuo},
  url={https://github.com/Gatech-Flash/primal}
}
```
