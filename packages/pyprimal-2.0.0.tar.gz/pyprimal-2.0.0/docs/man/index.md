# Function Manual

This section is the Python equivalent of an R `man/` directory:
one page per public function with usage and argument notes.

## Solvers

- [`dantzig_solver`](dantzig_solver.md)
- [`sparse_svm_solver`](sparse_svm_solver.md)
- [`compressed_sensing_solver`](compressed_sensing_solver.md)
- [`quantile_regression_solver`](quantile_regression_solver.md)

## Result object

- [`PrimalResult`](PrimalResult.md)

## Result methods

- [`PrimalResult.summary`](summary.md)
- [`PrimalResult.coef`](coef.md)
- [`PrimalResult.plot`](plot.md)

## Runtime helper

- [`test`](test.md)
