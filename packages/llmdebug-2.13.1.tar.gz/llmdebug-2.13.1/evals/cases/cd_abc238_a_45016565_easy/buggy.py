n = int(input())
if n >= 5:
    print("Yes")
else:
    print("No")
