# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""CLI module for airbyte-ops command-line interface."""
