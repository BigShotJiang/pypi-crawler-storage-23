"""HeyLead MCP tools — the 5 core tools that make up the MVP."""
