__title__ = 'django-imagekit'
__author__ = 'Matthew Tretter, Venelin Stoykov, Eric Eldredge, Bryan Veloso, Greg Newman, Chris Drackett, Justin Driscoll'
__version__ = '6.1.0'
__license__ = 'BSD'
__all__ = ['__title__', '__author__', '__version__', '__license__']
