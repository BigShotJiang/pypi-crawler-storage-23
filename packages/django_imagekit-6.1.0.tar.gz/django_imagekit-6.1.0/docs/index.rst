.. include:: ../README.rst


Authors
=======

.. include:: ../AUTHORS


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. toctree::
    :glob:
    :maxdepth: 2

    configuration
    advanced_usage
    caching
    upgrading
