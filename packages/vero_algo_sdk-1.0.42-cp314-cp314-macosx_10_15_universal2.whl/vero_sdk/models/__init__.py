"""
Models (DTOs) and Enums for Vero Algo SDK.

All data transfer objects, enums, and type definitions are stored here.
"""

from .enums import (
    OrderSide,
    OrderType,
    OrderStatus,
    AlgoStatus,
    RunMode,
    PositionSide,
    Timeframe,
    DatePreset,
)
from .orders import (
    PersistenceInfo,
    NewOrderRequest,
    CancelOrderRequest,
    OrderData,
    OrderResponse,
    Trade,
)
from .market_data import (
    Candle,
    PriceLevel,
    ProductMaster,
    MarginRatio,
    ProductInfo,
    ProductStat,
    Depth,
)
from .account import Account
from .streaming import SubscribeData, StreamMessage
from .settings import StrategyInitSettings
from .position import Position, ClosedPosition, AccountInfo
from .risk import RiskSettings
from .reports import StrategyMetrics, PerformanceReport

__all__ = [
    # Enums
    "OrderSide",
    "OrderType",
    "OrderStatus",
    "AlgoStatus",
    "RunMode",
    "PositionSide",
    "Timeframe",
    "DatePreset",
    # Orders
    "PersistenceInfo",
    "NewOrderRequest",
    "CancelOrderRequest",
    "OrderData",
    "OrderResponse",
    "Trade",
    # Market Data
    "Candle",
    "PriceLevel",
    "ProductMaster",
    "MarginRatio",
    "ProductInfo",
    "ProductStat",
    "Depth",
    # Account
    "Account",
    # Streaming
    "SubscribeData",
    "StreamMessage",
    # Settings
    "StrategyInitSettings",
    # Position
    "Position",
    "ClosedPosition",
    "AccountInfo",
    # Risk
    "RiskSettings",
    # Reports
    "StrategyMetrics",
    "PerformanceReport",
]
