"""
Risk manager for Vero Algo SDK.

Monitors positions and enforces risk limits automatically.
"""

from datetime import datetime
from typing import Tuple, Optional, List

from ..models import RiskSettings, Position, PositionSide
from ..strategy.context import TradingContext
from ..utils.logging_config import StrategyLogger, VeroLogger


_logger = VeroLogger("risk")


class RiskManager:
    """
    Automated risk management engine.
    
    Monitors positions and enforces:
    - Daily P&L limits
    - Per-position stop-loss and take-profit
    - Max drawdown protection
    - Position count limits
    - Order size limits
    - Trailing stops
    """
    
    def __init__(
        self,
        settings: RiskSettings,
        context: TradingContext,
        logger: StrategyLogger,
    ):
        """
        Initialize RiskManager.
        
        Args:
            settings: RiskSettings configuration
            context: TradingContext to monitor
            logger: Logger for risk events
        """
        self.settings = settings
        self.context = context
        self.logger = logger
        
        # State tracking
        self._halted = False
        self._halt_reason = ""
        self._consecutive_losses = 0
        self._paused_until: Optional[datetime] = None
        self._positions_to_close: List[str] = []
        
        _logger.debug(
            f"RiskManager initialized: max_daily_loss={settings.max_daily_loss:,.0f} "
            f"max_drawdown={settings.max_drawdown_pct}% max_positions={settings.max_open_positions} "
            f"max_order_qty={settings.max_order_qty}"
        )
    
    @property
    def is_halted(self) -> bool:
        """Check if trading is halted."""
        return self._halted
    
    @property
    def halt_reason(self) -> str:
        """Get reason for trading halt."""
        return self._halt_reason
    
    def can_open_position(
        self,
        symbol: str,
        side: PositionSide,
        qty: int,
        price: float,
    ) -> Tuple[bool, str]:
        """
        Check if a new position can be opened.
        
        Args:
            symbol: Trading symbol
            side: Position side
            qty: Quantity
            price: Entry price
            
        Returns:
            Tuple of (allowed, reason)
        """
        # Check if halted
        if self._halted:
            _logger.debug(f"can_open_position blocked: halted ({self._halt_reason})")
            return False, f"Trading halted: {self._halt_reason}"
        
        # Check if paused
        if self._paused_until and datetime.now() < self._paused_until:
            remaining = (self._paused_until - datetime.now()).seconds // 60
            _logger.debug(f"can_open_position blocked: paused for {remaining} more minutes")
            return False, f"Trading paused for {remaining} more minutes"
        
        # Check time restrictions
        if not self._check_trading_time():
            _logger.debug("can_open_position blocked: outside trading hours")
            return False, "Outside trading hours"
        
        # Check daily loss limit
        if abs(self.context.daily_pnl) >= self.settings.max_daily_loss:
            if self.settings.halt_on_daily_limit:
                self._halt("Daily loss limit reached")
            _logger.debug(f"can_open_position blocked: daily_pnl={self.context.daily_pnl:,.2f} >= limit={self.settings.max_daily_loss:,.2f}")
            return False, "Daily loss limit reached"
        
        # Check drawdown
        if self.context.drawdown >= self.settings.max_drawdown_pct:
            if self.settings.halt_on_drawdown:
                self._halt("Max drawdown reached")
            _logger.debug(f"can_open_position blocked: drawdown={self.context.drawdown:.2f}% >= limit={self.settings.max_drawdown_pct}%")
            return False, "Max drawdown reached"
        
        # Check max positions
        if len(self.context.positions) >= self.settings.max_open_positions:
            _logger.debug(f"can_open_position blocked: {len(self.context.positions)} positions >= max {self.settings.max_open_positions}")
            return False, f"Max {self.settings.max_open_positions} positions allowed"
        
        # Check positions per symbol
        symbol_positions = self.context.get_positions_by_symbol(symbol)
        if len(symbol_positions) >= self.settings.max_positions_per_symbol:
            _logger.debug(f"can_open_position blocked: {len(symbol_positions)} positions for {symbol} >= max {self.settings.max_positions_per_symbol}")
            return False, f"Max {self.settings.max_positions_per_symbol} positions per symbol"
        
        # Check order quantity
        if qty > self.settings.max_order_qty:
            _logger.debug(f"can_open_position blocked: qty={qty} > max={self.settings.max_order_qty}")
            return False, f"Qty {qty} exceeds max {self.settings.max_order_qty}"
        
        # Check order value
        order_value = qty * price
        if self.settings.max_order_value > 0 and order_value > self.settings.max_order_value:
            _logger.debug(f"can_open_position blocked: order_value={order_value:,.2f} > max={self.settings.max_order_value:,.2f}")
            return False, f"Order value {order_value} exceeds max {self.settings.max_order_value}"
        
        # Check free margin
        margin_required = order_value * 0.1  # Simplified
        min_margin = self.context.equity * self.settings.min_free_margin_pct / 100
        if self.context.account.free_margin - margin_required < min_margin:
            _logger.debug(
                f"can_open_position blocked: free_margin={self.context.account.free_margin:,.2f} "
                f"- margin_required={margin_required:,.2f} < min_margin={min_margin:,.2f}"
            )
            return False, "Insufficient free margin"
        
        _logger.debug(f"can_open_position allowed: {symbol} {side.value} qty={qty} @ {price:.4f}")
        return True, ""
    
    def check_positions(self) -> List[str]:
        """
        Check all positions against risk limits.
        
        Returns:
            List of position IDs that should be closed
        """
        positions_to_close = []
        
        for pos_id, position in list(self.context.positions.items()):
            should_close, reason = self._check_position(position)
            if should_close:
                positions_to_close.append(pos_id)
                self.logger.risk(f"Position {pos_id[:8]} flagged for close: {reason}")
        
        if positions_to_close:
            _logger.debug(f"check_positions: {len(positions_to_close)} positions flagged for close out of {len(self.context.positions)}")
        
        return positions_to_close
    
    def _check_position(self, position: Position) -> Tuple[bool, str]:
        """Check a single position against limits."""
        # Check stop loss trigger
        if position.should_stop_loss():
            _logger.debug(f"Position {position.id[:8]} {position.symbol}: stop loss triggered (SL={position.stop_loss}, price={position.current_price})")
            return True, "Stop loss triggered"
        
        # Check take profit trigger
        if position.should_take_profit():
            _logger.debug(f"Position {position.id[:8]} {position.symbol}: take profit triggered (TP={position.take_profit}, price={position.current_price})")
            return True, "Take profit triggered"
        
        # Calculate position P&L percentage
        pnl_pct = position.pnl_percent
        
        # Check max loss
        if pnl_pct <= -self.settings.max_position_loss_pct:
            if self.settings.auto_close_on_limit:
                _logger.debug(f"Position {position.id[:8]} {position.symbol}: max loss reached (pnl={pnl_pct:.2f}% <= -{self.settings.max_position_loss_pct}%)")
                return True, f"Max loss {self.settings.max_position_loss_pct}% reached"
        
        # Check max profit
        if pnl_pct >= self.settings.max_position_profit_pct:
            if self.settings.auto_close_on_limit:
                _logger.debug(f"Position {position.id[:8]} {position.symbol}: profit target reached (pnl={pnl_pct:.2f}% >= {self.settings.max_position_profit_pct}%)")
                return True, f"Profit target {self.settings.max_position_profit_pct}% reached"
        
        return False, ""
    
    def on_position_closed(self, pnl: float) -> None:
        """
        Handle position close event for consecutive loss tracking.
        
        Args:
            pnl: Realized P&L of closed position
        """
        if pnl < 0:
            self._consecutive_losses += 1
            _logger.debug(f"Consecutive losses: {self._consecutive_losses} (PnL={pnl:+,.2f})")
            
            if (self.settings.max_consecutive_losses > 0 and 
                self._consecutive_losses >= self.settings.max_consecutive_losses):
                
                self._pause_trading(self.settings.pause_after_losses_minutes)
                self.logger.risk(
                    f"Paused trading for {self.settings.pause_after_losses_minutes} minutes "
                    f"after {self._consecutive_losses} consecutive losses"
                )
        else:
            if self._consecutive_losses > 0:
                _logger.debug(f"Consecutive loss streak broken at {self._consecutive_losses} (PnL={pnl:+,.2f})")
            self._consecutive_losses = 0
    
    def _halt(self, reason: str) -> None:
        """Halt all trading."""
        self._halted = True
        self._halt_reason = reason
        self.logger.risk(f"TRADING HALTED: {reason}")
    
    def _pause_trading(self, minutes: int) -> None:
        """Pause trading for specified minutes."""
        from datetime import timedelta
        self._paused_until = datetime.now() + timedelta(minutes=minutes)
        _logger.info(f"Trading paused until {self._paused_until.strftime('%H:%M:%S')} ({minutes} minutes)")
    
    def _check_trading_time(self) -> bool:
        """Check if current time is within trading hours."""
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        
        if self.settings.no_trade_before:
            if current_time < self.settings.no_trade_before:
                return False
        
        if self.settings.no_trade_after:
            if current_time > self.settings.no_trade_after:
                return False
        
        return True
    
    def should_close_all(self) -> bool:
        """Check if all positions should be closed (end of day)."""
        if not self.settings.close_all_at:
            return False
        
        current_time = datetime.now().strftime("%H:%M")
        should = current_time >= self.settings.close_all_at
        if should:
            _logger.info(f"End-of-day close triggered: current={current_time} >= close_all_at={self.settings.close_all_at}")
        return should
    
    def reset_daily(self) -> None:
        """Reset daily counters (call at start of new trading day)."""
        _logger.info(f"Resetting daily counters: prev_daily_pnl={self.context.daily_pnl:+,.2f} consecutive_losses={self._consecutive_losses}")
        self.context.reset_daily_pnl()
        self._consecutive_losses = 0
        self._paused_until = None
        
        # Only resume if halted due to daily limit
        if self._halted and "daily" in self._halt_reason.lower():
            self._halted = False
            self._halt_reason = ""
            self.logger.info("Daily limits reset, trading resumed")
    
    def resume_trading(self) -> None:
        """Manually resume trading after halt."""
        _logger.info(f"Trading manually resumed (was halted: {self._halted}, reason: {self._halt_reason})")
        self._halted = False
        self._halt_reason = ""
        self._paused_until = None
        self.logger.info("Trading manually resumed")
