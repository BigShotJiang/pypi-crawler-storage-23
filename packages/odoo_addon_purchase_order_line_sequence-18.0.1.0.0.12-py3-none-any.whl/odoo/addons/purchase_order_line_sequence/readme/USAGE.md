This module depends on the following module(s) :  
- stock_picking_line_sequence
  (<https://github.com/OCA/stock-logistics-workflow/>)
