### sosdiff
Compare two [sosreport](https://github.com/sosreport/sos) and show the differences.

- To compare them `sosdiff` reads the file `sos_reports/sos.json` and lists the differences:
  - [-] Plugin is missing on sosreport2. 
  - [--] Entity is missing on sosreport2. 
  - [---] File is missing on sosreport2.
  - [/] File content is different. Optionally show `diff` command output.
  - [+] Plugin is present on sosreport2 but it isn't on sosreport1.
  - [++] Entity is present on sosreport2 but it isn't on sosreport1.
  - [+++] File is present on sosreport2 but it isn't on sosreport1.
- Some files are automatically exluded to avoid "Too many levels of symbolic links" errors.
  - Refer to [excluded_href](https://github.com/pafernanr/sosdiff/blob/main/sosdiff/lib/util.py#L20)
- Custom excluded files can be added to configuration file at `~/.sosdiff/configuration.yaml`.
   
#### Installation
There are multiple ways to to install `sosdiff`.

- Using `pip`.
  ~~~
  pip install sosdiff
  ~~~

- Using the prebuild packages at [Latest Release](https://github.com/pafernanr/sosdiff/releases/latest)

#### Usage
~~~
usage: sosdiff [-h] [-c <config_file>] [-d] [-n SKIP_PLUGINS] [-o ONLY_PLUGINS] [-t] sospath1 sospath2

Compare two sosreports and show the differences.

positional arguments:
  sospath1              Path to first sosreport folder.
  sospath2              Path to second sosreport folder.

options:
  -h, --help            show this help message and exit
  -c <config_file>, --configuration <config_file>
                        Configuration file. Defaults to `/home/pablofr/.sosdiff/configuration.ini`
  -d, --diff            Show `diff` when file content don't match.
  -n SKIP_PLUGINS, --skip-plugins SKIP_PLUGINS
                        disable these plugins. Can be used multiple times.
  -o ONLY_PLUGINS, --only-plugins ONLY_PLUGINS
                        enable these plugins only. Can be used multiple times.
  -t, --text            Print plain text without colors.
~~~
