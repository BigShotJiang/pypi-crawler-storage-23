"""Prefect submitit integration."""

from __future__ import annotations
