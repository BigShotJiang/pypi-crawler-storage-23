# prefect-submitit

Prefect submitit integration.

---

## Quick Start

**Prerequisites:** Python 3.12+, [Pixi](https://pixi.sh)

```bash
# Install Pixi (if needed)
curl -fsSL https://pixi.sh/install.sh | bash

# Clone and install
git clone https://github.com/andrewhunt/prefect-submitit.git
cd prefect-submitit
pixi install

# Verify
pixi run python -c "import prefect_submitit; print('Installed successfully')"
```

---

## Development

```bash
pixi run -e dev test    # Run tests
pixi run -e dev fmt     # Format and lint
```

---

## License

BSD 3-Clause. See [LICENSE](LICENSE) for details.
