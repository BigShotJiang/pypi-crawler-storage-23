from .runner import run_system_tests

if __name__ == "__main__":
    run_system_tests()
