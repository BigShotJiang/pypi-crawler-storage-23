"""
Readiness Manager for AIO-Dev.

Provides application-specific readiness checks to ensure the AIO environment
is properly configured for deploying specific GenAI applications.
"""

import os
import subprocess
from typing import Dict, List, Optional, Tuple, Any
from pathlib import Path

from rich.console import Console
from rich.table import Table

from .config import AIOConfig
from .k3s import K3sManager
from .helm import HelmManager
from .utils import validate_prerequisites

console = Console()


class ReadinessManager:
    """Manager for application readiness checks."""

    def __init__(self, config: AIOConfig):
        """Initialize the readiness manager."""
        self.config = config
        self.k3s = K3sManager(config.k3s)
        self.helm = HelmManager()

    def check_application_readiness(self, app_name: str, namespace: Optional[str] = None,
                                  environment: Optional[str] = None, verbose: bool = False,
                                  json_output: bool = False) -> bool:
        """
        Check if the AIO environment is ready for a specific application.

        Args:
            app_name: Name of the application to check readiness for
            namespace: Target namespace (defaults to app name or config namespace)
            environment: Environment (dev, stage, prod)
            verbose: Show detailed information
            json_output: Output in JSON format

        Returns:
            True if environment is ready, False otherwise
        """
        # Determine environment from kubectl context if not specified
        if not environment:
            environment = self._detect_environment_from_context()

        # Determine namespace based on environment if not specified
        if not namespace:
            namespace = self._get_namespace_for_environment(environment, app_name)

        console.print(f"[dim]Application: {app_name}[/dim]")
        console.print(f"[dim]Namespace: {namespace}[/dim]")
        console.print(f"[dim]Environment: {environment}[/dim]")
        console.print()

        # Run all readiness checks
        checks = []
        checks.extend(self._check_prerequisites())
        checks.extend(self._check_cluster_readiness())
        checks.extend(self._check_namespace_readiness(namespace))
        checks.extend(self._check_infrastructure_readiness(app_name, environment))
        checks.extend(self._check_application_specific_readiness(app_name, namespace, environment))

        if json_output:
            import json
            results = {
                "application": app_name,
                "namespace": namespace,
                "environment": environment,
                "checks": [
                    {
                        "category": check[0],
                        "check": check[1],
                        "status": "passed" if check[2] else "failed",
                        "message": check[3],
                        "details": check[4] if len(check) > 4 else None
                    }
                    for check in checks
                ]
            }
            console.print(json.dumps(results, indent=2))
        else:
            self._display_readiness_results(checks, verbose)

        # Return overall readiness status
        all_passed = all(check[2] for check in checks)
        return all_passed

    def _detect_environment_from_context(self) -> str:
        """Detect environment from current kubectl context."""
        try:
            result = subprocess.run(
                ["kubectl", "config", "current-context"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                current_context = result.stdout.strip()
                
                # Map contexts to environments
                context_to_env = {
                    "default": "local",  # Local K3s cluster
                    "aio-dev": "dev",
                    "aio-stage": "stage", 
                    "aio-prod": "prod"
                }
                
                return context_to_env.get(current_context, "dev")
        except:
            pass
        
        # Fallback to environment variable or dev
        return os.getenv("ENVIRONMENT", "dev").lower()

    def _get_namespace_for_environment(self, environment: str, app_name: str) -> str:
        """Get the appropriate namespace for the given environment."""
        # Environment to namespace mapping
        env_namespaces = {
            "local": "aio-local",
            "dev": "aio-dev", 
            "stage": "aio-stage",
            "prod": "aio-prod"
        }
        
        # Return environment-specific namespace, fallback to app name
        return env_namespaces.get(environment, app_name.lower())

    def _check_prerequisites(self) -> List[Tuple[str, str, bool, str, Optional[Any]]]:
        """Check system prerequisites."""
        checks = []

        # Check tools
        all_ok, missing = validate_prerequisites()
        checks.append((
            "Prerequisites",
            "Required Tools",
            all_ok,
            f"All tools installed ({', '.join(['kubectl', 'helm', 'git'])})" if all_ok else f"Missing tools: {', '.join(missing)}",
            {"missing_tools": missing} if not all_ok else None
        ))

        # Check kubeconfig
        kubeconfig_valid = self._check_kubeconfig()
        checks.append((
            "Prerequisites",
            "Kubeconfig Access",
            kubeconfig_valid,
            "Kubeconfig is accessible and valid" if kubeconfig_valid else "Kubeconfig not accessible or invalid",
            None
        ))

        return checks

    def _check_cluster_readiness(self) -> List[Tuple[str, str, bool, str, Optional[Any]]]:
        """Check cluster readiness."""
        checks = []

        # Check if cluster is running
        cluster_running = self.k3s.is_installed()
        checks.append((
            "Cluster",
            "Cluster Status",
            cluster_running,
            "Kubernetes cluster is running" if cluster_running else "Kubernetes cluster is not running",
            None
        ))

        if cluster_running:
            # Check node readiness
            nodes_ready = self._check_nodes_ready()
            checks.append((
                "Cluster",
                "Node Readiness",
                nodes_ready,
                "All nodes are ready" if nodes_ready else "Some nodes are not ready",
                None
            ))

            # Check cluster resources
            resources_ok = self._check_cluster_resources()
            checks.append((
                "Cluster",
                "Resource Availability",
                resources_ok,
                "Sufficient cluster resources available" if resources_ok else "Insufficient cluster resources",
                None
            ))

        return checks

    def _check_namespace_readiness(self, namespace: str) -> List[Tuple[str, str, bool, str, Optional[Any]]]:
        """Check namespace readiness."""
        checks = []

        # Check if namespace exists
        namespace_exists = self._check_namespace_exists(namespace)
        if not namespace_exists:
            checks.append((
                "Namespace",
                "Namespace Existence",
                False,
                f"Namespace '{namespace}' does not exist",
                {"action": "Will be created during deployment"}
            ))
        else:
            checks.append((
                "Namespace",
                "Namespace Existence",
                True,
                f"Namespace '{namespace}' exists",
                None
            ))

        return checks

    def _check_infrastructure_readiness(self, app_name: str, environment: str) -> List[Tuple[str, str, bool, str, Optional[Any]]]:
        """Check infrastructure readiness for the application."""
        checks = []

        # Check required infrastructure based on environment
        infra_config = self.config.infrastructure

        # Check ingress readiness
        if infra_config.ingress:
            ingress_ready = self._check_ingress_readiness()
            checks.append((
                "Infrastructure",
                "Ingress Controller",
                ingress_ready,
                "Ingress controller is available" if ingress_ready else "Ingress controller not found",
                None
            ))

        # Check cert-manager readiness
        if infra_config.cert_manager:
            cert_manager_ready = self._check_cert_manager_readiness()
            checks.append((
                "Infrastructure",
                "Certificate Manager",
                cert_manager_ready,
                "Cert-manager is available" if cert_manager_ready else "Cert-manager not found",
                None
            ))

        # Check monitoring readiness
        if infra_config.monitoring:
            monitoring_ready = self._check_monitoring_readiness()
            checks.append((
                "Infrastructure",
                "Monitoring Stack",
                monitoring_ready,
                "Monitoring stack is available" if monitoring_ready else "Monitoring stack not found",
                None
            ))

        # Check storage readiness
        storage_ready = self._check_storage_readiness()
        checks.append((
            "Infrastructure",
            "Storage Classes",
            storage_ready,
            "Storage classes are available" if storage_ready else "No storage classes available",
            None
        ))

        return checks

    def _check_application_specific_readiness(self, app_name: str, namespace: str, environment: str) -> List[Tuple[str, str, bool, str, Optional[Any]]]:
        """Check application-specific readiness requirements."""
        checks = []

        # Check if application is configured
        app_configured = self._check_app_configuration(app_name)
        checks.append((
            "Application",
            "Configuration",
            app_configured,
            f"Application '{app_name}' is configured" if app_configured else f"Application '{app_name}' not found in configuration",
            None
        ))

        if app_configured:
            # Check application-specific requirements
            app_checks = self._get_app_specific_checks(app_name, namespace, environment)
            checks.extend(app_checks)

        return checks

    def _check_kubeconfig(self) -> bool:
        """Check if kubeconfig is accessible."""
        try:
            result = subprocess.run(
                ["kubectl", "cluster-info"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except:
            return False

    def _check_nodes_ready(self) -> bool:
        """Check if all nodes are ready."""
        try:
            result = subprocess.run(
                ["kubectl", "get", "nodes", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode != 0:
                return False

            lines = result.stdout.strip().split('\n')
            for line in lines:
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 2:
                        status = parts[1]
                        if 'NotReady' in status or 'SchedulingDisabled' in status:
                            return False
            return True
        except:
            return False

    def _check_cluster_resources(self) -> bool:
        """Check if cluster has sufficient resources."""
        try:
            # Check if we can get node resources
            result = subprocess.run(
                ["kubectl", "get", "nodes", "-o", "json"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except:
            return False

    def _check_namespace_exists(self, namespace: str) -> bool:
        """Check if namespace exists."""
        try:
            result = subprocess.run(
                ["kubectl", "get", "namespace", namespace],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except:
            return False

    def _check_ingress_readiness(self) -> bool:
        """Check if ingress controller is available."""
        try:
            # Check for nginx ingress controller
            result = subprocess.run(
                ["kubectl", "get", "pods", "-n", "ingress-nginx", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0 and result.stdout.strip():
                return True

            # Check for other ingress controllers
            result = subprocess.run(
                ["kubectl", "get", "pods", "-A", "-l", "app.kubernetes.io/name=ingress-nginx", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0 and result.stdout.strip()
        except:
            return False

    def _check_cert_manager_readiness(self) -> bool:
        """Check if cert-manager is available."""
        try:
            result = subprocess.run(
                ["kubectl", "get", "pods", "-n", "cert-manager", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0 and result.stdout.strip()
        except:
            return False

    def _check_monitoring_readiness(self) -> bool:
        """Check if monitoring stack is available."""
        try:
            # Check for prometheus
            result = subprocess.run(
                ["kubectl", "get", "pods", "-n", "monitoring", "-l", "app.kubernetes.io/name=prometheus", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0 and result.stdout.strip():
                return True

            # Check for kube-prometheus-stack
            result = subprocess.run(
                ["kubectl", "get", "pods", "-A", "-l", "app.kubernetes.io/name=kube-prometheus-stack", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0 and result.stdout.strip()
        except:
            return False

    def _check_storage_readiness(self) -> bool:
        """Check if storage classes are available."""
        try:
            result = subprocess.run(
                ["kubectl", "get", "storageclass", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0 and result.stdout.strip()
        except:
            return False

    def _check_app_configuration(self, app_name: str) -> bool:
        """Check if application is configured in AIO config."""
        for chart in self.config.helm_charts:
            if chart.name.lower() == app_name.lower():
                return True
        return False

    def _get_app_specific_checks(self, app_name: str, namespace: str, environment: str) -> List[Tuple[str, str, bool, str, Optional[Any]]]:
        """Get application-specific readiness checks."""
        checks = []

        # GenAI Healthcare specific checks
        if app_name.lower() == "genai-healthcare":
            checks.extend(self._check_genai_healthcare_readiness(namespace, environment))

        # Add more application-specific checks here as needed

        return checks

    def _check_genai_healthcare_readiness(self, namespace: str, environment: str) -> List[Tuple[str, str, bool, str, Optional[Any]]]:
        """Check readiness for GenAI Healthcare application."""
        checks = []

        # Check for required secrets/configmaps
        required_secrets = ["genai-healthcare-secrets", "database-credentials"]
        for secret in required_secrets:
            secret_exists = self._check_secret_exists(secret, namespace)
            checks.append((
                "GenAI Healthcare",
                f"Secret: {secret}",
                secret_exists,
                f"Secret '{secret}' exists" if secret_exists else f"Secret '{secret}' not found",
                {"action": "Create secret before deployment"} if not secret_exists else None
            ))

        # Check for required configmaps
        required_configmaps = ["genai-healthcare-config", "model-config"]
        for configmap in required_configmaps:
            cm_exists = self._check_configmap_exists(configmap, namespace)
            checks.append((
                "GenAI Healthcare",
                f"ConfigMap: {configmap}",
                cm_exists,
                f"ConfigMap '{configmap}' exists" if cm_exists else f"ConfigMap '{configmap}' not found",
                {"action": "Create configmap before deployment"} if not cm_exists else None
            ))

        # Check for GPU resources if required
        gpu_required = environment in ["stage", "prod"]  # Assume GPU needed for stage/prod
        if gpu_required:
            gpu_available = self._check_gpu_resources()
            checks.append((
                "GenAI Healthcare",
                "GPU Resources",
                gpu_available,
                "GPU resources available" if gpu_available else "GPU resources not available",
                {"note": "GPU required for production workloads"} if not gpu_available else None
            ))

        # Check for persistent storage
        storage_required = True  # GenAI apps typically need persistent storage
        if storage_required:
            pvc_ready = self._check_pvc_readiness(namespace)
            checks.append((
                "GenAI Healthcare",
                "Persistent Storage",
                pvc_ready,
                "Persistent storage configured" if pvc_ready else "Persistent storage not configured",
                None
            ))

        return checks

    def _check_secret_exists(self, secret_name: str, namespace: str) -> bool:
        """Check if a secret exists."""
        try:
            result = subprocess.run(
                ["kubectl", "get", "secret", secret_name, "-n", namespace],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except:
            return False

    def _check_configmap_exists(self, configmap_name: str, namespace: str) -> bool:
        """Check if a configmap exists."""
        try:
            result = subprocess.run(
                ["kubectl", "get", "configmap", configmap_name, "-n", namespace],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except:
            return False

    def _check_gpu_resources(self) -> bool:
        """Check if GPU resources are available."""
        try:
            result = subprocess.run(
                ["kubectl", "get", "nodes", "-o", "json"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode != 0:
                return False

            import json
            data = json.loads(result.stdout)
            for node in data.get('items', []):
                capacity = node.get('status', {}).get('capacity', {})
                if 'nvidia.com/gpu' in capacity or 'amd.com/gpu' in capacity:
                    return True
            return False
        except:
            return False

    def _check_pvc_readiness(self, namespace: str) -> bool:
        """Check if PVCs are ready in the namespace."""
        try:
            result = subprocess.run(
                ["kubectl", "get", "pvc", "-n", namespace, "--no-headers"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except:
            return False

    def _display_readiness_results(self, checks: List[Tuple[str, str, bool, str, Optional[Any]]], verbose: bool = False):
        """Display readiness check results in a formatted way."""
        # Group checks by category
        categories = {}
        for check in checks:
            category = check[0]
            if category not in categories:
                categories[category] = []
            categories[category].append(check)

        # Display results by category
        for category, category_checks in categories.items():
            console.print(f"[bold blue]{category} Checks:[/bold blue]")

            table = Table()
            table.add_column("Check", style="cyan")
            table.add_column("Status", style="green")
            table.add_column("Message", style="white")

            all_passed = True
            for check in category_checks:
                _, check_name, passed, message, details = check
                status = "[green]✓ PASS[/green]" if passed else "[red]✗ FAIL[/red]"
                table.add_row(check_name, status, message)

                if not passed:
                    all_passed = False

                if verbose and details:
                    console.print(f"[dim]  Details: {details}[/dim]")

            console.print(table)

            if all_passed:
                console.print(f"[green]✓ All {category.lower()} checks passed[/green]")
            else:
                console.print(f"[red]✗ Some {category.lower()} checks failed[/red]")

            console.print()

        # Overall summary
        total_checks = len(checks)
        passed_checks = sum(1 for check in checks if check[2])
        failed_checks = total_checks - passed_checks

        console.print("[bold cyan]Overall Readiness Summary:[/bold cyan]")
        console.print(f"  Total checks: {total_checks}")
        console.print(f"  Passed: [green]{passed_checks}[/green]")
        console.print(f"  Failed: [red]{failed_checks}[/red]")

        if failed_checks == 0:
            console.print("\n[green]🎉 Environment is ready for deployment![/green]")
            return True
        else:
            console.print(f"\n[red]❌ Environment is not ready. {failed_checks} checks failed.[/red]")
            console.print("[yellow]💡 Address the failed checks before deploying.[/yellow]")
            return False