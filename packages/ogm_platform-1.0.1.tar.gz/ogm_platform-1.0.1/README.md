# OGM Platform

**All-in-One K3s Development Environment for GenAI Applications**

[![PyPI version](https://badge.fury.io/py/ogm-platform.svg)](https://pypi.org/project/ogm-platform/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

OGM Platform is a comprehensive command-line tool that simplifies Kubernetes development for Generative AI applications. It provides one-command setup for complete development environments with K3s or full Kubernetes clusters.

## Features

- 🚀 **One-Command Setup**: Initialize complete Kubernetes clusters (K3s or Full K8s)
- 🔄 **Multi-Environment Support**: Seamless deployment across local, dev, stage, and production
- 📦 **Helm Integration**: Automated Helm chart deployment and management
- 🔐 **Authentication Management**: Secure credential storage and Kubernetes context handling
- 📊 **Monitoring & Diagnostics**: Built-in health checks and troubleshooting tools
- 🔄 **GitOps Workflow**: Automated repository synchronization
- 🛡️ **Production Ready**: Enterprise-grade security and reliability

## Installation

```bash
pip install ogm-platform
```

## Quick Start

```bash
# Initialize a development environment
aio init

# Deploy applications
aio deploy

# Check cluster status
aio status

# Clean up environment
aio destroy
```

## Requirements

- Python 3.8+
- Docker (optional, for containerized deployments)
- kubectl (installed automatically)

## Documentation

For detailed documentation, visit [OGM Platform Docs](https://docs.ogmplatform.com).

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please read our [Contributing Guide](CONTRIBUTING.md) for details.

## Support

For support and questions:
- 📧 Email: dev@ogmplatform.com
- 📖 Documentation: https://docs.ogmplatform.com
- 🐛 Issues: [GitHub Issues](https://github.com/ogmworldwide/ogm-platform/issues)</content>
<parameter name="filePath">/home/mksaraf/projects/ogm-platform-package/README.md