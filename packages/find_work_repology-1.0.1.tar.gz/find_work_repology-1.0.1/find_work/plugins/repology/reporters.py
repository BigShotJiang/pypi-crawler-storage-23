# SPDX-License-Identifier: WTFPL
# SPDX-FileCopyrightText: 2025 Anna <cyber@sysrq.in>
# No warranty

"""
Results reporter for Repology results, such as repository problems.
"""

from typing import Any

from pydantic import validate_call
from repology_client.types import Problem

from find_work.core.reporters import AbstractReporter


class ConsoleProblemReporter(AbstractReporter[Problem]):
    reporter_name = "console"
    result_type = Problem

    def add_result(self, item: Problem) -> None:
        match item.type:
            case "homepage_dead":
                url = item.data.get("url", "URL is missing")
                status = item.data.get("status", 0)
                self.options.echo("\t", nl=False)
                self.options.echo(f"Homepage link <{url}> is dead ()")
