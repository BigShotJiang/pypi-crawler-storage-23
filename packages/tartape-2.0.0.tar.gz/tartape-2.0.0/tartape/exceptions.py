class TarIntegrityError(Exception):
    """Exception thrown when disk does not match inventory."""

    pass
