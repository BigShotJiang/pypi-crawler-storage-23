"""
Vocal SDK - Python client for Vocal API

Auto-generated from OpenAPI specification.
"""

from .client import AudioAPI, ModelsAPI, VocalSDK

__version__ = "0.3.3"
__all__ = ["VocalSDK", "ModelsAPI", "AudioAPI"]
