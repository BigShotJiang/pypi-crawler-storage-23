"""Consts for unions."""

UNION_SCHEMA_IGNORE_ERRORS = frozenset({"Invalid input type."})
