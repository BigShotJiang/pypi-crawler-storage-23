# Flashcard Quiz App

This is a simple CLI flashcard quiz I made.  
Add your own questions, quiz yourself, and see which ones you keep messing up.

## How to run

Just run:

```bash
python quiz.py