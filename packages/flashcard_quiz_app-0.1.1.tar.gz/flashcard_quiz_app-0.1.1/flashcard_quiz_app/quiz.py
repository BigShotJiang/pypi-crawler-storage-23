import json
import os
import random
import sys

def get_data_path(filename):
    data_dir = os.path.join(os.path.expanduser("~"), ".flashcard_app")
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    return os.path.join(data_dir, filename)

def run_quiz(cards, missed, track_missed=True):
    if not cards:
        print("No questions available")
        return

    print("\n========================")
    print("      FLASHCARD QUIZ")
    print("========================\n")

    cards_copy = list(cards)
    random.shuffle(cards_copy)
    score = 0
    total = len(cards_copy)

    for index, card in enumerate(cards_copy, start=1):
        print(f"Question {index}/{total}")
        answer = input(card["question"] + " ")

        if answer.strip().lower() == card["answer"].strip().lower():
            print("Correct!\n")
            score += 1

            for m_card in missed[:]:
                if m_card["question"] == card["question"] and m_card["answer"] == card["answer"]:
                    missed.remove(m_card)
        else:
            print(f"Wrong! Answer: {card['answer']}\n")

            if track_missed:
                is_missed = False
                for m_card in missed:
                    if m_card["question"] == card["question"]:
                        is_missed = True
                        break
                if not is_missed:
                    missed.append(card)

    print(f"Final Score: {score}/{total}\n")

def main():
    file_name = get_data_path("flashcards.json")
    missed_questions = get_data_path("missed.json")

    if os.path.exists(file_name):
        try:
            with open(file_name, "r") as f:
                flashcards = json.load(f)
        except json.JSONDecodeError:
            flashcards = []
    else:
        flashcards = []

    if os.path.exists(missed_questions):
        try:
            with open(missed_questions, "r") as f:
                missed = json.load(f)
        except json.JSONDecodeError:
            missed = []
    else:
        missed = []

    while True:
        add = input("Do you want to add a new flashcard? (Yes/No): ").lower()
        if add in ("yes", "y"):
            q = input("Enter question: ")
            a = input("Enter answer: ")
            cat = input("Enter category (eg. Math, Geography): ")
            flashcards.append({
                "question": q,
                "answer": a,
                "category": cat if cat else "General"
            })
            with open(file_name, "w") as f:
                json.dump(flashcards, f, indent=4)
        else:
            break

    if missed:
        review = input("Do you want to review missed questions first? (y/n): ").lower()
        if review in ("y", "yes"):
            run_quiz(missed, missed, track_missed=False)
            with open(missed_questions, "w") as f:
                json.dump(missed, f, indent=4)

    if flashcards:
        categories = sorted(set(card.get("category", "General") for card in flashcards))
        print("\nAvailable Categories:")
        for cat in categories:
            print("-", cat)
        print("- All")

        choice = input("Choose a category: ").strip()
        if choice.lower() == "all":
            selected_cards = flashcards
        else:
            selected_cards = [
                card for card in flashcards
                if card.get("category", "General").lower() == choice.lower()
            ]

        if selected_cards:
            run_quiz(selected_cards, missed)
            with open(missed_questions, "w") as f:
                json.dump(missed, f, indent=4)
        else:
            print("No cards found for that category.")
    else:
        if not missed:
            print("No flashcards available. Add some to start!")

if __name__ == "__main__":
    main()