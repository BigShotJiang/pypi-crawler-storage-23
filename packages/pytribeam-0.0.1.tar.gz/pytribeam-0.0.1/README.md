# pyTriBeam

![main_logo](https://raw.githubusercontent.com/sandialabs/pytribeam/refs/heads/gh-pages/docs/userguide/src/logo_color.png)

[![userguide][userguide_badge]](https://sandialabs.github.io/pytribeam/docs/userguide/book/index.html) [![api][api_badge]](https://sandialabs.github.io/pytribeam/docs/api/index.html) [![test-coverage][test-coverage_badge]](https://sandialabs.github.io/pytribeam/coverage_reports/combined/htmlcov/index.html) [![lint][lint_badge]](https://sandialabs.github.io/pytribeam/logs/lint.log) [![version][version_badge]](https://github.com/sandialabs/pytribeam) 

[userguide_badge]: https://sandialabs.github.io/pytribeam/badges/userguide.svg
[api_badge]: https://sandialabs.github.io/pytribeam/badges/api.svg
[test-coverage_badge]: https://sandialabs.github.io/pytribeam/badges/test-coverage.svg
[lint_badge]: https://sandialabs.github.io/pytribeam/badges/lint.svg
[version_badge]: https://sandialabs.github.io/pytribeam/badges/version.svg

## Getting Started

Installation instructions and more can be found in the [User Guide](https://sandialabs.github.io/pytribeam/docs/userguide/book/index.html).

More info coming soon!
