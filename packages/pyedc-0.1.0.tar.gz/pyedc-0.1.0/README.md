# pyedc

Meta package that installs both `pyedc-core` (JSON-LD helpers, middleware, API clients) and `pyedc-dataplane` (signaling routers and schemas). Installing `pyedc` pulls in everything you need to build and run the reference EDC data plane services.
