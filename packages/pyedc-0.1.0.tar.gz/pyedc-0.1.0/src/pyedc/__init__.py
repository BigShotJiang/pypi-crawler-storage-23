"""Meta package that brings in both pyedc-core and pyedc-dataplane."""

from importlib import import_module

import pyedc_core
import pyedc_dataplane

_CORE_PACKAGE = "pyedc_core"
_DATAPLANE_PACKAGE = "pyedc_dataplane"

# Lazily import to surface helpful errors if dependencies are missing.
for _package in (_CORE_PACKAGE, _DATAPLANE_PACKAGE):
    try:
        import_module(_package)
    except ImportError as exc:  # pragma: no cover - defensive import guard
        raise ImportError(
            f"pyedc requires '{_package}' to be installed; original error: {exc}"
        ) from exc

__all__ = ["pyedc_core", "pyedc_dataplane"]
