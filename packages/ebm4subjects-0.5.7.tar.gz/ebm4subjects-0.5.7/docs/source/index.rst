.. ebm4subjects documentation master file, created by
   sphinx-quickstart on Thu Oct  2 10:35:44 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ebm4subjects documentation
==========================

See the
`github <https://github.com/deutsche-nationalbibliothek/ebm4subjects/tree/main>`_
page for more details on this project.


.. toctree::
   Instructions <../README.md>
   ebm4subjects
   :maxdepth: 2
   :caption: Contents

