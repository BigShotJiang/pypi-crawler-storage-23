# Lodum Benchmark History

This file tracks the history of benchmark runs for Lodum. Each run is organized into a nested folder named by the date and description of the run.

| Run Date | Description | Path |
| :--- | :--- | :--- |
| 2025-01-19 | Initial Baseline | [benchmarks/results/2025-01-19_baseline/results.md](https://github.com/webmaven/lodum/blob/main/benchmarks/results/2025-01-19_baseline/results.md) |
| 2025-01-19 | Statistical & Optimized | [benchmarks/results/2025-01-19_statistical_optimized/results.md](https://github.com/webmaven/lodum/blob/main/benchmarks/results/2025-01-19_statistical_optimized/results.md) |
| 2026-01-20 | Merged & Safety Fixed | [benchmarks/results/2026-01-20_merged_performance/results.md](https://github.com/webmaven/lodum/blob/main/benchmarks/results/2026-01-20_merged_performance/results.md) ([Win32](https://github.com/webmaven/lodum/blob/main/benchmarks/results/2026-01-20_merged_performance/results_win32.md)) |
| 2026-01-24 | AST Verification | [benchmarks/results/2026-01-24_ast_verification/comparison.md](https://github.com/webmaven/lodum/blob/main/benchmarks/results/2026-01-24_ast_verification/comparison.md) ([Raw](https://github.com/webmaven/lodum/blob/main/benchmarks/results/2026-01-24_ast_verification/results.md)) |
| 2026-01-25 | Final Modular Refactor | [benchmarks/results/2026-01-25_final_modular_refactor/results.md](https://github.com/webmaven/lodum/blob/main/benchmarks/results/2026-01-25_final_modular_refactor/results.md) |

For the latest performance analysis and summary, see [PERFORMANCE.md](PERFORMANCE.md).