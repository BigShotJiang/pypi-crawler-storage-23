# Security Policy

## Supported Versions

The following versions of `lodum` are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 0.3.x   | :white_check_mark: |
| 0.2.x   | :white_check_mark: |
| < 0.2.0 | :x:                |

## Reporting a Vulnerability

We take the security of `lodum` seriously. If you believe you have found a security vulnerability, please report it to us by following these steps:

1.  **Do not open a public GitHub issue.**
2.  Email your findings to **zopemaven@gmail.com**.
3.  Include as much detail as possible, including steps to reproduce the issue.

We will acknowledge your report within 48 hours and provide a timeline for a fix if applicable. We request that you follow responsible disclosure practices and give us time to address the issue before making it public.
