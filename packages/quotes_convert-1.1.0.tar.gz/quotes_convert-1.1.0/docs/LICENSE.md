---
title: License
description: "MIT License for quotes-convert Python library."
keywords:
  - license
  - MIT license
  - open source
---

--8<-- "LICENSE"
