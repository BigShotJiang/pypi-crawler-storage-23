# Backward compatibility stub - imports from tool_decorators
from .tool_decorators import tool, skill

__all__ = ['skill', 'tool']
