# Backward compatibility stub - imports from capabilities_operations
from .capabilities_operations import (
    CapabilitiesOperations,
    CapabilitiesOperations as SkillManagerOperations,
)

__all__ = ['SkillManagerOperations', 'CapabilitiesOperations']
