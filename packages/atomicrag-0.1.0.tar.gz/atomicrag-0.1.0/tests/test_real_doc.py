"""
Test AtomicRAG with a real document (Red Hat App Modernization PDF content).
Reads a markdown file, indexes it, and runs queries against it.

Usage:
    export GOOGLE_API_KEY="your-key"
    python tests/test_real_doc.py
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atomicrag import IndexPipeline, RetrievePipeline, AtomicRAGConfig
from atomicrag.integrations.gemini import GeminiLLM, GeminiEmbedding

API_KEY = os.environ.get("GOOGLE_API_KEY", "")
if not API_KEY:
    raise RuntimeError("Set GOOGLE_API_KEY environment variable to run this test.")

DOC_PATH = Path(__file__).parent.parent / "atomicrag" / "_AcceleratingAppModernization-Entire_PDF_prompt_2.md"

TEST_QUERIES = [
    "What are the Red Hat OpenShift Developer Services?",
    "How does the Trusted Software Supply Chain work?",
    "What migration toolkits does Red Hat offer?",
    "What is the SPACE framework for measuring developer productivity?",
    "What is the difference between inner loop and outer loop development?",
]


def run_test():
    print("=" * 70)
    print("AtomicRAG Test: Real Document (App Modernization)")
    print("=" * 70)

    # Load document
    doc_text = DOC_PATH.read_text()
    print(f"\nDocument: {DOC_PATH.name}")
    print(f"Size: {len(doc_text)} chars, {len(doc_text.splitlines())} lines")

    # Init models
    llm = GeminiLLM(api_key=API_KEY, model="gemini-2.5-flash")
    embedding = GeminiEmbedding(api_key=API_KEY, model="models/gemini-embedding-001")

    config = AtomicRAGConfig(
        chunk_size=1000,
        chunk_overlap=150,
        verbose=True,
        result_top_n=3,
        traversal_depth=2,
        beam_size=10,
    )

    # === INDEX ===
    print("\n--- INDEXING ---\n")
    graph = IndexPipeline(llm=llm, embedding=embedding, config=config).run([
        {"text": doc_text, "doc_id": "app-modernization-pdf"}
    ])

    stats = graph.stats()
    print(f"\nGraph Stats: {stats}")
    print(f"Entities ({len(graph.entities)}): {[e.name for e in graph.entities[:15]]}...")
    print(f"Sample KU: \"{graph.knowledge_units[0].content}\"")
    print(f"Embedding dim: {len(graph.knowledge_units[0].embedding)}")

    assert stats["chunks"] >= 3, f"Expected >= 3 chunks, got {stats['chunks']}"
    assert stats["knowledge_units"] >= 10, f"Expected >= 10 KUs, got {stats['knowledge_units']}"
    assert stats["entities"] >= 10, f"Expected >= 10 entities, got {stats['entities']}"
    print("\n[PASS] Graph integrity OK")

    # Save
    graph.to_json("/tmp/atomicrag_real_doc_graph.json")
    print("[PASS] Graph saved to /tmp/atomicrag_real_doc_graph.json")

    # === RETRIEVE ===
    print("\n--- RETRIEVAL ---\n")
    retriever = RetrievePipeline(graph=graph, llm=llm, embedding=embedding, config=config)

    for query in TEST_QUERIES:
        print(f"\nQuery: \"{query}\"")
        print("-" * 60)
        results = retriever.search(query)

        print(f"  Entities extracted: {results.entities_extracted}")
        print(f"  KUs traversed: {results.graph_stats.get('kus_retrieved', 0)}")
        print(f"  Results: {len(results.items)} items")

        for i, item in enumerate(results.items, 1):
            print(f"\n  [{i}] Score: {item.score:.3f}")
            print(f"      Entities: {item.entity_names[:5]}")
            content_preview = item.content.replace('\n', ' ')[:150]
            print(f"      Content: {content_preview}...")

        assert len(results.items) > 0, f"No results for: {query}"
        assert results.items[0].score > 0, "Top score should be positive"
        print(f"\n  [PASS] Query OK ({len(results.items)} results, top={results.items[0].score:.3f})")

    print("\n" + "=" * 70)
    print("ALL REAL DOCUMENT TESTS PASSED")
    print("=" * 70)


if __name__ == "__main__":
    run_test()
