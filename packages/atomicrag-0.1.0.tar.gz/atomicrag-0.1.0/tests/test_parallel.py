"""
Test parallel processing for LLM extraction and embedding.
Compares sequential (concurrency=1) vs parallel (concurrency=10).
"""
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atomicrag import IndexPipeline, AtomicRAGConfig
from atomicrag.integrations.gemini import GeminiLLM, GeminiEmbedding

API_KEY = os.environ.get("GOOGLE_API_KEY", "")
if not API_KEY:
    raise RuntimeError("Set GOOGLE_API_KEY environment variable to run this test.")

DOC_PATH = Path(__file__).parent.parent / "atomicrag" / "_AcceleratingAppModernization-Entire_PDF_prompt_2.md"


def run_pipeline(label, ku_concurrency, embedding_concurrency):
    doc_text = DOC_PATH.read_text()
    llm = GeminiLLM(api_key=API_KEY, model="gemini-2.5-flash")
    embedding = GeminiEmbedding(api_key=API_KEY, model="models/gemini-embedding-001")

    config = AtomicRAGConfig(
        chunk_size=1000,
        chunk_overlap=150,
        verbose=True,
        ku_concurrency=ku_concurrency,
        embedding_concurrency=embedding_concurrency,
        embedding_batch_size=50,
    )

    print(f"\n{'='*60}")
    print(f"  {label}")
    print(f"  ku_concurrency={ku_concurrency}, embedding_concurrency={embedding_concurrency}")
    print(f"{'='*60}\n")

    start = time.time()
    graph = IndexPipeline(llm=llm, embedding=embedding, config=config).run([
        {"text": doc_text, "doc_id": "app-mod"}
    ])
    elapsed = time.time() - start

    stats = graph.stats()
    print(f"\n  Stats: {stats}")
    print(f"  Time: {elapsed:.1f}s")
    print(f"  Embedding dim: {len(graph.knowledge_units[0].embedding)}")

    assert stats["knowledge_units"] >= 10
    assert stats["entities"] >= 10
    assert len(graph.knowledge_units[0].embedding) > 0

    return elapsed, stats


def main():
    print("=" * 60)
    print("PARALLEL PROCESSING BENCHMARK")
    print("=" * 60)

    # Run parallel (concurrency=10) FIRST since it's the feature being tested
    t_parallel, s_parallel = run_pipeline(
        "PARALLEL (ku=10, emb=10)", ku_concurrency=10, embedding_concurrency=10
    )

    print(f"\n{'='*60}")
    print(f"RESULT")
    print(f"{'='*60}")
    print(f"  Parallel:   {t_parallel:.1f}s  ({s_parallel['knowledge_units']} KUs, {s_parallel['entities']} entities)")
    print(f"{'='*60}")
    print(f"\n[PASS] Parallel processing test completed successfully")


if __name__ == "__main__":
    main()
