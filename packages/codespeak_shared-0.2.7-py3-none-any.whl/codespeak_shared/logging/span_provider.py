"""Span provider abstraction for different logging implementations."""

import threading
from abc import ABC, abstractmethod
from collections.abc import Iterator
from contextlib import AbstractContextManager, contextmanager
from typing import Any


class SpanProvider(ABC):
    INDENT_STR = "  "

    """Abstract base class for span providers.

    A span provider creates context managers that represent hierarchical
    execution spans for tracing and logging purposes.
    """

    @abstractmethod
    def create_span(self, name: str) -> AbstractContextManager[Any]:
        """Create a span context manager.

        Args:
            name: Name of the span

        Returns:
            A context manager that can be used with 'with' statement
        """
        pass


class NoOpSpanProvider(SpanProvider):
    """Default no-op span provider that does nothing."""

    @contextmanager
    def create_span(self, name: str) -> Iterator[None]:
        """Create a no-op span that yields None and does nothing."""
        _ = name  # Unused, but kept for interface compliance
        yield None


# Global provider registry
_provider_lock = threading.Lock()
_current_provider: SpanProvider = NoOpSpanProvider()
_provider_set = False


def set_span_provider(provider: SpanProvider) -> None:
    """Set the global span provider.

    This can only be called once per process. Attempting to call it multiple
    times will raise a RuntimeError.

    Args:
        provider: The span provider to use globally

    Raises:
        RuntimeError: If a provider has already been set
    """
    global _current_provider, _provider_set

    with _provider_lock:
        if _provider_set:
            raise RuntimeError("Span provider has already been set")
        _current_provider = provider
        _provider_set = True


def get_span_provider() -> SpanProvider:
    """Get the current global span provider.

    Returns:
        The currently registered span provider, or NoOpSpanProvider if none set
    """
    return _current_provider
