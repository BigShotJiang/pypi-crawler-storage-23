"""Shared logging utility with span abstraction."""

from contextlib import AbstractContextManager
from typing import Any

from codespeak_shared.logging.span_provider import get_span_provider


class LoggingUtil:
    """Shared logging utility that delegates span creation to registered provider."""

    @staticmethod
    def Span(name: str) -> AbstractContextManager[Any]:
        """Create a span. Returns a context manager.

        The actual implementation depends on which span provider has been
        registered globally (OpenTelemetry for core, indenting logger for console-client).

        Args:
            name: Name of the span

        Returns:
            A context manager that can be used with 'with' statement
        """
        return get_span_provider().create_span(name)
