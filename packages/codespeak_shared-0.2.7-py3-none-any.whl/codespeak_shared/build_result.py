# ruff: noqa: TID251 - uses BaseException type incompatible with pydantic dataclasses
from dataclasses import dataclass
from typing import Literal, override


@dataclass
class BuildStatistics:
    cache_enabled: bool = True
    cache_hits: int = 0
    cache_misses: int = 0
    total_time: float = 0

    @override
    def __str__(self) -> str:
        cache_stats = (
            f"Cache hits: {self.cache_hits}, cache misses: {self.cache_misses}"
            if self.cache_enabled
            else "Cache disabled"
        )
        return f"{cache_stats}, total time: {self.total_time:.2f} s"


BuildResultType = Literal["succeeded", "failed", "skipped"]


@dataclass
class BuildResult:
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    SKIPPED = "skipped"

    enum_type: BuildResultType
    build_stats: BuildStatistics
    command: str
    exception: BaseException | None = None  # includes KeyboardInterrupt
    user_visible_message: str | None = None

    def __init__(
        self,
        enum_type: BuildResultType,
        command: str,
        exception: BaseException | None = None,
        user_visible_message: str | None = None,
    ):
        self.command = command
        self.enum_type = enum_type
        self.exception = exception
        self.user_visible_message = user_visible_message
        self.build_stats = BuildStatistics()

    @classmethod
    def succeeded(cls, command: str) -> "BuildResult":
        return cls(cls.SUCCEEDED, command)

    @classmethod
    def failed(cls, command: str, exception: BaseException | None) -> "BuildResult":
        return cls(cls.FAILED, command, exception=exception)

    @classmethod
    def skipped(cls, command: str, user_visible_message: str | None = None) -> "BuildResult":
        return cls(cls.SKIPPED, command, user_visible_message=user_visible_message)
