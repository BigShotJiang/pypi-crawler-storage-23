from typing import TYPE_CHECKING, Any

from codespeak_shared.build_insight.events import ProgressItemCreateEvent, ProgressItemStatus

if TYPE_CHECKING:
    from codespeak_shared.progress.progress_reporter import ProgressReporter


class Step:
    """
    Higher-level wrapper around ProgressItem that carries a bit of extra
    context/state and some utilities (like context management) to make progress
    reporting easier for phases/clients (compared to using raw Events)
    """

    def __init__(
        self,
        text: str,
        reporter: "ProgressReporter",
        progress_item: ProgressItemCreateEvent,
        collapse: bool = True,
    ):
        self.text = text
        self.reporter = reporter
        self.status_text = ""
        self.final_status_text = ""
        self.tokens = 0
        self.collapse = collapse
        self.start_time = None
        self.progress_item = progress_item
        self.override_final_status: ProgressItemStatus | None = None
        self.was_ended = False  # Mostly for debugging
        self.was_started = False  # Mostly for debugging

    def __enter__(self) -> "Step":
        self.reporter.start_step(self)
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: Any) -> bool | None:
        self.reporter.end_step(
            self,
            exc_type,
            exc_val,
            exc_tb,
            final_status_text=self.final_status_text,
            final_status=self.override_final_status,
        )
        return False

    def set_final_status_text(self, status: str):
        """Set the final status text that will appear in the completion message"""
        self.final_status_text = status  # Will be sent with the step end event

    def append(self, text: str, color: str = ""):
        """Add a line to the progress display"""
        self.reporter.append(text, color, parent_progress_item_id=self.progress_item.progress_item_id)

    def spinner(self, text: str):
        """Show a spinner with text"""
        self.reporter.update_step_status_text(self, text)

    def set_final_status(self, status: ProgressItemStatus):
        """Set the final status of the step"""
        self.override_final_status = status


class NoOpStep(Step):
    """A no-op step that does nothing for all method calls"""

    def __init__(self):
        pass

    def __getattr__(self, name: str) -> Any:
        # All dunder methods are non-existent on NoOpStep
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        # Return a no-op function for any attribute access
        def result(*args: Any, **kwargs: Any):
            return None

        return result

    def __enter__(self) -> "NoOpStep":
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: Any) -> bool:
        return False  # Don't suppress exceptions

    def set_final_status_text(self, status: str):
        pass

    def append(self, text: str, color: str = ""):
        pass

    def spinner(self, text: str):
        pass

    def set_final_status(self, status: ProgressItemStatus):
        pass
