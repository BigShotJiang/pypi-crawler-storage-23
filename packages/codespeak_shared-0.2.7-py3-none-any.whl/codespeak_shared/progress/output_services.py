from pydantic import BaseModel, ConfigDict
from rich.console import Console

from codespeak_shared.build_insight.storage import BuildInsightStorage
from codespeak_shared.progress.progress_reporter import ProgressReporter


class OutputServices(BaseModel):
    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    console: Console
    build_insight: BuildInsightStorage
    progress_reporter: ProgressReporter
