import time
from typing import Any

from codespeak_shared.build_insight.events import (
    ProgressItemCreateEvent,
    ProgressItemStatus,
    TextOutputEvent,
    ToolCallEvent,
    UserVisibleModelOutputEvent,
)
from codespeak_shared.build_insight.storage import BuildInsightStorage
from codespeak_shared.exceptions import SkipBuildException
from codespeak_shared.progress.step import NoOpStep, Step


class ProgressReporter:
    """Factory/coordinator for progress reporting using Steps"""

    def __init__(self, build_insight: BuildInsightStorage):
        self._build_insight = build_insight
        self.active_steps_stack: list[Step] = []
        self.start_time = None

    @property
    def active_step(self) -> Step | None:
        return self.active_steps_stack[-1] if self.active_steps_stack else None

    @property
    def active_step_progress_id(self) -> str | None:
        return self.active_step.progress_item.progress_item_id if self.active_step else None

    def with_no_op_step(self) -> NoOpStep:
        """Create a NoOpStep object that can be used as a context manager"""
        return NoOpStep()

    def create_step(self, text: str, collapse: bool = True, parent_step: Step | None = None, **extra: Any) -> Step:
        """Create a Step object that can be used as a context manager"""

        parent_item_id = parent_step.progress_item.progress_item_id if parent_step else None
        progress_item = self._build_insight.report_event(
            ProgressItemCreateEvent(title=text, parent_item_id=parent_item_id, extra=extra)
        )
        return Step(text, self, progress_item, collapse)

    def start_step(self, step: Step, allow_restart: bool = False):
        if step.was_started:
            if not allow_restart:
                raise ValueError(f"Step {step} was already started")

            # Best-effort recovery from step restarts
            self._build_insight.report_event(step.progress_item.create_updating_event(ProgressItemStatus.IN_PROGRESS))
            self.start_time = time.time()
            if step not in self.active_steps_stack:
                self.active_steps_stack.append(step)
            step.was_ended = False
        else:
            step.was_started = True
            self._build_insight.report_event(step.progress_item.create_updating_event(ProgressItemStatus.IN_PROGRESS))
            self.start_time = time.time()
            self.active_steps_stack.append(step)

    def end_step(
        self,
        step: Step,
        exc_type: type[BaseException] | None = None,
        exc_val: BaseException | None = None,
        exc_tb: Any = None,
        final_status_text: str | None = None,
        final_status: ProgressItemStatus | None = None,
    ):
        if step.was_ended:
            raise ValueError(f"Step {step} was already closed")
        step.was_ended = True
        if final_status is None:
            if exc_type is None:
                final_status = ProgressItemStatus.DONE
            elif isinstance(exc_val, SkipBuildException):
                final_status = ProgressItemStatus.SKIPPED
            else:
                final_status = ProgressItemStatus.FAILED
        self._build_insight.report_event(step.progress_item.create_updating_event(final_status, final_status_text))

        if step.was_started:
            # Sometimes step can be marked as done before it was started. E.g., Claude Code
            # planned a todo-item, and then during implementation of previous items realized
            # that it also completed the next one.
            self.active_steps_stack.pop()

    def with_ad_hoc_step(self, text: str, collapse: bool = True, parent_step: Step | None = None, **extra: Any) -> Step:
        step = self.create_step(text, collapse, parent_step=parent_step if parent_step else self.active_step, **extra)
        return step

    def append(
        self,
        text: str,
        color: str = "",
        parent_progress_item_id: str | None = None,
        **extra: Any,
    ):
        """Add a line to the progress display outside of steps"""
        self._build_insight.report_event(
            TextOutputEvent(text=text, parent_progress_item_id=parent_progress_item_id, extra=extra)
        )

    def append_to_the_current_step(self, text: str, color: str = "", **extra: Any):
        """Add a line to the progress display outside of steps"""
        assert self.active_step
        self.append(text, color, parent_progress_item_id=self.active_step.progress_item.progress_item_id, **extra)

    def report_model_output(self, text: str, parent_progress_item_id: str | None = None, **extra: Any):
        """Report a model output event"""
        if not parent_progress_item_id and self.active_step:
            parent_progress_item_id = self.active_step.progress_item.progress_item_id
        self._build_insight.report_event(
            UserVisibleModelOutputEvent(text=text, parent_progress_item_id=parent_progress_item_id, extra=extra)
        )

    def update_step_status_text(self, step: Step, status_text: str):
        """Update the status text of a step"""
        self._build_insight.report_event(step.progress_item.create_updating_event(new_status_text=status_text))

    def report_tool_call(
        self,
        title_for_build_insight: str,
        details: str | None = None,
        parent_progress_item_id: str | None = None,
        **extra: Any,
    ):
        if not parent_progress_item_id and self.active_step:
            parent_progress_item_id = self.active_step.progress_item.progress_item_id
        self._build_insight.report_event(
            ToolCallEvent(
                title=title_for_build_insight,
                details=details,
                parent_progress_item_id=parent_progress_item_id,
                extra=extra,
            )
        )
