import sys
import termios
import time
from traceback import FrameSummary
from typing import Any

from rich.console import Console, Group, RenderableType
from rich.constrain import Constrain
from rich.live import Live
from rich.padding import Padding
from rich.panel import Panel
from rich.text import Text
from rich.traceback import Frame as RichFrame
from rich.traceback import Stack as RichStack
from rich.traceback import Trace as RichTrace
from rich.traceback import Traceback as RichTraceback
from rich.tree import Tree

from codespeak_shared.build_insight.events import (
    ProgressItemCreateEvent,
    ProgressItemStatus,
    ProgressItemUpdateEvent,
    StopInteractiveProgressEvent,
    TextOutputEvent,
    ToolCallEvent,
    UserVisibleModelOutputEvent,
)
from codespeak_shared.build_insight.storage import BuildInsightStorage
from codespeak_shared.utils.colors import Colors
from codespeak_shared.utils.type_utils import nn


class ProgressItem:
    """Internal model for tracking progress items from events"""

    def __init__(self, event: ProgressItemCreateEvent):
        self.id = event.progress_item_id
        self.title = event.title
        self.description = event.description
        self.parent_id = event.parent_item_id
        self.status = event.status
        self.status_text = event.status_text  # Store status text from events
        self.created_at: float = event.timestamp
        self.started_at: float | None = None
        self.updated_at: float | None = None
        self.children: list[ProgressItem] = []
        self.text_outputs: list[str] = []  # Store text output lines
        self.subcontent_prefix: str = "   "  # Three spaces for subcontent (matches ╰─ spacing)
        self.truncate_child_output: bool = event.extra.get("truncate_child_output", False)
        self.last_model_output: str | None = None  # Store only most recent model output

    def update_status(self, event: ProgressItemUpdateEvent):
        """Update the status from an update event"""
        self.status = event.status
        if event.status_text is not None:
            self.status_text = event.status_text

        if event.status == ProgressItemStatus.IN_PROGRESS:
            self.started_at = event.timestamp

        self.updated_at = event.timestamp

    @property
    def elapsed(self) -> float:
        """Calculate elapsed time - real-time for in-progress items, fixed for completed items"""
        # Defensive fallbacks in case events come in surprising orders
        if self.status == ProgressItemStatus.IN_PROGRESS:
            # For in-progress items, show real-time elapsed time
            return time.time() - nn(self.started_at)  # Must exist for IN_PROGRESS items, see `update_status`
        elif self.status == ProgressItemStatus.PENDING:
            return 0.0
        else:  # DONE, FAILED, SKIPPED
            if not self.started_at:
                return 0.0  # If the item was never started, then elapsed tiem is 0
            return (
                nn(self.updated_at) - self.started_at
            )  # updated_at must exist for completed items, see `update_status`

    @property
    def is_active(self) -> bool:
        """Check if this item is currently active"""
        return self.status == ProgressItemStatus.IN_PROGRESS

    @property
    def is_completed(self) -> bool:
        """Check if this item is completed"""
        return self.status in [ProgressItemStatus.DONE, ProgressItemStatus.FAILED, ProgressItemStatus.SKIPPED]

    def get_subcontent_prefix(self) -> str:
        """Get this item's contribution to its children's tree prefix.

        Returns "   " (3 spaces) for all items with parents,
        or "" if this is a root item (no parent).
        """
        if not self.parent_id:
            # Root items don't contribute to their children's prefix
            return ""

        return self.subcontent_prefix

    def append_child(self, child: "ProgressItem"):
        """Add a child to this item.

        With rounded corner connectors (╰─), all children have the same spacing,
        so no prefix updates are needed.
        """
        self.children.append(child)


class RichBasedCliProgressRenderer:
    """Event-driven Rich progress output that subscribes to BuildInsightStorage events

    This implementation completely ignores the ProgressOutput interface calls and instead
    builds the display purely from BuildInsightStorage events. This provides a cleaner
    separation of concerns and more accurate progress tracking.

    Benefits of Event-Driven Approach:
    - Single source of truth: BuildInsightStorage events
    - Automatic synchronization with build insight data
    - No duplicate state management between ProgressOutput and BuildInsightStorage
    - More accurate timing and progress tracking
    - Can reconstruct display from historical events
    - Cleaner architecture with clear separation of concerns

    Features:
    - Event-driven architecture using BuildInsightStorage
    - Real-time hierarchical progress display
    - Automatic live updates when events are fired
    - No state management through ProgressOutput interface
    - Perfect synchronization with build insight system

    Usage:
        storage = BuildInsightStorage()
        output = RichBasedCliProgressRenderer(storage)

        # The output will automatically update as events are reported to storage
        # Traditional ProgressReporter still works, but display is driven by events
        reporter = ProgressReporter(storage)
    """

    _LOGO_LINES = [
        " ██████╗ ██████╗ ██████╗ ███████╗███████╗██████╗ ███████╗ █████╗ ██╗  ██╗",
        "██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝██╔══██╗██╔════╝██╔══██╗██║ ██╔╝",
        "██║     ██║   ██║██║  ██║█████╗  ███████╗██████╔╝█████╗  ███████║█████╔╝",
        "██║     ██║   ██║██║  ██║██╔══╝  ╚════██║██╔═══╝ ██╔══╝  ██╔══██║██╔═██╗",
        "╚██████╗╚██████╔╝██████╔╝███████╗███████║██║     ███████╗██║  ██║██║  ██╗",
        " ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝",
    ]

    _ALPHA_PREVIEW_SUBTITLE = "[white]🚧 [/white][orange1]Alpha Preview[/orange1][white] 🚧[/white]"

    def __init__(self, console: Console, build_insight: BuildInsightStorage, interactive: bool = True):
        # Create a custom theme for progress display inspired by MONOKAI

        self.console = console
        self.build_insight = build_insight
        self.interactive = interactive
        self.live: Live | None = None

        # Capture the initial display width
        # This will be necessary to know the correct (approximation) of the console width when we'll return
        # the content back to the original buffer after the live display is stopped. We can't just query
        # _current_display_width for the final frame, because moving between buffers might slightly change the width
        # on some terminals, and, moreover, that change is a bit racy (so _current_display_width right after live.stop()
        # might not show the correct width)
        self._initial_display_width = self._current_display_width

        # Internal state built from events
        self.items: dict[str, ProgressItem] = {}
        self.root_items: list[ProgressItem] = []
        self.global_text_outputs: list[str] = []  # Text outputs without parent, rendered after all progress

        # Subscribe to events
        self.build_insight.register_event_listener(self._handle_progress_create, ProgressItemCreateEvent)
        self.build_insight.register_event_listener(self._handle_progress_update, ProgressItemUpdateEvent)
        self.build_insight.register_event_listener(self._handle_text_output, TextOutputEvent)
        self.build_insight.register_event_listener(self._handle_tool_call, ToolCallEvent)
        self.build_insight.register_event_listener(self._handle_model_output, UserVisibleModelOutputEvent)
        self.build_insight.register_event_listener(self._handle_stop_interactive_progress, StopInteractiveProgressEvent)

        # Track if we've started the live display
        self._live_started = False
        self._saved_termios: list[Any] | None = None
        # Track what we've already printed in non-interactive mode
        self._printed_items: set[str] = set()  # Track which items we've printed
        self._printed_item_statuses: dict[str, ProgressItemStatus] = {}  # Track last printed status per item
        self._item_depth_cache: dict[str, int] = {}  # Cache depth calculations for tree structure

    @property
    def _current_display_width(self) -> int:
        return int(self.console.width * 0.95)

    # Event handlers
    def _handle_progress_create(self, event: ProgressItemCreateEvent):
        """Handle creation of a new progress item"""
        item = ProgressItem(event)
        self.items[item.id] = item

        # Link to parent or add to root
        if item.parent_id and item.parent_id in self.items:
            parent = self.items[item.parent_id]
            parent.append_child(item)
        else:
            self.root_items.append(item)

        # Handle display based on mode
        if not self.interactive:
            # In non-interactive mode, track the item but only print non-pending items
            self._print_item_status_line(item)  # This will skip PENDING items internally
            self._printed_items.add(item.id)
            self._printed_item_statuses[item.id] = item.status
        else:
            # Start live display on first item
            if not self._live_started:
                self._start_live_display()
                self._live_started = True
            else:
                self._update_display()

    def _handle_progress_update(self, event: ProgressItemUpdateEvent):
        """Handle update to an existing progress item"""
        if event.progress_item_id in self.items:
            item = self.items[event.progress_item_id]
            old_status = item.status
            item.update_status(event)

            if not self.interactive:
                # In non-interactive mode, only print if status changed
                if old_status != event.status:
                    self._print_item_status_line(item)
                    self._printed_item_statuses[item.id] = item.status
            else:
                self._update_display()

    def _handle_tool_call(self, event: ToolCallEvent):
        # Tool calls are handled the same way for both truncated and non-truncated items
        # They accumulate in text_outputs, and get cleared when a new model output arrives for truncated items
        self._append_text_output(f"  {event.title}", event.parent_progress_item_id)

    def _handle_model_output(self, event: UserVisibleModelOutputEvent):
        formatted_output = "\n▸ " + event.text.strip()

        # For truncated items, store only the last model output and clear previous tool calls
        if event.parent_progress_item_id and event.parent_progress_item_id in self.items:
            item = self.items[event.parent_progress_item_id]
            if item.truncate_child_output:
                item.last_model_output = formatted_output
                # Clear previous tool calls since we're starting a new "thought" phase
                item.text_outputs.clear()

                # Print in non-interactive mode, but don't add to text_outputs list
                should_print_directly = not self.interactive or (self._live_started and self.live is None)
                if should_print_directly:
                    self._print_text_directly(formatted_output, event.parent_progress_item_id)
                elif self.live:
                    self._update_display()
                return

        # For non-truncated items, use existing behavior
        self._append_text_output(formatted_output, event.parent_progress_item_id)

    def _handle_stop_interactive_progress(self, _event: StopInteractiveProgressEvent):
        self.stop_interactive_progress()

    def _handle_text_output(self, event: TextOutputEvent):
        self._append_text_output(event.text, event.parent_progress_item_id)

    def _append_text_output(self, text: str, parent_progress_item_id: str | None = None):
        should_print_directly = not self.interactive or (self._live_started and self.live is None)

        if parent_progress_item_id and parent_progress_item_id in self.items:
            item = self.items[parent_progress_item_id]
            item.text_outputs.append(text)

            if should_print_directly:
                self._print_text_directly(text, parent_progress_item_id)
        else:
            self.global_text_outputs.append(text)

            if should_print_directly:
                self._print_text_directly(text, None)

        if self.interactive and self.live:
            self._update_display()

    def _print_text_directly(self, text: str, parent_progress_item_id: str | None):
        """Print text output directly to console (for non-interactive mode)."""
        if parent_progress_item_id and parent_progress_item_id in self.items:
            item = self.items[parent_progress_item_id]
            depth = self._get_item_depth(item)
            indent_spaces = 2 * (depth + 1)
            rich_text = Text(text, style="progress.timing")
            padded = Padding(rich_text, (0, 0, 0, indent_spaces))
            self.console.print(padded)
        else:
            self.console.print(Text(text, style="progress.timing"))

    def _get_live_renderable(self) -> RenderableType:
        """Get the renderable for Rich's Live component with optimized refresh behavior"""
        return self._build_display()

    def _has_in_progress_items(self) -> bool:
        """Check if there are any in-progress items that need real-time updates"""
        return any(item.is_active for item in self.items.values())

    # Display management
    def _start_live_display(self):
        """Start the Rich live display in alternate screen buffer"""
        if not self.interactive:
            # In non-interactive mode, we don't need to do anything special on start
            # Individual items will be printed as they're created/updated
            return

        if not self.live:
            self.live = Live(
                console=self.console,
                refresh_per_second=10,  # Refresh once per second for smooth time updates
                auto_refresh=True,  # Enable automatic refresh
                transient=False,
                vertical_overflow="crop",  # Crop vertical overflow to avoid artifacts when moving content back
                screen=True,  # Use alternate screen buffer
                get_renderable=self._get_live_renderable,  # Use callable to get fresh content on each refresh
            )
            self.live.start()
            self._disable_stdin_echo()

    def _disable_stdin_echo(self) -> None:
        """Disable stdin echo to prevent key presses from appearing as escape sequences during Live display."""
        if not sys.stdin.isatty():
            return
        try:
            attrs = termios.tcgetattr(sys.stdin)
            self._saved_termios = attrs
            modified = termios.tcgetattr(sys.stdin)
            modified[3] = modified[3] & ~termios.ECHO
            termios.tcsetattr(sys.stdin, termios.TCSANOW, modified)
        except termios.error:
            self._saved_termios = None

    def _restore_stdin_echo(self) -> None:
        """Restore original terminal attributes saved by _disable_stdin_echo."""
        if self._saved_termios is not None:
            try:
                # Discard any input that accumulated while echo was off,
                # otherwise it would be consumed by the shell after we return.
                termios.tcflush(sys.stdin, termios.TCIFLUSH)
                termios.tcsetattr(sys.stdin, termios.TCSANOW, self._saved_termios)
            except termios.error:
                pass
            self._saved_termios = None

    def _update_display(self):
        """Update the live display with current progress"""
        if not self.interactive:
            # In non-interactive mode, we handle printing in the individual event handlers
            # This method is a no-op for non-interactive mode
            return

        if self.live:
            self.live.update(self._build_display())

    def _stop_live_display(self):
        """Stop the live display and print final state to main terminal buffer"""
        if not self.interactive:
            # In non-interactive mode, we don't need to print anything special
            # Items have already been printed as they completed
            return

        if self.live:
            self._restore_stdin_echo()
            # Stop the live display (exits alternate screen buffer)
            self.live.stop()
            self.live = None

            # Leave the final frame in the original buffer. Use the initial display width as an additional constraint, because sometimes
            # temporary buffer might be larger than the initial buffer (and there will be weird cropping when we'll try to fit content
            # rendered for larger width into it).
            # Just calling _current_display_width here is not OK, because terminal might not've updated its width yet after live.stop()
            final_display = self._build_display(additional_width_contraint=self._initial_display_width, crop=False)
            self.console.print(final_display)

    _LOGO_OVERHEAD_LINES = 8  # logo top-padding (1) + logo (6) + blank line (1)
    _PANEL_OVERHEAD_LINES = 4  # panel borders (2) + safety margin (2)
    _MIN_TEXT_OUTPUT_LINES = 5  # reserve at least this many lines for text output to avoid flickering

    @staticmethod
    def _count_content_lines(content_items: list[str]) -> int:
        return sum(s.count("\n") + 1 for s in content_items)

    def _count_text_output_lines(self) -> int:
        """Count text output lines across all non-completed items (model output + tool calls)."""
        total = 0
        for item in self.items.values():
            if item.is_completed:
                continue
            if item.truncate_child_output and item.last_model_output:
                total += sum(1 for line in item.last_model_output.split("\n") if line)
            for text_output in item.text_outputs:
                total += text_output.count("\n") + 1
        return total

    def _effective_content_lines(self, content_items: list[str]) -> int:
        """Content line count with a minimum reservation for text output.

        Model output can vary in size rapidly, so we pretend it's at least
        _MIN_TEXT_OUTPUT_LINES to keep cascade decisions stable and avoid flickering.
        """
        actual = self._count_content_lines(content_items)
        output_lines = self._count_text_output_lines()
        return actual + max(0, self._MIN_TEXT_OUTPUT_LINES - output_lines)

    def _build_display(self, additional_width_contraint: int | None = None, crop: bool = True) -> RenderableType:
        """Build the Rich display tree from current progress items"""
        if not self.root_items:
            panel = Panel(
                "[progress.panel.title]No active progress[/progress.panel.title]",
                title="[progress.panel.title]CodeSpeak Progress[/progress.panel.title]",
                subtitle=RichBasedCliProgressRenderer._ALPHA_PREVIEW_SUBTITLE,
                border_style="progress.panel.border",
            )
            include_logo = True
        else:
            if crop:
                global_lines = (
                    sum(s.count("\n") + 1 for s in self.global_text_outputs) if self.global_text_outputs else 0
                )
                total_overhead = self._PANEL_OVERHEAD_LINES + global_lines
                available_with_logo = self.console.height - total_overhead - self._LOGO_OVERHEAD_LINES
                available_without_logo = self.console.height - total_overhead
                content_items, include_logo = self._cascade_fit_content(available_with_logo, available_without_logo)
            else:
                content_items = self._render_all_roots()
                include_logo = True

            # Combine all content
            if content_items:
                content = Group(*content_items)
            else:
                content = "[progress.panel.title]No active progress[/progress.panel.title]"

            panel = Panel(
                content,
                title="[progress.panel.title]CodeSpeak Progress[/progress.panel.title]",
                subtitle=RichBasedCliProgressRenderer._ALPHA_PREVIEW_SUBTITLE,
                border_style="progress.panel.border",
            )

        # Build the final display with global text outputs outside the panel
        display_items: list[RenderableType] = []
        if include_logo:
            logo_string = "\n".join(self._LOGO_LINES)
            logo_text = Text(logo_string, style="dim", no_wrap=True, overflow="ignore")
            padded_logo = Padding(logo_text, (1, 0, 0, 2))  # (top, right, bottom, left)
            display_items.extend([padded_logo, Text("")])
        display_items.append(panel)

        # Add global text outputs after the panel
        if self.global_text_outputs:
            display_items.extend(self.global_text_outputs)

        constraint_width = (
            self._current_display_width
            if additional_width_contraint is None
            else min(self._current_display_width, additional_width_contraint)
        )
        return Constrain(Group(*display_items), width=constraint_width)

    def _render_all_roots(self, skip_root_statuses: set[ProgressItemStatus] | None = None) -> list[str]:
        content_items: list[str] = []
        skipped_counts: dict[ProgressItemStatus, int] = {}
        for i, root_item in enumerate(self.root_items):
            if skip_root_statuses and root_item.status in skip_root_statuses:
                skipped_counts[root_item.status] = skipped_counts.get(root_item.status, 0) + 1
                continue
            is_last_root = i == len(self.root_items) - 1
            content_items.append(self._render_item_as_text(root_item, 0, is_last_root, ""))
        if skipped_counts:
            parts: list[str] = []
            for status, label in [
                (ProgressItemStatus.DONE, "completed"),
                (ProgressItemStatus.FAILED, "failed"),
                (ProgressItemStatus.SKIPPED, "skipped"),
                (ProgressItemStatus.PENDING, "pending"),
            ]:
                if status in skipped_counts:
                    parts.append(f"{skipped_counts[status]} {label}")
            content_items.append(f"[dim]{', '.join(parts)} (hidden)[/dim]")
        return content_items

    def _cascade_fit_content(self, available_with_logo: int, available_without_logo: int) -> tuple[list[str], bool]:
        """Try progressively more aggressive filtering to fit content within terminal height.

        Returns (content_items, include_logo).
        """
        # Step 1: Full render, with logo
        content_items = self._render_all_roots()
        if available_with_logo > 0 and self._effective_content_lines(content_items) <= available_with_logo:
            return content_items, True

        # Step 2: Full render, without logo
        if available_without_logo > 0 and self._effective_content_lines(content_items) <= available_without_logo:
            return content_items, False

        # Step 3: Skip completed/failed/skipped root items, without logo
        skip_terminal = {ProgressItemStatus.DONE, ProgressItemStatus.FAILED, ProgressItemStatus.SKIPPED}
        content_items = self._render_all_roots(skip_root_statuses=skip_terminal)
        if available_without_logo > 0 and self._effective_content_lines(content_items) <= available_without_logo:
            return content_items, False

        # Step 4: Also skip pending root items, without logo
        skip_all_inactive = skip_terminal | {ProgressItemStatus.PENDING}
        content_items = self._render_all_roots(skip_root_statuses=skip_all_inactive)
        if available_without_logo > 0 and self._effective_content_lines(content_items) <= available_without_logo:
            return content_items, False

        # Step 5: Last resort — crop arbitrary top lines from active content
        if available_without_logo > 0:
            content_items = self._crop_content_from_top(content_items, available_without_logo)
        return content_items, False

    @staticmethod
    def _crop_content_from_top(content_items: list[str], max_lines: int) -> list[str]:
        """Crop content from the top to fit within max_lines.

        When content exceeds available height, removes lines from the top
        so the most recent activity (at the bottom) remains visible.
        """
        all_lines: list[str] = []
        for item in content_items:
            all_lines.extend(item.split("\n"))

        if len(all_lines) <= max_lines:
            return content_items

        # Reserve one line for the "cropped" indicator
        cropped_lines = all_lines[-(max_lines - 1) :]
        cropped_lines.insert(0, "[dim]⋮ (earlier items hidden)[/dim]")

        return ["\n".join(cropped_lines)]

    def _add_item_to_tree(self, parent_tree: Tree, item: ProgressItem):
        """Recursively add a progress item and its children to the tree"""
        # Apply semantic colors based on status
        if item.status == ProgressItemStatus.PENDING:
            item_title = f"[progress.pending]○ {item.title}[/progress.pending]"
        elif item.status == ProgressItemStatus.IN_PROGRESS:
            # Active items: entirely colored (rare, need attention)
            item_title = f"[progress.active]● {item.title}[/progress.active]"
        elif item.status == ProgressItemStatus.DONE:
            # Done items: only icon green, text in normal color (less distracting)
            item_title = f"[progress.success.icon]✓[/progress.success.icon] [progress.success.text]{item.title}[/progress.success.text]"
        elif item.status == ProgressItemStatus.FAILED:
            # Failed items: entirely colored (rare, need attention)
            item_title = f"[error]✗ {item.title}[/error]"
        else:
            item_title = f"[progress.unknown]? {item.title}[/progress.unknown]"

        # Add timing only for in-progress and completed items (not pending)
        if item.status == ProgressItemStatus.IN_PROGRESS or item.is_completed:
            elapsed_text = f"({self._format_time(item.elapsed)})"
            item_title += f" [progress.timing]{elapsed_text}[/progress.timing]"

        # Add item to tree
        item_branch = parent_tree.add(item_title)

        # Add children first
        for child in item.children:
            self._add_item_to_tree(item_branch, child)

        # Add text outputs after children if not completed (folding behavior)
        if not item.is_completed and item.text_outputs:
            # Add text outputs as separate tree items under this item
            for text_output in item.text_outputs:
                item_branch.add(f"[progress.timing]{text_output}[/progress.timing]")

    def _render_item_as_text(
        self, item: ProgressItem, indent_level: int = 0, is_last: bool = True, parent_prefix: str = ""
    ) -> str:
        """Render a progress item with tree-style connectors"""
        # Create tree connector prefix
        if indent_level == 0:
            connector = ""
            current_prefix = ""
        else:
            # Use rounded corner for all sub-items (parent-to-child visual)
            connector = "╰─ "
            current_prefix = parent_prefix + "   "

        item_line = self._format_item_line_interactive(item, connector, parent_prefix)

        lines = [item_line]

        # Add children first
        for i, child in enumerate(item.children):
            is_last_child = i == len(item.children) - 1
            child_content = self._render_item_as_text(child, indent_level + 1, is_last_child, current_prefix)
            lines.append(child_content)

        # Add outputs after children if not completed
        if not item.is_completed:
            if item.truncate_child_output and item.last_model_output:
                # For truncated items, show the last model output and all accumulated tool calls
                # Handle multi-line model output by applying prefix to each line
                output_lines = item.last_model_output.split("\n")
                for output_line in output_lines:
                    if output_line:  # Skip empty lines
                        lines.append(
                            f"[progress.tree]{current_prefix}[/progress.tree][progress.timing]{output_line}[/progress.timing]"
                        )
                # Show all tool calls for this thought phase
                for text_output in item.text_outputs:
                    lines.append(
                        f"[progress.tree]{current_prefix}[/progress.tree][progress.timing]{text_output}[/progress.timing]"
                    )
            elif item.text_outputs:
                # For non-truncated items, show all text outputs
                for text_output in item.text_outputs:
                    lines.append(
                        f"[progress.tree]{current_prefix}[/progress.tree][progress.timing]{text_output}[/progress.timing]"
                    )

        return "\n".join(lines)

    def _get_item_depth(self, item: ProgressItem) -> int:
        """Calculate the depth of an item in the tree hierarchy"""
        if item.id in self._item_depth_cache:
            return self._item_depth_cache[item.id]

        if not item.parent_id or item.parent_id not in self.items:
            depth = 0
        else:
            parent = self.items[item.parent_id]
            depth = self._get_item_depth(parent) + 1

        self._item_depth_cache[item.id] = depth
        return depth

    def _compute_tree_prefix(self, item: ProgressItem) -> tuple[str, str]:
        """Compute tree prefix for an item, returning (connector, parent_prefix).

        This method computes the proper tree structure connectors (├──, └──, │)
        by walking up the parent chain and using each ancestor's cached prefix contribution.

        The logic works as follows:
        - For root items: no connector, no prefix
        - For non-root items:
          - connector: "└── " if this is the last child of parent, "├── " otherwise
          - parent_prefix: built by recursively walking up the tree and concatenating
            each ancestor's contribution (cached in the ProgressItem)

        Returns:
            connector: The connector string for this item (e.g., "├── " or "└── ")
            parent_prefix: The prefix string from all ancestors (e.g., "│   │   ")
        """
        if not item.parent_id or item.parent_id not in self.items:
            # Root level item
            return "", ""

        # Build the prefix by walking up the parent chain
        parent = self.items[item.parent_id]

        # Get parent's prefix recursively
        _, parent_parent_prefix = self._compute_tree_prefix(parent)

        # Use rounded corner for all sub-items (parent-to-child visual)
        connector = "╰─ "

        # Build our parent_prefix using parent's cached contribution
        parent_prefix = parent_parent_prefix + parent.get_subcontent_prefix()

        return connector, parent_prefix

    def _format_item_line_non_interactive(
        self, item: ProgressItem, connector: str = "", parent_prefix: str = ""
    ) -> str | None:
        spacing_for_root_items = "\n" if item.parent_id is None else ""
        if item.status == ProgressItemStatus.PENDING:
            return None  # Skip printing PENDING items to reduce clutter

        if item.status == ProgressItemStatus.IN_PROGRESS:
            # Full prefix with connectors for in-progress items
            prefix = f"[progress.tree]{parent_prefix}{connector}[/progress.tree][progress.active]"
        else:
            # No conectors, just indent for other items
            prefix = f"[progress.tree]{parent_prefix}{' ' * len(connector)}[/progress.tree]"

        if item.status == ProgressItemStatus.IN_PROGRESS:
            item_line = f"{spacing_for_root_items}{prefix}[progress.active]● {item.title}[/progress.active]"
        elif item.status == ProgressItemStatus.DONE:
            item_line = f"{prefix}[progress.success.icon]✓[/progress.success.icon] [progress.success.text]Completed in: {self._format_time(item.elapsed)}[/progress.success.text]"
        elif item.status == ProgressItemStatus.FAILED:
            item_line = f"{prefix}[error]✗ Failed in: {self._format_time(item.elapsed)}[/error]"
        elif item.status == ProgressItemStatus.SKIPPED:
            item_line = f"{prefix}[progress.skipped]⊘ Skipped[/progress.skipped]"
        else:
            item_line = f"{prefix}[progress.unknown]? Unknown status[/progress.unknown]"

        # Add status text if present
        if item.status_text:
            item_line += f" [progress.status]- {item.status_text}[/progress.status]"

        return item_line

    def _format_item_line_interactive(self, item: ProgressItem, connector: str = "", parent_prefix: str = "") -> str:
        # Build item line with colors and tree connector
        if item.status == ProgressItemStatus.PENDING:
            item_line = f"[progress.tree]{parent_prefix}{connector}[/progress.tree][progress.pending]○ {item.title}[/progress.pending]"
        elif item.status == ProgressItemStatus.IN_PROGRESS:
            item_line = f"[progress.tree]{parent_prefix}{connector}[/progress.tree][progress.active]● {item.title}[/progress.active]"
        elif item.status == ProgressItemStatus.DONE:
            item_line = f"[progress.tree]{parent_prefix}{connector}[/progress.tree][progress.success.icon]✓[/progress.success.icon] [progress.success.text]{item.title}[/progress.success.text]"
        elif item.status == ProgressItemStatus.FAILED:
            item_line = f"[progress.tree]{parent_prefix}{connector}[/progress.tree][error]✗ {item.title}[/error]"
        elif item.status == ProgressItemStatus.SKIPPED:
            item_line = f"[progress.tree]{parent_prefix}{connector}[/progress.tree][progress.skipped]⊘ {item.title}[/progress.skipped]"
        else:
            item_line = f"[progress.tree]{parent_prefix}{connector}[/progress.tree][progress.unknown]? {item.title}[/progress.unknown]"

        # Add timing only for in-progress and completed items (not pending)
        if item.status == ProgressItemStatus.IN_PROGRESS or item.is_completed:
            elapsed_text = f"({self._format_time(item.elapsed)})"
            item_line += f" [progress.timing]{elapsed_text}[/progress.timing]"

        # Add status text if present
        if item.status_text:
            item_line += f" [progress.status]- {item.status_text}[/progress.status]"

        return item_line

    def _print_item_status_line(self, item: ProgressItem):
        """Print a single line for an item's current status (for non-interactive mode)"""
        if self.interactive:
            return  # Only for non-interactive mode

        # Compute tree prefix using the same logic as interactive mode
        connector, parent_prefix = self._compute_tree_prefix(item)

        item_line = self._format_item_line_non_interactive(item, connector, parent_prefix)
        if not item_line:
            return

        self.console.print(item_line)

    def stop_interactive_progress(self):
        """Stop the interactive progress display.

        Called when transitioning from build progress to running the target app,
        so that the app's output can be displayed directly to the console.
        """
        self._stop_live_display()

    def finalize(self):
        self._stop_live_display()

    def append_text(self, text: str):
        """Append text output to the display.

        The text will appear after all progress items.
        This is a convenience method for clients to add text without
        needing to call internal methods or create TextOutputEvent instances.
        """
        self._append_text_output(text, parent_progress_item_id=None)

    def _format_time(self, seconds: float) -> str:
        """Format elapsed time in a human-readable way"""
        if seconds < 60:
            return f"{seconds:.1f}s"
        elif seconds < 3600:
            return f"{seconds // 60:.0f}m {seconds % 60:.0f}s"
        else:
            return f"{seconds // 3600:.0f}h {seconds % 3600 // 60:.0f}m {seconds % 60:.0f}s"


def rich_traceback_from_stack_frames(
    stack_frames: list[FrameSummary],
    *,
    show_locals: bool = False,
    width: int | None = None,
    code_width: int | None = None,
    extra_lines: int = 3,
) -> RichTraceback:
    """Convert a list of traceback.FrameSummary to a RichTraceback.

    Parameters allow customizing the resulting Rich traceback rendering.
    """
    rich_frames: list[RichFrame] = []
    for frame_summary in stack_frames:
        rich_frames.append(
            RichFrame(
                filename=frame_summary.filename,
                lineno=frame_summary.lineno or 0,
                name=frame_summary.name,
                line=frame_summary.line or "",
            )
        )

    stack = RichStack(exc_type="Cancellation request stacktrace", exc_value="", frames=rich_frames)
    trace = RichTrace([stack])
    return RichTraceback(
        trace,
        show_locals=show_locals,
        width=width,
        code_width=code_width,
        extra_lines=extra_lines,
    )


def convert_log_colors_to_rich_colors(text: str) -> str:
    """Convert ANSI color codes from colors.py to Rich theme style references.

    Maps Colors.* ANSI codes to appropriate Rich theme styles defined in _DARK_THEME.
    """
    # Map ANSI color codes to Rich theme style names
    color_mappings = {
        Colors.BRIGHT_BLUE: "progress.panel.border",  # #66d9ef MONOKAI blue
        Colors.BRIGHT_CYAN: "progress.panel.border",  # #66d9ef MONOKAI blue (closest match)
        Colors.BRIGHT_GREEN: "success",  # #a6e22e MONOKAI green
        Colors.BRIGHT_RED: "error",  # #f92672 MONOKAI pink/red
        Colors.BRIGHT_YELLOW: "warning",  # #e6db74 MONOKAI yellow
        Colors.BRIGHT_MAGENTA: "error",  # #f92672 MONOKAI pink/red (closest match)
        Colors.BOLD: "bold",  # Rich bold style
        Colors.DIM: "dim",  # Rich dim style
        Colors.GREY: "info",  # #75715e MONOKAI comment gray
        Colors.LIGHT_GREY: "info",  # #75715e MONOKAI comment gray (closest match)
        Colors.END: "/",  # Rich reset
    }

    result = text

    # Replace ANSI codes with Rich markup
    for ansi_code, rich_style in color_mappings.items():
        if ansi_code in result:
            # Replace opening code with Rich markup
            result = result.replace(ansi_code, f"[{rich_style}]")
    return result
