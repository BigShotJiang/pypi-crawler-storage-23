# Protocol version for client-server communication.
# Increment CURRENT_VERSION on any breaking protocol change.
# Increment MIN_SUPPORTED_VERSION when dropping backward compatibility.

CURRENT_VERSION: int = 1

# Server will reject clients with protocol_version < MIN_SUPPORTED_VERSION
MIN_SUPPORTED_VERSION: int = 1
