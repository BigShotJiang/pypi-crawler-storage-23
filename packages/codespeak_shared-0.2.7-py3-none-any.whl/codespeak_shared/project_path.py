"""ProjectPath - wrapper for relative paths within a CodeSpeak project."""

from __future__ import annotations

import functools
import os.path
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import GetCoreSchemaHandler
from pydantic_core import core_schema

if TYPE_CHECKING:
    from typing_extensions import Self


@functools.total_ordering
class ProjectPath:
    """
    Path in the project. Possibly remote. Can be absolute or relative to project root.
    Typically produced by a Project and consumed by OsEnvironment.
    """

    def __init__(self, path: Path):
        self._path = path

    @classmethod
    def from_path(cls, path: Path) -> Self:
        """Create a ProjectPath from a Path object (must be relative)."""
        return cls(path)

    @classmethod
    def from_string(cls, path_str: str) -> Self:
        return cls(Path(path_str))

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: GetCoreSchemaHandler) -> core_schema.CoreSchema:
        return core_schema.no_info_after_validator_function(
            cls._pydantic_validate,
            core_schema.str_schema(),
            serialization=core_schema.plain_serializer_function_ser_schema(
                lambda x: str(x),
                info_arg=False,
            ),
        )

    @classmethod
    def _pydantic_validate(cls, value: str) -> Self:
        """Validate and convert string to ProjectPath for Pydantic."""
        return cls.from_string(value)

    def __truediv__(self, other: str | Path | ProjectPath) -> ProjectPath:
        """Concatenate paths using the / operator."""
        if isinstance(other, ProjectPath):
            combined = self._path / other._path
        else:
            combined = self._path / other
        return ProjectPath.from_path(combined)

    def __str__(self) -> str:
        return str(self._path)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ProjectPath):
            return NotImplemented
        return self._path == other._path

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, ProjectPath):
            return NotImplemented
        return self._path < other._path

    def __hash__(self) -> int:
        return hash(self._path)

    @property
    def parent(self) -> ProjectPath:
        return ProjectPath.from_path(self._path.parent)

    @property
    def name(self) -> str:
        return self._path.name

    @property
    def suffix(self) -> str:
        return self._path.suffix

    def with_suffix(self, suffix: str) -> ProjectPath:
        return ProjectPath.from_path(self._path.with_suffix(suffix))

    def is_relative_to(self, other: ProjectPath) -> bool:
        return self._path.is_relative_to(other._path)

    def relative_to(self, other: ProjectPath) -> ProjectPath:
        return ProjectPath.from_path(self._path.relative_to(other._path))

    def get_underlying_path(self) -> Path:
        return self._path

    def is_absolute(self) -> bool:
        return self._path.is_absolute()

    def normalized(self) -> ProjectPath:
        """
        Removes "." and ".."
        """
        return ProjectPath.from_string(os.path.normpath(self._path))
