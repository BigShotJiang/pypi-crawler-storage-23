import json
from typing import Any, cast

from codespeak_shared.exceptions import InvalidSettingsError
from codespeak_shared.os_environment import OsEnvironment
from codespeak_shared.project_path import ProjectPath


class ProjectSettings:
    _PROJECT_NAME_ATTR = "project_name"
    _PROFILE_NAME_ATTR = "profile_name"
    _SPECS_ATTR = "specs"
    _WHITELISTED_FILES_ATTR = "whitelisted_files"

    def __init__(self, os_env: OsEnvironment | None) -> None:
        super().__init__()
        self._config_json: dict[str, Any] = {}
        self._os_env = os_env
        raise RuntimeError("Please use factory method")

    @classmethod
    def empty(cls, os_env: OsEnvironment) -> "ProjectSettings":
        self = object.__new__(cls)
        self._config_json = {"version": "0.1.0"}
        self._os_env = os_env
        return self

    @classmethod
    def load(cls, os_env: OsEnvironment, settings_path_relative: ProjectPath) -> "ProjectSettings":
        self = object.__new__(cls)
        config_str = os_env.read_file(settings_path_relative)
        self._config_json = json.loads(config_str)
        self._os_env = os_env
        return self

    @classmethod
    def from_json(cls, json_str: str) -> "ProjectSettings":
        self = object.__new__(cls)
        self._config_json = json.loads(json_str)
        self._os_env = None
        return self

    def to_json_str(self) -> str:
        return json.dumps(self._config_json, indent=2)

    @property
    def project_name(self) -> str | None:
        return self._config_json.get(self._PROJECT_NAME_ATTR)

    @project_name.setter
    def project_name(self, value: str | None):
        self._config_json[self._PROJECT_NAME_ATTR] = value

    @property
    def profile_name(self) -> str | None:
        return self._config_json.get(self._PROFILE_NAME_ATTR)

    @profile_name.setter
    def profile_name(self, value: str | None):
        self._config_json[self._PROFILE_NAME_ATTR] = value

    @property
    def specs(self) -> list[str] | None:
        raw = self._config_json.get(self._SPECS_ATTR)
        if raw is None:
            return None
        if not isinstance(raw, list) or not all(isinstance(s, str) for s in cast(list[object], raw)):
            raise InvalidSettingsError(f"'specs' in codespeak.json must be a list of strings (file paths), got: {raw}")
        return cast(list[str], raw)

    @specs.setter
    def specs(self, value: list[str] | None):
        if value is not None:
            self._config_json[self._SPECS_ATTR] = value
        elif self._SPECS_ATTR in self._config_json:
            del self._config_json[self._SPECS_ATTR]

    @property
    def whitelisted_files(self) -> list[str]:
        return self._config_json.get(self._WHITELISTED_FILES_ATTR, [])

    @whitelisted_files.setter
    def whitelisted_files(self, value: list[str] | None):
        if value is not None:
            self._config_json[self._WHITELISTED_FILES_ATTR] = value
        elif self._WHITELISTED_FILES_ATTR in self._config_json:
            del self._config_json[self._WHITELISTED_FILES_ATTR]

    def save(self, settings_path_relative: ProjectPath) -> None:
        if not self._os_env:
            raise RuntimeError("Cannot save settings as OsEnvironment is not set")

        config_str = json.dumps(self._config_json, indent=2)
        self._os_env.write_file(settings_path_relative, config_str)
