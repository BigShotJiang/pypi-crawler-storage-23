from argparse import Namespace
from collections.abc import Callable
from typing import TypeVar

from rich.console import Console

from codespeak_shared import BuildResult
from codespeak_shared.codespeak_project import CodeSpeakProject
from codespeak_shared.exceptions import (
    CodeChangeRequestFileAlreadyExists,
    CodeChangeRequestFileDoesntExist,
)
from codespeak_shared.project_initializer import load_shared_resource

T = TypeVar("T")


def implement_code_change_request(
    project: CodeSpeakProject,
    args: Namespace,
    console: Console,
    build_project: Callable[[], BuildResult],
) -> BuildResult:
    if args.new:
        path = project.code_change_request_path()
        if project.os_env().exists(path):
            return BuildResult.failed("change", CodeChangeRequestFileAlreadyExists(str(path.get_underlying_path())))
        project.os_env().write_file(path, load_shared_resource("change-request-template.cs.md"))
        console.print(f"[progress.success.text]Created template change request in [/progress.success.text] {path}.")
        return BuildResult.succeeded("change")
    else:
        path = project.code_change_request_path()
        # TODO(dsavvinov): a bit hacky way of saying "let's run a different set of phases, but aside from that, generally
        # do same things as normal build (specifically, checkpoints housekeeping and build resume validation)"
        # It's hacky because generally we're not thinking about profiles as something that can be changed naturally by the user,
        # but so far there are no known issues with that, so we'll keep it until more requirements arise.
        args.profile = "change_request"
        file_exists = project.os_env().exists(path)
        if args.message and file_exists:
            return BuildResult.failed("change", CodeChangeRequestFileAlreadyExists(str(path.get_underlying_path())))
        elif not args.message and not file_exists:
            return BuildResult.failed("change", CodeChangeRequestFileDoesntExist(str(path.get_underlying_path())))
        elif args.message and not file_exists:
            project.os_env().write_file(path, args.message)
            console.print(f"[progress.success.text]Created change request in [/progress.success.text] {path}.")
            return build_project()
        else:  # not args.message and path.exists() - normal case
            return build_project()
