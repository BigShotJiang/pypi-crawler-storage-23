import logging
import os
import threading
from os import _Environ as Environ  # pyright: ignore[reportPrivateUsage]
from typing import Any, NoReturn, cast, override

from codespeak_shared.utils.type_utils import instanceof

# Thread-local storage to track when we're in initialization
_thread_local = threading.local()


class _FlagAccessProxy:
    """Proxy object that raises an error when accessed directly but allows get_flag_value usage."""

    def __init__(self, flag: "FeatureFlag[Any]", flag_name: str):
        self._flag = flag
        self._flag_name = flag_name

    def __bool__(self):
        self.throw(self._flag_name)

    @override
    def __eq__(self, other: Any) -> bool:
        self.throw(self._flag_name)

    @override
    def __ne__(self, other: Any) -> bool:
        self.throw(self._flag_name)

    @property
    def name(self) -> str:
        return self._flag_name

    @staticmethod
    def throw(flag_name: str) -> NoReturn:
        raise AttributeError(
            f"Direct access to feature flag '{flag_name}' is not allowed. "
            f"Use feature_flags.get_flag_value(FeatureFlags.{flag_name}) instead."
        )


class FeatureFlagsMeta(type):
    """Metaclass that prevents direct access to FeatureFlag class attributes."""

    @override
    def __getattribute__(cls, name: str) -> Any:
        attr = super().__getattribute__(name)

        # If it's a FeatureFlag instance, return proxy except during initialization
        if instanceof(attr, FeatureFlag[Any]):
            # Allow access during initialization
            if getattr(_thread_local, "allow_flag_access", False):
                return attr

            # Return a proxy that will error on direct usage but allows get_flag_value
            return _FlagAccessProxy(attr, name)

        return attr


class FeatureFlag[T]:
    def __init__(self, default_value: T, override_value: T | None = None):
        self.name: str | None = None  # Will be set by FeatureFlags during initialization
        self.default_value: T = default_value

    @staticmethod
    def _parse_env_value[TT](env_value: str, default_value: TT) -> TT:
        """Parse environment variable value according to the default value type."""
        if isinstance(default_value, bool):
            return cast(TT, env_value.lower() in ("true", "1", "yes", "on"))
        elif isinstance(default_value, int):
            try:
                return cast(TT, int(env_value))
            except ValueError:
                return default_value
        elif isinstance(default_value, float):
            try:
                return cast(TT, float(env_value))
            except ValueError:
                return default_value
        else:
            return cast(TT, env_value)

    @property
    def value(self) -> T:
        if self.name is None:
            raise RuntimeError("FeatureFlag name not set. Must be used within FeatureFlags class.")
        env_var_name = f"CODESPEAK_{self.name}"
        env_value = os.getenv(env_var_name)
        if env_value is not None:
            return self._parse_env_value(env_value, self.default_value)
        return self.default_value


class FeatureFlagsRegistry:
    def __init__(
        self,
        environment: dict[str, Any] | Environ[str],
        enabled_flags: list[str] | None = None,
        disabled_flags: list[str] | None = None,
    ):
        self.flags: dict[str, Any] = {}
        self.flag_sources: dict[str, str] = {}  # Track where each flag value came from

        # Allow flag access during initialization
        _thread_local.allow_flag_access = True
        try:
            # Initialize all declared flags
            for attr_name in dir(self.__class__):
                attr_value = getattr(self.__class__, attr_name)
                if instanceof(attr_value, FeatureFlag[Any]):
                    # Set the flag name from the attribute name
                    attr_value.name = attr_name
                    value, source = self._initialize_flag(attr_value, environment)
                    self.flags[attr_name] = value
                    self.flag_sources[attr_name] = source

            # can't print warnings right away since the console is not yet configured
            self.warnings = self._apply_overrides(enabled_flags, disabled_flags)
        finally:
            _thread_local.allow_flag_access = False

    def _apply_overrides(
        self, enabled_flag_names: list[str] | None, disabled_flag_names: list[str] | None
    ) -> list[str]:
        unresolved_flags: list[str] = []
        enabled_flags: set[FeatureFlag[object]] = set()
        disabled_flags: set[FeatureFlag[object]] = set()

        def resolve_feature_flags(
            passed_names: list[str] | None, resolved: set[FeatureFlag[object]], unresolved: list[str]
        ):
            if passed_names is None:
                return
            for feature in passed_names:
                flag = self._resolve_flag_by_name(feature)
                if flag:
                    resolved.add(flag)
                else:
                    unresolved.append(feature)

        resolve_feature_flags(enabled_flag_names, enabled_flags, unresolved_flags)
        resolve_feature_flags(disabled_flag_names, disabled_flags, unresolved_flags)

        warnings = list[str]()
        if enabled_flags or disabled_flags:
            warnings.append(
                "[warning]Internal flags (--enable-flag/--disable-flag) were used. Stability of CodeSpeak is not guaranteed.[/warning]"
            )

        if unresolved_flags:
            warnings.append(
                f"[warning]Internal flags with the following names were not found and will be ignored[/warning]: {', '.join(unresolved_flags)}"
            )

        conflicting_features = enabled_flags & disabled_flags
        enabled_flags -= conflicting_features
        disabled_flags -= conflicting_features

        if conflicting_features:
            conflicting_feature_names = ", ".join(flag.name for flag in conflicting_features if flag.name is not None)
            warnings.append(
                f"[warning]Internal flags with the following names were used together and will be ignored[/warning]:\n{conflicting_feature_names}"
            )

        for feature in enabled_flags:
            if feature.name is not None:
                self.flags[feature.name] = True
                self.flag_sources[feature.name] = "cli_override"
        for feature in disabled_flags:
            if feature.name is not None:
                self.flags[feature.name] = False
                self.flag_sources[feature.name] = "cli_override"

        return warnings

    @staticmethod
    def _initialize_flag[T](flag: FeatureFlag[T], environment: dict[str, Any] | Environ[str]) -> tuple[T, str]:
        env_var_name = f"CODESPEAK_{flag.name}"
        env_value = environment.get(env_var_name)

        if env_value is not None:
            env_value = str(env_value)
            parsed_value: T = FeatureFlag._parse_env_value(env_value, flag.default_value)  # pyright: ignore[reportPrivateUsage]
            return parsed_value, f"environment ({env_var_name}={env_value})"
        return flag.default_value, "default"

    @staticmethod
    def get_flag_name(flag: FeatureFlag[Any]) -> str | None:
        if isinstance(flag, _FlagAccessProxy):
            return flag._flag_name  # pyright: ignore[reportPrivateUsage]
        else:
            return getattr(flag, "name", None)

    def get_flag_value[T](self, flag: FeatureFlag[T]) -> T:
        flag_name = self.get_flag_name(flag)

        if flag_name and flag_name in self.flags:
            return cast(T, self.flags.get(flag_name))

        raise ValueError(f"FeatureFlag instance is not defined in {self.__class__.__name__} class")

    def set_flag_value[T](self, flag: FeatureFlag[T], value: T) -> None:
        flag_name = self.get_flag_name(flag)

        if flag_name and flag_name in self.flags:
            self.flags[flag_name] = value
            self.flag_sources[flag_name] = "programmatic"
            return

        raise ValueError(f"FeatureFlag instance is not defined in {self.__class__.__name__} class")

    def _resolve_flag_by_name(self, flag_name: str) -> FeatureFlag[object] | None:
        flag_name = str.upper(flag_name)
        if flag_name.startswith("CODESPEAK_"):
            flag_name = flag_name.removeprefix("CODESPEAK_")
        if not hasattr(self.__class__, flag_name):
            return None
        attr_value = getattr(self.__class__, flag_name)
        if isinstance(attr_value, FeatureFlag):
            return cast(FeatureFlag[object], attr_value)
        else:
            return None

    def to_dict(self) -> dict[str, Any]:
        """Return a read-only copy of all flag values as a dictionary."""
        return self.flags.copy()

    def dump_to_log(self):
        logger = logging.getLogger(self.__class__.__qualname__)
        for key, value in sorted(self.flags.items(), key=lambda item: item[0]):
            source = self.flag_sources.get(key, "unknown")
            logger.info(f"{key}: {value} (from {source})")

    @classmethod
    def instance(cls, environment: dict[str, Any] | Environ[str] | None = None) -> "FeatureFlagsRegistry":
        if environment is None:
            environment = os.environ
        return cls(environment)

    @override
    def __getattribute__(self, name: str) -> Any:
        # Allow access to methods and non-flag attributes
        attr_ = super().__getattribute__(name)

        # If it's a FeatureFlag instance, prevent direct access
        if isinstance(attr_, FeatureFlag):
            raise _FlagAccessProxy.throw(name)

        return attr_


class SharedFeatureFlags(FeatureFlagsRegistry, metaclass=FeatureFlagsMeta):
    """Shared feature flags available across all packages."""

    CONSOLE_USES_DARK_THEME = FeatureFlag(default_value=True)

    PRINT_STACKTRACE_ON_FAILURE = FeatureFlag(default_value=False)

    SHOW_LOCALS_IN_STACKTRACE = FeatureFlag(default_value=False)

    DEBUG_GRPC = FeatureFlag(default_value=False)

    MAX_GRPC_MESSAGE_LENGTH = FeatureFlag(default_value=50 * 1024 * 1024)  # 50 MB
