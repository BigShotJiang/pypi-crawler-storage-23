"""Shared foundational types for CodeSpeak packages."""

from codespeak_shared.build_insight import (
    BuildInsightEvent,
    BuildInsightStorage,
    BuildInsightStorageMode,
    NoOpBuildInsightStorage,
    ProgressItemCreateEvent,
    ProgressItemStatus,
    ProgressItemUpdateEvent,
    SpanCloseEvent,
    SpanOpenEvent,
    TestsRunEvent,
    TextOutputEvent,
    ToolCallEvent,
    UserVisibleModelOutputEvent,
)
from codespeak_shared.build_result import BuildResult, BuildResultType, BuildStatistics
from codespeak_shared.logging import LoggingUtil, NoOpSpanProvider, SpanProvider
from codespeak_shared.project_path import ProjectPath
from codespeak_shared.test_runner_types import MissingCoverage, TestFailure, TestOutcome, TestResults

__all__ = [
    "BuildInsightEvent",
    "BuildInsightStorage",
    "BuildInsightStorageMode",
    "BuildResult",
    "BuildResultType",
    "BuildStatistics",
    "LoggingUtil",
    "MissingCoverage",
    "NoOpBuildInsightStorage",
    "NoOpSpanProvider",
    "ProgressItemCreateEvent",
    "ProgressItemStatus",
    "ProgressItemUpdateEvent",
    "ProjectPath",
    "SpanCloseEvent",
    "SpanOpenEvent",
    "SpanProvider",
    "TestFailure",
    "TestOutcome",
    "TestResults",
    "TestsRunEvent",
    "TextOutputEvent",
    "ToolCallEvent",
    "UserVisibleModelOutputEvent",
]
