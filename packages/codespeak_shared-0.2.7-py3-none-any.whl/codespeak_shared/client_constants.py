class ClientConstants:
    CONSOLE_CLIENT_PACKAGE_NAME = "codespeak-cli"

    CONSOLE_CLIENT_UPGRADE_COMMAND = f"uv tool upgrade {CONSOLE_CLIENT_PACKAGE_NAME}"
