from enum import Enum

from pydantic import BaseModel


class TestOutcome(str, Enum):
    """Possible outcomes for a test."""

    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    ERROR = "error"
    XFAILED = "xfailed"  # Expected to fail and did fail
    XPASSED = "xpassed"  # Expected to fail but passed

    __test__ = False


class TestFailure(BaseModel):
    test_name: str
    message: str
    outcome: TestOutcome

    __test__ = False


class MissingCoverage(BaseModel):
    file_path: str
    function_name: str
    uncovered_ranges: list[tuple[int, int]] = []

    def format_message(self) -> str:
        if self.uncovered_ranges:
            ranges = ", ".join(f"{r[0]}-{r[1]}" if r[0] != r[1] else str(r[0]) for r in self.uncovered_ranges)
            return f"Function {self.function_name} in {self.file_path}, uncovered lines: {ranges}"
        else:
            return f"Function {self.function_name} in {self.file_path} not covered at all"


class TestResults(BaseModel):
    test_discovery_failure: str | None = None
    passed: int = 0
    failed: int = 0
    skipped: int = 0
    error: int = 0
    test_failures: list[TestFailure] = []
    missing_coverage: list[MissingCoverage] = []
    total_coverage_percent: float | None = None

    __test__ = False
