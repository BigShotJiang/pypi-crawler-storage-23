from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import override

from codespeak_shared.os_environment import LocalOsEnvironment, OsEnvironment
from codespeak_shared.project_path import ProjectPath
from codespeak_shared.project_settings import ProjectSettings


class CodeSpeakProject(ABC):
    SETTINGS_FILE_NAME = "codespeak.json"
    ENTRY_POINT_FILE_NAME = "main.cs.md"
    CODESPEAK_INTERNAL_DATA_DIR_NAME = ".codespeak"
    CODESPEAK_INTERNAL_IGNORED_DATA_DIR_NAME = "ignored"
    SPEC_FILES_DIR_NAME = "spec"
    CODE_CHANGE_REQUEST_FILE_NAME = "change-request.cs.md"

    @property
    @abstractmethod
    def project_root(self) -> ProjectPath:
        pass

    @property
    @abstractmethod
    def project_name(self) -> str:
        pass

    @property
    @abstractmethod
    def profile_name(self) -> str | None:
        pass

    @property
    def codespeak_settings_path(self) -> ProjectPath:
        return self.project_root / self.SETTINGS_FILE_NAME

    @property
    def entry_point_path(self) -> ProjectPath:
        return self.spec_files_root / self.ENTRY_POINT_FILE_NAME

    @property
    def spec_files_root(self) -> ProjectPath:
        return self.project_root / self.SPEC_FILES_DIR_NAME

    @property
    def target_app_root(self) -> ProjectPath:
        return self.project_root

    @property
    def internal_data_root(self) -> ProjectPath:
        return self.project_root / self.CODESPEAK_INTERNAL_DATA_DIR_NAME

    @property
    def ignored_data_root(self) -> ProjectPath:
        return self.internal_data_root / self.CODESPEAK_INTERNAL_IGNORED_DATA_DIR_NAME

    # Layout factory-methods
    def path_in_target_app(self, file_relative_to_sources_dir: str) -> ProjectPath:
        return self.target_app_root / file_relative_to_sources_dir

    def internal_data_path(self, file_relative_to_internal_data_dir: str) -> ProjectPath:
        return self.internal_data_root / file_relative_to_internal_data_dir

    def ignored_data_path(self, file_relative_to_ignored_data_dir: str) -> ProjectPath:
        return self.ignored_data_root / file_relative_to_ignored_data_dir

    def path_in_project(self, project_relative_path: str) -> ProjectPath:
        return self.project_root / project_relative_path

    def code_change_request_path(self) -> ProjectPath:
        return self.project_root / self.CODE_CHANGE_REQUEST_FILE_NAME

    @abstractmethod
    def os_env(self) -> OsEnvironment:
        pass

    @property
    def specs(self) -> list[str] | None:
        return None

    @property
    def whitelisted_files(self) -> list[str]:
        return []


class FileBasedCodeSpeakProject(CodeSpeakProject):
    def __init__(self, project_root: Path, new_project_params: tuple[str | None, str | None] | None = None):
        self._local_project_root = project_root  # don't resolve the path as it can contain symlinks
        assert self._local_project_root.is_dir(), f"Project root {self.project_root} is not a directory"

        self._local_env = LocalOsEnvironment(self._local_project_root)

        if new_project_params is not None:
            # new project
            project_name, profile_name = new_project_params
            self._settings = ProjectSettings.empty(self._local_env)
            if project_name is not None:
                self._settings.project_name = project_name
            if profile_name is not None:
                self._settings.profile_name = profile_name
            # Always save settings file for new projects, even if empty
            self._settings.save(self.codespeak_settings_path)
        else:
            # existing project
            self._settings: ProjectSettings = ProjectSettings.load(self._local_env, self.codespeak_settings_path)

        self._project_name = (
            self._settings.project_name if self._settings.project_name else self._local_project_root.resolve().name
        )

    def settings_json_str(self) -> str:
        return self._settings.to_json_str()

    @classmethod
    def load_existing(cls, project_root: Path) -> FileBasedCodeSpeakProject:
        return cls(project_root, new_project_params=None)

    @classmethod
    def create_new(
        cls, project_root: Path, override_project_name: str | None = None, override_profile_name: str | None = None
    ) -> FileBasedCodeSpeakProject:
        return cls(project_root, new_project_params=(override_project_name, override_profile_name))

    @override
    def __str__(self) -> str:
        return f"Project '{self.project_name}' (at {self.project_root})"

    @property
    @override
    def project_root(self) -> ProjectPath:
        return ProjectPath.from_path(self._local_project_root)

    @property
    @override
    def project_name(self) -> str:
        return self._project_name

    @property
    @override
    def profile_name(self) -> str | None:
        return self._settings.profile_name

    @property
    @override
    def specs(self) -> list[str] | None:
        return self._settings.specs

    @property
    @override
    def whitelisted_files(self) -> list[str]:
        return self._settings.whitelisted_files

    @classmethod
    def is_valid_codespeak_project_root(cls, path: Path) -> bool:
        return (path / cls.SETTINGS_FILE_NAME).exists()

    @classmethod
    def find_upwards(cls, current_path: Path) -> FileBasedCodeSpeakProject | None:
        current_path = current_path.resolve()
        assert current_path.exists(), f"Path {current_path} doesn't exist"

        current_dir = current_path
        while True:
            if cls.is_valid_codespeak_project_root(current_dir):
                return cls.load_existing(current_dir)
            if current_dir == current_dir.parent:  # Stop when we reach filesystem root
                return None
            current_dir = current_dir.parent

    @override
    def os_env(self) -> OsEnvironment:
        return self._local_env
