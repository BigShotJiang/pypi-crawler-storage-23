"""
Environment variable allowlist for client-server communication.

Only environment variables in this allowlist are transmitted from client to server (enforced both at the server and client side).

Note: client feature flags are passed separately, so always allowlisted.

"""

from collections.abc import Mapping

ENV_ALLOWLIST = frozenset(
    {
        # Anthropic
        "ANTHROPIC_API_KEY",
        # OpenAI
        "OPENAI_API_KEY",
        # Amazon Bedrock
        "AWS_ACCESS_KEY_ID",
        "AWS_SECRET_ACCESS_KEY",
        # Cerebras
        "CEREBRAS_API_KEY",
    }
)


def filter_env_vars(env: Mapping[str, str]) -> dict[str, str]:
    result = dict[str, str]()
    for key, value in env.items():
        # pass all CODESPEAK_* env variables as they can define Core feature flags
        if key in ENV_ALLOWLIST or key.startswith("CODESPEAK_"):
            result[key] = value
    return result
