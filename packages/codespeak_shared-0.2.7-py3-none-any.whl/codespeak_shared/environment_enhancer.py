"""Environment enhancer for interactive API key prompting."""

import os
import sys
from pathlib import Path

from anthropic import Anthropic, APIConnectionError, AuthenticationError
from rich.console import Console
from rich.prompt import Prompt

from codespeak_shared.exceptions import AnthropicApiKeyMissingUserError
from codespeak_shared.utils.dotenv_utils import append_to_env_local


def enhance_environment_with_api_key(
    console: Console,
    env_vars: dict[str, str],
    project_root: Path,
    no_interactive: bool,
) -> dict[str, str]:
    """
    Enhance environment with interactive API key prompting if needed.

    Returns enhanced env_vars dict (copy, doesn't modify original).
    """
    project_root_path = Path(str(project_root))

    if not _should_prompt_for_api_key(env_vars, no_interactive):
        return env_vars

    console.print("\n[yellow]Anthropic API Key not found[/yellow]")
    console.print("[dim]You can get your API key from: https://console.anthropic.com/settings/keys[/dim]\n")

    max_attempts = 3
    for attempt in range(1, max_attempts + 1):
        try:
            api_key = Prompt.ask(
                "[bold]Enter your Anthropic API key[/bold]",
                password=True,
            )

            if not api_key or not api_key.strip():
                console.print("[red]✗[/red] API key cannot be empty\n")
                continue

            api_key = api_key.strip()

            console.print("[dim]Validating API key...[/dim]")
            is_valid_api, api_error = _validate_api_key_with_api(api_key)

            if not is_valid_api:
                console.print(f"[red]✗[/red] {api_error}\n")
                if attempt < max_attempts:
                    console.print(f"[dim]Please try again ({attempt}/{max_attempts} attempts)[/dim]\n")
                continue

            _save_api_key_to_env_local(console, project_root_path, api_key)

            enhanced_vars = dict(env_vars)
            enhanced_vars["ANTHROPIC_API_KEY"] = api_key
            os.environ["ANTHROPIC_API_KEY"] = api_key

            return enhanced_vars

        except KeyboardInterrupt:
            console.print("\n[yellow]Cancelled by user[/yellow]")
            raise AnthropicApiKeyMissingUserError("API key entry cancelled by user")

    console.print(f"[red]Failed to obtain valid API key after {max_attempts} attempts.[/red]")
    raise AnthropicApiKeyMissingUserError(f"Failed to obtain valid API key after {max_attempts} attempts")


def _should_prompt_for_api_key(env_vars: dict[str, str], no_interactive: bool) -> bool:
    """Check if we should prompt for API key."""
    if env_vars.get("ANTHROPIC_API_KEY"):
        return False

    # TODO: Check if AWS Bedrock or LiteLLM are enabled via feature flags,
    #       can't do easily with the current client design

    # if feature_flags.get_flag_value(CoreFeatureFlags.USE_AWS_BEDROCK):
    #     return False

    # if feature_flags.get_flag_value(CoreFeatureFlags.ENABLE_LITE_LLM):
    #     return False

    # Check for external LiteLLM proxy
    if env_vars.get("LITELLM_PROXY"):
        return False

    if no_interactive:
        return False

    if not _is_terminal_interactive():
        return False

    return True


def _is_terminal_interactive() -> bool:
    """Check if terminal is interactive (TTY and not CI environment)."""
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return False

    ci_indicators = ["CI", "CONTINUOUS_INTEGRATION", "GITHUB_ACTIONS", "GITLAB_CI", "CIRCLECI", "TRAVIS"]
    if any(os.getenv(var) for var in ci_indicators):
        return False

    return True


def _validate_api_key_with_api(key: str) -> tuple[bool, str]:
    """
    Validate API key by calling the /v1/models endpoint.

    This endpoint lists available models and is free/very cheap.
    It requires authentication, so it validates the key works.

    Returns: (is_valid, error_message)
    """
    try:
        client = Anthropic(api_key=key)
        client.models.list()
        return (True, "")
    except AuthenticationError:
        return (False, "Invalid API key - authentication failed")
    except (OSError, TimeoutError, ConnectionError, APIConnectionError):
        return (True, "")


def _save_api_key_to_env_local(console: Console, project_root: Path, api_key: str) -> None:
    """Save API key to .env.local file."""
    env_local_path = project_root / ".env.local"

    try:
        append_to_env_local(env_local_path, "ANTHROPIC_API_KEY", api_key)

        relative_path = env_local_path.relative_to(project_root)
        console.print(f"\n[green]✓[/green] API key saved to [cyan]{relative_path}[/cyan]")
        console.print("[dim]This file is gitignored and won't be committed to version control.[/dim]")
        console.print("[dim]Tip: You can also set ANTHROPIC_API_KEY in your shell environment.[/dim]\n")
    except OSError as e:
        console.print(f"\n[yellow]⚠[/yellow] Could not save API key to file: {e}")
        console.print("[dim]API key will be used for this session only.[/dim]\n")
