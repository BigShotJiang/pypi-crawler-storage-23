"""Shared project initialization logic for CodeSpeak."""

import logging
from argparse import Namespace
from importlib.resources import files
from pathlib import Path
from typing import Callable

from rich.console import Console

from codespeak_shared import BuildResult, LoggingUtil
from codespeak_shared.cmdline_tools.git_tool import MIN_GIT_VERSION, GitVersionParser
from codespeak_shared.cmdline_tools.version_parser import validate_required_tools
from codespeak_shared.codespeak_project import FileBasedCodeSpeakProject
from codespeak_shared.exceptions import (
    CodespeakUserError,
    GitRepositoryNotFoundUserError,
    InvalidCommandLineParameterUserError,
    ProjectAlreadyInitializedUserError,
    UnknownProfileUserError,
)
from codespeak_shared.profile_names import MIXED_MODE_PROFILE_NAME, is_valid_profile_name
from codespeak_shared.shared_feature_flags import SharedFeatureFlags
from codespeak_shared.utils.colors import Colors
from codespeak_shared.utils.git_helper import SharedGitHelper


def append_codespeak_entries_to_gitignore(git_repo_root: Path) -> None:
    gitignore_path = git_repo_root / ".gitignore"
    try:
        content = gitignore_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        content = ""

    lines_to_append = "# CodeSpeak\n.codespeak/ignored/\n"
    if content and not content.endswith("\n"):
        lines_to_append = "\n" + lines_to_append

    gitignore_path.write_text(content + lines_to_append, encoding="utf-8")


def load_shared_resource(path_in_resources_folder: str) -> str:
    """Load a resource file from the shared package resources."""
    return (files("codespeak_shared.resources") / path_in_resources_folder).read_text(encoding="utf-8")


def initialize_project(
    current_path: Path,
    console: Console,
    feature_flags: SharedFeatureFlags,
    args: Namespace,
    initialize_logging: Callable[[FileBasedCodeSpeakProject, SharedFeatureFlags], None],
) -> BuildResult:
    local_project = FileBasedCodeSpeakProject.find_upwards(current_path)
    if local_project:
        if (
            local_project.project_root.get_underlying_path().samefile(current_path.resolve())
            or not args.ignore_enclosing_project_check
        ):
            # NB: even --ignore-enclosing-project-check doesn't allow to init a project in the SAME folder as an already existing project
            return BuildResult.failed("init", ProjectAlreadyInitializedUserError(str(local_project.project_root)))

    # TODO we may want to pull the list of profiles from the server
    # Validate profile name
    if args.profile and not is_valid_profile_name(args.profile):
        return BuildResult.failed("init", UnknownProfileUserError(args.profile))

    # Check for conflicting parameters
    if args.mixed and args.profile and args.profile != MIXED_MODE_PROFILE_NAME:
        return BuildResult.failed(
            "init",
            InvalidCommandLineParameterUserError("Can't use --mixed-mode together with a custom --profile arg"),
        )

    if args.mixed:
        git_repo_root = SharedGitHelper.get_git_repo_root()
        if not git_repo_root:
            return BuildResult.failed("init", GitRepositoryNotFoundUserError(current_path))
        FileBasedCodeSpeakProject.create_new(
            git_repo_root,
            override_project_name=args.project_name,
            override_profile_name=MIXED_MODE_PROFILE_NAME,
        )
        append_codespeak_entries_to_gitignore(git_repo_root)
        console.print("[dim]Initialized CodeSpeak project in mixed mode[/dim]")
        return BuildResult.succeeded("init")

    # Rest of the function - for init in greenfield mode

    local_project = FileBasedCodeSpeakProject.create_new(
        current_path,
        override_project_name=args.project_name,
        override_profile_name=args.profile,
    )

    logging_initialized = False

    def maybe_log_error(msg: str, exception: BaseException | None):
        # by default, logger would write stacktrace to the console
        if logging_initialized:
            logging.getLogger("project_initializer").error(msg, exc_info=exception)

    try:
        # below we can also use direct paths
        local_project.os_env().mkdirs(local_project.internal_data_root)
        initialize_logging(local_project, feature_flags)
        logging_initialized = True

        with LoggingUtil.Span(
            f"Initializing new project in {local_project.project_root.get_underlying_path().resolve()}"
        ):
            feature_flags.dump_to_log()
            validate_required_tools({GitVersionParser(): MIN_GIT_VERSION}, local_project.os_env())

            # create Git repo in the project root, we'll need it for internal purposes (state machine)
            git_helper = SharedGitHelper(local_project.os_env())
            git_helper.create_repo()  # Tolerant to the case when repo already exists

            # Make the commit with .gitignore and codespeak.json
            git_ignore_contents = load_shared_resource("app_template/.gitignore")
            gitignore_path_relative = ".gitignore"
            local_project.os_env().write_file(
                local_project.path_in_project(gitignore_path_relative), git_ignore_contents
            )

            files_to_commit: list[str] = [
                str(gitignore_path_relative),
                str(local_project.codespeak_settings_path),
            ]

            git_helper.add_files(files_to_commit)
            git_helper.commit_files(
                title="Initial commit",
                description="",
                files=files_to_commit,
            )

            spec_existed = local_project.os_env().is_file(local_project.entry_point_path)
            # Add new template file (unversioned)
            if spec_existed:
                message = f"[dim]Initialized CodeSpeak project '{local_project.project_name}' in the current directory using exising specification"
            else:
                spec_folder = local_project.entry_point_path.parent
                local_project.os_env().mkdirs(spec_folder)

                initial_spec = load_shared_resource("templates/initial_spec.md")
                local_project.os_env().write_file(local_project.entry_point_path, initial_spec)

                message = f"[dim]Initialized CodeSpeak project '{local_project.project_name}' in the current directory"

            if args.profile:
                message += f" using custom profile: {args.profile}"
            message += ".[/dim]"
            console.print(message)
            if spec_existed:
                console.print(
                    "[progress.success.text]Run `codespeak build` to start the build.[/progress.success.text]"
                )
            else:
                console.print(
                    "[progress.success.text]Check out the spec in spec/main.cs.md and run `codespeak build` to start the build.[/progress.success.text]"
                )

            if not git_helper.is_user_configured():
                console.print("\n[yellow]Tip: Git user identity (user.name and user.email) is not configured.[/yellow]")

        return BuildResult.succeeded("init")

    except KeyboardInterrupt as e:
        maybe_log_error(f"{Colors.BRIGHT_RED}Init interrupted{Colors.END}", exception=None)
        return BuildResult.failed("init", e)

    except CodespeakUserError as e:
        maybe_log_error(f"{Colors.BRIGHT_RED}Init failed with user error: {e}{Colors.END}", e)
        return BuildResult.failed("init", e)

    except BaseException as e:  # noqa: BLE001 (init_project catch-all block)
        maybe_log_error(f"{Colors.BRIGHT_RED}Init failed with internal error: {e}{Colors.END}", e)
        return BuildResult.failed("init", e)
