"""Base exception classes for CodeSpeak packages."""

from pathlib import Path
from traceback import FrameSummary

# See https://docs.google.com/document/d/1EfVonaIu6smgZUdvbLCmZgr-ohpuDnl3JwS7rWapgYY/edit?tab=t.0#heading=h.u4o2staonnap
# for error handling philosophy.


class CodespeakUserError(Exception):
    """Base class for user-facing errors."""

    EXIT_CODE = 1

    def __init__(self, user_visible_message: str):
        super().__init__(user_visible_message)


class CodespeakProviderFailure(CodespeakUserError):
    """Base class for provider-related failures.

    Formally, this is not a user error (rather than model provider),
    but this is not something CodeSpeak is responsible for or can do anything about.
    User needs to wait or configure a different provider.
    """

    def __init__(self, user_visible_message: str):
        super().__init__(user_visible_message)


class CodespeakInternalError(Exception):
    """Base class for internal errors."""

    EXIT_CODE = 100

    def __init__(
        self,
        internal_message: str | None = None,
        cause: Exception | None = None,
        server_stack_trace: str | None = None,
    ):
        super().__init__(internal_message)
        if not internal_message and not cause:
            raise ValueError("internal_message or cause must be provided")

        self.cause = cause  # Python exception chaining works only when raising an exception
        self.server_stack_trace = server_stack_trace


class InvalidSettingsError(CodespeakUserError):
    """Error raised when codespeak.json contains invalid settings."""

    def __init__(self, message: str):
        super().__init__(message)


class ProjectNotFoundUserError(CodespeakUserError):
    """Error raised when a CodeSpeak project cannot be found at the specified path."""

    def __init__(self, path: Path):
        super().__init__(f"{path.resolve()} does not belong to a CodeSpeak project. Please run 'codespeak init' first.")


class CodeSpeakServerUnavailableUserError(CodespeakUserError):
    """Error raised when the build server is unavailable."""

    def __init__(self, server_address: str):
        super().__init__(
            f"Failed to connect to build server at {server_address}.\n"
            f"Please ensure the server is running and the address is correct."
        )


class ProjectAlreadyInitializedUserError(CodespeakUserError):
    """Error raised when trying to initialize a project that already exists."""

    def __init__(self, project_root: str):
        super().__init__(f"CodeSpeak project at {project_root} already initialized.")


class UnknownProfileUserError(CodespeakUserError):
    """Error raised when an unknown profile is specified."""

    def __init__(self, profile: str):
        super().__init__(f"Unknown profile: {profile}")


class InvalidCommandLineParameterUserError(CodespeakUserError):
    """Error raised for invalid command line parameters."""

    def __init__(self, user_visible_message: str):
        super().__init__(user_visible_message)


class GitRepositoryNotFoundUserError(CodespeakUserError):
    """Error raised when git repository is required but not found."""

    def __init__(self, project_root: Path):
        super().__init__(
            f"Folder {project_root.resolve()} is not under .git-repository. Git repository is required for mixed mode"
        )


class CmdlineToolMissingUserError(CodespeakUserError):
    """Raised when a required command-line tool is not found."""

    def __init__(self, user_visible_message: str):
        super().__init__(user_visible_message)


class CmdlineToolVersionTooOldUserError(CodespeakUserError):
    """Raised when a command-line tool version is below the minimum required."""

    def __init__(self, user_visible_message: str):
        super().__init__(user_visible_message)


class RequiredToolsValidationUserError(CodespeakUserError):
    """Raised when one or more required tools fail validation."""

    def __init__(self, problems: list[str]):
        message = "Required tools validation failed:\n" + "\n".join(f"  - {p}" for p in problems)
        super().__init__(message)
        self.problems = problems


class CodeChangeRequestFileAlreadyExists(CodespeakUserError):
    """Raised when trying to create a change request file that already exists."""

    def __init__(self, path_to_change_request: str):
        super().__init__(f"Code change request file {path_to_change_request} already exists.\n")


class CodeChangeRequestFileDoesntExist(CodespeakUserError):
    """Raised when a change request file is expected but doesn't exist."""

    def __init__(self, path_to_change_request: str):
        super().__init__(
            f"Code change request file {path_to_change_request} doesn't exist.\n"
            f"Hint: you can run 'codespeak change --new' to create a change request template"
        )


class BuildWithExistingChangeRequest(CodespeakUserError):
    def __init__(self, path_to_change_request: Path):
        super().__init__(
            f"Build cannot be started with an existing change request.\n"
            f"Either:\n"
            f"- remove the change request file ({path_to_change_request}) and build the spec via 'codespeak build'.\n"
            f"- or finish the change request first via 'codespeak change'"
        )


class BuildStartFailedUserError(CodespeakUserError):
    """Error raised when the build failed to start on the server."""

    def __init__(self, user_visible_message: str):
        super().__init__(user_visible_message)


class ServerOverloadedUserError(CodespeakUserError):
    """Error raised when the build server has too many concurrent builds."""

    def __init__(self) -> None:
        super().__init__("CodeSpeak build servers are overloaded. Please try again later.")


class SkipBuildException(Exception):
    """Exception indicating the build was skipped (not failed).

    Progress reporter shows "Skipped" instead of "Failed" for this exception.
    """

    def __init__(self, message: str):
        super().__init__()
        self.user_visible_message = message


class RunCancelledUserError(CodespeakUserError):
    def __init__(self, user_visible_message: str, request_traceback: list[FrameSummary]):
        super().__init__(user_visible_message)
        self.request_traceback = request_traceback


class RunCancelledInternalError(CodespeakInternalError):
    def __init__(self, internal_message: str, request_traceback: list[FrameSummary]):
        super().__init__(internal_message)
        self.request_traceback = request_traceback


class AnthropicApiKeyMissingUserError(CodespeakUserError):
    def __init__(self, message: str | None = None):
        super().__init__(message or "Anthropic API Key not found.")
