"""Shared profile name constants for CodeSpeak."""

# List of valid profile names
# Keep this in sync with the Profiles class in core package
VALID_PROFILE_NAMES = frozenset(
    [
        "claude_code",
        "mixed_mode",
        "change_request",
        "default",  # alias for claude_code
    ]
)

# Default profile name
DEFAULT_PROFILE_NAME = "claude_code"

# Mixed mode profile name
MIXED_MODE_PROFILE_NAME = "mixed_mode"


def is_valid_profile_name(name: str | None) -> bool:
    """Check if a profile name is valid."""
    if name is None:
        return True  # None means use default
    return name.lower() in VALID_PROFILE_NAMES
