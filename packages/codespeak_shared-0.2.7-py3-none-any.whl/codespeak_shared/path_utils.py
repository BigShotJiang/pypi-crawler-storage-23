from pathlib import Path

from codespeak_shared.codespeak_project import CodeSpeakProject
from codespeak_shared.exceptions import CodespeakUserError
from codespeak_shared.project_path import ProjectPath


def try_convert_user_string_to_path_in_project(raw_path: str, project: CodeSpeakProject) -> ProjectPath | None:
    """Resolve raw_path (relative to CWD or absolute) into a project-relative ProjectPath.

    Returns None if the resolved path falls outside the project root.
    """
    resolved = Path(raw_path).resolve()
    project_root = project.project_root.get_underlying_path().resolve()
    if not resolved.is_relative_to(project_root):
        return None
    return ProjectPath.from_path(resolved.relative_to(project_root))


def convert_user_string_to_path_in_project(raw_path: str, project: CodeSpeakProject) -> ProjectPath:
    """Resolve raw_path (relative to CWD or absolute) into a project-relative ProjectPath.

    Raises CodespeakUserError if the resolved path falls outside the project root.
    """
    result = try_convert_user_string_to_path_in_project(raw_path, project)
    if result is None:
        resolved = Path(raw_path).resolve()
        project_root = project.project_root.get_underlying_path().resolve()
        raise CodespeakUserError(
            f"Provided path '{raw_path}' resolves to '{resolved}', which is outside the project root '{project_root}'.\n"
            f"Tip: Specify a path within the project directory"
        )
    return result
