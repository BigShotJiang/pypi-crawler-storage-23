// This is a comment. This line is ignored.
// This is an example of a CodeSpeak specification file.
// Feel free to improve it, experiment wildly, and then run "codespeak build" to see what awesome things happen!

HelloWorld is a Django app that responds to only one route (/) and generates a nice looking HTML page "Hello, World! This is CodeSpeak.".
It is styled with Tailwind CSS.
