from types import UnionType
from typing import Any, TypeIs, cast, get_args, get_origin, overload


def nn[T: Any](nullable: T | None) -> T:
    if nullable is None:
        raise ValueError("Value is None")
    return nullable


@overload
def instanceof[T](obj: object, cls: type[T]) -> TypeIs[T]: ...


@overload
def instanceof[T1, T2](obj: object, cls: tuple[type[T1], type[T2]]) -> TypeIs[T1 | T2]: ...


@overload
def instanceof[T1, T2, T3](obj: object, cls: tuple[type[T1], type[T2], type[T3]]) -> TypeIs[T1 | T2 | T3]: ...


@overload
def instanceof[T1, T2, T3, T4](
    obj: object, cls: tuple[type[T1], type[T2], type[T3], type[T4]]
) -> TypeIs[T1 | T2 | T3 | T4]: ...


@overload
def instanceof[T1, T2, T3, T4, T5](
    obj: object, cls: tuple[type[T1], type[T2], type[T3], type[T4], type[T5]]
) -> TypeIs[T1 | T2 | T3 | T4 | T5]: ...


@overload
def instanceof(obj: object, cls: Any) -> bool: ...


def instanceof(obj: object, cls: Any) -> Any:
    def _normalize(target: Any) -> Any:
        if target is Any:
            return object
        if isinstance(target, UnionType):
            return _normalize(get_args(target))
        if isinstance(target, tuple):
            entries: tuple[Any, ...] = cast(tuple[Any, ...], target)
            return tuple(_normalize(entry) for entry in entries)
        origin = get_origin(target)
        return origin if origin is not None else target

    return isinstance(obj, _normalize(cls))
