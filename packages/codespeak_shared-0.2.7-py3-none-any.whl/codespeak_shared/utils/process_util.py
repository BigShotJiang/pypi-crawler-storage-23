import logging
import selectors
import signal
import subprocess
import sys
import threading
import time
import traceback
from collections.abc import Callable
from enum import Enum
from pathlib import Path
from types import FrameType

from codespeak_shared import LoggingUtil
from codespeak_shared.utils.type_utils import nn

_SLEEP_TIMEOUT = 0.1
_DEFAULT_MAX_LOGGED_LINES = 5000


class ProcessTimeoutError(TimeoutError):
    """TimeoutError that includes partial output captured before timeout."""

    def __init__(self, message: str, stdout: str, stderr: str):
        super().__init__(message)
        self.stdout = stdout
        self.stderr = stderr


class OutputType(Enum):
    STDOUT = 1
    STDERR = 2


def run_child_process_sync(
    args: list[str],
    cwd: str | Path,
    timeout: float,
    check: bool,
    env: dict[str, str] | None = None,
    output_listener: Callable[[str, OutputType], None] | None = None,
    redirected_output_path: str | Path | None = None,
    shell: bool = False,
    max_logged_lines: int | None = _DEFAULT_MAX_LOGGED_LINES,
) -> tuple[int, str, str]:
    """Runs a child process and waits for its exit (or timeout), logging stdout and stderr as output arrives."""

    logger = logging.getLogger("run_child_process_sync")
    with LoggingUtil.Span(f"Running local command: '{' '.join(args)}' in '{cwd}' with timeout {timeout}s"):
        child_process = None
        redirect_file = None
        try:
            start_time = time.time()

            # Open redirect file if specified and use it as stdout
            stdout_target = subprocess.PIPE
            if redirected_output_path:
                redirect_file = open(redirected_output_path, "w", encoding="utf-8")
                stdout_target = redirect_file

            child_process = subprocess.Popen(
                args=args,
                cwd=cwd,
                stdout=stdout_target,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
                stdin=subprocess.DEVNULL,
                shell=shell,
            )

            # Use selectors to do non-blocking reads
            sel = selectors.DefaultSelector()
            # Only register stdout if we're not redirecting to a file
            if not redirect_file:
                process_stdout = nn(child_process.stdout)
                sel.register(process_stdout, selectors.EVENT_READ)
            else:
                process_stdout = None
            sel.register(nn(child_process.stderr), selectors.EVENT_READ)

            stdout_lines: list[str] = []
            stderr_lines: list[str] = []

            def process_output_line(line: str, output_type: OutputType):
                total_lines = len(stdout_lines) + len(stderr_lines)
                should_log = max_logged_lines is None or total_lines < max_logged_lines

                if output_type == OutputType.STDOUT:
                    if should_log:
                        logger.info(f"[STDOUT]: {line}")
                    stdout_lines.append(line)
                else:
                    if should_log:
                        logger.info(f"[STDERR]: {line}")
                    stderr_lines.append(line)

                if output_listener:
                    output_listener(line, output_type)

            def process_available_output(select_timeout: float) -> tuple[bool, bool]:
                """Read available output from selector.

                Returns:
                    (has_fds, read_data):
                        - has_fds: True if selector has registered file descriptors
                        - read_data: True if any data was actually read
                """
                if not sel.get_map():
                    return False, False

                events = sel.select(timeout=select_timeout)
                read_data = False
                for key, _ in events:
                    data = str(key.fileobj.readline())  # type: ignore[attr-defined]  # selector type is too restrictive
                    if not data:
                        # EOF
                        sel.unregister(key.fileobj)
                    else:
                        read_data = True
                        # Only strip the trailing newline delimiter, never skip empty lines —
                        # stripping whitespace leads to bugs like incorrect diff computation.
                        output_line = data.rstrip("\n")
                        output_type = (
                            OutputType.STDOUT if process_stdout and key.fileobj == process_stdout else OutputType.STDERR
                        )
                        process_output_line(output_line, output_type)
                return True, read_data

            while True:
                elapsed = time.time() - start_time
                if elapsed > timeout:
                    stdout = "\n".join(stdout_lines)
                    stderr = "\n".join(stderr_lines)
                    raise ProcessTimeoutError(
                        f"Child process '{' '.join(args)}' timed out after {elapsed:.2f} s",
                        stdout,
                        stderr,
                    )

                exit_code = child_process.poll()
                if exit_code is not None:
                    # Process has finished, drain any remaining output from pipes
                    # First, read any remaining data from the selector (non-blocking)
                    while True:
                        _, read_data = process_available_output(select_timeout=0)
                        if not read_data:
                            break

                    # Then call communicate() to ensure everything is drained
                    # Note: remaining_stdout will be None if stdout was redirected to a file
                    remaining_stdout, remaining_stderr = child_process.communicate()

                    # Add any remaining lines to our collections
                    # Only process stdout if it wasn't redirected (remaining_stdout will be None when redirected)
                    if remaining_stdout:
                        for line in remaining_stdout.rstrip("\n").split("\n"):
                            process_output_line(line, OutputType.STDOUT)

                    if remaining_stderr:
                        for line in remaining_stderr.rstrip("\n").split("\n"):
                            process_output_line(line, OutputType.STDERR)

                    child_process = None  # nothing to kill, child process has already finished

                    stdout = "\n".join(stdout_lines)
                    stderr = "\n".join(stderr_lines)
                    total_lines = len(stdout_lines) + len(stderr_lines)
                    skipped_lines = max(0, total_lines - max_logged_lines) if max_logged_lines is not None else 0
                    skipped_msg = f" ({skipped_lines} lines not logged)" if skipped_lines > 0 else ""
                    logger.info(
                        f"Child process '{' '.join(args)}' finished with exit code {exit_code} after {elapsed:.2f}s{skipped_msg}"
                    )
                    if check and exit_code != 0:
                        raise subprocess.CalledProcessError(exit_code, args, stdout, stderr)
                    return exit_code, stdout, stderr

                # Try to read output with blocking timeout
                has_fds, _ = process_available_output(select_timeout=_SLEEP_TIMEOUT)
                if not has_fds:
                    # No file descriptors registered, sleep before new iteration
                    time.sleep(_SLEEP_TIMEOUT)
        finally:
            if redirect_file:
                redirect_file.close()
            if child_process:
                logger.info(f"Shutting down child process '{' '.join(args)}'")
                kill_child_process(child_process)


def kill_child_process(process: subprocess.Popen[str]):
    process.terminate()
    process.wait(timeout=3)
    process.kill()


def register_signal_handlers():
    def handle_sigterm(sig: int, frame: FrameType | None) -> None:
        stack = traceback.StackSummary(
            traceback.extract_stack(frame) if frame is not None else traceback.StackSummary.from_list([])
        )

        logger = logging.getLogger("sigterm_handler")
        if frame:
            logger.info(f"Interrupted with signal {sig} at\n{''.join(traceback.format_list(stack))}")
            raise KeyboardInterrupt(f"Interrupted with signal {sig} at {frame.f_code.co_name}, line {frame.f_lineno}")
        else:
            logger.error(f"Interrupted with signal {sig}")
            raise KeyboardInterrupt(f"Interrupted with signal {sig}")

    signal.signal(signal.SIGTERM, handle_sigterm)

    # Handle SIGUSR1 to dump thread stack traces for debugging
    def dump_threads_handler(signum: int, frame: FrameType | None) -> None:
        logger.info("Dumping all thread stack traces on SIGUSR1...")
        # Use getattr to access _current_frames without pyright private usage warning
        current_frames: dict[int, FrameType] = getattr(sys, "_current_frames")()
        for thread_id, stack in current_frames.items():
            thread_name = "unknown"
            for thread in threading.enumerate():
                if thread.ident == thread_id:
                    thread_name = thread.name
                    break
            stack_lines = "".join(traceback.format_stack(stack))
            logger.info(f"Thread: {thread_name} (ID: {thread_id})\n{stack_lines}")

    signal.signal(signal.SIGUSR1, dump_threads_handler)

    logger = logging.getLogger("register_sigterm_handler")
    logger.info(f"SIGTERM handler:{signal.getsignal(signal.SIGTERM)}")
    logger.info(f"SIGINT handler: {signal.getsignal(signal.SIGINT)}")
    logger.info(f"SIGUSR1 handler: {signal.getsignal(signal.SIGUSR1)}")
