from abc import ABC, abstractmethod
from typing import Callable


class Disposable(ABC):
    @abstractmethod
    def dispose(self) -> None:
        pass

    @staticmethod
    def from_callable(fn: Callable[[], None]) -> "Disposable":
        return _CallableDisposable(fn)


class _CallableDisposable(Disposable):
    def __init__(self, fn: Callable[[], None]) -> None:
        self._fn = fn

    def dispose(self) -> None:
        self._fn()
