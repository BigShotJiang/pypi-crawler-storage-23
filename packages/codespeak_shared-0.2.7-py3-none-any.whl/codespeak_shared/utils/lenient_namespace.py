from argparse import Namespace
from typing import Any


class LenientNamespace(Namespace):
    def __getattr__(self, name: str) -> Any:
        # Do not fallback to None for private attributes. This is needed because internally
        # argparse relies on the fact that some underscore-named attributes will lead
        # to AttributeError
        if name.startswith("_"):
            raise AttributeError(name)
        return None
