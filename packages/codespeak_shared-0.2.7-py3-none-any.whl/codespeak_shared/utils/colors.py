# ANSI color codes
from enum import Enum

from rich.theme import Theme


class ThemeType(Enum):
    LIGHT = "light"
    DARK = "dark"


class Colors:
    # Bright colors
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_RED = "\033[91m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_MAGENTA = "\033[95m"

    # Text formatting
    BOLD = "\033[1m"
    DIM = "\033[2m"
    GREY = "\033[37m"
    LIGHT_GREY = "\033[38;5;247m"

    # Reset
    END = "\033[0m"

    _LIGHT_THEME = Theme(
        {
            # General colors for statuses/text (darker colors for light background)
            "error": "#d70000",  # Bright red
            "warning": "#af8700",  # Dark yellow/orange
            "success": "#008700",  # Dark green
            "info": "#585858",  # Medium gray
            "primary_text": "#000000",  # Black
            "secondary_text": "#585858",  # Medium gray
            # Progress display
            "progress.pending": "#808080",  # Gray for pending items
            "progress.active": "#af8700",  # Dark yellow for active items
            "progress.success.icon": "#008700",  # Dark green for success icon
            "progress.success.text": "#000000",  # Black for success text
            "error.emphasized": "#d70000 bold",  # Bright red, bold
            "progress.skipped": "#808080",  # Gray for skipped items
            "progress.unknown": "#808080",  # Gray for unknown status
            "progress.timing": "#585858",  # Medium gray for timing
            "progress.status": "#585858 dim",  # Medium gray, dimmed for status text
            "progress.panel.border": "#0087af",  # Blue
            "progress.panel.title": "#000000",  # Black
            "progress.tree": "#808080",  # Gray for tree lines
        }
    )

    _DARK_THEME = Theme(
        {
            # General colors for statuses/text
            "error": "#f92672",  # MONOKAI pink/red
            "warning": "#e6db74",  # MONOKAI yellow
            "success": "#a6e22e",  # MONOKAI green
            "info": "#75715e",  # MONOKAI comment gray
            "primary_text": "#f8f8f2",  # MONOKAI foreground white
            "secondary_text": "#75715e",  # MONOKAI comment gray
            # Progress display
            "progress.pending": "#75715e",  # MONOKAI comment gray
            "progress.active": "#e6db74",  # MONOKAI yellow
            "progress.success.icon": "#a6e22e",  # MONOKAI green for ✓ icon only
            "progress.success.text": "#f8f8f2",  # MONOKAI foreground for done text
            "error.emphasized": "#f92672 bold",  # MONOKAI pink/red
            "progress.skipped": "#75715e",  # MONOKAI comment gray for skipped items
            "progress.unknown": "#75715e",  # MONOKAI comment gray
            "progress.timing": "#75715e",  # MONOKAI comment gray
            "progress.status": "#75715e dim",  # MONOKAI comment gray, dimmed for status text
            "progress.panel.border": "#66d9ef",  # MONOKAI blue
            "progress.panel.title": "#f8f8f2",  # MONOKAI foreground white
            "progress.tree": "#75715e",  # MONOKAI comment gray for tree lines
        }
    )

    @staticmethod
    def get_theme(theme: ThemeType) -> Theme:
        if theme == ThemeType.DARK:
            return Colors._DARK_THEME
        else:
            return Colors._LIGHT_THEME
