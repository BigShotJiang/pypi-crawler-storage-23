"""Utilities for controlling dotenv behavior."""

import os
import tempfile
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path

import dotenv


@contextmanager
def block_dotenv_load() -> Generator[None]:
    """
    Context manager that temporarily blocks dotenv.load_dotenv() calls.

    This is useful when importing libraries that auto-load .env at import time
    (e.g., litellm - see https://github.com/BerriAI/litellm/issues/12576).

    Usage:
        with block_dotenv_load():
            import litellm  # litellm's import-time load_dotenv() will be blocked

        dotenv.load_dotenv()  # This call works normally after the context exits
    """
    original_load_dotenv = dotenv.load_dotenv
    dotenv.load_dotenv = lambda *_args, **_kwargs: False  # type: ignore[assignment]
    try:
        yield
    finally:
        dotenv.load_dotenv = original_load_dotenv


def append_to_env_local(env_file_path: Path, key: str, value: str) -> None:
    """
    Safely append or update a key=value pair in .env.local file.

    - Creates file if missing
    - Updates existing key or appends new one
    - Preserves existing entries
    - Writes atomically via temp file + rename
    """
    env_dict: dict[str, str] = {}

    if env_file_path.exists():
        with env_file_path.open("r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env_dict[k.strip()] = v.strip()

    env_dict[key] = value

    temp_fd, temp_path = tempfile.mkstemp(dir=env_file_path.parent, text=True)
    try:
        with os.fdopen(temp_fd, "w") as f:
            for k, v in env_dict.items():
                f.write(f"{k}={v}\n")

        os.replace(temp_path, env_file_path)

        try:
            os.chmod(env_file_path, 0o600)
        except OSError:
            pass
    except Exception:
        try:
            os.unlink(temp_path)
        except OSError:
            pass
        raise
