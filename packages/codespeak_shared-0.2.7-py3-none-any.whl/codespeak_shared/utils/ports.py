import errno
import logging
import socket
from collections.abc import Callable
from typing import TypeVar

_T = TypeVar("_T")
_MAX_PORT_RETRIES = 20
_logger = logging.getLogger(__name__)


def is_port_free(port: int) -> bool:
    for host in ("", "localhost"):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((host, port))
            except OSError as e:
                if e.errno == errno.EADDRINUSE:
                    return False
                raise
    return True


def find_free_port(start_port: int, max_tries: int = 100) -> int:
    port = start_port
    for _ in range(max_tries):
        if is_port_free(port):
            return port
        else:
            port += 1
    raise RuntimeError(f"No free port found in range {start_port} to {port - 1}")


def verify_free_port(port: int) -> bool:
    return find_free_port(port) == port


def try_port_range(
    start_port: int, bind_fn: Callable[[int], _T], server_name: str, max_retries: int = _MAX_PORT_RETRIES
) -> tuple[_T, int]:
    for attempt in range(max_retries):
        port = start_port + attempt
        try:
            result = bind_fn(port)
            if attempt > 0:
                _logger.info(f"{server_name} started on port {port}")
            return result, port
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                _logger.warning(f"Port {port} is busy, trying next port")
                continue
            raise
    raise OSError(errno.EADDRINUSE, f"No free port found in range {start_port}–{start_port + max_retries - 1}")


def occupy_port(port: int) -> list[socket.socket]:
    sockets: list[socket.socket] = []

    # Bind to localhost IPv6
    sock_ipv6 = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
    sock_ipv6.bind(("::1", port))
    sock_ipv6.listen(1)
    sockets.append(sock_ipv6)

    # Bind to localhost IPv4
    sock_ipv4 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock_ipv4.bind(("127.0.0.1", port))
    sock_ipv4.listen(1)
    sockets.append(sock_ipv4)
    return sockets
