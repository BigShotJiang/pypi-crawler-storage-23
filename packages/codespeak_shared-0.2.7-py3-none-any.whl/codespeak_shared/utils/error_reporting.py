from rich.console import Console
from rich.traceback import Traceback as RichTraceback

from codespeak_shared.exceptions import (
    CodespeakInternalError,
    RunCancelledInternalError,
    RunCancelledUserError,
)
from codespeak_shared.progress.rich_progress_output import rich_traceback_from_stack_frames
from codespeak_shared.shared_feature_flags import SharedFeatureFlags


def print_stack_trace_if_enabled(
    exception: BaseException,
    console: Console,
    feature_flags: SharedFeatureFlags,
) -> None:
    if not feature_flags.get_flag_value(SharedFeatureFlags.PRINT_STACKTRACE_ON_FAILURE):
        return

    if isinstance(exception, (RunCancelledUserError, RunCancelledInternalError)):
        tb = rich_traceback_from_stack_frames(
            exception.request_traceback,
            show_locals=feature_flags.get_flag_value(SharedFeatureFlags.SHOW_LOCALS_IN_STACKTRACE),
            width=console.size.width,
            code_width=console.size.width,
            extra_lines=2,
        )
        console.print(tb)
        return

    if exception.__traceback__:
        tb: RichTraceback = RichTraceback.from_exception(
            type(exception),
            exception,
            exception.__traceback__,
            show_locals=feature_flags.get_flag_value(SharedFeatureFlags.SHOW_LOCALS_IN_STACKTRACE),
            width=console.size.width,
            code_width=console.size.width,
            extra_lines=2,
        )
        console.print(tb)
    elif isinstance(exception, CodespeakInternalError) and exception.server_stack_trace:
        console.print("[dim]Server stack trace:[/dim]")
        console.print(exception.server_stack_trace, highlight=True)
