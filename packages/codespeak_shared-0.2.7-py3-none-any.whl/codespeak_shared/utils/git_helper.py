"""Shared git helper for project initialization and basic git operations."""

import logging
from pathlib import Path

from codespeak_shared.os_environment import OsEnvironment
from codespeak_shared.project_path import ProjectPath
from codespeak_shared.utils.process_util import run_child_process_sync


class SharedGitHelper:
    """A helper class for basic git operations used during project initialization."""

    CODESPEAK_AUTHOR_NAME = "CodeSpeak"
    CODESPEAK_AUTHOR_EMAIL = "gen@codespeak.dev"
    CODESPEAK_AUTHOR = f"{CODESPEAK_AUTHOR_NAME} <{CODESPEAK_AUTHOR_EMAIL}>"

    @classmethod
    def git_user_config_args(cls) -> list[str]:
        """Return git -c args for setting committer identity."""
        return ["-c", f"user.name={cls.CODESPEAK_AUTHOR_NAME}", "-c", f"user.email={cls.CODESPEAK_AUTHOR_EMAIL}"]

    def __init__(self, os_environment: OsEnvironment):
        super().__init__()
        self._os_env = os_environment
        self._logger = logging.getLogger(self.__class__.__qualname__)

    def _run_command(self, command: list[str], redirect_output_to_file: str | None = None) -> tuple[int, str, str]:
        result = self._os_env.run_child_process(
            args=command,
            cwd=ProjectPath.from_string("."),
            timeout=300.0,
            check=False,
            redirected_output_path=ProjectPath.from_string(redirect_output_to_file)
            if redirect_output_to_file
            else None,
        )
        return result.exit_code, result.stdout, result.stderr

    def _run_command_and_assert(
        self,
        command: list[str],
        command_str: str | None = None,
        redirect_output_to_file: str | None = None,
        strip: bool = True,
    ) -> str:
        exit_code, stdout, stderr = self._run_command(command, redirect_output_to_file)
        if exit_code != 0:
            raise RuntimeError(
                f"Command '{command_str if command_str else ' '.join(command)}' exit code {exit_code}, stdout: [{stdout}], stderr: [{stderr}]"
            )

        result = stdout
        if strip:
            result = result.strip()
        return result

    def create_repo(self) -> str:
        """Create a new git repository with 'main' as the initial branch."""
        return self._run_command_and_assert(["git", "init", "--initial-branch=main"], "create repo")

    def add_files(self, file_paths: list[str]) -> None:
        """Stage files for commit."""
        self._run_command_and_assert(["git", "add"] + file_paths)

    def commit_files(self, title: str, description: str, files: list[str]) -> None:
        """Commit staged files with a message using CodeSpeak identity."""
        if len(files) == 0:
            return
        self._run_command_and_assert(
            ["git"] + self.git_user_config_args() + ["commit", "-m", title, "-m", description] + files
        )

    def is_user_configured(self) -> bool:
        """Check if git user.name and user.email are configured."""
        name_code, name_stdout, _ = self._run_command(["git", "config", "user.name"])
        email_code, email_stdout, _ = self._run_command(["git", "config", "user.email"])
        return name_code == 0 and bool(name_stdout.strip()) and email_code == 0 and bool(email_stdout.strip())

    @staticmethod
    def get_git_repo_root() -> Path | None:
        """
        Returns an absolute path to the root of the git repository, or None if not a git repository.
        """
        exit_code, stdout, _ = run_child_process_sync(
            args=["git", "rev-parse", "--show-toplevel"], cwd=".", check=False, timeout=60
        )
        if exit_code != 0:
            return None
        return Path(stdout.strip())
