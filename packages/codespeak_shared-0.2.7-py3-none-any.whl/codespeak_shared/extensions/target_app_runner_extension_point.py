"""Extension point for running target applications."""

from abc import ABC, abstractmethod
from typing import Any

from codespeak_shared.codespeak_project import CodeSpeakProject
from codespeak_shared.extensions.extension_point import ExtensionPoint
from codespeak_shared.progress.output_services import OutputServices

EXTENSION_GROUP = "codespeak.target_app_runner"


@ExtensionPoint(EXTENSION_GROUP)
class TargetAppRunnerExtensionPoint(ABC):
    """Extension point for running target applications.

    Implementations provide different ways to run target applications based on
    project state (e.g., Django server, Node.js server, console app).

    Extensions are registered in pyproject.toml:
        [project.entry-points."codespeak.target_app_runner"]
        django = "codespeak.lang_support.python.django_runner:DjangoRunnerExtension"
    """

    @abstractmethod
    def supports(self, state: dict[str, Any]) -> bool:
        """Return True if this runner can handle the given state.

        Args:
            state: Project state dictionary containing criteria and other build state.

        Returns:
            True if this runner can handle the project, False otherwise.
        """
        ...

    @abstractmethod
    def run_target_app(
        self,
        project: CodeSpeakProject,
        state: dict[str, Any],
        output_services: OutputServices,
    ) -> str | None:
        """Run the target application.

        Args:
            project: The project to run.
            state: Project state dictionary.
            output_services: Services for output and progress reporting.

        Returns:
            None on success, error message string on failure.
        """
        ...
