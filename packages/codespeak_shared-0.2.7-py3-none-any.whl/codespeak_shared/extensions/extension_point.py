from typing import TypeVar

T = TypeVar("T")

EXTENSION_POINT_GROUP_ATTR = "_extension_point_group"

# Registry mapping group names to their extension point classes
_extension_point_registry: dict[str, type] = {}


class ExtensionPoint:
    """
    Decorator that marks a class as an extension point.

    An extension point is an interface (typically an ABC) that can have multiple
    implementations discovered and loaded via Python's entry points mechanism.

    Usage:
        @ExtensionPoint("my.extension.group")
        class MyInterface(ABC):
            @abstractmethod
            def process(self, data: str) -> str:
                ...

    Extensions are registered in pyproject.toml:
        [project.entry-points."my.extension.group"]
        my_extension = "my_package.module:MyExtensionClass"
    """

    def __init__(self, group: str) -> None:
        """
        Args:
            group: The entry point group name used to discover extensions.
                   By convention, use a dotted name like "myapp.extensions.processors"
        """
        self._group = group

    def __call__(self, cls: type[T]) -> type[T]:
        """Apply the decorator to the class."""
        setattr(cls, EXTENSION_POINT_GROUP_ATTR, self._group)
        _extension_point_registry[self._group] = cls
        return cls


def get_extension_point_group(cls: type) -> str | None:
    """Get the extension point group name from a decorated class."""
    return getattr(cls, EXTENSION_POINT_GROUP_ATTR, None)


def get_all_extension_points() -> dict[str, type]:
    """Get all registered extension points as a dict mapping group name to class."""
    return _extension_point_registry.copy()
