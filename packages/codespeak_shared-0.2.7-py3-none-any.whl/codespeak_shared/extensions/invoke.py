from collections.abc import Callable
from importlib.metadata import entry_points
from typing import TypeVar

from codespeak_shared.extensions.extension_point import get_extension_point_group

E = TypeVar("E")
T = TypeVar("T")


class ExtensionLoadError(Exception):
    """Raised when an extension fails to load or validate."""

    def __init__(self, entry_point_name: str, group: str, message: str) -> None:
        super().__init__(f"Failed to load extension '{entry_point_name}' from group '{group}': {message}")
        self.entry_point_name = entry_point_name
        self.group = group


class DuplicateExtensionNameError(Exception):
    """Raised when multiple extensions have the same name within an extension point."""

    def __init__(self, name: str, group: str) -> None:
        super().__init__(f"Duplicate extension name '{name}' in group '{group}'")
        self.name = name
        self.group = group


class ExtensionNotFoundError(Exception):
    """Raised when a requested extension is not found."""

    def __init__(self, name: str, group: str) -> None:
        super().__init__(f"Extension '{name}' not found in group '{group}'")
        self.name = name
        self.group = group


def _get_group_or_raise(extension_point: type[E]) -> str:
    group = get_extension_point_group(extension_point)
    if group is None:
        raise ValueError(
            f"Class {extension_point.__name__} is not decorated with @ExtensionPoint. "
            f"Add @ExtensionPoint('group.name') decorator to the class."
        )
    return group


def _load_extensions(extension_point: type[E], group: str) -> dict[str, E]:
    """Load all extensions for a group, validating unique names."""
    extensions: dict[str, E] = {}
    discovered_entry_points = entry_points(group=group)

    for ep in discovered_entry_points:
        if ep.name in extensions:
            raise DuplicateExtensionNameError(ep.name, group)

        try:
            extension_class = ep.load()
        except Exception as e:
            raise ExtensionLoadError(ep.name, group, f"failed to import: {e}") from e

        if not isinstance(extension_class, type):
            raise ExtensionLoadError(ep.name, group, f"expected a class, got {type(extension_class).__name__}")

        if not issubclass(extension_class, extension_point):
            raise ExtensionLoadError(
                ep.name, group, f"class {extension_class.__name__} does not implement {extension_point.__name__}"
            )

        try:
            instance: E = extension_class()
        except Exception as e:
            raise ExtensionLoadError(ep.name, group, f"failed to instantiate: {e}") from e

        extensions[ep.name] = instance

    return extensions


def invoke_extensions(extension_point: type[E], func: Callable[[E], T]) -> list[T]:
    """
    Discover all implementations of an extension point and invoke a function on each.

    This function uses Python's entry points mechanism to discover all registered
    extensions for the given extension point, instantiates each one, and invokes
    the provided function on each instance.

    Args:
        extension_point: A class decorated with @ExtensionPoint that defines the
                         interface extensions must implement.
        func: A callable that receives an instance of the extension point interface
              and returns a value of type T.

    Returns:
        A list containing the return value from invoking func on each discovered
        extension instance. The order is not guaranteed.

    Raises:
        ValueError: If the extension_point class is not decorated with @ExtensionPoint.
        ExtensionLoadError: If an extension fails to load, instantiate, or doesn't
                           implement the extension point interface.
        DuplicateExtensionNameError: If multiple extensions have the same name.

    Usage:
        @ExtensionPoint("myapp.processors")
        class Processor(ABC):
            @abstractmethod
            def process(self, data: str) -> str:
                ...

        # Discover all processors and invoke process() on each
        results = invoke_extensions(
            Processor,
            lambda p: p.process("hello")
        )
        # results: list[str] containing output from each processor
    """
    group = _get_group_or_raise(extension_point)
    extensions = _load_extensions(extension_point, group)
    return [func(ext) for ext in extensions.values()]


def get_extensions(extension_point: type[E]) -> dict[str, E]:
    """
    Discover and instantiate all implementations of an extension point.

    Args:
        extension_point: A class decorated with @ExtensionPoint that defines the
                         interface extensions must implement.

    Returns:
        A dictionary mapping extension names to their instances.

    Raises:
        ValueError: If the extension_point class is not decorated with @ExtensionPoint.
        ExtensionLoadError: If an extension fails to load, instantiate, or doesn't
                           implement the extension point interface.
        DuplicateExtensionNameError: If multiple extensions have the same name.
    """
    group = _get_group_or_raise(extension_point)
    return _load_extensions(extension_point, group)


def get_extension_by_name(extension_point: type[E], name: str) -> E:
    """
    Get a specific extension by name.

    Args:
        extension_point: A class decorated with @ExtensionPoint that defines the
                         interface extensions must implement.
        name: The name of the extension to retrieve.

    Returns:
        The extension instance.

    Raises:
        ValueError: If the extension_point class is not decorated with @ExtensionPoint.
        ExtensionNotFoundError: If no extension with the given name exists.
        ExtensionLoadError: If the extension fails to load or instantiate.
        DuplicateExtensionNameError: If multiple extensions have the same name.
    """
    group = _get_group_or_raise(extension_point)
    extensions = _load_extensions(extension_point, group)

    if name not in extensions:
        raise ExtensionNotFoundError(name, group)

    return extensions[name]
