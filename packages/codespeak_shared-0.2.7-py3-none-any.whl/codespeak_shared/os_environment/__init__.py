# NOTE: We don't import grpc_server.create_server or RemoteOsEnvironment here
# to avoid loading gRPC at module import time. Import them directly when needed:
#   from build_server.grpc_server import create_server
#   from build_server.remote_environment import RemoteOsEnvironment

from codespeak_shared.os_environment.local_environment import LocalOsEnvironment
from codespeak_shared.os_environment.os_environment import (
    ChildProcessResult,
    EntryAttributes,
    ExistsWithLastModifiedTimestamp,
    FileNotFoundException,
    FileState,
    FileStateExpectationNotMet,
    Missing,
    OsEnvironment,
    OsEnvironmentException,
    ReadFileResult,
)

__all__ = [
    "ChildProcessResult",
    "EntryAttributes",
    "ExistsWithLastModifiedTimestamp",
    "FileNotFoundException",
    "FileState",
    "FileStateExpectationNotMet",
    "LocalOsEnvironment",
    "Missing",
    "OsEnvironment",
    "OsEnvironmentException",
    "ReadFileResult",
]
