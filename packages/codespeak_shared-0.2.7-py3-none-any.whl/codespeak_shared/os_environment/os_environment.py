import stat
from abc import ABC, abstractmethod
from collections.abc import Callable
from enum import Enum
from pathlib import Path

from pydantic import BaseModel

from codespeak_shared.project_path import ProjectPath
from codespeak_shared.utils.process_util import OutputType


class GrepOutputMode(Enum):
    FILES_WITH_MATCHES = "files_with_matches"
    CONTENT = "content"
    COUNT = "count"


class DjangoServerRunMode(Enum):
    INTERACTIVE = "interactive"
    SHUTDOWN_WHEN_READY = "shutdown_when_ready"


class GrepMatch(BaseModel):
    file_path: str
    line_number: int
    line_content: str


class GrepFileCount(BaseModel):
    file_path: str
    match_count: int


class GrepResult(BaseModel):
    matching_files: list[str] = []
    matches: list[GrepMatch] = []
    file_counts: list[GrepFileCount] = []


class TreeEntry(BaseModel):
    path: str
    is_directory: bool


class EntryAttributes(BaseModel):
    last_modified: float
    size: int
    mode: int
    nlink: int
    user_name: str
    group_name: str

    @property
    def is_directory(self) -> bool:
        return stat.S_ISDIR(self.mode)


class ReadFileResult(BaseModel):
    content: str
    attributes: EntryAttributes


class ChildProcessResult(BaseModel):
    exit_code: int
    stdout: str
    stderr: str


class FileState(BaseModel):
    """Base class for file state expectations."""

    pass


class Missing(FileState):
    """Expects that the file does not exist."""

    pass


class ExistsWithLastModifiedTimestamp(FileState):
    """Expects that the file exists with a specific last modified timestamp."""

    timestamp: float


class OsEnvironmentException(Exception):
    pass


class FileNotFoundException(OsEnvironmentException):
    """Raised when a file or directory is not found."""

    pass


class MaxFileSizeExceededException(OsEnvironmentException):
    def __init__(self, file_size: int, max_allowed_size: int):
        self.file_size = file_size
        self.max_allowed_size = max_allowed_size
        super().__init__(f"File size ({file_size} bytes) exceeds maximum allowed size ({max_allowed_size} bytes)")


class FileStateExpectationNotMet(OsEnvironmentException):
    """Raised when the file state doesn't match the expected state."""

    pass


class ClientResponseTooBig(OsEnvironmentException):
    def __init__(self, response_size: int, max_allowed_size: int, message: str | None = None):
        self.response_size = response_size
        self.max_allowed_size = max_allowed_size
        if message is None:
            response_size_mb = response_size / (1024 * 1024)
            max_allowed_size_mb = max_allowed_size / (1024 * 1024)
            message = (
                f"Server response size ({response_size_mb:.1f} MB) exceeds the limit of {max_allowed_size_mb:.0f} MB"
            )
        super().__init__(message)


class ChildProcessFailedToStartException(OsEnvironmentException):
    """Raised when a child process fails to start (e.g., cwd doesn't exist, executable not found)."""

    pass


class ChildProcessTimedOutException(OsEnvironmentException):
    """Raised when a child process times out."""

    def __init__(self, message: str, stdout: str = "", stderr: str = ""):
        super().__init__(message)
        self.stdout = stdout
        self.stderr = stderr


class OsEnvironment(ABC):
    """
    This class abstracts Operating System access: filesystem and network.
    Implementation can be either local or remote.

    Since filesystem paths are generally non-transferable,
    they must be relative to the root of the environment.

    All underlying exceptions (e.g. file not accessible) are raised as OsEnvironmentException.
    """

    @abstractmethod
    def get_attributes(self, project_path: ProjectPath) -> EntryAttributes:
        pass

    def read_file(self, project_path: ProjectPath) -> str:
        content, _, _ = self.read_file_ex(project_path)
        return content

    @abstractmethod
    def read_file_ex(
        self,
        project_path: ProjectPath,
        *,
        max_allowed_file_size_bytes: int = 20 * 1024 * 1024,
        offset_line: int | None = None,
        limit_lines: int | None = None,
    ) -> tuple[str, EntryAttributes, bool]:
        """Read file content with optional line offset and limit.

        Returns:
            Tuple of (content, attributes, truncated).
            truncated is True if the content was truncated due to limit_lines.

        Raises:
            MaxFileSizeExceededException: If file size exceeds max_allowed_file_size_bytes.
        """
        pass

    @abstractmethod
    def write_file(self, project_path: ProjectPath, content: str, *, expected_state: FileState | None = None) -> float:
        pass

    @abstractmethod
    def append_to_file(
        self, project_path: ProjectPath, content: str, *, expected_state: FileState | None = None
    ) -> float:
        pass

    @abstractmethod
    def mkdirs(self, project_path: ProjectPath) -> None:
        pass

    @abstractmethod
    def is_file(self, project_path: ProjectPath) -> bool:
        pass

    @abstractmethod
    def is_directory(self, project_path: ProjectPath) -> bool:
        pass

    @abstractmethod
    def exists(self, project_path: ProjectPath) -> bool:
        pass

    @abstractmethod
    def copy(self, source_path: ProjectPath, dest_path: ProjectPath) -> None:
        pass

    @abstractmethod
    def delete_recursively(self, project_path: ProjectPath) -> None:
        pass

    @abstractmethod
    def delete_file(self, project_path: ProjectPath) -> None:
        pass

    @abstractmethod
    def list_directory(self, project_path: ProjectPath) -> list[str]:
        """List all entries (files and directories) in a directory.
        Returns a list of entry names (not full paths)."""
        pass

    @abstractmethod
    def glob(self, pattern: str, path: ProjectPath | None = None) -> list[ProjectPath]:
        """Find all paths matching the glob pattern.

        Args:
            pattern: Glob pattern relative to search path.
            path: Optional directory to search in. If None, uses environment root.

        Returns:
            List of relative paths that match the pattern.
        """
        pass

    @abstractmethod
    def grep(
        self,
        pattern: str,
        *,
        path: ProjectPath | None = None,
        glob_filter: str | None = None,
        output_mode: GrepOutputMode = GrepOutputMode.FILES_WITH_MATCHES,
        context_before: int | None = None,
        context_after: int | None = None,
        context_both: int | None = None,
        show_line_numbers: bool = True,
        case_insensitive: bool = False,
        file_type: str | None = None,
        head_limit: int | None = None,
        offset: int | None = None,
        multiline: bool = False,
    ) -> GrepResult:
        """Search for pattern in files using ripgrep.

        Args:
            pattern: Regex pattern to search for.
            path: File or directory to search in. Defaults to root.
            glob_filter: Glob pattern to filter files.
            output_mode: What to return (files, content, or counts).
            context_before: Lines of context before each match.
            context_after: Lines of context after each match.
            context_both: Lines of context before and after.
            show_line_numbers: Include line numbers in content output.
            case_insensitive: Case insensitive search.
            file_type: Filter by file type (e.g., "py", "js").
            head_limit: Limit number of results.
            offset: Skip first N results.
            multiline: Enable multiline matching.

        Returns:
            GrepResult with matches based on output_mode.
        """
        pass

    @abstractmethod
    def resolve_user_name(self) -> str:
        """Resolve the current user name.
        Returns the user name or UID as a string if the name cannot be resolved."""
        pass

    @abstractmethod
    def run_child_process(
        self,
        args: list[str],
        cwd: ProjectPath,
        timeout: float,
        check: bool,
        redirected_output_path: ProjectPath | None = None,
        shell: bool = False,
        output_limit_chars: int | None = None,
        interactive_mode: bool = False,
        add_distribution_bin: bool = False,
    ) -> ChildProcessResult:
        """Run a child process and wait for it to complete.

        Args:
            args: Command and arguments to run (e.g., ['git', '--version']).
            cwd: Working directory for the process.
            timeout: Maximum time in seconds to wait for completion (ignored in interactive_mode).
            check: If True, raise OsEnvironmentException on non-zero exit code.
            redirected_output_path: Optional path to redirect stdout to a file.
            shell: If True, run the command through the shell.
            output_limit_chars: If specified, truncates stdout/stderr to this many characters.
            interactive_mode: If True, connects stdin/stdout/stderr directly to the terminal
                instead of capturing. Used for interactive processes (e.g., Django dev server,
                console apps). When enabled, timeout is ignored and output is not captured.
            add_distribution_bin: If True, prepends the directory containing the current
                Python interpreter to PATH. This makes bundled dependency entry points
                (e.g., rg from ripgrep) discoverable when installed via uv tool install.

        Returns:
            ChildProcessResult containing exit_code, stdout, and stderr.
            In interactive_mode, stdout and stderr will be empty strings.

        Raises:
            ChildProcessFailedToStartException: If the process failed to start.
                This includes cases where the executable is not found.
            ChildProcessTimedOutException: If the process did not complete within
                the timeout period (not raised in interactive_mode).
            OsEnvironmentException: If check=True and the process exits with non-zero code.
        """
        pass

    @abstractmethod
    def resolve_path(self, project_path: ProjectPath) -> Path:
        pass

    @abstractmethod
    def traverse(
        self,
        prune_dirnames: set[str],
        skip_file_basenames: set[str],
        required_extension: str,
    ) -> list[ProjectPath]:
        """Traverse the directory tree starting from the environment root.

        Args:
            prune_dirnames: Set of directory names to skip during traversal
            skip_file_basenames: Set of file basenames to skip
            required_extension: File extension to filter by (e.g., '.py')

        Returns:
            List of relative paths to files matching the criteria
        """
        pass

    # Default limit for list_tree entries
    DEFAULT_MAX_ENTRIES = 10000

    @abstractmethod
    def list_tree(
        self,
        path: ProjectPath | None = None,
        max_depth: int | None = None,
        max_entries: int | None = None,
    ) -> tuple[list[TreeEntry], bool]:
        """List all entries in a directory tree.

        Args:
            path: Directory to list. If None, lists from environment root.
            max_depth: Maximum depth to traverse. If None, no limit.
            max_entries: Maximum number of entries to return. Defaults to DEFAULT_MAX_ENTRIES.

        Returns:
            Tuple of (entries, truncated) where entries is a list of TreeEntry objects
            sorted for tree building (parents before children), and truncated indicates
            if the results were limited by max_entries.
        """
        pass

    @abstractmethod
    def run_django_dev_server(
        self,
        server_readiness_timeout: int,
        run_mode: DjangoServerRunMode,
        output_printer: Callable[[str, OutputType], None] | None,
    ) -> tuple[bool, str | None]:
        """Start Django development server, wait until ready, then keep running until interrupted.

        This method blocks until the server exits or is interrupted by the user (Ctrl+C),
        unless run_mode is SHUTDOWN_WHEN_READY in which case it shuts down after verifying the server started.

        In INTERACTIVE mode, the browser is automatically opened when the server is ready.

        Args:
            server_readiness_timeout: Maximum time to wait for server to become ready
            run_mode: Whether to run interactively or shutdown when ready (for testing)
            output_printer: Callback for output lines when in interactive mode.

        Returns:
            Tuple of (success, error_output):
            - success: True if server started successfully
            - error_output: Error output if failed to start, None if successful
        """
        pass

    def test_django_dev_server_starts(self, server_readiness_timeout: int) -> tuple[bool, str | None]:
        """Start Django development server, test if it starts successfully, then shut it down.

        This is a convenience method that calls run_django_dev_server with run_mode=SHUTDOWN_WHEN_READY.

        Args:
            server_readiness_timeout: Maximum time to wait for server to start

        Returns:
            Tuple of (success, error_output):
            - success: True if server started successfully
            - error_output: Error output if failed, None if successful
        """
        return self.run_django_dev_server(
            server_readiness_timeout=server_readiness_timeout,
            run_mode=DjangoServerRunMode.SHUTDOWN_WHEN_READY,
            output_printer=None,
        )
