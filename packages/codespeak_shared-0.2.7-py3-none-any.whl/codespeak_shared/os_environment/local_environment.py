import grp
import logging
import os
import pwd
import selectors
import shutil
import stat
import subprocess
import sys
import time
import webbrowser
from collections.abc import Callable
from pathlib import Path

import requests
from requests.exceptions import RequestException

from codespeak_shared.os_environment.os_environment import (
    ChildProcessFailedToStartException,
    ChildProcessResult,
    ChildProcessTimedOutException,
    DjangoServerRunMode,
    EntryAttributes,
    ExistsWithLastModifiedTimestamp,
    FileNotFoundException,
    FileState,
    FileStateExpectationNotMet,
    GrepFileCount,
    GrepMatch,
    GrepOutputMode,
    GrepResult,
    MaxFileSizeExceededException,
    Missing,
    OsEnvironment,
    OsEnvironmentException,
    TreeEntry,
)
from codespeak_shared.project_path import ProjectPath
from codespeak_shared.utils.ports import find_free_port
from codespeak_shared.utils.process_util import OutputType, kill_child_process, run_child_process_sync
from codespeak_shared.utils.type_utils import nn


class LocalOsEnvironment(OsEnvironment):
    def __init__(self, root: Path):
        self._root = root.resolve()
        self._logger = logging.getLogger(LocalOsEnvironment.__name__)

    def resolve_path(self, project_path: ProjectPath) -> Path:
        path = project_path.get_underlying_path()

        if path.is_absolute():
            resolved = path.resolve()
        else:
            resolved = (self._root / path).resolve()

        # Check that resolved path is within root (protects against path traversal)
        if not resolved.is_relative_to(self._root.resolve()):
            raise OsEnvironmentException(f"Path traversal not allowed: {project_path} resolves outside root")

        return resolved

    @staticmethod
    def _resolve_user_name(uid: int) -> str:
        try:
            return pwd.getpwuid(uid).pw_name
        except KeyError:
            return str(uid)

    @staticmethod
    def _resolve_group_name(gid: int) -> str:
        try:
            return grp.getgrgid(gid).gr_name
        except KeyError:
            return str(gid)

    @staticmethod
    def _stat_to_attributes(stat_result: os.stat_result, user_name: str, group_name: str) -> EntryAttributes:
        return EntryAttributes(
            last_modified=stat_result.st_mtime,
            size=stat_result.st_size,
            mode=stat_result.st_mode,
            nlink=stat_result.st_nlink,
            user_name=user_name,
            group_name=group_name,
        )

    @staticmethod
    def _verify_expected_state(path: Path, expected_state: FileState | None) -> None:
        if expected_state is None:
            return

        try:
            current_stat = path.stat()
            actual_state = ExistsWithLastModifiedTimestamp(timestamp=current_stat.st_mtime)
        except FileNotFoundError:
            actual_state = Missing()

        if expected_state != actual_state:
            match (expected_state, actual_state):
                case (Missing(), ExistsWithLastModifiedTimestamp(timestamp=actual_ts)):
                    raise FileStateExpectationNotMet(
                        f"Expected file to be missing, but it exists with last modified timestamp {actual_ts}"
                    )
                case (ExistsWithLastModifiedTimestamp(timestamp=expected_ts), Missing()):
                    raise FileStateExpectationNotMet(
                        f"Expected file to exist with last modified timestamp {expected_ts}, but file is missing"
                    )
                case (
                    ExistsWithLastModifiedTimestamp(timestamp=expected_ts),
                    ExistsWithLastModifiedTimestamp(timestamp=actual_ts),
                ):
                    raise FileStateExpectationNotMet(
                        f"File timestamp mismatch: expected {expected_ts}, actual {actual_ts}"
                    )
                case _:
                    raise ValueError(f"Expected state: {expected_state}, actual state: {actual_state}")

    def get_attributes(self, project_path: ProjectPath) -> EntryAttributes:
        try:
            path = self.resolve_path(project_path)
            stat_result = path.stat()
            user_name = self._resolve_user_name(stat_result.st_uid)
            group_name = self._resolve_group_name(stat_result.st_gid)
            return self._stat_to_attributes(stat_result, user_name, group_name)
        except FileNotFoundError as e:
            raise FileNotFoundException(f"File not found: {project_path}") from e
        except OSError as e:
            raise OsEnvironmentException(f"Failed to get attributes for {project_path}") from e

    def read_file_ex(
        self,
        project_path: ProjectPath,
        *,
        max_allowed_file_size_bytes: int = 20 * 1024 * 1024,
        offset_line: int | None = None,
        limit_lines: int | None = None,
    ) -> tuple[str, EntryAttributes, bool]:
        if offset_line is not None and offset_line < 1:
            raise OsEnvironmentException(f"offset_line must be >= 1, got {offset_line}")
        if limit_lines is not None and limit_lines <= 0:
            raise OsEnvironmentException(f"limit_lines must be positive, got {limit_lines}")

        try:
            path = self.resolve_path(project_path)
            stat_result = path.stat()

            if stat.S_ISDIR(stat_result.st_mode):
                raise OsEnvironmentException(f"Path is a directory: {project_path}")

            if stat_result.st_size > max_allowed_file_size_bytes:
                raise MaxFileSizeExceededException(
                    file_size=stat_result.st_size, max_allowed_size=max_allowed_file_size_bytes
                )

            content = path.read_text(encoding="utf-8", errors="replace")
            truncated = False

            # Apply offset and limit if specified
            if offset_line is not None or limit_lines is not None:
                lines = content.splitlines(keepends=True)
                start_line = (offset_line - 1) if offset_line is not None else 0
                if limit_lines is not None:
                    end_line = start_line + limit_lines
                    # Check if we're truncating
                    if end_line < len(lines):
                        truncated = True
                    lines = lines[start_line:end_line]
                else:
                    lines = lines[start_line:]
                content = "".join(lines)

            user_name = self._resolve_user_name(stat_result.st_uid)
            group_name = self._resolve_group_name(stat_result.st_gid)
            attributes = self._stat_to_attributes(stat_result, user_name, group_name)
            return content, attributes, truncated
        except FileNotFoundError as e:
            raise FileNotFoundException(f"File not found: {project_path}") from e
        except OSError as e:
            raise OsEnvironmentException(f"Failed to read file {project_path}") from e

    def write_file(self, project_path: ProjectPath, content: str, *, expected_state: FileState | None = None) -> float:
        try:
            path = self.resolve_path(project_path)

            self._verify_expected_state(path, expected_state)

            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")

            updated_stat = path.stat()
            return updated_stat.st_mtime
        except FileNotFoundError as e:
            raise FileNotFoundException(f"File not found: {project_path}") from e
        except OSError as e:
            raise OsEnvironmentException(f"Failed to write file {project_path}") from e

    def append_to_file(
        self, project_path: ProjectPath, content: str, *, expected_state: FileState | None = None
    ) -> float:
        try:
            path = self.resolve_path(project_path)

            self._verify_expected_state(path, expected_state)

            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as f:
                f.write(content)

            updated_stat = path.stat()
            return updated_stat.st_mtime
        except FileNotFoundError as e:
            raise FileNotFoundException(f"File not found: {project_path}") from e
        except OSError as e:
            raise OsEnvironmentException(f"Failed to append to file {project_path}") from e

    def mkdirs(self, project_path: ProjectPath) -> None:
        try:
            path = self.resolve_path(project_path)
            path.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise OsEnvironmentException(f"Failed to create directory {project_path}") from e

    def is_file(self, project_path: ProjectPath) -> bool:
        try:
            path = self.resolve_path(project_path)
            return path.is_file()
        except OSError as e:
            raise OsEnvironmentException(f"Failed to check if {project_path} is a file") from e

    def is_directory(self, project_path: ProjectPath) -> bool:
        try:
            path = self.resolve_path(project_path)
            return path.is_dir()
        except OSError as e:
            raise OsEnvironmentException(f"Failed to check if {project_path} is a directory") from e

    def exists(self, project_path: ProjectPath) -> bool:
        try:
            path = self.resolve_path(project_path)
            return path.exists()
        except OSError as e:
            raise OsEnvironmentException(f"Failed to check if {project_path} exists") from e

    def copy(self, source_path: ProjectPath, dest_path: ProjectPath) -> None:
        try:
            src = self.resolve_path(source_path)
            dst = self.resolve_path(dest_path)

            if not src.exists():
                raise FileNotFoundException(f"Source file not found: {source_path}")
            if src.is_dir():
                raise OsEnvironmentException(f"Source is a directory: {source_path}")

            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(src, dst)
        except OSError as e:
            raise OsEnvironmentException(f"Failed to copy {source_path} to {dest_path}") from e

    def delete_recursively(self, project_path: ProjectPath) -> None:
        try:
            path = self.resolve_path(project_path)

            if not path.exists():
                return

            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
        except OSError as e:
            raise OsEnvironmentException(f"Failed to delete {project_path}") from e

    def delete_file(self, project_path: ProjectPath) -> None:
        try:
            path = self.resolve_path(project_path)

            if path.is_dir():
                raise OsEnvironmentException(f"Path is a directory: {project_path}")

            path.unlink(missing_ok=True)
        except OSError as e:
            raise OsEnvironmentException(f"Failed to delete file {project_path}") from e

    def list_directory(self, project_path: ProjectPath) -> list[str]:
        try:
            path = self.resolve_path(project_path)

            if not path.exists():
                raise FileNotFoundException(f"Directory not found: {project_path}")
            if not path.is_dir():
                raise OsEnvironmentException(f"Path is not a directory: {project_path}")

            return sorted(os.listdir(path))
        except OSError as e:
            raise OsEnvironmentException(f"Failed to list directory {project_path}") from e

    def glob(self, pattern: str, path: ProjectPath | None = None) -> list[ProjectPath]:
        try:
            if path is not None:
                search_root = self.resolve_path(path)
                if not search_root.is_dir():
                    raise OsEnvironmentException(f"Path is not a directory: {path}")
            else:
                search_root = self._root

            # Use Path.glob() to find matching paths
            matched_paths_generator = search_root.glob(pattern)

            # Convert absolute paths to relative paths and wrap in ProjectPath
            relative_paths: list[ProjectPath] = []
            for matched_path in matched_paths_generator:
                try:
                    relative_path = matched_path.relative_to(self._root)
                    relative_paths.append(ProjectPath.from_path(relative_path))
                except ValueError:
                    # Path is not relative to root (shouldn't happen, but be safe)
                    continue

            # Sort by modification time (newest first)
            relative_paths.sort(key=lambda p: self.resolve_path(p).stat().st_mtime, reverse=True)

            return relative_paths
        except NotImplementedError as e:
            raise OsEnvironmentException(f"Invalid glob pattern '{pattern}': must be a relative pattern") from e
        except OSError as e:
            raise OsEnvironmentException(f"Failed to glob pattern {pattern}") from e

    def grep(
        self,
        pattern: str,
        *,
        path: ProjectPath | None = None,
        glob_filter: str | None = None,
        output_mode: GrepOutputMode = GrepOutputMode.FILES_WITH_MATCHES,
        context_before: int | None = None,
        context_after: int | None = None,
        context_both: int | None = None,
        show_line_numbers: bool = True,
        case_insensitive: bool = False,
        file_type: str | None = None,
        head_limit: int | None = None,
        offset: int | None = None,
        multiline: bool = False,
    ) -> GrepResult:
        # Claude Code uses pre-built and embedded ripgrep 14.1.1, can be run via "claude --ripgrep foo"
        # For the Python client it's sufficient to require "rg" to be pre-installed for now (see RipgrepVersionParser).
        #
        # NB: CLI invocations of ripgrep can not be just translated to grep or other grep-like tools
        # (rg has some pretty major default changes, like recursive search and .gitignore handling by default)

        try:
            # Build ripgrep command
            args = ["rg", "--no-heading", "--with-filename"]

            # Output format based on mode
            if output_mode == GrepOutputMode.FILES_WITH_MATCHES:
                args.append("-l")  # files with matches
            elif output_mode == GrepOutputMode.COUNT:
                args.append("-c")  # count matches
            elif output_mode == GrepOutputMode.CONTENT:
                if show_line_numbers:
                    args.append("-n")
            else:
                raise OsEnvironmentException(f"Unknown grep output mode: {output_mode}")

            # Context lines
            if context_both is not None:
                args.extend(["-C", str(context_both)])
            else:
                if context_before is not None:
                    args.extend(["-B", str(context_before)])
                if context_after is not None:
                    args.extend(["-A", str(context_after)])

            # Other options
            if case_insensitive:
                args.append("-i")

            if multiline:
                args.extend(["-U", "--multiline-dotall"])

            if glob_filter:
                args.extend(["--glob", glob_filter])

            if file_type:
                args.extend(["--type", file_type])

            # Pattern
            args.append(pattern)

            # Search path
            search_path = self.resolve_path(path) if path else self._root
            args.append(str(search_path))

            # Run ripgrep
            env = self._prepare_env(add_distribution_bin=True)
            result = subprocess.run(
                args,
                capture_output=True,
                text=True,
                cwd=self._root,
                env=env,
            )

            # ripgrep returns exit code 1 for no matches, 0 for matches, 2 for errors
            if result.returncode == 2:
                raise OsEnvironmentException(f"Grep failed: {result.stderr}")

            # Parse output based on mode
            lines = result.stdout.strip().split("\n") if result.stdout.strip() else []

            # Apply offset and limit
            if offset:
                lines = lines[offset:]
            if head_limit:
                lines = lines[:head_limit]

            if output_mode == GrepOutputMode.FILES_WITH_MATCHES:
                # Make paths relative to root
                matching_files: list[str] = []
                for line in lines:
                    if line:
                        try:
                            abs_path = Path(line)
                            rel_path = abs_path.relative_to(self._root)
                            matching_files.append(str(rel_path))
                        except ValueError:
                            matching_files.append(line)
                return GrepResult(matching_files=matching_files)

            elif output_mode == GrepOutputMode.COUNT:
                file_counts: list[GrepFileCount] = []
                for line in lines:
                    if ":" in line:
                        file_path, count = line.rsplit(":", 1)
                        try:
                            abs_path = Path(file_path)
                            rel_path = abs_path.relative_to(self._root)
                            file_counts.append(GrepFileCount(file_path=str(rel_path), match_count=int(count)))
                        except (ValueError, TypeError):
                            pass
                return GrepResult(file_counts=file_counts)

            elif output_mode == GrepOutputMode.CONTENT:
                matches: list[GrepMatch] = []
                for line in lines:
                    # Parse "file:line:content" format
                    parts = line.split(":", 2)
                    if len(parts) >= 3:
                        file_path, line_num, content = parts[0], parts[1], parts[2]
                        try:
                            abs_path = Path(file_path)
                            rel_path = abs_path.relative_to(self._root)
                            matches.append(
                                GrepMatch(file_path=str(rel_path), line_number=int(line_num), line_content=content)
                            )
                        except (ValueError, TypeError):
                            pass
                return GrepResult(matches=matches)

            else:
                raise OsEnvironmentException(f"Unknown grep output mode: {output_mode}")

        except FileNotFoundError:
            raise OsEnvironmentException("ripgrep (rg) not found. Please install ripgrep.")
        except OSError as e:
            raise OsEnvironmentException(f"Grep failed: {e}")

    def resolve_user_name(self) -> str:
        uid = os.getuid()
        try:
            return pwd.getpwuid(uid).pw_name
        except KeyError:
            # If user name cannot be resolved, return UID as string
            return str(uid)

    def run_child_process(
        self,
        args: list[str],
        cwd: ProjectPath,
        timeout: float,
        check: bool,
        redirected_output_path: ProjectPath | None = None,
        shell: bool = False,
        output_limit_chars: int | None = None,
        interactive_mode: bool = False,
        add_distribution_bin: bool = False,
    ) -> ChildProcessResult:
        if output_limit_chars is not None and output_limit_chars <= 0:
            raise OsEnvironmentException(f"output_limit_chars must be positive, got {output_limit_chars}")

        try:
            cwd_path = self.resolve_path(cwd)
            if not cwd_path.exists():
                raise ChildProcessFailedToStartException(f"Working directory not found: {cwd}")
            if not cwd_path.is_dir():
                raise ChildProcessFailedToStartException(f"Working directory is not a directory: {cwd}")

            env = self._prepare_env(add_distribution_bin=add_distribution_bin)

            if interactive_mode:
                # Interactive mode: connect stdin/stdout/stderr directly to terminal
                # Use subprocess with inherited stdio (no capture)
                process = subprocess.Popen(
                    args=args,
                    cwd=cwd_path,
                    shell=shell,
                    env=env,
                    # Don't capture - inherit from parent process
                    stdin=None,
                    stdout=None,
                    stderr=None,
                )
                try:
                    exit_code = process.wait()
                except KeyboardInterrupt:
                    process.terminate()
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        process.kill()
                    exit_code = 130  # Standard exit code for SIGINT
                return ChildProcessResult(exit_code=exit_code, stdout="", stderr="")

            # Non-interactive mode: capture output
            # Resolve redirect path if provided
            redirect_path = None
            if redirected_output_path:
                redirect_path = self.resolve_path(redirected_output_path)
                # Ensure parent directory exists
                redirect_path.parent.mkdir(parents=True, exist_ok=True)

            exit_code, stdout, stderr = run_child_process_sync(
                args=args,
                cwd=cwd_path,
                timeout=timeout,
                check=check,
                redirected_output_path=redirect_path,
                shell=shell,
                env=env,
            )

            # Apply output limit only if specified
            if output_limit_chars is not None:
                if len(stdout) > output_limit_chars:
                    stdout = (
                        stdout[:output_limit_chars]
                        + f"\n... [truncated, showing {output_limit_chars} of {len(stdout)} chars]"
                    )
                if len(stderr) > output_limit_chars:
                    stderr = (
                        stderr[:output_limit_chars]
                        + f"\n... [truncated, showing {output_limit_chars} of {len(stderr)} chars]"
                    )

            return ChildProcessResult(exit_code=exit_code, stdout=stdout, stderr=stderr)
        except subprocess.CalledProcessError as e:
            raise OsEnvironmentException(
                f"Command {args} failed with exit code {e.returncode} in {cwd}, stdout: [{e.stdout}], stderr: [{e.stderr}]"
            ) from e
        except TimeoutError as e:
            # Extract stdout/stderr from ProcessTimeoutError if available
            stdout = getattr(e, "stdout", "")
            stderr = getattr(e, "stderr", "")
            raise ChildProcessTimedOutException(f"Command {args} timed out in {cwd}", stdout, stderr) from e
        except OSError as e:
            raise ChildProcessFailedToStartException(f"Failed to run command {args} in {cwd}") from e

    def traverse(
        self,
        prune_dirnames: set[str],
        skip_file_basenames: set[str],
        required_extension: str,
    ) -> list[ProjectPath]:
        files_to_analyze: list[ProjectPath] = []

        try:
            for root, dirnames, filenames in os.walk(self._root, topdown=True):
                # Prune unwanted directories in-place
                dirnames[:] = [d for d in dirnames if d not in prune_dirnames]

                for filename in filenames:
                    if not filename.endswith(required_extension):
                        continue
                    if filename in skip_file_basenames:
                        continue

                    # Compute relative path from root
                    full_path = Path(root) / filename
                    relative_path = full_path.relative_to(self._root)
                    files_to_analyze.append(ProjectPath.from_path(relative_path))

            return files_to_analyze
        except OSError as e:
            raise OsEnvironmentException(f"Failed to traverse directory tree") from e

    def list_tree(
        self,
        path: ProjectPath | None = None,
        max_depth: int | None = None,
        max_entries: int | None = None,
    ) -> tuple[list[TreeEntry], bool]:
        effective_max_entries = max_entries if max_entries is not None else self.DEFAULT_MAX_ENTRIES

        try:
            if path is not None:
                search_root = self.resolve_path(path)
                if not search_root.exists():
                    raise FileNotFoundException(f"Directory not found: {path}")
                if not search_root.is_dir():
                    raise OsEnvironmentException(f"Path is not a directory: {path}")
            else:
                search_root = self._root

            entries: list[TreeEntry] = []
            truncated = False

            for root, dirnames, filenames in os.walk(search_root, topdown=True):
                # Calculate depth relative to search root
                rel_root = Path(root).relative_to(search_root)
                current_depth = len(rel_root.parts) if str(rel_root) != "." else 0

                # Skip this level and stop descending if we've reached max_depth
                if max_depth is not None and current_depth >= max_depth:
                    dirnames.clear()
                    continue

                # Sort for consistent ordering
                dirnames.sort()
                filenames.sort()

                # Add directories
                for dirname in dirnames:
                    if len(entries) >= effective_max_entries:
                        truncated = True
                        dirnames.clear()  # Stop descending
                        break
                    full_path = Path(root) / dirname
                    relative_path = full_path.relative_to(self._root)
                    entries.append(TreeEntry(path=str(relative_path), is_directory=True))

                if truncated:
                    break

                # Add files
                for filename in filenames:
                    if len(entries) >= effective_max_entries:
                        truncated = True
                        break
                    full_path = Path(root) / filename
                    relative_path = full_path.relative_to(self._root)
                    entries.append(TreeEntry(path=str(relative_path), is_directory=False))

                if truncated:
                    dirnames.clear()  # Stop descending
                    break

            return entries, truncated
        except OSError as e:
            raise OsEnvironmentException(f"Failed to list tree") from e

    def run_django_dev_server(
        self,
        server_readiness_timeout: int,
        run_mode: DjangoServerRunMode,
        output_printer: Callable[[str, OutputType], None] | None,
    ) -> tuple[bool, str | None]:
        if run_mode == DjangoServerRunMode.INTERACTIVE and not output_printer:
            raise OsEnvironmentException("Interactive mode requires output_printer callback")

        port = find_free_port(5678)
        args = ["uv", "run", "manage.py", "runserver", str(port)]
        if run_mode == DjangoServerRunMode.SHUTDOWN_WHEN_READY:
            args.append("--verbosity")
            args.append("3")

        accepted_status_codes = [200, 403, 302]

        server_process: subprocess.Popen[str] | None = None
        stdout_lines: list[str] = []
        stderr_lines: list[str] = []

        env = self._prepare_env()

        def format_captured_output() -> str:
            return (
                f"<STDOUT> " + "\n".join(stdout_lines) + "</STDOUT>, <STDERR> " + "\n".join(stderr_lines) + "</STDERR>"
            )

        def read_output(sel: selectors.DefaultSelector, log_with_elapsed: float | None) -> None:
            if not sel.get_map():
                return
            events = sel.select(timeout=0.1)
            for key, _ in events:
                assert server_process is not None
                data = str(key.fileobj.readline())  # pyright: ignore[reportAttributeAccessIssue, reportUnknownArgumentType, reportUnknownMemberType]
                if not data:
                    self._logger.info(f"Unregistering {'STDOUT' if key.fileobj == server_process.stdout else 'STDERR'}")
                    sel.unregister(key.fileobj)
                    continue

                output_line = data.rstrip("\n")
                if not output_line:
                    continue

                is_stderr = key.fileobj != server_process.stdout

                if is_stderr:
                    stderr_lines.append(output_line)
                else:
                    stdout_lines.append(output_line)

                # Output to callback when in interactive mode
                if run_mode == DjangoServerRunMode.INTERACTIVE:
                    output_type = OutputType.STDERR if is_stderr else OutputType.STDOUT
                    nn(output_printer)(output_line, output_type)

                # Log and collect output during startup phase
                if log_with_elapsed is not None:
                    stream_name = "STDERR" if is_stderr else "STDOUT"
                    self._logger.info(f'Received {stream_name} line: "{output_line}" after {log_with_elapsed:.2f}s')

        try:
            # In interactive mode we can just pass stdout=None, stderr=None as we're doing for the console app,
            # so server output is printed to the console. But if our server fails to start,
            # we want to have its output grabbed (to log it), so we're doing all this fancy stuff with selector.
            server_process = subprocess.Popen(
                args=args, cwd=self._root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env
            )

            # Set up selector to read stdout/stderr
            sel = selectors.DefaultSelector()
            sel.register(nn(server_process.stdout), selectors.EVENT_READ)
            sel.register(nn(server_process.stderr), selectors.EVENT_READ)

            time.sleep(0.5)  # wait for start

            start_time = time.time()

            # Poll until server is ready
            while True:
                elapsed = time.time() - start_time
                if elapsed > server_readiness_timeout:
                    error_msg = f"Server did not become ready within {server_readiness_timeout}s"
                    if run_mode == DjangoServerRunMode.SHUTDOWN_WHEN_READY:
                        error_msg = f"{error_msg}, {format_captured_output()}"
                    return False, error_msg

                exit_code = server_process.poll()
                if exit_code is not None:
                    error_msg = f"Server prematurely exited with code {exit_code}"
                    if run_mode == DjangoServerRunMode.SHUTDOWN_WHEN_READY:
                        error_msg = f"{error_msg}, {format_captured_output()}"
                    return False, error_msg

                url = f"http://localhost:{port}"
                try:
                    response = requests.get(url, allow_redirects=False, timeout=1)
                    if response.status_code in accepted_status_codes:
                        self._logger.info(f"Server ready at {url}")
                        break
                    else:
                        self._logger.info(
                            f"Request to {url} failed with status code {response.status_code}, "
                            f"response: {response.content}"
                        )
                except RequestException as e:
                    self._logger.info(f"Request to {url} failed with exception {e}")

                read_output(sel, log_with_elapsed=elapsed)
                time.sleep(0.1)

            # Server is ready

            if run_mode == DjangoServerRunMode.SHUTDOWN_WHEN_READY:
                # Server will be shut down in finally block
                return True, None

            # INTERACTIVE mode

            webbrowser.open(f"http://localhost:{port}")  # returns immediately

            try:
                # Loop indefinitely as long as the server is running
                while server_process.poll() is None:
                    read_output(sel, log_with_elapsed=None)
                    if not sel.get_map():
                        time.sleep(0.1)
            except KeyboardInterrupt:
                pass

            # Don't return output in interactive mode
            return True, None
        finally:
            if server_process and server_process.poll() is None:
                self._logger.info("Shutting down server")
                kill_child_process(server_process)

    @staticmethod
    def _prepare_env(add_distribution_bin: bool = False) -> dict[str, str]:
        env = os.environ.copy()
        env.pop("VIRTUAL_ENV", None)
        if add_distribution_bin:
            distribution_bin = str(Path(sys.executable).parent)
            env["PATH"] = distribution_bin + os.pathsep + env.get("PATH", "")
        return env
