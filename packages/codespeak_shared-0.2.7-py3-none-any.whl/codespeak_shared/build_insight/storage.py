import json
import time
from collections.abc import Callable
from enum import Enum
from pathlib import Path
from typing import Any, cast

from codespeak_shared.build_insight.events import BuildInsightEvent
from codespeak_shared.utils.type_utils import instanceof

ListenerType = Callable[[BuildInsightEvent], None]


class BuildInsightStorageMode(Enum):
    """Mode for BuildInsightStorage.

    LEADER: Assigns sequence numbers to events (for local/server-side storage)
    FOLLOWER: Expects events to have sequence numbers already assigned (for remote/client-side storage)
    """

    LEADER = "leader"
    FOLLOWER = "follower"


class BuildInsightStorage:
    storage: list[BuildInsightEvent]
    listeners: dict[type[BuildInsightEvent], list[ListenerType]]
    _sequence_counter: int
    _mode: BuildInsightStorageMode

    def __init__(self, mode: BuildInsightStorageMode):
        self.storage = []
        self.listeners = {}
        self._sequence_counter = 0
        self._mode = mode

    def report_event[T: BuildInsightEvent](self, event: T) -> T:
        if self._mode == BuildInsightStorageMode.LEADER:
            # LEADER mode: event should not have a sequence number yet
            if event.sequence_number is not None:
                raise ValueError(
                    f"Event already has sequence number {event.sequence_number}. "
                    "In LEADER mode, sequence numbers are assigned by BuildInsightStorage."
                )
            # Assign sequence number to the event
            event.sequence_number = self._sequence_counter
            self._sequence_counter += 1
        else:
            # FOLLOWER mode: event must have a sequence number already
            if event.sequence_number is None:
                raise ValueError(
                    "Event must have a sequence number. In FOLLOWER mode, sequence numbers must be pre-assigned."
                )

        self.storage.append(event)
        self._dispatch_event(event)
        return event

    def get_events(self) -> list[BuildInsightEvent]:
        return self.storage

    def get_events_of_type[T: BuildInsightEvent](self, event_type: type[T]) -> list[T]:
        return [event for event in self.storage if isinstance(event, event_type)]

    def _dispatch_event(self, event: BuildInsightEvent) -> None:
        """Dispatch an event to all relevant listeners."""
        # Call listeners registered for the exact event type
        event_type = type(event)
        if event_type in self.listeners:
            for listener in self.listeners[event_type]:
                listener(event)

        # Call listeners registered for BuildInsightEvent (all events)
        if BuildInsightEvent in self.listeners and event_type != BuildInsightEvent:
            for listener in self.listeners[BuildInsightEvent]:
                listener(event)

    @staticmethod
    def _all_event_subclasses() -> list[type[BuildInsightEvent]]:
        # Recursively collect all subclasses (direct and indirect) of BuildInsightEvent
        def walk(cls: type[BuildInsightEvent]) -> list[type[BuildInsightEvent]]:
            result: list[type[BuildInsightEvent]] = []
            for sub in cls.__subclasses__():
                result.append(sub)
                result.extend(walk(sub))
            return result

        return walk(BuildInsightEvent)

    @staticmethod
    def _event_type_key() -> str:
        return "__event_type__"

    def get_serialized_content(self) -> str:
        type_key = self._event_type_key()
        return json.dumps(
            [{**event.model_dump(mode="json"), type_key: event.__class__.__name__} for event in self.storage]
        )

    def serialize_to_file(self, file_path: Path):
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(self.get_serialized_content())

    def deserialize_from_file(self, file_path: Path):
        if not file_path.exists():
            raise ValueError(f"File {file_path} doesn't exist")
        content = file_path.read_text()
        raw_events = json.loads(content)

        if not instanceof(raw_events, list[Any]):
            raise ValueError("Serialized events must be a list")

        type_key = self._event_type_key()
        subclasses = {cls.__name__: cls for cls in self._all_event_subclasses()}

        loaded: list[BuildInsightEvent] = []
        for obj in raw_events:
            if not instanceof(obj, dict[str, Any]):
                raise ValueError("Each serialized event must be an object")
            type_name = obj.get(type_key)
            if not type_name:
                raise ValueError("Serialized event is missing type discriminator")
            event_cls = subclasses.get(type_name)
            if event_cls is None:
                raise ValueError(f"Unknown event type: {type_name}")
            data = {k: v for k, v in obj.items() if k != type_key}
            loaded.append(event_cls(**data))

        self.storage = loaded

    def replay_events(self, callback: ListenerType, speed: float = 1.0, instant: bool = False):
        sorted_events = sorted(self.storage, key=lambda x: x.timestamp)

        if not sorted_events:
            return

        # Start from the first event timestamp
        start_time = time.time()
        first_event_timestamp = sorted_events[0].timestamp

        for event in sorted_events:
            # Calculate how long to wait based on the original timing
            original_event_time_since_start = event.timestamp - first_event_timestamp
            real_time_since_start = time.time() - start_time

            # Wait if we're ahead of the original timing (accounting for speed)
            target_event_time_since_start = original_event_time_since_start / speed
            wait_time = target_event_time_since_start - real_time_since_start
            if wait_time > 0 and not instant:
                time.sleep(wait_time)

            # Call the callback with the event
            real_timestamp = start_time + target_event_time_since_start
            callback(event.model_copy(update={"timestamp": real_timestamp}))

    def register_global_event_listener(self, listener: Callable[[BuildInsightEvent], None]) -> None:
        """Register a listener for all events."""
        self.register_event_listener(listener, BuildInsightEvent)

    def register_event_listener[T: BuildInsightEvent](self, listener: Callable[[T], None], event_type: type[T]) -> None:
        """Register a listener for events of a specific type.

        Args:
            listener: Callback function to handle events
            event_type: Type of events to listen for (defaults to BuildInsightEvent for all events)
        """
        if event_type not in self.listeners:
            self.listeners[event_type] = []
        self.listeners[event_type].append(cast(ListenerType, listener))


class NoOpBuildInsightStorage(BuildInsightStorage):
    def __getattr__(self, name: str) -> Callable[[Any], None]:
        # Return a no-op function for any attribute access
        def result(*args: Any, **kwargs: Any) -> None:
            return None

        return result
