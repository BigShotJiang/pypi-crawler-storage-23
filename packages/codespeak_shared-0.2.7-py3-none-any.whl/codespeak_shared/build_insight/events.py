import json
import time
import uuid
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from codespeak_shared.test_runner_types import TestResults


def _current_timestamp() -> float:
    """Get current timestamp. Separate function for easier testing."""
    return time.time()


# Base class for all build insight events
class BuildInsightEvent(BaseModel):
    timestamp: float = Field(default_factory=_current_timestamp)
    sequence_number: int | None = None  # Set by BuildInsightStorage (leader) when event is reported
    extra: dict[str, Any] = Field(default_factory=dict)

    def pretty_print(self) -> str:
        json_model_dump = {"type": self.__class__.__name__, **self.model_dump()}
        text = json.dumps(json_model_dump)
        if len(text) > 200:
            text = json.dumps(json_model_dump, indent=2)
        return text


class SpanCloseEvent(BuildInsightEvent):
    span_id: str


class SpanOpenEvent(BuildInsightEvent):
    span_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str | None = None

    def create_closing_event(self) -> SpanCloseEvent:
        return SpanCloseEvent(span_id=self.span_id)


class ProgressItemStatus(str, Enum):
    PENDING = "Pending"
    IN_PROGRESS = "In Progress"
    SKIPPED = "Skipped"
    DONE = "Done"
    FAILED = "Failed"


class ProgressItemUpdateEvent(BuildInsightEvent):
    progress_item_id: str  # No default, must be set
    status: ProgressItemStatus
    status_text: str | None = None


class ProgressItemCreateEvent(ProgressItemUpdateEvent):
    progress_item_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    status: ProgressItemStatus = ProgressItemStatus.PENDING
    title: str
    description: str | None = None
    parent_item_id: str | None = None

    def create_updating_event(
        self, new_status: ProgressItemStatus | None = None, new_status_text: str | None = None
    ) -> ProgressItemUpdateEvent:
        return ProgressItemUpdateEvent(
            progress_item_id=self.progress_item_id,
            status=new_status or self.status,
            status_text=new_status_text or self.status_text,
        )


class ToolCallEvent(BuildInsightEvent):
    title: str
    details: str | None = None
    parent_progress_item_id: str | None = None


class TextOutputEvent(BuildInsightEvent):
    text: str
    parent_progress_item_id: str | None = None


class TestsRunEvent(BuildInsightEvent):
    test_results: TestResults | None

    __test__ = False


class UserVisibleModelOutputEvent(TextOutputEvent):
    """
    Event for messages that models/agents send with the intent of being displayed to the user.

    More specific type of TextOutputEvent that might be used by renderers for specific formatting.
    """

    pass


class StopInteractiveProgressEvent(BuildInsightEvent):
    """Signal to stop the interactive progress display before running an interactive operation."""

    pass
