import logging
from abc import ABC, abstractmethod

from semver import Version

from codespeak_shared.exceptions import (
    CmdlineToolMissingUserError,
    CmdlineToolVersionTooOldUserError,
    RequiredToolsValidationUserError,
)
from codespeak_shared.os_environment import OsEnvironment
from codespeak_shared.os_environment.os_environment import (
    ChildProcessFailedToStartException,
    ChildProcessTimedOutException,
)
from codespeak_shared.project_path import ProjectPath


class CmdlineToolVersionParser(ABC):
    """Abstract parser for extracting version from command-line tool output.

    Subclasses must implement the abstract properties and method to define
    how to run the version command and parse its output.
    """

    @property
    @abstractmethod
    def tool_name(self) -> str:
        """Human-readable name of the tool (e.g., 'git', 'uv')."""
        pass

    @property
    @abstractmethod
    def version_command(self) -> list[str]:
        """Command line arguments to run to get version info (e.g., ['git', '--version'])."""
        pass

    @property
    @abstractmethod
    def missing_tool_message(self) -> str:
        """Useful message shown when the tool is not installed."""
        pass

    @property
    @abstractmethod
    def version_too_old_message(self) -> str:
        """Useful message shown when version is below minimum.

        May contain {current_version} and {min_version} placeholders.
        """
        pass

    @abstractmethod
    def extract_version_from_output(self, stdout: str) -> Version:
        """Extract the version from the command output.

        Args:
            stdout: Standard output from running the version command.

        Returns:
            The parsed Version instance.

        Raises:
            ValueError: If the version cannot be extracted from the output.
        """
        pass


def _validate_required_tool(parser: CmdlineToolVersionParser, min_version: Version, os_env: OsEnvironment) -> Version:
    """Check that a command-line tool is installed and meets version requirements.

    Args:
        parser: The version parser for the tool to check.
        os_env: The OS environment to run commands in.
        min_version: Minimum required version of the tool.

    Returns:
        The detected version of the tool.

    Raises:
        CmdlineToolMissingUserError: If the tool is not found or fails to run.
        CmdlineToolVersionTooOldUserError: If the version is below the minimum required.
    """
    try:
        result = os_env.run_child_process(
            parser.version_command, ProjectPath.from_string("."), timeout=300, check=False, add_distribution_bin=True
        )
        exit_code, stdout = result.exit_code, result.stdout
    except ChildProcessFailedToStartException:
        raise CmdlineToolMissingUserError(parser.missing_tool_message)
    except ChildProcessTimedOutException:
        raise CmdlineToolMissingUserError(f"{parser.tool_name} command timed out. {parser.missing_tool_message}")

    if exit_code != 0:
        raise CmdlineToolMissingUserError(
            f"Failed to run '{' '.join(parser.version_command)}' (exit code {exit_code}). {parser.missing_tool_message}"
        )

    try:
        version = parser.extract_version_from_output(stdout)
    except (ValueError, IndexError) as e:
        raise CmdlineToolMissingUserError(
            f"Could not parse {parser.tool_name} version from output: {stdout.strip()}. Error: {e}"
        )

    logging.getLogger("_validate_required_tool").info(
        f"Tool {parser.tool_name} version: {version}, minimum required: {min_version}"
    )

    if version.compare(min_version) < 0:
        message = parser.version_too_old_message.format(current_version=version, min_version=min_version)
        raise CmdlineToolVersionTooOldUserError(message)

    return version


def validate_required_tools(tools: dict[CmdlineToolVersionParser, Version], os_env: OsEnvironment) -> None:
    """Check that multiple command-line tools are installed and meet version requirements.

    Args:
        os_env: The OS environment to run commands in.
        tools: A dictionary mapping parsers to their minimum required versions.

    Raises:
        RequiredToolsValidationUserError: If any tools fail validation.
    """
    problems: list[str] = []
    for parser, min_version in tools.items():
        try:
            _validate_required_tool(parser, min_version, os_env)
        except (CmdlineToolMissingUserError, CmdlineToolVersionTooOldUserError) as e:
            problems.append(f"{parser.tool_name}: {e}")

    if problems:
        raise RequiredToolsValidationUserError(problems)
