from typing import override

from semver import Version

from codespeak_shared.cmdline_tools.version_parser import CmdlineToolVersionParser

MIN_GIT_VERSION = Version.parse("2.35.0")


class GitVersionParser(CmdlineToolVersionParser):
    """Parser for git version detection."""

    @property
    @override
    def tool_name(self) -> str:
        return "git"

    @property
    @override
    def version_command(self) -> list[str]:
        return ["git", "--version"]

    @property
    @override
    def missing_tool_message(self) -> str:
        return "Git is required but not found. Please install git version 2.35.0 or later: https://git-scm.com/install/"

    @property
    @override
    def version_too_old_message(self) -> str:
        return (
            "Git version {current_version} is older than minimum required {min_version}. "
            "Please upgrade git to version {min_version} or later."
        )

    @override
    def extract_version_from_output(self, stdout: str) -> Version:
        # Output format: "git version 2.35.0" or "git version 2.35.0.windows.1"
        parts = stdout.strip().split()
        if len(parts) < 3:
            raise ValueError(f"Unexpected git version output format: {stdout}")
        version_str = parts[2]
        # Handle versions like "2.35.0.windows.1" by taking only the first 3 parts
        version_parts = version_str.split(".")
        if len(version_parts) >= 3:
            version_str = ".".join(version_parts[:3])
        return Version.parse(version_str)
