"""Extension point for validating required command-line tools."""

from abc import ABC, abstractmethod
from typing import Any

from codespeak_shared.extensions.extension_point import ExtensionPoint
from codespeak_shared.os_environment import OsEnvironment

EXTENSION_GROUP = "codespeak.validate_required_tools"


@ExtensionPoint(EXTENSION_GROUP)
class ValidateRequiredToolsExtensionPoint(ABC):
    """Extension point for validating required command-line tools.

    Implementations should check for specific tools based on project criteria
    and return a list of error messages for any missing or misconfigured tools.

    Extensions are registered in pyproject.toml:
        [project.entry-points."codespeak.validate_required_tools"]
        python = "codespeak.lang_support.python.validate_tools:PythonToolsValidationExtension"
    """

    @abstractmethod
    def validate_tools(self, os_env: OsEnvironment, criteria: dict[str, Any]) -> None:
        """Validate required tools based on project criteria.

        Args:
            os_env: The OS environment to run commands in.
            criteria: Project criteria dictionary containing detected features
                     (e.g., has_python, has_server, architecture).

        Returns:
            A list of error messages for missing or misconfigured tools.
            Returns an empty list if all required tools are properly installed.
        """
        ...
