from typing import override

from semver import Version

from codespeak_shared.cmdline_tools.version_parser import CmdlineToolVersionParser

_MIN_RIPGREP_VERSION_STR = "14.1.0"

MIN_RIPGREP_VERSION = Version.parse(
    _MIN_RIPGREP_VERSION_STR
)  # https://github.com/codespeak-dev/open-codespeak/issues/99


class RipgrepVersionParser(CmdlineToolVersionParser):
    """Parser for ripgrep version detection."""

    @property
    @override
    def tool_name(self) -> str:
        return "ripgrep"

    @property
    @override
    def version_command(self) -> list[str]:
        return ["rg", "--version"]

    @property
    @override
    def missing_tool_message(self) -> str:
        return f"ripgrep is required but not found. Please install ripgrep {_MIN_RIPGREP_VERSION_STR} or later: https://github.com/BurntSushi/ripgrep#installation"

    @property
    @override
    def version_too_old_message(self) -> str:
        return (
            "ripgrep version {current_version} is older than minimum required {min_version}. "
            "Please upgrade ripgrep to version {min_version} or later."
        )

    @override
    def extract_version_from_output(self, stdout: str) -> Version:
        # Output format: "ripgrep 14.1.1\n\nfeatures:..."
        first_line = stdout.strip().split("\n")[0]
        parts = first_line.split()
        if len(parts) < 2 or parts[0] != "ripgrep":
            raise ValueError(f"Unexpected ripgrep version output format: {stdout}")
        version_str = parts[1]
        return Version.parse(version_str)
