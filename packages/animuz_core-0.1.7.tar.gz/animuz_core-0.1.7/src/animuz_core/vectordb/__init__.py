"""Vector DB module - Qdrant client."""

from .utils import MyQdrantClient

# Alias for better naming
QdrantDBClient = MyQdrantClient

__all__ = [
    "MyQdrantClient",
    "QdrantDBClient",
]
