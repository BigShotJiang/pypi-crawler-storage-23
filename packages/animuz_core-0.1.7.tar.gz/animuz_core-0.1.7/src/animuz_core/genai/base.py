from abc import ABC, abstractmethod
import json, time

class BaseLLM(ABC):
    def clear_history(self) -> None:
        self.message_history = []

    @abstractmethod
    async def get_reply(self, prompt: str):
        pass

    def append_user_message(self, text: str):
        self.message_history.append({"role": "user", "content": text})

    def append_assistant_message(self, text: str):
        self.message_history.append({"role": "assistant", "content": text})

class BaseAgent(ABC):
    def clear_history(self) -> None:
        self.message_history = []

    @abstractmethod
    async def get_reply_frontend(self, prompt: str):
        pass

    def append_user_message(self, text: str):
        self.message_history.append({"role": "user", "content": text})

    def append_assistant_message(self, text: str):
        self.message_history.append({"role": "assistant", "content": text})

    async def process_tool_use(self, tool_input, tool_name, user_chat_id):
        try:
            if tool_name == "retriever":
                tool_input["user_chat_id"] = user_chat_id
                
            result = await self.tools[tool_name][1](**tool_input)

            if tool_name == "retriever":
                result = "<doc>".join(result[0])
            return result
        except Exception as e:
            result = "ERROR"
            print("ERROR tool result: ", result,"\n error: ", e)
            return result