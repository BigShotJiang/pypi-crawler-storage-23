"""GenAI module - LLM clients and base classes."""

from .base import BaseLLM, BaseAgent
from .openai_client import OpenAIAgentClient
from .openai_streaming_client import OpenAIAgentClientStreaming
from .openai_responses_client import OpenAIAgentClientResponses
from .tools import (
    AnthropicTool,
    OpenAITool,
    AnthropicRetrieverTool,
    OpenAIRetrieverTool,
    MCPTools,
)

# Lazy imports for optional providers
def __getattr__(name):
    if name in ("AnthropicClient", "AnthropicAgentClient"):
        from .anthropic_client import AnthropicClient, AnthropicAgentClient
        return {"AnthropicClient": AnthropicClient, "AnthropicAgentClient": AnthropicAgentClient}[name]
    if name == "OLlamaClient":
        from .ollama_client import OLlamaClient
        return OLlamaClient
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "BaseLLM",
    "BaseAgent",
    "OpenAIAgentClient",
    "OpenAIAgentClientStreaming",
    "OpenAIAgentClientResponses",
    "AnthropicClient",
    "AnthropicAgentClient",
    "OLlamaClient",
    "AnthropicTool",
    "OpenAITool",
    "AnthropicRetrieverTool",
    "OpenAIRetrieverTool",
    "MCPTools",
]
