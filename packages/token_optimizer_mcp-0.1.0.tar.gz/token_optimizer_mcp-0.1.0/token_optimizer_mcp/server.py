"""
Token Optimizer MCP Server — Core Implementation
=============================================
This module integrates all tools and exposes the start_server function.
Every tool is purpose-built to minimize token usage.
"""

from __future__ import annotations

import json
import logging
import sys

# ---------------------------------------------------------------------------
# Import the shared MCP server instance
# ---------------------------------------------------------------------------
from token_optimizer_mcp.app import mcp

# ---------------------------------------------------------------------------
# Register all tools
# ---------------------------------------------------------------------------
# Each sub-module calls `@mcp.tool()` when imported.
from token_optimizer_mcp.tools import file_tools    # noqa: F401
from token_optimizer_mcp.tools import search_tools  # noqa: F401
from token_optimizer_mcp.tools import summary_tools # noqa: F401
from token_optimizer_mcp.tools import git_tools     # noqa: F401
from token_optimizer_mcp.memory import memory_manager  # noqa: F401

# Token tracking tools
from token_optimizer_mcp.utils.token_tracker import get_lifetime_stats, reset_stats

logger = logging.getLogger("token_optimizer_mcp")

@mcp.tool()
async def get_token_stats() -> str:
    """Return lifetime token savings statistics."""
    return json.dumps(get_lifetime_stats(), indent=2)

@mcp.tool()
async def reset_token_stats() -> str:
    """Reset all accumulated token savings statistics to zero."""
    return json.dumps(reset_stats())

def start_server(transport: str = "stdio") -> None:
    """Entry point to run the FastMCP server.
    
    Args:
        transport: 'stdio' or 'sse'
    """
    logger.info("Starting Token Optimizer MCP server in %s mode.", transport)
    mcp.run(transport=transport)
