"""
Token Tracker — Persistent Token Usage & Savings Statistics
=============================================================
Quantifies token savings so you can see exactly how many tokens
(and dollars) you're saving.

TOKEN ESTIMATION: 1 token ≈ 4 characters (standard heuristic).
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from token_optimizer_mcp.config import CACHE_DIR, ENABLE_TOKEN_TRACKING, TOKEN_COST_PER_1K

logger = logging.getLogger("token_optimizer_mcp.tracker")

TRACKER_FILE: Path = CACHE_DIR / "token_tracker.json"


def estimate_tokens(text: str) -> int:
    """Estimate token count: ~4 characters per token."""
    return max(1, len(text) // 4)


def _load_totals() -> dict[str, Any]:
    """Load accumulated totals from disk."""
    if not TRACKER_FILE.is_file():
        return {
            "total_tokens_used": 0,
            "total_tokens_saved": 0,
            "total_full_tokens": 0,
            "total_requests": 0,
            "estimated_cost_saved_usd": 0.0,
            "first_tracked": None,
            "last_tracked": None,
        }
    try:
        with open(TRACKER_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {
            "total_tokens_used": 0,
            "total_tokens_saved": 0,
            "total_full_tokens": 0,
            "total_requests": 0,
            "estimated_cost_saved_usd": 0.0,
            "first_tracked": None,
            "last_tracked": None,
        }


def _save_totals(totals: dict[str, Any]) -> None:
    """Persist accumulated totals to disk."""
    TRACKER_FILE.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(TRACKER_FILE, "w") as f:
            json.dump(totals, f, indent=2)
    except Exception as exc:
        logger.warning("Failed to persist token tracker: %s", exc)


def record_savings(
    tool_name: str,
    full_text: str,
    actual_text: str,
) -> dict[str, Any]:
    """Record a single tool call's token savings and return stats."""
    if not ENABLE_TOKEN_TRACKING:
        return {}

    full_tokens = estimate_tokens(full_text)
    actual_tokens = estimate_tokens(actual_text)
    saved_tokens = max(0, full_tokens - actual_tokens)

    totals = _load_totals()
    now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    totals["total_tokens_used"] += actual_tokens
    totals["total_tokens_saved"] += saved_tokens
    totals["total_full_tokens"] += full_tokens
    totals["total_requests"] += 1
    totals["estimated_cost_saved_usd"] = round(
        (totals["total_tokens_saved"] / 1000) * TOKEN_COST_PER_1K, 6
    )
    if totals["first_tracked"] is None:
        totals["first_tracked"] = now
    totals["last_tracked"] = now

    _save_totals(totals)

    stats = {
        "_token_stats": {
            "tool": tool_name,
            "tokens_used": actual_tokens,
            "tokens_saved": saved_tokens,
            "total_tokens_saved": totals["total_tokens_saved"],
            "total_requests_tracked": totals["total_requests"],
            "estimated_cost_saved_usd": totals["estimated_cost_saved_usd"],
        }
    }

    logger.info(
        "Token tracker [%s]: used=%d, saved=%d, cumulative_saved=%d",
        tool_name, actual_tokens, saved_tokens, totals["total_tokens_saved"],
    )
    return stats


def get_lifetime_stats() -> dict[str, Any]:
    """Return the accumulated lifetime token savings statistics."""
    totals = _load_totals()
    totals["token_cost_per_1k"] = TOKEN_COST_PER_1K
    totals["tracking_enabled"] = ENABLE_TOKEN_TRACKING
    return totals


def reset_stats() -> dict[str, str]:
    """Reset all accumulated statistics to zero."""
    if TRACKER_FILE.is_file():
        TRACKER_FILE.unlink()
    logger.info("Token tracker stats reset.")
    return {"status": "reset", "message": "All token tracking statistics cleared."}
