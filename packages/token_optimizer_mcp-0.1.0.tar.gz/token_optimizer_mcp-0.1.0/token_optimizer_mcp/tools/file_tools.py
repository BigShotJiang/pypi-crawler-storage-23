"""
File Tools — read_file_chunk
==============================
TOKEN SAVING STRATEGY:
  Returns ONLY the requested line range.  A hard cap of MAX_FILE_LINES
  prevents accidental full-file reads.  Final output truncated to
  MAX_OUTPUT_CHARS as safety net.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import aiofiles

from token_optimizer_mcp.config import MAX_FILE_LINES, MAX_OUTPUT_CHARS
from token_optimizer_mcp.app import mcp
from token_optimizer_mcp.utils.token_tracker import record_savings

logger = logging.getLogger("token_optimizer_mcp.file_tools")


def _truncate(text: str, limit: int = MAX_OUTPUT_CHARS) -> str:
    """Hard-truncate text to limit, appending a marker if trimmed."""
    if len(text) <= limit:
        return text
    return text[:limit] + "\n... [TRUNCATED — output exceeded max chars]"


@mcp.tool()
async def read_file_chunk(
    file_path: str,
    start_line: int = 1,
    end_line: int = 50,
) -> str:
    """Read specific lines from a file.  Never returns the full file.

    Args:
        file_path: Absolute or relative path to the file.
        start_line: First line to read (1-indexed, default 1).
        end_line: Last line to read (1-indexed, inclusive, default 50).

    Returns:
        JSON with the requested lines, line range, total line count, and
        token savings statistics.
    """
    path = Path(file_path).resolve()

    if not path.is_file():
        return json.dumps({"error": f"File not found: {path}"})

    # Clamp the range — primary token-saving mechanism for file reads.
    start_line = max(1, start_line)
    span = min(end_line - start_line + 1, MAX_FILE_LINES)
    end_line = start_line + span - 1

    logger.info("read_file_chunk: %s [%d–%d]", path, start_line, end_line)

    try:
        async with aiofiles.open(path, mode="r", encoding="utf-8", errors="replace") as f:
            all_lines = await f.readlines()
    except Exception as exc:
        logger.error("Failed to read %s: %s", path, exc)
        return json.dumps({"error": str(exc)})

    total_lines = len(all_lines)
    full_content = "".join(all_lines)
    selected = all_lines[start_line - 1 : end_line]
    chunk_content = "".join(selected)

    result: dict = {
        "file": str(path),
        "start_line": start_line,
        "end_line": min(end_line, total_lines),
        "total_lines": total_lines,
        "lines_returned": len(selected),
        "content": chunk_content,
    }

    # Token savings tracking — full file vs. returned chunk.
    output = json.dumps(result, ensure_ascii=False)
    stats = record_savings("read_file_chunk", full_content, output)
    result.update(stats)

    return _truncate(json.dumps(result, ensure_ascii=False))
