"""
Summary Tools — summarize_file
=================================
TOKEN SAVING STRATEGY:
  Produces a STRUCTURAL SUMMARY (imports, classes, functions) instead of
  the full file content.  Capped at MAX_SUMMARY_CHARS, optionally cached.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import time
from pathlib import Path

import aiofiles

from token_optimizer_mcp.config import (
    CACHE_DIR,
    CACHE_ENABLED,
    MAX_OUTPUT_CHARS,
    MAX_SUMMARY_CHARS,
)
from token_optimizer_mcp.app import mcp
from token_optimizer_mcp.utils.token_tracker import record_savings

logger = logging.getLogger("token_optimizer_mcp.summary_tools")

_summary_cache: dict[str, dict] = {}


def _file_hash(path: Path) -> str:
    """Quick hash of file path + mtime for cache key."""
    stat = path.stat()
    raw = f"{path}:{stat.st_size}:{stat.st_mtime_ns}"
    return hashlib.md5(raw.encode()).hexdigest()


def _extract_structure(lines: list[str]) -> dict:
    """Parse a file's lines and extract a minimal structural summary."""
    imports: list[str] = []
    classes: list[str] = []
    functions: list[str] = []
    decorators: list[str] = []

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith(("import ", "from ")):
            imports.append(stripped)
        elif stripped.startswith("class "):
            match = re.match(r"class\s+(\w+)", stripped)
            if match:
                classes.append(f"L{i}: {match.group(1)}")
        elif stripped.startswith("def "):
            match = re.match(r"def\s+(\w+)", stripped)
            if match:
                functions.append(f"L{i}: {match.group(1)}")
        elif stripped.startswith("async def "):
            match = re.match(r"async\s+def\s+(\w+)", stripped)
            if match:
                functions.append(f"L{i}: async {match.group(1)}")
        elif stripped.startswith("@"):
            decorators.append(f"L{i}: {stripped}")

    return {
        "imports": imports[:30],
        "classes": classes[:50],
        "functions": functions[:80],
        "decorators": decorators[:30],
    }


async def _load_disk_cache() -> dict:
    """Load persisted summary cache from disk."""
    cache_file = CACHE_DIR / "summary_cache.json"
    if not cache_file.is_file():
        return {}
    try:
        async with aiofiles.open(cache_file, "r") as f:
            return json.loads(await f.read())
    except Exception:
        return {}


async def _save_disk_cache(cache: dict) -> None:
    """Persist summary cache to disk."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = CACHE_DIR / "summary_cache.json"
    try:
        async with aiofiles.open(cache_file, "w") as f:
            await f.write(json.dumps(cache, indent=2))
    except Exception as exc:
        logger.warning("Failed to persist summary cache: %s", exc)


@mcp.tool()
async def summarize_file(
    file_path: str,
    force_refresh: bool = False,
) -> str:
    """Return a structural summary of a file instead of its full content.

    If the file is small (≤ 60 lines), the full content is returned
    because a summary wouldn't save tokens.  For larger files, only
    the skeleton is returned (imports, classes, functions, line counts).

    Args:
        file_path: Path to the file to summarize.
        force_refresh: If True, bypass the summary cache.

    Returns:
        JSON summary with structural info, capped at MAX_SUMMARY_CHARS,
        and token savings statistics.
    """
    global _summary_cache

    path = Path(file_path).resolve()
    if not path.is_file():
        return json.dumps({"error": f"File not found: {path}"})

    # Cache check.
    cache_key = _file_hash(path)
    if CACHE_ENABLED and not force_refresh:
        if cache_key in _summary_cache:
            logger.info("summarize_file: cache HIT for %s", path)
            return _summary_cache[cache_key]["output"]

        disk_cache = await _load_disk_cache()
        if cache_key in disk_cache:
            _summary_cache[cache_key] = disk_cache[cache_key]
            logger.info("summarize_file: disk cache HIT for %s", path)
            return disk_cache[cache_key]["output"]

    logger.info("summarize_file: generating summary for %s", path)

    try:
        async with aiofiles.open(path, mode="r", encoding="utf-8", errors="replace") as f:
            lines = await f.readlines()
    except Exception as exc:
        return json.dumps({"error": str(exc)})

    total_lines = len(lines)
    full_content = "".join(lines)

    # Small files: return full content (cheaper than a summary).
    if total_lines <= 60:
        result: dict = {
            "file": str(path),
            "total_lines": total_lines,
            "mode": "full_content",
            "content": full_content,
        }
    else:
        structure = _extract_structure(lines)
        result = {
            "file": str(path),
            "total_lines": total_lines,
            "mode": "summary",
            "extension": path.suffix,
            "size_bytes": path.stat().st_size,
            **structure,
        }

    output = json.dumps(result, ensure_ascii=False)

    # Token savings tracking.
    stats = record_savings("summarize_file", full_content, output)
    result.update(stats)

    output = json.dumps(result, ensure_ascii=False)
    if len(output) > MAX_SUMMARY_CHARS:
        output = output[:MAX_SUMMARY_CHARS] + '..."}'
    if len(output) > MAX_OUTPUT_CHARS:
        output = output[:MAX_OUTPUT_CHARS] + "\n... [TRUNCATED]"

    # Cache result.
    if CACHE_ENABLED:
        _summary_cache[cache_key] = {
            "output": output,
            "timestamp": time.time(),
        }
        disk_cache = await _load_disk_cache()
        disk_cache[cache_key] = _summary_cache[cache_key]
        await _save_disk_cache(disk_cache)

    return output
