"""
Search Tools — search_codebase
================================
TOKEN SAVING STRATEGY:
  Returns only the N best matching FILE PATHS + a tiny PREVIEW SNIPPET.
  Skips binaries, vendored dirs, and noise.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

import aiofiles

from token_optimizer_mcp.config import (
    IGNORED_DIRS,
    IGNORED_EXTENSIONS,
    MAX_OUTPUT_CHARS,
    MAX_PREVIEW_CHARS,
    MAX_SEARCH_RESULTS,
    PROJECT_ROOT,
)
from token_optimizer_mcp.app import mcp
from token_optimizer_mcp.utils.token_tracker import record_savings

logger = logging.getLogger("token_optimizer_mcp.search_tools")


def _should_skip(path: Path) -> bool:
    """Return True if the path should be excluded from results."""
    for part in path.parts:
        if part in IGNORED_DIRS:
            return True
    if path.suffix.lower() in IGNORED_EXTENSIONS:
        return True
    return False


async def _read_preview(path: Path, query: str) -> str | None:
    """Read just enough to produce a small preview snippet."""
    try:
        async with aiofiles.open(path, mode="r", encoding="utf-8", errors="replace") as f:
            content = await f.read(50_000)
    except Exception:
        return None

    lower_content = content.lower()
    lower_query = query.lower()
    idx = lower_content.find(lower_query)
    if idx == -1:
        return None

    half = MAX_PREVIEW_CHARS // 2
    start = max(0, idx - half)
    end = min(len(content), idx + len(query) + half)
    snippet = content[start:end].strip()
    if start > 0:
        snippet = "..." + snippet
    if end < len(content):
        snippet = snippet + "..."
    return snippet


async def _estimate_full_output(matches_data: list[dict]) -> str:
    """Estimate what a naive search would have returned (full file contents)."""
    full_parts: list[str] = []
    for m in matches_data:
        try:
            async with aiofiles.open(m["file"], "r", encoding="utf-8", errors="replace") as f:
                full_parts.append(await f.read(50_000))
        except Exception:
            pass
    return "\n".join(full_parts)


@mcp.tool()
async def search_codebase(
    query: str,
    file_pattern: str = "*",
    root: str = "",
) -> str:
    """Search the project for files containing a query string.

    Returns matching file paths with a small preview snippet — NOT
    the full file content.  Results are capped to stay token-efficient.

    Args:
        query: Text to search for (case-insensitive).
        file_pattern: Optional glob pattern to filter files (e.g. '*.py').
        root: Directory to search.  Defaults to PROJECT_ROOT from config.

    Returns:
        JSON list of matches with path, snippet, and token savings stats.
    """
    search_root = Path(root).resolve() if root else PROJECT_ROOT

    if not search_root.is_dir():
        return json.dumps({"error": f"Directory not found: {search_root}"})

    logger.info("search_codebase: query=%r root=%s", query, search_root)

    matches: list[dict] = []

    for dirpath, dirnames, filenames in os.walk(search_root):
        dirnames[:] = [d for d in dirnames if d not in IGNORED_DIRS]

        for fname in filenames:
            if len(matches) >= MAX_SEARCH_RESULTS:
                break

            fpath = Path(dirpath) / fname
            if _should_skip(fpath):
                continue

            if file_pattern != "*" and not fpath.match(file_pattern):
                continue

            preview = await _read_preview(fpath, query)
            if preview is not None:
                matches.append({
                    "file": str(fpath),
                    "preview": preview,
                })

        if len(matches) >= MAX_SEARCH_RESULTS:
            break

    result: dict = {
        "query": query,
        "root": str(search_root),
        "total_matches": len(matches),
        "capped_at": MAX_SEARCH_RESULTS,
        "matches": matches,
    }

    output = json.dumps(result, ensure_ascii=False)
    full_output = await _estimate_full_output(matches)
    stats = record_savings("search_codebase", full_output, output)
    result.update(stats)

    output = json.dumps(result, ensure_ascii=False)
    if len(output) > MAX_OUTPUT_CHARS:
        output = output[:MAX_OUTPUT_CHARS] + "\n... [TRUNCATED]"
    return output
