"""
Git Tools — get_git_diff
==========================
TOKEN SAVING STRATEGY:
  Only changed lines are returned.  Optional file filter + hard
  MAX_OUTPUT_CHARS truncation.
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path

from token_optimizer_mcp.config import MAX_OUTPUT_CHARS, PROJECT_ROOT
from token_optimizer_mcp.app import mcp
from token_optimizer_mcp.utils.token_tracker import record_savings

logger = logging.getLogger("token_optimizer_mcp.git_tools")


async def _run_git(*args: str, cwd: Path) -> tuple[int, str, str]:
    """Run a git command asynchronously."""
    proc = await asyncio.create_subprocess_exec(
        "git", *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=str(cwd),
    )
    stdout, stderr = await proc.communicate()
    return (
        proc.returncode or 0,
        stdout.decode("utf-8", errors="replace"),
        stderr.decode("utf-8", errors="replace"),
    )


async def _get_full_file_content(file_path: str, cwd: Path) -> str:
    """Get full file content to estimate naive token cost."""
    if file_path:
        full_path = cwd / file_path
        if full_path.is_file():
            try:
                return full_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                pass
    return ""


@mcp.tool()
async def get_git_diff(
    file_path: str = "",
    staged: bool = False,
    root: str = "",
) -> str:
    """Return the git diff for the working tree (or a specific file).

    Only changed lines are returned — never the full file.  Output is
    hard-capped at MAX_OUTPUT_CHARS to prevent context-window blow-ups
    on large diffs.

    Args:
        file_path: Optional specific file to diff.  If empty, diffs the
                   entire working tree.
        staged: If True, show staged changes (--cached).  Default: False.
        root: Git repository root.  Defaults to PROJECT_ROOT.

    Returns:
        JSON with the diff text, stats, truncation status, and token savings.
    """
    repo = Path(root).resolve() if root else PROJECT_ROOT
    if not (repo / ".git").is_dir():
        return json.dumps({"error": f"Not a git repository: {repo}"})

    cmd: list[str] = ["diff", "--unified=3", "--stat"]
    if staged:
        cmd.append("--cached")
    if file_path:
        cmd.extend(["--", file_path])

    logger.info("get_git_diff: %s (staged=%s)", file_path or "(all)", staged)

    returncode, stdout, stderr = await _run_git(*cmd, cwd=repo)
    if returncode != 0:
        return json.dumps({"error": stderr.strip() or "git diff failed"})

    cmd_full: list[str] = ["diff", "--unified=3"]
    if staged:
        cmd_full.append("--cached")
    if file_path:
        cmd_full.extend(["--", file_path])

    _, diff_text, _ = await _run_git(*cmd_full, cwd=repo)

    truncated = False
    if len(diff_text) > MAX_OUTPUT_CHARS:
        diff_text = diff_text[:MAX_OUTPUT_CHARS]
        truncated = True

    result: dict = {
        "repository": str(repo),
        "file": file_path or "(all)",
        "staged": staged,
        "stats": stdout.strip(),
        "diff": diff_text,
        "truncated": truncated,
    }

    full_content = await _get_full_file_content(file_path, repo)
    output = json.dumps(result, ensure_ascii=False)
    stats = record_savings("get_git_diff", full_content or diff_text, output)
    result.update(stats)

    output = json.dumps(result, ensure_ascii=False)
    if len(output) > MAX_OUTPUT_CHARS:
        output = output[:MAX_OUTPUT_CHARS] + "\n... [TRUNCATED]"
    return output
