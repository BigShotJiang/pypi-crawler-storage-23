"""Tools subpackage — MCP tools for token-efficient code exploration."""
