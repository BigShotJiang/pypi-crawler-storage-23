"""
Token Optimizer MCP Server — Configuration
=============================================
Every constant here controls how much text the server returns.
Lower values = fewer tokens = lower API cost.

ALL settings are configurable via environment variables.
Users set them in their MCP client config:

{
  "mcpServers": {
    "token-optimizer-mcp": {
      "command": "token-optimizer-mcp",
      "env": {
        "PROJECT_ROOT": "/path/to/your/project",
        "MAX_FILE_LINES": "300",
        "MAX_OUTPUT_CHARS": "8000",
        "TOKEN_COST_PER_1K": "0.003"
      }
    }
  }
}
"""

import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Environment helpers
# ---------------------------------------------------------------------------

def _env_int(key: str, default: int) -> int:
    """Read an integer from an environment variable, with fallback."""
    val = os.getenv(key)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        print(f"⚠️  Invalid integer for {key}={val!r}, using default {default}", file=sys.stderr)
        return default


def _env_float(key: str, default: float) -> float:
    """Read a float from an environment variable, with fallback."""
    val = os.getenv(key)
    if val is None:
        return default
    try:
        return float(val)
    except ValueError:
        print(f"⚠️  Invalid float for {key}={val!r}, using default {default}", file=sys.stderr)
        return default


def _env_bool(key: str, default: bool) -> bool:
    """Read a boolean from an environment variable, with fallback.

    Accepts: 'true', '1', 'yes' (case-insensitive) → True
             'false', '0', 'no' (case-insensitive) → False
    """
    val = os.getenv(key)
    if val is None:
        return default
    return val.strip().lower() in ("true", "1", "yes")


# ---------------------------------------------------------------------------
# Output caps  (the main token-saving levers)
# ---------------------------------------------------------------------------

# Maximum number of lines read_file_chunk will ever return.
MAX_FILE_LINES: int = _env_int("MAX_FILE_LINES", 300)

# Global character ceiling applied to *every* tool response.
MAX_OUTPUT_CHARS: int = _env_int("MAX_OUTPUT_CHARS", 8_000)

# Maximum search results returned by search_codebase.
MAX_SEARCH_RESULTS: int = _env_int("MAX_SEARCH_RESULTS", 20)

# How many characters of file content to include as a preview snippet.
MAX_PREVIEW_CHARS: int = _env_int("MAX_PREVIEW_CHARS", 200)

# Hard cap on summarize_file output.
MAX_SUMMARY_CHARS: int = _env_int("MAX_SUMMARY_CHARS", 2_000)

# Maximum number of memory entries returned at once.
MAX_MEMORY_ENTRIES: int = _env_int("MAX_MEMORY_ENTRIES", 10)

# ---------------------------------------------------------------------------
# Caching
# ---------------------------------------------------------------------------

CACHE_ENABLED: bool = _env_bool("CACHE_ENABLED", True)

CACHE_DIR: Path = Path(os.getenv(
    "CACHE_DIR",
    str(Path.home() / ".cache" / "token_optimizer_mcp"),
))

# ---------------------------------------------------------------------------
# Project root
# ---------------------------------------------------------------------------

PROJECT_ROOT: Path = Path(os.getenv("PROJECT_ROOT", ".")).resolve()

# ---------------------------------------------------------------------------
# Ignore rules  (skip files the LLM should never see)
# ---------------------------------------------------------------------------

IGNORED_DIRS: set[str] = {
    ".git", "__pycache__", "node_modules", ".venv", "venv",
    ".tox", ".mypy_cache", ".pytest_cache", "dist", "build",
    ".eggs", "*.egg-info", ".idea", ".vscode",
}

IGNORED_EXTENSIONS: set[str] = {
    ".pyc", ".pyo", ".so", ".dll", ".dylib",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg",
    ".mp3", ".mp4", ".wav", ".avi",
    ".zip", ".tar", ".gz", ".bz2", ".7z",
    ".lock", ".bin", ".exe", ".woff", ".woff2", ".ttf", ".eot",
    ".pdf", ".DS_Store",
}

# ---------------------------------------------------------------------------
# Token Tracking
# ---------------------------------------------------------------------------

ENABLE_TOKEN_TRACKING: bool = _env_bool("ENABLE_TOKEN_TRACKING", True)

# Cost per 1,000 tokens (in USD).
#   GPT-4o input:      ~$0.0025 / 1K tokens
#   GPT-4 input:       ~$0.03   / 1K tokens
#   Claude 3.5 input:  ~$0.003  / 1K tokens
#   Claude 3 Opus:     ~$0.015  / 1K tokens
TOKEN_COST_PER_1K: float = _env_float("TOKEN_COST_PER_1K", 0.003)

# ---------------------------------------------------------------------------
# Embeddings & Vector Search
# ---------------------------------------------------------------------------

EMBEDDING_CHUNK_SIZE: int = _env_int("EMBEDDING_CHUNK_SIZE", 50)
EMBEDDING_CHUNK_OVERLAP: int = _env_int("EMBEDDING_CHUNK_OVERLAP", 10)
EMBEDDING_DIMENSION: int = _env_int("EMBEDDING_DIMENSION", 384)

FAISS_INDEX_PATH: Path = Path(os.getenv(
    "FAISS_INDEX_PATH",
    str(CACHE_DIR / "codebase_index.faiss")
))

