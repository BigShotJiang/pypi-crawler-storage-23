"""
Shared FastMCP instance for the Token Optimizer MCP server.
Isolated in its own module to prevent circular imports.
"""

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "Token Optimizer MCP",
    instructions=(
        "MCP server that minimises LLM token usage when working with "
        "large codebases.  Every tool is designed to return the smallest "
        "useful payload — never the full file, never the full repo.  "
        "Token savings statistics are included in every response."
    ),
)
