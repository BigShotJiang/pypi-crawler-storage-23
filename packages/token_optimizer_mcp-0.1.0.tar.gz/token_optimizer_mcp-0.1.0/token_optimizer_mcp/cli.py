"""
CLI Entry Point for token-optimizer-mcp
=======================================
Handles argument parsing and starts the server or management commands.
"""

import argparse
import sys
import logging
import asyncio
import json

from token_optimizer_mcp.server import start_server
from token_optimizer_mcp.utils.token_tracker import get_lifetime_stats, reset_stats
from token_optimizer_mcp import config

# Configure logging for CLI
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("token_optimizer_mcp.cli")

def main() -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="token-optimizer-mcp",
        description="Token Optimizer MCP Server — Reduce LLM costs in coding workflows.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Management command")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Start the MCP server (stdio mode by default)")
    run_parser.add_argument("--sse", action="store_true", help="Start in SSE (HTTP) mode")
    
    # Stats command
    subparsers.add_parser("stats", help="Show lifetime token savings statistics")
    
    # Reset command
    subparsers.add_parser("reset-stats", help="Reset token savings statistics")
    
    # Clear memory command
    subparsers.add_parser("clear-memory", help="Clear conversation memory store")

    # If no command is provided, default to starting the server (run)
    # This allows 'token-optimizer-mcp' to work directly like a server.
    if len(sys.argv) == 1:
        _run_server(False)
        return

    args = sys.argv[1:]
    # Check if first arg is a known command or just flags
    if args[0] not in subparsers.choices and args[0].startswith("-"):
        # Handle case where user runs 'token-optimizer-mcp --sse'
        # We need to manually parse flags for the 'run' command logic
        temp_parser = argparse.ArgumentParser()
        temp_parser.add_argument("--sse", action="store_true")
        known, _ = temp_parser.parse_known_args(args)
        _run_server(known.sse)
        return

    parsed_args = parser.parse_args()

    if parsed_args.command == "run" or parsed_args.command is None:
        _run_server(getattr(parsed_args, "sse", False))
    elif parsed_args.command == "stats":
        show_stats()
    elif parsed_args.command == "reset-stats":
        do_reset()
    elif parsed_args.command == "clear-memory":
        clear_memory_cli()

def _run_server(sse: bool) -> None:
    """Startup routine for the server."""
    print("🚀 Starting Token Optimizer MCP Server")
    print("======================================")
    print(f"PROJECT_ROOT:       {config.PROJECT_ROOT}")
    print(f"MAX_FILE_LINES:     {config.MAX_FILE_LINES}")
    print(f"MAX_OUTPUT_CHARS:   {config.MAX_OUTPUT_CHARS}")
    print(f"TOKEN_TRACKING:     {config.ENABLE_TOKEN_TRACKING}")
    print("-" * 38)
    
    transport = "sse" if sse else "stdio"
    start_server(transport=transport)

def show_stats() -> None:
    """Display persistent stats."""
    stats = get_lifetime_stats()
    print("\n📊 Lifetime Token Savings")
    print("======================================")
    print(f"Total Requests:      {stats['total_requests']}")
    print(f"Tokens Used:         {stats['total_tokens_used']:,}")
    print(f"Tokens Saved:        {stats['total_tokens_saved']:,}")
    print(f"Estimated Savings:   ${stats['estimated_cost_saved_usd']:.4f}")
    print(f"Tracking Since:      {stats['first_tracked']}")
    print("-" * 38)

def do_reset() -> None:
    """Reset statistics."""
    result = reset_stats()
    print(f"✅ {result['message']}")

def clear_memory_cli() -> None:
    """Bridge to the async clear_memory tool."""
    from token_optimizer_mcp.memory.memory_manager import clear_memory
    
    async def _do_clear():
        res_json = await clear_memory()
        res = json.loads(res_json)
        print(f"✅ Memory cleared. Removed {res['entries_removed']} summaries.")
    
    asyncio.run(_do_clear())

if __name__ == "__main__":
    main()
