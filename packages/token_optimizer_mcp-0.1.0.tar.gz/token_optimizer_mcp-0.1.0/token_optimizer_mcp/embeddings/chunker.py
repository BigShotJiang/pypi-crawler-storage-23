"""
File Chunker — Split Files for Embedding
==========================================
TOKEN SAVING STRATEGY:
  Embedding an entire file as one vector loses granularity and forces the
  retrieval system to return huge blobs.  Chunking splits files into small,
  overlapping segments so that vector search can return ONLY the relevant
  fragment — not the whole file.

  The overlap ensures context isn't lost at chunk boundaries.

  This module is a pure utility with no external dependencies.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from config import EMBEDDING_CHUNK_OVERLAP, EMBEDDING_CHUNK_SIZE

logger = logging.getLogger("token_mcp.chunker")


@dataclass
class FileChunk:
    """A single chunk of a file, ready for embedding."""
    file_path: str
    chunk_index: int
    start_line: int          # 1-indexed, inclusive
    end_line: int            # 1-indexed, inclusive
    content: str
    char_count: int = 0
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.char_count = len(self.content)

    def to_dict(self) -> dict:
        return {
            "file": self.file_path,
            "chunk": self.chunk_index,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "char_count": self.char_count,
            "content": self.content,
            "metadata": self.metadata,
        }


def chunk_file(
    file_path: str | Path,
    chunk_size: int = EMBEDDING_CHUNK_SIZE,
    overlap: int = EMBEDDING_CHUNK_OVERLAP,
) -> list[FileChunk]:
    """Split a file into overlapping line-based chunks.

    Args:
        file_path: Path to the file to chunk.
        chunk_size: Number of lines per chunk (default from config).
        overlap: Number of overlapping lines between consecutive chunks.

    Returns:
        List of FileChunk objects.  Each contains the text, line range,
        and metadata needed for embedding storage.
    """
    path = Path(file_path).resolve()
    if not path.is_file():
        logger.warning("chunk_file: file not found: %s", path)
        return []

    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
    except Exception as exc:
        logger.error("chunk_file: failed to read %s: %s", path, exc)
        return []

    if not lines:
        return []

    chunks: list[FileChunk] = []
    step = max(1, chunk_size - overlap)
    idx = 0

    for start in range(0, len(lines), step):
        end = min(start + chunk_size, len(lines))
        content = "".join(lines[start:end])

        chunks.append(FileChunk(
            file_path=str(path),
            chunk_index=idx,
            start_line=start + 1,
            end_line=end,
            content=content,
            metadata={
                "extension": path.suffix,
                "filename": path.name,
                "total_lines": len(lines),
            },
        ))
        idx += 1

        if end >= len(lines):
            break

    logger.info("chunk_file: %s → %d chunks (size=%d, overlap=%d)",
                path.name, len(chunks), chunk_size, overlap)
    return chunks


def chunk_files(
    paths: list[str | Path],
    chunk_size: int = EMBEDDING_CHUNK_SIZE,
    overlap: int = EMBEDDING_CHUNK_OVERLAP,
) -> list[FileChunk]:
    """Chunk multiple files and return a flat list of all chunks."""
    all_chunks: list[FileChunk] = []
    for p in paths:
        all_chunks.extend(chunk_file(p, chunk_size, overlap))
    return all_chunks
