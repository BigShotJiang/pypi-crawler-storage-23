"""
Vector Store — FAISS-backed Embedding Search
===============================================
TOKEN SAVING STRATEGY:
  Instead of dumping an entire codebase into the LLM context, this module
  lets you embed file chunks into a FAISS index and retrieve ONLY the most
  semantically relevant fragments for a given query.

  The LLM sees 3–5 short snippets instead of thousands of lines.

  Architecture:
    • Uses faiss-cpu for fast similarity search (no GPU required).
    • Stores chunk metadata alongside vectors for retrieval.
    • Provides a plug-in point for any embedding model — by default it
      uses random vectors as a placeholder.  Replace `embed_text()` with
      your model of choice (OpenAI, sentence-transformers, etc.).
    • Supports persistence: save/load the index to/from disk.

  No external API calls are made by default — everything runs locally.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import numpy as np

try:
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False

from config import EMBEDDING_DIMENSION, FAISS_INDEX_PATH

logger = logging.getLogger("token_mcp.vector_store")


# ---------------------------------------------------------------------------
# Embedding function (PLUG-IN POINT)
# ---------------------------------------------------------------------------

def embed_text(text: str) -> np.ndarray:
    """Convert text into a dense vector.

    >>> vec = embed_text("hello world")
    >>> vec.shape
    (384,)

    PLUG-IN POINT: Replace this function body with your embedding model:

        # Example with sentence-transformers:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer("all-MiniLM-L6-v2")
        def embed_text(text: str) -> np.ndarray:
            return _model.encode(text)

        # Example with OpenAI:
        import openai
        def embed_text(text: str) -> np.ndarray:
            resp = openai.embeddings.create(model="text-embedding-3-small", input=text)
            return np.array(resp.data[0].embedding, dtype=np.float32)

    The default implementation uses a deterministic hash-based projection
    so that identical texts always map to the same vector.  This is NOT
    semantically meaningful — it's a placeholder for testing the pipeline.
    """
    # Deterministic pseudo-random vector seeded by text hash.
    seed = hash(text) & 0xFFFFFFFF
    rng = np.random.RandomState(seed)
    vec = rng.randn(EMBEDDING_DIMENSION).astype(np.float32)
    # L2-normalize for cosine-like similarity with FAISS IndexFlatIP.
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec /= norm
    return vec


# ---------------------------------------------------------------------------
# Vector Store
# ---------------------------------------------------------------------------

class VectorStore:
    """FAISS-backed vector store for code chunk retrieval.

    TOKEN SAVING: instead of sending entire files to the LLM, embed
    chunks and search for only the relevant ones.  The LLM receives
    3–5 small snippets instead of 10,000 lines.
    """

    def __init__(self, dimension: int = EMBEDDING_DIMENSION) -> None:
        if not FAISS_AVAILABLE:
            raise ImportError(
                "faiss-cpu is required.  Install with: pip install faiss-cpu"
            )

        self.dimension = dimension
        # Inner-product index — works with L2-normalized vectors for cosine similarity.
        self.index = faiss.IndexFlatIP(dimension)
        # Parallel metadata list: metadata[i] corresponds to vector i.
        self.metadata: list[dict[str, Any]] = []

        logger.info("VectorStore initialized (dim=%d)", dimension)

    @property
    def size(self) -> int:
        """Number of vectors in the index."""
        return self.index.ntotal

    def add(
        self,
        text: str,
        metadata: dict[str, Any] | None = None,
        vector: np.ndarray | None = None,
    ) -> int:
        """Add a text chunk (or pre-computed vector) to the index.

        Args:
            text: The text content to embed and store.
            metadata: Arbitrary metadata dict (file path, line range, etc.).
            vector: Optional pre-computed embedding.  If None, embed_text is called.

        Returns:
            The index position of the added vector.
        """
        if vector is None:
            vector = embed_text(text)

        vector = vector.astype(np.float32).reshape(1, -1)
        self.index.add(vector)
        self.metadata.append({
            "text": text[:500],  # Store a preview, not the full chunk (saves memory)
            **(metadata or {}),
        })

        return self.index.ntotal - 1

    def add_batch(
        self,
        texts: list[str],
        metadatas: list[dict[str, Any]] | None = None,
    ) -> int:
        """Add multiple texts at once.  More efficient than individual adds.

        Returns:
            Number of vectors added.
        """
        if not texts:
            return 0

        vectors = np.array([embed_text(t) for t in texts], dtype=np.float32)
        self.index.add(vectors)

        metas = metadatas or [{} for _ in texts]
        for text, meta in zip(texts, metas):
            self.metadata.append({"text": text[:500], **meta})

        logger.info("add_batch: added %d vectors (total=%d)", len(texts), self.size)
        return len(texts)

    def search(
        self,
        query: str,
        top_k: int = 5,
        query_vector: np.ndarray | None = None,
    ) -> list[dict[str, Any]]:
        """Find the top_k most similar chunks to the query.

        TOKEN SAVING: returns only the best matches with their metadata,
        not the entire corpus.

        Args:
            query: Query text to search for.
            top_k: Number of results to return.
            query_vector: Optional pre-computed query embedding.

        Returns:
            List of dicts with "score", "text", and any stored metadata.
        """
        if self.index.ntotal == 0:
            return []

        if query_vector is None:
            query_vector = embed_text(query)

        query_vector = query_vector.astype(np.float32).reshape(1, -1)
        top_k = min(top_k, self.index.ntotal)

        scores, indices = self.index.search(query_vector, top_k)

        results: list[dict[str, Any]] = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            entry = {
                "score": float(score),
                **self.metadata[idx],
            }
            results.append(entry)

        return results

    def clear(self) -> None:
        """Remove all vectors and metadata."""
        self.index.reset()
        self.metadata.clear()
        logger.info("VectorStore cleared.")

    def save(self, path: str | Path | None = None) -> None:
        """Persist the FAISS index and metadata to disk.

        Args:
            path: Directory to save into.  Defaults to FAISS_INDEX_PATH.
        """
        save_dir = Path(path) if path else FAISS_INDEX_PATH
        save_dir.mkdir(parents=True, exist_ok=True)

        faiss.write_index(self.index, str(save_dir / "index.faiss"))

        with open(save_dir / "metadata.json", "w") as f:
            json.dump(self.metadata, f, ensure_ascii=False)

        logger.info("VectorStore saved to %s (%d vectors)", save_dir, self.size)

    def load(self, path: str | Path | None = None) -> None:
        """Load a FAISS index and metadata from disk.

        Args:
            path: Directory to load from.  Defaults to FAISS_INDEX_PATH.
        """
        load_dir = Path(path) if path else FAISS_INDEX_PATH
        index_file = load_dir / "index.faiss"
        meta_file = load_dir / "metadata.json"

        if not index_file.is_file():
            logger.warning("No saved index found at %s", load_dir)
            return

        self.index = faiss.read_index(str(index_file))

        if meta_file.is_file():
            with open(meta_file, "r") as f:
                self.metadata = json.load(f)

        logger.info("VectorStore loaded from %s (%d vectors)", load_dir, self.size)
