"""Memory subpackage — conversation summary store."""
