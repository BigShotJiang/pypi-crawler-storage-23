"""
Memory Manager — Conversation Summary Store
=============================================
TOKEN SAVING STRATEGY:
  Lets the LLM store and retrieve COMPRESSED SUMMARIES instead of
  replaying the full conversation history on every turn.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from pathlib import Path

import aiofiles

from token_optimizer_mcp.config import CACHE_DIR, MAX_MEMORY_ENTRIES, MAX_OUTPUT_CHARS
from token_optimizer_mcp.app import mcp
from token_optimizer_mcp.utils.token_tracker import record_savings

logger = logging.getLogger("token_optimizer_mcp.memory")

MEMORY_FILE: Path = CACHE_DIR / "memory.json"


async def _load_memories() -> list[dict]:
    """Load all stored memories from disk."""
    if not MEMORY_FILE.is_file():
        return []
    try:
        async with aiofiles.open(MEMORY_FILE, "r") as f:
            return json.loads(await f.read())
    except Exception:
        return []


async def _save_memories(memories: list[dict]) -> None:
    """Persist memories to disk."""
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    async with aiofiles.open(MEMORY_FILE, "w") as f:
        await f.write(json.dumps(memories, indent=2, ensure_ascii=False))


@mcp.tool()
async def save_memory(
    summary: str,
    session_id: str = "",
    tags: str = "",
) -> str:
    """Store a compressed conversation summary for later retrieval.

    Instead of carrying the full conversation history, the LLM can
    save key points here and retrieve them when needed — dramatically
    reducing context-window usage.

    Args:
        summary: The compressed summary text to store.
        session_id: Optional session identifier.  Auto-generated if empty.
        tags: Optional comma-separated tags for filtering.

    Returns:
        JSON confirmation with the assigned memory ID and token savings.
    """
    memories = await _load_memories()

    entry = {
        "id": str(uuid.uuid4())[:8],
        "session_id": session_id or str(uuid.uuid4())[:8],
        "summary": summary[:MAX_OUTPUT_CHARS],
        "tags": [t.strip() for t in tags.split(",") if t.strip()] if tags else [],
        "timestamp": time.time(),
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }

    memories.append(entry)
    await _save_memories(memories)

    logger.info("save_memory: stored entry %s", entry["id"])

    result: dict = {"status": "saved", "id": entry["id"]}

    estimated_full = summary * 5
    output = json.dumps(result, ensure_ascii=False)
    stats = record_savings("save_memory", estimated_full, output)
    result.update(stats)

    return json.dumps(result, ensure_ascii=False)


@mcp.tool()
async def get_memory(
    session_id: str = "",
    tag: str = "",
    limit: int = 0,
) -> str:
    """Retrieve stored conversation summaries.

    Returns only the compressed summaries — never the full original
    conversation.  Most recent entries first.

    Args:
        session_id: Filter by session.  Empty = all sessions.
        tag: Filter by tag.  Empty = all tags.
        limit: Max entries to return.  0 = use MAX_MEMORY_ENTRIES.

    Returns:
        JSON list of summary entries, capped for token efficiency,
        with token savings statistics.
    """
    memories = await _load_memories()
    all_memories_text = json.dumps(memories, ensure_ascii=False)

    if session_id:
        memories = [m for m in memories if m.get("session_id") == session_id]
    if tag:
        memories = [m for m in memories if tag in m.get("tags", [])]

    cap = limit if limit > 0 else MAX_MEMORY_ENTRIES
    memories = sorted(memories, key=lambda m: m.get("timestamp", 0), reverse=True)[:cap]

    result: dict = {
        "total_stored": len(await _load_memories()),
        "returned": len(memories),
        "memories": memories,
    }

    output = json.dumps(result, ensure_ascii=False)
    stats = record_savings("get_memory", all_memories_text, output)
    result.update(stats)

    output = json.dumps(result, ensure_ascii=False)
    if len(output) > MAX_OUTPUT_CHARS:
        output = output[:MAX_OUTPUT_CHARS] + "\n... [TRUNCATED]"
    return output


@mcp.tool()
async def clear_memory(session_id: str = "") -> str:
    """Clear stored conversation summaries.

    Args:
        session_id: If provided, only clear entries for this session.
                     Empty = clear ALL memories.

    Returns:
        JSON confirmation with count of cleared entries.
    """
    memories = await _load_memories()
    original_count = len(memories)

    if session_id:
        memories = [m for m in memories if m.get("session_id") != session_id]
    else:
        memories = []

    await _save_memories(memories)
    cleared = original_count - len(memories)

    logger.info("clear_memory: cleared %d entries", cleared)
    return json.dumps({"status": "cleared", "entries_removed": cleared})
