"""
Token Optimizer MCP — A production-ready MCP server that minimises
LLM token usage and API cost when working with large codebases.
"""

__version__ = "0.1.0"
