"""Tests for the P21 APIs service."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api import AugurAPI
from augur_api.services.p21_apis import (
    EntityContactsRefreshResponse,
    EntityContactsResource,
    EntityCustomersRefreshResponse,
    EntityCustomersResource,
    HealthCheckData,
    TransCategory,
    TransCategoryCreateParams,
    TransCategoryParams,
    TransCategoryResource,
    TransCategoryUpdateParams,
    TransCompany,
    TransCompanyCreateParams,
    TransCompanyParams,
    TransCompanyResource,
    TransCompanyUpdateParams,
    TransPurchaseOrderReceipt,
    TransPurchaseOrderReceiptParams,
    TransPurchaseOrderReceiptResource,
    TransPurchaseOrderReceiptUpdateParams,
    TransUser,
    TransUserCreateParams,
    TransUserParams,
    TransUserResource,
    TransUserUpdateParams,
    TransWebDisplayType,
    TransWebDisplayTypeCreateParams,
    TransWebDisplayTypeDefaults,
    TransWebDisplayTypeDefinition,
    TransWebDisplayTypeParams,
    TransWebDisplayTypeResource,
    TransWebDisplayTypeUpdateParams,
)


def mock_response(data: Any) -> dict[str, Any]:
    """Create a mock API response with all required fields."""
    return {
        "count": 1 if not isinstance(data, list) else len(data),
        "data": data,
        "message": "Success",
        "options": [],
        "params": [],
        "status": 200,
        "total": 1 if not isinstance(data, list) else len(data),
        "totalResults": 1 if not isinstance(data, list) else len(data),
    }


# =============================================================================
# Schema Tests
# =============================================================================


class TestHealthCheckDataSchema:
    """Tests for HealthCheckData schema."""

    def test_with_all_fields(self) -> None:
        obj = HealthCheckData(site_hash="abc123", site_id="site1")
        assert obj.site_hash == "abc123"
        assert obj.site_id == "site1"

    def test_with_none_values(self) -> None:
        obj = HealthCheckData()
        assert obj.site_hash is None
        assert obj.site_id is None


class TestEntityContactsSchemas:
    """Tests for entity contacts schemas."""

    def test_refresh_response_model(self) -> None:
        obj = EntityContactsRefreshResponse()
        assert obj is not None


class TestEntityCustomersSchemas:
    """Tests for entity customers schemas."""

    def test_refresh_response_model(self) -> None:
        obj = EntityCustomersRefreshResponse()
        assert obj is not None


class TestTransCategorySchemas:
    """Tests for trans category schemas."""

    def test_params(self) -> None:
        obj = TransCategoryParams(category_id="CAT001")
        assert obj.category_id == "CAT001"

    def test_params_defaults(self) -> None:
        obj = TransCategoryParams()
        assert obj.category_id is None

    def test_model(self) -> None:
        obj = TransCategory(category_uid=1)
        assert obj.category_uid == 1

    def test_create_params(self) -> None:
        obj = TransCategoryCreateParams()
        assert obj is not None

    def test_update_params(self) -> None:
        obj = TransCategoryUpdateParams()
        assert obj is not None


class TestTransCompanySchemas:
    """Tests for trans company schemas."""

    def test_params(self) -> None:
        obj = TransCompanyParams(company_id="COMP001")
        assert obj.company_id == "COMP001"

    def test_params_defaults(self) -> None:
        obj = TransCompanyParams()
        assert obj.company_id is None

    def test_model(self) -> None:
        obj = TransCompany(company_uid=1)
        assert obj.company_uid == 1

    def test_create_params(self) -> None:
        obj = TransCompanyCreateParams()
        assert obj is not None

    def test_update_params(self) -> None:
        obj = TransCompanyUpdateParams()
        assert obj is not None


class TestTransPurchaseOrderReceiptSchemas:
    """Tests for trans purchase order receipt schemas."""

    def test_params(self) -> None:
        # TransPurchaseOrderReceiptParams has no query params
        obj = TransPurchaseOrderReceiptParams()
        assert obj is not None

    def test_params_defaults(self) -> None:
        obj = TransPurchaseOrderReceiptParams()
        assert obj is not None

    def test_model(self) -> None:
        obj = TransPurchaseOrderReceipt(po_no="PO123")
        assert obj.po_no == "PO123"

    def test_update_params(self) -> None:
        obj = TransPurchaseOrderReceiptUpdateParams()
        assert obj is not None


class TestTransUserSchemas:
    """Tests for trans user schemas."""

    def test_params(self) -> None:
        obj = TransUserParams(user_id="USER001")
        assert obj.user_id == "USER001"

    def test_params_defaults(self) -> None:
        obj = TransUserParams()
        assert obj.user_id is None

    def test_model(self) -> None:
        obj = TransUser(users_uid=1)
        assert obj.users_uid == 1

    def test_create_params(self) -> None:
        obj = TransUserCreateParams()
        assert obj is not None

    def test_update_params(self) -> None:
        obj = TransUserUpdateParams()
        assert obj is not None


class TestTransWebDisplayTypeSchemas:
    """Tests for trans web display type schemas."""

    def test_params(self) -> None:
        obj = TransWebDisplayTypeParams(web_display_type_id="WDT001")
        assert obj.web_display_type_id == "WDT001"

    def test_params_defaults(self) -> None:
        obj = TransWebDisplayTypeParams()
        assert obj.web_display_type_id is None

    def test_model(self) -> None:
        obj = TransWebDisplayType(web_display_type_uid=1)
        assert obj.web_display_type_uid == 1

    def test_create_params(self) -> None:
        obj = TransWebDisplayTypeCreateParams()
        assert obj is not None

    def test_update_params(self) -> None:
        obj = TransWebDisplayTypeUpdateParams()
        assert obj is not None

    def test_defaults_model(self) -> None:
        obj = TransWebDisplayTypeDefaults()
        assert obj is not None

    def test_definition_model(self) -> None:
        obj = TransWebDisplayTypeDefinition()
        assert obj is not None


# =============================================================================
# Client Tests
# =============================================================================


class TestP21ApisClient:
    """Tests for P21ApisClient base functionality."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(self, api: AugurAPI) -> None:
        api.p21_apis._http.get = MagicMock(
            return_value=mock_response({"siteHash": "abc", "siteId": "site1"})
        )
        result = api.p21_apis.health_check()
        assert result.data.site_hash == "abc"

    def test_ping(self, api: AugurAPI) -> None:
        api.p21_apis._http.get = MagicMock(return_value=mock_response("pong"))
        result = api.p21_apis.ping()
        assert result.data == "pong"

    def test_whoami(self, api: AugurAPI) -> None:
        api.p21_apis._http.get = MagicMock(return_value=mock_response({"user": "test"}))
        result = api.p21_apis.whoami()
        assert result.data is not None


class TestP21ApisClientProperties:
    """Tests for P21ApisClient property accessors."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        return AugurAPI(token="test-token", site_id="test-site")

    def test_entity_contacts_property_returns_same_instance(self, api: AugurAPI) -> None:
        first = api.p21_apis.entity_contacts
        second = api.p21_apis.entity_contacts
        assert first is second
        assert isinstance(first, EntityContactsResource)

    def test_entity_customers_property_returns_same_instance(self, api: AugurAPI) -> None:
        first = api.p21_apis.entity_customers
        second = api.p21_apis.entity_customers
        assert first is second
        assert isinstance(first, EntityCustomersResource)

    def test_trans_category_property_returns_same_instance(self, api: AugurAPI) -> None:
        first = api.p21_apis.trans_category
        second = api.p21_apis.trans_category
        assert first is second
        assert isinstance(first, TransCategoryResource)

    def test_trans_company_property_returns_same_instance(self, api: AugurAPI) -> None:
        first = api.p21_apis.trans_company
        second = api.p21_apis.trans_company
        assert first is second
        assert isinstance(first, TransCompanyResource)

    def test_trans_purchase_order_receipt_property_returns_same_instance(
        self, api: AugurAPI
    ) -> None:
        first = api.p21_apis.trans_purchase_order_receipt
        second = api.p21_apis.trans_purchase_order_receipt
        assert first is second
        assert isinstance(first, TransPurchaseOrderReceiptResource)

    def test_trans_user_property_returns_same_instance(self, api: AugurAPI) -> None:
        first = api.p21_apis.trans_user
        second = api.p21_apis.trans_user
        assert first is second
        assert isinstance(first, TransUserResource)

    def test_trans_web_display_type_property_returns_same_instance(self, api: AugurAPI) -> None:
        first = api.p21_apis.trans_web_display_type
        second = api.p21_apis.trans_web_display_type
        assert first is second
        assert isinstance(first, TransWebDisplayTypeResource)


# =============================================================================
# Resource Tests
# =============================================================================


class TestEntityContactsResource:
    """Tests for EntityContactsResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> EntityContactsResource:
        return EntityContactsResource(mock_http)

    def test_refresh(self, resource: EntityContactsResource, mock_http: MagicMock) -> None:
        mock_http.get.return_value = mock_response({"refreshed": True})
        result = resource.refresh()
        mock_http.get.assert_called_once_with("/entity-contacts/refresh", params=None)
        assert result.data is not None


class TestEntityCustomersResource:
    """Tests for EntityCustomersResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> EntityCustomersResource:
        return EntityCustomersResource(mock_http)

    def test_refresh(self, resource: EntityCustomersResource, mock_http: MagicMock) -> None:
        mock_http.get.return_value = mock_response({"refreshed": True})
        result = resource.refresh()
        mock_http.get.assert_called_once_with("/entity-customers/refresh", params=None)
        assert result.data is not None


class TestTransCategoryResource:
    """Tests for TransCategoryResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> TransCategoryResource:
        return TransCategoryResource(mock_http)

    def test_get(self, resource: TransCategoryResource, mock_http: MagicMock) -> None:
        mock_http.get.return_value = mock_response({"categoryUid": 1})
        result = resource.get(1)
        mock_http.get.assert_called_once_with("/trans-category/1", params=None)
        assert result.data.category_uid == 1

    def test_create(self, resource: TransCategoryResource, mock_http: MagicMock) -> None:
        mock_http.post.return_value = mock_response({"categoryUid": 1})
        data = TransCategoryCreateParams()
        result = resource.create(data)
        mock_http.post.assert_called_once()
        assert result.data.category_uid == 1

    def test_update(self, resource: TransCategoryResource, mock_http: MagicMock) -> None:
        mock_http.put.return_value = mock_response({"categoryUid": 1})
        data = TransCategoryUpdateParams()
        result = resource.update(1, data)
        mock_http.put.assert_called_once()
        assert result.data.category_uid == 1

    def test_delete(self, resource: TransCategoryResource, mock_http: MagicMock) -> None:
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        mock_http.delete.assert_called_once_with("/trans-category/1", params=None)
        assert result.data is True


class TestTransCompanyResource:
    """Tests for TransCompanyResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> TransCompanyResource:
        return TransCompanyResource(mock_http)

    def test_get(self, resource: TransCompanyResource, mock_http: MagicMock) -> None:
        mock_http.get.return_value = mock_response({"companyUid": 1})
        result = resource.get(1)
        mock_http.get.assert_called_once_with("/trans-company/1", params=None)
        assert result.data.company_uid == 1

    def test_create(self, resource: TransCompanyResource, mock_http: MagicMock) -> None:
        mock_http.post.return_value = mock_response({"companyUid": 1})
        data = TransCompanyCreateParams()
        result = resource.create(data)
        mock_http.post.assert_called_once()
        assert result.data.company_uid == 1

    def test_update(self, resource: TransCompanyResource, mock_http: MagicMock) -> None:
        mock_http.put.return_value = mock_response({"companyUid": 1})
        data = TransCompanyUpdateParams()
        result = resource.update(1, data)
        mock_http.put.assert_called_once()
        assert result.data.company_uid == 1

    def test_delete(self, resource: TransCompanyResource, mock_http: MagicMock) -> None:
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        mock_http.delete.assert_called_once_with("/trans-company/1", params=None)
        assert result.data is True


class TestTransPurchaseOrderReceiptResource:
    """Tests for TransPurchaseOrderReceiptResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> TransPurchaseOrderReceiptResource:
        return TransPurchaseOrderReceiptResource(mock_http)

    def test_get(self, resource: TransPurchaseOrderReceiptResource, mock_http: MagicMock) -> None:
        mock_http.get.return_value = mock_response({"poNo": "PO123"})
        result = resource.get("PO123")
        mock_http.get.assert_called_once_with("/trans-purchase-order-receipt/PO123", params=None)
        assert result.data.po_no == "PO123"

    def test_update(
        self, resource: TransPurchaseOrderReceiptResource, mock_http: MagicMock
    ) -> None:
        mock_http.put.return_value = mock_response({"poNo": "PO123"})
        data = TransPurchaseOrderReceiptUpdateParams()
        result = resource.update("PO123", data)
        mock_http.put.assert_called_once()
        assert result.data.po_no == "PO123"


class TestTransUserResource:
    """Tests for TransUserResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> TransUserResource:
        return TransUserResource(mock_http)

    def test_get(self, resource: TransUserResource, mock_http: MagicMock) -> None:
        mock_http.get.return_value = mock_response({"usersUid": 1})
        result = resource.get(1)
        mock_http.get.assert_called_once_with("/trans-user/1", params=None)
        assert result.data.users_uid == 1

    def test_create(self, resource: TransUserResource, mock_http: MagicMock) -> None:
        mock_http.post.return_value = mock_response({"usersUid": 1})
        data = TransUserCreateParams()
        result = resource.create(data)
        mock_http.post.assert_called_once()
        assert result.data.users_uid == 1

    def test_update(self, resource: TransUserResource, mock_http: MagicMock) -> None:
        mock_http.put.return_value = mock_response({"usersUid": 1})
        data = TransUserUpdateParams()
        result = resource.update(1, data)
        mock_http.put.assert_called_once()
        assert result.data.users_uid == 1

    def test_delete(self, resource: TransUserResource, mock_http: MagicMock) -> None:
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        mock_http.delete.assert_called_once_with("/trans-user/1", params=None)
        assert result.data is True


class TestTransWebDisplayTypeResource:
    """Tests for TransWebDisplayTypeResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> TransWebDisplayTypeResource:
        return TransWebDisplayTypeResource(mock_http)

    def test_get(self, resource: TransWebDisplayTypeResource, mock_http: MagicMock) -> None:
        mock_http.get.return_value = mock_response({"webDisplayTypeUid": 1})
        result = resource.get(1)
        mock_http.get.assert_called_once_with("/trans-web-display-type/1", params=None)
        assert result.data.web_display_type_uid == 1

    def test_create(self, resource: TransWebDisplayTypeResource, mock_http: MagicMock) -> None:
        mock_http.post.return_value = mock_response({"webDisplayTypeUid": 1})
        data = TransWebDisplayTypeCreateParams()
        result = resource.create(data)
        mock_http.post.assert_called_once()
        assert result.data.web_display_type_uid == 1

    def test_update(self, resource: TransWebDisplayTypeResource, mock_http: MagicMock) -> None:
        mock_http.put.return_value = mock_response({"webDisplayTypeUid": 1})
        data = TransWebDisplayTypeUpdateParams()
        result = resource.update(1, data)
        mock_http.put.assert_called_once()
        assert result.data.web_display_type_uid == 1

    def test_delete(self, resource: TransWebDisplayTypeResource, mock_http: MagicMock) -> None:
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        mock_http.delete.assert_called_once_with("/trans-web-display-type/1", params=None)
        assert result.data is True

    def test_get_defaults(
        self, resource: TransWebDisplayTypeResource, mock_http: MagicMock
    ) -> None:
        mock_http.get.return_value = mock_response({"default": "value"})
        result = resource.get_defaults()
        mock_http.get.assert_called_once_with("/trans-web-display-type/defaults", params=None)
        assert result.data is not None

    def test_get_definition(
        self, resource: TransWebDisplayTypeResource, mock_http: MagicMock
    ) -> None:
        mock_http.get.return_value = mock_response({"definition": "value"})
        result = resource.get_definition()
        mock_http.get.assert_called_once_with("/trans-web-display-type/definition", params=None)
        assert result.data is not None
