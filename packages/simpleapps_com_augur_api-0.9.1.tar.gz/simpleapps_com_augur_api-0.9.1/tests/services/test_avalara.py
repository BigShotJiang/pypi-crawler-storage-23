"""Tests for the Avalara service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.avalara import (
    RatesParams,
    TaxRate,
)
from augur_api.services.avalara.schemas import HealthCheckData


class TestAvalaraSchemas:
    """Tests for Avalara schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"
        assert result.site_hash == "abc123"

    def test_rates_params(self) -> None:
        """Should create rates params."""
        params = RatesParams(
            line1="123 Main St",
            city="Seattle",
            region="WA",
            postal_code="98101",
            country="US",
        )
        assert params.line1 == "123 Main St"
        assert params.city == "Seattle"
        assert params.postal_code == "98101"

    def test_rates_params_defaults(self) -> None:
        """Should have None defaults."""
        params = RatesParams()
        assert params.line1 is None
        assert params.city is None
        assert params.postal_code is None

    def test_tax_rate_model(self) -> None:
        """Should parse tax rate data."""
        data = {
            "totalRate": 0.102,
            "stateRate": 0.065,
            "countyRate": 0.02,
            "cityRate": 0.01,
            "specialRate": 0.007,
        }
        result = TaxRate.model_validate(data)
        assert result.total_rate == 0.102
        assert result.state_rate == 0.065
        assert result.county_rate == 0.02
        assert result.city_rate == 0.01
        assert result.special_rate == 0.007


class TestAvalaraClient:
    """Tests for AvalaraClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://avalara.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.avalara.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://avalara.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.avalara.ping()
        assert response.data == "pong"

    def test_whoami(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should call whoami endpoint."""
        mock_response = {
            "count": 1,
            "data": {"user_id": "test-user", "email": "test@example.com"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://avalara.augur-api.com/whoami",
            json=mock_response,
        )
        response = api.avalara.whoami()
        assert response.data["user_id"] == "test-user"

    def test_rates_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should calculate tax rates."""
        mock_response = {
            "count": 1,
            "data": {
                "totalRate": 0.102,
                "stateRate": 0.065,
                "countyRate": 0.02,
                "cityRate": 0.01,
                "specialRate": 0.007,
            },
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            method="POST",
            url="https://avalara.augur-api.com/rates",
            json=mock_response,
        )
        response = api.avalara.rates.create(RatesParams())
        assert response.data.total_rate == 0.102

    def test_rates_create_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should calculate tax rates with address params."""
        mock_response = {
            "count": 1,
            "data": {
                "totalRate": 0.102,
                "stateRate": 0.065,
            },
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            method="POST",
            url="https://avalara.augur-api.com/rates",
            json=mock_response,
        )
        params = RatesParams(postal_code="98101")
        response = api.avalara.rates.create(params)
        assert response.data.total_rate == 0.102

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.avalara
        assert client.rates is client.rates
