"""Tests for the Payments service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.payments.schemas import (
    AccountQueryData,
    AccountQueryParams,
    BillingUpdateParams,
    CardInfoData,
    CardInfoParams,
    ElementPaymentParams,
    ElementPaymentResponse,
    HealthCheckData,
    MonerisData,
    PaytraceAuthorizationParams,
    PaytraceCaptureParams,
    PaytraceRefundParams,
    PaytraceResponse,
    PaytraceSaleParams,
    PaytraceVoidParams,
    PreAuthCompleteParams,
    PreAuthParams,
    SurchargeData,
    SurchargeParams,
    TransactionSetupData,
    TransactionSetupParams,
    ValidateParams,
)


class TestPaymentsSchemas:
    """Tests for Payments schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    # Element schemas
    def test_element_payment_params(self) -> None:
        """Should create element payment params (passthrough)."""
        params = ElementPaymentParams(custom_field="value")
        assert params.model_dump()["custom_field"] == "value"

    def test_element_payment_response(self) -> None:
        """Should parse element payment response (passthrough)."""
        data = {"result": "success", "transactionId": "elem-123"}
        result = ElementPaymentResponse.model_validate(data)
        assert result is not None

    # Moneris schemas
    def test_pre_auth_params(self) -> None:
        """Should create pre-auth params."""
        params = PreAuthParams(
            amount=100.00,
            cc_number="4111111111111111",
            exp_date="1225",
            order_id="ORD-123",
            test_mode=True,
        )
        assert params.amount == 100.00
        assert params.cc_number == "4111111111111111"
        assert params.test_mode is True

    def test_pre_auth_complete_params(self) -> None:
        """Should create pre-auth complete params."""
        params = PreAuthCompleteParams(
            amount=100.00,
            order_id="ORD-123",
            txn_number="TXN-456",
        )
        assert params.amount == 100.00
        assert params.txn_number == "TXN-456"

    def test_moneris_data(self) -> None:
        """Should parse moneris data (passthrough)."""
        data = {"responseCode": "00", "message": "Approved"}
        result = MonerisData.model_validate(data)
        assert result is not None

    # Paytrace schemas
    def test_paytrace_authorization_params(self) -> None:
        """Should create paytrace authorization params (passthrough)."""
        params = PaytraceAuthorizationParams(amount="100.00", card_number="4111")
        assert params is not None

    def test_paytrace_capture_params(self) -> None:
        """Should create paytrace capture params (passthrough)."""
        params = PaytraceCaptureParams(transaction_id="txn-123")
        assert params is not None

    def test_paytrace_refund_params(self) -> None:
        """Should create paytrace refund params (passthrough)."""
        params = PaytraceRefundParams(transaction_id="txn-123", amount="50.00")
        assert params is not None

    def test_paytrace_sale_params(self) -> None:
        """Should create paytrace sale params (passthrough)."""
        params = PaytraceSaleParams(amount="100.00")
        assert params is not None

    def test_paytrace_void_params(self) -> None:
        """Should create paytrace void params (passthrough)."""
        params = PaytraceVoidParams(transaction_id="txn-123")
        assert params is not None

    def test_paytrace_response(self) -> None:
        """Should parse paytrace response (passthrough)."""
        data = {"success": True, "transactionId": "pt-123"}
        result = PaytraceResponse.model_validate(data)
        assert result is not None

    # Unified schemas
    def test_transaction_setup_params(self) -> None:
        """Should create transaction setup params."""
        params = TransactionSetupParams(customer_id="CUST001", mode="dev")
        assert params.customer_id == "CUST001"
        assert params.mode == "dev"

    def test_transaction_setup_data(self) -> None:
        """Should parse transaction setup data."""
        data = {"transactionSetupId": "txn-123"}
        result = TransactionSetupData.model_validate(data)
        assert result.transaction_setup_id == "txn-123"

    def test_account_query_params(self) -> None:
        """Should create account query params."""
        params = AccountQueryParams(
            customer_id="CUST001", transaction_setup_id="txn-123", mode="live"
        )
        assert params.customer_id == "CUST001"
        assert params.transaction_setup_id == "txn-123"

    def test_account_query_data(self) -> None:
        """Should parse account query data (passthrough)."""
        data = {"PaymentAccountID": "acc-123"}
        result = AccountQueryData.model_validate(data)
        # Passthrough - field name doesn't convert to snake_case
        assert result is not None

    def test_billing_update_params(self) -> None:
        """Should create billing update params."""
        params = BillingUpdateParams(
            transaction_setup_id="txn-123",
            address1="123 Main St",
            city="New York",
            state="NY",
            zip="10001",
        )
        assert params.address1 == "123 Main St"
        assert params.city == "New York"

    def test_card_info_params(self) -> None:
        """Should create card info params."""
        params = CardInfoParams(transaction_setup_id="txn-123", mode="dev")
        assert params.transaction_setup_id == "txn-123"

    def test_card_info_data(self) -> None:
        """Should parse card info data (passthrough)."""
        data = {"cardType": "Visa", "lastFour": "4242"}
        result = CardInfoData.model_validate(data)
        assert result is not None

    def test_surcharge_params(self) -> None:
        """Should create surcharge params."""
        params = SurchargeParams(
            customer_id="CUST001",
            payment_account_id="acc-123",
            amount="100.00",
            from_state="CA",
            to_state="NY",
            country="US",
        )
        assert params.customer_id == "CUST001"
        assert params.amount == "100.00"

    def test_surcharge_data(self) -> None:
        """Should parse surcharge data (passthrough)."""
        data = {"surchargeAmount": 3.50, "totalAmount": 103.50}
        result = SurchargeData.model_validate(data)
        assert result is not None

    def test_validate_params(self) -> None:
        """Should create validate params."""
        params = ValidateParams(customer_id="CUST001", transaction_setup_id="txn-123", mode="dev")
        assert params.customer_id == "CUST001"


class TestPaymentsClient:
    """Tests for PaymentsClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://payments.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.payments.health_check()
        assert response.data.site_id == "test-site"

    # Element tests
    def test_element_payment_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create element payment."""
        mock_response = {
            "count": 1,
            "data": {"transactionId": "elem-123", "status": "approved"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/element/payment",
            json=mock_response,
            method="POST",
        )
        response = api.payments.element.payment.create(ElementPaymentParams())
        assert response.data is not None

    # Moneris tests
    def test_moneris_pre_auth_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get moneris pre-auth."""
        mock_response = {
            "count": 1,
            "data": {"responseCode": "00", "message": "Approved"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/moneris/pre-auth?amount=100.0&cc_number=4111111111111111&exp_date=1225&order_id=ORD-123",
            json=mock_response,
            method="GET",
        )
        response = api.payments.moneris.pre_auth.get(
            PreAuthParams(
                amount=100.0,
                cc_number="4111111111111111",
                exp_date="1225",
                order_id="ORD-123",
            )
        )
        assert response.data is not None

    def test_moneris_pre_auth_complete_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should complete moneris pre-auth."""
        mock_response = {
            "count": 1,
            "data": {"responseCode": "00", "message": "Complete"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/moneris/pre-auth-complete?amount=100.0&order_id=ORD-123&txn_number=TXN-456",
            json=mock_response,
            method="GET",
        )
        response = api.payments.moneris.pre_auth_complete.get(
            PreAuthCompleteParams(
                amount=100.0,
                order_id="ORD-123",
                txn_number="TXN-456",
            )
        )
        assert response.data is not None

    # Paytrace tests
    def test_paytrace_authorization_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create paytrace authorization."""
        mock_response = {
            "count": 1,
            "data": {"success": True, "transactionId": "pt-123"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/paytrace/authorization",
            json=mock_response,
            method="POST",
        )
        response = api.payments.paytrace.authorization.create(PaytraceAuthorizationParams())
        assert response.data is not None

    def test_paytrace_capture_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create paytrace capture."""
        mock_response = {
            "count": 1,
            "data": {"success": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/paytrace/capture",
            json=mock_response,
            method="POST",
        )
        response = api.payments.paytrace.capture.create(PaytraceCaptureParams())
        assert response.data is not None

    def test_paytrace_refund_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create paytrace refund."""
        mock_response = {
            "count": 1,
            "data": {"success": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/paytrace/refund",
            json=mock_response,
            method="POST",
        )
        response = api.payments.paytrace.refund.create(PaytraceRefundParams())
        assert response.data is not None

    def test_paytrace_sale_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create paytrace sale."""
        mock_response = {
            "count": 1,
            "data": {"success": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/paytrace/sale",
            json=mock_response,
            method="POST",
        )
        response = api.payments.paytrace.sale.create(PaytraceSaleParams())
        assert response.data is not None

    def test_paytrace_void_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create paytrace void."""
        mock_response = {
            "count": 1,
            "data": {"success": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/paytrace/void",
            json=mock_response,
            method="POST",
        )
        response = api.payments.paytrace.void.create(PaytraceVoidParams())
        assert response.data is not None

    # Unified tests
    def test_unified_transaction_setup_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get transaction setup."""
        mock_response = {
            "count": 1,
            "data": {"transactionSetupId": "txn-123"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/unified/transaction-setup?customer_id=CUST001",
            json=mock_response,
            method="GET",
        )
        response = api.payments.unified.transaction_setup.get(
            TransactionSetupParams(customer_id="CUST001")
        )
        assert response.data.transaction_setup_id == "txn-123"

    def test_unified_account_query_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get account query."""
        mock_response = {
            "count": 1,
            "data": {"PaymentAccountID": "acc-123"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/unified/account-query?customer_id=CUST001&transaction_setup_id=txn-123",
            json=mock_response,
            method="GET",
        )
        response = api.payments.unified.account_query.get(
            AccountQueryParams(customer_id="CUST001", transaction_setup_id="txn-123")
        )
        assert response.data is not None

    def test_unified_account_query_get_false(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should handle account query returning false."""
        mock_response = {
            "count": 1,
            "data": False,
            "message": "No accounts",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/unified/account-query?customer_id=CUST001&transaction_setup_id=txn-456",
            json=mock_response,
            method="GET",
        )
        response = api.payments.unified.account_query.get(
            AccountQueryParams(customer_id="CUST001", transaction_setup_id="txn-456")
        )
        assert response.data is False

    def test_unified_billing_update_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get billing update."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/unified/billing-update?transaction_setup_id=txn-123&address1=123+Main+St&city=New+York&state=NY&zip=10001",
            json=mock_response,
            method="GET",
        )
        response = api.payments.unified.billing_update.get(
            BillingUpdateParams(
                transaction_setup_id="txn-123",
                address1="123 Main St",
                city="New York",
                state="NY",
                zip="10001",
            )
        )
        assert response.data is True

    def test_unified_card_info_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get card info."""
        mock_response = {
            "count": 1,
            "data": {"cardType": "Visa", "lastFour": "4242"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/unified/card-info?transaction_setup_id=txn-123",
            json=mock_response,
            method="GET",
        )
        response = api.payments.unified.card_info.get(
            CardInfoParams(transaction_setup_id="txn-123")
        )
        assert response.data is not None

    def test_unified_surcharge_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get surcharge."""
        mock_response = {
            "count": 1,
            "data": {"surchargeAmount": 3.50, "totalAmount": 103.50},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/unified/surcharge?customer_id=CUST001&payment_account_id=acc-123&amount=100.00&from_state=CA&to_state=NY&country=US",
            json=mock_response,
            method="GET",
        )
        response = api.payments.unified.surcharge.get(
            SurchargeParams(
                customer_id="CUST001",
                payment_account_id="acc-123",
                amount="100.00",
                from_state="CA",
                to_state="NY",
                country="US",
            )
        )
        assert response.data is not None

    def test_unified_validate_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should validate transaction."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://payments.augur-api.com/unified/validate?customer_id=CUST001&transaction_setup_id=txn-123",
            json=mock_response,
            method="GET",
        )
        response = api.payments.unified.validate.get(
            ValidateParams(customer_id="CUST001", transaction_setup_id="txn-123")
        )
        assert response.data is True

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.payments
        assert client.unified is client.unified
        assert client.element is client.element
        assert client.moneris is client.moneris
        assert client.paytrace is client.paytrace

    def test_nested_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same nested resource instance on multiple accesses."""
        unified = api.payments.unified
        assert unified.transaction_setup is unified.transaction_setup
        assert unified.account_query is unified.account_query
        assert unified.billing_update is unified.billing_update
        assert unified.card_info is unified.card_info
        assert unified.surcharge is unified.surcharge
        assert unified.validate is unified.validate

        element = api.payments.element
        assert element.payment is element.payment

        moneris = api.payments.moneris
        assert moneris.pre_auth is moneris.pre_auth
        assert moneris.pre_auth_complete is moneris.pre_auth_complete

        paytrace = api.payments.paytrace
        assert paytrace.authorization is paytrace.authorization
        assert paytrace.capture is paytrace.capture
        assert paytrace.refund is paytrace.refund
        assert paytrace.sale is paytrace.sale
        assert paytrace.void is paytrace.void
