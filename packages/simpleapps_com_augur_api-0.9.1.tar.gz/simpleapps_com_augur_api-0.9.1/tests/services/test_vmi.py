"""Tests for the VMI service client."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.vmi import (
    # Schemas
    Distributor,
    DistributorCreateParams,
    DistributorEnableParams,
    DistributorListParams,
    # Resources
    DistributorProductsResource,
    DistributorsResource,
    DistributorUpdateParams,
    HealthCheckData,
    InventoryAdjustParams,
    InventoryAvailability,
    InventoryAvailabilityParams,
    InventoryReceiveParams,
    InvProfileHdr,
    InvProfileHdrCreateParams,
    InvProfileHdrListParams,
    InvProfileHdrResource,
    InvProfileHdrUpdateParams,
    InvProfileLine,
    InvProfileLineCreateParams,
    InvProfileLineListParams,
    InvProfileLineResource,
    InvProfileLineUpdateParams,
    InvProfileUploadResource,
    Product,
    ProductCreateParams,
    ProductEnableParams,
    ProductFindItem,
    ProductFindParams,
    ProductFindResource,
    ProductListParams,
    ProductsResource,
    ProductUpdateParams,
    ReplenishmentInfo,
    ReplenishmentParams,
    ReplenishParams,
    RestockHdr,
    RestockHdrCreateParams,
    RestockHdrListParams,
    RestockHdrResource,
    RestockHdrUpdateParams,
    Section,
    SectionCreateParams,
    SectionEnableParams,
    SectionListParams,
    SectionsResource,
    SectionUpdateParams,
    TransferParams,
    UsageParams,
    # Client
    VMIClient,
    Warehouse,
    WarehouseAdjustResource,
    WarehouseAvailabilityResource,
    WarehouseCreateParams,
    WarehouseEnableParams,
    WarehouseListParams,
    WarehouseReceiveResource,
    WarehouseReplenishResource,
    WarehouseResource,
    WarehouseTransferResource,
    WarehouseUpdateParams,
    WarehouseUsageResource,
    WarehouseUser,
    WarehouseUserCreateParams,
    WarehouseUserListParams,
    WarehouseUsersResource,
    WarehouseUserUpdateParams,
)


def mock_response(data: Any) -> dict[str, Any]:
    """Create a mock API response with all required fields."""
    return {
        "count": 1 if not isinstance(data, list) else len(data),
        "data": data,
        "message": "Success",
        "options": [],
        "params": [],
        "status": 200,
        "total": 1 if not isinstance(data, list) else len(data),
        "totalResults": 1 if not isinstance(data, list) else len(data),
    }


class TestHealthCheckDataSchema:
    """Tests for HealthCheckData schema."""

    def test_with_all_fields(self):
        """Test with all fields."""
        data = HealthCheckData(site_hash="abc123", site_id="SITE1")
        assert data.site_hash == "abc123"
        assert data.site_id == "SITE1"

    def test_with_optional_fields(self):
        """Test with optional fields."""
        data = HealthCheckData()
        assert data.site_hash is None
        assert data.site_id is None

    def test_extra_fields_allowed(self):
        """Test extra fields are allowed."""
        data = HealthCheckData(extra_field="value")
        assert data.extra_field == "value"


class TestWarehouseSchemas:
    """Tests for Warehouse schemas."""

    def test_warehouse_list_params(self):
        """Test WarehouseListParams."""
        params = WarehouseListParams(limit=10, offset=0, customer_id=123, status_cd=1)
        assert params.limit == 10
        assert params.offset == 0
        assert params.customer_id == 123
        assert params.status_cd == 1

    def test_warehouse(self):
        """Test Warehouse."""
        wh = Warehouse(warehouse_uid=1)
        assert wh.warehouse_uid == 1

    def test_warehouse_create_params(self):
        """Test WarehouseCreateParams."""
        params = WarehouseCreateParams(name="Test Warehouse")
        assert params.name == "Test Warehouse"

    def test_warehouse_update_params(self):
        """Test WarehouseUpdateParams."""
        params = WarehouseUpdateParams(name="Updated Warehouse")
        assert params.name == "Updated Warehouse"

    def test_warehouse_enable_params(self):
        """Test WarehouseEnableParams."""
        params = WarehouseEnableParams(status_cd=1)
        assert params.status_cd == 1


class TestWarehouseNestedSchemas:
    """Tests for Warehouse nested schemas."""

    def test_inventory_availability_params(self):
        """Test InventoryAvailabilityParams."""
        params = InventoryAvailabilityParams(q="search", limit=10, offset=0)
        assert params.q == "search"
        assert params.limit == 10

    def test_inventory_availability(self):
        """Test InventoryAvailability."""
        item = InventoryAvailability(products_uid=1)
        assert item.products_uid == 1

    def test_inventory_adjust_params(self):
        """Test InventoryAdjustParams."""
        params = InventoryAdjustParams(qty=10)
        assert params.qty == 10

    def test_inventory_receive_params(self):
        """Test InventoryReceiveParams."""
        params = InventoryReceiveParams(qty=10)
        assert params.qty == 10

    def test_replenishment_params(self):
        """Test ReplenishmentParams."""
        params = ReplenishmentParams(distributors_uid=1)
        assert params.distributors_uid == 1

    def test_replenishment_info(self):
        """Test ReplenishmentInfo."""
        info = ReplenishmentInfo(qty=100)
        assert info.qty == 100

    def test_replenish_params(self):
        """Test ReplenishParams."""
        params = ReplenishParams(qty=10)
        assert params.qty == 10

    def test_transfer_params(self):
        """Test TransferParams."""
        params = TransferParams(qty=10)
        assert params.qty == 10

    def test_usage_params(self):
        """Test UsageParams."""
        params = UsageParams(qty=10)
        assert params.qty == 10


class TestWarehouseUserSchemas:
    """Tests for Warehouse User schemas."""

    def test_warehouse_user_list_params(self):
        """Test WarehouseUserListParams."""
        params = WarehouseUserListParams(limit=10, offset=0, status_cd=1)
        assert params.limit == 10
        assert params.status_cd == 1

    def test_warehouse_user(self):
        """Test WarehouseUser."""
        user = WarehouseUser(warehouse_x_users_uid=1)
        assert user.warehouse_x_users_uid == 1

    def test_warehouse_user_create_params(self):
        """Test WarehouseUserCreateParams."""
        params = WarehouseUserCreateParams(user_id=1)
        assert params.user_id == 1

    def test_warehouse_user_update_params(self):
        """Test WarehouseUserUpdateParams."""
        params = WarehouseUserUpdateParams(status_cd=1)
        assert params.status_cd == 1


class TestDistributorSchemas:
    """Tests for Distributor schemas."""

    def test_distributor_list_params(self):
        """Test DistributorListParams."""
        params = DistributorListParams(limit=10, offset=0, customer_id=123, status_cd=1)
        assert params.limit == 10
        assert params.customer_id == 123

    def test_distributor(self):
        """Test Distributor."""
        dist = Distributor(distributors_uid=1)
        assert dist.distributors_uid == 1

    def test_distributor_create_params(self):
        """Test DistributorCreateParams."""
        params = DistributorCreateParams(name="Test Distributor")
        assert params.name == "Test Distributor"

    def test_distributor_update_params(self):
        """Test DistributorUpdateParams."""
        params = DistributorUpdateParams(name="Updated Distributor")
        assert params.name == "Updated Distributor"

    def test_distributor_enable_params(self):
        """Test DistributorEnableParams."""
        params = DistributorEnableParams(status_cd=1)
        assert params.status_cd == 1


class TestProductSchemas:
    """Tests for Product schemas."""

    def test_product_list_params(self):
        """Test ProductListParams."""
        params = ProductListParams(
            limit=10, offset=0, customer_id=123, distributors_uid=1, status_cd=1
        )
        assert params.limit == 10
        assert params.distributors_uid == 1

    def test_product(self):
        """Test Product."""
        prod = Product(products_uid=1)
        assert prod.products_uid == 1

    def test_product_create_params(self):
        """Test ProductCreateParams."""
        params = ProductCreateParams(name="Test Product")
        assert params.name == "Test Product"

    def test_product_update_params(self):
        """Test ProductUpdateParams."""
        params = ProductUpdateParams(name="Updated Product")
        assert params.name == "Updated Product"

    def test_product_enable_params(self):
        """Test ProductEnableParams."""
        params = ProductEnableParams(status_cd=1)
        assert params.status_cd == 1

    def test_product_find_params(self):
        """Test ProductFindParams."""
        params = ProductFindParams(customer_id=123, prefix="ABC")
        assert params.customer_id == 123
        assert params.prefix == "ABC"

    def test_product_find_item(self):
        """Test ProductFindItem."""
        item = ProductFindItem(item_id="ITEM1", item_type="product")
        assert item.item_id == "ITEM1"
        assert item.item_type == "product"


class TestInvProfileHdrSchemas:
    """Tests for InvProfileHdr schemas."""

    def test_inv_profile_hdr_list_params(self):
        """Test InvProfileHdrListParams."""
        params = InvProfileHdrListParams(limit=10, offset=0, customer_id=123)
        assert params.limit == 10
        assert params.customer_id == 123

    def test_inv_profile_hdr(self):
        """Test InvProfileHdr."""
        hdr = InvProfileHdr(inv_profile_hdr_uid=1)
        assert hdr.inv_profile_hdr_uid == 1

    def test_inv_profile_hdr_create_params(self):
        """Test InvProfileHdrCreateParams."""
        params = InvProfileHdrCreateParams(name="Test Profile")
        assert params.name == "Test Profile"

    def test_inv_profile_hdr_update_params(self):
        """Test InvProfileHdrUpdateParams."""
        params = InvProfileHdrUpdateParams(name="Updated Profile")
        assert params.name == "Updated Profile"


class TestInvProfileLineSchemas:
    """Tests for InvProfileLine schemas."""

    def test_inv_profile_line_list_params(self):
        """Test InvProfileLineListParams."""
        params = InvProfileLineListParams(limit=10, offset=0)
        assert params.limit == 10
        assert params.offset == 0

    def test_inv_profile_line(self):
        """Test InvProfileLine."""
        line = InvProfileLine(inv_profile_line_uid=1)
        assert line.inv_profile_line_uid == 1

    def test_inv_profile_line_create_params(self):
        """Test InvProfileLineCreateParams."""
        params = InvProfileLineCreateParams(item_id="ITEM1")
        assert params.item_id == "ITEM1"

    def test_inv_profile_line_update_params(self):
        """Test InvProfileLineUpdateParams."""
        params = InvProfileLineUpdateParams(item_id="ITEM2")
        assert params.item_id == "ITEM2"


class TestRestockHdrSchemas:
    """Tests for RestockHdr schemas."""

    def test_restock_hdr_list_params(self):
        """Test RestockHdrListParams."""
        params = RestockHdrListParams(limit=10, offset=0, warehouse_uid=1, distributors_uid=2)
        assert params.limit == 10
        assert params.warehouse_uid == 1
        assert params.distributors_uid == 2

    def test_restock_hdr(self):
        """Test RestockHdr."""
        hdr = RestockHdr(restock_hdr_uid=1)
        assert hdr.restock_hdr_uid == 1

    def test_restock_hdr_create_params(self):
        """Test RestockHdrCreateParams."""
        params = RestockHdrCreateParams(name="Test Restock")
        assert params.name == "Test Restock"

    def test_restock_hdr_update_params(self):
        """Test RestockHdrUpdateParams."""
        params = RestockHdrUpdateParams(name="Updated Restock")
        assert params.name == "Updated Restock"


class TestSectionSchemas:
    """Tests for Section schemas."""

    def test_section_list_params(self):
        """Test SectionListParams."""
        params = SectionListParams(limit=10, offset=0, customer_id=123, status_cd=1)
        assert params.limit == 10
        assert params.customer_id == 123

    def test_section(self):
        """Test Section."""
        section = Section(sections_uid=1)
        assert section.sections_uid == 1

    def test_section_create_params(self):
        """Test SectionCreateParams."""
        params = SectionCreateParams(name="Test Section")
        assert params.name == "Test Section"

    def test_section_update_params(self):
        """Test SectionUpdateParams."""
        params = SectionUpdateParams(name="Updated Section")
        assert params.name == "Updated Section"

    def test_section_enable_params(self):
        """Test SectionEnableParams."""
        params = SectionEnableParams(status_cd=1)
        assert params.status_cd == 1


class TestVMIClient:
    """Tests for VMI client."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def client(self, mock_http):
        """Create VMI client."""
        return VMIClient(mock_http)

    def test_warehouse_property(self, client):
        """Test warehouse property."""
        warehouse = client.warehouse
        assert isinstance(warehouse, WarehouseResource)
        # Test caching
        assert client.warehouse is warehouse

    def test_distributors_property(self, client):
        """Test distributors property."""
        distributors = client.distributors
        assert isinstance(distributors, DistributorsResource)
        # Test caching
        assert client.distributors is distributors

    def test_products_property(self, client):
        """Test products property."""
        products = client.products
        assert isinstance(products, ProductsResource)
        # Test caching
        assert client.products is products

    def test_inv_profile_hdr_property(self, client):
        """Test inv_profile_hdr property."""
        inv_profile_hdr = client.inv_profile_hdr
        assert isinstance(inv_profile_hdr, InvProfileHdrResource)
        # Test caching
        assert client.inv_profile_hdr is inv_profile_hdr

    def test_restock_hdr_property(self, client):
        """Test restock_hdr property."""
        restock_hdr = client.restock_hdr
        assert isinstance(restock_hdr, RestockHdrResource)
        # Test caching
        assert client.restock_hdr is restock_hdr

    def test_sections_property(self, client):
        """Test sections property."""
        sections = client.sections
        assert isinstance(sections, SectionsResource)
        # Test caching
        assert client.sections is sections


class TestWarehouseResource:
    """Tests for Warehouse resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create Warehouse resource."""
        return WarehouseResource(mock_http)

    def test_list(self, resource, mock_http):
        """Test list method."""
        mock_http.get.return_value = mock_response([{"warehouseUid": 1}])
        result = resource.list()
        assert len(result.data) == 1
        mock_http.get.assert_called_once()

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response({"warehouseUid": 1})
        result = resource.get(1)
        assert result.data.warehouse_uid == 1

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response({"warehouseUid": 1})
        result = resource.create(WarehouseCreateParams(name="Test"))
        assert result.data.warehouse_uid == 1

    def test_update(self, resource, mock_http):
        """Test update method."""
        mock_http.put.return_value = mock_response({"warehouseUid": 1})
        result = resource.update(1, WarehouseUpdateParams(name="Updated"))
        assert result.data.warehouse_uid == 1

    def test_delete(self, resource, mock_http):
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_enable(self, resource, mock_http):
        """Test enable method."""
        mock_http.put.return_value = mock_response({"warehouseUid": 1})
        result = resource.enable(1, WarehouseEnableParams(status_cd=1))
        assert result.data.warehouse_uid == 1

    def test_availability_factory(self, resource):
        """Test availability factory method."""
        avail = resource.availability(1)
        assert isinstance(avail, WarehouseAvailabilityResource)

    def test_adjust_factory(self, resource):
        """Test adjust factory method."""
        adjust = resource.adjust(1)
        assert isinstance(adjust, WarehouseAdjustResource)

    def test_receive_factory(self, resource):
        """Test receive factory method."""
        receive = resource.receive(1)
        assert isinstance(receive, WarehouseReceiveResource)

    def test_replenish_factory(self, resource):
        """Test replenish factory method."""
        replenish = resource.replenish(1)
        assert isinstance(replenish, WarehouseReplenishResource)

    def test_transfer_factory(self, resource):
        """Test transfer factory method."""
        transfer = resource.transfer(1)
        assert isinstance(transfer, WarehouseTransferResource)

    def test_usage_factory(self, resource):
        """Test usage factory method."""
        usage = resource.usage(1)
        assert isinstance(usage, WarehouseUsageResource)

    def test_users_factory(self, resource):
        """Test users factory method."""
        users = resource.users(1)
        assert isinstance(users, WarehouseUsersResource)


class TestWarehouseNestedResources:
    """Tests for Warehouse nested resources."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    def test_availability_get(self, mock_http):
        """Test availability get method."""
        mock_http.get.return_value = mock_response([{"productsUid": 1}])
        resource = WarehouseAvailabilityResource(mock_http, 1)
        result = resource.get(InventoryAvailabilityParams(q="search"))
        assert len(result.data) == 1

    def test_adjust_create(self, mock_http):
        """Test adjust create method."""
        mock_http.post.return_value = mock_response(True)
        resource = WarehouseAdjustResource(mock_http, 1)
        result = resource.create(InventoryAdjustParams(qty=10))
        assert result.data is True

    def test_receive_create(self, mock_http):
        """Test receive create method."""
        mock_http.post.return_value = mock_response(True)
        resource = WarehouseReceiveResource(mock_http, 1)
        result = resource.create(InventoryReceiveParams(qty=10))
        assert result.data is True

    def test_replenish_get(self, mock_http):
        """Test replenish get method."""
        mock_http.get.return_value = mock_response({"qty": 100})
        resource = WarehouseReplenishResource(mock_http, 1)
        result = resource.get()
        assert result.data is not None

    def test_replenish_create(self, mock_http):
        """Test replenish create method."""
        mock_http.post.return_value = mock_response(True)
        resource = WarehouseReplenishResource(mock_http, 1)
        result = resource.create(ReplenishParams(qty=10))
        assert result.data is True

    def test_transfer_create(self, mock_http):
        """Test transfer create method."""
        mock_http.post.return_value = mock_response(True)
        resource = WarehouseTransferResource(mock_http, 1)
        result = resource.create(TransferParams(qty=10))
        assert result.data is True

    def test_usage_create(self, mock_http):
        """Test usage create method."""
        mock_http.post.return_value = mock_response(True)
        resource = WarehouseUsageResource(mock_http, 1)
        result = resource.create(UsageParams(qty=10))
        assert result.data is True


class TestWarehouseUsersResource:
    """Tests for Warehouse Users resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create Warehouse Users resource."""
        return WarehouseUsersResource(mock_http, 1)

    def test_list(self, resource, mock_http):
        """Test list method."""
        mock_http.get.return_value = mock_response([{"warehouseXUsersUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response({"warehouseXUsersUid": 1})
        result = resource.get(1)
        assert result.data.warehouse_x_users_uid == 1

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response({"warehouseXUsersUid": 1})
        result = resource.create(WarehouseUserCreateParams(user_id=1))
        assert result.data.warehouse_x_users_uid == 1

    def test_update(self, resource, mock_http):
        """Test update method."""
        mock_http.put.return_value = mock_response({"warehouseXUsersUid": 1})
        result = resource.update(1, WarehouseUserUpdateParams(status_cd=1))
        assert result.data.warehouse_x_users_uid == 1

    def test_delete(self, resource, mock_http):
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestDistributorsResource:
    """Tests for Distributors resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create Distributors resource."""
        return DistributorsResource(mock_http)

    def test_list(self, resource, mock_http):
        """Test list method."""
        mock_http.get.return_value = mock_response([{"distributorsUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response({"distributorsUid": 1})
        result = resource.get(1)
        assert result.data.distributors_uid == 1

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response({"distributorsUid": 1})
        result = resource.create(DistributorCreateParams(name="Test"))
        assert result.data.distributors_uid == 1

    def test_update(self, resource, mock_http):
        """Test update method."""
        mock_http.put.return_value = mock_response({"distributorsUid": 1})
        result = resource.update(1, DistributorUpdateParams(name="Updated"))
        assert result.data.distributors_uid == 1

    def test_delete(self, resource, mock_http):
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_enable(self, resource, mock_http):
        """Test enable method."""
        mock_http.put.return_value = mock_response({"distributorsUid": 1})
        result = resource.enable(1, DistributorEnableParams(status_cd=1))
        assert result.data.distributors_uid == 1

    def test_products_factory(self, resource):
        """Test products factory method."""
        products = resource.products(1)
        assert isinstance(products, DistributorProductsResource)


class TestDistributorProductsResource:
    """Tests for Distributor Products resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create Distributor Products resource."""
        return DistributorProductsResource(mock_http, 1)

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response({"productsUid": 1})
        result = resource.create(ProductCreateParams(name="Test"))
        assert result.data.products_uid == 1


class TestProductsResource:
    """Tests for Products resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create Products resource."""
        return ProductsResource(mock_http)

    def test_list(self, resource, mock_http):
        """Test list method."""
        mock_http.get.return_value = mock_response([{"productsUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response({"productsUid": 1})
        result = resource.get(1)
        assert result.data.products_uid == 1

    def test_update(self, resource, mock_http):
        """Test update method."""
        mock_http.put.return_value = mock_response({"productsUid": 1})
        result = resource.update(1, ProductUpdateParams(name="Updated"))
        assert result.data.products_uid == 1

    def test_delete(self, resource, mock_http):
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_enable(self, resource, mock_http):
        """Test enable method."""
        mock_http.put.return_value = mock_response({"productsUid": 1})
        result = resource.enable(1, ProductEnableParams(status_cd=1))
        assert result.data.products_uid == 1

    def test_find_property(self, resource):
        """Test find property."""
        find = resource.find
        assert isinstance(find, ProductFindResource)
        # Test caching
        assert resource.find is find


class TestProductFindResource:
    """Tests for Product Find resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create Product Find resource."""
        return ProductFindResource(mock_http)

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response([{"itemId": "ITEM1", "itemType": "product"}])
        result = resource.get(ProductFindParams(customer_id=123))
        assert len(result.data) == 1
        assert result.data[0].item_id == "ITEM1"


class TestInvProfileHdrResource:
    """Tests for InvProfileHdr resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create InvProfileHdr resource."""
        return InvProfileHdrResource(mock_http)

    def test_list(self, resource, mock_http):
        """Test list method."""
        mock_http.get.return_value = mock_response([{"invProfileHdrUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response({"invProfileHdrUid": 1})
        result = resource.get(1)
        assert result.data.inv_profile_hdr_uid == 1

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response({"invProfileHdrUid": 1})
        result = resource.create(InvProfileHdrCreateParams(name="Test"))
        assert result.data.inv_profile_hdr_uid == 1

    def test_update(self, resource, mock_http):
        """Test update method."""
        mock_http.put.return_value = mock_response({"invProfileHdrUid": 1})
        result = resource.update(1, InvProfileHdrUpdateParams(name="Updated"))
        assert result.data.inv_profile_hdr_uid == 1

    def test_delete(self, resource, mock_http):
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_inv_profile_line_factory(self, resource):
        """Test inv_profile_line factory method."""
        line = resource.inv_profile_line(1)
        assert isinstance(line, InvProfileLineResource)

    def test_upload_factory(self, resource):
        """Test upload factory method."""
        upload = resource.upload(123)
        assert isinstance(upload, InvProfileUploadResource)


class TestInvProfileLineResource:
    """Tests for InvProfileLine resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create InvProfileLine resource."""
        return InvProfileLineResource(mock_http, 1)

    def test_list(self, resource, mock_http):
        """Test list method."""
        mock_http.get.return_value = mock_response([{"invProfileLineUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response({"invProfileLineUid": 1})
        result = resource.get(1)
        assert result.data.inv_profile_line_uid == 1

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response({"invProfileLineUid": 1})
        result = resource.create(InvProfileLineCreateParams(item_id="ITEM1"))
        assert result.data.inv_profile_line_uid == 1

    def test_update(self, resource, mock_http):
        """Test update method."""
        mock_http.put.return_value = mock_response({"invProfileLineUid": 1})
        result = resource.update(1, InvProfileLineUpdateParams(item_id="ITEM2"))
        assert result.data.inv_profile_line_uid == 1

    def test_delete(self, resource, mock_http):
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestInvProfileUploadResource:
    """Tests for InvProfileUpload resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create InvProfileUpload resource."""
        return InvProfileUploadResource(mock_http, 123)

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response(True)
        result = resource.create()
        assert result.data is True


class TestRestockHdrResource:
    """Tests for RestockHdr resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create RestockHdr resource."""
        return RestockHdrResource(mock_http)

    def test_list(self, resource, mock_http):
        """Test list method."""
        mock_http.get.return_value = mock_response([{"restockHdrUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response({"restockHdrUid": 1})
        result = resource.get(1)
        assert result.data.restock_hdr_uid == 1

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response({"restockHdrUid": 1})
        result = resource.create(RestockHdrCreateParams(name="Test"))
        assert result.data.restock_hdr_uid == 1

    def test_update(self, resource, mock_http):
        """Test update method."""
        mock_http.put.return_value = mock_response({"restockHdrUid": 1})
        result = resource.update(1, RestockHdrUpdateParams(name="Updated"))
        assert result.data.restock_hdr_uid == 1

    def test_delete(self, resource, mock_http):
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestSectionsResource:
    """Tests for Sections resource."""

    @pytest.fixture
    def mock_http(self):
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http):
        """Create Sections resource."""
        return SectionsResource(mock_http)

    def test_list(self, resource, mock_http):
        """Test list method."""
        mock_http.get.return_value = mock_response([{"sectionsUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource, mock_http):
        """Test get method."""
        mock_http.get.return_value = mock_response({"sectionsUid": 1})
        result = resource.get(1)
        assert result.data.sections_uid == 1

    def test_create(self, resource, mock_http):
        """Test create method."""
        mock_http.post.return_value = mock_response({"sectionsUid": 1})
        result = resource.create(SectionCreateParams(name="Test"))
        assert result.data.sections_uid == 1

    def test_update(self, resource, mock_http):
        """Test update method."""
        mock_http.put.return_value = mock_response({"sectionsUid": 1})
        result = resource.update(1, SectionUpdateParams(name="Updated"))
        assert result.data.sections_uid == 1

    def test_delete(self, resource, mock_http):
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_enable(self, resource, mock_http):
        """Test enable method."""
        mock_http.put.return_value = mock_response({"sectionsUid": 1})
        result = resource.enable(1, SectionEnableParams(status_cd=1))
        assert result.data.sections_uid == 1
