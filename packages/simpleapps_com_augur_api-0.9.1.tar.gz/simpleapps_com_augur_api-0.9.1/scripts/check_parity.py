#!/usr/bin/env python3
"""Check and report parity between TypeScript and Python clients.

Usage:
  uv run python scripts/check_parity.py           # Full report
  uv run python scripts/check_parity.py --summary # Summary only
  uv run python scripts/check_parity.py items     # Single service
"""

import subprocess
import sys
from dataclasses import dataclass


@dataclass
class ParityReport:
    """Parity report for a service."""

    service: str
    missing_from_py: list[str]
    missing_from_ts: list[str]
    complete: int
    total: int


def get_sync_todos(service: str) -> ParityReport:
    """Get sync todos for a service and parse the output."""
    result = subprocess.run(  # noqa: S603
        ["uv", "run", "python", "scripts/fetch_llms_openapi.py", "--sync-todos", service],  # noqa: S607
        capture_output=True,
        text=True,
        check=False,
    )

    missing_py: list[str] = []
    missing_ts: list[str] = []
    complete = 0
    total = 0

    for raw_line in result.stdout.split("\n"):
        line = raw_line.strip()
        if "No PY" in line:
            # Extract method and path
            parts = line.split()
            if len(parts) >= 2:
                missing_py.append(f"{parts[0]} {parts[1]}")
        elif "No TS" in line:
            parts = line.split()
            if len(parts) >= 2:
                missing_ts.append(f"{parts[0]} {parts[1]}")
        elif "Complete:" in line:
            # Parse "Complete: 25/33"
            try:
                fraction = line.split("Complete:")[1].strip().split()[0]
                complete, total = map(int, fraction.split("/"))
            except (ValueError, IndexError):
                pass

    return ParityReport(
        service=service,
        missing_from_py=missing_py,
        missing_from_ts=missing_ts,
        complete=complete,
        total=total,
    )


SERVICES = [
    "agr-info",
    "agr-site",
    "agr-work",
    "avalara",
    "basecamp2",
    "brand-folder",
    "commerce",
    "customers",
    "gregorovich",
    "items",
    "joomla",
    "legacy",
    "logistics",
    "nexus",
    "open-search",
    "orders",
    "p21-apis",
    "p21-core",
    "p21-pim",
    "p21-sism",
    "payments",
    "pricing",
    "shipping",
    "slack",
    "smarty-streets",
    "ups",
    "vmi",
]


def print_summary(reports: list[ParityReport]) -> None:
    """Print summary of parity status."""
    total_missing_py = sum(len(r.missing_from_py) for r in reports)
    total_missing_ts = sum(len(r.missing_from_ts) for r in reports)
    total_complete = sum(r.complete for r in reports)
    total_endpoints = sum(r.total for r in reports)

    print("\n" + "=" * 80)
    print("PARITY SUMMARY")
    print("=" * 80)
    print(f"\nTotal endpoints across all services: {total_endpoints}")
    print(f"Complete (in both TS and PY): {total_complete}")
    print(f"Missing from Python: {total_missing_py}")
    print(f"Missing from TypeScript: {total_missing_ts}")
    pct = 100 * total_complete / total_endpoints
    print(f"\nParity score: {total_complete}/{total_endpoints} ({pct:.1f}%)")

    print("\n" + "-" * 80)
    print("BY SERVICE:")
    print("-" * 80)
    print(f"{'Service':<20} {'Complete':<12} {'Missing PY':<12} {'Missing TS':<12} Status")
    print("-" * 80)

    for r in sorted(reports, key=lambda x: -(len(x.missing_from_py) + len(x.missing_from_ts))):
        status = "✅ PARITY" if not r.missing_from_py and not r.missing_from_ts else "⚠️  GAPS"
        pct = f"{r.complete}/{r.total}" if r.total > 0 else "0/0"
        miss_py = len(r.missing_from_py)
        miss_ts = len(r.missing_from_ts)
        print(f"{r.service:<20} {pct:<12} {miss_py:<12} {miss_ts:<12} {status}")


def print_detailed(reports: list[ParityReport]) -> None:
    """Print detailed missing endpoints."""
    print("\n" + "=" * 80)
    print("MISSING FROM PYTHON (Need to add to packages/python/)")
    print("=" * 80)

    for r in reports:
        if r.missing_from_py:
            print(f"\n{r.service}:")
            for endpoint in r.missing_from_py:
                print(f"  - {endpoint}")

    print("\n" + "=" * 80)
    print("MISSING FROM TYPESCRIPT (Need to add to packages/typescript/)")
    print("=" * 80)

    for r in reports:
        if r.missing_from_ts:
            print(f"\n{r.service}:")
            for endpoint in r.missing_from_ts:
                print(f"  - {endpoint}")


def main() -> None:
    """Main entry point."""
    args = sys.argv[1:]
    summary_only = "--summary" in args
    args = [a for a in args if not a.startswith("--")]

    services = args if args else SERVICES

    print("Checking parity...")
    reports = []
    for service in services:
        print(f"  {service}...", end=" ", flush=True)
        report = get_sync_todos(service)
        reports.append(report)
        status = "✅" if not report.missing_from_py and not report.missing_from_ts else "⚠️"
        print(status)

    print_summary(reports)

    if not summary_only:
        print_detailed(reports)

    # Exit with error code if not at parity
    total_missing = sum(len(r.missing_from_py) + len(r.missing_from_ts) for r in reports)
    if total_missing > 0:
        print(f"\n❌ NOT AT PARITY: {total_missing} endpoints need to be added")
        sys.exit(1)
    else:
        print("\n✅ FULL PARITY ACHIEVED!")
        sys.exit(0)


if __name__ == "__main__":
    main()
