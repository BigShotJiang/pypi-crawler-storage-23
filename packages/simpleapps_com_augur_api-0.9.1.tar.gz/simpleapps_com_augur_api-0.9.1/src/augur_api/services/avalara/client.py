"""Avalara service client for tax rate calculations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse
from augur_api.services.avalara.schemas import (
    TaxRate,
)
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class RatesResource(BaseResource):
    """Resource for /rates endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/rates")

    def create(self, data: Any) -> BaseResponse[TaxRate]:
        """Calculate tax rates for an address.

        Args:
            data: Address parameters for tax rate calculation.

        Returns:
            BaseResponse containing tax rate information.
        """
        response = self._post(data=data)
        return BaseResponse[TaxRate].model_validate(response)


class AvalaraClient(BaseServiceClient):
    """Client for the Avalara tax service.

    Provides access to tax rate calculation endpoints.

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> rates = api.avalara.rates.create(RatesParams(postal_code="98101"))
        >>> print(rates.data.total_rate)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Avalara client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._rates: RatesResource | None = None

    @property
    def rates(self) -> RatesResource:
        """Access tax rates endpoints."""
        if self._rates is None:
            self._rates = RatesResource(self._http)
        return self._rates
