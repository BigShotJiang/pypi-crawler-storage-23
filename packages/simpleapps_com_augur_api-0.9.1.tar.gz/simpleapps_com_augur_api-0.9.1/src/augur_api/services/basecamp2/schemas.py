"""Schemas for the Basecamp2 service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Projects
class ProjectListParams(EdgeCacheParams):
    """Parameters for listing projects."""

    limit: int | None = None
    offset: int | None = None
    archived_flag: str | None = None


class Project(CamelCaseModel):
    """Basecamp project entity."""

    projects_uid: int | None = None
    bc_project_id: int | None = None
    name: str | None = None
    description: str | None = None
    status: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


# Todos
class TodoListParams(EdgeCacheParams):
    """Parameters for listing todos."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    completed_flag: str | None = None
    projects_id: int | None = None


class Todo(CamelCaseModel):
    """Basecamp todo entity."""

    todos_uid: int | None = None
    bc_todo_id: int | None = None
    content: str | None = None
    completed: bool | None = None
    due_at: str | None = None
    assignee_id: int | None = None
    project_id: int | None = None
    todolist_id: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class TodoCreateParams(BaseModel):
    """Parameters for creating a todo."""

    content: str
    todolist_id: int
    due_at: str | None = None
    assignee_id: int | None = None


class TodoUpdateParams(BaseModel):
    """Parameters for updating a todo."""

    content: str | None = None
    completed: bool | None = None
    due_at: str | None = None
    assignee_id: int | None = None


# People
class PersonListParams(EdgeCacheParams):
    """Parameters for listing people."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    admin_flag: str | None = None
    trashed_flag: str | None = None


class Person(CamelCaseModel):
    """Basecamp person entity."""

    people_uid: int | None = None
    bc_person_id: int | None = None
    name: str | None = None
    email_address: str | None = None
    avatar_url: str | None = None
    admin: bool | None = None
    created_at: str | None = None
    updated_at: str | None = None


# Comments
class CommentListParams(EdgeCacheParams):
    """Parameters for listing comments."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    creator_id: int | None = None
    todos_id: int | None = None


class Comment(CamelCaseModel):
    """Basecamp comment entity."""

    comments_uid: int | None = None
    bc_comment_id: int | None = None
    content: str | None = None
    creator_id: int | None = None
    todo_id: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class CommentCreateParams(BaseModel):
    """Parameters for creating a comment."""

    content: str
    todo_id: int


# Events
class EventListParams(EdgeCacheParams):
    """Parameters for listing events."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    event_type_cd: str | None = None
    id: int | None = None
    people_id: int | None = None


class Event(CamelCaseModel, extra="allow"):
    """Basecamp event entity (passthrough for API flexibility)."""

    events_uid: int | None = None


# Metrics
class MetricsListParams(EdgeCacheParams):
    """Parameters for listing metrics."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    assignee_id: int | None = None
    creator_id: int | None = None
    has_comments: str | None = None
    is_stale: str | None = None
    needs_response: str | None = None
    projects_id: int | None = None
    todos_status_cd: str | None = None


class Metric(CamelCaseModel, extra="allow"):
    """Basecamp metric entity (passthrough for API flexibility)."""


# Todolists
class TodolistListParams(EdgeCacheParams):
    """Parameters for listing todolists."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


class Todolist(CamelCaseModel, extra="allow"):
    """Basecamp todolist entity (passthrough for API flexibility)."""

    todolists_uid: int | None = None
    name: str | None = None


# Todos Summary
class TodosSummaryListParams(EdgeCacheParams):
    """Parameters for listing todos summary."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    akasha_cd: int | None = None
    process_cd: int | None = None


class TodosSummary(CamelCaseModel, extra="allow"):
    """Basecamp todos summary entity (passthrough for API flexibility)."""

    todos_summary_uid: int | None = None


# Sessions
class SessionListParams(EdgeCacheParams):
    """Parameters for listing sessions."""

    limit: int | None = None
    offset: int | None = None
    session_status_cd: int | None = None


class Session(CamelCaseModel, extra="allow"):
    """Basecamp session entity (passthrough for API flexibility)."""

    session_id: int | None = None


class SessionCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a session (passthrough)."""


class SessionUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a session (passthrough)."""
