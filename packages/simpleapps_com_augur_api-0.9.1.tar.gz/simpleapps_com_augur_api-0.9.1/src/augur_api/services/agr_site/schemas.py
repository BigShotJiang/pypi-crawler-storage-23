"""Schemas for the AGR Site service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Context
class ContextGetParams(EdgeCacheParams):
    """Parameters for getting context."""


class ContextResponse(CamelCaseModel):
    """Context response data."""


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Ping
class PingResponse(CamelCaseModel):
    """Ping response data."""

    pong: bool | None = None
    timestamp: str | None = None


# Whoami
class WhoamiResponse(CamelCaseModel):
    """Whoami response data."""

    site_id: str | None = None
    user_id: int | None = None
    contact_id: int | None = None
    customer_id: int | None = None


# Settings
class SettingListParams(EdgeCacheParams):
    """Parameters for listing settings."""

    limit: int | None = None
    offset: int | None = None
    service_name: str | None = None


class Setting(CamelCaseModel):
    """Setting entity."""

    settings_uid: int | None = None
    service_name: str | None = None
    setting_key: str | None = None
    setting_value: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class SettingCreateParams(BaseModel):
    """Parameters for creating a setting."""

    service_name: str | None = None
    setting_key: str | None = None
    setting_value: str | None = None


class SettingUpdateParams(BaseModel):
    """Parameters for updating a setting."""

    setting_value: str | None = None


# Fyxer Transcript
class FyxerTranscriptListParams(EdgeCacheParams):
    """Parameters for listing Fyxer transcripts."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class FyxerTranscript(CamelCaseModel):
    """Fyxer transcript entity."""

    fyxer_transcript_hdr_uid: int | None = None
    link: str | None = None
    title: str | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class FyxerTranscriptCreateParams(BaseModel):
    """Parameters for creating a Fyxer transcript."""

    link: str


class FyxerTranscriptUpdateParams(BaseModel):
    """Parameters for updating a Fyxer transcript."""

    title: str | None = None
    status_cd: int | None = None


# Training Set
class TrainingSetListParams(EdgeCacheParams):
    """Parameters for listing training sets."""

    limit: int | None = None
    offset: int | None = None


class TrainingSet(CamelCaseModel):
    """Training set entity."""

    training_set_uid: int | None = None
    name: str | None = None
    description: str | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class TrainingSetCreateParams(BaseModel):
    """Parameters for creating a training set."""

    name: str | None = None
    description: str | None = None


class TrainingSetUpdateParams(BaseModel):
    """Parameters for updating a training set."""

    name: str | None = None
    description: str | None = None
    status_cd: int | None = None


# Training Conversation
class TrainingConvListParams(EdgeCacheParams):
    """Parameters for listing training conversations."""

    limit: int | None = None
    offset: int | None = None


class TrainingConv(CamelCaseModel):
    """Training conversation entity."""

    training_conv_uid: int | None = None
    training_set_uid: int | None = None
    title: str | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class TrainingConvCreateParams(BaseModel):
    """Parameters for creating a training conversation."""

    title: str | None = None


class TrainingConvUpdateParams(BaseModel):
    """Parameters for updating a training conversation."""

    title: str | None = None
    status_cd: int | None = None


# Training Message
class TrainingMsgListParams(EdgeCacheParams):
    """Parameters for listing training messages."""

    limit: int | None = None
    offset: int | None = None


class TrainingMsg(CamelCaseModel):
    """Training message entity."""

    training_msg_uid: int | None = None
    training_conv_uid: int | None = None
    role: str | None = None
    content: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class TrainingMsgCreateParams(BaseModel):
    """Parameters for creating a training message."""

    role: str | None = None
    content: str | None = None


class TrainingMsgUpdateParams(BaseModel):
    """Parameters for updating a training message."""

    role: str | None = None
    content: str | None = None


# Geo Codes Postal Codes
class GeoCodesPostalCodesListParams(EdgeCacheParams):
    """Parameters for listing geo codes."""

    limit: int | None = None
    offset: int | None = None


class GeoCodesPostalCodes(CamelCaseModel):
    """Geo codes postal codes entity."""

    geo_codes_postal_codes_uid: int | None = None
    postal_code: str | None = None
    city: str | None = None
    state: str | None = None
    country: str | None = None
    latitude: float | None = None
    longitude: float | None = None


# Notifications
class NotificationCreateParams(BaseModel):
    """Parameters for creating a notification."""

    message: str | None = None
    recipient: str | None = None
    notification_type: str | None = None


class NotificationResponse(CamelCaseModel):
    """Notification response."""

    success: bool | None = None
    message: str | None = None


# Open Search Embedding
class OpenSearchEmbeddingParams(EdgeCacheParams):
    """Parameters for OpenSearch embedding."""

    q: str
    model: str | None = None
    dimensions: int | None = None


class OpenSearchEmbeddingResponse(CamelCaseModel):
    """OpenSearch embedding response."""

    embedding: list[float] | None = None
    model: str | None = None
    dimensions: int | None = None


# Meta Files
class MetaFilesRobotsResponse(CamelCaseModel):
    """Meta files robots response."""

    content: str | None = None
