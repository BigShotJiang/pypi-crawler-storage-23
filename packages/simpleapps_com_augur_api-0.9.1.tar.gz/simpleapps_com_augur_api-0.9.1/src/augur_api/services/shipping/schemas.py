"""Schemas for the Shipping service."""

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Rates
class RatesParams(EdgeCacheParams):
    """Parameters for shipping rate calculation."""

    origin_zip: str
    destination_zip: str
    weight: float
    length: float | None = None
    width: float | None = None
    height: float | None = None
    carrier: str | None = None
    service_type: str | None = None


class RateQuote(CamelCaseModel):
    """Shipping rate quote entity."""

    carrier: str | None = None
    service_type: str | None = None
    service_name: str | None = None
    rate: float | None = None
    currency: str | None = None
    transit_days: int | None = None
    delivery_date: str | None = None
    guaranteed: bool | None = None
