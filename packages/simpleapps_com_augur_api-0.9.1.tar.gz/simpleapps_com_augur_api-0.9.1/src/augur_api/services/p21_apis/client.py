"""P21 APIs service client for Prophet 21 API integration."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.p21_apis.schemas import (
    EntityContactsRefreshResponse,
    EntityCustomersRefreshResponse,
    TransCategory,
    TransCompany,
    TransPurchaseOrderReceipt,
    TransUser,
    TransWebDisplayType,
    TransWebDisplayTypeDefaults,
    TransWebDisplayTypeDefinition,
)
from augur_api.services.resource import BaseResource


class EntityContactsResource(BaseResource):
    """Resource for /entity-contacts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/entity-contacts")

    def refresh(self) -> BaseResponse[EntityContactsRefreshResponse]:
        """Trigger a data refresh for entity contacts.

        Returns:
            BaseResponse containing refresh result.
        """
        response = self._get("/refresh")
        return BaseResponse[EntityContactsRefreshResponse].model_validate(response)


class EntityCustomersResource(BaseResource):
    """Resource for /entity-customers endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/entity-customers")

    def refresh(self) -> BaseResponse[EntityCustomersRefreshResponse]:
        """Trigger a data refresh for entity customers.

        Returns:
            BaseResponse containing refresh result.
        """
        response = self._get("/refresh")
        return BaseResponse[EntityCustomersRefreshResponse].model_validate(response)


class TransCategoryResource(BaseResource):
    """Resource for /trans-category endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-category")

    def get(self, category_uid: int) -> BaseResponse[TransCategory]:
        """Get category details by category UID.

        Args:
            category_uid: The category UID.

        Returns:
            BaseResponse containing category data.
        """
        response = self._get(f"/{category_uid}")
        return BaseResponse[TransCategory].model_validate(response)

    def create(self, data: Any) -> BaseResponse[TransCategory]:
        """Create a new category.

        Args:
            data: Category data to create.

        Returns:
            BaseResponse containing created category.
        """
        response = self._post(data=data)
        return BaseResponse[TransCategory].model_validate(response)

    def update(self, category_uid: int, data: Any) -> BaseResponse[TransCategory]:
        """Update a category.

        Args:
            category_uid: The category UID.
            data: Category data to update.

        Returns:
            BaseResponse containing updated category.
        """
        response = self._put(f"/{category_uid}", data=data)
        return BaseResponse[TransCategory].model_validate(response)

    def delete(self, category_uid: int) -> BaseResponse[bool]:
        """Delete a category.

        Args:
            category_uid: The category UID.

        Returns:
            BaseResponse with deletion status.
        """
        response = self._delete(f"/{category_uid}")
        return BaseResponse[bool].model_validate(response)


class TransCompanyResource(BaseResource):
    """Resource for /trans-company endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-company")

    def get(self, company_uid: int) -> BaseResponse[TransCompany]:
        """Get company details by company UID.

        Args:
            company_uid: The company UID.

        Returns:
            BaseResponse containing company data.
        """
        response = self._get(f"/{company_uid}")
        return BaseResponse[TransCompany].model_validate(response)

    def create(self, data: Any) -> BaseResponse[TransCompany]:
        """Create a new company.

        Args:
            data: Company data to create.

        Returns:
            BaseResponse containing created company.
        """
        response = self._post(data=data)
        return BaseResponse[TransCompany].model_validate(response)

    def update(self, company_uid: int, data: Any) -> BaseResponse[TransCompany]:
        """Update a company.

        Args:
            company_uid: The company UID.
            data: Company data to update.

        Returns:
            BaseResponse containing updated company.
        """
        response = self._put(f"/{company_uid}", data=data)
        return BaseResponse[TransCompany].model_validate(response)

    def delete(self, company_uid: int) -> BaseResponse[bool]:
        """Delete a company.

        Args:
            company_uid: The company UID.

        Returns:
            BaseResponse with deletion status.
        """
        response = self._delete(f"/{company_uid}")
        return BaseResponse[bool].model_validate(response)


class TransPurchaseOrderReceiptResource(BaseResource):
    """Resource for /trans-purchase-order-receipt endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-purchase-order-receipt")

    def get(self, po_no: str) -> BaseResponse[TransPurchaseOrderReceipt]:
        """Get purchase order receipt details by PO number.

        Args:
            po_no: The purchase order number.

        Returns:
            BaseResponse containing purchase order receipt data.
        """
        response = self._get(f"/{po_no}")
        return BaseResponse[TransPurchaseOrderReceipt].model_validate(response)

    def update(self, po_no: str, data: Any) -> BaseResponse[TransPurchaseOrderReceipt]:
        """Update a purchase order receipt.

        Args:
            po_no: The purchase order number.
            data: Purchase order receipt data to update.

        Returns:
            BaseResponse containing updated purchase order receipt.
        """
        response = self._put(f"/{po_no}", data=data)
        return BaseResponse[TransPurchaseOrderReceipt].model_validate(response)


class TransUserResource(BaseResource):
    """Resource for /trans-user endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-user")

    def get(self, users_uid: int) -> BaseResponse[TransUser]:
        """Get user details by user UID.

        Args:
            users_uid: The user UID.

        Returns:
            BaseResponse containing user data.
        """
        response = self._get(f"/{users_uid}")
        return BaseResponse[TransUser].model_validate(response)

    def create(self, data: Any) -> BaseResponse[TransUser]:
        """Create a new user.

        Args:
            data: User data to create.

        Returns:
            BaseResponse containing created user.
        """
        response = self._post(data=data)
        return BaseResponse[TransUser].model_validate(response)

    def update(self, users_uid: int, data: Any) -> BaseResponse[TransUser]:
        """Update a user.

        Args:
            users_uid: The user UID.
            data: User data to update.

        Returns:
            BaseResponse containing updated user.
        """
        response = self._put(f"/{users_uid}", data=data)
        return BaseResponse[TransUser].model_validate(response)

    def delete(self, users_uid: int) -> BaseResponse[bool]:
        """Delete a user.

        Args:
            users_uid: The user UID.

        Returns:
            BaseResponse with deletion status.
        """
        response = self._delete(f"/{users_uid}")
        return BaseResponse[bool].model_validate(response)


class TransWebDisplayTypeResource(BaseResource):
    """Resource for /trans-web-display-type endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/trans-web-display-type")

    def get(self, web_display_type_uid: int) -> BaseResponse[TransWebDisplayType]:
        """Get web display type details by UID.

        Args:
            web_display_type_uid: The web display type UID.

        Returns:
            BaseResponse containing web display type data.
        """
        response = self._get(f"/{web_display_type_uid}")
        return BaseResponse[TransWebDisplayType].model_validate(response)

    def create(self, data: Any) -> BaseResponse[TransWebDisplayType]:
        """Create a new web display type.

        Args:
            data: Web display type data to create.

        Returns:
            BaseResponse containing created web display type.
        """
        response = self._post(data=data)
        return BaseResponse[TransWebDisplayType].model_validate(response)

    def update(self, web_display_type_uid: int, data: Any) -> BaseResponse[TransWebDisplayType]:
        """Update a web display type.

        Args:
            web_display_type_uid: The web display type UID.
            data: Web display type data to update.

        Returns:
            BaseResponse containing updated web display type.
        """
        response = self._put(f"/{web_display_type_uid}", data=data)
        return BaseResponse[TransWebDisplayType].model_validate(response)

    def delete(self, web_display_type_uid: int) -> BaseResponse[bool]:
        """Delete a web display type.

        Args:
            web_display_type_uid: The web display type UID.

        Returns:
            BaseResponse with deletion status.
        """
        response = self._delete(f"/{web_display_type_uid}")
        return BaseResponse[bool].model_validate(response)

    def get_defaults(self) -> BaseResponse[TransWebDisplayTypeDefaults]:
        """Get web display type defaults.

        Returns:
            BaseResponse containing defaults data.
        """
        response = self._get("/defaults")
        return BaseResponse[TransWebDisplayTypeDefaults].model_validate(response)

    def get_definition(self) -> BaseResponse[TransWebDisplayTypeDefinition]:
        """Get web display type definition.

        Returns:
            BaseResponse containing definition data.
        """
        response = self._get("/definition")
        return BaseResponse[TransWebDisplayTypeDefinition].model_validate(response)


class P21ApisClient(BaseServiceClient):
    """Client for the P21 APIs service.

    Provides access to Prophet 21 API integration endpoints including:
    - Health check (health_check) - inherited from BaseServiceClient
    - Entity contacts (entity_contacts)
    - Entity customers (entity_customers)
    - Trans category (trans_category)
    - Trans company (trans_company)
    - Trans purchase order receipt (trans_purchase_order_receipt)
    - Trans user (trans_user)
    - Trans web display type (trans_web_display_type)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> category = api.p21_apis.trans_category.get(1)
        >>> print(category.data.category_uid)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the P21 APIs client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._entity_contacts: EntityContactsResource | None = None
        self._entity_customers: EntityCustomersResource | None = None
        self._trans_category: TransCategoryResource | None = None
        self._trans_company: TransCompanyResource | None = None
        self._trans_purchase_order_receipt: TransPurchaseOrderReceiptResource | None = None
        self._trans_user: TransUserResource | None = None
        self._trans_web_display_type: TransWebDisplayTypeResource | None = None

    @property
    def entity_contacts(self) -> EntityContactsResource:
        """Access entity contacts endpoints."""
        if self._entity_contacts is None:
            self._entity_contacts = EntityContactsResource(self._http)
        return self._entity_contacts

    @property
    def entity_customers(self) -> EntityCustomersResource:
        """Access entity customers endpoints."""
        if self._entity_customers is None:
            self._entity_customers = EntityCustomersResource(self._http)
        return self._entity_customers

    @property
    def trans_category(self) -> TransCategoryResource:
        """Access trans category endpoints."""
        if self._trans_category is None:
            self._trans_category = TransCategoryResource(self._http)
        return self._trans_category

    @property
    def trans_company(self) -> TransCompanyResource:
        """Access trans company endpoints."""
        if self._trans_company is None:
            self._trans_company = TransCompanyResource(self._http)
        return self._trans_company

    @property
    def trans_purchase_order_receipt(self) -> TransPurchaseOrderReceiptResource:
        """Access trans purchase order receipt endpoints."""
        if self._trans_purchase_order_receipt is None:
            self._trans_purchase_order_receipt = TransPurchaseOrderReceiptResource(self._http)
        return self._trans_purchase_order_receipt

    @property
    def trans_user(self) -> TransUserResource:
        """Access trans user endpoints."""
        if self._trans_user is None:
            self._trans_user = TransUserResource(self._http)
        return self._trans_user

    @property
    def trans_web_display_type(self) -> TransWebDisplayTypeResource:
        """Access trans web display type endpoints."""
        if self._trans_web_display_type is None:
            self._trans_web_display_type = TransWebDisplayTypeResource(self._http)
        return self._trans_web_display_type
