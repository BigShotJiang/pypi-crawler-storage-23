import io
import json
import os
import re
import signal
import sys
from pathlib import Path

OPERATION_TIMEOUT = 300
EVAL_TIMEOUT = 600


class AgentTimeoutError(Exception):
    pass


def _timeout_handler(signum, frame):
    raise AgentTimeoutError("Agent exceeded time limit")


class StreamingLogFile:
    def __init__(self, file_path):
        self.file_path = file_path
        self.buffer = io.StringIO()

    def write(self, data):
        self.buffer.write(data)
        with open(self.file_path, 'a') as f:
            f.write(data)
            f.flush()

    def flush(self):
        pass

    def getvalue(self):
        return self.buffer.getvalue()


def _persist_agent_trajectory(agent, trajectory_file: Path):
    trajectory_data = {
        "messages": getattr(agent, "messages", []),
        "actions": getattr(agent, "actions", []),
    }
    temp_file = trajectory_file.with_suffix(".tmp")
    temp_file.write_text(json.dumps(trajectory_data, indent=2))
    temp_file.replace(trajectory_file)


def _patch_agent_for_progress(log_file, trajectory_file: Path, agent_class):
    original_add_message = agent_class.add_message

    def patched_add_message(self, role, content, **kwargs):
        original_add_message(self, role, content, **kwargs)

        with open(log_file, 'a') as f:
            if role == "assistant":
                step_num = len([m for m in self.messages if m.get("role") == "assistant"])
                f.write(f"\n[Step {step_num}]\n")
                f.write(f"Assistant: {content}\n")
            elif role == "user" and len(self.messages) > 2:
                f.write(f"Observation: {content}\n")
            f.flush()

        _persist_agent_trajectory(self, trajectory_file)

    agent_class.add_message = patched_add_message


def run_minisweagent_task(
    task_prompt: str,
    work_dir: Path,
    model_name: str | None = None,
    agent_config: dict | None = None,
    operation_timeout: int = OPERATION_TIMEOUT,
    eval_timeout: int = EVAL_TIMEOUT,
) -> dict:
    """Run MiniSWE agent on a task.
    
    Args:
        task_prompt: Task description for the agent
        work_dir: Working directory for the agent
        model_name: Optional model name (e.g., "anthropic/claude-sonnet-4")
        agent_config: Optional agent configuration dict
        operation_timeout: Timeout for individual operations (seconds)
        eval_timeout: Timeout for entire evaluation (seconds)
    
    Returns:
        dict with keys "answer" (parsed JSON or None) and "metadata"
    """
    from minisweagent.agents.default import DefaultAgent, AgentConfig, FormatError
    from minisweagent.environments.local import LocalEnvironment
    from minisweagent.models import get_model
    import re

    class FlexibleAgent(DefaultAgent):
        def parse_action(self, response: dict) -> dict:
            content = response["content"]
            actions = re.findall(r"```(?:bash|sh|shell)?\s*\n(.*?)\n?```", content, re.DOTALL)
            if len(actions) == 1:
                return {"action": actions[0].strip(), **response}
            raise FormatError(self.render_template(self.config.format_error_template, actions=actions))

        def has_finished(self, output: dict):
            from minisweagent.agents.default import Submitted
            full_output = output.get("output", "")
            for marker in ["COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT", "MINI_SWE_AGENT_FINAL_OUTPUT"]:
                if marker in full_output:
                    idx = full_output.find(marker)
                    rest = full_output[idx + len(marker):].strip()
                    raise Submitted(rest)

    original_dir = os.getcwd()

    agent_log_file = work_dir / "agent_output.log"
    trajectory_file = work_dir / "trajectory.json"
    trajectory_file.write_text(json.dumps({"messages": [], "actions": []}, indent=2))
    _patch_agent_for_progress(agent_log_file, trajectory_file, FlexibleAgent)
    if agent_log_file.exists():
        agent_log_file.unlink()

    captured_output = StreamingLogFile(agent_log_file)
    original_stdout = sys.stdout
    original_stderr = sys.stderr

    class TeeOutput:
        def __init__(self, *streams):
            self.streams = streams

        def write(self, data):
            for stream in self.streams:
                stream.write(data)
                if hasattr(stream, 'flush'):
                    stream.flush()

        def flush(self):
            for stream in self.streams:
                if hasattr(stream, 'flush'):
                    stream.flush()

    agent = None
    timed_out = False
    try:
        os.chdir(str(work_dir))

        sys.stdout = TeeOutput(original_stdout, captured_output)
        sys.stderr = TeeOutput(original_stderr, captured_output)

        enhanced_prompt = _enhance_prompt_with_local_files(task_prompt, work_dir)

        enhanced_prompt += """

CRITICAL INSTRUCTIONS:
1. Do NOT wrap your code in try/except blocks. Let errors propagate so you can see them and fix them in subsequent steps.
2. You must write eval_answer.json BEFORE printing the completion signal.
3. Correct order: Perform analysis -> Write eval_answer.json -> Print 'COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT' as your FINAL line of output.

The file eval_answer.json should contain ONLY the JSON object with the required fields

Example eval_answer.json:
{
  "field1": value1,
  "field2": value2
}"""

        if model_name is not None:
            os.environ['MSWEA_MODEL_NAME'] = model_name
            if model_name.startswith("mistral/"):
                os.environ.setdefault("MSWEA_COST_TRACKING", "ignore_errors")

        model = get_model()
        env = LocalEnvironment(timeout=operation_timeout)

        if agent_config:
            agent = FlexibleAgent(model, env, step_limit=100, **agent_config)
        else:
            agent = FlexibleAgent(model, env, step_limit=100)

        old_handler = signal.signal(signal.SIGALRM, _timeout_handler)
        signal.alarm(eval_timeout)

        try:
            agent.run(enhanced_prompt)
        except AgentTimeoutError:
            timed_out = True
            print(f"\nAgent timed out after {eval_timeout} seconds")
        except Exception as e:
            if "Submitted" in str(type(e).__name__):
                pass
            else:
                raise
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)

            sys.stdout = original_stdout
            sys.stderr = original_stderr

            print(f"Agent output saved to: {agent_log_file}")

            if hasattr(agent, "messages"):
                _persist_agent_trajectory(agent, trajectory_file)
                print(f"Agent trajectory saved to: {trajectory_file}")
                print(f"  Total message exchanges: {len(agent.messages)}")

        eval_answer_file = work_dir / "eval_answer.json"
        agent_answer = None
        error_details = None

        if not eval_answer_file.exists():
            agent_log_file = work_dir / "agent_output.log"
            log_tail = ""
            if agent_log_file.exists():
                log_content = agent_log_file.read_text()
                log_tail = log_content[-1000:]

            trajectory_info = ""
            if hasattr(agent, "messages"):
                trajectory_info = f"Agent had {len(agent.messages)} message exchanges."

            error_msg = "Agent timed out" if timed_out else "Agent did not create eval_answer.json"
            error_details = {
                "error": error_msg,
                "timed_out": timed_out,
                "trajectory_info": trajectory_info,
                "log_tail": log_tail
            }
            print(f"\nWarning: {error_msg}. {trajectory_info}")
        else:
            try:
                agent_answer = json.loads(eval_answer_file.read_text())
            except json.JSONDecodeError as e:
                error_details = {
                    "error": f"Failed to parse eval_answer.json: {e}",
                    "file_contents": eval_answer_file.read_text()[:500]
                }
                print(f"\nWarning: Failed to parse eval_answer.json: {e}")

        metadata = {}
        if hasattr(agent, "model"):
            metadata["total_cost"] = getattr(agent.model, "cost", None)
            metadata["n_steps"] = getattr(agent.model, "n_calls", None)
        if hasattr(agent, "messages"):
            metadata["n_messages"] = len(agent.messages)
        if timed_out:
            metadata["timed_out"] = True
            metadata["eval_timeout_seconds"] = eval_timeout
        if error_details:
            metadata["error_details"] = error_details

        return {"answer": agent_answer, "metadata": metadata}

    finally:
        os.chdir(original_dir)


def _enhance_prompt_with_local_files(task_prompt: str, work_dir: Path) -> str:
    """Extract <ContextualNodeData> and add local file list to prompt."""
    contextual_data_match = re.search(r'<ContextualNodeData>(.*?)</ContextualNodeData>', task_prompt, re.DOTALL)

    if not contextual_data_match:
        return task_prompt

    try:
        contextual_data = json.loads(contextual_data_match.group(1))
    except json.JSONDecodeError:
        return task_prompt

    local_files = []
    for item in contextual_data:
        if 'local_path' in item:
            local_files.append(item['local_path'])

    if not local_files:
        return task_prompt

    file_list = "\n".join([f"- {f}" for f in local_files])

    enhancement = f"\n\nThe following data files are available in your current working directory:\n{file_list}\n\nUse these local filenames to access the data.\n"

    parts = task_prompt.split('<ContextualNodeData>')
    if len(parts) == 2:
        return parts[0] + enhancement + '<ContextualNodeData>' + parts[1]

    return task_prompt
