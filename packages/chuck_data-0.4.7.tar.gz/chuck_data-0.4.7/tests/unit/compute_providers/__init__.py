"""Unit tests for compute providers."""
