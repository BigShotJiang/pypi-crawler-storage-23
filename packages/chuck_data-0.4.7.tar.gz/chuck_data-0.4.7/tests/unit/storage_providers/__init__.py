"""Unit tests for storage providers."""
