"""Unit tests for wizard commands."""
