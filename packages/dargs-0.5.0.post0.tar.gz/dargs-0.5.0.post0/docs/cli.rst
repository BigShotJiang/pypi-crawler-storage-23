.. _cli:

Command line interface
======================

.. argparse::
   :module: dargs.cli
   :func: main_parser
   :prog: dargs
