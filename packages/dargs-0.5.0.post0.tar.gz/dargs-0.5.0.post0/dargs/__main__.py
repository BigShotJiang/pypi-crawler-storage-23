from __future__ import annotations

from dargs.cli import main

if __name__ == "__main__":
    main()
