# Release History

## 1.0.0b1 (2026-02-10)

### Other Changes

  - Initial version