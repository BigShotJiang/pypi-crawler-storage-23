# coinbase-agentkit-kevros

**Governance primitive for Coinbase AgentKit** — verify actions, attest provenance, bind intents, and check peer trust. One import, four actions.

## Install

```bash
pip install coinbase-agentkit-kevros
```

## Quick Start

```python
from coinbase_agentkit import AgentKit, AgentKitConfig
from coinbase_agentkit.wallet_providers import CdpEvmWalletProvider
from kevros_agentkit import kevros_governance_provider

# Add governance to any AgentKit agent (auto-signup, zero config)
agent_kit = AgentKit(AgentKitConfig(
    wallet_provider=CdpEvmWalletProvider(...),
    action_providers=[kevros_governance_provider(agent_id="my-agent")]
))

# Your agent now has 4 governance actions alongside all Coinbase actions
```

## Actions

| Action | Description | Cost |
|--------|-------------|------|
| `verify_action` | Check if an action is allowed. Returns ALLOW/CLAMP/DENY with cryptographic release token. | $0.01 |
| `attest_provenance` | Record an action in a hash-chained, tamper-evident provenance ledger. Post-quantum attested. | $0.02 |
| `bind_intent` | Cryptographically bind a declared intent to the command that fulfills it. | $0.02 |
| `check_peer_trust` | Check another agent's trust score and provenance history before collaborating. | Free |

## How It Works

```python
# Before a trade — verify it's allowed
result = provider.verify_action(wallet, {
    "action_type": "trade",
    "action_payload": {"asset": "ETH", "amount": 1.0, "side": "buy"},
    "agent_id": "my-agent"
})
# → {"decision": "ALLOW", "release_token": "...", "provenance_hash": "..."}

# After the trade — record it in the provenance ledger
result = provider.attest_provenance(wallet, {
    "agent_id": "my-agent",
    "action_description": "Bought 1.0 ETH at $3,200",
    "action_payload": {"asset": "ETH", "amount": 1.0, "price": 3200}
})
# → {"hash_curr": "...", "chain_length": 42}

# Before collaborating — check the other agent
result = provider.check_peer_trust(wallet, {
    "agent_id": "other-agent-id"
})
# → {"trust_score": 1.0, "chain_length": 120, "chain_intact": true}
```

## Configuration

```python
# Zero config (auto-signup: 100 free calls/mo)
provider = kevros_governance_provider(agent_id="my-agent")

# Explicit API key
provider = kevros_governance_provider(api_key="kvrs_...")

# Custom gateway
provider = kevros_governance_provider(
    api_key="kvrs_...",
    gateway_url="https://your-gateway.example.com"
)
```

## x402 Payment

Each governance call is priced via the [x402 protocol](https://www.x402.org/). When used through the Agentic Wallet, payments are automatic — USDC on Base, deducted per-call.

## Links

- [Kevros Gateway](https://governance.taskhawktech.com)
- [Agent Card](https://governance.taskhawktech.com/.well-known/agent.json)
- [x402 Discovery](https://governance.taskhawktech.com/.well-known/x402)
- [TaskHawk Systems](https://taskhawktech.com)

## License

BSL-1.1 — © TaskHawk Systems LLC
