"""
Kevros Governance ActionProvider for Coinbase AgentKit.

The trust primitive for the Coinbase agent stack. Adds verify, attest,
bind, and peer-trust to any AgentKit agent — one import, four actions.

Usage (zero config):
    from kevros_agentkit import kevros_governance_provider

    agent_kit = AgentKit(AgentKitConfig(
        wallet_provider=CdpEvmWalletProvider(...),
        action_providers=[kevros_governance_provider(agent_id="my-agent")]
    ))

Usage (explicit key):
    from kevros_agentkit import kevros_governance_provider

    provider = kevros_governance_provider(api_key="kvrs_...")

Free tier: 100 calls/mo, no credit card. Auto-signup on first use.
"""

from __future__ import annotations

__version__ = "0.1.0"

import json
from typing import Any, Dict

from coinbase_agentkit import ActionProvider, WalletProvider, create_action
from kevros_governance import GovernanceClient, IntentType, IntentSource

from .schemas import (
    AttestProvenanceSchema,
    BindIntentSchema,
    CheckPeerTrustSchema,
    VerifyActionSchema,
)


def _to_json(obj: Any) -> str:
    """Serialize a response to JSON string (AgentKit requirement)."""
    if hasattr(obj, "__dict__"):
        d = {}
        for k, v in obj.__dict__.items():
            if hasattr(v, "value"):  # Enum
                d[k] = v.value
            else:
                d[k] = v
        return json.dumps(d, default=str)
    return json.dumps(obj, default=str)


class KevrosGovernanceProvider(ActionProvider[WalletProvider]):
    """
    Governance verification, provenance attestation, intent binding,
    and peer trust for any Coinbase AgentKit agent.

    Wraps the Kevros GovernanceClient. Auto-signup: pass agent_id instead
    of api_key to get a free key (100 calls/mo) cached at ~/.kevros/api_key.
    """

    def __init__(
        self,
        api_key: str = "",
        agent_id: str = "",
        gateway_url: str = "",
    ):
        super().__init__("kevros-governance", [])
        self._client = GovernanceClient(
            api_key=api_key,
            agent_id=agent_id,
            base_url=gateway_url or "https://governance.taskhawktech.com",
        )

    # ------------------------------------------------------------------
    # verify_action — $0.01
    # ------------------------------------------------------------------

    @create_action(
        name="verify_action",
        description=(
            "Verify an action against governance policy before executing it. "
            "Returns ALLOW (proceed), CLAMP (proceed with modified bounds), or "
            "DENY (do not proceed). Use this before any high-stakes action: trades, "
            "transfers, deployments, API calls to external services. The response "
            "includes a cryptographic release token that proves the action was "
            "authorized."
        ),
        schema=VerifyActionSchema,
    )
    def verify_action(self, wallet_provider: WalletProvider, args: dict) -> str:
        """Verify an action before executing it."""
        try:
            result = self._client.verify(
                action_type=args["action_type"],
                action_payload=args["action_payload"],
                agent_id=args["agent_id"],
                policy_context=args.get("policy_context"),
            )
            return _to_json(result)
        except Exception as e:
            return json.dumps({"error": str(e)})

    # ------------------------------------------------------------------
    # attest_provenance — $0.02
    # ------------------------------------------------------------------

    @create_action(
        name="attest_provenance",
        description=(
            "Record an action you've taken in a tamper-evident, hash-chained "
            "provenance ledger. Each record links to the previous via cryptographic "
            "hash, creating an independently verifiable audit trail. Use after "
            "completing actions to build trust history."
        ),
        schema=AttestProvenanceSchema,
    )
    def attest_provenance(self, wallet_provider: WalletProvider, args: dict) -> str:
        """Record an action in the provenance ledger."""
        try:
            result = self._client.attest(
                agent_id=args["agent_id"],
                action_description=args["action_description"],
                action_payload=args["action_payload"],
                context=args.get("context"),
            )
            return _to_json(result)
        except Exception as e:
            return json.dumps({"error": str(e)})

    # ------------------------------------------------------------------
    # bind_intent — $0.02
    # ------------------------------------------------------------------

    @create_action(
        name="bind_intent",
        description=(
            "Cryptographically bind your declared intent to the command that "
            "fulfills it. This creates a verifiable proof that what you said you "
            "would do matches what you actually did. Use before executing a command "
            "to declare your intent, then verify the outcome afterward."
        ),
        schema=BindIntentSchema,
    )
    def bind_intent(self, wallet_provider: WalletProvider, args: dict) -> str:
        """Bind a declared intent to a command."""
        try:
            # Resolve intent_type string to enum
            intent_type_str = args["intent_type"].upper()
            try:
                intent_type = IntentType(intent_type_str)
            except ValueError:
                intent_type = IntentType.AI_GENERATED

            result = self._client.bind(
                agent_id=args["agent_id"],
                intent_type=intent_type,
                intent_description=args["intent_description"],
                command_payload=args["command_payload"],
                intent_source=IntentSource.AI_PLANNER,
                goal_state=args.get("goal_state"),
            )
            return _to_json(result)
        except Exception as e:
            return json.dumps({"error": str(e)})

    # ------------------------------------------------------------------
    # check_peer_trust — Free
    # ------------------------------------------------------------------

    @create_action(
        name="check_peer_trust",
        description=(
            "Check another agent's governance reputation before collaborating. "
            "Returns their trust score, provenance chain length, and recent "
            "decision history. Use before accepting requests from or delegating "
            "to other agents."
        ),
        schema=CheckPeerTrustSchema,
    )
    def check_peer_trust(self, wallet_provider: WalletProvider, args: dict) -> str:
        """Check another agent's trust score."""
        try:
            result = self._client.verify_peer(agent_id=args["agent_id"])
            return json.dumps(result, default=str)
        except Exception as e:
            return json.dumps({"error": str(e)})

    def supports_network(self, network: str) -> bool:
        """Governance is chain-agnostic — supports all networks."""
        return True


def kevros_governance_provider(
    api_key: str = "",
    agent_id: str = "",
    gateway_url: str = "",
) -> KevrosGovernanceProvider:
    """
    Factory function for the Kevros governance ActionProvider.

    Args:
        api_key: Your Kevros API key (starts with kvrs_). Optional if agent_id is provided.
        agent_id: Your agent's identifier. Used for auto-signup if no api_key.
        gateway_url: Gateway URL. Defaults to https://governance.taskhawktech.com

    Returns:
        KevrosGovernanceProvider ready to add to AgentKit.

    Example:
        agent_kit = AgentKit(AgentKitConfig(
            wallet_provider=CdpEvmWalletProvider(...),
            action_providers=[kevros_governance_provider(agent_id="my-agent")]
        ))
    """
    return KevrosGovernanceProvider(
        api_key=api_key,
        agent_id=agent_id,
        gateway_url=gateway_url,
    )
