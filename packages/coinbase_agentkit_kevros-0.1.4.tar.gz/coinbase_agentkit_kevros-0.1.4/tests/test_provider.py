"""Unit tests for KevrosGovernanceProvider."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, Optional
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Mock the GovernanceClient responses
# ---------------------------------------------------------------------------

class _MockDecision:
    value = "ALLOW"

@dataclass
class _MockVerifyResponse:
    decision: Any = None
    verification_id: str = "vrf_test_001"
    reason: str = "Within policy bounds"
    epoch: int = 42
    provenance_hash: str = "abc123"
    timestamp_utc: str = "2026-02-26T12:00:00Z"
    release_token: str = "tok_test"
    applied_action: Optional[Dict] = None
    policy_applied: Optional[Dict] = None
    hash_prev: str = "prev_hash"

    def __post_init__(self):
        if self.decision is None:
            self.decision = _MockDecision()

@dataclass
class _MockAttestResponse:
    attestation_id: str = "att_test_001"
    epoch: int = 42
    hash_prev: str = "prev_hash"
    hash_curr: str = "curr_hash"
    timestamp_utc: str = "2026-02-26T12:00:00Z"
    chain_length: int = 15
    pqc_block_ref: Optional[str] = None

@dataclass
class _MockBindResponse:
    intent_id: str = "int_test_001"
    intent_hash: str = "intent_hash"
    binding_id: str = "bind_test_001"
    binding_hmac: str = "hmac_test"
    command_hash: str = "cmd_hash"
    epoch: int = 42
    timestamp_utc: str = "2026-02-26T12:00:00Z"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_client():
    """Create a mocked GovernanceClient."""
    client = MagicMock()
    client.verify.return_value = _MockVerifyResponse()
    client.attest.return_value = _MockAttestResponse()
    client.bind.return_value = _MockBindResponse()
    client.verify_peer.return_value = {
        "agent_id": "peer-agent",
        "trust_score": 1.0,
        "chain_length": 120,
        "attestation_count": 95,
        "outcome_count": 30,
        "achieved_count": 30,
        "chain_intact": True,
    }
    return client


@pytest.fixture
def provider(mock_client):
    """Create a KevrosGovernanceProvider with mocked client."""
    with patch("kevros_agentkit.GovernanceClient", return_value=mock_client):
        from kevros_agentkit import KevrosGovernanceProvider
        p = KevrosGovernanceProvider(api_key="kvrs_test_key", agent_id="test-agent")
        p._client = mock_client
        return p


@pytest.fixture
def wallet():
    """Mock WalletProvider."""
    return MagicMock()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestVerifyAction:
    def test_verify_returns_json(self, provider, wallet):
        result = provider.verify_action(wallet, {
            "action_type": "trade",
            "action_payload": {"asset": "ETH", "amount": 1.0},
            "agent_id": "test-agent",
        })
        data = json.loads(result)
        assert data["decision"] == "ALLOW"
        assert data["verification_id"] == "vrf_test_001"
        assert data["epoch"] == 42

    def test_verify_with_policy_context(self, provider, wallet, mock_client):
        provider.verify_action(wallet, {
            "action_type": "transfer",
            "action_payload": {"to": "0xabc", "amount": 500},
            "agent_id": "test-agent",
            "policy_context": {"max_amount": 1000},
        })
        mock_client.verify.assert_called_once()
        call_kwargs = mock_client.verify.call_args
        assert call_kwargs.kwargs.get("policy_context") == {"max_amount": 1000}

    def test_verify_error_handling(self, provider, wallet, mock_client):
        mock_client.verify.side_effect = RuntimeError("Network error")
        result = provider.verify_action(wallet, {
            "action_type": "trade",
            "action_payload": {},
            "agent_id": "test",
        })
        data = json.loads(result)
        assert "error" in data
        assert "Network error" in data["error"]


class TestAttestProvenance:
    def test_attest_returns_json(self, provider, wallet):
        result = provider.attest_provenance(wallet, {
            "agent_id": "test-agent",
            "action_description": "Executed ETH trade",
            "action_payload": {"asset": "ETH", "amount": 1.0, "price": 3200},
        })
        data = json.loads(result)
        assert data["attestation_id"] == "att_test_001"
        assert data["chain_length"] == 15
        assert data["hash_curr"] == "curr_hash"

    def test_attest_with_context(self, provider, wallet, mock_client):
        provider.attest_provenance(wallet, {
            "agent_id": "test-agent",
            "action_description": "Deployed contract",
            "action_payload": {"contract": "0xdef"},
            "context": {"network": "base-mainnet"},
        })
        call_kwargs = mock_client.attest.call_args
        assert call_kwargs.kwargs.get("context") == {"network": "base-mainnet"}


class TestBindIntent:
    def test_bind_returns_json(self, provider, wallet):
        result = provider.bind_intent(wallet, {
            "agent_id": "test-agent",
            "intent_type": "COMMUNICATION",
            "intent_description": "Send status update to coordinator",
            "command_payload": {"message": "Task complete", "recipient": "coord-01"},
        })
        data = json.loads(result)
        assert data["intent_id"] == "int_test_001"
        assert data["binding_hmac"] == "hmac_test"

    def test_bind_invalid_intent_type_falls_back(self, provider, wallet, mock_client):
        """Invalid intent_type should fall back to AI_GENERATED."""
        provider.bind_intent(wallet, {
            "agent_id": "test-agent",
            "intent_type": "INVALID_TYPE",
            "intent_description": "Something",
            "command_payload": {},
        })
        call_kwargs = mock_client.bind.call_args
        from kevros_governance import IntentType
        assert call_kwargs.kwargs["intent_type"] == IntentType.AI_GENERATED

    def test_bind_with_goal_state(self, provider, wallet, mock_client):
        provider.bind_intent(wallet, {
            "agent_id": "test-agent",
            "intent_type": "AI_GENERATED",
            "intent_description": "Execute trade",
            "command_payload": {"action": "buy_eth"},
            "goal_state": {"eth_balance_increased": True},
        })
        call_kwargs = mock_client.bind.call_args
        assert call_kwargs.kwargs.get("goal_state") == {"eth_balance_increased": True}


class TestCheckPeerTrust:
    def test_check_peer_returns_json(self, provider, wallet):
        result = provider.check_peer_trust(wallet, {
            "agent_id": "peer-agent",
        })
        data = json.loads(result)
        assert data["trust_score"] == 1.0
        assert data["chain_length"] == 120

    def test_check_peer_not_found(self, provider, wallet, mock_client):
        mock_client.verify_peer.return_value = {
            "error": "not_found",
            "detail": "No records for agent: unknown-agent",
        }
        result = provider.check_peer_trust(wallet, {"agent_id": "unknown-agent"})
        data = json.loads(result)
        assert data["error"] == "not_found"


class TestProviderMeta:
    def test_supports_all_networks(self, provider):
        assert provider.supports_network("base-mainnet") is True
        assert provider.supports_network("ethereum-mainnet") is True
        assert provider.supports_network("anything") is True

    def test_factory_function(self, mock_client):
        with patch("kevros_agentkit.GovernanceClient", return_value=mock_client):
            from kevros_agentkit import kevros_governance_provider
            p = kevros_governance_provider(agent_id="factory-test")
            assert isinstance(p, object)  # KevrosGovernanceProvider
