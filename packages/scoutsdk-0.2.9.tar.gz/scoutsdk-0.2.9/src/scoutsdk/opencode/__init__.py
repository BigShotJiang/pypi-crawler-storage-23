from .opencode import opencode

__all__ = ["opencode"]
