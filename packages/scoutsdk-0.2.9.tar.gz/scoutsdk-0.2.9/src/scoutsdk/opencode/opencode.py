import json
import os
import re
import subprocess
from typing import Any
from ansi2html import Ansi2HTMLConverter
from ..api.function_progress import HtmlFunctionProgress
from ..api.project_helpers import scout


def strip_ansi_and_full_path(text: str) -> str:
    # Detect file paths containing code_create_directory/ and extract just the filename
    code_dir_pattern = re.compile(r"[^\s]*code_create_directory/([^\s]+)")
    text = code_dir_pattern.sub(r"\1", text)

    conv = Ansi2HTMLConverter(inline=True)
    text = conv.convert(text, full=False)

    return text


def opencode(prompt: str, update_progress: bool = True) -> str:
    if update_progress:
        progress = HtmlFunctionProgress("<p>Starting code ...</p>")

    package_executor = os.environ.get("JAVASCRIPT_PACKAGE_EXCUTOR", "bunx")

    variables_and_headers = os.environ.copy()

    scout_context_variables: dict[str, Any]
    if scout.context.get("SCOUT_CODE_MODEL_ID"):
        scout_context_variables = scout.context.copy()
    else:
        with open("scout_variables.json", "r") as f:
            scout_context_variables = json.load(f)

    scout_code_model_id = scout_context_variables.get("SCOUT_CODE_MODEL_ID")
    if not scout_code_model_id:
        raise Exception("Variable SCOUT_CODE_MODEL_ID not set")
    scout_context_variables.pop("SCOUT_FUNCTION_PROGRESS_UPLOAD_URL", None)
    variables_and_headers.update({"SCOUT_CONTEXT": json.dumps(scout_context_variables)})

    opencode_process = subprocess.Popen(
        [
            package_executor,
            "opencode",
            "--model",
            f"scout/{scout_code_model_id}",
            "run",
            prompt,
        ],
        env=variables_and_headers,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    last_result = ""
    if opencode_process.stdout:
        for line in opencode_process.stdout:
            if len(line.strip()) > 0 and last_result != line.strip():
                last_result = line.strip()
                if update_progress:
                    progress.append(f"<p>{strip_ansi_and_full_path(last_result)}</p>")
                print(last_result)

    opencode_process.wait()
    return last_result
