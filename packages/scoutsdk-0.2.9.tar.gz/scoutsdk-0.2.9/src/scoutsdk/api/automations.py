"""Automations API for Scout SDK."""

from typing import Optional, List, Dict, Any, Callable
from pydantic import BaseModel

from .request_utils import RequestUtils
from scouttypes.automations import (
    AutomationResponse,
    AutomationPayload,
    AutomationRunResponse,
)


class AutomationsAPI:
    """API client for automation operations."""

    def __init__(self, base_url: str, headers: dict, retry_strategy: Callable) -> None:
        self._base_url = base_url
        self._headers = headers
        self._retry_strategy = retry_strategy

    def create(
        self,
        name: str,
        assistant_id: str,
        payload: AutomationPayload | Dict[str, Any],
        schedules: Dict[str, Any],
        external_services: List[str],
    ) -> AutomationResponse:
        """
        Create a new automation.

        Args:
            name (str): The name of the automation.
            assistant_id (str): The ID of the assistant to associate with this automation.
            payload (AutomationPayload | Dict[str, Any]): The automation payload configuration.
            schedules (Dict[str, Any]): Schedule configuration for the automation.
            external_services (List[str]): List of external services the automation can use.

        Returns:
            AutomationResponse: The created automation object.
        """
        request_payload = {
            "name": name,
            "assistant_id": assistant_id,
            "payload": payload.model_dump()
            if isinstance(payload, BaseModel)
            else payload,
            "schedules": schedules,
            "external_services": external_services,
        }

        response, status_code = RequestUtils.post(
            url=f"{self._base_url}/api/automations",
            headers=self._headers,
            json_payload=request_payload,
            retry_strategy=self._retry_strategy,
        )

        return AutomationResponse.model_validate(response)

    def get(self, automation_id: str) -> AutomationResponse:
        """
        Retrieve a specific automation by its ID.

        Args:
            automation_id (str): The ID of the automation to retrieve.

        Returns:
            AutomationResponse: The automation object retrieved from the API.
        """
        response, status_code = RequestUtils.get(
            url=f"{self._base_url}/api/automations/{automation_id}",
            headers=self._headers,
            retry_strategy=self._retry_strategy,
        )

        return AutomationResponse.model_validate(response)

    def list(self, assistant_id: Optional[str] = None) -> List[AutomationResponse]:
        """
        Retrieve a list of all automations for a specific assistant.

        Args:
            assistant_id (str): The ID of the assistant to get automations for.

        Returns:
            List[AutomationResponse]: A list of automation objects for the specified assistant.
        """
        endpoint = (
            f"{self._base_url}/api/assistants/{assistant_id}/automations"
            if assistant_id
            else f"{self._base_url}/api/automations"
        )

        response, status_code = RequestUtils.get(
            url=endpoint,
            headers=self._headers,
            retry_strategy=self._retry_strategy,
        )

        return [
            AutomationResponse.model_validate(automation) for automation in response
        ]

    def update(
        self,
        automation_id: str,
        name: Optional[str] = None,
        payload: Optional[AutomationPayload | Dict[str, Any]] = None,
        schedules: Optional[Dict[str, Any]] = None,
        external_services: Optional[List[str]] = None,
    ) -> AutomationResponse:
        """
        Update an existing automation.

        Args:
            automation_id (str): The ID of the automation to update.
            name (Optional[str]): The new name for the automation.
            payload (Optional[AutomationPayload | Dict[str, Any]]): The new payload configuration.
            schedules (Optional[Dict[str, Any]]): The new schedule configuration.
            external_services (Optional[List[str]]): The new list of external services.

        Returns:
            AutomationResponse: The updated automation object.
        """
        request_payload: dict[str, Any] = {}

        if name is not None:
            request_payload["name"] = name
        if payload is not None:
            request_payload["payload"] = (
                payload.model_dump() if isinstance(payload, BaseModel) else payload
            )
        if schedules is not None:
            request_payload["schedules"] = schedules
        if external_services is not None:
            request_payload["external_services"] = external_services

        response, status_code = RequestUtils.put(
            url=f"{self._base_url}/api/automations/{automation_id}",
            headers=self._headers,
            payload=request_payload,
            retry_strategy=self._retry_strategy,
        )

        return AutomationResponse.model_validate(response)

    def delete(self, automation_id: str) -> None:
        """
        Delete an automation.

        Args:
            automation_id (str): The ID of the automation to delete.
        """
        response, status_code = RequestUtils.delete(
            url=f"{self._base_url}/api/automations/{automation_id}",
            headers=self._headers,
            retry_strategy=self._retry_strategy,
        )
        # Delete typically returns empty response

    def start(self, automation_id: str) -> AutomationRunResponse:
        """
        Create a new automation run (trigger the automation).

        Args:
            automation_id (str): The ID of the automation to run.
            function_progress_key (Optional[str]): Optional progress tracking key.

        Returns:
            AutomationRunResponse: The created automation run object.
        """
        response, status_code = RequestUtils.post(
            url=f"{self._base_url}/api/automations/{automation_id}/run",
            headers=self._headers,
            json_payload={},
            retry_strategy=self._retry_strategy,
        )

        return AutomationRunResponse.model_validate(response)

    def runs(self, automation_id: str) -> List[AutomationRunResponse]:
        """
        Get all runs for a specific automation.

        Args:
            automation_id (str): The ID of the automation.

        Returns:
            List[AutomationRunResponse]: A list of automation run objects.
        """
        response, status_code = RequestUtils.get(
            url=f"{self._base_url}/api/automations/{automation_id}/runs",
            headers=self._headers,
            retry_strategy=self._retry_strategy,
        )

        return [AutomationRunResponse.model_validate(run) for run in response]

    def run(self, run_id: str) -> AutomationRunResponse:
        """
        Get a specific automation run by its ID.

        Args:
            run_id (str): The ID of the automation run.

        Returns:
            AutomationRunResponse: The automation run object.
        """
        response, status_code = RequestUtils.get(
            url=f"{self._base_url}/api/automations/runs/{run_id}",
            headers=self._headers,
            retry_strategy=self._retry_strategy,
        )

        return AutomationRunResponse.model_validate(response)

    def delete_run(self, run_id: str) -> None:
        """
        Delete a specific automation run by its ID.

        Args:
            run_id (str): The ID of the automation run to delete.
        """
        response, status_code = RequestUtils.delete(
            url=f"{self._base_url}/api/automations/runs/{run_id}",
            headers=self._headers,
            retry_strategy=self._retry_strategy,
        )
        # Delete typically returns empty response
