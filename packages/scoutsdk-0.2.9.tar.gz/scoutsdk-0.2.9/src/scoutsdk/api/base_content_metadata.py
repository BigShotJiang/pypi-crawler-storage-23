from typing import Protocol, runtime_checkable, Any, Optional


@runtime_checkable
class ContentMetadataProtocol(Protocol):
    """Protocol for objects that have content and metadata fields."""

    content: str
    metadata: Optional[Any]


__all__ = ["ContentMetadataProtocol"]
