from datetime import datetime, timezone
import fnmatch
from typing import Callable, Optional, Type
import importlib

from pydantic import BaseModel

from ..api import ScoutAPI, AssistantDataList


from .indexers_impl.utils.assistant_data_utils import (
    add_data_to_assistant,
    delete_url_assistant_data_entries,
    update_url_indexed_date,
)


class Indexer:
    def __init__(self) -> None:
        self.api = ScoutAPI()

    def index_document(
        self, url: str, local_path: str, is_important: bool
    ) -> Optional[AssistantDataList]:
        pass


class RegisteredIndexer(BaseModel):
    class_type: Type[Indexer]
    masks: list[str]


class IndexerClassDecorator:
    _registered_indexers: list[RegisteredIndexer]

    def __init__(self) -> None:
        from .indexers_impl.spreadsheet_indexer import SpreadsheetIndexer
        from .indexers_impl.summary_indexer import SummaryIndexer
        from .indexers_impl.document_indexer import DocumentIndexer

        self._registered_indexers = [
            RegisteredIndexer(
                class_type=DocumentIndexer,
                masks=["*.docx", "*.txt", "*.pdf"],
            ),
            RegisteredIndexer(class_type=SummaryIndexer, masks=["*.ppt", "*.pptx"]),
            RegisteredIndexer(
                class_type=SpreadsheetIndexer,
                masks=["*.csv", "*.xlsx", "*.xls", "*.xlsm"],
            ),
        ]

    def register(self, masks: list[str]) -> Callable[[Type[Indexer]], Type[Indexer]]:
        def decorator(class_type: Type[Indexer]) -> Type[Indexer]:
            self._registered_indexers.insert(
                0, RegisteredIndexer(class_type=class_type, masks=masks)
            )
            return class_type

        return decorator

    def indexer_exists_for_file(
        self, url: str, indexer_config: Optional[dict[str, str]] = None
    ) -> bool:
        return self.indexer_for_file(url, indexer_config) is not None

    def indexer_for_file(
        self, local_path: str, indexer_config: Optional[dict[str, str]] = None
    ) -> Optional[Indexer]:
        # Check for override configuration first
        for pattern, indexer_class_name in (indexer_config or {}).items():
            if fnmatch.fnmatch(local_path, pattern):
                return self._get_indexer_by_class_name(indexer_class_name)

        # Fall back to default registered indexers
        for registered_indexer in self._registered_indexers:
            for pattern in registered_indexer.masks:
                if fnmatch.fnmatch(local_path, pattern):
                    return registered_indexer.class_type()
        return None

    def _get_indexer_by_class_name(self, class_name: str) -> Optional[Indexer]:
        # First try to find in registered indexers
        for registered_indexer in self._registered_indexers:
            if registered_indexer.class_type.__name__ == class_name:
                return registered_indexer.class_type()

        # If not found, try to import dynamically from indexers_impl
        try:
            module_name = f".indexers_impl.{self._class_name_to_module(class_name)}"
            module = importlib.import_module(module_name, package=__package__)
            indexer_class = getattr(module, class_name)
            return indexer_class()
        except (ImportError, AttributeError):
            print(f"Warning: Could not find indexer class {class_name}")
            return None

    def _class_name_to_module(self, class_name: str) -> str:
        # Convert CamelCase to snake_case for module name
        import re

        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", class_name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()

    def indexers(self) -> list[RegisteredIndexer]:
        return self._registered_indexers

    def index_document(
        self,
        url: str,
        local_path: str,
        is_important: bool,
        indexer_config: Optional[dict[str, str]] = None,
    ) -> None:
        indexer = self.indexer_for_file(local_path, indexer_config)
        if indexer is None:
            print("No indexer found for", url)
        else:
            indexer_name = indexer.__class__.__name__
            print(
                "Indexing",
                is_important,
                url,
                f"({local_path})",
                f"{indexer_name} - (Summary)" if not is_important else "",
            )
            assistant_data_list = indexer.index_document(url, local_path, is_important)
            delete_url_assistant_data_entries(url)
            if assistant_data_list is not None:
                add_data_to_assistant(assistant_data_list)
                update_url_indexed_date(url, datetime.now(timezone.utc).isoformat())


indexers = IndexerClassDecorator()
