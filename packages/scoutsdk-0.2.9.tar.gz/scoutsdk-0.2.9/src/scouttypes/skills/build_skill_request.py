from typing import Optional
from pydantic import BaseModel, ConfigDict


class BuildSkillRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    instructions: str
    external_services: list[str] = []
    input_files: list[str] = []
    skill_filename: Optional[str] = None


__all__ = ["BuildSkillRequest"]
