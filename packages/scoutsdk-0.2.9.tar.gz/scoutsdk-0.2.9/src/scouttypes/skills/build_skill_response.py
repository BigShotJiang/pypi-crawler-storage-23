from pydantic import BaseModel, ConfigDict


class BuildSkillResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    run_protected_url: str
    function_progress_url: str


__all__ = ["BuildSkillResponse"]
