"""Automation types for Scout SDK."""

from .automation import (
    AutomationResponse,
    AutomationListResponse,
    CreateAutomationRequest,
    UpdateAutomationRequest,
    AutomationPayload,
    AutomationPayloadType,
)
from .automation_run import (
    AutomationRunResponse,
    AutomationRunListResponse,
    CreateAutomationRunRequest,
    UpdateAutomationRunRequest,
    AutomationRunStatus,
)

__all__ = [
    # Automation types
    "AutomationResponse",
    "AutomationListResponse",
    "CreateAutomationRequest",
    "UpdateAutomationRequest",
    "AutomationPayload",
    "AutomationPayloadType",
    # Automation run types
    "AutomationRunResponse",
    "AutomationRunListResponse",
    "CreateAutomationRunRequest",
    "UpdateAutomationRunRequest",
    "AutomationRunStatus",
]
