"""Automation type definitions for Scout SDK."""

from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
from pydantic import BaseModel


class AutomationPayloadType(str, Enum):
    """Automation payload types."""

    FUNCTION = "function"
    CONVERSATION = "conversation"


class AutomationPayload(BaseModel):
    """Automation payload definition."""

    type: AutomationPayloadType
    function: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None
    message: Optional[str] = None


class AutomationResponse(BaseModel):
    """Automation response from API."""

    id: str
    user_id: str
    assistant_id: str
    name: str
    payload: AutomationPayload
    schedules: Dict[str, Any]
    external_services: List[str]
    created_at: datetime
    updated_at: datetime


class AutomationListResponse(BaseModel):
    """List of automations response."""

    automations: List[AutomationResponse]


class CreateAutomationRequest(BaseModel):
    """Request to create a new automation."""

    name: str
    payload: AutomationPayload
    schedules: Dict[str, Any]
    external_services: List[str]


class UpdateAutomationRequest(BaseModel):
    """Request to update an automation."""

    name: Optional[str] = None
    payload: Optional[AutomationPayload] = None
    schedules: Optional[Dict[str, Any]] = None
    external_services: Optional[List[str]] = None
