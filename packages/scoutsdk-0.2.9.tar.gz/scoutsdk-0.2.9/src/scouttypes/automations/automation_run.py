"""Automation run type definitions for Scout SDK."""

from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
from pydantic import BaseModel


class AutomationRunStatus(str, Enum):
    """Automation run status types."""

    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


class AutomationRunResponse(BaseModel):
    """Automation run response from API."""

    id: str
    automation_id: str
    status: AutomationRunStatus
    result: Optional[Dict[str, Any]] = None
    function_progress_key: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class AutomationRunListResponse(BaseModel):
    """List of automation runs response."""

    runs: List[AutomationRunResponse]


class CreateAutomationRunRequest(BaseModel):
    """Request to create a new automation run."""

    function_progress_key: Optional[str] = None


class UpdateAutomationRunRequest(BaseModel):
    """Request to update an automation run."""

    status: Optional[AutomationRunStatus] = None
    result: Optional[Dict[str, Any]] = None
    function_progress_key: Optional[str] = None
