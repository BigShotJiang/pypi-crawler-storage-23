from pydantic import BaseModel, ConfigDict
from typing import Optional


class LlmModel(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str
    api_id: Optional[str] = None
    displayName: str  # noqa: N815
    description: str
    max_input_tokens: Optional[int] = None
    tags: Optional[list[str]] = None
    supports_tools: bool = True
    llm_args: Optional[dict] = None
    usage_pricing: Optional[dict] = None


__all__ = ["LlmModel"]
