from enum import StrEnum


class ImageResolution(StrEnum):
    ONE_K = "1k"
    TWO_K = "2k"
    FOUR_K = "4k"


__all__ = ["ImageResolution"]
