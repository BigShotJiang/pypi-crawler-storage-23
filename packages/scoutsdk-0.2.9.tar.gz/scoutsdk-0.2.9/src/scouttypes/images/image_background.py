from enum import StrEnum


class ImageBackground(StrEnum):
    AUTO = "auto"
    OPAQUE = "opaque"
    TRANSPARENT = "transparent"
    WHITE = "white"


__all__ = ["ImageBackground"]
