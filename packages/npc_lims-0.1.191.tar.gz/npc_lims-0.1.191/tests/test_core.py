import npc_lims


def test_import_package():
    pass
