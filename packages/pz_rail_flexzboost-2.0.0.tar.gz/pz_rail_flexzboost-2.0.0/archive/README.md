## This directory contains **archived** configuration files. 

Previously requirements.txt file was necessary to define a dependency on Flexcode 
while it was unavailable on PyPI. It has since been published to PyPI, and the 
dependency is now moved into pyproject.toml.

The pyproject.toml file is the source of truth for building and dependencies now, 
however, the files in this directory will be retained for a period of time as a 
convenience.

## These files will be removed at a later date!

Please use them only for reference. 
Update pyproject.toml in the base directory if changes to the build are required.
