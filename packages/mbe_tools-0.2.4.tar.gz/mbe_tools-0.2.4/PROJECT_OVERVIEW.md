# Project Overview

`mbe-tools` is a Python toolkit for Many-Body Expansion (MBE) workflows in computational chemistry. It focuses on a full pipeline: fragmenting clusters, generating subset geometries, building Q-Chem/ORCA inputs, preparing HPC run scripts, parsing outputs into JSONL, and assembling MBE energies for analysis.

## What this project does

- Cluster handling: read/write `.xyz`, fragment clusters (water heuristic or connectivity), and sample fragments.
- MBE generation: generate subset geometries up to order K with optional counterpoise (ghost atom) correction.
- Input and HPC prep: render Q-Chem/ORCA input files and PBS/Slurm scripts (with run-control wrapper).
- Parsing and analysis: parse Q-Chem/ORCA outputs to JSONL, then assemble MBE(k) energies and export summaries.

## How the pieces fit together

Typical flow:

1. **Read + fragment** an input cluster from `.xyz`.
2. **Generate subsets** (monomers, dimers, trimers, ...) with MBE naming and optional CP correction.
3. **Build inputs** for Q-Chem/ORCA.
4. **Create HPC scripts** for batch execution.
5. **Parse outputs** into JSONL records.
6. **Analyze** the JSONL for MBE totals, summaries, and plots.

The CLI `mbe` in `src/mbe_tools/cli.py` wires these steps; the same functions are available as a Python API.

## Repository structure

```
mbe-tools/
├── src/mbe_tools/              # Library code
│   ├── cli.py                  # Typer CLI entrypoint
│   ├── cluster.py              # XYZ IO, fragmentation, sampling
│   ├── mbe.py                  # Subset geometry generation
│   ├── mbe_math.py             # Inclusion-exclusion math
│   ├── input_builder.py        # Q-Chem/ORCA input rendering
│   ├── hpc_templates.py        # PBS/Slurm scripts + run-control
│   ├── analysis.py             # JSONL analysis + MBE assembly
│   ├── config.py               # Settings and config resolution
│   ├── jsonl_selector.py       # Default JSONL selection
│   ├── backends/               # Backend-specific formatting
│   └── parsers/                # Output parsing and metadata inference
├── notebooks/                  # Tutorial notebooks and sample inputs
├── tests/                      # Test suite
├── README.md                   # Full user docs
└── pyproject.toml              # Package metadata
```

## Key modules and responsibilities

- `cluster.py`: XYZ parsing/writing; fragmentation (water heuristic, connectivity); random/spatial sampling.
- `mbe.py`: MBE subset generation, ordering, and CP handling; emits geometry blocks.
- `input_builder.py`: Input file templates for Q-Chem/ORCA with method/basis/config options.
- `hpc_templates.py`: PBS/Slurm templates, chunking, and optional run-control logic.
- `parsers/`: Program auto-detection, metadata inference, output parsing to JSONL.
- `analysis.py` + `mbe_math.py`: Inclusion–exclusion formulas, totals by order, exports.
- `config.py`: TOML + env + local settings precedence used by CLI.
- `cli.py`: Exposes the workflow as the `mbe` command.

## Data formats

- **XYZ**: input clusters and sampled fragment sets.
- **.geom**: internal geometry blocks used for job generation.
- **JSONL**: parsed job results; one record per subset with energies, metadata, and indices.

## Extending the project

- **Add a new backend**: implement formatting in `src/mbe_tools/backends/` and wire it into
  `mbe.py` and `input_builder.py`.
- **Add a parser**: follow `src/mbe_tools/parsers/base.py` and update auto-detect in
  `src/mbe_tools/parsers/io.py`.
- **Add CLI commands**: implement in `cli.py` and reuse existing module functions.

## Tests and notebooks

- Tests live in `tests/` and cover parsing, CLI behavior, and MBE math.
- Notebooks in `notebooks/` provide end-to-end walkthroughs.
