from wbcore.menus import ItemPermission, MenuItem

INSTRUMENTMETRIC_MENUITEM = MenuItem(
    label="Metrics",
    endpoint="metric:instrumentmetric-list",
    endpoint_get_parameters={"parent_metric__isnull": True},
    permission=ItemPermission(
        permissions=["metric.view_instrumentmetric"], method=lambda request: request.user.is_internal
    ),
)
