from datetime import date

from oauthlib.uri_validate import query
from wbcore import filters as wb_filters

from wbfdm.models import InstrumentListThroughModel


class InstrumentListThroughModelFilterSet(wb_filters.FilterSet):
    validity_date = wb_filters.DateFilter(
        default=lambda: date.today(),
        help_text="The relationship validity date",
        label="validity_date",
        method="filter_validity_date",
        required=True,
    )

    validated = wb_filters.BooleanFilter(default=True, label="validated")

    def filter_validity_date(self, queryset, name, value):
        if value:
            return queryset.filter(timespan__contains=value)
        return query

    class Meta:
        model = InstrumentListThroughModel
        fields = {
            "instrument_list": ["exact"],
            "instrument": ["exact"],
            "validated": ["exact"],
        }
