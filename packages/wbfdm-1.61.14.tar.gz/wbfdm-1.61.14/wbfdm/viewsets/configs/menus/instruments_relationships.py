from wbcore.menus import ItemPermission, MenuItem

INSTRUMENTFAVORITEGROUP_MENUITEM = MenuItem(
    label="Favorite Group",
    endpoint="wbfdm:favoritegroup-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbfdm.view_instrumentfavoritegroup"]
    ),
)

CLASSIFIEDINSTRUMENTS_MENUITEM = MenuItem(
    label="Classified Instruments",
    endpoint="wbfdm:classifiedinstrument-list",
    permission=ItemPermission(method=lambda request: request.user.is_internal, permissions=["wbfdm.view_instrument"]),
)

INSTRUMENT_REQUEST_MENUITEM = MenuItem(
    label="Instrument Requests",
    endpoint="wbfdm:instrumentrequest-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbfdm.view_instrumentrequest"]
    ),
    add=MenuItem(
        label="Create Instrument Request",
        endpoint="wbfdm:instrumentrequest-list",
        permission=ItemPermission(
            method=lambda request: request.user.is_internal, permissions=["wbfdm.add_instrumentrequest"]
        ),
    ),
)
