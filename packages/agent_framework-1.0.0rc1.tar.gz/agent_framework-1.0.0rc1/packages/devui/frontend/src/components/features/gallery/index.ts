/**
 * Gallery component exports
 */

export { GalleryView } from './gallery-view';