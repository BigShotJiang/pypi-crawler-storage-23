# Get Started with Microsoft Agent Framework Claude

Please install this package via pip:

```bash
pip install agent-framework-claude --pre
```

## Claude Agent

The Claude agent enables integration with Claude Agent SDK, allowing you to interact with Claude's agentic capabilities through the Agent Framework.
