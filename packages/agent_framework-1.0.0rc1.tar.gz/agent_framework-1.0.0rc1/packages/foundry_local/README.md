# Get Started with Microsoft Agent Framework Foundry Local

Please install this package as the extra for `agent-framework`:

```bash
pip install agent-framework-foundry-local --pre
```

and see the [README](https://github.com/microsoft/agent-framework/tree/main/python/README.md) for more information.

## Foundry Local Sample

See the [Foundry Local provider sample](../../samples/02-agents/providers/foundry_local/foundry_local_agent.py) for a runnable example.
