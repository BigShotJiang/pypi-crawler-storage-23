import contextlib
import datetime
import http
import typing as t

import httpx
import keyring
import pydantic

import httpx_oauth2_flows
from httpx_oauth2_flows._lib import Scope, Url, jwt, util

from . import authorization_code, client_credentials, jwt_bearer, refresh_token
from .exceptions import BaseError
from .grant_type import GrantType
from .token_response import SuccessfulTokenResponse


class AuthorizationCodeFlow(authorization_code.Config, frozen=True):
    kind: t.Literal['authorization_code'] = 'authorization_code'

    async def execute(self, http_client: httpx.AsyncClient) -> SuccessfulTokenResponse:
        return await authorization_code.execute(self, http_client)

    GRANT_TYPE: t.ClassVar = authorization_code.GRANT_TYPE


class ClientCredentialsFlow(client_credentials.Config, frozen=True):
    kind: t.Literal['client_credentials'] = 'client_credentials'

    async def execute(self, http_client: httpx.AsyncClient) -> SuccessfulTokenResponse:
        return await client_credentials.execute(self, http_client)

    GRANT_TYPE: t.ClassVar = client_credentials.GRANT_TYPE


class JwtBearerFlow(jwt_bearer.Config, frozen=True):
    kind: t.Literal['jwt_bearer'] = 'jwt_bearer'

    async def execute(self, http_client: httpx.AsyncClient) -> SuccessfulTokenResponse:
        return await jwt_bearer.execute(self, http_client)

    GRANT_TYPE: t.ClassVar = jwt_bearer.GRANT_TYPE


type Flow = AuthorizationCodeFlow | ClientCredentialsFlow | JwtBearerFlow


class CachedToken(pydantic.BaseModel):
    response: SuccessfulTokenResponse
    expires_at: datetime.datetime
    grant_type: GrantType
    client_id: str
    auth_server: Url


class Auth(httpx.Auth):
    def __init__(self, flow: Flow, service_name: str | None = None) -> None:
        self.flow = flow
        self.service_name = service_name or httpx_oauth2_flows.PACKAGE_NAME
        self.username = util.base64url_encode(str(self.flow.auth_server))
        self._cached_token: CachedToken | None = None

        super().__init__()

    def sync_auth_flow(
        self, request: httpx.Request
    ) -> t.Generator[httpx.Request, httpx.Response, None]:
        raise NotImplementedError

    def create_cached_token(self, response: SuccessfulTokenResponse) -> CachedToken:
        if response.expires_in is None:
            parsed_payload = jwt.parse_payload(response.access_token)
            if parsed_payload.exp is None:
                msg = 'Access token does not expire'
                raise NotImplementedError(msg)

            expires_at = datetime.datetime.fromtimestamp(parsed_payload.exp, tz=datetime.UTC)
        else:
            expires_at = util.now() + response.expires_in

        cached_token = CachedToken(
            response=response,
            expires_at=expires_at,
            grant_type=self.flow.GRANT_TYPE,
            auth_server=self.flow.auth_server,
            client_id=self.flow.client_id,
        )
        keyring.set_password(
            service_name=self.service_name,
            username=self.username,
            password=cached_token.model_dump_json(),
        )
        return cached_token

    def clear_stored_token(self) -> None:
        keyring.delete_password(service_name=self.service_name, username=self.username)

    def try_get_stored_token(self) -> None:
        match self.flow:
            case AuthorizationCodeFlow():
                cached_token_json = keyring.get_password(
                    service_name=self.service_name, username=self.username
                )
                if cached_token_json is not None:
                    with contextlib.suppress(pydantic.ValidationError):
                        self._cached_token = CachedToken.model_validate_json(cached_token_json)

            case ClientCredentialsFlow() | JwtBearerFlow():
                pass

    async def try_refresh_token(self, http_client: httpx.AsyncClient) -> None:
        if (
            self._cached_token is not None
            and self._cached_token.response.refresh_token is not None
            and self._cached_token.grant_type
            in (GrantType.AUTHORIZATION_CODE, GrantType.REFRESH_TOKEN)
        ):
            with contextlib.suppress(BaseError):
                response = await refresh_token.execute(
                    config=refresh_token.Config(
                        auth_server=self._cached_token.auth_server,
                        client_id=self._cached_token.client_id,
                        refresh_token=self._cached_token.response.refresh_token,
                        scope=Scope(frozenset(self._cached_token.response.scope.split()))
                        if self._cached_token.response.scope is not None
                        else None,
                    ),
                    http_client=http_client,
                )
                self._cached_token = self.create_cached_token(response)

    async def execute_flow(self, http_client: httpx.AsyncClient) -> None:
        response = await self.flow.execute(http_client)
        self._cached_token = self.create_cached_token(response)

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> t.AsyncGenerator[httpx.Request, httpx.Response]:
        now = util.now()
        request_timeout = util.get_request_timeout(request)

        def is_token_valid(cached_token: CachedToken | None) -> t.TypeGuard[CachedToken]:
            return cached_token is not None and now + request_timeout < cached_token.expires_at

        if not is_token_valid(self._cached_token):
            self.try_get_stored_token()
            if not is_token_valid(self._cached_token):
                async with httpx.AsyncClient() as http_client:
                    await self.try_refresh_token(http_client)
                    if not is_token_valid(self._cached_token):
                        await self.execute_flow(http_client)
                        if not is_token_valid(self._cached_token):
                            msg = 'Invalid token after flow execution'
                            raise RuntimeError(msg)

        request.headers['Authorization'] = (
            f'{self._cached_token.response.token_type} {self._cached_token.response.access_token}'
        )
        res = yield request
        if res.status_code in (http.HTTPStatus.UNAUTHORIZED, http.HTTPStatus.FORBIDDEN):
            self.clear_stored_token()
        await res.aread()
