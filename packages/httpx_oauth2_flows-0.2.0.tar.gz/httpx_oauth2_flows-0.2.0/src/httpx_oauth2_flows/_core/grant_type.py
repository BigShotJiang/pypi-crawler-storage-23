import enum


class GrantType(enum.Enum):
    AUTHORIZATION_CODE = 'authorization_code'
    CLIENT_CREDENTIALS = 'client_credentials'
    JWT_BEARER = 'urn:ietf:params:oauth:grant-type:jwt-bearer'
    REFRESH_TOKEN = 'refresh_token'
