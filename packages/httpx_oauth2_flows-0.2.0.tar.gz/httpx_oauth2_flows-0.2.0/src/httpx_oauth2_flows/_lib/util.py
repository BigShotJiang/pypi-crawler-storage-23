import base64
import dataclasses
import datetime
import json
import typing as t

import httpx
import pydantic


def check_response_status(res: httpx.Response) -> None:
    if not (200 <= res.status_code < 300):
        msg = f'Request failed: {res.url=} {res.status_code=} {res.text=} {res.headers=}'
        raise RuntimeError(msg)


def get_validated_response[T](response: httpx.Response, validator: t.Callable[[bytes], T]) -> T:
    check_response_status(response)
    return validator(response.content)


def get_response_model[T: pydantic.BaseModel](response: httpx.Response, model: type[T]) -> T:
    return get_validated_response(response, model.model_validate_json)


def get_response_json(response: httpx.Response) -> object:
    return get_validated_response(response, json.loads)


def base64url_encode(data: bytes | str) -> str:
    if isinstance(data, str):
        data = data.encode()
    return base64.urlsafe_b64encode(data).decode().replace('=', '')


async def awaitable[T](t: T) -> T:
    return t


def is_any_dict(d: object) -> t.TypeGuard[dict[object, object]]:
    return isinstance(d, dict)


@t.runtime_checkable
class DataclassWithExtra(t.Protocol):
    __dataclass_fields__: t.ClassVar[dict[str, dataclasses.Field[t.Any]]]

    @property
    def extra(self) -> t.Mapping[str, object]: ...


def validate_dataclass_with_extra[T: DataclassWithExtra](cls: t.Type[T], obj: object, /) -> T:
    if not is_any_dict(obj):
        msg = f'object {obj} should be a dict but is a {type(obj)}'
        raise ValueError(msg)

    all_fields = {f.name for f in cls.__dataclass_fields__.values()}

    obj = dict.fromkeys(all_fields) | obj
    known_keys = all_fields - {'extra'}
    known_data = {k: v for k, v in obj.items() if k in known_keys}
    extra_data = {k: v for k, v in obj.items() if k not in known_keys}
    adapter = pydantic.TypeAdapter(cls)
    known_data['extra'] = extra_data
    return adapter.validate_python(known_data)


def now() -> datetime.datetime:
    return datetime.datetime.now(tz=datetime.UTC)


def get_request_timeout(request: httpx.Request) -> datetime.timedelta:
    timeout = request.extensions.get('timeout')
    if timeout is None or not is_any_dict(timeout):
        timeout = {}

    connect = timeout.get('connect') or 60
    read = timeout.get('read') or 60
    write = timeout.get('write') or 60
    pool = timeout.get('pool') or 60

    if not isinstance(connect, (int, float)):
        connect = 60
    if not isinstance(read, (int, float)):
        read = 60
    if not isinstance(write, (int, float)):
        write = 60
    if not isinstance(pool, (int, float)):
        pool = 60

    return datetime.timedelta(seconds=connect + read + write + pool)
