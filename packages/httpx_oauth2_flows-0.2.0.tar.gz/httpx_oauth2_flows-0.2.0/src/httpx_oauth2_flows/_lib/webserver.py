import asyncio
import contextlib
import dataclasses
import datetime
import http
import logging
import time
import typing as t
import urllib.parse

import uvicorn
from uvicorn import _types as asgi

from . import util
from ._types import Error, Url

# Public Types


@dataclasses.dataclass(frozen=True, slots=True)
class Request:
    client: tuple[str, int] | None
    method: str
    path: str
    query: t.Mapping[str, t.Sequence[str]]


@dataclasses.dataclass(frozen=True, slots=True)
class Response:
    content_type: str | None = None
    content: bytes | str | None = None
    status: http.HTTPStatus | None = None
    headers: t.Mapping[str, str] | None = None


type Result[T] = tuple[T, Response]


class Handler[T, R](t.Protocol):
    async def __call__(self, request: Request, ready_result: R, /) -> Result[T]: ...


@dataclasses.dataclass(frozen=True, slots=True)
class Config[T, R]:
    method: http.HTTPMethod
    path: str
    max_wait: datetime.timedelta
    bind_host: str
    handler: Handler[T, R]
    on_ready: t.Callable[[Url], t.Awaitable[R]]


# Private Impl

type _AnyConfig = Config[t.Any, t.Any]

_TEXT_CONTENT_TYPE = 'text/plain'
_BINARY_CONTENT_TYPE = 'application/octet-stream'


def _match_target(scope: asgi.HTTPScope, config: _AnyConfig) -> bool:
    return scope['method'].upper() == config.method and scope['path'] == config.path


def _create_request(scope: asgi.HTTPScope) -> Request:
    return Request(
        client=scope['client'],
        method=scope['method'],
        path=scope['path'],
        query=urllib.parse.parse_qs(scope['query_string'].decode()),
    )


async def _respond(response: Response, send: asgi.ASGISendCallable) -> None:
    status = response.status if response.status is not None else http.HTTPStatus.OK

    content_type = response.content_type
    content = response.content
    if content is None:
        content = f'{status} {status.name}'
    if content_type is None:
        content_type = _TEXT_CONTENT_TYPE if isinstance(content, str) else _BINARY_CONTENT_TYPE
    if isinstance(content, str):
        content = content.encode()

    content_length = f'{len(content)}'

    await send(
        {
            'type': 'http.response.start',
            'status': status,
            'headers': [
                (b'Content-Type', content_type.encode()),
                (b'Content-Length', content_length.encode()),
            ],
        }
    )
    await send({'type': 'http.response.body', 'body': content})


@dataclasses.dataclass(frozen=True, slots=True)
class _App[T, R]:
    config: Config[T, R]

    result: asyncio.Future[T] = dataclasses.field(init=False, default_factory=asyncio.Future[T])
    ready_result_fut: asyncio.Future[R] = dataclasses.field(
        init=False, default_factory=asyncio.Future[R]
    )

    async def __call__(
        self, scope: asgi.Scope, _receive: asgi.ASGIReceiveCallable, send: asgi.ASGISendCallable
    ) -> None:
        match scope['type']:
            case 'lifespan' | 'websocket':
                return
            case 'http':
                if _match_target(scope, self.config):
                    ready_result = await self.ready_result_fut
                    request = _create_request(scope)
                    try:
                        (result_value, response) = await self.config.handler(request, ready_result)
                    except:
                        await _respond(Response(status=http.HTTPStatus.INTERNAL_SERVER_ERROR), send)
                        raise

                    await _respond(response, send)
                    self.result.set_result(result_value)
                else:
                    await _respond(Response(status=http.HTTPStatus.NOT_FOUND), send)


@dataclasses.dataclass(frozen=True, slots=True)
class _Server:
    uvicorn_server: uvicorn.Server
    task: asyncio.Task[None]
    exit: asyncio.Event
    config: _AnyConfig
    started_at: float

    @property
    def url(self) -> Url:
        asyncio_servers = self.uvicorn_server.servers
        if len(asyncio_servers) == 0:
            msg = 'Uvicorn server has no asyncio server'
            raise RuntimeError(msg)

        asyncio_sockets = asyncio_servers[0].sockets

        if len(asyncio_sockets) == 0:
            msg = 'Asyncio server has no sockets'
            raise RuntimeError(msg)

        asyncio_socket = asyncio_sockets[0]

        _, port = asyncio_socket.getsockname()

        if not isinstance(port, int):
            msg = f'Asyncio socket port is not an int: {port=}'
            raise TypeError(msg)

        return Url('', scheme='http', host=self.config.bind_host, port=port)

    def get_exit_reason(self) -> str:
        if self.task.cancelled():
            return 'it was canceled, probably after receiving an expected request'

        exc = self.task.exception()
        if isinstance(exc, TimeoutError):
            time_since_start = time.perf_counter() - self.started_at
            max_wait_seconds = self.config.max_wait.total_seconds()
            if abs(time_since_start - max_wait_seconds) < 1:
                return f'it exceeded the configured maximum wait time of {max_wait_seconds} seconds'

            return (
                f'it exceeded an unknown time limit after {time_since_start} seconds'
                f'the configured maximum wait time is at {max_wait_seconds} seconds'
            )

        if exc is not None:
            return f'it exited because an unexpected exception was raised: {exc!r}'

        if self.uvicorn_server.should_exit:
            return 'it exited on its own, probably after receiving a signal'

        return 'it exited for an unknwon reason'


@contextlib.asynccontextmanager
async def _create_server(
    app: asgi.ASGI3Application, config: _AnyConfig
) -> t.AsyncIterator[_Server]:
    started = asyncio.Event()
    exited = asyncio.Event()

    server = uvicorn.Server(
        uvicorn.Config(
            app,
            host=config.bind_host,
            port=0,
            lifespan='off',
            ws='none',
            limit_max_requests=None,
            callback_notify=lambda: util.awaitable(started.set()),
            log_level=logging.WARNING,
        )
    )

    async def serve() -> None:
        async with asyncio.timeout(config.max_wait.total_seconds()):
            await server.serve()

    task = asyncio.create_task(serve())

    task.add_done_callback(lambda _: exited.set())

    started_at = time.perf_counter()

    await started.wait()

    try:
        yield _Server(server, task, exited, config, started_at)
    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


# Public Api


async def wait_for_request[T, R](config: Config[T, R]) -> T | Error:
    app = _App(config)
    async with _create_server(app, config) as server:
        app.result.add_done_callback(lambda _: server.task.cancel())
        ready_result = await config.on_ready(server.url)
        app.ready_result_fut.set_result(ready_result)
        await server.exit.wait()
        exit_reason = server.get_exit_reason()

    if not app.result.done():
        return Error(
            f'The uvicorn server exited before receiving a matching request, reason: {exit_reason}'
        )

    return await app.result
