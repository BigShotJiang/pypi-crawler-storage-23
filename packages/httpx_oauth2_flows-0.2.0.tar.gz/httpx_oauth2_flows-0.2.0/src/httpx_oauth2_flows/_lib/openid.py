import dataclasses
import datetime
import typing as t

import httpx
import pydantic

from . import util
from ._types import Url


class Configuration(pydantic.BaseModel):
    issuer: str
    authorization_endpoint: Url | None = None
    token_endpoint: Url | None = None
    introspection_endpoint: Url | None = None
    userinfo_endpoint: Url | None = None
    revocation_endpoint: Url | None = None
    end_session_endpoint: Url | None = None
    device_authorization_endpoint: Url | None = None
    jwks_uri: str | None = None
    grant_types_supported: t.Set[str] | None = None
    code_challenge_methods_supported: t.Set[str] | None = None
    token_endpoint_auth_methods_supported: t.Set[str] | None = None


async def fetch_configuration(
    auth_server: Url, http_client: httpx.AsyncClient, *, check_support_grant_type: str | None = None
) -> Configuration:
    response = await http_client.get(auth_server / '.well-known' / 'openid-configuration')
    configuration = util.get_response_model(response, Configuration)

    if (
        check_support_grant_type is not None
        and configuration.grant_types_supported is not None
        and check_support_grant_type not in configuration.grant_types_supported
    ):
        msg = f'{auth_server} does not support the {check_support_grant_type} grant type'
        raise RuntimeError(msg)

    return configuration


@dataclasses.dataclass(slots=True, frozen=True)
class UserInfo:
    sub: str | None
    email: str | None
    email_verified: bool | None
    family_name: str | None
    given_name: str | None
    locale: str | None
    gender: str | None
    name: str | None
    nickname: str | None
    preferred_username: str | None
    updated_at: datetime.datetime | None
    extra: t.Mapping[str, object]


class _Token(t.Protocol):
    @property
    def token_type(self) -> str: ...
    @property
    def access_token(self) -> str: ...


async def fetch_user_info(
    token: _Token, auth_server: Url, http_client: httpx.AsyncClient
) -> UserInfo:
    configuration = await fetch_configuration(auth_server, http_client)
    if configuration.userinfo_endpoint is None:
        msg = 'Cannot fetch user info because no endpoint is provided in the OpenID configuration.'
        raise RuntimeError(msg)

    response = await http_client.get(
        configuration.userinfo_endpoint,
        headers={'Authorization': f'{token.token_type} {token.access_token}'},
    )

    return util.validate_dataclass_with_extra(UserInfo, util.get_response_json(response))
