import pathlib

RESOURCES_DIR = pathlib.Path(__file__).parent

__all__ = ['RESOURCES_DIR']
