"""Deprecated: This module has been split into focused modules.

- ``plone.pgcatalog.pending``: Thread-local pending store and transaction integration
- ``plone.pgcatalog.pool``: Connection pool discovery and request-scoped connections
- ``plone.pgcatalog.processor``: CatalogStateProcessor for zodb-pgjsonb integration
- ``plone.pgcatalog.startup``: IDatabaseOpenedWithRoot subscriber and index sync
"""
