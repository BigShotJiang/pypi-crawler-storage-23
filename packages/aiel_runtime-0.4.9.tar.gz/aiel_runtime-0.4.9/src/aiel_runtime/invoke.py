from __future__ import annotations

import asyncio
import importlib
import inspect
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from aiel_sdk import get_registry
from .protocol import Context, HttpRequest, McpRequest


class InvokeTimeout(RuntimeError):
    pass


@contextmanager
def _temporary_sys_path(path: str):
    sys.path.insert(0, path)
    try:
        yield
    finally:
        try:
            sys.path.remove(path)
        except ValueError:
            pass


def _ensure_dict(x: Any, what: str) -> Dict[str, Any]:
    if x is None:
        return {}
    if not isinstance(x, dict):
        raise TypeError(f"{what} must be an object (dict). Got: {type(x).__name__}")
    return x


async def _run_with_timeout(coro: asyncio.Future, timeout_ms: int) -> Any:
    try:
        return await asyncio.wait_for(coro, timeout=timeout_ms / 1000.0)
    except asyncio.TimeoutError:
        raise InvokeTimeout(f"Invocation timed out after {timeout_ms}ms")


async def _call_fn(ctx: Context, fn, arg: Dict[str, Any], *, timeout_ms: int) -> Any:
    """
    Calls sync functions in a thread so timeouts can interrupt waiting.
    """
    if inspect.iscoroutinefunction(fn):
        return await _run_with_timeout(fn(ctx, arg), timeout_ms)

    async def _thread_call():
        return await asyncio.to_thread(fn, ctx, arg)

    return await _run_with_timeout(_thread_call(), timeout_ms)


async def _call_fn_aws(ctx: Context, fn, event: Dict[str, Any], *, timeout_ms: int) -> Any:
    """
    Lambda-style handler signature: fn(event, context)
    """
    if inspect.iscoroutinefunction(fn):
        return await _run_with_timeout(fn(event, ctx), timeout_ms)

    async def _thread_call():
        return await asyncio.to_thread(fn, event, ctx)

    return await _run_with_timeout(_thread_call(), timeout_ms)


def _find_http_handler(method: str, path: str):
    reg = get_registry()
    for h in reg.http_handlers:
        if h.method.upper() == method.upper() and h.path == path:
            return h
    return None


async def _invoke_tool(ctx: Context, handler: str, event: dict, timeout_ms: int) -> Any:
    reg = get_registry()
    exp = reg.tools.get(handler)
    if not exp:
        raise KeyError(f"Tool not found: {handler}")
    return await _call_fn(ctx, exp.fn, event, timeout_ms=timeout_ms)


async def _invoke_agent(ctx: Context, handler: str, event: dict, timeout_ms: int) -> dict:
    reg = get_registry()
    exp = reg.agents.get(handler)
    if not exp:
        raise KeyError(f"Agent not found: {handler}")
    out = await _call_fn(ctx, exp.fn, event, timeout_ms=timeout_ms)
    if not isinstance(out, dict):
        raise TypeError("Agent must return a dict state.")
    return out


async def _invoke_flow(ctx: Context, handler: str, event: dict, timeout_ms: int) -> dict:
    reg = get_registry()
    exp = reg.flows.get(handler)
    if not exp:
        raise KeyError(f"Flow not found: {handler}")
    out = await _call_fn(ctx, exp.fn, event, timeout_ms=timeout_ms)
    if not isinstance(out, dict):
        raise TypeError("Flow must return a dict state.")
    return out


async def _invoke_http(ctx: Context, http: HttpRequest, timeout_ms: int) -> Any:
    """
    We route by (method, path) and call the registered function.

    Contract:
      http handler functions should be (ctx, body_or_req_dict) -> dict
      - For GET: pass a request dict with query/headers/path/method
      - For POST/etc: pass body dict, but still include request metadata via ctx.log if needed
    """
    h = _find_http_handler(http.method, http.path)
    if not h:
        raise KeyError(f"HTTP handler not found for {http.method} {http.path}")

    # Build a JSON-safe request dict
    req_dict = {
        "method": http.method,
        "path": http.path,
        "query": dict(http.query),
        "headers": dict(http.headers),
        "body": dict(http.body),
    }

    # If your SDK registers http handlers with fn expecting (ctx, body)
    # you can pass body for non-GET and full req for GET.
    arg = req_dict if http.method.upper() == "GET" else req_dict["body"]

    return await _call_fn(ctx, h.fn, _ensure_dict(arg, "http arg"), timeout_ms=timeout_ms)


async def _invoke_mcp(ctx: Context, mcp: McpRequest, timeout_ms: int) -> Any:
    """
    MCP invoke: validate server exists and tool is allowed, then execute the tool.
    """
    reg = get_registry()
    server = reg.mcp_servers.get(mcp.server)
    if not server:
        raise KeyError(f"MCP server not found: {mcp.server}")

    if mcp.tool not in server.tools:
        raise PermissionError(f"Tool '{mcp.tool}' not allowed by MCP server '{mcp.server}'")

    # Tool execution is the same as regular tool invoke
    return await _invoke_tool(ctx, mcp.tool, _ensure_dict(mcp.args, "mcp.args"), timeout_ms)


async def invoke(
    *,
    kind: str,
    handler: Optional[str],
    event: Optional[dict],
    http: Optional[HttpRequest],
    mcp: Optional[McpRequest],
    ctx: Context,
    timeout_ms: int,
) -> Any:
    event_dict = _ensure_dict(event, "event")

    if kind == "tool":
        return await _invoke_tool(ctx, handler or "", event_dict, timeout_ms)

    if kind == "agent":
        return await _invoke_agent(ctx, handler or "", event_dict, timeout_ms)

    if kind == "flow":
        return await _invoke_flow(ctx, handler or "", event_dict, timeout_ms)

    if kind == "http":
        if http is None:
            raise ValueError("http kind requires http object")
        return await _invoke_http(ctx, http, timeout_ms)

    if kind == "mcp":
        if mcp is None:
            raise ValueError("mcp kind requires mcp object")
        return await _invoke_mcp(ctx, mcp, timeout_ms)

    raise KeyError(f"Unsupported kind: {kind}")


def _resolve_handler(handler: str, *, default_module: str = "entry_point") -> tuple[str, str]:
    if not handler:
        raise ValueError("handler must be in the form 'module.function'")
    if "." not in handler:
        return default_module, handler
    module_name, func_name = handler.rsplit(".", 1)
    if not module_name or not func_name:
        raise ValueError("handler must be in the form 'module.function'")
    return module_name, func_name


async def execute_handler(
    *,
    files_root: Path,
    handler: str,
    event: Optional[dict],
    ctx: Context,
    timeout_ms: int,
) -> Any:
    """
    Execute a Lambda-style handler (module.function) with (event, context).
    """
    event_dict = _ensure_dict(event, "event")
    module_name, func_name = _resolve_handler(handler, default_module="entry_point")
    with _temporary_sys_path(str(files_root.resolve())):
        mod = importlib.import_module(module_name)
    fn = getattr(mod, func_name, None)
    if not callable(fn):
        raise KeyError(f"Handler not found: {handler}")
    return await _call_fn_aws(ctx, fn, event_dict, timeout_ms=timeout_ms)
