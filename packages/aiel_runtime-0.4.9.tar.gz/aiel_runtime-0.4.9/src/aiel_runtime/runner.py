from __future__ import annotations

import argparse
import asyncio
import json
import os
import time
import traceback
import importlib.util
from pathlib import Path
from typing import Any, Optional

from aiel_sdk import SDK_VERSION

from ._version import RUNTIME_VERSION
from .describe import describe as describe_fn
from .invoke import invoke as invoke_fn, InvokeTimeout, execute_handler
from .loader import load_snapshot, compute_snapshot_id, SnapshotInfo
from .protocol import RunnerRequest, RunnerResponse, ErrorInfo, ResponseMeta, Context, InvokeMeta
from .security import ImportPolicy, enforce_import_policy
from .utils.context_discovery import _load_local_ctx_or_raise, _merge_ctx


ERROR_VALIDATION = "VALIDATION_ERROR"
ERROR_NOT_FOUND = "NOT_FOUND"
ERROR_USER_CODE = "USER_CODE_ERROR"
ERROR_TIMEOUT = "TIMEOUT"
ERROR_INTERNAL = "INTERNAL"
ERROR_SECURITY = "SECURITY_VIOLATION"

_SNAPSHOT_CACHE: dict[str, Any] = {}
_EXEC_COLD_START = True


def _read_stdin_json() -> str:
    import sys
    data = sys.stdin.read()
    if not data.strip():
        raise ValueError("Empty input. Expected JSON on stdin.")
    return data


def _read_stdin_json_optional() -> Optional[str]:
    import sys
    if sys.stdin.isatty():
        return None
    data = sys.stdin.read()
    if not data.strip():
        return None
    return data


def _mk_policy(meta: Optional[InvokeMeta]) -> ImportPolicy:
    caps = (meta.capabilities if meta else None)
    return ImportPolicy(
        allow_network=bool(caps.network) if caps else False,
        allow_subprocess=bool(caps.subprocess) if caps else False,
        allow_ctypes=bool(caps.ctypes) if caps else False,
        allow_signal=bool(caps.signal) if caps else False,
        allow_resource=bool(caps.resource) if caps else False,
    )


def _error_response(
    *,
    request_id: str,
    trace_id: Optional[str],
    start_ms: int,
    cold_start: bool,
    snapshot_id: Optional[str],
    code: str,
    message: str,
    legacy_code: Optional[str] = None,
    details: Optional[dict] = None,
    logs: Optional[list] = None,
) -> RunnerResponse:
    duration = int(time.time() * 1000) - start_ms
    if legacy_code:
        details = dict(details or {})
        details["legacy_code"] = legacy_code
    return RunnerResponse(
        ok=False,
        result=None,
        error=ErrorInfo(code=code, message=message, details=details),
        meta=ResponseMeta(
            request_id=request_id,
            trace_id=trace_id,
            duration_ms=duration,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            sdk_version=SDK_VERSION,
            runtime_version=RUNTIME_VERSION,
            logs=logs or [],
        ),
    )


def _extract_user_location(
    tb: Optional[object],
    *,
    files_root: Optional[Path],
) -> Optional[dict]:
    if tb is None:
        return None

    try:
        frames = traceback.extract_tb(tb)  # type: ignore[arg-type]
    except Exception:
        return None

    if not frames:
        return None

    root = None
    if files_root is not None:
        try:
            root = str(files_root.resolve())
        except Exception:
            root = None

    def _frame_to_loc(frame: traceback.FrameSummary) -> dict:
        loc = {
            "file": frame.filename,
            "line": frame.lineno,
            "function": frame.name,
        }
        if frame.line:
            loc["code"] = frame.line
        if root:
            try:
                loc["relpath"] = str(Path(frame.filename).resolve().relative_to(root))
            except Exception:
                pass
        return loc

    if root:
        root_prefix = root + os.sep
        for frame in reversed(frames):
            try:
                f_abs = str(Path(frame.filename).resolve())
            except Exception:
                f_abs = frame.filename
            if f_abs.startswith(root_prefix) or f_abs == root:
                return _frame_to_loc(frame)

    return _frame_to_loc(frames[-1])


def _error_details(
    e: Exception,
    *,
    files_root: Optional[Path],
    include_traceback: bool,
) -> Optional[dict]:
    details: dict[str, Any] = {"exception_type": e.__class__.__name__}
    location = _extract_user_location(getattr(e, "__traceback__", None), files_root=files_root)
    if location:
        details["location"] = location
    if include_traceback:
        details["traceback"] = traceback.format_exc()
    return details or None


def _ok_response(
    *,
    request_id: str,
    trace_id: Optional[str],
    start_ms: int,
    cold_start: bool,
    snapshot_id: Optional[str],
    result: Any,
    logs: list,
) -> RunnerResponse:
    duration = int(time.time() * 1000) - start_ms
    return RunnerResponse(
        ok=True,
        result=result,
        error=None,
        meta=ResponseMeta(
            request_id=request_id,
            trace_id=trace_id,
            duration_ms=duration,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            sdk_version=SDK_VERSION,
            runtime_version=RUNTIME_VERSION,
            logs=logs,
        ),
    )


def _now_ms() -> int:
    return int(time.time() * 1000)


def _dump_response(resp: RunnerResponse, *, pretty: bool = False) -> str:
    t0 = time.time()
    if pretty:
        payload = json.dumps(resp.model_dump(), indent=2, ensure_ascii=False)
    else:
        payload = resp.model_dump_json()
    serialize_ms = int((time.time() - t0) * 1000)
    if resp.meta is not None:
        resp.meta.serialize_ms = serialize_ms
        if pretty:
            payload = json.dumps(resp.model_dump(), indent=2, ensure_ascii=False)
        else:
            payload = resp.model_dump_json()
    return payload


def _load_snapshot_cached(
    *,
    files_root: Path,
    policy: ImportPolicy,
    keep_warm: bool,
) -> SnapshotInfo:
    resolved = files_root.resolve()
    t_hash_start = time.time()
    snapshot_id = compute_snapshot_id(resolved)
    hash_ms = int((time.time() - t_hash_start) * 1000)

    cached = _SNAPSHOT_CACHE.get("snapshot")
    if cached and _SNAPSHOT_CACHE.get("snapshot_id") == snapshot_id and _SNAPSHOT_CACHE.get("files_root") == str(resolved):
        return SnapshotInfo(
            snapshot_id=snapshot_id,
            cold_start=False,
            module_name=cached.module_name,
            hash_ms=hash_ms,
            import_ms=0,
            validate_ms=0,
            cleanup_ms=0,
            total_ms=hash_ms,
        )

    snap = load_snapshot(resolved, policy=policy, keep_warm=keep_warm)
    _SNAPSHOT_CACHE["snapshot"] = snap
    _SNAPSHOT_CACHE["snapshot_id"] = snap.snapshot_id
    _SNAPSHOT_CACHE["files_root"] = str(resolved)
    return snap


def _prepare_snapshot_execute(*, files_root: Path, policy: ImportPolicy) -> SnapshotInfo:
    """
    Lightweight snapshot prep for execute: enforce import policy + compute snapshot id.
    Avoids importing entry_point twice (once for registry, once for handler).
    """
    global _EXEC_COLD_START

    resolved = files_root.resolve()
    t_hash_start = time.time()
    snapshot_id = compute_snapshot_id(resolved)
    hash_ms = int((time.time() - t_hash_start) * 1000)

    enforce_import_policy(resolved, policy)

    cold_start = _EXEC_COLD_START
    _EXEC_COLD_START = False

    return SnapshotInfo(
        snapshot_id=snapshot_id,
        cold_start=cold_start,
        module_name="entry_point",
        hash_ms=hash_ms,
        import_ms=0,
        validate_ms=0,
        cleanup_ms=0,
        total_ms=hash_ms,
    )


def _entrypoint_uses_aiel(files_root: Path) -> bool:
    entry = files_root / "entry_point.py"
    try:
        src = entry.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return False
    return ("from aiel " in src) or ("from aiel." in src) or ("import aiel" in src)


def _ensure_aiel_available(files_root: Path) -> Optional[str]:
    if not _entrypoint_uses_aiel(files_root):
        return None
    try:
        spec = importlib.util.find_spec("aiel")
    except Exception as e:
        return f"Failed to resolve 'aiel' module: {e}"
    if spec is None:
        return "Missing dependency: aiel (install aiel-cli in the runtime environment)"
    return None


async def main_async() -> int:
    ap = argparse.ArgumentParser(
        prog="aiel_runtime.runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  echo '{\"action\":\"describe\"}' | python -m aiel_runtime.runner --files-root \"$PWD\"\n"
            "  echo '{\"action\":\"invoke\",\"kind\":\"tool\",\"handler\":\"my_tool\",\"event\":{}}' | "
            "python -m aiel_runtime.runner --files-root \"$PWD\" --no-traceback\n"
            "  python -m aiel_runtime.runner --action invoke --kind tool --name my_tool "
            "--payload '{\"foo\":\"bar\"}'\n"
        ),
    )
    ap.add_argument("--files-root", required=False, help="Path to user snapshot root (contains entry_point.py)")
    ap.add_argument("--no-traceback", action="store_true", help="Do not include traceback in errors")
    ap.add_argument("--debug", action="store_true", help="Include sanitized tracebacks in errors")
    ap.add_argument("--keep-warm", action="store_true", help="Keep snapshot loaded (less safe; not recommended)")
    ap.add_argument("--schema-version", default="v1", help="Request schema version (default: v1)")
    ap.add_argument("--pretty", action="store_true", help="Pretty-print JSON output")
    ap.add_argument("--auto-ctx", action="store_true", help="Enable local context discovery (CLI-only)")
    ap.add_argument("--action", choices=["describe", "invoke", "execute"], help="Action to perform")
    ap.add_argument("--kind", choices=["tool", "agent", "flow", "http", "mcp"], help="Invoke kind")
    ap.add_argument("--name", help="Legacy handler name (alias of --handler)")
    ap.add_argument("--handler", help="Handler name (module.function)")
    ap.add_argument("--payload", help="Legacy event payload as JSON object string")
    ap.add_argument("--event", help="Event payload as JSON object string")
    ap.add_argument("--ctx", help="Context as JSON object string (CLI only)")
    ap.add_argument("--timeout-ms", type=int, help="Invocation timeout in ms")
    ap.add_argument("--request-id", help="Request id override")
    ap.add_argument("--trace-id", help="Trace id override")
    args = ap.parse_args()

    pretty_json = bool(args.pretty)
    env_pretty = os.getenv("AIEL_PRETTY_JSON")
    if env_pretty is not None:
        val = env_pretty.strip().lower()
        if val in {"1", "true", "yes", "on"}:
            pretty_json = True
        elif val in {"0", "false", "no", "off"}:
            pretty_json = False

    start_ms = _now_ms()
    include_traceback = bool(args.debug) and not bool(args.no_traceback)

    files_root = Path(args.files_root) if args.files_root else Path.cwd()
    entry_point = files_root / "entry_point.py"
    if not entry_point.exists():
        resp = _error_response(
            request_id="unknown",
            trace_id=None,
            start_ms=start_ms,
            cold_start=True,
            snapshot_id=None,
            code=ERROR_NOT_FOUND,
            message=f"entry_point.py not found at: {entry_point}",
            legacy_code="ENTRYPOINT_NOT_FOUND",
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 3

    stdin_json = _read_stdin_json_optional()
    if stdin_json is None:
        if not args.action:
            resp = _error_response(
                request_id="unknown",
                trace_id=None,
                start_ms=start_ms,
                cold_start=True,
                snapshot_id=None,
                code=ERROR_VALIDATION,
                message="Empty input. Provide JSON on stdin or use --action/--kind/--payload.",
                legacy_code="BAD_REQUEST",
            )
            print(_dump_response(resp, pretty=pretty_json))
            return 2

        event_payload: Optional[dict] = None
        payload_raw = args.event or args.payload
        if payload_raw:
            try:
                parsed = json.loads(payload_raw)
            except Exception as e:
                resp = _error_response(
                    request_id="unknown",
                    trace_id=None,
                    start_ms=start_ms,
                    cold_start=True,
                    snapshot_id=None,
                    code=ERROR_VALIDATION,
                    message=f"Invalid JSON in payload/event: {e}",
                    legacy_code="BAD_REQUEST",
                )
                print(_dump_response(resp, pretty=pretty_json))
                return 2
            if not isinstance(parsed, dict):
                resp = _error_response(
                    request_id="unknown",
                    trace_id=None,
                    start_ms=start_ms,
                    cold_start=True,
                    snapshot_id=None,
                    code=ERROR_VALIDATION,
                    message="payload/event must be a JSON object",
                    legacy_code="BAD_REQUEST",
                )
                print(_dump_response(resp, pretty=pretty_json))
                return 2
            event_payload = parsed

        ctx_payload: Optional[dict] = None
        if args.ctx:
            try:
                parsed_ctx = json.loads(args.ctx)
            except Exception as e:
                resp = _error_response(
                    request_id="unknown",
                    trace_id=None,
                    start_ms=start_ms,
                    cold_start=True,
                    snapshot_id=None,
                    code=ERROR_VALIDATION,
                    message=f"Invalid JSON in ctx: {e}",
                    legacy_code="BAD_REQUEST",
                )
                print(_dump_response(resp, pretty=pretty_json))
                return 2
            if not isinstance(parsed_ctx, dict):
                resp = _error_response(
                    request_id="unknown",
                    trace_id=None,
                    start_ms=start_ms,
                    cold_start=True,
                    snapshot_id=None,
                    code=ERROR_VALIDATION,
                    message="ctx must be a JSON object",
                    legacy_code="BAD_REQUEST",
                )
                print(_dump_response(resp, pretty=pretty_json))
                return 2
            ctx_payload = parsed_ctx

        req_dict: dict[str, Any] = {
            "schema_version": args.schema_version,
            "action": args.action,
        }
        if ctx_payload is not None:
            req_dict["ctx"] = ctx_payload
        if args.action == "invoke":
            req_dict["kind"] = args.kind
            if args.handler or args.name:
                req_dict["handler"] = args.handler or args.name
                req_dict["name"] = args.name
            if event_payload is not None:
                req_dict["event"] = event_payload
                req_dict["payload"] = event_payload
            if args.timeout_ms or args.request_id or args.trace_id:
                req_dict["meta"] = {
                    k: v
                    for k, v in {
                        "timeout_ms": args.timeout_ms,
                        "request_id": args.request_id,
                        "trace_id": args.trace_id,
                    }.items()
                    if v is not None
                }
        
        if args.action == "execute":
            if args.handler or args.name:
                req_dict["handler"] = args.handler or args.name
                req_dict["name"] = args.name
            else:
                req_dict["handler"] = "entry_point.aiel_handler"
            
            if event_payload is not None:
                req_dict["event"] = event_payload
                req_dict["payload"] = event_payload
            
            if args.timeout_ms or args.request_id or args.trace_id:
                req_dict["meta"] = {
                    k: v
                    for k, v in {
                        "timeout_ms": args.timeout_ms,
                        "request_id": args.request_id,
                        "trace_id": args.trace_id,
                    }.items()
                    if v is not None
                }
        stdin_json = json.dumps(req_dict)

    # Parse request
    try:
        req = RunnerRequest.model_validate_json(stdin_json if stdin_json is not None else _read_stdin_json())
    except Exception as e:
        resp = _error_response(
            request_id="unknown",
            trace_id=None,
            start_ms=start_ms,
            cold_start=True,
            snapshot_id=None,
            code=ERROR_VALIDATION,
            message=str(e),
            legacy_code="BAD_REQUEST",
            details=_error_details(e, files_root=None, include_traceback=include_traceback),
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 2

    meta = req.meta or InvokeMeta()
    request_id = meta.request_id
    trace_id = meta.trace_id

    # Load snapshot first (describe/invoke depend on registry). Execute uses lighter prep.
    snapshot_id = None
    cold_start = True
    snap: Optional[SnapshotInfo] = None
    try:
        dep_err = _ensure_aiel_available(files_root)
        if dep_err:
            resp = _error_response(
                request_id=request_id,
                trace_id=trace_id,
                start_ms=start_ms,
                cold_start=cold_start,
                snapshot_id=snapshot_id,
                code=ERROR_VALIDATION,
                message=dep_err,
                legacy_code="MISSING_DEPENDENCY",
            )
            print(_dump_response(resp, pretty=pretty_json))
            return 3
        policy = _mk_policy(meta)
        if req.action == "execute":
            snap = _prepare_snapshot_execute(files_root=files_root, policy=policy)
        else:
            snap = _load_snapshot_cached(files_root=files_root, policy=policy, keep_warm=args.keep_warm)
        snapshot_id = snap.snapshot_id
        cold_start = snap.cold_start
    except PermissionError as e:
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code=ERROR_SECURITY,
            message=str(e),
            legacy_code="SECURITY_VIOLATION",
            details=_error_details(e, files_root=files_root, include_traceback=include_traceback),
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 3
    except FileNotFoundError as e:
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code=ERROR_NOT_FOUND,
            message=str(e),
            legacy_code="ENTRYPOINT_NOT_FOUND",
            details=_error_details(e, files_root=files_root, include_traceback=include_traceback),
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 3
    except Exception as e:
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code=ERROR_INTERNAL,
            message=str(e),
            legacy_code="SNAPSHOT_LOAD_ERROR",
            details=_error_details(e, files_root=files_root, include_traceback=include_traceback),
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 3

    # Build context + deadline
    now_ms = _now_ms()
    deadline_ms = now_ms + meta.timeout_ms if meta.timeout_ms else None
    # ctx = Context.from_dict(req.ctx)
    provided_ctx = req.ctx if isinstance(req.ctx, dict) else None

    env_auto_ctx = os.getenv("AIEL_AUTO_CTX")
    auto_ctx_enabled = bool(args.auto_ctx)
    if env_auto_ctx is not None:
        val = env_auto_ctx.strip().lower()
        if val in {"1", "true", "yes", "on"}:
            auto_ctx_enabled = True
        elif val in {"0", "false", "no", "off"}:
            auto_ctx_enabled = False

    if auto_ctx_enabled:
        auto_ctx: dict[str, Any] = {}
        if provided_ctx:
            try:
                auto_ctx = _load_local_ctx_or_raise()
            except ValueError:
                auto_ctx = {}
        else:
            auto_ctx = _load_local_ctx_or_raise()
        merged_ctx = _merge_ctx(auto_ctx, provided_ctx)
    else:
        merged_ctx = provided_ctx or {}

    ctx = Context.from_dict(merged_ctx)
    ctx.request_id = request_id
    ctx.trace_id = trace_id
    ctx.deadline_ms = deadline_ms
    ctx.snapshot_id = snapshot_id
    ctx.runtime_version = RUNTIME_VERSION
    ctx.sdk_version = SDK_VERSION
    ctx.log(
        "runner.start",
        action=req.action,
        snapshot_id=snapshot_id,
        cold_start=cold_start,
    )
    if snap:
        ctx.log(
            "runner.init",
            hash_ms=snap.hash_ms,
            import_ms=snap.import_ms,
            validate_ms=snap.validate_ms,
            registry_ms=snap.validate_ms,
            cleanup_ms=snap.cleanup_ms,
            total_ms=snap.total_ms,
        )

    try:
        if req.action == "describe":
            t_describe_start = time.time()
            out = describe_fn(snapshot_id=snapshot_id)
            describe_ms = int((time.time() - t_describe_start) * 1000)
            ctx.log("runner.describe.ok")
            resp = _ok_response(
                request_id=request_id,
                trace_id=trace_id,
                start_ms=start_ms,
                cold_start=cold_start,
                snapshot_id=snapshot_id,
                result=out,
                logs=ctx.logs,  # ✅ fixed
            )
            ctx.log("runner.describe.timing", duration_ms=describe_ms)
            print(_dump_response(resp, pretty=pretty_json))
            return 0

        if req.action == "invoke":
            # For invoke, requirements depend on kind
            if not req.kind:
                raise ValueError("invoke requires 'kind'")

            ctx.log(
                "runner.invoke",
                resource_kind=req.kind,
                resource_name=req.handler,
                kind=req.kind,
                handler=req.handler,
            )

            t_invoke_start = time.time()
            result = await invoke_fn(
                kind=req.kind,
                handler=req.handler,
                event=req.event,
                http=req.http,
                mcp=req.mcp,
                ctx=ctx,
                timeout_ms=meta.timeout_ms,
            )
            invoke_ms = int((time.time() - t_invoke_start) * 1000)

            ctx.log("runner.invoke.ok", duration_ms=invoke_ms, resource_kind=req.kind, resource_name=req.handler)
            resp = _ok_response(
                request_id=request_id,
                trace_id=trace_id,
                start_ms=start_ms,
                cold_start=cold_start,
                snapshot_id=snapshot_id,
                result=result,
                logs=ctx.logs,  # ✅ fixed
            )
            print(_dump_response(resp, pretty=pretty_json))
            return 0

        if req.action == "execute":
            if not req.handler:
                raise ValueError("execute requires handler")

            ctx.log(
                "runner.execute",
                resource_kind="handler",
                resource_name=req.handler,
                handler=req.handler,
            )
            t_exec_start = time.time()
            result = await execute_handler(
                files_root=files_root,
                handler=req.handler,
                event=req.event,
                ctx=ctx,
                timeout_ms=meta.timeout_ms,
            )
            exec_ms = int((time.time() - t_exec_start) * 1000)
            ctx.log(
                "runner.execute.ok",
                duration_ms=exec_ms,
                resource_kind="handler",
                resource_name=req.handler,
            )
            resp = _ok_response(
                request_id=request_id,
                trace_id=trace_id,
                start_ms=start_ms,
                cold_start=cold_start,
                snapshot_id=snapshot_id,
                result=result,
                logs=ctx.logs,
            )
            print(_dump_response(resp, pretty=pretty_json))
            return 0

        raise ValueError(f"Invalid action: {req.action}")

    except InvokeTimeout as e:
        ctx.log(
            "runner.invoke.timeout",
            message=str(e),
            level="WARN",
            resource_kind=req.kind,
            resource_name=req.handler,
        )
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code=ERROR_TIMEOUT,
            message=str(e),
            details=_error_details(e, files_root=files_root, include_traceback=include_traceback),
            logs=ctx.logs,  # ✅ fixed
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 4

    except KeyError as e:
        msg = str(e).strip("'")
        ctx.log(
            "runner.invoke.not_found",
            message=msg,
            level="WARN",
            resource_kind=req.kind,
            resource_name=req.handler,
        )
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code=ERROR_NOT_FOUND,
            message=msg,
            legacy_code="HANDLER_NOT_FOUND",
            details=_error_details(e, files_root=files_root, include_traceback=include_traceback),
            logs=ctx.logs,  # ✅ fixed
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 5

    except (TypeError, ValueError) as e:
        ctx.log(
            "runner.invoke.validation_error",
            message=str(e),
            level="WARN",
            resource_kind=req.kind,
            resource_name=req.handler,
        )
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code=ERROR_VALIDATION,
            message=str(e),
            details=_error_details(e, files_root=files_root, include_traceback=include_traceback),
            logs=ctx.logs,  # ✅ fixed
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 6

    except PermissionError as e:
        ctx.log(
            "runner.invoke.security_violation",
            message=str(e),
            level="ERROR",
            resource_kind=req.kind,
            resource_name=req.handler,
        )
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code=ERROR_SECURITY,
            message=str(e),
            legacy_code="SECURITY_VIOLATION",
            details=_error_details(e, files_root=files_root, include_traceback=include_traceback),
            logs=ctx.logs,
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 7

    except Exception as e:
        ctx.log(
            "runner.invoke.user_code_error",
            message=str(e),
            level="ERROR",
            resource_kind=req.kind,
            resource_name=req.handler,
        )
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code=ERROR_USER_CODE,
            message=str(e),
            details=_error_details(e, files_root=files_root, include_traceback=include_traceback),
            logs=ctx.logs,  # ✅ fixed
        )
        print(_dump_response(resp, pretty=pretty_json))
        return 7


def main() -> None:
    rc = asyncio.run(main_async())
    raise SystemExit(rc)


def cli() -> None:
    main()


if __name__ == "__main__":
    main()
