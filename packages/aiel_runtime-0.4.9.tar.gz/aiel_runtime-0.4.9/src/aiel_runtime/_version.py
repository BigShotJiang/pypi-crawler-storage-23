from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

PACKAGE_NAME = "aiel-runtime"

try:
    RUNTIME_VERSION = version(PACKAGE_NAME)
except PackageNotFoundError:
    # Running from source (not installed) or editable edge case
    RUNTIME_VERSION = "0.0.0+dev"