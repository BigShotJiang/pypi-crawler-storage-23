from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional
from uuid import uuid4
import time

from pydantic import BaseModel, Field, ConfigDict, model_validator


# ---------------------------
# Context (passed to handlers)
# ---------------------------

@dataclass
class Context:
    request_id: str = "req_unknown"
    tenant_id: Optional[str] = None
    workspace_id: Optional[str] = None
    project_id: Optional[str] = None
    user_id: Optional[str] = None
    trace_id: Optional[str] = None
    deadline_ms: Optional[int] = None
    snapshot_id: Optional[str] = None
    runtime_version: Optional[str] = None
    sdk_version: Optional[str] = None

    logs: List[Dict[str, Any]] = field(default_factory=list)

    def log(
        self,
        event: str,
        *,
        level: str = "INFO",
        resource_kind: Optional[str] = None,
        resource_name: Optional[str] = None,
        **fields: Any,
    ) -> None:
        self.logs.append(
            {
                "ts_ms": int(time.time() * 1000),
                "level": level,
                "event": event,
                "request_id": self.request_id,
                "trace_id": self.trace_id,
                "snapshot_id": self.snapshot_id,
                "resource_kind": resource_kind,
                "resource_name": resource_name,
                "fields": fields,
            }
        )

    def time_remaining_ms(self) -> Optional[int]:
        if self.deadline_ms is None:
            return None
        now = int(time.time() * 1000)
        return max(0, self.deadline_ms - now)

    def get_remaining_time_ms(self) -> Optional[int]:
        return self.time_remaining_ms()

    @classmethod
    def from_dict(cls, d: Optional[Dict[str, Any]]) -> "Context":
        if not d:
            return cls()
        return cls(
            request_id=d.get("request_id", "req_unknown"),
            tenant_id=d.get("tenant_id"),
            workspace_id=d.get("workspace_id"),
            project_id=d.get("project_id"),
            user_id=d.get("user_id"),
            trace_id=d.get("trace_id"),
            deadline_ms=d.get("deadline_ms"),
            snapshot_id=d.get("snapshot_id"),
            runtime_version=d.get("runtime_version"),
            sdk_version=d.get("sdk_version"),
        )


# ---------------------------
# Meta / Capabilities
# ---------------------------

class Capabilities(BaseModel):
    """
    These are *authorization flags* for the execution environment.
    Real enforcement is best done outside Python (network egress, etc.).
    """
    model_config = ConfigDict(extra="forbid")

    network: bool = False
    subprocess: bool = False
    ctypes: bool = False
    signal: bool = False
    resource: bool = False

    # Useful for LangSmith
    outbound_https_only: bool = True


class InvokeMeta(BaseModel):
    model_config = ConfigDict(extra="forbid")

    request_id: str = Field(default_factory=lambda: str(uuid4()))
    trace_id: Optional[str] = None
    timeout_ms: int = 30_000
    idempotency_key: Optional[str] = None
    capabilities: Capabilities = Field(default_factory=Capabilities)

    # Optional env injection for LLM SDKs (keep allowlisted in your backend)
    env: Optional[Dict[str, str]] = None

class ResponseMeta(BaseModel):
    model_config = ConfigDict(extra="ignore")
    request_id: str
    trace_id: Optional[str] = None
    duration_ms: int
    cold_start: bool
    snapshot_id: Optional[str] = None
    sdk_version: str
    runtime_version: str
    logs: list[dict] = Field(default_factory=list)
    serialize_ms: Optional[int] = None
# ---------------------------
# HTTP request model
# ---------------------------

class HttpRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    method: Literal["GET", "POST", "PUT", "PATCH", "OPTIONS"]
    path: str
    query: Dict[str, Any] = Field(default_factory=dict)
    headers: Dict[str, str] = Field(default_factory=dict)
    body: Dict[str, Any] = Field(default_factory=dict)


# ---------------------------
# MCP request model
# ---------------------------

class McpRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    server: str
    tool: str
    args: Dict[str, Any] = Field(default_factory=dict)


# ---------------------------
# Runner Request / Response
# ---------------------------

Kind = Literal["tool", "agent", "flow", "http", "mcp"]


class RunnerRequest(BaseModel):
    """
    Backward compatible.

    New fields:
      - handler, event
    Legacy:
      - name, payload
    """
    model_config = ConfigDict(extra="ignore")

    schema_version: Literal["v1"] = "v1"
    action: Literal["describe", "invoke", "execute"]

    kind: Optional[Kind] = None

    # New shape
    handler: Optional[str] = None
    event: Optional[Dict[str, Any]] = None

    # Legacy shape
    name: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None

    # Specialized kinds
    http: Optional[HttpRequest] = None
    mcp: Optional[McpRequest] = None

    meta: Optional[InvokeMeta] = None
    ctx: Optional[Dict[str, Any]] = None

    @model_validator(mode="after")
    def _normalize(self) -> "RunnerRequest":
        # Normalize legacy -> new
        if self.handler is None and self.name is not None:
            self.handler = self.name
        if self.event is None and self.payload is not None:
            self.event = self.payload

        # Normalize empties
        if self.event is None:
            self.event = {}

        if self.action == "invoke":
            if not self.kind:
                raise ValueError("invoke requires kind")

            if self.kind in ("tool", "agent", "flow"):
                if not self.handler:
                    raise ValueError("invoke requires handler (or legacy name)")

            if self.kind == "http":
                if self.http is None:
                    raise ValueError("http invoke requires http object")

            if self.kind == "mcp":
                if self.mcp is None:
                    raise ValueError("mcp invoke requires mcp object")

        if self.action == "execute":
            if not self.handler:
                self.handler = "entry_point.aiel_handler"

        return self


class ErrorInfo(BaseModel):
    model_config = ConfigDict(extra="ignore")
    code: str
    message: str
    details: Optional[Dict[str, Any]] = None


class RunnerResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    schema_version: Literal["v1"] = "v1"
    ok: bool
    result: Any | None = None
    error: Optional[ErrorInfo] = None
    meta: Optional[ResponseMeta] = None
