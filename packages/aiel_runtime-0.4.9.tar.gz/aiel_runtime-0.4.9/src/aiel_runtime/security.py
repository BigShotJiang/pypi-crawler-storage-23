from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Set, Optional
import ast
import os


_IGNORE_DIRS = {
    ".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", "node_modules", "dist", "build", ".idea", ".vscode",
}

_IGNORE_PART_CONTAINS = (
    "site-packages",
    "dist-packages",
)


@dataclass(frozen=True)
class ImportPolicy:
    allow_network: bool = False
    allow_subprocess: bool = False
    allow_ctypes: bool = False
    allow_signal: bool = False
    allow_resource: bool = False

    def denied_roots(self) -> Set[str]:
        denied = set()

        # IMPORTANT: socket/signal are extremely common in dependencies.
        # If you deny them at import-scan time you will get tons of false positives.
        # Enforce "no network" at runtime/platform level instead.
        #
        # if not self.allow_network:
        #     denied.add("socket")

        if not self.allow_subprocess:
            denied.add("subprocess")

        if not self.allow_ctypes:
            denied.add("ctypes")

        # signal/resource are also commonly imported by frameworks.
        # Prefer runtime/platform enforcement; keep as optional if you want.
        # if not self.allow_signal:
        #     denied.add("signal")
        # if not self.allow_resource:
        #     denied.add("resource")

        return denied


def _is_ignored(path: Path, root: Path) -> bool:
    try:
        rel_parts = path.relative_to(root).parts
    except Exception:
        return True

    for part in rel_parts:
        if part in _IGNORE_DIRS:
            return True
        if part.startswith(".") and part not in (".",):
            return True
        for needle in _IGNORE_PART_CONTAINS:
            if needle in part:
                return True
        if part.endswith(".egg-info"):
            return True

    # Also ignore anything with site-packages/dist-packages anywhere in the full path
    full = str(path)
    if "site-packages" in full or "dist-packages" in full:
        return True

    return False


def scan_import_roots_with_sources(files_root: Path) -> Dict[str, Set[str]]:
    """
    Returns: { import_root: {file1, file2, ...} }
    Only scans snapshot code (excludes venv, site-packages, hidden dirs, etc.).
    """
    files_root = files_root.resolve()
    found: Dict[str, Set[str]] = {}

    for p in files_root.rglob("*.py"):
        if not p.is_file():
            continue
        if _is_ignored(p, files_root):
            continue

        src = p.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(src, filename=str(p))

        def add(root_name: str):
            if not root_name:
                return
            found.setdefault(root_name, set()).add(str(p))

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    add((alias.name or "").split(".")[0].strip())
            elif isinstance(node, ast.ImportFrom):
                if getattr(node, "level", 0) and getattr(node, "level", 0) > 0:
                    continue
                if node.module:
                    add(node.module.split(".")[0].strip())

    return found


def enforce_import_policy(files_root: Path, policy: ImportPolicy) -> None:
    imports = scan_import_roots_with_sources(files_root)
    denied = policy.denied_roots()

    offenders = {k: sorted(list(v)) for k, v in imports.items() if k in denied}
    if offenders:
        # Put the actual files in the error so you can immediately fix
        raise PermissionError(
            "Disallowed imports detected: "
            + ", ".join(sorted(offenders.keys()))
            + f" | sources={offenders}"
        )
