# Runner Contract (v1)

This document defines the public contract for the `aiel_runtime.runner` CLI and execution model.

## Lifecycle
1. Init phase: load and validate the snapshot (`entry_point.py` + registry).
2. Invoke phase: execute `describe` or `invoke`.
3. Serialize phase: emit a JSON response envelope.

The runtime may reuse the execution environment across multiple invocations within the same process.

## Request Envelope (v1)
```json
{
  "schema_version": "v1",
  "action": "describe" | "invoke" | "execute",
  "kind": "tool" | "agent" | "flow" | "http" | "mcp",
  "handler": "module.function",
  "event": {},
  "name": "legacy-handler-name",
  "payload": {},
  "http": { "method": "GET", "path": "/health", "query": {}, "headers": {}, "body": {} },
  "mcp": { "server": "my_server", "tool": "tool_name", "args": {} },
  "meta": {
    "request_id": "uuid",
    "trace_id": "optional",
    "timeout_ms": 30000,
    "capabilities": {
      "network": false,
      "subprocess": false,
      "ctypes": false,
      "signal": false,
      "resource": false
    }
  }
}
```

Legacy compatibility:
- `name` is normalized to `handler`
- `payload` is normalized to `event`

## Response Envelope (v1)
```json
{
  "schema_version": "v1",
  "ok": true,
  "result": {},
  "error": null,
  "meta": {
    "request_id": "uuid",
    "trace_id": "optional",
    "duration_ms": 12,
    "cold_start": true,
    "snapshot_id": "sha256",
    "sdk_version": "x.y.z",
    "runtime_version": "x.y.z",
    "serialize_ms": 1,
    "logs": []
  }
}
```

## Context (handler input)
Handlers receive `ctx` and `event`:
- `ctx.request_id`
- `ctx.trace_id`
- `ctx.snapshot_id`
- `ctx.runtime_version`
- `ctx.sdk_version`
- `ctx.deadline_ms`
- `ctx.get_remaining_time_ms()`
 - `ctx.workspace_id`, `ctx.project_id`, `ctx.user_id` (if provided by the platform)

## Error Taxonomy
All errors map to a stable code:
- `VALIDATION_ERROR`
- `NOT_FOUND`
- `USER_CODE_ERROR`
- `TIMEOUT`
- `INTERNAL`
- `SECURITY_VIOLATION`

Legacy codes are preserved in `error.details.legacy_code` when applicable.

## Structured Logs
Each log entry is a JSON object with the following fields:
- `ts_ms`
- `level`
- `event`
- `request_id`
- `trace_id`
- `snapshot_id`
- `resource_kind`
- `resource_name`
- `fields` (additional data)

## CLI Examples
```bash
echo '{"action":"describe"}' | python -m aiel_runtime.runner --files-root "$PWD"
echo '{"action":"invoke","kind":"tool","handler":"my_tool","event":{}}' | python -m aiel_runtime.runner --files-root "$PWD" --no-traceback
echo '{"action":"execute","handler":"app.aiel_handler","event":{}}' | python -m aiel_runtime.runner --files-root "$PWD"
python -m aiel_runtime.runner --files-root "$PWD" --action invoke --kind tool --handler my_tool --ctx '{"workspace_id":"w_123","user_id":"u_123"}'
python -m aiel_runtime.runner --files-root "$PWD" --action invoke --kind tool --handler my_tool --auto-ctx
python -m aiel_runtime.runner --files-root "$PWD" --action invoke --kind tool --handler my_tool --pretty
```

## Execute (Lambda-style)
`execute` runs a module handler using the AWS Lambda signature:
```python
def aiel_handler(event, context):
    ...
```
The runtime passes `(event, context)` where `context` is the same `Context` object used by tools/agents/flows.
If no handler is provided, the default is `entry_point.aiel_handler`.

## Invocation Context Injection
The control plane (e.g., CLI) should inject identity and workspace metadata into `ctx`.
Local credential discovery is disabled by default; enable it with `--auto-ctx` or `AIEL_AUTO_CTX=1`.
Pretty JSON output is optional; enable it with `--pretty` or `AIEL_PRETTY_JSON=1`.
Example request:
```json
{
  "schema_version": "v1",
  "action": "execute",
  "handler": "entry_point.aiel_handler",
  "event": {},
  "ctx": {
    "workspace_id": "w_123",
    "project_id": "p_123",
    "user_id": "u_123",
    "trace_id": "trace_123"
  }
}
```
