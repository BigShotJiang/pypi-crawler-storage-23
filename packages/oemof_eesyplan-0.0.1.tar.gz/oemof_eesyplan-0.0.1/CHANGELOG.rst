
Changelog
=========

0.0.0 (2025-08-22)
------------------

* First release on PyPI.
