from math import sqrt

from oemof.eesyplan.investment import _create_invest_if_wanted
from oemof.solph import Flow
from oemof.solph import Investment
from oemof.solph.components import GenericStorage


class HydrogenStorage(GenericStorage):
    def __init__(
        self,
        name,
        bus_in_h2,
        age_installed,
        installed_capacity,
        capex_var,
        opex_fix,
        opex_var,
        lifetime,
        optimize_cap,
        soc_max,
        soc_min,
        crate,  # ToDo: Distinguish input and output and change to c_rate
        efficiency,  # ToDo: Distinguish input and output
        project_data,
        capex_fix=0.0,
        self_discharge=0.0,
        bus_out_h2=None,
        maximum_capacity=float("+inf"),
    ):
        """
        Hydrogen Energy Storage System (H2ESS).

        This class represents a hydrogen energy storage system for storing
        and dispatching hydrogen gas for various applications.

        .. important ::
            This system requires specialized storage technology for
            hydrogen handling and safety.

        :Structure:
          *input*
            1. charge : H2
          *output*
            1. discharge : H2

        Parameters
        ----------
        name : str
           Name of the asset.

        Examples
        --------
        >>> from oemof.eesyplan import Project
        >>> from oemof.eesyplan import CarrierBus
        >>> my_project = Project(
        ...         name="my_project",
        ...         lifetime=20,
        ...         tax=0,
        ...         discount_factor=0.01
        ...     )
        >>> h2_bus = CarrierBus(name="my_h2_bus")
        >>> my_bess = HydrogenStorage(
        ...     name="lithium_battery_system",
        ...     bus_in_h2=h2_bus,
        ...     age_installed=0,
        ...     installed_capacity=0,
        ...     capex_var=3,
        ...     opex_fix=5,
        ...     opex_var=0.,
        ...     lifetime=10,
        ...     optimize_cap=False,
        ...     soc_max=1,
        ...     soc_min=0,
        ...     crate=1,
        ...     efficiency=0.99,
        ...     project_data=my_project,
        ...     self_discharge=0.0001,
        ... )
        """

        nv = _create_invest_if_wanted(
            optimise_cap=optimize_cap,
            capex_var=capex_var,
            opex_fix=opex_fix,
            lifetime=lifetime,
            age_installed=age_installed,
            existing_capacity=installed_capacity,
            maximum_capacity=maximum_capacity,
            project_data=project_data,
        )

        self.self_discharge = self_discharge
        self.efficiency = sqrt(efficiency)

        if optimize_cap:
            self.capacity_charge = Investment()
            self.capacity_discharge = Investment()
            self.crate_charge = crate
            self.crate_discharge = crate
        else:
            self.capacity_charge = nv * crate
            self.capacity_discharge = nv * crate
            self.crate_charge = None
            self.crate_discharge = None

        if bus_out_h2 is None:
            bus_out_h2 = bus_in_h2

        super().__init__(
            label=name,
            nominal_capacity=nv,
            inputs={
                bus_in_h2: Flow(
                    nominal_capacity=self.capacity_charge,
                    variable_costs=opex_var,
                )
            },
            outputs={
                bus_out_h2: Flow(nominal_capacity=self.capacity_discharge)
            },
            loss_rate=self.self_discharge,
            min_storage_level=soc_min,
            max_storage_level=soc_max,
            balanced=True,
            initial_storage_level=None,
            inflow_conversion_factor=self.efficiency,
            outflow_conversion_factor=self.efficiency,
            invest_relation_input_capacity=self.crate_charge,
            invest_relation_output_capacity=self.crate_charge,
        )
