import logging
from pathlib import Path

from simple_dispatch_dp import create_energy_system_from_dp
from simple_dispatch_scripted import create_energy_system_sc

from oemof.eesyplan import export_results
from oemof.eesyplan import import_results
from oemof.network import graph
from oemof.solph import Model
from oemof.solph import Results
from oemof.tools.logger import define_logging


def main(kind, debug=False):
    results = optimise(kind=kind, debug=debug)
    print("'*************** First time **************")
    process_results(results)  # original result object
    results_path = Path(Path.home(), "openplan", "openPlan_results")
    results_path.mkdir(parents=True, exist_ok=True)
    export_results(results, path=results_path)
    if kind == "dp":
        es = create_energy_system_from_dp()
    else:
        es = create_energy_system_sc()
    results = import_results(results_path, es=es)
    print("'*************** Second time **************")
    process_results(results)  # imported result object


def optimise(kind, debug=False):
    solver = "cbc"

    # ################################ optimization ###########################
    energy_system = None
    if kind == "dp":
        energy_system = create_energy_system_from_dp()
    elif kind == "sc":
        energy_system = create_energy_system_sc()
    else:
        ValueError(f"Wrong kind: {kind}")
    # create optimization model based on energy_system
    graph_path = Path(Path.home(), "test_graph.graphml")
    graph.create_nx_graph(energy_system, filename=graph_path)
    logging.info("Create model")
    optimization_model = Model(energysystem=energy_system)

    # solve problem
    logging.info("Solve model")

    if debug:
        skwargs = {"tee": True, "keepfiles": False}
    else:
        skwargs = {}
    optimization_model.solve(solver=solver, solve_kwargs=skwargs)
    return Results(optimization_model)


def process_results(results):
    rdf = results["flow"]

    for n, m in [(0, 1), (1, 0)]:
        rdf.rename(
            columns={
                c[n]: c[n].label[-1]
                for c in rdf.columns
                if isinstance(c[n].label, tuple)
                and not isinstance(c[m].label, tuple)
            },
            level=n,
            inplace=True,
        )
    elec_in = rdf[[c for c in rdf.columns if c[0] == "electricity"]]
    elec_out = rdf[[c for c in rdf.columns if c[1] == "electricity"]]
    print(elec_in.sum())
    print(elec_out.sum())
    print("*****************")
    print("Input:", round(elec_in.sum().sum()))
    print("Output:", round(elec_out.sum().sum()))
    if "invest" in results:
        print("Invest:", results["invest"])

    print("Objective:", results["objective"])


if __name__ == "__main__":
    define_logging(screen_level=logging.WARNING)
    print("**************** Datapackage ******************")
    main("dp")

    print("**************** Scripted ******************")
    main("sc")
