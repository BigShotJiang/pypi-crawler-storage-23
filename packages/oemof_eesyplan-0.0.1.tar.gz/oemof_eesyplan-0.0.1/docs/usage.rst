=====
Usage
=====

To use the project:

.. code-block:: bash

    $ something ...
