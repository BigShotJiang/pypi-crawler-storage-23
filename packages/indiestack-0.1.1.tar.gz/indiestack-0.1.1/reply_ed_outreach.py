"""Reply to Ed — outreach update + what shipped today."""
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

html = """
<div style="font-family:-apple-system,sans-serif;max-width:600px;margin:0 auto;color:#333;">
    <p style="font-size:15px;line-height:1.6;">Hey Ed,</p>

    <p style="font-size:15px;line-height:1.6;">
        39 GitHub issues, emails, Twitter DMs, <em>and</em> Reddit posts — that's an incredible push. Seriously well done.
    </p>

    <p style="font-size:15px;line-height:1.6;">
        Your PR has been merged and deployed. <strong>Public submissions are live</strong> — anyone can submit a tool now.
    </p>

    <h2 style="color:#1A2D4A;font-size:18px;margin-top:28px;margin-bottom:12px;">What shipped today</h2>

    <table style="width:100%;border-collapse:collapse;font-size:14px;">
        <tr>
            <td style="padding:10px 12px;background:#F0F7FA;border-radius:8px;vertical-align:top;width:28px;">
                <span style="color:#00D4F5;font-weight:700;">1.</span>
            </td>
            <td style="padding:10px 12px;">
                <strong>Referral system</strong> — every user has a unique referral code. Share link, friend signs up + gets a tool approved, referrer gets <strong>10 free boost days</strong>. Already emailed all 6 existing users their codes.
            </td>
        </tr>
        <tr>
            <td style="padding:10px 12px;background:#F0F7FA;border-radius:8px;vertical-align:top;">
                <span style="color:#00D4F5;font-weight:700;">2.</span>
            </td>
            <td style="padding:10px 12px;">
                <strong>Outbound click tracking</strong> — every "Visit Website" click on tool pages is tracked. Dashboard shows clicks in the funnel table. This is the metric we pitch to sponsors.
            </td>
        </tr>
        <tr>
            <td style="padding:10px 12px;background:#F0F7FA;border-radius:8px;vertical-align:top;">
                <span style="color:#00D4F5;font-weight:700;">3.</span>
            </td>
            <td style="padding:10px 12px;">
                <strong>Stripe is live</strong> — test keys for now, live keys ready when we activate the account.
            </td>
        </tr>
        <tr>
            <td style="padding:10px 12px;background:#F0F7FA;border-radius:8px;vertical-align:top;">
                <span style="color:#00D4F5;font-weight:700;">4.</span>
            </td>
            <td style="padding:10px 12px;">
                <strong>Upvote active state</strong> — buttons now show when you've already upvoted something.
            </td>
        </tr>
        <tr>
            <td style="padding:10px 12px;background:#F0F7FA;border-radius:8px;vertical-align:top;">
                <span style="color:#00D4F5;font-weight:700;">5.</span>
            </td>
            <td style="padding:10px 12px;">
                <strong>Explore page</strong> — now shows 24 tools per page with proper pagination (was capped at 12).
            </td>
        </tr>
    </table>

    <h2 style="color:#1A2D4A;font-size:18px;margin-top:28px;margin-bottom:12px;">Next steps</h2>

    <p style="font-size:15px;line-height:1.6;">Agreed on all your suggestions:</p>
    <ul style="font-size:14px;line-height:1.8;padding-left:20px;">
        <li>Track claim responses in admin</li>
        <li>Follow-up outreach in 3-4 days for unclaimed tools</li>
        <li>Keep the Reddit posts going (r/SaaS, r/webdev, r/IndieHackers)</li>
        <li>When makers claim, remind them about the referral programme</li>
    </ul>

    <p style="font-size:15px;line-height:1.6;margin-top:24px;">
        Cheers,<br>
        <strong>Patrick</strong>
    </p>

    <div style="margin-top:32px;padding-top:16px;border-top:1px solid #E8E3DC;">
        <p style="font-size:12px;color:#888;">
            <a href="https://indiestack.fly.dev" style="color:#00D4F5;">IndieStack</a> — Discover indie SaaS tools
        </p>
    </div>
</div>
"""

msg = MIMEMultipart('alternative')
msg['Subject'] = 'Re: Outreach update \u2014 all 55 contacted'
msg['From'] = f'IndieStack <{os.environ.get("SMTP_FROM", "noreply@indiestack.fly.dev")}>'
msg['To'] = 'toedgamings@gmail.com'
msg.attach(MIMEText(html, 'html'))

with smtplib.SMTP(os.environ['SMTP_HOST'], 587) as server:
    server.starttls()
    server.login(os.environ['SMTP_USER'], os.environ['SMTP_PASSWORD'])
    server.sendmail(os.environ['SMTP_FROM'], ['toedgamings@gmail.com'], msg.as_string())
    print('Email sent to toedgamings@gmail.com!')
