"""Send referral code announcement emails to all users."""
import asyncio
import sys
sys.path.insert(0, '/app/src' if __import__('os').path.exists('/app/src') else 'src')

from indiestack.email import send_email, _email_wrapper

USERS = [
    ("Ed Mills", "ed.mills@hotmail.co.uk", "REF-b5985e"),
    ("Louis", "louisszabo333@protonmail.com", "REF-67439e"),
    ("Doezer", "doezerx@gmail.com", "REF-8e4395"),
    ("Martin Weiss", "martin@weiss.no", "REF-140890"),
]

def referral_email_html(name: str, code: str) -> str:
    link = f"https://indiestack.fly.dev/signup?ref={code}"
    return f"""
    <div style="text-align:center;margin-bottom:24px;">
        <div style="display:inline-block;background:#1A2D4A;color:#00D4F5;font-size:11px;font-weight:700;
                    text-transform:uppercase;letter-spacing:1.5px;padding:6px 14px;border-radius:999px;">
            New Feature
        </div>
    </div>
    <h2 style="font-family:serif;font-size:22px;color:#1A2D4A;margin-bottom:8px;text-align:center;">
        You've got a referral code
    </h2>
    <p style="color:#6B6560;font-size:15px;text-align:center;margin-bottom:24px;">
        Hey {name} &mdash; thanks for being an early member of IndieStack.
        We just launched a referral programme and you're already in.
    </p>

    <div style="background:#F0F7FA;border-radius:12px;padding:20px;text-align:center;margin-bottom:24px;">
        <p style="font-size:13px;color:#6B6560;margin:0 0 8px;">Your referral link</p>
        <p style="font-family:monospace;font-size:14px;color:#1A2D4A;font-weight:700;margin:0;word-break:break-all;">
            {link}
        </p>
    </div>

    <h3 style="font-family:serif;font-size:17px;color:#1A2D4A;margin-bottom:8px;">How it works</h3>
    <div style="color:#6B6560;font-size:14px;line-height:1.8;">
        <p style="margin:0 0 4px;"><strong>1.</strong> Share your link with indie makers</p>
        <p style="margin:0 0 4px;"><strong>2.</strong> They sign up and submit their tool</p>
        <p style="margin:0 0 4px;"><strong>3.</strong> When their tool gets approved, you earn <strong>10 free boost days</strong></p>
        <p style="margin:0 0 4px;"><strong>4.</strong> Apply boost days to any of your tools from your dashboard</p>
    </div>

    <div style="background:#ECFDF5;border-radius:12px;padding:16px;margin:24px 0;text-align:center;">
        <p style="font-size:14px;color:#065F46;font-weight:600;margin:0;">
            Boost days stack &mdash; the more you refer, the longer your tools stay featured.
        </p>
    </div>

    <div style="text-align:center;margin-top:24px;">
        <a href="https://indiestack.fly.dev/dashboard" style="display:inline-block;background:#00D4F5;color:#1A2D4A;
           padding:14px 32px;border-radius:8px;font-weight:700;font-size:16px;text-decoration:none;">
            View Your Dashboard
        </a>
    </div>
    """

async def main():
    for name, email, code in USERS:
        html = referral_email_html(name, code)
        ok = await send_email(email, f"{name}, you've got a referral code on IndieStack", html)
        status = "SENT" if ok else "FAILED"
        print(f"{status}: {email}")

asyncio.run(main())
