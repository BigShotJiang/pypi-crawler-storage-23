# IndieStack — Competitive Differentiator Brainstorm

## Your Role
You are a ruthlessly honest startup strategist. Your job is to brainstorm genuinely defensible differentiators for IndieStack — features and positioning that competitors (Gumroad, Lemon Squeezy, AppSumo, Product Hunt) cannot easily copy. No fluff. No "just build community." Real moats.

## Context

**What IndieStack is:** A curated marketplace for indie SaaS tools. Built by two CS students (Patrick and Ed) from Cardiff. Python/FastAPI, SQLite, Stripe Connect, deployed on Fly.io. Live at indiestack.fly.dev.

**Current state:**
- ~26 seeded tools (real indie products like Plausible, Carrd, Buttondown, Railway)
- 1 maker account (Patrick), waiting on real makers to list
- Commission: 5% free tier, 3% Pro tier (Stripe takes ~3% on top)
- Features: search by problem, verified indie badges, indie score (0-100), upvotes, wishlists, reviews, maker profiles, tool changelogs, curated collections, email newsletter capture
- Design: clean, navy/cyan, DM Serif Display + DM Sans

**Current positioning:** "Save your tokens — use indie builds." The thesis: in 2026, anyone can vibe-code anything with AI, but every tool you build from scratch is tokens burned, bugs introduced, and maintenance debt. IndieStack is where you buy polished indie tools for the boring bits so you can save your tokens for the magic.

**Target audience:**
- Primary: AI-native developers / vibe-coders who build with Claude, Cursor, Windsurf, Replit, etc.
- Secondary: Indie makers who want distribution beyond their own Twitter following
- Tertiary: Non-technical founders who want to assemble a SaaS stack without building

**Competitors and their moats:**
- **Gumroad** (10% fee): Brand recognition, massive creator base, Sahil's personal brand. No curation.
- **Lemon Squeezy** (5%+50p): Merchant of record (handles tax globally), developer-friendly API. No curation.
- **AppSumo** (70%+ cut): Massive buyer email list, editorial curation, lifetime deal model. Extractive for makers.
- **Product Hunt** (free): Launch-day traffic spikes, social proof. No ongoing sales, traffic dies after day 1.
- **Indie Hackers** (free): Community, but no marketplace. Stripe acquired them and it's stagnating.

**What IndieStack does NOT have yet:**
- Real traffic or sales (pre-launch effectively)
- A large maker base
- Brand recognition
- Merchant of record capability (makers handle their own tax via Stripe)
- A mobile app
- An API

**Technical capabilities (what we can build fast):**
- Pure Python server-side rendering (no JS framework, no build step)
- SQLite with FTS5 full-text search
- Stripe Connect for payments
- Can build API endpoints trivially (FastAPI)
- Can build MCP servers (Python SDK available)
- Can add AI features via Claude/OpenAI APIs

## The Brief

Give me **10 genuinely defensible differentiators** that IndieStack could build. For each one:

1. **Name it** (catchy, memorable)
2. **One-line pitch** (what it does for the user)
3. **Why it's defensible** (why Gumroad/Lemon Squeezy/AppSumo can't or won't copy it)
4. **Build complexity** (weekend hack / 1-2 weeks / month+ project)
5. **Network effect potential** (does it get better with more users?)
6. **Revenue impact** (does it directly drive sales or is it a growth play?)

## Constraints
- Must be buildable by 2 part-time CS students
- Must work with the existing Python/FastAPI/SQLite stack
- Must align with the "save your tokens" positioning
- Prefer ideas that create network effects or switching costs
- Prefer ideas that are weird/novel over ideas that are "table stakes"
- Do NOT suggest "build a community forum" or "add a blog" — those are generic and don't create moats

## Starter Ideas to Riff On (improve, combine, or discard)
- **MCP Server**: An IndieStack plugin for AI coding tools (Claude Code, Cursor). When a developer is about to build something, their AI checks IndieStack for existing tools first. "Before you spend 50k tokens building invoicing, there's Plausible on IndieStack for £9/mo."
- **Build vs Buy AI Calculator**: Paste a feature description, get a token/time estimate to build it vs the cost of an indie tool.
- **Tool Stacks**: Curated bundles like "Launch a SaaS this weekend" — analytics + payments + auth + landing page for £X total.
- **Maker Referral Graph**: Makers earn commission recommending each other's tools. Creates a cross-promotion network.
- **"Shipped With" Badges**: Embeddable badges for sites built using IndieStack tools. Free marketing flywheel.

## Format
Be specific. Include example UX flows where helpful. Prioritize the top 3 you'd build first and explain why. End with a "dark horse" idea that sounds crazy but might be brilliant.
