"""One-off: reply to Ed's email about magic links + GitHub."""
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

html = """
<div style="font-family:-apple-system,sans-serif;max-width:600px;margin:0 auto;">
    <p style="color:#444;font-size:15px;line-height:1.6;">Hey Ed,</p>

    <p style="color:#444;font-size:15px;line-height:1.6;">
        Magic links are live! You just need to log into the admin panel first at
        <a href="https://indiestack.fly.dev/admin">indiestack.fly.dev/admin</a>
        with the admin password (you already have it).
    </p>

    <p style="color:#444;font-size:15px;line-height:1.6;">
        Once you're in, click the <strong>"Tools"</strong> tab, then use the
        <strong>"Special"</strong> dropdown to filter by <strong>"Unclaimed"</strong>.
        You'll see a <strong>"Copy Link"</strong> button next to each unclaimed tool.
        Click it, and it generates a magic claim URL you can paste straight into your DMs.
    </p>

    <p style="color:#444;font-size:15px;line-height:1.6;">
        On the GitHub front — I've set up the repo and added you as a collaborator.
        You should have an invite waiting:
    </p>

    <div style="background:#F5F3F0;padding:16px 20px;border-radius:12px;margin:16px 0;">
        <p style="color:#333;font-size:14px;margin:0;">
            <strong>Repo:</strong> <a href="https://github.com/Pattyboi101/indiestack">github.com/Pattyboi101/indiestack</a> (private)<br><br>
            Accept the invite, clone it, make your changes on a branch, and open a PR.
            I'll review and merge, then deploy from my end.
        </p>
    </div>

    <p style="color:#444;font-size:15px;line-height:1.6;">
        Looking forward to seeing the no-login submit patch!
    </p>

    <p style="color:#444;font-size:15px;line-height:1.6;">
        Cheers,<br>
        Patrick
    </p>
</div>
"""

msg = MIMEMultipart('alternative')
msg['Subject'] = 'Re: Magic claim links + GitHub repo'
msg['From'] = f'IndieStack <{os.environ.get("SMTP_FROM", "noreply@indiestack.fly.dev")}>'
msg['To'] = 'toedgamings@gmail.com'
msg.attach(MIMEText(html, 'html'))

with smtplib.SMTP(os.environ['SMTP_HOST'], 587) as server:
    server.starttls()
    server.login(os.environ['SMTP_USER'], os.environ['SMTP_PASSWORD'])
    server.sendmail(os.environ['SMTP_FROM'], ['toedgamings@gmail.com'], msg.as_string())
    print('Reply sent to Ed!')
