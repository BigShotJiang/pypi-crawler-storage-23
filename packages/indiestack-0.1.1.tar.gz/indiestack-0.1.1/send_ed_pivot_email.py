"""One-off: email Ed the positioning pivot details for marketing."""
import asyncio
import sys
sys.path.insert(0, '/app/src' if __import__('os').path.exists('/app/src') else 'src')

from indiestack.email import send_email, _email_wrapper

html = """
<div style="text-align:center;margin-bottom:24px;">
    <div style="display:inline-block;background:#1A2D4A;color:#00D4F5;font-size:11px;font-weight:700;
                text-transform:uppercase;letter-spacing:1.5px;padding:6px 14px;border-radius:999px;">
        Positioning Update
    </div>
</div>

<h2 style="font-family:serif;font-size:22px;color:#1A2D4A;margin-bottom:8px;text-align:center;">
    We've pivoted the positioning
</h2>
<p style="color:#6B6560;font-size:15px;margin-bottom:24px;">
    Hey Ed &mdash; big update. We've reframed the entire landing page to position IndieStack as
    <strong>"Your AI's tool discovery layer"</strong> instead of just another SaaS directory.
    Here's what changed and how to use it in your outreach.
</p>

<h3 style="font-family:serif;font-size:17px;color:#1A2D4A;margin-bottom:8px;">The new story</h3>
<div style="background:#F0F7FA;border-radius:12px;padding:20px;margin-bottom:24px;">
    <p style="font-size:15px;color:#1A2D4A;font-weight:700;margin:0 0 8px;">
        "Your AI already knows what exists."
    </p>
    <p style="font-size:14px;color:#6B6560;margin:0;line-height:1.6;">
        IndieStack plugs into Claude, Cursor, and Windsurf via MCP. Before your AI writes a single line
        of boilerplate, it searches 130+ vetted indie tools and suggests what's already built.
    </p>
</div>

<h3 style="font-family:serif;font-size:17px;color:#1A2D4A;margin-bottom:8px;">Key marketing angles</h3>
<div style="color:#6B6560;font-size:14px;line-height:1.8;margin-bottom:24px;">
    <p style="margin:0 0 8px;"><strong>1. For Reddit/HN posts:</strong> "Stop wasting tokens rebuilding auth, payments, and analytics. Install IndieStack's MCP server and your AI checks what already exists before writing 50k tokens of boilerplate."</p>
    <p style="margin:0 0 8px;"><strong>2. For maker outreach:</strong> "Your tool gets discovered by AI coding assistants, not just humans browsing a directory. When a dev asks Claude to 'build invoicing', it suggests YOUR tool first."</p>
    <p style="margin:0 0 8px;"><strong>3. For dev communities:</strong> "pip install indiestack + one command = your AI stops rebuilding what indie makers already built."</p>
    <p style="margin:0 0 8px;"><strong>4. Package.json angle:</strong> "Paste your package.json at indiestack.fly.dev/stacks/generator and see how many of your DIY dependencies have indie alternatives."</p>
</div>

<h3 style="font-family:serif;font-size:17px;color:#1A2D4A;margin-bottom:8px;">What changed on the site</h3>
<div style="color:#6B6560;font-size:14px;line-height:1.8;margin-bottom:24px;">
    <p style="margin:0 0 4px;">&bull; <strong>New headline:</strong> "Your AI already knows what exists." (was "Skip the boilerplate")</p>
    <p style="margin:0 0 4px;">&bull; <strong>Hero visual:</strong> Shows a code conversation where AI suggests a tool instead of writing code</p>
    <p style="margin:0 0 4px;">&bull; <strong>MCP install moved to position 2</strong> (was buried at position 10)</p>
    <p style="margin:0 0 4px;">&bull; <strong>Package.json analyzer promoted</strong> with dedicated CTA card</p>
    <p style="margin:0 0 4px;">&bull; <strong>"How it works" rewritten:</strong> Install &rarr; Code &rarr; Save (not Discover &rarr; Upvote &rarr; Submit)</p>
    <p style="margin:0 0 4px;">&bull; <strong>Page title:</strong> "IndieStack &mdash; Your AI's Tool Discovery Layer"</p>
    <p style="margin:0 0 4px;">&bull; <strong>Meta description updated</strong> for SEO</p>
</div>

<h3 style="font-family:serif;font-size:17px;color:#1A2D4A;margin-bottom:8px;">Why this matters</h3>
<p style="color:#6B6560;font-size:14px;line-height:1.6;margin-bottom:24px;">
    Every directory competes with Product Hunt and AlternativeTo. Nobody else is the
    <strong>discovery layer inside your AI coding tool</strong>. The MCP server is the moat &mdash;
    when devs install it, IndieStack becomes part of their daily workflow, not a website they visit once.
</p>

<div style="background:#ECFDF5;border-radius:12px;padding:16px;margin-bottom:24px;text-align:center;">
    <p style="font-size:14px;color:#065F46;font-weight:600;margin:0;">
        The landing page is live now. Take a look and update your outreach accordingly.
    </p>
</div>

<div style="text-align:center;margin-top:24px;">
    <a href="https://indiestack.fly.dev" style="display:inline-block;background:#00D4F5;color:#1A2D4A;
       padding:14px 32px;border-radius:8px;font-weight:700;font-size:16px;text-decoration:none;">
        See the New Landing Page
    </a>
</div>
"""

async def main():
    ok = await send_email(
        "ed.mills@hotmail.co.uk",
        "IndieStack positioning pivot — new marketing angles for you",
        html
    )
    print("SENT" if ok else "FAILED")

asyncio.run(main())
