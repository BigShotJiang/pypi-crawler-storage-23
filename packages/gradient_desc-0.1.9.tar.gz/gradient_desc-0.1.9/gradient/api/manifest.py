"""Manifest helpers."""

import json
import os
import torch
from datetime import datetime
from typing import Dict, List, Optional


def _manifest_path(run_dir: str) -> str:
    return os.path.join(run_dir, "manifest.json")

def load_manifest(run_dir: str) -> dict:
    """
    Load manifest.json if it exists, otherwise return a valid empty manifest.
    Works for both legacy run_dir and repo_path.
    """
    path = _manifest_path(run_dir)
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)

    return {
        "checkpoints": []
    }


def save_manifest(run_dir: str, manifest: dict) -> None:
    """
    Persist manifest.json to disk.
    """
    os.makedirs(run_dir, exist_ok=True)
    path = _manifest_path(run_dir)
    with open(path, "w") as f:
        json.dump(manifest, f, indent=2)


def record_checkpoint(run_dir: str, ckpt_path: str) -> None:
    """
    Append a checkpoint entry to the manifest.
    """
    payload = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    data = payload["data"]
    meta = data.get("meta", {})

    manifest = load_manifest(run_dir)

    manifest["checkpoints"].append({
        "step": data["step"],
        "branch": meta.get("branch"),
        "file": ckpt_path,
        "type": "delta" if payload.get("is_delta", False) else "anchor",
    })

    save_manifest(run_dir, manifest)


def latest_checkpoint_for_branch(
    run_dir: str,
    branch: str,
) -> Optional[str]:
    """
    Return the latest checkpoint ref for a branch as 'branch@step',
    or None if no checkpoints exist.
    """
    manifest = load_manifest(run_dir)
    checkpoints = manifest.get("checkpoints", [])

    best_step = -1
    best_ref = None

    for c in checkpoints:
        if c.get("branch") != branch:
            continue

        step = c.get("step")
        if step is not None and step > best_step:
            best_step = step
            best_ref = f"{branch}@{step}"

    return best_ref

def load_repo_manifest(repo_path: str) -> dict:
    """
    Load repo manifest with enhanced metadata.
    If manifest doesn't exist or is legacy format, migrates to new format.
    """
    manifest = load_manifest(repo_path)
    
    if "repo_name" not in manifest:
        manifest["repo_name"] = os.path.basename(repo_path)
    if "created_at" not in manifest:
        manifest["created_at"] = datetime.now().isoformat()
    if "checkpoints" not in manifest:
        manifest["checkpoints"] = []
    
    return manifest


def save_repo_manifest(repo_path: str, manifest: dict) -> None:
    """Save repo manifest (same as save_manifest but explicit name)."""
    save_manifest(repo_path, manifest)


def init_repo_manifest(
    repo_path: str,
    repo_name: str,
    description: Optional[str] = None,
) -> dict:
    """
    Initialize a new repo manifest with metadata.
    """
    manifest = {
        "repo_name": repo_name,
        "description": description or "",
        "created_at": datetime.now().isoformat(),
        "checkpoints": [],
    }
    save_manifest(repo_path, manifest)
    return manifest


def get_repo_branches(repo_path: str) -> Dict[str, int]:
    """
    Get all branches in a repo with their latest step.
    Returns dict of {branch_name: latest_step}.
    """
    manifest = load_manifest(repo_path)
    checkpoints = manifest.get("checkpoints", [])
    
    branches: Dict[str, int] = {}
    for c in checkpoints:
        branch = c.get("branch")
        step = c.get("step")
        if branch and step is not None:
            if branch not in branches or step > branches[branch]:
                branches[branch] = step
    
    return branches


def get_branch_checkpoints(repo_path: str, branch: str) -> List[dict]:
    """
    Get all checkpoints for a specific branch, sorted by step.
    """
    manifest = load_manifest(repo_path)
    checkpoints = manifest.get("checkpoints", [])
    
    branch_ckpts = [c for c in checkpoints if c.get("branch") == branch]
    return sorted(branch_ckpts, key=lambda c: c.get("step", 0))


def get_repo_stats(repo_path: str) -> dict:
    """
    Get statistics about a repo.
    """
    manifest = load_manifest(repo_path)
    checkpoints = manifest.get("checkpoints", [])
    
    branches = get_repo_branches(repo_path)
    
    anchor_count = sum(1 for c in checkpoints if c.get("type") == "anchor")
    delta_count = sum(1 for c in checkpoints if c.get("type") == "delta")
    
    return {
        "repo_name": manifest.get("repo_name", os.path.basename(repo_path)),
        "description": manifest.get("description", ""),
        "total_checkpoints": len(checkpoints),
        "anchor_count": anchor_count,
        "delta_count": delta_count,
        "branch_count": len(branches),
        "branches": branches,
    }
