"""Workspace and repo management helpers."""

import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional


WORKSPACE_DIR = ".gradient"
WORKSPACE_CONFIG = "config.json"
REPO_DIR = ".gradient-repo"
REPO_CONFIG = "config.json"


@dataclass
class WorkspaceConfig:
    """Configuration for a Gradient workspace (contains multiple repos)."""
    name: str
    root_path: str
    repos: List[str] = field(default_factory=list)
    created_at: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "workspace_name": self.name,
            "root_path": self.root_path,
            "repos": self.repos,
            "created_at": self.created_at or datetime.now().isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict, root_path: str) -> "WorkspaceConfig":
        return cls(
            name=data.get("workspace_name", "unnamed"),
            root_path=root_path,
            repos=data.get("repos", []),
            created_at=data.get("created_at"),
        )


@dataclass
class RepoConfig:
    """Configuration for a Gradient repo (one model)."""
    name: str
    repo_path: str
    workspace_path: Optional[str] = None
    description: Optional[str] = None
    created_at: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "repo_name": self.name,
            "description": self.description or "",
            "workspace_path": self.workspace_path,
            "created_at": self.created_at or datetime.now().isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict, repo_path: str) -> "RepoConfig":
        return cls(
            name=data.get("repo_name", "unnamed"),
            repo_path=repo_path,
            workspace_path=data.get("workspace_path"),
            description=data.get("description"),
            created_at=data.get("created_at"),
        )

def find_workspace(start: str = ".") -> Optional[str]:
    """
    Walk up directory tree looking for .gradient/ workspace marker.
    Returns the workspace root path, or None if not found.
    """
    curr = os.path.abspath(start)
    while True:
        workspace_dir = os.path.join(curr, WORKSPACE_DIR)
        if os.path.isdir(workspace_dir):
            return curr
        parent = os.path.dirname(curr)
        if parent == curr:
            return None
        curr = parent


def find_repo(start: str = ".") -> Optional[str]:
    """
    Walk up directory tree looking for .gradient-repo/ marker.
    Returns the repo root path, or None if not found.
    """
    curr = os.path.abspath(start)
    while True:
        repo_dir = os.path.join(curr, REPO_DIR)
        if os.path.isdir(repo_dir):
            return curr
        parent = os.path.dirname(curr)
        if parent == curr:
            return None
        curr = parent

def load_workspace_config(workspace_path: str) -> Optional[WorkspaceConfig]:
    """Load workspace configuration from .gradient/config.json."""
    config_path = os.path.join(workspace_path, WORKSPACE_DIR, WORKSPACE_CONFIG)
    if not os.path.exists(config_path):
        return None
    with open(config_path, "r") as f:
        data = json.load(f)
    return WorkspaceConfig.from_dict(data, workspace_path)


def save_workspace_config(config: WorkspaceConfig) -> None:
    """Save workspace configuration to .gradient/config.json."""
    workspace_dir = os.path.join(config.root_path, WORKSPACE_DIR)
    os.makedirs(workspace_dir, exist_ok=True)
    config_path = os.path.join(workspace_dir, WORKSPACE_CONFIG)
    with open(config_path, "w") as f:
        json.dump(config.to_dict(), f, indent=2)


def init_workspace(path: str, name: Optional[str] = None) -> WorkspaceConfig:
    """
    Initialize a new Gradient workspace at the given path.
    Creates .gradient/ directory with config.json.
    """
    abs_path = os.path.abspath(path)
    os.makedirs(abs_path, exist_ok=True)
    
    existing = load_workspace_config(abs_path)
    if existing:
        return existing
    
    workspace_name = name or os.path.basename(abs_path)
    config = WorkspaceConfig(
        name=workspace_name,
        root_path=abs_path,
        repos=[],
        created_at=datetime.now().isoformat(),
    )
    save_workspace_config(config)
    return config


def list_workspace_repos(workspace_path: str) -> List[str]:
    """List all repos in a workspace by scanning for .gradient-repo directories."""
    repos = []
    for entry in os.listdir(workspace_path):
        entry_path = os.path.join(workspace_path, entry)
        if os.path.isdir(entry_path):
            repo_marker = os.path.join(entry_path, REPO_DIR)
            if os.path.isdir(repo_marker):
                repos.append(entry)
    return sorted(repos)


def add_repo_to_workspace(workspace_path: str, repo_name: str) -> None:
    """Register a repo in the workspace config."""
    config = load_workspace_config(workspace_path)
    if config is None:
        raise ValueError(f"No workspace found at {workspace_path}")
    if repo_name not in config.repos:
        config.repos.append(repo_name)
        config.repos.sort()
        save_workspace_config(config)

def load_repo_config(repo_path: str) -> Optional[RepoConfig]:
    """Load repo configuration from .gradient-repo/config.json."""
    config_path = os.path.join(repo_path, REPO_DIR, REPO_CONFIG)
    if not os.path.exists(config_path):
        return None
    with open(config_path, "r") as f:
        data = json.load(f)
    return RepoConfig.from_dict(data, repo_path)


def save_repo_config(config: RepoConfig) -> None:
    """Save repo configuration to .gradient-repo/config.json."""
    repo_dir = os.path.join(config.repo_path, REPO_DIR)
    os.makedirs(repo_dir, exist_ok=True)
    config_path = os.path.join(repo_dir, REPO_CONFIG)
    with open(config_path, "w") as f:
        json.dump(config.to_dict(), f, indent=2)


def init_repo(
    repo_path: str,
    name: Optional[str] = None,
    description: Optional[str] = None,
    workspace_path: Optional[str] = None,
) -> RepoConfig:
    """
    Initialize a new Gradient repo at the given path.
    Creates .gradient-repo/ directory with config.json.
    
    If workspace_path is provided, registers the repo with the workspace.
    """
    abs_path = os.path.abspath(repo_path)
    os.makedirs(abs_path, exist_ok=True)
    
    existing = load_repo_config(abs_path)
    if existing:
        return existing
    
    repo_name = name or os.path.basename(abs_path)
    config = RepoConfig(
        name=repo_name,
        repo_path=abs_path,
        workspace_path=workspace_path,
        description=description,
        created_at=datetime.now().isoformat(),
    )
    save_repo_config(config)
    
    if workspace_path:
        add_repo_to_workspace(workspace_path, repo_name)
    
    return config


def get_repo_path_in_workspace(workspace_path: str, repo_name: str) -> str:
    """Get the full path to a repo within a workspace."""
    return os.path.join(workspace_path, repo_name)

@dataclass
class GradientContext:
    """Resolved context for current directory."""
    workspace_path: Optional[str] = None
    workspace_config: Optional[WorkspaceConfig] = None
    repo_path: Optional[str] = None
    repo_config: Optional[RepoConfig] = None

    @property
    def in_workspace(self) -> bool:
        return self.workspace_path is not None

    @property
    def in_repo(self) -> bool:
        return self.repo_path is not None


def resolve_context(start: str = ".") -> GradientContext:
    """
    Resolve the Gradient context for the current directory.
    Finds workspace and repo by walking up the directory tree.
    """
    ctx = GradientContext()
    
    repo_path = find_repo(start)
    if repo_path:
        ctx.repo_path = repo_path
        ctx.repo_config = load_repo_config(repo_path)

    workspace_path = find_workspace(start)
    if workspace_path:
        ctx.workspace_path = workspace_path
        ctx.workspace_config = load_workspace_config(workspace_path)
    
    return ctx
