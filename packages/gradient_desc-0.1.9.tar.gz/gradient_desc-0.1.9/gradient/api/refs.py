def parse_ref(ref: str) -> tuple[str, int]:
    """Parse a checkpoint ref like 'branch@step'."""
    if "@" not in ref:
        raise ValueError(f"Invalid checkpoint ref: {ref}")
    branch, step = ref.split("@", 1)
    return branch, int(step)
