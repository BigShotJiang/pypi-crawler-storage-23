import os
from typing import Optional

from gradient.api.config import GradientConfig
from gradient.api.refs import parse_ref
from gradient.api.manifest import (
    load_manifest,
    save_manifest,
    record_checkpoint,
    latest_checkpoint_for_branch,
    load_repo_manifest,
)
from gradient.api.workspace import (
    find_workspace,
    find_repo,
    load_repo_config,
    get_repo_path_in_workspace,
    resolve_context,
    init_workspace,
    init_repo,
)
from gradient.core.checkpoint_engine import CheckPointEngine
from gradient.core.training_state import ExternalStateComponent


class GradientEngine:
    """Public API wrapper around CheckPointEngine."""

    def __init__(self, backend: CheckPointEngine, config: GradientConfig):
        self._engine = backend
        self._config = config
        self._autocommit_every: Optional[int] = None
        self._current_step: int = 0

    @classmethod
    def attach(
        cls,
        model,
        optimizer,
        scheduler=None,
        *,
        workspace: Optional[str] = None,
        repo: Optional[str] = None,
        config: Optional[GradientConfig] = None,
    ):
        """Attach to a model and optimizer for checkpointing."""
        env_workspace = os.getenv("GRADIENT_WORKSPACE")
        env_repo = os.getenv("GRADIENT_REPO")
        env_branch = os.getenv("GRADIENT_BRANCH")
        resume_ref = os.getenv("GRADIENT_RESUME_REF")
        autocommit = os.getenv("GRADIENT_AUTOCOMMIT")

        if env_workspace:
            workspace = env_workspace
        if env_repo:
            repo = env_repo

        workspace_path, repo_name = cls._resolve_workspace_repo(workspace, repo)

        if config is None:
            config = GradientConfig(
                workspace_path=workspace_path,
                repo_name=repo_name,
            )

        if env_branch is not None:
            config.branch = env_branch

        os.makedirs(config.repo_path, exist_ok=True)

        compress_deltas = config.compression != "off"
        if config.delta_threshold is None:
            delta_threshold = 1e-3 if config.compression == "aggressive" else 0.0
        else:
            delta_threshold = config.delta_threshold

        backend = CheckPointEngine(
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            ckpt_dir=config.repo_path,
            delta_optimizer=config.delta_optimizer,
            reanchor_interval=config.reanchor_interval,
            compress_deltas=compress_deltas,
            delta_threshold=delta_threshold,
            strict_resume=config.strict_resume,
        )

        engine = cls(backend, config)

        manifest = load_repo_manifest(config.repo_path)
        save_manifest(config.repo_path, manifest)

        if autocommit:
            engine.autocommit(every=int(autocommit))

        if resume_ref:
            if resume_ref == "latest":
                engine._current_step = engine.resume_latest()
            else:
                engine._current_step = engine.resume(resume_ref)
        else:
            engine._current_step = 0

        return engine

    @classmethod
    def _resolve_workspace_repo(
        cls,
        workspace: Optional[str],
        repo: Optional[str],
    ) -> tuple[str, str]:
        """Resolve workspace path and repo name."""
        if workspace and repo:
            abs_workspace = os.path.abspath(workspace)

            if not find_workspace(abs_workspace):
                init_workspace(abs_workspace)

            repo_path = get_repo_path_in_workspace(abs_workspace, repo)
            if not find_repo(repo_path):
                init_repo(repo_path, name=repo, workspace_path=abs_workspace)

            return abs_workspace, repo

        ctx = resolve_context()

        if ctx.in_repo and ctx.repo_config:
            ws_path = ctx.workspace_path or os.path.dirname(ctx.repo_path)
            return ws_path, ctx.repo_config.name

        if ctx.in_workspace and repo:
            return ctx.workspace_path, repo

        raise ValueError(
            "Could not determine workspace/repo. Provide one of:\n"
            "  - workspace='path/to/workspace', repo='repo_name'\n"
            "  - Run from within an initialized repo directory\n"
            "\n"
            "To initialize:\n"
            "  gradient workspace init /path/to/workspace\n"
            "  gradient repo init my_model"
        )

    def _ckpt_path(self, branch: str, step: int) -> str:
        ckpt_id = f"{branch}_s{step}"
        return os.path.join(self._config.repo_path, f"ckpt_{ckpt_id}.pt")

    def commit(self, step: int, *, message: str = "") -> str:
        """Commit a checkpoint at a logical step."""
        path = self._engine.commit(
            step=step,
            branch=self._config.branch,
            message=message,
        )
        record_checkpoint(self._config.repo_path, path)
        return path

    def resume(self, ref: str) -> int:
        """Resume from a checkpoint ref (branch@step)."""
        branch, step = parse_ref(ref)
        ckpt_path = self._ckpt_path(branch, step)
        return self._engine.resume(ckpt_path)

    def resume_latest(self) -> int:
        """Resume from the most recent checkpoint on the active branch."""
        branch = self._config.branch
        ref = latest_checkpoint_for_branch(
            run_dir=self._config.repo_path,
            branch=branch,
        )
        if ref is None:
            raise RuntimeError(
                f"No checkpoints found for branch '{branch}'"
            )
        return self.resume(ref)

    def fork(
        self,
        *,
        from_ref: str,
        new_branch: str,
        reset_optimizer: bool = False,
        reset_scheduler: bool = False,
        reset_rng_seed: Optional[int] = None,
        message: str = "",
    ) -> str:
        """Fork a new branch from an existing checkpoint."""
        branch, step = parse_ref(from_ref)
        ckpt_path = self._ckpt_path(branch, step)

        path = self._engine.fork_into(
            checkpoint_ref=ckpt_path,
            new_branch=new_branch,
            reset_optimizer_state=reset_optimizer,
            reset_scheduler_state=reset_scheduler,
            reset_rng_seed=reset_rng_seed,
            message=message,
        )

        record_checkpoint(self._config.repo_path, path)
        return path

    def autocommit(self, *, every: int):
        self._autocommit_every = every

    def maybe_commit(self, step: int):
        if self._autocommit_every is not None:
            if step % self._autocommit_every == 0:
                self.commit(step)

    def register_state(self, name: str, *, getter, setter):
        """Register external state."""
        self._engine._components[name] = ExternalStateComponent(
            state_getter=getter,
            state_setter=setter,
        )

    @property
    def current_step(self) -> int:
        """Logical step restored on attach. Zero means fresh run."""
        return self._current_step

    @property
    def repo_name(self) -> str:
        """Current repo name."""
        return self._config.repo_name

    @property
    def workspace_path(self) -> str:
        """Workspace path."""
        return self._config.workspace_path

    @property
    def repo_path(self) -> str:
        """Repo path."""
        return self._config.repo_path

    @property
    def branch(self) -> str:
        """Current branch name."""
        return self._config.branch
