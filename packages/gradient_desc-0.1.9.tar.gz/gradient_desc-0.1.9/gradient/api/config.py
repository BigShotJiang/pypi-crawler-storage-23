from dataclasses import dataclass
from typing import Literal, Optional
import os


@dataclass
class GradientConfig:
    """Configuration for a Gradient training run."""

    workspace_path: str
    repo_name: str

    branch: str = "main"

    checkpoint_every: Optional[int] = None

    delta_optimizer: bool = True
    reanchor_interval: Optional[int] = None
    compression: Literal["off", "auto", "aggressive"] = "auto"
    delta_threshold: Optional[float] = None

    strict_resume: bool = True

    @property
    def repo_path(self) -> str:
        """Return the full path to the repo directory."""
        return os.path.join(self.workspace_path, self.repo_name)
