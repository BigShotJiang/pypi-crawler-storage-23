"""Auth helpers for Gradient CLI access tokens."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import importlib
import json
import os
from urllib import error as urllib_error
from urllib import parse as urllib_parse
from urllib import request as urllib_request


KEYRING_SERVICE_NAME = "gradient-cli"
KEYRING_USERNAME = "access-token"

AUTH_CONFIG_DIRNAME = ".gradient"
AUTH_CONFIG_FILENAME = "auth.json"

AUTH_VERIFY_URL_ENV_VAR = "GRADIENT_AUTH_VERIFY_URL"
DEFAULT_AUTH_VERIFY_URL = "https://www.gradient-desc.com/api/auth/verify-token"
DEFAULT_VERIFY_TIMEOUT_SECONDS = 10.0
MAX_VERIFY_REDIRECTS = 3

_SENSITIVE_METADATA_KEYS = {
    "authorization",
    "token",
    "access_token",
    "raw_token",
    "refresh_token",
}


class AuthError(RuntimeError):
    """Raised when auth configuration or token operations fail."""


@dataclass
class AuthSession:
    """Non-secret auth metadata persisted on disk."""

    verify_url: str
    last_verified_at: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "verify_url": self.verify_url,
            "last_verified_at": self.last_verified_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AuthSession":
        metadata = data.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        return cls(
            verify_url=str(data.get("verify_url", "")).strip(),
            last_verified_at=str(data.get("last_verified_at", "")).strip(),
            metadata=metadata,
        )


def get_auth_dir() -> Path:
    """Return the config directory used for non-secret auth metadata."""
    return Path.home() / AUTH_CONFIG_DIRNAME


def get_auth_config_path() -> Path:
    """Return path to auth metadata file."""
    return get_auth_dir() / AUTH_CONFIG_FILENAME


def resolve_verify_url(explicit_verify_url: str | None = None) -> str:
    """Resolve and validate the token verification URL."""
    candidate = explicit_verify_url
    if candidate is None or not str(candidate).strip():
        candidate = os.getenv(AUTH_VERIFY_URL_ENV_VAR, "").strip()
    if not candidate:
        candidate = DEFAULT_AUTH_VERIFY_URL

    verify_url = str(candidate).strip()

    parsed = urllib_parse.urlparse(verify_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise AuthError(f"Invalid verify URL: {verify_url}")

    return verify_url


def verify_token(
    token: str,
    verify_url: str,
    timeout_seconds: float = DEFAULT_VERIFY_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    """Verify token by calling remote auth endpoint."""
    clean_token = token.strip()
    if not clean_token:
        raise AuthError("Access token cannot be empty.")
    current_url = verify_url
    for _ in range(MAX_VERIFY_REDIRECTS + 1):
        request = urllib_request.Request(
            current_url,
            data=b"{}",
            method="POST",
            headers={
                "Authorization": f"Bearer {clean_token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )

        try:
            with urllib_request.urlopen(request, timeout=timeout_seconds) as response:
                status = int(response.getcode() or 0)
                body = response.read()
        except urllib_error.HTTPError as exc:
            status = int(exc.code or 0)
            body = exc.read() if hasattr(exc, "read") else b""

            if status in (301, 302, 303, 307, 308):
                location = exc.headers.get("Location")
                if not location:
                    _raise_verify_error(status, body)
                current_url = urllib_parse.urljoin(current_url, location)
                continue

            _raise_verify_error(status, body)
        except urllib_error.URLError as exc:
            reason = getattr(exc, "reason", exc)
            raise AuthError(f"Token verification request failed: {reason}") from exc
        except TimeoutError as exc:
            raise AuthError("Token verification request timed out.") from exc

        if status < 200 or status >= 300:
            _raise_verify_error(status, body)

        payload = _decode_response_payload(body)
        _validate_verify_payload(payload)
        return payload

    raise AuthError("Token verification failed due to too many redirects.")


def store_token(token: str) -> None:
    """Store the token in OS keyring."""
    clean_token = token.strip()
    if not clean_token:
        raise AuthError("Access token cannot be empty.")

    keyring = _load_keyring_module()
    try:
        keyring.set_password(KEYRING_SERVICE_NAME, KEYRING_USERNAME, clean_token)
    except Exception as exc:  # pragma: no cover - backend exceptions vary by platform
        if _is_no_keyring_backend_error(exc):
            raise AuthError(
                "No keyring backend available. Configure an OS keyring backend and rerun `gradient login`."
            ) from exc
        raise AuthError("Failed to store access token in keyring.") from exc


def load_token() -> str | None:
    """Load stored token from OS keyring."""
    keyring = _load_keyring_module()
    try:
        token = keyring.get_password(KEYRING_SERVICE_NAME, KEYRING_USERNAME)
    except Exception as exc:  # pragma: no cover - backend exceptions vary by platform
        if _is_no_keyring_backend_error(exc):
            raise AuthError(
                "No keyring backend available. Configure an OS keyring backend and rerun `gradient login`."
            ) from exc
        raise AuthError("Failed to read access token from keyring.") from exc

    if token is None:
        return None
    clean_token = str(token).strip()
    return clean_token or None


def save_session_metadata(verify_url: str, verify_payload: dict[str, Any]) -> AuthSession:
    """Persist non-secret auth metadata in ~/.gradient/auth.json."""
    session = AuthSession(
        verify_url=verify_url,
        last_verified_at=datetime.now(timezone.utc).isoformat(),
        metadata=_sanitize_metadata(verify_payload),
    )

    auth_dir = get_auth_dir()
    auth_dir.mkdir(parents=True, exist_ok=True)

    config_path = get_auth_config_path()
    try:
        config_path.write_text(json.dumps(session.to_dict(), indent=2), encoding="utf-8")
        _lock_down_permissions(config_path)
    except OSError as exc:
        raise AuthError(f"Failed to write auth metadata at {config_path}.") from exc

    return session


def load_session_metadata() -> AuthSession | None:
    """Read non-secret auth metadata from ~/.gradient/auth.json."""
    config_path = get_auth_config_path()
    if not config_path.exists():
        return None

    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise AuthError(f"Failed to read auth metadata at {config_path}.") from exc
    except json.JSONDecodeError as exc:
        raise AuthError(f"Invalid JSON in auth metadata at {config_path}.") from exc

    if not isinstance(data, dict):
        raise AuthError(f"Invalid auth metadata format at {config_path}.")

    session = AuthSession.from_dict(data)
    if not session.verify_url:
        raise AuthError(f"Auth metadata missing verify_url at {config_path}.")
    if not session.last_verified_at:
        raise AuthError(f"Auth metadata missing last_verified_at at {config_path}.")

    return session


def build_http_auth_headers() -> dict[str, str]:
    """Build Authorization header from stored token."""
    token = load_token()
    if not token:
        raise AuthError("No access token found. Run `gradient login` first.")
    return {"Authorization": f"Bearer {token}"}


def build_grpc_auth_metadata() -> list[tuple[str, str]]:
    """Build gRPC metadata from stored token."""
    token = load_token()
    if not token:
        raise AuthError("No access token found. Run `gradient login` first.")
    return [("authorization", f"Bearer {token}")]


def _decode_response_payload(body: bytes) -> dict[str, Any]:
    if not body:
        return {}

    text = body.decode("utf-8", errors="replace").strip()
    if not text:
        return {}

    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return {"raw_response": text}

    if isinstance(payload, dict):
        return payload

    return {"data": payload}


def _validate_verify_payload(payload: dict[str, Any]) -> None:
    raw_response = payload.get("raw_response")
    if not isinstance(raw_response, str):
        return

    trimmed = raw_response.strip().lower()
    if trimmed.startswith("<!doctype") or trimmed.startswith("<html"):
        raise AuthError(
            "Token verification endpoint returned HTML instead of API JSON. Check verify URL/deployment."
        )


def _extract_error_message(body: bytes) -> str:
    payload = _decode_response_payload(body)
    if not payload:
        return ""

    if isinstance(payload, dict):
        for key in ("error", "message", "detail"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        raw_response = payload.get("raw_response")
        if isinstance(raw_response, str) and raw_response.strip():
            return raw_response.strip()

    return ""


def _raise_verify_error(status: int, body: bytes) -> None:
    if status in (401, 403):
        raise AuthError("Token verification failed: invalid or unauthorized access token.")

    details = _extract_error_message(body)
    if details:
        raise AuthError(f"Token verification failed with status {status}: {details}")
    raise AuthError(f"Token verification failed with status {status}.")


def _sanitize_metadata(verify_payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(verify_payload, dict):
        return {}

    sanitized: dict[str, Any] = {}
    for key, value in verify_payload.items():
        if isinstance(key, str) and key.lower() in _SENSITIVE_METADATA_KEYS:
            continue
        sanitized[str(key)] = value
    return sanitized


def _load_keyring_module():
    try:
        return importlib.import_module("keyring")
    except ImportError as exc:
        raise AuthError(
            "Keyring support is required for `gradient login`. Ensure the `keyring` package is installed."
        ) from exc


def _is_no_keyring_backend_error(exc: Exception) -> bool:
    message = str(exc).lower()
    if "no recommended backend" in message or "no keyring backend" in message:
        return True

    try:
        keyring_errors = importlib.import_module("keyring.errors")
    except ImportError:
        return False

    for error_name in ("NoKeyringError", "InitError"):
        error_type = getattr(keyring_errors, error_name, None)
        if error_type is not None and isinstance(exc, error_type):
            return True

    return False


def _lock_down_permissions(path: Path) -> None:
    """Best-effort hardening for metadata file permissions."""
    try:
        os.chmod(path, 0o600)
    except OSError:
        # Windows and some filesystems may ignore POSIX modes.
        pass
