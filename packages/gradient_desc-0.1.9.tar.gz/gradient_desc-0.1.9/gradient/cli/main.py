"""
Gradient CLI - Git-like control for ML training runs.

Commands:
    Workspace:
        gradient workspace init [path]    Initialize a new workspace
        gradient workspace status         Show workspace with all repos

    Repo:
        gradient repo init <name>         Create a new repo in current workspace
        gradient repo list                List all repos in workspace

    Auth:
        gradient login                    Authenticate CLI with an access token

    Training:
        gradient status                   Show current repo status
        gradient resume <ref>             Resume training from a checkpoint
        gradient fork <ref> <branch>      Fork a new branch from a checkpoint
"""

import argparse
import getpass
import os
import sys

from gradient.api.workspace import (
    init_workspace,
    init_repo,
    find_workspace,
    find_repo,
    load_workspace_config,
    load_repo_config,
    list_workspace_repos,
    get_repo_path_in_workspace,
    resolve_context,
)
from gradient.api.manifest import (
    get_repo_branches,
    get_repo_stats,
    init_repo_manifest,
)
from gradient.api.auth import (
    AuthError,
    resolve_verify_url,
    verify_token,
    store_token,
    save_session_metadata,
)


# -------------------------------------------------
# Env hygiene
# -------------------------------------------------

GRADIENT_INTENT_ENV_VARS = (
    "GRADIENT_WORKSPACE",
    "GRADIENT_REPO",
    "GRADIENT_RESUME_REF",
    "GRADIENT_BRANCH",
    "GRADIENT_RESET_OPTIMIZER",
    "GRADIENT_RESET_SEED",
    "GRADIENT_AUTOCOMMIT",
)


def clear_gradient_env():
    """Clear transient GRADIENT_* env vars used for training handoff."""
    for key in GRADIENT_INTENT_ENV_VARS:
        os.environ.pop(key, None)


# -------------------------------------------------
# Workspace commands
# -------------------------------------------------

def cmd_workspace_init(args):
    """Initialize a new workspace."""
    path = args.path or "."
    name = args.name
    
    config = init_workspace(path, name)
    print(f"✔ Initialized workspace '{config.name}'")
    print(f"  Path: {config.root_path}")
    print()
    print("Next steps:")
    print(f"  cd {path}")
    print("  gradient repo init <model-name>")


def cmd_workspace_status(args):
    """Show workspace status with all repos."""
    workspace_path = find_workspace(args.path or ".")
    
    if not workspace_path:
        print("❌ No workspace found.")
        print("  Run 'gradient workspace init' to create one.")
        sys.exit(1)
    
    config = load_workspace_config(workspace_path)
    repos = list_workspace_repos(workspace_path)
    
    print(f"📂 Workspace: {config.name}")
    print(f"   Path: {workspace_path}")
    print()
    
    if not repos:
        print("   No repos yet.")
        print("   Run 'gradient repo init <name>' to create one.")
        return
    
    print(f"📦 Repos ({len(repos)}):")
    for repo_name in repos:
        repo_path = get_repo_path_in_workspace(workspace_path, repo_name)
        stats = get_repo_stats(repo_path)
        
        print(f"\n   {repo_name}/")
        if stats["description"]:
            print(f"      {stats['description']}")
        print(f"      Checkpoints: {stats['total_checkpoints']} ({stats['anchor_count']} anchors, {stats['delta_count']} deltas)")
        
        if stats["branches"]:
            print("      🌿 Branches:")
            for branch, latest_step in stats["branches"].items():
                print(f"         • {branch}: step {latest_step}")
        else:
            print("      No branches yet.")


# -------------------------------------------------
# Repo commands
# -------------------------------------------------

def cmd_repo_init(args):
    """Initialize a new repo in the current workspace."""
    # Find workspace
    workspace_path = find_workspace(".")
    
    if not workspace_path:
        print("❌ No workspace found.")
        print("  Run 'gradient workspace init' first.")
        sys.exit(1)
    
    repo_name = args.name
    description = args.description
    
    # Create repo directory inside workspace
    repo_path = get_repo_path_in_workspace(workspace_path, repo_name)
    
    # Initialize repo
    config = init_repo(
        repo_path=repo_path,
        name=repo_name,
        description=description,
        workspace_path=workspace_path,
    )
    
    # Initialize repo manifest
    init_repo_manifest(repo_path, repo_name, description)
    
    print(f"✔ Initialized repo '{repo_name}'")
    print(f"  Path: {repo_path}")
    if description:
        print(f"  Description: {description}")
    print()
    print("Next steps:")
    print(f"  cd {repo_name}")
    print("  # Add GradientEngine.attach() to your training script")


def cmd_repo_list(args):
    """List all repos in the workspace."""
    workspace_path = find_workspace(args.path or ".")
    
    if not workspace_path:
        print("❌ No workspace found.")
        sys.exit(1)
    
    repos = list_workspace_repos(workspace_path)
    
    if not repos:
        print("No repos in workspace.")
        return
    
    print(f"Repos in workspace ({len(repos)}):")
    for repo_name in repos:
        repo_path = get_repo_path_in_workspace(workspace_path, repo_name)
        repo_config = load_repo_config(repo_path)
        
        desc = ""
        if repo_config and repo_config.description:
            desc = f" - {repo_config.description}"
        
        print(f"  • {repo_name}{desc}")


# -------------------------------------------------
# Status command (repo-level)
# -------------------------------------------------

def cmd_status(args):
    """Show current repo status."""
    ctx = resolve_context()
    
    if not ctx.in_repo:
        print("❌ Not inside a Gradient repo.")
        print("  Run from inside an initialized repo directory.")
        print()
        print("  To initialize:")
        print("    gradient workspace init /path/to/workspace")
        print("    cd /path/to/workspace")
        print("    gradient repo init my_model")
        sys.exit(1)
    
    print_repo_status(ctx.repo_path, ctx.repo_config)


def print_repo_status(repo_path: str, repo_config):
    """Print status for a repo."""
    stats = get_repo_stats(repo_path)
    
    print(f"📦 Repo: {stats['repo_name']}")
    print(f"   Path: {repo_path}")
    if stats["description"]:
        print(f"   {stats['description']}")
    print()
    
    if not stats["branches"]:
        print("   No checkpoints yet.")
        return
    
    print(f"   Checkpoints: {stats['total_checkpoints']} ({stats['anchor_count']} anchors, {stats['delta_count']} deltas)")
    print()
    print("🌿 Branches:")
    for branch, latest_step in stats["branches"].items():
        print(f"   • {branch}: latest @ step {latest_step}")
    
    # Env intent
    resume_ref = os.getenv("GRADIENT_RESUME_REF")
    branch_env = os.getenv("GRADIENT_BRANCH")
    
    if resume_ref or branch_env:
        print()
        print("⚠️  Pending intent (from env vars):")
        if resume_ref:
            print(f"   Resume ref: {resume_ref}")
        if branch_env:
            print(f"   Branch override: {branch_env}")


# -------------------------------------------------
# Resume command
# -------------------------------------------------

def cmd_resume(args):
    """Set up environment for resuming from a checkpoint."""
    ctx = resolve_context()
    
    if not ctx.in_repo:
        print("❌ Not inside a Gradient repo.")
        print("  Run from inside an initialized repo directory.")
        sys.exit(1)

    os.environ["GRADIENT_WORKSPACE"] = ctx.workspace_path or os.path.dirname(ctx.repo_path)
    os.environ["GRADIENT_REPO"] = ctx.repo_config.name
    os.environ["GRADIENT_RESUME_REF"] = args.ref
    
    print(f"✔ Will resume from {args.ref}")
    print(f"✔ Repo: {ctx.repo_config.name}")
    print(f"   Path: {ctx.repo_path}")


# -------------------------------------------------
# Fork command
# -------------------------------------------------

def cmd_fork(args):
    """Set up environment for forking a new branch."""
    ctx = resolve_context()
    
    if not ctx.in_repo:
        print("❌ Not inside a Gradient repo.")
        print("  Run from inside an initialized repo directory.")
        sys.exit(1)

    os.environ["GRADIENT_WORKSPACE"] = ctx.workspace_path or os.path.dirname(ctx.repo_path)
    os.environ["GRADIENT_REPO"] = ctx.repo_config.name
    os.environ["GRADIENT_RESUME_REF"] = args.from_ref
    os.environ["GRADIENT_BRANCH"] = args.new_branch

    if args.reset_optimizer:
        os.environ["GRADIENT_RESET_OPTIMIZER"] = "1"
    if args.seed is not None:
        os.environ["GRADIENT_RESET_SEED"] = str(args.seed)

    print(f"✔ Forked branch '{args.new_branch}' from {args.from_ref}")
    print(f"✔ Repo: {ctx.repo_config.name}")
    print(f"   Path: {ctx.repo_path}")


# -------------------------------------------------
# Login command
# -------------------------------------------------

def cmd_login(args):
    """Verify and store a CLI access token."""
    token = (args.token or "").strip()
    if not token:
        token = getpass.getpass("Access token: ").strip()

    if not token:
        print("ERROR: Access token cannot be empty.")
        sys.exit(1)

    try:
        verify_url = resolve_verify_url(args.verify_url)
        verify_payload = verify_token(token, verify_url)
        store_token(token)
        session = save_session_metadata(verify_url, verify_payload)
    except AuthError as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)

    print("Login successful.")
    print(f"  Verify URL: {session.verify_url}")
    print(f"  Verified at: {session.last_verified_at}")
    if session.metadata:
        workspace_hint = (
            session.metadata.get("workspaceSlug")
            or session.metadata.get("workspace_slug")
            or session.metadata.get("workspaceId")
            or session.metadata.get("workspace_id")
        )
        if workspace_hint:
            print(f"  Workspace: {workspace_hint}")


# -------------------------------------------------
# CLI entrypoint
# -------------------------------------------------

def main():
    # Split argv on `--` to support chaining commands
    if "--" in sys.argv:
        idx = sys.argv.index("--")
        cli_argv = sys.argv[1:idx]
        exec_cmd = sys.argv[idx + 1:]
    else:
        cli_argv = sys.argv[1:]
        exec_cmd = None

    clear_gradient_env()

    parser = argparse.ArgumentParser(
        prog="gradient",
        description="Git-like control for ML training runs",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # -------------------------------------------------
    # gradient workspace init
    # -------------------------------------------------
    ws_parser = subparsers.add_parser(
        "workspace",
        help="Workspace management commands",
    )
    ws_subparsers = ws_parser.add_subparsers(dest="ws_command", required=True)
    
    ws_init = ws_subparsers.add_parser(
        "init",
        help="Initialize a new workspace",
    )
    ws_init.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Path to create workspace (default: current directory)",
    )
    ws_init.add_argument(
        "--name",
        help="Workspace name (default: directory name)",
    )
    
    ws_status = ws_subparsers.add_parser(
        "status",
        help="Show workspace status with all repos",
    )
    ws_status.add_argument(
        "--path",
        help="Path to workspace (default: auto-discover)",
    )

    # -------------------------------------------------
    # gradient repo init/list
    # -------------------------------------------------
    repo_parser = subparsers.add_parser(
        "repo",
        help="Repo management commands",
    )
    repo_subparsers = repo_parser.add_subparsers(dest="repo_command", required=True)
    
    repo_init = repo_subparsers.add_parser(
        "init",
        help="Initialize a new repo in the workspace",
    )
    repo_init.add_argument(
        "name",
        help="Repo name (will be used as directory name)",
    )
    repo_init.add_argument(
        "--description", "-d",
        help="Description of the model/repo",
    )
    
    repo_list = repo_subparsers.add_parser(
        "list",
        help="List all repos in the workspace",
    )
    repo_list.add_argument(
        "--path",
        help="Path to workspace (default: auto-discover)",
    )

    # -------------------------------------------------
    # gradient status
    # -------------------------------------------------
    subparsers.add_parser(
        "status",
        help="Show current repo status",
    )

    # -------------------------------------------------
    # gradient login
    # -------------------------------------------------
    login = subparsers.add_parser(
        "login",
        help="Verify and store an access token for CLI API calls",
    )
    login.add_argument(
        "--token",
        help="Access token (optional; prompt if omitted)",
    )
    login.add_argument(
        "--verify-url",
        help="Token verify endpoint URL override (default: production, env: GRADIENT_AUTH_VERIFY_URL)",
    )

    # -------------------------------------------------
    # gradient resume
    # -------------------------------------------------
    resume = subparsers.add_parser(
        "resume",
        help="Resume training from a checkpoint",
    )
    resume.add_argument("ref", help="Checkpoint reference (e.g., main@100 or latest)")

    # -------------------------------------------------
    # gradient fork
    # -------------------------------------------------
    fork = subparsers.add_parser(
        "fork",
        help="Fork a new branch from a checkpoint",
    )
    fork.add_argument("from_ref", help="Source checkpoint reference")
    fork.add_argument("new_branch", help="Name for the new branch")
    fork.add_argument("--reset-optimizer", action="store_true", help="Reset optimizer state")
    fork.add_argument("--seed", type=int, help="Reset RNG with this seed")

    args = parser.parse_args(cli_argv)

    # -------------------------------------------------
    # Route to handlers
    # -------------------------------------------------
    
    if args.command == "workspace":
        if args.ws_command == "init":
            cmd_workspace_init(args)
        elif args.ws_command == "status":
            cmd_workspace_status(args)
        return

    if args.command == "repo":
        if args.repo_command == "init":
            cmd_repo_init(args)
        elif args.repo_command == "list":
            cmd_repo_list(args)
        return

    if args.command == "status":
        cmd_status(args)
        return

    if args.command == "login":
        cmd_login(args)
        return

    # -------------------------------------------------
    # Commands that set up env for training
    # -------------------------------------------------
    
    if args.command == "resume":
        cmd_resume(args)
    elif args.command == "fork":
        cmd_fork(args)

    # Execute chained command if provided
    if exec_cmd:
        print()
        print("→ Launching training:")
        print("  ", " ".join(exec_cmd))
        os.execvp(exec_cmd[0], exec_cmd)
    else:
        print()
        print("→ Run your training script:")
        print("   python train.py")


if __name__ == "__main__":
    main()
