import os
from typing import Dict, Optional

import torch
import torch.nn as nn

from gradient.core.training_state import (
    AMPStateComponent,
    DistributedStateComponent,
    ExternalStateComponent,
    ModelStateComponent,
    OptimizerStateComponent,
    RNGStateComponent,
    SchedulerStateComponent,
    StateComponent,
    TrainingState,
)

class CheckPointEngine:
    """Anchor/delta checkpoint engine."""

    def __init__(
        self,
        model,
        optimizer,
        scheduler=None,
        amp_scaler=None,
        external_state_getter=None,
        external_state_setter=None,
        external_state_default=None,
        external_state_version=None,
        state_components: Optional[Dict[str, StateComponent]] = None,
        ckpt_dir="checkpoints",
        delta_optimizer=True,
        reanchor_interval=None,
        compress_deltas=False,
        delta_threshold=0.0,
        strict_resume=False,
    ):
        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.amp_scaler = amp_scaler
        self.external_state_getter = external_state_getter
        self.external_state_setter = external_state_setter
        self.external_state_default = external_state_default
        self.external_state_version = external_state_version

        self.ckpt_dir = ckpt_dir
        os.makedirs(self.ckpt_dir, exist_ok=True)

        self.anchor_id = None
        self.delta_optimizer = delta_optimizer

        self.reanchor_interval = reanchor_interval
        self._deltas_since_anchor = 0

        self.compress_deltas = bool(compress_deltas)
        self.delta_threshold = float(delta_threshold)
        self.strict_resume = bool(strict_resume)
        self._components = state_components or self._build_default_components()

    def _build_default_components(self) -> Dict[str, StateComponent]:
        return {
            "model": ModelStateComponent(
                self.model,
                compress_tensor=self._compress_tensor,
                decompress_tensor=self._decompress_tensor,
            ),
            "optimizer": OptimizerStateComponent(
                self.optimizer,
                delta_enabled=self.delta_optimizer,
                compress_tensor=self._compress_tensor,
                decompress_tensor=self._decompress_tensor,
            ),
            "scheduler": SchedulerStateComponent(self.scheduler),
            "rng": RNGStateComponent(),
            "amp": AMPStateComponent(self.amp_scaler),
            "distributed": DistributedStateComponent(),
            "external": ExternalStateComponent(
                state_getter=self.external_state_getter,
                state_setter=self.external_state_setter,
                default=self.external_state_default,
                version=self.external_state_version,
            ),
        }

    def _training_state(self) -> TrainingState:
        return TrainingState(components=self._components)

    def _make_id(self, branch, step):
        return f"{branch}_s{step}"

    def _rank_suffix(self):
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            return f"_rank{torch.distributed.get_rank()}"
        return ""

    def _path_from_id(self, ckpt_id):
        suffix = self._rank_suffix()
        return os.path.join(self.ckpt_dir, f"ckpt_{ckpt_id}{suffix}.pt")

    def _ckpt_path(self, branch, step):
        return self._path_from_id(self._make_id(branch, step))

    def _resolve_ckpt_path(self, checkpoint_ref=None, branch=None, step=None):
        if checkpoint_ref is not None:
            if os.path.isfile(checkpoint_ref):
                return checkpoint_ref
            return self._path_from_id(checkpoint_ref)

        if branch is not None and step is not None:
            return self._ckpt_path(branch, step)

        raise ValueError("Must provide checkpoint_ref or (branch, step) to locate a checkpoint.")

    def _compress_tensor(self, delta: torch.Tensor):
        """Compress a delta tensor for storage."""
        if not self.compress_deltas:
            return delta

        delta_cpu = delta.detach().cpu()

        if self.delta_threshold > 0.0:
            mask = delta_cpu.abs() > self.delta_threshold
            nnz = int(mask.sum().item())
            if nnz == 0:
                return {
                    "__compressed__": True,
                    "scheme": "zeros",
                    "shape": delta_cpu.shape,
                }
            indices = mask.nonzero(as_tuple=False).int()
            values = delta_cpu[mask].to(torch.float16)

            return {
                "__compressed__": True,
                "scheme": "sparse_fp16",
                "shape": delta_cpu.shape,
                "indices": indices,
                "values": values,
            }
        return {
            "__compressed__": True,
            "scheme": "fp16",
            "shape": delta_cpu.shape,
            "values": delta_cpu.to(torch.float16),
        }

    def _decompress_tensor(self, anchor_tensor: torch.Tensor, blob):
        """Decompress a stored delta tensor."""
        if not isinstance(blob, dict) or not blob.get("__compressed__", False):
            return blob

        scheme = blob["scheme"]
        shape = tuple(blob["shape"])
        device = anchor_tensor.device
        dtype = anchor_tensor.dtype

        if scheme == "zeros":
            return torch.zeros(shape, device=device, dtype=dtype)

        if scheme == "fp16":
            vals = blob["values"].to(device=device, dtype=torch.float16)
            return vals.to(dtype=dtype).view(shape)

        if scheme == "sparse_fp16":
            full = torch.zeros(shape, device=device, dtype=dtype)
            idx = blob["indices"].to(device=device, dtype=torch.long)
            vals = blob["values"].to(device=device, dtype=torch.float16).to(dtype=dtype)
            full[tuple(idx.t())] = vals
            return full

        raise ValueError(f"Unknown compression scheme: {scheme}")

    def _capture_state(self, step, branch, message, meta_extra=None):
        """Capture full training state."""
        training_state = self._training_state()

        meta = {
            "branch": branch,
            "message": message,
        }
        if self.external_state_version is not None:
            meta["external_version"] = self.external_state_version
        if meta_extra:
            meta.update(meta_extra)

        state = training_state.state_dict()
        return {"step": step, **state, "meta": meta}

    def _reset_optimizer_state(self):
        self.optimizer.state = {}

    def _reset_scheduler_state(self):
        if not self.scheduler:
            return
        if hasattr(self.scheduler, "last_epoch"):
            self.scheduler.last_epoch = -1
        if hasattr(self.scheduler, "_step_count"):
            self.scheduler._step_count = 0

    def commit(self, step, branch="main", message="", force_new_anchor=False, meta_extra=None):
        """Save an anchor or delta checkpoint."""
        ckpt_id = self._make_id(branch, step)
        path = self._ckpt_path(branch, step)
        meta = {"ckpt_id": ckpt_id}
        if meta_extra:
            meta.update(meta_extra)
        state = self._capture_state(step, branch, message, meta_extra=meta)

        need_new_anchor = (
            self.anchor_id is None
            or force_new_anchor
            or (
                self.reanchor_interval is not None
                and self._deltas_since_anchor >= self.reanchor_interval
            )
        )

        if need_new_anchor:
            is_delta = False
            anchor_id = ckpt_id
            self.anchor_id = anchor_id
            self._deltas_since_anchor = 0

            payload = {
                "data": state,
                "is_delta": is_delta,
                "anchor_id": anchor_id,
                "anchor_path": path,
            }
            torch.save(payload, path)
            print(f"[CKPT] Saved anchor checkpoint at step {step} → {path}")
            return path

        anchor_path = self._path_from_id(self.anchor_id)
        anchor_ckpt = torch.load(anchor_path, map_location="cpu", weights_only=False)
        anchor_data = anchor_ckpt["data"]

        delta_state = {"step": state["step"], "meta": state.get("meta")}
        for name, component in self._components.items():
            if name in state and name in anchor_data:
                delta_state[name] = component.diff(anchor_data[name], state[name])
            elif name in state:
                delta_state[name] = state[name]

        payload = {
            "data": delta_state,
            "is_delta": True,
            "anchor_id": self.anchor_id,
            "anchor_path": anchor_path,
        }
        torch.save(payload, path)

        self._deltas_since_anchor += 1

        print(f"[CKPT] Saved DELTA checkpoint at step {step} → {path} (anchor={self.anchor_id})")
        return path

    def create_lora_fork(self, rank=8):
        """LoRA fork stub."""
        print("Preparing model for LoRA-style fork (stub)...")

        for name, module in self.model.named_modules():
            if isinstance(module, nn.Linear):
                module.weight.requires_grad = False

        trainable = [p for p in self.model.parameters() if p.requires_grad]
        if not trainable:
            print("Warning: no trainable params after LoRA fork.")
        self.optimizer = torch.optim.Adam(trainable, lr=1e-4)
        return "LoRA fork (stub) complete."

    def fork_into(
        self,
        checkpoint_ref=None,
        *,
        branch=None,
        step=None,
        new_branch="fork",
        new_step=None,
        message="",
        map_location=None,
        reset_optimizer_state=False,
        reset_scheduler_state=False,
        reset_rng_seed=None,
    ):
        """Fork training from an existing checkpoint."""
        path = self._resolve_ckpt_path(
            checkpoint_ref=checkpoint_ref, branch=branch, step=step
        )
        if not os.path.exists(path):
            raise FileNotFoundError(f"Checkpoint not found: {path}")

        parent_id = None
        try:
            parent_payload = torch.load(path, map_location="cpu", weights_only=False)
            parent_meta = parent_payload.get("data", {}).get("meta", {})
            parent_id = parent_meta.get("ckpt_id")
        except Exception:
            parent_id = None
        if not parent_id:
            base = os.path.basename(path)
            if base.startswith("ckpt_") and base.endswith(".pt"):
                parent_id = base[len("ckpt_") : -len(".pt")]

        loaded_step = self.resume(path, map_location=map_location)

        if reset_optimizer_state:
            self._reset_optimizer_state()
            if self.amp_scaler is not None:
                self.amp_scaler = torch.cuda.amp.GradScaler()

        if reset_scheduler_state:
            self._reset_scheduler_state()

        if reset_rng_seed is not None:
            torch.manual_seed(int(reset_rng_seed))
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(int(reset_rng_seed))

        fork_step = loaded_step if new_step is None else new_step
        return self.commit(
            step=fork_step,
            branch=new_branch,
            message=message,
            force_new_anchor=True,
            meta_extra={"parent_id": parent_id},
        )

    def fork_from(self, *args, **kwargs):
        """Backward-compatible alias."""
        return self.fork_into(*args, **kwargs)

    def resume(self, checkpoint_path, map_location=None):
        """Restore state from a checkpoint."""
        ckpt = torch.load(checkpoint_path, map_location=map_location, weights_only=False)
        data = ckpt["data"]
        is_delta = ckpt["is_delta"]
        anchor_id = ckpt["anchor_id"]
        anchor_path = ckpt.get("anchor_path")

        full_state = {}
        if not is_delta:
            for name in self._components.keys():
                if name in data:
                    full_state[name] = data[name]
        else:
            resolved_anchor_path = anchor_path or self._path_from_id(anchor_id)
            if not os.path.exists(resolved_anchor_path) and anchor_path:
                resolved_anchor_path = os.path.join(
                    self.ckpt_dir, os.path.basename(anchor_path)
                )
            anchor_ckpt = torch.load(resolved_anchor_path, map_location=map_location, weights_only=False)
            anchor_data = anchor_ckpt["data"]
            if anchor_ckpt["is_delta"]:
                raise ValueError("Anchor checkpoint must be full, but is a delta.")

            for name, component in self._components.items():
                if name in data and name in anchor_data:
                    full_state[name] = component.apply(anchor_data[name], data[name])
                elif name in data:
                    full_state[name] = data[name]
                elif name in anchor_data:
                    full_state[name] = anchor_data[name]

        training_state = self._training_state()
        training_state.load_state_dict(full_state, strict=self.strict_resume)

        if not is_delta:
            self.anchor_id = anchor_id
            self._deltas_since_anchor = 0

        print(f"[CKPT] Resumed at step {data['step']} (delta={is_delta}, anchor_id={anchor_id})")
        return data["step"]
