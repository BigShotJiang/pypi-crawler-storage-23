import random
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional, Protocol

import torch


class StateComponent(Protocol):
    def state_dict(self) -> Any:
        ...

    def load_state_dict(self, state: Any) -> None:
        ...

    def diff(self, anchor: Any, current: Any) -> Any:
        ...

    def apply(self, anchor: Any, delta: Any) -> Any:
        ...


@dataclass
class TrainingState:
    components: Dict[str, StateComponent] = field(default_factory=dict)

    def state_dict(self) -> Dict[str, Any]:
        return {name: component.state_dict() for name, component in self.components.items()}

    def load_state_dict(self, state: Dict[str, Any], *, strict: bool = True) -> None:
        missing = []
        for name, component in self.components.items():
            if name not in state:
                missing.append(name)
                continue
            component.load_state_dict(state[name])
        if strict and missing:
            raise KeyError(f"Missing state for components: {', '.join(missing)}")


def diff_state_dict(
    current: Dict[str, Any],
    anchor: Dict[str, Any],
    *,
    compress_tensor: Optional[Callable[[torch.Tensor], Any]] = None,
) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k, v in current.items():
        if k not in anchor:
            out[k] = v
            continue
        anchor_v = anchor[k]
        if isinstance(v, dict):
            out[k] = diff_state_dict(
                v,
                anchor_v,
                compress_tensor=compress_tensor,
            )
            continue
        if torch.is_tensor(v):
            anchor_t = anchor_v

            # Anchor snapshots are typically on CPU
            if anchor_t.device != v.device:
                anchor_t = anchor_t.to(v.device)

            raw_delta = v - anchor_t
            out[k] = compress_tensor(raw_delta) if compress_tensor else raw_delta
            continue
        out[k] = v
    return out


def apply_delta_dict(
    anchor: Dict[str, Any],
    delta: Dict[str, Any],
    *,
    decompress_tensor: Optional[Callable[[torch.Tensor, Any], torch.Tensor]] = None,
) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k, v in delta.items():
        if k not in anchor:
            out[k] = v
            continue
        anchor_v = anchor[k]
        if isinstance(v, torch.Tensor):
            out[k] = anchor_v + v
        elif isinstance(v, dict) and v.get("__compressed__", False) and decompress_tensor:
            delta_tensor = decompress_tensor(anchor_v, v)
            out[k] = anchor_v + delta_tensor
        elif isinstance(v, dict):
            out[k] = apply_delta_dict(anchor_v, v, decompress_tensor=decompress_tensor)
        else:
            out[k] = v
    return out


class ModelStateComponent:
    def __init__(self, model, *, compress_tensor=None, decompress_tensor=None):
        self.model = model
        self.compress_tensor = compress_tensor
        self.decompress_tensor = decompress_tensor

    def state_dict(self):
        return self.model.state_dict()

    def load_state_dict(self, state):
        self.model.load_state_dict(state)

    def diff(self, anchor, current):
        return diff_state_dict(current, anchor, compress_tensor=self.compress_tensor)

    def apply(self, anchor, delta):
        return apply_delta_dict(anchor, delta, decompress_tensor=self.decompress_tensor)


class OptimizerStateComponent:
    def __init__(self, optimizer, *, delta_enabled=False, compress_tensor=None, decompress_tensor=None):
        self.optimizer = optimizer
        self.delta_enabled = delta_enabled
        self.compress_tensor = compress_tensor
        self.decompress_tensor = decompress_tensor

    def state_dict(self):
        return self.optimizer.state_dict()

    def load_state_dict(self, state):
        self.optimizer.load_state_dict(state)

    def diff(self, anchor, current):
        if not self.delta_enabled:
            return current
        return diff_state_dict(current, anchor, compress_tensor=self.compress_tensor)

    def apply(self, anchor, delta):
        if not self.delta_enabled:
            return delta
        return apply_delta_dict(anchor, delta, decompress_tensor=self.decompress_tensor)


class SchedulerStateComponent:
    def __init__(self, scheduler):
        self.scheduler = scheduler

    def state_dict(self):
        return self.scheduler.state_dict() if self.scheduler else None

    def load_state_dict(self, state):
        if self.scheduler is None or state is None:
            return
        self.scheduler.load_state_dict(state)

    def diff(self, anchor, current):
        return current

    def apply(self, anchor, delta):
        return delta


class RNGStateComponent:
    def state_dict(self):
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            if torch.distributed.get_rank() != 0:
                return None
        return {
            "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
            "python": random.getstate(),
        }

    def load_state_dict(self, state):
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            obj_list = [state] if torch.distributed.get_rank() == 0 else [None]
            torch.distributed.broadcast_object_list(obj_list, src=0)
            state = obj_list[0]
        if not state:
            return
        torch_state = state.get("torch")
        if torch_state is not None:
            torch.set_rng_state(torch_state)
        cuda_state = state.get("cuda")
        if torch.cuda.is_available() and cuda_state is not None:
            torch.cuda.set_rng_state_all(cuda_state)
        python_state = state.get("python")
        if python_state is not None:
            random.setstate(python_state)

    def diff(self, anchor, current):
        return current

    def apply(self, anchor, delta):
        return delta


class AMPStateComponent:
    def __init__(self, scaler):
        self.scaler = scaler

    def state_dict(self):
        return self.scaler.state_dict() if self.scaler else None

    def load_state_dict(self, state):
        if self.scaler is None or state is None:
            return
        self.scaler.load_state_dict(state)

    def diff(self, anchor, current):
        return current

    def apply(self, anchor, delta):
        return delta


class DistributedStateComponent:
    def state_dict(self):
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            return {
                "rank": torch.distributed.get_rank(),
                "world_size": torch.distributed.get_world_size(),
            }
        return None

    def load_state_dict(self, state):
        if state is None:
            return
        if not torch.distributed.is_available() or not torch.distributed.is_initialized():
            raise ValueError("Distributed state found but torch.distributed is not initialized.")
        current_world_size = torch.distributed.get_world_size()
        saved_world_size = state.get("world_size")
        if saved_world_size is not None and saved_world_size != current_world_size:
            raise ValueError(
                f"World size mismatch: checkpoint={saved_world_size} current={current_world_size}"
            )
        current_rank = torch.distributed.get_rank()
        saved_rank = state.get("rank")
        if saved_rank is not None and saved_rank != current_rank:
            raise ValueError(f"Rank mismatch: checkpoint={saved_rank} current={current_rank}")

    def diff(self, anchor, current):
        return current

    def apply(self, anchor, delta):
        return delta


class ExternalStateComponent:
    def __init__(
        self,
        state_getter: Optional[Callable[[], Any]] = None,
        state_setter: Optional[Callable[[Any], None]] = None,
        default: Any = None,
        version: Optional[str] = None,
    ):
        self.state_getter = state_getter
        self.state_setter = state_setter
        self.default = default
        self.version = version

    def state_dict(self):
        if self.state_getter:
            payload = self.state_getter()
        else:
            payload = self.default
        return {"version": self.version, "state": payload}

    def load_state_dict(self, state):
        if state is None:
            return
        if isinstance(state, dict) and "version" in state:
            state_version = state.get("version")
            if self.version is not None and state_version != self.version:
                raise ValueError(
                    f"External state version mismatch: checkpoint={state_version} current={self.version}"
                )
            payload = state.get("state")
        else:
            payload = state
        if self.state_setter and payload is not None:
            self.state_setter(payload)

    def diff(self, anchor, current):
        return current

    def apply(self, anchor, delta):
        return delta


ModelComponent = ModelStateComponent
OptimizerComponent = OptimizerStateComponent
SchedulerComponent = SchedulerStateComponent
RNGComponent = RNGStateComponent
AMPComponent = AMPStateComponent
