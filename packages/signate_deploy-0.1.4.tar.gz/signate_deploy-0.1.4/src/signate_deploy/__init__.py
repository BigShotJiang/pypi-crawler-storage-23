"""signate-deploy: GitHub Actions経由でSIGNATEコンペを自動化するCLIツール"""

__version__ = "0.1.4"
