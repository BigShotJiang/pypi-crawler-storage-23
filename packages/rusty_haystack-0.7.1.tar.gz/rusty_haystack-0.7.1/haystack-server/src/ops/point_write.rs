//! The `pointWrite` op — write a value to a writable point.
//!
//! # Overview
//!
//! `POST /api/pointWrite` writes a value to one or more writable point
//! entities. Each row represents a write command. The entity must carry
//! the `writable` marker tag.
//!
//! # Request Grid Columns
//!
//! | Column  | Kind   | Description                                     |
//! |---------|--------|-------------------------------------------------|
//! | `id`    | Ref    | Writable point entity reference                 |
//! | `level` | Number | Priority level 1–17 (default 17 if omitted)     |
//! | `val`   | *any*  | Value to write                                  |
//!
//! # Response
//!
//! Empty grid on success.
//!
//! # Errors
//!
//! - **400 Bad Request** — `level` outside 1–17, entity not `writable`, write
//!   failed, or request decode failure.
//! - **404 Not Found** — entity not in local graph and not owned by any
//!   federation connector.
//! - **500 Internal Server Error** — federation proxy or encoding error.

use actix_web::{HttpRequest, HttpResponse, web};

use haystack_core::data::{HDict, HGrid};
use haystack_core::kinds::Kind;

use crate::content;
use crate::error::HaystackError;
use crate::state::AppState;

/// POST /api/pointWrite
///
/// Request grid has `id`, `level`, and `val` columns.
/// Writes the value to the entity in the graph as a simple curVal update.
pub async fn handle(
    req: HttpRequest,
    body: String,
    state: web::Data<AppState>,
) -> Result<HttpResponse, HaystackError> {
    let content_type = req
        .headers()
        .get("Content-Type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");
    let accept = req
        .headers()
        .get("Accept")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");

    let request_grid = content::decode_request_grid(&body, content_type)
        .map_err(|e| HaystackError::bad_request(format!("failed to decode request: {e}")))?;

    for row in request_grid.rows.iter() {
        let ref_val = match row.get("id") {
            Some(Kind::Ref(r)) => r.val.clone(),
            _ => continue,
        };

        let level = match row.get("level") {
            Some(Kind::Number(n)) => n.val as u32,
            _ => 17, // Default level
        };

        if !(1..=17).contains(&level) {
            return Err(HaystackError::bad_request(format!(
                "level must be between 1 and 17, got {level}"
            )));
        }

        // Check federation: if entity is not in local graph, proxy to remote.
        if !state.graph.contains(&ref_val) {
            if let Some(connector) = state.federation.owner_of(&ref_val) {
                let val = row.get("val").cloned().unwrap_or(Kind::Null);
                connector
                    .proxy_point_write(&ref_val, level as u8, &val)
                    .await
                    .map_err(|e| HaystackError::internal(format!("federation proxy error: {e}")))?;
                continue;
            }
            return Err(HaystackError::not_found(format!(
                "entity not found: {ref_val}"
            )));
        }

        // Check that the target entity has the `writable` marker tag
        let entity = state
            .graph
            .get(&ref_val)
            .ok_or_else(|| HaystackError::not_found(format!("entity not found: {ref_val}")))?;
        if !entity.has("writable") {
            return Err(HaystackError::bad_request(format!(
                "entity '{ref_val}' is not writable"
            )));
        }

        // Get the value to write
        if let Some(val) = row.get("val") {
            // Simple implementation: update the entity's curVal tag at the given level
            let mut changes = HDict::new();
            changes.set("curVal", val.clone());
            changes.set(
                "writeLevel",
                Kind::Number(haystack_core::kinds::Number::unitless(level as f64)),
            );
            state
                .graph
                .update(&ref_val, changes)
                .map_err(|e| HaystackError::bad_request(format!("write failed: {e}")))?;
        }
    }

    // Return empty grid on success
    let grid = HGrid::new();
    let (encoded, ct) = content::encode_response_grid(&grid, accept)
        .map_err(|e| HaystackError::internal(format!("encoding error: {e}")))?;

    Ok(HttpResponse::Ok().content_type(ct).body(encoded))
}
