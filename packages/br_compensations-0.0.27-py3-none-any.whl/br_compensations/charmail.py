
class CharacterMailService():
    '''
        Сервис обработки ингейм почты персонажа
    '''
    pass