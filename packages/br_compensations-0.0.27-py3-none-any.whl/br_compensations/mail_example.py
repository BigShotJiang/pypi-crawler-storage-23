"""
Пример использования сервиса EveMailService для работы с почтой персонажа EVE Online.

Для работы этого примера необходимо:
1. Пользователь должен авторизоваться через EVE SSO с скоупом esi-mail.read_mail.v1
2. В базе данных должен быть токен для персонажа с нужным скоупом
"""

from .services import EveMailService


def example_get_character_mails(character_id: int):
    """
    Пример получения всех писем персонажа с содержимым
    
    Args:
        character_id: ID персонажа
    """
    print(f"=== Получение писем для персонажа {character_id} ===\n")
    
    # Получаем все письма (максимум 20)
    mails = EveMailService.get_character_mails(
        character_id=character_id,
        limit=20,
        unread_only=False
    )
    
    print(f"Получено {len(mails)} писем\n")
    
    for mail in mails:
        print(f"--- Письмо #{mail.get('mail_id')} ---")
        print(f"Тема: {mail.get('subject')}")
        print(f"От: {mail.get('from')}")
        print(f"Дата: {mail.get('timestamp')}")
        print(f"Прочитано: {'Да' if mail.get('is_read') else 'Нет'}")
        print(f"Содержимое:\n{mail.get('body', '<Нет содержимого>')}")
        print()


def example_get_unread_mails(character_id: int):
    """
    Пример получения только непрочитанных писем
    
    Args:
        character_id: ID персонажа
    """
    print(f"=== Получение непрочитанных писем для персонажа {character_id} ===\n")
    
    # Получаем только непрочитанные письма
    mails = EveMailService.get_character_mails(
        character_id=character_id,
        limit=10,
        unread_only=True
    )
    
    print(f"Получено {len(mails)} непрочитанных писем\n")
    
    for mail in mails:
        print(f"--- Письмо #{mail.get('mail_id')} ---")
        print(f"Тема: {mail.get('subject')}")
        print(f"От: {mail.get('from')}")
        print(f"Дата: {mail.get('timestamp')}")
        print()


def example_get_mail_list_only(character_id: int):
    """
    Пример получения только списка писем (без содержимого)
    Это быстрее, так как не делает дополнительные запросы для каждого письма
    
    Args:
        character_id: ID персонажа
    """
    print(f"=== Получение списка писем для персонажа {character_id} ===\n")
    
    # Сначала получаем токен
    token = EveMailService.get_token_for_character(character_id)
    
    if not token:
        print("Не найден токен для персонажа или токен не имеет нужных скоупов")
        return
    
    # Получаем только список писем (метаданные)
    mail_list = EveMailService.get_character_mail_list(
        character_id=character_id,
        token=token
    )
    
    print(f"Получено {len(mail_list)} писем\n")
    
    for mail in mail_list:
        print(f"ID: {mail.get('mail_id')}")
        print(f"Тема: {mail.get('subject')}")
        print(f"От: {mail.get('from')}")
        print(f"Дата: {mail.get('timestamp')}")
        print(f"Прочитано: {'Да' if mail.get('is_read') else 'Нет'}")
        print()


def example_get_specific_mail(character_id: int, mail_id: int):
    """
    Пример получения содержимого конкретного письма
    
    Args:
        character_id: ID персонажа
        mail_id: ID письма
    """
    print(f"=== Получение письма #{mail_id} для персонажа {character_id} ===\n")
    
    # Сначала получаем токен
    token = EveMailService.get_token_for_character(character_id)
    
    if not token:
        print("Не найден токен для персонажа или токен не имеет нужных скоупов")
        return
    
    # Получаем содержимое письма
    mail = EveMailService.get_mail_content(
        character_id=character_id,
        mail_id=mail_id,
        token=token
    )
    
    print(f"Тема: {mail.get('subject')}")
    print(f"От: {mail.get('from')}")
    print(f"Дата: {mail.get('timestamp')}")
    print(f"Прочитано: {'Да' if mail.get('is_read') else 'Нет'}")
    print(f"Получатели: {mail.get('recipients', [])}")
    print(f"Метки: {mail.get('labels', [])}")
    print(f"\nСодержимое:\n{mail.get('body', '<Нет содержимого>')}")


# Примеры использования в Django view
def example_django_view(request):
    """
    Пример использования в Django view
    
    Args:
        request: Django request объект
    """
    from allianceauth.eveonline.models import EveCharacter
    
    # Получаем персонажа текущего пользователя
    character = EveCharacter.objects.filter(
        character_ownership__user=request.user
    ).first()
    
    if not character:
        return {"error": "У пользователя нет персонажа"}
    
    # Получаем письма персонажа
    mails = EveMailService.get_character_mails(
        character_id=character.character_id,
        limit=10,
        unread_only=False
    )
    
    return {
        "character": character.character_name,
        "mails_count": len(mails),
        "mails": mails
    }


# Пример использования в Celery task
def example_celery_task(character_id: int):
    """
    Пример использования в Celery task для фонового получения писем
    
    Args:
        character_id: ID персонажа
    """
    from allianceauth.services.hooks import get_extension_logger
    
    logger = get_extension_logger(__name__)
    
    try:
        # Получаем письма персонажа
        mails = EveMailService.get_character_mails(
            character_id=character_id,
            limit=50,
            unread_only=False
        )
        
        logger.info(f"Получено {len(mails)} писем для персонажа {character_id}")
        
        # Здесь можно добавить логику обработки писем
        # Например, сохранение в базу данных, отправка уведомлений и т.д.
        
        return {
            "success": True,
            "mails_count": len(mails)
        }
        
    except Exception as e:
        logger.error(f"Ошибка при получении писем для персонажа {character_id}: {e}")
        return {
            "success": False,
            "error": str(e)
        }


if __name__ == "__main__":
    # Пример запуска (только для тестирования)
    # Замените character_id на реальный ID персонажа
    CHARACTER_ID = 12345678  # Замените на реальный ID
    
    print("Выберите пример для запуска:")
    print("1. Получить все письма с содержимым")
    print("2. Получить только непрочитанные письма")
    print("3. Получить только список писем (без содержимого)")
    print("4. Получить конкретное письмо")
    
    # Для примера запустим первый вариант
    # example_get_character_mails(CHARACTER_ID)
