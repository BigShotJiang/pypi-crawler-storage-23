import datetime
import re
from typing import List

from celery import shared_task
from django.db import transaction

from .models import BattleReport, CharMailParse
from django.utils import timezone
from allianceauth.services.hooks import get_extension_logger
from .services import BattleReportsService
from br_compensations.models import BattleReport
from allianceauth.eveonline.models import EveCharacter

logger = get_extension_logger(__name__)

# Конфигурация
MAX_RETRIES = 3
BATCH_SIZE = 5
BACKOFF_SCHEDULE = [1, 5, 15]  # Минуты для экспоненциального бэк-оффа
PROCESSING_TIMEOUT = 300  # 5 минут на обработку

@shared_task(bind=True)
def process_queued_links(self):
    """
    Обрабатывает отложенные ссылки из очереди.
    Использует блокировку записей для предотвращения обработки одной ссылки несколькими воркерами.
    """
    logger.info('Запускается обработка новых ссылок...')
    start_time = timezone.now()
    logger.info('Поиск новых ссылок...')
    reports = BattleReport.objects.exclude(status = BattleReport.PROCESS_COMPLETE).all()
    logger.info(f'Количество ссылок для обработки: {len(reports)}.')
    processed_count = 0
    failed_count = 0
    
    try:
        with transaction.atomic():
            # Блокируем записи для обработки (используем select_for_update)
            # Фильтруем записи со статусом PENDING, у которых время следующей попытки уже наступило
            start_time = timezone.now()
            queue_items = reports.select_for_update(skip_locked=True)[
                :BATCH_SIZE  # Ограничиваем количество обрабатываемых за раз
            ] 
            
            for item in queue_items:
                try:
                    logger.info(f'Обработка ссыли: {item}')
                    killmails = BattleReportsService.process(item)
                    logger.info(f'Количество найденных киллмэйлов: {len(killmails) if not killmails == None else 0}.')
                    count = len(killmails)
                    if not count or count == None:
                        count = 0
                    if count > 0:
                        # Успех - помечаем как завершенную
                        logger.info('Помечаем ссылку как обработанную.')
                        item.status = BattleReport.PROCESS_COMPLETE
                        item.save() 
                        processed_count += 1
                    else:
                        # Нет целевых киллов, но данные получены
                        logger.info('Помечаем ссылку как обработанную.')
                        item.status = BattleReport.PROCESS_COMPLETE
                        item.save() 
                        logger.info(f"No targeted kills found in {item.link}")
                
                except Exception as e:
                    logger.error(f'При обработке отчета произошла ошибка {e}',e)
                    item.status = BattleReport.PROCESS_FAILED
                    item.save()
                    
                # Прерываем обработку, если превышено время выполнения
                if (timezone.now() - start_time).total_seconds() > PROCESSING_TIMEOUT:
                    logger.info("Processing timeout reached, stopping batch")
                    break
    
    except Exception as e:
        logger.exception("Error in process_queued_links task")
        raise e
        
    return {
        "status": "completed",
        "processed_count": processed_count,
        "failed_count": failed_count,
        "duration": (timezone.now() - start_time).total_seconds()
    }

@shared_task
def cleanup_old_killmails():
    pass

@shared_task(bind=True)
def fetch_characters_mails(self):
    """Фоновая задача для получения писем персонажа"""
    
    for character in CharMailParse.objects.all():
        try:
            mailboxCharacter = EveCharacter.objects.get(character_id=character.character_id)
            # Получаем письма персонажа
            mails = EveMailService.get_character_mails(
                character_id=character.character_id,
                limit=10,
                unread_only=False
            )
            
            logger.info(f"Получено {len(mails)} писем для персонажа {mailboxCharacter.character_name}")
            killIDs = []
            
            if len(mails) > 0:
                for mail in mails:
                    logger.debug(mail)
                    pattern = r'<a\s+[^>]*href="([^"]*)"[^>]*>'
                    matches = re.findall(pattern, mail.get('body'))
                    if matches:
                        for match in matches:
                            parts = match.split(':')
                            if parts[0] == 'killReport':
                                killIDs.append(match.split(':')[1])
                                kill = match.split(':')[1]
                                try: 
                                    if not BattleReport.objects.filter(link = f'https://zkillboard.com/kill/{kill}/').exists():
                                        kill = BattleReport(
                                            link = f'https://zkillboard.com/kill/{kill}/',
                                            comment = f'Автоматически загружен из почтового ящика {mailboxCharacter.character_name}',
                                            status = BattleReport.PROCESS_NEW,
                                            report_type = BattleReport.KILLMAIL
                                        )
                                        kill.save()
                                        logger.info(f'Киллмэйл {kill} из почтового ящика персонажа {mailboxCharacter.character_name} добавлен на обработку')
                                    else:
                                        logger.info(f'Киллмэйл {kill} из почтового ящика персонажа {mailboxCharacter.character_name} не добавлен так как уже есть в базе данных')
                                except Exception as e:
                                    logger.error(e)
           
            character.updated_at = datetime.datetime.now()     
            character.save()
            
            return {
                "success": True,
                "mails_count": len(mails)
            }
            
        except Exception as e:
            logger.error(f"Ошибка при получении писем: {e}")
            raise
        