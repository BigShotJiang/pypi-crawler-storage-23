# pocket-tts-mcp

MCP server for streaming text-to-speech via [PocketTTS](https://github.com/KoljaB/PocketTTS). Speaks text out loud with near-instant playback — audio streams to speakers in ~200ms.

## Install

```bash
# Run directly (no install needed)
uvx pocket-tts-mcp

# Or install globally
pip install pocket-tts-mcp
```

## Claude Code integration

Add to your Claude Code MCP config:

```json
{
  "mcpServers": {
    "pockettts": {
      "command": "uvx",
      "args": ["pocket-tts-mcp"]
    }
  }
}
```

## Tools

### `speak(text, voice?)`
Queue text for playback. Returns immediately with a speech ID. Voices: `"male"` (default), `"female"`.

### `speech_status()`
Check how much audio is queued. Returns instantly.

### `await_speech(id?)`
Block until speech finishes. No args = wait for all. Pass an ID to wait for just that item.
