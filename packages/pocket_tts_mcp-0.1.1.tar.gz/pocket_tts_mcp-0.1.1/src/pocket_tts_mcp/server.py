"""PocketTTS MCP server — in-process streaming TTS via FastMCP.

Loads the PocketTTS model on CPU, streams PCM chunks to ffplay as
they're generated. No HTTP server, no temp files.
"""

import asyncio
import subprocess
import sys
import threading
from collections import deque
from typing import Optional

import numpy as np
from fastmcp import FastMCP
from pocket_tts import TTSModel

# ── Voice configuration ──────────────────────────────────────

VOICE_MAP = {
    "male": "alba",
    "female": "azelma",
}

VOICE_PREFIX = {
    "male": "... ",
    "female": "... ",
}

VOICE_TEMPO = {
    "male": 1.0,
    "female": 1.0,
}

DEFAULT_VOICE = "male"

# ── Constants ────────────────────────────────────────────────

FFPLAY_TIMEOUT_SECONDS = 300
AWAIT_TIMEOUT_SECONDS = 120.0
POLL_INTERVAL_SECONDS = 0.2
LEAD_IN_SILENCE_FRACTION = 5  # sample_rate // N → 200ms at N=5

# ── Model loading ────────────────────────────────────────────

print("[pocket-tts-mcp] Loading TTS model...", file=sys.stderr, flush=True)
model = TTSModel.load_model(eos_threshold=-4.0, lsd_decode_steps=1, temp=0.8)

print("[pocket-tts-mcp] Using CPU", file=sys.stderr, flush=True)

sample_rate = model.sample_rate

# Pre-compute voice states for both voices
print("[pocket-tts-mcp] Warming up voices...", file=sys.stderr, flush=True)
voice_states: dict[str, dict] = {}
for short_name, pockettts_name in VOICE_MAP.items():
    voice_states[short_name] = model.get_state_for_audio_prompt(pockettts_name)
print("[pocket-tts-mcp] Warmup complete.", file=sys.stderr, flush=True)

# ── Speech queue & tracking ──────────────────────────────────

speech_queue: deque[dict] = deque()
queued_word_count = 0
next_speech_id = 1
id_lock = threading.Lock()

# Map speech ID → asyncio.Event (set when that ID finishes playing)
speech_events: dict[int, asyncio.Event] = {}

drain_task: Optional[asyncio.Task] = None


def _play_streaming(text: str, voice_name: str) -> None:
    """Synthesize text and stream PCM chunks to ffplay (runs in thread)."""
    state = voice_states.get(voice_name, voice_states[DEFAULT_VOICE])
    prefix = VOICE_PREFIX.get(voice_name, ".")
    tempo = VOICE_TEMPO.get(voice_name, 0.9)

    proc = subprocess.Popen(
        [
            "ffplay",
            "-f", "s16le",
            "-ar", str(sample_rate),
            "-ch_layout", "mono",
            "-af", f"atempo={tempo}",
            "-nodisp",
            "-autoexit",
            "-loglevel", "quiet",
            "-i", "pipe:0",
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    try:
        # Lead-in silence so ffplay can initialize audio output before real audio
        silence = np.zeros(sample_rate // LEAD_IN_SILENCE_FRACTION, dtype=np.int16)
        proc.stdin.write(silence.tobytes())

        for chunk in model.generate_audio_stream(
            model_state=state,
            text_to_generate=f"{prefix}{text}",
            copy_state=True,
            frames_after_eos=6,
        ):
            pcm = (np.clip(chunk.numpy(), -1.0, 1.0) * 32767).astype(np.int16)
            proc.stdin.write(pcm.tobytes())
        proc.stdin.close()
        proc.wait(timeout=FFPLAY_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        print(
            f"[pocket-tts-mcp] ffplay timed out after {FFPLAY_TIMEOUT_SECONDS}s, killing",
            file=sys.stderr,
            flush=True,
        )
        proc.kill()
        proc.wait()
    except Exception as exc:
        print(
            f"[pocket-tts-mcp] Playback error: {exc}",
            file=sys.stderr,
            flush=True,
        )
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.kill()
        proc.wait()


async def _drain_playback() -> None:
    """Background task: dequeue items, play each, resolve waiters."""
    global queued_word_count

    while speech_queue:
        item = speech_queue.popleft()
        queued_word_count -= item["word_count"]

        await asyncio.to_thread(
            _play_streaming, item["text"], item["voice"]
        )

        # Signal completion and clean up event
        speech_id = item["id"]
        event = speech_events.pop(speech_id, None)
        if event:
            event.set()


def _enqueue_speech(text: str, voice: str, word_count: int) -> int:
    """Add text to the playback queue. Returns speech ID."""
    global next_speech_id, drain_task, queued_word_count

    with id_lock:
        speech_id = next_speech_id
        next_speech_id += 1

    event = asyncio.Event()
    speech_events[speech_id] = event

    speech_queue.append({
        "id": speech_id,
        "text": text,
        "voice": voice,
        "word_count": word_count,
    })
    queued_word_count += word_count

    # Start drain task if not already running
    if drain_task is None or drain_task.done():
        drain_task = asyncio.get_running_loop().create_task(_drain_playback())

    return speech_id


# ── MCP server ───────────────────────────────────────────────

mcp = FastMCP("pocket-tts-mcp")


@mcp.tool()
async def speak(text: str, voice: str = "male") -> str:
    """Speak text out loud using PocketTTS. Returns immediately with a speech ID. Audio streams to speakers in ~200ms."""
    word_count = len(text.split())
    speech_id = _enqueue_speech(text, voice, word_count)
    return f'Queued id={speech_id} [{voice}]: "{text}"'


@mcp.tool()
async def speech_status() -> str:
    """Check how much audio is queued. Returns instantly. Use this to decide whether to queue more speech, do browser actions, or wait."""
    pending = len(speech_queue)
    estimated_seconds = round(queued_word_count / 2.5)
    playing = drain_task is not None and not drain_task.done()
    status = "Playing now." if playing else "Silent."
    return f"Pending: {pending} items (~{estimated_seconds}s). {status}"


@mcp.tool()
async def await_speech(id: int | None = None) -> str:
    """Block until queued speech finishes playing. With no args, waits for ALL queued speech. With an id, waits for just that item (later items keep playing). Call at scene boundaries to sync audio with browser actions."""
    if id is not None:
        event = speech_events.get(id)
        if event is None:
            return f"Speech id={id} not found (already finished or never queued)."
        try:
            await asyncio.wait_for(event.wait(), timeout=AWAIT_TIMEOUT_SECONDS)
            return f"Speech id={id} finished."
        except asyncio.TimeoutError:
            return f"Timed out waiting for speech id={id}."

    # Wait for all queued speech
    deadline = AWAIT_TIMEOUT_SECONDS
    while (speech_queue or (drain_task and not drain_task.done())) and deadline > 0:
        await asyncio.sleep(POLL_INTERVAL_SECONDS)
        deadline -= POLL_INTERVAL_SECONDS
    if deadline <= 0:
        return "Timed out waiting for all speech."
    return "All speech finished."


def main() -> None:
    """Entry point for the pocket-tts-mcp command."""
    mcp.run()


if __name__ == "__main__":
    main()
