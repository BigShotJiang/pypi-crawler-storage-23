"""Allow running as `python -m pocket_tts_mcp`."""

from pocket_tts_mcp.server import main

main()
