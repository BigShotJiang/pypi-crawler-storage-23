"""PocketTTS MCP server — streaming text-to-speech via FastMCP."""
