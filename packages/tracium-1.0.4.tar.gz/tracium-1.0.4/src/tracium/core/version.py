"""
Version information for Tracium SDK.
"""

__version__ = "1.0.4"
