"""
Tests for core SDK components.
"""
