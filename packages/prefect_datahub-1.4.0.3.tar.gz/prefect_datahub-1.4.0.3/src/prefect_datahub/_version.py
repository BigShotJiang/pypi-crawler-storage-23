# Published at https://pypi.org/project/prefect-datahub/.
__package_name__ = "prefect-datahub"
__version__ = "1.4.0.3"
