"""NextToken SDK - Simple client for the NextToken Gateway."""

from .client import NextToken
from .email import Email
from .fetch import Fetch
from .integrations import Integrations
from .search import Search

__version__ = "0.5.0"
__all__ = ["NextToken", "Email", "Fetch", "Integrations", "Search", "__version__"]
