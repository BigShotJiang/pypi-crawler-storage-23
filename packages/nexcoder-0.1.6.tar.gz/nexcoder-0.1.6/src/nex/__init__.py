"""Nex AI — The Coding Agent That Remembers."""

__version__ = "v0.1.6"
__app_name__ = "nex"
