# Secret Detection

::: enforcecore.redactor.secrets.SecretScanner

::: enforcecore.redactor.secrets.DetectedSecret
