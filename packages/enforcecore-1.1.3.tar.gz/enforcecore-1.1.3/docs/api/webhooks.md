# Webhooks

::: enforcecore.plugins.webhooks.WebhookDispatcher

::: enforcecore.plugins.webhooks.WebhookEvent
