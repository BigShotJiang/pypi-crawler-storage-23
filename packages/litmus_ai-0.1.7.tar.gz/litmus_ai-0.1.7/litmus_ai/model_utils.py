import os
import warnings
import logging

# Suppress all HF/transformers warnings before any imports
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN_WARNING"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["TRANSFORMERS_NO_ADVISORY_WARNINGS"] = "true"
os.environ["HF_HUB_VERBOSITY"] = "error"
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"    # suppress "Loading weights" bar

# Silence Python warnings from transformers / huggingface_hub
warnings.filterwarnings("ignore", category=UserWarning, module="transformers")
warnings.filterwarnings("ignore", category=FutureWarning, module="transformers")
warnings.filterwarnings("ignore", category=UserWarning, module="huggingface_hub")

# Silence logging from huggingface_hub and transformers
logging.getLogger("transformers").setLevel(logging.ERROR)
logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
logging.getLogger("filelock").setLevel(logging.ERROR)

import torch
from typing import List

try:
    from transformers import AutoTokenizer, AutoModel, logging as transformers_logging
    transformers_logging.set_verbosity_error()
except ImportError:
    AutoTokenizer = None
    AutoModel = None


# ── Process-level singleton cache ────────────────────────────────────────────
# Key: (model_name, device, model_type)  →  Value: ModelManager instance
_MODEL_CACHE: dict = {}


class ModelManager:
    """
    Manages loading transformer models and tokenizers.
    Supports bi-encoders (embeddings) and cross-encoders (classification).

    Uses a process-level singleton cache so each unique (model, device, type)
    combination is loaded only ONCE per Python process. Subsequent instantiations
    return the already-loaded instance immediately with no disk I/O.
    """

    def __new__(cls, model_name: str, device: str = 'cpu', model_type: str = 'bi-encoder'):
        cache_key = (model_name, device, model_type)
        if cache_key in _MODEL_CACHE:
            return _MODEL_CACHE[cache_key]
        instance = super().__new__(cls)
        _MODEL_CACHE[cache_key] = instance
        return instance

    def __init__(self, model_name: str, device: str = 'cpu', model_type: str = 'bi-encoder'):
        # Guard: skip re-initialization if already loaded
        if getattr(self, '_initialized', False):
            return

        if AutoTokenizer is None or AutoModel is None:
            raise ImportError(
                "The 'transformers' library is required. "
                "Install it with: pip install transformers"
            )

        self.device = device
        self.model_type = model_type

        self.tokenizer = AutoTokenizer.from_pretrained(model_name)

        if model_type == 'cross-encoder':
            from transformers import AutoModelForSequenceClassification
            self.model = AutoModelForSequenceClassification.from_pretrained(
                model_name
            ).to(self.device)
        else:
            self.model = AutoModel.from_pretrained(model_name).to(self.device)

        self.model.eval()
        self._initialized = True

    # ── Inference methods ─────────────────────────────────────────────────────

    def embed_texts(self, texts: List[str]) -> torch.Tensor:
        """Embed a list of texts using mean pooling (bi-encoder only)."""
        if self.model_type != 'bi-encoder':
            raise ValueError("embed_texts is only available for bi-encoder models.")
        if not texts:
            return torch.tensor([]).to(self.device)

        inputs = self.tokenizer(
            texts, padding=True, truncation=True,
            max_length=512, return_tensors="pt"
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model(**inputs)
            embeddings = outputs.last_hidden_state
            attention_mask = inputs['attention_mask']
            mask_expanded = attention_mask.unsqueeze(-1).expand(embeddings.size()).float()
            sum_embeddings = torch.sum(embeddings * mask_expanded, dim=1)
            sum_mask = torch.clamp(mask_expanded.sum(dim=1), min=1e-9)
            emb = sum_embeddings / sum_mask

        return torch.nn.functional.normalize(emb, p=2, dim=1)

    def get_pooled_embedding(self, text1: str, text2: str) -> torch.Tensor:
        """Get pooled embedding for a text pair (cross-encoder only)."""
        if self.model_type != 'cross-encoder':
            raise ValueError("get_pooled_embedding is only available for cross-encoder models.")

        features = {}

        def hook_fn(module, input, output):
            features['pooled'] = input[0].detach()

        hook = self.model.classifier.register_forward_hook(hook_fn)
        inputs = self.tokenizer(
            text1, text2, return_tensors="pt", padding=True, truncation=True
        ).to(self.device)

        with torch.no_grad():
            _ = self.model(**inputs)

        hook.remove()
        return features['pooled'].squeeze()

    def get_probs(self, text1: str, text2: str) -> torch.Tensor:
        """Get classification probabilities for a text pair (cross-encoder only)."""
        if self.model_type != 'cross-encoder':
            raise ValueError("get_probs is available only for cross-encoder models.")

        inputs = self.tokenizer(
            text1, text2, return_tensors="pt", padding=True, truncation=True
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model(**inputs)
            probs = torch.nn.functional.softmax(outputs.logits, dim=-1).squeeze()

        return probs
