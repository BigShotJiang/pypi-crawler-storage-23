from typing import List, Union
from .utils import split_into_sentences

class LitmusContext:
    """
    Represents the context (evidence) for hallucination detection.
    """
    def __init__(self, content: Union[str, List[str]]):
        if isinstance(content, str):
            self.sentences = split_into_sentences(content)
        else:
            self.sentences = content

    def __repr__(self):
        return f"<LitmusContext sentences={len(self.sentences)}>"
