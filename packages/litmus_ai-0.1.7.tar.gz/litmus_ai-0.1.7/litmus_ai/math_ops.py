import torch
import torch.nn.functional as F
from typing import Tuple, List
from itertools import combinations

def project_embedding(o: torch.Tensor, e1: torch.Tensor, e2: torch.Tensor) -> float:
    """
    Project vector o onto the plane defined by e1 and e2.
    Returns the support score (norm of projection / norm of o).
    """
    # Gram-Schmidt orthonormalization
    u1 = F.normalize(e1, p=2, dim=0)
    e2_orth = e2 - (e2 @ u1) * u1
    e2_norm = torch.norm(e2_orth)
    
    if e2_norm < 1e-6:
        # e1 and e2 are parallel, project onto line
        proj = (o @ u1) * u1
    else:
        u2 = e2_orth / e2_norm
        # Project onto plane
        proj = (o @ u1) * u1 + (o @ u2) * u2
    
    o_norm = torch.norm(o) + 1e-9
    support = (torch.norm(proj) / o_norm).item()
    return support

def calculate_bivector_support(
    claim_embedding: torch.Tensor, 
    evidence_embeddings: torch.Tensor,
    threshold: float = 0.7
) -> dict:
    """
    Calculate the best support score for a claim embedding against a set of evidence embeddings
    using bivector projection (Type I).
    
    Args:
        claim_embedding: Tensor of shape (hidden_dim,)
        evidence_embeddings: Tensor of shape (num_evidence, hidden_dim)
        threshold: Support threshold
        
    Returns:
        Dictionary containing support score, unsupported score, best pair indices.
    """
    num_evidence = evidence_embeddings.size(0)
    
    # If fewer than 2 pieces of evidence, fall back to simple max similarity
    if num_evidence < 2:
        if num_evidence == 0:
            return {
                'support': 0.0,
                'unsupported_score': 1.0,
                'best_pair': None,
                'method': 'none'
            }
        
        # Simple cosine similarity with single evidence
        sim = (claim_embedding @ evidence_embeddings[0]).item()
        return {
            'support': sim,
            'unsupported_score': 1.0 - sim,
            'best_pair': (0, 0),
            'method': 'cosine'
        }

    # Bivector projection onto all pairs
    pairs = list(combinations(range(num_evidence), 2))
    best_support = 0.0
    best_pair = (0, 1)
    
    for (p, q) in pairs:
        support = project_embedding(
            claim_embedding, 
            evidence_embeddings[p], 
            evidence_embeddings[q]
        )
        if support > best_support:
            best_support = support
            best_pair = (p, q)
            
    return {
        'support': best_support,
        'unsupported_score': 1.0 - best_support,
        'best_pair': best_pair,
        'method': 'bivector'
    }
