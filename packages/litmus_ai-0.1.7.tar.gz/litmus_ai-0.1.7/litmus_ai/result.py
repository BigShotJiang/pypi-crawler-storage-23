from dataclasses import dataclass, field
from typing import Dict, Any

@dataclass
class LitmusResult:
    """
    Result of a hallucination detection check.
    """
    score: float
    is_hallucination: bool
    details: Dict[str, Any] = field(default_factory=dict)
