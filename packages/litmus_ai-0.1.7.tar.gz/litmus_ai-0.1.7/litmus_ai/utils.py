from typing import List

def split_into_sentences(text: str) -> List[str]:
    """
    Split text into sentences using simple heuristics.
    In a production environment, use nltk or spacy.
    """
    if not text:
        return []
    # Replace common end markers with a unique token to split on, 
    # being careful not to split on abbreviations (this is a naive implementation)
    normalized = text.replace('!', '.').replace('?', '.')
    sentences = [s.strip() for s in normalized.split('.') if s.strip()]
    return sentences
