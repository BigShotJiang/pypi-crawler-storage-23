import os
import logging

# Suppress warnings
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN_WARNING"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from typing import Union, List, Optional
from .model_utils import ModelManager
from .result import LitmusResult
from .context import LitmusContext
from .output import LitmusOutput
from .strategies import get_strategy_class

class LitmusDetector:
    """
    High-level detector for hallucinations.
    Supports multiple detection types via strategy pattern.
    """
    def __init__(self, 
                 type: str = 'context-grounding',
                 model_name: Optional[str] = None, 
                 threshold: Optional[float] = None, 
                 device: str = 'cpu'):

        self.type = type
        self.device = device
        self.threshold = threshold
        self.model_name = model_name
        
        self._setup_strategy(type, model_name, threshold, device)

    def _setup_strategy(self, type, model_name, threshold, device):
        if type == 'context-grounding':
            m_name = model_name or 'sentence-transformers/all-MiniLM-L6-v2'
            thresh = threshold if threshold is not None else 0.7
            m_type = 'bi-encoder'
        elif type in ['context-contradiction', 'relational-inversion']:
            m_name = model_name or 'cross-encoder/nli-deberta-v3-base'
            thresh = threshold if threshold is not None else (0.5 if type == 'relational-inversion' else 0.3)
            m_type = 'cross-encoder'
        elif type == 'instruction-drift':
            m_name = model_name or 'sentence-transformers/all-MiniLM-L6-v2'
            thresh = threshold if threshold is not None else 0.3
            m_type = 'bi-encoder'
        else:
            raise ValueError(f"Unsupported type: '{type}'. Available: context-grounding, context-contradiction, relational-inversion, instruction-drift")

        self.threshold = thresh
        self.model_manager = ModelManager(
            model_name=m_name, 
            device=device,
            model_type=m_type
        )
        
        StrategyClass = get_strategy_class(type)
        self.strategy = StrategyClass(self.model_manager, threshold=thresh)

    def check(self, 
              context: Union[str, LitmusContext, List[str]], 
              output: Union[str, LitmusOutput, List[str]],
              query: Optional[str] = None,
              threshold: Optional[float] = None) -> LitmusResult:
        """
        Check if the output is supported by the context.

        Args:
            context: The context/evidence to check against.
            output: The output/claims to verify.
            query: Required only for type='instruction-drift'.
            threshold: Optional per-call threshold override (0.0 to 1.0).
                       Defaults to the threshold set at initialization.
        """
        # Validate query for instruction-drift
        if self.type == 'instruction-drift' and query is None:
            raise ValueError("query parameter is required for type='instruction-drift'")
        
        # Validate threshold override
        if threshold is not None:
            if not (0.0 <= threshold <= 1.0):
                raise ValueError("threshold must be between 0.0 and 1.0 inclusive")
            original_threshold = self.strategy.threshold
            self.strategy.threshold = threshold
        
        # Standardize inputs
        if isinstance(context, (str, list)):
            context = LitmusContext(context)
            
        if isinstance(output, (str, list)):
            output = LitmusOutput(output)
            
        evidence_texts = context.sentences
        claim_texts = output.sentences
        
        # Delegate to strategy
        if self.type == 'instruction-drift':
            raw_result = self.strategy.detect(query, evidence_texts, claim_texts)
        else:
            raw_result = self.strategy.detect(evidence_texts, claim_texts)
        
        # Restore original threshold
        if threshold is not None:
            self.strategy.threshold = original_threshold
            
        return LitmusResult(
            score=raw_result['score'],
            is_hallucination=raw_result['is_hallucination'],
            details=raw_result['details']
        )
