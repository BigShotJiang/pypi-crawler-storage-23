from typing import List, Union
from .utils import split_into_sentences

class LitmusOutput:
    """
    Represents the LLM output (claims) to be verified.
    """
    def __init__(self, content: Union[str, List[str]]):
        if isinstance(content, str):
            self.sentences = split_into_sentences(content)
        else:
            self.sentences = content

    def __repr__(self):
        return f"<LitmusOutput sentences={len(self.sentences)}>"
