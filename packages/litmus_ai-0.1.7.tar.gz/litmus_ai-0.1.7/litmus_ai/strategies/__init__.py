from .grounding import ContextGroundingStrategy
from .contradiction import ContextContradictionStrategy
from .inversion import RelationalInversionStrategy
from .drift import InstructionDriftStrategy

STRATEGIES = {
    'context-grounding': ContextGroundingStrategy,
    'context-contradiction': ContextContradictionStrategy,
    'relational-inversion': RelationalInversionStrategy,
    'instruction-drift': InstructionDriftStrategy
}

def get_strategy_class(type: str):
    if type not in STRATEGIES:
        raise ValueError(f"Unknown type '{type}'. Available: {list(STRATEGIES.keys())}")
    return STRATEGIES[type]
