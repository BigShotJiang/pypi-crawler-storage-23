import torch
from typing import Dict, List, Any
from ..math_ops import calculate_bivector_support
from ..model_utils import ModelManager

class ContextGroundingStrategy:
    """
    Type I: Hallucination Detection via Bivector Projection for Context Grounding.
    """
    def __init__(self, model_manager: ModelManager, threshold: float = 0.7):
        self.model_manager = model_manager
        self.threshold = threshold

    def detect(self, evidence_texts: List[str], claim_texts: List[str]) -> Dict[str, Any]:
        """
        Detect hallucinations by checking if claims are supported by evidence context.
        """
        # Embed
        evidence_embs = self.model_manager.embed_texts(evidence_texts)
        claim_embs = self.model_manager.embed_texts(claim_texts)
        
        if len(claim_embs) == 0:
             return {
                 'score': 1.0, 
                 'is_hallucination': False, 
                 'details': {'reason': 'No claims found to verify.'}
            }

        results = []
        min_support = 1.0
        
        for i, claim_emb in enumerate(claim_embs):
            claim_text = claim_texts[i]
            res = calculate_bivector_support(claim_emb, evidence_embs, threshold=self.threshold)
            res['claim'] = claim_text
            results.append(res)
            
            if res['support'] < min_support:
                min_support = res['support']
        
        is_hallucination = min_support < self.threshold
        
        return {
            'score': min_support,
            'is_hallucination': is_hallucination,
            'details': {
                'claim_scores': results,
                'threshold': self.threshold,
                'metric': 'context-grounding'
            }
        }
