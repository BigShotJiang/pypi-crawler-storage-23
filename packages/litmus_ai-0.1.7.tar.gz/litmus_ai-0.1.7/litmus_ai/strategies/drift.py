"""
Instruction Drift Strategy (Type IV)

Detects when an LLM answer drifts away from the query-context relationship,
even if it uses similar keywords. Uses GA bivector plane alignment.
"""
from typing import Dict, Any, List
import numpy as np


class InstructionDriftStrategy:
    """
    Type IV: Instruction Drift Detection
    
    Computes plane cosine between (Query ∧ Context) and (Query ∧ Answer).
    Drift = 1 - plane_cosine. Higher drift → hallucination.
    """
    
    def __init__(self, model_manager, threshold: float = 0.3):
        self.model_manager = model_manager
        self.threshold = threshold  # Drift threshold for hallucination
    
    def _embed(self, text: str) -> np.ndarray:
        """Get normalized embedding for text."""
        emb = self.model_manager.embed_texts([text])[0]
        # Convert to numpy array if needed
        emb = np.asarray(emb, dtype=np.float64)
        # Normalize for cosine similarity
        norm = np.linalg.norm(emb)
        if norm > 0:
            emb = emb / norm
        return emb

    
    def _dot(self, u: np.ndarray, v: np.ndarray) -> float:
        return float(np.dot(u, v))
    
    def _wedge_norm(self, u: np.ndarray, v: np.ndarray, eps: float = 1e-12) -> float:
        """||u ∧ v||^2 = ||u||^2||v||^2 - (u·v)^2"""
        uu = self._dot(u, u)
        vv = self._dot(v, v)
        uv = self._dot(u, v)
        val = uu * vv - uv * uv
        return float(np.sqrt(max(val, eps)))
    
    def _bivector_inner(self, u: np.ndarray, v: np.ndarray, x: np.ndarray, y: np.ndarray) -> float:
        """<u∧v, x∧y> = (u·x)(v·y) - (u·y)(v·x)"""
        return self._dot(u, x) * self._dot(v, y) - self._dot(u, y) * self._dot(v, x)
    
    def _plane_cosine(self, u: np.ndarray, v: np.ndarray, x: np.ndarray, y: np.ndarray, eps: float = 1e-12) -> float:
        """Cosine similarity between planes (u∧v) and (x∧y)."""
        num = self._bivector_inner(u, v, x, y)
        den = self._wedge_norm(u, v, eps=eps) * self._wedge_norm(x, y, eps=eps)
        return float(num / max(den, eps))
    
    def detect(self, query: str, evidence_texts: List[str], claim_texts: List[str]) -> Dict[str, Any]:
        """
        Detect instruction drift for each claim.
        
        Args:
            query: The original query/instruction
            evidence_texts: Context sentences
            claim_texts: Output claims to check
            
        Returns:
            Detection result with drift scores
        """
        # Embed query
        q = self._embed(query)
        
        # Embed and combine context
        if len(evidence_texts) == 1:
            c = self._embed(evidence_texts[0])
        else:
            # Average context embeddings
            c_embs = [self._embed(t) for t in evidence_texts]
            c = np.mean(c_embs, axis=0)
            c = c / np.linalg.norm(c)
        
        results = []
        overall_hallucination = False
        max_drift = 0.0
        
        for claim in claim_texts:
            a = self._embed(claim)
            
            # Compute plane cosine between (Q∧C) and (Q∧A)
            pc = self._plane_cosine(q, c, q, a)
            drift = 1.0 - pc
            
            is_hallucination = drift > self.threshold
            max_drift = max(max_drift, drift)
            if is_hallucination:
                overall_hallucination = True
            
            results.append({
                'claim': claim,
                'drift_score': drift,
                'plane_cosine': pc,
                'is_hallucination': is_hallucination
            })
        
        return {
            'score': max_drift,
            'is_hallucination': overall_hallucination,
            'details': {
                'claim_scores': results,
                'query': query
            }
        }
