import torch
import numpy as np
from typing import Dict, List, Any
from scipy.linalg import qr

class RelationalInversionStrategy:
    """
    Type III: Relational Inversion Detection.
    Uses subspace projection to distinguish between Inversion and Contradiction.
    """
    def __init__(self, model_manager, threshold: float = 0.5):
        self.model_manager = model_manager
        self.threshold = threshold # This threshold acts as a minimum probability for contradiction first
        
        # Calibration examples
        self.inversion_examples = [
            ("Alice hired Bob.", "Bob hired Alice."),
            ("The cat caught the mouse.", "The mouse caught the cat."),
            ("Team A defeated Team B.", "Team B defeated Team A."),
            ("The teacher graded the student.", "The student graded the teacher."),
            ("Company X acquired Company Y.", "Company Y acquired Company X."),
        ]
        
        self.contradiction_examples = [
            ("The sky is blue.", "The sky is not blue."),
            ("The experiment succeeded.", "The experiment failed."),
            ("He arrived early.", "He arrived late."),
            ("The door is open.", "The door is closed."),
            ("The answer is correct.", "The answer is wrong."),
        ]
        
        # Build subspaces
        self.Q_inv = self._build_subspace_basis(self.inversion_examples)
        self.Q_contra = self._build_subspace_basis(self.contradiction_examples)

    def _build_subspace_basis(self, examples):
        """Build orthonormal basis for a subspace."""
        embeddings = []
        for premise, hypothesis in examples:
            h = self.model_manager.get_pooled_embedding(premise, hypothesis).cpu().numpy()
            embeddings.append(h)
        
        H = np.array(embeddings)
        # QR decomposition: H^T = Q R
        Q, R = qr(H.T, mode='economic')
        rank = np.sum(np.abs(np.diag(R)) > 1e-6)
        return Q[:, :rank]

    def _compute_subspace_support(self, h, Q):
        """Compute projection magnitude."""
        projection = Q @ (Q.T @ h)
        return np.linalg.norm(projection) / (np.linalg.norm(h) + 1e-10)

    def detect(self, evidence_texts: List[str], claim_texts: List[str]) -> Dict[str, Any]:
        results = []
        overall_hallucination = False
        max_severity = 0.0
        
        for claim in claim_texts:
            best_res = {
                'claim': claim,
                'score': 0.0,
                'type': 'No Hallucination',
                'is_hallucination': False,
                'context_claim': None,
                'is_supported': False
            }
            
            for ctx in evidence_texts:
                # 1. Check Probabilities
                probs = self.model_manager.get_probs(ctx, claim)
                p_contra = probs[0].item() 
                p_entail = probs[1].item()
                
                if p_entail > 0.5:
                    best_res['is_supported'] = True
                
                if p_contra < self.threshold:
                    continue 
                    
                # 2. Potential Hallucination (Inversion or Contradiction)
                h = self.model_manager.get_pooled_embedding(ctx, claim).cpu().numpy()
                support_inv = self._compute_subspace_support(h, self.Q_inv)
                support_contra = self._compute_subspace_support(h, self.Q_contra)
                
                diff = support_inv - support_contra
                score = max(support_inv, support_contra)
                
                pred_type = "Relational Inversion" if diff > 0 else "Contradiction"
                
                if score > best_res['score']:
                    best_res.update({
                        'score': score,
                        'type': pred_type,
                        'is_hallucination': True,
                        'context_claim': ctx,
                        'details': {
                            'support_inversion': float(support_inv),
                            'support_contradiction': float(support_contra),
                            'probability_contradiction': float(p_contra)
                        }
                    })
            
            # Support overrules contradiction
            if best_res['is_supported']:
                best_res['is_hallucination'] = False
                best_res['type'] = 'No Hallucination'
                best_res['score'] = 0.0
            
            if best_res['is_hallucination']:
                overall_hallucination = True
                max_severity = max(max_severity, best_res['score'])
                
            results.append(best_res)


        return {
            'score': max_severity,
            'is_hallucination': overall_hallucination,
            'details': {
                'claim_scores': results,
                'metric': 'relational-inversion'
            }
        }
