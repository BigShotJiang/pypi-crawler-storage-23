import torch
import torch.nn.functional as F
from typing import Dict, List, Any

class ContextContradictionStrategy:
    """
    Type II: Hallucination Detection via Contradiction Detection.
    Uses a Cross-Encoder to project [Context, Claim] pairs onto a contradiction direction.
    """
    def __init__(self, model_manager, threshold: float = 0.3):
        # We expect a CrossEncoderManager here, but duck typing is fine
        self.model_manager = model_manager
        self.threshold = threshold
        # Extract discriminants upon initialization
        self.w_pure_contra = self._extract_discriminants()

    def _extract_discriminants(self):
        """Extract and orthogonalize discriminant directions."""
        # The final classification layer is usually a Linear layer.
        # Its weights define the directions for [Contradiction, Entailment, Neutral]
        W = self.model_manager.model.classifier.weight.data
        
        # Depending on the model, index 0 might be Contradiction or Entailment.
        # For 'cross-encoder/nli-deberta-v3-base':
        # Labels: 0: Contradiction, 1: Entailment, 2: Neutral
        w_contra = W[0]
        w_entail = W[1]
        
        # Gram-Schmidt Orthogonalization
        # Remove the entailment component from the contradiction vector
        # proj = (w_c . w_e) / (w_e . w_e) * w_e
        dot_ce = torch.dot(w_contra, w_entail)
        dot_ee = torch.dot(w_entail, w_entail)
        proj = (dot_ce / dot_ee) * w_entail
        
        w_pure = w_contra - proj
        
        # Normalize to create the unit vector for our detector
        return F.normalize(w_pure, p=2, dim=0)

    def detect(self, evidence_texts: List[str], claim_texts: List[str]) -> Dict[str, Any]:
        results = []
        overall_hallucination = False
        min_score = 1.0 # In contradiction, lower score (less contradictory) is "better" for non-hallucination? 
        # Actually for consistency, let's keep score as "support" or "safety".
        # But here 'score' in core_type_II is 'contradiction score'.
        # Let's start with raw contradiction score and map it later if needed.
        
        for claim in claim_texts:
            max_cos = -1.0
            contra_idx = -1
            best_context = None
            
            for i, ctx in enumerate(evidence_texts):
                # Encode pair
                h = self.model_manager.get_pooled_embedding(ctx, claim)
                h_norm = F.normalize(h, p=2, dim=0)
                
                # Project h onto the pure contradiction direction
                score = torch.dot(h_norm, self.w_pure_contra).item()
                
                if score > max_cos:
                    max_cos = score
                    contra_idx = i
                    best_context = ctx
            
            is_contradiction = max_cos > self.threshold
            if is_contradiction:
                overall_hallucination = True
                
            results.append({
                'claim': claim,
                'score': max_cos, # This is a CONTRADICTION score, higher = worse
                'contradicts': is_contradiction,
                'context_claim': best_context
            })

        # For consistency with the existing result structure:
        # score: global metric. For grounding, it was "min support".
        # For contradiction, maybe "max contradiction score"?
        max_contradiction_score = max([r['score'] for r in results]) if results else 0.0
        
        return {
            'score': max_contradiction_score, # Note: Meaning inverted compared to grounding
            'is_hallucination': overall_hallucination,
            'details': {
                'claim_scores': results,
                'threshold': self.threshold,
                'metric': 'context-contradiction'
            }
        }
