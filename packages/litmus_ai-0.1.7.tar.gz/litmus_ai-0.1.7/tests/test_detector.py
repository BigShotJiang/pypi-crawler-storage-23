import pytest
import torch
from unittest.mock import MagicMock, patch
from litmus_ai import LitmusDetector, LitmusResult

# Mock ModelManager to avoid loading real models during tests
@pytest.fixture
def mock_model_manager():
    with patch("litmus_ai.detector.ModelManager") as MockManager:
        instance = MockManager.return_value
        # Mock embed_texts to return random tensors of shape (N, 3)
        instance.embed_texts.side_effect = lambda texts: torch.randn(len(texts), 3) if texts else torch.tensor([])
        yield instance

def test_detector_instantiation(mock_model_manager):
    detector = LitmusDetector()
    assert detector is not None

def test_detector_check_structure(mock_model_manager):
    detector = LitmusDetector()
    # Mock return values for embeddings to control the math outcome strictly if needed,
    # or just test structure with random values.
    # Let's mock the actual math return to test the detector logic.
    
    # Mock the math function used by the Grounding strategy
    with patch("litmus_ai.strategies.grounding.calculate_bivector_support") as mock_calc:
        mock_calc.return_value = {
            'support': 0.9,
            'unsupported_score': 0.1,
            'best_pair': (0, 1),
            'method': 'bivector'
        }
        
        result = detector.check("context sentence one. context sentence two.", "claim sentence.")
        
        assert isinstance(result, LitmusResult)
        assert result.score == 0.9
        assert not result.is_hallucination
        assert 'claim_scores' in result.details

def test_detector_hallucination_flag(mock_model_manager):
    detector = LitmusDetector(threshold=0.8)
    
    with patch("litmus_ai.strategies.grounding.calculate_bivector_support") as mock_calc:
        # Return low support
        mock_calc.return_value = {
            'support': 0.5,
            'unsupported_score': 0.5,
            'best_pair': (0, 1),
            'method': 'bivector'
        }
        
        result = detector.check("context", "claim")
        assert result.is_hallucination is True

def test_detector_contradiction(mock_model_manager):
    # Test for the new metric
    # We need to mock the model_type in manager to be 'cross-encoder' for this to work implicitly
    # or just trust the mock logic.
    mock_model_manager.model_type = 'cross-encoder'
    mock_model_manager.encode_pair = MagicMock(return_value=torch.tensor([1.0, 0.0, 0.0]))
    
    # We also need to mock the classifier weights access in strategy init
    # The strategy init accesses model_manager.model.classifier.weight.data
    mock_model_manager.model.classifier.weight.data = torch.randn(3, 3) # random weights
    
    detector = LitmusDetector(metric='context-contradiction')
    # Replace the strategy's model manager with our mock
    detector.strategy.model_manager = mock_model_manager
    # Re-initialize strategy or just mock the heavy lifting
    detector.strategy.w_pure_contra = torch.tensor([1.0, 0.0, 0.0])
    
    # Run check
    # We need to patch the encode_pair call or the dot product part, but simply running it 
    # with mocked encode_pair should be enough if logic is sound.
    
    result = detector.check("context", "claim")
    assert result.details['metric'] == 'context-contradiction'
