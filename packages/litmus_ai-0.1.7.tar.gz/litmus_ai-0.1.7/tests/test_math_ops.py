import pytest
import torch
from litmus_ai.math_ops import project_embedding, calculate_bivector_support, F

def test_project_embedding():
    # Setup simple orthogonal vectors
    e1 = torch.tensor([1.0, 0.0, 0.0])
    e2 = torch.tensor([0.0, 1.0, 0.0])
    
    # Vector in the plane (should define perfect support)
    o = torch.tensor([1.0, 1.0, 0.0])
    
    support = project_embedding(o, e1, e2)
    # The projection of [1, 1, 0] onto xy-plane is [1, 1, 0]
    # Norm is sqrt(2). support = norm(proj) / norm(o) = 1.0
    assert abs(support - 1.0) < 1e-5

    # Vector orthogonal to the plane (should support 0)
    o_orth = torch.tensor([0.0, 0.0, 1.0])
    support_orth = project_embedding(o_orth, e1, e2)
    assert abs(support_orth - 0.0) < 1e-5

def test_calculate_bivector_support():
    # Setup dummy embeddings
    # Evidence: x-axis, y-axis
    evidence = torch.tensor([
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0]
    ])
    
    # Claim: z-axis (unsupported)
    claim_unsupported = torch.tensor([0.0, 0.0, 1.0])
    
    res = calculate_bivector_support(claim_unsupported, evidence, threshold=0.5)
    assert res['support'] < 0.1
    
    # Claim: 45 deg between x and y (supported)
    claim_supported = F.normalize(torch.tensor([1.0, 1.0, 0.0]), p=2, dim=0)
    res_sup = calculate_bivector_support(claim_supported, evidence, threshold=0.5)
    assert res_sup['support'] > 0.9
