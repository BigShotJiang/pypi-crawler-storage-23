"""
Entry point for running pyRofex_To_Excel as a module.

Usage:
    python -m pyRofex_To_Excel
"""

from .main import main

if __name__ == "__main__":
    main()
