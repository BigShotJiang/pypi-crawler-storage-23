from __future__ import annotations

from pygeomoptics.fibers import fiber_core_refractive_index

fiber_core_refractive_index.replace_implementation(lambda: 1234)
