from ._core import *

from . import _version
__version__ = _version.get_versions()['version']
