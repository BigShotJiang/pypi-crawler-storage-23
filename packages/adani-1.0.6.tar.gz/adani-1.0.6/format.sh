clang-format -i inc/adani/*.h
clang-format -i src/*.cc
clang-format -i pywrap/pywrap.cc
clang-format -i output/*.cpp
clang-format -i examples/test.cpp
