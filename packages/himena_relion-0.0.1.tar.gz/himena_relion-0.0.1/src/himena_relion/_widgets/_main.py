from __future__ import annotations
from pathlib import Path
from typing import Callable, Iterator, TypeVar, TYPE_CHECKING
import logging
import weakref

from qtpy import QtWidgets as QtW, QtCore, QtGui
from superqt import QElidingLabel
from superqt.utils import thread_worker, GeneratorWorker
from watchfiles import watch
from timeit import default_timer
from himena import MainWindow, WidgetDataModel
from himena.plugins import validate_protocol
from himena.qt import QColoredToolButton
from himena_relion import _job_dir, _utils
from himena_relion._widgets._job_widgets import (
    JobWidgetBase,
    QJobStateLabel,
    QRunOutErrLog,
    QNoteEdit,
    QJobPipelineViewer,
    QJobParameterView,
)
from himena_relion._widgets._misc import spacer_widget
from himena_relion._impl_objects import RelionJobIsTesting
from himena_relion._utils import monospace_font_family
from himena_relion.consts import RelionJobState

if TYPE_CHECKING:
    pass

_LOGGER = logging.getLogger(__name__)
_C = TypeVar("_C", bound=JobWidgetBase)


class QRelionJobWidget(QtW.QWidget):
    job_updated = QtCore.Signal(Path)
    _instances = set["QRelionJobWidget"]()

    def __init__(self, ui: MainWindow):
        super().__init__()
        self._ui_ref = weakref.ref(ui)
        self._job_dir: _job_dir.JobDirectory | None = None
        self._control_widget: QRelionJobWidgetControl | None = None
        layout = QtW.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self._state_widget = QJobStateLabel(self)
        layout.addWidget(self._state_widget)
        self._tab_widget = QtW.QTabWidget(self)
        self._tab_widget.tabBar().setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        layout.addWidget(self._tab_widget)
        self._watcher: GeneratorWorker | None = None
        self.job_updated.connect(self._on_job_updated)
        self._instances.add(self)

    @validate_protocol
    def update_model(self, model: WidgetDataModel):
        """Update the widget with a new model."""
        self._tab_widget.clear()
        if self._watcher:
            self._watcher.quit()
        self._job_dir = job_dir = model.value
        if not isinstance(job_dir, _job_dir.JobDirectory):
            raise TypeError(f"Expected JobDirectory, got {type(job_dir)}")
        if isinstance(model.metadata, RelionJobIsTesting):
            self._watcher = None
        else:
            self._watcher = self._watch_job_directory(job_dir.path)

        if wcls := RelionJobViewRegistry.instance().get_widget_class(job_dir):
            _LOGGER.info(f"Adding job widget for {job_dir.path}: {wcls!r}")
            wdt = wcls(job_dir)
            self.add_job_widget(wdt)

        self.add_job_widget(QJobPipelineViewer(show_tree_view=True))
        self.add_job_widget(QJobParameterView())
        self.add_job_widget(QRunOutErrLog())
        self.add_job_widget(QNoteEdit())
        self.initialize_widgets(job_dir)

    def initialize_widgets(self, job_dir: _job_dir.JobDirectory):
        """Initialize all job widgets with the given job directory."""
        for wdt in self._iter_job_widgets():
            try:
                t0 = default_timer()
                wdt.initialize(job_dir)
            except Exception:
                _LOGGER.error(
                    f"Failed to initialize job widget {type(wdt).__name__!r}",
                    exc_info=True,
                )
            else:
                t1 = default_timer()
                _LOGGER.info(
                    f"Initialization of {type(wdt).__name__} took {t1 - t0:.3f} seconds"
                )

    @validate_protocol
    def to_model(self) -> WidgetDataModel:
        """Convert the widget state back to a model."""
        if self._job_dir is None:
            raise RuntimeError("Job directory is not set.")
        return WidgetDataModel(
            value=self._job_dir,
            type=self._job_dir.himena_model_type(),
        )

    @validate_protocol
    def model_type(self) -> str:
        return self._job_dir.himena_model_type()

    @validate_protocol
    def size_hint(self):
        return 420, 540

    @validate_protocol
    def theme_changed_callback(self, theme):
        """Callback when the application theme is changed."""
        for wdt in self.control_widget()._tool_buttons:
            wdt.update_theme(theme)

    @validate_protocol
    def control_widget(self) -> QRelionJobWidgetControl:
        """Get the control widget for this job widget."""
        if self._control_widget is None:
            self._control_widget = QRelionJobWidgetControl(self)
        return self._control_widget

    @validate_protocol
    def widget_added_callback(self):
        """Callback when the widget is added to the main window."""
        for wdt in self._iter_job_widgets():
            wdt.widget_added_callback()

    @validate_protocol
    def widget_closed_callback(self):
        """Callback when the widget is closed."""
        if self._watcher is not None:
            self._watcher.quit()
            self._watcher = None

    def add_job_widget(self, widget: JobWidgetBase):
        """Add a job widget to the tab widget."""
        if not isinstance(widget, JobWidgetBase):
            raise TypeError(f"Expected JobWidgetBase, got {type(widget)}")
        self._tab_widget.addTab(widget, widget.tab_title())

    @thread_worker(start_thread=True)
    def _watch_job_directory(self, path: Path):
        """Watch the job directory for changes."""
        for changes in watch(path, step=160, rust_timeout=400, yield_on_timeout=True):
            if self._watcher is None:
                return  # stopped
            updated_files: list[Path] = []
            for change, fp in changes:
                path = Path(fp)
                if path not in updated_files:
                    updated_files.append(path)
            for updated_file in updated_files:
                self.job_updated.emit(updated_file)
                yield

    def _on_job_updated(self, path: Path):
        """Handle changes to the job directory."""
        if self._job_dir is None:
            return
        if not self._job_dir.path.exists():
            self.widget_closed_callback()
            raise RuntimeError(
                "Job directory has been deleted externally. This widget will no longer "
                "respond to changes. Please close this job widget."
            )
        msg = ""
        for wdt in self._iter_job_widgets():
            wdt.on_job_updated(self._job_dir, Path(path))
            if isinstance(wdt, QRunOutErrLog):
                msg = wdt.last_lines()
        if self._job_dir.state() is RelionJobState.RUNNING:
            self._control_widget.set_msg(msg)
        else:
            self._control_widget.set_msg("")

    def _iter_job_widgets(self) -> Iterator[JobWidgetBase]:
        """Iterate over all job widgets in the tab widget."""
        yield self._state_widget
        for i in range(self._tab_widget.count()):
            if isinstance(wdt := self._tab_widget.widget(i), JobWidgetBase):
                yield wdt


class RelionJobViewRegistry:
    _instance = None

    def __init__(self):
        self._registered_spa = {}
        self._registered_tomo = {}

    @classmethod
    def instance(cls) -> RelionJobViewRegistry:
        """Get the singleton instance of the registry."""
        if cls._instance is None:
            cls._instance = RelionJobViewRegistry()
        return cls._instance

    def get_widget_class(
        self, job_dir: _job_dir.JobDirectory
    ) -> Callable[[_job_dir.JobDirectory], JobWidgetBase] | None:
        """Get the widget class for a specific job type."""
        label = job_dir.job_type_label()
        if job_dir.is_tomo():
            registries = [self._registered_tomo, self._registered_spa]
        else:
            registries = [self._registered_spa, self._registered_tomo]

        # split by `.` and try each part
        for reg in registries:
            num_substrings = label.count(".") + 1
            for i in range(label.count(".")):
                label_sub = ".".join(label.split(".")[: num_substrings - i])
                if factory := reg.get(label_sub, None):
                    return factory


_T = TypeVar("_T", bound=JobWidgetBase)


def register_job(
    job_type: str,
    is_tomo: bool = False,
) -> Callable[[_T], _T]:
    """Decorator to register a widget class for a specific job type."""
    if not isinstance(job_type, str):
        raise TypeError(f"Expected str for job_type, got {type(job_type)}")

    def inner(widget_cls: _T) -> _T:
        ins = RelionJobViewRegistry.instance()
        if is_tomo:
            ins._registered_tomo[job_type] = widget_cls
        else:
            ins._registered_spa[job_type] = widget_cls
        return widget_cls

    return inner


class QRelionJobWidgetControl(QtW.QWidget):
    def __init__(self, parent: QRelionJobWidget):
        super().__init__()
        self._parent = parent
        # The last lines show the progress of the job, which is useful for users during
        # running jobs.
        self._oneline_msg = QElidingLabel("")
        self._oneline_msg.setFixedWidth(700)
        self._oneline_msg.setSizePolicy(
            QtW.QSizePolicy.Policy.Expanding, QtW.QSizePolicy.Policy.Preferred
        )
        self._oneline_msg.setTextInteractionFlags(
            QtCore.Qt.TextInteractionFlag.TextSelectableByMouse
        )
        self._oneline_msg.setFont(QtGui.QFont(monospace_font_family(), 7))
        self._tool_buttons = [
            QColoredToolButton(
                self.find_me_in_flowchart, _utils.path_icon_svg("findme")
            ),
            QColoredToolButton(self.refresh_widget, _utils.path_icon_svg("refresh")),
        ]
        layout = QtW.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(1)
        layout.addWidget(self._oneline_msg, alignment=QtCore.Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(spacer_widget())
        for btn in self._tool_buttons:
            layout.addWidget(btn, alignment=QtCore.Qt.AlignmentFlag.AlignRight)

        # initialize the message
        if parent._job_dir.state() is RelionJobState.RUNNING:
            if wdt := self.find_child_widget(QRunOutErrLog):
                msg = wdt.last_lines()
                self.set_msg(msg)

    @property
    def widget(self) -> QRelionJobWidget:
        return self._parent

    def find_child_widget(self, widget_type: type[_C]) -> _C | None:
        for wdt in self.widget._iter_job_widgets():
            if isinstance(wdt, widget_type):
                return wdt

    def refresh_widget(self):
        """Reload this RELION job."""
        self.widget.update_model(self.widget.to_model())

    def find_me_in_flowchart(self):
        """Focus on the node item corresponding to this job in the flowchart."""
        if ui := self.widget._ui_ref():
            job_dir = self.widget._job_dir
            flowchart = _utils.get_pipeline_widgets(ui, job_dir.relion_project_dir)
            if flowchart is None:
                return
            job_item_id = job_dir.path.relative_to(job_dir.relion_project_dir)
            if node := flowchart._flow_chart._node_map.get(job_item_id):
                flowchart._flow_chart.center_on_item(node.item())

    def set_msg(self, msg: str):
        """Set the one-line message in the control widget."""
        self._oneline_msg.setText(msg)
        if msg:
            self._oneline_msg.setToolTip("The last two lines of run.out")
        else:
            self._oneline_msg.setToolTip("")
