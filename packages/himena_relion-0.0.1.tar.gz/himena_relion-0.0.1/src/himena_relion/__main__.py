from himena_relion.external import run_function


def main():
    run_function()
