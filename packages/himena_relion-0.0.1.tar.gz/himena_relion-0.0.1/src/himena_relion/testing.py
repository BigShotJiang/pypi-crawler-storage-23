from typing import TypeVar, Generic
import mrcfile
import numpy as np
from himena_relion._widgets._job_widgets import JobWidgetBase
from himena_relion._job_dir import JobDirectory

_T = TypeVar("_T", bound=JobWidgetBase)


class JobWidgetTester(Generic[_T]):
    def __init__(self, widget: _T, job_dir: JobDirectory):
        self.widget = widget
        self.job_dir = job_dir
        widget.initialize(job_dir)
        self._rng = np.random.default_rng(29958293)

    @classmethod
    def no_widget(cls, job_dir: JobDirectory) -> "JobWidgetTester[JobWidgetBase]":
        widget = JobWidgetBase()
        return cls(widget, job_dir)

    def write_text(self, path: str, text: str):
        fp = self.job_dir.path / path
        fp.write_text(text)
        self.widget.on_job_updated(self.job_dir, str(fp))

    def write_mrc(self, path: str, data: np.ndarray):
        fp = self.job_dir.path / path
        with mrcfile.new(fp) as mrc:
            mrc.set_data(data)
        self.widget.on_job_updated(self.job_dir, str(fp))

    def write_random_mrc(self, path: str, shape: tuple[int, ...], dtype=np.float32):
        self.write_mrc(path, self.make_random_mrc(shape, dtype))

    def write_sphere_mrc(self, path: str, size: int, dtype=np.float32):
        xx, yy, zz = np.indices((size, size, size))
        c = (size - 1) / 2
        sphere = (xx - c) ** 2 + (yy - c) ** 2 + (zz - c) ** 2 < (c * 0.8) ** 2
        self.write_mrc(path, sphere.astype(dtype))

    def make_random_mrc(self, shape: tuple[int, ...], dtype=np.float32) -> np.ndarray:
        return self._rng.normal(loc=1.0, scale=1.0, size=shape).astype(dtype)

    def mkdir(self, name: str):
        fp = self.job_dir.path / name
        fp.mkdir(parents=True, exist_ok=True)

    def initialize(self):
        """Re-initialize the widget with the job directory."""
        self.widget.initialize(self.job_dir)

    def write_exit_with_success(self):
        self.write_text("RELION_JOB_EXIT_SUCCESS", "")
