OUTPUT_PARTICLES = "particles_shifted.star"
OUTPUT_MAP = "map_shifted.mrc"
OUTPUT_MASK = "mask_shifted.mrc"
RELION_STAR_HANDLER = "relion_star_handler"
