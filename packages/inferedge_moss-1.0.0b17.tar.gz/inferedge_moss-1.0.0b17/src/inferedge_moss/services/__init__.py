"""Services package initialization."""

import sys

# Skip embedding service in Python 3.14 (onnxruntime not supported)
if sys.version_info < (3, 14):
    from .embedding_service import EmbeddingService

    __all__ = [
        "EmbeddingService",
    ]
else:
    __all__ = []
