"""
Unit tests for metadata filtering through the PyIndex Rust bindings.
Uses custom embeddings — no cloud credentials needed.
"""

import pytest
from moss_core import Index, DocumentInfo


@pytest.fixture
def index():
    idx = Index("test-filter", "custom")
    docs = [
        DocumentInfo(id="1", text="coffee shop in NYC",   metadata={"city": "NYC",   "price": "12", "category": "food"}),
        DocumentInfo(id="2", text="sushi bar in Tokyo",   metadata={"city": "Tokyo", "price": "45", "category": "food"}),
        DocumentInfo(id="3", text="tech meetup in NYC",   metadata={"city": "NYC",   "price": "0",  "category": "tech"}),
        DocumentInfo(id="4", text="museum in Paris",      metadata={"city": "Paris", "price": "20", "category": "culture"}),
        DocumentInfo(id="5", text="street food in Tokyo", metadata={"city": "Tokyo", "price": "8",  "category": "food"}),
        DocumentInfo(id="6", text="no metadata doc"),
    ]
    embeddings = [
        [1.0, 0.0, 0.0, 0.0],
        [0.0, 1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0, 0.0],
        [0.0, 0.0, 0.0, 1.0],
        [0.5, 0.5, 0.0, 0.0],
        [0.1, 0.1, 0.1, 0.1],
    ]
    idx.add_documents(docs, embeddings)
    return idx


@pytest.fixture
def geo_index():
    idx = Index("test-geo", "custom")
    docs = [
        DocumentInfo(id="ts",  text="times square NYC",    metadata={"location": "40.7580,-73.9855"}),
        DocumentInfo(id="sol", text="statue of liberty",    metadata={"location": "40.6892,-74.0445"}),
        DocumentInfo(id="par", text="eiffel tower paris",   metadata={"location": "48.8566,2.3522"}),
        DocumentInfo(id="nol", text="doc without location", metadata={"city": "NYC"}),
    ]
    embeddings = [
        [1.0, 0.0, 0.0, 0.0],
        [0.0, 1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0, 0.0],
        [0.0, 0.0, 0.0, 1.0],
    ]
    idx.add_documents(docs, embeddings)
    return idx


QUERY_EMB = [1.0, 0.0, 0.0, 0.0]


def query_ids(idx, filt):
    result = idx.query("test", 10, QUERY_EMB, 0.8, filt)
    return sorted(d.id for d in result.docs)


class TestFilterConditions:
    def test_eq(self, index):
        assert query_ids(index, {"field": "city", "condition": {"$eq": "NYC"}}) == ["1", "3"]

    def test_ne(self, index):
        assert query_ids(index, {"field": "city", "condition": {"$ne": "NYC"}}) == ["2", "4", "5"]

    def test_gt_string(self, index):
        assert query_ids(index, {"field": "price", "condition": {"$gt": "10"}}) == ["1", "2", "4"]

    def test_gt_int_coercion(self, index):
        assert query_ids(index, {"field": "price", "condition": {"$gt": 10}}) == ["1", "2", "4"]

    def test_gt_float_coercion(self, index):
        assert query_ids(index, {"field": "price", "condition": {"$gt": 10.0}}) == ["1", "2", "4"]

    def test_lt(self, index):
        assert query_ids(index, {"field": "price", "condition": {"$lt": "15"}}) == ["1", "3", "5"]

    def test_gte(self, index):
        assert query_ids(index, {"field": "price", "condition": {"$gte": "20"}}) == ["2", "4"]

    def test_lte(self, index):
        assert query_ids(index, {"field": "price", "condition": {"$lte": "8"}}) == ["3", "5"]

    def test_in(self, index):
        assert query_ids(index, {"field": "city", "condition": {"$in": ["NYC", "Paris"]}}) == ["1", "3", "4"]

    def test_in_int_coercion(self, index):
        assert query_ids(index, {"field": "price", "condition": {"$in": [12, 20]}}) == ["1", "4"]

    def test_nin(self, index):
        assert query_ids(index, {"field": "city", "condition": {"$nin": ["NYC"]}}) == ["2", "4", "5"]


class TestCompositeFilters:
    def test_and(self, index):
        filt = {"$and": [
            {"field": "city", "condition": {"$eq": "NYC"}},
            {"field": "category", "condition": {"$eq": "food"}},
        ]}
        assert query_ids(index, filt) == ["1"]

    def test_or(self, index):
        filt = {"$or": [
            {"field": "city", "condition": {"$eq": "Paris"}},
            {"field": "category", "condition": {"$eq": "tech"}},
        ]}
        assert query_ids(index, filt) == ["3", "4"]

    def test_nested_and_or(self, index):
        filt = {"$and": [
            {"$or": [
                {"field": "city", "condition": {"$eq": "NYC"}},
                {"field": "city", "condition": {"$eq": "Tokyo"}},
            ]},
            {"field": "category", "condition": {"$eq": "food"}},
        ]}
        assert query_ids(index, filt) == ["1", "2", "5"]


class TestEdgeCases:
    def test_no_matches(self, index):
        assert query_ids(index, {"field": "city", "condition": {"$eq": "Berlin"}}) == []

    def test_skips_docs_without_metadata(self, index):
        ids = query_ids(index, {"field": "city", "condition": {"$ne": "nonexistent"}})
        assert "6" not in ids

    def test_no_filter_returns_all(self, index):
        result = index.query("test", 10, QUERY_EMB, 0.8, None)
        assert len(result.docs) == 6


class TestNearGeoFilter:
    def test_near_within_range(self, geo_index):
        # 10km around Times Square — should match ts (~0km) and sol (~8.7km)
        filt = {"field": "location", "condition": {"$near": "40.7580,-73.9855,10000"}}
        result = geo_index.query("test", 10, QUERY_EMB, 0.8, filt)
        ids = sorted(d.id for d in result.docs)
        assert "ts" in ids
        assert "sol" in ids
        assert "par" not in ids

    def test_near_excludes_far(self, geo_index):
        # 5km around Times Square — only ts (~0km), not sol (~8.7km)
        filt = {"field": "location", "condition": {"$near": "40.7580,-73.9855,5000"}}
        result = geo_index.query("test", 10, QUERY_EMB, 0.8, filt)
        ids = sorted(d.id for d in result.docs)
        assert "ts" in ids
        assert "sol" not in ids

    def test_near_skips_missing_location(self, geo_index):
        # doc "nol" has no location field — should not match
        filt = {"field": "location", "condition": {"$near": "40.7580,-73.9855,100000"}}
        result = geo_index.query("test", 10, QUERY_EMB, 0.8, filt)
        ids = [d.id for d in result.docs]
        assert "nol" not in ids

    def test_near_large_radius_matches_all_geo_docs(self, geo_index):
        # Huge radius — should match all docs that have location metadata
        filt = {"field": "location", "condition": {"$near": "40.7580,-73.9855,10000000"}}
        result = geo_index.query("test", 10, QUERY_EMB, 0.8, filt)
        ids = sorted(d.id for d in result.docs)
        assert ids == ["par", "sol", "ts"]


class TestHybridUnionBehavior:
    @pytest.fixture
    def hybrid_index(self):
        idx = Index("test-hybrid-union", "custom")
        docs = [
            DocumentInfo(id="emb1", text="noise text", metadata={"group": "keep"}),
            DocumentInfo(id="emb2", text="noise text", metadata={"group": "keep"}),
            DocumentInfo(id="cross", text="focusterm focusterm focusterm", metadata={"group": "keep"}),
            DocumentInfo(id="kw1", text="focusterm focusterm focusterm focusterm focusterm", metadata={"group": "keep"}),
            DocumentInfo(id="kw2", text="focusterm focusterm focusterm focusterm", metadata={"group": "keep"}),
            DocumentInfo(id="drop", text="irrelevant text", metadata={"group": "drop"}),
        ]
        embeddings = [
            [1.00, 0.0, 0.0, 0.0],
            [0.90, 0.0, 0.0, 0.0],
            [0.80, 0.0, 0.0, 0.0],
            [0.10, 0.0, 0.0, 0.0],
            [0.05, 0.0, 0.0, 0.0],
            [0.01, 0.0, 0.0, 0.0],
        ]
        idx.add_documents(docs, embeddings)
        return idx

    def test_cross_signal_doc_can_surface_with_deeper_fusion_depth(self, hybrid_index):
        result = hybrid_index.query("focusterm", 2, QUERY_EMB, 0.5, None)
        ids = [d.id for d in result.docs]
        assert "cross" in ids

    def test_hybrid_filter_still_enforced(self, hybrid_index):
        filt = {"field": "group", "condition": {"$eq": "keep"}}
        result = hybrid_index.query("focusterm", 4, QUERY_EMB, 0.5, filt)
        ids = [d.id for d in result.docs]
        assert "drop" not in ids
