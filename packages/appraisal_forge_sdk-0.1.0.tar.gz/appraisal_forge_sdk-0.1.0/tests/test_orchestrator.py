from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import Mock

from appraisal_forge_sdk.orchestrator import run_fill


def test_run_fill_creates_and_writes(tmp_path: Path) -> None:
    cfg = tmp_path / "fill.json"
    cfg.write_text(
        json.dumps(
            {
                "subject_address": "123 Main St, Raleigh, NC 27601",
                "report_name": "Main Report",
                "uad_fields": {"0100.0009": "Raleigh"},
                "validate_after": True,
            }
        )
    )

    client = Mock()
    client.create_appraisal.return_value = {"id": 77}
    client.validate.return_value = {"ok": True}

    out = run_fill(client, str(cfg))

    assert out["appraisal_id"] == 77
    assert out["fields_written"] == 1
    client.create_appraisal.assert_called_once()
    client.write_fields.assert_called_once_with(77, {"0100.0009": "Raleigh"})
    client.validate.assert_called_once_with(77)


def test_run_fill_dry_run(tmp_path: Path) -> None:
    cfg = tmp_path / "fill.json"
    cfg.write_text(json.dumps({"subject_address": "123 Main St", "uad_fields": {"0100.0009": "Raleigh"}}))

    client = Mock()
    out = run_fill(client, str(cfg), dry_run=True)

    assert out["dry_run"] is True
    assert out["appraisal_id"] == -1
    client.create_appraisal.assert_not_called()
    client.write_fields.assert_not_called()
