from .app import main

__version__ = "1.1.2"