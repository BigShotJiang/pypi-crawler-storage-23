"""
TrueZmanim TUI - A Text User Interface for Jewish prayer times (zmanim)
Based on the truezmanim.com API
"""

import asyncio
import aiohttp
import json
import os
import sys
from pathlib import Path
from datetime import date
from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.widgets import Input, Button, Static, Label, ListView, ListItem, Checkbox
from textual.events import Key
from textual import work

try:
    from talPYot.main import main as talPYot_main
except ImportError:
    talPYot_main = None


HEADERS = {
    'Referer': 'https://truezmanim.com/',
    'Origin': 'https://truezmanim.com'
}

API_BASE = "https://truezmanim.com/api"

SETTINGS_DIR = Path.home() / ".config" / "truezmanim"
SETTINGS_FILE = SETTINGS_DIR / "settings.json"


class ZmanimTUI(App):
    """A TUI app for viewing Jewish prayer times (zmanim)"""

    CSS = """
    Screen {
        background: $surface;
    }
    
    #main-container {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }
    
    #title {
        text-align: center;
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }
    
    #date-display {
        text-align: center;
        margin-bottom: 1;
    }
    
    #heb-date {
        text-align: center;
        color: $text-muted;
        margin-bottom: 1;
    }
    
    #parsha-display {
        text-align: center;
        color: $text-muted;
        margin-bottom: 1;
    }
    
    #input-row {
        height: auto;
        margin-bottom: 1;
    }
    
    #city-input {
        width: 40;
    }
    
    #suggestions {
        height: 8;
        border: solid $border;
        margin-bottom: 1;
    }
    
    #zmanim-display {
        width: 50%;
        height: 100%;
        border: solid $border;
    }
    
    #davening-angle {
        width: 50%;
        height: 100%;
        border: solid $border;
    }
    
    .zman-header {
        text-align: center;
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }
    
    .zman-row {
        height: 1;
    }
    
    .zman-name {
        width: 30;
        padding: 0 1;
    }
    
    .zman-time {
        width: 15;
        padding: 0 1;
    }
    
    .davening-row {
        padding: 0 1;
    }
    
    .davening-row.bold {
        text-style: bold;
    }
    
    .error-text {
        color: $error;
    }
    
    #loading {
        text-align: center;
        color: $accent;
    }
    
    #error {
        text-align: center;
        color: $error;
    }
    
    ListView {
        border: none;
    }

    #clear-btn {
        width: 3;
    }
    """

    def __init__(self):
        super().__init__()
        self.selected_city = ""
        self.selected_location = ""
        self.city_suggestions = []
        self.is_english = True
        self._debounce_timer = None
        self._zmanim_data = None  # Store fetched zmanim data
        
        # Load settings from file
        self._load_settings()
    
    def _load_settings(self) -> None:
        """Load settings from JSON file"""
        try:
            # Ensure settings directory exists
            SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
            if SETTINGS_FILE.exists():
                with open(SETTINGS_FILE, 'r') as f:
                    data = json.load(f)
                    self.selected_city = data.get('city', '') or ''
                    self.selected_location = data.get('location', '') or ''
                    self.is_english = data.get('is_english', True)
        except Exception as e:
            print(f"Error loading settings: {e}")
    
    def _save_settings(self) -> None:
        """Save settings to JSON file"""
        try:
            # Ensure settings directory exists
            SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                'city': self.selected_city,
                'location': self.selected_location,
                'is_english': self.is_english
            }
            with open(SETTINGS_FILE, 'w') as f:
                json.dump(data, f)
        except Exception as e:
            print(f"Error saving settings: {e}")

    def compose(self) -> ComposeResult:
        """Create the UI layout"""
        yield Container(
            Static("✡ TrueZmanim ✡", id="title"),
            Static(id="date-display"),
            Static(id="heb-date"),
            Static(id="parsha-display"),
            Horizontal(
                Input(placeholder="Enter city name...", id="city-input"),
                Button("X", id="clear-btn", variant="default"),
                Checkbox("English", id="lang-toggle", value=True),
                id="input-row"
            ),
            ListView(id="suggestions"),
            Static("", id="loading"),
            Static("", id="error"),
            Horizontal(
                Vertical(id="zmanim-display"),
                ScrollableContainer(id="davening-angle"),
            ),
            id="main-container"
        )

    def on_mount(self) -> None:
        """Initialize the app on mount"""
        self.update_date_display()
        # Set placeholder for heb-date
        self.query_one("#heb-date").update("📿 Loading...")
        self.query_one("#parsha-display").update("📖 Loading...")
        # Set language checkbox from saved settings
        lang_checkbox = self.query_one("#lang-toggle", Checkbox)
        lang_checkbox.value = self.is_english
        city_input = self.query_one("#city-input", Input)
        city = self.selected_city or ''
        location = self.selected_location or ''
        if city or location:
            city_input.value = city + ", " + location

        # Schedule the async functions
        asyncio.create_task(self._fetch_heb_date_async())
        asyncio.create_task(self._fetch_parsha_async())
        # If we have a saved city, fetch zmanim
        if self.selected_city and self.selected_location:
            asyncio.create_task(self._fetch_zmanim_async())

    async def _fetch_heb_date_async(self) -> None:
        """Fetch the Hebrew date - async version"""
        today = date.today()
        url = f"{API_BASE}/hebdate/{today.year}/{today.month:02d}/{today.day:02d}"
        print(f"Fetching heb date from: {url}")
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, headers=HEADERS) as response:
                    print(f"Hebrew date response status: {response.status}")
                    if response.status == 200:
                        data = await response.json()
                        print(f"Hebrew date API response: {data}")
                        self.update_heb_date(data)
            except Exception as e:
                print(f"Error fetching heb date: {e}")

    def update_date_display(self) -> None:
        """Update the current date display"""
        today = date.today()
        self.query_one("#date-display").update(f"{today.strftime('%A, %B %d, %Y')}")

    @work(exclusive=True)
    async def fetch_heb_date(self) -> None:
        """Fetch the Hebrew date"""
        today = date.today()
        url = f"{API_BASE}/hebdate/{today.year}/{today.month:02d}/{today.day:02d}"
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, headers=HEADERS) as response:
                    if response.status == 200:
                        data = await response.json()
                        print(f"Hebrew date API response: {data}")  # Debug
                        self.update_heb_date(data)
            except Exception as e:
                print(f"Error fetching heb date: {e}")  # Debug

    def update_heb_date(self, data: dict) -> None:
        """Update the Hebrew date display"""
        if data and 'heb_date' in data:
            self.query_one("#heb-date").update(f"{data['heb_date']}")

    async def _fetch_parsha_async(self) -> None:
        """Fetch the weekly parsha - async version"""
        today = date.today()
        url = f"{API_BASE}/parsha/{today.year}/{today.month:02d}/{today.day:02d}"
        print(f"Fetching parsha from: {url}")
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, headers=HEADERS) as response:
                    print(f"Parsha response status: {response.status}")
                    if response.status == 200:
                        data = await response.json()
                        print(f"Parsha API response: {data}")
                        self.update_parsha(data)
            except Exception as e:
                print(f"Error fetching parsha: {e}")

    def update_parsha(self, data: dict) -> None:
        """Update the parsha display"""
        if data and 'parsha' in data:
            self.query_one("#parsha-display").update(f"פרשת {data['parsha']}")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission (Enter key)"""
        if event.input.id == "city-input":
            query = event.input.value.strip()
            if len(query) >= 2:
                self.search_cities(query)

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle input change (each keystroke) with debounce"""
        if event.input.id == "city-input":
            # Cancel previous timer
            if self._debounce_timer:
                self._debounce_timer = None
            
            query = event.input.value.strip()
            if len(query) >= 3:
                # Schedule search after delay
                self.set_timer(0.3, lambda: self._debounced_search(event.input.value))
            else:
                # Clear suggestions if less than 3 chars
                suggestions = self.query_one("#suggestions", ListView)
                suggestions.clear()
                self.city_suggestions = []

    def _debounced_search(self, value: str) -> None:
        """Debounced search callback"""
        query = value.strip()
        if len(query) >= 3:
            asyncio.create_task(self._search_cities_async(query))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press"""
        if event.button.id == "clear-btn":
            # Clear the input and suggestions
            city_input = self.query_one("#city-input")
            city_input.value = ""
            city_input.focus()
            suggestions = self.query_one("#suggestions", ListView)
            suggestions.clear()
            self.city_suggestions = []

    @work(exclusive=True)
    async def search_cities(self, query: str) -> None:
        """Search for cities (for button click)"""
        await self._search_cities_async(query)

    async def _search_cities_async(self, query: str) -> None:
        """Search for cities - async version"""
        url = f"{API_BASE}/cities?q={query}"
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, headers=HEADERS) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.update_suggestions(data)
            except Exception as e:
                self.show_error(f"Error searching cities: {e}")

    def update_suggestions(self, cities: list) -> None:
        """Update city suggestions list"""
        self.city_suggestions = []
        suggestions = self.query_one("#suggestions", ListView)
        suggestions.clear()
        
        for idx, city in enumerate(cities[:10]):  # Limit to 10 suggestions
            is_heb_result = not city.get('city') and city.get('heb')
            city_name = city.get('heb') if is_heb_result else city.get('city', '')
            country = city.get('country', 'IL' if is_heb_result else '')
            state = city.get('state', '')
            
            if state:
                label = f"{city_name}, {state}, {country}"
            else:
                label = f"{city_name}, {country}"
            
            self.city_suggestions.append({
                'city': city_name,
                'country': country,
                'state': state,
                'label': label
            })
            suggestions.append(ListItem(Label(label)))

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Handle city selection from suggestions"""
        suggestions = self.query_one("#suggestions", ListView)
        index = event.list_view.index
        
        if index is not None and 0 <= index < len(self.city_suggestions):
            city_data = self.city_suggestions[index]
            self.selected_city = city_data['city']
            self.selected_location = city_data['state'] if city_data['state'] else city_data['country']
            
            # Update input with selected city
            city_input = self.query_one("#city-input")
            city_input.value = city_data['label']
            
            # Clear suggestions
            suggestions.clear()
            
            # Save settings
            self._save_settings()
            
            # Fetch zmanim
            self.fetch_zmanim()
            
            # Fetch talPYot (davening angle)
            self.fetch_talPYot()

    @work(exclusive=True)
    async def fetch_zmanim(self) -> None:
        """Fetch zmanim for the selected city"""
        await self._fetch_zmanim_async()

    async def _fetch_zmanim_async(self) -> None:
        """Fetch zmanim for the selected city - async version"""
        if not self.selected_city or not self.selected_location:
            return
        
        today = date.today()
        url = f"{API_BASE}/yom/{today.year}/{today.month:02d}/{today.day:02d}/{self.selected_city}/{self.selected_location}"
        print(f"Fetching zmanim from: {url}")
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, headers=HEADERS) as response:
                    print(f"Zmanim response status: {response.status}")
                    if response.status == 200:
                        data = await response.json()
                        print(f"Zmanim data received: {len(data)} items")
                        self.display_zmanim(data)
                    else:
                        self.show_error(f"Error: HTTP {response.status}")
            except Exception as e:
                self.show_error(f"Error fetching zmanim: {e}")

    def get_talPYot_results(self, location: str):
        """Get talPYot results for a location using sys.argv approach"""
        if talPYot_main is None:
            return {"error": "talPYot not installed"}
        
        import io
        from contextlib import redirect_stdout
        
        original_args = sys.argv
        sys.argv = ['talPYot', location]
        try:
            # Capture stdout
            output = io.StringIO()
            try:
                with redirect_stdout(output):
                    talPYot_main()
                result = json.loads(output.getvalue())
                return result
            except json.JSONDecodeError:
                return {"error": "Failed to parse talPYot output"}
        finally:
            sys.argv = original_args

    @work(exclusive=True)
    async def fetch_talPYot(self) -> None:
        """Fetch talPYot (davening angle) for the selected city"""
        await self._fetch_talPYot_async()

    async def _fetch_talPYot_async(self) -> None:
        """Fetch talPYot (davening angle) for the selected city - async version"""
        if not self.selected_city or not self.selected_location:
            return
        
        location = f"{self.selected_city}, {self.selected_location}"
        
        # Run in executor to avoid blocking the async loop
        loop = asyncio.get_event_loop()
        try:
            result = await loop.run_in_executor(None, self.get_talPYot_results, location)
            self.display_talPYot(result)
        except Exception as e:
            print(f"Error fetching talPYot: {e}")

    def display_talPYot(self, data: dict) -> None:
        """Display the talPYot (davening angle) results"""
        davening_display = self.query_one("#davening-angle", ScrollableContainer)
        davening_display.remove_children()
        
        # Add header
        davening_display.mount(Static("Davening Angle", classes="zman-header"))
        
        if not data:
            davening_display.mount(Static("No data available"))
            return
        
        if "error" in data:
            davening_display.mount(Static(f"Error: {data['error']}", classes="error-text"))
            return
        
        angle = data.get('DaveningAngle', 'N/A')
        # Round angle to nearest integer if it's a number
        if isinstance(angle, (int, float)):
            angle = round(angle)
        compass = data.get('DirectionCompass', 'N/A')
        davening_display.mount(Static(f"Angle: {angle}°", classes="davening-row bold"))
        davening_display.mount(Static(f"Direction:\n {compass}", classes="davening-row bold"))

    def display_zmanim(self, data: dict) -> None:
        """Display the zmanim"""
        self.hide_loading()
        self.clear_error()
        
        if not data:
            self.show_error("No data received")
            return
        
        # Store data for language switching
        self._zmanim_data = data
        self._render_zmanim()
        
        # Fetch talPYot after zmanim is displayed
        if self.selected_city and self.selected_location:
            asyncio.create_task(self._fetch_talPYot_async())
    
    def _render_zmanim(self) -> None:
        """Render the zmanim with current language setting"""
        if not self._zmanim_data:
            return
        
        data = self._zmanim_data
        zmanim_display = self.query_one("#zmanim-display", Vertical)
        davening_display = self.query_one("#davening-angle", ScrollableContainer)
        zmanim_display.remove_children()
        davening_display.remove_children()
        
        # Add header for zmanim display
        zmanim_display.mount(Static("Zmanim", classes="zman-header"))
        davening_display.mount(Static("Davening Angle", classes="zman-header"))
        
        # Sort by raw time
        keys = sorted(data.keys(), key=lambda k: data[k].get('raw', 0) if data[k].get('raw') is not None else float('inf'))
        
        for key in keys:
            item = data[key]
            raw = item.get('raw')
            
            if raw is not None and raw >= 0:
                if self.is_english:
                    name = item.get('eng', key)
                    time = item.get('am_pm', '')
                else:
                    name = item.get('heb', key)
                    time = item.get('clock_24', '')
                
                row = Horizontal(
                    Static(name, classes="zman-name"),
                    Static(time, classes="zman-time"),
                    classes="zman-row"
                )
                zmanim_display.mount(row)

    def on_checkbox_changed(self, event: Checkbox.Changed) -> None:
        """Handle checkbox state change"""
        if event.checkbox.id == "lang-toggle":
            self.is_english = event.checkbox.value
            # Save settings
            self._save_settings()
            # Re-render zmanim with new language
            if self._zmanim_data:
                self._render_zmanim()

    def show_loading(self, message: str) -> None:
        """Show loading message"""
        loading = self.query_one("#loading")
        loading.update(message)
        
    def hide_loading(self) -> None:
        """Hide loading message"""
        loading = self.query_one("#loading")
        loading.update("")

    def show_error(self, message: str) -> None:
        """Show error message"""
        self.hide_loading()
        error = self.query_one("#error")
        error.update(message)

    def clear_error(self) -> None:
        """Clear error message"""
        error = self.query_one("#error")
        error.update("")


def main():
    app = ZmanimTUI()
    app.run()

if __name__ == "__main__":
    main()