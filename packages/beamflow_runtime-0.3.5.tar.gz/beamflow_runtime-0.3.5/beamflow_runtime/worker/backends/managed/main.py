from fastapi import FastAPI
from beamflow_lib.config.runtime_config import RuntimeConfig
from .http_entrypoint import router
from beamflow_runtime.wiring.runtime import initialize_runtime

def create_app(config: RuntimeConfig) -> FastAPI:
    """
    Create the FastAPI application for the managed worker backend.
    """
    app = FastAPI(title="Managed Worker Runtime")
    
    # Include the task handling router
    app.include_router(router)
    
    @app.on_event("startup")
    async def startup_event():
        # Wire up the runtime (backend, clients, etc.)
        initialize_runtime(config)

    return app
