"""
AfriLink SLURM Job Management Module

Handles all SLURM interactions for CINECA Leonardo:
- Job script generation
- Job submission (sbatch)
- Job status queries (squeue, sacct)
- Job cancellation (scancel)
- Output retrieval

Designed to work with Singularity containers on HPC.
"""

import os
import re
import time
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field

# Import from SDK modules
from .finetune import FinetuneJobSpec, TrainingConfig
from .distributed import DistributedConfig, DistributedStrategy, TrainingScriptGenerator


@dataclass
class SlurmConfig:
    """SLURM cluster configuration for CINECA Leonardo"""

    # Partition configuration
    partition: str = "boost_usr_prod"  # CINECA GPU partition
    qos: str = "normal"
    account: str = "aih4a_dataspire"  # DataSpires' AIH4A allocation (lowercase)

    # Default resource limits
    default_gpus: int = 1
    default_cpus_per_gpu: int = 8 # Since 1 GPU gets counted as 1/4 node with 32 CPUs by default 
    default_memory_gb: int = 64
    default_time: str = "04:00:00"

    # GPU configuration (Leonardo specifics)
    gpus_per_node: int = 4  # A100 GPUs per node
    gpu_type: str = "a100"

    # Paths on CINECA
    work_dir: str = "$WORK"  # Expands to user's work directory
    scratch_dir: str = "$SCRATCH"
    singularity_cache: str = "$WORK/.singularity"

    # Module loads required
    # Note: Singularity is already available on Leonardo without module load
    # CUDA driver is provided by Singularity --nv flag from host
    # Container has all Python deps baked in
    modules: List[str] = field(default_factory=lambda: [
        "cuda/12.3",  # Available on Leonardo (12.2, 12.3, 12.6)
    ])


class SlurmScriptGenerator:
    """Generates SLURM batch scripts for CINECA"""

    SBATCH_TEMPLATE = '''#!/bin/bash
#SBATCH --job-name={job_name}
#SBATCH --output={output_dir}/logs/%x_%j.out
#SBATCH --error={output_dir}/logs/%x_%j.err
#SBATCH --partition={partition}
#SBATCH --qos={qos}
#SBATCH --account={account}
#SBATCH --nodes={nodes}
#SBATCH --ntasks-per-node={tasks_per_node}
#SBATCH --cpus-per-task={cpus_per_task}
#SBATCH --gpus-per-node={gpus_per_node}
#SBATCH --mem={memory}G
#SBATCH --time={time_limit}
{extra_sbatch}

# ============================================================
# AfriLink Finetune Job
# Job ID: {job_id}
# Model: {model}
# Training Mode: {training_mode}
# GPUs: {total_gpus}
# ============================================================

set -e

# Load required modules
{module_loads}

# Set up environment
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export CUDA_VISIBLE_DEVICES=$(seq -s, 0 $((SLURM_GPUS_ON_NODE-1)))

# Distributed training environment
export MASTER_ADDR=$(scontrol show hostnames $SLURM_JOB_NODELIST | head -n 1)
export MASTER_PORT=29500
export WORLD_SIZE=$SLURM_NTASKS
export RANK=$SLURM_PROCID

# HuggingFace cache directories
export HF_HOME=/workspace/.cache/huggingface
export TRANSFORMERS_CACHE=/workspace/.cache/transformers
export HF_DATASETS_CACHE=/workspace/.cache/datasets
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

# Create output directories
mkdir -p {output_dir}/logs
mkdir -p {output_dir}/checkpoints

# Create writable cache directory for HuggingFace (container filesystem is read-only)
mkdir -p $SCRATCH/.cache/huggingface
mkdir -p $SCRATCH/.cache/transformers
mkdir -p $SCRATCH/.cache/datasets

# Create job config for the training script
cat > {output_dir}/job_config.json << 'CONFIG_EOF'
{job_config_json}
CONFIG_EOF

# Run training with Singularity container
{singularity_command}

echo ""
echo "================================================"
echo "Job completed at $(date)"
echo "================================================"
'''

    def __init__(self, slurm_config: SlurmConfig):
        """
        Initialize script generator.

        Args:
            slurm_config: SLURM cluster configuration
        """
        self.config = slurm_config

    def _generate_module_loads(self) -> str:
        """Generate module load commands"""
        return "\n".join(f"module load {mod}" for mod in self.config.modules)

    def _generate_singularity_command(
        self,
        job_spec: FinetuneJobSpec,
        dist_config: DistributedConfig,
        sif_path: str,
    ) -> str:
        """Generate Singularity execution command"""

        # Base Singularity options
        sing_opts = [
            "--nv",  # NVIDIA GPU support
            "--cleanenv",  # Don't leak host environment (prevents /leonardo_work path issues)
            # Re-inject necessary SLURM env vars that got cleaned
            "--env SLURM_JOB_ID=$SLURM_JOB_ID",
            "--env SLURM_PROCID=$SLURM_PROCID",
            "--env SLURM_LOCALID=$SLURM_LOCALID",
            "--env SLURM_NTASKS=$SLURM_NTASKS",
            "--env SLURM_JOB_NODELIST=$SLURM_JOB_NODELIST",
            "--env CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES",
            # HuggingFace offline mode (model baked into container)
            "--env HF_HUB_OFFLINE=1",
            "--env TRANSFORMERS_OFFLINE=1",
            "--env HF_HOME=/workspace/.cache/huggingface",
            "--env TRANSFORMERS_CACHE=/workspace/.cache/transformers",
            "--env HF_DATASETS_CACHE=/workspace/.cache/datasets",
            # Bind directories
            "--bind $WORK:/workspace/work",
            "--bind $SCRATCH:/workspace/scratch",
            # Bind writable cache directory (container filesystem is read-only)
            "--bind $SCRATCH/.cache:/workspace/.cache",
            f"--bind {job_spec.output_dir}:/workspace/output",
            # Bind job config file
            f"--bind {job_spec.output_dir}/job_config.json:/workspace/job_config.json",
        ]

        # Add model and data bindings if they're paths
        if job_spec.model_path:
            sing_opts.append(f"--bind {job_spec.model_path}:/workspace/models")
        if job_spec.dataset_path:
            # Bind the dataset's parent DIRECTORY (not the file itself) to /workspace/data
            # This avoids Singularity file-to-directory bind issues
            dataset_dir = str(Path(job_spec.dataset_path).parent)
            sing_opts.append(f"--bind {dataset_dir}:/workspace/data")

        sing_opts_str = " \\\n    ".join(sing_opts)

        # Training command inside container
        train_cmd = "python /workspace/train/finetune.py"

        # For multi-GPU/multi-node, use srun + torchrun
        if dist_config.num_gpus > 1:
            if dist_config.strategy == DistributedStrategy.DDP:
                launcher = f"""srun --ntasks={dist_config.num_gpus} \\
    singularity exec {sing_opts_str} \\
    {sif_path} \\
    torchrun --nproc_per_node={self.config.gpus_per_node} \\
             --nnodes=$SLURM_NNODES \\
             --node_rank=$SLURM_NODEID \\
             --master_addr=$MASTER_ADDR \\
             --master_port=$MASTER_PORT \\
    {train_cmd}"""
            elif dist_config.strategy in [DistributedStrategy.DEEPSPEED_Z2, DistributedStrategy.DEEPSPEED_Z3]:
                launcher = f"""srun --ntasks={dist_config.num_gpus} \\
    singularity exec {sing_opts_str} \\
    {sif_path} \\
    deepspeed --num_gpus={dist_config.num_gpus} \\
              --num_nodes=$SLURM_NNODES \\
              --master_addr=$MASTER_ADDR \\
              --master_port=$MASTER_PORT \\
    {train_cmd}"""
            else:
                # FSDP uses torchrun same as DDP
                launcher = f"""srun --ntasks={dist_config.num_gpus} \\
    singularity exec {sing_opts_str} \\
    {sif_path} \\
    torchrun --nproc_per_node={self.config.gpus_per_node} \\
             --nnodes=$SLURM_NNODES \\
             --node_rank=$SLURM_NODEID \\
             --master_addr=$MASTER_ADDR \\
             --master_port=$MASTER_PORT \\
    {train_cmd}"""
        else:
            # Single GPU
            launcher = f"""singularity exec {sing_opts_str} \\
    {sif_path} \\
    {train_cmd}"""

        return launcher

    def generate(
        self,
        job_spec: FinetuneJobSpec,
        dist_config: DistributedConfig,
        sif_path: str,
    ) -> str:
        """
        Generate complete SLURM batch script.

        Args:
            job_spec: Finetune job specification
            dist_config: Distributed training configuration
            sif_path: Path to Singularity image

        Returns:
            Complete SLURM script as string
        """
        # Calculate nodes needed
        num_nodes = (job_spec.gpus + self.config.gpus_per_node - 1) // self.config.gpus_per_node
        gpus_per_node = min(job_spec.gpus, self.config.gpus_per_node)

        # Extra SBATCH directives
        extra_sbatch = ""
        if job_spec.gpus > self.config.gpus_per_node:
            extra_sbatch = f"#SBATCH --exclusive"

        # Generate job config JSON for the training script
        # The container expects model at /workspace/models/qwen2.5-0.5b (baked in)
        # Dataset directory is bound to /workspace/data/, so use the actual filename
        import json
        dataset_filename = Path(job_spec.dataset_path).name if job_spec.dataset_path else "train.jsonl"
        job_config = {
            "model_path": "/workspace/models/qwen2.5-0.5b",
            "dataset_path": f"/workspace/data/{dataset_filename}",
            "output_dir": "/workspace/output",
            "lora_r": job_spec.training_config.lora_r if job_spec.training_config else 8,
            "lora_alpha": job_spec.training_config.lora_alpha if job_spec.training_config else 16,
            "batch_size": job_spec.training_config.batch_size if job_spec.training_config else 2,
            "gradient_accumulation_steps": job_spec.training_config.gradient_accumulation_steps if job_spec.training_config else 8,
            "num_epochs": job_spec.training_config.num_epochs if job_spec.training_config else 3,
            "learning_rate": job_spec.training_config.learning_rate if job_spec.training_config else 2e-4,
        }
        job_config_json = json.dumps(job_config, indent=2)

        return self.SBATCH_TEMPLATE.format(
            job_name=job_spec.job_name,
            job_id=job_spec.job_id,
            model=job_spec.model,
            training_mode=job_spec.training_mode.value,
            total_gpus=job_spec.gpus,
            partition=self.config.partition,
            qos=self.config.qos,
            account=self.config.account,
            nodes=num_nodes,
            tasks_per_node=gpus_per_node,
            cpus_per_task=job_spec.cpus_per_gpu,
            gpus_per_node=gpus_per_node,
            memory=job_spec.memory_gb,
            time_limit=job_spec.time_limit,
            extra_sbatch=extra_sbatch,
            output_dir=job_spec.output_dir,
            module_loads=self._generate_module_loads(),
            singularity_command=self._generate_singularity_command(job_spec, dist_config, sif_path),
            job_config_json=job_config_json,
        )


class SlurmJobManager:
    """
    Manages SLURM job lifecycle on CINECA Leonardo.

    Requires an authenticated CinecaDirectAuth client for SSH access.
    """

    def __init__(
        self,
        cineca_auth,
        slurm_config: SlurmConfig = None,
    ):
        """
        Initialize SLURM job manager.

        Args:
            cineca_auth: Authenticated CinecaDirectAuth instance
            slurm_config: SLURM configuration (default: CINECA Leonardo)
        """
        self.auth = cineca_auth
        self.config = slurm_config or SlurmConfig()
        self.script_generator = SlurmScriptGenerator(self.config)

        # Track submitted jobs
        self._jobs: Dict[str, Dict[str, Any]] = {}

    def _run_ssh(self, command: str, timeout: int = 60) -> Tuple[int, str, str]:
        """Run command on CINECA via SSH"""
        return self.auth.run_ssh_command(command, timeout=timeout)

    def _resolve_work_path(self) -> str:
        """Resolve $WORK to actual path on CINECA (needed for SBATCH directives)"""
        code, stdout, _ = self._run_ssh("echo $WORK")
        if code == 0 and stdout.strip():
            return stdout.strip()
        # Fallback to common CINECA pattern
        code, stdout, _ = self._run_ssh("echo $USER")
        if code == 0 and stdout.strip():
            return f"/leonardo_work/AIH4A_dataspire"
        return "/leonardo_work/AIH4A_dataspire"

    def submit_job(
        self,
        job_spec: FinetuneJobSpec,
        sif_path: str = None,
    ) -> str:
        """
        Submit a finetune job to SLURM.

        Args:
            job_spec: Job specification
            sif_path: Path to Singularity image on CINECA

        Returns:
            SLURM job ID

        Raises:
            RuntimeError: If submission fails
        """
        # Resolve $WORK to actual path (SBATCH directives don't expand env vars)
        work_path = self._resolve_work_path()

        # Replace $WORK in paths with actual path for SBATCH compatibility
        # Make output dir job-specific to isolate each job's artifacts (model, logs, checkpoints)
        resolved_output_dir = f"{job_spec.output_dir}/{job_spec.job_id}".replace("$WORK", work_path)

        # Get optimal distributed strategy
        from .distributed import DistributedConfig
        dist_config = DistributedConfig.auto(
            num_gpus=job_spec.gpus,
            model_size_b=7.0,  # Default assumption
        )

        # Resolve $WORK in SIF path (caller must provide sif_path)
        if not sif_path:
            raise ValueError("sif_path is required — no container path provided")
        sif_path = sif_path.replace("$WORK", work_path)

        # Temporarily update job_spec paths for script generation
        original_output_dir = job_spec.output_dir
        original_dataset_path = job_spec.dataset_path
        original_model_path = job_spec.model_path

        job_spec.output_dir = resolved_output_dir
        if job_spec.dataset_path:
            job_spec.dataset_path = job_spec.dataset_path.replace("$WORK", work_path)
        if job_spec.model_path:
            job_spec.model_path = job_spec.model_path.replace("$WORK", work_path)

        # Also resolve work_dir in config for script generation
        original_work_dir = self.config.work_dir
        self.config.work_dir = work_path

        # Generate SLURM script with resolved paths
        script = self.script_generator.generate(job_spec, dist_config, sif_path)

        # Restore original values
        job_spec.output_dir = original_output_dir
        job_spec.dataset_path = original_dataset_path
        job_spec.model_path = original_model_path
        self.config.work_dir = original_work_dir

        # Write script to CINECA
        script_path = f"{work_path}/jobs/{job_spec.job_id}.sbatch"

        # Create job directory and output log directory (SLURM needs log dir to exist before job starts)
        code, _, err = self._run_ssh(f"mkdir -p {work_path}/jobs {resolved_output_dir}/logs")
        if code != 0:
            raise RuntimeError(f"Failed to create directories: {err}")

        # Write script via heredoc
        escaped_script = script.replace("'", "'\\''")
        code, _, err = self._run_ssh(f"cat > {script_path} << 'SBATCH_EOF'\n{script}\nSBATCH_EOF")
        if code != 0:
            raise RuntimeError(f"Failed to write job script: {err}")

        # Submit job
        code, stdout, err = self._run_ssh(f"sbatch {script_path}")
        if code != 0:
            raise RuntimeError(f"sbatch failed: {err}")

        # Parse job ID from output: "Submitted batch job 12345678"
        match = re.search(r'Submitted batch job (\d+)', stdout)
        if not match:
            raise RuntimeError(f"Could not parse job ID from: {stdout}")

        slurm_job_id = match.group(1)

        # Track job
        self._jobs[slurm_job_id] = {
            "job_spec": job_spec,
            "script_path": script_path,
            "submitted_at": time.time(),
            "status": "PENDING",
        }

        return slurm_job_id

    def get_job_status(self, slurm_job_id: str) -> Dict[str, Any]:
        """
        Get current job status.

        Args:
            slurm_job_id: SLURM job ID

        Returns:
            Dict with job status information
        """
        # Try squeue first (for running/pending jobs)
        code, stdout, _ = self._run_ssh(
            f"squeue -j {slurm_job_id} -o '%T|%M|%N|%r' --noheader"
        )

        if code == 0 and stdout.strip():
            parts = stdout.strip().split('|')
            state = parts[0] if len(parts) > 0 else "UNKNOWN"
            elapsed = parts[1] if len(parts) > 1 else "0:00"
            node = parts[2] if len(parts) > 2 else ""
            reason = parts[3] if len(parts) > 3 else ""

            return {
                "job_id": slurm_job_id,
                "state": state,
                "elapsed_time": elapsed,
                "node": node,
                "reason": reason,
            }

        # Job not in queue - check sacct for completed jobs
        code, stdout, _ = self._run_ssh(
            f"sacct -j {slurm_job_id} -o State,Elapsed,ExitCode --noheader -n"
        )

        if code == 0 and stdout.strip():
            lines = stdout.strip().split('\n')
            # First line is the job, subsequent lines are steps
            parts = lines[0].split()
            state = parts[0] if len(parts) > 0 else "UNKNOWN"
            elapsed = parts[1] if len(parts) > 1 else "0:00:00"
            exit_code = parts[2] if len(parts) > 2 else "0:0"

            return {
                "job_id": slurm_job_id,
                "state": state,
                "elapsed_time": elapsed,
                "exit_code": exit_code,
            }

        return {
            "job_id": slurm_job_id,
            "state": "UNKNOWN",
            "error": "Could not retrieve job status",
        }

    def cancel_job(self, slurm_job_id: str) -> bool:
        """
        Cancel a running or pending job.

        Args:
            slurm_job_id: SLURM job ID

        Returns:
            True if cancelled successfully
        """
        code, stdout, err = self._run_ssh(f"scancel {slurm_job_id}")

        if code == 0:
            if slurm_job_id in self._jobs:
                self._jobs[slurm_job_id]["status"] = "CANCELLED"
            return True

        print(f"scancel failed: {err}")
        return False

    def get_job_logs(self, slurm_job_id: str, tail: int = 100) -> str:
        """
        Get job output logs.

        Args:
            slurm_job_id: SLURM job ID
            tail: Number of lines to return

        Returns:
            Log content
        """
        # Find the job's output file (logs are in job-specific output dir)
        if slurm_job_id in self._jobs:
            job_spec = self._jobs[slurm_job_id]["job_spec"]
            log_pattern = f"{job_spec.output_dir}/{job_spec.job_id}/logs/*_{slurm_job_id}.out"
        else:
            log_pattern = f"{self.config.work_dir}/**/logs/*_{slurm_job_id}.out"

        code, stdout, _ = self._run_ssh(f"tail -n {tail} {log_pattern} 2>/dev/null || echo 'Log file not found'")

        return stdout

    def get_job_error(self, slurm_job_id: str) -> str:
        """
        Get job error logs.

        Args:
            slurm_job_id: SLURM job ID

        Returns:
            Error log content
        """
        if slurm_job_id in self._jobs:
            job_spec = self._jobs[slurm_job_id]["job_spec"]
            log_pattern = f"{job_spec.output_dir}/{job_spec.job_id}/logs/*_{slurm_job_id}.err"
        else:
            log_pattern = f"{self.config.work_dir}/**/logs/*_{slurm_job_id}.err"

        code, stdout, _ = self._run_ssh(f"cat {log_pattern} 2>/dev/null || echo 'Error file not found'")

        return stdout

    def get_job_output(self, slurm_job_id: str) -> Dict[str, Any]:
        """
        Get job output paths after completion.

        Args:
            slurm_job_id: SLURM job ID

        Returns:
            Dict with output paths
        """
        if slurm_job_id not in self._jobs:
            return {"error": "Job not tracked"}

        job_spec = self._jobs[slurm_job_id]["job_spec"]
        output_base = f"{self.config.work_dir}/finetune_outputs/{job_spec.job_id}"

        # Check if output exists
        code, stdout, _ = self._run_ssh(f"ls {output_base}/ 2>/dev/null")

        if code == 0:
            return {
                "output_dir": output_base,
                "model_path": f"{output_base}/",
                "files": stdout.strip().split('\n') if stdout.strip() else [],
            }

        return {
            "error": "Output not found",
            "expected_path": output_base,
        }

    def list_jobs(self, user_only: bool = True) -> List[Dict[str, Any]]:
        """
        List SLURM jobs.

        Args:
            user_only: Only show current user's jobs

        Returns:
            List of job info dicts
        """
        user_filter = "-u $USER" if user_only else ""
        code, stdout, _ = self._run_ssh(
            f"squeue {user_filter} -o '%i|%j|%T|%M|%D|%C' --noheader"
        )

        if code != 0 or not stdout.strip():
            return []

        jobs = []
        for line in stdout.strip().split('\n'):
            parts = line.split('|')
            if len(parts) >= 6:
                jobs.append({
                    "job_id": parts[0],
                    "name": parts[1],
                    "state": parts[2],
                    "time": parts[3],
                    "nodes": parts[4],
                    "cpus": parts[5],
                })

        return jobs

    def get_queue_info(self) -> Dict[str, Any]:
        """
        Get queue status information.

        Returns:
            Dict with queue info
        """
        code, stdout, _ = self._run_ssh(
            f"sinfo -p {self.config.partition} -o '%P|%a|%l|%D|%T|%N' --noheader"
        )

        if code != 0:
            return {"error": "Could not get queue info"}

        return {
            "partition": self.config.partition,
            "raw_output": stdout.strip(),
        }
