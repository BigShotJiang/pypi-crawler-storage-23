"""
AfriLink Data Transfer Module

Handles data transfer between Colab/local environments and CINECA:
- Upload datasets to CINECA
- Download trained model weights from CINECA
- Sync files between environments
- Progress tracking

Uses SSH/SCP for secure transfers.
"""

import os
import sys
import time
import subprocess
import tempfile
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable, Tuple
from dataclasses import dataclass


@dataclass
class TransferProgress:
    """Progress information for file transfer"""
    filename: str
    total_bytes: int
    transferred_bytes: int
    percent_complete: float
    speed_mbps: float
    eta_seconds: Optional[int]
    status: str  # "in_progress", "completed", "failed"


@dataclass
class TransferResult:
    """Result of a transfer operation"""
    success: bool
    source: str
    destination: str
    bytes_transferred: int
    duration_seconds: float
    error: Optional[str] = None


class DataTransferManager:
    """
    Manages data transfer between local environment and CINECA.

    Uses SCP for file transfers over authenticated SSH.
    """

    def __init__(
        self,
        cineca_auth,
        work_dir: str = "$WORK",
    ):
        """
        Initialize transfer manager.

        Args:
            cineca_auth: Authenticated CinecaDirectAuth instance
            work_dir: Base working directory on CINECA
        """
        self.auth = cineca_auth
        self.work_dir = work_dir
        self.username = cineca_auth.username
        self.host = cineca_auth.CINECA_HOST

        # Transfer tracking
        self._active_transfers: Dict[str, TransferProgress] = {}

        # Clear any stale host keys on initialization
        self._clear_stale_host_keys()

    def _clear_stale_host_keys(self):
        """
        Clear any stale host keys for CINECA from known_hosts.

        This prevents "REMOTE HOST IDENTIFICATION HAS CHANGED" errors
        when CINECA updates their server keys or when the runtime
        has a known_hosts file from a previous session with different keys.
        """
        known_hosts = Path.home() / ".ssh" / "known_hosts"
        if known_hosts.exists():
            try:
                subprocess.run(
                    ["ssh-keygen", "-R", self.host],
                    capture_output=True,
                    timeout=5,
                )
            except Exception:
                pass  # Ignore errors - file might not have the entry

    def _build_scp_command(
        self,
        source: str,
        destination: str,
        recursive: bool = False,
    ) -> List[str]:
        """Build SCP command with appropriate options"""
        cmd = [
            "scp",
            "-o", "StrictHostKeyChecking=accept-new",
            "-o", "BatchMode=yes",
        ]

        # Add key file if available on disk
        if isinstance(self.auth.key_path, Path) and self.auth.key_path.exists():
            cmd.extend(["-i", str(self.auth.key_path)])

        if recursive:
            cmd.append("-r")

        cmd.extend([source, destination])
        return cmd

    def _build_rsync_command(
        self,
        source: str,
        destination: str,
        delete: bool = False,
    ) -> List[str]:
        """Build rsync command for efficient sync"""
        cmd = [
            "rsync",
            "-avz",  # archive, verbose, compress
            "--progress",
            "-e", "ssh -o StrictHostKeyChecking=accept-new -o BatchMode=yes",
        ]

        # Add key file if available
        if isinstance(self.auth.key_path, Path) and self.auth.key_path.exists():
            cmd[-1] += f" -i {self.auth.key_path}"

        if delete:
            cmd.append("--delete")

        cmd.extend([source, destination])
        return cmd

    def _run_transfer(
        self,
        cmd: List[str],
        progress_callback: Callable[[TransferProgress], None] = None,
    ) -> Tuple[int, str, str]:
        """Run transfer command with optional progress tracking"""
        # Always clear stale host keys before transfer to prevent
        # "REMOTE HOST IDENTIFICATION HAS CHANGED" errors
        self._clear_stale_host_keys()

        start_time = time.time()

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        stdout, stderr = process.communicate()
        duration = time.time() - start_time

        return process.returncode, stdout, stderr

    def upload_file(
        self,
        local_path: str,
        remote_path: str = None,
        progress_callback: Callable[[TransferProgress], None] = None,
    ) -> TransferResult:
        """
        Upload a file to CINECA.

        Args:
            local_path: Path to local file
            remote_path: Destination path on CINECA (default: $WORK/uploads/)
            progress_callback: Optional callback for progress updates

        Returns:
            TransferResult
        """
        local_path = Path(local_path)
        if not local_path.exists():
            return TransferResult(
                success=False,
                source=str(local_path),
                destination=remote_path or "",
                bytes_transferred=0,
                duration_seconds=0,
                error=f"Local file not found: {local_path}",
            )

        # Default remote path
        if remote_path is None:
            remote_path = f"{self.work_dir}/uploads/{local_path.name}"

        # Ensure remote directory exists
        remote_dir = str(Path(remote_path).parent)
        self.auth.run_ssh_command(f"mkdir -p {remote_dir}")

        # Build destination
        destination = f"{self.username}@{self.host}:{remote_path}"

        start_time = time.time()

        cmd = self._build_scp_command(str(local_path), destination)
        code, stdout, stderr = self._run_transfer(cmd, progress_callback)

        duration = time.time() - start_time
        file_size = local_path.stat().st_size

        if code == 0:
            return TransferResult(
                success=True,
                source=str(local_path),
                destination=remote_path,
                bytes_transferred=file_size,
                duration_seconds=duration,
            )
        else:
            return TransferResult(
                success=False,
                source=str(local_path),
                destination=remote_path,
                bytes_transferred=0,
                duration_seconds=duration,
                error=stderr,
            )

    def upload_directory(
        self,
        local_dir: str,
        remote_dir: str = None,
        progress_callback: Callable[[TransferProgress], None] = None,
    ) -> TransferResult:
        """
        Upload a directory to CINECA.

        Args:
            local_dir: Path to local directory
            remote_dir: Destination directory on CINECA
            progress_callback: Optional callback for progress updates

        Returns:
            TransferResult
        """
        local_dir = Path(local_dir)
        if not local_dir.is_dir():
            return TransferResult(
                success=False,
                source=str(local_dir),
                destination=remote_dir or "",
                bytes_transferred=0,
                duration_seconds=0,
                error=f"Local directory not found: {local_dir}",
            )

        # Default remote path
        if remote_dir is None:
            remote_dir = f"{self.work_dir}/uploads/{local_dir.name}"

        # Ensure remote parent directory exists
        self.auth.run_ssh_command(f"mkdir -p {remote_dir}")

        # Build destination
        destination = f"{self.username}@{self.host}:{remote_dir}"

        start_time = time.time()

        cmd = self._build_scp_command(str(local_dir), destination, recursive=True)
        code, stdout, stderr = self._run_transfer(cmd, progress_callback)

        duration = time.time() - start_time

        # Calculate total size
        total_size = sum(f.stat().st_size for f in local_dir.rglob("*") if f.is_file())

        if code == 0:
            return TransferResult(
                success=True,
                source=str(local_dir),
                destination=remote_dir,
                bytes_transferred=total_size,
                duration_seconds=duration,
            )
        else:
            return TransferResult(
                success=False,
                source=str(local_dir),
                destination=remote_dir,
                bytes_transferred=0,
                duration_seconds=duration,
                error=stderr,
            )

    def download_file(
        self,
        remote_path: str,
        local_path: str = None,
        progress_callback: Callable[[TransferProgress], None] = None,
    ) -> TransferResult:
        """
        Download a file from CINECA.

        Args:
            remote_path: Path on CINECA
            local_path: Local destination (default: current directory)
            progress_callback: Optional callback for progress updates

        Returns:
            TransferResult
        """
        # Default local path
        if local_path is None:
            local_path = Path(remote_path).name

        local_path = Path(local_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)

        # Build source
        source = f"{self.username}@{self.host}:{remote_path}"

        start_time = time.time()

        cmd = self._build_scp_command(source, str(local_path))
        code, stdout, stderr = self._run_transfer(cmd, progress_callback)

        duration = time.time() - start_time

        if code == 0 and local_path.exists():
            file_size = local_path.stat().st_size
            return TransferResult(
                success=True,
                source=remote_path,
                destination=str(local_path),
                bytes_transferred=file_size,
                duration_seconds=duration,
            )
        else:
            return TransferResult(
                success=False,
                source=remote_path,
                destination=str(local_path),
                bytes_transferred=0,
                duration_seconds=duration,
                error=stderr,
            )

    def download_directory(
        self,
        remote_dir: str,
        local_dir: str = None,
        progress_callback: Callable[[TransferProgress], None] = None,
    ) -> TransferResult:
        """
        Download a directory from CINECA.

        Args:
            remote_dir: Directory path on CINECA
            local_dir: Local destination directory
            progress_callback: Optional callback for progress updates

        Returns:
            TransferResult
        """
        # Default local path
        if local_dir is None:
            local_dir = Path(remote_dir).name

        local_dir = Path(local_dir)
        local_dir.mkdir(parents=True, exist_ok=True)

        # Build source (add trailing slash to copy contents)
        source = f"{self.username}@{self.host}:{remote_dir}/"

        start_time = time.time()

        cmd = self._build_scp_command(source, str(local_dir), recursive=True)
        code, stdout, stderr = self._run_transfer(cmd, progress_callback)

        duration = time.time() - start_time

        if code == 0:
            # Calculate downloaded size
            total_size = sum(f.stat().st_size for f in local_dir.rglob("*") if f.is_file())
            return TransferResult(
                success=True,
                source=remote_dir,
                destination=str(local_dir),
                bytes_transferred=total_size,
                duration_seconds=duration,
            )
        else:
            return TransferResult(
                success=False,
                source=remote_dir,
                destination=str(local_dir),
                bytes_transferred=0,
                duration_seconds=duration,
                error=stderr,
            )

    def download_model_weights(
        self,
        job_id: str,
        local_dir: str = None,
    ) -> TransferResult:
        """
        Download trained model weights from a completed finetune job.

        Downloads only the model adapter files (not logs/checkpoints) and places
        them directly in local_dir so it can be used with PeftModel.from_pretrained().

        Args:
            job_id: Finetune job ID
            local_dir: Local destination directory

        Returns:
            TransferResult
        """
        remote_dir = f"{self.work_dir}/finetune_outputs/{job_id}"
        local_dir = local_dir or f"./models/{job_id}"

        # Check if remote directory exists and list model files
        code, stdout, stderr = self.auth.run_ssh_command(f"ls {remote_dir}")
        if code != 0:
            return TransferResult(
                success=False,
                source=remote_dir,
                destination=local_dir,
                bytes_transferred=0,
                duration_seconds=0,
                error=f"Model output not found: {remote_dir}",
            )

        # Verify adapter files actually exist (job may have failed)
        check_code, check_out, _ = self.auth.run_ssh_command(
            f"test -f {remote_dir}/adapter_config.json && echo found || echo missing"
        )
        if "missing" in (check_out or ""):
            return TransferResult(
                success=False,
                source=remote_dir,
                destination=local_dir,
                bytes_transferred=0,
                duration_seconds=0,
                error=f"No adapter_config.json found — training job likely failed",
            )

        # Download individual model files (not logs/checkpoints dirs) directly into local_dir
        # This ensures PeftModel.from_pretrained(local_dir) works without extra nesting
        model_files = [
            "adapter_config.json",
            "adapter_model.safetensors",
            "added_tokens.json",
            "special_tokens_map.json",
            "tokenizer_config.json",
            "tokenizer.json",
            "merges.txt",
            "vocab.json",
            "training_args.bin",
            "README.md",
        ]

        local_path = Path(local_dir)
        local_path.mkdir(parents=True, exist_ok=True)

        start_time = time.time()
        total_bytes = 0
        errors = []

        for fname in model_files:
            remote_file = f"{remote_dir}/{fname}"
            # Check if file exists before downloading
            check_code, _, _ = self.auth.run_ssh_command(f"test -f {remote_file} && echo ok")
            if check_code != 0:
                continue

            source = f"{self.username}@{self.host}:{remote_file}"
            dest = str(local_path / fname)
            cmd = self._build_scp_command(source, dest)
            code, _, err = self._run_transfer(cmd)
            if code == 0:
                fsize = (local_path / fname).stat().st_size
                total_bytes += fsize
            else:
                errors.append(f"{fname}: {err}")

        duration = time.time() - start_time

        if errors:
            pass  # Errors captured in TransferResult

        return TransferResult(
            success=len(errors) == 0,
            source=remote_dir,
            destination=str(local_dir),
            bytes_transferred=total_bytes,
            duration_seconds=duration,
            error="; ".join(errors) if errors else None,
        )

    def upload_dataset(
        self,
        local_path: str,
        dataset_name: str = None,
    ) -> TransferResult:
        """
        Upload a dataset to CINECA for training.

        Args:
            local_path: Path to local dataset file or directory
            dataset_name: Name for the dataset on CINECA

        Returns:
            TransferResult
        """
        local_path = Path(local_path)
        dataset_name = dataset_name or local_path.stem

        remote_path = f"{self.work_dir}/datasets/{dataset_name}"

        if local_path.is_file():
            remote_file = f"{remote_path}/{local_path.name}"
            self.auth.run_ssh_command(f"mkdir -p {remote_path}")
            return self.upload_file(str(local_path), remote_file)
        else:
            return self.upload_directory(str(local_path), remote_path)

    def list_remote_files(self, remote_path: str) -> List[Dict[str, Any]]:
        """
        List files in a remote directory.

        Args:
            remote_path: Path on CINECA

        Returns:
            List of file info dicts
        """
        code, stdout, stderr = self.auth.run_ssh_command(
            f"ls -la {remote_path} 2>/dev/null || echo 'Directory not found'"
        )

        if code != 0 or "Directory not found" in stdout:
            return []

        files = []
        for line in stdout.strip().split('\n')[1:]:  # Skip total line
            parts = line.split()
            if len(parts) >= 9:
                files.append({
                    "permissions": parts[0],
                    "size": int(parts[4]) if parts[4].isdigit() else 0,
                    "date": f"{parts[5]} {parts[6]} {parts[7]}",
                    "name": " ".join(parts[8:]),
                })

        return files

    def get_remote_size(self, remote_path: str) -> int:
        """
        Get size of remote file or directory in bytes.

        Args:
            remote_path: Path on CINECA

        Returns:
            Size in bytes
        """
        code, stdout, stderr = self.auth.run_ssh_command(
            f"du -sb {remote_path} 2>/dev/null | cut -f1"
        )

        if code == 0 and stdout.strip().isdigit():
            return int(stdout.strip())

        return 0


def create_transfer_manager(cineca_auth) -> DataTransferManager:
    """
    Create a data transfer manager.

    Args:
        cineca_auth: Authenticated CinecaDirectAuth instance

    Returns:
        Configured DataTransferManager
    """
    return DataTransferManager(cineca_auth)
