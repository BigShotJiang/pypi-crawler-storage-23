"""Gen Agent — AI assistant conversations with streaming.

In this example, we:
  - Create a Gen Agent conversation and stream the response
  - Send a message with an attached image for context
  - Show the non-streaming alternative

Gen Agent is SeaArt's general-purpose AI assistant. Unlike character chat,
it is not tied to a specific persona and supports image attachments.

Requires:
    SEAART_EMAIL and SEAART_PASSWORD environment variables.
"""

from __future__ import annotations

import os

from seaart import SyncClient
from seaart.options import GenAgentReqOptions
from seaart.options.gen_agent_messages import ImagePartOptions


# ---------------------------------------------------------------------------
# Streaming
# ---------------------------------------------------------------------------


def streaming() -> None:
    """Stream Gen Agent response chunk by chunk."""
    with SyncClient() as client:
        client.auth.login(
            email=os.environ["SEAART_EMAIL"],
            password=os.environ["SEAART_PASSWORD"],
        )

        conv = client.genagent.create()
        conv_id = conv.value.conv_id

        try:
            for item in client.genagent.messages.stream(
                "Write a prompt for the character Amelia Watson.",
                conv_id,
            ):
                if item.event == "message":
                    print(item.text, end="", flush=True)
            print()
        finally:
            client.genagent.delete(conv_id)


# ---------------------------------------------------------------------------
# Non-streaming
# ---------------------------------------------------------------------------


def non_streaming() -> None:
    """Send a message and get the complete response."""
    with SyncClient() as client:
        client.auth.login(
            email=os.environ["SEAART_EMAIL"],
            password=os.environ["SEAART_PASSWORD"],
        )

        conv = client.genagent.create()
        conv_id = conv.value.conv_id

        try:
            result = client.genagent.messages.send(
                "What makes a good portrait photograph?",
                conv_id,
            )
            if result:
                print(result.text)
        finally:
            client.genagent.delete(conv_id)


# ---------------------------------------------------------------------------
# Image attachments
# ---------------------------------------------------------------------------


def with_image() -> None:
    """Attach an image and ask a question about it.

    Pass images via GenAgentReqOptions. The agent can analyze
    the image and incorporate it into its response.
    """
    with SyncClient() as client:
        client.auth.login(
            email=os.environ["SEAART_EMAIL"],
            password=os.environ["SEAART_PASSWORD"],
        )

        conv = client.genagent.create()
        conv_id = conv.value.conv_id

        try:
            result = client.genagent.messages.send(
                "How can I generate something like this?",
                conv_id,
                options=GenAgentReqOptions(
                    images=[
                        ImagePartOptions(
                            url="https://www.seaart.ai/images/1a2b3c4d5e/abc123.jpg",
                        )
                    ]
                ),
            )
            if result:
                print(result.text)
        finally:
            client.genagent.delete(conv_id)


if __name__ == "__main__":
    streaming()