"""Quickstart — from zero to a working result in minutes.

The shortest path to using the SeaArt SDK:
  1. Create a client and log in
  2. Chat with an AI character
  3. Generate an image from a text prompt

For more detailed examples, see the other files in this directory:
  auth.py              — authentication methods
  characters_chat.py   — sessions, history, settings, voice
  characters_stream.py — real-time streaming
  image_generation.py  — text-to-image, upscaling, and more
  gen_agent.py         — AI assistant conversations
  search.py            — search characters, models, works
  async_usage.py       — concurrent operations with AsyncClient

Requires:
    SEAART_EMAIL and SEAART_PASSWORD environment variables
    for image generation. No credentials needed for character chat.
"""

from __future__ import annotations

import os

from seaart import SyncClient
from seaart.helpers import extract_character_link, extract_model_link
from seaart.types import AppId

CHARACTER_URL = (
    "https://www.seaart.ai/ru/character/chat/d5f5v2te878c73cmjhhg?from=null&s_id=123"
)
MODEL_URL = "https://www.seaart.ai/create/image?id=cu8d8ble878c738hejd0&model_ver_no=f1ebdcc036b767a672db420eb367688d"


# ---------------------------------------------------------------------------
# Character chat (no account needed)
# ---------------------------------------------------------------------------


def chat_with_character() -> None:
    """Send a message to a character and print the reply."""
    link = extract_character_link(CHARACTER_URL)
    assert link is not None

    with SyncClient(app_id=AppId.APP) as client:
        client.auth.login_as_tourist()

        chat = client.characters.chats.create(link.character_id)
        result = client.characters.chats.send(
            "Hello! Tell me about yourself.",
            chat.value.session_id,
        )
        print(result.text)


# ---------------------------------------------------------------------------
# Image generation (account required)
# ---------------------------------------------------------------------------


def generate_image() -> None:
    """Generate an image from a text prompt and print the URL."""
    model = extract_model_link(MODEL_URL)
    assert model is not None

    with SyncClient() as client:
        client.auth.login(
            email=os.environ["SEAART_EMAIL"],
            password=os.environ["SEAART_PASSWORD"],
        )

        envelope = client.images.text_to_img(
            prompt="a serene mountain landscape at sunset, oil painting",
            model_no=model.model_no,
        )
        item = envelope.wait(timeout=120)
        print(f"Image URL: {item.image_url}")


if __name__ == "__main__":
    chat_with_character()
