"""Search — find characters, models, works, and more.

In this example, we:
  - Search for characters by name
  - Search for models with sorting and pagination
  - Search across all content types at once
  - Show how to paginate through results

Available search methods:
  characters(), models(), works(), posts(),
  ai_apps(), ai_videos(), workflows(), all()

All methods return SearchResult with .items, .has_more, and .offset.

Requires:
    SEAART_EMAIL and SEAART_PASSWORD environment variables.
"""

from __future__ import annotations

import os

from seaart import SyncClient


# ---------------------------------------------------------------------------
# Characters
# ---------------------------------------------------------------------------


def search_characters() -> None:
    """Find characters by name."""
    with SyncClient() as client:
        client.auth.login(
            email=os.environ["SEAART_EMAIL"],
            password=os.environ["SEAART_PASSWORD"],
        )

        result = client.search.characters("Василиса Зарецкая", page_size=5)
        print("Characters:")
        for item in result.value.items:
            print(f"  {item.id} — {item.title}")


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


def search_models() -> None:
    """Find models with sorting."""
    with SyncClient() as client:
        client.auth.login(
            email=os.environ["SEAART_EMAIL"],
            password=os.environ["SEAART_PASSWORD"],
        )

        # order_by accepts "hot" or "new".
        result = client.search.models("realistic", page_size=5, order_by="hot")
        print("Models:")
        for item in result.value.items:
            print(f"  {item.id} — {item.title}")


# ---------------------------------------------------------------------------
# Pagination
# ---------------------------------------------------------------------------


def search_with_pagination() -> None:
    """Paginate through search results using offset.

    Each response includes .has_more and .offset — pass the offset
    from the previous page to fetch the next one.
    """
    with SyncClient() as client:
        client.auth.login(
            email=os.environ["SEAART_EMAIL"],
            password=os.environ["SEAART_PASSWORD"],
        )

        offset = 0
        page = 1

        while True:
            result = client.search.works("fantasy", page_size=10, offset=offset)
            print(f"Page {page}:")
            for item in result.value.items:
                print(f"  {item.title}")

            if not result.value.has_more:
                break

            offset = int(result.value.offset)
            page += 1

            # Stop after 3 pages for this example.
            if page > 3:
                break


# ---------------------------------------------------------------------------
# All content types
# ---------------------------------------------------------------------------


def search_all() -> None:
    """Search across all content types at once."""
    with SyncClient() as client:
        client.auth.login(
            email=os.environ["SEAART_EMAIL"],
            password=os.environ["SEAART_PASSWORD"],
        )

        result = client.search.all("cyberpunk", page_size=5)
        print("All results:")
        for item in result.value.items:
            print(f"  {item.id} — {item.title}")


if __name__ == "__main__":
    search_characters()
