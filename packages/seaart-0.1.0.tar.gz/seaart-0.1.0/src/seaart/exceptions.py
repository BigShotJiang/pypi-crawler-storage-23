from __future__ import annotations


class SeaArtError(Exception):
    """Base exception for all SeaArt client errors."""


class APIError(SeaArtError):
    """Generic API error raised for HTTP or logic failures.

    Attributes:
        http_status: Raw HTTP status code.
        code: Optional API error code.
        msg: Optional message returned by the API.
        body: Raw response body as bytes.
    """

    def __init__(
        self,
        status: int,
        body: bytes,
        *,
        code: int | None = None,
        msg: str | None = None,
    ):
        self.http_status = status
        self.code = code
        self.msg = msg
        self.body = body
        super().__init__(f"HTTP {status}, code={code}, msg={msg}")


class AuthError(APIError):
    """Base class for authentication-related API errors."""


class AccountNotFoundError(AuthError):
    """Raised when the specified account does not exist."""


class InvalidPasswordError(AuthError):
    """Raised when an incorrect password is provided."""


class AuthTokenInvalidError(AuthError):
    """Raised when an authentication token is missing or invalid."""


class AccountNotLoggedInError(AuthError):
    """Raised when an account is not logged in."""


class AccountBlockedError(AuthError):
    """Raised when an account is blocked."""


class MissingDataError(SeaArtError):
    """Raised when ``APIEnvelope.value`` is accessed but ``data`` is ``None``."""


class AccountForbiddenError(APIError):
    """Raised when an account is forbidden from performing an action."""


class AccountCancelOncePerDayError(APIError):
    """Raised when an account cancellation is attempted more than once per day."""


class TaskCompletionCannotBeCanceledError(APIError):
    """Raised when a task completion cannot be canceled."""


class ParamsError(APIError):
    """Raised when the parameters are invalid."""


class ServerError(APIError):
    """Raised when the server encounters an internal error."""


class ArtModelNoIsEmptyError(APIError):
    """Raised when the art model is empty."""


class ComfyuiApiNodeCannotBeCanceledError(APIError):
    """Raised when a ComfyUI API node cannot be canceled."""


class TaskHangLimitExceededError(APIError):
    """Raised when a task hang limit is exceeded."""


class TaskTimeoutError(SeaArtError, TimeoutError):
    """Raised when a task exceeds the allowed time limit."""


class InvalidRequestError(SeaArtError, ValueError):
    """Raised when a request cannot be built due to invalid/missing parameters."""


class UsernameError(APIError):
    """Raised when the provided username is invalid."""


class TouristChatNumLimitError(APIError):
    """Raised when the tourist chat number limit is exceeded."""


class PromptHaveSensitiveWordsError(APIError):
    """Raised when the prompt contains sensitive words."""


class FeatureRequiresPaymentError(APIError):
    """Raised when a requested feature requires payment."""


class ImageCountExceedLimitError(APIError):
    """Raised when the number of images in a request exceeds the allowed limit."""


class DoNotTurnOffPermissionToPublishWorksToTheCommunityError(APIError):
    """Raised when attempting to turn off the permission to publish works to the community if you don't have the subscription."""


class StreamInterruptedError(SeaArtError):
    """Raised when a streaming response ends without receiving an 'end' event.

    This typically indicates a network interruption or an unexpected server-side
    termination of the stream before the final event was delivered.
    """


class BalanceNotEnoughError(APIError):
    """Raised when the account balance is insufficient to perform an action."""


class OperationNotAllowedError(APIError):
    """Raised when an attempted operation is not allowed."""


class ProcessingError(APIError):
    """Raised when the server fails to process the request."""


class AccountNotMatchError(APIError):
    """Raised when it does not apply to a specific account."""


__all__ = [
    "APIError",
    "AccountBlockedError",
    "AccountCancelOncePerDayError",
    "AccountForbiddenError",
    "AccountNotFoundError",
    "AccountNotLoggedInError",
    "ArtModelNoIsEmptyError",
    "AuthError",
    "AuthTokenInvalidError",
    "BalanceNotEnoughError",
    "ComfyuiApiNodeCannotBeCanceledError",
    "DoNotTurnOffPermissionToPublishWorksToTheCommunityError",
    "FeatureRequiresPaymentError",
    "ImageCountExceedLimitError",
    "InvalidPasswordError",
    "InvalidRequestError",
    "MissingDataError",
    "OperationNotAllowedError",
    "ParamsError",
    "ProcessingError",
    "PromptHaveSensitiveWordsError",
    "SeaArtError",
    "ServerError",
    "StreamInterruptedError",
    "TaskCompletionCannotBeCanceledError",
    "TaskHangLimitExceededError",
    "TaskTimeoutError",
    "TouristChatNumLimitError",
    "UsernameError",
]
