from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...._constants import EMPTY_JSON
from ...._endpoints import GenAgent
from ...._internal._schemas import APIEnvelope
from ...._internal._schemas.genagent.gen_agent import ConversationId
from ..._base import BaseResource
from .gen_agent_messages import AsyncGenAgentMessagesResource

if TYPE_CHECKING:
    from ...._async_client import AsyncClient
else:
    AsyncClient = Any


class AsyncGenAgentResource(BaseResource[AsyncClient]):
    """Root resource for Gen Agent (AI Assistant) operations (async).

    Accessible via ``client.genagent``.

    Sub-resources:

    - ``messages`` — send messages and stream responses
    """

    def __init__(self, client: AsyncClient) -> None:
        super().__init__(client)
        self.messages = AsyncGenAgentMessagesResource(client)

    async def create(self, conv_type: str | None = None) -> APIEnvelope[ConversationId]:
        """Create a new Gen Agent conversation.

        Args:
            conv_type: Optional conversation type hint forwarded to the API.

        Returns:
            ``APIEnvelope[ConversationId]`` — ``.value.conv_id`` is the new
            conversation ID to pass to ``messages.stream()`` / ``messages.send()``.

        Example:
            >>> result = await client.genagent.create()
            >>> conv_id = result.value.conv_id
        """
        env = await self._client.request_route(
            GenAgent.CREATE,
            json={"conv_type": conv_type} if conv_type else EMPTY_JSON,
        )
        return APIEnvelope[ConversationId].model_validate(env)

    async def delete(self, conv_id: str) -> APIEnvelope[None]:
        """Delete a Gen Agent conversation.

        Args:
            conv_id: ID of the conversation to delete.

        Returns:
            ``APIEnvelope[None]`` — the server returns no data payload on
            success.

        Example:
            >>> await client.genagent.delete(conv_id)
        """
        env = await self._client.request_route(
            GenAgent.DELETE,
            json={"conv_id": conv_id},
        )
        return APIEnvelope[None].model_validate(env)
