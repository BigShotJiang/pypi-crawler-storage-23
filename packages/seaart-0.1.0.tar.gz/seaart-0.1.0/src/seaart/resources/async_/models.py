from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..._endpoints import Models
from ..._internal._schemas import APIEnvelope
from ..._internal._schemas.models import (
    GenerationParameters,
    ModelDetails,
)
from .._base import BaseResource

if TYPE_CHECKING:
    from ..._async_client import AsyncClient
else:
    AsyncClient = Any


class AsyncModelsResource(BaseResource[AsyncClient]):
    """Provides model information and generation parameters (async).

    Accessible via ``client.models``.
    """

    def __init__(self, client: AsyncClient) -> None:
        super().__init__(client)

    async def detail(
        self,
        model_no: str,
        *,
        scene: str = "model_detail_v2",
    ) -> APIEnvelope[ModelDetails]:
        """Fetch detailed information about a model.

        Args:
            model_no: Model identifier to look up.
            scene: Scene context forwarded to the API.

        Returns:
            ``APIEnvelope[ModelDetails]`` — contains the model metadata (name, tags, stats, etc.).

        Example:
            >>> info = await client.models.detail("model_abc123")
            >>> print(info.value.name)
        """
        env = await self._client.request_route(
            Models.DETAIL,
            response_model=ModelDetails,
            json={"id": model_no, "scene": scene},
        )
        return APIEnvelope[ModelDetails].model_validate(env)

    async def generation_parameters(
        self,
        model_no: str,
        model_ver_no: str,
        *,
        base_model_name: str | None = None,
    ) -> APIEnvelope[GenerationParameters]:
        """Fetch generation parameters for a specific model version.

        Args:
            model_no: Model identifier.
            model_ver_no: Model version identifier.
            base_model_name: Optional base model name to filter parameters.

        Returns:
            ``APIEnvelope[GenerationParameters]`` — contains parameter
            panels (basic, advanced, image generation) and type/limit info.

        Example:
            >>> params = await client.models.generation_parameters(
            ...     "model_abc123", "ver_xyz"
            ... )
            >>> print(params.value.model_type)
        """
        payload = {"model_no": model_no, "model_ver_no": model_ver_no}
        if base_model_name is not None:
            payload["base_model_name"] = base_model_name
        return await self._client.request_route(
            Models.GENERATION_PARAMETERS,
            response_model=GenerationParameters,
            json=payload,
        )
