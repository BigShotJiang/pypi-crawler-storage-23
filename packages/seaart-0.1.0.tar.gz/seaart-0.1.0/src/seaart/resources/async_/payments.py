from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..._constants import EMPTY_JSON
from ..._endpoints import Payments
from ..._internal._schemas import APIEnvelope
from ..._internal._schemas.payments import PaymentAccessInfo
from .._base import BaseResource

if TYPE_CHECKING:
    from ..._async_client import AsyncClient
else:
    AsyncClient = Any


class AsyncPaymentsResource(BaseResource[AsyncClient]):
    """Provides payment and subscription information (async).

    Accessible via ``client.payments``.
    """

    async def assets(self) -> APIEnvelope[PaymentAccessInfo]:
        """Fetch the current account's payment assets and subscription status.

        Returns:
            ``APIEnvelope[PaymentAccessInfo]`` — ``.value`` contains coin
            balances (``paid_coins``, ``free_coins``, ``temp_free_coins``,
            ``temp_coins``) and subscription flags (``is_active``,
            ``lite_is_active``, ``big_is_active``).

        Example:
            >>> info = await client.payments.assets()
            >>> print(info.value.paid_coins, info.value.free_coins)
        """
        env = await self._client.request_route(
            Payments.ASSETS,
            json=EMPTY_JSON,
        )

        return APIEnvelope[PaymentAccessInfo].model_validate(env)
