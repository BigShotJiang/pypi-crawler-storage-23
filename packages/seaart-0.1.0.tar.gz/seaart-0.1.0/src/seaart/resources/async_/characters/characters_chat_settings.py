from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...._endpoints import Characters
from ...._internal._builders.characters import build_settings_character_chat_body
from ..._base import BaseResource

if TYPE_CHECKING:
    from ...._async_client import AsyncClient
    from ...._internal._schemas import APIEnvelope
else:
    AsyncClient = Any


class AsyncCharactersChatSettingsResource(BaseResource[AsyncClient]):
    """Manages generation settings for a character chat session (async).

    Accessible via ``client.characters.chats.settings``.
    """

    async def update(
        self,
        character_id: str,
        *,
        account_id: str | None = None,
        gpt_model: str | None = None,
        workflow_no: str | None = None,
        temperature: float | None = None,
        diversity: float | None = None,
        length_of_reply: int | None = None,
    ) -> APIEnvelope[None]:
        """Update generation settings for a character chat session.

        Only the parameters you pass are applied; omitted ones remain
        unchanged. If ``account_id`` is not provided, the authenticated
        account's ID is fetched automatically.

        Args:
            character_id: The character whose chat settings to update.
            account_id: Account ID to associate the update with. Defaults
                to the authenticated account.
            gpt_model: AI model identifier to use for the character's
                responses.
            workflow_no: Internal workflow identifier forwarded to the API.
            temperature: Sampling temperature controlling response
                randomness.
            diversity: Diversity parameter controlling response variation.
            length_of_reply: Maximum reply length hint forwarded to the API.

        Returns:
            ``APIEnvelope[None]`` — no data payload; a successful return
            confirms the settings were applied.

        Example:
            >>> await client.characters.chats.settings.update(
            ...     "char_abc123", temperature=0.8, length_of_reply=2000
            ... )
        """
        body = build_settings_character_chat_body(
            account_id=account_id or await self._client.get_account_id(),
            character_id=character_id,
            gpt_model=gpt_model,
            workflow_no=workflow_no,
            temperature=temperature,
            diversity=diversity,
            length_of_reply=length_of_reply,
        )
        return await self._client.request_route(
            Characters.Chat.Settings.UPDATE,
            json=body.model_dump(exclude_none=True),
        )
