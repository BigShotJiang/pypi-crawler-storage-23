from __future__ import annotations

from typing import Generic, TypeVar

ClientT = TypeVar("ClientT")


class BaseResource(Generic[ClientT]):
    """Base class for all API resources."""

    def __init__(self, client: ClientT):
        self._client = client
