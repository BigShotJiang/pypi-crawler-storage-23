from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..._constants import EMPTY_JSON
from ..._endpoints import Auth
from ..._internal._schemas import APIEnvelope
from .._base import BaseResource
from .._shared.auth import (
    build_tourist_headers,
    parse_login_and_apply_token,
)

if TYPE_CHECKING:
    from ..._internal._schemas.auth import AuthSession
    from ..._sync_client import SyncClient
else:
    SyncClient = Any


class AuthResource(BaseResource[SyncClient]):
    """Handles authentication for the sync client (sync).

    Accessible via ``client.auth``.
    """

    def login(self, email: str, password: str) -> APIEnvelope[AuthSession]:
        """Log in with email and password.

        On success the client's auth token is updated automatically, so
        subsequent requests are authenticated without any extra steps.

        Args:
            email: Account email address.
            password: Account password.

        Returns:
            ``APIEnvelope[AuthSession]`` — ``.value.token`` is the auth
            token; ``.value.account`` contains basic account info.

        Raises:
            AuthError: If authentication fails.
            AccountNotFoundError: If no account with that email exists.
            InvalidPasswordError: If the password is incorrect.
            AccountBlockedError: If the account is blocked.

        Example:
            >>> session = client.auth.login("user@example.com", "secret")
            >>> print(session.value.token)
        """
        env = self._client.request_route(
            Auth.LOGIN,
            json={"email": email, "password": password},
        )
        return parse_login_and_apply_token(self._client, env)

    def login_as_tourist(
        self, device_id: str | None = None
    ) -> APIEnvelope[AuthSession]:
        """Log in as a guest without credentials.

        On success the client's auth token is updated automatically.

        Args:
            device_id: Optional device identifier to associate with the
                guest session.

        Returns:
            ``APIEnvelope[AuthSession]`` — ``.value.token`` is the guest
            auth token.

        Example:
            >>> session = client.auth.login_as_tourist()
            >>> print(session.value.token)
        """
        env = self._client.request_route(
            Auth.LOGIN_TOURIST,
            json=EMPTY_JSON,
            headers=build_tourist_headers(self._client, device_id),
        )
        return parse_login_and_apply_token(self._client, env)

    def logout(self) -> APIEnvelope[None]:
        """Log out the current session.

        Clears the client's auth token and notifies the server.

        Returns:
            ``APIEnvelope[None]`` — the server returns no data payload on
            success.

        Example:
            >>> client.auth.logout()
        """
        self._client.set_token(None)
        return self._client.request_route(Auth.LOGOUT)

    def forgot_password(self, email: str) -> APIEnvelope[None]:
        """Send a password-reset email.

        Args:
            email: Email address of the account to reset.

        Returns:
            ``APIEnvelope[None]`` — the server returns no data payload on
            success.

        Example:
            >>> client.auth.forgot_password("user@example.com")
        """
        return APIEnvelope[None].model_validate(
            self._client.request_route(Auth.FORGOT_PASSWORD, json={"email": email})
        )
