from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...._constants import EMPTY_JSON
from ...._endpoints import Characters
from ...._internal._schemas import APIEnvelope
from ...._internal._schemas.characters import (
    CharacterDetail,
    CharacterListModels,
    CollectResponse,
)
from ..._base import BaseResource
from .characters_chat import CharactersChatResource
from .characters_datacards import CharactersDataCardsResource
from .characters_replies import CharactersRepliesResource
from .characters_settings import CharactersSettingsResource

if TYPE_CHECKING:
    from ...._sync_client import SyncClient
else:
    SyncClient = Any


class CharactersResource(BaseResource[SyncClient]):
    """Root resource for character-related API operations (sync).

    Accessible via ``client.characters``.

    Sub-resources:

    - ``chats`` — chat sessions and message streaming
    - ``settings`` — global account-level character settings
    - ``datacards`` — user persona profiles attached to chats
    - ``replies`` — AI-suggested reply recommendations
    """

    def __init__(self, client: SyncClient) -> None:
        super().__init__(client)
        self.chats = CharactersChatResource(client)
        self.settings = CharactersSettingsResource(client)
        self.datacards = CharactersDataCardsResource(client)
        self.replies = CharactersRepliesResource(client)

    def follow(
        self,
        character_id: str,
        collection_no: str | None = None,
    ) -> APIEnvelope[CollectResponse]:
        """Follow (collect) a character.

        Args:
            character_id: ID of the character to follow.
            collection_no: Optional collection to add the character to.

        Returns:
            ``APIEnvelope[CollectResponse]`` — ``.value.id`` is the
            follow-record ID needed to :meth:`unfollow` later.

        Example:
            >>> result = client.characters.follow("char_abc123")
            >>> follow_id = result.value.id
        """
        payload: dict[str, str] = {"character_no": character_id}
        if collection_no is not None:
            payload["collection_no"] = collection_no

        env = self._client.request_route(Characters.COLLECT, json=payload)
        return APIEnvelope[CollectResponse].model_validate(env)

    def unfollow(
        self,
        id: str,
    ) -> APIEnvelope[CollectResponse]:
        """Unfollow a previously followed character.

        Args:
            id: Follow-record ID returned by :meth:`follow` (``result.value.id``),
                not the character ID.

        Returns:
            ``APIEnvelope[CollectResponse]`` — ``.value.id`` echoes the
            follow-record ID.

        Example:
            >>> client.characters.unfollow(follow_id)
        """
        env = self._client.request_route(
            Characters.COLLECT,
            json={"id": id},
        )
        return APIEnvelope[CollectResponse].model_validate(env)

    def detail(
        self,
        character_id: str,
    ) -> APIEnvelope[CharacterDetail]:
        """Fetch detailed information about a character.

        Args:
            character_id: ID of the character to look up.

        Returns:
            ``APIEnvelope[CharacterDetail]`` — rich object with character
            metadata: name, persona, tags, follower count, related
            characters, and more.

        Example:
            >>> info = client.characters.detail("char_abc123")
            >>> print(info.value.name)
        """
        env = self._client.request_route(
            Characters.DETAIL,
            json={"id": character_id},
        )

        return APIEnvelope[CharacterDetail].model_validate(env)

    def models(
        self,
    ) -> APIEnvelope[CharacterListModels]:
        """Fetch the list of available AI models for character chats.

        Returns:
            ``APIEnvelope[CharacterListModels]`` — ``.value.List`` contains
            the available models; ``.value.functionality_list`` describes
            per-model feature flags.

        Example:
            >>> result = client.characters.models()
            >>> for m in result.value.List:
            ...     print(f"{m.gpt_model} | {m.title_key}")
        """
        env = self._client.request_route(
            Characters.MODELS,
            json=EMPTY_JSON,
        )

        return APIEnvelope[CharacterListModels].model_validate(env)
