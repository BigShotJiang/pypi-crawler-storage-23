from .characters import CharactersResource

__all__ = ["CharactersResource"]
