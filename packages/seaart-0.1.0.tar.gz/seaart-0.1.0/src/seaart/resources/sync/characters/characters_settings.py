from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...._endpoints import Characters
from ...._internal._builders.characters import build_other_setting_character_chat_body
from ..._base import BaseResource

if TYPE_CHECKING:
    from ...._internal._schemas import APIEnvelope
    from ...._internal._schemas.characters.characters_settings import WorkflowNo
    from ...._sync_client import SyncClient
else:
    SyncClient = Any


class CharactersSettingsResource(BaseResource[SyncClient]):
    """Manages global account-level character chat settings (sync).

    These settings apply across all character chats, not just a single
    session.  Use :class:`CharactersChatSettingsResource` (accessible
    via ``client.characters.chats.settings``) to adjust per-session
    generation parameters instead.

    Accessible via ``client.characters.settings``.
    """

    def update(
        self,
        *,
        enable_memory: int | None = None,
        initiative_chat: int | None = None,
        auto_play_tts: int | None = None,
        model: str | None = None,
        workflow_no: WorkflowNo | None = None,
    ) -> APIEnvelope[None]:
        """Update global character chat settings.

        Only parameters explicitly passed are included in the request; omit
        any you do not want to change.

        Args:
            enable_memory: Whether long-term memory is enabled
                (``1`` = on (2x long memory), ``2`` = off).
            initiative_chat: Whether the character can send message proactively
                (``1`` = on, ``2`` = off).
            auto_play_tts: Whether TTS audio plays automatically
                (``1`` = on, ``2`` = off).
            model: Identifier of the AI model to use for character
                responses.
            workflow_no: Talk mode (conversation style). One of:

                - ``"chat_model_changLiao"`` — Chat Mode
                - ``"chat_model_lingDong"`` — Nimble Mode
                - ``"chat_model_xiNi"`` — Delicate Mode
                - ``"chat_model_guShi"`` — Novel Mode
                - ``"chat_model_ziYou"`` — Freestyle Mode
                - ``"chat_mode_qinMi"`` — Intimate Mode
                - ``"chat_mode_langMan"`` — Romantic Mode

        Returns:
            ``APIEnvelope[None]`` — the server returns no data payload on
            success.

        Example:
            >>> client.characters.settings.update(
            ...     enable_memory=1,
            ...     auto_play_tts=2,
            ... )
        """
        body = build_other_setting_character_chat_body(
            enable_memory=enable_memory,
            initiative_chat=initiative_chat,
            auto_play_tts=auto_play_tts,
            gpt_model=model,
            workflow_no=workflow_no,
        )
        return self._client.request_route(
            Characters.Settings.UPDATE,
            json=body.model_dump(exclude_none=True),
        )

    def set_default(
        self,
        character_id: str,
    ) -> APIEnvelope[None]:
        """Set the default chat settings for the character.

        Args:
            character_id: ID of the character to set as the default.

        Returns:
            ``APIEnvelope[None]`` — the server returns no data payload on
            success.

        Example:
            >>> client.characters.settings.set_default("char_abc123")
        """
        return self._client.request_route(
            Characters.Settings.SET_DEFAULT,
            json={"character_id": character_id},
        )
