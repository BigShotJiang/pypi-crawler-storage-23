from .gen_agent import GenAgentResource

__all__ = ["GenAgentResource"]
