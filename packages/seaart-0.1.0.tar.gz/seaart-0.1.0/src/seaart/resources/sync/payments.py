from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..._constants import EMPTY_JSON
from ..._endpoints import Payments
from ..._internal._schemas import APIEnvelope
from ..._internal._schemas.payments import PaymentAccessInfo
from .._base import BaseResource

if TYPE_CHECKING:
    from ..._sync_client import SyncClient
else:
    SyncClient = Any


class PaymentsResource(BaseResource[SyncClient]):
    """Provides payment and subscription information (sync).

    Accessible via ``client.payments``.
    """

    def assets(self) -> APIEnvelope[PaymentAccessInfo]:
        """Fetch the current account's payment assets and subscription status.

        Returns:
            ``APIEnvelope[PaymentAccessInfo]`` — ``.value`` contains coin
            balances (``paid_coins``, ``free_coins``, ``temp_free_coins``,
            ``temp_coins``) and subscription flags (``is_active``,
            ``lite_is_active``, ``big_is_active``).

        Example:
            >>> info = client.payments.assets()
            >>> print(info.value.paid_coins, info.value.free_coins)
        """
        env = self._client.request_route(
            Payments.ASSETS,
            json=EMPTY_JSON,
        )

        return APIEnvelope[PaymentAccessInfo].model_validate(env)
