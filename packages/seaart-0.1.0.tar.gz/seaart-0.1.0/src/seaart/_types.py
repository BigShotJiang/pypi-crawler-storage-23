from __future__ import annotations

from collections.abc import Iterable
from typing import Any, TypeAlias

from ._internal._schemas.characters.characters_chat import HistoryMessage

HistoryRole: TypeAlias = int | str

HistoryItem: TypeAlias = (
    HistoryMessage
    | dict[str, Any]
    | tuple[HistoryRole, str]
    | tuple[HistoryRole, str, str]
    | str
)

HistoryInput: TypeAlias = HistoryItem | Iterable[HistoryItem] | None

__all__ = ["HistoryInput", "HistoryItem", "HistoryRole"]
