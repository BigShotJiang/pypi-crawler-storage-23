from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class SamplingOptions(BaseModel):
    steps: int = Field(default=25, ge=1)
    sampler_name: str = Field(default="Euler")
    cfg_scale: float = Field(default=6, ge=0)
    seed: int | None = None


class GenerateOptions(BaseModel):
    anime_enhance: int = 0
    mode: int = 0
    gen_mode: int = 0


class ImgToImgOptions(BaseModel):
    """Options for the ``img_to_img`` generation method. All fields are optional and have sensible defaults."""

    channel_id: str = Field(default="")

    negative_prompt: str = Field(default="")

    sampling: SamplingOptions = Field(default_factory=SamplingOptions)
    generate: GenerateOptions = Field(default_factory=GenerateOptions)

    clip_skip: int = Field(default=2)
    vae: str | None = None

    ss: int | None = None

    lora_models: list[Any] = Field(default_factory=list)
    embeddings: list[Any] = Field(default_factory=list)
