from __future__ import annotations

from pydantic import BaseModel, Field


class UpscaleHdFixOptions(BaseModel):
    """Options for the ``upscale_hd_fix`` method. All fields are optional and have sensible defaults."""

    category: int = Field(default=1)
    width: int = Field(default=1024)
    height: int = Field(default=1024)
    task_flow_version: str = Field(default="v2")
    pre_task_id: str = Field(default="")
    pre_art_work_id: str = Field(default="")
    task_uri_index: int = Field(default=0)
    ss: int | None = None
