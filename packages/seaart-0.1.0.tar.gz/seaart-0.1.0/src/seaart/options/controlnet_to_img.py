from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class SamplingOptions(BaseModel):
    steps: int = Field(default=25, ge=1)
    sampler_name: str = Field(default="Euler")
    cfg_scale: float = Field(default=6, ge=0)
    seed: int | None = None


class GenerateOptions(BaseModel):
    anime_enhance: int = 2
    mode: int = 0


class ControlnetOptions(BaseModel):
    control_mode: int = 0
    guidance: int = 1
    guidance_end: int = 1
    model: str | None = "control_v11p_sd15_canny"
    module: str | None = "canny"
    processor_res: int = 512
    threshold_a: Any | None = None
    type: str = "canny"


class ControlnetToImgOptions(BaseModel):
    """Options for the ``controlnet`` generation method. All fields are optional and have sensible defaults."""

    channel_id: str = Field(default="")

    negative_prompt: str = Field(default="")

    sampling: SamplingOptions = Field(default_factory=SamplingOptions)
    generate: GenerateOptions = Field(default_factory=GenerateOptions)

    clip_skip: int = Field(default=0)
    vae: str | None = None

    ss: int | None = None

    controlnet: ControlnetOptions = Field(default_factory=ControlnetOptions)

    lora_models: list[Any] = Field(default_factory=list)
    embeddings: list[Any] = Field(default_factory=list)

    pre_art_work_id: str | None = None
