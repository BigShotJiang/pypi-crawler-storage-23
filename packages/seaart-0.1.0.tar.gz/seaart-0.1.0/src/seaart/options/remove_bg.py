from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class GenerateOptions(BaseModel):
    anime_enhance: int = 0
    mode: int = 0
    gen_mode: int = 0
    prompt_magic_mode: int = 0


class RemoveBgOptions(BaseModel):
    """Options for the ``remove_bg`` method. All fields are optional and have sensible defaults."""

    channel_id: str = Field(default="")
    art_work_no: str = Field(default="")
    parent_task_id: str = Field(default="")
    category: int = Field(default=10)
    ss: int | None = None

    width: int = Field(default=0)
    height: int = Field(default=0)
    hi_res_arg: Any | None = None
    extra_prompt: str = Field(default="")
    prompt: str = Field(default="")
    local_prompt: str = Field(default="")
    clip_skip: int = Field(default=2)

    steps: int = Field(default=0)
    batch_size: int = Field(default=1)
    init_images: list[str] | None = None
    sampler_name: str = Field(default="Euler")

    seed: int = Field(default=0)
    n_iter: int = Field(default=1)
    cfg_scale: float = Field(default=5.0)

    lora_models: list[Any] | None = None
    smart_edit: Any | None = None
    guidance_scale: int = Field(default=0)
    left_margin: int = Field(default=0)
    up_margin: int = Field(default=0)
    image: str = Field(default="")

    vae: str | None = None
    refiner_mode: int = Field(default=0)
    lcm_mode: int = Field(default=0)

    embeddings: list[Any] | None = None

    generate: GenerateOptions = Field(default_factory=GenerateOptions)
