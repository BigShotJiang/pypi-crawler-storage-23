from __future__ import annotations

from pydantic import BaseModel


class ImagePartOptions(BaseModel):
    url: str
    width: int | None = None
    height: int | None = None


class GenAgentBizParamOptions(BaseModel):
    curr_base_model_name: str | None = None
    curr_model_id: str | None = None
    curr_model_ver_id: str | None = None
    conv_type: str | None = "creative_flow"
    current_workspace_type: str | None = "image"
    video_base_model_name: str | None = "SeaArt SonoVision"
    video_model_id: str | None = "a70a84e9d2db46c7861dseaartwan25v"
    video_model_ver_id: str | None = "1cd2354ece4e4308a1b8seaartwan25v"


class GenAgentReqOptions(BaseModel):
    images: list[ImagePartOptions] = []

    version: str = "v2"
    enable_agent: bool | None = None
    select_agent_mode: str = "combined_gen_assistant_agent_v2"
    safe_scene: int = 52
    seg_id: str = ""

    biz_param: GenAgentBizParamOptions | None = None
