BASE_URL = "https://www.seaart.ai/api/v1"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
EMPTY_JSON: dict[str, object] = {}
