from __future__ import annotations

from typing import Any

from .._schemas.search import SearchBody


def build_search_body(
    *,
    query: str,
    query_en: str = "",
    query_type: int = 99,
    offset: int = 0,
    order_by: str | None = None,
    page: int = 1,
    page_size: int = 35,
    scene: str = "square",
    url: str = "",
    base_models: list[str] | None = None,
    model_types: list[Any] | None = None,
    ss: int | None = None,
) -> SearchBody:
    return SearchBody(
        obj_name=query,
        obj_name_en=query_en,
        obj_type=query_type,
        offset=offset,
        order_by=order_by,
        page=page,
        page_size=page_size,
        scene=scene,
        url=url,
        base_models=base_models,
        model_types=model_types,
        ss=ss,
    )
