from __future__ import annotations

from .._schemas.account import (
    EditAccountBody,
    HomeSet,
    OverviewListItem,
    OverviewSettings,
    UpdateAccountSettingsBody,
)


def build_edit_body(
    *,
    avatar_url: str | None = None,
    nickname: str | None = None,
    home_set: HomeSet | None = None,
    overview: OverviewSettings | None = None,
) -> EditAccountBody:
    return EditAccountBody(
        avatar=avatar_url,
        nickname=nickname,
        home_set=home_set,
        overview_list=[
            OverviewListItem(key="Work", obj_type=1, is_show=overview.work),
            OverviewListItem(key="Model", obj_type=2, is_show=overview.model),
            OverviewListItem(
                key="digitalHuman", obj_type=9, is_show=overview.digital_human
            ),
            OverviewListItem(key="Post", obj_type=7, is_show=overview.post),
            OverviewListItem(key="Canvas", obj_type=11, is_show=overview.canvas),
            OverviewListItem(
                key="WorkflowAIAPP", obj_type=13, is_show=overview.workflow_aiapp
            ),
            OverviewListItem(key="AIAudio", obj_type=16, is_show=overview.ai_audio),
        ]
        if overview
        else None,
    )


def build_settings_body(
    *,
    auto_pub_community: int | None = None,
    localization: int | None = None,
    ai_video_auto_play: int | None = None,
    auto_save_artwork: int | None = None,
    age_confirm: bool | None = None,
    nsfw_plus: int | None = None,
    mode: int | None = None,
) -> UpdateAccountSettingsBody:
    return UpdateAccountSettingsBody(
        auto_pub_community=auto_pub_community,
        localization=localization,
        ai_video_auto_play=ai_video_auto_play,
        auto_save_artwork=auto_save_artwork,
        age_confirm=age_confirm,
        nsfw_plus=nsfw_plus,
        mode=mode,
    )
