from __future__ import annotations

from .._schemas.characters.characters_chat import (
    Avatar,
    CharacterChatBody,
    CharacterVoiceChatBody,
    HistoryMessage,
    Message,
)
from .._schemas.characters.characters_chat_settings import SettingCharacterChatBody
from .._schemas.characters.characters_datacards import DataCardBody, Gender
from .._schemas.characters.characters_replies import (
    CharacterReplyRecommendBody,
    RecommendMessage,
)
from .._schemas.characters.characters_settings import (
    OtherSettingCharacterChat,
    WorkflowNo,
)


def build_settings_character_chat_body(
    *,
    account_id: str | None = None,
    character_id: str,
    gpt_model: str | None = None,
    workflow_no: str | None = None,
    temperature: float | None = None,
    diversity: float | None = None,
    length_of_reply: int | None = None,
) -> SettingCharacterChatBody:
    return SettingCharacterChatBody(
        account_id=account_id,
        character_id=character_id,
        gpt_model=gpt_model,
        workflow_no=workflow_no,
        temperature=temperature,
        diversity=diversity,
        length_of_reply=length_of_reply,
    )


def build_character_datacards_body(
    *,
    account_id: str | None = None,
    age: int | None = None,
    avatar_height: int | None = None,
    avatar_url: str | None = None,
    avatar_width: int | None = None,
    dislike: str | None = None,
    extra: str | None = None,
    gender: Gender | None = None,
    is_default: int | None = None,
    is_main: bool | None = None,
    like: str | None = None,
    username: str | None = None,
) -> DataCardBody:
    return DataCardBody(
        account_id=account_id,
        age=age,
        avatar=Avatar(
            height=avatar_height,
            url=avatar_url,
            width=avatar_width,
        )
        if avatar_url and avatar_width and avatar_height
        else None,
        dislike=dislike,
        extra=extra,
        gender=gender,
        is_default=is_default,
        is_main=is_main,
        like=like,
        username=username,
    )


def build_character_reply_recommend_body(
    *,
    character_id: str,
    char_name: str | None = None,
    character_type: int | None = None,
    user_name: str | None = None,
    messages: list[RecommendMessage] | None = None,
) -> CharacterReplyRecommendBody:
    return CharacterReplyRecommendBody(
        character_id=character_id,
        char_name=char_name,
        character_type=character_type,
        user_name=user_name,
        messages=messages,
    )


def build_other_setting_character_chat_body(
    *,
    enable_memory: int | None = None,
    initiative_chat: int | None = None,
    auto_play_tts: int | None = None,
    gpt_model: str | None = None,
    workflow_no: WorkflowNo | None = None,
) -> OtherSettingCharacterChat:
    return OtherSettingCharacterChat(
        enable_memory=enable_memory,
        initiative_chat=initiative_chat,
        auto_play_tts=auto_play_tts,
        gpt_model=gpt_model,
        workflow_no=workflow_no,
    )


def build_character_chat_body(
    *,
    content: str,
    session_id: str,
    model: str,
    vip_only: int,
    support_voice: int,
    refer: str,
    stream: bool,
    name: str | None = None,
    messages: Message | None = None,
    history_message: list[HistoryMessage] | None = None,
    ss: int | None = None,
) -> CharacterChatBody:
    return CharacterChatBody(
        content=content,
        session_id=session_id,
        vip_only=vip_only,
        support_voice=support_voice,
        name=name,
        model=model,
        refer=refer,
        stream=stream,
        messages=[messages] if messages else [],
        history_message=history_message or [],
        ss=ss,
    )


def build_character_voice_chat_body(
    *, msg_id: str, sub_msg_id: str | None = None, timbre_id: str
) -> CharacterVoiceChatBody:
    return CharacterVoiceChatBody(
        msg_id=msg_id,
        sub_msg_id=sub_msg_id,
        timbre_id=timbre_id,
    )
