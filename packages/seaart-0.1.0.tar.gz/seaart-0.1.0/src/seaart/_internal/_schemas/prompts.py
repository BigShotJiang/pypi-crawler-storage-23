from __future__ import annotations

from .base import APIDataModel


# Response models
class PromptRecommendation(APIDataModel):
    local: str | None = None
