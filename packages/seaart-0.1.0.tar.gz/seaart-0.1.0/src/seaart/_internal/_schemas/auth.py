from __future__ import annotations

from .base import APIDataModel


# Response models
class Account(APIDataModel):
    id: str
    email: str | None = None
    head: str | None = None
    avatar_frame: str | None = None
    create_at: int | None = None
    name: str
    status: int | None = None
    emp_status: int | None = None
    guide_status: int | None = None
    device_code: str | None = None
    is_europe: bool | None = None
    adv_platforms: list[str] | None = None
    lang: str | None = None
    lang_code: str | None = None


class AuthSession(APIDataModel):
    account: Account
    token: str
