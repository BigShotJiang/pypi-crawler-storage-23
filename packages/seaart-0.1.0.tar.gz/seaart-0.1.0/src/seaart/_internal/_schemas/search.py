from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from .base import APIDataModel


# Request models
class SearchBody(BaseModel):
    obj_name: str
    obj_name_en: str
    obj_type: int
    offset: int
    order_by: str | None = None
    page: int
    page_size: int
    scene: str
    url: str
    base_models: list[str] | None = None
    model_types: list[Any] | None = None
    ss: int | None = None


# Response models
class Author(APIDataModel):
    id: str
    email: str
    head: str
    avatar_frame: str
    create_at: int
    name: str
    status: int
    emp_status: int
    guide_status: int
    device_code: str
    is_europe: bool
    adv_platforms: Any
    lang: str
    lang_code: str


class Cover(APIDataModel):
    url: str
    video: str
    width: int
    height: int
    nsfw: int


class Stat(APIDataModel):
    num_of_like: int
    num_of_collection: int
    num_of_task: int
    num_of_view: int
    num_of_artwork: int
    rating: float
    num_of_download: int | None = None


class ChildItem(APIDataModel):
    id: str
    obj_type: int
    sub_obj_type: int
    is_video_has_audio: bool
    c_nsfw_level: int
    nsfw_level: int
    edging: bool


class Item(APIDataModel):
    id: str
    obj_type: int
    sub_obj_type: int
    channel: str | None = None
    sub_channel: str | None = None
    is_video_has_audio: bool
    title: str | None = None
    description: str | None = None
    author: Author
    cover: Cover
    c_nsfw_level: int
    nsfw_level: int
    stat: Stat
    publish_status: int
    status: int
    nsfw: int
    child: list[ChildItem] | None = None
    content_type: str | None = None
    content_sub_type: str | None = None
    pt: str
    create_at: int
    edging: bool


class CorrelatedInfo(APIDataModel):
    status: int
    index: int


class SearchResult(APIDataModel):
    has_more: bool
    offset: str
    items: list[Item]
    search_word_en: str
    related_search_words: Any
    obj_card_list: Any
    log_via: str
    correlated_info: CorrelatedInfo | None = None

    @property
    def first(self) -> Item | None:
        """Return the first search result item, or ``None`` if the list is empty."""
        return self.items[0] if self.items else None
