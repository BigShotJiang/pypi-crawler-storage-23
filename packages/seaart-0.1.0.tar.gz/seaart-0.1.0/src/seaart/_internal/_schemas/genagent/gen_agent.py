from __future__ import annotations

from ..base import APIDataModel


# Response models
class ConversationId(APIDataModel):
    conv_id: str
