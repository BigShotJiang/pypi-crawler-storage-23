from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

WorkflowNo = Literal[
    "chat_model_changLiao",
    "chat_model_lingDong",
    "chat_model_xiNi",
    "chat_model_guShi",
    "chat_model_ziYou",
    "chat_mode_qinMi",
    "chat_mode_langMan",
]


# Request models
class OtherSettingCharacterChat(BaseModel):
    enable_memory: int | None = None
    initiative_chat: int | None = None
    auto_play_tts: int | None = None
    gpt_model: str | None = None
    workflow_no: str | None = None
