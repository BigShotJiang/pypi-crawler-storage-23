from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from ..base import APIDataModel


# Request models
class RecommendMessage(BaseModel):
    role: Literal["user", "assistant"]
    text: str


class CharacterReplyRecommendBody(BaseModel):
    character_id: str
    char_name: str | None = None
    character_type: int | None = None
    user_name: str | None = None
    messages: list[RecommendMessage] | None = None


# Response models
class ItemRecommend(APIDataModel):
    text: str | None = None


class CharacterReplyRecommend(APIDataModel):
    items: list[ItemRecommend] | None = None
    free_times: int
    video_prompt_key: str
