from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from ..base import APIDataModel
from ..characters.characters_chat import Avatar

# Request models
# "femail" is a typo in the upstream API (not our mistake).
Gender = Literal["femail", "male", "anime", "other"]


class DataCardBody(BaseModel):
    account_id: str | None = None
    username: str | None = None
    like: str | None = None
    is_default: int | None = None
    is_main: bool | None = None
    gender: Gender | None = None
    extra: str | None = None
    dislike: str | None = None
    avatar: Avatar | None = None
    age: int | None = None


# Response models
class DataCard(APIDataModel):
    id: str
    create_at: int | None = None
    update_at: int | None = None
    username: str | None = None
    avatar: Avatar | None = None
    age: int | None = None
    gender: str | None = None
    like: str | None = None
    dislike: str | None = None
    account_id: str | None = None
    extra: str | None = None


class MyDataCards(APIDataModel):
    items: list[DataCard] | None = None
