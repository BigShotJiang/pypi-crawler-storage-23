from __future__ import annotations

from pydantic import BaseModel


# Request models
class SettingCharacterChatBody(BaseModel):
    account_id: str | None = None
    character_id: str
    gpt_model: str | None = None
    workflow_no: str | None = None
    temperature: float | None = None
    diversity: float | None = None
    length_of_reply: int | None = None
