from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from ..base import APIDataModel
from .characters import Cover


# Request models
class MessageContent(BaseModel):
    content_type: str
    parts: list[str]


class Message(BaseModel):
    role: str
    content: str | MessageContent


class HistoryMessage(BaseModel):
    role: int
    content: str
    msg_id: str = ""


class CharacterChatBody(BaseModel):
    content: str
    session_id: str
    vip_only: int
    support_voice: int
    name: str | None = None
    model: str
    refer: str
    stream: bool
    messages: list[Message] | None = None
    history_message: list[HistoryMessage] | None = None
    ss: int | None = None


class HistoryCharacterChatBody(BaseModel):
    character_id: str
    page: int | None = None
    page_size: int | None = None
    with_latest_msg: int | None = None
    ss: int | None = None


class CharacterVoiceChatBody(BaseModel):
    msg_id: str
    sub_msg_id: str | None = None
    timbre_id: str


# Response models
class CreateChatInfo(APIDataModel):
    session_id: str
    msg: str
    create_at: int
    id: str
    support_voice: int
    voice_duration: int


class Timbre(APIDataModel):
    id: str
    gender: str
    tones: Any
    name: str
    url: str
    age: str
    tags: Any
    langs: Any
    cover: Any
    Text: str
    author_id: str


class Label(APIDataModel):
    name: str
    type: int


class ScanResult(APIDataModel):
    labels: list[Label]
    score: int
    desc: str


class Avatar(APIDataModel):
    url: str | None = None
    width: int | None = None
    height: int | None = None
    cover: str | None = None
    nsfw: int | None = None
    video: str | None = None
    cover_width: int | None = None
    cover_height: int | None = None
    cover_nsfw_level: int | None = None
    scan_result: ScanResult | None = None


class Card(APIDataModel):
    id: str
    username: str
    avatar: Avatar | None = None
    age: int
    gender: str
    like: str
    dislike: str
    account_id: str
    extra: str


class LatestSessionInfo(APIDataModel):
    session_id: str
    x_msg_id: str
    x_response_msg_id: str
    original_msg_id: str
    msg_type: str
    user_msg: str
    msg_end: bool
    response_msg: str
    response_json_msg: Any
    create_at: int
    support_voice: int
    voice_duration: int
    think_duration: int
    status: int
    gpt_model: str
    file_info: Any
    is_active_upload: int
    openai_msg: Any
    search_results: Any
    character_type: int


class GuideMsg(APIDataModel):
    msg_id: str
    title: str
    desc: str


class FreeModelGuideMsg(APIDataModel):
    msg_id: str
    title: str
    desc: str


class ChatCardPopup(APIDataModel):
    popup_type: int
    show_popup: int


class StartChatInfo(APIDataModel):
    position: str
    full_screen: int
    hide_bg: int
    timbre: Timbre
    free_times: int
    enable_memory: int
    card: Card
    is_main_card: int
    limit_tourist_chat: int
    latest_session_info: LatestSessionInfo
    guide_msg: GuideMsg
    free_model_guide_msg: FreeModelGuideMsg
    chated_free_times: int
    chated_num: int
    today_free_chat_num: int
    draw_lottery_condition_num: int
    is_draw_lottery: int
    reply_img_author_id: str
    is_new_business: int
    chat_card_popup: ChatCardPopup


class LatestMsg(APIDataModel):
    id: str
    num_of_token: int | None = None
    coin: float | None = None
    content: str
    original_content: str
    json_content: Any
    create_at: int
    role: int
    support_voice: int
    voice_duration: int
    think_duration: int
    status: int
    active_idx: int
    gpt_model: str
    sub_msg: Any
    file_info: Any
    is_active_upload: int
    search_results: Any
    on_line_search: int
    scene: str
    is_like: int
    indistinct: int
    handle_button_text: str
    handle_msg_type: int


class Item(APIDataModel):
    session_id: str
    session_title: str
    character_id: str
    create_at: int
    update_at: int
    name: str
    gender: str
    nsfw: int
    cover: Cover
    source: str
    intro: str
    vision: Any
    personal: str
    mask: str
    dialog_example: str
    sys_tag: Any
    first_msg: str
    scene: str
    config: str
    categories: Any
    status: int
    account_no: str
    show_in: int
    publish_status: int
    latest_msg: LatestMsg
    nsfw_level: int


class HistoryCharacterChat(APIDataModel):
    items: list[Item] | None = None
    has_more: bool | None = None
