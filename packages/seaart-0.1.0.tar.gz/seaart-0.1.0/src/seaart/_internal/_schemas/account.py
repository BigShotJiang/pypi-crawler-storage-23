from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from .base import APIDataModel


# Request models
class HomeSet(BaseModel):
    sex: int | None = None
    intro: str | None = None
    notice: str | None = None
    background_img: str | None = None
    show_sex: int | None = None


class OverviewListItem(BaseModel):
    key: str
    obj_type: int
    is_show: bool | None = None


class EditAccountBody(BaseModel):
    avatar: str | None = None
    nickname: str | None = None
    home_set: HomeSet | None = None
    overview_list: list[OverviewListItem] | None = None


class UpdateAccountSettingsBody(BaseModel):
    auto_pub_community: int | None = None
    localization: int | None = None
    ai_video_auto_play: int | None = None
    auto_save_artwork: int | None = None
    age_confirm: bool | None = None
    nsfw_plus: int | None = None
    mode: int | None = None


class OverviewSettings(BaseModel):
    work: bool | None = None
    model: bool | None = None
    digital_human: bool | None = None
    post: bool | None = None
    canvas: bool | None = None
    workflow_aiapp: bool | None = None
    ai_audio: bool | None = None


# Response models
class Settings(APIDataModel):
    is_variant_operation: bool
    is_auto_pub_community: bool
    is_off_localization: bool
    bg_cover: str
    green_mode: int
    lang_code: str
    nsfw_plus: int
    insight: int
    ai_video_auto_play: int
    task_flow_version: str
    task_image_prompt_switch: int
    use_model_preset_meta_mode: int
    character_push: int
    show_sexy_content: int
    show_eyes: int
    auto_save_artwork: int
    enable_no_download: int
    auto_save_work_flow: int
    enable_community_subscribe: int


class Badge(APIDataModel):
    id: str
    name_key: str
    intro_key: str
    uri: str
    uri_big: str
    status: int
    type: int
    name: str
    intro: str
    create_at: int
    start_at: int
    expire_at: int
    display_order: int


class CharacterSetting(APIDataModel):
    gpt_model: str
    functionality_gpt_model: str
    auto_tts: int
    enable_memory: int
    enable_five_memory: int
    style: str
    full_screen: int
    h5_full_screen: int
    h5_style: str
    hide_bg: int
    h5_hide_bg: int
    h5_hide_continue: int
    enable_stream_chat: int
    default_card: str
    gender: str
    is_set_companion_model: int
    is_set_functionality_model: int
    is_set_workflow: int
    on_line_search: int
    workflow_no: str
    initiative_chat: int
    immerse_switch: int
    recommend_reply: int
    confirm_guide_msg_id: str
    free_model_guide_msg_id: str
    auto_play_tts: int
    apply_list_img: str


class AccountInfo(APIDataModel):
    id: str
    email: str
    type: str
    name: str
    head: str
    avatar_frame: str
    owned_avatar_frame: Any
    badges: list[Badge]
    verified_badges: list[Any]
    create_at: int
    settings: Settings
    character_setting: CharacterSetting
    guide_status: int
    newbie_guide_status: int
    colleted_cnt: int
    following_cnt: int
    follower_cnt: int
    num_of_post: int | None = None
    num_of_total: int
    num_of_timbre: int
    view_cnt: int
    invite_user_code: str
    invite_user_num: int
    review: Any
    c_home: str
    is_model_creator: bool
    enable_ai: bool
    enable_gf: bool
    enable_tavern: bool
    enable_portfolio: bool
    enable_video: bool
    enable_palette: bool
    is_active: bool
    enable_nsfw_plus: bool
    is_studio_beta: bool
    show_lab: bool
    payment_conf: list[str] | None = None
    account_login_channel: int
    role: str
    emp_status: int
    managed_tags: Any
    collect_tags: Any
    collect_tag_item: Any
    post_white: bool
    apps_flyer_id: str
    apps_flyer_adid: str
    task_num: int
    guide_pop: bool
    character_pop: bool
    is_audit: int
    join_stimulate: int
    system_push: int
    comment_push: int
    like_favorite_push: int
    follow_push: int
    followed_content_push: int
    ai_video_auto_play: int
    enable_comfyui: bool
    bind_adyen: bool
    task_expire_day: int
    app_id: str
    home_set: Any
    overview_list: Any
    can_push_surveys: bool
    num_of_active: int
    show_evaluation_guide: bool
    adv_platform: list[Any] | None = None
    can_show_ad: bool
    login_app: int
    story_gray: bool
    is_questionnaire: bool
    current_country_code: str
    show_download: bool
    task_flow_gt: str
    h5_task_flow_gt: str
    show_task_v2_guide: bool
    show_task_v2_guide_for_h5: bool
    shot_task_v2_preset_meta_popup: bool
    is_digital_lang_flow: int
    trial_order_pay_popup: int
    earnings: int
    is_show_video_calculate: bool
    is_interior: bool
    show_sexy_button: bool
    show_nexus_button: bool
    is_pinterest_share_award: int
    time_zone: str
    disable_task_v1_switch: bool
    is_sdk: bool
    apply_cn_temp_guide_popup: bool
    is_cheat_account: bool
    ad_code_from: str
    character_discount: float
    ip_country_code: str
    lock_risk: int
    num_of_be_subscribe: int
    num_of_subscribe: int
    risk_type: str


class EditAccountStatus(APIDataModel):
    status: int
