from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from .base import APIDataModel


# Request models
class AddImageHistoryBody(BaseModel):
    url: str
    img_category: int
    width: int | None = None
    height: int | None = None


# Response models
class ItemImageHistory(APIDataModel):
    id: str
    url: str
    width: int
    height: int
    artwork_id: str
    source_type: int
    nsfw_level: int
    nsfw: int
    nsfw_plus: bool


class ImageHistory(APIDataModel):
    items: list[ItemImageHistory] | None = None


class ActionCapabilityEntry(APIDataModel):
    val: str
    creativity_template_id: str | None = None


class ActionCapability(APIDataModel):
    basic: list[ActionCapabilityEntry] | None = None
    app_basic: list[ActionCapabilityEntry] | None = None
    hover: list[ActionCapabilityEntry] | None = None
    edit: list[ActionCapabilityEntry] | None = None
    extend: list[ActionCapabilityEntry] | None = None
    permission: Any | None = None


class Component(APIDataModel):
    id: str | None = None
    width: int | None = None
    height: int | None = None
    cover_url: str | None = None
    title: str | None = None
    is_blur: bool | None = None
    url: str | None = None
    nsfw: int | None = None
    is_nsfw_plus: bool | None = None
    index: int | None = None
    expiration_time: int | None = None
    is_submit: bool | None = None
    is_saved_personal: bool | None = None
    rembg_x: int | None = None
    rembg_y: int | None = None
    node_key: str | None = None
    type: int | None = None
    sub_type: int | None = None
    operation_labels: list[str] | None = None
    action_capability: ActionCapability | None = None
    is_nsfw_appeal: bool | None = None
    is_video_has_audio: bool | None = None


class Cover(APIDataModel):
    width: int
    height: int
    url: str
    nsfw: int
    nsfw_level: int
    is_nsfw_plus: bool
    green: int
    has_meta: int
    stream_url: str
    cover_url: str


class Creativity(APIDataModel):
    id: str | None = None
    type: int | None = None
    name: str | None = None
    node_num: int | None = None
    node_types: None
    cover: Cover | None = None
    is_support_retry: bool | None = None
    ver_no: str | None = None


class DeductionDetail(APIDataModel):
    is_chargeable: bool | None = None
    hashrate: float | None = None
    temp_hashrate: float | None = None
    history_hashrate: bool | None = None
    after_hashrate: float | None = None
    after_temp_hashrate: float | None = None
    refund_hashrate: float | None = None
    refund_temp_hashrate: float | None = None
    daily_task_count: int | None = None
    free_nsfw_refund_total_count: int | None = None
    free_nsfw_refund_used_count: int | None = None


class BizInfo(APIDataModel):
    gen_guide_tpl_id: str | None = None
    use_origin_gen_guide_tpl_param: bool | None = None
    is_can_guide: bool | None = None


class Item(APIDataModel):
    id: str | None = None
    parent_id: str | None = None
    type: int | None = None
    task_domain_type: int | None = None
    sub_type: int | None = None
    sub_model_category: int | None = None
    prompt: str | None = None
    local_prompt: str | None = None
    width: int | None = None
    height: int | None = None
    status: int | None = None
    status_desc: str | None = None
    sub_status: int | None = None
    create_at: int | None = None
    components: list[Component] | None = None
    category: int | None = None
    expiration_time: int | None = None
    ckpts: list[Any] | None = None
    loras: list[Any] | None = None
    embeddings: list[Any] | None = None
    creativity: Creativity | None = None
    deduction_detail: DeductionDetail | None = None
    pub_community: int | None = None
    speed_type: int | None = None
    trans_off: bool | None = None
    biz_info: BizInfo | None = None


class Histories(APIDataModel):
    after_id: str | None = None
    has_more: bool | None = None
    items: list[Item] | None = None
