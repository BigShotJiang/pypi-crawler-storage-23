from __future__ import annotations

from typing_extensions import TypedDict


class ProxySpec(TypedDict, total=False):
    all: str
    http: str
    https: str
    ws: str
    wss: str


class MimePart(TypedDict, total=False):
    name: str
    filename: str
    local_path: str
    data: bytes
    content_type: str
