from __future__ import annotations

from curl_cffi.requests.impersonate import BrowserTypeLiteral
from curl_cffi.requests.utils import HttpVersionLiteral
from pydantic import BaseModel, ConfigDict, Field

from ..._enums import AppId
from .http import ProxySpec


class ClientConfig(BaseModel):
    """Validated configuration for a SeaArt API client instance.

    Holds the base URL, auth token, timeout (scalar or ``(connect, read)``
    tuple), proxy settings, browser impersonation profile, and other
    per-client defaults.
    """

    model_config = ConfigDict(extra="ignore")

    app_id: AppId

    base_url: str
    timeout: float | tuple[float, float]
    cache_ttl_seconds: float | None = None
    user_agent: str
    http_version: HttpVersionLiteral

    default_headers: dict[str, str] = Field(default_factory=dict)
    token: str | None = None
    proxy: str | None = None
    proxies: ProxySpec | None = None
    impersonate: BrowserTypeLiteral | None = None
