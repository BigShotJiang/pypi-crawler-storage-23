from __future__ import annotations

from typing import Any

from .base import APIDataModel


# Response models
class Estimate(APIDataModel):
    calculate_coins: int
    calculate_coins_before_discount: int
    has_discount: bool
    discount_rate: int
    discount_off_rate: int


class TryOutLimit(APIDataModel):
    pattern_20: int
    pattern_21: int
    studio: int


class PaymentAccessInfo(APIDataModel):
    account_id: str
    is_active: bool
    lite_is_active: bool
    big_is_active: bool
    paid_coins: int
    free_coins: int
    temp_free_coins: int
    temp_coins: float
    calculate_coins: float
    latest_sub_cp_product_id: str
    product_type: int
    product_level: int
    expiry_time: int
    lite_expiry_time: int
    big_expiry_time: int
    moreshort_expiry_time_ms: int
    run_limit: int
    hang_limit: int
    privacy_mode: bool
    work_delete: bool
    extra_recharge: bool
    vip_customer_service: bool
    temp_coins_expiry_time: int
    show_auto_pub_switch: bool
    coins_version: int
    try_out_limit: TryOutLimit
    max_recharge: float
    emp_assets: Any
    max_out_image: int
    purchase_type: int
    latest_sub_sys_order_id: str
    train_run_limit: int
    train_hang_limit: int
    infinite_queue: bool
    fast_queue_trial_num: int
    palette_limit: int
    forever_save_task: bool
    vip_type: str
    app_ad_num: int
    every_temp_coins: int
    has_send_welfare: bool
    is_send_tourist_temp_coins: bool
    create_at: int
    used_free_month: int
    free_month_end: int
    buff_vip_expiry_time: int
    card_type: str
    discount_pop_type: int
    total_recharge: float
    stimulate_earnings: float
    default_sub_product_id: str
    user_type: int
    seen_sub: int
    sub_product_id: str
    adyen_client_key: str
    country_level: str
    country_level_product_id: str
    box_free_times: int
    used_special_activity_product_id: str
    refund_gift_status: int
    operator_num: int
    product_price_version: str
    shop_guide_popup_status: int
    character_vip_expiry_time_ms: int
    payermax_payment_method: str
    payermax_payment_method_common: str
    card_channel: str
    extra_data: dict[str, Any]
