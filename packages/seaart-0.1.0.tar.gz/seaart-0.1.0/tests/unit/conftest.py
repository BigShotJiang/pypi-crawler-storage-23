"""Shared fixtures for unit tests."""

from typing import Any

import pytest

from seaart import AsyncClient
from seaart._internal._schemas.envelope import APIEnvelope


@pytest.fixture()
def client() -> AsyncClient:
    """Pre-configured async client with a dummy token."""
    return AsyncClient(token="test-token")


def make_ok(data: object = None) -> APIEnvelope[object]:
    """Build a successful ``APIEnvelope`` (code 10000)."""
    return APIEnvelope[object].model_validate(
        {"status": {"code": 10000, "msg": "ok", "request_id": "r1"}, "data": data}
    )


def make_error(code: int, msg: str = "error") -> APIEnvelope[Any]:
    """Build an error ``APIEnvelope`` with the given code."""
    return APIEnvelope[Any].model_validate(
        {"status": {"code": code, "msg": msg, "request_id": "r1"}, "data": None}
    )
