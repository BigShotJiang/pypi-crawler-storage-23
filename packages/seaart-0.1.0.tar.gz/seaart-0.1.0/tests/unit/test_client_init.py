# pyright: reportPrivateUsage=false
"""Unit tests: client initialization, configuration, and copy."""

from seaart import AsyncClient
from seaart._constants import BASE_URL, USER_AGENT
from seaart._enums import AppId


# ── Defaults ────────────────────────────────────────────────────────────────


class TestClientDefaults:
    def test_default_base_url(self) -> None:
        c = AsyncClient()
        assert c.cfg.base_url == BASE_URL

    def test_default_token_none(self) -> None:
        c = AsyncClient()
        assert c.token is None

    def test_default_app_id(self) -> None:
        c = AsyncClient()
        assert c.cfg.app_id == AppId.WEB

    def test_default_timeout(self) -> None:
        c = AsyncClient()
        assert c.cfg.timeout == 30.0

    def test_default_user_agent(self) -> None:
        c = AsyncClient()
        assert c.cfg.user_agent == USER_AGENT

    def test_default_proxy_none(self) -> None:
        c = AsyncClient()
        assert c.cfg.proxy is None

    def test_default_cache_ttl_none(self) -> None:
        c = AsyncClient()
        assert c.cfg.cache_ttl_seconds is None


# ── Custom values ───────────────────────────────────────────────────────────


class TestClientCustomValues:
    def test_custom_token(self) -> None:
        c = AsyncClient(token="my-token")
        assert c.token == "my-token"

    def test_custom_base_url(self) -> None:
        c = AsyncClient(base_url="https://custom.api.com/v2")
        assert c.cfg.base_url == "https://custom.api.com/v2"

    def test_custom_timeout(self) -> None:
        c = AsyncClient(timeout=60.0)
        assert c.cfg.timeout == 60.0

    def test_custom_app_id(self) -> None:
        c = AsyncClient(app_id=AppId.APP)
        assert c.cfg.app_id == AppId.APP

    def test_custom_proxy(self) -> None:
        c = AsyncClient(proxy="http://proxy:8080")
        assert c.cfg.proxy == "http://proxy:8080"

    def test_custom_user_agent(self) -> None:
        c = AsyncClient(user_agent="MyBot/1.0")
        assert c.cfg.user_agent == "MyBot/1.0"

    def test_custom_cache_ttl(self) -> None:
        c = AsyncClient(cache_ttl_seconds=120.0)
        assert c.cfg.cache_ttl_seconds == 120.0

    def test_custom_default_headers(self) -> None:
        c = AsyncClient(default_headers={"X-Custom": "val"})
        assert c.default_headers["X-Custom"] == "val"


# ── Timeout ─────────────────────────────────────────────────────────────────


class TestClientTimeout:
    def test_default_timeout_is_float(self) -> None:
        c = AsyncClient()
        assert c.cfg.timeout == 30.0

    def test_connect_timeout_only(self) -> None:
        c = AsyncClient(connect_timeout=5.0)
        assert c.cfg.timeout == (5.0, 30.0)

    def test_read_timeout_only(self) -> None:
        c = AsyncClient(read_timeout=60.0)
        assert c.cfg.timeout == (30.0, 60.0)

    def test_both_timeouts(self) -> None:
        c = AsyncClient(connect_timeout=5.0, read_timeout=60.0)
        assert c.cfg.timeout == (5.0, 60.0)

    def test_override_base_with_both(self) -> None:
        c = AsyncClient(timeout=10.0, connect_timeout=3.0, read_timeout=15.0)
        assert c.cfg.timeout == (3.0, 15.0)

    def test_override_base_with_connect_only(self) -> None:
        c = AsyncClient(timeout=10.0, connect_timeout=3.0)
        assert c.cfg.timeout == (3.0, 10.0)


# ── Copy ────────────────────────────────────────────────────────────────────


class TestClientCopy:
    def test_copy_preserves_token(self) -> None:
        c = AsyncClient(token="abc")
        c2 = c.copy(clear_token=False)
        assert c2.token == "abc"

    def test_copy_clear_token(self) -> None:
        c = AsyncClient(token="abc")
        c2 = c.copy()
        assert c2.token is None
        assert c.token == "abc"  # original unchanged

    def test_copy_preserves_config(self) -> None:
        c = AsyncClient(
            base_url="https://custom.api.com",
            timeout=99.0,
            app_id=AppId.APP,
        )
        c2 = c.copy()
        assert c2.cfg.base_url == "https://custom.api.com"
        assert c2.cfg.timeout == 99.0
        assert c2.cfg.app_id == AppId.APP

    def test_copy_is_independent(self) -> None:
        c = AsyncClient(token="abc")
        c2 = c.copy()
        c2.set_token("xyz")
        assert c.token == "abc"
        assert c2.token == "xyz"


# ── Resources exist ─────────────────────────────────────────────────────────


class TestClientResources:
    def test_has_all_resources(self) -> None:
        c = AsyncClient(token="test")
        assert hasattr(c, "health")
        assert hasattr(c, "auth")
        assert hasattr(c, "account")
        assert hasattr(c, "payments")
        assert hasattr(c, "search")
        assert hasattr(c, "images")
        assert hasattr(c, "models")
        assert hasattr(c, "tasks")
        assert hasattr(c, "characters")
        assert hasattr(c, "prompts")
        assert hasattr(c, "genagent")

    def test_nested_resources(self) -> None:
        c = AsyncClient(token="test")
        assert hasattr(c.characters, "chats")
        assert hasattr(c.characters.chats, "messages")
        assert hasattr(c.images, "history")
