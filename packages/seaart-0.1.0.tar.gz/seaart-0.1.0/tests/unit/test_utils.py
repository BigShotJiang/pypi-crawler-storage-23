# pyright: reportPrivateUsage=false
"""Unit tests: mask_token, mask_sensitive_json, generate_seed, etc."""

from __future__ import annotations

import pytest

from seaart._base_client import BaseClient
from seaart._utils import mask_sensitive_json, mask_token


# ── mask_token ───────────────────────────────────────────────────────────────


class TestMaskToken:
    def test_normal_token(self) -> None:
        assert mask_token("abcde12345fghij6789") == "abcde...6789"

    def test_short_token(self) -> None:
        result = mask_token("123456789")
        assert result == "12345...6789"


# ── mask_sensitive_json ──────────────────────────────────────────────────────


class TestMaskSensitiveJson:
    def test_masks_password(self) -> None:
        d = {"username": "user", "password": "secret123"}
        result = mask_sensitive_json(d)
        assert result["password"] == "***"
        assert result["username"] == "user"

    def test_no_password(self) -> None:
        d = {"username": "user", "email": "a@b.com"}
        result = mask_sensitive_json(d)
        assert result == d

    def test_original_unchanged(self) -> None:
        d = {"password": "secret"}
        mask_sensitive_json(d)
        assert d["password"] == "secret"

    def test_empty_dict(self) -> None:
        assert mask_sensitive_json({}) == {}


# ── generate_seed / generate_x_device_id ─────────────────────────────────────


class _StubClient(BaseClient[None]):
    def _init_session(self) -> None:
        return None


class TestGenerateSeed:
    def test_explicit_seed(self) -> None:
        c = _StubClient()
        assert c.generate_seed(42) == 42

    def test_none_seed_random(self) -> None:
        c = _StubClient()
        seed = c.generate_seed(None)
        assert 0 <= seed <= 999_999_999

    def test_zero_seed_generates_random(self) -> None:
        c = _StubClient()
        seed = c.generate_seed(0)
        # 0 is falsy, so should generate random (same range as None)
        assert 0 <= seed <= 999_999_999


class TestGenerateDeviceId:
    def test_explicit_id(self) -> None:
        c = _StubClient()
        assert c.generate_x_device_id("my-device") == "my-device"

    def test_none_generates_uuid(self) -> None:
        c = _StubClient()
        result = c.generate_x_device_id(None)
        assert len(result) == 36  # UUID format


# ── Client properties ────────────────────────────────────────────────────────


class TestClientProperties:
    def test_token_property(self) -> None:
        c = _StubClient(token="abc")
        assert c.token == "abc"

    def test_set_token(self) -> None:
        c = _StubClient()
        assert c.token is None
        c.set_token("new-token")
        assert c.token == "new-token"

    def test_set_token_none(self) -> None:
        c = _StubClient(token="abc")
        c.set_token(None)
        assert c.token is None

    def test_default_headers_immutable(self) -> None:
        c = _StubClient()
        headers = c.default_headers
        with pytest.raises(TypeError):
            headers["new"] = "val"  # type: ignore[index]

    def test_set_default_headers(self) -> None:
        c = _StubClient()
        c.set_default_headers({"X-Custom": "val"})
        assert c.default_headers["X-Custom"] == "val"

    def test_clear_default_headers(self) -> None:
        c = _StubClient(default_headers={"X-Custom": "val"})
        c.clear_default_headers()
        assert "X-Custom" not in c.default_headers

    def test_set_account_id(self) -> None:
        c = _StubClient()
        c.set_account_id("acc123")
        assert c._account_id == "acc123"
