# pyright: reportPrivateUsage=false
"""Unit tests: astream_json_events — async SSE transport with fake session."""

import json
from collections.abc import AsyncIterator, Mapping
from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock

import pytest

from seaart._transport_sse import SSEEvent, astream_json_events
from seaart.exceptions import APIError

# Type alias for the parsed item returned by _identity_parser.
_ParsedItem = tuple[str, dict[str, Any] | None]


# ── Fake response ───────────────────────────────────────────────────────────


@dataclass
class FakeResponse:
    status_code: int = 200
    headers: dict[str, str] = field(default_factory=lambda: dict[str, str]())
    chunks: list[bytes] = field(default_factory=lambda: list[bytes]())
    closed: bool = False

    async def aiter_content(self) -> AsyncIterator[bytes]:
        for chunk in self.chunks:
            yield chunk

    async def aclose(self) -> None:
        self.closed = True


def _sse_bytes(event: str, data: dict[str, Any]) -> bytes:
    """Build raw SSE bytes for a single event."""
    return f"event: {event}\ndata: {json.dumps(data)}\n\n".encode()


def _identity_parser(ev: SSEEvent, obj: dict[str, Any] | None) -> _ParsedItem:
    """Passthrough parser returning (event_type, parsed_obj)."""
    return (ev.event, obj)


# ── Happy path ──────────────────────────────────────────────────────────────


class TestAStreamHappyPath:
    async def test_single_event(self) -> None:
        resp = FakeResponse(chunks=[_sse_bytes("chunk", {"text": "hello"})])
        session_request = AsyncMock(return_value=resp)

        items: list[_ParsedItem] = []
        async for item in astream_json_events(
            session_request=session_request,
            method="POST", url="https://example.com/stream",
            headers={}, params=None, json_body=None, data=None,
            timeout=10.0, parser=_identity_parser,
        ):
            items.append(item)

        assert len(items) == 1
        assert items[0][0] == "chunk"
        assert items[0][1] == {"text": "hello"}

    async def test_multiple_events(self) -> None:
        raw_chunks: list[bytes] = [
            _sse_bytes("chunk", {"i": 1}),
            _sse_bytes("chunk", {"i": 2}),
            _sse_bytes("end", {"done": True}),
        ]
        resp = FakeResponse(chunks=raw_chunks)
        session_request = AsyncMock(return_value=resp)

        items: list[_ParsedItem] = []
        async for item in astream_json_events(
            session_request=session_request,
            method="POST", url="https://example.com/stream",
            headers={}, params=None, json_body=None, data=None,
            timeout=10.0, parser=_identity_parser,
        ):
            items.append(item)

        assert len(items) == 3
        assert items[0][1] == {"i": 1}
        assert items[2][0] == "end"

    async def test_multiple_events_in_one_chunk(self) -> None:
        combined = _sse_bytes("chunk", {"a": 1}) + _sse_bytes("chunk", {"b": 2})
        resp = FakeResponse(chunks=[combined])
        session_request = AsyncMock(return_value=resp)

        items: list[_ParsedItem] = []
        async for item in astream_json_events(
            session_request=session_request,
            method="POST", url="https://example.com/stream",
            headers={}, params=None, json_body=None, data=None,
            timeout=10.0, parser=_identity_parser,
        ):
            items.append(item)

        assert len(items) == 2

    async def test_response_closed_after_iteration(self) -> None:
        resp = FakeResponse(chunks=[_sse_bytes("chunk", {"x": 1})])
        session_request = AsyncMock(return_value=resp)

        async for _ in astream_json_events(
            session_request=session_request,
            method="POST", url="https://example.com/stream",
            headers={}, params=None, json_body=None, data=None,
            timeout=10.0, parser=_identity_parser,
        ):
            pass

        assert resp.closed


# ── Error handling ──────────────────────────────────────────────────────────


class TestAStreamErrors:
    async def test_http_error_raises_api_error(self) -> None:
        resp = FakeResponse(status_code=500, chunks=[])
        session_request = AsyncMock(return_value=resp)

        with pytest.raises(APIError):
            async for _ in astream_json_events(
                session_request=session_request,
                method="POST", url="https://example.com/stream",
                headers={}, params=None, json_body=None, data=None,
                timeout=10.0, parser=_identity_parser,
            ):
                pass

    async def test_invalid_json_skipped(self) -> None:
        bad_chunk = b"event: chunk\ndata: not-json\n\n"
        good_chunk = _sse_bytes("chunk", {"ok": True})
        resp = FakeResponse(chunks=[bad_chunk, good_chunk])
        session_request = AsyncMock(return_value=resp)

        items: list[_ParsedItem] = []
        async for item in astream_json_events(
            session_request=session_request,
            method="POST", url="https://example.com/stream",
            headers={}, params=None, json_body=None, data=None,
            timeout=10.0, parser=_identity_parser,
        ):
            items.append(item)

        # bad chunk yields (event, None) since obj is None; good chunk has data
        good_items = [i for i in items if i[1] is not None]
        assert len(good_items) == 1
        assert good_items[0][1] == {"ok": True}

    async def test_done_marker_skipped(self) -> None:
        done_chunk = b"data: [DONE]\n\n"
        real_chunk = _sse_bytes("chunk", {"x": 1})
        resp = FakeResponse(chunks=[real_chunk, done_chunk])
        session_request = AsyncMock(return_value=resp)

        items: list[_ParsedItem] = []
        async for item in astream_json_events(
            session_request=session_request,
            method="POST", url="https://example.com/stream",
            headers={}, params=None, json_body=None, data=None,
            timeout=10.0, parser=_identity_parser,
        ):
            items.append(item)

        assert len(items) == 1  # [DONE] is skipped

    async def test_parser_error_skipped(self) -> None:
        resp = FakeResponse(chunks=[
            _sse_bytes("chunk", {"x": 1}),
            _sse_bytes("chunk", {"x": 2}),
        ])
        session_request = AsyncMock(return_value=resp)
        call_count = 0

        def failing_parser(ev: SSEEvent, obj: dict[str, Any] | None) -> _ParsedItem:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise ValueError("parse fail")
            return (ev.event, obj)

        items: list[_ParsedItem] = []
        async for item in astream_json_events(
            session_request=session_request,
            method="POST", url="https://example.com/stream",
            headers={}, params=None, json_body=None, data=None,
            timeout=10.0, parser=failing_parser,
        ):
            items.append(item)

        assert len(items) == 1  # first event skipped due to parser error
        assert items[0][1] == {"x": 2}


# ── Request forwarding ──────────────────────────────────────────────────────


class TestAStreamRequestForwarding:
    async def test_passes_method_url_headers(self) -> None:
        resp = FakeResponse(chunks=[])
        session_request = AsyncMock(return_value=resp)

        headers: dict[str, str] = {"Authorization": "Bearer token"}
        async for _ in astream_json_events(
            session_request=session_request,
            method="POST", url="https://api.example.com/v1/chat",
            headers=headers, params=None,
            json_body={"prompt": "test"}, data=None,
            timeout=30.0, parser=_identity_parser,
        ):
            pass

        session_request.assert_awaited_once()
        call_kwargs: Any = session_request.call_args
        assert call_kwargs[0][0] == "POST"
        assert call_kwargs[0][1] == "https://api.example.com/v1/chat"
        assert call_kwargs[1]["headers"] == headers
        assert call_kwargs[1]["json"] == {"prompt": "test"}
        assert call_kwargs[1]["timeout"] == 30.0
        assert call_kwargs[1]["stream"] is True

    async def test_headers_forwarded_to_events(self) -> None:
        resp = FakeResponse(
            headers={"x-request-id": "req-123", "content-type": "text/event-stream"},
            chunks=[_sse_bytes("chunk", {"x": 1})],
        )
        session_request = AsyncMock(return_value=resp)

        def header_parser(ev: SSEEvent, obj: dict[str, Any] | None) -> Mapping[str, str] | None:
            return ev.headers

        items: list[Mapping[str, str] | None] = []
        async for item in astream_json_events(
            session_request=session_request,
            method="POST", url="https://example.com/stream",
            headers={}, params=None, json_body=None, data=None,
            timeout=10.0, parser=header_parser,
        ):
            items.append(item)

        assert len(items) == 1
        assert items[0] is not None
        assert items[0]["x-request-id"] == "req-123"
