# pyright: reportPrivateUsage=false
"""Unit tests: _build_url and _build_headers."""

from seaart._base_client import BaseClient
from seaart._enums import AppId


class _StubClient(BaseClient[None]):
    def _init_session(self) -> None:
        return None


class TestBuildUrl:
    def test_relative_path(self) -> None:
        c = _StubClient(base_url="https://api.example.com/v1")
        assert c._build_url("users/me") == "https://api.example.com/v1/users/me"

    def test_relative_path_leading_slash(self) -> None:
        c = _StubClient(base_url="https://api.example.com/v1")
        assert c._build_url("/users/me") == "https://api.example.com/v1/users/me"

    def test_base_trailing_slash(self) -> None:
        c = _StubClient(base_url="https://api.example.com/v1/")
        assert c._build_url("users/me") == "https://api.example.com/v1/users/me"

    def test_absolute_http(self) -> None:
        c = _StubClient()
        assert c._build_url("http://other.com/path") == "http://other.com/path"

    def test_absolute_https(self) -> None:
        c = _StubClient()
        assert c._build_url("https://other.com/path") == "https://other.com/path"

    def test_protocol_relative(self) -> None:
        c = _StubClient()
        assert c._build_url("//cdn.example.com/file") == "https://cdn.example.com/file"


class TestBuildHeaders:
    def test_default_headers(self) -> None:
        c = _StubClient()
        h = c._build_headers(None)
        assert "User-Agent" in h
        assert h["Accept"] == "application/json"
        assert h["x-app-id"] == AppId.WEB.value

    def test_token_included(self) -> None:
        c = _StubClient(token="my-secret-token")
        h = c._build_headers(None)
        assert h["token"] == "my-secret-token"

    def test_no_token_when_none(self) -> None:
        c = _StubClient(token=None)
        h = c._build_headers(None)
        assert "token" not in h

    def test_extra_headers_merged(self) -> None:
        c = _StubClient()
        h = c._build_headers({"X-Custom": "value"})
        assert h["X-Custom"] == "value"

    def test_extra_overrides(self) -> None:
        c = _StubClient()
        h = c._build_headers({"Accept": "text/html"})
        assert h["Accept"] == "text/html"

    def test_default_headers_config(self) -> None:
        c = _StubClient(default_headers={"X-Team": "backend"})
        h = c._build_headers(None)
        assert h["X-Team"] == "backend"

    def test_app_id_custom(self) -> None:
        c = _StubClient(app_id=AppId.APP)
        h = c._build_headers(None)
        assert h["x-app-id"] == AppId.APP.value
