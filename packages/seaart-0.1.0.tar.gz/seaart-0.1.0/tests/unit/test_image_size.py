"""Unit tests: ImageSize enum."""

from __future__ import annotations

import pytest

from seaart._enums import ImageSize


class TestImageSizePresets:
    @pytest.mark.parametrize(
        ("member", "w", "h"),
        [
            (ImageSize.SQUARE, 1, 1),
            (ImageSize.PORTRAIT_2_3, 2, 3),
            (ImageSize.LANDSCAPE_16_9, 16, 9),
            (ImageSize.PORTRAIT_9_16, 9, 16),
            (ImageSize.LANDSCAPE_4_3, 4, 3),
        ],
    )
    def test_width_height(self, member: ImageSize, w: int, h: int) -> None:
        assert member.width == w
        assert member.height == h

    def test_ratio(self) -> None:
        assert ImageSize.SQUARE.ratio == "1:1"
        assert ImageSize.PORTRAIT_2_3.ratio == "2:3"

    def test_is_custom_false(self) -> None:
        assert not ImageSize.SQUARE.is_custom
        assert not ImageSize.LANDSCAPE_16_9.is_custom


class TestImageSizeCustom:
    def test_custom_valid(self) -> None:
        size = ImageSize.custom(512, 768)
        assert size.width == 512
        assert size.height == 768
        assert size.ratio == "512:768"
        assert size.is_custom

    def test_custom_minimum(self) -> None:
        size = ImageSize.custom(384, 384)
        assert size.width == 384

    def test_custom_too_small_width(self) -> None:
        with pytest.raises(ValueError, match="at least 384"):
            ImageSize.custom(383, 512)

    def test_custom_too_small_height(self) -> None:
        with pytest.raises(ValueError, match="at least 384"):
            ImageSize.custom(512, 383)

    def test_missing_creates_custom(self) -> None:
        size = ImageSize("999:111")
        assert size.value == "999:111"
        assert size.is_custom
