"""Integration tests: search resource."""

from __future__ import annotations

from seaart import AsyncClient


QUERY = "anime"


class TestSearch:
    async def test_all(self, client: AsyncClient) -> None:
        result = await client.search.all(QUERY, page_size=5)
        assert result.status.code == 10000
        assert result.value is not None

    async def test_works(self, client: AsyncClient) -> None:
        result = await client.search.works(QUERY, page_size=5)
        assert result.status.code == 10000

    async def test_models(self, client: AsyncClient) -> None:
        result = await client.search.models(QUERY, page_size=5)
        assert result.status.code == 10000

    async def test_characters(self, client: AsyncClient) -> None:
        result = await client.search.characters(QUERY, page_size=5)
        assert result.status.code == 10000

    async def test_ai_apps(self, client: AsyncClient) -> None:
        result = await client.search.ai_apps(QUERY, page_size=5)
        assert result.status.code == 10000

    async def test_posts(self, client: AsyncClient) -> None:
        result = await client.search.posts(QUERY, page_size=5)
        assert result.status.code == 10000

    async def test_ai_videos(self, client: AsyncClient) -> None:
        result = await client.search.ai_videos(QUERY, page_size=5)
        assert result.status.code == 10000

    async def test_workflows(self, client: AsyncClient) -> None:
        result = await client.search.workflows(QUERY, page_size=5)
        assert result.status.code == 10000

    async def test_all_with_order(self, client: AsyncClient) -> None:
        result = await client.search.all(QUERY, page_size=5, order_by="new")
        assert result.status.code == 10000

    async def test_all_with_pagination(self, client: AsyncClient) -> None:
        result = await client.search.all(QUERY, page=2, page_size=5)
        assert result.status.code == 10000
