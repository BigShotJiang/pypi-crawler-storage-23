"""Integration tests: prompts resource."""

from typing import Any

from seaart import AsyncClient
from seaart._internal._schemas import APIEnvelope


class TestPrompts:
    async def test_render(self, client: AsyncClient) -> None:
        result = await client.prompts.render("a cute cat")
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0

    async def test_stream_render(self, client: AsyncClient) -> None:
        chunks: list[APIEnvelope[Any]] = []
        async for env in client.prompts.stream_render("a cute cat"):
            chunks.append(env)
        assert len(chunks) > 0

    async def test_recommend(self, client: AsyncClient, model_no: str) -> None:
        result = await client.prompts.recommend(model_no)
        assert result.status.code == 10000
