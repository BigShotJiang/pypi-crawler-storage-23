"""Integration tests: models resource."""

from __future__ import annotations

from seaart import AsyncClient


class TestModels:
    async def test_detail(self, client: AsyncClient, model_no: str) -> None:
        result = await client.models.detail(model_no)
        assert result.status.code == 10000
        assert result.value is not None

    async def test_generation_parameters(self, client: AsyncClient, model_no: str) -> None:
        detail = await client.models.detail(model_no)
        ver_no = detail.value.model_ver_nos[0].id

        result = await client.models.generation_parameters(model_no, ver_no)
        assert result.status.code == 10000
        assert result.value is not None
