"""Shared fixtures for integration tests.

Required env vars:
    SEAART_TOKEN           – auth token (skip all tests if missing)

Optional env vars:
    SEAART_CHARACTER_ID    – character id for chat tests
    SEAART_MODEL_NO        – model number for image/model tests
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator

import pytest
import pytest_asyncio

from seaart import AsyncClient


# ---------------------------------------------------------------------------
# Auto-skip when token is absent
# ---------------------------------------------------------------------------

def pytest_collection_modifyitems(
    config: pytest.Config,  # noqa: ARG001
    items: list[pytest.Item],
) -> None:
    token = os.environ.get("SEAART_TOKEN")
    if token:
        return
    skip = pytest.mark.skip(reason="SEAART_TOKEN not set")
    for item in items:
        if "integration" in str(item.fspath):
            item.add_marker(skip)


# ---------------------------------------------------------------------------
# Client fixtures
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture(scope="session")
async def client() -> AsyncIterator[AsyncClient]:
    """Authenticated async client (session-scoped, shared across all tests)."""
    token = os.environ["SEAART_TOKEN"]
    async with AsyncClient(token=token) as c:
        yield c


@pytest_asyncio.fixture(scope="session")
async def tourist_client() -> AsyncIterator[AsyncClient]:
    """Tourist-authenticated async client."""
    async with AsyncClient() as c:
        resp = await c.auth.login_as_tourist()
        c.set_token(resp.value.token)
        yield c


# ---------------------------------------------------------------------------
# Reusable test data
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def character_id() -> str:
    """Character id from env or a well-known default."""
    return os.environ.get("SEAART_CHARACTER_ID", "d5f5v2te878c73cmjhhg")


@pytest.fixture(scope="session")
def model_no() -> str:
    """Model number from env or a well-known default."""
    return os.environ.get("SEAART_MODEL_NO", "cu8d8ble878c738hejd0")
