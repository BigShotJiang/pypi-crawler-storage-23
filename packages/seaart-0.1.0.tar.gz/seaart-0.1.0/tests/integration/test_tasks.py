"""Integration tests: tasks resource.

Most task tests require an existing task_id, which we try to
obtain from history. Tests that mutate tasks (cancel, delete, speed_up)
are marked ``expensive`` since they need a live task to operate on.
"""

from __future__ import annotations

import pytest

from seaart import AsyncClient


TEST_IMAGE_URL = "https://image.cdn2.seaart.me/2026-03-01/d6iaplte878c7394hke0/6df71b7525cde42de0ac8f45671524df_high.webp"


class TestTasksReadOnly:
    @pytest.fixture
    async def task_id(self, client: AsyncClient) -> str:
        """Get a task_id from recent history, or skip."""
        history = await client.images.history.list_v2(limit=1)
        items = history.value.items if history.value else None
        if not items or items[0].id is None:
            pytest.skip("no history items — cannot get task_id")
        return items[0].id

    async def test_batch_progress(self, client: AsyncClient, task_id: str) -> None:
        result = await client.tasks.batch_progress([task_id])
        assert result.status.code == 10000

    async def test_progress(self, client: AsyncClient, task_id: str) -> None:
        result = await client.tasks.progress(task_id)
        assert result.status.code == 10000

    async def test_detail(self, client: AsyncClient, task_id: str) -> None:
        result = await client.tasks.detail(task_id)
        assert result.status.code == 10000
        assert result.value is not None


@pytest.mark.expensive
class TestTasksMutating:
    async def test_cancel(self, client: AsyncClient, model_no: str) -> None:
        """Requires a running task — generate one first."""
        gen = await client.images.text_to_img("a cat on a skateboard", model_no)
        task_id = gen.value.id
        result = await client.tasks.cancel(task_id)
        assert result.status.code == 10000

    async def test_delete(self, client: AsyncClient) -> None:
        """Delete a task from history."""
        history = await client.images.history.list_v2(limit=1)
        items = history.value.items if history.value else None
        if not items or items[0].id is None:
            pytest.skip("no tasks to delete")
        result = await client.tasks.delete(items[0].id)
        assert result.status.code == 10000

    async def test_speed_up(self, client: AsyncClient, model_no: str) -> None:
        """Speed up requires a running task."""
        gen = await client.images.text_to_img("a dog riding a bicycle", model_no)
        task_id = gen.value.id
        result = await client.tasks.speed_up(task_id)
        assert result.status.code == 10000