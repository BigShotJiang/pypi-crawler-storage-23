"""Integration tests: genagent resource."""

from collections.abc import AsyncIterator

import pytest_asyncio

from seaart import AsyncClient
from seaart._internal._schemas.genagent.gen_agent_messages import (
    AgentGenerationStreamItem,
)


class TestGenAgent:
    @pytest_asyncio.fixture
    async def conv_id(self, client: AsyncClient) -> AsyncIterator[str]:
        """Create a conversation and clean up after."""
        created = await client.genagent.create()
        conv_id = created.value.conv_id
        yield conv_id
        await client.genagent.delete(conv_id)

    async def test_create_and_delete(self, client: AsyncClient) -> None:
        created = await client.genagent.create()
        assert created.status.code == 10000
        conv_id = created.value.conv_id
        assert conv_id

        deleted = await client.genagent.delete(conv_id)
        assert deleted.status.code == 10000

    async def test_stream(self, client: AsyncClient, conv_id: str) -> None:
        chunks: list[AgentGenerationStreamItem] = []
        async for item in client.genagent.messages.stream(
            message="Generate a simple cat image",
            conv_id=conv_id,
        ):
            chunks.append(item)
        assert len(chunks) > 0

    async def test_send(self, client: AsyncClient, conv_id: str) -> None:
        result = await client.genagent.messages.send(
            message="Generate a simple dog image",
            conv_id=conv_id,
        )
        # send() can return None if the stream produced no parseable result
        if result is not None:
            assert result.text is not None
