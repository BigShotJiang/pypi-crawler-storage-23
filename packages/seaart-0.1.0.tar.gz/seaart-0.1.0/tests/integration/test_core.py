"""Integration tests: health, auth, account, payments."""

from __future__ import annotations

import os

import pytest

from seaart import AsyncClient


# ── Health ──────────────────────────────────────────────────────────────────

class TestHealth:
    async def test_ping(self, client: AsyncClient) -> None:
        result = await client.health.ping()
        assert result.status.code == 10000

    async def test_ping_with_action(self, client: AsyncClient) -> None:
        result = await client.health.ping(action="first_open")
        assert result.status.code == 10000


# ── Auth ────────────────────────────────────────────────────────────────────

class TestAuth:
    async def test_login_as_tourist(self) -> None:
        async with AsyncClient() as c:
            resp = await c.auth.login_as_tourist()
            assert resp.value.token
            assert isinstance(resp.value.token, str)

    async def test_tourist_logout(self) -> None:
        async with AsyncClient() as c:
            resp = await c.auth.login_as_tourist()
            c.set_token(resp.value.token)
            result = await c.auth.logout()
            assert result.status.code == 10000

    @pytest.mark.skip(reason="requires real credentials, run manually")
    async def test_login(self) -> None:
        """Skipped by default — requires SEAART_EMAIL / SEAART_PASSWORD."""
        async with AsyncClient() as c:
            resp = await c.auth.login(
                email=os.environ["SEAART_EMAIL"],
                password=os.environ["SEAART_PASSWORD"],
            )
            assert resp.value.token

    @pytest.mark.skip(reason="sends a real email, run manually")
    async def test_forgot_password(self) -> None:
        pass


# ── Account ─────────────────────────────────────────────────────────────────

class TestAccount:
    async def test_me(self, client: AsyncClient) -> None:
        result = await client.account.me()
        info = result.value
        assert info.id is not None
        assert info.name is not None

    async def test_settings(self, client: AsyncClient) -> None:
        result = await client.account.settings()
        assert result.status.code == 10000

    async def test_edit(self, client: AsyncClient) -> None:
        """Edit with no changes — should still succeed."""
        result = await client.account.edit()
        assert result.status.code == 10000

    @pytest.mark.skip(reason="destructive — changes password")
    async def test_update_password(self) -> None:
        pass

    @pytest.mark.skip(reason="destructive — deletes account!")
    async def test_delete(self) -> None:
        pass


# ── Payments ────────────────────────────────────────────────────────────────

class TestPayments:
    async def test_assets(self, client: AsyncClient) -> None:
        result = await client.payments.assets()
        assert result.value is not None
