# mkpipe-extractor-timescaledb

TimescaleDB extractor plugin for mkpipe. Uses PostgreSQL JDBC driver.
