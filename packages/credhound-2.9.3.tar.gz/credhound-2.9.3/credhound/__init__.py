"""CredHound - 로컬 파일 보안 credential 탐지 도구"""
__version__ = "2.9.3"
