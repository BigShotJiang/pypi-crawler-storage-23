import sys
import os


__all__ = ["temp"]


def temp():
    pass