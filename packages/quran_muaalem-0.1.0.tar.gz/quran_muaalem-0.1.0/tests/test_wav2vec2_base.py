import torch
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
from time import perf_counter

seconds = 1
# seconds = 2
dtype = torch.float32
# dtype = torch.float16
device = "cpu"

model = Wav2Vec2ForCTC.from_pretrained("facebook/wav2vec2-base-960h").to(
    device, dtype=dtype
)
processor = Wav2Vec2Processor.from_pretrained("facebook/wav2vec2-base-960h")

wave = torch.zeros(1, seconds * 16000, dtype=torch.float16)

# Transcribe
for _ in range(5):
    with torch.no_grad():
        start = perf_counter()
        inputs = processor(wave.squeeze(), sampling_rate=16000, return_tensors="pt").to(
            device, dtype=dtype
        )
        logits = model(inputs.input_values.to(dtype)).logits
        end = perf_counter()
        print(f"Total time on `{device}` with dtype `{dtype}` is : {end - start}")
        print(processor.batch_decode(torch.argmax(logits, dim=-1))[0])
