"""osojicode — AI-powered code quality and documentation auditing tool."""

__version__ = "0.0.1"
