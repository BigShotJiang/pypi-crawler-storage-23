"""Prediction tab modules."""
