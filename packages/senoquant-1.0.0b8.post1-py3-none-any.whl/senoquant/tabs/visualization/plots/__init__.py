"""Visualization plot UI components."""

from __future__ import annotations

import importlib
import pkgutil
from typing import Iterable

from .base import PlotConfig, PlotData, SenoQuantPlot
from .spatialplot import SpatialPlotData
from .umap import UMAPData
from .double_expression import DoubleExpressionData
from .neighborhood import NeighborhoodEnrichmentData


def _iter_subclasses(cls: type[SenoQuantPlot]) -> Iterable[type[SenoQuantPlot]]:
    """Yield all subclasses of a plot class recursively.

    Parameters
    ----------
    cls : type[SenoQuantPlot]
        Base class whose subclasses should be discovered.

    Yields
    ------
    type[SenoQuantPlot]
        Plot subclass types.
    """
    for subclass in cls.__subclasses__():
        yield subclass
        yield from _iter_subclasses(subclass)


def get_plot_registry() -> dict[str, type[SenoQuantPlot]]:
    """Discover plot classes and return a registry by name."""
    for module in pkgutil.walk_packages(__path__, f"{__name__}."):
        importlib.import_module(module.name)

    registry: dict[str, type[SenoQuantPlot]] = {}
    for plot_cls in _iter_subclasses(SenoQuantPlot):
        plot_type = getattr(plot_cls, "plot_type", "")
        if not plot_type:
            continue
        registry[plot_type] = plot_cls

    return dict(
        sorted(
            registry.items(),
            key=lambda item: getattr(item[1], "order", 0),
        )
    )

PLOT_DATA_FACTORY: dict[str, type[PlotData]] = {
    "UMAP": UMAPData,
    "Spatial Plot": SpatialPlotData,
    "Double Expression": DoubleExpressionData,
    "Neighborhood Enrichment": NeighborhoodEnrichmentData,
}


def build_plot_data(plot_type: str) -> PlotData:
    """Create a plot data instance for the specified plot type.

    Parameters
    ----------
    plot_type : str
        Plot type name.

    Returns
    -------
    PlotData
        Plot-specific configuration instance.
    """
    data_cls = PLOT_DATA_FACTORY.get(plot_type, PlotData)
    return data_cls()


__all__ = [
    "PlotConfig",
    "PlotData",
    "SenoQuantPlot",
    "build_plot_data",
    "get_plot_registry",
]
