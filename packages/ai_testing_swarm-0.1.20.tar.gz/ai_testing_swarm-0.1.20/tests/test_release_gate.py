from ai_testing_swarm.agents.release_gate_agent import ReleaseGateAgent


def test_release_gate_treats_method_not_allowed_as_expected():
    agent = ReleaseGateAgent()
    results = [
        {
            "name": "happy_path",
            "failure_type": "success",
            "response": {"status_code": 200},
        },
        {
            "name": "wrong_method_get",
            "failure_type": "method_not_allowed",
            "response": {"status_code": 405},
        },
    ]

    assert agent.decide(results) == "APPROVE_RELEASE"


def test_release_gate_rejects_on_security_risk():
    agent = ReleaseGateAgent()
    results = [
        {
            "name": "happy_path",
            "failure_type": "success",
            "response": {"status_code": 200},
        },
        {
            "name": "security_body_password_1",
            "failure_type": "security_risk",
            "response": {"status_code": 200},
        },
    ]

    assert agent.decide(results) == "REJECT_RELEASE"
