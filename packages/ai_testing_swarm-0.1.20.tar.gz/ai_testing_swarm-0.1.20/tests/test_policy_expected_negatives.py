from ai_testing_swarm.agents.llm_reasoning_agent import LLMReasoningAgent
from ai_testing_swarm.agents.release_gate_agent import ReleaseGateAgent


def test_wrong_method_405_is_expected_not_blocking():
    reasoner = LLMReasoningAgent()

    exec_result = {
        "name": "wrong_method_POST",
        "mutation": {"strategy": "method_misuse"},
        "response": {"status_code": 405, "elapsed_ms": 10, "body_snippet": ""},
    }

    cls = reasoner.reason(exec_result)
    assert cls["type"] == "method_not_allowed"

    # Gate should not reject release if happy path passes and only expected negatives exist
    gate = ReleaseGateAgent()
    decision = gate.decide([
        {"name": "happy_path", "failure_type": "success", "response": {"status_code": 200}},
        {"name": "wrong_method_POST", "failure_type": cls["type"], "response": {"status_code": 405}},
    ])
    assert decision in ("APPROVE_RELEASE", "APPROVE_RELEASE_WITH_RISKS")


def test_accept_header_406_is_expected():
    reasoner = LLMReasoningAgent()
    exec_result = {
        "name": "headers_accept_text",
        "mutation": {"strategy": "headers"},
        "response": {"status_code": 406, "elapsed_ms": 10, "body_snippet": ""},
    }
    cls = reasoner.reason(exec_result)
    assert cls["type"] == "content_negotiation"
