import json
from pathlib import Path

from ai_testing_swarm.cli import normalize_request


def test_openapi_normalize_builds_request():
    repo_root = Path(__file__).resolve().parents[1]
    payload = json.loads((repo_root / "input" / "openapi_public_example.json").read_text())

    # Ensure relative openapi path resolves from repo root
    payload["openapi"] = str(repo_root / "input" / "openapi_spec_postman_echo.json")

    req = normalize_request(payload)

    assert req["method"] == "POST"
    assert req["url"].startswith("https://postman-echo.com/post")
    assert req["body"]["hello"] == "world"
    assert req.get("_openapi", {}).get("path") == "/post"
