import json
import os
from pathlib import Path

import pytest

allure = pytest.importorskip("allure")

LIVE_TEST_ENABLED = os.getenv("AI_SWARM_RUN_LIVE_TESTS", "0").lower() in {"1", "true", "yes"}

from ai_testing_swarm.core.curl_parser import parse_curl
from ai_testing_swarm.orchestrator import SwarmOrchestrator


@allure.epic("AI Testing Swarm")
@pytest.mark.integration
@pytest.mark.skipif(not LIVE_TEST_ENABLED, reason="Live swarm test disabled (set AI_SWARM_RUN_LIVE_TESTS=1)")
def test_swarm():
    # Public-only test target (enforced by orchestrator safety guard)
    repo_root = Path(__file__).resolve().parents[1]
    payload = json.loads((repo_root / "input" / "public_example_request.json").read_text())
    request = parse_curl(payload["curl"])

    decision, results = SwarmOrchestrator().run(request)

    allure.attach(decision, "Release Decision")

    for r in results:
        allure.attach(str(r), r["name"])

    assert decision in ["APPROVE_RELEASE", "APPROVE_RELEASE_WITH_RISKS", "REJECT_RELEASE"]
