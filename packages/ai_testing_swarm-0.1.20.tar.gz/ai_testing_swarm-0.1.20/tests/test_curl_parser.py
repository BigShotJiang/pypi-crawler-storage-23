from ai_testing_swarm.core.curl_parser import parse_curl


def test_parse_curl_preserves_explicit_method_with_data():
    parsed = parse_curl(
        "curl -X PUT https://example.com/orders/123 "
        "-H 'Content-Type: application/json' "
        "--data '{\"status\":\"shipped\"}'"
    )

    assert parsed["method"] == "PUT"
    assert parsed["body"] == {"status": "shipped"}


def test_parse_curl_extracts_query_params_and_url():
    parsed = parse_curl("curl 'https://example.com/search?q=chair&page=2'")

    assert parsed["url"] == "https://example.com/search"
    assert parsed["params"] == {"q": "chair", "page": "2"}
