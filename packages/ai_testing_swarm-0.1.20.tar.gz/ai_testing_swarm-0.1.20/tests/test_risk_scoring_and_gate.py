from ai_testing_swarm.core.risk import (
    RiskThresholds,
    compute_test_risk_score,
    compute_endpoint_risk_score,
    gate_from_score,
)


def test_compute_test_risk_score_expected_is_low():
    r = {
        "failure_type": "missing_param",
        "status": "PASSED",
        "response": {"status_code": 400, "elapsed_ms": 10},
    }
    assert compute_test_risk_score(r, sla_ms=2000) == 0


def test_compute_test_risk_score_blocking_is_high():
    r = {
        "failure_type": "security_risk",
        "status": "FAILED",
        "response": {"status_code": 200, "elapsed_ms": 10},
    }
    assert compute_test_risk_score(r, sla_ms=2000) >= 90


def test_endpoint_risk_is_max_test_risk():
    results = [
        {"risk_score": 10},
        {"risk_score": 80},
        {"risk_score": 35},
    ]
    assert compute_endpoint_risk_score(results) == 80


def test_gate_from_score_thresholds():
    thr = RiskThresholds(warn=30, block=80)
    assert gate_from_score(0, thr) == "PASS"
    assert gate_from_score(30, thr) == "WARN"
    assert gate_from_score(79, thr) == "WARN"
    assert gate_from_score(80, thr) == "BLOCK"
