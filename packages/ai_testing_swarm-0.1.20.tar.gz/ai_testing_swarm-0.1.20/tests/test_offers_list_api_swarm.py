import json
import logging
import os

import pytest

allure = pytest.importorskip("allure")

LIVE_TEST_ENABLED = os.getenv("AI_SWARM_RUN_LIVE_TESTS", "0").lower() in {"1", "true", "yes"}
PRIVATE_TEST_ENABLED = os.getenv("AI_SWARM_RUN_PRIVATE_TESTS", "0").lower() in {"1", "true", "yes"}

from ai_testing_swarm.core.curl_parser import parse_curl
from ai_testing_swarm.orchestrator import SwarmOrchestrator


# ------------------------------------------------------------------------------
# Logger setup
# ------------------------------------------------------------------------------
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


@pytest.fixture
def private_target_mode():
    previous_public_only = os.environ.get("AI_SWARM_PUBLIC_ONLY")
    os.environ["AI_SWARM_PUBLIC_ONLY"] = "0"
    try:
        yield
    finally:
        if previous_public_only is None:
            os.environ.pop("AI_SWARM_PUBLIC_ONLY", None)
        else:
            os.environ["AI_SWARM_PUBLIC_ONLY"] = previous_public_only


@allure.feature("Offers APIs")
@allure.story("Offers List – SKU Based")
@allure.severity(allure.severity_level.CRITICAL)
@pytest.mark.integration
@pytest.mark.skipif(not LIVE_TEST_ENABLED, reason="Live swarm test disabled (set AI_SWARM_RUN_LIVE_TESTS=1)")
@pytest.mark.skipif(not PRIVATE_TEST_ENABLED, reason="Private offers test disabled (set AI_SWARM_RUN_PRIVATE_TESTS=1)")
def test_offers_list_api_swarm(private_target_mode):
    """
    AI-powered swarm test for:
    GET /api/offers/{sku}/list

    PURPOSE:
    - Validate API robustness
    - Validate query/path handling
    - Validate security behavior
    - Validate swarm reasoning
    """

    # --------------------------------------------------------------------------
    # STEP 1: Prepare CURL
    # --------------------------------------------------------------------------
    with allure.step("Prepare input CURL"):
        curl = (
            "curl --location "
            "'https://api.wakefit.co/api/offers/WOMFM72366/list' "
            "--header 'authority: api.wakefit.co' "
            "--header 'accept: application/json, text/plain, */*' "
            "--header 'accept-language: en-GB,en-US;q=0.9,en;q=0.8' "
            "--header 'api-secret-key: ycq55IbIjkLb' "
            "--header 'api-token: c84d563b77441d784dce71323f69eb42' "
            "--header 'content-type: application/json' "
            "--header 'my-cookie: undefined' "
            "--header 'origin: https://www.wakefit.co' "
            "--header 'referer: https://www.wakefit.co/' "
            "--header 'sec-ch-ua: \"Chromium\";v=\"110\", \"Not A(Brand\";v=\"24\", \"Google Chrome\";v=\"110\"' "
            "--header 'sec-ch-ua-mobile: ?0' "
            "--header 'sec-ch-ua-platform: \"macOS\"' "
            "--header 'sec-fetch-dest: empty' "
            "--header 'sec-fetch-mode: cors' "
            "--header 'sec-fetch-site: same-site' "
            "--header 'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'"
        )

        logger.info("📌 Input CURL prepared")
        allure.attach(curl, "Input CURL", allure.attachment_type.TEXT)

    # --------------------------------------------------------------------------
    # STEP 2: Parse CURL
    # --------------------------------------------------------------------------
    with allure.step("Parse CURL into structured request"):
        request = parse_curl(curl)

        logger.info("🔍 Parsed request")
        allure.attach(
            json.dumps(request, indent=2),
            "Parsed Request",
            allure.attachment_type.JSON,
        )

    # --------------------------------------------------------------------------
    # STEP 3: Run AI Testing Swarm
    # --------------------------------------------------------------------------
    with allure.step("Execute AI Testing Swarm"):
        logger.info("🤖 Running AI Swarm for Offers List API")
        decision, results = SwarmOrchestrator().run(request)

        logger.info("🚦 Release Decision = %s", decision)
        allure.attach(decision, "Release Decision", allure.attachment_type.TEXT)

    # --------------------------------------------------------------------------
    # STEP 4: Attach raw swarm results
    # --------------------------------------------------------------------------
    with allure.step("Attach AI Swarm detailed results"):
        allure.attach(
            json.dumps(results, indent=2),
            "AI Swarm Results",
            allure.attachment_type.JSON,
        )

    # --------------------------------------------------------------------------
    # STEP 5: Human-readable summary
    # --------------------------------------------------------------------------
    with allure.step("Attach human-readable test summary"):
        summary = []
        for r in results:
            summary.append(
                f"{r['name']:35} | "
                f"HTTP={r['response']['status_code']} | "
                f"type={r['failure_type']}"
            )

        summary_text = "\n".join(summary)
        logger.info("🧪 Swarm Summary:\n%s", summary_text)

        allure.attach(
            summary_text,
            "AI Swarm Summary",
            allure.attachment_type.TEXT,
        )

    # --------------------------------------------------------------------------
    # STEP 6: 🧠 Validate swarm intelligence (NOT CI gate)
    # --------------------------------------------------------------------------
    with allure.step("Validate swarm reasoning and decisions"):

        # ------------------------------------------------------
        # 1️⃣ Happy path MUST exist and succeed
        # ------------------------------------------------------
        happy_path = next(
            (r for r in results if r.get("name") == "happy_path"),
            None,
        )

        assert happy_path is not None, "❌ Happy path test was not executed"

        status_code = happy_path.get("response", {}).get("status_code")
        if status_code is None:
            error = happy_path.get("response", {}).get("error", "Unknown network error")
            pytest.skip(f"Private endpoint unreachable from current network: {error}")

        assert status_code == 200, f"❌ Happy path failed with {status_code}"

        # ------------------------------------------------------
        # 2️⃣ Blocking failures (visible, not fatal)
        # ------------------------------------------------------
        blocking_failures = [
            r for r in results
            if r["failure_type"] in {"security_risk", "infra", "auth_issue"}
        ]

        if blocking_failures:
            allure.dynamic.severity(allure.severity_level.NORMAL)

            allure.attach(
                json.dumps(blocking_failures, indent=2),
                "🚨 Blocking Failures Detected",
                allure.attachment_type.JSON,
            )

            logger.warning(
                "🚨 Blocking failures detected: %s",
                [f"{r['name']}:{r['failure_type']}" for r in blocking_failures],
            )
        else:
            allure.dynamic.severity(allure.severity_level.CRITICAL)

        # ------------------------------------------------------
        # 3️⃣ Sanity check
        # ------------------------------------------------------
        assert results, "❌ No swarm tests executed"

        logger.info("✅ Offers List swarm test completed successfully")
