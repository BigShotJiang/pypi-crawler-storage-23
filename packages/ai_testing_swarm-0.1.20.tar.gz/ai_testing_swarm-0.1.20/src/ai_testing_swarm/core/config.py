import os


def env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except Exception:
        return default


AI_SWARM_WORKERS = env_int("AI_SWARM_WORKERS", 5)
AI_SWARM_MAX_TESTS = env_int("AI_SWARM_MAX_TESTS", 80)
AI_SWARM_RPS = env_int("AI_SWARM_RPS", 0)  # 0 = no throttling
AI_SWARM_RETRY_COUNT = env_int("AI_SWARM_RETRY_COUNT", 1)
AI_SWARM_RETRY_BACKOFF_MS = env_int("AI_SWARM_RETRY_BACKOFF_MS", 250)
AI_SWARM_SLA_MS = env_int("AI_SWARM_SLA_MS", 2000)  # flag slow responses in reports

# Optional OpenAI augmentation (off by default)
AI_SWARM_USE_OPENAI = os.getenv("AI_SWARM_USE_OPENAI", "0").lower() in {"1", "true", "yes"}
AI_SWARM_OPENAI_MODEL = os.getenv("AI_SWARM_OPENAI_MODEL", "gpt-4.1-mini")
AI_SWARM_MAX_AI_TESTS = env_int("AI_SWARM_MAX_AI_TESTS", 20)
AI_SWARM_AI_SUMMARY = os.getenv("AI_SWARM_AI_SUMMARY", "0").lower() in {"1", "true", "yes"}

# OpenAPI schema-based request-body fuzzing (on by default when OpenAPI context exists)
AI_SWARM_OPENAPI_FUZZ = os.getenv("AI_SWARM_OPENAPI_FUZZ", "1").lower() in {"1", "true", "yes"}
AI_SWARM_OPENAPI_FUZZ_MAX_VALID = env_int("AI_SWARM_OPENAPI_FUZZ_MAX_VALID", 8)
AI_SWARM_OPENAPI_FUZZ_MAX_INVALID = env_int("AI_SWARM_OPENAPI_FUZZ_MAX_INVALID", 8)
AI_SWARM_OPENAPI_FUZZ_MAX_DEPTH = env_int("AI_SWARM_OPENAPI_FUZZ_MAX_DEPTH", 6)
