import requests


def send_request(method, url, headers=None, body=None, allow_redirects=False):
    response = requests.request(
        method=method,
        url=url,
        headers=headers,
        json=body,
        timeout=10,
        allow_redirects=allow_redirects
    )

    try:
        response_json = response.json()
    except Exception:
        response_json = {}

    return response, response_json
