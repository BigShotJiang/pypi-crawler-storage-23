# class ReleaseGateAgent:
#     """
#     Release decision engine based on mutation testing semantics.
#
#     IMPORTANT:
#     - Test FAIL does NOT mean system FAIL
#     - Only unexpected behavior blocks release
#     """
#
#     # ❌ These mean SYSTEM IS BROKEN
#     BLOCKING_FAILURES = {
#         "auth_issue",       # auth broken
#         "infra",            # infra / network / 5xx
#         "security_risk",    # malicious payload succeeded (2xx/3xx)
#         "server_error",
#     }
#
#     # ⚠️ Ambiguous behavior (release with caution)
#     RISKY_FAILURES = {
#         "unknown",
#     }
#
#     # ✅ EXPECTED & HEALTHY system behavior
#     EXPECTED_FAILURES = {
#         "success",
#         "missing_param",
#         "invalid_param",
#         "security",
#     }
#
#     def decide(self, results: list) -> str:
#         happy_path_ok = False
#         has_blocker = False
#         has_risk = False
#
#         for r in results:
#             test_name = r.get("test_name")
#             failure_type = r.get("failure_type")
#             status_code = r.get("response", {}).get("status_code")
#
#             # -------------------------------
#             # Happy path MUST succeed
#             # -------------------------------
#             if test_name == "happy_path":
#                 if failure_type == "success" and status_code and status_code < 400:
#                     happy_path_ok = True
#                 else:
#                     return "REJECT_RELEASE"
#
#             # -------------------------------
#             # Blocking issues
#             # -------------------------------
#             if failure_type in self.BLOCKING_FAILURES:
#                 has_blocker = True
#
#             # -------------------------------
#             # Risky but not blocking
#             # -------------------------------
#             elif failure_type in self.RISKY_FAILURES:
#                 has_risk = True
#
#             # EXPECTED_FAILURES are intentionally ignored
#
#         # -------------------------------
#         # Final decision
#         # -------------------------------
#         if has_blocker:
#             return "REJECT_RELEASE"
#
#         if has_risk:
#             return "APPROVE_RELEASE_WITH_RISKS"
#
#         return "APPROVE_RELEASE"
import logging

logger = logging.getLogger(__name__)

class ReleaseGateAgent:
    """
    Release decision engine based on mutation testing semantics.

    IMPORTANT:
    - Test FAIL does NOT mean system FAIL
    - Only unexpected behavior blocks release
    """

    # ❌ These mean SYSTEM IS BROKEN
    BLOCKING_FAILURES = {
        "auth_issue",       # auth broken
        "infra",            # infra / network / 5xx
        "security_risk",    # malicious payload succeeded (2xx/3xx)
        "server_error",
    }

    # ⚠️ Ambiguous behavior (release with caution)
    RISKY_FAILURES = {
        "unknown",
    }

    # ✅ EXPECTED & HEALTHY system behavior
    EXPECTED_FAILURES = {
        "success",
        "missing_param",
        "invalid_param",
        "security",         # 🔥 IMPORTANT: security blocked = SAFE
        "method_not_allowed",  # wrong-method tests should typically return 405
    }

    def decide(self, results: list) -> str:
        happy_path_ok = False
        has_blocker = False
        has_risk = False

        for r in results:
            # ✅ FIX 1: correct key
            test_name = r.get("name") or r.get("test_name")
            failure_type = r.get("failure_type")
            status_code = r.get("response", {}).get("status_code")

            logger.info(
                "🔍 Evaluating test=%s | failure_type=%s | status_code=%s",
                test_name,
                failure_type,
                status_code,
            )

            # -------------------------------
            # Happy path MUST succeed
            # -------------------------------
            if test_name == "happy_path":
                if failure_type == "success" and status_code and status_code < 400:
                    happy_path_ok = True
                    logger.info("✅ Happy path passed")
                else:
                    logger.error(
                        "❌ Happy path failed → failure_type=%s status_code=%s",
                        failure_type,
                        status_code,
                    )
                    return "REJECT_RELEASE"

            # -------------------------------
            # Blocking issues
            # -------------------------------
            if failure_type in self.BLOCKING_FAILURES:
                logger.error(
                    "🚫 BLOCKING FAILURE DETECTED → test=%s | failure_type=%s | status_code=%s",
                    test_name,
                    failure_type,
                    status_code,
                )
                has_blocker = True

            # -------------------------------
            # Risky but not blocking
            # -------------------------------
            elif failure_type in self.RISKY_FAILURES:
                logger.warning(
                    "⚠️ Risky behavior detected → test=%s | failure_type=%s",
                    test_name,
                    failure_type,
                )
                has_risk = True

        # -------------------------------
        # Final decision
        # -------------------------------
        if not happy_path_ok:
            return "REJECT_RELEASE"

        if has_blocker:
            return "REJECT_RELEASE"

        if has_risk:
            return "APPROVE_RELEASE_WITH_RISKS"

        return "APPROVE_RELEASE"
