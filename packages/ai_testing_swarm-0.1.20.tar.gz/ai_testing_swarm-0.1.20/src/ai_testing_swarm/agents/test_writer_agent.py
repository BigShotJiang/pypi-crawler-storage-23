import copy


class TestWriterAgent:
    def write(self, request, plan):
        tests = []

        for step in plan:
            if step == "happy_path":
                tests.append(("happy_path", request))
            else:
                for key in request["body"].keys():
                    r = copy.deepcopy(request)
                    if step == "missing_param":
                        r["body"].pop(key, None)
                    elif step == "null_param":
                        r["body"][key] = None
                    elif step == "wrong_type":
                        r["body"][key] = "INVALID"
                    tests.append((f"{step}_{key}", r))

        return tests
