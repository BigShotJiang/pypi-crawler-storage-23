"""Tests for fanart_composer and --fanart CLI flag."""

import os
import tempfile
import unittest

from PIL import Image


class TestComposeFanartHD(unittest.TestCase):
    """compose_fanart produces correct HD dimensions."""

    def _make_jpeg(self, tmpdir: str, width: int, height: int, name: str = "frame.jpg") -> str:
        path = os.path.join(tmpdir, name)
        Image.new("RGB", (width, height), color=(128, 64, 32)).save(path, "JPEG")
        return path

    def test_hd_dimensions_from_16_9_source(self):
        from video_thumbnail_creator.fanart_composer import compose_fanart, FANART_WIDTH_HD, FANART_HEIGHT_HD
        with tempfile.TemporaryDirectory() as tmpdir:
            src = self._make_jpeg(tmpdir, 1920, 1080)
            out = os.path.join(tmpdir, "fanart.jpg")
            result = compose_fanart(src, out, is_4k=False)
            with Image.open(result) as img:
                self.assertEqual(img.size, (FANART_WIDTH_HD, FANART_HEIGHT_HD))

    def test_4k_dimensions_from_16_9_source(self):
        from video_thumbnail_creator.fanart_composer import compose_fanart, FANART_WIDTH_4K, FANART_HEIGHT_4K
        with tempfile.TemporaryDirectory() as tmpdir:
            src = self._make_jpeg(tmpdir, 3840, 2160)
            out = os.path.join(tmpdir, "fanart.jpg")
            result = compose_fanart(src, out, is_4k=True)
            with Image.open(result) as img:
                self.assertEqual(img.size, (FANART_WIDTH_4K, FANART_HEIGHT_4K))

    def test_non_16_9_source_still_produces_hd_output(self):
        """A square (1:1) source should produce 1920×1080 output via blurred background."""
        from video_thumbnail_creator.fanart_composer import compose_fanart, FANART_WIDTH_HD, FANART_HEIGHT_HD
        with tempfile.TemporaryDirectory() as tmpdir:
            src = self._make_jpeg(tmpdir, 1080, 1080)
            out = os.path.join(tmpdir, "fanart.jpg")
            result = compose_fanart(src, out, is_4k=False)
            with Image.open(result) as img:
                self.assertEqual(img.size, (FANART_WIDTH_HD, FANART_HEIGHT_HD))

    def test_returns_absolute_path(self):
        from video_thumbnail_creator.fanart_composer import compose_fanart
        with tempfile.TemporaryDirectory() as tmpdir:
            src = self._make_jpeg(tmpdir, 1920, 1080)
            out = os.path.join(tmpdir, "fanart.jpg")
            result = compose_fanart(src, out, is_4k=False)
            self.assertTrue(os.path.isabs(result))
            self.assertTrue(os.path.isfile(result))


class TestFanartConstants(unittest.TestCase):
    """Module-level constants are defined correctly."""

    def test_fanart_suffix_value(self):
        from video_thumbnail_creator.fanart_composer import FANART_SUFFIX
        self.assertEqual(FANART_SUFFIX, "-fanart")

    def test_resolution_constants(self):
        from video_thumbnail_creator.fanart_composer import (
            FANART_WIDTH_4K, FANART_HEIGHT_4K,
            FANART_WIDTH_HD, FANART_HEIGHT_HD,
        )
        self.assertEqual(FANART_WIDTH_4K, 3840)
        self.assertEqual(FANART_HEIGHT_4K, 2160)
        self.assertEqual(FANART_WIDTH_HD, 1920)
        self.assertEqual(FANART_HEIGHT_HD, 1080)


class TestFanartPublicAPI(unittest.TestCase):
    """compose_fanart and FANART_SUFFIX are exported from __init__."""

    def test_exported_from_package(self):
        from video_thumbnail_creator import compose_fanart, FANART_SUFFIX
        self.assertTrue(callable(compose_fanart))
        self.assertEqual(FANART_SUFFIX, "-fanart")


class TestFanartCLIFlag(unittest.TestCase):
    """--fanart flag is parsed correctly."""

    def _make_parser(self):
        from video_thumbnail_creator.cli import _build_parser
        return _build_parser()

    def test_fanart_defaults_to_false(self):
        parser = self._make_parser()
        args = parser.parse_args(["extract", "input.mp4"])
        self.assertFalse(args.fanart)

    def test_fanart_flag_parsed_as_true(self):
        parser = self._make_parser()
        args = parser.parse_args(["extract", "input.mp4", "--fanart"])
        self.assertTrue(args.fanart)


if __name__ == "__main__":
    unittest.main()
