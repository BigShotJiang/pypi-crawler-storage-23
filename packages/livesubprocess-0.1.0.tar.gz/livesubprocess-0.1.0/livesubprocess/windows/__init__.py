"""Windows-specific implementations of RealtimeStdoutDisplaying."""

from livesubprocess.windows.popen import LivePipeReader

__all__ = ["LivePipeReader"]
