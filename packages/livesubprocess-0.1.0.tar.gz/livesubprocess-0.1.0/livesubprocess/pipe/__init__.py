"""The package for real-time reading from pipe."""
