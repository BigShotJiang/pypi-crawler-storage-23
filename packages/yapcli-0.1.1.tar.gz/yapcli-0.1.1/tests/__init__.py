"""Tests for yapcli package."""
