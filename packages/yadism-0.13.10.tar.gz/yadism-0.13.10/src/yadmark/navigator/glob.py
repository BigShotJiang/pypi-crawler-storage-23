app = None
glob = globals()
