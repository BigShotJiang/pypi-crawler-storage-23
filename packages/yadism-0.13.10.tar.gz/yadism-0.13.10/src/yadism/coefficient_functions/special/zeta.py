from scipy.special import zeta  # pylint: disable=all

zeta2 = zeta(2)
zeta3 = zeta(3)
