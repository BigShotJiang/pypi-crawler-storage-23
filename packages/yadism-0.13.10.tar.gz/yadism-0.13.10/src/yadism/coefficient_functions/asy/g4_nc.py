from ..partonic_channel import EmptyPartonicChannel


class AsyLLNonSinglet(EmptyPartonicChannel):
    pass


class AsyNLLNonSinglet(EmptyPartonicChannel):
    pass


class AsyNNLLNonSinglet(EmptyPartonicChannel):
    pass


class AsyNNNLLNonSinglet(EmptyPartonicChannel):
    pass


class AsyLLIntrinsic(EmptyPartonicChannel):
    pass


class AsyNLLIntrinsicMatching(EmptyPartonicChannel):
    pass


class AsyNLLIntrinsicLight(EmptyPartonicChannel):
    pass
