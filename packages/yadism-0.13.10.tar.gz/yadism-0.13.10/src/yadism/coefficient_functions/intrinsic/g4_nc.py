from ..partonic_channel import EmptyPartonicChannel


class Rplus(EmptyPartonicChannel):
    pass


class Rminus(EmptyPartonicChannel):
    pass
