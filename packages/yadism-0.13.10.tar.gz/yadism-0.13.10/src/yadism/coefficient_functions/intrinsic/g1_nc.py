from ..partonic_channel import EmptyPartonicChannel


class Splus(EmptyPartonicChannel):
    pass


class Sminus(EmptyPartonicChannel):
    pass
