"""Some shorthand notations."""

d3 = 1 / 3.0
d9 = 1 / 9.0
d27 = 1.0 / 27.0
d81 = 1.0 / 81.0
d243 = 1.0 / 243.0
