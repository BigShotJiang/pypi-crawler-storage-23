"""

The main NC reference used is: :cite:`felix-thesis`.

The main CC reference used is: :cite:`gluck-ccheavy`
"""

from . import kernels
