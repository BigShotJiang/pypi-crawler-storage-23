"""Integration smoke test for the analytics monitor server.

Turns on set_analytics(True), waits for the HTTP server to come up on
localhost:8333, makes a real HTTP request, and verifies the dashboard is served.
Also exercises the event queue by firing a mock LLM response event.
"""

import time
import urllib.request
import urllib.error

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def wait_for_server(url: str, timeout: float = 8.0, interval: float = 0.2) -> bool:
    """Poll url until it returns 200 or timeout expires."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(interval)
    return False


def reset_analytics_state() -> None:
    """Force-reset the analytics module thread globals between tests."""
    import orkestra._analytics as _a
    # Stop running servers if any
    if _a._ws_stop:
        _a._ws_stop.set()
    if _a._http_server:
        try:
            _a._http_server.shutdown()
        except Exception:
            pass
    _a._enabled = False
    _a._queue = None
    _a._http_server = None
    _a._ws_stop = None
    _a._ws_thread = None
    _a._handlers_registered = False


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestAnalyticsServerStartup:
    def setup_method(self):
        reset_analytics_state()

    def teardown_method(self):
        import orkestra._analytics as _a
        if _a._enabled:
            from orkestra._analytics import set_analytics
            set_analytics(False)
        reset_analytics_state()

    def test_set_analytics_true_starts_threads(self):
        """set_analytics(True) should start HTTP + WS daemon threads."""
        import orkestra._analytics as _a
        from orkestra._analytics import set_analytics

        set_analytics(True)

        assert _a._enabled is True
        assert _a._http_server is not None
        assert _a._ws_thread is not None
        assert _a._ws_thread.is_alive()
        assert _a._queue is not None

    def test_http_server_responds_on_8333(self):
        """HTTP server on :8333 should serve a 200 response."""
        from orkestra._analytics import set_analytics

        set_analytics(True)

        up = wait_for_server("http://localhost:8333", timeout=8.0)
        assert up, "HTTP server on :8333 did not become reachable within 8 seconds"

    def test_dashboard_html_is_served(self):
        """The response body should be the React dashboard HTML document."""
        from orkestra._analytics import set_analytics

        set_analytics(True)

        up = wait_for_server("http://localhost:8333", timeout=8.0)
        assert up, "Server not reachable"

        with urllib.request.urlopen("http://localhost:8333", timeout=5) as resp:
            assert resp.status == 200
            content_type = resp.headers.get("Content-Type", "")
            body = resp.read().decode("utf-8", errors="replace")

        assert "text/html" in content_type or body.strip().lower().startswith("<!doctype"), (
            f"Expected HTML, got Content-Type={content_type!r}"
        )
        assert "<script" in body.lower() or "assets/" in body, (
            "Response does not look like the built Vite dashboard"
        )

    def test_set_analytics_false_stops_servers(self):
        """set_analytics(False) should clear all server state."""
        import orkestra._analytics as _a
        from orkestra._analytics import set_analytics

        set_analytics(True)
        assert _a._http_server is not None

        set_analytics(False)

        assert _a._enabled is False
        assert _a._http_server is None
        assert _a._ws_stop is None
        assert _a._queue is None

    def test_calling_set_analytics_true_twice_is_idempotent(self):
        """Calling set_analytics(True) again while already enabled is a no-op."""
        import orkestra._analytics as _a
        from orkestra._analytics import set_analytics

        set_analytics(True)
        first_server = id(_a._http_server)

        set_analytics(True)  # second call — should do nothing
        second_server = id(_a._http_server)

        assert first_server == second_server, "Should not create a second HTTP server"


class TestAnalyticsEventFlow:
    """Verify that LLM call events actually reach the monitor queue."""

    def setup_method(self):
        reset_analytics_state()

    def teardown_method(self):
        import orkestra._analytics as _a
        if _a._enabled:
            from orkestra._analytics import set_analytics
            set_analytics(False)
        reset_analytics_state()

    def test_on_response_event_reaches_queue(self):
        """Firing an on_response event should enqueue a serialized payload."""
        import orkestra._analytics as _a
        from orkestra._analytics import set_analytics
        from orkestra._events import emit_event, ON_RESPONSE, EventData
        from orkestra._types import Response

        set_analytics(True)

        fake_response = Response(
            text="hello",
            model="gemini-2.5-flash-lite",
            provider="google",
            cost=0.000005,
            input_tokens=10,
            output_tokens=20,
            input_cost=0.000001,
            output_cost=0.000004,
            savings=0.0001,
            savings_percent=95.0,
            base_model="gemini-3-pro-preview",
            base_cost=0.000105,
        )

        # Stop the WS drain thread so it doesn't consume the queue before we read it
        assert _a._ws_stop is not None
        _a._ws_stop.set()

        emit_event(
            ON_RESPONSE,
            EventData(
                event=ON_RESPONSE,
                provider="google",
                prompt="What is 2+2?",
                model="gemini-2.5-flash-lite",
                response=fake_response,
                metadata={"request_id": "test1234", "duration_ms": 420.0},
            ),
        )

        # The _push handler is synchronous — the item is in the queue immediately
        assert _a._queue is not None
        assert not _a._queue.empty(), "Event was not enqueued"

        payload = _a._queue.get_nowait()
        assert payload["event"] == "on_response"
        assert payload["provider"] == "google"
        assert payload["model"] == "gemini-2.5-flash-lite"
        assert payload["response"]["cost"] == pytest.approx(0.000005)
        assert payload["metadata"]["request_id"] == "test1234"
        assert payload["metadata"]["duration_ms"] == pytest.approx(420.0)
