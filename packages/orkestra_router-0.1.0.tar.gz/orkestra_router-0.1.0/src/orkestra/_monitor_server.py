"""Monitor WebSocket broadcaster — runs inside a daemon thread."""

from __future__ import annotations

import asyncio
import datetime
import json
import queue
import threading
from typing import Any

WS_PORT = 8334

# Per-thread state (only ever accessed from within the WS daemon thread's asyncio loop)
_connected_clients: set = set()
_summary: dict[str, Any] = {
    "total_tokens": 0,
    "total_cost": 0.0,
    "total_savings": 0.0,
    "total_requests": 0,
    "model_distribution": {},
    "provider_distribution": {},
    "requests_over_time": [],
}


# ---------------------------------------------------------------------------
# Public entry point (called from _analytics._run_ws_thread via asyncio.run)
# ---------------------------------------------------------------------------

async def run_ws_server(q: queue.Queue, stop: threading.Event) -> None:  # type: ignore[type-arg]
    """Async entry point: WebSocket server + queue poller."""
    try:
        import websockets  # type: ignore[import-untyped]
    except ImportError as exc:
        raise ImportError(
            "The 'websockets' package is required for analytics monitoring. "
            "Install it with: pip install websockets"
        ) from exc

    async with websockets.serve(_handle_client, "", WS_PORT):
        await _poll_queue(q, stop)


# ---------------------------------------------------------------------------
# WebSocket client handling
# ---------------------------------------------------------------------------

async def _handle_client(websocket: Any) -> None:
    _connected_clients.add(websocket)
    try:
        await websocket.send(json.dumps({"type": "summary", **_summary}))
        await websocket.wait_closed()
    finally:
        _connected_clients.discard(websocket)


async def _broadcast(message: str) -> None:
    dead: set = set()
    for ws in list(_connected_clients):
        try:
            await ws.send(message)
        except Exception:
            dead.add(ws)
    _connected_clients.difference_update(dead)


# ---------------------------------------------------------------------------
# Queue poller
# ---------------------------------------------------------------------------

async def _poll_queue(q: queue.Queue, stop: threading.Event) -> None:  # type: ignore[type-arg]
    while not stop.is_set():
        try:
            while not q.empty():
                payload = q.get_nowait()
                msg = _process_event(payload)
                if msg:
                    await _broadcast(json.dumps(msg))
                    if payload.get("event") == "on_response":
                        await _broadcast(json.dumps({"type": "summary", **_summary}))
        except Exception:
            pass
        await asyncio.sleep(0.05)


# ---------------------------------------------------------------------------
# Event processing + summary accounting
# ---------------------------------------------------------------------------

def _process_event(payload: dict) -> dict | None:
    event = payload.get("event")

    if event == "on_response":
        response = payload.get("response", {})
        metadata = payload.get("metadata", {})

        tokens = response.get("input_tokens", 0) + response.get("output_tokens", 0)
        _summary["total_tokens"] += tokens
        _summary["total_cost"] += response.get("cost", 0.0)
        _summary["total_savings"] += response.get("savings", 0.0)
        _summary["total_requests"] += 1

        model = payload.get("model") or "unknown"
        provider = payload.get("provider") or "unknown"
        _summary["model_distribution"][model] = (
            _summary["model_distribution"].get(model, 0) + 1
        )
        _summary["provider_distribution"][provider] = (
            _summary["provider_distribution"].get(provider, 0) + 1
        )

        minute = datetime.datetime.now().strftime("%H:%M")
        rot: list = _summary["requests_over_time"]
        if rot and rot[-1]["minute"] == minute:
            rot[-1]["count"] += 1
            rot[-1]["tokens"] += tokens
        else:
            rot.append({"minute": minute, "count": 1, "tokens": tokens})
            if len(rot) > 60:
                rot.pop(0)

        return {
            "type": "request",
            "request_id": metadata.get("request_id", ""),
            "timestamp": payload.get("timestamp", 0),
            "event": event,
            "provider": provider,
            "model": model,
            "prompt_preview": (payload.get("prompt") or "")[:200],
            "response": response,
            "routing": {
                "scores": metadata.get("routing_scores", {}),
                "duration_ms": metadata.get("routing_duration_ms", 0),
            },
            "duration_ms": metadata.get("duration_ms", 0),
        }

    if event in ("on_route", "on_chat", "on_stream", "on_stream_complete"):
        return {
            "type": "event",
            "event": event,
            "provider": payload.get("provider"),
            "model": payload.get("model"),
            "metadata": {
                k: v
                for k, v in payload.get("metadata", {}).items()
                if k != "chunk"
            },
            "timestamp": payload.get("timestamp", 0),
        }

    return None
