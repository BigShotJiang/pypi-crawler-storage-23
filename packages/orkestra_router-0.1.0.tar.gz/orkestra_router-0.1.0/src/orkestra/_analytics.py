"""Real-time analytics monitor for orkestra."""

from __future__ import annotations

import os
import queue
import threading
import time
from typing import Any

from orkestra._events import (
    ON_CHAT,
    ON_RESPONSE,
    ON_ROUTE,
    ON_STREAM,
    ON_STREAM_COMPLETE,
    EventData,
    _global_bus,
)

_enabled: bool = False
_handlers_registered: bool = False
_queue: queue.Queue | None = None          # type: ignore[type-arg]
_http_server: Any = None                   # http.server.HTTPServer instance
_ws_stop: threading.Event | None = None
_ws_thread: threading.Thread | None = None


def set_analytics(enabled: bool) -> None:
    """Enable or disable the real-time analytics monitor.

    When enabled, launches a local web server at http://localhost:8333 with a
    dashboard showing live LLM call metrics, routing decisions, costs, and
    savings. Connects via WebSocket on port 8334 for real-time updates.

    Usage::

        import orkestra as o

        o.set_analytics(True)

        provider = o.Provider("google", "YOUR_API_KEY")
        response = provider.chat("Hello")  # appears in dashboard immediately

    Args:
        enabled: True to launch the monitor, False to shut it down.
    """
    global _enabled, _queue, _http_server, _ws_stop, _ws_thread

    if enabled and not _enabled:
        _enabled = True
        dist_path = _get_dist_path()
        _queue = queue.Queue()
        _ws_stop = threading.Event()

        # HTTP server — serves the built React dashboard
        _http_server = _start_http_server(dist_path)

        # WebSocket broadcaster — runs its own asyncio loop in a daemon thread
        _ws_thread = threading.Thread(
            target=_run_ws_thread,
            args=(_queue, _ws_stop),
            daemon=True,
            name="orkestra-ws",
        )
        _ws_thread.start()

        print("[orkestra] running monitor on http://localhost:8333")
        _register_handlers()

    elif not enabled and _enabled:
        _enabled = False
        if _ws_stop:
            _ws_stop.set()
        if _http_server:
            _http_server.shutdown()
        _queue = None
        _http_server = None
        _ws_stop = None
        _ws_thread = None


def _get_dist_path() -> str:
    """Find the built React dashboard files."""
    # 1. Packaged install: _monitor_dist/ alongside this file
    pkg_dist = os.path.join(os.path.dirname(__file__), "_monitor_dist")
    if os.path.isdir(pkg_dist) and os.path.isfile(os.path.join(pkg_dist, "index.html")):
        return pkg_dist

    # 2. Development (src layout): monitor/dist/ two levels up from src/orkestra/
    repo_dist = os.path.normpath(
        os.path.join(os.path.dirname(__file__), "..", "..", "monitor", "dist")
    )
    if os.path.isdir(repo_dist) and os.path.isfile(os.path.join(repo_dist, "index.html")):
        return repo_dist

    raise FileNotFoundError(
        "Monitor dashboard files not found. "
        "Run `cd monitor && npm run build` to build the dashboard, "
        "then copy monitor/dist/ to src/orkestra/_monitor_dist/."
    )


def _start_http_server(dist_path: str) -> Any:
    """Start the HTTP static-file server in a daemon thread. Returns the server."""
    import functools
    import http.server

    class _SilentHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *args: Any) -> None:
            pass

        def end_headers(self) -> None:
            self.send_header("Access-Control-Allow-Origin", "*")
            super().end_headers()

    handler = functools.partial(_SilentHandler, directory=dist_path)
    httpd = http.server.HTTPServer(("", 8333), handler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True, name="orkestra-http")
    t.start()
    return httpd


def _run_ws_thread(q: queue.Queue, stop: threading.Event) -> None:  # type: ignore[type-arg]
    """Entry point for the WebSocket daemon thread."""
    import asyncio
    from orkestra._monitor_server import run_ws_server
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(run_ws_server(q, stop))
    finally:
        loop.close()


def _register_handlers() -> None:
    """Subscribe to global events and forward serialized payloads to the queue."""
    global _handlers_registered
    if _handlers_registered:
        return
    _handlers_registered = True

    def _push(data: EventData) -> None:
        if _queue is None:
            return
        payload: dict[str, Any] = {
            "event": data.event,
            "provider": data.provider,
            "prompt": data.prompt,
            "model": data.model,
            "timestamp": time.time(),
            "metadata": data.metadata,
        }
        if data.response is not None:
            r = data.response
            payload["response"] = {
                "text": (r.text or "")[:500],
                "cost": r.cost,
                "input_tokens": r.input_tokens,
                "output_tokens": r.output_tokens,
                "input_cost": r.input_cost,
                "output_cost": r.output_cost,
                "savings": r.savings,
                "savings_percent": r.savings_percent,
                "base_model": r.base_model,
                "base_cost": r.base_cost,
            }
        try:
            _queue.put_nowait(payload)
        except Exception:
            pass  # never block LLM calls for analytics

    _global_bus.on(ON_CHAT, _push)
    _global_bus.on(ON_STREAM, _push)
    _global_bus.on(ON_ROUTE, _push)
    _global_bus.on(ON_RESPONSE, _push)
    _global_bus.on(ON_STREAM_COMPLETE, _push)
