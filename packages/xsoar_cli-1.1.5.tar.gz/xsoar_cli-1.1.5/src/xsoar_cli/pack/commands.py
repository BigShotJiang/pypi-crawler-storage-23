import sys
from typing import TYPE_CHECKING

import click

from xsoar_cli.utilities import get_xsoar_config, load_config, validate_artifacts_provider, validate_xsoar_connectivity

if TYPE_CHECKING:
    from xsoar_client.xsoar_client import Client


@click.group()
@click.pass_context
def pack(ctx: click.Context) -> None:
    """Various content pack related commands."""


@click.option("--environment", default=None, help="Default environment set in config file.")
@click.command()
@click.argument("pack_id", type=str)
@click.pass_context
@load_config
@validate_xsoar_connectivity
def delete(ctx: click.Context, environment: str | None, pack_id: str) -> None:
    """Deletes a content pack from the XSOAR server."""
    config = get_xsoar_config(ctx)
    xsoar_client: Client = config.get_client(environment)
    if not xsoar_client.is_installed(pack_id=pack_id):
        click.echo(f"Pack ID {pack_id} is not installed. Cannot delete.")
        sys.exit(1)
    xsoar_client.delete(pack_id=pack_id)
    click.echo(f"Deleted pack {pack_id} from XSOAR {environment}")


@click.option("--environment", default=None, help="Default environment set in config file.")
@click.command()
@click.pass_context
@load_config
@validate_artifacts_provider
@validate_xsoar_connectivity
def get_outdated(ctx: click.Context, environment: str | None) -> None:
    """Prints out a list of outdated content packs."""
    config = get_xsoar_config(ctx)
    xsoar_client: Client = config.get_client(environment)
    click.echo("Fetching outdated packs. This may take a little while...", err=True)
    outdated_packs = xsoar_client.get_outdated_packs()
    if not outdated_packs:
        click.echo("No outdated packs found")
        sys.exit(0)
    id_header = "Pack ID"
    installed_header = "Installed"
    latest_header = "Latest"
    click.echo(f"{id_header:<52}{installed_header:>14}{latest_header:>14}")
    for pack in outdated_packs:
        msg = f"{pack['id']:<52}{pack['currentVersion']:>14}{pack['latest']:>14}"
        click.echo(msg)


pack.add_command(delete)
pack.add_command(get_outdated)
