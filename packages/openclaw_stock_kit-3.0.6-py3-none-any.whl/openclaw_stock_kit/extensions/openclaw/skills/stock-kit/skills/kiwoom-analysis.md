# kiwoom-analysis — 분석/순위/업종/테마 (77개 API)

키움증권 REST API 중 외국인·기관 동향, 종목 순위, 업종, 테마 분석을 다루는 도구 모음이다.
모든 API는 KIWOOM_APP_KEY + KIWOOM_SECRET_KEY 환경변수가 필요하다.

**Rate Limit**: 실전 20회/s, 모의 2회/s. 429 에러 시 지수 백오프 적용.
**연속조회**: 응답의 cont-yn=Y이면 next-key로 페이징. 연속조회도 Rate Limit에 합산.

## 기본 호출 패턴

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"CODE","inputs":{...}}' 2>/dev/null
```

파라미터 스펙 확인:
```bash
openclaw-stock-kit call kiwoom_api_spec '{"tr_id":"ka10008"}' 2>/dev/null
```

---

## 외국인/기관 (frgnistt) — 30개

| API 코드 | 설명 |
|----------|------|
| ka10008 | 외국인 매매동향 |
| ka10009 | 기관 매매동향 |
| ka10013 | 프로그램 매매 |
| ka10014 | 프로그램 매매 상세 |
| ka10015 | 프로그램 매매 추이 |
| ka10035~ka10045 | 기관·외국인 상세 분석 |
| ka10051~ka10053 | 투자자별 매매 |
| ka10058~ka10066 | 상세 분석 시리즈 |
| ka10078 | 외국인 보유 현황 |
| ka10131 | 외국인 한도 |
| ka52301 | 금현물 외국인 |

시장구분 코드: 0=전체, 1=코스피, 2=코스닥
매매구분 코드: 0=순매수, 1=매수, 2=매도

### ka10008 — 외국인 매매동향

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10008","inputs":{"시장구분":"0","매매구분":"0"}}' 2>/dev/null
```

외국인이 순매수한 종목 목록과 수량을 반환한다.

### ka10009 — 기관 매매동향

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10009","inputs":{"시장구분":"0","매매구분":"0"}}' 2>/dev/null
```

### ka10078 — 외국인 보유 현황

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10078","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

특정 종목의 외국인 보유 수량 및 비율을 반환한다.

---

## 순위 (rkinfo) — 23개

| API 코드 | 설명 |
|----------|------|
| ka10016 | 상승률 순위 |
| ka10017 | 하락률 순위 |
| ka10018 | 상한가 종목 |
| ka10020 | 거래량 상위 |
| ka10021 | 거래대금 상위 |
| ka10022 | 전일대비 등락률 |
| ka10023 | 시가총액 상위 |
| ka10024~ka10034 | 각종 순위 |
| ka10046 | 신고가 종목 |
| ka10047 | 신저가 종목 |
| ka10054 | 등락률 순위 |
| ka10098 | 실시간 순위 |
| ka00198 | 실시간 검색 |

### ka10016 — 상승률 순위

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10016","inputs":{"시장구분":"0"}}' 2>/dev/null
```

### ka10017 — 하락률 순위

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10017","inputs":{"시장구분":"0"}}' 2>/dev/null
```

### ka10020 — 거래량 상위

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10020","inputs":{"시장구분":"0"}}' 2>/dev/null
```

### ka10046 — 신고가 종목

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10046","inputs":{"시장구분":"0"}}' 2>/dev/null
```

### ka10047 — 신저가 종목

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10047","inputs":{"시장구분":"0"}}' 2>/dev/null
```

---

## 업종 (sect) — 12개

| API 코드 | 설명 |
|----------|------|
| ka10010 | 프로그램 매매 업종 |
| ka20001 | 업종 현재가 |
| ka20002 | 업종 등락 |
| ka20003~ka20009 | 업종 상세 시리즈 |
| ka20019 | 업종 차트 |
| ka20068 | 업종 순위 |

주요 업종코드: 001=종합(KOSPI), 002=대형주, 003=중형주, 101=종합(KOSDAQ)

### ka20001 — 업종 현재가

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka20001","inputs":{"업종코드":"001"}}' 2>/dev/null
```

### ka20002 — 업종 등락

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka20002","inputs":{"업종코드":"001"}}' 2>/dev/null
```

업종 내 종목들의 등락 분포를 반환한다.

### ka20068 — 업종 순위

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka20068","inputs":{"시장구분":"0"}}' 2>/dev/null
```

---

## 테마 (thme) — 12개

| API 코드 | 설명 |
|----------|------|
| ka90001 | 테마 순위 |
| ka90002~ka90010 | 테마 상세 시리즈 |
| ka90012 | 테마 검색 |
| ka90013 | 테마 히스토리 |

### ka90001 — 테마 순위 (가장 많이 사용)

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka90001","inputs":{}}' 2>/dev/null
```

당일 상승률 기준 테마 순위와 대표 종목을 반환한다.

### ka90002 — 테마 상세 (테마 내 종목 목록)

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka90002","inputs":{"테마코드":"XXXXXX"}}' 2>/dev/null
```

테마코드는 ka90001 응답에서 확인한다.

### ka90012 — 테마 검색

```bash
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka90012","inputs":{"검색어":"반도체"}}' 2>/dev/null
```

키워드로 관련 테마를 검색한다.
