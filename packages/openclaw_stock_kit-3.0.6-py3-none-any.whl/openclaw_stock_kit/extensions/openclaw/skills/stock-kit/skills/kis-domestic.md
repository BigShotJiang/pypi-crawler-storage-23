# KIS 국내주식 (kis_domestic_stock) — 74 APIs

한국투자증권 국내주식. 시세·순위·종목정보·주문·계좌를 모두 포함한다.

## 인증
`KIS_APP_KEY` · `KIS_APP_SECRET` · `KIS_ACCOUNT_NO` (한국투자증권 API 포탈 발급)

## CLI 패턴
```bash
openclaw-stock-kit call kis_domestic_stock '{"api_type":"API_TYPE","params":{"PARAM":"VALUE"}}' 2>/dev/null
```

## 메타 API
```bash
# 파라미터 스펙 조회 (모르는 파라미터는 항상 먼저 조회)
openclaw-stock-kit call kis_domestic_stock '{"api_type":"find_api_detail","params":{"api_type":"inquire_price"}}' 2>/dev/null
# 종목코드 검색 (종목명 → 종목코드)
openclaw-stock-kit call kis_domestic_stock '{"api_type":"find_stock_code","params":{"stock_name":"삼성전자"}}' 2>/dev/null
```

---

## 기본시세 (16)

| api_type | 설명 |
|---|---|
| `inquire_price` | 주식현재가 시세 |
| `inquire_price_2` | 주식현재가 시세2 |
| `inquire_asking_price_exp_ccn` | 주식현재가 호가/예상체결 |
| `inquire_ccnl` | 주식현재가 체결 |
| `inquire_daily_price` | 주식현재가 일자별 |
| `inquire_investor` | 주식현재가 투자자 |
| `inquire_member` | 주식현재가 회원사 |
| `inquire_time_itemchartprice` | 주식당일분봉조회 |
| `inquire_time_dailychartprice` | 주식일별분봉조회 |
| `inquire_daily_itemchartprice` | 국내주식기간별시세(일/주/월/년) |
| `inquire_time_itemconclusion` | 주식현재가 당일시간대별체결 |
| `inquire_overtime_price` | 국내주식 시간외현재가 |
| `inquire_overtime_asking_price` | 국내주식 시간외호가 |
| `inquire_daily_overtimeprice` | 주식현재가 시간외일자별주가 |
| `inquire_time_overtimeconclusion` | 주식현재가 시간외시간별체결 |
| `inquire_elw_price` | ELW 현재가 시세 |

```bash
# 현재가
openclaw-stock-kit call kis_domestic_stock '{"api_type":"inquire_price","params":{"stock_name":"삼성전자"}}' 2>/dev/null
# 일별시세
openclaw-stock-kit call kis_domestic_stock '{"api_type":"inquire_daily_price","params":{"stock_name":"삼성전자"}}' 2>/dev/null
# 당일분봉
openclaw-stock-kit call kis_domestic_stock '{"api_type":"inquire_time_itemchartprice","params":{"stock_name":"카카오"}}' 2>/dev/null
```

## 순위분석 (4)

| api_type | 설명 |
|---|---|
| `volume_rank` | 거래량순위 |
| `fluctuation` | 국내주식 등락률 순위 |
| `market_cap` | 국내주식 시가총액 상위 |
| `volume_power` | 국내주식 체결강도 상위 |

```bash
openclaw-stock-kit call kis_domestic_stock '{"api_type":"volume_rank","params":{}}' 2>/dev/null
openclaw-stock-kit call kis_domestic_stock '{"api_type":"fluctuation","params":{}}' 2>/dev/null
```

## 시세분석 (19)
`intstock_multprice` 멀티종목시세 · `psearch_title` 조건검색목록 · `psearch_result` 조건검색실행 · `inquire_member_daily` 회원사종목매매동향 · `investor_trend_estimate` 외인기관추정가집계 · `comp_program_trade_daily` 프로그램매매종합(일별) · `inquire_daily_trade_volume` 종목별일별체결량 · `intstock_stocklist_by_group` 관심종목그룹별 · `inquire_investor_time_by_market` 시장별투자자매매(시세) · `inquire_investor_daily_by_market` 시장별투자자매매(일별) · `program_trade_by_stock` 종목별프로그램매매(체결) · `program_trade_by_stock_daily` 종목별프로그램매매(일별) · `daily_short_sale` 공매도일별추이 · `frgnmem_trade_trend` 회원사실시간매매동향 · `frgnmem_pchs_trend` 외국계순매수추이 · `foreign_institution_total` 외국인기관매매가집계 · `daily_loan_trans` 대차거래추이 · `investor_program_trade_today` 프로그램매매투자자동향(당일) · `investor_trade_by_stock_daily` 종목별투자자매매(일별)

```bash
# 조건검색 목록 먼저 확인 후 seq 값 추출
openclaw-stock-kit call kis_domestic_stock '{"api_type":"psearch_title","params":{"user_id":"USER"}}' 2>/dev/null
# 조건검색 실행
openclaw-stock-kit call kis_domestic_stock '{"api_type":"psearch_result","params":{"user_id":"USER","seq":"SEQ"}}' 2>/dev/null
```

## 업종/기타 (7)
`inquire_index_price` 업종현재지수 · `inquire_index_daily_price` 업종일자별지수 · `inquire_daily_indexchartprice` 업종기간별시세(일/주/월/년) · `inquire_time_indexchartprice` 업종분봉 · `inquire_vi_status` VI현황 · `chk_holiday` 휴장일조회 · `news_title` 시황/공시제목

## 종목정보 (5)
`search_info` 상품기본조회 · `search_stock_info` 주식기본조회 · `invest_opbysec` 증권사별투자의견 · `invest_opinion` 종목투자의견 · `estimate_perform` 종목추정실적

## 주문/계좌 (23) — ⚠️ order* 계열은 실제 거래 발생

| api_type | 설명 |
|---|---|
| `order_cash` | 주식주문(현금) ⚠️ |
| `order_credit` | 주식주문(신용) ⚠️ |
| `order_resv` | 주식예약주문 ⚠️ |
| `order_rvsecncl` | 주식주문(정정취소) |
| `order_resv_rvsecncl` | 주식예약주문정정취소 |
| `order_resv_ccnl` | 주식예약주문조회 |
| `inquire_balance` | 주식잔고조회 |
| `inquire_balance_rlz_pl` | 주식잔고조회_실현손익 |
| `inquire_daily_ccld` | 주식일별주문체결조회 |
| `inquire_psbl_order` | 매수가능조회 |
| `inquire_psbl_sell` | 매도가능수량조회 |
| `inquire_psbl_rvsecncl` | 주식정정취소가능주문조회 |
| `inquire_period_profit` | 기간별손익일별합산조회 |
| `inquire_period_trade_profit` | 기간별매매손익현황조회 |
| `inquire_account_balance` | 투자계좌자산현황조회 |
| `inquire_credit_psamount` | 신용매수가능조회 |
| `intgr_margin` | 주식통합증거금 현황 |
| `period_rights` | 기간별계좌권리현황조회 |
| `pension_inquire_balance` | 퇴직연금 잔고조회 |
| `pension_inquire_psbl_order` | 퇴직연금 매수가능조회 |
| `pension_inquire_daily_ccld` | 퇴직연금 미체결내역 |
| `pension_inquire_deposit` | 퇴직연금 예수금조회 |
| `pension_inquire_present_balance` | 퇴직연금 체결기준잔고 |

```bash
# 잔고 조회
openclaw-stock-kit call kis_domestic_stock '{"api_type":"inquire_balance","params":{}}' 2>/dev/null
# 매수가능 금액 확인
openclaw-stock-kit call kis_domestic_stock '{"api_type":"inquire_psbl_order","params":{"stock_name":"삼성전자"}}' 2>/dev/null
# 현금 매수 ⚠️ (price:"0" = 시장가)
openclaw-stock-kit call kis_domestic_stock '{"api_type":"order_cash","params":{"stock_name":"삼성전자","order_type":"buy","qty":"10","price":"0"}}' 2>/dev/null
# 현금 매도 ⚠️
openclaw-stock-kit call kis_domestic_stock '{"api_type":"order_cash","params":{"stock_name":"삼성전자","order_type":"sell","qty":"10","price":"0"}}' 2>/dev/null
```
