# DataKit — DART 공시 + 지배구조 (DART_API_KEY 필요)

금융감독원 DART API를 통해 기업 공시 및 지배구조 정보를 조회한다.

> **필수 API 키:** `DART_API_KEY`
> 발급: https://opendart.fss.or.kr — 회원가입 후 API 신청
> 입력: Settings 페이지에서 DART_API_KEY 항목에 입력

> **corp_code 주의:** DART 고유번호(8자리)로, 종목코드(6자리)와 다르다.
> `search_stock`으로 종목코드를 먼저 확인하고, 그 종목코드로 corp_code를 특정한다.
> 삼성전자 corp_code 예시: `00126380`

**기본 CLI 패턴:**
```bash
openclaw-stock-kit call datakit_call '{"function":"FUNC","params_json":"{...}"}' 2>/dev/null
```

---

## 분기 코드 매핑 (reprt_code)

| 보고서 종류 | reprt_code |
|------------|-----------|
| 1분기보고서 | 11013 |
| 반기보고서  | 11012 |
| 3분기보고서 | 11014 |
| 사업보고서  | 11011 |

---

## 1. dart_disclosures — 공시 목록 검색

종목별·기간별 공시 목록을 조회한다.

| 파라미터 | 타입 | 설명 |
|----------|------|------|
| corp_code | string | DART 고유번호 8자리 |
| bgn_de | string | 시작일 YYYYMMDD |
| end_de | string | 종료일 YYYYMMDD |
| page_count | string | 반환 건수 (기본: 10) |

```bash
openclaw-stock-kit call datakit_call '{"function":"dart_disclosures","params_json":"{\"corp_code\":\"00126380\",\"bgn_de\":\"20260101\",\"end_de\":\"20260220\",\"page_count\":\"10\"}"}' 2>/dev/null
```

---

## 2. dart_company — 기업 개황

기업명, 대표자, 설립일, 주소, 업종 등 기본 정보를 반환한다.

| 파라미터 | 타입 | 설명 |
|----------|------|------|
| corp_code | string | DART 고유번호 8자리 |

```bash
openclaw-stock-kit call datakit_call '{"function":"dart_company","params_json":"{\"corp_code\":\"00126380\"}"}' 2>/dev/null
```

반환 정보: 법인명, 대표이사, 법인구분, 설립일, 결산월, 홈페이지, 주소 등

---

## 3. governance_majority — 최대주주 현황

분기보고서 기준 최대주주 명단 및 지분율을 조회한다.

| 파라미터 | 타입 | 설명 |
|----------|------|------|
| corp_code | string | DART 고유번호 8자리 |
| bsns_year | string | 연도 (예: `"2025"`) |
| reprt_code | string | 분기 코드 (위 매핑표 참조) |

```bash
# 2025년 사업보고서 기준 최대주주
openclaw-stock-kit call datakit_call '{"function":"governance_majority","params_json":"{\"corp_code\":\"00126380\",\"bsns_year\":\"2025\",\"reprt_code\":\"11011\"}"}' 2>/dev/null

# 2025년 반기보고서 기준
openclaw-stock-kit call datakit_call '{"function":"governance_majority","params_json":"{\"corp_code\":\"00126380\",\"bsns_year\":\"2025\",\"reprt_code\":\"11012\"}"}' 2>/dev/null
```

---

## 4. governance_bulk_holding — 대량보유 현황

5% 이상 지분 보유자의 대량보유 상황보고서를 조회한다.

| 파라미터 | 타입 | 설명 |
|----------|------|------|
| corp_code | string | DART 고유번호 8자리 |

```bash
openclaw-stock-kit call datakit_call '{"function":"governance_bulk_holding","params_json":"{\"corp_code\":\"00126380\"}"}' 2>/dev/null
```

반환 정보: 보고자명, 보유주식수, 보유비율, 보고사유, 보고일자

---

## 5. governance_executives — 임원 현황

분기보고서 기준 등기·미등기 임원 현황을 조회한다.

| 파라미터 | 타입 | 설명 |
|----------|------|------|
| corp_code | string | DART 고유번호 8자리 |
| bsns_year | string | 연도 (예: `"2025"`) |
| reprt_code | string | 분기 코드 (위 매핑표 참조) |

```bash
openclaw-stock-kit call datakit_call '{"function":"governance_executives","params_json":"{\"corp_code\":\"00126380\",\"bsns_year\":\"2025\",\"reprt_code\":\"11011\"}"}' 2>/dev/null
```

반환 정보: 임원명, 직위, 등기여부, 상근여부, 담당업무, 임기만료일

---

## 헬퍼 명령어

```bash
# DART_API_KEY 설정 여부 확인
openclaw-stock-kit call datakit_get_env_info 2>/dev/null

# 사용 가능한 DART 함수 목록
openclaw-stock-kit call datakit_list_functions 2>/dev/null
```
