#!/usr/bin/env python3
"""OpenClaw Stock Kit — 표준 응답 스키마

모든 MCP 도구의 응답을 표준화하는 유틸리티.
"""

from datetime import datetime, timezone, timedelta

__all__ = ["ok_response", "error_response", "wrap_legacy", "ErrorCode"]

_KST = timezone(timedelta(hours=9))


class ErrorCode:
    """표준 에러 코드"""
    # 공통
    UNKNOWN = "UNKNOWN"
    TIMEOUT = "TIMEOUT"
    NOT_FOUND = "NOT_FOUND"
    INVALID_PARAMS = "INVALID_PARAMS"

    # 라이선스
    LICENSE_MISSING = "LICENSE_MISSING"
    LICENSE_INVALID = "LICENSE_INVALID"
    LICENSE_EXPIRED = "LICENSE_EXPIRED"
    LICENSE_REVOKED = "LICENSE_REVOKED"
    LICENSE_SERVER_ERROR = "LICENSE_SERVER_ERROR"
    RATE_LIMITED = "RATE_LIMITED"

    # 데이터
    DATA_UNAVAILABLE = "DATA_UNAVAILABLE"
    API_KEY_MISSING = "API_KEY_MISSING"
    API_ERROR = "API_ERROR"

    # 연결
    CONNECTION_ERROR = "CONNECTION_ERROR"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"


def _now_kst() -> str:
    return datetime.now(_KST).isoformat(timespec="seconds")


def ok_response(data, *, source: str, meta: dict = None) -> dict:
    """성공 응답 생성"""
    return {
        "ok": True,
        "source": source,
        "asof": _now_kst(),
        "data": data,
        "meta": meta,
        "error": None,
    }


def error_response(code: str, message: str, *, source: str, meta: dict = None) -> dict:
    """에러 응답 생성"""
    return {
        "ok": False,
        "source": source,
        "asof": _now_kst(),
        "data": None,
        "meta": meta,
        "error": {"code": code, "message": message},
    }


def wrap_legacy(result: dict, *, source: str) -> dict:
    """기존 레거시 응답을 표준 포맷으로 래핑 (점진적 마이그레이션용)

    result에 success=True 또는 data 키가 있으면 성공,
    success=False 또는 error 키가 있으면 실패로 변환.
    """
    if not isinstance(result, dict):
        return ok_response(result, source=source)

    # 실패 판별
    if result.get("success") is False or (not result.get("success", True)):
        err_msg = result.get("error", "Unknown error")
        err_code = result.get("error_code", ErrorCode.UNKNOWN)
        return error_response(err_code, str(err_msg), source=source)

    # 성공 — data 키가 있으면 그대로, 없으면 result 전체를 data로
    data = result.get("data", result)
    meta = result.get("meta")
    return ok_response(data, source=source, meta=meta)
