# -*- coding: utf-8 -*-
"""
本库统一日志命名空间配置入口。
命名空间为 ``lidar_manager``，子模块为 ``lidar_manager.xxx.yyy``。
子模块应使用 get_module_logger(__name__) 获取 logger，保证与包命名空间一致。
应用可配置：``logging.getLogger('lidar_manager').setLevel(logging.DEBUG)``
或使用本模块：``lidar_manager.set_level(logging.DEBUG)``
"""

import logging
from typing import Union

PACKAGE_LOGGER_NAME = "lidar_manager"


def get_module_logger(name: str) -> logging.Logger:
    """子模块统一入口：返回命名空间下的 logger，name 通常为 __name__。"""
    return logging.getLogger(name)


def get_logger() -> logging.Logger:
    """返回包根 logger，供应用挂 handler 或细分配置。"""
    return logging.getLogger(PACKAGE_LOGGER_NAME)


def set_level(level: Union[int, str]) -> None:
    """设置本库包根 logger 的级别（如 logging.DEBUG）。"""
    logging.getLogger(PACKAGE_LOGGER_NAME).setLevel(level)
