# lidar_manager: LiDAR 点云投影、颜色管理、降采样、缓存、距离/强度过滤，输出渲染图

import logging

from lidar_manager.logger import PACKAGE_LOGGER_NAME, get_logger, get_module_logger, set_level

# 包根 logger 添加 NullHandler，避免应用未配置时库日志意外输出
_logger = logging.getLogger(PACKAGE_LOGGER_NAME)
if not _logger.handlers:
    _logger.addHandler(logging.NullHandler())

from lidar_manager.pointcloud.projector import (
    LidarToCameraProjector,
    apply_pinhole_distortion,
    apply_fisheye_distortion,
)
from lidar_manager.pointcloud.renderer import PointCloudRenderer
from lidar_manager.pointcloud.color_manager import ColorManager
from lidar_manager.pointcloud.downsampler import PointCloudDownsampler
from lidar_manager.projection.projection_manager import ProjectionManager
from lidar_manager.projection.projection_manager_cache import ProjectionCacheManager
from lidar_manager.color_utils.color_mapper import ColorMapper
from lidar_manager.color_utils.default_schemes import (
    get_default_color_scheme,
    list_default_scheme_names,
)
from lidar_manager.image.processor import ImageProcessor
from lidar_manager.types.common import Point2D, Point3D, Intrinsics, Extrinsics

__all__ = [
    "LidarToCameraProjector",
    "apply_pinhole_distortion",
    "apply_fisheye_distortion",
    "PointCloudRenderer",
    "ColorManager",
    "PointCloudDownsampler",
    "ProjectionManager",
    "ProjectionCacheManager",
    "ColorMapper",
    "get_default_color_scheme",
    "list_default_scheme_names",
    "ImageProcessor",
    "Point2D",
    "Point3D",
    "Intrinsics",
    "Extrinsics",
    "get_logger",
    "set_level",
    "get_module_logger",
]
