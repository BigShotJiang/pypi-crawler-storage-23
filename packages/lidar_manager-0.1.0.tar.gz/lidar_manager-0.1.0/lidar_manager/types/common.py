from dataclasses import dataclass
from typing import Optional, Tuple
import numpy as np


Point3D = Tuple[float, float, float]
Point2D = Tuple[float, float]


@dataclass
class Intrinsics:
    """相机内参定义"""
    K: np.ndarray  # 3x3 内参矩阵
    dist_coeffs: Optional[np.ndarray] = None  # 畸变系数
    model: str = "pinhole"  # pinhole 或 fisheye


@dataclass
class Extrinsics:
    """LiDAR -> Camera 外参定义"""
    T_lidar_to_cam: np.ndarray  # 4x4 齐次矩阵
    euler_order: str = "ZYX"
