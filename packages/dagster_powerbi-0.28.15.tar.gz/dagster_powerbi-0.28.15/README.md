# dagster-powerbi

The docs for `dagster-powerbi ` can be found
[here](https://docs.dagster.io/integrations/libraries/powerbi/dagster-powerbi).
