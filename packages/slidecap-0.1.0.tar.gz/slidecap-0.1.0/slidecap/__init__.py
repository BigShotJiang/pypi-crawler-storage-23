"""slidecap package."""

from .core import PipelineResult, run_pipeline

__all__ = ["run_pipeline", "PipelineResult"]
