"""Tests for omnibase-spi protocol interfaces."""
