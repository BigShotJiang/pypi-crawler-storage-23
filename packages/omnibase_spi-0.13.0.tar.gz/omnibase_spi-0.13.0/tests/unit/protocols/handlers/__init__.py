"""Unit tests for handler protocols."""
