"""Unit tests for event bus protocol definitions."""
