"""Tests for effect execution protocols."""
