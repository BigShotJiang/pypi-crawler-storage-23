//! Some internal utilities.

pub mod paths;
pub mod timer;
