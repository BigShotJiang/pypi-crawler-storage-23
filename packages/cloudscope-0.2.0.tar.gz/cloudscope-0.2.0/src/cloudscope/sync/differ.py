"""Three-way diff calculator for bi-directional sync.

Compares three states:
1. Local filesystem now
2. Remote cloud now
3. Last-known sync state (from SQLite)

Produces a SyncDiff describing what actions are needed.
"""

from __future__ import annotations

import os
from pathlib import Path

from cloudscope.models.cloud_file import CloudFile
from cloudscope.models.sync_state import SyncConflict, SyncDiff, SyncRecord


def compute_diff(
    local_dir: Path,
    remote_files: dict[str, CloudFile],
    sync_records: dict[str, SyncRecord],
) -> SyncDiff:
    """Compute the three-way diff between local, remote, and last-sync states.

    Args:
        local_dir: Root directory of the local sync folder.
        remote_files: Mapping of relative_path -> CloudFile for all remote files.
        sync_records: Mapping of relative_path -> SyncRecord from the state DB.

    Returns:
        A SyncDiff describing required actions.
    """
    # Scan local files
    local_files = _scan_local(local_dir)

    # Collect all known paths
    all_paths = set(local_files.keys()) | set(remote_files.keys()) | set(sync_records.keys())

    uploads: list[str] = []
    downloads: list[str] = []
    delete_local: list[str] = []
    delete_remote: list[str] = []
    conflicts: list[SyncConflict] = []
    no_change: list[str] = []

    for path in sorted(all_paths):
        local = local_files.get(path)
        remote = remote_files.get(path)
        record = sync_records.get(path)

        local_exists = local is not None
        remote_exists = remote is not None
        record_exists = record is not None

        if local_exists and remote_exists and record_exists:
            # All three exist — check for changes
            local_changed = _local_changed(local, record)  # type: ignore[arg-type]
            remote_changed = _remote_changed(remote, record)

            if not local_changed and not remote_changed:
                no_change.append(path)
            elif local_changed and not remote_changed:
                uploads.append(path)
            elif not local_changed and remote_changed:
                downloads.append(path)
            else:
                # Both changed — conflict
                local_info = local  # type: ignore[assignment]
                conflicts.append(
                    SyncConflict(
                        relative_path=path,
                        local_mtime=local_info["mtime"],
                        local_size=local_info["size"],
                        remote_mtime=remote.last_modified.timestamp() if remote.last_modified else 0,
                        remote_size=remote.size,
                    )
                )

        elif local_exists and remote_exists and not record_exists:
            # Both exist but no sync record — treat as conflict if different
            local_info = local  # type: ignore[assignment]
            remote_mtime = remote.last_modified.timestamp() if remote.last_modified else 0
            if local_info["size"] == remote.size:
                no_change.append(path)
            else:
                conflicts.append(
                    SyncConflict(
                        relative_path=path,
                        local_mtime=local_info["mtime"],
                        local_size=local_info["size"],
                        remote_mtime=remote_mtime,
                        remote_size=remote.size,
                    )
                )

        elif local_exists and not remote_exists:
            if record_exists:
                # Was synced before, remote was deleted
                delete_local.append(path)
            else:
                # New local file
                uploads.append(path)

        elif not local_exists and remote_exists:
            if record_exists:
                # Was synced before, local was deleted
                delete_remote.append(path)
            else:
                # New remote file
                downloads.append(path)

        elif not local_exists and not remote_exists and record_exists:
            # Both deleted — just clean up the record
            no_change.append(path)

    return SyncDiff(
        uploads=uploads,
        downloads=downloads,
        delete_local=delete_local,
        delete_remote=delete_remote,
        conflicts=conflicts,
        no_change=no_change,
    )


def _scan_local(local_dir: Path) -> dict[str, dict]:
    """Scan local directory and return {relative_path: {size, mtime}} for all files."""
    files: dict[str, dict] = {}
    if not local_dir.exists():
        return files
    for entry in local_dir.rglob("*"):
        if entry.is_file():
            rel_path = str(entry.relative_to(local_dir))
            # Normalize to forward slashes
            rel_path = rel_path.replace("\\", "/")
            stat = entry.stat()
            files[rel_path] = {
                "size": stat.st_size,
                "mtime": stat.st_mtime,
            }
    return files


def _local_changed(local_info: dict, record: SyncRecord) -> bool:
    """Check if a local file has changed since last sync."""
    if record.local_size is not None and local_info["size"] != record.local_size:
        return True
    if record.local_mtime is not None and abs(local_info["mtime"] - record.local_mtime) > 1.0:
        return True
    return False


def _remote_changed(remote: CloudFile, record: SyncRecord) -> bool:
    """Check if a remote file has changed since last sync."""
    if record.remote_size is not None and remote.size != record.remote_size:
        return True
    if record.remote_checksum and remote.checksum and remote.checksum != record.remote_checksum:
        return True
    if record.remote_mtime is not None and remote.last_modified:
        remote_mtime = remote.last_modified.timestamp()
        if abs(remote_mtime - record.remote_mtime) > 1.0:
            return True
    return False
