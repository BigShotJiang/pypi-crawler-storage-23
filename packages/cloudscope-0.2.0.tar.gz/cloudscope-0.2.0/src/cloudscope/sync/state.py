"""SQLite-backed sync state tracking."""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path

from platformdirs import user_data_dir

from cloudscope.models.sync_state import SyncRecord

SYNC_DATA_DIR = Path(user_data_dir("cloudscope", ensure_exists=True)) / "sync"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sync_state (
    relative_path TEXT PRIMARY KEY,
    local_size INTEGER,
    local_mtime REAL,
    local_checksum TEXT,
    remote_size INTEGER,
    remote_mtime REAL,
    remote_checksum TEXT,
    last_synced REAL NOT NULL,
    sync_direction TEXT NOT NULL DEFAULT 'both'
);
"""


class SyncStateDB:
    """Persistent sync state stored in a SQLite database."""

    def __init__(self, db_path: Path | None = None) -> None:
        if db_path is None:
            SYNC_DATA_DIR.mkdir(parents=True, exist_ok=True)
            db_path = SYNC_DATA_DIR / "sync_state.db"
        self._db_path = db_path
        self._conn: sqlite3.Connection | None = None

    def open(self) -> None:
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(_SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> SyncStateDB:
        self.open()
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def _ensure_open(self) -> sqlite3.Connection:
        if self._conn is None:
            self.open()
        return self._conn  # type: ignore[return-value]

    def get_record(self, relative_path: str) -> SyncRecord | None:
        conn = self._ensure_open()
        row = conn.execute(
            "SELECT * FROM sync_state WHERE relative_path = ?", (relative_path,)
        ).fetchone()
        if row is None:
            return None
        return self._row_to_record(row)

    def upsert_record(self, record: SyncRecord) -> None:
        conn = self._ensure_open()
        conn.execute(
            """
            INSERT INTO sync_state
                (relative_path, local_size, local_mtime, local_checksum,
                 remote_size, remote_mtime, remote_checksum, last_synced, sync_direction)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(relative_path) DO UPDATE SET
                local_size = excluded.local_size,
                local_mtime = excluded.local_mtime,
                local_checksum = excluded.local_checksum,
                remote_size = excluded.remote_size,
                remote_mtime = excluded.remote_mtime,
                remote_checksum = excluded.remote_checksum,
                last_synced = excluded.last_synced,
                sync_direction = excluded.sync_direction
            """,
            (
                record.relative_path,
                record.local_size,
                record.local_mtime,
                record.local_checksum,
                record.remote_size,
                record.remote_mtime,
                record.remote_checksum,
                record.last_synced,
                record.sync_direction,
            ),
        )
        conn.commit()

    def delete_record(self, relative_path: str) -> None:
        conn = self._ensure_open()
        conn.execute(
            "DELETE FROM sync_state WHERE relative_path = ?", (relative_path,)
        )
        conn.commit()

    def all_records(self) -> list[SyncRecord]:
        conn = self._ensure_open()
        rows = conn.execute("SELECT * FROM sync_state ORDER BY relative_path").fetchall()
        return [self._row_to_record(row) for row in rows]

    def clear(self) -> None:
        conn = self._ensure_open()
        conn.execute("DELETE FROM sync_state")
        conn.commit()

    @staticmethod
    def _row_to_record(row: tuple) -> SyncRecord:
        return SyncRecord(
            relative_path=row[0],
            local_size=row[1],
            local_mtime=row[2],
            local_checksum=row[3],
            remote_size=row[4],
            remote_mtime=row[5],
            remote_checksum=row[6],
            last_synced=row[7],
            sync_direction=row[8],
        )


def db_path_for_sync_pair(backend_type: str, container: str, prefix: str) -> Path:
    """Generate a unique DB path for a sync pair."""
    safe_name = f"{backend_type}_{container}_{prefix}".replace("/", "_").replace("\\", "_")
    SYNC_DATA_DIR.mkdir(parents=True, exist_ok=True)
    return SYNC_DATA_DIR / f"{safe_name}.db"
