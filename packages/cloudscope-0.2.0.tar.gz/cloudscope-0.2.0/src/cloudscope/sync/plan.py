"""Sync plan builder — converts a resolved diff into an ordered list of actions."""

from __future__ import annotations

from cloudscope.models.cloud_file import CloudFile
from cloudscope.models.sync_state import SyncAction, SyncActionType, SyncDiff, SyncPlan


def build_plan(
    diff: SyncDiff,
    remote_files: dict[str, CloudFile] | None = None,
    local_sizes: dict[str, int] | None = None,
) -> SyncPlan:
    """Build an executable sync plan from a resolved diff.

    Args:
        diff: The resolved SyncDiff (conflicts should already be resolved).
        remote_files: Mapping of path -> CloudFile for size estimates.
        local_sizes: Mapping of path -> size for local files.
    """
    remote_files = remote_files or {}
    local_sizes = local_sizes or {}
    actions: list[SyncAction] = []
    total_bytes = 0

    # Downloads first (safer — preserving remote data)
    for path in diff.downloads:
        size = remote_files[path].size if path in remote_files else 0
        actions.append(SyncAction(SyncActionType.DOWNLOAD, path, size))
        total_bytes += size

    # Uploads
    for path in diff.uploads:
        size = local_sizes.get(path, 0)
        actions.append(SyncAction(SyncActionType.UPLOAD, path, size))
        total_bytes += size

    # Local deletions
    for path in diff.delete_local:
        actions.append(SyncAction(SyncActionType.DELETE_LOCAL, path))

    # Remote deletions
    for path in diff.delete_remote:
        actions.append(SyncAction(SyncActionType.DELETE_REMOTE, path))

    return SyncPlan(actions=actions, total_bytes=total_bytes)
