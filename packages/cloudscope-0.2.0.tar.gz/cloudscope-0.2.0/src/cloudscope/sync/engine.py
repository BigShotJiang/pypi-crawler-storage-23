"""Sync engine orchestrator — coordinates diff, plan, and execution."""

from __future__ import annotations

import time
from collections.abc import Callable
from pathlib import Path

from cloudscope.backends.base import CloudBackend
from cloudscope.models.cloud_file import CloudFile
from cloudscope.models.sync_state import (
    ConflictStrategy,
    SyncAction,
    SyncActionType,
    SyncDiff,
    SyncPlan,
    SyncRecord,
)
from cloudscope.sync.differ import compute_diff
from cloudscope.sync.plan import build_plan
from cloudscope.sync.resolver import resolve_conflicts
from cloudscope.sync.state import SyncStateDB, db_path_for_sync_pair


class SyncResult:
    """Result of a sync execution."""

    def __init__(self) -> None:
        self.uploaded: list[str] = []
        self.downloaded: list[str] = []
        self.deleted_local: list[str] = []
        self.deleted_remote: list[str] = []
        self.errors: list[tuple[str, str]] = []

    @property
    def total_actions(self) -> int:
        return (
            len(self.uploaded)
            + len(self.downloaded)
            + len(self.deleted_local)
            + len(self.deleted_remote)
        )

    @property
    def summary(self) -> str:
        parts = []
        if self.uploaded:
            parts.append(f"{len(self.uploaded)} uploaded")
        if self.downloaded:
            parts.append(f"{len(self.downloaded)} downloaded")
        if self.deleted_local:
            parts.append(f"{len(self.deleted_local)} deleted locally")
        if self.deleted_remote:
            parts.append(f"{len(self.deleted_remote)} deleted remotely")
        if self.errors:
            parts.append(f"{len(self.errors)} errors")
        return ", ".join(parts) if parts else "nothing to sync"


ProgressCallback = Callable[[SyncAction, int, int], None]


class SyncEngine:
    """Orchestrates bi-directional sync between a local directory and a cloud backend."""

    def __init__(
        self,
        backend: CloudBackend,
        container: str,
        remote_prefix: str,
        local_dir: Path,
        conflict_strategy: ConflictStrategy = ConflictStrategy.ASK,
    ) -> None:
        self._backend = backend
        self._container = container
        self._remote_prefix = remote_prefix
        self._local_dir = local_dir
        self._conflict_strategy = conflict_strategy
        self._db = SyncStateDB(
            db_path_for_sync_pair(backend.backend_type, container, remote_prefix)
        )

    async def compute_diff(self) -> SyncDiff:
        """Scan local and remote, compare with state DB, return diff."""
        self._db.open()

        # Gather remote files
        remote_files: dict[str, CloudFile] = {}
        async for f in self._backend.list_files_recursive(
            self._container, self._remote_prefix
        ):
            # Make path relative to the sync prefix
            rel_path = f.path
            if self._remote_prefix:
                rel_path = f.path.removeprefix(self._remote_prefix).lstrip("/")
            if rel_path:
                remote_files[rel_path] = f

        # Gather sync records
        records = {r.relative_path: r for r in self._db.all_records()}

        return compute_diff(self._local_dir, remote_files, records)

    async def build_plan(self, diff: SyncDiff) -> SyncPlan:
        """Resolve conflicts and build an executable plan."""
        resolved = resolve_conflicts(diff, self._conflict_strategy)

        # Gather size info for plan
        remote_files: dict[str, CloudFile] = {}
        async for f in self._backend.list_files_recursive(
            self._container, self._remote_prefix
        ):
            rel_path = f.path
            if self._remote_prefix:
                rel_path = f.path.removeprefix(self._remote_prefix).lstrip("/")
            if rel_path:
                remote_files[rel_path] = f

        local_sizes: dict[str, int] = {}
        for path in resolved.uploads:
            local_path = self._local_dir / path
            if local_path.exists():
                local_sizes[path] = local_path.stat().st_size

        return build_plan(resolved, remote_files, local_sizes)

    async def execute_plan(
        self,
        plan: SyncPlan,
        progress_callback: ProgressCallback | None = None,
    ) -> SyncResult:
        """Execute the sync plan action by action."""
        result = SyncResult()

        for i, action in enumerate(plan.actions):
            if progress_callback:
                progress_callback(action, i, len(plan.actions))

            try:
                await self._execute_action(action)
                self._record_action(action)

                if action.action_type == SyncActionType.UPLOAD:
                    result.uploaded.append(action.relative_path)
                elif action.action_type == SyncActionType.DOWNLOAD:
                    result.downloaded.append(action.relative_path)
                elif action.action_type == SyncActionType.DELETE_LOCAL:
                    result.deleted_local.append(action.relative_path)
                elif action.action_type == SyncActionType.DELETE_REMOTE:
                    result.deleted_remote.append(action.relative_path)
            except Exception as e:
                result.errors.append((action.relative_path, str(e)))

        return result

    async def full_sync(
        self,
        progress_callback: ProgressCallback | None = None,
    ) -> SyncResult:
        """High-level: compute_diff -> build_plan -> execute_plan."""
        diff = await self.compute_diff()
        plan = await self.build_plan(diff)
        return await self.execute_plan(plan, progress_callback)

    async def _execute_action(self, action: SyncAction) -> None:
        """Execute a single sync action."""
        remote_path = action.relative_path
        if self._remote_prefix:
            remote_path = f"{self._remote_prefix.rstrip('/')}/{action.relative_path}"

        local_path = self._local_dir / action.relative_path

        if action.action_type == SyncActionType.DOWNLOAD:
            local_path.parent.mkdir(parents=True, exist_ok=True)
            await self._backend.download(
                self._container, remote_path, str(local_path)
            )

        elif action.action_type == SyncActionType.UPLOAD:
            await self._backend.upload(
                self._container, str(local_path), remote_path
            )

        elif action.action_type == SyncActionType.DELETE_LOCAL:
            if local_path.exists():
                local_path.unlink()

        elif action.action_type == SyncActionType.DELETE_REMOTE:
            await self._backend.delete(self._container, remote_path)

    def _record_action(self, action: SyncAction) -> None:
        """Update sync state DB after a successful action."""
        now = time.time()
        path = action.relative_path
        local_path = self._local_dir / path

        if action.action_type in (SyncActionType.DELETE_LOCAL, SyncActionType.DELETE_REMOTE):
            self._db.delete_record(path)
            return

        local_stat = local_path.stat() if local_path.exists() else None
        record = SyncRecord(
            relative_path=path,
            local_size=local_stat.st_size if local_stat else None,
            local_mtime=local_stat.st_mtime if local_stat else None,
            remote_size=action.size,
            remote_mtime=now,
            last_synced=now,
            sync_direction="up" if action.action_type == SyncActionType.UPLOAD else "down",
        )
        self._db.upsert_record(record)

    def close(self) -> None:
        self._db.close()
