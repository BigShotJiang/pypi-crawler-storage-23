"""Conflict resolution strategies for bi-directional sync."""

from __future__ import annotations

from cloudscope.models.sync_state import ConflictStrategy, SyncConflict, SyncDiff


def resolve_conflicts(
    diff: SyncDiff,
    strategy: ConflictStrategy,
) -> SyncDiff:
    """Apply a conflict resolution strategy to all conflicts in a diff.

    For ConflictStrategy.ASK, conflicts are left unresolved (the UI handles them).

    Returns a new SyncDiff with conflicts resolved into uploads/downloads/keep_both.
    """
    if strategy == ConflictStrategy.ASK:
        return diff  # Caller must resolve conflicts individually

    uploads = list(diff.uploads)
    downloads = list(diff.downloads)
    remaining_conflicts: list[SyncConflict] = []

    for conflict in diff.conflicts:
        resolved = resolve_single_conflict(conflict, strategy)
        if resolved == "upload":
            uploads.append(conflict.relative_path)
        elif resolved == "download":
            downloads.append(conflict.relative_path)
        elif resolved == "keep_both":
            # Download remote with a conflict suffix, keep local as-is
            downloads.append(conflict.relative_path)
        else:
            remaining_conflicts.append(conflict)

    return SyncDiff(
        uploads=uploads,
        downloads=downloads,
        delete_local=list(diff.delete_local),
        delete_remote=list(diff.delete_remote),
        conflicts=remaining_conflicts,
        no_change=list(diff.no_change),
    )


def resolve_single_conflict(
    conflict: SyncConflict,
    strategy: ConflictStrategy,
) -> str:
    """Resolve a single conflict. Returns 'upload', 'download', or 'keep_both'."""
    if strategy == ConflictStrategy.LOCAL_WINS:
        return "upload"
    elif strategy == ConflictStrategy.REMOTE_WINS:
        return "download"
    elif strategy == ConflictStrategy.NEWER_WINS:
        if conflict.local_mtime >= conflict.remote_mtime:
            return "upload"
        else:
            return "download"
    elif strategy == ConflictStrategy.KEEP_BOTH:
        return "keep_both"
    else:
        return "upload"  # Fallback
