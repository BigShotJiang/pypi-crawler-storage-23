"""Entry point for `python -m cloudscope` and the `cloudscope` CLI command."""

from cloudscope.app import CloudScopeApp


def main() -> None:
    app = CloudScopeApp()
    app.run()


if __name__ == "__main__":
    main()
