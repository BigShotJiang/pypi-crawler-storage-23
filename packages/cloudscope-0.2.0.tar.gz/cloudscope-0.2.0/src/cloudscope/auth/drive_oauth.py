"""Google Drive OAuth2 authentication flow and token management."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from platformdirs import user_config_dir

SCOPES = [
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/drive.metadata.readonly",
]

CONFIG_DIR = Path(user_config_dir("cloudscope", ensure_exists=True))
TOKEN_FILE = CONFIG_DIR / "drive_token.json"
CLIENT_SECRETS_FILE = CONFIG_DIR / "drive_client_secrets.json"


def get_drive_credentials(
    client_secrets_path: str | None = None,
) -> Credentials:
    """Get or refresh Google Drive credentials.

    On first run, opens a browser for OAuth consent.
    Subsequent runs use the stored refresh token.
    """
    credentials: Credentials | None = None

    # Try to load existing token
    if TOKEN_FILE.exists():
        credentials = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

    # Refresh or obtain new credentials
    if credentials and credentials.expired and credentials.refresh_token:
        credentials.refresh(Request())
        _save_token(credentials)
    elif not credentials or not credentials.valid:
        secrets_path = client_secrets_path or str(CLIENT_SECRETS_FILE)
        if not Path(secrets_path).exists():
            raise FileNotFoundError(
                f"Google Drive client secrets not found at {secrets_path}. "
                f"Download OAuth credentials from Google Cloud Console and save to {CLIENT_SECRETS_FILE}"
            )
        flow = InstalledAppFlow.from_client_secrets_file(secrets_path, SCOPES)
        credentials = flow.run_local_server(port=0)
        _save_token(credentials)

    return credentials


async def get_drive_credentials_async(
    client_secrets_path: str | None = None,
) -> Credentials:
    return await asyncio.to_thread(get_drive_credentials, client_secrets_path)


def _save_token(credentials: Credentials) -> None:
    """Save credentials to the token file with restricted permissions."""
    TOKEN_FILE.write_text(credentials.to_json())
    TOKEN_FILE.chmod(0o600)


def has_drive_credentials() -> bool:
    """Check if Drive credentials exist (may be expired)."""
    return TOKEN_FILE.exists()


def clear_drive_credentials() -> None:
    """Remove stored Drive credentials."""
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()
