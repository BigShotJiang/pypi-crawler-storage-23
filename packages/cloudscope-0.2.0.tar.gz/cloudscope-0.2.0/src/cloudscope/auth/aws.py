"""AWS credential handling — profile discovery and session creation."""

from __future__ import annotations

import asyncio
from configparser import ConfigParser
from pathlib import Path
from typing import Any

import boto3
import botocore.session


def list_aws_profiles() -> list[str]:
    """Return available AWS profile names from ~/.aws/credentials and ~/.aws/config."""
    profiles: set[str] = set()
    creds_file = Path.home() / ".aws" / "credentials"
    config_file = Path.home() / ".aws" / "config"

    for filepath in (creds_file, config_file):
        if filepath.exists():
            parser = ConfigParser()
            parser.read(filepath)
            for section in parser.sections():
                name = section.removeprefix("profile ").strip()
                profiles.add(name)

    if not profiles:
        profiles.add("default")
    return sorted(profiles)


def create_s3_client(profile: str | None = None, region: str | None = None) -> Any:
    """Create a boto3 S3 client with the given profile."""
    session = boto3.Session(profile_name=profile, region_name=region)
    return session.client("s3")


async def create_s3_client_async(
    profile: str | None = None, region: str | None = None
) -> Any:
    return await asyncio.to_thread(create_s3_client, profile, region)
