"""GCP credential handling — Application Default Credentials and service accounts."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import google.auth
from google.cloud import storage
from google.oauth2 import service_account


def create_gcs_client(
    project: str | None = None,
    service_account_key: str | None = None,
) -> storage.Client:
    """Create a GCS client using ADC or a service account key file."""
    if service_account_key:
        key_path = Path(service_account_key)
        if not key_path.exists():
            raise FileNotFoundError(f"Service account key not found: {key_path}")
        credentials = service_account.Credentials.from_service_account_file(
            str(key_path),
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
        return storage.Client(project=project, credentials=credentials)

    # Fall back to Application Default Credentials
    credentials, detected_project = google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return storage.Client(
        project=project or detected_project, credentials=credentials
    )


async def create_gcs_client_async(
    project: str | None = None,
    service_account_key: str | None = None,
) -> storage.Client:
    return await asyncio.to_thread(create_gcs_client, project, service_account_key)
