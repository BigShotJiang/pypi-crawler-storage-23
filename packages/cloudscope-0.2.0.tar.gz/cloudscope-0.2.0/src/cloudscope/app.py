"""Main CloudScope application."""

from __future__ import annotations

from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding

from cloudscope.backends.registry import available_backends, get_backend
from cloudscope.backends import s3 as _s3_reg  # noqa: F401 — triggers register_backend
from cloudscope.backends import gcs as _gcs_reg  # noqa: F401
from cloudscope.backends import drive as _drive_reg  # noqa: F401
from cloudscope.config import AppConfig
from cloudscope.tui.commands import CloudScopeCommands
from cloudscope.tui.screens.auth_setup import AuthSetupScreen
from cloudscope.tui.screens.browse import BrowseScreen
from cloudscope.tui.screens.settings import SettingsScreen
from cloudscope.tui.screens.sync_config import SyncConfigScreen


class CloudScopeApp(App[None]):
    """CloudScope — browse and sync cloud storage from your terminal."""

    TITLE = "CloudScope"
    CSS_PATH = Path(__file__).parent / "tui" / "styles" / "cloudscope.tcss"
    COMMANDS = {CloudScopeCommands}

    BINDINGS = [
        Binding("q", "quit", "Quit", show=False, priority=True),
        Binding("1", "switch_backend('s3')", "S3", show=False, priority=True),
        Binding("2", "switch_backend('gcs')", "GCS", show=False, priority=True),
        Binding("3", "switch_backend('drive')", "Drive", show=False, priority=True),
        Binding("s", "open_sync", "Sync", show=False, priority=True),
        Binding("comma", "open_settings", "Settings", show=False, priority=True),
        Binding("a", "open_auth", "Auth", show=False, priority=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._config = AppConfig.load()
        self._current_backend = None
        self._browse_screen: BrowseScreen | None = None

    def on_mount(self) -> None:
        """Initialize the app — connect to default backend and show browse screen."""
        backend = self._create_backend(self._config.default_backend)
        self._current_backend = backend
        self._browse_screen = BrowseScreen(backend=backend)
        self.push_screen(self._browse_screen)

    def _create_backend(self, backend_type: str):
        """Create a backend instance from config."""
        backend_config = self._config.backends.get(backend_type)
        profile = backend_config.profile if backend_config else None
        extra = backend_config.extra if backend_config else {}

        kwargs = {}
        if backend_type == "s3":
            if profile:
                kwargs["profile"] = profile
            if extra.get("region"):
                kwargs["region"] = extra["region"]
        elif backend_type == "gcs":
            if extra.get("project"):
                kwargs["project"] = extra["project"]
            if extra.get("service_account_key"):
                kwargs["service_account_key"] = extra["service_account_key"]
        elif backend_type == "drive":
            if extra.get("client_secrets_path"):
                kwargs["client_secrets_path"] = extra["client_secrets_path"]

        try:
            return get_backend(backend_type, **kwargs)
        except ValueError:
            self.notify(
                f"Backend '{backend_type}' not available. Available: {available_backends()}",
                severity="error",
            )
            return get_backend("s3")

    def action_switch_backend(self, backend_type: str) -> None:
        """Switch to a different cloud backend."""
        backend = self._create_backend(backend_type)
        self._current_backend = backend
        if self._browse_screen:
            self._browse_screen.set_backend(backend)
            self.notify(f"Switched to {backend.display_name}")

    def action_open_sync(self) -> None:
        """Open the sync configuration screen."""
        self.push_screen(SyncConfigScreen(backend=self._current_backend))

    def action_open_settings(self) -> None:
        """Open the settings screen."""
        self.push_screen(SettingsScreen())

    def action_open_auth(self) -> None:
        """Open the auth setup screen."""
        self.push_screen(AuthSetupScreen())
