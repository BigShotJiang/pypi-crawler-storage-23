"""Core data models for cloud file objects and locations."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any


class CloudFileType(Enum):
    FILE = auto()
    FOLDER = auto()


@dataclass(frozen=True)
class CloudFile:
    """Unified representation of a remote file or folder."""

    name: str
    path: str
    file_type: CloudFileType
    size: int = 0
    last_modified: datetime | None = None
    checksum: str | None = None
    content_type: str | None = None
    native_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_folder(self) -> bool:
        return self.file_type == CloudFileType.FOLDER


@dataclass(frozen=True)
class CloudLocation:
    """Identifies a location within a cloud backend."""

    backend_type: str
    container: str
    prefix: str = ""
    profile: str | None = None

    @property
    def display_path(self) -> str:
        scheme = self.backend_type
        path = f"{self.container}/{self.prefix}".rstrip("/")
        return f"{scheme}://{path}"
