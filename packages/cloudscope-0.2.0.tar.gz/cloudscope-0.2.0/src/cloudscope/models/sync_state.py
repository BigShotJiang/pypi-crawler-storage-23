"""Data models for sync state tracking."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class ConflictStrategy(Enum):
    LOCAL_WINS = auto()
    REMOTE_WINS = auto()
    NEWER_WINS = auto()
    KEEP_BOTH = auto()
    ASK = auto()


class SyncActionType(Enum):
    UPLOAD = auto()
    DOWNLOAD = auto()
    DELETE_LOCAL = auto()
    DELETE_REMOTE = auto()
    CREATE_REMOTE_FOLDER = auto()
    CREATE_LOCAL_FOLDER = auto()


@dataclass
class SyncRecord:
    """Last-known state of a file from a completed sync."""

    relative_path: str
    local_size: int | None = None
    local_mtime: float | None = None
    local_checksum: str | None = None
    remote_size: int | None = None
    remote_mtime: float | None = None
    remote_checksum: str | None = None
    last_synced: float = 0.0
    sync_direction: str = "both"


@dataclass
class SyncConflict:
    """A file that was modified on both sides since last sync."""

    relative_path: str
    local_mtime: float
    local_size: int
    remote_mtime: float
    remote_size: int
    resolution: ConflictStrategy | None = None


@dataclass
class SyncAction:
    """A single action in a sync plan."""

    action_type: SyncActionType
    relative_path: str
    size: int = 0


@dataclass
class SyncDiff:
    """Result of comparing local, remote, and last-sync states."""

    uploads: list[str]
    downloads: list[str]
    delete_local: list[str]
    delete_remote: list[str]
    conflicts: list[SyncConflict]
    no_change: list[str]


@dataclass
class SyncPlan:
    """An ordered, executable list of sync actions."""

    actions: list[SyncAction]
    total_bytes: int = 0

    @property
    def summary(self) -> str:
        counts: dict[SyncActionType, int] = {}
        for action in self.actions:
            counts[action.action_type] = counts.get(action.action_type, 0) + 1
        parts = [f"{count} {action_type.name.lower()}" for action_type, count in counts.items()]
        return ", ".join(parts) if parts else "nothing to sync"
