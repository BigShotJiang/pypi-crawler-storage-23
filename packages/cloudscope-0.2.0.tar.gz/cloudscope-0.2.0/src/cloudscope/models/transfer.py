"""Data models for file transfer operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path


class TransferDirection(Enum):
    DOWNLOAD = auto()
    UPLOAD = auto()


class TransferStatus(Enum):
    PENDING = auto()
    IN_PROGRESS = auto()
    COMPLETED = auto()
    FAILED = auto()
    CANCELLED = auto()


@dataclass
class TransferJob:
    """Represents a single file transfer operation."""

    id: str
    direction: TransferDirection
    local_path: Path
    remote_container: str
    remote_path: str
    backend_type: str
    total_bytes: int = 0
    transferred_bytes: int = 0
    status: TransferStatus = TransferStatus.PENDING
    error: str | None = None

    @property
    def progress(self) -> float:
        if self.total_bytes == 0:
            return 0.0
        return self.transferred_bytes / self.total_bytes

    @property
    def display_name(self) -> str:
        return Path(self.remote_path).name
