"""Progress callback adapter — bridges SDK callbacks to the transfer manager."""

from __future__ import annotations

from cloudscope.models.transfer import TransferJob


class ProgressAdapter:
    """Wraps a TransferJob and updates it from SDK progress callbacks."""

    def __init__(self, job: TransferJob, on_update: callable | None = None) -> None:
        self._job = job
        self._on_update = on_update

    def __call__(self, bytes_transferred: int, total_bytes: int) -> None:
        self._job.transferred_bytes = bytes_transferred
        if total_bytes > 0:
            self._job.total_bytes = total_bytes
        if self._on_update:
            self._on_update(self._job)
