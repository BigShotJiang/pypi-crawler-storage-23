"""Transfer manager — queues and executes file transfers with concurrency control."""

from __future__ import annotations

import asyncio
import uuid
from collections.abc import Callable
from pathlib import Path

from cloudscope.backends.base import CloudBackend
from cloudscope.models.transfer import TransferDirection, TransferJob, TransferStatus
from cloudscope.transfer.progress import ProgressAdapter


class TransferManager:
    """Manages concurrent file transfer operations."""

    def __init__(self, max_concurrent: int = 3) -> None:
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._jobs: dict[str, TransferJob] = {}
        self._on_update: Callable[[TransferJob], None] | None = None

    @property
    def jobs(self) -> list[TransferJob]:
        return list(self._jobs.values())

    @property
    def active_jobs(self) -> list[TransferJob]:
        return [
            j
            for j in self._jobs.values()
            if j.status in (TransferStatus.PENDING, TransferStatus.IN_PROGRESS)
        ]

    def set_update_callback(self, callback: Callable[[TransferJob], None]) -> None:
        self._on_update = callback

    async def download(
        self,
        backend: CloudBackend,
        container: str,
        remote_path: str,
        local_path: str,
    ) -> TransferJob:
        """Queue a download job."""
        job = TransferJob(
            id=str(uuid.uuid4())[:8],
            direction=TransferDirection.DOWNLOAD,
            local_path=Path(local_path),
            remote_container=container,
            remote_path=remote_path,
            backend_type=backend.backend_type,
        )
        self._jobs[job.id] = job
        self._notify(job)

        asyncio.create_task(self._execute_download(backend, job))
        return job

    async def upload(
        self,
        backend: CloudBackend,
        container: str,
        local_path: str,
        remote_path: str,
    ) -> TransferJob:
        """Queue an upload job."""
        local = Path(local_path)
        job = TransferJob(
            id=str(uuid.uuid4())[:8],
            direction=TransferDirection.UPLOAD,
            local_path=local,
            remote_container=container,
            remote_path=remote_path,
            backend_type=backend.backend_type,
            total_bytes=local.stat().st_size if local.exists() else 0,
        )
        self._jobs[job.id] = job
        self._notify(job)

        asyncio.create_task(self._execute_upload(backend, job))
        return job

    async def _execute_download(
        self, backend: CloudBackend, job: TransferJob
    ) -> None:
        async with self._semaphore:
            job.status = TransferStatus.IN_PROGRESS
            self._notify(job)
            try:
                # Get file size first
                try:
                    stat = await backend.stat(job.remote_container, job.remote_path)
                    job.total_bytes = stat.size
                except Exception:
                    pass

                progress = ProgressAdapter(job, self._notify)
                await backend.download(
                    job.remote_container,
                    job.remote_path,
                    str(job.local_path),
                    progress_callback=progress,
                )
                job.status = TransferStatus.COMPLETED
                job.transferred_bytes = job.total_bytes
            except Exception as e:
                job.status = TransferStatus.FAILED
                job.error = str(e)
            self._notify(job)

    async def _execute_upload(
        self, backend: CloudBackend, job: TransferJob
    ) -> None:
        async with self._semaphore:
            job.status = TransferStatus.IN_PROGRESS
            self._notify(job)
            try:
                progress = ProgressAdapter(job, self._notify)
                await backend.upload(
                    job.remote_container,
                    str(job.local_path),
                    job.remote_path,
                    progress_callback=progress,
                )
                job.status = TransferStatus.COMPLETED
                job.transferred_bytes = job.total_bytes
            except Exception as e:
                job.status = TransferStatus.FAILED
                job.error = str(e)
            self._notify(job)

    def cancel(self, job_id: str) -> None:
        """Cancel a pending or in-progress job."""
        job = self._jobs.get(job_id)
        if job and job.status in (TransferStatus.PENDING, TransferStatus.IN_PROGRESS):
            job.status = TransferStatus.CANCELLED
            self._notify(job)

    def clear_completed(self) -> None:
        """Remove completed, failed, and cancelled jobs from the list."""
        self._jobs = {
            k: v
            for k, v in self._jobs.items()
            if v.status in (TransferStatus.PENDING, TransferStatus.IN_PROGRESS)
        }

    def _notify(self, job: TransferJob) -> None:
        if self._on_update:
            self._on_update(job)
