"""Google Cloud Storage backend implementation."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from datetime import datetime
from pathlib import Path
from typing import Any

from google.cloud import storage

from cloudscope.auth.gcp import create_gcs_client
from cloudscope.backends.base import (
    AuthenticationError,
    CloudScopeError,
    NetworkError,
    NotFoundError,
    ProgressCallback,
)
from cloudscope.backends.registry import register_backend
from cloudscope.models.cloud_file import CloudFile, CloudFileType


class GCSBackend:
    """CloudBackend implementation for Google Cloud Storage."""

    def __init__(
        self,
        project: str | None = None,
        service_account_key: str | None = None,
    ) -> None:
        self._project = project
        self._service_account_key = service_account_key
        self._client: storage.Client | None = None

    @property
    def backend_type(self) -> str:
        return "gcs"

    @property
    def display_name(self) -> str:
        suffix = f" ({self._project})" if self._project else ""
        return f"Google Cloud Storage{suffix}"

    # --- Connection ---

    async def connect(self) -> None:
        try:
            self._client = await asyncio.to_thread(
                create_gcs_client, self._project, self._service_account_key
            )
            # Validate by listing buckets (limited to 1)
            await asyncio.to_thread(lambda: list(self._client.list_buckets(max_results=1)))
        except Exception as e:
            err_str = str(e).lower()
            if "credential" in err_str or "forbidden" in err_str or "unauthorized" in err_str:
                raise AuthenticationError(f"GCP authentication failed: {e}") from e
            raise NetworkError(f"Failed to connect to GCS: {e}") from e

    async def disconnect(self) -> None:
        if self._client:
            await asyncio.to_thread(self._client.close)
        self._client = None

    async def is_connected(self) -> bool:
        if self._client is None:
            return False
        try:
            await asyncio.to_thread(lambda: list(self._client.list_buckets(max_results=1)))
            return True
        except Exception:
            return False

    # --- Container listing ---

    async def list_containers(self) -> list[str]:
        self._ensure_connected()

        def _list() -> list[str]:
            return [b.name for b in self._client.list_buckets()]  # type: ignore[union-attr]

        return await asyncio.to_thread(_list)

    # --- Browsing ---

    async def list_files(
        self,
        container: str,
        prefix: str = "",
        recursive: bool = False,
    ) -> list[CloudFile]:
        self._ensure_connected()

        def _list() -> list[CloudFile]:
            bucket = self._client.bucket(container)  # type: ignore[union-attr]
            delimiter = None if recursive else "/"
            blobs = bucket.list_blobs(prefix=prefix, delimiter=delimiter)

            files: list[CloudFile] = []

            for blob in blobs:
                # Skip the prefix itself
                if blob.name == prefix:
                    continue
                # Skip folder markers
                if blob.name.endswith("/") and blob.size == 0:
                    continue

                name = blob.name.rstrip("/").rsplit("/", 1)[-1]
                files.append(
                    CloudFile(
                        name=name,
                        path=blob.name.rstrip("/"),
                        file_type=CloudFileType.FILE,
                        size=blob.size or 0,
                        last_modified=blob.updated,
                        checksum=blob.crc32c,
                        content_type=blob.content_type,
                    )
                )

            # Folder prefixes (only when delimiter is set)
            if not recursive:
                for folder_prefix in blobs.prefixes:
                    name = folder_prefix.rstrip("/").rsplit("/", 1)[-1]
                    files.append(
                        CloudFile(
                            name=name,
                            path=folder_prefix.rstrip("/"),
                            file_type=CloudFileType.FOLDER,
                        )
                    )

            return files

        return await asyncio.to_thread(_list)

    async def stat(self, container: str, path: str) -> CloudFile:
        self._ensure_connected()

        def _stat() -> CloudFile:
            bucket = self._client.bucket(container)  # type: ignore[union-attr]
            blob = bucket.blob(path)
            if not blob.exists():
                raise NotFoundError(f"gs://{container}/{path} not found")
            blob.reload()
            name = path.rsplit("/", 1)[-1]
            return CloudFile(
                name=name,
                path=path,
                file_type=CloudFileType.FILE,
                size=blob.size or 0,
                last_modified=blob.updated,
                checksum=blob.crc32c,
                content_type=blob.content_type,
            )

        return await asyncio.to_thread(_stat)

    async def exists(self, container: str, path: str) -> bool:
        try:
            await self.stat(container, path)
            return True
        except NotFoundError:
            return False

    # --- Transfer ---

    async def download(
        self,
        container: str,
        remote_path: str,
        local_path: str,
        progress_callback: ProgressCallback | None = None,
    ) -> None:
        self._ensure_connected()

        def _download() -> None:
            bucket = self._client.bucket(container)  # type: ignore[union-attr]
            blob = bucket.blob(remote_path)
            Path(local_path).parent.mkdir(parents=True, exist_ok=True)
            blob.download_to_filename(local_path)
            if progress_callback:
                progress_callback(blob.size or 0, blob.size or 0)

        await asyncio.to_thread(_download)

    async def upload(
        self,
        container: str,
        local_path: str,
        remote_path: str,
        progress_callback: ProgressCallback | None = None,
    ) -> CloudFile:
        self._ensure_connected()

        def _upload() -> None:
            bucket = self._client.bucket(container)  # type: ignore[union-attr]
            blob = bucket.blob(remote_path)
            blob.upload_from_filename(local_path)
            if progress_callback:
                size = Path(local_path).stat().st_size
                progress_callback(size, size)

        await asyncio.to_thread(_upload)
        return await self.stat(container, remote_path)

    # --- Mutation ---

    async def delete(self, container: str, path: str) -> None:
        self._ensure_connected()

        def _delete() -> None:
            bucket = self._client.bucket(container)  # type: ignore[union-attr]
            blob = bucket.blob(path)
            blob.delete()

        await asyncio.to_thread(_delete)

    async def create_folder(self, container: str, path: str) -> CloudFile:
        self._ensure_connected()
        folder_key = path.rstrip("/") + "/"

        def _create() -> None:
            bucket = self._client.bucket(container)  # type: ignore[union-attr]
            blob = bucket.blob(folder_key)
            blob.upload_from_string("")

        await asyncio.to_thread(_create)
        name = path.rstrip("/").rsplit("/", 1)[-1]
        return CloudFile(
            name=name,
            path=path.rstrip("/"),
            file_type=CloudFileType.FOLDER,
        )

    async def move(self, container: str, src: str, dst: str) -> CloudFile:
        result = await self.copy(container, src, dst)
        await self.delete(container, src)
        return result

    async def copy(self, container: str, src: str, dst: str) -> CloudFile:
        self._ensure_connected()

        def _copy() -> None:
            bucket = self._client.bucket(container)  # type: ignore[union-attr]
            src_blob = bucket.blob(src)
            bucket.copy_blob(src_blob, bucket, dst)

        await asyncio.to_thread(_copy)
        return await self.stat(container, dst)

    # --- Sync support ---

    async def list_files_recursive(
        self, container: str, prefix: str = ""
    ) -> AsyncIterator[CloudFile]:
        files = await self.list_files(container, prefix, recursive=True)
        for f in files:
            yield f

    # --- Internals ---

    def _ensure_connected(self) -> None:
        if self._client is None:
            raise CloudScopeError("Not connected. Call connect() first.")


register_backend("gcs", GCSBackend)
