"""S3 backend implementation using boto3."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from boto3.s3.transfer import TransferConfig

from cloudscope.auth.aws import create_s3_client
from cloudscope.backends.base import (
    AuthenticationError,
    CloudScopeError,
    NetworkError,
    NotFoundError,
    ProgressCallback,
)
from cloudscope.backends.registry import register_backend
from cloudscope.models.cloud_file import CloudFile, CloudFileType


class S3Backend:
    """CloudBackend implementation for AWS S3."""

    def __init__(self, profile: str | None = None, region: str | None = None) -> None:
        self._profile = profile
        self._region = region
        self._client: Any = None

    @property
    def backend_type(self) -> str:
        return "s3"

    @property
    def display_name(self) -> str:
        suffix = f" ({self._profile})" if self._profile else ""
        return f"AWS S3{suffix}"

    # --- Connection ---

    async def connect(self) -> None:
        try:
            self._client = await asyncio.to_thread(
                create_s3_client, self._profile, self._region
            )
            # Validate credentials by listing buckets
            await asyncio.to_thread(self._client.list_buckets)
        except Exception as e:
            err_str = str(e).lower()
            if "credential" in err_str or "access denied" in err_str or "invalid" in err_str:
                raise AuthenticationError(f"AWS authentication failed: {e}") from e
            raise NetworkError(f"Failed to connect to S3: {e}") from e

    async def disconnect(self) -> None:
        self._client = None

    async def is_connected(self) -> bool:
        if self._client is None:
            return False
        try:
            await asyncio.to_thread(self._client.list_buckets)
            return True
        except Exception:
            return False

    # --- Container listing ---

    async def list_containers(self) -> list[str]:
        self._ensure_connected()
        response = await asyncio.to_thread(self._client.list_buckets)
        return [b["Name"] for b in response.get("Buckets", [])]

    # --- Browsing ---

    async def list_files(
        self,
        container: str,
        prefix: str = "",
        recursive: bool = False,
    ) -> list[CloudFile]:
        self._ensure_connected()
        files: list[CloudFile] = []

        kwargs: dict[str, Any] = {"Bucket": container, "Prefix": prefix}
        if not recursive:
            kwargs["Delimiter"] = "/"

        paginator = self._client.get_paginator("list_objects_v2")

        def _paginate() -> list[CloudFile]:
            result: list[CloudFile] = []
            for page in paginator.paginate(**kwargs):
                # Folders (common prefixes)
                for cp in page.get("CommonPrefixes", []):
                    folder_path = cp["Prefix"]
                    name = folder_path.rstrip("/").rsplit("/", 1)[-1]
                    result.append(
                        CloudFile(
                            name=name,
                            path=folder_path.rstrip("/"),
                            file_type=CloudFileType.FOLDER,
                        )
                    )
                # Files
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    # Skip the prefix itself if it appears as an object
                    if key == prefix:
                        continue
                    # Skip folder-marker objects (zero-byte keys ending with /)
                    if key.endswith("/"):
                        continue
                    name = key.rsplit("/", 1)[-1]
                    result.append(
                        CloudFile(
                            name=name,
                            path=key,
                            file_type=CloudFileType.FILE,
                            size=obj.get("Size", 0),
                            last_modified=obj.get("LastModified"),
                            checksum=obj.get("ETag", "").strip('"'),
                        )
                    )
            return result

        return await asyncio.to_thread(_paginate)

    async def stat(self, container: str, path: str) -> CloudFile:
        self._ensure_connected()

        def _head() -> CloudFile:
            try:
                resp = self._client.head_object(Bucket=container, Key=path)
            except self._client.exceptions.NoSuchKey:
                raise NotFoundError(f"s3://{container}/{path} not found")
            except Exception as e:
                if "404" in str(e) or "NoSuchKey" in str(e):
                    raise NotFoundError(f"s3://{container}/{path} not found") from e
                raise
            name = path.rsplit("/", 1)[-1]
            return CloudFile(
                name=name,
                path=path,
                file_type=CloudFileType.FILE,
                size=resp.get("ContentLength", 0),
                last_modified=resp.get("LastModified"),
                checksum=resp.get("ETag", "").strip('"'),
                content_type=resp.get("ContentType"),
            )

        return await asyncio.to_thread(_head)

    async def exists(self, container: str, path: str) -> bool:
        try:
            await self.stat(container, path)
            return True
        except NotFoundError:
            return False

    # --- Transfer ---

    async def download(
        self,
        container: str,
        remote_path: str,
        local_path: str,
        progress_callback: ProgressCallback | None = None,
    ) -> None:
        self._ensure_connected()

        def _download() -> None:
            config = TransferConfig(
                multipart_threshold=8 * 1024 * 1024,
                max_concurrency=10,
            )
            callback = _S3ProgressAdapter(progress_callback) if progress_callback else None
            Path(local_path).parent.mkdir(parents=True, exist_ok=True)
            self._client.download_file(
                Bucket=container,
                Key=remote_path,
                Filename=local_path,
                Config=config,
                Callback=callback,
            )

        await asyncio.to_thread(_download)

    async def upload(
        self,
        container: str,
        local_path: str,
        remote_path: str,
        progress_callback: ProgressCallback | None = None,
    ) -> CloudFile:
        self._ensure_connected()

        def _upload() -> None:
            config = TransferConfig(
                multipart_threshold=8 * 1024 * 1024,
                max_concurrency=10,
            )
            callback = _S3ProgressAdapter(progress_callback) if progress_callback else None
            self._client.upload_file(
                Filename=local_path,
                Bucket=container,
                Key=remote_path,
                Config=config,
                Callback=callback,
            )

        await asyncio.to_thread(_upload)
        return await self.stat(container, remote_path)

    # --- Mutation ---

    async def delete(self, container: str, path: str) -> None:
        self._ensure_connected()
        await asyncio.to_thread(
            self._client.delete_object, Bucket=container, Key=path
        )

    async def create_folder(self, container: str, path: str) -> CloudFile:
        self._ensure_connected()
        folder_key = path.rstrip("/") + "/"
        await asyncio.to_thread(
            self._client.put_object, Bucket=container, Key=folder_key, Body=b""
        )
        name = path.rstrip("/").rsplit("/", 1)[-1]
        return CloudFile(
            name=name,
            path=path.rstrip("/"),
            file_type=CloudFileType.FOLDER,
        )

    async def move(self, container: str, src: str, dst: str) -> CloudFile:
        result = await self.copy(container, src, dst)
        await self.delete(container, src)
        return result

    async def copy(self, container: str, src: str, dst: str) -> CloudFile:
        self._ensure_connected()
        await asyncio.to_thread(
            self._client.copy_object,
            Bucket=container,
            CopySource={"Bucket": container, "Key": src},
            Key=dst,
        )
        return await self.stat(container, dst)

    # --- Sync support ---

    async def list_files_recursive(
        self, container: str, prefix: str = ""
    ) -> AsyncIterator[CloudFile]:
        files = await self.list_files(container, prefix, recursive=True)
        for f in files:
            yield f

    # --- Internals ---

    def _ensure_connected(self) -> None:
        if self._client is None:
            raise CloudScopeError("Not connected. Call connect() first.")


class _S3ProgressAdapter:
    """Adapts boto3's callback(bytes_amount) to our ProgressCallback(transferred, total)."""

    def __init__(self, callback: ProgressCallback) -> None:
        self._callback = callback
        self._transferred = 0

    def __call__(self, bytes_amount: int) -> None:
        self._transferred += bytes_amount
        self._callback(self._transferred, 0)


register_backend("s3", S3Backend)
