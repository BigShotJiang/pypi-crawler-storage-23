"""Backend registry — factory for creating backend instances."""

from __future__ import annotations

from typing import Any

from cloudscope.backends.base import CloudBackend

_BACKENDS: dict[str, type] = {}


def register_backend(name: str, cls: type) -> None:
    _BACKENDS[name] = cls


def get_backend(name: str, **kwargs: Any) -> CloudBackend:
    if name not in _BACKENDS:
        raise ValueError(f"Unknown backend: {name!r}. Available: {list(_BACKENDS.keys())}")
    return _BACKENDS[name](**kwargs)


def available_backends() -> list[str]:
    return list(_BACKENDS.keys())
