"""CloudBackend Protocol — the central abstraction all backends implement."""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from typing import Protocol, runtime_checkable

from cloudscope.models.cloud_file import CloudFile

ProgressCallback = Callable[[int, int], None]  # (bytes_transferred, total_bytes)


class CloudScopeError(Exception):
    """Base exception for all cloudscope errors."""


class AuthenticationError(CloudScopeError):
    """Credentials are invalid or expired."""


class PermissionError(CloudScopeError):  # noqa: A001
    """Insufficient permissions for the requested operation."""


class NotFoundError(CloudScopeError):
    """The requested file, folder, or container does not exist."""


class QuotaError(CloudScopeError):
    """Rate limit or storage quota exceeded."""


class NetworkError(CloudScopeError):
    """Connectivity failure."""


@runtime_checkable
class CloudBackend(Protocol):
    """Unified interface for cloud storage backends."""

    @property
    def backend_type(self) -> str: ...

    @property
    def display_name(self) -> str: ...

    # --- Connection ---
    async def connect(self) -> None: ...

    async def disconnect(self) -> None: ...

    async def is_connected(self) -> bool: ...

    # --- Container listing ---
    async def list_containers(self) -> list[str]: ...

    # --- Browsing ---
    async def list_files(
        self,
        container: str,
        prefix: str = "",
        recursive: bool = False,
    ) -> list[CloudFile]: ...

    async def stat(self, container: str, path: str) -> CloudFile: ...

    async def exists(self, container: str, path: str) -> bool: ...

    # --- Transfer ---
    async def download(
        self,
        container: str,
        remote_path: str,
        local_path: str,
        progress_callback: ProgressCallback | None = None,
    ) -> None: ...

    async def upload(
        self,
        container: str,
        local_path: str,
        remote_path: str,
        progress_callback: ProgressCallback | None = None,
    ) -> CloudFile: ...

    # --- Mutation ---
    async def delete(self, container: str, path: str) -> None: ...

    async def create_folder(self, container: str, path: str) -> CloudFile: ...

    async def move(self, container: str, src: str, dst: str) -> CloudFile: ...

    async def copy(self, container: str, src: str, dst: str) -> CloudFile: ...

    # --- Sync support ---
    async def list_files_recursive(
        self, container: str, prefix: str = ""
    ) -> AsyncIterator[CloudFile]: ...
