"""Download destination picker dialog."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, DirectoryTree, Input, Label, Static


class DownloadDialog(ModalScreen[str | None]):
    """Modal for selecting a local download destination."""

    DEFAULT_CSS = """
    DownloadDialog {
        align: center middle;
        background: rgba(10, 10, 26, 0.85);
    }
    DownloadDialog > Vertical {
        width: 70;
        height: 30;
        border: double #7c3aed;
        background: #16213e;
        padding: 1 2;
    }
    DownloadDialog .title {
        text-style: bold;
        color: #e2e8f0;
        width: 100%;
        content-align: center middle;
        margin-bottom: 1;
    }
    DownloadDialog Static {
        color: #94a3b8;
    }
    DownloadDialog DirectoryTree {
        height: 1fr;
        margin-bottom: 1;
        background: #1a1a2e;
        scrollbar-size: 1 1;
        scrollbar-background: #1a1a2e;
        scrollbar-color: #2a2a4a;
        scrollbar-color-hover: #475569;
    }
    DownloadDialog Input {
        margin-bottom: 1;
        background: #1a1a2e;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    DownloadDialog Input:focus {
        border: tall #7c3aed;
    }
    DownloadDialog Horizontal {
        width: 100%;
        height: auto;
        align: center middle;
    }
    DownloadDialog Button {
        margin: 0 1;
        background: #1e2a4a;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    DownloadDialog Button:hover {
        background: #2a2a4a;
    }
    DownloadDialog #download {
        background: #7c3aed;
        color: #e2e8f0;
        border: tall #5b21b6;
    }
    DownloadDialog #download:hover {
        background: #5b21b6;
    }
    """

    def __init__(self, file_name: str, default_dir: str | None = None) -> None:
        super().__init__()
        self._file_name = file_name
        self._default_dir = default_dir or str(Path.home() / "Downloads")

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label(f"Download: {self._file_name}", classes="title")
            yield Static("Select destination directory:")
            yield DirectoryTree(self._default_dir, id="dir-tree")
            yield Input(value=self._default_dir, placeholder="Destination path", id="path-input")
            with Horizontal():
                yield Button("Download", id="download")
                yield Button("Cancel", id="cancel")

    def on_directory_tree_directory_selected(
        self, event: DirectoryTree.DirectorySelected
    ) -> None:
        path_input = self.query_one("#path-input", Input)
        path_input.value = str(event.path)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "download":
            path_input = self.query_one("#path-input", Input)
            dest_dir = path_input.value.strip()
            if dest_dir:
                full_path = str(Path(dest_dir) / self._file_name)
                self.dismiss(full_path)
            else:
                self.notify("Please select a destination", severity="warning")
        else:
            self.dismiss(None)
