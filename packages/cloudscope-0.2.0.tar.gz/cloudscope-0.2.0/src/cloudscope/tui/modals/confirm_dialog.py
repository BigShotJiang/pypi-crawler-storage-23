"""Generic confirmation modal dialog."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Static


class ConfirmDialog(ModalScreen[bool]):
    """A modal dialog that asks for yes/no confirmation."""

    DEFAULT_CSS = """
    ConfirmDialog {
        align: center middle;
        background: rgba(10, 10, 26, 0.85);
    }
    ConfirmDialog > Vertical {
        width: 50;
        height: auto;
        max-height: 15;
        border: double #7c3aed;
        background: #16213e;
        padding: 1 2;
    }
    ConfirmDialog .title {
        text-style: bold;
        color: #e2e8f0;
        width: 100%;
        content-align: center middle;
        margin-bottom: 1;
    }
    ConfirmDialog .message {
        color: #94a3b8;
        width: 100%;
        margin-bottom: 1;
    }
    ConfirmDialog Horizontal {
        width: 100%;
        height: auto;
        align: center middle;
    }
    ConfirmDialog Button {
        margin: 0 1;
        background: #1e2a4a;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    ConfirmDialog Button:hover {
        background: #2a2a4a;
    }
    ConfirmDialog #yes {
        background: #ef4444;
        color: #e2e8f0;
        border: tall #dc2626;
    }
    ConfirmDialog #yes:hover {
        background: #dc2626;
    }
    ConfirmDialog #no {
        background: #7c3aed;
        color: #e2e8f0;
        border: tall #5b21b6;
    }
    ConfirmDialog #no:hover {
        background: #5b21b6;
    }
    """

    def __init__(
        self,
        title: str = "Confirm",
        message: str = "Are you sure?",
        yes_label: str = "Yes",
        no_label: str = "No",
    ) -> None:
        super().__init__()
        self._title = title
        self._message = message
        self._yes_label = yes_label
        self._no_label = no_label

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label(self._title, classes="title")
            yield Static(self._message, classes="message")
            with Horizontal():
                yield Button(self._yes_label, id="yes")
                yield Button(self._no_label, id="no")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "yes")
