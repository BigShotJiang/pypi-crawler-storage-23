"""New folder creation dialog."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label


class NewFolderDialog(ModalScreen[str | None]):
    """Modal for entering a new folder name."""

    DEFAULT_CSS = """
    NewFolderDialog {
        align: center middle;
        background: rgba(10, 10, 26, 0.85);
    }
    NewFolderDialog > Vertical {
        width: 50;
        height: auto;
        border: double #7c3aed;
        background: #16213e;
        padding: 1 2;
    }
    NewFolderDialog .title {
        text-style: bold;
        color: #e2e8f0;
        width: 100%;
        content-align: center middle;
        margin-bottom: 1;
    }
    NewFolderDialog Input {
        margin-bottom: 1;
        background: #1a1a2e;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    NewFolderDialog Input:focus {
        border: tall #7c3aed;
    }
    NewFolderDialog Horizontal {
        width: 100%;
        height: auto;
        align: center middle;
    }
    NewFolderDialog Button {
        margin: 0 1;
        background: #1e2a4a;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    NewFolderDialog Button:hover {
        background: #2a2a4a;
    }
    NewFolderDialog #create {
        background: #7c3aed;
        color: #e2e8f0;
        border: tall #5b21b6;
    }
    NewFolderDialog #create:hover {
        background: #5b21b6;
    }
    """

    def __init__(self, current_path: str = "") -> None:
        super().__init__()
        self._current_path = current_path

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("Create New Folder", classes="title")
            yield Input(placeholder="Folder name", id="folder-name")
            with Horizontal():
                yield Button("Create", id="create")
                yield Button("Cancel", id="cancel")

    def on_mount(self) -> None:
        self.query_one("#folder-name", Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self._submit()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "create":
            self._submit()
        else:
            self.dismiss(None)

    def _submit(self) -> None:
        name = self.query_one("#folder-name", Input).value.strip()
        if name:
            path = f"{self._current_path}/{name}".lstrip("/")
            self.dismiss(path)
        else:
            self.notify("Please enter a folder name", severity="warning")
