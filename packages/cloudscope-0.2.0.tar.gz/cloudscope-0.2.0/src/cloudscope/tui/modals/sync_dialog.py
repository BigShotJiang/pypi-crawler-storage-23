"""Sync conflict resolution dialog."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, DataTable, Label, Static

import humanize

from cloudscope.models.sync_state import ConflictStrategy, SyncConflict


class SyncConflictDialog(ModalScreen[dict[str, ConflictStrategy]]):
    """Modal for resolving sync conflicts one by one or in batch."""

    DEFAULT_CSS = """
    SyncConflictDialog {
        align: center middle;
        background: rgba(10, 10, 26, 0.85);
    }
    SyncConflictDialog > Vertical {
        width: 80;
        height: 30;
        border: double #7c3aed;
        background: #16213e;
        padding: 1 2;
    }
    SyncConflictDialog .title {
        text-style: bold;
        color: #e2e8f0;
        width: 100%;
        content-align: center middle;
        margin-bottom: 1;
    }
    SyncConflictDialog .conflict-info {
        color: #94a3b8;
        margin-bottom: 1;
    }
    SyncConflictDialog DataTable {
        height: 1fr;
        margin-bottom: 1;
        background: #1a1a2e;
        scrollbar-size: 1 1;
        scrollbar-background: #1a1a2e;
        scrollbar-color: #2a2a4a;
    }
    SyncConflictDialog DataTable > .datatable--header {
        background: #1a1a2e;
        color: #475569;
        text-style: bold;
    }
    SyncConflictDialog DataTable > .datatable--cursor {
        background: #2d1b69;
        color: #e2e8f0;
    }
    SyncConflictDialog Horizontal {
        width: 100%;
        height: auto;
        align: center middle;
    }
    SyncConflictDialog Button {
        margin: 0 1;
        background: #1e2a4a;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    SyncConflictDialog Button:hover {
        background: #2a2a4a;
    }
    SyncConflictDialog #all-local {
        background: #7c3aed;
        color: #e2e8f0;
        border: tall #5b21b6;
    }
    SyncConflictDialog #all-remote {
        background: #eab308;
        color: #1a1a2e;
        border: tall #ca8a04;
    }
    SyncConflictDialog #all-newer {
        background: #22c55e;
        color: #1a1a2e;
        border: tall #16a34a;
    }
    """

    def __init__(self, conflicts: list[SyncConflict]) -> None:
        super().__init__()
        self._conflicts = conflicts
        self._resolutions: dict[str, ConflictStrategy] = {}

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label(
                f"Sync Conflicts ({len(self._conflicts)} files)",
                classes="title",
            )
            yield Static(
                "These files were modified on both local and remote since last sync.",
                classes="conflict-info",
            )
            table = DataTable(id="conflict-table")
            yield table
            with Horizontal():
                yield Button("Keep All Local", id="all-local")
                yield Button("Keep All Remote", id="all-remote")
                yield Button("Newer Wins", id="all-newer")
                yield Button("Cancel", id="cancel")

    def on_mount(self) -> None:
        table = self.query_one("#conflict-table", DataTable)
        table.add_columns("File", "Local Size", "Local Modified", "Remote Size", "Remote Modified")
        for conflict in self._conflicts:
            from datetime import datetime

            local_time = datetime.fromtimestamp(conflict.local_mtime).strftime("%Y-%m-%d %H:%M")
            remote_time = datetime.fromtimestamp(conflict.remote_mtime).strftime("%Y-%m-%d %H:%M")
            table.add_row(
                conflict.relative_path,
                humanize.naturalsize(conflict.local_size, binary=True),
                local_time,
                humanize.naturalsize(conflict.remote_size, binary=True),
                remote_time,
                key=conflict.relative_path,
            )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "all-local":
            self._resolve_all(ConflictStrategy.LOCAL_WINS)
        elif event.button.id == "all-remote":
            self._resolve_all(ConflictStrategy.REMOTE_WINS)
        elif event.button.id == "all-newer":
            self._resolve_all(ConflictStrategy.NEWER_WINS)
        elif event.button.id == "cancel":
            self.dismiss({})

    def _resolve_all(self, strategy: ConflictStrategy) -> None:
        for conflict in self._conflicts:
            self._resolutions[conflict.relative_path] = strategy
        self.dismiss(self._resolutions)
