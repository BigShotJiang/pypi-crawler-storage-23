"""Upload file picker dialog."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, DirectoryTree, Input, Label, Static


class UploadDialog(ModalScreen[str | None]):
    """Modal for selecting a local file to upload."""

    DEFAULT_CSS = """
    UploadDialog {
        align: center middle;
        background: rgba(10, 10, 26, 0.85);
    }
    UploadDialog > Vertical {
        width: 70;
        height: 30;
        border: double #7c3aed;
        background: #16213e;
        padding: 1 2;
    }
    UploadDialog .title {
        text-style: bold;
        color: #e2e8f0;
        width: 100%;
        content-align: center middle;
        margin-bottom: 1;
    }
    UploadDialog Static {
        color: #94a3b8;
    }
    UploadDialog DirectoryTree {
        height: 1fr;
        margin-bottom: 1;
        background: #1a1a2e;
        scrollbar-size: 1 1;
        scrollbar-background: #1a1a2e;
        scrollbar-color: #2a2a4a;
        scrollbar-color-hover: #475569;
    }
    UploadDialog Input {
        margin-bottom: 1;
        background: #1a1a2e;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    UploadDialog Input:focus {
        border: tall #7c3aed;
    }
    UploadDialog Horizontal {
        width: 100%;
        height: auto;
        align: center middle;
    }
    UploadDialog Button {
        margin: 0 1;
        background: #1e2a4a;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    UploadDialog Button:hover {
        background: #2a2a4a;
    }
    UploadDialog #upload {
        background: #7c3aed;
        color: #e2e8f0;
        border: tall #5b21b6;
    }
    UploadDialog #upload:hover {
        background: #5b21b6;
    }
    """

    def __init__(self, default_dir: str | None = None) -> None:
        super().__init__()
        self._default_dir = default_dir or str(Path.home())

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("Select file to upload", classes="title")
            yield Static("Browse to select a file:")
            yield DirectoryTree(self._default_dir, id="dir-tree")
            yield Input(value="", placeholder="File path", id="path-input")
            with Horizontal():
                yield Button("Upload", id="upload")
                yield Button("Cancel", id="cancel")

    def on_directory_tree_file_selected(
        self, event: DirectoryTree.FileSelected
    ) -> None:
        path_input = self.query_one("#path-input", Input)
        path_input.value = str(event.path)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "upload":
            path_input = self.query_one("#path-input", Input)
            file_path = path_input.value.strip()
            if file_path and Path(file_path).is_file():
                self.dismiss(file_path)
            else:
                self.notify("Please select a valid file", severity="warning")
        else:
            self.dismiss(None)
