"""Command palette provider for CloudScope."""

from __future__ import annotations

from functools import partial

from textual.command import Hit, Hits, Provider


class CloudScopeCommands(Provider):
    """Provides app-specific commands for the Ctrl+K command palette."""

    COMMANDS: list[tuple[str, str, str]] = [
        ("Switch to S3", "switch_backend('s3')", "Connect to Amazon S3"),
        ("Switch to GCS", "switch_backend('gcs')", "Connect to Google Cloud Storage"),
        ("Switch to Google Drive", "switch_backend('drive')", "Connect to Google Drive"),
        ("Download selected file", "download", "Download the currently selected file"),
        ("Upload file", "upload", "Upload a local file to the current location"),
        ("Create new folder", "new_folder", "Create a new folder in the current location"),
        ("Delete selected", "delete_file", "Delete the currently selected file"),
        ("Refresh", "refresh", "Refresh the current view"),
        ("Open sync", "open_sync", "Open sync configuration"),
        ("Open settings", "open_settings", "Open application settings"),
        ("Open auth setup", "open_auth", "Configure authentication"),
        ("Quit", "quit", "Exit CloudScope"),
    ]

    async def search(self, query: str) -> Hits:
        matcher = self.matcher(query)
        for name, action, help_text in self.COMMANDS:
            score = matcher.match(name)
            if score > 0:
                yield Hit(
                    score,
                    matcher.highlight(name),
                    partial(self.app.run_action, action),
                    help=help_text,
                )

    async def discover(self) -> Hits:
        for name, action, help_text in self.COMMANDS:
            yield Hit(
                1.0,
                name,
                partial(self.app.run_action, action),
                help=help_text,
            )
