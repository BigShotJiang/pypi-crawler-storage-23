"""File table — clean DataTable with muted headers and subtle rows."""

from __future__ import annotations

from textual.message import Message
from textual.widgets import DataTable

import humanize

from cloudscope.models.cloud_file import CloudFile, CloudFileType


class FileTable(DataTable):
    """Sortable file listing with Linear-inspired clean styling."""

    class FileActivated(Message):
        def __init__(self, cloud_file: CloudFile) -> None:
            super().__init__()
            self.cloud_file = cloud_file

    class FileHighlighted(Message):
        def __init__(self, cloud_file: CloudFile) -> None:
            super().__init__()
            self.cloud_file = cloud_file

    def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(**kwargs)
        self._files: list[CloudFile] = []
        self._sort_key: str = "name"
        self._sort_reverse: bool = False

    def on_mount(self) -> None:
        self.cursor_type = "row"
        self.zebra_stripes = True
        self.add_columns("NAME", "SIZE", "MODIFIED", "TYPE")

    def populate(self, files: list[CloudFile]) -> None:
        self._files = list(files)
        self._sort_and_render()

    def _sort_and_render(self) -> None:
        self.clear()
        folders = [f for f in self._files if f.is_folder]
        file_items = [f for f in self._files if not f.is_folder]

        def sort_fn(f: CloudFile) -> tuple:
            if self._sort_key == "size":
                return (f.size,)
            elif self._sort_key == "modified":
                return (f.last_modified or "",)
            elif self._sort_key == "type":
                return (f.content_type or "",)
            return (f.name.lower(),)

        folders.sort(key=sort_fn, reverse=self._sort_reverse)
        file_items.sort(key=sort_fn, reverse=self._sort_reverse)
        sorted_files = folders + file_items
        self._files = sorted_files

        for f in sorted_files:
            if f.is_folder:
                name = f"[bold #60a5fa]{f.name}/[/]"
                size = "[#475569]--[/]"
                modified = "[#475569]--[/]"
                ftype = "[#475569]folder[/]"
            else:
                name = f"[#e2e8f0]{f.name}[/]"
                size = (
                    f"[#94a3b8]{humanize.naturalsize(f.size, binary=True)}[/]"
                    if f.size
                    else "[#475569]--[/]"
                )
                modified = (
                    f"[#94a3b8]{f.last_modified:%b %d %H:%M}[/]"
                    if f.last_modified
                    else "[#475569]--[/]"
                )
                ftype = f"[#475569]{f.content_type or '--'}[/]"
            self.add_row(name, size, modified, ftype, key=f.path)

    def on_data_table_header_selected(self, event: DataTable.HeaderSelected) -> None:
        col_map = {0: "name", 1: "size", 2: "modified", 3: "type"}
        col_key = col_map.get(event.column_index, "name")
        if col_key == self._sort_key:
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_key = col_key
            self._sort_reverse = False
        self._sort_and_render()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        row_key = event.row_key
        cloud_file = self._get_file_by_key(str(row_key.value))
        if cloud_file:
            self.post_message(self.FileActivated(cloud_file))

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.row_key is None:
            return
        cloud_file = self._get_file_by_key(str(event.row_key.value))
        if cloud_file:
            self.post_message(self.FileHighlighted(cloud_file))

    def _get_file_by_key(self, key: str) -> CloudFile | None:
        for f in self._files:
            if f.path == key:
                return f
        return None

    def get_selected_file(self) -> CloudFile | None:
        if self.cursor_row is not None and 0 <= self.cursor_row < len(self._files):
            return self._files[self.cursor_row]
        return None
