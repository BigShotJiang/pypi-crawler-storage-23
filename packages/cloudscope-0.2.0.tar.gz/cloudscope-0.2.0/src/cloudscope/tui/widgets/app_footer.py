"""AppFooter — slim 1-line footer with context-relevant keybind hints."""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static


class AppFooter(Static):
    """Slim footer showing keyboard shortcuts for the current context."""

    context: reactive[str] = reactive("browse")

    def __init__(self, context: str = "browse", **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(**kwargs)
        self.context = context

    BROWSE_HINTS = (
        "[#475569]d[/] [#94a3b8]Download[/]  "
        "[#475569]u[/] [#94a3b8]Upload[/]  "
        "[#475569]n[/] [#94a3b8]New Folder[/]  "
        "[#475569]r[/] [#94a3b8]Refresh[/]  "
        "[#475569]s[/] [#94a3b8]Sync[/]  "
        "[#475569]1-3[/] [#94a3b8]Backend[/]  "
        "[#475569]?[/] [#94a3b8]Help[/]  "
        "[#475569]q[/] [#94a3b8]Quit[/]"
    )

    SYNC_HINTS = (
        "[#475569]Esc[/] [#94a3b8]Back[/]  "
        "[#475569]Enter[/] [#94a3b8]Start Sync[/]  "
        "[#475569]q[/] [#94a3b8]Quit[/]"
    )

    SETTINGS_HINTS = (
        "[#475569]Esc[/] [#94a3b8]Back[/]  "
        "[#475569]Enter[/] [#94a3b8]Save[/]  "
        "[#475569]q[/] [#94a3b8]Quit[/]"
    )

    def render(self) -> str:
        if self.context == "sync":
            return f" {self.SYNC_HINTS}"
        if self.context == "settings":
            return f" {self.SETTINGS_HINTS}"
        return f" {self.BROWSE_HINTS}"
