"""Preview panel — clean key-value metadata display, hides when empty."""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static

import humanize

from cloudscope.models.cloud_file import CloudFile


class PreviewPanel(Static):
    """Displays metadata for the currently selected file. Hides when nothing selected."""

    def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(**kwargs)
        self._file: CloudFile | None = None

    def show_file(self, cloud_file: CloudFile | None) -> None:
        self._file = cloud_file
        if cloud_file is None:
            self.display = False
        else:
            self.display = True
            self.update(self._render_content())

    def on_mount(self) -> None:
        self.display = False

    def _render_content(self) -> str:
        if self._file is None:
            return ""

        f = self._file
        parts: list[str] = []

        # First line: name + size
        name = f"[bold #e2e8f0]{f.name}[/]"
        if f.is_folder:
            parts.append(f"[#60a5fa]󰉋[/]  {name}  [#475569]folder[/]")
        else:
            size = humanize.naturalsize(f.size, binary=True) if f.size else "--"
            parts.append(f"{name}  [#94a3b8]{size}[/]")

        # Second line: metadata
        meta: list[str] = []
        if f.last_modified:
            meta.append(f"[#475569]Modified[/] [#94a3b8]{f.last_modified:%b %d, %Y %H:%M}[/]")
        if f.content_type:
            meta.append(f"[#475569]Type[/] [#94a3b8]{f.content_type}[/]")
        if f.checksum:
            short = f.checksum[:12] + "..." if len(f.checksum) > 12 else f.checksum
            meta.append(f"[#475569]ETag[/] [#94a3b8]{short}[/]")

        if meta:
            parts.append("  ".join(meta))

        return "\n".join(parts)
