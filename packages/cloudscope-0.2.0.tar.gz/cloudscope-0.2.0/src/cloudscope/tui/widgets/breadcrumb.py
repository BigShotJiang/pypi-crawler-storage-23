"""Breadcrumb navigation widget — Linear-style with › separators."""

from __future__ import annotations

from textual.message import Message
from textual.reactive import reactive
from textual.widgets import Static


class Breadcrumb(Static):
    """Displays the current cloud path with clean › separators."""

    path: reactive[str] = reactive("")
    backend_type: reactive[str] = reactive("")
    container: reactive[str] = reactive("")

    class Navigate(Message):
        def __init__(self, prefix: str) -> None:
            super().__init__()
            self.prefix = prefix

    def render(self) -> str:
        if not self.container:
            return "[#475569 italic] Select a bucket to browse...[/]"

        scheme = self.backend_type or "cloud"
        parts = [f"[#7c3aed]{scheme}://[/][bold #e2e8f0]{self.container}[/]"]

        if self.path:
            segments = self.path.strip("/").split("/")
            for i, seg in enumerate(segments):
                is_last = i == len(segments) - 1
                parts.append("[#475569] › [/]")
                if is_last:
                    parts.append(f"[bold #e2e8f0]{seg}[/]")
                else:
                    parts.append(f"[#94a3b8]{seg}[/]")

        return "".join(parts)
