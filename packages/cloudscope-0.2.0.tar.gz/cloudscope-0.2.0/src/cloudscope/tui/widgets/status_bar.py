"""AppHeader — slim 1-line header with connection status and app name."""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static


class AppHeader(Static):
    """Slim header: connection dot + backend pill + app name + Ctrl+K hint."""

    backend_name: reactive[str] = reactive("")
    connected: reactive[bool] = reactive(False)

    def render(self) -> str:
        dot = "[#22c55e]●[/]" if self.connected else "[#ef4444]●[/]"
        backend = f"[bold #e2e8f0]{self.backend_name}[/]" if self.backend_name else ""
        left = f" {dot} {backend}  [#475569]cloudscope[/]"
        right = "[#475569]Ctrl+K[/] [#94a3b8]Command Palette[/] "
        gap = " " * max(1, 10)  # will be positioned via CSS content-align
        return f"{left}"

    def watch_backend_name(self) -> None:
        self.refresh()

    def watch_connected(self) -> None:
        self.refresh()
