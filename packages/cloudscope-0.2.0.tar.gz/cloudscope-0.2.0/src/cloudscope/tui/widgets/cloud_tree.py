"""Cloud file tree widget — clean sidebar with lazy-loading."""

from __future__ import annotations

from textual import work
from textual.message import Message
from textual.widgets import Tree
from textual.widgets._tree import TreeNode

from cloudscope.backends.base import CloudBackend
from cloudscope.models.cloud_file import CloudFile, CloudFileType


class CloudTree(Tree[CloudFile | str]):
    """Lazy-loading tree for cloud storage. Clean, minimal node rendering."""

    class FileSelected(Message):
        def __init__(self, cloud_file: CloudFile) -> None:
            super().__init__()
            self.cloud_file = cloud_file

    class FolderOpened(Message):
        def __init__(self, container: str, prefix: str) -> None:
            super().__init__()
            self.container = container
            self.prefix = prefix

    class ContainerSelected(Message):
        def __init__(self, container: str) -> None:
            super().__init__()
            self.container = container

    def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__("", **kwargs)
        self.show_root = False
        self.guide_depth = 3
        self._backend: CloudBackend | None = None
        self._loaded_nodes: set[int] = set()

    def set_backend(self, backend: CloudBackend) -> None:
        self._backend = backend
        self._loaded_nodes.clear()
        self.clear()
        self.root.expand()
        self._load_containers()

    @work
    async def _load_containers(self) -> None:
        if self._backend is None:
            return
        try:
            containers = await self._backend.list_containers()
        except Exception as e:
            self.notify(f"Failed to list containers: {e}", severity="error")
            return
        self._populate_containers(containers)

    def _populate_containers(self, containers: list[str]) -> None:
        self.root.remove_children()
        for name in sorted(containers):
            label = f"[bold #60a5fa]{name}[/]"
            node = self.root.add(label, data=name, allow_expand=True)
            node.add_leaf("[#475569]...[/]", data="__placeholder__")
        self.root.expand()

    def on_tree_node_expanded(self, event: Tree.NodeExpanded[CloudFile | str]) -> None:
        node = event.node
        node_id = id(node)
        if node_id in self._loaded_nodes:
            return
        self._loaded_nodes.add(node_id)
        container, prefix = self._resolve_node_path(node)
        if container is None:
            return
        self._load_children(node, container, prefix)

    def on_tree_node_selected(self, event: Tree.NodeSelected[CloudFile | str]) -> None:
        node = event.node
        data = node.data
        if isinstance(data, CloudFile):
            if data.is_folder:
                container, _ = self._resolve_node_path(node)
                if container:
                    self.post_message(self.FolderOpened(container, data.path))
            else:
                self.post_message(self.FileSelected(data))
        elif isinstance(data, str) and data != "__placeholder__":
            self.post_message(self.ContainerSelected(data))
            container, _ = self._resolve_node_path(node)
            if container:
                self.post_message(self.FolderOpened(container, ""))

    @work
    async def _load_children(
        self, node: TreeNode[CloudFile | str], container: str, prefix: str
    ) -> None:
        if self._backend is None:
            return
        try:
            files = await self._backend.list_files(container, prefix)
        except Exception as e:
            self.notify(f"Failed to list: {e}", severity="error")
            return
        self._populate_children(node, files)

    def _populate_children(
        self, node: TreeNode[CloudFile | str], files: list[CloudFile]
    ) -> None:
        node.remove_children()
        folders = sorted([f for f in files if f.is_folder], key=lambda f: f.name.lower())
        file_items = sorted([f for f in files if not f.is_folder], key=lambda f: f.name.lower())

        for folder in folders:
            label = f"[#60a5fa]{folder.name}/[/]"
            child = node.add(label, data=folder, allow_expand=True)
            child.add_leaf("[#475569]...[/]", data="__placeholder__")

        for fi in file_items:
            label = f"[#94a3b8]{fi.name}[/]"
            node.add_leaf(label, data=fi)

        if not folders and not file_items:
            node.add_leaf("[#475569 italic]empty[/]", data="__placeholder__")

    def _resolve_node_path(
        self, node: TreeNode[CloudFile | str]
    ) -> tuple[str | None, str]:
        data = node.data
        if isinstance(data, CloudFile):
            prefix = data.path + "/" if data.is_folder else data.path
            current = node.parent
            while current and current != self.root:
                if isinstance(current.data, str) and current.data != "__placeholder__":
                    return current.data, prefix
                current = current.parent
            return None, ""
        if isinstance(data, str) and data != "__placeholder__":
            return data, ""
        return None, ""

    def refresh_node(self, node: TreeNode[CloudFile | str]) -> None:
        node_id = id(node)
        self._loaded_nodes.discard(node_id)
        node.remove_children()
        node.add_leaf("[#475569]...[/]", data="__placeholder__")
        node.expand()
