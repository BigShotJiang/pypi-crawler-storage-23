"""Transfer panel — slim bar showing active transfers, hides when idle."""

from __future__ import annotations

from textual.widgets import Static

import humanize

from cloudscope.models.transfer import TransferJob, TransferStatus


class TransferPanel(Static):
    """Slim transfer progress display. Hidden when no active transfers."""

    def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(**kwargs)
        self._jobs: list[TransferJob] = []

    def on_mount(self) -> None:
        self.display = False

    def update_jobs(self, jobs: list[TransferJob]) -> None:
        self._jobs = jobs
        active = [j for j in jobs if j.status in (TransferStatus.PENDING, TransferStatus.IN_PROGRESS)]
        if not active and not any(j.status == TransferStatus.FAILED for j in jobs):
            self.display = False
            return
        self.display = True
        self.update(self._render_content())

    def _render_content(self) -> str:
        lines: list[str] = []
        for job in self._jobs[:3]:  # max 3 visible
            icon = "↓" if job.direction.name == "DOWNLOAD" else "↑"

            if job.status == TransferStatus.IN_PROGRESS and job.total_bytes:
                pct = int(job.progress * 100)
                bar_w = 16
                filled = int(bar_w * job.progress)
                bar = "[#7c3aed]" + "━" * filled + "[/][#2a2a4a]" + "━" * (bar_w - filled) + "[/]"
                transferred = humanize.naturalsize(job.transferred_bytes, binary=True)
                total = humanize.naturalsize(job.total_bytes, binary=True)
                lines.append(
                    f"[#94a3b8]{icon}[/] [#e2e8f0]{job.display_name}[/]  {bar}  "
                    f"[#94a3b8]{pct}%  {transferred}/{total}[/]"
                )
            elif job.status == TransferStatus.COMPLETED:
                lines.append(f"[#22c55e]✓[/] [#94a3b8]{job.display_name}  done[/]")
            elif job.status == TransferStatus.FAILED:
                lines.append(f"[#ef4444]✗[/] [#94a3b8]{job.display_name}  {job.error or 'failed'}[/]")
            elif job.status == TransferStatus.PENDING:
                lines.append(f"[#475569]◌[/] [#94a3b8]{job.display_name}  queued[/]")

        return "\n".join(lines)
