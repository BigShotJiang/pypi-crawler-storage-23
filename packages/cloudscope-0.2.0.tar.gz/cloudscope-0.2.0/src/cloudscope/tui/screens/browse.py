"""Main browsing screen — tree + file table + transfer panel + preview."""

from __future__ import annotations

from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.reactive import reactive
from textual.screen import Screen
from textual.widgets import Static

from cloudscope.backends.base import CloudBackend
from cloudscope.models.cloud_file import CloudFile
from cloudscope.transfer.manager import TransferManager
from cloudscope.tui.modals.confirm_dialog import ConfirmDialog
from cloudscope.tui.modals.download_dialog import DownloadDialog
from cloudscope.tui.modals.new_folder import NewFolderDialog
from cloudscope.tui.modals.upload_dialog import UploadDialog
from cloudscope.tui.widgets.breadcrumb import Breadcrumb
from cloudscope.tui.widgets.cloud_tree import CloudTree
from cloudscope.tui.widgets.file_table import FileTable
from cloudscope.tui.widgets.preview_panel import PreviewPanel
from cloudscope.tui.widgets.status_bar import AppHeader
from cloudscope.tui.widgets.app_footer import AppFooter
from cloudscope.tui.widgets.transfer_panel import TransferPanel


class BrowseScreen(Screen):
    """The primary screen for browsing cloud storage."""

    BINDINGS = [
        Binding("d", "download", "Download", show=False),
        Binding("u", "upload", "Upload", show=False),
        Binding("n", "new_folder", "New Folder", show=False),
        Binding("delete", "delete_file", "Delete", show=False),
        Binding("r", "refresh", "Refresh", show=False),
        Binding("question_mark", "help", "Help", show=False),
        Binding("tab", "focus_next", "Next Panel", show=False),
        Binding("shift+tab", "focus_previous", "Prev Panel", show=False),
    ]

    current_container: reactive[str] = reactive("")
    current_prefix: reactive[str] = reactive("")

    def __init__(self, backend: CloudBackend | None = None) -> None:
        super().__init__()
        self._backend = backend
        self._transfer_manager = TransferManager()
        self._transfer_manager.set_update_callback(self._on_transfer_update)

    def compose(self) -> ComposeResult:
        yield AppHeader(id="app-header")
        with Horizontal(id="main-content"):
            with Vertical(id="sidebar"):
                yield Static("BUCKETS", id="sidebar-label")
                yield CloudTree(id="tree-panel")
            with Vertical(id="right-panel"):
                yield Breadcrumb(id="breadcrumb-bar")
                yield FileTable(id="file-table")
                with Vertical(id="bottom-area"):
                    yield PreviewPanel(id="preview-panel")
                    yield TransferPanel(id="transfer-bar")
        yield AppFooter(id="app-footer")

    def on_mount(self) -> None:
        if self._backend is not None:
            self.set_backend(self._backend)

    def set_backend(self, backend: CloudBackend) -> None:
        """Connect to a backend and populate the tree."""
        self._backend = backend
        header = self.query_one("#app-header", AppHeader)
        header.backend_name = backend.display_name
        breadcrumb = self.query_one("#breadcrumb-bar", Breadcrumb)
        breadcrumb.backend_type = backend.backend_type
        # Update sidebar label based on backend type
        label = self.query_one("#sidebar-label", Static)
        label_map = {"s3": "BUCKETS", "gcs": "BUCKETS", "drive": "DRIVES"}
        label.update(label_map.get(backend.backend_type, "CONTAINERS"))
        self._connect_backend()

    @work
    async def _connect_backend(self) -> None:
        if self._backend is None:
            return
        try:
            await self._backend.connect()
        except Exception as e:
            self.notify(f"Connection failed: {e}", severity="error")
            return
        self._on_connected()

    def _on_connected(self) -> None:
        header = self.query_one("#app-header", AppHeader)
        header.connected = True
        tree = self.query_one("#tree-panel", CloudTree)
        tree.set_backend(self._backend)  # type: ignore[arg-type]

    # --- Tree events ---

    def on_cloud_tree_container_selected(self, event: CloudTree.ContainerSelected) -> None:
        self.current_container = event.container
        self.current_prefix = ""
        breadcrumb = self.query_one("#breadcrumb-bar", Breadcrumb)
        breadcrumb.container = event.container
        breadcrumb.path = ""
        self._load_file_table(event.container, "")

    def on_cloud_tree_folder_opened(self, event: CloudTree.FolderOpened) -> None:
        self.current_container = event.container
        self.current_prefix = event.prefix
        breadcrumb = self.query_one("#breadcrumb-bar", Breadcrumb)
        breadcrumb.container = event.container
        breadcrumb.path = event.prefix
        self._load_file_table(event.container, event.prefix)

    def on_cloud_tree_file_selected(self, event: CloudTree.FileSelected) -> None:
        preview = self.query_one("#preview-panel", PreviewPanel)
        preview.show_file(event.cloud_file)

    # --- File table events ---

    def on_file_table_file_highlighted(self, event: FileTable.FileHighlighted) -> None:
        preview = self.query_one("#preview-panel", PreviewPanel)
        preview.show_file(event.cloud_file)

    def on_file_table_file_activated(self, event: FileTable.FileActivated) -> None:
        if event.cloud_file.is_folder:
            self.current_prefix = event.cloud_file.path + "/"
            breadcrumb = self.query_one("#breadcrumb-bar", Breadcrumb)
            breadcrumb.path = event.cloud_file.path
            self._load_file_table(self.current_container, event.cloud_file.path + "/")
        else:
            preview = self.query_one("#preview-panel", PreviewPanel)
            preview.show_file(event.cloud_file)

    # --- Data loading ---

    @work
    async def _load_file_table(self, container: str, prefix: str) -> None:
        if self._backend is None:
            return
        try:
            files = await self._backend.list_files(container, prefix)
        except Exception as e:
            self.notify(f"Failed to list files: {e}", severity="error")
            return
        self._populate_file_table(files)

    def _populate_file_table(self, files: list[CloudFile]) -> None:
        table = self.query_one("#file-table", FileTable)
        table.populate(files)

    # --- Transfer updates ---

    def _on_transfer_update(self, job) -> None:  # type: ignore[no-untyped-def]
        try:
            panel = self.query_one("#transfer-bar", TransferPanel)
            panel.update_jobs(self._transfer_manager.jobs)
        except Exception:
            pass

    # --- Actions ---

    def action_refresh(self) -> None:
        """Refresh the current view."""
        if self.current_container:
            self._load_file_table(self.current_container, self.current_prefix)
            tree = self.query_one("#tree-panel", CloudTree)
            if tree.cursor_node:
                tree.refresh_node(tree.cursor_node)
        self.notify("Refreshed")

    def action_download(self) -> None:
        table = self.query_one("#file-table", FileTable)
        selected = table.get_selected_file()
        if not selected or selected.is_folder:
            self.notify("Select a file to download", severity="warning")
            return

        def on_download_path(path: str | None) -> None:
            if path and self._backend:
                self._start_download(selected, path)

        self.app.push_screen(DownloadDialog(selected.name), callback=on_download_path)

    @work
    async def _start_download(self, cloud_file: CloudFile, local_path: str) -> None:
        if self._backend is None:
            return
        await self._transfer_manager.download(
            self._backend,
            self.current_container,
            cloud_file.path,
            local_path,
        )

    def action_upload(self) -> None:
        if not self.current_container:
            self.notify("Select a container first", severity="warning")
            return

        def on_upload_path(path: str | None) -> None:
            if path and self._backend:
                file_name = path.rsplit("/", 1)[-1]
                remote_path = f"{self.current_prefix}{file_name}".lstrip("/")
                self._start_upload(path, remote_path)

        self.app.push_screen(UploadDialog(), callback=on_upload_path)

    @work
    async def _start_upload(self, local_path: str, remote_path: str) -> None:
        if self._backend is None:
            return
        await self._transfer_manager.upload(
            self._backend,
            self.current_container,
            local_path,
            remote_path,
        )
        self._load_file_table(self.current_container, self.current_prefix)

    def action_new_folder(self) -> None:
        if not self.current_container:
            self.notify("Select a container first", severity="warning")
            return

        def on_folder_path(path: str | None) -> None:
            if path and self._backend:
                self._create_folder(path)

        self.app.push_screen(
            NewFolderDialog(self.current_prefix.rstrip("/")),
            callback=on_folder_path,
        )

    @work
    async def _create_folder(self, path: str) -> None:
        if self._backend is None:
            return
        try:
            await self._backend.create_folder(self.current_container, path)
            self.notify(f"Created folder: {path}")
            self._load_file_table(self.current_container, self.current_prefix)
        except Exception as e:
            self.notify(f"Failed to create folder: {e}", severity="error")

    def action_delete_file(self) -> None:
        table = self.query_one("#file-table", FileTable)
        selected = table.get_selected_file()
        if not selected:
            self.notify("Select a file to delete", severity="warning")
            return

        def on_confirm(confirmed: bool) -> None:
            if confirmed and self._backend:
                self._delete_file(selected)

        self.app.push_screen(
            ConfirmDialog(
                title="Delete File",
                message=f"Delete '{selected.name}'? This cannot be undone.",
            ),
            callback=on_confirm,
        )

    @work
    async def _delete_file(self, cloud_file: CloudFile) -> None:
        if self._backend is None:
            return
        try:
            await self._backend.delete(self.current_container, cloud_file.path)
            self.notify(f"Deleted: {cloud_file.name}")
            self._load_file_table(self.current_container, self.current_prefix)
        except Exception as e:
            self.notify(f"Failed to delete: {e}", severity="error")

    def action_help(self) -> None:
        self.notify(
            "d=Download  u=Upload  n=New Folder  Del=Delete  r=Refresh  Tab=Switch Panel  q=Quit"
        )
