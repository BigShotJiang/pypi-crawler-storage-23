"""Sync configuration and execution screen."""

from __future__ import annotations

from pathlib import Path

from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import (
    Button,
    DirectoryTree,
    Input,
    Label,
    OptionList,
    Select,
    Static,
)

from cloudscope.backends.base import CloudBackend
from cloudscope.tui.widgets.status_bar import AppHeader
from cloudscope.tui.widgets.app_footer import AppFooter
from cloudscope.models.sync_state import ConflictStrategy, SyncAction
from cloudscope.sync.engine import SyncEngine, SyncResult


class SyncConfigScreen(Screen):
    """Screen for configuring and running sync operations."""

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
    ]

    DEFAULT_CSS = """
    SyncConfigScreen {
        layout: vertical;
        background: #1a1a2e;
    }
    #sync-form {
        padding: 1 2;
        height: 1fr;
    }
    .form-row {
        height: auto;
        margin-bottom: 1;
        layout: horizontal;
    }
    .form-label {
        width: 20;
        height: 1;
        content-align: left middle;
        color: #94a3b8;
    }
    .form-input {
        width: 1fr;
    }
    SyncConfigScreen Input {
        background: #16213e;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    SyncConfigScreen Input:focus {
        border: tall #7c3aed;
    }
    SyncConfigScreen Select {
        background: #16213e;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    SyncConfigScreen Button {
        background: #1e2a4a;
        color: #e2e8f0;
        border: tall #2a2a4a;
        margin: 0 1;
    }
    SyncConfigScreen Button:hover {
        background: #2a2a4a;
    }
    SyncConfigScreen #start-sync {
        background: #7c3aed;
        border: tall #5b21b6;
    }
    #sync-log {
        height: 10;
        border-top: solid #2a2a4a;
        padding: 0 1;
        overflow-y: auto;
        color: #94a3b8;
        background: #16213e;
    }
    #actions {
        height: auto;
        padding: 1 2;
        align: center middle;
    }
    """

    def __init__(self, backend: CloudBackend | None = None) -> None:
        super().__init__()
        self._backend = backend

    def compose(self) -> ComposeResult:
        yield AppHeader()
        with Vertical(id="sync-form"):
            yield Label("[bold]Sync Configuration[/]")
            yield Static("")

            with Horizontal(classes="form-row"):
                yield Label("Local Directory:", classes="form-label")
                yield Input(
                    value=str(Path.home() / "CloudScope"),
                    placeholder="Local directory path",
                    id="local-dir",
                    classes="form-input",
                )

            with Horizontal(classes="form-row"):
                yield Label("Remote Container:", classes="form-label")
                yield Input(
                    placeholder="Bucket or drive name",
                    id="remote-container",
                    classes="form-input",
                )

            with Horizontal(classes="form-row"):
                yield Label("Remote Prefix:", classes="form-label")
                yield Input(
                    placeholder="Path prefix (optional)",
                    id="remote-prefix",
                    classes="form-input",
                )

            with Horizontal(classes="form-row"):
                yield Label("Conflict Strategy:", classes="form-label")
                yield Select(
                    [
                        ("Newer Wins", "newer"),
                        ("Local Wins", "local"),
                        ("Remote Wins", "remote"),
                        ("Keep Both", "keep_both"),
                        ("Ask Each Time", "ask"),
                    ],
                    value="newer",
                    id="conflict-strategy",
                    classes="form-input",
                )

            with Horizontal(id="actions"):
                yield Button("Start Sync", variant="primary", id="start-sync")
                yield Button("Dry Run", variant="default", id="dry-run")
                yield Button("Back", variant="default", id="back")

        yield Static("", id="sync-log")
        yield AppFooter(context="sync")

    def _get_strategy(self) -> ConflictStrategy:
        select = self.query_one("#conflict-strategy", Select)
        mapping = {
            "newer": ConflictStrategy.NEWER_WINS,
            "local": ConflictStrategy.LOCAL_WINS,
            "remote": ConflictStrategy.REMOTE_WINS,
            "keep_both": ConflictStrategy.KEEP_BOTH,
            "ask": ConflictStrategy.ASK,
        }
        return mapping.get(str(select.value), ConflictStrategy.NEWER_WINS)

    def _log(self, message: str) -> None:
        log = self.query_one("#sync-log", Static)
        current = log.renderable
        if isinstance(current, str):
            log.update(current + "\n" + message)
        else:
            log.update(message)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "start-sync":
            self._run_sync(dry_run=False)
        elif event.button.id == "dry-run":
            self._run_sync(dry_run=True)
        elif event.button.id == "back":
            self.app.pop_screen()

    @work
    async def _run_sync(self, dry_run: bool = False) -> None:
        if self._backend is None:
            self.notify("No backend connected", severity="error")
            return

        local_dir = self.query_one("#local-dir", Input).value.strip()
        container = self.query_one("#remote-container", Input).value.strip()
        prefix = self.query_one("#remote-prefix", Input).value.strip()
        strategy = self._get_strategy()

        if not local_dir or not container:
            self.notify("Local directory and container are required", severity="error")
            return

        local_path = Path(local_dir)
        local_path.mkdir(parents=True, exist_ok=True)

        engine = SyncEngine(
            backend=self._backend,
            container=container,
            remote_prefix=prefix,
            local_dir=local_path,
            conflict_strategy=strategy,
        )

        try:
            self._log("Computing diff...")
            diff = await engine.compute_diff()

            self._log(
                f"Diff: {len(diff.uploads)} uploads, {len(diff.downloads)} downloads, "
                f"{len(diff.delete_local)} local deletes, {len(diff.delete_remote)} remote deletes, "
                f"{len(diff.conflicts)} conflicts",
            )

            if dry_run:
                self._log("Dry run complete — no changes made.")
                return

            self._log("Building plan...")
            plan = await engine.build_plan(diff)
            self._log(f"Plan: {plan.summary}")

            def on_progress(action: SyncAction, current: int, total: int) -> None:
                self._log(
                    f"  [{current+1}/{total}] {action.action_type.name}: {action.relative_path}",
                )

            self._log("Executing sync...")
            result = await engine.execute_plan(plan, progress_callback=on_progress)
            self._log(f"Sync complete: {result.summary}")

            if result.errors:
                for path, err in result.errors:
                    self._log(f"  ERROR: {path}: {err}")

        except Exception as e:
            self._log(f"Sync failed: {e}")
        finally:
            engine.close()
