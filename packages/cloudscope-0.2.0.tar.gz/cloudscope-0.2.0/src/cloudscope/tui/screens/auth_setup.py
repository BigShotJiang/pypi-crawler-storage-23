"""Auth setup screen — guided authentication for each backend."""

from __future__ import annotations

from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import Screen
from textual.widgets import Button, Label, OptionList, Static

from cloudscope.auth.aws import list_aws_profiles
from cloudscope.tui.widgets.status_bar import AppHeader
from cloudscope.tui.widgets.app_footer import AppFooter


class AuthSetupScreen(Screen):
    """Guided setup for cloud backend authentication."""

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
    ]

    DEFAULT_CSS = """
    AuthSetupScreen {
        layout: vertical;
        background: #1a1a2e;
    }
    #auth-content {
        padding: 1 2;
        height: 1fr;
    }
    .section {
        margin-bottom: 2;
    }
    .section-header {
        text-style: bold;
        color: #e2e8f0;
        margin-bottom: 1;
    }
    AuthSetupScreen Static {
        color: #94a3b8;
    }
    AuthSetupScreen Button {
        background: #1e2a4a;
        color: #e2e8f0;
        border: tall #2a2a4a;
        margin: 0 1;
    }
    AuthSetupScreen Button:hover {
        background: #2a2a4a;
    }
    #status-log {
        height: 8;
        border-top: solid #2a2a4a;
        padding: 0 1;
        color: #94a3b8;
        background: #16213e;
    }
    """

    def compose(self) -> ComposeResult:
        yield AppHeader()
        with Vertical(id="auth-content"):
            yield Label("[bold]Authentication Setup[/]")
            yield Static("")

            with Vertical(classes="section"):
                yield Label("AWS S3", classes="section-header")
                yield Static("Uses AWS credentials from environment or ~/.aws/credentials")
                yield Button("Test S3 Connection", id="test-s3")

            with Vertical(classes="section"):
                yield Label("Google Cloud Storage", classes="section-header")
                yield Static(
                    "Uses Application Default Credentials.\n"
                    "Run 'gcloud auth application-default login' to set up."
                )
                yield Button("Test GCS Connection", id="test-gcs")

            with Vertical(classes="section"):
                yield Label("Google Drive", classes="section-header")
                yield Static(
                    "Requires OAuth2 consent. Place your client_secrets.json in\n"
                    "~/.config/cloudscope/drive_client_secrets.json"
                )
                yield Button("Authenticate Drive", id="auth-drive")

            yield Button("Back", variant="default", id="back")

        yield Static("", id="status-log")
        yield AppFooter(context="settings")

    def _log(self, message: str) -> None:
        log = self.query_one("#status-log", Static)
        current = log.renderable
        if isinstance(current, str):
            log.update(current + "\n" + message)
        else:
            log.update(message)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "test-s3":
            self._test_s3()
        elif event.button.id == "test-gcs":
            self._test_gcs()
        elif event.button.id == "auth-drive":
            self._auth_drive()
        elif event.button.id == "back":
            self.app.pop_screen()

    @work
    async def _test_s3(self) -> None:
        self._log("Testing S3 connection...")
        try:
            from cloudscope.backends.s3 import S3Backend

            backend = S3Backend()
            await backend.connect()
            containers = await backend.list_containers()
            await backend.disconnect()
            self._log(f"S3 OK — found {len(containers)} bucket(s)")
        except Exception as e:
            self._log(f"S3 failed: {e}")

    @work
    async def _test_gcs(self) -> None:
        self._log("Testing GCS connection...")
        try:
            from cloudscope.backends.gcs import GCSBackend

            backend = GCSBackend()
            await backend.connect()
            containers = await backend.list_containers()
            await backend.disconnect()
            self._log(f"GCS OK — found {len(containers)} bucket(s)")
        except Exception as e:
            self._log(f"GCS failed: {e}")

    @work
    async def _auth_drive(self) -> None:
        self._log("Starting Drive OAuth flow...")
        self._log("A browser window will open for authentication.")
        try:
            from cloudscope.auth.drive_oauth import get_drive_credentials

            import asyncio

            credentials = await asyncio.to_thread(get_drive_credentials)
            self._log("Google Drive authentication successful!")
        except FileNotFoundError as e:
            self._log(str(e))
        except Exception as e:
            self._log(f"Drive auth failed: {e}")
