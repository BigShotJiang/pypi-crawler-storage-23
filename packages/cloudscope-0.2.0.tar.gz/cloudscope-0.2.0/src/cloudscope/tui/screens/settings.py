"""Global settings screen."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Select, Static

from cloudscope.backends.registry import available_backends
from cloudscope.config import AppConfig
from cloudscope.tui.widgets.status_bar import AppHeader
from cloudscope.tui.widgets.app_footer import AppFooter


class SettingsScreen(Screen):
    """Screen for managing application settings."""

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
    ]

    DEFAULT_CSS = """
    SettingsScreen {
        layout: vertical;
        background: #1a1a2e;
    }
    #settings-form {
        padding: 1 2;
        height: 1fr;
    }
    .form-row {
        height: auto;
        margin-bottom: 1;
        layout: horizontal;
    }
    .form-label {
        width: 25;
        height: 1;
        content-align: left middle;
        color: #94a3b8;
    }
    .form-input {
        width: 1fr;
    }
    .section-header {
        text-style: bold;
        color: #e2e8f0;
        margin-top: 1;
        margin-bottom: 1;
    }
    SettingsScreen Label {
        color: #e2e8f0;
    }
    SettingsScreen Input {
        background: #16213e;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    SettingsScreen Input:focus {
        border: tall #7c3aed;
    }
    SettingsScreen Select {
        background: #16213e;
        color: #e2e8f0;
        border: tall #2a2a4a;
    }
    SettingsScreen Button {
        background: #1e2a4a;
        color: #e2e8f0;
        border: tall #2a2a4a;
        margin: 0 1;
    }
    SettingsScreen Button:hover {
        background: #2a2a4a;
    }
    SettingsScreen #save {
        background: #7c3aed;
        border: tall #5b21b6;
    }
    #actions {
        height: auto;
        padding: 1 2;
        align: center middle;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._config = AppConfig.load()

    def compose(self) -> ComposeResult:
        yield AppHeader()
        with Vertical(id="settings-form"):
            yield Label("[bold]Settings[/]")
            yield Static("")

            yield Label("General", classes="section-header")
            with Horizontal(classes="form-row"):
                yield Label("Default Backend:", classes="form-label")
                backends = [(b.upper(), b) for b in available_backends()]
                yield Select(
                    backends,
                    value=self._config.default_backend,
                    id="default-backend",
                    classes="form-input",
                )

            with Horizontal(classes="form-row"):
                yield Label("Max Concurrent Transfers:", classes="form-label")
                yield Input(
                    value=str(self._config.max_concurrent_transfers),
                    id="max-transfers",
                    classes="form-input",
                )

            yield Label("AWS S3", classes="section-header")
            with Horizontal(classes="form-row"):
                yield Label("AWS Profile:", classes="form-label")
                aws_config = self._config.backends.get("s3")
                yield Input(
                    value=aws_config.profile or "" if aws_config else "",
                    placeholder="default",
                    id="aws-profile",
                    classes="form-input",
                )

            with Horizontal(classes="form-row"):
                yield Label("AWS Region:", classes="form-label")
                yield Input(
                    value=aws_config.extra.get("region", "") if aws_config else "",
                    placeholder="us-east-1",
                    id="aws-region",
                    classes="form-input",
                )

            yield Label("Google Cloud Storage", classes="section-header")
            with Horizontal(classes="form-row"):
                yield Label("GCP Project:", classes="form-label")
                gcs_config = self._config.backends.get("gcs")
                yield Input(
                    value=gcs_config.extra.get("project", "") if gcs_config else "",
                    placeholder="my-project-id",
                    id="gcp-project",
                    classes="form-input",
                )

            with Horizontal(classes="form-row"):
                yield Label("Service Account Key:", classes="form-label")
                yield Input(
                    value=gcs_config.extra.get("service_account_key", "") if gcs_config else "",
                    placeholder="Path to service account JSON",
                    id="gcp-key",
                    classes="form-input",
                )

            yield Label("Google Drive", classes="section-header")
            with Horizontal(classes="form-row"):
                yield Label("Client Secrets Path:", classes="form-label")
                drive_config = self._config.backends.get("drive")
                yield Input(
                    value=drive_config.extra.get("client_secrets_path", "") if drive_config else "",
                    placeholder="Path to OAuth client secrets JSON",
                    id="drive-secrets",
                    classes="form-input",
                )

            with Horizontal(id="actions"):
                yield Button("Save", variant="primary", id="save")
                yield Button("Back", variant="default", id="back")

        yield AppFooter(context="settings")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "save":
            self._save_settings()
        elif event.button.id == "back":
            self.app.pop_screen()

    def _save_settings(self) -> None:
        from cloudscope.config import BackendConfig

        default_backend = str(self.query_one("#default-backend", Select).value)
        max_transfers = self.query_one("#max-transfers", Input).value.strip()

        self._config.default_backend = default_backend
        try:
            self._config.max_concurrent_transfers = int(max_transfers)
        except ValueError:
            pass

        # S3
        aws_profile = self.query_one("#aws-profile", Input).value.strip()
        aws_region = self.query_one("#aws-region", Input).value.strip()
        self._config.backends["s3"] = BackendConfig(
            backend_type="s3",
            profile=aws_profile or None,
            extra={"region": aws_region} if aws_region else {},
        )

        # GCS
        gcp_project = self.query_one("#gcp-project", Input).value.strip()
        gcp_key = self.query_one("#gcp-key", Input).value.strip()
        self._config.backends["gcs"] = BackendConfig(
            backend_type="gcs",
            extra={
                k: v
                for k, v in {"project": gcp_project, "service_account_key": gcp_key}.items()
                if v
            },
        )

        # Drive
        drive_secrets = self.query_one("#drive-secrets", Input).value.strip()
        self._config.backends["drive"] = BackendConfig(
            backend_type="drive",
            extra={"client_secrets_path": drive_secrets} if drive_secrets else {},
        )

        self._config.save()
        self.notify("Settings saved")
