"""Configuration loading and saving."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from platformdirs import user_config_dir

CONFIG_DIR = Path(user_config_dir("cloudscope", ensure_exists=True))
CONFIG_FILE = CONFIG_DIR / "config.toml"


@dataclass
class BackendConfig:
    backend_type: str = "s3"
    profile: str | None = None
    default_container: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class AppConfig:
    default_backend: str = "s3"
    backends: dict[str, BackendConfig] = field(default_factory=dict)
    max_concurrent_transfers: int = 3
    theme: str = "default"

    @classmethod
    def load(cls) -> AppConfig:
        if not CONFIG_FILE.exists():
            return cls()
        with open(CONFIG_FILE, "rb") as f:
            data = tomllib.load(f)
        config = cls()
        config.default_backend = data.get("default_backend", "s3")
        config.max_concurrent_transfers = data.get("max_concurrent_transfers", 3)
        config.theme = data.get("theme", "default")
        for name, backend_data in data.get("backends", {}).items():
            config.backends[name] = BackendConfig(
                backend_type=backend_data.get("type", name),
                profile=backend_data.get("profile"),
                default_container=backend_data.get("default_container"),
                extra={k: v for k, v in backend_data.items() if k not in {"type", "profile", "default_container"}},
            )
        return config

    def save(self) -> None:
        lines = [
            f'default_backend = "{self.default_backend}"',
            f"max_concurrent_transfers = {self.max_concurrent_transfers}",
            f'theme = "{self.theme}"',
            "",
        ]
        for name, bc in self.backends.items():
            lines.append(f"[backends.{name}]")
            lines.append(f'type = "{bc.backend_type}"')
            if bc.profile:
                lines.append(f'profile = "{bc.profile}"')
            if bc.default_container:
                lines.append(f'default_container = "{bc.default_container}"')
            for k, v in bc.extra.items():
                if isinstance(v, str):
                    lines.append(f'{k} = "{v}"')
                else:
                    lines.append(f"{k} = {v}")
            lines.append("")
        CONFIG_FILE.write_text("\n".join(lines))
