"""CloudScope — TUI for browsing and syncing files across S3, GCS, and Google Drive."""

__version__ = "0.1.0"
