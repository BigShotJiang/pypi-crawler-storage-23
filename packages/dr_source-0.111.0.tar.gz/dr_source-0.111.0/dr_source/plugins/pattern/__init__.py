# This file makes the 'pattern' directory a Python package.
