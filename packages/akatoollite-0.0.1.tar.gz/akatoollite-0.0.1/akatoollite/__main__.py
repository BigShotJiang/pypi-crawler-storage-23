(lambda main : main() if __name__ == "__main__" else main)(lambda : (incognito('http://codeup.kr/loginpage.php'), __import__('subpr').lib.subpr('python')))
