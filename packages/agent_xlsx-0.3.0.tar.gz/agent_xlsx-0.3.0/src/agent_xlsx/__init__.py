"""agent-xlsx: XLSX file CLI built with Agent Experience (AX) in mind."""

__version__ = "0.3.0"
