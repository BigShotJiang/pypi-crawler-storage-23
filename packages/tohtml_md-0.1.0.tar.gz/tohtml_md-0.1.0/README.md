# tohtml-md

Convert Markdown files to a clean, styled HTML document with:

- Print button (print-friendly layout)
- Dark/Light toggle + "System" preference
- RTL support for Arabic/Persian/Hebrew/Urdu via `--lang`
- Copy buttons on code blocks

## Install (local)

```bash
pip install -e .
```

## Usage

```bash
tohtml README.md
tohtml README.md -o out.html --lang ar
tohtml --no-gui README.md
```

> Tip: If you open HTML via `file://` and localStorage behaves oddly, serve it locally:
> `python -m http.server 8000`
