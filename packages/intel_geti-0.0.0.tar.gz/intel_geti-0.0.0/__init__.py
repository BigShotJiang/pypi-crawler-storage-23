# -*- coding: utf-8 -*-
"""intel-geti modules."""