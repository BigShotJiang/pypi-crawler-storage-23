
import sys

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

# invalid email
# download url
# url
# project urls

setup(
    name ="intel-geti",
    packages=[".",],
    version='0.0.0',
    description="Build computer vision models in a fraction of the time and with less data.",
    long_description="""
## Overview
intel-geti is a Python library for doing awesome things.
This name has been reserved using [Reserver](https://github.com/openscilab/reserver).
""",
    long_description_content_type='text/markdown',
    author="Intel Corporation",
    author_email="test@test.com",
    url="https://docs.geti.intel.com",
    download_url="https://download_url.com",
    keywords="python3 python reserve reserver reserved",
    project_urls={
            'Source':"https://github.com/source",
    },
    install_requires="",
    python_requires='>=3.6',
    classifiers=[
        'Development Status :: 1 - Planning',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    license="MIT",
)

