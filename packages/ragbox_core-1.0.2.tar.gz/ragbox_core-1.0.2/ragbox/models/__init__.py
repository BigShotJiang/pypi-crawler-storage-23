"""
Models module for RAGBox.
"""
