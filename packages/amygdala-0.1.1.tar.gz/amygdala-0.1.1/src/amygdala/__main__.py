"""Allow running as `python -m amygdala`."""

from amygdala.cli.app import main  # pragma: no cover

main()  # pragma: no cover
