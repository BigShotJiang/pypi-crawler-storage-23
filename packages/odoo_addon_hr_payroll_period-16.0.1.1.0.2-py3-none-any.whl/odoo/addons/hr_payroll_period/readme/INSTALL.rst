Install the payroll of your localization, then install this module.
