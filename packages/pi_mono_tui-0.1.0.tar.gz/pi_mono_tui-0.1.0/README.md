# pi-tui

Part of [pi-mono-py](https://github.com/your-repo/pi-mono-py).

## Installation

```bash
pip install pi-tui
```

## License

MIT
