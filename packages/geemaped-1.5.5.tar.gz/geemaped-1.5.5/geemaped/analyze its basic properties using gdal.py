import os

print("Current directory:")
print(os.getcwd())

print("\nFiles in this directory:")
print(os.listdir())
from google.colab import files
files.upload()


from osgeo import gdal
import matplotlib.pyplot as plt
import numpy as np
import sys

# Open raster file
raster_path = "/content/ind_population_2024.tif"
ds = gdal.Open(raster_path)

if ds is None:
    print("Failed to open raster file")
    sys.exit(1)

print("Raster loaded successfully")

# Read basic raster properties
print("Raster Width (columns):", ds.RasterXSize)
print("Raster Height (rows):", ds.RasterYSize)
print("Number of Bands:", ds.RasterCount)
print("Projection:", ds.GetProjection())
print("GeoTransform:", ds.GetGeoTransform())

# Read first raster band
band = ds.GetRasterBand(1)

# Read raster values into NumPy array
band_array = band.ReadAsArray()

# Band statistics
min_val = band.GetMinimum()
max_val = band.GetMaximum()

if min_val is None or max_val is None:
    min_val, max_val = band.ComputeRasterMinMax()

print("Minimum value:", min_val)
print("Maximum value:", max_val)

# Visualize raster
plt.figure(figsize=(8, 6))
plt.imshow(band_array, cmap="viridis")
plt.colorbar(label="Raster Value")
plt.title("Raster Visualization (Band 1)")
plt.xlabel("Column Index")
plt.ylabel("Row Index")
plt.show()
