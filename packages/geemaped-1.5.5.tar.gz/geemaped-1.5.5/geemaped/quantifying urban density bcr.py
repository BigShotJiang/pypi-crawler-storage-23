import osmnx as ox
import folium

ox.settings.use_cache = True
ox.settings.log_console = False

place_name = "Dadar, Mumbai, India"

print(f"Fetching data for {place_name}...")

place_gdf = ox.geocode_to_gdf(place_name)

print("Fetching building footprints...")
buildings = ox.features_from_polygon(
    place_gdf.geometry.iloc[0],
    tags={"building": True}
)

buildings_proj = buildings.to_crs(epsg=32643)
study_area_proj = place_gdf.to_crs(epsg=32643)

total_building_area = buildings_proj.area.sum()
total_land_area = study_area_proj.geometry.area.iloc[0]

print(f"\n--- Statistics for {place_name} ---")
print(f"Total Building Area: {total_building_area:,.2f} m²")
print(f"Total Study Area: {total_land_area:,.2f} m²")
print(f"Building Coverage Ratio (BCR): {(total_building_area / total_land_area) * 100:.2f}%")

m = buildings.explore(style_kwds={"fillOpacity": 0.7})
folium.LayerControl().add_to(m)

m