import osmnx as ox, folium

address = "Marine Drive, Mumbai, India"
dist = 800

Gd = ox.graph_from_address(address, dist=dist, network_type='drive')
Gw = ox.graph_from_address(address, dist=dist, network_type='walk')

_, ed = ox.graph_to_gdfs(Gd)
_, ew = ox.graph_to_gdfs(Gw)

m = ew.explore(color="blue",
               style_kwds={'weight':4, 'opacity':0.6},
               name="Walking")

ed.explore(m=m,
           color="red",
           style_kwds={'weight':4, 'opacity':0.7},
           name="Driving")

folium.LayerControl().add_to(m)
m