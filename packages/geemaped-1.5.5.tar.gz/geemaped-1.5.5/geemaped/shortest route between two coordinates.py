import osmnx as ox
import networkx as nx
import folium

ox.settings.use_cache = True
ox.settings.log_console = False

center_point = (18.9388, 72.8354)

G = ox.graph_from_point(
    center_point,
    dist=15000,
    network_type="drive"
)

G = ox.add_edge_speeds(G)
G = ox.add_edge_travel_times(G)

origin_point = (18.92198, 72.83465)
destination_point = (19.01699, 72.83040)

orig_node = ox.distance.nearest_nodes(G, X=origin_point[1], Y=origin_point[0])
dest_node = ox.distance.nearest_nodes(G, X=destination_point[1], Y=destination_point[0])

route = nx.shortest_path(G, orig_node, dest_node, weight="travel_time")

dist_m = nx.shortest_path_length(G, orig_node, dest_node, weight="length")
time_sec = nx.shortest_path_length(G, orig_node, dest_node, weight="travel_time")

print(f"Shortest Path Distance: {dist_m / 1000:.2f} km")
print(f"Estimated Travel Time: {time_sec / 60:.2f} minutes")

route_edges = ox.routing.route_to_gdf(G, route)

m = route_edges.explore(
    color="blue",
    style_kwds={"weight": 5, "opacity": 0.8},
    name="Fastest Route"
)

folium.Marker(
    origin_point,
    popup="Gateway of India",
    icon=folium.Icon(color="green")
).add_to(m)

folium.Marker(
    destination_point,
    popup="Siddhivinayak Temple",
    icon=folium.Icon(color="red")
).add_to(m)

m