from osgeo import gdal
import matplotlib.pyplot as plt


ds = gdal.Open("/content/ind_population_2024.tif")
if ds is None:
    raise FileNotFoundError("Raster file not found")


print("Raster Width (columns):", ds.RasterXSize)
print("Raster Height (rows):", ds.RasterYSize)
print("Number of Bands:", ds.RasterCount)
print("Projection:", ds.GetProjection())
print("GeoTransform:", ds.GetGeoTransform())

# Read first band
band = ds.GetRasterBand(1)
array = band.ReadAsArray()
min_val, max_val = band.ComputeRasterMinMax()

print("Minimum value:", min_val)
print("Maximum value:", max_val)

# Plot
plt.imshow(array, cmap="viridis")
plt.colorbar(label="Raster Value")
plt.title("Raster Visualization")
plt.show()
