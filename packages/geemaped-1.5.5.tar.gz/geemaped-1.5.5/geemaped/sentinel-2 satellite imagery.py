import ee, geemap
ee.Authenticate(auth_mode='colab')
ee.Initialize(project='advanced-python-489018' )

Map = geemap.Map(center=[19.0, 72.9], zoom=11)
roi_mumbai = ee.Geometry.Rectangle([72.7, 18.8, 73.0, 19.3])
Map.addLayer(roi_mumbai, {'color': 'red'}, 'ROI Mumbai')
img = (
    ee.ImageCollection('COPERNICUS/S2_SR')
    .filterDate('2025-01-15', '2025-02-15')
    .filterBounds(roi_mumbai)
    .sort('CLOUDY_PIXEL_PERCENTAGE')
    .first()
)

img_clipped = img.clip(roi_mumbai)

Map.addLayer(
    img_clipped,
    {'bands': ['B4', 'B3', 'B2'], 'min': 0, 'max': 3000},
    'S2 RGB clipped'
)

ndvi = img_clipped.normalizedDifference(['B8', 'B4']).rename('NDVI')
ndvi_vis = {'min': 0, 'max': 1, 'palette': ['white', 'lightgreen', 'green']}
Map.addLayer(ndvi, ndvi_vis, 'NDVI clipped')
Map.centerObject(roi_mumbai, 11)

Map
