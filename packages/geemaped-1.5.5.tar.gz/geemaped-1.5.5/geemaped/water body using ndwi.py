import ee
import geemap

ee.Authenticate(auth_mode='colab')
ee.Initialize(project='advanced-python-489018')

Map = geemap.Map(center=[19.0, 72.9], zoom=10)

roi = ee.Geometry.Rectangle([72.7, 18.8, 73.0, 19.3])

Map.addLayer(roi, {'color': 'red'}, 'ROI - Mumbai')
Map.centerObject(roi, 10)

collection = (
    ee.ImageCollection('COPERNICUS/S2_SR')
    .filterBounds(roi)
    .filterDate('2024-01-01', '2024-12-31')
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
)

print("Total images used:", collection.size().getInfo())

def add_ndwi(image):
    ndwi = image.normalizedDifference(['B3', 'B8']).rename('NDWI')
    return image.addBands(ndwi)

ndwi_collection = collection.map(add_ndwi)

mean_ndwi = ndwi_collection.select('NDWI').mean().clip(roi)

ndwi_vis = {
    'min': -0.5,
    'max': 0.5,
    'palette': ['brown', 'white', 'blue']
}

Map.addLayer(mean_ndwi, ndwi_vis, 'Mean NDWI (Water Bodies)')

Map