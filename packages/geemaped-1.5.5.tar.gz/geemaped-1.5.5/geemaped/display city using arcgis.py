pip install arcgis-mapping

from arcgis.gis import GIS
from google.colab import output

output.enable_custom_widget_manager()

gis = GIS()
map_mumbai = gis.map("Mumbai, India")

map_mumbai.basemap.basemap = "dark-gray-vector"
map_mumbai.zoom = 12

map_mumbai
