import osmnx as ox

mumbai_coords = (19.0760, 72.8777)

print("Downloading road network... this may take a moment.")
G = ox.graph_from_point(mumbai_coords, dist=5000, network_type="drive")

G_proj = ox.project_graph(G)

nodes, edges = ox.graph_to_gdfs(G_proj)


m = edges.explore(
    color="black",

    tiles="OpenStreetMap",
    name="Mumbai Road Network"
)


m