from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from enum import Enum

# TODO remove
class Session(BaseModel):
    """Session schema."""
    session_token: str
    username: str
    started_at: datetime
    ended_at: Optional[datetime] = None

# TODO use this schema for return types from database functions instead of the internal User model which includes password hash
class UserInfo(BaseModel):
    """User information."""
    email: str
    firstname: str
    lastname: str
    city: Optional[str] = None
    state: Optional[str] = None
    organization: Optional[str] = None

# Below are schemas for API request/response models

class FileModification(BaseModel):
    """File modification submission from client."""
    filename: str
    fullpath: str           # full absolute path of the file
    content: str
    modified_at: float      # modified timestamp reported by client

class AuthStatusRequest(BaseModel):
    id: str

class AuthStatus(str, Enum):
    AUTHORIZED = "authorized"
    UNAUTHORIZED = "unauthorized"
    PENDING = "pending"

class AuthStatusResponse(BaseModel):
    """Response for authentication status for polling endpoint /api/auth/status."""
    status: AuthStatus
    username: Optional[str] = None

class LoginRequest(BaseModel):
    """Request model for api login endpoint."""
    email: str
    password: str
    id: Optional[str] = None  # Optional ID identifying the client, can be used for tracking authentication status

class LoginResponse(BaseModel):
    """Response model for api login endpoint."""
    verified: bool

class PasswordChangeRequest(BaseModel):
    """Request model for api password change endpoint."""
    email: str
    old_password: str
    new_password: str


class RegisterRequest(BaseModel):
    """Request model for registration endpoint."""
    firstname: str
    lastname: str
    email: str
    password: str
    city: Optional[str] = None
    state: Optional[str] = None
    organization: Optional[str] = None


class RegisterResponse(BaseModel):
    """Response model for registration endpoint."""
    submitted: bool
    detail: Optional[str] = None
