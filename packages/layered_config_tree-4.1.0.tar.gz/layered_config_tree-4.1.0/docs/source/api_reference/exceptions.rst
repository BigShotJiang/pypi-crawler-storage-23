.. automodule:: layered_config_tree.exceptions
