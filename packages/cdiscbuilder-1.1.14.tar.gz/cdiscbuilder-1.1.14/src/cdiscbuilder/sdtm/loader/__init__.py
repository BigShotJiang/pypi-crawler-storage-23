"""
ODM Processing package.
"""

from . import load

__all__ = ["load"]

__version__ = "0.1.0"
