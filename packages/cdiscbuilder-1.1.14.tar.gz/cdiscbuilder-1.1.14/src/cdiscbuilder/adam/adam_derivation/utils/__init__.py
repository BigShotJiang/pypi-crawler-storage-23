"""Utility functions for adam_derivation module."""
