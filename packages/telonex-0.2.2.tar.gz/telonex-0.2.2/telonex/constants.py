"""Constants for the Telonex SDK."""

# API base URL
API_BASE_URL = "https://api.telonex.io"
