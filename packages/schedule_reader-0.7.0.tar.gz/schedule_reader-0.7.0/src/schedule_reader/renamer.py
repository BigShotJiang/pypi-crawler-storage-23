"""
A function to rename the wells, groups, or well lists in the schedule dictionary. This function is not implemented yet, but it should receive a data file or include, read all and rename the well, group, or well list in the corresponding keywords.

developed by: Martin Araya
email: martinaraya@gmail.com
"""

__version__ = '0.7.0'
__release__ = 20260228

def rename(data, *, well=None, group=None, welllist=None):
    """
    not impplemented

    should receive a data file or include, read all and rename the well, group, or well list in the corresponding heywords
    """
    pass