# Email Management Skill

Help manage email inbox - triage, summarize, draft responses.

## Usage

Use this skill when the user wants to:
- Check their inbox or get a summary of unread emails
- Find specific emails
- Draft responses to emails
- Send emails on their behalf (with confirmation)

## Important

- Always summarize what you find before taking action
- Get explicit confirmation before sending any emails
- Prioritize emails from donors, board members, and grant organizations
- Flag urgent items (deadlines, time-sensitive requests)

## Nonprofit Context

Pay special attention to:
- Donor communications (thank you notes, acknowledgments)
- Grant-related emails (deadlines, reporting requirements)
- Board member communications
- Volunteer coordination
- Event-related correspondence
