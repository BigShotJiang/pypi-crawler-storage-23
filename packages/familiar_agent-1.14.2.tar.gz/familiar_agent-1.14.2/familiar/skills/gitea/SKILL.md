# Gitea / Forgejo

Manage repositories and issues on your Gitea or Forgejo instance.

## Usage

Use this skill when the user asks about repositories, issues, or pull requests on their self-hosted Gitea or Forgejo instance. This includes listing repos, searching issues, creating issues, reviewing PRs, and checking repo statistics.

## Examples

- "List my repos on Gitea"
- "Show open issues in the familiar repo"
- "Create an issue for the login bug"
- "Any open pull requests?"
- "What are the stats for the familiar repo?"
- "Search for issues tagged 'bug' in my project"

## Important

- Repository names are case-sensitive in the Gitea API.
- When creating issues, confirm the target repository with the user if multiple repos exist.
- Use `gitea_search_issues` with specific query terms rather than listing all issues.

## Disambiguation

- This is **NOT** for GitHub or GitLab — only self-hosted Gitea/Forgejo instances.
- This is **NOT** for local git operations (commit, push, branch) — use `run_shell` with git commands for local repos.
- This is **NOT** for code review or reading file contents — use local tools or browser tools for that.

## Setup

Set `GITEA_URL` and `GITEA_TOKEN` environment variables.

## Tools

- `gitea_list_repos` — List your repositories
- `gitea_search_issues` — Search issues in a repository
- `gitea_create_issue` — Create a new issue (requires confirmation)
- `gitea_list_prs` — List pull requests
- `gitea_repo_stats` — Get repository statistics
