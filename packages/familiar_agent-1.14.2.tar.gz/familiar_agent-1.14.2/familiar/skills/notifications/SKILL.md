# Notification Routing Skill

Push alerts to the user's phone, desktop, or email when something
needs attention. Deadline approaching, urgent email, donor action needed.

## Usage

Use this skill when the user wants to:
- Send an alert via Telegram, email, ntfy, or PWA push
- Set rules for what events trigger notifications
- Review notification history and delivery status
- Subscribe to topic-based notification streams

## Channels

- **Telegram**: Uses existing bot integration
- **Email digest**: Sends via existing email skill SMTP
- **ntfy.sh**: Self-hosted push notification service (HIPAA-safe)
- **PWA push**: Via existing PWA infrastructure

## Cross-Skill Integration

- **proactive**: Deadline alerts, briefings, urgent items push to configured channel
- **triggers**: Scheduled triggers can fire notifications
- **triage**: Urgent email classification triggers phone alert
