#include <simplebluez/Config.h>

namespace SimpleBluez {
namespace Config {

bool use_system_bus = true;

}  // namespace Config
}  // namespace SimpleBluez
