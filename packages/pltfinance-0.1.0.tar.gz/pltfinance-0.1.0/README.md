# pltfinance

A simple financial plotting library built on top of Plotly.

## Installation

```bash
pip install pltfinance
```

- `pltfinance` requires [plotly](https://pypi.org/project/plotly/) and [pandas](https://pypi.org/project/pandas/)

## Basic Usage

```python
import pandas as pd
import pltfinance as pf

quotes = pd.read_csv("examples/data/AAPL-20241202-20251128.csv")
pf.plot(quotes)
```

![png](https://raw.githubusercontent.com/dumbsmart-org/pltfinance/master/images/basic_usage_aapl_ohlcv.png)

## Plot Indicators with OHLCV

```python
import pandas as pd
import pltfinance as pf

def compute_macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> pd.DataFrame:
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram = macd_line - signal_line

    return pd.DataFrame(
        {"DIF": macd_line, "DEA": signal_line, "MACD": histogram}, index=close.index
    )

quotes = pd.read_csv("examples/data/AAPL-20241202-20251128.csv")
ohlcv = pf.normalize_quotes(quotes)

price_ma5 = ohlcv["close"].rolling(5).mean()
price_ma20 = ohlcv["close"].rolling(20).mean()
price_ma60 = ohlcv["close"].rolling(60).mean()
volume_ma20 = ohlcv["volume"].rolling(20).mean()

macd = compute_macd(ohlcv["close"])

indicators = [
    pf.SeriesPlot(series=price_ma5, label="Price_MA5"),
    pf.SeriesPlot(series=price_ma20, label="Price_MA20"),
    pf.SeriesPlot(series=price_ma60, label="Price_MA60"),
    pf.SeriesPlot(series=volume_ma20, label="Volume_MA20", panel=1),
    pf.SeriesPlot(series=macd["DIF"], label="DIF", panel=2, color="#0099c6"),
    pf.SeriesPlot(series=macd["DEA"], label="DEA", panel=2, color=pf.Color.MAGENTA),
    pf.SeriesPlot(
        series=macd["MACD"],
        label="MACD",
        panel=2,
        type=pf.CharType.BAR,
        color=[pf.Color.GREEN if v >= 0 else pf.Color.RED for v in macd["MACD"]],
        secondary_y=True,
    ),
]

pf.plot(quotes, title="AAPL", indicators=indicators)
```

![png](https://raw.githubusercontent.com/dumbsmart-org/pltfinance/master/images/ohlcv_with_indicators.png)

## Copyright and Licenses

Code and documentation copyright 2026 dumbsmart.org.

Code released under the **MIT license**.
