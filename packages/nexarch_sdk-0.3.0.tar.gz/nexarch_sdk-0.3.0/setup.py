"""Setup configuration for nexarch-sdk"""
from setuptools import setup

# Configuration is in pyproject.toml
setup()
