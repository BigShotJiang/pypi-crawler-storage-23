"""Unit tests for research module."""
