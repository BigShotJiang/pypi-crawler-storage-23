# __init__.py dentro da pasta starbatdb

import json

class DB:
    def __init__(self, arquivo="StarBatDB.json"):
        self.arquivo = arquivo
        try:
            with open(self.arquivo, "r") as f:
                self.db = json.load(f)
        except FileNotFoundError:
            self.db = {}

    def salvar(self):
        with open(self.arquivo, "w") as f:
            json.dump(self.db, f, indent=4)

    def add_input_multilinha(self, pergunta):
        print(pergunta)
        print("Digite os dados do usuário (linha em branco para terminar):")
        linhas = []
        while True:
            linha = input()
            if linha.strip() == "":
                break
            linhas.append(linha)

        if not linhas:
            print("Nada foi digitado!")
            return

        # primeira linha é a chave principal
        chave = linhas[0].rstrip(":")
        self.db[chave] = {}

        cont = 0
        for l in linhas[1:]:
            if "=" in l:
                k, v = l.split("=", 1)
                k = k.strip()
                v = v.strip().replace(",", ".")
                # tenta converter para número
                try:
                    v = float(v)
                    if v.is_integer():
                        v = int(v)
                except:
                    pass
                self.db[chave][k] = v
                cont += 1

        self.salvar()
        print(f"{chave} adicionado ao banco com {cont} campo(s)! ✅")

    def get(self, key):
        return self.db.get(key, None)

    def update(self, key, campo, valor):
        if key in self.db:
            self.db[key][campo] = valor
            self.salvar()
            print(f"{key} atualizado! ✅")
        else:
            print(f"{key} não encontrado!")

    def remove(self, key):
        if key in self.db:
            del self.db[key]
            self.salvar()
            print(f"{key} removido! ✅")
        else:
            print(f"{key} não encontrado!")

    def list(self):
        # lista todos os usuários/chaves do banco
        return list(self.db.keys())

# funções que o usuário vai chamar
def start(arquivo="StarBatDB.json"):
    return DB(arquivo)

def config():
    print("Configuração pronta! ✨")