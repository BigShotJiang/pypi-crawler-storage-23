# StarBatDB

StarBatDB é um **banco de dados simples em Python** estilo StarBat, totalmente local, que salva os dados em **JSON**.  
Perfeito pra jogos, apps ou qualquer projeto onde você quer **armazenar dados do usuário de forma fácil**.

---

## 🔥 Funcionalidades
- `start()` → inicializa o banco de dados automaticamente
- `config()` → faz configuração inicial
- `db.add_input_multilinha("...")` → usuário adiciona dados interativamente
- `db.get("usuario")` → busca dados do usuário
- `db.update("usuario", "campo", "valor")` → atualiza dados
- `db.remove("usuario")` → remove dados do banco
- Tudo salvo automaticamente em **JSON**

---

## ⚡ Instalação

```bash
pip install starbatdb