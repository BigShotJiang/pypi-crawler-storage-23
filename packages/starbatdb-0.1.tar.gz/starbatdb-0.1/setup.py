from setuptools import setup, find_packages

setup(
    name="starbatdb",
    version="0.1",
    packages=find_packages(),
    description="Lib para banco de dados (DBs)",
    author="StarBat",
    license="MIT",
)