"""Assistant agent with coding tools and browser automation."""

import kiss.agents.assistant.config  # type: ignore # noqa: F401
