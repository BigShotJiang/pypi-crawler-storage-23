"""Slash commands for Claude Code and Codex."""
