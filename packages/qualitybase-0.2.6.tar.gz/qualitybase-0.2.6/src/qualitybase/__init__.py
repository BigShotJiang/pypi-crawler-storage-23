"""Services package for Python project tooling."""

from importlib.metadata import version

__version__ = version("qualitybase")
