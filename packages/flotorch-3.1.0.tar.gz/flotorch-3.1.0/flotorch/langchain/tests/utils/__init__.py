"""Tests for LangChain utility functions."""


