"""Tests for ADK utility functions."""

