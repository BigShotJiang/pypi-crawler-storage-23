"""
agentcents predictor.py — Phase 6
XGBoost cost predictor.

Trains on your actual ledger data to predict call cost before it happens.
Features: model, prompt_length, tag, hour_of_day, day_of_week, token_ratio

Usage:
    from agentcents.predictor import train, predict, prediction_report

    train()                        # train/retrain on current ledger
    cost = predict(model_id, prompt_text, tag)
    prediction_report()            # show feature importances + accuracy

Requires:
    pip install xgboost scikit-learn
"""

import json
import time
import logging
import pickle
from pathlib import Path
from typing import Optional

logger = logging.getLogger("agentcents.predictor")

MODEL_PATH = Path(__file__).parent / "data" / "cost_predictor.pkl"
MIN_ROWS   = 20   # minimum ledger rows needed to train


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------

# All known model IDs → integer index for XGBoost
MODEL_INDEX: dict = {}
TAG_INDEX:   dict = {}


def _featurize(
    model_id: str,
    prompt_len: int,
    tag: str,
    ts: float,
    completion_tokens: Optional[int] = None,
    prompt_tokens: Optional[int] = None,
) -> list:
    """
    Build feature vector:
      0: model_index         (categorical encoded)
      1: prompt_len          (character count of raw prompt)
      2: tag_index           (categorical encoded)
      3: hour_of_day         (0-23)
      4: day_of_week         (0=Mon, 6=Sun)
      5: token_ratio         (completion/prompt tokens, or 0 if unknown)
      6: log_prompt_len      (log scale handles long prompts better)
    """
    import math

    model_idx = MODEL_INDEX.get(model_id, -1)
    tag_idx   = TAG_INDEX.get(tag, -1)

    dt = time.localtime(ts)
    hour = dt.tm_hour
    dow  = dt.tm_wday

    if prompt_tokens and completion_tokens and prompt_tokens > 0:
        token_ratio = completion_tokens / prompt_tokens
    else:
        token_ratio = 0.0

    log_prompt = math.log1p(prompt_len)

    return [model_idx, prompt_len, tag_idx, hour, dow, token_ratio, log_prompt]


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------

def train(force: bool = False) -> bool:
    """
    Train XGBoost on ledger data.
    Returns True if training succeeded, False if not enough data.
    """
    import sqlite3
    import numpy as np

    db_path = Path(__file__).parent / "data" / "ledger.db"
    if not db_path.exists():
        logger.warning("No ledger.db found — call the proxy first to generate data")
        return False

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    rows = conn.execute("""
        SELECT model_id, tag, ts, prompt_tokens, completion_tokens, cost_usd
        FROM calls
        WHERE cost_usd > 0
          AND prompt_tokens > 0
          AND completion_tokens > 0
    """).fetchall()
    conn.close()

    if len(rows) < MIN_ROWS:
        logger.warning(f"Only {len(rows)} usable rows — need {MIN_ROWS} to train")
        return False

    # Build vocabulary
    global MODEL_INDEX, TAG_INDEX
    models = sorted(set(r["model_id"] for r in rows if r["model_id"]))
    tags   = sorted(set(r["tag"]      for r in rows if r["tag"]))
    MODEL_INDEX = {m: i for i, m in enumerate(models)}
    TAG_INDEX   = {t: i for i, t in enumerate(tags)}

    X, y = [], []
    for r in rows:
        # Approximate prompt length from token count (avg ~4 chars/token)
        prompt_len = (r["prompt_tokens"] or 0) * 4
        feat = _featurize(
            model_id          = r["model_id"] or "",
            prompt_len        = prompt_len,
            tag               = r["tag"] or "default",
            ts                = r["ts"],
            completion_tokens = r["completion_tokens"],
            prompt_tokens     = r["prompt_tokens"],
        )
        X.append(feat)
        y.append(r["cost_usd"])

    X = np.array(X, dtype=np.float32)
    y = np.array(y, dtype=np.float32)

    try:
        import xgboost as xgb
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import mean_absolute_error, r2_score

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )

        model = xgb.XGBRegressor(
            n_estimators     = 200,
            max_depth        = 4,
            learning_rate    = 0.05,
            subsample        = 0.8,
            colsample_bytree = 0.8,
            random_state     = 42,
            verbosity        = 0,
        )
        model.fit(X_train, y_train)

        y_pred = model.predict(X_test)
        mae    = mean_absolute_error(y_test, y_pred)
        r2     = r2_score(y_test, y_pred)

        # Save model + vocabulary
        MODEL_PATH.parent.mkdir(exist_ok=True)
        with open(MODEL_PATH, "wb") as f:
            pickle.dump({
                "model":       model,
                "model_index": MODEL_INDEX,
                "tag_index":   TAG_INDEX,
                "trained_at":  time.time(),
                "n_rows":      len(rows),
                "mae":         mae,
                "r2":          r2,
            }, f)

        logger.info(f"Trained on {len(rows)} rows  MAE=${mae:.8f}  R²={r2:.3f}")
        return True

    except ImportError as e:
        logger.error(f"Missing dependency: {e}  — pip install xgboost scikit-learn")
        return False
    except Exception as e:
        logger.error(f"Training failed: {e}")
        return False


# ---------------------------------------------------------------------------
# Inference
# ---------------------------------------------------------------------------

def _load_model() -> Optional[dict]:
    if not MODEL_PATH.exists():
        return None
    try:
        with open(MODEL_PATH, "rb") as f:
            return pickle.load(f)
    except Exception:
        return None


def predict(
    model_id: str,
    prompt_text: str,
    tag: str = "default",
    ts: Optional[float] = None,
) -> Optional[float]:
    """
    Predict cost (USD) for a call before it's made.
    Returns None if predictor not trained yet.
    """
    import numpy as np

    bundle = _load_model()
    if not bundle:
        return None

    global MODEL_INDEX, TAG_INDEX
    MODEL_INDEX = bundle["model_index"]
    TAG_INDEX   = bundle["tag_index"]

    feat = _featurize(
        model_id   = model_id,
        prompt_len = len(prompt_text),
        tag        = tag,
        ts         = ts or time.time(),
    )

    try:
        X = np.array([feat], dtype=np.float32)
        pred = bundle["model"].predict(X)[0]
        return max(float(pred), 0.0)
    except Exception as e:
        logger.warning(f"Prediction failed: {e}")
        return None


def model_info() -> Optional[dict]:
    bundle = _load_model()
    if not bundle:
        return None
    return {
        "trained_at": time.strftime("%Y-%m-%d %H:%M", time.localtime(bundle["trained_at"])),
        "n_rows":     bundle["n_rows"],
        "mae":        bundle["mae"],
        "r2":         bundle["r2"],
        "n_models":   len(bundle["model_index"]),
        "n_tags":     len(bundle["tag_index"]),
    }


def prediction_report():
    """Print feature importances and model accuracy."""
    import numpy as np

    bundle = _load_model()
    if not bundle:
        print("\n  No trained model found. Run: agentcents train\n")
        return

    m = bundle["model"]
    info = model_info()
    importances = m.feature_importances_

    feature_names = [
        "model_id", "prompt_length", "tag",
        "hour_of_day", "day_of_week", "token_ratio", "log_prompt_len"
    ]

    print(f"\nagentcents predictor\n")
    print(f"  trained:   {info['trained_at']}")
    print(f"  rows:      {info['n_rows']}")
    print(f"  MAE:       ${info['mae']:.8f}")
    print(f"  R²:        {info['r2']:.4f}")
    print(f"  models:    {info['n_models']}  tags: {info['n_tags']}")
    print(f"\n  Feature importances:")

    pairs = sorted(zip(feature_names, importances), key=lambda x: x[1], reverse=True)
    for name, imp in pairs:
        bar = "█" * int(imp * 40)
        print(f"    {name:<20} {imp:.4f}  {bar}")
    print()
