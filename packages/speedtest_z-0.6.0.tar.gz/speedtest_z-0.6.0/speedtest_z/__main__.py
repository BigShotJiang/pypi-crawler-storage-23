"""Allow running speedtest-z as ``python -m speedtest_z``."""

from speedtest_z.cli import main

main()
