from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class sex:
    good: bool = True

    def __bool__(self):
        return self.good

    def __repr__(self):
        return "sex()" if self.good else "sex(good=False)"
