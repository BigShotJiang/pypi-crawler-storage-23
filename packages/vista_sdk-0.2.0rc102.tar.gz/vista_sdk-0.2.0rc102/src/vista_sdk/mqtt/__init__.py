"""MQTT extensions for Vista SDK."""

from vista_sdk.mqtt.mqtt_local_id import MqttLocalId

__all__ = ["MqttLocalId"]
