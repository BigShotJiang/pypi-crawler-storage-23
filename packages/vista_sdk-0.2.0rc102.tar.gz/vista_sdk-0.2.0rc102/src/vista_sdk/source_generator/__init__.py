"""Init for source generator module."""
