1.  Create some portal users belonging to the same company.
2.  Create some invoices for several of these users.
3.  Log in with each portal user credential.
4.  Only the invoices belonging to the logged in user's partner or his
    descendants should be accessible.
