By default, portal users are allowed to see all the invoices in which a
member of their organization are followers. That could cause a leaking
of documents between members and departments and of the organization
that should stay private.

This module restricts that behavior so the portal users only see their
own documents.

A similar module named `portal_sale_personal_data_only` exists to do the
same for sale orders.
