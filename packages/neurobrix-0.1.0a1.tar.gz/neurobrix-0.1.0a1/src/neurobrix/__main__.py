"""Allow running neurobrix as: python -m neurobrix"""
from neurobrix.cli import main
main()
