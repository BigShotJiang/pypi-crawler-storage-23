"""NeuroBrix - Universal Deep Learning Inference Engine."""
__version__ = "0.1.0a1"
