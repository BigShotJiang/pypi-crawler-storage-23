"""
NeuroBrix Core - Universal Deep Learning Runtime.

Modules:
    - nbx: Model container format (.nbx)
    - prism: Hardware planning and allocation (SINGLE SOURCE OF TRUTH)
    - executor: Execution engine
    - runtime: Passive orchestration layer
"""
