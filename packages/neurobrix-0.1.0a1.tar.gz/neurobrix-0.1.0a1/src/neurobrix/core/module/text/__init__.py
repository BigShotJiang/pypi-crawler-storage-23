# core/module/text/__init__.py
"""TextProcessor brick — unified tokenization for all flow types."""
from neurobrix.core.module.text.processor import TextProcessor

__all__ = ["TextProcessor"]
