# core/module/cache/__init__.py
"""StateCacheFactory brick — declarative KV cache creation."""
from neurobrix.core.module.cache.factory import StateCacheFactory

__all__ = ["StateCacheFactory"]
