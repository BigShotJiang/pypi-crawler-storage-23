## Vision Printemps 2026 — Roadmap officielle NeuroBrix Runtime

**État: Février 2026 — Mise à jour basée sur l'état réel du système**

(Document stratégique – version interne, qualité CTO/Board)

### 1. Vision

NeuroBrix devient en 2026 le premier runtime IA entièrement multihardware, déterministe et modulaire, capable d'exécuter n'importe quel modèle IA moderne sans dépendance propriétaire, sans fallback implicite, et avec une architecture claire et portable.

L'objectif :
Créer l'équivalent IA d'un système d'exploitation universel pour les réseaux neuronaux.

**Réalité Feb 2026**: NeuroBrix est un package Python + Triton pip-installable avec runtime graph-based, système de registre, et architecture modulaire mature.

### 2. Pilier 1 — NBX Graph et Topology Engine 2.0

#### Objectif

Un pipeline de parsing universel, stable, vendor-neutral.

#### État: ✅ FAIT (Janvier 2026)

**Implémentation actuelle:**
- **PyTorch Tracer**: `forge/tracer/` (anciennement `trace/`) — système de capture complet via `torch.compile(backend=...)`
- **NeuroTax**: `src/neurobrix/nbx/neurotax.py` — normalisation ATen → format canonique `aten::op`
- **NBX Graph Standard**: `components/{name}/graph.json` — TensorDAG avec op_uid, op_type, inputs, outputs, attributes
- **Topology**: `topology.json` — metadata, components, modules, execution pipeline
- **ONNX**: ❌ Jamais utilisé dans NeuroBrix — PyTorch Dynamo capture directe

**Fichiers clés:**
- `forge/tracer/dynamo.py` — Backend Dynamo
- `forge/tracer/capture.py` — Extraction graph
- `forge/tracer/orchestrator.py` — Orchestration multi-composants
- `src/neurobrix/nbx/neurotax.py` — Normalisation aten.op.variant → aten::op

#### Résultat
- ✅ Topologie 100% correcte (validée sur PixArt, Sana, Janus, DeepSeek)
- ✅ Multi-framework ready (architecture extensible, actuellement PyTorch)
- ✅ Conversion totalement fiable (format canonique ATen)

### 3. Pilier 2 — Universal Execution Backend (UEB)

#### Objectif

Exécuter n'importe quelle opération sur n'importe quel hardware.

#### État: ⚡ PARTIELLEMENT FAIT (architecture 100% Python + Triton)

**Backends implémentés:**
- ✅ **Compiled (défaut)**: `src/neurobrix/core/runtime/graph/compiled_sequence.py` — CompiledSequenceV2 + DtypeEngine (AMP autocast)
- ✅ **Native (--seq_aten)**: `src/neurobrix/core/runtime/native_dispatcher.py` — PyTorch ATen direct
- ✅ **Triton (--triton)**: `src/neurobrix/kernels/` — Kernels Triton custom (R&D)
- ✅ **Metadata**: `src/neurobrix/kernels/metadata_ops.py` — Opérations shape-only (--triton mode)

**Architecture actuelle:**
```
GraphExecutor → mode="compiled" (défaut)
             → mode="native" (--seq_aten)
             → mode="triton" (--triton, via KernelAdapter)
```

**Limitations:**
- ❌ SYCL, Vulkan, Metal, ROCm: Non implémentés (100% Python + Triton NVIDIA/AMD)
- ❌ CPU backend natif: Triton CPU backend expérimental uniquement
- ⚠️ Hardware testé: NVIDIA V100/A100 uniquement (AMD/Apple Silicon TODO)

**Fichiers clés:**
- `src/neurobrix/core/runtime/graph_executor.py` — Orchestration multi-mode
- `src/neurobrix/core/dtype/engine.py` — DtypeEngine (AMP autocast PyTorch)
- `src/neurobrix/kernels/adapter.py` — Triton kernel dispatcher
- `src/neurobrix/kernels/classification.py` — TRITON vs METADATA ops

#### Actions TODO 2026
- ⬜ Tester Triton AMD ROCm
- ⬜ Valider Triton CPU backend
- ⬜ Metal/MPS support (Apple Silicon)
- ⬜ Benchmarking suite NBX-Bench

### 4. Pilier 3 — Triton Kernel Suite (TKS)

#### Objectif

Écrire les kernels Triton nécessaires pour couvrir 95% des modèles IA.

#### État: 🔬 R&D EN COURS (--triton experimental)

**Kernels implémentés (src/neurobrix/kernels/ops/):**
- ✅ **Activations**: ReLU, GELU, SiLU, Sigmoid, Tanh
- ✅ **Pooling**: AdaptiveAvgPool2D, MaxPool2D
- ✅ **Scatter/Gather**: scatter, gather
- ✅ **Elementwise**: add, mul, sub, div
- ⚠️ **MatMul**: Délégué à PyTorch (classification METADATA)
- ⚠️ **Attention**: Délégué à PyTorch SDPA (classification METADATA)
- ⚠️ **LayerNorm/RMSNorm**: Délégué à PyTorch (classification METADATA)

**Architecture kernels:**
```python
@triton.jit
def _kernel_name(...):
    # Pure Triton compute via tl.*
    pass

@register_kernel(family="...", vendor="nvidia", tier="common")
def kernel_name(x: torch.Tensor) -> torch.Tensor:
    # Setup only — NO COMPUTE in wrapper
    output = torch.empty_like(x)
    _kernel_name[grid](...)
    return output
```

**Limitations actuelles:**
- ❌ **Pas de MatMul custom** (PyTorch cuBLAS/rocBLAS plus rapide)
- ❌ **Pas de fusion MLP** (complexité vs gain)
- ❌ **Conv1D/2D** non prioritaires (diffusion utilise PyTorch conv2d)
- ⚠️ **Performance vs PyTorch**: 400× divergence observée sur certains ops (voir KERNELS_OPERATOR_SYSTEM.md)

**Fichiers clés:**
- `src/neurobrix/kernels/ops/activations.py`
- `src/neurobrix/kernels/ops/pooling.py`
- `src/neurobrix/kernels/ops/scatter_gather.py`
- `src/neurobrix/kernels/classification.py` — TRITON vs METADATA routing

#### Actions TODO 2026
- ⬜ TKS v1: Stabiliser kernels existants (éliminer divergences)
- ⬜ TKS v2: Fused LayerNorm+Linear, Fused GELU+Matmul
- ⬜ TKS v3: Flash Attention compatible
- ⬜ TKS v4: Quantization-aware (int8, fp8)

### 5. Pilier 4 — Zero Fallback Policy (ZFP)

#### Objectif

Aucune ambiguïté, aucune substitution silencieuse.

#### État: ✅ FAIT (principe fondateur)

**Implémentation actuelle:**
- ✅ **ZERO HARDCODE**: Toutes valeurs dérivées du container NBX (manifest.json, defaults.json, runtime.json)
- ✅ **ZERO FALLBACK**: Crash explicite si données manquantes (pas de valeurs par défaut silencieuses)
- ✅ **ZERO SEMANTIC**: Runtime sans connaissance domaine (pas de "image", "latent", "vae" — uniquement tenseurs et axes)
- ✅ **Container = Source of Truth**: `.nbx` → extraction → `~/.neurobrix/cache/{model}/`

**Documentation:**
- `docs/ZERO_FALLBACK_POLICY.md` — Spécification complète
- `CLAUDE.md` section 1 — Principes ZERO

**Exemples:**
```python
# ZERO HARDCODE: dimensions from manifest
state_channels = manifest["components"]["transformer"]["attributes"]["state_channels"]

# ZERO FALLBACK: crash if missing
if "num_inference_steps" not in defaults:
    raise ValueError("Missing num_inference_steps in defaults.json")

# ZERO SEMANTIC: no domain keywords
# WRONG: if component_type == "vae":
# CORRECT: if component_name in persistent_components:
```

**Fichiers clés:**
- `src/neurobrix/core/validators/nbx_validator.py` — Validation container
- `src/neurobrix/core/runtime/variables.py` — Résolution variables sans fallback

#### Actions TODO 2026
- ⬜ NBX Doctor: outil diagnostic automatique (valide container avant run)
- ⬜ Analyse compile-time: détecter ops non supportées avant exécution
- ✅ Rapports d'erreurs: déjà détaillés (stack traces avec contexte NBX)

### 6. Pilier 5 — Multi-vendor & Sustainability

#### Objectif

Un runtime réellement indépendant.

#### État: ⚠️ PARTIELLEMENT FAIT (architecture prête, tests limités)

**Architecture actuelle:**
- ✅ **Abstraction hardware**: `src/neurobrix/core/hardware/detector.py` — Détection device-agnostic
- ✅ **Prism solver**: `src/neurobrix/core/prism/solver.py` — Allocation multi-GPU strategy-aware
- ✅ **Hardware profiles YAML**: `src/neurobrix/config/hardware/` — V100, A100, configs custom
- ✅ **Triton backend**: Vendor-neutral par design (NVIDIA/AMD/Intel GPU)
- ✅ **Zero appels CUDA directs**: Tout via PyTorch/Triton abstractions

**Hardware testé:**
- ✅ **NVIDIA V100 32GB** (single GPU)
- ✅ **NVIDIA V100 NVLink cluster** (4x GPU, pipeline parallelism)
- ⬜ **AMD ROCm** (architecture supportée, non testé)
- ⬜ **Intel GPU** (Triton compatible, non testé)
- ⬜ **Apple Silicon (Metal/MPS)** (TODO)
- ⬜ **ARM/Mobile** (TODO)

**Stratégies Prism implémentées:**
- ✅ `SINGLE_GPU` (lazy/eager/lifecycle)
- ✅ `PP_NVLINK` / `PP_PCIE` (pipeline parallelism)
- ✅ `TP_INTENT` (tensor parallelism)
- ✅ `ZERO3_OFFLOAD` (DeepSpeed-style offload)
- ✅ `COMPONENT_AFFINITY` (multi-GPU assignment)

**Fichiers clés:**
- `src/neurobrix/core/prism/solver.py` — Solver multi-stratégie
- `src/neurobrix/core/strategies/` — Implémentations stratégies
- `src/neurobrix/config/hardware/` — Profiles YAML

#### Actions TODO 2026
- ⬜ Tester AMD ROCm (MI100/MI250)
- ⬜ Tester Intel GPU (Arc A770)
- ⬜ Apple Silicon MPS backend
- ⬜ ARM/Mobile (Snapdragon, Jetson)
- ⬜ RISC-V (architecture futureproof)

### 7. Pilier 6 — Developer Experience (DevX)

#### Objectif

Rendre NeuroBrix simple, lisible, adoptable.

#### État: ✅ LARGEMENT FAIT (package pip-installable, CLI moderne)

**Implémentation actuelle:**
- ✅ **Package pip-installable**: `pip install neurobrix` (structure src/neurobrix/)
- ✅ **CLI moderne**: `neurobrix run|import|list|remove|info|inspect|validate`
- ✅ **Documentation extensive**: `docs/` (BIBLE_NEUROBRIX.md, CHANGELOG.md, KERNELS_OPERATOR_SYSTEM.md)
- ✅ **CLAUDE.md**: Mémoire persistante et directives système (1300+ lignes)
- ✅ **API runtime stable**: RuntimeExecutor, NBXContainer, PrismSolver
- ✅ **Debug système**: `NBX_DEBUG`, `NBX_TRACE_ZEROS`, `NBX_TRACE_NAN`, `NBX_NAN_GUARD`
- ✅ **Registry intégré**: neurobrix.es (PostgreSQL + MinIO + Next.js)

**Architecture package:**
```
src/neurobrix/
├── cli.py              # Entry point CLI
├── core/               # Runtime engine
├── kernels/            # Triton kernels
├── nbx/                # Format NBX + NeuroTax
└── config/             # Hardware/vendor YAML

forge/                  # Outils privés (snap/build/trace/publish)
├── forge.py            # CLI forge
├── importer/           # NBX builder
├── tracer/             # PyTorch capture
└── config/families/    # Templates famille
```

**Expérience utilisateur:**
```bash
# Installation
pip install neurobrix

# Import modèle depuis registry
neurobrix import sana/1600m-1024

# Liste modèles installés
neurobrix list

# Exécution
neurobrix run --model 1600m-1024 --hardware v100-32g --prompt "A sunset"

# Debug
NBX_DEBUG=1 neurobrix run --model ... --seq_aten  # Mode natif verbose
NBX_TRACE_ZEROS=1 neurobrix run ...  # Détecter zéros anormaux
```

**Fichiers clés:**
- `src/neurobrix/cli.py` — Interface CLI principale
- `CLAUDE.md` — Documentation développeur complète
- `docs/BIBLE_NEUROBRIX.md` — Architecture système

#### Actions TODO 2026
- ⬜ **NBX Visualizer**: Interface web graphe opérationnel interactif (D3.js/Cytoscape)
- ⬜ **Templates kernels**: Générateur skeleton kernels Triton
- ⬜ **NBX Debugger**: Breakpoints dans le graphe, inspection tenseurs
- ⬜ **Profiler intégré**: Temps/mémoire par op (extension `--profile`)
- ⬜ **Documentation API publique**: Sphinx/MkDocs pour src/neurobrix/

### 8. Résultat attendu Printemps 2026

#### État: ✅ OBJECTIFS PRINCIPAUX ATTEINTS (Février 2026)

**NeuroBrix est devenu:**

- ✅ **Le runtime IA le plus propre et prévisible**
  - Architecture ZERO HARDCODE/FALLBACK/SEMANTIC strictement appliquée
  - Container NBX comme source unique de vérité
  - Crashes explicites plutôt que comportements silencieux
  - DtypeEngine avec AMP autocast PyTorch (stabilité fp16)

- ⚠️ **Indépendance fournisseurs (partiellement)**
  - ✅ Format NBX vendor-neutral
  - ✅ Triton backend (NVIDIA/AMD/Intel compatible par design)
  - ⚠️ Testé uniquement NVIDIA V100/A100 (AMD/Apple TODO)
  - ✅ Zero appels CUDA directs (abstraction PyTorch/Triton)

- ⚡ **Performance (compétitive avec optimisations)**
  - ✅ CompiledSequenceV2: Élimine overhead Python (~15000 dict lookups → 0)
  - ✅ DtypeEngine: AMP autocast évite overflows fp16 (RMSNorm pow→mean→rsqrt)
  - ✅ Prism KV cache: Data-driven sizing (max_tokens + prompt_margin)
  - ⚠️ Triton kernels: 400× divergence sur certains ops (R&D en cours)
  - ✅ Inference mode: `torch.inference_mode()` élimine autograd overhead

- ✅ **Cohérence et extensibilité**
  - Architecture modulaire: core/ (runtime), kernels/ (Triton), nbx/ (format), config/ (YAML)
  - Stratégies Prism: SINGLE_GPU, PP_NVLINK, TP_INTENT, ZERO3_OFFLOAD
  - Flow handlers: iterative_process, autoregressive_generation, forward_pass, static_graph
  - Registry neurobrix.es (import/list/remove models)

- ✅ **Support modèles multiples**
  - **Diffusion**: PixArt-Alpha, PixArt-Sigma, Sana 1024px/4K, FLUX
  - **LLM**: DeepSeek-MoE-16B, Llama, Mistral
  - **Multimodal**: Janus-Pro-7B (VQ autoregressive image)
  - **Audio**: Whisper (TODO)
  - **Video**: CogVideoX (TODO)

- ✅ **Prêt pour industrialisation**
  - Package pip: `pip install neurobrix`
  - CLI: `neurobrix run|import|list|remove`
  - Registry public: neurobrix.es (PostgreSQL + MinIO + Next.js)
  - Forge privé: `forge/forge.py snap|build|trace|publish`
  - Documentation: CLAUDE.md (1300+ lignes), BIBLE_NEUROBRIX.md
  - Debug système: NBX_DEBUG, NBX_TRACE_ZEROS, NBX_TRACE_NAN

### 9. Prochaines étapes (Q2 2026)

**Priorités court terme:**

1. **Multi-hardware validation**
   - Tester AMD ROCm (MI100/MI250)
   - Tester Apple Silicon MPS
   - Valider Triton CPU backend

2. **Triton kernels stabilisation**
   - Résoudre divergences 400× (voir KERNELS_OPERATOR_SYSTEM.md)
   - Flash Attention compatible
   - Fused kernels (LayerNorm+Linear, GELU+Matmul)

3. **DevX improvements**
   - NBX Visualizer (graphe interactif web)
   - NBX Debugger (breakpoints graphe)
   - Documentation API publique (Sphinx)
   - Profiler intégré (temps/mémoire par op)

4. **Performance optimizations**
   - MOE fusion kernels (src/neurobrix/core/runtime/graph/moe_fusion.py)
   - KV cache quantization (int8/fp8)
   - Pipeline parallelism optimizations

5. **Ecosystem expansion**
   - SDK tiers (Python API stable pour intégration)
   - Quantization support (GGUF, AWQ, GPTQ)
   - Audio models (Whisper complet)
   - Video models (CogVideoX, Sora-like)

**Vision long terme:**

NeuroBrix comme standard de runtime IA universal, avec:
- Support 6+ architectures GPU (NVIDIA, AMD, Intel, Apple, ARM, RISC-V)
- Kernels Triton 95% coverage (fusion aggressive)
- Registry public >100 modèles (diffusion, LLM, multimodal, audio, video)
- Adoption communauté (pip install neurobrix standard workflow)
- Alternative crédible à ONNX Runtime / TensorRT / vLLM
