import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone

import httpx

PYPI_API = "https://pypi.org/pypi/{}/json"
GITHUB_SEARCH_API = "https://api.github.com/search/repositories"
TIMEOUT = 10

# ANSI colors (no-op on redirected output)
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"


def _ensure_utf8():
    """Reconfigure stdout/stderr to UTF-8 on Windows to avoid cp1252 errors."""
    if sys.platform == "win32" and hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def _supports_color():
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def check_name(client: httpx.Client, name: str) -> dict:
    """Check a single package name against the live PyPI API."""
    url = PYPI_API.format(name)
    try:
        resp = client.get(url)
    except httpx.HTTPError as exc:
        return {"name": name, "available": None, "error": str(exc)}

    if resp.status_code == 404:
        return {"name": name, "available": True}

    if resp.status_code == 200:
        data = resp.json()
        info = data.get("info", {})
        return {
            "name": name,
            "available": False,
            "version": info.get("version", ""),
            "summary": info.get("summary", ""),
            "author": info.get("author", "") or info.get("maintainer", ""),
            "url": f"https://pypi.org/project/{name}/",
        }

    return {
        "name": name,
        "available": None,
        "error": f"Unexpected status {resp.status_code}",
    }


def print_result(result: dict, color: bool):
    """Pretty-print a single lookup result."""
    name = result["name"]

    if result.get("error"):
        print(f"  ? {name} — error: {result['error']}")
        return

    if result["available"]:
        tag = f"{GREEN}✔{RESET}" if color else "✔"
        print(f"  {tag} {BOLD}{name}{RESET} is available!" if color else f"  ✔ {name} is available!")
    else:
        tag = f"{RED}✘{RESET}" if color else "✘"
        version = result.get("version", "")
        summary = result.get("summary", "")
        meta = f" (v{version})" if version else ""
        desc = f" — {summary}" if summary else ""
        print(f"  {tag} {BOLD}{name}{RESET}{meta}{desc}" if color else f"  ✘ {name}{meta}{desc}")
        url = result.get("url", "")
        if url:
            print(f"    {DIM}{url}{RESET}" if color else f"    {url}")


# --- GitHub scan helpers ---


def _github_headers():
    """Build headers for GitHub API requests, with optional token auth."""
    headers = {"Accept": "application/vnd.github+json"}
    token = os.environ.get("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _build_scan_query(keywords, min_stars, days, topic):
    """Construct the GitHub search API `q` parameter."""
    q = f"{keywords} language:python in:description,readme"
    q += f" stars:>={min_stars}"
    if days:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        q += f" pushed:>{cutoff.strftime('%Y-%m-%d')}"
    if topic:
        q += f" topic:{topic}"
    return q


def scan_github(client: httpx.Client, query: str, limit: int) -> list[dict]:
    """Search GitHub for Python repos matching a description."""
    params = {
        "q": query,
        "sort": "stars",
        "order": "desc",
        "per_page": min(limit, 100),
    }
    try:
        resp = client.get(
            GITHUB_SEARCH_API,
            params=params,
            headers=_github_headers(),
        )
    except httpx.HTTPError as exc:
        return [{"error": f"Network error: {exc}"}]

    if resp.status_code == 403:
        return [{"error": "GitHub API rate limit exceeded. Set GITHUB_TOKEN env var to increase limits."}]

    if resp.status_code != 200:
        return [{"error": f"GitHub API returned status {resp.status_code}"}]

    data = resp.json()
    results = []
    for repo in data.get("items", [])[:limit]:
        license_info = repo.get("license") or {}
        results.append({
            "name": repo.get("full_name", ""),
            "description": repo.get("description", "") or "",
            "stars": repo.get("stargazers_count", 0),
            "url": repo.get("html_url", ""),
            "pushed_at": repo.get("pushed_at", "")[:10],
            "topics": repo.get("topics", []),
            "license": license_info.get("spdx_id", "") or "",
        })
    return results


def print_scan_result(result: dict, index: int, color: bool):
    """Pretty-print a single GitHub scan result."""
    if result.get("error"):
        print(f"  ! {result['error']}")
        return

    name = result["name"]
    stars = result["stars"]
    desc = result["description"]
    pushed = result["pushed_at"]
    lic = result["license"]
    topics = result["topics"]
    url = result["url"]

    star_str = f"{YELLOW}★ {stars}{RESET}" if color else f"★ {stars}"
    name_str = f"{BOLD}{name}{RESET}" if color else name

    print(f"  {name_str}  {star_str}")
    if desc:
        print(f"    {desc}")
    meta_parts = []
    if pushed:
        meta_parts.append(f"updated {pushed}")
    if lic:
        meta_parts.append(lic)
    if topics:
        meta_parts.append(", ".join(topics))
    if meta_parts:
        meta = " | ".join(meta_parts)
        print(f"    {DIM}{meta}{RESET}" if color else f"    {meta}")
    if url:
        print(f"    {DIM}{url}{RESET}" if color else f"    {url}")


# --- Subcommand runners ---


def run_check(args):
    """Run the PyPI name-check subcommand."""
    color = _supports_color() and not args.json_output
    results = []

    with httpx.Client(timeout=TIMEOUT, follow_redirects=True) as client:
        for name in args.names:
            results.append(check_name(client, name))

    if args.json_output:
        json.dump(results, sys.stdout, indent=2)
        print()
    else:
        for r in results:
            print_result(r, color)


def run_scan(args):
    """Run the GitHub scan subcommand."""
    color = _supports_color() and not args.json_output
    keywords = " ".join(args.query)
    query = _build_scan_query(keywords, args.stars, args.days, args.topic)

    with httpx.Client(timeout=TIMEOUT, follow_redirects=True) as client:
        results = scan_github(client, query, args.limit)

    if args.json_output:
        json.dump(results, sys.stdout, indent=2)
        print()
    else:
        if not results:
            print("  No matching repositories found.")
        elif results[0].get("error"):
            print_scan_result(results[0], 0, color)
        else:
            for i, r in enumerate(results):
                print_scan_result(r, i, color)
                if i < len(results) - 1:
                    print()


def main():
    parser = argparse.ArgumentParser(
        prog="pkgscout",
        description="Check PyPI name availability and scan GitHub for similar packages.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # --- check subcommand ---
    check_parser = subparsers.add_parser(
        "check",
        help="Check whether package names are available on PyPI",
    )
    check_parser.add_argument(
        "names",
        nargs="+",
        metavar="NAME",
        help="One or more package names to check",
    )
    check_parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output results as JSON",
    )

    # --- scan subcommand ---
    scan_parser = subparsers.add_parser(
        "scan",
        help="Search GitHub for Python repos matching a description",
    )
    scan_parser.add_argument(
        "query",
        nargs="+",
        metavar="KEYWORD",
        help="Keywords describing the package idea",
    )
    scan_parser.add_argument(
        "--stars",
        type=int,
        default=10,
        help="Minimum star count (default: 10)",
    )
    scan_parser.add_argument(
        "--days",
        type=int,
        default=365,
        help="Only repos pushed within N days (default: 365)",
    )
    scan_parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Max results to display (default: 10)",
    )
    scan_parser.add_argument(
        "--topic",
        default=None,
        help="Filter by GitHub topic",
    )
    scan_parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output results as JSON",
    )

    _ensure_utf8()

    # Backward compat: if first arg is not a known subcommand, assume "check"
    argv = sys.argv[1:]
    if argv and argv[0] not in ("check", "scan", "-h", "--help"):
        # Handle --json before positional names: e.g. `pkgscout --json requests`
        argv = ["check"] + argv

    args = parser.parse_args(argv)

    if args.command == "check":
        run_check(args)
    elif args.command == "scan":
        run_scan(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
