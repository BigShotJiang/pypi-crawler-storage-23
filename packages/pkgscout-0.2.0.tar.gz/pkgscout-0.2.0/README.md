# pkgscout

A modern CLI to check whether Python package names are available on PyPI.

Queries the **live PyPI API** — no stale offline database. Shows rich metadata for taken names: version, summary, author, and project URL.

## Install

Requires [UV](https://docs.astral.sh/uv/) and Python 3.12+.

```bash
uv sync
```

## Usage

```bash
# Check a single name
uv run pkgscout requests
#   ✘ requests (v2.32.5) — Python HTTP for Humans.
#     https://pypi.org/project/requests/

# Check if a name is available
uv run pkgscout my-cool-lib
#   ✔ my-cool-lib is available!

# Batch check
uv run pkgscout requests flask numpy my-cool-lib
#   ✘ requests (v2.32.5) — Python HTTP for Humans.
#   ✘ flask (v3.1.2) — A simple framework for building complex web applications.
#   ✘ numpy (v2.4.2) — Fundamental package for array computing in Python
#   ✔ my-cool-lib is available!

# JSON output for scripting
uv run pkgscout --json requests my-cool-lib
```

JSON output example:

```json
[
  {
    "name": "requests",
    "available": false,
    "version": "2.32.5",
    "summary": "Python HTTP for Humans.",
    "author": "Kenneth Reitz",
    "url": "https://pypi.org/project/requests/"
  },
  {
    "name": "my-cool-lib",
    "available": true
  }
]
```

## How It Works

For each name, pkgscout sends a `GET` request to `https://pypi.org/pypi/{name}/json`:

- **200** — name is taken, metadata is extracted and displayed
- **404** — name is available

## License

MIT
