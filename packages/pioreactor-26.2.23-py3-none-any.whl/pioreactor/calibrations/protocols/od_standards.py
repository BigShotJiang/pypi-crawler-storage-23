# -*- coding: utf-8 -*-
"""
Copyright 2023 Chris Macdonald, Pioreactor

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
import uuid
from time import sleep
from typing import cast
from typing import ClassVar

from msgspec import to_builtins
from pioreactor import structs
from pioreactor import types as pt
from pioreactor.background_jobs.od_reading import average_over_od_readings
from pioreactor.background_jobs.od_reading import REF_keyword
from pioreactor.background_jobs.od_reading import start_od_reading
from pioreactor.calibrations import list_of_calibrations_by_device
from pioreactor.calibrations.registry import CalibrationProtocol
from pioreactor.calibrations.session_flow import CalibrationComplete
from pioreactor.calibrations.session_flow import fields
from pioreactor.calibrations.session_flow import run_session_in_cli
from pioreactor.calibrations.session_flow import SessionContext
from pioreactor.calibrations.session_flow import SessionStep
from pioreactor.calibrations.session_flow import StepRegistry
from pioreactor.calibrations.session_flow import steps
from pioreactor.calibrations.structured_session import CalibrationSession
from pioreactor.calibrations.structured_session import CalibrationStep
from pioreactor.calibrations.structured_session import utc_iso_timestamp
from pioreactor.config import config
from pioreactor.pubsub import publish
from pioreactor.utils import is_pio_job_running
from pioreactor.utils.timing import current_utc_datestamp
from pioreactor.utils.timing import current_utc_datetime
from pioreactor.whoami import get_testing_experiment_name
from pioreactor.whoami import get_unit_name
from pioreactor.whoami import is_testing_env


def to_struct(
    curve_data_: structs.CalibrationCurveData,
    voltages: list[pt.Voltage],
    od600s: list[pt.OD],
    angle,
    name: str,
    pd_channel: pt.PdChannel,
    unit: str,
) -> structs.OD600Calibration:
    data_blob = structs.OD600Calibration(
        created_at=current_utc_datetime(),
        calibrated_on_pioreactor_unit=unit,
        calibration_name=name,
        angle=angle,
        curve_data_=curve_data_,
        recorded_data={"x": od600s, "y": voltages},
        ir_led_intensity=float(config["od_reading.config"]["ir_led_intensity"]),
        pd_channel=pd_channel,
    )

    return data_blob


def _channel_angle_map_from_config(
    target_device: pt.ODCalibrationDevices,
) -> dict[pt.PdChannel, pt.PdAngle]:
    pd_channels = config["od_config.photodiode_channel"]
    ref_channels = [k for k, v in pd_channels.items() if v == REF_keyword]
    if not ref_channels:
        raise ValueError("REF required for this calibration")

    channel_angle_map: dict[pt.PdChannel, pt.PdAngle] = {}
    for channel, angle in pd_channels.items():
        if angle in (None, "", REF_keyword):
            continue
        channel_angle_map[cast(pt.PdChannel, channel)] = cast(pt.PdAngle, angle)

    if not channel_angle_map:
        raise ValueError("Need at least one non-REF PD channel for this calibration")

    if target_device != "od":
        target_angle = target_device.removeprefix("od")
        channel_angle_map = {
            channel: angle for channel, angle in channel_angle_map.items() if angle == target_angle
        }
        if not channel_angle_map:
            raise ValueError(
                f"No channels configured for angle {target_angle}°. Check [od_config.photodiode_channel]."
            )

    return channel_angle_map


def _read_voltages_from_adc(
    channel_angle_map: dict[pt.PdChannel, pt.PdAngle],
) -> dict[pt.PdChannel, pt.Voltage]:
    signal_channels = sorted(channel_angle_map.keys(), key=int)

    with start_od_reading(
        config["od_config.photodiode_channel"],
        interval=None,
        unit=get_unit_name(),
        fake_data=is_testing_env(),
        experiment=get_testing_experiment_name(),
        calibration=False,
    ) as od_reader:

        for _ in range(3):
            od_reader.record_from_adc()
            sleep(1.0)

        od_readings1 = od_reader.record_from_adc()
        sleep(3.0)
        od_readings2 = od_reader.record_from_adc()
        sleep(3.0)
        od_readings3 = od_reader.record_from_adc()
        assert od_readings1 is not None
        assert od_readings2 is not None
        assert od_readings3 is not None
        averaged_readings = average_over_od_readings(od_readings1, od_readings2, od_readings3)
        return {channel: averaged_readings.ods[channel].od for channel in signal_channels}


def _measure_standard(
    rpm: float,
    channel_angle_map: dict[pt.PdChannel, pt.PdAngle],
) -> dict[pt.PdChannel, pt.Voltage]:
    from pioreactor.background_jobs.stirring import start_stirring as stirring

    with stirring(
        target_rpm=rpm,
        unit=get_unit_name(),
        experiment=get_testing_experiment_name(),
    ) as st:
        st.block_until_rpm_is_close_to_target(abs_tolerance=120)
        sleep(1.0)
        return _read_voltages_from_adc(channel_angle_map)


def _measure_standard_for_session(
    ctx: SessionContext,
    rpm: float,
    channel_angle_map: dict[pt.PdChannel, pt.PdAngle],
) -> dict[pt.PdChannel, pt.Voltage]:
    if ctx.executor and ctx.mode == "ui":
        payload = ctx.executor(
            "od_standards_measure",
            {
                "rpm": rpm,
                "channel_angle_map": {str(k): str(v) for k, v in channel_angle_map.items()},
            },
        )
        raw = payload["voltages"]
        assert isinstance(raw, dict)
        return {cast(pt.PdChannel, channel): float(voltage) for channel, voltage in raw.items()}
    return _measure_standard(rpm, channel_angle_map)


def _default_calibration_name() -> str:
    return f"od-cal-{current_utc_datestamp()}"


def _devices_for_angles(channel_angle_map: dict[pt.PdChannel, pt.PdAngle]) -> list[str]:
    return [f"od{angle}" for angle in sorted(channel_angle_map.values(), key=int)]


def _calculate_curve_data(
    od600_values: list[float],
    voltages: list[float],
) -> structs.CalibrationCurveData:
    from pioreactor.utils.splines import spline_fit

    return spline_fit(od600_values, voltages)


def _build_standards_chart_metadata(
    od600_values: list[float],
    voltages_by_channel: dict[pt.PdChannel, list[float]],
    channel_angle_map: dict[pt.PdChannel, pt.PdAngle],
) -> dict[str, object] | None:
    series = []
    for channel, angle in sorted(channel_angle_map.items(), key=lambda item: int(item[0])):
        voltages = voltages_by_channel[channel]
        count = min(len(od600_values), len(voltages))
        if count <= 0:
            continue
        points = [{"x": float(od600_values[i]), "y": float(voltages[i])} for i in range(count)]

        series.append(
            {
                "id": str(channel),
                "label": f"{channel} ({angle}°)",
                "points": points,
                "curve": None,  # later we could add a curve to the UI
            }
        )

    if not series:
        return None

    return {
        "title": "Calibration progress",
        "x_label": "OD600",
        "y_label": "Voltage",
        "series": series,
    }


def start_standards_session(target_device: pt.ODCalibrationDevices) -> CalibrationSession:
    if config.get("od_reading.config", "ir_led_intensity") == "auto":
        raise ValueError(
            "ir_led_intensity cannot be auto for OD calibrations. Set a numeric value in config.ini."
        )

    if any(is_pio_job_running(["stirring", "od_reading"])):
        raise ValueError("Both stirring and OD reading must be off before starting.")

    channel_angle_map = _channel_angle_map_from_config(target_device)
    channel_summary = ", ".join(f"{channel}={angle}°" for channel, angle in channel_angle_map.items())
    devices_for_name_check = _devices_for_angles(channel_angle_map)

    session_id = str(uuid.uuid4())
    now = utc_iso_timestamp()
    return CalibrationSession(
        session_id=session_id,
        protocol_name=StandardsODProtocol.protocol_name,
        target_device=target_device,
        status="in_progress",
        step_id="intro",
        data={
            "channel_angle_map": to_builtins(channel_angle_map),
            "channel_summary": channel_summary,
            "devices_for_name_check": devices_for_name_check,
            "od600_values": [],
            "voltages_by_channel": {channel: [] for channel in channel_angle_map},
            "rpm": config.getfloat("stirring.config", "initial_target_rpm"),
        },
        created_at=now,
        updated_at=now,
    )


def _get_channel_angle_map(ctx: SessionContext) -> dict[pt.PdChannel, pt.PdAngle]:
    return {
        cast(pt.PdChannel, channel): cast(pt.PdAngle, angle)
        for channel, angle in ctx.data["channel_angle_map"].items()
    }


class Intro(SessionStep):
    step_id = "intro"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        return steps.info(
            "OD standards calibration",
            (
                "This routine calibrates the Pioreactor to OD600 readings using standards. "
                "You will need:\n"
                "1. A Pioreactor.\n"
                "2. A set of OD600 standards in Pioreactor vials (at least 10 mL each), with stir bars. It helps to enumerate these 1..N.\n"
                "3. One standard should be a blank (media only)."
            ),
        )

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        if ctx.inputs.has_inputs:
            return NameInput()
        return None


class NameInput(SessionStep):
    step_id = "name_input"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        default_name = ctx.data.get("default_name")
        if default_name is None:
            default_name = _default_calibration_name()
            ctx.data["default_name"] = default_name
        return steps.form(
            "Name calibration",
            "Provide a name for this calibration.",
            [fields.str("calibration_name", label="Calibration name", default=default_name)],
        )

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        default_name = ctx.data.get("default_name")
        if default_name is None:
            default_name = _default_calibration_name()
            ctx.data["default_name"] = default_name
        name = ctx.inputs.str("calibration_name", default=default_name)
        devices_for_name_check = ctx.data["devices_for_name_check"]
        existing = set()
        for device in devices_for_name_check:
            existing.update(list_of_calibrations_by_device(device))
        if name in existing:
            ctx.data["pending_name"] = name
            return NameOverwriteConfirm()
        ctx.data["calibration_name"] = name

        if len(ctx.data["channel_angle_map"]) == 1:
            return RpmInput()
        else:
            return ChannelConfirm()


class NameOverwriteConfirm(SessionStep):
    step_id = "name_overwrite_confirm"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        pending_name = ctx.data["pending_name"]
        return steps.form(
            "Name already exists",
            f"Calibration name '{pending_name}' already exists. Overwrite it?",
            [fields.bool("overwrite", label="Overwrite existing calibration?", default=False)],
        )

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        pending_name = ctx.data["pending_name"]
        overwrite = ctx.inputs.bool("overwrite", default=False)
        if overwrite:
            ctx.data["calibration_name"] = pending_name
            ctx.data.pop("pending_name", None)

            if len(ctx.data["channel_angle_map"]) == 1:
                return RpmInput()
            else:
                return ChannelConfirm()

        ctx.data.pop("pending_name", None)
        return NameInput()


class ChannelConfirm(SessionStep):
    step_id = "channel_confirm"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        channel_summary = ctx.data["channel_summary"]
        channel_lines = channel_summary.split(", ") if channel_summary else []
        if channel_lines:
            message = "Using channels:\n" + "\n".join(channel_lines)
        else:
            message = "Using channels."
        return steps.info("Confirm channels", message)

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        if ctx.inputs.has_inputs:
            return RpmInput()
        return None


class RpmInput(SessionStep):
    step_id = "rpm_input"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        default_rpm = ctx.data["rpm"]
        return steps.form(
            "Stirring setup",
            "Optional: set stirring RPM used during readings.",
            [fields.float("rpm", label="Stirring RPM", default=default_rpm, minimum=0, maximum=10000)],
        )

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        rpm = ctx.inputs.float("rpm")
        ctx.data["rpm"] = rpm
        return PlaceStandard()


class PlaceStandard(SessionStep):
    step_id = "place_standard"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        standard_index = int(ctx.data.get("standard_index", 1))
        step = steps.info(
            f"Place standard {standard_index}",
            f"Place standard vial {standard_index} (non-blank) with a stir bar into the Pioreactor.",
        )
        step.metadata = {
            "image": {
                "src": "/static/svgs/place-standard-arrow-pioreactor.svg",
                "alt": f"Place standard vial {standard_index} (non-blank) with a stir bar into the Pioreactor.",
                "caption": f"Place standard vial {standard_index} (non-blank) with a stir bar into the Pioreactor.",
            }
        }
        return step

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        if ctx.inputs.has_inputs:
            return MeasureStandard()
        return None


class MeasureStandard(SessionStep):
    step_id = "measure_standard"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        n_frames = 12
        standard_index = int(ctx.data.get("standard_index", 1))
        step = steps.form(
            f"Record standard {standard_index}",
            f"Enter the OD600 measurement for standard vial {standard_index}. Then, press Continue to start stirring and take an OD reading for this standard.",
            [fields.float("od600_value", label="OD600 value", minimum=0)],
        )
        step.metadata = {
            "loading_images": [
                {
                    "src": f"/static/svgs/od-fusion-stir-{i:02d}.svg",
                    "alt": "Stirring standard vial.",
                    "caption": "One moment please...",
                }
                for i in range(1, n_frames + 1, 2)
            ]
        }
        od600_values = ctx.data.get("od600_values", [])
        if isinstance(od600_values, list) and od600_values:
            rows = []
            for index, value in enumerate(od600_values, start=1):
                if isinstance(value, (int, float)):
                    rows.append([index, value])
            if rows:
                step.metadata = {
                    "table": {
                        "title": "Standards recorded so far",
                        "columns": ["#", "OD600"],
                        "rows": rows,
                    },
                    **step.metadata,
                }
        return step

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        channel_angle_map = _get_channel_angle_map(ctx)
        od600_value = ctx.inputs.float("od600_value")
        voltages = _measure_standard_for_session(ctx, ctx.data["rpm"], channel_angle_map)
        ctx.data.setdefault("standard_index", 1)
        ctx.data["od600_values"].append(od600_value)
        for channel, voltage in voltages.items():
            ctx.data["voltages_by_channel"][channel].append(voltage)
        return AnotherStandard()


class AnotherStandard(SessionStep):
    step_id = "another_standard"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        standard_index = int(ctx.data.get("standard_index", 1))
        next_standard_index = standard_index + 1
        step = steps.form(
            "Next standard",
            (
                f"Record standard {next_standard_index}, move on to the blank, "
                "or redo the last measurement?"
            ),
            [
                fields.choice(
                    "next_action",
                    ["record another standard", "continue to blank (media only)"],
                    label="Next action",
                    default="record another standard",
                )
            ],
        )
        step.metadata = {
            "actions": [
                {"label": "Redo last measurement", "inputs": {"action": "redo_last"}},
            ]
        }
        chart = _build_standards_chart_metadata(
            ctx.data["od600_values"],
            ctx.data["voltages_by_channel"],
            _get_channel_angle_map(ctx),
        )
        if chart:
            step.metadata = {**step.metadata, "chart": chart} if step.metadata else {"chart": chart}
        return step

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        action = ctx.inputs.raw.get("action")  # type: ignore
        if action == "redo_last":
            ctx.data["od600_values"].pop()
            for channel in ctx.data["voltages_by_channel"]:
                ctx.data["voltages_by_channel"][channel].pop()
            return PlaceStandard()
        next_action = ctx.inputs.choice(
            "next_action",
            ["record another standard", "continue to blank (media only)"],
            default="record another standard",
        )
        if next_action == "record another standard":
            ctx.data["standard_index"] = int(ctx.data.get("standard_index", 1)) + 1
            return PlaceStandard()
        return PlaceBlank()


class PlaceBlank(SessionStep):
    step_id = "place_blank"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        step = steps.info(
            "Place blank",
            "Place the blank (media only) standard vial into the Pioreactor.",
        )
        step.metadata = {
            "image": {
                "src": "/static/svgs/place-blank-arrow-pioreactor.svg",
                "alt": "Place the blank (media only) standard vial into the Pioreactor.",
                "caption": "Place the blank (media only) standard vial into the Pioreactor.",
            }
        }

        return step

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        if ctx.inputs.has_inputs:
            return MeasureBlank()
        return None


class MeasureBlank(SessionStep):
    step_id = "measure_blank"

    def render(self, ctx: SessionContext) -> CalibrationStep:
        n_frames = 12
        step = steps.form(
            "Record blank",
            "Enter the OD600 measurement for the blank.",
            [fields.float("od600_blank", label="Blank OD600 value", minimum=0)],
        )
        step.metadata = {
            "loading_images": [
                {
                    "src": f"/static/svgs/od-fusion-stir-{i:02d}.svg",
                    "alt": "Stirring standard vial.",
                    "caption": "One moment please...",
                }
                for i in range(1, n_frames + 1, 2)
            ]
        }
        od600_values = ctx.data.get("od600_values", [])
        if isinstance(od600_values, list) and od600_values:
            rows = []
            for index, value in enumerate(od600_values, start=1):
                if isinstance(value, (int, float)):
                    rows.append([index, value])
            if rows:
                step.metadata = {
                    "table": {
                        "title": "Standards recorded so far",
                        "columns": ["#", "OD600"],
                        "rows": rows,
                    },
                    **step.metadata,
                }
        chart = _build_standards_chart_metadata(
            ctx.data["od600_values"],
            ctx.data["voltages_by_channel"],
            _get_channel_angle_map(ctx),
        )
        if chart:
            step.metadata = {**step.metadata, "chart": chart} if step.metadata else {"chart": chart}
        return step

    def advance(self, ctx: SessionContext) -> SessionStep | None:
        channel_angle_map = _get_channel_angle_map(ctx)
        od600_blank = ctx.inputs.float("od600_blank")
        voltages = _measure_standard_for_session(ctx, ctx.data["rpm"], channel_angle_map)
        ctx.data["od600_values"].append(od600_blank)
        for channel, voltage in voltages.items():
            ctx.data["voltages_by_channel"][channel].append(voltage)

        calibration_links: list[dict[str, str | None]] = []
        for pd_channel, angle in sorted(channel_angle_map.items(), key=lambda item: int(item[0])):
            voltages_list = ctx.data["voltages_by_channel"][pd_channel]
            od600_values = ctx.data["od600_values"]
            curve_data_ = _calculate_curve_data(od600_values, voltages_list)
            cal = to_struct(
                curve_data_,
                voltages_list,
                od600_values,
                angle,
                ctx.data["calibration_name"],
                pd_channel,
                get_unit_name(),
            )
            device = f"od{angle}"
            calibration_links.append(ctx.store_calibration(cal, device))

        ctx.complete({"calibrations": calibration_links})
        return CalibrationComplete()


_OD_STANDARDS_STEPS: StepRegistry = {
    Intro.step_id: Intro,
    NameInput.step_id: NameInput,
    NameOverwriteConfirm.step_id: NameOverwriteConfirm,
    ChannelConfirm.step_id: ChannelConfirm,
    RpmInput.step_id: RpmInput,
    PlaceStandard.step_id: PlaceStandard,
    MeasureStandard.step_id: MeasureStandard,
    AnotherStandard.step_id: AnotherStandard,
    PlaceBlank.step_id: PlaceBlank,
    MeasureBlank.step_id: MeasureBlank,
}


def get_valid_od_devices_for_this_unit() -> list[pt.ODCalibrationDevices]:

    pd_channels = config["od_config.photodiode_channel"]
    valid_devices: list[pt.ODCalibrationDevices] = []

    for _, angle in pd_channels.items():
        if angle in (None, "", REF_keyword):
            continue
        device = f"od{angle}"
        if device in pt.OD_DEVICES and device not in valid_devices:
            valid_devices.append(cast(pt.ODCalibrationDevices, device))

    if len(valid_devices) >= 2:
        valid_devices.append(cast(pt.ODCalibrationDevices, "od"))

    return valid_devices


class StandardsODProtocol(CalibrationProtocol[pt.ODCalibrationDevices]):
    target_device = get_valid_od_devices_for_this_unit()
    protocol_name = "standards"
    title = "OD600 calibration using standards"
    description = "Calibrate {device} channels using a series of OD600 standards and a blank."
    requirements = (
        "OD600 standards (including a blank)",
        "Vials",
        "Stir bars",
    )
    step_registry: ClassVar[StepRegistry] = _OD_STANDARDS_STEPS

    @classmethod
    def start_session(cls, target_device: pt.ODCalibrationDevices) -> CalibrationSession:
        return start_standards_session(target_device)

    @classmethod
    def on_session_abort(
        cls,
        _session: CalibrationSession,
        executor=None,
    ) -> None:
        experiment = get_testing_experiment_name()
        unit = get_unit_name()
        publish(f"pioreactor/{unit}/{experiment}/od_reading/$state/set", b"disconnected", qos=1)
        publish(f"pioreactor/{unit}/{experiment}/stirring/$state/set", b"disconnected", qos=1)

    def run(  # type: ignore
        self, target_device: pt.ODCalibrationDevices, *args, **kwargs
    ) -> structs.OD600Calibration | list[structs.OD600Calibration]:
        session = start_standards_session(target_device)
        return run_session_in_cli(_OD_STANDARDS_STEPS, session)
