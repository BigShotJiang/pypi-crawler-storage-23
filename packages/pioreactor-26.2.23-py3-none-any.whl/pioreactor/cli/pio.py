# -*- coding: utf-8 -*-
import os
import re
import subprocess
from os import geteuid
from pathlib import Path
from shlex import quote
from typing import Any
from typing import Optional

import click
from pioreactor import exc
from pioreactor import whoami
from pioreactor.cli.lazy_group import LazyGroup
from pioreactor.mureq import get

lazy_subcommands = {
    "run": "pioreactor.cli.run.run",
    "plugins": "pioreactor.cli.plugins.plugins",
    "calibrations": "pioreactor.cli.calibrations.calibration",
    "estimators": "pioreactor.cli.estimators.estimators",
}

if whoami.am_I_leader():
    # add in ability to control workers
    lazy_subcommands["workers"] = "pioreactor.cli.workers.workers"
    # experiment management is leader-only
    lazy_subcommands["experiments"] = "pioreactor.cli.experiments.experiments"


GIT_SHA_PATTERN = re.compile(r"^[0-9a-fA-F]{4,40}$")


def validate_git_sha(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None

    cleaned_value = value.strip()
    if not GIT_SHA_PATTERN.fullmatch(cleaned_value):
        raise click.BadParameter("Expected a commit SHA (4 to 40 hexadecimal characters).")

    return cleaned_value.lower()


def validate_git_sha_option(
    _ctx: click.Context, _param: click.Parameter, value: Optional[str]
) -> Optional[str]:
    return validate_git_sha(value)


def get_update_app_commands(
    branch: Optional[str],
    repo: str,
    source: Optional[str],
    version: Optional[str],
    sha: Optional[str] = None,
    no_deps: bool = False,
    defer_web_restart: bool = False,
) -> tuple[list[tuple[str, float]], str]:
    """Build the commands_and_priority list and return the installed version."""
    import tempfile
    import re
    from msgspec.json import decode as loads
    from pioreactor.config import config
    from pioreactor.mureq import get
    from pioreactor.mureq import HTTPException
    from pioreactor.utils.networking import is_using_local_access_point

    commands_and_priority: list[tuple[str, float]] = []
    sha = validate_git_sha(sha)
    # source overrides branch/version/sha
    if source is not None:
        source = quote(source)
        if re.search(r"release_\d{0,2}\.\d{0,2}\.\d{0,2}\w{0,6}\.zip$", source):
            # provided a release archive
            version_installed = re.search(r"release_(.*).zip$", source).groups()[0]  # type: ignore
            tmp_dir = tempfile.gettempdir()
            tmp_rls_dir = f"{tmp_dir}/release_{version_installed}"
            commands_and_priority.extend(
                [
                    (f"sudo rm -rf {tmp_rls_dir}", -99),
                    (f"unzip -o {source} -d {tmp_rls_dir}", 0),
                    (
                        f"unzip -o {tmp_rls_dir}/wheels_{version_installed}.zip -d {tmp_rls_dir}/wheels",
                        1,
                    ),  # noqa: E501
                    (f"sudo bash {tmp_rls_dir}/pre_update.sh", 2),
                    (f"sudo bash {tmp_rls_dir}/update.sh", 4),
                    (f"sudo bash {tmp_rls_dir}/post_update.sh", 20),
                    (f"sudo rm -rf {tmp_rls_dir}", 98),
                ]
            )
            if not defer_web_restart:
                commands_and_priority.append(
                    ("sudo systemctl restart pioreactor-web.target", 99)
                )  # restart lighttpd (flask api) and huey.
            if whoami.am_I_leader():
                commands_and_priority.extend(
                    [
                        (
                            f"/opt/pioreactor/venv/bin/pip install --no-index --find-links={tmp_rls_dir}/wheels/ {tmp_rls_dir}/pioreactor-{version_installed}-py3-none-any.whl[leader,worker]",
                            3,
                        ),  # noqa: E501
                        (
                            f'sudo sqlite3 {config.get("storage","database")} < {tmp_rls_dir}/update.sql || :',
                            10,
                        ),  # noqa: E501
                    ]
                )
            else:
                commands_and_priority.append(
                    (
                        f"/opt/pioreactor/venv/bin/pip install --no-index --find-links={tmp_rls_dir}/wheels/ {tmp_rls_dir}/pioreactor-{version_installed}-py3-none-any.whl[worker]",
                        3,
                    )  # noqa: E501
                )
        elif source.endswith(".whl"):
            version_installed = source
            commands_and_priority.append(
                (f"/opt/pioreactor/venv/bin/pip install --force-reinstall --no-index {source}", 1)
            )
            if not defer_web_restart:
                commands_and_priority.append(("sudo systemctl restart pioreactor-web.target", 30))
        else:
            click.echo("Not a valid source file. Should be either a whl or release archive.")
            raise click.Abort()
    elif branch is not None or sha is not None:
        git_ref = branch if branch is not None else sha
        assert git_ref is not None
        cleaned_ref = quote(git_ref)
        cleaned_repo = quote(repo)
        version_installed = cleaned_ref
        no_deps_flag = "--no-deps " if no_deps else ""
        commands_and_priority.append(
            (
                f"/opt/pioreactor/venv/bin/pip install --force-reinstall {no_deps_flag}--index-url https://piwheels.org/simple --extra-index-url https://pypi.org/simple "
                f'"pioreactor[leader_worker] @ git+https://github.com/{cleaned_repo}.git@{cleaned_ref}#subdirectory=core"',
                1,
            )  # noqa: E501
        )
        if not defer_web_restart:
            commands_and_priority.append(("sudo systemctl restart pioreactor-web.target", 30))  # noqa: E501

    else:
        try:
            tag = get_tag_to_install(repo, version)
        except HTTPException:
            raise HTTPException(
                f"Unable to retrieve information over internet. Is the Pioreactor connected to the internet? "
                f"Local access point is {'active' if is_using_local_access_point() else 'inactive'}."
            )
        response = get(f"https://api.github.com/repos/{repo}/releases/{tag}")
        if not response.ok:
            raise HTTPException(f"Version {version} not found on GitHub")
        release_metadata = loads(response.body)
        version_installed = release_metadata["tag_name"]
        found_whl = False
        tmp_dir = tempfile.gettempdir()
        tmp_rls_dir = f"{tmp_dir}/release_{version_installed}"
        commands_and_priority.append((f"mkdir {tmp_rls_dir}", -9))
        commands_and_priority.append((f"rm -rf {tmp_rls_dir}", -10))
        for asset in release_metadata["assets"]:
            url = asset["browser_download_url"]
            name = asset["name"]
            if name == "pre_update.sh":
                commands_and_priority.extend(
                    [
                        (f"wget -O {tmp_rls_dir}/pre_update.sh {url}", 0),
                        (f"sudo bash {tmp_rls_dir}/pre_update.sh", 1),
                    ]
                )
            elif name.startswith("pioreactor") and name.endswith(".whl"):
                found_whl = True
                assert (
                    version_installed in url
                ), f"pip installing {url} but doesn't match version {version_installed}"
                if whoami.am_I_leader():
                    commands_and_priority.append(
                        (f'/opt/pioreactor/venv/bin/pip install "pioreactor[worker,leader] @ {url}"', 2)
                    )
                else:
                    commands_and_priority.append(
                        (f'/opt/pioreactor/venv/bin/pip install "pioreactor[worker] @ {url}"', 2)
                    )
            elif name == "update.sh":
                commands_and_priority.extend(
                    [
                        (f"wget -O {tmp_rls_dir}/update.sh {url}", 3),
                        (f"sudo bash {tmp_rls_dir}/update.sh", 4),
                    ]
                )
            elif name == "update.sql" and whoami.am_I_leader():
                commands_and_priority.extend(
                    [
                        (f"wget -O {tmp_rls_dir}/update.sql {url}", 5),
                        (
                            f'sudo sqlite3 {config.get("storage","database")} < {tmp_rls_dir}/update.sql || :',
                            6,
                        ),
                    ]
                )
            elif name == "post_update.sh":
                commands_and_priority.extend(
                    [
                        (f"wget -O {tmp_rls_dir}/post_update.sh {url}", 99),
                        (f"sudo bash {tmp_rls_dir}/post_update.sh", 100),
                    ]
                )
            else:
                commands_and_priority.append((f"wget -O {tmp_rls_dir}/{name} {url}", -1))
        if not found_whl:
            raise FileNotFoundError(f"Could not find a whl in assets of {repo} release {tag}")
    return commands_and_priority, version_installed


@click.group(
    cls=LazyGroup,
    lazy_subcommands=lazy_subcommands,
    invoke_without_command=True,
)
@click.option(
    "--version", "show_version", is_flag=True, help="print the Pioreactor software version and exit"
)
@click.pass_context
def pio(ctx, show_version: bool) -> None:
    """
    Execute commands on this Pioreactor.

    Configuration available: /home/pioreactor/.pioreactor/config.ini

    See full documentation: https://docs.pioreactor.com/user-guide/cli

    Report errors or feedback: https://github.com/Pioreactor/pioreactor/issues
    """

    if show_version:
        ctx.invoke(version)
        ctx.exit()

    if not whoami.is_testing_env():
        # this check could go somewhere else. TODO This check won't execute if calling pioreactor from a script.
        if not whoami.check_firstboot_successful():
            raise SystemError(
                "/usr/local/bin/firstboot.sh found on disk. firstboot.sh likely failed. Try looking for errors in `sudo systemctl status firstboot.service`."
            )

        # running as root can cause problems as files created by the software are owned by root
        if geteuid() == 0:
            raise SystemError("Don't run as root!")

    # https://click.palletsprojects.com/en/8.1.x/commands/#group-invocation-without-command
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _resolve_config_paths_like_runtime() -> tuple[str, str]:
    """
    Resolve global and local config paths with runtime-like precedence.
    """
    from pioreactor.whoami import is_testing_env

    if os.environ.get("GLOBAL_CONFIG") is not None:
        global_config_path = os.environ["GLOBAL_CONFIG"]
    elif os.environ.get("DOT_PIOREACTOR") is not None:
        global_config_path = os.environ["DOT_PIOREACTOR"] + "/config.ini"
    else:
        if is_testing_env():
            global_config_path = "./.pioreactor/config.ini"
        else:
            global_config_path = "/home/pioreactor/.pioreactor/config.ini"

    if os.environ.get("LOCAL_CONFIG") is not None:
        local_config_path = os.environ["LOCAL_CONFIG"]
    elif os.environ.get("DOT_PIOREACTOR") is not None:
        local_config_path = os.environ["DOT_PIOREACTOR"] + "/unit_config.ini"
    else:
        if is_testing_env():
            local_config_path = "./.pioreactor/unit_config.ini"
        else:
            local_config_path = "/home/pioreactor/.pioreactor/unit_config.ini"

    return global_config_path, local_config_path


def _load_config_file(path: str):
    from pioreactor.config import ConfigParserMod

    parser = ConfigParserMod(strict=False)
    config_path = Path(path)
    if config_path.is_file():
        parser.read([str(config_path)])
    return parser


def _format_config_key_value(option_name: str, option_value: str | None) -> str:
    if option_value is None:
        return option_name
    return f"{option_name}={option_value}"


@pio.group(name="config", short_help="inspect effective configuration")
def config_group() -> None:
    """Show effective configuration values."""
    pass


@config_group.command(name="show", short_help="show the effective merged config")
@click.option("--section", "section_name", type=click.STRING, help="show only one section")
@click.option("--key", "key_name", type=click.STRING, help="show only one key (requires --section)")
@click.option("--json", "json_output", is_flag=True, help="output as json")
@click.option("--with-source", is_flag=True, help="include source: global/local/derived")
def show_config(
    section_name: str | None,
    key_name: str | None,
    json_output: bool,
    with_source: bool,
) -> None:
    """
    Print the merged config (global + local + derived sections).
    """
    from msgspec.json import encode as dumps
    from pioreactor.config import get_config

    if key_name is not None and section_name is None:
        raise click.BadParameter("--key requires --section.", param_hint="--key")

    global_config_path, local_config_path = _resolve_config_paths_like_runtime()
    global_config = _load_config_file(global_config_path)
    local_config = _load_config_file(local_config_path)

    def value_source(section: str, key: str) -> str:
        if local_config.has_section(section) and local_config.has_option(section, key):
            return "local"
        if global_config.has_section(section) and global_config.has_option(section, key):
            return "global"
        return "derived"

    effective_config = get_config()
    payload: dict[str, dict[str, str | None]] = {}
    for section in sorted(effective_config.sections()):
        payload[section] = {
            option_name: option_value
            for option_name, option_value in sorted(effective_config[section].items())
        }

    if section_name is not None:
        if section_name not in payload:
            raise click.ClickException(f"Section '{section_name}' not found in effective config.")
        payload = {section_name: payload[section_name]}

    if key_name is not None:
        assert section_name is not None
        if key_name not in payload[section_name]:
            raise click.ClickException(f"Key '{key_name}' not found in section '{section_name}'.")
        payload = {section_name: {key_name: payload[section_name][key_name]}}

    if json_output:
        if with_source:
            payload_with_source = {
                section: {
                    key: {"value": value, "source": value_source(section, key)}
                    for key, value in options.items()
                }
                for section, options in payload.items()
            }
            click.echo(dumps(payload_with_source).decode())
            return

        click.echo(dumps(payload).decode())
        return

    sections = list(payload.items())
    for section_index, (section, options) in enumerate(sections):
        click.echo(f"[{section}]")
        for key, value in options.items():
            line = _format_config_key_value(key, value)
            if with_source:
                line = f"{line}  # source={value_source(section, key)}"
            click.echo(line)

        if section_index < len(sections) - 1:
            click.echo("")


@pio.command(name="logs", short_help="show recent logs")
@click.option("-n", default=100, type=int)
@click.option(
    "-f",
    is_flag=True,
    help="follow the logs, like tail -f",
)
def logs(n: int, f: bool) -> None:
    """
    Tail & stream the logs from this unit to the terminal. CTRL-C to exit.
    """
    from pioreactor.config import config

    log_file = config.get("logging", "log_file", fallback="/var/log/pioreactor.log")
    ui_log_file = config.get("logging", "ui_log_file", fallback="/var/log/pioreactor.log")

    if whoami.am_I_leader():
        log_files = list(set([log_file, ui_log_file]))  # deduping
    else:
        log_files = [log_file]

    with subprocess.Popen(
        ["tail", "-qn", str(n)] + (["-f"] if f else []) + log_files,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    ) as process:
        assert process.stdout is not None
        for line in process.stdout:
            click.echo(line.decode("utf8").rstrip("\n"))


@pio.command(name="log", short_help="append a log message from the CLI")
@click.option("-m", "--message", required=True, type=str, help="the message to append to the log")
@click.option(
    "-l",
    "--level",
    default="debug",
    type=click.Choice(["debug", "info", "notice", "warning", "error", "critical"], case_sensitive=False),
    help="the log level to use",
)
@click.option(
    "-n",
    "--name",
    default="CLI",
    type=str,
    help="logger name to display in the log record",
)
@click.option("--local-only", is_flag=True, help="don't send to MQTT; write only to local disk")
def log(message: str, level: str, name: str, local_only: bool):
    """
    Append a single log entry from the CLI.

    \b
    Examples:
      pio log -m "Calibration started" -l info
      pio log -m "Skipping pump test" --local-only
    """
    try:
        from pioreactor.logging import create_logger

        logger = create_logger(
            name,
            unit=whoami.get_unit_name(),
            experiment=whoami.UNIVERSAL_EXPERIMENT,
            to_mqtt=not local_only,
        )
        getattr(logger, level)(message)

    except Exception as e:
        # don't let a logging error bring down a script...
        print(e)
        raise click.Abort()


@pio.command(name="blink", short_help="blink LED")
def blink() -> None:
    """
    monitor job is required to be running.
    """
    from pioreactor.pubsub import post_into_leader

    post_into_leader(f"/api/workers/{whoami.get_unit_name()}/blink")


@pio.command(name="kill", short_help="kill job(s)")
@click.option("--job-name", type=click.STRING)
@click.option("--experiment", type=click.STRING)
@click.option("--job-source", type=click.STRING)
@click.option("--job-id", type=click.INT)
@click.option("--all-jobs", is_flag=True, help="kill all Pioreactor jobs running")
def kill(
    job_name: str | None, experiment: str | None, job_source: str | None, job_id: int | None, all_jobs: bool
) -> None:
    """
    stop job(s).
    """
    from pioreactor.utils.job_manager import JobManager

    if not (job_name or experiment or job_source or all_jobs or job_id):
        raise click.Abort("Provide an option to kill. See --help")

    with JobManager() as jm:
        count = jm.kill_jobs(
            all_jobs=all_jobs, job_name=job_name, experiment=experiment, job_source=job_source, job_id=job_id
        )
    click.echo(f"Killed {count} job{'s' if count != 1 else ''}.")


@pio.group(name="jobs", short_help="job-related commands")
def jobs():
    """Interact with Pioreactor jobs."""
    pass


def _format_job_history_line(
    job_id: int,
    job_name: str,
    experiment: str,
    job_source: str | None,
    unit: str,
    started_at: str,
    ended_at: str | None,
) -> str:
    job_source_display = job_source or "unknown"
    ended_at_display = _format_timestamp_to_seconds(ended_at) or "still running"
    job_id_label = click.style(f"[job_id={job_id}]", fg="cyan")
    job_name_label = click.style(job_name, fg="green", bold=True)
    ended_at_label = (
        click.style(ended_at_display, fg="yellow", bold=True) if ended_at is None else ended_at_display
    )

    return (
        f"{job_id_label} {job_name_label} "
        f"experiment={experiment}, source={job_source_display}, "
        f"started_at={_format_timestamp_to_seconds(started_at)}, ended_at={ended_at_label}"
    )


def _show_job_history(running_only: bool = False) -> None:
    from pioreactor.utils.job_manager import JobManager

    with JobManager() as jm:
        jobs = jm.list_job_history(running_only=running_only)

    if not jobs:
        click.echo("No jobs recorded.")
        return

    for job in jobs:
        click.echo(_format_job_history_line(*job))


@jobs.group(name="list", short_help="list jobs current and previous", invoke_without_command=True)
@click.pass_context
def job_list(ctx: click.Context) -> None:
    if ctx.invoked_subcommand is None:
        _show_job_history()


@job_list.command(name="running", short_help="show status of running job(s)")
def job_list_running() -> None:
    _show_job_history(running_only=True)


def _format_timestamp_to_seconds(timestamp: str | None) -> str:

    if timestamp is None:
        return ""

    try:
        from pioreactor.utils.timing import to_datetime

        dt = to_datetime(timestamp)
    except ValueError:
        return timestamp

    return dt.replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%S")


@jobs.command(name="info", short_help="show details for a job")
@click.option("--job-id", type=click.INT)
@click.option("--job-name", type=click.STRING)
def job_info(job_id: int | None, job_name: str | None) -> None:

    if job_id is None and job_name is None:
        click.echo("Provide --job-id or --job-name.")
        return

    if job_id is None and job_name is not None:
        from pioreactor.utils import get_running_pio_job_id

        job_id = get_running_pio_job_id(job_name)
        if job_id is None:
            click.echo(f"No running job found with name {job_name}.")
            return

    assert job_id is not None

    from pioreactor.utils.job_manager import JobManager

    with JobManager() as jm:
        job = jm.get_job_info(job_id)
        settings = jm.list_job_settings(job_id) if job else []

    if job is None:
        click.echo(f"No job found with job_id={job_id}.")
        return

    (
        found_job_id,
        job_name,
        experiment,
        job_source,
        unit,
        started_at,
        ended_at,
        is_running,
        leader,
        pid,
        is_long_running_job,
    ) = job

    click.echo(
        _format_job_history_line(found_job_id, job_name, experiment, job_source, unit, started_at, ended_at)
    )

    status_label = (
        click.style("running", fg="green", bold=True) if is_running else click.style("stopped", fg="red")
    )
    click.echo(f"status={status_label}")

    if not settings:
        return

    click.echo("published settings:")
    for setting, value, created_at, updated_at in settings:
        setting_label = click.style(setting, fg="cyan")
        created_at_display = _format_timestamp_to_seconds(created_at)
        updated_at_display = _format_timestamp_to_seconds(updated_at)

        def _stringify(val: Any) -> str:
            if val is None:
                return "None"
            if isinstance(val, bytes):
                try:
                    return val.decode()
                except Exception:
                    return str(val)
            return str(val)

        click.echo(
            f"  {setting_label}={_stringify(value)} "
            f"(created_at={created_at_display}, updated_at={updated_at_display})"
        )


@jobs.command(name="purge", short_help="remove a job record")
@click.option("--job-id", type=click.INT)
@click.option("--job-name", type=click.STRING)
def job_purge(job_id: int | None, job_name: str | None) -> None:
    if job_id is None and job_name is None:
        click.echo("Provide --job-id or --job-name.")
        return

    if job_id is None and job_name is not None:
        from pioreactor.utils import get_running_pio_job_id

        job_id = get_running_pio_job_id(job_name)
        if job_id is None:
            click.echo(f"No running job found with name {job_name}.")
            return

    assert job_id is not None

    from pioreactor.utils.job_manager import JobManager

    with JobManager() as jm:
        job = jm.get_job_info(job_id)

        if job is None:
            click.echo(f"No job found with job_id={job_id}.")
            return

        removed = jm.remove_job(job_id)

    if removed:
        click.echo(f"Removed job record {job_id}.")
    else:
        click.echo(f"Failed to remove job record {job_id}.")


@pio.command(name="version", short_help="print the Pioreactor software version")
@click.option("--verbose", "-v", is_flag=True, help="show more system information")
def version(verbose: bool) -> None:
    from pioreactor.version import tuple_to_text
    from pioreactor.version import software_version_info

    if verbose:
        import platform
        from pioreactor.version import hardware_version_info
        from pioreactor.version import serial_number
        from pioreactor.version import get_firmware_version
        from pioreactor.version import rpi_version_info
        from pioreactor.whoami import get_pioreactor_model

        try:
            model = get_pioreactor_model().display_name
        except exc.NoModelAssignedError:
            model = ""

        click.echo(f"Pioreactor app:         {tuple_to_text(software_version_info)}")

        if whoami.am_I_a_worker():
            click.echo(f"Pioreactor HAT:         {tuple_to_text(hardware_version_info)}")
            click.echo(f"Pioreactor firmware:    {tuple_to_text(get_firmware_version())}")
            click.echo(f"Bioreactor model name:  {model}")
            click.echo(f"HAT serial number:      {serial_number}")

        click.echo(f"Operating system:       {platform.platform()}")
        click.echo(f"Raspberry Pi:           {rpi_version_info}")
        click.echo(f"Image version:          {whoami.get_image_git_hash()}")

    else:
        click.echo(tuple_to_text(software_version_info))


@pio.command(name="status", short_help="show local system status")
def status() -> None:
    """
    Show a quick, local-only status report for this unit.
    """
    import shutil
    import socket
    import sqlite3
    import subprocess
    from pathlib import Path

    from pioreactor import mureq
    from pioreactor.config import config
    from pioreactor.pubsub import create_webserver_path
    from pioreactor.utils.job_manager import JobManager
    from pioreactor.version import get_firmware_version
    from pioreactor.version import software_version_info
    from pioreactor.version import tuple_to_text

    checks: list[tuple[str, str, str]] = []

    def add_check(name: str, status: str, details: str) -> None:
        checks.append((name, status, details))

    unit = whoami.get_unit_name()
    role = "leader" if whoami.am_I_leader() else "worker"
    experiment = whoami.get_assigned_experiment_name(unit)
    add_check("identity", "OK", f"unit={unit} role={role} experiment={experiment}")

    version_details = f"app={tuple_to_text(software_version_info)}"
    version_status = "OK"
    if whoami.am_I_a_worker():
        try:
            version_details += f" firmware={tuple_to_text(get_firmware_version())}"
        except Exception:
            version_details += " firmware=unknown"
            version_status = "WARN"
    add_check("version", version_status, version_details)

    broker_host = config.get("mqtt", "broker_address", fallback="localhost").split(";")[0].strip()
    broker_port = config.getint("mqtt", "broker_port", fallback=1883)
    try:
        with socket.create_connection((broker_host, broker_port), timeout=2):
            add_check("connectivity:mqtt", "OK", f"{broker_host}:{broker_port}")
    except OSError as exc:
        add_check("connectivity:mqtt", "FAIL", f"{broker_host}:{broker_port} ({exc})")

    webserver_url = create_webserver_path("localhost", "unit_api/health")
    try:
        response = mureq.get(webserver_url, timeout=2)
        if response.ok:
            add_check("services:web", "OK", webserver_url)
        else:
            add_check("services:web", "FAIL", f"{webserver_url} (HTTP {response.status_code})")
    except Exception as exc:
        add_check("services:web", "FAIL", f"{webserver_url} ({exc})")

    systemctl_path = shutil.which("systemctl")
    if systemctl_path is None:
        add_check("services:huey", "WARN", "systemctl not available")
    else:
        result = subprocess.run(
            [systemctl_path, "is-active", "huey.service"],
            capture_output=True,
            text=True,
        )
        raw_status = (result.stdout or result.stderr).strip()
        huey_status = "OK" if result.returncode == 0 and raw_status == "active" else "FAIL"
        add_check("services:huey", huey_status, raw_status or "unknown")

    with JobManager() as jm:
        running_jobs = jm.list_jobs(all_jobs=True)
    add_check("jobs:running", "OK", f"count={len(running_jobs)}")

    log_file = Path(config.get("logging", "log_file", fallback="/var/log/pioreactor.log"))
    log_status = "OK" if log_file.exists() else "WARN"
    log_details = str(log_file) if log_file.exists() else f"missing: {log_file}"
    add_check("storage:logs", log_status, log_details)

    db_path = Path(config.get("storage", "database"))
    if whoami.am_I_leader():
        db_status = "OK"
        db_details = [str(db_path)]
        try:
            conn = sqlite3.connect(str(db_path))
            conn.execute("select 1;")
            conn.close()
        except Exception as exc:
            add_check("storage:db", "FAIL", f"{db_path} ({exc})")
        else:
            shm_path = Path(f"{db_path}-shm")
            wal_path = Path(f"{db_path}-wal")
            file_checks = {
                "db": db_path,
                "shm": shm_path,
                "wal": wal_path,
            }

            try:
                import grp
                import pwd

                expected_uid = pwd.getpwnam("pioreactor").pw_uid
                expected_gid = grp.getgrnam("www-data").gr_gid
                expected_owner = "pioreactor:www-data"
            except KeyError:
                expected_uid = None
                expected_gid = None
                expected_owner = "pioreactor:www-data (missing on this system)"

            for label, path in file_checks.items():
                if not path.exists():
                    db_status = "WARN"
                    db_details.append(f"{label}=missing")
                    continue

                if expected_uid is not None and expected_gid is not None:
                    stat_result = path.stat()
                    if stat_result.st_uid != expected_uid or stat_result.st_gid != expected_gid:
                        db_status = "WARN"
                        db_details.append(f"{label}=owner!= {expected_owner}")

            add_check("storage:db", db_status, " ".join(db_details))

    disk_root = db_path.parent
    if disk_root.exists():
        free_bytes = shutil.disk_usage(disk_root).free
        free_gb = free_bytes / (1024**3)
        disk_status = "WARN" if free_gb < 1.0 else "OK"
        add_check("storage:disk", disk_status, f"free={free_gb:.1f}GB path={disk_root}")

    name_width = 22
    status_width = 7
    click.echo(f"{'Check':{name_width}s} {'Status':{status_width}s} Details")
    for name, status, details in checks:
        padded_status = f"{status:{status_width}s}"
        if status == "OK":
            status_display = click.style(padded_status, fg="green", bold=True)
        elif status == "WARN":
            status_display = click.style(padded_status, fg="yellow", bold=True)
        elif status == "FAIL":
            status_display = click.style(padded_status, fg="red", bold=True)
        else:
            status_display = padded_status
        click.echo(f"{name:{name_width}s} {status_display} {details}")


@pio.group(short_help="manage the local caches")
def cache():
    """Inspect or clear local caches."""
    pass


@cache.command(name="view", short_help="print out the contents of a cache")
@click.argument("cache", metavar="CACHE")
@click.argument("key", metavar="KEY", required=False)
def view_cache(cache: str, key: str | None) -> None:
    """
    Print key/value pairs for a cache.

    \b
    Examples:
      pio cache view pwm
      pio cache view pwm 12
    """
    from pioreactor.utils import local_intermittent_storage
    from pioreactor.utils import local_persistent_storage

    for cacher in [local_intermittent_storage, local_persistent_storage]:  # TODO: this sucks
        with cacher(cache) as c:
            keys_to_show = [key] if key is not None else sorted(list(c.iterkeys()))
            for key_to_show in keys_to_show:
                if key_to_show in c:
                    click.echo(f"{click.style(key_to_show, bold=True)} = {c[key_to_show]}")


@cache.command(name="purge", short_help="remove a key from a cache")
@click.argument("cache", metavar="CACHE")
@click.argument("key", metavar="KEY")
@click.option("--as-int", is_flag=True, help="evict after casting key to int, useful for gpio pins.")
def purge_cache(cache: str, key: str, as_int: bool) -> None:
    """
    Remove a single entry from a cache.

    \b
    Examples:
      pio cache purge pwm 12
      pio cache purge gpio 18 --as-int
    """
    from pioreactor.utils import local_intermittent_storage
    from pioreactor.utils import local_persistent_storage

    key_to_evict = int(key) if as_int else key
    removed = False

    for cacher in [local_intermittent_storage, local_persistent_storage]:
        with cacher(cache) as c:
            if key_to_evict in c:
                del c[key_to_evict]
                removed = True

    if removed:
        click.echo(f"Removed key {key_to_evict} from cache '{cache}'.")
    else:
        click.echo(f"No entry for key {key_to_evict} found in cache '{cache}'.")


@pio.command(
    name="update-settings",
    context_settings=dict(ignore_unknown_options=True, allow_extra_args=True),
    short_help="update settings on a running job",
)
@click.argument("job", type=click.STRING)
@click.pass_context
def update_settings(ctx, job: str) -> None:
    """
    Examples
    ----------

    > pio update-settings stirring --target_rpm 500
    > pio update-settings stirring --target-rpm 500

    """
    from pioreactor.pubsub import publish

    unit = whoami.get_unit_name()
    exp = whoami.get_assigned_experiment_name(unit)

    extra_args = {ctx.args[i][2:]: ctx.args[i + 1] for i in range(0, len(ctx.args), 2)}

    assert len(extra_args) > 0

    for setting, value in extra_args.items():
        setting = setting.replace("-", "_")
        publish(f"pioreactor/{unit}/{exp}/{job}/{setting}/set", value)


@pio.group(invoke_without_command=True)
@click.option("-s", "--source", help="use a URL, whl file, or release-***.zip file")
@click.option("-b", "--branch", help="specify a branch")
@click.option("--sha", callback=validate_git_sha_option, help="specify a commit SHA")
@click.pass_context
def update(ctx, source: Optional[str], branch: Optional[str], sha: Optional[str]) -> None:
    """
    update software for the app (it's an alias for pio update app)
    """
    if ctx.invoked_subcommand is None:
        # run update app
        if source is not None:
            ctx.invoke(update_app, source=source)
        elif branch is not None:
            ctx.invoke(update_app, branch=branch)
        else:
            ctx.invoke(update_app, sha=sha)


def get_non_prerelease_tags_of_pioreactor(repo) -> list[str]:
    """
    Returns a list of all the tag names associated with non-prerelease releases, sorted in descending order
    """
    from packaging.version import Version

    url = f"https://api.github.com/repos/{repo}/releases"
    headers = {"Accept": "application/vnd.github.v3+json"}
    response = get(url, headers=headers)

    if not response.ok:
        raise Exception(f"Failed to retrieve releases (status code: {response.status_code})")

    releases = response.json()
    non_prerelease_tags = []

    for release in releases:
        if not release["prerelease"]:
            non_prerelease_tags.append(release["tag_name"])

    return sorted(non_prerelease_tags, key=Version)


def get_tag_to_install(repo: str, version_desired: Optional[str]) -> str:
    """
    The function get_tag_to_install takes an optional argument version_desired and
    returns a string that represents the tag of a particular version of software to install.

    If version_desired is not provided or is None, the function determines the latest
    non-prerelease version of the software installed on the system, and returns the tag
    of the previous version as a string, or "latest" if the system is already up to date.

    If version_desired is provided and is "latest", the function returns "latest" as a string.

    Otherwise, the function returns the tag of the specified version as a string, preceded by "tags/".
    """

    if version_desired is None:
        # we should only update one step at a time.
        from pioreactor.version import __version__
        from packaging.version import Version
        from bisect import bisect

        software_version = Version(Version(__version__).base_version)  # this removes and .devY or rcx
        version_history = get_non_prerelease_tags_of_pioreactor(repo)
        if bisect(version_history, software_version, key=Version) < len(version_history):
            ix = bisect(version_history, software_version, key=Version)
            if ix >= 1:
                tag = f"tags/{version_history[ix]}"
            elif ix == 0:
                tag = "latest"  # essentially a re-install?

        else:
            tag = "latest"

    elif version_desired == "latest":
        tag = "latest"
    else:
        tag = f"tags/{version_desired}"

    return tag


@update.command(name="app")
@click.option("-b", "--branch", help="install from a branch on github")
@click.option("--sha", callback=validate_git_sha_option, help="install from a commit SHA on github")
@click.option(
    "--no-deps",
    is_flag=True,
    default=False,
    help="skip dependency resolution for branch/SHA updates",
)
@click.option(
    "-r",
    "--repo",
    help="install from a repo on github. Format: 'username/project'",
    default="pioreactor/pioreactor",
)
@click.option("--source", help="use a URL, whl file, or release-***.zip file")
@click.option("-v", "--version", help="install a specific version, default is latest")
@click.option(
    "--defer-web-restart",
    is_flag=True,
    default=False,
    help="skip restarting pioreactor-web.target; useful when another process will restart it later",
)
def update_app(
    branch: Optional[str],
    sha: Optional[str],
    no_deps: bool,
    repo: str,
    source: Optional[str],
    version: Optional[str],
    defer_web_restart: bool = False,
) -> None:
    """
    Update the Pioreactor core software
    """
    from msgspec.json import encode as dumps
    from pioreactor.logging import create_logger
    from pioreactor.utils.timing import current_utc_timestamp

    # initialize logger and build commands based on input parameters
    logger = create_logger("update_app", unit=whoami.get_unit_name(), experiment=whoami.UNIVERSAL_EXPERIMENT)
    logger.debug(
        "Starting app update. branch=%s sha=%s repo=%s source=%s version=%s no_deps=%s defer_web_restart=%s",
        branch,
        sha,
        repo,
        source,
        version,
        no_deps,
        defer_web_restart,
    )
    commands_and_priority, version_installed = get_update_app_commands(
        branch,
        repo,
        source,
        version,
        sha=sha,
        no_deps=no_deps,
        defer_web_restart=defer_web_restart,
    )
    logger.debug(
        "Prepared %s update commands. target_version=%s", len(commands_and_priority), version_installed
    )

    for index, (command, priority) in enumerate(sorted(commands_and_priority, key=lambda t: t[1]), start=1):
        if whoami.is_testing_env():
            logger.debug("DRY-RUN (step %s, priority %s): %s", index, priority, command)
            continue

        logger.debug(
            "Running update step %s/%s: %s",
            index,
            len(commands_and_priority),
            command,
        )

        p = subprocess.run(
            command,
            shell=True,
            universal_newlines=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if p.returncode != 0:
            if p.stdout:
                logger.debug("Update step %s stdout: %s", index, p.stdout)
            if p.stderr:
                logger.debug("Update step %s stderr: %s", index, p.stderr)
            logger.debug("Update failed at step %s with returncode %s.", index, p.returncode)
            # end early
            raise click.Abort()
        elif p.stdout:
            logger.debug("Update step %s stdout: %s", index, p.stdout)
        if p.stderr:
            logger.debug("Update step %s stderr: %s", index, p.stderr)

    logger.notice(f"Updated Pioreactor app to version {version_installed}.")  # type: ignore
    # everything work? Let's publish to MQTT. This is a terrible hack, as monitor should do this.
    from pioreactor.pubsub import publish

    publish(
        f"pioreactor/{whoami.get_unit_name()}/{whoami.UNIVERSAL_EXPERIMENT}/monitor/versions/set",
        dumps({"app": version_installed, "timestamp": current_utc_timestamp()}),
    )


@update.command(name="firmware")
@click.option("-v", "--version", help="install a specific version, default is latest")
def update_firmware(version: Optional[str]) -> None:
    """
    Update the RP2040 firmware.

    # TODO: this needs accept a --source arg
    """

    from msgspec.json import decode as loads
    from pioreactor.logging import create_logger
    from pioreactor.mureq import get

    logger = create_logger(
        "update_firmware", unit=whoami.get_unit_name(), experiment=whoami.UNIVERSAL_EXPERIMENT
    )
    commands_and_priority: list[tuple[str, int]] = []

    if version is None:
        version = "latest"
    else:
        version = quote(version)
        version = f"tags/{version}"

    release_metadata = loads(
        get(f"https://api.github.com/repos/pioreactor/pico-build/releases/{version}").body
    )
    version_installed = release_metadata["tag_name"]

    for asset in release_metadata["assets"]:
        url = asset["browser_download_url"]
        asset_name = asset["name"]

        if asset_name == "main.elf":
            commands_and_priority.extend(
                [
                    (f"sudo wget -O /usr/local/bin/main.elf {url}", 0),
                    ("sudo bash /usr/local/bin/load_rp2040.sh", 1),
                ]
            )

    for command, _ in sorted(commands_and_priority, key=lambda t: t[1]):
        logger.debug(command)
        p = subprocess.run(
            command,
            shell=True,
            universal_newlines=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        if p.returncode != 0:
            logger.debug(p.stderr)
            logger.error("Update failed. See logs.")
            # end early
            raise click.Abort()

    logger.info(f"Updated Pioreactor firmware to version {version_installed}.")  # type: ignore


if whoami.am_I_leader():

    @pio.command(short_help="access the database's CLI")
    def db() -> None:
        """
        Open an interactive SQLite shell to the local Pioreactor database.

        \b
        Examples:
          pio db
        """
        import os
        from pioreactor.config import config

        os.system(f"sqlite3 {config.get('storage','database')} -column -header")

    @pio.command(short_help="tail MQTT")
    @click.option("--topic", "-t", default="pioreactor/#")
    def mqtt(topic: str) -> None:
        with subprocess.Popen(
            [
                "mosquitto_sub",
                "-v",
                "-t",
                topic,
                "-F",
                "%19.19I||%t||%p",
                "-u",
                "pioreactor",
                "-P",
                "raspberry",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        ) as process:
            assert process.stdout is not None
            for line in process.stdout:
                timestamp, topic, value = line.decode("utf8").rstrip("\n").split("||")
                click.echo(
                    click.style(timestamp, fg="cyan")
                    + " | "
                    + click.style(topic, fg="bright_green")
                    + " | "
                    + click.style(value, fg="bright_yellow")
                )
