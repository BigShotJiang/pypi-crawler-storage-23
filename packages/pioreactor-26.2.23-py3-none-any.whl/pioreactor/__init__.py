# -*- coding: utf-8 -*-
from pioreactor.version import __version__  # noqa: F401
