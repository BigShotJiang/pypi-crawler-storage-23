# -*- coding: utf-8 -*-
"""
These define structs for internal data structures including MQTT messages, and are type-checkable + runtime-checked.

"""
import typing as t
from datetime import datetime
from pathlib import Path

from msgspec import Meta
from msgspec import Struct
from msgspec.json import encode
from msgspec.yaml import encode as yaml_encode
from pioreactor import exc
from pioreactor import types as pt
from pioreactor.logging import create_logger


T = t.TypeVar("T")


def subclass_union(cls: t.Type[T]) -> t.Type[T]:
    """
    Returns a Union of all subclasses of `cls` (excluding `cls` itself)
    Note: this can't be used in static type inference...
    """

    classes = set()

    def _add(cls):
        for c in cls.__subclasses__():
            _add(c)
        classes.add(cls)

    for c in cls.__subclasses__():
        _add(c)
    return t.Union[tuple(classes)]  # type: ignore


class JSONPrintedStruct(Struct):
    def __str__(self):
        return encode(self).decode()  # this is a valid JSON str, decode() for bytes->str


class PolyFitCoefficients(Struct, tag="poly"):
    coefficients: list[float]

    @property
    def type(self):
        return self.__struct_config__.tag


class SplineFitData(Struct, tag="spline"):
    knots: list[float]
    coefficients: list[list[float]]

    @property
    def type(self):
        return self.__struct_config__.tag


class AkimaFitData(Struct, tag="akima"):
    knots: list[float]
    coefficients: list[list[float]]

    @property
    def type(self):
        return self.__struct_config__.tag


type CalibrationCurveData = PolyFitCoefficients | SplineFitData | AkimaFitData


class AutomationSettings(JSONPrintedStruct):
    """
    Metadata produced when settings in an automation job change
    """

    pioreactor_unit: pt.Unit
    experiment: pt.Experiment
    started_at: t.Annotated[datetime, Meta(tz=True)]
    ended_at: t.Optional[t.Annotated[datetime, Meta(tz=True)]]
    automation_name: str
    settings: bytes


class AutomationEvent(JSONPrintedStruct, tag=True, tag_field="event_name"):  # type: ignore
    """
    Automations can return an AutomationEvent from their `execute` method, and it
    will get published to MQTT under /latest_event
    """

    message: t.Optional[str] = None
    data: t.Optional[dict] = None

    def display(self) -> str:
        if self.message:
            return f"{self.human_readable_name}: {self.message}"
        else:
            return self.human_readable_name

    @property
    def human_readable_name(self) -> str:
        name = type(self).__name__
        return name

    # @property
    # def type(self) -> str:
    #    return self.__class__.__struct_tag__  # type: ignore


class LEDChangeEvent(JSONPrintedStruct):
    """
    Produced when an LED changes value
    """

    channel: pt.LedChannel
    intensity: pt.LedIntensityValue
    source_of_event: t.Optional[str]
    timestamp: t.Annotated[datetime, Meta(tz=True)]


class DosingEvent(JSONPrintedStruct):
    """
    Output of a pump action
    """

    volume_change: float  # can be negative!
    event: str
    source_of_event: t.Optional[str]
    timestamp: t.Annotated[datetime, Meta(tz=True)]


class MeasuredRPM(JSONPrintedStruct):
    measured_rpm: t.Annotated[float, Meta(ge=0)]
    timestamp: t.Annotated[datetime, Meta(tz=True)]


class GrowthRate(JSONPrintedStruct):
    growth_rate: float
    timestamp: t.Annotated[datetime, Meta(tz=True)]


class ODFiltered(JSONPrintedStruct):
    od_filtered: float
    timestamp: t.Annotated[datetime, Meta(tz=True)]


class ODFused(JSONPrintedStruct):
    od_fused: float
    timestamp: t.Annotated[datetime, Meta(tz=True)]


class RawPDReading(JSONPrintedStruct):
    reading: pt.Voltage
    channel: pt.PdChannel


class CalibratedODReading(JSONPrintedStruct, tag=1, tag_field="calibrated"):
    timestamp: t.Annotated[datetime, Meta(tz=True)]
    angle: pt.PdAngle
    od: pt.CalibratedOD
    channel: pt.PdChannel
    ir_led_intensity: float
    calibration_name: str


class RawODReading(JSONPrintedStruct, tag=0, tag_field="calibrated"):
    timestamp: t.Annotated[datetime, Meta(tz=True)]
    angle: pt.PdAngle
    od: pt.RawOD
    channel: pt.PdChannel
    ir_led_intensity: float


ODReading = RawODReading | CalibratedODReading


class ODReadings(JSONPrintedStruct):
    timestamp: t.Annotated[datetime, Meta(tz=True)]
    ods: dict[pt.PdChannel, ODReading]


class Temperature(JSONPrintedStruct):
    timestamp: t.Annotated[datetime, Meta(tz=True)]
    temperature: float


class Voltage(JSONPrintedStruct):
    timestamp: t.Annotated[datetime, Meta(tz=True)]
    voltage: pt.Voltage


X = float
Y = float


class CalibrationBase(Struct, tag_field="calibration_type", kw_only=True):
    calibration_name: str
    calibrated_on_pioreactor_unit: pt.Unit
    created_at: t.Annotated[datetime, Meta(tz=True)]
    curve_data_: CalibrationCurveData
    x: str
    y: str
    recorded_data: dict[t.Literal["x", "y"], list[X | Y]]

    def __post_init__(self):
        if len(self.recorded_data["x"]) != len(self.recorded_data["y"]):
            raise ValueError("Lists in `recorded_data` should have the same lengths")

    @property
    def calibration_type(self):
        return self.__struct_config__.tag

    def path_on_disk_for_device(self, device: str) -> Path:
        from pioreactor.calibrations import CALIBRATION_PATH

        calibration_dir = CALIBRATION_PATH / device
        out_file = calibration_dir / f"{self.calibration_name}.yaml"
        return out_file

    def save_to_disk_for_device(self, device: str) -> str:
        logger = create_logger("calibrations", experiment="$experiment")

        out_file = self.path_on_disk_for_device(device)
        device_dir = out_file.parent
        device_dir.mkdir(parents=True, exist_ok=True)

        # Serialize to YAML
        with out_file.open("wb") as f:
            f.write(yaml_encode(self))

        logger.info(f"Saved calibration {self.calibration_name} to {out_file}")
        return str(out_file)

    def set_as_active_calibration_for_device(self, device: str) -> None:
        from pioreactor.utils import local_persistent_storage

        logger = create_logger("calibrations", experiment="$experiment")

        if not self.exists_on_disk_for_device(device):
            self.save_to_disk_for_device(device)

        with local_persistent_storage("active_calibrations") as c:
            c[device] = self.calibration_name

        logger.info(f"Set {self.calibration_name} as active calibration for {device}")

    def remove_as_active_calibration_for_device(self, device: str) -> None:
        from pioreactor.utils import local_persistent_storage

        logger = create_logger("calibrations", experiment="$experiment")

        with local_persistent_storage("active_calibrations") as c:
            if c.get(device) == self.calibration_name:
                del c[device]
                logger.info(f"Removed {self.calibration_name} as active calibration for {device}")

    def exists_on_disk_for_device(self, device: str) -> bool:
        from pioreactor.calibrations import CALIBRATION_PATH

        target_file = CALIBRATION_PATH / device / f"{self.calibration_name}.yaml"

        return target_file.is_file()

    def x_to_y(self, x: X) -> Y:
        """
        Predict y given x
        """
        if self.curve_data_.type == "poly":
            from pioreactor.utils.polys import poly_eval

            poly_data = t.cast(PolyFitCoefficients, self.curve_data_)
            if len(poly_data.coefficients) == 0:
                raise exc.NoSolutionsFoundError(f"calibration {self}'s curve_data_ is empty")
            return round(poly_eval(poly_data, x), 10)
        if self.curve_data_.type == "spline":
            from pioreactor.utils.splines import spline_eval

            spline_data = t.cast(SplineFitData, self.curve_data_)
            if len(spline_data.knots) == 0 or len(spline_data.coefficients) == 0:
                raise exc.NoSolutionsFoundError(f"calibration {self}'s curve_data_ is empty")
            return round(spline_eval(spline_data, x), 10)
        if self.curve_data_.type == "akima":
            from pioreactor.utils.akimas import akima_eval

            akima_data = t.cast(AkimaFitData, self.curve_data_)
            if len(akima_data.knots) == 0 or len(akima_data.coefficients) == 0:
                raise exc.NoSolutionsFoundError(f"calibration {self}'s curve_data_ is empty")
            return round(akima_eval(akima_data, x), 10)

        raise NotImplementedError(f"Unsupported curve_type: {self.curve_data_.type}")

    def y_to_x(self, y: Y, enforce_bounds=False) -> X:
        """
        predict x given y
        """
        from pioreactor.utils.math_helpers import closest_point_to_domain

        if self.curve_data_.type == "poly":
            from pioreactor.utils.polys import poly_solve

            poly_data = t.cast(PolyFitCoefficients, self.curve_data_)
            if len(poly_data.coefficients) == 0:
                raise exc.NoSolutionsFoundError(f"calibration {self}'s curve_data_ is empty")
            plausible_sols_ = poly_solve(poly_data, y)
        elif self.curve_data_.type == "spline":
            from pioreactor.utils.splines import spline_solve

            spline_data = t.cast(SplineFitData, self.curve_data_)
            if len(spline_data.knots) == 0 or len(spline_data.coefficients) == 0:
                raise exc.NoSolutionsFoundError(f"calibration {self}'s curve_data_ is empty")
            plausible_sols_ = spline_solve(spline_data, y)
        elif self.curve_data_.type == "akima":
            from pioreactor.utils.akimas import akima_solve

            akima_data = t.cast(AkimaFitData, self.curve_data_)
            if len(akima_data.knots) == 0 or len(akima_data.coefficients) == 0:
                raise exc.NoSolutionsFoundError(f"calibration {self}'s curve_data_ is empty")
            plausible_sols_ = akima_solve(akima_data, y)
        else:
            raise NotImplementedError(f"Unsupported curve_type: {self.curve_data_.type}")

        if len(self.recorded_data["x"]) == 0:
            from math import inf

            min_X, max_X = -inf, inf
        else:
            min_X, max_X = min(self.recorded_data["x"]), max(self.recorded_data["x"])

        if len(plausible_sols_) == 0:
            raise exc.NoSolutionsFoundError("No solutions found")
        elif len(plausible_sols_) == 1:
            sol = plausible_sols_[0]

            if not enforce_bounds:
                return round(sol, 10)

            # if we are here, we let the downstream code decide how to proceed

            domain_tolerance = 1e-12  # numpy.roots can return a solution like -1e-16 for a true zero root due to floating‑point noise.
            if min_X <= sol <= max_X:
                return round(sol, 10)
            elif sol < min_X and abs(sol - min_X) <= domain_tolerance:
                return round(min_X, 10)
            elif sol > max_X and abs(sol - max_X) <= domain_tolerance:
                return round(max_X, 10)
            elif sol < min_X:
                raise exc.SolutionBelowDomainError(f"Solution below domain [{min_X}, {max_X}]")
            else:
                raise exc.SolutionAboveDomainError(f"Solution above domain [{min_X}, {max_X}]")

        # what do we do with multiple solutions?
        closest_sol = closest_point_to_domain(plausible_sols_, (min_X, max_X))
        # closet sol can be inside or outside domain. If inside, happy path:
        if (min_X <= closest_sol <= max_X) or not enforce_bounds:
            return round(closest_sol, 10)

        # if we are here, we let the downstream code decide how to proceed
        elif closest_sol < min_X:
            raise exc.SolutionBelowDomainError("Solution below domain")
        else:
            raise exc.SolutionAboveDomainError("Solution below domain")

    def is_active(self, device: str) -> bool:
        from pioreactor.utils import local_persistent_storage

        with local_persistent_storage("active_calibrations") as c:
            return c.get(device) == self.calibration_name


class EstimatorBase(Struct, tag_field="estimator_type", kw_only=True):
    estimator_name: str
    calibrated_on_pioreactor_unit: pt.Unit
    created_at: t.Annotated[datetime, Meta(tz=True)]

    @property
    def estimator_type(self):
        return self.__struct_config__.tag

    def path_on_disk_for_device(self, device: str) -> Path:
        from pioreactor.estimators import ESTIMATOR_PATH

        estimator_dir = ESTIMATOR_PATH / device
        out_file = estimator_dir / f"{self.estimator_name}.yaml"
        return out_file

    def save_to_disk_for_device(self, device: str) -> str:
        logger = create_logger("estimators", experiment="$experiment")

        out_file = self.path_on_disk_for_device(device)
        device_dir = out_file.parent
        device_dir.mkdir(parents=True, exist_ok=True)

        # Serialize to YAML
        with out_file.open("wb") as f:
            f.write(yaml_encode(self))

        logger.info(f"Saved estimator {self.estimator_name} to {out_file}")
        return str(out_file)

    def set_as_active_calibration_for_device(self, device: str) -> None:
        from pioreactor.utils import local_persistent_storage

        logger = create_logger("estimators", experiment="$experiment")

        if not self.exists_on_disk_for_device(device):
            self.save_to_disk_for_device(device)

        with local_persistent_storage("active_estimators") as c:
            c[device] = self.estimator_name

        logger.info(f"Set {self.estimator_name} as active estimator for {device}")

    def remove_as_active_calibration_for_device(self, device: str) -> None:
        from pioreactor.utils import local_persistent_storage

        logger = create_logger("estimators", experiment="$experiment")

        with local_persistent_storage("active_estimators") as c:
            if c.get(device) == self.estimator_name:
                del c[device]
                logger.info(f"Removed {self.estimator_name} as active estimator for {device}")

    def exists_on_disk_for_device(self, device: str) -> bool:
        from pioreactor.estimators import ESTIMATOR_PATH

        target_file = ESTIMATOR_PATH / device / f"{self.estimator_name}.yaml"

        return target_file.is_file()

    def is_active(self, device: str) -> bool:
        from pioreactor.utils import local_persistent_storage

        with local_persistent_storage("active_estimators") as c:
            return c.get(device) == self.estimator_name


class ODCalibration(CalibrationBase, kw_only=True, tag="od"):
    ir_led_intensity: float
    angle: t.Literal["45", "90", "135", "180"]
    pd_channel: pt.PdChannel
    y: str = "Voltage"
    x: str = "OD"


class OD600Calibration(ODCalibration, kw_only=True, tag="od600"):
    x: str = "OD600"


class ODFusionEstimator(EstimatorBase, kw_only=True, tag="od_fused_estimator"):
    ir_led_intensity: float
    angles: list[pt.PdAngle]
    mu_splines: dict[pt.PdAngle, AkimaFitData]
    sigma_splines_log: dict[pt.PdAngle, AkimaFitData]
    min_logc: float
    max_logc: float
    sigma_floor: float
    recorded_data: dict[str, t.Any]
    y: str = "log(Voltage)"


class SimplePeristalticPumpCalibration(CalibrationBase, kw_only=True, tag="simple_peristaltic_pump"):
    hz: t.Annotated[float, Meta(ge=0)]
    dc: t.Annotated[float, Meta(ge=0)]
    voltage: float
    x: str = "Duration"
    y: str = "Volume"

    def ml_to_duration(self, ml: pt.mL) -> pt.Seconds:
        return t.cast(pt.Seconds, self.y_to_x(ml))

    def duration_to_ml(self, duration: pt.Seconds) -> pt.mL:
        return t.cast(pt.mL, self.x_to_y(duration))


class SimpleStirringCalibration(CalibrationBase, kw_only=True, tag="simple_stirring"):
    pwm_hz: t.Annotated[float, Meta(ge=0)]
    voltage: float
    x: str = "DC %"
    y: str = "RPM"


AnyCalibration = t.Union[
    SimpleStirringCalibration,
    SimplePeristalticPumpCalibration,
    ODCalibration,
    OD600Calibration,
    CalibrationBase,
]

AnyEstimator = t.Union[EstimatorBase, ODFusionEstimator]


class Log(JSONPrintedStruct):
    message: str
    level: str
    task: str
    source: str
    timestamp: t.Annotated[datetime, Meta(tz=True)]


class KalmanFilterOutput(JSONPrintedStruct):
    state: t.Annotated[list[float], Meta(max_length=3)]
    covariance_matrix: list[list[float]]
    timestamp: t.Annotated[datetime, Meta(tz=True)]


class Dataset(JSONPrintedStruct):
    dataset_name: str  # the unique key
    description: t.Optional[str]
    display_name: str
    has_experiment: bool
    has_unit: bool
    default_order_by: t.Optional[str]
    table: t.Optional[str] = None
    query: t.Optional[str] = None
    source: str = "app"
    timestamp_columns: list[str] = []
    always_partition_by_unit: bool = False


class Model(Struct):
    """Defines a bioreactor hardware model with its physical and automation parameters."""

    model_name: str  # this in combination with model_version should form a unique pair
    model_version: str  # this in combination with model_name should form a unique pair
    display_name: str  # for UI and such

    # reactor vessel capacity (e.g. 20 or 40 mL)
    reactor_capacity_ml: float

    # physical diameter of the reactor
    reactor_diameter_mm: float

    # maximum safe fill volume of the reactor
    reactor_max_fill_volume_ml: float

    # temperature and safety parameters:
    max_temp_to_reduce_heating: float
    max_temp_to_disable_heating: float
    max_temp_to_shutdown: float

    # metadata
    is_legacy: bool = False
    is_contrib: bool = True


#### Jobs


class PublishedSettingsDescriptor(Struct, forbid_unknown_fields=True):  # type: ignore
    key: str
    type: t.Literal["numeric", "boolean", "string", "json"]
    display: bool
    description: t.Optional[str] = None
    default: t.Optional[t.Union[str, bool]] = None  # DEPRECATED DO NOT USE
    unit: t.Optional[str] = None
    label: t.Optional[str] = None  # if display is false, this isn't needed
    editable: bool = True


class BackgroundJobDescriptor(Struct, forbid_unknown_fields=True):  # type: ignore
    display_name: str
    job_name: str
    display: bool
    published_settings: list[PublishedSettingsDescriptor]
    source: t.Optional[str] = None  # what plugin / app created this job? Usually `app`
    description: t.Optional[str] = None  # if display is false, this isn't needed
    subtext: t.Optional[str] = None
    is_testing: bool = False  # DEPRECATED DO NOT USE


#### Automations


class AutomationFieldsDescriptor(Struct, forbid_unknown_fields=True):  # type: ignore
    key: str
    default: t.Union[str, float, int, None]
    label: str
    disabled: bool = False
    unit: t.Optional[str] = None
    type: t.Literal["numeric", "string", "select"] = "numeric"  # TODO we will include boolean
    options: t.Optional[list[str]] = None


class AutomationDescriptor(Struct, forbid_unknown_fields=True):  # type: ignore
    display_name: str
    automation_name: str
    description: str
    source: t.Optional[str] = None  # what plugin / app created this automation? Usually `app`
    fields: list[AutomationFieldsDescriptor] = []


#### Charts


class ChartDescriptor(Struct, forbid_unknown_fields=True):  # type: ignore
    chart_key: str
    data_source: str  # SQL table
    title: str
    source: str
    y_axis_label: str
    fixed_decimals: int
    down_sample: bool = True
    mqtt_topic: t.Optional[str | list[str]] = None  # leave empty for no live updates from mqtt
    lookback: t.Union[int, str, float] = 100_000
    data_source_column: t.Optional[str] = None  # column in sql store
    payload_key: t.Optional[str] = None
    y_transformation: t.Optional[str] = "(y) => y"  # default is the identity
    y_axis_domain: t.Optional[list[float]] = None
    interpolation: t.Literal[
        "basis",
        "bundle",
        "cardinal",
        "catmullRom",
        "linear",
        "monotoneX",
        "monotoneY",
        "natural",
        "step",
        "stepAfter",
        "stepBefore",
    ] = "stepAfter"


class ArgsOptionsEnvs(Struct):
    options: dict[str, t.Any] = {}
    env: dict[str, str] = {}
    args: list[str] = []


class ArgsOptionsEnvsConfigOverrides(ArgsOptionsEnvs):
    config_overrides: list[list[str]] = []
