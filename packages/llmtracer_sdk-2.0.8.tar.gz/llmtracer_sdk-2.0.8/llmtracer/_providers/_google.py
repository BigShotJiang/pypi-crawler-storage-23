"""Google Gemini-specific: patch targets, response parsing, stream wrapping."""

from .. import _config
from .._wrapper import _build_and_enqueue

# ── Patch targets ─────────────────────────────────────────────────────────────
# google-genai SDK (used by langchain-google-genai v4+)
# LangChain calls: client.models.generate_content() / client.aio.models.generate_content()

SYNC_TARGET = ("google.genai.models", "Models", "generate_content")
ASYNC_TARGET = ("google.genai.models", "AsyncModels", "generate_content")


# ── Token extraction helper ──────────────────────────────────────────────────


def _extract_tokens_from_usage(usage):
    """Extract input/output token counts from Google usage_metadata.

    Includes ALL billable token categories:
    - thoughts_token_count (Gemini 2.5 reasoning, billed as output)
    - tool_use_prompt_token_count (tool definitions, billed as input)
    - cached_content_token_count (cached context, billed as input)
    """
    if usage is None:
        return 0, 0

    input_tokens = 0
    output_tokens = 0

    # New-style fields first (google-genai SDK) — old-style fields return garbage on newer SDKs
    for field in ("input_tokens", "prompt_tokens", "prompt_token_count"):
        val = getattr(usage, field, None)
        if isinstance(val, int) and val > 0:
            input_tokens = val
            break

    for field in ("output_tokens", "completion_tokens", "candidates_token_count"):
        val = getattr(usage, field, None)
        if isinstance(val, int) and val > 0:
            output_tokens = val
            break

    # Include cached/system tokens (avoid double-counting if already included)
    cached = getattr(usage, "cached_content_token_count", 0) or 0
    if cached > 0 and cached != input_tokens:
        input_tokens += cached

    # Add tool use tokens to input (tool/function definitions, billed as input)
    tool_tokens = getattr(usage, "tool_use_prompt_token_count", 0) or 0
    input_tokens += tool_tokens

    # Add thinking/reasoning tokens to output (Gemini 2.5 models, billed as output)
    thoughts = getattr(usage, "thoughts_token_count", 0) or 0
    output_tokens += thoughts

    # Sanity check: if extracted tokens are tiny vs total, use total as fallback
    total = getattr(usage, "total_token_count", 0) or 0
    if total > 0 and (input_tokens + output_tokens) < total * 0.1:
        input_tokens = total - output_tokens if output_tokens > 0 else total

    if _config.debug:
        base_in = input_tokens - tool_tokens - cached
        base_out = output_tokens - thoughts
        print(f"[llmtracer] Google tokens — base_in={base_in} cached={cached} tools={tool_tokens} base_out={base_out} thoughts={thoughts} total_reported={total}")
        print(f"[llmtracer] Google tokens extracted: in={input_tokens} out={output_tokens}")

    return input_tokens, output_tokens


# ── Response parsing ──────────────────────────────────────────────────────────

def parse_response(result):
    """Extract provider/model/tokens from a Google GenerateContentResponse."""
    usage = getattr(result, "usage_metadata", None)

    model = "unknown"
    # The response object may have model_version or model
    for attr in ("model_version", "model"):
        val = getattr(result, attr, None)
        if val:
            model = str(val)
            break

    input_tokens, output_tokens = _extract_tokens_from_usage(usage)

    return {
        "provider": "google",
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "status": "success",
    }


# ── Sync stream wrapper ──────────────────────────────────────────────────────

class _WrappedStream:
    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._elapsed_ms = start_elapsed_ms
        self._kwargs = kwargs
        self._chunks = []

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            try:
                self._record()
            except Exception:
                pass
            raise

    def _record(self):
        model = self._kwargs.get("model", "unknown")
        input_tokens = 0
        output_tokens = 0

        for chunk in reversed(self._chunks):
            usage = getattr(chunk, "usage_metadata", None)
            if usage:
                input_tokens, output_tokens = _extract_tokens_from_usage(usage)
                break

        response_data = {
            "provider": "google",
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "status": "success",
        }
        _build_and_enqueue(self._context, response_data, self._elapsed_ms)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*exc)
        return False


def wrap_stream(result, context, elapsed_ms, kwargs):
    return _WrappedStream(result, context, elapsed_ms, kwargs)


# ── Async stream wrapper ─────────────────────────────────────────────────────

class _WrappedAsyncStream:
    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._elapsed_ms = start_elapsed_ms
        self._kwargs = kwargs
        self._chunks = []

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            try:
                self._record()
            except Exception:
                pass
            raise

    def _record(self):
        model = self._kwargs.get("model", "unknown")
        input_tokens = 0
        output_tokens = 0

        for chunk in reversed(self._chunks):
            usage = getattr(chunk, "usage_metadata", None)
            if usage:
                input_tokens, output_tokens = _extract_tokens_from_usage(usage)
                break

        response_data = {
            "provider": "google",
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "status": "success",
        }
        _build_and_enqueue(self._context, response_data, self._elapsed_ms)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*exc)
        return False


def wrap_async_stream(result, context, elapsed_ms, kwargs):
    return _WrappedAsyncStream(result, context, elapsed_ms, kwargs)
