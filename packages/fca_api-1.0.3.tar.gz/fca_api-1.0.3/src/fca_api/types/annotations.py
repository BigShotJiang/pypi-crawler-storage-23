"""Custom annotations for FCA API types."""


class FcaApiUrl:
    """Annotation for FCA API URL fields."""
