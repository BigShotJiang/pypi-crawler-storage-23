"""Citation accuracy evaluator.

SPEC-008 §5.1: CitationAccuracyEvaluator — verifies agent response citations
correctly reference source documents returned by Foundry IQ agentic retrieval.
"""

from __future__ import annotations

import re
from typing import Any

from agentops_toolkit.evaluators.base import CustomEvaluator
from agentops_toolkit.models.run import EvalResult


class CitationAccuracyEvaluator(CustomEvaluator):
    """Evaluates whether citations in agent responses accurately
    reference the source documents (SPEC-008 §5.1, FR-122).

    Scores 0.0–1.0 based on the fraction of citations that can be
    verified against the provided retrieved documents.
    """

    _name = "citation_accuracy"
    _required_columns = ["response", "context"]
    _score_range = (0.0, 1.0)

    @property
    def name(self) -> str:
        return self._name

    @property
    def required_columns(self) -> list[str]:
        return self._required_columns

    @property
    def score_range(self) -> tuple[float, float]:
        return self._score_range

    async def evaluate(self, input_data: dict[str, Any]) -> EvalResult:
        """Score citation accuracy.

        Extracts citation references from the response (e.g. [1], [source.pdf]),
        then checks if each can be matched to the provided context/documents.
        """
        response = input_data.get("response", "")
        context = input_data.get("context", "")
        retrieved_documents = input_data.get("retrieved_documents", [])

        # Extract citations from response
        citations = self._extract_citations(response)

        if not citations:
            return EvalResult(
                evaluator_name=self.name,
                score=1.0,
                passed=True,
                raw_output={
                    "citation_count": 0,
                    "detail": "No citations found in response.",
                },
            )

        # Build a searchable context string
        if isinstance(context, list):
            context_text = "\n".join(str(c) for c in context)
        else:
            context_text = str(context)

        # Also include retrieved documents if available
        doc_texts: dict[str, str] = {}
        for doc in retrieved_documents:
            doc_id = doc.get("id", "")
            doc_content = doc.get("content", "")
            doc_texts[doc_id] = doc_content
            context_text += f"\n{doc_content}"

        # Verify each citation
        verified = 0
        details: list[dict[str, Any]] = []
        for citation in citations:
            is_match = self._verify_citation(citation, context_text, doc_texts)
            if is_match:
                verified += 1
            details.append({"ref": citation, "verified": is_match})

        score = verified / len(citations)

        return EvalResult(
            evaluator_name=self.name,
            score=score,
            passed=score >= 0.8,  # Default threshold
            raw_output={
                "citation_count": len(citations),
                "verified_count": verified,
                "citations": details,
            },
        )

    @staticmethod
    def _extract_citations(text: str) -> list[str]:
        """Extract citation references from text.

        Matches patterns like [1], [source.pdf], [doc_id], [ref:xyz].
        """
        return re.findall(r"\[([^\[\]]+)\]", text)

    @staticmethod
    def _verify_citation(
        citation: str,
        context_text: str,
        doc_texts: dict[str, str],
    ) -> bool:
        """Check if a citation reference can be matched to context or documents."""
        citation_lower = citation.lower().strip()

        # Check if citation matches a document ID
        for doc_id in doc_texts:
            if citation_lower == doc_id.lower() or citation_lower in doc_id.lower():
                return True

        # Check if citation text appears in context (filename, section ref, etc.)
        if citation_lower in context_text.lower():
            return True

        # Numeric citation — check if context has that many sources
        if citation_lower.isdigit():
            # Assume numeric citations are valid if context exists
            return bool(context_text.strip())

        return False
