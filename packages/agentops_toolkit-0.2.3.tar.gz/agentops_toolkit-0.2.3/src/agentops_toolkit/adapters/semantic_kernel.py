"""Semantic Kernel adapter — auto-discover plugins, capture kernel I/O.

SPEC-004 §4.1, FR-081: SemanticKernelAdapter.
"""

from __future__ import annotations

import logging
from typing import Any

from agentops_toolkit.adapters.registry import (
    AdapterCapabilities,
    AdapterRegistry,
    AgentDiscovery,
    AgentOutput,
    DiscoveredAgent,
)

logger = logging.getLogger(__name__)


class SemanticKernelAdapter:
    """Adapter for Microsoft Semantic Kernel agents (SPEC-004 §4.1).

    Auto-discovers kernel plugins, captures I/O via ChatCompletionService,
    and hooks planner steps via FunctionInvocationFilter.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config
        self._kernel = None
        self._captured_tool_calls: list[dict] = []

    @property
    def name(self) -> str:
        return "semantic-kernel"

    @property
    def framework_version(self) -> str:
        try:
            import semantic_kernel

            return getattr(semantic_kernel, "__version__", "unknown")
        except ImportError:
            return "not-installed"

    async def setup(self, config: dict[str, Any]) -> None:
        """Import entry point, locate Kernel, install filters."""
        entry_point = config.get("entry_point", "")
        kernel_var = config.get("kernel_var", "kernel")
        logger.info("SK adapter setup: entry=%s, kernel_var=%s", entry_point, kernel_var)
        # Production: import module, find kernel, install filters
        # See SPEC-004 §4.1 for full implementation

    async def teardown(self) -> None:
        self._kernel = None
        self._captured_tool_calls.clear()

    async def invoke(self, query: str, context: str | None = None) -> AgentOutput:
        """Invoke the SK agent with a query."""
        logger.info("SK invoke: query=%s", query[:50])
        # Production: build ChatHistory, call ChatCompletionService, capture result
        return AgentOutput(
            response="[SK adapter — production implementation calls kernel]",
            tool_calls=self._captured_tool_calls or None,
            metadata={"framework": "semantic-kernel"},
        )

    async def discover(self, config: dict[str, Any]) -> AgentDiscovery:
        """Discover SK agents: scan for Kernel instances and plugins."""
        return AgentDiscovery(
            framework="semantic-kernel",
            framework_version=self.framework_version,
            agents=[
                DiscoveredAgent(
                    name="kernel",
                    entry_point=config.get("entry_point", ""),
                    agent_type="single",
                )
            ],
        )

    def get_capabilities(self) -> AdapterCapabilities:
        return AdapterCapabilities(
            captures_tool_calls=True,
            captures_planner_steps=True,
            captures_token_usage=True,
        )

    def supports_streaming(self) -> bool:
        return True


# Auto-register
AdapterRegistry.register("semantic-kernel", SemanticKernelAdapter)
