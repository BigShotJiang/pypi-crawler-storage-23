"""Framework adapters — bridge between AgentOps and agent frameworks.

SPEC-004: FrameworkAdapter protocol, AdapterRegistry, auto-detection.

Importing this package auto-registers all built-in adapters.
"""

from agentops_toolkit.adapters import agent_service as _as  # noqa: F401
from agentops_toolkit.adapters import autogen as _ag  # noqa: F401
from agentops_toolkit.adapters import generic as _gen  # noqa: F401

# Auto-register built-in adapters on import
from agentops_toolkit.adapters import semantic_kernel as _sk  # noqa: F401
from agentops_toolkit.adapters.registry import (
    AdapterCapabilities,
    AdapterRegistry,
    AgentDiscovery,
    AgentOutput,
    DiscoveredAgent,
    FrameworkAdapter,
)

__all__ = [
    "AdapterCapabilities",
    "AdapterRegistry",
    "AgentDiscovery",
    "AgentOutput",
    "DiscoveredAgent",
    "FrameworkAdapter",
]
