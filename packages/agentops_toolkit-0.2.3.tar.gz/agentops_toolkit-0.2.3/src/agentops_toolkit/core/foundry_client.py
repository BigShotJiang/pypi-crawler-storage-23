"""FoundryClient interface — unified abstraction for SDK and MCP backends.

SPEC-003 §1.1: Protocol that both FoundrySDKClient and FoundryMCPClient implement.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class FoundryClient(Protocol):
    """Unified interface for Foundry operations.

    Implemented by:
      - FoundrySDKClient  (default, uses azure-ai-evaluation SDK)
      - FoundryMCPClient  (alternative, uses Foundry MCP Server — SPEC-009)
    """

    async def evaluate(
        self,
        evaluators: dict[str, Any],
        data: dict[str, Any],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run evaluators against input data. Returns raw Foundry result."""
        ...

    async def create_evaluation(
        self,
        dataset_id: str,
        evaluator_ids: list[str],
        agent_id: str | None = None,
    ) -> str:
        """Create a full evaluation run. Returns evaluation ID."""
        ...

    async def get_evaluation(self, evaluation_id: str) -> dict[str, Any]:
        """Retrieve evaluation results."""
        ...

    async def compare_evaluations(self, eval_id_a: str, eval_id_b: str) -> dict[str, Any]:
        """Compare two evaluations. Returns comparison with deltas."""
        ...

    async def check_connectivity(self) -> bool:
        """Verify credentials and project reachability."""
        ...
