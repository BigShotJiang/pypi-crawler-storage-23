"""Configuration loader — find, parse, validate, resolve agentops.yaml.

SPEC-006 §2, §8: ConfigLoader with env var resolution, override priority,
validation rules CFG-001–CFG-015.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from pydantic import ValidationError
from ruamel.yaml import YAML

from agentops_toolkit.models.config import ProjectConfig

_yaml = YAML(typ="safe")

# ── Environment variable resolution ──

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


class ConfigError(Exception):
    """Configuration loading or validation error."""

    def __init__(self, message: str, code: int = 10) -> None:
        self.code = code
        super().__init__(message)


def _resolve_env_vars(value: Any, path: str = "") -> Any:
    """Recursively resolve ``${VAR}`` references in config values."""
    if isinstance(value, str):

        def _replacer(match: re.Match[str]) -> str:
            var_name = match.group(1)
            env_val = os.environ.get(var_name)
            if env_val is None:
                raise ConfigError(
                    f"Environment variable '{var_name}' is not set (referenced in {path})",
                    code=16,
                )
            return env_val

        return _ENV_PATTERN.sub(_replacer, value)
    elif isinstance(value, dict):
        return {k: _resolve_env_vars(v, f"{path}.{k}") for k, v in value.items()}
    elif isinstance(value, list):
        return [_resolve_env_vars(v, f"{path}[{i}]") for i, v in enumerate(value)]
    return value


def _coerce_type(value: str, key: str) -> Any:
    """Coerce string env var to appropriate Python type."""
    int_keys = {"max_concurrency", "timeout_seconds"}
    bool_keys = {"auto_report", "fail_on_threshold"}
    if key in int_keys:
        return int(value)
    if key in bool_keys:
        return value.lower() in ("true", "1", "yes")
    return value


def _apply_env_overrides(config: dict[str, Any]) -> dict[str, Any]:
    """Apply well-known environment variable overrides (SPEC-006 §5)."""
    overrides: dict[str, tuple[str, str]] = {
        "AZURE_AI_FOUNDRY_PROJECT_ENDPOINT": ("foundry", "project_endpoint"),
        # Legacy fallback
        "FOUNDRY_CONNECTION": ("foundry", "project_connection"),
        "AGENTOPS_LOG_LEVEL": ("logging", "level"),
        "AGENTOPS_MAX_CONCURRENCY": ("agent", "max_concurrency"),
        "AGENTOPS_TIMEOUT": ("agent", "timeout_seconds"),
        "AGENTOPS_OUTPUT_DIR": ("runs", "output_dir"),
    }
    for env_var, (section, key) in overrides.items():
        val = os.environ.get(env_var)
        if val is not None:
            config.setdefault(section, {})[key] = _coerce_type(val, key)
    return config


# ── Search paths ──

_SEARCH_PATHS = [
    "agentops.yaml",
    "agentops.yml",
    ".agentops/config.yaml",
]


def find_config_path(explicit_path: str | None = None) -> Path:
    """Locate the configuration file (SPEC-006 §2).

    Resolution order:
      1. ``--config`` flag (explicit_path)
      2. ``AGENTOPS_CONFIG`` env var
      3. ``agentops.yaml`` → ``agentops.yml`` → ``.agentops/config.yaml``

    Raises:
        ConfigError: If no config file is found.
    """
    if explicit_path:
        p = Path(explicit_path)
        if not p.exists():
            raise ConfigError(f"Config file not found: {explicit_path}", code=10)
        return p

    env_path = os.environ.get("AGENTOPS_CONFIG")
    if env_path:
        p = Path(env_path)
        if not p.exists():
            raise ConfigError(f"AGENTOPS_CONFIG points to missing file: {env_path}", code=10)
        return p

    for search in _SEARCH_PATHS:
        p = Path(search)
        if p.exists():
            return p

    raise ConfigError("No agentops.yaml found. Run 'agentops init' to create one.", code=10)


def load_config(config_path: str | None = None) -> ProjectConfig:
    """Load, resolve, validate, and return the project configuration.

    Steps (SPEC-006 §8):
      1. Find config file
      2. Parse YAML
      3. Resolve ``${VAR}`` environment variables
      4. Apply well-known env var overrides
      5. Validate via Pydantic model
    """
    path = find_config_path(config_path)

    # Load .env file next to the config (if it exists) so ${VAR} references resolve
    env_file = path.parent / ".env"
    if env_file.exists():
        load_dotenv(env_file, override=False)

    try:
        with open(path, encoding="utf-8") as f:
            raw = _yaml.load(f)
    except Exception as e:
        raise ConfigError(f"Failed to parse YAML: {e}", code=10) from e

    if not isinstance(raw, dict):
        raise ConfigError("Config file is empty or not a YAML mapping", code=10)

    # Resolve env vars
    resolved = _resolve_env_vars(raw)

    # Apply env overrides
    resolved = _apply_env_overrides(resolved)

    # Validate
    try:
        return ProjectConfig.model_validate(resolved)
    except ValidationError as e:
        errors = "\n".join(
            f"  - {err['msg']} ({'.'.join(str(x) for x in err['loc'])})" for err in e.errors()
        )
        raise ConfigError(f"Config validation failed:\n{errors}", code=10) from e
