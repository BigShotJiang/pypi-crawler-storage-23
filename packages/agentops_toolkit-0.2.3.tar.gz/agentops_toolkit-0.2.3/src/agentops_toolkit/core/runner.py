"""Agent runner — executes agents against dataset entries.

SPEC-003 §2 Phase 2: AgentRunner with semaphore concurrency and timeout.
"""
