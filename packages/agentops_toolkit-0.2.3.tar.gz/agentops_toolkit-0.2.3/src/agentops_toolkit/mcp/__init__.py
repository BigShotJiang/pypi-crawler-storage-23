"""Foundry MCP Server integration — control plane.

SPEC-009: MCP HTTP client, FoundryMCPEvalBackend, ModelManager, AgentManager.
"""
