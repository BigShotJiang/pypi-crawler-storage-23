"""Run and evaluation result models.

SPEC-001 §3.10–3.13: RunConfig, Run, RunEntry, EvalResult, RunSummary, EvaluatorSummary.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from agentops_toolkit.models.bundle import BundleConfig
from agentops_toolkit.models.dataset import ConversationTurn, ToolCall

# ── Enums ──


class RunStatus(str, Enum):
    """Lifecycle status of a run."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class EntryStatus(str, Enum):
    """Outcome of a single dataset entry execution."""

    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


# ── Config ──


class RunConfig(BaseModel):
    """Run configuration from agentops.yaml (SPEC-001 §3.10)."""

    agent_entry: str
    dataset: str
    bundle: str
    max_concurrency: int = Field(default=5, ge=1, le=100)
    timeout_per_entry: int = Field(default=120, ge=1, le=3600)
    retry_on_failure: int = Field(default=1, ge=0)
    env: dict[str, str] = Field(default_factory=dict)


# ── Results ──


class EvalResult(BaseModel):
    """Evaluation score for one evaluator on one dataset entry (SPEC-001 §3.12)."""

    evaluator_name: str
    score: float | None = None
    label: str | None = None
    severity: str | None = None
    reasoning: str | None = None
    passed: bool | None = None
    raw_output: dict[str, Any] = Field(default_factory=dict)


class RunEntry(BaseModel):
    """Result for one dataset entry within a run (SPEC-001 §3.11)."""

    dataset_entry_id: str
    status: EntryStatus

    # Agent output
    agent_response: str | None = None
    agent_latency_ms: float | None = None
    tool_calls: list[ToolCall] | None = None
    conversation_turns: list[ConversationTurn] | None = None

    # Evaluation scores
    eval_results: list[EvalResult] = Field(default_factory=list)

    # Error info
    error_message: str | None = None
    error_type: str | None = None


class EvaluatorSummary(BaseModel):
    """Aggregate stats for one evaluator across all entries (SPEC-001 §3.13)."""

    evaluator_name: str
    mean_score: float
    median_score: float
    min_score: float
    max_score: float
    std_dev: float
    pass_rate: float | None = None
    distribution: dict[str, int] = Field(default_factory=dict)


class RunSummary(BaseModel):
    """Aggregate statistics for a completed run (SPEC-001 §3.13)."""

    total_entries: int
    successful_entries: int
    failed_entries: int
    skipped_entries: int

    evaluator_scores: dict[str, EvaluatorSummary] = Field(default_factory=dict)

    aggregate_score: float | None = None
    pass_rate: float | None = None

    total_duration_ms: float = 0.0
    avg_agent_latency_ms: float = 0.0
    p95_agent_latency_ms: float = 0.0


class Run(BaseModel):
    """A completed or in-progress run instance (SPEC-001 §3.10).

    Stored as JSON in ``agentops/runs/<run_id>/run.json``.
    """

    id: str
    name: str
    status: RunStatus
    config: RunConfig
    bundle_snapshot: BundleConfig
    dataset_name: str

    # Timing
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None

    # Results
    entries: list[RunEntry] = Field(default_factory=list)
    summary: RunSummary | None = None

    # Provenance
    agent_version: str | None = None
    toolkit_version: str = ""
    foundry_project: str = ""
