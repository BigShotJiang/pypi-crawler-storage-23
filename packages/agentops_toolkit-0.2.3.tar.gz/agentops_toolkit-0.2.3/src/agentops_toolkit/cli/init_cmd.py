"""agentops init — Project scaffolding.

SPEC-002 §3.1, FR-001–FR-007.
"""

from __future__ import annotations

import re
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from ruamel.yaml import YAML

from agentops_toolkit.models.config import Framework, UseCase

console = Console()
_yaml = YAML()
_yaml.default_flow_style = False

init_app = typer.Typer(name="init", invoke_without_command=True)

# ── Default bundle for each use case ──

_DEFAULT_BUNDLE: dict[UseCase, str] = {
    UseCase.RAG: "rag_quality",
    UseCase.AGENT: "agent_quality",
    UseCase.MULTI_AGENT: "multi_agent_quality",
}

# ── Sample dataset ──

_SAMPLE_DATASET = [
    {
        "id": "001",
        "query": "What is the refund policy?",
        "context": "Our refund policy allows returns within 30 days of purchase for a full refund.",
        "ground_truth": "You can return items within 30 days for a full refund.",
    },
    {
        "id": "002",
        "query": "How do I reset my password?",
        "context": "To reset your password, go to Settings > Security and click Reset Password.",
        "ground_truth": "Go to Settings > Security and click Reset Password.",
    },
    {
        "id": "003",
        "query": "What payment methods do you accept?",
        "context": "We accept Visa, MasterCard, American Express, PayPal, and bank transfers.",
        "ground_truth": "We accept Visa, MasterCard, American Express, PayPal, and bank transfers.",
    },
]


def _detect_framework(project_root: Path) -> Framework | None:
    """Auto-detect agent framework from project dependencies (SPEC-004 §3)."""
    detection_map = {
        "semantic-kernel": Framework.SEMANTIC_KERNEL,
        "semantic_kernel": Framework.SEMANTIC_KERNEL,
        "autogen": Framework.AUTOGEN,
        "autogen-agentchat": Framework.AUTOGEN,
        "azure-ai-projects": Framework.AGENT_SERVICE,
    }

    files_to_check = ["pyproject.toml", "requirements.txt", "setup.cfg"]
    for fname in files_to_check:
        fpath = project_root / fname
        if fpath.exists():
            content = fpath.read_text(encoding="utf-8").lower()
            for pkg, fw in detection_map.items():
                if pkg in content:
                    return fw
    return None


def _generate_config(
    project_name: str,
    use_case: UseCase,
    framework: Framework,
    entry_point: str,
) -> dict:
    """Generate the agentops.yaml content as a dict."""
    return {
        "schema_version": "1.0",
        "project": {"name": project_name},
        "foundry": {"project_endpoint": "${AZURE_AI_FOUNDRY_PROJECT_ENDPOINT}"},
        "agent": {
            "framework": framework.value,
            "use_case": use_case.value,
            "entry_point": entry_point,
        },
        "bundles": {"default": _DEFAULT_BUNDLE.get(use_case, "rag_quality")},
        "datasets": {
            "default": "golden_set",
            "entries": [
                {
                    "name": "golden_set",
                    "path": "agentops/datasets/golden_set.jsonl",
                    "format": "jsonl",
                    "description": "Sample golden dataset — replace with your test data",
                }
            ],
        },
    }


def _write_env_file(project_root: Path, endpoint: str) -> None:
    """Write or update .env file with the Foundry endpoint."""
    env_path = project_root / ".env"
    env_var = "AZURE_AI_FOUNDRY_PROJECT_ENDPOINT"

    if env_path.exists():
        content = env_path.read_text(encoding="utf-8")
        # Update existing entry if present
        pattern = rf"^{env_var}=.*$"
        if re.search(pattern, content, re.MULTILINE):
            content = re.sub(pattern, f"{env_var}={endpoint}", content, flags=re.MULTILINE)
        else:
            content = content.rstrip("\n") + f"\n{env_var}={endpoint}\n"
        env_path.write_text(content, encoding="utf-8")
    else:
        env_path.write_text(
            f"# Azure AI Foundry project endpoint\n{env_var}={endpoint}\n",
            encoding="utf-8",
        )


def _write_sample_dataset(datasets_dir: Path) -> None:
    """Write sample golden dataset JSONL."""
    import json

    dataset_path = datasets_dir / "golden_set.jsonl"
    with open(dataset_path, "w", encoding="utf-8") as f:
        for entry in _SAMPLE_DATASET:
            f.write(json.dumps(entry) + "\n")


@init_app.callback(invoke_without_command=True)
def init(
    path: str | None = typer.Option(
        None, "--path", "-p", help="Project directory to initialize (defaults to current directory)"
    ),
    use_case: UseCase | None = typer.Option(
        None, "--use-case", "-u", help="Agent use case: rag, agent, multi-agent"
    ),
    framework: Framework | None = typer.Option(None, "--framework", "-f", help="Agent framework"),
    entry_point: str = typer.Option(
        "src/agent.py", "--entry-point", "-e", help="Agent entry point file"
    ),
    endpoint: str | None = typer.Option(
        None, "--endpoint", help="Azure AI Foundry project endpoint URL"
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite existing agentops.yaml"),
    no_interactive: bool = typer.Option(
        False, "--no-interactive", help="Skip prompts; fail if required values missing"
    ),
) -> None:
    """Initialize AgentOps in a project directory.

    Optionally pass a PATH to initialize a specific directory
    (created if it doesn't exist). Defaults to the current directory.
    """
    project_root = Path(path).resolve() if path else Path.cwd()
    project_root.mkdir(parents=True, exist_ok=True)
    config_path = project_root / "agentops.yaml"

    # Check existing config
    if config_path.exists() and not force:
        console.print("[red]✗[/red] agentops.yaml already exists. Use --force to overwrite.")
        raise typer.Exit(code=1)

    # Auto-detect framework
    detected_framework = _detect_framework(project_root)
    if framework is None:
        framework = detected_framework
    framework_label = ""
    if framework is None:
        if no_interactive:
            framework = Framework.CUSTOM
            framework_label = "custom (default)"
        else:
            framework = Framework.CUSTOM
            framework_label = "custom"
    else:
        framework_label = framework.value
        if detected_framework and framework == detected_framework:
            framework_label += " (auto-detected)"

    # Use case
    if use_case is None:
        if no_interactive:
            console.print("[red]✗[/red] --use-case is required in --no-interactive mode.")
            raise typer.Exit(code=2)
        use_case = UseCase.RAG  # Default

    # ── Endpoint / .env ──
    if endpoint is None and not no_interactive:
        endpoint = Prompt.ask(
            "[cyan]Azure AI Foundry project endpoint[/cyan] (Enter to skip)",
            default="",
            console=console,
        ).strip()
        if not endpoint:
            endpoint = None  # user skipped

    if endpoint:
        _write_env_file(project_root, endpoint)

    # Derive project name from directory
    project_name = project_root.name.lower().replace(" ", "-")
    # Sanitize to match CFG-002 pattern
    project_name = re.sub(r"[^a-z0-9._-]", "-", project_name)
    if not project_name or not project_name[0].isalnum():
        project_name = "my-agent"

    # Create directories
    dirs = [
        project_root / "agentops" / "bundles",
        project_root / "agentops" / "datasets",
        project_root / "agentops" / "runs",
        project_root / "agentops" / "reports",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)

    # Write agentops.yaml
    config_data = _generate_config(project_name, use_case, framework, entry_point)
    with open(config_path, "w", encoding="utf-8") as f:
        _yaml.dump(config_data, f)

    # Write sample dataset
    _write_sample_dataset(project_root / "agentops" / "datasets")

    # Print success
    bundle_name = _DEFAULT_BUNDLE.get(use_case, "rag_quality")
    from agentops_toolkit.core.bundle_registry import BundleRegistry

    registry = BundleRegistry()
    bundle = registry.get(bundle_name)
    evaluator_count = len(bundle.evaluators)

    console.print()
    console.print(
        Panel(
            f"[green]✓[/green] AgentOps initialized for project [bold]'{project_name}'[/bold]\n"
            f"  Use case:  {use_case.value}\n"
            f"  Framework: {framework_label}\n"
            f"  Bundle:    {bundle_name} ({evaluator_count} evaluators)",
            title="[bold]AgentOps[/bold]",
            border_style="green",
        )
    )
    # Show .env status
    if endpoint:
        console.print("  [green]✓[/green] .env saved with endpoint")

    console.print()
    console.print("  [dim]Next steps:[/dim]")
    console.print("    1. Add your test data to agentops/datasets/golden_set.jsonl")
    if not endpoint:
        console.print("    2. Run [bold]az login[/bold] and add endpoint to .env")
        console.print("    3. Run: [bold]agentops eval run[/bold]")
    else:
        console.print("    2. Run [bold]az login[/bold]")
        console.print("    3. Run: [bold]agentops eval run[/bold]")
    console.print("    4. View results: [bold]agentops report show latest[/bold]")
    console.print()
