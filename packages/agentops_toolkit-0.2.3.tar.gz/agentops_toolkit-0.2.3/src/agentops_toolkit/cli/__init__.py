"""CLI entry point and command registration."""
