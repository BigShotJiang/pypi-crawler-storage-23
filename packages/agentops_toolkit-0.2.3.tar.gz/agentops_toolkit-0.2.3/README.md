# AgentOps Toolkit

> **Evaluate, trace, and monitor AI agents on Azure AI Foundry — from your terminal.**

AgentOps Toolkit is an open-source CLI that helps you evaluate AI agent applications using [Azure AI Foundry](https://ai.azure.com) evaluators. Pick a pre-built evaluator bundle for your use case (RAG, tool-using agent, multi-agent), point it at a dataset, and get a quality + safety scorecard in seconds.

```bash
pip install agentops-toolkit
```

---

## Table of Contents

[Quick Start](#quick-start) · [Sample Data](#sample-data) · [Hands-On Tutorials](#hands-on-tutorials) · [Installation](#installation) · [Core Concepts](#core-concepts) · [Command Reference](#command-reference) · [Configuration](#configuration) · [Evaluator Bundles](#evaluator-bundles) · [Custom Evaluators](#custom-evaluators) · [CI/CD Integration](#cicd-integration) · [Observability](#observability) · [Framework Support](#framework-support) · [Dataset Format](#dataset-format) · [Architecture](#architecture) · [Development](#development)

---

## Quick Start

### 1. Initialize your project

```bash
agentops init --path ./my-rag-app --use-case rag

# Azure AI Foundry project endpoint (Enter to skip): https://my-proj.cognitiveservices.azure.com/
# ✓ AgentOps initialized for project 'my-rag-app'
#   Use case:  rag
#   Framework: custom
#   Bundle:    rag_quality (4 evaluators)
# ✓ .env saved with endpoint
```

The init wizard:
- Scaffolds directories + `agentops.yaml` config
- Prompts for your Azure AI Foundry endpoint and saves it to `.env`
- Auto-detects your framework from `pyproject.toml`

```
my-rag-app/
├── .env                                    # AZURE_AI_FOUNDRY_PROJECT_ENDPOINT
├── agentops.yaml                           # Project configuration
└── agentops/
    ├── bundles/                            # Custom bundle definitions
    ├── datasets/
    │   └── golden_set.jsonl                # Sample dataset (replace with yours)
    ├── runs/                               # Evaluation run outputs
    └── reports/                            # Exported reports
```

> **Tip:** Pass `--path ./my-project` to create the project in a new directory.
> Omit it to initialize the current directory.

### 2. Prepare your dataset

Create a JSONL file where each line is a test case. The `response` field contains the agent output you want to evaluate:

```jsonl
{"query": "What is the refund policy?", "context": "Returns accepted within 30 days.", "response": "You can return items within 30 days.", "ground_truth": "Returns accepted within 30 days."}
{"query": "How do I reset my password?", "context": "Go to Settings > Security > Reset Password.", "response": "Navigate to Settings, then Security, and click Reset Password.", "ground_truth": "Go to Settings > Security > Reset Password."}
```

Replace the sample `agentops/datasets/golden_set.jsonl` with your data, or use `--dataset` to point to any file.

### 3. Authenticate with Azure

```bash
# Sign in with Azure CLI — AgentOps uses DefaultAzureCredential
az login
```

If you skipped the endpoint prompt during `init`, add it to `.env` manually:

```env
AZURE_AI_FOUNDRY_PROJECT_ENDPOINT=https://<your-project>.cognitiveservices.azure.com/
```

AgentOps automatically loads `.env` at startup — no manual `export` needed.

### 4. Run evaluation

```bash
agentops eval run
```

This evaluates your dataset against the default bundle (`rag_quality`: groundedness, relevance, coherence, fluency) and displays a rich scorecard:

```
✓ Run 'default' completed (2026-02-26_a1b2c3d4)

  5/5 entries successful (0 errors, 0 skipped)

  Evaluator        Mean   Median  Min   Max   Pass Rate
  ────────────────────────────────────────────────────────
  groundedness     4.20   4.0     3.0   5.0   100%
  relevance        4.50   5.0     3.0   5.0   100%
  coherence        4.10   4.0     3.0   5.0   100%
  fluency          4.70   5.0     4.0   5.0   100%

  Aggregate score: 4.38
  Overall pass rate: 100%
```

### 5. Export a report

```bash
agentops report export latest --format markdown --output report.md
agentops report export latest --format json --output report.json
agentops report export latest --format csv --output report.csv
```

---

## Sample Data

AgentOps ships ready-to-use sample datasets in the [`samples/`](samples/) directory so you can try the toolkit immediately:

| Dataset                                                                            | Use Case         | Entries | Description                                                                         |
| ---------------------------------------------------------------------------------- | ---------------- | ------- | ----------------------------------------------------------------------------------- |
| [`samples/rag/eval_dataset.jsonl`](samples/rag/eval_dataset.jsonl)                 | RAG              | 10      | Customer support Q&A — refund policies, password resets, shipping, billing          |
| [`samples/agent/eval_dataset.jsonl`](samples/agent/eval_dataset.jsonl)             | Tool-using Agent | 8       | Single agent with tool calls — flight booking, weather, email triage, health checks |
| [`samples/multi-agent/eval_dataset.jsonl`](samples/multi-agent/eval_dataset.jsonl) | Multi-Agent      | 5       | Multi-agent orchestration — event planning, competitor research, debugging          |

Use them directly:

```bash
# Import into your project
agentops dataset import samples/rag/eval_dataset.jsonl

# Or point to them at eval time
agentops eval run --dataset samples/rag/eval_dataset.jsonl --bundle rag_quality
```

---

## Hands-On Tutorials

<details>
<summary><strong>Tutorial 1: Evaluate a RAG App</strong> — init → import data → evaluate → export report</summary>

```bash
# Step 1 — Create a new project (prompts for endpoint → saved to .env)
agentops init --path ./my-rag-app --use-case rag
cd my-rag-app

# Step 2 — Import the sample RAG dataset (10 entries)
agentops dataset import ../samples/rag/eval_dataset.jsonl

# Step 3 — Validate the dataset against the bundle's expected fields
agentops dataset validate eval_dataset --bundle rag_quality

# Step 4 — Inspect what evaluators are in the bundle
agentops bundle show rag_quality
# → groundedness, relevance, coherence, fluency (thresholds: 3.0 each)

# Step 5 — Authenticate and run the evaluation
az login
agentops eval run --dataset agentops/datasets/eval_dataset.jsonl --bundle rag_quality

# Step 6 — View results
agentops report show latest
agentops report show latest --verbose  # per-entry detail

# Step 7 — Export
agentops report export latest --format markdown --output rag_report.md
agentops report export latest --format csv --output rag_scores.csv
```

**What to look for:** Groundedness = response supported by context. Relevance = actually answers the question. Coherence & fluency = language quality.

</details>

<details>
<summary><strong>Tutorial 2: Evaluate a Tool-Using Agent</strong> — agent_quality bundle with tool_call_accuracy</summary>

```bash
agentops init --path ./my-agent-app --use-case agent
cd my-agent-app
agentops dataset import ../samples/agent/eval_dataset.jsonl
agentops eval run --dataset agentops/datasets/eval_dataset.jsonl --bundle agent_quality
agentops report show latest
```

**Tip:** The `context` field contains tool call traces (inputs + outputs). Evaluators check whether the agent's response is consistent with tool results.

</details>

<details>
<summary><strong>Tutorial 3: Add Safety Checks</strong> — rag_complete bundle (10 evaluators: quality + safety)</summary>

```bash
agentops eval run --dataset agentops/datasets/eval_dataset.jsonl --bundle rag_complete
agentops report show latest --evaluator hate_unfairness
agentops report show latest --evaluator violence
```

Safety evaluators (hate_unfairness, sexual, violence, self_harm, protected_material) score content risk 1–5. Higher = safer. Entries below 3.0 are flagged.

</details>

<details>
<summary><strong>Tutorial 4: Gate Your CI Pipeline</strong> — fail builds when quality drops</summary>

```bash
# Enable threshold gating in agentops.yaml → runs.fail_on_threshold: true
agentops config cicd --platform github-actions
```

**Real-world flow:**
1. Developer opens a PR that changes the RAG prompt
2. CI runs `agentops eval run` against the golden dataset
3. Groundedness drops from 4.2 → 2.8 (below 3.0 threshold)
4. Build fails with a report showing which evaluator regressed
5. Developer fixes the prompt before merging

</details>

---

## Installation

Requires **Python 3.12+** and an **Azure AI Foundry project**.

```bash
# Core toolkit
pip install agentops-toolkit

# With OpenTelemetry tracing + Azure Monitor support
pip install agentops-toolkit[observability]

# With IQ knowledge layer evaluators (Azure AI Search)
pip install agentops-toolkit[iq]

# Everything
pip install agentops-toolkit[observability,iq]
```

### Prerequisites

- Azure AI Foundry project with evaluation APIs enabled
- **Azure CLI** — run `az login` (AgentOps authenticates via `DefaultAzureCredential`)
- Set `AZURE_AI_FOUNDRY_PROJECT_ENDPOINT` environment variable (or configure in `agentops.yaml`)

---

## Core Concepts

| Concept       | Description                                                                                             |
| ------------- | ------------------------------------------------------------------------------------------------------- |
| **Bundle**    | A named set of evaluators + thresholds for a specific use case. AgentOps ships 13 built-in bundles.     |
| **Dataset**   | A JSONL/CSV/JSON file of test cases with `query`, `context`, `response`, and optional `ground_truth`.   |
| **Run**       | One execution of evaluation — a dataset scored against a bundle. Persisted as JSON in `agentops/runs/`. |
| **Evaluator** | An Azure AI Foundry evaluator (e.g. groundedness, relevance) that scores agent outputs on a 1–5 scale.  |
| **Report**    | A formatted view of run results — table, JSON, Markdown, or CSV.                                        |

---

## Command Reference

| Command                                       | Description                                                          |
| --------------------------------------------- | -------------------------------------------------------------------- |
| `agentops init [--path DIR]`                  | Scaffold a new project with config, sample data, and `.env` endpoint |
| `agentops eval run`                           | Evaluate a dataset against an evaluator bundle                       |
| `agentops run list\|show`                     | List or inspect past evaluation runs                                 |
| `agentops report show\|export`                | View or export reports (table, JSON, Markdown, CSV)                  |
| `agentops bundle list\|show`                  | Browse the 13 built-in evaluator bundles                             |
| `agentops dataset validate\|describe\|import` | Validate, inspect, or import datasets                                |
| `agentops config validate\|show\|cicd`        | Check config, generate CI/CD pipelines                               |
| `agentops trace init`                         | Set up OpenTelemetry tracing (cloud or local)                        |
| `agentops monitor setup\|dashboard\|alert`    | Production monitoring dashboards and alerts                          |
| `agentops model list\|recommend\|benchmark`   | Model lifecycle management via Foundry                               |

<details>
<summary><strong>agentops init</strong> — project scaffolding</summary>

```bash
agentops init --path ./my-project                    # init in a new directory
agentops init --use-case rag --framework semantic-kernel
agentops init --endpoint https://my-proj.cognitiveservices.azure.com/
agentops init --no-interactive --endpoint https://...  # CI-friendly
agentops init --force                             # overwrite existing agentops.yaml
```

| Option                | Description                                                |
| --------------------- | ---------------------------------------------------------- |
| `--path`, `-p`        | Target directory (created if needed). Defaults to `.`      |
| `--use-case`, `-u`    | `rag`, `agent`, or `multi-agent`                           |
| `--framework`, `-f`   | `semantic-kernel`, `autogen`, `agent-service`, or `custom` |
| `--endpoint`          | Azure AI Foundry endpoint URL — saved to `.env`            |
| `--entry-point`, `-e` | Agent entry point file (default: `src/agent.py`)           |
| `--no-interactive`    | Skip prompts — fail if required values are missing         |
| `--force`             | Overwrite existing config                                  |

In interactive mode, the wizard prompts for the endpoint and saves it to `.env`.
Framework is auto-detected from `pyproject.toml` or `requirements.txt` when not specified.

</details>

<details>
<summary><strong>agentops eval</strong> — run evaluations</summary>

```bash
agentops eval run
agentops eval run --dataset data/test.jsonl --bundle rag_quality
agentops eval run --format json
```

| Option            | Description                                 |
| ----------------- | ------------------------------------------- |
| `--dataset`, `-d` | Path to dataset file (JSONL)                |
| `--bundle`, `-b`  | Evaluator bundle name                       |
| `--config`, `-c`  | Config file path (default: `agentops.yaml`) |
| `--format`, `-f`  | Output format: `table` (default) or `json`  |

</details>

<details>
<summary><strong>agentops run</strong> — manage past runs</summary>

```bash
agentops run list
agentops run list --format json --limit 10
agentops run show 2026-02-26_a1b2c3d4
agentops run show 2026-02-26_a1b2c3d4 --format json
```

</details>

<details>
<summary><strong>agentops report</strong> — view & export reports</summary>

```bash
agentops report show latest
agentops report show latest --verbose
agentops report show latest --evaluator groundedness
agentops report export latest --format json --output report.json
agentops report export latest --format markdown --output report.md
agentops report export latest --format csv --output scores.csv
```

Formats: `table` (terminal), `json` (automation), `markdown` (PR comments), `csv` (spreadsheets).

</details>

<details>
<summary><strong>agentops bundle</strong> — browse evaluator bundles</summary>

```bash
agentops bundle list
agentops bundle list --use-case rag
agentops bundle show rag_quality
agentops bundle show rag_safety --format json
```

See [Evaluator Bundles](#evaluator-bundles) for the full catalog.

</details>

<details>
<summary><strong>agentops dataset</strong> — validate & inspect datasets</summary>

```bash
agentops dataset validate agentops/datasets/golden_set.jsonl
agentops dataset validate golden_set --bundle rag_quality
agentops dataset describe agentops/datasets/golden_set.jsonl
agentops dataset import /path/to/external_data.jsonl
```

</details>

<details>
<summary><strong>agentops config</strong> — configuration & CI/CD</summary>

```bash
agentops config validate
agentops config show
agentops config show --format json
agentops config cicd --platform github-actions
agentops config cicd --platform azure-devops
```

</details>

<details>
<summary><strong>agentops trace / monitor / model</strong> — observability & model management</summary>

```bash
# Tracing (requires agentops-toolkit[observability])
agentops trace init --project-endpoint $FOUNDRY_PROJECT_ENDPOINT
agentops trace init --local --otlp http://localhost:4317

# Monitoring
agentops monitor setup --service-name my-agent
agentops monitor dashboard --template agent-overview
agentops monitor alert create --name "quality-drop" --metric "eval.groundedness.avg" --operator lt --threshold 3.5

# Model lifecycle (requires Foundry MCP Server)
agentops model list --capability chat
agentops model recommend --current gpt-4o
agentops model benchmark --from gpt-4o --to gpt-4.1
```

</details>

---

## Configuration

All settings live in a single `agentops.yaml` at the project root. `${VAR}` references are resolved from environment variables or a `.env` file (auto-loaded from the project root).

<details>
<summary><strong>.env file</strong></summary>

Create a `.env` file alongside `agentops.yaml`:

```env
AZURE_AI_FOUNDRY_PROJECT_ENDPOINT=https://<your-project>.cognitiveservices.azure.com/
# AGENTOPS_LOG_LEVEL=debug
# AGENTOPS_MAX_CONCURRENCY=4
```

AgentOps loads this file automatically. Add `.env` to `.gitignore` to avoid committing secrets.

</details>

<details>
<summary><strong>Full agentops.yaml example</strong></summary>

```yaml
schema_version: "1.0"

project:
  name: my-rag-agent

foundry:
  project_endpoint: ${AZURE_AI_FOUNDRY_PROJECT_ENDPOINT}  # az login provides credentials

agent:
  framework: semantic-kernel    # or: autogen, agent-service, custom
  use_case: rag                 # or: agent, multi-agent
  entry_point: src/agent.py

datasets:
  default: golden_set
  entries:
    - name: golden_set
      path: agentops/datasets/golden_set.jsonl
      format: jsonl

bundles:
  default: rag_quality

runs:
  output_dir: agentops/runs
  auto_report: true
  fail_on_threshold: false      # set to true for CI gating
```

</details>

<details>
<summary><strong>Environment variables</strong></summary>

| Variable                            | Description                                                                                   |
| ----------------------------------- | --------------------------------------------------------------------------------------------- |
| `AZURE_AI_FOUNDRY_PROJECT_ENDPOINT` | Azure AI Foundry project endpoint URL (credentials via `az login` / `DefaultAzureCredential`) |
| `AGENTOPS_CONFIG`                   | Override config file path                                                                     |
| `AGENTOPS_LOG_LEVEL`                | Logging level: `debug`, `info`, `warning`, `error`                                            |
| `AGENTOPS_MAX_CONCURRENCY`          | Max concurrent evaluator calls                                                                |
| `AGENTOPS_TIMEOUT`                  | Per-entry timeout in seconds                                                                  |
| `AGENTOPS_OUTPUT_DIR`               | Override run output directory                                                                 |

</details>

---

## Evaluator Bundles

AgentOps ships 13 built-in evaluator bundles. Each bundle is a curated set of Azure AI Foundry evaluators with sensible thresholds.

### RAG (Retrieval-Augmented Generation)

| Bundle                  | Evaluators                                                       | Description                     |
| ----------------------- | ---------------------------------------------------------------- | ------------------------------- |
| `rag_quality`           | groundedness, relevance, coherence, fluency                      | Core quality metrics            |
| `rag_safety`            | hate_unfairness, sexual, violence, self_harm, protected_material | Safety screening                |
| `rag_complete`          | All 10 quality + safety evaluators                               | Comprehensive evaluation        |
| `rag_foundry_iq`        | Quality + Foundry IQ knowledge evaluators                        | For Foundry IQ knowledge bases  |
| `rag_agentic_retrieval` | Quality + agentic retrieval evaluators                           | For agentic retrieval pipelines |
| `rag_permission_aware`  | Quality + ACL enforcement evaluators                             | For permission-aware RAG        |
| `rag_fabric_iq`         | Quality + Fabric IQ evaluators                                   | For Fabric IQ ontologies        |
| `rag_work_iq`           | Quality + M365 evaluators                                        | For Work IQ / M365 data         |
| `rag_cross_iq`          | Quality + multi-source evaluators                                | For multi-IQ source evaluation  |

### Agent & Multi-Agent

| Bundle                | Evaluators                                                           | Description                      |
| --------------------- | -------------------------------------------------------------------- | -------------------------------- |
| `agent_quality`       | groundedness, relevance, coherence, tool_call_accuracy               | Tool-using agents                |
| `agent_safety`        | Safety evaluators for agents                                         | Agent safety screening           |
| `multi_agent_quality` | groundedness, relevance, coherence, task_completion, handoff_quality | Orchestrated multi-agent systems |

### Custom

| Bundle   | Evaluators | Description                           |
| -------- | ---------- | ------------------------------------- |
| `custom` | (empty)    | Template for building your own bundle |

View any bundle's details:

```bash
agentops bundle show rag_quality
```

---

## Custom Evaluators

Define custom bundles in `agentops.yaml` and implement scoring in Python.

<details>
<summary><strong>YAML definition + Python implementation</strong></summary>

**agentops.yaml:**
```yaml
bundles:
  default: my_bundle
  custom:
    - name: my_bundle
      description: "Domain-specific evaluation"
      evaluators:
        - name: groundedness
          type: foundry
          threshold: 4.0
        - name: domain_accuracy
          type: custom
          module: evaluators.domain
          class: DomainAccuracyEvaluator
```

**evaluators/domain.py:**
```python
from agentops_toolkit.evaluators.base import CustomEvaluator
from agentops_toolkit.models.run import EvalResult

class DomainAccuracyEvaluator(CustomEvaluator):
    name = "domain_accuracy"
    required_columns = ["query", "response", "ground_truth"]
    score_range = (0.0, 1.0)

    async def evaluate(self, input_data: dict) -> EvalResult:
        score = compute_similarity(input_data["response"], input_data["ground_truth"])
        return EvalResult(evaluator_name=self.name, score=score, passed=score >= 0.8)
```

</details>

---

## CI/CD Integration

Generate a GitHub Actions or Azure DevOps pipeline with one command:

```bash
agentops config cicd --platform github-actions
agentops config cicd --platform azure-devops
```

Set `fail_on_threshold: true` in `agentops.yaml` to fail builds when scores drop below thresholds.

<details>
<summary><strong>GitHub Actions workflow example</strong></summary>

```yaml
name: Agent Evaluation
on: [pull_request]

jobs:
  evaluate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install agentops-toolkit
      - name: Run evaluation
        run: agentops eval run --format json
        env:
          AZURE_AI_FOUNDRY_PROJECT_ENDPOINT: ${{ secrets.AZURE_AI_FOUNDRY_PROJECT_ENDPOINT }}
          AZURE_CLIENT_ID: ${{ secrets.AZURE_CLIENT_ID }}
          AZURE_TENANT_ID: ${{ secrets.AZURE_TENANT_ID }}
          AZURE_CLIENT_SECRET: ${{ secrets.AZURE_CLIENT_SECRET }}
      - name: Post report to PR
        run: agentops report export latest --format markdown >> $GITHUB_STEP_SUMMARY
```

</details>

---

## Observability

OpenTelemetry tracing (cloud or local) + Azure Monitor dashboards and alert rules. Auto-instruments OpenAI SDK, Semantic Kernel, and LangChain.

```bash
agentops trace init --project-endpoint $FOUNDRY_PROJECT_ENDPOINT   # cloud
agentops trace init --local --otlp http://localhost:4317            # local
agentops monitor dashboard --template agent-overview               # dashboards
agentops monitor alert create --name "quality-drop" --metric "eval.groundedness.avg" --operator lt --threshold 3.5
```

> Requires `pip install agentops-toolkit[observability]`

---

## Framework Support

Auto-detects your agent framework from project dependencies: **Semantic Kernel**, **AutoGen**, **Azure AI Agent Service**, or use the **generic adapter** for any framework.

```python
from agentops_toolkit.adapters.generic import GenericAdapter
adapter = GenericAdapter(func=my_agent_function)
result = adapter.invoke("What is the refund policy?")
```

---

## Dataset Format

JSONL (recommended) — one JSON object per line with `query`, `context`, `response`, and optional `ground_truth` / `id` fields. Entries without `response` are automatically skipped.

```jsonl
{"id": "001", "query": "What is X?", "context": "X is a thing.", "response": "X is a thing.", "ground_truth": "X is a thing."}
```

See [`samples/`](samples/) for complete, ready-to-use examples.

---

## Architecture

```mermaid
graph TD
    CLI["<b>agentops CLI</b><br/>init | eval | run | report | bundle | ..."]

    CLI --> ConfigLoader["Config Loader<br/><i>YAML + env resolution</i>"]
    CLI --> Pipeline["Pipeline<br/><i>load → evaluate → report</i>"]
    CLI --> BundleRegistry["Bundle Registry<br/><i>13 built-in + custom</i>"]

    Pipeline --> FoundryEval["Foundry Evaluator<br/>Wrapper"]
    Pipeline --> CustomEval["Custom Evaluator<br/><i>(user-defined)</i>"]
    Pipeline --> Adapters["Framework Adapters<br/><i>SK / AutoGen / Agent Service</i>"]

    FoundryEval --> Foundry["<b>Azure AI Foundry</b><br/>Evaluation SDK<br/><i>groundedness, relevance, coherence, ...</i>"]

    style CLI fill:#4A90D9,stroke:#2C5F8A,color:#fff
    style ConfigLoader fill:#6DB56D,stroke:#3D7A3D,color:#fff
    style Pipeline fill:#6DB56D,stroke:#3D7A3D,color:#fff
    style BundleRegistry fill:#6DB56D,stroke:#3D7A3D,color:#fff
    style FoundryEval fill:#E8A838,stroke:#B37D1E,color:#fff
    style CustomEval fill:#E8A838,stroke:#B37D1E,color:#fff
    style Adapters fill:#E8A838,stroke:#B37D1E,color:#fff
    style Foundry fill:#D94A4A,stroke:#8A2C2C,color:#fff
```

<details>
<summary><strong>Key modules</strong></summary>

| Module                                  | Purpose                                                  |
| --------------------------------------- | -------------------------------------------------------- |
| `agentops_toolkit.cli`                  | Typer CLI commands                                       |
| `agentops_toolkit.core.pipeline`        | Load dataset → evaluate → aggregate → persist            |
| `agentops_toolkit.core.config_loader`   | YAML parsing, env var resolution, Pydantic validation    |
| `agentops_toolkit.core.bundle_registry` | Built-in + custom evaluator bundles                      |
| `agentops_toolkit.evaluators.base`      | BaseEvaluator, FoundryEvaluatorWrapper, CustomEvaluator  |
| `agentops_toolkit.models`               | Pydantic models for config, runs, datasets, bundles      |
| `agentops_toolkit.obs`                  | OpenTelemetry tracing + Azure Monitor                    |
| `agentops_toolkit.adapters`             | Framework adapters (SK, AutoGen, Agent Service, Generic) |

</details>

---

## Development

```bash
# Clone
git clone https://github.com/mcaps-microsoft/agentops-toolkit.git
cd agentops-toolkit

# Install with dev dependencies
pip install -e ".[dev]"

# Run tests (206 tests: 159 unit + 47 e2e)
pytest tests/

# Run only e2e tests
pytest tests/e2e/

# Lint
ruff check src/ tests/

# Type check
mypy src/
```

---

## Contributing

Contributions are welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## License

[MIT](LICENSE)

---

<sub>Built on [Azure AI Foundry](https://ai.azure.com). Designed for developers who ship agents to production.</sub>
