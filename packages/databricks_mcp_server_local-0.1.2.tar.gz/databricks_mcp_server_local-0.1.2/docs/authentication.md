# Authentication Setup Guide

This guide covers all authentication methods supported by the Databricks MCP server.

## Overview

The Databricks MCP server supports multiple authentication methods:

1. **Personal Access Token** (Recommended) - Most secure and straightforward
2. **OAuth / Unified Authentication** - Automatic authentication via Databricks SDK
3. **Notebook-native Authentication** - When running inside Databricks notebooks

## Method 1: Personal Access Token (Recommended)

### Creating a Personal Access Token

1. **Log into your Databricks workspace**
   - Navigate to `https://your-workspace.cloud.databricks.com`

2. **Access User Settings**
   - Click your username in the top right corner
   - Select **User Settings** from the dropdown

3. **Navigate to Access Tokens**
   - Click on the **Access Tokens** tab

4. **Generate New Token**
   - Click **Generate New Token**
   - Enter a comment/description (e.g., "Databricks MCP Integration")
   - Set an expiration period (optional, recommended for security)
     - Leave blank for no expiration (not recommended for production)
     - Set to 30, 60, or 90 days for better security
   - Click **Generate**

5. **Copy the Token**
   - **IMPORTANT**: Copy the token immediately - it's only shown once!
   - Store it securely (password manager, secure note, etc.)

### Configuring the Token

Add the token to your `.env` file:

```bash
DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
DATABRICKS_TOKEN=dapi1234567890abcdefghijklmnopqrstuvwxyz
```

Or set it as an environment variable:

```bash
export DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
export DATABRICKS_TOKEN=dapi1234567890abcdefghijklmnopqrstuvwxyz
```

### Token Permissions

Personal Access Tokens inherit the permissions of the user who created them. Ensure your user account has:

- **Workspace access** - To read/write notebooks and files
- **Cluster management** - To manage clusters
- **Job management** - To create and run jobs
- **SQL warehouse access** - To execute SQL queries

## Method 2: OAuth / Unified Authentication

The Databricks SDK supports unified authentication that automatically detects credentials from multiple sources.

### Using Databricks CLI

1. **Install Databricks CLI**
   ```bash
   pip install databricks-cli
   ```

2. **Authenticate**
   ```bash
   databricks auth login
   ```
   This will open your browser to authenticate and store credentials in `~/.databrickscfg`

3. **The SDK will automatically use these credentials**
   - No additional configuration needed in `.env`
   - Just set `DATABRICKS_HOST` if needed

### Using Environment Variables

Set these environment variables:

```bash
export DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
export DATABRICKS_TOKEN=your_token_here
```

Or for Azure Databricks:

```bash
export DATABRICKS_HOST=https://adb-1234567890123456.7.azuredatabricks.net
export AZURE_CLIENT_ID=your_client_id
export AZURE_CLIENT_SECRET=your_client_secret
export AZURE_TENANT_ID=your_tenant_id
```

### Using .databrickscfg File

Create `~/.databrickscfg`:

```ini
[DEFAULT]
host = https://your-workspace.cloud.databricks.com
token = your_personal_access_token
```

Or for Azure:

```ini
[DEFAULT]
host = https://adb-1234567890123456.7.azuredatabricks.net
azure_workspace_resource_id = /subscriptions/.../resourceGroups/.../providers/Microsoft.Databricks/workspaces/...
azure_client_id = your_client_id
azure_client_secret = your_client_secret
azure_tenant_id = your_tenant_id
```

## Method 3: Notebook-Native Authentication

When running inside a Databricks notebook, authentication is automatic. The SDK detects the notebook context and uses the current user's credentials.

**Note**: This method only works when the MCP server is running inside a Databricks notebook environment.

## Account-Level Operations

For account-level operations (managing multiple workspaces), you may need:

```bash
DATABRICKS_ACCOUNT_ID=your_account_id
DATABRICKS_HOST=https://accounts.cloud.databricks.com
```

Use account-level Personal Access Tokens for these operations.

## Environment Variable Reference

### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABRICKS_HOST` | Your Databricks workspace URL | `https://your-workspace.cloud.databricks.com` |

### Authentication Variables (choose one method)

| Variable | Description | When to Use |
|----------|-------------|-------------|
| `DATABRICKS_TOKEN` | Personal Access Token | Standard workspace operations |
| `DATABRICKS_ACCOUNT_ID` | Account ID | Account-level operations |
| `AZURE_CLIENT_ID` | Azure Client ID | Azure Databricks |
| `AZURE_CLIENT_SECRET` | Azure Client Secret | Azure Databricks |
| `AZURE_TENANT_ID` | Azure Tenant ID | Azure Databricks |

### Optional Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABRICKS_CLUSTER_ID` | Default cluster ID | `1234-567890-abc123` |
| `DATABRICKS_WAREHOUSE_ID` | Default SQL warehouse ID | `abc123def456` |

## Security Best Practices

1. **Use Personal Access Tokens** - More secure than password authentication
2. **Set Token Expiration** - Rotate tokens regularly (30-90 days)
3. **Use Least Privilege** - Grant only necessary permissions
4. **Never Commit Tokens** - Keep `.env` files out of version control
5. **Use Environment Variables** - Prefer environment variables over hardcoding
6. **Rotate Regularly** - Change tokens according to your security policy
7. **Monitor Token Usage** - Review token usage in User Settings periodically
8. **Use Separate Tokens** - Create different tokens for different purposes/environments

## Troubleshooting Authentication

### "Authentication failed" Error

1. **Verify Token Format**
   - Personal Access Tokens start with `dapi`
   - Check for extra spaces or newlines
   - Ensure the token hasn't expired

2. **Check Workspace URL**
   - Must include `https://`
   - No trailing slash
   - Correct workspace URL (not account URL)

3. **Verify Permissions**
   - Token must have appropriate permissions
   - User account must have workspace access

### "Connection timeout" Error

1. **Check Network Connectivity**
   - Ensure you can access the Databricks workspace in a browser
   - Check firewall/proxy settings

2. **Verify Workspace URL**
   - Workspace must be accessible from your network
   - Check for VPN requirements

### OAuth Not Working

1. **Check Databricks CLI**
   ```bash
   databricks auth login
   databricks clusters list  # Test authentication
   ```

2. **Verify .databrickscfg**
   - File exists at `~/.databrickscfg`
   - Contains valid credentials
   - Format is correct (INI format)

## Additional Resources

- [Databricks Authentication Documentation](https://docs.databricks.com/en/dev-tools/auth/index.html)
- [Personal Access Tokens Guide](https://docs.databricks.com/en/dev-tools/auth/pat.html)
- [Databricks CLI Authentication](https://docs.databricks.com/en/dev-tools/cli/auth.html)
- [Azure Databricks Authentication](https://docs.databricks.com/en/dev-tools/auth/azure.html)
