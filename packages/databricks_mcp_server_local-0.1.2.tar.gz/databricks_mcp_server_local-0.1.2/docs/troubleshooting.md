# Troubleshooting Guide

Common issues and solutions for the Databricks MCP server.

## Connection Issues

### MCP Server Not Connecting in Cursor

**Symptoms:**
- MCP server shows as disconnected in Cursor
- No tools available in Composer
- Error messages in Cursor logs

**Solutions:**

1. **Verify Configuration**
   - Check that `config/cursor-mcp-config.json` exists and is valid JSON
   - Ensure the configuration is added to Cursor Settings > Features > MCP Servers
   - Verify environment variables are set correctly

2. **Restart Cursor**
   - Close Cursor completely
   - Reopen Cursor IDE
   - Check MCP server status indicator

3. **Check Python Path**
   - Verify Python is in your PATH: `which python3`
   - Update the `command` in MCP config if needed:
     ```json
     "command": "/usr/local/bin/python3"
     ```

4. **Verify Package Installation**
   ```bash
   pip list | grep databricks-mcp-server-local
   python3 -m databricks_mcp.server --help
   ```

### "Module not found" Error

**Symptoms:**
- `ModuleNotFoundError: No module named 'databricks_mcp'`
- `ModuleNotFoundError: No module named 'fastmcp'`

**Solutions:**

1. **Install Dependencies**
   ```bash
   pip install -e .
   # or
   pip install fastmcp databricks-sdk python-dotenv
   ```

2. **Check Python Environment**
   - Ensure you're using the correct Python interpreter
   - Use virtual environment if needed:
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     pip install -e .
     ```

3. **Update Cursor Config**
   - Point to the correct Python with packages installed
   - Use full path to Python executable if needed

## Authentication Problems

### "Authentication failed" Error

**Symptoms:**
- `ValueError: Failed to initialize Databricks client`
- `401 Unauthorized` errors
- Connection validation fails

**Solutions:**

1. **Verify Token**
   - Check token format (starts with `dapi`)
   - Ensure no extra spaces or newlines
   - Verify token hasn't expired

2. **Check Environment Variables**
   ```bash
   echo $DATABRICKS_HOST
   echo $DATABRICKS_TOKEN
   ```
   - Ensure variables are set correctly
   - No quotes around values in `.env` file

3. **Test Authentication**
   ```bash
   ./scripts/verify-connection.sh
   ```

4. **Try OAuth**
   - Use Databricks CLI: `databricks auth login`
   - Remove `DATABRICKS_TOKEN` from `.env` to use OAuth

### "Invalid workspace URL" Error

**Symptoms:**
- `ValueError: DATABRICKS_HOST environment variable is required`
- Connection fails with URL-related errors

**Solutions:**

1. **Check URL Format**
   - Must start with `https://`
   - No trailing slash
   - Correct workspace URL (not account URL)
   - Example: `https://your-workspace.cloud.databricks.com`

2. **Verify Workspace Access**
   - Test URL in browser
   - Ensure you have access to the workspace
   - Check VPN/proxy requirements

## Tool Execution Issues

### "Cluster not found" Error

**Symptoms:**
- `404 Not Found` when accessing clusters
- Cluster operations fail

**Solutions:**

1. **Verify Cluster ID**
   - Use correct cluster ID format
   - Check cluster exists: `list_clusters()` tool

2. **Check Permissions**
   - Ensure your token/user has cluster access
   - Verify cluster is in accessible workspace

### "Notebook not found" Error

**Symptoms:**
- `404 Not Found` when accessing notebooks
- Notebook operations fail

**Solutions:**

1. **Verify Path**
   - Use absolute path: `/Users/user@example.com/notebook`
   - Check path exists: `list_workspace()` tool
   - Ensure correct case and spelling

2. **Check Permissions**
   - Verify read/write permissions
   - Ensure notebook is in accessible workspace

### SQL Query Execution Fails

**Symptoms:**
- `execute_sql` returns errors
- Query execution times out

**Solutions:**

1. **Verify Warehouse ID**
   - Use correct warehouse ID
   - Check warehouse exists: `list_sql_warehouses()` tool
   - Ensure warehouse is running

2. **Check SQL Syntax**
   - Verify query syntax is correct
   - Test query in Databricks SQL editor first
   - Check for syntax errors

3. **Warehouse State**
   - Ensure SQL warehouse is running
   - Check warehouse status in Databricks UI

## Performance Issues

### Slow Tool Execution

**Symptoms:**
- Tools take a long time to respond
- Timeouts occur

**Solutions:**

1. **Check Network**
   - Verify network connectivity
   - Check for VPN/proxy delays
   - Test Databricks API directly

2. **Reduce Data Size**
   - Limit results in queries
   - Use pagination for large lists
   - Filter results when possible

3. **Check Workspace Load**
   - Databricks workspace may be under heavy load
   - Try again later
   - Check Databricks status page

## MCP Server Startup Issues

### Server Won't Start

**Symptoms:**
- MCP server fails to initialize
- Error on startup

**Solutions:**

1. **Check Python Version**
   ```bash
   python3 --version  # Should be 3.9+
   ```

2. **Verify Dependencies**
   ```bash
   pip install --upgrade fastmcp databricks-sdk python-dotenv
   ```

3. **Check Logs**
   - Review Cursor logs for detailed error messages
   - Run server directly: `python3 -m databricks_mcp.server`
   - Check for import errors

4. **Environment Variables**
   - Ensure `.env` file exists
   - Verify all required variables are set
   - Check for syntax errors in `.env`

### Import Errors

**Symptoms:**
- `ImportError` on startup
- Missing module errors

**Solutions:**

1. **Reinstall Package**
   ```bash
   pip uninstall databricks-mcp-server-local
   pip install -e .
   ```

2. **Check Python Path**
   - Ensure correct Python is used
   - Verify virtual environment if used

3. **Update Dependencies**
   ```bash
   pip install --upgrade -r requirements.txt
   ```

## Configuration Issues

### Environment Variables Not Loading

**Symptoms:**
- Variables not found
- Default values used instead

**Solutions:**

1. **Check .env File**
   - File exists in project root
   - No syntax errors
   - Variables formatted correctly (no spaces around `=`)

2. **Load Manually**
   ```bash
   export DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
   export DATABRICKS_TOKEN=your_token
   ```

3. **Use Cursor Config**
   - Set variables in `cursor-mcp-config.json` `env` section
   - Restart Cursor after changes

### Cursor Config Not Working

**Symptoms:**
- MCP server not appearing in Cursor
- Configuration not applied

**Solutions:**

1. **Verify JSON Format**
   - Check for syntax errors
   - Validate JSON format
   - Ensure proper nesting

2. **Check Cursor Settings**
   - Configuration added to correct location
   - No duplicate entries
   - Restart Cursor after changes

3. **Use Example Config**
   - Copy from `config/cursor-mcp-config.json.example`
   - Update with your values
   - Ensure all required fields present

## Getting Help

If you're still experiencing issues:

1. **Check Logs**
   - Cursor logs: Help > Toggle Developer Tools > Console
   - Server logs: Run server directly to see errors

2. **Verify Setup**
   ```bash
   ./scripts/verify-connection.sh
   ```

3. **Test Components**
   ```bash
   python3 -c "from databricks.sdk import WorkspaceClient; client = WorkspaceClient(); print(client.current_user.me())"
   ```

4. **Review Documentation**
   - [Authentication Guide](authentication.md)
   - [Usage Examples](usage-examples.md)
   - [Databricks SDK Docs](https://docs.databricks.com/en/dev-tools/sdk-python.html)

5. **Report Issues**
   - Check existing issues on GitHub
   - Create new issue with:
     - Error messages
     - Steps to reproduce
     - Environment details (Python version, OS, etc.)

## BrokenResourceError / "Found 0 tools" on Startup

**Symptoms:**
- MCP server crashes when Cursor sends `ListToolsRequest`
- Log shows `anyio.BrokenResourceError` in `stdin_reader`
- Cursor reports "Found 0 tools, 0 prompts, and 0 resources"

**Cause:** Known stdio transport issue when Cursor connects—parallel requests can break the pipe. Buffering can also cause the connection to close prematurely.

**Solutions:**

1. **Use unbuffered Python** - Update your Cursor MCP config to add `-u` flag and `PYTHONUNBUFFERED`:
   ```json
   {
     "mcpServers": {
       "databricks-mcp-server-local": {
         "command": "python",
         "args": ["-u", "-m", "databricks_mcp.server"],
         "env": {
           "DATABRICKS_HOST": "https://your-workspace.cloud.databricks.com",
           "DATABRICKS_TOKEN": "your_token",
           "PYTHONUNBUFFERED": "1"
         }
       }
     }
   }
   ```

2. **Upgrade FastMCP** - Ensure you have FastMCP 2.14+:
   ```bash
   pip install --upgrade "fastmcp>=2.14.0"
   ```

3. **Restart Cursor fully** - Close all windows and reopen to clear stale MCP connections.

4. **Use project-specific Python** - If using pyenv/venv, ensure the `command` in MCP config points to the Python that has databricks-mcp-server-local installed (e.g. absolute path to project venv).

## Common Error Messages

| Error | Cause | Solution |
|-------|-------|----------|
| `DATABRICKS_HOST environment variable is required` | Missing workspace URL | Set `DATABRICKS_HOST` in `.env` |
| `Failed to initialize Databricks client` | Authentication failed | Check token and workspace URL |
| `ModuleNotFoundError` | Missing dependencies | Run `pip install -e .` |
| `401 Unauthorized` | Invalid token | Regenerate token and update `.env` |
| `404 Not Found` | Resource doesn't exist | Verify resource ID/path |
| `Connection timeout` | Network issue | Check connectivity and firewall |
