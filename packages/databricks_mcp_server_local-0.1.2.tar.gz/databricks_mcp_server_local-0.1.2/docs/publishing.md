# Publishing databricks-mcp-server-local to PyPI

This guide walks you through publishing the package to PyPI safely.

## Prerequisites

1. **PyPI account** – Create one at [pypi.org](https://pypi.org/account/register/)
2. **Test PyPI account** (recommended) – Create one at [test.pypi.org](https://test.pypi.org/account/register/)
3. **Python 3.9+** with `build` and `twine` installed

## Security Checklist (Critical)

**Before every publish**, verify that no sensitive data will be included:

- [ ] **`.env`** – Must NOT exist in the build. It's in `.gitignore` and `MANIFEST.in` exclusions.
- [ ] **`config/cursor-mcp-config.json`** – Contains credentials. Must NOT be committed or published. It's in `.gitignore`.
- [ ] **No real tokens** – Search the repo: `grep -r "dapi" . --include="*.py" --include="*.json" --include="*.md"` (excluding `.git`). Placeholders like `your_personal_access_token_here` are fine.
- [ ] **Rotate exposed tokens** – If `config/cursor-mcp-config.json` or `.env` were ever committed, rotate those tokens immediately in Databricks User Settings.

### Verify Build Contents

Before publishing, inspect what will be included:

```bash
# Build the package (creates dist/ folder)
python -m build

# Inspect the source distribution contents
tar -tzf dist/databricks_mcp_server_local-*.tar.gz | head -50

# Confirm .env and cursor-mcp-config.json (without .example) are NOT in the list
# Note: cursor-mcp-config.json.example is safe (placeholders only)
tar -tzf dist/databricks_mcp_server_local-*.tar.gz | grep -E "/\.env$|/cursor-mcp-config\.json$" | grep -v "\.example" && echo "⚠️ SECURITY: Sensitive files found!" || echo "✅ No sensitive files in build"
```

## Step 1: Install Build Tools

```bash
pip install build twine
```

## Step 2: Configure PyPI Authentication

### Option A: API Token (Recommended)

1. Go to [pypi.org/manage/account](https://pypi.org/manage/account/)
2. Create an API token (scope: entire account or specific project)
3. Create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_API_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TEST_TOKEN_HERE
```

**Security:** Add `~/.pypirc` to `.gitignore` (already excluded via `MANIFEST.in`). Never commit this file.

### Option B: Environment Variable

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-YOUR_API_TOKEN_HERE
```

## Step 3: Bump Version (if needed)

Edit `pyproject.toml` and update the version:

```toml
version = "0.1.1"  # Increment for each release
```

Follow [Semantic Versioning](https://semver.org/): MAJOR.MINOR.PATCH.

## Step 4: Build the Package

```bash
# Clean previous builds
rm -rf dist/ build/ src/*.egg-info

# Build source distribution and wheel
python -m build
```

This creates:
- `dist/databricks-mcp-server-local-X.Y.Z.tar.gz` (source)
- `dist/databricks_mcp_server_local-X.Y.Z-py3-none-any.whl` (wheel)

## Step 5: Test on Test PyPI First

```bash
twine upload --repository testpypi dist/*
```

Then test the install:

```bash
pip install --index-url https://test.pypi.org/simple/ databricks-mcp-server-local
databricks-mcp-server-local  # Verify it runs
```

## Step 6: Publish to PyPI

```bash
twine upload dist/*
```

Or with explicit repository:

```bash
twine upload --repository pypi dist/*
```

## Step 7: Verify Publication

1. Check [pypi.org/project/databricks-mcp-server-local](https://pypi.org/project/databricks-mcp-server-local/)
2. Test install: `pip install databricks-mcp-server-local`
3. Test uvx: `uvx databricks-mcp-server-local`

## Post-Publish

- Tag the release in git: `git tag v0.1.0 && git push origin v0.1.0`
- Update the GitHub repo URLs in `pyproject.toml` if you have a real repository
- Consider setting up GitHub Actions for automated publishing on release

## Troubleshooting

| Error | Solution |
|-------|----------|
| `File already exists` | Version already published. Bump version in `pyproject.toml`. |
| `Invalid or non-existent authentication` | Check `~/.pypirc` or `TWINE_PASSWORD`. |
| `403 Forbidden` | Verify API token has upload permissions. |
| Package name taken | Choose a different name or coordinate with existing maintainer. |

## Files Never to Publish

These are excluded via `.gitignore` and `MANIFEST.in`:

- `.env` – Local credentials
- `.env.local`, `.env.*.local`
- `config/cursor-mcp-config.json` – Generated config with tokens
- `*.token`, `*.key`, `.pypirc`
- `*.pem`, `*.p12` – Certificates
