# Usage Examples

Example queries and use cases for the Databricks MCP server.

## Notebook Management

### List Notebooks

**Query:**
```
List all notebooks in my workspace
```

**Alternative:**
```
Show me all Python notebooks in /Users/user@example.com
```

**What it does:**
- Lists all notebooks in the workspace
- Can filter by path or language
- Returns notebook paths and metadata

### Get Notebook Content

**Query:**
```
Get the content of notebook /Users/user@example.com/my_notebook
```

**Alternative:**
```
Show me what's in /Users/user@example.com/data_analysis
```

**What it does:**
- Retrieves notebook content
- Shows code cells and metadata
- Useful for reviewing or copying code

### Create Notebook

**Query:**
```
Create a new Python notebook at /Users/user@example.com/test_notebook with code 'print("Hello, Databricks!")'
```

**Alternative:**
```
Create a SQL notebook called daily_report at /Users/user@example.com/
```

**What it does:**
- Creates a new notebook
- Sets initial content
- Supports Python, Scala, SQL, and R

### Run Notebook

**Query:**
```
Run notebook /Users/user@example.com/data_pipeline with parameters {'date': '2024-01-01', 'table': 'sales'}
```

**What it does:**
- Executes notebook with parameters
- Returns execution ID
- Can monitor execution status

### Delete Notebook

**Query:**
```
Delete notebook /Users/user@example.com/old_notebook
```

**What it does:**
- Removes notebook from workspace
- Cannot be undone (be careful!)

## Cluster Management

### List Clusters

**Query:**
```
List all clusters in my workspace
```

**Alternative:**
```
Show me all running clusters
```

**What it does:**
- Lists all clusters
- Shows cluster state, size, and configuration
- Useful for monitoring cluster usage

### Get Cluster Details

**Query:**
```
Show me details of cluster abc-123-def-456
```

**What it does:**
- Returns detailed cluster information
- Includes configuration, state, and metadata
- Useful for troubleshooting

### Create Cluster

**Query:**
```
Create a new cluster named 'production-cluster' with Spark version 13.3.x-scala2.12, node type i3.xlarge, and 2 workers
```

**Alternative:**
```
Create a single-node cluster called 'dev-cluster' with Spark 13.3.x
```

**What it does:**
- Creates new cluster configuration
- Sets Spark version, node types, and worker count
- Cluster starts automatically

### Start/Stop Cluster

**Query:**
```
Start cluster abc-123-def-456
```

**Alternative:**
```
Stop cluster abc-123-def-456
```

**What it does:**
- Starts or stops cluster
- Useful for cost management
- Can restart stopped clusters

### Restart Cluster

**Query:**
```
Restart cluster abc-123-def-456
```

**What it does:**
- Restarts cluster
- Useful after configuration changes
- Clears cluster state

## Job Management

### List Jobs

**Query:**
```
List all jobs in my workspace
```

**Alternative:**
```
Show me the last 10 jobs
```

**What it does:**
- Lists all jobs
- Shows job names, IDs, and configuration
- Can limit number of results

### Get Job Details

**Query:**
```
Show me details of job 12345
```

**What it does:**
- Returns job configuration
- Shows tasks, schedule, and settings
- Useful for understanding job setup

### Create Job

**Query:**
```
Create a job named 'daily-data-pipeline' that runs notebook /Users/user@example.com/pipeline on cluster abc-123
```

**Alternative:**
```
Create a job to run my notebook with Spark 13.3.x and 2 workers
```

**What it does:**
- Creates new job configuration
- Links notebook to cluster
- Sets up execution parameters

### Run Job

**Query:**
```
Run job 12345 with parameters {'date': '2024-01-01'}
```

**What it does:**
- Triggers job execution
- Returns run ID
- Can override default parameters

### Get Job Run Status

**Query:**
```
What's the status of job run 67890?
```

**Alternative:**
```
Check if job run 67890 completed successfully
```

**What it does:**
- Returns run status and details
- Shows execution state and results
- Useful for monitoring job execution

### Delete Job

**Query:**
```
Delete job 12345
```

**What it does:**
- Removes job configuration
- Does not delete run history
- Cannot be undone

## SQL Operations

### List SQL Warehouses

**Query:**
```
List all SQL warehouses
```

**What it does:**
- Lists all SQL warehouses
- Shows warehouse IDs, names, and states
- Useful for finding warehouse IDs

### Execute SQL Query

**Query:**
```
Execute SQL query 'SELECT * FROM sales_table LIMIT 10' on warehouse abc123def456
```

**Alternative:**
```
Run SQL query 'SELECT COUNT(*) FROM users WHERE created_date > '2024-01-01'' on my default warehouse
```

**What it does:**
- Executes SQL query on SQL warehouse
- Returns query results
- Supports any SQL syntax

### Get Query History

**Query:**
```
Show me recent query history
```

**Alternative:**
```
List the last 20 queries executed on warehouse abc123
```

**What it does:**
- Returns query execution history
- Shows query text, status, and execution time
- Useful for monitoring and debugging

### Create Saved Query

**Query:**
```
Create a saved query named 'daily_report' with SQL 'SELECT * FROM sales WHERE date = CURRENT_DATE' on warehouse abc123
```

**What it does:**
- Creates reusable query
- Saves query for later use
- Can add description

### Get Query Details

**Query:**
```
Show me details of query query-123-456
```

**What it does:**
- Returns saved query details
- Shows query text and metadata
- Useful for reviewing queries

## Workspace Operations

### List Workspace

**Query:**
```
List files in /Users/user@example.com
```

**Alternative:**
```
Show me everything in my workspace recursively
```

**What it does:**
- Lists workspace files and directories
- Can list recursively
- Shows object types and paths

### Read File

**Query:**
```
Read the content of /Users/user@example.com/script.py
```

**Alternative:**
```
Get the content of notebook /Users/user@example.com/analysis
```

**What it does:**
- Reads file content
- Supports notebooks, Python files, etc.
- Returns file contents as text

### Create File

**Query:**
```
Create a new file at /Users/user@example.com/test.py with content 'print("Hello")'
```

**What it does:**
- Creates new workspace file
- Sets initial content
- Supports various file types

### Delete File

**Query:**
```
Delete file /Users/user@example.com/old_file.py
```

**Alternative:**
```
Delete directory /Users/user@example.com/old_folder recursively
```

**What it does:**
- Deletes file or directory
- Can delete recursively
- Cannot be undone

### List Repositories

**Query:**
```
List all Git repositories in my workspace
```

**What it does:**
- Lists Git repositories
- Shows repo paths and URLs
- Useful for managing repos

## Complex Workflows

### Data Pipeline Setup

**Query:**
```
Create a job named 'daily-etl' that runs notebook /Users/user@example.com/etl_pipeline on a new cluster with Spark 13.3.x, i3.xlarge nodes, and 2 workers. Then run the job with parameters {'date': '2024-01-01'}
```

**What it does:**
- Creates complete ETL pipeline setup
- Combines multiple operations
- Useful for automation

### Cluster Management Workflow

**Query:**
```
List all clusters, then stop any clusters that have been idle for more than 2 hours
```

**What it does:**
- Monitors cluster usage
- Manages costs
- Can be automated

### Notebook Backup

**Query:**
```
List all notebooks in /Users/user@example.com, get their content, and save summaries
```

**What it does:**
- Backs up notebook contents
- Creates documentation
- Useful for version control

## Best Practices

1. **Use Specific Paths**
   - Always use full paths: `/Users/user@example.com/notebook`
   - Avoid relative paths

2. **Verify Before Delete**
   - List resources before deleting
   - Double-check paths and IDs

3. **Monitor Long Operations**
   - Check job/cluster status regularly
   - Use appropriate timeouts

4. **Use Parameters**
   - Parameterize notebooks and jobs
   - Makes workflows reusable

5. **Error Handling**
   - Check operation results
   - Handle errors gracefully

6. **Resource Management**
   - Stop unused clusters
   - Clean up old jobs
   - Monitor costs

## Tips and Tricks

- **Combine Operations**: You can chain multiple operations in a single query
- **Use Variables**: Reference previous results in follow-up queries
- **Check Status**: Always verify operation status before proceeding
- **Test First**: Test operations on non-production resources first
- **Document Paths**: Keep track of important notebook/job paths

## Getting More Help

- Review [Authentication Guide](authentication.md) for setup issues
- Check [Troubleshooting Guide](troubleshooting.md) for common problems
- See [Databricks Documentation](https://docs.databricks.com) for API details
