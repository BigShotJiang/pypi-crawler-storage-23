"""Notebook management tools for Databricks MCP server."""

import json
import logging
from typing import Optional, Dict, Any
from databricks.sdk.service.workspace import Language, ObjectType, ExportFormat

logger = logging.getLogger(__name__)


def run_notebook(
    path: str,
    parameters: Optional[str] = None,
    timeout_seconds: Optional[int] = None,
    client: Any = None,
) -> Dict[str, Any]:
    """
    Execute a notebook with optional parameters.
    
    Args:
        path: Path to the notebook (e.g., /Users/user@example.com/my_notebook)
        parameters: JSON string of parameters to pass to the notebook
        timeout_seconds: Timeout in seconds (default: 300)
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Execution result with run_id and status
    """
    try:
        if parameters:
            params_dict = json.loads(parameters)
        else:
            params_dict = {}
        
        timeout = timeout_seconds or 300
        
        # Use Jobs API to run notebook as a one-time job
        # This is a more reliable approach than command execution
        from databricks.sdk.service.jobs import CreateJob, NotebookTask, Task
        from databricks.sdk.service.compute import CreateCluster
        
        # Get first available cluster or create job with new cluster
        clusters = list(client.clusters.list())
        if clusters and clusters[0].cluster_id:
            cluster_id = clusters[0].cluster_id
        else:
            raise ValueError("No clusters available. Please create a cluster first or use Jobs API with cluster creation.")
        
        # Create a temporary job to run the notebook
        notebook_task = NotebookTask(
            notebook_path=path,
            base_parameters=[{"key": k, "value": str(v)} for k, v in params_dict.items()] if params_dict else None,
        )
        
        task = Task(
            task_key="run_notebook",
            notebook_task=notebook_task,
        )
        
        job_settings = CreateJob(
            name=f"mcp_notebook_run_{path.split('/')[-1]}",
            tasks=[task],
            timeout_seconds=timeout,
        )
        job_settings.existing_cluster_id = cluster_id
        
        job = client.jobs.create(**job_settings.as_dict())
        run = client.jobs.run_now(job_id=job.job_id)
        
        return {
            "status": "success",
            "run_id": run.run_id,
            "job_id": job.job_id,
            "message": "Notebook execution started via job",
        }
        
        return {
            "status": "success",
            "run_id": result.id if hasattr(result, "id") else "unknown",
            "message": "Notebook execution started",
        }
    except Exception as e:
        logger.error(f"Failed to run notebook {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def list_notebooks(path: str = "/", recursive: bool = True, client: Any = None) -> Dict[str, Any]:
    """
    List notebooks in the workspace.
    
    Args:
        path: Workspace path to list (default: /)
        recursive: Whether to list recursively (default: True)
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: List of notebooks with their paths and metadata
    """
    try:
        notebooks = []
        
        def list_recursive(current_path: str):
            try:
                objects = client.workspace.list(path=current_path)
                for obj in objects:
                    if obj.object_type == ObjectType.NOTEBOOK:
                        notebooks.append({
                            "path": obj.path,
                            "language": obj.language.name if obj.language else "unknown",
                            "object_type": obj.object_type.name,
                        })
                    elif obj.object_type == ObjectType.DIRECTORY and recursive:
                        list_recursive(obj.path)
            except Exception as e:
                logger.warning(f"Error listing {current_path}: {e}")
        
        list_recursive(path)
        
        return {
            "status": "success",
            "notebooks": notebooks,
            "count": len(notebooks),
        }
    except Exception as e:
        logger.error(f"Failed to list notebooks: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def get_notebook(path: str, client: Any = None) -> Dict[str, Any]:
    """
    Get notebook content and metadata.
    
    Args:
        path: Path to the notebook
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Notebook content and metadata
    """
    try:
        # Get notebook content (SDK returns ExportResponse with .content)
        export_result = client.workspace.export(path, format=ExportFormat.SOURCE)
        content = export_result.content if hasattr(export_result, "content") else (
            export_result.decode("utf-8") if isinstance(export_result, bytes) else str(export_result)
        )
        if isinstance(content, bytes):
            content = content.decode("utf-8")
        
        # Get notebook object info
        obj_info = None
        try:
            parent_path = "/".join(path.rstrip("/").split("/")[:-1]) or "/"
            for obj in client.workspace.list(path=parent_path):
                if obj.path == path:
                    obj_info = obj
                    break
        except Exception:
            pass
        
        language = "unknown"
        object_type = "notebook"
        if obj_info:
            language = getattr(obj_info.language, "name", None) or getattr(obj_info.language, "value", None) or str(obj_info.language) if obj_info.language else "unknown"
            object_type = getattr(obj_info.object_type, "name", None) or getattr(obj_info.object_type, "value", None) or str(obj_info.object_type) if obj_info.object_type else "notebook"
        
        return {
            "status": "success",
            "path": path,
            "content": content,
            "language": language,
            "object_type": object_type,
        }
    except Exception as e:
        logger.error(f"Failed to get notebook {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def create_notebook(
    path: str,
    content: str,
    language: str = "PYTHON",
    client: Any = None,
) -> Dict[str, Any]:
    """
    Create a new notebook.
    
    Args:
        path: Path where to create the notebook
        content: Notebook content (code)
        language: Language (PYTHON, SCALA, SQL, R) - default: PYTHON
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Creation result
    """
    try:
        lang_map = {
            "PYTHON": Language.PYTHON,
            "SCALA": Language.SCALA,
            "SQL": Language.SQL,
            "R": Language.R,
        }
        
        lang = lang_map.get(language.upper(), Language.PYTHON)
        
        import io
        from databricks.sdk.service.workspace import ImportFormat

        client.workspace.upload(
            path=path,
            content=io.BytesIO(content.encode("utf-8")),
            format=ImportFormat.SOURCE,
            language=lang,
            overwrite=False,
        )
        
        return {
            "status": "success",
            "path": path,
            "message": "Notebook created successfully",
        }
    except Exception as e:
        logger.error(f"Failed to create notebook {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def delete_notebook(path: str, client: Any = None) -> Dict[str, Any]:
    """
    Delete a notebook.
    
    Args:
        path: Path to the notebook to delete
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Deletion result
    """
    try:
        client.workspace.delete(path, recursive=False)
        
        return {
            "status": "success",
            "path": path,
            "message": "Notebook deleted successfully",
        }
    except Exception as e:
        logger.error(f"Failed to delete notebook {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }
