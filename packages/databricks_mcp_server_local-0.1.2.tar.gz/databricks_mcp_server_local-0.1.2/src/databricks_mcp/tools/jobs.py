"""Job management tools for Databricks MCP server."""

import json
import logging
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


def list_jobs(limit: int = 20, client: Any = None) -> Dict[str, Any]:
    """
    List all jobs in the workspace.
    
    Args:
        limit: Maximum number of jobs to return (default: 20)
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: List of jobs with their details
    """
    try:
        jobs = []
        for job in client.jobs.list(limit=limit):
            jobs.append({
                "job_id": job.job_id,
                "job_name": job.settings.name if hasattr(job, "settings") and job.settings else "unknown",
                "creator_user_name": job.creator_user_name if hasattr(job, "creator_user_name") else None,
                "timeout_seconds": job.settings.timeout_seconds if hasattr(job, "settings") and hasattr(job.settings, "timeout_seconds") else None,
                "max_concurrent_runs": job.settings.max_concurrent_runs if hasattr(job, "settings") and hasattr(job.settings, "max_concurrent_runs") else None,
            })
        
        return {
            "status": "success",
            "jobs": jobs,
            "count": len(jobs),
        }
    except Exception as e:
        logger.error(f"Failed to list jobs: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def get_job(job_id: int, client: Any = None) -> Dict[str, Any]:
    """
    Get detailed information about a specific job.
    
    Args:
        job_id: The job ID
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Job details
    """
    try:
        job = client.jobs.get(job_id=job_id)
        
        job_info = {
            "job_id": job.job_id,
            "creator_user_name": job.creator_user_name if hasattr(job, "creator_user_name") else None,
            "settings": {},
        }
        
        if hasattr(job, "settings") and job.settings:
            settings = job.settings
            job_info["settings"]["name"] = settings.name if hasattr(settings, "name") else None
            job_info["settings"]["timeout_seconds"] = settings.timeout_seconds if hasattr(settings, "timeout_seconds") else None
            job_info["settings"]["max_concurrent_runs"] = settings.max_concurrent_runs if hasattr(settings, "max_concurrent_runs") else None
            job_info["settings"]["tasks"] = []
            
            if hasattr(settings, "tasks") and settings.tasks:
                for task in settings.tasks:
                    task_info = {
                        "task_key": task.task_key if hasattr(task, "task_key") else None,
                        "description": task.description if hasattr(task, "description") else None,
                    }
                    if hasattr(task, "notebook_task"):
                        task_info["type"] = "notebook"
                        task_info["notebook_path"] = task.notebook_task.notebook_path if hasattr(task.notebook_task, "notebook_path") else None
                    elif hasattr(task, "spark_python_task"):
                        task_info["type"] = "python"
                    elif hasattr(task, "spark_jar_task"):
                        task_info["type"] = "jar"
                    elif hasattr(task, "spark_submit_task"):
                        task_info["type"] = "spark_submit"
                    job_info["settings"]["tasks"].append(task_info)
        
        return {
            "status": "success",
            "job": job_info,
        }
    except Exception as e:
        logger.error(f"Failed to get job {job_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def create_job(
    name: str,
    notebook_path: Optional[str] = None,
    cluster_id: Optional[str] = None,
    spark_version: Optional[str] = None,
    node_type_id: Optional[str] = None,
    parameters: Optional[str] = None,
    timeout_seconds: Optional[int] = None,
    client: Any = None,
) -> Dict[str, Any]:
    """
    Create a new job.
    
    Args:
        name: Job name
        notebook_path: Path to notebook to run (required if no other task type)
        cluster_id: Existing cluster ID (or specify spark_version/node_type_id for new cluster)
        spark_version: Spark version for new cluster
        node_type_id: Node type for new cluster
        parameters: JSON string of parameters to pass to notebook
        timeout_seconds: Job timeout in seconds
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Created job details
    """
    try:
        from databricks.sdk.service.jobs import (
            CreateJob,
            NotebookTask,
            Task,
        )
        
        if not notebook_path:
            raise ValueError("notebook_path is required")
        
        # Parse parameters
        params_list = []
        if parameters:
            params_dict = json.loads(parameters)
            params_list = [{"key": k, "value": str(v)} for k, v in params_dict.items()]
        
        # Create notebook task
        notebook_task = NotebookTask(
            notebook_path=notebook_path,
            base_parameters=params_list if params_list else None,
        )
        
        # Create task
        task = Task(
            task_key="run_notebook",
            notebook_task=notebook_task,
        )
        
        # Create job settings
        job_settings = CreateJob(
            name=name,
            tasks=[task],
            timeout_seconds=timeout_seconds,
        )
        
        # Configure cluster
        if cluster_id:
            job_settings.existing_cluster_id = cluster_id
        elif spark_version and node_type_id:
            from databricks.sdk.service.compute import CreateCluster
            job_settings.new_cluster = CreateCluster(
                spark_version=spark_version,
                node_type_id=node_type_id,
                num_workers=0,
            )
        else:
            raise ValueError("Either cluster_id or both spark_version and node_type_id must be provided")
        
        job = client.jobs.create(**job_settings.as_dict())
        
        return {
            "status": "success",
            "job_id": job.job_id,
            "job_name": name,
            "message": "Job created successfully",
        }
    except Exception as e:
        logger.error(f"Failed to create job: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def run_job(
    job_id: int,
    parameters: Optional[str] = None,
    client: Any = None,
) -> Dict[str, Any]:
    """
    Trigger a job run.
    
    Args:
        job_id: The job ID to run
        parameters: JSON string of parameters to override job defaults
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Run details with run_id
    """
    try:
        params_dict = {}
        if parameters:
            params_dict = json.loads(parameters)
        
        run = client.jobs.run_now(
            job_id=job_id,
            notebook_params=params_dict if params_dict else None,
        )
        
        return {
            "status": "success",
            "run_id": run.run_id,
            "number_in_job": run.number_in_job if hasattr(run, "number_in_job") else None,
            "message": "Job run triggered successfully",
        }
    except Exception as e:
        logger.error(f"Failed to run job {job_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def get_job_run(run_id: int, client: Any = None) -> Dict[str, Any]:
    """
    Get status and details of a job run.
    
    Args:
        run_id: The run ID
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Run details and status
    """
    try:
        run = client.jobs.get_run(run_id=run_id)
        
        run_info = {
            "run_id": run.run_id,
            "job_id": run.job_id if hasattr(run, "job_id") else None,
            "run_name": run.run_name if hasattr(run, "run_name") else None,
            "state": {
                "life_cycle_state": run.state.life_cycle_state.value if run.state and hasattr(run.state, "life_cycle_state") else "unknown",
                "result_state": run.state.result_state.value if run.state and hasattr(run.state, "result_state") else None,
                "state_message": run.state.state_message if run.state and hasattr(run.state, "state_message") else None,
            } if run.state else None,
            "start_time": run.start_time if hasattr(run, "start_time") else None,
            "end_time": run.end_time if hasattr(run, "end_time") else None,
        }
        
        return {
            "status": "success",
            "run": run_info,
        }
    except Exception as e:
        logger.error(f"Failed to get job run {run_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def delete_job(job_id: int, client: Any = None) -> Dict[str, Any]:
    """
    Delete a job.
    
    Args:
        job_id: The job ID to delete
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Deletion result
    """
    try:
        client.jobs.delete(job_id=job_id)
        
        return {
            "status": "success",
            "job_id": job_id,
            "message": "Job deleted successfully",
        }
    except Exception as e:
        logger.error(f"Failed to delete job {job_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }
