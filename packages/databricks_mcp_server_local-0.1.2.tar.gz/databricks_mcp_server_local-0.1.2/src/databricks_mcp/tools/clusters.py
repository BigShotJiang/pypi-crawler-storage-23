"""Cluster management tools for Databricks MCP server."""

import logging
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


def list_clusters(client: Any = None) -> Dict[str, Any]:
    """
    List all clusters in the workspace.
    
    Args:
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: List of clusters with their details
    """
    try:
        clusters = []
        for cluster in client.clusters.list():
            clusters.append({
                "cluster_id": cluster.cluster_id,
                "cluster_name": cluster.cluster_name,
                "state": cluster.state.value if cluster.state else "unknown",
                "spark_version": cluster.spark_version,
                "node_type_id": cluster.node_type_id,
                "num_workers": cluster.num_workers if hasattr(cluster, "num_workers") else 0,
                "driver_node_type_id": cluster.driver_node_type_id if hasattr(cluster, "driver_node_type_id") else None,
                "autotermination_minutes": cluster.autotermination_minutes if hasattr(cluster, "autotermination_minutes") else None,
            })
        
        return {
            "status": "success",
            "clusters": clusters,
            "count": len(clusters),
        }
    except Exception as e:
        logger.error(f"Failed to list clusters: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def get_cluster(cluster_id: str, client: Any = None) -> Dict[str, Any]:
    """
    Get detailed information about a specific cluster.
    
    Args:
        cluster_id: The cluster ID
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Cluster details
    """
    try:
        cluster = client.clusters.get(cluster_id=cluster_id)
        
        return {
            "status": "success",
            "cluster": {
                "cluster_id": cluster.cluster_id,
                "cluster_name": cluster.cluster_name,
                "state": cluster.state.value if cluster.state else "unknown",
                "spark_version": cluster.spark_version,
                "node_type_id": cluster.node_type_id,
                "num_workers": cluster.num_workers if hasattr(cluster, "num_workers") else 0,
                "driver_node_type_id": cluster.driver_node_type_id if hasattr(cluster, "driver_node_type_id") else None,
                "autotermination_minutes": cluster.autotermination_minutes if hasattr(cluster, "autotermination_minutes") else None,
                "cluster_source": cluster.cluster_source.value if hasattr(cluster, "cluster_source") else None,
                "cluster_log_conf": str(cluster.cluster_log_conf) if hasattr(cluster, "cluster_log_conf") else None,
            },
        }
    except Exception as e:
        logger.error(f"Failed to get cluster {cluster_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def create_cluster(
    cluster_name: str,
    spark_version: str,
    node_type_id: str,
    num_workers: int = 0,
    autotermination_minutes: Optional[int] = 60,
    driver_node_type_id: Optional[str] = None,
    client: Any = None,
) -> Dict[str, Any]:
    """
    Create a new cluster.
    
    Args:
        cluster_name: Name for the cluster
        spark_version: Spark version (e.g., "13.3.x-scala2.12")
        node_type_id: Node type ID (e.g., "i3.xlarge")
        num_workers: Number of worker nodes (0 for single-node)
        autotermination_minutes: Minutes of inactivity before termination
        driver_node_type_id: Driver node type (optional, defaults to node_type_id)
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Created cluster details
    """
    try:
        from databricks.sdk.service.compute import CreateCluster
        
        create_cluster_config = CreateCluster(
            cluster_name=cluster_name,
            spark_version=spark_version,
            node_type_id=node_type_id,
            num_workers=num_workers,
            autotermination_minutes=autotermination_minutes,
        )
        
        if driver_node_type_id:
            create_cluster_config.driver_node_type_id = driver_node_type_id
        
        cluster = client.clusters.create(**create_cluster_config.as_dict())
        
        return {
            "status": "success",
            "cluster_id": cluster.cluster_id,
            "cluster_name": cluster.cluster_name,
            "message": "Cluster created successfully",
        }
    except Exception as e:
        logger.error(f"Failed to create cluster: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def start_cluster(cluster_id: str, client: Any = None) -> Dict[str, Any]:
    """
    Start a cluster.
    
    Args:
        cluster_id: The cluster ID to start
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Start operation result
    """
    try:
        client.clusters.start(cluster_id=cluster_id)
        
        return {
            "status": "success",
            "cluster_id": cluster_id,
            "message": "Cluster start requested",
        }
    except Exception as e:
        logger.error(f"Failed to start cluster {cluster_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def stop_cluster(cluster_id: str, client: Any = None) -> Dict[str, Any]:
    """
    Stop/terminate a cluster.
    
    Args:
        cluster_id: The cluster ID to stop
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Stop operation result
    """
    try:
        client.clusters.delete(cluster_id=cluster_id)
        
        return {
            "status": "success",
            "cluster_id": cluster_id,
            "message": "Cluster termination requested",
        }
    except Exception as e:
        logger.error(f"Failed to stop cluster {cluster_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def restart_cluster(cluster_id: str, client: Any = None) -> Dict[str, Any]:
    """
    Restart a cluster.
    
    Args:
        cluster_id: The cluster ID to restart
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Restart operation result
    """
    try:
        client.clusters.restart(cluster_id=cluster_id)
        
        return {
            "status": "success",
            "cluster_id": cluster_id,
            "message": "Cluster restart requested",
        }
    except Exception as e:
        logger.error(f"Failed to restart cluster {cluster_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }
