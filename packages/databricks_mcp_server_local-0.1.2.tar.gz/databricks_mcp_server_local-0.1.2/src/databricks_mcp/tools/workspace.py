"""Workspace management tools for Databricks MCP server."""

import base64
import io
import json
import logging
import os
import re
import tempfile
import zipfile
from typing import Optional, Dict, Any, List
from databricks.sdk.service.workspace import ExportFormat

logger = logging.getLogger(__name__)


def list_workspace(path: str = "/", recursive: bool = False, client: Any = None) -> Dict[str, Any]:
    """
    List workspace files and objects.
    
    Args:
        path: Workspace path to list (default: /)
        recursive: Whether to list recursively (default: False)
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: List of workspace objects
    """
    try:
        objects = []
        
        def list_recursive(current_path: str, depth: int = 0):
            if depth > 10:  # Prevent infinite recursion
                return
            try:
                items = client.workspace.list(path=current_path)
                for item in items:
                    obj_info = {
                        "path": item.path,
                        "object_type": item.object_type.name if item.object_type else "unknown",
                        "language": item.language.name if hasattr(item, "language") and item.language else None,
                    }
                    objects.append(obj_info)
                    
                    if recursive and item.object_type.name == "DIRECTORY":
                        list_recursive(item.path, depth + 1)
            except Exception as e:
                logger.warning(f"Error listing {current_path}: {e}")
        
        list_recursive(path)
        
        return {
            "status": "success",
            "path": path,
            "objects": objects,
            "count": len(objects),
        }
    except Exception as e:
        logger.error(f"Failed to list workspace {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def read_file(path: str, format: str = "SOURCE", client: Any = None) -> Dict[str, Any]:
    """
    Read workspace file content.
    
    Args:
        path: Path to the file
        format: Format to export (SOURCE, HTML, JUPYTER, DBC) - default: SOURCE
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: File content and metadata
    """
    try:
        format_enum = ExportFormat.SOURCE
        if format and format.upper() != "SOURCE":
            format_enum = getattr(ExportFormat, format.upper(), ExportFormat.SOURCE)
        
        export_result = client.workspace.export(path=path, format=format_enum)
        content = export_result.content if hasattr(export_result, "content") else export_result
        
        # Decode if bytes
        if isinstance(content, bytes):
            content_str = content.decode("utf-8")
        else:
            content_str = str(content)
        
        return {
            "status": "success",
            "path": path,
            "format": format,
            "content": content_str,
        }
    except Exception as e:
        logger.error(f"Failed to read file {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def create_file(
    path: str,
    content: str,
    language: Optional[str] = None,
    format: str = "SOURCE",
    overwrite: bool = False,
    content_encoding: str = "utf8",
    client: Any = None,
) -> Dict[str, Any]:
    """
    Create a workspace file.

    Args:
        path: Path where to create the file
        content: File content (UTF-8 text or base64 when content_encoding=base64)
        language: Language for notebooks (PYTHON, SCALA, SQL, R)
        format: Format (SOURCE, HTML, JUPYTER, DBC) - default: SOURCE
        overwrite: Whether to overwrite if file exists
        content_encoding: "utf8" (default) or "base64" - use base64 when cloning from read_file
        client: Databricks WorkspaceClient instance

    Returns:
        dict: Creation result
    """
    try:
        from databricks.sdk.service.workspace import ImportFormat, Language

        lang = None
        if language:
            lang_map = {
                "PYTHON": Language.PYTHON,
                "SCALA": Language.SCALA,
                "SQL": Language.SQL,
                "R": Language.R,
            }
            lang = lang_map.get(language.upper())

        format_enum = getattr(ImportFormat, format.upper(), ImportFormat.SOURCE)
        if content_encoding and content_encoding.lower() == "base64":
            raw_bytes = base64.b64decode(content)
        else:
            raw_bytes = content.encode("utf-8") if isinstance(content, str) else content

        client.workspace.upload(
            path=path,
            content=io.BytesIO(raw_bytes),
            format=format_enum,
            language=lang,
            overwrite=overwrite,
        )
        
        return {
            "status": "success",
            "path": path,
            "message": "File created successfully",
        }
    except Exception as e:
        logger.error(f"Failed to create file {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def clone_file(
    source_path: str,
    target_path: str,
    format: str = "DBC",
    overwrite: bool = False,
    create_parent_dir: bool = True,
    client: Any = None,
) -> Dict[str, Any]:
    """
    Clone a workspace file or notebook to a new path. Performs read and write
    entirely on the server side to avoid MCP protocol size limits.

    Use format=DBC (default) to preserve notebook parameters/widgets. Use
    format=SOURCE for plain source-only copy.

    Args:
        source_path: Path to the source file or notebook
        target_path: Path where to create the clone (directory for DBC; file path for SOURCE)
        format: Export/import format (DBC, SOURCE, HTML, JUPYTER) - default: DBC
        overwrite: Whether to overwrite if target exists (ignored for DBC)
        create_parent_dir: Whether to create parent directory if it does not exist
        client: Databricks WorkspaceClient instance

    Returns:
        dict: Clone result
    """
    try:
        from databricks.sdk.service.workspace import ImportFormat, ExportFormat

        format_upper = (format or "DBC").upper()
        format_enum = getattr(ExportFormat, format_upper, ExportFormat.DBC)

        if format_upper == "DBC":
            raw_bytes = client.workspace.download(path=source_path, format=ExportFormat.DBC).read()
            import_path = target_path.rstrip("/")
            if create_parent_dir and import_path:
                parent = "/".join(import_path.split("/")[:-1])
                if parent:
                    try:
                        client.workspace.mkdirs(parent)
                    except Exception:
                        pass
            client.workspace.upload(
                path=import_path,
                content=io.BytesIO(raw_bytes),
                format=ImportFormat.DBC,
                overwrite=False,
            )
        else:
            export_result = client.workspace.export(path=source_path, format=format_enum)
            content = export_result.content if hasattr(export_result, "content") else export_result

            if isinstance(content, bytes):
                raw_bytes = content
            else:
                raw_bytes = base64.b64decode(content)

            if create_parent_dir:
                target_dir = "/".join(target_path.split("/")[:-1])
                if target_dir:
                    try:
                        client.workspace.mkdirs(target_dir)
                    except Exception:
                        pass

            lang = None
            try:
                status = client.workspace.get_status(path=source_path)
                if hasattr(status, "language") and status.language:
                    lang = status.language
            except Exception:
                pass

            import_format = getattr(ImportFormat, format_upper, ImportFormat.SOURCE)
            client.workspace.upload(
                path=target_path,
                content=io.BytesIO(raw_bytes),
                format=import_format,
                language=lang,
                overwrite=overwrite,
            )

        return {
            "status": "success",
            "source_path": source_path,
            "target_path": target_path,
            "message": "File cloned successfully",
        }
    except Exception as e:
        logger.error(f"Failed to clone {source_path} to {target_path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def _update_sql_param_placeholders(commands: List[Dict], params: Dict[str, str]) -> bool:
    """Replace ${param} placeholders in SQL/SQL-like commands. Returns True if any change made."""
    changed = False
    for cmd in commands:
        content = cmd.get("command", "")
        if not content:
            continue
        orig = content
        for param_name, param_value in params.items():
            placeholder = "${" + param_name + "}"
            if placeholder in content:
                content = content.replace(placeholder, param_value)
        if content != orig:
            cmd["command"] = content
            changed = True
    return changed


def _update_widgets_in_commands(commands: List[Dict], params: Dict[str, str]) -> bool:
    """Update widget default values in notebook commands. Returns True if any change made."""
    changed = False
    for cmd in commands:
        content = cmd.get("command", "")
        if not content:
            continue
        for param_name, param_value in params.items():
            escaped_value = param_value.replace("\\", "\\\\").replace('"', '\\"')
            text_pattern = rf'dbutils\.widgets\.text\("{re.escape(param_name)}",\s*"[^"]*"\)'
            dropdown_pattern = rf'dbutils\.widgets\.dropdown\("{re.escape(param_name)}",\s*"[^"]*"'
            content = re.sub(text_pattern, f'dbutils.widgets.text("{param_name}", "{escaped_value}")', content)
            content = re.sub(dropdown_pattern, f'dbutils.widgets.dropdown("{param_name}", "{escaped_value}"', content)
        if content != cmd.get("command", ""):
            cmd["command"] = content
            changed = True
    return changed


def _update_input_widgets(notebook: Dict, params: Dict[str, str]) -> bool:
    """Update inputWidgets dict (Databricks SQL parameter widgets). Returns True if any change made."""
    changed = False
    widgets = notebook.get("inputWidgets")
    if not isinstance(widgets, dict):
        return False
    for name, param_value in params.items():
        w = widgets.get(name)
        if not isinstance(w, dict):
            continue
        if w.get("currentValue") != param_value:
            w["currentValue"] = param_value
            changed = True
        wi = w.get("widgetInfo")
        if isinstance(wi, dict) and wi.get("defaultValue") != param_value:
            wi["defaultValue"] = param_value
            changed = True
        twi = w.get("typedWidgetInfo")
        if isinstance(twi, dict) and twi.get("defaultValue") != param_value:
            twi["defaultValue"] = param_value
            changed = True
    return changed


def _update_widget_definitions(notebook: Dict, params: Dict[str, str]) -> bool:
    """Update widget definitions in notebook JSON. Returns True if any change made."""
    changed = _update_input_widgets(notebook, params)
    for key in ("widgets", "parameterDefinitions", "widgetDefinitions"):
        widgets = notebook.get(key)
        if not isinstance(widgets, list):
            continue
        for w in widgets:
            if isinstance(w, dict):
                name = w.get("name")
                if name in params:
                    if "defaultValue" in w:
                        w["defaultValue"] = params[name]
                        changed = True
                    if "value" in w:
                        w["value"] = params[name]
                        changed = True
    return changed


def update_notebook_parameters(
    path: str,
    parameters: Dict[str, str],
    client: Any = None,
) -> Dict[str, Any]:
    """
    Update notebook widget/parameter default values. Works with DBC-format notebooks
    by modifying the notebook JSON inside the archive.

    Args:
        path: Path to the notebook in the workspace
        parameters: Dict mapping parameter names to values (e.g. {"Statsig_Experiment_Name": "exp_123"})
        client: Databricks WorkspaceClient instance

    Returns:
        dict: Update result
    """
    try:
        from databricks.sdk.service.workspace import ImportFormat, ExportFormat

        raw_bytes = client.workspace.download(path=path, format=ExportFormat.DBC).read()
        changed = False

        with tempfile.TemporaryDirectory() as tmpdir:
            with zipfile.ZipFile(io.BytesIO(raw_bytes), "r") as zf:
                zf.extractall(tmpdir)

            for root, _, files in os.walk(tmpdir):
                for f in files:
                    if not f.endswith(".json") and not f.endswith(".sql") and not f.endswith(".python"):
                        continue
                    filepath = os.path.join(root, f)
                    try:
                        with open(filepath, "r", encoding="utf-8") as fp:
                            data = json.load(fp)
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        continue

                    if isinstance(data, dict) and data.get("version") == "NotebookV1":
                        file_changed = _update_widget_definitions(data, parameters)
                        if "commands" in data:
                            file_changed = _update_widgets_in_commands(data["commands"], parameters) or file_changed
                            file_changed = _update_sql_param_placeholders(data["commands"], parameters) or file_changed
                        if file_changed:
                            changed = True
                            with open(filepath, "w", encoding="utf-8") as fp:
                                json.dump(data, fp, indent=2, ensure_ascii=False)

            if changed:
                out = io.BytesIO()
                with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
                    for root, _, files in os.walk(tmpdir):
                        for f in files:
                            filepath = os.path.join(root, f)
                            arcname = os.path.relpath(filepath, tmpdir)
                            zf.write(filepath, arcname)
                try:
                    client.workspace.delete(path)
                except Exception:
                    pass
                client.workspace.upload(
                    path=path,
                    content=io.BytesIO(out.getvalue()),
                    format=ImportFormat.DBC,
                    overwrite=False,
                )

        return {
            "status": "success",
            "path": path,
            "parameters_updated": list(parameters.keys()),
            "message": "Notebook parameters updated" if changed else "No matching parameters found to update",
        }
    except Exception as e:
        logger.error(f"Failed to update parameters for {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def mkdirs(path: str, client: Any = None) -> Dict[str, Any]:
    """
    Create a directory (and parent directories if needed).

    Args:
        path: Absolute path of the directory
        client: Databricks WorkspaceClient instance

    Returns:
        dict: Creation result
    """
    try:
        client.workspace.mkdirs(path)
        return {
            "status": "success",
            "path": path,
            "message": "Directory created successfully",
        }
    except Exception as e:
        logger.error(f"Failed to create directory {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def delete_file(path: str, recursive: bool = False, client: Any = None) -> Dict[str, Any]:
    """
    Delete a workspace file or directory.
    
    Args:
        path: Path to the file/directory to delete
        recursive: Whether to delete recursively (for directories)
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Deletion result
    """
    try:
        client.workspace.delete(path=path, recursive=recursive)
        
        return {
            "status": "success",
            "path": path,
            "message": "File/directory deleted successfully",
        }
    except Exception as e:
        logger.error(f"Failed to delete file {path}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def list_repos(client: Any = None) -> Dict[str, Any]:
    """
    List Git repositories in the workspace.
    
    Args:
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: List of repositories
    """
    try:
        repos = []
        for repo in client.repos.list():
            repos.append({
                "id": repo.id if hasattr(repo, "id") else None,
                "path": repo.path if hasattr(repo, "path") else None,
                "url": repo.url if hasattr(repo, "url") else None,
                "provider": repo.provider.value if hasattr(repo, "provider") and repo.provider else None,
                "branch": repo.branch if hasattr(repo, "branch") else None,
                "head_commit_id": repo.head_commit_id if hasattr(repo, "head_commit_id") else None,
            })
        
        return {
            "status": "success",
            "repos": repos,
            "count": len(repos),
        }
    except Exception as e:
        logger.error(f"Failed to list repos: {e}")
        return {
            "status": "error",
            "error": str(e),
        }
