"""SQL warehouse and query tools for Databricks MCP server."""

import logging
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


def list_sql_warehouses(client: Any = None) -> Dict[str, Any]:
    """
    List all SQL warehouses in the workspace.
    
    Args:
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: List of SQL warehouses with their details
    """
    try:
        warehouses = []
        for warehouse in client.sql.warehouses.list():
            warehouses.append({
                "id": warehouse.id,
                "name": warehouse.name,
                "cluster_size": warehouse.cluster_size if hasattr(warehouse, "cluster_size") else None,
                "min_num_clusters": warehouse.min_num_clusters if hasattr(warehouse, "min_num_clusters") else None,
                "max_num_clusters": warehouse.max_num_clusters if hasattr(warehouse, "max_num_clusters") else None,
                "state": warehouse.state.value if hasattr(warehouse, "state") and warehouse.state else "unknown",
                "warehouse_type": warehouse.warehouse_type.value if hasattr(warehouse, "warehouse_type") and warehouse.warehouse_type else None,
            })
        
        return {
            "status": "success",
            "warehouses": warehouses,
            "count": len(warehouses),
        }
    except Exception as e:
        logger.error(f"Failed to list SQL warehouses: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def execute_sql(
    warehouse_id: str,
    query: str,
    client: Any = None,
) -> Dict[str, Any]:
    """
    Execute a SQL query on a SQL warehouse.
    
    Args:
        warehouse_id: The SQL warehouse ID
        query: SQL query to execute
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Query execution result
    """
    try:
        # Use Statement Execution API
        statement = client.statement_execution.execute_statement(
            warehouse_id=warehouse_id,
            statement=query,
            wait_timeout="30s",
        )
        
        result = {
            "status": "success",
            "statement_id": statement.statement_id if hasattr(statement, "statement_id") else None,
            "status": statement.status.state.value if statement.status and hasattr(statement.status, "state") else "unknown",
        }
        
        # Try to get results if available
        if statement.status and hasattr(statement.status, "state") and statement.status.state.value == "SUCCEEDED":
            try:
                result_data = client.statement_execution.get_statement_result(
                    statement_id=statement.statement_id,
                )
                if result_data:
                    result["has_results"] = True
                    result["row_count"] = result_data.result.row_count if hasattr(result_data.result, "row_count") else 0
            except:
                result["has_results"] = False
        
        return result
    except Exception as e:
        logger.error(f"Failed to execute SQL query: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def get_query_history(
    limit: int = 20,
    warehouse_id: Optional[str] = None,
    client: Any = None,
) -> Dict[str, Any]:
    """
    Get query execution history.
    
    Args:
        limit: Maximum number of queries to return (default: 20)
        warehouse_id: Optional warehouse ID to filter by
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: List of query executions
    """
    try:
        queries = []
        
        # Use Query History API
        history = client.query_history.list(
            filter_by={"warehouse_ids": [warehouse_id]} if warehouse_id else None,
            max_results=limit,
        )
        
        if hasattr(history, "res") and history.res:
            for query in history.res:
                queries.append({
                    "query_id": query.query_id if hasattr(query, "query_id") else None,
                    "query_text": query.query_text if hasattr(query, "query_text") else None,
                    "status": query.status.value if hasattr(query, "status") and query.status else "unknown",
                    "query_start_time_ms": query.query_start_time_ms if hasattr(query, "query_start_time_ms") else None,
                    "execution_time": query.execution_time if hasattr(query, "execution_time") else None,
                    "warehouse_id": query.warehouse_id if hasattr(query, "warehouse_id") else None,
                })
        
        return {
            "status": "success",
            "queries": queries,
            "count": len(queries),
        }
    except Exception as e:
        logger.error(f"Failed to get query history: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def create_query(
    name: str,
    query: str,
    warehouse_id: str,
    description: Optional[str] = None,
    client: Any = None,
) -> Dict[str, Any]:
    """
    Create a saved query.
    
    Args:
        name: Query name
        query: SQL query text
        warehouse_id: SQL warehouse ID
        description: Optional query description
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Created query details
    """
    try:
        created_query = client.queries.create(
            name=name,
            query=query,
            data_source_id=warehouse_id,
            description=description,
        )
        
        return {
            "status": "success",
            "query_id": created_query.id if hasattr(created_query, "id") else None,
            "name": name,
            "message": "Query created successfully",
        }
    except Exception as e:
        logger.error(f"Failed to create query: {e}")
        return {
            "status": "error",
            "error": str(e),
        }


def get_query(query_id: str, client: Any = None) -> Dict[str, Any]:
    """
    Get details of a saved query.
    
    Args:
        query_id: The query ID
        client: Databricks WorkspaceClient instance
        
    Returns:
        dict: Query details
    """
    try:
        query = client.queries.get(query_id=query_id)
        
        return {
            "status": "success",
            "query": {
                "id": query.id if hasattr(query, "id") else None,
                "name": query.name if hasattr(query, "name") else None,
                "query": query.query if hasattr(query, "query") else None,
                "description": query.description if hasattr(query, "description") else None,
                "data_source_id": query.data_source_id if hasattr(query, "data_source_id") else None,
                "created_at": query.created_at if hasattr(query, "created_at") else None,
                "updated_at": query.updated_at if hasattr(query, "updated_at") else None,
            },
        }
    except Exception as e:
        logger.error(f"Failed to get query {query_id}: {e}")
        return {
            "status": "error",
            "error": str(e),
        }
