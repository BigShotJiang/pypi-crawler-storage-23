"""Main MCP server implementation for Databricks."""

import os
import logging
from fastmcp import FastMCP
from dotenv import load_dotenv

from .databricks_client import DatabricksClient
from .tools import notebooks, clusters, jobs, sql, workspace

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize MCP server
mcp = FastMCP("Databricks MCP Server")

# Lazy client initialization - only create when needed
_db_client_instance = None

def get_client():
    """Get or create Databricks client instance (lazy initialization)."""
    global _db_client_instance
    if _db_client_instance is None:
        try:
            _db_client_instance = DatabricksClient()
        except Exception as e:
            logger.error(f"Failed to initialize Databricks client: {e}")
            raise
    return _db_client_instance.client


# Notebook tools
@mcp.tool()
def run_notebook(
    path: str,
    parameters: str = None,
    timeout_seconds: int = None,
) -> str:
    """Execute a notebook with optional parameters."""
    try:
        client = get_client()
        result = notebooks.run_notebook(path, parameters, timeout_seconds, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def list_notebooks(path: str = "/", recursive: bool = True) -> str:
    """List notebooks in the workspace."""
    try:
        client = get_client()
        result = notebooks.list_notebooks(path, recursive, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def get_notebook(path: str) -> str:
    """Get notebook content and metadata."""
    try:
        client = get_client()
        result = notebooks.get_notebook(path, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def create_notebook(path: str, content: str, language: str = "PYTHON") -> str:
    """Create a new notebook."""
    try:
        client = get_client()
        result = notebooks.create_notebook(path, content, language, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def delete_notebook(path: str) -> str:
    """Delete a notebook."""
    try:
        client = get_client()
        result = notebooks.delete_notebook(path, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


# Cluster tools
@mcp.tool()
def list_clusters() -> str:
    """List all clusters in the workspace."""
    try:
        client = get_client()
        result = clusters.list_clusters(client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def get_cluster(cluster_id: str) -> str:
    """Get detailed information about a specific cluster."""
    try:
        client = get_client()
        result = clusters.get_cluster(cluster_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def create_cluster(
    cluster_name: str,
    spark_version: str,
    node_type_id: str,
    num_workers: int = 0,
    autotermination_minutes: int = 60,
    driver_node_type_id: str = None,
) -> str:
    """Create a new cluster."""
    try:
        client = get_client()
        result = clusters.create_cluster(
            cluster_name, spark_version, node_type_id, num_workers,
            autotermination_minutes, driver_node_type_id, client
        )
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def start_cluster(cluster_id: str) -> str:
    """Start a cluster."""
    try:
        client = get_client()
        result = clusters.start_cluster(cluster_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def stop_cluster(cluster_id: str) -> str:
    """Stop/terminate a cluster."""
    try:
        client = get_client()
        result = clusters.stop_cluster(cluster_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def restart_cluster(cluster_id: str) -> str:
    """Restart a cluster."""
    try:
        client = get_client()
        result = clusters.restart_cluster(cluster_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


# Job tools
@mcp.tool()
def list_jobs(limit: int = 20) -> str:
    """List all jobs in the workspace."""
    try:
        client = get_client()
        result = jobs.list_jobs(limit, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def get_job(job_id: int) -> str:
    """Get detailed information about a specific job."""
    try:
        client = get_client()
        result = jobs.get_job(job_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def create_job(
    name: str,
    notebook_path: str = None,
    cluster_id: str = None,
    spark_version: str = None,
    node_type_id: str = None,
    parameters: str = None,
    timeout_seconds: int = None,
) -> str:
    """Create a new job."""
    try:
        client = get_client()
        result = jobs.create_job(
            name, notebook_path, cluster_id, spark_version,
            node_type_id, parameters, timeout_seconds, client
        )
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def run_job(job_id: int, parameters: str = None) -> str:
    """Trigger a job run."""
    try:
        client = get_client()
        result = jobs.run_job(job_id, parameters, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def get_job_run(run_id: int) -> str:
    """Get status and details of a job run."""
    try:
        client = get_client()
        result = jobs.get_job_run(run_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def delete_job(job_id: int) -> str:
    """Delete a job."""
    try:
        client = get_client()
        result = jobs.delete_job(job_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


# SQL tools
@mcp.tool()
def list_sql_warehouses() -> str:
    """List all SQL warehouses in the workspace."""
    try:
        client = get_client()
        result = sql.list_sql_warehouses(client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def execute_sql(warehouse_id: str, query: str) -> str:
    """Execute a SQL query on a SQL warehouse."""
    try:
        client = get_client()
        result = sql.execute_sql(warehouse_id, query, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def get_query_history(limit: int = 20, warehouse_id: str = None) -> str:
    """Get query execution history."""
    try:
        client = get_client()
        result = sql.get_query_history(limit, warehouse_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def create_query(name: str, query: str, warehouse_id: str, description: str = None) -> str:
    """Create a saved query."""
    try:
        client = get_client()
        result = sql.create_query(name, query, warehouse_id, description, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def get_query(query_id: str) -> str:
    """Get details of a saved query."""
    try:
        client = get_client()
        result = sql.get_query(query_id, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


# Workspace tools
@mcp.tool()
def list_workspace(path: str = "/", recursive: bool = False) -> str:
    """List workspace files and objects."""
    try:
        client = get_client()
        result = workspace.list_workspace(path, recursive, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def read_file(path: str, format: str = "SOURCE") -> str:
    """Read workspace file content."""
    try:
        client = get_client()
        result = workspace.read_file(path, format, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def create_file(
    path: str,
    content: str,
    language: str = None,
    format: str = "SOURCE",
    overwrite: bool = False,
    content_encoding: str = "utf8",
) -> str:
    """Create a workspace file. Use content_encoding=base64 when cloning from read_file."""
    try:
        client = get_client()
        result = workspace.create_file(
            path, content, language, format, overwrite, content_encoding, client
        )
        import json
        return json.dumps(result)
    except Exception as e:
        import traceback
        import json
        err_msg = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        return json.dumps({"status": "error", "error": err_msg})


@mcp.tool()
def clone_file(
    source_path: str,
    target_path: str,
    format: str = "DBC",
    overwrite: bool = False,
    create_parent_dir: bool = True,
) -> str:
    """Clone a workspace file or notebook to a new path. Uses DBC format by default to preserve notebook parameters/widgets. Performs read and write on the server side to avoid size limits."""
    try:
        client = get_client()
        result = workspace.clone_file(
            source_path, target_path, format, overwrite, create_parent_dir, client
        )
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def update_notebook_parameters(path: str, parameters: str) -> str:
    """Update notebook widget/parameter default values. parameters: JSON object mapping param names to values, e.g. {\"Statsig_Experiment_Name\": \"exp_123\", \"Date_Range_0_Start_Date\": \"2024-01-01\"}."""
    try:
        import json as json_mod

        client = get_client()
        params_dict = json_mod.loads(parameters) if isinstance(parameters, str) else parameters
        result = workspace.update_notebook_parameters(path, params_dict, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def mkdirs(path: str) -> str:
    """Create a directory (and parent directories if needed)."""
    try:
        client = get_client()
        result = workspace.mkdirs(path, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def delete_file(path: str, recursive: bool = False) -> str:
    """Delete a workspace file or directory."""
    try:
        client = get_client()
        result = workspace.delete_file(path, recursive, client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
def list_repos() -> str:
    """List Git repositories in the workspace."""
    try:
        client = get_client()
        result = workspace.list_repos(client)
        import json
        return json.dumps(result)
    except Exception as e:
        import json
        return json.dumps({"status": "error", "error": str(e)})


def main():
    """Main entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
