"""Databricks MCP Server - Model Context Protocol server for Databricks."""

__version__ = "0.1.0"
