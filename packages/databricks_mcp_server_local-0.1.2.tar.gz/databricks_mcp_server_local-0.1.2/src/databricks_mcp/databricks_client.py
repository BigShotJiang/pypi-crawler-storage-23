"""Databricks client wrapper for MCP server."""

import os
import logging
from typing import Optional
from databricks.sdk import WorkspaceClient
from databricks.sdk.core import Config

logger = logging.getLogger(__name__)


class DatabricksClient:
    """Wrapper around Databricks SDK WorkspaceClient with authentication handling."""

    def __init__(self):
        """Initialize Databricks client from environment variables."""
        self._client: Optional[WorkspaceClient] = None
        self._initialize_client()

    def _initialize_client(self) -> None:
        """Initialize the Databricks WorkspaceClient."""
        try:
            # The WorkspaceClient will automatically pick up credentials from:
            # 1. Environment variables (DATABRICKS_HOST, DATABRICKS_TOKEN, etc.)
            # 2. .databrickscfg file
            # 3. Notebook-native authentication (if running in Databricks)
            
            # Check if we have minimum required config
            host = os.getenv("DATABRICKS_HOST")
            token = os.getenv("DATABRICKS_TOKEN")
            
            if not host:
                raise ValueError(
                    "DATABRICKS_HOST environment variable is required. "
                    "Set it to your Databricks workspace URL (e.g., https://your-workspace.cloud.databricks.com)"
                )
            
            # Create config explicitly if we have token
            if token:
                config = Config(
                    host=host,
                    token=token,
                )
                self._client = WorkspaceClient(config=config)
            else:
                # Let SDK auto-detect credentials
                self._client = WorkspaceClient()
            
            logger.info(f"Initialized Databricks client for workspace: {host}")
            
        except Exception as e:
            logger.error(f"Failed to initialize Databricks client: {e}")
            raise ValueError(
                f"Failed to initialize Databricks client: {e}. "
                "Please check your DATABRICKS_HOST and authentication credentials."
            ) from e

    @property
    def client(self) -> WorkspaceClient:
        """Get the Databricks WorkspaceClient instance."""
        if self._client is None:
            raise RuntimeError("Databricks client not initialized")
        return self._client

    def validate_connection(self) -> dict:
        """
        Validate the connection to Databricks.
        
        Returns:
            dict: Connection status information
        """
        try:
            # Try to get current user info to validate connection
            current_user = self.client.current_user.me()
            return {
                "status": "connected",
                "user": current_user.user_name if hasattr(current_user, "user_name") else "unknown",
                "workspace": self.client.config.host if hasattr(self.client.config, "host") else "unknown",
            }
        except Exception as e:
            logger.error(f"Connection validation failed: {e}")
            return {
                "status": "error",
                "error": str(e),
            }
