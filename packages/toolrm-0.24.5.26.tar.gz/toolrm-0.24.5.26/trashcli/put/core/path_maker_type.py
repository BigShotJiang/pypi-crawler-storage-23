from enum import Enum


class PathMakerType(Enum):
    AbsolutePaths = 'AbsolutePaths'
    RelativePaths = 'RelativePaths'
