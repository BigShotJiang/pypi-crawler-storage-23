from enum import Enum


class TrashResult(Enum):
    Failure = "Failure"
    Success = "Success"
