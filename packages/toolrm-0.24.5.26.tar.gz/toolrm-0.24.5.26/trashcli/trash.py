# Copyright (C) 2007-2011 Andrea Francia Trivolzio(PV) Italy

version = '0.24.5.26'
