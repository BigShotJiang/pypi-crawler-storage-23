# Copyright (C) 2007-2021 Andrea Francia Trivolzio(PV) Italy
from setuptools import setup

setup()
