Simple experiments with cellular automaton. Currently a customisable implementation of conways' game of life; will hopefully include interacive rule setting and beyond directly adjacent neighbour monitoring, along with more interesting visuals.

**Install:**

Homebrew:

```
brew tap Shiyuan-Chen-17/cautom
brew install cautom
```

Pip:

```
pip install --upgrade pip
pip install cautom
```
