from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.line_chart_config_label_position_type_0 import LineChartConfigLabelPositionType0
from ..models.line_chart_config_legend_orientation_type_0 import LineChartConfigLegendOrientationType0
from ..models.line_chart_config_legend_position_type_0 import LineChartConfigLegendPositionType0
from ..models.line_chart_config_line_type_type_0 import LineChartConfigLineTypeType0
from ..models.line_chart_config_orientation_type_0 import LineChartConfigOrientationType0
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.axis_label_config import AxisLabelConfig
    from ..models.chart_field import ChartField
    from ..models.chart_filter import ChartFilter
    from ..models.line_chart_config_chart_padding_type_1 import LineChartConfigChartPaddingType1
    from ..models.line_chart_config_series_styles_type_0 import LineChartConfigSeriesStylesType0
    from ..models.tooltip_config import TooltipConfig
    from ..models.visual_encoding_config import VisualEncodingConfig


T = TypeVar("T", bound="LineChartConfig")


@_attrs_define
class LineChartConfig:
    """Configuration for line charts.

    Attributes:
        type_ (Literal['line'] | Unset):  Default: 'line'.
        x (ChartField | None | Unset): X-axis field configuration
        y (ChartField | list[ChartField] | None | Unset): Y-axis field(s) configuration
        series (ChartField | None | Unset): Series field for grouping
        orientation (LineChartConfigOrientationType0 | None | Unset): Chart orientation Default:
            LineChartConfigOrientationType0.VERTICAL.
        colors (list[str] | None | Unset): Custom colors
        series_styles (LineChartConfigSeriesStylesType0 | None | Unset): Per-series styling configuration. Key is series
            ID, value is SeriesStyle
        visual_encoding (None | Unset | VisualEncodingConfig): Visual encoding configuration for multi-dimensional
            styling
        show_labels (bool | None | Unset): Whether to show labels
        label_position (LineChartConfigLabelPositionType0 | None | Unset): Label position
        show_legend (bool | None | Unset): Whether to show legend Default: True.
        legend_position (LineChartConfigLegendPositionType0 | None | Unset): Legend position
        legend_orientation (LineChartConfigLegendOrientationType0 | None | Unset): Legend orientation
        x_axis_label (AxisLabelConfig | None | Unset): X-axis label configuration
        y_axis_label (AxisLabelConfig | None | Unset): Y-axis label configuration
        show_x_axis_line (bool | None | Unset): Whether to show X-axis line Default: True.
        show_y_axis_line (bool | None | Unset): Whether to show Y-axis line Default: True.
        show_x_axis_units (bool | None | Unset): Whether to show X-axis unit labels Default: True.
        show_y_axis_units (bool | None | Unset): Whether to show Y-axis unit labels Default: True.
        show_x_grid (bool | None | Unset): Whether to show X-axis grid lines Default: True.
        show_y_grid (bool | None | Unset): Whether to show Y-axis grid lines Default: True.
        tooltip_config (None | TooltipConfig | Unset): Tooltip configuration
        filters (list[ChartFilter] | None | Unset): Chart-specific filters (applied before dashboard filters)
        chart_padding (int | LineChartConfigChartPaddingType1 | None | Unset): Chart padding (space around the chart
            inside the widget). Can be a single number for all sides, or an object for individual sides
        show_symbols (bool | None | Unset): Whether to show data point symbols
        symbol_size (int | None | Unset): Size of data point symbols
        smooth (bool | None | Unset): Whether to smooth the line (deprecated, use lineType on ChartField) Default: True.
        line_type (LineChartConfigLineTypeType0 | None | Unset): Line plot type (deprecated, use lineType on ChartField)
            Default: LineChartConfigLineTypeType0.SMOOTH.
        dashed_series (list[str] | None | Unset): Series to show as dashed
        show_area (bool | None | Unset): Whether to show area under line
        area_opacity (float | None | Unset): Area opacity (0-1) Default: 0.2.
    """

    type_: Literal["line"] | Unset = "line"
    x: ChartField | None | Unset = UNSET
    y: ChartField | list[ChartField] | None | Unset = UNSET
    series: ChartField | None | Unset = UNSET
    orientation: LineChartConfigOrientationType0 | None | Unset = LineChartConfigOrientationType0.VERTICAL
    colors: list[str] | None | Unset = UNSET
    series_styles: LineChartConfigSeriesStylesType0 | None | Unset = UNSET
    visual_encoding: None | Unset | VisualEncodingConfig = UNSET
    show_labels: bool | None | Unset = UNSET
    label_position: LineChartConfigLabelPositionType0 | None | Unset = UNSET
    show_legend: bool | None | Unset = True
    legend_position: LineChartConfigLegendPositionType0 | None | Unset = UNSET
    legend_orientation: LineChartConfigLegendOrientationType0 | None | Unset = UNSET
    x_axis_label: AxisLabelConfig | None | Unset = UNSET
    y_axis_label: AxisLabelConfig | None | Unset = UNSET
    show_x_axis_line: bool | None | Unset = True
    show_y_axis_line: bool | None | Unset = True
    show_x_axis_units: bool | None | Unset = True
    show_y_axis_units: bool | None | Unset = True
    show_x_grid: bool | None | Unset = True
    show_y_grid: bool | None | Unset = True
    tooltip_config: None | TooltipConfig | Unset = UNSET
    filters: list[ChartFilter] | None | Unset = UNSET
    chart_padding: int | LineChartConfigChartPaddingType1 | None | Unset = UNSET
    show_symbols: bool | None | Unset = UNSET
    symbol_size: int | None | Unset = UNSET
    smooth: bool | None | Unset = True
    line_type: LineChartConfigLineTypeType0 | None | Unset = LineChartConfigLineTypeType0.SMOOTH
    dashed_series: list[str] | None | Unset = UNSET
    show_area: bool | None | Unset = UNSET
    area_opacity: float | None | Unset = 0.2
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.axis_label_config import AxisLabelConfig
        from ..models.chart_field import ChartField
        from ..models.line_chart_config_chart_padding_type_1 import LineChartConfigChartPaddingType1
        from ..models.line_chart_config_series_styles_type_0 import LineChartConfigSeriesStylesType0
        from ..models.tooltip_config import TooltipConfig
        from ..models.visual_encoding_config import VisualEncodingConfig

        type_ = self.type_

        x: dict[str, Any] | None | Unset
        if isinstance(self.x, Unset):
            x = UNSET
        elif isinstance(self.x, ChartField):
            x = self.x.to_dict()
        else:
            x = self.x

        y: dict[str, Any] | list[dict[str, Any]] | None | Unset
        if isinstance(self.y, Unset):
            y = UNSET
        elif isinstance(self.y, ChartField):
            y = self.y.to_dict()
        elif isinstance(self.y, list):
            y = []
            for y_type_1_item_data in self.y:
                y_type_1_item = y_type_1_item_data.to_dict()
                y.append(y_type_1_item)

        else:
            y = self.y

        series: dict[str, Any] | None | Unset
        if isinstance(self.series, Unset):
            series = UNSET
        elif isinstance(self.series, ChartField):
            series = self.series.to_dict()
        else:
            series = self.series

        orientation: None | str | Unset
        if isinstance(self.orientation, Unset):
            orientation = UNSET
        elif isinstance(self.orientation, LineChartConfigOrientationType0):
            orientation = self.orientation.value
        else:
            orientation = self.orientation

        colors: list[str] | None | Unset
        if isinstance(self.colors, Unset):
            colors = UNSET
        elif isinstance(self.colors, list):
            colors = self.colors

        else:
            colors = self.colors

        series_styles: dict[str, Any] | None | Unset
        if isinstance(self.series_styles, Unset):
            series_styles = UNSET
        elif isinstance(self.series_styles, LineChartConfigSeriesStylesType0):
            series_styles = self.series_styles.to_dict()
        else:
            series_styles = self.series_styles

        visual_encoding: dict[str, Any] | None | Unset
        if isinstance(self.visual_encoding, Unset):
            visual_encoding = UNSET
        elif isinstance(self.visual_encoding, VisualEncodingConfig):
            visual_encoding = self.visual_encoding.to_dict()
        else:
            visual_encoding = self.visual_encoding

        show_labels: bool | None | Unset
        if isinstance(self.show_labels, Unset):
            show_labels = UNSET
        else:
            show_labels = self.show_labels

        label_position: None | str | Unset
        if isinstance(self.label_position, Unset):
            label_position = UNSET
        elif isinstance(self.label_position, LineChartConfigLabelPositionType0):
            label_position = self.label_position.value
        else:
            label_position = self.label_position

        show_legend: bool | None | Unset
        if isinstance(self.show_legend, Unset):
            show_legend = UNSET
        else:
            show_legend = self.show_legend

        legend_position: None | str | Unset
        if isinstance(self.legend_position, Unset):
            legend_position = UNSET
        elif isinstance(self.legend_position, LineChartConfigLegendPositionType0):
            legend_position = self.legend_position.value
        else:
            legend_position = self.legend_position

        legend_orientation: None | str | Unset
        if isinstance(self.legend_orientation, Unset):
            legend_orientation = UNSET
        elif isinstance(self.legend_orientation, LineChartConfigLegendOrientationType0):
            legend_orientation = self.legend_orientation.value
        else:
            legend_orientation = self.legend_orientation

        x_axis_label: dict[str, Any] | None | Unset
        if isinstance(self.x_axis_label, Unset):
            x_axis_label = UNSET
        elif isinstance(self.x_axis_label, AxisLabelConfig):
            x_axis_label = self.x_axis_label.to_dict()
        else:
            x_axis_label = self.x_axis_label

        y_axis_label: dict[str, Any] | None | Unset
        if isinstance(self.y_axis_label, Unset):
            y_axis_label = UNSET
        elif isinstance(self.y_axis_label, AxisLabelConfig):
            y_axis_label = self.y_axis_label.to_dict()
        else:
            y_axis_label = self.y_axis_label

        show_x_axis_line: bool | None | Unset
        if isinstance(self.show_x_axis_line, Unset):
            show_x_axis_line = UNSET
        else:
            show_x_axis_line = self.show_x_axis_line

        show_y_axis_line: bool | None | Unset
        if isinstance(self.show_y_axis_line, Unset):
            show_y_axis_line = UNSET
        else:
            show_y_axis_line = self.show_y_axis_line

        show_x_axis_units: bool | None | Unset
        if isinstance(self.show_x_axis_units, Unset):
            show_x_axis_units = UNSET
        else:
            show_x_axis_units = self.show_x_axis_units

        show_y_axis_units: bool | None | Unset
        if isinstance(self.show_y_axis_units, Unset):
            show_y_axis_units = UNSET
        else:
            show_y_axis_units = self.show_y_axis_units

        show_x_grid: bool | None | Unset
        if isinstance(self.show_x_grid, Unset):
            show_x_grid = UNSET
        else:
            show_x_grid = self.show_x_grid

        show_y_grid: bool | None | Unset
        if isinstance(self.show_y_grid, Unset):
            show_y_grid = UNSET
        else:
            show_y_grid = self.show_y_grid

        tooltip_config: dict[str, Any] | None | Unset
        if isinstance(self.tooltip_config, Unset):
            tooltip_config = UNSET
        elif isinstance(self.tooltip_config, TooltipConfig):
            tooltip_config = self.tooltip_config.to_dict()
        else:
            tooltip_config = self.tooltip_config

        filters: list[dict[str, Any]] | None | Unset
        if isinstance(self.filters, Unset):
            filters = UNSET
        elif isinstance(self.filters, list):
            filters = []
            for filters_type_0_item_data in self.filters:
                filters_type_0_item = filters_type_0_item_data.to_dict()
                filters.append(filters_type_0_item)

        else:
            filters = self.filters

        chart_padding: dict[str, Any] | int | None | Unset
        if isinstance(self.chart_padding, Unset):
            chart_padding = UNSET
        elif isinstance(self.chart_padding, LineChartConfigChartPaddingType1):
            chart_padding = self.chart_padding.to_dict()
        else:
            chart_padding = self.chart_padding

        show_symbols: bool | None | Unset
        if isinstance(self.show_symbols, Unset):
            show_symbols = UNSET
        else:
            show_symbols = self.show_symbols

        symbol_size: int | None | Unset
        if isinstance(self.symbol_size, Unset):
            symbol_size = UNSET
        else:
            symbol_size = self.symbol_size

        smooth: bool | None | Unset
        if isinstance(self.smooth, Unset):
            smooth = UNSET
        else:
            smooth = self.smooth

        line_type: None | str | Unset
        if isinstance(self.line_type, Unset):
            line_type = UNSET
        elif isinstance(self.line_type, LineChartConfigLineTypeType0):
            line_type = self.line_type.value
        else:
            line_type = self.line_type

        dashed_series: list[str] | None | Unset
        if isinstance(self.dashed_series, Unset):
            dashed_series = UNSET
        elif isinstance(self.dashed_series, list):
            dashed_series = self.dashed_series

        else:
            dashed_series = self.dashed_series

        show_area: bool | None | Unset
        if isinstance(self.show_area, Unset):
            show_area = UNSET
        else:
            show_area = self.show_area

        area_opacity: float | None | Unset
        if isinstance(self.area_opacity, Unset):
            area_opacity = UNSET
        else:
            area_opacity = self.area_opacity

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if x is not UNSET:
            field_dict["x"] = x
        if y is not UNSET:
            field_dict["y"] = y
        if series is not UNSET:
            field_dict["series"] = series
        if orientation is not UNSET:
            field_dict["orientation"] = orientation
        if colors is not UNSET:
            field_dict["colors"] = colors
        if series_styles is not UNSET:
            field_dict["seriesStyles"] = series_styles
        if visual_encoding is not UNSET:
            field_dict["visualEncoding"] = visual_encoding
        if show_labels is not UNSET:
            field_dict["showLabels"] = show_labels
        if label_position is not UNSET:
            field_dict["labelPosition"] = label_position
        if show_legend is not UNSET:
            field_dict["showLegend"] = show_legend
        if legend_position is not UNSET:
            field_dict["legendPosition"] = legend_position
        if legend_orientation is not UNSET:
            field_dict["legendOrientation"] = legend_orientation
        if x_axis_label is not UNSET:
            field_dict["xAxisLabel"] = x_axis_label
        if y_axis_label is not UNSET:
            field_dict["yAxisLabel"] = y_axis_label
        if show_x_axis_line is not UNSET:
            field_dict["showXAxisLine"] = show_x_axis_line
        if show_y_axis_line is not UNSET:
            field_dict["showYAxisLine"] = show_y_axis_line
        if show_x_axis_units is not UNSET:
            field_dict["showXAxisUnits"] = show_x_axis_units
        if show_y_axis_units is not UNSET:
            field_dict["showYAxisUnits"] = show_y_axis_units
        if show_x_grid is not UNSET:
            field_dict["showXGrid"] = show_x_grid
        if show_y_grid is not UNSET:
            field_dict["showYGrid"] = show_y_grid
        if tooltip_config is not UNSET:
            field_dict["tooltipConfig"] = tooltip_config
        if filters is not UNSET:
            field_dict["filters"] = filters
        if chart_padding is not UNSET:
            field_dict["chartPadding"] = chart_padding
        if show_symbols is not UNSET:
            field_dict["showSymbols"] = show_symbols
        if symbol_size is not UNSET:
            field_dict["symbolSize"] = symbol_size
        if smooth is not UNSET:
            field_dict["smooth"] = smooth
        if line_type is not UNSET:
            field_dict["lineType"] = line_type
        if dashed_series is not UNSET:
            field_dict["dashedSeries"] = dashed_series
        if show_area is not UNSET:
            field_dict["showArea"] = show_area
        if area_opacity is not UNSET:
            field_dict["areaOpacity"] = area_opacity

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.axis_label_config import AxisLabelConfig
        from ..models.chart_field import ChartField
        from ..models.chart_filter import ChartFilter
        from ..models.line_chart_config_chart_padding_type_1 import LineChartConfigChartPaddingType1
        from ..models.line_chart_config_series_styles_type_0 import LineChartConfigSeriesStylesType0
        from ..models.tooltip_config import TooltipConfig
        from ..models.visual_encoding_config import VisualEncodingConfig

        d = dict(src_dict)
        type_ = cast(Literal["line"] | Unset, d.pop("type", UNSET))
        if type_ != "line" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'line', got '{type_}'")

        def _parse_x(data: object) -> ChartField | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                x_type_0 = ChartField.from_dict(data)

                return x_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartField | None | Unset, data)

        x = _parse_x(d.pop("x", UNSET))

        def _parse_y(data: object) -> ChartField | list[ChartField] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                y_type_0 = ChartField.from_dict(data)

                return y_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, list):
                    raise TypeError()
                y_type_1 = []
                _y_type_1 = data
                for y_type_1_item_data in _y_type_1:
                    y_type_1_item = ChartField.from_dict(y_type_1_item_data)

                    y_type_1.append(y_type_1_item)

                return y_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartField | list[ChartField] | None | Unset, data)

        y = _parse_y(d.pop("y", UNSET))

        def _parse_series(data: object) -> ChartField | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                series_type_0 = ChartField.from_dict(data)

                return series_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartField | None | Unset, data)

        series = _parse_series(d.pop("series", UNSET))

        def _parse_orientation(data: object) -> LineChartConfigOrientationType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                orientation_type_0 = LineChartConfigOrientationType0(data)

                return orientation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LineChartConfigOrientationType0 | None | Unset, data)

        orientation = _parse_orientation(d.pop("orientation", UNSET))

        def _parse_colors(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                colors_type_0 = cast(list[str], data)

                return colors_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        colors = _parse_colors(d.pop("colors", UNSET))

        def _parse_series_styles(data: object) -> LineChartConfigSeriesStylesType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                series_styles_type_0 = LineChartConfigSeriesStylesType0.from_dict(data)

                return series_styles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LineChartConfigSeriesStylesType0 | None | Unset, data)

        series_styles = _parse_series_styles(d.pop("seriesStyles", UNSET))

        def _parse_visual_encoding(data: object) -> None | Unset | VisualEncodingConfig:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                visual_encoding_type_0 = VisualEncodingConfig.from_dict(data)

                return visual_encoding_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | VisualEncodingConfig, data)

        visual_encoding = _parse_visual_encoding(d.pop("visualEncoding", UNSET))

        def _parse_show_labels(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_labels = _parse_show_labels(d.pop("showLabels", UNSET))

        def _parse_label_position(data: object) -> LineChartConfigLabelPositionType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                label_position_type_0 = LineChartConfigLabelPositionType0(data)

                return label_position_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LineChartConfigLabelPositionType0 | None | Unset, data)

        label_position = _parse_label_position(d.pop("labelPosition", UNSET))

        def _parse_show_legend(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_legend = _parse_show_legend(d.pop("showLegend", UNSET))

        def _parse_legend_position(data: object) -> LineChartConfigLegendPositionType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                legend_position_type_0 = LineChartConfigLegendPositionType0(data)

                return legend_position_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LineChartConfigLegendPositionType0 | None | Unset, data)

        legend_position = _parse_legend_position(d.pop("legendPosition", UNSET))

        def _parse_legend_orientation(data: object) -> LineChartConfigLegendOrientationType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                legend_orientation_type_0 = LineChartConfigLegendOrientationType0(data)

                return legend_orientation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LineChartConfigLegendOrientationType0 | None | Unset, data)

        legend_orientation = _parse_legend_orientation(d.pop("legendOrientation", UNSET))

        def _parse_x_axis_label(data: object) -> AxisLabelConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                x_axis_label_type_0 = AxisLabelConfig.from_dict(data)

                return x_axis_label_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AxisLabelConfig | None | Unset, data)

        x_axis_label = _parse_x_axis_label(d.pop("xAxisLabel", UNSET))

        def _parse_y_axis_label(data: object) -> AxisLabelConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                y_axis_label_type_0 = AxisLabelConfig.from_dict(data)

                return y_axis_label_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AxisLabelConfig | None | Unset, data)

        y_axis_label = _parse_y_axis_label(d.pop("yAxisLabel", UNSET))

        def _parse_show_x_axis_line(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_x_axis_line = _parse_show_x_axis_line(d.pop("showXAxisLine", UNSET))

        def _parse_show_y_axis_line(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_y_axis_line = _parse_show_y_axis_line(d.pop("showYAxisLine", UNSET))

        def _parse_show_x_axis_units(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_x_axis_units = _parse_show_x_axis_units(d.pop("showXAxisUnits", UNSET))

        def _parse_show_y_axis_units(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_y_axis_units = _parse_show_y_axis_units(d.pop("showYAxisUnits", UNSET))

        def _parse_show_x_grid(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_x_grid = _parse_show_x_grid(d.pop("showXGrid", UNSET))

        def _parse_show_y_grid(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_y_grid = _parse_show_y_grid(d.pop("showYGrid", UNSET))

        def _parse_tooltip_config(data: object) -> None | TooltipConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                tooltip_config_type_0 = TooltipConfig.from_dict(data)

                return tooltip_config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TooltipConfig | Unset, data)

        tooltip_config = _parse_tooltip_config(d.pop("tooltipConfig", UNSET))

        def _parse_filters(data: object) -> list[ChartFilter] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                filters_type_0 = []
                _filters_type_0 = data
                for filters_type_0_item_data in _filters_type_0:
                    filters_type_0_item = ChartFilter.from_dict(filters_type_0_item_data)

                    filters_type_0.append(filters_type_0_item)

                return filters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ChartFilter] | None | Unset, data)

        filters = _parse_filters(d.pop("filters", UNSET))

        def _parse_chart_padding(data: object) -> int | LineChartConfigChartPaddingType1 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chart_padding_type_1 = LineChartConfigChartPaddingType1.from_dict(data)

                return chart_padding_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(int | LineChartConfigChartPaddingType1 | None | Unset, data)

        chart_padding = _parse_chart_padding(d.pop("chartPadding", UNSET))

        def _parse_show_symbols(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_symbols = _parse_show_symbols(d.pop("showSymbols", UNSET))

        def _parse_symbol_size(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        symbol_size = _parse_symbol_size(d.pop("symbolSize", UNSET))

        def _parse_smooth(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        smooth = _parse_smooth(d.pop("smooth", UNSET))

        def _parse_line_type(data: object) -> LineChartConfigLineTypeType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                line_type_type_0 = LineChartConfigLineTypeType0(data)

                return line_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LineChartConfigLineTypeType0 | None | Unset, data)

        line_type = _parse_line_type(d.pop("lineType", UNSET))

        def _parse_dashed_series(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dashed_series_type_0 = cast(list[str], data)

                return dashed_series_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        dashed_series = _parse_dashed_series(d.pop("dashedSeries", UNSET))

        def _parse_show_area(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_area = _parse_show_area(d.pop("showArea", UNSET))

        def _parse_area_opacity(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        area_opacity = _parse_area_opacity(d.pop("areaOpacity", UNSET))

        line_chart_config = cls(
            type_=type_,
            x=x,
            y=y,
            series=series,
            orientation=orientation,
            colors=colors,
            series_styles=series_styles,
            visual_encoding=visual_encoding,
            show_labels=show_labels,
            label_position=label_position,
            show_legend=show_legend,
            legend_position=legend_position,
            legend_orientation=legend_orientation,
            x_axis_label=x_axis_label,
            y_axis_label=y_axis_label,
            show_x_axis_line=show_x_axis_line,
            show_y_axis_line=show_y_axis_line,
            show_x_axis_units=show_x_axis_units,
            show_y_axis_units=show_y_axis_units,
            show_x_grid=show_x_grid,
            show_y_grid=show_y_grid,
            tooltip_config=tooltip_config,
            filters=filters,
            chart_padding=chart_padding,
            show_symbols=show_symbols,
            symbol_size=symbol_size,
            smooth=smooth,
            line_type=line_type,
            dashed_series=dashed_series,
            show_area=show_area,
            area_opacity=area_opacity,
        )

        line_chart_config.additional_properties = d
        return line_chart_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
