from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chat_session_update_chat_state_type_0 import ChatSessionUpdateChatStateType0


T = TypeVar("T", bound="ChatSessionUpdate")


@_attrs_define
class ChatSessionUpdate:
    """Payload for updating an existing chat session.

    Attributes:
        title (None | str | Unset):
        chat_state (ChatSessionUpdateChatStateType0 | None | Unset):
    """

    title: None | str | Unset = UNSET
    chat_state: ChatSessionUpdateChatStateType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chat_session_update_chat_state_type_0 import ChatSessionUpdateChatStateType0

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        chat_state: dict[str, Any] | None | Unset
        if isinstance(self.chat_state, Unset):
            chat_state = UNSET
        elif isinstance(self.chat_state, ChatSessionUpdateChatStateType0):
            chat_state = self.chat_state.to_dict()
        else:
            chat_state = self.chat_state

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if title is not UNSET:
            field_dict["title"] = title
        if chat_state is not UNSET:
            field_dict["chatState"] = chat_state

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chat_session_update_chat_state_type_0 import ChatSessionUpdateChatStateType0

        d = dict(src_dict)

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_chat_state(data: object) -> ChatSessionUpdateChatStateType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chat_state_type_0 = ChatSessionUpdateChatStateType0.from_dict(data)

                return chat_state_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatSessionUpdateChatStateType0 | None | Unset, data)

        chat_state = _parse_chat_state(d.pop("chatState", UNSET))

        chat_session_update = cls(
            title=title,
            chat_state=chat_state,
        )

        chat_session_update.additional_properties = d
        return chat_session_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
