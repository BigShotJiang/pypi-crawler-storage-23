from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateDatabricksConnectionRequest")


@_attrs_define
class CreateDatabricksConnectionRequest:
    """
    Attributes:
        name (str): Connection name
        project_id (str): Project this connection belongs to
        server_hostname (str): Databricks workspace hostname (e.g., adb-xxx.azuredatabricks.net)
        http_path (str): SQL warehouse HTTP path (e.g., /sql/1.0/warehouses/xxx)
        access_token (str): Personal access token or OAuth token
        type_ (Literal['DATABRICKS_V1'] | Unset):  Default: 'DATABRICKS_V1'.
        description (None | str | Unset): Connection description
        catalog (None | str | Unset): Default catalog
        db_schema (None | str | Unset): Default schema Default: 'default'.
    """

    name: str
    project_id: str
    server_hostname: str
    http_path: str
    access_token: str
    type_: Literal["DATABRICKS_V1"] | Unset = "DATABRICKS_V1"
    description: None | str | Unset = UNSET
    catalog: None | str | Unset = UNSET
    db_schema: None | str | Unset = "default"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        project_id = self.project_id

        server_hostname = self.server_hostname

        http_path = self.http_path

        access_token = self.access_token

        type_ = self.type_

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        catalog: None | str | Unset
        if isinstance(self.catalog, Unset):
            catalog = UNSET
        else:
            catalog = self.catalog

        db_schema: None | str | Unset
        if isinstance(self.db_schema, Unset):
            db_schema = UNSET
        else:
            db_schema = self.db_schema

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "projectId": project_id,
                "serverHostname": server_hostname,
                "httpPath": http_path,
                "accessToken": access_token,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if description is not UNSET:
            field_dict["description"] = description
        if catalog is not UNSET:
            field_dict["catalog"] = catalog
        if db_schema is not UNSET:
            field_dict["dbSchema"] = db_schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        project_id = d.pop("projectId")

        server_hostname = d.pop("serverHostname")

        http_path = d.pop("httpPath")

        access_token = d.pop("accessToken")

        type_ = cast(Literal["DATABRICKS_V1"] | Unset, d.pop("type", UNSET))
        if type_ != "DATABRICKS_V1" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'DATABRICKS_V1', got '{type_}'")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_catalog(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        catalog = _parse_catalog(d.pop("catalog", UNSET))

        def _parse_db_schema(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        db_schema = _parse_db_schema(d.pop("dbSchema", UNSET))

        create_databricks_connection_request = cls(
            name=name,
            project_id=project_id,
            server_hostname=server_hostname,
            http_path=http_path,
            access_token=access_token,
            type_=type_,
            description=description,
            catalog=catalog,
            db_schema=db_schema,
        )

        create_databricks_connection_request.additional_properties = d
        return create_databricks_connection_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
