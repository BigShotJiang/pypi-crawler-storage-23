from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.workspace_file import WorkspaceFile


T = TypeVar("T", bound="FileInfoResponse")


@_attrs_define
class FileInfoResponse:
    """
    Attributes:
        file_info (WorkspaceFile): Represents a file in the workspace.
        workspace_id (str):
    """

    file_info: WorkspaceFile
    workspace_id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_info = self.file_info.to_dict()

        workspace_id = self.workspace_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "file_info": file_info,
                "workspace_id": workspace_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.workspace_file import WorkspaceFile

        d = dict(src_dict)
        file_info = WorkspaceFile.from_dict(d.pop("file_info"))

        workspace_id = d.pop("workspace_id")

        file_info_response = cls(
            file_info=file_info,
            workspace_id=workspace_id,
        )

        file_info_response.additional_properties = d
        return file_info_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
