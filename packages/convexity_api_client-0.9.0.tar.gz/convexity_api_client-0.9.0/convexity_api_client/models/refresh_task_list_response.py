from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.worker_task_response import WorkerTaskResponse


T = TypeVar("T", bound="RefreshTaskListResponse")


@_attrs_define
class RefreshTaskListResponse:
    """Response for listing refresh tasks with pagination.

    Attributes:
        total (int): Total number of tasks
        tasks (list[WorkerTaskResponse] | Unset): List of refresh tasks
        offset (int | Unset): Current offset Default: 0.
        limit (int | Unset): Number of tasks per page Default: 20.
    """

    total: int
    tasks: list[WorkerTaskResponse] | Unset = UNSET
    offset: int | Unset = 0
    limit: int | Unset = 20
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total = self.total

        tasks: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.tasks, Unset):
            tasks = []
            for tasks_item_data in self.tasks:
                tasks_item = tasks_item_data.to_dict()
                tasks.append(tasks_item)

        offset = self.offset

        limit = self.limit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total": total,
            }
        )
        if tasks is not UNSET:
            field_dict["tasks"] = tasks
        if offset is not UNSET:
            field_dict["offset"] = offset
        if limit is not UNSET:
            field_dict["limit"] = limit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.worker_task_response import WorkerTaskResponse

        d = dict(src_dict)
        total = d.pop("total")

        _tasks = d.pop("tasks", UNSET)
        tasks: list[WorkerTaskResponse] | Unset = UNSET
        if _tasks is not UNSET:
            tasks = []
            for tasks_item_data in _tasks:
                tasks_item = WorkerTaskResponse.from_dict(tasks_item_data)

                tasks.append(tasks_item)

        offset = d.pop("offset", UNSET)

        limit = d.pop("limit", UNSET)

        refresh_task_list_response = cls(
            total=total,
            tasks=tasks,
            offset=offset,
            limit=limit,
        )

        refresh_task_list_response.additional_properties = d
        return refresh_task_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
