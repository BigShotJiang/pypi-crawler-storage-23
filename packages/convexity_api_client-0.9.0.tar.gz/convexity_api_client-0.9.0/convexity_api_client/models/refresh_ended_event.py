from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.refresh_ended_payload import RefreshEndedPayload


T = TypeVar("T", bound="RefreshEndedEvent")


@_attrs_define
class RefreshEndedEvent:
    """Event emitted when a dataset refresh task finishes.

    Attributes:
        data (RefreshEndedPayload):
        event_type (Literal['refresh_ended'] | Unset): Type of event, e.g. 'refresh_ended' Default: 'refresh_ended'.
    """

    data: RefreshEndedPayload
    event_type: Literal["refresh_ended"] | Unset = "refresh_ended"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = self.data.to_dict()

        event_type = self.event_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "data": data,
            }
        )
        if event_type is not UNSET:
            field_dict["event_type"] = event_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.refresh_ended_payload import RefreshEndedPayload

        d = dict(src_dict)
        data = RefreshEndedPayload.from_dict(d.pop("data"))

        event_type = cast(Literal["refresh_ended"] | Unset, d.pop("event_type", UNSET))
        if event_type != "refresh_ended" and not isinstance(event_type, Unset):
            raise ValueError(f"event_type must match const 'refresh_ended', got '{event_type}'")

        refresh_ended_event = cls(
            data=data,
            event_type=event_type,
        )

        refresh_ended_event.additional_properties = d
        return refresh_ended_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
