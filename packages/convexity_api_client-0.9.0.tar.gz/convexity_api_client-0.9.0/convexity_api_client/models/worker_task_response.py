from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.worker_task_status import WorkerTaskStatus
from ..models.worker_task_type import WorkerTaskType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.delete_dataset_payload import DeleteDatasetPayload
    from ..models.execute_run_payload import ExecuteRunPayload
    from ..models.refresh_dataset_payload import RefreshDatasetPayload
    from ..models.sync_catalog_to_s3_payload import SyncCatalogToS3Payload
    from ..models.vacuum_ducklake_payload import VacuumDucklakePayload


T = TypeVar("T", bound="WorkerTaskResponse")


@_attrs_define
class WorkerTaskResponse:
    """API response model for a worker task.

    Attributes:
        id (str):
        type_ (WorkerTaskType): Supported worker task types.
        status (WorkerTaskStatus):
        error (None | str | Unset):
        payload (DeleteDatasetPayload | ExecuteRunPayload | None | RefreshDatasetPayload | SyncCatalogToS3Payload |
            Unset | VacuumDucklakePayload): Typed task payload with progress information
        user_id (None | str | Unset):
        dataset_id (None | str | Unset):
        project_id (None | str | Unset):
        created_at (None | str | Unset):
        updated_at (None | str | Unset):
    """

    id: str
    type_: WorkerTaskType
    status: WorkerTaskStatus
    error: None | str | Unset = UNSET
    payload: (
        DeleteDatasetPayload
        | ExecuteRunPayload
        | None
        | RefreshDatasetPayload
        | SyncCatalogToS3Payload
        | Unset
        | VacuumDucklakePayload
    ) = UNSET
    user_id: None | str | Unset = UNSET
    dataset_id: None | str | Unset = UNSET
    project_id: None | str | Unset = UNSET
    created_at: None | str | Unset = UNSET
    updated_at: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.delete_dataset_payload import DeleteDatasetPayload
        from ..models.execute_run_payload import ExecuteRunPayload
        from ..models.refresh_dataset_payload import RefreshDatasetPayload
        from ..models.sync_catalog_to_s3_payload import SyncCatalogToS3Payload
        from ..models.vacuum_ducklake_payload import VacuumDucklakePayload

        id = self.id

        type_ = self.type_.value

        status = self.status.value

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        payload: dict[str, Any] | None | Unset
        if isinstance(self.payload, Unset):
            payload = UNSET
        elif isinstance(self.payload, RefreshDatasetPayload):
            payload = self.payload.to_dict()
        elif isinstance(self.payload, DeleteDatasetPayload):
            payload = self.payload.to_dict()
        elif isinstance(self.payload, VacuumDucklakePayload):
            payload = self.payload.to_dict()
        elif isinstance(self.payload, SyncCatalogToS3Payload):
            payload = self.payload.to_dict()
        elif isinstance(self.payload, ExecuteRunPayload):
            payload = self.payload.to_dict()
        else:
            payload = self.payload

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        dataset_id: None | str | Unset
        if isinstance(self.dataset_id, Unset):
            dataset_id = UNSET
        else:
            dataset_id = self.dataset_id

        project_id: None | str | Unset
        if isinstance(self.project_id, Unset):
            project_id = UNSET
        else:
            project_id = self.project_id

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        else:
            created_at = self.created_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "type": type_,
                "status": status,
            }
        )
        if error is not UNSET:
            field_dict["error"] = error
        if payload is not UNSET:
            field_dict["payload"] = payload
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if dataset_id is not UNSET:
            field_dict["datasetId"] = dataset_id
        if project_id is not UNSET:
            field_dict["projectId"] = project_id
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.delete_dataset_payload import DeleteDatasetPayload
        from ..models.execute_run_payload import ExecuteRunPayload
        from ..models.refresh_dataset_payload import RefreshDatasetPayload
        from ..models.sync_catalog_to_s3_payload import SyncCatalogToS3Payload
        from ..models.vacuum_ducklake_payload import VacuumDucklakePayload

        d = dict(src_dict)
        id = d.pop("id")

        type_ = WorkerTaskType(d.pop("type"))

        status = WorkerTaskStatus(d.pop("status"))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        def _parse_payload(
            data: object,
        ) -> (
            DeleteDatasetPayload
            | ExecuteRunPayload
            | None
            | RefreshDatasetPayload
            | SyncCatalogToS3Payload
            | Unset
            | VacuumDucklakePayload
        ):
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                payload_type_0_type_0 = RefreshDatasetPayload.from_dict(data)

                return payload_type_0_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                payload_type_0_type_1 = DeleteDatasetPayload.from_dict(data)

                return payload_type_0_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                payload_type_0_type_2 = VacuumDucklakePayload.from_dict(data)

                return payload_type_0_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                payload_type_0_type_3 = SyncCatalogToS3Payload.from_dict(data)

                return payload_type_0_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                payload_type_0_type_4 = ExecuteRunPayload.from_dict(data)

                return payload_type_0_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                DeleteDatasetPayload
                | ExecuteRunPayload
                | None
                | RefreshDatasetPayload
                | SyncCatalogToS3Payload
                | Unset
                | VacuumDucklakePayload,
                data,
            )

        payload = _parse_payload(d.pop("payload", UNSET))

        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("userId", UNSET))

        def _parse_dataset_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dataset_id = _parse_dataset_id(d.pop("datasetId", UNSET))

        def _parse_project_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        project_id = _parse_project_id(d.pop("projectId", UNSET))

        def _parse_created_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_updated_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_at = _parse_updated_at(d.pop("updatedAt", UNSET))

        worker_task_response = cls(
            id=id,
            type_=type_,
            status=status,
            error=error,
            payload=payload,
            user_id=user_id,
            dataset_id=dataset_id,
            project_id=project_id,
            created_at=created_at,
            updated_at=updated_at,
        )

        worker_task_response.additional_properties = d
        return worker_task_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
