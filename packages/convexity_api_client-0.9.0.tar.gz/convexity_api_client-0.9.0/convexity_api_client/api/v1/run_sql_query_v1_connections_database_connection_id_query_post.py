from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.sql_query_request import SqlQueryRequest
from ...models.sql_query_response import SqlQueryResponse
from ...types import Response


def _get_kwargs(
    connection_id: str,
    *,
    body: SqlQueryRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/connections/database/{connection_id}/query".format(
            connection_id=quote(str(connection_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SqlQueryResponse | None:
    if response.status_code == 200:
        response_200 = SqlQueryResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SqlQueryResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SqlQueryRequest,
) -> Response[HTTPValidationError | SqlQueryResponse]:
    """Run Sql Query

     Run SQL query. Requires viewer role.

    Args:
        connection_id (str):
        body (SqlQueryRequest): Request payload for running ad-hoc SQL queries against a database
            connection.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SqlQueryResponse]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SqlQueryRequest,
) -> HTTPValidationError | SqlQueryResponse | None:
    """Run Sql Query

     Run SQL query. Requires viewer role.

    Args:
        connection_id (str):
        body (SqlQueryRequest): Request payload for running ad-hoc SQL queries against a database
            connection.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SqlQueryResponse
    """

    return sync_detailed(
        connection_id=connection_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SqlQueryRequest,
) -> Response[HTTPValidationError | SqlQueryResponse]:
    """Run Sql Query

     Run SQL query. Requires viewer role.

    Args:
        connection_id (str):
        body (SqlQueryRequest): Request payload for running ad-hoc SQL queries against a database
            connection.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SqlQueryResponse]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SqlQueryRequest,
) -> HTTPValidationError | SqlQueryResponse | None:
    """Run Sql Query

     Run SQL query. Requires viewer role.

    Args:
        connection_id (str):
        body (SqlQueryRequest): Request payload for running ad-hoc SQL queries against a database
            connection.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SqlQueryResponse
    """

    return (
        await asyncio_detailed(
            connection_id=connection_id,
            client=client,
            body=body,
        )
    ).parsed
