from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.share_token_exchange_request import ShareTokenExchangeRequest
from ...models.token_response import TokenResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: ShareTokenExchangeRequest,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(referer, Unset):
        headers["referer"] = referer

    if not isinstance(origin, Unset):
        headers["origin"] = origin

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/public/auth/token",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | TokenResponse | None:
    if response.status_code == 200:
        response_200 = TokenResponse.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = cast(Any, None)
        return response_403

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | TokenResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ShareTokenExchangeRequest,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | TokenResponse]:
    """Exchange Share Token

     Exchange a share token for a short-lived JWT access token.

    This endpoint allows public dashboard viewers to obtain a JWT that can
    be used to authenticate subsequent API requests. The JWT:
    - Is valid for 15 minutes
    - Acts on behalf of the user who created the share
    - Contains metadata about the share (dashboard_id, share_id)

    The frontend should:
    1. Call this endpoint when loading a public dashboard
    2. Use the returned JWT for all subsequent API calls
    3. Re-call this endpoint when the token expires (check expires_at)

    Args:
        request: Contains the share_token to exchange
        referer: The Referer header (used for domain validation)
        origin: The Origin header (fallback for domain validation)

    Returns:
        TokenResponse with JWT and expiration info

    Args:
        referer (None | str | Unset):
        origin (None | str | Unset):
        body (ShareTokenExchangeRequest): Request to exchange a share token for a JWT.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | TokenResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        referer=referer,
        origin=origin,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ShareTokenExchangeRequest,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | TokenResponse | None:
    """Exchange Share Token

     Exchange a share token for a short-lived JWT access token.

    This endpoint allows public dashboard viewers to obtain a JWT that can
    be used to authenticate subsequent API requests. The JWT:
    - Is valid for 15 minutes
    - Acts on behalf of the user who created the share
    - Contains metadata about the share (dashboard_id, share_id)

    The frontend should:
    1. Call this endpoint when loading a public dashboard
    2. Use the returned JWT for all subsequent API calls
    3. Re-call this endpoint when the token expires (check expires_at)

    Args:
        request: Contains the share_token to exchange
        referer: The Referer header (used for domain validation)
        origin: The Origin header (fallback for domain validation)

    Returns:
        TokenResponse with JWT and expiration info

    Args:
        referer (None | str | Unset):
        origin (None | str | Unset):
        body (ShareTokenExchangeRequest): Request to exchange a share token for a JWT.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | TokenResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        referer=referer,
        origin=origin,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ShareTokenExchangeRequest,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | TokenResponse]:
    """Exchange Share Token

     Exchange a share token for a short-lived JWT access token.

    This endpoint allows public dashboard viewers to obtain a JWT that can
    be used to authenticate subsequent API requests. The JWT:
    - Is valid for 15 minutes
    - Acts on behalf of the user who created the share
    - Contains metadata about the share (dashboard_id, share_id)

    The frontend should:
    1. Call this endpoint when loading a public dashboard
    2. Use the returned JWT for all subsequent API calls
    3. Re-call this endpoint when the token expires (check expires_at)

    Args:
        request: Contains the share_token to exchange
        referer: The Referer header (used for domain validation)
        origin: The Origin header (fallback for domain validation)

    Returns:
        TokenResponse with JWT and expiration info

    Args:
        referer (None | str | Unset):
        origin (None | str | Unset):
        body (ShareTokenExchangeRequest): Request to exchange a share token for a JWT.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | TokenResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        referer=referer,
        origin=origin,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ShareTokenExchangeRequest,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | TokenResponse | None:
    """Exchange Share Token

     Exchange a share token for a short-lived JWT access token.

    This endpoint allows public dashboard viewers to obtain a JWT that can
    be used to authenticate subsequent API requests. The JWT:
    - Is valid for 15 minutes
    - Acts on behalf of the user who created the share
    - Contains metadata about the share (dashboard_id, share_id)

    The frontend should:
    1. Call this endpoint when loading a public dashboard
    2. Use the returned JWT for all subsequent API calls
    3. Re-call this endpoint when the token expires (check expires_at)

    Args:
        request: Contains the share_token to exchange
        referer: The Referer header (used for domain validation)
        origin: The Origin header (fallback for domain validation)

    Returns:
        TokenResponse with JWT and expiration info

    Args:
        referer (None | str | Unset):
        origin (None | str | Unset):
        body (ShareTokenExchangeRequest): Request to exchange a share token for a JWT.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | TokenResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            referer=referer,
            origin=origin,
        )
    ).parsed
