"""Functionality specific to PointStudio.

The contents of this module are not guaranteed to function unless the connected
application is PointStudio.
"""
