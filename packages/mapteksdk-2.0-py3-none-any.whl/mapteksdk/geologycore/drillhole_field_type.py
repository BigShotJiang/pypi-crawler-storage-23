"""Enumeration used to represent the type of a drillhole field."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import enum

import numpy as np

from ..data.units import NO_UNIT, AngleUnit, DistanceUnit, NoUnitType

class DrillholeFieldType(enum.Enum):
  """Enumeration of supported common field types.

  The field type indicates what the data in the field is intended to represent.
  """
  # :NOTE: This is based off of the string constants defined in:
  # mdf_products/mdf/src/drillholedatabase/api/FieldTypes.C
  # which are used to generate the JSON description of the Database.
  # If a new item is added to that enum and not added here, it will appear
  # as the "UNKNOWN" field type.
  NONE = ""
  """This field stores custom data not covered by another field type."""
  EASTING = "Easting"
  NORTHING = "Northing"
  ELEVATION = "RL"
  TOTAL_DEPTH = "Total depth"
  FROM_DEPTH = "From depth"
  TO_DEPTH = "To depth"
  THICKNESS = "Thickness"
  ROCK_TYPE = "Rock type"
  HORIZON = "Horizon"
  DEPTH = "Depth"
  AZIMUTH = "Azimuth"
  DIP = "Dip"
  UNKNOWN = "?"

  def can_be_repeated(self) -> bool:
    """True if a table can contain multiple fields of this type."""
    if self in (
        DrillholeFieldType.ROCK_TYPE,
        DrillholeFieldType.HORIZON,
        DrillholeFieldType.NONE):
      return True
    return False

  def supports_data_type(self, data_type: np.dtype | type) -> bool:
    """Determine if this field type supports the specified data type.

    Parameters
    ----------
    data_type
      Data type to check if it is supported.

    Returns
    -------
    bool
      True if the data type is supported.
    """
    supports_float_types = {
      DrillholeFieldType.NONE,
      DrillholeFieldType.EASTING,
      DrillholeFieldType.NORTHING,
      DrillholeFieldType.ELEVATION,
      DrillholeFieldType.TOTAL_DEPTH,
      DrillholeFieldType.FROM_DEPTH,
      DrillholeFieldType.TO_DEPTH,
      DrillholeFieldType.THICKNESS,
      DrillholeFieldType.DEPTH,
      DrillholeFieldType.AZIMUTH,
      DrillholeFieldType.DIP
    }

    supports_int_types = {
      DrillholeFieldType.NONE,
      DrillholeFieldType.EASTING,
      DrillholeFieldType.NORTHING,
      DrillholeFieldType.ELEVATION,
      DrillholeFieldType.TOTAL_DEPTH,
    }

    supports_bool_types = {
      DrillholeFieldType.NONE,
    }

    supports_str_types = {
      DrillholeFieldType.NONE,
      DrillholeFieldType.ROCK_TYPE,
      DrillholeFieldType.HORIZON,
    }

    if data_type in (np.float32, np.float64) and self in supports_float_types:
      return True
    if data_type == np.int32 and self in supports_int_types:
      return True
    if data_type == np.bool_ and self in supports_bool_types:
      return True
    if data_type == np.str_ and self in supports_str_types:
      return True

    return False

  @property
  def is_built_in(self) -> bool:
    """If the field is a built in field.

    This will return False for DrillholeFieldType.NONE and True for every
    other field type.
    """
    return self is not DrillholeFieldType.NONE

  @property
  def is_custom(self) -> bool:
    """If the field is a user-defined field.

    This is the inverse of is_built_in.
    """
    return not self.is_built_in

  @property
  def supports_distance_units(self) -> bool:
    """True if this field type supports distance units."""
    field_types_which_support_distance_units: set[DrillholeFieldType] = {
      DrillholeFieldType.EASTING,
      DrillholeFieldType.NORTHING,
      DrillholeFieldType.ELEVATION,
      DrillholeFieldType.TOTAL_DEPTH,
      DrillholeFieldType.TO_DEPTH,
      DrillholeFieldType.FROM_DEPTH,
      DrillholeFieldType.THICKNESS,
      DrillholeFieldType.DEPTH,
      DrillholeFieldType.NONE,
    }

    return self in field_types_which_support_distance_units

  @property
  def supports_angle_units(self) -> bool:
    """True if the field type supports angle units."""
    return self in (
      DrillholeFieldType.AZIMUTH,
      DrillholeFieldType.DIP,
      DrillholeFieldType.NONE,
    )

  @property
  def default_unit(self) -> DistanceUnit | AngleUnit | NoUnitType:
    """The default unit for fields of this type.

    This is NO_UNIT for the OTHER field type, metres for distance fields
    and radians for angle fields.
    """
    if self.is_custom:
      return NO_UNIT
    if self.supports_angle_units:
      return AngleUnit.RADIANS
    if self.supports_distance_units:
      return DistanceUnit.METRE
    return NO_UNIT