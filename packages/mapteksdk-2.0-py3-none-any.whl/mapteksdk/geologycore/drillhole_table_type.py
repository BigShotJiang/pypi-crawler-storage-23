"""Enumeration used to store the type of tables in drillhole databases."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################

import enum


class DrillholeTableType(enum.Enum):
  """Enumeration of supported table types."""
  # :NOTE: 2022-04-13 This is based off of the string constants defined in:
  # mdf_products/mdf/src/drillholedatabase/api/TableType.C
  # which are used to generate the JSON description of the Database.
  # If a new item is added to that enum and not added here, it will appear
  # as the "UNKNOWN" table type.
  COLLAR = "Collar"
  GEOLOGY = "Geology"
  ASSAY = "Assay"
  QUALITY = "Quality"
  DOWNHOLE = "Downhole"
  SURVEY = "Survey"
  OTHER = "Other"
  UNKNOWN  = ""

  def must_be_unique(self) -> bool:
    """True if a database can contain multiple tables of this type."""
    if self in (
        DrillholeTableType.ASSAY,
        DrillholeTableType.GEOLOGY,
        DrillholeTableType.QUALITY,
        DrillholeTableType.DOWNHOLE,
        DrillholeTableType.OTHER):
      return False
    return True