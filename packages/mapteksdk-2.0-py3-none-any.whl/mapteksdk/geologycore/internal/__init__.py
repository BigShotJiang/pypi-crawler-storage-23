"""Internal implementation details for the GeologyCore module.

Warnings
--------
Vendors and clients should not develop scripts or applications against the
contents of this package.
"""
###############################################################################
#
# (C) Copyright 2022, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
