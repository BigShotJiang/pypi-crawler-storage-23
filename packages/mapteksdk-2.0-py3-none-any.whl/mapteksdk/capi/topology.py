"""Interface for the MDF topology library.

Warnings
--------
Vendors and clients should not develop scripts or applications against
this module. The contents may change at any time without warning.

"""
###############################################################################
#
# (C) Copyright 2023, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

# pylint: disable=line-too-long
# pylint: disable=invalid-name;reason=Names match C++ names.
import ctypes
import math
import typing

import numpy as np

from ..errors import ApplicationTooOldError
from .errors import CApiUnknownError
from .wrapper_base import WrapperBase

if typing.TYPE_CHECKING:
  # pylint: disable=protected-access
  T = typing.TypeVar("T", bound=ctypes._CData)


class Triple(ctypes.Structure):
  """A struct that represents a triple index using three uint32s"""
  _fields_ = (("a", ctypes.c_uint32),
              ("b", ctypes.c_uint32),
              ("c", ctypes.c_uint32))

  def __str__(self):
    return f"({self.a}, {self.b}, {self.c})"


class Point(ctypes.Structure):
  """A struct that represents a geoS_Point space using three doubles.

  Parameters
  ----------
  x
    The x coordinate of the point. This can be infinite.
  y
    The y coordinate of the point. This can be infinite.
  z
    The z coordinate of the point. This can be infinite.

  Raises
  ------
  ValueError
    If x, y or z are NaN.
  """
  _fields_ = (("x", ctypes.c_double),
              ("y", ctypes.c_double),
              ("z", ctypes.c_double))

  def __init__(self, x, y, z) -> None:
    if any(math.isnan(i) for i in (x, y, z)):
      raise ValueError(
        f"Point cannot contain NaN. Point: ({x}, {y}, {z})")
    super().__init__(x, y, z)

  def __str__(self):
    return f"({self.x}, {self.y}, {self.z})"


def create_triple_with_limit(a: int, b: int, c: int, limit: int) -> Triple:
  """Create a triple with error checking.

  Parameters
  ----------
  a
    First element of the triple.
  b
    Second element of the triple.
  c
    Third element of the triple.
  limit
    An error will be raised if a, b or c are greater than or equal to
    the limit.

  Returns
  -------
  Triple
    Triple constructed from a, b and c

  Raises
  ------
  ValueError
    If a, b or c were greater than or equal to the limit.
  """
  if any(i >= limit for i in (a, b, c)):
    raise ValueError(
      f"Invalid point index in facet. All indices must be less than {limit}. "
      f"Indices: ({a}, {b}, {c})")
  return Triple(a, b, c)


def create_array_of_points(points) -> ctypes.Array[Point]:
  """Create an array of Point structs from points."""
  return (Point * len(points))(*(Point(x, y, z) for x, y, z in points))


def create_array_of_triples_with_limit(facets, limit: int) -> ctypes.Array[Triple]:
  """Create an array of triples from `facets`.

  Raises
  ------
  ValueError
    If any element in `facets` is greater than limit.
  """
  return (Triple * len(facets))(
    *(create_triple_with_limit(a, b, c, limit) for a, b, c in facets)
  )


def get_end_of_array(array: ctypes.Array[T], element_type: type[T]) -> ctypes._CArgObject:
  """Get an end point for `array`."""
  return ctypes.byref(
    array[0],
    ctypes.sizeof(element_type) * len(array)
  )


class TopologyApi(WrapperBase):
  """Access to the application topology API.

  This should be accessed through get_application_dlls() for new code.
  """
  @staticmethod
  def method_prefix():
    return "Topology"

  @staticmethod
  def dll_name() -> str:
    return "mdf_topology"

  def capi_functions(self):
    return [
      # Functions changed in version 0.
      # Format:
      # "name" : (return_type, arg_types)
      {
        "TopologyRegisterPointSetToSurface" : (
          ctypes.c_bool,
          [
            ctypes.POINTER(Point),
            ctypes.POINTER(Triple),
            ctypes.POINTER(Triple),
            ctypes.POINTER(Point),
            ctypes.POINTER(Point),
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_uint32),
          ]
        ),
        "TopologyCheckFacetNetworkValidity" : (
          ctypes.c_uint8,
          [
            ctypes.POINTER(Point),
            ctypes.POINTER(Triple),
            ctypes.POINTER(Triple),
            ctypes.c_bool,
          ]
        ),
        "TopologyClassifyPointsInSolid" : (
          None,
          [
            ctypes.POINTER(Point),
            ctypes.POINTER(Triple),
            ctypes.POINTER(Triple),
            ctypes.POINTER(Point),
            ctypes.POINTER(Point),
            ctypes.POINTER(ctypes.c_bool),
          ]
        ),
        "TopologyClassifyPointsAboveOrBelowSurface" : (
          None,
          [
            ctypes.POINTER(Point),
            ctypes.POINTER(Triple),
            ctypes.POINTER(Triple),
            ctypes.POINTER(Point),
            ctypes.POINTER(Point),
            ctypes.POINTER(ctypes.c_uint8),
          ]
        ),
      },
      # Functions changed in version 1.
      {
        "TopologyCApiVersion" : (ctypes.c_uint32, None),
        "TopologyCApiMinorVersion" : (ctypes.c_uint32, None),

        # New in 1.16.
        "TopologyClassifyPointsInsideSolidV2" : (
          ctypes.c_uint8, [
            ctypes.c_uint64,
            ctypes.POINTER(ctypes.c_double),
            ctypes.c_uint64,
            ctypes.POINTER(ctypes.c_uint32),
            ctypes.c_uint64,
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_bool), ]
          ),
      }
    ]

  def _in_solid_old_application(
    self,
    surface_points: np.ndarray,
    surface_facets: np.ndarray,
    points_to_classify: np.ndarray
  ) -> np.ndarray:
    c_points = create_array_of_points(surface_points)
    c_facets = create_array_of_triples_with_limit(surface_facets, len(surface_points))
    c_points_to_classify = create_array_of_points(points_to_classify)

    classifications = (ctypes.c_bool * len(points_to_classify))()
    try:
      self.dll.TopologyClassifyPointsInSolid(
        c_points,
        c_facets,
        get_end_of_array(c_facets, Triple),
        c_points_to_classify,
        get_end_of_array(c_points_to_classify, Point),
        classifications
      )
    except OSError:
      raise ApplicationTooOldError(
        "Failed to run solid filter. "
        "There is a bug in PointStudio 2025 and 2025.1 and GeologyCore 2025 "
        "which can cause the solid spatial filter to fail. "
        "To resolve, upgrade to a newer version of the application "
        "or simplify the solid to have less than 1000 facets."
      ) from None

    return np.array(classifications, dtype=ctypes.c_bool)

  def _in_solid_new_application(
    self,
    surface_points: np.ndarray,
    surface_facets: np.ndarray,
    points_to_classify: np.ndarray
  ) -> np.ndarray:
    point_count = len(surface_points)
    facet_count = len(surface_facets)
    points_to_classify_count = len(points_to_classify)

    flattened_points = (ctypes.c_double * (point_count * 3))()
    flattened_points[:] = surface_points.reshape(-1)

    flattened_facets = (ctypes.c_uint32 * (facet_count * 3))()
    flattened_facets[:] = surface_facets.reshape(-1)

    flattened_points_to_classify = (ctypes.c_double * (points_to_classify_count * 3))()
    flattened_points_to_classify[:] = points_to_classify.reshape(-1)

    classifications = (ctypes.c_bool * len(points_to_classify))()

    failure = self.dll.TopologyClassifyPointsInsideSolidV2(
      point_count,
      flattened_points,
      facet_count,
      flattened_facets,
      points_to_classify_count,
      flattened_points_to_classify,
      classifications
    )

    if failure:
      raise CApiUnknownError("Failed to classify points.")
    return np.array(classifications, dtype=ctypes.c_bool)

  def RegisterPointSetToSurface(
      self,
      surface_points,
      surface_facet_to_point_index,
      point_set_to_register):
    """Register a point set to a facet network surface.

    Parameters
    ----------
    surface_points: typing.Iterable[typing.Iterable[float]]
      An iterable containing three dimensional points (iterables containing
      three floating point numbers) representing the points on the surface
      to project point_set_to_register onto.
    surface_facet_to_point_index: typing.Iterable[typing.Iterable[int]]
      An iterable containing iterables of three integers. Each inner
      iterable represents which points make up each facet of the surface.
    point_set_to_register:
      An iterable containing three dimensional points (iterables containing
      three floating point numbers) representing the points to project onto
      the surface.

    Returns
    -------
    registered_z_values: ctypes.Array[ctypes.c_double]
      The adjusted z coordinates required to project point_set_to_register
      onto the surface. This has the same length as point_set_to_register.
    point_to_projected_facet_map: ctypes.Array[ctypes.c_uint32]
      Which facet each point in point_set_to_register was projected onto.
      This has the same length as point_set_to_register.

    Raises
    ------
    ValueError
      If surface_points or point_set_to_register contains a NaN.

    Warnings
    --------
    This will encounter an infinite loop if point_set_to_register contains
    a NaN.

    Notes
    -----
    This returns the ctypes types to avoid an extra copy when converting
    the output into a NumPy array.

    Examples
    --------
    The following example demonstrates using this function to project
    two points onto a surface with four points and two facets.

    >>> surface_points = ((0, 0, 20), (0, 10, 20), (10, 10, 20), (10, 0, 20))
    >>> surface_facet_to_point_index = ((0, 1, 2), (2, 3, 0))
    >>> point_set_to_register = ((5, 5, 5), (5, 1, 0))
    >>> z_values, point_to_projected_facet = Topology(
    ...     ).RegisterPointSetToSurface(
    ...         surface_points,
    ...         surface_facet_to_point_index,
    ...         point_set_to_register)
    """
    c_surface_points = create_array_of_points(surface_points)
    c_surface_facets = create_array_of_triples_with_limit(surface_facet_to_point_index, len(surface_points))
    c_point_set_to_register = create_array_of_points(point_set_to_register)
    registered_z_values = (ctypes.c_double * len(point_set_to_register))(
      *(z for _, _, z in point_set_to_register)
    )
    point_to_projected_facet_map = (ctypes.c_uint32 * len(point_set_to_register))()

    success = self.dll.TopologyRegisterPointSetToSurface(
      c_surface_points,
      c_surface_facets,
      get_end_of_array(c_surface_facets, Triple),
      c_point_set_to_register,
      get_end_of_array(c_point_set_to_register, Point),
      registered_z_values,
      point_to_projected_facet_map)

    if not success:
      raise CApiUnknownError("Failed to project points onto surface.")

    return registered_z_values, point_to_projected_facet_map

  def ClassifyPointsInSolid(
    self,
    surface_points: np.ndarray,
    surface_facets: np.ndarray,
    points_to_classify: np.ndarray
  ) -> np.ndarray:
    """Classify if points are inside a solid.

    Parameters
    ----------
    surface_points
      The points which make up the solid.
    surface_facets
      The facets which make up the solid. These must have consistent
      normals and must not have any holes.
    points_to_classify
      The points to classify.

    Returns
    -------
    numpy.ndarray
      A numpy array containing the classifications.
      True indicates the point was in or on the solid, False indicates it was
      outside.
    """
    if hasattr(self.dll, "TopologyClassifyPointsInsideSolidV2"):
      return self._in_solid_new_application(
        surface_points,
        surface_facets,
        points_to_classify
      )
    return self._in_solid_old_application(
      surface_points,
      surface_facets,
      points_to_classify
    )

  def ClassifyPointsAboveOrBelowSurface(
    self,
    surface_points,
    surface_facets,
    points_to_classify,
  ) -> np.ndarray:
    """Classify if points are above, below or on a surface.

    Parameters
    ----------
    surface_points
      The points which make up the surface.
    surface_facets
      The facets which make up the surface. These must have consistent
      normals.
    points_to_classify
      The points to classify.

    Returns
    -------
    numpy.ndarray
      A numpy array containing the classifications.
      This has one element for each point in points_to_classify and is encoded
      like this:
      * 0 = Above the surface.
      * 1 = On the surface.
      * 2 = Below the surface.
      * 3 = Outside the surface (i.e. neither above, below or on the surface).
    """
    c_points = create_array_of_points(surface_points)
    c_facets = create_array_of_triples_with_limit(surface_facets, len(surface_points))
    c_points_to_classify = create_array_of_points(points_to_classify)

    classifications = (ctypes.c_uint8 * len(points_to_classify))()
    self.dll.TopologyClassifyPointsAboveOrBelowSurface(
      c_points,
      c_facets,
      get_end_of_array(c_facets, Triple),
      c_points_to_classify,
      get_end_of_array(c_points_to_classify, Point),
      classifications
    )

    return np.array(classifications, dtype=ctypes.c_uint8)

  def CheckFacetNetworkValidity(
    self,
    points,
    facets,
    check_for_solid: bool,
  ) -> bool:
    """Check if `points` and `facets` define a valid surface.

    A valid surface has no trifurcations, consistent normals and no
    self-intersections.

    Parameters
    ----------
    points
      Points of the surface to check for validity.
    facets
      Facets of the surface to check for validity.
    check_for_solid
      If True, only return true if the surface is a closed solid.
      If False, only return true if the surface is not a closed solid.

    Returns
    -------
    bool
      True if the surface is valid.
    """
    c_points = create_array_of_points(points)
    c_facets = create_array_of_triples_with_limit(facets, len(points))

    result = self.dll.TopologyCheckFacetNetworkValidity(
      c_points,
      c_facets,
      get_end_of_array(c_facets, Triple),
      check_for_solid
    )

    if check_for_solid:
      return result == 1
    return result == 0
