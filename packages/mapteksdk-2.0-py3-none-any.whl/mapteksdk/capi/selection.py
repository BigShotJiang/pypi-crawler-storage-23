"""Interface for the MDF selection library.

Warnings
--------
Vendors and clients should not develop scripts or applications against
this module. The contents may change at any time without warning.

"""
###############################################################################
#
# (C) Copyright 2020, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

# pylint: disable=line-too-long
import ctypes
from collections.abc import Sequence

from ..errors import ApplicationTooOldError
from .errors import CApiUnknownError
from .types import T_ObjectHandle, T_TypeIndex, T_ReadHandle
from .util import raise_if_version_too_old
from .wrapper_base import WrapperBase


class SelectionApi(WrapperBase):
  """Access to the application selection API.

  This should be accessed through get_application_dlls() for new code.
  """
  @staticmethod
  def method_prefix():
    return "Selection"

  @staticmethod
  def dll_name() -> str:
    return "mdf_selection"

  def capi_functions(self):
    return [
      # Functions changed in version 0.
      # Format:
      # "name" : (return_type, arg_types)
      {"SelectionSaveGlobalSelection" : (T_ObjectHandle, None),
       "SelectionSetGlobalSelection" : (ctypes.c_void_p, [T_ObjectHandle, ]),
       "SelectionFreeSavedSelection" : (ctypes.c_void_p, [T_ObjectHandle, ]),},
      # Functions changed in version 1.
      {"SelectionCApiVersion" : (ctypes.c_uint32, None),
       "SelectionCApiMinorVersion" : (ctypes.c_uint32, None),

       # New in API version 1.13:
       "SelectionGroupType" : (T_TypeIndex, None),
       "SelectionGetSelectionGroupContextType" : (ctypes.c_uint8, [ctypes.POINTER(T_ReadHandle), ctypes.POINTER(ctypes.c_uint8), ]),
       "SelectionSetSelectionGroupContextType" : (ctypes.c_uint8, [ctypes.POINTER(T_ReadHandle), ctypes.c_uint8, ]),

       # New in API version 1.14:
       "SelectionGetGroupTarget" : (ctypes.c_uint8, [ctypes.POINTER(T_ReadHandle), ctypes.POINTER(T_ObjectHandle), ]),
       "SelectionSetGroupTarget" : (ctypes.c_uint8, [ctypes.POINTER(T_ReadHandle), T_ObjectHandle, ]),
       "SelectionGetGroupSelectionItems" : (ctypes.c_uint8, [ctypes.POINTER(T_ReadHandle), ctypes.POINTER(T_ObjectHandle), ctypes.POINTER(ctypes.c_uint64), ]),
       "SelectionSetGroupSelectionItems" : (ctypes.c_uint8, [ctypes.POINTER(T_ReadHandle), ctypes.POINTER(T_ObjectHandle), ctypes.c_uint64, ]),
      }
    ]

  def GroupType(self) -> int:
    """Get the static type for selection group objects."""
    raise_if_version_too_old(
      "Querying type of selection groups",
      current_version=self.version,
      required_version=(1, 13)
    )
    return self.dll.SelectionGroupType()

  def GetSelectionGroupContextType(self, read_handle: T_ReadHandle) -> int:
    """Get the context type index for the selection group `read_handle`.

    If the application is newer than the SDK, this may not return a context type
    index which the SDK knows about.
    """
    raise_if_version_too_old(
      "Querying selection group context type",
      current_version=self.version,
      required_version=(1, 13)
    )

    c_index = ctypes.c_uint8()
    result = self.dll.SelectionGetSelectionGroupContextType(read_handle, ctypes.byref(c_index))
    if result != 0:
      raise CApiUnknownError("Failed to query selection group context type.")
    return c_index.value

  def SetSelectionGroupContextType(self, edit_handle: T_ReadHandle, group_context_index: int):
    """Set the context type index for the selection group `edit_handle`.

    Raises
    ------
    ApplicationTooOldError
      If `group_context_index` is not supported by the connected application.
    """
    raise_if_version_too_old(
      "Querying selection group context type",
      current_version=self.version,
      required_version=(1, 13)
    )

    result = self.dll.SelectionSetSelectionGroupContextType(edit_handle, group_context_index)
    if result == 3:
      raise ApplicationTooOldError("The application does not support the SelectionGroup's context.")
    if result != 0:
      raise CApiUnknownError("Failed to set selection group context type.")

  def GetGroupTarget(self, read_handle: T_ReadHandle) -> T_ObjectHandle:
    """Get the target of the selection group `read_handle`."""
    raise_if_version_too_old(
      "Querying selection group target",
      current_version=self.version,
      required_version=(1, 14)
    )

    handle = T_ObjectHandle(0)
    result = self.dll.SelectionGetGroupTarget(read_handle, ctypes.byref(handle))

    if result != 0:
      raise CApiUnknownError("Failed to get selection group target.")

    return handle

  def SetGroupTarget(self, edit_handle: T_ReadHandle, handle: T_ObjectHandle):
    """Set the target of selection group open with `edit_handle` to `handle`."""
    raise_if_version_too_old(
      "Setting selection group target",
      current_version=self.version,
      required_version=(1, 14)
    )

    result = self.dll.SelectionSetGroupTarget(edit_handle, handle)

    if result != 0:
      raise CApiUnknownError("Failed to set selection group target.")

  def GetGroupSelectionItems(self, read_handle: T_ReadHandle) -> Sequence[T_ObjectHandle]:
    """Get the selection items from the group open with `read_handle`.

    The returned sequence may contain object ids which are not selection
    files.
    """
    raise_if_version_too_old(
      "Getting selection group selection items",
      current_version=self.version,
      required_version=(1, 14)
    )
    buffer_size = ctypes.c_uint64(0)

    result = self.dll.SelectionGetGroupSelectionItems(
      read_handle,
      None,
      ctypes.byref(buffer_size)
    )

    if result == 0:
      # There were no items in the group.
      return tuple()
    if result != 5:
      raise CApiUnknownError("Failed to get selection items.")

    buffer = (T_ObjectHandle * buffer_size.value)()
    result = self.dll.SelectionGetGroupSelectionItems(
      read_handle,
      buffer,
      ctypes.byref(buffer_size)
    )
    if result != 0:
      raise CApiUnknownError("Failed to get selection items.")
    return tuple(handle for handle in buffer)

  def SetGroupSelectionItems(self, edit_handle: T_ReadHandle, handles: Sequence[T_ObjectHandle]):
    """Set the selection items for the group open with `edit_handle` to `handles`."""
    raise_if_version_too_old(
      "Setting selection group target",
      current_version=self.version,
      required_version=(1, 14)
    )

    buffer_size = len(handles)
    buffer = (T_ObjectHandle * buffer_size)(*handles)
    result = self.dll.SelectionSetGroupSelectionItems(
      edit_handle,
      buffer,
      ctypes.c_uint64(buffer_size)
    )
    if result != 0:
      raise CApiUnknownError("Failed to set selection items.")
