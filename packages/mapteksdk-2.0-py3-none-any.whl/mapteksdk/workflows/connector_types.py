"""Basic connector type subclasses.

These can be passed to WorkflowArgumentParser.declare_input_connector
and WorkflowArgumentParser.declare_output_connector to determine which
type of data the connector should accept. The names of these classes
match the names of the connectors types as displayed in workflows.

"""
###############################################################################
#
# (C) Copyright 2021, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

from collections.abc import Iterable
import csv
import datetime
import os
import pathlib
import typing

import numpy as np

from .connector_type import (
  ConnectorType,
  DataType,
  Dimensionality,
  DynamicConnectorType,
  PortType,
)
from .errors import UnsupportedInputTypeError
from ..internal.util import default_type_error_message

if typing.TYPE_CHECKING:
  from .internal.typing import JsonValues

  PythonPortTypes: typing.TypeAlias = (
    str
    | int
    | float
    | bool
    | list
    | datetime.datetime
    | pathlib.Path
    | None
  )

  AnyPortType: typing.TypeAlias = (
    PortType
    | DynamicConnectorType
    | type[ConnectorType]
  )

@typing.overload
def python_type_to_connector_type(
  python_type: ConnectorType
) -> ConnectorType:
  ...

@typing.overload
def python_type_to_connector_type(
  python_type: PortType
) -> PortType:
  ...

@typing.overload
def python_type_to_connector_type(
  python_type: DynamicConnectorType
) -> DynamicConnectorType:
  ...

@typing.overload
def python_type_to_connector_type(
  python_type: type[PythonPortTypes] | None
) -> PortType | DynamicConnectorType:
  ...

def python_type_to_connector_type(
  python_type: type[PythonPortTypes] | AnyPortType | None
) -> AnyPortType:
  """Returns the corresponding ConnectorType subclass for a Python type.

  This only contains mappings for the ConnectorType subclasses
  defined in this file.

  Parameters
  ----------
  python_type : Type
    The Python type to match to a basic connector type.

  Returns
  -------
  ConnectorType
    The corresponding ConnectorType subclass from this file.

  Raises
  ------
  KeyError
    If there was no corresponding ConnectorType subclass.

  """
  if python_type is None:
    return AnyConnectorType
  try:
    if isinstance(python_type, type) and issubclass(python_type, ConnectorType):
      return python_type
  except TypeError:
    pass

  if isinstance(python_type, (DynamicConnectorType, PortType)):
    return python_type

  try:
    return python_type_to_dynamic_connector_type(python_type)
  except KeyError as error:
    raise ValueError("Connector type must be a ConnectorType subclass"
      ) from error

def python_type_to_dynamic_connector_type(
  python_type: type[PythonPortTypes]
) -> DynamicConnectorType:
  """Map a Python type to the corresponding dynamic connector type."""
  type_mapping: dict[type, DynamicConnectorType] = {
    str: StringConnectorType,
    int: IntegerConnectorType,
    float: DoubleConnectorType,
    bool: BooleanConnectorType,
    list: CSVStringConnectorType,
    datetime.datetime: DateTimeConnectorType,
    pathlib.Path: FileConnectorType,
  }
  return type_mapping[python_type]


def python_type_to_port_type(
  python_type: type[PythonPortTypes]
) -> PortType:
  """Get the port type for a given Python type."""
  type_mapping: dict[type, PortType] = {
    str: StringConnectorType,
    int: IntegerConnectorType,
    float: DoubleConnectorType,
    bool: BooleanConnectorType,
    list: CSVStringConnectorType,
    datetime.datetime: DateTimeConnectorType,
    pathlib.Path: FileConnectorType,
  }
  return type_mapping[python_type]


class _ListPortType(PortType):
  def __init__(self, element_type: PortType):
    self.__element_type = element_type
    self.__data_type = DataType(
      self.__element_type.data_type().name,
      Dimensionality.LIST,
    )

  def data_type(self) -> DataType:
    return self.__data_type

  def from_workflow_native(self, json_value: JsonValues) -> list:
    if not isinstance(json_value, list):
      raise TypeError(
        default_type_error_message("workflow list", json_value, list)
      )
    return [self.__element_type.from_workflow_native(element) for element in json_value]

  def to_workflow_native(self, value: typing.Any) -> JsonValues:
    if not isinstance(value, Iterable):
      raise TypeError(
        default_type_error_message("workflow list", value, Iterable)
      )
    return [self.__element_type.to_workflow_native(element) for element in value]


class AnyConnectorTypeClass(DynamicConnectorType):
  """The class of AnyConnectorType."""
  def data_type(self) -> DataType:
    return DataType("", Dimensionality.SINGLE)

  def from_string(self, string_value: str) -> str:
    return string_value

  def to_json(self, value: str) -> str:
    return str(value)

class StringConnectorTypeClass(DynamicConnectorType, PortType):
  """The class of StringConnectorType."""
  def data_type(self) -> DataType:
    return DataType("String", Dimensionality.SINGLE)

  def from_string(self, string_value: str) -> str:
    return string_value

  def to_json(self, value: str) -> str:
    return str(value)

  def to_workflow_native(self, value: typing.Any) -> JsonValues:
    return self.to_json(value)

  def from_workflow_native(self, json_value: JsonValues) -> str:
    return str(json_value)

class IntegerConnectorTypeClass(DynamicConnectorType, PortType):
  """Class for IntegerConnectorType."""
  def data_type(self) -> DataType:
    return DataType("Integer", Dimensionality.SINGLE)

  def from_string(self, string_value: str) -> int:
    # Convert to float first to ensure that float strings are truncated
    # to integers instead of raising an error.
    return int(float(string_value))

  def to_json(self, value: int) -> int:
    return int(value)

  def to_workflow_native(self, value: typing.Any) -> JsonValues:
    return self.to_json(value)

  def from_workflow_native(self, json_value: JsonValues) -> int:
    if isinstance(json_value, (list, dict)):
      raise TypeError(default_type_error_message("int", json_value, int))
    # Convert to float first to ensure that float strings are truncated
    # to integers instead of raising an error.
    return int(float(json_value))

class DoubleConnectorTypeClass(DynamicConnectorType, PortType):
  """Class for DoubleConnectorType."""
  def data_type(self) -> DataType:
    return DataType("Double", Dimensionality.SINGLE)

  def from_string(self, string_value: str) -> float:
    return float(string_value)

  def to_json(self, value: float) -> float:
    return float(value)

  def to_workflow_native(self, value: typing.Any) -> JsonValues:
    return self.to_json(value)

  def from_workflow_native(self, json_value: JsonValues) -> float:
    if isinstance(json_value, (list, dict)):
      raise TypeError(default_type_error_message("float", json_value, float))
    return float(json_value)

class BooleanConnectorTypeClass(DynamicConnectorType, PortType):
  """Class for BooleanConnectorType."""
  def data_type(self) -> DataType:
    return DataType("Boolean", Dimensionality.SINGLE)

  def from_string(self, string_value: str) -> float:
    return bool(string_value)

  def to_json(self, value: bool) -> bool:
    return bool(value)

  def to_workflow_native(self, value: typing.Any) -> JsonValues:
    return self.to_json(value)

  def from_workflow_native(self, json_value: JsonValues) -> bool:
    return bool(json_value)

class CSVStringConnectorTypeClass(DynamicConnectorType, PortType):
  """Class for CSVStringConnectorType."""
  def data_type(self) -> DataType:
    return DataType("String", Dimensionality.LIST)

  def type_string(self) -> str:
    # Overwrite type string for backwards compatibility.
    return "List"

  def from_string(self, string_value: str) -> list:
    if not isinstance(string_value, str):
      raise TypeError(default_type_error_message("string_value",
                                                 string_value,
                                                 str))
    # Strip off the first and last character if they are brackets.
    if string_value.startswith("[") and string_value.endswith("]"):
      string_value = string_value[1:-1]
    elif string_value.startswith("(") and string_value.endswith(")"):
      string_value = string_value[1:-1]

    # Use csv reader to parse the comma separated string and take the first
    # line. This should work as long as there are no new lines in the list.
    return list(csv.reader([string_value], skipinitialspace=True))[0]

  def to_json(self, value: list) -> list:
    return list(value)

  def to_default_json(self, value):
    if not isinstance(value, Iterable):
      raise TypeError(default_type_error_message("list default",
                                                 value,
                                                 Iterable))
    return ",".join([str(x) for x in value])

  def to_workflow_native(self, value: typing.Any) -> JsonValues:
    return _StringListPortType.to_workflow_native(value)

  def from_workflow_native(self, json_value: JsonValues) -> list:
    return _StringListPortType.from_workflow_native(json_value)

class DateTimeConnectorTypeClass(DynamicConnectorType, PortType):
  """Class for DateTimeConnectorType."""
  def data_type(self) -> DataType:
    return DataType("DateTime", Dimensionality.SINGLE)

  def from_string(self, string_value: str) -> datetime.datetime:
    if not isinstance(string_value, str):
      raise TypeError(default_type_error_message("string_value",
                                                 string_value,
                                                 str))
    string_value = string_value.strip('"\'')
    return datetime.datetime.fromisoformat(string_value)

  def to_json(self, value: datetime.datetime | str) -> str:
    if isinstance(value, str):
      try:
        datetime.datetime.fromisoformat(value)
      except ValueError as error:
        message = f"Invalid datetime string: {value}. Must be ISO-8601 format."
        raise ValueError(message) from error
      return value
    try:
      return value.isoformat()
    except AttributeError as error:
      raise TypeError(default_type_error_message("value",
                                                 value,
                                                 datetime.datetime)) from error

  def to_default_json(self, value: datetime.datetime) -> str:
    raise TypeError("Default value for datetime is not supported.")

  def to_workflow_native(self, value: datetime.datetime | str) -> JsonValues:
    if isinstance(value, str):
      value = datetime.datetime.fromisoformat(value)
    try:
      # Python does not currently supported extended dates
      # (i.e. With the leading +/-)
      datetime_string = value.astimezone(datetime.timezone.utc).isoformat(
        timespec='microseconds'
      )

      # Add an extra zero to the decimals after the second component.
      # Python includes 6 decimal places with timespec=microseconds
      # C# requires exactly 7 decimal places, so add an extra one.
      datetime_string = datetime_string[:26] + "0" + datetime_string[26:]
      return f"+{datetime_string}"
    except AttributeError as error:
      raise TypeError(default_type_error_message(
        "value", value, datetime.datetime
      )) from error

  def from_workflow_native(self, json_value: JsonValues) -> datetime.datetime:
    if not isinstance(json_value, (str)):
      raise TypeError(default_type_error_message("datetime", json_value, str))
    if json_value[0] == "+":
      json_value = json_value[1:]
    return datetime.datetime.fromisoformat(json_value)

class Point3DConnectorTypeClass(DynamicConnectorType, PortType):
  """Class for Point3DConnectorType."""
  def data_type(self) -> DataType:
    return DataType("Point3D", Dimensionality.SINGLE)

  def from_string(self, string_value: str) -> np.ndarray:
    if not isinstance(string_value, str):
      raise TypeError(default_type_error_message("string_value",
                                                 string_value,
                                                 str))
    ordinates = string_value.strip("()").split(",")
    point = np.zeros((3,), float)
    point[:] = ordinates
    return point

  def to_json(self, value: np.ndarray) -> str:
    middle = ", ".join([str(float(x)) for x in value])
    return f"({middle})"

  def to_workflow_native(self, value: typing.Any) -> list[float]:
    try:
      return [
        float(value[0]),
        float(value[1]),
        float(value[2]),
      ]
    except IndexError:
      raise ValueError(
        f"Insufficient ordinates for 3D point in value: {value}"
      ) from None

  def from_workflow_native(self, json_value: JsonValues) -> np.ndarray:
    ordinates = _DoubleListPortType.from_workflow_native(json_value)
    array = np.empty((3,), dtype=np.float64)
    array[:] = ordinates
    return array


class FileSystemConnectorTypeClass(DynamicConnectorType, PortType):
  """Connector type for file and directory connector types."""
  def __init__(
    self,
    type_string: typing.Literal["File"] | typing.Literal["Folder"]
  ):
    self.__type_string = type_string

  def data_type(self) -> DataType:
    return DataType(self.__type_string, Dimensionality.SINGLE)

  def from_string(self, string_value: str) -> pathlib.Path:
    # :NOTE: Ideally, this would use pathlib.Path.resolve(), however there
    # is a bug in Python 3.7~3.9 where if a file path:
    # * Is relative.
    # * Leads to a non-existent file or directory.
    # * Doesn't contain ".."
    # Then pathlib.Path.resolve() will return the path unchanged, thus returning
    # a relative path instead of an absolute path.
    # To avoid this, this uses os.path.abspath().
    # :NOTE: This calls resolve on the path even though it is already
    # absolute to convert 8.3 file names to long file names.
    return pathlib.Path(os.path.abspath(string_value)).resolve()

  def to_json(self, value: os.PathLike | str) -> str:
    # See note in "from_string()" for why this is using os.path instead
    # of pathlib.Path.
    return os.path.abspath(value)

  def to_workflow_native(self, value: typing.Any) -> JsonValues:
    return self.to_json(value)

  def from_workflow_native(self, json_value: JsonValues) -> pathlib.Path:
    if not isinstance(json_value, (str)):
      raise TypeError(
        default_type_error_message("pathlib.Path", json_value, str)
      )
    # :NOTE: Ideally, this would use pathlib.Path.resolve(), however there
    # is a bug in Python 3.7~3.9 where if a file path:
    # * Is relative.
    # * Leads to a non-existent file or directory.
    # * Doesn't contain ".."
    # Then pathlib.Path.resolve() will return the path unchanged, thus returning
    # a relative path instead of an absolute path.
    # To avoid this, this uses os.path.abspath().
    return pathlib.Path(os.path.abspath(json_value)).resolve()


AnyConnectorType = AnyConnectorTypeClass()
"""Connector type representing no connector type set.

This corresponds to the connector type being blank on the workflows
side. Input connectors of this type will accept any value from other
connectors and the string representation of that value will be returned.
Output connectors of this type will accept any value which can be converted
into a string.
"""


StringConnectorType = StringConnectorTypeClass()
"""Connector type corresponding to String on the workflows side.

This can be passed to declare_input_connector or declare_output_connector
to declare the connector type as String. Passing the python type str
is equivalent to passing this class.

Examples
--------
This example sets the output connector "reversed" to contain a reversed
version of the string from the input connector "string"

>>> from mapteksdk.workflows import (WorkflowArgumentParser,
...                                  StringConnectorType)
>>> parser = WorkflowArgumentParser()
>>> parser.declare_input_connector("string", StringConnectorType)
>>> parser.declare_output_connector("reversed", StringConnectorType)
>>> parser.parse_arguments()
>>> parser.set_output("reversed", parser["string"][::-1])
"""

IntegerConnectorType = IntegerConnectorTypeClass()
"""Connector type corresponding to Integer on the workflows side.

Passing the connector type as int is equivalent to passing this to
declare_input/output_connector.

Examples
--------
This example creates a workflow component with an Integer
input and output connector. The output connector "new_count" is set to the
value of the input connector "count" plus one.

>>> from mapteksdk.workflows import (WorkflowArgumentParser,
...                                  IntegerConnectorType)
>>> parser = WorkflowArgumentParser()
>>> parser.declare_input_connector("count", IntegerConnectorType)
>>> parser.declare_output_connector("new_count", IntegerConnectorType)
>>> parser.parse_arguments()
>>> parser.set_output("new_count", parser["count"] += 1)
"""

DoubleConnectorType = DoubleConnectorTypeClass()
"""Connector type corresponding to Double on the workflows side.

Passing the connector type as float is equivalent to passing this to
declare_input/output_connector.

Examples
--------
This example sets the value of the output connector "x_over_2" to the value
of the input connector "x" divided by two.

>>> from mapteksdk.workflows import (WorkflowArgumentParser,
...                                  DoubleConnectorType)
>>> parser = WorkflowArgumentParser()
>>> parser.declare_input_connector("x", DoubleConnectorType)
>>> parser.declare_output_connector("x_over_2", DoubleConnectorType)
>>> parser.parse_arguments()
>>> parser.set_output("x_over_2", parser["x"] / 2)
"""

BooleanConnectorType = BooleanConnectorTypeClass()
"""Connector type corresponding to Boolean on the workflows side.

Passing the connector type as bool is equivalent to passing this to
declare_input/output_connector.

Examples
--------
This example sets the output connector "not x" to be the inverse of the
value passed to the "x" input connector.

>>> from mapteksdk.workflows import (WorkflowArgumentParser,
...                                  IntegerConnectorType)
>>> parser = WorkflowArgumentParser()
>>> parser.declare_input_connector("x", BooleanConnectorType)
>>> parser.declare_output_connector("not x", BooleanConnectorType)
>>> parser.parse_arguments()
>>> parser.set_output("not x", not parser["x"])
"""

CSVStringConnectorType = CSVStringConnectorTypeClass()
"""Connector type corresponding to CSV String on the workflows side.

Passing the connector type as list is
equivalent to passing this to declare_input/output_connector.

Examples
--------
This example filters out every second element in the list from the
input connector "values" and sets the filtered list to the output connector
"second_values".

>>> from mapteksdk.workflows import (WorkflowArgumentParser,
...                                  CSVStringConnectorType)
>>> parser = WorkflowArgumentParser()
>>> parser.declare_input_connector("values", CSVStringConnectorType)
>>> parser.declare_output_connector("second_values", CSVStringConnectorType)
>>> parser.parse_arguments()
>>> parser.set_output("second_values", parser["values"][::2])
"""

DateTimeConnectorType = DateTimeConnectorTypeClass()
"""Connector type corresponding to DateTime on the Workflows side.

Passing the connector type as datetime.datetime is equivalent to passing this to
declare_input/output_connector.

This does not currently support defaults.

Examples
--------
This example adds 24 hours to the time from the input connector "today" and
sets that time to the output connector "tomorrow".
Note that this may not give the same time on the next day due to
daylight savings start/ending.

>>> import datetime
>>> from mapteksdk.workflows import (WorkflowArgumentParser,
...                                  DateTimeConnectorType)
>>> parser = WorkflowArgumentParser()
>>> parser.declare_input_connector("today", DateTimeConnectorType)
>>> parser.declare_output_connector("tomorrow", DateTimeConnectorType)
>>> parser.parse_arguments()
>>> tomorrow = parser["today"] + datetime.timedelta(days=1)
>>> parser.set_output("tomorrow", tomorrow)
"""

Point3DConnectorType = Point3DConnectorTypeClass()
"""Connector type representing a 3D point in workflows.

An input connector of this type will return a numpy array of floats with
shape (3, ) representing the point in the form [X, Y, Z].

Default values can be specified using any iterable as long as its length
is three and all values can be converted to floats, though list or numpy
arrays are generally preferable.

Given a script called "script.py" with an input connector of type
Point3DConnectorType called "point", to pass the point [1.2, 3.4, -1.3]
via the command line you would type:

>>> py script.py --point=(1.2,3.4,-1.3)

Examples
--------
This example sets the output connector "inverted_point" to the inverse of the
point from the input connector "point".

>>> from mapteksdk.workflows import (WorkflowArgumentParser,
...                                  Point3DConnectorType)
>>> parser = WorkflowArgumentParser()
>>> parser.declare_input_connector("point", Point3DConnectorType)
>>> parser.declare_output_connector("inverted_point", Point3DConnectorType)
>>> parser.parse_arguments()
>>> parser.set_output("inverted_point", -parser["point"])
"""

FileConnectorType = FileSystemConnectorTypeClass("File")
"""Connector type representing a File.

If used as an input, the file path will be returned as a pathlib.Path
object.

If used as an output, the file path can be provided as any path-like
object.

Warnings
--------
This class does not validate the file paths received from a Workflow, nor does
it validate file paths provided to output connectors. This means:

* The file path given by an input connector may not point to an existing file.
* The file path given by an input connector may be the path to a directory
  instead of a file.
* An output connector will not raise an error if given the path to a file
  which does not exist.
* An output connector will not raise an error if given the path to a
  directory.

Notes
-----
When declaring connectors, pathlib.Path can be used instead of this class.

Examples
--------
The following example demonstrates a script which accepts a file path from
a workflow and then reads the CSV file at that file path using pandas.

>>> import pandas
>>> import pathlib
>>> from mapteksdk.workflows import WorkflowArgumentParser, FileConnectorType
>>> if __name__ == "__main__":
...   parser = WorkflowArgumentParser(
...     description="Example of reading a CSV file.")
...   parser.declare_input_connector(
...     "csv_file",
...     FileConnectorType,
...     description="Path to the CSV file to read."
...   )
...   parser.parse_arguments()
...   csv_file_path: pathlib.Path = parser["csv_file"]
...   if not csv_file_path.exists():
...     raise FileNotFoundError(
...       f"The CSV file does not exist: '{csv_file_path}'"
...     )
...   if csv_file_path.is_dir():
...     raise ValueError(
...       f"The CSV file cannot be a directory."
...     )
...   csv_data = pandas.read_csv(csv_file_path)
...   # Now do something with the CSV.
"""


DirectoryConnectorType = FileSystemConnectorTypeClass("Folder")
"""Connector type representing a directory.

If used as an input, the path to the directory is returned as a pathlib.Path
object.

If used as an output, the directory path can be provided as any path-like
object.

Warnings
--------
This class does not validate the directory paths received from a Workflow,
nor does it validate directory paths provided to output connectors. This
means:

* The directory path given by an input connector may not point to an existing
  directory.
* The directory path given by an input connector may be the path to a file
  instead of a directory.
* An output connector will not raise an error if given the path to a directory
  which does not exist.
* An output connector will not raise an error if given the path to a
  file.

Examples
--------
The following example demonstrates a workflow which accepts a directory input
and produces an output list which contains every file within that directory.

>>> import pathlib
>>> from mapteksdk.workflows import (
...   WorkflowArgumentParser, DirectoryConnectorType)
>>> if __name__ == "__main__":
...   parser = WorkflowArgumentParser(
...     description="This script accepts a directory input from workflows. "
...       "It outputs a list containing all of the files within that "
...       "directory. This script will fail if the file input does not exist "
...       "or the user does not have permissions to access that directory."
...   )
...   parser.declare_input_connector(
...     "directory",
...     DirectoryConnectorType,
...     description="Path to the directory to list the files it contains."
...   )
...   parser.declare_output_connector(
...     "files_in_directory",
...     list,
...     description="Path to the files contained in the input directory."
...   )
...   parser.parse_arguments()
...   directory: pathlib.Path = parser["directory"]
...   # :NOTE: is_dir() will return false if the directory does not exist.
...   # Thus check if the path exists before checking if it is a directory.
...   if not directory.exists():
...     raise FileNotFoundError(
...       f"The input directory did not exist: '{directory}'"
...     )
...   if not directory.is_dir():
...     raise ValueError(
...       f"The input directory path pointed to a file: {directory}"
...     )
...   files_in_directory = [str(path) for path in directory.iterdir()]
...   parser.set_output("files_in_directory", files_in_directory)
"""

_StringListPortType = _ListPortType(StringConnectorType)

_DoubleListPortType = _ListPortType(DoubleConnectorType)


_DATA_TYPE_TO_PORT_TYPE = {
  "String" : StringConnectorType,
  "Integer" : IntegerConnectorType,
  "Double" : DoubleConnectorType,
  "Boolean" : BooleanConnectorType,
  "DateTime" : DateTimeConnectorType,
  "Point3D" : Point3DConnectorType,
  "File" : FileConnectorType,
  "Folder" : DirectoryConnectorType
}


def data_type_to_port_type(data_type: DataType) -> PortType:
  """Get the port type which can handle the `data_type`."""
  try:
    base_type = _DATA_TYPE_TO_PORT_TYPE[data_type.base_type().name]
    if data_type.dimensionality is Dimensionality.SINGLE:
      return base_type
    if data_type.dimensionality is Dimensionality.LIST:
      return _ListPortType(base_type)
  except KeyError:
    pass
  raise UnsupportedInputTypeError(data_type.name) from None
