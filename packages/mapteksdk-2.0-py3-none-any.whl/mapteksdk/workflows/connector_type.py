"""The ConnectorType interface.

Classes which implement this interface can be passed to WorkflowArgumentParser
as connector types.

"""
###############################################################################
#
# (C) Copyright 2021, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import enum
import typing

if typing.TYPE_CHECKING:
  from .internal import JsonValues


class Dimensionality(enum.Enum):
  """Represents the dimensionality of an input."""
  SINGLE = 0
  """This connector type accepts a single value."""
  LIST = 1
  """This connector accepts a list of uniformly typed values."""


class DataType:
  """A data type supported by workflows."""
  def __init__(self, name: str, dimensionality: Dimensionality):
    self.__name = name
    self.__dimensionality = dimensionality

  @property
  def name(self) -> str:
    """The name of this data type."""
    return self.__name

  @property
  def dimensionality(self) -> Dimensionality:
    """The dimensionality of this data type."""
    return self.__dimensionality

  def base_type(self) -> DataType:
    """The base type of this data type.

    This will be this data type.
    """
    return DataType(self.__name.split(".")[0], self.__dimensionality)

  def is_subtype_of(self, data_type: DataType):
    """True if this DataType is a subtype of `data_type`."""
    return self.name.startswith(data_type.name)


@typing.runtime_checkable
class PortType(typing.Protocol):
  """Interface for classes representing port types.

  Classes which implement this protocol can be used as data types for
  WorkflowArgumentParser.declare_input_connector() and
  WorkflowArgumentParser.declare_output_connector() when running in
  WorkflowMAE.
  """
  def data_type(self) -> DataType:
    """The type of data supported by this port."""
    raise NotImplementedError

  def type_string(self) -> str:
    """The data type when generating ports."""
    return self.data_type().name

  def from_workflow_native(self, json_value: JsonValues) -> typing.Any:
    """Convert from the Workflow native representation to the Python one.

    Raises
    ------
    TypeError
      If json_value is not a supported type.
    ValueError
      If json_value is the correct type but an invalid value.
    """
    raise NotImplementedError

  def to_workflow_native(self, value: typing.Any) -> JsonValues:
    """Convert `value` to the Workflow native format."""
    raise NotImplementedError

@typing.runtime_checkable
class DynamicConnectorType(typing.Protocol):
  """Interface for classes representing connector types.

  Classes which implement this protocol can be used as data types for
  WorkflowArgumentParser.declare_input_connector() and
  WorkflowArgumentParser.declare_output_connector() when running in
  Workflows.

  Remarks
  -------
  This differs from `ConnectorType` by being a non-static class, allowing for
  a class to implement both `PortType` and `DynamicConnectorType` so that it
  supports both Workflows and WorkflowMAE.
  """
  def data_type(self) -> DataType:
    """The type of data supported by this port."""
    raise NotImplementedError

  def type_string(self) -> str:
    """The data type when generating ports."""
    return self.data_type().name

  def from_string(self, string_value: str) -> typing.Any:
    """Convert a string value to the corresponding python type.

    Raises
    ------
    TypeError
      If string_value is not a supported type.
    ValueError
      If string_value is the correct type but an invalid value.
    """
    raise NotImplementedError

  def to_json(self, value: typing.Any) -> typing.Any:
    """Converts the value to a json-serializable value.

    This is used to convert python values to json values to be passed
    to the workflow for output connectors.

    Returns
    -------
    json-serializable
      Json serializable representation of value.

    Raises
    ------
    TypeError
      If value is not a supported type.
    ValueError
      If value is the correct type but an invalid value.

    """
    raise NotImplementedError

  def to_default_json(self, value: typing.Any) -> str | None:
    """Converts the value to a json serializable default.

    This allows for specifying a different representation for default
    values. The output of this function should not include lists.

    Overwrite this function to raise an error to indicate that default
    values are not supported.

    By default this calls to_json.

    Returns
    -------
    str
      String representation of value.
      None if there is no default value.

    Raises
    ------
    TypeError
      If value is not a supported type.
    ValueError
      If value is the correct type but an invalid value.

    """
    return self.to_json(value)

class ConnectorType:
  """Interface for classes representing connector types.

  Classes which implement this interface can be passed as types for
  WorkflowArgumentParser.declare_input_connector() and
  WorkflowArgumentParser.declare_output_connector().

  """
  @classmethod
  def data_type(cls) -> DataType:
    """The type of data supported by this port."""
    dimensionality_string = cls.json_dimensionality()
    if dimensionality_string == "Single":
      dimensionality = Dimensionality.SINGLE
    elif dimensionality_string == "List":
      dimensionality = Dimensionality.LIST
    else:
      raise RuntimeError(
        f"Unsupported dimensionality: {dimensionality_string}"
      )
    return DataType(
      cls.type_string(),
      dimensionality
    )

  @classmethod
  def type_string(cls) -> str:
    """The data type when generating ports.

    Returns
    -------
    str
      String representation of the type to report to the workflow.

    """
    raise NotImplementedError

  @classmethod
  def json_type_string(cls) -> str:
    """The type string expected to be in JSON inputs.

    This is the same as the type string by default, but for certain cases
    this differs.
    """
    return cls.type_string()

  @classmethod
  def json_dimensionality(cls) -> str:
    """The dimensionality of the input in JSON.

    This must either be 'Single' or 'List'. It is 'Single' by default.
    """
    return "Single"

  @classmethod
  def from_string(cls, string_value: str) -> typing.Any:
    """Convert a string value from an input connector to the corresponding
    python type and returns it.

    Returns
    -------
    any
      The python representation of the string value.

    Raises
    ------
    TypeError
      If string_value is not a supported type.
    ValueError
      If string_value is the correct type but an invalid value.

    """
    raise NotImplementedError

  @classmethod
  def to_json(cls, value: typing.Any) -> typing.Any:
    """Converts the value to a json-serializable value.

    This is used to convert python values to json values to be passed
    to the workflow for output connectors.

    Returns
    -------
    json-serializable
      Json serializable representation of value.

    Raises
    ------
    TypeError
      If value is not a supported type.
    ValueError
      If value is the correct type but an invalid value.

    """
    raise NotImplementedError

  @classmethod
  def to_default_json(cls, value: typing.Any) -> str | None:
    """Converts the value to a json serializable default.

    This allows for specifying a different representation for default
    values. The output of this function should not include lists.

    Overwrite this function to raise an error to indicate that default
    values are not supported.

    By default this calls to_json.

    Returns
    -------
    str
      String representation of value.
      None if there is no default value.

    Raises
    ------
    TypeError
      If value is not a supported type.
    ValueError
      If value is the correct type but an invalid value.

    """
    return cls.to_json(value)

  @classmethod
  def to_workflow_native(cls, value: typing.Any) -> JsonValues:
    """Convert value to JSON using the modern format."""
    return cls.to_json(value)
