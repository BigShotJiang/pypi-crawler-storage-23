"""Legacy output for Workflows."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import io
import json
import typing


if typing.TYPE_CHECKING:
  from .output_dictionary import LegacyOutputDictionary

class LegacyOutputHandler:
  """Legacy output for Workflows V1."""
  def write_output(
    self,
    outputs: LegacyOutputDictionary,
    stream: io.TextIOBase,
    pretty: bool = False,
  ):
    """Write `outputs` to `stream`."""
    separators = None if pretty else (",", ":")
    indent = 2 if pretty else None
    actual_outputs = {
      key : variant.json_value for key, variant in outputs.to_dict().items()
    }
    json.dump(actual_outputs, stream, separators=separators, indent=indent)
