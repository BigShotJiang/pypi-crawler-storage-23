"""Tuple representing which formats are supported.

Warnings
--------
Vendors and clients should not develop scripts or applications against
this package. The contents may change at any time without warning.
"""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations
import typing

class JsonSupportTuple(typing.NamedTuple):
  """Named tuple representing JSON version support."""
  minimum: int
  """The minimum supported version.

  0 indicates no JSON versions are supported.
  """
  maximum: int

  """The maximum supported version.

  0 indicates no JSON versions are supported.
  """
