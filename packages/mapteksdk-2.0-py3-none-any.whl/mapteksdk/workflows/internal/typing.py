"""Static type checking constructs for internal workflows.

Until this package drops support for Python 3.9, this can only be imported in
an `if typing.TYPE_CHECKING` block.
"""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################

import typing

if typing.TYPE_CHECKING:
  from collections.abc import Sequence

  from ..connector_types import ConnectorType, DynamicConnectorType, PortType

  class Key(typing.TypedDict):
    """Dictionary representing the key for a JSON input."""
    Value: str

  class Value(typing.TypedDict):
    """Dictionary representing the value for a JSON input."""
    Dimensionality: int
    Nullability: bool
    Type: str
    Value: typing.Any

  class JsonVariant(typing.TypedDict):
    """Dictionary representing a single JSON input or output."""
    Key: Key
    Value: Value

  JsonVariants: typing.TypeAlias = Sequence[JsonVariant]
  """Represents a group of JSON inputs or outputs."""

  JsonValues: typing.TypeAlias = str | int | float | bool | list | dict

  DataTypeDictionary: typing.TypeAlias = dict[
    str, type[ConnectorType] | DynamicConnectorType | PortType
  ]
  """A dictionary which maps names to connector types."""
