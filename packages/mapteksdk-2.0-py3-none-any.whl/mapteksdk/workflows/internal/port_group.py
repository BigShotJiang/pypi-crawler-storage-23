"""Class for managing groups of ports."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

from collections.abc import Iterable
import typing

from ...internal.util import default_type_error_message
from .data_port import DataPort, SupportedIoFormats

if typing.TYPE_CHECKING:
  from .typing import DataTypeDictionary

class DataPortGroup:
  """Represents a group of ports for a Workflow Node.

  This makes no distinction between Data In Ports and Data Out Ports.
  """
  def __init__(self):
    self._ports: dict[str, DataPort] = {}
    self.__supported_io_formats: SupportedIoFormats = (
      SupportedIoFormats.LEGACY
      | SupportedIoFormats.WORKFLOW_NATIVE
    )

  def __len__(self) -> int:
    return len(self._ports)

  def __getitem__(self, port_name: str) -> DataPort:
    return self._ports[port_name]

  def __contains__(self, item: object) -> bool:
    if isinstance(item, str):
      return item in self._ports
    if isinstance(item, DataPort):
      return item.name in self._ports
    return False

  def __repr__(self) -> str:
    return f"DataPortGroup({self._ports})"

  def add_port(self, port: DataPort):
    """Add a new port to the group.

    Parameters
    ----------
    port
      The port to add to the group.

    Raises
    ------
    ValueError
      If this group already contains a port with the name of the given port.
    """
    try:
      name = port.name
    except AttributeError:
      raise TypeError(
        default_type_error_message("port", port, DataPort)
      ) from None
    if name in self._ports:
      raise ValueError(
        f"This port group already contains a port with name: {name}"
      )
    self.__supported_io_formats &= port.supported_io_formats
    self._ports[port.name] = port

  def values(self) -> Iterable[DataPort]:
    """Get an iterable over the ports in the group."""
    return self._ports.values()

  def to_type_dictionary(self) -> DataTypeDictionary:
    """Convert the port group into a dictionary of ports to data types."""
    return {
      port.name : port.arg_type for port in self.values()
    }

  @property
  def supported_io_formats(self) -> SupportedIoFormats:
    """The supported IO formats for this port group.

    This will only include formats which are supported by all ports
    in the group.
    """
    return self.__supported_io_formats
