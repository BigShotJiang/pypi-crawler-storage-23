"""Handling for JSON inputs for workflows."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import json
import typing

from ..connector_type import DataType, Dimensionality
from ..connector_types import data_type_to_port_type
from ..errors import (
  InputDimensionMismatchError,
  MalformedInputError,
  InputTypeError,
)
from .input_handler import InputHandler

if typing.TYPE_CHECKING:
  import os

  from .typing import JsonVariants, DataTypeDictionary


class JsonInputHandler(InputHandler):
  """Handler for JSON inputs."""
  def __init__(self, json_inputs: JsonVariants, input_types: DataTypeDictionary):
    try:
      self.__inputs: dict[str, typing.Any] = self._parse_inputs(
        json_inputs,
        input_types,
      )
    except TypeError as error:
      raise MalformedInputError(
        "The inputs provided by the workflow were malformed. "
        "This could indicate that the mapteksdk package is incompatible "
        "with the installed version of workbench."
      ) from error
    except KeyError as error:
      raise MalformedInputError(
        "The inputs provided by the workflow were malformed. "
        "One or more required values were missing."
      ) from error

  @classmethod
  def from_file(
    cls,
    json_path: os.PathLike,
    input_types: DataTypeDictionary
  ) -> typing.Self:
    """Construct the input handler from a JSON file."""
    with open(json_path, "r", encoding="utf-8") as json_file:
      json_data = json.load(json_file)
    return cls(json_data, input_types)

  def _parse_inputs(
    self,
    json_inputs: JsonVariants,
    input_types: DataTypeDictionary
  ) -> dict[str, typing.Any]:
    input_dictionary = {}
    for json_input in json_inputs:
      key = json_input["Key"]["Value"]
      value = json_input["Value"]
      _ = value["Nullability"]
      actual_type = DataType(
        value["Type"],
        Dimensionality(value["Dimensionality"])
      )

      try:
        converter = input_types[key]

        expected_type = converter.data_type()
        if not actual_type.is_subtype_of(expected_type):
          raise InputTypeError(key, expected_type.name, actual_type.name)

        if actual_type.dimensionality != expected_type.dimensionality:
          raise InputDimensionMismatchError(
            key,
            expected_type.dimensionality.value,
            actual_type.dimensionality.value
          )
      except KeyError:
        converter = data_type_to_port_type(actual_type)

      input_dictionary[key] = converter.from_workflow_native(value["Value"])
    return input_dictionary

  def read_inputs(self) -> dict[str, typing.Any]:
    return self.__inputs

  def read_unknown_inputs(self) -> dict[str, typing.Any]:
    return {}

  def help(self) -> str:
    return "Command line inputs are not supported."
