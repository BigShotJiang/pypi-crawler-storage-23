"""Class for holding metadata about a data port."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import typing

from .constants import (
  is_reserved_argument,
)
from .io_formats import SupportedIoFormats
from ..connector_types import (
  AnyConnectorTypeClass,
  DynamicConnectorType,
  PortType,
  python_type_to_connector_type,
)
from ..errors import InvalidConnectorNameError
from ..matching import MatchAttribute
from ...internal.util import default_type_error_message

if typing.TYPE_CHECKING:
  from ..connector_types import PythonPortTypes, AnyPortType

class DataPort:
  """Class designed to hold metadata for input and output ports.

  This is primarily used for serializing the input/output port
  information to JSON to be used by the Extend Python workflow component to
  generate input and output ports.

  Parameters
  ----------
  name
    The attribute to associate with the port. This cannot contain
    spaces.
  arg_type
    The Python type of values accepted by the port.
  default
    The default value for this port. The default is None.
  port_name
    A human-readable name for the port. Unlike name this may contain
    spaces. If None (default) name will be used as the port name.
  description
    The description of the port. If None (default) the description
    will be empty.
  matching
    How the attribute will be matched on the workflows side.

  Raises
  ------
  InvalidConnectorNameError
    If the name is reserved or not a valid Python identifier.

  """
  def __init__(
      self,
      name: str,
      arg_type: AnyPortType | type[PythonPortTypes] | None,
      default: typing.Any=None,
      port_name: str | None=None,
      description: str | None=None,
      matching: MatchAttribute | None=None):
    self._raise_if_connector_name_invalid(name)
    if matching is not None and not isinstance(matching, MatchAttribute):
      raise TypeError(default_type_error_message(
        "matching", matching, MatchAttribute))
    self.__name = name
    self.__arg_type = python_type_to_connector_type(arg_type)
    self.__supported_io_formats = SupportedIoFormats.NONE

    if isinstance(self.__arg_type, DynamicConnectorType):
      self.__supported_io_formats |= SupportedIoFormats.LEGACY
    if isinstance(self.__arg_type, PortType):
      self.__supported_io_formats |= SupportedIoFormats.WORKFLOW_NATIVE
    self.__port_name = port_name
    self.__default = default
    if default is not None:
      try:
        self.__default_json = self.__arg_type.to_default_json( # type: ignore
          default
        )
      except AttributeError:
        # :TODO: SDK-988 Support defaults in WorkflowMAE.
        raise NotImplementedError(
          "Defaults not supported in WorkflowMAE."
        ) from None
    else:
      self.__default_json = None
    if description is None:
      self.__description = ""
    else:
      self.__description = description
    if (
      matching is MatchAttribute.BY_TYPE
      and isinstance(self.__arg_type, AnyConnectorTypeClass)
    ):
      raise ValueError("AnyConnectorType does not support match by type")
    self.__matching = matching

  @classmethod
  def _raise_if_connector_name_invalid(cls, name: str):
    """Raises an InvalidConnectorName error if the name is invalid."""
    if is_reserved_argument(name):
      raise InvalidConnectorNameError(
        f"Cannot declare connector with name : {name}. The name is reserved.")
    if not name.replace("-", "_").isidentifier():
      raise InvalidConnectorNameError(f"Invalid name : {name}. "
                                      "Name is not a valid identifier")

  def to_dict(self) -> dict[str, typing.Any]:
    """Converts this object to a dictionary ready for serialization
    to JSON.

    Returns
    -------
    dict
      Dictionary representing this object ready for serialization to JSON.

    """
    # New values should not be included in the dictionary by default. This
    # ensures pre-existing tests do not need to be modified.
    result: dict[str, typing.Any] = {"Name" : self.__name}
    arg_type = self.__arg_type
    if not isinstance(arg_type, AnyConnectorTypeClass):
      result["Type"] = arg_type.type_string()
      result["Dimensionality"] = arg_type.data_type().dimensionality.value
    if self.__default_json is not None:
      result["Default"] = self.__default_json
    if self.__description:
      result["Description"] = self.__description
    if self.__port_name:
      result["ConnectorName"] = self.__port_name
    if self.__matching:
      result["Matching"] = self.__matching.value
    return result

  @property
  def name(self) -> str:
    """The name of this port."""
    return self.__name

  @property
  def arg_type(self) -> AnyPortType:
    """The type of argument accepted by this port."""
    return self.__arg_type

  @property
  def description(self) -> str | None:
    """User-facing description for this port."""
    return self.__description

  @property
  def default(self) -> typing.Any:
    """Default value for this port."""
    return self.__default

  def __repr__(self) -> str:
    return f"DataPort({self.to_dict()})"

  @property
  def supported_io_formats(self) -> SupportedIoFormats:
    """The supported IO formats for this port."""
    return self.__supported_io_formats
