"""Constants for use in workflows."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################

DESCRIBE_ARGUMENT: str = "describe"
INPUT_ARGUMENT: str = "workflow-input-path"
OUTPUT_ARGUMENT: str = "workflow-output-path"
ITEMS_ARGUMENT: str = "workflow-attribute-items"
MINIMUM_SUPPORTED_JSON_VERSION: int = 2
MAXIMUM_SUPPORTED_JSON_VERSION: int = 2

def is_reserved_argument(string: str) -> bool:
  """True if `string` is one of the constants in this file."""
  return string in (
    DESCRIBE_ARGUMENT,
    INPUT_ARGUMENT,
    OUTPUT_ARGUMENT,
    ITEMS_ARGUMENT
  )
