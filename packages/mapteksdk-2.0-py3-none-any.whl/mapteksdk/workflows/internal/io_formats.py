"""Enum representing I/O formats for workflows.

Warnings
--------
Vendors and clients should not develop scripts or applications against
this package. The contents may change at any time without warning.
"""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################

import enum


class SupportedIoFormats(enum.Flag):
  """Enum of supported IO formats.

  This is a flag enum so members can be combined using the | operator
  to indicate multiple formats are supported.

  Warnings
  --------
  The integer values of this enum should not be considered stable and can
  change without warning.
  """
  NONE = 0
  """No formats are supported."""
  LEGACY = enum.auto()
  """The legacy format used by the original Workflows system.

  This involves passing inputs as command line arguments and writing the
  outputs as a JSON file. This cannot support the full WorkflowMAE type
  system due to the difficulties of converting all the inputs to string
  and handling the complexities of parsing command line arguments.
  """
  LEGACY_JSON = enum.auto()
  """An old experimental JSON format which is no longer supported.

  This was in several released versions of the SDK. This was designed
  as a replacement for the legacy format which could support the full
  WorkflowMAE type system. However, it was never used in the Workbench
  and was removed when implementing support for the Workflow-native
  format.
  """
  WORKFLOW_NATIVE = enum.auto()
  """Native format used by WorkflowMAE to transfer data."""
