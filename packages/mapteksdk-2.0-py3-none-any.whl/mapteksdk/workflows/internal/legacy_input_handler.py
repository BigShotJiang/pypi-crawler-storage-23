"""Handling for legacy command line I/O for vanilla workflows."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import argparse
import typing

from ..connector_types import BooleanConnectorType, CSVStringConnectorType
from .constants import ITEMS_ARGUMENT
from .input_handler import InputHandler

if typing.TYPE_CHECKING:
  from .port_group import DataPortGroup, DataPort

  KnownInputs: typing.TypeAlias = dict[str, typing.Any]
  UnknownInputs: typing.TypeAlias = dict[str, str]

class LegacyInputHandler(InputHandler):
  """Class which handles legacy command line I/O for workflows.

  Parameters
  ----------
  input_ports
    The input ports which define the command line arguments.
  description
    Optional user-facing description to use for this script.
  allow_unknown_arguments
    If False (default), a SystemExit error will be raised if any inputs which
    do not correspond to a port in `input_ports` is encountered.
    If True, any input not in `input_ports` will be included in the output
    of `read_inputs` as a string.
  """
  def __init__(
    self,
    arguments: list[str],
    input_ports: DataPortGroup,
    description: str = "",
    allow_unknown_arguments: bool = False,
  ):
    self.__parser = self._create_argument_parser(input_ports, description)
    self.__arguments = arguments
    self.__allow_unknown_arguments = allow_unknown_arguments
    self.__inputs: KnownInputs | None = None
    """Cached parsed inputs.

    Always access this through `_parse_inputs()`.
    """
    self.__unknown_inputs: UnknownInputs | None = None
    """Cached parsed unknown inputs.

    Always access this through `_parse_inputs()`.
    """

  def _create_argument_parser(
    self,
    input_ports: DataPortGroup,
    description: str
  ) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
      description=description,
      # These are handled by WorkflowArgumentParser, so are not needed here.
      add_help=False,
      usage="from command line (legacy)"
    )
    for port in input_ports.values():
      self._add_port_argument_parser(parser, port)

    parser.add_argument(
      f"--{ITEMS_ARGUMENT}",
      type=CSVStringConnectorType.from_string,
      default=None,
    )
    return parser

  def _add_port_argument_parser(
    self,
    parser: argparse.ArgumentParser,
    port: DataPort
  ):
    name = port.name
    if len(name) == 1:
      key = f"-{name}"
    else:
      key = f"--{name}"

    if port.arg_type == BooleanConnectorType:
      # Special handling for bool arguments. Default value is always
      # False.
      parser.add_argument(
        key,
        action='store_true',
        default=False,
        help=port.description
      )
    else:
      parser.add_argument(
        key,
        type=port.arg_type.from_string,
        default=port.default,
        help=port.description
      )

  def _parse_known_inputs(
    self,
    namespace: argparse.Namespace
  ) -> KnownInputs:
    return dict(vars(namespace))

  def _parse_unknown_inputs(self, unknown_inputs: list[str]) -> UnknownInputs:
    result: UnknownInputs = {}
    for unknown_input in unknown_inputs:
      if "=" in unknown_input:
        # The unknown arg is of the form:
        # --name=value
        # or
        # -n=value
        key, value = unknown_input.split("=", maxsplit=1)
      else:
        # The unknown arg is of the form:
        # -k
        # or
        # --key
        key = unknown_input
        value = str(True)
      key = key.strip("-")
      result[key] = value
    return result

  def _parse_inputs(self) -> tuple[KnownInputs, UnknownInputs]:
    """Parse the inputs and cache the result.

    If the inputs have already been parsed, this will return the cached value.

    Returns
    -------
    tuple[dict[str, typing.Any], dict[str, str]]
      A tuple containing:
      * 0 = The known inputs dictionary.
      * 1 = The unknown inputs dictionary.
    """
    cached_inputs = self.__inputs
    cached_unknown = self.__unknown_inputs
    if cached_inputs is not None and cached_unknown is not None:
      return cached_inputs, cached_unknown

    if self.__allow_unknown_arguments:
      known_args, unknown_args = self.__parser.parse_known_args(
        self.__arguments
      )
    else:
      known_args = self.__parser.parse_args(self.__arguments)
      unknown_args = []

    known_inputs = self._parse_known_inputs(known_args)
    unknown_inputs = self._parse_unknown_inputs(unknown_args)
    self.__inputs = known_inputs
    self.__unknown_inputs = unknown_inputs
    return known_inputs, unknown_inputs

  def read_inputs(self) -> KnownInputs:
    return self._parse_inputs()[0]

  def read_unknown_inputs(self) -> UnknownInputs:
    return self._parse_inputs()[1]

  def help(self) -> str:
    return self.__parser.format_help()
