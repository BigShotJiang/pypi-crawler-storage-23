"""Protocol for classes which parse workflow inputs."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################

import typing

class InputHandler(typing.Protocol):
  """Defines a class which can read the inputs from a workflow."""
  def read_inputs(self) -> dict[str, typing.Any]:
    """Read the inputs and return a dictionary containing them.

    Calling this more than once should return the same dictionary each time.
    """
    ... # pylint: disable=unnecessary-ellipsis

  def read_unknown_inputs(self) -> dict[str, typing.Any]:
    """Read any unknown inputs.

    These are any inputs which were provided but were not expected.
    """
    ... # pylint: disable=unnecessary-ellipsis

  def help(self) -> str:
    """Return a user-facing help string."""
    ... # pylint: disable=unnecessary-ellipsis
