"""Handling for new JSON outputs for workflows."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import io
import json
import typing

if typing.TYPE_CHECKING:
  from .output_dictionary import ModernOutputDictionary
  from .typing import JsonVariants, JsonVariant, Key, Value

class JsonOutputHandler:
  """JSON output format for WorkflowMAE."""
  def write_output(
    self,
    outputs: ModernOutputDictionary,
    stream: io.TextIOBase,
    pretty: bool = False,
  ):
    """Write `outputs` to `stream`."""
    variants: JsonVariants = []

    for name, variant in outputs.to_dict().items():
      key: Key = {"Value" : name}
      data_type = variant.data_type.data_type()
      value: Value = {
        "Dimensionality" : data_type.dimensionality.value,
        "Nullability" : False,
        "Type" : data_type.name,
        "Value" : variant.json_value
      }
      json_variant: JsonVariant = {"Key" : key, "Value": value}
      variants.append(json_variant)

    separators = None if pretty else (",", ":")
    indent = 2 if pretty else None
    json.dump(variants, stream, separators=separators, indent=indent)
