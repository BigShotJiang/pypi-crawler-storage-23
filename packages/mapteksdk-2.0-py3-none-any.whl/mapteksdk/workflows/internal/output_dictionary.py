"""Storage for outputs for Workflows."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import typing

from ..connector_types import (
  ConnectorType,
  DynamicConnectorType,
  PortType,
  python_type_to_dynamic_connector_type,
  python_type_to_port_type
)
from ..errors import OutputDataTypeNotSupportedError

if typing.TYPE_CHECKING:
  from ..connector_types import (
    AnyPortType,

  )
  from .typing import JsonValues

  T = typing.TypeVar("T", bound=AnyPortType)
else:
  T = typing.TypeVar("T")

class Variant:
  """Contains a value and its type."""
  def __init__(self, name: str, data_type: AnyPortType, json_value: JsonValues):
    self.__name = name
    self.__data_type = data_type
    self.__json_value = json_value

  @property
  def name(self) -> str:
    """The name of the output."""
    return self.__name

  @property
  def data_type(self) -> AnyPortType:
    """The data type of this variant."""
    return self.__data_type

  @property
  def json_value(self) -> JsonValues:
    """The value converted to JSON."""
    return self.__json_value

  def __repr__(self) -> str:
    data_type = self.data_type.data_type()
    return (
      f"Variant({self.name}, {data_type.name}, "
      f"{data_type.dimensionality}, {self.json_value})"
    )

  def __eq__(self, other: typing.Any) -> bool:
    if not isinstance(other, Variant):
      return False

    return (
      self.name == other.name
      and self.data_type == other.data_type
      and self.json_value == other.json_value
    )


class OutputDictionary(typing.Generic[T]):
  """Wrapper around the dictionary for storing workflow outputs."""
  def __init__(
    self,
    type_dictionary: dict[str, T | type[ConnectorType]] | None = None,
  ):
    self.__outputs: dict[str, Variant] = {}
    self.__type_dictionary: dict[
      str, T | type[ConnectorType]
    ] = type_dictionary or {}

  def __setitem__(self, key: str, value: typing.Any):
    if key in self.__outputs:
      raise KeyError("There is already an output with the given name.")

    try:
      expected_type = self.__type_dictionary[key]
    except KeyError:
      expected_type = self._derive_type_from_value(key, value)

    self.__outputs[key] = Variant(
      key,
      expected_type,
      self._convert_value_to_json(value, expected_type)
    )

  def __getitem__(self, key: str) -> Variant:
    return self.__outputs[key]

  def __contains__(self, item: object) -> bool:
    return item in self.__outputs

  def _derive_type_from_value(self, key: str, value: typing.Any) -> T:
    raise NotImplementedError

  def _convert_value_to_json(
    self,
    value: typing.Any,
    data_type: T | type[ConnectorType],
  ) -> JsonValues:
    raise NotImplementedError

  def to_dict(self) -> dict[str, Variant]:
    """Return the contents as a dictionary suitable for JSON serialisation."""
    return self.__outputs


class LegacyOutputDictionary(OutputDictionary[DynamicConnectorType]):
  """Output dictionary for use with Workflows."""
  def _derive_type_from_value(
    self,
    key: str,
    value: typing.Any
  ) -> DynamicConnectorType:
    try:
      expected_type = python_type_to_dynamic_connector_type(type(value))
    except KeyError as error:
      raise TypeError(
        f"Invalid output: '{value}' (type: {type(value).__name__}) for "
        f"output: '{key}'"
      ) from error

    return expected_type

  def _convert_value_to_json(
    self,
    value: typing.Any,
    data_type: DynamicConnectorType | type[ConnectorType],
  ) -> JsonValues:
    try:
      return data_type.to_json(value)
    except AttributeError as error:
      raise OutputDataTypeNotSupportedError(
        f"{data_type.data_type().name} is not supported in Workflows. "
        "It requires WorkflowMAE."
      ) from error


class ModernOutputDictionary(OutputDictionary[PortType]):
  """Output dictionary for use with WorkflowMAE."""
  def _derive_type_from_value(
    self,
    key: str,
    value: typing.Any
  ) -> PortType:
    try:
      expected_type = python_type_to_port_type(type(value))
    except ValueError as error:
      raise TypeError(
        f"Invalid output: '{value}' (type: {type(value).__name__}) for "
        f"output: '{key}'"
      ) from error

    return expected_type

  def _convert_value_to_json(
    self,
    value: typing.Any,
    data_type: PortType | type[ConnectorType],
  ) -> JsonValues:
    try:
      return data_type.to_workflow_native(value)
    except AttributeError as error:
      raise OutputDataTypeNotSupportedError(
        f"{data_type.data_type().name} is not supported in WorkflowMAE."
      ) from error
