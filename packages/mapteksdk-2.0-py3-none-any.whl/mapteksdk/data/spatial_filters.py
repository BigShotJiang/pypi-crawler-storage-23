"""Factory module for creating spatial filters.

The functions defined in this package can be used to create spatial filters
which can then be combined with binary operators.

Examples
--------
To hide all blocks of a dense block model where the block centroid is not
between the picked top and bottom surface:

>>> from mapteksdk.data import Surface, DenseBlockModel, spatial_filters
>>> from mapteksdk.operations import object_pick
>>> from mapteksdk.project import Project
>>> def main(project: Project):
...     top_surface_oid = object_pick(
...         object_types=Surface, label="Pick top surface"
...     )
...     bottom_surface_oid = object_pick(
...         object_types=Surface, label="Pick bottom surface"
...     )
...     model_oid = object_pick(
...         object_types=DenseBlockModel,
...         label="Pick block models to filter blocks"
...     )
...     below_top = spatial_filters.below_surface(top_surface_oid)
...     above_bottom = spatial_filters.above_surface(bottom_surface_oid)
...
...     between_surfaces = below_top & above_bottom
...     with project.edit(model_oid) as model:
...         between_surfaces_blocks = between_surfaces.filter(model)
...         # The ~ inverts the match. Otherwise, this would hide the blocks
...         # between the surfaces.
...         model.block_visibility[~between_surfaces_blocks] = False
>>> if __name__ == "__main__":
...     with Project() as project:
...         with project.undo():
...             main(project)
"""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

from ..common.typing import (
  FacetArrayLike,
  PointArrayLike,
)
from ..geometry import Extent, Plane
from ..internal.telemetry import get_telemetry
from . import internal
from .base import Topology
from .facets import Surface
from .internal import SpatialFilter
from .objectid import ObjectID


def __record_telemetry(function_name: str):
  get_telemetry().record_function_call(f"spatial_filters.{function_name}")


def accept_all_filter() -> SpatialFilter:
  """A spatial filter which accepts all points.

  This is useful for when a spatial filter is syntactically required, but the
  caller does not expect to perform any filtering (e.g. When passing a filter
  as a function argument). This is also useful for creating a filter which
  matches points which are matched by all of a set of filters.

  Examples
  --------
  To create a filter which matches points which are inside of all of the
  solids in `surface_ids`:

  >>> surface_ids: Sequence[ObjectID[Surface]]
  >>> all_filter = spatial_filters.accept_all_filter()
  >>> for surface_id in surface_ids:
  ...     all_filter &= spatial_filters.inside_solid(surface_id)
  """
  __record_telemetry("accept_all_filter")
  return internal.ConstantFilter(True)


def reject_all_filter() -> SpatialFilter:
  """A spatial filter which accepts no points.

  This is useful for creating a filter which matches points which are matched
  by any of a set of filters.

  Examples
  --------
  To create a filter which matches points which are inside of any of the
  solids in `surface_ids`:

  >>> surface_ids: Sequence[ObjectID[Surface]]
  >>> any_filter = spatial_filters.reject_all_filter()
  >>> for surface_id in surface_ids:
  ...     any_filter |= spatial_filters.inside_solid(surface_id)
  """
  __record_telemetry("reject_all_filter")
  return internal.ConstantFilter(False)


def any_filters(*filters: SpatialFilter) -> SpatialFilter:
  """Get a filter which matches points matched by any of the `filters`.

  This is equivalent to combining every filter in `filters` with the |
  operator.

  Parameters
  ----------
  filters
    The filters to combine.

  Raises
  ------
  ValueError
    If no filters are given.
    Which points are matched by any of an empty set of filters is poorly
    defined.

  Examples
  --------
  This function is primarily intended to make it easier to combine iterables
  of spatial filters together with an or operator. For example:

  >>> spatial_filters: Iterable[SpatialFilter]
  >>> any_filter = spatial_filters.any_filters(*spatial_filters)

  This is most useful when the spatial filters can be created via a list
  comprehension. For example, to create a filter which matches points which
  are inside of any of the solids in `surface_ids`:

  >>> surface_ids: Sequence[ObjectID[Surface]]
  >>> any_filter = spatial_filters.any_filters(
  ...     *[
  ...           spatial_filters.inside_solid(surface_id)
  ...           for surface_id in surface_ids
  ...     ]
  >>> )

  You can also mix and match filters with this function:

  >>> any_filter = spatial_filters.any_filters(
  ...     spatial_filters.inside_solid(solid_id),
  ...     spatial_filters.above_surface(surface_id),
  >>> )
  """
  __record_telemetry("any_filters")
  return internal.OrFilter(*filters)


def all_filters(*filters: SpatialFilter) -> SpatialFilter:
  """Get a filter which matches points matched by all of the `filters`.

  This is equivalent to combining every filter in `filters` with the &
  operator.

  Parameters
  ----------
  filters
    The filters to combine.

  Raises
  ------
  ValueError
    If no filters are given.
    Which points are matched by all of an empty set of filters is poorly
    defined.

  Examples
  --------
  This function is primarily intended to make it easier to combine iterables
  of spatial filters together with an and operator. For example:

  >>> spatial_filters: Iterable[SpatialFilter]
  >>> all_filter = spatial_filters.all_filters(*spatial_filters)

  This is most useful when the spatial filters can be created via a list
  comprehension. For example, to create a filter which matches points which
  are inside of all of the solids in `surface_ids`:

  >>> surface_ids: Sequence[ObjectID[Surface]]
  >>> all_filter = spatial_filters.all_filters(
  ...     *[
  ...           spatial_filters.inside_solid(surface_id)
  ...           for surface_id in surface_ids
  ...     ]
  >>> )

  You can also mix and match filters with this function:

  >>> all_filter = spatial_filters.all_filters(
  ...     spatial_filters.inside_solid(solid_id),
  ...     spatial_filters.above_surface(surface_id),
  >>> )
  """
  __record_telemetry("all_filters")
  return internal.AndFilter(*filters)


def above_facets(
  points: PointArrayLike,
  facets: FacetArrayLike,
  *,
  include_on: bool = False,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a spatial filter which accepts all points above the given `facets`.

  Parameters
  ----------
  points
    Points of the surface.
  facets
    Facets of the surface.
  include_on
    If set to True, points on the surface will be included by the filter.
    If False (default), points on the surface will be filtered out.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations or
    self-intersections.
  ValueError
    If any facet references a non-existent point.
  """
  __record_telemetry("above_facets")
  filter_type = internal.SurfaceFilterType.ABOVE
  if include_on:
    filter_type |= internal.SurfaceFilterType.ON
  return internal.SurfaceFilter(
    points,
    facets,
    filter_type,
    bypass_validity_check=bypass_validity_check
  )


def above_surface(
  surface_or_id: Surface | ObjectID[Surface],
  *,
  include_on: bool = False,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a spatial filter which accepts all points above `surface`.

  Parameters
  ----------
  surface_or_id
    Open Surface or ObjectID of the Surface the filter will use.
  include_on
    If set to True, points on the surface will be included by the filter.
    If False (default), points on the surface will be filtered out.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `surface_or_id` has less than three points or no facets.
  ObjectClosedError
    If `surface_or_id` is a `Surface` object and `close()` has been called
    on it (i.e. The `Project.read()`, `Project.edit()` or `Project.new()`
    block has ended).
  """
  __record_telemetry("above_surface")
  filter_type = internal.SurfaceFilterType.ABOVE
  if include_on:
    filter_type |= internal.SurfaceFilterType.ON
  return internal.SurfaceFilter.from_surface(
    surface_or_id,
    filter_type,
    bypass_validity_check=bypass_validity_check,
  )


def below_facets(
  points: PointArrayLike,
  facets: FacetArrayLike,
  *,
  include_on: bool = False,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a spatial filter which accepts all points below the given `facets`.

  Parameters
  ----------
  points
    Points of the surface.
  facets
    Facets of the surface.
  include_on
    If set to True, points on the surface will be included by the filter.
    If False (default), points on the surface will be filtered out.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations or
    self-intersections.
  ValueError
    If any facet references a non-existent point.
  """
  __record_telemetry("below_facets")
  filter_type = internal.SurfaceFilterType.BELOW
  if include_on:
    filter_type |= internal.SurfaceFilterType.ON
  return internal.SurfaceFilter(
    points,
    facets,
    filter_type,
    bypass_validity_check=bypass_validity_check
  )


def below_surface(
  surface_or_id: Surface | ObjectID[Surface],
  *,
  include_on: bool = False,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a spatial filter which accepts all points below `surface`.

  Parameters
  ----------
  surface_or_id
    Open Surface or ObjectID of the Surface the filter will use.
  include_on
    If set to True, points on the surface will be included by the filter.
    If False (default), points on the surface will be filtered out.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `surface_or_id` has less than three points or no facets.
  ObjectClosedError
    If `surface_or_id` is a `Surface` object and `close()` has been called
    on it (i.e. The `Project.read()`, `Project.edit()` or `Project.new()`
    block has ended).
  """
  __record_telemetry("below_surface")
  filter_type = internal.SurfaceFilterType.BELOW
  if include_on:
    filter_type |= internal.SurfaceFilterType.ON
  return internal.SurfaceFilter.from_surface(
    surface_or_id,
    filter_type,
    bypass_validity_check=bypass_validity_check,
  )


def inside_facet_extent(
  points: PointArrayLike,
  facets: FacetArrayLike,
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points within the extent of `facets`.

  This will accept points which are above, below or on the surface. It
  rejects where if a line in the direction of the z-axis were drawn
  through the point, that line would not intersect the surface.

  Parameters
  ----------
  points
    Points of the surface.
  facets
    Facets of the surface.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations or
    self-intersections.
  ValueError
    If any facet references a non-existent point.
  """
  __record_telemetry("inside_facet_extent")
  return internal.SurfaceFilter(
    points,
    facets,
    internal.SurfaceFilterType.BELOW
    | internal.SurfaceFilterType.ON
    | internal.SurfaceFilterType.ABOVE,
    bypass_validity_check=bypass_validity_check
  )


def inside_surface_extent(
  surface_or_id: Surface | ObjectID[Surface],
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points within the extent of `surface`.

  This will accept points which are above, below or on the surface. It
  rejects where if a line in the direction of the z-axis were drawn
  through the point, that line would not intersect the surface.

  Parameters
  ----------
  surface_or_id
    Open Surface or ObjectID of the Surface the filter will use.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `surface_or_id` has less than three points or no facets.
  ObjectClosedError
    If `surface_or_id` is a `Surface` object and `close()` has been called
    on it (i.e. The `Project.read()`, `Project.edit()` or `Project.new()`
    block has ended).
  """
  __record_telemetry("inside_surface_extent")
  return internal.SurfaceFilter.from_surface(
    surface_or_id,
    internal.SurfaceFilterType.BELOW
    | internal.SurfaceFilterType.ON
    | internal.SurfaceFilterType.ABOVE,
    bypass_validity_check=bypass_validity_check,
  )


def outside_facet_extent(
  points: PointArrayLike,
  facets: FacetArrayLike,
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points outside the extent of `facets`.

  This only accepts points where if a line in the direction of the z-axis
  were drawn through the point, that line would not intersect the surface.

  Parameters
  ----------
  points
    Points of the surface.
  facets
    Facets of the surface.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations or
    self-intersections.
  ValueError
    If any facet references a non-existent point.
  """
  __record_telemetry("outside_facet_extent")
  return internal.SurfaceFilter(
    points,
    facets,
    internal.SurfaceFilterType.OUTSIDE,
    bypass_validity_check=bypass_validity_check
  )


def outside_surface_extent(
  surface_or_id: Surface | ObjectID[Surface],
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points outside the extent of `surface`.

  This only accepts points where if a line in the direction of the z-axis
  were drawn through the point, that line would not intersect the surface.

  Parameters
  ----------
  surface_or_id
    Open Surface or ObjectID of the Surface the filter will use.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `surface_or_id` has less than three points or no facets.
  ObjectClosedError
    If `surface_or_id` is a `Surface` object and `close()` has been called
    on it (i.e. The `Project.read()`, `Project.edit()` or `Project.new()`
    block has ended).
  """
  __record_telemetry("outside_surface_extent")
  return internal.SurfaceFilter.from_surface(
    surface_or_id,
    internal.SurfaceFilterType.OUTSIDE,
    bypass_validity_check=bypass_validity_check,
  )


def on_facets(
  points: PointArrayLike,
  facets: FacetArrayLike,
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points on the surface.

  Parameters
  ----------
  points
    Points of the surface.
  facets
    Facets of the surface.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations or
    self-intersections.
  ValueError
    If any facet references a non-existent point.
  """
  __record_telemetry("on_facets")
  return internal.SurfaceFilter(
    points,
    facets,
    internal.SurfaceFilterType.ON,
    bypass_validity_check=bypass_validity_check
  )


def on_surface(
  surface_or_id: Surface | ObjectID[Surface],
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points on the surface.

  Parameters
  ----------
  surface_or_id
    Open Surface or ObjectID of the Surface the filter will use.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `surface_or_id` has less than three points or no facets.
  ObjectClosedError
    If `surface_or_id` is a `Surface` object and `close()` has been called
    on it (i.e. The `Project.read()`, `Project.edit()` or `Project.new()`
    block has ended).
  """
  __record_telemetry("on_surface")
  return internal.SurfaceFilter.from_surface(
    surface_or_id,
    internal.SurfaceFilterType.ON,
    bypass_validity_check=bypass_validity_check,
  )


def inside_solid_facets(
  points: PointArrayLike,
  facets: FacetArrayLike,
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points inside the solid defined by facets.

  Points on the solid are considered to be inside.

  Parameters
  ----------
  points
    Points of the solid.
  facets
    Facets of the solid.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations,
    self-intersections or is not closed.
  ValueError
    If any facet references a non-existent point.
  """
  __record_telemetry("inside_solid_facets")
  return internal.SolidFilter(
    points,
    facets,
    bypass_validity_check=bypass_validity_check
  )


def inside_solid(
  surface_or_id: Surface | ObjectID[Surface],
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points inside the solid.

  Points on the solid are considered to be inside.

  Parameters
  ----------
  surface_or_id
    Open Surface or ObjectID of the solid the filter must use.
    It must be a closed surface with consistent surface geometry.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `surface_or_id` has less than three points or no facets.
  ObjectClosedError
    If `surface_or_id` is a `Surface` object and `close()` has been called
    on it (i.e. The `Project.read()`, `Project.edit()` or `Project.new()`
    block has ended).
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations,
    self-intersections or is not closed.
  """
  __record_telemetry("inside_solid")
  return internal.SolidFilter.from_surface(
    surface_or_id,
    bypass_validity_check=bypass_validity_check,
  )


def outside_solid_facets(
  points: PointArrayLike,
  facets: FacetArrayLike,
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points outside the solid defined by facets.

  Points on the solid are considered to be inside.

  Parameters
  ----------
  points
    Points of the solid.
  facets
    Facets of the solid.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations,
    self-intersections or is not closed.
  ValueError
    If any facet references a non-existent point.
  """
  __record_telemetry("outside_solid_facets")
  return internal.SolidFilter(
    points,
    facets,
    bypass_validity_check=bypass_validity_check
  ).invert()


def outside_solid(
  surface_or_id: Surface | ObjectID[Surface],
  *,
  bypass_validity_check: bool = False,
) -> SpatialFilter:
  """Get a filter which accepts all points outside the solid.

  Points on the solid are considered to be inside.

  Parameters
  ----------
  surface_or_id
    Open Surface or ObjectID of the solid the filter must use.
    It must be a closed surface with consistent surface geometry.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `surface_or_id` has less than three points or no facets.
  ObjectClosedError
    If `surface_or_id` is a `Surface` object and `close()` has been called
    on it (i.e. The `Project.read()`, `Project.edit()` or `Project.new()`
    block has ended).
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations,
    self-intersections or is not closed.
  """
  __record_telemetry("outside_solid")
  return internal.SolidFilter.from_surface(
    surface_or_id,
    bypass_validity_check=bypass_validity_check,
  ).invert()


def inside_extent(
  extent: Extent
) -> SpatialFilter:
  """Get a filter which accepts all points inside of `extent`."""
  __record_telemetry("inside_extent")
  return internal.ExtentFilter(extent)


def outside_extent(
  extent: Extent
) -> SpatialFilter:
  """Get a filter which accepts all points outside of `extent`."""
  __record_telemetry("outside_extent")
  return internal.ExtentFilter(extent).invert()


def inside_object_extent(
  topology_or_id: Topology | ObjectID[Topology]
) -> SpatialFilter:
  """A filter which accepts all points inside the extent of `topology_or_id`.

  This accepts any points within the smallest possible axis-aligned
  rectangular prism such that the entire geometry of `topology_or_id` is
  contained within it.

  This will not take into account any changes to the extent since the object
  was opened. If passing an open object, it is best to pass an object which
  was opened with `Project.read()` to ensure that the returned filter
  behaves as expected.

  Raises
  ------
  ObjectClosedError
    If `topology_or_id` is a `Topology` object and `close()` has been
    called on it (i.e. The `Project.read()`, `Project.edit()` or
    `Project.new()` block has ended).
  """
  __record_telemetry("inside_object_extent")
  return internal.ExtentFilter.from_topology(topology_or_id)


def outside_object_extent(
  topology_or_id: Topology | ObjectID[Topology]
) -> SpatialFilter:
  """A filter which rejects all points inside the extent of `topology_or_id`.

  This accepts any points outside the smallest possible axis-aligned
  rectangular prism such that the entire geometry of `topology_or_id` is
  contained within it.

  This will not take into account any changes to the extent since the object
  was opened. If passing an open object, it is best to pass an object which
  was opened with `Project.read()` to ensure that the returned filter
  behaves as expected.

  Raises
  ------
  ObjectClosedError
    If `topology_or_id` is a `Topology` object and `close()` has been
    called on it (i.e. The `Project.read()`, `Project.edit()` or
    `Project.new()` block has ended).
  """
  __record_telemetry("outside_object_extent")
  return internal.ExtentFilter.from_topology(topology_or_id).invert()


def above_plane(plane: Plane, include_on: bool = False) -> SpatialFilter:
  """A filter which accepts all points above `plane`.

  A plane divides space into two half-spaces separated by the plane.
  This matches points in the half-space the plane's normal vector points in.
  i.e. Given the plane defined by the equation `Ax + By + Cz + D = 0`, the
  normal vector is `(A, B, C)` and the 'above' half-space is the half-space
  that normal vector points into.

  Parameters
  ----------
  plane
    The plane to match points above.
  include_on
    If True, points on the plane are also considered to be above the plane.
  """
  __record_telemetry("above_plane")
  filter_type = internal.PlaneFilterType.ABOVE
  if include_on:
    filter_type |= internal.PlaneFilterType.ON
  return internal.PlaneFilter(plane, filter_type)


def below_plane(plane: Plane, include_on: bool = False) -> SpatialFilter:
  """A filter which accepts all points below `plane`.

  This matches points in the opposite half-space to `above_plane`.

  Parameters
  ----------
  plane
    The plane to match points above.
  include_on
    If True, points on the plane are also considered to be above the plane.
  """
  __record_telemetry("below_plane")
  filter_type = internal.PlaneFilterType.BELOW
  if include_on:
    filter_type |= internal.PlaneFilterType.ON
  return internal.PlaneFilter(plane, filter_type)


def on_plane(plane: Plane) -> SpatialFilter:
  """A filter which accepts all points which are on `plane`."""
  __record_telemetry("on_plane")
  return internal.PlaneFilter(plane, internal.PlaneFilterType.ON)


__all__ = [
  # Document spatial filter here. It is defined in internal, so otherwise
  # would not be documented.
  "SpatialFilter",
  "accept_all_filter",
  "reject_all_filter",
  "any_filters",
  "all_filters",
  "above_facets",
  "above_plane",
  "above_surface",
  "below_facets",
  "below_plane",
  "below_surface",
  "inside_extent",
  "inside_facet_extent",
  "inside_object_extent",
  "inside_surface_extent",
  "inside_solid",
  "inside_solid_facets",
  "outside_extent",
  "outside_facet_extent",
  "outside_object_extent",
  "outside_surface_extent",
  "outside_solid",
  "outside_solid_facets",
  "on_facets",
  "on_plane",
  "on_surface",
]
