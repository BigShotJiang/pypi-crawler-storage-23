"""The selection group data type."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

from collections.abc import Callable, Iterable
import enum
import typing

from .objectid import ObjectID
from .base import DataObject
from .containers import Container, VisualContainer
from .selection_file import SelectionFile
from ..capi.util import CApiDllLoadFailureError
from ..internal.lock import LockType
from ..internal.unique_name import unique_name
from ..internal.util import default_type_error_message

if typing.TYPE_CHECKING:
  from collections.abc import Sequence

  from .base.data_object import StaticType
  from ..capi import SelectionApi
  from ..geologycore import DrillholeDatabase, Drillhole


class _Unsupported:
  """Sentinel value used to detect when drillholes are not supported."""


class SelectionGroupTypeNotSupportedError(ValueError):
  """Error raised if the selection group type is not supported."""


class GroupCannotContainObjectError(ValueError):
  """Error raised if the selection group cannot contain an object."""
  def __init__(self, group_type: SelectionGroupType, oid: ObjectID) -> None:
    super().__init__(
      f"Cannot add objects of type: {oid.type_name} to selection group "
      f"of type {group_type}"
    )
    self.group_type = group_type
    """The group type which triggered this error."""
    self.oid = oid
    """The Object ID of the object which could not be part of the group."""


class SelectionGroupType(enum.Enum):
  """Enum indicating the type of objects stored in a selection group."""
  UNDEFINED = 0
  """The selection group type is undefined."""
  DRILLHOLE = 1
  """The selection group can only contain drillholes.

  Warnings
  --------
  This group type only works when the script is connected to GeologyCore.
  Other applications can't operate on drillholes and any attempt to
  add objects to such a group will fail (including attempts to add a drillhole
  to the group).
  Note that the blast holes in BlastLogic are not considered drillholes for
  the purposes of this group type.
  """
  MIXED = 2
  """The selection group can contain any object."""
  FUTURE = 255
  """The selection group type is not supported by the SDK.

  The selection group can be read, but not edited.
  """

  @classmethod
  def from_index(cls, index: int) -> SelectionGroupType:
    """Construct a selection group type from the index.

    If the index is not supported, this will return SelectionGroupType.FUTURE.
    """
    try:
      return cls(index)
    except ValueError:
      return cls.FUTURE

  def is_supported(self) -> bool:
    """True if this group type is supported by mapteksdk."""
    return self in (SelectionGroupType.DRILLHOLE, SelectionGroupType.MIXED)


class DrillholeGroupTemplate:
  """Template used to generate selection group contents.

  This class should not be instantiated directly. Instead, use the functions
  on `SelectionGroup` to get an instance.

  The template consists of a target drillhole database and a set of selection
  files. If the template is used to set the contents of the selection group,
  the contents will be set to be all drillholes in the target database
  which match any inclusion selection files in the template and which do not
  match any exclusion selection files in the template.
  """
  def __init__(self, owner: SelectionGroup):
    # This class basically only provides a logical grouping for the target and
    # the selection items.
    self.__owner = owner
    self.__target: ObjectID[DrillholeDatabase] | None = None
    self.__selection_items: dict[
      ObjectID[SelectionFile], None
    ] | None = None

  def __selection_api(self) -> SelectionApi:
    # pylint: disable=protected-access
    return self.__owner._selection_api()

  def __lock(self):
    # pylint: disable=protected-access
    return self.__owner._lock.lock

  def _is_a_database(
    self,
    oid: ObjectID
  ) -> typing.TypeGuard[ObjectID[DrillholeDatabase]]:
    # pylint: disable=protected-access
    return self.__owner._safe_is_a(oid, self.__owner._database_static_type())

  def _is_a_drillhole(
    self,
    oid: ObjectID
  ) -> typing.TypeGuard[ObjectID[Drillhole]]:
    # pylint: disable=protected-access
    return self.__owner._safe_is_a(oid, self.__owner._drillhole_static_type())

  def _save(self):
    """Save the template."""
    target = self.__target
    if target is not None:
      self.__selection_api().SetGroupTarget(
        self.__lock(), target.handle
      )

    items = self.__selection_items
    if items is not None:
      self.__selection_api().SetGroupSelectionItems(
        self.__lock(),
        [oid.handle for oid in items]
      )

  @property
  def target(self) -> ObjectID[DrillholeDatabase]:
    """The drillhole database used to create the drillhole selection.

    If the group does not have a target or the target has been deleted or
    renamed, this will be the null object ID.
    """
    if self.__target is None:
      target_handle = self.__selection_api().GetGroupTarget(self.__lock())
      target_id = ObjectID(target_handle)

      # The C++ allows the target to be any object. Only return the target
      # if it is a drillhole database.
      if not self._is_a_database(target_id):
        target_id = ObjectID()
      self.__target = target_id
    return self.__target

  @target.setter
  def target(self, oid: ObjectID[DrillholeDatabase]):
    if not isinstance(oid, ObjectID):
      raise TypeError(default_type_error_message("target", oid, ObjectID))
    # pylint: disable=protected-access
    if not self._is_a_database(oid):
      type_name = oid.type_name if oid else "null"
      raise ValueError(
        f"Target must be a drillhole database, not: {type_name}."
      )
    self.__target = oid

  @property
  def _selection_items(self) -> dict[ObjectID[SelectionFile], None]:
    """The selection items as an ordered set.

    Access this through selections instead.
    The selection items are stored as a dictionary using only the keys.
    This is the easiest way to get an ordered set in Python. It must be ordered
    to avoid re-ordering the selection items during save.
    """
    if self.__selection_items is None:
      # pylint: disable=protected-access
      handles = self.__owner._selection_api().GetGroupSelectionItems(
        self.__owner._lock.lock
      )
      object_ids = [ObjectID(handle) for handle in handles]
      # The C++ code allows selection items to contain null object ids and
      # object ids which are not selection files. Thus, filter all the bad
      # ones out.
      self.__selection_items = {
        oid : None for oid in object_ids if oid and oid.is_a(SelectionFile)
      }

    # Return as a tuple to prevent callers from mutating the internal list.
    return self.__selection_items

  @property
  def selection_items(self) -> Sequence[ObjectID[SelectionFile]]:
    """The selection files used to generate the group contents.

    Any selection files which have been renamed or deleted will be silently
    ignored and removed from the selection group when changes are saved.
    """
    # Return as a tuple to prevent callers from mutating the internal
    # representation.
    return tuple(self._selection_items.keys())

  def add_selection_item(self, oid: ObjectID[SelectionFile]):
    """Add a selection file to be used to generate the contents."""
    self.extend_selection_items([oid])

  def extend_selection_items(self, oids: Iterable[ObjectID[SelectionFile]]):
    """Add multiple selection files to use to generate the contents."""
    def validate_oid(oid: ObjectID):
      if not isinstance(oid, ObjectID):
        raise TypeError(
          default_type_error_message("oid", oid, ObjectID[SelectionFile])
        )
      if not oid:
        raise ValueError("Object ID must not be null.")
      if not oid.is_a(SelectionFile):
        raise ValueError(
          f"Object ID must be a selection file, not: {oid.type_name}"
        )

    for oid in oids:
      validate_oid(oid)

    for oid in oids:
      self._selection_items[oid] = None

  def remove_selection_file(self, oid: ObjectID[SelectionFile]):
    """Remove a selection file from generating the contents."""
    if not isinstance(oid, ObjectID):
      raise TypeError(
        default_type_error_message("oid", oid, ObjectID[SelectionFile])
      )

    self._selection_items.pop(oid, None)

  def refresh(self):
    """Refresh the contents of the selection group based on the template.

    This will clear the contents of the group and then add each drillhole
    from the target database for which:
    * The name matches any inclusion selection file in the template.
    * The name does not match any exclusion selection file in the template.

    Raises
    ------
    RuntimeError
      If the target database is not set for this template.
      If there are no selection items in this template.
    """
    target_id = self.target
    if not target_id:
      raise RuntimeError("Cannot refresh because there is no target database.")

    selection_items = self.selection_items
    if not selection_items:
      raise RuntimeError("Cannot refresh because there are no selection files.")

    # DrillholeDatabase is defined in the geologycore subpackage, which
    # depends on the data subpackage. Thus, opening the database as a
    # DrillholeDatabase here would result in a circular dependency between
    # the geologycore and data subpackages.
    # Fortunately, this only needs to read the contents so it can open
    # the drillhole database as a container.
    with Container(target_id, lock_type=LockType.READ) as target_container:
      contents: list[tuple[str, ObjectID]] = [
        (name, oid) for name, oid in target_container.items()
        if self._is_a_drillhole(oid)
      ]

    included: set[ObjectID] = set()
    excluded: set[ObjectID] = set()

    def include_from_file(selection_file: SelectionFile):
      for name, oid in contents:
        if name in selection_file:
          included.add(oid)

    def exclude_from_file(selection_file: SelectionFile):
      for name, oid in contents:
        if name not in selection_file:
          excluded.add(oid)

    any_inclusion_files: bool = False
    for selection_item_id in selection_items:
      with SelectionFile(
        selection_item_id,
        lock_type=LockType.READ
      ) as selection_file:
        if selection_file.is_inclusion:
          include_from_file(selection_file)
          any_inclusion_files = True
        else:
          exclude_from_file(selection_file)

    if not any_inclusion_files:
      # No inclusion files, so all names are considered included.
      included = set(oid for _, oid in contents)

    result = included - excluded
    self.__owner.clear()
    self.__owner.extend(result)


class SelectionGroup(DataObject):
  """A selection which has been saved into the Project.

  These can be selected in the explorer to automatically select the objects in
  the selection group.
  """
  def __init__(
    self,
    object_id: ObjectID[SelectionGroup] | None=None,
    lock_type: LockType=LockType.READWRITE,
    *,
    rollback_on_error: bool=False,
  ):
    is_new = False
    if not object_id:
      object_id = ObjectID(
        self._data_engine_api().NewObject(self.static_type()) # type: ignore
      )
      is_new = True

    super().__init__(object_id, lock_type, rollback_on_error=rollback_on_error)
    self.__contents: dict[str, ObjectID] | None = None
    """Cached copy of the contents of the selection.

    When editing this class, one must be careful to ensure this remains
    synced with the contents in the application.
    """
    self.__drillhole_static_type: StaticType | _Unsupported | None  = None
    """The static type of drillholes.

    Access this through self._drillhole_static_type() instead.
    This will be None if this has not been queried.
    """
    self.__database_static_type: StaticType | _Unsupported | None = None
    """The static type of drillhole databases.

    Access this through self._database_static_type() instead.
    This will be None if this has not been queried.
    """
    self.__template: DrillholeGroupTemplate | None = None
    """The template used to generate the selection group."""

    if is_new:
      self._group_type = SelectionGroupType.MIXED
      self.__contents = {}
      self._save_group_type(self._group_type)
    else:
      self._group_type = SelectionGroupType.from_index(
        self._selection_api().GetSelectionGroupContextType(self._lock.lock)
      )

  @classmethod
  def _selection_api(cls) -> SelectionApi:
    return cls._application_api().selection

  @classmethod
  def static_type(cls) -> StaticType:
    return cls._selection_api().GroupType() # type: ignore

  def _save(self):
    # Most of this class's properties are not cached as this class does not
    # use potentially large NumPy arrays.

    # pylint: disable=protected-access
    template = self.__template
    if template is not None:
      template._save()

  def _extra_invalidate_properties(self):
    self.__contents = None

  def _record_object_size_telemetry(self):
    length = self._data_engine_api().ContainerElementCount(self._lock.lock)
    self._record_size_for("Length", length)

  def _save_group_type(self, group_type: SelectionGroupType):
    """Save the selection group type."""
    self._selection_api().SetSelectionGroupContextType(
        self._lock.lock,
        group_type.value
      )

  def _safe_static_type(
    self,
    query: Callable[[], StaticType]
  ) -> StaticType | _Unsupported:
    """Get the static type when the required DLL may not be present.

    Parameters
    ----------
    query
      Function which returns the static type. This should throw a
      CApiDllLoadFailureError if the dll is not available.

    Returns
    -------
    StaticType
      If query does not throw.
    _Unsupported
      If query throws CApiDllLoadFailureError.
    """
    try:
      return query()
    except CApiDllLoadFailureError:
      # This must not throw exceptions to avoid the script crashing when not
      # connected to GeologyCore.
      return _Unsupported()

  def _drillhole_static_type(self) -> StaticType | _Unsupported:
    """The static type for drillholes.

    This does not use `ObjectID.is_a(Drillhole)` because the `geologycore`
    package depends on `data`, so the `data` package cannot use classes
    defined in `geologycore` without introducing a circular dependency.
    """
    drillhole_static_type = self.__drillhole_static_type
    if drillhole_static_type is None:
      drillhole_static_type = self._safe_static_type(
        # The exception will be thrown by the drillhole_model property,
        # so that must be inside of the lambda.
        # pylint: disable=unnecessary-lambda
        lambda: self._application_api().drillhole_model.DrillholeType()
      )
      self.__drillhole_static_type = drillhole_static_type
    return drillhole_static_type

  def _database_static_type(self) -> StaticType | _Unsupported:
    """The static type for drillhole databases.

    This does not use `ObjectID.is_a(DrillholeDatabase)` because the
    `geologycore` package depends on `data`, so the `data` package cannot
    use classes defined in `geologycore` without introducing a circular
    dependency.
    """
    database_static_type = self.__database_static_type
    if database_static_type is None:
      database_static_type = self._safe_static_type(
        # The exception will be thrown by the drillhole_model property,
        # so that must be inside of the lambda.
        # pylint: disable=unnecessary-lambda
        lambda: self._application_api().drillhole_model.DatabaseType()
      )
      self.__database_static_type = database_static_type
    return database_static_type

  def _safe_is_a(self, oid: ObjectID, static_type: StaticType | _Unsupported):
    if isinstance(static_type, _Unsupported):
      return False

    try:
      return oid.is_a(static_type)
    except TypeError:
      # A null object id is not any type.
      return False

  def _can_change_group_type_to(self, new_type: SelectionGroupType) -> bool:
    if not new_type.is_supported():
      return False
    if new_type is SelectionGroupType.DRILLHOLE and isinstance(
      self._drillhole_static_type(), _Unsupported
    ):
      return False
    return True

  def __raise_if_oid_is_invalid(self, object_id: ObjectID):
    """Raises an error if `object_id` cannot be added to the selection."""
    if not isinstance(object_id, ObjectID):
      raise TypeError(
        default_type_error_message(
          "oid",
          object_id,
          ObjectID
        )
      )

    if not object_id:
      raise ValueError("Cannot add null object ID to the selection.")

    # SelectionGroups only have non-primary parents, so the object ID must
    # have a primary parent.
    if not object_id.parent:
      raise ValueError("Cannot add orphan object to the selection group.")

  def __add(self, name: str, oid: ObjectID):
    """Add an item to the selection group."""
    contents = self._contents

    if oid in contents.values():
      # The Object ID is already in the group.
      # Note that this can't be done via name, as the name of the object
      # in the selection group may not match the primary name.
      # This occurs if the object was added to the selection group and then
      # its primary name was changed, as in this case the secondary name will
      # not be updated to match.
      return

    name = unique_name(
      name,
      lambda potential_name: potential_name in contents
    )

    self._data_engine_api().ContainerAppend(
      self._lock.lock,
      name,
      oid.handle,
      force_primary_parenting=False
    )
    self._contents[name] = oid

  def __is_a_container(
    self,
    oid: ObjectID[DataObject]
  ) -> typing.TypeGuard[ObjectID[Container]]:
    """Type guard which indicates that an OID is a container.

    `oid.is_a(Container)` will return True for almost all objects, as almost
    all objects are non-browsable containers. This returns true if an object
    is a browsable container.
    """
    # pylint: disable=protected-access
    if oid._is_exactly_a(Container):
      return True
    # Note that a SelectionGroup is a VisualContainer on the C++ side,
    # so this returns true for them as well.
    if oid.is_a(VisualContainer):
      return True
    return False

  def __can_include_oid(self, oid: ObjectID) -> bool:
    """True if `oid` can be added to this group."""
    if self.group_type is SelectionGroupType.MIXED:
      return not oid.is_a(VisualContainer)
    if self.group_type is SelectionGroupType.DRILLHOLE:
      return self._safe_is_a(oid, self._drillhole_static_type())
    # Cannot add to a group type Python doesn't know how to handle.
    return False

  def _remove_unsupported_objects(self):
    """Remove all unsupported objects for the current group type."""
    contents = self.contents
    for oid in contents:
      if not self.__can_include_oid(oid):
        self.remove(oid)

  @property
  def _contents(self) -> dict[str, ObjectID]:
    """The names and object IDs of the objects in the selection.

    The name of any item in the selection may not match the object id's
    primary name if the object was renamed since being added to the selection.
    """
    if self.__contents is None:
      contents = self._data_engine_api().GetContainerContents(self._lock.lock)
      self.__contents = {
        name : ObjectID(handle) for name, handle in contents
      }
    return self.__contents

  @property
  def contents(self) -> Sequence[ObjectID]:
    """The Object IDs of the objects in this selection group.

    If this has the DRILLHOLE group_type, this may be a stale selection of
    drillholes if the drillhole database or selection files have been edited
    since this selection group has been updated.
    """
    return tuple(self._contents.values())

  @property
  def group_type(self) -> SelectionGroupType:
    """The type of this selection group."""
    return self._group_type

  @property
  def template(self) -> DrillholeGroupTemplate:
    """Template which was used to generate the groups contents.

    This is only relevant for drillhole selection groups. Accessing this
    property for non-drillhole selection groups will result in an error.

    The contents of the group may not match the template, as the group can
    be edited after the template is used to set the contents.
    """
    if self.group_type is not SelectionGroupType.DRILLHOLE:
      raise SelectionGroupTypeNotSupportedError(
        f"Group type: {self.group_type.name} does not support templates."
      )

    if self.__template is None:
      self.__template = DrillholeGroupTemplate(self)
    return self.__template

  def change_group_type(self, new_type: SelectionGroupType):
    """Change the group type to `new_type`.

    This will remove any unsupported objects from the selection group.
    For example, changing the group type to `SelectionGroupType.Drillhole`
    will remove all non-drillhole objects from the group.

    Raises
    ------
    SelectionGroupTypeNotSupportedError
      If changing the group type to `new_type` is not supported. This will
      always be raised for `SelectionGroupType.UNDEFINED` or
      `SelectionGroupType.FUTURE`. If the script is not connected to
      GeologyCore, this will be raised for `SelectionGroupType.DRILLHOLE` as
      well.
    """
    if not isinstance(new_type, SelectionGroupType):
      raise TypeError(
        default_type_error_message("new_type", new_type, SelectionGroupType)
      )
    if not self._can_change_group_type_to(new_type):
      raise SelectionGroupTypeNotSupportedError(
        f"Unsupported group type: {new_type.name}"
      )
    self._save_group_type(new_type)
    self._group_type = new_type
    self._remove_unsupported_objects()
    self._record_function_call_telemetry(
      f"change_group_type.{new_type.name.lower()}"
    )

  def add(self, oid: ObjectID[DataObject]):
    """Add `oid` to this selection group.

    Raises
    ------
    ValueError
      If `oid` is an orphan object or the null object.
    GroupCannotContainObjectError
      If `oid` cannot be added to groups of this type.
      The most common case of this is if the group type is
      `SelectionGroupType.DRILLHOLE` and `oid` is not a drillhole or if the
      script is not connected to GeologyCore.
    """
    self.extend([oid])

  def extend(self, oids: Iterable[ObjectID[DataObject]]):
    """Add all items in `oids` to the selection group.

    Raises
    ------
    ValueError
      If any item in `oids` is an orphan object or the null object.
    GroupCannotContainObjectError
      If any object in `oids` cannot be added to groups of this type.
      The most common case of this is if the group type is
      `SelectionGroupType.DRILLHOLE` and any item in `oids` is not a drillhole
      or if the script is not connected to GeologyCore.
    """
    if not self.group_type.is_supported():
      raise NotImplementedError(
        f"Adding to groups of type: {self.group_type} is not implemented."
      )
    actual_oids = list(oids)
    # Collect the names and handles first so that if an object ID
    # in the middle is invalid, then none of them are added.
    objects_to_add: list[tuple[str, ObjectID]] = []
    for oid in actual_oids:
      self.__raise_if_oid_is_invalid(oid)
      if self.__is_a_container(oid):
        # Add the contents of a container instead of the container.
        with Container(oid, LockType.READ) as container:
          actual_oids.extend(container.ids())
          continue
      if not self.__can_include_oid(oid):
        raise GroupCannotContainObjectError(self.group_type, oid)
      objects_to_add.append((oid.name, oid))

    for name, handle in objects_to_add:
      self.__add(name, handle)

  def remove(self, oid: ObjectID[DataObject]):
    """Remove `oid` from the selection group.

    This has no effect if `oid` is not in the group.
    """
    if not self.group_type.is_supported():
      raise NotImplementedError(
        f"Removing from groups of type: {self.group_type} is not implemented."
      )
    try:
      self._data_engine_api().ContainerRemoveObject(
        self._lock.lock,
        oid.handle,
        True
      )
    except (AttributeError, TypeError):
      raise TypeError(
        default_type_error_message(
          "oid",
          oid,
          ObjectID[DataObject]
        )
      ) from None
    key_to_remove: str | None = None
    for key, item in self._contents.items():
      if item == oid:
        key_to_remove = key
        break
    if key_to_remove is not None:
      del self._contents[key_to_remove]

  def clear(self):
    """Remove all items from this selection group."""
    if not self.group_type.is_supported():
      raise NotImplementedError(
        f"Clearing groups of type: {self.group_type} is not implemented."
      )
    self._data_engine_api().ContainerPurge(self._lock.lock)
    self._contents.clear()
