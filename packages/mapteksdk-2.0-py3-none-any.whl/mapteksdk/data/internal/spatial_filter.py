"""Classes for filtering points spatially.

Warnings
--------
Vendors and clients should not develop scripts or applications against
this package. The contents may change at any time without warning.
"""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import enum
import typing
import logging
import warnings

import numpy as np

from ...capi import get_application_dlls
from ...common.typing import (
  BlockCentroids3d,
  BooleanArray,
  FacetArray,
  FacetArrayLike,
  PointArray,
  PointArrayLike,
)
from ...geometry import Extent, Plane
from ...internal.lock import LockType
from ...internal.util import default_type_error_message
from ..base import Topology
from ..errors import DegenerateTopologyError, SurfaceValidityError
from ..facets import Surface
from ..objectid import ObjectID

LOG = logging.getLogger("mapteksdk.data.internal")

@typing.runtime_checkable
class HasBlocks(typing.Protocol):
  """Represents any block model class."""
  @property
  def block_centroids(self) -> BlockCentroids3d:
    ...


@typing.runtime_checkable
class HasPoints(typing.Protocol):
  """Represents any class with points."""
  @property
  def points(self) -> PointArray:
    ...


@typing.runtime_checkable
class SpatialFilter(typing.Protocol):
  """Represents a filter which can be used to filter points spatially.

  Examples
  --------
  Multiple spatial filters can be combined using the "&" operator to create
  a filter which only accepts points which are matched by both filters.
  For example:

  >>> block_model: DenseBlockModel
  >>> first = spatial_filters.above_surface(bottom_surface)
  >>> second = spatial_filters.below_surface(top_surface)
  >>> compound = first & second
  >>> blocks_between_surfaces = compound.filter(block_model)

  To create a filter which accepts points matched by either filter, use
  the pipe operator "|" to combine them.
  For example:

  >>> block_model: DenseBlockModel
  >>> first = spatial_filters.below_surface(bottom_surface)
  >>> second = spatial_filters.above_surface(top_surface)
  >>> compound = first | second
  >>> blocks_not_between_surfaces = compound.filter(block_model)

  After calling the filter function, the result can be inverted using the
  '~' operator:

  >>> block_model: DenseBlockModel
  >>> compound: SpatialFilter
  >>> blocks_between_surfaces = compound.filter(block_model)
  >>> blocks_not_between_surfaces = ~blocks_between_surfaces
  """
  def __and__(self, other: SpatialFilter) -> SpatialFilter:
    ...

  def __or__(self, other: SpatialFilter) -> SpatialFilter:
    ...

  def invert(self) -> SpatialFilter:
    """Invert this filter.

    This returns a filter which matches any points not matched by this filter.
    """
    ... # pylint: disable=unnecessary-ellipsis

  def filter(
    self,
    target: PointArrayLike | HasBlocks | HasPoints
  ) -> BooleanArray:
    """Get points in `target` which match the filter.

    True indicates matched points, False indicates non-matched points.

    Examples
    --------
    There are three main ways to call the filter function. The first is to
    pass the points directly:

    >>> spatial_filter: SpatialFilter
    >>> matched_point_mask = spatial_filter.filter([[0, 0, 0], [1, 2, 3]])

    Secondly, to filter to blocks in a block model where the block centroid
    matches the filter:

    >>> spatial_filter: SpatialFilter
    >>> project: Project
    >>> block_model_id: ObjectID[DenseBlockModel]
    >>> with project.read(block_model_id, DenseBlockModel) as block_model:
    ...     filtered_block_mask = spatial_filter.filter(block_model)
    ...     # Make all the blocks which match the filter blue.
    ...     block_model.block_colours[filtered_block_mask] = [0, 0, 200, 255]

    Thirdly, to filter to the points in any `DataObject` subclass with a
    `points` property:

    >>> spatial_filter: SpatialFilter
    >>> project: Project
    >>> point_set_id: ObjectID[PointSet]
    >>> with project.read(point_set_id, PointSet) as point_set:
    ...     filtered_point_mask = spatial_filter.filter(point_set)
    ...     # Make all the points which match the filter blue.
    ...     point_set.point_colours[filtered_point_mask] = [0, 0, 200, 255]
    """
    ... # pylint: disable=unnecessary-ellipsis


class SpatialFilterBase(SpatialFilter):
  """Base class for spatial filters which perform the actual filtering."""
  def __and__(self, other: SpatialFilter) -> SpatialFilter:
    return AndFilter(self, other)

  def __or__(self, other: SpatialFilter) -> SpatialFilter:
    return OrFilter(self, other)

  def invert(self) -> SpatialFilter:
    return InvertFilter(self)

  @typing.final
  def filter(
    self,
    target: PointArrayLike | HasBlocks | HasPoints
  ) -> BooleanArray:
    numpy_points: PointArray
    if isinstance(target, HasBlocks):
      numpy_points = target.block_centroids
    elif isinstance(target, HasPoints):
      numpy_points = target.points
    elif not isinstance(target, np.ndarray):
      numpy_points = np.empty((len(target), 3), dtype=np.float64)
      if len(target) != 0:
        numpy_points[:] = target
    else:
      if target.ndim != 2:
        raise ValueError("Filter only accepts an array of points.")
      if target.shape[1] != 3:
        raise ValueError(
          f"Too many ordinates for point array: {target.shape[1]}."
        )
      # This will only perform a copy if the dtype is not float64.
      numpy_points = target.astype(np.float64, copy=False)
    if not np.all(np.isfinite(numpy_points)):
      raise ValueError(
        "Points to filter contained a non-finite value."
      )

    return self._filter(numpy_points)

  def _filter(self, points: PointArray) -> BooleanArray:
    """Implementation for `filter`.

    Implementing this means subclasses only need to handle points and none of
    the complexities of filtering other objects.
    """
    raise NotImplementedError


class AndFilter(SpatialFilterBase):
  """Matches points matched by all of the given filters.

  Raises
  ------
  ValueError
    If given no filters.
  """
  def __init__(
    self,
    *filters: SpatialFilter
  ) -> None:
    if not filters:
      raise ValueError(
        "Filtering points to any matched by given filters requires at least "
        "one filter."
      )
    super().__init__()
    for child_filter in filters:
      if not isinstance(child_filter, SpatialFilter):
        raise TypeError(default_type_error_message(
          "filter",
          child_filter,
          SpatialFilter
        ))

    # This is a tuple because spatial filters are immutable.
    self._filters = tuple(filters)

  def __and__(self, other: SpatialFilter) -> SpatialFilter:
    # Rather than nest all filters, create a new one with the new filter.
    if isinstance(other, AndFilter):
      return AndFilter(*self._filters, *other._filters)
    return AndFilter(*self._filters, other)

  def _filter(self, points: PointArray) -> BooleanArray:
    result = np.full(len(points), True, dtype=np.bool_)

    for child_filter in self._filters:
      result &= child_filter.filter(points)

    return result


class OrFilter(SpatialFilterBase):
  """Matches any point matched by any of the given filters.

  Raises
  ------
  ValueError
    If given no filters.
  """
  def __init__(
    self,
    *filters: SpatialFilter
  ) -> None:
    if not filters:
      raise ValueError(
        "Filtering points to any matched by given filters requires at least "
        "one filter."
      )
    super().__init__()
    for child_filter in filters:
      if not isinstance(child_filter, SpatialFilter):
        raise TypeError(default_type_error_message(
          "filter",
          child_filter,
          SpatialFilter
        ))

    # This is a tuple because spatial filters are immutable.
    self._filters = tuple(filters)

  def __or__(self, other: SpatialFilter) -> SpatialFilter:
    # Rather than nest any filters, create a new one with the new filter.
    if isinstance(other, OrFilter):
      return OrFilter(*self._filters, *other._filters)
    return OrFilter(*self._filters, other)

  def _filter(self, points: PointArray) -> BooleanArray:
    result = np.full(len(points), False, dtype=np.bool_)

    for child_filter in self._filters:
      result |= child_filter.filter(points)

    return result


class InvertFilter(SpatialFilterBase):
  """A filter which inverts the base filter."""
  def __init__(self, base_filter: SpatialFilter) -> None:
    super().__init__()
    self.__base_filter = base_filter

  def invert(self) -> SpatialFilter:
    return self.__base_filter

  def _filter(self, points: PointArray) -> BooleanArray:
    return ~self.__base_filter.filter(points)


class ConstantFilter(SpatialFilterBase):
  """A filter which returns a uniformly valued array.

  This can either return an array of True, resulting in the filter accepting
  all points, or an array of False, resulting in the filter accepting no
  points.

  Parameters
  ----------
  fill_value
    The value to fill returned arrays with.
  """
  def __init__(self, fill_value: bool) -> None:
    super().__init__()
    self.__fill_value = fill_value

  def _filter(self, points: PointArray) -> BooleanArray:
    return np.full(len(points), self.__fill_value, dtype=np.bool_)

  def invert(self) -> SpatialFilter:
    return ConstantFilter(not self.__fill_value)


class ExtentFilter(SpatialFilterBase):
  """A filter which accepts any points in the given extent."""
  def __init__(self, extent: Extent) -> None:
    if not isinstance(extent, Extent):
      raise TypeError(default_type_error_message("extent", extent, Extent))
    super().__init__()
    self.__extent = extent

  @classmethod
  def from_topology(cls, topology_or_id: Topology | ObjectID[Topology]):
    """Create a filter which accepts any point in the extent of `topology`.

    Raises
    ------
    ObjectClosedError
      If `topology_or_id` is a `Topology` object and `close()` has been
      called on it (i.e. The `Project.read()`, `Project.edit()` or
      `Project.new()` block has ended).
    """
    if isinstance(topology_or_id, Topology):
      return cls(topology_or_id.extent)

    if isinstance(topology_or_id, ObjectID):
      if not topology_or_id.is_a(Topology):
        raise ValueError(
          f"Above surface requires a Surface, not a {topology_or_id.type_name}"
        )
      with Topology(topology_or_id, LockType.READ) as topology:
        return cls(topology.extent)

    raise TypeError(
      default_type_error_message(
        "topology_or_id",
        topology_or_id,
        (Surface, ObjectID[Surface])
      )
    )

  def _filter(self, points: PointArray) -> BooleanArray:
    extent = self.__extent
    result = points >= extent.minimum
    result &= points <= extent.maximum
    return np.all(result, axis=1)


class PlaneFilterType(enum.Flag):
  """Controls how a plane filter filters points.

  Elements can be combined with bitwise elements to create more advanced
  filters.
  """
  NULL = 0
  """No filter type selected.

  This results in an invalid filter which excludes all points.
  """
  BELOW = enum.auto()
  """Match points below the plane.

  This matches points on the side of the plane opposite to the plane's normal
  vector.
  """
  ON = enum.auto()
  """Match points on the plane.

  This matches points on the plane.
  """
  ABOVE = enum.auto()
  """Match points above the plane.

  This matches points on the side of the plane of the plane's normal vector.
  """
  ALL = BELOW | ON | ABOVE
  """All elements are selected.

  This results in an invalid filter which includes all points.
  """

  def is_valid(self) -> bool:
    """If this filter type creates a valid filter.

    The `NULL` and `All` plane filter types do not create valid filters.
    """
    return self not in (PlaneFilterType.ALL, PlaneFilterType.NULL)


class PlaneFilter(SpatialFilterBase):
  """A filter which accepts points above, below or on a given plane.

  Parameters
  ----------
  plane
    The plane to use for this filter.
  filter_type
    Determines how points are matched relative to the plane.
  """
  def __init__(
    self,
    plane: Plane,
    filter_type: PlaneFilterType
  ) -> None:
    if not isinstance(plane, Plane):
      raise TypeError(default_type_error_message("plane", plane, Plane))
    if not filter_type.is_valid():
      raise ValueError(f"Invalid filter type: {filter_type}.")
    super().__init__()
    self.__plane = plane
    self.__filter_type = filter_type

  def _filter(self, points: PointArray) -> BooleanArray:
    include_on = PlaneFilterType.ON in self.__filter_type
    if PlaneFilterType.ABOVE in self.__filter_type:
      return self.__plane.are_points_above_plane(points, include_on)
    if PlaneFilterType.BELOW in self.__filter_type:
      return self.__plane.are_points_below_plane(points, include_on)
    if PlaneFilterType.ON in self.__filter_type:
      return self.__plane.are_points_on_plane(points)

    # A new enum member was added but this was not updated.
    LOG.warning(
      "Unreachable code reached. Invalid plane filter type: %s",
      self.__filter_type
    )
    return ConstantFilter(True).filter(points)


class SurfaceBasedFilterBase(SpatialFilterBase):
  """Base class for surface-based filters.

  This handles validating the geometry of the surface which is used to define
  the filter.
  """
  def __init__(
    self,
    points: PointArrayLike,
    facets: FacetArrayLike,
    *,
    bypass_validity_check = False,
  ) -> None:
    super().__init__()
    if len(points) < 3:
      raise DegenerateTopologyError(
        "A surface must contain at least three points."
      )
    if len(facets) == 0:
      raise DegenerateTopologyError(
        "A surface must contain at least one facet."
      )

    self.__points = np.empty((len(points), 3), dtype=np.float64)
    self.__points[:] = points

    self.__facets = np.empty((len(facets), 3), dtype=np.uint32)
    self._update_facets_safe(facets)

    if np.any(self.__facets > len(points)):
      raise ValueError(
        "One or more facets refers to a point which does not exist."
      )

    if not bypass_validity_check and not self._is_surface_valid(
      self.points, self.facets
    ):
      raise SurfaceValidityError(
        "The given surface has trifurcations, inconsistent normals or "
        "self-intersections. Use `fix_surface` to fix these issues."
      )

  @classmethod
  def from_surface(
    cls,
    surface_or_id: Surface | ObjectID[Surface],
    *,
    bypass_validity_check: bool=False
  ) -> typing.Self:
    """Construct this object from a `Surface` or its `ObjectID`.

    Parameters
    ----------
    surface_or_id
      Open `Surface` or `ObjectID` of the surface to use for this filter.
      If the surface is open with `Project.edit()`, this function will not
      take into account any edits made to the surface if the `ObjectID`
      is passed.
    bypass_validity_check
      Disable the check for surface validity.
      Setting this to True will improve the performance of this function,
      especially for large objects. However, this should only be set to
      True if the caller is certain the surface geometry is valid
      (e.g. Due to calling `fix_surface()` on it).
      Setting this to True when the surface does not have valid geometry will
      cause this function to give inconsistent results.

    Raises
    ------
    DegenerateTopologyError
      If `surface_or_id` has less than three points or no facets.
    ObjectClosedError
      If `surface_or_id` is a `Surface` object and `close()` has been called
      on it (i.e. The `Project.read()`, `Project.edit()` or `Project.new()`
      block has ended).
    """
    if isinstance(surface_or_id, Surface):
      return cls(
        surface_or_id.points,
        surface_or_id.facets,
        bypass_validity_check=bypass_validity_check,
      )
    if isinstance(surface_or_id, ObjectID):
      if not surface_or_id.is_a(Surface):
        raise ValueError(
          f"Above surface requires a Surface, not a {surface_or_id.type_name}"
        )

      with Surface(surface_or_id, lock_type=LockType.READ) as surface:
        return cls(
          surface.points,
          surface.facets,
          bypass_validity_check=bypass_validity_check,
        )

    raise TypeError(
      default_type_error_message(
        "surface_or_id",
        surface_or_id,
        (Surface, ObjectID[Surface])
      )
    )

  @property
  def points(self) -> PointArray:
    """The points which define the surface used by this filter."""
    return self.__points

  @property
  def facets(self) -> FacetArray:
    """The facets which define the surface used by this filter."""
    return self.__facets

  def _update_facets_safe(self, facets: FacetArrayLike):
    """Update the facets.

    This ensures consistent behaviour of updating the facets in all of the
    following situations:
    * Numpy 1.X, warnings are warnings.
    * Numpy 1.X, warnings are errors.
    * Numpy 2.X
    """
    with warnings.catch_warnings(record=True) as warning_filter:
      try:
        self.__facets[:] = facets
      except OverflowError as error:
        # This is hit for numpy 2.X
        raise ValueError(
          "All point indices in facets must be positive."
        ) from error
      except DeprecationWarning as error:
        # This is hit for numpy 1.X with warnings converted to errors.
        raise ValueError(
          "All point indices in facets must be positive."
        ) from error

    if warning_filter:
      # This is hit for numpy 1.X with warnings not converted to errors.
      raise ValueError(
        "All point indices in facets must be positive."
      )

  def _is_surface_valid(self, points: PointArray, facets: FacetArray) -> bool:
    """Return if `points` and `facets` are valid for this filter."""
    raise NotImplementedError

  def _filter(self, points: PointArray) -> BooleanArray:
    raise NotImplementedError


class SurfaceFilterType(enum.Flag):
  """Enum which defines the type of points to filter with a surface filter."""
  ABOVE = enum.auto()
  """Filter to points above the surface."""
  ON = enum.auto()
  """Filter to points on the surface."""
  BELOW = enum.auto()
  """Filter to points below the surface."""
  OUTSIDE = enum.auto()
  """Filter to points outside of the surface extent."""


class SurfaceFilter(SurfaceBasedFilterBase):
  """A filter for classifying if points are above, below or on a surface.

  Parameters
  ----------
  points
    Points which define the surface used by this filter.
  facets
    Facets which define the surface used by this filter.
  filter_type
    Determines whether this filter will match points above, below or on a
    surface.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations or
    self-intersections.
  ValueError
    If any facet references a non-existent point.
  """
  def __init__(
    self,
    points: PointArrayLike,
    facets: FacetArrayLike,
    filter_type: SurfaceFilterType = SurfaceFilterType.ABOVE,
    *,
    bypass_validity_check = False,
  ) -> None:
    super().__init__(
      points,
      facets,
      bypass_validity_check=bypass_validity_check
    )

    if not isinstance(filter_type, SurfaceFilterType):
      raise TypeError(
        default_type_error_message(
          "filter_type",
          filter_type,
          SurfaceFilterType,
        )
      )

    self._filter_type = filter_type

  @classmethod
  def from_surface(
    cls,
    surface_or_id: Surface | ObjectID[Surface],
    filter_type: SurfaceFilterType = SurfaceFilterType.ABOVE,
    *,
    bypass_validity_check: bool=False
  ) -> typing.Self:
    surface_filter = super().from_surface(
      surface_or_id,
      bypass_validity_check=bypass_validity_check
    )
    # pylint: disable=protected-access
    surface_filter._filter_type = filter_type
    return surface_filter

  @property
  def filter_type(self) -> SurfaceFilterType:
    """The filter type used by this filter."""
    return self._filter_type

  def _is_surface_valid(self, points: PointArray, facets: FacetArray) -> bool:
    topology = get_application_dlls().topology
    return topology.CheckFacetNetworkValidity(
      points,
      facets,
      False
    )

  def _filter(self, points: PointArray) -> BooleanArray:
    topology = get_application_dlls().topology

    classification = topology.ClassifyPointsAboveOrBelowSurface(
      self.points,
      self.facets,
      points,
    )

    result = np.full_like(classification, False, dtype=np.bool_)
    filter_type = self.filter_type

    if SurfaceFilterType.ABOVE in filter_type:
      result |= classification == 0
    if SurfaceFilterType.ON in filter_type:
      result |= classification == 1
    if SurfaceFilterType.BELOW in filter_type:
      result |= classification == 2
    if SurfaceFilterType.OUTSIDE in filter_type:
      result |= classification == 3

    return result


class SolidFilter(SurfaceBasedFilterBase):
  """A filter for classifying if points are inside or outside of a solid.

  Parameters
  ----------
  points
    Points which define the surface used by this filter.
  facets
    Facets which define the surface used by this filter.
  filter_type
    Determines whether this filter will match points inside or outside of
    the solid.
  bypass_validity_check
    Disable the check for surface validity.
    Setting this to True will improve the performance of this function,
    especially for large objects. However, this should only be set to
    True if the caller is certain the surface geometry is valid
    (e.g. Due to calling `fix_surface()` on it).
    Setting this to True when the surface does not have valid geometry will
    cause this function to give inconsistent results.

  Raises
  ------
  DegenerateTopologyError
    If `points` contains less than three points or if `facets` contains no
    facets.
  SurfaceValidityError
    If the surface has inconsistent facet normals, trifurcations or
    self-intersections.
  ValueError
    If any facet references a non-existent point.
  """
  def _is_surface_valid(self, points: PointArray, facets: FacetArray) -> bool:
    topology = get_application_dlls().topology
    return topology.CheckFacetNetworkValidity(
      points,
      facets,
      True
    )

  def _filter(self, points: PointArray) -> BooleanArray:
    topology = get_application_dlls().topology

    return topology.ClassifyPointsInSolid(
      self.points,
      self.facets,
      points,
    )
