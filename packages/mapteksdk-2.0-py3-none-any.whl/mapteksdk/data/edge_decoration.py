"""Classes for specifying edge decorations from Python."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

import enum
import math
import typing

from ..internal.util import default_type_error_message

class EdgeGlyph(enum.Enum):
  """A glyph to display on an edge."""
  ARROW = 0
  """Display an arrow head on the edge."""
  DOUBLE_ARROW = 1
  """Display two arrows on the edge."""
  CROSS = 2
  """Display a cross on the edge."""
  TRIPLE_CROSS = 3
  """Display three crosses on the edge."""
  CIRCLE = 4
  """Display a circle on the edge."""
  UNKNOWN = 255
  """Represents an unknown edge glyph.

  Typically, this indicates the SDK is too old to be fully compatible with
  the connected application.
  """



class EdgeGlyphLocation(enum.Enum):
  """Determines where an edge glyph should be displayed."""
  END = 0
  """The glyph should be displayed at the end of the edge."""
  MIDDLE = 1
  """The glyph should be displayed in the middle of the edge."""
  BEGINNING = 2
  """The glyph should be displayed at the start of the edge."""
  UNKNOWN = 255
  """Represents an unknown edge glyph location.

  Typically, this indicates the SDK is too old to be fully compatible with
  the connected application.
  """


class EdgeGlyphSize(typing.NamedTuple):
  """Named tuple representing the size of an edge glyph.

  A negative width or height can be used to flip the edge decoration in that
  direction.

  For objects constructed by `EdgeDecoration`, the width and height should
  always be finite and non-zero.
  """
  width: float
  """The width of the edge glyph in pixels."""
  height: float
  """The height of the edge glyph in pixels."""


class EdgeDecoration:
  """Represents an edge decoration.

  Parameters
  ----------
  glyph
    The glyph to display on the edge.
  location
    The location to display for the glyph.
  size
    The size in the form (width, height).
    This is measured in pixels.

  Raises
  ------
  ValueError
    If size contains a zero or non-finite value.
  """
  def __init__(
    self,
    glyph: EdgeGlyph,
    location: EdgeGlyphLocation,
    size: tuple[float, float] = (32.0, 32.0)
  ):
    if not isinstance(glyph, EdgeGlyph):
      raise TypeError(default_type_error_message("glyph", glyph, EdgeGlyph))
    if not isinstance(location, EdgeGlyphLocation):
      raise TypeError(
        default_type_error_message("location", location, EdgeGlyphLocation)
      )
    self.__glyph = glyph
    self.__location = location

    self.__size = self._validate_size_tuple(size)

  def __repr__(self) -> str:
    return f"EdgeDecoration({self.__glyph},{self.__location},{self.__size})"

  def __eq__(self, other: object) -> bool:
    if not isinstance(other, type(self)):
      return False

    return (
      self.glyph == other.glyph
      and self.location == other.location
      and self.size == other.size
    )

  def _validate_size_tuple(self, size) -> EdgeGlyphSize:
    try:
      width, height = (float(size[0]), float(size[1]))
    except IndexError:
      raise ValueError(
        "Too few ordinates for edge decoration size"
      ) from None

    if width == 0 or not math.isfinite(width):
      raise ValueError(
        f"Invalid width: {width}. "
        "Width must be finite and non-zero."
      )

    if height == 0 or not math.isfinite(height):
      raise ValueError(
        f"Invalid height: {height}. "
        "Height must be finite and non-zero."
      )

    return EdgeGlyphSize(width, height)

  @classmethod
  def arrow_at_end(cls) -> typing.Self:
    """Get an edge decoration representing an arrow at the end of each edge."""
    return cls(EdgeGlyph.ARROW, EdgeGlyphLocation.END)

  @classmethod
  def arrow_in_middle(cls) -> typing.Self:
    """Get a decoration representing an arrow in the middle of each edge."""
    return cls(EdgeGlyph.ARROW, EdgeGlyphLocation.MIDDLE)

  @property
  def glyph(self) -> EdgeGlyph:
    """The edge glyph for this decoration."""
    return self.__glyph

  @property
  def location(self) -> EdgeGlyphLocation:
    """The location for this edge glyph."""
    return self.__location

  @property
  def size(self) -> EdgeGlyphSize:
    """The size of the glyph.

    The width and height are measured in pixels.
    A negative width or height can be used to flip the edge decoration in that
    direction.
    """
    return self.__size
