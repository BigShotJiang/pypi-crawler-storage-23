"""Implementation for the project class.

Classes in this file should not be accessed from outside of the project
subpackage.

"""
###############################################################################
#
# (C) Copyright 2024, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
