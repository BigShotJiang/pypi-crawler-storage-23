"""Module containing classes related to arrays."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

from collections.abc import Callable
import typing

import numpy as np
import numpy.typing as npt

from .util import default_type_error_message

DataTypeT_co = typing.TypeVar("DataTypeT_co", bound=np.dtype, covariant=True)
AnyArray: typing.TypeAlias = np.ndarray[tuple[int, ...], DataTypeT_co]
Array1d: typing.TypeAlias = np.ndarray[tuple[int], DataTypeT_co]
Array2d: typing.TypeAlias = np.ndarray[tuple[int, int], DataTypeT_co]

class ArrayHolder(typing.Protocol, typing.Generic[DataTypeT_co]):
  """Class which holds an array."""
  @property
  def array(self) -> AnyArray[DataTypeT_co]:
    """The array held by this object."""
    ...


class PrimaryArray1D(ArrayHolder[DataTypeT_co]):
  """A holder which contains a 1D array which can vary in length.

  The array is primary because it does not depend on any other array.

  Parameters
  ----------
  data_type
    The data type held in the array.
  initial_array
    The initial values to store in the array.
  """
  def __init__(
    self,
    data_type: DataTypeT_co,
    initial_array: Array1d[DataTypeT_co] | npt.ArrayLike | None=None
  ):
    if not isinstance(data_type, np.dtype):
      raise TypeError(
        default_type_error_message("data_type", data_type, np.dtype)
      )

    self.__data_type: DataTypeT_co = data_type

    self.__array: Array1d | None = None
    if initial_array is not None:
      self.replace_array(initial_array)

  def _generate_default_array(self) -> Array1d:
    """Generate the default array."""
    return np.empty((0,), self.__data_type)

  def replace_array(self, new_array: npt.ArrayLike):
    """Replace the array with the new array.

    Note that the array can be edited in-place by assigning to the array
    property.

    Parameters
    ----------
    new_array
      The new array to store in this holder.
    """
    if isinstance(new_array, np.ndarray
        ) and new_array.dtype == self.__data_type:
      array = new_array
    else:
      array = np.array(new_array, dtype=self.__data_type)

    # Empty arrays (0 dimensional) are valid here.
    if array.ndim > 1:
      raise ValueError(
        "Expected one dimensional array. "
        f"Got: {array.ndim} dimensional array."
      )

    self.__array = array

  @property
  def array(self) -> Array1d:
    """The array contained by this object."""
    if self.__array is None:
      self.__array = self._generate_default_array()
    return self.__array


class SecondaryColourArray2D(ArrayHolder[np.dtype[np.uint8]]):
  """Array which holds one RGBA colour for each element in another array.

  This is secondary because the shape is wholly dependant on another array.
  This only supports one dimensional primary arrays.
  """
  def __init__(
    self,
    get_length: Callable[[], int],
    initial_array: npt.ArrayLike | None = None,
    *,
    default_colour: tuple[float, float, float, float] = (0, 220, 0, 255)
  ):
    self.__get_length = get_length
    self.__array: Array2d[np.dtype[np.uint8]] | None = None
    self.__default_colour: tuple[float, float, float, float] = default_colour
    if initial_array is not None:
      self.array = initial_array

  def _generate_default_array(self) -> Array2d[np.dtype[np.uint8]]:
    """Set the array to a correctly sized array filled with default colours.

    This returns the updated array.
    """
    default = np.empty((self.__get_length(), 4), np.uint8)
    default[:] = self.__default_colour
    self.__array = default
    return default

  def _resize_array(self, current_array: Array2d) -> Array2d:
    """Resize the array and copy over current_array if possible."""
    new_array = self._generate_default_array()
    new_array[:current_array.shape[0]] = current_array[:new_array.shape[0]]
    self.__array = new_array
    current_array = new_array
    return current_array

  def _array_needs_resize(self, array: Array2d) -> bool:
    return array.shape[0] != self.__get_length()

  @property
  def array(self) -> Array2d[np.dtype[np.uint8]]:
    array = self.__array
    if array is None:
      array = self._generate_default_array()

    if self._array_needs_resize(array):
      array = self._resize_array(array)
    return array

  @array.setter
  def array(self, new_array: npt.ArrayLike):
    try:
      self.array[:] = new_array
    except ValueError:
      # Handle RGB colours.
      self.array[:, :3] = new_array
