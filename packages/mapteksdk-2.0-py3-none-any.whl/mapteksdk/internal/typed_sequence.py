"""A strongly typed sequence."""
###############################################################################
#
# (C) Copyright 2025, Maptek Pty Ltd. All rights reserved.
#
###############################################################################
from __future__ import annotations

from collections.abc import MutableSequence, Iterable
import typing

from .util import default_type_error_message

T = typing.TypeVar("T")


class TypedSequence(MutableSequence[T]):
  """A sequence which enforces all elements are the same type."""
  def __init__(self, data_type: type[T]):
    self.__elements = []
    self.__data_type = data_type

  def __repr__(self) -> str:
    return f"TypedSequence({self.__data_type}, {self.__elements})"

  def __len__(self) -> int:
    return len(self.__elements)

  @typing.overload
  def __getitem__(self, index: int) -> T:
    ...

  @typing.overload
  def __getitem__(self, index: slice) -> MutableSequence[T]:
    ...

  def __getitem__(self, *args, **kwargs):
    return self.__elements.__getitem__(*args, **kwargs)

  def insert(self, index: int, value: T) -> None:
    if not isinstance(value, self.__data_type):
      raise TypeError(
        default_type_error_message("value", value, self.__data_type)
      )
    self.__elements.insert(index, value)

  @typing.overload
  def __setitem__(self, index: int, value: T) -> None:
    ...

  @typing.overload
  def __setitem__(self, index: slice, value: Iterable[T]) -> None:
    ...

  def __setitem__(self, index: int | slice, value: T | Iterable[T]):
    if isinstance(value, self.__data_type):
      pass
    elif isinstance(value, Iterable):
      for item in value:
        if not isinstance(item, self.__data_type):
          raise TypeError(
            default_type_error_message("value", item, self.__data_type)
          )
    else:
      raise TypeError(
        default_type_error_message("value", value, self.__data_type)
      )

    # Lists support slices.
    self.__elements[index] = value # type: ignore

  @typing.overload
  def __delitem__(self, index: int) -> None:
    ...

  @typing.overload
  def __delitem__(self, index: slice) -> None:
    ...

  def __delitem__(self, *args, **kwargs):
    self.__elements.__delitem__(*args, **kwargs)
