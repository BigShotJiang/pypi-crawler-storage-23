# Appose: multi-language interprocess cooperation with shared memory.
# Copyright (C) 2023 - 2025 Appose developers.
# SPDX-License-Identifier: BSD-2-Clause

"""
The appose.service package contains classes for services and tasks.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
import threading
from enum import Enum
from pathlib import Path
from traceback import format_exc
from typing import Any, Callable
from uuid import uuid4

from .syntax import ScriptSyntax, get as syntax_from_name
from .util import process
from .util.message import Args, decode, encode, proxify_worker_objects


class TaskException(Exception):
    """
    Exception raised when a Task fails to complete successfully.

    This exception is raised by Task.wait_for() when the task finishes
    in a non-successful state (FAILED, CANCELED, or CRASHED).
    """

    def __init__(self, message: str, task: "Task") -> None:
        super().__init__(message)
        self.task: Task = task


class Service:
    """
    An Appose *service* provides access to a linked Appose *worker* running
    in a different process. Using the service, programs create Appose *tasks*
    that run asynchronously in the worker process, which notifies the
    service of updates via communication over pipes (stdin and stdout).
    """

    _service_count: int = 0

    def __init__(
        self, cwd: str | Path, env_vars: dict[str, str] | None = None, *args: str
    ) -> None:
        self._cwd: Path = Path(cwd)
        self._env_vars: dict[str, str] = env_vars.copy() if env_vars is not None else {}
        self._args: list[str] = list(args)
        self._tasks: dict[str, "Task"] = {}
        self._service_id: int = Service._service_count
        Service._service_count += 1
        self._invalid_lines: list[str] = []
        self._error_lines: list[str] = []
        self._process: subprocess.Popen | None = None
        self._stdout_thread: threading.Thread | None = None
        self._stderr_thread: threading.Thread | None = None
        self._monitor_thread: threading.Thread | None = None
        self._debug_callback: Callable[[str], Any] | None = None
        self._init_script: str | None = None
        self._syntax: ScriptSyntax | None = None

    def debug(self, debug_callback: Callable[[str], Any]) -> "Service":
        """
        Register a callback function to receive messages describing current
        service/worker activity.

        Args:
            debug_callback: A function that accepts a single string argument.
        """
        self._debug_callback = debug_callback
        return self

    def init(self, script: str) -> "Service":
        """
        Register a script to be executed when the worker process first starts up,
        before any tasks are processed. This is useful for early initialization that
        must happen before the worker's main loop begins, such as importing libraries
        that may interfere with I/O operations.

        Example: On Windows, importing numpy can hang when stdin is open for reading
        (described at https://github.com/numpy/numpy/issues/24290).
        Using service.init("import numpy") works around this by importing
        numpy before the worker's I/O loop starts.

        Args:
            script: The script code to execute during worker initialization.

        Returns:
            This service object, for chaining method calls.

        Raises:
            RuntimeError: If the service has already started.
        """
        if self._process is not None:
            raise RuntimeError("Service already started")
        self._init_script = script
        return self

    def start(self) -> "Service":
        """
        Explicitly launch the worker process associated with this service.

        This method is called automatically the first time a task is launched.
        But you can call it yourself if you want to let the worker process
        get going asynchronously before running the first task, or if you
        want to register a debug callback before the process starts to ensure
        you don't miss any events that occur early in the worker execution.

        Returns:
            This service object, for chaining method calls.
        """
        if self._process is not None:
            # Already started.
            return

        prefix = f"Appose-Service-{self._service_id}"

        # If an init script is provided, write it to a temporary file
        # and pass its path via environment variable.
        if self._init_script:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                prefix="appose-init-",
                suffix=".txt",
                delete=False,
            ) as init_file:
                init_file.write(self._init_script)
                self._env_vars["APPOSE_INIT_SCRIPT"] = init_file.name

        self._process = process.builder(self._cwd, self._env_vars, *self._args)
        self._stdout_thread = threading.Thread(
            target=self._stdout_loop, name=f"{prefix}-Stdout"
        )
        self._stderr_thread = threading.Thread(
            target=self._stderr_loop, name=f"{prefix}-Stderr"
        )
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop, name=f"{prefix}-Monitor"
        )
        self._stdout_thread.start()
        self._stderr_thread.start()
        self._monitor_thread.start()
        return self

    def task(
        self, script: str, inputs: Args | None = None, queue: str | None = None
    ) -> "Task":
        """
        Create a new task, passing the given script to the worker for execution.

        Args:
            script: The script for the worker to execute in its environment.
            inputs: Optional list of key/value pairs to feed into the script as inputs.
            queue: Optional queue target. Pass "main" to queue to worker's main thread.
        """
        self.start()
        return Task(self, script, inputs, queue)

    def syntax(self, syntax: str | ScriptSyntax) -> Service:
        """
        Declare the script syntax of this service.

        This value determines which ScriptSyntax implementation is used
        for generating language-specific scripts.

        This method is called directly by Environment.python() and
        Environment.groovy() when creating services of those types.
        It can also be called manually to support custom languages with
        registered ScriptSyntax plugins.

        Args:
            syntax: The type identifier (e.g., "python", "groovy").

        Returns:
            This service object, for chaining method calls.

        Raises:
            ValueError: If no syntax plugin is found for the given type.
        """
        self._syntax = (
            syntax if isinstance(syntax, ScriptSyntax) else syntax_from_name(syntax)
        )
        return self

    def get_var(self, name: str) -> Any:
        """
        Retrieve a variable's value from the worker process's global scope.

        The variable must have been previously exported using task.export()
        to be accessible across tasks.

        Args:
            name: The name of the variable to retrieve.

        Returns:
            The value of the variable.

        Raises:
            TaskException: If the variable retrieval fails.
            ValueError: If no script syntax has been configured for this service.
        """
        if self._syntax is None:
            raise ValueError("No script syntax configured for this service")
        script = self._syntax.get_var(name)
        task = self.task(script).wait_for()
        return task.outputs.get("result")

    def put_var(self, name: str, value: Any) -> None:
        """
        Set a variable in the worker process's global scope and export it
        for future use across tasks.

        Args:
            name: The name of the variable to set in the worker process.
            value: The value to assign to the variable.

        Raises:
            TaskException: If the variable assignment fails.
            ValueError: If no script syntax has been configured for this service.
        """
        if self._syntax is None:
            raise ValueError("No script syntax configured for this service")
        inputs = {"_value": value}
        script = self._syntax.put_var(name, "_value")
        self.task(script, inputs).wait_for()

    def call(self, function: str, *args: Any) -> Any:
        """
        Call a function in the worker process with the given arguments and
        return the result.

        The function must be accessible in the worker's global scope (either
        built-in or previously defined/imported).

        Args:
            function: The name of the function to call in the worker process.
            *args: The arguments to pass to the function.

        Returns:
            The result of the function call.

        Raises:
            TaskException: If the function call fails.
            ValueError: If no script syntax has been configured for this service.
        """
        if self._syntax is None:
            raise ValueError("No script syntax configured for this service")
        inputs = {}
        var_names = []
        for i, arg in enumerate(args):
            var_name = f"arg{i}"
            inputs[var_name] = arg
            var_names.append(var_name)
        script = self._syntax.call(function, var_names)
        task = self.task(script, inputs).wait_for()
        return task.outputs.get("result")

    def proxy(self, var: str, queue: str | None = None) -> Any:
        """
        Create a proxy object providing access to a remote object in this
        service's worker process.

        Method calls on the proxy are transparently forwarded to the remote
        object via Tasks.

        Important: The variable must be explicitly exported using
        task.export(varName=value) in a previous task. Only exported variables
        are accessible across tasks within the same service.

        Args:
            var: The name of the exported variable in the worker process
                 referencing the remote object.
            queue: Optional queue identifier for task execution. Pass "main" to
                   ensure execution on the worker's main thread.

        Returns:
            A proxy object that forwards method calls to the remote object.

        Raises:
            ValueError: If no script syntax has been configured for this service.
        """
        if self._syntax is None:
            raise ValueError("No script syntax configured for this service")
        from .util.proxy import create

        return create(self, var, queue)

    def close(self) -> None:
        """
        Close the worker process's input stream, in order to shut it down.
        """
        if self._process is None:
            raise RuntimeError("Service has not been started")
        self._process.stdin.close()

    def kill(self) -> None:
        """
        Force the service's worker process to begin shutting down. Any tasks still
        pending completion will be interrupted, reporting TaskStatus.CRASHED.

        To shut down the service more gently, allowing any pending tasks to run to
        completion, use close() instead.

        To wait until the service's worker process has completely shut down
        and all output has been reported, call wait_for() afterward.
        """
        self._process.kill()

    def wait_for(self) -> int:
        """
        Wait for the service's worker process to terminate.

        Returns:
            Exit value of the worker process.
        """
        self._process.wait()

        # Wait for worker output processing threads to finish up.
        self._stdout_thread.join()
        self._stderr_thread.join()
        self._monitor_thread.join()

        return self._process.returncode

    def is_alive(self) -> bool:
        """
        Return true if the service's worker process is currently running,
        or false if it has not yet started or has already shut down or crashed.

        Returns:
            Whether the service's worker process is currently running.
        """
        return self._process is not None and self._process.poll() is None

    def invalid_lines(self) -> list[str]:
        """
        Unparseable lines emitted by the worker process on its stdout stream,
        collected over the lifetime of the service.
        Can be useful for analyzing why a worker process has crashed.
        """
        return self._invalid_lines

    def error_lines(self) -> list[str]:
        """
        Lines emitted by the worker process on its stderr stream,
        collected over the lifetime of the service.
        Can be useful for analyzing why a worker process has crashed.
        """
        return self._error_lines

    def _stdout_loop(self) -> None:
        """
        Input loop processing lines from the worker's stdout stream.
        """
        while True:
            stdout = self._process.stdout
            # noinspection PyBroadException
            try:
                line = None if stdout is None else stdout.readline()
            except Exception:
                # Something went wrong reading the stdout line. Panic!
                self._debug_service(format_exc())
                break

            if not line:  # readline returns empty string upon EOF
                self._debug_service("<worker stdout closed>")
                return

            # noinspection PyBroadException
            try:
                response = decode(line)
                self._debug_service(line)  # Echo the line to the debug listener.
                uuid = response.get("task")
                if uuid is None:
                    self._debug_service("Invalid service message: {line}")
                    continue
                task = self._tasks.get(uuid)
                if task is None:
                    self._debug_service(f"No such task: {uuid}")
                    continue
                # noinspection PyProtectedMember
                task._handle(response)
            except Exception:
                # Something went wrong decoding the line of JSON.
                # Skip it and keep going, but log it first.
                self._debug_service(f"<INVALID> {line}")
                self._invalid_lines.append(line.rstrip("\n\r"))

    def _stderr_loop(self) -> None:
        """
        Input loop processing lines from the worker's stderr stream.
        """
        while True:
            stderr = self._process.stderr
            # noinspection PyBroadException
            try:
                line = None if stderr is None else stderr.readline()
            except Exception:
                # Something went wrong reading the stderr line. Panic!
                self._debug_service(format_exc())
                break
            if not line:  # readline returns empty string upon EOF
                self._debug_service("<worker stderr closed>")
                break
            self._debug_worker(line)
            self._error_lines.append(line.rstrip("\n\r"))

    def _monitor_loop(self) -> None:
        # Wait until the worker process terminates.
        self._process.wait()

        # Do some sanity checks.
        exit_code = self._process.returncode
        if exit_code != 0:
            self._debug_service(
                f"<worker process terminated with exit code {exit_code}>"
            )
        task_count = len(self._tasks)
        if task_count == 0:
            # No hanging tasks to clean up.
            return

        self._debug_service(
            "<worker process terminated with "
            + f"{task_count} pending task{'' if task_count == 1 else 's'}>"
        )

        # Notify any remaining tasks about the process crash.
        nl = os.linesep
        error_parts = [f"Worker crashed with exit code {exit_code}."]
        error_parts.append("")
        error_parts.append("[stdout]")
        if len(self._invalid_lines) == 0:
            error_parts.append("<none>")
        else:
            error_parts.extend(self._invalid_lines)
        error_parts.append("")
        error_parts.append("[stderr]")
        if len(self._error_lines) == 0:
            error_parts.append("<none>")
        else:
            error_parts.extend(self._error_lines)
        error = nl.join(error_parts) + nl
        for task in self._tasks.values():
            task._crash(error)
        self._tasks.clear()

    def _debug_service(self, message: str) -> None:
        self._debug("SERVICE", message)

    def _debug_worker(self, message: str) -> None:
        self._debug("WORKER", message)

    def _debug(self, prefix: str, message: str) -> None:
        """
        Pass a message to the callback registered via the debug method.
        """
        if self._debug_callback is None:
            return
        self._debug_callback(f"[{prefix}-{self._service_id}] {message}")

    def __enter__(self) -> "Service":
        return self

    def __exit__(self, exc_type, exc_value, exc_tb) -> None:
        self.close()


class TaskStatus(Enum):
    INITIAL = "INITIAL"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETE = "COMPLETE"
    CANCELED = "CANCELED"
    FAILED = "FAILED"
    CRASHED = "CRASHED"

    def is_finished(self) -> bool:
        """
        True iff status is COMPLETE, CANCELED, FAILED, or CRASHED.
        """
        return self == TaskStatus.COMPLETE or self.is_error()

    def is_error(self) -> bool:
        """
        True iff status is CANCELED, FAILED, or CRASHED.
        """
        return self in (
            TaskStatus.CANCELED,
            TaskStatus.FAILED,
            TaskStatus.CRASHED,
        )


class RequestType(Enum):
    EXECUTE = "EXECUTE"
    CANCEL = "CANCEL"


class ResponseType(Enum):
    LAUNCH = "LAUNCH"
    UPDATE = "UPDATE"
    COMPLETION = "COMPLETION"
    CANCELATION = "CANCELATION"
    FAILURE = "FAILURE"
    CRASH = "CRASH"

    """
    True iff response type is COMPLETE, CANCELED, FAILED, or CRASHED.
    """

    def is_terminal(self) -> bool:
        return self in (
            ResponseType.COMPLETION,
            ResponseType.CANCELATION,
            ResponseType.FAILURE,
            ResponseType.CRASH,
        )


class TaskEvent:
    def __init__(
        self,
        task: "Task",
        response_type: ResponseType,
        message: str | None = None,
        current: int | None = None,
        maximum: int | None = None,
        info: Args | None = None,
    ) -> None:
        self.task: "Task" = task
        self.response_type: ResponseType = response_type
        self.message: str | None = message
        self.current: int | None = current
        self.maximum: int | None = maximum
        self.info: Args | None = info

    def __str__(self):
        return f"[{self.response_type}] {self.task}"


# noinspection PyProtectedMember
class Task:
    """
    An Appose *task* is an asynchronous operation performed by its
    associated Appose *service*. It is analogous to an asyncio.Future.
    """

    def __init__(
        self,
        service: Service,
        script: str,
        inputs: Args | None = None,
        queue: str | None = None,
    ) -> None:
        self.uuid: str = uuid4().hex
        self.service: Service = service
        self.script: str = script
        self.inputs: Args = {}
        self.queue: str | None = queue
        if inputs is not None:
            self.inputs.update(inputs)
        self.outputs: Args = {}
        self.status: TaskStatus = TaskStatus.INITIAL
        self.message: str | None = None
        self.current: int = 0
        self.maximum: int = 1
        self.error: str | None = None
        self.listeners: list[Callable[["TaskEvent"], None]] = []
        self.cv: threading.Condition = threading.Condition()
        self.service._tasks[self.uuid] = self

    def start(self) -> "Task":
        with self.cv:
            if self.status != TaskStatus.INITIAL:
                raise RuntimeError("Task is not in the INITIAL state")

            self.status = TaskStatus.QUEUED

        args = {"script": self.script, "inputs": self.inputs, "queue": self.queue}
        self._request(RequestType.EXECUTE, args)

        return self

    def listen(self, listener: Callable[["TaskEvent"], None]) -> None:
        """
        Register a callback function to be notified of updates to the task.
        """
        with self.cv:
            if self.status != TaskStatus.INITIAL:
                raise RuntimeError("Task is not in the INITIAL state")

            self.listeners.append(listener)

    def wait_for(self) -> "Task":
        """
        Wait for this task to complete.

        Returns:
            This task (for method chaining).

        Raises:
            TaskException: If the task fails, is canceled, or crashes.
        """
        with self.cv:
            if self.status == TaskStatus.INITIAL:
                self.start()

            if self.status not in (TaskStatus.QUEUED, TaskStatus.RUNNING):
                # Task already finished - check if we need to raise
                if self.status != TaskStatus.COMPLETE:
                    self._raise_if_failed()
                return self

            self.cv.wait()

        # After waiting, check if task failed
        self._raise_if_failed()
        return self

    def result(self) -> Any:
        """
        Return the result of this task.

        This is a convenience method that returns outputs["result"].
        For tasks that return a single value (e.g., from an expression),
        that value is stored in outputs["result"].

        Returns:
            The task's result value.
        """
        return self.outputs.get("result")

    def _raise_if_failed(self) -> None:
        """Raise TaskException if this task is in a failed state."""
        if self.status == TaskStatus.FAILED:
            error_msg = self.error if self.error else "Unknown error"
            raise TaskException(f"Task failed: {error_msg}", self)
        elif self.status == TaskStatus.CANCELED:
            raise TaskException("Task was canceled", self)
        elif self.status == TaskStatus.CRASHED:
            error_msg = self.error if self.error else "Worker process crashed"
            raise TaskException(f"Task crashed: {error_msg}", self)

    def cancel(self) -> None:
        """
        Send a task cancelation request to the worker process.
        """
        self._request(RequestType.CANCEL, {})

    def _request(self, request_type: RequestType, args: Args) -> None:
        """
        Send a request to the worker process.
        """
        request = {"task": self.uuid, "requestType": request_type.value}
        if args is not None:
            request.update(args)

        encoded = encode(request)
        # NB: Flush is necessary to ensure worker receives the data!
        print(encoded, file=self.service._process.stdin, flush=True)
        self.service._debug_service(encoded)

    def _handle(self, response: Args) -> None:
        maybe_response_type = response.get("responseType")
        if maybe_response_type is None:
            self.service._debug_service("Message type not specified")
            return
        response_type = ResponseType(maybe_response_type)

        if response_type == ResponseType.LAUNCH:
            self.status = TaskStatus.RUNNING
        elif response_type == ResponseType.UPDATE:
            # No extra action needed.
            pass
        elif response_type == ResponseType.COMPLETION:
            self.service._tasks.pop(self.uuid, None)
            self.status = TaskStatus.COMPLETE
            outputs = response.get("outputs")
            if outputs is not None:
                # Convert any worker_object references to ProxyObject instances.
                proxified_outputs = proxify_worker_objects(outputs, self.service)
                self.outputs.update(proxified_outputs)
        elif response_type == ResponseType.CANCELATION:
            self.service._tasks.pop(self.uuid, None)
            self.status = TaskStatus.CANCELED
        elif response_type == ResponseType.FAILURE:
            self.service._tasks.pop(self.uuid, None)
            self.status = TaskStatus.FAILED
            self.error = response.get("error")
        else:
            self.service._debug_service(
                f"Invalid service message type: {response_type}"
            )
            return

        message = response.get("message")
        current = response.get("current")
        maximum = response.get("maximum")
        info = response.get("info")
        event = TaskEvent(self, response_type, message, current, maximum, info)
        for listener in self.listeners:
            listener(event)

        if self.status.is_finished():
            with self.cv:
                self.cv.notify_all()

    def _crash(self, error: str):
        event = TaskEvent(self, ResponseType.CRASH)
        self.status = TaskStatus.CRASHED
        self.error = error
        for listener in self.listeners:
            listener(event)
        with self.cv:
            self.cv.notify_all()

    def __str__(self):
        return f"{self.uuid=}, {self.status=}, {self.error=}"
