"""
`wagtail-tw-blocks`: is a collection of reusable, production-ready content blocks
for Wagtail CMS, styled with Tailwind CSS and daisyUI. It provides a set of common
UI components—ready to drop into your `StreamField`—so you can build rich, modern page
layouts without reinventing the wheel.
"""
