"""
Core infrastructure for Yahoo Finance operations.

This module provides shared components used across all Yahoo Finance functionality:
- HTTP client for API communication
- Custom exceptions for error handling
"""

from .http_client import YahooFinanceHTTPClient
from .exceptions import (
	YahooFinanceError,
	APIError,
	RateLimitError,
	DataNotFoundError,
	InvalidTickerError,
	ParseError,
	TimeoutError
)

__all__ = [
	'YahooFinanceHTTPClient',
	'YahooFinanceError',
	'APIError',
	'RateLimitError',
	'DataNotFoundError',
	'InvalidTickerError',
	'ParseError',
	'TimeoutError'
]
