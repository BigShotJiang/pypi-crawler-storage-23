"""
Custom exceptions for Yahoo Finance API operations.
"""


class YahooFinanceError(Exception):
    """Base exception for all Yahoo Finance related errors."""
    pass


class APIError(YahooFinanceError):
    """Raised when Yahoo Finance API returns an error."""
    pass


class RateLimitError(YahooFinanceError):
    """Raised when rate limit is exceeded."""
    pass


class DataNotFoundError(YahooFinanceError):
    """Raised when no data is found for the requested ticker."""
    pass


class InvalidTickerError(YahooFinanceError):
    """Raised when ticker symbol is invalid."""
    pass


class ParseError(YahooFinanceError):
    """Raised when JSON response cannot be parsed."""
    pass


class TimeoutError(YahooFinanceError):
    """Raised when request times out."""
    pass
