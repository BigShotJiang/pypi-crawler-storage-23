"""
Events module - Yahoo Finance events helpers.

This module provides parsing utilities for corporate events data.
"""

__all__ = []
