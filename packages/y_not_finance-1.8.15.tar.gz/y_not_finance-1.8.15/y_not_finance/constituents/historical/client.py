"""
S&P 500 Historical Data Client

Provides access to historical S&P 500 constituent lists and intraday OHLC data
downloaded on first use and cached locally as Parquet files.
"""

import logging
from pathlib import Path
from typing import Optional
import urllib.request

import pandas as pd

logger = logging.getLogger(__name__)

_CACHE_DIR = Path.home() / ".my_package_data"

_DATA_MAP = {
    "SPX": ("https://github.com/PIMPOON/DATA/releases/download/Y-Not-Finance/", "sp500_intraday_ohlcv_2024.parquet"),
    "ETFS": ("https://github.com/PIMPOON/DATA/releases/download/Y-Not-Finance/", "ETFs_intraday_ohlcv_2012_2024.parquet"),
    "CONSTITUENTS": ("https://github.com/PIMPOON/DATA/releases/download/Y-Not-Finance/", "sp500_constituents_19800101_20251231.parquet")
}

def _load_parquet(url: str, filename: str) -> pd.DataFrame:
    """Download the parquet file into a local cache and load it."""
    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    complete_url = url + filename
    local_path = _CACHE_DIR / filename

    if not local_path.exists():
        logger.info("Downloading historical data file: %s", filename)
        urllib.request.urlretrieve(complete_url, local_path)

    return pd.read_parquet(local_path)

def get_historical_constituents(
    date: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> pd.DataFrame:
    """
    Retrieve S&P 500 historical constituent data.
    
    Returns daily S&P 500 constituent lists from 1980-01-01 to 2025-12-31.
    Downloads the Parquet file to a local cache on first use.
    
    Args:
        date: Filter to specific date in 'YYYY-MM-DD' format.
        start_date: Filter from this date (inclusive) in 'YYYY-MM-DD' format.
        end_date: Filter to this date (inclusive) in 'YYYY-MM-DD' format.
    
    Returns:
        pd.DataFrame: Constituent data with columns [ticker, date]
    
    Raises:
        ValueError: If date parameters are invalid.
    """
    try:
        logger.info("Loading historical constituents data")
        url, filename = _DATA_MAP["CONSTITUENTS"]
        df = _load_parquet(url, filename)
        
        if df.empty:
            logger.warning("Historical constituents dataframe is empty")
            return df
        
        if "date" in df.columns and df["date"].dtype == "object":
            df["date"] = pd.to_datetime(df["date"])
        
        if date is not None:
            try:
                filter_date = pd.to_datetime(date).date()
                df = df[df["date"].dt.date == filter_date] # type: ignore
                logger.info(f"Filtered to {len(df)} constituents for {date}")
            except Exception as e:
                error_msg = f"Invalid date format ''{date}'': {e}"
                logger.error(error_msg)
                raise ValueError(error_msg)
        else:
            if start_date is not None or end_date is not None:
                try:
                    if start_date is not None:
                        start = pd.to_datetime(start_date)
                        df = df[df["date"] >= start]
                    
                    if end_date is not None:
                        end = pd.to_datetime(end_date)
                        df = df[df["date"] <= end]
                    
                    logger.info(f"Filtered to {len(df)} records for range {start_date} to {end_date}")
                except Exception as e:
                    error_msg = f"Invalid date range: {e}"
                    logger.error(error_msg)
                    raise ValueError(error_msg)
        
        df = df.reset_index(drop=True)
        logger.info(f"Returned {len(df)} records")
        return df
        
    except ValueError:
        raise
    except Exception as e:
        logger.error(f"Error loading historical constituents: {e}", exc_info=True)
        raise


def get_intraday(
    symbol: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> pd.DataFrame:
    """
    Retrieve intraday OHLCV (Open, High, Low, Close, Volume) data.

    Returns intraday price data.
    Downloads the Parquet file to a local cache on first use.

    Args:
        symbol: Filter to specific ticker symbol (e.g., 'SPX', 'ETFs').
        start_date: Filter from this date (inclusive) in 'YYYY-MM-DD' format.
        end_date: Filter to this date (inclusive) in 'YYYY-MM-DD' format.

    Returns:
        pd.DataFrame: Intraday OHLC data with columns [ticker, date, interval_start, open, high, low, close, volume]

    Raises:
        ValueError: If parameters are invalid.
    """

    try:
        logger.info("Loading intraday OHLCV data")

        key = None

        if symbol is not None:
            symbol_upper = symbol.upper()
            if symbol_upper in ["^SPX", "SPX"]:
                key = "SPX"
            elif symbol_upper in ["ETFS", "ETF"]:
                key = "ETFS"
            else: 
                logger.warning("Unknown symbol '%s'. Supported symbols: 'SPX', 'ETFs' (and variations)", symbol)
                return pd.DataFrame()
            
        # Get URL/Filename in one shot
        url, filename = _DATA_MAP.get(key, (None, None)) # type: ignore

        df = _load_parquet(url, filename) if url and filename else pd.DataFrame()

        if df.empty:
            logger.warning("Intraday OHLCV dataframe is empty")
            return df

        # Handle Date Columns (Conversion + Identification)
        date_candidates = ["date", "datetime", "timestamp"]
        date_col = next((col for col in date_candidates if col in df.columns), None)

        for col in date_candidates:
            if col in df.columns and df[col].dtype == "object":
                df[col] = pd.to_datetime(df[col], errors='ignore') # type: ignore

        # Apply date filters
        if date_col and (start_date or end_date):
            try:
                if start_date:
                    df = df[df[date_col] >= pd.to_datetime(start_date)]
                if end_date:
                    df = df[df[date_col] <= pd.to_datetime(end_date)]
                
                logger.info(f"Filtered to {len(df)} records for range {start_date} to {end_date}")
            except Exception as e:
                error_msg = f"Invalid date range logic: {e}"
                logger.error(error_msg)
                raise ValueError(error_msg)

        df = df.reset_index(drop=True)
        logger.info(f"Returned {len(df)} records")
        return df

    except ValueError:
        raise
    except Exception as e:
        logger.error(f"Error loading intraday OHLC data: {e}", exc_info=True)
        raise


__all__ = [
    "get_historical_constituents",
    "get_intraday",
]
