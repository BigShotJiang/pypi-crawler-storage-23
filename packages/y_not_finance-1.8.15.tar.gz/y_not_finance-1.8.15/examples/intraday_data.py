"""
Example showing intraday data fetching and analysis.

This example demonstrates:
- Fetching intraday data at different intervals (1m, 5m, 1h)
- Working with minute-level and hourly data
- Data from a single trading day
"""

import sys
from pathlib import Path
import pandas as pd

# Ensure local package is used when running from repo
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from y_not_finance import YahooFinanceClient


def main():
    api = YahooFinanceClient()
    
    # Example 1: 1-minute data for 1 day
    print("=" * 60)
    print("Example 1: 1-minute data (last day)")
    print("=" * 60)
    df = api.get_prices("AAPL", interval="1m", range_str="1d", fields="close")
    print(df.head(10))
    print(f"Total records: {len(df)}\n")
    
    # Example 2: 5-minute data
    print("=" * 60)
    print("Example 2: 5-minute data (last day)")
    print("=" * 60)
    df = api.get_prices("MSFT", interval="5m", range_str="1d", fields=["open", "close"])
    print(df.head(10))
    print(f"Total records: {len(df)}\n")
    
    # Example 3: 1-hour data
    print("=" * 60)
    print("Example 3: 1-hour data (last 7 days)")
    print("=" * 60)
    df = api.get_prices("GOOGL", interval="1h", range_str="7d", fields="volume")
    print(df.head(10))
    print(f"Total records: {len(df)}\n")
    
    # Example 4: Compare multiple intervals
    print("=" * 60)
    print("Example 4: Compare 1-minute vs 1-hour data")
    print("=" * 60)
    df_1m = api.get_prices("AAPL", interval="1m", range_str="1d", fields="close")
    df_1h = api.get_prices("AAPL", interval="1h", range_str="1d", fields="close")
    
    print(f"1-minute records: {len(df_1m)}")
    print(f"1-hour records: {len(df_1h)}")
    print(f"Ratio: {len(df_1m) / len(df_1h):.1f}x more data with 1-minute interval\n")


if __name__ == "__main__":
    main()
