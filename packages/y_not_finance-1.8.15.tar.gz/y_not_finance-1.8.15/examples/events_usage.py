"""
Examples for Yahoo Finance events data.

Run:
    python examples/events_usage.py
"""

import sys
from pathlib import Path

# Ensure local package is used when running from repo
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
    
from y_not_finance import YahooFinanceClient


def main() -> None:
    client = YahooFinanceClient()

    print("=" * 60)
    print("Example 1: Get dividends for single ticker")
    print("=" * 60)
    dividends_df = client.get_events("XUS.TO", range_str="5y", event_type="dividends")
    print(dividends_df)
    print(f"\nShape: {dividends_df.shape}")

    print("\n" + "=" * 60)
    print("Example 2: Get dividends for multiple tickers")
    print("=" * 60)
    dividends_df = client.get_events(
        ["AAPL", "MSFT"],
        range_str="2y",
        event_type="dividends"
    )
    print(dividends_df.head(10))
    print(f"\nShape: {dividends_df.shape}")

    print("\n" + "=" * 60)
    print("Example 3: Get splits for multiple tickers")
    print("=" * 60)
    splits_df = client.get_events(
        ["NVDA", "TSLA"],
        range_str="10y",
        event_type="splits"
    )
    if not splits_df.empty:
        print(splits_df)
        print(f"\nShape: {splits_df.shape}")
    else:
        print("No splits data available")


if __name__ == "__main__":
    main()
