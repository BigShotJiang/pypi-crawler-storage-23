"""
Example showing data export and persistence.

This example demonstrates:
- Exporting to CSV
- Exporting to Parquet (optional, requires pyarrow)
- Loading data from files
- Comparing different export formats
"""

import os
import sys
from pathlib import Path
import pandas as pd

# Ensure local package is used when running from repo
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from y_not_finance import YahooFinanceClient


def main():
    api = YahooFinanceClient()
    
    # Create output directory
    output_dir = Path("data_exports")
    output_dir.mkdir(exist_ok=True)
    
    # Fetch data
    print("=" * 60)
    print("Fetching data...")
    print("=" * 60)
    df = api.get_prices(
        ["AAPL", "MSFT", "GOOGL"],
        range_str="1y",
        interval="1d",
        fields=["open", "close", "volume"]
    )
    print(f"Fetched {len(df)} records\n")
    
    # Example 1: Export to CSV
    print("=" * 60)
    print("Example 1: Export to CSV")
    print("=" * 60)
    csv_path = output_dir / "stock_data.csv"
    df.to_csv(csv_path)
    csv_size = os.path.getsize(csv_path) / 1024  # KB
    print(f"Saved to: {csv_path}")
    print(f"File size: {csv_size:.2f} KB\n")
    
    # Example 2: Export to Parquet (optional)
    print("=" * 60)
    print("Example 2: Export to Parquet (compressed, optional)")
    print("=" * 60)
    parquet_path = output_dir / "stock_data.parquet"
    parquet_size = 0
    try:
        df.to_parquet(parquet_path)
        parquet_size = os.path.getsize(parquet_path) / 1024  # KB
        print(f"Saved to: {parquet_path}")
        print(f"File size: {parquet_size:.2f} KB")
        print(f"Compression ratio: {csv_size / parquet_size:.2f}x smaller\n")
    except Exception:
        print("Parquet export skipped (install 'pyarrow' to enable).\n")
    
    # Example 3: Load from CSV
    print("=" * 60)
    print("Example 3: Load from CSV")
    print("=" * 60)
    df_csv = pd.read_csv(csv_path, index_col=0, parse_dates=True)
    print("Loaded data shape:", df_csv.shape)
    print("First few rows:")
    print(df_csv.head())
    print()
    
    # Example 4: Load from Parquet
    print("=" * 60)
    print("Example 4: Load from Parquet")
    print("=" * 60)
    df_parquet = pd.read_parquet(parquet_path)
    print("Loaded data shape:", df_parquet.shape)
    print("First few rows:")
    print(df_parquet.head())
    print()
    
    # Example 5: Verify data integrity
    print("=" * 60)
    print("Example 5: Verify data integrity")
    print("=" * 60)
    print(f"CSV and Parquet match: {df_csv.equals(df_parquet)}")
    
    # Compare with original
    print(f"Original and CSV match: {df.equals(df_csv)}")
    print(f"Original and Parquet match: {df.equals(df_parquet)}")
    print()
    
    # Example 6: Export specific fields to Excel
    print("=" * 60)
    print("Example 6: Export to Excel")
    print("=" * 60)
    excel_path = output_dir / "stock_data.xlsx"
    df.to_excel(excel_path)
    excel_size = os.path.getsize(excel_path) / 1024  # KB
    print(f"Saved to: {excel_path}")
    print(f"File size: {excel_size:.2f} KB\n")
    
    # Summary
    print("=" * 60)
    print("Summary")
    print("=" * 60)
    print(f"CSV:     {csv_size:8.2f} KB  - Human readable, widely compatible")
    print(f"Parquet: {parquet_size:8.2f} KB  - Compressed, faster to load")
    print(f"Excel:   {excel_size:8.2f} KB  - Formatted, great for sharing")


if __name__ == "__main__":
    main()
