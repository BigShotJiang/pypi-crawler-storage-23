"""Example usage for historical S&P 500 constituents and intraday OHLC data."""

import sys
from pathlib import Path

# Ensure local package is used when running from repo
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


from y_not_finance import get_historical_constituents, get_intraday


def main() -> None:
    """Run historical data examples."""
    # Daily constituents for a short range
    constituents_df = get_historical_constituents()
    print("Constituents sample:")
    print(constituents_df)

    # Intraday OHLC for a specific symbol
    ohlc_df = get_intraday("test")
    print("\nIntraday OHLC sample:")
    print(ohlc_df)


if __name__ == "__main__":
    main()