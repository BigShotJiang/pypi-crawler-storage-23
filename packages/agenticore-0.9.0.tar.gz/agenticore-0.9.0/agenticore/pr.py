"""Auto-PR creation after successful job execution.

When ``profile.auto_pr: true`` and the job succeeds (exit_code == 0):
1. Check if there are changes in the worktree branch
2. Push the branch
3. Create PR via ``gh pr create``
4. Return PR URL
"""

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Optional

from agenticore.git_credentials import git_askpass_env
from agenticore.jobs import Job
from agenticore.repos import repo_dir, resolve_github_token

logger = logging.getLogger(__name__)


async def create_auto_pr(job: Job) -> Optional[str]:
    """Create a PR for a completed job.

    Requires:
    - GITHUB_TOKEN in env (for ``gh`` CLI)
    - Changes committed by Claude in the worktree branch

    Returns:
        PR URL string, or None if no changes or PR creation failed.
    """
    if not job.repo_url:
        return None

    token = resolve_github_token()
    if not token:
        logger.warning("No GitHub token available — skipping auto-PR for job %s", job.id)
        return None

    rdir = repo_dir(job.repo_url)
    if not rdir.exists():
        return None

    # Find the worktree branch created by Claude
    # Claude --worktree creates branches like cc-worktree-{hash}
    branch = await _get_worktree_branch(rdir, job.id)
    if not branch:
        return None

    # Stage and commit any files Claude wrote but didn't git-add.
    # Claude Code's --worktree mode leaves files untracked when the task
    # doesn't include explicit git operations.
    if job.worktree_path:
        await _commit_untracked(Path(job.worktree_path), job.id)

    # Check if there are commits on this branch
    has_changes = await _has_changes(rdir, branch)
    if not has_changes:
        return None

    # Push the branch
    push_ok = await _push_branch(rdir, branch)
    if not push_ok:
        return None

    # Create PR
    pr_url = await _create_pr(rdir, branch, job)
    return pr_url


async def _commit_untracked(worktree_path: Path, job_id: str) -> None:
    """Stage and commit any untracked/modified files left by Claude.

    Claude Code's --worktree mode may write files without running git.
    This ensures those changes are committed onto the branch before the
    PR is created.  A non-zero exit from ``git commit`` (e.g. "nothing
    to commit") is silently ignored.
    """
    if not worktree_path.exists():
        return
    try:
        add = await asyncio.create_subprocess_exec(
            "git",
            "add",
            "-A",
            cwd=worktree_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await add.communicate()

        commit = await asyncio.create_subprocess_exec(
            "git",
            "commit",
            "-m",
            f"chore: apply changes from agenticore job {job_id}",
            cwd=worktree_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await commit.communicate()
        # rc=1 with "nothing to commit" is normal when Claude committed already
    except Exception as e:
        print(f"_commit_untracked failed for {worktree_path}: {e}", file=sys.stderr)


async def _get_worktree_branch(rdir, _job_id: str) -> Optional[str]:
    """Find the worktree branch for this job."""
    try:
        result = await asyncio.create_subprocess_exec(
            "git",
            "branch",
            "--list",
            "cc-*",
            cwd=rdir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await result.communicate()
        branches = [b.strip().lstrip("* ") for b in stdout.decode().strip().split("\n") if b.strip()]
        # Return the most recent cc- branch (there should typically be one)
        return branches[-1] if branches else None
    except Exception:
        return None


async def _has_changes(rdir, branch: str) -> bool:
    """Check if the branch has commits ahead of the default branch."""
    try:
        result = await asyncio.create_subprocess_exec(
            "git",
            "log",
            f"origin/HEAD..{branch}",
            "--oneline",
            cwd=rdir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await result.communicate()
        return bool(stdout.decode().strip())
    except Exception:
        return False


async def _push_branch(rdir, branch: str) -> bool:
    """Push the branch to origin using GIT_ASKPASS for credentials."""
    token = resolve_github_token()
    with git_askpass_env(token) as extra_env:
        try:
            env = os.environ.copy()
            env.update(extra_env)
            result = await asyncio.create_subprocess_exec(
                "git",
                "push",
                "origin",
                branch,
                cwd=rdir,
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await result.communicate()
            return result.returncode == 0
        except Exception as e:
            print(f"Push failed: {e}", file=sys.stderr)
            return False


async def _create_pr(rdir, branch: str, job: Job) -> Optional[str]:
    """Create a PR using the gh CLI."""
    title = job.task[:70] if len(job.task) > 70 else job.task
    body = f"Job: {job.id}\n\nTask: {job.task}\n\nProfile: {job.profile}"

    token = resolve_github_token()
    env = os.environ.copy()
    if token:
        env["GITHUB_TOKEN"] = token

    try:
        result = await asyncio.create_subprocess_exec(
            "gh",
            "pr",
            "create",
            "--title",
            title,
            "--body",
            body,
            "--head",
            branch,
            cwd=rdir,
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await result.communicate()
        if result.returncode == 0:
            return stdout.decode().strip()
        else:
            print(f"PR creation failed: {stderr.decode()}", file=sys.stderr)
            return None
    except Exception as e:
        print(f"PR creation error: {e}", file=sys.stderr)
        return None
