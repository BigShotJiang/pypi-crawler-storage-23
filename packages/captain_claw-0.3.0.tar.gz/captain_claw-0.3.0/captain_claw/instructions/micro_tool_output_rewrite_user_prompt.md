User request:
{user_input}

Raw output:
{tool_output}{clipped_note}

Produce a helpful final response.