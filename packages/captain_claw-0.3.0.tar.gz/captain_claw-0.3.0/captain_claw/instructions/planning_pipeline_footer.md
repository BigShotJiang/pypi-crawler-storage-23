If tools are needed, use them for the current in-progress task.
