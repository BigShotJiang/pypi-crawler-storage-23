Summarize the earlier conversation for continued work.
Keep it concise and factual. Include:
- user goals and constraints
- important outputs/results
- open questions or pending tasks
- key links, file paths, and commands if present
Use short bullet points.

Conversation excerpt:
{formatted}
