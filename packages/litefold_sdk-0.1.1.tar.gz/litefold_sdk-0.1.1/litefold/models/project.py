from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Project:
    job_name: str
    description: Optional[str] = None
    created_at: Optional[str] = None
    jobs: Optional[dict] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Project":
        return cls(
            job_name=data["job_name"],
            description=data.get("description"),
            created_at=data.get("created_at"),
            jobs=data.get("jobs"),
        )


@dataclass
class ProjectList:
    total: int
    projects: list[Project] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "ProjectList":
        return cls(
            total=data.get("total_projects", 0),
            projects=[Project.from_dict(p) for p in data.get("projects", [])],
        )
