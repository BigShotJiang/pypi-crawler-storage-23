from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class DesignValidation:
    success: bool
    valid: bool
    message: str
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> DesignValidation:
        return cls(
            success=data.get("success", False),
            valid=data.get("valid", False),
            message=data.get("message", ""),
            error=data.get("error"),
        )


@dataclass
class DesignJobSubmission:
    success: bool
    message: str
    job_id: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> DesignJobSubmission:
        return cls(
            success=data.get("success", False),
            message=data.get("message", ""),
            job_id=data.get("job_id"),
        )


@dataclass
class DesignJob:
    id: int
    job_name: str
    design_model_name: str
    design_config_name: str
    protein_name: str
    status: str
    ligand_name: Optional[str] = None
    input_config: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    summary: Optional[dict] = None
    total_designs: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict) -> DesignJob:
        return cls(
            id=data.get("id", 0),
            job_name=data.get("job_name", ""),
            design_model_name=data.get("design_model_name", ""),
            design_config_name=data.get("design_config_name", ""),
            protein_name=data.get("protein_name", ""),
            status=data.get("status", ""),
            ligand_name=data.get("ligand_name"),
            input_config=data.get("input_config"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            summary=data.get("summary"),
            total_designs=data.get("total_designs"),
        )


@dataclass
class DesignJobStatus:
    success: bool
    message: Optional[str] = None
    job_id: Optional[str] = None
    status: Optional[str] = None
    design_model_name: Optional[str] = None
    design_config_name: Optional[str] = None
    protein_name: Optional[str] = None
    ligand_name: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    summary: Optional[dict] = None

    @classmethod
    def from_dict(cls, data: dict) -> DesignJobStatus:
        return cls(
            success=data.get("success", False),
            message=data.get("message"),
            job_id=data.get("job_id"),
            status=data.get("status"),
            design_model_name=data.get("design_model_name"),
            design_config_name=data.get("design_config_name"),
            protein_name=data.get("protein_name"),
            ligand_name=data.get("ligand_name"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            summary=data.get("summary"),
        )


@dataclass
class DesignContent:
    success: bool
    message: Optional[str] = None
    design_model_name: Optional[str] = None
    design_config_name: Optional[str] = None
    protein_name: Optional[str] = None
    ligand_name: Optional[str] = None
    summary: Optional[dict] = None
    total_designs: Optional[int] = None
    designs: Optional[list] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> DesignContent:
        return cls(
            success=data.get("success", False),
            message=data.get("message"),
            design_model_name=data.get("design_model_name"),
            design_config_name=data.get("design_config_name"),
            protein_name=data.get("protein_name"),
            ligand_name=data.get("ligand_name"),
            summary=data.get("summary"),
            total_designs=data.get("total_designs"),
            designs=data.get("designs"),
            error=data.get("error"),
        )
