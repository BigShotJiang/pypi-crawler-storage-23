from __future__ import annotations

import mimetypes
from pathlib import Path
from typing import Optional, Union

from .._http import HttpClient
from ..models.files import FileInfo, FileUrl, UploadResponse


class FilesNamespace:
    def __init__(self, http: HttpClient):
        self._http = http

    # ── upload ───────────────────────────────────────────────────

    def upload(
        self,
        project: str,
        paths: Union[str, Path, list[Union[str, Path]]],
        folder: str = "upload",
    ) -> UploadResponse:
        if isinstance(paths, (str, Path)):
            paths = [paths]

        multipart_files = []
        for p in paths:
            p = Path(p)
            mime = mimetypes.guess_type(str(p))[0] or "application/octet-stream"
            multipart_files.append(("files", (p.name, p.read_bytes(), mime)))

        data = self._http.post_multipart(
            "/uploads",
            data={"job_name": project, "folder": folder},
            files=multipart_files,
        )
        return UploadResponse.from_dict(data)

    def upload_bytes(
        self,
        project: str,
        filename: str,
        content: bytes,
        folder: str = "upload",
        content_type: str = "application/octet-stream",
    ) -> UploadResponse:
        data = self._http.post_multipart(
            "/uploads",
            data={"job_name": project, "folder": folder},
            files=[("files", (filename, content, content_type))],
        )
        return UploadResponse.from_dict(data)

    # ── list ─────────────────────────────────────────────────────

    def list(
        self,
        project: str,
        folder: str = "upload",
    ) -> list[FileInfo]:
        data = self._http.get("/files/list", params={
            "job_name": project,
            "folder": folder,
        })
        return [FileInfo.from_dict(f) for f in data.get("files", [])]

    def list_all(self, project: str) -> list[FileInfo]:
        data = self._http.get("/files/list/all", params={"job_name": project})
        return [FileInfo.from_dict(f) for f in data.get("files", [])]

    def list_by_format(
        self,
        project: str,
        format_type: str,
    ) -> list[FileInfo]:
        data = self._http.get("/files/list/format", params={
            "job_name": project,
            "format_type": format_type,
        })
        return [FileInfo.from_dict(f) for f in data.get("files", [])]

    def list_children(
        self,
        project: str,
        parent_file_name: str,
    ) -> list[FileInfo]:
        data = self._http.get("/files/children", params={
            "job_name": project,
            "parent_file_name": parent_file_name,
        })
        return [FileInfo.from_dict(f) for f in data.get("children", [])]

    # ── read / download ──────────────────────────────────────────

    def get_content(
        self,
        project: str,
        file_name: str,
        folder: str = "upload",
    ) -> str:
        data = self._http.get("/files/content", params={
            "job_name": project,
            "folder": folder,
            "file_name": file_name,
        })
        return data.get("content", "")

    def get_url(
        self,
        project: str,
        file_name: str,
        folder: str = "upload",
        expires_in: int = 3600,
    ) -> FileUrl:
        data = self._http.get("/files/url", params={
            "job_name": project,
            "folder": folder,
            "file_name": file_name,
            "expires_in": expires_in,
        })
        return FileUrl.from_dict(data)

    def download(
        self,
        project: str,
        file_name: str,
        folder: str = "upload",
    ) -> bytes:
        response = self._http.get_raw("/files/download", params={
            "job_name": project,
            "folder": folder,
            "file_name": file_name,
        })
        return response.content

    def download_to(
        self,
        project: str,
        file_name: str,
        dest: Union[str, Path],
        folder: str = "upload",
    ) -> Path:
        dest = Path(dest)
        if dest.is_dir():
            dest = dest / file_name
        dest.write_bytes(self.download(project, file_name, folder))
        return dest

    # ── metadata ─────────────────────────────────────────────────

    def get_metadata(
        self,
        project: str,
        file_name: str,
        folder: str = "upload",
    ) -> FileInfo:
        data = self._http.get("/files/metadata", params={
            "job_name": project,
            "folder": folder,
            "file_name": file_name,
        })
        return FileInfo.from_dict(data)

    def update_metadata(
        self,
        project: str,
        file_name: str,
        metadata: dict,
        folder: str = "upload",
    ) -> dict:
        return self._http.patch("/files/metadata", json={
            "job_name": project,
            "folder": folder,
            "file_name": file_name,
            "metadata": metadata,
        })

    # ── delete ───────────────────────────────────────────────────

    def delete(
        self,
        project: str,
        file_name: str,
        folder: str = "upload",
    ) -> bool:
        data = self._http.delete("/files", params={
            "job_name": project,
            "folder": folder,
            "file_name": file_name,
        })
        return data.get("success", False)

    def delete_batch(
        self,
        project: str,
        file_names: list[str],
        folder: str = "upload",
    ) -> dict:
        data = self._http.post("/files/delete/batch", json={
            "job_name": project,
            "folder": folder,
            "file_names": file_names,
        })
        return data

    # ── sync ─────────────────────────────────────────────────────

    def upsync(self, project: str, folder: str) -> dict:
        return self._http.post("/files/upsync", json={
            "job_name": project,
            "folder": folder,
        })

    def downsync(self, project: str, folder: str) -> dict:
        return self._http.post("/files/downsync", json={
            "job_name": project,
            "folder": folder,
        })
