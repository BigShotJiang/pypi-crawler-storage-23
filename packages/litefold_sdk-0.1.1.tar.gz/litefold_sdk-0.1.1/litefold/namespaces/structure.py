from __future__ import annotations

from .._http import HttpClient
from ..models.structure import (
    StructureJobSubmission,
    StructureJob,
    StructureJobStatus,
    StructurePredictionResult,
)


class StructureNamespace:
    def __init__(self, http: HttpClient):
        self._http = http

    def submit(
        self,
        project: str,
        job_name: str,
        file_names: list[str],
    ) -> StructureJobSubmission:
        data = self._http.post("/structure/submit", json={
            "job_name": job_name,
            "file_names": file_names,
        })
        return StructureJobSubmission.from_dict(data)

    def list_jobs(self, project: str) -> list[StructureJob]:
        data = self._http.get("/structure/jobs")
        return [StructureJob.from_dict(j) for j in data.get("jobs", [])]

    def get_status(self, project: str, job_name: str) -> StructureJobStatus:
        data = self._http.get(f"/structure/jobs/{job_name}/status")
        return StructureJobStatus.from_dict(data)

    def get_result(
        self,
        project: str,
        job_name: str,
        file_name: str,
    ) -> StructurePredictionResult:
        data = self._http.get(f"/structure/jobs/{job_name}/files/{file_name}/result")
        return StructurePredictionResult.from_dict(data)
