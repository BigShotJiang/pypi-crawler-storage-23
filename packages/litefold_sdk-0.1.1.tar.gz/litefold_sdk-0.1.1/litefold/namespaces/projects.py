from typing import Optional

from .._http import HttpClient
from ..models.project import Project, ProjectList


class ProjectsNamespace:
    def __init__(self, http: HttpClient):
        self._http = http

    def create(self, name: str, description: Optional[str] = None) -> Project:
        data = self._http.post("/jobs/init", json={
            "job_name": name,
            "description": description or "",
            "is_default": False,
        })
        return Project(
            job_name=data.get("job_name", name),
            description=description,
        )

    def list(self) -> ProjectList:
        data = self._http.get("/jobs")
        return ProjectList.from_dict(data)

    def get(self, name: str) -> Project:
        data = self._http.get(f"/jobs/{name}")
        return Project.from_dict({
            "job_name": data.get("job_name", name),
            "description": data.get("description"),
            "created_at": data.get("created_at"),
            "jobs": data.get("jobs"),
        })

    def delete(self, name: str) -> bool:
        data = self._http.delete(f"/jobs/{name}")
        return data.get("success", False)
