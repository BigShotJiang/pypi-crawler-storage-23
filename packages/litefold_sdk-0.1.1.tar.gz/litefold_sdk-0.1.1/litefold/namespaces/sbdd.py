from __future__ import annotations

from typing import Optional

from .._http import HttpClient
from ..models.sbdd import (
    SBDDJobSubmission,
    SBDDJob,
    SBDDJobStatus,
    SBDDResults,
    SBDDMoleculeDetail,
    SBDDSummary,
)


class SBDDNamespace:
    def __init__(self, http: HttpClient):
        self._http = http

    def submit(
        self,
        project: str,
        job_name: str,
        protein_file_name: str,
        pocket_coords: list[float],
        num_mols: int = 100,
        radius: int = 13,
    ) -> SBDDJobSubmission:
        data = self._http.post("/sbdd/submit", json={
            "job_name": job_name,
            "protein_file_name": protein_file_name,
            "pocket_coords": pocket_coords,
            "num_mols": num_mols,
            "radius": radius,
        })
        return SBDDJobSubmission.from_dict(data)

    def list_jobs(
        self,
        project: str,
        job_name: Optional[str] = None,
    ) -> list[SBDDJob]:
        params: dict = {}
        if job_name:
            params["job_name"] = job_name
        data = self._http.get("/sbdd/jobs", params=params or None)
        return [SBDDJob.from_dict(j) for j in data.get("jobs", [])]

    def get_status(
        self,
        project: str,
        job_name: str,
        protein_file_name: str,
    ) -> SBDDJobStatus:
        data = self._http.get(f"/sbdd/status/{job_name}/{protein_file_name}")
        return SBDDJobStatus.from_dict(data)

    def get_results(
        self,
        project: str,
        job_name: str,
        protein_file_name: str,
        denovo_job_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        sort_by: str = "vina_score",
        sort_order: str = "asc",
    ) -> SBDDResults:
        params: dict = {
            "limit": limit,
            "offset": offset,
            "sort_by": sort_by,
            "sort_order": sort_order,
        }
        if denovo_job_id:
            params["denovo_job_id"] = denovo_job_id
        data = self._http.get(
            f"/sbdd/results/{job_name}/{protein_file_name}",
            params=params,
        )
        return SBDDResults.from_dict(data)

    def get_molecule(
        self,
        project: str,
        job_name: str,
        mol_id: str,
    ) -> SBDDMoleculeDetail:
        data = self._http.get(f"/sbdd/molecule/{job_name}/{mol_id}")
        return SBDDMoleculeDetail.from_dict(data)

    def get_summary(
        self,
        project: str,
        job_name: str,
        protein_file_name: str,
    ) -> SBDDSummary:
        data = self._http.get(f"/sbdd/summary/{job_name}/{protein_file_name}")
        return SBDDSummary.from_dict(data)
