class LiteFoldError(Exception):
    pass


class LiteFoldAPIError(LiteFoldError):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"HTTP {status_code}: {message}")


class LiteFoldAuthError(LiteFoldAPIError):
    pass


class LiteFoldNotFoundError(LiteFoldAPIError):
    pass


class LiteFoldRateLimitError(LiteFoldAPIError):
    pass


class LiteFoldTimeoutError(LiteFoldError):
    pass
