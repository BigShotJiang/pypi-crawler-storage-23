"""LVAE losses."""
