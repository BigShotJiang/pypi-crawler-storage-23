"""NG Dataset compatible callbacks for PyTorch Lightning."""
