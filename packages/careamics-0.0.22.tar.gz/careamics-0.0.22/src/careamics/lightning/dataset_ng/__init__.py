"""Next-Generation DataModules for Careamics."""
