"""Models package."""

__all__ = ["model_factory"]

from .model_factory import model_factory
