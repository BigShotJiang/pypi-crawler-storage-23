---
name: Interoperability request
about: Tell us about potential synergies for CAREamics
title: "[Interoperability]"
labels: interoperability
assignees: ''
---

## Description
<!-- A clear and concise description of what other software or tool CAREamics could be compatible with. -->

[description here]

## Limitations to interfacing
<!-- Description of the current limitations and challenges to interfacing CAREamics with this other tool. -->

[description here]


## References

<!-- Add any other context, links, publications, guidelines that are relevant to interfacing the tool with other libraries. -->

[additional context here]
