---
name: Question
about: Ask us anything about CAREamics
title: "[Question]"
labels: question
assignees: ''
---

## Question
<!-- A clear question about CAREamics and how to use it. -->

[question here]

