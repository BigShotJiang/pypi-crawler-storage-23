---
name: Example report
about: Tell us about how you use CAREamics
title: "[Example]"
labels: example
assignees: ''
---

## Task
<!-- A description of what you are trying to achieve. -->

[description here]

## Results
<!-- Description of the results obtained with CAREamics. -->

[description here]


## References

<!-- Potential references, such as your preprint or article. -->

[additional context here]
