---
name: Feature request
about: Suggest an idea for CAREamics
title: '[Feature]'
labels: feature
assignees: ''

---

## Problem
<!-- A clear and concise description of what the problem is. -->

[your problem description here]


## Potential solution
<!-- A clear and concise description of what you want to happen. -->

[potential solution here, if applicable]

