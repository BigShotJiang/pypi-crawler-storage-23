# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/betas.py
"""
Exact rational β-stream construction for the φ-Engine.

Each β-stream defines the contraction weights that transform factorial
Fibonacci node evaluations into derivative or integral results
without grids or numeric fitting. All coefficients are derived exactly
as rational objects by solving the finite moment system:

    Σ_i β_i x_i^k = w_k,    for k = 0..R,

where x_i = 1/(F_i!)² and w_k comes from the selected moment law
in `moments.py`. The resulting β-streams guarantee perfect algebraic
consistency and form the certified payload recorded in φ-certificates.

The combinatorial backbone is built from elementary symmetric polynomials
over the factorial-derived layers. Given nodes xᵢ, these routines compute
σₖ and related structures forming the coefficients of the characteristic
polynomial P_R(x) = ∏(x - xᵢ). All symmetric-sum relations are purely
algebraic — no floating-point arithmetic, no approximation.

The canonical contraction formula is:
    βᵢ = [1 / P′(xᵢ)] Σₖ wₖ (−1)^{R−k} σ_{R−k}^{(i)}

where P′(xᵢ) = ∏_{j≠i}(xᵢ - xⱼ) supplies the denominators and
leave-one-out symmetric sums σₖ^{(i)} supply the numerator structure.

Functions
---------
- `beta_from_moment_law(xs, w)`
    Solve a given moment law for β-coefficients using exact arithmetic.
- `beta_operator_fractions(fib_count)`
    Build all standard β-streams ("derivative", "integral")
    for a specified factorial Fibonacci ladder length.

Dependencies
------------
- `fib.py` for factorial Fibonacci node generation.
- `moments.py` for target moment laws.
"""

from fractions import Fraction

from ._rational import Fraction
from typing import Dict, List
from .fib import *
from .moments import *


def elem_symmetric_sums(xs: List[Fraction]) -> List[Fraction]:
    """Compute σ_k for k=0..R+1 (σ_0=1) using standard recurrence."""
    n = len(xs)
    sigma = [Fraction(0)] * (n + 1)
    sigma[0] = Fraction(1)
    for x in xs:
        for k in range(n, 0, -1):
            sigma[k] += x * sigma[k-1]
    return sigma  # length n+1


def leave_one_out_symmetric_sums(xs: List[Fraction],
                                 sigma: List[Fraction]) -> List[List[Fraction]]:
    """
    σ_k = σ_k^{(i)} + x_i σ_{k-1}^{(i)},  σ_0^{(i)}=1.
    Solve forward for σ_k^{(i)}.
    """
    n = len(xs)
    R = n - 1
    loi: List[List[Fraction]] = []
    for i, xi in enumerate(xs):
        s = [Fraction(0)] * (R + 1)
        s[0] = Fraction(1)
        for k in range(1, R + 1):
            s[k] = sigma[k] - xi * s[k-1]
        loi.append(s)
    return loi


def Pprime_at_layers(xs: List[Fraction]) -> List[Fraction]:
    """P_R'(x_i) = ∏_{j≠i}(x_i - x_j)."""
    n = len(xs)
    out = []
    for i in range(n):
        xi = xs[i]
        prod = Fraction(1)
        for j in range(n):
            if j == i: continue
            prod *= (xi - xs[j])
        out.append(prod)
    return out


def beta_from_moment_law(xs: List[Fraction],
                         w: List[Fraction]) -> List[Fraction]:
    """
    Solve for β-coefficients that satisfy a given factorial moment law.

    Parameters
    ----------
    xs : list[Fraction]
        Node locations, typically x_i = 1/(F_i!)² for a factorial Fibonacci ladder.
    w : list[Fraction]
        Target moments defining the contraction rule (from `moments.py`).

    Returns
    -------
    list[Fraction]
        Exact rational β-coefficients satisfying Σ_i β_i x_i^k = w_k
        for k = 0..R, with R = len(xs) - 1.

    Notes
    -----
    This function builds and solves the moment system using exact
    fraction arithmetic. It never performs floating-point operations.
    """
    n = len(xs)
    R = n - 1
    sigma = elem_symmetric_sums(xs)
    loi = leave_one_out_symmetric_sums(xs, sigma)
    Pp  = Pprime_at_layers(xs)
    betas: List[Fraction] = []
    for i in range(n):
        acc = Fraction(0)
        s_i = loi[i]
        for k in range(n):
            sign = -1 if ((R - k) % 2 == 1) else 1
            acc += w[k] * sign * s_i[R - k]
        betas.append(acc / Pp[i])
    return betas

# ---------- Exact β-streams as Fractions ----------

def beta_operator_fractions(fib_count: int, order: int = 1) -> Dict[str, List[Fraction]]:
    """
    Construct all β-stream families (value, derivative, integral, int_primitive)
    as exact Fractions for the given factorial ladder depth and operator order.

    Parameters
    ----------
    fib_count : int
        Number of factorial layers (Fibonacci count - 1).
    order : int, optional
        Operator order. Affects:
            • derivative  → nth derivative
            • integral    → nth integral

    Returns
    -------
    dict[str, list[Fraction]]
        {"value": [...], "derivative": [...], "integral": [...]}
    """

    fibs = fib_ladder(fib_count)
    xs   = layers_from_fibs(fibs)

    ops: Dict[str, List[Fraction]] = {
        "derivative": beta_from_moment_law(xs, w_derivative(fib_count, order)),
        "integral": beta_from_moment_law(xs, w_integral(fib_count, order)),
    }

    return ops

