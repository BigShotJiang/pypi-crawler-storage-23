# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/moments.py
"""
Moment laws defining factorial contraction targets for φ-calculus.

This module encodes the analytic moment constraints that define each
β-stream family — derivative, and integral — within the φ-Engine.
Each moment law provides the exact rational targets Σ βᵢ xᵢᵏ = Mₖ for
k = 0..R, forming the linear systems solved by `beta_from_moment_law`.

Unlike numerical quadrature weights, these coefficients are not fitted
to functions or grids; they are *structural laws*. Each set of weights
expresses how factorial displacements contract to yield the identity
for a given operator family. The “integral” mode, for example, enforces
Σ βᵢ xᵢᵏ = 1/(2k+1), reproducing the primitive-free symmetric integral.

These laws fully determine the calculus behavior of the φ-Engine:
  - `w_derivative`: δ-moment, for first-order difference contraction.
  - `w_integral`: moment targets 1/(2k+1) for first-order symmetric integral.

Together they form the canonical factorial basis of φ-calculus.
They allow functions to execute themselves, with no retrospection.
"""

from ._rational import Fraction
from typing import List
from math import factorial

def w_integral(n: int, order: int = 1) -> List[Fraction]:
    return [Fraction(1, 2*k + 1) for k in range(n)]


def w_derivative(n: int, order: int = 1) -> list[Fraction]:
    """
    Moment targets for extracting f^{(order)}(x) under the engine's
    parity-aware sampling:

    odd order:  m*(F(x+h)-F(x-h))
    even order: (F(x+h)+F(x-h)-2F(x))/h^2
    with h = 1/(2m) and x_i = 1/m^2.

    For a moment vector of length n, the implied index is:
      odd  order = 2k+1 → k = (order-1)//2  (requires k < n)
      even order = 2k+2 → k = order//2 - 1  (requires k < n)
    """
    if order < 1:
        raise ValueError("order must be >= 1")

    w = [Fraction(0) for _ in range(n)]

    if order % 2 == 1:
        # order = 2k+1
        k = (order - 1) // 2
        if k >= n:
            raise ValueError(
                f"Requested derivative order {order} exceeds moment depth for n={n}. "
                f"Increase fib_count or reduce order (requires k<(n), here k={(order-1)//2})."
            )
        w[k] = Fraction((4 ** k) * factorial(order), 1)
    else:
        # order = 2k+2
        k = (order // 2) - 1
        if k >= n:
            raise ValueError(
                f"Requested derivative order {order} exceeds moment depth for n={n}. "
                f"Increase fib_count or reduce order (requires k<(n), here k={order//2 - 1})."
            )
        w[k] = Fraction((4 ** k) * factorial(order), 2)
    return w

