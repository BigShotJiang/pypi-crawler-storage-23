# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# =============================================================================================================
# ⚠️  IMPORTANT NOTE FOR READERS OF THE LETTER  ⚠️
#
# This implementation predates the final φ-Calculus letter.
# The mathematics in the letter is the canonical reference.
# Variable names, helper functions, and docstrings in this file may use
# older notation.
# The *structure* is correct:
#     – factorial layers  ->  phi_i = 1/F_i^+!
#     – symmetric probes  ->  S_avg and S_diff
#     – moment laws       ->  beta_i streams
#     – dyadic tiling     ->  global integration
#
# The engine matches the finalized theory exactly — only terminology differs.
# A notation-aligned refactor is planned for v1.1+.
# Until then if you have questions try reading the LetterToCantor.pdf
# Located at: https://github.com/Purrplexia/LettersToMyHeroes/Cantor_GoldenContinuum/LetterToCantor.pdf
# =============================================================================================================


# phi_engine/core/phi_engine.py
"""
φ-Engine core: the executable calculus kernel.

This module houses the `PhiEngine` class — the unified factorial runtime that performs
evaluation, differentiation, and integration entirely from β coefficient-streams.
All combinatorics and scaling factors are handled as exact Fractions;
only the output is ever evaluated in floating-point form via mpmath.

There are no grids, meshes, or quadrature points here.  The φ-Engine contracts exact
moment-law coefficients (β-streams) with symmetric difference operators that probe the
function directly in factorial space.  Each β-stream is pre-certified to satisfy a
specific moment law (derivative, or integral), ensuring analytic correctness
independent of sampling resolution.

Key design principles
---------------------
• **Exact combinatorics:** factorial and Fibonacci ladders are exact integers;
  β-coefficients are rational and cacheable.
• **Adaptive precision:** each term grows its own decimal precision budget based on
  coefficient magnitude, factorial growth, and offset scale.
• **Stability:** all summations use magnitude sorting and Kahan compensation.
• **Determinism:** same inputs always produce the same outputs, regardless of precision
  context.
• **Purity:** the engine never uses closed-form identities or analytic shortcuts; every
  result is obtained by constructive execution of the factorial structure itself.

This module is the locus where calculus becomes an I/O process — β-streams supply the
infinite exact structure, and the engine's adaptive contraction turns it into numeric
output.  Precision is only a window into that underlying infinity.
"""

from ._rational import Fraction, RATIONAL_TYPES

from math import factorial, log10
from typing import Callable, Dict, List, Tuple, Optional, Union
from mpmath import mp
import time
import warnings
from . import certificates as phi_certs
from .betas import beta_operator_fractions
from .fib import fib_ladder
from .evals import _eval_deltaF_adaptive, _eval_symF_adaptive
from .precision import (
    _digits_fraction_abs, _digits_factorial_int, _digits_from_h
)
from .phi_engine_config import PhiEngineConfig, DEFAULT_FIB_COUNT


# ---------- Engine ----------

class PhiEngine:
    """
    The executable runtime of the φ-Calculus.

    `PhiEngine` is a precision-adaptive evaluator that contracts β-streams
    with user-supplied analytic functions.  It supports evaluation, differentiation,
    and integration — all driven purely by factorial structure, never
    by grid or mesh.

    Each operator call draws its coefficients from exact rational β-streams determined
    by the Fibonacci factorial ladder.  These encode the entire analytic moment law
    for the operation, guaranteeing convergence without approximation theory.
    """

    def __init__(self, config: Optional[PhiEngineConfig] = None):
        self._beta_cache: Dict[Tuple[str, int], List[Fraction]] = {}
        if config:
            self._config: PhiEngineConfig = config
        else:
            self._config = PhiEngineConfig()

        # Validate fibonacci input
        if self._config.fib_count < 2:
            raise ValueError("fib_count must be > 1")

        self._fib_cert_warning_emitted = False  # to avoid repeated warnings
        self._last_execution_summary: Optional[Dict] = None

    def set_config(self, cfg: "PhiEngineConfig") -> None:
        self._config = cfg

    @property
    def config(self):
        return self._config

    def _start_timer(self, force_timing: bool = False):
        if force_timing or self._config.timing:
            return time.perf_counter()
        return None

    @staticmethod
    def _stop_timer(t0):
        if t0 is None:
            return None
        return time.perf_counter() - t0

    def _maybe_wrap_result(self, result, fib_count, order, used_dps_list, needed_dps_list, t0, beta_time, ladder_len=None,
                           certify=False, moment=None, name=None):
        """Attach diagnostics if enabled; otherwise return the bare result.
        :param order:
        """
        if not self._config.return_diagnostics and not certify:
            return result

        if not self._config.return_diagnostics and moment:
            cert = self.emit_cert(moment=moment, fib_count=fib_count, order=order)
            return result, cert

        # ---- build diagnostics defaults ----
        diag = {
            "fib_count": fib_count,
            "beta_time": beta_time,
            "terms": ladder_len if ladder_len else len(used_dps_list),
            "used_dps_list": list(used_dps_list),
            "needed_dps_list": list(needed_dps_list),
            "used_dps_max": max(used_dps_list) if used_dps_list else self._config.base_dps,
            "used_dps_min": min(used_dps_list) if used_dps_list else self._config.base_dps,
            "used_dps_avg": sum(used_dps_list) / len(used_dps_list) if used_dps_list else self._config.base_dps,
            "hit_ceiling": any(d >= self._config.max_dps for d in used_dps_list),
            "timing_s": self._stop_timer(t0),
            "function": name if name else ""
        }

        if self._last_execution_summary is not None:
            diag["execution"] = self._last_execution_summary

        if not certify:
            return result, diag

        if moment:
            cert = self.emit_cert(moment=moment, fib_count=fib_count, order=order)
            return result, diag, cert

        return result, diag

    def report(self, diag: dict | None = None, batch: bool = False, verbose: bool = False, all_mode: bool = False, title=None) -> None:
        """
        Print a compact diagnostic report from the supplied diagnostics.
        If config.show_error is True and 'error' is present in diag,
        prints the absolute error using display_digits for formatting.
        • If given a single dict (default), prints the standard detailed box.
        • If given a list of dicts or batch=True, prints a compact summary table.
        • If given a list of dicts and all_mode=True, prints a compact summary table of all ops.
        """
        if diag is None:
            print("No diagnostics available. Enable return_diagnostics=True in config.")
            return

        n = getattr(self._config, "display_digits", 12)

        def _fmt_result(v):
            try:
                return mp.nstr(v, n=n)
            except Exception:
                try:
                    return f"{float(v):.{n}g}"
                except Exception:
                    return str(v)

        def _fmt_sci(v):
            """Format numeric v in scientific notation, truncated to `display_digits` sig figs."""
            try:
                f = float(v)
                if f != 0.0:
                    return f"{f:.{n}e}"
                # float underflowed to zero but v might not actually be zero
                if v != 0:
                    return mp.nstr(v, n, strip_zeros=False)
                return f"{0.0:.{n}e}"
            except Exception:
                return str(v)

        # ---------- unified all_mode (value + derivative + integral) ----------
        if all_mode:
            if not isinstance(diag, list):
                print("φ-Engine all-mode requires a list of diagnostics.")
                return

            diags = diag  # Expecting exactly [d_val, d_der, d_int]
            if len(diags) != 2:
                print("φ-Engine all-mode expects exactly three diagnostics.")
                return

            terms_hdr = diags[0].get("fib_count", "?") - 1

            # assume order: 0=value, 1=derivative, 2=integral
            rows = [
                ("derivative", diags[0].get("result"), diags[0]),
                ("integral", diags[1].get("result"), diags[1]),
            ]

            print("\n" + "=" * 70)
            print(f"φ-Engine Unified Report ({terms_hdr}-term factorial ladder)")
            print("=" * 70)

            # pull shared metadata from first diag
            d0 = diags[0]
            fname = d0.get("function", "")
            a = d0.get("interval", "").strip()[1:-1].split(',')[0] if "interval" in d0 else None
            b = d0.get("interval", "").strip()[1:-1].split(',')[1] if "interval" in d0 else None

            print(f"Function     : {fname}")
            if "x0" in d0:
                print(f"x0           : {d0['x0']}")
            if a is not None and b is not None:
                print(f"Interval     : [{a}, {b}]")
            print(f"Fib count    : {d0.get('fib_count', '?')}")

            # User-defined header keys
            header_keys = getattr(self._config, "header_keys", ())
            if header_keys:
                for key in header_keys:
                    vals = {d.get(key) for (_, _, d) in rows if key in d}
                    if not vals:
                        continue
                    hdr_val = next(iter(vals)) if len(vals) == 1 else "Mixed"
                    label = key.replace("_", " ").capitalize()
                    print(f"{label:16}: {hdr_val}")

            print("-" * 70)

            any_err = any("error" in d for (_, _, d) in rows)

            # table header
            if any_err:
                print(f"{'Operator':12} {'Result':20} {'dps':>6} {'Cap':>4} {'φ-time(s)':>10} {'AbsErr':>14}")
            else:
                print(f"{'Operator':12} {'Result':20} {'dps':>6} {'Cap':>4} {'φ-time(s)':>10}")

            print("-" * 70)

            # table rows
            for label, result, d in rows:
                dps_used = d.get("used_dps_max", "?")
                cap = "Y" if d.get("hit_ceiling", False) else "N"
                t = d.get("timing_s", 0.0)
                t_s = f"{float(t):.6f}" if t is not None else "    n/a   "

                if any_err:
                    err = d.get("error", "")
                    err_fmt = _fmt_sci(err) if err != "" else ""
                    print(f"{label:12} {_fmt_result(result):20} {dps_used:>6} {cap:>4} {t_s:>10} {err_fmt:>14}")
                else:
                    print(f"{label:12} {_fmt_result(result):20} {dps_used:>6} {cap:>4} {t_s:>10}")

            if not self._config.suppress_guarantee:
                print(self._phi_guarantee(diags[0].get("fib_count", "?")))

            print("=" * 70 + "\n")
            return

        # ---------- batch mode ----------
        if batch or isinstance(diag, list):
            diags = diag if isinstance(diag, list) else [diag]
            if not diags:
                print("No diagnostic entries to report.")
                return
            first = diags[0]
            colw = self._config.report_col_width
            FUNC_W = 24
            X0_W = 8
            TIME_W = 10
            RESULT_W = colw
            ERR_W = colw
            alt_timing_key = None
            alt_timing_label = None
            for k in first.keys():
                if k.startswith("timing_s_alt_"):
                    alt_timing_key = k
                    suffix = k[len("timing_s_alt_"):]
                    alt_timing_label = f"{suffix}(s)"
                    break

            have_alt_time = alt_timing_key is not None

            have_x0 = any("x0" in d for d in diags)
            terms_hdr = diags[0].get("fib_count", "?") - 1

            show_err = getattr(self._config, "show_error", True)

            # ---------- build sample header conditionally ----------
            header_parts = [f"{'Function':{FUNC_W}}"]
            if have_x0:
                header_parts.append(f"{'x0':>{X0_W}}")
            header_parts.append(f"{'φ-time(s)':>{TIME_W}}")
            if have_alt_time:
                header_parts.append(f"{alt_timing_label:>10}")
            header_parts.append(f"{'Result':>{RESULT_W}}")
            if show_err:
                header_parts.append(f"{'AbsErr':>{ERR_W}}")
            sample_header = " ".join(header_parts)

            border = "=" * (len(sample_header)+4)
            dashborder = "-" * (len(sample_header)+4)

            print(border)
            if not title:
                print(f"φ-Engine Batch Diagnostic Summary  ({terms_hdr}-term factorial ladder)")
            else:
                print(f"{title}")
            print(border)

            # Operation / Interval summary (aggregate; "Mixed" if not uniform)
            ops = {d.get("operation", "N/A") for d in diags}
            op_hdr = next(iter(ops)) if len(ops) == 1 else "Mixed"
            intervals = {d.get("interval", None) for d in diags if "interval" in d}
            int_hdr = next(iter(intervals)) if len(intervals) == 1 else ("Mixed" if intervals else None)

            print()
            print(f"Operation: {op_hdr}")
            if int_hdr is not None:
                print(f"Interval: {int_hdr}")

            header_keys = getattr(self._config, "header_keys", ())
            for key in header_keys:
                vals = {d.get(key) for d in diags if key in d}
                if not vals:
                    continue
                hdr_val = next(iter(vals)) if len(vals) == 1 else "Mixed"
                label = key.replace("_", " ").capitalize()
                print(f"{label}: {hdr_val}")

            print()

            if verbose:
                header = (
                    f"{'Function':{FUNC_W}} "
                    + (f"{'x0':>{X0_W}} " if have_x0 else "")
                    + f"{'Terms':>5} {'dps(min/avg/max)':>20} {'Cap':>4} "
                    + f"{'φ-time(s)':>{TIME_W}}"
                )
            else:
                if have_alt_time:
                    header = (
                        f"{'Function':{FUNC_W}} "
                        + (f"{'x0':>{X0_W}} " if have_x0 else "")
                        + f"{'φ-time(s)':>{TIME_W}} {f'{alt_timing_label}':>10} "
                        + f"{'Result':>{RESULT_W}}"
                        + (f" {'AbsErr':>{ERR_W}}" if show_err else "")
                    )
                else:
                    header = (
                        f"{'Function':{FUNC_W}} "
                        + (f"{'x0':>{X0_W}} " if have_x0 else "")
                        + f"{'φ-time(s)':>{TIME_W}} "
                        + f"{'Result':>{RESULT_W}}"
                        + (f" {'AbsErr':>{ERR_W}}" if show_err else "")
                    )
            # ------------------------------------------------

            print(dashborder)
            print(header)
            print(dashborder)

            for d in diags:
                func_full = d.get("function", "N/A")
                if len(func_full) > FUNC_W:
                    print(func_full)
                    func = ""
                else:
                    func = func_full

                row = [f"{func:{FUNC_W}}"]

                if have_x0:
                    x0_val = d.get("x0", "")
                    row.append(f"{str(x0_val):>{X0_W}}")

                time_phi = float(d.get("timing_s", 0.0))
                time_phi_str = f"{time_phi:.6f}"

                time_alt_str = ""
                if have_alt_time:
                    for k in d.keys():
                        if k.startswith("timing_s_alt_"):
                            alt_time = float(d.get(k, 0.0))
                            time_alt_str = f"{alt_time:.6f}"
                            break
                    else:
                        time_alt_str = "?"
                result = _fmt_result(d.get("result", ""))
                err = _fmt_sci(d.get("error")) if "error" in d else ""

                if verbose:
                    terms = str(d.get("terms", "?"))
                    dps_min = d.get("used_dps_min", "?")
                    dps_avg = d.get("used_dps_avg", "?")
                    dps_max = d.get("used_dps_max", "?")
                    dps_str = f"{dps_min}/{int(dps_avg)}/{dps_max}"
                    cap = "Y" if d.get("hit_ceiling", False) else "N"

                    row.append(f"{terms:>5} {dps_str:>20} {cap:>4}")
                    if have_alt_time:
                        row.append(f"{time_phi_str:>{TIME_W}} {time_alt_str:>10}")
                    else:
                        row.append(f"{time_phi_str:>{TIME_W}}")

                else:
                    if have_alt_time:
                        row.append(f"{time_phi_str:>{TIME_W}} {time_alt_str:>10}")
                    else:
                        row.append(f"{time_phi_str:>{TIME_W}}")

                row.append(f"{result:>{RESULT_W}}")
                if show_err:
                    row.append(f"{err:>{ERR_W}}")

                print(" ".join(row))

            if not self._config.suppress_guarantee:
                print(dashborder)
                print(self._phi_guarantee(diags[0].get("fib_count", "?")))

            print(border)
            return


        # ---------- single diagnostic ----------

        # Dynamic header key printing
        header_keys = getattr(self._config, "header_keys", ())
        labels = [
            key.replace("_", " ").capitalize()
            for key in header_keys
            if key in diag
        ]

        FIELD_WIDTH = 18  # maybe make this editable later?

        # Compute dynamic width (so headers align with the built-in ones)
        max_label_width = max([FIELD_WIDTH] + [len(label) for label in labels])
        print("=" * 70)
        print("φ-Engine Diagnostic Report")
        print("=" * 70)
        # Print keys with aligned formatting
        for key in header_keys:
            if key not in diag:
                continue
            label = key.replace("_", " ").capitalize()
            val = diag[key]
            print(f"{label:<{max_label_width}} : {val}")

        print(f"Operation          : {diag.get('operation', 'N/A')}")
        if "interval" in diag:
            print(f"Interval           : {diag['interval']}")
        if "function" in diag:
            print(f"Function           : {diag['function']}")
        if "result" in diag:
            print(f"Result             : {_fmt_result(diag['result'])}")
        print(f"Fib Number         : {diag.get('fib_count', '?')}")
        print(f"Terms evaluated    : {diag.get('terms', '?')}")
        print(f"Max used precision : {diag.get('used_dps_max', '?')} dps")
        hit = diag.get("hit_ceiling", False)
        print(f"Hit precision cap  : {'Yes' if hit else 'No'}")
        t = diag.get("timing_s", None)
        if t is not None:
            try:
                print(f"Total time         : {float(t):.6f} s")
            except Exception:
                print(f"Total time         : {t} s")
        alt_timing_key = None
        alt_timing_label = None
        alt_time = None
        for k in diag.keys():
            if k.startswith("timing_s_alt_"):
                alt_timing_key = k
                suffix = k[len("timing_s_alt_"):]
                alt_timing_label = f"{suffix}(s)"
                alt_time = diag.get(k, 0.0)
                break
        if alt_timing_key is not None and alt_timing_label is not None:
            try:
                print(f"{alt_timing_label}      : {float(alt_time):.6f} s")
            except Exception:
                print(f"{alt_timing_label}      : {alt_time} s")
        if getattr(self._config, "show_error", True) and "error" in diag:
            print(f"Absolute error     : {_fmt_sci(diag['error'])}")
        if not self._config.suppress_guarantee:
            print("-" * 50)
            print(self._phi_guarantee(diag.get('fib_count', '?')))

        print("=" * 70)


    def get_betas(self, kind: str, fib_count: int, order: int = 1) -> Tuple[List[Fraction], int]:
        """
        Retrieve or compute a β-stream of exact Fractions for the given mode, order,
        and Fibonacci depth.

        Parameters
        ----------
        kind : str
            One of {"derivative", "integral"}.
        fib_count : int
            Number of Fibonacci factorial layers to include (requested).
        order : int, optional
            Operator order. For now:
              - derivative, integral: order >= 1 allowed

        Returns
        -------
        (List[Fraction], int)
            Exact rational β-coefficients satisfying the chosen moment law,
            and the effective fib_count actually used (after cert logic).
        """

        # Certificate-based path: fib_count may be overridden (if default) or constrained (if explicit)
        if self._config.beta_source == "cert" and self._config.cert_path:
            loaded = phi_certs.load_cert(self._config.cert_path)
            phi_certs.verify_hash(loaded)

            if self._config.ensure_moments:
                phi_certs.verify_moments(loaded)

            cert_fib_count = loaded.fib_count

            # Call-level fib_count == default → treat as "no opinion, defer to cert"
            if fib_count == DEFAULT_FIB_COUNT:
                if (not self._fib_cert_warning_emitted
                        and cert_fib_count != DEFAULT_FIB_COUNT):
                    warnings.warn(
                        f"\nfib_count={DEFAULT_FIB_COUNT} is the engine default.\n"
                        f"Certificate fib_count={cert_fib_count} is authoritative in cert mode "
                        f"and will be used.",
                        UserWarning,
                        stacklevel=2,
                    )
                    self._fib_cert_warning_emitted = True
                effective_fib_count = cert_fib_count

            # Caller explicitly set fib_count → must match cert
            elif fib_count != cert_fib_count:
                raise ValueError(
                    f"Requested fib_count={fib_count} does not match "
                    f"certificate fib_count={cert_fib_count}.\nCertificate is authoritative."
                )
            else:
                # Explicit fib_count that matches cert
                effective_fib_count = fib_count

            key = (kind, order, effective_fib_count)
            if key in self._beta_cache:
                return self._beta_cache[key], effective_fib_count

            betas = phi_certs.betas_from_cert(loaded)
            self._beta_cache[key] = betas
            return betas, effective_fib_count

        # -- Default compute mode (no cert) --
        key = (kind, order, fib_count)
        if key in self._beta_cache:
            return self._beta_cache[key], fib_count

        ops = beta_operator_fractions(fib_count, order=order)
        self._beta_cache[key] = ops[kind]
        return self._beta_cache[key], fib_count

    def differentiate(self,
                      F_eval,  # Callable[[mp.mpf], mp.mpf]
                      x0,  # mp.mpf
                      fib_count=None,
                      order: int = 1,
                      certify: bool = False,
                      name=None,
                      force_timing: bool = False,
                      parallel: bool = False,
                      max_workers=None,
                      ):
        """
        Evaluate the factorial derivative f^{(order)}(x₀) via φ–β contraction.

        Each derivative call expands symmetric differences around x₀ with
        factorial-scaled offsets (1/(2·F_i!)). The δ-moment β-stream ensures exact
        cancellation of all even Taylor terms, producing the analytic derivative
        to the requested precision, independent of grid spacing.

        Parameters
        ----------
        F_eval : Callable[[mp.mpf], mp.mpf]
            Target analytic function. Must be thread-safe if parallel=True.
        x0 : mp.mpf
            Point of evaluation.
        fib_count : int, optional
            Fibonacci ladder depth. Defaults to engine configuration.
        order : int
            Derivative order. Default is 1.
        certify : bool
            If True, attaches a φ-certificate proving the contraction.
        name : str, optional
            Name of the differentiated function.
        force_timing : bool
            Forces timing even if disabled in config.
        parallel : bool
            If True, evaluate F at all sample points concurrently.
            Uses ThreadPoolExecutor by default. F must be thread-safe.
        max_workers : int, optional
            Maximum parallel workers. None = auto (CPU count).

        Returns
        -------
        mp.mpf
            The contracted analytic derivative at x₀.
        (mp.mpf, dict)
            If return_diagnostics=True, also returns diagnostic metadata.
        (mp.mpf, dict, PhiCert)
            If certify=True, returns the derivative, diagnostics, and certificate.

        Notes
        -----
        The only source of inexactness is mp.mpf input/output. The β-contraction
        itself is exact to all orders permitted by fib_count.

        Thread Safety
        -------------
        When parallel=True, F is called from multiple threads simultaneously.
        Ensure F has no shared mutable state. Pure mpmath functions are safe.
        """
        if parallel:
            from ._parallel_ops import differentiate_parallel
            return differentiate_parallel(
                self, F_eval, x0, fib_count, order,
                certify, name, force_timing, max_workers
            )
        else:
            return self._differentiate_sequential(
                F_eval, x0, fib_count, order, certify, name, force_timing
            )

    def integrate(self,
                  F_eval,  # Callable[[mp.mpf], mp.mpf]
                  a,  # Fraction
                  b,  # Fraction
                  fib_count=None,
                  order: int = 1,
                  certify: bool = False,
                  name=None,
                  force_timing: bool = False,
                  dyadic_depth: int = 0,
                  parallel: bool = False,  # NEW
                  max_workers=None,  # NEW
                  ):
        """
        Evaluate the r-th iterated integral of f on [a,b] via φ–β contraction.

        For order r, computes:
            F^{(r)}(b) = (1/(r-1)!) ∫_a^b (b-t)^{r-1} f(t) dt

        by applying the order-1 φ-integrator to the Cauchy-weighted function
        g(t) = (b-t)^{r-1} f(t).

        Parameters
        ----------
        F_eval : Callable[[mp.mpf], mp.mpf]
            Target analytic function. Must be thread-safe if parallel=True.
        a, b : Fraction
            Exact rational interval endpoints.
        fib_count : int, optional
            Fibonacci ladder depth. Defaults to engine configuration.
        order : int
            Integral order (r). Default is 1.
        certify : bool
            If True, attaches a φ-certificate proving the contraction.
        name : str, optional
            Name of the integrated function.
        force_timing : bool
            Forces timing even if disabled in config.
        dyadic_depth : int
            If > 0, tile [a,b] into 2^dyadic_depth equal dyadic subintervals.
        parallel : bool
            If True, evaluate F at all sample points concurrently.
            For dyadic_depth > 0, all panels × layers are parallelized.
        max_workers : int, optional
            Maximum parallel workers. None = auto (CPU count).

        Returns
        -------
        mp.mpf | (mp.mpf, dict) | (mp.mpf, dict, PhiCert)

        Thread Safety
        -------------
        When parallel=True, F is called from multiple threads simultaneously.
        Ensure F has no shared mutable state.
        """
        if parallel:
            from ._parallel_ops import integrate_parallel
            return integrate_parallel(
                self, F_eval, a, b, fib_count, order,
                certify, name, force_timing, dyadic_depth, max_workers
            )
        else:
            return self._integrate_sequential(
                F_eval, a, b, fib_count, order, certify, name, force_timing, dyadic_depth
            )


    def _differentiate_sequential(self,
                                  F_eval: Callable[[mp.mpf], mp.mpf],
                                  x0: mp.mpf,
                                  fib_count: Optional[int] = None,
                                  order: int = 1,
                                  certify: bool = False,
                                  name: Optional[str] = None,
                                  force_timing: bool = False,
                                  ) -> Union[mp.mpf, Tuple[mp.mpf, dict], Tuple[mp.mpf, dict, phi_certs.PhiCert]]:
        """
        Sequential Differentiation Path
        """
        if fib_count is None:
            fib_count = self._config.fib_count

        # --- Global β synthesis (timed only if uncached) ---
        key = ("derivative", order, fib_count)
        beta_time = 0.0
        key_in_cache = key in self._beta_cache
        t_beta0 = None  # IDEs are annoying
        if not key_in_cache:
            t_beta0 = time.time()

        betas, fib_count = self.get_betas("derivative", fib_count, order)

        if not key_in_cache:
            beta_time = time.time() - t_beta0

        # --- begin timer on calculus loop ---
        t0 = self._start_timer(force_timing=force_timing)
        used_dps_list = []
        needed_dps_list = []
        fibs = fib_ladder(fib_count)
        terms: List[mp.mpf] = []

        x0_mp = mp.mpf(x0)
        for idx, f in enumerate(fibs):
            m_int = factorial(f)
            m_frac = Fraction(m_int, 1)
            h_frac = Fraction(1, 2) / m_frac  # h = 1/(2m)

            # precision budgeting
            if self._config.per_term_guard:
                digits_beta = _digits_fraction_abs(betas[idx])
                digits_m = _digits_factorial_int(m_int)
                digits_h = _digits_from_h(h_frac)

                # One extra h-scale for even-lane second difference
                parity_cost = digits_h if (order % 2 == 0) else 0

                margin = 30
                needed_dps = min(
                    self._config.max_dps,
                    max(
                        self._config.base_dps,
                        digits_beta + digits_m + digits_h + parity_cost + margin
                    )
                )
            else:
                needed_dps = self._config.base_dps
            needed_dps_list.append(needed_dps)

            # ΔF adaptive
            deltaF, used_dps = _eval_deltaF_adaptive(
                F_eval,
                x0_mp,
                h_frac,
                start_dps=needed_dps,
                max_dps=self._config.max_dps,
                dps_step=self._config.dps_step,
                order=order
            )
            # Honor user base_dps setting incase no guard
            lifetime_dps = max(self._config.base_dps, used_dps)
            used_dps_list.append(lifetime_dps)

            with mp.workdps(lifetime_dps):
                beta_mp = mp.mpf(betas[idx].numerator) / mp.mpf(betas[idx].denominator)
                h_mp = mp.mpf(h_frac.numerator) / mp.mpf(h_frac.denominator)
                if order % 2 == 1:
                    norm = mp.mpf('1') / (2 * h_mp)
                else:
                    norm = mp.mpf('1') / (h_mp * h_mp)

                term = beta_mp * (norm * deltaF)
            terms.append(term)

        max_used = max(used_dps_list) if used_dps_list else self._config.base_dps

        with mp.workdps(max_used):
            # sort + Kahan sum
            terms.sort(key=abs)
            _zero = terms[0] * 0 if terms else mp.mpf('0')
            total = _zero
            c = +_zero
            for term in terms:
                y = term - c
                t = total + y
                c = (t - total) - y
                total = t

        return self._maybe_wrap_result(total, fib_count, order, used_dps_list, needed_dps_list, t0, beta_time, certify=certify,
                                       moment="derivative", name=name)


    def _integrate_sequential(self,
                              F_eval: Callable[[mp.mpf], mp.mpf],
                              a: Fraction,
                              b: Fraction,
                              fib_count: int = None,
                              order: int = 1,
                              certify: bool = False,
                              name: Optional[str] = None,
                              force_timing: bool = False,
                              dyadic_depth: int = 0,
                              ) -> Union[mp.mpf, Tuple[mp.mpf, dict], Tuple[mp.mpf, dict, phi_certs.PhiCert]]:
        """
        Sequential Integral Path.
        """
        if not isinstance(a, RATIONAL_TYPES):
            raise TypeError(f"Integration bound 'a' must be a rational (Fraction/mpq), got {type(a)}")
        if not isinstance(b, RATIONAL_TYPES):
            raise TypeError(f"Integration bound 'b' must be a rational (Fraction/mpq), got {type(b)}")
        if dyadic_depth < 0:
            raise ValueError("dyadic_depth must be >= 0")
        if order < 1:
            raise ValueError("order must be >= 1")

        if fib_count is None:
            fib_count = self._config.fib_count

        # --- β synthesis for ORDER-1 integration only ---
        # Higher-order integration is reduced to order-1 via Cauchy kernel
        t_beta0 = time.time()
        betas, fib_count = self.get_betas("integral", fib_count, 1)  # Always order 1
        beta_time = time.time() - t_beta0

        t0 = self._start_timer(force_timing=force_timing)
        fibs = fib_ladder(fib_count)
        base_dps = self._config.base_dps

        # Convert global endpoint to mpf once
        b_mp_global = mp.mpf(b.numerator) / mp.mpf(b.denominator)

        def _make_cauchy_weighted(f_eval, b_global_mp, r):
            """
            Return g(t) = (b - t)^{r-1} * f(t)

            For r=1, this is just f(t).
            """
            if r == 1:
                return f_eval

            def g(t):
                kernel = (b_global_mp - t) ** (r - 1)
                return kernel * f_eval(t)

            return g

        # Wrap the function with the Cauchy kernel
        G_eval = _make_cauchy_weighted(F_eval, b_mp_global, order)

        def _integrate_single_order1(a_frac: Fraction,
                                     b_frac: Fraction,
                                     F_func: Callable
                                     ) -> Tuple[mp.mpf, List[int], List[int]]:
            """
            Standard order-1 φ-integrator on [a_frac, b_frac].
            """
            used_dps_list: List[int] = []
            needed_dps_list: List[int] = []

            mid = (a_frac + b_frac) / 2
            width = b_frac - a_frac
            terms: List[mp.mpf] = []

            with mp.workdps(base_dps):
                x0_mp = mp.mpf(mid.numerator) / mp.mpf(mid.denominator)

                for idx, f in enumerate(fibs):
                    m_int = factorial(f)
                    m_frac = Fraction(m_int, 1)
                    h_frac = width / (2 * m_frac)

                    if self._config.per_term_guard:
                        digits_beta = _digits_fraction_abs(betas[idx])
                        digits_m = _digits_factorial_int(m_int)
                        margin = 30
                        needed_dps = min(
                            self._config.max_dps,
                            max(self._config.base_dps, digits_beta + digits_m + margin)
                        )
                    else:
                        needed_dps = self._config.base_dps
                    needed_dps_list.append(needed_dps)

                    # Order-1: even lane (symmetric sum)
                    symF, used_dps = _eval_symF_adaptive(
                        F_func, x0_mp, h_frac, 1,
                        start_dps=needed_dps,
                        max_dps=self._config.max_dps,
                        dps_step=self._config.dps_step,
                    )
                    used_dps_list.append(used_dps)

                    with mp.workdps(used_dps):
                        beta_mp = mp.mpf(betas[idx].numerator) / mp.mpf(betas[idx].denominator)
                        scale = mp.mpf("1") / 2
                        term = beta_mp * scale * symF
                    terms.append(term)

            max_used = max(used_dps_list) if used_dps_list else base_dps
            with mp.workdps(max_used):
                terms.sort(key=abs)
                _zero = terms[0] * 0 if terms else mp.mpf('0')
                subtotal = _zero
                c_kahan = +_zero
                for term in terms:
                    y = term - c_kahan
                    t = subtotal + y
                    c_kahan = (t - subtotal) - y
                    subtotal = t

                width_mp = mp.mpf(width.numerator) / mp.mpf(width.denominator)
                subtotal *= width_mp  # Order-1 scaling

            return subtotal, used_dps_list, needed_dps_list

        # --- Single panel ---
        if dyadic_depth == 0:
            raw_integral, used_dps_list, needed_dps_list = _integrate_single_order1(a, b, G_eval)

            # Apply Cauchy normalization: divide by (r-1)!
            with mp.workdps(max(used_dps_list) if used_dps_list else base_dps):
                total = raw_integral / mp.factorial(order - 1)

            return self._maybe_wrap_result(total, fib_count, order, used_dps_list, needed_dps_list, t0, beta_time=beta_time,
                                           ladder_len=fib_count - 1, certify=certify, moment="integral", name=name)

        # --- Dyadic tiling ---
        N_panels = 1 << dyadic_depth
        panel_width = (b - a) / N_panels

        panel_results: List[mp.mpf] = []
        used_dps_all: List[int] = []
        needed_dps_all: List[int] = []

        for j in range(N_panels):
            a_j = a + j * panel_width
            b_j = a_j + panel_width
            subtotal, used_list, needed_list = _integrate_single_order1(a_j, b_j, G_eval)
            panel_results.append(subtotal)
            used_dps_all.extend(used_list)
            needed_dps_all.extend(needed_list)

        max_used_global = max(used_dps_all) if used_dps_all else base_dps
        with mp.workdps(max_used_global):
            panel_results.sort(key=abs)
            _zero = panel_results[0] * 0 if panel_results else mp.mpf('0')
            total_global = _zero
            c_kahan = +_zero
            for val in panel_results:
                y = val - c_kahan
                t = total_global + y
                c_kahan = (t - total_global) - y
                total_global = t

            # Apply Cauchy normalization
            total_global /= mp.factorial(order - 1)

        return self._maybe_wrap_result(total_global, fib_count, order, used_dps_all, needed_dps_all, t0, beta_time, len(fibs),
                                       certify=certify, moment="integral", name=name)

    def compare(self, operation, F_eval, x0=None, a=None, b=None, dyadic_depth=0, dps=None, name=None, tol=None):
        """
        Compare a φ-Engine operator against a high-precision mpmath oracle,
        timing both and reporting error + speedup.

        Parameters
        ----------
        operation : {"differentiate", "integrate"}
            Which φ-operator to compare.
        F_eval : Callable[[mp.mpf], mp.mpf]
            Analytic function to evaluate.
        x0 : mp.mpf, optional
            Point for differentiation.
        a, b : Fraction or float, optional
            Bounds for integration.
        dps : int, optional
            Working precision for the *oracle* (mpmath). Defaults to
            max(config.base_dps, 50).
        name : str, optional
            Friendly function name for printing.
        tol : mp.mpf or float, optional
            Absolute-error tolerance to decide "Match" vs "Deviation".
        dyadic_depth : int, optional
            Number of dyadic panels to partition the integral

        Returns
        -------
        (phi_value, oracle_res, abs_err, rel_err, ok)
            Comparison results against a high-precision mpmath oracle
        """

        # ----- format helpers --------

        def fmt_sci(x):
            """Scientific notation for mpf with fixed digits."""
            return mp.nstr(x, n=self._config.display_digits, strip_zeros=False)

        def fmt(x):
            """Fixed-width decimal for mpf."""
            return mp.nstr(x, n=self._config.display_digits)

        # ----- determine oracle_res -------
        mp.dps = max(dps, 50)
        if operation == "differentiate":
            if x0 is None:
                raise ValueError("x0 is required for differentiation.")
            t_oracle_0 = time.perf_counter()
            oracle_res = mp.diff(F_eval, x0)
            t_oracle = time.perf_counter() - t_oracle_0
            phi, diag = self.differentiate(F_eval, x0, name=name, force_timing=True)

        elif operation == "integrate":
            if a is None or b is None:
                raise ValueError("a,b required for integration.")

            # convert Fractions -> mp.mpf for mpmath.quad
            def to_mp(x):
                if isinstance(x, Fraction):
                    return mp.mpf(x.numerator) / mp.mpf(x.denominator)
                return mp.mpf(x)

            a_mp = to_mp(a)
            b_mp = to_mp(b)

            # mpmath oracle (oracle_res)
            t_oracle_0 = time.perf_counter()
            oracle_res = mp.quad(F_eval, [a_mp, b_mp])
            t_oracle = time.perf_counter() - t_oracle_0
            phi, diag = self.integrate(F_eval, a, b, dyadic_depth=dyadic_depth, name=name, force_timing=True)

        else:
            raise NotImplementedError("Only 'differentiate' and 'integrate' supported in compare().")

        # ----- compute errors -------
        abs_err = abs(phi - oracle_res)
        rel_err = abs_err / max(1e-50, abs(oracle_res))

        if tol is not None:
            ok = abs_err < tol
        else:
            ok = False

        # ----- pretty print -------
        dd = getattr(self._config, "display_digits", 12)
        phi_time = diag.get("timing_s", '')
        speedup = (t_oracle/phi_time) if phi_time > 0 else float("inf")

        fmt = lambda x: mp.nstr(x, dd)

        print("\n======================================================================")
        print(f"φ-Engine Compare Report — {operation.capitalize()} @ {dps} dps")
        print("======================================================================")

        if operation == "differentiate":
            print(f"Point              : x0 = {fmt(x0)}")
        else:
            print(f"Interval           : [{fmt(a)}, {fmt(b)}]")
        print(f"Function           : {name or ''}")
        print(f"φ-Engine value     : {fmt(phi)}")
        print(f"Truth              : {fmt(oracle_res)}")
        print(f"Absolute error     : {fmt_sci(abs_err)}")
        print(f"Relative error     : {fmt_sci(rel_err)}")
        if tol is not None:
            status = "✓ Match within tolerance" if ok else "⚠ Deviation from tolerance"
            print(f"Status             : {status}")
        print("------------------------------------------------------------------")
        print(f"φ-Engine time      : {phi_time:.6f} s")
        print(f"mpmath time        : {t_oracle:.6f} s")
        if speedup != float("inf"):
            print(f"Speedup (mp/φ)     : {speedup:.3f}×")
        else:
            print(f"Speedup (mp/φ)     : ∞ (φ time ≈ 0)")
        if not self._config.suppress_guarantee:
            print(self._phi_guarantee())
        print("======================================================================\n")

        return phi, oracle_res, abs_err, rel_err, ok

    def all(self,
            F_eval,
            x0,
            a,
            b,
            dps=None,
            name=None,
            force_timing=False,
            dyadic_depth=4
            ):
        """
        Unified φ-operator bundle:
            • f(x0)
            • f'(x0)
            • ∫_a^b f(x) dx

        Behavior:
            • If return_diagnostics=False:
                  returns ONLY numeric results.
            • If return_diagnostics=True:
                  returns (results_dict, diag_list).
                  Use eng.report(diag_list, all_mode=True) to render.

        Parameters
        ----------
        F_eval : callable
            Analytic function.
        x0 : mp.mpf
            Point where value + derivative are evaluated.
        a, b : Fraction
            Integration bounds.
        dps : int or None
            Precision context for mp layer, defaults to base_dps.
        name : str
            Label used in diagnostic printouts.
        force_timing : bool
            Always collect timing even if config.timing=False.
        dyadic_depth : int
            Number of dyadic panels to partition the integral

        Returns
        -------
        If return_diagnostics=False: Dict

        If return_diagnostics=True: Tuple[Dict, List]
        """
        use_dps = dps or self._config.base_dps

        # Compute-only mode (default)
        if not self._config.return_diagnostics:
            with mp.workdps(use_dps):
                der = self.differentiate(F_eval, x0, name=name)
                integ = self.integrate(F_eval, a, b, dyadic_depth=dyadic_depth, name=name)
            return {"derivative": der, "integral": integ}

        with mp.workdps(use_dps):
            der, d_der = self.differentiate(F_eval, x0, name=name, force_timing=force_timing)
            integ, d_int = self.integrate(F_eval, a, b, name=name, dyadic_depth=dyadic_depth, force_timing=force_timing)

        # Attach diagnostics
        d_der["result"] = der
        d_int["result"] = integ

        return ({"derivative": der, "integral": integ},
                [d_der, d_int])


    def emit_cert(self, moment: str, fib_count: int | None = None, order: int = 1):
        """Emit and optionally save a φ-certificate using current config."""
        fib_count = fib_count or self._config.fib_count
        cert = phi_certs.emit_cert_from_engine(self, moment=moment, fib_count=fib_count, order=order)

        # Inject meta
        if self._config.cert_meta:
            cert.meta = {**(cert.meta or {}), **self._config.cert_meta}

        # Compute hash
        root_material = {
            "type": cert.type,
            "moment": cert.moment,
            "fib_count": cert.fib_count,
            "fibs": cert.fibs,
            "order": cert.order,
            "node_formula": cert.node_formula,
            "encoding": cert.encoding,
            "payload": cert.payload,
        }
        cert.hash.root = phi_certs.compute_sha256_hex(root_material)
        mode = self._config.cert_mode
        path = self._config.cert_path
        if mode == "emit" and path:
            phi_certs.save_cert(cert, path, gzip_out=self._config.gzip_cert, verify_roundtrip=True)
        elif mode == "verify" and path:
            try:
                loaded = phi_certs.load_cert(path)
                phi_certs.verify_hash(loaded)
                phi_certs.verify_moments(loaded)
                print(f"✓ Certificate verified: {path}")
            except Exception as e:
                print(f"⚠ Certificate verification failed: {e}")
                # continue execution anyway no error raised
        elif mode == "require" and path:
            try:
                loaded = phi_certs.load_cert(path)
                phi_certs.verify_hash(loaded)
                phi_certs.verify_moments(loaded)
                print(f"✓ Certificate requirement satisfied: {path}")
            except Exception as e:
                raise RuntimeError(
                    f"Required φ-certificate failed verification or missing: {path}"
                ) from e

        return cert


    def _phi_guarantee(self, fib_count: Optional[int] = None) -> str | None:
        if not fib_count:
            fib_count = self._config.fib_count  # None case for compare mode which cannot use certificates
        try:
            N = fib_count - 1
            deg_exact = 2*N - 2
            deg_survive = 2*N - 1

            result = (
                f"φ-structural guarantee:\n"
                f"  • Exact through Taylor degree 2N−2 = {deg_exact}.\n"
                f"  • First possible surviving term: order 2N−1 = {deg_survive}.\n"
                f"  • Higher Taylor terms are killed superfactorially\n    by powers of xᵢ = 1/(F⁺ᵢ!)².\n"
                f"To hide this footer set suppress_guarantee=True in PhiEngineConfig."
            )
        except Exception:
            result = (
                f"φ-structural guarantee: (unavailable, encountered Exception)\n"
                f"To hide this footer set suppress_guarantee=True in PhiEngineConfig."
            )
        return result
