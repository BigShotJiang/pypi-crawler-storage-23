# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
# phi_engine/core/_parallel_ops.py

"""
Parallel-aware differentiation and integration for φ-engine.

Drop-in replacements for sequential differentiate() and integrate()
that support parallel evaluation via the `parallel` flag.

Uses mp.workdps() for thread-safe per-layer precision handling.
"""

from __future__ import annotations

import time
from ._rational import Fraction, RATIONAL_TYPES
from math import factorial
from typing import Callable, Optional, List

from mpmath import mp

from ._parallel import (
    ParallelBackend,
    build_diff_eval_points,
    build_int_eval_points,
    evaluate_parallel_diff,
    evaluate_parallel_int,
    reconstruct_deltaF,
    reconstruct_symF, resolve_backend, EvalCtx, EvalTask, check_cuda_available, _get_cuda_device_name,
    _get_cpu_name,
)

def _to_mpf(x):
    if hasattr(x, "numerator") and hasattr(x, "denominator"):
        try:
            return mp.mpf(x.numerator) / mp.mpf(x.denominator)
        except Exception:
            pass
    if hasattr(x, "p") and hasattr(x, "q"):
        return mp.mpf(int(x.p)) / mp.mpf(int(x.q))
    try:
        return mp.mpf(x)
    except TypeError:
        return mp.mpf(str(x))

def _classify_layers_for_cuda(engine, betas, fibs, order):
    """
    Determine whether each factorial ladder layer can safely be
    evaluated in float64 without destroying β-contracted precision.

    Returns:
        cuda_layers : indices safe for CUDA float64 evaluation
        cpu_layers  : indices requiring arbitrary precision
    """

    FLOAT64_DIGITS = 16
    TARGET = engine._config.target_cuda_digits
    SAFETY = 3

    cuda_layers = []
    cpu_layers = []

    for i, f_val in enumerate(fibs):

        # factorial step size
        m = factorial(f_val)
        h = Fraction(1, 2 * m)

        h_mp = _to_mpf(h)
        beta_abs = _to_mpf(abs(betas[i]))

        # --- amplification cost (β contraction) ---
        # digits lost when scaling ΔF by β/h
        if beta_abs > 0:
            amp_cost = mp.log10(beta_abs / h_mp)
        else:
            amp_cost = mp.mpf("0")

        # --- cancellation cost (Taylor subtraction) ---
        # odd derivative ~ h
        # even derivative ~ h²
        cancel_cost = -mp.log10(h_mp)
        if order % 2 == 0:
            cancel_cost *= 2

        total_cost = float(amp_cost + cancel_cost)

        surviving_digits = FLOAT64_DIGITS - total_cost

        if surviving_digits >= TARGET + SAFETY:
            cuda_layers.append(i)
        else:
            cpu_layers.append(i)

    return cuda_layers, cpu_layers



def differentiate_parallel(
    engine,
    F_eval: Callable,
    x0: mp.mpf,
    fib_count: Optional[int] = None,
    order: int = 1,
    certify: bool = False,
    name: Optional[str] = None,
    force_timing: bool = False,
    max_workers: Optional[int] = None,
):
    """
    Parallel φ-engine differentiation with analytic backend routing.

    - Analytic layer builds evaluation points.
    - Execution planner assigns backend + precision per task.
    - Parallel backend executes grouped batches.
    - Reconstruction and contraction remain backend-agnostic.

    Backward compatible:
        F_eval(x) still works.
        Advanced users may implement F_eval(x, ctx).
    """

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------

    if fib_count is None:
        fib_count = engine._config.fib_count

    key = ("derivative", order, fib_count)
    beta_time = 0.0
    key_in_cache = key in engine._beta_cache

    if not key_in_cache:
        t_beta0 = time.time()

    betas, fib_count = engine.get_betas("derivative", fib_count, order)

    if not key_in_cache:
        beta_time = time.time() - t_beta0

    t0 = engine._start_timer(force_timing=force_timing)

    from .fib import fib_ladder
    from .precision import (
        _digits_fraction_abs,
        _digits_factorial_int,
        _digits_from_h,
    )

    fibs = fib_ladder(fib_count)
    x0_mp = mp.mpf(x0)

    pconf = engine._config.parallel
    if max_workers is None:
        max_workers = pconf.max_workers

    # ------------------------------------------------------------------
    # Phase 1: precision budgets
    # ------------------------------------------------------------------

    needed_dps_list = []
    h_values = []

    for idx, f in enumerate(fibs):
        m_int = factorial(f)
        h_frac = Fraction(1, 2 * m_int)
        h_values.append(h_frac)

        if engine._config.per_term_guard:
            digits_beta = _digits_fraction_abs(betas[idx])
            digits_m = _digits_factorial_int(m_int)
            digits_h = _digits_from_h(h_frac)
            parity_cost = digits_h if (order % 2 == 0) else 0
            margin = 30

            needed_dps = min(
                engine._config.max_dps,
                max(
                    engine._config.base_dps,
                    digits_beta + digits_m + digits_h + parity_cost + margin,
                ),
            )
        else:
            needed_dps = engine._config.base_dps

        needed_dps_list.append(needed_dps)

    # ------------------------------------------------------------------
    # Phase 2: analytic sampling points
    # ------------------------------------------------------------------

    eval_points, _ = build_diff_eval_points(fibs, factorial, order, Fraction)

    # ------------------------------------------------------------------
    # Phase 3: analytic routing → EvalTask (policy-aware)
    # ------------------------------------------------------------------

    policy = getattr(engine._config, "precision_policy", "auto")

    cuda_layers, cpu_layers = _classify_layers_for_cuda(engine, betas, fibs, order)

    eval_tasks = []

    # Enforce Policy
    for ep in eval_points:
        if policy == "strict":
            backend = "cpu"
        elif policy == "fast":
            backend = "cuda"
        else:  # auto hybrid
            backend = "cuda" if ep.layer_idx in cuda_layers else "cpu"

        precision = (
            needed_dps_list[ep.layer_idx]
            if ep.layer_idx >= 0 else None
        )

        eval_tasks.append(
            EvalTask(
                point=ep,
                ctx=EvalCtx(backend=backend, precision=precision),
            )
        )

    # Graceful fallback if CUDA unavailable
    cuda_available = check_cuda_available()
    if not cuda_available:
        for t in eval_tasks:
            if t.ctx.backend == "cuda":
                t.ctx.backend = "cpu"

    # ------------------------------------------------------------------
    # Phase 4: batch routing
    # ------------------------------------------------------------------

    cuda_tasks = [t for t in eval_tasks if t.ctx.backend == "cuda"]
    cpu_tasks = [t for t in eval_tasks if t.ctx.backend != "cuda"]

    # ------------------------------------------------------------------
    # Attach execution diagnostics summary
    # ------------------------------------------------------------------

    engine._last_execution_summary = {
        "policy": policy,
        "cuda_available": cuda_available,
        "cuda_task_count": len(cuda_tasks),
        "cpu_task_count": len(cpu_tasks),

        "environment": {
            "parallel_backend": (
                engine._config.parallel.backend.name
                if engine._config.parallel else None
            ),
            "max_workers": (
                engine._config.parallel.max_workers
                if engine._config.parallel else None
            ),
            "cuda_device": (
                engine._config.parallel.cuda_device
                if engine._config.parallel else None
            ),
            "gpu_name": _get_cuda_device_name(),
            "cpu_name": _get_cpu_name()
        },

        "layers": [
            {
                "layer": t.point.layer_idx,
                "backend": t.ctx.backend,
                "needed_dps": t.ctx.precision,
            }
            for t in eval_tasks
            if t.point.layer_idx >= 0
        ],
    }
    # Execute batches
    lookup = {}

    def _extract_dps_list(tasks):
        dps = [t.ctx.precision for t in tasks if t.point.layer_idx >= 0 and t.ctx.precision is not None]
        return dps if dps else [50]  # safe floor

    if cuda_tasks:
        cuda_results = evaluate_parallel_diff(
            F_eval,
            x0_mp,
            cuda_tasks,
            _extract_dps_list(cuda_tasks),
            max_workers=max_workers,
            backend=ParallelBackend.CUDA_STREAMS,
        )
        for t, val in zip(cuda_tasks, cuda_results):
            lookup[(t.point.layer_idx, t.point.offset_type)] = val

    if cpu_tasks:
        cpu_results = evaluate_parallel_diff(
            F_eval,
            x0_mp,
            cpu_tasks,
            [t.ctx.precision for t in cpu_tasks if t.point.layer_idx >= 0],
            max_workers=max_workers,
            backend=ParallelBackend.THREADPOOL,
        )
        for t, val in zip(cpu_tasks, cpu_results):
            lookup[(t.point.layer_idx, t.point.offset_type)] = val

    # Preserve analytic ordering
    eval_results = [
        lookup[(ep.layer_idx, ep.offset_type)] for ep in eval_points
    ]

    # ------------------------------------------------------------------
    # Phase 5: reconstruction
    # ------------------------------------------------------------------

    deltaF_by_layer = reconstruct_deltaF(
        eval_results, eval_points, order, needed_dps_list
    )

    # ------------------------------------------------------------------
    # Phase 6: β contraction
    # ------------------------------------------------------------------

    used_dps_list = []
    terms = []

    for idx, f in enumerate(fibs):
        h_frac = h_values[idx]
        used_dps = needed_dps_list[idx]
        used_dps_list.append(used_dps)

        deltaF = deltaF_by_layer[idx]

        with mp.workdps(used_dps):
            beta_mp = mp.mpf(betas[idx].numerator) / mp.mpf(betas[idx].denominator)
            h_mp = mp.mpf(h_frac.numerator) / mp.mpf(h_frac.denominator)

            norm = (
                mp.mpf("1") / (2 * h_mp)
                if order % 2 == 1
                else mp.mpf("1") / (h_mp * h_mp)
            )

            terms.append(beta_mp * norm * deltaF)

    # ------------------------------------------------------------------
    # Phase 7: compensated summation
    # ------------------------------------------------------------------

    max_used = max(used_dps_list) if used_dps_list else engine._config.base_dps

    with mp.workdps(max_used):
        terms.sort(key=abs)
        _zero = terms[0] * 0 if terms else mp.mpf("0")
        total = _zero
        c = +_zero
        for term in terms:
            y = term - c
            t_sum = total + y
            c = (t_sum - total) - y
            total = t_sum

    # ------------------------------------------------------------------
    # Final result
    # ------------------------------------------------------------------

    return engine._maybe_wrap_result(total, fib_count, order, used_dps_list, needed_dps_list, t0, beta_time, certify=certify,
                                     moment="derivative", name=name)



def _classify_layers_for_cuda_int(engine, betas, fibs, width):
    """
    Determine whether each factorial ladder layer can safely be
    evaluated in float64 for integration.

    Integration uses the symmetric lane: S = F(mid+h) + F(mid-h).
    No cancellation cost (unlike differentiation's antisymmetric lane).
    The only cost is β amplification.

    Returns:
        cuda_layers : indices safe for CUDA float64 evaluation
        cpu_layers  : indices requiring arbitrary precision
    """

    FLOAT64_DIGITS = 16
    TARGET = engine._config.target_cuda_digits
    SAFETY = 3

    cuda_layers = []
    cpu_layers = []

    for i, f_val in enumerate(fibs):
        m = factorial(f_val)
        m_frac = Fraction(m, 1)
        h = width / (2 * m_frac)

        h_mp = _to_mpf(h)
        beta_abs = _to_mpf(abs(betas[i]))

        # --- amplification cost (β contraction) ---
        # Integration contracts: β * (1/2) * symF
        # The dominant cost is β magnitude
        if beta_abs > 0:
            amp_cost = float(mp.log10(beta_abs))
        else:
            amp_cost = 0.0

        # No cancellation cost for symmetric sum (addition, not subtraction)
        total_cost = max(0.0, amp_cost)

        surviving_digits = FLOAT64_DIGITS - total_cost

        if surviving_digits >= TARGET + SAFETY:
            cuda_layers.append(i)
        else:
            cpu_layers.append(i)

    return cuda_layers, cpu_layers


def integrate_parallel(
    engine,  # PhiEngine instance
    F_eval: Callable[[mp.mpf], mp.mpf],
    a: Fraction,
    b: Fraction,
    fib_count: Optional[int] = None,
    order: int = 1,
    certify: bool = False,
    name: Optional[str] = None,
    force_timing: bool = False,
    dyadic_depth: int = 0,
    max_workers: Optional[int] = None,
):
    """
    Parallel φ-engine integration with analytic backend routing.

    - Analytic layer builds evaluation points per panel.
    - Execution planner assigns backend + precision per task.
    - Parallel backend executes grouped batches (all panels × layers).
    - Reconstruction and contraction remain backend-agnostic.

    Backward compatible:
        F_eval(x) still works.
        Advanced users may implement F_eval(x, ctx).
    """

    # ------------------------------------------------------------------
    # Input validation
    # ------------------------------------------------------------------
    if not isinstance(a, RATIONAL_TYPES):
        raise TypeError(f"Integration bound 'a' must be a rational (Fraction/mpq), got {type(a)}")
    if not isinstance(b, RATIONAL_TYPES):
        raise TypeError(f"Integration bound 'b' must be a rational (Fraction/mpq), got {type(b)}")
    if dyadic_depth < 0:
        raise ValueError("dyadic_depth must be >= 0")
    if order < 1:
        raise ValueError("order must be >= 1")

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------

    if fib_count is None:
        fib_count = engine._config.fib_count

    key = ("integral", 1, fib_count)  # Always order-1 betas for integration
    beta_time = 0.0
    key_in_cache = key in engine._beta_cache

    if not key_in_cache:
        t_beta0 = time.time()

    betas, fib_count = engine.get_betas("integral", fib_count, 1)  # Always order 1

    if not key_in_cache:
        beta_time = time.time() - t_beta0

    t0 = engine._start_timer(force_timing=force_timing)

    from .fib import fib_ladder
    from .precision import _digits_fraction_abs, _digits_factorial_int

    fibs = fib_ladder(fib_count)
    pconf = engine._config.parallel
    if max_workers is None:
        max_workers = pconf.max_workers
    base_dps = engine._config.base_dps

    # Global endpoint for Cauchy kernel
    b_mp_global = mp.mpf(b.numerator) / mp.mpf(b.denominator)

    def _make_cauchy_weighted(f_eval, b_global_mp, r):
        if r == 1:
            return f_eval
        def g(t):
            kernel = (b_global_mp - t) ** (r - 1)
            return kernel * f_eval(t)
        return g

    G_eval = _make_cauchy_weighted(F_eval, b_mp_global, order)

    # ------------------------------------------------------------------
    # Determine panels
    # ------------------------------------------------------------------
    if dyadic_depth == 0:
        panels = [(a, b)]
    else:
        N_panels = 1 << dyadic_depth
        panel_width = (b - a) / N_panels
        panels = [(a + j * panel_width, a + (j + 1) * panel_width) for j in range(N_panels)]

    # ------------------------------------------------------------------
    # Phase 1: precision budgets (first panel defines the layer budget;
    #          all dyadic panels share the same width so budgets are identical)
    # ------------------------------------------------------------------

    first_width = panels[0][1] - panels[0][0]
    needed_dps_list = []
    h_values = []

    for idx, f in enumerate(fibs):
        m_int = factorial(f)
        m_frac = Fraction(m_int, 1)
        h_frac = first_width / (2 * m_frac)
        h_values.append(h_frac)

        if engine._config.per_term_guard:
            digits_beta = _digits_fraction_abs(betas[idx])
            digits_m = _digits_factorial_int(m_int)
            margin = 30
            needed_dps = min(
                engine._config.max_dps,
                max(base_dps, digits_beta + digits_m + margin)
            )
        else:
            needed_dps = base_dps

        needed_dps_list.append(needed_dps)

    # ------------------------------------------------------------------
    # Phase 2: CUDA layer classification (policy-aware)
    # ------------------------------------------------------------------

    policy = getattr(engine._config, "precision_policy", "auto")
    cuda_layers, cpu_layers = _classify_layers_for_cuda_int(engine, betas, fibs, first_width)

    cuda_available = check_cuda_available()

    # ------------------------------------------------------------------
    # Phase 3: build ALL eval tasks across ALL panels
    # ------------------------------------------------------------------

    # Each task carries panel_idx so we can reconstruct per-panel after dispatch
    all_eval_tasks = []       # flat list of (panel_idx, EvalTask)
    panel_eval_counts = []    # how many tasks per panel

    for panel_idx, (a_frac, b_frac) in enumerate(panels):
        width = b_frac - a_frac

        eval_points, _ = build_int_eval_points(fibs, width, factorial, Fraction)

        panel_tasks = []
        for ep in eval_points:
            if policy == "strict":
                backend = "cpu"
            elif policy == "fast":
                backend = "cuda"
            else:  # adaptive
                backend = "cuda" if ep.layer_idx in cuda_layers else "cpu"

            # Graceful CUDA fallback
            if backend == "cuda" and not cuda_available:
                backend = "cpu"

            precision = (
                needed_dps_list[ep.layer_idx]
                if ep.layer_idx >= 0 else None
            )

            task = EvalTask(
                point=ep,
                ctx=EvalCtx(backend=backend, precision=precision),
            )
            panel_tasks.append(task)
            all_eval_tasks.append((panel_idx, task))

        panel_eval_counts.append(len(panel_tasks))

    # Flatten tasks for batch dispatch
    flat_tasks = [t for _, t in all_eval_tasks]

    cuda_tasks = [t for t in flat_tasks if t.ctx.backend == "cuda"]
    cpu_tasks = [t for t in flat_tasks if t.ctx.backend != "cuda"]

    # ------------------------------------------------------------------
    # Attach execution diagnostics summary
    # ------------------------------------------------------------------

    engine._last_execution_summary = {
        "policy": policy,
        "cuda_available": cuda_available,
        "cuda_task_count": len(cuda_tasks),
        "cpu_task_count": len(cpu_tasks),
        "panel_count": len(panels),

        "environment": {
            "parallel_backend": (
                engine._config.parallel.backend.name
                if engine._config.parallel else None
            ),
            "max_workers": (
                engine._config.parallel.max_workers
                if engine._config.parallel else None
            ),
            "cuda_device": (
                engine._config.parallel.cuda_device
                if engine._config.parallel else None
            ),
            "gpu_name": _get_cuda_device_name(),
            "cpu_name": _get_cpu_name()
        },

        "layers": [
            {
                "layer": t.point.layer_idx,
                "backend": t.ctx.backend,
                "needed_dps": t.ctx.precision,
            }
            for t in flat_tasks
            if t.point.layer_idx >= 0
        ][:len(fibs)],  # Only report unique layer dispatch (first panel representative)
    }

    # ------------------------------------------------------------------
    # Phase 4: batch execution — dispatch all panels × layers at once
    # ------------------------------------------------------------------

    # We need per-panel midpoints for the evaluator. Build a mapping
    # from flat task index → panel midpoint.
    panel_midpoints = []
    for a_frac, b_frac in panels:
        mid = (a_frac + b_frac) / 2
        panel_midpoints.append(mp.mpf(mid.numerator) / mp.mpf(mid.denominator))

    # Build flat index → panel_idx mapping
    flat_to_panel = [panel_idx for panel_idx, _ in all_eval_tasks]

    def _extract_dps_list(tasks):
        dps = [t.ctx.precision for t in tasks if t.point.layer_idx >= 0 and t.ctx.precision is not None]
        return dps if dps else [50]

    lookup = {}

    # We need a unique key per task: (flat_index, layer_idx, offset_type)
    # since the same layer_idx+offset_type appears across panels
    flat_cuda_indices = [i for i, t in enumerate(flat_tasks) if t.ctx.backend == "cuda"]
    flat_cpu_indices = [i for i, t in enumerate(flat_tasks) if t.ctx.backend != "cuda"]

    if flat_cuda_indices:
        cuda_task_batch = [flat_tasks[i] for i in flat_cuda_indices]
        cuda_mids = [panel_midpoints[flat_to_panel[i]] for i in flat_cuda_indices]

        # Evaluate each CUDA task with its panel midpoint
        from mpmath import mp as _mp
        max_dps = max(_extract_dps_list(cuda_task_batch))
        original_dps = _mp.dps

        from ._parallel import _make_caller
        call = _make_caller(G_eval)

        def _cuda_worker(args):
            task, mid_mp = args
            ep = task.point
            ctx = task.ctx
            mid_str = str(mid_mp)
            m = _mp.mpf(mid_str)
            h_mp = _mp.mpf(ep.h_frac.numerator) / _mp.mpf(ep.h_frac.denominator)
            if ep.offset_type == 'plus':
                return call(m + h_mp, ctx)
            else:
                return call(m - h_mp, ctx)

        try:
            _mp.dps = max_dps
            from ._parallel import evaluate_parallel
            cuda_results = evaluate_parallel(
                _cuda_worker,
                list(zip(cuda_task_batch, cuda_mids)),
                ParallelBackend.CUDA_STREAMS,
                max_workers,
            )
        finally:
            _mp.dps = original_dps

        for flat_idx, result in zip(flat_cuda_indices, cuda_results):
            lookup[flat_idx] = result

    if flat_cpu_indices:
        cpu_task_batch = [flat_tasks[i] for i in flat_cpu_indices]
        cpu_mids = [panel_midpoints[flat_to_panel[i]] for i in flat_cpu_indices]

        from mpmath import mp as _mp
        max_dps = max(_extract_dps_list(cpu_task_batch))
        original_dps = _mp.dps

        from ._parallel import _make_caller
        call = _make_caller(G_eval)

        def _cpu_worker(args):
            task, mid_mp = args
            ep = task.point
            ctx = task.ctx
            mid_str = str(mid_mp)
            m = _mp.mpf(mid_str)
            h_mp = _mp.mpf(ep.h_frac.numerator) / _mp.mpf(ep.h_frac.denominator)
            if ep.offset_type == 'plus':
                return call(m + h_mp, ctx)
            else:
                return call(m - h_mp, ctx)

        try:
            _mp.dps = max_dps
            from ._parallel import evaluate_parallel
            cpu_results = evaluate_parallel(
                _cpu_worker,
                list(zip(cpu_task_batch, cpu_mids)),
                ParallelBackend.THREADPOOL,
                max_workers,
            )
        finally:
            _mp.dps = original_dps

        for flat_idx, result in zip(flat_cpu_indices, cpu_results):
            lookup[flat_idx] = result

    # ------------------------------------------------------------------
    # Phase 5: reconstruct per-panel and contract
    # ------------------------------------------------------------------

    panel_results: List[mp.mpf] = []
    used_dps_all: List[int] = []
    needed_dps_all: List[int] = []

    flat_offset = 0
    for panel_idx, (a_frac, b_frac) in enumerate(panels):
        width = b_frac - a_frac
        n_tasks = panel_eval_counts[panel_idx]

        # Gather this panel's eval results in order
        panel_eval_results = [lookup[flat_offset + i] for i in range(n_tasks)]

        # Rebuild eval_points for this panel (same structure, needed for reconstruct)
        eval_points, _ = build_int_eval_points(fibs, width, factorial, Fraction)

        # Reconstruct symF
        symF_by_layer = reconstruct_symF(panel_eval_results, eval_points, 1, needed_dps_list)

        # β contraction
        used_dps_list: List[int] = []
        terms: List[mp.mpf] = []

        for idx, f in enumerate(fibs):
            needed_dps = needed_dps_list[idx]
            used_dps_list.append(needed_dps)

            symF = symF_by_layer[idx]

            with mp.workdps(needed_dps):
                beta_mp = mp.mpf(betas[idx].numerator) / mp.mpf(betas[idx].denominator)
                scale = mp.mpf("1") / 2
                term = beta_mp * scale * symF
            terms.append(term)

        # Kahan sum for this panel
        max_used = max(used_dps_list) if used_dps_list else base_dps
        with mp.workdps(max_used):
            terms.sort(key=abs)
            _zero = terms[0] * 0 if terms else mp.mpf('0')
            subtotal = _zero
            c_kahan = +_zero
            for term in terms:
                y = term - c_kahan
                t = subtotal + y
                c_kahan = (t - subtotal) - y
                subtotal = t

            width_mp = mp.mpf(width.numerator) / mp.mpf(width.denominator)
            subtotal *= width_mp

        panel_results.append(subtotal)
        used_dps_all.extend(used_dps_list)
        needed_dps_all.extend(needed_dps_list)

        flat_offset += n_tasks

    # ------------------------------------------------------------------
    # Phase 6: compensated summation across panels + Cauchy normalization
    # ------------------------------------------------------------------

    max_used_global = max(used_dps_all) if used_dps_all else base_dps
    with mp.workdps(max_used_global):
        panel_results.sort(key=abs)
        _zero = panel_results[0] * 0 if panel_results else mp.mpf('0')
        total_global = _zero
        c_kahan = +_zero
        for val in panel_results:
            y = val - c_kahan
            t = total_global + y
            c_kahan = (t - total_global) - y
            total_global = t

        # Cauchy normalization
        total_global /= mp.factorial(order - 1)

    # ------------------------------------------------------------------
    # Final result
    # ------------------------------------------------------------------

    return engine._maybe_wrap_result(total_global, fib_count, order, used_dps_all, needed_dps_all, t0, beta_time, len(fibs),
                                     certify=certify, moment="integral", name=name)
