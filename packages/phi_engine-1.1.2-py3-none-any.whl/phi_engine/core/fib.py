# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/fib.py
"""
Fibonacci ladder generation for factorial node placement.

This module defines the Fibonacci-based indexing scheme that underlies
all φ-Engine constructions. Each ladder [1,2,3,5,8,...] defines the factorial
orders used to compute the evaluation layers xᵢ = 1/(Fᵢ!)². These layers
are not sample points, but structural displacements in the factorial
Golden continuum — fixed anchors for β-stream derivation and contraction.

The ladder length `fib_count` directly controls the resolution and
stability of φ-operations: higher counts produce denser factorial
structure, not more “points.”  These ladders are deterministic, exact,
and purely combinatorial — no floating-point arithmetic is involved or allowed.
"""

from ._rational import Fraction
from typing import List
from math import factorial

def fib_ladder(fib_count: int) -> List[int]:
    """Return shifted Fibonacci ladder [1,2,3,5,...] with length fib_count-1.
    Given fib_count = N (canonical Fibonacci index),
    this returns the first N-1 shifted terms, ending at Fib_N
    i.e. user requests 5th canonical Fibonacci number, engine builds [1,2,3,5].
    """
    fibs = [1, 2]
    shifted = fib_count - 1
    while len(fibs) < shifted:
        fibs.append(fibs[-1] + fibs[-2])
    return fibs[:shifted]

def layers_from_fibs(fibs: List[int]) -> List[Fraction]:
    """x_i = 1/(F_i!)"""
    xs: List[Fraction] = []
    for f in fibs:
        m = factorial(f)
        xs.append(Fraction(1, m*m))
    return xs

if __name__ == "__main__":
    for actual_fib_num in range(2, 9):
        print(fib_ladder(actual_fib_num)[-1])
    print(f"8th actual fib = 21, engine 8th fib {fib_ladder(8)[-1]}")
