# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
# phi_engine/core/_parallel.py

"""
Parallel evaluation backends for φ-engine.

This module provides concurrent evaluation of callable F at multiple sample points.
Uses mp.workdps() for thread-safe precision handling.

Thread Safety:
    F must be thread-safe. For mpmath-based functions, this is typically fine
    since each call creates local mpf values. Functions with internal mutable
    state may produce incorrect results.
"""

from __future__ import annotations

import inspect
import warnings
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from typing import Callable, List, Tuple, Any, Optional, Literal
from dataclasses import dataclass
from enum import Enum, auto
import mpmath as mp
import subprocess
import platform

# ---------------------------------------------------------------------------
# Parallel Backend
# ---------------------------------------------------------------------------

class ParallelBackend(Enum):
    """Available parallel execution backends."""
    THREADPOOL = auto()
    PROCESSPOOL = auto()
    CUDA_STREAMS = auto()

@dataclass
class ParallelConfig:
    """Configuration for parallel evaluation."""
    backend: ParallelBackend = ParallelBackend.THREADPOOL
    max_workers: Optional[int] = None  # None = auto (CPU count)
    cuda_device: int = 0


def _get_cpu_name():
    # Windows: query WMI
    if platform.system() == "Windows":
        try:
            out = subprocess.check_output(
                ["wmic", "cpu", "get", "Name"],
                stderr=subprocess.DEVNULL
            ).decode().strip().split("\n")
            if len(out) > 1:
                return out[1].strip()
        except Exception:
            pass

    # Linux fallback
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if "model name" in line:
                    return line.split(":")[1].strip()
    except Exception:
        pass

    # macOS fallback
    try:
        out = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"]
        ).decode().strip()
        if out:
            return out
    except Exception:
        pass

    # Last resort
    return platform.processor() or "Unknown CPU"


def _get_cuda_device_name(cuda_device: int = 0) -> str:
    try:
        import torch
        if torch.cuda.is_available():
            return torch.cuda.get_device_name(cuda_device)
        else:
            return None
    except ImportError:
        return None

def check_cuda_available() -> bool:
    """Check if PyTorch with CUDA is available."""
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        return False

def resolve_backend(parallel: bool, preferred_backend: Optional[ParallelBackend] = None) -> Optional[ParallelBackend]:
    """
    Resolve the requested parallel configuration to an actual backend.

    Parameters
    ----------
    parallel : bool
        Whether parallel evaluation was requested.
    preferred_backend : ParallelBackend, optional
        Preferred backend. If None, auto-selects based on availability.

    Returns
    -------
    ParallelBackend or None
        The backend to use, or None if parallel=False.

    Warns
    -----
    RuntimeWarning
        If CUDA was requested but is unavailable.
    """
    if not parallel:
        return None

    if preferred_backend == ParallelBackend.CUDA_STREAMS:
        if check_cuda_available():
            return ParallelBackend.CUDA_STREAMS
        else:
            warnings.warn(
                "CUDA streams requested but PyTorch/CUDA is not available. "
                "Falling back to ThreadPoolExecutor. "
                "Install PyTorch with CUDA support for GPU acceleration.",
                RuntimeWarning,
                stacklevel=3
            )
            return ParallelBackend.THREADPOOL

    if preferred_backend is not None:
        return preferred_backend

    # Auto-select: prefer CUDA if available, otherwise threadpool
    if check_cuda_available():
        return ParallelBackend.CUDA_STREAMS
    return ParallelBackend.THREADPOOL


def _evaluate_threadpool(
        F: Callable,
        points: List[Any],
        max_workers: Optional[int] = None,
) -> List[Any]:
    """
    Evaluate F at all points using ThreadPoolExecutor.

    This is the default backend. Works for any F, including:
    - mpmath-based functions
    - API calls
    - I/O-bound operations

    For CPU-bound F that holds the GIL, consider ProcessPoolExecutor.
    """
    n = len(points)
    if n == 0:
        return []

    # For very small workloads, sequential might be faster
    if n <= 2:
        return [F(p) for p in points]

    results = [None] * n

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks with their indices
        future_to_idx = {
            executor.submit(F, point): idx
            for idx, point in enumerate(points)
        }

        # Collect results preserving order
        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            try:
                results[idx] = future.result()
            except Exception as e:
                raise RuntimeError(
                    f"Parallel evaluation failed at point index {idx}: {e}"
                ) from e

    return results


def _evaluate_processpool(
        F: Callable,
        points: List[Any],
        max_workers: Optional[int] = None,
) -> List[Any]:
    """
    Evaluate F at all points using ProcessPoolExecutor.

    Use this for CPU-bound F that doesn't release the GIL.
    Note: F must be picklable (top-level function, not a closure).
    """
    n = len(points)
    if n == 0:
        return []

    if n <= 2:
        return [F(p) for p in points]

    results = [None] * n

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_to_idx = {
            executor.submit(F, point): idx
            for idx, point in enumerate(points)
        }

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            try:
                results[idx] = future.result()
            except Exception as e:
                raise RuntimeError(
                    f"Parallel evaluation failed at point index {idx}: {e}"
                ) from e

    return results


def _evaluate_cuda_streams(
        F: Callable,
        points: List[Any],
) -> List[Any]:
    """
    Evaluate F at all points dispatched through CUDA streams.

    Each evaluation runs in its own CUDA stream. For lightweight
    callables (single-op torch functions), stream overhead exceeds
    compute cost and sequential CPU is faster. Stream isolation
    becomes beneficial when F involves multi-kernel computation
    (neural network forward passes, iterative solvers, etc.).

    For callables that don't use PyTorch internally, falls back
    to threadpool.
    """
    try:
        import torch
    except ImportError:
        warnings.warn(
            "CUDA streams requested but PyTorch not installed. "
            "Falling back to threadpool.",
            RuntimeWarning,
            stacklevel=2
        )
        return _evaluate_threadpool(F, points, None)

    if not torch.cuda.is_available():
        warnings.warn(
            "CUDA streams requested but CUDA not available. "
            "Falling back to threadpool.",
            RuntimeWarning,
            stacklevel=2
        )
        return _evaluate_threadpool(F, points, None)

    n = len(points)
    if n == 0:
        return []

    if n <= 2:
        return [F(p) for p in points]

    # Create a stream per evaluation point
    streams = [torch.cuda.Stream() for _ in range(n)]
    results = [None] * n
    exceptions = [None] * n

    # Launch all evaluations
    for idx, (point, stream) in enumerate(zip(points, streams)):
        with torch.cuda.stream(stream):
            try:
                results[idx] = F(point)
            except Exception as e:
                exceptions[idx] = e

    # Synchronize all streams
    torch.cuda.synchronize()

    # Check for exceptions
    for idx, exc in enumerate(exceptions):
        if exc is not None:
            raise RuntimeError(
                f"Parallel CUDA evaluation failed at point index {idx}: {exc}"
            ) from exc

    return results


def evaluate_parallel(
        F: Callable,
        points: List[Any],
        backend: ParallelBackend = ParallelBackend.THREADPOOL,
        max_workers: Optional[int] = None,
) -> List[Any]:
    """
    Evaluate F at all points concurrently.

    Parameters
    ----------
    F : Callable
        The function to evaluate. Must be thread-safe.
    points : List[Any]
        Evaluation points (typically mp.mpf values).
    backend : ParallelBackend
        Which parallel backend to use.
    max_workers : int, optional
        Maximum concurrent evaluations. None = auto.

    Returns
    -------
    List[Any]
        F(point) for each point, in the same order as input.
    """
    if backend == ParallelBackend.THREADPOOL:
        return _evaluate_threadpool(F, points, max_workers)
    elif backend == ParallelBackend.PROCESSPOOL:
        return _evaluate_processpool(F, points, max_workers)
    elif backend == ParallelBackend.CUDA_STREAMS:
        return _evaluate_cuda_streams(F, points)
    else:
        raise ValueError(f"Unknown backend: {backend}")



# ---------------------------------------------------------------------------
# Point and Execution Ctx builders - return descriptors, NOT precomputed mpf values
# ---------------------------------------------------------------------------
@dataclass
class EvalTask:
    point: EvalPoint
    ctx: EvalCtx

@dataclass
class EvalCtx:
    backend: str = "cpu"
    precision: Optional[int] = None

@dataclass
class EvalPoint:
    """
    Evaluation point descriptor.
    Point descriptors only — actual mpf values are computed at evaluation time with per-layer precision.
    """
    layer_idx: int
    offset_type: Literal['plus', 'minus', 'center']
    h_frac: Any  # Fraction - None for center point



def build_diff_eval_points(
    fibs: List[int],
    factorial_fn: Callable[[int], int],
    order: int,
    Fraction,
) -> Tuple[List[EvalPoint], List[Any]]:
    """
    Build evaluation point descriptors for differentiation.
    
    Does NOT compute actual x0±h values - those are computed
    at evaluation time with proper per-layer precision.
    """
    eval_points = []
    h_values = []
    
    for idx, f in enumerate(fibs):
        m_int = factorial_fn(f)
        h_frac = Fraction(1, 2 * m_int)
        h_values.append(h_frac)
        
        eval_points.append(EvalPoint(idx, 'plus', h_frac))
        eval_points.append(EvalPoint(idx, 'minus', h_frac))
    
    if order % 2 == 0:
        eval_points.append(EvalPoint(-1, 'center', None))
    
    return eval_points, h_values


def build_int_eval_points(
    fibs: List[int],
    width: Any,  # Fraction - panel width
    factorial_fn: Callable[[int], int],
    Fraction,
) -> Tuple[List[EvalPoint], List[Any]]:
    """
    Build evaluation point descriptors for a single integration panel.
    
    Does NOT compute actual mid±h values - those are computed
    at evaluation time with proper per-layer precision.
    """
    eval_points = []
    h_values = []
    
    for idx, f in enumerate(fibs):
        m_int = factorial_fn(f)
        m_frac = Fraction(m_int, 1)
        h_frac = width / (2 * m_frac)
        h_values.append(h_frac)
        
        eval_points.append(EvalPoint(idx, 'plus', h_frac))
        eval_points.append(EvalPoint(idx, 'minus', h_frac))
    
    return eval_points, h_values


# ---------------------------------------------------------------------------
# Parallel evaluators - thread-safe precision
# ---------------------------------------------------------------------------

def _make_caller(F_eval):
    """
    Build a fast callable dispatcher for F_eval.

    - Detects once whether F_eval accepts an EvalCtx argument.
    - Avoids per-call try/except that could mask genuine TypeErrors.
    - Supports positional-only, keyword-only, *args, **kwargs.
    - Falls back safely if signature inspection fails.
    """

    try:
        sig = inspect.signature(F_eval)
        params = list(sig.parameters.values())
    except (ValueError, TypeError):
        # Fall back to no ctx.
        f = F_eval

        def caller(x, ctx):
            return f(x)
        return caller

    # Detect whether ctx can be passed
    accepts_ctx = False

    if len(params) >= 2:
        p = params[1]
        accepts_ctx = p.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        )

    # Variadic arguments always safe to pass ctx
    if any(p.kind == inspect.Parameter.VAR_POSITIONAL for p in params):
        accepts_ctx = True
    if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params):
        accepts_ctx = True

    # Bind locally for faster calls
    f = F_eval

    if accepts_ctx:
        def caller(x, ctx):
            return f(x, ctx)
    else:
        def caller(x, ctx):
            return f(x)

    return caller


def evaluate_parallel_diff(
    F_eval: Callable,
    x0,
    eval_tasks: List[EvalTask],
    needed_dps_list: List[int],
    max_workers: Optional[int] = None,
    backend: Optional[ParallelBackend] = None,
) -> List[Any]:
    """
    Evaluate F at all differentiation points with per-layer precision.

    Thread-safe: sets global mp.dps to max(needed_dps_list) before
    dispatch so all workers (and user callables) operate at sufficient
    precision. Per-layer truncation is deferred to reconstruct_deltaF.

    Parameters
    ----------
    F_eval : Callable
        Target function.
    x0 : number
        Center point (will be converted to mpf per-worker).
    eval_tasks : List[EvalTask]
        Task descriptors.
    needed_dps_list : List[int]
        Required precision per layer.
    max_workers : int, optional
        Max parallel workers.
    backend : ParallelBackend, optional
        Backend executor to use. If None, auto-selects based on availability.

    Returns
    -------
    List[Any]
        F values in same order as eval_points.
    """
    from mpmath import mp
    if backend is None:
        backend = ParallelBackend.THREADPOOL

    max_dps = max(needed_dps_list) if needed_dps_list else 50
    original_dps = mp.dps

    x0_str = str(x0)

    # Get call signature for backend adaptive calling
    call = _make_caller(F_eval)

    def worker(task):
        ep = task.point
        ctx = task.ctx
        # print("backend:", ctx.backend, "layer:", ep.layer_idx)

        x0_mp = mp.mpf(x0_str)

        if ep.offset_type == "center":
            return call(x0_mp, ctx)

        h_mp = mp.mpf(ep.h_frac.numerator) / mp.mpf(ep.h_frac.denominator)

        x_eval = (
            x0_mp + h_mp if ep.offset_type == "plus"
            else x0_mp - h_mp
        )

        return call(x_eval, ctx)

    try:
        mp.dps = max_dps
        return evaluate_parallel(worker, eval_tasks, backend, max_workers)
    finally:
        mp.dps = original_dps


def evaluate_parallel_int(
    F_eval: Callable,
    mid,
    eval_tasks: List[EvalTask],
    needed_dps_list: List[int],
    max_workers: Optional[int] = None,
    backend: Optional[ParallelBackend] = None,
) -> List[Any]:
    """
    Evaluate F at all integration points with per-layer precision.

    Thread-safe: sets global mp.dps to max(needed_dps_list) before
    dispatch so all workers (and user callables) operate at sufficient
    precision. Per-layer truncation is deferred to reconstruct_symF.

    Parameters
    ----------
    F_eval : Callable
        Target function (possibly Cauchy-weighted).
    mid : number
        Panel midpoint (will be converted to mpf per-worker).
    eval_tasks : List[EvalTask]
        Task descriptors with point + execution context.
    needed_dps_list : List[int]
        Required precision per layer.
    max_workers : int, optional
        Max parallel workers.
    backend : ParallelBackend, optional
        Backend executor to use. If None, auto-selects based on availability.

    Returns
    -------
    List[Any]
        F values in same order as eval_tasks.
    """
    from mpmath import mp
    if backend is None:
        backend = ParallelBackend.THREADPOOL

    max_dps = max(needed_dps_list) if needed_dps_list else 50
    original_dps = mp.dps

    mid_str = str(mid)

    call = _make_caller(F_eval)

    def worker(task):
        ep = task.point
        ctx = task.ctx

        mid_mp = mp.mpf(mid_str)
        h_mp = mp.mpf(ep.h_frac.numerator) / mp.mpf(ep.h_frac.denominator)

        if ep.offset_type == 'plus':
            return call(mid_mp + h_mp, ctx)
        else:
            return call(mid_mp - h_mp, ctx)

    try:
        mp.dps = max_dps
        return evaluate_parallel(worker, eval_tasks, backend, max_workers)
    finally:
        mp.dps = original_dps

# ---------------------------------------------------------------------------
# Reconstruction - parity gates to get ΔF / symF from F values
# ---------------------------------------------------------------------------

def _eval_deltaF_parallel(
    order: int,
    F_plus,
    F_minus,
    F_center=None,
):
    """
    Compute ΔF from pre-evaluated F values.
    
    Parity gate:
        odd  order: ΔF = F(x0+h) - F(x0-h)
        even order: ΔF = F(x0+h) + F(x0-h) - 2*F(x0)
    
    No normalization - caller handles that.
    """
    if order % 2 == 1:
        return F_plus - F_minus
    else:
        return F_plus + F_minus - 2 * F_center


def _eval_symF_parallel(
    F_plus,
    F_minus,
    order: int,
):
    """
    Compute symmetric F from pre-evaluated F values.
    
    Parity gate (integration):
        odd  order → even lane → S = F(x0+h) + F(x0-h)
        even order → odd  lane → S = F(x0+h) - F(x0-h)
    
    No normalization - caller handles that.
    """
    if order % 2 == 1:
        return F_plus + F_minus
    else:
        return F_plus - F_minus


def reconstruct_deltaF(
        eval_results: List[Any],
        eval_points: List[EvalPoint],
        order: int,
        needed_dps_list: Optional[List[int]] = None,
) -> dict:
    """
    Reconstruct ΔF values per layer from parallel evaluation results.

    Parameters
    ----------
    eval_results : List[Any]
        F(point) for each eval_point, in same order.
    eval_points : List[EvalPoint]
        The evaluation point descriptors.
    order : int
        Derivative order (determines parity gate).
    needed_dps_list : list[int], optional
        Per-layer precision budget. If provided, each layer's
        differencing is performed under workdps(needed_dps_list[idx])
        to prevent truncation of high-precision eval results.

    Returns
    -------
    dict
        {layer_idx: deltaF_value} for each layer.
    """
    # Build lookup: (layer_idx, offset_type) -> F value
    F_values = {}
    for ep, result in zip(eval_points, eval_results):
        F_values[(ep.layer_idx, ep.offset_type)] = result

    # Extract center value if present (even order)
    F_center = F_values.get((-1, 'center'), None)

    # Compute deltaF per layer
    deltaF_by_layer = {}
    layer_indices = sorted(set(ep.layer_idx for ep in eval_points if ep.layer_idx >= 0))

    for idx in layer_indices:
        F_plus = F_values[(idx, 'plus')]
        F_minus = F_values[(idx, 'minus')]

        if needed_dps_list is not None and idx < len(needed_dps_list):
            with mp.workdps(needed_dps_list[idx]):
                deltaF_by_layer[idx] = _eval_deltaF_parallel(order, F_plus, F_minus, F_center)
        else:
            deltaF_by_layer[idx] = _eval_deltaF_parallel(order, F_plus, F_minus, F_center)

    return deltaF_by_layer


def reconstruct_symF(
        eval_results: List[Any],
        eval_points: List[EvalPoint],
        order: int,
        needed_dps_list: Optional[List[int]] = None,
) -> dict:
    """
    Reconstruct symmetric F values per layer for integration.

    Parameters
    ----------
    eval_results : List[Any]
        F(point) for each eval_point, in same order.
    eval_points : List[EvalPoint]
        The evaluation point descriptors.
    order : int
        Integral order (determines parity gate).
    needed_dps_list : list[int], optional
        Per-layer precision budget. If provided, each layer's
        arithmetic is performed under workdps(needed_dps_list[idx]).

    Returns
    -------
    dict
        {layer_idx: symF_value} for each layer.
    """
    # Build lookup
    F_values = {}
    for ep, result in zip(eval_points, eval_results):
        F_values[(ep.layer_idx, ep.offset_type)] = result

    # Compute symF per layer
    symF_by_layer = {}
    layer_indices = sorted(set(ep.layer_idx for ep in eval_points if ep.layer_idx >= 0))

    for idx in layer_indices:
        F_plus = F_values[(idx, 'plus')]
        F_minus = F_values[(idx, 'minus')]

        if needed_dps_list is not None and idx < len(needed_dps_list):
            with mp.workdps(needed_dps_list[idx]):
                symF_by_layer[idx] = _eval_symF_parallel(F_plus, F_minus, order)
        else:
            symF_by_layer[idx] = _eval_symF_parallel(F_plus, F_minus, order)

    return symF_by_layer
