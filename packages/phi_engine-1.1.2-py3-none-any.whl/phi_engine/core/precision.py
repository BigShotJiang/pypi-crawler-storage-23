# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/precision.py
"""
Precision budgeting and bit-length heuristics for adaptive φ-evaluation.

This module provides helper routines to estimate the decimal precision
required for exact rational intermediates without ever touching floating-point
arithmetic.  Each function operates on Python's arbitrary-precision integers,
using only bit-length analysis to infer approximate digit magnitude.

In the φ-Engine, precision is not about numerical error in a sampled sense;
it's an *execution budget* — how many digits are needed to safely resolve a
factorial displacement, given its numerator/denominator structure.  These
helpers allow the engine to scale mpmath's decimal precision dynamically,
ensuring that contraction proceeds without overflow or premature truncation.

All functions here are identity-free and deterministic: the same rational
inputs will always produce the same precision estimates, guaranteeing that
the adaptive DPS logic remains reproducible across systems and sessions.

This was my attempt to solve the I/O problem I created, but this is far from the
best solution, φ-certificates will help other people find a better one.
"""


from ._rational import Fraction
from mpmath import mp

_LOG10_2 = mp.log10(2)

def _dec_digits_from_bits(bitlen: int) -> int:
    return int(mp.ceil(bitlen * _LOG10_2))

def _digits_fraction_abs(q: Fraction) -> int:
    """
    Estimate decimal digits of |num/den| ≈ max(dec_digits(num), dec_digits(den)) + slack
    """
    nbits = q.numerator.bit_length()
    dbits = q.denominator.bit_length()
    return max(_dec_digits_from_bits(nbits), _dec_digits_from_bits(dbits)) + 2

def _digits_factorial_int(m_int: int) -> int:
    return _dec_digits_from_bits(m_int.bit_length())

def _digits_from_h(h_frac: Fraction) -> int:
    # digits needed to resolve an O(h) difference; use log10(1/|h|)
    if h_frac == 0:
        return 0
    n = abs(h_frac.numerator)
    d = h_frac.denominator
    # log10(1/|h|) ≈ log10(d) - log10(n) using bit-lengths
    return max(0, _dec_digits_from_bits(d.bit_length()) - _dec_digits_from_bits(n.bit_length()) + 2)
