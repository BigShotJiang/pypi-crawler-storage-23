# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
# phi_engine/core/_rational.py

"""Unified rational arithmetic shim.

Auto-selects gmpy2.mpq when available, falls back to fractions.Fraction.
Exports Fraction, GMPY2_AVAILABLE, and RATIONAL_TYPES for engine-wide use.
"""
import warnings

try:
    import gmpy2
    from gmpy2 import mpq as Fraction
    from fractions import Fraction as PyFraction

    GMPY2_AVAILABLE = True
    RATIONAL_TYPES = (Fraction, PyFraction)

except ImportError:
    from fractions import Fraction

    GMPY2_AVAILABLE = False
    RATIONAL_TYPES = (Fraction,)
    warnings.warn(
        "gmpy2 not found — falling back to stdlib Fraction. "
        "Install gmpy2 for >10x faster engine performance.",
        stacklevel=2
    )

__all__ = ["Fraction", "GMPY2_AVAILABLE", "RATIONAL_TYPES"]
