# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/certificates.py
"""
Implements the φ-certificate system: a reproducible, verifiable archive
format for exact rational β-streams and their factorial structure.

A φ-certificate represents a frozen proof of convergence for a specific
moment law and Fibonacci factorial depth.  Each certificate encodes the
exact β-coefficients as rational numerators and denominators together
with deterministic metadata and a canonical SHA-256 hash.  This makes
it possible to reproduce, audit, or distribute an infinite-precision
β-stream without ever re-computing it.

Unlike traditional floating-point snapshots, these files preserve the
entire symbolic precision of the underlying mathematics.  The limiting
factor of evaluation therefore becomes I/O bandwidth and JSON parsing
speed, not arithmetic accuracy — calculus itself is already exact.
All numerical errors are confined to the contraction step performed by
`mpmath` at user-selected precision.

Design principles
-----------------
• **Exactness** – All β values are stored as integer pairs (num, den).
  No truncation or rounding occurs at any stage.

• **Determinism** – Every certificate is serialized through canonical
  JSON (sorted keys, compact separators) to guarantee identical hashes
  across machines and operating systems.

• **Cryptographic traceability** – A SHA-256 digest over the canonical
  encoding serves as a tamper-proof root.  This hash is the definitive
  identifier of the β-stream and its factorial ladder.

• **Portability** – Certificates can be gzip-compressed and verified
  independently of the φ-Engine runtime, enabling external analysis or
  archival in version control.

• **Extensibility** – The schema is minimal and self-describing, allowing
  future encodings beyond `exact_rational` (for example, modular residue
  or continued-fraction representations).

In the φ-Engine architecture, these certificates are the boundary
between pure mathematics and machine execution: they are the interface
where infinite precision meets the physical limits of storage and
transfer.  Once a β-stream is certified, calculus becomes an I/O
problem — extracting digits, not deriving formulas.

Main entry points
-----------------
- `PhiCert` : Dataclass describing the schema and metadata fields.
- `save_cert()` / `load_cert()` : Serialize or rehydrate certificates.
- `verify_hash()` / `verify_moments()` : Ensure integrity and moment-law
  correctness.
- `emit_cert_from_engine()` : Generate a certificate directly from a
  configured φ-Engine instance.

Each certified β-stream is both a mathematical object and a digital
artifact — a self-contained, cryptographically verifiable statement that
a specific factorial structure executes calculus exactly.
"""


import json
import gzip
import hashlib
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Optional
from ._rational import Fraction
from math import factorial
from datetime import datetime, timezone
UTC = timezone.utc
from .moments import w_derivative, w_integral

# ---------- Utilities ----------

def _canon_json(obj: Any) -> bytes:
    """Canonical JSON (sorted keys, compact separators) for deterministic hashing."""
    return json.dumps(obj, sort_keys=True, separators=(',', ':')).encode('utf-8')

def compute_sha256_hex(obj: Any) -> str:
    """Compute SHA-256 digest (hex) over canonical JSON encoding."""
    return hashlib.sha256(_canon_json(obj)).hexdigest()

# ---------- Schema ----------

@dataclass
class HashInfo:
    alg: str = "sha256"
    root: str = ""

@dataclass
class PhiCert:
    """
    Structured record describing a φ-certificate.

    A φ-certificate packages a complete β-stream together with its
    factorial node structure, encoding method, and deterministic hash.
    It is the canonical representation of an exact φ-moment proof:
    a reproducible statement that a given factorial ladder performs
    derivative, or integral evaluation exactly to any desired precision.

    Fields
    -------
    type : str
        Schema version, e.g. "phi_beta/v1".
    moment : str
        Operator family: "derivative", "integral".
    fib_count : int
        Ladder length defining the factorial Fibonacci depth.
    fibs : list[int]
        The actual Fibonacci sequence used to construct node positions.
    node_formula : str
        Descriptive string for x_i definitions (for provenance only).
    encoding : str
        Current payload encoding, usually "exact_rational".
    payload : dict
        Serialized β-coefficients or other encoding-specific data.
    hash : HashInfo
        Hash algorithm and canonical digest root.
    meta : dict | None
        Optional metadata (generator, timestamp, or provenance notes).
    """
    type: str                # e.g. "phi_beta/v1"
    moment: str              # "derivative" | "integral"
    fib_count: int
    fibs: List[int]
    order: int
    node_formula: str        # e.g. "x_i = 1/(F_i!)^2"
    encoding: str            # "exact_rational" (MVP)
    payload: Dict[str, Any]
    hash: HashInfo
    meta: Optional[Dict[str, Any]] = None  # provenance, timestamp, generator, etc.

# ---------- Core I/O ----------

def save_cert(cert: PhiCert, path: str, gzip_out: bool = True, verify_roundtrip: bool = False) -> None:
    """
    Serialize and save a φ-certificate.
    Optionally verifies round-trip integrity by reloading and re-hashing.
    """
    payload = asdict(cert)
    # Compute canonical root hash (exclude meta)
    root_material = {
        "type": cert.type,
        "moment": cert.moment,
        "fib_count": cert.fib_count,
        "fibs": cert.fibs,
        "order": cert.order,
        "node_formula": cert.node_formula,
        "encoding": cert.encoding,
        "payload": cert.payload,
    }
    payload["hash"] = {"alg": "sha256", "root": compute_sha256_hex(root_material)}
    payload.setdefault("meta", {
        "generated": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "generator": "phi_engine",
        "version": "1.1.2"
    })

    data = _canon_json(payload)
    if gzip_out:
        with gzip.open(path, "wb") as f:
            f.write(data)
    else:
        with open(path, "wb") as f:
            f.write(data)

    if verify_roundtrip:
        tmp = load_cert(path)
        verify_hash(tmp)

def load_cert(path: str) -> PhiCert:
    """Load a φ-certificate (gzip or plain) and rehydrate dataclass fields."""
    try:
        with gzip.open(path, "rb") as f:
            b = f.read()
    except OSError:
        with open(path, "rb") as f:
            b = f.read()

    obj = json.loads(b.decode("utf-8"))

    # Rehydrate nested dataclasses
    h = obj.get("hash", {})
    if not isinstance(h, HashInfo):
        h = HashInfo(**h)
    meta = obj.get("meta", None)

    return PhiCert(
        type=obj["type"],
        moment=obj["moment"],
        fib_count=obj["fib_count"],
        fibs=obj["fibs"],
        order=obj["order"],
        node_formula=obj["node_formula"],
        encoding=obj["encoding"],
        payload=obj["payload"],
        hash=h,
        meta=meta,
    )


# ---------- Verification ----------

def betas_from_cert(cert: PhiCert) -> List[Fraction]:
    """Extract β-rational stream as Fraction list."""
    if cert.encoding != "exact_rational":
        raise NotImplementedError("Only exact_rational encoding implemented.")
    pairs = cert.payload.get("beta_rationals")
    if not isinstance(pairs, list):
        raise ValueError("Malformed payload: missing beta_rationals list.")
    return [Fraction(int(n), int(d)) for (n, d) in pairs]

def verify_hash(cert: PhiCert) -> None:
    """Recompute and verify embedded SHA-256 root."""
    root_material = {
        "type": cert.type,
        "moment": cert.moment,
        "fib_count": cert.fib_count,
        "fibs": cert.fibs,
        "order": cert.order,
        "node_formula": cert.node_formula,
        "encoding": cert.encoding,
        "payload": cert.payload,
    }
    expected = compute_sha256_hex(root_material)
    alg = cert.hash.alg if isinstance(cert.hash, HashInfo) else cert.hash.alg
    root = cert.hash.root if isinstance(cert.hash, HashInfo) else cert.hash.root
    assert alg == "sha256", "Unexpected hash algorithm."
    assert root == expected, "Certificate hash mismatch."


def verify_moments(cert: PhiCert, J: Optional[int] = None) -> None:
    """
    Verifies Σ β_i x_i^k against the correct target sequence per moment:

      derivative:   S_0 = 1, S_k = 0 (k >= 1)
      integral:     S_k = 1/(2k+1)   (value-based primitive-free integral via symmetric averages)

    where x_i = 1/(F_i!)^2 and R = len(β)-1.
    """
    betas = betas_from_cert(cert)
    xs = [Fraction(1, factorial(f) ** 2) for f in cert.fibs]
    R = len(betas) - 1
    if J is None:
        J = R

    if cert.moment == "derivative":
        targets = w_derivative(cert.fib_count, cert.order)
    elif cert.moment == "integral":
        targets = w_integral(cert.fib_count, cert.order)
    else:
        raise ValueError(f"Unknown moment kind: {cert.moment}")

    for k in range(J + 1):
        s = sum(betas[i] * (xs[i] ** k) for i in range(R + 1))
        assert s == targets[k], f"Moment check failed at k={k}: {s} != {targets[k]}"

def verify_cert(cert: PhiCert, verbose: bool = False):
    """
    Verify a φ-certificate's hash and moment laws.
    If verbose=True, print human-friendly success/failure messages.
    """
    try:
        verify_hash(cert)
        verify_moments(cert)
        if verbose:
            print(f"✓ Certificate OK (moment={cert.moment}, fib_count={cert.fib_count}, order={cert.order})")
        return True
    except Exception as e:
        if verbose:
            print(f"✗ Certificate FAILED (moment={cert.moment}, fib_count={cert.fib_count}, order={cert.order}): {e}")
        return False


# ---------- Engine Integration ----------

def emit_cert_from_engine(engine, moment: str, fib_count: int, order: int = 1) -> PhiCert:
    """
    Emit certificate directly from a φ-engine instance.
    """
    from .fib import fib_ladder

    betas, eff_count = engine.get_betas(moment, fib_count, order)

    payload = {
        "beta_rationals": [
            [str(b.numerator), str(b.denominator)]
            for b in betas
        ]
    }

    cert = PhiCert(
        type="phi_beta/v1",
        moment=moment,
        fib_count=eff_count,
        fibs=fib_ladder(eff_count),
        order=order,
        node_formula="x_i = 1/(F_i!)^2",
        encoding="exact_rational",
        payload=payload,
        hash=HashInfo(),
        meta={"generated": datetime.now(UTC).isoformat().replace("+00:00", "Z")}
    )

    return cert
