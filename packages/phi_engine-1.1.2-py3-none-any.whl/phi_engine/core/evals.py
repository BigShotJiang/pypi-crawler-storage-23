# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/evals.py
"""
Adaptive evaluators for analytic function deltas and symmetric forms.

This module provides low-level adaptive routines that compute forward
and symmetric finite differences directly in mpmath space, without
using any mesh or discrete grid. Each evaluator increases decimal
precision until the result becomes both finite and nonzero, allowing
the φ-Engine to perform self-stabilizing contraction of β-streams.

Unlike classical quadrature or finite-difference approaches, these
evaluators treat evaluation as a *pure functional call* with adaptive
precision budgeting — never as an accumulation of samples. They are
therefore compatible with φ-calculus' identity-free structure, where
integration, differentiation, and symmetric value evaluation share a
single factorial framework.

Critically, these functions do not operate on point sets: they act
directly on factorial displacements derived from exact Fractions,
making them coefficient-driven, not coordinate-driven.

All deltas and symmetrics returned by these functions are deterministic
given the same function and Fraction inputs, regardless of the starting
precision, making them ideal primitives for exact β-stream contraction.
"""


from ._rational import Fraction
from typing import Callable, Tuple
from mpmath import mp


def _eval_deltaF_adaptive(
    F_eval: Callable[[mp.mpf], mp.mpf],
    x0: mp.mpf,
    h_frac: Fraction,
    start_dps: int,
    max_dps: int,
    dps_step: int,
    order: int,
) -> Tuple[mp.mpf, int]:
    """
    Parity-aware, *numerator-only* adaptive evaluator.

    Returns the raw symmetric numerator ΔF_num, with NO normalization.

      odd  order: ΔF_num = F(x0+h) - F(x0-h)
      even order: ΔF_num = F(x0+h) + F(x0-h) - 2*F(x0)
    """
    if order < 1:
        raise ValueError("order must be >= 1")

    dps = max(64, start_dps)

    last_num = None
    last_dps = None

    zero_streak = 0
    ZERO_STREAK_LIMIT = 3  # confirmation threshold for structural zeros

    while True:
        if dps > max_dps:
            # Ceiling reached: return best-known numerator (or 0 if none ever computed)
            if last_num is None:
                return mp.mpf("0"), max_dps
            return last_num, last_dps if last_dps is not None else max_dps

        with mp.workdps(dps):
            x0_mp = mp.mpf(x0)
            h_mp = mp.mpf(h_frac.numerator) / mp.mpf(h_frac.denominator)

            fa = F_eval(x0_mp + h_mp)
            fb = F_eval(x0_mp - h_mp)

            if order % 2 == 0:
                # Even lane: centered second-difference numerator
                fc = F_eval(x0_mp)
                num = fa + fb - 2 * fc
            else:
                # Odd lane: antisymmetric numerator
                num = fa - fb

        # If numerator is non-finite, it's not resolved; keep escalating.
        if not (num.isfinite() if hasattr(num, 'isfinite') else mp.isfinite(num)):
            zero_streak = 0
        else:
            if num != 0:
                # Resolved to a finite, nonzero numerator at this precision.
                return num, dps

            # num == 0: possible structural zero OR rounded-to-zero.
            zero_streak += 1
            if zero_streak >= ZERO_STREAK_LIMIT:
                return mp.mpf("0"), dps

        # Escalate precision and remember last computed numerator.
        last_num = num
        last_dps = dps
        dps = min(max_dps, max(dps + dps_step, dps * 2))


def _eval_symF_adaptive(
    F_eval: Callable[[mp.mpf], mp.mpf],
    x0: mp.mpf,
    h_frac: Fraction,
    order: int,
    start_dps: int,
    max_dps: int,
    dps_step: int,
) -> Tuple[mp.mpf, int]:
    """
    Parity-aware, numerator-only symmetric sampler for φ-integration.

    Returns the raw symmetric numerator S_num, with NO normalization.

      odd  order → even lane → S_num = F(x0+h) + F(x0-h)
      even order → odd  lane → S_num = F(x0+h) - F(x0-h)

    Responsibilities:
      • Escalate precision until finite and nonzero OR confirmed structural zero
      • Never accept rounded-to-zero prematurely
      • Report the precision (dps) at which the value stabilized
      • Perform all mp.mpf reconstruction inside workdps

    Scaling by 1/2, h, or interval width is handled by the caller.
    """
    if order < 1:
        raise ValueError("order must be >= 1")

    dps = max(64, start_dps)

    last_num = None
    last_dps = None

    zero_streak = 0
    ZERO_STREAK_LIMIT = 3  # structural zero confirmation

    while True:
        if dps > max_dps:
            if last_num is None:
                return mp.mpf("0"), max_dps
            return last_num, last_dps if last_dps is not None else max_dps

        with mp.workdps(dps):
            x0_mp = mp.mpf(x0)
            h_mp  = mp.mpf(h_frac.numerator) / mp.mpf(h_frac.denominator)

            fa = F_eval(x0_mp + h_mp)
            fb = F_eval(x0_mp - h_mp)
            num = fa + fb

            if order % 2 == 1:
                # odd-order integral → even lane
                num = fa + fb
            else:
                # even-order integral → odd lane
                num = fa - fb

        if not (num.isfinite() if hasattr(num, 'isfinite') else mp.isfinite(num)):
            zero_streak = 0
        else:
            if num != 0:
                return num, dps

            zero_streak += 1
            if zero_streak >= ZERO_STREAK_LIMIT:
                return mp.mpf("0"), dps

        last_num = num
        last_dps = dps
        dps = min(max_dps, max(dps + dps_step, dps * 2))


def _eval_deltaF_parallel(
        F_eval: Callable,
        x0: 'mp.mpf',
        h_frac: 'Fraction',
        order: int,
        F_plus: 'mp.mpf',
        F_minus: 'mp.mpf',
        F_center: 'mp.mpf' = None,
) -> 'mp.mpf':
    """
    Compute ΔF from pre-evaluated F values.

    Parity gate:
        odd  order: ΔF = F(x0+h) - F(x0-h)
        even order: ΔF = F(x0+h) + F(x0-h) - 2*F(x0)

    No normalization - caller handles that.
    """
    if order % 2 == 1:
        return F_plus - F_minus
    else:
        return F_plus + F_minus - 2 * F_center


def _eval_symF_parallel(
        F_plus: 'mp.mpf',
        F_minus: 'mp.mpf',
        order: int,
) -> 'mp.mpf':
    """
    Compute symmetric F from pre-evaluated F values.

    Parity gate (integration):
        odd  order → even lane → S = F(x0+h) + F(x0-h)
        even order → odd  lane → S = F(x0+h) - F(x0-h)

    No normalization - caller handles that.
    """
    if order % 2 == 1:
        return F_plus + F_minus
    else:
        return F_plus - F_minus


