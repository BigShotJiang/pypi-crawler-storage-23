# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/phi_engine_config.py
"""
Centralized configuration object controlling all φ-engine runtime behavior.

This frozen dataclass defines computational policy, precision management,
diagnostics behavior, and certificate I/O.  All fields are immutable; use
`with_updates()` to create modified configurations safely.

===============================================================================================================================
                                                Configuration Reference
===============================================================================================================================
| **Category**      | **Key**              | **Purpose**                                                                      |
|-------------------|----------------------|----------------------------------------------------------------------------------|
| **Precision**     | `base_dps`           | Initial decimal precision for backend function evaluations                       |
|                   | `max_dps`            | Upper bound on adaptive precision escalation                                     |
|                   | `dps_step`           | Increment when increasing mpmath precision                                       |
|                   | `per_term_guard`     | Analytic per-layer precision budgeting (highly recommended)                      |
|                   | `rtol`, `atol`       | Optional numeric tolerances for safety checks                                    |
|                   | `suppress_guarantee` | Hide φ-digit lower bounds in diagnostic output                                   |
| **Parallel**      | `parallel`           | `ParallelConfig` dataclass: backend, max_workers, cuda_device                    |
|                   | `target_cuda_digits` | Digit budget for CUDA float64 layer classification (default 16)                  |
|                   | `precision_policy`   | Device enforcement: `"strict"` = CPU only, `"fast"` = GPU, `"adaptive"` = auto   |
| **Structure**     | `fib_count`          | Number of factorial layers (`N` annihilates Taylor terms up to degree `2N−2`)    |
| **Diagnostics**   | `timing`             | Include φ-timing information in reports                                          |
|                   | `show_error`         | Display error if user populates an `"error"` field in diagnostics                |
|                   | `return_diagnostics` | Return diagnostics dictionaries from every engine call                           |
|                   | `display_digits`     | Number of digits to print in reports                                             |
|                   | `header_keys`        | User-defined fields to include in batch-report headers                           |
| **Certification** | `beta_source`        | `"compute"` = build β-streams; `"cert"` = load from φ-certificates               |
|                   | `cert_mode`          | `"emit"` = write certs, `"verify"` = verify, `"require"` = enforce certification |
|                   | `cert_path`          | Path to certificate file when using `"cert"` mode                                |
|                   | `gzip_cert`          | Compress emitted certificates as `.json.gz`                                      |
|                   | `cert_meta`          | Metadata to embed in emitted certificates                                        |
|                   | `ensure_moments`     | Re-verify all moment identities when loading a φ-certificate (expensive).        |

Presets
--------
`preset_fast()`        → reduced precision + smaller ladder for quick exploratory runs
`preset_accurate()`    → adaptive precision + deeper ladders for research-grade work
`preset_cert_only()`   → minimal computation; load β-streams exclusively from φ-certs
`preset_diagnostics()` → all diagnostics settings on for debugging and numeric inspection
`preset_cuda()`        → float64 CUDA stream backend; trades precision for throughput
"""


from __future__ import annotations
from dataclasses import dataclass, replace, asdict, field
from typing import Optional, Callable, Dict, Any, Tuple
import json

from ._parallel import ParallelConfig

DEFAULT_FIB_COUNT = 9

@dataclass(frozen=True)
class PhiEngineConfig:
    """
    Immutable configuration object controlling φ-engine runtime behavior.

    This dataclass defines all precision parameters, caching policies,
    certification options, and diagnostic output settings.  Instances are
    lightweight and immutable; use ``with_updates`` to clone with changes.

    Methods and Notes
    -----
    - ``with_updates(**kwargs)`` — clone with modified fields.
    - ``to_json()`` / ``from_json(s)`` — serialize or restore configuration.
    - ``preset_fast()``, ``preset_accurate()``, ``preset_cert_only(path)``, ``preset_cuda()`` — factory presets.
    All fields are frozen (immutable).  Modify configurations using
    ``with_updates`` or by creating a new instance.
    """

    # Precision & adaptivity
    base_dps: int = 200
    max_dps: int = 4096
    dps_step: int = 32
    per_term_guard: bool = True
    rtol: float = 1e-18                 # These are for sanity checks only
    atol: float = 0.0
    suppress_guarantee: bool = False    # Phi engine digit accuracy guarantee by pure math (see proof in README)
    parallel: ParallelConfig = field(default_factory=ParallelConfig)
    target_cuda_digits: int = 16        # The target for CUDA precision gating usually capped by Float64
    precision_policy: str = "adaptive"  # Device enforcement: strict=cpu fast=gpu else adaptive

    # Layers + 1 (terms always 1 less than fib input due to shifted ladder)
    fib_count: int = DEFAULT_FIB_COUNT

    # Diagnostics
    return_diagnostics: bool = False
    timing: bool = False
    display_digits: int = 16
    show_error: bool = False         # Used only in .report() as a key lookup getattr
    report_col_width: int = 18

    # Cert I/O details
    gzip_cert: bool = True
    cert_meta: Optional[Dict[str, Any]] = None
    beta_source: str = "compute"     # "compute" | "cert"
    cert_mode: str = "verify"        # "require" | "verify" | "emit"
    cert_path: Optional[str] = None  # path or None
    ensure_moments: bool = False     # Forces moment check on load

    header_keys: Tuple[str, ...] = ()  # user insertable keys for output headers default = empty tuple

    def with_updates(self, **kw) -> "PhiEngineConfig":
        return replace(self, **kw)

    def to_json(self) -> str:
        obj = asdict(self)
        return json.dumps(obj, sort_keys=True, separators=(',', ':'))


    @classmethod
    def from_json(cls, s: str) -> "PhiEngineConfig":
        obj = json.loads(s)
        return cls(**obj)

    @classmethod
    def preset_fast(cls, **kwargs):
        return cls(base_dps=50, max_dps=1024, fib_count=7, **kwargs)

    @classmethod
    def preset_accurate(cls, **kwargs):
        return cls(base_dps=500, per_term_guard=True, max_dps=8192, fib_count=12, **kwargs)

    @classmethod
    def preset_cert_only(cls, path: str, **kwargs):
        # Prevent semantic hacks
        forbidden = {"beta_source", "cert_mode", "cert_path"}
        if any(k in forbidden for k in kwargs):
            raise ValueError("preset_cert_only does not allow overriding certification parameters.")
        return cls(
            beta_source="cert",
            cert_mode="require",
            cert_path=path
        ).with_updates(**kwargs)

    @classmethod
    def preset_diagnostics(cls, **kwargs) -> "PhiEngineConfig":
        return cls(
            base_dps=200,
            fib_count=9,
            per_term_guard=True,
            timing=True,
            return_diagnostics=True,
            show_error=True,
            display_digits=16,       # Machine Epsilon most used value
        ).with_updates(**kwargs)

    @classmethod
    def preset_cuda(cls, **kwargs) -> "PhiEngineConfig":
        """
        Float64 CUDA stream preset — trades precision for throughput.

        Tuned from 50,000+ configuration sweeps. Of 70 tested ladder ratios,
        none outperformed the golden ratio on any configuration test.

        WARNING: Many callables WILL lose structural information under float64
        truncation and may produce incorrect results. You are trading precision
        for speed. This preset is ONLY relevant when your callable is slow due
        to the Python GIL and CUDA kernel launch overhead.
        """
        from ._parallel import ParallelConfig, ParallelBackend
        return cls(
            precision_policy="fast",
            fib_count=6,
            base_dps=2,
            max_dps=50,
            parallel=ParallelConfig(backend=ParallelBackend.CUDA_STREAMS),
            suppress_guarantee=True,
        ).with_updates(**kwargs)
