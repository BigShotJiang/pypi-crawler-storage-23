# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_load_cert_diff.py
"""
Loads a φ-Certificate using the `preset_cert_only`
config preset to ensure trustless behavior.

In cert preset, the certificate is authoritative.
This is an absurdly high precision demo on a precomputed
large β-stream, the file loads and verifies the cert,
then executes the derivative of the Gaussian function
to a 100,000 global dps match.

You will need to increase your max string size to run this.
"""

PATH = "../certs/phi_cert_diff_fib18_order1.json.gz"

try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

from mpmath import mp
import sys
# sys.set_int_max_str_digits(250_000)   # UNCOMMENT THIS LINE TO RUN

cfg = PhiEngineConfig.preset_cert_only(
    PATH,
    per_term_guard=True,
    max_dps=250000,
    return_diagnostics=True,
    show_error=True,
    timing=True,
)

mp.dps = 40000  # Enough to capture full results

eng = PhiEngine(cfg)
f = lambda x: mp.e ** (-x ** 2)
f_truth = lambda x: -2 * x / mp.e ** (x * x)
x_0 = mp.mpf('0.25')
try:
    res, diag = eng.differentiate(f, x_0, name="Gaussian")
    diag["error"] = abs(res - f_truth(x_0))
    diag["operation"] = "Differentiation"
    diag["x0"] = x_0
    diag["result"] = res

    # Call engine report method
    eng.report(diag)

except ValueError:
    print("ValueError: String limit exceeded, UNCOMMENT sys.set_int_max_str_digits(250_000) and run again.")

