# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_all.py
"""
Demonstrates eng.all() across a suite of analytic functions.

Shows: value, derivative, and integral operators side-by-side with
internal precision tracking, timing, caps, and the φ-guarantee footer.
"""

from fractions import Fraction
from mpmath import mp

try:
    # Installed package
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    # Local development layout
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig


def main():
    # High-safety configuration so users see all caps + internal tracking
    cfg = PhiEngineConfig(
        base_dps=550,          # internal conversion headroom
        fib_count=9,           # 8-term factorial ladder
        return_diagnostics=True,
        timing=True,
        show_error=True,
        display_digits=12,
        max_dps=600            # let integration hit its internal limit
    )

    eng = PhiEngine(cfg)

    # Suite of analytic tests
    tests = [
        (
            "poly 3x^4 - 2x + 1",
            lambda x: 3 * x**4 - 2 * x + 1,
            mp.mpf("0.25"),
            Fraction(0), Fraction(1)
        ),

        (
            "gaussian",
            lambda x: mp.e ** (-x**2),
            mp.mpf("0.5"),
            Fraction(0), Fraction(1)
        ),

        (
            "cos x^2",
            lambda x: mp.cos(x**2),
            mp.mpf("0.2"),
            Fraction(0), Fraction(1)
        ),

        (
            "sin(cos(x^3)) * exp(-x^2)",
            lambda x: mp.sin(mp.cos(x**3)) * mp.e ** (-x**2),
            mp.mpf("0.5"),
            Fraction(0), Fraction(1)
        ),
    ]

    for name, f, x0, a, b in tests:

        # Important: Prevent global dps from leaking into other examples
        with mp.workdps(500):
            results, diags = eng.all(
                F_eval=f,
                x0=x0,
                a=a,
                b=b,
                dps=500,
                name=name,
                force_timing=True
            )
            # Add headers for display (these are built-in checks)
            diags[0].update({
                "interval": f"[{a},{b}]",
                "x0": f"{mp.nstr(x0, 2)}"
            })
        eng.report(diags, all_mode=True)

    print("\nAll tests finished.\n")


if __name__ == "__main__":
    main()
