# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_loss_landscape_curvature.py
"""
Loss Landscape Curvature — Exact Higher-Order Derivatives for AI Researchers
-----------------------------------------------------------------------------
Computes ∂¹L/∂w through ∂³L/∂w³ along a 1D slice through the loss landscape
of a small tanh MLP.

What this measures:
  ∂L/∂w    → gradient (slope of loss along this weight direction)
  ∂²L/∂w²  → curvature (local Hessian eigenvalue along this direction)
  ∂³L/∂w³  → anharmonic curvature (asymmetry of the loss basin)

The setup:
  - A small tanh MLP: 1 → 32 → 32 → 32 → 1
  - Fixed input x₀, fixed target y_target
  - Loss L(w) = (nn(x₀; θ + w·eᵢ) − y_target)²
    where eᵢ is a unit vector that perturbs a single weight
  - φ-engine differentiates L(w) at w=0 (the nominal weight)
"""

import sys
import torch
import torch.nn as nn
from mpmath import mp, mpf
import time

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine, PhiEngineConfig

sys.set_int_max_str_digits(100_000)


# ──────────────────────────────────────────────────────────
# Build a small tanh MLP and extract weights
# ──────────────────────────────────────────────────────────

def build_tanh_mlp(hidden_dims, seed=42):
    torch.manual_seed(seed)
    layers = []
    in_dim = 1
    for h in hidden_dims:
        layers.append(nn.Linear(in_dim, h, dtype=torch.float64))
        layers.append(nn.Tanh())
        in_dim = h
    layers.append(nn.Linear(in_dim, 1, dtype=torch.float64))
    model = nn.Sequential(*layers)
    model.eval()
    return model


def extract_weights(model):
    """Extract (W, b) pairs as plain Python floats."""
    params = []
    for module in model.modules():
        if isinstance(module, nn.Linear):
            W = module.weight.detach().cpu().tolist()
            b = module.bias.detach().cpu().tolist()
            params.append((W, b))
    return params


# ──────────────────────────────────────────────────────────
# mpmath forward pass (arbitrary precision)
# ──────────────────────────────────────────────────────────

def mpmath_forward(x_mp, params):
    """Pure mpmath forward pass through a tanh MLP."""
    a = [x_mp]
    for i, (W, b) in enumerate(params):
        out_dim = len(W)
        in_dim = len(W[0])
        z = []
        for row in range(out_dim):
            val = mpf(b[row])
            for col in range(in_dim):
                val += mpf(W[row][col]) * a[col]
            z.append(val)
        if i < len(params) - 1:
            a = [mp.tanh(zi) for zi in z]
        else:
            a = z
    return a[0]


# ──────────────────────────────────────────────────────────
# Loss landscape slice
# ──────────────────────────────────────────────────────────

def make_loss_slice(params, x_fixed, y_target, layer_idx, row_idx, col_idx):
    """
    Returns L(w) = (nn(x_fixed; θ + w·eᵢ) - y_target)²

    where eᵢ perturbs params[layer_idx].W[row_idx][col_idx] by w.
    At w=0, you get the nominal network; L(w) traces a 1D cross-section
    through the loss landscape along that single weight direction.
    """

    def loss_fn(w, ctx=None):
        # Deep-copy params and perturb the target weight
        perturbed = []
        for li, (W, b) in enumerate(params):
            if li == layer_idx:
                W_new = [row[:] for row in W]
                W_new[row_idx][col_idx] = mpf(W[row_idx][col_idx]) + mp.mpf(w)
                perturbed.append((W_new, b))
            else:
                perturbed.append((W, b))

        y_pred = mpmath_forward(mp.mpf(x_fixed), perturbed)
        return (y_pred - mp.mpf(y_target)) ** 2

    return loss_fn


# ──────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────

def _to_mpf(x):
    if hasattr(x, "numerator") and hasattr(x, "denominator"):
        try:
            return mp.mpf(x.numerator) / mp.mpf(x.denominator)
        except Exception:
            pass
    try:
        return mp.mpf(x)
    except TypeError:
        return mp.mpf(str(x))


# ──────────────────────────────────────────────────────────
# Setup
# ──────────────────────────────────────────────────────────

# Network: 3-layer 32-wide tanh MLP (small enough for fast mpmath)
model = build_tanh_mlp([32, 32, 32], seed=42)
params = extract_weights(model)

# Count parameters
n_params = sum(len(W) * len(W[0]) + len(b) for W, b in params)
print(f"Network: 3×32 tanh MLP ({n_params:,} params)")

# Fixed input and target
x_fixed = 0.5
y_target = 0.3  # arbitrary target — doesn't need to be achievable

# Perturb the first weight of the second hidden layer
# (layer 1, row 0, col 0 — a weight deep enough to be interesting)
layer_idx, row_idx, col_idx = 1, 0, 0
nominal_weight = params[layer_idx][0][row_idx][col_idx]
print(f"Perturbing weight [{layer_idx}][{row_idx}][{col_idx}] = {nominal_weight:.6f}")
print(f"Input x = {x_fixed}, target y = {y_target}\n")

# Build the 1D loss slice
L = make_loss_slice(params, x_fixed, y_target, layer_idx, row_idx, col_idx)

# ──────────────────────────────────────────────────────────
# Engine config
# ──────────────────────────────────────────────────────────

MAX_DPS = 5000
mp.dps = MAX_DPS

cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=12,
    timing=True,
    return_diagnostics=True,
    max_dps=MAX_DPS,
    per_term_guard=True,
    show_error=True,
    suppress_guarantee=True,
    report_col_width=24,
    display_digits=14,
    header_keys=(
        "network",
        "perturbed_weight",
        "num_fibs",
        "max_dps_used",
    ),
)

eng = PhiEngine(cfg)

# ──────────────────────────────────────────────────────────
# Compute loss landscape derivatives: orders 1 through 3
# ──────────────────────────────────────────────────────────

labels = [
    "∂L/∂w   (gradient)",
    "∂²L/∂w² (curvature)",
    "∂³L/∂w³ (anharmonic)",
]

diags = []
used_dps_list = []

print("Computing exact loss landscape derivatives...\n")
t0 = time.perf_counter()

for order in range(1, 4):
    res, diag = eng.differentiate(
        L, mpf("0"), order=order, name=labels[order - 1],
    )

    # Truth via mpmath finite differences at high dps (slow but reliable)
    with mp.workdps(mp.dps + 100):
        truth_val = mp.diff(L, mpf("0"), order)

    res_mpf = _to_mpf(res)
    abs_err = mp.fabs(res_mpf - truth_val)

    used_dps_list.append(diag.get("used_dps_max", 0))

    diag.update({
        "operation": "Differentiation",
        "result": res,
        "truth": truth_val,
        "error": abs_err,
    })

    diags.append(diag)

elapsed = time.perf_counter() - t0

diags[0].update({
    "network": "3×32 tanh MLP",
    "perturbed_weight": f"layer[{layer_idx}][{row_idx}][{col_idx}]",
    "num_fibs": cfg.fib_count,
    "max_dps_used": max(used_dps_list),
})

# ──────────────────────────────────────────────────────────
# Report
# ──────────────────────────────────────────────────────────

eng.report(
    diags,
    title="LOSS LANDSCAPE CURVATURE — ORDERS 1 THROUGH 3",
    batch=True,
)

print(f"\nTotal wall time: {elapsed:.1f}s")
