# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# hello_phi_engine.py
"""The smallest possible φ-Engine demo."""


from mpmath import mp
try:
    # Installed package path
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    # Local development path
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

# 1) Create an engine with default configuration
eng = PhiEngine()

# 2) Define an analytic function
f = lambda x: mp.sin(x)

# 3) Evaluate at a single point
x0 = mp.mpf("0.5")
result = eng.differentiate(f, x0)

print("φ-differentiate sin(0.5) =", result)
