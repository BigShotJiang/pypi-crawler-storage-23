# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_hard_integration_batch.py
"""
Benchmark: φ-Engine vs mpmath.quad
----------------------------------
Demonstrates the factorial-integrator's accuracy and runtime advantage
over mp.quad on several analytic functions.

• Pure Python φ-integrator (9 terms) vs compiled C-backed mp.quad
• No symbolic shortcuts, no adaptivity, no grids
• Shows AbsErr and timing side-by-side in a batch summary

If you want to adjust the knobs make sure cfg.base_dps is high enough to convert internals
It should always be a bit higher than global dps for your function (F_eval)
You can also set per_term_guard=True and the engine will automatically scale internal dps
then kahan sum with higest term dps before output
"""

from fractions import Fraction
from mpmath import mp
from math import pi
try:
    # Installed package path
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    # Local development path
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

import time


# ------------------------------------------------------------
# Engine Configuration
# ------------------------------------------------------------
cfg = PhiEngineConfig(
    base_dps=50,              # internal precision per term
    fib_count=10,               # 9 taylor-term factorial ladder (literally 7 coefficients)
    timing=True,               # record φ-timing
    return_diagnostics=True,   # return diagnostics dicts for inspection
    show_error=True,
    display_digits=12,
    max_dps=2000,               # Internal ceiling on adaptive dps climb
    header_keys=("global_dps", "num_fibs"),  # custom user keys to show in batch header
    per_term_guard=True,
    suppress_guarantee=True
)

eng = PhiEngine(cfg)

# ------------------------------------------------------------
# Test functions (analytic on [0,1])
# ------------------------------------------------------------
tests = [
    ("poly: 3x^11 - 7x^8",
     lambda x: 3*x**11 - 7*x**8),
    ("exp(-x^2)",        lambda x: mp.e**(-x**2)),
    ("cos(x^2)",         lambda x: mp.cos(x**2)),
    ("sin(x^2)",         lambda x: mp.sin(x**2)),
    ("exp(x^2)",         lambda x: mp.e**(x**2)),
    ("cosh(x^2)",        lambda x: mp.cosh(x**2)),
    ("exp(-(x-1/3)^2)",  lambda x: mp.e**(-(x-1/3)**2)),
]

a,b = 0, 1    # integral bounds
diags = []

t_0 = time.perf_counter()

# ------------------------------------------------------------
# Benchmark Loop
# ------------------------------------------------------------
for label, func in tests:
    mp.dps = 500  # visible accuracy, not φ accuracy

    # φ-time
    res, diag = eng.integrate(func, Fraction(a), Fraction(b), dyadic_depth=6)

    # mp.quad time
    t0 = time.perf_counter()
    mp_val = mp.quad(func, [a, b])
    mp_elapsed = time.perf_counter() - t0

    # Populate diagnostics
    diag.update({
        "function": label,
        "operation": "Integration",
        "interval": f"[{a}, {b}]",
        "result": res,
        "error": abs(res - mp_val),
        "timing_s_alt_mpquad": mp_elapsed,
        "global_dps": mp.dps,
        "num_fibs": eng.config.fib_count
    })

    diags.append(diag)

# ------------------------------------------------------------
# Batch Summary Report
# ------------------------------------------------------------
eng.report(diags, batch=True)
