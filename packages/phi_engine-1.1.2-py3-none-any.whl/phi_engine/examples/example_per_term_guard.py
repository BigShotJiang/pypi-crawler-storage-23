# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_per_term_guard_derivative.py
"""
Demonstrates φ-Engine's adaptive per-term precision budgeting (“per_term_guard”)
for differentiation, on an oscillatory function:

    F(x) = sin(x)

This is not meant to be a hard demo, its meant to be a look into the
brain of the engine with only a few layers for printability.
Each factorial layer f_i!, step h_i, and β_i coefficient implies a
mathematically predictable precision requirement. φ-Engine computes this exact
digit budget per term and evaluates symmetric samples at the required precision.

This demo prints:
    • factorial ladder index f
    • factorial mass m = f!
    • step h used by the derivative stencil
    • approximate |β| magnitude
    • analytic dps_needed (precision budgeting)
    • actual used_dps (mpmath execution)

This makes the precision brain of the φ-Engine visible for derivatives.
"""

from mpmath import mp

try:
    # Installed package path
    from phi_engine import PhiEngine, PhiEngineConfig
    from phi_engine import fib_ladder
except ImportError:
    # Local repo clone path
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core.fib import fib_ladder


def demo_precision_budget_derivative():
    F = lambda x: mp.sin(x)
    F_truth = lambda x: mp.cos(x)

    x0 = mp.mpf('0.25')

    cfg = PhiEngineConfig(
        base_dps=30,            # deliberately small baseline; per_term_guard will climb as needed
        fib_count=7,            # 6-term ladder (fib - 1)
        max_dps=3000,
        per_term_guard=True,    # <-- main feature of this demo
        return_diagnostics=True,
        timing=False,
    )

    eng = PhiEngine(cfg)

    # Set visible precision for truth / printing
    mp.dps = 200

    # -----------------------------------
    # Perform φ-Engine differentiation
    # -----------------------------------
    result, diag = eng.differentiate(F, x0, name="sin(x)")

    used_dps    = diag["used_dps_list"]
    dps_needed  = diag["needed_dps_list"]

    # Retrieve the β-stream and ladder used by the derivative operator
    betas, effective_fib_count = eng.get_betas("derivative", cfg.fib_count)
    fibs = fib_ladder(effective_fib_count)

    # Sanity: length match
    terms = min(len(fibs), len(betas), len(used_dps), len(dps_needed))

    taylor_terms = effective_fib_count - 1

    print("=" * 78)
    print(" φ-Engine Per-Term Precision Budget Demonstration (Derivative)")
    print("=" * 78)
    print(f"Function : sin(x)")
    print(f"x0       : {mp.nstr(x0, 12)}")
    print(f"Operation: Differentiation")
    print(f"Taylor Terms (annihilated): {taylor_terms}\n")
    print("Each row corresponds to one factorial layer in the symmetric ladder.\n")

    print(f"{'f':>3}  "
          f"{'m=f!':>14}  "
          f"{'h=1/(2m) (deriv)':>18}  "
          f"{'|β|':>10}  "
          f"{'needed_dps':>12}  "
          f"{'used_dps':>10}")
    print("-" * 78)

    # ------------------------------------------------------
    # Pretty-print each factorial layer
    # ------------------------------------------------------
    for idx in range(terms):
        f = fibs[idx]
        m = mp.factorial(f)

        # Derivative-specific stencil step (central difference).
        h = mp.mpf(1) / (2 * m)

        beta = abs(betas[idx])
        if beta == 0:
            beta_str = "0"
        else:
            # Approximate log10(|β|) via bit_length
            beta_log10 = (
                beta.numerator.bit_length() / 3.32192809489
                - beta.denominator.bit_length() / 3.32192809489
            )
            beta_str = f"1e{int(beta_log10):+d}"

        need = dps_needed[idx]
        used = used_dps[idx]

        print(
            f"{f:>3}  "
            f"{str(m):>14}  "
            f"{mp.nstr(h, 12):>18}  "
            f"{beta_str:>10}  "
            f"{str(need):>12}  "
            f"{str(used):>10}"
        )

    # ------------------------------------------------------
    # Footer: compare with true derivative and show φ-guarantee
    # ------------------------------------------------------
    true_val = F_truth(x0)

    print("\nφ-Engine derivative:", mp.nstr(result, 20))
    print("True derivative     :", mp.nstr(true_val, 20))
    print("Abs error           :", mp.nstr(abs(result - true_val), 10))

    print("=" * 78)


if __name__ == "__main__":
    demo_precision_budget_derivative()
