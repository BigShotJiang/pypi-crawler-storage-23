# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_nondyadic_intervals.py
"""
Demonstration: why non-dyadic intervals destroy precision — and why *every*
numerical method in history has secretly depended on dyadic structure.

This example shows a phenomenon long observed in classical numerical analysis:
methods behave “mysteriously” better when the interval is subdivided into
powers of 2. Traditionally, this improvement was blamed on machine artifacts:
    • binary hardware
    • floating-point representation
    • BigFloat rounding behavior
    • stability of uniform dyadic meshes
    • step-size heuristics
    • better conditioning of polynomial fits

The φ-Engine Letter proves the actual reason:
None of those explanations were ever correct.
To confirm this, the φ-Engine removes *all* floating-point artifacts:
every operation is performed in exact rationals until the final numeric
conversion. Even under perfect arithmetic, the precision collapse on
non-dyadic intervals still appears.
This revealed the cause was purely mathematical, not numerical.
The Letter proves this fact in more detail if you are curious.

Core structural facts:
    • The integral operator only couples to *even* Taylor powers.
    • Odd powers integrate to zero by symmetry.
    • Radii obey x_i^ℓ = (F_i^+!)^{-2ℓ}, which have exploding 2-adic valuation.
    • On a dyadic interval, (b–a)/2^d introduces **no new primes**.
      The entire contraction stays inside the prime-free 2-adic tower.
    • On a non-dyadic interval, new prime divisors enter the Taylor numerators.
      Those primes do **not** cancel against φᵢ = 1/Fᵢ⁺!, breaking prime control.

Result:
    Dyadic → prime control preserved → digits survive.
    Non-dyadic → new primes intrude → guaranteed digits collapse.

This explains why *all* classical quadrature and differentiation schemes
empirically perform best on dyadic grids: Simpson, Clenshaw–Curtis, FFT-based
quadrature, Gaussian refinements, Romberg, Richardson, adaptive solvers, etc.
They benefitted from dyadic refinement not because of computers,
but because the underlying Taylor numerators are powers of 2.

They saw the symptom.
The φ-Engine exposes the cause.
"""


from fractions import Fraction
from mpmath import mp
import time

try:
    # Installed package path
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    # Local development path
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig


# ------------------------------------------------------------
# Engine Configuration (your config)
# ------------------------------------------------------------
cfg = PhiEngineConfig(
    base_dps=350,              # internal precision per term
    fib_count=11,              # 7 taylor-term factorial ladder
    timing=True,               # record φ-timing
    return_diagnostics=True,   # return diagnostics dicts for inspection
    show_error=True,
    display_digits=12,
    max_dps=5000,              # internal ceiling on adaptive dps climb
    header_keys=("global_dps", "num_fibs"),
    per_term_guard=True,
    suppress_guarantee=True
)

eng = PhiEngine(cfg)


# ------------------------------------------------------------
# Test functions (same as your example)
# ------------------------------------------------------------
tests = [
    ("poly: 3x^11 - 7x^8",
     lambda x: 3*x**11 - 7*x**8),
    ("exp(-x^2)",        lambda x: mp.e**(-x**2)),
    ("cos(x^2)",         lambda x: mp.cos(x**2)),
    ("sin(x^2)",         lambda x: mp.sin(x**2)),
    ("exp(x^2)",         lambda x: mp.e**(x**2)),
    ("cosh(x^2)",        lambda x: mp.cosh(x**2)),
    ("exp(-(x-1/3)^2)",  lambda x: mp.e**(-(x-1/3)**2)),
]


# ------------------------------------------------------------
# Dyadic interval list
#   You can add/remove intervals here.
#   Each entry is ((a1, a2), (b1, b2)) meaning [a1/a2, b1/b2].
#   Non-dyadic entries will have drastically worse precision
#   See my LetterToCantor.pdf for explanation
# ------------------------------------------------------------
dyadic_intervals = [
    # small symmetric
    ((-1, 64), (1, 64)),    # [-1/64, 1/64]
    ((-1, 32), (1, 32)),    # [-1/32, 1/32]
    ((-1, 16), (1, 16)),    # [-1/16, 1/16]

    # small one-sided
    ((0, 1), (1, 64)),      # [0, 1/64]
    ((0, 1), (1, 32)),      # [0, 1/32]
    ((0, 1), (1, 16)),      # [0, 1/16]

    # unit-ish
    ((0, 1), (1, 1)),       # [0, 1]
    ((-1, 1), (1, 1)),      # [-1, 1]

    # larger dyadic-ish
    ((0, 1), (2, 1)),       # [0, 2]
    ((-2, 1), (2, 1)),      # [-2, 2]

    # nearly-dyadic, just off-by-one
    ((-1, 65), (1, 65)),      # [-1/65, 1/65]
    ((-1, 33), (1, 33)),      # [-1/33, 1/33]
    ((-1, 17), (1, 17)),      # [-1/17, 1/17]

    # awkward denominators
    ((0, 1), (1, 113)),
    ((0, 1), (1, 127)),
    ((0, 1), (1, 191)),

    # asymmetric weird intervals
    ((1, 13), (9, 14)),       # [1/13, 9/14]
    ((-3, 17), (8, 19)),      # [-3/17, 8/19]
    ((-11, 23), (7, 25)),     # [-11/23, 7/25]
]


# ------------------------------------------------------------
# Benchmark loop: ONE batch report per interval
# ------------------------------------------------------------
mp.dps = 200  # visible accuracy, not φ accuracy

for (a_pair, b_pair) in dyadic_intervals:
    a1, a2 = a_pair
    b1, b2 = b_pair

    a_frac = Fraction(a1, a2)
    b_frac = Fraction(b1, b2)

    diags = []  # fresh batch for THIS interval only

    print(f"{'\n'*3}")

    for label, func in tests:
        # φ-time
        res, diag = eng.integrate(
            func,
            a_frac,
            b_frac,
            dyadic_depth=2  # You can change this to zero if you want to see base local integral
        )

        # mp.quad reference
        t0 = time.perf_counter()
        mp_val = mp.quad(func, [a1 / a2, b1 / b2])
        mp_elapsed = time.perf_counter() - t0

        # Populate diagnostics
        diag.update({
            "function": label,
            "operation": "Integration",
            "interval": f"[{a1/a2}, {b1/b2}]",
            "result": res,
            "error": abs(res - mp_val),
            "timing_s_alt_mpquad": mp_elapsed,
            "global_dps": mp.dps,
            "num_fibs": eng.config.fib_count,
        })

        diags.append(diag)

    eng.report(diags, batch=True)
