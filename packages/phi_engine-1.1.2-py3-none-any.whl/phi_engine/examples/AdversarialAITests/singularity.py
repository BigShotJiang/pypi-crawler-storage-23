# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/singularity.py

"""Singularity.
"""

# phi_engine/examples/example_adversarial_tests.py
#
# Adversarial-but-fair tests for φ-Engine
# --------------------------------------
# These tests are designed to stress the *edges* of the analytic guarantees
# without violating them.
#
# All functions:
#   - are analytic in a neighborhood of x0
#   - are deterministic
#   - expose behavior only via a callable interface
#
# Failures here would be real red flags.

from mpmath import mp
import time

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

import sys
sys.set_int_max_str_digits(1_000_000)

# ---------------------------------------------------------------------
# Engine configuration
# ---------------------------------------------------------------------
cfg = PhiEngineConfig(
    base_dps=80,
    fib_count=16,
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=20000,
    display_digits=20,
    report_col_width=30,
    suppress_guarantee=True
)

eng = PhiEngine(cfg)

# Evaluation point (chosen to avoid singularities)
x0 = mp.mpf("0.1")

# High truth precision
mp.dps = 30000


# ---------------------------------------------------------------------
# Test 1: Analytic with extremely small radius of convergence
# ---------------------------------------------------------------------
eps = mp.mpf("1e-30")

def near_pole(x):
    return 1 / (x**2 + eps**2)

def near_pole_prime(x):
    return -2*x / (x**2 + eps**2)**2


# ---------------------------------------------------------------------
# Test 2: Entire function with catastrophic cancellation
# ---------------------------------------------------------------------
def cancellation_beast(x):
    return mp.e**(1e3 * x) - mp.e**(1e3 * x - 1)

def cancellation_beast_prime(x):
    return 1e3 * (mp.e**(1e3 * x) - mp.e**(1e3 * x - 1))


# ---------------------------------------------------------------------
# Test 3: Analytic, flat, and oscillatory (shifted to preserve analyticity)
# ---------------------------------------------------------------------
def flat_oscillator_shifted(x):
    return mp.e**(-1/(x+1)**2) * mp.sin(1/(x+1))

def flat_oscillator_shifted_prime(x):
    u = x + 1
    return (
        mp.e**(-1/u**2) *
        (mp.cos(1/u)*(-1/u**2) + mp.sin(1/u)*(2/u**3))
    )


# ---------------------------------------------------------------------
# Test registry
# ---------------------------------------------------------------------
tests = [
    ("Near pole (tiny radius)", near_pole, near_pole_prime),
    ("Catastrophic cancellation", cancellation_beast, cancellation_beast_prime),
    ("Flat oscillatory analytic", flat_oscillator_shifted, flat_oscillator_shifted_prime),
]

# ---------------------------------------------------------------------
# Run tests
# ---------------------------------------------------------------------
print("\n" + "="*80)
print("φ-ENGINE ADVERSARIAL TEST SUITE")
print("="*80 + "\n")

results = []

for label, f, fprime in tests:
    print(f"Running test: {label}")

    res, diag = eng.differentiate(f, x0, name=label)
    truth = fprime(x0)

    abs_err = abs(res - truth)

    diag.update({
        "function": label,
        "result": res,
        "truth": truth,
        "error": abs_err,
        "evaluation_point": x0,
    })

    results.append(diag)

    print(f"  result : {mp.nstr(res, 20)}")
    print(f"  truth  : {mp.nstr(truth, 20)}")
    print(f"  error  : {mp.nstr(abs_err, 5)}")
    print(f"  time   : {diag.get('timing_s', 0):.4f}s")
    print(f"  max dps used: {diag.get('used_dps_max', 'N/A')}")
    print()

# ---------------------------------------------------------------------
# Summary report
# ---------------------------------------------------------------------

eng.report(results, batch=True)

