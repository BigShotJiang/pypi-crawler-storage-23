# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/claude_diag_test_int_orders.py

"""
Claude Integral Orders Test.
"""

from mpmath import mp


try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig, Fraction

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core._rational import Fraction

mp.dps = 500

cfg = PhiEngineConfig(
    base_dps=100,
    fib_count=10,
    per_term_guard=True,
    return_diagnostics=True,
    timing=True,
    show_error=True,
    max_dps=2000,
    display_digits=20,
    suppress_guarantee=True,
)

eng = PhiEngine(cfg)

a = Fraction(0, 1)
b = Fraction(1, 1)

print("=" * 70)
print("COMPREHENSIVE HIGHER-ORDER INTEGRATION TEST")
print("=" * 70)

# =============================================================================
# TEST 1: Monomials (should still be exact)
# =============================================================================
print("\n" + "=" * 70)
print("TEST 1: Monomials f(x) = x^n, orders 1-5")
print("Truth: ∫^r x^n = x^{n+r} / (n+1)(n+2)...(n+r)")
print("=" * 70)


def make_monomial(n):
    def f(x):
        return x ** n

    return f


for n in [1, 2, 3]:
    print(f"\n--- f(x) = x^{n} ---")
    for order in range(1, 5):
        f = make_monomial(n)
        val, _ = eng.integrate(f, a, b, order=order, dyadic_depth=4)

        # Truth: 1 / (n+1)(n+2)...(n+order) = n! / (n+order)!
        truth = mp.mpf(1)
        for k in range(1, order + 1):
            truth /= (n + k)

        err = abs(val - truth)
        status = "✓" if err < mp.mpf(10) ** (-50) else "✗"
        print(f"  order {order}: result={mp.nstr(val, 10)}, truth={mp.nstr(truth, 10)}, err={mp.nstr(err, 6)} {status}")

# =============================================================================
# TEST 2: Exponential (the classic)
# =============================================================================
print("\n" + "=" * 70)
print("TEST 2: f(x) = e^x, orders 1-6")
print("Truth: ∫^r e^x from 0 to 1 = e - Σ_{k=0}^{r-1} 1/k!")
print("=" * 70)


def F_exp(x):
    return mp.exp(x)


for order in range(1, 7):
    val, _ = eng.integrate(F_exp, a, b, order=order, dyadic_depth=4)

    # Truth: e - sum of 1/k! for k=0 to order-1
    truth = mp.e - sum(mp.mpf(1) / mp.factorial(k) for k in range(order))

    err = abs(val - truth)
    rel_err = err / abs(truth) if truth != 0 else err
    status = "✓" if rel_err < mp.mpf(10) ** (-40) else "✗"
    print(
        f"order {order}: result={mp.nstr(val, 12)}, truth={mp.nstr(truth, 12)}, rel_err={mp.nstr(rel_err, 6)} {status}")

# =============================================================================
# TEST 3: Trigonometric
# =============================================================================
print("\n" + "=" * 70)
print("TEST 3: f(x) = sin(x), orders 1-5")
print("=" * 70)


def F_sin(x):
    return mp.sin(x)


# Iterated integrals of sin(x) from 0:
# order 1: -cos(x) + 1 = 1 - cos(1)
# order 2: -sin(x) + x  evaluated: 1 - sin(1)
# order 3: cos(x) - 1 + x^2/2 evaluated: cos(1) - 1 + 1/2
# order 4: sin(x) - x + x^3/6 evaluated: sin(1) - 1 + 1/6
# order 5: -cos(x) + 1 - x^2/2 + x^4/24 evaluated: 1 - cos(1) - 1/2 + 1/24

sin_truths = {
    1: 1 - mp.cos(1),
    2: 1 - mp.sin(1),
    3: mp.cos(1) - 1 + mp.mpf(1) / 2,
    4: mp.sin(1) - 1 + mp.mpf(1) / 6,
    5: 1 - mp.cos(1) - mp.mpf(1) / 2 + mp.mpf(1) / 24,
}

for order in range(1, 6):
    val, _ = eng.integrate(F_sin, a, b, order=order, dyadic_depth=4)
    truth = sin_truths[order]

    err = abs(val - truth)
    rel_err = err / abs(truth) if truth != 0 else err
    status = "✓" if rel_err < mp.mpf(10) ** (-40) else "✗"
    print(
        f"order {order}: result={mp.nstr(val, 12)}, truth={mp.nstr(truth, 12)}, rel_err={mp.nstr(rel_err, 6)} {status}")

# =============================================================================
# TEST 4: Hyperbolic
# =============================================================================
print("\n" + "=" * 70)
print("TEST 4: f(x) = cosh(x), orders 1-4")
print("=" * 70)


def F_cosh(x):
    return mp.cosh(x)


# Iterated integrals of cosh(x) from 0:
# order 1: sinh(x) evaluated at 1: sinh(1)
# order 2: cosh(x) - 1 evaluated: cosh(1) - 1
# order 3: sinh(x) - x evaluated: sinh(1) - 1
# order 4: cosh(x) - 1 - x^2/2 evaluated: cosh(1) - 1 - 1/2

cosh_truths = {
    1: mp.sinh(1),
    2: mp.cosh(1) - 1,
    3: mp.sinh(1) - 1,
    4: mp.cosh(1) - 1 - mp.mpf(1) / 2,
}

for order in range(1, 5):
    val, _ = eng.integrate(F_cosh, a, b, order=order, dyadic_depth=4)
    truth = cosh_truths[order]

    err = abs(val - truth)
    rel_err = err / abs(truth) if truth != 0 else err
    status = "✓" if rel_err < mp.mpf(10) ** (-40) else "✗"
    print(
        f"order {order}: result={mp.nstr(val, 12)}, truth={mp.nstr(truth, 12)}, rel_err={mp.nstr(rel_err, 6)} {status}")

# =============================================================================
# TEST 5: Mixed analytic (the real stress test)
# =============================================================================
print("\n" + "=" * 70)
print("TEST 5: f(x) = e^x * sin(x), orders 1-4")
print("=" * 70)


def F_mixed(x):
    return mp.exp(x) * mp.sin(x)


# Using Cauchy formula directly for verification via numerical integration at high precision
# ∫^r f = (1/(r-1)!) ∫_0^1 (1-t)^{r-1} e^t sin(t) dt

mp.dps = 1000  # High precision for truth computation

mixed_truths = {}
for order in range(1, 5):
    # Compute truth via direct high-precision quadrature of Cauchy form
    def integrand(t):
        return ((1 - t) ** (order - 1)) * mp.exp(t) * mp.sin(t)


    raw = mp.quad(integrand, [0, 1])
    mixed_truths[order] = raw / mp.factorial(order - 1)

mp.dps = 500  # Back to test precision

for order in range(1, 5):
    val, _ = eng.integrate(F_mixed, a, b, order=order, dyadic_depth=5)
    truth = mixed_truths[order]

    err = abs(val - truth)
    rel_err = err / abs(truth) if truth != 0 else err
    status = "✓" if rel_err < mp.mpf(10) ** (-40) else "✗"
    print(
        f"order {order}: result={mp.nstr(val, 12)}, truth={mp.nstr(truth, 12)}, rel_err={mp.nstr(rel_err, 6)} {status}")

# =============================================================================
# TEST 6: Non-unit interval
# =============================================================================
print("\n" + "=" * 70)
print("TEST 6: f(x) = e^x on [1/4, 3/4], orders 1-3")
print("=" * 70)

a2 = Fraction(1, 4)
b2 = Fraction(3, 4)

mp.dps = 1000
nonunit_truths = {}
for order in range(1, 4):
    def integrand(t):
        return ((mp.mpf(3) / 4 - t) ** (order - 1)) * mp.exp(t)


    raw = mp.quad(integrand, [0.25, 0.75])
    nonunit_truths[order] = raw / mp.factorial(order - 1)

mp.dps = 500

for order in range(1, 4):
    val, _ = eng.integrate(F_exp, a2, b2, order=order, dyadic_depth=4)
    truth = nonunit_truths[order]

    err = abs(val - truth)
    rel_err = err / abs(truth) if truth != 0 else err
    status = "✓" if rel_err < mp.mpf(10) ** (-40) else "✗"
    print(
        f"order {order}: result={mp.nstr(val, 12)}, truth={mp.nstr(truth, 12)}, rel_err={mp.nstr(rel_err, 6)} {status}")

print("\n" + "=" * 70)
print("TEST COMPLETE")
print("=" * 70)
