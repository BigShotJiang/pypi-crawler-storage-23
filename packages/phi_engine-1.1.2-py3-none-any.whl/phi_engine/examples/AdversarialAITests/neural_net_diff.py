# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/neural_net_diff.py

"""Nueral Net Diff.
"""

from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    # Local clone
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

mp.dps = 200

cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=9,
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=200,
    display_digits=30,
    suppress_guarantee=False,
)

eng = PhiEngine(cfg)

# Simulate a "black box" neural network
# In reality this would be an API call or compiled binary
# We'll fake it with a known function so we can verify

import random

random.seed(42)

# Hidden architecture: 3 layers, tanh activations, random weights
# But phi-engine doesn't know this — it just sees f(x) -> y

W1 = [[random.gauss(0, 1) for _ in range(4)] for _ in range(4)]
W2 = [[random.gauss(0, 1) for _ in range(4)] for _ in range(4)]
W3 = [random.gauss(0, 1) for _ in range(4)]
b1 = [random.gauss(0, 0.1) for _ in range(4)]
b2 = [random.gauss(0, 0.1) for _ in range(4)]
b3 = random.gauss(0, 0.1)


def neural_net(x):
    """Black box: you can call it but you don't know what's inside."""
    x = mp.mpf(x)

    # Layer 1
    h1 = [mp.tanh(sum(mp.mpf(W1[i][j]) * (x if j == 0 else mp.mpf(0))
                      for j in range(4)) + mp.mpf(b1[i]))
          for i in range(4)]

    # Layer 2
    h2 = [mp.tanh(sum(mp.mpf(W2[i][j]) * h1[j] for j in range(4)) + mp.mpf(b2[i]))
          for i in range(4)]

    # Output layer
    out = sum(mp.mpf(W3[i]) * h2[i] for i in range(4)) + mp.mpf(b3)

    return out


def neural_net_derivative_manual(x):
    """
    Manual derivative via chain rule — this is what autodiff computes.
    We use this as ground truth, but phi-engine doesn't have access to it.
    """
    x = mp.mpf(x)

    # Forward pass (keeping intermediates)
    z1 = [sum(mp.mpf(W1[i][j]) * (x if j == 0 else mp.mpf(0))
              for j in range(4)) + mp.mpf(b1[i])
          for i in range(4)]
    h1 = [mp.tanh(z) for z in z1]

    z2 = [sum(mp.mpf(W2[i][j]) * h1[j] for j in range(4)) + mp.mpf(b2[i])
          for i in range(4)]
    h2 = [mp.tanh(z) for z in z2]

    # Backward pass
    # d(out)/d(h2[i]) = W3[i]
    # d(h2[i])/d(z2[i]) = 1 - tanh^2(z2[i]) = 1 - h2[i]^2
    # d(z2[i])/d(h1[j]) = W2[i][j]
    # d(h1[j])/d(z1[j]) = 1 - h1[j]^2
    # d(z1[j])/d(x) = W1[j][0]

    dout_dh2 = [mp.mpf(W3[i]) for i in range(4)]
    dh2_dz2 = [1 - h2[i] ** 2 for i in range(4)]
    dout_dz2 = [dout_dh2[i] * dh2_dz2[i] for i in range(4)]

    dout_dh1 = [sum(dout_dz2[i] * mp.mpf(W2[i][j]) for i in range(4)) for j in range(4)]
    dh1_dz1 = [1 - h1[j] ** 2 for j in range(4)]
    dout_dz1 = [dout_dh1[j] * dh1_dz1[j] for j in range(4)]

    dout_dx = sum(dout_dz1[j] * mp.mpf(W1[j][0]) for j in range(4))

    return dout_dx


print("=" * 80)
print("BLACK BOX NEURAL NETWORK DIFFERENTIATION")
print("=" * 80)
print()
print("The neural network is a black box. φ-engine cannot see:")
print("  - The weights")
print("  - The architecture")
print("  - The activation functions")
print("  - The computational graph")
print()
print("It can only call: neural_net(x) -> y")
print()
print("=" * 80)

test_points = [mp.mpf('-1.0'), mp.mpf('0.0'), mp.mpf('0.5'), mp.mpf('1.0'), mp.mpf('2.0')]

for x0 in test_points:
    print(f"x = {x0}")

    # φ-engine differentiates the black box
    result, diag = eng.differentiate(neural_net, x0, name="neural_net")

    # Ground truth from manual backprop (simulating autodiff)
    truth = neural_net_derivative_manual(x0)

    err = abs(result - truth)
    if abs(truth) > 1e-100:
        rel_err = err / abs(truth)
        correct_digits = -mp.log10(rel_err) if rel_err > 0 else mp.inf
    else:
        correct_digits = -mp.log10(err) if err > 0 else mp.inf

    print(f"  f(x):        {mp.nstr(neural_net(x0), 15)}")
    print(f"  φ-engine:    {mp.nstr(result, 25)}")
    print(f"  autodiff:    {mp.nstr(truth, 25)}")
    print(f"  error:       {mp.nstr(err, 10)}")
    print(f"  correct:     ~{int(correct_digits)} digits")
    print(f"  time:        {diag.get('timing_s', 0):.4f}s")
    print()

print("=" * 80)
print("φ-engine differentiated a neural network without knowing it was one.")
print("No weights. No graph. No autodiff. Just function evaluations.")
print("=" * 80)
