# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/gpt_adversarial_test.py

"""
φ-Engine Benchmark Candidate Harness
=====================================

Goal: Find a vulnerability in φ-Engine given the attack prompt's capability targets.

Categories:
  A. Extreme oscillation (classical methods fail completely)
  B. AI-relevant activations
  C. Deep composition (shows black-box power)
  D. Pathological precision killers (finite diff can't touch these)
  E. Physics / engineering callables
  F. Functions with large/tiny derivatives

All truth values are hardcoded. No mp.diff, no mp.quad.
"""

from mpmath import mp, mpf
import time

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine, PhiEngineConfig


def _to_mpf(x):
    if hasattr(x, "numerator") and hasattr(x, "denominator"):
        try:
            return mp.mpf(x.numerator) / mp.mpf(x.denominator)
        except Exception:
            pass
    if hasattr(x, "p") and hasattr(x, "q"):
        return mp.mpf(int(x.p)) / mp.mpf(int(x.q))
    try:
        return mp.mpf(x)
    except TypeError:
        return mp.mpf(str(x))


def run_benchmark(eng, cases, category_name):
    """Run a set of benchmark cases and print results."""
    print(f"\n{'=' * 100}")
    print(f"  {category_name}")
    print(f"{'=' * 100}")
    print(f"  {'Function':<45} {'Time':>10} {'Digits':>10} {'|f\'(x)|':>16} {'Note'}")
    print(f"  {'─' * 95}")

    results = []
    for case in cases:
        func = case["func"]
        x0 = case["x0"]
        truth = case["truth"]
        name = case["name"]
        note = case.get("note", "")

        # 3 runs, take minimum
        times = []
        result = None
        for _ in range(3):
            t0 = time.perf_counter()
            result, diag = eng.differentiate(func, x0, order=1)
            t1 = time.perf_counter()
            times.append(t1 - t0)

        min_time = min(times)
        result_mpf = _to_mpf(result)

        with mp.workdps(2000):
            truth_val = truth()  # evaluate truth at high precision
            err = mp.fabs(result_mpf - truth_val)
            truth_abs = mp.fabs(truth_val)

            if err > 0 and truth_abs > 0:
                digits = -float(mp.log10(err / truth_abs))
            elif err == 0:
                digits = 9999.0
            else:
                digits = -float(mp.log10(err)) if err > 0 else 9999.0

        results.append({
            "name": name, "time": min_time, "digits": digits,
            "magnitude": float(mp.log10(truth_abs)) if truth_abs > 0 else 0,
            "truth_abs": truth_abs, "note": note
        })

        mag_str = mp.nstr(truth_abs, 6) if truth_abs < 1e12 else f"10^{float(mp.log10(truth_abs)):.0f}"
        digits_str = f">{int(digits)}" if digits > 1000 else f"{digits:.1f}"

        print(f"  {name:<45} {min_time:>8.3f}s {digits_str:>10} {mag_str:>16}  {note}")

    return results


def main():
    mp.dps = 2000  # for truth computation

    cfg = PhiEngineConfig(
        base_dps=50,
        fib_count=13,
        per_term_guard=True,
        return_diagnostics=True,
        timing=True,
        show_error=False,
        max_dps=2000,  # lowered from 10000 — Airy Ai(x) was minutes at 10k
    )
    eng = PhiEngine(cfg)

    # Warmup
    _ = eng.differentiate(lambda x: mp.exp(x), mpf("0.5"), order=1)

    all_results = []

    # =================================================================
    # A. EXTREME OSCILLATION
    #    These are the "impossible for classical methods" cases.
    #    The point: finite differences can't even get the SIGN right.
    # =================================================================

    x_quarter = mpf("0.25")
    x_half = mpf("0.5")
    x_third = mpf("1") / 3

    cases_A = [
        {
            "name": "sin(10^6 · x²)",
            "func": lambda x: mp.sin(mpf("1e6") * x * x),
            "x0": x_quarter,
            # d/dx sin(a·x²) = 2ax·cos(a·x²), a=1e6
            "truth": lambda: 2 * mpf("1e6") * x_quarter * mp.cos(mpf("1e6") * x_quarter**2),
            "note": "FD needs h < 10^-6",
        },
        {
            "name": "sin(10^12 · x²)",
            "func": lambda x: mp.sin(mpf("1e12") * x * x),
            "x0": x_quarter,
            "truth": lambda: 2 * mpf("1e12") * x_quarter * mp.cos(mpf("1e12") * x_quarter**2),
            "note": "FD needs h < 10^-12",
        },
        {
            "name": "sin(10^24 · x²)",
            "func": lambda x: mp.sin(mpf("1e24") * x * x),
            "x0": x_quarter,
            "truth": lambda: 2 * mpf("1e24") * x_quarter * mp.cos(mpf("1e24") * x_quarter**2),
            "note": "FD impossible in float64",
        },
        {
            "name": "sin(10^50 · x²)",
            "func": lambda x: mp.sin(mpf("1e50") * x * x),
            "x0": x_quarter,
            "truth": lambda: 2 * mpf("1e50") * x_quarter * mp.cos(mpf("1e50") * x_quarter**2),
            "note": "FD impossible in float128",
        },
        {
            "name": "sin(10^100 · x²)",
            "func": lambda x: mp.sin(mpf("1e100") * x * x),
            "x0": x_quarter,
            "truth": lambda: 2 * mpf("1e100") * x_quarter * mp.cos(mpf("1e100") * x_quarter**2),
            "note": "FD impossible in any hardware",
        },
        {
            "name": "sin(10^200 · x²)",
            "func": lambda x: mp.sin(mpf("1e200") * x * x),
            "x0": x_quarter,
            "truth": lambda: 2 * mpf("1e200") * x_quarter * mp.cos(mpf("1e200") * x_quarter**2),
            "note": "Beyond double-double-double",
        },
        {
            "name": "cos(10^100 · x³)",
            "func": lambda x: mp.cos(mpf("1e100") * x**3),
            "x0": x_third,
            # d/dx cos(a·x³) = -3ax²·sin(a·x³)
            "truth": lambda: -3 * mpf("1e100") * x_third**2 * mp.sin(mpf("1e100") * x_third**3),
            "note": "Cubic frequency scaling",
        },
        {
            "name": "exp(sin(10^50 · x))",
            "func": lambda x: mp.exp(mp.sin(mpf("1e50") * x)),
            "x0": x_quarter,
            # d/dx exp(sin(ax)) = a·cos(ax)·exp(sin(ax))
            "truth": lambda: mpf("1e50") * mp.cos(mpf("1e50") * x_quarter) * mp.exp(mp.sin(mpf("1e50") * x_quarter)),
            "note": "Extreme oscillation inside exp",
        },
    ]

    all_results.extend(run_benchmark(eng, cases_A, "A. EXTREME OSCILLATION — Classical methods fail"))

    # =================================================================
    # B. AI-RELEVANT ACTIVATIONS
    #    These are the functions AI researchers use daily.
    #    Showing exact derivatives of these is directly relevant.
    # =================================================================

    cases_B = [
        {
            "name": "tanh(x)",
            "func": lambda x: mp.tanh(x),
            "x0": x_half,
            # d/dx tanh(x) = sech²(x) = 1 - tanh²(x)
            "truth": lambda: 1 - mp.tanh(x_half)**2,
            "note": "RNN/LSTM activation",
        },
        {
            "name": "sigmoid(x) = 1/(1+e^-x)",
            "func": lambda x: 1 / (1 + mp.exp(-x)),
            "x0": x_half,
            # d/dx σ(x) = σ(x)(1-σ(x))
            "truth": lambda: (1/(1+mp.exp(-x_half))) * (1 - 1/(1+mp.exp(-x_half))),
            "note": "Logistic activation",
        },
        {
            "name": "GELU(x)",
            "func": lambda x: x * (1 + mp.erf(x / mp.sqrt(2))) / 2,
            "x0": x_half,
            # d/dx GELU(x) = Φ(x) + x·φ(x) where Φ=CDF, φ=PDF of N(0,1)
            "truth": lambda: (
                (1 + mp.erf(x_half / mp.sqrt(2))) / 2
                + x_half * mp.exp(-x_half**2 / 2) / mp.sqrt(2 * mp.pi)
            ),
            "note": "GPT/BERT activation",
        },
        {
            "name": "SiLU(x) = x·σ(x)",
            "func": lambda x: x / (1 + mp.exp(-x)),
            "x0": x_half,
            # d/dx [x·σ(x)] = σ(x) + x·σ(x)(1-σ(x))
            "truth": lambda: (
                1/(1+mp.exp(-x_half))
                + x_half * (1/(1+mp.exp(-x_half))) * (1 - 1/(1+mp.exp(-x_half)))
            ),
            "note": "LLaMA/Mistral activation",
        },
        {
            "name": "Softplus(x) = log(1+e^x)",
            "func": lambda x: mp.log(1 + mp.exp(x)),
            "x0": x_half,
            # d/dx softplus(x) = sigmoid(x)
            "truth": lambda: 1 / (1 + mp.exp(-x_half)),
            "note": "Smooth ReLU approx",
        },
        {
            "name": "Mish(x) = x·tanh(softplus(x))",
            "func": lambda x: x * mp.tanh(mp.log(1 + mp.exp(x))),
            "x0": x_half,
            # d/dx Mish = tanh(sp) + x·sech²(sp)·σ(x)
            # where sp = softplus(x), σ = sigmoid
            "truth": lambda: (
                mp.tanh(mp.log(1 + mp.exp(x_half)))
                + x_half * (1 - mp.tanh(mp.log(1 + mp.exp(x_half)))**2) * (1/(1+mp.exp(-x_half)))
            ),
            "note": "YOLOv4 activation",
        },
        {
            "name": "log-sum-exp proxy: log(e^x + e^2x)",
            "func": lambda x: mp.log(mp.exp(x) + mp.exp(2*x)),
            "x0": x_half,
            # d/dx log(e^x + e^2x) = (e^x + 2e^2x)/(e^x + e^2x)
            "truth": lambda: (mp.exp(x_half) + 2*mp.exp(2*x_half)) / (mp.exp(x_half) + mp.exp(2*x_half)),
            "note": "Attention numerics",
        },
        {
            "name": "10-layer tanh composition",
            "func": lambda x: mp.tanh(mp.tanh(mp.tanh(mp.tanh(mp.tanh(
                        mp.tanh(mp.tanh(mp.tanh(mp.tanh(mp.tanh(x)))))))))),
            "x0": mpf("0.1"),
            # truth: chain rule gives product of sech² at each layer
            # compute iteratively
            "truth": lambda: _chain_tanh_deriv(mpf("0.1"), 10),
            "note": "AD loses digits per layer",
        },
        {
            "name": "50-layer tanh composition",
            "func": lambda x: _compose_tanh(x, 50),
            "x0": mpf("0.1"),
            "truth": lambda: _chain_tanh_deriv(mpf("0.1"), 50),
            "note": "AD severely degraded",
        },
        {
            "name": "100-layer tanh composition",
            "func": lambda x: _compose_tanh(x, 100),
            "x0": mpf("0.1"),
            "truth": lambda: _chain_tanh_deriv(mpf("0.1"), 100),
            "note": "AD: ~4-5 digits left",
        },
    ]

    all_results.extend(run_benchmark(eng, cases_B, "B. AI-RELEVANT ACTIVATIONS — Direct pitch relevance"))

    # =================================================================
    # C. DEEP COMPOSITION / NESTING
    #    Shows the engine doesn't care about internal complexity.
    # =================================================================

    cases_C = [
        {
            "name": "exp(exp(x))",
            "func": lambda x: mp.exp(mp.exp(x)),
            "x0": x_half,
            # d/dx exp(exp(x)) = exp(x)·exp(exp(x))
            "truth": lambda: mp.exp(x_half) * mp.exp(mp.exp(x_half)),
            "note": "Double exponential",
        },
        {
            "name": "exp(exp(exp(x)))",
            "func": lambda x: mp.exp(mp.exp(mp.exp(x))),
            "x0": mpf("0.1"),
            # d/dx exp(exp(exp(x))) = exp(x)·exp(exp(x))·exp(exp(exp(x)))
            "truth": lambda: mp.exp(mpf("0.1")) * mp.exp(mp.exp(mpf("0.1"))) * mp.exp(mp.exp(mp.exp(mpf("0.1")))),
            "note": "Triple exponential",
        },
        {
            "name": "sin(exp(cos(x²)))",
            "func": lambda x: mp.sin(mp.exp(mp.cos(x**2))),
            "x0": x_half,
            # chain rule: cos(exp(cos(x²)))·exp(cos(x²))·(-sin(x²))·2x
            "truth": lambda: (
                mp.cos(mp.exp(mp.cos(x_half**2)))
                * mp.exp(mp.cos(x_half**2))
                * (-mp.sin(x_half**2))
                * 2 * x_half
            ),
            "note": "4-deep composition",
        },
        {
            "name": "log(1 + exp(sin(x³)))",
            "func": lambda x: mp.log(1 + mp.exp(mp.sin(x**3))),
            "x0": x_half,
            # chain: [exp(sin(x³))/(1+exp(sin(x³)))] · cos(x³) · 3x²
            "truth": lambda: (
                mp.exp(mp.sin(x_half**3)) / (1 + mp.exp(mp.sin(x_half**3)))
                * mp.cos(x_half**3)
                * 3 * x_half**2
            ),
            "note": "Softplus of sin of cube",
        },
        {
            "name": "erf(tanh(exp(x)))",
            "func": lambda x: mp.erf(mp.tanh(mp.exp(x))),
            "x0": mpf("0.1"),
            # chain: (2/√π)·exp(-tanh(exp(x))²)·sech²(exp(x))·exp(x)
            "truth": lambda: (
                (2 / mp.sqrt(mp.pi))
                * mp.exp(-mp.tanh(mp.exp(mpf("0.1")))**2)
                * (1 - mp.tanh(mp.exp(mpf("0.1")))**2)
                * mp.exp(mpf("0.1"))
            ),
            "note": "erf∘tanh∘exp",
        },
    ]

    all_results.extend(run_benchmark(eng, cases_C, "C. DEEP COMPOSITION — Black-box power"))

    # =================================================================
    # D. PRECISION KILLERS
    #    Functions where cancellation or near-singularity
    #    destroys finite differences.
    # =================================================================

    cases_D = [
        {
            "name": "(e^x - 1)/x at x=10^-15",
            "func": lambda x: (mp.exp(x) - 1) / x,
            "x0": mpf("1e-15"),
            # d/dx [(e^x-1)/x] = [x·e^x - (e^x-1)]/x²
            "truth": lambda: (mpf("1e-15") * mp.exp(mpf("1e-15")) - (mp.exp(mpf("1e-15")) - 1)) / mpf("1e-15")**2,
            "note": "Cancellation disaster for FD",
        },
        {
            "name": "sin(x)/x at x=10^-10",
            "func": lambda x: mp.sin(x) / x if x != 0 else mpf("1"),
            "x0": mpf("1e-10"),
            # d/dx [sin(x)/x] = [x·cos(x) - sin(x)]/x²
            "truth": lambda: (mpf("1e-10") * mp.cos(mpf("1e-10")) - mp.sin(mpf("1e-10"))) / mpf("1e-10")**2,
            "note": "sinc near origin",
        },
        {
            "name": "log(1+x)/x at x=10^-12",
            "func": lambda x: mp.log(1 + x) / x,
            "x0": mpf("1e-12"),
            # d/dx [log(1+x)/x] = [x/(1+x) - log(1+x)]/x²
            "truth": lambda: (mpf("1e-12")/(1+mpf("1e-12")) - mp.log(1+mpf("1e-12"))) / mpf("1e-12")**2,
            "note": "Near-zero quotient",
        },
        {
            "name": "exp(x)·sin(10^8·x) at x=π/10^8",
            "func": lambda x: mp.exp(x) * mp.sin(mpf("1e8") * x),
            "x0": mp.pi / mpf("1e8"),
            # d/dx [exp(x)sin(ax)] = exp(x)[sin(ax) + a·cos(ax)]
            "truth": lambda: mp.exp(mp.pi/mpf("1e8")) * (
                mp.sin(mpf("1e8") * mp.pi/mpf("1e8"))
                + mpf("1e8") * mp.cos(mpf("1e8") * mp.pi/mpf("1e8"))
            ),
            "note": "Near node of sin",
        },
    ]

    all_results.extend(run_benchmark(eng, cases_D, "D. PRECISION KILLERS — Finite differences break"))

    # =================================================================
    # E. PHYSICS / ENGINEERING
    #    Functions from real applications.
    # =================================================================

    cases_E = [
        {
            "name": "Bessel J₀(x)",
            "func": lambda x: mp.besselj(0, x),
            "x0": mpf("3.0"),
            # d/dx J₀(x) = -J₁(x)
            "truth": lambda: -mp.besselj(1, mpf("3.0")),
            "note": "Electromagnetics",
        },
        {
            "name": "Bessel J₀(100x)",
            "func": lambda x: mp.besselj(0, 100 * x),
            "x0": x_half,
            # d/dx J₀(ax) = -a·J₁(ax)
            "truth": lambda: -100 * mp.besselj(1, 100 * x_half),
            "note": "High-frequency Bessel",
        },
        {
            "name": "Airy Ai(x)",
            "func": lambda x: mp.airyai(x),
            "x0": mpf("1.0"),
            # d/dx Ai(x) = Ai'(x)
            "truth": lambda: mp.airyai(mpf("1.0"), derivative=1),
            "note": "Quantum tunneling",
        },
        {
            "name": "Gamma(x)",
            "func": lambda x: mp.gamma(x),
            "x0": mpf("3.5"),
            # d/dx Γ(x) = Γ(x)·ψ(x)  where ψ is digamma
            "truth": lambda: mp.gamma(mpf("3.5")) * mp.digamma(mpf("3.5")),
            "note": "Statistical distributions",
        },
        {
            "name": "erf(x²)",
            "func": lambda x: mp.erf(x**2),
            "x0": x_half,
            # d/dx erf(x²) = (4x/√π)·exp(-x⁴)
            "truth": lambda: (4 * x_half / mp.sqrt(mp.pi)) * mp.exp(-x_half**4),
            "note": "Error function composition",
        },
        {
            "name": "Planck radiation: x³/(e^x - 1)",
            "func": lambda x: x**3 / (mp.exp(x) - 1),
            "x0": mpf("2.0"),
            # d/dx [x³/(e^x-1)] = [3x²(e^x-1) - x³·e^x] / (e^x-1)²
            "truth": lambda: (
                (3 * mpf("2.0")**2 * (mp.exp(mpf("2.0")) - 1)
                 - mpf("2.0")**3 * mp.exp(mpf("2.0")))
                / (mp.exp(mpf("2.0")) - 1)**2
            ),
            "note": "Blackbody spectrum",
        },
        {
            "name": "Fermi-Dirac: 1/(e^(x-μ)/T + 1)",
            "func": lambda x: 1 / (mp.exp((x - mpf("0.5")) / mpf("0.1")) + 1),
            "x0": mpf("0.5"),
            # At x=μ: d/dx = -(1/T)·σ(0)·(1-σ(0)) = -(1/T)·(1/4)
            "truth": lambda: -(1/mpf("0.1")) * mpf("0.25"),
            "note": "Condensed matter, T=0.1",
        },
    ]

    all_results.extend(run_benchmark(eng, cases_E, "E. PHYSICS & ENGINEERING — Real applications"))

    # =================================================================
    # F. DYNAMIC RANGE
    #    Derivatives spanning many orders of magnitude.
    # =================================================================

    cases_F = [
        {
            "name": "exp(100x) at x=0.5",
            "func": lambda x: mp.exp(100 * x),
            "x0": x_half,
            # d/dx exp(ax) = a·exp(ax)
            "truth": lambda: 100 * mp.exp(100 * x_half),
            "note": "|f'| ~ 5×10^23",
        },
        {
            "name": "exp(-100x²) at x=0.5",
            "func": lambda x: mp.exp(-100 * x**2),
            "x0": x_half,
            # d/dx exp(-ax²) = -2ax·exp(-ax²)
            "truth": lambda: -200 * x_half * mp.exp(-100 * x_half**2),
            "note": "|f'| ~ 10^-10",
        },
        {
            "name": "x^100 at x=0.99",
            "func": lambda x: x**100,
            "x0": mpf("0.99"),
            # d/dx x^100 = 100·x^99
            "truth": lambda: 100 * mpf("0.99")**99,
            "note": "Polynomial, large power",
        },
        {
            "name": "exp(x^10) at x=0.9",
            "func": lambda x: mp.exp(x**10),
            "x0": mpf("0.9"),
            # d/dx exp(x^10) = 10x^9·exp(x^10)
            "truth": lambda: 10 * mpf("0.9")**9 * mp.exp(mpf("0.9")**10),
            "note": "Fast-growing composition",
        },
    ]

    all_results.extend(run_benchmark(eng, cases_F, "F. DYNAMIC RANGE — Orders of magnitude"))

    # =================================================================
    # SUMMARY
    # =================================================================
    print(f"\n\n{'=' * 100}")
    print(f"  SUMMARY: ALL CANDIDATES RANKED BY CHART IMPACT")
    print(f"{'=' * 100}")
    print(f"  {'Function':<45} {'Digits':>10} {'Time':>10} {'Category'}")
    print(f"  {'─' * 80}")

    # Sort by digits descending
    all_sorted = sorted(all_results, key=lambda r: -r["digits"])
    for r in all_sorted:
        digits_str = f">{int(r['digits'])}" if r['digits'] > 1000 else f"{r['digits']:.1f}"
        print(f"  {r['name']:<45} {digits_str:>10} {r['time']:>8.3f}s  {r['note']}")


# =================================================================
# Helper functions
# =================================================================

def _compose_tanh(x, n):
    """Apply tanh n times."""
    val = x
    for _ in range(n):
        val = mp.tanh(val)
    return val


def _chain_tanh_deriv(x0, n):
    """
    Exact derivative of n-fold tanh composition at x0.
    d/dx tanh^(n)(x) = product_{k=0}^{n-1} sech²(tanh^(k)(x0))
    where tanh^(k) means k-fold application.
    """
    vals = [x0]
    v = x0
    for _ in range(n - 1):
        v = mp.tanh(v)
        vals.append(v)
    # product of sech² at each intermediate value
    prod = mpf("1")
    for v in vals:
        prod *= (1 - mp.tanh(v)**2)
    return prod


if __name__ == "__main__":
    main()
