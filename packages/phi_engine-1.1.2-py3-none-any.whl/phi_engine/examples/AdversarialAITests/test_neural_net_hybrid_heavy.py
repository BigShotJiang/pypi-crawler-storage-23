# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/test_neural_net_hybrid_heavy.py

"""
φ-engine hybrid routing stress test: Heavy neural networks.

Same architecture as test_neural_net_hybrid.py but with much larger
networks to stress-test the CUDA/CPU dispatch and showcase the
speedup multiplier when each mpmath forward pass is expensive.

Networks:
  - "heavy"  : 8-layer, 128-wide tanh MLP  (~130k weights)
  - "monster": 12-layer, 256-wide tanh MLP  (~780k weights)

Each mpmath forward pass on the monster net does ~780k arbitrary-
precision multiply-adds per evaluation.  The CUDA path does the same
arithmetic in float64 on GPU in microseconds.  The contrast between
GPU-routed and CPU-routed layer timings should be dramatic.

Truth reference: sequential all-CPU run (mpmath IS the ground truth).

Runtime: ~2 minutes on a Ryzen 7 7800X3D bottleneck.

Usage:
    python test_neural_net_hybrid_heavy.py
"""

import torch
import torch.nn as nn
from mpmath import mp, mpf

try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig, Fraction, ParallelBackend, EvalCtx

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core._rational import Fraction
    from core._parallel import ParallelBackend, EvalCtx

# --------------------------------------------------
# Device setup
# --------------------------------------------------

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.set_default_dtype(torch.float64)


# --------------------------------------------------
# Build a torch model and extract weights
# --------------------------------------------------

def build_tanh_mlp(hidden_dims, seed=42):
    torch.manual_seed(seed)
    layers = []
    in_dim = 1
    for h in hidden_dims:
        layers.append(nn.Linear(in_dim, h, dtype=torch.float64))
        layers.append(nn.Tanh())
        in_dim = h
    layers.append(nn.Linear(in_dim, 1, dtype=torch.float64))
    model = nn.Sequential(*layers)
    model.eval()
    return model


def extract_weights(model):
    """Extract (W, b) pairs as plain Python floats."""
    params = []
    for module in model.modules():
        if isinstance(module, nn.Linear):
            W = module.weight.detach().cpu().tolist()
            b = module.bias.detach().cpu().tolist()
            params.append((W, b))
    return params


# --------------------------------------------------
# mpmath forward pass (arbitrary precision)
# --------------------------------------------------

def mpmath_forward(x_mp, params):
    """
    Pure mpmath forward pass through a tanh MLP.
    Each layer does out_dim × in_dim multiply-adds at full dps.
    """
    a = [x_mp]

    for i, (W, b) in enumerate(params):
        out_dim = len(W)
        in_dim = len(W[0])

        z = []
        for row in range(out_dim):
            val = mpf(b[row])
            for col in range(in_dim):
                val += mpf(W[row][col]) * a[col]
            z.append(val)

        if i < len(params) - 1:
            a = [mp.tanh(zi) for zi in z]
        else:
            a = z

    return a[0]


# --------------------------------------------------
# Hybrid callable factory
# --------------------------------------------------

def make_hybrid_nn(model_gpu, params):
    """
    Hybrid callable:
      - CUDA path: torch forward (float64, microseconds)
      - CPU path: mpmath forward (arbitrary precision, slow)
    """

    @torch.no_grad()
    def nn_callable(x, ctx: EvalCtx = None):
        backend = getattr(ctx, "backend", "?")

        if backend == "cuda":
            x_f = float(mp.nstr(x, 17))
            t = torch.tensor([[x_f]], dtype=torch.float64, device=DEVICE)
            return float(model_gpu(t).item())
        else:
            return mpmath_forward(mp.mpf(x), params)

    return nn_callable


# --------------------------------------------------
# mpmath-only callable (for CPU baseline)
# --------------------------------------------------

def make_cpu_nn(params):
    """Pure mpmath callable — no torch, no CUDA."""

    def nn_callable(x, ctx: EvalCtx = None):
        return mpmath_forward(mp.mpf(x), params)

    return nn_callable


# --------------------------------------------------
# Helpers
# --------------------------------------------------

def _to_mpf(x):
    if hasattr(x, "numerator") and hasattr(x, "denominator"):
        try:
            return mp.mpf(x.numerator) / mp.mpf(x.denominator)
        except Exception:
            pass
    try:
        return mp.mpf(x)
    except TypeError:
        return mp.mpf(str(x))


def count_weights(params):
    """Total number of scalar weights + biases in a network."""
    total = 0
    for W, b in params:
        total += len(W) * len(W[0]) + len(b)
    return total


# --------------------------------------------------
# Build models — HEAVY
# --------------------------------------------------

# 8-layer 128-wide tanh net
heavy_dims = [128] * 8
heavy_torch = build_tanh_mlp(heavy_dims, seed=77)
heavy_gpu = build_tanh_mlp(heavy_dims, seed=77).to(DEVICE)
heavy_params = extract_weights(heavy_torch)
heavy_hybrid = make_hybrid_nn(heavy_gpu, heavy_params)
heavy_cpu = make_cpu_nn(heavy_params)

# 12-layer 256-wide tanh net
monster_dims = [256] * 12
monster_torch = build_tanh_mlp(monster_dims, seed=314)
monster_gpu = build_tanh_mlp(monster_dims, seed=314).to(DEVICE)
monster_params = extract_weights(monster_torch)
monster_hybrid = make_hybrid_nn(monster_gpu, monster_params)
monster_cpu = make_cpu_nn(monster_params)

print(f"Heavy net:   {len(heavy_dims)} layers × {heavy_dims[0]} wide  ({count_weights(heavy_params):,} params)")
print(f"Monster net: {len(monster_dims)} layers × {monster_dims[0]} wide ({count_weights(monster_params):,} params)")

# --------------------------------------------------
# Engine settings
# --------------------------------------------------

FIB_COUNT = 11
MAX_DPS = 5000

mp.dps = MAX_DPS
x0 = mp.mpf("0.7")

test_cases = [
    ("heavy 8x128", heavy_hybrid, heavy_cpu),
    ("monster 12x256", monster_hybrid, monster_cpu),
]


# ==========================================================
# PHASE 1: Sequential CPU baseline (this IS truth)
# ==========================================================

print("\nPhase 1: Sequential CPU baseline (mpmath only, ground truth)\n")

cfg_seq = PhiEngineConfig(
    base_dps=50,
    fib_count=FIB_COUNT,
    timing=True,
    return_diagnostics=True,
    max_dps=MAX_DPS,
    per_term_guard=True,
    show_error=False,
    suppress_guarantee=True,
    report_col_width=26,
    precision_policy="strict",
    header_keys=(
        "cpu_name",
        "policy",
        "max_dps_used",
    ),
)

eng_seq = PhiEngine(cfg_seq)

# Warmup
_ = eng_seq.differentiate(heavy_cpu, x0, order=1)

cpu_truths = {}
diags_seq = []
used_dps_seq = []

for label, _, F_cpu in test_cases:
    for order in range(1, 4):
        res, diag = eng_seq.differentiate(
            F_cpu,
            x0,
            order=order,
            name=f"{label} d{order}",
            parallel=False,
        )

        cpu_truths[(label, order)] = _to_mpf(res)
        used_dps_seq.append(diag.get("used_dps_max", 0))

        diag.update({
            "operation": "Differentiation",
            "result": res,
        })

        diags_seq.append(diag)

diags_seq[0].update({
    "max_dps_used": max(used_dps_seq),
    "policy": "strict",
})

eng_seq.report(
    diags_seq,
    title="PHASE 1 — CPU BASELINE (mpmath only)",
    batch=True,
)


# ==========================================================
# PHASE 2: Hybrid CUDA/CPU dispatch
# ==========================================================

print("\nPhase 2: Hybrid CUDA/CPU dispatch\n")

cfg_hybrid = PhiEngineConfig(
    base_dps=50,
    fib_count=FIB_COUNT,
    timing=True,
    return_diagnostics=True,
    max_dps=MAX_DPS,
    per_term_guard=True,
    suppress_guarantee=True,
    report_col_width=26,
    precision_policy="adaptive",
    header_keys=(
        "cpu_name",
        "gpu_name",
        "gpu_tasks_total",
        "cpu_tasks_total",
        "policy",
        "max_dps_used",
    ),
)

cfg_hybrid.parallel.backend = ParallelBackend.CUDA_STREAMS
cfg_hybrid.parallel.max_workers = 8

eng_hybrid = PhiEngine(cfg_hybrid)

# Warmup
_ = eng_hybrid.differentiate(heavy_hybrid, x0, order=1, parallel=True)

diags_hybrid = []
hybrid_names = []
used_dps_hybrid = []
total_cuda_tasks = 0
total_cpu_tasks = 0

for label, F_hybrid, _ in test_cases:
    for order in range(1, 4):
        res, diag = eng_hybrid.differentiate(
            F_hybrid,
            x0,
            order=order,
            name=f"{label} d{order}",
            parallel=True,
        )

        used_dps_hybrid.append(diag.get("used_dps_max", 0))

        exec_info = diag.get("execution", {})
        cuda_count = exec_info.get("cuda_task_count", 0)
        cpu_count = exec_info.get("cpu_task_count", 0)
        total_cuda_tasks += cuda_count
        total_cpu_tasks += cpu_count

        # Compare to CPU truth
        truth = cpu_truths[(label, order)]
        hybrid_val = _to_mpf(res)

        if truth != 0:
            err = mp.fabs(hybrid_val - truth)
            rel_err = err / mp.fabs(truth)
            if rel_err > 0:
                digits = -float(mp.log10(rel_err))
            else:
                digits = 9999.0
        else:
            err = mp.fabs(hybrid_val)
            digits = -float(mp.log10(err)) if err > 0 else 9999.0

        diag.update({
            "operation": "Differentiation",
            "result": res,
            "truth": truth,
            "error": err,
            "correct_digits": digits,
            "global_dps": mp.dps,
            "num_fibs": FIB_COUNT,
            "evaluation_point": x0,
            "cuda_tasks": cuda_count,
            "cpu_tasks": cpu_count,
            "policy": exec_info.get("policy", "adaptive"),
        })

        diags_hybrid.append(diag)
        hybrid_names.append(f"{label} d{order}")

env_info = diags_hybrid[0].get("execution", {}).get("environment", {})

diags_hybrid[0].update({
    "cpu_name": env_info.get("cpu_name", "?"),
    "gpu_name": env_info.get("gpu_name", "?"),
    "max_dps_used": max(used_dps_hybrid),
    "cpu_tasks_total": total_cpu_tasks,
    "gpu_tasks_total": total_cuda_tasks,
})

eng_hybrid.report(
    diags_hybrid,
    title="PHASE 2 — HYBRID (torch CUDA / mpmath CPU)",
    batch=True,
)


# ==========================================================
# PHASE 3: Comparison summary
# ==========================================================

print(f"\nHybrid dispatch summary: {total_cuda_tasks} CUDA tasks, {total_cpu_tasks} CPU tasks  (fib_count={FIB_COUNT}, max_dps={MAX_DPS})")

if total_cuda_tasks > 0 and total_cpu_tasks > 0:
    print("✓ Genuine hybrid: both backends received work\n")
elif total_cuda_tasks > 0:
    print("⚠ All-CUDA: classifier routed everything to GPU\n")
else:
    print("⚠ All-CPU: no CUDA dispatch occurred\n")

print(f"  {'Test':<28} {'Digits':>8} {'Hybrid':>10} {'CPU':>10} {'Speedup':>9}")
print(f"  {'─' * 68}")

for i, diag_h in enumerate(diags_hybrid):
    diag_s = diags_seq[i]
    name = hybrid_names[i]
    digits = diag_h.get("correct_digits", 0)
    t_hybrid = diag_h.get("timing_s", 0)
    t_seq = diag_s.get("timing_s", 0)
    speedup = t_seq / t_hybrid if t_hybrid > 0 else 0

    digits_str = f">{int(digits)}" if digits > 1000 else f"{digits:.1f}"
    print(f"  {name:<28} {digits_str:>8} {t_hybrid:>8.3f}s {t_seq:>8.3f}s {speedup:>8.1f}x")
