# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/stokes_lines.py

"""
Stokes Lines.
"""

import mpmath as mp

try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig, Fraction

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core._rational import Fraction

mp.dps = 100

cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=13,
    max_dps=10000,
    return_diagnostics=True,
    timing=True,
)

eng = PhiEngine(cfg)

def F(x):
    # Entire, oscillatory, Stokes phenomenon in complex plane
    return mp.e**(-x*x) * mp.cos(mp.e**x)

a = Fraction(0, 1)
b = Fraction(3, 1)

print("=" * 80)
print("STOKES-LINE / DYADIC PANEL CONSISTENCY TEST")
print("=" * 80)
print()

results = []

for depth in [3, 4, 5, 6]:
    val, diag = eng.integrate(
        F,
        a,
        b,
        order=6,
        dyadic_depth=depth,
    )
    results.append((depth, val, diag))
    print(f"dyadic_depth={depth}")
    print(f"  value: {mp.nstr(val, 30)}")
    print(f"  time:  {diag.get('timing_s', 0):.4f}s")
    print()

print("-" * 80)
print("PAIRWISE DIFFERENCES")
print("-" * 80)

for i in range(len(results) - 1):
    d1, v1, _ = results[i]
    d2, v2, _ = results[i + 1]
    diff = abs(v2 - v1)
    print(f"depth {d1} → {d2}: |Δ| = {mp.nstr(diff, 12)}")
