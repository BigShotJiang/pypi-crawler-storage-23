# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/multi_order_showcase.py

"""Multi-Order Differentiation & Integration Showcase.

Tests orders 1-5 for differentiation and orders 1-4 for integration
across 11 analytic functions (exp, sin, cos, exp*sin, exp*cos, sinh,
cosh, log(1+x), x^5, 1/(1+x^2), exp(-x^2)) with hardcoded closed-form
truths. No mp.diff, no mp.quad — pure phi-engine vs. exact formulas.
"""

from mpmath import mp
import time
import sys

try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig, Fraction

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core._rational import Fraction


mp.dps = 2000

cfg = PhiEngineConfig(
    base_dps=5,
    fib_count=12,
    per_term_guard=True,
    return_diagnostics=True,
    timing=True,
    show_error=True,
    max_dps=5000,
    display_digits=12,
    suppress_guarantee=True,
)

eng = PhiEngine(cfg)

x0 = mp.mpf("0.25")

# =============================================================================
# DIFFERENTIATION SHOWCASE — ORDERS 1 THROUGH 5
# Analytic closed-form truths only
# =============================================================================

print("=" * 100)
print("φ-ENGINE DIFFERENTIATION SHOWCASE — ORDERS 1 THROUGH 5")
print("=" * 100)
print(f"Evaluation point: x₀ = {x0}")
print(f"Fibonacci layers: {cfg.fib_count}")
print(f"Global dps: {mp.dps}")
print("=" * 100)

# Each entry: (name, f, {order: truth_func})
# Truth functions take x and return the exact derivative

diff_tests = [
    # -------------------------------------------------------------------------
    # exp(x): all derivatives are exp(x)
    # -------------------------------------------------------------------------
    (
        "exp(x)",
        lambda x: mp.exp(x),
        {
            1: lambda x: mp.exp(x),
            2: lambda x: mp.exp(x),
            3: lambda x: mp.exp(x),
            4: lambda x: mp.exp(x),
            5: lambda x: mp.exp(x),
        }
    ),
    # -------------------------------------------------------------------------
    # sin(x): derivatives cycle sin → cos → -sin → -cos → sin
    # -------------------------------------------------------------------------
    (
        "sin(x)",
        lambda x: mp.sin(x),
        {
            1: lambda x: mp.cos(x),
            2: lambda x: -mp.sin(x),
            3: lambda x: -mp.cos(x),
            4: lambda x: mp.sin(x),
            5: lambda x: mp.cos(x),
        }
    ),
    # -------------------------------------------------------------------------
    # cos(x): derivatives cycle cos → -sin → -cos → sin → cos
    # -------------------------------------------------------------------------
    (
        "cos(x)",
        lambda x: mp.cos(x),
        {
            1: lambda x: -mp.sin(x),
            2: lambda x: -mp.cos(x),
            3: lambda x: mp.sin(x),
            4: lambda x: mp.cos(x),
            5: lambda x: -mp.sin(x),
        }
    ),
    # -------------------------------------------------------------------------
    # exp(x)*sin(x):
    # d/dx [e^x sin(x)] = e^x(sin(x) + cos(x))
    # d²/dx² = 2e^x cos(x)
    # d³/dx³ = 2e^x(cos(x) - sin(x))
    # d⁴/dx⁴ = -4e^x sin(x)
    # d⁵/dx⁵ = -4e^x(sin(x) + cos(x))
    # -------------------------------------------------------------------------
    (
        "exp(x)*sin(x)",
        lambda x: mp.exp(x) * mp.sin(x),
        {
            1: lambda x: mp.exp(x) * (mp.sin(x) + mp.cos(x)),
            2: lambda x: 2 * mp.exp(x) * mp.cos(x),
            3: lambda x: 2 * mp.exp(x) * (mp.cos(x) - mp.sin(x)),
            4: lambda x: -4 * mp.exp(x) * mp.sin(x),
            5: lambda x: -4 * mp.exp(x) * (mp.sin(x) + mp.cos(x)),
        }
    ),
    # -------------------------------------------------------------------------
    # exp(x)*cos(x):
    # d/dx [e^x cos(x)] = e^x(cos(x) - sin(x))
    # d²/dx² = -2e^x sin(x)
    # d³/dx³ = -2e^x(sin(x) + cos(x))
    # d⁴/dx⁴ = -4e^x cos(x)
    # d⁵/dx⁵ = -4e^x(cos(x) - sin(x))
    # -------------------------------------------------------------------------
    (
        "exp(x)*cos(x)",
        lambda x: mp.exp(x) * mp.cos(x),
        {
            1: lambda x: mp.exp(x) * (mp.cos(x) - mp.sin(x)),
            2: lambda x: -2 * mp.exp(x) * mp.sin(x),
            3: lambda x: -2 * mp.exp(x) * (mp.sin(x) + mp.cos(x)),
            4: lambda x: -4 * mp.exp(x) * mp.cos(x),
            5: lambda x: -4 * mp.exp(x) * (mp.cos(x) - mp.sin(x)),
        }
    ),
    # -------------------------------------------------------------------------
    # sinh(x): derivatives alternate sinh → cosh → sinh → cosh
    # -------------------------------------------------------------------------
    (
        "sinh(x)",
        lambda x: mp.sinh(x),
        {
            1: lambda x: mp.cosh(x),
            2: lambda x: mp.sinh(x),
            3: lambda x: mp.cosh(x),
            4: lambda x: mp.sinh(x),
            5: lambda x: mp.cosh(x),
        }
    ),
    # -------------------------------------------------------------------------
    # cosh(x): derivatives alternate cosh → sinh → cosh → sinh
    # -------------------------------------------------------------------------
    (
        "cosh(x)",
        lambda x: mp.cosh(x),
        {
            1: lambda x: mp.sinh(x),
            2: lambda x: mp.cosh(x),
            3: lambda x: mp.sinh(x),
            4: lambda x: mp.cosh(x),
            5: lambda x: mp.sinh(x),
        }
    ),
    # -------------------------------------------------------------------------
    # log(1+x):
    # d/dx = 1/(1+x)
    # d²/dx² = -1/(1+x)²
    # d³/dx³ = 2/(1+x)³
    # d⁴/dx⁴ = -6/(1+x)⁴
    # d⁵/dx⁵ = 24/(1+x)⁵
    # General: dⁿ/dxⁿ log(1+x) = (-1)^{n+1} (n-1)! / (1+x)^n
    # -------------------------------------------------------------------------
    (
        "log(1+x)",
        lambda x: mp.log(1 + x),
        {
            1: lambda x: 1 / (1 + x),
            2: lambda x: -1 / (1 + x) ** 2,
            3: lambda x: 2 / (1 + x) ** 3,
            4: lambda x: -6 / (1 + x) ** 4,
            5: lambda x: 24 / (1 + x) ** 5,
        }
    ),
    # -------------------------------------------------------------------------
    # x^5:
    # d/dx = 5x^4
    # d²/dx² = 20x³
    # d³/dx³ = 60x²
    # d⁴/dx⁴ = 120x
    # d⁵/dx⁵ = 120
    # -------------------------------------------------------------------------
    (
        "x^5",
        lambda x: x ** 5,
        {
            1: lambda x: 5 * x ** 4,
            2: lambda x: 20 * x ** 3,
            3: lambda x: 60 * x ** 2,
            4: lambda x: 120 * x,
            5: lambda x: mp.mpf(120),
        }
    ),
    # -------------------------------------------------------------------------
    # 1/(1+x²):
    # Let u = 1+x². Then f = u^{-1}
    # d/dx = -2x/(1+x²)²
    # d²/dx² = (6x²-2)/(1+x²)³ = 2(3x²-1)/(1+x²)³
    # d³/dx³ = -24x(x²-1)/(1+x²)⁴
    # d⁴/dx⁴ = 24(5x⁴ - 10x² + 1)/(1+x²)⁵
    # d⁵/dx⁵ = -240x(3x⁴ - 10x² + 3)/(1+x²)⁶
    # -------------------------------------------------------------------------
    (
        "1/(1+x²)",
        lambda x: 1 / (1 + x ** 2),
        {
            1: lambda x: -2 * x / (1 + x ** 2) ** 2,
            2: lambda x: 2 * (3 * x ** 2 - 1) / (1 + x ** 2) ** 3,
            3: lambda x: -24 * x * (x ** 2 - 1) / (1 + x ** 2) ** 4,
            4: lambda x: 24 * (5 * x ** 4 - 10 * x ** 2 + 1) / (1 + x ** 2) ** 5,
            5: lambda x: -240 * x * (3 * x ** 4 - 10 * x ** 2 + 3) / (1 + x ** 2) ** 6,
        }
    ),
    # -------------------------------------------------------------------------
    # exp(-x²): Gaussian
    # d/dx = -2x exp(-x²)
    # d²/dx² = (4x² - 2) exp(-x²)
    # d³/dx³ = (-8x³ + 12x) exp(-x²) = -4x(2x² - 3) exp(-x²)
    # d⁴/dx⁴ = (16x⁴ - 48x² + 12) exp(-x²)
    # d⁵/dx⁵ = (-32x⁵ + 160x³ - 120x) exp(-x²)
    # -------------------------------------------------------------------------
    (
        "exp(-x²)",
        lambda x: mp.exp(-x ** 2),
        {
            1: lambda x: -2 * x * mp.exp(-x ** 2),
            2: lambda x: (4 * x ** 2 - 2) * mp.exp(-x ** 2),
            3: lambda x: -4 * x * (2 * x ** 2 - 3) * mp.exp(-x ** 2),
            4: lambda x: (16 * x ** 4 - 48 * x ** 2 + 12) * mp.exp(-x ** 2),
            5: lambda x: (-32 * x ** 5 + 160 * x ** 3 - 120 * x) * mp.exp(-x ** 2),
        }
    ),
]

for order in range(1, 6):
    print(f"\n{'─' * 100}")
    print(f"ORDER {order} DERIVATIVES")
    print(f"{'─' * 100}")
    print(f"{'Function':<20} {'φ-time(s)':<12} {'Result':<26} {'AbsErr':<24}")
    print(f"{'─' * 100}")

    for name, f, truths in diff_tests:
        t0 = time.perf_counter()
        result, diag = eng.differentiate(f, x0, order=order, name=name)
        elapsed = time.perf_counter() - t0

        truth = truths[order](x0)
        err = abs(result - truth)

        if err == 0:
            err_str = "0.0"
        else:
            err_str = mp.nstr(err, 6)

        print(f"{name:<20} {elapsed:<12.6f} {mp.nstr(result, 15):<26} {err_str:<24}")

# =============================================================================
# INTEGRATION SHOWCASE — ORDERS 1 THROUGH 4
# Analytic closed-form truths only
# =============================================================================

print("\n" + "=" * 100)
print("φ-ENGINE INTEGRATION SHOWCASE — ORDERS 1 THROUGH 4")
print("=" * 100)
print(f"Interval: [0, 1]")
print(f"Dyadic depth: 4")
print("=" * 100)

a = Fraction(0, 1)
b = Fraction(1, 1)

# Each entry: (name, f, {order: truth_value})
# Truths are the r-th iterated integral from 0 to 1

int_tests = [
    # -------------------------------------------------------------------------
    # exp(x): ∫^r e^x = e - Σ_{k=0}^{r-1} 1/k!
    # -------------------------------------------------------------------------
    (
        "exp(x)",
        lambda x: mp.exp(x),
        {
            1: mp.e - 1,
            2: mp.e - 2,
            3: mp.e - mp.mpf(5) / 2,
            4: mp.e - mp.mpf(8) / 3,
        }
    ),
    # -------------------------------------------------------------------------
    # sin(x):
    # ∫ sin = 1 - cos(1)
    # ∫² sin = 1 - sin(1)
    # ∫³ sin = cos(1) - 1 + 1/2
    # ∫⁴ sin = sin(1) - 1 + 1/6
    # -------------------------------------------------------------------------
    (
        "sin(x)",
        lambda x: mp.sin(x),
        {
            1: 1 - mp.cos(1),
            2: 1 - mp.sin(1),
            3: mp.cos(1) - 1 + mp.mpf(1) / 2,
            4: mp.sin(1) - 1 + mp.mpf(1) / 6,
        }
    ),
    # -------------------------------------------------------------------------
    # cos(x):
    # ∫ cos = sin(1)
    # ∫² cos = 1 - cos(1)
    # ∫³ cos = 1 - sin(1) - 1/2 = 1/2 - sin(1)
    # ∫⁴ cos = 1 - cos(1) - 1/6 = 5/6 - cos(1)
    # -------------------------------------------------------------------------
    (
        "cos(x)",
        lambda x: mp.cos(x),
        {
            1: mp.sin(1),
            2: 1 - mp.cos(1),
            3: mp.mpf(1) / 2 - mp.sin(1),
            4: mp.mpf(5) / 6 - mp.cos(1),
        }
    ),
    # -------------------------------------------------------------------------
    # sinh(x):
    # ∫ sinh = cosh(1) - 1
    # ∫² sinh = sinh(1) - 1
    # ∫³ sinh = cosh(1) - 1 - 1/2
    # ∫⁴ sinh = sinh(1) - 1 - 1/6
    # -------------------------------------------------------------------------
    (
        "sinh(x)",
        lambda x: mp.sinh(x),
        {
            1: mp.cosh(1) - 1,
            2: mp.sinh(1) - 1,
            3: mp.cosh(1) - 1 - mp.mpf(1) / 2,
            4: mp.sinh(1) - 1 - mp.mpf(1) / 6,
        }
    ),
    # -------------------------------------------------------------------------
    # cosh(x):
    # ∫ cosh = sinh(1)
    # ∫² cosh = cosh(1) - 1
    # ∫³ cosh = sinh(1) - 1
    # ∫⁴ cosh = cosh(1) - 1 - 1/2
    # -------------------------------------------------------------------------
    (
        "cosh(x)",
        lambda x: mp.cosh(x),
        {
            1: mp.sinh(1),
            2: mp.cosh(1) - 1,
            3: mp.sinh(1) - 1,
            4: mp.cosh(1) - 1 - mp.mpf(1) / 2,
        }
    ),
    # -------------------------------------------------------------------------
    # x^n: ∫^r x^n = 1/[(n+1)(n+2)...(n+r)]
    # -------------------------------------------------------------------------
    (
        "x",
        lambda x: x,
        {
            1: mp.mpf(1) / 2,
            2: mp.mpf(1) / 6,
            3: mp.mpf(1) / 24,
            4: mp.mpf(1) / 120,
        }
    ),
    (
        "x²",
        lambda x: x ** 2,
        {
            1: mp.mpf(1) / 3,
            2: mp.mpf(1) / 12,
            3: mp.mpf(1) / 60,
            4: mp.mpf(1) / 360,
        }
    ),
    (
        "x³",
        lambda x: x ** 3,
        {
            1: mp.mpf(1) / 4,
            2: mp.mpf(1) / 20,
            3: mp.mpf(1) / 120,
            4: mp.mpf(1) / 840,
        }
    ),
    # -------------------------------------------------------------------------
    # exp(x)*sin(x): computed via Cauchy formula
    # ∫₀¹ e^t sin(t) dt = (e(sin1 - cos1) + 1)/2
    # Higher orders computed symbolically
    # -------------------------------------------------------------------------
    (
        "exp(x)*sin(x)",
        lambda x: mp.exp(x) * mp.sin(x),
        {
            1: (mp.e * (mp.sin(1) - mp.cos(1)) + 1) / 2,
            2: (mp.e * (2 - 2 * mp.cos(1)) - 1) / 4,
            3: (mp.e * (3 * mp.sin(1) - mp.cos(1) - 2) + 2) / 8,
            4: (mp.e * (4 - 4 * mp.cos(1) - 2 * mp.sin(1)) - 1) / 16,
        }
    ),
    # -------------------------------------------------------------------------
    # exp(x)*cos(x):
    # ∫₀¹ e^t cos(t) dt = (e(sin1 + cos1) - 1)/2
    # -------------------------------------------------------------------------
    (
        "exp(x)*cos(x)",
        lambda x: mp.exp(x) * mp.cos(x),
        {
            1: (mp.e * (mp.sin(1) + mp.cos(1)) - 1) / 2,
            2: (mp.e * 2 * mp.sin(1) - 1) / 4,
            3: (mp.e * (mp.sin(1) + 3 * mp.cos(1) - 2) - 1) / 8,
            4: (mp.e * (4 * mp.sin(1) + 2 * mp.cos(1) - 2) - 1) / 16,
        }
    ),
]

for order in range(1, 5):
    print(f"\n{'─' * 100}")
    print(f"ORDER {order} INTEGRALS")
    print(f"{'─' * 100}")
    print(f"{'Function':<20} {'φ-time(s)':<12} {'Result':<26} {'RelErr':<24}")
    print(f"{'─' * 100}")

    for name, f, truths in int_tests:
        t0 = time.perf_counter()
        result, diag = eng.integrate(f, a, b, order=order, dyadic_depth=5, name=name)
        elapsed = time.perf_counter() - t0

        truth = truths[order]

        if truth != 0:
            rel_err = abs(result - truth) / abs(truth)
        else:
            rel_err = abs(result - truth)

        if rel_err == 0:
            err_str = "0.0"
        elif rel_err < mp.mpf("1e-100"):
            err_str = "< 1e-100"
        else:
            err_str = mp.nstr(rel_err, 6)

        print(f"{name:<20} {elapsed:<12.6f} {mp.nstr(result, 15):<26} {err_str:<24}")

print("\n" + "=" * 100)
print("SHOWCASE COMPLETE")
print("=" * 100)
