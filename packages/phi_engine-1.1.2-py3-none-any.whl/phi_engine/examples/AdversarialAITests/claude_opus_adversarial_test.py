# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/claude_opus_adversarial_test.py

"""
Private test: Claude Opus Adversarial Test.
"""

from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
import sys

sys.set_int_max_str_digits(200000)


cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=13,
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=10000,
    display_digits=30,
    suppress_guarantee=False,
)
mp.dps = 20000
eng = PhiEngine(cfg)

x0 = mp.mpf('0.7')

tests = [
    # 1. Exponential of oscillation with polynomial phase
    ("exp(sin(x^3 + x^2))",
     lambda x: mp.exp(mp.sin(x ** 3 + x ** 2)),
     lambda x: mp.exp(mp.sin(x ** 3 + x ** 2)) * mp.cos(x ** 3 + x ** 2) * (3 * x ** 2 + 2 * x)),

    # 2. Nested trig with exponential envelope
    ("exp(x^2) * sin(cos(x^3))",
     lambda x: mp.exp(x ** 2) * mp.sin(mp.cos(x ** 3)),
     lambda x: (2 * x * mp.exp(x ** 2) * mp.sin(mp.cos(x ** 3))
                + mp.exp(x ** 2) * mp.cos(mp.cos(x ** 3)) * (-mp.sin(x ** 3)) * 3 * x ** 2)),

    # 3. High frequency with exponential growth competing
    ("exp(x^3) * sin(1e15 * x)",
     lambda x: mp.exp(x ** 3) * mp.sin(mp.mpf('1e15') * x),
     lambda x: (3 * x ** 2 * mp.exp(x ** 3) * mp.sin(mp.mpf('1e15') * x)
                + mp.exp(x ** 3) * mp.cos(mp.mpf('1e15') * x) * mp.mpf('1e15'))),

    # 4. Bessel with exponential argument
    ("besselj(0, exp(x^2))",
     lambda x: mp.besselj(0, mp.exp(x ** 2)),
     lambda x: -mp.besselj(1, mp.exp(x ** 2)) * mp.exp(x ** 2) * 2 * x),

    # 5. Log-trig-exp composite
    ("log(2 + sin(x^2)) * exp(cos(x))",
     lambda x: mp.log(2 + mp.sin(x ** 2)) * mp.exp(mp.cos(x)),
     lambda x: ((2 * x * mp.cos(x ** 2)) / (2 + mp.sin(x ** 2)) * mp.exp(mp.cos(x))
                + mp.log(2 + mp.sin(x ** 2)) * mp.exp(mp.cos(x)) * (-mp.sin(x)))),

    # 6. The cruelty: triple composition with high frequency
    ("sin(exp(cos(1e10 * x^2)))",
     lambda x: mp.sin(mp.exp(mp.cos(mp.mpf('1e10') * x ** 2))),
     lambda x: (mp.cos(mp.exp(mp.cos(mp.mpf('1e10') * x ** 2)))
                * mp.exp(mp.cos(mp.mpf('1e10') * x ** 2))
                * (-mp.sin(mp.mpf('1e10') * x ** 2))
                * mp.mpf('1e10') * 2 * x)),
]

diags = []
used_dps_maxs = []

for label, f, f_prime in tests:
    print(f"Testing: {label}")
    result, diag = eng.differentiate(f, x0, name=label)
    truth = f_prime(x0)
    err = abs(result - truth)
    used_dps_maxs.append(diag.get("used_dps_max", 0))

    diag.update({
        "function": label,
        "result": result,
        "truth": truth,
        "error": err,
    })
    diags.append(diag)

    print(f"  Result: {mp.nstr(result, 40)}")
    print(f"  Truth:  {mp.nstr(truth, 40)}")
    print(f"  Error:  {mp.nstr(err, 10)}")
    print()

print("=" * 80)
print(f"Max DPS used across all tests: {max(used_dps_maxs)}")
print("=" * 80)
