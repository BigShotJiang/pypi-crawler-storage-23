# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/claude_opus_adversarial_test_2.py

"""
Claude Opus Test 2.
"""

import sys

sys.set_int_max_str_digits(200000)

from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

mp.dps = 1000

cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=10,
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=2000,
    display_digits=30,
    suppress_guarantee=False,
)

eng = PhiEngine(cfg)

tests = [
    # 1. Derivative at 10^44
    ("exp(x^2) at x=10",
     mp.mpf('10'),
     lambda x: mp.exp(x ** 2),
     lambda x: 2 * x * mp.exp(x ** 2)),

    # 2. Derivative at 10^-43
    ("exp(-x^2) at x=10",
     mp.mpf('10'),
     lambda x: mp.exp(-x ** 2),
     lambda x: -2 * x * mp.exp(-x ** 2)),

    # 3. Near-zero but not exactly zero: cos(x) at x=pi/4
    ("cos(x) at x=pi/4",
     mp.pi/4,
     lambda x: mp.cos(x),
     lambda x: -mp.sin(x)),

    # 4. Derivative = -1 exactly
    ("sin(x) at x=pi",
     mp.pi,
     lambda x: mp.sin(x),
     lambda x: mp.cos(x)),

    # 5. Derivative at 10^66
    ("exp(exp(x)) at x=5",
     mp.mpf('5'),
     lambda x: mp.exp(mp.exp(x)),
     lambda x: mp.exp(mp.exp(x)) * mp.exp(x)),

    # 6. Derivative at 10^-63
    ("exp(-exp(x)) at x=5",
     mp.mpf('5'),
     lambda x: mp.exp(-mp.exp(x)),
     lambda x: -mp.exp(-mp.exp(x)) * mp.exp(x)),

    # 7. Gamma at x=5.5 (safe from poles)
    ("gamma(x) at x=5.5",
     mp.mpf('5.5'),
     lambda x: mp.gamma(x),
     lambda x: mp.gamma(x) * mp.digamma(x)),

    # 8. Digamma itself at x=3.7
    ("digamma(x) at x=3.7",
     mp.mpf('3.7'),
     lambda x: mp.digamma(x),
     lambda x: mp.psi(1, x)),  # trigamma = psi(1, x)

    # 9. Lambert W at x=1
    ("lambertw(x) at x=1",
     mp.mpf('1'),
     lambda x: mp.lambertw(x),
     lambda x: mp.lambertw(x) / (x * (1 + mp.lambertw(x)))),

    # 10. Zeta at x=3 (away from pole at x=1)
    ("zeta(x) at x=3",
     mp.mpf('3'),
     lambda x: mp.zeta(x),
     lambda x: mp.mpf(mp.diff(mp.zeta, x))),

    # 11. The monster: gamma(x) * sin(x^2) at x=4.3
    ("gamma(x)*sin(x^2) at x=4.3",
     mp.mpf('4.3'),
     lambda x: mp.gamma(x) * mp.sin(x ** 2),
     lambda x: mp.gamma(x) * mp.digamma(x) * mp.sin(x ** 2) + mp.gamma(x) * mp.cos(x ** 2) * 2 * x),
]

print("=" * 90)
print("SCALE INVARIANCE TEST: Safe from poles")
print("=" * 90)
print()

for label, x0, f, f_prime in tests:
    print(f"Testing: {label}")
    result, diag = eng.differentiate(f, x0, name=label)
    truth = f_prime(x0)

    if abs(truth) > 1e-10000:
        abs_err = abs(result - truth)
        rel_err = abs_err / abs(truth)
        correct = -mp.log10(rel_err) if rel_err > 0 else mp.mpf('inf')
    else:
        abs_err = abs(result - truth)
        correct = -mp.log10(abs_err) if abs_err > 0 else mp.mpf('inf')

    mag = int(mp.log10(abs(truth))) if abs(truth) > 1e-10000 else '~0'

    print(f"  x0:     {x0}")
    print(f"  Result: {mp.nstr(result, 40)}")
    print(f"  Truth:  {mp.nstr(truth, 40)}")
    print(f"  Magnitude of derivative: 10^{mag}")
    print(f"  Correct digits: {int(correct) if correct < 10000 else '>10000'}")
    print(f"  Time: {diag.get('timing_s', 0):.4f}s")
    print()

print("=" * 90)
print("Test complete.")
print("=" * 90)
