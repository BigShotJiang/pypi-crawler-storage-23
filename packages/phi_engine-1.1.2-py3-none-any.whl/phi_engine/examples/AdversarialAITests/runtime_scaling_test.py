# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/runtime_scaling_test.py

"""
φ-Engine Runtime Scaling Test — Constant-Time Across Orders
=============================================================

Demonstrates that φ-engine runtime is effectively O(N-k): higher
derivative orders are FASTER because order k removes k terms from
the contraction window. This is the opposite of classical methods
where higher order = more computation.

Parts:
  1. Differentiation timing — exp(x), orders 1–11
  2. Differentiation timing — sin(x), orders 1–11
  3. Differentiation timing — exp(3x)·sin(5x), orders 1–11
  4. Integration timing — multiple functions, dyadic depths 3–5
  5. Summary

Truth oracles are hardcoded — no mp.diff or mp.quad.
"""

from mpmath import mp, mpf
from fractions import Fraction as PyFraction
import time

# ── Engine imports (adjust if needed) ──
try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine, PhiEngineConfig

try:
    from core._rational import Fraction
except ImportError:
    Fraction = PyFraction


def _to_mpf(x):
    if hasattr(x, "numerator") and hasattr(x, "denominator"):
        try:
            return mp.mpf(x.numerator) / mp.mpf(x.denominator)
        except Exception:
            pass
    if hasattr(x, "p") and hasattr(x, "q"):
        return mp.mpf(int(x.p)) / mp.mpf(int(x.q))
    try:
        return mp.mpf(x)
    except TypeError:
        return mp.mpf(str(x))


def main():
    mp.dps = 100  # for truth computation only

    # ── Engine config ──
    cfg = PhiEngineConfig(
        base_dps=50,
        fib_count=13,
        per_term_guard=True,
        return_diagnostics=True,
        timing=True,
        show_error=False,
        max_dps=10000,
    )
    eng = PhiEngine(cfg)

    x0 = mpf("0.5")

    # ══════════════════════════════════════════════════════
    # PART 1: Differentiation — exp(x)
    # All derivatives of exp(x) = exp(x)
    # ══════════════════════════════════════════════════════

    print("=" * 90)
    print("PART 1: DIFFERENTIATION TIMING — exp(x) at x0 = 0.5")
    print("All orders: truth = exp(0.5)")
    print("fib_count = 13, max_dps = 10000")
    print("=" * 90)

    def F_exp(x):
        return mp.exp(x)

    truth_exp = mp.exp(x0)

    # Warmup: run order 1 once to prime caches
    _ = eng.differentiate(F_exp, x0, order=1, parallel=True)

    print(f"\n  {'Order':>6} {'Time (s)':>12} {'Error':>20} {'Digits':>8} {'Max DPS':>10} {'Terms':>6}")
    print(f"  {'─' * 70}")

    max_order = 11  # fib_count=13 means N=12 terms, so max order for odd = 2*12-1 = 23
    timing_data = []

    for order in range(1, max_order + 1):
        # Run multiple times for stable timing
        times = []
        result = None
        diag = None
        for _ in range(3):
            t0 = time.perf_counter()
            result, diag = eng.differentiate(F_exp, x0, order=order)
            t1 = time.perf_counter()
            times.append(t1 - t0)

        avg_time = sum(times) / len(times)
        min_time = min(times)

        err = mp.fabs(_to_mpf(result) - truth_exp)
        if err > 0:
            digits = -float(mp.log10(err / mp.fabs(truth_exp)))
        else:
            digits = 999.0

        max_dps_used = max(diag.get("used_dps_list", [50])) if isinstance(diag, dict) else 0
        n_terms = diag.get("terms_evaluated", "?") if isinstance(diag, dict) else "?"

        timing_data.append((order, min_time, digits))
        print(f"  {order:>6} {min_time:>12.6f} {mp.nstr(err, 6):>20} {digits:>8.1f} {max_dps_used:>10} {n_terms!s:>6}")

    # ══════════════════════════════════════════════════════
    # PART 2: Differentiation — sin(x)
    # d^k/dx^k sin(x) cycles: cos, -sin, -cos, sin, ...
    # ══════════════════════════════════════════════════════

    print("\n\n" + "=" * 90)
    print("PART 2: DIFFERENTIATION TIMING — sin(x) at x0 = 0.5")
    print("fib_count = 13, max_dps = 10000")
    print("=" * 90)

    def F_sin(x):
        return mp.sin(x)

    # Hardcoded truth for d^k/dx^k sin(x):
    # k%4 == 0: sin(x), k%4 == 1: cos(x), k%4 == 2: -sin(x), k%4 == 3: -cos(x)
    def sin_truth(x, k):
        r = k % 4
        if r == 0:
            return mp.sin(x)
        elif r == 1:
            return mp.cos(x)
        elif r == 2:
            return -mp.sin(x)
        else:
            return -mp.cos(x)

    # Warmup
    _ = eng.differentiate(F_sin, x0, order=1)

    print(f"\n  {'Order':>6} {'Time (s)':>12} {'Error':>20} {'Digits':>8}")
    print(f"  {'─' * 55}")

    for order in range(1, max_order + 1):
        truth_k = sin_truth(x0, order)
        times = []
        result = None
        for _ in range(3):
            t0 = time.perf_counter()
            result, diag = eng.differentiate(F_sin, x0, order=order)
            t1 = time.perf_counter()
            times.append(t1 - t0)

        min_time = min(times)
        err = mp.fabs(_to_mpf(result) - truth_k)
        if err > 0 and mp.fabs(truth_k) > 0:
            digits = -float(mp.log10(err / mp.fabs(truth_k)))
        elif err == 0:
            digits = 999.0
        else:
            digits = -float(mp.log10(err)) if err > 0 else 999.0

        print(f"  {order:>6} {min_time:>12.6f} {mp.nstr(err, 6):>20} {digits:>8.1f}")

    # ══════════════════════════════════════════════════════
    # PART 3: Harder function — exp(3x) * sin(5x)
    # d^k/dx^k [exp(ax)sin(bx)] has closed form
    # ══════════════════════════════════════════════════════

    print("\n\n" + "=" * 90)
    print("PART 3: DIFFERENTIATION TIMING — exp(3x)·sin(5x) at x0 = 0.5")
    print("fib_count = 13, max_dps = 10000")
    print("=" * 90)

    a_val = mpf("3")
    b_val = mpf("5")

    def F_expsin(x):
        return mp.exp(a_val * x) * mp.sin(b_val * x)

    # Truth: d^k/dx^k [exp(ax)sin(bx)] = r^k * exp(ax) * sin(bx + k*phi)
    # where r = sqrt(a² + b²), phi = atan2(b, a)
    r_val = mp.sqrt(a_val**2 + b_val**2)
    phi_val = mp.atan2(b_val, a_val)

    def expsin_truth(x, k):
        return r_val**k * mp.exp(a_val * x) * mp.sin(b_val * x + k * phi_val)

    _ = eng.differentiate(F_expsin, x0, order=1)

    print(f"\n  {'Order':>6} {'Time (s)':>12} {'Error':>20} {'Digits':>8} {'|f^(k)|':>14}")
    print(f"  {'─' * 70}")

    for order in range(1, max_order + 1):
        truth_k = expsin_truth(x0, order)
        times = []
        result = None
        for _ in range(3):
            t0 = time.perf_counter()
            result, diag = eng.differentiate(F_expsin, x0, order=order)
            t1 = time.perf_counter()
            times.append(t1 - t0)

        min_time = min(times)
        result_mpf = _to_mpf(result)
        err = mp.fabs(result_mpf - truth_k)
        truth_abs = mp.fabs(truth_k)
        if err > 0 and truth_abs > 0:
            digits = -float(mp.log10(err / truth_abs))
        elif err == 0:
            digits = 999.0
        else:
            digits = 0.0

        print(f"  {order:>6} {min_time:>12.6f} {mp.nstr(err, 6):>20} {digits:>8.1f} {mp.nstr(truth_abs, 6):>14}")

    # ══════════════════════════════════════════════════════
    # PART 4: Integration timing
    # ∫ exp(x) dx from 0 to 1 = e - 1
    # ∫ sin(x) dx from 0 to π = 2
    # ∫ exp(3x)sin(5x) dx from 0 to 1 = closed form
    # ══════════════════════════════════════════════════════

    print("\n\n" + "=" * 90)
    print("PART 4: INTEGRATION TIMING")
    print("fib_count = 13, max_dps = 10000")
    print("=" * 90)

    int_cases = []

    # Case 1: ∫₀¹ exp(x) dx = e - 1
    int_cases.append({
        "name": "exp(x) on [0, 1]",
        "func": lambda x: mp.exp(x),
        "a": Fraction(0),
        "b": Fraction(1),
        "truth": mp.exp(1) - 1,
    })

    # Case 2: ∫₀^π sin(x) dx = 2
    # Use a rational approximation of π for the endpoint
    # Actually, let's use ∫₀¹ sin(x) dx = 1 - cos(1) (exact, no π needed)
    int_cases.append({
        "name": "sin(x) on [0, 1]",
        "func": lambda x: mp.sin(x),
        "a": Fraction(0),
        "b": Fraction(1),
        "truth": 1 - mp.cos(1),
    })

    # Case 3: ∫₀¹ x² dx = 1/3
    int_cases.append({
        "name": "x² on [0, 1]",
        "func": lambda x: x * x,
        "a": Fraction(0),
        "b": Fraction(1),
        "truth": mpf("1") / 3,
    })

    # Case 4: ∫₀¹ exp(3x)sin(5x) dx — closed form
    # ∫ exp(ax)sin(bx) dx = exp(ax)(a·sin(bx) - b·cos(bx))/(a²+b²)
    def expsin_antideriv(x):
        ea = mp.exp(a_val * x)
        return ea * (a_val * mp.sin(b_val * x) - b_val * mp.cos(b_val * x)) / (a_val**2 + b_val**2)

    int_cases.append({
        "name": "exp(3x)sin(5x) on [0, 1]",
        "func": lambda x: mp.exp(mpf("3") * x) * mp.sin(mpf("5") * x),
        "a": Fraction(0),
        "b": Fraction(1),
        "truth": expsin_antideriv(mpf("1")) - expsin_antideriv(mpf("0")),
    })

    # Case 5: ∫₀¹ 1/(1+x²) dx = arctan(1) - arctan(0) = π/4
    int_cases.append({
        "name": "1/(1+x²) on [0, 1]",
        "func": lambda x: 1 / (1 + x * x),
        "a": Fraction(0),
        "b": Fraction(1),
        "truth": mp.pi / 4,
    })

    for dyadic_depth in [3, 4, 5]:
        print(f"\n  Dyadic depth = {dyadic_depth}")
        print(f"  {'Function':>30} {'Time (s)':>12} {'Error':>20} {'Digits':>8}")
        print(f"  {'─' * 75}")

        for case in int_cases:
            times = []
            result = None
            for _ in range(3):
                t0 = time.perf_counter()
                result, diag = eng.integrate(
                    case["func"], case["a"], case["b"],
                    dyadic_depth=dyadic_depth
                )
                t1 = time.perf_counter()
                times.append(t1 - t0)

            min_time = min(times)
            result_mpf = _to_mpf(result)
            truth = case["truth"]
            err = mp.fabs(result_mpf - truth)
            if err > 0 and mp.fabs(truth) > 0:
                digits = -float(mp.log10(err / mp.fabs(truth)))
            elif err == 0:
                digits = 999.0
            else:
                digits = 0.0

            print(f"  {case['name']:>30} {min_time:>12.6f} {mp.nstr(err, 6):>20} {digits:>8.1f}")

    # ══════════════════════════════════════════════════════
    # PART 5: Timing scaling summary
    # ══════════════════════════════════════════════════════

    print("\n\n" + "=" * 90)
    print("PART 5: TIMING SUMMARY — Does higher order = faster?")
    print("=" * 90)
    print("\nIf O(N-k) holds, we should see monotonically decreasing times")
    print("as order increases, because each order removes a term from the window.")
    print("\nRefer to the timing columns above for all three test functions.")
    print("The time column shows the minimum of 3 runs (wall clock, seconds).")


if __name__ == "__main__":
    main()
