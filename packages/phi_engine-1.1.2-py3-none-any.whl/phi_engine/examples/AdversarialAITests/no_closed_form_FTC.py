# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/no_closed_form_FTC.py

"""No Closed Form.
"""

from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

mp.dps = 200
cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=11,
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=500,
    display_digits=30,
    suppress_guarantee=False,
)

eng = PhiEngine(cfg)


# Fundamental theorem of calculus test:
# g(x) = integral from 0 to x of exp(-t^2) * sin(t^3) dt
# g'(x) should equal exp(-x^2) * sin(x^3)

def g(x):
    """No closed form. Must integrate numerically."""
    if x == 0:
        return mp.mpf(0)
    return mp.quad(lambda t: mp.exp(-t ** 2) * mp.sin(t ** 3), [0, x])


def g_prime_truth(x):
    """The integrand — what the derivative should be."""
    return mp.exp(-x ** 2) * mp.sin(x ** 3)


print("=" * 80)
print("FUNDAMENTAL THEOREM OF CALCULUS")
print("g(x) = ∫₀ˣ exp(-t²)sin(t³) dt")
print("g'(x) should equal exp(-x²)sin(x³)")
print("=" * 80)
print()

test_points = [mp.mpf('0.5'), mp.mpf('1.0'), mp.mpf('1.5'), mp.mpf('2.0')]

for x0 in test_points:
    print(f"x = {x0}")

    # φ-engine differentiates the integral
    result, diag = eng.differentiate(g, x0, name="∫exp(-t²)sin(t³)dt", parallel=True)

    # Truth is just the integrand
    truth = g_prime_truth(x0)

    err = abs(result - truth)
    if truth != 0:
        correct_digits = -mp.log10(err / abs(truth)) if err > 0 else mp.inf
    else:
        correct_digits = -mp.log10(err) if err > 0 else mp.inf

    print(f"  g(x):        {mp.nstr(g(x0), 20)}")
    print(f"  φ-engine:    {mp.nstr(result, 25)}")
    print(f"  truth:       {mp.nstr(truth, 25)}")
    print(f"  error:       {mp.nstr(err, 10)}")
    print(f"  correct:     ~{int(correct_digits)} digits")
    print(f"  time:        {diag.get('timing_s', 0):.4f}s")
    print()

print("=" * 80)
print("The derivative was recovered from the integral — no closed form used.")
print("=" * 80)
