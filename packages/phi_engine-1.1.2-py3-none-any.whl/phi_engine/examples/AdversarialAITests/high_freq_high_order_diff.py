# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/high_freq_high_order_diff.py

"""High-Frequency, High-Order Differentiation Test.

Computes d^11/dx^11 sin(100x) at x=50.0 — a regime where the derivative
amplitude reaches ~10^22 and classical finite differences are hopeless.
Verifies superfactorial error decay, precision inversion, and correct
amplitude recovery.
"""

import time
from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig


# Configuration - intentionally using LESS precision than differentiation demo
# to test whether structural guarantees hold even with reduced working precision
cfg = PhiEngineConfig(
    base_dps=100,        # Even less than before (was 150)
    fib_count=15,        # Same as your demo
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=5000,        # Keep the handicap
    display_digits=15,   # Show more digits for verification
    report_col_width=28,
    suppress_guarantee=True,
)

eng = PhiEngine(cfg)

# Set ground truth precision very high to verify correctness
mp.dps = 10000


# Target function: sin(100x)
def F(x):
    return mp.sin(100 * x)


# Ground truth: d^11/dx^11[sin(100x)] = -100^11 * cos(100x)
def F11_analytical(x):
    return -(100**11) * mp.cos(100 * x)


def fmt_sci(x, sig=6) -> str:
    """mpmath-safe scientific formatting (works for mpf/mpc) without float conversion."""
    return mp.nstr(x, n=sig, min_fixed=0, max_fixed=0)


# Evaluation point
x0 = mp.mpf("50.0")

print("=" * 80)
print("ADVERSARIAL TEST: High-Frequency, High-Order, Large Displacement")
print("=" * 80)
print("Function: sin(100x)")
print("Derivative order: 11")
print(f"Evaluation point: x = {x0}")
print("Expected amplitude: ~10^22")
print(f"Working precision cap: {cfg.max_dps} digits")
print("=" * 80)
print()

t0 = time.perf_counter()

result, diag = eng.differentiate(
    F,
    x0,
    order=11,
    name="sin(100x)",
)

elapsed = time.perf_counter() - t0

truth = F11_analytical(x0)
abs_err = abs(result - truth)
rel_err = abs_err / abs(truth) if truth != 0 else mp.inf

# Compute correct digits safely
if rel_err == 0:
    correct_digits_str = "inf"
elif rel_err == mp.inf:
    correct_digits_str = "0"
else:
    correct_digits_str = mp.nstr(-mp.log10(rel_err), n=8)

print(f"φ-Engine result:  {mp.nstr(result)}")
print(f"Analytical truth: {mp.nstr(truth)}")
print(f"Absolute error:   {fmt_sci(abs_err, sig=6)}")
print(f"Relative error:   {fmt_sci(rel_err, sig=6)}")
print(f"Correct digits:   ~{correct_digits_str}")
print(f"Wall time:        {elapsed:.4f} s")
print(f"Max DPS used:     {diag.get('used_dps_max', 'N/A')}")
print()

# Verification checks
print("=" * 80)
print("VERIFICATION CHECKS:")
print("=" * 80)

# Check 1: Is the error superfactorially small?
if abs_err < mp.mpf("1e-100"):
    print("✓ PASS: Error is superfactorially small (< 10^-100)")
else:
    print(f"✗ FAIL: Error is too large ({fmt_sci(abs_err, sig=3)})")

# Check 2: Is the timing reasonable?
if elapsed < 1.0:
    print(f"✓ PASS: Timing is fast ({elapsed:.4f}s < 1s)")
else:
    print(f"⚠ WARN: Timing is slow ({elapsed:.4f}s)")

# Check 3: Did it use less working precision than output precision?
output_precision = (-mp.log10(rel_err) if (rel_err not in (0, mp.inf)) else (mp.inf if rel_err == 0 else mp.mpf("0")))
working_precision = diag.get("used_dps_max", 0)
if output_precision > working_precision:
    outp_str = "inf" if output_precision == mp.inf else mp.nstr(output_precision, n=10)
    print(f"✓ PASS: Precision inversion ({outp_str} output > {working_precision} working)")
else:
    outp_str = "inf" if output_precision == mp.inf else mp.nstr(output_precision, n=10)
    print(f"✗ FAIL: No precision inversion ({outp_str} output ≤ {working_precision} working)")

# Check 4: Is the amplitude correct?
expected_amplitude = 100**11
actual_amplitude = abs(result)
amplitude_ratio = actual_amplitude / expected_amplitude
if mp.mpf("0.1") < amplitude_ratio < mp.mpf("10"):  # Within order of magnitude
    print(f"✓ PASS: Amplitude is correct (~10^22, ratio={mp.nstr(amplitude_ratio, n=6)})")
else:
    print(
        "✗ FAIL: Amplitude is wrong "
        f"(expected ~{expected_amplitude:.2e}, got {mp.nstr(actual_amplitude, n=6, min_fixed=0, max_fixed=0)})"
    )

print("=" * 80)
