# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/test_airy_hybrid.py

"""
φ-engine hybrid routing test: Airy function Ai(x)

Airy functions are expensive per-evaluation — they involve convergent
series / asymptotic expansions internally, so each mpmath.airyai(x) call
is significantly heavier than a single exp(). This makes Airy a natural
test case for hybrid CUDA routing where parallel dispatch should show
real wall-clock gains over sequential CPU.

Usage:
    python test_airy_hybrid.py
"""

import torch
from mpmath import mp

try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig, Fraction, ParallelBackend, EvalCtx

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core._rational import Fraction
    from core._parallel import ParallelBackend, EvalCtx

# --------------------------------------------------
# Device setup
# --------------------------------------------------

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.set_default_dtype(torch.float64)

# --------------------------------------------------
# Hybrid callable: Airy Ai(x)
# --------------------------------------------------

def airy(x, ctx: EvalCtx = None):
    backend = getattr(ctx, "backend", "?")
    if backend == "cuda":
        return cuda_airy(x)
    elif backend == "cpu":
        return cpu_airy(x)
    else:
        return cpu_airy(x)


def cuda_airy(x):
    """
    GPU path: convert to float64, use torch.special.airy_ai.
    Available since PyTorch 1.13+.
    """
    x_f = float(mp.nstr(x, 17))
    t = torch.tensor([x_f], dtype=torch.float64, device=DEVICE)
    with torch.no_grad():
        y = torch.special.airy_ai(t)
    return float(y.item())


def cpu_airy(x):
    """CPU path: full mpmath arbitrary-precision Airy Ai."""
    return mp.airyai(x)


# --------------------------------------------------
# Closed-form derivatives of Ai(x) via mpmath
#
# Ai'(x)  = airyai(x, derivative=1)
# Ai''(x) = x * Ai(x)            (defining ODE: y'' - x*y = 0)
# Ai'''(x) = Ai(x) + x * Ai'(x)  (differentiate the ODE)
# --------------------------------------------------

def d_airy(x, order):
    x = mp.mpf(x)
    ai  = mp.airyai(x)
    aip = mp.airyai(x, derivative=1)

    if order == 1:
        return aip
    elif order == 2:
        return x * ai
    elif order == 3:
        return ai + x * aip
    else:
        raise ValueError(f"Oracle not implemented for order {order}")


# --------------------------------------------------
# Engine config
# --------------------------------------------------

cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=9,
    timing=True,
    return_diagnostics=True,
    max_dps=1000,
    per_term_guard=True,
    suppress_guarantee=True,
    report_col_width=22,
    precision_policy="adaptive",
    header_keys=(
        "cpu_name",
        "gpu_name",
        "gpu_tasks_total",
        "cpu_tasks_total",
        "policy",
        "max_dps_used",
    ),
)

cfg.parallel.backend = ParallelBackend.CUDA_STREAMS
cfg.parallel.max_workers = 8

eng = PhiEngine(cfg)

# --------------------------------------------------
# Run
# --------------------------------------------------

title = "φ-ENGINE CUDA PARALLEL HYBRID-ROUTING TEST — AIRY Ai(x)"

mp.dps = 1000

x0 = mp.mpf("2.5")   # away from zero — Ai decays but derivatives are nontrivial

diags = []
used_dps_maxs_list = []

total_cuda_tasks = 0
total_cpu_tasks = 0

for order in range(1, 4):
    res, diag = eng.differentiate(
        airy,
        x0,
        order=order,
        name=f"Airy Ai  order {order}",
        parallel=True,
    )

    used_dps_maxs_list.append(diag.get("used_dps_max", 0))

    exec_info = diag.get("execution", {})
    cuda_count = exec_info.get("cuda_task_count", 0)
    cpu_count  = exec_info.get("cpu_task_count", 0)
    total_cuda_tasks += cuda_count
    total_cpu_tasks  += cpu_count

    truth = d_airy(x0, order)
    err = abs(res - truth)

    diag.update({
        "operation": "Differentiation",
        "result": res,
        "truth": truth,
        "error": err,
        "global_dps": mp.dps,
        "num_fibs": eng.config.fib_count,
        "evaluation_point": x0,
        "cuda_tasks": cuda_count,
        "cpu_tasks": cpu_count,
        "policy": exec_info.get("policy", "adaptive"),
    })

    diags.append(diag)

# --------------------------------------------------
# Batch summary
# --------------------------------------------------

env_info = diags[0].get("execution", {}).get("environment", {})

diags[0].update({
    "cpu_name": env_info.get("cpu_name", "?"),
    "gpu_name": env_info.get("gpu_name", "?"),
    "max_dps_used": max(used_dps_maxs_list),
    "cpu_tasks_total": total_cpu_tasks,
    "gpu_tasks_total": total_cuda_tasks,
})

eng.report(diags, title=title, batch=True)
