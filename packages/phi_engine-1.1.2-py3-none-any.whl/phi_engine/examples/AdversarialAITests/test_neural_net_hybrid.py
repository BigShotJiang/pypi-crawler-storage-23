# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/test_nn_hybrid_mpmath.py

"""
φ-engine hybrid routing test: Neural network with mpmath CPU backend

Demonstrates genuine CUDA/CPU hybrid dispatch on a neural network.

The key: with fib_count=12, the later β-coefficients are enormous.
The CUDA layer classifier determines which fibonacci layers survive
at float64 (~15 digits) after β amplification, and which layers
MUST go to CPU for arbitrary-precision mpmath evaluation.

  - GPU path: torch forward pass (float64, fast)
  - CPU path: mpmath forward pass (arbitrary precision, slow)

Same network, same weights, two precision regimes — the engine
decides the split automatically based on the β-amplification budget.

Truth reference: sequential all-CPU run at the same fib_count.
The mpmath path at high dps IS the ground truth for this function.
Finite differences are not used — they're garbage for this.

Usage:
    python test_nn_hybrid_mpmath.py
"""

import torch
import torch.nn as nn
from mpmath import mp, mpf

try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig, Fraction, ParallelBackend, EvalCtx

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core._rational import Fraction
    from core._parallel import ParallelBackend, EvalCtx

# --------------------------------------------------
# Device setup
# --------------------------------------------------

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.set_default_dtype(torch.float64)


# --------------------------------------------------
# Build a torch model and extract weights
# --------------------------------------------------

def build_tanh_mlp(hidden_dims, seed=42):
    torch.manual_seed(seed)
    layers = []
    in_dim = 1
    for h in hidden_dims:
        layers.append(nn.Linear(in_dim, h, dtype=torch.float64))
        layers.append(nn.Tanh())
        in_dim = h
    layers.append(nn.Linear(in_dim, 1, dtype=torch.float64))
    model = nn.Sequential(*layers)
    model.eval()
    return model


def extract_weights(model):
    """
    Extract (W, b) pairs from a Sequential model.
    Returns list of (weight_2d_list, bias_1d_list) as plain Python floats.
    """
    params = []
    for module in model.modules():
        if isinstance(module, nn.Linear):
            W = module.weight.detach().cpu().tolist()
            b = module.bias.detach().cpu().tolist()
            params.append((W, b))
    return params


# --------------------------------------------------
# mpmath forward pass (arbitrary precision)
# --------------------------------------------------

def mpmath_forward(x_mp, params):
    """
    Pure mpmath forward pass through a tanh MLP.

    x_mp : mpf scalar input
    params : list of (W, b) from extract_weights()

    Returns mpf scalar output.
    """
    a = [x_mp]

    for i, (W, b) in enumerate(params):
        out_dim = len(W)
        in_dim = len(W[0])

        z = []
        for row in range(out_dim):
            val = mpf(b[row])
            for col in range(in_dim):
                val += mpf(W[row][col]) * a[col]
            z.append(val)

        if i < len(params) - 1:
            a = [mp.tanh(zi) for zi in z]
        else:
            a = z

    return a[0]


# --------------------------------------------------
# Hybrid callable factory
# --------------------------------------------------

def make_hybrid_nn(model_gpu, params):
    """
    Returns a hybrid callable:
      - CUDA path: torch forward pass (float64)
      - CPU path: mpmath forward pass (arbitrary precision)

    Same network, same weights, two precision regimes.
    """

    @torch.no_grad()
    def nn_callable(x, ctx: EvalCtx = None):
        backend = getattr(ctx, "backend", "?")

        if backend == "cuda":
            x_f = float(mp.nstr(x, 17))
            t = torch.tensor([[x_f]], dtype=torch.float64, device=DEVICE)
            return float(model_gpu(t).item())
        else:
            return mpmath_forward(mp.mpf(x), params)

    return nn_callable


# --------------------------------------------------
# mpmath-only callable (for CPU baseline)
# --------------------------------------------------

def make_cpu_nn(params):
    """Pure mpmath callable — no torch, no CUDA."""

    def nn_callable(x, ctx: EvalCtx = None):
        return mpmath_forward(mp.mpf(x), params)

    return nn_callable


# --------------------------------------------------
# Helpers
# --------------------------------------------------

def _to_mpf(x):
    if hasattr(x, "numerator") and hasattr(x, "denominator"):
        try:
            return mp.mpf(x.numerator) / mp.mpf(x.denominator)
        except Exception:
            pass
    try:
        return mp.mpf(x)
    except TypeError:
        return mp.mpf(str(x))


# --------------------------------------------------
# Build models
# --------------------------------------------------

# 3-layer tanh net (light — fast mpmath forward pass)
light_dims = [32, 32, 32]
light_torch = build_tanh_mlp(light_dims, seed=42)
light_gpu = build_tanh_mlp(light_dims, seed=42).to(DEVICE)
light_params = extract_weights(light_torch)
light_hybrid = make_hybrid_nn(light_gpu, light_params)
light_cpu = make_cpu_nn(light_params)

# 5-layer tanh net (medium — heavier mpmath forward pass)
medium_dims = [48, 48, 32, 32, 16]
medium_torch = build_tanh_mlp(medium_dims, seed=123)
medium_gpu = build_tanh_mlp(medium_dims, seed=123).to(DEVICE)
medium_params = extract_weights(medium_torch)
medium_hybrid = make_hybrid_nn(medium_gpu, medium_params)
medium_cpu = make_cpu_nn(medium_params)


# --------------------------------------------------
# fib_count=12: forces genuine hybrid split
# Later β-coefficients overflow float64 budget → CPU
# Earlier β-coefficients fit float64 → CUDA
# --------------------------------------------------

FIB_COUNT = 11
MAX_DPS = 5000

mp.dps = MAX_DPS
x0 = mp.mpf("0.7")

test_cases = [
    ("tanh 3x32", light_hybrid, light_cpu),
    ("tanh 5x48", medium_hybrid, medium_cpu),
]


# ==========================================================
# PHASE 1: Sequential CPU baseline (this IS truth)
# ==========================================================

print("Phase 1: Sequential CPU baseline (mpmath only, ground truth)\n")

cfg_seq = PhiEngineConfig(
    base_dps=50,
    fib_count=FIB_COUNT,
    timing=True,
    return_diagnostics=True,
    max_dps=MAX_DPS,
    per_term_guard=True,
    show_error=False,
    suppress_guarantee=True,
    report_col_width=22,
    precision_policy="strict",
    header_keys=(
        "cpu_name",
        "policy",
        "max_dps_used",
    ),
)

eng_seq = PhiEngine(cfg_seq)

# Warmup
_ = eng_seq.differentiate(light_cpu, x0, order=1)

cpu_truths = {}  # (label, order) → mpf result
diags_seq = []
used_dps_seq = []

for label, _, F_cpu in test_cases:
    for order in range(1, 4):
        res, diag = eng_seq.differentiate(
            F_cpu,
            x0,
            order=order,
            name=f"{label} d{order}",
            parallel=False,
        )

        cpu_truths[(label, order)] = _to_mpf(res)
        used_dps_seq.append(diag.get("used_dps_max", 0))

        diag.update({
            "operation": "Differentiation",
            "result": res,
        })

        diags_seq.append(diag)

env_info_seq = diags_seq[0].get("execution", {}).get("environment", {})
diags_seq[0].update({
    "max_dps_used": max(used_dps_seq),
    "policy": "strict",
})

eng_seq.report(
    diags_seq,
    title="PHASE 1 — CPU BASELINE (mpmath only)",
    batch=True,
)

# ==========================================================
# PHASE 2: Hybrid CUDA/CPU dispatch
# ==========================================================

print("\nPhase 2: Hybrid CUDA/CPU dispatch\n")

cfg_hybrid = PhiEngineConfig(
    base_dps=50,
    fib_count=FIB_COUNT,
    timing=True,
    return_diagnostics=True,
    max_dps=MAX_DPS,
    per_term_guard=True,
    suppress_guarantee=True,
    report_col_width=22,
    precision_policy="adaptive",
    header_keys=(
        "cpu_name",
        "gpu_name",
        "gpu_tasks_total",
        "cpu_tasks_total",
        "policy",
        "max_dps_used",
    ),
)

cfg_hybrid.parallel.backend = ParallelBackend.CUDA_STREAMS
cfg_hybrid.parallel.max_workers = 8

eng_hybrid = PhiEngine(cfg_hybrid)

# Warmup
_ = eng_hybrid.differentiate(light_hybrid, x0, order=1, parallel=True)

diags_hybrid = []
hybrid_names = []
used_dps_hybrid = []
total_cuda_tasks = 0
total_cpu_tasks = 0

for label, F_hybrid, _ in test_cases:
    for order in range(1, 4):
        res, diag = eng_hybrid.differentiate(
            F_hybrid,
            x0,
            order=order,
            name=f"{label} d{order}",
            parallel=True,
        )

        used_dps_hybrid.append(diag.get("used_dps_max", 0))

        exec_info = diag.get("execution", {})
        cuda_count = exec_info.get("cuda_task_count", 0)
        cpu_count = exec_info.get("cpu_task_count", 0)
        total_cuda_tasks += cuda_count
        total_cpu_tasks += cpu_count

        # Compare to CPU truth
        truth = cpu_truths[(label, order)]
        hybrid_val = _to_mpf(res)

        if truth != 0:
            err = mp.fabs(hybrid_val - truth)
            rel_err = err / mp.fabs(truth)
            if rel_err > 0:
                digits = -float(mp.log10(rel_err))
            else:
                digits = 9999.0
        else:
            err = mp.fabs(hybrid_val)
            digits = -float(mp.log10(err)) if err > 0 else 9999.0

        diag.update({
            "operation": "Differentiation",
            "result": res,
            "truth": truth,
            "error": err,
            "correct_digits": digits,
            "global_dps": mp.dps,
            "num_fibs": FIB_COUNT,
            "evaluation_point": x0,
            "cuda_tasks": cuda_count,
            "cpu_tasks": cpu_count,
            "policy": exec_info.get("policy", "adaptive"),
        })

        diags_hybrid.append(diag)
        hybrid_names.append(f"{label} d{order}")

env_info = diags_hybrid[0].get("execution", {}).get("environment", {})

diags_hybrid[0].update({
    "cpu_name": env_info.get("cpu_name", "?"),
    "gpu_name": env_info.get("gpu_name", "?"),
    "max_dps_used": max(used_dps_hybrid),
    "cpu_tasks_total": total_cpu_tasks,
    "gpu_tasks_total": total_cuda_tasks,
})

eng_hybrid.report(
    diags_hybrid,
    title="PHASE 2 — HYBRID (torch CUDA / mpmath CPU)",
    batch=True,
)

# ==========================================================
# PHASE 3: Comparison summary
# ==========================================================

print(f"\nHybrid dispatch summary: {total_cuda_tasks} CUDA tasks, {total_cpu_tasks} CPU tasks  (fib_count={FIB_COUNT}, max_dps={MAX_DPS})")

if total_cuda_tasks > 0 and total_cpu_tasks > 0:
    print("✓ Genuine hybrid: both backends received work\n")
elif total_cuda_tasks > 0:
    print("⚠ All-CUDA: classifier routed everything to GPU\n")
else:
    print("⚠ All-CPU: no CUDA dispatch occurred\n")

print(f"  {'Test':<25} {'Digits':>8} {'Hybrid':>10} {'CPU':>10} {'Speedup':>9}")
print(f"  {'─' * 65}")

for i, diag_h in enumerate(diags_hybrid):
    diag_s = diags_seq[i]
    name = hybrid_names[i]
    digits = diag_h.get("correct_digits", 0)
    t_hybrid = diag_h.get("timing_s", 0)
    t_seq = diag_s.get("timing_s", 0)
    speedup = t_seq / t_hybrid if t_hybrid > 0 else 0

    digits_str = f">{int(digits)}" if digits > 1000 else f"{digits:.1f}"
    print(f"  {name:<25} {digits_str:>8} {t_hybrid:>8.3f}s {t_seq:>8.3f}s {speedup:>8.1f}x")

