# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/bump_test.py

"""
GPT5.2 Adversarial Bump Test.
"""

from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

mp.dps = 2000

cfg = PhiEngineConfig(
    base_dps=100,
    fib_count=14,
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=10000,
    display_digits=50,
)
eng = PhiEngine(cfg)

def bump(x):
    x = mp.mpf(x)
    if x == 0:
        return mp.mpf("0")
    return mp.e ** (-(1/(x*x)))

print("="*80)
print("BUMP TEST: C∞ BUT NON-ANALYTIC AT 0")
print("="*80)

# 1) Derivatives at 0 (all should be 0, exactly)
x0 = mp.mpf("0")
for k in [1,2,3,5,10,15]:
    val, diag = eng.differentiate(bump, x0, order=k, name="bump@0")
    print(f"bump^{k}(0) = {mp.nstr(val, 30)}  | time={diag.get('timing_s',0):.4f}s")

print()

# 2) Show it's not identically zero near 0
for x in ["0.5", "0.2", "0.1", "0.05"]:
    print(f"bump({x}) = {mp.nstr(bump(mp.mpf(x)), 50)}")

print()
