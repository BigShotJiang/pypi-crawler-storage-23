# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.
#
# examples/AdversarialAITests/test_parallel.py

"""
φ-engine parallel evaluation test harness.

Tests correctness and speedup for differentiation and integration.
"""

import time
from mpmath import mp

try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig, Fraction

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core._rational import Fraction

mp.dps = 2000


def make_slow_F(delay_ms=50):
    """Simulate slow black-box callable (API, sensor, heavy compute)."""

    def F(x):
        time.sleep(delay_ms / 1000)
        x = mp.mpf(x)
        return mp.sin(x) * mp.exp(-x ** 2)

    return F


def make_fast_F():
    """Fast analytic function for correctness testing."""

    def F(x):
        x = mp.mpf(x)
        return mp.exp(x) * mp.sin(x)

    return F

def test_differentiation_correctness(eng):
    """Verify parallel and sequential produce identical results."""
    print("=" * 60)
    print("DIFFERENTIATION CORRECTNESS")
    print("=" * 60)

    F = make_fast_F()
    test_points = [mp.mpf(x) for x in ['-1', '0', '0.5', '1', '2']]

    all_pass = True
    for x0 in test_points:
        seq_result = eng.differentiate(F, x0, parallel=False)
        par_result = eng.differentiate(F, x0, parallel=True)

        # Handle tuple returns if diagnostics enabled
        if isinstance(seq_result, tuple):
            seq_result = seq_result[0]
        if isinstance(par_result, tuple):
            par_result = par_result[0]

        diff = abs(seq_result - par_result)
        match = diff < mp.mpf('1e-40')
        all_pass = all_pass and match

        status = "✓" if match else "✗"
        print(f"  x={float(x0):>5.1f}: {status}  diff={mp.nstr(diff, 5)}")

    print(f"\n  Result: {'PASS' if all_pass else 'FAIL'}")
    return all_pass


def test_integration_correctness(eng):
    """Verify parallel and sequential integration match."""
    print("\n" + "=" * 60)
    print("INTEGRATION CORRECTNESS")
    print("=" * 60)

    F = make_fast_F()
    intervals = [
        (Fraction(0), Fraction(1)),
        (Fraction(-1), Fraction(1)),
        (Fraction(0), Fraction(2)),
    ]

    all_pass = True
    for a, b in intervals:
        seq_result = eng.integrate(F, a, b, parallel=False)
        par_result = eng.integrate(F, a, b, parallel=True)

        if isinstance(seq_result, tuple):
            seq_result = seq_result[0]
        if isinstance(par_result, tuple):
            par_result = par_result[0]

        diff = abs(seq_result - par_result)
        match = diff < mp.mpf('1e-40')
        all_pass = all_pass and match

        status = "✓" if match else "✗"
        print(f"  [{float(a)}, {float(b)}]: {status}  diff={mp.nstr(diff, 5)}")

    print(f"\n  Result: {'PASS' if all_pass else 'FAIL'}")
    return all_pass


def test_differentiation_speedup(eng, delay_ms=50):
    """Measure parallel speedup with slow callable using engine diagnostics.

    NOTE: We use diag['timing_s'] from the engine rather than external
    wall-clock timing, because beta coefficients are cached after the
    first call — external timing on a second call would be unfairly fast.
    """
    print("\n" + "=" * 60)
    print(f"DIFFERENTIATION SPEEDUP (F delay={delay_ms}ms)")
    print("=" * 60)

    F = make_slow_F(delay_ms)
    x0 = mp.mpf('1')

    # Sequential
    seq_result = eng.differentiate(F, x0, parallel=False)
    if isinstance(seq_result, tuple):
        seq_val, seq_diag = seq_result
    else:
        seq_val, seq_diag = seq_result, {}

    # Parallel
    par_result = eng.differentiate(F, x0, parallel=True)
    if isinstance(par_result, tuple):
        par_val, par_diag = par_result
    else:
        par_val, par_diag = par_result, {}

    seq_time = seq_diag.get('timing_s', 0)
    par_time = par_diag.get('timing_s', 0)

    match = abs(seq_val - par_val) < mp.mpf('1e-40')
    speedup = seq_time / par_time if par_time > 0 else 0

    print(f"  Sequential: {seq_time * 1000:>8.0f}ms  (from engine diagnostics)")
    print(f"  Parallel:   {par_time * 1000:>8.0f}ms  (from engine diagnostics)")
    print(f"  Speedup:    {speedup:>8.1f}x")
    print(f"  Match:      {'✓' if match else '✗'}")

    return match, speedup


def test_integration_speedup(eng, delay_ms=50, dyadic_depth=0):
    """Measure parallel speedup for integration using engine diagnostics."""
    print("\n" + "=" * 60)
    print(f"INTEGRATION SPEEDUP (F delay={delay_ms}ms, dyadic={dyadic_depth})")
    print("=" * 60)

    F = make_slow_F(delay_ms)
    a, b = Fraction(0), Fraction(1)

    # Sequential
    seq_result = eng.integrate(F, a, b, parallel=False, dyadic_depth=dyadic_depth)
    if isinstance(seq_result, tuple):
        seq_val, seq_diag = seq_result
    else:
        seq_val, seq_diag = seq_result, {}

    # Parallel
    par_result = eng.integrate(F, a, b, parallel=True, dyadic_depth=dyadic_depth)
    if isinstance(par_result, tuple):
        par_val, par_diag = par_result
    else:
        par_val, par_diag = par_result, {}

    seq_time = seq_diag.get('timing_s', 0)
    par_time = par_diag.get('timing_s', 0)

    match = abs(seq_val - par_val) < mp.mpf('1e-40')
    speedup = seq_time / par_time if par_time > 0 else 0

    print(f"  Sequential: {seq_time * 1000:>8.0f}ms  (from engine diagnostics)")
    print(f"  Parallel:   {par_time * 1000:>8.0f}ms  (from engine diagnostics)")
    print(f"  Speedup:    {speedup:>8.1f}x")
    print(f"  Match:      {'✓' if match else '✗'}")

    return match, speedup


def main():
    print("φ-ENGINE PARALLEL TEST HARNESS")
    print("=" * 60)

    cfg = PhiEngineConfig(
        base_dps=50,
        fib_count=12,
        return_diagnostics=True,
        timing=True,
    )
    eng = PhiEngine(cfg)

    print(f"\nConfig: fib_count={cfg.fib_count} → {cfg.fib_count * 2} F evals")

    # Correctness
    diff_ok = test_differentiation_correctness(eng)
    int_ok = test_integration_correctness(eng)

    # Speedup
    _, diff_speedup = test_differentiation_speedup(eng, delay_ms=50)
    _, int_speedup = test_integration_speedup(eng, delay_ms=50)
    _, int_dyadic_speedup = test_integration_speedup(eng, delay_ms=25, dyadic_depth=2)

    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"  Differentiation correct: {'✓' if diff_ok else '✗'}")
    print(f"  Integration correct:     {'✓' if int_ok else '✗'}")
    print(f"  Diff speedup (50ms F):   {diff_speedup:.1f}x")
    print(f"  Int speedup (50ms F):    {int_speedup:.1f}x")
    print(f"  Int+dyadic speedup:      {int_dyadic_speedup:.1f}x")

    if diff_ok and int_ok:
        print("\n  ✓ All tests passed")
    else:
        print("\n  ✗ Some tests failed")


if __name__ == "__main__":
    main()
