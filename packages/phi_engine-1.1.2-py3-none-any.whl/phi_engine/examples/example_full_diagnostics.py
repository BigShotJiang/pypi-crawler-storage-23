# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_full_diagnostics.py
"""
Full Diagnostics Demonstration for φ-Engine

This example exercises:
    • value(), derivative(), integral()
    • unified all() operator
    • compare() helper vs high-precision mpmath oracles
    • per-operator diagnostics
    • used_dps tracking and per_term_guard
    • error computation against analytic "truth"
    • batch mode reporting
    • φ-certificate emission and verification


It shows the *complete diagnostic vocabulary* the engine can emit.
"""
import time
from fractions import Fraction
from mpmath import mp
from math import pi

try:
    from phi_engine import PhiEngine, PhiEngineConfig, verify_cert, Fraction
except ImportError:
    from core.phi_engine import PhiEngine, Fraction
    from core.phi_engine_config import PhiEngineConfig
    from core.certificates import verify_cert


def main():

    # ------------------------------------------------------------
    # Configuration: enable ALL diagnostic features
    # ------------------------------------------------------------
    cfg = PhiEngineConfig(
        base_dps=250,
        fib_count=9,
        per_term_guard=True,
        return_diagnostics=True,
        timing=True,
        show_error=True,
        header_keys=("global_dps", "num_fibs"),
        display_digits=8
    )

    eng = PhiEngine(cfg)

    # Target function: analytic on a,b
    F = lambda x: mp.e**(-x*x)

    x0 = mp.mpf("0.25")
    a, b = Fraction(0), Fraction(1)
    mp.dps = 500


    # ============================================================
    # 1. DERIVATIVE OPERATOR
    # ============================================================
    print("\n=== DERIVATIVE DIAGNOSTICS ===\n")

    deriv, diag_deriv = eng.differentiate(F, x0, name="Gaussian")

    truth_deriv = -2 * x0 * mp.e**(-x0 * x0)

    diag_deriv.update({
        "error": abs(deriv - truth_deriv),
        "operation": "Derivative",
        "x0": x0,
        "result": deriv,
        "global_dps": mp.dps,
        "num_fibs": eng.config.fib_count,
    })

    eng.report(diag_deriv)

    # ============================================================
    # 2. INTEGRAL OPERATOR + BATCH MODE
    # ============================================================
    print("\n=== INTEGRAL DIAGNOSTICS (Batch Mode) ===\n")

    # Test functions (analytic on [0,1])
    tests = [
        ("poly: 3x^11 - 7x^8",
         lambda x: 3 * x ** 11 - 7 * x ** 8),
        ("exp(-x^2)", lambda x: mp.e ** (-x ** 2)),
        ("cos(x^2)", lambda x: mp.cos(x ** 2)),
        ("sin(x^2)", lambda x: mp.sin(x ** 2)),
        ("exp(x^2)", lambda x: mp.e ** (x ** 2)),
        ("cosh(x^2)", lambda x: mp.cosh(x ** 2)),
        ("exp(-(x-1/3)^2)", lambda x: mp.e ** (-(x - 1 / 3) ** 2)),
    ]

    diags = []

    # Benchmark Loop
    for label, func in tests:
        mp.dps = 500  # visible accuracy, not φ accuracy

        # φ-time
        res, diag = eng.integrate(func, Fraction(a), Fraction(pi), dyadic_depth=8)

        # mp.quad time
        t0 = time.perf_counter()
        mp_val = mp.quad(func, [a, pi])
        mp_elapsed = time.perf_counter() - t0

        # Populate diagnostics
        diag.update({
            "function": label,
            "operation": "Integration",
            "interval": f"[{a}, {pi}]",
            "result": res,
            "error": abs(res - mp_val),
            "timing_s_alt_mpquad": mp_elapsed,
            "global_dps": mp.dps,
            "num_fibs": eng.config.fib_count
        })

        diags.append(diag)
    eng.report(diags, batch=True)


    # ============================================================
    # 3. UNIFIED ALL-MODE DIAGNOSTICS
    # ============================================================
    print("\n=== UNIFIED ALL-MODE DIAGNOSTICS ===\n")


    results_all, diags = eng.all(
        F_eval=F,
        x0=x0,
        a=Fraction(a),
        b=Fraction(b),
        dps=500,
        name="Gaussian",
        force_timing=True,
        dyadic_depth=8
    )

    # Truths
    truth_der = mp.diff(F, x0)
    truth_int = mp.sqrt(mp.pi) / 2 * mp.erf(1)

    # Attach metadata + errors for the unified report

    # derivative
    diags[0]["operation"] = "Derivative"
    diags[0]["x0"] = x0
    diags[0]["error"] = abs(diags[0]["result"] - truth_der)

    # integral
    diags[1]["operation"] = "Integration"
    diags[0]["interval"] = f"[{a}, {b}]"  # For now the engine only checks for header keys in diags[0]
    diags[1]["error"] = abs(diags[1]["result"] - truth_int)

    # Now render the nice all-mode table
    eng.report(diags, all_mode=True)

    # ============================================================
    # 4. COMPARE() — φ vs mpmath oracle (timing + error + speedup)
    # ============================================================
    print("\n=== COMPARE HELPER (φ vs mpmath) ===\n")

    # Use the same F, x0, [a,b], and a reasonable oracle precision
    compare_dps = 250
    tol = mp.mpf("1e-50")  # just to exercise the tolerance

    # Differentiate comparison
    eng.compare(
        operation="differentiate",
        F_eval=F,
        x0=x0,
        dps=compare_dps,
        name="Gaussian",
        tol=tol,
    )

    # Integrate comparison
    eng.compare(
        operation="integrate",
        F_eval=F,
        a=Fraction(a),
        b=Fraction(b),
        dyadic_depth=7,
        dps=compare_dps,
        name="Gaussian",
        tol=tol,
    )

    print("\nAll diagnostics complete.\n")


if __name__ == "__main__":
    main()
