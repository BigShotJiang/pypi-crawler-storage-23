# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/ddx_sin_googol_x^2.py
"""
φ-Engine Demo:
    Derivative of f(x) = sin(10^100 · x^2) at x0 = 0.25

This is wildly beyond classical “high frequency” tests,
but still within the numeric range that mpmath can evaluate
sin(10^100 · x^2) and cos(10^100 · x^2) reliably for comparison.

The point of the demo is:
  • φ-Engine derivative on an absurdly oscillatory function.
  • Single diagnostic report with structural guarantee.
  • A very funny number to put in sin(kx^2).

Classical numerical methods can't even determine the sign bit
of d/dx sin(1 googol · x^2).

The user: "Could you differentiate something harder?"
φ-Engine: "Hit precision cap: No."
"""
# TODO: try d/dx sin(2↑↑5 · x^2) next


from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    # Fallback for running inside the Cantor_GoldenContinuum/code tree
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

def main():
    mp.dps = 3000  # high enough to exhaust output precision

    cfg = PhiEngineConfig(
        base_dps=1000,
        fib_count=14,
        per_term_guard=True,
        return_diagnostics=True,
        timing=True,
        show_error=True,
        header_keys=("global_dps", "num_fibs"),
        max_dps=20000,
        suppress_guarantee=True
    )

    eng = PhiEngine(cfg)

    GOOGOL = mp.power(10, 100)
    x0 = mp.mpf("0.25")

    def F(x):
        return mp.sin(GOOGOL * x * x)

    func_name = f"sin(googol x^2)"

    truth = 2 * GOOGOL * x0 * mp.cos(GOOGOL * x0 * x0)

    deriv, diag = eng.differentiate(F, x0)

    # Attach diagnostic metadata for the pretty report
    diag.update({
        "operation": "Derivative",
        "function": func_name,
        "result": deriv,
        "x0": x0,
        "global_dps": mp.dps,
        "num_fibs": eng.config.fib_count,
        "error": abs(deriv - truth),
    })
    eng.report(diag)


if __name__ == "__main__":
    main()
