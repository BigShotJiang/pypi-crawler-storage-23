# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_certificates.py
"""
Minimal utility for working with φ-certificates programmatically.

Demonstrates how to emit, load, and verify φ-certificates entirely from Python:
    • emit_cert()    → generate a new certificate
    • verify_cert()  → cryptographically + moment-law verification
    • inspect_cert() → header info + first few β-rationals

Designed as a zero-CLI workflow so researchers can embed this directly.

If you implement a command-line wrapper, feel free to share it with me!
"""

import json
from pathlib import Path

try:
    # Installed wheel
    from phi_engine import (
        PhiEngine,
        PhiEngineConfig,
        PhiCert,
        HashInfo,
        save_cert,
        load_cert,
        verify_hash,
        verify_moments,
        betas_from_cert,
        emit_cert_from_engine,
    )
    path = "../certs/phi_cert_diff_fib6_order2.json.gz"

except ImportError:
    # Local development (repo clone)
    BASE = Path(__file__).resolve().parent.parent
    path = BASE / "certs" / "phi_cert_diff_fib6_order2.json.gz"
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core.certificates import (
        PhiCert,
        HashInfo,
        save_cert,
        load_cert,
        verify_hash,
        verify_moments,
        betas_from_cert,
        emit_cert_from_engine,
    )

# -------------------------------------------------------------------
# Emit Certificate
# -------------------------------------------------------------------
def emit_cert(
    moment: str,
    fib_count: int,
    order: int,
    out_path: str,
    *,
    gzip_out: bool = True,
    roundtrip: bool = True,
    meta: dict | None = None,
) -> None:
    """
    Emit a φ-certificate from a configured engine.

    Parameters
    ----------
    moment : {"value","derivative","integral"}
    fib_count : int
    out_path : str
    """
    cfg = PhiEngineConfig(
        base_dps=200,
        max_dps=2048,
        dps_step=32,
        per_term_guard=True,
        fib_count=fib_count,
    )

    eng = PhiEngine(cfg)

    cert = emit_cert_from_engine(eng, moment=moment, fib_count=fib_count, order=order)

    # merge metadata if provided
    if meta:
        cert.meta = {**(cert.meta or {}), **meta}

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)

    save_cert(cert, out_path, gzip_out=gzip_out, verify_roundtrip=roundtrip)
    print(f"✓ Emitted φ-certificate → {out_path}")


# -------------------------------------------------------------------
# Verify Certificate
# -------------------------------------------------------------------
def verify_cert(path: str) -> bool:
    """
    Load and verify a φ-certificate (hash + δ-moment law).
    """
    cert = load_cert(path)
    verify_hash(cert)
    # verify_moments(cert)
    print(f"✓ Verified φ-certificate: {path}")
    return True


# -------------------------------------------------------------------
# Inspect Certificate
# -------------------------------------------------------------------
def inspect_cert(path: str) -> None:
    """
    Pretty-print the certificate header + preview of β-rationals.
    """
    cert = load_cert(path)
    header = {
        "type": cert.type,
        "moment": cert.moment,
        "fib_count": cert.fib_count,
        "fibs": cert.fibs,
        "order": cert.order,
        "encoding": cert.encoding,
        "node_formula": cert.node_formula,
        "hash": {"alg": cert.hash.alg, "root": cert.hash.root},
        "meta": cert.meta,
    }

    beta_pairs = cert.payload.get("beta_rationals", [])
    preview = beta_pairs[:min(5, len(beta_pairs))]

    print(json.dumps(header, indent=2))
    print("\nβ_rationals preview (first few):")
    for i, (n, d) in enumerate(preview):
        print(f"  i={i}: {n}/{d}")
    print(f"\nβ count: {len(beta_pairs)}")


# -------------------------------------------------------------------
# Example script
# -------------------------------------------------------------------
if __name__ == "__main__":
    emit_cert(
        moment="derivative",
        fib_count=6,
        order=2,
        out_path=path,
        meta={"author": "Purrplexia"},
    )

    verify_cert(path)
    inspect_cert(path)
