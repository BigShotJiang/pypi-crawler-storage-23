# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_hard_differentiation_batch.py
"""
Benchmark: φ-Engine on Hard Analytic Derivatives
------------------------------------------------
Demonstrates the factorial-differentiator on several functions that are
notoriously hostile to classical numerical differentiation:

- iterated exponentials: exp(exp(x)), exp(exp(exp(x²)))
- ultra-oscillatory phase: sin(10²⁴ x²)
- flat bumps and high-order curvature: exp(-x⁴), exp(x⁶)
- special functions: besselj(0, x²), erf(x²)
- composite beasts: exp(log(x+3)·log(x+5)), log(1+x²)·exp(sin(x))

Closed-form derivatives are used *only* as truth oracles.
φ-Engine itself only sees F(x).

This version intentionally skips the heaviest “gamma·polylog+zeta” test
to avoid melting your CPU. Feel free to make your own nuclear torture test!
"""
import sys

from mpmath import mp
import time

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig

# ------------------------------------------------------------
# Engine Configuration
# ------------------------------------------------------------
cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=13,
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=10000,
    display_digits=12,
    report_col_width=24,
    header_keys=("global_dps", "num_fibs", "evaluation_point", "max_dps_used"),
)

eng = PhiEngine(cfg)

# ------------------------------------------------------------
# Hard Analytic Test Functions (CPU-friendly subset)
# ------------------------------------------------------------
tests = [

    # ------------------------------------------------------------
    # EXPONENTIAL ANOMALIES (Entire functions)
    # ------------------------------------------------------------

    # 1. Double exponential
    ("exp(exp(x))",
     lambda x: mp.e**(mp.e**x),
     lambda x: mp.e**(mp.e**x) * mp.e**x),

    # 2. Triple exponential x^2 lmao
    ("exp(exp(exp(x^2)))",
     lambda x: mp.e ** (mp.e ** (mp.e ** (x ** 2))),
     lambda x: mp.e ** (mp.e ** (mp.e ** (x ** 2))) * mp.e ** (mp.e ** (x ** 2)) * mp.e ** (x ** 2) * (2 * x)),

    # 3. Gaussian derivative torture >:)
    ("exp(-x^4)",
     lambda x: mp.e**(-x**4),
     lambda x: -4*x**3 * mp.e**(-x**4)),

    # 4. Hyper-Gaussian (still entire!)
    ("exp(x^6)",
    lambda x: mp.e**(x**6),
    lambda x: 6*x**5 * mp.e**(x**6)),

    # 5. Exponential of trig
    ("exp(sin(x))",
     lambda x: mp.e**(mp.sin(x)),
     lambda x: mp.e**(mp.sin(x)) * mp.cos(x)),


    # ------------------------------------------------------------
    # TRIGONOMETRIC MONSTERS
    # ------------------------------------------------------------

    # 6. High-frequency oscillation (perfectly safe LOL)
    ("sin(1e24 * x^2)",
     lambda x: mp.sin(1_000_000_000_000_000_000_000_000 * x**2),
     lambda x: 2_000_000_000_000_000_000_000_000*x * mp.cos(1_000_000_000_000_000_000_000_000 * x**2)),

    # 7. Quartic oscillation
    ("cos(x^4)",
     lambda x: mp.cos(x**4),
     lambda x: -4*x**3 * mp.sin(x**4)),

    # 8. Mixed trig–poly
    # ("sin(x^3 + x)",
    #  lambda x: mp.sin(x**3 + x),
    #  lambda x: mp.cos(x**3 + x)*(3*x**2 + 1)),

    # 9. Oscillatory with exponential envelope
    # ("e^x * cos(x^3)",
    #  lambda x: mp.e**x * mp.cos(x**3),
    #  lambda x: mp.e**x * mp.cos(x**3) + mp.e**x * (-mp.sin(x**3)*3*x**2)),



    # ------------------------------------------------------------
    # SPECIAL FUNCTIONS (all analytic everywhere)
    # ------------------------------------------------------------

    # 10. Bessel J0 of x^2
    ("besselj(0, x^2)",
     lambda x: mp.besselj(0, x**2),
     lambda x: -2*x * mp.besselj(1, x**2)),

    # 11. Airy Ai of polynomial don't uncomment unless you want to wait 30s for mpmath to evaluate this tons of times
    # ("airy(x^2)",
    #  lambda x: mp.airyai(x**2),
    #  lambda x: mp.airyai(x**2)*(2*x)),

    # 12. Erf composition (entire!)
    ("erf(x^2)",
     lambda x: mp.erf(x**2),
     lambda x: 2*x*(2/mp.sqrt(mp.pi))*mp.e**(-(x**2)**2)),

    # 13. Polylog analytic on |x|<1
    # ("polylog(2, x/2)",
    #  lambda x: mp.polylog(2, x/2),
    #  lambda x: mp.polylog(1, x/2) * (1/2)),



    # ------------------------------------------------------------
    # LOGARITHMIC ANALYTIC FUNCTIONS
    # ------------------------------------------------------------

    # 14. Exp(log(x+3)*log(x+5))
    ("exp(log(x+3)*log(x+5))",
     lambda x: mp.e ** (mp.log(x+3)*mp.log(x+5)),
     lambda x: mp.e ** (mp.log(x+3)*mp.log(x+5)) *
               ((1/(x+3))*mp.log(x+5) + (1/(x+5))*mp.log(x+3))),

    # 15. log(1 + x^2) * exp(sin(x))
    ("log(1+x^2)*exp(sin(x))",
     lambda x: mp.log(1+x**2) * mp.e**(mp.sin(x)),
     lambda x: (2*x/(1+x**2)) * mp.e**(mp.sin(x))
               + mp.log(1+x**2)*mp.e**(mp.sin(x))*mp.cos(x)),



    # ------------------------------------------------------------
    # POLYNOMIAL & MIXED GROWTH
    # ------------------------------------------------------------

    # 16. x^10 * exp(x^3)
    # ("x^10 * exp(x^3)",
    #  lambda x: x**10 * mp.e**(x**3),
    #  lambda x: 10*x**9*mp.e**(x**3) + 3*x**12*mp.e**(x**3)),

    # 17. x^8 * cosh(x^2)
    ("x^8 * cosh(x^2)",
     lambda x: x**8 * mp.cosh(x**2),
     lambda x: 8*x**7*mp.cosh(x**2) + x**8 * mp.sinh(x**2) * 2*x),

    # 18. x^3 * exp(-x^4)
    ("x^3 * exp(-x^4)",
    lambda x: x**3 * mp.e**(-x**4),
    lambda x: 3*x**2 * mp.e**(-x**4) + x**3 * (-4*x**3)*mp.e**(-x**4)),

    # 19. Mixed growth & oscillation
    ("x^3 * sin(x^3) * exp(x)",
     lambda x: x**3 * mp.sin(x**3) * mp.e**x,
     lambda x: 3*x**2*mp.sin(x**3)*mp.e**x +
               x**3*(3*x**2)*mp.cos(x**3)*mp.e**x +
               x**3*mp.sin(x**3)*mp.e**x),

    # 20. Smooth but brutal curvature transitions
    ("exp(-x^2) * cos(x^5)",
     lambda x: mp.e**(-x**2) * mp.cos(x**5),
     lambda x: -2*x*mp.e**(-x**2)*mp.cos(x**5) +
               mp.e**(-x**2)*(-mp.sin(x**5)*5*x**4)),
]



# Evaluation point
x0 = mp.mpf('0.25')

# Visible precision for truth printing (φ uses its own internal dps)
mp.dps = 2000

diags = []
t0 = time.perf_counter()

print("Computing frozen global differentiation β-operator. . .")
# NOTE: This is NOT required for use just demo drama
_, warm_diag = eng.differentiate(lambda x: x, x0, name="warmup")  # This is NOT required just demo
beta_time = warm_diag.get("beta_time", 0.0)
print(f"β synthesis time: {beta_time:.6f} seconds")

used_dps_maxs_list = []
for label, f, f_truth in tests:
    # φ-Engine differentiation
    print(f"Calling differentiate on {label}")
    res, diag = eng.differentiate(f, x0, name=label)
    used_dps_maxs_list.append(diag.get("used_dps_max", 0))
    # Closed-form truth for comparison
    truth = f_truth(x0)
    abs_err = abs(res - truth)

    diag.update({
        "function": label,
        "operation": "Differentiation",
        "result": res,
        "truth": truth,
        "error": abs_err,
        "global_dps": mp.dps,
        "num_fibs": eng.config.fib_count,
        "evaluation_point": x0
    })
    diags.append(diag)

diags[0].update({"max_dps_used": max(used_dps_maxs_list)})

# ------------------------------------------------------------
# Summary Report
# ------------------------------------------------------------
print('\n'*3)
eng.report(diags, batch=True)



elapsed = time.perf_counter() - t0

print(f"Total batch wall time: {elapsed:.5f} s", flush=True)
