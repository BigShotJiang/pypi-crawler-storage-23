# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_int_orders.py

"""
Example: higher-order integration via Cauchy kernel reduction.
"""

import time
from fractions import Fraction
from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig


cfg = PhiEngineConfig(
    base_dps=20,
    fib_count=11,
    timing=True,
    return_diagnostics=True,
    show_error=True,
    per_term_guard=True,
    max_dps=2000,
    display_digits=12,
    report_col_width=24,
    header_keys=("global_dps", "num_fibs", "interval", "order", "max_dps_used"),
    suppress_guarantee=True,
)

eng = PhiEngine(cfg)

mp.dps = 100

def F(x):
    return mp.e**x * mp.sin(x)

def truth_iterated_integral(order):
    """
    (1/(r-1)!) ∫_0^1 (1 - t)^(r-1) e^t sin(t) dt
    """
    def integrand(t):
        return (1 - t)**(order - 1) * mp.e**t * mp.sin(t)

    raw = mp.quad(integrand, [0, 1])
    return raw / mp.factorial(order - 1)

a = Fraction(0, 1)
b = Fraction(1, 1)

diags = []
used_dps_maxs = []

t0 = time.perf_counter()

for order in range(1, 5):
    result, diag = eng.integrate(
        F,
        a,
        b,
        order=order,
        dyadic_depth=5,
        name=f"∫^{order} e^x sin(x)",
    )

    truth = truth_iterated_integral(order)
    abs_err = abs(result - truth)

    used_dps_maxs.append(diag.get("used_dps_max", 0))

    diag.update({
        "function": "exp(x)·sin(x)",
        "operation": "Iterated Integration",
        "interval": "[0, 1]",
        "order": order,
        "result": result,
        "truth": truth,
        "error": abs_err,
        "global_dps": mp.dps,
        "num_fibs": eng.config.fib_count,
    })

    diags.append(diag)

# propagate batch-wide max DPS (exactly like differentiation harness)
diags[0].update({"max_dps_used": max(used_dps_maxs)})

eng.report(diags, batch=True)

elapsed = time.perf_counter() - t0
print(f"Total batch wall time: {elapsed:.5f} s", flush=True)
