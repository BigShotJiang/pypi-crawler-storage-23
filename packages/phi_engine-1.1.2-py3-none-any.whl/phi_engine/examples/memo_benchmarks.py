# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/memo_benchmarks.py

"""
φ-Engine Capability Benchmark
==============================

Reproduces the exact results from the φ-Engine capability memo.
All derivative orders are loaded from precomputed certificates.

Requirements:
    pip install phi-engine

Certificates required in ./certs/:
    phi_cert_diff_fib13_order1.json.gz
    phi_cert_diff_fib13_order2.json.gz
    phi_cert_diff_fib13_order3.json.gz
    phi_cert_diff_fib13_order5.json.gz
    phi_cert_diff_fib13_order10.json.gz

"""

import sys
import time
from pathlib import Path
from mpmath import mp, mpf

# Required for cert load
sys.set_int_max_str_digits(10000)

# ── Imports + cert path resolution (2 cases) ──
def _resolve_engine_and_certs():
    """
    Case 1: Local clone of repository
      - import from core.*
      - certs live at: <repo>/certs  (one level up from this examples/ file)

    Case 2: Pip installed build
      - import from exported module path (phi_engine)
      - prefer local working directory ./certs
      - else fall back to wheel-installed phi_engine/certs (sibling of core/)
    """
    try:
        # Case 2: pip installed build (preferred)
        from phi_engine import PhiEngine, PhiEngineConfig, Fraction  # type: ignore
        cert_dir = Path(__file__).resolve().parent.parent / "certs"
        return PhiEngine, PhiEngineConfig, Fraction, cert_dir

    except ImportError:
        # Case 1: local clone
        from core.phi_engine import PhiEngine, PhiEngineConfig  # type: ignore
        from core._rational import Fraction
        # this file is in .../examples/, but certs is at .../certs/
        cert_dir = Path(__file__).resolve().parent.parent / "certs"
        return PhiEngine, PhiEngineConfig, Fraction, cert_dir


PhiEngine, PhiEngineConfig, Fraction, CERT_DIR = _resolve_engine_and_certs()


def cert_path(order: int) -> str:
    p = CERT_DIR / f"phi_cert_diff_fib13_order{order}.json.gz"
    if not p.is_file():
        print(f"  ✗ Certificate not found: {p}", file=sys.stderr)
        sys.exit(1)
    return str(p)


# ── Result helpers ──

def _to_mpf(x):
    """Robust conversion to mpf (handles gmpy2.mpq, mpf, int, str)."""
    if hasattr(x, "numerator") and hasattr(x, "denominator"):
        try:
            return mp.mpf(x.numerator) / mp.mpf(x.denominator)
        except Exception:
            pass
    if hasattr(x, "p") and hasattr(x, "q"):
        return mp.mpf(int(x.p)) / mp.mpf(int(x.q))
    try:
        return mp.mpf(x)
    except TypeError:
        return mp.mpf(str(x))


def make_engine(order: int) -> PhiEngine:
    """
    Build a φ-Engine for a given order using the cert-only preset,
    with config matching the benchmark harness exactly.
    """
    cfg = PhiEngineConfig.preset_cert_only(
        cert_path(order),
        base_dps=50,
        fib_count=13,
        per_term_guard=True,
        return_diagnostics=True,
        timing=True,
        show_error=False,
        max_dps=10000,
    )
    return PhiEngine(cfg)


def measure(eng, func, x0, order, truth_val, runs=3):
    """
    Run a benchmark and return (min_time, digits, result_mpf, truth_abs).
    truth_val: exact mpf value computed at high DPS, or None (no oracle).
    All arithmetic stays in mpf — no float() casts on results.
    """
    times = []
    result = None
    for _ in range(runs):
        t0 = time.perf_counter()
        result, diag = eng.differentiate(func, x0, order=order)
        t1 = time.perf_counter()
        times.append(t1 - t0)

    min_time = min(times)
    result_mpf = _to_mpf(result)

    if truth_val is not None:
        err = mp.fabs(result_mpf - truth_val)
        truth_abs = mp.fabs(truth_val)

        if err > 0 and truth_abs > 0:
            digits = -mp.log10(err / truth_abs)
        elif err == 0:
            digits = mpf("9999")
        else:
            digits = mpf("0")
    else:
        digits = None
        truth_abs = mp.fabs(result_mpf)

    return min_time, digits, result_mpf, truth_abs


def fmt_digits(d):
    if d is None:
        return "---"
    # only cast to float for display formatting, never for computation
    d_val = float(d)
    if d_val > 9000:
        return f">{int(d_val)}"
    return f"{d_val:.1f}"


def fmt_time(t):
    if t < 1.0:
        return f"{t*1000:.0f} ms"
    return f"{t:.2f} s"


def fmt_mag(truth_abs):
    if truth_abs == 0:
        return "0"
    if truth_abs > mpf("1e15"):
        return f"~10^{mp.nstr(mp.log10(truth_abs), 3)}"
    elif truth_abs < mpf("1e-6"):
        return f"~10^{mp.nstr(mp.log10(truth_abs), 3)}"
    else:
        return mp.nstr(truth_abs, 6)


# ── Callables ──

def compose_tanh(x, n):
    """Apply tanh n times."""
    v = x
    for _ in range(n):
        v = mp.tanh(v)
    return v


def chain_tanh_deriv(x0, n):
    """Exact first derivative of n-fold tanh composition."""
    vals = [x0]
    v = x0
    for _ in range(n - 1):
        v = mp.tanh(v)
        vals.append(v)
    prod = mpf("1")
    for v in vals:
        prod *= (1 - mp.tanh(v) ** 2)
    return prod

# ── Integration helpers ──

def run_all_integrals(eng):
    """
    Run the four integration benchmarks from the memo table.
    All on [0, 1], dyadic depth 5, order 1 (no cert needed).
    """
    a = Fraction(0,1)
    b = Fraction(1,1)

    # Truth values (exact, computed at current mp.dps)
    # ∫₀¹ exp(x) dx = e - 1
    # ∫₀¹ sin(x) dx = 1 - cos(1)
    # ∫₀¹ exp(3x)sin(5x) dx = exp(ax)[a·sin(bx) - b·cos(bx)]/(a²+b²) |₀¹
    # ∫₀¹ 1/(1+x²) dx = π/4

    three = mpf("3")
    five = mpf("5")
    denom = three ** 2 + five ** 2  # 34

    cases = [
        (
            "exp(x)",
            lambda x: mp.exp(x),
            mp.exp(mpf("1")) - 1,
        ),
        (
            "sin(x)",
            lambda x: mp.sin(x),
            1 - mp.cos(mpf("1")),
        ),
        (
            "exp(3x)·sin(5x)",
            lambda x: mp.exp(three * x) * mp.sin(five * x),
            (
                mp.exp(three) * (three * mp.sin(five) - five * mp.cos(five)) / denom
                - (three * mp.sin(mpf("0")) - five * mp.cos(mpf("0"))) / denom
            ),
        ),
        (
            "1/(1+x²)",
            lambda x: 1 / (1 + x ** 2),
            mp.pi / 4,
        ),
    ]

    print(f"\n  {'':─<95}")
    print(f"  Integration on [0, 1]")
    print(f"  {'':─<95}")

    for name, func, truth_val in cases:
        times = []
        result = None
        for _ in range(3):
            t0 = time.perf_counter()
            result, diag = eng.integrate(func, a, b, dyadic_depth=5)
            t1 = time.perf_counter()
            times.append(t1 - t0)

        min_time = min(times)
        result_mpf = _to_mpf(result)

        err = mp.fabs(result_mpf - truth_val)
        truth_abs = mp.fabs(truth_val)

        if err > 0 and truth_abs > 0:
            digits = -mp.log10(err / truth_abs)
        elif err == 0:
            digits = mpf("9999")
        else:
            digits = mpf("0")

        print(f"  {'∫ ' + name:<42} {'1':>5} {fmt_time(min_time):>10} {fmt_digits(digits):>10} {fmt_mag(truth_abs):>18}  verified")

# ── Main ──

def main():
    mp.dps = 10000

    print()
    print("=" * 90)
    print("  φ-Engine Capability Benchmark")
    print("  Reproduces results from the capability memo.")
    print("  All derivatives loaded from precomputed certificates.")
    print("=" * 90)

    # Pre-build engines for each required derivative order
    orders_needed = [1, 2, 3, 5, 10]
    engines = {}
    print("\n  Loading certificates...")
    for o in orders_needed:
        engines[o] = make_engine(o)
        print(f"    ✓ Order {o}")

    # Warmup
    engines[1].differentiate(lambda x: mp.exp(x), mpf("0.5"), order=1)

    # ── Evaluation points (all mpf, no Python floats) ──
    x_quarter = mpf("0.25")
    x_half = mpf("0.5")
    x_tenth = mpf("0.1")
    x_tiny = mpf("1e-15")

    # ── Constants for truth oracles (all mpf) ──
    a_googol = mpf("1e100")
    a_bicentennial = mpf("1e200")
    a_mega = mpf("1")
    b_mega = mpf("1e6")
    r_mega = mp.sqrt(a_mega ** 2 + b_mega ** 2)
    phi_mega = mp.atan2(b_mega, a_mega)

    # ══════════════════════════════════════════════════════════════════
    #  DIFFERENTIATION
    # ══════════════════════════════════════════════════════════════════

    print()
    print(f"  {'Function':<42} {'Order':>5} {'Time':>10} {'Digits':>10} {'|f^(k)|':>18}  Status")
    print(f"  {'─' * 95}")

    # ── Group 1: Extreme oscillation ──

    print(f"  {'':─<95}")
    print(f"  Extreme oscillation — classical methods cannot determine the sign")
    print(f"  {'':─<95}")

    truth = 2 * a_googol * x_quarter * mp.cos(a_googol * x_quarter ** 2)
    t, d, _, ta = measure(engines[1], lambda x: mp.sin(a_googol * x * x), x_quarter, 1, truth)
    print(f"  {'sin(10^100 · x²) at x=0.25':<42} {1:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  verified")

    truth = (
        2 * a_googol * mp.cos(a_googol * x_quarter ** 2)
        - 4 * a_googol ** 2 * x_quarter ** 2 * mp.sin(a_googol * x_quarter ** 2)
    )
    t, d, _, ta = measure(engines[2], lambda x: mp.sin(a_googol * x * x), x_quarter, 2, truth)
    print(f"  {'sin(10^100 · x²) at x=0.25':<42} {2:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  verified")

    truth = 2 * a_bicentennial * x_quarter * mp.cos(a_bicentennial * x_quarter ** 2)
    t, d, _, ta = measure(engines[1], lambda x: mp.sin(a_bicentennial * x * x), x_quarter, 1, truth)
    print(f"  {'sin(10^200 · x²) at x=0.25':<42} {1:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  verified")

    # ── Group 2: High-order verified ──

    print(f"\n  {'':─<95}")
    print(f"  High-order verified — 10^6 oscillations per unit interval")
    print(f"  {'':─<95}")

    def f_mega(x):
        return mp.exp(a_mega * x) * mp.sin(b_mega * x)

    for order in [1, 5, 10]:
        truth = r_mega ** order * mp.exp(a_mega * x_quarter) * mp.sin(b_mega * x_quarter + order * phi_mega)
        t, d, _, ta = measure(engines[order], f_mega, x_quarter, order, truth)
        print(f"  {'exp(x)·sin(10^6·x) at x=0.25':<42} {order:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  verified")

    # ── Group 3: AI-relevant callables ──

    print(f"\n  {'':─<95}")
    print(f"  AI-relevant callables")
    print(f"  {'':─<95}")

    def gelu(x):
        return x * (1 + mp.erf(x / mp.sqrt(2))) / 2

    def phi_pdf(x):
        return mp.exp(-x ** 2 / 2) / mp.sqrt(2 * mp.pi)

    def phi_cdf(x):
        return (1 + mp.erf(x / mp.sqrt(2))) / 2

    truth = phi_cdf(x_half) + x_half * phi_pdf(x_half)
    t, d, _, ta = measure(engines[1], gelu, x_half, 1, truth)
    print(f"  {'GELU(x) at x=0.5':<42} {1:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  verified")

    truth = phi_pdf(x_half) * (x_half ** 3 - 4 * x_half)
    t, d, _, ta = measure(engines[3], gelu, x_half, 3, truth)
    print(f"  {'GELU(x) at x=0.5':<42} {3:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  verified")

    truth = chain_tanh_deriv(x_tenth, 100)
    t, d, _, ta = measure(engines[1], lambda x: compose_tanh(x, 100), x_tenth, 1, truth)
    print(f"  {'100-layer tanh composition at x=0.1':<42} {1:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  verified")

    t, d, _, ta = measure(engines[2], lambda x: compose_tanh(x, 100), x_tenth, 2, None)
    print(f"  {'100-layer tanh composition at x=0.1':<42} {2:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  (no oracle)")

    # ── Group 4: Cancellation pathology ──

    print(f"\n  {'':─<95}")
    print(f"  Numerical pathology — catastrophic cancellation for finite differences")
    print(f"  {'':─<95}")

    truth = (x_tiny * mp.exp(x_tiny) - (mp.exp(x_tiny) - 1)) / x_tiny ** 2
    t, d, _, ta = measure(engines[1], lambda x: (mp.exp(x) - 1) / x, x_tiny, 1, truth)
    print(f"  {'(exp(x)-1)/x at x=10^-15':<42} {1:>5} {fmt_time(t):>10} {fmt_digits(d):>10} {fmt_mag(ta):>18}  verified")

    # ══════════════════════════════════════════════════════════════════
    #  INTEGRATION
    # ══════════════════════════════════════════════════════════════════

    # Integration uses order 1 — no certificate needed, standard engine.
    int_cfg = PhiEngineConfig(
        base_dps=50,
        fib_count=13,
        per_term_guard=True,
        return_diagnostics=True,
        timing=True,
        show_error=False,
        max_dps=10000,
    )
    int_eng = PhiEngine(int_cfg)

    run_all_integrals(int_eng)

    # ── Done ──

    print()
    print("=" * 90)
    print("  All results are deterministic and reproducible.")
    print("  Certificates are cryptographically sealed — run `phi-engine verify` to check.")
    print("=" * 90)
    print()

if __name__ == "__main__":
    main()
