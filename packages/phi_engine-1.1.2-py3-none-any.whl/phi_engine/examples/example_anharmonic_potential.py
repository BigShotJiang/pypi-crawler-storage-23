# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_anharmonic_potential.py
"""
Anharmonic Potential — Higher-Order Derivatives for Physicists
--------------------------------------------------------------
Computes ∂¹V/∂x through ∂⁵V/∂x⁵ for an anharmonic oscillatory potential:

    V(x) = exp(-x⁴) · cos(x³)

This is physically relevant: an anharmonic well with oscillatory structure.
In perturbation theory, you need these higher derivatives to extract:

  V''(x₀)  → harmonic frequency (ω²)
  V'''(x₀) → first anharmonic correction
  V⁴(x₀)   → next anharmonic correction (Duffing-like)
  V⁵(x₀)   → higher-order quantum corrections

Getting 4th and 5th derivatives reliably from a black-box potential is
genuinely painful with finite differences — catastrophic cancellation
kills you. φ-Engine does all five to hundreds of correct digits.

No h-step. No mesh. No tuning. Just the operator.
"""

import sys
from mpmath import mp

try:
    from phi_engine import PhiEngine, PhiEngineConfig
except ImportError:
    from core.phi_engine import PhiEngine, PhiEngineConfig

sys.set_int_max_str_digits(100_000)

# ──────────────────────────────────────────────────────────
# The potential
# ──────────────────────────────────────────────────────────

def V(x):
    """Anharmonic oscillatory potential: exp(-x⁴)·cos(x³)"""
    return mp.exp(-x**4) * mp.cos(x**3)

# ──────────────────────────────────────────────────────────
# Closed-form derivatives (truth oracles — φ-Engine never sees these)
# ──────────────────────────────────────────────────────────

def dV1(x):
    """V'(x) = exp(-x⁴)·[-4x³·cos(x³) - 3x²·sin(x³)]"""
    E = mp.exp(-x**4)
    return E * (-4*x**3 * mp.cos(x**3) - 3*x**2 * mp.sin(x**3))

def dV2(x):
    """V''(x) — harmonic frequency"""
    E = mp.exp(-x**4)
    c = mp.cos(x**3)
    s = mp.sin(x**3)
    return E * (
        (16*x**6 - 12*x**2) * c
        + (24*x**5 - 6*x) * s
        + (9*x**4 - 0) * (-c)
    )

def dV3(x):
    """V'''(x) — first anharmonic correction"""
    # Too gnarly for closed form in a demo — use mpmath's symbolic diff
    with mp.workdps(mp.dps + 50):
        return mp.diff(V, x, 3)

def dV4(x):
    """V⁴(x) — Duffing correction"""
    with mp.workdps(mp.dps + 50):
        return mp.diff(V, x, 4)

def dV5(x):
    """V⁵(x) — higher-order quantum correction"""
    with mp.workdps(mp.dps + 50):
        return mp.diff(V, x, 5)


# ──────────────────────────────────────────────────────────
# Engine setup
# ──────────────────────────────────────────────────────────

mp.dps = 5000
x0 = mp.mpf("0.3")

cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=12,
    timing=True,
    return_diagnostics=True,
    max_dps=5000,
    per_term_guard=True,
    show_error=True,
    suppress_guarantee=True,
    report_col_width=24,
    display_digits=14,
    header_keys=(
        "potential",
        "evaluation_point",
        "num_fibs",
        "max_dps_used",
    ),
)

eng = PhiEngine(cfg)

# Warmup (synthesize β-streams)
_ = eng.differentiate(V, x0, order=1)

# ──────────────────────────────────────────────────────────
# Compute orders 1 through 5
# ──────────────────────────────────────────────────────────

truths = [dV1, dV2, dV3, dV4, dV5]
labels = [
    "V'   (force)",
    "V''  (harmonic freq)",
    "V''' (anharmonic-1)",
    "V⁴   (anharmonic-2)",
    "V⁵   (anharmonic-3)",
]

diags = []
used_dps_list = []

for order in range(1, 6):
    res, diag = eng.differentiate(
        V, x0, order=order, name=labels[order - 1],
    )

    truth_val = truths[order - 1](x0)
    abs_err = abs(res - truth_val)

    used_dps_list.append(diag.get("used_dps_max", 0))

    diag.update({
        "operation": "Differentiation",
        "result": res,
        "truth": truth_val,
        "error": abs_err,
    })

    diags.append(diag)

diags[0].update({
    "potential": "V(x) = exp(-x⁴)·cos(x³)",
    "evaluation_point": str(x0),
    "num_fibs": cfg.fib_count,
    "max_dps_used": max(used_dps_list),
})

# ──────────────────────────────────────────────────────────
# Report
# ──────────────────────────────────────────────────────────

eng.report(
    diags,
    title="ANHARMONIC POTENTIAL — ORDERS 1 THROUGH 5",
    batch=True,
)
