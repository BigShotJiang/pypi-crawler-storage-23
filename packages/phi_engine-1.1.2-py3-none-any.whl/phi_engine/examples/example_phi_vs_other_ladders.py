# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_phi_ladder_compare.py
"""
External ladder comparison bench (no engine changes).

What it does:
- Imports existing PhiEngine + fib_ladder exactly as-is.
- Monkeypatches fib_ladder in BOTH:
    • the fib module, and
    • the engine module that imported it.
- For each ladder strategy:
    • Builds a fresh PhiEngine(cfg).
    • Runs a shared zoo of test functions (including φ-sensitive ones).
    • Prints per-function:
        - AbsErr
        - digits ≈ -log10(error)
        - used_dps_max
        - digits_per_dps
    • Prints a small summary per ladder.

You can copy/paste the tables into a spreadsheet if you want.
"""

import time
from typing import List, Callable, Dict, Tuple

from mpmath import mp

# Imports: try package-style first, then local fallback
try:
    from phi_engine import PhiEngine, PhiEngineConfig
    import phi_engine.core.fib as fib_mod
    import phi_engine.core.phi_engine as eng_mod
except ImportError:
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    import core.fib as fib_mod
    import core.phi_engine as eng_mod


from typing import Callable, List, Dict
import math

LadderFn = Callable[[int], List[int]]

# Canonical φ-ladder
def ladder_fib_canonical(n: int) -> List[int]:
    seq = [1, 2]
    target = n - 1
    while len(seq) < target:
        seq.append(seq[-1] + seq[-2])
    return seq[:target]

# Ratio-2 ladder
def ladder_ratio2(n: int) -> List[int]:
    seq = [1, 2]
    target = n - 1
    while len(seq) < target:
        seq.append(seq[-1] * 2)
    return seq[:target]

# Linear ladder
def ladder_linear(n: int) -> List[int]:
    return list(range(1, n))

# Ratio-3 ladder
def ladder_ratio3(n: int) -> List[int]:
    seq = [1, 3]
    target = n - 1
    while len(seq) < target:
        seq.append(seq[-1] * 3)
    return seq[:target]

# π ladder:
# This ladder was removed because it attempted a
# denial-of-service attack on the factorial radii.
# (It succeeded.)
# Removed for the safety of future researchers. <3


# General irrational ratio ladder
def ladder_ratio(r: float, n: int) -> List[int]:
    seq = [1]
    target = n - 1
    while len(seq) < target:
        nxt = int(round(seq[-1] * r))
        if nxt <= seq[-1]:
            nxt = seq[-1] + 1
        seq.append(nxt)
    return seq[:target]

# -----------------------------
# Extra ladders
# -----------------------------

def ladder_ratio_e(n: int) -> List[int]:
    return ladder_ratio(math.e, n)

def ladder_ratio_sqrt2(n: int) -> List[int]:
    return ladder_ratio(math.sqrt(2), n)

def ladder_ratio_sqrt5(n: int) -> List[int]:
    return ladder_ratio(math.sqrt(5), n)

def ladder_ratio_plastic(n: int) -> List[int]:
    return ladder_ratio(1.3247179572447458, n)

def ladder_ratio_silver(n: int) -> List[int]:
    return ladder_ratio(1 + math.sqrt(2), n)

# -----------------------------
# Registry
# -----------------------------
LADDERS: Dict[str, LadderFn] = {
    "canonical_phi": ladder_fib_canonical,
    "ratio2":        ladder_ratio2,
    "linear":        ladder_linear,
    "ratio3":        ladder_ratio3,
    "ratio_e":       ladder_ratio_e,
    "ratio_sqrt2":   ladder_ratio_sqrt2,
    "ratio_sqrt5":   ladder_ratio_sqrt5,
    "ratio_plastic": ladder_ratio_plastic,
    "ratio_silver":  ladder_ratio_silver,
}

phi_const = (1 + mp.sqrt(5)) / 2

def build_tests():
    tests: List[Tuple[str, Callable, Callable]] = []

    # analytic zoo
    tests.extend([
        ("exp(exp(x))",
         lambda x: mp.e ** (mp.e ** x),
         lambda x: mp.e ** (mp.e ** x) * mp.e ** x),

        ("exp(exp(exp(x^2)))",
         lambda x: mp.e ** (mp.e ** (mp.e ** (x ** 2))),
         lambda x: mp.e ** (mp.e ** (mp.e ** (x ** 2))) *
                   mp.e ** (mp.e ** (x ** 2)) *
                   mp.e ** (x ** 2) * (2 * x)),

        ("exp(-x^4)",
         lambda x: mp.e ** (-x ** 4),
         lambda x: -4 * x ** 3 * mp.e ** (-x ** 4)),

        ("exp(x^6)",
         lambda x: mp.e ** (x ** 6),
         lambda x: 6 * x ** 5 * mp.e ** (x ** 6)),

        ("exp(sin(x))",
         lambda x: mp.e ** (mp.sin(x)),
         lambda x: mp.e ** (mp.sin(x)) * mp.cos(x)),

        ("sin(1e24 * x^2)",  # lol
         lambda x: mp.sin(1_000_000_000_000_000_000_000_000 * x ** 2),
         lambda x: 2_000_000_000_000_000_000_000_000 * x *
                   mp.cos(1_000_000_000_000_000_000_000_000 * x ** 2)),

        ("cos(x^4)",
         lambda x: mp.cos(x ** 4),
         lambda x: -4 * x ** 3 * mp.sin(x ** 4)),

        ("besselj(0, x^2)",
            lambda x: mp.besselj(0, x ** 2),
            lambda x: -2 * x * mp.besselj(1, x ** 2)),

        ("erf(x^2)",
         lambda x: mp.erf(x ** 2),
         lambda x: 2 * x * (2 / mp.sqrt(mp.pi)) * mp.e ** (-(x ** 2) ** 2)),

        ("exp(log(x+3)*log(x+5))",
         lambda x: mp.e ** (mp.log(x + 3) * mp.log(x + 5)),
         lambda x: mp.e ** (mp.log(x + 3) * mp.log(x + 5)) *
                   ((1 / (x + 3)) * mp.log(x + 5) +
                    (1 / (x + 5)) * mp.log(x + 3))),

        ("log(1+x^2)*exp(sin(x))",
         lambda x: mp.log(1 + x ** 2) * mp.e ** (mp.sin(x)),
         lambda x: (2 * x / (1 + x ** 2)) * mp.e ** (mp.sin(x))
                   + mp.log(1 + x ** 2) * mp.e ** (mp.sin(x)) * mp.cos(x)),

        ("x^8 * cosh(x^2)",
         lambda x: x ** 8 * mp.cosh(x ** 2),
         lambda x: 8 * x ** 7 * mp.cosh(x ** 2) +
                   x ** 8 * mp.sinh(x ** 2) * 2 * x),

        ("x^3 * exp(-x^4)",
         lambda x: x ** 3 * mp.e ** (-x ** 4),
         lambda x: 3 * x ** 2 * mp.e ** (-x ** 4) +
                   x ** 3 * (-4 * x ** 3) * mp.e ** (-x ** 4)),

        ("x^3 * sin(x^3) * exp(x)",
         lambda x: x ** 3 * mp.sin(x ** 3) * mp.e ** x,
         lambda x: 3 * x ** 2 * mp.sin(x ** 3) * mp.e ** x +
                   x ** 3 * (3 * x ** 2) * mp.cos(x ** 3) * mp.e ** x +
                   x ** 3 * mp.sin(x ** 3) * mp.e ** x),

        ("exp(-x^2) * cos(x^5)",
         lambda x: mp.e ** (-x ** 2) * mp.cos(x ** 5),
         lambda x: -2 * x * mp.e ** (-x ** 2) * mp.cos(x ** 5) +
                   mp.e ** (-x ** 2) * (-mp.sin(x ** 5) * 5 * x ** 4)),
    ])

    # φ / irrational / aliasing-sensitive ones
    tests.extend([
        ("sin(pi*x)",
         lambda x: mp.sin(mp.pi * x),
         lambda x: mp.pi * mp.cos(mp.pi * x)),

        ("sin(sqrt(2)*x)",
         lambda x: mp.sin(mp.sqrt(2) * x),
         lambda x: mp.sqrt(2) * mp.cos(mp.sqrt(2) * x)),

        ("sin(phi*x)",
         lambda x: mp.sin(phi_const * x),
         lambda x: phi_const * mp.cos(phi_const * x)),

        ("sin(1e6*phi*x)",
         lambda x: mp.sin(1_000_000 * phi_const * x),
         lambda x: 1_000_000 * phi_const * mp.cos(1_000_000 * phi_const * x)),
    ])

    # multi-scale harsh ones with mp.diff truth
    def f_multi(x):
        return mp.e ** (-x ** 2) * mp.cos(1_000_000_000 * x) * mp.sin(x ** 2)

    tests.append((
        "exp(-x^2)*cos(1e9 x)*sin(x^2)",
        f_multi,
        lambda x: mp.diff(f_multi, x)
    ))

    def f_triple(x):
        return mp.sin(x ** 2) * mp.sin(x ** 3) * mp.sin(x ** 5)

    tests.append((
        "sin(x^2)*sin(x^3)*sin(x^5)",
        f_triple,
        lambda x: mp.diff(f_triple, x)
    ))

    return tests


# Monkey patch ladders only
def set_ladder(fn: LadderFn):
    """
    Patch both:
      - fib_mod.fib_ladder (definition module)
      - eng_mod.fib_ladder (engine's imported binding)

    WITHOUT changing the engine source.
    """
    fib_mod.fib_ladder = fn
    eng_mod.fib_ladder = fn


def effective_digits(err: mp.mpf, cap: int = 1000) -> float:
    if err == 0:
        return float(cap)
    try:
        d = -mp.log10(err)
    except Exception:
        return 0.0
    if d < 0:
        return 0.0
    if d > cap:
        return float(cap)
    return float(d)


# Main runner per ladder
def run_for_ladder(name: str, ladder_fn: LadderFn, tests, x0: mp.mpf, fib_count: int):
    print("\n" + "=" * 90)
    print(f"LADDER: {name}")
    print("=" * 90)

    # patch the ladder used by the engine
    set_ladder(ladder_fn)

    cfg = PhiEngineConfig(
        base_dps=50,             # Low dps to force engine internal self-aware scaling for each test
        fib_count=fib_count,
        timing=True,
        return_diagnostics=True,
        show_error=False,
        per_term_guard=True,     # Enables adaptive precision to intelligently scale to each ladders requirement
        max_dps=13500,           # Enough to capture the max of ratio3 lol
        display_digits=12,
        report_col_width=24,
        header_keys=("global_dps", "num_fibs", "evaluation_point", "max_dps_used"),
    )

    eng = PhiEngine(cfg)

    mp.dps = 6000

    print(f"fib_count = {fib_count}, ladder indices = {ladder_fn(fib_count)}")

    # Warmup for β synthesis (not required)
    _, warm_diag = eng.differentiate(lambda x: x, x0, name="warmup")
    beta_time = warm_diag.get("beta_time", 0.0)
    print(f"β synthesis time: {beta_time:.6f} s\n")

    print(f"{'Function':30s} {'AbsErr':>18s} {'digits':>10s} {'used_dps':>10s} {'digits/dps':>10s}")
    print("-" * 90)

    used_dps_list = []
    digits_list = []
    digits_per_dps_list = []

    t0 = time.perf_counter()

    for label, f, f_truth in tests:
        res, diag = eng.differentiate(f, x0, name=label)
        truth = f_truth(x0)
        err = abs(res - truth)

        used_dps = int(diag.get("used_dps_max", cfg.base_dps))
        d = effective_digits(err)
        dps_eff = d / used_dps if used_dps > 0 else 0.0

        used_dps_list.append(used_dps)
        digits_list.append(d)
        digits_per_dps_list.append(dps_eff)

        print(f"{label[:28]:30s} {mp.nstr(err, 8):>18s} {d:10.1f} {used_dps:10d} {dps_eff:10.3f}")

    elapsed = time.perf_counter() - t0

    def avg(v):
        return sum(v) / len(v) if v else 0.0

    print("\nSummary:")
    print(f"  mean used_dps   = {avg(used_dps_list):.1f}")
    print(f"  max used_dps    = {max(used_dps_list) if used_dps_list else 0}")
    print(f"  mean digits     = {avg(digits_list):.1f}")
    print(f"  mean digits/dps = {avg(digits_per_dps_list):.3f}")
    print(f"  wall time (s)   = {elapsed:.3f}")



def main():
    x0 = mp.mpf("0.25")
    fib_count = 9  # same across all ladders (if you increase this some ladders may take a long time, like forever time)

    tests = build_tests()

    print("φ Ladder Sensitivity Bench (engine untouched)")
    print("=============================================")
    print(f"x0        = {x0}")
    print(f"fib_count = {fib_count}")
    print(f"mp.mp.dps = 6000\n")

    for name, fn in LADDERS.items():
        run_for_ladder(name, fn, tests, x0, fib_count)


if __name__ == "__main__":
    main()
