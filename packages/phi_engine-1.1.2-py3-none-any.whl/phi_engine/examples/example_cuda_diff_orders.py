# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/examples/example_cuda_diff_orders.py

"""
Example: parallel higher-order differentiation and integration with CUDA backend.
"""

import torch
from mpmath import mp

try:
    # Installed wheel
    from phi_engine import PhiEngine, PhiEngineConfig, Fraction, ParallelBackend, EvalCtx

except ImportError:
    # Local development (repo clone)
    from core.phi_engine import PhiEngine
    from core.phi_engine_config import PhiEngineConfig
    from core._rational import Fraction
    from core._parallel import ParallelBackend, EvalCtx


# --------------------------------------------------
# CUDA analytic callable
# --------------------------------------------------

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.set_default_dtype(torch.float64)

def gaussian(x, ctx: EvalCtx = None):
    # Backward compatible: sequential path calls gaussian(x) with no ctx
    backend = getattr(ctx, "backend", "?")

    if backend == "cuda":
        return cuda_gaussian(x)
    elif backend == "cpu":
        return cpu_gaussian(x)
    else:
        # graceful fallback
        return cpu_gaussian(x)


def cuda_gaussian(x):
    x = float(mp.nstr(x, 17))
    t = torch.tensor([x], dtype=torch.float64, device=DEVICE)
    with torch.no_grad():
        y = torch.exp(-t ** 2)
    return float(y.item())

def cpu_gaussian(x):
    return mp.exp(-x**2)

# --------------------------------------------------
# Closed-form oracle functions
# --------------------------------------------------

def d_gaussian(x, order):
    x = mp.mpf(x)
    if order == 1:
        return -2 * x * mp.exp(-x*x)
    elif order == 2:
        return (4 * x * x - 2) * mp.exp(-x * x)
    else:
        return (-8 * x ** 3 + 12 * x) * mp.exp(-x * x)

# --------------------------------------------------
# Engine config (CUDA-hybrid mode)
# --------------------------------------------------

cfg = PhiEngineConfig(
    base_dps=50,
    fib_count=9,
    timing=True,
    return_diagnostics=True,
    max_dps=1000,
    per_term_guard=True,
    suppress_guarantee=True,
    report_col_width=22,
    precision_policy="adaptive",  # Allows engine to dispatch threads
    header_keys=(
        "cpu_name",
        "gpu_name",
        "gpu_tasks_total",
        "cpu_tasks_total",
        "policy",
        "max_dps_used"
    )
)

cfg.parallel.backend = ParallelBackend.CUDA_STREAMS
cfg.parallel.max_workers = 8

eng = PhiEngine(cfg)

title = "φ-ENGINE CUDA PARALLEL HYBRID-ROUTING TEST"

mp.dps = 1000

x0 = mp.mpf("0.1")
a = Fraction(0, 1)
b = Fraction(1, 1)

diags = []
used_dps_maxs_list = []

total_cuda_tasks = 0
total_cpu_tasks = 0
hybrid_flags = []

for order in range(1, 4):
    res, diag = eng.differentiate(
        gaussian,
        x0,
        order=order,
        name=f"Gaussian order {order}",
        parallel=True
    )

    used_dps_maxs_list.append(diag.get("used_dps_max", 0))

    # ---- execution summary extraction ----
    exec_info = diag.get("execution", {})

    cuda_count = exec_info.get("cuda_task_count", 0)
    cpu_count  = exec_info.get("cpu_task_count", 0)
    total_cuda_tasks += cuda_count
    total_cpu_tasks  += cpu_count

    # ---- truth comparison ----
    truth = d_gaussian(x0, order)
    err = abs(res - truth)

    diag.update({
        "operation": "Differentiation",
        "result": res,
        "truth": truth,
        "error": err,
        "global_dps": mp.dps,
        "num_fibs": eng.config.fib_count,
        "evaluation_point": x0,

        # ---- execution clarity fields ----
        "cuda_tasks": cuda_count,
        "cpu_tasks": cpu_count,
        "policy": exec_info.get("policy", "adaptive"),
    })

    diags.append(diag)

env_info = diags[0].get("execution", {}).get("environment", {})
cpu_name = env_info.get("cpu_name", "?")
gpu_name = env_info.get("gpu_name", "?")

# ---- batch-level summary ----
diags[0].update({
    "cpu_name": cpu_name,
    "gpu_name": gpu_name,
    "max_dps_used": max(used_dps_maxs_list),
    "cpu_tasks_total": total_cpu_tasks,
    "gpu_tasks_total": total_cuda_tasks,
    "hybrid_any": any(hybrid_flags),
})

eng.report(diags, title=title, batch=True)
