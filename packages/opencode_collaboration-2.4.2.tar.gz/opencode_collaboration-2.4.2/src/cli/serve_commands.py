"""API服务CLI命令"""
import os
import click


@click.command()
@click.option("--port", "-p", default=None, type=int, help="API服务端口")
@click.option("--host", "-h", default="0.0.0.0", help="API服务地址")
def serve(port, host):
    """启动HTTP API服务"""
    from src.api.serve import start_server
    
    port = port or int(os.getenv("OC_API_PORT", "8001"))
    click.echo(f"启动API服务: http://{host}:{port}")
    click.echo(f"健康检查: http://{host}:{port}/health")
    click.echo(f"API文档: http://{host}:{port}/docs")
    
    start_server(port=port)
