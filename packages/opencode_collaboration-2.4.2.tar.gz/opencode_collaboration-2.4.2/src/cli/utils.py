"""CLI工具模块

提供CLI命令中使用的通用工具函数。
"""

import click
from typing import List
from ..core.agent_registry import get_default_agents


def get_agent_choices() -> List[str]:
    """获取Agent选项列表，用于CLI"""
    return get_default_agents()


def create_agent_choice_option(default: str = None):
    """创建动态Agent选择选项"""
    return click.Choice(get_agent_choices(), default=default)


__all__ = ["get_agent_choices", "create_agent_choice_option"]
