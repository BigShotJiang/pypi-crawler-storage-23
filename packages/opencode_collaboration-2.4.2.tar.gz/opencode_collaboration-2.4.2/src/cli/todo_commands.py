"""TODO相关命令
"""

import click
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from ..core.todo_queue_manager import TodoQueueManager, TodoQueueItem
from ..core.context_manager import ContextManager
from ..core.agent_registry import AgentRegistry


@click.group("todo")
def todo_group():
    """TODO管理命令组"""
    pass


@todo_group.command("list")
@click.option("--unread", is_flag=True, help="仅显示未读TODO")
@click.option("--agent", type=click.Choice(["1", "2"]), help="按接收者筛选")
@click.option("--priority", type=click.Choice(["high", "medium", "low"]), help="按优先级筛选")
@click.option("--source", type=click.Choice(["BUG", "REQUIREMENT", "FEEDBACK", "MANUAL"]), help="按来源筛选")
@click.option("--json", is_flag=True, help="JSON格式输出")
def todo_list_command(unread: bool, agent: str, priority: str, source: str, json: bool):
    """显示TODO列表

    示例:
      oc-collab todo list                  # 显示当前Agent的TODO
      oc-collab todo list --unread        # 仅显示未读TODO
      oc-collab todo list --unread --agent 2  # 筛选接收者
      oc-collab todo list --unread --json # JSON格式
    """
    try:
        queue_manager = TodoQueueManager()

        # 默认使用当前Agent过滤，除非显式指定--agent
        current_agent = None
        if agent is None:
            registry = AgentRegistry()
            current = registry.get_current_agent_id()
            if current:
                # 提取数字部分：agent2 -> 2
                current_agent = current.replace("agent", "")
                agent = current_agent

        if unread:
            agent_id = f"agent{agent}" if agent else None
            todos = queue_manager.get_unread(agent_id, priority)

            if json:
                import json
                output = {
                    "unread_count": len(todos),
                    "todos": [
                        {
                            "id": t.id,
                            "content": t.content,
                            "priority": t.priority,
                            "from_agent": t.from_agent,
                            "created_at": t.created_at
                        }
                        for t in todos
                    ]
                }
                click.echo(json.dumps(output, indent=2, ensure_ascii=False))
                return

            if not todos:
                click.echo("✅ 无未读TODO")
                return

            click.echo(f"\n🔔 未读TODO ({len(todos)}个):")
            click.echo("-" * 60)

            for t in todos:
                priority_icons = {"high": "🔴", "medium": "🟡", "low": "🟢"}
                icon = priority_icons.get(t.priority, "⚪")
                click.echo(f"  {icon} [{t.id}] {t.content}")
                click.echo(f"      from {t.from_agent} · {t.created_at}")
                click.echo("")

        else:
            agent_id = f"agent{agent}" if agent else None
            todos = queue_manager.get_all(agent_id)

            if json:
                import json
                output = {
                    "total_count": len(todos),
                    "todos": [
                        {
                            "id": t.id,
                            "content": t.content,
                            "priority": t.priority,
                            "from_agent": t.from_agent,
                            "to_agent": t.to_agent,
                            "read": t.read,
                            "created_at": t.created_at
                        }
                        for t in todos
                    ]
                }
                click.echo(json.dumps(output, indent=2, ensure_ascii=False))
                return

            if not todos:
                click.echo("TODO列表为空")
                return

            click.echo(f"\n📋 TODO列表 ({len(todos)}个):")
            click.echo("-" * 60)

            for t in todos:
                status = "✅" if t.read else "📬"
                priority_icons = {"high": "🔴", "medium": "🟡", "low": "🟢"}
                icon = priority_icons.get(t.priority, "⚪")
                click.echo(f"  {status} {icon} [{t.id}] {t.content}")
                click.echo(f"      {t.from_agent} → {t.to_agent} · {t.created_at}")

    except Exception as e:
        click.echo(f"❌ 获取TODO列表失败: {e}")


@todo_group.command("mark-read")
@click.argument("todo_id")
@click.option("--agent", type=click.Choice(["1", "2"]), help="验证接收者")
def mark_read_command(todo_id: str, agent: str):
    """标记TODO为已读

    示例:
      oc-collab todo mark-read TODO-001
    """
    try:
        from ..core.todo_sync_manager import TodoSyncManager
        sync_manager = TodoSyncManager()

        result = sync_manager.update_todo(todo_id, is_read=1)

        if result:
            click.echo(f"✅ TODO {todo_id} 已标记为已读")
        else:
            click.echo(f"❌ TODO {todo_id} 不存在")

    except Exception as e:
        click.echo(f"❌ 标记失败: {e}")


@todo_group.command("mark-all-read")
@click.option("--agent", type=click.Choice(["1", "2"]), help="仅标记该接收者的TODO")
def mark_all_read_command(agent: str):
    """标记所有TODO为已读

    示例:
      oc-collab todo mark-all-read        # 标记所有
      oc-collab todo mark-all-read --agent 2  # 仅标记发给Agent2的
    """
    try:
        queue_manager = TodoQueueManager()
        agent_id = f"agent{agent}" if agent else None

        count = queue_manager.mark_all_read(agent_id)

        if count > 0:
            click.echo(f"✅ 已标记 {count} 个TODO为已读")
        else:
            click.echo("✅ 无未读TODO")

    except Exception as e:
        click.echo(f"❌ 标记失败: {e}")


@todo_group.command("stats")
@click.option("--agent", type=click.Choice(["1", "2"]), help="按接收者筛选")
@click.option("--json", is_flag=True, help="JSON格式输出")
def todo_stats_command(agent: str, json: bool):
    """显示TODO统计信息

    示例:
      oc-collab todo stats
      oc-collab todo stats --agent 1
      oc-collab todo stats --json
    """
    try:
        queue_manager = TodoQueueManager()
        agent_id = f"agent{agent}" if agent else None
        stats = queue_manager.get_stats(agent_id)

        if json:
            import json
            output = {
                "total": stats.total,
                "unread": stats.unread,
                "by_agent": stats.by_agent,
                "by_priority": stats.by_priority,
                "last_updated": stats.last_updated
            }
            click.echo(json.dumps(output, indent=2, ensure_ascii=False))
            return

        click.echo(f"\n📊 TODO队列统计:")
        click.echo(f"  总数: {stats.total}")
        click.echo(f"  未读: {stats.unread}")
        click.echo(f"  按Agent: agent1={stats.by_agent.get('agent1', 0)}, agent2={stats.by_agent.get('agent2', 0)}")
        click.echo(f"  按优先级: 高={stats.by_priority.get('high', 0)}, 中={stats.by_priority.get('medium', 0)}, 低={stats.by_priority.get('low', 0)}")
        click.echo(f"  最后更新: {stats.last_updated}")
        click.echo("")

    except Exception as e:
        click.echo(f"❌ 获取统计失败: {e}")


@todo_group.command("cleanup")
@click.option("--days", default=7, help="清理N天前的已读TODO", type=int)
def todo_cleanup_command(days: int):
    """清理过期的已读TODO

    示例:
      oc-collab todo cleanup
      oc-collab todo cleanup --days 14
    """
    try:
        queue_manager = TodoQueueManager()
        count = queue_manager.cleanup(days)
        click.echo(f"✅ 已清理 {count} 个过期TODO")

    except Exception as e:
        click.echo(f"❌ 清理失败: {e}")


@todo_group.command("clear")
@click.option("--agent", type=click.Choice(["1", "2"]), help="仅清空该接收者的TODO")
def todo_clear_command(agent: str):
    """清空TODO队列

    示例:
      oc-collab todo clear         # 清空所有
      oc-collab todo clear --agent 1  # 仅清空发给Agent1的
    """
    try:
        queue_manager = TodoQueueManager()
        agent_id = f"agent{agent}" if agent else None

        count = queue_manager.clear(agent_id)

        if count > 0:
            click.echo(f"✅ 已清空 {count} 个TODO")
        else:
            click.echo("✅ TODO队列已为空")

    except Exception as e:
        click.echo(f"❌ 清空失败: {e}")


@todo_group.command("show")
@click.argument("todo_id")
@click.option("--json", is_flag=True, help="JSON格式输出")
def todo_show_command(todo_id: str, json: bool):
    """显示TODO详情
    
    示例:
      oc-collab todo show TODO-1-001
      oc-collab todo show TODO-1to2-001 --json
    """
    try:
        from ..core.context_manager import ContextManager
        from ..core.todo_sync_manager import TodoSyncManager
        ctx = ContextManager().load_context()
        
        sync_manager = TodoSyncManager()
        todo = sync_manager.get_todo(todo_id)
        
        if not todo:
            click.echo(f"❌ 未找到TODO: {todo_id}")
            return
        
        # 自动ACK（如果查看者是接收者）
        current_agent = str(ctx.agent).replace("agent", "") if ctx.agent else None
        if current_agent and todo.agent_id and int(current_agent) == todo.agent_id:
            from ..core.ack_confirm import ACKConfirm
            ack = ACKConfirm()
            ack.auto_ack_on_show(todo_id, f"agent{current_agent}")
        
        if json:
            import json
            click.echo(json.dumps({
                "id": todo.id,
                "content": todo.content,
                "status": todo.status,
                "priority": todo.priority,
                "agent_id": todo.agent_id,
                "created_at": todo.created_at,
                "updated_at": todo.updated_at
            }, indent=2, ensure_ascii=False))
        else:
            click.echo(f"\n📋 TODO详情:")
            click.echo(f"  ID: {todo.id}")
            click.echo(f"  内容: {todo.content}")
            click.echo(f"  状态: {todo.status}")
            click.echo(f"  优先级: {todo.priority}")
            click.echo(f"  接收者: agent{todo.agent_id}")
            click.echo(f"  创建时间: {todo.created_at}")
            click.echo("")
    
    except Exception as e:
        click.echo(f"❌ 显示失败: {e}")


@todo_group.command("ack")
@click.argument("todo_id")
def todo_ack_command(todo_id: str):
    """手动确认TODO
    
    示例:
      oc-collab todo ack TODO-1-001
    """
    try:
        from ..core.context_manager import ContextManager
        ctx = ContextManager().load_context()
        
        current_agent = ctx.agent
        if current_agent is None:
            click.echo("❌ 无法确定当前Agent")
            return
        
        # 处理agent可能是字符串或数字的情况
        if isinstance(current_agent, int):
            current_agent = str(current_agent)
        elif isinstance(current_agent, str) and current_agent.isdigit():
            pass  # 已经是数字字符串
        else:
            current_agent = current_agent.replace("agent", "") if current_agent else None
        
        from ..core.ack_confirm import ACKConfirm
        ack = ACKConfirm()
        
        result = ack.acknowledge(todo_id, f"agent{current_agent}")
        
        if result:
            click.echo(f"✅ TODO {todo_id} 已确认")
        else:
            click.echo(f"❌ 确认失败")
    
    except Exception as e:
        click.echo(f"❌ 确认失败: {e}")


@todo_group.command("complete")
@click.argument("todo_id")
@click.option("--signoff/--no-signoff", default=False, help="完成后自动触发signoff")
@click.option("--test-results", type=str, default="", help="测试结果 JSON: {\"passed\":10,\"failed\":0,\"coverage\":93}")
def todo_complete_command(todo_id: str, signoff: bool, test_results: str):
    """标记TODO为完成
    
    示例:
      oc-collab todo complete TODO-1-001
      oc-collab todo complete TODO-1-001 --signoff --test-results '{"passed":10,"failed":0,"coverage":93}'
    """
    try:
        import json
        from ..core.todo_sync_manager import TodoSyncManager
        sync_manager = TodoSyncManager()
        
        result = sync_manager.update_todo(todo_id, status="completed")
        
        if result:
            click.echo(f"✅ TODO {todo_id} 已标记为完成")
            
            if signoff and test_results:
                try:
                    import json
                    from pathlib import Path
                    project_path = str(Path.cwd())
                    test_data = json.loads(test_results)
                    from ..core.state_manager import StateManager
                    from ..core.workflow import WorkflowEngine
                    from ..core.signoff import SignoffEngine
                    state_manager = StateManager(project_path)
                    workflow_engine = WorkflowEngine(state_manager)
                    signoff_mgr = SignoffEngine(state_manager, workflow_engine)
                    
                    stage = "test"
                    trigger_result = signoff_mgr.auto_trigger_signoff(stage, test_data)
                    
                    if trigger_result.get("triggered"):
                        click.echo(f"🔔 自动触发signoff: {trigger_result.get('message')}")
                        signoff_todo = signoff_mgr.create_signoff_todo_from_test(stage, test_data)
                        click.echo(f"✅ 已创建signoff TODO: {signoff_todo.get('message', '')}")
                    else:
                        click.echo(f"ℹ️  未触发signoff: {trigger_result.get('message')}")
                except json.JSONDecodeError:
                    click.echo("⚠️  test-results JSON格式错误")
                except Exception as e:
                    click.echo(f"⚠️  signoff触发失败: {e}")
            elif signoff:
                click.echo("ℹ️  使用 --signoff 时请同时提供 --test-results")
        else:
            click.echo(f"❌ TODO {todo_id} 不存在")
    
    except Exception as e:
        click.echo(f"❌ 操作失败: {e}")


@todo_group.command("delete")
@click.argument("todo_id")
def todo_delete_command(todo_id: str):
    """删除TODO
    
    示例:
      oc-collab todo delete TODO-1-001
    """
    try:
        from ..core.todo_sync_manager import TodoSyncManager
        sync_manager = TodoSyncManager()
        
        result = sync_manager.delete_todo(todo_id)
        
        if result:
            click.echo(f"✅ TODO {todo_id} 已删除")
        else:
            click.echo(f"❌ TODO {todo_id} 不存在")
    
    except Exception as e:
        click.echo(f"❌ 删除失败: {e}")
