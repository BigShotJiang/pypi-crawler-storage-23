"""
OpenCode Agent Session Manager - 使用HTTP API实现常驻Agent

功能：
1. 启动OpenCode服务器
2. 创建持久session
3. 通过HTTP API发送任务
4. 获取执行结果

基于 OpenCode Server HTTP API:
- POST /session - 创建session
- POST /session/:id/message - 发送消息并等待响应
- GET /session - 列出所有session
"""

import requests
import json
import subprocess
import time
import os
import signal
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class OpenCodeMessage:
    """消息响应"""
    content: str
    message_id: str
    parts: List[Dict]


@dataclass
class OpenCodeSession:
    """Session信息"""
    id: str
    title: str
    created_at: str


class OpenCodeServer:
    """OpenCode服务器管理器"""
    
    def __init__(self, port: int = 4096, hostname: str = "127.0.0.1"):
        self.port = port
        self.hostname = hostname
        self.base_url = f"http://{hostname}:{port}"
        self.process: Optional[subprocess.Popen] = None
    
    def start(self, timeout: int = 30) -> bool:
        """启动OpenCode服务器"""
        logger.info(f"启动OpenCode服务器 on {self.base_url}...")
        
        self.process = subprocess.Popen(
            ["opencode", "serve", "--port", str(self.port), "--hostname", self.hostname],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=os.environ.copy()
        )
        
        # 等待服务器就绪
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                resp = requests.get(f"{self.base_url}/global/health", timeout=1)
                if resp.status_code == 200:
                    logger.info(f"✅ OpenCode服务器已就绪: {self.base_url}")
                    return True
            except:
                pass
            time.sleep(1)
        
        logger.error("❌ OpenCode服务器启动失败")
        return False
    
    def stop(self):
        """停止OpenCode服务器"""
        if self.process:
            logger.info("停止OpenCode服务器...")
            self.process.terminate()
            self.process.wait(timeout=5)
            logger.info("✅ OpenCode服务器已停止")
    
    def is_running(self) -> bool:
        """检查服务器是否运行"""
        try:
            resp = requests.get(f"{self.base_url}/global/health", timeout=1)
            return resp.status_code == 200
        except:
            return False


class OpenCodeSessionManager:
    """OpenCode Session管理器 - 通过HTTP API"""
    
    def __init__(self, server: OpenCodeServer):
        self.server = server
        self.base_url = server.base_url
        self.session_id: Optional[str] = None
    
    def create_session(self, title: str = "AutoExecute Agent") -> Optional[OpenCodeSession]:
        """创建新session"""
        try:
            resp = requests.post(
                f"{self.base_url}/session",
                json={"title": title},
                timeout=10
            )
            if resp.status_code == 200:
                data = resp.json()
                self.session_id = data["id"]
                logger.info(f"✅ 创建Session: {self.session_id}")
                return OpenCodeSession(
                    id=data["id"],
                    title=data.get("title", ""),
                    created_at=data.get("createdAt", "")
                )
        except Exception as e:
            logger.error(f"创建Session失败: {e}")
        return None
    
    def send_message(self, message: str, timeout: int = 300) -> Optional[OpenCodeMessage]:
        """
        发送消息并等待响应 - 核心方法
        
        这是实现自动执行的关键：
        1. 把TODO内容作为message发送
        2. OpenCode使用内置工具执行任务
        3. 返回执行结果
        """
        if not self.session_id:
            logger.error("未创建session")
            return None
        
        try:
            logger.info(f"发送消息: {message[:50]}...")
            
            resp = requests.post(
                f"{self.base_url}/session/{self.session_id}/message",
                json={
                    "parts": [{"type": "text", "text": message}],
                    "noReply": False
                },
                timeout=timeout
            )
            
            if resp.status_code == 200:
                data = resp.json()
                # 解析响应内容
                parts = data.get("parts", [])
                content = ""
                for part in parts:
                    if part.get("type") == "text":
                        content += part.get("text", "")
                    elif part.get("type") == "tool_use":
                        content += f"\n[工具调用: {part.get('name')}]"
                    elif part.get("type") == "tool_result":
                        content += f"\n[工具结果: {part.get('result', '')}]"
                
                logger.info(f"✅ 消息发送成功, message_id: {data.get('info', {}).get('id')}")
                
                return OpenCodeMessage(
                    content=content,
                    message_id=data.get("info", {}).get("id", ""),
                    parts=parts
                )
            else:
                logger.error(f"发送消息失败: {resp.status_code} - {resp.text}")
                
        except requests.exceptions.Timeout:
            logger.error("消息发送超时")
        except Exception as e:
            logger.error(f"发送消息失败: {e}")
        
        return None
    
    def get_session_todos(self) -> List[Dict]:
        """获取session的TODO列表"""
        if not self.session_id:
            return []
        
        try:
            resp = requests.get(
                f"{self.base_url}/session/{self.session_id}/todo",
                timeout=10
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception as e:
            logger.error(f"获取TODO失败: {e}")
        
        return []
    
    def list_sessions(self) -> List[OpenCodeSession]:
        """列出所有session"""
        try:
            resp = requests.get(f"{self.base_url}/session", timeout=10)
            if resp.status_code == 200:
                sessions = resp.json()
                return [
                    OpenCodeSession(
                        id=s["id"],
                        title=s.get("title", ""),
                        created_at=s.get("createdAt", "")
                    )
                    for s in sessions
                ]
        except Exception as e:
            logger.error(f"列出session失败: {e}")
        return []


class OpenCodeAutoExecutor:
    """
    OpenCode自动执行器 - 整合方案
    
    完整流程：
    1. 启动OpenCode服务器
    2. 创建持久session
    3. 监听TODO
    4. 收到任务 → 通过HTTP API发送消息
    5. 等待OpenCode执行完成
    6. 返回结果
    """
    
    def __init__(self, port: int = 4096):
        self.server = OpenCodeServer(port=port)
        self.session_manager: Optional[OpenCodeSessionManager] = None
        self.running = False
    
    def start(self) -> bool:
        """启动自动执行器"""
        # 1. 启动服务器
        if not self.server.start():
            return False
        
        # 2. 创建session
        self.session_manager = OpenCodeSessionManager(self.server)
        session = self.session_manager.create_session("AutoExecute Agent")
        
        if session:
            self.running = True
            logger.info("🚀 OpenCode自动执行器已启动")
            return True
        
        return False
    
    def stop(self):
        """停止自动执行器"""
        self.running = False
        self.server.stop()
        logger.info("🛑 OpenCode自动执行器已停止")
    
    def execute_task(self, task_description: str, timeout: int = 300) -> Optional[str]:
        """
        执行任务 - 核心方法
        
        把任务描述发送给OpenCode，OpenCode会：
        1. 理解任务内容
        2. 使用工具执行（read/edit/write/bash等）
        3. 返回执行结果
        """
        if not self.session_manager:
            logger.error("自动执行器未启动")
            return None
        
        # 通过HTTP API发送任务
        result = self.session_manager.send_message(task_description, timeout=timeout)
        
        if result:
            return result.content
        
        return None
    
    def demo_review_task(self):
        """演示：评审任务"""
        task = """请评审文件 src/core/todo_storage.py
关注：
1. 代码结构是否合理
2. 是否有潜在bug
3. 是否有安全风险"""
        
        result = self.execute_task(task)
        print("\n" + "="*60)
        print("评审结果:")
        print("="*60)
        print(result or "执行失败")
        print("="*60)


def demo_basic():
    """基础演示：启动服务器，创建session，发送消息"""
    print("="*60)
    print("OpenCode HTTP API 基础演示")
    print("="*60)
    
    # 启动服务器
    server = OpenCodeServer(port=4096)
    if not server.start():
        print("❌ 服务器启动失败")
        return
    
    try:
        # 创建session
        manager = OpenCodeSessionManager(server)
        session = manager.create_session("Demo Session")
        
        if not session:
            print("❌ 创建session失败")
            return
        
        print(f"\n✅ Session创建成功: {session.id}")
        
        # 发送消息
        print("\n发送测试消息...")
        response = manager.send_message("请简单介绍一下你自己")
        
        if response:
            print(f"\n✅ 收到响应:")
            print("-"*60)
            print(response.content[:500] if response.content else "(无内容)")
            print("-"*60)
        else:
            print("❌ 未收到响应")
    
    finally:
        server.stop()


def demo_auto_execute():
    """演示：自动执行任务"""
    print("="*60)
    print("OpenCode 自动执行演示")
    print("="*60)
    
    executor = OpenCodeAutoExecutor(port=4096)
    
    if not executor.start():
        print("❌ 自动执行器启动失败")
        return
    
    try:
        # 执行评审任务
        executor.demo_review_task()
    
    finally:
        executor.stop()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--auto":
        demo_auto_execute()
    else:
        demo_basic()
