"""
Agent类型兼容层

提供AgentType枚举的动态版本，支持从配置动态加载。
"""

from enum import Enum
from typing import List, Optional
from .agent_registry import get_default_agents, is_valid_agent


class DynamicAgentType:
    """动态Agent类型 - 支持从配置动态加载"""
    
    _cached_agents: Optional[List[str]] = None
    
    @classmethod
    def get_all_agents(cls) -> List[str]:
        """获取所有Agent类型"""
        if cls._cached_agents is None:
            cls._cached_agents = get_default_agents()
        return cls._cached_agents
    
    @classmethod
    def is_valid(cls, agent_id: str) -> bool:
        """检查Agent ID是否有效"""
        return is_valid_agent(agent_id)
    
    @classmethod
    def refresh(cls):
        """刷新缓存"""
        cls._cached_agents = None


class AgentType(Enum):
    """Agent类型枚举 - 兼容旧代码"""
    
    AGENT_1 = "agent1"
    AGENT_2 = "agent2"
    
    @classmethod
    def from_id(cls, agent_id: str) -> "AgentType":
        """从Agent ID获取AgentType"""
        if agent_id == "agent1":
            return cls.AGENT_1
        elif agent_id == "agent2":
            return cls.AGENT_2
        else:
            for agent in cls:
                if agent.value == agent_id:
                    return agent
            return cls.AGENT_1
    
    @classmethod
    def get_default(cls) -> "AgentType":
        """获取默认Agent类型"""
        return cls.AGENT_1
    
    @classmethod
    def list_all(cls) -> List["AgentType"]:
        """列出所有Agent类型"""
        return list(cls)


__all__ = ["AgentType", "DynamicAgentType"]
