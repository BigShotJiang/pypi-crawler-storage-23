"""统一配置管理模块。

提供配置接口定义和默认实现，支持依赖注入。
"""
from pathlib import Path
from typing import Optional, Protocol
import os


class IConfigProvider(Protocol):
    """配置提供者接口 - 满足 IConfigProvider 规范"""
    
    VERSION = "1.0.0"
    
    def get_data_dir(self) -> str:
        """获取数据目录路径
        
        Returns:
            str: 数据目录相对路径，如 "state"
        """
        ...
    
    def get_config_dir(self) -> str:
        """获取配置目录路径
        
        Returns:
            str: 配置目录相对路径，如 "config"
        """
        ...
    
    def get_log_dir(self) -> str:
        """获取日志目录路径
        
        Returns:
            str: 日志目录相对路径，如 "logs"
        """
        ...
    
    def get_temp_dir(self) -> str:
        """获取临时目录路径
        
        Returns:
            str: 临时目录相对路径，如 "tmp"
        """
        ...
    
    def get_todo_db_path(self) -> str:
        """获取 TODO 数据库文件路径
        
        Returns:
            str: TODO 数据库文件相对路径，如 "todos.db"
        """
        ...
    
    def get_state_file_path(self) -> str:
        """获取状态文件路径
        
        Returns:
            str: 状态文件相对路径，如 "project_state.yaml"
        """
        ...
    
    def get_lock_file_path(self, name: str) -> str:
        """获取锁文件路径
        
        Args:
            name: 锁文件名，如 "todo_id"
        
        Returns:
            str: 锁文件相对路径，如 ".todo_id.lock"
        """
        ...
    
    def get_agent_status_db_path(self) -> str:
        """获取 Agent 状态数据库路径
        
        Returns:
            str: Agent 状态数据库相对路径，如 "agent_status.db"
        """
        ...
    
    def get_session_dir(self) -> str:
        """获取会话目录路径
        
        Returns:
            str: 会话目录相对路径，如 "sessions"
        """
        ...
    
    def get_opencode_db_path(self) -> str:
        """获取 OpenCode 原数据库路径
        
        Returns:
            str: OpenCode 原数据库相对路径，如 ".opencode/opencode.db"
        """
        ...
    
    def get_identity_file_path(self) -> str:
        """获取 Agent 身份文件路径
        
        Returns:
            str: Agent 身份文件相对路径，如 "agent.identity"
        """
        ...
    
    def get_pid_file_path(self) -> str:
        """获取进程 ID 文件路径
        
        Returns:
            str: 进程 ID 文件相对路径，如 "agent.pid"
        """
        ...
    
    def get_git_sync_config_path(self) -> str:
        """获取 Git 同步配置路径
        
        Returns:
            str: Git 同步配置相对路径，如 "git_sync.yaml"
        """
        ...
    
    def get_notification_config_path(self) -> str:
        """获取通知配置路径
        
        Returns:
            str: 通知配置相对路径，如 "notification.yaml"
        """
        ...
    
    def get_skill_index_path(self) -> str:
        """获取 Skill 索引配置路径
        
        Returns:
            str: Skill 索引配置相对路径，如 "skill_index.yaml"
        """
        ...
    
    def get_agents_config_path(self) -> str:
        """获取 Agent 注册配置路径
        
        Returns:
            str: Agent 注册配置相对路径，如 "agents.yaml"
        """
        ...
    
    def get_file_owners_path(self) -> str:
        """获取文件 Owner 配置路径
        
        Returns:
            str: 文件 Owner 配置相对路径，如 "file_owners.yaml"
        """
        ...
    
    def get_full_path(self, relative_path: str, base_path: Optional[Path] = None) -> Path:
        """获取完整路径
        
        Args:
            relative_path: 相对路径
            base_path: 基础路径，默认为当前工作目录
        
        Returns:
            Path: 完整路径
        """
        ...


class LocalConfigProvider:
    """本地配置提供者 - 满足 IConfigProvider 接口的默认实现
    
    支持通过环境变量 OC_TODO_DB_PATH 指定统一数据库路径，
    实现多子系统共享同一个TODO数据库。
    """
    
    VERSION = "1.0.0"
    
    def __init__(self, project_path: Optional[Path] = None):
        self.project_path = project_path or Path.cwd()
    
    def _get_env_db_path(self, default: str) -> str:
        """从环境变量获取数据库路径"""
        env_path = os.environ.get("OC_TODO_DB_PATH")
        if env_path:
            return env_path
        return default
    
    def get_data_dir(self) -> str:
        return "state"
    
    def get_config_dir(self) -> str:
        return "config"
    
    def get_log_dir(self) -> str:
        return "logs"
    
    def get_temp_dir(self) -> str:
        return "tmp"
    
    def get_todo_db_path(self) -> str:
        return self._get_env_db_path("todos.db")
    
    def get_state_file_path(self) -> str:
        return "project_state.yaml"
    
    def get_lock_file_path(self, name: str) -> str:
        return f".{name}.lock"
    
    def get_agent_status_db_path(self) -> str:
        return "agent_status.db"
    
    def get_session_dir(self) -> str:
        return "sessions"
    
    def get_opencode_db_path(self) -> str:
        return ".opencode/opencode.db"
    
    def get_identity_file_path(self) -> str:
        return "agent.identity"
    
    def get_pid_file_path(self) -> str:
        return "agent.pid"
    
    def get_git_sync_config_path(self) -> str:
        return "git_sync.yaml"
    
    def get_notification_config_path(self) -> str:
        return "notification.yaml"
    
    def get_skill_index_path(self) -> str:
        return "skill_index.yaml"
    
    def get_agents_config_path(self) -> str:
        return "agents.yaml"
    
    def get_file_owners_path(self) -> str:
        return "file_owners.yaml"
    
    def get_full_path(self, relative_path: str, base_path: Optional[Path] = None) -> Path:
        base = base_path or self.project_path
        return base / relative_path
    
    def get_todo_db_full_path(self) -> Path:
        """获取 TODO 数据库完整路径"""
        db_path = self.get_todo_db_path()
        if Path(db_path).is_absolute():
            return Path(db_path)
        return self.project_path / self.get_data_dir() / db_path
    
    def get_state_file_full_path(self) -> Path:
        """获取状态文件完整路径"""
        return self.project_path / self.get_data_dir() / self.get_state_file_path()
    
    def get_lock_file_full_path(self, name: str) -> Path:
        """获取锁文件完整路径"""
        return self.project_path / self.get_data_dir() / self.get_lock_file_path(name)


class AppConfig:
    """应用配置类 - 统一管理项目配置"""
    
    VERSION = "1.0.0"
    
    def __init__(
        self,
        project_path: Optional[str] = None,
        config_provider: Optional[IConfigProvider] = None
    ):
        self.project_path = Path(project_path) if project_path else Path.cwd()
        self.config_provider = config_provider or LocalConfigProvider(self.project_path)
        
        self._ensure_directories()
    
    def _ensure_directories(self):
        """确保必要目录存在"""
        dirs = [
            self.project_path / self.config_provider.get_data_dir(),
            self.project_path / self.config_provider.get_config_dir(),
            self.project_path / self.config_provider.get_log_dir(),
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)
    
    @property
    def todo_db_path(self) -> Path:
        """TODO数据库路径"""
        return self.config_provider.get_todo_db_full_path()
    
    @property
    def state_file_path(self) -> Path:
        """状态文件路径"""
        return self.config_provider.get_state_file_full_path()
    
    def get_lock_path(self, name: str) -> Path:
        """锁文件路径"""
        return self.config_provider.get_lock_file_full_path(name)
    
    def get_path(self, relative_path: str) -> Path:
        """获取项目内相对路径"""
        return self.project_path / relative_path


_default_config: Optional[AppConfig] = None


def get_default_config(project_path: Optional[str] = None) -> AppConfig:
    """获取默认配置单例
    
    Args:
        project_path: 项目路径，默认当前目录
    
    Returns:
        AppConfig: 应用配置实例
    """
    global _default_config
    if _default_config is None:
        _default_config = AppConfig(project_path)
    return _default_config


def set_default_config(config: AppConfig):
    """设置默认配置
    
    Args:
        config: 应用配置实例
    """
    global _default_config
    _default_config = config


def reset_default_config():
    """重置默认配置"""
    global _default_config
    _default_config = None
