"""
自动执行监听器 - PoC v1.0

功能：
1. 轮询检测带有 auto_execute=1 的TODO
2. 触发自动执行
"""

import time
import logging
import json
from typing import Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class AutoExecuteListener:
    """自动执行监听器"""
    
    def __init__(self, storage, executor, interval: int = 5):
        self.storage = storage
        self.executor = executor
        self.interval = interval
        self.running = False
    
    def start(self, interval: Optional[int] = None):
        """启动监听"""
        if interval:
            self.interval = interval
        self.running = True
        logger.info(f"启动自动执行监听器，间隔 {self.interval} 秒")
        
        while self.running:
            try:
                self._check_and_execute()
            except Exception as e:
                logger.error(f"检查失败: {e}")
            time.sleep(self.interval)
    
    def stop(self):
        """停止监听"""
        self.running = False
        logger.info("自动执行监听器已停止")
    
    def _check_and_execute(self):
        """检查并执行自动执行TODO"""
        # 查询所有pending的TODO
        todos = self.storage.list(status='pending')
        
        for todo in todos:
            if not isinstance(todo, dict):
                continue
                
            todo_id = todo.get('id')
            receiver = todo.get('receiver')
            
            # 检查metadata中是否有auto_execute
            metadata_str = todo.get('metadata')
            try:
                # metadata可能是双重转义的JSON字符串
                if isinstance(metadata_str, str):
                    # 先尝试解析一次
                    metadata = json.loads(metadata_str)
                    # 如果解析结果是字符串，说明是双重转义的，再解析一次
                    if isinstance(metadata, str):
                        metadata = json.loads(metadata)
                else:
                    metadata = metadata_str or {}
            except:
                metadata = {}
            
            if metadata.get('auto_execute') != 1:
                continue
            
            logger.info(f"发现自动执行TODO: {todo_id}")
            
            # 防止循环：自己创建的TODO自己不要执行
            sender = todo.get('sender')
            if sender == receiver:
                logger.warning(f"跳过循环: sender={sender} == receiver={receiver}")
                continue
            
            # 执行
            try:
                result = self.executor.execute(todo)
                
                # 更新状态 - 使用字典参数
                self.storage.update(todo_id, {
                    'status': 'completed',
                    'completed_at': datetime.now().isoformat(),
                    'metadata': {
                        **metadata,
                        'executed_at': datetime.now().isoformat(),
                        'execution_result': result
                    }
                })
                
                logger.info(f"TODO {todo_id} 执行完成: {result}")
                
                # 通知发起人
                self._notify_sender(todo, result)
                
            except Exception as e:
                logger.error(f"执行失败: {e}")
                self.storage.update(todo_id, {
                    'metadata': {
                        **metadata,
                        'execution_result': f"失败: {e}"
                    }
                })
    
    def _notify_sender(self, todo, result):
        """通知发起人"""
        sender = todo.get('sender')
        content = todo.get('content')
        logger.info(f"通知发起人 {sender}: TODO执行完成 - {content[:50]}")
