"""
TODO编号生成器

提供Agent独立的TODO编号生成功能，支持多Agent编号格式。
使用UUID+时间戳方案，支持跨机器协作。
"""

import os
import re
import uuid
from pathlib import Path
from typing import Optional, Dict
from datetime import datetime
import yaml
import logging

logger = logging.getLogger(__name__)


class TodoIdGenerator:
    """Agent独立TODO编号生成器，支持多Agent编号格式
    
    使用 UUID+时间戳 方案，支持跨机器协作，无需文件锁。
    """

    def __init__(
        self,
        agent_id: Optional[str] = None,
        counter_file: Optional[str] = None,
        state_file: Optional[str] = None,
        use_uuid: bool = True
    ):
        """
        Args:
            agent_id: Agent标识 ("1" 或 "2")，新格式不需要
            counter_file: 旧格式计数器文件路径（兼容用）
            state_file: 状态文件路径（用于旧格式兼容）
            use_uuid: 是否使用UUID+时间戳方案（新格式），默认True
        """
        self.agent_id = agent_id
        self.counter_file = Path(counter_file) if counter_file else None
        self.state_file = state_file or "state/project_state.yaml"
        self.lock_file = "state/.todo_id.lock"
        self.use_uuid = use_uuid

    def generate(self, creator: Optional[str] = None, receiver: Optional[str] = None) -> str:
        """
        生成TODO编号
        
        Args:
            creator: 创建者Agent ID (如 "1", "2")
            receiver: 接收者Agent ID (如 "1", "2")
        
        Returns:
            TODO编号
            - 新格式: TODO-1to2-20260220123456-a1b2c3d4
            - 旧格式: TODO-1to2-001 (仅当 use_uuid=False 时)
        """
        if self.use_uuid:
            return self._generate_uuid_format(creator, receiver)
        else:
            return self._generate_legacy_counter(creator, receiver)

    def _generate_uuid_format(
        self,
        creator: Optional[str] = None,
        receiver: Optional[str] = None
    ) -> str:
        """生成UUID格式的TODO编号
        
        格式: TODO-{creator}to{receiver}-{timestamp}-{uuid_short}
        示例: TODO-1to2-20260220123456-a1b2c3d4
        
        优点: 跨机器无需协调，保证唯一性
        """
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        uuid_short = uuid.uuid4().hex[:8]
        
        creator_str = creator or "x"
        receiver_str = receiver or "x"
        
        return f"TODO-{creator_str}to{receiver_str}-{timestamp}-{uuid_short}"

    def _generate_legacy_counter(
        self,
        creator: Optional[str] = None,
        receiver: Optional[str] = None
    ) -> str:
        """旧格式生成（兼容）- 使用数据库自增"""
        if not creator:
            creator = self.agent_id or "1"
        if not receiver:
            receiver = creator
        
        key = f"{creator}to{receiver}"
        
        state = self._load_state()
        counters = state.get("todo_id_counters", {})
        
        if key not in counters:
            counters[key] = 0
        
        counters[key] += 1
        seq = counters[key]
        
        state["todo_id_counters"] = counters
        self._save_state(state)
        
        return f"TODO-{creator}to{receiver}-{seq:03d}"

    def _load_state(self) -> Dict:
        """加载状态"""
        if not os.path.exists(self.state_file):
            return {"todo_id_counters": {}}
        try:
            with open(self.state_file, 'r') as f:
                return yaml.safe_load(f) or {}
        except yaml.YAMLError:
            return {"todo_id_counters": {}}

    def _save_state(self, state: Dict):
        """保存状态"""
        state_dir = os.path.dirname(self.state_file)
        if state_dir:
            os.makedirs(state_dir, exist_ok=True)
        with open(self.state_file, 'w') as f:
            yaml.safe_dump(state, f)

    def parse(self, todo_id: str) -> Optional[Dict]:
        """
        解析TODO编号
        
        Args:
            todo_id: TODO编号
        
        Returns:
            dict{creator, receiver, timestamp, uuid, is_legacy, is_uuid} 或 None
        """
        # 新格式: TODO-1to2-20260220123456-a1b2c3d4
        match = re.match(r'TODO-(\d?)to(\d?)-(\d{14})-([a-f0-9]{8})', todo_id)
        if match:
            return {
                "creator": match.group(1) if match.group(1) != 'x' else None,
                "receiver": match.group(2) if match.group(2) != 'x' else None,
                "timestamp": match.group(3),
                "uuid": match.group(4),
                "is_legacy": False,
                "is_uuid": True
            }
        
        # 旧格式: TODO-1to2-001
        match = re.match(r'TODO-(\d?)to(\d?)-(\d+)', todo_id)
        if match:
            return {
                "creator": match.group(1),
                "receiver": match.group(2),
                "seq": int(match.group(3)),
                "is_legacy": True,
                "is_uuid": False
            }
        
        # 早期旧格式: TODO-1-001
        match = re.match(r'TODO-(\d+)-(\d+)', todo_id)
        if match:
            return {
                "creator": match.group(1),
                "receiver": match.group(1),
                "seq": int(match.group(2)),
                "is_legacy": True,
                "is_uuid": False
            }
        
        return None

    def is_valid(self, todo_id: str) -> bool:
        """验证TODO ID格式
        
        Args:
            todo_id: TODO ID
        
        Returns:
            是否有效
        """
        return self.parse(todo_id) is not None

    def is_uuid_format(self, todo_id: str) -> bool:
        """判断是否UUID格式"""
        parsed = self.parse(todo_id)
        return parsed.get("is_uuid", False) if parsed else False

    def is_legacy_format(self, todo_id: str) -> bool:
        """判断是否旧格式"""
        parsed = self.parse(todo_id)
        return parsed.get("is_legacy", False) if parsed else False


class TodoIdConflictError(Exception):
    """TODO编号冲突异常"""

    def __init__(self, message: str, existing_id: str):
        super().__init__(message)
        self.existing_id = existing_id
