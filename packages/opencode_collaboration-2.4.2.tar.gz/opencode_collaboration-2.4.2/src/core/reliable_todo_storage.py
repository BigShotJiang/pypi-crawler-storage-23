"""
可靠的TODO存储层

提供100%可靠的TODO数据存储，确保：
1. 统一数据库路径获取
2. 事务支持
3. 错误重试
4. 数据完整性校验
5. 并发安全
"""

import sqlite3
import os
import logging
import time
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class ReliableTodoStorageError(Exception):
    """可靠存储异常"""
    pass


class TodoRecord:
    """TODO记录"""
    
    def __init__(self, data: Dict[str, Any]):
        self.id = data.get("id")
        self.content = data.get("content")
        self.status = data.get("status", "pending")
        self.priority = data.get("priority", "medium")
        self.sender = data.get("sender")
        self.receiver = data.get("receiver")
        self.source = data.get("source")
        self.created_at = data.get("created_at")
        self.updated_at = data.get("updated_at")
        self.completed_at = data.get("completed_at")
        self.is_read = data.get("is_read", 0)
        self.acknowledged = data.get("acknowledged", 0)
        self.metadata = data.get("metadata")
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "content": self.content,
            "status": self.status,
            "priority": self.priority,
            "sender": self.sender,
            "receiver": self.receiver,
            "source": self.source,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "completed_at": self.completed_at,
            "is_read": self.is_read,
            "acknowledged": self.acknowledged,
            "metadata": self.metadata,
        }


class ReliableTodoStorage:
    """可靠的TODO存储层"""
    
    MAX_RETRIES = 3
    RETRY_DELAY = 0.5
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = self._resolve_db_path(db_path)
        self._ensure_db_exists()
        logger.info(f"ReliableTodoStorage initialized: {self.db_path}")
    
    def _resolve_db_path(self, db_path: Optional[str]) -> Path:
        """解析数据库路径，优先级：参数 > 环境变量 > 默认"""
        if db_path:
            return Path(db_path)
        
        env_path = os.environ.get("OC_TODO_DB_PATH")
        if env_path:
            return Path(env_path)
        
        return Path("state/todos.db")
    
    def _ensure_db_exists(self):
        """确保数据库和表存在"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'in_progress', 'completed', 'cancelled', 'deferred')),
                priority TEXT DEFAULT 'medium' CHECK(priority IN ('low', 'medium', 'high')),
                sender TEXT,
                receiver TEXT,
                source TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP,
                completed_at TIMESTAMP,
                deferred_until TIMESTAMP,
                is_read INTEGER DEFAULT 0,
                acknowledged INTEGER DEFAULT 0,
                acknowledged_by TEXT,
                acknowledged_at TIMESTAMP,
                metadata TEXT
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_todos_receiver ON todos(receiver)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_todos_status ON todos(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_todos_created_at ON todos(created_at)")
        
        conn.commit()
        conn.close()
    
    @contextmanager
    def _get_connection(self):
        """获取数据库连接，带重试机制"""
        last_error = None
        conn = None
        for attempt in range(self.MAX_RETRIES):
            try:
                conn = sqlite3.connect(
                    str(self.db_path),
                    timeout=30.0,
                    isolation_level="DEFERRED"
                )
                conn.row_factory = sqlite3.Row
                try:
                    yield conn
                    return
                except Exception as e:
                    last_error = e
                    if attempt < self.MAX_RETRIES - 1:
                        time.sleep(self.RETRY_DELAY * (attempt + 1))
                        continue
                    raise
                finally:
                    if conn:
                        conn.close()
            except sqlite3.OperationalError as e:
                last_error = e
                if conn:
                    conn.close()
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY * (attempt + 1))
                    continue
                raise ReliableTodoStorageError(f"数据库连接失败: {e}") from last_error
        
        if last_error:
            raise ReliableTodoStorageError(f"数据库操作失败: {last_error}") from last_error
    
    def _execute_with_retry(self, query: str, params: Tuple = ()) -> Tuple[List, int]:
        """执行SQL带重试"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
            return cursor.fetchall(), cursor.rowcount
    
    def create(self, todo: Dict[str, Any]) -> bool:
        """创建TODO"""
        try:
            self._execute_with_retry("""
                INSERT INTO todos (id, content, status, priority, sender, receiver, source, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                todo.get("id"),
                todo.get("content"),
                todo.get("status", "pending"),
                todo.get("priority", "medium"),
                todo.get("sender"),
                todo.get("receiver"),
                todo.get("source"),
                todo.get("metadata"),
            ))
            logger.info(f"TODO created: {todo.get('id')}")
            return True
        except sqlite3.IntegrityError:
            logger.warning(f"TODO already exists: {todo.get('id')}")
            return False
        except Exception as e:
            logger.error(f"Failed to create TODO: {e}")
            raise ReliableTodoStorageError(f"创建TODO失败: {e}") from e
    
    def get(self, todo_id: str) -> Optional[TodoRecord]:
        """获取单个TODO"""
        rows, _ = self._execute_with_retry("SELECT * FROM todos WHERE id = ?", (todo_id,))
        if rows:
            return TodoRecord(dict(rows[0]))
        return None
    
    def list(
        self,
        receiver: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100
    ) -> List[TodoRecord]:
        """列出TODO"""
        query = "SELECT * FROM todos WHERE 1=1"
        params = []
        
        if receiver:
            query += " AND receiver = ?"
            params.append(receiver)
        
        if status:
            query += " AND status = ?"
            params.append(status)
        
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        
        rows, _ = self._execute_with_retry(query, tuple(params))
        return [TodoRecord(dict(row)) for row in rows]
    
    def update_status(self, todo_id: str, status: str) -> bool:
        """更新TODO状态"""
        now = datetime.now().isoformat()
        
        if status == "completed":
            _, rowcount = self._execute_with_retry("""
                UPDATE todos 
                SET status = ?, updated_at = ?, completed_at = ?
                WHERE id = ?
            """, (status, now, now, todo_id))
        else:
            _, rowcount = self._execute_with_retry("""
                UPDATE todos 
                SET status = ?, updated_at = ?
                WHERE id = ?
            """, (status, now, todo_id))
        
        if rowcount > 0:
            logger.info(f"TODO status updated: {todo_id} -> {status}")
            return True
        return False
    
    def mark_read(self, todo_id: str, receiver: str) -> bool:
        """标记TODO为已读"""
        now = datetime.now().isoformat()
        _, rowcount = self._execute_with_retry("""
            UPDATE todos 
            SET is_read = 1, acknowledged = 1, acknowledged_by = ?, acknowledged_at = ?
            WHERE id = ? AND receiver = ?
        """, (receiver, now, todo_id, receiver))
        
        return rowcount > 0
    
    def delete(self, todo_id: str) -> bool:
        """删除TODO"""
        _, rowcount = self._execute_with_retry("DELETE FROM todos WHERE id = ?", (todo_id,))
        
        if rowcount > 0:
            logger.info(f"TODO deleted: {todo_id}")
            return True
        return False
    
    def count(self, receiver: Optional[str] = None, status: Optional[str] = None) -> int:
        """统计TODO数量"""
        query = "SELECT COUNT(*) FROM todos WHERE 1=1"
        params = []
        
        if receiver:
            query += " AND receiver = ?"
            params.append(receiver)
        
        if status:
            query += " AND status = ?"
            params.append(status)
        
        rows, _ = self._execute_with_retry(query, tuple(params))
        return rows[0][0] if rows else 0
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT status, COUNT(*) as count FROM todos GROUP BY status
            """)
            status_counts = {row[0]: row[1] for row in cursor.fetchall()}
            
            cursor.execute("SELECT COUNT(*) FROM todos WHERE is_read = 0")
            unread_count = cursor.fetchone()[0]
        
        return {
            "total": sum(status_counts.values()),
            "by_status": status_counts,
            "unread": unread_count,
        }
    
    def verify_integrity(self) -> Dict[str, Any]:
        """验证数据完整性"""
        issues = []
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, content FROM todos WHERE content IS NULL OR content = ''")
            empty_contents = cursor.fetchall()
            if empty_contents:
                issues.append(f"Found {len(empty_contents)} todos with empty content")
            
            cursor.execute("""
                SELECT id, receiver FROM todos 
                WHERE receiver IS NOT NULL AND receiver != '' 
                AND receiver NOT LIKE 'agent%'
            """)
            invalid_receivers = cursor.fetchall()
            if invalid_receivers:
                issues.append(f"Found {len(invalid_receivers)} todos with invalid receiver")
        
        return {
            "healthy": len(issues) == 0,
            "issues": issues,
        }


_storage_instance: Optional[ReliableTodoStorage] = None


def get_reliable_storage(db_path: Optional[str] = None) -> ReliableTodoStorage:
    """获取可靠存储单例"""
    global _storage_instance
    
    if _storage_instance is None:
        _storage_instance = ReliableTodoStorage(db_path)
    
    return _storage_instance


def reset_storage():
    """重置存储单例"""
    global _storage_instance
    _storage_instance = None
