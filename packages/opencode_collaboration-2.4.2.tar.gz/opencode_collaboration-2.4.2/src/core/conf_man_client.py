"""ConfMan HTTP API客户端 - 与conf-man配置服务HTTP API交互"""

import os
import requests
from pathlib import Path
from typing import Optional, Dict, Any, List
import logging

logger = logging.getLogger(__name__)

CONF_MAN_API_URL = os.getenv("CONF_MAN_API_URL", "http://localhost:8000")
CONF_MAN_API_KEY = os.getenv("CONF_MAN_API_KEY", "")


class VersionInfo:
    """版本信息"""
    
    def __init__(self, version: str, commit_hash: str, registered_at: str, 
                 manifest: Dict[str, Any], test_report: str):
        self.version = version
        self.commit_hash = commit_hash
        self.registered_at = registered_at
        self.manifest = manifest
        self.test_report = test_report
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "commit_hash": self.commit_hash,
            "registered_at": self.registered_at,
            "manifest": self.manifest,
            "test_report": self.test_report
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VersionInfo":
        return cls(
            version=data.get("version", ""),
            commit_hash=data.get("git_commit_hash", ""),
            registered_at=data.get("registered_at", ""),
            manifest=data.get("manifest", {}),
            test_report=data.get("test_report", "")
        )


class ConfManClientError(Exception):
    """ConfMan客户端错误"""
    pass


class ConfManClient:
    """ConfMan配置服务HTTP API客户端"""
    
    def __init__(self, api_url: Optional[str] = None, api_key: Optional[str] = None):
        self.api_url = api_url or CONF_MAN_API_URL
        self.api_key = api_key or CONF_MAN_API_KEY
        self._session = requests.Session()
        if self.api_key:
            self._session.headers.update({"X-API-Key": self.api_key})
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """发送HTTP请求"""
        url = f"{self.api_url}{endpoint}"
        
        try:
            response = self._session.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            raise ConfManClientError(f"API request failed: {e}")
    
    def _get(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self._request("GET", endpoint, **kwargs)
    
    def _post(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self._request("POST", endpoint, **kwargs)
    
    def _put(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self._request("PUT", endpoint, **kwargs)
    
    def _delete(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self._request("DELETE", endpoint, **kwargs)
    
    def health_check(self) -> bool:
        """检查服务健康状态"""
        try:
            result = self._get("/health")
            return result.get("status") == "ok"
        except ConfManClientError:
            return False
    
    def register_version(
        self, 
        version: str, 
        project_id: str = "default",
        manifest: str = "",
        git_commit_hash: str = ""
    ) -> VersionInfo:
        """登记新版本"""
        data = {
            "version": version,
            "project_id": project_id,
            "manifest": manifest,
            "git_commit_hash": git_commit_hash
        }
        
        result = self._post("/api/v1/versions", json=data)
        return VersionInfo.from_dict(result)
    
    def list_versions(self, project_id: Optional[str] = None) -> List[VersionInfo]:
        """列出所有已登记的版本"""
        params = {"project_id": project_id} if project_id else {}
        result = self._get("/api/v1/versions", params=params)
        
        versions = []
        for item in result.get("versions", []):
            versions.append(VersionInfo.from_dict(item))
        
        return versions
    
    def show_version(self, version_id: str) -> VersionInfo:
        """显示指定版本的详细信息"""
        result = self._get(f"/api/v1/versions/{version_id}")
        return VersionInfo.from_dict(result)
    
    def get_version_by_version_string(self, version: str) -> Optional[VersionInfo]:
        """通过版本号获取版本信息"""
        versions = self.list_versions()
        for v in versions:
            if v.version == version:
                return v
        return None
    
    def get_latest_version(self) -> Optional[VersionInfo]:
        """获取最新登记的版本"""
        versions = self.list_versions()
        if not versions:
            return None
        return versions[-1]
    
    def trigger_release(self, version_id: str) -> Dict[str, Any]:
        """触发版本发布"""
        return self._post(f"/api/v1/versions/{version_id}/release")
    
    def update_version(
        self, 
        version_id: str, 
        version: Optional[str] = None,
        manifest: Optional[str] = None,
        git_commit_hash: Optional[str] = None
    ) -> VersionInfo:
        """更新版本信息"""
        data = {}
        if version:
            data["version"] = version
        if manifest is not None:
            data["manifest"] = manifest
        if git_commit_hash is not None:
            data["git_commit_hash"] = git_commit_hash
        
        result = self._put(f"/api/v1/versions/{version_id}", json=data)
        return VersionInfo.from_dict(result)


_client_instance: Optional[ConfManClient] = None


def get_conf_man_client(
    api_url: Optional[str] = None, 
    api_key: Optional[str] = None
) -> ConfManClient:
    """获取ConfManClient单例"""
    global _client_instance
    
    if _client_instance is None:
        _client_instance = ConfManClient(api_url, api_key)
    
    return _client_instance


def reset_client():
    """重置客户端实例（用于测试）"""
    global _client_instance
    _client_instance = None
