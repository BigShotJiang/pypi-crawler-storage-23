"""Version客户端 - 版本查询和管理"""

import os
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any, List
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class VersionClientError(Exception):
    """Version客户端错误"""
    pass


class VersionClient:
    """版本管理客户端"""
    
    def __init__(self, project_path: Optional[str] = None):
        self.project_path = Path(project_path) if project_path else Path.cwd()
    
    def get_current_version(self) -> str:
        """获取当前项目版本"""
        version_file = self.project_path / "VERSION"
        if version_file.exists():
            return version_file.read_text().strip()
        
        pyproject = self.project_path / "pyproject.toml"
        if pyproject.exists():
            content = pyproject.read_text()
            for line in content.split("\n"):
                if line.startswith("version"):
                    parts = line.split("=")
                    if len(parts) == 2:
                        return parts[1].strip().strip('"').strip("'")
        
        return "unknown"
    
    def get_git_commit(self) -> str:
        """获取当前Git commit hash"""
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self.project_path,
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return "unknown"
    
    def get_version_info(self) -> Dict[str, Any]:
        """获取完整的版本信息"""
        return {
            "version": self.get_current_version(),
            "commit_hash": self.get_git_commit(),
            "timestamp": datetime.now().isoformat(),
            "project_path": str(self.project_path)
        }
    
    def compare_versions(self, version1: str, version2: str) -> int:
        """比较两个版本
        
        Returns:
            -1: version1 < version2
             0: version1 == version2
             1: version1 > version2
        """
        from packaging import version
        
        try:
            v1 = version.parse(version1)
            v2 = version.parse(version2)
            
            if v1 < v2:
                return -1
            elif v1 > v2:
                return 1
            else:
                return 0
        except Exception:
            return 0
    
    def is_version_released(self, version: str) -> bool:
        """检查版本是否已发布"""
        import os
        conf_man_api_url = os.getenv("CONF_MAN_API_URL")
        
        if conf_man_api_url:
            try:
                from .conf_man_client import get_conf_man_client
                client = get_conf_man_client(api_url=conf_man_api_url)
                v = client.get_version_by_version_string(version)
                return v is not None and getattr(v, 'status', '') == 'released'
            except Exception:
                pass
        
        conf_man_versions = self.project_path / "conf-man" / "versions"
        if not conf_man_versions.exists():
            return False
        
        version_file = conf_man_versions / f"v{version}.yaml"
        return version_file.exists()
    
    def list_releases(self) -> List[Dict[str, Any]]:
        """列出所有已发布的版本"""
        import os
        conf_man_api_url = os.getenv("CONF_MAN_API_URL")
        
        if conf_man_api_url:
            try:
                from .conf_man_client import get_conf_man_client
                client = get_conf_man_client(api_url=conf_man_api_url)
                versions = client.list_versions()
                return [{"version": v.version, "data": v.to_dict()} for v in versions]
            except Exception:
                pass
        
        conf_man_versions = self.project_path / "conf-man" / "versions"
        releases = []
        
        if not conf_man_versions.exists():
            return releases
        
        for version_file in conf_man_versions.glob("v*.yaml"):
            import yaml
            try:
                with open(version_file, 'r') as f:
                    data = yaml.safe_load(f)
                    releases.append({
                        "version": version_file.stem[1:],
                        "data": data
                    })
            except Exception:
                continue
        
        return sorted(releases, key=lambda x: x["version"])


_client_instance: Optional[VersionClient] = None


def get_version_client(project_path: Optional[str] = None) -> VersionClient:
    """获取VersionClient单例"""
    global _client_instance
    
    if _client_instance is None:
        _client_instance = VersionClient(project_path)
    
    return _client_instance


def reset_version_client():
    """重置客户端实例（用于测试）"""
    global _client_instance
    _client_instance = None
