from pathlib import Path
from typing import Optional, List
import re
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .state_manager import StateManager
from .agent_registry import get_default_agents

console = Console()


def _get_agent_roles() -> dict:
    """动态获取Agent角色配置"""
    agents = get_default_agents()
    pm_agent = agents[0] if agents else "agent1"
    dev_agent = agents[1] if len(agents) > 1 else "agent2"
    
    return {
        pm_agent: {
            "role": "产品经理",
            "responsibilities": [
                "编写和评审需求文档",
                "定义验收标准",
                "签署需求确认",
                "评审设计文档",
                "评审测试报告"
            ]
        },
        dev_agent: {
            "role": "开发负责人",
            "responsibilities": [
                "评审需求文档",
                "编写详细设计",
                "代码实现",
                "编写单元测试",
                "签署技术确认"
            ]
        }
    }


AGENT_ROLES = _get_agent_roles()

COMMON_COMMANDS = [
    ("oc-collab status", "查看项目状态"),
    ("oc-collab todo", "查看待办事项"),
    ("oc-collab review", "评审文档"),
    ("oc-collab signoff", "签署确认"),
    ("oc-collab history", "查看协作历史"),
    ("oc-collab switch <1|2>", "切换Agent角色")
]


class SessionConfig:
    def __init__(self, project_path: str):
        self.project_path = project_path
        self.enabled = True
        self.show_responsibilities = True
        self.show_todo = True
        self.show_pending = True
        self.load_config()

    def load_config(self):
        state_file = Path(self.project_path) / "state" / "project_state.yaml"
        if state_file.exists():
            try:
                import yaml
                with open(state_file) as f:
                    state = yaml.safe_load(f) or {}
                session_config = state.get("session_start", {})
                self.enabled = session_config.get("enabled", True)
                self.show_responsibilities = session_config.get("show_responsibilities", True)
                self.show_todo = session_config.get("show_todo", True)
                self.show_pending = session_config.get("show_pending", True)
            except Exception:
                pass


class SessionManager:
    def __init__(self, project_path: str):
        self.project_path = project_path
        self.state_manager = StateManager(project_path)
        self.config = SessionConfig(project_path)

    def get_project_info(self) -> dict:
        try:
            state = self.state_manager.load_state()

            metadata = state.get("metadata", {})
            project_info = state.get("project", {})

            project_name = metadata.get("project_name") or project_info.get("name")

            if not project_name:
                version_keys = [k for k in state.keys() if re.match(r'^v2\.\d+', k)]
                if version_keys:
                    latest_version = sorted(version_keys, key=lambda x: [int(n) for n in re.findall(r'\d+', x)])[-1]
                    project_name = f"oc-collab {latest_version}"

            if not project_name:
                project_name = "oc-collab"

            phase = project_info.get("phase") or state.get("phase", "未知")

            if phase == "未知":
                version_keys = [k for k in state.keys() if re.match(r'^v2\.\d+', k)]
                if version_keys:
                    latest_version = sorted(version_keys, key=lambda x: [int(n) for n in re.findall(r'\d+', x)])[-1]
                    version_data = state.get(latest_version, {})
                    dev_status = version_data.get("development", {}).get("status", "")
                    if dev_status == "completed":
                        phase = "testing"
                    elif dev_status == "in_progress":
                        phase = "development"

            return {
                "name": project_name,
                "phase": phase,
                "milestone": state.get("current_milestone", "待定义")
            }
        except Exception as e:
            return {"name": "oc-collab", "phase": "未知", "milestone": "待定义"}

    def get_agent_info(self, agent_id: str) -> dict:
        agent_config = AGENT_ROLES.get(agent_id, {
            "role": "未知",
            "responsibilities": []
        })

        try:
            state = self.state_manager.load_state()
            agents = state.get("agents", {})
            agent_state = agents.get(agent_id, {})
        except KeyError:
            agent_state = {}
        except Exception:
            agent_state = {}

        return {
            "id": agent_id,
            "role": agent_config["role"],
            "current_task": agent_state.get("current_task", ""),
            "responsibilities": agent_config["responsibilities"]
        }

    def get_responsibilities_text(self, agent_id: str) -> str:
        agent = self.get_agent_info(agent_id)
        if not self.config.show_responsibilities:
            return ""

        lines = ["你的职责:"]
        for resp in agent["responsibilities"]:
            lines.append(f"  - {resp}")
        return "\n".join(lines)

    def get_todo_items(self) -> str:
        if not self.config.show_todo:
            return ""

        todo_lines = []

        try:
            from .todo_storage import TodoStorage
            storage = TodoStorage(str(Path(self.project_path) / "state" / "todos.db"))
            todos = storage.list(status="pending")
            if todos:
                todo_lines.append("待办事项:")
                for item in todos[:5]:
                    todo_id = item.get("id", "")
                    content = item.get("content", "")
                    todo_lines.append(f"  [{todo_id}] {content}")
        except Exception:
            pass

        if not todo_lines:
            return "待办事项:\n  暂无待办事项"

        return "\n".join(todo_lines)

    def get_pending_issues(self) -> str:
        if not self.config.show_pending:
            return ""

        pending_file = Path(self.project_path) / "state" / "memory" / "pending.yaml"
        if not pending_file.exists():
            return "上次会话遗留:\n  无遗留问题"

        try:
            import yaml
            with open(pending_file) as f:
                pending = yaml.safe_load(f) or []

            if not pending:
                return "上次会话遗留:\n  无遗留问题"

            lines = ["上次会话遗留:"]
            for item in pending[:5]:
                desc = item.get("description", item)
                lines.append(f"  - {desc}")
            return "\n".join(lines)
        except Exception:
            return "上次会话遗留:\n  无遗留问题"

    def auto_discover_tasks(self) -> List[str]:
        """自动发现需要Agent2处理的任务并创建TODO。"""
        discovered = []
        state = self.state_manager.load_state()

        try:
            from .todo_sync_manager import TodoSyncManager
            todo_manager = TodoSyncManager(self.project_path)

            todos = todo_manager.list_todos(status="pending")
            pending_ids = [t.id for t in todos]

            phase = state.get("phase", "")
            if phase in ["requirements_review", "requirements_approved"]:
                if "requirements" in pending_ids:
                    pass
                else:
                    todo_manager.add_todo(
                        content="评审需求文档",
                        agent_id=2,
                        priority="P0"
                    )
                    discovered.append("评审需求文档")

            if phase in ["design_review", "design_approved"]:
                if "design_review" in str(pending_ids):
                    pass
                else:
                    todo_manager.add_todo(
                        content="评审设计文档",
                        agent_id=2,
                        priority="P0"
                    )
                    discovered.append("评审设计文档")

            if phase == "development":
                if "development" not in str(pending_ids):
                    todo_manager.add_todo(
                        content="开发实现功能模块",
                        agent_id=2,
                        priority="P0"
                    )
                    discovered.append("开发实现功能模块")

        except Exception as e:
            pass

        return discovered

    def get_common_commands(self) -> str:
        lines = ["常用命令:"]
        for cmd, desc in COMMON_COMMANDS:
            lines.append(f"  - {cmd}: {desc}")
        return "\n".join(lines)

    def get_welcome_message(self, agent_id: str) -> str:
        if not self.config.enabled:
            return ""

        project = self.get_project_info()
        agent = self.get_agent_info(agent_id)

        parts = [
            f"=== Agent {agent_id.replace('agent', '')} ({agent['role']}) ===",
            "",
            f"当前项目: {project['name']}",
            f"当前阶段: {project['phase']}",
            f"当前里程碑: {project['milestone']}",
            ""
        ]

        resp_text = self.get_responsibilities_text(agent_id)
        if resp_text:
            parts.append(resp_text)
            parts.append("")

        todo_text = self.get_todo_items()
        if todo_text:
            parts.append(todo_text)
            parts.append("")

        pending_text = self.get_pending_issues()
        if pending_text:
            parts.append(pending_text)
            parts.append("")

        parts.append(self.get_common_commands())

        return "\n".join(parts)

    def show_welcome(self, agent_id: str):
        message = self.get_welcome_message(agent_id)
        if message:
            console.print(Panel(
                Text(message, justify="left"),
                title="会话引导",
                style="blue"
            ))
