"""跨子系统TODO数据库客户端

所有子系统共享同一个SQLite数据库。
通过conf-man获取数据库路径，实现TODO数据统一管理。
"""

import sqlite3
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
import os


class SharedTodoDB:
    """跨子系统共享的TODO数据库客户端"""
    
    def __init__(self, db_path: Optional[str] = None):
        """
        初始化共享数据库客户端
        
        Args:
            db_path: 数据库路径，默认从oc-collab获取
        """
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = self._find_shared_db()
        
        self._ensure_db_exists()
    
    def _find_shared_db(self) -> Path:
        """查找共享数据库路径"""
        # 方案1: 从环境变量获取
        env_path = os.environ.get("OC_TODO_DB_PATH")
        if env_path:
            return Path(env_path)
        
        # 方案2: 查找oc-collab数据库
        candidates = [
            Path("../dual-agent-collaboration-system/state/todos.db"),
            Path("../../dual-agent-collaboration-system/state/todos.db"),
            Path("state/todos.db"),
            Path("../state/todos.db"),
        ]
        
        for candidate in candidates:
            if candidate.exists():
                return candidate
        
        # 方案3: 使用当前目录的默认路径
        return Path("state/todos.db")
    
    def _ensure_db_exists(self):
        """确保数据库存在"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        if not self.db_path.exists():
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS todos (
                    id TEXT PRIMARY KEY,
                    content TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',
                    priority TEXT DEFAULT 'medium',
                    sender TEXT,
                    receiver TEXT,
                    source TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP,
                    completed_at TIMESTAMP,
                    deferred_until TIMESTAMP,
                    is_read INTEGER DEFAULT 0,
                    acknowledged INTEGER DEFAULT 0,
                    acknowledged_by TEXT,
                    acknowledged_at TIMESTAMP,
                    metadata TEXT
                )
            """)
            conn.commit()
            conn.close()
    
    def _get_connection(self) -> sqlite3.Connection:
        """获取数据库连接"""
        return sqlite3.connect(str(self.db_path))
    
    def create_todo(self, todo: Dict[str, Any]) -> bool:
        """创建TODO"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO todos (id, content, status, priority, sender, receiver, source, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                todo.get("id"),
                todo.get("content"),
                todo.get("status", "pending"),
                todo.get("priority", "medium"),
                todo.get("sender"),
                todo.get("receiver"),
                todo.get("source"),
                todo.get("metadata"),
            ))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()
    
    def get_todos(self, receiver: Optional[str] = None, status: Optional[str] = None) -> List[Dict]:
        """获取TODO列表"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        query = "SELECT * FROM todos WHERE 1=1"
        params = []
        
        if receiver:
            query += " AND receiver = ?"
            params.append(receiver)
        
        if status:
            query += " AND status = ?"
            params.append(status)
        
        query += " ORDER BY created_at DESC"
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()
        
        columns = [desc[0] for desc in cursor.description]
        return [dict(zip(columns, row)) for row in rows]
    
    def update_status(self, todo_id: str, status: str) -> bool:
        """更新TODO状态"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE todos 
            SET status = ?, updated_at = ?
            WHERE id = ?
        """, (status, datetime.now().isoformat(), todo_id))
        
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        
        return success
    
    def delete_todo(self, todo_id: str) -> bool:
        """删除TODO"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM todos WHERE id = ?", (todo_id,))
        
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        
        return success
    
    def get_stats(self) -> Dict[str, int]:
        """获取统计信息"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT status, COUNT(*) FROM todos GROUP BY status")
        stats = {row[0]: row[1] for row in cursor.fetchall()}
        
        conn.close()
        
        return stats


# 全局单例
_shared_db: Optional[SharedTodoDB] = None


def get_shared_db(db_path: Optional[str] = None) -> SharedTodoDB:
    """获取共享数据库单例"""
    global _shared_db
    
    if _shared_db is None:
        _shared_db = SharedTodoDB(db_path)
    
    return _shared_db


def reset_shared_db():
    """重置共享数据库（用于测试）"""
    global _shared_db
    _shared_db = None
