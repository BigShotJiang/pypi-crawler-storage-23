"""
F-NF-001: ConfManClient 测试

测试ConfManClient与conf-man子系统的集成
实际API: register_version(), list_versions(), show_version(), get_latest_version()
"""

import pytest
import os
from unittest.mock import Mock, patch, MagicMock

os.environ["OC_SKIP_SKILL_CHECK"] = "1"


class TestConfManClient:
    """ConfManClient测试"""

    def test_import_confman_client(self):
        """TC-F-NF-001-01: 导入ConfManClient类"""
        try:
            from src.core.conf_man_client import ConfManClient
            assert ConfManClient is not None
        except ImportError:
            pytest.skip("ConfManClient not implemented yet")

    def test_register_version(self):
        """TC-F-NF-001-02: 测试register_version功能"""
        try:
            from src.core.conf_man_client import ConfManClient, VersionInfo
            with patch('pathlib.Path.exists', return_value=True):
                with patch('subprocess.run') as mock_run:
                    mock_run.return_value = Mock(
                        returncode=0,
                        stdout='{"version": "1.0.0", "commit_hash": "abc123", "registered_at": "2026-02-22", "manifest": {}, "test_report": ""}'
                    )
                    client = ConfManClient()
                    result = client.register_version("v1.0.0", "manifest.yaml", "report.md")
                    assert result.version == "1.0.0"
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")

    def test_list_versions(self):
        """TC-F-NF-001-03: 测试list_versions功能"""
        try:
            from src.core.conf_man_client import ConfManClient
            with patch('pathlib.Path.exists', return_value=True):
                with patch('subprocess.run') as mock_run:
                    mock_run.return_value = Mock(
                        returncode=0,
                        stdout='{"versions": []}'
                    )
                    client = ConfManClient()
                    versions = client.list_versions()
                    assert isinstance(versions, list)
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")

    def test_get_latest_version(self):
        """TC-F-NF-001-04: 测试get_latest_version功能"""
        try:
            from src.core.conf_man_client import ConfManClient
            with patch('pathlib.Path.exists', return_value=True):
                with patch('subprocess.run') as mock_run:
                    mock_run.return_value = Mock(
                        returncode=0,
                        stdout='{"version": "1.0.0", "commit_hash": "abc123", "registered_at": "2026-02-22", "manifest": {}, "test_report": ""}'
                    )
                    client = ConfManClient()
                    version = client.get_latest_version()
                    assert version is None or version.version == "1.0.0"
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")

    def test_show_version(self):
        """TC-F-NF-001-05: 测试show_version功能"""
        try:
            from src.core.conf_man_client import ConfManClient
            with patch('pathlib.Path.exists', return_value=True):
                with patch('subprocess.run') as mock_run:
                    mock_run.return_value = Mock(
                        returncode=0,
                        stdout='{"version": "1.0.0", "commit_hash": "abc123", "registered_at": "2026-02-22", "manifest": {}, "test_report": ""}'
                    )
                    client = ConfManClient()
                    version = client.show_version("v1.0.0")
                    assert version.version == "1.0.0"
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")


class TestConfManClientErrors:
    """ConfManClient异常处理测试"""

    def test_confman_not_found(self):
        """TC-F-NF-001-06: conf-man不可用时的错误处理"""
        try:
            from src.core.conf_man_client import ConfManClient, ConfManClientError
            with patch('pathlib.Path.exists', return_value=False):
                with pytest.raises(ConfManClientError):
                    client = ConfManClient()
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")
