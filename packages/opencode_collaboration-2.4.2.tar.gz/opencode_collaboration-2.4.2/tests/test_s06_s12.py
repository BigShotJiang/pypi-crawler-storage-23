"""
S06-S12测试代码
覆盖文档: test-agent/docs/03-test/oc-collab/S06-S12
"""

import pytest
import subprocess
import os


# S06-配置状态 (20用例)
class TestConfigSystem:
    def test_config_show(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "config", "list"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0

    def test_config_set(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "config", "set", "test_key", "test_value"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


# S07-Git同步 (22用例)
class TestGitSync:
    def test_git_sync_basic(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "git", "sync"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


# S08-工作流 (7用例)
class TestWorkflow:
    def test_workflow_show(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "workflow"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


# S09-通知部署 (23用例)
class TestNotify:
    def test_notify_send(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "notify", "test"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


# S10-合规检查 (12用例)
class TestCompliance:
    def test_compliance_check(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "compliance", "check"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


# S11-数据迁移 (5用例)
class TestMigrate:
    def test_migrate_export(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "migrate", "status"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0
