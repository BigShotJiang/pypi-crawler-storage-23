"""
F-NF-004: ReliableTodoStorage 可靠存储测试

测试可靠存储层的事务，重试、完整性校验、并发安全
实际API: create(), get(), list(), update_status(), delete(), verify_integrity()
"""

import pytest
import os
import sqlite3
import threading
from pathlib import Path

os.environ["OC_SKIP_SKILL_CHECK"] = "1"


@pytest.fixture
def temp_db(tmp_path):
    """创建临时数据库"""
    db_path = tmp_path / "test.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS todos (
            id TEXT PRIMARY KEY,
            content TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            priority TEXT DEFAULT 'medium',
            sender TEXT,
            receiver TEXT,
            source TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP,
            completed_at TIMESTAMP,
            deferred_until TIMESTAMP,
            is_read INTEGER DEFAULT 0,
            acknowledged INTEGER DEFAULT 0,
            acknowledged_by TEXT,
            acknowledged_at TIMESTAMP,
            metadata TEXT
        )
    """)
    conn.commit()
    conn.close()
    yield str(db_path)


class TestReliableTodoStorage:
    """可靠存储测试"""

    def test_import_reliable_storage(self):
        """TC-F-NF-004-00: 导入ReliableTodoStorage"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            assert ReliableTodoStorage is not None
        except ImportError:
            pytest.skip("ReliableTodoStorage not implemented yet")

    def test_create_and_get(self, temp_db):
        """TC-F-NF-004-01: 创建和获取TODO"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            todo = {"id": "test-1", "content": "test content", "status": "pending"}
            result = storage.create(todo)
            assert result is True
            
            retrieved = storage.get("test-1")
            assert retrieved is not None
            assert retrieved.id == "test-1"
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")

    def test_list_todos(self, temp_db):
        """TC-F-NF-004-02: 列出TODO"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            storage.create({"id": "test-1", "content": "test1", "status": "pending"})
            storage.create({"id": "test-2", "content": "test2", "status": "completed"})
            
            todos = storage.list(receiver=None, status=None, limit=10)
            assert len(todos) >= 2
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")

    def test_update_status(self, temp_db):
        """TC-F-NF-004-03: 更新状态"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            storage.create({"id": "test-1", "content": "test", "status": "pending"})
            result = storage.update_status("test-1", "completed")
            assert result is True
            
            todo = storage.get("test-1")
            assert todo.status == "completed"
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")

    def test_delete_todo(self, temp_db):
        """TC-F-NF-004-04: 删除TODO"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            storage.create({"id": "test-1", "content": "test", "status": "pending"})
            result = storage.delete("test-1")
            assert result is True
            
            todo = storage.get("test-1")
            assert todo is None
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")

    def test_verify_integrity(self, temp_db):
        """TC-F-NF-004-05: 验证完整性"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            storage.create({"id": "test-1", "content": "test", "status": "pending"})
            
            result = storage.verify_integrity()
            assert isinstance(result, dict)
            assert "healthy" in result
            assert result.get("healthy") is True
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")


class TestReliableTodoStorageConcurrent:
    """并发安全测试"""

    def test_concurrent_create(self, temp_db):
        """TC-F-NF-004-06: 并发创建"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            errors = []
            
            def create_todo(i):
                try:
                    storage.create({
                        "id": f"concurrent-{i}",
                        "content": f"test-{i}",
                        "status": "pending"
                    })
                except Exception as e:
                    errors.append(e)
            
            threads = []
            for i in range(10):
                t = threading.Thread(target=create_todo, args=(i,))
                threads.append(t)
                t.start()
            
            for t in threads:
                t.join()
            
            assert len(errors) == 0
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")
