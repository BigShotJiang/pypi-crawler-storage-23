"""
S05-Skill系统测试代码
用例数: 18
覆盖文档: test-agent/docs/03-test/oc-collab/S05_skill.md
"""

import pytest
import subprocess
import os


class TestSkillList:
    """S05-T001-T006: Skill列表"""
    
    def test_skill_list_basic(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "skill", "list"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


class TestSkillShow:
    """S05-T007-T012: Skill详情"""
    
    def test_skill_show_basic(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "skill", "show", "test-skill"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


class TestSkillValidate:
    """S05-T013-T018: Skill验证"""
    
    def test_skill_validate_basic(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "skill", "validate"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0
