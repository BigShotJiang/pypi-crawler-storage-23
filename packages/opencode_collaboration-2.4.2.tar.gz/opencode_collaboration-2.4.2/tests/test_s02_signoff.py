"""
S02-签署工作流子系统测试代码
用例数: 20
覆盖文档: test-agent/docs/03-test/oc-collab/S02_signoff.md
"""

import pytest
import subprocess
import sqlite3
import os
import tempfile
from pathlib import Path
import yaml


class TestSignoffBasic:
    """S02-T001-T005: 签署基本功能"""
    
    def test_signoff_approve(self, tmp_path, monkeypatch):
        """测试批准签署"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        os.makedirs("config", exist_ok=True)
        
        # 创建项目配置
        with open("config/project.yaml", "w") as f:
            yaml.dump({"project": "test-project", "version": "v1.0"}, f)
        
        # 创建签署记录表
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--project", "test-project", "--role", "pm"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_reject(self, tmp_path, monkeypatch):
        """测试拒绝签署"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--project", "test-project", "--role", "pm", "--reject"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_list(self, tmp_path, monkeypatch):
        """测试列出签署记录"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO signoffs (id, project, version, role, status, signed_at)
            VALUES ('S001', 'test', 'v1.0', 'pm', 'approved', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--list"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_history(self, tmp_path, monkeypatch):
        """测试查看签署历史"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--history"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_status(self, tmp_path, monkeypatch):
        """测试查看签署状态"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--status"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestSignoffRoles:
    """S02-T006-T010: 不同角色签署"""
    
    @pytest.mark.parametrize("role", ["pm", "dev", "qa", "architect"])
    def test_signoff_different_roles(self, tmp_path, monkeypatch, role):
        """测试不同角色签署"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--project", "test", "--role", role],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestSignoffWorkflow:
    """S02-T011-T015: 签署工作流"""
    
    def test_signoff_sequential(self, tmp_path, monkeypatch):
        """测试顺序签署"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        for role in ["pm", "dev", "qa"]:
            result = subprocess.run(
                ["python3", "-m", "src.cli.main", "signoff", "--project", "test", "--role", role],
                capture_output=True,
                text=True,
                cwd=tmp_path
            )
            assert result.returncode == 0

    def test_signoff_parallel(self, tmp_path, monkeypatch):
        """测试并行签署"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--project", "test", "--all"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_rollback(self, tmp_path, monkeypatch):
        """测试签署回滚"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        conn = sqlite3.connect("state/signoffs.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signoffs (
                id TEXT PRIMARY KEY,
                project TEXT,
                version TEXT,
                role TEXT,
                status TEXT,
                signed_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO signoffs (id, project, version, role, status, signed_at)
            VALUES ('S001', 'test', 'v1.0', 'pm', 'approved', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--rollback", "--project", "test", "--role", "pm"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestSignoffIntegration:
    """S02-T016-T020: 签署集成"""
    
    def test_signoff_with_milestone(self, tmp_path, monkeypatch):
        """测试里程碑签署"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--milestone", "M1"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_notification(self, tmp_path, monkeypatch):
        """测试签署通知"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--notify"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_compliance(self, tmp_path, monkeypatch):
        """测试签署合规检查"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--compliance-check"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_audit(self, tmp_path, monkeypatch):
        """测试签署审计"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--audit"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_signoff_export(self, tmp_path, monkeypatch):
        """测试签署记录导出"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "signoff", "--export", "signoffs.json"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        if result.returncode == 0:
            assert "export" in result.stdout.lower() or "signoff" in result.stdout.lower(), "成功时应显示export信息"
        else:
            assert result.stderr, "失败时应输出错误信息"
