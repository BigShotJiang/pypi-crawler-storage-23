"""Version of libmelee """
__version__ = '0.45.0'
