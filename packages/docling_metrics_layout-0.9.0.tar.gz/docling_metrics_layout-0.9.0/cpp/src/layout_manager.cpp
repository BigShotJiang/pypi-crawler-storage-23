#include "layout_manager.h"

namespace docling {
LayoutManager::LayoutManager() {}
} // namespace docling
