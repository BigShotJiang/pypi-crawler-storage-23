#include <iostream>
#include <string>
#include <vector>

int main(int argc, char *argv[]) { return 0; }
