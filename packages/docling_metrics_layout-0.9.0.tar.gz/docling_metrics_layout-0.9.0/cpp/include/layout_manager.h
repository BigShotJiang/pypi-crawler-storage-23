#pragma once
#include <string>
#include <vector>

namespace docling {

class LayoutManager {
public:
  LayoutManager();
};

} // namespace docling
