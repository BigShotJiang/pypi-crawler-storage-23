#!/bin/bash

readonly BUILD_DIR="build"

ctest --test-dir "${BUILD_DIR}"

