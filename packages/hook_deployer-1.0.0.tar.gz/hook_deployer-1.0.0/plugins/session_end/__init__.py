"""SessionEnd 插件 - 对话结束时自动保存历史"""

from .plugin import SessionEndPlugin

__all__ = ['SessionEndPlugin']
