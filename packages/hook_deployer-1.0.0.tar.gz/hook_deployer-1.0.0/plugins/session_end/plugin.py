"""SessionEnd 插件实现"""

import os
from pathlib import Path
from typing import List, Dict
from core.plugin_base import HookPlugin


class SessionEndPlugin(HookPlugin):
    """SessionEnd 事件插件

    在 AI 对话结束时自动保存对话历史
    """

    @property
    def event_name(self) -> str:
        """事件名称"""
        return "SessionEnd"

    @property
    def supported_ides(self) -> List[str]:
        """支持的 IDE"""
        return ["claude", "cursor", "codebuddy"]

    def generate_script(self, output_dir: Path) -> Path:
        """生成 Hook 脚本

        Args:
            output_dir: 输出目录

        Returns:
            Path: 生成的脚本文件路径
        """
        # 确保输出目录存在
        output_dir.mkdir(parents=True, exist_ok=True)

        # 脚本路径
        script_path = output_dir / "session-end.sh"

        # 脚本模板
        script_content = """#!/bin/bash
# SessionEnd Hook Script
# 自动保存 AI 对话历史

set -e

# 从 stdin 读取 JSON 输入
input=$(cat)

# 解析关键字段
session_id=$(echo "$input" | jq -r '.session_id // .sessionId // "unknown"')
transcript_path=$(echo "$input" | jq -r '.transcript_path // .transcriptPath // empty')
timestamp=$(date +"%Y%m%d_%H%M%S")
tool=$(echo "$input" | jq -r '.tool // "unknown"')
cwd=$(echo "$input" | jq -r '.cwd // .cwd // "unknown"')

# 输出目录
output_dir="{{output_dir}}"

# 确保输出目录存在
mkdir -p "$output_dir"

# 生成文件名
filename="${timestamp}_${session_id}.md"

# 写入 Markdown 文件
cat > "$output_dir/$filename" <<EOF
# 对话历史

**时间**: $(date -Iseconds)
**工具**: $tool
**工作目录**: $cwd
**会话 ID**: $session_id

---

## 对话内容

EOF

# 如果有 transcript_path，复制文件内容
if [ -n "$transcript_path" ] && [ -f "$transcript_path" ]; then
    cat "$transcript_path" >> "$output_dir/$filename"
else
    # 否则直接保存 JSON 输入
    echo "$input" >> "$output_dir/$filename"
fi

# 设置文件权限（仅所有者可读写）
chmod 600 "$output_dir/$filename"

# 必须返回符合规范的 JSON
echo '{"continue": true}'
exit 0
"""

        # 替换模板变量
        script_content = script_content.replace("{{output_dir}}", str(output_dir.absolute()))

        # 写入脚本文件
        script_path.write_text(script_content, encoding='utf-8')

        # 设置可执行权限
        script_path.chmod(0o755)

        return script_path

    def get_config(self, ide: str, script_path: Path) -> Dict:
        """获取 IDE 配置

        Args:
            ide: IDE 名称
            script_path: 脚本路径

        Returns:
            Dict: IDE 配置字典
        """
        script_path_str = str(script_path.absolute())

        if ide == "claude":
            return {
                "on_stop": script_path_str,
                "enabled": True
            }
        elif ide == "cursor":
            return {
                "sessionEnd": {
                    "script": script_path_str,
                    "enabled": True
                }
            }
        elif ide == "codebuddy":
            return {
                "onSessionEnd": {
                    "script": script_path_str,
                    "enabled": True
                }
            }
        else:
            return {}
