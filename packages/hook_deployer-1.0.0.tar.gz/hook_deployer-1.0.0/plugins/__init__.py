"""插件模块"""

from core.plugin_base import HookPlugin

__all__ = ['HookPlugin']
