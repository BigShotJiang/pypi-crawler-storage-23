"""OpenClaw 插件 - 支持 OpenClaw 对话历史保存"""

from .plugin import OpenClawPlugin

__all__ = ['OpenClawPlugin']
