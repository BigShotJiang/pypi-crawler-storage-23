"""日志系统"""

import logging
import sys
from pathlib import Path
from typing import Optional


class Logger:
    """日志管理器"""

    def __init__(self, name: str = "hook-deployer", level: str = "INFO"):
        """初始化日志器

        Args:
            name: 日志器名称
            level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        """
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, level.upper()))

        # 清除已有的处理器
        self.logger.handlers.clear()

        # 控制台处理器
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console_handler.setFormatter(console_formatter)
        self.logger.addHandler(console_handler)

    def set_level(self, level: str):
        """设置日志级别

        Args:
            level: 日志级别
        """
        self.logger.setLevel(getattr(logging, level.upper()))

    def add_file_handler(self, log_file: Path, level: str = "DEBUG"):
        """添加文件处理器

        Args:
            log_file: 日志文件路径
            level: 日志级别
        """
        log_file.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(getattr(logging, level.upper()))
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        self.logger.addHandler(file_handler)

    def debug(self, message: str):
        """输出 DEBUG 级别日志"""
        self.logger.debug(message)

    def info(self, message: str):
        """输出 INFO 级别日志"""
        self.logger.info(message)

    def warning(self, message: str):
        """输出 WARNING 级别日志"""
        self.logger.warning(message)

    def error(self, message: str, exc_info: bool = False):
        """输出 ERROR 级别日志

        Args:
            message: 日志消息
            exc_info: 是否包含异常信息
        """
        self.logger.error(message, exc_info=exc_info)

    def critical(self, message: str, exc_info: bool = False):
        """输出 CRITICAL 级别日志

        Args:
            message: 日志消息
            exc_info: 是否包含异常信息
        """
        self.logger.critical(message, exc_info=exc_info)


# 全局日志器实例
_logger: Optional[Logger] = None


def get_logger(name: str = "hook-deployer", level: str = "INFO") -> Logger:
    """获取全局日志器实例

    Args:
        name: 日志器名称
        level: 日志级别

    Returns:
        Logger: 日志器实例
    """
    global _logger
    if _logger is None:
        _logger = Logger(name, level)
    return _logger
