"""插件基类定义"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Dict


class HookPlugin(ABC):
    """插件基类

    所有插件必须实现此接口
    """

    @property
    @abstractmethod
    def event_name(self) -> str:
        """事件名称，如 SessionEnd

        Returns:
            str: 事件名称
        """
        pass

    @property
    @abstractmethod
    def supported_ides(self) -> List[str]:
        """支持的 IDE 列表

        Returns:
            List[str]: IDE 名称列表，如 ["claude", "cursor"]
        """
        pass

    @abstractmethod
    def generate_script(self, output_dir: Path) -> Path:
        """生成 Hook 脚本

        Args:
            output_dir: 输出目录

        Returns:
            Path: 生成的脚本文件路径
        """
        pass

    @abstractmethod
    def get_config(self, ide: str, script_path: Path) -> Dict:
        """获取 IDE 配置

        Args:
            ide: IDE 名称
            script_path: 脚本路径

        Returns:
            Dict: IDE 配置字典
        """
        pass
