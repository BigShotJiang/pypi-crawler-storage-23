"""Hook 生命周期管理器"""

from typing import Dict, List
from core.plugin_base import HookPlugin


class HookManager:
    """Hook 插件管理器

    负责插件的注册、查询和管理
    """

    def __init__(self):
        """初始化管理器"""
        self.plugins: Dict[str, HookPlugin] = {}

    def register(self, plugin: HookPlugin) -> None:
        """注册插件

        Args:
            plugin: 插件实例
        """
        self.plugins[plugin.event_name] = plugin

    def get_plugin(self, event_name: str) -> HookPlugin:
        """根据事件名称获取插件

        Args:
            event_name: 事件名称

        Returns:
            HookPlugin: 插件实例，如果不存在则返回 None
        """
        return self.plugins.get(event_name)

    def list_plugins(self) -> List[str]:
        """列出所有已注册的插件

        Returns:
            List[str]: 事件名称列表
        """
        return list(self.plugins.keys())

    def supports_ide(self, event_name: str, ide: str) -> bool:
        """检查插件是否支持指定 IDE

        Args:
            event_name: 事件名称
            ide: IDE 名称

        Returns:
            bool: 是否支持
        """
        plugin = self.get_plugin(event_name)
        return plugin is not None and ide in plugin.supported_ides
