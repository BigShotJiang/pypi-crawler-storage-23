"""自定义异常类"""


class HookDeployerError(Exception):
    """Hook Deployer 基础异常"""

    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)


class IDENotFoundError(HookDeployerError):
    """IDE 未找到异常"""

    def __init__(self, ide: str):
        self.ide = ide
        message = f"IDE '{ide}' 未检测到或不受支持"
        super().__init__(message)


class HookAlreadyInstalledError(HookDeployerError):
    """Hook 已安装异常"""

    def __init__(self, project_path: str):
        self.project_path = project_path
        message = f"Hook 已经安装在 {project_path}，使用 --force 强制重新安装"
        super().__init__(message)


class ScriptGenerationError(HookDeployerError):
    """脚本生成异常"""

    def __init__(self, plugin_name: str, reason: str):
        self.plugin_name = plugin_name
        self.reason = reason
        message = f"插件 '{plugin_name}' 脚本生成失败: {reason}"
        super().__init__(message)


class ConfigurationError(HookDeployerError):
    """配置异常"""

    def __init__(self, config_file: str, reason: str):
        self.config_file = config_file
        self.reason = reason
        message = f"配置文件 '{config_file}' 错误: {reason}"
        super().__init__(message)


class PermissionError(HookDeployerError):
    """权限异常"""

    def __init__(self, path: str, operation: str):
        self.path = path
        self.operation = operation
        message = f"权限不足: 无法 {operation} '{path}'"
        super().__init__(message)
