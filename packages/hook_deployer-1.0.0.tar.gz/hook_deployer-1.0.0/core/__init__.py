"""Hook Deployer 核心模块"""

__version__ = "1.0.0"
