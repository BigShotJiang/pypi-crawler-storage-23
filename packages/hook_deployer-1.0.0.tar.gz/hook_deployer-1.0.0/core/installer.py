"""IDE 配置安装器"""

from pathlib import Path
from typing import List, Dict, Optional
import json
import shutil

from core.logger import get_logger
from core.exceptions import (
    HookAlreadyInstalledError,
    ConfigurationError,
    PermissionError
)

logger = get_logger()


class Installer:
    """IDE Hook 配置安装器

    负责检测项目中的 IDE 并安装/卸载 Hook 配置
    """

    # IDE 配置文件路径映射
    IDE_CONFIG_PATHS = {
        "claude": ".claude/config.json",
        "cursor": ".cursor/hooks.json",
        "codebuddy": ".codebuddy/config.json",
        "cline": ".cline/hooks.json",
        "openclaw": ".openclaw/hooks.json",
    }

    def __init__(self, project_root: Path):
        """初始化安装器

        Args:
            project_root: 项目根目录
        """
        self.project_root = project_root.resolve()
        logger.debug(f"初始化安装器，项目根目录: {self.project_root}")

    def detect_ides(self) -> List[str]:
        """检测项目中使用的 IDE

        通过检查项目根目录下的配置文件来判断

        Returns:
            List[str]: 检测到的 IDE 列表
        """
        detected = []

        # Claude Code
        if (self.project_root / ".claude").exists():
            detected.append("claude")
            logger.debug("检测到 Claude Code")

        # Cursor
        if (self.project_root / ".cursor").exists():
            detected.append("cursor")
            logger.debug("检测到 Cursor")

        # CodeBuddy
        if (self.project_root / ".codebuddy").exists():
            detected.append("codebuddy")
            logger.debug("检测到 CodeBuddy")

        # Cline
        if (self.project_root / ".cline").exists():
            detected.append("cline")
            logger.debug("检测到 Cline")

        # OpenClaw
        if (self.project_root / ".openclaw").exists():
            detected.append("openclaw")
            logger.debug("检测到 OpenClaw")

        logger.info(f"检测到的 IDE: {', '.join(detected) if detected else '无'}")
        return detected

    def install_hook(self, ide: str, config: Dict) -> None:
        """为指定 IDE 安装 Hook 配置

        Args:
            ide: IDE 名称
            config: Hook 配置字典
        """
        config_path = self.project_root / self.IDE_CONFIG_PATHS.get(ide, "")

        if not config_path.parent.exists():
            try:
                config_path.parent.mkdir(parents=True)
                logger.debug(f"创建配置目录: {config_path.parent}")
            except OSError as e:
                raise PermissionError(str(config_path.parent), "创建目录")

        # 读取现有配置（如果存在）
        existing_config = {}
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    existing_config = json.load(f)
                logger.debug(f"读取现有配置: {config_path}")
            except json.JSONDecodeError as e:
                logger.warning(f"配置文件格式错误，将覆盖: {e}")
                existing_config = {}
            except IOError as e:
                raise ConfigurationError(str(config_path), str(e))

        # 合并配置
        existing_config.update(config)

        # 写入配置文件
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(existing_config, f, indent=2, ensure_ascii=False)
            logger.info(f"已写入 {ide} 配置: {config_path}")
        except IOError as e:
            raise ConfigurationError(str(config_path), str(e))

    def remove_hook(self, ide: str) -> None:
        """移除指定 IDE 的 Hook 配置

        Args:
            ide: IDE 名称
        """
        config_path = self.project_root / self.IDE_CONFIG_PATHS.get(ide, "")

        if not config_path.exists():
            return

        # 读取现有配置
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)

            # 移除 hook 相关配置
            keys_to_remove = ["on_stop", "sessionEnd", "onSessionEnd", "session_end"]
            for key in keys_to_remove:
                config.pop(key, None)

            # 写回配置
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)

        except (json.JSONDecodeError, IOError):
            # 如果配置文件损坏，直接删除
            config_path.unlink()

    def save_project_config(self, config: Dict) -> None:
        """保存项目配置到 .hook-deployer/config.json

        Args:
            config: 配置字典
        """
        config_dir = self.project_root / ".hook-deployer"
        try:
            config_dir.mkdir(parents=True, exist_ok=True)
            logger.debug(f"创建配置目录: {config_dir}")
        except OSError as e:
            raise PermissionError(str(config_dir), "创建目录")

        config_path = config_dir / "config.json"
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            logger.info(f"已保存项目配置: {config_path}")
        except IOError as e:
            raise ConfigurationError(str(config_path), str(e))

    def load_project_config(self) -> Dict:
        """读取项目配置

        Returns:
            Dict: 配置字典，如果不存在则返回空字典
        """
        config_path = self.project_root / ".hook-deployer" / "config.json"

        if not config_path.exists():
            logger.debug("项目配置文件不存在")
            return {}

        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                logger.debug(f"已读取项目配置: {config_path}")
                return config
        except json.JSONDecodeError as e:
            logger.error(f"配置文件格式错误: {e}")
            raise ConfigurationError(str(config_path), str(e))
        except IOError as e:
            logger.error(f"无法读取配置文件: {e}")
            raise ConfigurationError(str(config_path), str(e))

    def remove_project_config(self) -> None:
        """移除项目配置目录"""
        config_dir = self.project_root / ".hook-deployer"

        if config_dir.exists():
            shutil.rmtree(config_dir)
