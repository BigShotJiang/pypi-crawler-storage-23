"""Hook Deployer 打包配置"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="hook-deployer",
    version="1.0.0",
    author="Hook Deployer Team",
    author_email="contact@hook-deployer.com",
    description="AI 对话历史自动存档工具 - 支持 Claude Code、Cursor、CodeBuddy、OpenClaw",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/openclaw/hook-deployer",
    project_urls={
        "Bug Reports": "https://github.com/openclaw/hook-deployer/issues",
        "Source": "https://github.com/openclaw/hook-deployer",
        "Documentation": "https://github.com/openclaw/hook-deployer#readme",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],
    python_requires=">=3.8",
    install_requires=[
        "click>=8.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "hook-deployer=cli:cli",
        ],
    },
    keywords="ai chat history claude cursor codebuddy openclaw hook deployer",
    include_package_data=True,
    zip_safe=False,
)
