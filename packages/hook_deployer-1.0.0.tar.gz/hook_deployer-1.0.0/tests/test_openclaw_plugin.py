"""OpenClaw 插件测试"""

import pytest
from pathlib import Path
import tempfile
from plugins.openclaw import OpenClawPlugin


def test_plugin_properties():
    """测试插件属性"""
    plugin = OpenClawPlugin()

    assert plugin.event_name == "OpenClawSessionEnd"
    assert "openclaw" in plugin.supported_ides


def test_generate_script():
    """测试脚本生成"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = OpenClawPlugin()

        script_path = plugin.generate_script(output_dir)

        assert script_path.exists()
        assert script_path.name == "openclaw-session-end.sh"
        assert script_path.stat().st_mode & 0o111 != 0  # 可执行

        content = script_path.read_text()
        assert "#!/bin/bash" in content
        assert "output_dir" in content
        assert "jq" in content
        assert "OpenClaw" in content
        assert "session_id" in content
        assert "channel" in content


def test_get_openclaw_config():
    """测试 OpenClaw 配置"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = OpenClawPlugin()
        script_path = plugin.generate_script(output_dir)

        config = plugin.get_config("openclaw", script_path)

        assert "on_session_end" in config
        assert config["on_session_end"]["enabled"] is True
        assert config["on_session_end"]["auto_save"] is True
        assert config["on_session_end"]["format"] == "markdown"
        assert script_path.name in config["on_session_end"]["script"]


def test_script_content_format():
    """测试脚本内容格式"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = OpenClawPlugin()

        script_path = plugin.generate_script(output_dir)
        content = script_path.read_text()

        # 检查关键字段
        assert "user_message" in content
        assert "ai_response" in content
        assert "transcript" in content
        assert "chat_id" in content
        assert "provider" in content

        # 检查 Markdown 格式
        assert "# OpenClaw 对话历史" in content
        assert "**时间**:" in content
        assert "**会话 ID**:" in content
        assert "**渠道**:" in content

        # 检查文件权限设置
        assert "chmod 600" in content

        # 检查返回值
        assert "continue" in content
        assert "exit 0" in content
