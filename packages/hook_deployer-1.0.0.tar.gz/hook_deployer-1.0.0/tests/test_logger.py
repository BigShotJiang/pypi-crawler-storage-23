"""日志系统测试"""

import pytest
import tempfile
from pathlib import Path

from core.logger import Logger, get_logger


def test_logger_initialization():
    """测试日志器初始化"""
    logger = Logger("test-logger", "INFO")
    assert logger.logger.name == "test-logger"


def test_log_levels():
    """测试日志级别"""
    logger = Logger("test-logger", "DEBUG")

    # 测试各种日志级别
    logger.debug("Debug message")
    logger.info("Info message")
    logger.warning("Warning message")
    logger.error("Error message")
    logger.critical("Critical message")


def test_file_handler():
    """测试文件处理器"""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_file = Path(tmpdir) / "test.log"
        logger = Logger("test-logger", "DEBUG")

        logger.add_file_handler(log_file)

        # 写入日志
        logger.info("Test message")

        # 验证文件存在
        assert log_file.exists()

        # 验证文件内容
        content = log_file.read_text(encoding='utf-8')
        assert "Test message" in content


def test_set_level():
    """测试设置日志级别"""
    logger = Logger("test-logger", "INFO")
    logger.set_level("DEBUG")

    logger.debug("Debug message")


def test_global_logger():
    """测试全局日志器"""
    logger1 = get_logger("test", "INFO")
    logger2 = get_logger("test", "INFO")

    # 应该返回同一个实例
    assert logger1 is logger2
