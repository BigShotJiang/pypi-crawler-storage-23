"""自举测试 - 验证 hook-deployer 的 OpenClaw 支持"""

import pytest
import tempfile
import subprocess
import json
from pathlib import Path
from click.testing import CliRunner

from cli import cli
from core.installer import Installer


@pytest.fixture
def temp_openclaw_project():
    """创建带有 OpenClaw 配置的临时项目"""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_root = Path(tmpdir)

        # 创建 OpenClaw 配置目录
        openclaw_dir = project_root / ".openclaw"
        openclaw_dir.mkdir()

        yield project_root


def test_openclaw_plugin_registration():
    """测试 OpenClaw 插件是否正确注册"""
    from core.hook_manager import HookManager
    from plugins.openclaw import OpenClawPlugin

    manager = HookManager()
    manager.register(OpenClawPlugin())

    plugin = manager.get_plugin("OpenClawSessionEnd")
    assert plugin is not None
    assert plugin.event_name == "OpenClawSessionEnd"


def test_openclaw_detection(temp_openclaw_project):
    """测试 OpenClaw IDE 检测"""
    installer = Installer(temp_openclaw_project)
    ides = installer.detect_ides()

    assert "openclaw" in ides


def test_openclaw_install(temp_openclaw_project):
    """测试 OpenClaw Hook 安装"""
    runner = CliRunner()

    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_openclaw_project)

        # 执行 install 命令
        result = runner.invoke(cli, ['install'])

        # 检查退出码
        assert result.exit_code == 0

        # 检查输出
        assert "检测到的 IDE" in result.output
        assert "openclaw" in result.output

        # 验证文件创建
        output_dir = temp_openclaw_project / ".ai-conversations"
        assert output_dir.exists()

        script_file = output_dir / "openclaw-session-end.sh"
        assert script_file.exists()

        # 验证项目配置
        config_file = temp_openclaw_project / ".hook-deployer" / "config.json"
        assert config_file.exists()

        config = json.loads(config_file.read_text())
        assert "openclaw" in config.get("enabled_ides", [])
        assert "openclaw" in config.get("hook_scripts", {})

    finally:
        os.chdir(old_cwd)


def test_openclaw_script_execution(temp_openclaw_project):
    """测试 OpenClaw Hook 脚本执行"""
    runner = CliRunner()

    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_openclaw_project)

        # 先安装 Hook
        result1 = runner.invoke(cli, ['install'])
        assert result1.exit_code == 0

        # 生成测试数据
        test_data = {
            "session_id": "test_session_123",
            "channel": "feishu",
            "provider": "feishu",
            "chat_id": "user:test_user",
            "user_message": "你好，这是一条测试消息",
            "ai_response": "你好！这是一条测试响应",
            "transcript": "完整的对话历史内容..."
        }

        # 执行 Hook 脚本
        script_path = temp_openclaw_project / ".ai-conversations" / "openclaw-session-end.sh"
        process = subprocess.run(
            [str(script_path)],
            input=json.dumps(test_data),
            capture_output=True,
            text=True
        )

        # 检查执行结果
        assert process.returncode == 0

        # 验证返回值
        response = json.loads(process.stdout)
        assert response.get("continue") is True

        # 验证文件生成
        output_files = list((temp_openclaw_project / ".ai-conversations").glob("*.md"))
        assert len(output_files) > 0

        # 验证文件内容
        latest_file = output_files[0]
        content = latest_file.read_text(encoding='utf-8')

        assert "# OpenClaw 对话历史" in content
        assert "test_session_123" in content
        assert "feishu" in content
        assert "你好，这是一条测试消息" in content
        assert "你好！这是一条测试响应" in content
        assert "完整的对话历史内容..." in content

    finally:
        os.chdir(old_cwd)


def test_openclaw_uninstall(temp_openclaw_project):
    """测试 OpenClaw Hook 卸载"""
    runner = CliRunner()

    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_openclaw_project)

        # 先安装
        result1 = runner.invoke(cli, ['install'])
        assert result1.exit_code == 0

        # 卸载
        result2 = runner.invoke(cli, ['uninstall'])
        assert result2.exit_code == 0

        # 验证配置文件删除
        config_file = temp_openclaw_project / ".hook-deployer" / "config.json"
        assert not config_file.exists()

    finally:
        os.chdir(old_cwd)


def test_openclaw_multiple_ides():
    """测试多个 IDE 同时存在的情况"""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_root = Path(tmpdir)

        # 创建多个 IDE 配置目录
        (project_root / ".claude").mkdir()
        (project_root / ".openclaw").mkdir()

        installer = Installer(project_root)
        ides = installer.detect_ides()

        assert "claude" in ides
        assert "openclaw" in ides
