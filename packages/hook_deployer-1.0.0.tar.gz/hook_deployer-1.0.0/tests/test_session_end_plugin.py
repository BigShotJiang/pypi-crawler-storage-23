"""SessionEnd 插件测试"""

import pytest
from pathlib import Path
import tempfile
from plugins.session_end import SessionEndPlugin


def test_plugin_properties():
    """测试插件属性"""
    plugin = SessionEndPlugin()

    assert plugin.event_name == "SessionEnd"
    assert "claude" in plugin.supported_ides
    assert "cursor" in plugin.supported_ides
    assert "codebuddy" in plugin.supported_ides


def test_generate_script():
    """测试脚本生成"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = SessionEndPlugin()

        script_path = plugin.generate_script(output_dir)

        assert script_path.exists()
        assert script_path.name == "session-end.sh"
        assert script_path.stat().st_mode & 0o111 != 0  # 可执行

        content = script_path.read_text()
        assert "#!/bin/bash" in content
        assert "output_dir" in content
        assert "jq" in content


def test_get_claude_config():
    """测试 Claude 配置"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = SessionEndPlugin()
        script_path = plugin.generate_script(output_dir)

        config = plugin.get_config("claude", script_path)

        assert "on_stop" in config
        assert config["enabled"] is True
        assert script_path.name in config["on_stop"]


def test_get_cursor_config():
    """测试 Cursor 配置"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = SessionEndPlugin()
        script_path = plugin.generate_script(output_dir)

        config = plugin.get_config("cursor", script_path)

        assert "sessionEnd" in config
        assert config["sessionEnd"]["enabled"] is True
        assert script_path.name in config["sessionEnd"]["script"]


def test_get_codebuddy_config():
    """测试 CodeBuddy 配置"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = SessionEndPlugin()
        script_path = plugin.generate_script(output_dir)

        config = plugin.get_config("codebuddy", script_path)

        assert "onSessionEnd" in config
        assert config["onSessionEnd"]["enabled"] is True
        assert script_path.name in config["onSessionEnd"]["script"]
