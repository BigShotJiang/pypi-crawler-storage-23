"""安装器测试"""

import pytest
from pathlib import Path
import tempfile
import json

from core.installer import Installer


@pytest.fixture
def temp_project():
    """创建临时项目目录"""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_root = Path(tmpdir)

        # 创建 IDE 配置目录
        (project_root / ".claude").mkdir()
        (project_root / ".cursor").mkdir()

        yield project_root


def test_detect_ides(temp_project):
    """测试 IDE 检测"""
    installer = Installer(temp_project)
    ides = installer.detect_ides()

    assert "claude" in ides
    assert "cursor" in ides


def test_install_hook(temp_project):
    """测试 Hook 安装"""
    installer = Installer(temp_project)
    config = {
        "on_stop": "/path/to/script.sh",
        "enabled": True
    }

    installer.install_hook("claude", config)

    config_path = temp_project / ".claude" / "config.json"
    assert config_path.exists()

    with open(config_path, 'r') as f:
        loaded_config = json.load(f)

    assert loaded_config == config


def test_remove_hook(temp_project):
    """测试 Hook 移除"""
    installer = Installer(temp_project)

    # 先安装
    config = {
        "on_stop": "/path/to/script.sh",
        "enabled": True
    }
    installer.install_hook("claude", config)

    # 再移除
    installer.remove_hook("claude")

    config_path = temp_project / ".claude" / "config.json"
    assert config_path.exists()

    with open(config_path, 'r') as f:
        loaded_config = json.load(f)

    assert "on_stop" not in loaded_config


def test_project_config(temp_project):
    """测试项目配置"""
    installer = Installer(temp_project)
    config = {
        "version": "1.0.0",
        "output_dir": ".ai-conversations"
    }

    # 保存
    installer.save_project_config(config)

    # 读取
    loaded = installer.load_project_config()

    assert loaded == config

    # 移除
    installer.remove_project_config()

    config_dir = temp_project / ".hook-deployer"
    assert not config_dir.exists()


def test_nonexistent_project():
    """测试不存在的项目"""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_root = Path(tmpdir) / "nonexistent"
        installer = Installer(project_root)

        # 检测 IDE 应该返回空列表
        ides = installer.detect_ides()
        assert ides == []

        # 读取配置应该返回空字典
        config = installer.load_project_config()
        assert config == {}
