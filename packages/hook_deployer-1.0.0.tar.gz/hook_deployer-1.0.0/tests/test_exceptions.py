"""异常类测试"""

import pytest

from core.exceptions import (
    HookDeployerError,
    IDENotFoundError,
    HookAlreadyInstalledError,
    ScriptGenerationError,
    ConfigurationError,
    PermissionError
)


def test_base_exception():
    """测试基础异常"""
    exc = HookDeployerError("Test error")
    assert str(exc) == "Test error"


def test_ide_not_found_error():
    """测试 IDE 未找到异常"""
    exc = IDENotFoundError("cursor")
    assert exc.ide == "cursor"
    assert "cursor" in str(exc)


def test_hook_already_installed_error():
    """测试 Hook 已安装异常"""
    exc = HookAlreadyInstalledError("/path/to/project")
    assert exc.project_path == "/path/to/project"
    assert "/path/to/project" in str(exc)


def test_script_generation_error():
    """测试脚本生成异常"""
    exc = ScriptGenerationError("SessionEnd", "Permission denied")
    assert exc.plugin_name == "SessionEnd"
    assert exc.reason == "Permission denied"
    assert "SessionEnd" in str(exc)
    assert "Permission denied" in str(exc)


def test_configuration_error():
    """测试配置异常"""
    exc = ConfigurationError("/path/to/config.json", "Invalid JSON")
    assert exc.config_file == "/path/to/config.json"
    assert exc.reason == "Invalid JSON"
    assert "/path/to/config.json" in str(exc)
    assert "Invalid JSON" in str(exc)


def test_permission_error():
    """测试权限异常"""
    exc = PermissionError("/path/to/file", "写入")
    assert exc.path == "/path/to/file"
    assert exc.operation == "写入"
    assert "/path/to/file" in str(exc)
    assert "写入" in str(exc)
