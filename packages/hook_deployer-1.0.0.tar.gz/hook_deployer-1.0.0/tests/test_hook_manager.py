"""Hook 管理器测试"""

import pytest
from core.hook_manager import HookManager
from core.plugin_base import HookPlugin
from pathlib import Path


class TestPlugin(HookPlugin):
    """测试插件"""

    @property
    def event_name(self) -> str:
        return "TestEvent"

    @property
    def supported_ides(self) -> list:
        return ["claude", "cursor"]

    def generate_script(self, output_dir: Path) -> Path:
        return output_dir / "test.sh"

    def get_config(self, ide: str, script_path: Path) -> dict:
        return {}


def test_register_plugin():
    """测试插件注册"""
    manager = HookManager()
    plugin = TestPlugin()

    manager.register(plugin)

    assert manager.get_plugin("TestEvent") == plugin


def test_get_nonexistent_plugin():
    """测试获取不存在的插件"""
    manager = HookManager()

    assert manager.get_plugin("NonExistent") is None


def test_list_plugins():
    """测试列出插件"""
    manager = HookManager()
    plugin1 = TestPlugin()
    manager.register(plugin1)

    assert manager.list_plugins() == ["TestEvent"]


def test_supports_ide():
    """测试 IDE 支持检查"""
    manager = HookManager()
    plugin = TestPlugin()
    manager.register(plugin)

    assert manager.supports_ide("TestEvent", "claude")
    assert manager.supports_ide("TestEvent", "cursor")
    assert not manager.supports_ide("TestEvent", "codebuddy")
    assert not manager.supports_ide("NonExistent", "claude")
