"""插件基类测试"""

import pytest
from pathlib import Path
import tempfile
import shutil

from core.plugin_base import HookPlugin


class MockPlugin(HookPlugin):
    """测试用的 Mock 插件"""

    @property
    def event_name(self) -> str:
        return "TestEvent"

    @property
    def supported_ides(self) -> list:
        return ["test_ide"]

    def generate_script(self, output_dir: Path) -> Path:
        script_path = output_dir / "test.sh"
        script_path.write_text("#!/bin/bash\necho 'test'\n")
        script_path.chmod(0o755)
        return script_path

    def get_config(self, ide: str, script_path: Path) -> dict:
        return {"script": str(script_path)}


def test_plugin_properties():
    """测试插件属性"""
    plugin = MockPlugin()

    assert plugin.event_name == "TestEvent"
    assert plugin.supported_ides == ["test_ide"]


def test_generate_script():
    """测试脚本生成"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = MockPlugin()

        script_path = plugin.generate_script(output_dir)

        assert script_path.exists()
        assert script_path.is_file()
        assert script_path.stat().st_mode & 0o111 != 0  # 可执行


def test_get_config():
    """测试配置获取"""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir)
        plugin = MockPlugin()
        script_path = plugin.generate_script(output_dir)

        config = plugin.get_config("test_ide", script_path)

        assert "script" in config
        assert config["script"] == str(script_path)
