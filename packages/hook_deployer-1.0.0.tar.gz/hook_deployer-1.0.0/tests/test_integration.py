"""集成测试"""

import pytest
import tempfile
import shutil
from pathlib import Path
import json

from cli import cli
from click.testing import CliRunner
from core.installer import Installer


@pytest.fixture
def temp_project_with_ide():
    """创建带有 IDE 配置的临时项目"""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_root = Path(tmpdir)

        # 创建 Claude Code 配置目录
        claude_dir = project_root / ".claude"
        claude_dir.mkdir()

        # 创建 Cursor 配置目录
        cursor_dir = project_root / ".cursor"
        cursor_dir.mkdir()

        yield project_root


def test_install_command(temp_project_with_ide):
    """测试 install 命令"""
    runner = CliRunner()

    # 切换到项目目录
    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_project_with_ide)

        # 执行 install 命令
        result = runner.invoke(cli, ['install'])

        # 检查退出码
        assert result.exit_code == 0

        # 检查输出
        assert "检测到的 IDE" in result.output
        assert "已为 claude 配置 Hook" in result.output

        # 验证文件创建
        output_dir = temp_project_with_ide / ".ai-conversations"
        assert output_dir.exists()

        script_file = output_dir / "session-end.sh"
        assert script_file.exists()

        # 验证项目配置
        config_file = temp_project_with_ide / ".hook-deployer" / "config.json"
        assert config_file.exists()

        config = json.loads(config_file.read_text())
        assert "version" in config
        assert "enabled_ides" in config

    finally:
        os.chdir(old_cwd)


def test_install_with_force(temp_project_with_ide):
    """测试强制重新安装"""
    runner = CliRunner()

    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_project_with_ide)

        # 第一次安装
        result1 = runner.invoke(cli, ['install'])
        assert result1.exit_code == 0

        # 第二次安装（应该提示已安装）
        result2 = runner.invoke(cli, ['install'])
        assert result2.exit_code == 1
        assert "已经安装" in result2.output

        # 强制重新安装
        result3 = runner.invoke(cli, ['install', '--force'])
        assert result3.exit_code == 0
        assert "安装完成" in result3.output

    finally:
        os.chdir(old_cwd)


def test_install_custom_output_dir(temp_project_with_ide):
    """测试自定义输出目录"""
    runner = CliRunner()

    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_project_with_ide)

        # 使用自定义输出目录
        result = runner.invoke(cli, ['install', '--output-dir', 'custom-history'])

        assert result.exit_code == 0

        # 验证自定义目录
        custom_dir = temp_project_with_ide / "custom-history"
        assert custom_dir.exists()

        config_file = temp_project_with_ide / ".hook-deployer" / "config.json"
        config = json.loads(config_file.read_text())
        assert config["output_dir"] == "custom-history"

    finally:
        os.chdir(old_cwd)


def test_uninstall_command(temp_project_with_ide):
    """测试 uninstall 命令"""
    runner = CliRunner()

    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_project_with_ide)

        # 先安装
        result1 = runner.invoke(cli, ['install'])
        assert result1.exit_code == 0

        # 验证配置文件存在
        config_file = temp_project_with_ide / ".hook-deployer" / "config.json"
        assert config_file.exists()

        # 卸载
        result2 = runner.invoke(cli, ['uninstall'])
        assert result2.exit_code == 0
        assert "已移除" in result2.output

        # 验证配置文件已删除
        assert not config_file.exists()

    finally:
        os.chdir(old_cwd)


def test_list_command(temp_project_with_ide):
    """测试 list 命令"""
    runner = CliRunner()

    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_project_with_ide)

        # 未安装时
        result1 = runner.invoke(cli, ['list'])
        assert "未安装 Hook" in result1.output

        # 安装后
        result2 = runner.invoke(cli, ['install'])
        assert result2.exit_code == 0

        result3 = runner.invoke(cli, ['list'])
        assert result3.exit_code == 0
        assert "版本" in result3.output
        assert "已启用的 IDE" in result3.output

    finally:
        os.chdir(old_cwd)


def test_no_ide_detected():
    """测试没有检测到 IDE 的情况"""
    runner = CliRunner()

    with tempfile.TemporaryDirectory() as tmpdir:
        old_cwd = Path.cwd()
        try:
            import os
            os.chdir(tmpdir)

            # 空目录，没有 IDE
            result = runner.invoke(cli, ['install'])

            # 应该成功但没有配置任何 IDE
            assert result.exit_code == 0
            assert "未检测到支持的 IDE" in result.output

        finally:
            os.chdir(old_cwd)


def test_verbose_mode(temp_project_with_ide):
    """测试详细日志模式"""
    runner = CliRunner()

    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(temp_project_with_ide)

        # 使用 verbose 模式
        result = runner.invoke(cli, ['install', '--verbose'])

        assert result.exit_code == 0

    finally:
        os.chdir(old_cwd)
