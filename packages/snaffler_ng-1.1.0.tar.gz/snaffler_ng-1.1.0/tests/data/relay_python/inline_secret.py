apiKey = "deadbeefcafebabe1234"
client_secret = "topsecretvalue"
