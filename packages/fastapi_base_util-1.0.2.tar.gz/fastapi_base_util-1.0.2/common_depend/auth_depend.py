import json
from fastapi import Depends, Request
from fastapi.security import OAuth2PasswordBearer, SecurityScopes
from common.consts import REDIS_PREFIX_BLOCKLIST, REDIS_PREFIX_USER_INFO
from common.exception import CustomException
from common_model.user_model import User
from common_utlis.jwt_util import JwtUtil
from core.databases.aioredis import AioRedis

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth_center/login")

async def get_current_user(request: Request, token: str, security_scopes: SecurityScopes) -> User:
    """
    获取当前登录用户
    """
    payload = JwtUtil.decode_token(token)
    if not payload:
        raise CustomException(msg="无效的令牌")

    # 检查是否在黑名单中
    if await AioRedis.get(f"{REDIS_PREFIX_BLOCKLIST}{token}"):
        raise CustomException(msg="令牌已失效")

    user_id = payload.get("sub")
    if not user_id:
        raise CustomException(msg="无效的令牌")

    # 1. 尝试从缓存获取
    user = None
    user_data = await AioRedis.get(f"{REDIS_PREFIX_USER_INFO}{user_id}")
    if user_data:
        user = User(**json.loads(user_data))

    # 2. 缓存未命中，查库
    if not user:
        user = await User.get_or_none(id=user_id)
        if user:
            user_data = await user.model_dump()
            await AioRedis.set(f"{REDIS_PREFIX_USER_INFO}{user_id}", json.dumps(user_data), ex=60 * 60 * 24)

    if not user:
        raise CustomException(msg="用户不存在")

    if not user.is_active:
        raise CustomException(msg="用户已被禁用")

    permissions = []
    if user.is_superuser:
        permissions.append('*.*.*')
    else:
        # TODO 从数据库中查询用户权限
        pass

    # 设置请求上下文
    request.state.user = user
    return user


async def login_require(request: Request, security_scopes: SecurityScopes, token=Depends(oauth2_scheme)) -> User:
    """获取用户，获取不到报错"""
    if not token:
        raise CustomException('请先登录')

    return await get_current_user(request, token, security_scopes)


async def login_or_none(request: Request, security_scopes: SecurityScopes, token=Depends(oauth2_scheme)) -> User | None:
    """获取用户，获取不到返回空"""
    if not token:
        return None

    try:
        return await get_current_user(request, token, security_scopes)
    except Exception as e:
        return None
