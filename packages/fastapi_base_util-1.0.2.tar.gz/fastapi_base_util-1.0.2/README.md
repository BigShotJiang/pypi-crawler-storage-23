pip uninstall ../fastapi_base/fastapi_base-1.0-py3-none-any.whl -y
pip install ../fastapi_base/fastapi_base-1.0-py3-none-any.whl
