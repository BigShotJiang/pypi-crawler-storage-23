from pydantic_settings import BaseSettings, SettingsConfigDict


class BaseConfig(BaseSettings):
    app_debug: bool = False
    app_title: str = ''
    app_name: str = ''

    redis_url: str = ''
    mysql_url: str = ''

    # 跨域
    cors_origins: list[str] = ['*']
    cors_allow_credentials: bool = True
    cors_allow_methods: list[str] = ['GET', 'POST', 'PUT', 'DELETE']
    cors_allow_headers: list[str] = ['*']

    # jwt密钥
    jwt_secret_key: str = "bgb0tnl9d58+6n-6h-ea&u^1#s0ccp!794=krylacjq75vzps$"

    model_config = SettingsConfigDict(
        env_file=('envs/dev.env', 'envs/pro.env'),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra='ignore'
    )

base_config = BaseConfig()
