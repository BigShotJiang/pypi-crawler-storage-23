import datetime
from typing import Dict, List, Optional, Any, Tuple
from fastapi import FastAPI
from fastapi.encoders import jsonable_encoder
from tortoise import Tortoise
from tortoise.models import Model
from tortoise.contrib.fastapi import RegisterTortoise
from tortoise.queryset import QuerySetSingle, QuerySet
from contextlib import asynccontextmanager

from core.base_config import base_config

db_models = [
    'aerich.models',
    'models'
]

db_config = {
    'connections': {
        'main': base_config.mysql_url,  # 默认数据库连接
    },
    'apps': {
        'main': {'models': db_models, 'default_connection': 'main'},
    },
    'use_tz': False,
    'timezone': 'Asia/Shanghai'
}

class AioDb:

    ### 事务的两种方式：
    # async with in_transaction() as connection:  
    #     pass
    #
    # @atomic('main')  （推荐使用）
    # def func():
    #     pass
    #

    @classmethod
    async def connect(cls):
        await Tortoise.init(config=db_config)

    @classmethod
    async def close(cls):
        await Tortoise.close_connections()

    @classmethod
    async def register_db(cls, app: FastAPI) -> RegisterTortoise:
        # 注册数据库，FastAPI用
        tortoise = RegisterTortoise(
            app,
            config=db_config,
            generate_schemas=False,  # 自动创建不存在的表（生产环境建议关闭，手动管理）
            add_exception_handlers=True  # 添加 Tortoise 异常处理器
        )
        return tortoise
        

    @classmethod
    async def init_tables(cls):
        """初始化数据库表，如果表不存在则创建"""
        try:
            await Tortoise.generate_schemas()
        except Exception as e:
            raise e

    @classmethod
    @asynccontextmanager
    async def execute(cls):
        """
        :example:
            async with AioDb.execute():
                await async_func()
        """
        await cls.connect()
        yield
        await cls.close()

    @classmethod
    def get_model_by_name(cls, name, app='main'):
        return Tortoise.apps[app][name]

    @classmethod
    async def run_func(cls, func, *args, **kwargs):
        async with AioDb.execute():
            await func(*args, **kwargs)


class MySQLUtils(Model):

    async def model_dump(self, **kwargs):
        return await MySQLUtils.model2dict(self, **kwargs)

    @staticmethod
    def json_encoder(
            obj: Any,
            include: Optional[List[str]] = None,
            exclude: Optional[List[str]] = None,
            **kwargs
    ):
        return jsonable_encoder(
            obj,
            include=set(include) if include else None,
            exclude=set(exclude) if exclude else None,
            custom_encoder={
                datetime.datetime: lambda dt: datetime.datetime.strftime(dt, '%Y-%m-%d %H:%M:%S')
            }
        )

    @classmethod
    async def model2dict(
            cls,
            model: Model,
            include: List[str] | None = None,
            exclude: List[str] | None = None,
            alias: List[Tuple[str, str]] | None = None,
            fetch_related: List[str] | None = None,
            flat: bool = False,  # 扁平化
            **kwargs
    ) -> Dict[str, Any]:
        meta = getattr(cls, 'PydanticMeta', getattr(cls, 'Meta', None))
        if meta:
            _include = getattr(meta, 'include', None)
            _exclude = getattr(meta, 'exclude', None)
            if _include:
                include = list(set(include + _include)) if include else _include
            if _exclude:
                exclude = list(set(exclude + _exclude)) if exclude else _exclude

        if include and exclude:
            for include_field in include:
                if include_field in exclude:
                    exclude.remove(include_field)

        alias_dict = dict()
        if alias:
            for item in alias:
                alias_dict[item[0]] = item[1]
        
        # 默认过滤掉deleted字段
        if exclude:
            exclude.append('deleted')
        else:
            exclude = ['deleted']

        result = cls.json_encoder(
            obj=model,
            include=include,
            exclude=exclude,
            **kwargs
        )

        if alias_dict:
            for attr in result.keys():
                if attr in alias_dict:
                    result[alias_dict[attr]] = result.pop(attr)

        fix_data = getattr(model, 'fix_data', None)
        if fix_data and callable(fix_data):
            fix_data(result)

        if fetch_related:
            for fr in fetch_related:
                fr_include = kwargs.get(f'fr_{fr}_include')
                fr_exclude = kwargs.get(f'fr_{fr}_exclude')
                fr_field = getattr(model, fr)
                if not fr_field:
                    result[fr] = None
                    continue
                fr_model = await fr_field

                fr_meta = getattr(fr_model, 'PydanticMeta', None)
                if fr_meta:
                    _fr_include = getattr(fr_meta, 'include', None)
                    _fr_exclude = getattr(fr_meta, 'exclude', None)
                    if _fr_include:
                        fr_include = list(set(fr_include + _fr_include)) if fr_include else _fr_include
                    if _fr_exclude:
                        fr_exclude = list(set(fr_exclude + _fr_exclude)) if fr_exclude else _fr_exclude

                if fr_include and fr_exclude:
                    for fr_include_field in fr_include:
                        if fr_include_field in fr_exclude:
                            fr_exclude.remove(fr_include_field)

                fix_data = None
                if isinstance(fr_model, list) and fr_model:
                    fix_data = getattr(fr_model[0], 'fix_data', None)
                elif isinstance(fr_model, Model):
                    fix_data = getattr(fr_model, 'fix_data', None)

                # 默认过滤掉deleted字段
                if fr_exclude:
                    fr_exclude.append('deleted')
                else:
                    fr_exclude = ['deleted']

                fr_result = cls.json_encoder(
                    obj=fr_model,
                    include=fr_include,
                    exclude=fr_exclude,
                    **kwargs
                )

                if alias_dict:
                    for attr in result.keys():
                        key = f'{fr}.{attr}'
                        if key in alias_dict:
                            fr_result[alias_dict[key]] = fr_result.pop(attr)

                if fix_data and callable(fix_data):
                    if isinstance(fr_result, list):
                        for frr in fr_result:
                            fix_data(frr)
                    elif isinstance(fr_result, dict):
                        fix_data(fr_result)

                if flat and isinstance(fr_result, dict):
                    for k, v in fr_result.items():
                        result[fr + '_' + k] = v
                else:
                    result[fr] = fr_result
        return result

    @classmethod
    async def get_data(
            cls,
            *args,
            include: List[str] | None = None,  # 包含哪些字段，默认全部
            exclude: List[str] | None = None,  # 排除哪些字段，默认全部
            alias: List[Tuple[str, str]] | None = None,  # 字段别名，如[('id', 'uid')]
            fetch_related: List[str] | None = None,  # 对应关系表
            flat: bool = False,  # 扁平化
            deleted: bool | None = None,
            queryset_model: QuerySetSingle | Model | None = None,
            **kwargs
    ) -> Dict[str, Any] | None:
        if 'deleted' in cls._meta.fields and deleted is None:
            kwargs['deleted'] = False

        queryKwargs = {}
        if fetch_related:
            for k, v in kwargs.items():
                if k.startswith('fr_'):
                    continue
                queryKwargs[k] = v
        else:
            queryKwargs = kwargs

        qm: QuerySetSingle | Model = queryset_model if queryset_model else cls.get(*args, **queryKwargs)
        if isinstance(qm, Model):
            if fetch_related:
                await qm.fetch_related(*fetch_related)
            model = qm
        else:
            if fetch_related:
                qm = qm.prefetch_related(*fetch_related)
            model = await qm

        if not model:
            return None
        result = await cls.model2dict(model, include, exclude, alias, fetch_related, flat, **kwargs)
        return result

    @classmethod
    async def get_or_none_data(
            cls,
            *args,
            include: List[str] | None = None,  # 包含哪些字段，默认全部
            exclude: List[str] | None = None,  # 排除哪些字段，默认全部
            alias: List[Tuple[str, str]] | None = None,  # 字段别名，如[('id', 'uid')]
            fetch_related: List[str] | None = None,  # 对应关系表
            flat: bool = False,  # 扁平化
            deleted: bool | None = None,
            queryset_model: QuerySetSingle | Model | None = None,
            **kwargs
    ) -> Dict[str, Any] | None:
        if 'deleted' in cls._meta.fields and deleted is None:
            kwargs['deleted'] = False

        queryKwargs = {}
        if fetch_related:
            for k, v in kwargs.items():
                if k.startswith('fr_'):
                    continue
                queryKwargs[k] = v
        else:
            queryKwargs = kwargs

        qm: QuerySetSingle | Model = queryset_model if queryset_model else cls.get_or_none(*args, **kwargs)
        if isinstance(qm, Model):
            if fetch_related:
                await qm.fetch_related(*fetch_related)
            model = qm
        else:
            if fetch_related:
                qm = qm.prefetch_related(*fetch_related)
            model = await qm

        if not model:
            return None
        result = await cls.model2dict(model, include, exclude, alias, fetch_related, flat, **kwargs)
        return result

    @classmethod
    async def query_data(
            cls,
            *args,
            page_no: int | None = 0,
            page_size: int | None = 0,
            nocount: bool = False,
            include: List[str] | None = None,   # 包含哪些字段，默认全部
            exclude: List[str] | None = None,   # 排除哪些字段，默认全部
            alias: List[Tuple[str, str]] | None = None,   # 字段别名，如[('id', 'uid')]
            fetch_related: List[str] | None = None,  # 对应关系表
            flat: bool = False,  # 扁平化
            deleted: bool | None = None,
            queryset: QuerySet | None = None,
            order_by: List[str] | None = None,
            **kwargs
    ) -> Dict[str, Any] | List[Dict[str, Any]]:
        if 'deleted' in cls._meta.fields and deleted is None:
            kwargs['deleted'] = False

        queryKwargs = {}
        if fetch_related:
            for k, v in kwargs.items():
                if k.startswith('fr_'):
                    continue
                queryKwargs[k] = v
        else:
            queryKwargs = kwargs

        qs: QuerySet = queryset if queryset else cls.filter(*args, **kwargs)
        result = {'items': [], 'count': 0}
        if not nocount:
            result['count'] = await qs.count()
        else:
            del result['count']

        if order_by:
            qs = qs.order_by(*order_by)
        if page_no and page_size:
            qs = qs.limit(page_size).offset((page_no - 1) * page_size)
        if fetch_related:
            qs = qs.prefetch_related(*fetch_related)

        model_list = await qs
        for model in model_list:
            item = await cls.model2dict(model, include, exclude, alias, fetch_related, flat, **kwargs)
            result['items'].append(item)

        if nocount:
            return result['items']
            
        return result

    class Meta:
        abstract = True
