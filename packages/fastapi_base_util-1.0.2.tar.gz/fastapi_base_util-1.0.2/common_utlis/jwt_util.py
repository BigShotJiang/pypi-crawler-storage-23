import jwt
from datetime import datetime, timedelta
from typing import Any
from core.base_config import base_config

class JwtUtil:
    """
    JWT 工具类
    """
    SECRET_KEY = base_config.jwt_secret_key
    ALGORITHM = "HS256"

    @classmethod
    def create_access_token(cls, data: dict, expires_delta: timedelta) -> str:
        """
        生成访问令牌
        
        Args:
            data: 数据载荷
            expires_delta: 过期时间差 (必须指定)
            
        Returns:
            str: JWT Token
        """
        to_encode = data.copy()
        expire = datetime.now() + expires_delta
        
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, cls.SECRET_KEY, algorithm=cls.ALGORITHM)
        return encoded_jwt

    @classmethod
    def decode_token(cls, token: str) -> dict[str, Any] | None:
        """
        解析令牌
        
        Args:
            token: JWT Token
            
        Returns:
            dict | None: 解析后的数据，解析失败返回 None
        """
        try:
            payload = jwt.decode(token, cls.SECRET_KEY, algorithms=[cls.ALGORITHM])
            return payload
        except jwt.PyJWTError:
            return None
