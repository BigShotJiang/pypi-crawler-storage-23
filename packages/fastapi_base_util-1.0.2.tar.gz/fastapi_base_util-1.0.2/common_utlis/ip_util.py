import re

from common import aiorequests


class IpUtil:
    """
    获取IP归属地工具类
    """
    
    @classmethod
    def is_valid_ip(cls, ip: str) -> bool:
        """
        校验IP格式是否合法
        
        :param ip: IP地址
        :return: 是否合法
        """
        ip_pattern = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        return bool(re.match(ip_pattern, ip))
    
    @classmethod
    def is_private_ip(cls, ip: str) -> bool:
        """
        校验IP是否为内网IP
        
        :param ip: IP地址
        :return: 是否为内网IP
        """
        ip_parts = list(map(int, ip.split('.')))
        
        # 检查是否为 10.0.0.0/8
        if ip_parts[0] == 10:
            return True
        
        # 检查是否为 172.16.0.0/12
        if ip_parts[0] == 172 and 16 <= ip_parts[1] <= 31:
            return True
        
        # 检查是否为 192.168.0.0/16
        if ip_parts[0] == 192 and ip_parts[1] == 168:
            return True
        
        # 检查是否为 127.0.0.0/8
        if ip_parts[0] == 127:
            return True
        
        return False


    @classmethod
    async def get_ip_location(cls, ip: str) -> str | None:
        """
        获取IP归属地信息
        
        :param ip: IP地址
        :return: IP归属地信息
        """
        # 校验IP格式
        if not cls.is_valid_ip(ip):
            # IP格式不合法
            return "未知"
        
        # 内网IP直接返回
        if cls.is_private_ip(ip):
            return '内网IP'
            
        try:
            # 使用ip-api.com API获取IP归属地信息
            response = await aiorequests.get(f'http://ip-api.com/json/{ip}')
            if response and response.json().get('ret') == 200:
                    result = response.json().get('data', {})
                    return f"{result.get('country','')}-{result.get('prov','')}-{result.get('city','')}-{result.get('area','')}-{result.get('isp','')}"

            response = await aiorequests.get(f'https://qifu-api.baidubce.com/ip/geo/v1/district?ip={ip}')
            if response and response.json().get('code') == "Success":
                    data = response.json().get('data', {})
                    # 修正原代码中的格式错误
                    return f"{data.get('country','')}-{data.get('prov','')}-{data.get('city','')}-{data.get('district','')}-{data.get('isp','')}"

        except Exception as e:
            # 获取IP归属地失败
            return "未知"
