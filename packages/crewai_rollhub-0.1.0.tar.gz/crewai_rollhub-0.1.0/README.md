# crewai-rollhub

CrewAI tools for [Agent Casino](https://agent.rollhub.com) — let your AI agents gamble with provably fair dice, verify bets, and earn affiliate revenue.

## Installation

```bash
pip install crewai-rollhub
```

## Quick Start

```python
from crewai import Agent, Task, Crew
from crewai_rollhub import RollhubTools

# Initialize all tools with your API key
tools = RollhubTools(api_key="rh_sk_...").all()

# Create a gambling analyst agent
analyst = Agent(
    role="Gambling Analyst",
    goal="Analyze dice betting strategies and maximize returns while managing risk",
    backstory="You are a seasoned quantitative analyst who uses provably fair dice games to test betting strategies.",
    tools=tools,
    verbose=True,
)

# Give it a task
task = Task(
    description=(
        "Check our current balance, then place a conservative bet "
        "(target=0.5, direction=over, amount=100 cents). "
        "Verify the bet was provably fair. Report the results."
    ),
    expected_output="A report with balance, bet result, and verification status.",
    agent=analyst,
)

crew = Crew(agents=[analyst], tasks=[task], verbose=True)
result = crew.kickoff()
print(result)
```

## Available Tools

| Tool | Description |
|------|-------------|
| `RollhubBetTool` | Place a provably fair dice bet |
| `RollhubVerifyTool` | Verify a bet's cryptographic proof |
| `RollhubBalanceTool` | Check account balance |
| `RollhubAffiliateTool` | Check affiliate/referral earnings |
| `RollhubDepositTool` | Get a deposit address |
| `RollhubWithdrawTool` | Withdraw funds |

## Using Individual Tools

```python
from crewai_rollhub import RollhubBetTool, RollhubBalanceTool

bet_tool = RollhubBetTool(api_key="rh_sk_...")
balance_tool = RollhubBalanceTool(api_key="rh_sk_...")

agent = Agent(
    role="Dice Player",
    goal="Place smart bets",
    backstory="A careful gambler.",
    tools=[bet_tool, balance_tool],
)
```

## Getting an API Key

```python
from rollhub_dice import DiceAgent

agent = DiceAgent.register(wallet_address="your_wallet_address")
print(agent.api_key)  # rh_sk_...
```

## Links

- [Agent Casino](https://agent.rollhub.com)
- [rollhub-dice SDK](https://pypi.org/project/rollhub-dice/)
- [CrewAI docs](https://docs.crewai.com)
