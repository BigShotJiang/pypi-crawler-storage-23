#!/bin/env python3

__version__="0.0.0.0"
__datetime__="Jan 01 00:00 UTC 1970"