"""Sharpe log capture server extension.

Attaches a ring-buffer handler to the ServerApp logger and exposes
buffered entries via:
  GET /api/sharpe/logs          -- JSON snapshot (cursor-based pagination)
  GET /api/sharpe/logs/stream   -- SSE stream (real-time push)
"""

import asyncio
import json
import logging
import threading
from collections import deque
from datetime import datetime, timezone

from jupyter_server.base.handlers import JupyterHandler
from tornado import web
from tornado.iostream import StreamClosedError


class RingBufferHandler(logging.Handler):
    """Thread-safe ring buffer that stores the last *maxlen* log records.

    Also maintains an asyncio Event that SSE handlers can await to be
    notified of new entries without polling.
    """

    def __init__(self, maxlen: int = 500):
        super().__init__()
        self._lock = threading.Lock()
        self._buf: deque[dict] = deque(maxlen=maxlen)
        self._seq = 0
        self._notify_event: asyncio.Event | None = None
        self._loop: asyncio.AbstractEventLoop | None = None

    def emit(self, record: logging.LogRecord) -> None:
        entry = {
            "seq": 0,
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "message": self.format(record),
            "level": record.levelname,
            "source": record.name,
        }
        with self._lock:
            self._seq += 1
            entry["seq"] = self._seq
            self._buf.append(entry)

        # Wake up any SSE handlers waiting for new entries.
        if self._loop is not None and self._notify_event is not None:
            try:
                self._loop.call_soon_threadsafe(self._notify_event.set)
            except RuntimeError:
                pass

    def get_entries(self, cursor: int = 0, limit: int = 100) -> tuple[list[dict], int]:
        with self._lock:
            entries = [e for e in self._buf if e["seq"] > cursor]
            head = self._seq
        entries = entries[:limit]
        next_cursor = entries[-1]["seq"] if entries else max(cursor, head)
        return entries, next_cursor

    async def wait_for_new(self, timeout: float = 30.0) -> None:
        """Block until a new entry arrives or *timeout* seconds elapse."""
        # Lazily bind to the running event loop on first await
        if self._notify_event is None:
            self._loop = asyncio.get_running_loop()
            self._notify_event = asyncio.Event()
        try:
            await asyncio.wait_for(self._notify_event.wait(), timeout=timeout)
            self._notify_event.clear()
        except asyncio.TimeoutError:
            pass


_ring_buffer = RingBufferHandler()


class LogsHandler(JupyterHandler):
    """GET /api/sharpe/logs -- returns buffered log entries as JSON."""

    @web.authenticated
    def get(self) -> None:
        cursor = int(self.get_argument("cursor", "0"))
        limit = int(self.get_argument("limit", "100"))
        limit = max(1, min(limit, 500))

        entries, next_cursor = _ring_buffer.get_entries(cursor, limit)

        self.set_header("Content-Type", "application/json")
        self.finish(json.dumps({"entries": entries, "nextCursor": next_cursor}))


class LogStreamHandler(JupyterHandler):
    """GET /api/sharpe/logs/stream -- SSE endpoint that pushes log entries."""

    @web.authenticated
    async def get(self) -> None:
        self.set_header("Content-Type", "text/event-stream")
        self.set_header("Cache-Control", "no-cache")
        self.set_header("X-Accel-Buffering", "no")

        cursor = int(self.get_argument("cursor", "0"))

        try:
            # Send existing entries first
            entries, cursor = _ring_buffer.get_entries(cursor)
            for entry in entries:
                self.write(f"data: {json.dumps(entry)}\n\n")
            await self.flush()

            # Then push new entries as they arrive
            while True:
                await _ring_buffer.wait_for_new()

                entries, cursor = _ring_buffer.get_entries(cursor)
                if not entries:
                    self.write(": keepalive\n\n")
                    await self.flush()
                    continue

                for entry in entries:
                    self.write(f"data: {json.dumps(entry)}\n\n")
                await self.flush()
        except StreamClosedError:
            pass


def _load_jupyter_server_extension(serverapp) -> None:  # noqa: ANN001
    """Called by jupyter-server to initialise the extension."""

    _ring_buffer.setLevel(logging.INFO)
    _ring_buffer.setFormatter(logging.Formatter("%(message)s"))

    serverapp.log.addHandler(_ring_buffer)

    host_pattern = ".*$"
    base_url = serverapp.web_app.settings["base_url"]

    logs_route = f"{base_url}api/sharpe/logs"
    stream_route = f"{base_url}api/sharpe/logs/stream"

    serverapp.web_app.add_handlers(
        host_pattern,
        [
            (logs_route, LogsHandler),
            (stream_route, LogStreamHandler),
        ],
    )

    serverapp.log.info("[SharpeLogExtension] Registered %s and %s", logs_route, stream_route)
