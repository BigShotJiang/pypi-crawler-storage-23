__version__ = "0.2.0"


def _jupyter_server_extension_points():
    return [{"module": "sharpe_log_handler"}]


def _load_jupyter_server_extension(serverapp):
    from .handler import _load_jupyter_server_extension as _load

    _load(serverapp)
