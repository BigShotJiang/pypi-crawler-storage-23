"""Tests for {{ cookiecutter.package_name }}."""
