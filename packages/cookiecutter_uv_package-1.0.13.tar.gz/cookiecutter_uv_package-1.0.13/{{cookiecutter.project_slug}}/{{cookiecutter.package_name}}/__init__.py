"""{{ cookiecutter.project_short_description }}"""

from __future__ import annotations

__version__ = "{{ cookiecutter.version }}"
__all__ = ["__version__"]
