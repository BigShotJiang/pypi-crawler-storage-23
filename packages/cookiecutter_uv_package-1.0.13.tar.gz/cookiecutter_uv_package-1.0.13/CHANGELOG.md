# Changelog

All notable changes to this project will be documented in this file. See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.13](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.12...v1.0.13) (2026-02-28)


### Bug Fixes

* **deps-dev:** bump ruff from 0.15.0 to 0.15.1 in the all-pip-deps group ([#31](https://github.com/serafinovsky/cookiecutter-uv-package/issues/31)) ([81555a4](https://github.com/serafinovsky/cookiecutter-uv-package/commit/81555a4533a81ab64c7b40e8da14501bab225189))

## [1.0.12](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.11...v1.0.12) (2026-02-13)


### Bug Fixes

* **deps-dev:** bump ruff from 0.14.14 to 0.15.0 in the all-pip-deps group ([#29](https://github.com/serafinovsky/cookiecutter-uv-package/issues/29)) ([3a4cf5b](https://github.com/serafinovsky/cookiecutter-uv-package/commit/3a4cf5bfe975432567ad937d93674d87c338f12d))

## [1.0.11](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.10...v1.0.11) (2026-02-05)


### Bug Fixes

* **deps-dev:** bump ruff from 0.14.11 to 0.14.14 in the all-pip-deps group ([#27](https://github.com/serafinovsky/cookiecutter-uv-package/issues/27)) ([e5943f4](https://github.com/serafinovsky/cookiecutter-uv-package/commit/e5943f42845fbe42eafdccd21caabc4a3286f750))

## [1.0.10](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.9...v1.0.10) (2026-01-27)


### Bug Fixes

* **deps-dev:** bump ruff from 0.14.7 to 0.14.11 in the all-pip-deps group across 1 directory ([#25](https://github.com/serafinovsky/cookiecutter-uv-package/issues/25)) ([191547d](https://github.com/serafinovsky/cookiecutter-uv-package/commit/191547ddb134134ab3b2c5b8b74755809b7debdf))

## [1.0.9](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.8...v1.0.9) (2025-12-08)


### Bug Fixes

* **deps-dev:** bump ruff from 0.14.3 to 0.14.7 in the all-pip-deps group ([#21](https://github.com/serafinovsky/cookiecutter-uv-package/issues/21)) ([1457c6f](https://github.com/serafinovsky/cookiecutter-uv-package/commit/1457c6f0db12d8d3b7a493a761c972c3c30f9dac))

## [1.0.8](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.7...v1.0.8) (2025-11-25)


### Bug Fixes

* **deps-dev:** bump ruff from 0.14.1 to 0.14.3 in the all-pip-deps group ([#19](https://github.com/serafinovsky/cookiecutter-uv-package/issues/19)) ([afda206](https://github.com/serafinovsky/cookiecutter-uv-package/commit/afda206844968613aa93a4b236e45be2b50d6021))

## [1.0.7](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.6...v1.0.7) (2025-11-02)


### Bug Fixes

* **deps:** bump the all-pip-deps group with 2 updates ([#17](https://github.com/serafinovsky/cookiecutter-uv-package/issues/17)) ([b61261e](https://github.com/serafinovsky/cookiecutter-uv-package/commit/b61261e4fffd734fd21de3d088a08bfa89e60495))

## [1.0.6](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.5...v1.0.6) (2025-10-14)


### Bug Fixes

* **deps:** bump the all-pip-deps group with 3 updates ([#14](https://github.com/serafinovsky/cookiecutter-uv-package/issues/14)) ([e8210eb](https://github.com/serafinovsky/cookiecutter-uv-package/commit/e8210eb963b1c69398ef35ba5d911d541281251d))

## [1.0.5](https://github.com/serafinovsky/cookiecutter-uv-package/compare/v1.0.4...v1.0.5) (2025-10-14)


### Bug Fixes

* rename package ([#12](https://github.com/serafinovsky/cookiecutter-uv-package/issues/12)) ([ca538f5](https://github.com/serafinovsky/cookiecutter-uv-package/commit/ca538f504f69fccf19f115479d2bbcdafa3b0026))

## [1.0.4](https://github.com/serafinovsky/cookiecutter-py-package/compare/v1.0.3...v1.0.4) (2025-10-14)


### Bug Fixes

* rename package ([#10](https://github.com/serafinovsky/cookiecutter-py-package/issues/10)) ([52efb93](https://github.com/serafinovsky/cookiecutter-py-package/commit/52efb93204034bcbea40ad8d7746ffa321dc3a76))

## [1.0.3](https://github.com/serafinovsky/cookiecutter-python-package/compare/v1.0.2...v1.0.3) (2025-10-14)


### Bug Fixes

* remove attestations and duplicate triggers from template publish workflow ([#8](https://github.com/serafinovsky/cookiecutter-python-package/issues/8)) ([06959b5](https://github.com/serafinovsky/cookiecutter-python-package/commit/06959b56933e85742945f397ef85e9558edad951))

## [1.0.2](https://github.com/serafinovsky/cookiecutter-python-package/compare/v1.0.1...v1.0.2) (2025-10-14)


### Bug Fixes

* remove attestations and duplicate trigger from publish workflow ([#6](https://github.com/serafinovsky/cookiecutter-python-package/issues/6)) ([18c1765](https://github.com/serafinovsky/cookiecutter-python-package/commit/18c17650535a487a39bca22769896efe01e068aa))

## [1.0.1](https://github.com/serafinovsky/cookiecutter-python-package/compare/v1.0.0...v1.0.1) (2025-10-14)


### Bug Fixes

* fixing publishing, dock and readme ([#4](https://github.com/serafinovsky/cookiecutter-python-package/issues/4)) ([5334b7f](https://github.com/serafinovsky/cookiecutter-python-package/commit/5334b7f5ff5e81baba223a7043ee283ccb3385da))

## [1.0.0](https://github.com/serafinovsky/cookiecutter-python-package/compare/v0.1.0...v1.0.0) (2025-10-14)


### ⚠ BREAKING CHANGES

* Correcting cookiecutter.json, setting up github, making python package

### Features

* update uv.lock on dependabot MR ([b22e9fd](https://github.com/serafinovsky/cookiecutter-python-package/commit/b22e9fd9116fc1e82629d0f23611d81d20c9e910))


### Bug Fixes

* Correcting cookiecutter.json, setting up github, making python package ([cb33172](https://github.com/serafinovsky/cookiecutter-python-package/commit/cb331725411ee052d8b838f8c9555df4cbc06eae))

## [0.1.0] - 2024-01-01

### Added

- Initial release of cookiecutter-python-package template
- Complete CI/CD setup with GitHub Actions
- Modern Python development tools (uv, Ruff, MyPy, Pytest)
- Automatic PyPI publishing support
- Release Please integration for version management

- Comprehensive documentation with MkDocs
