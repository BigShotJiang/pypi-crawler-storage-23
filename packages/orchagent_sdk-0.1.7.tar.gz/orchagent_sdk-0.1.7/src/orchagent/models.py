"""
Per-task model resolution for orchagent agents.

Reads ORCHAGENT_MODEL_* environment variables injected by the platform
at runtime.  These are configured via ``model_tasks`` in orchagent.json.

Usage::

    from orchagent import get_model

    # Uses the "default" model
    model = get_model()

    # Uses a specific task model (falls back to "default" if not found)
    model = get_model("code_editing")
"""

from __future__ import annotations

import os


def get_model(task: str = "default") -> str:
    """Return the model ID configured for *task*.

    Resolution order:

    1. ``ORCHAGENT_MODEL_{TASK_UPPERCASE}`` env var
    2. ``ORCHAGENT_MODEL_DEFAULT`` env var (fallback)

    Raises ``ValueError`` if neither the task-specific nor default env var
    is set — which means model_tasks was not configured in orchagent.json.
    """
    env_key = f"ORCHAGENT_MODEL_{task.upper()}"
    model = os.environ.get(env_key)
    if model:
        return model

    # Fall back to default
    if task != "default":
        default = os.environ.get("ORCHAGENT_MODEL_DEFAULT")
        if default:
            return default

    raise ValueError(
        f"No model configured for task '{task}'. "
        "Add model_tasks to orchagent.json with at least a 'default' entry."
    )
