"""Tests for orchagent.models — per-task model resolution (get_model)."""

import os
import pytest
from unittest.mock import patch

from orchagent.models import get_model


class TestGetModel:
    """Test get_model() env var resolution."""

    def test_default_task(self):
        with patch.dict(os.environ, {"ORCHAGENT_MODEL_DEFAULT": "claude-haiku-4-5-20251001"}):
            assert get_model() == "claude-haiku-4-5-20251001"

    def test_explicit_default(self):
        with patch.dict(os.environ, {"ORCHAGENT_MODEL_DEFAULT": "gpt-4o"}):
            assert get_model("default") == "gpt-4o"

    def test_named_task(self):
        with patch.dict(os.environ, {
            "ORCHAGENT_MODEL_DEFAULT": "claude-haiku-4-5-20251001",
            "ORCHAGENT_MODEL_CODE_EDITING": "claude-opus-4-6",
        }):
            assert get_model("code_editing") == "claude-opus-4-6"

    def test_fallback_to_default(self):
        """Unknown task name falls back to default model."""
        with patch.dict(os.environ, {
            "ORCHAGENT_MODEL_DEFAULT": "claude-haiku-4-5-20251001",
        }, clear=False):
            # Remove any existing ORCHAGENT_MODEL_BANANA
            env = os.environ.copy()
            env.pop("ORCHAGENT_MODEL_BANANA", None)
            env["ORCHAGENT_MODEL_DEFAULT"] = "claude-haiku-4-5-20251001"
            with patch.dict(os.environ, env, clear=True):
                assert get_model("banana") == "claude-haiku-4-5-20251001"

    def test_case_insensitive_task_name(self):
        """Task names are uppercased for env var lookup."""
        with patch.dict(os.environ, {
            "ORCHAGENT_MODEL_REASONING": "claude-sonnet-4-6",
            "ORCHAGENT_MODEL_DEFAULT": "claude-haiku-4-5-20251001",
        }):
            assert get_model("reasoning") == "claude-sonnet-4-6"
            assert get_model("REASONING") == "claude-sonnet-4-6"

    def test_raises_when_no_default(self):
        """Should raise ValueError when no default is configured."""
        env = {k: v for k, v in os.environ.items() if not k.startswith("ORCHAGENT_MODEL_")}
        with patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="No model configured"):
                get_model()

    def test_raises_for_unknown_task_no_default(self):
        """Should raise ValueError for unknown task when no default exists."""
        env = {k: v for k, v in os.environ.items() if not k.startswith("ORCHAGENT_MODEL_")}
        with patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="No model configured"):
                get_model("nonexistent")

    def test_multiple_tasks(self):
        with patch.dict(os.environ, {
            "ORCHAGENT_MODEL_DEFAULT": "claude-haiku-4-5-20251001",
            "ORCHAGENT_MODEL_CODE_EDITING": "claude-opus-4-6",
            "ORCHAGENT_MODEL_REASONING": "claude-sonnet-4-6",
            "ORCHAGENT_MODEL_IMAGE_GENERATION": "gemini-2.0-flash",
        }):
            assert get_model("default") == "claude-haiku-4-5-20251001"
            assert get_model("code_editing") == "claude-opus-4-6"
            assert get_model("reasoning") == "claude-sonnet-4-6"
            assert get_model("image_generation") == "gemini-2.0-flash"

    def test_cross_provider_models(self):
        """Model IDs from different providers should all work."""
        with patch.dict(os.environ, {
            "ORCHAGENT_MODEL_DEFAULT": "claude-haiku-4-5-20251001",
            "ORCHAGENT_MODEL_TRANSLATION": "gpt-4o",
            "ORCHAGENT_MODEL_IMAGE_GENERATION": "gemini-2.0-flash",
        }):
            assert get_model("default") == "claude-haiku-4-5-20251001"
            assert get_model("translation") == "gpt-4o"
            assert get_model("image_generation") == "gemini-2.0-flash"


class TestGetModelImport:
    """Test that get_model is importable from orchagent package."""

    def test_import_from_package(self):
        from orchagent import get_model as gm
        assert gm is get_model

    def test_in_all(self):
        import orchagent
        assert "get_model" in orchagent.__all__
