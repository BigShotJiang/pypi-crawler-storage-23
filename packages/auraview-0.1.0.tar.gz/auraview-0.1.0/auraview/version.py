"""
version.py

Author: Benevant Mathew
Date: 2026-02-19
"""
__version__ = "0.1.0"
__author__ = "Benevant Mathew"
__email__ = "benevantmathewv@gmail.com"
__release_date__="19-02-2026"

if __name__ == "__main__":
    print(__version__)
