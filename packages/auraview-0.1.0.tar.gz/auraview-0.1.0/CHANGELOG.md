# Changelog
## Version 0.1.0 - 19-02-2026
- Initial release
- Able to view photos.
- supports apple image extensions.
- Navigation supported.
- Image transform: Rotation possible.
- Rotations are considered inplace.
- Copy and Move functions available.
