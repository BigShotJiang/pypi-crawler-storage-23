"""deep_variance — GPU Virtual Memory Stitching SDK."""

from deep_variance.vmm import (
    vmm_empty as vmm_empty,
    vmm_empty_nd as vmm_empty_nd,
    set_cache_limit as set_cache_limit,
    cache_stats as cache_stats,
)
from deep_variance._env_check import (
    check_environment as check_environment,
    ensure_cuda_visible as ensure_cuda_visible,
)
from deep_variance._analytics import (
    enable_analytics as enable_analytics,
    disable_analytics as disable_analytics,
    is_analytics_enabled as is_analytics_enabled,
    analytics_summary as analytics_summary,
)

__version__: str
__all__: list[str]
