from __future__ import annotations

from typing import Any, Dict

def vmm_alloc_dlpack(
    numel: int,
    device_id: int,
    chunk_bytes: int,
    dtype_code: int,
    bits: int,
    lanes: int,
) -> Any:
    """Allocate a physically-stitched CUDA tensor and return a DLPack capsule."""
    ...

def set_cache_limit(
    device_id: int,
    chunk_bytes: int,
    max_bytes: int,
) -> None:
    """Set the physical memory cache limit for a given device/chunk-size pool."""
    ...

def cache_stats() -> Dict[str, Any]:
    """Return per-pool cache statistics (cached_bytes, num_chunks, etc.)."""
    ...
