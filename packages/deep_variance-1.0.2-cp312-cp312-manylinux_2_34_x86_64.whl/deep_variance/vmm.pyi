from __future__ import annotations

from typing import Tuple, Union

import torch

def vmm_empty(
    numel: int,
    dtype: torch.dtype = ...,
    device: Union[str, torch.device] = ...,
    chunk_bytes: int = ...,
) -> torch.Tensor: ...

def vmm_empty_nd(
    shape: Union[int, Tuple[int, ...]],
    dtype: torch.dtype = ...,
    device: Union[str, torch.device] = ...,
    chunk_bytes: int = ...,
) -> torch.Tensor: ...

def set_cache_limit(
    device_id: int = ...,
    chunk_bytes: int = ...,
    max_bytes: int = ...,
) -> None: ...

def cache_stats() -> dict: ...
