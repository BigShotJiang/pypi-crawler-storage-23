from __future__ import annotations

from enum import Enum
from typing import Any, Dict, Optional


class EventType(str, Enum):
    SESSION_START: str
    VMM_ALLOC: str
    SESSION_END: str


def _register_session() -> str: ...
def _track(event: EventType, data: Optional[Dict[str, Any]] = None) -> None: ...
def track_alloc(
    numel: int,
    device_id: int,
    dtype_str: str,
    bytes_allocated: int,
    success: bool,
) -> None: ...
def enable_analytics() -> None: ...
def disable_analytics() -> None: ...
def is_analytics_enabled() -> bool: ...
def analytics_summary() -> Dict[str, Any]: ...
