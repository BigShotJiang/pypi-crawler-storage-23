"""
Weight files from EvoEF2
"""

from __future__ import annotations

from typing import Dict, List, Optional

from neurosnap.algos.evoef2_lib.constants import MAX_EVOEF_ENERGY_TERM_NUM, WEIGHT_KEY_TO_INDEX

# Weights generated from weight_EvoEF2.txt
WEIGHTS_EVOEF2 = {
  "aapropensity": 0.59,
  "dunbrack": 0.35,
  "interD_deslvH": 4.79,
  "interD_deslvP": 0.68,
  "interD_electr": 2.44,
  "interD_hbbbbb_dis": 1.01,
  "interD_hbbbbb_phi": 1.02,
  "interD_hbbbbb_the": 1.01,
  "interD_hbscbb_dis": 0.94,
  "interD_hbscbb_phi": 0.32,
  "interD_hbscbb_the": 0.7,
  "interD_hbscsc_dis": 0.94,
  "interD_hbscsc_phi": 0.0,
  "interD_hbscsc_the": 0.97,
  "interD_ssbond": 1.07,
  "interD_vdwatt": 1.06,
  "interD_vdwrep": 0.8,
  "interS_deslvH": 4.59,
  "interS_deslvP": 0.75,
  "interS_electr": 2.31,
  "interS_hbbbbb_dis": 1.02,
  "interS_hbbbbb_phi": 1.07,
  "interS_hbbbbb_the": 1.01,
  "interS_hbscbb_dis": 0.85,
  "interS_hbscbb_phi": 0.17,
  "interS_hbscbb_the": 0.91,
  "interS_hbscsc_dis": 1.19,
  "interS_hbscsc_phi": 0.0,
  "interS_hbscsc_the": 0.71,
  "interS_ssbond": 2.72,
  "interS_vdwatt": 1.21,
  "interS_vdwrep": 1.28,
  "intraR_deslvH": 0.34,
  "intraR_deslvP": 0.0,
  "intraR_electr": 0.29,
  "intraR_hbscbb_dis": 0.83,
  "intraR_hbscbb_phi": 0.0,
  "intraR_hbscbb_the": 0.28,
  "intraR_vdwatt": 0.43,
  "intraR_vdwrep": 0.06,
  "ligand_deslvH": 1.0,
  "ligand_deslvP": 1.0,
  "ligand_electr": 1.0,
  "ligand_hbscbb_dis": 1.0,
  "ligand_hbscbb_phi": 1.0,
  "ligand_hbscbb_the": 1.0,
  "ligand_hbscsc_dis": 1.0,
  "ligand_hbscsc_phi": 1.0,
  "ligand_hbscsc_the": 1.0,
  "ligand_vdwatt": 1.0,
  "ligand_vdwrep": 1.0,
  "ramachandran": 0.42,
  "reference_ALA": -0.408,
  "reference_ARG": -1.322,
  "reference_ASN": -2.155,
  "reference_ASP": -0.802,
  "reference_CYS": -0.111,
  "reference_GLN": -1.936,
  "reference_GLU": -1.225,
  "reference_GLY": -2.093,
  "reference_HIS": -0.295,
  "reference_ILE": 2.33,
  "reference_LEU": 1.613,
  "reference_LYS": -1.25,
  "reference_MET": 0.759,
  "reference_PHE": 0.679,
  "reference_PRO": -0.647,
  "reference_SER": -1.978,
  "reference_THR": -0.416,
  "reference_TRP": 2.004,
  "reference_TYR": 0.7,
  "reference_VAL": 1.7,
}

# Weights generated from weight_EvoEF.txt
WEIGHTS_EVOEF = {
  "aapropensity": 0.0,
  "dunbrack": 0.0,
  "interD_deslvH": 0.34,
  "interD_deslvP": 0.4,
  "interD_electr": 0.0,
  "interD_hbbbbb_dis": 0.0,
  "interD_hbbbbb_phi": 0.5,
  "interD_hbbbbb_the": 0.76,
  "interD_hbscbb_dis": 0.0,
  "interD_hbscbb_phi": 0.52,
  "interD_hbscbb_the": 0.66,
  "interD_hbscsc_dis": 0.72,
  "interD_hbscsc_phi": 0.5,
  "interD_hbscsc_the": 0.67,
  "interD_ssbond": 0.0,
  "interD_vdwatt": 0.64,
  "interD_vdwrep": 0.79,
  "interS_deslvH": 0.03,
  "interS_deslvP": 0.3,
  "interS_electr": 0.0,
  "interS_hbbbbb_dis": 0.36,
  "interS_hbbbbb_phi": 0.0,
  "interS_hbbbbb_the": 0.0,
  "interS_hbscbb_dis": 0.55,
  "interS_hbscbb_phi": 0.16,
  "interS_hbscbb_the": 0.21,
  "interS_hbscsc_dis": 0.3,
  "interS_hbscsc_phi": 0.0,
  "interS_hbscsc_the": 0.08,
  "interS_ssbond": 0.0,
  "interS_vdwatt": 0.61,
  "interS_vdwrep": 0.5,
  "intraR_deslvH": 0.0,
  "intraR_deslvP": 0.0,
  "intraR_electr": 0.0,
  "intraR_hbscbb_dis": 0.0,
  "intraR_hbscbb_phi": 0.0,
  "intraR_hbscbb_the": 0.04,
  "intraR_vdwatt": 0.0,
  "intraR_vdwrep": 0.12,
  "ligand_deslvH": 1.0,
  "ligand_deslvP": 1.0,
  "ligand_electr": 1.0,
  "ligand_hbscbb_dis": 1.0,
  "ligand_hbscbb_phi": 1.0,
  "ligand_hbscbb_the": 1.0,
  "ligand_hbscsc_dis": 1.0,
  "ligand_hbscsc_phi": 1.0,
  "ligand_hbscsc_the": 1.0,
  "ligand_vdwatt": 1.0,
  "ligand_vdwrep": 1.0,
  "ramachandran": 0.0,
  "reference_ALA": 1.2,
  "reference_ARG": 0.72,
  "reference_ASN": 1.0,
  "reference_ASP": 1.2,
  "reference_CYS": 0.6,
  "reference_GLN": 1.4,
  "reference_GLU": 1.0,
  "reference_GLY": 2.0,
  "reference_HIS": 2.2,
  "reference_ILE": -0.12,
  "reference_LEU": 0.0,
  "reference_LYS": 1.2,
  "reference_MET": 1.0,
  "reference_PHE": 2.0,
  "reference_PRO": 0.96,
  "reference_SER": 1.2,
  "reference_THR": 0.8,
  "reference_TRP": 2.6,
  "reference_TYR": 1.6,
  "reference_VAL": 0.24,
}


def get_weights(weight_dict: Optional[Dict[str, float]] = None) -> List[float]:
  """Get the vectorized EvoEF2 term weights from the reference dictionary file.

  Args:
    weight_dict: Weights dictionary to use.

  Returns:
    Weight list indexed by EvoEF2 term index.
  """
  if weight_dict is None:
    weight_dict = WEIGHTS_EVOEF2

  weights = [1.0] * MAX_EVOEF_ENERGY_TERM_NUM
  for term, val in weight_dict.items():
    if term in WEIGHT_KEY_TO_INDEX:
      weights[WEIGHT_KEY_TO_INDEX[term]] = float(val)
  return weights
