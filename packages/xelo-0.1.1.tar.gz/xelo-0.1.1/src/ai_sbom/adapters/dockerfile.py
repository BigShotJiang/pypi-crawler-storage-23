"""Dockerfile adapter — extracts CONTAINER_IMAGE nodes from Dockerfile* files.

Parses every ``FROM`` instruction and emits one ``ComponentDetection`` per
unique base image reference.  Multi-stage builds produce one node per stage
image (scratch stages are skipped).

Supported syntaxes
------------------
    FROM <image>
    FROM <image>:<tag>
    FROM <image>@sha256:<digest>
    FROM <image>:<tag>@sha256:<digest>
    FROM [--platform=<platform>] <image>[:<tag>][@<digest>] [AS <alias>]
    FROM registry.example.com/org/image:1.2.3

Evidence kind: ``"dockerfile"``
"""
from __future__ import annotations

import logging
import re
from typing import Any

from ai_sbom.adapters.base import ComponentDetection
from ai_sbom.types import ComponentType

_log = logging.getLogger(__name__)

# Matches a FROM instruction (case-insensitive, handles --platform flag and AS alias)
_FROM_RE = re.compile(
    r"^\s*FROM\s+"
    r"(?:--platform=\S+\s+)?"   # optional --platform=...
    r"(?P<ref>[^\s#]+)"          # the image reference (no whitespace, no comment)
    r"(?:\s+AS\s+\S+)?",         # optional AS <alias>
    re.IGNORECASE | re.MULTILINE,
)

# Splits an image reference into registry + name + tag + digest
# Examples:
#   python:3.12-slim               → name=python  tag=3.12-slim  digest=None
#   gcr.io/myproj/app:latest       → registry=gcr.io name=myproj/app tag=latest
#   ubuntu@sha256:abc123           → name=ubuntu   digest=sha256:abc123
#   registry/img:tag@sha256:abc    → name=registry/img tag=tag digest=sha256:abc
_REF_RE = re.compile(
    r"^"
    r"(?:(?P<registry>[a-zA-Z0-9._\-]+\.[a-zA-Z]{2,}(?::[0-9]+)?)/)?"  # optional registry
    r"(?P<name>[^:@\s]+)"                                                # image name / path
    r"(?::(?P<tag>[^@\s]+))?"                                            # optional :tag
    r"(?:@(?P<digest>sha256:[a-f0-9]{7,}))?"                             # optional @sha256:…
    r"$",
)


def _parse_image_ref(ref: str) -> dict[str, str | None]:
    """Break *ref* into registry, name, tag, digest components."""
    m = _REF_RE.match(ref.strip())
    if not m:
        return {"registry": None, "name": ref, "tag": None, "digest": None}
    return {
        "registry": m.group("registry"),
        "name":     m.group("name"),
        "tag":      m.group("tag"),
        "digest":   m.group("digest"),
    }


class DockerfileAdapter:
    """Scans Dockerfile content and emits CONTAINER_IMAGE component detections.

    Unlike ``FrameworkAdapter``, this class is not AST-aware and is invoked
    directly by the extractor for files named ``Dockerfile`` or ``*.dockerfile``.
    """

    name     = "dockerfile"
    priority = 5  # high priority — Dockerfiles are ground truth for container images

    def scan(self, content: str, file_path: str) -> list[ComponentDetection]:
        """Return one ``ComponentDetection`` per unique base image in *content*."""
        detections: list[ComponentDetection] = []
        seen: set[str] = set()

        for match in _FROM_RE.finditer(content):
            ref = match.group("ref").strip()
            if ref.lower() == "scratch":
                _log.debug("%s: skipping FROM scratch", file_path)
                continue

            line = content[: match.start()].count("\n") + 1
            canonical = f"container_image:{ref.lower()}"

            if canonical in seen:
                continue
            seen.add(canonical)

            parts = _parse_image_ref(ref)
            name  = parts["name"] or ref
            tag   = parts["tag"]
            digest = parts["digest"]
            registry = parts["registry"]

            # Build a compact display name
            display = name
            if tag:
                display = f"{name}:{tag}"
            elif not digest:
                display = f"{name}:latest"

            metadata: dict[str, Any] = {
                "base_image": ref,
                "image_name": name,
                "image_tag":  tag or ("" if digest else "latest"),
                "image_digest": digest,
                "registry":  registry or "docker.io",
                "dockerfile": file_path,
            }

            _log.debug(
                "%s:%d — detected container image: %s (tag=%s digest=%s registry=%s)",
                file_path, line, name, tag, digest, registry,
            )

            detections.append(
                ComponentDetection(
                    component_type=ComponentType.CONTAINER_IMAGE,
                    canonical_name=canonical,
                    display_name=display,
                    adapter_name=self.name,
                    priority=self.priority,
                    confidence=0.99,  # FROM is authoritative — no ambiguity
                    metadata=metadata,
                    file_path=file_path,
                    line=line,
                    snippet=match.group(0).strip()[:120],
                    evidence_kind="dockerfile",
                )
            )

        _log.info(
            "dockerfile adapter: %d unique image(s) found in %s",
            len(detections), file_path,
        )
        return detections
