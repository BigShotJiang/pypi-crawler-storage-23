"""TypeScript/JavaScript Framework Adapters for Xelo SBOM.

Supports detection of AI frameworks in TypeScript and JavaScript code:
- LangGraph.js / LangChain.js
- OpenAI Agents SDK
- Google ADK (Genkit)
- Common LLM clients (OpenAI, Anthropic, Google AI, Cohere, Mistral, Groq)
- Prompt detection and analysis
- Datastore detection (SQL, Vector DBs, Object Storage)
- AWS Bedrock Agents
"""

from ai_sbom.adapters.typescript.bedrock_agents import BedrockAgentsTSAdapter
from ai_sbom.adapters.typescript.datastores import DatastoreTSAdapter
from ai_sbom.adapters.typescript.google_adk import GoogleADKAdapter
from ai_sbom.adapters.typescript.langgraph import LangGraphTSAdapter
from ai_sbom.adapters.typescript.llm_clients import LLMClientTSAdapter
from ai_sbom.adapters.typescript.openai_agents import OpenAIAgentsTSAdapter
from ai_sbom.adapters.typescript.prompts import PromptTSAdapter

__all__ = [
    "BedrockAgentsTSAdapter",
    "DatastoreTSAdapter",
    "GoogleADKAdapter",
    "LangGraphTSAdapter",
    "LLMClientTSAdapter",
    "OpenAIAgentsTSAdapter",
    "PromptTSAdapter",
]
