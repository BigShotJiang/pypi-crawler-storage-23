## Benchmark

Benchmark between `primp` and other python http clients:

- aiohttp
- curl_cffi
- httpx
- primp
- pycurl
- requests

Server response is gzipped.

#### Run benchmark:
    
    python run.py
