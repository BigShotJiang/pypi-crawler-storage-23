"""Re-exports from gds.verification.findings for backwards compatibility.

The OGS VerificationReport uses 'pattern_name' while GDS uses 'system_name'.
We provide a thin wrapper for backwards compatibility.
"""

from gds.verification.findings import Finding, Severity  # noqa: F401
from gds.verification.findings import VerificationReport as _GDSVerificationReport

from pydantic import Field


class VerificationReport(_GDSVerificationReport):
    """OGS-compatible verification report with pattern_name alias."""

    pattern_name: str = ""

    def __init__(self, **data):
        # Map pattern_name to system_name for GDS base
        if "pattern_name" in data and "system_name" not in data:
            data["system_name"] = data["pattern_name"]
        super().__init__(**data)

    @property
    def pattern_name_compat(self) -> str:
        return self.system_name


__all__ = ["Finding", "Severity", "VerificationReport"]
