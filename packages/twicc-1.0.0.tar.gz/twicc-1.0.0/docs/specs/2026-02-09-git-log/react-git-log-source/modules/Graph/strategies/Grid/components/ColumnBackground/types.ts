export interface ColumnBackgroundProps {
  id: string
  index: number
  colour: string
  commitNodeIndex: number
}