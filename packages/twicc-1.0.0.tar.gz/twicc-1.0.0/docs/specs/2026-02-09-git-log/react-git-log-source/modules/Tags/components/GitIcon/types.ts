export interface GitIconProps {
  className?: string
}