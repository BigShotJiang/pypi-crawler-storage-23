export interface LeftDownCurveProps {
  color: string
  showBottomBreakPoint?: boolean
  isPlaceholder?: boolean
}