export interface HeadCommitVerticalLineProps {
  columnColour: string
}