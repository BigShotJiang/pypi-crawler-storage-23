export interface IndexPseudoCommitNodeProps {
  columnColour: string
  animate: boolean
}