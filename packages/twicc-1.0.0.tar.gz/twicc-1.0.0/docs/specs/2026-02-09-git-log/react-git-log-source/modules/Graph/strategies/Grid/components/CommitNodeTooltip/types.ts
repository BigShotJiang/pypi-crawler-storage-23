import { Commit } from 'types/Commit'

export interface CommitNodeTooltipProps {
  commit: Commit
  color?: string
}