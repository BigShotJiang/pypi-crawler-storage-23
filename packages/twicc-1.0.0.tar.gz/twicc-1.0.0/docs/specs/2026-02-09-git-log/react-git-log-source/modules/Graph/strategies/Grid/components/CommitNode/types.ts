import { Commit } from 'types/Commit'

export interface CommitNodeProps {
  colour: string
  commit: Commit
}