from twicc.cli import main

__all__ = ["main"]
