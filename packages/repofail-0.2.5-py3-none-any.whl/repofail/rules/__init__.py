"""Five high-confidence incompatibility rules. No YAML. No plugins."""

from .base import RuleResult, Severity

__all__ = ["RuleResult", "Severity"]
