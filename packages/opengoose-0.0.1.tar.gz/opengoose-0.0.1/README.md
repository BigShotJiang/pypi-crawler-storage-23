OpenGoose placeholder package.

This package name is reserved for the OpenGoose project.
