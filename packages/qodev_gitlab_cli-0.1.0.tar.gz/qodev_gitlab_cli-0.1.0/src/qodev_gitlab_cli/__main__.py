"""Allow running as `python -m qodev_gitlab_cli`."""

from qodev_gitlab_cli.app import main

main()
