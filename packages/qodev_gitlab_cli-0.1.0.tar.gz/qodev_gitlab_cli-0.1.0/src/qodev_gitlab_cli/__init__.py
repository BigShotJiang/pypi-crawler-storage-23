"""GitLab CLI — agent-friendly CLI for the GitLab API."""
