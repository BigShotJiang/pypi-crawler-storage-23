"""Command groups for the GitLab CLI."""
