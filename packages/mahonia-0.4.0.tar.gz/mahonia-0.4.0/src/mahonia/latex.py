# Copyright (c) 2025 JP Hutchins
# SPDX-License-Identifier: MIT

"""LaTeX serialization for mahonia expressions.

This module provides functionality to convert mahonia expressions to LaTeX
mathematical notation.

>>> from typing import NamedTuple
>>> class Ctx(NamedTuple):
...     x: int
...     y: int
>>> from mahonia import Var, Const
>>> x = Var[int, Ctx]("x")
>>> y = Var[int, Ctx]("y")
>>> expr = x + y * 2
>>> latex(expr)
'x + y \\\\cdot 2'
>>> latex(x > 5)
'x > 5'
"""

from enum import Flag, auto
from typing import Any, Final, Generic, NamedTuple, assert_never

from mahonia import (
	Abs,
	Add,
	AllExpr,
	And,
	AnyExpr,
	Approximately,
	ClampExpr,
	Const,
	Contains,
	Div,
	Eq,
	Expr,
	FilterExpr,
	Func,
	Ge,
	Gt,
	Le,
	Lt,
	Mul,
	Ne,
	Neg,
	Not,
	Or,
	Percent,
	PlusMinus,
	Pow,
	Predicate,
	S,
	Sub,
	Var,
	format_iterable_var,
)
from mahonia.match import MatchExpr
from mahonia.stats import Count, Mean, Median, Percentile, Range, StdDev

type BinaryOpExpr = (
	Eq[Any, Any]
	| Ne[Any, Any]
	| Lt[Any, Any]
	| Le[Any, Any]
	| Gt[Any, Any]
	| Ge[Any, Any]
	| And[Any, Any]
	| Or[Any, Any]
)


class Show(Flag):
	"""Display options for latex evaluation.

	Assuming that x is 2 and y is 3:
	- (none): `x + y`
	- VALUES: `x:2 + y:3`
	- WORK: `(x + y \\rightarrow 5)`
	- VALUES | WORK: `(x:2 + y:3 \\rightarrow 5)`

	Examples:
	>>> from typing import NamedTuple
	>>> class TestCtx(NamedTuple):
	...     x: int
	...     y: int
	>>> x = Var[int, TestCtx]("x")
	>>> y = Var[int, TestCtx]("y")
	>>> test_ctx = TestCtx(x=2, y=3)
	>>> expr = x + y
	>>> latex(expr, LatexCtx(test_ctx, Show.VALUES))
	'(x:2 + y:3 \\\\rightarrow 5)'
	>>> latex(expr, LatexCtx(test_ctx, Show.WORK))
	'(x + y \\\\rightarrow 5)'
	>>> latex(expr, LatexCtx(test_ctx, Show.VALUES | Show.WORK))
	'(x:2 + y:3 \\\\rightarrow 5)'
	"""

	VALUES = auto()
	"""Add values to variables: `name:<val>."""
	WORK = auto()
	"""Show the evaluated result of the expression."""


class LatexCtx(NamedTuple, Generic[S]):
	ctx: S
	show: Show = Show.VALUES | Show.WORK


def latex(expr: Expr[Any, S, Any] | Func[Any, S], ctx: LatexCtx[S] | None = None) -> str:
	"""Convert a mahonia expression to LaTeX mathematical notation.

	Examples:
	>>> from typing import NamedTuple
	>>> class TestCtx(NamedTuple):
	...     x: float
	...     y: float
	>>> x = Var[float, TestCtx]("x")
	>>> y = Var[float, TestCtx]("y")
	>>> latex(x + y)
	'x + y'
	>>> latex(x * y)
	'x \\\\cdot y'
	>>> latex(x / y)
	'\\\\frac{x}{y}'
	>>> latex(x**2 + y**2)
	'x^2 + y^2'
	>>> # With context - default shows values and work
	>>> test_ctx = TestCtx(x=2.0, y=3.0)
	>>> latex(x + y, LatexCtx(test_ctx))
	'(x:2.0 + y:3.0 \\\\rightarrow 5.0)'
	>>> # Show only values
	>>> latex(x + y, LatexCtx(test_ctx, Show.VALUES))
	'(x:2.0 + y:3.0 \\\\rightarrow 5.0)'
	>>> # Show only work
	>>> latex(x + y, LatexCtx(test_ctx, Show.WORK))
	'(x + y \\\\rightarrow 5.0)'
	>>> # Show nothing (structure only)
	>>> latex(x + y, LatexCtx(test_ctx, Show(0)))
	'(x + y \\\\rightarrow 5.0)'
	>>> # Boolean expressions
	>>> latex(x > y, LatexCtx(test_ctx, Show.VALUES | Show.WORK))
	'(x:2.0 > y:3.0 \\\\rightarrow \\\\text{False})'
	>>> # Complex expressions
	>>> latex((x + y) / 2, LatexCtx(test_ctx, Show.VALUES))
	'(\\\\frac{x:2.0 + y:3.0}{2} \\\\rightarrow 2.5)'
	"""
	if isinstance(expr, Func):
		return _latex_func(expr, ctx)

	match ctx:
		case None:
			return _latex_expr_structure(expr)
		case LatexCtx(ctx_data, show) if show & Show.WORK:
			structure = _latex_expr_structure(expr, ctx)
			return (
				structure
				if "\\rightarrow" in structure
				else _format_with_result(structure, expr.eval(ctx_data))
			)
		case LatexCtx(ctx_data, _):
			return _format_with_result(_latex_expr_structure(expr, ctx), expr.eval(ctx_data))
		case _:
			assert_never(ctx)


def _latex_func(func: Func[Any, Any], latex_ctx: LatexCtx[Any] | None = None) -> str:
	"""Convert a Func to LaTeX lambda calculus notation."""
	expr_latex = _latex_expr_structure(func.expr, latex_ctx)

	if len(func.args) == 0:
		return f"\\lambda.{expr_latex}"
	elif len(func.args) == 1:
		arg_latex = _latex_expr_structure(func.args[0], latex_ctx)
		return f"\\lambda {arg_latex}.{expr_latex}"
	else:
		args_latex = ",".join(_latex_expr_structure(arg, latex_ctx) for arg in func.args)
		return f"\\lambda {args_latex}.{expr_latex}"


def _latex_value(value: Any) -> str:
	"""Convert a value to LaTeX format."""
	if isinstance(value, bool):
		return f"\\text{{{str(value)}}}"
	return str(value)


def _format_with_result(structure: str, result: Const[Any]) -> str:
	"""Format structure with result arrow notation."""
	result_latex = (
		_latex_expr_structure(result)  # pyright: ignore[reportUnknownArgumentType]
		if isinstance(result, (PlusMinus, Percent))
		else _latex_value(result.value)
	)
	return f"({structure} \\rightarrow {result_latex})"


def _latex_expr_structure(expr: Expr[Any, Any, Any], latex_ctx: LatexCtx[Any] | None = None) -> str:
	"""Convert expression structure to LaTeX, optionally showing variable values."""
	match expr:
		case Var(name=name):
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.VALUES:
					evaluated = expr.eval(ctx)
					return f"{_latex_var(name)}:{evaluated.value}"
				case _:
					return _latex_var(name)
		case PlusMinus(name=name, value=value, plus_minus=pm):  # pyright: ignore[reportUnknownVariableType]
			return f"{_latex_var(name) if name else str(value)} \\pm {pm}"  # pyright: ignore[reportUnknownArgumentType]
		case Percent(name=name, value=value, percent=pct):  # pyright: ignore[reportUnknownVariableType]
			return f"{_latex_var(name) if name else str(value)} \\pm {pct}\\%"  # pyright: ignore[reportUnknownArgumentType]
		case Const(name=name, value=value) if name:
			match latex_ctx:
				case LatexCtx(_, show) if show & Show.VALUES:
					return f"{_latex_var(name)}:{value}"
				case _:
					return _latex_var(name)
		case Const(value=value):
			return _latex_value(value)
		case Add():
			left = _latex_expr_structure(expr.left, latex_ctx)
			right = _latex_expr_structure(expr.right, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({left} + {right} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"{left} + {right}"
		case Sub():
			left = _latex_expr_structure(expr.left, latex_ctx)
			right = _latex_expr_structure(expr.right, latex_ctx)
			right_formatted = f"({right})" if _needs_parentheses(expr.right, expr) else right
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({left} - {right_formatted} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"{left} - {right_formatted}"
		case Mul():
			left = _latex_expr_structure(expr.left, latex_ctx)
			right = _latex_expr_structure(expr.right, latex_ctx)
			left_formatted = f"({left})" if _needs_parentheses(expr.left, expr) else left
			right_formatted = f"({right})" if _needs_parentheses(expr.right, expr) else right
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({left_formatted} \\cdot {right_formatted} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"{left_formatted} \\cdot {right_formatted}"
		case Div():
			left = _latex_expr_structure(expr.left, latex_ctx)
			right = _latex_expr_structure(expr.right, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\frac{{{left}}}{{{right}}} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\frac{{{left}}}{{{right}}}"
		case Pow():
			base = _latex_expr_structure(expr.left, latex_ctx)
			power = _latex_expr_structure(expr.right, latex_ctx)
			formatted_base = f"({base})" if _needs_parentheses(expr.left, expr) else base
			power_formatted = (
				f"{formatted_base}^{{{power}}}"
				if len(power) > 1 or not power.isdigit()
				else f"{formatted_base}^{power}"
			)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({power_formatted} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return power_formatted
		case Eq() | Ne() | Lt() | Le() | Gt() | Ge() | And() | Or() as binary_op:
			left = _latex_expr_structure(binary_op.left, latex_ctx)
			right = _latex_expr_structure(binary_op.right, latex_ctx)
			expr_str = f"{left} {LATEX_OP[type(binary_op)]} {right}"
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({expr_str} \\rightarrow {_latex_value(binary_op.eval(ctx).value)})"
				case _:
					return expr_str
		case Not():
			operand = _latex_expr_structure(expr.left, latex_ctx)
			operand_formatted = f"({operand})" if _needs_parentheses(expr.left, expr) else operand
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\neg {operand_formatted} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\neg {operand_formatted}"
		case Approximately():
			left = _latex_expr_structure(expr.left, latex_ctx)
			right = _latex_expr_structure(expr.right, latex_ctx)
			expr_str = f"{left} \\approx {right}"
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({expr_str} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return expr_str
		case Predicate(name=name, expr=pred_expr):
			expr_latex = _latex_expr_structure(pred_expr, latex_ctx)
			pred_str = f"\\text{{{name}}}: {expr_latex}" if name else expr_latex
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({pred_str} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return pred_str
		case Mean():
			operand_formatted = _format_statistical_operand(expr, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\bar{{{operand_formatted}}} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\bar{{{operand_formatted}}}"
		case StdDev():
			operand_formatted = _format_statistical_operand(expr, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\sigma_{{{operand_formatted}}} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\sigma_{{{operand_formatted}}}"
		case Median():
			operand_formatted = _format_statistical_operand(expr, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\text{{median}}({operand_formatted}) \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\text{{median}}({operand_formatted})"
		case Percentile():
			operand_formatted = _format_statistical_operand(expr, latex_ctx)
			percentile_str = (
				f"P_{{{int(expr.percentile) if expr.percentile.is_integer() else expr.percentile}}}"
			)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({percentile_str}({operand_formatted}) \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"{percentile_str}({operand_formatted})"
		case Range():
			operand_formatted = _format_statistical_operand(expr, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\text{{range}}({operand_formatted}) \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\text{{range}}({operand_formatted})"
		case Count():
			operand_formatted = _format_statistical_operand(expr, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return (
						f"(|{operand_formatted}| \\rightarrow {_latex_value(expr.eval(ctx).value)})"
					)
				case _:
					return f"|{operand_formatted}|"
		case Contains():
			element_formatted = _latex_expr_structure(expr.element, latex_ctx)  # pyright: ignore[reportUnknownMemberType, reportUnknownArgumentType]
			container_formatted = _latex_expr_structure(expr.container, latex_ctx)  # pyright: ignore[reportUnknownMemberType, reportUnknownArgumentType]
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"({element_formatted} \\in {container_formatted} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"{element_formatted} \\in {container_formatted}"
		case AnyExpr():
			operand_formatted = _format_statistical_operand(expr, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\exists x \\in {operand_formatted}: x \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\exists x \\in {operand_formatted}: x"
		case AllExpr():
			operand_formatted = _format_statistical_operand(expr, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\forall x \\in {operand_formatted}: x \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\forall x \\in {operand_formatted}: x"
		case FilterExpr():
			container = _latex_expr_structure(expr.container, latex_ctx)  # pyright: ignore[reportUnknownMemberType, reportUnknownArgumentType]
			pred = _latex_func(expr.predicate, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					result_value = expr.eval(ctx).value  # pyright: ignore[reportUnknownVariableType, reportUnknownMemberType]
					return f"(\\{{ x \\in {container} : {pred} \\}} \\rightarrow {_latex_value(len(result_value))} \\text{{ elements}})"  # pyright: ignore[reportUnknownArgumentType]
				case _:
					return f"\\{{ x \\in {container} : {pred} \\}}"
		case MatchExpr():
			branches_latex = " \\\\ ".join(
				f"{_latex_expr_structure(val, latex_ctx)} & \\text{{if }} {_latex_expr_structure(cond, latex_ctx)}"
				for cond, val in expr.branches  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
			)
			default_latex = _latex_expr_structure(expr.default, latex_ctx)  # pyright: ignore[reportUnknownMemberType, reportUnknownArgumentType]
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\begin{{cases}} {branches_latex} \\\\ {default_latex} & \\text{{otherwise}} \\end{{cases}} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\begin{{cases}} {branches_latex} \\\\ {default_latex} & \\text{{otherwise}} \\end{{cases}}"
		case Neg():
			operand = _latex_expr_structure(expr.left, latex_ctx)
			operand_formatted = f"({operand})" if _needs_parentheses(expr.left, expr) else operand
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return (
						f"(-{operand_formatted} \\rightarrow {_latex_value(expr.eval(ctx).value)})"
					)
				case _:
					return f"-{operand_formatted}"
		case Abs():
			operand = _latex_expr_structure(expr.left, latex_ctx)
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\left|{operand}\\right| \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\left|{operand}\\right|"
		case ClampExpr():
			operand = _latex_expr_structure(expr.value, latex_ctx)  # pyright: ignore[reportUnknownMemberType, reportUnknownArgumentType]
			lo = expr.lo  # pyright: ignore[reportUnknownMemberType]
			hi = expr.hi  # pyright: ignore[reportUnknownMemberType]
			match latex_ctx:
				case LatexCtx(ctx, show) if show & Show.WORK:
					return f"(\\text{{clamp}}_{{{lo}}}^{{{hi}}}({operand}) \\rightarrow {_latex_value(expr.eval(ctx).value)})"
				case _:
					return f"\\text{{clamp}}_{{{lo}}}^{{{hi}}}({operand})"
		case _:
			return f"\\text{{Unknown: {type(expr).__name__}}}"


LATEX_OP: Final[dict[type[BinaryOpExpr], str]] = {
	Eq: "=",
	Ne: "\\neq",
	Lt: "<",
	Le: "\\leq",
	Gt: ">",
	Ge: "\\geq",
	And: "\\land",
	Or: "\\lor",
}


def _latex_var(name: str) -> str:
	"""Convert a variable name to LaTeX format.

	Handles subscripts and Greek letters.
	"""
	# Handle subscripts (e.g., x_1 -> x_1, x_max -> x_{max})
	if "_" in name:
		parts = name.split("_", 1)
		base, subscript = parts
		return f"{base}_{subscript}" if len(subscript) == 1 else f"{base}_{{{subscript}}}"

	# Common Greek letters
	return {
		"alpha": "\\alpha",
		"beta": "\\beta",
		"gamma": "\\gamma",
		"delta": "\\delta",
		"epsilon": "\\epsilon",
		"zeta": "\\zeta",
		"eta": "\\eta",
		"theta": "\\theta",
		"iota": "\\iota",
		"kappa": "\\kappa",
		"lambda": "\\lambda",
		"mu": "\\mu",
		"nu": "\\nu",
		"xi": "\\xi",
		"pi": "\\pi",
		"rho": "\\rho",
		"sigma": "\\sigma",
		"tau": "\\tau",
		"upsilon": "\\upsilon",
		"phi": "\\phi",
		"chi": "\\chi",
		"psi": "\\psi",
		"omega": "\\omega",
	}.get(name.lower(), name)


PRECEDENCE: Final[dict[type[Expr[Any, Any, Any]], int]] = {
	Or: 1,
	And: 2,
	Not: 3,
	Eq: 4,
	Ne: 4,
	Lt: 4,
	Le: 4,
	Gt: 4,
	Ge: 4,
	Approximately: 4,
	Add: 5,
	Sub: 5,
	Mul: 6,
	Div: 6,
	Pow: 7,
	Mean: 8,
	StdDev: 8,
	Median: 8,
	Percentile: 8,
	Range: 8,
	Count: 8,
}


def _needs_parentheses(operand: Expr[Any, Any, Any], parent: Expr[Any, Any, Any]) -> bool:
	"""Determine if an operand needs parentheses in the context of its parent operation."""

	if isinstance(
		operand, (Var, Const, PlusMinus, Percent, Mean, StdDev, Median, Percentile, Range, Count)
	):
		return False

	if PRECEDENCE[type(operand)] < PRECEDENCE[type(parent)]:
		return True

	# Special cases for subtraction and division (right-associative concerns)
	if isinstance(parent, Sub) and operand is parent.right:
		if isinstance(operand, (Add, Sub)):
			return True

	if isinstance(parent, Div) and operand is parent.right:
		if isinstance(operand, (Mul, Div)):
			return True

	return False


def _format_statistical_operand(
	stat_expr: Expr[Any, Any, Any], latex_ctx: LatexCtx[Any] | None
) -> str:
	match latex_ctx:
		case LatexCtx(ctx, show) if show & Show.VALUES:
			if hasattr(stat_expr, "left"):
				left_expr = getattr(stat_expr, "left")
				formatted = format_iterable_var(left_expr, ctx)
				if ":" in formatted:
					var_name, rest = formatted.split(":", 1)
					return f"{_latex_var(var_name)}:{rest}"
				return _latex_var(formatted)
			return "data"
		case _:
			if hasattr(stat_expr, "left"):
				left_expr = getattr(stat_expr, "left")
				if hasattr(left_expr, "name"):
					return _latex_var(getattr(left_expr, "name"))
			return "data"
