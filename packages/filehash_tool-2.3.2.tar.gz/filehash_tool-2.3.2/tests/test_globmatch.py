import os
import re
import sys
import unittest
from functools import partial, lru_cache

PATH = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.dirname(PATH)
PATH = os.path.join(PATH, 'filehash_tool')
sys.path.append(PATH)
try:
    from globmatch import globmatch
except ImportError:
    from filehash_tool.filehash import globmatch

@lru_cache(maxsize=None)
def generate_combinations(n):
    if n == 0:
        return ['']

    # 递归生成长度为n-1的所有组合
    smaller_combinations = generate_combinations(n - 1)

    # 在每个组合前添加'a'和'b'
    result = []
    for combo in smaller_combinations:
        result.append(combo + '/')
        result.append(combo + '\\')
    return result

class TestGlobMatch(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.count = 0

    @classmethod
    def tearDownClass(cls):
        print(f'共测试了{cls.count}次')

    def _t(self, path, pattern, should_match=True):
        TestGlobMatch.count += 1
        try:
            ret = globmatch(path, pattern,
                            case_sensitive=False, cross_fs=True)
        except:
            print(path, pattern, should_match, flush=True)
            raise
        else:
            if ret != should_match:
                msg = 'Should match:' if should_match else 'Should not match:'
                raise AssertionError(f'\n{msg}\n{path}\n{pattern}')

    def _sep(self, pattern):
        if isinstance(pattern, bytes):
            sep_pat = rb'[/\\]'
            repl_lbd = lambda c: c.encode('ISO-8859-1')
        else:
            sep_pat = r'[/\\]'
            repl_lbd = lambda c: c

        n = len(re.findall(sep_pat, pattern))

        def get_repl(comb):
            count = 0
            def repl(m):
                nonlocal count
                ret = comb[count]
                count += 1
                return repl_lbd(ret)
            return repl

        ret = []
        combs = generate_combinations(n)
        for comb in combs:
            repl = get_repl(comb)
            s = re.sub(sep_pat, repl, pattern)
            ret.append(s)
        return ret

    def _combine(self, path, pattern, should_match=True):
        #t1 = TestGlobMatch.count
        for p in self._sep(pattern):
            self._t(path, p, should_match)
        #t2 = TestGlobMatch.count - t1
        #print(f'测试了{t2}次：\n{path}\n{pattern}')

    def test_windows_path(self):
        PATH = r'E:\software\driver\gpu\gfx_win_101.7084.exe'
        t = partial(self._combine, PATH)
        t(r'*driver*')
        t(r'*DRIVER*')

        t(r'driver', False)
        t(r'/driver/', False)

        t(r'*/driver/*')
        t(r'*/driver/**/*')
        t(r'*/driver/**/**')
        t(r'*/software/**/gpu/**/*.*')
        t(r'*/software/**/gpu/**/*.exe')
        t(r'*/software/**/gpu/**/.exe', False)
        t(r'*/driver/**/gpu/**/*.*')
        t(r'*/driver/**/gpu/**/*.exe')
        t(r'*/driver/**/**/*.exe')

        t(r'*/gpu/**/software/**/*.exe', False)

    def test_linux_path(self):
        PATH = '/opt/python3.13/bin/python3d.ext'
        t = partial(self._combine, PATH)
        t(r'*bin*')
        t(r'*BIN*')

        t(r'bin', False)
        t(r'/bin/', False)

        t(r'*/bin/*')
        t(r'*/bin/**/*')
        t(r'*/opt/**/bin/**/*')
        t(r'*/opt/**/bin/**/**')
        t(r'*/opt/**/bin/**/*.*')
        t(r'*/opt/**/bin/**/*.ext')
        t(r'*/opt/**/bin/**/.ext', False)
        t(r'*/python3.13/**/bin/**/*')
        t(r'*/python3.13/**/**/*')
        t(r'*/python3.13/**/bin/**/*.*')

    def test_linux_path_with_backslash(self):
        PATH = r'/opt/python\3.13/b\in/python3\d'
        t = partial(self._t, PATH)

        t(r'*\python[\]3.13\b[!a]in\*')
        t(r'*python3*')
        t(r'*python3?d')
        t(r'*/python3\d')
        t(r'*/python\3.13/**/b\in/**/*')
        t(r'*/python\3.13/**/b\in/**/**')
        t(r'*/python\**/b\in/**/*')
        t(r'*/python\*/b\in/**/*')
        t(r'*/python\**/**\in/**/*')
        t(r'*/python\**/**/**\b\in/**/*')
        t(r'*/python\**/**/**/b\in/**/*')
        t(r'*/python\3.13/**\in/**/*')
        t(r'*/python\3.13/**/in/**/*')
        t(r'*/python\3.13/**\b\in\**/*')
        t(r'*/python\3.13\**/b\in/**\*')

    def test_windows_share_path(self):
        PATH = r'\\ServerName\SharedFolder\Subfolder\Document.docx'
        t = partial(self._combine, PATH)

        t(r'\\ServerName*')
        t(r'\\servername*')
        t(r'*\SharedFolder\Sub[fF]older\*')
        t(r'*.docx')
        t(r'*.?OC?')
        t(r'\\servername\**\*.do[a-c][x]')
        t(r'*\servername\**\sub[!a]olde?\**\*.do[A-C]x')

    def test_bytes_path(self):
        PATH = b'/opt/python3.13/bin/python3d'
        t = partial(self._combine, PATH)

        t(rb'*bin*')
        t(rb'*BIN*')
        t(rb'*/opt/**/bin/**/*')
        t(rb'*/opt/**/bin/**/**')

    def test_case_sensitive(self):
        def t(path, pat, case_sensitive, should_match):
            r = globmatch(path, pat, case_sensitive=case_sensitive)
            self.assertIs(r, should_match)

        # str
        t('/opt/python3.13/bin/python3d',
          '*/PYTHON????/*',
          True, False)

        t('/opt/python3.13/bin/python3d',
          '*/PYTHON????/*',
          False, True)

        # bytes
        t(b'/opt/python3.13/bin/python3d',
          b'*/PYTHON????/*',
          True, False)

        t(b'/opt/python3.13/bin/python3d',
          b'*/PYTHON????/*',
          False, True)

    def test_cross_fs(self):
        def t(path, pat, cross_fs, should_match):
            r = globmatch(path, pat, cross_fs=cross_fs)
            self.assertIs(r, should_match)

        # linux
        t('/opt/python3.13/bin/python3d',
          '*\\bin\\*',
          False, False)

        t(b'/opt/python3.13/bin/python3d',
          b'*\\bin\\*',
          False, False)

        t('/opt/python3.13/bin/python3d.exe',
          '*/bin/**/*.exe',
          False, True)
        t('/opt/python3.13/bin/python3d.exe',
          '*/bin/**/.exe',
          False, False)

        # linux with \
        t(r'/opt/python\3.13/b\in/python3\d',
          r'*/python\3.13/**/b\in/*',
          False, True)

        t(r'/opt/python\3.13/b\in/python3\d',
          r'*/python\**/b\in/*',
          False, True)

        t(r'/opt/python\3.13/b\in/python3\d',
          r'*/python/**/b\in/*',
          False, False)

        # windows
        t(r'E:\software\driver\gpu\gfx_win_101.7084.exe',
          '*/driver/*',
          False, False)

        t(rb'E:\software\driver\gpu\gfx_win_101.7084.exe',
          b'*/driver/*',
          False, False)

        t(r'E:\software\driver\gpu\gfx_win_101.7084.exe',
          r'*\driver\**\*.exe',
          False, True)
        t(r'E:\software\driver\gpu\gfx_win_101.7084.exe',
          r'*\driver\**\.exe',
          False, False)

if __name__ == '__main__':
    unittest.main()