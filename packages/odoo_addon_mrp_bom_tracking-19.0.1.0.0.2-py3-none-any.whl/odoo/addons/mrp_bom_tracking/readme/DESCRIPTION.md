This module adds track visibility to some fields of mrp boms. Also, it
log notes for any change in the bom lines (components).
