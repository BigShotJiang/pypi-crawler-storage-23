# Bossanova

Unified mixed-effects modeling in Python. JAX + NumPy backends. R/lme4 parity.

## Installation

```bash
uv add bossanova
```

or

```bash
pip install bossanova
```

## Features

- **One unified entry point** — `model()` handles linear, generalized, and mixed-effects models
- **R-style formulas** — `y ~ x + (1|group)`, `factor()`, `center()`, `scale()`
- **Multiple inference strategies** — asymptotic, bootstrap, permutation, cross-validation
- **Marginal effects** — `.explore()` for estimated marginal means, slopes, and contrasts
- **JAX acceleration** — automatic acceleration when JAX is available, NumPy fallback
- **R parity** — matches lme4/emmeans within f64 tolerance

## Quick Example

```python
from bossanova import model, load_dataset

df = load_dataset("sleepstudy")

# Fit a mixed model
m = model("Reaction ~ Days + (1 + Days | Subject)", data=df).fit()
m.params

# Perform bootstrapped parameter inference
m.infer(how='boot')

# Explore marginal effects
m.explore("Days")
m.effects
```

## Development

```bash
# Install dependencies
pixi install

# Install the IPython kernel (required for notebooks)
pixi run setup-kernel

# Run the full lint + type-check chain
pixi run lint

# Run fast unit tests
pixi run test
```

