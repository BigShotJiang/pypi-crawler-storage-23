"""GLM fitting via Iteratively Reweighted Least Squares (IRLS)."""

from __future__ import annotations

from bossanova.internal.containers import (
    DataBundle,
    FitState,
    ModelSpec,
    build_fit_state,
)
from bossanova.internal.maths.inference.diagnostics import compute_leverage
from bossanova.internal.maths.family import create_family, tdist
from bossanova.internal.maths.solvers.glm import fit_glm_irls as glm_irls_solver

__all__ = ["fit_glm_irls"]


def fit_glm_irls(
    spec: ModelSpec,
    bundle: DataBundle,
    *,
    max_iter: int = 25,
    tol: float = 1e-8,
) -> FitState:
    """Fit generalized linear model using Iteratively Reweighted Least Squares.

    This adapter wraps the IRLS implementation in bossanova.internal.maths.solvers.glm.
    IRLS solves GLMs by iterating between computing working weights and
    solving a weighted least squares problem.

    Algorithm:
        1. Initialize mu from y (or link function default)
        2. For each iteration:
           a. Compute working weights: W = 1 / (V(mu) * g'(mu)^2)
           b. Compute working response: z = eta + (y - mu) * g'(mu)
           c. Solve weighted least squares: beta = (X'WX)^{-1} X'Wz
           d. Update eta = X @ beta, mu = g^{-1}(eta)
        3. Continue until convergence (change in deviance < tol)

    Supported Families:
        - gaussian: Identity variance, identity link
        - binomial: mu(1-mu) variance, logit/probit/cloglog link
        - poisson: mu variance, log link
        - gamma: mu^2 variance, inverse/log link

    Args:
        spec: Model specification containing:
            - family: Distribution family (determines variance function)
            - link: Link function (determines g and g')
        bundle: Data bundle containing X, y, and optional weights.
        max_iter: Maximum IRLS iterations (default: 25).
        tol: Convergence tolerance on deviance (default: 1e-8).

    Returns:
        FitState containing:
            - coef: Coefficient estimates
            - vcov: Variance-covariance (observed Fisher information)
            - fitted: Predicted values on response scale
            - residuals: Response residuals (y - mu)
            - leverage: Hat matrix diagonal
            - df_resid: Residual degrees of freedom
            - loglik: Log-likelihood
            - dispersion: Estimated dispersion parameter
            - converged: Whether IRLS converged
            - n_iter: Number of IRLS iterations

    See Also:
        - bossanova.internal.maths.solvers.glm: Underlying IRLS implementation
    """
    X, y = bundle.X, bundle.y

    # Create Family object from spec
    # tdist requires deferred creation — df is computed from data dimensions
    if spec.family == "tdist":
        n, p = X.shape
        df_resid = n - p
        if df_resid <= 0:
            raise ValueError(
                f"Not enough observations for t-distribution family. "
                f"Need n > p, but got n={n}, p={p}."
            )
        family = tdist(df=df_resid)
    else:
        family = create_family(spec.family, spec.link)

    weights = bundle.weights if hasattr(bundle, "weights") else None

    # Run IRLS algorithm
    result = glm_irls_solver(
        y=y,
        X=X,
        family=family,
        weights=weights,
        max_iter=max_iter,
        tol=tol,
    )

    # Compute leverage values using diagnostics module
    # For GLM, use IRLS weights and XtWX_inv from the fit
    leverage = compute_leverage(
        X, weights=result["irls_weights"], XtWX_inv=result["XtWX_inv"]
    )

    return build_fit_state(
        coef=result["coef"],
        vcov=result["vcov"],
        fitted=result["fitted"],
        residuals=result["residuals"],
        leverage=leverage,
        df_resid=float(result["df_residual"]),
        loglik=float(result["loglik"]),
        dispersion=float(result["dispersion"]),
        null_deviance=float(result["null_deviance"]),
        deviance=float(result["deviance"]),
        converged=result["converged"],
        n_iter=result["n_iter"],
        irls_weights=result["irls_weights"],
        XtWX_inv=result["XtWX_inv"],
    )
