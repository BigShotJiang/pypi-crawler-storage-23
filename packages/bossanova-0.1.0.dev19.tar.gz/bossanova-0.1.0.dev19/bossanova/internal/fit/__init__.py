"""Model fitting, diagnostics, convergence, varying parameters, and prediction.

Call chain:
    model.fit() -> fit_model() -> resolve_solver() -> fit_ols_qr / fit_glm_irls / fit_lmer_pls / fit_glmer_pirls
"""

from bossanova.internal.fit.convergence import check_convergence
from bossanova.internal.fit.diagnostics import (
    augment_data_with_diagnostics,
    compute_diagnostics,
    compute_metadata,
    compute_optimizer_diagnostics,
    compute_r_squared,
)
from bossanova.internal.fit.dispatch import (
    fit_model,
    resolve_solver,
    validate_fit_method,
)
from bossanova.internal.fit.glm import (
    fit_glm_irls,
)
from bossanova.internal.fit.glmer import (
    fit_glmer_pirls,
)
from bossanova.internal.fit.lmer import (
    fit_lmer_pls,
)
from bossanova.internal.fit.ols import (
    fit_ols_qr,
)
from bossanova.internal.fit.varying import (
    compute_varying_spread_state,
    compute_varying_state,
    per_factor_re_info,
)
from bossanova.internal.maths.solvers.heuristics import get_theta_lower_bounds

__all__ = [
    "augment_data_with_diagnostics",
    "check_convergence",
    "compute_diagnostics",
    "compute_metadata",
    "compute_optimizer_diagnostics",
    "compute_r_squared",
    "compute_varying_spread_state",
    "compute_varying_state",
    "fit_glm_irls",
    "fit_glmer_pirls",
    "fit_lmer_pls",
    "fit_model",
    "fit_ols_qr",
    "get_theta_lower_bounds",
    "per_factor_re_info",
    "resolve_solver",
    "validate_fit_method",
]
