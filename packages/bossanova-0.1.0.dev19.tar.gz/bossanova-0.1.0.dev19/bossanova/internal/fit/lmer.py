"""LMM fitting via Penalized Least Squares (PLS)."""

from __future__ import annotations

import numpy as np
import scipy.sparse as sp

from bossanova.internal.containers import (
    DataBundle,
    FitState,
    ModelSpec,
    build_fit_state,
)
from bossanova.internal.maths.inference.diagnostics import compute_leverage
from bossanova.internal.maths.linalg.schur import compute_vcov_schur_sparse
from bossanova.internal.maths.solvers.heuristics import get_theta_lower_bounds

__all__ = [
    "fit_lmer_pls",
]


def fit_lmer_pls(
    spec: ModelSpec,
    bundle: DataBundle,
    *,
    max_iter: int = 10000,
    verbose: bool = False,
) -> FitState:
    """Fit linear mixed-effects model using Penalized Least Squares.

    This adapter wraps the PLS implementation from bossanova.internal.maths.
    PLS is the algorithm from Bates et al. (2015) used in R's lme4 package.

    Algorithm:
        Outer loop (BOBYQA optimization over theta):
            For each theta (relative covariance parameters):
            1. Build Lambda (block-diagonal Cholesky factor from theta)
            2. Form S_22 = Lambda' Z' Z Lambda + I
            3. Sparse Cholesky factorization of S_22
            4. Compute Schur complement for fixed effects
            5. Solve for beta (fixed effects) and u (spherical RE)
            6. Compute REML or ML deviance

    Args:
        spec: Model specification containing:
            - method: "reml" or "ml" (determines objective function)
            - random_terms: Parsed random effect specifications
        bundle: Data bundle containing:
            - X: Fixed effects design matrix (n x p)
            - Z: Random effects design matrix (n x q, sparse CSC)
            - y: Response vector
            - re_metadata: Grouping structure information
        max_iter: Maximum BOBYQA iterations (default: 10000).
        verbose: Print optimization progress (default: False).

    Returns:
        FitState containing:
            - coef: Fixed effect coefficient estimates
            - vcov: Variance-covariance of fixed effects
            - fitted: Predicted values (fixed + random)
            - residuals: Response residuals (y - fitted)
            - leverage: Approximate leverage values
            - df_resid: Residual degrees of freedom
            - loglik: REML or ML log-likelihood
            - sigma: Residual standard deviation
            - theta: Optimized relative covariance parameters
            - u: Spherical random effects (unit variance)
            - converged: Whether optimizer converged
            - n_iter: Number of optimizer iterations

    See Also:
        - bossanova.internal.maths.solvers.lmer: Underlying PLS implementation
    """
    from bossanova.internal.maths.solvers.initialization import compute_moment_init
    from bossanova.internal.maths.solvers import optimize_theta
    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_sparse,
        build_lambda_template,
    )
    from bossanova.internal.maths.solvers.lmer import (
        apply_sqrt_weights,
        compute_pls_invariants,
        lmm_deviance_sparse,
        solve_pls_sparse,
    )

    # Extract data from bundle
    X = bundle.X
    y = bundle.y
    Z = bundle.Z
    weights = bundle.weights

    if Z is None:
        raise ValueError(
            "Z matrix is required for mixed model fitting. "
            "Ensure the formula contains random effects and data is properly prepared."
        )

    # Ensure Z is CSC format
    if not sp.isspmatrix_csc(Z):
        Z = Z.tocsc()

    # Apply sqrt(weights) transformation for weighted models.
    # This transforms the weighted LMM into an equivalent unweighted problem:
    #   minimize ||W^{1/2}(y - Xβ - ZΛu)||² + ||u||²
    # becomes:
    #   minimize ||y_w - X_w·β - Z_w·Λu||² + ||u||²
    # where X_w, Z_w, y_w = W^{1/2}X, W^{1/2}Z, W^{1/2}y.
    # The same PLS solver applies to both weighted and unweighted models.
    X_w, Z_w, y_w, sqrtwts = apply_sqrt_weights(X, Z, y, weights)

    # Extract RE metadata
    re_meta = bundle.re_metadata
    if re_meta is None:
        raise ValueError(
            "re_metadata is required for mixed model fitting. "
            "Ensure the DataBundle was built with random effects information."
        )

    n, p = X.shape
    n_groups_list = re_meta.n_groups_list
    re_structure = re_meta.re_structure
    metadata = re_meta.metadata
    group_ids_list = re_meta.group_ids_list
    X_re = re_meta.X_re

    # Determine estimation method
    method = spec.method.upper() if spec.method else "REML"
    if method not in ("REML", "ML"):
        method = "REML"

    # Note: tol is not exposed — BOBYQA uses rhobeg/rhoend instead

    # Initialize theta using moment-based initialization
    theta_init = compute_moment_init(
        X=X,
        Z=Z,
        y=y,
        group_ids_list=group_ids_list,
        n_groups_list=n_groups_list,
        re_structure=re_structure,
        X_re=X_re,
        metadata=metadata,
    )

    # Build Lambda template for efficient repeated updates during optimization
    lambda_template = build_lambda_template(n_groups_list, re_structure, metadata)

    # Pre-compute invariants (X'X, X'y) before optimization loop
    # Use transformed data so invariants reflect weights
    pls_invariants = compute_pls_invariants(X_w, y_w)

    # Define deviance function for optimizer
    # Use transformed data (X_w, Z_w, y_w) so weights are implicit in the PLS solve.
    # Pass sqrtwts for the Jacobian correction in the deviance.
    def deviance_fn(theta: np.ndarray) -> float:
        return lmm_deviance_sparse(
            theta=theta,
            X=X_w,
            Z=Z_w,
            y=y_w,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            method=method,
            lambda_template=lambda_template,
            pls_invariants=pls_invariants,
            metadata=metadata,
            sqrtwts=sqrtwts,
        )

    # Set bounds for theta (diagonal elements >= 0, off-diagonal unbounded)
    n_theta = len(theta_init)
    lower_bounds = get_theta_lower_bounds(n_theta, re_structure, metadata)
    upper_bounds = [np.inf] * n_theta

    # Optimize with BOBYQA
    if verbose:
        print(f"Optimizing {n_theta} variance parameters...")

    result = optimize_theta(
        objective=deviance_fn,
        theta0=theta_init,
        lower=lower_bounds,
        upper=upper_bounds,
        rhobeg=2e-3,
        rhoend=2e-7,
        maxfun=max_iter,
        verbose=verbose,
    )

    theta_opt = np.array(result["theta"])
    final_deviance = result["fun"]
    converged = result["converged"]
    n_iter = result["n_evals"]

    # Extract results at optimal theta (using transformed data for correct estimates)
    Lambda = build_lambda_sparse(theta_opt, n_groups_list, re_structure, metadata)
    pls_result = solve_pls_sparse(X_w, Z_w, Lambda, y_w, pls_invariants=pls_invariants)

    beta = pls_result["beta"]
    u = pls_result["u"]
    rss = pls_result["rss"]
    # logdet_L and logdet_RX are used in deviance computation (via deviance_fn)
    # but not needed for post-fit extraction

    # Compute PWRSS (penalized residual sum of squares)
    pwrss = rss + np.sum(u**2)

    # Estimate sigma
    if method == "REML":
        sigma2 = pwrss / (n - p)
    else:  # ML
        sigma2 = pwrss / n

    sigma = np.sqrt(sigma2)

    # Compute variance-covariance matrix via Schur complement
    # Use transformed data (weights implicit in X_w, Z_w)
    vcov = compute_vcov_schur_sparse(X_w, Z_w, Lambda, sigma2=sigma2)

    # Compute fitted values and residuals on the ORIGINAL (unweighted) scale.
    # This preserves interpretability: Var(eps_i) = sigma^2/w_i.
    ZL_orig = Z @ Lambda
    fitted = X @ beta + ZL_orig.toarray() @ u
    residuals = y - fitted

    # Compute approximate leverage (diagonal of hat matrix for fixed effects)
    leverage = compute_leverage(X)

    # Log-likelihood
    loglik = -0.5 * final_deviance

    # Degrees of freedom
    df_resid = float(n - p)

    return build_fit_state(
        coef=beta,
        vcov=vcov,
        fitted=fitted,
        residuals=residuals,
        leverage=leverage,
        df_resid=df_resid,
        loglik=loglik,
        sigma=float(sigma),
        theta=theta_opt,
        u=u,
        converged=converged,
        n_iter=n_iter,
    )
