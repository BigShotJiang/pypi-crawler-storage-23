"""Data generating process (DGP) utilities for simulation studies."""

from bossanova.internal.simulation.dgp.glm import generate_glm_data
from bossanova.internal.simulation.dgp.glmer import generate_glmer_data
from bossanova.internal.simulation.dgp.lm import generate_lm_data
from bossanova.internal.simulation.dgp.lmer import generate_lmer_data

__all__ = [
    "generate_glm_data",
    "generate_glmer_data",
    "generate_lm_data",
    "generate_lmer_data",
]
