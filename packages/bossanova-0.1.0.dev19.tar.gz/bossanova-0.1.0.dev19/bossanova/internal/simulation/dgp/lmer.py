"""Data generating process for linear mixed models."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Literal

import numpy as np
import polars as pl

from bossanova.internal.maths.rng import RNG

if TYPE_CHECKING:
    from bossanova.internal.simulation.dgp.generate import Distribution

ArrayLike = Sequence[float] | np.ndarray

__all__ = ["generate_lmer_data"]


def generate_lmer_data(
    n_obs: int,
    n_groups: int,
    beta: ArrayLike,
    theta: ArrayLike,
    sigma: float = 1.0,
    re_structure: Literal["intercept", "slope", "both"] = "intercept",
    obs_per_group: int | None = None,
    distributions: dict[str, Distribution] | None = None,
    seed: int | None = None,
) -> tuple[pl.DataFrame, dict]:
    """Generate linear mixed model data with known parameters.

    Creates synthetic data from the model:
        y_ij = X_ij @ beta + Z_ij @ b_i + epsilon_ij
        b_i ~ N(0, G)
        epsilon_ij ~ N(0, sigma^2)

    Args:
        n_obs: Total number of observations. If obs_per_group is None,
            observations are distributed evenly across groups.
        n_groups: Number of groups/clusters.
        beta: Fixed effect coefficients [intercept, slope1, ...].
        theta: Random effect parameters. Interpretation depends on re_structure:
            - "intercept": [sigma_intercept] - SD of random intercepts
            - "slope": [sigma_slope] - SD of random slopes (no random intercept)
            - "both": [sigma_intercept, sigma_slope, corr] or [sigma_int, sigma_slope]
              If length 2, assumes uncorrelated (corr=0).
        sigma: Residual standard deviation (default 1.0).
        re_structure: Random effects structure:
            - "intercept": Random intercepts only (1|group)
            - "slope": Random slopes only (0 + x1|group)
            - "both": Random intercepts and slopes (1 + x1|group)
        obs_per_group: Observations per group. If None, uses n_obs // n_groups.
        distributions: Mapping of variable names to Distribution objects.
            When provided, these override standard normal for the specified
            variables. Variable names should match x1, x2, etc.
        seed: Random seed for reproducibility.

    Returns:
        A tuple of (data, true_params) where:
        - data: DataFrame with columns y, x1, group
        - true_params: dict with beta, theta, sigma, and ranef (actual random effects)

    Examples:
        Old API (still works)::

            # Random intercepts model
            data, params = generate_lmer_data(
                n_obs=200, n_groups=20,
                beta=[1.0, 0.5],
                theta=[0.5],  # SD of random intercepts
                sigma=1.0,
            )

        New API with distribution objects::

            from bossanova.distributions import uniform

            data, params = generate_lmer_data(
                n_obs=200, n_groups=20,
                beta=[1.0, 0.5],
                theta=[0.5],
                distributions={"x1": uniform(-1, 1)},
            )
    """
    beta = np.asarray(beta, dtype=np.float64)
    theta = np.asarray(theta, dtype=np.float64)

    if len(beta) < 2:
        raise ValueError("beta must have at least 2 elements [intercept, slope]")

    if sigma <= 0:
        raise ValueError("sigma must be positive")

    # Determine observations per group
    if obs_per_group is None:
        obs_per_group = n_obs // n_groups
    actual_n_obs = obs_per_group * n_groups

    # Initialize RNG (works with both JAX and NumPy backends)
    rng = RNG.from_seed(seed)

    # Split keys
    rng_x, rng_b, rng_eps = rng.split(n=3)

    # Generate group assignments (balanced design)
    groups = np.repeat(np.arange(n_groups), obs_per_group)

    # Generate fixed effect predictors (x1)
    n_fixed_predictors = len(beta) - 1

    # Generate predictors from distributions if provided
    if distributions is not None:
        from bossanova.internal.simulation.dgp.generate import (
            generate_predictors,
        )

        # Get numpy generator from RNG for distribution sampling
        np_rng = rng_x.key if hasattr(rng_x.key, "random") else rng_x.key
        if not isinstance(np_rng, np.random.Generator):
            # For JAX backend, create a numpy generator from seed
            np_rng = np.random.default_rng(seed)

        dist_predictors = generate_predictors(distributions, actual_n_obs, np_rng)

        # Build X matrix, using distributions where provided, normal as fallback
        X_cols = []
        extra_cols: dict[str, np.ndarray] = {}

        for i in range(n_fixed_predictors):
            col_name = f"x{i + 1}"
            if col_name in dist_predictors:
                values = dist_predictors[col_name]
                # Check if categorical (string dtype)
                if values.dtype.kind in ("U", "O", "S"):
                    # Store categorical separately, don't include in X matrix
                    extra_cols[col_name] = values
                    # Use zeros as placeholder in X (not used in linear predictor)
                    X_cols.append(np.zeros(actual_n_obs))
                else:
                    X_cols.append(np.asarray(values, dtype=np.float64))
            else:
                # Fall back to normal distribution for this column
                X_cols.append(np.asarray(rng_x.normal(shape=(actual_n_obs,))))

        X = np.column_stack(X_cols) if X_cols else np.empty((actual_n_obs, 0))
    else:
        # Original behavior: generate all predictors from normal
        extra_cols = {}
        X = np.asarray(rng_x.normal(shape=(actual_n_obs, n_fixed_predictors)))

    # Build fixed effects design matrix
    intercept = np.ones((actual_n_obs, 1))
    X_full = np.hstack([intercept, X])

    # Generate random effects based on structure
    if re_structure == "intercept":
        # Random intercepts only: b_i ~ N(0, theta[0]^2)
        if len(theta) < 1:
            raise ValueError("theta must have at least 1 element for intercept RE")
        sigma_int = float(theta[0])
        b_intercepts = np.asarray(rng_b.normal(shape=(n_groups,))) * sigma_int
        b_slopes = np.zeros(n_groups)
        ranef = {"intercept": np.asarray(b_intercepts)}

    elif re_structure == "slope":
        # Random slopes only (no random intercept)
        if len(theta) < 1:
            raise ValueError("theta must have at least 1 element for slope RE")
        sigma_slope = float(theta[0])
        b_intercepts = np.zeros(n_groups)
        b_slopes = np.asarray(rng_b.normal(shape=(n_groups,))) * sigma_slope
        ranef = {"slope": np.asarray(b_slopes)}

    else:  # "both"
        # Random intercepts and slopes
        if len(theta) < 2:
            raise ValueError(
                "theta must have at least 2 elements for intercept+slope RE"
            )
        sigma_int = float(theta[0])
        sigma_slope = float(theta[1])
        corr = float(theta[2]) if len(theta) > 2 else 0.0

        # Build covariance matrix
        cov = np.array(
            [
                [sigma_int**2, corr * sigma_int * sigma_slope],
                [corr * sigma_int * sigma_slope, sigma_slope**2],
            ]
        )

        # Generate correlated random effects using Cholesky decomposition
        L = np.linalg.cholesky(cov + 1e-10 * np.eye(2))
        z = np.asarray(rng_b.normal(shape=(n_groups, 2)))
        b = z @ L.T
        b_intercepts = b[:, 0]
        b_slopes = b[:, 1]
        ranef = {
            "intercept": np.asarray(b_intercepts),
            "slope": np.asarray(b_slopes),
        }

    # Compute random effects contribution for each observation
    re_contribution = b_intercepts[groups]
    if re_structure in ["slope", "both"]:
        # Add slope contribution: b_slope_i * x1_ij
        re_contribution = re_contribution + b_slopes[groups] * X[:, 0]

    # Generate response
    fixed_part = X_full @ beta
    epsilon = np.asarray(rng_eps.normal(shape=(actual_n_obs,))) * sigma
    y = fixed_part + re_contribution + epsilon

    # Build DataFrame
    data_dict: dict[str, np.ndarray] = {
        "y": np.asarray(y),
        "group": np.asarray(groups),
    }
    for i in range(n_fixed_predictors):
        col_name = f"x{i + 1}"
        if col_name in extra_cols:
            # Use categorical values
            data_dict[col_name] = extra_cols[col_name]
        else:
            data_dict[col_name] = np.asarray(X[:, i])

    data = pl.DataFrame(data_dict)

    true_params = {
        "beta": np.asarray(beta),
        "theta": np.asarray(theta),
        "sigma": float(sigma),
        "ranef": ranef,
        "re_structure": re_structure,
    }

    return data, true_params
