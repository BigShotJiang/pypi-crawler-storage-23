"""Data generating process for linear models."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Literal

import numpy as np
import polars as pl

from bossanova.internal.maths.rng import RNG

if TYPE_CHECKING:
    from bossanova.internal.simulation.dgp.generate import Distribution

# Type alias for array-like inputs
ArrayLike = Sequence[float] | np.ndarray

__all__ = ["generate_lm_data"]


def generate_lm_data(
    n: int,
    beta: ArrayLike,
    sigma: float = 1.0,
    x_type: Literal["gaussian", "uniform", "binary"] = "gaussian",
    distributions: dict[str, Distribution] | None = None,
    seed: int | None = None,
) -> tuple[pl.DataFrame, dict]:
    """Generate linear model data with known parameters.

    Creates synthetic data from the model:
        y = intercept + beta[1]*x1 + beta[2]*x2 + ... + epsilon
        epsilon ~ N(0, sigma^2)

    Args:
        n: Number of observations to generate.
        beta: True coefficients as [intercept, slope1, slope2, ...].
            Length determines number of predictors (len(beta) - 1).
        sigma: Residual standard deviation (default 1.0).
        x_type: Distribution for predictors:
            - "gaussian": Standard normal N(0, 1)
            - "uniform": Uniform on [0, 1]
            - "binary": Bernoulli(0.5), values in {0, 1}
        distributions: Mapping of variable names to Distribution objects.
            When provided, these override x_type for the specified variables.
            Variable names should match x1, x2, etc. Categorical distributions
            are stored as separate columns (not in X matrix).
        seed: Random seed for reproducibility. If None, uses random state.

    Returns:
        A tuple of (data, true_params) where:
        - data: polars DataFrame with columns y, x1, x2, ...
        - true_params: dict with keys "beta" (array) and "sigma" (float)

    Examples:
        Old API (still works)::

            data, params = generate_lm_data(n=100, beta=[1.0, 2.0], sigma=0.5)
            data.shape
            # (100, 2)
            params["beta"]
            # array([1., 2.])

        New API with distribution objects::

            from bossanova.distributions import normal, categorical

            data, params = generate_lm_data(
                n=100,
                beta=[0.0, 0.5],
                distributions={"x1": normal(0, 2)},
            )
    """
    beta = np.asarray(beta, dtype=np.float64)
    n_predictors = len(beta) - 1

    if n_predictors < 1:
        raise ValueError("beta must have at least 2 elements [intercept, slope]")

    if sigma <= 0:
        raise ValueError("sigma must be positive")

    # Initialize RNG (works with both JAX and NumPy backends)
    rng = RNG.from_seed(seed)

    # Split for X and epsilon
    rng_x, rng_eps = rng.split()

    # Generate predictors from distributions if provided
    if distributions is not None:
        from bossanova.internal.simulation.dgp.generate import (
            generate_predictors,
        )

        # Get numpy generator from RNG for distribution sampling
        np_rng = rng_x.key if hasattr(rng_x.key, "random") else rng_x.key
        if not isinstance(np_rng, np.random.Generator):
            # For JAX backend, create a numpy generator from seed
            np_rng = np.random.default_rng(seed)

        dist_predictors = generate_predictors(distributions, n, np_rng)

        # Build X matrix, using distributions where provided, x_type as fallback
        X_cols = []
        extra_cols: dict[str, np.ndarray] = {}

        for i in range(n_predictors):
            col_name = f"x{i + 1}"
            if col_name in dist_predictors:
                values = dist_predictors[col_name]
                # Check if categorical (string dtype)
                if values.dtype.kind in ("U", "O", "S"):
                    # Store categorical separately, don't include in X matrix
                    extra_cols[col_name] = values
                    # Use zeros as placeholder in X (not used in linear predictor)
                    X_cols.append(np.zeros(n))
                else:
                    X_cols.append(np.asarray(values, dtype=np.float64))
            else:
                # Fall back to x_type for this column
                if x_type == "gaussian":
                    X_cols.append(np.asarray(rng_x.normal(shape=(n,))))
                elif x_type == "uniform":
                    X_cols.append(np.asarray(rng_x.uniform(shape=(n,))))
                elif x_type == "binary":
                    X_cols.append(
                        np.asarray(rng_x.bernoulli(p=0.5, shape=(n,))).astype(
                            np.float64
                        )
                    )
                else:
                    raise ValueError(
                        f"Unknown x_type: {x_type}. Use 'gaussian', 'uniform', 'binary'"
                    )

        X = np.column_stack(X_cols) if X_cols else np.empty((n, 0))
    else:
        # Original behavior: generate all predictors from x_type
        extra_cols = {}
        if x_type == "gaussian":
            X = rng_x.normal(shape=(n, n_predictors))
        elif x_type == "uniform":
            X = rng_x.uniform(shape=(n, n_predictors))
        elif x_type == "binary":
            X = rng_x.bernoulli(p=0.5, shape=(n, n_predictors)).astype(np.float64)
        else:
            raise ValueError(
                f"Unknown x_type: {x_type}. Use 'gaussian', 'uniform', 'binary'"
            )

    # Ensure X is a NumPy array for consistent operations
    X = np.asarray(X)

    # Build design matrix with intercept
    intercept = np.ones((n, 1))
    X_full = np.hstack([intercept, X])

    # Generate response: y = X @ beta + epsilon
    epsilon = np.asarray(rng_eps.normal(shape=(n,))) * sigma
    y = X_full @ beta + epsilon

    # Build DataFrame
    data_dict: dict[str, np.ndarray] = {"y": np.asarray(y)}
    for i in range(n_predictors):
        col_name = f"x{i + 1}"
        if col_name in extra_cols:
            # Use categorical values
            data_dict[col_name] = extra_cols[col_name]
        else:
            data_dict[col_name] = np.asarray(X[:, i])

    data = pl.DataFrame(data_dict)

    true_params = {
        "beta": np.asarray(beta),
        "sigma": float(sigma),
    }

    return data, true_params
