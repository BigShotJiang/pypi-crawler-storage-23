"""Stateful transform classes (center, norm, zscore, scale) for formula evaluation."""

import warnings
from dataclasses import dataclass
from typing import Any

import numpy as np
from numpy.typing import NDArray

__all__ = [
    "STATEFUL_TRANSFORMS",
    "Center",
    "Norm",
    "Rank",
    "Scale",
    "SignedRank",
    "StatefulTransform",
    "TransformState",
    "Zscore",
    "create_transform",
]


# =============================================================================
# Stateful Transform Classes
# =============================================================================


@dataclass(frozen=True, slots=True)
class TransformState:
    """Container for captured transform parameters.

    Attributes:
        name: Transform name (center, scale, standardize).
        params: Dictionary of learned parameters (mean, std).
    """

    name: str
    params: dict[str, Any]


class StatefulTransform:
    """Base class for stateful transforms.

    Stateful transforms capture parameters from training data and
    reuse them when transforming new data for predictions.

    Note:
        This class is intentionally mutable. The `fit()` method updates
        internal state (`_params`, `_fitted`) which is reused by `transform()`.
    """

    name: str = "base"

    def __init__(self) -> None:
        self._fitted = False
        self._params: dict[str, Any] = {}

    @property
    def fitted(self) -> bool:
        """Whether transform has been fitted to data."""
        return self._fitted

    @property
    def state(self) -> TransformState:
        """Get current transform state."""
        return TransformState(name=self.name, params=self._params.copy())

    def fit(self, x: NDArray[np.floating[Any]]) -> None:
        """Compute and store parameters from training data.

        Args:
            x: Training data array.
        """
        raise NotImplementedError

    def transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Transform data using stored parameters.

        Args:
            x: Data to transform.

        Returns:
            Transformed data.

        Raises:
            RuntimeError: If transform has not been fitted.
        """
        raise NotImplementedError

    def fit_transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Fit to data and transform in one step.

        Args:
            x: Training data to fit and transform.

        Returns:
            Transformed training data.
        """
        self.fit(x)
        return self.transform(x)

    def __call__(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Apply transform, fitting if not already fitted.

        This allows the transform to be used as a callable in formulas.
        First call fits the transform; subsequent calls reuse parameters.

        Args:
            x: Data to transform.

        Returns:
            Transformed data.
        """
        if not self._fitted:
            return self.fit_transform(x)
        return self.transform(x)


class Center(StatefulTransform):
    """Mean-centering transform: x - mean(x).

    Subtracts the mean computed from training data.

    Note:
        This class is intentionally mutable (see `StatefulTransform`).

    Examples:
        >>> transform = Center()
        >>> train = np.array([10.0, 20.0, 30.0])
        >>> transform.fit_transform(train)  # mean=20
        array([-10.,   0.,  10.])
        >>> new = np.array([25.0, 35.0])
        >>> transform.transform(new)  # uses mean=20 from training
        array([ 5., 15.])
    """

    name = "center"

    def fit(self, x: NDArray[np.floating[Any]]) -> None:
        """Compute mean from training data."""
        self._params["mean"] = float(np.nanmean(x))
        self._fitted = True

    def transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Subtract training mean from data."""
        if not self._fitted:
            raise RuntimeError("Transform not fitted. Call fit() first.")
        return x - self._params["mean"]


class Norm(StatefulTransform):
    """Normalization transform: x / std(x).

    Divides by the standard deviation computed from training data.
    Does NOT subtract the mean (use Zscore or Scale for centered transforms).

    Note:
        This class is intentionally mutable (see `StatefulTransform`).

    Examples:
        >>> transform = Norm()
        >>> train = np.array([0.0, 10.0, 20.0])
        >>> transform.fit_transform(train)  # std=10
        array([0., 1., 2.])
        >>> new = np.array([5.0, 15.0])
        >>> transform.transform(new)  # uses std=10 from training
        array([0.5, 1.5])
    """

    name = "norm"

    def fit(self, x: NDArray[np.floating[Any]]) -> None:
        """Compute std from training data."""
        n = len(x) if hasattr(x, "__len__") else x.size
        if n < 2:
            warnings.warn(
                f"norm() received only {n} value(s). "
                "Standard deviation requires at least 2 values. "
                "Transform will return the original values unchanged.",
                UserWarning,
                stacklevel=3,
            )
        std = float(np.nanstd(x, ddof=1))  # Sample std
        if std == 0 or np.isnan(std):
            if n >= 2:
                warnings.warn(
                    "norm() received constant values (zero variance). "
                    "Transform will return the original values unchanged.",
                    UserWarning,
                    stacklevel=3,
                )
            std = 1.0  # Avoid division by zero
        self._params["std"] = std
        self._fitted = True

    def transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Divide data by training std."""
        if not self._fitted:
            raise RuntimeError("Transform not fitted. Call fit() first.")
        return x / self._params["std"]


class Zscore(StatefulTransform):
    """Z-score transform: (x - mean(x)) / std(x).

    Traditional standardization using mean and std from training data.
    Coefficients represent effect of 1 SD change.

    Note:
        This class is intentionally mutable (see `StatefulTransform`).

    Examples:
        >>> transform = Zscore()
        >>> train = np.array([10.0, 20.0, 30.0])
        >>> transform.fit_transform(train)  # mean=20, std=10
        array([-1.,  0.,  1.])
        >>> new = np.array([25.0, 35.0])
        >>> transform.transform(new)  # uses training mean/std
        array([0.5, 1.5])
    """

    name = "zscore"

    def fit(self, x: NDArray[np.floating[Any]]) -> None:
        """Compute mean and std from training data."""
        n = len(x) if hasattr(x, "__len__") else x.size
        if n < 2:
            warnings.warn(
                f"zscore() received only {n} value(s). "
                "Standard deviation requires at least 2 values. "
                "Transform will center but not scale.",
                UserWarning,
                stacklevel=3,
            )
        self._params["mean"] = float(np.nanmean(x))
        std = float(np.nanstd(x, ddof=1))  # Sample std
        if std == 0 or np.isnan(std):
            if n >= 2:
                warnings.warn(
                    "zscore() received constant values (zero variance). "
                    "Transform will center but not scale.",
                    UserWarning,
                    stacklevel=3,
                )
            std = 1.0  # Avoid division by zero
        self._params["std"] = std
        self._fitted = True

    def transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Apply z-score using training mean and std."""
        if not self._fitted:
            raise RuntimeError("Transform not fitted. Call fit() first.")
        return (x - self._params["mean"]) / self._params["std"]


class Scale(StatefulTransform):
    """Gelman scaling transform: (x - mean(x)) / (2 * std(x)).

    Centers and divides by 2 standard deviations, following Gelman (2008).
    This makes continuous predictor coefficients directly comparable to
    binary predictor coefficients in regression models.

    A 2-SD change roughly corresponds to moving from "low" to "high" in
    the predictor's range, analogous to the full effect of a binary variable.

    Note:
        This class is intentionally mutable (see `StatefulTransform`).

    References:
        Gelman, A. (2008). Scaling regression inputs by dividing by two
        standard deviations. Statistics in Medicine, 27, 2865-2873.

    Examples:
        >>> transform = Scale()
        >>> train = np.array([10.0, 20.0, 30.0])
        >>> transform.fit_transform(train)  # mean=20, std=10
        array([-0.5,  0. ,  0.5])
        >>> new = np.array([25.0, 35.0])
        >>> transform.transform(new)  # uses training mean/std
        array([0.25, 0.75])
    """

    name = "scale"

    def fit(self, x: NDArray[np.floating[Any]]) -> None:
        """Compute mean and std from training data."""
        n = len(x) if hasattr(x, "__len__") else x.size
        if n < 2:
            warnings.warn(
                f"scale() received only {n} value(s). "
                "Standard deviation requires at least 2 values. "
                "Transform will center but not scale.",
                UserWarning,
                stacklevel=3,
            )
        self._params["mean"] = float(np.nanmean(x))
        std = float(np.nanstd(x, ddof=1))  # Sample std
        if std == 0 or np.isnan(std):
            if n >= 2:
                warnings.warn(
                    "scale() received constant values (zero variance). "
                    "Transform will center but not scale.",
                    UserWarning,
                    stacklevel=3,
                )
            std = 1.0  # Avoid division by zero
        self._params["std"] = std
        self._fitted = True

    def transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Apply Gelman scaling using training mean and 2*std."""
        if not self._fitted:
            raise RuntimeError("Transform not fitted. Call fit() first.")
        return (x - self._params["mean"]) / (2 * self._params["std"])


# =============================================================================
# Rank helpers (no scipy dependency)
# =============================================================================


def _rankdata_average(x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
    """Compute average-method ranks, matching R's default rank() behaviour.

    NaN values in the input produce NaN in the output.

    Args:
        x: 1-D numeric array.

    Returns:
        Array of ranks (1-based, float64). Ties get the average of their ranks.
    """
    x = np.asarray(x, dtype=np.float64)
    result = np.empty_like(x, dtype=np.float64)
    mask = np.isnan(x)
    valid = ~mask
    xv = x[valid]

    if xv.size == 0:
        result[:] = np.nan
        return result

    # Stable argsort preserves insertion order for ties
    order = np.argsort(xv, kind="mergesort")
    ranks = np.empty_like(xv)
    ranks[order] = np.arange(1, len(xv) + 1, dtype=np.float64)

    # Average tie-breaking: group identical values, assign mean rank
    sorted_vals = xv[order]
    i = 0
    while i < len(sorted_vals):
        j = i + 1
        while j < len(sorted_vals) and sorted_vals[j] == sorted_vals[i]:
            j += 1
        if j > i + 1:
            # Tied group from i to j-1 (inclusive)
            avg_rank = np.mean(np.arange(i + 1, j + 1, dtype=np.float64))
            for k in range(i, j):
                ranks[order[k]] = avg_rank
        i = j

    result[valid] = ranks
    result[mask] = np.nan
    return result


def _interpolate_rank(
    x: NDArray[np.floating[Any]],
    sorted_vals: NDArray[np.floating[Any]],
    n_train: int,
) -> NDArray[np.floating[Any]]:
    """Interpolate ranks for new data using training distribution.

    For values that match training data exactly, returns the midpoint rank
    of the matching values. For values between training points, linearly
    interpolates. For values outside the training range, clamps to [1, n].

    Args:
        x: 1-D array of new values.
        sorted_vals: Sorted non-NaN training values.
        n_train: Number of non-NaN training observations.

    Returns:
        Interpolated ranks (1-based, float64). NaN inputs produce NaN.
    """
    x = np.asarray(x, dtype=np.float64)
    result = np.empty_like(x, dtype=np.float64)
    mask = np.isnan(x)
    valid = ~mask
    xv = x[valid]

    if xv.size == 0:
        result[:] = np.nan
        return result

    n = n_train
    # Training ranks are evenly spaced: rank_i = i+1 for i in 0..n-1
    # For each new value, find where it falls among sorted_vals
    ranks = np.empty_like(xv, dtype=np.float64)
    for idx in range(len(xv)):
        val = xv[idx]
        # Find insertion points
        lo = np.searchsorted(sorted_vals, val, side="left")
        hi = np.searchsorted(sorted_vals, val, side="right")

        if lo < hi:
            # Exact match(es) — average rank of the matching positions
            ranks[idx] = np.mean(np.arange(lo + 1, hi + 1, dtype=np.float64))
        elif lo == 0:
            # Below minimum → clamp to 1
            ranks[idx] = 1.0
        elif lo >= n:
            # Above maximum → clamp to n
            ranks[idx] = float(n)
        else:
            # Between sorted_vals[lo-1] and sorted_vals[lo] — interpolate
            v_lo = sorted_vals[lo - 1]
            v_hi = sorted_vals[lo]
            frac = (val - v_lo) / (v_hi - v_lo) if v_hi != v_lo else 0.5
            ranks[idx] = float(lo) + frac  # lo is rank of v_lo, lo+1 is rank of v_hi

    result[valid] = ranks
    result[mask] = np.nan
    return result


class Rank(StatefulTransform):
    """Average-method rank transform: rank(x).

    Converts values to their ranks using the average method for ties,
    matching R's default ``rank()`` behaviour.

    On training data (``fit_transform``), computes exact average-method ranks.
    On new data (``transform``), interpolates ranks using the training
    distribution for smooth out-of-sample predictions.

    Note:
        This class is intentionally mutable (see ``StatefulTransform``).

    Examples:
        >>> transform = Rank()
        >>> train = np.array([10.0, 30.0, 20.0])
        >>> transform.fit_transform(train)
        array([1., 3., 2.])
        >>> new = np.array([15.0, 35.0])
        >>> transform.transform(new)  # interpolated ranks
        array([1.5, 3. ])
    """

    name = "rank"

    def fit(self, x: NDArray[np.floating[Any]]) -> None:
        """Store sorted training values for newdata interpolation.

        Args:
            x: Training data array.
        """
        x = np.asarray(x, dtype=np.float64)
        valid = x[~np.isnan(x)]
        self._params["sorted_vals"] = np.sort(valid)
        self._params["n_train"] = len(valid)
        self._fitted = True

    def transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Interpolate ranks for new data using training distribution.

        Args:
            x: Data to transform.

        Returns:
            Interpolated ranks.

        Raises:
            RuntimeError: If transform has not been fitted.
        """
        if not self._fitted:
            raise RuntimeError("Transform not fitted. Call fit() first.")
        return _interpolate_rank(
            x, self._params["sorted_vals"], self._params["n_train"]
        )

    def fit_transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Compute exact average-method ranks for training data.

        Overrides the default fit+transform because exact ranks on training
        data differ from the interpolation used for new data.

        Args:
            x: Training data to fit and transform.

        Returns:
            Exact average-method ranks.
        """
        self.fit(x)
        return _rankdata_average(x)


class SignedRank(StatefulTransform):
    """Signed-rank transform: sign(x) * rank(|x|).

    Used for Wilcoxon signed-rank tests as linear models. Signs are
    preserved while absolute values are ranked.

    On training data (``fit_transform``), computes exact signed ranks.
    On new data (``transform``), interpolates absolute-value ranks using
    the training distribution, then restores signs.

    Note:
        This class is intentionally mutable (see ``StatefulTransform``).

    Examples:
        >>> transform = SignedRank()
        >>> train = np.array([-3.0, 1.0, 2.0])
        >>> transform.fit_transform(train)
        array([-3.,  1.,  2.])
    """

    name = "signed_rank"

    def fit(self, x: NDArray[np.floating[Any]]) -> None:
        """Store sorted |x| training values for newdata interpolation.

        Args:
            x: Training data array.
        """
        x = np.asarray(x, dtype=np.float64)
        valid = np.abs(x[~np.isnan(x)])
        self._params["sorted_abs_vals"] = np.sort(valid)
        self._params["n_train"] = len(valid)
        self._fitted = True

    def transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Interpolate signed ranks for new data.

        Args:
            x: Data to transform.

        Returns:
            Signed interpolated ranks.

        Raises:
            RuntimeError: If transform has not been fitted.
        """
        if not self._fitted:
            raise RuntimeError("Transform not fitted. Call fit() first.")
        x = np.asarray(x, dtype=np.float64)
        abs_ranks = _interpolate_rank(
            np.abs(x), self._params["sorted_abs_vals"], self._params["n_train"]
        )
        return np.sign(x) * abs_ranks

    def fit_transform(self, x: NDArray[np.floating[Any]]) -> NDArray[np.floating[Any]]:
        """Compute exact signed ranks for training data.

        Args:
            x: Training data to fit and transform.

        Returns:
            sign(x) * rank(|x|) with exact average-method ranks.
        """
        self.fit(x)
        x = np.asarray(x, dtype=np.float64)
        abs_ranks = _rankdata_average(np.abs(x))
        return np.sign(x) * abs_ranks


# Registry of stateful transform classes
STATEFUL_TRANSFORMS: dict[str, type[StatefulTransform]] = {
    "center": Center,
    "norm": Norm,
    "zscore": Zscore,
    "scale": Scale,
    "rank": Rank,
    "signed_rank": SignedRank,
}


def create_transform(name: str) -> StatefulTransform:
    """Create a stateful transform instance by name.

    Args:
        name: Transform name (center, scale, standardize, zscore).

    Returns:
        New transform instance.

    Raises:
        ValueError: If transform name is unknown.

    Examples:
        >>> transform = create_transform("center")
        >>> transform.fit_transform(np.array([1.0, 2.0, 3.0]))
        array([-1.,  0.,  1.])
    """
    if name not in STATEFUL_TRANSFORMS:
        raise ValueError(
            f"Unknown transform '{name}'. "
            f"Valid transforms: {sorted(STATEFUL_TRANSFORMS.keys())}"
        )
    return STATEFUL_TRANSFORMS[name]()
