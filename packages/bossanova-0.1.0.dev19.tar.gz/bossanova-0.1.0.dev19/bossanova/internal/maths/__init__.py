"""Internal computational utilities for bossanova.

This module contains shared computational functions used by model classes.
These are internal implementation details and should not be imported directly.

Subpackages:
    inference/       Statistical inference (estimation, hypothesis tests,
                     diagnostics, sandwich estimators, Satterthwaite df,
                     Wald variance, profile CI, contrasts, Welch tests,
                     information criteria)
    distributions/   Probability distributions with algebra and visualization
    family/          GLM family system (link functions, per-family modules)
    solvers/         Model fitting algorithms (OLS, IRLS, REML, etc.)
    backend/         JAX/NumPy backend dispatch

Top-level modules:
    batching         Memory-aware batch sizing for JAX operations
    differentiation  Numerical differentiation (Richardson extrapolation)
    linalg           QR and SVD solvers for ordinary least squares
    rng              Unified RNG abstraction for JAX/NumPy backends
    transforms       Stateful transforms (center, scale, norm)
"""

from bossanova.internal.maths.batching import (
    compute_batch_size,
    get_available_memory_gb,
)
from bossanova.internal.maths.config import is_singular
from bossanova.internal.maths.rounding import round_float_columns, round_sigfigs
from bossanova.internal.maths.inference import (
    Chi2TestResult,
    FTestResult,
    InferenceResult,
    TTestResult,
    adjust_pvalues,
    compute_aic,
    compute_akaike_weights,
    compute_bic,
    compute_chi2_test,
    compute_ci,
    compute_contrast_variance,
    compute_cooks_distance,
    compute_deviance,
    compute_f_pvalue,
    compute_f_test,
    compute_leverage,
    compute_pvalue,
    compute_se_from_vcov,
    compute_studentized_residuals,
    compute_t_critical,
    compute_t_test,
    compute_vif,
    compute_wald_statistic,
    compute_z_critical,
    delta_method_se,
    format_pvalue_with_stars,
    parse_conf_int,
)
from bossanova.internal.maths.backend.dispatch import clear_ops_cache, get_ops
from bossanova.internal.maths.linalg import (
    QRSolveResult,
    SVDSolveResult,
    qr_solve,
    svd_solve,
)
from bossanova.internal.maths.rng import RNG, create_rng
from bossanova.internal.design.names import (
    DesignColumnInfo,
    extract_base_term,
    extract_categorical_variables,
    extract_level_from_column,
    identify_column_type,
    parse_design_column_name,
)
from bossanova.internal.design.reference import (
    build_reference_design_matrix,
    build_reference_row,
    build_slope_reference_matrix,
)
from bossanova.internal.maths.inference.sandwich import (
    compute_glm_hc_vcov,
    compute_hc_vcov,
)
from bossanova.internal.design.coding import (
    array_to_coding_matrix,
    convert_coding_to_hypothesis,
    poly_coding,
    poly_coding_labels,
    sequential_coding,
    sequential_coding_labels,
    sum_coding,
    sum_coding_labels,
    treatment_coding,
    treatment_coding_labels,
)
from bossanova.internal.maths.transforms import (
    STATEFUL_TRANSFORMS,
    Center,
    Norm,
    Rank,
    Scale,
    SignedRank,
    StatefulTransform,
    TransformState,
    Zscore,
    create_transform,
)
from bossanova.internal.maths.inference.welch import (
    CellInfo,
    compute_cell_info,
    extract_factors_from_formula,
)
from bossanova.internal.design.z_matrix import (
    RandomEffectsInfo,
    build_random_effects,
    build_z_crossed,
    build_z_nested,
    build_z_simple,
)
from bossanova.internal.maths.distributions import (
    ConvolvedDistribution,
    Distribution,
    F_dist,
    FoldedDistribution,
    Probability,
    TransformedDistribution,
    TruncatedDistribution,
    beta,
    binomial,
    chi2,
    exponential,
    gamma,
    normal,
    poisson,
    t_dist,
    uniform,
)

__all__ = [
    "RNG",
    "STATEFUL_TRANSFORMS",
    "CellInfo",
    "Center",
    "Chi2TestResult",
    "ConvolvedDistribution",
    "DesignColumnInfo",
    "Distribution",
    "FTestResult",
    "F_dist",
    "FoldedDistribution",
    "InferenceResult",
    "Norm",
    "Probability",
    "QRSolveResult",
    "RandomEffectsInfo",
    "Rank",
    "SVDSolveResult",
    "Scale",
    "SignedRank",
    "StatefulTransform",
    "TTestResult",
    "TransformState",
    "TransformedDistribution",
    "TruncatedDistribution",
    "Zscore",
    "adjust_pvalues",
    "array_to_coding_matrix",
    "beta",
    "binomial",
    "build_random_effects",
    "build_reference_design_matrix",
    "build_reference_row",
    "build_slope_reference_matrix",
    "build_z_crossed",
    "build_z_nested",
    "build_z_simple",
    "chi2",
    "clear_ops_cache",
    "compute_aic",
    "compute_akaike_weights",
    "compute_batch_size",
    "compute_bic",
    "compute_cell_info",
    "compute_chi2_test",
    "compute_ci",
    "compute_contrast_variance",
    "compute_cooks_distance",
    "compute_deviance",
    "compute_f_pvalue",
    "compute_f_test",
    "compute_glm_hc_vcov",
    "compute_hc_vcov",
    "compute_leverage",
    "compute_pvalue",
    "compute_se_from_vcov",
    "compute_studentized_residuals",
    "compute_t_critical",
    "compute_t_test",
    "compute_vif",
    "compute_wald_statistic",
    "compute_z_critical",
    "convert_coding_to_hypothesis",
    "create_rng",
    "create_transform",
    "delta_method_se",
    "exponential",
    "extract_base_term",
    "extract_categorical_variables",
    "extract_factors_from_formula",
    "extract_level_from_column",
    "format_pvalue_with_stars",
    "gamma",
    "get_available_memory_gb",
    "get_ops",
    "identify_column_type",
    "is_singular",
    "normal",
    "parse_conf_int",
    "parse_design_column_name",
    "poisson",
    "poly_coding",
    "poly_coding_labels",
    "qr_solve",
    "round_float_columns",
    "round_sigfigs",
    "sequential_coding",
    "sequential_coding_labels",
    "sum_coding",
    "sum_coding_labels",
    "svd_solve",
    "t_dist",
    "treatment_coding",
    "treatment_coding_labels",
    "uniform",
]
