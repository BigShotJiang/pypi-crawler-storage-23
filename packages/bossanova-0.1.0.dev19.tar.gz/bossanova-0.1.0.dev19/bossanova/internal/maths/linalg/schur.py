"""Schur complement variance-covariance computation for mixed models."""

from __future__ import annotations

import numpy as np
import scipy.sparse as sp

from bossanova.internal.maths.linalg.sparse import compute_sparse_cholesky

__all__ = [
    "compute_vcov_schur_sparse",
]


def compute_vcov_schur_sparse(
    X: np.ndarray,
    Z: sp.spmatrix,
    Lambda: sp.spmatrix,
    weights: np.ndarray | None = None,
    sigma2: float = 1.0,
) -> np.ndarray:
    """Compute variance-covariance matrix of fixed effects via Schur complement.

    Uses the block matrix inversion formula to compute vcov(beta) without
    explicitly inverting the full augmented system. Handles both LMM
    (unweighted or pre-transformed) and GLMM (IRLS-weighted) cases.

    For LMMs:
        vcov(beta) = sigma2 * (X'X - X'ZL S22^{-1} ZL'X)^{-1}

    For GLMMs (with IRLS weights W):
        vcov(beta) = (X'WX - X'WZL S22^{-1} ZL'WX)^{-1}

    where S22 = ZL'[W]ZL + I and ZL = Z @ Lambda.

    Args:
        X: Fixed effects design matrix (n x p).
        Z: Random effects design matrix (n x q, sparse).
        Lambda: Cholesky-like factor (q x q, sparse).
        weights: Diagonal weights for IRLS (n,). None for unweighted (LMM).
        sigma2: Residual variance scaling. For LMMs, pass the estimated sigma^2.
            For GLMMs, leave as 1.0 (no scaling).

    Returns:
        Variance-covariance matrix (p x p).
    """
    # Compute ZL (sparse)
    ZL = Z @ Lambda

    q = Lambda.shape[0]

    if weights is not None:
        # Weighted case (GLMM)
        W = sp.diags(weights, format="csc")

        # Build S22 = ZL'WZL + I (sparse)
        ZLtWZL = (ZL.T @ W @ ZL).tocsc()
        S22 = ZLtWZL + sp.eye(q, format="csc")

        # Factor S22
        factor_S22 = compute_sparse_cholesky(S22)

        # Compute weighted cross-products
        XtWX = X.T @ W @ X
        XtWZL = (ZL.T @ W @ X).T  # (p, q)

        # Solve S22^{-1} * (X'WZL)' via factor
        S22_inv_XtWZL_T = factor_S22(XtWZL.T)

        # Schur complement: X'WX - X'WZL * S22^{-1} * ZL'WX
        schur = XtWX - XtWZL @ S22_inv_XtWZL_T
    else:
        # Unweighted case (LMM)

        # Build S22 = ZL'ZL + I (sparse)
        ZLtZL = (ZL.T @ ZL).tocsc()
        S22 = ZLtZL + sp.eye(q, format="csc")

        # Factor S22
        factor_S22 = compute_sparse_cholesky(S22)

        # Compute Schur complement: X'X - X'ZL * S22^{-1} * ZL'X
        XtX = X.T @ X
        XtZL = (ZL.T @ X).T  # (p, q)

        # Solve S22^{-1} * (X'ZL)' via factor
        S22_inv_XtZL_T = factor_S22(XtZL.T)
        schur = XtX - XtZL @ S22_inv_XtZL_T

    # vcov(beta) = sigma2 * schur^{-1}
    try:
        schur_inv = np.linalg.inv(schur)
    except np.linalg.LinAlgError:
        # Use pseudo-inverse for near-singular cases
        schur_inv = np.linalg.pinv(schur)

    return sigma2 * schur_inv
