"""Linear algebra solvers for least squares and sparse systems."""

from bossanova.internal.maths.linalg.qr import (
    QRSolveResult,
    qr_solve,
    qr_solve_jax,
)
from bossanova.internal.maths.linalg.schur import (
    compute_vcov_schur_sparse,
)
from bossanova.internal.maths.linalg.svd import (
    SVDSolveResult,
    svd_solve,
    svd_solve_jax,
)
from bossanova.internal.maths.linalg.sparse import (
    CHOLMODFactorization,
    SPLUFactorization,
    SparseFactorization,
    clear_sparse_solver_cache,
    compute_sparse_cholesky,
)

__all__ = [
    "CHOLMODFactorization",
    "QRSolveResult",
    "SPLUFactorization",
    "SVDSolveResult",
    "SparseFactorization",
    "clear_sparse_solver_cache",
    "compute_sparse_cholesky",
    "compute_vcov_schur_sparse",
    "qr_solve",
    "qr_solve_jax",
    "svd_solve",
    "svd_solve_jax",
]
