"""Binomial family functions for GLM fitting."""

# Conditional JAX import for Pyodide compatibility
try:
    import jax
    import jax.numpy as jnp

    HAS_JAX = True
except (ImportError, AttributeError):
    import numpy as jnp  # type: ignore[no-redef]

    HAS_JAX = False

    # No-op decorator when JAX is not available
    class FakeJax:
        @staticmethod
        def jit(fn):
            return fn

    jax = FakeJax()  # type: ignore[assignment]

from bossanova.internal.maths.family.links import (
    logit_link,
    logit_link_deriv,
    logit_link_inverse,
    probit_link,
    probit_link_deriv,
    probit_link_inverse,
)
from bossanova.internal.maths.family.schema import Family

__all__ = [
    "binomial",
    "binomial_deviance",
    "binomial_dispersion",
    "binomial_initialize",
    "binomial_loglik",
    "binomial_variance",
]


# ============================================================================
# Binomial Family Functions
# ============================================================================


@jax.jit
def binomial_variance(mu: jnp.ndarray) -> jnp.ndarray:
    """Binomial variance function: V(μ) = μ(1-μ).

    Args:
        mu: Mean values (n,), must be in (0, 1)

    Returns:
        Variance values (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)
    return mu_clipped * (1 - mu_clipped)


@jax.jit
def binomial_deviance(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Binomial unit deviance: d(y, μ) = 2[y log(y/μ) + (1-y) log((1-y)/(1-μ))].

    Uses log-space arithmetic for numerical stability.

    Args:
        y: Response values (n,), must be in [0, 1]
        mu: Fitted mean values (n,), must be in (0, 1)

    Returns:
        Unit deviance values (n,)
    """
    y_clipped = jnp.clip(y, 1e-10, 1 - 1e-10)
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)

    # Use log-space: log(a/b) = log(a) - log(b)
    dev = jnp.where(
        y > 0,
        2 * y * (jnp.log(y_clipped) - jnp.log(mu_clipped)),
        0.0,
    )
    dev += jnp.where(
        y < 1,
        2 * (1 - y) * (jnp.log(1 - y_clipped) - jnp.log(1 - mu_clipped)),
        0.0,
    )
    return dev


@jax.jit
def binomial_loglik(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Binomial conditional log-likelihood (per observation).

    Computes log p(y|μ) = y*log(μ) + (1-y)*log(1-μ) for Bernoulli trials.
    Uses the same numerical stability patterns as binomial_deviance.

    For binomial trials with n > 1, the binomial coefficient log(n choose k)
    would be added, but for Bernoulli (n=1) this term is zero.

    Args:
        y: Response values (n,), must be in [0, 1]
        mu: Fitted mean values (n,), must be in (0, 1)

    Returns:
        Per-observation log-likelihood values (n,), NOT summed
    """
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)

    # log p(y|μ) = y*log(μ) + (1-y)*log(1-μ)
    # Use conditional evaluation to avoid log(0) issues
    ll = jnp.where(
        y > 0,
        y * jnp.log(mu_clipped),
        0.0,
    )
    ll += jnp.where(
        y < 1,
        (1 - y) * jnp.log(1 - mu_clipped),
        0.0,
    )
    return ll


def binomial_initialize(
    y: jnp.ndarray, weights: jnp.ndarray | None = None
) -> jnp.ndarray:
    """Initialize μ for binomial family.

    Uses the weighted formula from R's stats::binomial family:
        mustart <- (weights * y + 0.5) / (weights + 1)

    This avoids boundary values (0 or 1) while accounting for prior weights.
    When weights=1 (unweighted), this gives (y + 0.5) / 2.

    Args:
        y: Response values (n,), must be in [0, 1]
        weights: Optional prior weights (n,). Defaults to 1.0 for all observations.

    Returns:
        Initial mean values (n,)
    """
    if weights is None:
        weights = jnp.ones_like(y)
    # Match R's formula exactly: (n*y + 0.5) / (n + 1) where n = weights
    return (weights * y + 0.5) / (weights + 1)


def binomial_dispersion(y: jnp.ndarray, mu: jnp.ndarray, df_resid: int) -> float:
    """Dispersion parameter for binomial family.

    Fixed at 1.0 for binomial models.

    Args:
        y: Response values (n,)
        mu: Fitted mean values (n,)
        df_resid: Residual degrees of freedom (unused)

    Returns:
        Dispersion value (always 1.0)
    """
    return 1.0


# ============================================================================
# Family Factory Function
# ============================================================================


def binomial(link: str | None = None) -> Family:
    """Create binomial family for binary or proportion data.

    The binomial family is appropriate for binary outcomes (0/1) or
    proportions (successes/trials). Commonly used for logistic and
    probit regression.

    Args:
        link: Link function name. Options are "logit" (default) or "probit".
            Defaults to "logit" if None.

    Returns:
        Binomial family configuration

    Raises:
        ValueError: If link is not None, "logit", or "probit"

    Examples:
        >>> # Logistic regression (default)
        >>> fam = binomial()
        >>> fam.link_name
        'logit'

        >>> # Probit regression
        >>> fam = binomial("probit")
        >>> fam.link_name
        'probit'
    """
    if link is None or link == "logit":
        return Family(
            name="binomial",
            link_name="logit",
            link=logit_link,
            link_inverse=logit_link_inverse,
            link_deriv=logit_link_deriv,
            variance=binomial_variance,
            deviance=binomial_deviance,
            loglik=binomial_loglik,
            initialize=binomial_initialize,
            dispersion=binomial_dispersion,
        )
    elif link == "probit":
        return Family(
            name="binomial",
            link_name="probit",
            link=probit_link,
            link_inverse=probit_link_inverse,
            link_deriv=probit_link_deriv,
            variance=binomial_variance,
            deviance=binomial_deviance,
            loglik=binomial_loglik,
            initialize=binomial_initialize,
            dispersion=binomial_dispersion,
        )
    else:
        raise ValueError(
            f"Invalid link '{link}' for binomial family. "
            f"Supported links: 'logit', 'probit'"
        )
