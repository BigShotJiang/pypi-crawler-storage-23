"""Student-t family functions for robust GLM fitting."""

# Conditional JAX import for Pyodide compatibility
try:
    import jax
    import jax.numpy as jnp

    HAS_JAX = True
except (ImportError, AttributeError):
    import numpy as jnp  # type: ignore[no-redef]

    HAS_JAX = False

    # No-op decorator when JAX is not available
    class FakeJax:
        @staticmethod
        def jit(fn):
            return fn

    jax = FakeJax()  # type: ignore[assignment]

from bossanova.internal.maths.family.links import (
    identity_link,
    identity_link_deriv,
    identity_link_inverse,
)
from bossanova.internal.maths.family.schema import Family

__all__ = [
    "tdist",
    "tdist_deviance",
    "tdist_dispersion",
    "tdist_initialize",
    "tdist_loglik",
    "tdist_robust_weights",
    "tdist_variance",
]


# ============================================================================
# Student-t Family Functions
# ============================================================================


@jax.jit
def tdist_variance(mu: jnp.ndarray) -> jnp.ndarray:
    """Student-t variance function: V(μ) = 1.

    Like Gaussian, the variance function is constant. The heavy-tailed
    behavior comes from the robust weights, not the variance function.

    Args:
        mu: Mean values (n,)

    Returns:
        Variance values (n,), all ones
    """
    return jnp.ones_like(mu)


def make_tdist_deviance(df: int):
    """Create t-distribution deviance function with fixed df.

    The deviance for t-distribution is based on -2 * log-likelihood.
    For location-scale t-distribution: -2 * log(p(y|μ,σ,df))

    Args:
        df: Degrees of freedom for the t-distribution.

    Returns:
        JIT-compiled deviance function.
    """

    @jax.jit
    def tdist_deviance(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
        """Student-t unit deviance.

        Uses the t-distribution density to compute deviance.
        Deviance = (df + 1) * log(1 + (y - μ)² / df)

        This is proportional to -2 * log(density) ignoring constants.

        Args:
            y: Response values (n,)
            mu: Fitted mean values (n,)

        Returns:
            Unit deviance values (n,)
        """
        residuals_sq = (y - mu) ** 2
        # Deviance contribution: (df + 1) * log(1 + r²/df)
        return (df + 1) * jnp.log(1 + residuals_sq / df)

    return tdist_deviance


def make_tdist_loglik(df: int):
    """Create t-distribution log-likelihood function with fixed df.

    Args:
        df: Degrees of freedom for the t-distribution.

    Returns:
        JIT-compiled log-likelihood function.
    """

    @jax.jit
    def tdist_loglik(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
        """Student-t conditional log-likelihood (per observation).

        Computes log p(y|μ, df) for standardized t-distribution (σ=1).
        log p = log(Γ((df+1)/2)) - log(Γ(df/2)) - 0.5*log(df*π)
                - ((df+1)/2) * log(1 + (y-μ)²/df)

        Args:
            y: Response values (n,)
            mu: Fitted mean values (n,)

        Returns:
            Per-observation log-likelihood values (n,), NOT summed
        """
        residuals_sq = (y - mu) ** 2
        # Log-likelihood of t-distribution (up to constant terms)
        # The constant terms involving Gamma functions cancel in optimization
        return -0.5 * (df + 1) * jnp.log(1 + residuals_sq / df)

    return tdist_loglik


def tdist_initialize(y: jnp.ndarray, weights: jnp.ndarray | None = None) -> jnp.ndarray:
    """Initialize μ for Student-t family.

    Uses y directly as the starting value (like Gaussian).

    Args:
        y: Response values (n,)
        weights: Optional prior weights (n,). Unused for t-distribution.

    Returns:
        Initial mean values (n,)
    """
    return y + 0.01 * jnp.std(y)


def tdist_dispersion(y: jnp.ndarray, mu: jnp.ndarray, df_resid: int) -> float:
    """Estimate dispersion (scale) parameter for Student-t family.

    Uses MAD (median absolute deviation) for robust scale estimation:
        σ = MAD / 0.6745

    where 0.6745 is the MAD of the standard normal distribution.

    Args:
        y: Response values (n,)
        mu: Fitted mean values (n,)
        df_resid: Residual degrees of freedom (unused for MAD)

    Returns:
        Dispersion estimate σ̂
    """
    residuals = y - mu
    mad = jnp.median(jnp.abs(residuals - jnp.median(residuals)))
    # Scale MAD to be consistent with standard deviation for normal
    scale = mad / 0.6745
    # Avoid zero scale
    return float(jnp.maximum(scale, 1e-10))


def make_tdist_robust_weights(df: int):
    """Create t-distribution robust weights function with fixed df.

    Args:
        df: Degrees of freedom for the t-distribution.

    Returns:
        JIT-compiled robust weights function.
    """

    @jax.jit
    def tdist_robust_weights(
        y: jnp.ndarray, mu: jnp.ndarray, scale: float
    ) -> jnp.ndarray:
        """Compute robust weights for t-distribution IRLS.

        These weights downweight observations with large residuals:
            w_i = (df + 1) / (df + (r_i / σ)²)

        As df → ∞, weights → 1 (Gaussian behavior).
        For small df, outliers get strongly downweighted.

        Args:
            y: Response values (n,)
            mu: Fitted mean values (n,)
            scale: Scale parameter σ

        Returns:
            Robust weights (n,), values in (0, 1]
        """
        residuals_sq = ((y - mu) / (scale + 1e-10)) ** 2
        return (df + 1) / (df + residuals_sq)

    return tdist_robust_weights


# Placeholder functions for direct import (will be replaced by factory)
def tdist_deviance(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Placeholder - use tdist(df=...) factory to get proper function."""
    raise RuntimeError("Use tdist(df=...) factory to create t-distribution family")


def tdist_loglik(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Placeholder - use tdist(df=...) factory to get proper function."""
    raise RuntimeError("Use tdist(df=...) factory to create t-distribution family")


def tdist_robust_weights(y: jnp.ndarray, mu: jnp.ndarray, scale: float) -> jnp.ndarray:
    """Placeholder - use tdist(df=...) factory to get proper function."""
    raise RuntimeError("Use tdist(df=...) factory to create t-distribution family")


# ============================================================================
# Family Factory Function
# ============================================================================


def tdist(df: int, link: str | None = None) -> Family:
    """Create Student-t family for robust regression.

    The Student-t family provides robust regression by using a t-distribution
    for the errors instead of Gaussian. This downweights outliers through
    iteratively reweighted least squares (IRLS).

    The t-distribution has heavier tails than the Gaussian:
    - df=1: Cauchy distribution (very heavy tails)
    - df=4-5: Moderately heavy tails (common for robust regression)
    - df→∞: Converges to Gaussian

    For automatic df based on residual degrees of freedom (n - p), use
    `family="tdist"` in glm() and df will be set at fit() time.

    Args:
        df: Degrees of freedom. Must be > 0. Typically set to n - p
            (residual degrees of freedom) for proper inference.
        link: Link function name. Only "identity" supported.
            Defaults to "identity" if None.

    Returns:
        Student-t family configuration with robust weights.

    Raises:
        ValueError: If df <= 0 or link is not "identity".

    Examples:
        >>> # Robust regression with df=10
        >>> fam = tdist(df=10)
        >>> fam.name
        'tdist'

        >>> # In practice, use with glm (df set automatically)
        >>> model = glm("y ~ x", data=df, family="tdist").fit()
    """
    if df <= 0:
        raise ValueError(f"df must be positive, got {df}")

    if link is not None and link != "identity":
        raise ValueError(
            f"Invalid link '{link}' for tdist family. Supported links: 'identity'"
        )

    # Create df-specific functions using closures
    deviance_fn = make_tdist_deviance(df)
    loglik_fn = make_tdist_loglik(df)
    robust_weights_fn = make_tdist_robust_weights(df)

    return Family(
        name="tdist",
        link_name="identity",
        link=identity_link,
        link_inverse=identity_link_inverse,
        link_deriv=identity_link_deriv,
        variance=tdist_variance,
        deviance=deviance_fn,
        loglik=loglik_fn,
        initialize=tdist_initialize,
        dispersion=tdist_dispersion,
        df=df,
        robust_weights=robust_weights_fn,
    )
