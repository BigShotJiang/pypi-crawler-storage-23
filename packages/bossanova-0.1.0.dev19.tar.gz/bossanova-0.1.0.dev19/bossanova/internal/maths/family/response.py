"""Response sampling and sigma resolution for GLM families.

Provides ``sample_response`` to draw response values from a GLM family
distribution given the mean on the response scale, and ``resolve_sigma``
to handle optional dispersion parameters.

These utilities eliminate triplicated family-dispatch code in simulation,
prediction, and varying-state operations.
"""

import numpy as np

__all__ = [
    "CANONICAL_LINKS",
    "resolve_sigma",
    "sample_response",
]

# Canonical link for each family (used by DGP to convert eta → mu)
CANONICAL_LINKS: dict[str, str] = {
    "gaussian": "identity",
    "binomial": "logit",
    "poisson": "log",
    "gamma": "inverse",
    "tdist": "identity",
}


def sample_response(
    family: str,
    mu: np.ndarray,
    sigma: float,
    rng: np.random.Generator,
) -> np.ndarray:
    """Sample response values from a GLM family distribution.

    Given the conditional mean on the response scale (after inverse link),
    draws observations from the appropriate distribution.

    Args:
        family: Distribution family name ("gaussian", "binomial", "poisson").
        mu: Conditional mean on the response scale, shape ``(n,)``.
        sigma: Residual standard deviation (used only for gaussian/tdist).
        rng: NumPy random number generator.

    Returns:
        Sampled response values, shape ``(n,)``.
    """
    n = len(mu)
    if family == "gaussian" or family == "tdist":
        return mu + rng.normal(0, sigma, n)
    if family == "binomial":
        return rng.binomial(1, np.clip(mu, 0.0, 1.0), n).astype(float)
    if family == "poisson":
        return rng.poisson(np.maximum(mu, 0.0), n).astype(float)
    # Fallback: gaussian
    return mu + rng.normal(0, sigma, n)


def resolve_sigma(sigma: float | None) -> float:
    """Resolve optional sigma to a concrete float.

    GLMs without a dispersion parameter (binomial, poisson) store
    ``sigma=None`` in FitState. This resolves to 1.0 for those families.

    Args:
        sigma: Residual SD from FitState, or None.

    Returns:
        The sigma value, or 1.0 if None.
    """
    return sigma if sigma is not None else 1.0
