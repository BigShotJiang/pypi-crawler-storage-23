"""Multiplicity adjustment for contrast confidence intervals.

Provides critical value computation for multiplicity-adjusted CIs,
matching R's emmeans defaults:

- Tukey HSD for pairwise contrasts (studentized range).
- Multivariate-t (MVT) for sequential, treatment, sum, helmert contrasts
  (Genz-Bretz CDF + root-finding).
- No adjustment for polynomial contrasts.

Internal exports:
    compute_tukey_critical: Tukey HSD critical value via studentized range.
    compute_mvt_critical: MVT critical value via CDF inversion.
"""

from __future__ import annotations

import numpy as np

__all__ = [
    "compute_mvt_critical",
    "compute_tukey_critical",
]


def compute_tukey_critical(
    conf_level: float,
    k: int,
    df: float,
) -> float:
    """Compute Tukey HSD critical value for pairwise comparisons.

    Uses the studentized range distribution to compute the critical value
    for simultaneous pairwise comparisons of ``k`` group means. Matches
    R's ``qtukey(conf_level, k, df) / sqrt(2)``.

    Args:
        conf_level: Confidence level (e.g. 0.95).
        k: Number of group means being compared (family size).
        df: Degrees of freedom. Use ``np.inf`` for asymptotic (z-based).

    Returns:
        Critical value for Tukey-adjusted confidence intervals.

    Examples:
        >>> crit = compute_tukey_critical(0.95, k=3, df=28)
        >>> abs(crit - 2.474) < 0.001
        True
    """
    from scipy.stats import studentized_range

    q = studentized_range.ppf(conf_level, k, df)
    return float(q / np.sqrt(2))


def compute_mvt_critical(
    conf_level: float,
    corr: np.ndarray,
    df: float,
    *,
    tol: float = 1e-6,
) -> float:
    """Compute multivariate-t critical value for simultaneous inference.

    Finds ``c`` such that ``P(-c < T_i < c for all i) = conf_level`` where
    ``T ~ MVT(df, corr)``. Uses scipy's Genz-Bretz CDF integration with
    Brent root-finding, matching R's ``mvtnorm::qmvt()``.

    For ``df = inf`` (asymptotic), uses multivariate normal instead.

    Args:
        conf_level: Confidence level (e.g. 0.95).
        corr: Correlation matrix of contrast estimates, shape (m, m).
        df: Degrees of freedom. Use ``np.inf`` for asymptotic.
        tol: Root-finding tolerance (default 1e-6).

    Returns:
        Critical value for MVT-adjusted confidence intervals.

    Examples:
        >>> corr = np.array([[1.0, 0.5], [0.5, 1.0]])
        >>> crit = compute_mvt_critical(0.95, corr, df=50)
        >>> crit > 1.96  # wider than unadjusted
        True
    """
    from scipy.optimize import brentq
    from scipy.stats import multivariate_normal, multivariate_t

    m = corr.shape[0]
    mean = np.zeros(m)

    if np.isfinite(df):
        dist = multivariate_t(loc=mean, shape=corr, df=df)
    else:
        dist = multivariate_normal(mean=mean, cov=corr)

    def objective(c: float) -> float:
        upper = np.full(m, c)
        lower = np.full(m, -c)
        return dist.cdf(upper, lower_limit=lower) - conf_level

    return float(brentq(objective, 0.5, 20.0, xtol=tol))
