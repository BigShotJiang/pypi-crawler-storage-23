"""Welch-Satterthwaite degrees of freedom for unequal variance inference."""

__all__ = [
    "CellInfo",
    "compute_cell_info",
    "compute_welch_vcov",
    "extract_factors_from_formula",
    "welch_satterthwaite_df_for_L",
    "welch_satterthwaite_df_for_contrast",
    "welch_satterthwaite_df_per_coef",
]

import re
from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray
import polars as pl


# =============================================================================
# Cell-based variance computation for Welch inference
# =============================================================================


@dataclass(frozen=True, slots=True)
class CellInfo:
    """Information about factor cells for Welch-style inference.

    When using `errors='unequal_var'`, residual variances are computed
    within each cell defined by the crossing of all factors in the model.
    This implements the Welch-James approach for factorial designs.

    Attributes:
        cell_labels: Labels for each cell as tuples of factor levels.
            For single factor: [("A",), ("B",), ...]
            For multiple factors: [("A", "X"), ("A", "Y"), ("B", "X"), ...]
        cell_variances: Sample variance of residuals within each cell.
        cell_counts: Number of observations in each cell.
        cell_indices: Cell membership for each observation (0-indexed).
        factor_columns: Names of factor columns used to define cells.
    """

    cell_labels: list[tuple[str, ...]]
    cell_variances: NDArray[np.float64]
    cell_counts: NDArray[np.int64]
    cell_indices: NDArray[np.int64]
    factor_columns: list[str]


def extract_factors_from_formula(formula: str, data: pl.DataFrame) -> list[str]:
    """Extract factor (categorical) column names from a model formula.

    Parses the RHS of the formula and identifies which columns are
    categorical (String, Categorical, or Enum type in polars).

    Args:
        formula: Model formula like "y ~ A + B + x" or "y ~ A * B + center(x)".
        data: DataFrame containing the columns referenced in the formula.

    Returns:
        List of column names that are categorical/factor variables.

    Examples:
        ```python
        import polars as pl
        df = pl.DataFrame({
            "y": [1.0, 2.0, 3.0],
            "group": ["A", "B", "A"],
            "x": [0.1, 0.2, 0.3],
        })
        extract_factors_from_formula("y ~ group + x", df)
        # ['group']

        # Multiple factors
        df2 = df.with_columns(pl.col("group").alias("treatment"))
        extract_factors_from_formula("y ~ group * treatment", df2)
        # ['group', 'treatment']
        ```

    Notes:
        - Handles interaction terms (*, :) by extracting component columns
        - Handles transforms like center(x) by extracting the inner column
        - Skips intercept terms (1, 0, -1)
        - Only returns columns that exist in the data
    """
    # Parse RHS of formula
    if "~" not in formula:
        raise ValueError(f"Formula must contain '~', got: {formula!r}")

    rhs = formula.split("~")[1].strip()

    # Extract column names by splitting on operators and cleaning
    # Handles: +, *, :, | (random effects separator)
    terms = re.split(r"[+*:|]", rhs)
    columns: list[str] = []
    contrast_wrapped: set[str] = set()  # Columns wrapped in contrast functions

    # Contrast encoding functions that mark columns as categorical
    _CONTRAST_FNS = r"(?:treatment|sum|helmert|sequential|poly|dummy|deviation)"

    for term in terms:
        term = term.strip()

        # Skip intercept terms
        if term in ("1", "0", "-1", ""):
            continue

        # Handle contrast function wrappers — mark column as categorical
        if "(" in term:
            contrast_match = re.match(rf"^{_CONTRAST_FNS}\((\w+)(?:,.*)?\)$", term)
            if contrast_match:
                col_name = contrast_match.group(1).strip()
                contrast_wrapped.add(col_name)
                term = col_name
            else:
                # Handle other transforms like center(x), scale(y), log(z)
                match = re.search(r"\(([^)]+)\)", term)
                if match:
                    term = match.group(1).strip()

        # Handle polynomial terms like I(x^2)
        if term.startswith("I("):
            continue  # Skip I() terms as they're transformations

        # Skip numeric literals
        if re.match(r"^[\d.]+$", term):
            continue

        if term and term not in columns:
            columns.append(term)

    # Filter to factors (categorical columns or contrast-wrapped columns)
    factors = []
    for col in columns:
        if col not in data.columns:
            continue

        # Contrast-wrapped columns are always treated as categorical
        if col in contrast_wrapped:
            factors.append(col)
            continue

        dtype = data[col].dtype
        # Check for categorical types in polars
        is_categorical = (
            dtype == pl.Utf8
            or dtype == pl.String
            or dtype == pl.Categorical
            or str(dtype).startswith("Enum")
        )

        if is_categorical:
            factors.append(col)

    return factors


def compute_cell_info(
    residuals: NDArray[np.float64],
    data: pl.DataFrame,
    factor_columns: list[str],
) -> CellInfo:
    """Compute cell-based variance information for Welch inference.

    For multi-factor models, cells are defined by the crossing of all factors.
    This implements the Welch-James approach for factorial designs.

    Args:
        residuals: OLS residuals, shape (n,).
        data: DataFrame with factor columns.
        factor_columns: List of factor column names.

    Returns:
        CellInfo containing variance information for each cell.

    Raises:
        ValueError: If factor_columns is empty or contains invalid columns.
        ValueError: If any cell has fewer than 2 observations.

    Examples:
        ```python
        import numpy as np
        import polars as pl
        df = pl.DataFrame({
            "group": ["A", "A", "B", "B", "B"],
            "x": [1.0, 2.0, 3.0, 4.0, 5.0],
        })
        residuals = np.array([0.1, -0.1, 0.2, -0.1, -0.1])
        info = compute_cell_info(residuals, df, ["group"])
        info.cell_labels
        # [('A',), ('B',)]
        info.cell_counts
        # array([2, 3])
        ```
    """
    if not factor_columns:
        raise ValueError("factor_columns cannot be empty")

    residuals = np.asarray(residuals, dtype=np.float64).ravel()
    n = len(residuals)

    # Validate columns exist
    for col in factor_columns:
        if col not in data.columns:
            raise ValueError(f"Factor column '{col}' not found in data")

    if len(factor_columns) == 1:
        # Single factor: simple grouping
        factor = factor_columns[0]
        groups = data[factor].to_numpy()
        unique_groups = np.unique(groups)
        k = len(unique_groups)

        cell_labels = [(str(g),) for g in unique_groups]
        cell_indices = np.zeros(n, dtype=np.int64)
        cell_variances = np.zeros(k, dtype=np.float64)
        cell_counts = np.zeros(k, dtype=np.int64)

        for i, g in enumerate(unique_groups):
            mask = groups == g
            cell_indices[mask] = i
            count = int(np.sum(mask))
            cell_counts[i] = count

            if count < 2:
                raise ValueError(
                    f"Cell '{g}' has only {count} observation(s). "
                    "All cells must have at least 2 observations for Welch inference."
                )

            cell_variances[i] = float(np.var(residuals[mask], ddof=1))

    else:
        # Multiple factors: use cell crossings
        cell_data = data.select(factor_columns)

        # Get unique cells (sorted for reproducibility)
        unique_cells = cell_data.unique().sort(factor_columns)
        k = len(unique_cells)

        cell_labels = unique_cells.cast(pl.String).rows()
        cell_indices = np.zeros(n, dtype=np.int64)
        cell_variances = np.zeros(k, dtype=np.float64)
        cell_counts = np.zeros(k, dtype=np.int64)

        for i, cell_row in enumerate(unique_cells.to_dicts()):
            # Build mask for this cell by matching all factor levels
            mask = np.ones(n, dtype=bool)
            for col, val in cell_row.items():
                col_values = data[col].to_numpy()
                mask &= col_values == val

            cell_indices[mask] = i
            count = int(np.sum(mask))
            cell_counts[i] = count

            if count < 2:
                cell_label = ", ".join(f"{k}={v}" for k, v in cell_row.items())
                raise ValueError(
                    f"Cell ({cell_label}) has only {count} observation(s). "
                    "All cells must have at least 2 observations for Welch inference."
                )

            cell_variances[i] = float(np.var(residuals[mask], ddof=1))

    return CellInfo(
        cell_labels=cell_labels,
        cell_variances=cell_variances,
        cell_counts=cell_counts,
        cell_indices=cell_indices,
        factor_columns=factor_columns,
    )


def compute_welch_vcov(
    X: NDArray[np.float64],
    cell_info: CellInfo,
) -> NDArray[np.float64]:
    """Compute Welch sandwich variance-covariance matrix.

    Uses per-cell residual variances to build a heteroscedasticity-consistent
    vcov that accounts for unequal variances across groups:

        V = (X'X)⁻¹ X' Ω X (X'X)⁻¹

    where Ω = diag(σ²_j) assigns each observation the variance of its cell.

    For a two-group comparison this gives the same SE as the classical Welch
    t-test: SE = sqrt(s₁²/n₁ + s₂²/n₂).

    Args:
        X: Design matrix, shape (n, p).
        cell_info: Cell-based variance information from compute_cell_info().

    Returns:
        Variance-covariance matrix, shape (p, p).
    """
    # Build per-observation variance weights from cell variances
    omega = cell_info.cell_variances[cell_info.cell_indices]  # shape (n,)

    # Sandwich: (X'X)⁻¹ X' Ω X (X'X)⁻¹
    XtX_inv = np.linalg.inv(X.T @ X)
    XtOmegaX = X.T @ (omega[:, np.newaxis] * X)  # (p, p)

    return XtX_inv @ XtOmegaX @ XtX_inv


def welch_satterthwaite_df_per_coef(
    X: NDArray[np.float64],
    cell_info: CellInfo,
) -> NDArray[np.float64]:
    """Compute per-coefficient Welch-Satterthwaite degrees of freedom.

    For each coefficient j, decomposes its sandwich variance into per-cell
    contributions and applies the Satterthwaite approximation independently.
    This gives genuinely different df values for different coefficients.

    For a two-group treatment-coded design ``y ~ factor(group)``:

    - **Intercept** (reference group mean): df = n_ref - 1
    - **Slope** (group difference): classic two-group Welch formula

    Algorithm for each coefficient j::

        W = X @ (X'X)^{-1}                        # (n, p) projection weights
        cell_W_sq[k, j] = sum_{i in cell_k} W[i,j]^2
        v[k, j] = s_k^2 * cell_W_sq[k, j]        # cell k's contribution
        df_j = (sum_k v[k,j])^2 / sum_k [v[k,j]^2 / (n_k - 1)]

    Args:
        X: Design matrix, shape (n, p).
        cell_info: Cell-based variance information from ``compute_cell_info()``.

    Returns:
        Per-coefficient degrees of freedom, shape (p,).

    Notes:
        This is a bossanova extension with no direct R equivalent. R's
        ``sandwich``/``emmeans``/``coeftest`` use residual df with HC SEs.
        Bossanova computes proper Satterthwaite df per coefficient, which
        for a two-group model exactly matches the classic Welch t-test
        (``t.test(var.equal=FALSE)`` / ``scipy.stats.ttest_ind``).

        - For symmetric designs (equal n and variance), all df are equal
        - The total variance ``sum_k v[k,j]`` equals ``vcov[j,j]`` from
          ``compute_welch_vcov``
        - Loops over cells (typically 2-5), vectorized over coefficients

    Examples:
        ```python
        import numpy as np
        # Two-group treatment-coded design
        X = np.column_stack([np.ones(20), np.array([0]*10 + [1]*10)])
        # ... with cell_info from compute_cell_info ...
        df = welch_satterthwaite_df_per_coef(X, cell_info)
        # df[0] ≈ n_ref - 1 (intercept)
        # df[1] ≈ classic Welch df (slope)
        ```
    """
    n, p = X.shape
    k = len(cell_info.cell_variances)

    # Projection weights: W = X @ (X'X)^{-1}, shape (n, p)
    XtX_inv = np.linalg.inv(X.T @ X)
    W = X @ XtX_inv

    # Per-cell squared weights: cell_W_sq[cell, coef] = sum_{i in cell} W[i,j]^2
    cell_W_sq = np.zeros((k, p), dtype=np.float64)
    for cell_k in range(k):
        mask = cell_info.cell_indices == cell_k
        cell_W_sq[cell_k] = np.sum(W[mask] ** 2, axis=0)

    # Variance contributions: v[k, j] = s_k^2 * cell_W_sq[k, j]
    # cell_variances shape (k,) -> (k, 1) for broadcasting
    contributions = cell_info.cell_variances[:, np.newaxis] * cell_W_sq  # (k, p)

    # Satterthwaite: df_j = (sum_k v[k,j])^2 / sum_k [v[k,j]^2 / (n_k - 1)]
    total = np.sum(contributions, axis=0)  # (p,)

    # (n_k - 1) shape (k,) -> (k, 1) for broadcasting
    denom_terms = contributions**2 / (cell_info.cell_counts[:, np.newaxis] - 1)
    denom = np.sum(denom_terms, axis=0)  # (p,)

    # Avoid division by zero (near-equal variances or single-cell dominance)
    safe_denom = np.where(denom < 1e-15, 1e-15, denom)
    df = total**2 / safe_denom

    # Cap at 1e6 for near-zero denominators
    df = np.where(denom < 1e-15, 1e6, df)

    return df


def welch_satterthwaite_df_for_contrast(
    L_row: NDArray[np.float64],
    X: NDArray[np.float64],
    cell_info: CellInfo,
) -> float:
    """Satterthwaite df for a single linear contrast ``L @ beta``.

    Generalizes ``welch_satterthwaite_df_per_coef`` from unit vectors to
    arbitrary contrast vectors. For unit vector ``e_j``, this recovers
    ``welch_satterthwaite_df_per_coef[j]``. For a two-group A-B contrast,
    this gives the classic Welch t-test df.

    Algorithm::

        W = X @ (X'X)^{-1}                        # (n, p) projection weights
        For each cell k:
            LW_k = W[cell_k, :] @ L_row           # scalar contributions
            v_k  = s_k^2 * sum(LW_k^2)
        df = (sum_k v_k)^2 / sum_k [v_k^2 / (n_k - 1)]

    Args:
        L_row: Contrast vector, shape ``(p,)``.
        X: Design matrix, shape ``(n, p)``.
        cell_info: Cell-based variance information from ``compute_cell_info()``.

    Returns:
        Satterthwaite degrees of freedom (scalar).

    Examples:
        For a unit vector ``e_j``::

            L_row = np.zeros(p)
            L_row[j] = 1.0
            df_j = welch_satterthwaite_df_for_contrast(L_row, X, cell_info)
            # Matches welch_satterthwaite_df_per_coef(X, cell_info)[j]
    """
    k = len(cell_info.cell_variances)
    XtX_inv = np.linalg.inv(X.T @ X)
    W = X @ XtX_inv  # (n, p)

    contributions = np.zeros(k, dtype=np.float64)
    for cell_k in range(k):
        mask = cell_info.cell_indices == cell_k
        LW_k = W[mask] @ L_row  # (n_k,)
        contributions[cell_k] = cell_info.cell_variances[cell_k] * np.sum(LW_k**2)

    total = np.sum(contributions)
    denom = np.sum(contributions**2 / (cell_info.cell_counts - 1))

    if denom < 1e-15:
        return 1e6
    return float(total**2 / denom)


def welch_satterthwaite_df_for_L(
    L: NDArray[np.float64],
    X: NDArray[np.float64],
    cell_info: CellInfo,
) -> NDArray[np.float64]:
    """Vectorized Satterthwaite df for each row of a contrast matrix ``L``.

    Applies ``welch_satterthwaite_df_for_contrast`` to each row of ``L``
    and returns per-row degrees of freedom.

    Args:
        L: Contrast matrix, shape ``(q, p)``.
        X: Design matrix, shape ``(n, p)``.
        cell_info: Cell-based variance information from ``compute_cell_info()``.

    Returns:
        Per-row degrees of freedom, shape ``(q,)``.
    """
    q = L.shape[0]
    dfs = np.zeros(q, dtype=np.float64)
    for i in range(q):
        dfs[i] = welch_satterthwaite_df_for_contrast(L[i], X, cell_info)
    return dfs
