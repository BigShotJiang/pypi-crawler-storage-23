"""Deviance, AIC, BIC, and Akaike weights."""

import numpy as np

__all__ = [
    "compute_aic",
    "compute_akaike_weights",
    "compute_bic",
    "compute_deviance",
]


def compute_deviance(loglik: float) -> float:
    """Compute deviance from log-likelihood.

    Deviance = -2 * loglik. Measures lack of fit relative to a saturated model.

    Args:
        loglik: Log-likelihood value.

    Returns:
        Deviance value (always >= 0 for valid log-likelihoods).

    Examples:
        >>> compute_deviance(-100.0)
        200.0
        >>> compute_deviance(0.0)
        0.0
    """
    return -2.0 * loglik


def compute_aic(loglik: float, k: int) -> float:
    """Compute Akaike Information Criterion.

    AIC = -2 * loglik + 2 * k. Trades off model fit against complexity,
    penalizing by 2 per parameter.

    Args:
        loglik: Log-likelihood value.
        k: Number of estimated parameters (including intercept and any
            scale/variance parameters).

    Returns:
        AIC value (lower is better).

    Examples:
        >>> compute_aic(-100.0, k=3)
        206.0
        >>> compute_aic(-50.0, k=5)
        110.0
    """
    return -2.0 * loglik + 2.0 * k


def compute_bic(loglik: float, k: int, n: int) -> float:
    """Compute Bayesian Information Criterion.

    BIC = -2 * loglik + k * log(n). Penalizes complexity more heavily
    than AIC for n >= 8, preferring simpler models.

    Args:
        loglik: Log-likelihood value.
        k: Number of estimated parameters.
        n: Number of observations.

    Returns:
        BIC value (lower is better).

    Raises:
        ValueError: If n <= 0.

    Examples:
        >>> compute_bic(-100.0, k=3, n=100)
        213.81...
        >>> compute_bic(-100.0, k=3, n=50)
        211.73...
    """
    if n <= 0:
        raise ValueError(f"n must be positive, got {n}")
    return -2.0 * loglik + k * np.log(n)


def compute_akaike_weights(ic_values: np.ndarray) -> np.ndarray:
    """Compute Akaike weights from information criterion values.

    Weights quantify relative probability that each model is the best model
    in the set. Works with AIC or BIC values.

    w_i = exp(-0.5 * delta_i) / sum(exp(-0.5 * delta_j))

    where delta_i = IC_i - min(IC).

    Args:
        ic_values: Array of information criterion values (AIC or BIC)
            for each model, shape (m,) where m is the number of models.

    Returns:
        Array of weights summing to 1.0, shape (m,).

    Examples:
        >>> weights = compute_akaike_weights(np.array([100.0, 102.0, 110.0]))
        >>> np.isclose(weights.sum(), 1.0)
        True
        >>> weights[0] > weights[1] > weights[2]
        True
    """
    ic_values = np.asarray(ic_values, dtype=np.float64)
    deltas = ic_values - np.min(ic_values)
    # Use exp(-0.5 * delta) with log-sum-exp stability not needed here
    # since deltas are non-negative and typically small (< 50)
    exp_deltas = np.exp(-0.5 * deltas)
    return exp_deltas / np.sum(exp_deltas)
