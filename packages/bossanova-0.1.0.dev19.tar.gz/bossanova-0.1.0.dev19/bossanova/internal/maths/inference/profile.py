"""Profile likelihood for variance components in mixed-effects models.

This module implements the profile likelihood algorithm for computing
confidence intervals for variance components (theta parameters and sigma)
in linear mixed-effects models.

The algorithm follows MixedModels.jl and lme4:
1. For each theta parameter, step bidirectionally from the MLE
2. At each step, fix that theta and re-optimize all other thetas
3. Sigma is derived analytically at each step (profile concentrated likelihood)
4. Compute the signed likelihood root: zeta = sign * sqrt(dev - dev_opt)
5. Fit B-splines for interpolation
6. Extract CIs where |zeta| = sqrt(chi2(conf_level, df=1))

References:
    - Bates et al. (2015). Fitting Linear Mixed-Effects Models Using lme4.
    - MixedModels.jl: https://github.com/JuliaStats/MixedModels.jl
"""

from typing import Callable, Protocol, runtime_checkable

__all__ = [
    "MixedModelProtocol",
    "compute_sigma_se_wald",
    "convert_theta_ci_to_sd",
    "extract_ci_bound",
    "profile_likelihood",
    "profile_theta_parameter",
]

import numpy as np
import polars as pl
from numpy.typing import NDArray
from scipy import stats
from scipy.interpolate import UnivariateSpline

# =============================================================================
# Protocol for Mixed-Effects Models
# =============================================================================


@runtime_checkable
class MixedModelProtocol(Protocol):
    """Protocol for mixed-effects models compatible with profile likelihood.

    This protocol defines the minimal interface required for profile_likelihood(),
    supporting both legacy lmer/glmer classes and the new unified model() class.

    The protocol is runtime checkable, allowing isinstance() checks if needed,
    but the function primarily uses duck typing for flexibility.
    """

    # Variance parameters (relative Cholesky factors)
    _theta: NDArray[np.floating]

    # Residual standard deviation
    _sigma: float

    # Optimal deviance at convergence
    _deviance: float

    # Deviance function: theta -> deviance
    _deviance_fn: Callable[[NDArray[np.floating]], float]

    # Grouping factor names
    _group_names: list[str]

    # Random effect names per group
    _random_names: list[str] | dict[str, list[str]]

    # Response vector
    _y: NDArray[np.floating]

    # Valid mask for missing data handling
    _valid_mask: NDArray[np.bool_]

    # Fixed effects design matrix
    _X: NDArray[np.floating]

    def get_theta_lower_bounds(self, n_theta: int) -> list[float]:
        """Get lower bounds for theta parameters."""
        ...

    def _get_re_structure(self) -> str | list[str]:
        """Get random effects structure."""
        ...


def profile_likelihood(
    model: MixedModelProtocol,
    conf_level: float = 0.95,
    threshold: float = 4.0,
    n_steps: int = 15,
    verbose: bool = False,
) -> dict:
    """Compute profile likelihood confidence intervals for variance components.

    Profiles theta parameters (relative Cholesky factors) to compute
    profile likelihood CIs that are more accurate than Wald CIs, especially
    when variance components are near the boundary (zero).

    Sigma (residual SD) is derived analytically at each profile step.
    Sigma CI is computed via the Wald approximation.

    Args:
        model: Fitted mixed-effects model (lmer, glmer, or unified model).
            Must have attributes: _theta, _sigma, _deviance, _deviance_fn,
            _group_names, _random_names, and methods get_theta_lower_bounds(),
            _get_re_structure().
        conf_level: Confidence level for CIs (default 0.95).
        threshold: Maximum |zeta| to profile (default 4, ~qnorm(0.99997)).
        n_steps: Number of steps per direction from MLE (default 15).
        verbose: Print progress messages.

    Returns:
        Dict with keys matching ProfileState fields: table, spline_forward,
        spline_reverse, ci_theta, ci_sd, ci_lower_sd, ci_upper_sd,
        conf_level, dev_opt, threshold. The caller constructs ProfileState
        to respect the maths-never-imports-containers boundary.

    Notes:
        - Profile CIs respect parameter bounds (variances >= 0)
        - Computational cost: ~2 * n_steps * n_theta deviance evaluations
        - For large models, consider using Wald CIs (cheaper) or bootstrap

    Examples:
        >>> # Legacy API
        >>> m = lmer("y ~ x + (1|group)", data).fit()
        >>> prof = profile_likelihood(m)
        >>> prof.ci_sd  # CIs on SD scale
        {'group:Intercept': (15.21, 40.23), 'Residual': (22.83, 28.69)}

        >>> # New unified API
        >>> m = model("y ~ x + (1|group)", data).fit()
        >>> prof = profile_likelihood(m)
    """
    # Extract model components
    theta_opt = model._theta.copy()
    sigma_opt = model._sigma
    n_theta = len(theta_opt)

    # Get optimal deviance
    dev_opt = model._deviance

    # Get theta bounds
    theta_lower_bounds = np.array(model.get_theta_lower_bounds(n_theta))

    # Use model's existing deviance function (over theta only, sigma is derived)
    deviance_fn = model._deviance_fn

    # Critical zeta for CIs
    zeta_crit = np.sqrt(stats.chi2.ppf(conf_level, df=1))

    # Build parameter names
    theta_names = [f"theta[{i}]" for i in range(n_theta)]

    # Profile each theta parameter
    all_rows: list[dict] = []
    spline_forward: dict[str, UnivariateSpline] = {}
    spline_reverse: dict[str, UnivariateSpline] = {}
    ci_theta: dict[str, tuple[float, float]] = {}

    for i in range(n_theta):
        param_name = theta_names[i]
        param_opt = theta_opt[i]
        lower_bound = theta_lower_bounds[i]

        if verbose:
            print(f"Profiling {param_name}...")

        # Profile this parameter
        profile_data = profile_theta_parameter(
            param_idx=i,
            param_name=param_name,
            param_opt=param_opt,
            theta_opt=theta_opt,
            dev_opt=dev_opt,
            deviance_fn=deviance_fn,
            lower_bounds=theta_lower_bounds,
            n_steps=n_steps,
            threshold=threshold,
            verbose=verbose,
        )

        all_rows.extend(profile_data["rows"])

        # Fit splines if we have enough data points
        focal_values = np.array(profile_data["focal"])
        zeta_values = np.array(profile_data["zeta"])

        if len(focal_values) >= 4:
            # Sort by focal value for spline fitting
            sort_idx = np.argsort(focal_values)
            focal_sorted = focal_values[sort_idx]
            zeta_sorted = zeta_values[sort_idx]

            try:
                # Forward spline: param -> zeta
                spline_fwd = UnivariateSpline(focal_sorted, zeta_sorted, k=3, s=0)
                spline_forward[param_name] = spline_fwd

                # Reverse spline: zeta -> param
                # Need to sort by zeta for reverse
                zeta_sort_idx = np.argsort(zeta_sorted)
                spline_rev = UnivariateSpline(
                    zeta_sorted[zeta_sort_idx],
                    focal_sorted[zeta_sort_idx],
                    k=3,
                    s=0,
                )
                spline_reverse[param_name] = spline_rev

                # Extract CI from reverse spline
                ci_lower = extract_ci_bound(
                    spline_rev, -zeta_crit, lower_bound, param_opt
                )
                ci_upper = extract_ci_bound(
                    spline_rev, zeta_crit, lower_bound, param_opt * 3
                )
                ci_theta[param_name] = (ci_lower, ci_upper)

            except Exception as e:
                if verbose:
                    print(f"  Warning: spline fitting failed for {param_name}: {e}")
                # Fall back to linear interpolation
                ci_lower = np.interp(-zeta_crit, zeta_sorted, focal_sorted)
                ci_upper = np.interp(zeta_crit, zeta_sorted, focal_sorted)
                ci_theta[param_name] = (max(lower_bound, ci_lower), ci_upper)

        else:
            if verbose:
                print(f"  Warning: insufficient data for {param_name}, using Wald CI")
            # Not enough points - use wide CI
            ci_theta[param_name] = (lower_bound, param_opt * 3)

    # Add sigma CI from Wald approximation
    # (Profile for sigma requires different treatment since it's a derived parameter)
    sigma_se = compute_sigma_se_wald(model)
    ci_theta["sigma"] = (
        max(1e-10, sigma_opt - zeta_crit * sigma_se),
        sigma_opt + zeta_crit * sigma_se,
    )

    # Build profile table
    table = pl.DataFrame(all_rows) if all_rows else pl.DataFrame()

    # Convert theta CIs to SD scale
    ci_sd, ci_lower_sd, ci_upper_sd = convert_theta_ci_to_sd(
        ci_theta=ci_theta,
        theta_opt=theta_opt,
        sigma_opt=sigma_opt,
        group_names=model._group_names,
        random_names=model._random_names,
        re_structure=model._get_re_structure(),
    )

    return {
        "table": table,
        "spline_forward": spline_forward,
        "spline_reverse": spline_reverse,
        "ci_theta": ci_theta,
        "ci_sd": ci_sd,
        "ci_lower_sd": ci_lower_sd,
        "ci_upper_sd": ci_upper_sd,
        "conf_level": conf_level,
        "dev_opt": dev_opt,
        "threshold": threshold,
    }


def profile_theta_parameter(
    param_idx: int,
    param_name: str,
    param_opt: float,
    theta_opt: np.ndarray,
    dev_opt: float,
    deviance_fn: Callable[[np.ndarray], float],
    lower_bounds: np.ndarray,
    n_steps: int,
    threshold: float,
    verbose: bool,
) -> dict:
    """Profile a single theta parameter bidirectionally from its MLE.

    At each step, fixes the focal theta and re-optimizes all other theta
    elements to find the conditional MLE deviance.

    Args:
        param_idx: Index of parameter in theta vector.
        param_name: Human-readable name.
        param_opt: Optimal value of this parameter.
        theta_opt: Full optimal theta vector.
        dev_opt: Optimal deviance.
        deviance_fn: Function theta -> deviance (model's internal fn).
        lower_bounds: Lower bounds for ALL theta parameters.
        n_steps: Steps in each direction.
        threshold: Maximum |zeta| to profile.
        verbose: Print progress.

    Returns:
        Dict with 'rows', 'focal', 'zeta' lists.
    """
    from scipy.optimize import minimize

    rows: list[dict] = []
    focal_values: list[float] = []
    zeta_values: list[float] = []

    n_theta = len(theta_opt)
    lower_bound = lower_bounds[param_idx]

    # Start with optimal point
    rows.append(
        {
            "param": param_name,
            "focal": param_opt,
            "zeta": 0.0,
        }
    )
    focal_values.append(param_opt)
    zeta_values.append(0.0)

    # Create mask for non-focal parameters
    non_focal_mask = np.ones(n_theta, dtype=bool)
    non_focal_mask[param_idx] = False
    non_focal_bounds = lower_bounds[non_focal_mask]

    def conditional_deviance(non_focal_params: np.ndarray, focal_value: float) -> float:
        """Deviance with focal theta fixed."""
        theta = np.empty(n_theta)
        theta[non_focal_mask] = non_focal_params
        theta[param_idx] = focal_value
        return deviance_fn(theta)

    def profile_at_focal(
        focal: float, init_non_focal: np.ndarray
    ) -> tuple[float, np.ndarray]:
        """Find conditional MLE deviance at fixed focal value."""
        if len(init_non_focal) == 0:
            # Only one theta parameter, no optimization needed
            theta = np.array([focal])
            return deviance_fn(theta), np.array([])

        # Optimize non-focal parameters
        result = minimize(
            conditional_deviance,
            init_non_focal,
            args=(focal,),
            method="L-BFGS-B",
            bounds=[(lb, None) for lb in non_focal_bounds],
            options={"maxiter": 100, "ftol": 1e-8},
        )
        return result.fun, result.x

    # Determine step sizes based on parameter scale
    # Use geometric spacing
    base_step = max(param_opt * 0.1, 0.05)  # At least 10% or 0.05

    # Track last successful non-focal params for warm-starting
    last_non_focal = theta_opt[non_focal_mask].copy()

    # Profile downward (toward lower bound)
    for step in range(1, n_steps + 1):
        # Geometric step toward lower bound
        focal = param_opt - base_step * (1.3 ** (step - 1))
        focal = max(focal, lower_bound + 1e-8)

        try:
            dev, new_non_focal = profile_at_focal(focal, last_non_focal)
        except Exception:
            break

        if np.isinf(dev) or np.isnan(dev):
            break

        # Compute signed likelihood root
        dev_diff = dev - dev_opt
        if dev_diff < -1e-6:
            # Numerical issue - deviance should not decrease
            dev_diff = 0.0
        zeta = -np.sqrt(max(0, dev_diff))  # Negative for below MLE

        rows.append(
            {
                "param": param_name,
                "focal": focal,
                "zeta": zeta,
            }
        )
        focal_values.append(focal)
        zeta_values.append(zeta)

        if len(new_non_focal) > 0:
            last_non_focal = new_non_focal

        if abs(zeta) > threshold:
            break

        if focal <= lower_bound + 1e-7:
            break

    # Reset for upward profiling
    last_non_focal = theta_opt[non_focal_mask].copy()

    # Profile upward (away from lower bound)
    for step in range(1, n_steps + 1):
        # Geometric step upward
        focal = param_opt + base_step * (1.3 ** (step - 1))

        try:
            dev, new_non_focal = profile_at_focal(focal, last_non_focal)
        except Exception:
            break

        if np.isinf(dev) or np.isnan(dev):
            break

        dev_diff = dev - dev_opt
        if dev_diff < -1e-6:
            dev_diff = 0.0
        zeta = np.sqrt(max(0, dev_diff))  # Positive for above MLE

        rows.append(
            {
                "param": param_name,
                "focal": focal,
                "zeta": zeta,
            }
        )
        focal_values.append(focal)
        zeta_values.append(zeta)

        if len(new_non_focal) > 0:
            last_non_focal = new_non_focal

        if abs(zeta) > threshold:
            break

    return {
        "rows": rows,
        "focal": focal_values,
        "zeta": zeta_values,
    }


def compute_sigma_se_wald(model: MixedModelProtocol) -> float:
    """Compute Wald standard error for sigma.

    Uses the delta method approximation from the Hessian.

    Args:
        model: Fitted mixed-effects model with Satterthwaite inference.

    Returns:
        Standard error of sigma.
    """
    # If we have vcov_varpar from Satterthwaite, use it
    if hasattr(model, "_vcov_varpar") and model._vcov_varpar is not None:
        # Last element of vcov_varpar is variance of sigma
        var_sigma = model._vcov_varpar[-1, -1]
        return np.sqrt(max(0, var_sigma))

    # Fallback: simple approximation based on REML theory
    # SE(sigma) ≈ sigma / sqrt(2 * (n - p))
    n = len(model._y[model._valid_mask])
    p = model._X.shape[1]
    return model._sigma / np.sqrt(2 * (n - p))


def extract_ci_bound(
    spline: UnivariateSpline,
    zeta_target: float,
    lower_bound: float,
    upper_guess: float,
) -> float:
    """Extract CI bound by finding where spline equals target zeta.

    Args:
        spline: Reverse spline (zeta -> param).
        zeta_target: Target zeta value (negative for lower, positive for upper).
        lower_bound: Parameter lower bound.
        upper_guess: Upper search bound guess.

    Returns:
        Parameter value where zeta = zeta_target.
    """
    try:
        # Evaluate spline at target
        result = float(spline(zeta_target))
        # Ensure within bounds
        return max(lower_bound, result)
    except Exception:
        # Fallback: linear extrapolation from spline endpoints
        return lower_bound if zeta_target < 0 else upper_guess


def convert_theta_ci_to_sd(
    ci_theta: dict[str, tuple[float, float]],
    theta_opt: np.ndarray,
    sigma_opt: float,
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
    re_structure: str | list[str] | dict[str, str],
) -> tuple[dict[str, tuple[float, float]], np.ndarray, np.ndarray]:
    """Convert theta-scale CIs to SD-scale CIs.

    For variance components, SD = sigma * |theta| for simple cases.
    For slope models with Cholesky factors, we use the diagonal elements
    of sigma^2 * L @ L.T.

    Args:
        ci_theta: CIs on theta scale, keyed by parameter name.
        theta_opt: Optimal theta values.
        sigma_opt: Optimal sigma value.
        group_names: Grouping factor names.
        random_names: Random effect names.
        re_structure: RE structure per group.

    Returns:
        Tuple of (ci_sd dict, ci_lower_sd array, ci_upper_sd array).
        Arrays are ordered to match result_varying rows.
    """
    # Parse structures
    if isinstance(re_structure, str):
        structure_dict = {gn: re_structure for gn in group_names}
    elif isinstance(re_structure, list):
        structure_dict = dict(zip(group_names, re_structure))
    else:
        structure_dict = re_structure

    if isinstance(random_names, list):
        names_dict = {gn: random_names for gn in group_names}
    else:
        names_dict = random_names

    ci_sd: dict[str, tuple[float, float]] = {}
    ci_lower_list: list[float] = []
    ci_upper_list: list[float] = []

    theta_idx = 0

    # Get sigma CI
    sigma_ci = ci_theta.get("sigma", (sigma_opt * 0.8, sigma_opt * 1.2))

    for group_name in group_names:
        structure = structure_dict[group_name]
        re_names = names_dict[group_name]
        n_re = len(re_names)

        if structure == "intercept":
            # SD = sigma * |theta|
            theta_name = f"theta[{theta_idx}]"
            theta_ci = ci_theta.get(
                theta_name, (theta_opt[theta_idx], theta_opt[theta_idx])
            )

            # Use sigma CI bounds appropriately
            sd_lower = sigma_ci[0] * abs(theta_ci[0])
            sd_upper = sigma_ci[1] * abs(theta_ci[1])

            key = f"{group_name}:{re_names[0]}"
            ci_sd[key] = (sd_lower, sd_upper)
            ci_lower_list.append(sd_lower)
            ci_upper_list.append(sd_upper)

            theta_idx += 1

        elif structure == "diagonal":
            for i, re_name in enumerate(re_names):
                theta_name = f"theta[{theta_idx + i}]"
                theta_ci = ci_theta.get(
                    theta_name, (theta_opt[theta_idx + i], theta_opt[theta_idx + i])
                )

                sd_lower = sigma_ci[0] * abs(theta_ci[0])
                sd_upper = sigma_ci[1] * abs(theta_ci[1])

                key = f"{group_name}:{re_name}"
                ci_sd[key] = (sd_lower, sd_upper)
                ci_lower_list.append(sd_lower)
                ci_upper_list.append(sd_upper)

            theta_idx += n_re

        elif structure == "slope":
            # For slope models, we need to be more careful
            # SD[i] = sigma * sqrt(sum_k L[i,k]^2)
            # For now, use approximate transformation
            n_theta_group = n_re * (n_re + 1) // 2

            for i, re_name in enumerate(re_names):
                # This is approximate - proper would require profiling the SD directly
                # Use a heuristic based on the diagonal theta element
                if i == 0:
                    # First diagonal element
                    theta_name = f"theta[{theta_idx}]"
                else:
                    # Later diagonal elements have different indexing
                    # In lower-triangular storage: theta[0], theta[1], theta[2], theta[3], ...
                    # For 2x2: [[theta[0], 0], [theta[1], theta[2]]]
                    # Diagonal elements are at indices: 0, 2 (for 2x2), or 0, 2, 5 (for 3x3)
                    diag_idx = theta_idx + i * (i + 1) // 2 + i
                    theta_name = f"theta[{diag_idx}]"

                theta_ci = ci_theta.get(theta_name, (0.5, 2.0))

                # Approximate SD CI (transform from theta scale)
                sd_lower = sigma_ci[0] * abs(theta_ci[0])
                sd_upper = sigma_ci[1] * abs(theta_ci[1])

                key = f"{group_name}:{re_name}"
                ci_sd[key] = (max(0, sd_lower), sd_upper)
                ci_lower_list.append(max(0, sd_lower))
                ci_upper_list.append(sd_upper)

            theta_idx += n_theta_group

        else:
            raise ValueError(f"Unknown RE structure: {structure}")

    # Add residual SD
    ci_sd["Residual"] = sigma_ci
    ci_lower_list.append(sigma_ci[0])
    ci_upper_list.append(sigma_ci[1])

    return ci_sd, np.array(ci_lower_list), np.array(ci_upper_list)
