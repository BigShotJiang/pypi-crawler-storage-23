"""Satterthwaite degrees of freedom approximation for linear mixed models."""

import warnings

import numpy as np
from scipy.stats import t as t_dist

__all__ = [
    "compute_satterthwaite_summary_table",
    "satterthwaite_df",
    "satterthwaite_df_for_contrasts",
    "satterthwaite_t_test",
]


# =============================================================================
# Satterthwaite Degrees of Freedom
# =============================================================================


def satterthwaite_df(
    vcov_beta: np.ndarray,
    jacobian_vcov: np.ndarray,
    hessian_deviance: np.ndarray,
    min_df: float = 1.0,
    max_df: float = 1e6,
    tol: float = 1e-8,
) -> np.ndarray:
    """Compute Satterthwaite degrees of freedom for each fixed effect.

    Implements the Satterthwaite approximation for denominator degrees of freedom:

        df_j = 2 * (SE(β̂_j)²)² / Var(SE(β̂_j)²)

    Where Var(SE(β̂_j)²) is computed via the delta method using the Jacobian
    of Vcov(beta) w.r.t. variance parameters and the inverse Hessian of the
    deviance function.

    Args:
        vcov_beta: Variance-covariance matrix of fixed effects, shape (p, p).
        jacobian_vcov: Jacobian of Vcov(beta) w.r.t. variance parameters,
                       shape (p, p, k) where k = number of variance parameters.
        hessian_deviance: Hessian of deviance w.r.t. variance parameters,
                          shape (k, k).
        min_df: Minimum allowable df (default 1.0).
        max_df: Maximum allowable df (default 1e6).
        tol: Tolerance for determining positive eigenvalues in Hessian.

    Returns:
        Array of degrees of freedom for each fixed effect, shape (p,).

    Notes:
        - Uses Moore-Penrose pseudo-inverse for the Hessian to handle
          negative or near-zero eigenvalues (convergence issues)
        - Warns when negative eigenvalues are detected
        - Clips df to [min_df, max_df] range for numerical stability
        - Returns max_df when variance of variance is near zero

    Examples:
        ```python
        # After fitting lmer model and computing Hessian/Jacobian
        df = satterthwaite_df(vcov_beta, jac, hess)
        # df[0] is the denominator df for testing beta[0]
        ```
    """
    p = vcov_beta.shape[0]
    k = jacobian_vcov.shape[2]

    # Compute vcov_varpar = 2 * H^{-1} using Moore-Penrose pseudo-inverse
    # Only use positive eigenvalues (lmerTest approach)
    try:
        eig_vals, eig_vecs = np.linalg.eigh(hessian_deviance)
    except np.linalg.LinAlgError:
        # Eigendecomposition failed (e.g., SVD did not converge on small data)
        warnings.warn(
            "Eigendecomposition of Hessian failed (SVD did not converge). "
            "Using maximum degrees of freedom. Results may be unreliable "
            "with very small datasets.",
            UserWarning,
        )
        return np.full(p, max_df, dtype=np.float64)

    # Check for negative eigenvalues (convergence issues)
    neg = eig_vals < -tol
    zero = (eig_vals > -tol) & (eig_vals < tol)
    pos = eig_vals > tol

    if np.sum(neg) > 0:
        # Warn about negative eigenvalues
        neg_count = int(np.sum(neg))
        eval_chr = "eigenvalues" if neg_count > 1 else "eigenvalue"
        warnings.warn(
            f"Model failed to converge with {neg_count} negative {eval_chr}. "
            f"Using Moore-Penrose pseudo-inverse for numerical stability.",
            UserWarning,
        )

    if np.sum(zero) > 0:
        # Warn about near-zero eigenvalues
        zero_count = int(np.sum(zero))
        eval_chr = "eigenvalues" if zero_count > 1 else "eigenvalue"
        warnings.warn(
            f"Model may not have converged with {zero_count} {eval_chr} close to zero. "
            f"Using Moore-Penrose pseudo-inverse for numerical stability.",
            UserWarning,
        )

    # Compute vcov_varpar = 2 * H^{-1}
    q = int(np.sum(pos))
    if q > 0:
        # Moore-Penrose: H^{-1} = V * D^{-1} * V^T where D contains only positive eigenvalues
        eig_vecs_pos = eig_vecs[:, pos]
        eig_vals_pos = eig_vals[pos]
        # Compute: V * diag(1/eigenvals) * V^T
        H_inv = eig_vecs_pos @ np.diag(1.0 / eig_vals_pos) @ eig_vecs_pos.T
        vcov_varpar = 2.0 * H_inv
    else:
        # All eigenvalues are negative/zero - use small regularization
        warnings.warn(
            "All Hessian eigenvalues are non-positive. "
            "Using regularized pseudo-inverse.",
            UserWarning,
        )
        # Add small regularization and use pinv as last resort
        vcov_varpar = 2.0 * np.linalg.pinv(hessian_deviance + np.eye(k) * 1e-6)

    # Compute df for each coefficient
    dfs = np.zeros(p, dtype=np.float64)

    for j in range(p):
        # Extract variance of j-th coefficient: var_j = Vcov(beta)[j, j]
        var_j = vcov_beta[j, j]
        var_j = np.abs(var_j)  # Ensure non-negative

        # Extract gradient of var_j w.r.t. variance parameters: g = Jac[j, j, :]
        grad_var_j = jacobian_vcov[j, j, :]

        # Compute variance of var_j using delta method:
        # Var(var_j) = g' * Vcov(varpar) * g
        var_of_var = grad_var_j @ vcov_varpar @ grad_var_j
        var_of_var = np.abs(var_of_var)  # Ensure non-negative

        # Check for numerical issues in denominator
        if var_of_var < 1e-10:
            # Denominator too small - use large df as fallback
            warnings.warn(
                f"Var(var_contrast) is near zero ({var_of_var:.2e}) for coefficient {j}. "
                f"Using maximum df={max_df}.",
                UserWarning,
            )
            dfs[j] = max_df
        else:
            # Satterthwaite formula: df = 2 * var^2 / Var(var)
            df_j = 2.0 * var_j**2 / var_of_var

            # Clip to reasonable range
            dfs[j] = np.clip(df_j, min_df, max_df)

    return dfs


def satterthwaite_df_for_contrasts(
    L: np.ndarray,
    vcov_beta: np.ndarray,
    vcov_varpar: np.ndarray,
    jac_list: list[np.ndarray],
    min_df: float = 1.0,
    max_df: float = 1e6,
) -> np.ndarray:
    """Compute Satterthwaite degrees of freedom for arbitrary contrasts.

    This generalizes `satterthwaite_df()` to handle arbitrary linear contrasts
    L @ β, not just individual coefficients. This is needed for emmeans where
    each EMM is a linear combination of coefficients.

    The Satterthwaite formula for contrast L is:

        df = 2 * var_contrast² / Var(var_contrast)

    Where:
        var_contrast = L @ Vcov(β) @ L.T
        grad[i] = L @ Jac_i @ L.T  (gradient w.r.t. variance parameter i)
        Var(var_contrast) = grad @ Vcov(varpar) @ grad

    Args:
        L: Contrast matrix, shape (n_contrasts, n_coef). Each row is a contrast.
            For a single contrast, shape can be (n_coef,).
        vcov_beta: Variance-covariance matrix of fixed effects, shape (p, p).
        vcov_varpar: Variance-covariance matrix of variance parameters, shape (k, k).
            This is 2 * H^{-1} where H is the Hessian of deviance.
        jac_list: List of k Jacobian matrices, each shape (p, p).
            jac_list[i] = ∂Vcov(β)/∂varpar_i.
        min_df: Minimum allowable df (default 1.0).
        max_df: Maximum allowable df (default 1e6).

    Returns:
        Array of degrees of freedom for each contrast, shape (n_contrasts,).
        For a single contrast (1D input), returns a scalar float.

    Examples:
        ```python
        # Compute df for EMMs where X_ref is the prediction matrix
        df = satterthwaite_df_for_contrasts(
            X_ref, vcov_beta, vcov_varpar, jac_list
        )
        # df[i] is the denominator df for EMM i
        ```
    """
    # Handle 1D input (single contrast)
    L = np.atleast_2d(L)
    n_contrasts = L.shape[0]
    k = len(jac_list)

    dfs = np.zeros(n_contrasts, dtype=np.float64)

    for i in range(n_contrasts):
        Li = L[i, :]

        # Compute variance of contrast: var_contrast = L @ Vcov(β) @ L
        var_contrast = Li @ vcov_beta @ Li
        var_contrast = np.abs(var_contrast)  # Ensure non-negative

        # Compute gradient of var_contrast w.r.t. variance parameters
        # grad[j] = L @ Jac_j @ L
        grad_var_contrast = np.array([Li @ jac_list[j] @ Li for j in range(k)])

        # Compute variance of var_contrast using delta method:
        # Var(var_contrast) = grad @ Vcov(varpar) @ grad
        var_of_var = grad_var_contrast @ vcov_varpar @ grad_var_contrast
        var_of_var = np.abs(var_of_var)  # Ensure non-negative

        # Check for numerical issues in denominator
        if var_of_var < 1e-10:
            # Denominator too small - use large df as fallback
            dfs[i] = max_df
        else:
            # Satterthwaite formula: df = 2 * var^2 / Var(var)
            df_i = 2.0 * var_contrast**2 / var_of_var
            # Clip to reasonable range
            dfs[i] = np.clip(df_i, min_df, max_df)

    # Return scalar for single contrast input
    if n_contrasts == 1:
        return float(dfs[0])
    return dfs


def satterthwaite_t_test(
    beta: np.ndarray,
    se: np.ndarray,
    df: np.ndarray,
    conf_level: float = 0.95,
) -> dict[str, np.ndarray]:
    """Compute t-statistics, p-values, and confidence intervals.

    Uses Satterthwaite degrees of freedom for each coefficient to compute
    t-test statistics and p-values.

    Args:
        beta: Coefficient estimates, shape (p,).
        se: Standard errors, shape (p,).
        df: Satterthwaite degrees of freedom for each coefficient, shape (p,).
        conf_level: Confidence level for intervals (default 0.95 for 95% CI).

    Returns:
        Dictionary with:
        - 'statistic': t-statistics, shape (p,)
        - 'p_value': Two-tailed p-values, shape (p,)
        - 'ci_lower': Lower confidence bounds, shape (p,)
        - 'ci_upper': Upper confidence bounds, shape (p,)

    Examples:
        ```python
        # After computing df from satterthwaite_df()
        se = np.sqrt(np.diag(vcov_beta))
        results = satterthwaite_t_test(beta, se, df)
        print(results['p_value'])  # Two-tailed p-values
        ```
    """
    p = len(beta)

    # Compute t-statistics
    t_stats = beta / se

    # Compute p-values (two-tailed)
    p_values = np.array(
        [2.0 * t_dist.sf(np.abs(t_stats[i]), df=df[i]) for i in range(p)]
    )

    # Compute confidence intervals
    alpha = 1.0 - conf_level
    t_crit = np.array([t_dist.ppf(1 - alpha / 2, df=df[i]) for i in range(p)])
    ci_lower = beta - t_crit * se
    ci_upper = beta + t_crit * se

    return {
        "statistic": t_stats,
        "p_value": p_values,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
    }


def compute_satterthwaite_summary_table(
    beta: np.ndarray,
    beta_names: list[str],
    vcov_beta: np.ndarray,
    vcov_varpar: np.ndarray,
    jac_list: list[np.ndarray],
) -> dict[str, list]:
    """Compute full coefficient table with Satterthwaite df and p-values.

    Computes t-statistics, degrees of freedom, and p-values for all
    fixed effects using Satterthwaite's approximation.

    This is a convenience function that combines `satterthwaite_df()`
    and `satterthwaite_t_test()` into a single summary table.

    Args:
        beta: Fixed effects estimates, shape (p,).
        beta_names: Names of fixed effects.
        vcov_beta: Variance-covariance matrix of beta, shape (p, p).
        vcov_varpar: Variance-covariance matrix of variance parameters.
        jac_list: List of Jacobian matrices, each shape (p, p).

    Returns:
        Dictionary with keys:
        - 'Parameter': List of parameter names
        - 'Estimate': Coefficient estimates
        - 'Std. Error': Standard errors
        - 'df': Satterthwaite degrees of freedom
        - 't value': t-statistics
        - 'Pr(>|t|)': Two-tailed p-values

    Notes:
        - Computes one t-test per fixed effect
        - Uses standard t-distribution for p-values
        - All computations vectorized for efficiency

    Examples:
        ```python
        # After fitting lmer and computing Hessian/Jacobian
        table = compute_satterthwaite_summary_table(
            beta, beta_names, vcov_beta, vcov_varpar, jac_list
        )
        import pandas as pd
        df = pd.DataFrame(table)
        print(df)
        ```
    """
    p = len(beta)

    # Storage for results
    estimates = []
    std_errors = []
    dfs = []
    t_stats = []
    p_values = []

    # Compute for each coefficient
    for i in range(p):
        # Contrast vector: picks out i-th coefficient
        L = np.zeros(p)
        L[i] = 1.0

        # Compute variance of contrast: var_contrast = L' * Vcov(beta) * L
        var_contrast = L @ vcov_beta @ L
        var_contrast = np.abs(var_contrast)
        se = np.sqrt(var_contrast)

        # Compute gradient of var_contrast w.r.t. variance parameters
        # g_i = L' * Jac_i * L
        k = len(jac_list)
        grad_var_contrast = np.array([L @ jac_list[j] @ L for j in range(k)])

        # Compute variance of var_contrast using delta method:
        # Var(var_contrast) = grad' * Vcov(varpar) * grad
        var_of_var = grad_var_contrast @ vcov_varpar @ grad_var_contrast
        var_of_var = np.abs(var_of_var)

        # Check for numerical issues in denominator
        tol = 1e-10
        if var_of_var < tol:
            # Denominator too small - use large df as fallback
            warnings.warn(
                f"Var(var_contrast) is near zero ({var_of_var:.2e}). "
                f"Using maximum df=1e6 for this contrast.",
                UserWarning,
            )
            ddf = 1e6
        else:
            # Satterthwaite formula: ddf = 2 * var^2 / Var(var)
            ddf = 2.0 * var_contrast**2 / var_of_var

            # Clip to reasonable range
            ddf = np.clip(ddf, 1.0, 1e6)

        # Compute t-statistic
        estimate = beta[i]
        t_stat = estimate / se

        # Compute two-tailed p-value (clamp to machine epsilon floor)
        p_value = max(
            2.0 * t_dist.sf(np.abs(float(t_stat)), df=float(ddf)),
            np.finfo(np.float64).eps,
        )

        # Store results
        estimates.append(float(estimate))
        std_errors.append(float(se))
        dfs.append(float(ddf))
        t_stats.append(float(t_stat))
        p_values.append(float(p_value))

    return {
        "Parameter": beta_names,
        "Estimate": estimates,
        "Std. Error": std_errors,
        "df": dfs,
        "t value": t_stats,
        "Pr(>|t|)": p_values,
    }
