"""Standard errors, confidence intervals, and coefficient inference."""

from dataclasses import dataclass

import numpy as np
from scipy import stats

from .hypothesis import compute_pvalue

__all__ = [
    "InferenceResult",
    "compute_ci",
    "compute_coefficient_inference",
    "compute_se_from_vcov",
    "compute_t_critical",
    "compute_z_critical",
    "delta_method_se",
    "parse_conf_int",
]


@dataclass(frozen=True, slots=True)
class InferenceResult:
    """Results from coefficient inference computation.

    Attributes:
        se: Standard errors for each coefficient.
        statistic: Test statistics (t or z values).
        p_values: Two-tailed p-values.
        ci_lower: Lower confidence interval bounds.
        ci_upper: Upper confidence interval bounds.
        df_values: Degrees of freedom for each coefficient (inf for z-distribution).
    """

    se: np.ndarray
    statistic: np.ndarray
    p_values: np.ndarray
    ci_lower: np.ndarray
    ci_upper: np.ndarray
    df_values: list[float]


def parse_conf_int(conf_int: float | int | str) -> float:
    """Parse flexible confidence interval input to float.

    Args:
        conf_int: Confidence interval specification. Accepts:
            float in (0, 1): treated as confidence level,
            int in (1, 99]: converted to proportion (e.g., 95 -> 0.95),
            str: parsed as number with optional '%' (e.g., "95%", "95").

    Returns:
        Confidence level as proportion in (0, 1).

    Raises:
        ValueError: If conf_int cannot be parsed or is out of valid range.

    Examples:
        >>> parse_conf_int(0.95)
        0.95
        >>> parse_conf_int(95)
        0.95
        >>> parse_conf_int("95%")
        0.95
    """
    if isinstance(conf_int, str):
        # Remove '%' if present
        conf_int = conf_int.strip().rstrip("%")
        try:
            conf_int = float(conf_int)
        except ValueError:
            raise ValueError(f"Cannot parse conf_int: {conf_int}")

    # Convert int/float to proportion
    if isinstance(conf_int, (int, float)):
        if 0 < conf_int < 1:
            # Already a proportion
            return float(conf_int)
        elif 1 < conf_int <= 100:
            # Percentage notation - but only accept integers to avoid mistakes
            # like conf_int=1.5 which is likely meant to be 0.95
            if conf_int != int(conf_int):
                raise ValueError(
                    f"conf_int={conf_int} is ambiguous. "
                    f"Use {conf_int / 100:.4f} for {conf_int}% CI, "
                    f"or an integer like 95 for 95% CI."
                )
            return float(conf_int) / 100.0
        else:
            raise ValueError(
                f"conf_int must be in (0, 1) or an integer in [2, 100], got {conf_int}"
            )
    else:
        raise ValueError(f"conf_int must be float, int, or str, got {type(conf_int)}")


def compute_t_critical(
    conf_int: float,
    df: float | np.ndarray,
    alternative: str = "two-sided",
) -> float | np.ndarray:
    """Compute t-distribution critical value for confidence interval.

    Args:
        conf_int: Confidence level (0 < conf_int < 1).
        df: Degrees of freedom (scalar or per-coefficient array).
        alternative: "two-sided" (default), "greater", or "less".

    Returns:
        Critical value(s) from t-distribution. Scalar if df is scalar,
        array if df is array.

    Examples:
        >>> crit = compute_t_critical(0.95, df=10)
        >>> abs(crit - 2.228) < 0.01
        True
    """
    if not 0 < conf_int < 1:
        raise ValueError(f"conf_int must be between 0 and 1, got {conf_int}")

    alpha = 1 - conf_int
    if alternative == "two-sided":
        return stats.t.ppf(1 - alpha / 2, df=df)
    else:
        return stats.t.ppf(1 - alpha, df=df)


def compute_z_critical(conf_int: float, alternative: str = "two-sided") -> float:
    """Compute z-distribution critical value for confidence interval.

    Args:
        conf_int: Confidence level (0 < conf_int < 1).
        alternative: "two-sided" (default), "greater", or "less".

    Returns:
        Critical value from standard normal distribution.

    Examples:
        >>> crit = compute_z_critical(0.95)
        >>> abs(crit - 1.96) < 0.01
        True
    """
    if not 0 < conf_int < 1:
        raise ValueError(f"conf_int must be between 0 and 1, got {conf_int}")

    alpha = 1 - conf_int
    if alternative == "two-sided":
        return stats.norm.ppf(1 - alpha / 2)
    else:
        return stats.norm.ppf(1 - alpha)


def compute_se_from_vcov(vcov: np.ndarray) -> np.ndarray:
    """Compute standard errors from variance-covariance matrix.

    Args:
        vcov: Variance-covariance matrix of parameter estimates, shape (p, p).

    Returns:
        Standard errors for each parameter, shape (p,).

    Examples:
        >>> vcov = np.array([[0.04, 0.01], [0.01, 0.09]])
        >>> se = compute_se_from_vcov(vcov)
        >>> np.allclose(se, [0.2, 0.3])
        True
    """
    return np.sqrt(np.diag(vcov))


def compute_ci(
    estimate: np.ndarray,
    se: np.ndarray,
    critical: float | np.ndarray,
    alternative: str = "two-sided",
) -> tuple[np.ndarray, np.ndarray]:
    """Compute confidence interval bounds.

    Args:
        estimate: Point estimates.
        se: Standard errors.
        critical: Critical value(s) from distribution (t or z). Scalar or
            per-coefficient array that broadcasts with estimate and se.
        alternative: "two-sided" (default), "greater", or "less".
            - "greater": lower bound only, upper = +inf
            - "less": upper bound only, lower = -inf

    Returns:
        Tuple of (ci_lower, ci_upper) arrays with confidence bounds.

    Examples:
        >>> estimate = np.array([1.5, 2.0])
        >>> se = np.array([0.2, 0.3])
        >>> critical = 1.96
        >>> ci_lower, ci_upper = compute_ci(estimate, se, critical)
    """
    if alternative == "greater":
        ci_lower = estimate - critical * se
        ci_upper = np.full_like(estimate, np.inf)
    elif alternative == "less":
        ci_lower = np.full_like(estimate, -np.inf)
        ci_upper = estimate + critical * se
    else:
        ci_lower = estimate - critical * se
        ci_upper = estimate + critical * se

    return ci_lower, ci_upper


def compute_coefficient_inference(
    coef: np.ndarray,
    vcov: np.ndarray,
    df: float | np.ndarray | None,
    conf_level: float = 0.95,
    null: float = 0.0,
    alternative: str = "two-sided",
) -> InferenceResult:
    """Compute inference statistics for regression coefficients.

    Orchestrates computation of standard errors, test statistics, p-values,
    and confidence intervals for coefficient estimates.

    Args:
        coef: Coefficient estimates, shape (p,).
        vcov: Variance-covariance matrix, shape (p, p).
        df: Degrees of freedom for t-distribution. Scalar (same df for all
            coefficients), array of shape (p,) for per-coefficient df, or
            None for z-distribution.
        conf_level: Confidence level for intervals (default 0.95).
        null: Null hypothesis value (default 0.0). Statistic = (coef - null) / se.
        alternative: Direction of the alternative hypothesis.
            - "two-sided": H₁: β ≠ null (default)
            - "greater": H₁: β > null
            - "less": H₁: β < null

    Returns:
        InferenceResult with se, statistic, p_values, ci_lower, ci_upper, df_values.

    Examples:
        >>> coef = np.array([1.5, 2.0])
        >>> vcov = np.array([[0.04, 0.01], [0.01, 0.09]])
        >>> result = compute_coefficient_inference(coef, vcov, df=20)
        >>> result.se.shape
        (2,)
    """
    se = compute_se_from_vcov(vcov)

    # Compute test statistics: (coef - null) / se
    centered = coef - null
    statistic = np.divide(centered, se, out=np.full_like(coef, np.nan), where=se != 0)

    # Compute p-values — scipy.stats.t broadcasts over array df
    p_values = compute_pvalue(statistic, df=df, alternative=alternative)

    # Compute confidence intervals
    if df is not None:
        crit = compute_t_critical(conf_level, df=df, alternative=alternative)
        if isinstance(df, np.ndarray):
            df_values = df.astype(float).tolist()
        else:
            df_values = [float(df)] * len(coef)
    else:
        crit = compute_z_critical(conf_level, alternative=alternative)
        df_values = [float("inf")] * len(coef)

    ci_lower, ci_upper = compute_ci(coef, se, crit, alternative=alternative)

    return InferenceResult(
        se=se,
        statistic=statistic,
        p_values=p_values,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        df_values=df_values,
    )


def delta_method_se(X_pred: np.ndarray, vcov: np.ndarray) -> np.ndarray:
    """Compute standard errors for predictions via delta method.

    For predictions Xβ, the variance is: Var(Xβ) = X Var(β) X^T

    Args:
        X_pred: Design matrix for predictions, shape (n, p).
        vcov: Variance-covariance matrix of parameter estimates, shape (p, p).

    Returns:
        Standard errors for each prediction, shape (n,).

    Note:
        Uses efficient computation: SE_i = sqrt(sum((X_pred @ vcov) * X_pred, axis=1))
        which avoids forming the full quadratic form.

    Examples:
        >>> X_new = np.array([[1, 2], [1, 3]])
        >>> vcov = np.array([[0.1, 0.01], [0.01, 0.05]])
        >>> se = delta_method_se(X_new, vcov)
    """
    # Efficient computation: sqrt(diag(X @ vcov @ X^T))
    se = np.sqrt(np.sum((X_pred @ vcov) * X_pred, axis=1))
    return se
