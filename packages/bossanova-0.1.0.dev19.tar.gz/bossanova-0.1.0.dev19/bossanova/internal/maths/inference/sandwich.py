"""Sandwich covariance matrix estimators for robust standard errors.

Provides:
- HC0-HC3: Heteroscedasticity-consistent estimators for OLS/GLM.
- CR0-CR3: Cluster-robust estimators for mixed models, clustering by
  the random-effects grouping variable.
"""

__all__ = [
    "compute_cr_vcov",
    "compute_glm_cr_vcov",
    "compute_glm_hc_vcov",
    "compute_hc_vcov",
]

import numpy as np
from numpy.typing import NDArray


def compute_hc_vcov(
    X: NDArray[np.float64],
    residuals: NDArray[np.float64],
    XtX_inv: NDArray[np.float64],
    hc_type: str = "HC3",
) -> NDArray[np.float64]:
    """Compute heteroscedasticity-consistent covariance matrix.

    Implements the sandwich estimator: (X'X)^{-1} X' Omega X (X'X)^{-1}
    where Omega is a diagonal matrix of squared (possibly adjusted) residuals.

    Args:
        X: Design matrix, shape (n, p).
        residuals: OLS residuals, shape (n,).
        XtX_inv: (X'X)^{-1} from OLS, shape (p, p).
        hc_type: Type of HC estimator:
            - "HC0": White's original (no adjustment)
            - "HC1": df correction
            - "HC2": Leverage adjustment
            - "HC3": Squared leverage (default, most conservative)

    Returns:
        Heteroscedasticity-consistent covariance matrix, shape (p, p).

    Raises:
        ValueError: If hc_type is not one of HC0, HC1, HC2, HC3.
    """
    n, p = X.shape
    residuals = np.asarray(residuals, dtype=np.float64).ravel()

    if len(residuals) != n:
        raise ValueError(f"residuals length ({len(residuals)}) must match X rows ({n})")

    # Compute leverage (hat matrix diagonal): h_ii = x_i'(X'X)^{-1}x_i
    leverage = np.sum((X @ XtX_inv) * X, axis=1)

    # Compute omega (diagonal weights) based on HC type
    if hc_type == "HC0":
        omega = residuals**2
    elif hc_type == "HC1":
        omega = residuals**2 * (n / (n - p))
    elif hc_type == "HC2":
        omega = residuals**2 / (1 - leverage)
    elif hc_type == "HC3":
        omega = residuals**2 / (1 - leverage) ** 2
    else:
        raise ValueError(
            f"Unknown hc_type: {hc_type!r}. Use 'HC0', 'HC1', 'HC2', or 'HC3'."
        )

    # Sandwich formula: (X'X)^{-1} X' Omega X (X'X)^{-1}
    meat = X.T @ (X * omega[:, np.newaxis])
    vcov = XtX_inv @ meat @ XtX_inv

    return vcov


def compute_glm_hc_vcov(
    X: NDArray[np.float64],
    residuals: NDArray[np.float64],
    irls_weights: NDArray[np.float64],
    XtWX_inv: NDArray[np.float64],
    hc_type: str = "HC0",
) -> NDArray[np.float64]:
    """Compute heteroscedasticity-consistent covariance matrix for GLM.

    Implements the sandwich estimator for generalized linear models:
        (X'WX)^{-1} X'W Omega W X (X'WX)^{-1}

    where W are the IRLS weights and Omega accounts for variance misspecification.

    Args:
        X: Design matrix, shape (n, p).
        residuals: Response residuals (y - mu), shape (n,).
        irls_weights: IRLS weights from GLM fit, shape (n,).
        XtWX_inv: (X'WX)^{-1} from GLM fit, shape (p, p).
        hc_type: Type of HC estimator:
            - "HC0": No small-sample adjustment (default for GLM)
            - "HC1": df correction

    Returns:
        Heteroscedasticity-consistent covariance matrix, shape (p, p).
    """
    n, p = X.shape
    residuals = np.asarray(residuals, dtype=np.float64).ravel()
    irls_weights = np.asarray(irls_weights, dtype=np.float64).ravel()

    if len(residuals) != n:
        raise ValueError(f"residuals length ({len(residuals)}) must match X rows ({n})")
    if len(irls_weights) != n:
        raise ValueError(
            f"irls_weights length ({len(irls_weights)}) must match X rows ({n})"
        )

    omega = (irls_weights * residuals) ** 2

    if hc_type == "HC0":
        pass
    elif hc_type == "HC1":
        omega = omega * (n / (n - p))
    else:
        raise ValueError(f"Unknown hc_type for GLM: {hc_type!r}. Use 'HC0' or 'HC1'.")

    meat = X.T @ (X * omega[:, np.newaxis])
    vcov = XtWX_inv @ meat @ XtWX_inv

    return vcov


# =============================================================================
# Cluster-Robust (CR) estimators for mixed models
# =============================================================================


def compute_cr_vcov(
    X: NDArray[np.float64],
    residuals: NDArray[np.float64],
    cluster_ids: NDArray[np.intp],
    XtX_inv: NDArray[np.float64],
    cr_type: str = "CR0",
) -> NDArray[np.float64]:
    """Compute cluster-robust covariance matrix for Gaussian mixed models.

    Implements the sandwich estimator clustered by random-effects grouping
    variable: ``(X'X)^{-1} M (X'X)^{-1}`` where M sums outer products of
    per-cluster score vectors.

    Matches ``sandwich::vcovCL()`` in R.

    Args:
        X: Design matrix, shape (n, p).
        residuals: Marginal residuals ``y - X @ beta``, shape (n,).
        cluster_ids: Integer cluster labels, shape (n,). Values in ``[0, G)``.
        XtX_inv: ``(X'X)^{-1}`` from OLS, shape (p, p).
        cr_type: Type of CR estimator:
            - "CR0": No small-sample adjustment.
            - "CR1": ``G/(G-1) * (n-1)/(n-p)`` correction.
            - "CR2": Bell-McCaffrey bias-reduced (square-root leverage).
            - "CR3": Jackknife (inverse leverage, most conservative).

    Returns:
        Cluster-robust covariance matrix, shape (p, p).

    Raises:
        ValueError: If cr_type is not one of CR0-CR3.
    """
    n, p = X.shape
    residuals = np.asarray(residuals, dtype=np.float64).ravel()
    cluster_ids = np.asarray(cluster_ids)

    unique_clusters = np.unique(cluster_ids)
    G = len(unique_clusters)

    if cr_type in ("CR2", "CR3"):
        # Precompute per-cluster leverage and adjustments
        meat = np.zeros((p, p), dtype=np.float64)
        for g in unique_clusters:
            mask = cluster_ids == g
            X_g = X[mask]
            e_g = residuals[mask]
            n_g = mask.sum()

            # Per-cluster hat matrix: H_gg = X_g (X'X)^{-1} X_g'
            H_gg = X_g @ XtX_inv @ X_g.T

            I_g = np.eye(n_g)
            ImH = I_g - H_gg

            if cr_type == "CR3":
                # Jackknife: A_g = (I - H_gg)^{-1}
                A_g = np.linalg.inv(ImH)
            else:
                # CR2 Bell-McCaffrey: A_g = sqrtm((I - H_gg)^{-1})
                # Use eigendecomposition for matrix square root of inverse
                eigvals, eigvecs = np.linalg.eigh(ImH)
                # Clamp small eigenvalues for numerical stability
                eigvals = np.maximum(eigvals, 1e-12)
                A_g = eigvecs @ np.diag(1.0 / np.sqrt(eigvals)) @ eigvecs.T

            adjusted_e_g = A_g @ e_g
            score_g = X_g.T @ adjusted_e_g
            meat += np.outer(score_g, score_g)

        vcov = XtX_inv @ meat @ XtX_inv
        return vcov

    # CR0 and CR1: standard clustered sandwich
    meat = np.zeros((p, p), dtype=np.float64)
    for g in unique_clusters:
        mask = cluster_ids == g
        X_g = X[mask]
        e_g = residuals[mask]
        score_g = X_g.T @ e_g  # (p,)
        meat += np.outer(score_g, score_g)

    if cr_type == "CR0":
        pass
    elif cr_type == "CR1":
        meat *= (G / (G - 1)) * ((n - 1) / (n - p))
    else:
        raise ValueError(
            f"Unknown cr_type: {cr_type!r}. Use 'CR0', 'CR1', 'CR2', or 'CR3'."
        )

    vcov = XtX_inv @ meat @ XtX_inv
    return vcov


def compute_glm_cr_vcov(
    X: NDArray[np.float64],
    residuals: NDArray[np.float64],
    irls_weights: NDArray[np.float64],
    cluster_ids: NDArray[np.intp],
    XtWX_inv: NDArray[np.float64],
    cr_type: str = "CR0",
) -> NDArray[np.float64]:
    """Compute cluster-robust covariance matrix for non-Gaussian mixed models.

    Implements the weighted sandwich estimator clustered by random-effects
    grouping variable. Only CR0 and CR1 are supported (CR2/CR3 require
    leverage adjustments that are not well-defined for GLM).

    Args:
        X: Design matrix, shape (n, p).
        residuals: Response residuals ``y - mu``, shape (n,).
        irls_weights: IRLS weights from GLM fit, shape (n,).
        cluster_ids: Integer cluster labels, shape (n,). Values in ``[0, G)``.
        XtWX_inv: ``(X'WX)^{-1}`` from GLM fit, shape (p, p).
        cr_type: Type of CR estimator:
            - "CR0": No small-sample adjustment (default).
            - "CR1": ``G/(G-1) * (n-1)/(n-p)`` correction.

    Returns:
        Cluster-robust covariance matrix, shape (p, p).

    Raises:
        ValueError: If cr_type is not CR0 or CR1.
    """
    n, p = X.shape
    residuals = np.asarray(residuals, dtype=np.float64).ravel()
    irls_weights = np.asarray(irls_weights, dtype=np.float64).ravel()
    cluster_ids = np.asarray(cluster_ids)

    if len(residuals) != n:
        raise ValueError(f"residuals length ({len(residuals)}) must match X rows ({n})")
    if len(irls_weights) != n:
        raise ValueError(
            f"irls_weights length ({len(irls_weights)}) must match X rows ({n})"
        )

    unique_clusters = np.unique(cluster_ids)
    G = len(unique_clusters)

    # Weighted meat: sum of outer(X_g' W_g e_g, X_g' W_g e_g)
    meat = np.zeros((p, p), dtype=np.float64)
    for g in unique_clusters:
        mask = cluster_ids == g
        X_g = X[mask]
        e_g = residuals[mask]
        w_g = irls_weights[mask]
        score_g = X_g.T @ (w_g * e_g)  # (p,)
        meat += np.outer(score_g, score_g)

    if cr_type == "CR0":
        pass
    elif cr_type == "CR1":
        meat *= (G / (G - 1)) * ((n - 1) / (n - p))
    else:
        raise ValueError(f"Unknown cr_type for GLMER: {cr_type!r}. Use 'CR0' or 'CR1'.")

    vcov = XtWX_inv @ meat @ XtWX_inv
    return vcov
