"""Core LMM operations: PLS solving and deviance computation.

This module implements the Penalized Least Squares (PLS) formulation for linear
mixed models, matching lme4's canonical approach.

The PLS system solves:
    minimize: ||y - X*β - Z*Λ*u||² + ||u||²

where:
- X is the fixed effects design matrix
- Z is the random effects design matrix
- Λ is the Cholesky-like factor from theta parameters
- u are spherical random effects (u ~ N(0, I))

Architecture:
- Uses scipy.sparse for sparse matrices and scikit-sparse for CHOLMOD
- Dense linear algebra via backend (JAX JIT or NumPy), dispatched through _jit_cache
- Returns NumPy arrays for downstream processing

lme4 Algorithm Reference:
    lme4 factors only S22 = Λ'Z'ZΛ + I (not the full augmented system)
    and uses the Schur complement to solve for beta. See:
    - lme4/src/predModule.cpp lines 263-301 (updateDecomp)
    - lme4/src/predModule.cpp lines 189-203 (solve)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import numpy as np
import scipy.sparse as sp

from bossanova.internal.maths.backend import get_backend, get_ops
from bossanova.internal.maths.linalg.sparse import compute_sparse_cholesky

if TYPE_CHECKING:
    from bossanova.internal.maths.solvers.lambda_builder import LambdaTemplate

__all__ = [
    "PLSInvariants",
    "apply_sqrt_weights",
    "compute_pls_invariants",
    "lmm_deviance_sparse",
    "solve_pls_sparse",
]


# =============================================================================
# Weight Transformations
# =============================================================================


def apply_sqrt_weights(
    X: np.ndarray,
    Z: sp.csc_matrix,
    y: np.ndarray,
    weights: np.ndarray | None,
) -> tuple[np.ndarray, sp.csc_matrix, np.ndarray, np.ndarray | None]:
    """Apply sqrt(weights) transformation to design matrices and response.

    Transforms the weighted LMM problem into an unweighted problem on
    transformed data. This is the standard approach from lme4 and MixedModels.jl.

    For weighted LMM:
        minimize ||W^{1/2}(y - Xβ - ZΛu)||² + ||u||²

    After transformation (X_w, Z_w, y_w = W^{1/2}X, W^{1/2}Z, W^{1/2}y):
        minimize ||y_w - X_w·β - Z_w·Λu||² + ||u||²

    This is the standard unweighted PLS, so the same solver applies.

    Args:
        X: Fixed effects design matrix, shape (n, p).
        Z: Random effects design matrix, sparse csc, shape (n, q).
        y: Response vector, shape (n,).
        weights: Observation weights, shape (n,), or None for unweighted.

    Returns:
        Tuple of (X_w, Z_w, y_w, sqrtwts) where:
            X_w: Transformed X, shape (n, p)
            Z_w: Transformed Z, sparse csc, shape (n, q)
            y_w: Transformed y, shape (n,)
            sqrtwts: sqrt(weights), shape (n,), or None if weights is None
    """
    if weights is None:
        return X, Z, y, None

    sqrtwts = np.sqrt(weights)

    # Transform X: W^{1/2} @ X (row-wise multiplication)
    X_w = sqrtwts[:, np.newaxis] * X

    # Transform y: W^{1/2} @ y (element-wise)
    y_w = sqrtwts * y

    # Transform Z: W^{1/2} @ Z (row-wise multiplication on sparse matrix)
    # For sparse csc matrix, multiply each row by corresponding sqrtwt
    Z_w = sp.diags(sqrtwts, format="csr") @ Z
    Z_w = Z_w.tocsc()

    return X_w, Z_w, y_w, sqrtwts


# =============================================================================
# Pre-computed Invariants (computed once per model)
# =============================================================================


@dataclass(frozen=True, slots=True)
class PLSInvariants:
    """Pre-computed quantities that don't change during theta optimization.

    These are computed once when the model is set up and reused for every
    deviance evaluation during BOBYQA optimization.

    Attributes:
        XtX: Gram matrix X'X, shape (p, p). Backend array (JAX or NumPy).
        Xty: Cross-product X'y, shape (p,). Backend array.
        X_backend: Fixed effects design matrix as backend array, shape (n, p).
        y_backend: Response vector as backend array, shape (n,).
    """

    XtX: np.ndarray
    Xty: np.ndarray
    X_backend: np.ndarray
    y_backend: np.ndarray


def compute_pls_invariants(X: np.ndarray, y: np.ndarray) -> PLSInvariants:
    """Pre-compute quantities that are constant during optimization.

    Call this once before the optimization loop to avoid redundant computation.
    X'X and X'y don't depend on theta, so computing them once saves work.

    Args:
        X: Fixed effects design matrix, shape (n, p).
        y: Response vector, shape (n,).

    Returns:
        PLSInvariants with pre-computed X'X, X'y, and backend arrays.

    Examples:
        >>> X = np.random.randn(100, 3)
        >>> y = np.random.randn(100)
        >>> inv = compute_pls_invariants(X, y)
        >>> inv.XtX.shape
        (3, 3)
    """
    ops = get_ops()
    xp = ops.np
    X_be = xp.asarray(X)
    y_be = xp.asarray(y)
    XtX = X_be.T @ X_be
    Xty = X_be.T @ y_be

    return PLSInvariants(XtX=XtX, Xty=Xty, X_backend=X_be, y_backend=y_be)


# =============================================================================
# JIT-Cached Dense Operations (backend-aware)
# =============================================================================

# Cache keyed by backend name. Cleared on backend switch via set_backend().
_jit_cache: dict[str, Any] = {}


def _make_dense_ops(ops: Any) -> dict[str, Any]:
    """Create JIT-compiled dense algebra functions for the given backend.

    Args:
        ops: ArrayOps instance (JAXBackend or NumPyBackend).

    Returns:
        Dict mapping function names to (possibly JIT-compiled) callables.
    """
    xp = ops.np

    def _compute_schur_complement(
        XtX: np.ndarray,
        XtZL: np.ndarray,
        S22_inv_XtZL_T: np.ndarray,
    ) -> np.ndarray:
        return XtX - XtZL @ S22_inv_XtZL_T

    def _solve_beta_and_u(
        schur: np.ndarray,
        Xty: np.ndarray,
        XtZL: np.ndarray,
        cu: np.ndarray,
        S22_inv_XtZL_T: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        rhs_beta = Xty - XtZL @ cu
        beta = xp.linalg.solve(schur, rhs_beta)
        u = cu - S22_inv_XtZL_T @ beta
        return beta, u

    def _compute_logdet_schur(schur: np.ndarray) -> np.ndarray:
        RX = xp.linalg.cholesky(schur)
        return 2.0 * xp.sum(xp.log(xp.diag(RX)))

    def _compute_rss(
        y: np.ndarray,
        X: np.ndarray,
        ZL: np.ndarray,
        beta: np.ndarray,
        u: np.ndarray,
    ) -> np.ndarray:
        residuals = y - X @ beta - ZL @ u
        return xp.sum(residuals**2)

    return {
        "schur": ops.jit(_compute_schur_complement),
        "solve": ops.jit(_solve_beta_and_u),
        "logdet": ops.jit(_compute_logdet_schur),
        "rss": ops.jit(_compute_rss),
    }


def _get_dense_ops() -> dict[str, Any]:
    """Get cached JIT-compiled dense operations for the current backend.

    Returns:
        Dict mapping function names to compiled callables.
    """
    backend = get_backend()
    if backend not in _jit_cache:
        _jit_cache[backend] = _make_dense_ops(get_ops())
    return _jit_cache[backend]


def compute_schur_complement(
    XtX: np.ndarray,
    XtZL: np.ndarray,
    S22_inv_XtZL_T: np.ndarray,
) -> np.ndarray:
    """Compute Schur complement of the augmented system.

    The Schur complement is: X'X - X'ZΛ * S22^{-1} * Λ'Z'X

    This is the (1,1) block of the inverse of the augmented system,
    and represents the "effective" precision of beta after accounting
    for random effects.

    Args:
        XtX: Fixed effects Gram matrix X'X, shape (p, p).
        XtZL: Cross-product X'ZΛ, shape (p, q).
        S22_inv_XtZL_T: S22^{-1} * (X'ZΛ)', from CHOLMOD, shape (q, p).

    Returns:
        Schur complement matrix, shape (p, p).
    """
    return _get_dense_ops()["schur"](XtX, XtZL, S22_inv_XtZL_T)


def solve_beta_and_u(
    schur: np.ndarray,
    Xty: np.ndarray,
    XtZL: np.ndarray,
    cu: np.ndarray,
    S22_inv_XtZL_T: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Solve for fixed effects (beta) and spherical random effects (u).

    Uses the Schur complement to solve the blocked system:
        [X'X      X'ZΛ  ] [β]   [X'y  ]
        [Λ'Z'X   S22    ] [u] = [Λ'Z'y]

    Algorithm:
        1. beta = schur^{-1} * (X'y - X'ZΛ * cu)  where cu = S22^{-1} * Λ'Z'y
        2. u = cu - S22^{-1} * Λ'Z'X * beta

    Args:
        schur: Schur complement matrix, shape (p, p).
        Xty: Cross-product X'y, shape (p,).
        XtZL: Cross-product X'ZΛ, shape (p, q).
        cu: Intermediate S22^{-1} * Λ'Z'y from CHOLMOD, shape (q,).
        S22_inv_XtZL_T: S22^{-1} * (X'ZΛ)' from CHOLMOD, shape (q, p).

    Returns:
        Tuple of (beta, u):
        - beta: Fixed effects coefficients, shape (p,).
        - u: Spherical random effects, shape (q,).
    """
    return _get_dense_ops()["solve"](schur, Xty, XtZL, cu, S22_inv_XtZL_T)


def compute_logdet_schur(schur: np.ndarray) -> np.ndarray:
    """Compute log-determinant of Schur complement via Cholesky.

    For REML estimation, we need log|X'V^{-1}X| which equals log|schur|.
    Using Cholesky: log|A| = 2 * sum(log(diag(chol(A)))).

    Args:
        schur: Schur complement matrix (positive definite), shape (p, p).

    Returns:
        Log-determinant as scalar.
    """
    return _get_dense_ops()["logdet"](schur)


def compute_rss(
    y: np.ndarray,
    X: np.ndarray,
    ZL: np.ndarray,
    beta: np.ndarray,
    u: np.ndarray,
) -> np.ndarray:
    """Compute residual sum of squares.

    RSS = ||y - X*beta - ZΛ*u||²

    This is the squared norm of residuals after removing both
    fixed effects and (scaled) random effects.

    Args:
        y: Response vector, shape (n,).
        X: Fixed effects design matrix, shape (n, p).
        ZL: Random effects design ZΛ, shape (n, q).
        beta: Fixed effects coefficients, shape (p,).
        u: Spherical random effects, shape (q,).

    Returns:
        RSS as scalar.
    """
    return _get_dense_ops()["rss"](y, X, ZL, beta, u)


def solve_pls_sparse(
    X: np.ndarray,
    Z: sp.csc_matrix,
    Lambda: sp.csc_matrix,
    y: np.ndarray,
    pls_invariants: PLSInvariants | None = None,
) -> dict:
    """Solve Penalized Least Squares system using Schur complement.

    Uses lme4's algorithm: factor only S22 = Λ'Z'ZΛ + I, then use Schur
    complement to solve for beta. This avoids factoring the full augmented
    system.

    Algorithm (matching lme4/src/predModule.cpp):
        1. Factor S22 = Λ'Z'ZΛ + I via CHOLMOD
        2. Compute RZX = L^{-1} * Λ'Z'X (forward solve)
        3. Compute Schur = X'X - RZX' * RZX (rank update)
        4. Solve for beta via Schur complement
        5. Back-solve for u

    Memory efficiency:
        ZΛ is kept sparse throughout. For InstEval-scale data (73k obs × 4k
        groups), this uses ~50MB instead of ~2.4GB per iteration.

    Args:
        X: Fixed effects design matrix, shape (n, p).
        Z: Random effects design matrix, shape (n, q), scipy sparse CSC.
        Lambda: Cholesky-like factor, shape (q, q), scipy sparse CSC.
        y: Response vector, shape (n,).
        pls_invariants: Optional pre-computed invariants (X'X, X'y, backend arrays).
            If provided, avoids redundant computation in optimization loop.
            Use compute_pls_invariants() to create this before the loop.

    Returns:
        Dictionary with keys:
        - beta: Fixed effects coefficients, shape (p,).
        - u: Spherical random effects, shape (q,).
        - logdet_L: Log-determinant of (Λ'Z'ZΛ + I).
        - rss: Residual sum of squares ||y - Xβ - ZΛu||².
        - logdet_RX: Log-determinant of Schur complement (for REML).

    Examples:
        >>> import numpy as np
        >>> import scipy.sparse as sp
        >>> n, p, q = 100, 3, 10
        >>> X = np.random.randn(n, p)
        >>> Z = sp.random(n, q, density=0.1, format='csc')
        >>> Lambda = sp.eye(q, format='csc')
        >>> y = np.random.randn(n)
        >>> result = solve_pls_sparse(X, Z, Lambda, y)
        >>> result['beta'].shape
        (3,)
        >>> result['u'].shape
        (10,)

    Notes:
        - Converts Z and Lambda to CSC format if needed (CHOLMOD requirement)
        - Uses CHOLMOD for numerically stable sparse Cholesky of S22
        - Dense linear algebra uses JIT-compiled functions (via _get_dense_ops)
        - ZΛ stays sparse; cross-products use efficient sparse-dense ops
        - Returns RSS without penalty term (PWRSS = RSS + ||u||²)
    """
    ops = get_ops()
    xp = ops.np

    # Ensure CSC format for CHOLMOD
    if not sp.isspmatrix_csc(Z):
        Z = Z.tocsc()
    if not sp.isspmatrix_csc(Lambda):
        Lambda = Lambda.tocsc()

    q = Lambda.shape[0]

    # Compute ZΛ (sparse @ sparse = sparse) - KEEP SPARSE throughout
    ZL = Z @ Lambda

    # Build S22 = Λ'Z'ZΛ + I (sparse) - the ONLY matrix we factor
    # Ensure CSC format for CHOLMOD (ZL.T @ ZL may produce CSR)
    ZLtZL = (ZL.T @ ZL).tocsc()
    S22 = ZLtZL + sp.eye(q, format="csc")

    # Sparse factorization of S22 (CHOLMOD or splu)
    factor_S22 = compute_sparse_cholesky(S22)
    logdet_L = factor_S22.logdet()

    # --- Cross-products using sparse-dense operations ---
    # These produce small dense arrays: (q, p) and (q,)
    # Use pre-computed invariants if provided, otherwise compute on the fly
    if pls_invariants is not None:
        X_be = pls_invariants.X_backend
        y_be = pls_invariants.y_backend
        XtX = pls_invariants.XtX
        Xty = pls_invariants.Xty
        # For sparse ops, we need numpy arrays
        X_np = np.asarray(X_be)
        y_np = np.asarray(y_be)
    else:
        X_np = X
        y_np = y
        X_be = xp.asarray(X)
        y_be = xp.asarray(y)
        XtX = X_be.T @ X_be
        Xty = X_be.T @ y_be

    # Compute theta-dependent cross-products via sparse-dense ops
    # ZL.T @ X: sparse (q,n) @ dense (n,p) -> dense (q,p) - efficient!
    # ZL.T @ y: sparse (q,n) @ dense (n,) -> dense (q,) - efficient!
    XtZL_np = (ZL.T @ X_np).T  # (p, q) - transpose for consistency
    ZLty_np = ZL.T @ y_np  # (q,)

    # Convert to backend arrays for downstream operations
    XtZL = xp.asarray(XtZL_np)

    # Compute RZX = L^{-1} * (Λ'Z'X) via forward solve
    # This is factor_S22 solving S22 @ x = XtZL.T
    S22_inv_XtZL_T = factor_S22(XtZL_np.T)  # Shape: (q, p)
    S22_inv_XtZL_T_be = xp.asarray(S22_inv_XtZL_T)

    # Compute Schur complement via JIT-compiled function
    schur = compute_schur_complement(XtX, XtZL, S22_inv_XtZL_T_be)

    # Solve for cu = S22^{-1} * Λ'Z'y (intermediate for u)
    cu = factor_S22(ZLty_np)  # Shape: (q,)
    cu_be = xp.asarray(cu)

    # Solve for beta and u via JIT-compiled function
    # On NumPy backend, linalg.solve/cholesky raise LinAlgError
    # for singular Schur complement. JAX returns NaN silently. Match JAX
    # behavior by catching the error and returning inf deviance components
    # so the optimizer moves away from this theta region (lme4 strategy).
    try:
        beta, u = solve_beta_and_u(schur, Xty, XtZL, cu_be, S22_inv_XtZL_T_be)
        logdet_RX = compute_logdet_schur(schur)
    except np.linalg.LinAlgError:
        p = X_np.shape[1]
        return {
            "beta": np.full(p, np.nan),
            "u": np.full(q, np.nan),
            "logdet_L": float(logdet_L),
            "rss": np.inf,
            "logdet_RX": np.inf,
        }

    # Compute residual sum of squares using sparse matvec
    # RSS = ||y - X*beta - ZΛ*u||²
    # This is efficient: sparse (n,q) @ dense (q,) -> dense (n,)
    beta_np = np.asarray(beta)
    u_np = np.asarray(u)
    fitted_fixed = X_np @ beta_np  # dense (n,)
    fitted_random = ZL @ u_np  # sparse @ dense -> dense (n,)
    residuals = y_np - fitted_fixed - fitted_random
    rss = float(np.sum(residuals**2))

    # Convert back to numpy for return
    return {
        "beta": beta_np,
        "u": u_np,
        "logdet_L": float(logdet_L),
        "rss": rss,
        "logdet_RX": float(logdet_RX),
    }


def lmm_deviance_sparse(
    theta: np.ndarray,
    X: np.ndarray,
    Z: sp.csc_matrix,
    y: np.ndarray,
    n_groups_list: list[int],
    re_structure: str,
    method: str = "REML",
    lambda_template: "LambdaTemplate | None" = None,
    pls_invariants: PLSInvariants | None = None,
    metadata: dict | None = None,
    sqrtwts: np.ndarray | None = None,
) -> float:
    """Compute LMM deviance for optimization.

    The deviance is -2 * log-likelihood, profiled over β and σ².

    For ML:
        -2 log L = log|Λ'Z'ZΛ+I| + n*log(2π*PWRSS/n) + n

    For REML:
        -2 REML = log|Λ'Z'ZΛ+I| + log|X'V⁻¹X| + (n-p)*log(2π*PWRSS/(n-p)) + (n-p)

    For weighted models, the deviance includes an additional adjustment:
        -log|W| = -2*sum(log(sqrtwts))

    This follows lme4 and MixedModels.jl: X, Z, y should already be
    pre-transformed by sqrt(weights) using apply_sqrt_weights().

    Args:
        theta: Cholesky factor elements (lower triangle, column-major).
        X: Fixed effects design matrix, shape (n, p). Should be pre-transformed
            by sqrt(weights) if weighted.
        Z: Random effects design matrix, shape (n, q), scipy sparse. Should be
            pre-transformed by sqrt(weights) if weighted.
        y: Response vector, shape (n,). Should be pre-transformed by
            sqrt(weights) if weighted.
        n_groups_list: Number of groups per grouping factor.
        re_structure: Random effects structure type.
            Options: "intercept", "slope", "diagonal", "nested", "crossed", "mixed"
        method: Estimation method, either "ML" or "REML".
        lambda_template: Optional pre-built template for efficient Lambda updates.
            If provided, uses update_lambda_from_template instead of build_lambda_sparse.
            This avoids rebuilding the sparsity pattern on each call.
        pls_invariants: Optional pre-computed invariants (X'X, X'y, JAX arrays).
            If provided, avoids redundant matrix computation in optimization loop.
            Use compute_pls_invariants() to create this before the loop.
        metadata: Optional metadata dict with structure information.
            Required for crossed/nested/mixed structures with non-intercept factors.
            Should contain 're_structures_list' specifying each factor's structure.
        sqrtwts: Optional sqrt(weights), shape (n,). If provided, adds the
            log-determinant adjustment -2*sum(log(sqrtwts)) to the deviance.
            This compensates for the Jacobian from the weight transformation.

    Returns:
        Deviance value (scalar).

    Examples:
        >>> import numpy as np
        >>> import scipy.sparse as sp
        >>> # Simple random intercept model
        >>> theta = np.array([1.5])
        >>> X = np.random.randn(100, 2)
        >>> Z = sp.random(100, 10, density=0.1, format='csc')
        >>> y = np.random.randn(100)
        >>> dev = lmm_deviance_sparse(theta, X, Z, y, [10], "intercept", "REML")
        >>> dev > 0
        True

    Notes:
        - Requires lambda_builder module for building Λ from theta
        - Returns ML deviance if method="ML", REML criterion if method="REML"
        - Used as objective function in BOBYQA optimization
        - Pass lambda_template for ~10-20% speedup in optimization loop
        - Pass pls_invariants for additional speedup (avoids X'X, X'y computation)
        - For weighted models, pass sqrtwts and pre-transformed X, Z, y
    """
    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_sparse,
        update_lambda_from_template,
    )

    n, p = X.shape

    # Build Lambda from theta (use template if provided)
    if lambda_template is not None:
        Lambda = update_lambda_from_template(lambda_template, theta)
    else:
        Lambda = build_lambda_sparse(theta, n_groups_list, re_structure, metadata)

    # Solve PLS (pass invariants if provided)
    result = solve_pls_sparse(X, Z, Lambda, y, pls_invariants=pls_invariants)
    u = result["u"]
    logdet_L = result["logdet_L"]
    rss = result["rss"]
    logdet_RX = result["logdet_RX"]

    # Early exit for singular Schur (NumPy: inf from catch, JAX: NaN from
    # silent degradation). Return +inf so optimizer moves to a better theta.
    if not np.isfinite(rss):
        return np.inf

    # Penalized residual sum of squares
    pwrss = rss + np.sum(u**2)

    # Compute deviance
    if method == "ML":
        # ML deviance
        deviance = logdet_L + n * (1.0 + np.log(2.0 * np.pi * pwrss / n))
    elif method == "REML":
        # REML criterion
        deviance = (
            logdet_L
            + logdet_RX
            + (n - p) * (1.0 + np.log(2.0 * np.pi * pwrss / (n - p)))
        )
    else:
        raise ValueError(f"Unknown method: {method}. Use 'ML' or 'REML'.")

    # Guard against NaN deviance (e.g., JAX Cholesky on singular Schur
    # returns NaN logdet_RX which propagates). Return +inf for optimizer.
    if not np.isfinite(deviance):
        return np.inf

    # Weight adjustment: -log|W| = -2*sum(log(sqrtwts))
    # This compensates for the Jacobian from the sqrt(W) transformation.
    # See lme4 respModule.cpp line 94-99 and MixedModels.jl linearmixedmodel.jl
    if sqrtwts is not None:
        log_det_W = 2.0 * np.sum(np.log(sqrtwts))
        deviance = deviance - log_det_W

    return float(deviance)
