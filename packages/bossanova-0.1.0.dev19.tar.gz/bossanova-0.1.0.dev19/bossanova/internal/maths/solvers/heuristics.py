"""Heuristics and numerical utilities for GLMM fitting.

This module contains initialization heuristics, bound computation, and
finite-difference derivative routines used by the GLMM fitter in ``glmer.py``.

Functions:
    init_theta_glmm: Conservative theta initialization for GLMMs.
    get_theta_lower_bounds: Lower bounds for theta parameters (Cholesky constraint).
    deriv12: Central finite-difference gradient and Hessian (matches lme4's deriv12).
    compute_hessian_vcov: Hessian-based variance-covariance for fixed effects.
"""

from collections.abc import Callable

import numpy as np
import scipy.sparse as sp

from bossanova.internal.maths.family import Family

__all__ = [
    "compute_hessian_vcov",
    "deriv12",
    "get_theta_lower_bounds",
    "init_theta_glmm",
]


def init_theta_glmm(
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
) -> np.ndarray:
    """Initialize theta for GLMM fitting.

    Uses conservative defaults. Unlike LMMs, GLMMs work on the link scale
    so moment-based initialization is less useful.

    Args:
        n_groups_list: Number of groups per grouping factor.
        re_structure: Random effects structure type.
        metadata: Optional metadata dict containing 'random_names' or 're_terms'
            to determine correct number of theta parameters.

    Returns:
        Initial theta values.
    """
    if re_structure == "intercept":
        # One variance component per grouping factor
        return np.array([1.0] * len(n_groups_list))
    elif re_structure == "diagonal":
        # One variance component per RE term (uncorrelated slopes from || syntax)
        # Get number of terms from metadata
        n_terms = 1  # Default fallback
        if metadata:
            if "random_names" in metadata:
                n_terms = len(metadata["random_names"])
            elif "re_terms" in metadata:
                n_terms = len(metadata["re_terms"])
        return np.array([0.5] * n_terms)
    elif re_structure == "slope":
        # Cholesky factor: n_terms*(n_terms+1)/2 parameters
        # Get number of terms from metadata
        n_terms = 2  # Default: intercept + 1 slope
        if metadata:
            if "random_names" in metadata:
                n_terms = len(metadata["random_names"])
            elif "re_terms" in metadata:
                n_terms = len(metadata["re_terms"])
        # Build initial Cholesky: diagonal = [1.0, 0.5, 0.5, ...], off-diag = 0
        n_theta = n_terms * (n_terms + 1) // 2
        theta = np.zeros(n_theta)
        idx = 0
        for col in range(n_terms):
            for row in range(col, n_terms):
                if row == col:
                    theta[idx] = 1.0 if col == 0 else 0.5
                # Off-diagonal stays 0
                idx += 1
        return theta
    elif re_structure in ("crossed", "nested", "mixed"):
        # Crossed/nested/mixed: compute theta for each factor based on its structure
        re_structures_list = metadata.get("re_structures_list") if metadata else None

        if re_structures_list is None:
            # Fallback: assume all intercepts (one theta per factor)
            return np.array([1.0] * len(n_groups_list))

        # Compute theta for each factor based on its structure
        theta_list = []
        for factor_structure in re_structures_list:
            if factor_structure == "intercept":
                theta_list.append(1.0)
            elif factor_structure == "slope":
                # 2x2 Cholesky: [L00, L10, L11] = 3 params
                theta_list.extend([1.0, 0.0, 0.5])
            elif factor_structure == "diagonal":
                # Default to 2 terms (intercept + slope, uncorrelated)
                theta_list.extend([0.5, 0.5])
            else:
                theta_list.append(1.0)

        return np.array(theta_list)
    else:
        return np.array([1.0])


def get_theta_lower_bounds(
    n_theta: int,
    re_structure: str,
    metadata: dict | None = None,
) -> list[float]:
    """Get lower bounds for theta parameters.

    Diagonal elements of Cholesky factor must be non-negative.
    Off-diagonal elements are unbounded.

    Args:
        n_theta: Number of theta parameters
        re_structure: Random effects structure type
        metadata: Optional metadata dict with 're_structures_list' for
            crossed/nested/mixed structures

    Returns:
        List of lower bounds
    """
    if re_structure in ("intercept", "diagonal"):
        # All theta are diagonal elements
        return [0.0] * n_theta
    elif re_structure == "slope":
        # Cholesky factor: diagonal >= 0, off-diagonal unbounded
        dim = int((-1 + np.sqrt(1 + 8 * n_theta)) / 2)
        bounds = []
        for col in range(dim):
            for row in range(col, dim):
                if row == col:
                    bounds.append(0.0)
                else:
                    bounds.append(float("-inf"))
        return bounds
    elif re_structure in ("crossed", "nested", "mixed"):
        # Crossed/nested/mixed: compute bounds for each factor based on its structure
        re_structures_list = metadata.get("re_structures_list") if metadata else None

        if re_structures_list is None:
            # Fallback: assume all intercepts (all bounds = 0)
            return [0.0] * n_theta

        bounds = []
        for factor_structure in re_structures_list:
            if factor_structure == "intercept":
                bounds.append(0.0)
            elif factor_structure == "slope":
                # 2x2 Cholesky: [L00, L10, L11]
                bounds.extend([0.0, float("-inf"), 0.0])
            elif factor_structure == "diagonal":
                bounds.extend([0.0, 0.0])
            else:
                bounds.append(0.0)

        return bounds
    else:
        # Conservative: all non-negative
        return [0.0] * n_theta


def deriv12(
    func: Callable[[np.ndarray], float],
    x: np.ndarray,
    delta: float = 1e-4,
    fx: float | None = None,
) -> dict:
    """Compute gradient and Hessian using central finite differences.

    This matches lme4's deriv12() function exactly (lme4/R/deriv.R).
    Uses simple central differences with step size delta.

    The Hessian is computed simultaneously with the gradient for efficiency:
    - Diagonal: H[j,j] = (f(x+d) - 2f(x) + f(x-d)) / d^2
    - Off-diag: H[i,j] = (f(x+di+dj) - f(x+di-dj) - f(x-di+dj) + f(x-di-dj)) / (4d^2)

    Args:
        func: Scalar function R^n -> R to differentiate.
        x: Point at which to compute derivatives, shape (n,).
        delta: Step size for finite differences (default 1e-4, matches lme4).
        fx: Optional pre-computed f(x) to avoid redundant evaluation.

    Returns:
        Dictionary with:
            - "gradient": First derivative vector, shape (n,)
            - "Hessian": Second derivative matrix, shape (n, n)

    Note:
        This is O(h^2) accurate, matching lme4's approach. For higher accuracy
        (O(h^8)), use compute_hessian_richardson from bossanova.internal.maths.differentiation.
    """
    x = np.asarray(x, dtype=np.float64)
    n = len(x)

    if fx is None:
        fx = func(x)

    H = np.zeros((n, n), dtype=np.float64)
    g = np.zeros(n, dtype=np.float64)

    # Perturbed points
    x_add = x + delta
    x_sub = x - delta

    for j in range(n):
        # Evaluate at x + delta*e_j and x - delta*e_j
        x_plus_j = x.copy()
        x_plus_j[j] = x_add[j]
        f_add = func(x_plus_j)

        x_minus_j = x.copy()
        x_minus_j[j] = x_sub[j]
        f_sub = func(x_minus_j)

        # Diagonal Hessian element: (f(x+d) - 2f(x) + f(x-d)) / d^2
        H[j, j] = (f_add - 2.0 * fx + f_sub) / (delta**2)

        # Gradient: (f(x+d) - f(x-d)) / (2d)
        g[j] = (f_add - f_sub) / (2.0 * delta)

        # Off-diagonal elements (upper triangle, then mirror)
        for i in range(j):
            # Four-point stencil for mixed partial
            x_pp = x.copy()
            x_pp[i] = x_add[i]
            x_pp[j] = x_add[j]

            x_pm = x.copy()
            x_pm[i] = x_add[i]
            x_pm[j] = x_sub[j]

            x_mp = x.copy()
            x_mp[i] = x_sub[i]
            x_mp[j] = x_add[j]

            x_mm = x.copy()
            x_mm[i] = x_sub[i]
            x_mm[j] = x_sub[j]

            # Mixed partial: (f++ - f+- - f-+ + f--) / (4d^2)
            H[i, j] = (func(x_pp) - func(x_pm) - func(x_mp) + func(x_mm)) / (
                4.0 * delta**2
            )
            H[j, i] = H[i, j]  # Symmetric

    return {"gradient": g, "Hessian": H}


def compute_hessian_vcov(
    theta: np.ndarray,
    beta: np.ndarray,
    X: np.ndarray,
    Z: sp.csc_matrix,
    y: np.ndarray,
    family: Family,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
    prior_weights: np.ndarray | None = None,
    pirls_max_iter: int = 30,
    pirls_tol: float = 1e-7,
    delta: float = 1e-4,
    eta_init: np.ndarray | None = None,
) -> tuple[np.ndarray, dict]:
    """Compute Hessian-based vcov for fixed effects.

    Matches lme4's use.hessian=TRUE approach:
    1. Compute numerical Hessian of deviance w.r.t. [theta, beta]
    2. Invert the Hessian
    3. Extract beta-beta block
    4. Symmetrize

    This uses lme4's deriv12() approach (simple central differences with
    delta=1e-4) for exact parity with R.

    Args:
        theta: Final theta (variance component) estimates
        beta: Final beta (fixed effect) estimates
        X: Fixed effects design matrix (n, p)
        Z: Random effects design matrix (n, q), scipy sparse
        y: Response vector (n,)
        family: GLM family (binomial, poisson)
        n_groups_list: Number of groups per grouping factor
        re_structure: Random effects structure type
        metadata: Additional RE metadata
        prior_weights: Prior observation weights
        pirls_max_iter: Maximum PIRLS iterations per deviance evaluation
        pirls_tol: PIRLS convergence tolerance
        delta: Finite difference step size (default 1e-4, matches lme4)
        eta_init: Initial linear predictor for PIRLS. If provided, used as
            starting point for all deviance evaluations. This provides
            numerical stability for models with large random effects.

    Returns:
        Tuple of:
            - vcov_beta: Variance-covariance matrix for beta, shape (p, p)
            - derivs: Dictionary with "gradient" and "Hessian" (for diagnostics)

    Notes:
        If the Hessian is not positive definite, this function returns the
        pseudo-inverse of the beta-beta block, with a warning.
    """
    import warnings

    # Deferred import to avoid circular dependency:
    # heuristics -> glmer -> heuristics
    from bossanova.internal.maths.solvers.glmer import (
        glmm_deviance_at_fixed_theta_beta,
    )

    n_theta = len(theta)

    # Combined parameter vector [theta, beta] - matches lme4 ordering
    params = np.concatenate([theta, beta])

    # Deviance function over [theta, beta]
    # Uses eta_init as starting point for PIRLS, providing stability for
    # models with large random effects (like intercept-only Poisson GLMMs).
    def deviance_fn(p: np.ndarray) -> float:
        t = p[:n_theta]
        b = p[n_theta:]
        return glmm_deviance_at_fixed_theta_beta(
            theta=t,
            beta=b,
            X=X,
            Z=Z,
            y=y,
            family=family,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            metadata=metadata,
            prior_weights=prior_weights,
            pirls_max_iter=pirls_max_iter,
            pirls_tol=pirls_tol,
            verbose=False,
            eta_init=eta_init,  # Pass through for stability
        )

    # Compute gradient and Hessian via deriv12 (matches lme4)
    derivs = deriv12(deviance_fn, params, delta=delta)
    H = derivs["Hessian"]

    # Invert Hessian with error handling
    try:
        H_inv = np.linalg.inv(H)
        bad_hessian = False
    except np.linalg.LinAlgError:
        # Singular Hessian - use pseudo-inverse
        H_inv = np.linalg.pinv(H)
        bad_hessian = True

    # Check positive definiteness via eigenvalues (lme4's checkHess approach)
    if not bad_hessian:
        eig_vals = np.linalg.eigvalsh(H_inv)
        if np.min(eig_vals) <= 0:
            bad_hessian = True

    if bad_hessian:
        warnings.warn(
            "Hessian is not positive definite. "
            "Consider using use_hessian=False for Schur complement-based vcov.",
            RuntimeWarning,
        )

    # Extract beta-beta block (drop first n_theta rows/cols)
    vcov_beta = H_inv[n_theta:, n_theta:]

    # Apply factor of 2 and symmetrize (matches lme4's forceSymmetric(h + t(h)))
    # The Hessian is of deviance = -2*loglik, so vcov = 2*solve(H)[beta, beta]
    # lme4's forceSymmetric(h + t(h)) is equivalent to 2*(h+h^T)/2 = h + h^T
    # Since our H_inv is already symmetric, this equals 2*H_inv
    vcov_beta = vcov_beta + vcov_beta.T  # This gives 2*vcov_beta since symmetric

    return vcov_beta, derivs
