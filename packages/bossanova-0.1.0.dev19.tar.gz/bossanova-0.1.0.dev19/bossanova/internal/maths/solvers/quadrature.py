"""Adaptive Gauss-Hermite Quadrature (AGQ) for GLMM marginal likelihood.

This module implements nAGQ > 1 integration for scalar random intercept
models. The AGQ deviance replaces the Laplace deviance in Stage 2 of
GLMM fitting when higher accuracy is needed (few observations per group,
extreme probabilities).

Restriction: nAGQ > 1 only works for models with a single scalar random
intercept (e.g., ``(1|group)``). This matches lme4's restriction.

Math
====
For group *i* with conditional mode ``u_hat_i`` and conditional SD
``sigma_hat_i``:

.. math::

    u_{ij} = \\hat{u}_i + \\sqrt{2} \\, \\sigma_i \\, z_j
    \\quad (\\text{adaptive nodes})

    h(u_{ij}) = \\sum_{k \\in i} \\log f(y_k | \\mu(\\eta_{ij,k}))
                - \\tfrac{1}{2} u_{ij}^2
    \\quad (\\text{log integrand})

    \\log I_i = \\log(\\sigma_i)
              + \\text{logsumexp}_j\\!\\bigl(
                    \\log(w_j / \\sqrt{\\pi}) + h(u_{ij}) + z_j^2
                \\bigr)

    \\text{deviance} = -2 \\sum_i \\log I_i

Reference
---------
Pinheiro & Bates (1995), Approximations to the Log-Likelihood Function
in the Nonlinear Mixed-Effects Model, JCGS 4(1):12-35.

lme4 source: glmFamily.cpp ``aic()`` and ``laplace()``.
"""

from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

import numpy as np
import scipy.sparse as sp

from bossanova.internal.maths.family import Family
from bossanova.internal.maths.solvers.pirls_sparse import (
    compute_irls_quantities,
    pirls_sparse,
)

if TYPE_CHECKING:
    from bossanova.internal.maths.solvers.lambda_builder import LambdaTemplate

__all__ = [
    "compute_agq_deviance",
]


@lru_cache(maxsize=16)
def _cached_hermgauss(nAGQ: int) -> tuple[np.ndarray, np.ndarray]:
    """Cache Gauss-Hermite nodes and weights.

    Args:
        nAGQ: Number of quadrature points.

    Returns:
        Tuple of (nodes, weights), each shape ``(nAGQ,)``.
    """
    nodes, weights = np.polynomial.hermite.hermgauss(nAGQ)
    return nodes, weights


def _log_sum_exp(x: np.ndarray) -> float:
    """Numerically stable log-sum-exp.

    Computes ``log(sum(exp(x)))`` avoiding overflow by shifting.

    Args:
        x: Array of log-values.

    Returns:
        Scalar log-sum-exp.
    """
    x_max = np.max(x)
    if not np.isfinite(x_max):
        return float(x_max)
    return float(x_max + np.log(np.sum(np.exp(x - x_max))))


def compute_agq_deviance(
    theta: np.ndarray,
    beta: np.ndarray,
    X: np.ndarray,
    Z: sp.csc_matrix,
    y: np.ndarray,
    family: Family,
    n_groups_list: list[int],
    re_structure: str,
    group_ids: np.ndarray,
    nAGQ: int,
    metadata: dict | None = None,
    prior_weights: np.ndarray | None = None,
    pirls_max_iter: int = 30,
    pirls_tol: float = 1e-7,
    eta_init: np.ndarray | None = None,
    lambda_template: "LambdaTemplate | None" = None,
    factor_cache: dict | None = None,
) -> float:
    """Compute AGQ deviance for Stage 2 optimization.

    This is the objective function for nAGQ > 1. It:
    1. Runs PIRLS with ``beta_fixed`` to get conditional modes ``u_hat``
    2. Computes per-group conditional SDs from the S22 diagonal
    3. Evaluates the AGQ integral using Gauss-Hermite quadrature
    4. Returns ``-2 * sum_i(log_integral_i)``

    Only valid for scalar random intercept models (single grouping factor,
    intercept only).

    Args:
        theta: Cholesky factor elements (scalar for random intercept).
        beta: Fixed effects coefficients (p,).
        X: Fixed effects design matrix (n, p).
        Z: Random effects design matrix (n, q), scipy sparse.
        y: Response vector (n,).
        family: GLM family (binomial, poisson).
        n_groups_list: Number of groups per grouping factor.
        re_structure: Random effects structure type.
        group_ids: Group membership array (n,), integer-coded.
        nAGQ: Number of quadrature points (must be > 1).
        metadata: Additional RE metadata.
        prior_weights: Prior observation weights.
        pirls_max_iter: Maximum PIRLS iterations per evaluation.
        pirls_tol: PIRLS convergence tolerance.
        eta_init: Initial linear predictor for PIRLS.
        lambda_template: Pre-built template for efficient Lambda updates.
        factor_cache: Mutable dict for caching Cholesky factors.

    Returns:
        AGQ deviance (scalar) = ``-2 * sum(log marginal likelihood)``.
    """
    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_sparse,
        update_lambda_from_template,
    )

    # Build Lambda from theta
    if lambda_template is not None:
        Lambda = update_lambda_from_template(lambda_template, theta)
    else:
        Lambda = build_lambda_sparse(theta, n_groups_list, re_structure, metadata)

    # Extract cached factors if caching is enabled
    factor_S22 = factor_cache.get("factor_S22") if factor_cache is not None else None
    factor_S = factor_cache.get("factor_S") if factor_cache is not None else None

    # Run PIRLS with beta_fixed to get conditional modes u_hat
    pirls_result = pirls_sparse(
        X=X,
        Z=Z,
        Lambda=Lambda,
        y=y,
        family=family,
        prior_weights=prior_weights,
        beta_fixed=beta,
        eta_init=eta_init,
        max_iter=pirls_max_iter,
        tol=pirls_tol,
        verbose=False,
        factor_S22=factor_S22,
        factor_S=factor_S,
    )

    # Update cache with factors for next call
    if factor_cache is not None:
        factor_cache["factor_S22"] = pirls_result.get("factor_S22")
        factor_cache["factor_S"] = pirls_result.get("factor_S")

    u_hat = pirls_result["u"]
    eta_hat = pirls_result["eta"]

    # Compute IRLS weights at the conditional mode
    mu_hat = np.asarray(family.link_inverse(eta_hat))
    working_weights, _ = compute_irls_quantities(y, eta_hat, family)

    if prior_weights is not None:
        total_weights = np.asarray(prior_weights) * working_weights
    else:
        total_weights = working_weights

    # For scalar random intercept: theta is scalar, Lambda = theta * I
    # ZL = Z * theta, so ZL_col_j = Z_col_j * theta
    # S22_jj = theta^2 * sum_i(w_i * Z_ij^2) + 1
    # sigma_hat_j = 1 / sqrt(S22_jj)
    theta_val = float(theta[0])
    n_groups = n_groups_list[0]

    # Compute per-group conditional variances from S22 diagonal
    # For scalar RE with one group factor: Z is (n, n_groups) indicator matrix
    # S22_jj = theta^2 * sum_{i in group j} w_i + 1
    # Compute diagonal of ZL'WZL + I efficiently
    # For scalar RE with indicator Z: ZL_ij = theta if i in group j, 0 otherwise
    # So S22_jj = theta^2 * sum_{i in group j} w_i + 1
    s22_diag = np.ones(n_groups)
    for j in range(n_groups):
        mask = group_ids == j
        s22_diag[j] = theta_val**2 * np.sum(total_weights[mask]) + 1.0

    sigma_hat = 1.0 / np.sqrt(s22_diag)

    # Get Gauss-Hermite nodes and weights
    gh_nodes, gh_weights = _cached_hermgauss(nAGQ)

    # Compute log-likelihood contributions for each observation
    # Pre-compute per-observation log-likelihood at the conditional mode
    ll_obs = np.asarray(family.loglik(y, mu_hat))
    if prior_weights is not None:
        ll_obs = np.asarray(prior_weights) * ll_obs

    # Compute AGQ integral for each group
    # eta_fixed = X @ beta (fixed effects part only)
    eta_fixed = X @ beta

    log_integrals = np.empty(n_groups)

    for j in range(n_groups):
        mask = group_ids == j
        y_j = y[mask]
        eta_fixed_j = eta_fixed[mask]
        Z_j = Z[mask, j]  # Column j of Z for obs in group j
        pw_j = prior_weights[mask] if prior_weights is not None else None

        # Adaptive quadrature nodes: u_ij = u_hat_j + sqrt(2) * sigma_j * z_k
        u_nodes = u_hat[j] + np.sqrt(2.0) * sigma_hat[j] * gh_nodes

        # Evaluate log-integrand at each quadrature node
        log_terms = np.empty(nAGQ)

        for k in range(nAGQ):
            u_jk = u_nodes[k]

            # Linear predictor at this quadrature node
            # eta = X_j @ beta + Z_j * theta * u_jk
            Z_j_dense = Z_j.toarray().ravel() if sp.issparse(Z_j) else Z_j
            eta_jk = eta_fixed_j + Z_j_dense * theta_val * u_jk

            # Conditional log-likelihood: sum over obs in group j
            mu_jk = np.asarray(family.link_inverse(eta_jk))
            ll_jk = np.asarray(family.loglik(y_j, mu_jk))
            if pw_j is not None:
                ll_jk = pw_j * ll_jk

            # Log integrand: conditional loglik - 0.5 * u^2
            h_jk = float(np.sum(ll_jk)) - 0.5 * u_jk**2

            # log(w_k / sqrt(pi)) + h(u_jk) + z_k^2
            # The z_k^2 cancels the exp(-z^2) in the Gauss-Hermite weight
            log_terms[k] = (
                np.log(gh_weights[k] / np.sqrt(np.pi)) + h_jk + gh_nodes[k] ** 2
            )

        # log integral = log(sigma_j) + logsumexp(log_terms)
        # The w_k/sqrt(pi) in log_terms absorbs the 1/sqrt(pi) from sigma_j/sqrt(pi)
        # (the full normalization is sigma_j/sqrt(pi) after the Jacobian sqrt(2)*sigma_j
        # cancels with 1/sqrt(2*pi) from the Gaussian prior)
        log_integrals[j] = np.log(sigma_hat[j]) + _log_sum_exp(log_terms)

    # AGQ deviance = -2 * sum of log marginal likelihoods
    return float(-2.0 * np.sum(log_integrals))
