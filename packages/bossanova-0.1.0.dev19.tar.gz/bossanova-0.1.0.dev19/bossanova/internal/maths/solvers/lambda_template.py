"""Lambda matrix templates and sparsity pattern preservation.

Provides LambdaTemplate and PatternTemplate for efficient repeated Lambda
construction during optimization. Templates cache sparsity patterns so that
only data values need updating when theta changes.

Pattern preservation functions ensure consistent sparsity across all theta
evaluations, even at boundary conditions (theta=0), matching lme4's behavior.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
import scipy.sparse as sp

if TYPE_CHECKING:
    pass

__all__ = [
    "LambdaTemplate",
    "PatternTemplate",
    "build_lambda_template",
    "build_pattern_template",
    "compute_s22_preserve_pattern",
    "compute_zl_preserve_pattern",
    "infer_diagonal_dim",
    "infer_slope_dim",
    "update_lambda_from_template",
]


@dataclass(frozen=True, slots=True)
class LambdaTemplate:
    """Template for efficient Lambda matrix updates during optimization.

    Caches the sparsity pattern of Lambda so that repeated calls only
    update the data values, avoiding reconstruction of indices.

    Attributes:
        template: Sparse CSC matrix with correct structure but placeholder values.
        theta_to_data_map: List mapping theta indices to positions in template.data.
            Each element is an int64 array of indices into template.data.
        re_structure: The random effects structure type.
        n_groups_list: Number of groups per factor.
    """

    template: sp.csc_matrix
    theta_to_data_map: list[np.ndarray]  # List of int arrays, not object array
    re_structure: str
    n_groups_list: list[int]


@dataclass(frozen=True, slots=True)
class PatternTemplate:
    """Template for preserving sparsity patterns across theta evaluations.

    This is critical for cross-theta Cholesky caching. When theta has boundary
    values (theta=0), the resulting matrices would normally have fewer non-zeros.
    This template ensures the sparsity pattern remains constant by storing
    explicit zeros where needed.

    Used to match lme4's behavior where the sparsity pattern is fixed at
    initialization and never changes during optimization.

    Attributes:
        ZL_pattern: Sparsity pattern of Z @ Lambda (computed with theta=ones).
        S22_pattern: Sparsity pattern of ZL' @ ZL + I (computed with theta=ones).
        Z: Reference to the original Z matrix for value computation.
        lambda_template: Reference to the LambdaTemplate.
    """

    ZL_pattern: sp.csc_matrix
    S22_pattern: sp.csc_matrix
    Z: sp.csc_matrix
    lambda_template: "LambdaTemplate"


def infer_diagonal_dim(metadata: dict) -> int:
    """Infer dimension for diagonal structure from metadata.

    Args:
        metadata: Metadata dict possibly containing 're_terms' or 'random_names'.

    Returns:
        Dimension of the diagonal structure.
    """
    if "re_terms" in metadata:
        return len(metadata["re_terms"])
    if "random_names" in metadata:
        return len(metadata["random_names"])
    return 2  # Default: intercept + slope


def infer_slope_dim(metadata: dict) -> int:
    """Infer dimension for slope structure from metadata.

    Args:
        metadata: Metadata dict possibly containing 're_terms' or 'random_names'.

    Returns:
        Dimension of the slope structure.
    """
    if "re_terms" in metadata:
        return len(metadata["re_terms"])
    if "random_names" in metadata:
        return len(metadata["random_names"])
    return 2  # Default: intercept + slope


def build_factor_template(
    n_groups: int,
    factor_structure: str,
) -> tuple[sp.csc_matrix, list[np.ndarray]]:
    """Build template block and local theta-to-data map for one grouping factor.

    Used internally by build_lambda_template() for nested/crossed/mixed
    structures that iterate over per-factor blocks.

    Args:
        n_groups: Number of groups in this factor.
        factor_structure: Per-factor structure ("intercept" or "slope").

    Returns:
        Tuple of (block_template, local_theta_to_data_map) where data
        positions in the map are relative to the block start (0-indexed).
    """
    if factor_structure == "intercept":
        block = sp.diags([1.0], offsets=0, shape=(n_groups, n_groups), format="csc")
        # 1 theta param maps to all diagonal positions
        theta_map = [np.arange(n_groups, dtype=np.int64)]

    elif factor_structure == "slope":
        # Correlated slopes: 2x2 lower-triangular Cholesky blocks
        dim = 2  # Hardcoded, matching build_lambda_sparse() reference
        n_params = dim * (dim + 1) // 2  # 3

        L_template = np.zeros((dim, dim))
        for col in range(dim):
            for row in range(col, dim):
                L_template[row, col] = 1.0

        block_sparse = sp.csc_matrix(L_template)
        blocks = [block_sparse.copy() for _ in range(n_groups)]
        block = sp.block_diag(blocks, format="csc")

        # Map each theta to its position across all group blocks
        nnz_per_block = block_sparse.nnz
        theta_map = [
            np.array(
                [g * nnz_per_block + theta_idx for g in range(n_groups)],
                dtype=np.int64,
            )
            for theta_idx in range(n_params)
        ]

    else:
        raise ValueError(f"Unknown factor structure: {factor_structure}")

    return block, theta_map


def build_lambda_template(
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
) -> LambdaTemplate:
    """Build a Lambda template for efficient repeated updates.

    Creates a sparse matrix template with the correct sparsity pattern,
    plus a mapping from theta indices to data array positions.

    Args:
        n_groups_list: Number of groups per grouping factor.
        re_structure: Random effects structure type.
        metadata: Optional metadata dict with structure information.

    Returns:
        LambdaTemplate with template matrix and theta-to-data mapping.

    Examples:
        >>> # Create template for random intercept model
        >>> template = build_lambda_template([18], "intercept")
        >>> template.template.shape
        (18, 18)

        >>> # Update with new theta values
        >>> Lambda = update_lambda_from_template(template, np.array([1.5]))
        >>> Lambda.data[0]
        1.5

    Notes:
        - Template is built once per model, reused during optimization
        - theta_to_data_map[i] gives indices in template.data for theta[i]
    """
    if metadata is None:
        metadata = {}

    if re_structure == "intercept":
        if len(n_groups_list) == 1:
            # Simple intercept: diagonal matrix
            n_groups = n_groups_list[0]
            template = sp.diags(
                [1.0], offsets=0, shape=(n_groups, n_groups), format="csc"
            )
            # theta[0] maps to all diagonal positions
            theta_to_data_map = [np.arange(n_groups, dtype=np.int64)]
        else:
            # Multiple factors: block diagonal of diagonals
            blocks = []
            theta_to_data_map = []
            offset = 0
            for n_groups in n_groups_list:
                block = sp.diags(
                    [1.0], offsets=0, shape=(n_groups, n_groups), format="csc"
                )
                blocks.append(block)
                theta_to_data_map.append(
                    np.arange(offset, offset + n_groups, dtype=np.int64)
                )
                offset += n_groups
            template = sp.block_diag(blocks, format="csc")

    elif re_structure == "diagonal":
        # Uncorrelated slopes: blocked diagonal
        n_groups = n_groups_list[0]
        k = infer_diagonal_dim(metadata)
        q = n_groups * k

        template = sp.diags([1.0] * q, offsets=0, shape=(q, q), format="csc")

        # theta[i] maps to positions [i*n_groups, ..., (i+1)*n_groups - 1]
        theta_to_data_map = [
            np.arange(i * n_groups, (i + 1) * n_groups, dtype=np.int64)
            for i in range(k)
        ]

    elif re_structure == "slope":
        # Correlated slopes: block diagonal of Cholesky blocks
        dim = infer_slope_dim(metadata)
        n_groups = n_groups_list[0]
        n_theta = dim * (dim + 1) // 2

        # Build single block template
        L_template = np.zeros((dim, dim))
        idx = 0
        for col in range(dim):
            for row in range(col, dim):
                L_template[row, col] = 1.0
                idx += 1

        block_sparse = sp.csc_matrix(L_template)
        blocks = [block_sparse.copy() for _ in range(n_groups)]
        template = sp.block_diag(blocks, format="csc")

        # Build theta-to-data mapping
        # For each theta element, find which positions in template.data it affects
        theta_to_data_map = []
        nnz_per_block = block_sparse.nnz

        for theta_idx in range(n_theta):
            # Find position of this theta in a single block
            block_data_idx = theta_idx  # Since we fill column-major in lower triangle
            # This theta affects all blocks at the same position
            positions = np.array(
                [g * nnz_per_block + block_data_idx for g in range(n_groups)],
                dtype=np.int64,
            )
            theta_to_data_map.append(positions)

    elif re_structure in ("nested", "crossed"):
        # Each grouping factor gets its own block
        re_structures_list = metadata.get("re_structures_list", None)
        if re_structures_list is None:
            # Default: assume all intercepts (matches build_lambda_sparse)
            re_structures_list = ["intercept"] * len(n_groups_list)

        blocks = []
        theta_to_data_map = []
        data_offset = 0

        for n_groups, factor_structure in zip(n_groups_list, re_structures_list):
            block, local_map = build_factor_template(n_groups, factor_structure)
            blocks.append(block)
            # Shift local data positions by cumulative offset
            for positions in local_map:
                theta_to_data_map.append(positions + data_offset)
            data_offset += block.nnz

        template = sp.block_diag(blocks, format="csc")

    elif re_structure == "mixed":
        # Mixed structures require per-factor metadata (matches build_lambda_sparse)
        re_structures_list = metadata.get("re_structures_list", None)
        if re_structures_list is None:
            raise ValueError(
                "Mixed structure requires 're_structures_list' in metadata"
            )

        blocks = []
        theta_to_data_map = []
        data_offset = 0

        for n_groups, factor_structure in zip(n_groups_list, re_structures_list):
            block, local_map = build_factor_template(n_groups, factor_structure)
            blocks.append(block)
            for positions in local_map:
                theta_to_data_map.append(positions + data_offset)
            data_offset += block.nnz

        template = sp.block_diag(blocks, format="csc")

    else:
        raise ValueError(
            f"Unknown re_structure={re_structure!r}. "
            f"Supported: 'intercept', 'diagonal', 'slope', 'nested', 'crossed', 'mixed'."
        )

    return LambdaTemplate(
        template=template,
        theta_to_data_map=theta_to_data_map,
        re_structure=re_structure,
        n_groups_list=n_groups_list,
    )


def update_lambda_from_template(
    template: LambdaTemplate,
    theta: np.ndarray,
) -> sp.csc_matrix:
    """Update Lambda matrix from template using new theta values.

    Efficiently updates only the data values without rebuilding structure.

    Args:
        template: LambdaTemplate created by build_lambda_template.
        theta: New theta values.

    Returns:
        Updated sparse Lambda matrix in CSC format.

    Examples:
        >>> template = build_lambda_template([18], "intercept")
        >>> Lambda = update_lambda_from_template(template, np.array([1.5]))
        >>> Lambda[0, 0]
        1.5

    Notes:
        - Much faster than build_lambda_sparse for repeated calls
        - Modifies template.data in place for maximum efficiency
    """
    # Copy the template (to avoid modifying the original)
    Lambda = template.template.copy()

    # Update data values based on mapping
    for theta_idx, data_indices in enumerate(template.theta_to_data_map):
        Lambda.data[data_indices] = theta[theta_idx]

    return Lambda


def build_pattern_template(
    Z: sp.csc_matrix,
    lambda_template: LambdaTemplate,
) -> PatternTemplate:
    """Build pattern template for cross-theta Cholesky caching.

    Computes the "maximal" sparsity patterns of ZL and S22 using theta=ones.
    These patterns are used to ensure consistent sparsity across all theta
    evaluations, even when theta components are zero (boundary conditions).

    This matches lme4's approach where the sparsity pattern is fixed at
    model initialization and never changes during optimization.

    Args:
        Z: Random effects design matrix (n, q), scipy sparse CSC.
        lambda_template: LambdaTemplate with pattern information.

    Returns:
        PatternTemplate with ZL and S22 patterns.

    Examples:
        >>> Z = sp.random(100, 50, density=0.1, format='csc')
        >>> lambda_tpl = build_lambda_template([50], "intercept")
        >>> pattern_tpl = build_pattern_template(Z, lambda_tpl)
        >>> # Now use pattern_tpl for pattern-preserved computations
    """
    if not sp.isspmatrix_csc(Z):
        Z = Z.tocsc()

    # Build Lambda with theta=ones to get maximal pattern
    n_theta = len(lambda_template.theta_to_data_map)
    theta_ones = np.ones(n_theta)
    Lambda_max = update_lambda_from_template(lambda_template, theta_ones)

    # Compute ZL pattern (maximal, with theta=ones)
    ZL_pattern = Z @ Lambda_max
    if not sp.isspmatrix_csc(ZL_pattern):
        ZL_pattern = ZL_pattern.tocsc()

    # Compute S22 pattern: ZL' @ ZL + I (without weights, pattern only)
    S22_pattern = ZL_pattern.T @ ZL_pattern
    S22_pattern = S22_pattern + sp.eye(S22_pattern.shape[0], format="csc")
    if not sp.isspmatrix_csc(S22_pattern):
        S22_pattern = S22_pattern.tocsc()

    return PatternTemplate(
        ZL_pattern=ZL_pattern,
        S22_pattern=S22_pattern,
        Z=Z,
        lambda_template=lambda_template,
    )


def compute_zl_preserve_pattern(
    Z: sp.csc_matrix,
    Lambda: sp.csc_matrix,
    ZL_pattern: sp.csc_matrix,
) -> sp.csc_matrix:
    """Compute Z @ Lambda while preserving the sparsity pattern of ZL_pattern.

    When theta has zeros (boundary), scipy's Z @ Lambda prunes explicit zeros,
    changing the sparsity pattern. This function ensures the result always has
    the same pattern as ZL_pattern by adding explicit zeros where needed.

    This is critical for CHOLMOD caching: the factorization reuses the symbolic
    analysis, which depends on having a consistent sparsity pattern.

    Args:
        Z: Random effects design matrix (n, q).
        Lambda: Current Lambda matrix (may have zeros from boundary theta).
        ZL_pattern: The "maximal" ZL pattern from build_pattern_template.

    Returns:
        ZL with ZL_pattern's sparsity structure but current values.

    Notes:
        - Pattern positions not in Z @ Lambda are filled with explicit zeros.
        - This matches lme4's updateLamtUt() which preserves pattern via manual iteration.
    """
    # Compute actual ZL values
    ZL_values = Z @ Lambda
    if not sp.isspmatrix_csc(ZL_values):
        ZL_values = ZL_values.tocsc()

    # If patterns match, we're done
    if ZL_values.nnz == ZL_pattern.nnz:
        return ZL_values

    # Create result with pattern's structure
    # Start with zeros in pattern's positions
    result_data = np.zeros(ZL_pattern.nnz, dtype=np.float64)

    # Copy values from ZL_values where they exist in pattern
    # We need to map from ZL_values positions to ZL_pattern positions
    n_cols = ZL_pattern.shape[1]

    for col in range(n_cols):
        # Pattern column range
        pat_start = ZL_pattern.indptr[col]
        pat_end = ZL_pattern.indptr[col + 1]
        pat_rows = ZL_pattern.indices[pat_start:pat_end]

        # Values column range
        val_start = ZL_values.indptr[col]
        val_end = ZL_values.indptr[col + 1]
        val_rows = ZL_values.indices[val_start:val_end]
        val_data = ZL_values.data[val_start:val_end]

        # For each row in pattern, find if it exists in values
        # Use searchsorted for efficiency (rows are sorted in CSC)
        for i, pat_row in enumerate(pat_rows):
            idx = np.searchsorted(val_rows, pat_row)
            if idx < len(val_rows) and val_rows[idx] == pat_row:
                result_data[pat_start + i] = val_data[idx]
            # else: stays 0 (explicit zero)

    result = sp.csc_matrix(
        (result_data, ZL_pattern.indices.copy(), ZL_pattern.indptr.copy()),
        shape=ZL_pattern.shape,
    )
    return result


def compute_s22_preserve_pattern(
    ZL: sp.csc_matrix,
    W: sp.csc_matrix,
    S22_pattern: sp.csc_matrix,
) -> sp.csc_matrix:
    """Compute ZL' @ W @ ZL + I while preserving S22_pattern's sparsity.

    Similar to compute_zl_preserve_pattern, this ensures S22 always has
    the same sparsity pattern regardless of theta values.

    Args:
        ZL: Pattern-preserved ZL matrix from compute_zl_preserve_pattern.
        W: Diagonal weight matrix.
        S22_pattern: The "maximal" S22 pattern from build_pattern_template.

    Returns:
        S22 with S22_pattern's sparsity structure but current values.
    """
    # Compute actual S22 values
    S22_values = ZL.T @ W @ ZL
    q = S22_values.shape[0]
    S22_values = S22_values + sp.eye(q, format="csc")
    if not sp.isspmatrix_csc(S22_values):
        S22_values = S22_values.tocsc()

    # If patterns match, we're done
    if S22_values.nnz == S22_pattern.nnz:
        return S22_values

    # Create result with pattern's structure
    result_data = np.zeros(S22_pattern.nnz, dtype=np.float64)

    n_cols = S22_pattern.shape[1]

    for col in range(n_cols):
        # Pattern column range
        pat_start = S22_pattern.indptr[col]
        pat_end = S22_pattern.indptr[col + 1]
        pat_rows = S22_pattern.indices[pat_start:pat_end]

        # Values column range
        val_start = S22_values.indptr[col]
        val_end = S22_values.indptr[col + 1]
        val_rows = S22_values.indices[val_start:val_end]
        val_data = S22_values.data[val_start:val_end]

        # For each row in pattern, find if it exists in values
        for i, pat_row in enumerate(pat_rows):
            idx = np.searchsorted(val_rows, pat_row)
            if idx < len(val_rows) and val_rows[idx] == pat_row:
                result_data[pat_start + i] = val_data[idx]
            # else: stays 0 (explicit zero for off-diag, but diag has +I)

    result = sp.csc_matrix(
        (result_data, S22_pattern.indices.copy(), S22_pattern.indptr.copy()),
        shape=S22_pattern.shape,
    )
    return result
