"""Global configuration for bossanova.

This module provides package-wide configuration settings that can be modified
at runtime. Currently manages singular tolerance for mixed models.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np

__all__ = [
    "get_display_digits",
    "get_singular_tolerance",
    "is_singular",
    "set_display_digits",
    "set_singular_tolerance",
]

# Default significant figures for DataFrame display output.
# Matches R's summary() convention of 4 significant digits.
_DISPLAY_DIGITS: int = 4

# Default singular tolerance matches lme4's default (utilities.R:924-928)
_SINGULAR_TOLERANCE: float = 1e-4


def get_display_digits() -> int:
    """Get the number of significant figures for DataFrame display output.

    Controls how many significant figures are shown in user-facing
    DataFrames returned by model properties (``.params``, ``.effects``,
    ``.diagnostics``, etc.) and ``compare()``.  Matches R's ``signif()``
    convention.

    Returns:
        Current display digits setting (default 4).

    Examples:
        ```python
        from bossanova import get_display_digits
        get_display_digits()
        # 4
        ```
    """
    return _DISPLAY_DIGITS


def set_display_digits(digits: int) -> None:
    """Set the number of significant figures for DataFrame display output.

    Controls how many significant figures are shown in user-facing
    DataFrames returned by model properties (``.params``, ``.effects``,
    ``.diagnostics``, etc.) and ``compare()``.  Matches R's ``signif()``
    convention.

    The ``summary()`` method has its own ``digits`` parameter and is
    unaffected by this setting.

    Args:
        digits: Number of significant figures.  Must be >= 1.

    Raises:
        ValueError: If digits is less than 1.

    Examples:
        ```python
        from bossanova import set_display_digits
        set_display_digits(6)  # Show 6 significant figures
        ```
    """
    global _DISPLAY_DIGITS
    if digits < 1:
        raise ValueError(f"digits must be >= 1, got {digits}")
    _DISPLAY_DIGITS = digits


def get_singular_tolerance() -> float:
    """Get the current singular tolerance for mixed models.

    The singular tolerance is used by `isSingular()` to determine if a mixed
    model fit is singular (has variance components at or near zero).

    Returns:
        The current singular tolerance threshold.

    Examples:
        ```python
        from bossanova import get_singular_tolerance
        get_singular_tolerance()
        # 0.0001
        ```
    """
    return _SINGULAR_TOLERANCE


def set_singular_tolerance(tol: float) -> None:
    """Set the global singular tolerance for mixed models.

    The singular tolerance is used by `isSingular()` to determine if a mixed
    model fit is singular. Values below this threshold are considered
    effectively zero.

    Args:
        tol: New tolerance threshold. Must be positive.

    Raises:
        ValueError: If tol is not positive.

    Examples:
        ```python
        from bossanova import set_singular_tolerance
        set_singular_tolerance(1e-6)  # More strict threshold
        ```
    """
    global _SINGULAR_TOLERANCE
    if tol <= 0:
        raise ValueError(f"Tolerance must be positive, got {tol}")
    _SINGULAR_TOLERANCE = tol


def is_singular(theta: np.ndarray | None, tol: float | None = None) -> bool:
    """Check whether a mixed model fit is singular.

    A fit is singular when any theta parameter (variance component on the
    relative scale) is at or near zero, indicating a variance component
    on the boundary of the parameter space.

    Args:
        theta: Relative variance parameters from REML/ML optimization.
            None indicates no random effects (returns False).
        tol: Tolerance threshold. If None, uses the global singular
            tolerance from ``get_singular_tolerance()``.

    Returns:
        True if any element of theta has absolute value below the tolerance.

    Examples:
        ```python
        from bossanova.internal.maths.config import is_singular
        import numpy as np
        is_singular(np.array([0.5, 1e-6]))  # True (1e-6 < 1e-4)
        is_singular(np.array([0.5, 0.3]))   # False
        is_singular(None)                    # False
        ```
    """
    if theta is None:
        return False
    import numpy as np

    if tol is None:
        tol = _SINGULAR_TOLERANCE
    return bool(np.any(np.abs(theta) < tol))
