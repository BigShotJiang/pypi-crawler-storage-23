"""Distribution plotting mixin.

Provides visualization methods for Distribution objects including
PDF/PMF plotting, shading, and notebook rendering.

Internal exports:
    DistributionPlotMixin: Mixin class adding plot methods to Distribution.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

import numpy as np

from bossanova.internal.maths.distributions.probability import figure_to_html
from bossanova.internal.viz.core import BOSSANOVA_STYLE

if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from matplotlib.figure import Figure

__all__ = [
    "DistributionPlotMixin",
]


class DistributionPlotMixin:
    """Mixin providing visualization methods for distributions.

    Expects the host class to provide:
        _dist: Frozen scipy.stats distribution.
        _name: str display name.
        _params: dict[str, float] parameter dictionary.
        _is_discrete: bool whether distribution is discrete.
        mean: float property.
        median: float property.
        interval(confidence) -> tuple[float, float].
        ppf(q) -> np.ndarray.
    """

    # =========================================================================
    # Visualization
    # =========================================================================

    def compute_x_range(self) -> tuple[float, float]:
        """Compute sensible x-range for plotting.

        Returns:
            Tuple of (low, high) x values covering the distribution.
        """
        if self._is_discrete:
            # For discrete: use ppf to find range covering 99.9%
            low = max(0, int(self._dist.ppf(0.001)))
            high = int(self._dist.ppf(0.999)) + 1
            return (float(low), float(high))
        else:
            # For continuous: use ppf for 0.001 to 0.999
            low = self._dist.ppf(0.001)
            high = self._dist.ppf(0.999)
            # Add some padding
            padding = (high - low) * 0.05
            return (float(low - padding), float(high + padding))

    def parse_shade_region(
        self,
        shade_region: tuple[float, float] | str | None,
    ) -> tuple[float, float] | None:
        """Parse shade_region argument to actual bounds.

        Args:
            shade_region: Region specification (tuple, string shortcut, or None).

        Returns:
            Tuple of (low, high) bounds, or None if no shading.
        """
        if shade_region is None:
            return None

        if isinstance(shade_region, tuple):
            return shade_region

        # String shortcuts
        if shade_region == "ci95":
            return self.interval(0.95)
        elif shade_region == "ci99":
            return self.interval(0.99)
        elif shade_region == "ci90":
            return self.interval(0.90)
        elif shade_region == "critical_left":
            return (float("-inf"), float(self.ppf(0.05)))
        elif shade_region == "critical_right":
            return (float(self.ppf(0.95)), float("inf"))
        elif shade_region == "critical_two":
            return (float(self.ppf(0.025)), float(self.ppf(0.975)))
        else:
            raise ValueError(
                f"Unknown shade_region: {shade_region!r}. "
                "Use tuple, 'ci95', 'ci99', 'ci90', 'critical_left', "
                "'critical_right', or 'critical_two'."
            )

    def plot(
        self,
        *,
        ax: Axes | None = None,
        shade_region: tuple[float, float] | str | None = None,
        shade_direction: Literal["between", "outside", "left", "right"] = "between",
        shade_alpha: float = 0.3,
        shade_color: str | None = None,
        show_mean: bool = False,
        show_median: bool = False,
        x_range: tuple[float, float] | None = None,
        figsize: tuple[float, float] = (6, 4),
        color: str | None = None,
        title: str | None = None,
    ) -> Figure:
        """Plot the distribution.

        Args:
            ax: Matplotlib axes. If None, creates new figure.
            shade_region: Region to shade. Can be:
                - tuple[float, float]: Shade between these x values
                - "ci95", "ci99", "ci90": Shade confidence interval
                - "critical_left": Shade left tail (alpha=0.05)
                - "critical_right": Shade right tail (alpha=0.05)
                - "critical_two": Shade both tails (alpha=0.025 each)
            shade_direction: How to shade relative to bounds:
                - "between": Shade area between bounds (default for CI)
                - "outside": Shade area outside bounds (rejection regions)
                - "left": Shade left of lower bound
                - "right": Shade right of upper bound
            shade_alpha: Transparency for shaded region.
            shade_color: Color for shaded region (defaults to line color).
            show_mean: Show vertical line at mean.
            show_median: Show vertical line at median.
            x_range: Custom x-axis range (auto-computed if None).
            figsize: Figure size in inches.
            color: Line/bar color (uses palette default if None).
            title: Plot title (auto-generated if None).

        Returns:
            Matplotlib Figure object.
        """
        import matplotlib.pyplot as plt

        # Create figure if needed
        if ax is None:
            fig, ax = plt.subplots(figsize=figsize)
        else:
            fig = ax.get_figure()

        # Get styling
        style = BOSSANOVA_STYLE
        plot_color = color or plt.cm.tab10(0)

        # Compute x range
        if x_range is None:
            x_lo, x_hi = self.compute_x_range()
        else:
            x_lo, x_hi = x_range

        # Plot based on distribution type
        if self._is_discrete:
            self._plot_discrete(ax, x_lo, x_hi, plot_color, style)
        else:
            self._plot_continuous(ax, x_lo, x_hi, plot_color, style)

        # Add shading
        bounds = self.parse_shade_region(shade_region)
        if bounds is not None:
            self._add_shading(
                ax,
                bounds,
                shade_direction,
                shade_alpha,
                shade_color or plot_color,
                x_lo,
                x_hi,
            )

        # Add reference lines
        if show_mean:
            ax.axvline(
                self.mean,
                color=style["ref_line_color"],
                linestyle="--",
                linewidth=style["ref_line_width"],
                label=f"Mean = {self.mean:.3g}",
            )
        if show_median:
            ax.axvline(
                self.median,
                color=style["ref_line_color"],
                linestyle=":",
                linewidth=style["ref_line_width"],
                label=f"Median = {self.median:.3g}",
            )

        # Labels
        param_str = ", ".join(f"{k}={v:.3g}" for k, v in self._params.items())
        default_title = f"{self._name}({param_str})"
        ax.set_title(title or default_title, fontsize=style["title_size"])
        ax.set_xlabel("x", fontsize=style["label_size"])
        ax.set_ylabel(
            "Probability" if self._is_discrete else "Density",
            fontsize=style["label_size"],
        )

        # Add legend if reference lines shown
        if show_mean or show_median:
            ax.legend(fontsize=style["font_size"])

        # Style
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(True, alpha=style["grid_alpha"], linestyle=style["grid_style"])

        fig.tight_layout()
        return fig

    def _plot_continuous(
        self,
        ax: Axes,
        x_lo: float,
        x_hi: float,
        color: Any,
        style: dict[str, Any],
    ) -> None:
        """Plot PDF for continuous distribution.

        Args:
            ax: Matplotlib axes to plot on.
            x_lo: Lower x-axis bound.
            x_hi: Upper x-axis bound.
            color: Line and fill color.
            style: Bossanova style dictionary.
        """
        x = np.linspace(x_lo, x_hi, 200)
        y = self._dist.pdf(x)
        ax.plot(x, y, color=color, linewidth=style["line_width"])
        ax.fill_between(x, y, alpha=style["ci_alpha"] * 0.5, color=color)

    def _plot_discrete(
        self,
        ax: Axes,
        x_lo: float,
        x_hi: float,
        color: Any,
        style: dict[str, Any],
    ) -> None:
        """Plot PMF bars for discrete distribution.

        Args:
            ax: Matplotlib axes to plot on.
            x_lo: Lower x-axis bound.
            x_hi: Upper x-axis bound.
            color: Bar color.
            style: Bossanova style dictionary.
        """
        x = np.arange(int(x_lo), int(x_hi) + 1)
        y = self._dist.pmf(x)
        ax.bar(x, y, width=0.8, color=color, alpha=0.7, edgecolor="white")

    def _add_shading(
        self,
        ax: Axes,
        bounds: tuple[float, float],
        direction: str,
        alpha: float,
        color: Any,
        x_lo: float,
        x_hi: float,
    ) -> None:
        """Add shaded region to plot.

        Args:
            ax: Matplotlib axes to shade on.
            bounds: Tuple of (lower, upper) bounds for shading.
            direction: One of "between", "outside", "left", "right".
            alpha: Transparency level.
            color: Shade color.
            x_lo: Lower x-axis bound for full range.
            x_hi: Upper x-axis bound for full range.
        """
        lo, hi = bounds

        if self._is_discrete:
            # For discrete, shade bars
            x_all = np.arange(int(x_lo), int(x_hi) + 1)
            y_all = self._dist.pmf(x_all)

            if direction == "between":
                mask = (x_all >= lo) & (x_all <= hi)
            elif direction == "outside":
                mask = (x_all < lo) | (x_all > hi)
            elif direction == "left":
                mask = x_all <= lo
            elif direction == "right":
                mask = x_all >= hi
            else:
                return

            ax.bar(
                x_all[mask],
                y_all[mask],
                width=0.8,
                color=color,
                alpha=alpha + 0.3,
                edgecolor="white",
            )
        else:
            # For continuous, use fill_between
            x = np.linspace(x_lo, x_hi, 200)
            y = self._dist.pdf(x)

            if direction == "between":
                mask = (x >= lo) & (x <= hi)
                ax.fill_between(x, y, where=mask, alpha=alpha, color=color)
            elif direction == "outside":
                mask_left = x <= lo
                mask_right = x >= hi
                ax.fill_between(x, y, where=mask_left, alpha=alpha, color=color)
                ax.fill_between(x, y, where=mask_right, alpha=alpha, color=color)
            elif direction == "left":
                mask = x <= lo
                ax.fill_between(x, y, where=mask, alpha=alpha, color=color)
            elif direction == "right":
                mask = x >= hi
                ax.fill_between(x, y, where=mask, alpha=alpha, color=color)

    def _repr_html_(self) -> str:
        """HTML representation with embedded plot for notebooks.

        Returns:
            HTML string with base64-encoded plot image.
        """
        fig = self.plot()
        return figure_to_html(fig)
