"""Distribution factory functions.

Provides user-friendly constructors for common probability distributions
with intuitive parameterization (e.g., mean/sd instead of loc/scale).

Internal exports:
    normal, t_dist, chi2, F_dist, beta, binomial, poisson,
    exponential, gamma, uniform
"""

from scipy import stats

from bossanova.internal.maths.distributions.base import Distribution

__all__ = [
    "F_dist",
    "beta",
    "binomial",
    "chi2",
    "exponential",
    "gamma",
    "normal",
    "poisson",
    "t_dist",
    "uniform",
]


def normal(mean: float = 0, sd: float = 1) -> Distribution:
    """Normal (Gaussian) distribution.

    Args:
        mean: Mean of the distribution.
        sd: Standard deviation (must be positive).

    Returns:
        Distribution object.

    Examples:
        ```python
        d = normal(mean=100, sd=15)
        d.cdf(115)  # P(X <= 115)
        # 0.8413...
        ```
    """
    if sd <= 0:
        raise ValueError("sd must be positive")
    return Distribution(
        dist=stats.norm(loc=mean, scale=sd),
        name="Normal",
        params={"mean": mean, "sd": sd},
    )


def t_dist(df: float, mean: float = 0, sd: float = 1) -> Distribution:
    """Student's t distribution.

    Args:
        df: Degrees of freedom (must be positive).
        mean: Location parameter.
        sd: Scale parameter (must be positive).

    Returns:
        Distribution object.

    Examples:
        ```python
        t = t_dist(df=29)
        t.ppf(0.975)  # Critical value for 95% CI
        # 2.045...
        ```
    """
    if df <= 0:
        raise ValueError("df must be positive")
    if sd <= 0:
        raise ValueError("sd must be positive")
    return Distribution(
        dist=stats.t(df=df, loc=mean, scale=sd),
        name="Student's t",
        params={"df": df, "mean": mean, "sd": sd},
    )


def chi2(df: float) -> Distribution:
    """Chi-squared distribution.

    Args:
        df: Degrees of freedom (must be positive).

    Returns:
        Distribution object.

    Examples:
        ```python
        c = chi2(df=5)
        c.ppf(0.95)  # Critical value
        # 11.07...
        ```
    """
    if df <= 0:
        raise ValueError("df must be positive")
    return Distribution(
        dist=stats.chi2(df=df),
        name="Chi-squared",
        params={"df": df},
    )


def F_dist(df1: float, df2: float) -> Distribution:
    """F distribution.

    Args:
        df1: Numerator degrees of freedom (must be positive).
        df2: Denominator degrees of freedom (must be positive).

    Returns:
        Distribution object.

    Examples:
        ```python
        f = F_dist(df1=5, df2=20)
        f.ppf(0.95)  # Critical value
        # 2.71...
        ```
    """
    if df1 <= 0 or df2 <= 0:
        raise ValueError("df1 and df2 must be positive")
    return Distribution(
        dist=stats.f(dfn=df1, dfd=df2),
        name="F",
        params={"df1": df1, "df2": df2},
    )


def beta(a: float, b: float) -> Distribution:
    """Beta distribution.

    Args:
        a: Shape parameter alpha (must be positive).
        b: Shape parameter beta (must be positive).

    Returns:
        Distribution object.

    Examples:
        ```python
        d = beta(a=2, b=5)
        d.mean
        # 0.285...
        ```
    """
    if a <= 0 or b <= 0:
        raise ValueError("a and b must be positive")
    return Distribution(
        dist=stats.beta(a=a, b=b),
        name="Beta",
        params={"a": a, "b": b},
    )


def binomial(n: int, p: float) -> Distribution:
    """Binomial distribution.

    Args:
        n: Number of trials (must be non-negative integer).
        p: Probability of success (must be in [0, 1]).

    Returns:
        Distribution object.

    Examples:
        ```python
        b = binomial(n=20, p=0.3)
        b.mean
        # 6.0
        b.pmf(6)  # P(X = 6)
        # 0.191...
        ```
    """
    if n < 0 or not isinstance(n, int):
        raise ValueError("n must be a non-negative integer")
    if not 0 <= p <= 1:
        raise ValueError("p must be in [0, 1]")
    return Distribution(
        dist=stats.binom(n=n, p=p),
        name="Binomial",
        params={"n": n, "p": p},
    )


def poisson(mu: float) -> Distribution:
    """Poisson distribution.

    Args:
        mu: Expected number of events (rate, must be positive).

    Returns:
        Distribution object.

    Examples:
        ```python
        d = poisson(mu=5)
        d.pmf(3)  # P(X = 3)
        # 0.140...
        ```
    """
    if mu <= 0:
        raise ValueError("mu must be positive")
    return Distribution(
        dist=stats.poisson(mu=mu),
        name="Poisson",
        params={"mu": mu},
    )


def exponential(rate: float) -> Distribution:
    """Exponential distribution (rate parameterization).

    Args:
        rate: Rate parameter lambda (must be positive).
            Mean = 1/rate.

    Returns:
        Distribution object.

    Examples:
        ```python
        d = exponential(rate=0.5)
        d.mean
        # 2.0
        ```
    """
    if rate <= 0:
        raise ValueError("rate must be positive")
    # scipy uses scale = 1/rate
    return Distribution(
        dist=stats.expon(scale=1 / rate),
        name="Exponential",
        params={"rate": rate},
    )


def gamma(
    shape: float,
    rate: float | None = None,
    scale: float | None = None,
) -> Distribution:
    """Gamma distribution.

    Accepts either rate or scale parameterization (not both).

    Args:
        shape: Shape parameter (must be positive).
        rate: Rate parameter (1/scale). If provided, scale must be None.
        scale: Scale parameter. If provided, rate must be None.
            Default is scale=1 if neither specified.

    Returns:
        Distribution object.

    Raises:
        ValueError: If both rate and scale are provided.

    Examples:
        ```python
        g = gamma(shape=2, rate=0.5)
        g.mean
        # 4.0
        g = gamma(shape=2, scale=2)  # Equivalent
        g.mean
        # 4.0
        ```
    """
    if shape <= 0:
        raise ValueError("shape must be positive")
    if rate is not None and scale is not None:
        raise ValueError("Specify either rate or scale, not both")
    if rate is not None:
        if rate <= 0:
            raise ValueError("rate must be positive")
        scale = 1 / rate
    elif scale is None:
        scale = 1.0
    if scale <= 0:
        raise ValueError("scale must be positive")

    params = {"shape": shape}
    if rate is not None:
        params["rate"] = rate
    else:
        params["scale"] = scale

    return Distribution(
        dist=stats.gamma(a=shape, scale=scale),
        name="Gamma",
        params=params,
    )


def uniform(low: float = 0, high: float = 1) -> Distribution:
    """Uniform distribution.

    Args:
        low: Lower bound.
        high: Upper bound (must be > low).

    Returns:
        Distribution object.

    Examples:
        ```python
        d = uniform(low=0, high=10)
        d.mean
        # 5.0
        ```
    """
    if high <= low:
        raise ValueError("high must be greater than low")
    return Distribution(
        dist=stats.uniform(loc=low, scale=high - low),
        name="Uniform",
        params={"low": low, "high": high},
    )
