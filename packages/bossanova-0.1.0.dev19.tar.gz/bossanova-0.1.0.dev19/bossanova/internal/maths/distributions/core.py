"""Backward-compatibility re-exports for distribution classes.

This module re-exports all distribution classes from their new locations:
- ``base.py``: Distribution base class
- ``derived.py``: TransformedDistribution, ConvolvedDistribution,
  TruncatedDistribution, FoldedDistribution

Import from this module or directly from the submodules.
"""

from bossanova.internal.maths.distributions.base import Distribution
from bossanova.internal.maths.distributions.derived import (
    ConvolvedDistribution,
    FoldedDistribution,
    TransformedDistribution,
    TruncatedDistribution,
)

__all__ = [
    "ConvolvedDistribution",
    "Distribution",
    "FoldedDistribution",
    "TransformedDistribution",
    "TruncatedDistribution",
]
