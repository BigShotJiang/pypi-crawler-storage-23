"""Derived distribution types.

Provides distribution classes for transformed, convolved, truncated,
and folded distributions built from a base Distribution.

Internal exports:
    TransformedDistribution: Affine-transformed distribution (Y = scale*X + shift).
    ConvolvedDistribution: Sum of independent random variables (X + Y).
    TruncatedDistribution: Distribution truncated to an interval [low, high].
    FoldedDistribution: Absolute value distribution |X|.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy import stats

from bossanova.internal.maths.distributions.base import Distribution
from bossanova.internal.maths.distributions.probability import MC_SAMPLES

if TYPE_CHECKING:
    from numpy.typing import ArrayLike

__all__ = [
    "ConvolvedDistribution",
    "FoldedDistribution",
    "TransformedDistribution",
    "TruncatedDistribution",
]


class TransformedDistribution(Distribution):
    """Distribution resulting from an affine transformation: Y = scale*X + shift.

    Used when closed-form parameters aren't available. Delegates to the base
    distribution with appropriate transformations applied.

    Args:
        base: The original distribution.
        scale: Multiplicative factor.
        shift: Additive constant.
    """

    __slots__ = ("_base", "_scale", "_shift")

    def __init__(self, base: Distribution, scale: float, shift: float) -> None:
        self._base = base
        self._scale = scale
        self._shift = shift

        # Build descriptive name
        if scale == 1:
            name = f"{base._name} + {shift:.4g}"
        elif shift == 0:
            name = f"{scale:.4g} \u00d7 {base._name}"
        else:
            name = f"{scale:.4g} \u00d7 {base._name} + {shift:.4g}"

        # Initialize base class attributes
        object.__setattr__(self, "_dist", base._dist)
        object.__setattr__(self, "_name", name)
        object.__setattr__(
            self, "_params", {"scale": scale, "shift": shift, **base._params}
        )
        object.__setattr__(self, "_is_discrete", base._is_discrete)

    @property
    def mean(self) -> float:
        """Transformed mean: scale * E[X] + shift."""
        return self._scale * self._base.mean + self._shift

    @property
    def var(self) -> float:
        """Transformed variance: scale^2 * Var[X]."""
        return self._scale**2 * self._base.var

    @property
    def std(self) -> float:
        """Transformed standard deviation: |scale| * SD[X]."""
        return abs(self._scale) * self._base.std

    @property
    def median(self) -> float:
        """Transformed median: scale * median[X] + shift."""
        return self._scale * self._base.median + self._shift

    def pdf(self, x: ArrayLike) -> np.ndarray:
        """PDF of transformed distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            PDF values at each point.

        Raises:
            AttributeError: If called on a discrete distribution.
        """
        if self._is_discrete:
            raise AttributeError(f"{self._name} is discrete. Use pmf() instead.")
        x = np.asarray(x)
        # Y = scale*X + shift -> X = (Y - shift)/scale
        x_orig = (x - self._shift) / self._scale
        # PDF scales by |1/scale| (Jacobian)
        return np.asarray(self._base.pdf(x_orig) / abs(self._scale))

    def pmf(self, x: ArrayLike) -> np.ndarray:
        """PMF of transformed distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            PMF values at each point.

        Raises:
            AttributeError: If called on a continuous distribution.
        """
        if not self._is_discrete:
            raise AttributeError(f"{self._name} is continuous. Use pdf() instead.")
        x = np.asarray(x)
        x_orig = (x - self._shift) / self._scale
        return np.asarray(self._base.pmf(x_orig))

    def cdf(self, x: ArrayLike) -> np.ndarray:
        """CDF of transformed distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            CDF values at each point.
        """
        x = np.asarray(x)
        x_orig = (x - self._shift) / self._scale
        if self._scale >= 0:
            return np.asarray(self._base.cdf(x_orig))
        # Negative scale reverses the CDF
        return np.asarray(1 - self._base.cdf(x_orig))

    def sf(self, x: ArrayLike) -> np.ndarray:
        """Survival function of transformed distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            Survival function values at each point.
        """
        return 1 - self.cdf(x)

    def ppf(self, q: ArrayLike) -> np.ndarray:
        """PPF of transformed distribution.

        Args:
            q: Quantiles (probabilities between 0 and 1).

        Returns:
            Values x such that P(Y <= x) = q.
        """
        q = np.asarray(q)
        if self._scale >= 0:
            x_orig = self._base.ppf(q)
        else:
            x_orig = self._base.ppf(1 - q)
        return np.asarray(self._scale * x_orig + self._shift)

    def rvs(
        self,
        size: int | tuple[int, ...] = 1,
        seed: int | np.random.Generator | None = None,
    ) -> np.ndarray:
        """Generate random samples from transformed distribution.

        Args:
            size: Number of samples or shape of output array.
            seed: Random seed or Generator for reproducibility.

        Returns:
            Array of random samples.
        """
        samples = self._base.rvs(size=size, seed=seed)
        return self._scale * samples + self._shift


class ConvolvedDistribution(Distribution):
    """Distribution representing the sum of two independent random variables.

    Uses Monte Carlo simulation for CDF/PPF computations when no closed-form
    solution is available.

    Args:
        dist1: First distribution (X).
        dist2: Second distribution (Y).
        n_samples: Number of samples for Monte Carlo estimation.
    """

    __slots__ = ("_dist1", "_dist2", "_n_samples", "_samples_cache", "_seed")

    def __init__(
        self,
        dist1: Distribution,
        dist2: Distribution,
        n_samples: int = MC_SAMPLES,
    ) -> None:
        self._dist1 = dist1
        self._dist2 = dist2
        self._n_samples = n_samples
        self._samples_cache: np.ndarray | None = None
        self._seed = 42  # Fixed seed for reproducibility

        # Build descriptive name
        name = f"{dist1._name} + {dist2._name}"

        # Initialize base class attributes
        object.__setattr__(self, "_dist", dist1._dist)
        object.__setattr__(self, "_name", name)
        object.__setattr__(
            self, "_params", {"dist1": dist1._name, "dist2": dist2._name}
        )
        object.__setattr__(
            self, "_is_discrete", dist1._is_discrete and dist2._is_discrete
        )

    def get_samples(self) -> np.ndarray:
        """Get or generate cached samples.

        Returns:
            Sorted array of Monte Carlo samples from X + Y.
        """
        if self._samples_cache is None:
            rng = np.random.default_rng(self._seed)
            s1 = self._dist1.rvs(size=self._n_samples, seed=rng)
            s2 = self._dist2.rvs(size=self._n_samples, seed=rng)
            object.__setattr__(self, "_samples_cache", np.sort(s1 + s2))
        return self._samples_cache

    @property
    def mean(self) -> float:
        """Mean of sum: E[X] + E[Y]."""
        return self._dist1.mean + self._dist2.mean

    @property
    def var(self) -> float:
        """Variance of sum (independent): Var[X] + Var[Y]."""
        return self._dist1.var + self._dist2.var

    @property
    def std(self) -> float:
        """Standard deviation of sum."""
        return np.sqrt(self.var)

    @property
    def median(self) -> float:
        """Median estimated from samples."""
        return float(np.median(self.get_samples()))

    def pdf(self, x: ArrayLike) -> np.ndarray:
        """PDF estimated via kernel density estimation.

        Args:
            x: Points at which to evaluate.

        Returns:
            KDE-estimated PDF values.

        Raises:
            AttributeError: If called on a discrete distribution.
        """
        if self._is_discrete:
            raise AttributeError(f"{self._name} is discrete. Use pmf() instead.")
        from scipy.stats import gaussian_kde

        x = np.asarray(x)
        samples = self.get_samples()
        kde = gaussian_kde(samples)
        return np.asarray(kde(x))

    def pmf(self, x: ArrayLike) -> np.ndarray:
        """PMF estimated from sample frequencies.

        Args:
            x: Points at which to evaluate.

        Returns:
            Frequency-estimated PMF values.

        Raises:
            AttributeError: If called on a continuous distribution.
        """
        if not self._is_discrete:
            raise AttributeError(f"{self._name} is continuous. Use pdf() instead.")
        x = np.asarray(x)
        samples = self.get_samples()
        # Count frequency of each value
        unique, counts = np.unique(samples, return_counts=True)
        freq = dict(zip(unique, counts / len(samples), strict=False))
        return np.array([freq.get(xi, 0.0) for xi in x.flat]).reshape(x.shape)

    def cdf(self, x: ArrayLike) -> np.ndarray:
        """CDF estimated from empirical distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            Empirical CDF values.
        """
        x = np.asarray(x)
        samples = self.get_samples()
        # Empirical CDF: proportion of samples <= x
        return np.array([np.mean(samples <= xi) for xi in x.flat], dtype=float).reshape(
            x.shape
        )

    def sf(self, x: ArrayLike) -> np.ndarray:
        """Survival function.

        Args:
            x: Points at which to evaluate.

        Returns:
            Survival function values (1 - CDF).
        """
        return 1 - self.cdf(x)

    def ppf(self, q: ArrayLike) -> np.ndarray:
        """PPF (quantile function) estimated from samples.

        Args:
            q: Quantiles (probabilities between 0 and 1).

        Returns:
            Estimated quantile values.
        """
        q = np.asarray(q)
        samples = self.get_samples()
        return np.percentile(samples, q * 100).reshape(q.shape)

    def rvs(
        self,
        size: int | tuple[int, ...] = 1,
        seed: int | np.random.Generator | None = None,
    ) -> np.ndarray:
        """Generate random samples from convolved distribution.

        Args:
            size: Number of samples or shape of output array.
            seed: Random seed or Generator for reproducibility.

        Returns:
            Array of random samples from X + Y.
        """
        s1 = self._dist1.rvs(size=size, seed=seed)
        # Use different seed for second distribution
        if isinstance(seed, int):
            seed2 = seed + 1
        elif seed is not None:
            seed2 = seed
        else:
            seed2 = None
        s2 = self._dist2.rvs(size=size, seed=seed2)
        return s1 + s2


class TruncatedDistribution(Distribution):
    """Distribution truncated to an interval [low, high].

    The PDF is normalized to integrate to 1 over the truncation region.

    Args:
        base: The original distribution.
        low: Lower bound (inclusive).
        high: Upper bound (inclusive).
    """

    __slots__ = ("_base", "_low", "_high", "_norm_const", "_scipy_trunc")

    def __init__(
        self,
        base: Distribution,
        low: float = float("-inf"),
        high: float = float("inf"),
    ) -> None:
        if high <= low:
            raise ValueError("high must be greater than low for truncation")

        self._base = base
        self._low = low
        self._high = high

        # Normalization constant: P(low <= X <= high)
        self._norm_const = float(base.cdf(high) - base.cdf(low))
        if self._norm_const <= 0:
            raise ValueError("Truncation interval has zero probability")

        # Use scipy's truncated distribution when base is continuous
        if not base._is_discrete:
            # Convert to standard form for scipy.stats.truncnorm-like handling
            a = (low - base.mean) / base.std
            b = (high - base.mean) / base.std
            self._scipy_trunc = stats.truncnorm(a=a, b=b, loc=base.mean, scale=base.std)
        else:
            self._scipy_trunc = None

        # Build name
        if low == float("-inf"):
            name = f"{base._name}|X\u2264{high:.4g}"
        elif high == float("inf"):
            name = f"{base._name}|X\u2265{low:.4g}"
        else:
            name = f"{base._name}|{low:.4g}\u2264X\u2264{high:.4g}"

        object.__setattr__(self, "_dist", base._dist)
        object.__setattr__(self, "_name", name)
        object.__setattr__(self, "_params", {"low": low, "high": high, **base._params})
        object.__setattr__(self, "_is_discrete", base._is_discrete)

    @property
    def mean(self) -> float:
        """Mean of truncated distribution."""
        if self._scipy_trunc is not None:
            return float(self._scipy_trunc.mean())
        # For discrete, compute numerically
        samples = self.rvs(10000, seed=42)
        return float(np.mean(samples))

    @property
    def var(self) -> float:
        """Variance of truncated distribution."""
        if self._scipy_trunc is not None:
            return float(self._scipy_trunc.var())
        samples = self.rvs(10000, seed=42)
        return float(np.var(samples))

    @property
    def std(self) -> float:
        """Standard deviation of truncated distribution."""
        return np.sqrt(self.var)

    @property
    def median(self) -> float:
        """Median of truncated distribution."""
        return float(self.ppf(0.5))

    def pdf(self, x: ArrayLike) -> np.ndarray:
        """PDF of truncated distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            PDF values (zero outside truncation bounds).

        Raises:
            AttributeError: If called on a discrete distribution.
        """
        if self._is_discrete:
            raise AttributeError(f"{self._name} is discrete. Use pmf() instead.")
        x = np.asarray(x)
        if self._scipy_trunc is not None:
            return np.asarray(self._scipy_trunc.pdf(x))
        # Manual: normalize base PDF
        result = self._base.pdf(x) / self._norm_const
        mask = (x < self._low) | (x > self._high)
        result = np.where(mask, 0.0, result)
        return result

    def pmf(self, x: ArrayLike) -> np.ndarray:
        """PMF of truncated distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            PMF values (zero outside truncation bounds).

        Raises:
            AttributeError: If called on a continuous distribution.
        """
        if not self._is_discrete:
            raise AttributeError(f"{self._name} is continuous. Use pdf() instead.")
        x = np.asarray(x)
        result = self._base.pmf(x) / self._norm_const
        mask = (x < self._low) | (x > self._high)
        result = np.where(mask, 0.0, result)
        return result

    def cdf(self, x: ArrayLike) -> np.ndarray:
        """CDF of truncated distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            CDF values (0 below low, 1 above high).
        """
        x = np.asarray(x)
        if self._scipy_trunc is not None:
            return np.asarray(self._scipy_trunc.cdf(x))
        # Clamp to truncation region
        base_cdf_low = self._base.cdf(self._low)
        base_cdf_x = self._base.cdf(np.clip(x, self._low, self._high))
        cdf_vals = (base_cdf_x - base_cdf_low) / self._norm_const
        # Handle bounds
        cdf_vals = np.where(x < self._low, 0.0, cdf_vals)
        cdf_vals = np.where(x > self._high, 1.0, cdf_vals)
        return cdf_vals

    def sf(self, x: ArrayLike) -> np.ndarray:
        """Survival function of truncated distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            Survival function values (1 - CDF).
        """
        return 1 - self.cdf(x)

    def ppf(self, q: ArrayLike) -> np.ndarray:
        """PPF of truncated distribution.

        Args:
            q: Quantiles (probabilities between 0 and 1).

        Returns:
            Quantile values within truncation bounds.
        """
        q = np.asarray(q)
        if self._scipy_trunc is not None:
            return np.asarray(self._scipy_trunc.ppf(q))
        # Manual: invert the truncated CDF
        base_cdf_low = self._base.cdf(self._low)
        target_cdf = base_cdf_low + q * self._norm_const
        return np.asarray(self._base.ppf(target_cdf))

    def rvs(
        self,
        size: int | tuple[int, ...] = 1,
        seed: int | np.random.Generator | None = None,
    ) -> np.ndarray:
        """Generate random samples from truncated distribution.

        Args:
            size: Number of samples or shape of output array.
            seed: Random seed or Generator for reproducibility.

        Returns:
            Array of random samples within truncation bounds.
        """
        if self._scipy_trunc is not None:
            return np.asarray(self._scipy_trunc.rvs(size=size, random_state=seed))
        # Inverse transform sampling
        rng = np.random.default_rng(seed)
        u = rng.uniform(0, 1, size=size)
        return self.ppf(u)


class FoldedDistribution(Distribution):
    """Distribution of |X| - the absolute value of X.

    Uses simulation for CDF/PPF computations.

    Args:
        base: The original distribution.
        n_samples: Number of samples for Monte Carlo estimation.
    """

    __slots__ = ("_base", "_n_samples", "_samples_cache", "_seed")

    def __init__(self, base: Distribution, n_samples: int = MC_SAMPLES) -> None:
        self._base = base
        self._n_samples = n_samples
        self._samples_cache: np.ndarray | None = None
        self._seed = 42

        name = f"|{base._name}|"

        object.__setattr__(self, "_dist", base._dist)
        object.__setattr__(self, "_name", name)
        object.__setattr__(self, "_params", base._params.copy())
        object.__setattr__(self, "_is_discrete", base._is_discrete)

    def get_samples(self) -> np.ndarray:
        """Get or generate cached samples.

        Returns:
            Sorted array of Monte Carlo samples from |X|.
        """
        if self._samples_cache is None:
            rng = np.random.default_rng(self._seed)
            samples = np.abs(self._base.rvs(size=self._n_samples, seed=rng))
            object.__setattr__(self, "_samples_cache", np.sort(samples))
        return self._samples_cache

    @property
    def mean(self) -> float:
        """Mean of folded distribution."""
        return float(np.mean(self.get_samples()))

    @property
    def var(self) -> float:
        """Variance of folded distribution."""
        return float(np.var(self.get_samples()))

    @property
    def std(self) -> float:
        """Standard deviation of folded distribution."""
        return np.sqrt(self.var)

    @property
    def median(self) -> float:
        """Median of folded distribution."""
        return float(np.median(self.get_samples()))

    def pdf(self, x: ArrayLike) -> np.ndarray:
        """PDF of folded distribution: f_|X|(y) = f_X(y) + f_X(-y) for y >= 0.

        Args:
            x: Points at which to evaluate.

        Returns:
            PDF values (zero for negative x).

        Raises:
            AttributeError: If called on a discrete distribution.
        """
        if self._is_discrete:
            raise AttributeError(f"{self._name} is discrete. Use pmf() instead.")
        x = np.asarray(x)
        result = self._base.pdf(x) + self._base.pdf(-x)
        return np.where(x < 0, 0.0, result)

    def pmf(self, x: ArrayLike) -> np.ndarray:
        """PMF of folded distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            PMF values (zero for negative x).

        Raises:
            AttributeError: If called on a continuous distribution.
        """
        if not self._is_discrete:
            raise AttributeError(f"{self._name} is continuous. Use pdf() instead.")
        x = np.asarray(x)
        result = self._base.pmf(x) + self._base.pmf(-x)
        # Avoid double-counting zero
        result = np.where(x == 0, self._base.pmf(0), result)
        return np.where(x < 0, 0.0, result)

    def cdf(self, x: ArrayLike) -> np.ndarray:
        """CDF of folded distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            Empirical CDF values.
        """
        x = np.asarray(x)
        samples = self.get_samples()
        return np.array([np.mean(samples <= xi) for xi in x.flat], dtype=float).reshape(
            x.shape
        )

    def sf(self, x: ArrayLike) -> np.ndarray:
        """Survival function of folded distribution.

        Args:
            x: Points at which to evaluate.

        Returns:
            Survival function values (1 - CDF).
        """
        return 1 - self.cdf(x)

    def ppf(self, q: ArrayLike) -> np.ndarray:
        """PPF of folded distribution.

        Args:
            q: Quantiles (probabilities between 0 and 1).

        Returns:
            Estimated quantile values.
        """
        q = np.asarray(q)
        samples = self.get_samples()
        return np.percentile(samples, q * 100).reshape(q.shape)

    def rvs(
        self,
        size: int | tuple[int, ...] = 1,
        seed: int | np.random.Generator | None = None,
    ) -> np.ndarray:
        """Generate random samples from folded distribution.

        Args:
            size: Number of samples or shape of output array.
            seed: Random seed or Generator for reproducibility.

        Returns:
            Array of |X| random samples.
        """
        return np.abs(self._base.rvs(size=size, seed=seed))
