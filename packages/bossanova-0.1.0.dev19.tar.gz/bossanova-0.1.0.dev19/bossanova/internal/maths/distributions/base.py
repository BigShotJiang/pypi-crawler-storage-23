"""Distribution base class.

Provides the Distribution class wrapping scipy.stats with algebraic
composition, probability queries, hypothesis testing, and visualization.

Internal exports:
    Distribution: Base distribution wrapper with full algebra support.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
from scipy.stats._distn_infrastructure import rv_discrete_frozen

from bossanova.internal.maths.distributions.algebra import DistributionAlgebraMixin
from bossanova.internal.maths.distributions.plotting import DistributionPlotMixin
from bossanova.internal.maths.distributions.probability import (
    Probability,
    rv_frozen,
)

if TYPE_CHECKING:
    from numpy.typing import ArrayLike

    from bossanova.internal.maths.distributions.derived import (
        FoldedDistribution,
        TruncatedDistribution,
    )

__all__ = [
    "Distribution",
]


class Distribution(DistributionPlotMixin, DistributionAlgebraMixin):
    """Wrapper for scipy.stats distributions with visualization.

    Provides a unified interface for probability distributions with:
    - Probability functions (pdf/pmf, cdf, ppf)
    - Random sampling (rvs)
    - Moments (mean, var, std)
    - Visualization with shading support
    - Automatic notebook rendering
    - Algebraic composition (affine transforms, convolution, truncation)
    - Probability queries via comparison operators
    - Hypothesis testing helpers

    Args:
        dist: Frozen scipy.stats distribution.
        name: Display name for the distribution.
        params: User-facing parameter dictionary for display.

    Examples:
        ```python
        # Use factory functions instead of direct instantiation
        from bossanova.internal.maths.distributions import normal, t_dist
        d = normal(mean=0, sd=1)
        d.cdf(1.96)  # 0.975
        d.ppf(0.975)  # 1.96
        ```
    """

    __slots__ = ("_dist", "_name", "_params", "_is_discrete")

    def __init__(
        self,
        dist: rv_frozen,
        name: str,
        params: dict[str, float],
    ) -> None:
        self._dist = dist
        self._name = name
        self._params = params
        self._is_discrete = isinstance(dist, rv_discrete_frozen)

    @property
    def is_discrete(self) -> bool:
        """Whether this is a discrete distribution."""
        return self._is_discrete

    @property
    def name(self) -> str:
        """Distribution name."""
        return self._name

    @property
    def params(self) -> dict[str, float]:
        """Distribution parameters."""
        return self._params.copy()

    # =========================================================================
    # Probability Functions
    # =========================================================================

    def pdf(self, x: ArrayLike) -> np.ndarray:
        """Probability density function (continuous distributions only).

        Args:
            x: Points at which to evaluate the PDF.

        Returns:
            PDF values at each point.

        Raises:
            AttributeError: If called on a discrete distribution.
        """
        if self._is_discrete:
            raise AttributeError(
                f"{self._name} is discrete. Use pmf() instead of pdf()."
            )
        return np.asarray(self._dist.pdf(x))

    def pmf(self, x: ArrayLike) -> np.ndarray:
        """Probability mass function (discrete distributions only).

        Args:
            x: Points at which to evaluate the PMF.

        Returns:
            PMF values at each point.

        Raises:
            AttributeError: If called on a continuous distribution.
        """
        if not self._is_discrete:
            raise AttributeError(
                f"{self._name} is continuous. Use pdf() instead of pmf()."
            )
        return np.asarray(self._dist.pmf(x))

    def prob(self, x: ArrayLike) -> np.ndarray:
        """Unified probability function (pdf or pmf based on type).

        Args:
            x: Points at which to evaluate.

        Returns:
            Probability values (density for continuous, mass for discrete).
        """
        if self._is_discrete:
            return self.pmf(x)
        return self.pdf(x)

    def cdf(self, x: ArrayLike) -> np.ndarray:
        """Cumulative distribution function.

        Args:
            x: Points at which to evaluate the CDF.

        Returns:
            CDF values (P(X <= x)) at each point.
        """
        return np.asarray(self._dist.cdf(x))

    def sf(self, x: ArrayLike) -> np.ndarray:
        """Survival function (1 - CDF).

        Args:
            x: Points at which to evaluate.

        Returns:
            Survival function values (P(X > x)) at each point.
        """
        return np.asarray(self._dist.sf(x))

    def ppf(self, q: ArrayLike) -> np.ndarray:
        """Percent point function (inverse CDF / quantile function).

        Args:
            q: Quantiles (probabilities between 0 and 1).

        Returns:
            Values x such that P(X <= x) = q.
        """
        return np.asarray(self._dist.ppf(q))

    def rvs(
        self,
        size: int | tuple[int, ...] = 1,
        seed: int | np.random.Generator | None = None,
    ) -> np.ndarray:
        """Generate random variates.

        Args:
            size: Number of samples or shape of output array.
            seed: Random seed or Generator for reproducibility.

        Returns:
            Array of random samples from the distribution.
        """
        return np.asarray(self._dist.rvs(size=size, random_state=seed))

    # =========================================================================
    # Moments
    # =========================================================================

    @property
    def mean(self) -> float:
        """Distribution mean (expected value)."""
        return float(self._dist.mean())

    @property
    def var(self) -> float:
        """Distribution variance."""
        return float(self._dist.var())

    @property
    def std(self) -> float:
        """Distribution standard deviation."""
        return float(self._dist.std())

    @property
    def median(self) -> float:
        """Distribution median."""
        return float(self._dist.median())

    def interval(self, confidence: float = 0.95) -> tuple[float, float]:
        """Central confidence interval containing given probability mass.

        Args:
            confidence: Probability mass in the interval (default 0.95).

        Returns:
            Tuple of (lower, upper) bounds.
        """
        lo, hi = self._dist.interval(confidence)
        return (float(lo), float(hi))

    # =========================================================================
    # Probability Queries (Comparison Operators)
    # =========================================================================

    def make_prob(self, value: float, expr: str) -> Probability:
        """Helper to create Probability with distribution context.

        Args:
            value: The probability value.
            expr: Expression string for display.

        Returns:
            Probability object with rich display.
        """
        param_str = ", ".join(f"{k}={v:.4g}" for k, v in self._params.items())
        return Probability(
            value=value, expr=expr, dist_name=f"{self._name}({param_str})"
        )

    def __gt__(self, x: float) -> Probability:
        """P(X > x) - probability of exceeding x.

        Args:
            x: Threshold value.

        Returns:
            Probability object with rich display.

        Examples:
            ```python
            d = normal()
            d > 1.96
            # P(X > 1.96) = 0.025
            ```
        """
        return self.make_prob(float(self.sf(x)), f"X > {x:.4g}")

    def __lt__(self, x: float) -> Probability:
        """P(X < x) - probability of being less than x.

        Args:
            x: Threshold value.

        Returns:
            Probability object with rich display.

        Examples:
            ```python
            d = normal()
            d < -1.96
            # P(X < -1.96) = 0.025
            ```
        """
        return self.make_prob(float(self.cdf(x)), f"X < {x:.4g}")

    def __ge__(self, x: float) -> Probability:
        """P(X >= x) - probability of being at least x.

        For continuous distributions, this equals P(X > x).
        For discrete distributions, includes P(X = x).

        Args:
            x: Threshold value.

        Returns:
            Probability object with rich display.
        """
        if self._is_discrete:
            # P(X >= x) = P(X > x-1) = 1 - P(X <= x-1)
            return self.make_prob(float(1 - self.cdf(x - 1)), f"X \u2265 {x:.4g}")
        return self.make_prob(float(self.sf(x)), f"X \u2265 {x:.4g}")

    def __le__(self, x: float) -> Probability:
        """P(X <= x) - probability of being at most x.

        Args:
            x: Threshold value.

        Returns:
            Probability object with rich display.
        """
        return self.make_prob(float(self.cdf(x)), f"X \u2264 {x:.4g}")

    def between(self, low: float, high: float) -> Probability:
        """P(low <= X <= high) - probability within an interval.

        Args:
            low: Lower bound of interval.
            high: Upper bound of interval.

        Returns:
            Probability object with rich display.

        Examples:
            ```python
            d = normal(100, 15)
            d.between(85, 115)
            # P(85 <= X <= 115) = 0.6827
            ```
        """
        prob = float(self.cdf(high) - self.cdf(low))
        if self._is_discrete:
            # For discrete, include P(X = low)
            prob += float(self.pmf(low))
        return self.make_prob(prob, f"{low:.4g} \u2264 X \u2264 {high:.4g}")

    def outside(self, low: float, high: float) -> Probability:
        """P(X < low or X > high) - probability outside an interval.

        Args:
            low: Lower bound of interval.
            high: Upper bound of interval.

        Returns:
            Probability object with rich display.

        Examples:
            ```python
            d = normal()
            d.outside(-1.96, 1.96)
            # P(X < -1.96 or X > 1.96) = 0.05
            ```
        """
        prob = float(self.cdf(low) + self.sf(high))
        return self.make_prob(prob, f"X < {low:.4g} or X > {high:.4g}")

    # =========================================================================
    # Fluent API
    # =========================================================================

    def standardize(self) -> Distribution:
        """Standardize to mean=0, sd=1.

        Returns:
            New distribution with zero mean and unit variance.

        Examples:
            ```python
            d = normal(100, 15).standardize()
            d.mean
            # 0.0
            d.std
            # 1.0
            ```
        """
        return (self - self.mean) / self.std

    def shift(self, delta: float) -> Distribution:
        """Shift distribution by adding delta to all values.

        Args:
            delta: Amount to add to the mean.

        Returns:
            New shifted distribution.

        Examples:
            ```python
            d = normal(0, 1).shift(5)
            d.mean
            # 5.0
            ```
        """
        return self + delta

    def scale(self, factor: float) -> Distribution:
        """Scale distribution by multiplying by factor.

        Args:
            factor: Multiplicative scale factor.

        Returns:
            New scaled distribution.

        Examples:
            ```python
            d = normal(0, 1).scale(2)
            d.std
            # 2.0
            ```
        """
        return self * factor

    def truncate(
        self, low: float = float("-inf"), high: float = float("inf")
    ) -> TruncatedDistribution:
        """Truncate distribution to an interval.

        Args:
            low: Lower bound (inclusive). Defaults to -inf.
            high: Upper bound (inclusive). Defaults to +inf.

        Returns:
            TruncatedDistribution over the specified interval.

        Examples:
            ```python
            d = normal().truncate(0, np.inf)  # Half-normal
            d.mean  # Approximately 0.798
            ```
        """
        from bossanova.internal.maths.distributions.derived import (
            TruncatedDistribution,
        )

        return TruncatedDistribution(self, low, high)

    def abs(self) -> FoldedDistribution:
        """Absolute value distribution: |X|.

        Returns:
            FoldedDistribution representing |X|.

        Examples:
            ```python
            d = normal().abs()  # Half-normal (folded at 0)
            d.mean  # Approximately 0.798
            ```
        """
        from bossanova.internal.maths.distributions.derived import FoldedDistribution

        return FoldedDistribution(self)

    # =========================================================================
    # Hypothesis Testing Helpers
    # =========================================================================

    def p_value(
        self, x: float, tail: Literal["two", "left", "right"] = "two"
    ) -> Probability:
        """Compute p-value for observed statistic.

        Args:
            x: Observed test statistic.
            tail: Type of test:
                - "two": Two-tailed (more extreme in either direction)
                - "left": Left-tailed (smaller values)
                - "right": Right-tailed (larger values)

        Returns:
            Probability object representing the p-value.

        Examples:
            ```python
            t = t_dist(df=29)
            t.p_value(2.3, tail="two")
            # P(|X| > 2.3) = 0.0285
            ```
        """
        if tail == "left":
            prob = float(self.cdf(x))
            expr = f"X < {x:.4g}"
        elif tail == "right":
            prob = float(self.sf(x))
            expr = f"X > {x:.4g}"
        else:  # two-tailed
            prob = 2 * float(min(self.cdf(x), self.sf(x)))
            expr = f"|X| > {abs(x):.4g}"
        return self.make_prob(prob, expr)

    def critical(
        self, alpha: float = 0.05, tail: Literal["two", "left", "right"] = "two"
    ) -> float | tuple[float, float]:
        """Compute critical value(s) for hypothesis testing.

        Args:
            alpha: Significance level.
            tail: Type of test:
                - "two": Returns (lower, upper) critical values
                - "left": Returns lower critical value
                - "right": Returns upper critical value

        Returns:
            Critical value(s) for the specified test.

        Examples:
            ```python
            t = t_dist(df=29)
            t.critical(alpha=0.05, tail="two")
            # (-2.045, 2.045)
            ```
        """
        if tail == "left":
            return float(self.ppf(alpha))
        if tail == "right":
            return float(self.ppf(1 - alpha))
        # Two-tailed
        lower = float(self.ppf(alpha / 2))
        upper = float(self.ppf(1 - alpha / 2))
        return (lower, upper)

    def reject(
        self,
        x: float,
        alpha: float = 0.05,
        tail: Literal["two", "left", "right"] = "two",
    ) -> bool:
        """Determine if null hypothesis should be rejected.

        Args:
            x: Observed test statistic.
            alpha: Significance level.
            tail: Type of test.

        Returns:
            True if null hypothesis should be rejected.

        Examples:
            ```python
            t = t_dist(df=29)
            t.reject(2.3, alpha=0.05)
            # True
            ```
        """
        return float(self.p_value(x, tail)) < alpha

    # =========================================================================
    # Quantile Properties
    # =========================================================================

    @property
    def q1(self) -> float:
        """First quartile (25th percentile)."""
        return float(self.ppf(0.25))

    @property
    def q3(self) -> float:
        """Third quartile (75th percentile)."""
        return float(self.ppf(0.75))

    @property
    def iqr(self) -> float:
        """Interquartile range (Q3 - Q1)."""
        return self.q3 - self.q1

    def p(self, q: float) -> float:
        """Quantile function alias for ppf.

        Args:
            q: Probability (between 0 and 1).

        Returns:
            Value x such that P(X <= x) = q.

        Examples:
            ```python
            d = normal()
            d.p(0.975)  # Same as d.ppf(0.975)
            # 1.96
            ```
        """
        return float(self.ppf(q))

    # =========================================================================
    # Likelihood Methods
    # =========================================================================

    def loglik(self, data: ArrayLike) -> float:
        """Compute log-likelihood of data under this distribution.

        Args:
            data: Observed data points.

        Returns:
            Sum of log-probabilities: sum(log(f(x_i))).

        Examples:
            ```python
            d = normal(0, 1)
            d.loglik([0, 0.5, -0.5])
            # -3.112...
            ```
        """
        data = np.asarray(data)
        if self._is_discrete:
            log_probs = np.log(self._dist.pmf(data))
        else:
            log_probs = self._dist.logpdf(data)
        return float(np.sum(log_probs))

    def lik(self, data: ArrayLike) -> float:
        """Compute likelihood of data under this distribution.

        Warning: For numerical stability, prefer loglik() for inference.

        Args:
            data: Observed data points.

        Returns:
            Product of probabilities: prod(f(x_i)).

        Examples:
            ```python
            d = normal(0, 1)
            d.lik([0])
            # 0.3989...
            ```
        """
        return np.exp(self.loglik(data))

    # =========================================================================
    # Display Methods
    # =========================================================================

    def __repr__(self) -> str:
        """Text representation."""
        param_str = ", ".join(f"{k}={v:.4g}" for k, v in self._params.items())
        lines = [
            f"{self._name}({param_str})",
            f"  mean = {self.mean:.4g}",
            f"  std  = {self.std:.4g}",
        ]
        return "\n".join(lines)
