"""Probability distributions with expressive algebra and automatic visualization.

This package wraps scipy.stats distributions to provide:
- User-friendly parameterization (mean/sd instead of loc/scale)
- Automatic plotting in Jupyter notebooks via _repr_html_()
- **Algebraic composition**: affine transforms, convolution, truncation
- **Probability queries**: comparison operators returning rich Probability objects
- **Hypothesis testing helpers**: p-values, critical values, rejection decisions

Distribution Algebra
--------------------
Distributions support algebraic operations::

    d = 2 * normal(5, 1) + 3  # Affine transform → Normal(13, 2)
    z = normal() + normal()   # Sum of RVs → Normal(0, √2)
    p = normal() > 1.96       # Probability query → P(X > 1.96) = 0.025

Probability Queries
-------------------
Comparison operators return rich Probability objects::

    d = normal(100, 15)
    d > 130              # P(X > 130) = 0.0228
    d.between(85, 115)   # P(85 ≤ X ≤ 115) = 0.6827

Fluent API
----------
Chain transformations for readable code::

    normal(100, 15).standardize()  # → Normal(0, 1)
    normal().truncate(0, inf)      # Half-normal

Hypothesis Testing
------------------
Built-in methods for common testing tasks::

    t = t_dist(df=29)
    t.p_value(2.3, tail="two")     # → P(|X| > 2.3) = 0.0285
    t.critical(alpha=0.05)         # → (-2.045, 2.045)
    t.reject(2.3, alpha=0.05)      # → True

Available Distributions
-----------------------
Continuous: normal, t_dist, chi2, F_dist, beta, exponential, gamma, uniform
Discrete: binomial, poisson

See Also
--------
api/distributions : Tutorial with comprehensive examples
"""

from bossanova.internal.maths.distributions.base import Distribution
from bossanova.internal.maths.distributions.derived import (
    ConvolvedDistribution,
    FoldedDistribution,
    TransformedDistribution,
    TruncatedDistribution,
)
from bossanova.internal.maths.distributions.factories import (
    F_dist,
    beta,
    binomial,
    chi2,
    exponential,
    gamma,
    normal,
    poisson,
    t_dist,
    uniform,
)
from bossanova.internal.maths.distributions.probability import (
    Probability,
    figure_to_html,
)

__all__ = [
    "ConvolvedDistribution",
    "Distribution",
    "F_dist",
    "FoldedDistribution",
    "Probability",
    "TransformedDistribution",
    "TruncatedDistribution",
    "beta",
    "binomial",
    "chi2",
    "exponential",
    "figure_to_html",
    "gamma",
    "normal",
    "poisson",
    "t_dist",
    "uniform",
]
