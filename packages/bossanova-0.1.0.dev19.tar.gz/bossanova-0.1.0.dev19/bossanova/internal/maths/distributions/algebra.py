"""Distribution algebra mixin.

Provides algebraic operations (affine transforms, convolution, operator
overloads) for Distribution objects.

Internal exports:
    DistributionAlgebraMixin: Mixin class adding algebra to Distribution.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from bossanova.internal.maths.distributions.base import Distribution

__all__ = [
    "DistributionAlgebraMixin",
]


class DistributionAlgebraMixin:
    """Mixin providing algebraic operations for distributions.

    Expects the host class to provide:
        _name: str display name.
        _params: dict[str, float] parameter dictionary.
        affine_transform(scale, shift) -> Distribution.
        add_distribution(other) -> Distribution.
    """

    # =========================================================================
    # Affine Transformations
    # =========================================================================

    def __mul__(self, scalar: float) -> Distribution:
        """Multiply distribution by a scalar: a*X.

        For location-scale families, returns a new Distribution with transformed
        parameters. For others, returns a TransformedDistribution.

        Args:
            scalar: Multiplicative factor.

        Returns:
            New distribution representing a*X.

        Examples:
            ```python
            d = 2 * normal(5, 1)  # -> Normal(10, 2)
            d.mean
            # 10.0
            ```
        """
        return self.affine_transform(scalar, 0)

    def __rmul__(self, scalar: float) -> Distribution:
        """Right multiply: scalar * X (same as X * scalar)."""
        return self.__mul__(scalar)

    def __truediv__(self, scalar: float) -> Distribution:
        """Divide distribution by scalar: X/a.

        Args:
            scalar: Divisor (must be nonzero).

        Returns:
            New distribution representing X/a.

        Examples:
            ```python
            d = normal(0, 2) / 2  # -> Normal(0, 1)
            ```
        """
        if scalar == 0:
            raise ZeroDivisionError("Cannot divide distribution by zero")
        return self.affine_transform(1 / scalar, 0)

    def __neg__(self) -> Distribution:
        """Negate distribution: -X.

        Examples:
            ```python
            d = -normal(5, 1)  # -> Normal(-5, 1)
            d.mean
            # -5.0
            ```
        """
        return self.affine_transform(-1, 0)

    def __add__(self, other: float | Distribution) -> Distribution:
        """Add scalar or distribution: X + a or X + Y.

        If other is a scalar, performs affine shift.
        If other is a Distribution, returns sum of independent RVs (convolution).

        Args:
            other: Scalar or another Distribution.

        Returns:
            New distribution representing the sum.

        Examples:
            ```python
            d = normal() + 5  # -> Normal(5, 1)
            z = normal() + normal()  # -> Normal(0, sqrt(2))
            ```
        """
        # Import here to avoid issues with TYPE_CHECKING-only import
        from bossanova.internal.maths.distributions.base import Distribution

        if isinstance(other, Distribution):
            return self.add_distribution(other)
        return self.affine_transform(1, other)

    def __radd__(self, scalar: float) -> Distribution:
        """Right add scalar: a + X."""
        return self.affine_transform(1, scalar)

    def __sub__(self, other: float | Distribution) -> Distribution:
        """Subtract scalar or distribution: X - a or X - Y.

        Args:
            other: Scalar or another Distribution.

        Returns:
            New distribution representing the difference.

        Examples:
            ```python
            d = normal(5, 1) - 5  # -> Normal(0, 1)
            ```
        """
        from bossanova.internal.maths.distributions.base import Distribution

        if isinstance(other, Distribution):
            return self.add_distribution(-other)
        return self.affine_transform(1, -other)

    def __rsub__(self, scalar: float) -> Distribution:
        """Right subtract: a - X."""
        return (-self).__add__(scalar)

    def affine_transform(self, scale: float, shift: float) -> Distribution:
        """Apply affine transformation: scale*X + shift.

        Dispatches to closed-form solutions for location-scale families,
        otherwise returns TransformedDistribution.

        Args:
            scale: Multiplicative factor.
            shift: Additive constant.

        Returns:
            New distribution representing scale*X + shift.
        """
        # Lazy imports to avoid circular references
        from bossanova.internal.maths.distributions.derived import (
            TransformedDistribution,
        )
        from bossanova.internal.maths.distributions.factories import (
            exponential,
            normal,
            t_dist,
            uniform,
        )

        # Handle trivial case
        if scale == 1 and shift == 0:
            return self

        # Check for closed-form solutions based on distribution type
        name = self._name

        if name == "Normal":
            new_mean = scale * self._params["mean"] + shift
            new_sd = abs(scale) * self._params["sd"]
            return normal(mean=new_mean, sd=new_sd)

        if name == "Student's t":
            new_mean = scale * self._params["mean"] + shift
            new_sd = abs(scale) * self._params["sd"]
            return t_dist(df=self._params["df"], mean=new_mean, sd=new_sd)

        if name == "Uniform":
            lo, hi = self._params["low"], self._params["high"]
            if scale >= 0:
                new_lo = scale * lo + shift
                new_hi = scale * hi + shift
            else:
                new_lo = scale * hi + shift
                new_hi = scale * lo + shift
            return uniform(low=new_lo, high=new_hi)

        if name == "Exponential" and shift == 0 and scale > 0:
            # scale * Exp(rate) = Exp(rate/scale)
            new_rate = self._params["rate"] / scale
            return exponential(rate=new_rate)

        # General case: use TransformedDistribution
        return TransformedDistribution(self, scale, shift)

    # =========================================================================
    # Distribution Convolution (Sum of Independent RVs)
    # =========================================================================

    def add_distribution(self, other: Distribution) -> Distribution:
        """Add two independent random variables: X + Y.

        Uses closed-form solutions when available, otherwise falls back
        to simulation-backed ConvolvedDistribution.

        Args:
            other: Another independent distribution to add.

        Returns:
            New distribution representing X + Y.
        """
        # Lazy imports to avoid circular references
        from bossanova.internal.maths.distributions.derived import (
            ConvolvedDistribution,
        )
        from bossanova.internal.maths.distributions.factories import (
            binomial,
            chi2,
            gamma,
            normal,
            poisson,
        )

        # Normal + Normal -> Normal
        if self._name == "Normal" and other._name == "Normal":
            new_mean = self._params["mean"] + other._params["mean"]
            new_var = self._params["sd"] ** 2 + other._params["sd"] ** 2
            return normal(mean=new_mean, sd=np.sqrt(new_var))

        # Poisson + Poisson -> Poisson
        if self._name == "Poisson" and other._name == "Poisson":
            return poisson(mu=self._params["mu"] + other._params["mu"])

        # Gamma + Gamma (same rate) -> Gamma
        if self._name == "Gamma" and other._name == "Gamma":
            # Both must use rate parameterization with same rate
            if "rate" in self._params and "rate" in other._params:
                if np.isclose(self._params["rate"], other._params["rate"]):
                    new_shape = self._params["shape"] + other._params["shape"]
                    return gamma(shape=new_shape, rate=self._params["rate"])
            # Both use scale with same scale
            if "scale" in self._params and "scale" in other._params:
                if np.isclose(self._params["scale"], other._params["scale"]):
                    new_shape = self._params["shape"] + other._params["shape"]
                    return gamma(shape=new_shape, scale=self._params["scale"])

        # Binomial + Binomial (same p) -> Binomial
        if self._name == "Binomial" and other._name == "Binomial":
            if np.isclose(self._params["p"], other._params["p"]):
                new_n = self._params["n"] + other._params["n"]
                return binomial(n=new_n, p=self._params["p"])

        # Chi-squared + Chi-squared -> Chi-squared
        if self._name == "Chi-squared" and other._name == "Chi-squared":
            new_df = self._params["df"] + other._params["df"]
            return chi2(df=new_df)

        # Exponential + Exponential (same rate) -> Gamma(2, rate)
        if self._name == "Exponential" and other._name == "Exponential":
            if np.isclose(self._params["rate"], other._params["rate"]):
                return gamma(shape=2, rate=self._params["rate"])

        # General case: simulation-backed
        return ConvolvedDistribution(self, other)
