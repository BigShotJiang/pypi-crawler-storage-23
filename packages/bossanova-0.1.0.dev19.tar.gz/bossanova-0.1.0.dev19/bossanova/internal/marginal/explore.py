"""Explore formula parser.

Tokenizes and parses explore formula strings into :class:`ExploreFormula`
containers using :class:`ExploreScanner` and :class:`ExploreParser`.

Grammar::

    explore_formula := lhs [ '~' rhs ]

    lhs := focal_term | contrast_fn '(' focal_term { ',' arg } ')'
    focal_term := varname [ '@' at_spec ]
    at_spec := value | '[' value_list ']' | [':']'range(' n ')' | [':']'quantile(' n ')'
    contrast_fn := 'pairwise' | 'sequential' | 'poly'
                 | 'treatment' | 'dummy' | 'sum' | 'deviation' | 'helmert'
    arg := IDENTIFIER '=' value | value

    rhs := condition [ '+' condition ]*
    condition := term [ '@' at_spec ]
"""

from bossanova.internal.containers.structs.explore import (
    Condition,
    ExploreFormula,
    ExploreFormulaError,
)
from bossanova.internal.marginal.explore_parser import ExploreParser
from bossanova.internal.marginal.explore_scanner import ExploreScanner

__all__ = [
    # Re-exported from containers for backward compatibility
    "Condition",
    "ExploreFormula",
    "ExploreFormulaError",
    # Public API
    "parse_explore_formula",
    # Backward-compatible internal API (used by tests)
    "parse_lhs",
]


def parse_explore_formula(
    formula: str,
    model_terms: list[str] | None = None,
) -> ExploreFormula:
    """Parse an explore formula string.

    Args:
        formula: Explore formula (e.g., ``"pairwise(treatment) ~ age@50"``).
        model_terms: Optional list of valid model terms for validation.

    Returns:
        Parsed ExploreFormula object.

    Raises:
        ExploreFormulaError: If formula is invalid.

    Examples:
        Simple term::

            >>> parse_explore_formula("treatment")
            ExploreFormula(focal_var='treatment', contrast_type=None, conditions=())

        Contrast function::

            >>> parse_explore_formula("pairwise(treatment)")
            ExploreFormula(focal_var='treatment', contrast_type='pairwise', conditions=())

        With conditioning::

            >>> parse_explore_formula("treatment ~ age@50")
            ExploreFormula(
                focal_var='treatment',
                contrast_type=None,
                conditions=(Condition(var='age', at_values=(50.0,)),)
            )
    """
    formula = formula.strip()
    if not formula:
        raise ExploreFormulaError("Empty explore formula", formula)

    scanner = ExploreScanner(formula)
    tokens = scanner.scan()
    parser = ExploreParser(tokens, formula)
    parsed = parser.parse()

    if model_terms is not None:
        _validate_terms(parsed.focal_var, parsed.conditions, model_terms, formula)

    return parsed


def parse_lhs(
    lhs: str, formula: str
) -> tuple[
    str,
    str | None,
    int | None,
    tuple[float | str, ...] | None,
    int | None,
    int | None,
]:
    """Parse LHS of explore formula.

    Backward-compatible wrapper that tokenizes and parses just the LHS
    portion of an explore formula.

    Args:
        lhs: Left-hand side of the formula.
        formula: Full formula for error messages.

    Returns:
        Tuple of (focal_var, contrast_type, contrast_degree, focal_at_values,
        focal_at_range, focal_at_quantile).

    Raises:
        ExploreFormulaError: If LHS syntax is invalid.

    Note:
        This wrapper does not return ``contrast_ref``. Use
        ``parse_explore_formula()`` for the full result including
        ``contrast_ref``.
    """
    lhs = lhs.strip()
    if not lhs:
        raise ExploreFormulaError("Empty LHS in explore formula", formula)

    scanner = ExploreScanner(lhs)
    tokens = scanner.scan()
    parser = ExploreParser(tokens, formula)
    result = parser._parse_lhs()  # noqa: SLF001

    # Ensure all tokens consumed
    if not parser._at_end():  # noqa: SLF001
        token = parser._peek()  # noqa: SLF001
        raise ExploreFormulaError(
            f"Unexpected token '{token.lexeme}' after LHS",
            formula,
            token.position,
        )

    return (
        result["focal_var"],
        result.get("contrast_type"),
        result.get("contrast_degree"),
        result.get("focal_at_values"),
        result.get("focal_at_range"),
        result.get("focal_at_quantile"),
    )


def _validate_terms(
    focal_var: str,
    conditions: tuple[Condition, ...],
    model_terms: list[str],
    formula: str,
) -> None:
    """Validate terms exist in model.

    Args:
        focal_var: The focal variable.
        conditions: Tuple of conditions.
        model_terms: List of valid model terms.
        formula: Full formula for error messages.

    Raises:
        ExploreFormulaError: If any term is not in the model.
    """
    if focal_var not in model_terms:
        raise ExploreFormulaError(f"Variable '{focal_var}' not in model", formula)

    for cond in conditions:
        if cond.var not in model_terms:
            raise ExploreFormulaError(f"Variable '{cond.var}' not in model", formula)
