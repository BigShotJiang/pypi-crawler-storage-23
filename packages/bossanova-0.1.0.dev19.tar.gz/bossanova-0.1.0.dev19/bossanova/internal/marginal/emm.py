"""Estimated marginal means computation.

This module provides EMM computation for categorical focal variables.

Internal exports:
    compute_emm: Compute estimated marginal means at grid points
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.containers.builders.state import build_mee_state
from bossanova.internal.containers.structs.state import MeeState
from bossanova.internal.design.reference import (
    build_counterfactual_design_matrices,
    build_reference_design_matrix,
)
from bossanova.internal.marginal.factors import get_factor_levels
from bossanova.internal.marginal.validation import validate_focal_var

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.state import FitState

__all__ = [
    "compute_conditional_emm",
    "compute_emm",
]


def compute_emm(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    explore_formula: str,
    *,
    levels: list[str] | None = None,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
    spec: object | None = None,
    how: str = "mem",
    effect_scale: str = "link",
) -> MeeState:
    """Compute estimated marginal means for a categorical focal variable.

    Supports two averaging methods via the ``how`` parameter:

    - ``"mem"`` (default): Marginal Estimated Mean.  Balanced reference grid
      (emmeans-style).  Predictions at a grid where covariates are at their
      means.
    - ``"ame"``: Average Marginal Effect / g-computation.  For each focal
      level, sets every observation to that level and averages the resulting
      predictions.  Preserves the observed covariate distribution.

    For linear models (identity link), both approaches give identical results.
    For GLMs (non-identity link), they diverge because
    ``mean(g⁻¹(Xᵢβ)) ≠ g⁻¹(mean(Xᵢ) · β)``.

    Args:
        bundle: DataBundle with model data and metadata. Used to extract:
            - X: design matrix for computing covariate means
            - X_names: column names to identify variable types
            - factor_levels: level metadata for categorical variables
        fit: FitState with fitted coefficients (fit.coef array).
        focal_var: Name of the categorical variable to compute EMMs for.
        explore_formula: The explore formula string (for result metadata).
        levels: Optional list of levels to compute EMMs for. If None,
            uses all levels from bundle.factor_levels.
        at_overrides: Optional dict of ``{variable: value}`` to fix specific
            covariates at given values instead of their means. Used for
            conditioning (e.g., ``cyl ~ wt@[3.0]`` fixes wt at 3.0).
        set_categoricals: Optional dict mapping non-focal categorical variable
            names to specific levels to pin them at (instead of marginalizing
            at column means). E.g. ``{"Ethnicity": "Asian"}``.
        spec: ModelSpec with link/family info (needed for effect_scale="response").
        how: Averaging method: ``"mem"`` for balanced reference grid
            (emmeans-style), ``"ame"`` for g-computation over observed data.
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.

    Returns:
        MeeState with grid of levels and their estimated means.

    Raises:
        ValueError: If focal_var not found in bundle.factor_levels.

    Examples:
        Compute EMMs with default (reference grid) averaging::

            mee = compute_emm(bundle, fit, "treatment", "treatment")

        G-computation averaging for a logistic regression::

            mee = compute_emm(bundle, fit, "treatment", "treatment",
                              spec=spec, how="ame", effect_scale="response")

    Note:
        For ``how="ame"`` with ``effect_scale="response"`` on a non-identity
        link, confidence intervals use the response-scale delta method
        (symmetric CIs) rather than the link-scale back-transformation
        (asymmetric CIs) used by ``how="mem"``.
    """
    validate_focal_var(bundle, focal_var)

    # Get levels from bundle or use provided
    if levels is None:
        levels = get_factor_levels(bundle, focal_var)

    # Apply at-value overrides for conditioning
    X_means = bundle.X.mean(axis=0).copy()
    if at_overrides:
        X_names_list = list(bundle.X_names)
        for var_name, value in at_overrides.items():
            if var_name in X_names_list:
                idx = X_names_list.index(var_name)
                X_means[idx] = value

        unmatched = set(at_overrides) - set(X_names_list)
        if unmatched:
            warnings.warn(
                f"at-override keys {unmatched} don't match any model column; "
                f"overrides ignored. If the variable has a transform "
                f"(e.g. center(x)), use the raw name with "
                f"inverse_transforms=True (default).",
                stacklevel=4,
            )

    # G-computation path: how="ame" with non-identity link on response scale.
    # For link scale or identity link, the two approaches are mathematically
    # equivalent, so we fall through to the reference grid path for efficiency.
    use_gcomp = (
        how == "ame"
        and effect_scale == "response"
        and spec is not None
        and spec.link != "identity"
    )

    if use_gcomp:
        return _compute_emm_gcomp(
            bundle=bundle,
            fit=fit,
            focal_var=focal_var,
            explore_formula=explore_formula,
            levels=levels,
            spec=spec,
            at_overrides=at_overrides,
            set_categoricals=set_categoricals,
        )

    # Reference grid path (how="mem" or equivalent cases)
    X_ref = build_reference_design_matrix(
        X_names=bundle.X_names,
        focal_var=focal_var,
        levels=levels,
        X_means=X_means,
        set_categoricals=set_categoricals,
    )

    # Compute predictions: EMM = X_ref @ coef
    estimates_link = X_ref @ fit.coef
    estimates = estimates_link
    L_matrix = X_ref

    # Track link-scale L_matrix for CI back-transformation
    link_name: str | None = None
    L_matrix_link: np.ndarray | None = None

    if effect_scale == "response" and spec is not None and spec.link != "identity":
        from bossanova.internal.maths.family.links import (
            apply_link_inverse,
            apply_link_inverse_deriv,
        )

        estimates = np.asarray(apply_link_inverse(spec.link, estimates_link))
        # Delta method: L_data = diag(dμ/dη) @ X_ref
        d = np.asarray(apply_link_inverse_deriv(spec.link, estimates_link))
        L_matrix = d[:, np.newaxis] * X_ref
        # Store link-scale L_matrix for CI back-transformation at infer() time
        link_name = spec.link
        L_matrix_link = X_ref

    # Create grid DataFrame with conditioning columns first
    grid = _build_emm_grid(focal_var, levels, at_overrides, set_categoricals)

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="means",
        how="mem",
        effect_scale=effect_scale,
        L_matrix=L_matrix,
        link=link_name,
        L_matrix_link=L_matrix_link,
    )


def _compute_emm_gcomp(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    explore_formula: str,
    levels: list[str],
    spec: object,
    *,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
) -> MeeState:
    """G-computation EMMs: average counterfactual predictions over observed data.

    For each focal level k:
        1. Build counterfactual X_cf_k (all N rows, focal set to level k)
        2. η_k = X_cf_k @ β  (N linear predictors)
        3. pred_k = g⁻¹(η_k)  (N response-scale predictions)
        4. emm_k = mean(pred_k)
        5. L_k = mean(dμ/dη(η_k)[:, None] * X_cf_k, axis=0)  (delta method)

    Args:
        bundle: DataBundle with model data and design matrix.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical focal variable.
        explore_formula: Explore formula string for metadata.
        levels: Focal variable levels to compute EMMs for.
        spec: ModelSpec with link function info.
        at_overrides: Optional covariate overrides (applied before
            counterfactual construction).
        set_categoricals: Optional non-focal categorical pins.

    Returns:
        MeeState with g-computation estimates and response-scale L_matrix.
    """
    from bossanova.internal.maths.family.links import (
        apply_link_inverse,
        apply_link_inverse_deriv,
    )

    X = bundle.X

    # Apply at_overrides: replace column values in X before counterfactual
    if at_overrides:
        X = X.copy()
        X_names_list = list(bundle.X_names)
        for var_name, value in at_overrides.items():
            if var_name in X_names_list:
                idx = X_names_list.index(var_name)
                X[:, idx] = value

    # Apply set_categoricals: pin non-focal categoricals in X
    if set_categoricals:
        from bossanova.internal.design.names import parse_design_column_name

        X = X if at_overrides else X.copy()  # ensure we have a copy
        for j, name in enumerate(bundle.X_names):
            info = parse_design_column_name(name)
            if info.column_type == "categorical" and info.base_term in set_categoricals:
                X[:, j] = 1.0 if info.level == set_categoricals[info.base_term] else 0.0

    # Build counterfactual design matrices
    cf_matrices = build_counterfactual_design_matrices(
        X=X,
        X_names=bundle.X_names,
        focal_var=focal_var,
        levels=levels,
    )

    # Compute g-computation estimates and L_matrix for each level
    n_levels = len(levels)
    p = X.shape[1]
    estimates = np.empty(n_levels, dtype=np.float64)
    L_matrix = np.empty((n_levels, p), dtype=np.float64)

    for k, X_cf in enumerate(cf_matrices):
        eta_k = X_cf @ fit.coef  # (N,)
        pred_k = np.asarray(apply_link_inverse(spec.link, eta_k))  # (N,)
        estimates[k] = pred_k.mean()

        # Delta method: L_k = mean(dμ/dη(η_k)[:, None] * X_cf_k, axis=0)
        d_k = np.asarray(apply_link_inverse_deriv(spec.link, eta_k))  # (N,)
        L_matrix[k] = (d_k[:, np.newaxis] * X_cf).mean(axis=0)

    # Build grid DataFrame
    grid = _build_emm_grid(focal_var, levels, at_overrides, set_categoricals)

    # G-computation: no link/L_matrix_link — inference uses response-scale
    # delta method directly (symmetric CIs on response scale).
    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="means",
        how="ame",
        effect_scale="response",
        L_matrix=L_matrix,
        link=None,
        L_matrix_link=None,
    )


def _build_emm_grid(
    focal_var: str,
    levels: list[str],
    at_overrides: dict[str, float] | None,
    set_categoricals: dict[str, str] | None,
) -> pl.DataFrame:
    """Build the grid DataFrame for EMM results.

    Args:
        focal_var: Name of the focal variable.
        levels: Focal variable levels.
        at_overrides: Optional covariate overrides to include as columns.
        set_categoricals: Optional categorical pins to include as columns.

    Returns:
        Polars DataFrame with condition columns first, then focal column.
    """
    grid = pl.DataFrame({focal_var: levels})

    if set_categoricals:
        for cond_var, cond_level in set_categoricals.items():
            grid = grid.with_columns(pl.lit(cond_level).alias(cond_var))

    if at_overrides:
        for cond_var, cond_val in at_overrides.items():
            grid = grid.with_columns(pl.lit(cond_val).alias(cond_var))

    # Reorder: condition columns first, then focal
    cond_cols = list(set_categoricals or {}) + list(at_overrides or {})
    if cond_cols:
        grid = grid.select(cond_cols + [c for c in grid.columns if c not in cond_cols])

    return grid


def compute_emm_with_xref(
    X_ref: np.ndarray,
    coef: np.ndarray,
    grid: pl.DataFrame,
    explore_formula: str,
    focal_var: str,
) -> MeeState:
    """Compute EMMs using a pre-computed reference design matrix.

    Lower-level function for when the caller has already constructed
    the X_ref matrix (e.g., using a DesignMatrixBuilder).

    Args:
        X_ref: Reference design matrix, shape (n_grid, p).
        coef: Coefficient estimates, shape (p,).
        grid: Reference grid DataFrame.
        explore_formula: The explore formula string.
        focal_var: The focal variable name.

    Returns:
        MeeState with grid and estimated means.

    Note:
        This is the core EMM computation: EMM = X_ref @ β.
        Use this when you have complex design matrices or need to
        preserve transform parameters from model fitting.
    """
    estimates = X_ref @ coef

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="means",
        L_matrix=X_ref,  # Store for delta method inference
    )


def compute_conditional_emm(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    explore_formula: str,
    *,
    spec: object,
    varying_offsets: object,
    grouping_var: str,
    effect_scale: str = "link",
    levels: list[str] | None = None,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
) -> MeeState:
    """Compute per-group conditional EMMs incorporating intercept BLUPs.

    For each group g and each focal level, the conditional EMM is:
        η_g = X_ref_row @ β + b_intercept_g  (+ other BLUP contributions)

    When effect_scale="response": estimates = g⁻¹(η_g).

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        explore_formula: The explore formula string.
        spec: ModelSpec with link function info.
        varying_offsets: VaryingState with BLUPs per group.
        grouping_var: Name of the grouping variable.
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        levels: Optional list of focal levels.
        at_overrides: Optional covariate overrides.
        set_categoricals: Optional dict pinning non-focal categoricals.

    Returns:
        MeeState with per-(level, group) estimates.
    """
    from bossanova.internal.containers.structs.state import VaryingState

    validate_focal_var(bundle, focal_var)

    if levels is None:
        levels = get_factor_levels(bundle, focal_var)

    # Build reference X matrix as usual
    X_means = bundle.X.mean(axis=0).copy()
    if at_overrides:
        X_names_list = list(bundle.X_names)
        for var_name, value in at_overrides.items():
            if var_name in X_names_list:
                i = X_names_list.index(var_name)
                X_means[i] = value

    X_ref = build_reference_design_matrix(
        X_names=bundle.X_names,
        focal_var=focal_var,
        levels=levels,
        X_means=X_means,
        set_categoricals=set_categoricals,
    )

    assert isinstance(varying_offsets, VaryingState)
    n_groups = varying_offsets.n_groups
    n_levels = len(levels)

    # Compute per-group intercept BLUPs
    b_intercept = varying_offsets.effects.get("Intercept", np.zeros(n_groups))

    # Build estimates: one row per (level, group) combination
    # Shape: (n_levels * n_groups,)
    estimates_link = np.empty(n_levels * n_groups)
    L_matrix = np.empty((n_levels * n_groups, X_ref.shape[1]))

    for g in range(n_groups):
        # Total BLUP offset for this group
        blup_offset = b_intercept[g]
        for effect_name, blups in varying_offsets.effects.items():
            if effect_name == "Intercept":
                continue
            # Add slope BLUP contributions (evaluated at X_means)
            X_names_list = list(bundle.X_names)
            if effect_name in X_names_list:
                cov_idx = X_names_list.index(effect_name)
                blup_offset += blups[g] * X_means[cov_idx]

        for lev in range(n_levels):
            row_idx = lev * n_groups + g
            estimates_link[row_idx] = X_ref[lev] @ fit.coef + blup_offset
            L_matrix[row_idx] = X_ref[lev]

    estimates = estimates_link
    link_name: str | None = None
    L_matrix_link: np.ndarray | None = None

    if effect_scale == "response" and spec.link != "identity":
        from bossanova.internal.maths.family.links import (
            apply_link_inverse,
            apply_link_inverse_deriv,
        )

        estimates = np.asarray(apply_link_inverse(spec.link, estimates_link))
        d = np.asarray(apply_link_inverse_deriv(spec.link, estimates_link))
        link_name = spec.link
        L_matrix_link = L_matrix.copy()
        L_matrix = d[:, np.newaxis] * L_matrix

    # Build crossed grid: focal_var × grouping_var
    group_levels = varying_offsets.grid["level"].to_list()
    grid_focal = []
    grid_group = []
    for lev in levels:
        for gl in group_levels:
            grid_focal.append(lev)
            grid_group.append(gl)

    grid = pl.DataFrame({focal_var: grid_focal, grouping_var: grid_group})
    if at_overrides:
        for cond_var, cond_val in at_overrides.items():
            grid = grid.with_columns(pl.lit(cond_val).alias(cond_var))
        cond_cols = list(at_overrides.keys())
        grid = grid.select(cond_cols + [c for c in grid.columns if c not in cond_cols])

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="means",
        effect_scale=effect_scale,
        L_matrix=L_matrix,
        link=link_name,
        L_matrix_link=L_matrix_link,
    )
