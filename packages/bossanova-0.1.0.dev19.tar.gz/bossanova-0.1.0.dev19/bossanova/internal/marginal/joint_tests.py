"""ANOVA-style joint hypothesis tests for model terms."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from bossanova.internal.containers.builders.state import build_joint_test_state
from bossanova.internal.containers.structs.state import JointTestState
from bossanova.internal.maths.inference.hypothesis import (
    compute_chi2_test,
    compute_f_test,
)

if TYPE_CHECKING:
    import polars as pl  # noqa: F811

    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.specs import ModelSpec
    from bossanova.internal.containers.structs.state import FitState

__all__ = [
    "compute_joint_test",
]


def _combine_per_row_dfs(per_row_dfs: np.ndarray) -> float:
    """Combine per-row Satterthwaite df into a single term df2.

    For a multi-row L matrix (k-level factor), each row gets its own
    Satterthwaite df. These are combined using the Fai-Cornelius (1996)
    approximation:

        E = sum(v_i / (v_i - 2))  for v_i > 2
        df_term = 2 * E^2 / (E - q)

    When any v_i <= 2, falls back to min(per_row_dfs).

    Args:
        per_row_dfs: Per-row degrees of freedom, shape ``(q,)``.

    Returns:
        Combined denominator degrees of freedom for the term.
    """
    q = len(per_row_dfs)
    if q == 1:
        return float(per_row_dfs[0])

    # If any df <= 2, the Fai-Cornelius formula is undefined
    if np.any(per_row_dfs <= 2.0):
        return float(np.min(per_row_dfs))

    E = np.sum(per_row_dfs / (per_row_dfs - 2.0))
    if E <= q:
        return float(np.min(per_row_dfs))
    return float(2.0 * E**2 / (E - q))


def _resolve_joint_test_vcov_df(
    fit: FitState,
    bundle: DataBundle,
    spec: ModelSpec,
    errors: str,
    data: pl.DataFrame | None,
    term_L: dict[str, np.ndarray],
    ordered_terms: list[str],
) -> tuple[np.ndarray, dict[str, float] | float | None]:
    """Resolve vcov and per-term df2 based on errors specification.

    Args:
        fit: FitState with fitted coefficients and vcov.
        bundle: DataBundle with design matrix.
        spec: ModelSpec for family/random effects checks.
        errors: Error type (``"iid"``, ``"HC0"``-``"HC3"``, ``"hetero"``,
            ``"unequal_var"``).
        data: Original data frame (required for ``"unequal_var"``).
        term_L: Dictionary of term name -> L contrast matrix.
        ordered_terms: Ordered list of term names.

    Returns:
        Tuple of ``(vcov, df2_info)`` where ``df2_info`` is:
        - ``float``: scalar df_resid for iid/HC
        - ``dict[str, float]``: per-term df2 for unequal_var
        - ``None``: for non-gaussian (chi2)

    Raises:
        NotImplementedError: If errors type not supported for model family.
        ValueError: If unequal_var requirements not met.
    """
    if errors == "iid":
        # Standard behavior: use fit.vcov and fit.df_resid
        vcov = np.asarray(fit.vcov)
        df2: dict[str, float] | float | None = (
            fit.df_resid if spec.family == "gaussian" else None
        )
        return vcov, df2

    if errors == "unequal_var":
        # Welch: sandwich vcov + per-term Satterthwaite df
        from bossanova.internal.infer.asymptotic import resolve_welch

        welch_vcov, _per_coef_df = resolve_welch(spec, bundle, fit, data)

        # Compute per-term Satterthwaite df using contrast rows
        import polars as pl

        from bossanova.internal.maths.inference.welch import (
            compute_cell_info,
            extract_factors_from_formula,
            welch_satterthwaite_df_for_L,
        )

        # Re-derive cell_info (resolve_welch already validated)
        factors = extract_factors_from_formula(spec.formula, data)  # type: ignore[arg-type]
        valid_data = data.filter(pl.Series(bundle.valid_mask))  # type: ignore[union-attr]
        cell_info = compute_cell_info(fit.residuals, valid_data, factors)

        per_term_df2: dict[str, float] = {}
        for term_name in ordered_terms:
            L = term_L[term_name]
            per_row_dfs = welch_satterthwaite_df_for_L(L, bundle.X, cell_info)
            per_term_df2[term_name] = _combine_per_row_dfs(per_row_dfs)

        return welch_vcov, per_term_df2

    # HC sandwich types
    from bossanova.internal.infer.asymptotic import resolve_vcov

    hc_vcov = resolve_vcov(spec, bundle, fit, errors)
    df2 = fit.df_resid if spec.family == "gaussian" else None
    return hc_vcov, df2


def compute_joint_test(
    fit: FitState,
    bundle: DataBundle,
    spec: ModelSpec,
    terms: list[str] | None = None,
    *,
    errors: str = "iid",
    data: pl.DataFrame | None = None,
) -> JointTestState:
    """Compute joint hypothesis tests for model terms.

    Tests each model term (continuous variables, factors, and interactions)
    using direct coefficient tests. This matches R's emmeans::joint_tests()
    behavior.

    For each term:
    - Continuous variables: F-test on the single coefficient (df1=1)
    - Categorical factors: Joint F-test on all indicator coefficients
    - Interactions: Joint F-test on all interaction coefficients

    The test type is determined by the model family:
    - Gaussian (LM/LMER): F-test with df_resid
    - Non-Gaussian (GLM/GLMER): Chi-square test (asymptotic)

    Args:
        fit: FitState with fitted coefficients and vcov.
        bundle: DataBundle with X_names for term structure.
        spec: ModelSpec for model type detection.
        terms: Specific terms to test, or None for all terms.
        errors: Error structure assumption. Options:

            - ``"iid"`` (default): Standard errors from ``fit.vcov``.
            - ``"HC0"``-``"HC3"``, ``"hetero"``: Sandwich SEs.
            - ``"unequal_var"``: Welch ANOVA — sandwich SEs from per-cell
              variances with per-term Satterthwaite df2. For single-df
              terms this matches the Welch t-test; for multi-df terms
              (k-level factors), per-row dfs are combined via the
              Fai-Cornelius (1996) approximation.
        data: Original data frame, required for ``errors='unequal_var'``.

    Returns:
        JointTestState with test results for each term.

    Raises:
        ValueError: If specified terms not found in model.
        NotImplementedError: If errors type not supported for model family.

    Examples:
        Basic usage::

            from bossanova.internal.marginal import compute_joint_test
            state = compute_joint_test(fit, bundle, spec)
            # state.terms: ("x", "group", "x:group")
            # state.statistic: F or chi2 values per term
            # state.p_value: p-values per term

        Welch ANOVA::

            state = compute_joint_test(fit, bundle, spec, errors="unequal_var", data=df)
            # Per-term Satterthwaite df2 in state.df2

        Test specific terms only::

            state = compute_joint_test(fit, bundle, spec, terms=["group"])

    Note:
        Intercept is never tested. Random effect grouping factors are
        excluded for mixed models.
    """
    # Extract model components
    coef = np.asarray(fit.coef)
    X_names = list(bundle.X_names)

    # Build L matrices for each term
    term_L = build_term_L_matrices(X_names)

    # Filter to requested terms if specified
    if terms is not None:
        missing = set(terms) - set(term_L.keys())
        if missing:
            raise ValueError(
                f"Terms not found in model: {sorted(missing)}. "
                f"Available terms: {sorted(term_L.keys())}"
            )
        term_L = {t: term_L[t] for t in terms}

    if not term_L:
        # No testable terms - return empty state
        test_type = "F" if spec.family == "gaussian" else "chi2"
        return build_joint_test_state(
            terms=(),
            df1=np.array([], dtype=int),
            df2=np.array([]) if test_type == "F" else None,
            statistic=np.array([]),
            p_value=np.array([]),
            test_type=test_type,
        )

    # Determine test type from model spec
    use_f_test = spec.family == "gaussian"

    # Order terms: main effects first (no ":"), then interactions
    main_effects = [t for t in term_L.keys() if ":" not in t]
    interactions = [t for t in term_L.keys() if ":" in t]
    ordered_terms = main_effects + interactions

    # Resolve vcov and df based on errors specification
    vcov, df2_info = _resolve_joint_test_vcov_df(
        fit,
        bundle,
        spec,
        errors,
        data,
        term_L,
        ordered_terms,
    )

    # Compute tests for each term
    result_terms: list[str] = []
    result_df1: list[int] = []
    result_df2: list[float] = []
    result_statistic: list[float] = []
    result_pvalue: list[float] = []

    for term_name in ordered_terms:
        L = term_L[term_name]

        if use_f_test:
            # Resolve per-term df2
            if isinstance(df2_info, dict):
                term_df2 = df2_info[term_name]
            elif df2_info is not None:
                term_df2 = float(df2_info)
            else:
                term_df2 = fit.df_resid  # fallback

            test_result = compute_f_test(L, coef, vcov, term_df2)
            result_terms.append(term_name)
            result_df1.append(test_result.num_df)
            result_df2.append(test_result.den_df)
            result_statistic.append(test_result.F_value)
            result_pvalue.append(test_result.p_value)
        else:
            # Chi-square test for non-gaussian models
            test_result = compute_chi2_test(L, coef, vcov)
            result_terms.append(term_name)
            result_df1.append(test_result.num_df)
            result_statistic.append(test_result.chi2)
            result_pvalue.append(test_result.p_value)

    return build_joint_test_state(
        terms=tuple(result_terms),
        df1=np.array(result_df1),
        df2=np.array(result_df2) if use_f_test else None,
        statistic=np.array(result_statistic),
        p_value=np.array(result_pvalue),
        test_type="F" if use_f_test else "chi2",
        ss_type="III",  # emmeans-style tests are equivalent to Type III
    )


def build_term_L_matrices(X_names: list[str]) -> dict[str, np.ndarray]:
    """Build contrast matrices (L) for each model term.

    The L matrix for a term is constructed by:
    1. Identifying which coefficient indices belong to that term
    2. Creating an identity-like contrast for those coefficients

    Args:
        X_names: List of coefficient names from the model.

    Returns:
        Dictionary mapping term names to L matrices.
        Each L has shape [n_coefs_in_term, n_total_coefs].
    """
    n_coefs = len(X_names)
    term_indices: dict[str, list[int]] = {}

    for i, name in enumerate(X_names):
        if name.lower() == "intercept":
            continue  # Skip intercept, not tested in ANOVA

        term_name = get_term_from_coef(name)
        if term_name:
            if term_name not in term_indices:
                term_indices[term_name] = []
            term_indices[term_name].append(i)

    # Build L matrix for each term
    term_L: dict[str, np.ndarray] = {}
    for term_name, indices in term_indices.items():
        if len(indices) < 1:
            continue

        n_contrasts = len(indices)
        L = np.zeros((n_contrasts, n_coefs))
        for j, idx in enumerate(indices):
            L[j, idx] = 1.0

        term_L[term_name] = L

    return term_L


def get_term_from_coef(coef_name: str) -> str | None:
    """Extract term name from coefficient name.

    Handles various coefficient naming patterns:
    - "factor(group)[T.B]" -> "group"
    - "x" -> "x"
    - "x:y" -> "x:y"
    - "factor(a)[T.1]:factor(b)[T.2]" -> "a:b"
    - "group_B" -> "group" (underscore separator pattern)

    Args:
        coef_name: Coefficient name from model.

    Returns:
        Term name, or None if not determinable.
    """
    if not coef_name:
        return None

    # Handle interaction terms
    if ":" in coef_name:
        parts = coef_name.split(":")
        term_parts = []
        for part in parts:
            term = extract_term_part(part)
            if term:
                term_parts.append(term)
        if term_parts:
            return ":".join(term_parts)
        return None

    return extract_term_part(coef_name)


def extract_term_part(part: str) -> str | None:
    """Extract term name from a single coefficient part.

    Args:
        part: Single coefficient part (e.g., "factor(group)[T.B]" or "x").

    Returns:
        Term name (e.g., "group" or "x").
    """
    # Handle factor(var)[T.level] pattern
    if part.startswith("factor(") and "[" in part:
        start = part.find("(") + 1
        end = part.find(")")
        return part[start:end]

    # Handle var[T.level] pattern (without factor())
    if "[" in part:
        end = part.find("[")
        return part[:end]

    # Plain variable name
    return part
