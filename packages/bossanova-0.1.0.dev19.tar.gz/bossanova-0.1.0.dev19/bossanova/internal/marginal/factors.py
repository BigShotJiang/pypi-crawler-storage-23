"""Factor level extraction and handling utilities."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers.structs.data import DataBundle

__all__ = [
    "detect_factor_levels_from_data",
    "get_factor_levels",
]


def get_factor_levels(
    bundle: "DataBundle",
    var: str,
    *,
    fallback_data: "pl.DataFrame | None" = None,
    allow_inference: bool = True,
) -> list[str]:
    """Extract factor levels for a variable from bundle or data.

    Priority order:
    1. bundle.factor_levels[var] if present
    2. Infer from fallback_data[var].unique() if provided and allow_inference=True
    3. Raise ValueError if not found and no fallback

    Args:
        bundle: DataBundle with factor_levels metadata.
        var: Variable name to get levels for.
        fallback_data: Optional DataFrame to infer levels from if not in bundle.
        allow_inference: If True, allow inferring levels from data. If False,
            require levels to be in bundle.factor_levels.

    Returns:
        List of level values as strings, sorted.

    Raises:
        ValueError: If variable not found in bundle.factor_levels and no
            valid fallback available.

    Examples:
        Get levels from bundle metadata::

            levels = get_factor_levels(bundle, "treatment")
            # ["control", "drug_a", "drug_b"]

        Get levels with data fallback::

            levels = get_factor_levels(bundle, "group", fallback_data=df)
            # Inferred from df["group"].unique()
    """
    # Try bundle.factor_levels first
    if bundle.factor_levels and var in bundle.factor_levels:
        return list(bundle.factor_levels[var])

    # Try fallback data if allowed
    if allow_inference and fallback_data is not None and var in fallback_data.columns:
        return detect_factor_levels_from_data(fallback_data, var)

    # No valid source found
    available = list(bundle.factor_levels.keys()) if bundle.factor_levels else []
    raise ValueError(
        f"Factor variable '{var}' not found in bundle.factor_levels. "
        f"Available factors: {available}. "
        f"Provide fallback_data or ensure variable is properly encoded."
    )


def detect_factor_levels_from_data(
    data: "pl.DataFrame",
    var: str,
) -> list[str]:
    """Infer factor levels from unique values in data column.

    Extracts unique values and sorts them for consistent ordering.
    Values are converted to strings for uniform handling.

    Args:
        data: DataFrame containing the variable.
        var: Column name to extract levels from.

    Returns:
        Sorted list of unique values as strings.

    Raises:
        ValueError: If variable not found in data.

    Examples:
        >>> import polars as pl
        >>> df = pl.DataFrame({"group": ["B", "A", "B", "C", "A"]})
        >>> detect_factor_levels_from_data(df, "group")
        ['A', 'B', 'C']
    """
    if var not in data.columns:
        raise ValueError(
            f"Variable '{var}' not found in data. Available columns: {data.columns}"
        )

    # Get unique values, sort, convert to strings
    unique_values = data[var].unique().sort().to_list()
    return [str(v) for v in unique_values]
