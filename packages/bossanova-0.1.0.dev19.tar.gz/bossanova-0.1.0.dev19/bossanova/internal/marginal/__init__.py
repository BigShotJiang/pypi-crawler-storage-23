"""Marginal effects and estimated marginal means computation.

Call chain:
    model.explore() -> build_reference_grid() -> compute_emm() / compute_slopes() -> compute_contrasts()
"""

from bossanova.internal.marginal.explore import (
    Condition,
    ExploreFormula,
    ExploreFormulaError,
    parse_explore_formula,
)
from bossanova.internal.marginal.grid import (
    build_reference_grid,
)
from bossanova.internal.marginal.emm import (
    compute_conditional_emm,
    compute_emm,
)
from bossanova.internal.marginal.slopes import (
    compute_conditional_slopes,
    compute_slopes,
    compute_slopes_crossed,
    compute_slopes_finite_diff,
)
from bossanova.internal.marginal.compute import (
    dispatch_marginal_computation,
)
from bossanova.internal.marginal.conditions import (
    ResolvedConditions,
    combine_resolved,
    resolve_conditions,
)
from bossanova.internal.marginal.bracket_contrasts import (
    apply_bracket_contrasts,
    apply_bracket_contrasts_grouped,
    apply_rhs_bracket_contrast,
    build_bracket_contrast_matrix,
    compute_compound_bracket_contrasts,
)
from bossanova.internal.marginal.contrasts import (
    apply_contrasts,
    apply_contrasts_grouped,
    compute_contrasts,
)
from bossanova.internal.marginal.matrices import (
    build_all_pairwise_matrix,
    build_contrast_matrix,
    build_helmert_matrix,
    build_pairwise_matrix,
    build_poly_matrix,
    build_sequential_matrix,
    build_sum_to_zero_matrix,
    build_treatment_matrix,
    compose_contrast_matrix,
    get_contrast_labels,
)
from bossanova.internal.marginal.joint_tests import (
    compute_joint_test,
)
from bossanova.internal.marginal.inference import (
    compute_mee_inference,
    compute_mee_inference_fallback,
    compute_mee_se,
)

__all__ = [
    "Condition",
    "ExploreFormula",
    "ExploreFormulaError",
    "ResolvedConditions",
    "apply_bracket_contrasts",
    "apply_bracket_contrasts_grouped",
    "apply_contrasts",
    "apply_contrasts_grouped",
    "apply_rhs_bracket_contrast",
    "build_all_pairwise_matrix",
    "build_bracket_contrast_matrix",
    "build_contrast_matrix",
    "build_helmert_matrix",
    "build_pairwise_matrix",
    "build_poly_matrix",
    "build_reference_grid",
    "build_sequential_matrix",
    "build_sum_to_zero_matrix",
    "build_treatment_matrix",
    "combine_resolved",
    "compose_contrast_matrix",
    "compute_compound_bracket_contrasts",
    "compute_conditional_emm",
    "compute_conditional_slopes",
    "compute_contrasts",
    "compute_emm",
    "compute_joint_test",
    "compute_mee_inference",
    "compute_mee_inference_fallback",
    "compute_mee_se",
    "compute_slopes",
    "compute_slopes_crossed",
    "compute_slopes_finite_diff",
    "dispatch_marginal_computation",
    "get_contrast_labels",
    "parse_explore_formula",
    "resolve_conditions",
]
