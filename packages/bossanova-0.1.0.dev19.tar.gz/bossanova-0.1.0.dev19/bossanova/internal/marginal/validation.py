"""Validation guards for marginal effects operations.

Shared precondition checks for compute_emm, compute_slopes, etc.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

__all__ = [
    "validate_focal_var",
]

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle


def validate_focal_var(bundle: DataBundle, focal_var: str) -> None:
    """Guard: focal variable must be a predictor, not the response.

    Args:
        bundle: DataBundle with model metadata.
        focal_var: Name of the variable to compute marginal effects for.

    Raises:
        ValueError: If focal_var is the response variable.
    """
    if focal_var == bundle.y_name:
        raise ValueError(
            f"Cannot compute marginal effects for response variable '{focal_var}'. "
            f"explore() requires a predictor variable."
        )
