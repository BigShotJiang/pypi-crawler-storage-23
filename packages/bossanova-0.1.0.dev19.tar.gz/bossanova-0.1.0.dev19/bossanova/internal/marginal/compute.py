"""Marginal effects dispatch and routing.

Routes parsed explore formulas to the appropriate computation: EMMs for
categorical focal variables, slopes for continuous, or contrasts.
Supports ``effect_scale=`` (link/response scale), ``how=`` (mem/ame),
and ``varying=`` (marginal/conditional).
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.containers.builders.state import build_mee_state
from bossanova.internal.design.reference import build_continuous_reference_matrix
from bossanova.internal.marginal.conditions import (
    ResolvedConditions,
    get_column_values,
    resolve_conditions,
)
from bossanova.internal.marginal.contrasts import apply_contrasts
from bossanova.internal.marginal.emm import (
    compute_conditional_emm,
    compute_emm,
)
from bossanova.internal.marginal.slopes import (
    _has_focal_interaction,
    compute_conditional_slopes,
    compute_slopes,
    compute_slopes_crossed,
    compute_slopes_finite_diff,
)
from bossanova.internal.marginal.validation import validate_focal_var

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.explore import (
        ContrastExpr,
        ExploreFormula,
    )
    from bossanova.internal.containers.structs.formula import FormulaSpec
    from bossanova.internal.containers.structs.specs import ModelSpec
    from bossanova.internal.containers.structs.state import (
        FitState,
        MeeState,
        VaryingState,
    )
    from bossanova.internal.maths.transforms import StatefulTransform

__all__ = [
    "dispatch_marginal_computation",
]


def dispatch_marginal_computation(
    parsed: ExploreFormula,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame,
    *,
    spec: ModelSpec | None = None,
    formula_spec: object | None = None,
    varying_offsets: VaryingState | None = None,
    effect_scale: str = "link",
    varying: str = "exclude",
    how: str = "auto",
    inverse_transforms: bool = True,
    by: str | None = None,
) -> MeeState:
    """Route a parsed explore formula to the appropriate marginal computation.

    Validates the focal variable, determines whether it is categorical or
    continuous, and dispatches to the correct computation function.

    Supports ``effect_scale=`` and ``varying=`` for scale transforms and
    conditional (group-specific) effects in mixed models.  When RHS conditions
    contain bracket contrasts (e.g., ``Drug[A - B] ~ Dose[High - Low]``),
    applies them as a post-processing step after the main computation.

    Args:
        parsed: Parsed explore formula with focal variable and contrast info.
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        data: The model's data DataFrame (for variable lookup and type detection).
        spec: ModelSpec with link/family info (needed for effect_scale="response").
        formula_spec: FormulaSpec with learned encoding (needed for finite-diff slopes).
        varying_offsets: VaryingState with BLUPs (needed for conditional effects).
        effect_scale: ``"link"`` (default) or ``"response"`` (inverse-link / data scale).
        varying: ``"exclude"`` (default) or ``"include"`` (conditional effects).
        how: ``"auto"`` (default), ``"mem"`` (emmeans-style), or
            ``"ame"`` (g-computation / average marginal effect).
        inverse_transforms: When ``True`` (default), raw variable names and values
            are auto-resolved through learned formula transforms. Set to ``False``
            to use transformed-scale names/values directly.
        by: Grouping variable for faceted effects (default: None).

    Returns:
        MeeState with computed marginal effects.

    Raises:
        ValueError: If the focal variable is not found in data, is the response
            variable, or a ``by=`` variable is invalid.
    """
    result = _dispatch_marginal_core(
        parsed,
        bundle,
        fit,
        data,
        spec=spec,
        formula_spec=formula_spec,
        varying_offsets=varying_offsets,
        effect_scale=effect_scale,
        varying=varying,
        how=how,
        inverse_transforms=inverse_transforms,
        by=by,
    )

    # Post-process: apply RHS bracket contrasts
    if parsed.has_rhs_contrasts:
        from bossanova.internal.marginal.bracket_contrasts import (
            apply_rhs_bracket_contrast,
        )

        for cond in parsed.conditions:
            if cond.contrast_expr is not None:
                result = apply_rhs_bracket_contrast(result, cond.contrast_expr)

    return result


def _dispatch_marginal_core(
    parsed: ExploreFormula,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame,
    *,
    spec: ModelSpec | None = None,
    formula_spec: object | None = None,
    varying_offsets: VaryingState | None = None,
    effect_scale: str = "link",
    varying: str = "exclude",
    how: str = "auto",
    inverse_transforms: bool = True,
    by: str | None = None,
) -> MeeState:
    """Core dispatch logic for marginal computation.

    Called by :func:`dispatch_marginal_computation`.  See that function
    for full documentation.

    Args:
        parsed: Parsed explore formula.
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        data: The model's data DataFrame.
        spec: ModelSpec with link/family info.
        formula_spec: FormulaSpec with learned encoding.
        varying_offsets: VaryingState with BLUPs.
        effect_scale: ``"link"`` or ``"response"``.
        varying: ``"exclude"`` or ``"include"``.
        how: ``"auto"``, ``"mem"``, or ``"ame"``.
        inverse_transforms: Whether to apply forward transforms.
        by: Grouping variable for faceted effects.

    Returns:
        MeeState with computed marginal effects (before RHS contrast
        post-processing).
    """
    focal_var = parsed.focal_var

    # Compound focal variable: Drug:Dose[Active:High - Placebo:Low]
    if ":" in focal_var and parsed.has_contrast_expr:
        from bossanova.internal.marginal.bracket_contrasts import (
            compute_compound_bracket_contrasts,
        )

        resolved = _resolve_all_conditions(parsed, bundle, data, None, True)
        return compute_compound_bracket_contrasts(
            bundle,
            fit,
            focal_var,
            parsed.contrast_expr,
            data=data,
            spec=spec,
            effect_scale=effect_scale,
            resolved=resolved,
        )

    # Validate focal variable exists in data
    if focal_var not in data.columns:
        raise ValueError(f"Variable '{focal_var}' not found in data")

    # Validate focal variable is not the response
    validate_focal_var(bundle, focal_var)

    # Validate effect_scale
    if effect_scale not in ("link", "response"):
        raise ValueError(
            f"effect_scale must be 'link' or 'response', got {effect_scale!r}"
        )

    # Validate varying
    if varying not in ("exclude", "include"):
        raise ValueError(f"varying must be 'exclude' or 'include', got {varying!r}")

    # Resolve how= with smart default
    if how not in ("auto", "mem", "ame"):
        raise ValueError(f"how must be 'auto', 'mem', or 'ame', got {how!r}")
    if how == "auto":
        # Smart default: "ame" for GLMs (non-identity link), "mem" otherwise
        if spec is not None and spec.link != "identity":
            how = "ame"
        else:
            how = "mem"

    # Validate by= variable exists in data
    by_var = by
    if by_var is not None:
        by_vars: list[str] = (
            [by_var] if isinstance(by_var, str) else list(by_var)  # type: ignore[arg-type]
        )
        data_cols = set(data.columns)
        for bv in by_vars:
            if bv not in data_cols:
                raise ValueError(
                    f"by= variable '{bv}' not found in data. "
                    f"Available columns: {sorted(data_cols)}"
                )

    # Cast formula_spec for type safety
    fspec: FormulaSpec | None = formula_spec  # type: ignore[assignment]

    # Determine if conditional (group-specific) effects are requested
    is_conditional, grouping_var = _resolve_conditional(
        parsed, bundle, varying, varying_offsets
    )

    # Resolve conditions from formula RHS into typed buckets
    resolved = _resolve_all_conditions(parsed, bundle, data, fspec, inverse_transforms)

    # Resolve focal var name through transform map
    resolved_focal = _resolve_focal_var(
        focal_var, list(bundle.X_names), fspec, inverse_transforms
    )

    # Resolve focal at-range / at-quantile into concrete at-values
    parsed = _resolve_focal_at_spec(parsed, data, bundle)

    # Build at_overrides for backward-compat with existing EMM code path
    at_overrides: dict[str, float] | None = (
        resolved.at_overrides if resolved.at_overrides else None
    )

    # Detect categorical vs continuous using factor_levels as ground truth.
    # This must happen before at-value/contrast routing so that at-values
    # on categorical variables (e.g. "cyl@[4, 8]") route correctly.
    is_categorical = (
        bundle.factor_levels is not None and focal_var in bundle.factor_levels
    )
    if not is_categorical:
        # Fallback heuristic for variables not tracked in factor_levels
        col = data[focal_var]
        is_categorical = col.dtype == pl.Utf8

    # Bracket contrast expressions: Drug[A - B], Drug[* - Placebo], etc.
    if parsed.has_contrast_expr:
        return _compute_bracket_contrasts(
            bundle,
            fit,
            focal_var,
            parsed.contrast_expr,
            data=data,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
            resolved=resolved,
        )

    # Route based on formula structure
    if parsed.has_contrast:
        return _compute_contrasts(
            bundle,
            fit,
            focal_var,
            parsed.contrast_type,
            parsed.contrast_degree,
            data,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
            resolved=resolved,
            focal_at_values=parsed.focal_at_values,
            contrast_ref=parsed.contrast_ref,
            level_ordering=parsed.contrast_level_ordering,
        )

    # Focal at-values: behaviour depends on variable type
    if parsed.focal_at_values is not None:
        if is_categorical:
            # Categorical at-values (e.g. "cyl@[4, 8]"): filter to
            # requested levels and compute EMMs for that subset.
            requested_levels = [
                str(int(v)) if isinstance(v, float) and v == int(v) else str(v)
                for v in parsed.focal_at_values
            ]
            return _compute_emm_categorical(
                bundle,
                fit,
                focal_var,
                levels=requested_levels,
                at_overrides=at_overrides,
                set_categoricals=resolved.set_categoricals or None,
                spec=spec,
                effect_scale=effect_scale,
                how=how,
            )
        # Continuous at-values (e.g. "Days@[0, 3, 6, 9]"): EMMs at
        # specific values.  Forward-transform the at-values through the
        # formula transform so that raw-scale values (e.g. Days=0) become
        # transformed-scale values (e.g. center(Days) = 0 - mean(Days)).
        resolved_at = _resolve_focal_at_values(
            focal_var, parsed.focal_at_values, fspec, inverse_transforms
        )
        # Use resolved name for computation but raw name for display
        needs_display = resolved_focal != focal_var
        return _compute_emm_at_values(
            bundle,
            fit,
            resolved_focal,
            resolved_at,
            display_var=focal_var if needs_display else None,
            display_values=parsed.focal_at_values if needs_display else None,
        )

    if is_categorical:
        # Grid expansion: crossed EMMs over condition levels
        if resolved.has_grid:
            return _compute_emm_crossed(
                bundle,
                fit,
                focal_var,
                resolved=resolved,
                spec=spec,
                effect_scale=effect_scale,
            )
        if is_conditional and grouping_var is not None and varying_offsets is not None:
            return compute_conditional_emm(
                bundle=bundle,
                fit=fit,
                focal_var=focal_var,
                explore_formula=parsed.focal_var,
                spec=spec,
                varying_offsets=varying_offsets,
                grouping_var=grouping_var,
                effect_scale=effect_scale,
                at_overrides=at_overrides,
                set_categoricals=resolved.set_categoricals or None,
            )
        return _compute_emm_categorical(
            bundle,
            fit,
            focal_var,
            at_overrides=at_overrides,
            set_categoricals=resolved.set_categoricals or None,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
        )

    # Continuous focal variable → slopes
    if is_conditional and grouping_var is not None and varying_offsets is not None:
        return compute_conditional_slopes(
            bundle=bundle,
            fit=fit,
            focal_var=resolved_focal,
            explore_formula=focal_var,
            spec=spec,
            varying_offsets=varying_offsets,
            grouping_var=grouping_var,
            effect_scale=effect_scale,
        )

    # Crossed / conditioned slopes: conditions on RHS
    if resolved.has_grid or resolved.set_categoricals or resolved.at_overrides:
        # Slopes path operates on a raw-data grid where column names are raw
        # (e.g. "x2"), not design-matrix names (e.g. "scale(x2)").  Swap in
        # the pre-transform overrides so keys match data grid columns;
        # evaluate_newdata will apply formula transforms during design matrix
        # construction.
        slopes_resolved = resolved
        if resolved.raw_at_overrides:
            import attrs

            slopes_resolved = attrs.evolve(
                resolved, at_overrides=resolved.raw_at_overrides
            )
        return compute_slopes_crossed(
            bundle,
            fit,
            focal_var,
            resolved=slopes_resolved,
            data=data,
            spec=spec,
            formula_spec=fspec,
            effect_scale=effect_scale,
        )

    return _compute_marginal_slope(
        bundle,
        fit,
        focal_var,
        resolved_focal_var=resolved_focal,
        data=data,
        spec=spec,
        formula_spec=fspec,
        effect_scale=effect_scale,
        how=how,
    )


def _resolve_conditional(
    parsed: ExploreFormula,
    bundle: DataBundle,
    varying: str,
    varying_offsets: VaryingState | None,
) -> tuple[bool, str | None]:
    """Determine if conditional effects are requested and resolve grouping var.

    Args:
        parsed: Parsed explore formula.
        bundle: DataBundle with RE metadata.
        varying: "exclude" or "include".
        varying_offsets: VaryingState (None for non-mixed models).

    Returns:
        Tuple of (is_conditional, grouping_var or None).
    """
    if varying_offsets is None or bundle.re_metadata is None:
        return False, None

    grouping_vars = list(bundle.re_metadata.grouping_vars)

    # Check if any condition var is a grouping variable
    if parsed.has_conditions:
        for cond in parsed.conditions:
            if cond.var in grouping_vars:
                return True, cond.var

    # varying="include" with no condition → use first grouping var
    if varying == "include":
        return True, grouping_vars[0]

    return False, None


def _resolve_focal_at_spec(
    parsed: ExploreFormula,
    data: pl.DataFrame,
    bundle: DataBundle,
) -> ExploreFormula:
    """Resolve ``focal_at_range`` / ``focal_at_quantile`` into ``focal_at_values``.

    When the parsed formula contains ``focal_at_range=n`` or
    ``focal_at_quantile=n``, this function computes the concrete values from
    the data and returns an evolved copy with ``focal_at_values`` populated.

    Args:
        parsed: Parsed explore formula (may have range/quantile fields set).
        data: Original data DataFrame for computing range/quantile values.
        bundle: DataBundle with design matrix metadata.

    Returns:
        ExploreFormula with ``focal_at_values`` resolved (or unchanged if
        neither range nor quantile was set).
    """
    import attrs

    if parsed.focal_at_range is not None:
        col_vals = get_column_values(data, bundle, parsed.focal_var)
        values = tuple(
            float(v)
            for v in np.linspace(
                float(np.min(col_vals)),
                float(np.max(col_vals)),
                parsed.focal_at_range,
            )
        )
        return attrs.evolve(parsed, focal_at_values=values, focal_at_range=None)

    if parsed.focal_at_quantile is not None:
        col_vals = get_column_values(data, bundle, parsed.focal_var)
        n = parsed.focal_at_quantile
        probs = np.linspace(0.0, 1.0, n + 2)[1:-1]  # exclude 0 and 1
        values = tuple(float(v) for v in np.quantile(col_vals, probs))
        return attrs.evolve(parsed, focal_at_values=values, focal_at_quantile=None)

    return parsed


def _resolve_all_conditions(
    parsed: ExploreFormula,
    bundle: DataBundle,
    data: pl.DataFrame,
    fspec: FormulaSpec | None,
    inverse_transforms: bool,
) -> ResolvedConditions:
    """Resolve formula conditions into typed buckets.

    Classifies RHS conditions from the parsed formula, then applies
    forward transforms to numeric overrides.

    Args:
        parsed: Parsed explore formula.
        bundle: DataBundle with factor_levels and design matrix.
        data: Original data DataFrame.
        fspec: FormulaSpec with learned transforms (for forward resolution).
        inverse_transforms: Whether to apply forward transforms.

    Returns:
        ResolvedConditions with all conditions classified.
    """

    # Resolve formula RHS conditions
    if parsed.has_conditions:
        resolved = resolve_conditions(parsed.conditions, bundle, data)
    else:
        resolved = ResolvedConditions(
            at_overrides={},
            set_categoricals={},
            grid_categoricals={},
            grid_numerics={},
        )

    # Apply forward transforms to numeric overrides
    if resolved.at_overrides:
        raw_overrides = dict(resolved.at_overrides)
        transformed = _resolve_at_overrides(
            resolved.at_overrides, fspec, inverse_transforms
        )
        if transformed is not None and transformed != resolved.at_overrides:
            resolved = ResolvedConditions(
                at_overrides=transformed,
                set_categoricals=resolved.set_categoricals,
                grid_categoricals=resolved.grid_categoricals,
                grid_numerics=resolved.grid_numerics,
                raw_at_overrides=raw_overrides,
            )

    return resolved


def _compute_emm_categorical(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    *,
    levels: list[str] | None = None,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
) -> MeeState:
    """Compute EMMs for a categorical focal variable.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        levels: Optional subset of levels to compute EMMs for (e.g. from
            ``cyl@[4, 8]`` syntax).  If None, all levels are used.
        at_overrides: Optional covariate overrides for conditioning.
        set_categoricals: Optional dict pinning non-focal categoricals to
            specific levels (e.g. ``{"Ethnicity": "Asian"}``).
        spec: ModelSpec with link info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.

    Returns:
        MeeState with grid of levels and their estimated means.
    """
    return compute_emm(
        bundle=bundle,
        fit=fit,
        focal_var=focal_var,
        explore_formula=focal_var,
        levels=levels,
        at_overrides=at_overrides,
        set_categoricals=set_categoricals,
        spec=spec,
        effect_scale=effect_scale,
        how=how,
    )


def _compute_emm_crossed(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    *,
    resolved: ResolvedConditions,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
) -> MeeState:
    """Compute crossed EMMs over focal levels x condition grid.

    Builds a Cartesian product of focal levels with all grid conditions,
    computing one EMM row per combination.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical focal variable.
        resolved: ResolvedConditions with grid and scalar conditions.
        spec: ModelSpec with link info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.

    Returns:
        MeeState with ``n_focal x n_grid`` rows and condition columns.
    """
    from itertools import product as cartesian
    from bossanova.internal.design.reference import build_reference_row
    from bossanova.internal.marginal.factors import get_factor_levels

    validate_focal_var(bundle, focal_var)
    focal_levels = get_factor_levels(bundle, focal_var)
    X_means = bundle.X.mean(axis=0).copy()
    X_names_list = list(bundle.X_names)

    # Apply scalar numeric overrides to X_means
    for var_name, value in resolved.at_overrides.items():
        if var_name in X_names_list:
            X_means[X_names_list.index(var_name)] = value

    if resolved.at_overrides:
        unmatched = set(resolved.at_overrides) - set(X_names_list)
        if unmatched:
            warnings.warn(
                f"at-override keys {unmatched} don't match any model column; "
                f"overrides ignored. If the variable has a transform "
                f"(e.g. center(x)), use the raw name with "
                f"inverse_transforms=True (default).",
                stacklevel=4,
            )

    # Collect grid variables and their levels/values
    grid_vars: list[str] = []
    grid_vals: list[list[object]] = []
    for var, levels in resolved.grid_categoricals.items():
        grid_vars.append(var)
        grid_vals.append(levels)
    for var, values in resolved.grid_numerics.items():
        grid_vars.append(var)
        grid_vals.append(values)

    grid_combos = list(cartesian(*grid_vals)) if grid_vals else [()]
    n_focal = len(focal_levels)
    n_total = n_focal * len(grid_combos)
    p = len(bundle.X_names)
    X_ref = np.zeros((n_total, p), dtype=np.float64)

    # Build grid data for the DataFrame
    grid_data: dict[str, list[object]] = {focal_var: []}
    for gv in grid_vars:
        grid_data[gv] = []

    row_idx = 0
    for combo in grid_combos:
        # Merge combo values into set_categoricals / at_overrides
        combo_cats = dict(resolved.set_categoricals)
        row_X_means = X_means.copy()
        for i, gv in enumerate(grid_vars):
            val = combo[i]
            if isinstance(val, str):
                combo_cats[gv] = val
            elif gv in X_names_list:
                row_X_means[X_names_list.index(gv)] = float(val)

        for focal_level in focal_levels:
            X_ref[row_idx] = build_reference_row(
                bundle.X_names,
                focal_var,
                focal_level,
                row_X_means,
                set_categoricals=combo_cats or None,
            )
            grid_data[focal_var].append(focal_level)
            for i, gv in enumerate(grid_vars):
                grid_data[gv].append(combo[i])
            row_idx += 1

    # Compute estimates
    estimates_link = X_ref @ fit.coef
    estimates, L_matrix = estimates_link, X_ref
    link_name: str | None = None
    L_matrix_link: np.ndarray | None = None
    if effect_scale == "response" and spec is not None and spec.link != "identity":
        from bossanova.internal.maths.family.links import (
            apply_link_inverse,
            apply_link_inverse_deriv,
        )

        estimates = np.asarray(apply_link_inverse(spec.link, estimates_link))
        d = np.asarray(apply_link_inverse_deriv(spec.link, estimates_link))
        link_name = spec.link
        L_matrix_link = X_ref.copy()
        L_matrix = d[:, np.newaxis] * X_ref

    # Build grid DataFrame: condition columns first, then focal
    grid = pl.DataFrame(grid_data)
    if grid_vars:
        grid = grid.select(grid_vars + [c for c in grid.columns if c not in grid_vars])

    cond_str = " ~ " + ", ".join(grid_vars) if grid_vars else ""
    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=f"{focal_var}{cond_str}",
        focal_var=focal_var,
        mee_type="means",
        effect_scale=effect_scale,
        how="mem",
        L_matrix=L_matrix,
        link=link_name,
        L_matrix_link=L_matrix_link,
    )


def _compute_emm_at_values(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    at_values: tuple[float, ...],
    *,
    display_var: str | None = None,
    display_values: tuple[float, ...] | None = None,
) -> MeeState:
    """Compute EMMs at specific values of a continuous focal variable.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the continuous focal variable (design-matrix name,
            e.g. ``"center(Days)"``).
        at_values: Specific values to evaluate at (on the design-matrix scale).
        display_var: Optional raw variable name for user-facing grid/metadata.
            Defaults to ``focal_var`` when not provided.
        display_values: Optional raw-scale at-values for user-facing grid.
            Defaults to ``at_values`` when not provided.

    Returns:
        MeeState with EMM estimates at each specified value.
    """
    if display_var is None:
        display_var = focal_var
    if display_values is None:
        display_values = at_values

    X_means = bundle.X.mean(axis=0)
    X_ref = build_continuous_reference_matrix(
        X_names=bundle.X_names,
        focal_var=focal_var,
        at_values=at_values,
        X_means=X_means,
    )

    estimates = X_ref @ fit.coef

    # Build grid DataFrame with the raw (user-facing) variable name and values
    grid = pl.DataFrame({display_var: list(display_values)})

    # Build explore formula string for metadata using raw name
    vals_str = ", ".join(str(v) for v in display_values)
    explore_formula = f"{display_var}@[{vals_str}]"

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=display_var,
        mee_type="means",
        L_matrix=X_ref,
    )


def _compute_marginal_slope(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    *,
    resolved_focal_var: str | None = None,
    data: pl.DataFrame,
    spec: ModelSpec | None = None,
    formula_spec: FormulaSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
) -> MeeState:
    """Compute marginal slope for a continuous focal variable.

    Routes to ``compute_slopes_finite_diff`` when the model is a GLM
    (non-Gaussian or non-identity link) or when the focal variable
    participates in an interaction.  Otherwise falls back to the fast
    coefficient-extraction path (``compute_slopes``).

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the continuous variable (raw, user-facing).
        resolved_focal_var: Transformed column name for coefficient lookup
            (e.g. ``"center(x)"``).  Falls back to ``focal_var`` if None.
        data: Raw model data DataFrame.
        spec: ModelSpec with family/link info.
        formula_spec: FormulaSpec with learned encoding (for finite-diff).
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.

    Returns:
        MeeState with marginal slope estimate.
    """
    coef_var = resolved_focal_var or focal_var
    needs_finite_diff = False

    # GLM (non-Gaussian or non-identity link) → finite differences
    if spec is not None and (spec.family != "gaussian" or spec.link != "identity"):
        needs_finite_diff = True

    # Interactions involving focal variable → finite differences
    # Check both raw and resolved names against X_names
    if _has_focal_interaction(coef_var, bundle.X_names):
        needs_finite_diff = True

    if needs_finite_diff and formula_spec is not None:
        # Finite-diff path uses raw focal_var: grid is built in raw data
        # space and evaluate_newdata handles transforms
        return compute_slopes_finite_diff(
            bundle=bundle,
            fit=fit,
            focal_var=focal_var,
            explore_formula=focal_var,
            spec=spec,
            formula_spec=formula_spec,
            data=data,
            effect_scale=effect_scale,
            how=how,
        )

    # Fast path: coefficient extraction — use resolved name
    return compute_slopes(
        bundle=bundle,
        fit=fit,
        focal_var=coef_var,
        explore_formula=focal_var,
        spec=spec,
        effect_scale=effect_scale,
    )


# ---------------------------------------------------------------------------
# Transform resolution helpers
# ---------------------------------------------------------------------------

# Transforms that support forward application to raw-scale values.
_INVERTIBLE_TRANSFORMS = frozenset({"center", "norm", "zscore", "scale"})


def _build_var_transform_map(
    formula_spec: FormulaSpec | None,
) -> dict[str, tuple[str, StatefulTransform]]:
    """Build a mapping from raw variable names to their transformed column info.

    Inspects ``formula_spec.transform_state`` keys (e.g. ``"center(x)"``) and
    extracts the inner variable name.  Only includes invertible transforms
    (center, norm, zscore, scale).

    Args:
        formula_spec: FormulaSpec with transform_state and transforms dicts.

    Returns:
        Dict mapping raw variable name to ``(transformed_col_name, transform_obj)``.
        Empty dict when no transforms are present or formula_spec is None.
    """
    if formula_spec is None:
        return {}

    result: dict[str, tuple[str, StatefulTransform]] = {}
    for key, state in formula_spec.transform_state.items():
        transform_type = state.get("type", "")
        if transform_type not in _INVERTIBLE_TRANSFORMS:
            continue
        # Extract inner variable from state dict
        variable = state.get("variable", "")
        if not variable:
            continue
        transform_obj = formula_spec.transforms.get(key)
        if transform_obj is not None:
            result[variable] = (key, transform_obj)  # type: ignore[assignment]
    return result


def _resolve_at_overrides(
    at_overrides: dict[str, float] | None,
    formula_spec: FormulaSpec | None,
    inverse_transforms: bool,
) -> dict[str, float] | None:
    """Remap at-override keys through forward transforms; optionally transform values.

    Always remaps raw variable names to their transformed column names
    (e.g. ``"x"`` → ``"center(x)"``).  When ``inverse_transforms=True``,
    also forward-transforms the values (e.g. ``50`` → ``50 - mean``).
    When ``False``, values are left as-is on the user-specified scale.

    Args:
        at_overrides: Original at-override dict (may be None).
        formula_spec: FormulaSpec with learned transforms.
        inverse_transforms: Whether to apply forward transforms to values.

    Returns:
        Resolved at_overrides dict, or None if input was None.

    Raises:
        ValueError: If a raw variable maps to a non-invertible transform
            (rank, signed_rank) and ``inverse_transforms=True``.
    """
    if at_overrides is None or formula_spec is None:
        return at_overrides

    # Check for non-invertible transforms on any override variable
    if inverse_transforms:
        for key in at_overrides:
            for tkey, tstate in formula_spec.transform_state.items():
                variable = tstate.get("variable", "")
                if (
                    variable == key
                    and tstate.get("type", "") not in _INVERTIBLE_TRANSFORMS
                ):
                    raise ValueError(
                        f"Cannot use inverse_transforms with {tstate.get('type', '')}({key}): "
                        f"this transform is not invertible. Use inverse_transforms=False "
                        f"and provide values on the transformed scale, or use the "
                        f"transformed column name '{tkey}' directly."
                    )

    var_map = _build_var_transform_map(formula_spec)
    if not var_map:
        return at_overrides

    resolved: dict[str, float] = {}
    for var_name, value in at_overrides.items():
        if var_name in var_map:
            col_name, transform_obj = var_map[var_name]
            if inverse_transforms:
                transformed = transform_obj.transform(np.array([value]))
                resolved[col_name] = float(transformed[0])
            else:
                resolved[col_name] = value
        else:
            resolved[var_name] = value
    return resolved


def _resolve_focal_at_values(
    focal_var: str,
    at_values: tuple[float, ...],
    formula_spec: FormulaSpec | None,
    inverse_transforms: bool,
) -> tuple[float, ...]:
    """Forward-transform focal at-values through a formula transform.

    When ``inverse_transforms=True`` and the focal variable has a learned
    transform (e.g. ``center(x)``), applies the forward transform to each
    at-value so that raw-scale values become transformed-scale values.

    Args:
        focal_var: Raw focal variable name (e.g. ``"Days"``).
        at_values: User-specified at-values on the raw scale.
        formula_spec: FormulaSpec with learned transforms.
        inverse_transforms: Whether to apply forward transforms.

    Returns:
        Transformed at-values tuple (or original if no transform applies).
    """
    if not inverse_transforms or formula_spec is None:
        return at_values

    var_map = _build_var_transform_map(formula_spec)
    if focal_var not in var_map:
        return at_values

    _, transform_obj = var_map[focal_var]
    transformed = transform_obj.transform(np.array(at_values))
    return tuple(float(v) for v in transformed)


def _resolve_focal_var(
    focal_var: str,
    X_names: tuple[str, ...] | list[str],
    formula_spec: FormulaSpec | None,
    inverse_transforms: bool,
) -> str:
    """Resolve a raw focal variable name to its transformed column name.

    Always attempts resolution regardless of ``inverse_transforms`` so that
    raw variable names (e.g. ``"x"``) are mapped to their design-matrix
    column names (e.g. ``"center(x)"``).

    Args:
        focal_var: Raw variable name from the explore formula.
        X_names: Design matrix column names.
        formula_spec: FormulaSpec with transform info.
        inverse_transforms: Unused; kept for API compatibility.

    Returns:
        The resolved column name (transformed or original).
    """
    if formula_spec is None:
        return focal_var

    # If the focal var is already in X_names, no resolution needed
    if focal_var in X_names:
        return focal_var

    var_map = _build_var_transform_map(formula_spec)
    if focal_var in var_map:
        col_name, _ = var_map[focal_var]
        if col_name in X_names:
            return col_name

    return focal_var


def _compute_contrasts(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    contrast_type: str | None,
    contrast_degree: int | None,
    data: pl.DataFrame,
    *,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
    resolved: ResolvedConditions | None = None,
    focal_at_values: tuple[float | str, ...] | None = None,
    contrast_ref: str | None = None,
    level_ordering: tuple[str, ...] | None = None,
) -> MeeState:
    """Compute contrasts for a categorical focal variable.

    First computes EMMs, then applies the requested contrast matrix.
    When ``resolved`` contains grid conditions, computes crossed EMMs and
    applies grouped contrasts.  When ``focal_at_values`` is provided
    (e.g. from ``pairwise(cyl@[4, 8])``), contrasts are computed only
    over the requested subset of levels.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        contrast_type: Type of contrast (pairwise, sequential, poly, treatment,
            sum, helmert).
        contrast_degree: Degree for polynomial contrasts (None = max).
        data: Model data for level extraction.
        spec: ModelSpec with link info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.
        resolved: Resolved conditions for conditioning.
        focal_at_values: Optional subset of levels from at-spec syntax
            (e.g. ``pairwise(cyl@[4, 8])``).
        contrast_ref: Reference level name for treatment contrasts.
        level_ordering: Explicit level ordering for order-dependent contrasts
            (e.g. from ``poly(dose, [low, med, high])``).

    Returns:
        MeeState with contrast estimates.
    """
    # Convert focal_at_values to string level names for filtering
    requested_levels: list[str] | None = None
    if focal_at_values is not None:
        requested_levels = [
            str(int(v)) if isinstance(v, float) and v == int(v) else str(v)
            for v in focal_at_values
        ]

    # Resolve ref_idx from contrast_ref (level name -> index)
    ref_idx = None
    if contrast_ref is not None:
        # We'll resolve the ref_idx after computing EMMs, when we know the levels

        def _resolve_ref_idx(grid: "pl.DataFrame") -> int:
            levels = grid[focal_var].to_list()
            if contrast_ref in levels:
                return levels.index(contrast_ref)
            # Try numeric conversion (e.g. ref="4" matching level "4")
            str_levels = [str(lv) for lv in levels]
            if contrast_ref in str_levels:
                return str_levels.index(contrast_ref)
            raise ValueError(
                f"Reference level '{contrast_ref}' not found in "
                f"levels of '{focal_var}': {levels}"
            )

    if resolved is not None and resolved.has_grid:
        # Crossed path: compute EMMs over the full grid, then group contrasts
        from bossanova.internal.marginal.contrasts import (
            apply_contrasts_grouped,
        )

        emm_state = _compute_emm_crossed(
            bundle,
            fit,
            focal_var,
            resolved=resolved,
            spec=spec,
            effect_scale=effect_scale,
        )
        if contrast_ref is not None:
            ref_idx = _resolve_ref_idx(emm_state.grid)
        return apply_contrasts_grouped(
            emm_state,
            contrast_type,
            degree=contrast_degree,
            ref_idx=ref_idx,
            level_ordering=level_ordering,
        )

    # Simple path: no grid
    at_overrides = resolved.at_overrides if resolved and resolved.at_overrides else None
    set_cats = (
        resolved.set_categoricals if resolved and resolved.set_categoricals else None
    )
    emm_state = _compute_emm_categorical(
        bundle,
        fit,
        focal_var,
        levels=requested_levels,
        at_overrides=at_overrides,
        set_categoricals=set_cats,
        spec=spec,
        effect_scale=effect_scale,
        how=how,
    )
    if contrast_ref is not None:
        ref_idx = _resolve_ref_idx(emm_state.grid)
    return apply_contrasts(
        emm_state,
        contrast_type,
        degree=contrast_degree,
        ref_idx=ref_idx,
        level_ordering=level_ordering,
    )


def _compute_bracket_contrasts(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    contrast_expr: ContrastExpr,
    *,
    data: pl.DataFrame,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
    resolved: ResolvedConditions | None = None,
) -> MeeState:
    """Compute bracket contrast expression for a categorical focal variable.

    First computes EMMs, then applies the bracket contrast matrix.
    When ``resolved`` contains grid conditions, computes crossed EMMs
    and applies grouped bracket contrasts.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        contrast_expr: ContrastExpr AST from the parser.
        data: Model data DataFrame.
        spec: ModelSpec with link info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.
        resolved: Resolved conditions for conditioning.

    Returns:
        MeeState with bracket contrast estimates.
    """
    from bossanova.internal.marginal.bracket_contrasts import (
        apply_bracket_contrasts,
        apply_bracket_contrasts_grouped,
    )

    if resolved is not None and resolved.has_grid:
        emm_state = _compute_emm_crossed(
            bundle,
            fit,
            focal_var,
            resolved=resolved,
            spec=spec,
            effect_scale=effect_scale,
        )
        return apply_bracket_contrasts_grouped(emm_state, contrast_expr)

    at_overrides = resolved.at_overrides if resolved and resolved.at_overrides else None
    set_cats = (
        resolved.set_categoricals if resolved and resolved.set_categoricals else None
    )
    emm_state = _compute_emm_categorical(
        bundle,
        fit,
        focal_var,
        at_overrides=at_overrides,
        set_categoricals=set_cats,
        spec=spec,
        effect_scale=effect_scale,
        how=how,
    )
    return apply_bracket_contrasts(emm_state, contrast_expr)
