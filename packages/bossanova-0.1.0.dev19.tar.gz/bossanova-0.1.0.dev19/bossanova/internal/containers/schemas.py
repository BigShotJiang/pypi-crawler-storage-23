"""DataFrame schemas for model outputs using Polars Schema.

Provides Polars Schema definitions for type-safe DataFrame construction
and validation across model output properties. All column name constants
live in the ``Col`` namespace class for single-point-of-change renames.
"""

from polars import Float64, Int32, Int64, Schema, String

__all__ = [
    "AugmentedDataCols",
    "Col",
    "ComparisonAic",
    "ComparisonBic",
    "ComparisonCv",
    "ComparisonDevianceChi2",
    "ComparisonDevianceF",
    "ComparisonFTest",
    "ComparisonLrt",
    "DiagnosticsBase",
    "DiagnosticsCvCols",
    "DiagnosticsGaussian",
    "DiagnosticsGlm",
    "DiagnosticsLmer",
    "DiagnosticsPredCvCols",
    "EffectsAsympCols",
    "EffectsBaseCols",
    "EffectsBootCols",
    "EffectsPermCols",
    "MetadataBase",
    "MetadataMixed",
    "ParamsAsymp",
    "ParamsBase",
    "ParamsBoot",
    "ParamsCv",
    "ParamsPerm",
    "PowerSummaryCols",
    "PredictionsAsymp",
    "PredictionsBase",
    "PredictionsCv",
    "ResamplesRawSchema",
    "SimulationsInferCols",
    "VaryingCorrSchema",
    "VaryingOffsetsBaseCols",
    "VaryingOffsetsInferSuffix",
    "VaryingParamsBaseCols",
    "VaryingSpreadBase",
    "VaryingSpreadInfer",
]


# =============================================================================
# Column name constants — single source of truth
# =============================================================================


class Col:
    """Namespace for all column name constants used across DataFrame outputs.

    Organized by category. Use ``Col.XXX`` everywhere column names appear
    (schema definitions, dict keys, tuple constants) so that renaming a
    column is a single-point change.
    """

    # -- Shared inference columns --
    TERM: str = "term"
    ESTIMATE: str = "estimate"
    SE: str = "se"
    STATISTIC: str = "statistic"
    DF: str = "df"
    P_VALUE: str = "p_value"
    CI_LOWER: str = "ci_lower"
    CI_UPPER: str = "ci_upper"

    # -- Params-specific --
    PRE: str = "pre"
    PRE_SD: str = "pre_sd"
    N_BOOT: str = "n_boot"
    N_PERM: str = "n_perm"

    # -- Predictions --
    FITTED: str = "fitted"
    LINK: str = "link"
    CV_FITTED: str = "cv_fitted"
    CV_RESIDUAL: str = "cv_residual"
    CV_FOLD: str = "cv_fold"

    # -- Diagnostics --
    DF_MODEL: str = "df_model"
    DF_RESID: str = "df_resid"
    AIC: str = "aic"
    BIC: str = "bic"
    LOGLIK: str = "loglik"
    RSQUARED: str = "rsquared"
    RSQUARED_ADJ: str = "rsquared_adj"
    FSTATISTIC: str = "fstatistic"
    FSTATISTIC_PVALUE: str = "fstatistic_pvalue"
    SIGMA: str = "sigma"
    NULL_DEVIANCE: str = "null_deviance"
    DEVIANCE: str = "deviance"
    DISPERSION: str = "dispersion"
    PSEUDO_RSQUARED: str = "pseudo_rsquared"
    RSQUARED_MARGINAL: str = "rsquared_marginal"
    RSQUARED_CONDITIONAL: str = "rsquared_conditional"
    ICC: str = "icc"

    # -- Metadata --
    NOBS: str = "nobs"
    NOBS_TOTAL: str = "nobs_total"
    NOBS_MISSING: str = "nobs_missing"
    NPARAMS: str = "nparams"
    NGROUPS: str = "ngroups"

    # -- Varying (random effects) --
    COMPONENT: str = "component"
    GROUP: str = "group"
    LEVEL: str = "level"
    EFFECT1: str = "effect1"
    EFFECT2: str = "effect2"
    CORR: str = "corr"
    CI_METHOD: str = "ci_method"

    # -- Resamples --
    RESAMPLE: str = "resample"
    VALUE: str = "value"
    OBSERVED: str = "observed"
    MEAN: str = "mean"
    N_RESAMPLES: str = "n_resamples"
    METHOD: str = "method"
    CONTEXT: str = "context"

    # -- Compare (R-convention uppercase column names) --
    MODEL: str = "model"
    NPAR: str = "npar"
    CHI2: str = "chi2"
    AIC_R: str = "AIC"
    BIC_R: str = "BIC"
    PRE_R: str = "PRE"
    F_STAT: str = "F"
    RSS: str = "rss"
    SS: str = "ss"
    DEV_DIFF: str = "dev_diff"
    T_STAT: str = "t_stat"
    CV_SCORE: str = "cv_score"
    CV_SE: str = "cv_se"
    DIFF: str = "diff"
    DIFF_SE: str = "diff_se"
    DELTA_AIC: str = "delta_AIC"
    DELTA_BIC: str = "delta_BIC"
    WEIGHT: str = "weight"

    # -- Augmented data --
    RESID: str = "resid"
    HAT: str = "hat"
    STD_RESID: str = "std_resid"
    COOKSD: str = "cooksd"

    # -- Joint test --
    DF1: str = "df1"
    DF2: str = "df2"
    F_RATIO: str = "f_ratio"
    CHISQ: str = "Chisq"

    # -- Simulations --
    SIM_MEAN: str = "sim_mean"
    SIM_SD: str = "sim_sd"

    # -- Power analysis --
    POWER: str = "power"
    POWER_CI_LOWER: str = "power_ci_lower"
    POWER_CI_UPPER: str = "power_ci_upper"
    TRUE_VALUE: str = "true_value"
    COVERAGE: str = "coverage"
    BIAS: str = "bias"
    RMSE: str = "rmse"
    MEAN_SE: str = "mean_se"
    EMPIRICAL_SE: str = "empirical_se"
    N_SIMS: str = "n_sims"
    N_FAILED: str = "n_failed"
    N: str = "n"

    # -- CV diagnostics --
    CV_RMSE: str = "cv_rmse"
    CV_MAE: str = "cv_mae"
    CV_RSQUARED: str = "cv_rsquared"
    CV_K: str = "cv_k"
    CV_RMSE_SD: str = "cv_rmse_sd"
    CV_MAE_SD: str = "cv_mae_sd"
    CV_RSQUARED_SD: str = "cv_rsquared_sd"
    CV_DEVIANCE: str = "cv_deviance"

    # -- Optimizer diagnostics --
    CONVERGED: str = "converged"
    N_ITER: str = "n_iter"
    OPTIMIZER: str = "optimizer"
    IS_SINGULAR: str = "is_singular"
    N_THETA: str = "n_theta"

    # -- Dynamic prefixes (used with f-strings) --
    PI_LOWER_PREFIX: str = "pi_lower_"
    PI_UPPER_PREFIX: str = "pi_upper_"
    TAU2_PREFIX: str = "tau2_"
    RHO_PREFIX: str = "rho_"


# =============================================================================
# .params Schemas (rows = coefficients)
# =============================================================================

ParamsBase = Schema({Col.TERM: String, Col.ESTIMATE: Float64})

ParamsAsymp = Schema(
    {
        Col.TERM: String,
        Col.ESTIMATE: Float64,
        Col.SE: Float64,
        Col.CI_LOWER: Float64,
        Col.CI_UPPER: Float64,
        Col.STATISTIC: Float64,
        Col.DF: Float64,
        Col.P_VALUE: Float64,
    }
)

ParamsBoot = Schema(
    {
        Col.TERM: String,
        Col.ESTIMATE: Float64,
        Col.SE: Float64,
        Col.CI_LOWER: Float64,
        Col.CI_UPPER: Float64,
        Col.STATISTIC: Float64,
        Col.DF: Float64,
        Col.P_VALUE: Float64,
    }
)

ParamsPerm = Schema(
    {
        Col.TERM: String,
        Col.ESTIMATE: Float64,
        Col.SE: Float64,
        Col.STATISTIC: Float64,
        Col.DF: Float64,
        Col.P_VALUE: Float64,
    }
)

ParamsCv = Schema(
    {
        Col.TERM: String,
        Col.ESTIMATE: Float64,
        Col.PRE: Float64,
        Col.PRE_SD: Float64,
    }
)

# =============================================================================
# .predictions Schemas (rows = observations)
# =============================================================================

PredictionsBase = Schema({Col.FITTED: Float64})

PredictionsAsymp = Schema(
    {
        Col.FITTED: Float64,
        Col.SE: Float64,
        Col.CI_LOWER: Float64,
        Col.CI_UPPER: Float64,
    }
)

PredictionsCv = Schema(
    {
        Col.FITTED: Float64,
        Col.CV_FITTED: Float64,
        Col.CV_RESIDUAL: Float64,
        Col.CV_FOLD: Int32,
    }
)

# =============================================================================
# .data augmented columns (appended to raw data by augment_data_with_diagnostics)
# =============================================================================

AugmentedDataCols = (Col.FITTED, Col.RESID, Col.HAT, Col.STD_RESID, Col.COOKSD)

# =============================================================================
# .simulations Schemas (post-fit inference columns)
# =============================================================================

# Columns added by .infer() to .simulations
SimulationsInferCols = (Col.SIM_MEAN, Col.SIM_SD, "sim_q025", "sim_q975")


# =============================================================================
# Power analysis columns (rows = grid points × terms)
# =============================================================================

# Note: Grid columns (n, sigma, coef values) are dynamic — only metric columns are fixed
PowerSummaryCols = (
    Col.TERM,
    Col.TRUE_VALUE,
    Col.POWER,
    Col.POWER_CI_LOWER,
    Col.POWER_CI_UPPER,
    Col.COVERAGE,
    Col.BIAS,
    Col.RMSE,
    Col.MEAN_SE,
    Col.EMPIRICAL_SE,
    Col.N_SIMS,
    Col.N_FAILED,
)


# =============================================================================
# .effects Schemas (rows = grid points for EMM/marginal effects)
# =============================================================================

# Note: Grid columns are dynamic based on explore formula
EffectsBaseCols = (Col.ESTIMATE,)

EffectsAsympCols = (
    Col.ESTIMATE,
    Col.SE,
    Col.CI_LOWER,
    Col.CI_UPPER,
    Col.STATISTIC,
    Col.DF,
    Col.P_VALUE,
)

EffectsBootCols = (
    Col.ESTIMATE,
    Col.SE,
    Col.CI_LOWER,
    Col.CI_UPPER,
    Col.STATISTIC,
    Col.DF,
)

EffectsPermCols = (
    Col.ESTIMATE,
    Col.SE,
    Col.STATISTIC,
    Col.DF,
    Col.P_VALUE,
)


# =============================================================================
# .metadata Schemas (single row = model-level sample/structural info)
# =============================================================================

MetadataBase = Schema(
    {
        Col.NOBS: Int64,
        Col.NOBS_TOTAL: Int64,
        Col.NOBS_MISSING: Int64,
        Col.NPARAMS: Int64,
    }
)

MetadataMixed = Schema(
    {
        Col.NOBS: Int64,
        Col.NOBS_TOTAL: Int64,
        Col.NOBS_MISSING: Int64,
        Col.NPARAMS: Int64,
        Col.NGROUPS: Int64,
    }
)


# =============================================================================
# .diagnostics Schemas (single row = model-level diagnostics)
# =============================================================================

# Currently unused — retained as superset reference schema.
DiagnosticsBase = Schema(
    {
        Col.DF_MODEL: Float64,
        Col.DF_RESID: Float64,
        Col.AIC: Float64,
        Col.BIC: Float64,
        Col.LOGLIK: Float64,
    }
)

# Gaussian (OLS) model columns
DiagnosticsGaussian = Schema(
    {
        Col.DF_MODEL: Float64,
        Col.DF_RESID: Float64,
        Col.RSQUARED: Float64,
        Col.RSQUARED_ADJ: Float64,
        Col.FSTATISTIC: Float64,
        Col.FSTATISTIC_PVALUE: Float64,
        Col.SIGMA: Float64,
        Col.NULL_DEVIANCE: Float64,
        Col.DEVIANCE: Float64,
        Col.DISPERSION: Float64,
        Col.PSEUDO_RSQUARED: Float64,
        Col.AIC: Float64,
        Col.BIC: Float64,
        Col.LOGLIK: Float64,
    }
)

# GLM model columns
DiagnosticsGlm = Schema(
    {
        Col.DF_MODEL: Float64,
        Col.DF_RESID: Float64,
        Col.NULL_DEVIANCE: Float64,
        Col.DEVIANCE: Float64,
        Col.DISPERSION: Float64,
        Col.PSEUDO_RSQUARED: Float64,
        Col.AIC: Float64,
        Col.BIC: Float64,
        Col.LOGLIK: Float64,
    }
)

# Mixed model (lmer) columns
DiagnosticsLmer = Schema(
    {
        Col.DF_MODEL: Float64,
        Col.DF_RESID: Float64,
        Col.SIGMA: Float64,
        Col.DEVIANCE: Float64,
        Col.RSQUARED_MARGINAL: Float64,
        Col.RSQUARED_CONDITIONAL: Float64,
        Col.ICC: Float64,
        Col.AIC: Float64,
        Col.BIC: Float64,
        Col.LOGLIK: Float64,
    }
)

# CV-augmented columns (added by .infer(how='cv') after .fit())
DiagnosticsCvCols = (Col.CV_RMSE, Col.CV_MAE, Col.CV_RSQUARED, Col.CV_K)

# Prediction CV columns (added by .predict().infer(how='cv'))
DiagnosticsPredCvCols = (
    Col.CV_RMSE,
    Col.CV_RMSE_SD,
    Col.CV_MAE,
    Col.CV_MAE_SD,
    Col.CV_RSQUARED,
    Col.CV_RSQUARED_SD,
    Col.CV_K,
)


# =============================================================================
# .resamples Schema (long format = one row per resample × term)
# =============================================================================

ResamplesRawSchema = Schema(
    {
        Col.RESAMPLE: Int64,
        Col.TERM: String,
        Col.VALUE: Float64,
    }
)


# =============================================================================
# .varying_offsets Schemas (rows = group levels, BLUPs for mixed models)
# =============================================================================

# Base columns always present (effect columns are dynamic based on RE structure)
VaryingOffsetsBaseCols = (Col.GROUP, Col.LEVEL)

# Inference columns added by .infer() (per effect: pi_lower_<effect>, pi_upper_<effect>)
# These are prediction intervals, not confidence intervals (BLUPs are predictions)
VaryingOffsetsInferSuffix = (Col.PI_LOWER_PREFIX, Col.PI_UPPER_PREFIX)


# =============================================================================
# .varying_params Schemas (rows = group levels, fixed + varying)
# =============================================================================

# Same structure as .varying (group, level, effect columns)
# Values are population params + group deviations
VaryingParamsBaseCols = (Col.GROUP, Col.LEVEL)


# =============================================================================
# .varying_spread Schemas (rows = variance components)
# =============================================================================

VaryingSpreadBase = Schema({Col.COMPONENT: String, Col.ESTIMATE: Float64})

VaryingSpreadInfer = Schema(
    {
        Col.COMPONENT: String,
        Col.ESTIMATE: Float64,
        Col.CI_LOWER: Float64,
        Col.CI_UPPER: Float64,
        Col.CI_METHOD: String,
    }
)

# Component naming conventions:
# - "sigma2": Residual variance
# - "tau2_<group>:<effect>": Random effect variance (e.g., "tau2_subject:Intercept")
# - "rho_<effect1>_<effect2>": Correlation between random effects
# - "icc": Intraclass correlation coefficient


# =============================================================================
# .varying_corr Schema (rows = RE correlation pairs)
# =============================================================================

VaryingCorrSchema = Schema(
    {
        Col.GROUP: String,
        Col.EFFECT1: String,
        Col.EFFECT2: String,
        Col.CORR: Float64,
    }
)


# =============================================================================
# compare() Schemas (rows = models)
# =============================================================================

# AIC-based model comparison (used by compare(method='aic')).
ComparisonAic = Schema(
    {
        Col.MODEL: String,
        Col.NPAR: Int64,
        Col.LOGLIK: Float64,
        Col.DEVIANCE: Float64,
        Col.AIC_R: Float64,
        Col.BIC_R: Float64,
        Col.DELTA_AIC: Float64,
        Col.WEIGHT: Float64,
    }
)

# BIC-based model comparison (used by compare(method='bic')).
ComparisonBic = Schema(
    {
        Col.MODEL: String,
        Col.NPAR: Int64,
        Col.LOGLIK: Float64,
        Col.DEVIANCE: Float64,
        Col.AIC_R: Float64,
        Col.BIC_R: Float64,
        Col.DELTA_BIC: Float64,
        Col.WEIGHT: Float64,
    }
)

ComparisonLrt = Schema(
    {
        Col.MODEL: String,
        Col.CHI2: Float64,
        Col.NPAR: Int64,
        Col.AIC_R: Float64,
        Col.BIC_R: Float64,
        Col.LOGLIK: Float64,
        Col.DEVIANCE: Float64,
        Col.DF: Int64,
        Col.P_VALUE: Float64,
    }
)

ComparisonFTest = Schema(
    {
        Col.MODEL: String,
        Col.PRE_R: Float64,
        Col.F_STAT: Float64,
        Col.RSS: Float64,
        Col.SS: Float64,
        Col.DF: Float64,
        Col.DF_RESID: Float64,
        Col.P_VALUE: Float64,
    }
)

ComparisonDevianceChi2 = Schema(
    {
        Col.MODEL: String,
        Col.CHI2: Float64,
        Col.DEV_DIFF: Float64,
        Col.DEVIANCE: Float64,
        Col.DF: Float64,
        Col.DF_RESID: Float64,
        Col.P_VALUE: Float64,
    }
)

ComparisonDevianceF = Schema(
    {
        Col.MODEL: String,
        Col.F_STAT: Float64,
        Col.DEV_DIFF: Float64,
        Col.DEVIANCE: Float64,
        Col.DF: Float64,
        Col.DF_RESID: Float64,
        Col.P_VALUE: Float64,
    }
)

ComparisonCv = Schema(
    {
        Col.MODEL: String,
        Col.PRE_R: Float64,
        Col.T_STAT: Float64,
        Col.CV_SCORE: Float64,
        Col.CV_SE: Float64,
        Col.DIFF: Float64,
        Col.DIFF_SE: Float64,
        Col.P_VALUE: Float64,
    }
)
