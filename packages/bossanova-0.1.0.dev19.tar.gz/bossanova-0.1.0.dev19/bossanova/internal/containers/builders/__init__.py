"""Smart constructors: basic types → containers.

Builder functions validate inputs and construct frozen container instances.
Each builder accepts primitive types and returns a frozen attrs container.
"""

from bossanova.internal.containers.builders.dataframes import (
    build_effects_dataframe,
    build_joint_test_dataframe,
    build_params_dataframe,
    build_predictions_dataframe,
    build_simulations_dataframe,
    build_varying_corr_dataframe,
    build_varying_offsets_dataframe,
    build_varying_params_dataframe,
    build_varying_spread_dataframe,
)
from bossanova.internal.containers.builders.results import (
    append_inference_columns,
)
from bossanova.internal.containers.builders.specs import (
    build_model_spec,
    build_model_spec_from_formula,
    build_simulation_spec,
    build_simulation_spec_from_formula,
    build_varying_spec,
    get_varying_random_terms,
)
from bossanova.internal.containers.builders.resamples import (
    build_mee_resamples,
    build_params_resamples,
    build_resamples_dataframe,
    build_resamples_state,
    extract_mee_names,
)
from bossanova.internal.containers.builders.state import (
    build_cv_state,
    build_fit_state,
    build_inference_state,
    build_joint_test_state,
    build_mee_state,
    build_prediction_state,
    build_simulation_inference_state,
    build_varying_spread_state,
    build_varying_state,
)

__all__ = [
    "append_inference_columns",
    "build_cv_state",
    "build_effects_dataframe",
    "build_fit_state",
    "build_inference_state",
    "build_joint_test_dataframe",
    "build_joint_test_state",
    "build_mee_resamples",
    "build_mee_state",
    "build_model_spec",
    "build_model_spec_from_formula",
    "build_params_dataframe",
    "build_params_resamples",
    "build_prediction_state",
    "build_predictions_dataframe",
    "build_resamples_dataframe",
    "build_resamples_state",
    "build_simulation_inference_state",
    "build_simulation_spec",
    "build_simulation_spec_from_formula",
    "build_simulations_dataframe",
    "build_varying_corr_dataframe",
    "build_varying_offsets_dataframe",
    "build_varying_params_dataframe",
    "build_varying_spec",
    "build_varying_spread_dataframe",
    "build_varying_spread_state",
    "build_varying_state",
    "extract_mee_names",
    "get_varying_random_terms",
]
