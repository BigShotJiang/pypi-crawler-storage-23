"""Builder functions for resamples-related containers.

Provides constructors for ResamplesState and helpers for building
resamples from inference results. Moved from state.py to keep modules
under the 800-line limit.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from bossanova.internal.containers.schemas import (
    Col,
    ResamplesRawSchema,
)
from bossanova.internal.containers.structs.state import (
    ResamplesState,
)

if TYPE_CHECKING:
    import polars as pl
    from numpy.typing import NDArray

    from bossanova.internal.containers.structs.state import (
        InferenceState,
        MeeState,
    )

__all__ = [
    "build_mee_resamples",
    "build_params_resamples",
    "build_resamples_dataframe",
    "build_resamples_state",
    "extract_mee_names",
]


def build_resamples_state(
    *,
    samples: NDArray[np.floating],
    observed: NDArray[np.floating],
    names: tuple[str, ...] | list[str],
    method: str,
    n_resamples: int,
    context: str,
) -> ResamplesState:
    """Build a ResamplesState from resampling results.

    Args:
        samples: Resampled statistics array, shape (n_resamples, k).
        observed: Observed statistics, shape (k,).
        names: Term/effect names corresponding to columns of samples.
        method: Resampling method (``"boot"`` or ``"perm"``).
        n_resamples: Number of resamples.
        context: What was resampled (``"params"`` or ``"effects"``).

    Returns:
        Frozen ResamplesState instance.

    Examples:
        >>> state = build_resamples_state(
        ...     samples=np.random.randn(100, 2),
        ...     observed=np.array([1.0, 2.0]),
        ...     names=("Intercept", "x"),
        ...     method="boot",
        ...     n_resamples=100,
        ...     context="params",
        ... )
        >>> state.method
        'boot'
    """
    if isinstance(names, list):
        names = tuple(names)

    return ResamplesState(
        samples=samples,
        observed=observed,
        names=names,
        method=method,
        n_resamples=n_resamples,
        context=context,
    )


def build_resamples_dataframe(rs: ResamplesState) -> pl.DataFrame:
    """Build a long-format DataFrame of raw resampled values.

    Returns one row per (resample, term) combination with the raw
    resampled value — coefficient estimates for bootstrap, null
    t-statistics for permutation.

    Columns: ``resample`` (int), ``term`` (str), ``value`` (float).

    Args:
        rs: Frozen ResamplesState from bootstrap or permutation inference.

    Returns:
        Polars DataFrame with ``n_resamples × k`` rows, where *k* is the
        number of terms/effects.

    Examples:
        >>> df = build_resamples_dataframe(rs)
        >>> df.columns
        ['resample', 'term', 'value']
        >>> df.shape
        (1000, 3)  # 100 resamples × 10 terms
    """
    import polars as pl

    samples = np.asarray(rs.samples)
    n_resamples, k = samples.shape
    names = list(rs.names)

    # Repeat resample indices for each term, repeat term names for each resample
    resample_idx = np.repeat(np.arange(n_resamples), k)
    term_names = names * n_resamples
    values = samples.ravel()

    return pl.DataFrame(
        {
            Col.RESAMPLE: resample_idx,
            Col.TERM: term_names,
            Col.VALUE: values.tolist(),
        },
        schema=ResamplesRawSchema,
    )


def extract_mee_names(mee: MeeState) -> tuple[str, ...]:
    """Extract human-readable names from a MeeState.

    Args:
        mee: The MeeState to extract names from.

    Returns:
        Tuple of effect names for each estimate.
    """
    grid = mee.grid
    focal = mee.focal_var

    if mee.type == "contrasts" and "contrast" in grid.columns:
        return tuple(grid["contrast"].to_list())

    if focal in grid.columns:
        return tuple(str(v) for v in grid[focal].to_list())

    # Fallback: numbered estimates
    return tuple(f"estimate_{i}" for i in range(len(mee.estimate)))


def build_params_resamples(
    inference: InferenceState | None,
    fit_coef: np.ndarray,
    x_names: tuple[str, ...],
    how: str,
) -> ResamplesState | None:
    """Build ResamplesState from params inference if samples are available.

    Args:
        inference: The InferenceState from params inference, or None.
        fit_coef: Coefficient estimates from the FitState.
        x_names: Design matrix column names from the DataBundle.
        how: Inference method used (``"boot"``, ``"perm"``, etc.).

    Returns:
        ResamplesState if boot/perm samples were saved, else None.
    """
    if inference is None:
        return None

    if how == "boot" and inference.boot_samples is not None:
        return build_resamples_state(
            samples=inference.boot_samples,
            observed=fit_coef,
            names=x_names,
            method="boot",
            n_resamples=inference.n_resamples,
            context="params",
        )

    if how == "perm" and inference.perm_samples is not None:
        return build_resamples_state(
            samples=inference.perm_samples,
            observed=inference.statistic,
            names=x_names,
            method="perm",
            n_resamples=inference.n_resamples,
            context="params",
        )

    return None


def build_mee_resamples(
    mee: MeeState | None,
    samples: np.ndarray | None,
    how: str,
) -> ResamplesState | None:
    """Build ResamplesState from MEE inference if samples are available.

    Args:
        mee: The MeeState from explore, or None.
        samples: Raw resample array from dispatch_mee_inference, or None.
        how: Inference method used (``"boot"``, ``"perm"``, etc.).

    Returns:
        ResamplesState if boot/perm samples were saved, else None.
    """
    if samples is None or mee is None:
        return None

    names = extract_mee_names(mee)

    method = "boot" if how == "boot" else "perm"
    observed = mee.estimate if how == "boot" else mee.statistic

    return build_resamples_state(
        samples=samples,
        observed=observed,
        names=names,
        method=method,
        n_resamples=samples.shape[0],
        context="effects",
    )
