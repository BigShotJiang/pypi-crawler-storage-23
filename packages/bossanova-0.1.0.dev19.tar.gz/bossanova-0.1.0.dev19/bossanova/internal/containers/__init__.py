"""Internal state containers for model computation.

Provides frozen attrs classes for model configuration and state:
- ModelSpec: Formula, family, link, method
- DataBundle: X, y, Z matrices with metadata
- REMetadata: Random effects grouping metadata
- FitState: Fitting results (coefficients, vcov, residuals)
- InferenceState: SE, CI, p-values for parameters
- MeeState: Marginal effects / EMM results
- JointTestState: Joint hypothesis test results (ANOVA / Type II/III)
- PredictionState: Prediction results with optional intervals
- CVState: Cross-validation results
- SimulationInferenceState: Simulation summary statistics
- SimulationSpec: Data generation parameters
- VaryingSpec: Random effect grouping specification
- Distribution: Base distribution type for simulation
- VaryingState: Random effects (BLUPs) for mixed models
- VaryingSpreadState: Variance components (σ², τ², ICC) for mixed models

These are internal implementation details - users interact with
Polars DataFrames via model properties (.params, .predictions, etc.).
See bossanova.internal.containers.schemas for output schemas.
"""

# Structs (pure frozen data classes)
from bossanova.internal.containers.structs import (
    FAMILIES,
    FAMILY_DEFAULT_LINKS,
    LINKS,
    METHODS,
    CVState,
    Condition,
    DataBundle,
    Distribution,
    ExploreFormula,
    ExploreFormulaError,
    FitState,
    FormulaSpec,
    InferenceState,
    JointTestState,
    MeeState,
    ModelSpec,
    PredictionState,
    ProfileState,
    REMetadata,
    RankInfo,
    ResamplesState,
    SimulationInferenceState,
    SimulationSpec,
    VaryingSpec,
    VaryingSpreadState,
    VaryingState,
)

# Builders (smart constructors)
from bossanova.internal.containers.builders import (
    append_inference_columns,
    build_cv_state,
    build_effects_dataframe,
    build_fit_state,
    build_inference_state,
    build_joint_test_dataframe,
    build_joint_test_state,
    build_mee_state,
    build_model_spec,
    build_model_spec_from_formula,
    build_params_dataframe,
    build_prediction_state,
    build_predictions_dataframe,
    build_mee_resamples,
    build_params_resamples,
    build_resamples_dataframe,
    build_resamples_state,
    extract_mee_names,
    build_simulation_inference_state,
    build_simulation_spec,
    build_simulation_spec_from_formula,
    build_simulations_dataframe,
    build_varying_corr_dataframe,
    build_varying_offsets_dataframe,
    build_varying_params_dataframe,
    build_varying_spec,
    build_varying_spread_dataframe,
    build_varying_spread_state,
    build_varying_state,
    get_varying_random_terms,
)

__all__ = [
    "FAMILIES",
    "FAMILY_DEFAULT_LINKS",
    "LINKS",
    "METHODS",
    "CVState",
    "Condition",
    "DataBundle",
    "Distribution",
    "ExploreFormula",
    "ExploreFormulaError",
    "FitState",
    "FormulaSpec",
    "InferenceState",
    "JointTestState",
    "MeeState",
    "ModelSpec",
    "PredictionState",
    "ProfileState",
    "REMetadata",
    "RankInfo",
    "ResamplesState",
    "SimulationInferenceState",
    "SimulationSpec",
    "VaryingSpec",
    "VaryingSpreadState",
    "VaryingState",
    "append_inference_columns",
    "build_cv_state",
    "build_effects_dataframe",
    "build_fit_state",
    "build_inference_state",
    "build_joint_test_dataframe",
    "build_joint_test_state",
    "build_mee_resamples",
    "build_mee_state",
    "build_model_spec",
    "build_model_spec_from_formula",
    "build_params_dataframe",
    "build_params_resamples",
    "build_prediction_state",
    "build_predictions_dataframe",
    "build_resamples_dataframe",
    "build_resamples_state",
    "build_simulation_inference_state",
    "build_simulation_spec",
    "build_simulation_spec_from_formula",
    "build_simulations_dataframe",
    "build_varying_corr_dataframe",
    "build_varying_offsets_dataframe",
    "build_varying_params_dataframe",
    "build_varying_spec",
    "build_varying_spread_dataframe",
    "build_varying_spread_state",
    "build_varying_state",
    "extract_mee_names",
    "get_varying_random_terms",
]
