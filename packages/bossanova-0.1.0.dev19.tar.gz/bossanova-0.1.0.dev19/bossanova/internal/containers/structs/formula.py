"""Formula specification container for learned encoding state."""

from __future__ import annotations

from typing import TYPE_CHECKING

from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    to_factor_dict,
    to_frozen_dict,
    to_tuple,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray

__all__ = [
    "FormulaSpec",
]


@frozen
class FormulaSpec:
    """Learned formula encoding — everything needed to replay on new data.

    This container captures the full state of formula parsing and evaluation:
    - Parsed AST terms from the formula string
    - Categorical factor levels and contrast matrices learned from training data
    - Stateful transform parameters (mean, std, etc.) learned from training data

    Lifecycle:
        1. Created by parse_formula() with parsing results + detected categoricals
        2. Updated by build_design_matrices() with learned contrasts/transforms
        3. Consumed by evaluate_newdata() to apply same encoding to new data

    Attributes:
        formula: Original formula string.
        response_var: LHS variable name, or None for RHS-only formulas.
        response_transform: Transform chain applied to response, innermost first.
            E.g. ("rank", "zscore") means zscore(rank(y)). None if no transform.
        has_intercept: Whether the intercept is included.
        rhs_terms: Parsed AST nodes for fixed-effect RHS terms.
        re_terms: Random effect AST nodes (Binary with PIPE operator).
        factors: Factor name to ordered level list mapping.
        contrast_matrices: Factor name to contrast matrix mapping.
        contrast_types: Factor name to contrast type string mapping.
        transform_state: Transform key to state dict mapping.
        transforms: Transform key to fitted StatefulTransform instance mapping.
        custom_contrasts: User-provided contrast matrices.
        uncorr_metadata: Metadata from || expansion.
        nested_metadata: Metadata from / expansion.
    """

    # --- Parsing results (from formula string) ---
    formula: str = field(validator=validators.instance_of(str))
    response_var: str | None = field(default=None)
    response_transform: tuple[str, ...] | None = field(default=None)
    has_intercept: bool = field(default=True)
    rhs_terms: tuple = field(factory=tuple, converter=to_tuple)
    re_terms: tuple = field(factory=tuple, converter=to_tuple)

    # --- Categorical encoding (learned from training data) ---
    factors: dict[str, tuple[str, ...]] = field(factory=dict, converter=to_factor_dict)
    contrast_matrices: dict[str, NDArray] = field(
        factory=dict, converter=to_frozen_dict
    )
    contrast_types: dict[str, str] = field(factory=dict, converter=to_frozen_dict)

    # --- Transform state (learned from training data) ---
    transform_state: dict[str, dict] = field(factory=dict, converter=to_frozen_dict)
    transforms: dict[str, object] = field(factory=dict, converter=to_frozen_dict)

    # --- User-provided configuration ---
    custom_contrasts: dict[str, NDArray] = field(factory=dict, converter=to_frozen_dict)

    # --- Pre-expansion metadata ---
    uncorr_metadata: dict = field(factory=dict, converter=to_frozen_dict)
    nested_metadata: dict = field(factory=dict, converter=to_frozen_dict)

    @property
    def has_random_effects(self) -> bool:
        """Whether formula contains random effect terms."""
        return len(self.re_terms) > 0
