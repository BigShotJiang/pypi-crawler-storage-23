"""Configuration specifications for model and simulation."""

from typing import Any, Protocol, runtime_checkable

from attrs import Factory, field, frozen, validators

from bossanova.internal.containers.validators import (
    to_tuple,
    validate_correlations,
    validate_sigma,
    validate_slope_sds,
)

__all__ = [
    "FAMILIES",
    "FAMILY_DEFAULT_LINKS",
    "LINKS",
    "METHODS",
    "Distribution",
    "ModelSpec",
    "SimulationSpec",
    "VaryingSpec",
]

# =============================================================================
# Model Constants
# =============================================================================

FAMILIES: tuple[str, ...] = ("gaussian", "binomial", "poisson", "gamma", "tdist")
"""Supported distribution families."""

LINKS: tuple[str, ...] = ("identity", "log", "logit", "probit", "inverse", "cloglog")
"""Supported link functions."""

METHODS: tuple[str, ...] = ("ols", "ml", "reml")
"""Supported estimation methods."""

FAMILY_DEFAULT_LINKS: dict[str, str] = {
    "gaussian": "identity",
    "binomial": "logit",
    "poisson": "log",
    "gamma": "inverse",
    "tdist": "identity",
}
"""Default link functions per family."""


# =============================================================================
# ModelSpec
# =============================================================================


@frozen
class ModelSpec:
    """Immutable model configuration.

    Stores all model settings parsed from the formula and user-provided
    options. This is the core specification that drives fitting, inference,
    and prediction across all model types.

    Attributes:
        formula: The model formula string (e.g., "y ~ x + treatment").
        family: Distribution family for the response variable.
        link: Link function connecting linear predictor to response.
        has_random_effects: Whether the model includes random effects.
        method: Estimation method ("ols", "ml", or "reml").
        response_var: The response variable name parsed from formula.
        fixed_terms: Tuple of fixed effect term names.
        random_terms: Tuple of random effect term specifications.

    Examples:
        >>> spec = ModelSpec(
        ...     formula="y ~ x",
        ...     response_var="y",
        ...     fixed_terms=("Intercept", "x"),
        ... )
        >>> spec.family
        'gaussian'
    """

    # Required fields
    formula: str = field(validator=validators.instance_of(str))
    response_var: str = field(validator=validators.instance_of(str))
    fixed_terms: tuple[str, ...] = field(converter=to_tuple)

    # Optional fields with defaults and validation
    family: str = field(default="gaussian", validator=validators.in_(FAMILIES))
    link: str = field(
        default=Factory(
            lambda self: FAMILY_DEFAULT_LINKS.get(self.family, "identity"),
            takes_self=True,
        ),
        validator=validators.in_(LINKS),
    )
    has_random_effects: bool = field(
        default=False, validator=validators.instance_of(bool)
    )
    method: str = field(default="ols", validator=validators.in_(METHODS))
    random_terms: tuple[str, ...] = field(
        factory=tuple,
        converter=to_tuple,
    )


# =============================================================================
# Distribution Protocol
# =============================================================================


@runtime_checkable
class Distribution(Protocol):
    """Protocol for distribution objects that can generate random samples.

    Any class implementing this protocol can be used to specify variable
    distributions in SimulationSpec. The protocol requires a single method
    that generates samples given a sample size and random number generator.

    Examples:
        >>> class Normal:
        ...     def __init__(self, mean: float = 0.0, sd: float = 1.0):
        ...         self.mean = mean
        ...         self.sd = sd
        ...     def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        ...         return rng.normal(self.mean, self.sd, size=n)
        ...
        >>> dist = Normal(0, 1)
        >>> isinstance(dist, Distribution)
        True
    """

    def sample(self, n: int, rng: Any) -> Any:
        """Generate n random samples.

        Args:
            n: Number of samples to generate.
            rng: Random number generator (numpy Generator or RNG wrapper).

        Returns:
            Array of n samples from this distribution.
        """
        ...


# =============================================================================
# VaryingSpec
# =============================================================================


@frozen
class VaryingSpec:
    """Specification for random effect grouping in simulation.

    Defines how to generate random effect structure for a grouping variable.
    Supports random intercepts, random slopes, and correlations between them.

    Attributes:
        n: Number of groups (e.g., 50 subjects). Must be > 0.
        sd: Standard deviation for random intercept. Defaults to 1.0.
        slope_sds: Dictionary mapping term names to their random slope SDs.
        correlations: Dictionary mapping pairs of terms to their correlations.
        n_per: Number of units per group for nested effects.

    Examples:
        >>> spec = VaryingSpec(n=50, sd=0.3)
        >>> spec = VaryingSpec(
        ...     n=50,
        ...     sd=0.3,
        ...     slope_sds={"time": 0.1},
        ...     correlations={("Intercept", "time"): 0.2},
        ... )
    """

    n: int = field(validator=validators.gt(0))
    sd: float = field(default=1.0, validator=validators.ge(0.0))
    slope_sds: dict[str, float] = field(factory=dict, validator=validate_slope_sds)
    correlations: dict[tuple[str, str], float] = field(
        factory=dict, validator=validate_correlations
    )
    n_per: int | None = field(default=None)

    @n_per.validator
    def _validate_n_per(self, attribute: Any, value: int | None) -> None:
        """Validate n_per is positive if provided."""
        if value is not None and value <= 0:
            msg = f"n_per must be > 0, got {value}"
            raise ValueError(msg)


# =============================================================================
# SimulationSpec
# =============================================================================


@frozen
class SimulationSpec:
    """Specification for data generation in simulation-first workflows.

    Defines all parameters needed to generate a synthetic dataset from a
    model formula: sample size, variable distributions, true coefficients,
    residual variance, and random effect structure.

    Attributes:
        n: Total number of observations to generate. Must be > 0.
        distributions: Dictionary mapping variable names to Distribution objects.
        coef: Dictionary mapping coefficient names to their true values.
        sigma: Residual standard deviation for Gaussian models. Defaults to 1.0.
        re_spec: Dictionary mapping grouping variable names to VaryingSpec objects.
        seed: Random seed for reproducibility.

    Examples:
        >>> spec = SimulationSpec(
        ...     n=100,
        ...     coef={"Intercept": 0, "x": 0.5},
        ...     sigma=1.0,
        ...     seed=42,
        ... )
    """

    n: int = field(validator=validators.gt(0))
    distributions: dict[str, Distribution] = field(factory=dict)
    coef: dict[str, float] = field(factory=dict)
    sigma: float = field(default=1.0, validator=validate_sigma)
    re_spec: dict[str, VaryingSpec] = field(factory=dict)
    seed: int | None = field(default=None)
