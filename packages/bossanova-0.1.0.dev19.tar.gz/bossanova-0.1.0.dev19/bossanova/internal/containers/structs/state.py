"""Computation state containers for fitting and inference.

Pure frozen data classes for fitting results (FitState) and inference
results (InferenceState, MeeState, JointTestState, PredictionState,
CVState, SimulationInferenceState, VaryingState, VaryingSpreadState).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    is_ndarray,
    is_optional_ndarray,
    to_tuple,
)

if TYPE_CHECKING:
    import polars as pl
    from numpy.typing import NDArray


__all__ = [
    "CVState",
    "FitState",
    "InferenceState",
    "JointTestState",
    "MeeState",
    "PredictionState",
    "ProfileState",
    "ResamplesState",
    "SimulationInferenceState",
    "VaryingSpreadState",
    "VaryingState",
]


# =============================================================================
# FitState
# =============================================================================


@frozen
class FitState:
    """Immutable fitting result.

    Contains all state produced by fitting a model, including coefficients,
    variance-covariance matrix, fitted values, residuals, and model-specific
    parameters.

    Attributes:
        coef: Coefficient estimates (1D array of length p).
        vcov: Variance-covariance matrix (p x p array).
        fitted: Fitted values (1D array of length n).
        residuals: Residuals (1D array of length n).
        leverage: Hat matrix diagonal / leverage values (1D array of length n).
        df_resid: Residual degrees of freedom.
        loglik: Log-likelihood at convergence.
        converged: Whether the optimization converged.
        n_iter: Number of iterations (1 for closed-form solutions).
        sigma: Residual standard deviation (OLS models only).
        dispersion: Dispersion parameter (GLM models only).
        null_deviance: Null model deviance (GLM models only).
        deviance: Residual deviance, sum of unit deviances (GLM models only).
        theta: Random effect variance parameters (mixed models only).
        u: Spherical random effects (mixed models only).
        irls_weights: IRLS weights from GLM fit (GLM sandwich estimator).
        XtWX_inv: Inverse of X'WX from GLM fit (GLM sandwich estimator).

    Examples:
        >>> import numpy as np
        >>> from bossanova.internal.containers.structs.state import FitState
        >>> state = FitState(
        ...     coef=np.array([1.0, 2.0]),
        ...     vcov=np.eye(2),
        ...     fitted=np.array([1.0, 2.0, 3.0]),
        ...     residuals=np.array([0.1, -0.1, 0.0]),
        ...     leverage=np.array([0.3, 0.3, 0.4]),
        ...     df_resid=1.0,
        ...     loglik=-10.0,
        ... )
    """

    # Required arrays
    coef: NDArray[np.floating] = field(validator=is_ndarray)
    vcov: NDArray[np.floating] = field(validator=is_ndarray)
    fitted: NDArray[np.floating] = field(validator=is_ndarray)
    residuals: NDArray[np.floating] = field(validator=is_ndarray)
    leverage: NDArray[np.floating] = field(validator=is_ndarray)

    # Required scalars
    df_resid: float = field(validator=validators.instance_of((int, float)))
    loglik: float = field(validator=validators.instance_of((int, float)))

    # Convergence info (optional with defaults)
    converged: bool = field(default=True, validator=validators.instance_of(bool))
    n_iter: int = field(default=1, validator=validators.instance_of(int))

    # Model-specific (optional)
    sigma: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    dispersion: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    null_deviance: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    deviance: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    theta: NDArray[np.floating] | None = field(
        default=None,
        validator=is_optional_ndarray,
    )
    u: NDArray[np.floating] | None = field(
        default=None,
        validator=is_optional_ndarray,
    )

    # GLM sandwich estimator inputs (optional)
    irls_weights: NDArray[np.floating] | None = field(
        default=None,
        validator=is_optional_ndarray,
    )
    XtWX_inv: NDArray[np.floating] | None = field(
        default=None,
        validator=is_optional_ndarray,
    )


# =============================================================================
# Inference State
# =============================================================================


@frozen
class InferenceState:
    """Inference results that augment params or estimates.

    Contains standard errors, test statistics, p-values, and confidence
    intervals computed by .infer() on a fitted model.

    Attributes:
        se: Standard errors for each coefficient.
        statistic: Test statistics (t or z).
        df: Degrees of freedom (may be per-coefficient for Satterthwaite).
        p_value: Two-sided p-values.
        ci_lower: Lower confidence interval bounds.
        ci_upper: Upper confidence interval bounds.
        conf_level: Confidence level (e.g., 0.95 for 95% CI).
        method: Inference method used ("asymp", "boot", "perm", "cv").
        n_resamples: Number of bootstrap/permutation resamples (if applicable).
        boot_samples: Raw bootstrap samples for advanced diagnostics.
        perm_samples: Null distribution of test statistics from permutation tests.
        pre: Proportion Reduction in Error per predictor (CV ablation only).
        pre_sd: Standard deviation of PRE across CV folds (CV ablation only).

    Examples:
        >>> # InferenceState is created by .infer() and attached to params
        >>> m = model("y ~ x", data).fit().infer()
        >>> m.params  # DataFrame includes inference columns

        >>> # CV ablation inference adds PRE columns
        >>> m = model("y ~ x + z", data).fit().infer(how="cv")
        >>> m.params  # DataFrame includes pre, pre_sd columns
    """

    se: np.ndarray = field(validator=is_ndarray)
    statistic: np.ndarray = field(validator=is_ndarray)
    df: np.ndarray = field(validator=is_ndarray)
    p_value: np.ndarray = field(validator=is_ndarray)
    ci_lower: np.ndarray = field(validator=is_ndarray)
    ci_upper: np.ndarray = field(validator=is_ndarray)

    conf_level: float = field(default=0.95)
    method: str = field(default="asymp")
    null: float = field(default=0.0)
    alternative: str = field(default="two-sided")

    # Bootstrap-specific
    n_resamples: int | None = field(default=None)
    boot_samples: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )

    # Permutation-specific
    perm_samples: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )

    # CV-specific (PRE = Proportion Reduction in Error via ablation)
    pre: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    pre_sd: np.ndarray | None = field(default=None, validator=is_optional_ndarray)


# =============================================================================
# MEE State (Marginal Estimated Effects / EMM)
# =============================================================================


@frozen
class MeeState:
    """Marginal effects / estimated marginal means results.

    Created by .explore() and optionally augmented with inference by .infer().
    Contains the reference grid, point estimates, and (optionally) inference.

    Attributes:
        grid: Polars DataFrame with the evaluation grid (factor levels, covariate values).
        estimate: Point estimates for each grid row.
        explore_formula: The explore formula string that generated this result.
        focal_var: The primary variable being explored.
        type: Type of marginal effect ("means", "slopes", "contrasts").
        how: Averaging method: ``"mem"`` (Marginal Estimated Mean, balanced
            reference grid, emmeans-style) or ``"ame"`` (Average Marginal
            Effect, g-computation over observed data).
        effect_scale: Scale of estimates: ``"link"`` (linear predictor) or
            ``"response"`` (inverse-link / data scale).
        L_matrix: Design matrix for delta method inference. Shape (n_estimates, n_coef).
            For EMMs, this is X_ref; for slopes, a coefficient selector row.
        contrast_method: Original contrast type for multiplicity adjustment
            ("pairwise", "sequential", "poly", "treatment", "sum",
            "helmert", or None).
        n_contrast_levels: Number of EMM levels before contrasting (family size for Tukey).
        link: Link function name for response-scale back-transformation (set when
            effect_scale="response" and how="mem").
        L_matrix_link: Link-scale L_matrix for CI back-transformation (set when
            effect_scale="response" and how="mem").
        inference_method: Inference method used (``"asymp"``, ``"boot"``,
            ``"perm"``, or ``None``). Controls which columns appear in
            the ``.effects`` DataFrame.
        se: Standard errors (added by .infer()).
        df: Degrees of freedom (added by .infer()).
        statistic: Test statistics (added by .infer()).
        p_value: P-values (added by .infer()).
        ci_lower: Lower CI bounds (added by .infer()).
        ci_upper: Upper CI bounds (added by .infer()).
        conf_level: Confidence level (added by .infer()).

    Examples:
        >>> m = model("y ~ treatment", data).fit()
        >>> m.explore("treatment")  # Creates MeeState without inference
        >>> m.effects  # DataFrame with grid columns + estimate
        >>> m.infer()  # Augments MeeState with inference
        >>> m.effects  # Now includes se, ci_lower, ci_upper, etc.
    """

    # Required fields
    grid: "pl.DataFrame" = field(repr=False)
    estimate: np.ndarray = field(validator=is_ndarray)

    explore_formula: str = field(validator=validators.instance_of(str))
    focal_var: str = field(validator=validators.instance_of(str))
    type: str = field(validator=validators.in_(("means", "slopes", "contrasts")))
    how: str = field(default="mem", validator=validators.in_(("mem", "ame")))
    effect_scale: str = field(
        default="link", validator=validators.in_(("link", "response"))
    )

    # Design matrix for delta method inference (optional)
    # Shape: (n_estimates, n_coef). For EMMs, this is X_ref; for slopes, a selector row.
    L_matrix: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )

    # Contrast multiplicity adjustment (set by apply_contrasts)
    contrast_method: str | None = field(
        default=None,
        validator=validators.optional(
            validators.in_(
                (
                    "pairwise",
                    "sequential",
                    "poly",
                    "treatment",
                    "sum",
                    "helmert",
                    "custom",
                )
            )
        ),
    )
    n_contrast_levels: int | None = field(default=None)

    # Response-scale back-transformation (set when effect_scale="response" for GLM/GLMER)
    link: str | None = field(default=None)
    L_matrix_link: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )

    # Inference (optional, added by .infer())
    inference_method: str | None = field(
        default=None,
        validator=validators.optional(validators.in_(("asymp", "boot", "perm"))),
    )
    se: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    df: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    statistic: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    p_value: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    ci_lower: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    ci_upper: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    conf_level: float | None = field(default=None)

    @property
    def has_inference(self) -> bool:
        """Check if inference has been computed.

        Returns:
            True if .infer() has been called to add inference fields.
        """
        return self.se is not None


# =============================================================================
# Joint Test State (ANOVA / Type II/III Tests)
# =============================================================================


@frozen
class JointTestState:
    """Joint hypothesis test results for model terms.

    Created by .infer("joint") and contains per-term test statistics for omnibus tests
    of whether each term has any effect (H0: all coefficients for term = 0).

    This is equivalent to Type II/III ANOVA for linear models, or Wald tests
    for GLMs. For mixed models, uses Satterthwaite or Kenward-Roger df.

    Attributes:
        terms: Tuple of term names being tested.
        df1: Numerator degrees of freedom per term (number of constraints).
        df2: Denominator degrees of freedom per term (residual df, or None for chi2).
        statistic: Test statistic values (F for LM/LMM, chi2 for GLM/GLMM).
        p_value: P-values for each term.
        test_type: Type of test ("F" or "chi2").
        ss_type: Sum of squares type ("II" or "III") for linear models.

    Examples:
        Type III ANOVA for linear model::

            >>> m = model("y ~ a + b + a:b", data).fit()
            >>> m.infer("joint")
            >>> m.effects  # DataFrame with term, df1, df2, statistic, p_value

        Wald tests for GLM::

            >>> m = model("y ~ a + b", data, family="binomial").fit()
            >>> m.infer("joint")  # Uses chi2 tests

    Note:
        Joint tests answer "Does this term have ANY effect?" rather than
        testing individual coefficients. For a factor with 3 levels, the
        joint test has df1=2 (testing 2 contrasts simultaneously).
    """

    # Required fields
    terms: tuple[str, ...] = field(
        converter=to_tuple,
        validator=validators.deep_iterable(
            member_validator=validators.instance_of(str)
        ),
    )
    df1: np.ndarray = field(validator=is_ndarray)  # Numerator df per term
    statistic: np.ndarray = field(validator=is_ndarray)  # F or chi2 values
    p_value: np.ndarray = field(validator=is_ndarray)

    # Test configuration
    test_type: str = field(default="F", validator=validators.in_(("F", "chi2")))
    ss_type: str = field(default="III", validator=validators.in_(("II", "III")))

    # Optional: denominator df (None for asymptotic chi2 tests)
    df2: np.ndarray | None = field(default=None, validator=is_optional_ndarray)


# =============================================================================
# Prediction State
# =============================================================================


@frozen
class PredictionState:
    """Prediction results with optional intervals.

    Created by .predict() and optionally augmented with inference by .infer().
    Contains fitted values and (optionally) prediction/confidence intervals.

    Attributes:
        fitted: Predicted values on response scale.
        link: Predicted values on link scale (for GLM/GLMM).
        X_pred: Design matrix used for these predictions (training X or
            newdata X). Used by ``.infer()`` for delta-method SEs.
        se: Standard errors of predictions (added by .infer()).
        ci_lower: Lower interval bounds (added by .infer()).
        ci_upper: Upper interval bounds (added by .infer()).
        interval_type: Type of interval ("confidence" or "prediction").
        conf_level: Confidence level for intervals.

    Examples:
        >>> m = model("y ~ x", data).fit()
        >>> m.predict(newdata)  # Creates PredictionState
        >>> m.predictions  # DataFrame with .fitted column
        >>> m.infer()  # Augments with intervals
        >>> m.predictions  # Now includes .ci_lower, .ci_upper
    """

    fitted: np.ndarray = field(validator=is_ndarray)
    link: np.ndarray | None = field(default=None, validator=is_optional_ndarray)

    # Design matrix used for these predictions (training X or newdata X).
    # Carried through so .infer() can compute SEs via the delta method.
    X_pred: np.ndarray | None = field(
        default=None, validator=is_optional_ndarray, repr=False
    )

    # Inference (optional)
    se: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    ci_lower: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    ci_upper: np.ndarray | None = field(default=None, validator=is_optional_ndarray)

    interval_type: str | None = field(default=None)  # "confidence" or "prediction"
    conf_level: float | None = field(default=None)

    # CV-specific (fold metadata)
    cv_fitted: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    cv_residual: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    cv_fold: np.ndarray | None = field(default=None, validator=is_optional_ndarray)

    @property
    def has_inference(self) -> bool:
        """Check if inference has been computed.

        Returns:
            True if .infer() has been called to add interval fields.
        """
        return self.se is not None

    @property
    def has_cv(self) -> bool:
        """Check if CV inference has been computed.

        Returns:
            True if .infer(how='cv') has been called to add CV fields.
        """
        return self.cv_fitted is not None


# =============================================================================
# CV State (Cross-Validation Results)
# =============================================================================


@frozen
class CVState:
    """Cross-validation results for model evaluation.

    Contains out-of-sample prediction metrics computed via k-fold
    cross-validation. Created by .infer(how='cv').

    Attributes:
        k: Number of folds used in cross-validation.
        rmse: Root mean squared error (out-of-sample).
        mae: Mean absolute error (out-of-sample).
        r_squared: R-squared (1 - SS_res/SS_tot, computed on held-out data).
        deviance: Mean deviance across folds (for GLM models).
        accuracy: Classification accuracy (for binomial family only).
        fold_metrics: Per-fold metrics as dict of arrays.
        oos_predictions: Out-of-sample predictions aligned with original data.
        oos_residuals: Out-of-sample residuals aligned with original data.

    Examples:
        >>> m = model("y ~ x", data).fit().predict().infer(how="cv", k=10)
        >>> m.cv_metrics.rmse
        0.523
        >>> m.cv_metrics.r_squared
        0.891
    """

    k: int = field(validator=[validators.instance_of(int), validators.gt(0)])
    rmse: float = field(
        validator=[validators.instance_of((int, float)), validators.ge(0)]
    )
    mae: float = field(
        validator=[validators.instance_of((int, float)), validators.ge(0)]
    )
    # OOS R² can be negative when model is worse than the mean, so no lower bound
    r_squared: float = field(validator=validators.instance_of((int, float)))

    # GLM-specific metrics (optional)
    deviance: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0)]
        ),
    )
    accuracy: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )

    # Binomial SDT metrics (optional)
    sensitivity: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )
    specificity: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )
    f1: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )
    auc: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )

    # Per-fold details
    fold_metrics: dict[str, np.ndarray] = field(factory=dict, repr=False)

    # Full out-of-sample predictions/residuals
    oos_predictions: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    oos_residuals: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )

    # Fold assignments (which fold each observation belongs to)
    fold_assignments: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )


# =============================================================================
# Simulation Inference State
# =============================================================================


@frozen
class SimulationInferenceState:
    """Simulation inference results for post-fit or power analysis simulations.

    Contains summary statistics across simulations from .simulate(nsim=) or
    power/coverage metrics from simulation-based power analysis.

    For post-fit simulations (nsim=):
        - Per-observation summaries across simulation replicates
        - Mean, SD, and quantiles of simulated values

    For power analysis (simulation-first workflow):
        - Power: proportion of simulations with significant effect
        - Coverage: proportion of CIs containing true parameter value
        - Bias: average difference between estimated and true coefficients
        - RMSE: root mean squared error of estimates

    Attributes:
        sim_type: Type of simulation ("post_fit" or "power_analysis").
        n_sims: Number of simulations.
        sim_mean: Mean of simulated values per observation (post_fit only).
        sim_sd: SD of simulated values per observation (post_fit only).
        sim_quantiles: Dict mapping quantile names to arrays (e.g., "q025", "q975").
        power: Dict mapping term names to power (proportion p < alpha).
        coverage: Dict mapping term names to coverage (proportion CI contains true).
        bias: Dict mapping term names to bias (mean estimate - true value).
        rmse: Dict mapping term names to RMSE.
        alpha: Significance level used for power calculation.
        true_coef: True coefficients used for coverage/bias (power analysis only).

    Examples:
        Post-fit simulation summary::

            >>> m = model("y ~ x", data).fit().simulate(nsim=100).infer()
            >>> m.sim_inference.sim_mean  # Mean across simulations per obs
            >>> m.sim_inference.sim_sd    # SD across simulations per obs

        Power analysis::

            >>> # Check power to detect effect of x=0.3
            >>> m = model("y ~ x").simulate(n=100, coef={"x": 0.3}).fit().infer()
            >>> m.sim_inference.power["x"]  # Proportion of sims where p < 0.05
    """

    sim_type: str = field(validator=validators.in_(("post_fit", "power_analysis")))
    n_sims: int = field(validator=validators.instance_of(int))

    # Post-fit simulation summaries (per observation)
    sim_mean: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    sim_sd: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    sim_quantiles: dict[str, np.ndarray] = field(
        factory=dict, validator=validators.instance_of(dict)
    )

    # Power analysis metrics (per coefficient)
    power: dict[str, float] = field(
        factory=dict, validator=validators.instance_of(dict)
    )
    coverage: dict[str, float] = field(
        factory=dict, validator=validators.instance_of(dict)
    )
    bias: dict[str, float] = field(factory=dict, validator=validators.instance_of(dict))
    rmse: dict[str, float] = field(factory=dict, validator=validators.instance_of(dict))

    # Metadata
    alpha: float = field(default=0.05, validator=validators.instance_of((int, float)))
    true_coef: dict[str, float] = field(
        factory=dict, validator=validators.instance_of(dict)
    )


# =============================================================================
# Varying State (Random Effects / BLUPs)
# =============================================================================


@frozen
class VaryingState:
    """Random effects (BLUPs) for mixed models.

    Created by .fit() for mixed models. Contains group-level deviations from
    population parameters (BLUPs). Optionally augmented with prediction intervals
    by .infer().

    Attributes:
        grid: Polars DataFrame with grouping columns (group, level).
        effects: Dict mapping effect names to arrays of BLUPs.
            For (1 + x|subject): {"Intercept": array, "x": array}
        grouping_var: Name of the grouping variable (e.g., "subject").
        n_groups: Number of groups.
        pi_lower: Lower prediction interval bounds (added by .infer()).
        pi_upper: Upper prediction interval bounds (added by .infer()).
        conf_level: Confidence level for prediction intervals.

    Examples:
        >>> m = model("y ~ x + (x|subject)", data).fit()
        >>> m.varying_offsets  # DataFrame: group, level, Intercept, x
        >>> m.infer()
        >>> m.varying_offsets  # Now includes pi_lower_*, pi_upper_* columns

    Note:
        BLUPs are Best Linear Unbiased Predictors - they are shrinkage
        estimates of group-specific deviations, not fixed parameters.
        Use prediction intervals, not confidence intervals.
    """

    # Required fields
    grid: "pl.DataFrame" = field(repr=False)
    effects: dict[str, np.ndarray] = field(validator=validators.instance_of(dict))
    grouping_var: str = field(validator=validators.instance_of(str))
    n_groups: int = field(validator=validators.instance_of(int))

    # Inference (optional, added by .infer())
    # These are dicts: effect_name -> array of interval bounds
    pi_lower: dict[str, np.ndarray] | None = field(
        default=None, validator=validators.optional(validators.instance_of(dict))
    )
    pi_upper: dict[str, np.ndarray] | None = field(
        default=None, validator=validators.optional(validators.instance_of(dict))
    )
    conf_level: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )

    @property
    def has_inference(self) -> bool:
        """Check if prediction intervals have been computed.

        Returns:
            True if .infer() has been called.
        """
        return self.pi_lower is not None


# =============================================================================
# Varying Spread State (Variance Components)
# =============================================================================


@frozen
class VaryingSpreadState:
    """Variance components for mixed models.

    Created by .fit() for mixed models. Contains variance/covariance estimates
    for random effects and derived quantities like ICC. Optionally augmented
    with profile likelihood CIs by .infer().

    Attributes:
        components: Polars DataFrame with variance component estimates.
            Columns: component, estimate, [ci_lower, ci_upper after .infer()]
            Rows include:
            - "sigma2" (residual variance)
            - "tau2_<effect>" (variance for each RE, e.g., "tau2_Intercept")
            - "rho_<e1>_<e2>" (correlations between REs)
            - "icc" (intraclass correlation, if applicable)
        sigma2: Residual variance (sigma squared).
        tau2: Dict mapping effect names to variance estimates.
        rho: Dict mapping effect pairs to correlations.
        icc: Intraclass correlation coefficient (None if not applicable).
        ci_lower: Dict of lower CI bounds (added by .infer()).
        ci_upper: Dict of upper CI bounds (added by .infer()).
        conf_level: Confidence level for CIs.
        ci_method: CI method ("profile" or "wald").

    Examples:
        >>> m = model("y ~ x + (1|subject)", data).fit()
        >>> m.varying_spread
        # DataFrame: component, estimate
        # Rows: sigma2, tau2_Intercept, icc
        >>> m.infer()
        >>> m.varying_spread  # Now includes ci_lower, ci_upper

    Note:
        Profile likelihood CIs are preferred for variance components as
        they respect parameter bounds (variances >= 0) and handle
        boundary cases (variance near 0) correctly.
    """

    # Required fields
    components: "pl.DataFrame" = field(repr=False)
    sigma2: float = field(validator=validators.instance_of((int, float)))
    tau2: dict[str, float] = field(validator=validators.instance_of(dict))

    # Optional fields
    rho: dict[str, float] = field(factory=dict, validator=validators.instance_of(dict))
    icc: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )

    # Inference (optional, added by .infer())
    ci_lower: dict[str, float] | None = field(
        default=None, validator=validators.optional(validators.instance_of(dict))
    )
    ci_upper: dict[str, float] | None = field(
        default=None, validator=validators.optional(validators.instance_of(dict))
    )
    conf_level: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    ci_method: str | None = field(
        default=None,
        validator=validators.optional(validators.in_(("profile", "wald"))),
    )

    @property
    def has_inference(self) -> bool:
        """Check if confidence intervals have been computed.

        Returns:
            True if .infer() has been called.
        """
        return self.ci_lower is not None


# =============================================================================
# Profile State (Profile Likelihood)
# =============================================================================


@frozen
class ProfileState:
    """Profile likelihood state for variance component CIs.

    Stores the full profile table, fitted splines for diagnostics/plotting,
    and extracted confidence intervals on both theta and SD scales.

    Attributes:
        table: Polars DataFrame with profile trace. Columns include:
            - param: Parameter name being profiled ("theta[0]", "sigma", etc.)
            - focal: Value of focal parameter at this step
            - zeta: Signed likelihood root
        spline_forward: Dict mapping parameter names to forward splines (param -> zeta).
        spline_reverse: Dict mapping parameter names to reverse splines (zeta -> param).
        ci_theta: Dict mapping theta parameter names to (lower, upper) CI tuples
            on the theta (relative) scale.
        ci_sd: Dict mapping variance component names to (lower, upper) CI tuples
            on the standard deviation scale.
        ci_lower_sd: Array of lower CI bounds on SD scale.
        ci_upper_sd: Array of upper CI bounds on SD scale.
        conf_level: Confidence level used for CIs.
        dev_opt: Optimal deviance from fitted model.
        threshold: Zeta threshold used for profiling (default 4).

    Examples:
        >>> from bossanova.internal.maths.inference.profile import profile_likelihood
        >>> prof = profile_likelihood(fitted_mixed_model)
        >>> prof.ci_sd
        {'group:Intercept': (15.21, 40.23), 'Residual': (22.83, 28.69)}
    """

    table: "pl.DataFrame" = field(repr=False)
    spline_forward: dict[str, Any] = field(
        repr=False, validator=validators.instance_of(dict)
    )
    spline_reverse: dict[str, Any] = field(
        repr=False, validator=validators.instance_of(dict)
    )
    ci_theta: dict[str, tuple[float, float]] = field(
        validator=validators.instance_of(dict)
    )
    ci_sd: dict[str, tuple[float, float]] = field(
        validator=validators.instance_of(dict)
    )
    ci_lower_sd: NDArray[np.floating] = field(repr=False, validator=is_ndarray)
    ci_upper_sd: NDArray[np.floating] = field(repr=False, validator=is_ndarray)
    conf_level: float = field(validator=validators.instance_of((int, float)))
    dev_opt: float = field(validator=validators.instance_of((int, float)))
    threshold: float = field(
        default=4.0, validator=validators.instance_of((int, float))
    )


# =============================================================================
# Resamples State (Unified bootstrap / permutation samples)
# =============================================================================


@frozen
class ResamplesState:
    """Unified resampling results from bootstrap or permutation inference.

    Created by ``.infer(how="boot"|"perm", save_resamples=True)`` and accessed
    via the ``.resamples`` property on the model.

    Attributes:
        samples: Resampled statistics array.
            Bootstrap: coefficient/effect estimates, shape (n_resamples, k).
            Permutation: null t-statistics, shape (n_resamples, k).
        observed: Observed statistics (point estimates or t-stats), shape (k,).
        names: Term/effect names corresponding to columns of samples.
        method: Resampling method: ``"boot"`` or ``"perm"``.
        n_resamples: Number of resamples.
        context: What was resampled: ``"params"`` or ``"effects"``.

    Examples:
        >>> m = model("y ~ x", data).fit().infer(how="boot")
        >>> m.resamples.method
        'boot'
        >>> m.resamples.samples.shape
        (1000, 2)
        >>> m.resamples.context
        'params'
    """

    samples: np.ndarray = field(validator=is_ndarray)
    observed: np.ndarray = field(validator=is_ndarray)
    names: tuple[str, ...] = field()
    method: str = field(validator=validators.in_(("boot", "perm")))
    n_resamples: int = field(validator=[validators.instance_of(int), validators.gt(0)])
    context: str = field(validator=validators.in_(("params", "effects")))
