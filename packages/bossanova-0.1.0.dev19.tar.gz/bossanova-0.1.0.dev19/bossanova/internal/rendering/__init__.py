"""LaTeX equation and markdown rendering for model output.

Call chain:
    model.equation() -> build_equation(spec) -> LaTeX string
    model_result.to_markdown() -> dataframe_to_markdown(df) -> markdown string
"""

from bossanova.internal.rendering.latex import build_equation
from bossanova.internal.rendering.markdown import (
    dataframe_to_markdown,
    equation_to_markdown,
    to_markdown,
    write_text,
)

__all__ = [
    "build_equation",
    "dataframe_to_markdown",
    "equation_to_markdown",
    "to_markdown",
    "write_text",
]
