"""Data bundle construction from formula and DataFrame.

Orchestrates formula parsing, design matrix construction, missing value
handling, weight validation, rank deficiency detection, and random effects
metadata to produce a DataBundle. Extracted from model/core.py.
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np
    import polars as pl

    from bossanova.internal.containers.structs.data import DataBundle, REMetadata
    from bossanova.internal.containers.structs.formula import FormulaSpec
    from bossanova.internal.containers.structs.specs import ModelSpec

__all__ = [
    "build_bundle_from_data",
    "filter_valid_rows",
]


def filter_valid_rows(
    data: pl.DataFrame | None, valid_mask: np.ndarray | None
) -> pl.DataFrame | None:
    """Filter a DataFrame to only valid (non-NA) rows using a boolean mask.

    Returns the data unchanged if no filtering is needed (data is None,
    mask is None, or all rows are valid).

    Args:
        data: Polars DataFrame to filter, or None.
        valid_mask: Boolean array indicating valid rows, or None.

    Returns:
        Filtered DataFrame, or None if data was None.
    """
    if data is None or valid_mask is None or valid_mask.all():
        return data

    import polars as pl

    return data.filter(pl.Series(valid_mask))


def build_bundle_from_data(
    *,
    spec: ModelSpec,
    formula: str,
    data: pl.DataFrame,
    custom_contrasts: dict[str, np.ndarray] | None,
    weights_col: str | None,
    offset_col: str | None = None,
    missing: str,
) -> tuple[DataBundle, FormulaSpec]:
    """Build a DataBundle and learned FormulaSpec from a model spec and data.

    Handles the full pipeline: formula parsing, design matrix construction,
    missing value handling, weight validation, offset extraction, rank
    deficiency detection, family-specific response validation, and random
    effects metadata.

    Args:
        spec: Model specification with parsed formula info.
        formula: Raw formula string (e.g. ``"y ~ x + (1|group)"``).
        data: Input data as a Polars DataFrame.
        custom_contrasts: User-specified contrast matrices, or None.
        weights_col: Name of the weights column in data, or None.
        offset_col: Name of the offset column in data, or None.
        missing: How to handle missing values (``"drop"`` or ``"fail"``).

    Returns:
        Tuple of (DataBundle, FormulaSpec). The FormulaSpec is needed
        for consistent newdata evaluation via ``evaluate_newdata()``.

    Raises:
        ValueError: If response variable not found, data is empty,
            insufficient observations, or family-specific validation fails.
    """
    from bossanova.internal.containers import DataBundle
    from bossanova.internal.formula import (
        build_design_matrices,
        parse_formula,
    )

    response_var = spec.response_var
    n_rows = data.height if hasattr(data, "height") else len(data)
    if n_rows == 0:
        raise ValueError("Cannot fit model: data has 0 rows")

    if response_var not in data.columns:
        raise ValueError(f"Response variable '{response_var}' not found in data")

    # Auto-encode string/categorical response for binomial family
    response_levels: tuple[str, ...] | None = None
    if spec.family == "binomial":
        import polars as pl

        response_dtype = data[response_var].dtype
        if response_dtype in (pl.String, pl.Categorical) or isinstance(
            response_dtype, pl.Enum
        ):
            data, response_levels = _encode_binary_response(data, response_var)

    # Functional formula API: parse -> build -> return learned spec
    formula_spec = parse_formula(
        formula,
        data,
        custom_contrasts=custom_contrasts or None,
    )
    design, formula_spec = build_design_matrices(formula_spec, data)

    X = design.X
    y = design.y if design.y is not None else data[response_var].to_numpy()
    X_names = tuple(design.X_labels)
    n = len(y)

    # Extract observation weights and offset
    weights_array = _extract_weights(data, weights_col, response_var)
    offset_array = _extract_offset(data, offset_col)

    # Build valid mask and filter
    y, X, weights_array, offset_array, valid_mask, n_missing = _handle_missing_values(
        y=y,
        X=X,
        X_names=X_names,
        weights_array=weights_array,
        weights_col=weights_col,
        offset_array=offset_array,
        offset_col=offset_col,
        response_var=response_var,
        missing=missing,
    )

    n_valid = len(y)
    n_params = X.shape[1]

    if n_valid == 0:
        raise ValueError(
            "Cannot fit model: 0 rows remaining after removing "
            "non-finite values (NaN/Inf)"
        )

    # Rank deficiency detection
    from bossanova.internal.fit.rank import detect_rank_deficiency

    rank_info = detect_rank_deficiency(X, X_names)
    effective_p = rank_info.rank if rank_info is not None else n_params

    if n_valid < effective_p:
        raise ValueError(
            f"Cannot fit model: insufficient observations ({n_valid}) "
            f"for {effective_p} estimable parameters. "
            f"Need at least {effective_p} rows."
        )

    # Family-specific response validation
    _validate_response(spec.family, y, spec.response_var)

    # Random effects
    Z, re_metadata = _build_random_effects(
        spec=spec,
        formula_spec=formula_spec,
        data=data,
        valid_mask=valid_mask,
        n_missing=n_missing,
        n_valid=n_valid,
        effective_p=effective_p,
    )

    bundle = DataBundle(
        X=X,
        y=y,
        X_names=X_names,
        y_name=response_var,
        valid_mask=valid_mask,
        n_total=n,
        Z=Z,
        weights=weights_array,
        offset=offset_array,
        re_metadata=re_metadata,
        factor_levels={k: list(v) for k, v in formula_spec.factors.items()},
        contrast_types=dict(formula_spec.contrast_types),
        response_levels=response_levels,
        rank_info=rank_info,
    )

    return bundle, formula_spec


def _extract_weights(
    data: pl.DataFrame,
    weights_col: str | None,
    response_var: str,
) -> np.ndarray | None:
    """Extract and validate observation weights from data.

    Args:
        data: Input DataFrame.
        weights_col: Name of the weights column, or None.
        response_var: Name of response variable (needed for inverse-variance).

    Returns:
        Weight array, or None if no weights column specified.

    Raises:
        ValueError: If weights column not found or contains negative values.
    """
    if weights_col is None:
        return None

    import numpy as np

    if weights_col not in data.columns:
        raise ValueError(f"weights column '{weights_col}' not found in data")

    from bossanova.internal.maths.weights import (
        compute_inverse_variance_weights,
        detect_weight_type,
    )

    if detect_weight_type(data, weights_col):
        # Categorical column: compute inverse-variance weights
        weight_info = compute_inverse_variance_weights(data, response_var, weights_col)
        return weight_info.weights

    # Numeric column: use raw values as weights
    weights_array = data[weights_col].to_numpy().astype(np.float64)
    if np.any(weights_array < 0):
        raise ValueError("Weights must be non-negative")
    return weights_array


def _extract_offset(
    data: pl.DataFrame,
    offset_col: str | None,
) -> np.ndarray | None:
    """Extract offset vector from data.

    Args:
        data: Input DataFrame.
        offset_col: Name of the offset column, or None.

    Returns:
        Offset array as float64, or None if no offset column specified.

    Raises:
        ValueError: If offset column not found in data.
    """
    if offset_col is None:
        return None

    import numpy as np

    if offset_col not in data.columns:
        raise ValueError(f"offset column '{offset_col}' not found in data")

    return data[offset_col].to_numpy().astype(np.float64)


def _handle_missing_values(
    *,
    y: np.ndarray,
    X: np.ndarray,
    X_names: tuple[str, ...],
    weights_array: np.ndarray | None,
    weights_col: str | None,
    offset_array: np.ndarray | None,
    offset_col: str | None,
    response_var: str,
    missing: str,
) -> tuple[
    np.ndarray, np.ndarray, np.ndarray | None, np.ndarray | None, np.ndarray, int
]:
    """Build valid mask and optionally filter out rows with non-finite values.

    Args:
        y: Response vector.
        X: Design matrix.
        X_names: Column names for X.
        weights_array: Weight array, or None.
        weights_col: Weights column name (for error messages).
        offset_array: Offset array, or None.
        offset_col: Offset column name (for error messages).
        response_var: Response variable name (for error messages).
        missing: ``"drop"`` to filter, ``"fail"`` to raise on missing.

    Returns:
        Tuple of (y, X, weights_array, offset_array, valid_mask, n_missing)
        after filtering.

    Raises:
        ValueError: If ``missing="fail"`` and non-finite values exist.
    """
    import numpy as np

    n = len(y)
    y_valid = np.isfinite(y)
    X_valid = np.all(np.isfinite(X), axis=1)
    valid_mask = y_valid & X_valid
    if weights_array is not None:
        valid_mask &= np.isfinite(weights_array)
    if offset_array is not None:
        valid_mask &= np.isfinite(offset_array)

    n_missing = int(n - np.sum(valid_mask))
    if n_missing > 0:
        if missing == "fail":
            _raise_missing_detail(
                y_valid,
                X,
                X_names,
                weights_array,
                weights_col,
                offset_array,
                offset_col,
                response_var,
                n_missing,
            )
        # missing="drop": warn and filter
        warnings.warn(
            f"Dropping {n_missing} rows with non-finite values "
            f"({np.sum(valid_mask)} rows remaining)",
            stacklevel=4,
        )
        y = y[valid_mask]
        X = X[valid_mask]
        if weights_array is not None:
            weights_array = weights_array[valid_mask]
        if offset_array is not None:
            offset_array = offset_array[valid_mask]

    return y, X, weights_array, offset_array, valid_mask, n_missing


def _raise_missing_detail(
    y_valid: np.ndarray,
    X: np.ndarray,
    X_names: tuple[str, ...],
    weights_array: np.ndarray | None,
    weights_col: str | None,
    offset_array: np.ndarray | None,
    offset_col: str | None,
    response_var: str,
    n_missing: int,
) -> None:
    """Raise ValueError with per-variable NA breakdown.

    Args:
        y_valid: Boolean mask of finite y values.
        X: Design matrix.
        X_names: Column names for X.
        weights_array: Weight array, or None.
        weights_col: Weights column name, or None.
        offset_array: Offset array, or None.
        offset_col: Offset column name, or None.
        response_var: Response variable name.
        n_missing: Total missing row count.

    Raises:
        ValueError: Always, with detailed per-variable breakdown.
    """
    import numpy as np

    na_counts: dict[str, int] = {}
    if int(np.sum(~y_valid)) > 0:
        na_counts[response_var] = int(np.sum(~y_valid))
    for i, name in enumerate(X_names):
        col_invalid = int(np.sum(~np.isfinite(X[:, i])))
        if col_invalid > 0:
            na_counts[name] = col_invalid
    if weights_array is not None and weights_col is not None:
        w_invalid = int(np.sum(~np.isfinite(weights_array)))
        if w_invalid > 0:
            na_counts[weights_col] = w_invalid
    if offset_array is not None and offset_col is not None:
        o_invalid = int(np.sum(~np.isfinite(offset_array)))
        if o_invalid > 0:
            na_counts[offset_col] = o_invalid
    detail = ", ".join(f"{k}: {v}" for k, v in na_counts.items())
    raise ValueError(
        f"Non-finite values found in {n_missing} rows "
        f"(missing='fail'). Per-variable counts: {detail}"
    )


def _encode_binary_response(
    data: pl.DataFrame,
    response_var: str,
) -> tuple[pl.DataFrame, tuple[str, ...]]:
    """Auto-encode a string/categorical response for binomial models.

    Sorts unique levels alphabetically (matching R's ``factor()`` ordering)
    and maps the first level to 0 and the second to 1.

    Args:
        data: Input DataFrame with a string/categorical response column.
        response_var: Name of the response column.

    Returns:
        Tuple of (modified DataFrame with numeric response, level mapping).
        The level mapping is ``(level_for_0, level_for_1)``.

    Raises:
        ValueError: If the response column does not have exactly 2 unique levels.
    """
    import polars as pl

    col = data[response_var]
    levels = sorted(col.cast(pl.String).unique().drop_nulls().to_list())
    if len(levels) != 2:
        raise ValueError(
            f"Binomial family with string response requires exactly 2 levels, "
            f"but '{response_var}' has {len(levels)}: {levels}. "
            f"Use a numeric 0/1 response or a two-level factor."
        )

    # Encode: first alphabetically → 0, second → 1
    encoded = (
        pl.when(pl.col(response_var).cast(pl.String) == levels[1])
        .then(1.0)
        .otherwise(0.0)
        .alias(response_var)
    )
    data = data.with_columns(encoded)
    return data, tuple(levels)


def _validate_response(family: str, y: np.ndarray, response_var: str) -> None:
    """Family-specific response variable validation.

    Args:
        family: Distribution family name.
        y: Response vector (after NA filtering).
        response_var: Response variable name (for error messages).

    Raises:
        ValueError: If response values violate family constraints.
    """
    import numpy as np

    if family == "poisson" and np.any(y < 0):
        n_neg = int(np.sum(y < 0))
        raise ValueError(
            f"Poisson family requires non-negative response values. "
            f"Found {n_neg} negative value(s) in '{response_var}'. "
            f"Check your data or use a different family (e.g., gaussian)."
        )

    if family == "binomial":
        if np.any(y < 0) or np.any(y > 1):
            warnings.warn(
                f"Binomial family expects response values in [0, 1], "
                f"but '{response_var}' has values outside this range. "
                f"This matches R's behavior (non-integer successes warning).",
                stacklevel=4,
            )


def _reindex_groups_after_na_drop(
    *,
    group_ids_list: list[np.ndarray],
    n_groups_list: list[int],
    Z: np.ndarray,
    X_re: np.ndarray | list[np.ndarray] | None,
    re_info: object,
) -> tuple[list[np.ndarray], list[int], np.ndarray]:
    """Re-index group IDs and rebuild Z after NA rows are dropped.

    When NA filtering removes all observations for some group levels,
    those levels become empty. This function detects empty levels,
    re-indexes group IDs to be contiguous (0..n_active-1), and rebuilds
    the Z matrix to exclude columns for empty groups.

    Args:
        group_ids_list: Filtered group ID arrays (one per grouping factor).
        n_groups_list: Original number of groups per factor.
        Z: Filtered Z matrix (rows already masked by valid_mask).
        X_re: Random effects covariates (already filtered), or None.
        re_info: RandomEffectsInfo from the initial Z construction.

    Returns:
        Tuple of (reindexed_group_ids_list, updated_n_groups_list,
        rebuilt_Z_matrix).
    """
    import numpy as np
    import scipy.sparse as sp

    from bossanova.internal.design.z_matrix import build_z_simple

    any_dropped = False
    new_group_ids_list: list[np.ndarray] = []
    new_n_groups_list: list[int] = []

    for i, (ids, n_orig) in enumerate(zip(group_ids_list, n_groups_list)):
        present = np.unique(ids)
        if len(present) < n_orig:
            any_dropped = True
            # Build old-to-new mapping
            old_to_new = np.full(n_orig, -1, dtype=np.intp)
            old_to_new[present] = np.arange(len(present), dtype=np.intp)
            new_ids = old_to_new[ids]
            new_group_ids_list.append(new_ids)
            new_n_groups_list.append(len(present))
        else:
            new_group_ids_list.append(ids)
            new_n_groups_list.append(n_orig)

    if not any_dropped:
        return group_ids_list, n_groups_list, Z

    # Warn about dropped levels
    for i, (n_old, n_new) in enumerate(zip(n_groups_list, new_n_groups_list)):
        if n_new < n_old:
            name = re_info.group_names[i]
            n_dropped = n_old - n_new
            warnings.warn(
                f"Dropped {n_dropped} empty group level(s) from '{name}' "
                f"after NA filtering ({n_new} levels remaining)",
                stacklevel=5,
            )

    # Rebuild Z from re-indexed group IDs
    if len(new_group_ids_list) == 1:
        # Single factor: rebuild directly
        layout = "interleaved"
        if re_info.re_structure == "diagonal":
            layout = "blocked"
        Z_new = build_z_simple(
            new_group_ids_list[0],
            new_n_groups_list[0],
            X_re=X_re if not isinstance(X_re, list) else None,
            layout=layout,
        )
        if isinstance(X_re, list):
            # Diagonal structure: rebuild each block and hstack
            blocks = []
            for x in X_re:
                blk = build_z_simple(
                    new_group_ids_list[0],
                    new_n_groups_list[0],
                    X_re=x,
                    layout="blocked",
                )
                blocks.append(blk)
            Z_new = sp.hstack(blocks, format="csc")
    else:
        # Multiple factors (crossed): rebuild each block and hstack
        blocks = []
        for j, (ids, n_g) in enumerate(zip(new_group_ids_list, new_n_groups_list)):
            # Determine X_re for this factor
            if isinstance(X_re, list) and j < len(X_re):
                x_j = X_re[j]
            elif not isinstance(X_re, list):
                x_j = X_re
            else:
                x_j = None
            blk = build_z_simple(ids, n_g, X_re=x_j, layout="interleaved")
            blocks.append(blk)
        Z_new = sp.hstack(blocks, format="csc")

    return new_group_ids_list, new_n_groups_list, Z_new


def _build_random_effects(
    *,
    spec: ModelSpec,
    formula_spec: FormulaSpec,
    data: pl.DataFrame,
    valid_mask: np.ndarray,
    n_missing: int,
    n_valid: int,
    effective_p: int,
) -> tuple[np.ndarray | None, REMetadata | None]:
    """Build Z matrix and REMetadata for mixed models.

    Args:
        spec: Model specification.
        formula_spec: Learned formula specification.
        data: Input DataFrame.
        valid_mask: Boolean mask of valid (non-missing) rows.
        n_missing: Number of dropped rows.
        n_valid: Number of valid observations.
        effective_p: Effective number of fixed-effect parameters.

    Returns:
        Tuple of (Z matrix, REMetadata), both None for non-mixed models.

    Raises:
        ValueError: If mixed model is overparameterized.
    """
    if not spec.has_random_effects:
        return None, None

    from bossanova.internal.containers import REMetadata
    from bossanova.internal.formula.random_effects import (
        build_random_effects_from_spec,
    )

    # Ensure String columns known as factors are Enum before RE construction.
    # build_design_matrices handles this for the FE path, but the RE path
    # receives the original DataFrame.  Without this, factor() calls in RE
    # terms (e.g. "(factor(x)|group)") crash in encode_categorical.
    import polars as pl

    if formula_spec.factors:
        casts = []
        for col_name, levels in formula_spec.factors.items():
            if col_name in data.columns and data[col_name].dtype == pl.String:
                casts.append(pl.col(col_name).cast(pl.Enum(levels)))
        if casts:
            data = data.with_columns(casts)

    re_info = build_random_effects_from_spec(formula_spec, data)
    if re_info is None:
        return None, None

    Z = re_info.Z
    group_ids_list = re_info.group_ids_list
    X_re = re_info.X_re

    # Filter to valid rows (listwise deletion for mixed models)
    n_groups_list = list(re_info.n_groups_list)
    if n_missing > 0:
        Z = Z[valid_mask]
        group_ids_list = [ids[valid_mask] for ids in group_ids_list]
        if X_re is not None:
            if isinstance(X_re, list):
                X_re = [x[valid_mask] for x in X_re]
            else:
                X_re = X_re[valid_mask]

        # Re-index groups to drop empty levels and rebuild Z
        group_ids_list, n_groups_list, Z = _reindex_groups_after_na_drop(
            group_ids_list=group_ids_list,
            n_groups_list=n_groups_list,
            Z=Z,
            X_re=X_re,
            re_info=re_info,
        )

    re_metadata = REMetadata(
        grouping_vars=re_info.group_names,
        n_groups={name: n_g for name, n_g in zip(re_info.group_names, n_groups_list)},
        group_indices={
            name: ids for name, ids in zip(re_info.group_names, group_ids_list)
        },
        term_names=re_info.random_names,
        group_ids_list=group_ids_list,
        n_groups_list=n_groups_list,
        re_structure=re_info.re_structure,
        random_names=re_info.random_names,
        X_re=X_re,
        metadata={
            "re_type": re_info.re_structure,
            "re_structures_list": re_info.re_structures_list,
            "random_names": re_info.random_names,
            "group_names": re_info.group_names,
            "n_groups": n_groups_list,
            "re_terms": re_info.random_names,
        },
    )

    # Check for overparameterized mixed model
    total_re_params = sum(n_groups_list) + effective_p
    if n_valid <= total_re_params:
        raise ValueError(
            f"Cannot fit mixed model: overparameterized. "
            f"{n_valid} observations for {effective_p} fixed + "
            f"{sum(n_groups_list)} random effect levels. "
            f"Need more observations than parameters."
        )

    return Z, re_metadata
