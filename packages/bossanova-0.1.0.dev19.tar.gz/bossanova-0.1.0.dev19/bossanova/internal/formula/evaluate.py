"""Term evaluation — AST nodes to design matrix columns."""

import numpy as np
import polars as pl
from attrs import frozen
from numpy.typing import NDArray

from bossanova.internal.formula.parser.expr import (
    Binary,
    Call,
    Grouping,
    Literal,
    QuotedName,
    Variable,
)
from bossanova.internal.design.coding import (
    poly_coding,
    poly_coding_labels,
    sum_coding,
    treatment_coding,
)
from bossanova.internal.formula.encoding import (
    encode_categorical,
    get_levels,
)
from bossanova.internal.maths.transforms import (
    STATEFUL_TRANSFORMS,
)
from bossanova.internal.formula.helpers import (
    variable_not_found_error,
)
from bossanova.internal.formula.evaluate_contrast import (
    evaluate_contrast_call,
)
from bossanova.internal.formula.evaluate_transforms import (
    evaluate_math_transform,
    evaluate_stateful_transform,
)
from bossanova.internal.formula.contrast_registry import (
    MODEL_CONTRAST_FUNCTIONS,
)

__all__ = [
    "TermResult",
    "evaluate_call",
    "evaluate_categorical",
    "evaluate_interaction",
    "evaluate_star",
    "evaluate_term",
    "evaluate_variable",
]


@frozen
class TermResult:
    """Result of evaluating one formula term.

    Attributes:
        columns: Data array, shape (n_obs,) or (n_obs, k).
        labels: Column names for the result.
        state_updates: Partial state to merge back into accumulators.
            May contain keys: "factors", "contrast_matrices",
            "contrast_types", "transform_state", "transforms".
    """

    columns: NDArray[np.float64]
    labels: list[str]
    state_updates: dict


def full_rank_contrast(levels: list[str]) -> NDArray[np.float64]:
    """Build full-rank identity contrast matrix (all levels encoded)."""
    return np.eye(len(levels), dtype=np.float64)


def evaluate_term(
    term: object,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
    intercept_absorbed: bool,
) -> tuple[TermResult, bool]:
    """Evaluate a single formula term against data.

    Dispatches to evaluate_variable, evaluate_call, evaluate_interaction, etc.
    based on AST node type.

    Args:
        term: AST node representing the term.
        data: Polars DataFrame with training data.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices mapping.
        transform_state: Current transform state mapping.
        transforms: Current fitted transform instances mapping.
        custom_contrasts: User-provided contrast matrices.
        intercept_absorbed: Whether intercept df has been absorbed.

    Returns:
        (TermResult, updated_intercept_absorbed).
    """
    if isinstance(term, Variable):
        result = evaluate_variable(
            term.name.lexeme,
            data,
            factors,
            contrast_matrices,
            custom_contrasts,
            intercept_absorbed,
        )
        # Check if a categorical absorbed the intercept
        new_absorbed = intercept_absorbed
        if term.name.lexeme in result.state_updates.get("contrast_types", {}):
            ct = result.state_updates["contrast_types"][term.name.lexeme]
            if ct == "full":
                new_absorbed = True
        return result, new_absorbed

    if isinstance(term, QuotedName):
        result = evaluate_variable(
            term.expression.lexeme,
            data,
            factors,
            contrast_matrices,
            custom_contrasts,
            intercept_absorbed,
        )
        new_absorbed = intercept_absorbed
        if term.expression.lexeme in result.state_updates.get("contrast_types", {}):
            ct = result.state_updates["contrast_types"][term.expression.lexeme]
            if ct == "full":
                new_absorbed = True
        return result, new_absorbed

    if isinstance(term, Call):
        result, new_absorbed = evaluate_call(
            term,
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
            intercept_absorbed,
        )
        return result, new_absorbed

    if isinstance(term, Grouping):
        return evaluate_term(
            term.expression,
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
            intercept_absorbed,
        )

    if isinstance(term, Binary):
        if term.operator.kind == "COLON":
            result, new_absorbed = evaluate_interaction(
                term,
                data,
                factors,
                contrast_matrices,
                transform_state,
                transforms,
                custom_contrasts,
                intercept_absorbed,
                is_toplevel=True,
            )
            return result, new_absorbed

        if term.operator.kind == "STAR":
            result, new_absorbed = evaluate_star(
                term,
                data,
                factors,
                contrast_matrices,
                transform_state,
                transforms,
                custom_contrasts,
                intercept_absorbed,
            )
            return result, new_absorbed

        if term.operator.kind in ("STAR_STAR", "CARET"):
            left_result, _ = evaluate_term(
                term.left,
                data,
                factors,
                contrast_matrices,
                transform_state,
                transforms,
                custom_contrasts,
                intercept_absorbed,
            )
            right_result, _ = evaluate_term(
                term.right,
                data,
                factors,
                contrast_matrices,
                transform_state,
                transforms,
                custom_contrasts,
                intercept_absorbed,
            )
            left_data = left_result.columns
            right_data = right_result.columns
            if right_data.ndim > 0 and len(np.unique(right_data)) == 1:
                exponent = right_data[0]
            else:
                exponent = right_data
            result_arr = np.power(left_data, exponent)
            base_label = left_result.labels[0] if left_result.labels else "x"
            exp_label = int(exponent) if float(exponent).is_integer() else exponent
            labels = [f"{base_label}**{exp_label}"]
            return TermResult(
                columns=result_arr, labels=labels, state_updates={}
            ), intercept_absorbed

        raise ValueError(f"Unsupported binary operator in term: {term.operator.kind}")

    if isinstance(term, Literal):
        n_obs = len(data)
        val = float(term.value) if isinstance(term.value, (int, float)) else 0.0
        return TermResult(
            columns=np.full(n_obs, val, dtype=np.float64),
            labels=[str(term.value)],
            state_updates={},
        ), intercept_absorbed

    raise ValueError(f"Unsupported term type: {type(term)}")


def evaluate_variable(
    name: str,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    custom_contrasts: dict[str, NDArray],
    intercept_absorbed: bool,
) -> TermResult:
    """Evaluate a simple variable reference.

    Args:
        name: Column name.
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        custom_contrasts: User-provided contrast matrices.
        intercept_absorbed: Whether intercept df has been absorbed.

    Returns:
        TermResult with evaluated data.
    """
    if name not in data.columns:
        raise variable_not_found_error(name, data.columns)

    series = data[name]
    dtype = series.dtype

    if isinstance(dtype, (pl.Enum, pl.Categorical)) or name in factors:
        return evaluate_categorical(
            name,
            series,
            factors,
            contrast_matrices,
            custom_contrasts,
            intercept_absorbed,
        )

    return TermResult(
        columns=series.to_numpy().astype(np.float64),
        labels=[name],
        state_updates={},
    )


def evaluate_categorical(
    name: str,
    series: pl.Series,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    custom_contrasts: dict[str, NDArray],
    intercept_absorbed: bool,
    *,
    spans_intercept: bool | None = None,
    contrast_type: str | None = None,
) -> TermResult:
    """Evaluate a categorical variable with contrast encoding.

    Args:
        name: Variable name.
        series: Polars series with categorical data.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        custom_contrasts: User-provided contrast matrices.
        intercept_absorbed: Whether intercept df has been absorbed.
        spans_intercept: Whether this categorical should span the intercept.
            If None, determined automatically.
        contrast_type: Type of contrast to use. If None, defaults to "treatment".

    Returns:
        TermResult with encoded data and state updates.
    """
    # Get levels
    if name in factors:
        levels = (
            list(factors[name]) if isinstance(factors[name], tuple) else factors[name]
        )
    else:
        levels = get_levels(series)

    # Determine if this categorical spans the intercept
    if spans_intercept is None:
        spans_intercept = not intercept_absorbed

    state_updates: dict = {
        "factors": {},
        "contrast_matrices": {},
        "contrast_types": {},
    }

    # Build contrast matrix
    if spans_intercept:
        contrast = full_rank_contrast(levels)
        labels = [f"{name}[{lvl}]" for lvl in levels]
        actual_contrast_type = "full"
    elif name in custom_contrasts:
        contrast = custom_contrasts[name]
        actual_contrast_type = "custom"
        n_cols = contrast.shape[1]
        labels = [f"{name}[c{i + 1}]" for i in range(n_cols)]
    else:
        if contrast_type == "sum":
            contrast = sum_coding(levels)
            ref_level = levels[-1]
            actual_contrast_type = "sum"
            labels = [f"{name}[{lvl}]" for lvl in levels if lvl != ref_level]
        elif contrast_type == "poly":
            contrast = poly_coding(levels)
            actual_contrast_type = "poly"
            labels = [f"{name}{suffix}" for suffix in poly_coding_labels(levels)]
        else:
            contrast = treatment_coding(levels)
            ref_level = levels[0]
            actual_contrast_type = "treatment"
            labels = [f"{name}[{lvl}]" for lvl in levels if lvl != ref_level]

    state_updates["factors"][name] = levels
    state_updates["contrast_matrices"][name] = contrast
    state_updates["contrast_types"][name] = actual_contrast_type

    encoded = encode_categorical(series, contrast)

    return TermResult(columns=encoded, labels=labels, state_updates=state_updates)


def evaluate_call(
    call: Call,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
    intercept_absorbed: bool,
) -> tuple[TermResult, bool]:
    """Evaluate a function call term.

    Handles: contrast functions, transform, center/norm/zscore/scale, log/log10/sqrt.

    Args:
        call: Call AST node.
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        transform_state: Current transform state mapping.
        transforms: Current fitted transform instances.
        custom_contrasts: User-provided contrast matrices.
        intercept_absorbed: Whether intercept df has been absorbed.

    Returns:
        (TermResult, updated_intercept_absorbed).
    """
    if not isinstance(call.callee, Variable):
        raise ValueError(f"Unsupported callee type: {type(call.callee)}")

    func_name = call.callee.name.lexeme

    # Identity function transform() — evaluate contents as arithmetic
    if func_name == "transform":
        if not call.args:
            raise ValueError("transform() requires an argument")
        return evaluate_term(
            call.args[0],
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
            intercept_absorbed,
        )

    # Stateful transforms: center, norm, zscore, scale
    if func_name in STATEFUL_TRANSFORMS:
        if not call.args:
            raise ValueError(f"{func_name}() requires an argument")
        result = evaluate_stateful_transform(
            func_name,
            call.args[0],
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
        )
        return result, intercept_absorbed

    # Math transforms: log, log10, sqrt
    if func_name in ("log", "log10", "sqrt"):
        if not call.args:
            raise ValueError(f"{func_name}() requires an argument")
        result = evaluate_math_transform(
            func_name,
            call.args[0],
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
        )
        return result, intercept_absorbed

    # Contrast encoding functions: treatment, sum, helmert, sequential, poly, dummy, deviation
    if func_name in MODEL_CONTRAST_FUNCTIONS:
        return evaluate_contrast_call(
            call,
            func_name,
            data,
            factors,
            contrast_matrices,
            custom_contrasts,
            intercept_absorbed,
        )

    raise ValueError(
        f"Unknown function '{func_name}'. "
        f"Supported: treatment, sum, helmert, sequential, poly, "
        f"center, norm, zscore, scale, rank, signed_rank, log, log10, sqrt"
    )


def evaluate_term_for_interaction(
    term: object,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
    spans_intercept: bool,
) -> tuple[NDArray[np.float64], list[str], dict]:
    """Evaluate a term as part of an interaction with explicit spans_intercept.

    Args:
        term: AST node representing the term.
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        transform_state: Current transform state.
        transforms: Current fitted transforms.
        custom_contrasts: User-provided contrast matrices.
        spans_intercept: Whether categorical terms should use full encoding.

    Returns:
        (data_array, labels, state_updates).
    """
    if isinstance(term, Variable):
        name = term.name.lexeme
        if name not in data.columns:
            raise variable_not_found_error(name, data.columns)
        series = data[name]
        dtype = series.dtype
        if isinstance(dtype, (pl.Enum, pl.Categorical)) or name in factors:
            result = evaluate_categorical(
                name,
                series,
                factors,
                contrast_matrices,
                custom_contrasts,
                not spans_intercept,  # intercept_absorbed = not spans_intercept
                spans_intercept=spans_intercept,
            )
            return result.columns, result.labels, result.state_updates
        return series.to_numpy().astype(np.float64), [name], {}

    if isinstance(term, QuotedName):
        name = term.expression.lexeme
        if name not in data.columns:
            raise variable_not_found_error(name, data.columns)
        series = data[name]
        dtype = series.dtype
        if isinstance(dtype, (pl.Enum, pl.Categorical)) or name in factors:
            result = evaluate_categorical(
                name,
                series,
                factors,
                contrast_matrices,
                custom_contrasts,
                not spans_intercept,
                spans_intercept=spans_intercept,
            )
            return result.columns, result.labels, result.state_updates
        return series.to_numpy().astype(np.float64), [name], {}

    if isinstance(term, Call):
        if isinstance(term.callee, Variable):
            func_name = term.callee.name.lexeme
            # Contrast encoding functions in interactions
            if func_name in MODEL_CONTRAST_FUNCTIONS and term.args:
                result, _ = evaluate_contrast_call(
                    term,
                    func_name,
                    data,
                    factors,
                    contrast_matrices,
                    custom_contrasts,
                    not spans_intercept,
                    spans_intercept=spans_intercept,
                )
                return result.columns, result.labels, result.state_updates
        # Fall through to regular call evaluation
        result, _ = evaluate_call(
            term,
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
            not spans_intercept,
        )
        return result.columns, result.labels, result.state_updates

    if isinstance(term, Grouping):
        return evaluate_term_for_interaction(
            term.expression,
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
            spans_intercept,
        )

    if isinstance(term, Binary) and term.operator.kind == "COLON":
        return evaluate_nested_interaction(
            term,
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
            spans_intercept,
        )

    # For other terms, use regular evaluation
    result, _ = evaluate_term(
        term,
        data,
        factors,
        contrast_matrices,
        transform_state,
        transforms,
        custom_contrasts,
        True,
    )
    return result.columns, result.labels, result.state_updates


def evaluate_nested_interaction(
    term: Binary,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
    spans_intercept: bool,
) -> tuple[NDArray[np.float64], list[str], dict]:
    """Evaluate a nested interaction with propagated spans_intercept.

    Args:
        term: Binary AST node with COLON operator.
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        transform_state: Current transform state.
        transforms: Current fitted transforms.
        custom_contrasts: User-provided contrast matrices.
        spans_intercept: Whether categorical components should use full encoding.

    Returns:
        (interaction_array, labels, merged_state_updates).
    """
    left_data, left_labels, left_state = evaluate_term_for_interaction(
        term.left,
        data,
        factors,
        contrast_matrices,
        transform_state,
        transforms,
        custom_contrasts,
        spans_intercept,
    )
    right_data, right_labels, right_state = evaluate_term_for_interaction(
        term.right,
        data,
        factors,
        contrast_matrices,
        transform_state,
        transforms,
        custom_contrasts,
        spans_intercept,
    )

    if left_data.ndim == 1:
        left_data = left_data.reshape(-1, 1)
    if right_data.ndim == 1:
        right_data = right_data.reshape(-1, 1)

    n_left = left_data.shape[1]
    n_right = right_data.shape[1]
    n_obs = left_data.shape[0]

    result_cols = []
    result_labels = []
    for i in range(n_left):
        for j in range(n_right):
            result_cols.append(left_data[:, i] * right_data[:, j])
            result_labels.append(f"{left_labels[i]}:{right_labels[j]}")

    if result_cols:
        result = np.column_stack(result_cols)
    else:
        result = np.empty((n_obs, 0), dtype=np.float64)

    # Merge state updates
    merged_state: dict = {}
    for s in (left_state, right_state):
        for key, val in s.items():
            if key not in merged_state:
                merged_state[key] = {}
            merged_state[key].update(val)

    return result, result_labels, merged_state


def evaluate_interaction(
    term: Binary,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
    intercept_absorbed: bool,
    *,
    is_toplevel: bool = True,
) -> tuple[TermResult, bool]:
    """Evaluate an interaction term (a:b).

    Args:
        term: Binary AST node with COLON operator.
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        transform_state: Current transform state.
        transforms: Current fitted transforms.
        custom_contrasts: User-provided contrast matrices.
        intercept_absorbed: Whether intercept df has been absorbed.
        is_toplevel: Whether this is a top-level interaction term.

    Returns:
        (TermResult, updated_intercept_absorbed).
    """
    left_spans = not intercept_absorbed if is_toplevel else False
    right_spans = not intercept_absorbed if is_toplevel else False

    left_data, left_labels, left_state = evaluate_term_for_interaction(
        term.left,
        data,
        factors,
        contrast_matrices,
        transform_state,
        transforms,
        custom_contrasts,
        left_spans,
    )
    right_data, right_labels, right_state = evaluate_term_for_interaction(
        term.right,
        data,
        factors,
        contrast_matrices,
        transform_state,
        transforms,
        custom_contrasts,
        right_spans,
    )

    new_absorbed = intercept_absorbed
    if left_spans or right_spans:
        new_absorbed = True

    if left_data.ndim == 1:
        left_data = left_data.reshape(-1, 1)
    if right_data.ndim == 1:
        right_data = right_data.reshape(-1, 1)

    n_left = left_data.shape[1]
    n_right = right_data.shape[1]
    n_obs = left_data.shape[0]

    result_cols = []
    result_labels = []
    for i in range(n_left):
        for j in range(n_right):
            result_cols.append(left_data[:, i] * right_data[:, j])
            result_labels.append(f"{left_labels[i]}:{right_labels[j]}")

    if result_cols:
        result = np.column_stack(result_cols)
    else:
        result = np.empty((n_obs, 0), dtype=np.float64)

    # Merge state updates
    merged_state: dict = {}
    for s in (left_state, right_state):
        for key, val in s.items():
            if key not in merged_state:
                merged_state[key] = {}
            merged_state[key].update(val)

    return TermResult(
        columns=result, labels=result_labels, state_updates=merged_state
    ), new_absorbed


def evaluate_star(
    term: Binary,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
    intercept_absorbed: bool,
) -> tuple[TermResult, bool]:
    """Evaluate a * term (main effects + interaction): a * b = a + b + a:b.

    Args:
        term: Binary AST node with STAR operator.
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        transform_state: Current transform state.
        transforms: Current fitted transforms.
        custom_contrasts: User-provided contrast matrices.
        intercept_absorbed: Whether intercept df has been absorbed.

    Returns:
        (TermResult, updated_intercept_absorbed).
    """
    # Get main effects (these will absorb intercept if needed)
    left_result, intercept_absorbed = evaluate_term(
        term.left,
        data,
        factors,
        contrast_matrices,
        transform_state,
        transforms,
        custom_contrasts,
        intercept_absorbed,
    )
    # Merge left state updates into factors/contrasts for right side
    merged_factors = dict(factors)
    merged_contrasts = dict(contrast_matrices)
    for key, val in left_result.state_updates.get("factors", {}).items():
        merged_factors[key] = val
    for key, val in left_result.state_updates.get("contrast_matrices", {}).items():
        merged_contrasts[key] = val

    right_result, intercept_absorbed = evaluate_term(
        term.right,
        data,
        merged_factors,
        merged_contrasts,
        transform_state,
        transforms,
        custom_contrasts,
        intercept_absorbed,
    )

    # Get interaction (main effects already absorbed intercept, so reduced encoding)
    int_result, intercept_absorbed = evaluate_interaction(
        term,
        data,
        merged_factors,
        merged_contrasts,
        transform_state,
        transforms,
        custom_contrasts,
        intercept_absorbed,
        is_toplevel=False,
    )

    # Combine columns
    all_cols = []
    all_labels = []

    for result in (left_result, right_result, int_result):
        d = result.columns
        if d.ndim == 1:
            all_cols.append(d)
        else:
            for i in range(d.shape[1]):
                all_cols.append(d[:, i])
        all_labels.extend(result.labels)

    if all_cols:
        combined = np.column_stack(all_cols)
    else:
        combined = np.empty((len(data), 0), dtype=np.float64)

    # Merge all state updates
    merged_state: dict = {}
    for result in (left_result, right_result, int_result):
        for key, val in result.state_updates.items():
            if key not in merged_state:
                merged_state[key] = {}
            if isinstance(val, dict):
                merged_state[key].update(val)

    return TermResult(
        columns=combined, labels=all_labels, state_updates=merged_state
    ), intercept_absorbed
