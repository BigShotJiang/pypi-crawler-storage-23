"""Contrast specification resolution for design matrix coding.

Resolves user-facing contrast specs (strings, tuples, ndarrays) into
concrete contrast matrices. This is pure validation + dispatch logic
extracted from the model class.

Internal exports:
    resolve_contrast_specs: Validate and resolve contrast specifications
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from bossanova.internal.design.coding import (
    helmert_coding,
    poly_coding,
    sequential_coding,
    sum_coding,
    treatment_coding,
)

if TYPE_CHECKING:
    import polars as pl
    from numpy.typing import NDArray

__all__ = ["resolve_contrast_specs"]

VALID_CONTRAST_NAMES = ("treatment", "sum", "poly", "helmert", "sequential")

_CONTRAST_BUILDERS: dict[str, object] = {
    "treatment": treatment_coding,
    "sum": sum_coding,
    "poly": poly_coding,
    "sequential": sequential_coding,
    "helmert": helmert_coding,
}


def resolve_contrast_specs(
    data: pl.DataFrame,
    contrasts: dict[str, object],
) -> dict[str, NDArray[np.float64]]:
    """Resolve user-facing contrast specs into concrete contrast matrices.

    Takes the raw contrast specifications provided by the user (strings,
    tuples, ndarrays) and validates them against the data, returning a
    dict mapping column names to contrast matrices.

    Args:
        data: Polars DataFrame containing the model data. Used to validate
            column existence and extract factor levels.
        contrasts: Mapping of column names to contrast specifications.
            Each value can be:
            - A string: ``'treatment'``, ``'sum'``, ``'helmert'``, ``'poly'``,
              or ``'sequential'``
            - A tuple: ``('treatment', 'B')`` for treatment coding with 'B'
              as reference, or ``('sum', 'A')`` for sum coding omitting 'A'
            - An ndarray: Custom contrast matrix of shape
              ``(n_levels, n_levels - 1)``

    Returns:
        Dict mapping column names to contrast matrices (each of shape
        ``(n_levels, n_levels - 1)``).

    Raises:
        ValueError: If a column is not found in the data.
        ValueError: If a column has fewer than 2 unique values.
        ValueError: If an unknown contrast type string is provided.
        ValueError: If a custom matrix has wrong dimensions.
        ValueError: If a reference/omit level is not found in the data.
        TypeError: If a contrast spec is not a string, tuple, or ndarray.
    """
    custom: dict[str, NDArray[np.float64]] = {}

    for col_name, spec in contrasts.items():
        if col_name not in data.columns:
            raise ValueError(
                f"Column '{col_name}' not found in data. "
                f"Available columns: {data.columns}"
            )

        levels = sorted(data[col_name].unique().to_list())
        n_levels = len(levels)

        if n_levels < 2:
            raise ValueError(
                f"Column '{col_name}' has {n_levels} unique values. "
                f"Need at least 2 for contrast coding."
            )

        custom[col_name] = _resolve_single_spec(col_name, spec, levels, n_levels)

    return custom


def _resolve_single_spec(
    col_name: str,
    spec: object,
    levels: list[str],
    n_levels: int,
) -> NDArray[np.float64]:
    """Resolve a single contrast specification to a matrix.

    Args:
        col_name: Column name (for error messages).
        spec: The contrast specification (string, tuple, or ndarray).
        levels: Sorted unique level values.
        n_levels: Number of levels.

    Returns:
        Contrast matrix of shape (n_levels, n_levels - 1).

    Raises:
        ValueError: If spec is invalid.
        TypeError: If spec type is unsupported.
    """
    if isinstance(spec, str):
        return _resolve_string_spec(col_name, spec, levels)

    if isinstance(spec, tuple) and len(spec) == 2:
        return _resolve_tuple_spec(col_name, spec, levels)

    if isinstance(spec, np.ndarray):
        return _resolve_ndarray_spec(col_name, spec, n_levels)

    raise TypeError(
        f"Invalid contrast spec for '{col_name}': expected str, "
        f"tuple, or ndarray, got {type(spec).__name__}"
    )


def _resolve_string_spec(
    col_name: str,
    spec: str,
    levels: list[str],
) -> NDArray[np.float64]:
    """Resolve a string contrast spec (e.g. 'sum', 'helmert').

    Args:
        col_name: Column name (for error messages).
        spec: Contrast type name.
        levels: Sorted unique level values.

    Returns:
        Contrast matrix.

    Raises:
        ValueError: If spec is not a recognized contrast name.
    """
    if spec not in VALID_CONTRAST_NAMES:
        raise ValueError(
            f"Unknown contrast type '{spec}'. Valid types: {list(VALID_CONTRAST_NAMES)}"
        )

    builder = _CONTRAST_BUILDERS[spec]
    return builder(levels)  # type: ignore[operator]


def _resolve_tuple_spec(
    col_name: str,
    spec: tuple[object, ...],
    levels: list[str],
) -> NDArray[np.float64]:
    """Resolve a tuple contrast spec (e.g. ('treatment', 'B')).

    Args:
        col_name: Column name (for error messages).
        spec: Tuple of (contrast_type, reference_or_omit_level).
        levels: Sorted unique level values.

    Returns:
        Contrast matrix.

    Raises:
        ValueError: If contrast type is unsupported or level not found.
    """
    contrast_type, ref_level = spec

    if contrast_type == "treatment":
        if ref_level not in levels:
            raise ValueError(
                f"Reference level '{ref_level}' not found in "
                f"'{col_name}'. Available levels: {levels}"
            )
        return treatment_coding(levels, reference=ref_level)  # type: ignore[arg-type]

    if contrast_type == "sum":
        if ref_level not in levels:
            raise ValueError(
                f"Omit level '{ref_level}' not found in '{col_name}'. "
                f"Available levels: {levels}"
            )
        return sum_coding(levels, omit=ref_level)  # type: ignore[arg-type]

    raise ValueError(
        f"Tuple contrast must use 'treatment' or 'sum', got '{contrast_type}'"
    )


def _resolve_ndarray_spec(
    col_name: str,
    spec: NDArray[np.float64],
    n_levels: int,
) -> NDArray[np.float64]:
    """Resolve a custom ndarray contrast spec.

    Args:
        col_name: Column name (for error messages).
        spec: Custom contrast matrix.
        n_levels: Expected number of levels.

    Returns:
        The validated contrast matrix.

    Raises:
        ValueError: If matrix shape doesn't match expected dimensions.
    """
    expected_shape = (n_levels, n_levels - 1)
    if spec.shape != expected_shape:
        raise ValueError(
            f"Custom contrast matrix for '{col_name}' has shape "
            f"{spec.shape}, expected {expected_shape} "
            f"(n_levels x n_levels-1)"
        )
    return spec
