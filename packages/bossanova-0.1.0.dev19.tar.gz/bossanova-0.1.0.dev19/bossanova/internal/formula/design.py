"""Design matrix construction from FormulaSpec."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import evolve, frozen
from numpy.typing import NDArray

from bossanova.internal.formula.encoding import ensure_enum
from bossanova.internal.containers.structs.formula import FormulaSpec
from bossanova.internal.formula.evaluate import evaluate_term
from bossanova.internal.maths.transforms import STATEFUL_TRANSFORMS, create_transform

if TYPE_CHECKING:
    import polars as pl

__all__ = [
    "DesignResult",
    "build_design_matrices",
]


@frozen
class DesignResult:
    """Output of build_design_matrices(). Separates arrays from metadata.

    Attributes:
        X: Fixed effects design matrix of shape (n_obs, n_features).
        X_labels: Column names for X matrix.
        y: Response vector of shape (n_obs,), or None.
        y_label: Name of response variable, or None.
    """

    X: NDArray[np.float64]
    X_labels: tuple[str, ...]
    y: NDArray[np.float64] | None = None
    y_label: str | None = None

    @property
    def n_obs(self) -> int:
        """Number of observations."""
        return self.X.shape[0]

    @property
    def n_features(self) -> int:
        """Number of features (columns in X)."""
        return self.X.shape[1]


def build_design_matrices(
    spec: FormulaSpec,
    data: pl.DataFrame,
) -> tuple[DesignResult, FormulaSpec]:
    """Build X and y matrices from a parsed formula spec.

    Evaluates terms, learns encoding (contrasts, transforms), and returns
    both the design matrices AND an updated FormulaSpec with learned state.

    The returned FormulaSpec has contrast_matrices, contrast_types, and
    transform_state populated (they may be empty in the input spec from
    parse_formula if this is the first build).

    Args:
        spec: FormulaSpec from parse_formula().
        data: Polars DataFrame with training data.

    Returns:
        (DesignResult, FormulaSpec) — matrices + updated spec with learned encoding.

    Raises:
        ValueError: If response variable not found in data.
        ValueError: If predictor variable not found in data.
    """
    n_obs = len(data)

    # Ensure categorical columns are Enum type
    factors_as_lists = {
        k: list(v) if isinstance(v, tuple) else v for k, v in spec.factors.items()
    }
    if factors_as_lists:
        data = ensure_enum(data, factors_as_lists)

    # Mutable accumulators (local to this function)
    learned_factors: dict[str, list[str]] = {
        k: list(v) if isinstance(v, tuple) else v for k, v in spec.factors.items()
    }
    learned_contrasts: dict = dict(spec.contrast_matrices)
    learned_types: dict[str, str] = dict(spec.contrast_types)
    learned_transform_state: dict[str, dict] = dict(spec.transform_state)
    learned_transforms: dict[str, object] = dict(spec.transforms)
    intercept_absorbed = False

    # Build response vector
    y: NDArray[np.float64] | None = None
    if spec.response_var is not None:
        if spec.response_var not in data.columns:
            raise ValueError(f"Response variable '{spec.response_var}' not in data")
        y = data[spec.response_var].to_numpy().astype(np.float64)

        # Apply response transform chain if specified (e.g. rank(y), zscore(rank(y)))
        # Chain is stored innermost-first: ("rank", "zscore") means zscore(rank(y))
        if spec.response_transform is not None:
            # Build nested label incrementally: y → rank(y) → zscore(rank(y))
            label_so_far = spec.response_var
            for resp_transform_name in spec.response_transform:
                resp_key = f"{resp_transform_name}({label_so_far})"
                if resp_transform_name in STATEFUL_TRANSFORMS:
                    transform = create_transform(resp_transform_name)
                    y = transform.fit_transform(y)
                    learned_transform_state[resp_key] = {
                        "type": resp_transform_name,
                        "variable": label_so_far,
                        "params": transform.state.params,
                    }
                    learned_transforms[resp_key] = transform
                elif resp_transform_name == "log":
                    y = np.log(y)
                elif resp_transform_name == "log10":
                    y = np.log10(y)
                elif resp_transform_name == "sqrt":
                    y = np.sqrt(y)
                label_so_far = resp_key

    # Build design matrix columns
    columns: list[NDArray[np.float64]] = []
    labels: list[str] = []

    # Add intercept
    if spec.has_intercept:
        columns.append(np.ones(n_obs, dtype=np.float64))
        labels.append("Intercept")
        intercept_absorbed = True

    # Evaluate each term
    for term in spec.rhs_terms:
        result, intercept_absorbed = evaluate_term(
            term,
            data,
            learned_factors,
            learned_contrasts,
            learned_transform_state,
            learned_transforms,
            spec.custom_contrasts,
            intercept_absorbed,
        )

        # Merge state updates from this term
        for key, val in result.state_updates.get("factors", {}).items():
            learned_factors[key] = val
        for key, val in result.state_updates.get("contrast_matrices", {}).items():
            learned_contrasts[key] = val
        for key, val in result.state_updates.get("contrast_types", {}).items():
            learned_types[key] = val
        for key, val in result.state_updates.get("transform_state", {}).items():
            learned_transform_state[key] = val
        for key, val in result.state_updates.get("transforms", {}).items():
            learned_transforms[key] = val

        # Collect columns
        if result.columns.ndim == 1:
            columns.append(result.columns)
        else:
            for i in range(result.columns.shape[1]):
                columns.append(result.columns[:, i])
        labels.extend(result.labels)

    # Stack into matrix
    if columns:
        X = np.column_stack(columns)
    else:
        X = np.empty((n_obs, 0), dtype=np.float64)

    # Freeze into updated FormulaSpec
    updated_spec = evolve(
        spec,
        factors={k: tuple(v) for k, v in learned_factors.items()},
        contrast_matrices=learned_contrasts,
        contrast_types=learned_types,
        transform_state=learned_transform_state,
        transforms=learned_transforms,
    )

    design_result = DesignResult(
        X=X,
        X_labels=tuple(labels),
        y=y,
        y_label=spec.response_var,
    )

    return design_result, updated_spec
