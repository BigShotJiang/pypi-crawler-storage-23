"""Shared AST utilities for formula operations."""

from bossanova.internal.formula.parser.expr import (
    Binary,
    Grouping,
    Literal,
    QuotedName,
    Variable,
)

__all__ = [
    "contains_pipe",
    "extract_name",
    "variable_not_found_error",
]


def extract_name(node: object) -> str | None:
    """Extract variable name or literal value from AST node.

    Handles interaction terms (a:b) by recursively extracting names
    from both sides and joining with ':'.

    Args:
        node: AST node to extract name from.

    Returns:
        Variable name string, or None if not extractable.
    """
    if isinstance(node, Variable):
        return node.name.lexeme
    if isinstance(node, QuotedName):
        return node.expression.lexeme
    if isinstance(node, Literal):
        return str(node.value)
    if isinstance(node, Binary) and node.operator.kind == "COLON":
        left_name = extract_name(node.left)
        right_name = extract_name(node.right)
        if left_name is not None and right_name is not None:
            return f"{left_name}:{right_name}"
    return None


def contains_pipe(node: object) -> bool:
    """Check if an AST node contains a PIPE operator (random effect).

    Args:
        node: AST node to check.

    Returns:
        True if node contains a PIPE operator.
    """
    if isinstance(node, Binary):
        if node.operator.kind == "PIPE":
            return True
        return contains_pipe(node.left) or contains_pipe(node.right)
    if isinstance(node, Grouping):
        return contains_pipe(node.expression)
    return False


def variable_not_found_error(name: str, data_columns: list[str]) -> ValueError:
    """Create informative error for missing variable.

    Args:
        name: Variable name that was not found.
        data_columns: List of available column names in the data.

    Returns:
        ValueError with helpful message including available columns
        and "did you mean?" suggestions.
    """
    name_lower = name.lower()
    similar = [
        col
        for col in data_columns
        if name_lower in col.lower() or col.lower() in name_lower
    ]

    msg = f'Variable "{name}" not found in data.\n\n'
    if len(data_columns) <= 10:
        msg += f"Available columns: {', '.join(data_columns)}"
    else:
        msg += f"Available columns: {', '.join(data_columns[:10])} ... and {len(data_columns) - 10} more"

    if similar:
        suggestions = ", ".join(f'"{s}"' for s in similar[:3])
        msg += f"\n\nDid you mean: {suggestions}?"

    return ValueError(msg)
