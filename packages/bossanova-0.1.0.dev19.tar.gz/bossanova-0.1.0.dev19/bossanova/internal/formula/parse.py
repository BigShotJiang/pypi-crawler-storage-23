"""R-style formula string parsing into FormulaSpec containers."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from attrs import frozen

from bossanova.internal.formula.parser import Parser, Scanner
from bossanova.internal.formula.parser.expr import (
    Binary,
    Call,
    Grouping,
    Literal,
    Unary,
    Variable,
)
from bossanova.internal.formula.encoding import detect_categoricals
from bossanova.internal.containers.structs.formula import FormulaSpec
from bossanova.internal.maths.transforms import STATEFUL_TRANSFORMS
from bossanova.internal.formula.helpers import (
    contains_pipe,
    extract_name,
)

if TYPE_CHECKING:
    import polars as pl
    from numpy.typing import NDArray

__all__ = [
    "FormulaError",
    "FormulaStructure",
    "expand_double_verts",
    "expand_nested_syntax",
    "extract_formula_structure",
    "parse_formula",
]


class FormulaError(ValueError):
    """Exception raised for formula parsing errors.

    Provides helpful error messages with pointer to error position.

    Args:
        message: Error description.
        formula: The formula that caused the error.
        position: Character position of the error (optional).
    """

    def __init__(
        self,
        message: str,
        formula: str | None = None,
        position: int | None = None,
    ) -> None:
        self.formula = formula
        self.position = position
        if formula and position is not None:
            pointer = " " * position + "^"
            full_message = f"{message}\n  {formula}\n  {pointer}"
        elif formula:
            full_message = f"{message}\n  Formula: {formula}"
        else:
            full_message = message
        super().__init__(full_message)


def parse_formula(
    formula: str,
    data: pl.DataFrame,
    *,
    factors: dict[str, list[str]] | None = None,
    custom_contrasts: dict[str, NDArray] | None = None,
) -> FormulaSpec:
    """Parse formula and detect categoricals from data.

    This does parsing + categorical detection but NOT matrix construction.
    Reuses parser/ for tokenization and AST construction.

    Args:
        formula: R-style formula string (e.g., "y ~ x + z").
        data: Polars DataFrame to detect categoricals from.
        factors: Optional dict mapping column names to level orderings.
            If provided, these orderings are used for categorical encoding.
        custom_contrasts: Optional dict of user-provided contrast matrices.

    Returns:
        FormulaSpec with parsed terms and detected factor levels.

    Raises:
        FormulaError: If formula syntax is invalid.
        TypeError: If formula is not a string.
        ValueError: If formula is empty.
    """
    user_factors = factors or {}
    user_contrasts = custom_contrasts or {}

    # Validate formula type
    if not isinstance(formula, str):
        raise TypeError(f"Formula must be a string, got {type(formula).__name__}")
    if not formula or not formula.strip():
        raise ValueError("Formula cannot be empty. Example: 'y ~ x1 + x2'")

    # Pre-process: expand || and / syntax
    expanded_formula, uncorr_metadata = expand_double_verts(formula)
    expanded_formula, nested_metadata = expand_nested_syntax(expanded_formula)

    # Tokenize and parse
    tokens = Scanner(expanded_formula).scan()
    ast = Parser(tokens, expanded_formula).parse()

    # Extract response and RHS terms
    response_name: str | None = None
    response_transform: tuple[str, ...] | None = None
    rhs_terms: list[object] = []
    re_terms: list[object] = []
    has_intercept = True

    # Known transforms that can appear on the LHS
    _KNOWN_RESPONSE_TRANSFORMS = set(STATEFUL_TRANSFORMS) | {"log", "log10", "sqrt"}

    if isinstance(ast, Binary) and ast.operator.kind == "TILDE":
        # Handle LHS transforms like rank(y), log(y), zscore(rank(y))
        if isinstance(ast.left, Call) and isinstance(ast.left.callee, Variable):
            # Walk nested Call chain to extract transform list + base variable
            chain: list[str] = []
            node = ast.left
            while isinstance(node, Call) and isinstance(node.callee, Variable):
                func_name = node.callee.name.lexeme
                if func_name not in _KNOWN_RESPONSE_TRANSFORMS:
                    raise FormulaError(
                        f"Unknown response transform '{func_name}'. "
                        f"Supported: {sorted(_KNOWN_RESPONSE_TRANSFORMS)}",
                        formula=formula,
                    )
                if not node.args:
                    raise FormulaError(
                        f"{func_name}() requires an argument",
                        formula=formula,
                    )
                chain.append(func_name)
                node = node.args[0]
            # node should now be a Variable (the base response)
            var_name = extract_name(node)
            if var_name is None:
                raise FormulaError(
                    f"{chain[-1]}() argument must be a variable name",
                    formula=formula,
                )
            response_name = var_name
            # chain is outermost-first; reverse to innermost-first for application
            response_transform = tuple(reversed(chain))
        else:
            response_name = extract_name(ast.left)
        rhs_terms, re_terms, has_intercept = extract_rhs_terms(ast.right)
    else:
        rhs_terms, re_terms, has_intercept = extract_rhs_terms(ast)

    # Detect categoricals from formula and data
    detected_cats = detect_categoricals(ast, data)
    # Merge with user-provided factors (user takes precedence)
    merged_factors = {**detected_cats, **user_factors}

    # Ensure categorical columns are Enum type
    # Note: we don't mutate the caller's data — ensure_enum returns a new df.
    # The data with Enum types will be passed to build_design_matrices separately.

    return FormulaSpec(
        formula=formula,
        response_var=response_name,
        response_transform=response_transform,
        has_intercept=has_intercept,
        rhs_terms=tuple(rhs_terms),
        re_terms=tuple(re_terms),
        factors=merged_factors,
        custom_contrasts=user_contrasts,
        uncorr_metadata=uncorr_metadata,
        nested_metadata=nested_metadata,
    )


def extract_rhs_terms(
    node: object,
) -> tuple[list[object], list[object], bool]:
    """Extract terms from RHS of formula, handling + and - operators.

    Random effect terms (containing PIPE operator) are collected separately.

    Args:
        node: AST node representing the RHS.

    Returns:
        (fixed_terms, random_terms, has_intercept).
    """
    rhs_terms: list[object] = []
    re_terms: list[object] = []
    has_intercept = True

    def _walk(node: object) -> None:
        nonlocal has_intercept

        if isinstance(node, Binary):
            if node.operator.kind == "PLUS":
                _walk(node.left)
                _walk(node.right)
            elif node.operator.kind == "MINUS":
                _walk(node.left)
                right_name = extract_name(node.right)
                if right_name == "1":
                    has_intercept = False
            elif node.operator.kind == "PIPE":
                re_terms.append(node)
            else:
                rhs_terms.append(node)
        elif isinstance(node, Unary):
            if node.operator.kind == "MINUS":
                right_name = extract_name(node.right)
                if right_name in ("0", "1"):
                    has_intercept = False
            elif node.operator.kind == "PLUS":
                _walk(node.right)
        elif isinstance(node, Literal):
            if node.value in (0, 1, "0", "1"):
                if node.value in (0, "0"):
                    has_intercept = False
            else:
                rhs_terms.append(node)
        elif isinstance(node, Grouping):
            if contains_pipe(node.expression):
                _walk(node.expression)
            else:
                _walk(node.expression)
        else:
            rhs_terms.append(node)

    _walk(node)
    return rhs_terms, re_terms, has_intercept


@frozen
class FormulaStructure:
    """Data-free formula structure extracted from an AST.

    Contains the same structural information as a full ``parse_formula()``
    call but without requiring data for categorical detection.  Used by
    ``build_model_spec_from_formula()`` to replace regex-based extraction.

    Attributes:
        response_var: Response variable name, or None for RHS-only formulas.
        response_transform: Tuple of LHS transforms (innermost-first),
            or None if no transforms.
        fixed_term_names: Human-readable fixed-effect term names
            (e.g. ``["Intercept", "x", "group"]``).
        has_intercept: Whether the formula includes an intercept.
        has_random_effects: Whether the formula contains ``|`` terms.
        random_terms_raw: Raw string representations of RE terms
            (e.g. ``["(1|subject)"]``).
    """

    response_var: str | None
    response_transform: tuple[str, ...] | None
    fixed_term_names: tuple[str, ...]
    has_intercept: bool
    has_random_effects: bool
    random_terms_raw: tuple[str, ...]


def extract_formula_structure(formula: str) -> FormulaStructure:
    """Extract formula structure from a formula string without data.

    Parses the formula into an AST and walks it to extract response
    variable, fixed-effect term names, intercept presence, and
    random-effect term strings.  Does not require data (no categorical
    detection).

    Args:
        formula: R-style formula string (e.g. ``"y ~ x + (1|group)"``).

    Returns:
        FormulaStructure with extracted information.

    Raises:
        FormulaError: If formula syntax is invalid.
    """
    # Known transforms that can appear on the LHS
    _KNOWN_RESPONSE_TRANSFORMS = set(STATEFUL_TRANSFORMS) | {"log", "log10", "sqrt"}

    # Pre-process: expand || and / syntax
    expanded, _ = expand_double_verts(formula)
    expanded, _ = expand_nested_syntax(expanded)

    # Tokenize and parse
    tokens = Scanner(expanded).scan(add_intercept=False)
    ast = Parser(tokens, expanded).parse()

    response_var: str | None = None
    response_transform: tuple[str, ...] | None = None

    if isinstance(ast, Binary) and ast.operator.kind == "TILDE":
        # Extract response from LHS
        if isinstance(ast.left, Call) and isinstance(ast.left.callee, Variable):
            chain: list[str] = []
            node = ast.left
            while isinstance(node, Call) and isinstance(node.callee, Variable):
                func_name = node.callee.name.lexeme
                if func_name not in _KNOWN_RESPONSE_TRANSFORMS:
                    raise FormulaError(
                        f"Unknown response transform '{func_name}'. "
                        f"Supported: {sorted(_KNOWN_RESPONSE_TRANSFORMS)}",
                        formula=formula,
                    )
                if not node.args:
                    raise FormulaError(
                        f"{func_name}() requires an argument",
                        formula=formula,
                    )
                chain.append(func_name)
                node = node.args[0]
            var_name = extract_name(node)
            if var_name is None:
                raise FormulaError(
                    f"{chain[-1]}() argument must be a variable name",
                    formula=formula,
                )
            response_var = var_name
            response_transform = tuple(reversed(chain))
        else:
            response_var = extract_name(ast.left)
        rhs_terms, re_terms, has_intercept = extract_rhs_terms(ast.right)
    else:
        rhs_terms, re_terms, has_intercept = extract_rhs_terms(ast)

    # Extract human-readable fixed term names from AST nodes
    fixed_names: list[str] = []
    if has_intercept:
        fixed_names.append("Intercept")
    for term in rhs_terms:
        name = extract_name(term)
        # For Call nodes like factor(x), extract the argument name
        if name is None and isinstance(term, Call) and term.args:
            name = extract_name(term.args[0])
        if name is not None and name not in ("0", "1", "-1"):
            fixed_names.append(name)

    # Extract RE term strings from the original expanded formula
    re_pattern = r"\([^)]*\|[^)]*\)"
    _, expanded_rhs = expanded.split("~", 1) if "~" in expanded else ("", expanded)
    random_terms_raw = tuple(re.findall(re_pattern, expanded_rhs))

    if not fixed_names:
        fixed_names = ["Intercept"]

    return FormulaStructure(
        response_var=response_var,
        response_transform=response_transform,
        fixed_term_names=tuple(fixed_names),
        has_intercept=has_intercept,
        has_random_effects=len(re_terms) > 0,
        random_terms_raw=random_terms_raw,
    )


# =============================================================================
# Formula pre-processing (|| and / syntax expansion)
# =============================================================================


def parse_random_effects_spec(spec: str) -> list[str]:
    """Parse random effects specification like '1 + x + y' into ['1', 'x', 'y'].

    Args:
        spec: Random effects specification from left side of | or ||.

    Returns:
        List of term strings.

    Examples:
        >>> parse_random_effects_spec("1 + x + y")
        ['1', 'x', 'y']
        >>> parse_random_effects_spec("Days")
        ['Days']
        >>> parse_random_effects_spec("0 + x")
        ['0', 'x']
    """
    if not spec or spec.strip() == "":
        return ["1"]

    spec = spec.strip()

    # Handle special case of just "1"
    if spec == "1":
        return ["1"]

    # Split by + but preserve the terms
    # Use regex to split on + but not within parentheses
    terms = [t.strip() for t in re.split(r"\s*\+\s*", spec)]

    # Filter out empty strings
    return [t for t in terms if t]


def expand_double_verts(formula: str) -> tuple[str, dict]:
    """Expand || syntax into separate uncorrelated random effects terms.

    This matches lme4's expandDoubleVerts() function. The || syntax creates
    independent (uncorrelated) random effects by expanding to separate terms.

    Args:
        formula: R-style formula string potentially containing || syntax.

    Returns:
        A tuple of:
            - Expanded formula string with || replaced by separate | terms
            - Metadata dict tracking which terms came from || expansion

    Examples:
        >>> expand_double_verts("y ~ x + (Days || Subject)")
        ('y ~ x + (1 | Subject) + (0 + Days | Subject)', {...})

        >>> expand_double_verts("y ~ x + (1 + x + y || group)")
        ('y ~ x + (1 | group) + (0 + x | group) + (0 + y | group)', {...})

    Note:
        The transformation rules are:
        - (x || g) -> (1 | g) + (0 + x | g)
        - (1 + x || g) -> (1 | g) + (0 + x | g)
        - (1 + x + y || g) -> (1 | g) + (0 + x | g) + (0 + y | g)
        - (0 + x || g) -> (0 + x | g)  [no intercept term added]
    """
    metadata = {}

    # Find all || terms using regex
    double_bar_pattern = r"\(([^)]*)\|\|([^)]*)\)"
    matches = list(re.finditer(double_bar_pattern, formula))

    if not matches:
        return formula, metadata

    # Process each || term from right to left to preserve string positions
    for match in reversed(matches):
        full_match = match.group(0)
        lhs = match.group(1).strip()  # Left side: random effects spec
        rhs = match.group(2).strip()  # Right side: grouping factor

        # Parse LHS to extract individual terms
        terms = parse_random_effects_spec(lhs)

        # Build separate terms for each random effect
        expanded_terms = []
        has_zero = False

        # Check if intercept is explicitly excluded
        for term in terms:
            if term in ["0", "-1"]:
                has_zero = True

        # Add intercept term unless explicitly excluded
        if not has_zero:
            expanded_terms.append(f"(1 | {rhs})")

        # Add slope terms with 0 + to exclude their own intercepts
        for term in terms:
            if term not in ["1", "0", "-1"]:
                expanded_terms.append(f"(0 + {term} | {rhs})")

        # Replace the || term with expanded terms joined by +
        replacement = " + ".join(expanded_terms)
        formula = formula[: match.start()] + replacement + formula[match.end() :]

        # Track metadata for this expansion
        metadata[rhs] = {
            "original": full_match,
            "terms": expanded_terms,
            "is_uncorrelated": True,
        }

    return formula, metadata


def expand_nested_syntax(formula: str) -> tuple[str, dict]:
    """Expand nested / syntax into separate crossed random effects terms.

    This matches lme4's behavior where nested syntax (a/b) is syntactic sugar
    for separate terms: (1|a/b) expands to (1|a) + (1|a:b).

    The : in the grouping factor creates an interaction grouping where each
    unique combination of levels becomes a separate group.

    Args:
        formula: R-style formula string potentially containing / in RE terms.

    Returns:
        A tuple of:
            - Expanded formula string with / replaced by separate terms
            - Metadata dict tracking which terms came from / expansion

    Examples:
        >>> expand_nested_syntax("y ~ x + (1|school/class)")
        ('y ~ x + (1|school) + (1|school:class)', {...})

        >>> expand_nested_syntax("y ~ x + (1|a/b/c)")
        ('y ~ x + (1|a) + (1|a:b) + (1|a:b:c)', {...})

        >>> expand_nested_syntax("y ~ x + (Days|Subject/Session)")
        ('y ~ x + (Days|Subject) + (Days|Subject:Session)', {...})

    Note:
        The transformation rules are:
        - (1|a/b) -> (1|a) + (1|a:b)
        - (1|a/b/c) -> (1|a) + (1|a:b) + (1|a:b:c)
        - (x|a/b) -> (x|a) + (x|a:b)
        - (1 + x|a/b) -> (1 + x|a) + (1 + x|a:b)
    """
    metadata: dict = {}

    # Find all RE terms: (something | grouping)
    # Need to match terms where the grouping factor contains /
    # Pattern: ( lhs | rhs ) where rhs contains /
    re_term_pattern = r"\(([^|)]+)\|([^)]+)\)"
    matches = list(re.finditer(re_term_pattern, formula))

    if not matches:
        return formula, metadata

    # Process each RE term from right to left to preserve string positions
    for match in reversed(matches):
        full_match = match.group(0)
        lhs = match.group(1).strip()  # Left side: random effects spec
        rhs = match.group(2).strip()  # Right side: grouping factor(s)

        # Check if RHS contains nested syntax (/)
        if "/" not in rhs:
            continue

        # Parse the nested levels: a/b/c -> ["a", "b", "c"]
        nested_levels = [level.strip() for level in rhs.split("/")]

        # Build cumulative interaction terms
        # a/b/c -> [a, a:b, a:b:c]
        expanded_terms = []
        cumulative_group = ""

        for level in nested_levels:
            if cumulative_group:
                cumulative_group = f"{cumulative_group}:{level}"
            else:
                cumulative_group = level
            expanded_terms.append(f"({lhs}|{cumulative_group})")

        # Replace the nested term with expanded terms joined by +
        replacement = " + ".join(expanded_terms)
        formula = formula[: match.start()] + replacement + formula[match.end() :]

        # Track metadata for this expansion
        metadata[rhs] = {
            "original": full_match,
            "nested_levels": nested_levels,
            "expanded_groups": [
                ":".join(nested_levels[: i + 1]) for i in range(len(nested_levels))
            ],
            "terms": expanded_terms,
        }

    return formula, metadata
