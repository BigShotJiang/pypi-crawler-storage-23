"""REML-to-ML refit helper for mixed model comparison.

Provides ``refit_with_ml()`` which creates a new model fitted with ML
estimation when the original uses REML, enabling valid likelihood ratio tests.
"""

from typing import Any

from bossanova.internal.compare.helpers import get_model_type

__all__ = [
    "refit_with_ml",
]


def refit_with_ml(model: Any) -> Any:
    """Refit a mixed model with ML estimation if it uses REML.

    Creates a new model instance and fits with method="ML". The original
    model is not mutated.

    Args:
        model: A fitted lmer or glmer model.

    Returns:
        If model uses REML: a new model fitted with ML.
        If model uses ML: the original model unchanged.
    """
    # Already ML - return unchanged
    if model._spec.method == "ml":
        return model

    # Get model type and refit with ML
    model_type = get_model_type(model)

    if model_type in ("lmer", "glmer"):
        from bossanova.model import model as model_cls

        new_model = model_cls(
            model.formula,
            model.data,
            family=model.family,
            link=model.link,
        )
        new_model.fit(method="ML")
        return new_model

    else:
        # Not a mixed model - return unchanged
        return model
