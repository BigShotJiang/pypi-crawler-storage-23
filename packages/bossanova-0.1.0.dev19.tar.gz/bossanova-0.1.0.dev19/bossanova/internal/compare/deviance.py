"""Deviance test implementation for comparing nested GLM models.

Performs sequential deviance tests matching R's
``anova(glm1, glm2, test="Chisq")`` behavior.
"""

from typing import Any

import polars as pl
from scipy import stats

from bossanova.internal.containers.schemas import (
    Col,
    ComparisonDevianceChi2,
    ComparisonDevianceF,
)
from bossanova.internal.compare.helpers import check_nested

__all__ = [
    "compare_deviance",
]


def _get_deviance(m: Any) -> float:
    """Extract residual deviance from a fitted model.

    Uses the true residual deviance from the IRLS solver (sum of unit
    deviances) when available, falling back to -2*loglik for models
    that don't store it. R's ``anova()`` reports residual deviance,
    not -2*loglik, so this matches R's behavior.

    Args:
        m: Fitted model instance.

    Returns:
        Residual deviance as a scalar.
    """
    if m._fit.deviance is not None:
        return float(m._fit.deviance)
    return -2.0 * float(m._fit.loglik)


def compare_deviance(models: list[Any], test: str = "chisq") -> pl.DataFrame:
    """Perform deviance tests for nested glm models.

    Computes deviance differences comparing each model to the previous (simpler)
    model in the sequence. This matches R's anova(glm1, glm2, test="Chisq").

    Args:
        models: List of fitted glm models, sorted by complexity (simplest first).
        test: Test type: "chisq" for chi-squared test (default), "f" for F-test.

    Returns:
        DataFrame with columns:
        - model: Formula string
        - df_resid: Residual degrees of freedom
        - deviance: Residual deviance
        - df: Degrees of freedom for this comparison
        - dev_diff: Deviance difference (reduction)
        - statistic: Chi-squared or F statistic
        - p_value: p-value from chi-squared or F distribution

    Notes:
        The deviance difference follows a chi-squared distribution with df degrees
        of freedom under the null hypothesis that the compact model is adequate.

        For quasi-families (where dispersion is estimated), the F-test is more
        appropriate and accounts for overdispersion.
    """
    n_models = len(models)

    # Extract dispersion from the most complex (final) model for F-test.
    # R uses the final-model dispersion for all comparisons, matching
    # the pattern in f_test.py where mse_final is used throughout.
    m_final = models[-1]
    dispersion_final = m_final._fit.dispersion
    df_resid_final = m_final._fit.df_resid

    # Initialize result lists
    formulas: list[str] = []
    df_resids: list[float] = []
    deviances: list[float] = []
    dfs: list[float | None] = []
    dev_diffs: list[float | None] = []
    statistics: list[float | None] = []
    p_values: list[float | None] = []

    # First model (baseline)
    m0 = models[0]
    formulas.append(m0.formula)
    df_resids.append(float(m0._fit.df_resid))
    deviances.append(_get_deviance(m0))
    dfs.append(None)
    dev_diffs.append(None)
    statistics.append(None)
    p_values.append(None)

    # Compare each model to previous
    for i in range(1, n_models):
        m_prev = models[i - 1]
        m_curr = models[i]

        dev_prev = _get_deviance(m_prev)
        dev_curr = _get_deviance(m_curr)

        df_prev = m_prev._fit.df_resid
        df_curr = m_curr._fit.df_resid

        # Degrees of freedom for this comparison
        df_diff = df_prev - df_curr

        # Deviance reduction
        dev_diff = dev_prev - dev_curr

        # Compute test statistic and p-value
        if test == "chisq":
            # Chi-squared test: deviance difference ~ chi2(df_diff)
            chi2_stat = dev_diff
            p_val = 1.0 - stats.chi2.cdf(chi2_stat, df_diff) if df_diff > 0 else 1.0
            stat = chi2_stat
        else:  # test == "f"
            # F-test: accounts for estimated dispersion from the final model.
            # R uses the most-complex model's dispersion for all comparisons.
            f_stat = (dev_diff / df_diff) / dispersion_final if df_diff > 0 else 0.0
            p_val = 1.0 - stats.f.cdf(f_stat, df_diff, df_resid_final)
            stat = f_stat

        formulas.append(m_curr.formula)
        df_resids.append(float(df_curr))
        deviances.append(float(dev_curr))
        dfs.append(float(df_diff))
        dev_diffs.append(float(dev_diff))
        statistics.append(float(stat))
        p_values.append(float(p_val))

    # Check for non-nested models
    check_nested(dfs, dev_diffs, formulas, method="deviance")

    # Build DataFrame - column name and schema depend on test type
    stat_col_name = Col.CHI2 if test == "chisq" else Col.F_STAT
    schema = ComparisonDevianceChi2 if test == "chisq" else ComparisonDevianceF

    return pl.DataFrame(
        {
            Col.MODEL: formulas,
            stat_col_name: statistics,
            Col.DEV_DIFF: dev_diffs,
            Col.DEVIANCE: deviances,
            Col.DF: dfs,
            Col.DF_RESID: df_resids,
            Col.P_VALUE: p_values,
        },
        schema=schema,
    )
