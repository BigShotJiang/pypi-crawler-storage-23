"""Information criterion comparison for model selection.

Computes AIC/BIC tables with delta-IC and Akaike/Schwarz weights,
following Burnham & Anderson (2002). Unlike hypothesis-test comparisons
(F-test, LRT, deviance), IC comparison does not require model nesting —
any set of models fitted to the same data can be compared.

Functions:
    compare_aic: Rank models by AIC with delta-AIC and Akaike weights.
    compare_bic: Rank models by BIC with delta-BIC and Schwarz weights.
"""

from __future__ import annotations

import math
from typing import Any

import polars as pl

from bossanova.internal.containers.schemas import (
    Col,
    ComparisonAic,
    ComparisonBic,
)
from bossanova.internal.maths.family import ESTIMATED_DISPERSION_FAMILIES
from bossanova.internal.maths.inference import compute_aic, compute_bic

__all__ = ["compare_aic", "compare_bic"]


def _get_n_params_ic(model: Any) -> int:
    """Get total number of estimated parameters for IC computation.

    Follows the same counting as ``compute_diagnostics()``:

    - ``rank`` (estimable fixed effects)
    - ``+ len(theta)`` for mixed models (variance parameters)
    - ``+ 1`` for families with estimated dispersion (e.g. Gaussian sigma)

    Args:
        model: A fitted model instance.

    Returns:
        Total parameter count for AIC/BIC computation.
    """
    k: int = model._bundle.rank
    if model._fit.theta is not None:
        k += len(model._fit.theta)
    if model._spec.family in ESTIMATED_DISPERSION_FAMILIES:
        k += 1
    return k


def compare_aic(models: list[Any]) -> pl.DataFrame:
    """Compare models by AIC with delta-AIC and Akaike weights.

    Models are sorted by AIC (best first). Delta-AIC is the difference
    from the best model. Akaike weights represent the relative likelihood
    of each model being the best, following Burnham & Anderson (2002):

        w_i = exp(-0.5 * delta_i) / sum(exp(-0.5 * delta_j))

    Args:
        models: List of fitted model objects (at least 2).

    Returns:
        DataFrame with columns: model, npar, loglik, deviance, AIC, BIC,
        delta_AIC, weight. Sorted by AIC ascending (best model first).
    """
    return _compare_ic(models, criterion="aic")


def compare_bic(models: list[Any]) -> pl.DataFrame:
    """Compare models by BIC with delta-BIC and Schwarz weights.

    Models are sorted by BIC (best first). Delta-BIC is the difference
    from the best model. Schwarz weights use the same formula as Akaike
    weights but applied to BIC differences.

    Args:
        models: List of fitted model objects (at least 2).

    Returns:
        DataFrame with columns: model, npar, loglik, deviance, AIC, BIC,
        delta_BIC, weight. Sorted by BIC ascending (best model first).
    """
    return _compare_ic(models, criterion="bic")


def _compare_ic(models: list[Any], *, criterion: str) -> pl.DataFrame:
    """Shared implementation for AIC/BIC comparison.

    Args:
        models: List of fitted models.
        criterion: ``"aic"`` or ``"bic"``.

    Returns:
        DataFrame sorted by the chosen criterion with delta-IC and weights.
    """
    formulas: list[str] = []
    npars: list[int] = []
    logliks: list[float] = []
    deviances: list[float] = []
    aics: list[float] = []
    bics: list[float] = []

    for m in models:
        k = _get_n_params_ic(m)
        loglik = float(m._fit.loglik)
        n = m._bundle.n

        formulas.append(m.formula)
        npars.append(k)
        logliks.append(loglik)
        deviances.append(-2.0 * loglik)
        aics.append(compute_aic(loglik, k))
        bics.append(compute_bic(loglik, k, n))

    # Select criterion and schema
    if criterion == "aic":
        ic_values = aics
        delta_col = Col.DELTA_AIC
        schema = ComparisonAic
    else:
        ic_values = bics
        delta_col = Col.DELTA_BIC
        schema = ComparisonBic

    # Sort all lists by IC value (ascending = best first)
    order = sorted(range(len(models)), key=lambda i: ic_values[i])
    formulas = [formulas[i] for i in order]
    npars = [npars[i] for i in order]
    logliks = [logliks[i] for i in order]
    deviances = [deviances[i] for i in order]
    aics = [aics[i] for i in order]
    bics = [bics[i] for i in order]
    ic_values = [ic_values[i] for i in order]

    # Delta-IC: difference from best model
    ic_min = ic_values[0]
    deltas = [v - ic_min for v in ic_values]

    # Akaike/Schwarz weights: exp(-0.5 * delta) / sum(exp(-0.5 * delta))
    raw_weights = [math.exp(-0.5 * d) for d in deltas]
    weight_sum = sum(raw_weights)
    weights = [w / weight_sum for w in raw_weights]

    return pl.DataFrame(
        {
            Col.MODEL: formulas,
            Col.NPAR: npars,
            Col.LOGLIK: logliks,
            Col.DEVIANCE: deviances,
            Col.AIC_R: aics,
            Col.BIC_R: bics,
            delta_col: deltas,
            Col.WEIGHT: weights,
        },
        schema=schema,
    )
