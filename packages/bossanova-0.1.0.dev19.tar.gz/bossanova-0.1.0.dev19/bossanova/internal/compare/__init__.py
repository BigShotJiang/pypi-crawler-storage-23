"""Model comparison: information criteria, likelihood ratio tests, and composite tables.

Call chain:
    bossanova.compare(m1, m2, ...) -> compare() (composite AIC/BIC/loglik table)
    bossanova.lrt(m1, m2) -> lrt() (nested model likelihood ratio test)
"""

from bossanova.internal.compare.compare import compare
from bossanova.internal.compare.ic import compare_aic, compare_bic
from bossanova.internal.compare.lrt import lrt

__all__ = ["compare", "compare_aic", "compare_bic", "lrt"]
