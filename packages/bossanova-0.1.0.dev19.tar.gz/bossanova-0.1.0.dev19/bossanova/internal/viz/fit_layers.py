"""Layer drawing helpers for fit plots.

Each function is a FacetGrid.map_dataframe callback that draws one visual
layer (scatter, line, CI band, strip, or error bars) onto the current axes.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
import polars as pl

from bossanova.internal.viz.fit_builders import filter_to_facet, get_predictions
from bossanova.internal.viz.helpers import detect_ci_columns, fill_ci_band

if TYPE_CHECKING:
    from bossanova.model.core import model as BaseModel

__all__ = [
    "add_ci_band",
    "add_errorbar_layer",
    "add_fit_line",
    "add_population_line",
    "add_scatter_layer",
    "add_strip_layer",
]


def add_scatter_layer(
    data: Any,  # DataFrame from FacetGrid
    *,
    x: str,
    y: str,
    hue: str | None,
    color_map: dict | None,
    markers: str | list[str],
    style: dict,
    scatter_kws: dict | None,
    **kwargs: Any,
) -> None:
    """Add scatter points for observed data to the current axes.

    Draws raw data points colored by hue level when provided. Used as
    a map_dataframe callback inside a FacetGrid to overlay observed
    values on prediction lines / CI bands.

    Args:
        data: DataFrame passed by FacetGrid.map_dataframe (one facet slice).
        x: Column name for x-axis values.
        y: Column name for y-axis values (the response).
        hue: Column name for color grouping, or None for single-color.
        color_map: Mapping from hue level to matplotlib color. Required
            when ``hue`` is not None.
        markers: Marker style string or list of styles.
        style: BOSSANOVA_STYLE dictionary for default aesthetics.
        scatter_kws: Additional keyword arguments forwarded to
            ``ax.scatter()``. Overrides defaults when provided.
        **kwargs: Extra kwargs passed by FacetGrid (ignored).
    """
    import matplotlib.pyplot as plt

    ax = plt.gca()

    # Default scatter kwargs
    kws: dict[str, Any] = {
        "alpha": 0.6,
        "edgecolor": style["point_edgecolor"],
        "linewidth": style["point_linewidth"],
        "s": style["point_size"],
        "marker": markers if isinstance(markers, str) else markers[0],
        "zorder": 2,
    }
    if scatter_kws:
        kws.update(scatter_kws)

    x_vals = np.asarray(data[x])
    y_vals = np.asarray(data[y])

    if hue is None or color_map is None:
        ax.scatter(x_vals, y_vals, **kws)
    else:
        hue_vals = np.asarray(data[hue])
        for level, color in color_map.items():
            mask = hue_vals == level
            if np.any(mask):
                ax.scatter(x_vals[mask], y_vals[mask], color=color, **kws)


def add_fit_line(
    data: Any,  # DataFrame from FacetGrid (observed data, not used directly)
    *,
    pred_df: pl.DataFrame,
    x: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    color_map: dict | None,
    style: dict,
    line_kws: dict | None,
    **kwargs: Any,
) -> None:
    """Add model prediction line to the current axes.

    Draws the fitted prediction curve (population or BLUP) using
    pre-computed predictions in ``pred_df``. The predictions are
    filtered to the current facet and sorted along the x-axis before
    plotting.

    Args:
        data: DataFrame passed by FacetGrid.map_dataframe (unused; the
            prediction data comes from ``pred_df``).
        pred_df: Polars DataFrame with prediction grid including an
            ``x`` column and a ``fitted`` column.
        x: Column name for x-axis values in ``pred_df``.
        hue: Column name for color grouping, or None.
        col: Column name used for column faceting (for facet filtering).
        row: Column name used for row faceting (for facet filtering).
        color_map: Mapping from hue level to matplotlib color. Required
            when ``hue`` is not None.
        style: BOSSANOVA_STYLE dictionary for default aesthetics.
        line_kws: Additional keyword arguments forwarded to
            ``ax.plot()``. Overrides defaults when provided.
        **kwargs: Extra kwargs passed by FacetGrid (ignored).
    """
    import matplotlib.pyplot as plt

    ax = plt.gca()

    # Default line kwargs
    kws: dict[str, Any] = {
        "linewidth": style["line_width"],
        "zorder": 3,
    }
    if line_kws:
        kws.update(line_kws)

    # Filter predictions to match current facet
    filtered = filter_to_facet(pred_df, ax, col, row)

    if hue is None or color_map is None:
        x_vals = np.asarray(filtered[x])
        y_vals = np.asarray(filtered["fitted"])
        sort_idx = np.argsort(x_vals)
        ax.plot(x_vals[sort_idx], y_vals[sort_idx], **kws)
    else:
        hue_vals = np.asarray(filtered[hue])
        for level, color in color_map.items():
            mask = hue_vals == level
            if np.any(mask):
                x_subset = np.asarray(filtered[x])[mask]
                y_subset = np.asarray(filtered["fitted"])[mask]
                sort_idx = np.argsort(x_subset)
                ax.plot(x_subset[sort_idx], y_subset[sort_idx], color=color, **kws)


def add_ci_band(
    data: Any,  # DataFrame from FacetGrid (not used)
    *,
    pred_df: pl.DataFrame,
    x: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    color_map: dict | None,
    style: dict,
    ci_kws: dict | None,
    **kwargs: Any,
) -> None:
    """Add confidence interval band around prediction line.

    Draws a semi-transparent shaded region between the lower and upper
    confidence bounds in ``pred_df``. Supports both ``lwr``/``upr``
    (legacy) and ``ci_lower``/``ci_upper`` column naming conventions.

    Delegates rendering to :func:`~bossanova.internal.viz.helpers.fill_ci_band`.

    Args:
        data: DataFrame passed by FacetGrid.map_dataframe (unused; the
            interval data comes from ``pred_df``).
        pred_df: Polars DataFrame with prediction grid including CI
            bound columns (``lwr``/``upr`` or ``ci_lower``/``ci_upper``).
        x: Column name for x-axis values in ``pred_df``.
        hue: Column name for color grouping, or None.
        col: Column name used for column faceting (for facet filtering).
        row: Column name used for row faceting (for facet filtering).
        color_map: Mapping from hue level to matplotlib color. Required
            when ``hue`` is not None.
        style: BOSSANOVA_STYLE dictionary for default aesthetics.
        ci_kws: Additional keyword arguments forwarded to
            ``ax.fill_between()``. Overrides defaults when provided.
        **kwargs: Extra kwargs passed by FacetGrid (ignored).
    """
    import matplotlib.pyplot as plt

    ci_cols = detect_ci_columns(pred_df.columns)
    if ci_cols is None:
        return
    lower_col, upper_col = ci_cols

    ax = plt.gca()

    # Build fill kwargs from style + overrides
    kws: dict[str, Any] = {"alpha": style["ci_alpha"], "zorder": 1}
    if ci_kws:
        kws.update(ci_kws)

    # Filter predictions to match current facet
    filtered = filter_to_facet(pred_df, ax, col, row)

    fill_ci_band(
        ax=ax,
        x=np.asarray(filtered[x]),
        lower=np.asarray(filtered[lower_col]),
        upper=np.asarray(filtered[upper_col]),
        hue_values=np.asarray(filtered[hue]) if hue is not None else None,
        colors=color_map,
        fill_kws=kws,
    )


def add_population_line(
    data: Any,  # DataFrame from FacetGrid (not used directly)
    *,
    model: "BaseModel",
    pop_grid: pl.DataFrame,
    x: str,
    col: str | None,
    row: str | None,
    style: dict,
    population_kws: dict | None,
    **kwargs: Any,
) -> None:
    """Add dashed population-level prediction line.

    This draws a single line representing the population-level (fixed effects
    only) prediction, as a reference when showing subject-specific BLUP lines.

    Args:
        data: DataFrame passed by FacetGrid.map_dataframe (unused).
        model: The fitted model (used to compute population predictions).
        pop_grid: Prediction grid for population-level predictions.
        x: Column name for x-axis values.
        col: Column facet variable name (for facet filtering).
        row: Row facet variable name (for facet filtering).
        style: BOSSANOVA_STYLE dictionary for default aesthetics.
        population_kws: Additional keyword arguments for the population
            line (e.g. color, alpha). Overrides defaults when provided.
        **kwargs: Extra kwargs passed by FacetGrid (ignored).
    """
    import matplotlib.pyplot as plt

    ax = plt.gca()

    # Get population predictions
    pop_preds = get_predictions(model, pop_grid, ci=None, blup_mode=False)

    # Filter to current facet (for row faceting with non-grouping factors)
    filtered = filter_to_facet(pop_preds, ax, col, row)

    # Default style for population line
    default_kws: dict[str, Any] = {
        "linestyle": "--",
        "linewidth": style["line_width"] + 0.5,
        "alpha": 0.8,
        "color": "gray",
        "zorder": 2.5,
    }
    if population_kws:
        default_kws.update(population_kws)

    x_vals = np.asarray(filtered[x])
    y_vals = np.asarray(filtered["fitted"])
    sort_idx = np.argsort(x_vals)

    ax.plot(x_vals[sort_idx], y_vals[sort_idx], **default_kws)


def add_strip_layer(
    data: Any,  # DataFrame from FacetGrid
    *,
    x: str,
    y: str,
    hue: str | None,
    x_positions: dict,
    color_map: dict | None,
    hue_order: list | None,
    dodge: float,
    style: dict,
    scatter_kws: dict | None,
    **kwargs: Any,
) -> None:
    """Add jittered strip plot layer for categorical x-axis data.

    Converts categorical x values to numeric positions and adds random
    jitter so individual observations are visible. When ``hue`` is
    provided, observations are dodge-shifted by hue level to avoid
    overlap.

    Args:
        data: DataFrame passed by FacetGrid.map_dataframe (one facet slice).
        x: Column name for the categorical x-axis variable.
        y: Column name for y-axis values (the response).
        hue: Column name for color grouping, or None.
        x_positions: Mapping from category label to integer position.
        color_map: Mapping from hue level to matplotlib color.
        hue_order: Ordered list of hue levels for consistent dodge offsets.
        dodge: Horizontal offset between hue levels (in position units).
        style: BOSSANOVA_STYLE dictionary for default aesthetics.
        scatter_kws: Additional keyword arguments forwarded to
            ``ax.scatter()``. Overrides defaults when provided.
        **kwargs: Extra kwargs passed by FacetGrid (ignored).
    """
    import matplotlib.pyplot as plt

    ax = plt.gca()

    # Default strip kwargs
    kws: dict[str, Any] = {
        "alpha": 0.4,
        "s": style["point_size"] * 0.5,
        "zorder": 1,
    }
    if scatter_kws:
        kws.update(scatter_kws)

    x_vals_cat = np.asarray(data[x])
    y_vals = np.asarray(data[y])

    # Convert categories to numeric positions with jitter
    jitter = 0.1
    rng = np.random.default_rng(42)

    if hue is None or color_map is None:
        x_numeric = np.array([x_positions.get(v, 0) for v in x_vals_cat])
        x_jittered = x_numeric + rng.uniform(-jitter, jitter, len(x_numeric))
        ax.scatter(x_jittered, y_vals, **kws)
    else:
        hue_vals = np.asarray(data[hue])
        n_hue = len(hue_order)
        for i, (level, color) in enumerate(color_map.items()):
            mask = hue_vals == level
            if np.any(mask):
                x_numeric = np.array([x_positions.get(v, 0) for v in x_vals_cat[mask]])
                # Dodge by hue level
                hue_offset = (i - (n_hue - 1) / 2) * dodge
                x_jittered = (
                    x_numeric
                    + hue_offset
                    + rng.uniform(-jitter / 2, jitter / 2, len(x_numeric))
                )
                ax.scatter(x_jittered, y_vals[mask], color=color, **kws)


def add_errorbar_layer(
    data: Any,  # DataFrame from FacetGrid (not used)
    *,
    pred_df: pl.DataFrame,
    x: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    x_positions: dict,
    color_map: dict | None,
    hue_order: list | None,
    dodge: float,
    style: dict,
    ci_kws: dict | None,
    **kwargs: Any,
) -> None:
    """Add point estimates with error bars for categorical predictors.

    Draws predicted means as markers with optional confidence interval
    whiskers at each category position. When ``hue`` is provided, points
    are dodge-shifted to match the strip layer alignment.

    Args:
        data: DataFrame passed by FacetGrid.map_dataframe (unused; the
            prediction data comes from ``pred_df``).
        pred_df: Polars DataFrame with prediction grid including a
            ``fitted`` column and optional CI bound columns.
        x: Column name for the categorical x-axis variable.
        hue: Column name for color grouping, or None.
        col: Column name used for column faceting (for facet filtering).
        row: Column name used for row faceting (for facet filtering).
        x_positions: Mapping from category label to integer position.
        color_map: Mapping from hue level to matplotlib color.
        hue_order: Ordered list of hue levels for consistent dodge offsets.
        dodge: Horizontal offset between hue levels (in position units).
        style: BOSSANOVA_STYLE dictionary for default aesthetics.
        ci_kws: Additional keyword arguments forwarded to
            ``ax.errorbar()``. Overrides defaults when provided.
        **kwargs: Extra kwargs passed by FacetGrid (ignored).
    """
    import matplotlib.pyplot as plt

    ax = plt.gca()

    # Default errorbar kwargs
    kws: dict[str, Any] = {
        "fmt": "o",
        "markersize": 8,
        "capsize": style["capsize"],
        "linewidth": style["line_width"],
        "zorder": 3,
    }
    if ci_kws:
        kws.update(ci_kws)

    # Determine column names for CI bounds (prefer ci_lower/ci_upper)
    lower_col = "ci_lower" if "ci_lower" in pred_df.columns else "lwr"
    upper_col = "ci_upper" if "ci_upper" in pred_df.columns else "upr"
    has_ci = lower_col in pred_df.columns

    # Filter predictions to match current facet
    filtered = filter_to_facet(pred_df, ax, col, row)

    if hue is None or color_map is None:
        for cat in x_positions:
            cat_mask = np.asarray(filtered[x]) == cat
            if np.any(cat_mask):
                y_pred = np.asarray(filtered["fitted"])[cat_mask][0]
                x_pos = x_positions[cat]

                if has_ci:
                    lower = np.asarray(filtered[lower_col])[cat_mask][0]
                    upper = np.asarray(filtered[upper_col])[cat_mask][0]
                    yerr = [[y_pred - lower], [upper - y_pred]]
                    ax.errorbar(x_pos, y_pred, yerr=yerr, **kws)
                else:
                    ax.plot(x_pos, y_pred, "o", markersize=8, zorder=3)
    else:
        n_hue = len(hue_order)
        for i, (level, color) in enumerate(color_map.items()):
            hue_offset = (i - (n_hue - 1) / 2) * dodge

            for cat in x_positions:
                hue_col = np.asarray(filtered[hue])
                x_col = np.asarray(filtered[x])
                mask = (hue_col == level) & (x_col == cat)

                if np.any(mask):
                    y_pred = np.asarray(filtered["fitted"])[mask][0]
                    x_pos = x_positions[cat] + hue_offset

                    if has_ci:
                        lower = np.asarray(filtered[lower_col])[mask][0]
                        upper = np.asarray(filtered[upper_col])[mask][0]
                        yerr = [[y_pred - lower], [upper - y_pred]]
                        ax.errorbar(x_pos, y_pred, yerr=yerr, color=color, **kws)
                    else:
                        ax.plot(x_pos, y_pred, "o", markersize=8, color=color, zorder=3)
