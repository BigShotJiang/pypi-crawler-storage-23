"""Unified fit plot for bossanova models.

This module provides plot_fit() for visualizing model fit with data overlay:
- Continuous x: Scatter + prediction line + CI band (lmplot-style)
- Categorical x: Strip plot + point estimates + error bars (emmeans-style)

Implementation is split across sub-modules:
- fit_builders: data preparation (prediction grids, plot data)
- fit_layers: FacetGrid.map_dataframe layer callbacks
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import polars as pl

from bossanova.internal.viz.core import (
    BOSSANOVA_STYLE,
    build_facetgrid_kwargs,
    finalize_facetgrid,
    get_model_response,
    is_categorical,
    format_display_label,
)
from bossanova.internal.viz.fit_builders import (
    build_plot_data,
    build_prediction_grid,
    get_predictions,
    warn_many_groups,
)
from bossanova.internal.viz.fit_layers import (
    add_ci_band,
    add_errorbar_layer,
    add_fit_line,
    add_population_line,
    add_scatter_layer,
    add_strip_layer,
)
from bossanova.internal.viz.helpers import detect_blup_mode, get_grouping_factors

if TYPE_CHECKING:
    from typing import Any

    import seaborn as sns

    from bossanova.model.core import model as BaseModel

__all__ = ["plot_fit"]


def plot_fit(
    model: "Any",
    x: str,
    *,
    hue: str | None = None,
    col: str | None = None,
    row: str | None = None,
    col_wrap: int | None = None,
    scatter: bool = True,
    fit_line: bool = True,
    ci: int | None = 95,
    n_points: int = 100,
    prettify: bool = False,
    height: float = 5.0,
    aspect: float = 1.0,
    palette: str | None = None,
    markers: str | list[str] = "o",
    scatter_kws: dict | None = None,
    line_kws: dict | None = None,
    ci_kws: dict | None = None,
    dodge: float = 0.2,
    # BLUP visualization parameters
    blups: bool | None = None,
    groups: list[str] | int | None = None,
    population_line: bool = True,
    blup_kws: dict | None = None,
    population_kws: dict | None = None,
) -> "sns.FacetGrid":
    """Plot model fit overlaid on data.

    Auto-adapts based on predictor type:
    - **Continuous x**: Scatter + prediction line + CI band (lmplot-style)
    - **Categorical x**: Strip plot + point estimates + error bars

    For mixed models, when `hue`, `col`, or `row` is a grouping factor
    (e.g., Subject), the plot automatically shows subject-specific BLUP lines
    instead of the same population line in each facet.

    This answers: "How does the model fit the data across the predictor range?"

    Args:
        model: A fitted bossanova model.
        x: The predictor variable for the x-axis.
        hue: Column name for color encoding. Each hue level gets its own
            prediction line/points.
        col: Column name for faceting into columns.
        row: Column name for faceting into rows.
        col_wrap: Wrap column facets after this many. Ignored if row is set.
        scatter: Show data points (scatter for continuous, strip for categorical).
        fit_line: Show prediction line/points. Set False for data-only plot.
        ci: Confidence level for prediction intervals (e.g., 95 for 95% CI).
            Set to None to hide intervals. Note: Mixed models don't yet
            support prediction intervals - line shows without band.
        n_points: Number of points for continuous predictor prediction line.
        prettify: Convert axis labels to human-readable format (e.g.,
            "wt_hp_ratio" -> "Wt Hp Ratio"). Default False.
        height: Height of each facet in inches.
        aspect: Aspect ratio of each facet (width = height * aspect).
        palette: Color palette name (default: BOSSANOVA_STYLE palette).
        markers: Marker style(s) for scatter points.
        scatter_kws: Additional kwargs for scatter/strip plot.
        line_kws: Additional kwargs for prediction line.
        ci_kws: Additional kwargs for CI band/error bars.
        dodge: Dodge amount for categorical x with hue.
        blups: BLUP visualization mode. None (default) auto-detects: if any of
            hue/col/row is a grouping factor in a mixed model, BLUPs are shown.
            True forces BLUP lines; False forces population-level only.
        groups: Subset of group levels to show. Can be a list of specific levels
            (e.g., ["308", "309"]) or an int for random sample (e.g., 5 for 5
            random subjects). Useful when there are many groups.
        population_line: When in BLUP mode, show a dashed population-level
            reference line behind the BLUP lines. Default True.
        blup_kws: Additional kwargs for BLUP lines (merged with line_kws).
        population_kws: Additional kwargs for population line (e.g., color, alpha).

    Returns:
        Seaborn FacetGrid containing the plot.

    Raises:
        RuntimeError: If model is not fitted.
        ValueError: If x is not found in data columns.

    Examples:
        ::

            from bossanova import model, viz, load_dataset
            mtcars = load_dataset("mtcars")

            # Continuous x: scatter + prediction line + CI band
            m = model("mpg ~ wt + hp", mtcars).fit()
            viz.plot_fit(m, "wt")

            # Categorical x: strip + point estimates + error bars
            m = model("mpg ~ factor(cyl) + hp", mtcars).fit()
            viz.plot_fit(m, "cyl")

            # With hue: separate prediction lines per group
            m = model("mpg ~ wt * factor(cyl)", mtcars).fit()
            viz.plot_fit(m, "wt", hue="cyl")

            # Mixed model: BLUP lines by Subject (auto-detected)
            sleep = load_dataset("sleepstudy")
            m = model("Reaction ~ Days + (Days|Subject)", sleep).fit()
            viz.plot_fit(m, "Days", col="Subject", col_wrap=6)

    See Also:
        plot_predict: Marginal predictions without data overlay.
        plot_resid: Residual diagnostics.
    """

    if not model._is_fitted:
        raise RuntimeError("Model must be fitted before plotting")

    data = model.data

    # Validate x column exists
    if x not in data.columns:
        raise ValueError(f"Column '{x}' not found in data. Available: {data.columns}")

    style = BOSSANOVA_STYLE
    if palette is None:
        palette = style["palette"]

    # Determine predictor type
    x_is_categorical = is_categorical(data, x)

    # Detect BLUP mode for mixed models
    blup_mode = detect_blup_mode(model, hue=hue, col=col, row=row, blups=blups)

    # Warn if too many groups (only when BLUP mode is active)
    if blup_mode and groups is None:
        grouping_factors = set(get_grouping_factors(model))
        for var in (hue, col, row):
            if var and var in grouping_factors:
                warn_many_groups(data, var)

    # Build prediction grid
    pred_grid = build_prediction_grid(
        model=model,
        x=x,
        hue=hue,
        col=col,
        row=row,
        n_points=n_points,
        x_is_categorical=x_is_categorical,
        blup_mode=blup_mode,
        groups=groups,
    )

    # Get predictions with optional CI
    pred_df = get_predictions(model, pred_grid, ci=ci, blup_mode=blup_mode)

    # Build population grid for population line overlay (without grouping factors)
    pop_grid = None
    if blup_mode and population_line:
        pop_grid = build_prediction_grid(
            model=model,
            x=x,
            hue=None,  # Don't vary hue for population line
            col=col if col not in set(get_grouping_factors(model)) else None,
            row=row if row not in set(get_grouping_factors(model)) else None,
            n_points=n_points,
            x_is_categorical=x_is_categorical,
            blup_mode=False,  # Population level
            groups=None,
        )

    # Build plot data with observed values
    plot_df = build_plot_data(model, x=x, hue=hue, col=col, row=row)

    # Filter plot data to match groups subset (when groups is specified)
    if blup_mode and groups is not None:
        grouping_factors = set(get_grouping_factors(model))
        for var in (hue, col, row):
            if var and var in grouping_factors and var in plot_df.columns:
                # Get the levels from the prediction grid
                filtered_levels = pred_df[var].unique().to_list()
                plot_df = plot_df.filter(pl.col(var).is_in(filtered_levels))

    # Route to appropriate plotting function
    if x_is_categorical:
        g = _plot_categorical(
            plot_df=plot_df,
            pred_df=pred_df,
            x=x,
            hue=hue,
            col=col,
            row=row,
            col_wrap=col_wrap,
            scatter=scatter,
            fit_line=fit_line,
            height=height,
            aspect=aspect,
            palette=palette,
            style=style,
            scatter_kws=scatter_kws,
            ci_kws=ci_kws,
            dodge=dodge,
        )
    else:
        # Merge blup_kws with line_kws for BLUP lines
        effective_line_kws = line_kws.copy() if line_kws else {}
        if blup_mode and blup_kws:
            effective_line_kws.update(blup_kws)

        g = _plot_continuous(
            plot_df=plot_df,
            pred_df=pred_df,
            x=x,
            hue=hue,
            col=col,
            row=row,
            col_wrap=col_wrap,
            scatter=scatter,
            fit_line=fit_line,
            height=height,
            aspect=aspect,
            palette=palette,
            markers=markers,
            style=style,
            scatter_kws=scatter_kws,
            line_kws=effective_line_kws,
            ci_kws=ci_kws,
            # BLUP mode parameters
            blup_mode=blup_mode,
            population_line=population_line,
            model=model,
            pop_grid=pop_grid,
            population_kws=population_kws,
        )

    # Apply labels (optionally prettified)
    y_label = get_model_response(model)
    x_label = format_display_label(x) if prettify else x
    y_label = format_display_label(y_label) if prettify else y_label
    finalize_facetgrid(g, xlabel=x_label, ylabel=y_label)

    return g


# =============================================================================
# Internal Orchestrators (continuous / categorical)
# =============================================================================


def _plot_continuous(
    plot_df: pl.DataFrame,
    pred_df: pl.DataFrame,
    x: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    col_wrap: int | None,
    scatter: bool,
    fit_line: bool,
    height: float,
    aspect: float,
    palette: str,
    markers: str | list[str],
    style: dict,
    scatter_kws: dict | None,
    line_kws: dict | None,
    ci_kws: dict | None,
    # BLUP mode parameters
    blup_mode: bool = False,
    population_line: bool = True,
    model: "BaseModel | None" = None,
    pop_grid: pl.DataFrame | None = None,
    population_kws: dict | None = None,
) -> "sns.FacetGrid":
    """Create plot for continuous predictor: scatter + line + CI band.

    When blup_mode=True and population_line=True, adds a dashed population-level
    reference line behind the subject-specific BLUP lines.

    Args:
        plot_df: Observed data DataFrame.
        pred_df: Prediction DataFrame with fitted values and optional CIs.
        x: X-axis variable name.
        hue: Hue variable name or None.
        col: Column facet variable name or None.
        row: Row facet variable name or None.
        col_wrap: Number of columns before wrapping.
        scatter: Whether to show scatter points.
        fit_line: Whether to show prediction line.
        height: Facet height in inches.
        aspect: Facet aspect ratio.
        palette: Color palette name.
        markers: Marker style(s).
        style: BOSSANOVA_STYLE dictionary.
        scatter_kws: Extra scatter kwargs.
        line_kws: Extra line kwargs.
        ci_kws: Extra CI band kwargs.
        blup_mode: Whether BLUP mode is active.
        population_line: Whether to show population reference line.
        model: The fitted model (needed for population predictions).
        pop_grid: Population prediction grid.
        population_kws: Extra population line kwargs.

    Returns:
        Seaborn FacetGrid with the plot.
    """
    import seaborn as sns

    # Build FacetGrid manually for layered plotting
    grid_kwargs = build_facetgrid_kwargs(
        data=plot_df,
        height=height,
        aspect=aspect,
        col_wrap=col_wrap,
        hue=hue,
        col=col,
        row=row,
        palette=palette,
    )

    # Remove hue from grid_kwargs - we handle it in map_dataframe
    hue_order = None
    if hue is not None:
        hue_order = plot_df[hue].unique().sort().to_list()
        # Don't pass hue to FacetGrid - we handle coloring manually
        grid_kwargs.pop("hue", None)
        grid_kwargs.pop("palette", None)

    g = sns.FacetGrid(**grid_kwargs)

    # Get color palette
    if hue is not None:
        n_hue = len(hue_order)
        colors = sns.color_palette(palette, n_colors=n_hue)
        color_map = dict(zip(hue_order, colors))
    else:
        colors = [sns.color_palette(palette)[0]]
        color_map = None

    # Layer 1: CI band (if available)
    has_ci = "lwr" in pred_df.columns or "ci_lower" in pred_df.columns
    if fit_line and has_ci:
        g.map_dataframe(
            add_ci_band,
            pred_df=pred_df,
            x=x,
            hue=hue,
            col=col,
            row=row,
            color_map=color_map,
            style=style,
            ci_kws=ci_kws,
        )

    # Layer 2: Population line (in BLUP mode, before scatter/BLUP lines)
    if blup_mode and population_line and model is not None and pop_grid is not None:
        g.map_dataframe(
            add_population_line,
            model=model,
            pop_grid=pop_grid,
            x=x,
            col=col,
            row=row,
            style=style,
            population_kws=population_kws,
        )

    # Layer 3: Scatter (data points)
    response = [c for c in plot_df.columns if c not in [x, hue, col, row]][0]
    if scatter:
        g.map_dataframe(
            add_scatter_layer,
            x=x,
            y=response,
            hue=hue,
            color_map=color_map,
            markers=markers,
            style=style,
            scatter_kws=scatter_kws,
        )

    # Layer 4: Prediction line (BLUP lines in BLUP mode, population line otherwise)
    if fit_line:
        g.map_dataframe(
            add_fit_line,
            pred_df=pred_df,
            x=x,
            hue=hue,
            col=col,
            row=row,
            color_map=color_map,
            style=style,
            line_kws=line_kws,
        )

    # Add legend if hue is used
    if hue is not None:
        g.add_legend(title=hue)

    return g


def _plot_categorical(
    plot_df: pl.DataFrame,
    pred_df: pl.DataFrame,
    x: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    col_wrap: int | None,
    scatter: bool,
    fit_line: bool,
    height: float,
    aspect: float,
    palette: str,
    style: dict,
    scatter_kws: dict | None,
    ci_kws: dict | None,
    dodge: float,
) -> "sns.FacetGrid":
    """Create plot for categorical predictor: strip + points + error bars.

    Args:
        plot_df: Observed data DataFrame.
        pred_df: Prediction DataFrame with fitted values and optional CIs.
        x: X-axis variable name.
        hue: Hue variable name or None.
        col: Column facet variable name or None.
        row: Row facet variable name or None.
        col_wrap: Number of columns before wrapping.
        scatter: Whether to show strip points.
        fit_line: Whether to show point estimates.
        height: Facet height in inches.
        aspect: Facet aspect ratio.
        palette: Color palette name.
        style: BOSSANOVA_STYLE dictionary.
        scatter_kws: Extra scatter kwargs.
        ci_kws: Extra CI band kwargs.
        dodge: Horizontal offset between hue levels.

    Returns:
        Seaborn FacetGrid with the plot.
    """
    import seaborn as sns

    # Build FacetGrid
    grid_kwargs = build_facetgrid_kwargs(
        data=plot_df,
        height=height,
        aspect=aspect,
        col_wrap=col_wrap,
        hue=hue,
        col=col,
        row=row,
        palette=palette,
    )

    # Remove hue from grid_kwargs - we handle it manually
    hue_order = None
    if hue is not None:
        hue_order = plot_df[hue].unique().sort().to_list()
        grid_kwargs.pop("hue", None)
        grid_kwargs.pop("palette", None)

    g = sns.FacetGrid(**grid_kwargs)

    # Get color palette
    if hue is not None:
        n_hue = len(hue_order)
        colors = sns.color_palette(palette, n_colors=n_hue)
        color_map = dict(zip(hue_order, colors))
    else:
        colors = [sns.color_palette(palette)[0]]
        color_map = None

    # Get x categories and positions
    x_order = plot_df[x].unique().sort().to_list()
    x_positions = {cat: i for i, cat in enumerate(x_order)}

    # Layer 1: Strip plot (observed data)
    response = [c for c in plot_df.columns if c not in [x, hue, col, row]][0]
    if scatter:
        g.map_dataframe(
            add_strip_layer,
            x=x,
            y=response,
            hue=hue,
            x_positions=x_positions,
            color_map=color_map,
            hue_order=hue_order,
            dodge=dodge,
            style=style,
            scatter_kws=scatter_kws,
        )

    # Layer 2: Point estimates + error bars
    if fit_line:
        g.map_dataframe(
            add_errorbar_layer,
            pred_df=pred_df,
            x=x,
            hue=hue,
            col=col,
            row=row,
            x_positions=x_positions,
            color_map=color_map,
            hue_order=hue_order,
            dodge=dodge,
            style=style,
            ci_kws=ci_kws,
        )

    # Set x-axis ticks
    for ax in g.axes.flat:
        if ax is not None:
            ax.set_xticks(list(range(len(x_order))))
            ax.set_xticklabels(x_order)

    # Add legend if hue is used
    if hue is not None:
        g.add_legend(title=hue)

    return g
