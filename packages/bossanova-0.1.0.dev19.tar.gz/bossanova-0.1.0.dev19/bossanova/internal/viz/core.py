"""Core utilities for bossanova visualization.

This module re-exports shared infrastructure from split sub-modules:
- core_protocols: Model protocol and data extraction
- core_sizing: Figure sizing and styling constants
- core_data: Parameter, residual, random-effect extraction
- core_viz: Plot helpers, labels, type inference, FacetGrid support

All public names remain importable from ``bossanova.internal.viz.core``.
"""

from __future__ import annotations

# Model protocol and data extraction
from bossanova.internal.viz.core_protocols import (
    ModelProtocol,
    get_model_fitted,
    get_model_formula,
    get_model_params,
    get_model_residuals,
    get_model_response,
    is_unified_model,
)

# Styling and sizing
from bossanova.internal.viz.core_sizing import (
    BOSSANOVA_STYLE,
    compute_figsize,
    compute_grid_figsize,
    compute_heatmap_figsize,
)

# Data extraction (params, residuals, random effects)
from bossanova.internal.viz.core_data import (
    extract_fixef,
    extract_params,
    extract_ranef,
    extract_residuals,
)

# Plot helpers, labels, type inference, FacetGrid
from bossanova.internal.viz.core_viz import (
    add_ref_line,
    build_facetgrid_kwargs,
    coerce_to_column_dtype,
    create_multi_panel,
    create_single_panel,
    finalize_facetgrid,
    format_display_label,
    format_display_labels,
    format_pvalue_annotation,
    is_categorical,
    prettify_label,
    prettify_labels,
    setup_ax,
    strip_transform_wrapper,
)

__all__ = [
    "BOSSANOVA_STYLE",
    "ModelProtocol",
    "add_ref_line",
    "build_facetgrid_kwargs",
    "coerce_to_column_dtype",
    "compute_figsize",
    "compute_grid_figsize",
    "compute_heatmap_figsize",
    "create_multi_panel",
    "create_single_panel",
    "extract_fixef",
    "extract_params",
    "extract_ranef",
    "extract_residuals",
    "finalize_facetgrid",
    "format_display_label",
    "format_display_labels",
    "format_pvalue_annotation",
    "get_model_fitted",
    "get_model_formula",
    "get_model_params",
    "get_model_residuals",
    "get_model_response",
    "is_categorical",
    "is_unified_model",
    "prettify_label",
    "prettify_labels",
    "setup_ax",
    "strip_transform_wrapper",
]
