"""Prediction plots for bossanova models.

This module provides plot_predict() for visualizing marginal predictions
across the range of a predictor variable.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

import numpy as np
import polars as pl

from bossanova.internal.viz.core import (
    BOSSANOVA_STYLE,
    coerce_to_column_dtype,
    get_model_formula,
    is_categorical,
    format_display_label,
)
from bossanova.internal.viz.helpers import (
    detect_ci_columns,
    fill_ci_band,
    get_grouping_factors,
    is_mixed_model,
)

if TYPE_CHECKING:
    from typing import Any

    import seaborn as sns

    from bossanova.model.core import model as BaseModel

__all__ = ["plot_predict"]


def plot_predict(
    model: "Any",
    term: str,
    *,
    hue: str | None = None,
    col: str | None = None,
    row: str | None = None,
    at: dict | None = None,
    units: Literal["link", "data"] = "data",
    n_points: int = 50,
    interval: Literal["confidence", "prediction"] | None = "confidence",
    conf_int: float = 0.95,
    show_data: bool = False,
    show_rug: bool = False,
    show_blups: bool = False,
    groups: list[str] | None = None,
    prettify: bool = False,
    # FacetGrid params
    height: float = 4.0,
    aspect: float = 1.2,
    col_wrap: int | None = None,
    palette: str | None = None,
) -> sns.FacetGrid:
    """Plot marginal predictions across a predictor's range.

    Creates a visualization of model predictions varying one predictor while
    holding others at reference values (means for continuous, reference level
    for categorical).

    Args:
        model: A fitted bossanova model.
        term: The predictor variable to vary. Can be continuous or categorical.
        hue: Column name for color encoding (creates separate lines per level).
        col: Column name for faceting into columns.
        row: Column name for faceting into rows.
        at: Dictionary of predictor values to hold fixed.
            E.g., `at={"age": 30}` holds age at 30.
        units: Units for predictions.
            - "data": Back-transformed predictions (default).
            - "link": Predictions on link scale (GLM/GLMER).
        n_points: Number of points for continuous predictors.
        interval: Type of interval to show.
            - "confidence": Confidence interval for mean prediction.
            - "prediction": Prediction interval (wider, includes residual var).
            - None: No interval.
        conf_int: Confidence level (default 0.95).
        show_data: Overlay actual data points on the plot.
        show_rug: Add rug plot showing observed data distribution.
        show_blups: For mixed models, show group-specific BLUP lines in addition
            to the population-average fixed effects line.
        groups: For mixed models with show_blups=True, which group levels to show.
            If None, shows all groups (can be crowded for many groups).
        prettify: Convert axis labels to human-readable format (e.g.,
            "wt_hp_ratio" → "Wt Hp Ratio"). Default False.
        height: Height of each facet in inches.
        aspect: Aspect ratio of each facet.
        palette: Color palette name (default: BOSSANOVA_STYLE palette).

    Returns:
        Seaborn FacetGrid containing the plot.

    Raises:
        RuntimeError: If model is not fitted.
        ValueError: If term is not in the model.

    Examples:
        ::

            from bossanova import model, viz, load_dataset
            mtcars = load_dataset("mtcars")

            # Simple predictions
            m = model("mpg ~ wt + hp", mtcars).fit()
            viz.plot_predict(m, "wt")

            # Interaction visualization with hue
            m = model("mpg ~ wt * cyl", mtcars).fit()
            viz.plot_predict(m, "wt", hue="cyl")

            # Mixed model (inferred from formula)
            sleep = load_dataset("sleepstudy")
            m = model("Reaction ~ Days + (Days|Subject)", sleep).fit()
            viz.plot_predict(m, "Days", show_blups=True)

    See Also:
        plot_fit: Observed vs Predicted scatter plot.
        plot_explore: Marginal effects/means visualization.
    """
    import seaborn as sns

    if not model._is_fitted:
        raise RuntimeError("Model must be fitted before plotting predictions")

    style = BOSSANOVA_STYLE
    if palette is None:
        palette = style["palette"]

    # Get original data
    data = model.data

    # Check term exists
    if term not in data.columns:
        raise ValueError(f"Term '{term}' not found in data columns")

    # Determine if term is continuous or categorical
    term_is_categorical = is_categorical(data, term)

    # Build prediction data
    plot_df = build_prediction_data(
        model=model,
        data=data,
        term=term,
        hue=hue,
        col=col,
        row=row,
        at=at,
        n_points=n_points,
        is_categorical=term_is_categorical,
        pred_type=units,
        interval=interval,
        conf_int=conf_int,
        show_blups=show_blups,
        groups=groups,
    )

    # Create the plot
    if term_is_categorical:
        g = plot_categorical(
            plot_df, term, hue, col, row, height, aspect, palette, style
        )
    else:
        g = plot_continuous(
            plot_df, term, hue, col, row, height, aspect, palette, style, show_blups
        )

    # Add data points if requested
    if show_data:
        g.map_dataframe(add_data_layer, model=model, term=term, hue=hue, style=style)

    # Add rug if requested
    if show_rug and not term_is_categorical:
        g.map_dataframe(add_rug_layer, model=model, term=term)

    # Labels and title (optionally prettified)
    term_label = format_display_label(term) if prettify else term
    ylabel = "Predicted" if units == "data" else "Linear Predictor"
    g.set_axis_labels(term_label, ylabel)

    title = f"Marginal Predictions: {term_label}"
    g.figure.suptitle(title, y=1.02, fontsize=style["title_size"])

    # Clean up
    sns.despine()
    g.tight_layout()

    return g


def build_prediction_data(
    model: "Any",
    data: pl.DataFrame,
    term: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    at: dict | None,
    n_points: int,
    is_categorical: bool,
    pred_type: str,
    interval: str | None,
    conf_int: float,
    show_blups: bool,
    groups: list[str] | None,
) -> pl.DataFrame:
    """Build prediction DataFrame with fitted values and intervals."""
    response_col = get_model_formula(model).split("~")[0].strip()
    grouping_factors = get_grouping_factors(model)
    is_mixed = is_mixed_model(model)

    # Build base prediction grid
    grid_data = {}

    for col_name in data.columns:
        if col_name == response_col:
            continue

        # Handle grouping factors for mixed models
        if col_name in grouping_factors:
            if show_blups and is_mixed:
                # Include grouping factor in grid for BLUP predictions
                all_levels = data[col_name].unique().sort().to_list()
                if groups is not None:
                    # Coerce user-provided groups to match column dtype
                    coerced_groups = coerce_to_column_dtype(
                        list(groups), data, col_name
                    )
                    # Filter to requested groups
                    grid_data[col_name] = [g for g in all_levels if g in coerced_groups]
                else:
                    grid_data[col_name] = all_levels
            continue  # Skip if not showing BLUPs

        if col_name == term:
            # Vary this term
            if is_categorical:
                grid_data[col_name] = data[col_name].unique().sort().to_list()
            else:
                col_data = data[col_name].to_numpy()
                # Use nanmin/nanmax to handle columns with missing values
                grid_data[col_name] = list(
                    np.linspace(np.nanmin(col_data), np.nanmax(col_data), n_points)
                )
        elif at and col_name in at:
            grid_data[col_name] = [at[col_name]]
        elif col_name in [hue, col, row] and col_name is not None:
            # Vary grouping variables
            grid_data[col_name] = data[col_name].unique().sort().to_list()
        else:
            # Use reference value
            dtype = data[col_name].dtype
            if dtype in (pl.Categorical, pl.Utf8, pl.String):
                grid_data[col_name] = [data[col_name].unique().sort().to_list()[0]]
            else:
                grid_data[col_name] = [float(data[col_name].mean())]

    # Create Cartesian product grid
    from itertools import product

    keys = list(grid_data.keys())
    values = [grid_data[k] for k in keys]
    rows = [dict(zip(keys, combo)) for combo in product(*values)]
    pred_grid = pl.DataFrame(rows)

    # Save model state — plot_predict should not have side effects on
    # _last_op or _pred, since users may call .infer() after plotting and
    # expect it to route back to the pre-plot operation (e.g. "fit").
    # Unwrap ModelResult proxy (has __slots__, can't set attrs directly).
    from bossanova.model.result import ModelResult

    _core = model._model if isinstance(model, ModelResult) else model
    saved_last_op = _core._last_op
    saved_pred = _core._pred

    # Get predictions — request intervals in first call when possible to
    # avoid a redundant second model.predict() invocation.
    predict_kwargs: dict = {"type": pred_type}

    if is_mixed:
        if show_blups:
            predict_kwargs["varying"] = "include"
        else:
            predict_kwargs["varying"] = "exclude"

    # Try a single call with intervals included
    got_intervals = False
    if interval:
        try:
            interval_kwargs = {
                **predict_kwargs,
                "interval": interval,
                "conf_int": conf_int,
            }
            model.predict(pred_grid, **interval_kwargs)
            pred_df = model.predictions
            preds_array = pred_df["fitted"].to_numpy()
            result_df = pred_grid.with_columns(pl.Series("fit", preds_array))

            if isinstance(pred_df, pl.DataFrame):
                if "ci_lower" in pred_df.columns:
                    result_df = result_df.with_columns(
                        [
                            pl.Series("ci_lower", pred_df["ci_lower"].to_numpy()),
                            pl.Series("ci_upper", pred_df["ci_upper"].to_numpy()),
                        ]
                    )
                    got_intervals = True
                elif "lwr" in pred_df.columns:
                    result_df = result_df.with_columns(
                        [
                            pl.Series("lwr", pred_df["lwr"].to_numpy()),
                            pl.Series("upr", pred_df["upr"].to_numpy()),
                        ]
                    )
                    got_intervals = True
        except (TypeError, ValueError):
            # Interval not supported — fall back to point predictions only
            pass

    # Fall back to point-only predictions if intervals weren't obtained
    if not got_intervals:
        model.predict(pred_grid, **predict_kwargs)
        preds_array = model.predictions["fitted"].to_numpy()
        result_df = pred_grid.with_columns(pl.Series("fit", preds_array))

    # For mixed models with BLUPs, also add population-level predictions
    if show_blups and is_mixed and grouping_factors:
        # Add a column to identify BLUP vs fixed effects
        group_col = grouping_factors[0]
        result_df = result_df.with_columns(
            pl.col(group_col).cast(pl.Utf8).alias("_line_type")
        )

        # Cast grouping factor columns to String for consistent schema
        for gf in grouping_factors:
            result_df = result_df.with_columns(pl.col(gf).cast(pl.Utf8))

        # Get population-level predictions (no random effects)
        pop_grid = pred_grid.drop(grouping_factors)
        pop_grid = pop_grid.unique()

        # Use kwargs to pass varying only to mixed models (type checker can't narrow here)
        pop_kwargs: dict = {"type": pred_type, "varying": "exclude"}
        model.predict(pop_grid, **pop_kwargs)
        pop_preds_array = model.predictions["fitted"].to_numpy()
        pop_df = pop_grid.with_columns(
            [
                pl.Series("fit", pop_preds_array),
                pl.lit("Fixed Effects").alias("_line_type"),
            ]
        )

        # Add placeholder for group column (String type to match result_df)
        for gf in grouping_factors:
            pop_df = pop_df.with_columns(pl.lit("Fixed Effects").alias(gf))

        result_df = pl.concat([result_df, pop_df], how="diagonal")

    # Restore model state so plot_predict doesn't affect subsequent .infer()
    _core._last_op = saved_last_op
    _core._pred = saved_pred

    return result_df


def plot_continuous(
    plot_df: pl.DataFrame,
    term: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    height: float,
    aspect: float,
    palette: str,
    style: dict,
    show_blups: bool,
) -> sns.FacetGrid:
    """Create FacetGrid for continuous predictor."""
    import seaborn as sns

    # Determine what to use for hue
    effective_hue = hue
    if show_blups and "_line_type" in plot_df.columns:
        effective_hue = "_line_type"

    # Build relplot kwargs
    relplot_kwargs = {
        "data": plot_df,
        "x": term,
        "y": "fit",
        "kind": "line",
        "col": col,
        "row": row,
        "height": height,
        "aspect": aspect,
        "linewidth": style["line_width"],
    }

    if effective_hue is not None:
        relplot_kwargs["hue"] = effective_hue
        relplot_kwargs["palette"] = palette

    g = sns.relplot(**relplot_kwargs)

    # Add confidence bands if present
    if "ci_lower" in plot_df.columns or "lwr" in plot_df.columns:
        g.map_dataframe(add_ci_band, term=term, hue=effective_hue, style=style)

    return g


def plot_categorical(
    plot_df: pl.DataFrame,
    term: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    height: float,
    aspect: float,
    palette: str,
    style: dict,
) -> sns.FacetGrid:
    """Create FacetGrid for categorical predictor."""
    import seaborn as sns

    catplot_kwargs = {
        "data": plot_df,
        "x": term,
        "y": "fit",
        "kind": "point",
        "col": col,
        "row": row,
        "height": height,
        "aspect": aspect,
        "capsize": 0.1,
        "err_kws": {"linewidth": style["line_width"]},
        "markersize": 8,
    }

    if hue is not None:
        catplot_kwargs["hue"] = hue
        catplot_kwargs["palette"] = palette
        catplot_kwargs["dodge"] = True

    # Use errorbar for CI if available
    if "ci_lower" in plot_df.columns or "lwr" in plot_df.columns:
        catplot_kwargs["errorbar"] = None  # We'll add custom error bars

    g = sns.catplot(**catplot_kwargs)

    return g


def add_ci_band(
    data: Any,  # Polars or pandas DataFrame from FacetGrid
    *,
    term: str,
    hue: str | None,
    style: dict,
    **kwargs: Any,
) -> None:
    """Add confidence/prediction interval band to the current axes.

    Draws a semi-transparent shaded region between lower and upper
    confidence bounds. Supports both ``ci_lower``/``ci_upper``
    (preferred) and ``lwr``/``upr`` (legacy) column naming.

    Unlike ``fit_layers.add_ci_band``, this version receives
    pre-filtered data from ``FacetGrid.map_dataframe()`` and generates
    hue colors dynamically via ``plt.cm.tab10`` rather than using a
    pre-computed color map.

    Delegates rendering to :func:`~bossanova.internal.viz.helpers.fill_ci_band`.

    Args:
        data: DataFrame passed by FacetGrid.map_dataframe (already
            filtered to the current facet).
        term: Column name for x-axis values.
        hue: Column name for color grouping, or None.
        style: BOSSANOVA_STYLE dictionary for default aesthetics.
        **kwargs: Extra kwargs passed by FacetGrid (ignored).
    """
    import matplotlib.pyplot as plt

    ci_cols = detect_ci_columns(data.columns)
    if ci_cols is None:
        return
    lower_col, upper_col = ci_cols

    ax = plt.gca()
    kws: dict[str, Any] = {"alpha": style["ci_alpha"], "zorder": 1}

    # Build color map for hue groups (dynamic via tab10)
    hue_values: np.ndarray | None = None
    colors: dict[Any, Any] | None = None
    if hue is not None:
        hue_values = np.asarray(data[hue])
        groups = list(dict.fromkeys(hue_values))  # unique preserving order
        tab10_colors = plt.cm.tab10(np.linspace(0, 1, len(groups)))
        colors = dict(zip(groups, tab10_colors))

    fill_ci_band(
        ax=ax,
        x=np.asarray(data[term]),
        lower=np.asarray(data[lower_col]),
        upper=np.asarray(data[upper_col]),
        hue_values=hue_values,
        colors=colors,
        fill_kws=kws,
    )


def add_data_layer(
    data,  # Polars or pandas DataFrame from FacetGrid
    *,
    model: BaseModel,
    term: str,
    hue: str | None,
    style: dict,
    **kwargs,
) -> None:
    """Add actual data points as a layer."""
    import matplotlib.pyplot as plt

    ax = plt.gca()
    original_data = model.data  # Already Polars
    response_col = model.formula.split("~")[0].strip()

    x = np.asarray(original_data[term])
    y = np.asarray(original_data[response_col])

    if hue is None or hue not in original_data.columns:
        ax.scatter(x, y, alpha=0.3, s=style["point_size"] * 0.5, color="gray", zorder=0)
    else:
        hue_col = np.asarray(original_data[hue])
        groups = original_data[hue].unique().to_list()
        colors = plt.cm.tab10(np.linspace(0, 1, len(groups)))

        for i, group in enumerate(groups):
            mask = hue_col == group
            ax.scatter(
                x[mask],
                y[mask],
                alpha=0.3,
                s=style["point_size"] * 0.5,
                color=colors[i],
                zorder=0,
            )


def add_rug_layer(
    data,  # Polars or pandas DataFrame from FacetGrid
    *,
    model: BaseModel,
    term: str,
    **kwargs,
) -> None:
    """Add rug plot showing observed data distribution."""
    import matplotlib.pyplot as plt

    ax = plt.gca()
    original_data = model.data  # Already Polars
    x = np.asarray(original_data[term])

    ax.plot(
        x,
        np.zeros_like(x),
        "|",
        color="gray",
        alpha=0.5,
        markersize=10,
        transform=ax.get_xaxis_transform(),
        zorder=0,
    )
