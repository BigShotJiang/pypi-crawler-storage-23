"""Data preparation helpers for fit plots.

This module builds prediction grids, fetches model predictions, constructs
plot DataFrames, and filters predictions to FacetGrid facets.
"""

from __future__ import annotations

from itertools import product
from typing import TYPE_CHECKING, Any

import numpy as np
import polars as pl

from bossanova.internal.viz.core import get_model_response, is_categorical
from bossanova.internal.viz.helpers import get_grouping_factors

if TYPE_CHECKING:
    from bossanova.model.core import model as BaseModel

__all__ = [
    "build_plot_data",
    "build_prediction_grid",
    "filter_to_facet",
    "get_predictions",
    "warn_many_groups",
]


def build_prediction_grid(
    model: "Any",
    x: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    n_points: int,
    x_is_categorical: bool,
    blup_mode: bool = False,
    groups: list[str] | int | None = None,
) -> pl.DataFrame:
    """Build a prediction grid varying x (and hue/col/row levels).

    For continuous x: uses linspace(min, max, n_points).
    For categorical x: uses unique levels.
    Other predictors: reference values (mean for numeric, first level for cat).

    In BLUP mode: grouping factors used in hue/col/row are included in the grid.
    Otherwise: grouping factors are excluded (population-level predictions).

    Args:
        model: The fitted model.
        x: The x-axis variable.
        hue: Hue variable name.
        col: Column facet variable name.
        row: Row facet variable name.
        n_points: Number of points for continuous x.
        x_is_categorical: Whether x is categorical.
        blup_mode: If True, include grouping factors used in hue/col/row.
        groups: Subset of group levels to include, or int for random sample.

    Returns:
        DataFrame with prediction grid.
    """
    import random

    data = model.data
    response = get_model_response(model)

    # Get grouping factors for mixed models
    grouping_factors = set(get_grouping_factors(model))

    # Which grouping factors are being used for visualization
    viz_grouping_factors = set()
    for var in (hue, col, row):
        if var and var in grouping_factors:
            viz_grouping_factors.add(var)

    # Augmented columns added during fitting (not predictors)
    augmented_cols = {
        "fitted",
        "resid",
        "std_resid",
        "hat",
        "cooksd",
        "pearson_resid",
        "deviance_resid",
    }

    grid_data: dict[str, list] = {}

    for col_name in data.columns:
        if col_name == response:
            continue

        # Skip augmented columns (added during fitting)
        if col_name in augmented_cols:
            continue

        # Handle grouping factors
        if col_name in grouping_factors:
            if blup_mode and col_name in viz_grouping_factors:
                # Include this grouping factor with optional subsetting
                levels = data[col_name].unique().sort().to_list()

                if groups is not None:
                    if isinstance(groups, int):
                        # Random sample of levels
                        levels = random.sample(levels, min(groups, len(levels)))
                        levels = sorted(levels, key=str)
                    else:
                        # Filter to specified levels
                        levels = [lv for lv in levels if lv in groups]

                grid_data[col_name] = levels
            else:
                # Skip grouping factors not used in visualization
                continue
        elif col_name == x:
            # Vary this predictor
            if x_is_categorical:
                grid_data[col_name] = data[col_name].unique().sort().to_list()
            else:
                col_values = data[col_name].to_numpy()
                grid_data[col_name] = list(
                    np.linspace(np.nanmin(col_values), np.nanmax(col_values), n_points)
                )
        elif col_name in [hue, col, row]:
            # Vary non-grouping factor visualization variables (all levels)
            grid_data[col_name] = data[col_name].unique().sort().to_list()
        else:
            # Reference value: mean for numeric, first level for categorical
            if is_categorical(data, col_name):
                grid_data[col_name] = [data[col_name].unique().sort().to_list()[0]]
            else:
                grid_data[col_name] = [float(data[col_name].mean())]

    # Create Cartesian product grid
    keys = list(grid_data.keys())
    values = [grid_data[k] for k in keys]
    rows = [dict(zip(keys, combo)) for combo in product(*values)]

    return pl.DataFrame(rows)


def warn_many_groups(data: pl.DataFrame, var: str, threshold: int = 20) -> None:
    """Warn if faceting/hue by a variable with many levels.

    Args:
        data: The data containing the variable.
        var: Variable name to check.
        threshold: Maximum levels before warning.
    """
    import warnings

    n_levels = data[var].n_unique()
    if n_levels > threshold:
        warnings.warn(
            f"{var} has {n_levels} levels. Consider using groups= parameter "
            f"to subset, or groups={threshold // 2} to randomly sample levels.",
            UserWarning,
            stacklevel=4,
        )


def get_predictions(
    model: "BaseModel",
    grid: pl.DataFrame,
    ci: int | None,
    blup_mode: bool = False,
) -> pl.DataFrame:
    """Get predictions from model, with optional CI.

    For fixed-effects models (lm/glm): uses ``pred_int`` parameter.
    For unified model: uses ``predict().infer()`` for delta-method
    confidence intervals. Mixed models get population-level CIs
    (fixed-effects-only via delta method).

    Args:
        model: The fitted model.
        grid: Prediction grid DataFrame.
        ci: Confidence interval level (e.g., 95 for 95% CI).
        blup_mode: If True and mixed model, use varying='include' for BLUPs.

    Returns:
        DataFrame with predictions and optional CI bounds.
    """
    # Check model type for CI support
    # Resolve ModelResult proxy to get the actual model class name
    inner = getattr(model, "_model", model)
    model_class = type(inner).__name__.lower()
    supports_ci = model_class in ("lm", "glm")
    is_mixed = model_class in ("lmer", "glmer")

    # Unified model() class: check model_type and is_mixed
    if model_class == "model":
        is_mixed = getattr(model, "_is_mixed", False)
        # Unified model supports CI via predict().infer() for all model types
        # Mixed models get population-level (fixed-effects-only) CIs
        supports_ci = True

    # Build prediction kwargs
    predict_kwargs: dict[str, Any] = {}

    if is_mixed:
        # BLUP mode: include random effects; otherwise population-level
        predict_kwargs["varying"] = "include" if blup_mode else "exclude"

    if ci is not None and supports_ci and model_class in ("lm", "glm"):
        pred_int = ci / 100  # Convert percentage to fraction
        predict_kwargs["pred_int"] = pred_int

    model.predict(grid, **predict_kwargs)

    # For unified model, use predict().infer() to compute CI
    if ci is not None and supports_ci and model_class == "model":
        conf_level = ci / 100  # Convert percentage to fraction
        model.infer(conf_level=conf_level)

    pred_df = model.predictions

    # Build result DataFrame with fitted column and grid columns
    result = grid.clone()
    result = result.with_columns(pred_df["fitted"].alias("fitted"))

    # Add CI columns if present
    for ci_col in ("lwr", "upr", "ci_lower", "ci_upper"):
        if ci_col in pred_df.columns:
            result = result.with_columns(pred_df[ci_col])

    return result


def build_plot_data(
    model: "Any",
    x: str,
    hue: str | None,
    col: str | None,
    row: str | None,
) -> pl.DataFrame:
    """Build DataFrame with observed data for scatter/strip layer.

    Args:
        model: The fitted model.
        x: The x-axis variable.
        hue: Hue variable name.
        col: Column facet variable name.
        row: Row facet variable name.

    Returns:
        DataFrame with only the columns needed for plotting.
    """
    data = model.data
    response = get_model_response(model)

    # Select only needed columns
    cols = [x, response]
    for grp in [hue, col, row]:
        if grp is not None and grp not in cols:
            cols.append(grp)

    # Filter to columns that exist
    cols = [c for c in cols if c in data.columns]

    return data.select(cols)


def filter_to_facet(
    pred_df: pl.DataFrame,
    ax: "Any",  # matplotlib Axes
    col: str | None,
    row: str | None,
) -> pl.DataFrame:
    """Filter prediction DataFrame to match current facet based on axis title.

    Parses seaborn's facet title format (e.g. ``col_name = value`` or
    ``row = val | col = val``) and filters the prediction DataFrame to
    only include rows matching the current facet.

    Args:
        pred_df: Polars DataFrame with predictions.
        ax: Matplotlib axes (used to read the facet title).
        col: Column facet variable name (or None).
        row: Row facet variable name (or None).

    Returns:
        Filtered DataFrame matching the current facet.
    """
    if col is None and row is None:
        return pred_df

    # Get facet values from axis title
    title = ax.get_title()
    if not title:
        return pred_df

    # Parse seaborn's facet title format: "col_name = value" or "row = val | col = val"
    result = pred_df

    parts = title.split(" | ") if " | " in title else [title]
    for part in parts:
        if " = " in part:
            var_name, value = part.split(" = ", 1)
            var_name = var_name.strip()
            value = value.strip()

            if var_name in result.columns:
                col_dtype = result[var_name].dtype
                if col_dtype in (
                    pl.Float64,
                    pl.Float32,
                    pl.Int64,
                    pl.Int32,
                    pl.Int16,
                    pl.Int8,
                ):
                    try:
                        result = result.filter(pl.col(var_name) == float(value))
                    except ValueError:
                        result = result.filter(pl.col(var_name).cast(pl.Utf8) == value)
                else:
                    result = result.filter(pl.col(var_name).cast(pl.Utf8) == value)

    return result
