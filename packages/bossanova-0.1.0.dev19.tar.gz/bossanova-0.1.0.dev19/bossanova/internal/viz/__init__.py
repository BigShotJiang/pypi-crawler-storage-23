"""Plotting functions for model exploration and diagnostics.

All plot functions accept a fitted model instance and return matplotlib Figure objects.

Post-estimation plots (require .fit()):
    plot_params: Coefficient forest plot with CIs
    plot_resid: Residual diagnostic panels (QQ, fitted vs residuals)
    plot_predict: Prediction plots with confidence bands
    plot_fit: Observed vs fitted scatter
    plot_explore: Marginal effects visualization
    plot_ranef: Random effects caterpillar plot (mixed models)
    plot_resamples: Bootstrap/permutation distribution plots
    plot_compare: Model comparison visualization
    plot_profile: Profile likelihood plots (mixed models)
    plot_vif: Variance inflation factor bar plot

Pre-estimation plots (model cognition):
    plot_dag: Causal DAG from formula
    plot_lattice: Random effects grouping structure
    plot_cognition: Combined model understanding panel
    plot_design: Design matrix heatmap
    plot_relationships: Variable relationship scatter matrix
"""

from __future__ import annotations

from bossanova.internal.viz.core import (
    BOSSANOVA_STYLE,
    compute_figsize,
    compute_grid_figsize,
    extract_params,
    extract_residuals,
    # Compatibility utilities
    get_model_fitted,
    get_model_formula,
    get_model_params,
    get_model_residuals,
    get_model_response,
    is_unified_model,
)

# Plot functions (post-estimation)
from bossanova.internal.viz.params import plot_params
from bossanova.internal.viz.ranef import plot_ranef
from bossanova.internal.viz.resid import plot_resid
from bossanova.internal.viz.predict import plot_predict
from bossanova.internal.viz.fit import plot_fit
from bossanova.internal.viz.mem import plot_explore
from bossanova.internal.viz.compare import plot_compare
from bossanova.internal.viz.resamples import plot_resamples

# Plot functions (pre-estimation / model cognition)
from bossanova.internal.viz.dag import plot_dag
from bossanova.internal.viz.lattice import plot_lattice
from bossanova.internal.viz.cognition import plot_cognition
from bossanova.internal.viz.design import plot_design
from bossanova.internal.viz.vif import plot_vif
from bossanova.internal.viz.profile import plot_profile
from bossanova.internal.viz.relationships import plot_relationships

__all__ = [
    "BOSSANOVA_STYLE",
    "compute_figsize",
    "compute_grid_figsize",
    "extract_params",
    "extract_residuals",
    "get_model_fitted",
    "get_model_formula",
    "get_model_params",
    "get_model_residuals",
    "get_model_response",
    "is_unified_model",
    "plot_cognition",
    "plot_compare",
    "plot_dag",
    "plot_design",
    "plot_explore",
    "plot_fit",
    "plot_lattice",
    "plot_params",
    "plot_predict",
    "plot_profile",
    "plot_ranef",
    "plot_relationships",
    "plot_resamples",
    "plot_resid",
    "plot_vif",
]
