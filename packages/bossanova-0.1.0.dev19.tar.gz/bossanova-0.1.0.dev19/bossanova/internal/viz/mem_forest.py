"""Forest-style plots for slopes and contrasts.

Provides ``_plot_slopes`` and ``_plot_contrasts`` used by
``plot_explore()`` in ``mem.py``. Separated to keep each file under
800 lines.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.viz.core import (
    create_single_panel,
    finalize_facetgrid,
    format_display_labels,
    format_pvalue_annotation,
)
from bossanova.internal.viz.mem import (
    _build_yerr,
    _extract_by_category,
    condition_columns,
    prettify_if,
)

if TYPE_CHECKING:
    from typing import Any

    import seaborn as sns
    from matplotlib.axes import Axes


__all__ = ["_plot_contrasts", "_plot_slopes"]


# =============================================================================
# Slopes plot (forest-style or per-condition)
# =============================================================================


def _plot_slopes(
    df: pl.DataFrame,
    *,
    focal_var: str,
    specs: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    prettify: bool,
    height: float,
    aspect: float,
    palette: str,
    col_wrap: int | None,
    style: dict,
    show_pvalue: bool,
    ref_line: float,
) -> "sns.FacetGrid":
    """Plot marginal slopes.

    Single-row slopes are plotted as a horizontal forest plot.
    Multi-row crossed slopes (e.g., slope of x at each level of z)
    are plotted as point + error bar per condition level.

    Args:
        df: Effects DataFrame from explore().infer().
        focal_var: Name of the focal (continuous) variable.
        specs: Original explore formula string.
        hue: Hue grouping variable.
        col: Faceting column variable.
        row: Faceting row variable.
        prettify: Apply label prettification.
        height: Facet height in inches.
        aspect: Facet aspect ratio.
        palette: Color palette name.
        col_wrap: Number of columns before wrapping facets.
        style: BOSSANOVA_STYLE dictionary.
        show_pvalue: Annotate with significance stars.
        ref_line: Reference line position (default 0).

    Returns:
        Seaborn FacetGrid.
    """
    import seaborn as sns

    cond_cols = condition_columns(df, focal_var)
    n_rows = len(df)

    if n_rows <= 1 and not cond_cols:
        # Single slope — simple forest plot
        return _draw_single_slope_forest(
            df,
            focal_var=focal_var,
            specs=specs,
            prettify=prettify,
            height=height,
            aspect=aspect,
            style=style,
            show_pvalue=show_pvalue,
            ref_line=ref_line,
        )

    # Crossed slopes — point + error bar per condition level
    cond_col = cond_cols[0] if cond_cols else focal_var

    facet_kwargs: dict[str, Any] = {
        "data": df,
        "height": height,
        "aspect": aspect,
    }
    if hue is not None and hue in df.columns:
        facet_kwargs["hue"] = hue
    if col is not None:
        facet_kwargs["col"] = col
    if row is not None:
        facet_kwargs["row"] = row
    if col_wrap is not None:
        facet_kwargs["col_wrap"] = col_wrap

    g = sns.FacetGrid(**facet_kwargs)
    g.map_dataframe(
        _draw_slopes_points,
        cond_col=cond_col,
        style=style,
        show_pvalue=show_pvalue,
        ref_line=ref_line,
    )

    # Labels
    cond_label = prettify_if(cond_col, prettify)
    focal_label = prettify_if(focal_var, prettify)
    g.set_axis_labels(cond_label, f"Marginal Effect of {focal_label}")

    specs_label = prettify_if(specs, prettify)
    g.figure.suptitle(
        f"Marginal Slopes: {specs_label}",
        y=1.02,
        fontsize=style["title_size"],
    )

    if hue is not None:
        g.add_legend(title=prettify_if(hue, prettify))

    sns.despine()
    g.tight_layout()
    return g


def _draw_single_slope_forest(
    df: pl.DataFrame,
    *,
    focal_var: str,
    specs: str,
    prettify: bool,
    height: float,
    aspect: float,
    style: dict,
    show_pvalue: bool,
    ref_line: float,
) -> "sns.FacetGrid":
    """Draw a single slope as a horizontal forest-plot point + whisker.

    Args:
        df: Single-row effects DataFrame.
        focal_var: Focal variable name.
        specs: Explore formula.
        prettify: Apply label prettification.
        height: Figure height.
        aspect: Figure aspect ratio.
        style: Style dictionary.
        show_pvalue: Show significance stars.
        ref_line: Reference line position.

    Returns:
        Seaborn FacetGrid.
    """
    import seaborn as sns

    fig_height = max(2.5, height * 0.8)
    g, ax = create_single_panel((fig_height * aspect, fig_height))

    estimate = float(df["estimate"][0])
    has_ci = "ci_lower" in df.columns and "ci_upper" in df.columns

    # Draw CI whisker
    if has_ci:
        ci_lo = float(df["ci_lower"][0])
        ci_hi = float(df["ci_upper"][0])
        ax.errorbar(
            estimate,
            0,
            xerr=[[estimate - ci_lo], [ci_hi - estimate]],
            fmt="none",
            ecolor=style["ref_line_color"],
            elinewidth=style["line_width"],
            capsize=style["capsize"],
            zorder=1,
        )

    # Draw point
    ax.scatter(
        [estimate],
        [0],
        s=style["point_size"],
        marker=style["point_marker"],
        edgecolors=style["point_edgecolor"],
        linewidths=style["point_linewidth"],
        zorder=2,
        c="C0",
    )

    # Reference line
    ax.axvline(
        ref_line,
        color=style["ref_line_color"],
        linestyle=style["ref_line_style"],
        linewidth=style["ref_line_width"],
        zorder=0,
    )

    # P-value annotation
    if show_pvalue and "p_value" in df.columns:
        p = float(df["p_value"][0])
        stars = format_pvalue_annotation(p)
        if stars:
            ax.annotate(
                stars,
                (estimate, 0),
                xytext=(-5, 10),
                textcoords="offset points",
                fontsize=style["font_size"],
                ha="right",
                va="bottom",
            )

    focal_label = prettify_if(focal_var, prettify)
    ax.set_yticks([0])
    ax.set_yticklabels([focal_label])
    ax.set_xlabel("Marginal Effect")
    ax.grid(axis="x", alpha=style["grid_alpha"], linestyle=style["grid_style"])

    specs_label = prettify_if(specs, prettify)
    ax.set_title(
        f"Marginal Slope: {specs_label}",
        fontsize=style["title_size"],
    )

    sns.despine()
    g.tight_layout()
    return g


def _draw_slopes_points(
    data: "Any",
    *,
    cond_col: str,
    style: dict,
    show_pvalue: bool,
    ref_line: float,
    **kwargs: "Any",
) -> None:
    """Draw crossed slopes as point + error bar per condition level."""
    import matplotlib.pyplot as plt

    ax = plt.gca()

    cond_vals = np.asarray(data[cond_col])
    categories = list(dict.fromkeys(cond_vals))
    x_positions = np.arange(len(categories))

    estimates, ci_lo, ci_hi = _extract_by_category(data, cond_vals, categories)
    yerr = _build_yerr(estimates, ci_lo, ci_hi)

    ax.errorbar(
        x_positions,
        estimates,
        yerr=yerr,
        fmt="o",
        markersize=8,
        capsize=5,
        color="C0",
        ecolor=style["ref_line_color"],
        elinewidth=style["line_width"],
    )

    # Reference line (e.g., 0 for slopes)
    ax.axhline(
        ref_line,
        color=style["ref_line_color"],
        linestyle=style["ref_line_style"],
        linewidth=style["ref_line_width"],
        zorder=0,
    )

    # P-value annotations
    if show_pvalue and "p_value" in data.columns:
        p_values = np.asarray(data["p_value"])
        for i, (cat, x_pos) in enumerate(zip(categories, x_positions)):
            mask = cond_vals == cat
            if mask.any():
                idx = np.where(mask)[0][0]
                stars = format_pvalue_annotation(float(p_values[idx]))
                if stars:
                    ax.annotate(
                        stars,
                        (x_pos, estimates[i]),
                        xytext=(0, 8),
                        textcoords="offset points",
                        fontsize=style["font_size"],
                        ha="center",
                        va="bottom",
                    )

    ax.set_xticks(x_positions)
    ax.set_xticklabels([str(c) for c in categories])


# =============================================================================
# Contrasts plot (forest plot)
# =============================================================================


def _plot_contrasts(
    df: pl.DataFrame,
    *,
    focal_var: str,
    specs: str,
    col: str | None,
    row: str | None,
    prettify: bool,
    height: float,
    aspect: float,
    palette: str,
    col_wrap: int | None,
    style: dict,
    show_pvalue: bool,
    ref_line: float,
) -> "sns.FacetGrid":
    """Plot contrasts as a forest plot with reference line at 0.

    Each contrast is a horizontal point + CI whisker, with optional
    significance stars.

    Args:
        df: Effects DataFrame with ``contrast`` column.
        focal_var: Focal variable name.
        specs: Original explore formula string.
        col: Faceting column variable.
        row: Faceting row variable.
        prettify: Apply label prettification.
        height: Facet height in inches.
        aspect: Facet aspect ratio.
        palette: Color palette name.
        col_wrap: Number of columns before wrapping facets.
        style: BOSSANOVA_STYLE dictionary.
        show_pvalue: Annotate with significance stars.
        ref_line: Reference line position (default 0).

    Returns:
        Seaborn FacetGrid.
    """
    import seaborn as sns

    cond_cols = condition_columns(df, "contrast")

    if cond_cols and (col is not None or row is not None):
        # Faceted contrasts
        facet_kwargs: dict[str, Any] = {
            "data": df,
            "height": height,
            "aspect": aspect,
        }
        if col is not None:
            facet_kwargs["col"] = col
        if row is not None:
            facet_kwargs["row"] = row
        if col_wrap is not None:
            facet_kwargs["col_wrap"] = col_wrap

        g = sns.FacetGrid(**facet_kwargs)
        g.map_dataframe(
            _draw_contrast_forest,
            style=style,
            show_pvalue=show_pvalue,
            ref_line=ref_line,
            prettify=prettify,
        )
        g.figure.suptitle(
            f"Contrasts: {prettify_if(specs, prettify)}",
            y=1.02,
            fontsize=style["title_size"],
        )
    else:
        # Single panel
        n_contrasts = len(df)
        per_row_height = max(0.4, height * 0.15)
        fig_height = max(3.0, n_contrasts * per_row_height)
        fig_width = fig_height * aspect

        g, ax = create_single_panel((fig_width, fig_height))
        _draw_contrast_forest_ax(
            ax,
            df,
            style=style,
            show_pvalue=show_pvalue,
            ref_line=ref_line,
            prettify=prettify,
        )
        ax.set_title(
            f"Contrasts: {prettify_if(specs, prettify)}",
            fontsize=style["title_size"],
        )

    finalize_facetgrid(g, xlabel="Estimate", ylabel="")
    return g


def _draw_contrast_forest(
    data: "Any",
    *,
    style: dict,
    show_pvalue: bool,
    ref_line: float,
    prettify: bool,
    **kwargs: "Any",
) -> None:
    """Draw contrast forest plot panel (for FacetGrid mapping)."""
    import matplotlib.pyplot as plt

    ax = plt.gca()
    # Convert to polars if needed (FacetGrid may pass pandas)
    if not isinstance(data, pl.DataFrame):
        data = pl.from_pandas(data)
    _draw_contrast_forest_ax(
        ax,
        data,
        style=style,
        show_pvalue=show_pvalue,
        ref_line=ref_line,
        prettify=prettify,
    )


def _draw_contrast_forest_ax(
    ax: "Axes",
    df: pl.DataFrame,
    *,
    style: dict,
    show_pvalue: bool,
    ref_line: float,
    prettify: bool,
) -> None:
    """Draw contrast forest plot on a given axes.

    Args:
        ax: Matplotlib axes.
        df: Effects DataFrame with ``contrast`` column.
        style: Style dictionary.
        show_pvalue: Show significance stars.
        ref_line: Reference line position.
        prettify: Apply label prettification.
    """
    contrast_labels = list(df["contrast"])
    display_labels = format_display_labels(
        contrast_labels, max_chars=30, prettify=prettify, strip_transforms=False
    )
    estimates = np.asarray(df["estimate"])
    n_items = len(contrast_labels)
    y_positions = np.arange(n_items)

    has_ci = "ci_lower" in df.columns and "ci_upper" in df.columns
    has_pvalue = "p_value" in df.columns

    # CI whiskers
    if has_ci:
        ci_lower = np.asarray(df["ci_lower"])
        ci_upper = np.asarray(df["ci_upper"])
        valid = ~(np.isnan(ci_lower) | np.isnan(ci_upper))
        if valid.any():
            xerr_lo = estimates[valid] - ci_lower[valid]
            xerr_hi = ci_upper[valid] - estimates[valid]
            ax.errorbar(
                estimates[valid],
                y_positions[valid],
                xerr=[xerr_lo, xerr_hi],
                fmt="none",
                ecolor=style["ref_line_color"],
                elinewidth=style["line_width"],
                capsize=style["capsize"],
                zorder=1,
            )

    # Point estimates
    ax.scatter(
        estimates,
        y_positions,
        s=style["point_size"],
        marker=style["point_marker"],
        edgecolors=style["point_edgecolor"],
        linewidths=style["point_linewidth"],
        zorder=2,
        c="C0",
    )

    # Reference line at 0
    ax.axvline(
        ref_line,
        color=style["ref_line_color"],
        linestyle=style["ref_line_style"],
        linewidth=style["ref_line_width"],
        zorder=0,
    )

    # P-value stars
    if show_pvalue and has_pvalue:
        p_values = np.asarray(df["p_value"])
        for est, y, p in zip(estimates, y_positions, p_values):
            if not np.isnan(p):
                stars = format_pvalue_annotation(float(p))
                if stars:
                    ax.annotate(
                        stars,
                        (est, y),
                        xytext=(-5, 0),
                        textcoords="offset points",
                        fontsize=style["font_size"],
                        va="center",
                        ha="right",
                    )

    # Y-axis labels
    ax.set_yticks(y_positions)
    ax.set_yticklabels(display_labels)
    ax.invert_yaxis()

    # Grid
    ax.grid(axis="x", alpha=style["grid_alpha"], linestyle=style["grid_style"])
