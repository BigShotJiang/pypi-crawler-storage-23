"""Profile likelihood visualization.

Pure function operating on ProfileState containers.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

__all__ = [
    "plot_profile",
]

import numpy as np

from bossanova.internal.viz.core import BOSSANOVA_STYLE, format_display_label

if TYPE_CHECKING:
    import seaborn as sns

    from bossanova.internal.containers.structs.state import ProfileState


def plot_profile(
    profile: ProfileState,
    param: str | None = None,
    *,
    height: float = 4.0,
    aspect: float = 1.2,
    prettify: bool = False,
    palette: str | None = None,
) -> sns.FacetGrid:
    """Plot profile likelihood curves.

    Args:
        profile: ProfileState from profile_likelihood().
        param: Specific parameter to plot, or None for all parameters.
        height: Height of each panel in inches.
        aspect: Width-to-height ratio of each panel.
        prettify: Apply human-readable formatting to parameter names
            in axis labels and titles.
        palette: Color palette name for the profile curves. Each parameter
            gets a distinct color from the cycle. Default uses
            BOSSANOVA_STYLE palette.

    Returns:
        Seaborn FacetGrid containing zeta vs parameter plot(s).
    """
    import seaborn as _sns

    from bossanova.internal.viz.core import create_multi_panel, create_single_panel

    params_to_plot = [param] if param else list(profile.spline_forward.keys())
    n_params = len(params_to_plot)

    from scipy import stats

    zeta_crit = np.sqrt(stats.chi2.ppf(profile.conf_level, df=1))

    # Build color cycle
    style = BOSSANOVA_STYLE
    palette_name = palette or style["palette"]
    colors = _sns.color_palette(palette_name, n_params)

    if n_params == 1:
        figsize = (height * aspect, height)
        g, ax = create_single_panel(figsize)
        _draw_profile_on_ax(
            ax,
            profile,
            params_to_plot[0],
            zeta_crit,
            color=colors[0],
            prettify=prettify,
        )
    else:
        g, axes = create_multi_panel(
            n_params,
            col_wrap=min(3, n_params),
            height=height,
            aspect=aspect,
        )

        for i, pname in enumerate(params_to_plot):
            if i < len(axes):
                _draw_profile_on_ax(
                    axes[i],
                    profile,
                    pname,
                    zeta_crit,
                    color=colors[i],
                    prettify=prettify,
                )

        # Hide unused axes
        for j in range(n_params, len(axes)):
            axes[j].set_visible(False)

    g.tight_layout()
    return g


def _draw_profile_on_ax(
    ax: Any,
    profile: ProfileState,
    pname: str,
    zeta_crit: float,
    *,
    color: Any = "blue",
    prettify: bool = False,
) -> None:
    """Draw a single profile likelihood curve on an axes.

    Args:
        ax: Matplotlib axes to draw on.
        profile: ProfileState from profile_likelihood().
        pname: Parameter name to plot.
        zeta_crit: Critical zeta value for confidence interval lines.
        color: Color for the profile curve line and points.
        prettify: Apply human-readable formatting to parameter name.
    """
    # Get profile data for this parameter
    param_data = profile.table.filter(profile.table["param"] == pname)
    focal = param_data["focal"].to_numpy()
    zeta = param_data["zeta"].to_numpy()

    # Sort by focal value
    sort_idx = np.argsort(focal)
    focal = focal[sort_idx]
    zeta = zeta[sort_idx]

    # Plot profile curve
    ax.plot(focal, zeta, color=color, linestyle="-", linewidth=2)
    ax.scatter(focal, zeta, c=[color], s=20, zorder=5)

    # Add critical zeta lines
    ax.axhline(-zeta_crit, color="red", linestyle="--", alpha=0.7)
    ax.axhline(zeta_crit, color="red", linestyle="--", alpha=0.7)
    ax.axhline(0, color="gray", linestyle="-", alpha=0.5)

    # Add CI bounds as vertical lines
    if pname in profile.ci_theta:
        lower, upper = profile.ci_theta[pname]
        ax.axvline(lower, color="green", linestyle=":", alpha=0.7)
        ax.axvline(upper, color="green", linestyle=":", alpha=0.7)

    display_name = format_display_label(pname) if prettify else pname
    ax.set_xlabel(display_name)
    ax.set_ylabel("\u03b6 (signed likelihood root)")
    ax.set_title(f"Profile: {display_name}")
