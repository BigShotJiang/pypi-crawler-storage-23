"""Shared helper utilities for bossanova visualization modules.

This module consolidates helper functions used across multiple viz modules
(fit.py, predict.py, etc.) to eliminate duplication.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from typing import Any, Sequence

    from matplotlib.axes import Axes

__all__ = [
    "detect_blup_mode",
    "detect_ci_columns",
    "fill_ci_band",
    "get_grouping_factors",
    "is_mixed_model",
]


def detect_ci_columns(columns: "Sequence[str]") -> tuple[str, str] | None:
    """Detect CI bound column names in a DataFrame.

    Checks for ``ci_lower``/``ci_upper`` (preferred) falling back to
    ``lwr``/``upr`` (legacy). Returns ``None`` if neither pair is present.

    Args:
        columns: Column names to search (e.g., ``df.columns``).

    Returns:
        Tuple of ``(lower_col, upper_col)`` column names, or ``None``
        if no CI columns are found.
    """
    cols = set(columns)
    if "ci_lower" in cols:
        return ("ci_lower", "ci_upper")
    if "lwr" in cols:
        return ("lwr", "upr")
    return None


def fill_ci_band(
    ax: "Axes",
    x: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    hue_values: np.ndarray | None = None,
    colors: dict["Any", "Any"] | None = None,
    default_color: str = "C0",
    fill_kws: dict[str, "Any"] | None = None,
) -> None:
    """Render sorted CI bands on a matplotlib axes.

    This is the shared rendering core used by both ``fit_layers.add_ci_band``
    and ``predict.add_ci_band``. It sorts data along x, then calls
    ``ax.fill_between()`` once per hue level (or once if no hue).

    Args:
        ax: Matplotlib axes to draw on.
        x: X-axis values, shape ``(n,)``.
        lower: Lower CI bound values, shape ``(n,)``.
        upper: Upper CI bound values, shape ``(n,)``.
        hue_values: Per-observation hue labels, shape ``(n,)``. Pass
            ``None`` for single-color rendering.
        colors: Mapping from hue level to matplotlib color. Required
            when ``hue_values`` is not None. Determines both which
            levels to draw and their colors.
        default_color: Color to use when ``hue_values`` is None.
            Defaults to ``"C0"``.
        fill_kws: Additional keyword arguments forwarded to
            ``ax.fill_between()``.
    """
    kws = dict(fill_kws) if fill_kws else {}

    if hue_values is None or colors is None:
        sort_idx = np.argsort(x)
        ax.fill_between(
            x[sort_idx],
            lower[sort_idx],
            upper[sort_idx],
            color=default_color,
            **kws,
        )
    else:
        for level, color in colors.items():
            mask = hue_values == level
            if np.any(mask):
                x_sub = x[mask]
                sort_idx = np.argsort(x_sub)
                ax.fill_between(
                    x_sub[sort_idx],
                    lower[mask][sort_idx],
                    upper[mask][sort_idx],
                    color=color,
                    **kws,
                )


def is_mixed_model(model: "Any") -> bool:
    """Check if model is a mixed-effects model.

    Supports both the legacy API (lmer/glmer classes) and the unified
    model() class.

    Args:
        model: A bossanova model object (any API variant).

    Returns:
        True if the model contains random/varying effects.
    """
    # Resolve ModelResult proxy to get the actual model class name
    inner = getattr(model, "_model", model)
    model_class = type(inner).__name__.lower()

    # Legacy API (lmer/glmer classes)
    if model_class in ("lmer", "glmer"):
        return True

    # Unified model() class
    if model_class == "model" and hasattr(model, "_is_mixed"):
        return model._is_mixed

    return False


def get_grouping_factors(model: "Any") -> list[str]:
    """Get grouping factor column names for mixed models.

    Extracts the names of grouping variables (e.g., ``Subject`` from
    ``(1|Subject)``) from a fitted mixed model. Returns an empty list
    for fixed-effects-only models.

    Supports both the legacy API (lmer/glmer with ``_group_names``) and
    the unified model() class (via ``random_terms`` property).

    Args:
        model: A bossanova model object (any API variant).

    Returns:
        List of grouping factor column names, in the order they appear
        in the formula. Empty list for non-mixed models.
    """
    if not is_mixed_model(model):
        return []

    # Resolve ModelResult proxy to get the actual model class name
    inner = getattr(model, "_model", model)
    model_class = type(inner).__name__.lower()

    # Legacy API (lmer/glmer classes)
    if model_class in ("lmer", "glmer"):
        return list(getattr(model, "_group_names", []))

    # Unified model() class
    if model_class == "model" and hasattr(model, "_random_terms"):
        groups: list[str] = []
        for term in model._random_terms:
            if "|" in term:
                group = term.split("|")[-1].rstrip(")")
                if group not in groups:
                    groups.append(group)
        return groups

    return []


def detect_blup_mode(
    model: "Any",
    hue: str | None,
    col: str | None,
    row: str | None,
    blups: bool | None,
) -> bool:
    """Determine if BLUP mode should be enabled for a plot.

    Returns True if:
    - ``blups=True`` explicitly, OR
    - ``blups=None`` AND model is mixed AND any of ``hue``/``col``/``row``
      is a grouping factor (auto-detection).

    Args:
        model: A fitted bossanova model.
        hue: Hue variable name (or None).
        col: Column facet variable name (or None).
        row: Row facet variable name (or None).
        blups: Explicit BLUP mode setting. None triggers auto-detection.

    Returns:
        True if BLUP mode should be enabled.
    """
    if blups is not None:
        return blups

    # Only mixed models have grouping factors
    grouping_factors = get_grouping_factors(model)
    if not grouping_factors:
        return False

    # Check if any faceting/hue variable is a grouping factor
    for var in (hue, col, row):
        if var and var in grouping_factors:
            return True

    return False
