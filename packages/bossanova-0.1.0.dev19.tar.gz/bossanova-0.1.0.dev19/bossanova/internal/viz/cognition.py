"""Combined DAG and lattice visualization for model cognition."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from bossanova.internal.viz.dag import (
    DAG_STYLE,
    _draw_dag_on_ax,
    default_dag_edges,
)
from bossanova.internal.viz.lattice import _draw_lattice_on_ax
from bossanova.internal.viz.layout import (
    LayoutConfig,
    dag_layout,
    generate_lattice,
    lattice_layout,
)

if TYPE_CHECKING:
    import seaborn as sns

__all__ = ["plot_cognition"]


def plot_cognition(
    terms: list[str],
    outcome: str,
    dag_edges: list[tuple[str, str]] | None = None,
    dag_bidirected: list[tuple[str, str]] | None = None,
    exposure: str | None = None,
    kind: Literal["both", "dag", "lattice"] = "both",
    dag_source: Literal["default", "user"] = "default",
    figsize: tuple[float, float] | None = None,
    legend: bool = True,
) -> sns.FacetGrid:
    """Plot model cognition: DAG and/or model lattice.

    This is the main visualization function for understanding a model
    specification before estimation. It shows:
    1. The causal DAG (assumed or explicit)
    2. The model lattice (Hasse diagram of nested models)

    Args:
        terms: Model terms including "intercept" if present.
        outcome: Response variable name.
        dag_edges: Directed edges for DAG. If None, uses default
            regression interpretation (all predictors -> outcome).
        dag_bidirected: Bidirected edges (unmeasured confounding).
        exposure: Exposure variable for highlighting.
        kind: What to display:
            - "both": Side-by-side DAG and lattice (default)
            - "dag": DAG only
            - "lattice": Lattice only
        dag_source: Whether DAG is "default" or "user"-specified.
        figsize: Figure size. Auto-computed if None.
        legend: Whether to show color legends (default True).

    Returns:
        Seaborn FacetGrid containing the plot(s).

    Examples:
        ```python
        # Default regression assumptions
        g = plot_cognition(
            terms=["intercept", "x1", "x2"],
            outcome="y",
        )

        # With user-specified causal structure
        g = plot_cognition(
            terms=["intercept", "x1", "x2"],
            outcome="y",
            dag_edges=[("x1", "x2"), ("x2", "y"), ("x1", "y")],
            exposure="x1",
            dag_source="user",
        )
        ```
    """
    # Get predictors (exclude intercept for DAG)
    predictors = [t for t in terms if t != "intercept" and ":" not in t]

    # Generate default DAG if not provided
    if dag_edges is None:
        dag_edges = default_dag_edges(predictors, outcome)

    # Determine layout based on kind
    if kind == "dag":
        return _plot_dag_only(
            dag_edges, dag_bidirected, exposure, outcome, dag_source, figsize, legend
        )
    elif kind == "lattice":
        return _plot_lattice_only(terms, outcome, figsize, legend)
    else:  # "both"
        return _plot_side_by_side(
            terms,
            outcome,
            dag_edges,
            dag_bidirected,
            exposure,
            dag_source,
            figsize,
            legend,
        )


def _plot_dag_only(
    edges: list[tuple[str, str]],
    bidirected: list[tuple[str, str]] | None,
    exposure: str | None,
    outcome: str,
    source: str,
    figsize: tuple[float, float] | None,
    legend: bool,
) -> sns.FacetGrid:
    """Plot DAG only.

    Args:
        edges: Directed edges.
        bidirected: Bidirected edges.
        exposure: Exposure variable.
        outcome: Outcome variable.
        source: "default" or "user".
        figsize: Figure size.
        legend: Whether to show legend.

    Returns:
        Seaborn FacetGrid.
    """
    from bossanova.internal.viz.dag import plot_dag

    title = "Causal Assumptions"
    if source == "default":
        title += " (default)"

    return plot_dag(
        edges=edges,
        bidirected=bidirected,
        exposure=exposure,
        outcome=outcome,
        title=title,
        figsize=figsize,
        legend=legend,
    )


def _plot_lattice_only(
    terms: list[str],
    outcome: str,
    figsize: tuple[float, float] | None,
    legend: bool,
) -> sns.FacetGrid:
    """Plot lattice only.

    Args:
        terms: Model terms.
        outcome: Outcome variable.
        figsize: Figure size.
        legend: Whether to show legend.

    Returns:
        Seaborn FacetGrid.
    """
    from bossanova.internal.viz.lattice import plot_lattice

    return plot_lattice(
        terms=terms,
        outcome=outcome,
        title="Model Space",
        figsize=figsize,
        legend=legend,
    )


def _plot_side_by_side(
    terms: list[str],
    outcome: str,
    dag_edges: list[tuple[str, str]],
    dag_bidirected: list[tuple[str, str]] | None,
    exposure: str | None,
    dag_source: str,
    figsize: tuple[float, float] | None,
    legend: bool,
) -> sns.FacetGrid:
    """Plot DAG and lattice side-by-side in a two-panel FacetGrid.

    Args:
        terms: Model terms.
        outcome: Outcome variable.
        dag_edges: Directed edges.
        dag_bidirected: Bidirected edges.
        exposure: Exposure variable.
        dag_source: "default" or "user".
        figsize: Figure size.
        legend: Whether to show legends.

    Returns:
        Seaborn FacetGrid with two panels.
    """
    from bossanova.internal.viz.core import create_multi_panel

    bidirected = dag_bidirected or []

    # Compute figsize if not provided
    if figsize is None:
        n_terms = len([t for t in terms if t != "intercept"])
        width = max(10, min(16, 5 + n_terms * 1.5))
        height = max(4, min(8, 3 + n_terms * 0.5))
        figsize = (width, height)

    panel_height = figsize[1]
    panel_aspect = (figsize[0] / 2) / panel_height if panel_height > 0 else 1.0

    g, axes = create_multi_panel(
        2, col_wrap=2, height=panel_height, aspect=panel_aspect
    )
    ax_dag, ax_lattice = axes[0], axes[1]

    # Draw DAG on first panel
    dag_config = LayoutConfig(
        node_width=DAG_STYLE["node_width"],
        node_height=DAG_STYLE["node_height"],
        h_spacing=1.5,
        v_spacing=1.2,
    )
    dag_positions = dag_layout(dag_edges, bidirected, exposure, outcome, dag_config)

    dag_title = "Causal Assumptions"
    if dag_source == "default":
        dag_title += " (default)"

    if dag_positions:
        _draw_dag_on_ax(
            ax_dag,
            edges=dag_edges,
            bidirected=bidirected,
            exposure=exposure,
            outcome=outcome,
            positions=dag_positions,
            config=dag_config,
            title=dag_title,
            legend=legend,
        )
    else:
        ax_dag.text(0.5, 0.5, "Empty DAG", ha="center", va="center", fontsize=12)
        ax_dag.axis("off")
        ax_dag.set_title(dag_title, fontsize=12, fontweight="medium")

    # Draw lattice on second panel
    lattice_config = LayoutConfig(
        node_width=0.8,
        node_height=0.3,
        h_spacing=2.0,
        v_spacing=1.0,
    )
    lattice = generate_lattice(terms, outcome, True, 200)
    lattice_positions = lattice_layout(lattice, lattice_config)

    if lattice.nodes:
        _draw_lattice_on_ax(
            ax_lattice,
            lattice=lattice,
            positions=lattice_positions,
            config=lattice_config,
            title="Model Space",
            legend=legend,
        )
    else:
        ax_lattice.text(
            0.5, 0.5, "Empty lattice", ha="center", va="center", fontsize=12
        )
        ax_lattice.axis("off")
        ax_lattice.set_title("Model Space", fontsize=11, fontweight="medium")

    g.tight_layout()
    return g
