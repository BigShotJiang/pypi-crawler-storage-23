"""Design matrix column name parsing and variable type detection."""

from dataclasses import dataclass
from typing import Literal

__all__ = [
    "DesignColumnInfo",
    "extract_base_term",
    "extract_categorical_variables",
    "identify_column_type",
    "parse_design_column_name",
]


@dataclass(frozen=True, slots=True)
class DesignColumnInfo:
    """Parsed design matrix column metadata.

    Attributes:
        raw_name: Original column name (e.g., "treatment[A]").
        base_term: Base variable name without level (e.g., "treatment").
        level: Level value for categorical, None for continuous (e.g., "A").
        column_type: Type classification.
        is_interaction: Whether this is an interaction term.
    """

    raw_name: str
    base_term: str
    level: str | None
    column_type: Literal["intercept", "continuous", "categorical"]
    is_interaction: bool = False


def parse_design_column_name(name: str) -> DesignColumnInfo:
    """Parse design matrix column name into components.

    Handles standard R/formula naming conventions:
    - "Intercept" → intercept type
    - "x" → continuous variable
    - "treatment[A]" → categorical dummy for level A
    - "x:z" → continuous interaction
    - "treatment[A]:x" → categorical × continuous interaction

    Args:
        name: Column name from design matrix.

    Returns:
        DesignColumnInfo with parsed components.

    Examples:
        >>> parse_design_column_name("Intercept")
        DesignColumnInfo(raw_name='Intercept', base_term='Intercept',
                         level=None, column_type='intercept', is_interaction=False)

        >>> parse_design_column_name("x")
        DesignColumnInfo(raw_name='x', base_term='x',
                         level=None, column_type='continuous', is_interaction=False)

        >>> parse_design_column_name("treatment[A]")
        DesignColumnInfo(raw_name='treatment[A]', base_term='treatment',
                         level='A', column_type='categorical', is_interaction=False)

        >>> parse_design_column_name("treatment[A]:x")
        DesignColumnInfo(raw_name='treatment[A]:x', base_term='treatment:x',
                         level='A', column_type='categorical', is_interaction=True)
    """
    # Handle intercept
    if name == "Intercept":
        return DesignColumnInfo(
            raw_name=name,
            base_term="Intercept",
            level=None,
            column_type="intercept",
            is_interaction=False,
        )

    # Check for interaction (contains ":")
    is_interaction = ":" in name

    # Check for categorical (contains "[" and "]")
    if "[" in name and "]" in name:
        # Extract base term and level
        # Handle interactions: "treatment[A]:x" → base_term="treatment:x", level="A"
        if is_interaction:
            parts = name.split(":")
            base_parts = []
            level = None
            for part in parts:
                if "[" in part:
                    bracket_start = part.index("[")
                    bracket_end = part.index("]")
                    base_parts.append(part[:bracket_start])
                    # Take first level found (for multi-categorical interactions)
                    if level is None:
                        level = part[bracket_start + 1 : bracket_end]
                else:
                    base_parts.append(part)
            base_term = ":".join(base_parts)
        else:
            # Simple categorical: "treatment[A]"
            bracket_start = name.index("[")
            bracket_end = name.index("]")
            base_term = name[:bracket_start]
            level = name[bracket_start + 1 : bracket_end]

        return DesignColumnInfo(
            raw_name=name,
            base_term=base_term,
            level=level,
            column_type="categorical",
            is_interaction=is_interaction,
        )

    # Continuous variable or continuous interaction
    base_term = name  # For interactions like "x:z", base_term is "x:z"
    return DesignColumnInfo(
        raw_name=name,
        base_term=base_term,
        level=None,
        column_type="continuous",
        is_interaction=is_interaction,
    )


def identify_column_type(
    name: str,
) -> Literal["intercept", "continuous", "categorical"]:
    """Identify column type from name (simplified version).

    This is a lightweight alternative to parse_design_column_name()
    when only the type is needed.

    Args:
        name: Column name from design matrix.

    Returns:
        Column type as string literal.
    """
    if name == "Intercept":
        return "intercept"
    if "[" in name and "]" in name:
        return "categorical"
    return "continuous"


def extract_base_term(name: str) -> str:
    """Extract base term name from column name.

    For categorical variables, strips the level suffix.
    For interactions, extracts base terms without levels.

    Args:
        name: Column name from design matrix.

    Returns:
        Base term name.

    Examples:
        >>> extract_base_term("treatment[A]")
        'treatment'
        >>> extract_base_term("x")
        'x'
        >>> extract_base_term("treatment[A]:x")
        'treatment:x'
    """
    if name == "Intercept":
        return "Intercept"

    if "[" not in name:
        return name

    # Handle interactions
    if ":" in name:
        parts = name.split(":")
        base_parts = []
        for part in parts:
            if "[" in part:
                base_parts.append(part[: part.index("[")])
            else:
                base_parts.append(part)
        return ":".join(base_parts)

    # Simple categorical
    return name[: name.index("[")]


def extract_categorical_variables(X_names: tuple[str, ...] | list[str]) -> set[str]:
    """Find all categorical base variable names from design matrix columns.

    Scans column names for bracket patterns and extracts unique base terms.

    Args:
        X_names: Column names from design matrix.

    Returns:
        Set of categorical variable names (base terms, no levels).

    Examples:
        >>> extract_categorical_variables(["Intercept", "x", "treatment[A]", "treatment[B]"])
        {'treatment'}
    """
    categorical = set()
    for name in X_names:
        if "[" in name and "]" in name:
            base_term = extract_base_term(name)
            # For interactions, extract each categorical component
            if ":" in base_term:
                for part in name.split(":"):
                    if "[" in part:
                        categorical.add(part[: part.index("[")])
            else:
                categorical.add(base_term)
    return categorical


def extract_level_from_column(name: str, focal_var: str) -> str | None:
    """Extract level value for a specific focal variable from column name.

    Used when building reference grids to identify which column corresponds
    to which level of the focal variable.

    Args:
        name: Column name (e.g., "treatment[A]" or "treatment[A]:x").
        focal_var: The focal variable name (e.g., "treatment").

    Returns:
        Level value if column is for focal_var, else None.

    Examples:
        >>> extract_level_from_column("treatment[A]", "treatment")
        'A'
        >>> extract_level_from_column("treatment[A]:x", "treatment")
        'A'
        >>> extract_level_from_column("x", "treatment")
        None
        >>> extract_level_from_column("group[1]", "treatment")
        None
    """
    if not name.startswith(f"{focal_var}["):
        return None

    # Find the bracket content after focal_var
    start = len(focal_var) + 1  # After "focal_var["
    end = name.find("]", start)
    if end == -1:
        return None

    return name[start:end]
