"""Satterthwaite degrees of freedom for EMM contrasts in linear mixed models.

Computes per-EMM denominator df using the Satterthwaite approximation,
matching lmerTest's approach where derivatives are taken w.r.t. the full
variance parameter vector ``varpar = [theta, sigma]``.

Algorithm (matches Kuznetsova, Brockhoff & Christensen 2017):
    1. Build ``varpar = [theta, sigma]`` from the fitted model
    2. Define unprofiled deviance as a function of varpar
    3. Compute Hessian via Richardson extrapolation (``numDeriv::hessian``)
    4. ``vcov_varpar = 2 * H^{-1}``
    5. Define ``vcov(beta)`` as a function of varpar
    6. Compute Jacobian via Richardson extrapolation (``numDeriv::jacobian``)
    7. Call ``satterthwaite_df_for_contrasts(L, vcov, vcov_varpar, jac_list)``
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import scipy.sparse as sp

if TYPE_CHECKING:
    from bossanova.internal.containers.structs import DataBundle, FitState, ModelSpec

__all__ = [
    "compute_satterthwaite_emm_df",
]


def compute_satterthwaite_emm_df(
    bundle: DataBundle,
    fit: FitState,
    spec: ModelSpec,
    L: np.ndarray,
) -> np.ndarray:
    """Compute Satterthwaite denominator df for EMM contrast rows.

    For each row of the contrast matrix L, computes the Satterthwaite
    approximation to the denominator degrees of freedom.

    Follows lmerTest's convention of differentiating w.r.t. the full
    variance parameter vector ``varpar = [theta, sigma]``, not just theta.
    Both the Hessian and Jacobian are computed via Richardson extrapolation
    to match ``numDeriv::hessian()`` and ``numDeriv::jacobian()`` in R.

    Args:
        bundle: Data bundle with X, Z, y, and re_metadata.
        fit: Fit state with theta, vcov, and sigma.
        spec: Model specification (method, family, etc.).
        L: Contrast matrix, shape ``(n_contrasts, n_coef)``.

    Returns:
        Array of Satterthwaite df, shape ``(n_contrasts,)``.

    Raises:
        ValueError: If fit has no theta/sigma or bundle has no Z/re_metadata.
    """
    from bossanova.internal.maths.differentiation import (
        compute_hessian_richardson,
        compute_jacobian_richardson,
    )
    from bossanova.internal.maths.inference.satterthwaite import (
        satterthwaite_df_for_contrasts,
    )
    from bossanova.internal.maths.linalg.sparse import compute_sparse_cholesky
    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_sparse,
    )
    from bossanova.internal.maths.solvers.lmer import apply_sqrt_weights

    # --- Validate inputs ---------------------------------------------------
    if fit.theta is None:
        raise ValueError("Satterthwaite df requires theta from a fitted mixed model.")
    if fit.sigma is None:
        raise ValueError("Satterthwaite df requires sigma from a fitted mixed model.")
    if bundle.Z is None or bundle.re_metadata is None:
        raise ValueError(
            "Satterthwaite df requires Z matrix and re_metadata in DataBundle."
        )

    theta = fit.theta
    sigma = fit.sigma
    X = bundle.X
    Z = bundle.Z
    y = bundle.y
    re_meta = bundle.re_metadata
    n_groups_list = re_meta.n_groups_list
    re_structure = re_meta.re_structure
    metadata = re_meta.metadata

    # Apply sqrt(weights) transformation for weighted models.
    # The Satterthwaite derivatives must use the same weighted data as the solver.
    X_w, Z_w, y_w, sqrtwts = apply_sqrt_weights(X, Z, y, bundle.weights)

    n, p = X.shape
    method = spec.method.upper() if spec.method else "REML"
    if method not in ("REML", "ML"):
        method = "REML"

    # --- Build full variance parameter vector: varpar = [theta, sigma] -----
    varpar = np.concatenate([theta, [sigma]])

    # --- 1. Unprofiled deviance as a function of varpar --------------------
    # Uses transformed data (X_w, Z_w, y_w) so weights are implicit, matching
    # the solver. Adds the Jacobian correction -log|W| for weighted models.
    def deviance_varpar(vp: np.ndarray) -> float:
        """Deviance as function of [theta, sigma] (unprofiled)."""
        th = vp[:-1]
        sig = vp[-1]
        sig2 = sig**2

        Lambda = build_lambda_sparse(th, n_groups_list, re_structure, metadata)
        ZL = Z_w @ Lambda
        S22 = (ZL.T @ ZL).tocsc() + sp.eye(Lambda.shape[0], format="csc")
        factor_S22 = compute_sparse_cholesky(S22)

        logdet_L = factor_S22.logdet()

        # Solve for beta and u
        ZLty = ZL.T @ y_w
        cu = factor_S22(ZLty)
        XtX = X_w.T @ X_w
        XtZL = (ZL.T @ X_w).T
        Xty = X_w.T @ y_w
        S22_inv_XtZL_T = factor_S22(XtZL.T)
        schur = XtX - XtZL @ S22_inv_XtZL_T
        rhs = Xty - XtZL @ cu

        try:
            beta = np.linalg.solve(schur, rhs)
        except np.linalg.LinAlgError:
            beta = np.linalg.lstsq(schur, rhs, rcond=None)[0]
        u = cu - S22_inv_XtZL_T @ beta

        fitted_w = X_w @ beta + ZL @ u
        resid_w = y_w - fitted_w
        rss = np.sum(resid_w**2)
        pwrss = rss + np.sum(u**2)

        try:
            chol_schur = np.linalg.cholesky(schur)
        except np.linalg.LinAlgError:
            schur_reg = schur + 1e-8 * np.eye(schur.shape[0])
            chol_schur = np.linalg.cholesky(schur_reg)
        logdet_RX2 = 2 * np.sum(np.log(np.abs(np.diag(chol_schur))))

        if method == "REML":
            df_dev = n - p
            dev = (
                df_dev * np.log(2 * np.pi * sig2) + pwrss / sig2 + logdet_L + logdet_RX2
            )
        else:
            dev = n * np.log(2 * np.pi * sig2) + pwrss / sig2 + logdet_L

        # Weight adjustment: -log|W| = -2*sum(log(sqrtwts))
        if sqrtwts is not None:
            dev = dev - 2.0 * np.sum(np.log(sqrtwts))

        return float(dev)

    # --- 2. Hessian via Richardson extrapolation ---------------------------
    H = compute_hessian_richardson(deviance_varpar, varpar)

    # vcov_varpar = 2 * H^{-1} (Moore-Penrose for robustness)
    tol = 1e-8
    eig_vals, eig_vecs = np.linalg.eigh(H)
    pos = eig_vals > tol
    if np.any(pos):
        eig_vecs_pos = eig_vecs[:, pos]
        eig_vals_pos = eig_vals[pos]
        H_inv = eig_vecs_pos @ np.diag(1.0 / eig_vals_pos) @ eig_vecs_pos.T
    else:
        k = H.shape[0]
        H_inv = np.linalg.pinv(H + np.eye(k) * 1e-6)
    vcov_vp = 2.0 * H_inv

    # --- 3. vcov(beta) as a function of varpar ----------------------------
    # Uses transformed data (weights implicit in X_w, Z_w).
    def vcov_varpar_fn(vp: np.ndarray) -> np.ndarray:
        """Compute vcov(beta) for given [theta, sigma]."""
        th = vp[:-1]
        sig = vp[-1]
        sig2 = sig**2

        Lambda = build_lambda_sparse(th, n_groups_list, re_structure, metadata)
        ZL = Z_w @ Lambda
        S22 = (ZL.T @ ZL).tocsc() + sp.eye(Lambda.shape[0], format="csc")
        factor_S22 = compute_sparse_cholesky(S22)

        XtX = X_w.T @ X_w
        XtZL = (ZL.T @ X_w).T
        S22_inv_XtZL_T = factor_S22(XtZL.T)
        schur = XtX - XtZL @ S22_inv_XtZL_T

        try:
            schur_inv = np.linalg.inv(schur)
        except np.linalg.LinAlgError:
            schur_inv = np.linalg.pinv(schur)
        return sig2 * schur_inv

    # --- 4. Jacobian via Richardson extrapolation --------------------------
    jac_full = compute_jacobian_richardson(vcov_varpar_fn, varpar)

    # Convert (p, p, k) array to list of k matrices
    k = jac_full.shape[2]
    jac_list = [jac_full[:, :, i] for i in range(k)]

    # --- 5. Compute per-contrast Satterthwaite df --------------------------
    df = satterthwaite_df_for_contrasts(
        L=L,
        vcov_beta=fit.vcov,
        vcov_varpar=vcov_vp,
        jac_list=jac_list,
    )

    return np.atleast_1d(np.asarray(df, dtype=np.float64))
