"""Cross-validation inference and metrics.

Provides k-fold cross-validation for model evaluation: splits data into
folds, fits on training folds, predicts on held-out folds, and computes
out-of-sample metrics (RMSE, MAE, R², deviance, accuracy).

For mixed models, group-aware splitting ensures all observations from a
group stay in the same fold (``group_kfold_split``).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    import scipy.sparse as sp
    import polars as pl

    from bossanova.internal.containers import (
        CVState,
        DataBundle,
        InferenceState,
        ModelSpec,
    )
    from bossanova.internal.containers.structs.data import REMetadata

logger = logging.getLogger(__name__)

__all__ = [
    "compute_cv_metrics",
    "compute_params_cv_inference",
    "group_kfold_split",
    "kfold_split",
]


# =============================================================================
# Helpers
# =============================================================================


def kfold_split(
    n: int, k: int, seed: int | None = None
) -> list[tuple[np.ndarray, np.ndarray]]:
    """Generate k-fold cross-validation train/test indices.

    Shuffles the indices and splits into k roughly equal-sized folds.
    Each fold is used exactly once as the test set.

    Args:
        n: Total number of observations.
        k: Number of folds.
        seed: Random seed for reproducibility.

    Returns:
        List of (train_indices, test_indices) tuples, one per fold.

    Examples:
        >>> splits = kfold_split(100, k=10, seed=42)
        >>> len(splits)
        10
        >>> train_idx, test_idx = splits[0]
        >>> len(test_idx)  # ~10 observations per fold
        10
    """
    rng = np.random.default_rng(seed)
    indices = np.arange(n)
    rng.shuffle(indices)

    # Compute fold boundaries
    fold_sizes = np.full(k, n // k, dtype=int)
    fold_sizes[: n % k] += 1  # Distribute remainder

    splits = []
    current = 0
    for fold_size in fold_sizes:
        test_idx = indices[current : current + fold_size]
        train_idx = np.concatenate([indices[:current], indices[current + fold_size :]])
        splits.append((train_idx, test_idx))
        current += fold_size

    return splits


def group_kfold_split(
    group_ids: np.ndarray,
    k: int,
    seed: int | None = None,
) -> list[tuple[np.ndarray, np.ndarray]]:
    """Generate group-aware k-fold cross-validation indices.

    All observations from a group stay in the same fold, preventing data
    leakage from shared random effects. Groups are shuffled and assigned
    to roughly equal-sized folds.

    Args:
        group_ids: Array of group IDs for each observation (length n).
        k: Number of folds.
        seed: Random seed for reproducibility.

    Returns:
        List of (train_indices, test_indices) tuples, one per fold.

    Raises:
        ValueError: If k exceeds the number of unique groups.

    Examples:
        >>> group_ids = np.array([0, 0, 1, 1, 2, 2, 3, 3])
        >>> splits = group_kfold_split(group_ids, k=2, seed=42)
        >>> len(splits)
        2
    """
    unique_groups = np.unique(group_ids)
    n_groups = len(unique_groups)

    if k > n_groups:
        raise ValueError(
            f"k={k} exceeds number of groups ({n_groups}). Use k <= {n_groups}."
        )

    rng = np.random.default_rng(seed)
    group_order = unique_groups.copy()
    rng.shuffle(group_order)

    # Assign groups to folds with balanced sizes
    fold_sizes = np.full(k, n_groups // k, dtype=int)
    fold_sizes[: n_groups % k] += 1

    splits = []
    current = 0
    for fold_size in fold_sizes:
        test_groups = set(group_order[current : current + fold_size].tolist())
        test_mask = np.array([gid in test_groups for gid in group_ids])
        test_idx = np.where(test_mask)[0]
        train_idx = np.where(~test_mask)[0]
        splits.append((train_idx, test_idx))
        current += fold_size

    return splits


def _subset_re_metadata(
    re_metadata: "REMetadata",
    Z: "sp.csc_matrix",
    train_idx: np.ndarray,
) -> tuple["REMetadata", "sp.csc_matrix"]:
    """Subset random effects metadata and Z matrix for a training fold.

    Follows the ``_reindex_groups_after_na_drop`` pattern: subset group
    arrays by ``train_idx``, re-index to contiguous 0..n_active-1, and
    rebuild Z via ``build_z_simple``.

    Args:
        re_metadata: Full-data random effects metadata.
        Z: Full-data sparse Z matrix, shape (n, q).
        train_idx: Observation indices for the training fold.

    Returns:
        Tuple of (subset REMetadata, rebuilt Z matrix).
    """
    import scipy.sparse as sp

    import attrs

    from bossanova.internal.design.z_matrix import build_z_simple

    # Subset group IDs and X_re
    new_group_ids_list: list[np.ndarray] = []
    new_n_groups_list: list[int] = []
    new_group_indices: dict[str, np.ndarray] = {}
    new_n_groups: dict[str, int] = {}

    for i, (var, ids) in enumerate(
        zip(re_metadata.grouping_vars, re_metadata.group_ids_list)
    ):
        sub_ids = ids[train_idx]
        present = np.unique(sub_ids)
        n_active = len(present)

        # Re-index to 0..n_active-1
        old_to_new = np.full(re_metadata.n_groups_list[i], -1, dtype=np.intp)
        old_to_new[present] = np.arange(n_active, dtype=np.intp)
        reindexed = old_to_new[sub_ids]

        new_group_ids_list.append(reindexed)
        new_n_groups_list.append(n_active)
        new_group_indices[var] = reindexed
        new_n_groups[var] = n_active

    # Subset X_re
    X_re = re_metadata.X_re
    if X_re is not None:
        if isinstance(X_re, list):
            X_re = [x[train_idx] for x in X_re]
        else:
            X_re = X_re[train_idx]

    # Rebuild Z from re-indexed group IDs
    re_structure = re_metadata.re_structure
    if len(new_group_ids_list) == 1:
        layout = "interleaved"
        if re_structure == "diagonal":
            layout = "blocked"
        Z_new = build_z_simple(
            new_group_ids_list[0],
            new_n_groups_list[0],
            X_re=X_re if not isinstance(X_re, list) else None,
            layout=layout,
        )
        if isinstance(X_re, list):
            blocks = []
            for x in X_re:
                blk = build_z_simple(
                    new_group_ids_list[0],
                    new_n_groups_list[0],
                    X_re=x,
                    layout="blocked",
                )
                blocks.append(blk)
            Z_new = sp.hstack(blocks, format="csc")
    else:
        blocks = []
        for j, (ids_j, n_g) in enumerate(zip(new_group_ids_list, new_n_groups_list)):
            if isinstance(X_re, list) and j < len(X_re):
                x_j = X_re[j]
            elif not isinstance(X_re, list):
                x_j = X_re
            else:
                x_j = None
            blk = build_z_simple(ids_j, n_g, X_re=x_j, layout="interleaved")
            blocks.append(blk)
        Z_new = sp.hstack(blocks, format="csc")

    new_metadata = attrs.evolve(
        re_metadata,
        n_groups=new_n_groups,
        group_indices=new_group_indices,
        group_ids_list=new_group_ids_list,
        n_groups_list=new_n_groups_list,
        X_re=X_re,
    )
    return new_metadata, Z_new


# =============================================================================
# Public API
# =============================================================================


def compute_cv_metrics(
    spec: "ModelSpec",
    bundle: "DataBundle",
    k: int | str = 10,
    seed: int | None = None,
) -> "CVState":
    """Compute k-fold or leave-one-out cross-validation metrics.

    Splits the data into k folds, trains on k-1 folds, and predicts
    on the held-out fold. Aggregates out-of-sample prediction metrics.

    Args:
        spec: Model specification (family, link, etc.).
        bundle: Data bundle with X, y, and metadata.
        k: Number of folds (default 10), or ``"loo"`` for
            leave-one-out cross-validation.
        seed: Random seed for reproducibility. Ignored for LOO.

    Returns:
        CVState with RMSE, MAE, R², and optionally deviance/accuracy.

    Raises:
        ValueError: If k exceeds the number of observations.
        RuntimeError: If cross-validation produces no valid predictions.
    """
    import warnings

    from bossanova.internal.containers import DataBundle as DataBundleCls
    from bossanova.internal.containers import build_cv_state
    from bossanova.internal.fit import fit_model

    n = bundle.n
    is_mixed = spec.has_random_effects and bundle.re_metadata is not None

    # Handle LOO vs k-fold — group-aware for mixed models
    if is_mixed:
        primary_group_ids = bundle.re_metadata.group_ids_list[0]
        n_groups = len(np.unique(primary_group_ids))

        if k == "loo":
            # Leave-one-group-out for mixed models
            splits = group_kfold_split(primary_group_ids, k=n_groups, seed=seed)
            k_int = n_groups
        else:
            if not isinstance(k, int) or k < 2:
                raise ValueError(f"k must be an integer >= 2 or 'loo', got k={k!r}")
            if k > n_groups:
                warnings.warn(
                    f"k={k} exceeds number of groups ({n_groups}); using k={n_groups}",
                    stacklevel=3,
                )
                k = n_groups
            splits = group_kfold_split(primary_group_ids, k=k, seed=seed)
            k_int = k
    elif k == "loo":
        from bossanova.internal.infer.resample.core import generate_loo_indices

        splits = generate_loo_indices(n)
        k_int = n
    else:
        if not isinstance(k, int) or k < 2:
            raise ValueError(f"k must be an integer >= 2 or 'loo', got k={k!r}")
        if k > n:
            raise ValueError(f"k={k} cannot exceed number of observations n={n}")
        splits = kfold_split(n, k, seed=seed)
        k_int = k

    # Initialize arrays for out-of-sample predictions and fold assignments
    oos_predictions = np.full(n, np.nan)
    fold_assignments = np.full(n, -1, dtype=np.int32)
    fold_rmses: list[float] = []
    fold_maes: list[float] = []

    # For GLM metrics
    is_binomial = spec.family == "binomial"
    fold_deviances: list[float] | None = [] if spec.family != "gaussian" else None
    fold_accuracies: list[float] | None = [] if is_binomial else None

    # Per-fold R² (gaussian) or pseudo-R² (non-gaussian)
    fold_r2s: list[float] | None = [] if spec.family == "gaussian" else None
    fold_pseudo_r2s: list[float] | None = [] if spec.family != "gaussian" else None

    # Binomial SDT metrics
    fold_sensitivities: list[float] | None = [] if is_binomial else None
    fold_specificities: list[float] | None = [] if is_binomial else None
    fold_f1s: list[float] | None = [] if is_binomial else None
    fold_aucs: list[float] | None = [] if is_binomial else None

    for fold_idx, (train_idx, test_idx) in enumerate(splits):
        # Track which fold each observation belongs to
        fold_assignments[test_idx] = fold_idx

        # Create train bundle
        X_train = bundle.X[train_idx]
        y_train = bundle.y[train_idx]
        X_test = bundle.X[test_idx]
        y_test = bundle.y[test_idx]

        # Handle random effects (if present)
        Z_train = None
        re_metadata_train = None
        if bundle.Z is not None and bundle.re_metadata is not None:
            re_metadata_train, Z_train = _subset_re_metadata(
                bundle.re_metadata, bundle.Z, train_idx
            )
        elif bundle.Z is not None:
            Z_train = bundle.Z[train_idx, :]

        train_bundle = DataBundleCls(
            X=X_train,
            y=y_train,
            X_names=bundle.X_names,
            y_name=bundle.y_name,
            valid_mask=np.ones(len(train_idx), dtype=bool),
            n_total=len(train_idx),
            Z=Z_train,
            re_metadata=re_metadata_train,
            factor_levels=bundle.factor_levels,
        )

        # Fit on training fold
        try:
            fold_fit = fit_model(spec, train_bundle)
        except Exception as exc:
            logger.warning("Fold %d/%d failed: %s", fold_idx + 1, k_int, exc)
            continue

        # Predict on test fold
        y_pred = X_test @ fold_fit.coef

        # Apply inverse link for GLMs
        if spec.family != "gaussian":
            from bossanova.internal.maths import family as family_module

            family_fn = getattr(family_module, spec.family)
            family = family_fn()
            y_pred = family.link_inverse(y_pred)

        # Store out-of-sample predictions
        oos_predictions[test_idx] = y_pred

        # Compute fold metrics
        residuals = y_test - y_pred
        fold_rmses.append(np.sqrt(np.mean(residuals**2)))
        fold_maes.append(np.mean(np.abs(residuals)))

        # GLM-specific metrics
        if fold_deviances is not None:
            from bossanova.internal.maths import family as family_module

            family_fn = getattr(family_module, spec.family)
            family = family_fn()
            dev = family.deviance(y_test, y_pred)
            fold_deviances.append(float(np.mean(dev)))

        if fold_accuracies is not None:
            y_pred_class = (y_pred >= 0.5).astype(float)
            accuracy = np.mean(y_pred_class == y_test)
            fold_accuracies.append(accuracy)

        # Per-fold R² (gaussian) or pseudo-R² (non-gaussian)
        if fold_r2s is not None:
            ss_res_fold = np.sum(residuals**2)
            ss_tot_fold = np.sum((y_test - np.mean(y_test)) ** 2)
            fold_r2s.append(
                float(1 - ss_res_fold / ss_tot_fold) if ss_tot_fold > 0 else 0.0
            )

        if fold_pseudo_r2s is not None:
            # McFadden's pseudo-R²: 1 - deviance_model / deviance_null
            from bossanova.internal.maths import family as family_module

            family_fn = getattr(family_module, spec.family)
            family = family_fn()

            y_test_mean = np.mean(y_test)
            if spec.family == "binomial":
                null_mu = np.clip(y_test_mean, 1e-10, 1 - 1e-10) * np.ones_like(y_test)
            elif spec.family == "poisson":
                null_mu = np.maximum(y_test_mean, 1e-10) * np.ones_like(y_test)
            else:
                null_mu = y_test_mean * np.ones_like(y_test)

            null_deviance = float(np.sum(family.deviance(y_test, null_mu)))
            fold_deviance_sum = float(np.sum(family.deviance(y_test, y_pred)))
            pseudo_r2 = (
                1 - (fold_deviance_sum / null_deviance) if null_deviance > 0 else 0.0
            )
            fold_pseudo_r2s.append(pseudo_r2)

        # Binomial SDT metrics
        if fold_sensitivities is not None:
            y_pred_class = (y_pred >= 0.5).astype(float)
            tp = np.sum((y_pred_class == 1) & (y_test == 1))
            fp = np.sum((y_pred_class == 1) & (y_test == 0))
            fn = np.sum((y_pred_class == 0) & (y_test == 1))
            tn = np.sum((y_pred_class == 0) & (y_test == 0))

            sens = float(tp / (tp + fn)) if (tp + fn) > 0 else 0.0
            spec_val = float(tn / (tn + fp)) if (tn + fp) > 0 else 0.0
            prec = float(tp / (tp + fp)) if (tp + fp) > 0 else 0.0
            f1_val = (
                float(2 * prec * sens / (prec + sens)) if (prec + sens) > 0 else 0.0
            )

            fold_sensitivities.append(sens)
            fold_specificities.append(spec_val)
            fold_f1s.append(f1_val)

            # AUC via Mann-Whitney U statistic (no sklearn needed)
            n_pos = int(np.sum(y_test == 1))
            n_neg = len(y_test) - n_pos
            if n_pos > 0 and n_neg > 0:
                sorted_indices = np.argsort(y_pred)
                y_sorted = y_test[sorted_indices]
                ranks = np.arange(1, len(y_sorted) + 1, dtype=float)
                pos_rank_sum = float(np.sum(ranks[y_sorted == 1]))
                auc_val = (pos_rank_sum - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)
            else:
                auc_val = 0.5
            fold_aucs.append(float(auc_val))

    # Aggregate metrics across folds
    oos_residuals = bundle.y - oos_predictions

    # Handle NaN values in out-of-sample predictions
    valid_mask = ~np.isnan(oos_predictions)
    if not valid_mask.any():
        raise RuntimeError("Cross-validation failed: no valid predictions")

    y_valid = bundle.y[valid_mask]
    resid_valid = oos_residuals[valid_mask]

    # Overall out-of-sample metrics
    rmse = float(np.sqrt(np.mean(resid_valid**2)))
    mae = float(np.mean(np.abs(resid_valid)))

    # R² computed on out-of-sample predictions
    ss_res = np.sum(resid_valid**2)
    ss_tot = np.sum((y_valid - np.mean(y_valid)) ** 2)
    r_squared = float(1 - ss_res / ss_tot) if ss_tot > 0 else 0.0

    # Aggregate GLM metrics
    deviance = float(np.mean(fold_deviances)) if fold_deviances else None
    accuracy = float(np.mean(fold_accuracies)) if fold_accuracies else None

    # Per-fold metrics
    fold_metrics = {
        "rmse": np.array(fold_rmses),
        "mae": np.array(fold_maes),
    }
    if fold_deviances is not None:
        fold_metrics["deviance"] = np.array(fold_deviances)
    if fold_accuracies is not None:
        fold_metrics["accuracy"] = np.array(fold_accuracies)
    if fold_r2s is not None:
        fold_metrics["r2"] = np.array(fold_r2s)
    if fold_pseudo_r2s is not None:
        fold_metrics["pseudo_r2"] = np.array(fold_pseudo_r2s)
    if fold_sensitivities is not None:
        fold_metrics["sensitivity"] = np.array(fold_sensitivities)
        fold_metrics["specificity"] = np.array(fold_specificities)
        fold_metrics["f1"] = np.array(fold_f1s)
        fold_metrics["auc"] = np.array(fold_aucs)

    # Aggregate SDT metrics
    sensitivity = float(np.mean(fold_sensitivities)) if fold_sensitivities else None
    specificity_agg = float(np.mean(fold_specificities)) if fold_specificities else None
    f1_agg = float(np.mean(fold_f1s)) if fold_f1s else None
    auc_agg = float(np.mean(fold_aucs)) if fold_aucs else None

    return build_cv_state(
        k=k_int,
        rmse=rmse,
        mae=mae,
        r_squared=r_squared,
        deviance=deviance,
        accuracy=accuracy,
        sensitivity=sensitivity,
        specificity=specificity_agg,
        f1=f1_agg,
        auc=auc_agg,
        fold_metrics=fold_metrics,
        oos_predictions=oos_predictions,
        oos_residuals=oos_residuals,
        fold_assignments=fold_assignments,
    )


def compute_params_cv_inference(
    spec: "ModelSpec",
    bundle: "DataBundle",
    data: "pl.DataFrame",
    conf_level: float,
    *,
    link_override: str | None = None,
    k: int | str = 10,
    seed: int | None = None,
) -> tuple["InferenceState", "CVState"]:
    """Compute CV-based parameter importance via ablation.

    Operates at the **source term** level rather than the design matrix column
    level.  For each source term (excluding Intercept):

    1. Build an ablated formula from the remaining source terms (plus any
       random effects).  Main-effect ablation also removes interactions that
       contain that effect (hierarchical principle).
    2. Fit the ablated model and run k-fold CV.
    3. PRE = full_metric − ablated_metric per fold.
    4. Broadcast the per-term PRE to every design matrix column that belongs
       to that source term.

    A positive PRE value means the predictor reduces prediction error
    (improves model fit).

    Args:
        spec: Model specification for the full model.
        bundle: Data bundle for the full model.
        data: Original data frame (polars DataFrame).
        conf_level: Confidence level (kept for API consistency).
        link_override: Non-default link function override (None uses spec default).
        k: Number of folds for cross-validation (default 10).
        seed: Random seed for reproducibility.

    Returns:
        Tuple of (InferenceState with pre and pre_sd arrays, CVState with
        full-model cross-validation metrics).

    Examples:
        >>> m = model("y ~ x + z", data).fit().infer(how="cv")
        >>> m.params  # Includes pre, pre_sd columns
        >>> m.diagnostics  # Includes cv_rmse, cv_mae, cv_rsquared
    """
    from bossanova.internal.containers import build_inference_state
    from bossanova.internal.infer.formula_utils import build_ablated_formula
    from bossanova.internal.marginal.joint_tests import get_term_from_coef

    # Run CV on full model
    full_cv = compute_cv_metrics(spec, bundle, k=k, seed=seed)

    # Select metric based on family: R² for gaussian, pseudo-R² for GLMs
    metric_key = "r2" if spec.family == "gaussian" else "pseudo_r2"
    full_fold_metric = full_cv.fold_metrics[metric_key]

    # --- Map each X_name column to its source term ---
    col_names = list(bundle.X_names)
    n_cols = len(col_names)

    col_to_source: dict[str, str] = {}
    for col in col_names:
        source = get_term_from_coef(col) or col
        col_to_source[col] = source

    # Unique source terms preserving first-seen order, excluding Intercept
    seen: set[str] = set()
    source_terms: list[str] = []
    for col in col_names:
        src = col_to_source[col]
        if src.lower() != "intercept" and src not in seen:
            seen.add(src)
            source_terms.append(src)

    # --- Per-source-term ablation ---
    term_pre: dict[str, float] = {}
    term_pre_sd: dict[str, float] = {}

    for src_term in source_terms:
        ablated_formula = build_ablated_formula(
            response_var=spec.response_var,
            source_terms=source_terms,
            ablate_term=src_term,
            random_terms=spec.random_terms,
        )

        try:
            # Lazy import to avoid circular dependency
            from bossanova.model.core import model

            ablated_model = model(
                ablated_formula,
                data,
                family=spec.family,
                link=link_override if link_override is not None else spec.link,
                method=spec.method,
            ).fit()
            ablated_cv = compute_cv_metrics(
                ablated_model._spec, ablated_model._bundle, k=k, seed=seed
            )
            ablated_fold_metric = ablated_cv.fold_metrics[metric_key]

            # Per-fold PRE: difference in R²/pseudo-R² between full and ablated
            pre_per_fold = full_fold_metric - ablated_fold_metric
            term_pre[src_term] = float(np.mean(pre_per_fold))
            term_pre_sd[src_term] = float(np.std(pre_per_fold, ddof=1))
        except Exception:
            logger.debug("CV ablation failed for term '%s', setting PRE=0", src_term)
            term_pre[src_term] = 0.0
            term_pre_sd[src_term] = 0.0

    # --- Broadcast source-term PRE to every column ---
    pre = np.zeros(n_cols)
    pre_sd = np.zeros(n_cols)
    for i, col in enumerate(col_names):
        src = col_to_source[col]
        if src.lower() == "intercept":
            continue
        pre[i] = term_pre.get(src, 0.0)
        pre_sd[i] = term_pre_sd.get(src, 0.0)

    inference = build_inference_state(
        se=np.full(n_cols, np.nan),
        statistic=np.full(n_cols, np.nan),
        df=np.full(n_cols, np.nan),
        p_value=np.full(n_cols, np.nan),
        ci_lower=np.full(n_cols, np.nan),
        ci_upper=np.full(n_cols, np.nan),
        conf_level=conf_level,
        method="cv",
        pre=pre,
        pre_sd=pre_sd,
    )
    return inference, full_cv
