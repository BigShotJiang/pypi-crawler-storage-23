"""Result containers for resampling procedures."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

import numpy as np
import polars as pl

if TYPE_CHECKING:
    from jax import Array

__all__ = [
    "BootstrapResult",
]


@dataclass(frozen=True, slots=True)
class BootstrapResult:
    """Results from a bootstrap procedure.

    Attributes:
        observed: Observed statistics, shape [n_params].
        boot_samples: Bootstrap samples, shape [n_boot, n_params].
        ci_lower: Lower confidence bounds, shape [n_params].
        ci_upper: Upper confidence bounds, shape [n_params].
        param_names: Names of parameters.
        n_boot: Number of bootstrap samples.
        ci_type: Type of confidence interval ("percentile", "basic", or "bca").
        level: Confidence level (e.g., 0.95).
        term_types: Optional list indicating "fixef" or "ranef" for each parameter.
            Only populated for mixed model bootstrap with which="all".
    """

    observed: Array
    boot_samples: Array
    ci_lower: Array
    ci_upper: Array
    param_names: list[str]
    n_boot: int
    ci_type: Literal["percentile", "basic", "bca"]
    level: float
    term_types: list[str] | None = None

    @property
    def ci(self) -> tuple[Array, Array]:
        """Return confidence intervals as a tuple (lower, upper)."""
        return self.ci_lower, self.ci_upper

    @property
    def se(self) -> Array:
        """Bootstrap standard errors (std of boot_samples)."""
        return np.std(np.asarray(self.boot_samples), axis=0)

    def summary(self) -> str:
        """Generate a formatted summary of bootstrap results.

        Returns:
            Formatted summary table as string.
        """
        obs_np = np.asarray(self.observed)
        lower_np = np.asarray(self.ci_lower)
        upper_np = np.asarray(self.ci_upper)
        se_np = np.asarray(self.se)

        if obs_np.ndim == 0:
            obs_np = np.array([obs_np])
            lower_np = np.array([lower_np])
            upper_np = np.array([upper_np])
            se_np = np.array([se_np])

        n_params = len(obs_np)
        ci_percent = int(self.level * 100)

        lines = []
        lines.append("=" * 80)
        lines.append(f"Bootstrap Results ({self.ci_type} CI)")
        lines.append("=" * 80)
        lines.append(f"Number of bootstrap samples: {self.n_boot}")
        lines.append(f"Confidence level: {self.level:.1%}")
        lines.append("")
        lines.append(
            f"{'Parameter':<20} {'Observed':>12} {'Boot SE':>12} "
            f"{ci_percent}% CI Lower  {ci_percent}% CI Upper"
        )
        lines.append("-" * 80)

        for i in range(n_params):
            param_name = (
                self.param_names[i] if i < len(self.param_names) else f"param_{i}"
            )
            lines.append(
                f"{param_name:<20} {obs_np[i]:>12.6f} {se_np[i]:>12.6f} "
                f"{lower_np[i]:>12.6f}   {upper_np[i]:>12.6f}"
            )

        lines.append("-" * 80)
        lines.append(
            f"Note: Standard errors computed from {self.n_boot} bootstrap samples"
        )
        lines.append("=" * 80)

        return "\n".join(lines)

    def to_dataframe(self) -> pl.DataFrame:
        """Convert results to a polars DataFrame.

        Returns:
            DataFrame with columns [term, term_type, observed, se, ci_lower, ci_upper].
            The term_type column is included when available (mixed model bootstrap).
        """
        obs_np = np.asarray(self.observed)
        se_np = np.asarray(self.se)
        lower_np = np.asarray(self.ci_lower)
        upper_np = np.asarray(self.ci_upper)

        if obs_np.ndim == 0:
            obs_np = np.array([obs_np])
            se_np = np.array([se_np])
            lower_np = np.array([lower_np])
            upper_np = np.array([upper_np])

        data = {
            "term": self.param_names,
            "observed": obs_np,
            "se": se_np,
            "ci_lower": lower_np,
            "ci_upper": upper_np,
        }

        # Include term_type column when available (mixed model bootstrap)
        if self.term_types is not None:
            data["term_type"] = self.term_types

        return pl.DataFrame(data)
