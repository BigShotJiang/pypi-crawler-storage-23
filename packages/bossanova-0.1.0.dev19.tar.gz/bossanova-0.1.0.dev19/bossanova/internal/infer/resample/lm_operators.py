"""Linear model coefficient operator (hat-matrix trick).

Provides ``build_lm_coefficient_operator`` which pre-computes the expensive
factorization of (X'X) once and returns a lightweight function that maps
any response vector Y to OLS coefficients. Used by hypothesis property
tests (BS.4) and the generic bootstrap engine.
"""

from typing import Any, Callable, Literal

import numpy as np
import scipy.linalg as la

from bossanova.internal.maths.backend import get_backend

# Type alias for arrays (works with both JAX and NumPy)
Array = Any

__all__ = [
    "Array",
    "build_lm_coefficient_operator",
]


# =============================================================================
# Coefficient Operator (Hat-Matrix Trick)
# =============================================================================


def build_lm_coefficient_operator(
    X: Array,
    method: Literal["cholesky", "qr"] = "cholesky",
) -> Callable[[Array], Array]:
    """Create reusable linear operator Y -> coefficients.

    Precomputes and caches the expensive factorization. Returns a function
    that maps Y -> coefficients.

    This implements the "hat-matrix trick" for efficient permutation testing:
    For fixed design matrix X, coefficients are a linear map from Y -> beta_hat:
    beta_hat = (X'X)^-1 X'y. We precompute the factorization of (X'X) once
    and reuse it for all permuted/bootstrapped Y values.

    Args:
        X: Design matrix, shape (n, p).
        method: Factorization method.
            - 'cholesky': Uses Cholesky decomposition of X'X (faster, more stable).
            - 'qr': Uses QR decomposition of X (handles rank deficiency better).

    Returns:
        Function that maps Y (shape [n] or [n, m]) to coefficients.

    Examples:
        ```python
        X = np.array([[1, 2], [1, 3], [1, 4]])
        operator = build_lm_coefficient_operator(X)
        y = np.array([5, 8, 11])
        coef = operator(y)
        ```
    """
    backend = get_backend()

    if backend == "jax":
        import jax.numpy as jnp
        import jax.scipy.linalg as jsp

        X_jax = jnp.asarray(X)

        if method == "cholesky":
            XtX = X_jax.T @ X_jax
            L = jnp.linalg.cholesky(XtX)

            def apply_chol_jax(Y: Array) -> Array:
                Y_jax = jnp.asarray(Y)
                is_1d = Y_jax.ndim == 1
                if is_1d:
                    Y_jax = Y_jax[:, jnp.newaxis]

                XtY = X_jax.T @ Y_jax
                coef = jsp.cho_solve((L, True), XtY)

                if is_1d:
                    coef = jnp.squeeze(coef, axis=-1)
                return coef

            return apply_chol_jax

        elif method == "qr":
            Q, R = jnp.linalg.qr(X_jax)

            def apply_qr_jax(Y: Array) -> Array:
                Y_jax = jnp.asarray(Y)
                is_1d = Y_jax.ndim == 1
                if is_1d:
                    Y_jax = Y_jax[:, jnp.newaxis]

                QtY = Q.T @ Y_jax
                coef = jsp.solve_triangular(R, QtY, lower=False)

                if is_1d:
                    coef = jnp.squeeze(coef, axis=-1)
                return coef

            return apply_qr_jax

        else:
            raise ValueError(f"method must be 'cholesky' or 'qr', got {method}")

    else:
        # NumPy backend
        X_np = np.asarray(X)

        if method == "cholesky":
            XtX = X_np.T @ X_np
            L = la.cholesky(XtX, lower=True)

            def apply_chol_np(Y: Array) -> Array:
                Y_np = np.asarray(Y)
                is_1d = Y_np.ndim == 1
                if is_1d:
                    Y_np = Y_np[:, np.newaxis]

                XtY = X_np.T @ Y_np
                coef = la.cho_solve((L, True), XtY)

                if is_1d:
                    coef = np.squeeze(coef, axis=-1)
                return coef

            return apply_chol_np

        elif method == "qr":
            Q, R = la.qr(X_np, mode="economic")

            def apply_qr_np(Y: Array) -> Array:
                Y_np = np.asarray(Y)
                is_1d = Y_np.ndim == 1
                if is_1d:
                    Y_np = Y_np[:, np.newaxis]

                QtY = Q.T @ Y_np
                coef = la.solve_triangular(R, QtY, lower=False)

                if is_1d:
                    coef = np.squeeze(coef, axis=-1)
                return coef

            return apply_qr_np

        else:
            raise ValueError(f"method must be 'cholesky' or 'qr', got {method}")
