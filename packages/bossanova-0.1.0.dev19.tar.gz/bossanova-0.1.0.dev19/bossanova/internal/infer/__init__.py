"""Inference operations: asymptotic, bootstrap, permutation, cross-validation, profile, and simulation.

Call chain:
    model.infer() -> dispatch_infer() -> dispatch_{params,mee,prediction}_inference()
    Each dispatcher routes to the method-specific backend (asymptotic, bootstrap, etc.)
"""

from bossanova.internal.infer.asymptotic import (
    augment_spread_with_profile_ci,
    compute_params_asymptotic,
    compute_prediction_asymptotic,
)
from bossanova.internal.infer.bootstrap import (
    bootstrap_params,
    compute_bootstrap_pvalue,
    build_emm_reference_grid,
    compute_jackknife_coefs,
    compute_mee_bootstrap,
    compute_params_bootstrap,
    compute_params_bootstrap_mixed,
    compute_prediction_bootstrap,
)
from bossanova.internal.infer.mee import (
    dispatch_mee_inference,
)
from bossanova.internal.infer.satterthwaite_emm import (
    compute_satterthwaite_emm_df,
)
from bossanova.internal.infer.params import (
    dispatch_params_inference,
)
from bossanova.internal.infer.prediction import (
    dispatch_prediction_inference,
)
from bossanova.internal.infer.cv import (
    compute_cv_metrics,
    compute_params_cv_inference,
    group_kfold_split,
    kfold_split,
)
from bossanova.internal.infer.permutation import (
    compute_mee_permutation,
    compute_params_permutation,
)
from bossanova.internal.infer.profile import (
    compute_profile_inference,
)
from bossanova.internal.infer.simulation import (
    compute_simulation_inference,
)
from bossanova.internal.infer.dispatch import (
    InferResult,
    dispatch_infer,
)

__all__ = [
    "InferResult",
    "augment_spread_with_profile_ci",
    "bootstrap_params",
    "build_emm_reference_grid",
    "compute_bootstrap_pvalue",
    "compute_cv_metrics",
    "compute_jackknife_coefs",
    "compute_mee_bootstrap",
    "compute_mee_permutation",
    "compute_params_asymptotic",
    "compute_params_bootstrap",
    "compute_params_bootstrap_mixed",
    "compute_params_cv_inference",
    "compute_params_permutation",
    "compute_prediction_asymptotic",
    "compute_prediction_bootstrap",
    "compute_profile_inference",
    "compute_satterthwaite_emm_df",
    "compute_simulation_inference",
    "dispatch_infer",
    "dispatch_mee_inference",
    "dispatch_params_inference",
    "dispatch_prediction_inference",
    "group_kfold_split",
    "kfold_split",
]
