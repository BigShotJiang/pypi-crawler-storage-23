"""Simulation inference: summary statistics across simulation replicates.

For post-fit simulations (nsim=), computes per-observation mean, SD,
and quantiles across simulation columns. For pre-fit data generation,
returns a minimal state.

Internal exports:
    compute_simulation_inference: Summarize simulation replicates.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers.structs.state import SimulationInferenceState

__all__ = [
    "compute_simulation_inference",
]


def compute_simulation_inference(
    simulations: "pl.DataFrame",
    conf_level: float,
) -> "SimulationInferenceState":
    """Compute inference for simulations.

    For post-fit simulations (sim_1, sim_2, ...):
        Computes summary statistics across simulation replicates:
        - Mean and SD per observation across simulations
        - Quantiles (e.g., 2.5%, 97.5% for 95% interval)

    For pre-fit data generation:
        Returns a basic state indicating generated data.

    Args:
        simulations: DataFrame of simulation results. Post-fit simulations
            have columns named ``sim_1``, ``sim_2``, etc.
        conf_level: Confidence level for interval quantiles.

    Returns:
        SimulationInferenceState with summary statistics.
    """
    from bossanova.internal.containers import build_simulation_inference_state

    # Check if this is post-fit simulation (sim_1, sim_2, ...) or pre-fit
    is_post_fit = all(col.startswith("sim_") for col in simulations.columns)

    if is_post_fit:
        n_sims = len(simulations.columns)

        # Convert to numpy array: rows = observations, cols = simulations
        sim_array = simulations.to_numpy()

        # Compute per-observation statistics
        sim_mean = np.mean(sim_array, axis=1)
        sim_sd = np.std(sim_array, axis=1, ddof=1)

        # Compute quantiles based on conf_level
        alpha = 1 - conf_level
        lower_q = alpha / 2
        upper_q = 1 - alpha / 2

        # Use round() to avoid floating point issues
        sim_quantiles = {
            f"q{round(lower_q * 1000):03d}": np.quantile(sim_array, lower_q, axis=1),
            f"q{round(upper_q * 1000):03d}": np.quantile(sim_array, upper_q, axis=1),
            "q500": np.quantile(sim_array, 0.5, axis=1),  # median
        }

        return build_simulation_inference_state(
            sim_type="post_fit",
            n_sims=n_sims,
            sim_mean=sim_mean,
            sim_sd=sim_sd,
            sim_quantiles=sim_quantiles,
        )
    else:
        # Pre-fit data generation: simulation-first workflow
        return build_simulation_inference_state(
            sim_type="data_generation",
            n_sims=1,
        )
