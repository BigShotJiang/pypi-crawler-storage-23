"""Permutation inference for parameters and marginal effects.

Provides permutation test functions: permute the response variable, refit
the model, collect null distributions of test statistics, and compute
permutation p-values. Accepts containers and returns containers.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import evolve

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers import (
        DataBundle,
        FitState,
        InferenceState,
        MeeState,
        ModelSpec,
    )

__all__ = [
    "compute_mee_permutation",
    "compute_params_permutation",
]


# =============================================================================
# Helpers
# =============================================================================


def fit_with_permuted_y(
    spec: "ModelSpec",
    bundle: "DataBundle",
    y_perm: np.ndarray,
) -> "FitState":
    """Fit the model with a permuted response vector.

    Creates a temporary DataBundle with the permuted y and fits
    using the same model specification.

    Args:
        spec: Model specification.
        bundle: Original data bundle (provides X, names, etc.).
        y_perm: Permuted response vector.

    Returns:
        FitState from fitting with permuted response.
    """
    from bossanova.internal.containers import DataBundle as DataBundleCls
    from bossanova.internal.fit import fit_model

    bundle_perm = DataBundleCls(
        X=bundle.X,
        y=y_perm,
        X_names=bundle.X_names,
        y_name=bundle.y_name,
        valid_mask=bundle.valid_mask,
        n_total=bundle.n_total,
        Z=bundle.Z,
        re_metadata=bundle.re_metadata,
        factor_levels=bundle.factor_levels,
    )

    return fit_model(spec, bundle_perm)


def compute_emm_from_fit(
    bundle: "DataBundle",
    fit_state: "FitState",
    focal_var: str,
) -> tuple["pl.DataFrame", list[float]]:
    """Compute EMMs for a categorical focal variable from a FitState.

    Args:
        bundle: Data bundle with X_names and factor levels.
        fit_state: FitState to use for predictions.
        focal_var: The focal categorical variable.

    Returns:
        Tuple of (grid DataFrame, list of estimates).
    """
    from bossanova.internal.marginal import build_reference_grid

    grid = build_reference_grid(bundle, [focal_var])
    levels = grid[focal_var].to_list()

    estimates = []
    coef = fit_state.coef
    X_names = list(bundle.X_names)

    for level in levels:
        pred = coef[0]  # Intercept

        level_term = f"{focal_var}[{level}]"
        if level_term in X_names:
            idx = X_names.index(level_term)
            pred += coef[idx]

        estimates.append(pred)

    return grid, estimates


def compute_slope_from_fit(
    bundle: "DataBundle",
    fit_state: "FitState",
    focal_var: str,
) -> tuple["pl.DataFrame", list[float]]:
    """Compute marginal slope for a continuous focal variable from a FitState.

    Args:
        bundle: Data bundle with X_names.
        fit_state: FitState to use.
        focal_var: The focal continuous variable.

    Returns:
        Tuple of (grid DataFrame, list of slope estimates).
    """
    import polars as pl

    X_names = list(bundle.X_names)

    if focal_var in X_names:
        idx = X_names.index(focal_var)
        slope = fit_state.coef[idx]
    else:
        slope = float("nan")

    grid = pl.DataFrame({focal_var: ["marginal_effect"]})
    return grid, [slope]


def explore_with_fit(
    bundle: "DataBundle",
    data: "pl.DataFrame",
    fit_state: "FitState",
    explore_formula: str,
) -> "MeeState":
    """Compute marginal effects using a given FitState.

    Used by permutation inference to compute MEE on permuted fits.

    Args:
        bundle: Data bundle with X_names and factor levels.
        data: Original data frame (for detecting categorical variables).
        fit_state: FitState from a (possibly permuted) fit.
        explore_formula: The explore formula string.

    Returns:
        MeeState with estimates (no inference).
    """
    import polars as pl

    from bossanova.internal.containers import build_mee_state
    from bossanova.internal.marginal import parse_explore_formula

    parsed = parse_explore_formula(explore_formula)
    focal_var = parsed.focal_var

    col = data[focal_var]
    is_categorical = col.dtype == pl.Utf8 or col.n_unique() < 10

    if is_categorical:
        grid, estimate = compute_emm_from_fit(bundle, fit_state, focal_var)
        mee_type = "means"
    else:
        grid, estimate = compute_slope_from_fit(bundle, fit_state, focal_var)
        mee_type = "slopes"

    return build_mee_state(
        grid=grid,
        estimate=np.array(estimate),
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type=mee_type,
    )


# =============================================================================
# Public API
# =============================================================================


def compute_params_permutation(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    conf_level: float,
    n_perm: int = 1000,
    seed: int | None = None,
    save_resamples: bool = True,
    null: float = 0.0,
    alternative: str = "two-sided",
) -> "InferenceState":
    """Compute permutation-based inference for model parameters.

    Permutes the response variable to break the relationship with predictors,
    refits the model on each permutation, and computes p-values based on
    the null distribution of test statistics.

    Args:
        spec: Model specification.
        bundle: Data bundle with X, y, etc.
        fit: Fit state with coefficients and vcov.
        conf_level: Confidence level for intervals.
        n_perm: Number of permutations.
        seed: Random seed for reproducibility.
        save_resamples: If True (default), store null distribution
            in InferenceState. If False, discard to save memory.
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default "two-sided").

    Returns:
        InferenceState with permutation p-values and percentile CIs.
    """
    from bossanova.internal.containers import build_inference_state

    rng = np.random.default_rng(seed)

    # Get observed test statistics (using asymptotic SE for t-statistic)
    coef = fit.coef
    vcov = fit.vcov
    se_obs = np.sqrt(np.diag(vcov))
    t_obs = (coef - null) / se_obs

    n_coef = len(coef)

    # Store null distribution of coefficients and t-statistics
    null_coef = np.zeros((n_perm, n_coef))
    null_t = np.zeros((n_perm, n_coef))

    # Original y for permutation
    y_orig = bundle.y.copy()
    n_obs = len(y_orig)

    for i in range(n_perm):
        perm_idx = rng.permutation(n_obs)
        y_perm = y_orig[perm_idx]

        fit_perm = fit_with_permuted_y(spec, bundle, y_perm)

        null_coef[i, :] = fit_perm.coef
        null_t[i, :] = (fit_perm.coef - null) / se_obs

    # Permutation p-values based on alternative
    if alternative == "two-sided":
        p_values = np.mean(np.abs(null_t) >= np.abs(t_obs), axis=0)
    elif alternative == "greater":
        p_values = np.mean(null_t >= t_obs, axis=0)
    elif alternative == "less":
        p_values = np.mean(null_t <= t_obs, axis=0)
    else:
        raise ValueError(
            f"alternative must be 'two-sided', 'greater', or 'less', got {alternative!r}"
        )
    p_values = np.maximum(p_values, 1.0 / (n_perm + 1))

    # Percentile CIs from null distribution, shifted to center on observed
    alpha = 1 - conf_level
    ci_lower = np.percentile(null_coef, 100 * alpha / 2, axis=0)
    ci_upper = np.percentile(null_coef, 100 * (1 - alpha / 2), axis=0)

    null_width = ci_upper - ci_lower
    ci_lower = coef - null_width / 2
    ci_upper = coef + null_width / 2

    # Degrees of freedom: number of valid (non-NaN) permutation resamples
    # per coefficient.
    df = np.sum(~np.isnan(null_coef), axis=0).astype(float)

    return build_inference_state(
        se=se_obs,
        statistic=t_obs,
        df=df,
        p_value=p_values,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
        method="perm",
        null=null,
        alternative=alternative,
        n_resamples=n_perm,
        perm_samples=null_t if save_resamples else None,
    )


def compute_mee_permutation(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    mee: "MeeState",
    data: "pl.DataFrame",
    conf_level: float,
    se_obs: np.ndarray,
    n_perm: int = 1000,
    seed: int | None = None,
    null: float = 0.0,
    alternative: str = "two-sided",
    save_resamples: bool = True,
) -> "tuple[MeeState, np.ndarray | None]":
    """Compute permutation-based inference for marginal effects.

    Permutes the response variable, refits and re-explores on each
    permutation, and computes p-values based on the null distribution.

    Args:
        spec: Model specification.
        bundle: Data bundle with X, y, etc.
        fit: Fit state with coefficients.
        mee: Current MeeState with observed estimates.
        data: Original data frame (for categorical detection).
        conf_level: Confidence level for intervals.
        se_obs: Pre-computed standard errors for t-statistic denominator
            (from asymptotic SE computation in the model class).
        n_perm: Number of permutations.
        seed: Random seed for reproducibility.
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default "two-sided").
        save_resamples: If True (default), return null t-statistics alongside
            the MeeState. If False, discard to save memory.

    Returns:
        Tuple of (MeeState augmented with permutation inference,
        null t-statistics array or None).
    """
    rng = np.random.default_rng(seed)

    estimate_obs = mee.estimate
    n_estimates = len(estimate_obs)

    # Compute observed t-statistics: (estimate - null) / se
    centered = estimate_obs - null
    t_obs = np.divide(
        centered,
        se_obs,
        out=np.full_like(estimate_obs, np.nan),
        where=se_obs != 0,
    )

    # Store null distribution
    null_estimates = np.zeros((n_perm, n_estimates))

    y_orig = bundle.y.copy()
    n_obs = len(y_orig)
    explore_formula = mee.explore_formula

    # Use L_matrix projection when available (handles multi-row slopes
    # correctly); fall back to explore_with_fit for legacy MeeStates.
    L_matrix = mee.L_matrix

    for i in range(n_perm):
        perm_idx = rng.permutation(n_obs)
        y_perm = y_orig[perm_idx]

        fit_perm = fit_with_permuted_y(spec, bundle, y_perm)

        if L_matrix is not None:
            null_estimates[i, :] = L_matrix @ fit_perm.coef
        else:
            mee_perm = explore_with_fit(bundle, data, fit_perm, explore_formula)
            null_estimates[i, :] = mee_perm.estimate

    # Compute null t-statistics: (estimate - null) / se
    null_t = np.zeros((n_perm, n_estimates))
    for i in range(n_perm):
        null_t[i, :] = np.divide(
            null_estimates[i, :] - null,
            se_obs,
            out=np.full(n_estimates, np.nan),
            where=se_obs != 0,
        )

    # Permutation p-values based on alternative
    if alternative == "two-sided":
        p_values = np.mean(np.abs(null_t) >= np.abs(t_obs), axis=0)
    elif alternative == "greater":
        p_values = np.mean(null_t >= t_obs, axis=0)
    elif alternative == "less":
        p_values = np.mean(null_t <= t_obs, axis=0)
    else:
        raise ValueError(
            f"alternative must be 'two-sided', 'greater', or 'less', got {alternative!r}"
        )
    p_values = np.maximum(p_values, 1.0 / (n_perm + 1))

    # Percentile CIs, shifted to center on observed
    alpha = 1 - conf_level
    ci_lower = np.percentile(null_estimates, 100 * alpha / 2, axis=0)
    ci_upper = np.percentile(null_estimates, 100 * (1 - alpha / 2), axis=0)

    null_width = ci_upper - ci_lower
    ci_lower = estimate_obs - null_width / 2
    ci_upper = estimate_obs + null_width / 2

    # Degrees of freedom: number of valid (non-NaN) permutation resamples
    # per estimate.
    df = np.sum(~np.isnan(null_estimates), axis=0).astype(float)

    augmented = evolve(
        mee,
        se=se_obs,
        df=df,
        statistic=t_obs,
        p_value=p_values,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
    )
    return augmented, null_t if save_resamples else None
