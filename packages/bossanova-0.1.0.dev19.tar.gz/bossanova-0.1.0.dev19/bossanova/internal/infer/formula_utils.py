"""Formula utility functions shared across operations modules."""

import re

__all__ = [
    "build_ablated_formula",
    "parse_value",
    "remove_predictor_from_formula",
]


def build_ablated_formula(
    response_var: str,
    source_terms: list[str],
    ablate_term: str,
    random_terms: tuple[str, ...] = (),
) -> str:
    """Build a formula with one source term ablated.

    For main effects, also removes interactions containing that term
    (hierarchical principle). For interactions, removes only that
    interaction.

    Args:
        response_var: Name of the response variable.
        source_terms: All source terms (excluding Intercept) in the model.
        ablate_term: The term to remove.
        random_terms: Random effect terms (e.g., ``("(1|group)",)``).

    Returns:
        Formula string with the ablated term removed.

    Examples:
        >>> build_ablated_formula("y", ["x", "z", "x:z"], "x")
        'y ~ z'
        >>> build_ablated_formula("y", ["x", "z", "x:z"], "x:z")
        'y ~ x + z'
        >>> build_ablated_formula("y", ["x"], "x")
        'y ~ 1'
        >>> build_ablated_formula("y", ["x", "z"], "x", ("(1|group)",))
        'y ~ z + (1|group)'
    """
    if ":" in ablate_term:
        # Interaction: remove only that specific interaction
        remaining = [t for t in source_terms if t != ablate_term]
    else:
        # Main effect: also remove interactions containing it (hierarchical)
        remaining = [
            t
            for t in source_terms
            if t != ablate_term and ablate_term not in t.split(":")
        ]

    rhs_parts = remaining if remaining else ["1"]
    rhs_parts = rhs_parts + list(random_terms)
    return f"{response_var} ~ {' + '.join(rhs_parts)}"


def parse_value(s: str) -> float | str:
    """Parse a single value as float or string.

    Tries to parse as float first; falls back to unquoted or quoted string.

    Args:
        s: String to parse.

    Returns:
        Parsed value as float or string.

    Raises:
        ValueError: If the string is empty.

    Examples:
        >>> parse_value("3.14")
        3.14
        >>> parse_value("hello")
        'hello'
        >>> parse_value("'quoted'")
        'quoted'
    """
    s = s.strip()
    if not s:
        raise ValueError("Empty value")

    # Try to parse as number
    try:
        return float(s)
    except ValueError:
        pass

    # Remove quotes if present
    if (s.startswith('"') and s.endswith('"')) or (
        s.startswith("'") and s.endswith("'")
    ):
        return s[1:-1]

    # Return as-is (unquoted string, e.g., factor level)
    return s


def remove_predictor_from_formula(formula: str, predictor: str) -> str:
    """Remove a predictor term from a formula string.

    Handles various predictor formats including raw names, factor(), C(), c().

    Args:
        formula: R-style formula string (e.g., "y ~ x1 + x2").
        predictor: Name of predictor to remove.

    Returns:
        Modified formula with predictor removed, or original if removal fails.

    Examples:
        ```python
        remove_predictor_from_formula("y ~ a + b + c", "b")
        # 'y ~ a + c'
        remove_predictor_from_formula("y ~ factor(a) + b", "a")
        # 'y ~ b'
        ```
    """
    parts = formula.split("~")
    if len(parts) != 2:
        return formula

    lhs, rhs = parts[0].strip(), parts[1].strip()

    # Patterns to match: factor(pred), C(pred), c(pred), or raw pred
    patterns = [
        rf"\bfactor\({re.escape(predictor)}\)",
        rf"\bC\({re.escape(predictor)}\)",
        rf"\bc\({re.escape(predictor)}\)",
        rf"\b{re.escape(predictor)}\b",
    ]

    new_rhs = rhs
    for pattern in patterns:
        # Remove " + term" or "term + "
        new_rhs = re.sub(rf"\s*\+\s*{pattern}", "", new_rhs)
        new_rhs = re.sub(rf"{pattern}\s*\+\s*", "", new_rhs)
        # Remove standalone term
        new_rhs = re.sub(pattern, "", new_rhs)

    # Clean up whitespace and extra + signs
    new_rhs = re.sub(r"\s+", " ", new_rhs).strip()
    new_rhs = re.sub(r"\+\s*\+", "+", new_rhs)
    new_rhs = new_rhs.strip("+ ")

    # If nothing changed, return original
    if new_rhs == rhs:
        return formula

    # If RHS is empty after removal, use intercept-only model
    if not new_rhs:
        return f"{lhs} ~ 1"

    return f"{lhs} ~ {new_rhs}"
