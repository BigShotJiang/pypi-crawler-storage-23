"""Discrete distributions for simulation-first workflows.

Provides frozen attrs classes for discrete probability distributions
used in model.simulate() to generate factor/categorical predictor variables
and count data.

Example:
    Simulation-first workflow with factors::

        from bossanova import model
        from bossanova.distributions import categorical, poisson

        m = model("y ~ factor(treatment)")
        m.simulate(
            n=100,
            treatment=categorical(["Control", "Drug_A", "Drug_B"]),
            coef={"Intercept": 0, "treatment[Drug_A]": 0.5, "treatment[Drug_B]": 0.8},
        )

        # With custom probabilities (unbalanced design)
        m.simulate(
            n=100,
            treatment=categorical(["Control", "Drug_A"], p=[0.7, 0.3]),
            coef={"Intercept": 0, "treatment[Drug_A]": 0.5},
        )

    Count data with Poisson::

        from bossanova.distributions import poisson

        m = model("y ~ x", family="poisson")
        m.simulate(n=100, x=poisson(rate=5.0))
"""

from attrs import frozen, field, validators
import numpy as np


@frozen
class Categorical:
    """Categorical distribution for simulation.

    Generates categorical values from specified levels with optional probabilities.

    Args:
        levels (tuple[str, ...] | None): Category names. Either provide explicit
            levels or use k= for auto-naming.
        p (tuple[float, ...] | None): Probabilities for each level. Must sum to 1.
            If None, uniform distribution.
        k (int | None): Number of levels for auto-naming (level_1, level_2, ...).
            Ignored if levels is provided.

    Examples:
        >>> from bossanova.distributions import categorical
        >>> cat = categorical(levels=["A", "B", "C"])
        >>> rng = np.random.default_rng(42)
        >>> samples = cat.sample(5, rng)
        >>> samples.shape
        (5,)

        >>> cat = categorical(levels=["A", "B"], p=[0.8, 0.2])
        >>> # Mostly generates "A"

        >>> cat = categorical(k=4)  # Auto: level_1, level_2, level_3, level_4
    """

    levels: tuple[str, ...] | None = field(
        default=None, converter=lambda x: tuple(x) if x is not None else None
    )
    p: tuple[float, ...] | None = field(
        default=None, converter=lambda x: tuple(x) if x is not None else None
    )
    k: int | None = field(default=None)

    def __attrs_post_init__(self):
        """Validate that levels/k and p are consistent."""
        # Must have either levels or k
        if self.levels is None and self.k is None:
            msg = "Must specify either levels or k"
            raise ValueError(msg)
        if self.levels is not None and self.k is not None:
            msg = "Specify either levels or k, not both"
            raise ValueError(msg)

        # Validate p if provided
        if self.p is not None:
            if self.levels is None:
                msg = "p requires levels to be specified"
                raise ValueError(msg)
            if len(self.p) != len(self.levels):
                msg = f"p length ({len(self.p)}) must match levels length ({len(self.levels)})"
                raise ValueError(msg)
            if not np.isclose(sum(self.p), 1.0):
                msg = f"p must sum to 1.0, got {sum(self.p)}"
                raise ValueError(msg)

    @property
    def actual_levels(self) -> tuple[str, ...]:
        """Return the actual level names (resolving k if needed)."""
        if self.levels is not None:
            return self.levels
        return tuple(f"level_{i + 1}" for i in range(self.k))

    @property
    def n_levels(self) -> int:
        """Return the number of levels."""
        return len(self.actual_levels)

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Sample n categorical values.

        Args:
            n (int): Number of samples to draw.
            rng (np.random.Generator): NumPy random number generator.

        Returns:
            Array of n categorical values as strings.
        """
        levels = self.actual_levels
        probs = self.p if self.p is not None else None
        indices = rng.choice(len(levels), size=n, p=probs)
        return np.array([levels[i] for i in indices])


# =============================================================================
# Factory functions (user-facing API)
# =============================================================================


def categorical(
    levels: list[str] | None = None,
    *,
    p: list[float] | None = None,
    k: int | None = None,
) -> Categorical:
    """Create a categorical distribution.

    Args:
        levels (list[str] | None): Category names.
        p (list[float] | None): Probabilities (must sum to 1).
        k (int | None): Number of auto-named levels.

    Returns:
        Categorical distribution object.

    Examples:
        >>> categorical(["A", "B", "C"])
        Categorical(levels=('A', 'B', 'C'), p=None, k=None)
        >>> categorical(["A", "B"], p=[0.7, 0.3])
        Categorical(levels=('A', 'B'), p=(0.7, 0.3), k=None)
        >>> categorical(k=4)  # level_1, level_2, level_3, level_4
        Categorical(levels=None, p=None, k=4)
    """
    return Categorical(levels=levels, p=p, k=k)


@frozen
class Poisson:
    """Poisson distribution for count data simulation.

    Generates non-negative integer counts with mean equal to rate (lambda).

    Args:
        rate (float): Rate parameter (lambda). Must be > 0. Default is 1.0.

    Examples:
        >>> from bossanova.distributions import poisson
        >>> dist = poisson(rate=5.0)
        >>> rng = np.random.default_rng(42)
        >>> samples = dist.sample(100, rng)
        >>> samples.shape
        (100,)
        >>> samples.dtype
        dtype('int64')
    """

    rate: float = field(default=1.0, validator=validators.gt(0))

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Draw samples from the distribution.

        Args:
            n (int): Number of samples to draw.
            rng (np.random.Generator): NumPy random number generator.

        Returns:
            Array of n non-negative integer samples from Poisson(rate).
        """
        return rng.poisson(self.rate, n)


def poisson(rate: float = 1.0) -> Poisson:
    """Create a Poisson distribution for count data.

    Args:
        rate (float): Rate parameter (lambda). Must be > 0. Default is 1.0.
            The mean and variance of the distribution both equal rate.

    Returns:
        Poisson distribution specification.

    Examples:
        >>> dist = poisson()  # Poisson(1)
        >>> dist = poisson(rate=5.0)  # Poisson(5), mean = 5
    """
    return Poisson(rate=rate)


@frozen
class Binomial:
    """Binomial distribution for binary/count data simulation.

    Generates non-negative integer counts representing the number of successes
    in n independent Bernoulli trials, each with success probability p.

    Args:
        n (int): Number of trials. Must be >= 1. Default is 1 (Bernoulli).
        p (float): Probability of success per trial. Must be in [0, 1].
            Default is 0.5.

    Examples:
        >>> from bossanova.distributions import binomial
        >>> dist = binomial(n=10, p=0.3)
        >>> rng = np.random.default_rng(42)
        >>> samples = dist.sample(100, rng)
        >>> samples.shape
        (100,)
        >>> all((samples >= 0) & (samples <= 10))
        True

        >>> # Bernoulli (single trial) as special case
        >>> dist = binomial()  # n=1, p=0.5
        >>> samples = dist.sample(100, rng)
        >>> set(np.unique(samples)).issubset({0, 1})
        True
    """

    n: int = field(default=1, validator=validators.ge(1))
    p: float = field(default=0.5)

    @p.validator
    def _check_p(self, attribute, value):
        if value < 0 or value > 1:
            raise ValueError(f"p ({value}) must be in [0, 1]")

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Draw samples from the distribution.

        Args:
            n (int): Number of samples to draw.
            rng (np.random.Generator): NumPy random number generator.

        Returns:
            Array of n non-negative integer samples from Binomial(n, p).
        """
        return rng.binomial(self.n, self.p, n)


def binomial(n: int = 1, p: float = 0.5) -> Binomial:
    """Create a binomial distribution.

    Args:
        n (int): Number of trials. Must be >= 1. Default is 1 (Bernoulli trial).
        p (float): Probability of success per trial. Must be in [0, 1].
            Default is 0.5.

    Returns:
        Binomial distribution specification.

    Examples:
        >>> dist = binomial()  # Bernoulli(0.5)
        >>> dist = binomial(n=10, p=0.3)  # Binomial(10, 0.3), mean = 3
    """
    return Binomial(n=n, p=p)
