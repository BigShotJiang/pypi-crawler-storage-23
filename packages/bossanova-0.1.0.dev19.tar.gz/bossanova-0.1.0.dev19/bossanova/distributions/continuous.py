"""Continuous probability distributions for simulation-first workflows."""

from attrs import frozen, field, validators
import numpy as np


@frozen
class Normal:
    """Normal (Gaussian) distribution for simulation.

    Args:
        mean (float): Distribution mean (location parameter).
        sd (float): Standard deviation (scale parameter). Must be > 0.

    Examples:
        >>> from bossanova.distributions import normal
        >>> dist = normal(mean=0, sd=1)
        >>> rng = np.random.default_rng(42)
        >>> samples = dist.sample(100, rng)
        >>> samples.shape
        (100,)
    """

    mean: float = field(default=0.0)
    sd: float = field(default=1.0, validator=validators.gt(0))

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Draw samples from the distribution.

        Args:
            n (int): Number of samples to draw.
            rng (np.random.Generator): NumPy random number generator.

        Returns:
            Array of n samples from N(mean, sd^2).
        """
        return rng.normal(self.mean, self.sd, n)


@frozen
class Uniform:
    """Uniform distribution for simulation.

    Args:
        low (float): Lower bound of the distribution.
        high (float): Upper bound of the distribution. Must be > low.

    Examples:
        >>> from bossanova.distributions import uniform
        >>> dist = uniform(low=0, high=10)
        >>> rng = np.random.default_rng(42)
        >>> samples = dist.sample(100, rng)
        >>> all((samples >= 0) & (samples <= 10))
        True
    """

    low: float = field(default=0.0)
    high: float = field(default=1.0)

    @high.validator
    def _check_high(self, attribute, value):
        if value <= self.low:
            raise ValueError(f"high ({value}) must be > low ({self.low})")

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Draw samples from the distribution.

        Args:
            n (int): Number of samples to draw.
            rng (np.random.Generator): NumPy random number generator.

        Returns:
            Array of n samples from Uniform(low, high).
        """
        return rng.uniform(self.low, self.high, n)


@frozen
class Exponential:
    """Exponential distribution for simulation.

    Parameterized by rate (lambda), not scale. This matches the common
    statistical convention where E[X] = 1/rate.

    Args:
        rate (float): Rate parameter (lambda). Must be > 0. Mean is 1/rate.

    Examples:
        >>> from bossanova.distributions import exponential
        >>> dist = exponential(rate=2.0)  # Mean = 0.5
        >>> rng = np.random.default_rng(42)
        >>> samples = dist.sample(1000, rng)
        >>> abs(samples.mean() - 0.5) < 0.1  # Approximate mean check
        True
    """

    rate: float = field(default=1.0, validator=validators.gt(0))

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Draw samples from the distribution.

        Args:
            n (int): Number of samples to draw.
            rng (np.random.Generator): NumPy random number generator.

        Returns:
            Array of n samples from Exponential(rate).
        """
        return rng.exponential(1.0 / self.rate, n)


@frozen
class Gamma:
    """Gamma distribution for simulation.

    Parameterized by shape (k) and scale (theta), where E[X] = shape * scale.

    Args:
        shape (float): Shape parameter (k). Must be > 0.
        scale (float): Scale parameter (theta). Must be > 0. Default is 1.0.

    Examples:
        >>> from bossanova.distributions import gamma
        >>> dist = gamma(shape=2.0, scale=1.0)  # Mean = 2.0
        >>> rng = np.random.default_rng(42)
        >>> samples = dist.sample(1000, rng)
        >>> abs(samples.mean() - 2.0) < 0.2  # Approximate mean check
        True
    """

    shape: float = field(validator=validators.gt(0))
    scale: float = field(default=1.0, validator=validators.gt(0))

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Draw samples from the distribution.

        Args:
            n (int): Number of samples to draw.
            rng (np.random.Generator): NumPy random number generator.

        Returns:
            Array of n samples from Gamma(shape, scale).
        """
        return rng.gamma(self.shape, self.scale, n)


@frozen
class T:
    """Student's t distribution for simulation.

    Location-scale parameterization: X = loc + scale * T(df).
    When loc=0 and scale=1, this is the standard t-distribution.

    Args:
        df (float): Degrees of freedom. Must be > 0.
        loc (float): Location parameter (shift). Default is 0.0.
        scale (float): Scale parameter. Must be > 0. Default is 1.0.

    Examples:
        >>> from bossanova.distributions import t
        >>> dist = t(df=10, loc=0, scale=1)
        >>> rng = np.random.default_rng(42)
        >>> samples = dist.sample(1000, rng)
        >>> abs(samples.mean()) < 0.1  # Should be near 0
        True
    """

    df: float = field(validator=validators.gt(0))
    loc: float = field(default=0.0)
    scale: float = field(default=1.0, validator=validators.gt(0))

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Draw samples from the distribution.

        Args:
            n (int): Number of samples to draw.
            rng (np.random.Generator): NumPy random number generator.

        Returns:
            Array of n samples from loc + scale * T(df).
        """
        return self.loc + self.scale * rng.standard_t(self.df, n)


# =============================================================================
# Factory functions (user-facing API)
# =============================================================================


def normal(mean: float = 0.0, sd: float = 1.0) -> Normal:
    """Create a normal distribution.

    Args:
        mean (float): Distribution mean (location parameter). Default is 0.0.
        sd (float): Standard deviation (scale parameter). Must be > 0. Default is 1.0.

    Returns:
        Normal distribution specification.

    Examples:
        >>> dist = normal()  # Standard normal N(0, 1)
        >>> dist = normal(mean=5, sd=2)  # N(5, 4)
    """
    return Normal(mean=mean, sd=sd)


def uniform(low: float = 0.0, high: float = 1.0) -> Uniform:
    """Create a uniform distribution.

    Args:
        low (float): Lower bound of the distribution. Default is 0.0.
        high (float): Upper bound of the distribution. Must be > low. Default is 1.0.

    Returns:
        Uniform distribution specification.

    Examples:
        >>> dist = uniform()  # Uniform(0, 1)
        >>> dist = uniform(low=-1, high=1)  # Uniform(-1, 1)
    """
    return Uniform(low=low, high=high)


def exponential(rate: float = 1.0) -> Exponential:
    """Create an exponential distribution.

    Args:
        rate (float): Rate parameter (lambda). Must be > 0. Mean is 1/rate.
            Default is 1.0.

    Returns:
        Exponential distribution specification.

    Examples:
        >>> dist = exponential()  # Exponential(1), mean = 1
        >>> dist = exponential(rate=0.5)  # Exponential(0.5), mean = 2
    """
    return Exponential(rate=rate)


def gamma(shape: float, scale: float = 1.0) -> Gamma:
    """Create a gamma distribution.

    Args:
        shape (float): Shape parameter (k). Must be > 0.
        scale (float): Scale parameter (theta). Must be > 0. Default is 1.0.

    Returns:
        Gamma distribution specification.

    Examples:
        >>> dist = gamma(shape=2.0)  # Gamma(2, 1), mean = 2
        >>> dist = gamma(shape=2.0, scale=0.5)  # Gamma(2, 0.5), mean = 1
    """
    return Gamma(shape=shape, scale=scale)


def t(df: float, loc: float = 0.0, scale: float = 1.0) -> T:
    """Create a Student's t distribution.

    Args:
        df (float): Degrees of freedom. Must be > 0.
        loc (float): Location parameter (shift). Default is 0.0.
        scale (float): Scale parameter. Must be > 0. Default is 1.0.

    Returns:
        Student's t distribution specification.

    Examples:
        >>> dist = t(df=10)  # Standard t with 10 df
        >>> dist = t(df=5, loc=1, scale=2)  # Location-scale t
    """
    return T(df=df, loc=loc, scale=scale)
