"""Distribution factories for simulation-first workflows via model.simulate()."""

from bossanova.distributions.continuous import (
    # Classes (for type annotations)
    Exponential,
    Gamma,
    Normal,
    T,
    Uniform,
    # Factory functions (user-facing API)
    exponential,
    gamma,
    normal,
    t,
    uniform,
)
from bossanova.distributions.discrete import (
    # Classes (for type annotations)
    Binomial,
    Categorical,
    Poisson,
    # Factory functions (user-facing API)
    binomial,
    categorical,
    poisson,
)
from bossanova.distributions.varying import (
    # Class (for type annotations)
    Varying,
    # Factory function (user-facing API)
    varying,
)

__all__ = [
    "Binomial",
    "Categorical",
    "Exponential",
    "Gamma",
    "Normal",
    "Poisson",
    "T",
    "Uniform",
    "Varying",
    "binomial",
    "categorical",
    "exponential",
    "gamma",
    "normal",
    "poisson",
    "t",
    "uniform",
    "varying",
]
