"""Unified model class for bossanova."""

from bossanova.model.core import ModelStateError as ModelStateError
from bossanova.model.core import model
from bossanova.model.result import ModelResult as ModelResult

__all__ = ["ModelResult", "ModelStateError", "model"]
