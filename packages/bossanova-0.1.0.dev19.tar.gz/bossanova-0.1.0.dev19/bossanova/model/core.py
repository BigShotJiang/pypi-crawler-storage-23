"""Core user-facing model class."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar, Literal, Self

from bossanova.model.result import ModelResult

import polars as pl
from attrs import define, field, setters, validators

from bossanova.internal.containers import (
    FAMILIES,
    CVState,
    DataBundle,
    FitState,
    InferenceState,
    JointTestState,
    MeeState,
    ModelSpec,
    PredictionState,
    ProfileState,
    ResamplesState,
    SimulationInferenceState,
    VaryingSpreadState,
    VaryingState,
    build_effects_dataframe,
    build_joint_test_dataframe,
    build_model_spec_from_formula,
    build_params_dataframe,
    build_predictions_dataframe,
    build_resamples_dataframe,
    build_simulations_dataframe,
    build_varying_corr_dataframe,
    build_varying_offsets_dataframe,
    build_varying_params_dataframe,
    build_varying_spread_dataframe,
)
from bossanova.internal.containers.validators import normalize_conf_level
from bossanova.internal.maths.config import get_display_digits
from bossanova.internal.maths.rounding import round_float_columns
from bossanova.model.guards import (
    ModelStateError,
    requires_data,
    requires_explore,
    requires_fit,
    requires_mixed_data,
    requires_mixed_fit,
    requires_predict,
    requires_simulations,
    requires_varying,
)
from bossanova.internal.formula.bundle import build_bundle_from_data
from bossanova.internal.formula.bundle import filter_valid_rows
from bossanova.internal.formula.contrast_specs import resolve_contrast_specs
from bossanova.internal.fit.convergence import check_convergence
from bossanova.internal.fit.diagnostics import (
    augment_data_with_diagnostics,
    compute_diagnostics,
    compute_metadata,
    compute_optimizer_diagnostics,
)
from bossanova.internal.fit import validate_fit_method
from bossanova.internal.marginal import (
    compute_joint_test,
    dispatch_marginal_computation,
    parse_explore_formula,
)
from bossanova.internal.marginal.transforms import filter_effects_dataframe
from bossanova.internal.fit.varying import (
    compute_varying_spread_state,
    compute_varying_state,
)

if TYPE_CHECKING:
    import numpy as np

    from bossanova.internal.containers.structs.display import MathDisplay
    from bossanova.model.summary import FormattedText

__all__ = ["model"]

# File format readers keyed by suffix
_FILE_READERS: dict[str, Any] = {
    ".csv": pl.read_csv,
    ".tsv": lambda p: pl.read_csv(p, separator="\t"),
    ".parquet": pl.read_parquet,
    ".json": pl.read_json,
    ".ndjson": pl.read_ndjson,
}


def _coerce_data(value: pl.DataFrame | str | None) -> pl.DataFrame | None:
    """Convert a file path to a Polars DataFrame.

    Supports CSV, TSV, Parquet, JSON, and NDJSON. For custom read options
    (e.g. separator, dtypes), call ``pl.read_csv(...)`` yourself and pass
    the resulting DataFrame.

    Args:
        value: A Polars DataFrame, a file path (str or Path), or None.

    Returns:
        A Polars DataFrame or None.

    Raises:
        FileNotFoundError: If the path does not exist.
        ValueError: If the file extension is not supported.
    """
    if value is None:
        return None
    if isinstance(value, str):
        from pathlib import Path

        path = Path(value)
        if not path.exists():
            raise FileNotFoundError(f"Data file not found: {path}")
        ext = path.suffix.lower()
        if ext not in _FILE_READERS:
            supported = ", ".join(sorted(_FILE_READERS))
            raise ValueError(f"Unsupported file format '{ext}'. Supported: {supported}")
        return _FILE_READERS[ext](path)
    return value


def _validate_constructor_contrasts(contrasts: dict, data: pl.DataFrame | None) -> None:
    """Validate the ``contrasts=`` kwarg passed to the model constructor.

    Each value must be an ndarray of shape ``(n_levels, n_levels - 1)``
    where ``n_levels`` is the number of unique values in the column.

    Args:
        contrasts: Dict mapping column names to ndarray contrast matrices.
        data: The model's data (may be None for simulation-first).

    Raises:
        TypeError: If a value is not an ndarray.
        ValueError: If shape is wrong or column is not found in data.
    """
    import numpy as np

    if not isinstance(contrasts, dict):
        raise TypeError(
            f"contrasts= must be a dict mapping column names to ndarray matrices, "
            f"got {type(contrasts).__name__}"
        )

    for col, matrix in contrasts.items():
        if not isinstance(matrix, np.ndarray):
            raise TypeError(
                f"contrasts['{col}'] must be an ndarray, got {type(matrix).__name__}.\n\n"
                f"For string contrast specs, use formula syntax instead:\n"
                f'  model("y ~ sum({col}) + x", data)'
            )
        if data is not None and col in data.columns:
            n_levels = data[col].n_unique()
            expected = (n_levels, n_levels - 1)
            if matrix.shape != expected:
                raise ValueError(
                    f"contrasts['{col}'] has shape {matrix.shape}, "
                    f"expected {expected} (n_levels, n_levels - 1).\n\n"
                    f"Column '{col}' has {n_levels} unique values."
                )


@define
class model:
    """Unified statistical model with simulation-first support.

    Provides a single interface for lm, glm, lmer, and glmer. Model type is
    inferred from formula structure and family parameter.

    Args:
        formula (str): R/Patsy-style formula (e.g., ``"y ~ x"``,
            ``"y ~ x + (1|group)"``).
        data (DataFrame | str | None): Input data. Accepts a Polars
            DataFrame, a file path (str to CSV/TSV/Parquet/JSON/NDJSON),
            or None for simulation-first workflows.
        family (str): Response distribution: ``"gaussian"`` (default),
            ``"binomial"``, ``"poisson"``, ``"gamma"``, or ``"tdist"``.
        link (str | None): Link function (``"identity"``, ``"logit"``,
            ``"log"``, etc.). None uses canonical link for family.
        method (str | None): Estimation method: ``"ols"``, ``"ml"``, or
            ``"reml"``. None auto-selects.
        missing (str): Missing value handling: ``"drop"`` (default) or
            ``"fail"``.
        contrasts (dict | None): Custom contrast matrices for categorical
            predictors. Dict mapping column names to ndarray matrices of
            shape ``(n_levels, n_levels - 1)``. For named contrasts, use
            formula syntax instead: ``sum(x)``, ``treatment(x, ref=B)``,
            etc.

    Raises:
        ValueError: If formula, family, link, or method is invalid.
        ModelStateError: If accessing results before required methods are called.

    Notes:
        **Formula Operators**

        | Operator | Example | Meaning |
        |----------|---------|---------|
        | ``+`` | ``a + b`` | Main effects (additive) |
        | ``*`` | ``a * b`` | Main effects + interaction (``a + b + a:b``) |
        | ``:`` | ``a:b`` | Interaction term only |
        | ``**`` / ``^`` | ``x**2`` | Power term (quadratic, cubic, etc.) |
        | ``\|`` | ``(1 \| group)`` | Random effect (mixed models) |

        **In-Formula Transforms**

        | Transform | Effect | Example |
        |-----------|--------|---------|
        | ``center(x)`` | ``x - mean(x)`` | ``y ~ center(age)`` |
        | ``norm(x)`` | ``x / sd(x)`` | ``y ~ norm(income)`` |
        | ``zscore(x)`` | ``(x - mean(x)) / sd(x)`` | ``y ~ zscore(x)`` |
        | ``scale(x)`` | ``(x - mean(x)) / (2 * sd(x))`` — Gelman scaling | ``y ~ scale(x)`` |
        | ``rank(x)`` | Average-method rank | ``y ~ rank(x)`` |
        | ``signed_rank(x)`` | ``sign(x) * rank(\|x\|)`` | ``y ~ signed_rank(x)`` |
        | ``log(x)`` | Natural log | ``y ~ log(x)`` |
        | ``log10(x)`` | Base-10 log | ``y ~ log10(x)`` |
        | ``sqrt(x)`` | Square root | ``y ~ sqrt(x)`` |
        | ``poly(x, d)`` | Orthogonal polynomial basis of degree ``d`` | ``y ~ poly(x, 2)`` |
        | ``factor(x)`` | Treat as categorical | ``y ~ factor(year)`` |

        All stateful transforms (``center``, ``norm``, ``zscore``, ``scale``,
        ``rank``, ``signed_rank``) learn parameters from training data and
        reapply them on new data during ``.predict()``. Nesting is supported:
        ``zscore(rank(x))``.

        **Contrast Coding (In-Formula)**

        | Function | Example | Intercept means | Coefficients mean |
        |----------|---------|-----------------|-------------------|
        | ``treatment(x)`` | ``y ~ treatment(group)`` | Reference level mean | Difference from reference |
        | ``sum(x)`` | ``y ~ sum(group)`` | Grand mean | Deviation from grand mean |
        | ``helmert(x)`` | ``y ~ helmert(group)`` | Grand mean | Level vs. mean of previous levels |
        | ``poly(x)`` | ``y ~ poly(group)`` | Grand mean | Linear, quadratic, cubic trends |
        | ``sequential(x)`` | ``y ~ sequential(group)`` | First level mean | Successive differences (B-A, C-B) |

        Set a custom reference level or ordering with keyword args:
        ``treatment(group, ref=B)``, ``sum(group, omit=A)``,
        ``helmert(group, [low, med, high])``. ::

            model("y ~ sum(group) + x", data)                    # sum coding
            model("y ~ treatment(group, ref=B) + x", data)       # treatment with ref="B"
            model("y ~ group + x", data, contrasts={"group": M}) # custom ndarray matrix
    """

    # Class-level toggle for auto-displaying results in __repr__.
    # When True (default), repr includes the relevant result DataFrame
    # after the model header based on the last operation called.
    _auto_display: ClassVar[bool] = True

    formula: str = field(on_setattr=setters.frozen)
    """R-style model formula string (e.g., ``"y ~ x + (1|group)"``)."""

    data: pl.DataFrame | str | None = field(
        default=None,
        repr=False,
        converter=_coerce_data,
        validator=validators.optional(validators.instance_of(pl.DataFrame)),
        on_setattr=setters.frozen,
    )
    """Input data as a Polars DataFrame, file path, or None for simulation."""

    family: str = field(default="gaussian", validator=validators.in_(FAMILIES))
    """Response distribution (``"gaussian"``, ``"binomial"``, ``"poisson"``, ``"gamma"``, ``"tdist"``)."""

    link: str | None = field(default=None)
    """Link function (e.g., ``"identity"``, ``"logit"``, ``"log"``). None uses canonical link."""

    method: str | None = field(default=None)
    """Estimation method (``"ols"``, ``"ml"``, ``"reml"``). None auto-selects."""

    missing: str = field(default="drop", validator=validators.in_(["drop", "fail"]))
    """Missing value handling: ``"drop"`` (default) or ``"fail"``."""

    contrasts: dict | None = field(default=None, repr=False)
    """Custom contrast matrices mapping column names to ndarray matrices."""

    # Internal state
    _spec: ModelSpec = field(init=False)
    _bundle: DataBundle | None = field(init=False, default=None, repr=False)
    _fit: FitState | None = field(init=False, default=None, repr=False)
    _params_inference: InferenceState | None = field(init=False, default=None)
    _mee: MeeState | JointTestState | None = field(init=False, default=None, repr=False)
    _pred: PredictionState | None = field(init=False, default=None, repr=False)
    _cv: CVState | None = field(init=False, default=None, repr=False)
    _simulations: pl.DataFrame | None = field(init=False, default=None, repr=False)
    _sim_inference: SimulationInferenceState | None = field(
        init=False, default=None, repr=False
    )
    _resamples: ResamplesState | None = field(init=False, default=None, repr=False)
    _last_op: str | None = field(init=False, default=None)
    _weights_col: str | None = field(init=False, default=None, repr=False)
    _offset_col: str | None = field(init=False, default=None, repr=False)
    _formula_spec: object = field(init=False, default=None, repr=False)
    _varying_offsets: VaryingState | None = field(init=False, default=None, repr=False)
    _varying_spread: VaryingSpreadState | None = field(
        init=False, default=None, repr=False
    )
    _profile: ProfileState | None = field(init=False, default=None, repr=False)
    _raw_data: pl.DataFrame | None = field(init=False, default=None, repr=False)
    _custom_contrasts: dict = field(init=False, factory=dict, repr=False)
    _power: pl.DataFrame | None = field(init=False, default=None, repr=False)

    @classmethod
    def set_display(cls, enabled: bool) -> None:
        """Toggle automatic result display in the REPL and notebooks.

        When enabled (the default), evaluating a model object after calling
        ``.fit()``, ``.explore()``, ``.predict()``, or ``.simulate()``
        automatically shows the relevant result table below the model header.
        Disable for a compact one-line repr.

        Args:
            enabled: True to auto-display results, False for compact repr.
        """
        cls._auto_display = enabled

    def _header_repr(self) -> str:
        """One-line model header with formula, family, and status.

        Returns:
            Compact string like ``model(formula=..., family=..., fitted)``.
        """
        if self._fit is not None:
            status = "fitted"
        elif self._bundle is not None or self.data is not None:
            status = "has data"
        else:
            status = "no data"

        parts = [
            f"formula={self.formula!r}",
            f"family={self._spec.family!r}",
            f"link={self._spec.link!r}",
            f"method={self._spec.method!r}",
            status,
        ]

        if self._bundle is not None:
            parts.insert(-1, f"n_obs={len(self._bundle.y)}")

        return f"model({', '.join(parts)})"

    def _result_for_display(self) -> pl.DataFrame | None:
        """Return the result DataFrame for the last operation, or None.

        Returns:
            The DataFrame corresponding to the last method call (fit, explore,
            predict, simulate, or power), or None if no displayable result
            is available.
        """
        match self._last_op:
            case "fit":
                return self.params
            case "explore":
                return self.effects
            case "predict":
                return self.predictions
            case "simulate":
                return self.simulations
            case "power":
                return self.power_results
            case _:
                return None

    def __repr__(self) -> str:
        """Return string representation of model.

        When ``_auto_display`` is True and a result-producing method has been
        called, appends the relevant result table below the model header.

        Returns:
            String showing model metadata, state, and optionally the last
            result table.
        """
        header = self._header_repr()
        if not self._auto_display or self._last_op is None:
            return header

        result = self._result_for_display()
        if result is None:
            return header
        return f"{header}\n{result!r}"

    def _repr_html_(self) -> str:
        """Rich HTML representation for Jupyter notebooks.

        Shows the model header followed by the result DataFrame rendered
        as an HTML table (via Polars' ``_repr_html_``).

        Returns:
            HTML string for notebook display.
        """
        header = self._header_repr()
        header_html = f"<pre>{header}</pre>"

        if not self._auto_display or self._last_op is None:
            return header_html

        result = self._result_for_display()
        if result is None:
            return header_html
        return f"{header_html}\n{result._repr_html_()}"

    def __attrs_post_init__(self) -> None:
        """Parse formula, validate constructor contrasts, and build spec."""

        self._raw_data = self.data

        # Validate and store constructor-supplied contrasts
        if self.contrasts is not None:
            _validate_constructor_contrasts(self.contrasts, self.data)
            self._custom_contrasts = dict(self.contrasts)

        # Build ModelSpec with parse terms
        self._spec = build_model_spec_from_formula(
            self.formula,
            family=self.family,
            link=self.link,
            method=self.method,
        )

        if self.data is not None:
            self._bundle = self._build_bundle()

    @property
    def _model_type(self) -> str:
        """Model type code inferred from formula and family.

        Returns:
            str: One of ``"lm"``, ``"glm"``, ``"lmer"``, ``"glmer"``.
        """

        if self._spec.has_random_effects:
            out = "lmer" if self._spec.family == "gaussian" else "glmer"
        else:
            out = "lm" if self._spec.family == "gaussian" else "glm"
        return out

    @property
    def _is_fitted(self) -> bool:
        """Whether the model has been fitted.

        Returns:
            bool: True if ``.fit()`` has been called successfully.
        """
        return self._fit is not None

    @property
    def _is_mixed(self) -> bool:
        """Whether the model has random effects.

        Returns:
            bool: True if the formula contains random effect terms.
        """
        return self._spec.has_random_effects

    @property
    def _random_terms(self) -> tuple[str, ...]:
        """Random effect term specifications from the formula.

        Returns:
            tuple[str, ...]: Random effect term strings (e.g., ``"(1|group)"``).
                Empty tuple for fixed-effects-only models.
        """
        return self._spec.random_terms

    @property
    @requires_mixed_data
    def _ngroups(self) -> dict[str, int]:
        """Number of group levels per grouping factor.

        Returns:
            dict[str, int]: Mapping of grouping variable name to group count.

        Raises:
            ModelStateError: If model has no data or no random effects.
        """
        return dict(self._bundle.re_metadata.n_groups)

    @property
    @requires_data
    def _rank(self) -> int:
        """Effective numerical rank of the fixed-effects design matrix.

        Delegates to ``DataBundle.rank``, which uses pivoted-QR rank
        detection when available and falls back to the number of columns.

        Returns:
            int: Effective rank of X.

        Raises:
            ModelStateError: If no data is available.
        """
        return self._bundle.rank

    @property
    @requires_fit
    def params(self) -> pl.DataFrame:
        """Coefficient estimates table from the fitted model.

        Returns:
            pl.DataFrame: Columns: term, estimate. After ``.infer()``, adds
                se, statistic, df, p_value, ci_lower, ci_upper.

        Raises:
            ModelStateError: If the model has not been fitted.
        """
        return round_float_columns(
            build_params_dataframe(self._bundle, self._fit, self._params_inference),
            get_display_digits(),
        )

    @property
    def resamples(self) -> pl.DataFrame | None:
        """Raw resampled values from bootstrap or permutation inference.

        Returns a long-format DataFrame with one row per
        (resample, term) combination:

        - **resample** (int): Resample index (0 to n_resamples - 1).
        - **term** (str): Parameter or effect name.
        - **value** (float): Resampled estimate (bootstrap) or null
          test statistic (permutation).

        Total rows = ``n_resamples × n_terms``.

        Returns None if ``.infer()`` hasn't been called with
        ``how="boot"|"perm"``, or if ``save_resamples=False`` was passed.

        Returns:
            pl.DataFrame or None: Raw resampled values, or None.
        """
        if self._resamples is None:
            return None
        return round_float_columns(
            build_resamples_dataframe(self._resamples),
            get_display_digits(),
        )

    @property
    def power_results(self) -> pl.DataFrame:
        """Power analysis results from ``simulate(power=...)``.

        Returns:
            DataFrame with columns: n, sigma, term, true_value, power,
            power_ci_lower, power_ci_upper, coverage, bias, rmse,
            mean_se, empirical_se, n_sims, n_failed.

        Raises:
            ModelStateError: If ``simulate(power=...)`` has not been called.
        """
        if self._power is None:
            raise ModelStateError(
                "No power results available. Run simulate(power=...) first."
            )
        return round_float_columns(self._power, get_display_digits())

    @property
    @requires_varying
    def varying_offsets(self) -> pl.DataFrame:
        """Random effects (BLUPs) -- group-level deviations from population parameters.

        Returns:
            pl.DataFrame: Columns: group, level, plus one column per random effect.
                After ``.infer()``, adds pi_lower/pi_upper prediction intervals.

        Raises:
            ModelStateError: If not fitted or model has no random effects.
        """
        return round_float_columns(
            build_varying_offsets_dataframe(self._varying_offsets),
            get_display_digits(),
        )

    @property
    @requires_varying
    def varying_params(self) -> pl.DataFrame:
        """Group-specific coefficients (population params + varying offsets).

        Returns:
            pl.DataFrame: Columns: group, level, plus one column per random
                effect with the conditional coefficient (population + BLUP).

        Raises:
            ModelStateError: If not fitted or model has no random effects.
        """
        return round_float_columns(
            build_varying_params_dataframe(
                self._bundle, self._fit, self._varying_offsets
            ),
            get_display_digits(),
        )

    @property
    @requires_varying
    def varying_spread(self) -> pl.DataFrame:
        """Variance components for mixed models (sigma2, tau2, rho, ICC).

        Returns:
            pl.DataFrame: Columns: component, estimate. After
                ``.infer(how="profile")``, adds ci_lower, ci_upper, ci_method.

        Raises:
            ModelStateError: If not fitted or model has no random effects.
        """
        return round_float_columns(
            build_varying_spread_dataframe(self._varying_spread),
            get_display_digits(),
        )

    @property
    @requires_varying
    def varying_corr(self) -> pl.DataFrame:
        """Random effect correlations for mixed models.

        Returns a tidy DataFrame of pairwise correlations between random
        effects. Empty (zero rows) for models with only random intercepts
        or uncorrelated (diagonal) RE structures.

        Returns:
            pl.DataFrame: Columns: group, effect1, effect2, corr.

        Raises:
            ModelStateError: If not fitted or model has no random effects.
        """
        return round_float_columns(
            build_varying_corr_dataframe(self._varying_spread),
            get_display_digits(),
        )

    @requires_mixed_fit
    def _is_singular(self, tol: float | None = None) -> bool:
        """Check whether the mixed model fit is singular.

        Args:
            tol: Tolerance threshold. If None, uses the global singular
                tolerance (default 1e-4).

        Returns:
            True if the fit is singular (boundary variance components).

        Raises:
            ModelStateError: If the model has not been fitted or has no
                random effects.
        """

        from bossanova.internal.maths.config import is_singular as _is_singular_fn

        return _is_singular_fn(self._fit.theta, tol=tol)

    @property
    @requires_mixed_data
    def _re_structure(self) -> str:
        """Random effects structure type from the data bundle.

        Returns the RE structure string from the model's RE metadata.
        Common values: ``"intercept"``, ``"slope"``, ``"diagonal"``.

        Returns:
            str: The RE structure type.

        Raises:
            ModelStateError: If model has no data or no random effects.
        """
        return self._bundle.re_metadata.re_structure

    @property
    @requires_fit
    def _vcov(self) -> "np.ndarray":
        """Variance-covariance matrix of fixed effect coefficient estimates.

        Returns:
            np.ndarray: Shape (p, p). NaN for rank-deficient terms.

        Raises:
            ModelStateError: If the model has not been fitted.
        """
        return self._fit.vcov

    @property
    @requires_data
    def designmat(self) -> pl.DataFrame:
        """Fixed-effects design matrix as a named DataFrame.

        Returns:
            pl.DataFrame: n x p design matrix with columns named after model terms.

        Raises:
            ModelStateError: If no data is available.
        """
        return pl.DataFrame(self._bundle.X, schema=list(self._bundle.X_names))

    @property
    @requires_data
    def metadata(self) -> pl.DataFrame:
        """Model metadata: observation counts, parameter count, group counts.

        Returns a single-row DataFrame with structural info about the
        model and data. For mixed models, includes ``ngroups``.

        Returns:
            pl.DataFrame: Single-row DataFrame with model metadata.

        Raises:
            ModelStateError: If no data is available.
        """
        return compute_metadata(bundle=self._bundle)

    @property
    @requires_fit
    def diagnostics(self) -> pl.DataFrame:
        """Model-level goodness-of-fit diagnostics.

        Returns a single-row DataFrame with metrics that vary by model type:
        df, AIC, BIC, loglik, R-squared (OLS), deviance/dispersion (GLM),
        sigma/ICC (mixed). After ``.infer(how='cv')``, adds cv_error.

        Returns:
            pl.DataFrame: Single-row DataFrame with model diagnostics.

        Raises:
            ModelStateError: If the model has not been fitted.
        """
        has_intercept = (
            self._formula_spec.has_intercept if self._formula_spec is not None else True
        )
        return round_float_columns(
            compute_diagnostics(
                model_type=self._model_type,
                spec=self._spec,
                bundle=self._bundle,
                fit=self._fit,
                coef_for_predict=self._coef_for_predict(),
                varying_spread=self._varying_spread,
                cv=self._cv,
                has_intercept=has_intercept,
            ),
            get_display_digits(),
        )

    @property
    @requires_fit
    def _optimizer_diagnostics(self) -> pl.DataFrame:
        """Optimizer convergence diagnostics.

        Returns:
            pl.DataFrame: Single-row DataFrame with converged, n_iter, optimizer.
                GLMs add dispersion; mixed models add is_singular, n_theta.

        Raises:
            ModelStateError: If the model has not been fitted.
        """
        return compute_optimizer_diagnostics(
            model_type=self._model_type,
            fit=self._fit,
        )

    @property
    @requires_explore
    def effects(self) -> pl.DataFrame:
        """Marginal effects or estimated marginal means (EMMs) table.

        Returns:
            pl.DataFrame: Grid columns (focal variable levels or contrast labels)
                plus estimate. After ``.infer()``, adds se, statistic, df,
                p_value, ci_lower, ci_upper.

        Raises:
            ModelStateError: If ``.explore()`` has not been called.
        """

        if isinstance(self._mee, JointTestState):
            return round_float_columns(
                build_joint_test_dataframe(self._mee),
                get_display_digits(),
            )

        return round_float_columns(
            build_effects_dataframe(self._mee, method=self._mee.inference_method),
            get_display_digits(),
        )

    @property
    @requires_predict
    def predictions(self) -> pl.DataFrame:
        """Predictions table from the fitted model.

        Returns:
            pl.DataFrame: Columns: fitted (and link for GLMs). After
                ``.infer()``, adds se, ci_lower, ci_upper.

        Raises:
            ModelStateError: If ``.predict()`` has not been called.
        """
        return round_float_columns(
            build_predictions_dataframe(self._pred),
            get_display_digits(),
        )

    @property
    @requires_simulations
    def simulations(self) -> pl.DataFrame:
        """Simulations table from data generation or response simulation.

        Pre-fit mode (``n=``): full generated dataset with predictors and response.
        Post-fit mode (``nsim=``): sim_1, sim_2, ... columns with simulated responses.

        Returns:
            pl.DataFrame: Simulated data (contents vary by mode).

        Raises:
            ModelStateError: If ``.simulate()`` has not been called.
        """
        return round_float_columns(
            build_simulations_dataframe(self._simulations, self._sim_inference),
            get_display_digits(),
        )

    def set_contrasts(self, **contrasts: object) -> Self:
        """Set custom contrast coding for categorical predictors.

        .. deprecated::
            Use formula syntax (``sum(x)``, ``treatment(x, ref=B)``) or
            the ``contrasts=`` constructor kwarg for ndarray matrices instead.

        Args:
            **contrasts: Column name → contrast spec. Values: a string
                (``'treatment'``, ``'sum'``, ``'helmert'``, ``'poly'``,
                ``'sequential'``), a tuple ``('treatment', 'B')`` for custom
                reference, or an ndarray contrast matrix.

        Returns:
            self: For method chaining. Model must be re-fitted after.

        Raises:
            ValueError: If column not found, not categorical, or invalid spec.
        """
        import warnings

        if self.data is None:
            raise ModelStateError("No data available. Cannot determine factor levels.")

        # Emit targeted deprecation warnings
        for col, spec in contrasts.items():
            if isinstance(spec, (str, tuple)):
                warnings.warn(
                    f"set_contrasts({col}={spec!r}) is deprecated. "
                    f"Use formula syntax instead: e.g., sum({col}) or "
                    f"treatment({col}, ref=level) in the formula string.",
                    DeprecationWarning,
                    stacklevel=2,
                )
            else:
                warnings.warn(
                    f"set_contrasts({col}=<ndarray>) is deprecated. "
                    f"Use the contrasts= kwarg in the model() constructor: "
                    f'model("...", data, contrasts={{"{col}": matrix}}).',
                    DeprecationWarning,
                    stacklevel=2,
                )

        self._custom_contrasts = resolve_contrast_specs(self.data, contrasts)
        self._invalidate_all_state()
        return self

    def reset_contrasts(self) -> Self:
        """Reset contrast coding to defaults (treatment/dummy coding).

        .. deprecated::
            Create a new model instead of resetting contrasts in place.

        Clears any custom contrasts set via ``set_contrasts()``.
        The model must be re-fitted after resetting.

        Returns:
            self: The model instance for method chaining.
        """
        import warnings

        warnings.warn(
            "reset_contrasts() is deprecated. Create a new model instead of "
            "resetting contrasts in place.",
            DeprecationWarning,
            stacklevel=2,
        )
        self._custom_contrasts = {}
        self._invalidate_all_state()
        return self

    def _build_bundle(self) -> DataBundle:
        """Build DataBundle from current data, spec, and contrasts.

        Returns:
            DataBundle with X matrix, y vector, Z matrix (if mixed), and metadata.
        """
        bundle, formula_spec = build_bundle_from_data(
            spec=self._spec,
            formula=self.formula,
            data=self.data,
            custom_contrasts=self._custom_contrasts,
            weights_col=self._weights_col,
            offset_col=self._offset_col,
            missing=self.missing,
        )
        self._formula_spec = formula_spec
        return bundle

    def _invalidate_all_state(self) -> None:
        """Clear all fit and downstream state, rebuild the design matrix.

        Called when a change (e.g. contrast reconfiguration) requires the
        model to be re-fitted from scratch.  The bundle is rebuilt immediately
        so that ``.designmat`` always reflects the current contrasts.
        """
        self._fit = None
        self._params_inference = None
        self._resamples = None
        self._mee = None
        self._pred = None
        self._cv = None
        self._simulations = None
        self._sim_inference = None
        self._varying_offsets = None
        self._varying_spread = None
        self._profile = None
        self._last_op = None

        # Rebuild bundle so design matrix stays current
        if self.data is not None:
            self._bundle = self._build_bundle()
        else:
            self._bundle = None

    def _coef_for_predict(self):
        """Coefficients safe for matrix multiplication (NaN -> 0).

        Delegates to :func:`~bossanova.internal.fit.predict.resolve_coef_for_predict`.

        Returns:
            Coefficient array with NaN replaced by 0.
        """
        from bossanova.internal.fit.predict import resolve_coef_for_predict

        return resolve_coef_for_predict(self._fit.coef, self._bundle.rank_info)

    @requires_fit
    def _augment_data(self) -> None:
        """Augment self.data with diagnostic columns after fit.

        Adds fitted, resid, hat, std_resid, cooksd columns to the
        data DataFrame. Values are NaN for rows dropped due to missing data.
        """
        if self._raw_data is None:
            return
        object.__setattr__(
            self,
            "data",
            augment_data_with_diagnostics(
                raw_data=self._raw_data,
                fit=self._fit,
                bundle=self._bundle,
            ),
        )

    @requires_data
    def fit(
        self,
        *,
        weights: str | None = None,
        offset: str | None = None,
        nAGQ: int | None = None,
        **kwargs: object,
    ) -> ModelResult:
        """Fit the model to data.

        Args:
            weights: Column name for observation weights (non-negative).
            offset: Column name for an offset term (added to the linear predictor).
            nAGQ: Gauss-Hermite quadrature points for GLMM (0=fast, 1=Laplace,
                >1=adaptive GHQ for scalar random intercept models).
            **kwargs: Fitting options (method, tol, max_iter, verbose).

        Returns:
            self: For method chaining.

        Raises:
            ModelStateError: If no data is available.
            ValueError: If weights/offset column invalid or nAGQ invalid.

        Examples:
            Fit and inspect::

                m = model("y ~ x", data).fit()
                m.params

            Chain with inference::

                m = model("y ~ x", data).fit().infer()
        """

        # Validate solver kwarg if provided
        _VALID_SOLVERS = {"qr", "svd", "irls", "pls", "pirls"}
        if "solver" in kwargs:
            solver_val = kwargs.pop("solver")
            if solver_val not in _VALID_SOLVERS:
                raise ValueError(
                    f"Unknown solver: {solver_val!r}. "
                    f"Valid solvers are: {sorted(_VALID_SOLVERS)}"
                )

        # Update spec for spec-level kwargs (method) before solver dispatch
        if "method" in kwargs:
            self._spec = validate_fit_method(self._spec, str(kwargs.pop("method")))

        # Validate and forward nAGQ for GLMM
        if nAGQ is not None:
            if not isinstance(nAGQ, int) or nAGQ < 0:
                raise ValueError(f"nAGQ must be a non-negative integer, got {nAGQ}")
            kwargs["nAGQ"] = nAGQ

        # Extract fit-specific kwargs with defaults
        fit_kwargs = {
            "max_iter": kwargs.pop("max_iter", None),
            "max_outer_iter": int(kwargs.pop("max_outer_iter", 10000)),
            "tol": kwargs.pop("tol", None),
            "verbose": bool(kwargs.pop("verbose", False)),
            "nAGQ": int(kwargs.pop("nAGQ", 1)),
            "use_hessian": bool(kwargs.pop("use_hessian", True)),
        }
        if fit_kwargs["max_iter"] is not None:
            fit_kwargs["max_iter"] = int(fit_kwargs["max_iter"])
        if fit_kwargs["tol"] is not None:
            fit_kwargs["tol"] = float(fit_kwargs["tol"])

        # Restore raw data for clean re-fit (avoid feeding augmented cols)
        if self._raw_data is not None:
            object.__setattr__(self, "data", self._raw_data)

        # Save raw data if not already saved (handles simulate-first)
        if self._raw_data is None and self.data is not None:
            self._raw_data = self.data

        # Handle weights parameter
        if weights is not None:
            self._weights_col = weights
            self._bundle = None  # Force rebuild with weights

        # Handle offset parameter
        if offset is not None:
            self._offset_col = offset
            self._bundle = None  # Force rebuild with offset

        # Build DataBundle if not already built
        if self._bundle is None:
            self._bundle = self._build_bundle()

        # Fit using fitter adapter
        from bossanova.internal.fit import fit_model

        self._fit = fit_model(self._spec, self._bundle, **fit_kwargs)

        # Compute mixed model state (BLUPs and variance components)
        if self._is_mixed:
            # Compute VaryingState (BLUPs)
            if (
                self._fit.theta is not None
                and self._fit.u is not None
                and self._bundle.re_metadata is not None
            ):
                valid_data = filter_valid_rows(self.data, self._bundle.valid_mask)
                self._varying_offsets = compute_varying_state(
                    theta=self._fit.theta,
                    u=self._fit.u,
                    re_meta=self._bundle.re_metadata,
                    data=valid_data,
                )
            else:
                self._varying_offsets = None

            # Compute VaryingSpreadState (variance components)
            if self._fit.theta is not None and self._bundle.re_metadata is not None:
                sigma = self._fit.sigma if self._fit.sigma is not None else 1.0
                self._varying_spread = compute_varying_spread_state(
                    theta=self._fit.theta,
                    sigma=sigma,
                    re_meta=self._bundle.re_metadata,
                )
            else:
                self._varying_spread = None

            # Emit convergence warnings if any issues detected
            import warnings

            from bossanova.internal.maths.convergence import format_convergence_warnings

            msgs = check_convergence(self._fit, self._bundle.re_metadata)
            if msgs:
                warnings.warn(format_convergence_warnings(msgs), stacklevel=2)
        else:
            self._varying_offsets = None
            self._varying_spread = None

        # Clear downstream state
        self._params_inference = None
        self._resamples = None
        self._mee = None
        self._pred = None
        self._simulations = None

        # Augment data with diagnostic columns
        self._augment_data()

        self._last_op = "fit"

        return ModelResult(self)

    def simulate(
        self,
        n: int | None = None,
        nsim: int | None = None,
        seed: int | None = None,
        coef: dict[str, float] | None = None,
        sigma: float = 1.0,
        varying: str = "fitted",
        power: int | dict[str, Any] | None = None,
        **var_specs: object,
    ) -> ModelResult:
        """Generate data from scratch or simulate responses from a fitted model.

        Pre-fit mode (``n=``): generate a dataset from formula and distributions.
        Post-fit mode (``nsim=``): simulate response vectors from the fitted model.
        Power mode (``power=``): run simulation-based power analysis.

        Args:
            n: Number of observations to generate (pre-fit mode).
            nsim: Number of response vectors to simulate (post-fit mode).
            seed: Random seed for reproducibility.
            coef: True coefficient values for pre-fit mode.
            sigma: Residual SD for gaussian pre-fit mode (default 1.0).
            varying: Random effects handling in post-fit: ``"fitted"`` or ``"sample"``.
            power: Power analysis configuration. ``int`` for simple (number of sims),
                ``dict`` for sweeps (e.g., ``{"n_sims": 500, "n": [50, 100, 200]}``).
            **var_specs: Distribution specs for predictors (e.g., ``x=normal(0, 1)``).

        Returns:
            self: For method chaining.

        Raises:
            ValueError: If both or neither ``n``/``nsim`` specified, or invalid varying.
            ModelStateError: If ``n`` used with existing data, or ``nsim`` before fit.
        """
        if power is not None:
            return self._run_power_analysis(
                power=power,
                n=n,
                seed=seed,
                coef=coef,
                sigma=sigma,
                **var_specs,
            )

        if n is not None and nsim is not None:
            raise ValueError(
                "Specify n= (generate data) or nsim= (simulate from fit), not both"
            )

        if nsim is not None:
            if nsim < 1:
                raise ValueError(f"nsim must be at least 1, got {nsim}")
            # Validate varying parameter
            if varying not in ("fitted", "sample"):
                raise ValueError(
                    f"varying must be 'fitted' or 'sample', got '{varying}'"
                )
            if varying == "sample" and not self._is_mixed:
                raise ValueError(
                    "varying='sample' only applies to mixed models "
                    "(with random effects)"
                )
            # Post-fit simulation: generate new responses from fitted model
            if self._fit is None:
                raise ModelStateError("Model not fitted. Call .fit() first.")
            self._simulations = self._simulate_responses(nsim, seed, varying=varying)
            self._last_op = "simulate"
            return ModelResult(self)

        # Pre-fit data generation
        if self._bundle is not None or self.data is not None:
            raise ModelStateError(
                "Data already provided. Use nsim= to simulate from fitted model."
            )
        if n is None:
            raise ValueError("Must specify n= for data generation")

        # Build simulation spec from formula
        from bossanova.internal.containers.builders.specs import (
            build_simulation_spec_from_formula,
        )

        sim_spec = build_simulation_spec_from_formula(
            formula=self.formula,
            n=n,
            distributions=var_specs if var_specs else None,
            coef=coef,
            sigma=sigma,
            seed=seed,
        )

        # Generate data using DGP
        generated_data = self._generate_data(sim_spec)

        # Store generated data
        # Use object.__setattr__ since attrs makes 'data' field frozen after init
        object.__setattr__(self, "data", generated_data)
        self._simulations = generated_data

        self._last_op = "simulate"
        return ModelResult(self)

    def _run_power_analysis(
        self,
        power: int | dict[str, Any],
        n: int | None,
        seed: int | None,
        coef: dict[str, float] | None,
        sigma: float,
        **var_specs: object,
    ) -> ModelResult:
        """Run power analysis via simulation. Delegates to internal ops.

        Args:
            power: Power config — int (n_sims) or dict with sweep axes.
            n: Base sample size.
            seed: Random seed.
            coef: Base coefficient values.
            sigma: Base residual SD.
            **var_specs: Distribution specs for predictors.

        Returns:
            self for method chaining.

        Raises:
            ValueError: If n is not provided.
        """
        if n is None:
            raise ValueError("n= is required for power analysis")

        from bossanova.internal.simulation.power import (
            run_power_analysis,
        )

        self._power = run_power_analysis(
            formula=self.formula,
            family=self._spec.family,
            response_var=self._spec.response_var,
            power=power,
            n=n,
            seed=seed,
            coef=coef,
            sigma=sigma,
            var_specs=var_specs,
        )
        self._last_op = "power"
        return ModelResult(self)

    def _generate_data(self, sim_spec: object) -> pl.DataFrame:
        """Generate data from simulation spec. Delegates to internal ops."""
        from bossanova.internal.simulation.model_sim import (
            generate_data_from_spec,
        )

        return generate_data_from_spec(
            sim_spec=sim_spec,
            family=self._spec.family,
            response_var=self._spec.response_var,
        )

    def _simulate_responses(
        self, nsim: int, seed: int | None, varying: str = "fitted"
    ) -> pl.DataFrame:
        """Simulate new responses from a fitted model. Delegates to internal ops."""
        from bossanova.internal.simulation.model_sim import (
            simulate_responses_from_fit,
        )

        return simulate_responses_from_fit(
            fit=self._fit,
            bundle=self._bundle,
            spec=self._spec,
            nsim=nsim,
            seed=seed,
            varying=varying,
        )

    def _compute_mu_with_new_re(self, rng: "np.random.Generator") -> "np.ndarray":
        """Compute mu with newly sampled random effects. Delegates to internal ops."""
        from bossanova.internal.simulation.model_sim import (
            compute_mu_with_new_re,
        )

        return compute_mu_with_new_re(
            bundle=self._bundle,
            fit=self._fit,
            spec=self._spec,
            rng=rng,
        )

    @requires_fit
    def explore(
        self,
        formula: str,
        *,
        inverse_transforms: bool = True,
        effect_scale: Literal["link", "response"] = "link",
        varying: Literal["exclude", "include"] = "exclude",
        how: Literal["auto", "mem", "ame"] = "auto",
        by: str | None = None,
    ) -> ModelResult:
        """Compute marginal effects or estimated marginal means (EMMs).

        Args:
            formula: Explore formula. Grammar::

                    lhs [ '~' rhs ]
                    lhs := term | contrast_fn '(' term ')'
                    contrast_fn := 'pairwise' | 'sequential' | 'poly'
                                  | 'treatment' | 'dummy' | 'sum' | 'deviation' | 'helmert'
                    rhs := condition [ '+' condition ]*
                    condition := term [ '@' value | '[' list ']' | ':range(n)' | ':quantile(n)' ]

                Examples: ``"treatment"``, ``"pairwise(treatment)"``,
                ``"treatment ~ age@[30, 50]"``, ``"pairwise(treatment) ~ sex"``.
            inverse_transforms: When True (default), raw variable names
                and values in the explore formula are auto-resolved through
                learned formula transforms (e.g. ``center``, ``zscore``,
                ``scale``). Set to False to use transformed-scale
                names/values directly.
            effect_scale: ``"link"`` (default) or ``"response"``
                (inverse-link / data scale).
            varying: ``"exclude"`` (default) or ``"include"`` random effects.
            how: ``"auto"`` (default), ``"mem"`` for emmeans-style balanced
                reference grid (Marginal Estimated Mean), or ``"ame"`` for
                g-computation / Average Marginal Effect. ``"auto"`` selects
                ``"ame"`` for GLMs (non-identity link), ``"mem"`` for
                linear models.
            by: Column name for subgroup analysis. Computes separate
                effects within each level of this variable.

        Returns:
            self: For method chaining. Results in ``.effects``.

        Raises:
            ModelStateError: If model has not been fitted.
            ValueError: If focal variable not found in model, or if
                ``inverse_transforms=True`` is used with a non-invertible
                transform (rank, signed_rank).

        Examples:
            EMMs and contrasts::

                m = model("y ~ treatment", data).fit()
                m.explore("treatment").infer()
                m.explore("pairwise(treatment)").infer()

            With transforms (raw variable names resolve automatically)::

                m = model("y ~ center(x) + group", data).fit()
                m.explore("group ~ x@[50]")  # auto-centers 50

        Notes:
            **Formula Patterns**

            | Formula | Computes |
            |---------|----------|
            | ``"X"`` | EMMs (categorical) or marginal slope (continuous) |
            | ``"X@v"`` | EMM at a single value |
            | ``"X@[a, b, c]"`` | EMMs at specific levels or values |
            | ``"X@range(n)"`` | EMMs at n evenly-spaced values |
            | ``"X@quantile(n)"`` | EMMs at n quantile values |
            | ``"X ~ Z"`` | Break X out by levels of Z |
            | ``"X ~ Z@v"`` | Pin Z at value v |
            | ``"X ~ Z@[v1, v2]"`` | Cross X with multiple Z values |
            | ``"X ~ Z@range(n)"`` | Cross X with n evenly-spaced Z values |
            | ``"X ~ Z@quantile(n)"`` | Cross X with n quantile Z values |
            | ``"X ~ A + B"`` | Multiple conditions |
            | ``X[A - B]`` | A minus B |
            | ``X[A - B, C - B]`` | Multiple comparisons |
            | ``X[* - B]`` | Each other level vs B |
            | ``X[(A + B) - C]`` | mean(A, B) minus C |
            | ``X[A - B] ~ Z[C - D]`` | Interaction: (A-B at C) minus (A-B at D) |
            | ``x ~ Z[A - B]`` | Slope of x at A minus slope at B |
            | ``X:Z[A:C - B:D]`` | Cell A:C minus cell B:D |

            **Contrast Functions**

            | Formula | Computes | Order-dependent |
            |---------|----------|:---:|
            | ``treatment(X, ref=A)`` | Each level vs reference A | No |
            | ``dummy(X, ref=A)`` | Same as ``treatment`` | No |
            | ``sum(X)`` | Each level vs grand mean | No |
            | ``deviation(X, ref=A)`` | Same as ``sum`` | No |
            | ``poly(X)`` / ``poly(X, d)`` | Orthogonal polynomials up to degree d | Yes |
            | ``sequential(X)`` | Adjacent: B-A, C-B | Yes |
            | ``helmert(X)`` | Each level vs mean of previous | Yes |
            | ``pairwise(X)`` | All pairs: B-A, C-A, C-B | No |

            **Keyword Arguments for Scaling**

            | Kwarg | Values | Effect |
            |-------|--------|--------|
            | ``effect_scale`` | ``"link"`` (default), ``"response"`` | Linear predictor vs response scale (GLMs) |
            | ``varying`` | ``"exclude"`` (default), ``"include"`` | Population vs group-specific (mixed models) |
            | ``inverse_transforms`` | ``True`` (default), ``False`` | Auto-resolve ``center(x)`` / ``zscore(x)`` |
        """
        # Parse the explore formula
        parsed = parse_explore_formula(formula)

        if self.data is None:
            raise ModelStateError("No data available for computing marginal effects")

        # Dispatch to internal operations
        self._mee = dispatch_marginal_computation(
            parsed=parsed,
            bundle=self._bundle,
            fit=self._fit,
            data=self.data,
            spec=self._spec,
            formula_spec=self._formula_spec,
            varying_offsets=self._varying_offsets,
            effect_scale=effect_scale,
            varying=varying,
            how=how,
            inverse_transforms=inverse_transforms,
            by=by,
        )
        self._last_op = "explore"

        return ModelResult(self)

    def jointtest(
        self,
        terms: list[str] | None = None,
        *,
        errors: Literal[
            "iid", "HC0", "HC1", "HC2", "HC3", "hetero", "unequal_var"
        ] = "iid",
    ) -> pl.DataFrame:
        """Compute ANOVA-style joint hypothesis tests for model terms.

        Convenience method that auto-fits if needed, then computes joint
        (Type III) F-tests (gaussian) or chi-square tests (non-gaussian)
        for each model term.

        Args:
            terms: Specific terms to test, or None for all terms.
            errors: Error structure. ``"iid"`` (default) for standard
                OLS/MLE errors, ``"HC0"``–``"HC3"`` or ``"hetero"`` for
                sandwich SEs, or ``"unequal_var"`` for Welch ANOVA with
                per-term Satterthwaite df.

        Returns:
            pl.DataFrame: Columns: term, df1, df2 (F-test only),
                statistic, p_value.

        Raises:
            ModelStateError: If no data is available.
            ValueError: If specified terms not found in model.
            NotImplementedError: If errors type not supported for model family.

        Examples:
            Auto-fits and returns ANOVA table::

                m = model("y ~ x1 + x2", data)
                m.jointtest()

            Welch ANOVA (per-term Satterthwaite df)::

                m = model("y ~ factor(group)", data)
                m.jointtest(errors="unequal_var")
        """
        if self._fit is None:
            self.fit()

        self._mee = compute_joint_test(
            fit=self._fit,
            bundle=self._bundle,
            spec=self._spec,
            terms=terms,
            errors=errors,
            data=self.data,
        )
        self._last_op = "explore"

        return build_joint_test_dataframe(self._mee)

    @requires_fit
    def predict(
        self,
        newdata: pl.DataFrame | None = None,
        type: Literal["response", "link"] = "response",
        *,
        varying: Literal["exclude", "include"] = "exclude",
        allow_new_levels: bool = False,
        **kwargs: object,
    ) -> ModelResult:
        """Generate predictions from the fitted model.

        Args:
            newdata: Data for prediction (Polars DataFrame). None uses training data.
            type: Scale: ``"response"`` (default) or ``"link"``.
            varying: Random effects: ``"exclude"`` (default, population-level)
                or ``"include"`` (conditional with BLUPs).
            allow_new_levels: If True, unseen groups predict at population level.
            **kwargs: Reserved for future use.

        Returns:
            self: For method chaining. Results in ``.predictions``.

        Raises:
            ModelStateError: If model has not been fitted.
            ValueError: If newdata missing required columns or has unseen groups.

        Examples:
            Predict on new data::

                m = model("y ~ x", data).fit()
                m.predict(new_df).infer()
                m.predictions
        """

        # Compute predictions
        self._pred = self._compute_predictions(
            newdata, type, varying=varying, allow_new_levels=allow_new_levels
        )
        self._last_op = "predict"

        return ModelResult(self)

    def _compute_predictions(
        self,
        newdata: pl.DataFrame | None,
        pred_type: Literal["response", "link"],
        *,
        varying: Literal["exclude", "include"] = "exclude",
        allow_new_levels: bool = False,
    ) -> PredictionState:
        """Compute predictions for given data.

        Delegates to
        :func:`~bossanova.internal.fit.predict.compute_predictions`.

        Args:
            newdata: Data for prediction. If None, uses training data.
            pred_type: Prediction scale (``"response"`` or ``"link"``).
            varying: How to handle random effects for mixed models.
                ``"exclude"`` for population-level, ``"include"`` for
                conditional predictions with BLUPs.
            allow_new_levels: If True, new groups predict at population level.
                If False, raises ValueError for unseen groups.

        Returns:
            PredictionState with fitted values.
        """
        from bossanova.internal.fit.predict import compute_predictions

        return compute_predictions(
            spec=self._spec,
            bundle=self._bundle,
            fit=self._fit,
            formula_spec=self._formula_spec,
            training_data=self.data,
            newdata=newdata,
            pred_type=pred_type,
            varying=varying,
            allow_new_levels=allow_new_levels,
        )

    @requires_fit
    def infer(
        self,
        how: Literal["asymp", "boot", "perm", "cv", "profile", "joint"] = "asymp",
        what: Literal[
            "params|effects", "params-joint", "anova", "model"
        ] = "params|effects",
        conf_level: float | int | str = 0.95,
        errors: Literal[
            "iid", "HC0", "HC1", "HC2", "HC3", "hetero", "unequal_var"
        ] = "iid",
        null: float = 0.0,
        alternative: Literal["two-sided", "greater", "less"] = "two-sided",
        *,
        n_boot: int = 1000,
        n_perm: int = 1000,
        ci_type: Literal["bca", "percentile"] = "bca",
        seed: int | None = None,
        n_jobs: int = 1,
        save_resamples: bool = True,
        k: int = 10,
        n_steps: int = 20,
        verbose: bool = False,
        threshold: float | None = None,
    ) -> ModelResult:
        """Augment current results with statistical inference.

        Operates on the last operation: ``.fit()`` -> params, ``.explore()`` ->
        effects, ``.predict()`` -> predictions, ``.simulate()`` -> simulations.

        Use ``how="joint"`` for ANOVA-style joint hypothesis tests (F or
        chi-squared per term).

        Which ``how`` methods apply to which operations::

            Operation     asymp   boot   perm   cv   profile   joint
            ─────────     ─────   ────   ────   ──   ───────   ─────
            .fit()          ✓      ✓      ✓     ✓
            .explore()      ✓      ✓      ✓                     ✓
            .predict()      ✓      ✓            ✓
            .simulate()     ✓

        ``profile`` is a special case: it operates on mixed-model variance
        components (``varying_spread``), not on the last operation's results.

        Args:
            how: ``"asymp"`` (default), ``"boot"``, ``"perm"``, ``"cv"``,
                ``"profile"`` (mixed model variance components), or
                ``"joint"`` (ANOVA-style per-term tests).
            what: ``"params|effects"`` (default) infers on the last
                operation's results. ``"params-joint"`` runs joint tests
                alongside params. ``"anova"`` returns ANOVA table.
                ``"model"`` returns model-level fit statistics.
            conf_level: Confidence level (0.95, 95, or "95%").
            errors: Error structure. ``"iid"`` (default) for standard
                OLS/MLE errors, ``"HC0"``–``"HC3"`` for sandwich
                estimators, ``"hetero"`` (alias for HC3/HC0), or
                ``"unequal_var"`` for Welch-style per-cell SEs with
                Satterthwaite df.
            null: Null hypothesis value (default 0.0).
            alternative: ``"two-sided"`` (default), ``"greater"``, or
                ``"less"``.
            n_boot: Number of bootstrap resamples (``how="boot"``).
            n_perm: Number of permutations (``how="perm"``).
            ci_type: Bootstrap CI method: ``"bca"`` (default) or
                ``"percentile"``.
            seed: Random seed for reproducibility.
            n_jobs: Parallel workers. Default 1 (serial).
            save_resamples: Store individual resample results. Default True.
            k: Number of CV folds (``how="cv"``). Default 10.
            n_steps: Profile steps (``how="profile"``). Default 20.
            verbose: Print progress. Default False.
            threshold: Significance threshold (``how="profile"``).

        Returns:
            self: For method chaining.

        Raises:
            ModelStateError: If model not fitted or no last operation.
        """
        from bossanova.internal.infer.dispatch import dispatch_infer

        result = dispatch_infer(
            how=how,
            conf_level=normalize_conf_level(conf_level),
            errors=errors,
            null=null,
            alternative=alternative,
            last_op=self._last_op,
            spec=self._spec,
            bundle=self._bundle,
            fit=self._fit,
            data=self.data,
            link_override=self.link if self.link != self._spec.link else None,
            mee=self._mee,
            pred=self._pred,
            simulations=self._simulations,
            varying_spread=self._varying_spread,
            is_mixed=self._is_mixed,
            n_boot=n_boot,
            n_perm=n_perm,
            ci_type=ci_type,
            seed=seed,
            n_jobs=n_jobs,
            save_resamples=save_resamples,
            k=k,
            n_steps=n_steps,
            verbose=verbose,
            threshold=threshold,
        )

        # Assign populated fields from InferResult
        if result.params_inference is not None:
            self._params_inference = result.params_inference
        if result.mee is not None:
            self._mee = result.mee
        if result.pred is not None:
            self._pred = result.pred
        if result.cv is not None:
            self._cv = result.cv
        if result.sim_inference is not None:
            self._sim_inference = result.sim_inference
        if result.resamples is not None:
            self._resamples = result.resamples
        if result.varying_spread is not None:
            self._varying_spread = result.varying_spread
        if result.profile is not None:
            self._profile = result.profile
        if result.last_op is not None:
            self._last_op = result.last_op

        return ModelResult(self)

    @requires_data
    def vif(self) -> pl.DataFrame:
        """Compute variance inflation factors for model predictors.

        VIF measures multicollinearity — how much the variance of each
        coefficient is inflated due to correlation with other predictors.
        Only requires data (not fitting), since VIF is a property of the
        design matrix.

        Returns:
            DataFrame with columns: term, vif, ci_increase_factor.

        Raises:
            ModelStateError: If no data is available.

        Examples:
            >>> m = model("y ~ x1 + x2 + x3", data)
            >>> m.vif()
        """
        from bossanova.internal.maths.inference.diagnostics import compute_vif

        return compute_vif(self._bundle.X, list(self._bundle.X_names))

    @requires_fit
    def to_odds_ratio(self) -> pl.DataFrame:
        """Transform params to odds ratio scale (binomial GLM only).

        Exponentiates estimate, ci_lower, and ci_upper columns.

        Returns:
            DataFrame with exponentiated values.

        Raises:
            ModelStateError: If model has not been fitted.
            ValueError: If model is not binomial family.

        Examples:
            >>> m = model("y ~ x", data, family="binomial").fit().infer()
            >>> m.to_odds_ratio()
        """
        from bossanova.internal.marginal.transforms import convert_to_odds_ratio

        return convert_to_odds_ratio(self.params, self._spec.family)

    @requires_explore
    def to_response_scale(self) -> pl.DataFrame:
        """Transform effects from link scale to response scale.

        Applies the inverse link function to estimate and CI columns
        on the effects DataFrame. For example, converts log-odds to
        probabilities for logistic models.

        Returns:
            DataFrame with values on response scale.

        Raises:
            ModelStateError: If explore() has not been called.
            ValueError: If model uses identity link.

        Examples:
            >>> m = model("y ~ x", data, family="binomial").fit()
            >>> m.explore("x").infer()
            >>> m.to_response_scale()
        """
        from bossanova.internal.marginal.transforms import convert_to_response_scale

        return convert_to_response_scale(self.effects, self._spec.link)

    @requires_fit
    def to_effect_size(self, *, include_intercept: bool = False) -> pl.DataFrame:
        """Compute standardized effect sizes from params.

        Computes Cohen's d, semi-partial r, eta-squared, and odds ratio
        (for binomial models).

        Args:
            include_intercept: Whether to include the intercept row.

        Returns:
            DataFrame with added effect size columns (d, r_semi, eta_sq,
            and odds_ratio for binomial).

        Raises:
            ModelStateError: If model has not been fitted or inferred.

        Examples:
            >>> m = model("y ~ x1 + x2", data).fit().infer()
            >>> m.to_effect_size()
        """
        from bossanova.internal.marginal.transforms import convert_to_effect_size

        sigma = self._fit.sigma
        df_resid = self._fit.df_resid

        return convert_to_effect_size(
            self.params,
            sigma=sigma,
            df_resid=df_resid,
            family=self._spec.family,
            include_intercept=include_intercept,
        )

    def show_math(self, *, explanations: bool = True) -> "MathDisplay":
        """Display structural LaTeX equation with term explanations.

        Works before or after ``.fit()``. Before data, shows generic symbolic
        form. With data, shows specific factor levels and transform parameters.

        Args:
            explanations: If True (default), include term explanations with
                contrast types, reference levels, and transformation parameters.

        Returns:
            MathDisplay object with rich display support (_repr_latex_,
            _repr_html_, to_latex).

        Examples:
            >>> m = model("y ~ x + group", data)
            >>> m.show_math()           # renders in Jupyter
            >>> m.show_math().to_latex() # raw LaTeX string
        """
        from bossanova.internal.rendering.latex import build_equation

        return build_equation(
            spec=self._spec,
            bundle=self._bundle,
            formula_spec=self._formula_spec if self._bundle is not None else None,
            explanations=explanations,
        )

    @requires_fit
    def filter_significant(self, alpha: float = 0.05) -> pl.DataFrame:
        """Filter params to statistically significant results.

        Args:
            alpha: Significance threshold. Default 0.05.

        Returns:
            DataFrame with only rows where p_value < alpha.

        Raises:
            ModelStateError: If model has not been fitted.
            ValueError: If p_value column not present (call .infer() first).

        Examples:
            >>> m.fit().infer().filter_significant()
            >>> m.filter_significant(0.01)
        """
        df = self.params
        if "p_value" not in df.columns:
            raise ValueError(
                "Cannot filter by significance: 'p_value' column not found. "
                "Call .infer() first to compute p-values."
            )
        return df.filter(pl.col("p_value") < alpha)

    @requires_fit
    def filter_params(self, terms: list[str] | str) -> pl.DataFrame:
        """Filter params to specific coefficient terms.

        Args:
            terms: Term name(s) to include.

        Returns:
            Filtered DataFrame with only the specified terms.

        Examples:
            >>> m.filter_params("x")
            >>> m.filter_params(["x", "z"])
        """
        if isinstance(terms, str):
            terms = [terms]
        return self.params.filter(pl.col("term").is_in(terms))

    @requires_explore
    def filter_effects(
        self,
        *,
        terms: list[str] | str | None = None,
        levels: list[str] | str | None = None,
        contrasts: list[str] | str | None = None,
    ) -> pl.DataFrame:
        """Filter effects DataFrame by term, level, or contrast.

        Args:
            terms: Term name(s) to include (filters 'term' column).
            levels: Level name(s) to include (filters first grid column).
            contrasts: Contrast name(s) to include (filters 'contrast' column).

        Returns:
            Filtered effects DataFrame.

        Raises:
            ModelStateError: If explore() has not been called.

        Examples:
            >>> m.explore("treatment").infer()
            >>> m.filter_effects(levels=["A", "B"])
            >>> m.explore("pairwise(treatment)").infer()
            >>> m.filter_effects(contrasts="A - B")
        """
        return filter_effects_dataframe(
            self.effects, terms=terms, levels=levels, contrasts=contrasts
        )

    @property
    @requires_fit
    def _convergence(self) -> list:
        """Convergence diagnostic messages for mixed models.

        Returns:
            List of ConvergenceMessage objects. Empty for non-mixed models
            or if no issues detected.

        Raises:
            ModelStateError: If the model has not been fitted.
        """

        if not self._is_mixed:
            return []

        return check_convergence(self._fit, self._bundle.re_metadata)

    @requires_fit
    def summary(
        self, style: Literal["r", "compact"] = "r", digits: int = 3
    ) -> FormattedText:
        """Generate a formatted model summary (R-style or compact).

        Args:
            style: ``"r"`` (default) for full R-style output, ``"compact"`` for brief.
            digits: Decimal places for numeric values. Default 3.

        Returns:
            FormattedText that displays without needing ``print()``.

        Raises:
            ModelStateError: If model has not been fitted.
        """
        from bossanova.model.summary import format_summary

        return format_summary(
            spec=self._spec,
            bundle=self._bundle,
            fit=self._fit,
            params_inference=self._params_inference,
            mee=self._mee,
            cv=self._cv,
            varying_spread=self._varying_spread,
            last_op=self._last_op,
            style=style,
            digits=digits,
        )

    def _plot(self, name: str, *args: object, **kwargs: object) -> object:
        """Dispatch to ``bossanova.viz.<name>(self, *args, **kwargs)``.

        Lazily imports the viz module so matplotlib is not required at
        model-construction time.

        Args:
            name: Name of the viz function to call (e.g. ``"plot_params"``).
            *args: Positional arguments forwarded after ``self``.
            **kwargs: Keyword arguments forwarded to the viz function.

        Returns:
            Whatever the underlying viz function returns (typically a
            matplotlib Figure).
        """
        from bossanova import viz

        return getattr(viz, name)(self, *args, **kwargs)

    def plot_params(self, **kwargs: object) -> object:
        """Plot parameter estimates as a forest plot.

        Args:
            **kwargs: Forwarded to ``bossanova.viz.plot_params``. Key
                options: ``include_intercept``, ``sort``, ``show_values``,
                ``show_pvalue``, ``height``, ``aspect``.
        """
        return self._plot("plot_params", **kwargs)

    def plot_ranef(self, **kwargs: object) -> object:
        """Plot random effect estimates.

        Args:
            **kwargs: Forwarded to ``bossanova.viz.plot_ranef``. Key
                options: ``group``, ``term``, ``show``, ``sort``,
                ``height``, ``aspect``.
        """
        return self._plot("plot_ranef", **kwargs)

    def plot_resid(self, **kwargs: object) -> object:
        """Plot residual diagnostics (4-panel grid).

        Args:
            **kwargs: Forwarded to ``bossanova.viz.plot_resid``. Key
                options: ``which``, ``residual_type``, ``lowess``,
                ``label_outliers``, ``height``.
        """
        return self._plot("plot_resid", **kwargs)

    def plot_predict(self, term: str, **kwargs: object) -> object:
        """Plot marginal predictions across a predictor range.

        Args:
            term: Predictor variable to plot predictions for.
            **kwargs: Forwarded to ``bossanova.viz.plot_predict``. Key
                options: ``hue``, ``col``, ``at``, ``interval``,
                ``show_data``, ``show_rug``, ``height``, ``aspect``.
        """
        return self._plot("plot_predict", term, **kwargs)

    def plot_fit(self, x: str, **kwargs: object) -> object:
        """Plot fitted model against observed data.

        Args:
            x: Predictor variable for the x-axis.
            **kwargs: Forwarded to ``bossanova.viz.plot_fit``. Key
                options: ``hue``, ``col``, ``scatter``, ``fit_line``,
                ``ci``, ``blups``, ``groups``, ``height``.
        """
        return self._plot("plot_fit", x, **kwargs)

    def plot_explore(self, specs: str, **kwargs: object) -> object:
        """Plot marginal effects or estimated marginal means.

        Args:
            specs: Specification string for the marginal effects/means.
            **kwargs: Forwarded to ``bossanova.viz.plot_explore``. Key
                options: ``hue``, ``col``, ``row``, ``show_pvalue``,
                ``ref_line``, ``height``, ``aspect``.
        """
        return self._plot("plot_explore", specs, **kwargs)

    def plot_resamples(self, **kwargs: object) -> object:
        """Plot distribution of resampled statistics.

        Args:
            **kwargs: Forwarded to ``bossanova.viz.plot_resamples``. Key
                options: ``which``, ``include_intercept``, ``terms``,
                ``show_ci``, ``show_pvalue``.
        """
        return self._plot("plot_resamples", **kwargs)

    def plot_design(self, **kwargs: object) -> object:
        """Plot design matrix as an annotated heatmap.

        Args:
            **kwargs: Forwarded to ``bossanova.viz.plot_design``. Key
                options: ``max_rows``, ``annotate_terms``,
                ``show_contrast_info``, ``height``, ``aspect``.
        """
        return self._plot("plot_design", **kwargs)

    def plot_vif(self, **kwargs: object) -> object:
        """Plot VIF diagnostics as correlation heatmap.

        Args:
            **kwargs: Forwarded to ``bossanova.viz.plot_vif``. Key
                options: ``cmap``, ``height``, ``aspect``.
        """
        return self._plot("plot_vif", **kwargs)

    def plot_relationships(self, **kwargs: object) -> object:
        """Plot pairwise relationships between response and predictors.

        Args:
            **kwargs: Forwarded to ``bossanova.viz.plot_relationships``.
                Key options: ``show_vif``, ``height``, ``aspect``.
        """
        return self._plot("plot_relationships", **kwargs)

    def plot_profile(self, **kwargs: object) -> object:
        """Plot profile likelihood curves.

        Requires ``.infer(how="profile")`` to have been called first.

        Args:
            **kwargs: Forwarded to ``bossanova.viz.plot_profile``. Key
                options: ``height``, ``aspect``.
        """
        if self._profile is None:
            raise ModelStateError(
                "No profile likelihood computed. Call .infer(how='profile') first."
            )
        from bossanova import viz

        return viz.plot_profile(self._profile, **kwargs)
