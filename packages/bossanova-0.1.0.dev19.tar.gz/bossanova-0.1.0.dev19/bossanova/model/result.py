"""ModelResult — display-friendly proxy returned by model methods.

When a model method like ``.fit()``, ``.explore()``, or ``.infer()`` is
called, it returns a ``ModelResult`` instead of the raw model instance.
This proxy delegates display to the underlying result DataFrame, giving
notebook environments (marimo, Jupyter) consistent rendering with property
access (e.g., ``.params``, ``.effects``).

All other attribute access and method calls are forwarded to the model
instance, so method chaining works seamlessly::

    m = model("y ~ x", data).fit().infer()   # Each returns ModelResult
    m.params          # Forwarded to model.params → DataFrame
    m.explore("x")    # Forwarded to model.explore() → new ModelResult
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import polars as pl

if TYPE_CHECKING:
    from pathlib import Path

    from bossanova.model.core import model

__all__ = ["ModelResult"]


class ModelResult:
    """Proxy returned by model methods that renders as a DataFrame.

    Enables consistent notebook rendering (marimo, Jupyter) by delegating
    ``_repr_html_`` to the current result DataFrame, while forwarding all
    model methods and properties for seamless chaining.

    The displayed DataFrame is always the *current* result — determined
    dynamically by the model's ``_last_op`` state — so mutations to the
    model are reflected immediately.

    Args:
        model_ref: The model instance that produced this result.
    """

    __slots__ = ("_model",)

    def __init__(self, model_ref: model) -> None:
        object.__setattr__(self, "_model", model_ref)

    @property
    def dataframe(self) -> pl.DataFrame | None:
        """The current result DataFrame.

        Returns the same DataFrame as the corresponding model property
        (``.params``, ``.effects``, ``.predictions``, etc.) based on
        whichever method was called last.

        Returns:
            Polars DataFrame for the last operation, or None if no
            result-producing method has been called.
        """
        return self._model._result_for_display()

    def __repr__(self) -> str:
        """Text representation with model header and result table.

        Delegates to the model's ``__repr__``, which includes the header
        line and (when ``_auto_display`` is True) the result DataFrame.

        Returns:
            String showing model metadata and optionally the result table.
        """
        return repr(self._model)

    def _repr_html_(self) -> str:
        """Rich HTML representation for notebooks.

        Returns just the result DataFrame's HTML table — no model header —
        for consistent rendering with property access like ``.effects``.
        Notebook environments (marimo, Jupyter) render this identically
        to a bare ``pl.DataFrame``.

        When no displayable result is available or auto-display is off,
        falls back to the model header in a ``<pre>`` tag.

        Returns:
            HTML string from the result DataFrame, or header-only HTML.
        """
        if not self._model._auto_display:
            return f"<pre>{self._model._header_repr()}</pre>"

        df = self._model._result_for_display()
        if df is None:
            return f"<pre>{self._model._header_repr()}</pre>"

        return df._repr_html_()

    def to_markdown(
        self,
        path: str | Path | None = None,
        caption: str | None = None,
    ) -> str:
        """Export the current result as a pipe-delimited markdown table.

        Converts whichever result is currently displayed (params, effects,
        predictions, etc.) to GitHub Flavored Markdown / Quarto-compatible
        pipe table format. Suitable for embedding in ``.qmd`` files via
        Quarto's ``{{< include >}}`` shortcode.

        Args:
            path: Optional file path to write the markdown string. Parent
                directories are created automatically. If None, returns
                the string without writing.
            caption: Optional table caption, rendered as ``Table: ...``
                above the table (Quarto cross-reference syntax).

        Returns:
            Pipe-delimited markdown table as a string.

        Raises:
            ValueError: If no result is available (no method has been
                called yet).

        Examples:
            >>> m.infer().to_markdown("results/params.md", caption="Parameters")
            >>> md = m.infer().to_markdown()  # string only
        """
        from bossanova.internal.rendering.markdown import (
            dataframe_to_markdown,
            write_text,
        )

        df = self.dataframe
        if df is None:
            msg = (
                "No result available. Call .fit(), .explore(), .infer(), "
                ".predict(), or .simulate() before exporting."
            )
            raise ValueError(msg)
        text = dataframe_to_markdown(df, caption=caption)
        if path is not None:
            write_text(text, path)
        return text

    def to_csv(
        self,
        path: str | Path | None = None,
    ) -> str:
        """Export the current result as CSV.

        Args:
            path: Optional file path to write the CSV. Parent directories
                are created automatically. If None, returns the CSV
                string without writing.

        Returns:
            CSV content as a string.

        Raises:
            ValueError: If no result is available.

        Examples:
            >>> m.infer().to_csv("results/params.csv")
            >>> csv = m.infer().to_csv()  # string only
        """
        from bossanova.internal.rendering.markdown import write_text

        df = self.dataframe
        if df is None:
            msg = (
                "No result available. Call .fit(), .explore(), .infer(), "
                ".predict(), or .simulate() before exporting."
            )
            raise ValueError(msg)
        text = df.write_csv()
        if path is not None:
            write_text(text, path)
        return text

    def __getattr__(self, name: str) -> Any:
        """Forward attribute access to the underlying model.

        Enables seamless chaining (``m.fit().explore("x").infer()``) and
        property access (``m.fit().params``) through the proxy.

        Args:
            name: Attribute name to look up on the model.

        Returns:
            The attribute from the model instance.
        """
        return getattr(self._model, name)
