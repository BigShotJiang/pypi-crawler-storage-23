"""Bundled sample datasets for regression and mixed-effects modeling.

| Dataset | Argument | Description |
|---------|----------|-------------|
| Advertising | `"advertising"` | TV, radio, newspaper ad spend vs sales (200 x 4) |
| Cake | `"cake"` | Baking angle by recipe and temperature (270 x 5) |
| ChickWeight | `"chickweight"` | Chick weight over time by diet (578 x 4) |
| Credit | `"credit"` | Credit card balance by income and demographics (400 x 11) |
| Gammas | `"gammas"` | Simulated BOLD signal for Gamma GLM (6000 x 4) |
| mtcars | `"mtcars"` | Motor Trend car road tests (32 x 12) |
| Penguins | `"penguins"` | Palmer Penguins body measurements (344 x 8) |
| Poker | `"poker"` | Poker hand outcomes by skill and limit (300 x 4) |
| Sleep | `"sleep"` | Reaction time vs sleep deprivation (180 x 3) |
| Titanic | `"titanic"` | Passenger survival with demographics (891 x 15) |
| Titanic Train | `"titanic_train"` | Titanic training set, Kaggle format (891 x 12) |
| Titanic Test | `"titanic_test"` | Titanic test set, Kaggle format (418 x 11) |
"""

from importlib.resources import files
from typing import Literal

import polars as pl

__all__ = [
    "load_dataset",
    "show_datasets",
]

# Available datasets with descriptions
DATASETS: dict[str, str] = {
    "advertising": "TV, radio, and newspaper ad spend vs sales. 200 obs, 4 cols.",
    "cake": "Cake baking angle by recipe and temperature — lme4 mixed-model example. 270 obs, 5 cols.",
    "chickweight": "Chick weight over time by diet — repeated-measures growth data. 578 obs, 4 cols.",
    "credit": "Credit card balance predicted by income, demographics, and student status. 400 obs, 11 cols.",
    "gammas": "Simulated BOLD signal across timepoints, ROIs, and subjects — Gamma GLM example. 6000 obs, 4 cols.",
    "mtcars": "Motor Trend car road tests (1974) — classic regression dataset. 32 obs, 12 cols.",
    "penguins": "Palmer Penguins body measurements by species, island, and sex. 344 obs, 8 cols.",
    "poker": "Poker hand outcomes by skill level and limit — repeated-measures design. 300 obs, 4 cols.",
    "sleep": "Reaction time vs days of sleep deprivation by subject — lme4 mixed-model example. 180 obs, 3 cols.",
    "titanic": "Titanic passenger survival with demographics and travel details. 891 obs, 15 cols.",
    "titanic_train": "Titanic training set (Kaggle format). 891 obs, 12 cols.",
    "titanic_test": "Titanic test set (Kaggle format, no survival column). 418 obs, 11 cols.",
}

DatasetName = Literal[
    "advertising",
    "cake",
    "chickweight",
    "credit",
    "gammas",
    "mtcars",
    "penguins",
    "poker",
    "sleep",
    "titanic",
    "titanic_train",
    "titanic_test",
]


def show_datasets() -> pl.DataFrame:
    """Show available datasets with descriptions.

    Returns:
        DataFrame with columns: name, description.

    Examples:
        ```python
        from bossanova.data import show_datasets
        show_datasets()
        # shape: (12, 2)
        # ┌───────────────┬─────────────────────────────────┐
        # │ name          ┆ description                     │
        # │ ---           ┆ ---                             │
        # │ str           ┆ str                             │
        # ╞═══════════════╪═════════════════════════════════╡
        # │ sleep         ┆ Sleep study data (reaction ...  │
        # │ mtcars        ┆ Motor Trend Car Road Tests ...  │
        # │ ...           ┆ ...                             │
        # └───────────────┴─────────────────────────────────┘
        ```
    """
    rows = [{"name": name, "description": desc} for name, desc in DATASETS.items()]
    return pl.DataFrame(rows)


def load_dataset(name: DatasetName) -> pl.DataFrame:
    """Load a sample dataset as a Polars DataFrame.

    Datasets are bundled with the package and loaded directly from
    package resources. No network access required.

    Args:
        name: Name of the dataset to load. Use `show_datasets()` to see
            available options.

    Returns:
        The requested dataset as a Polars DataFrame.

    Raises:
        ValueError: If the dataset name is not recognized.

    Examples:
        ```python
        from bossanova.data import load_dataset

        # Load sleep study data for mixed models
        sleep = load_dataset("sleep")
        print(sleep.head())

        # Load mtcars for regression examples
        mtcars = load_dataset("mtcars")
        ```
    """
    if name not in DATASETS:
        valid = list(DATASETS.keys())
        raise ValueError(f"Unknown dataset: '{name}'. Valid options are: {valid}")

    # Load from package resources
    data_files = files("bossanova.data")
    csv_path = data_files.joinpath(f"{name}.csv")

    # Read CSV from package resource
    with csv_path.open("rb") as f:
        return pl.read_csv(f)
