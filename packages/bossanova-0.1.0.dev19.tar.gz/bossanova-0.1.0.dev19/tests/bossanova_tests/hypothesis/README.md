# Hypothesis Property-Based Tests

> Quick reference for adding and understanding property-based tests in bossanova.

## Overview

These tests verify **mathematical invariants** that must hold for any valid input. Unlike example-based tests, Hypothesis automatically discovers edge cases across the input domain.

| Primitive | Mathematical Meaning |
|-----------|---------------------|
| `@given(x=strategy)` | "For all x in Domain..." |
| `assume(predicate)` | Restrict domain (filter invalid inputs) |
| `@st.composite` | Construct valid inputs by construction |

**Run all hypothesis tests:**
```bash
pixi run hypothesis
```

---

## Theorem Chain

Tests are organized by mathematical dependencies. Each theorem builds on prior results:

```
LA.1-3 (QR decomposition)
    ↓
LA.4-5 (SVD) ──→ LA.7 (log-det)
    ↓
OLS.1-4 (normal equations, coefficient estimation)
    ↓
WLS.1-3 (weighted least squares, IRLS)
    ↓                    ↓
INF.1-2 (SE, CIs)    AGQ.1-3 (adaptive GH quadrature)
    ↓
INF.4-5 (Wald, F-tests) ──→ EMM.1-2 (marginal means)
    ↓
DX.1-4 (diagnostics: leverage, residuals)
```

**Domain prefixes:**
| Prefix | Domain |
|--------|--------|
| `LA` | Linear algebra |
| `OLS` | Ordinary least squares |
| `WLS` | Weighted least squares |
| `INF` | Inference (SE, CI, tests) |
| `DX` | Diagnostics |
| `EMM` | Estimated marginal means |
| `TR` | Transforms |
| `CT` | Contrasts |
| `LMM` | Linear mixed models |
| `BS` | Bootstrap |
| `AGQ` | Adaptive Gauss-Hermite quadrature |

---

## Adding a New Test

### 1. Choose the right file

| Testing... | File |
|------------|------|
| Matrix operations (QR, SVD, solve) | `ops/test_linalg_hypothesis.py` |
| JAX/NumPy backend parity | `ops/test_backend_hypothesis.py` |
| Residuals, leverage, influence | `ops/test_diagnostics_hypothesis.py` |
| Standard errors, CIs, p-values | `ops/test_inference_hypothesis.py` |
| GLM fitting (IRLS, deviance) | `ops/test_glm_hypothesis.py` |
| Contrast matrices (sum, poly) | `formula/test_contrasts_hypothesis.py` |
| Data transforms (center, zscore) | `formula/test_transforms_hypothesis.py` |
| EMMs, Wald/F tests | `marginal/test_emm_hypothesis.py` |

### 2. Use shared strategies and assumptions

```python
from tests.bossanova_tests.hypothesis.strategies import (
    HYPOTHESIS_SETTINGS,           # deadline=None (JAX JIT)
    HYPOTHESIS_SETTINGS_EXPENSIVE, # + max_examples=50
    ols_problem,                   # (X, y) pairs
    positive_definite_matrix,      # PD matrices
)

from tests.bossanova_tests.hypothesis.assumptions import (
    assume_full_rank,              # Filter rank-deficient
    assume_well_conditioned,       # Filter ill-conditioned
    assume_positive_variance,      # Filter constant vectors
)
```

### 3. Follow the docstring format

**Test docstring:**
```python
@given(data=ols_problem())
@settings(**HYPOTHESIS_SETTINGS)
def test_residuals_orthogonal_to_X(self, data):
    """OLS.1: Residuals orthogonal to column space of X.

    At the OLS solution, X'(y - Xβ̂) = 0.

    Intuition
    ---------
    Residuals represent unexplained variation. Zero correlation
    with X means we've extracted all linear signal.

    Depends
    -------
    LA.1 : QR decomposition exists

    Enables
    -------
    OLS.5 : Hat matrix idempotent
    DX.1 : Leverage bounds

    References
    ----------
    .. [hastie2009] Hastie, Tibshirani, Friedman. ESL (2009), §3.2.
    """
```

**Module header:**
```python
"""Property-based tests for [domain] properties.

Theorem Chain
=============
    [parent theorems]
          ↓
    [this module's theorems] ← THIS MODULE
          ↓
    [enabled theorems]

References
----------
.. [key] Author. Title. Year.
"""
```

### 4. Use tolerances from `_tolerances.py`

Tolerances are derived from backward error analysis (Golub & Van Loan), not empirical tuning:

```python
from bossanova.internal.math._tolerances import (
    EPS,                    # Machine epsilon (~2.2e-16)
    MAX_COND,               # 1e10 - filter ill-conditioned
    residual_atol,          # For X'e ≈ 0 checks
    solve_atol,             # For solution comparisons
    fitted_atol,            # For ŷ = Xβ̂ checks
    decomposition_atol,     # For Q'Q = I, A = QR checks
)
```

---

## Checklist

- [ ] Theorem ID in docstring (e.g., `OLS.1`, `INF.2`)
- [ ] `Intuition` section explaining *why* the property holds
- [ ] `Depends` section listing prerequisite theorems
- [ ] `Enables` section listing downstream theorems
- [ ] `@settings(**HYPOTHESIS_SETTINGS)` (or `_EXPENSIVE`)
- [ ] Use `assume_*` helpers, not raw `assume()`
- [ ] Tolerances from `_tolerances.py`, not magic numbers

---

## Key References

| Key | Citation |
|-----|----------|
| `hastie2009` | Hastie, Tibshirani, Friedman. *Elements of Statistical Learning* (2009) |
| `golub2013` | Golub, Van Loan. *Matrix Computations* (2013) |
| `greene2018` | Greene. *Econometric Analysis* (2018) |
| `casella2002` | Casella, Berger. *Statistical Inference* (2002) |
| `mccullagh1989` | McCullagh, Nelder. *Generalized Linear Models* (1989) |
| `bates2015` | Bates et al. *lme4* paper (2015) |
| `efron1993` | Efron, Tibshirani. *An Introduction to the Bootstrap* (1993) |
