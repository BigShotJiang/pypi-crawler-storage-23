[![Git](https://git-scm.com/images/logo@2x.png)](https://git-scm.com/) --everything-is-local
![](https://git-scm.com/images/dark-mode.svg)
  * [About](https://git-scm.com/about)
    * [Trademark](https://git-scm.com/about/trademark)
  * [Learn](https://git-scm.com/learn)
    * [Book](https://git-scm.com/book)
    * [Cheat Sheet](https://git-scm.com/cheat-sheet)
    * [Videos](https://git-scm.com/videos)
    * [External Links](https://git-scm.com/doc/ext)
  * [Tools](https://git-scm.com/tools)
    * [Command Line](https://git-scm.com/tools/command-line)
    * [GUIs](https://git-scm.com/tools/guis)
    * [Hosting](https://git-scm.com/tools/hosting)
  * [Reference](https://git-scm.com/docs)
  * [Install](https://git-scm.com/install/linux)
  * [Community](https://git-scm.com/community)


  * Table of Contents
    * [NAME](https://git-scm.com/docs/git-rev-list#_name)
    * [SYNOPSIS](https://git-scm.com/docs/git-rev-list#_synopsis)
    * [DESCRIPTION](https://git-scm.com/docs/git-rev-list#_description)
    * [OPTIONS](https://git-scm.com/docs/git-rev-list#_options)
    * [PRETTY FORMATS](https://git-scm.com/docs/git-rev-list#_pretty_formats)
    * [EXAMPLES](https://git-scm.com/docs/git-rev-list#_examples)
    * [GIT](https://git-scm.com/docs/git-rev-list#_git)


[ English ▾](https://git-scm.com/docs/git-rev-list)
Localized versions of **git-rev-list** manual
  1. [English ](https://git-scm.com/docs/git-rev-list)
  2. [Deutsch ](https://git-scm.com/docs/git-rev-list/de)
  3. [Français ](https://git-scm.com/docs/git-rev-list/fr)
  4. [Português (Brasil) ](https://git-scm.com/docs/git-rev-list/pt_BR)
  5. [українська мова ](https://git-scm.com/docs/git-rev-list/uk)
  6. [简体中文 ](https://git-scm.com/docs/git-rev-list/zh_HANS-CN)

Want to read in your language or fix typos?
[You can help translate this page](https://github.com/jnavila/git-manpages-l10n).
[Topics ▾](https://git-scm.com/docs/git-rev-list)
### Setup and Config
  * [ git ](https://git-scm.com/docs/git)
  * [ config ](https://git-scm.com/docs/git-config)
  * [ help ](https://git-scm.com/docs/git-help)
  * [ bugreport ](https://git-scm.com/docs/git-bugreport)
  * [ Credential helpers ](https://git-scm.com/doc/credential-helpers)


### Getting and Creating Projects
  * [ init ](https://git-scm.com/docs/git-init)
  * [ clone ](https://git-scm.com/docs/git-clone)


### Basic Snapshotting
  * [ add ](https://git-scm.com/docs/git-add)
  * [ status ](https://git-scm.com/docs/git-status)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ commit ](https://git-scm.com/docs/git-commit)
  * [ notes ](https://git-scm.com/docs/git-notes)
  * [ restore ](https://git-scm.com/docs/git-restore)
  * [ reset ](https://git-scm.com/docs/git-reset)
  * [ rm ](https://git-scm.com/docs/git-rm)
  * [ mv ](https://git-scm.com/docs/git-mv)


### Branching and Merging
  * [ branch ](https://git-scm.com/docs/git-branch)
  * [ checkout ](https://git-scm.com/docs/git-checkout)
  * [ switch ](https://git-scm.com/docs/git-switch)
  * [ merge ](https://git-scm.com/docs/git-merge)
  * [ mergetool ](https://git-scm.com/docs/git-mergetool)
  * [ log ](https://git-scm.com/docs/git-log)
  * [ stash ](https://git-scm.com/docs/git-stash)
  * [ tag ](https://git-scm.com/docs/git-tag)
  * [ worktree ](https://git-scm.com/docs/git-worktree)


### Sharing and Updating Projects
  * [ fetch ](https://git-scm.com/docs/git-fetch)
  * [ pull ](https://git-scm.com/docs/git-pull)
  * [ push ](https://git-scm.com/docs/git-push)
  * [ remote ](https://git-scm.com/docs/git-remote)
  * [ submodule ](https://git-scm.com/docs/git-submodule)


### Inspection and Comparison
  * [ show ](https://git-scm.com/docs/git-show)
  * [ log ](https://git-scm.com/docs/git-log)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ difftool ](https://git-scm.com/docs/git-difftool)
  * [ range-diff ](https://git-scm.com/docs/git-range-diff)
  * [ shortlog ](https://git-scm.com/docs/git-shortlog)
  * [ describe ](https://git-scm.com/docs/git-describe)


### Patching
  * [ apply ](https://git-scm.com/docs/git-apply)
  * [ cherry-pick ](https://git-scm.com/docs/git-cherry-pick)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ rebase ](https://git-scm.com/docs/git-rebase)
  * [ revert ](https://git-scm.com/docs/git-revert)


### Debugging
  * [ bisect ](https://git-scm.com/docs/git-bisect)
  * [ blame ](https://git-scm.com/docs/git-blame)
  * [ grep ](https://git-scm.com/docs/git-grep)


### Email
  * [ am ](https://git-scm.com/docs/git-am)
  * [ apply ](https://git-scm.com/docs/git-apply)
  * [ imap-send ](https://git-scm.com/docs/git-imap-send)
  * [ format-patch ](https://git-scm.com/docs/git-format-patch)
  * [ send-email ](https://git-scm.com/docs/git-send-email)
  * [ request-pull ](https://git-scm.com/docs/git-request-pull)


### External Systems
  * [ svn ](https://git-scm.com/docs/git-svn)
  * [ fast-import ](https://git-scm.com/docs/git-fast-import)


### Server Admin
  * [ daemon ](https://git-scm.com/docs/git-daemon)
  * [ update-server-info ](https://git-scm.com/docs/git-update-server-info)


### Guides
  * [ gitattributes ](https://git-scm.com/docs/gitattributes)
  * [ Command-line interface conventions ](https://git-scm.com/docs/gitcli)
  * [ Everyday Git ](https://git-scm.com/docs/giteveryday)
  * [ Frequently Asked Questions (FAQ) ](https://git-scm.com/docs/gitfaq)
  * [ Glossary ](https://git-scm.com/docs/gitglossary)
  * [ Hooks ](https://git-scm.com/docs/githooks)
  * [ gitignore ](https://git-scm.com/docs/gitignore)
  * [ gitmodules ](https://git-scm.com/docs/gitmodules)
  * [ Revisions ](https://git-scm.com/docs/gitrevisions)
  * [ Submodules ](https://git-scm.com/docs/gitsubmodules)
  * [ Tutorial ](https://git-scm.com/docs/gittutorial)
  * [ Workflows ](https://git-scm.com/docs/gitworkflows)
  * [ All guides... ](https://git-scm.com/docs/git#_guides)


### Administration
  * [ clean ](https://git-scm.com/docs/git-clean)
  * [ gc ](https://git-scm.com/docs/git-gc)
  * [ fsck ](https://git-scm.com/docs/git-fsck)
  * [ reflog ](https://git-scm.com/docs/git-reflog)
  * [ filter-branch ](https://git-scm.com/docs/git-filter-branch)
  * [ instaweb ](https://git-scm.com/docs/git-instaweb)
  * [ archive ](https://git-scm.com/docs/git-archive)
  * [ bundle ](https://git-scm.com/docs/git-bundle)


### Plumbing Commands
  * [ cat-file ](https://git-scm.com/docs/git-cat-file)
  * [ check-ignore ](https://git-scm.com/docs/git-check-ignore)
  * [ checkout-index ](https://git-scm.com/docs/git-checkout-index)
  * [ commit-tree ](https://git-scm.com/docs/git-commit-tree)
  * [ count-objects ](https://git-scm.com/docs/git-count-objects)
  * [ diff-index ](https://git-scm.com/docs/git-diff-index)
  * [ for-each-ref ](https://git-scm.com/docs/git-for-each-ref)
  * [ hash-object ](https://git-scm.com/docs/git-hash-object)
  * [ ls-files ](https://git-scm.com/docs/git-ls-files)
  * [ ls-tree ](https://git-scm.com/docs/git-ls-tree)
  * [ merge-base ](https://git-scm.com/docs/git-merge-base)
  * [ read-tree ](https://git-scm.com/docs/git-read-tree)
  * [ rev-list ](https://git-scm.com/docs/git-rev-list)
  * [ rev-parse ](https://git-scm.com/docs/git-rev-parse)
  * [ show-ref ](https://git-scm.com/docs/git-show-ref)
  * [ symbolic-ref ](https://git-scm.com/docs/git-symbolic-ref)
  * [ update-index ](https://git-scm.com/docs/git-update-index)
  * [ update-ref ](https://git-scm.com/docs/git-update-ref)
  * [ verify-pack ](https://git-scm.com/docs/git-verify-pack)
  * [ write-tree ](https://git-scm.com/docs/git-write-tree)


[ Latest version ▾ ](https://git-scm.com/docs/git-rev-list) git-rev-list last updated in 2.53.0
Changes in the **git-rev-list** manual
  1. [2.53.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2026-02-02_ ](https://git-scm.com/docs/git-rev-list/2.53.0)
  2. [2.52.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-11-17_ ](https://git-scm.com/docs/git-rev-list/2.52.0)
  3. 2.51.2 no changes
  4. [2.51.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-10-15_ ](https://git-scm.com/docs/git-rev-list/2.51.1)
  5. [2.51.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-08-18_ ](https://git-scm.com/docs/git-rev-list/2.51.0)
  6. 2.50.1 no changes
  7. [2.50.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-06-16_ ](https://git-scm.com/docs/git-rev-list/2.50.0)
  8. 2.49.1 no changes
  9. [2.49.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-03-14_ ](https://git-scm.com/docs/git-rev-list/2.49.0)
  10. 2.48.1 → 2.48.2 no changes
  11. [2.48.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-01-10_ ](https://git-scm.com/docs/git-rev-list/2.48.0)
  12. 2.45.1 → 2.47.3 no changes
  13. [2.45.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-29_ ](https://git-scm.com/docs/git-rev-list/2.45.0)
  14. 2.43.3 → 2.44.4 no changes
  15. [2.43.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-02-13_ ](https://git-scm.com/docs/git-rev-list/2.43.2)
  16. 2.43.1 no changes
  17. [2.43.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-11-20_ ](https://git-scm.com/docs/git-rev-list/2.43.0)
  18. 2.42.1 → 2.42.4 no changes
  19. [2.42.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-08-21_ ](https://git-scm.com/docs/git-rev-list/2.42.0)
  20. 2.41.1 → 2.41.3 no changes
  21. [2.41.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-06-01_ ](https://git-scm.com/docs/git-rev-list/2.41.0)
  22. 2.40.1 → 2.40.4 no changes
  23. [2.40.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-03-12_ ](https://git-scm.com/docs/git-rev-list/2.40.0)
  24. 2.39.1 → 2.39.5 no changes
  25. [2.39.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-12-12_ ](https://git-scm.com/docs/git-rev-list/2.39.0)
  26. 2.38.1 → 2.38.5 no changes
  27. [2.38.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-10-02_ ](https://git-scm.com/docs/git-rev-list/2.38.0)
  28. 2.37.1 → 2.37.7 no changes
  29. [2.37.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-06-27_ ](https://git-scm.com/docs/git-rev-list/2.37.0)
  30. 2.36.1 → 2.36.6 no changes
  31. [2.36.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-04-18_ ](https://git-scm.com/docs/git-rev-list/2.36.0)
  32. 2.35.1 → 2.35.8 no changes
  33. [2.35.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-01-24_ ](https://git-scm.com/docs/git-rev-list/2.35.0)
  34. 2.33.3 → 2.34.8 no changes
  35. [2.33.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-03-23_ ](https://git-scm.com/docs/git-rev-list/2.33.2)
  36. [2.33.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-10-12_ ](https://git-scm.com/docs/git-rev-list/2.33.1)
  37. [2.33.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-08-16_ ](https://git-scm.com/docs/git-rev-list/2.33.0)
  38. 2.32.1 → 2.32.7 no changes
  39. [2.32.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-06-06_ ](https://git-scm.com/docs/git-rev-list/2.32.0)
  40. 2.31.1 → 2.31.8 no changes
  41. [2.31.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-03-15_ ](https://git-scm.com/docs/git-rev-list/2.31.0)
  42. 2.30.1 → 2.30.9 no changes
  43. [2.30.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-12-27_ ](https://git-scm.com/docs/git-rev-list/2.30.0)
  44. 2.29.1 → 2.29.3 no changes
  45. [2.29.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-10-19_ ](https://git-scm.com/docs/git-rev-list/2.29.0)
  46. 2.28.1 no changes
  47. [2.28.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-07-27_ ](https://git-scm.com/docs/git-rev-list/2.28.0)
  48. 2.27.1 no changes
  49. [2.27.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-06-01_ ](https://git-scm.com/docs/git-rev-list/2.27.0)
  50. 2.26.1 → 2.26.3 no changes
  51. [2.26.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-03-22_ ](https://git-scm.com/docs/git-rev-list/2.26.0)
  52. 2.25.1 → 2.25.5 no changes
  53. [2.25.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-01-13_ ](https://git-scm.com/docs/git-rev-list/2.25.0)
  54. 2.24.1 → 2.24.4 no changes
  55. [2.24.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-11-04_ ](https://git-scm.com/docs/git-rev-list/2.24.0)
  56. 2.23.1 → 2.23.4 no changes
  57. [2.23.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-08-16_ ](https://git-scm.com/docs/git-rev-list/2.23.0)
  58. 2.22.1 → 2.22.5 no changes
  59. [2.22.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-06-07_ ](https://git-scm.com/docs/git-rev-list/2.22.0)
  60. 2.21.1 → 2.21.4 no changes
  61. [2.21.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-02-24_ ](https://git-scm.com/docs/git-rev-list/2.21.0)
  62. 2.20.1 → 2.20.5 no changes
  63. [2.20.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-12-09_ ](https://git-scm.com/docs/git-rev-list/2.20.0)
  64. 2.19.3 → 2.19.6 no changes
  65. [2.19.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-11-21_ ](https://git-scm.com/docs/git-rev-list/2.19.2)
  66. 2.17.1 → 2.19.1 no changes
  67. [2.17.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-04-02_ ](https://git-scm.com/docs/git-rev-list/2.17.0)
  68. [2.16.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/git-rev-list/2.16.6)
  69. [2.15.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/git-rev-list/2.15.4)
  70. [2.14.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/git-rev-list/2.14.6)
  71. [2.13.7 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-05-22_ ](https://git-scm.com/docs/git-rev-list/2.13.7)
  72. [2.12.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-09-22_ ](https://git-scm.com/docs/git-rev-list/2.12.5)
  73. [2.11.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-09-22_ ](https://git-scm.com/docs/git-rev-list/2.11.4)
  74. [2.10.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-09-22_ ](https://git-scm.com/docs/git-rev-list/2.10.5)
  75. [2.9.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-07-30_ ](https://git-scm.com/docs/git-rev-list/2.9.5)
  76. [2.8.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-07-30_ ](https://git-scm.com/docs/git-rev-list/2.8.6)
  77. [2.7.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-07-30_ ](https://git-scm.com/docs/git-rev-list/2.7.6)
  78. [2.6.7 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-05-05_ ](https://git-scm.com/docs/git-rev-list/2.6.7)
  79. [2.5.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-05-05_ ](https://git-scm.com/docs/git-rev-list/2.5.6)
  80. [2.4.12 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-05-05_ ](https://git-scm.com/docs/git-rev-list/2.4.12)
  81. [2.3.10 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2015-09-28_ ](https://git-scm.com/docs/git-rev-list/2.3.10)
  82. [2.2.3 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2015-09-04_ ](https://git-scm.com/docs/git-rev-list/2.2.3)
  83. [2.1.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2014-12-17_ ](https://git-scm.com/docs/git-rev-list/2.1.4)
  84. [2.0.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2014-12-17_ ](https://git-scm.com/docs/git-rev-list/2.0.5)


Check your version of git by running
`git --version`
##  [](https://git-scm.com/docs/git-rev-list#_name)NAME
git-rev-list - Lists commit objects in reverse chronological order
##  [](https://git-scm.com/docs/git-rev-list#_synopsis)SYNOPSIS
```
_git rev-list_ [<options>] <commit>…​ [--] [<path>…​]
```

##  [](https://git-scm.com/docs/git-rev-list#_description)DESCRIPTION
List commits that are reachable by following the `parent` links from the given commit(s), but exclude commits that are reachable from the one(s) given with a _^_ in front of them. The output is given in reverse chronological order by default.
You can think of this as a set operation. Commits reachable from any of the commits given on the command line form a set, and then commits reachable from any of the ones given with _^_ in front are subtracted from that set. The remaining commits are what comes out in the command’s output. Various other options and paths parameters can be used to further limit the result.
Thus, the following command:
```
$ git rev-list foo bar ^baz
```

means "list all the commits which are reachable from _foo_ or _bar_ , but not from _baz_ ".
A special notation "_< commit1>_`..`_< commit2>_" can be used as a short-hand for "`^`_< commit1>_ _< commit2>_". For example, either of the following may be used interchangeably:
```
$ git rev-list origin..HEAD
$ git rev-list HEAD ^origin
```

Another special notation is "_< commit1>_`...`_< commit2>_" which is useful for merges. The resulting set of commits is the symmetric difference between the two operands. The following two commands are equivalent:
```
$ git rev-list A B --not $(git merge-base --all A B)
$ git rev-list A...B
```

_rev-list_ is an essential Git command, since it provides the ability to build and traverse commit ancestry graphs. For this reason, it has a lot of different options that enable it to be used by commands as different as _git bisect_ and _git repack_.
##  [](https://git-scm.com/docs/git-rev-list#_options)OPTIONS
###  [](https://git-scm.com/docs/git-rev-list#_commit_limiting)Commit Limiting
Besides specifying a range of commits that should be listed using the special notations explained in the description, additional commit limiting may be applied.
Using more options generally further limits the output (e.g. `--since=`_< date1>_ limits to commits newer than _< date1>_, and using it with `--grep=`_< pattern>_ further limits to commits whose log message has a line that matches _< pattern>_), unless otherwise noted.
Note that these are applied before commit ordering and formatting options, such as `--reverse`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt--number)`-`_< number>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt--nnumber)`-n` _< number>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---max-countnumber)`--max-count=`_< number>_

Limit the output to _< number>_ commits.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---skipnumber)`--skip=`_< number>_

Skip _< number>_ commits before starting to show the commit output.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---sincedate)`--since=`_< date>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---afterdate)`--after=`_< date>_

Show commits more recent than _< date>_.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---since-as-filterdate)`--since-as-filter=`_< date>_

Show all commits more recent than _< date>_. This visits all commits in the range, rather than stopping at the first commit which is older than _< date>_.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---untildate)`--until=`_< date>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---beforedate)`--before=`_< date>_

Show commits older than _< date>_.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---max-agetimestamp)`--max-age=`_< timestamp>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---min-agetimestamp)`--min-age=`_< timestamp>_

Limit the commits output to specified time range.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---authorpattern)`--author=`_< pattern>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---committerpattern)`--committer=`_< pattern>_

Limit the commits output to ones with author/committer header lines that match the _< pattern>_ regular expression. With more than one `--author=`_< pattern>_, commits whose author matches any of the _< pattern>_ are chosen (similarly for multiple `--committer=`_< pattern>_).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---grep-reflogpattern)`--grep-reflog=`_< pattern>_

Limit the commits output to ones with reflog entries that match the _< pattern>_ regular expression. With more than one `--grep-reflog`, commits whose reflog message matches any of the given patterns are chosen. It is an error to use this option unless `--walk-reflogs` is in use.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---greppattern)`--grep=`_< pattern>_

Limit the commits output to ones with a log message that matches the _< pattern>_ regular expression. With more than one `--grep=`_< pattern>_, commits whose message matches any of the _< pattern>_ are chosen (but see `--all-match`).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---all-match)`--all-match`

Limit the commits output to ones that match all given `--grep`, instead of ones that match at least one.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---invert-grep)`--invert-grep`

Limit the commits output to ones with a log message that do not match the _< pattern>_ specified with `--grep=`_< pattern>_.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt--i)`-i`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---regexp-ignore-case)`--regexp-ignore-case`

Match the regular expression limiting patterns without regard to letter case.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---basic-regexp)`--basic-regexp`

Consider the limiting patterns to be basic regular expressions; this is the default.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt--E)`-E`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---extended-regexp)`--extended-regexp`

Consider the limiting patterns to be extended regular expressions instead of the default basic regular expressions.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt--F)`-F`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---fixed-strings)`--fixed-strings`

Consider the limiting patterns to be fixed strings (don’t interpret pattern as a regular expression).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt--P)`-P`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---perl-regexp)`--perl-regexp`

Consider the limiting patterns to be Perl-compatible regular expressions.
Support for these types of regular expressions is an optional compile-time dependency. If Git wasn’t compiled with support for them providing this option will cause it to die.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---remove-empty)`--remove-empty`

Stop when a given path disappears from the tree.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---merges)`--merges`

Print only merge commits. This is exactly the same as `--min-parents=2`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-merges)`--no-merges`

Do not print commits with more than one parent. This is exactly the same as `--max-parents=1`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---min-parentsnumber)`--min-parents=`_< number>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---max-parentsnumber)`--max-parents=`_< number>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-min-parents)`--no-min-parents`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-max-parents)`--no-max-parents`

Show only commits which have at least (or at most) that many parent commits. In particular, `--max-parents=1` is the same as `--no-merges`, `--min-parents=2` is the same as `--merges`. `--max-parents=0` gives all root commits and `--min-parents=3` all octopus merges.
`--no-min-parents` and `--no-max-parents` reset these limits (to no limit) again. Equivalent forms are `--min-parents=0` (any commit has 0 or more parents) and `--max-parents=-1` (negative numbers denote no upper limit).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---first-parent)`--first-parent`

When finding commits to include, follow only the first parent commit upon seeing a merge commit. This option can give a better overview when viewing the evolution of a particular topic branch, because merges into a topic branch tend to be only about adjusting to updated upstream from time to time, and this option allows you to ignore the individual commits brought in to your history by such a merge.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---exclude-first-parent-only)`--exclude-first-parent-only`

When finding commits to exclude (with a _^_), follow only the first parent commit upon seeing a merge commit. This can be used to find the set of changes in a topic branch from the point where it diverged from the remote branch, given that arbitrary merges can be valid topic branch changes.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---not)`--not`

Reverses the meaning of the _^_ prefix (or lack thereof) for all following revision specifiers, up to the next `--not`. When used on the command line before --stdin, the revisions passed through stdin will not be affected by it. Conversely, when passed via standard input, the revisions passed on the command line will not be affected by it.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---all)`--all`

Pretend as if all the refs in `refs/`, along with `HEAD`, are listed on the command line as _< commit>_.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---branchespattern)`--branches`[`=`_< pattern>_]

Pretend as if all the refs in `refs/heads` are listed on the command line as _< commit>_. If _< pattern>_ is given, limit branches to ones matching given shell glob. If _< pattern>_ lacks _?_ , _*_ , or _[_ , _/*_ at the end is implied.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---tagspattern)`--tags`[`=`_< pattern>_]

Pretend as if all the refs in `refs/tags` are listed on the command line as _< commit>_. If _< pattern>_ is given, limit tags to ones matching given shell glob. If pattern lacks _?_ , _*_ , or _[_ , _/*_ at the end is implied.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---remotespattern)`--remotes`[`=`_< pattern>_]

Pretend as if all the refs in `refs/remotes` are listed on the command line as _< commit>_. If _< pattern>_ is given, limit remote-tracking branches to ones matching given shell glob. If pattern lacks _?_ , _*_ , or _[_ , _/*_ at the end is implied.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---globglob-pattern)`--glob=`_< glob-pattern>_

Pretend as if all the refs matching shell glob _< glob-pattern>_ are listed on the command line as _< commit>_. Leading _refs/_ , is automatically prepended if missing. If pattern lacks _?_ , _*_ , or _[_ , _/*_ at the end is implied.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---excludeglob-pattern)`--exclude=`_< glob-pattern>_

Do not include refs matching _< glob-pattern>_ that the next `--all`, `--branches`, `--tags`, `--remotes`, or `--glob` would otherwise consider. Repetitions of this option accumulate exclusion patterns up to the next `--all`, `--branches`, `--tags`, `--remotes`, or `--glob` option (other options or arguments do not clear accumulated patterns).
The patterns given should not begin with `refs/heads`, `refs/tags`, or `refs/remotes` when applied to `--branches`, `--tags`, or `--remotes`, respectively, and they must begin with `refs/` when applied to `--glob` or `--all`. If a trailing _/*_ is intended, it must be given explicitly.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---exclude-hiddenfetchreceiveuploadpack)`--exclude-hidden=`(`fetch`|`receive`|`uploadpack`)

Do not include refs that would be hidden by `git-fetch`, `git-receive-pack` or `git-upload-pack` by consulting the appropriate `fetch.hideRefs`, `receive.hideRefs` or `uploadpack.hideRefs` configuration along with `transfer.hideRefs` (see [git-config[1]](https://git-scm.com/docs/git-config)). This option affects the next pseudo-ref option `--all` or `--glob` and is cleared after processing them.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---reflog)`--reflog`

Pretend as if all objects mentioned by reflogs are listed on the command line as _< commit>_.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---alternate-refs)`--alternate-refs`

Pretend as if all objects mentioned as ref tips of alternate repositories were listed on the command line. An alternate repository is any repository whose object directory is specified in `objects/info/alternates`. The set of included objects may be modified by `core.alternateRefsCommand`, etc. See [git-config[1]](https://git-scm.com/docs/git-config).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---single-worktree)`--single-worktree`

By default, all working trees will be examined by the following options when there are more than one (see [git-worktree[1]](https://git-scm.com/docs/git-worktree)): `--all`, `--reflog` and `--indexed-objects`. This option forces them to examine the current working tree only.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---ignore-missing)`--ignore-missing`

Upon seeing an invalid object name in the input, pretend as if the bad input was not given.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---stdin)`--stdin`

In addition to getting arguments from the command line, read them from standard input as well. This accepts commits and pseudo-options like `--all` and `--glob=`. When a `--` separator is seen, the following input is treated as paths and used to limit the result. Flags like `--not` which are read via standard input are only respected for arguments passed in the same way and will not influence any subsequent command line arguments.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---quiet)`--quiet`

Don’t print anything to standard output. This form is primarily meant to allow the caller to test the exit status to see if a range of objects is fully connected (or not). It is faster than redirecting stdout to `/dev/null` as the output does not have to be formatted.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---disk-usage)`--disk-usage`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---disk-usagehuman)`--disk-usage=human`

Suppress normal output; instead, print the sum of the bytes used for on-disk storage by the selected commits or objects. This is equivalent to piping the output into `git` `cat-file` `--batch-check='%`(`objectsize:disk`), except that it runs much faster (especially with `--use-bitmap-index`). See the `CAVEATS` section in [git-cat-file[1]](https://git-scm.com/docs/git-cat-file) for the limitations of what "on-disk storage" means. With the optional value `human`, on-disk storage size is shown in human-readable string(e.g. 12.24 Kib, 3.50 Mib).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---cherry-mark)`--cherry-mark`

Like `--cherry-pick` (see below) but mark equivalent commits with `=` rather than omitting them, and inequivalent ones with `+`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---cherry-pick)`--cherry-pick`

Omit any commit that introduces the same change as another commit on the “other side” when the set of commits are limited with symmetric difference.
For example, if you have two branches, `A` and `B`, a usual way to list all commits on only one side of them is with `--left-right` (see the example below in the description of the `--left-right` option). However, it shows the commits that were cherry-picked from the other branch (for example, “3rd on b” may be cherry-picked from branch A). With this option, such pairs of commits are excluded from the output.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---left-only)`--left-only`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---right-only)`--right-only`

List only commits on the respective side of a symmetric difference, i.e. only those which would be marked _<_ resp. _>_ by `--left-right`.
For example, `--cherry-pick` `--right-only` `A...B` omits those commits from `B` which are in `A` or are patch-equivalent to a commit in `A`. In other words, this lists the `+` commits from `git` `cherry` `A` `B`. More precisely, `--cherry-pick` `--right-only` `--no-merges` gives the exact list.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---cherry)`--cherry`

A synonym for `--right-only` `--cherry-mark` `--no-merges`; useful to limit the output to the commits on our side and mark those that have been applied to the other side of a forked history with `git` `log` `--cherry` `upstream...mybranch`, similar to `git` `cherry` `upstream` `mybranch`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt--g)`-g`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---walk-reflogs)`--walk-reflogs`

Instead of walking the commit ancestry chain, walk reflog entries from the most recent one to older ones. When this option is used you cannot specify commits to exclude (that is, `^`_< commit>_, _< commit1>_`..`_< commit2>_, and _< commit1>_`...`_< commit2>_ notations cannot be used).
With `--pretty` format other than `oneline` and `reference` (for obvious reasons), this causes the output to have two extra lines of information taken from the reflog. The reflog designator in the output may be shown as `ref@{`_< Nth>_`}` (where _< Nth>_ is the reverse-chronological index in the reflog) or as `ref@{`_< timestamp>_`}` (with the _< timestamp>_ for that entry), depending on a few rules:
  1. If the starting point is specified as `ref@{`_< Nth>_`}`, show the index format.
  2. If the starting point was specified as `ref@{now}`, show the timestamp format.
  3. If neither was used, but `--date` was given on the command line, show the timestamp in the format requested by `--date`.
  4. Otherwise, show the index format.


Under `--pretty=oneline`, the commit message is prefixed with this information on the same line. This option cannot be combined with `--reverse`. See also [git-reflog[1]](https://git-scm.com/docs/git-reflog).
Under `--pretty=reference`, this information will not be shown at all.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---merge)`--merge`

Show commits touching conflicted paths in the range `HEAD...`_< other>_, where _< other>_ is the first existing pseudoref in `MERGE_HEAD`, `CHERRY_PICK_HEAD`, `REVERT_HEAD` or `REBASE_HEAD`. Only works when the index has unmerged entries. This option can be used to show relevant commits when resolving conflicts from a 3-way merge.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---boundary)`--boundary`

Output excluded boundary commits. Boundary commits are prefixed with `-`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---use-bitmap-index)`--use-bitmap-index`

Try to speed up the traversal using the pack bitmap index (if one is available). Note that when traversing with `--objects`, trees and blobs will not have their associated path printed.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---progressheader)`--progress=`_< header>_

Show progress reports on stderr as objects are considered. The _< header>_ text will be printed with each progress update.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt--z)`-z`

Instead of being newline-delimited, each outputted object and its accompanying metadata is delimited using NUL bytes. Output is printed in the following form:
```
<OID> NUL [<token>=<value> NUL]...
```

Additional object metadata, such as object paths or boundary objects, is printed using the _< token>_`=`_< value>_ form. Token values are printed as-is without any encoding/truncation. An OID entry never contains a _=_ character and thus is used to signal the start of a new object record. Examples:
```
<OID> NUL
<OID> NUL path=<path> NUL
<OID> NUL boundary=yes NUL
<OID> NUL missing=yes NUL [<token>=<value> NUL]...
```

This mode is only compatible with the `--objects`, `--boundary`, and `--missing` output options.
###  [](https://git-scm.com/docs/git-rev-list#_history_simplification)History Simplification
Sometimes you are only interested in parts of the history, for example the commits modifying a particular <path>. But there are two parts of _History Simplification_ , one part is selecting the commits and the other is how to do it, as there are various strategies to simplify the history.
The following options select the commits to be shown:

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-paths)_< paths>_

Commits modifying the given <paths> are selected.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---simplify-by-decoration)`--simplify-by-decoration`

Commits that are referred by some branch or tag are selected.
Note that extra commits can be shown to give a meaningful history.
The following options affect the way the simplification is performed:

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-Defaultmode)`Default` `mode`

Simplifies the history to the simplest history explaining the final state of the tree. Simplest because it prunes some side branches if the end result is the same (i.e. merging branches with the same content)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---show-pulls)`--show-pulls`

Include all commits from the default mode, but also any merge commits that are not TREESAME to the first parent but are TREESAME to a later parent. This mode is helpful for showing the merge commits that "first introduced" a change to a branch.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---full-history)`--full-history`

Same as the default mode, but does not prune some history.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---dense)`--dense`

Only the selected commits are shown, plus some to have a meaningful history.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---sparse)`--sparse`

All commits in the simplified history are shown.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---simplify-merges)`--simplify-merges`

Additional option to `--full-history` to remove some needless merges from the resulting history, as there are no selected commits contributing to this merge.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---ancestry-pathcommit)`--ancestry-path`[`=`_< commit>_]

When given a range of commits to display (e.g. _< commit1>_`..`_< commit2>_ or _< commit2>_ `^`_< commit1>_), and a commit _< commit>_ in that range, only display commits in that range that are ancestors of _< commit>_, descendants of _< commit>_, or _< commit>_ itself. If no commit is specified, use _< commit1>_ (the excluded part of the range) as _< commit>_. Can be passed multiple times; if so, a commit is included if it is any of the commits given or if it is an ancestor or descendant of one of them.
A more detailed explanation follows.
Suppose you specified `foo` as the _< paths>_. We shall call commits that modify `foo` !TREESAME, and the rest TREESAME. (In a diff filtered for `foo`, they look different and equal, respectively.)
In the following, we will always refer to the same example history to illustrate the differences between simplification settings. We assume that you are filtering for a file `foo` in this commit graph:
```
	  .-A---M---N---O---P---Q
	 /     /   /   /   /   /
	I     B   C   D   E   Y
	 \   /   /   /   /   /
	  `-------------'   X
```

The horizontal line of history A---Q is taken to be the first parent of each merge. The commits are:
  * `I` is the initial commit, in which `foo` exists with contents `asdf`, and a file `quux` exists with contents `quux`. Initial commits are compared to an empty tree, so `I` is !TREESAME.
  * In `A`, `foo` contains just `foo`.
  * `B` contains the same change as `A`. Its merge `M` is trivial and hence TREESAME to all parents.
  * `C` does not change `foo`, but its merge `N` changes it to `foobar`, so it is not TREESAME to any parent.
  * `D` sets `foo` to `baz`. Its merge `O` combines the strings from `N` and `D` to `foobarbaz`; i.e., it is not TREESAME to any parent.
  * `E` changes `quux` to `xyzzy`, and its merge `P` combines the strings to `quux` `xyzzy`. `P` is TREESAME to `O`, but not to `E`.
  * `X` is an independent root commit that added a new file `side`, and `Y` modified it. `Y` is TREESAME to `X`. Its merge `Q` added `side` to `P`, and `Q` is TREESAME to `P`, but not to `Y`.


`rev-list` walks backwards through history, including or excluding commits based on whether `--full-history` and/or parent rewriting (via `--parents` or `--children`) are used. The following settings are available.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-Defaultmode-1)Default mode

Commits are included if they are not TREESAME to any parent (though this can be changed, see `--sparse` below). If the commit was a merge, and it was TREESAME to one parent, follow only that parent. (Even if there are several TREESAME parents, follow only one of them.) Otherwise, follow all parents.
This results in:
```
	  .-A---N---O
	 /     /   /
	I---------D
```

Note how the rule to only follow the TREESAME parent, if one is available, removed `B` from consideration entirely. `C` was considered via `N`, but is TREESAME. Root commits are compared to an empty tree, so `I` is !TREESAME.
Parent/child relations are only visible with `--parents`, but that does not affect the commits selected in default mode, so we have shown the parent lines.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---full-historywithoutparentrewriting)`--full-history` without parent rewriting

This mode differs from the default in one point: always follow all parents of a merge, even if it is TREESAME to one of them. Even if more than one side of the merge has commits that are included, this does not imply that the merge itself is! In the example, we get
```
	I  A  B  N  D  O  P  Q
```

`M` was excluded because it is TREESAME to both parents. `E`, `C` and `B` were all walked, but only `B` was !TREESAME, so the others do not appear.
Note that without parent rewriting, it is not really possible to talk about the parent/child relationships between the commits, so we show them disconnected.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---full-historywithparentrewriting)`--full-history` with parent rewriting

Ordinary commits are only included if they are !TREESAME (though this can be changed, see `--sparse` below).
Merges are always included. However, their parent list is rewritten: Along each parent, prune away commits that are not included themselves. This results in
```
	  .-A---M---N---O---P---Q
	 /     /   /   /   /
	I     B   /   D   /
	 \   /   /   /   /
	  `-------------'
```

Compare to `--full-history` without rewriting above. Note that `E` was pruned away because it is TREESAME, but the parent list of P was rewritten to contain `E`'s parent `I`. The same happened for `C` and `N`, and `X`, `Y` and `Q`.
In addition to the above settings, you can change whether TREESAME affects inclusion:

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---dense-1)`--dense`

Commits that are walked are included if they are not TREESAME to any parent.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---sparse-1)`--sparse`

All commits that are walked are included.
Note that without `--full-history`, this still simplifies merges: if one of the parents is TREESAME, we follow only that one, so the other sides of the merge are never walked.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---simplify-merges-1)`--simplify-merges`

First, build a history graph in the same way that `--full-history` with parent rewriting does (see above).
Then simplify each commit `C` to its replacement `C'` in the final history according to the following rules:
  * Set `C'` to `C`.
  * Replace each parent `P` of `C'` with its simplification `P'`. In the process, drop parents that are ancestors of other parents or that are root commits TREESAME to an empty tree, and remove duplicates, but take care to never drop all parents that we are TREESAME to.
  * If after this parent rewriting, `C'` is a root or merge commit (has zero or >1 parents), a boundary commit, or !TREESAME, it remains. Otherwise, it is replaced with its only parent.


The effect of this is best shown by way of comparing to `--full-history` with parent rewriting. The example turns into:
```
	  .-A---M---N---O
	 /     /       /
	I     B       D
	 \   /       /
	  `---------'
```

Note the major differences in `N`, `P`, and `Q` over `--full-history`:
  * `N`'s parent list had `I` removed, because it is an ancestor of the other parent `M`. Still, `N` remained because it is !TREESAME.
  * `P`'s parent list similarly had `I` removed. `P` was then removed completely, because it had one parent and is TREESAME.
  * `Q`'s parent list had `Y` simplified to `X`. `X` was then removed, because it was a TREESAME root. `Q` was then removed completely, because it had one parent and is TREESAME.


There is another simplification mode available:

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---ancestry-pathcommit-1)`--ancestry-path`[`=`_< commit>_]

Limit the displayed commits to those which are an ancestor of _< commit>_, or which are a descendant of _< commit>_, or are _< commit>_ itself.
As an example use case, consider the following commit history:
```
	    D---E-------F
	   /     \       \
	  B---C---G---H---I---J
	 /                     \
	A-------K---------------L--M
```

A regular _D..M_ computes the set of commits that are ancestors of `M`, but excludes the ones that are ancestors of `D`. This is useful to see what happened to the history leading to `M` since `D`, in the sense that "what does `M` have that did not exist in `D`". The result in this example would be all the commits, except `A` and `B` (and `D` itself, of course).
When we want to find out what commits in `M` are contaminated with the bug introduced by `D` and need fixing, however, we might want to view only the subset of `D..M` that are actually descendants of `D`, i.e. excluding `C` and `K`. This is exactly what the `--ancestry-path` option does. Applied to the `D..M` range, it results in:
```
		E-------F
		 \       \
		  G---H---I---J
			       \
				L--M
```

We can also use `--ancestry-path=D` instead of `--ancestry-path` which means the same thing when applied to the `D..M` range but is just more explicit.
If we instead are interested in a given topic within this range, and all commits affected by that topic, we may only want to view the subset of `D..M` which contain that topic in their ancestry path. So, using `--ancestry-path=H` `D..M` for example would result in:
```
		E
		 \
	      C---G---H---I---J
			       \
				L--M
```

Whereas `--ancestry-path=K` `D..M` would result in
```
		K---------------L--M
```

Before discussing another option, `--show-pulls`, we need to create a new example history.
A common problem users face when looking at simplified history is that a commit they know changed a file somehow does not appear in the file’s simplified history. Let’s demonstrate a new example and show how options such as `--full-history` and `--simplify-merges` works in that case:
```
	  .-A---M-----C--N---O---P
	 /     / \  \  \/   /   /
	I     B   \  R-'`-Z'   /
	 \   /     \/         /
	  \ /      /\        /
	   `---X--'  `---Y--'
```

For this example, suppose `I` created `file.txt` which was modified by `A`, `B`, and `X` in different ways. The single-parent commits `C`, `Z`, and `Y` do not change `file.txt`. The merge commit `M` was created by resolving the merge conflict to include both changes from `A` and `B` and hence is not TREESAME to either. The merge commit `R`, however, was created by ignoring the contents of `file.txt` at `M` and taking only the contents of `file.txt` at `X`. Hence, `R` is TREESAME to `X` but not `M`. Finally, the natural merge resolution to create `N` is to take the contents of `file.txt` at `R`, so `N` is TREESAME to `R` but not `C`. The merge commits `O` and `P` are TREESAME to their first parents, but not to their second parents, `Z` and `Y` respectively.
When using the default mode, `N` and `R` both have a TREESAME parent, so those edges are walked and the others are ignored. The resulting history graph is:
```
	I---X
```

When using `--full-history`, Git walks every edge. This will discover the commits `A` and `B` and the merge `M`, but also will reveal the merge commits `O` and `P`. With parent rewriting, the resulting graph is:
```
	  .-A---M--------N---O---P
	 /     / \  \  \/   /   /
	I     B   \  R-'`--'   /
	 \   /     \/         /
	  \ /      /\        /
	   `---X--'  `------'
```

Here, the merge commits `O` and `P` contribute extra noise, as they did not actually contribute a change to `file.txt`. They only merged a topic that was based on an older version of `file.txt`. This is a common issue in repositories using a workflow where many contributors work in parallel and merge their topic branches along a single trunk: many unrelated merges appear in the `--full-history` results.
When using the `--simplify-merges` option, the commits `O` and `P` disappear from the results. This is because the rewritten second parents of `O` and `P` are reachable from their first parents. Those edges are removed and then the commits look like single-parent commits that are TREESAME to their parent. This also happens to the commit `N`, resulting in a history view as follows:
```
	  .-A---M--.
	 /     /    \
	I     B      R
	 \   /      /
	  \ /      /
	   `---X--'
```

In this view, we see all of the important single-parent changes from `A`, `B`, and `X`. We also see the carefully-resolved merge `M` and the not-so-carefully-resolved merge `R`. This is usually enough information to determine why the commits `A` and `B` "disappeared" from history in the default view. However, there are a few issues with this approach.
The first issue is performance. Unlike any previous option, the `--simplify-merges` option requires walking the entire commit history before returning a single result. This can make the option difficult to use for very large repositories.
The second issue is one of auditing. When many contributors are working on the same repository, it is important which merge commits introduced a change into an important branch. The problematic merge `R` above is not likely to be the merge commit that was used to merge into an important branch. Instead, the merge `N` was used to merge `R` and `X` into the important branch. This commit may have information about why the change `X` came to override the changes from `A` and `B` in its commit message.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---show-pulls-1)`--show-pulls`

In addition to the commits shown in the default history, show each merge commit that is not TREESAME to its first parent but is TREESAME to a later parent.
When a merge commit is included by `--show-pulls`, the merge is treated as if it "pulled" the change from another branch. When using `--show-pulls` on this example (and no other options) the resulting graph is:
```
	I---X---R---N
```

Here, the merge commits `R` and `N` are included because they pulled the commits `X` and `R` into the base branch, respectively. These merges are the reason the commits `A` and `B` do not appear in the default history.
When `--show-pulls` is paired with `--simplify-merges`, the graph includes all of the necessary information:
```
	  .-A---M--.   N
	 /     /    \ /
	I     B      R
	 \   /      /
	  \ /      /
	   `---X--'
```

Notice that since `M` is reachable from `R`, the edge from `N` to `M` was simplified away. However, `N` still appears in the history as an important commit because it "pulled" the change `R` into the main branch.
The `--simplify-by-decoration` option allows you to view only the big picture of the topology of the history, by omitting commits that are not referenced by tags. Commits are marked as !TREESAME (in other words, kept after history simplification rules described above) if (1) they are referenced by tags, or (2) they change the contents of the paths given on the command line. All other commits are marked as TREESAME (subject to be simplified away).
###  [](https://git-scm.com/docs/git-rev-list#_bisection_helpers)Bisection Helpers

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---bisect)`--bisect`

Limit output to the one commit object which is roughly halfway between included and excluded commits. Note that the bad bisection ref `refs/bisect/bad` is added to the included commits (if it exists) and the good bisection refs `refs/bisect/good-*` are added to the excluded commits (if they exist). Thus, supposing there are no refs in `refs/bisect/`, if
```
	$ git rev-list --bisect foo ^bar ^baz
```

outputs _midpoint_ , the output of the two commands
```
	$ git rev-list foo ^midpoint
	$ git rev-list midpoint ^bar ^baz
```

would be of roughly the same length. Finding the change which introduces a regression is thus reduced to a binary search: repeatedly generate and test new 'midpoint’s until the commit chain is of length one.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---bisect-vars)`--bisect-vars`

This calculates the same as `--bisect`, except that refs in `refs/bisect/` are not used, and except that this outputs text ready to be eval’ed by the shell. These lines will assign the name of the midpoint revision to the variable `bisect_rev`, and the expected number of commits to be tested after `bisect_rev` is tested to `bisect_nr`, the expected number of commits to be tested if `bisect_rev` turns out to be good to `bisect_good`, the expected number of commits to be tested if `bisect_rev` turns out to be bad to `bisect_bad`, and the number of commits we are bisecting right now to `bisect_all`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---bisect-all)`--bisect-all`

This outputs all the commit objects between the included and excluded commits, ordered by their distance to the included and excluded commits. Refs in `refs/bisect/` are not used. The farthest from them is displayed first. (This is the only one displayed by `--bisect`.)
This is useful because it makes it easy to choose a good commit to test when you want to avoid to test some of them for some reason (they may not compile for example).
This option can be used along with `--bisect-vars`, in this case, after all the sorted commit objects, there will be the same text as if `--bisect-vars` had been used alone.
###  [](https://git-scm.com/docs/git-rev-list#_commit_ordering)Commit Ordering
By default, the commits are shown in reverse chronological order.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---date-order)`--date-order`

Show no parents before all of its children are shown, but otherwise show commits in the commit timestamp order.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---author-date-order)`--author-date-order`

Show no parents before all of its children are shown, but otherwise show commits in the author timestamp order.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---topo-order)`--topo-order`

Show no parents before all of its children are shown, and avoid showing commits on multiple lines of history intermixed.
For example, in a commit history like this:
```
    ---1----2----4----7
	\	       \
	 3----5----6----8---
```

where the numbers denote the order of commit timestamps, `git` `rev-list` and friends with `--date-order` show the commits in the timestamp order: 8 7 6 5 4 3 2 1.
With `--topo-order`, they would show 8 6 5 3 7 4 2 1 (or 8 7 4 2 6 5 3 1); some older commits are shown before newer ones in order to avoid showing the commits from two parallel development track mixed together.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---reverse)`--reverse`

Output the commits chosen to be shown (see _Commit Limiting_ section above) in reverse order. Cannot be combined with `--walk-reflogs`.
###  [](https://git-scm.com/docs/git-rev-list#_object_traversal)Object Traversal
These options are mostly targeted for packing of Git repositories.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---objects)`--objects`

Print the object IDs of any object referenced by the listed commits. `--objects` `foo` `^bar` thus means "send me all object IDs which I need to download if I have the commit object `bar` but not `foo`". See also `--object-names` below.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---in-commit-order)`--in-commit-order`

Print tree and blob ids in order of the commits. The tree and blob ids are printed after they are first referenced by a commit.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---objects-edge)`--objects-edge`

Similar to `--objects`, but also print the IDs of excluded commits prefixed with a "`-`" character. This is used by [git-pack-objects[1]](https://git-scm.com/docs/git-pack-objects) to build a “thin” pack, which records objects in deltified form based on objects contained in these excluded commits to reduce network traffic.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---objects-edge-aggressive)`--objects-edge-aggressive`

Similar to `--objects-edge`, but it tries harder to find excluded commits at the cost of increased time. This is used instead of `--objects-edge` to build “thin” packs for shallow repositories.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---indexed-objects)`--indexed-objects`

Pretend as if all trees and blobs used by the index are listed on the command line. Note that you probably want to use `--objects`, too.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---unpacked)`--unpacked`

Only useful with `--objects`; print the object IDs that are not in packs.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---object-names)`--object-names`

Only useful with `--objects`; print the names of the object IDs that are found. This is the default behavior. Note that the "name" of each object is ambiguous, and mostly intended as a hint for packing objects. In particular: no distinction is made between the names of tags, trees, and blobs; path names may be modified to remove newlines; and if an object would appear multiple times with different names, only one name is shown.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-object-names)`--no-object-names`

Only useful with `--objects`; does not print the names of the object IDs that are found. This inverts `--object-names`. This flag allows the output to be more easily parsed by commands such as [git-cat-file[1]](https://git-scm.com/docs/git-cat-file).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---filterfilter-spec)`--filter=`_< filter-spec>_

Only useful with one of the `--objects*`; omits objects (usually blobs) from the list of printed objects. The _< filter-spec>_ may be one of the following:
The form `--filter=blob:none` omits all blobs.
The form `--filter=blob:limit=`_< n>_[`kmg`] omits blobs of size at least _< n>_ bytes or units. _< n>_ may be zero. The suffixes `k`, `m`, and `g` can be used to name units in KiB, MiB, or GiB. For example, `blob:limit=1k` is the same as _blob:limit=1024_.
The form `--filter=object:type=`(`tag`|`commit`|`tree`|`blob`) omits all objects which are not of the requested type. Note that explicitly provided objects ignore filters and are always printed unless `--filter-provided-objects` is also specified.
The form `--filter=sparse:oid=`_< blob-ish>_ uses a sparse-checkout specification contained in the blob (or blob-expression) _< blob-ish>_ to omit blobs that would not be required for a sparse checkout on the requested refs.
The form `--filter=tree:`_< depth>_ omits all blobs and trees whose depth from the root tree is >= _< depth>_ (minimum depth if an object is located at multiple depths in the commits traversed). _< depth>_=0 will not include any trees or blobs unless included explicitly in the command-line (or standard input when `--stdin` is used). _< depth>_=1 will include only the tree and blobs which are referenced directly by a commit reachable from _< commit>_ or an explicitly-given object. _< depth>_=2 is like <depth>=1 while also including trees and blobs one more level removed from an explicitly-given commit or tree.
Note that the form `--filter=sparse:path=`_< path>_ that wants to read from an arbitrary path on the filesystem has been dropped for security reasons.
Multiple `--filter=` flags can be specified to combine filters. Only objects which are accepted by every filter are included.
The form `--filter=combine:`_< filter1>_`+`_< filter2>_`+...`_< filterN>_ can also be used to combined several filters, but this is harder than just repeating the `--filter` flag and is usually not necessary. Filters are joined by _+_ and individual filters are %-encoded (i.e. URL-encoded). Besides the _+_ and _%_ characters, the following characters are reserved and also must be encoded: _~!@#$^ &*()[]{}\;",<>?__'`_ as well as all characters with ASCII code <= `0x20`, which includes space and newline.
Other arbitrary characters can also be encoded. For instance, `combine:tree:3+blob:none` and `combine:tree%3A3+blob%3Anone` are equivalent.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-filter)`--no-filter`

Turn off any previous `--filter=` argument.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---filter-provided-objects)`--filter-provided-objects`

Filter the list of explicitly provided objects, which would otherwise always be printed even if they did not match any of the filters. Only useful with `--filter=`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---filter-print-omitted)`--filter-print-omitted`

Only useful with `--filter=`; prints a list of the objects omitted by the filter. Object IDs are prefixed with a “~” character.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---missingmissing-action)`--missing=`_< missing-action>_

A debug option to help with future "partial clone" development. This option specifies how missing objects are handled.
The form `--missing=error` requests that rev-list stop with an error if a missing object is encountered. This is the default action.
The form `--missing=allow-any` will allow object traversal to continue if a missing object is encountered. Missing objects will silently be omitted from the results.
The form `--missing=allow-promisor` is like `allow-any`, but will only allow object traversal to continue for EXPECTED promisor missing objects. Unexpected missing objects will raise an error.
The form `--missing=print` is like `allow-any`, but will also print a list of the missing objects. Object IDs are prefixed with a “?” character.
The form `--missing=print-info` is like `print`, but will also print additional information about the missing object inferred from its containing object. The information is all printed on the same line with the missing object ID in the form: _? <oid> [<token>=<value>]..._. The _< token>_`=`_< value>_ pairs containing additional information are separated from each other by a _SP_. The value is encoded in a token specific fashion, but _SP_ or _LF_ contained in value are always expected to be represented in such a way that the resulting encoded value does not have either of these two problematic bytes. Each _< token>_`=`_< value>_ may be one of the following:
  * The `path=`_< path>_ shows the path of the missing object inferred from a containing object. A path containing _SP_ or special characters is enclosed in double-quotes in the C style as needed.
  * The `type=`_< type>_ shows the type of the missing object inferred from a containing object.


If some tips passed to the traversal are missing, they will be considered as missing too, and the traversal will ignore them. In case we cannot get their Object ID though, an error will be raised.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---exclude-promisor-objects)`--exclude-promisor-objects`

(For internal use only.) Prefilter object traversal at promisor boundary. This is used with partial clone. This is stronger than `--missing=allow-promisor` because it limits the traversal, rather than just silencing errors about missing objects.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-walksortedunsorted)`--no-walk`[`=`(`sorted`|`unsorted`)]

Only show the given commits, but do not traverse their ancestors. This has no effect if a range is specified. If the argument `unsorted` is given, the commits are shown in the order they were given on the command line. Otherwise (if `sorted` or no argument was given), the commits are shown in reverse chronological order by commit time. Cannot be combined with `--graph`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---do-walk)`--do-walk`

Overrides a previous `--no-walk`.
###  [](https://git-scm.com/docs/git-rev-list#_commit_formatting)Commit Formatting
Using these options, [git-rev-list[1]](https://git-scm.com/docs/git-rev-list) will act similar to the more specialized family of commit log tools: [git-log[1]](https://git-scm.com/docs/git-log), [git-show[1]](https://git-scm.com/docs/git-show), and [git-whatchanged[1]](https://git-scm.com/docs/git-whatchanged).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---prettyformat)`--pretty`[`=`_< format>_]


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---formatformat)`--format=`_< format>_

Pretty-print the contents of the commit logs in a given format, where _< format>_ can be one of `oneline`, `short`, `medium`, `full`, `fuller`, `reference`, `email`, `raw`, `format:`_< string>_ and `tformat:`_< string>_. When _< format>_ is none of the above, and has `%`_< placeholder>_ in it, it acts as if `--pretty=tformat:`_< format>_ were given.
See the "PRETTY FORMATS" section for some additional details for each format. When `=`_< format>_ part is omitted, it defaults to `medium`.
Note |  you can specify the default pretty format in the repository configuration (see [git-config[1]](https://git-scm.com/docs/git-config)).
---|---

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---abbrev-commit)`--abbrev-commit`

Instead of showing the full 40-byte hexadecimal commit object name, show a prefix that names the object uniquely. `--abbrev=`_< n>_ (which also modifies diff output, if it is displayed) option can be used to specify the minimum length of the prefix.
This should make `--pretty=oneline` a whole lot more readable for people using 80-column terminals.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-abbrev-commit)`--no-abbrev-commit`

Show the full 40-byte hexadecimal commit object name. This negates `--abbrev-commit`, either explicit or implied by other options such as `--oneline`. It also overrides the `log.abbrevCommit` variable.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---oneline)`--oneline`

This is a shorthand for `--pretty=oneline` `--abbrev-commit` used together.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---encodingencoding)`--encoding=`_< encoding>_

Commit objects record the character encoding used for the log message in their encoding header; this option can be used to tell the command to re-code the commit log message in the encoding preferred by the user. For non plumbing commands this defaults to UTF-8. Note that if an object claims to be encoded in `X` and we are outputting in `X`, we will output the object verbatim; this means that invalid sequences in the original commit may be copied to the output. Likewise, if iconv(3) fails to convert the commit, we will quietly output the original object verbatim.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---expand-tabsn)`--expand-tabs=`_< n>_


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---expand-tabs)`--expand-tabs`


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-expand-tabs)`--no-expand-tabs`

Perform a tab expansion (replace each tab with enough spaces to fill to the next display column that is a multiple of _< n>_) in the log message before showing it in the output. `--expand-tabs` is a short-hand for `--expand-tabs=8`, and `--no-expand-tabs` is a short-hand for `--expand-tabs=0`, which disables tab expansion.
By default, tabs are expanded in pretty formats that indent the log message by 4 spaces (i.e. `medium`, which is the default, `full`, and `fuller`).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---show-signature)`--show-signature`

Check the validity of a signed commit object by passing the signature to `gpg` `--verify` and show the output.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---relative-date)`--relative-date`

Synonym for `--date=relative`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---dateformat)`--date=`_< format>_

Only takes effect for dates shown in human-readable format, such as when using `--pretty`. `log.date` config variable sets a default value for the log command’s `--date` option. By default, dates are shown in the original time zone (either committer’s or author’s). If `-local` is appended to the format (e.g., `iso-local`), the user’s local time zone is used instead.
`--date=relative` shows dates relative to the current time, e.g. “2 hours ago”. The `-local` option has no effect for `--date=relative`.
`--date=local` is an alias for `--date=default-local`.
`--date=iso` (or `--date=iso8601`) shows timestamps in a ISO 8601-like format. The differences to the strict ISO 8601 format are:
  * a space instead of the `T` date/time delimiter
  * a space between time and time zone
  * no colon between hours and minutes of the time zone


`--date=iso-strict` (or `--date=iso8601-strict`) shows timestamps in strict ISO 8601 format.
`--date=rfc` (or `--date=rfc2822`) shows timestamps in RFC 2822 format, often found in email messages.
`--date=short` shows only the date, but not the time, in `YYYY-MM-DD` format.
`--date=raw` shows the date as seconds since the epoch (1970-01-01 00:00:00 UTC), followed by a space, and then the timezone as an offset from UTC (a `+` or `-` with four digits; the first two are hours, and the second two are minutes). I.e., as if the timestamp were formatted with `strftime`(`"%s` `%z"`)). Note that the `-local` option does not affect the seconds-since-epoch value (which is always measured in UTC), but does switch the accompanying timezone value.
`--date=human` shows the timezone if the timezone does not match the current time-zone, and doesn’t print the whole date if that matches (ie skip printing year for dates that are "this year", but also skip the whole date itself if it’s in the last few days and we can just say what weekday it was). For older dates the hour and minute is also omitted.
`--date=unix` shows the date as a Unix epoch timestamp (seconds since 1970). As with `--raw`, this is always in UTC and therefore `-local` has no effect.
`--date=format:`_< format>_ feeds the _< format>_ to your system `strftime`, except for `%s`, `%z`, and `%Z`, which are handled internally. Use `--date=format:%c` to show the date in your system locale’s preferred format. See the `strftime`(3) manual for a complete list of format placeholders. When using `-local`, the correct syntax is `--date=format-local:`_< format>_.
`--date=default` is the default format, and is based on ctime(3) output. It shows a single line with three-letter day of the week, three-letter month, day-of-month, hour-minute-seconds in "HH:MM:SS" format, followed by 4-digit year, plus timezone information, unless the local time zone is used, e.g. `Thu` `Jan` `1` `00:00:00` `1970` `+0000`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---header)`--header`

Print the contents of the commit in raw-format; each record is separated with a NUL character.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---no-commit-header)`--no-commit-header`

Suppress the header line containing "commit" and the object ID printed before the specified format. This has no effect on the built-in formats; only custom formats are affected.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---commit-header)`--commit-header`

Overrides a previous `--no-commit-header`.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---parents)`--parents`

Print also the parents of the commit (in the form "commit parent…​"). Also enables parent rewriting, see _History Simplification_ above.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---children)`--children`

Print also the children of the commit (in the form "commit child…​"). Also enables parent rewriting, see _History Simplification_ above.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---timestamp)`--timestamp`

Print the raw commit timestamp.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---left-right)`--left-right`

Mark which side of a symmetric difference a commit is reachable from. Commits from the left side are prefixed with _<_ and those from the right with _>_. If combined with `--boundary`, those commits are prefixed with `-`.
For example, if you have this topology:
```
	     y---b---b  branch B
	    / \ /
	   /   .
	  /   / \
	 o---x---a---a  branch A
```

you would get an output like this:
```
	$ git rev-list --left-right --boundary --pretty=oneline A...B

	>bbbbbbb... 3rd on b
	>bbbbbbb... 2nd on b
	<aaaaaaa... 3rd on a
	<aaaaaaa... 2nd on a
	-yyyyyyy... 1st on b
	-xxxxxxx... 1st on a
```


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---graph)`--graph`

Draw a text-based graphical representation of the commit history on the left hand side of the output. This may cause extra lines to be printed in between commits, in order for the graph history to be drawn properly. Cannot be combined with `--no-walk`.
This enables parent rewriting, see _History Simplification_ above.
This implies the `--topo-order` option by default, but the `--date-order` option may also be specified.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---show-linear-breakbarrier)`--show-linear-break`[`=`_< barrier>_]

When `--graph` is not used, all history branches are flattened which can make it hard to see that the two consecutive commits do not belong to a linear branch. This option puts a barrier in between them in that case. If _< barrier>_ is specified, it is the string that will be shown instead of the default one.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt---count)`--count`

Print a number stating how many commits would have been listed, and suppress all other output. When used together with `--left-right`, instead print the counts for left and right commits, separated by a tab. When used together with `--cherry-mark`, omit patch equivalent commits from these counts and print the count for equivalent commits separated by a tab.
##  [](https://git-scm.com/docs/git-rev-list#_pretty_formats)PRETTY FORMATS
If the commit is a merge, and if the pretty-format is not `oneline`, `email` or `raw`, an additional line is inserted before the `Author:` line. This line begins with "Merge: " and the hashes of ancestral commits are printed, separated by spaces. Note that the listed commits may not necessarily be the list of the _direct_ parent commits if you have limited your view of history: for example, if you are only interested in changes related to a certain directory or file.
There are several built-in formats, and you can define additional formats by setting a pretty.<name> config option to either another format name, or a `format:` string, as described below (see [git-config[1]](https://git-scm.com/docs/git-config)). Here are the details of the built-in formats:
  * `oneline`
```
<hash> <title-line>
```

This is designed to be as compact as possible.
  * `short`
```
commit <hash>
Author: <author>
```

```
<title-line>
```

  * `medium`
```
commit <hash>
Author: <author>
Date:   <author-date>
```

```
<title-line>
```

```
<full-commit-message>
```

  * `full`
```
commit <hash>
Author: <author>
Commit: <committer>
```

```
<title-line>
```

```
<full-commit-message>
```

  * `fuller`
```
commit <hash>
Author:     <author>
AuthorDate: <author-date>
Commit:     <committer>
CommitDate: <committer-date>
```

```
<title-line>
```

```
<full-commit-message>
```

  * `reference`
```
<abbrev-hash> (<title-line>, <short-author-date>)
```

This format is used to refer to another commit in a commit message and is the same as `--pretty='format:%C`(`auto`)`%h` (`%s,` `%ad`). By default, the date is formatted with `--date=short` unless another `--date` option is explicitly specified. As with any `format:` with format placeholders, its output is not affected by other options like `--decorate` and `--walk-reflogs`.
  * `email`
```
From <hash> <date>
From: <author>
Date: <author-date>
Subject: [PATCH] <title-line>
```

```
<full-commit-message>
```

  * `mboxrd`
Like `email`, but lines in the commit message starting with "From " (preceded by zero or more ">") are quoted with ">" so they aren’t confused as starting a new commit.
  * `raw`
The `raw` format shows the entire commit exactly as stored in the commit object. Notably, the hashes are displayed in full, regardless of whether `--abbrev` or `--no-abbrev` are used, and _parents_ information show the true parent commits, without taking grafts or history simplification into account. Note that this format affects the way commits are displayed, but not the way the diff is shown e.g. with `git` `log` `--raw`. To get full object names in a raw diff format, use `--no-abbrev`.
  * `format:`_< format-string>_
The `format:`_< format-string>_ format allows you to specify which information you want to show. It works a little bit like printf format, with the notable exception that you get a newline with `%n` instead of _\n_.
E.g, _format:"The author of %h was %an, %ar%nThe title was >>%s<<%n"_ would show something like this:
```
The author of fe6e0ee was Junio C Hamano, 23 hours ago
The title was >>t4119: test autocomputing -p<n> for traditional diff input.<<
```

The placeholders are:
    * Placeholders that expand to a single literal character:

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-n)`%n`

newline

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-)`%%`

a raw `%`

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-x00)`%x00`

`%x` followed by two hexadecimal digits is replaced with a byte with the hexadecimal digits' value (we will call this "literal formatting code" in the rest of this document).
    * Placeholders that affect formatting of later placeholders:

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-Cred)`%Cred`

switch color to red

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-Cgreen)`%Cgreen`

switch color to green

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-Cblue)`%Cblue`

switch color to blue

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-Creset)`%Creset`

reset color

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-Cspec)`%C`(_< spec>_)

color specification, as described under Values in the "CONFIGURATION FILE" section of [git-config[1]](https://git-scm.com/docs/git-config). By default, colors are shown only when enabled for log output (by `color.diff`, `color.ui`, or `--color`, and respecting the `auto` settings of the former if we are going to a terminal). `%C`(`auto,`_< spec>_) is accepted as a historical synonym for the default (e.g., `%C`(`auto,red`)). Specifying `%C`(`always,`_< spec>_) will show the colors even when color is not otherwise enabled (though consider just using `--color=always` to enable color for the whole output, including this format and anything else git might color). `auto` alone (i.e. `%C`(`auto`)) will turn on auto coloring on the next placeholders until the color is switched again.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-m)`%m`

left (_<_), right (_>_) or boundary (`-`) mark

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-wwi1i2)`%w`([_< w>_[`,`_< i1>_[`,`_< i2>_]]])

switch line wrapping, like the `-w` option of [git-shortlog[1]](https://git-scm.com/docs/git-shortlog).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ntruncltruncmtrunc)_% <(__< n>_[`,`(`trunc`|`ltrunc`|`mtrunc`)])

make the next placeholder take at least N column widths, padding spaces on the right if necessary. Optionally truncate (with ellipsis `..`) at the left (ltrunc) `..ft`, the middle (mtrunc) `mi..le`, or the end (trunc) `rig..`, if the output is longer than _< n>_ columns. Note 1: that truncating only works correctly with _< n>_ >= 2. Note 2: spaces around the _< n>_ and _< m>_ (see below) values are optional. Note 3: Emojis and other wide characters will take two display columns, which may over-run column boundaries. Note 4: decomposed character combining marks may be misplaced at padding boundaries.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-m-1)_% <|(__< m>_ )

make the next placeholder take at least until _< m>_ th display column, padding spaces on the right if necessary. Use negative _< m>_ values for column positions measured from the right hand edge of the terminal window.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-n-1)_% >(__< n>_)


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-m-1-1)_% >|(__< m>_)

similar to _% <(__< n>_), _% <|(__< m>_) respectively, but padding spaces on the left

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-n-1-1)_% >>(__< n>_)


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-m-1-1-1)_% >>|(__< m>_)

similar to _% >(__< n>_), _% >|(__< m>_) respectively, except that if the next placeholder takes more spaces than given and there are spaces on its left, use those spaces

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-n-1-1-1)_% ><(__< n>_)


[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-m-1-1-1-1)_% ><|(__< m>_)

similar to _% <(__< n>_), _% <|(__< m>_) respectively, but padding both sides (i.e. the text is centered)
    * Placeholders that expand to information extracted from the commit:

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-H)`%H`

commit hash

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-h)`%h`

abbreviated commit hash

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-T)`%T`

tree hash

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-t)`%t`

abbreviated tree hash

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-P)`%P`

parent hashes

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-p)`%p`

abbreviated parent hashes

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-an)`%an`

author name

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-aN)`%aN`

author name (respecting .mailmap, see [git-shortlog[1]](https://git-scm.com/docs/git-shortlog) or [git-blame[1]](https://git-scm.com/docs/git-blame))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ae)`%ae`

author email

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-aE)`%aE`

author email (respecting .mailmap, see [git-shortlog[1]](https://git-scm.com/docs/git-shortlog) or [git-blame[1]](https://git-scm.com/docs/git-blame))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-al)`%al`

author email local-part (the part before the `@` sign)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-aL)`%aL`

author local-part (see `%al`) respecting .mailmap, see [git-shortlog[1]](https://git-scm.com/docs/git-shortlog) or [git-blame[1]](https://git-scm.com/docs/git-blame))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ad)`%ad`

author date (format respects --date= option)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-aD)`%aD`

author date, RFC2822 style

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ar)`%ar`

author date, relative

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-at)`%at`

author date, UNIX timestamp

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ai)`%ai`

author date, ISO 8601-like format

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-aI)`%aI`

author date, strict ISO 8601 format

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-as)`%as`

author date, short format (`YYYY-MM-DD`)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ah)`%ah`

author date, human style (like the `--date=human` option of [git-rev-list[1]](https://git-scm.com/docs/git-rev-list))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cn)`%cn`

committer name

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cN)`%cN`

committer name (respecting .mailmap, see [git-shortlog[1]](https://git-scm.com/docs/git-shortlog) or [git-blame[1]](https://git-scm.com/docs/git-blame))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ce)`%ce`

committer email

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cE)`%cE`

committer email (respecting .mailmap, see [git-shortlog[1]](https://git-scm.com/docs/git-shortlog) or [git-blame[1]](https://git-scm.com/docs/git-blame))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cl)`%cl`

committer email local-part (the part before the `@` sign)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cL)`%cL`

committer local-part (see `%cl`) respecting .mailmap, see [git-shortlog[1]](https://git-scm.com/docs/git-shortlog) or [git-blame[1]](https://git-scm.com/docs/git-blame))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cd)`%cd`

committer date (format respects --date= option)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cD)`%cD`

committer date, RFC2822 style

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cr)`%cr`

committer date, relative

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ct)`%ct`

committer date, UNIX timestamp

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ci)`%ci`

committer date, ISO 8601-like format

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cI)`%cI`

committer date, strict ISO 8601 format

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-cs)`%cs`

committer date, short format (`YYYY-MM-DD`)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ch)`%ch`

committer date, human style (like the `--date=human` option of [git-rev-list[1]](https://git-scm.com/docs/git-rev-list))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-d)`%d`

ref names, like the --decorate option of [git-log[1]](https://git-scm.com/docs/git-log)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-D)`%D`

ref names without the " (", ")" wrapping.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-decorateoption)`%`(`decorate`[`:`_< option>_`,...`])

ref names with custom decorations. The `decorate` string may be followed by a colon and zero or more comma-separated options. Option values may contain literal formatting codes. These must be used for commas (`%x2C`) and closing parentheses (`%x29`), due to their role in the option syntax.
      * `prefix=`_< value>_: Shown before the list of ref names. Defaults to " (".
      * `suffix=`_< value>_: Shown after the list of ref names. Defaults to ")".
      * `separator=`_< value>_: Shown between ref names. Defaults to "`,` ".
      * `pointer=`_< value>_: Shown between HEAD and the branch it points to, if any. Defaults to "  _→_ ".
      * `tag=`_< value>_: Shown before tag names. Defaults to "`tag:` ".
For example, to produce decorations with no wrapping or tag annotations, and spaces as separators:
`%`(`decorate:prefix=,suffix=,tag=,separator=` )

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-describeoption)`%`(`describe`[`:`_< option>_`,...`])

human-readable name, like [git-describe[1]](https://git-scm.com/docs/git-describe); empty string for undescribable commits. The `describe` string may be followed by a colon and zero or more comma-separated options. Descriptions can be inconsistent when tags are added or removed at the same time.
    * `tags`[`=`_< bool-value>_]: Instead of only considering annotated tags, consider lightweight tags as well.
    * `abbrev=`_< number>_: Instead of using the default number of hexadecimal digits (which will vary according to the number of objects in the repository with a default of 7) of the abbreviated object name, use <number> digits, or as many digits as needed to form a unique object name.
    * `match=`_< pattern>_: Only consider tags matching the given `glob`(`7`) _< pattern>_, excluding the `refs/tags/` prefix.
    * `exclude=`_< pattern>_: Do not consider tags matching the given `glob`(`7`) _< pattern>_, excluding the `refs/tags/` prefix.

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-S)`%S`

ref name given on the command line by which the commit was reached (like `git` `log` `--source`), only works with `git` `log`

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-e)`%e`

encoding

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-s)`%s`

subject

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-f)`%f`

sanitized subject line, suitable for a filename

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-b)`%b`

body

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-B)`%B`

raw body (unwrapped subject and body)

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-GG)`%GG`

raw verification message from GPG for a signed commit

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-G)_%G?_

show "G" for a good (valid) signature, "B" for a bad signature, "U" for a good signature with unknown validity, "X" for a good signature that has expired, "Y" for a good signature made by an expired key, "R" for a good signature made by a revoked key, "E" if the signature cannot be checked (e.g. missing key) and "N" for no signature

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-GS)`%GS`

show the name of the signer for a signed commit

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-GK)`%GK`

show the key used to sign a signed commit

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-GF)`%GF`

show the fingerprint of the key used to sign a signed commit

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-GP)`%GP`

show the fingerprint of the primary key whose subkey was used to sign a signed commit

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-GT)`%GT`

show the trust level for the key used to sign a signed commit

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-gD)`%gD`

reflog selector, e.g., `refs/stash@{1}` or `refs/stash@{2` `minutes` `ago}`; the format follows the rules described for the `-g` option. The portion before the `@` is the refname as given on the command line (so `git` `log` `-g` `refs/heads/master` would yield `refs/heads/master@{0}`).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-gd)`%gd`

shortened reflog selector; same as `%gD`, but the refname portion is shortened for human readability (so `refs/heads/master` becomes just `master`).

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-gn)`%gn`

reflog identity name

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-gN)`%gN`

reflog identity name (respecting .mailmap, see [git-shortlog[1]](https://git-scm.com/docs/git-shortlog) or [git-blame[1]](https://git-scm.com/docs/git-blame))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-ge)`%ge`

reflog identity email

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-gE)`%gE`

reflog identity email (respecting .mailmap, see [git-shortlog[1]](https://git-scm.com/docs/git-shortlog) or [git-blame[1]](https://git-scm.com/docs/git-blame))

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-gs)`%gs`

reflog subject

[](https://git-scm.com/docs/git-rev-list#Documentation/git-rev-list.txt-trailersoption)`%`(`trailers`[`:`_< option>_`,...`])

display the trailers of the body as interpreted by [git-interpret-trailers[1]](https://git-scm.com/docs/git-interpret-trailers). The `trailers` string may be followed by a colon and zero or more comma-separated options. If any option is provided multiple times, the last occurrence wins.
    * `key=`_< key>_: only show trailers with specified <key>. Matching is done case-insensitively and trailing colon is optional. If option is given multiple times trailer lines matching any of the keys are shown. This option automatically enables the `only` option so that non-trailer lines in the trailer block are hidden. If that is not desired it can be disabled with `only=false`. E.g., `%`(`trailers:key=Reviewed-by`) shows trailer lines with key `Reviewed-by`.
    * `only`[`=`_< bool>_]: select whether non-trailer lines from the trailer block should be included.
    * `separator=`_< sep>_: specify the separator inserted between trailer lines. Defaults to a line feed character. The string <sep> may contain the literal formatting codes described above. To use comma as separator one must use `%x2C` as it would otherwise be parsed as next option. E.g., `%`(`trailers:key=Ticket,separator=%x2C` ) shows all trailer lines whose key is "Ticket" separated by a comma and a space.
    * `unfold`[`=`_< bool>_]: make it behave as if interpret-trailer’s `--unfold` option was given. E.g., `%`(`trailers:only,unfold=true`) unfolds and shows all trailer lines.
    * `keyonly`[`=`_< bool>_]: only show the key part of the trailer.
    * `valueonly`[`=`_< bool>_]: only show the value part of the trailer.
    * `key_value_separator=`_< sep>_: specify the separator inserted between the key and value of each trailer. Defaults to ": ". Otherwise it shares the same semantics as `separator=`_< sep>_ above.


Note |  Some placeholders may depend on other options given to the revision traversal engine. For example, the `%g*` reflog options will insert an empty string unless we are traversing reflog entries (e.g., by `git` `log` `-g`). The `%d` and `%D` placeholders will use the "short" decoration format if `--decorate` was not already provided on the command line.
---|---
The boolean options accept an optional value [`=`_< bool-value>_]. The values taken by `--type=bool` [git-config[1]](https://git-scm.com/docs/git-config), like `yes` and `off`, are all accepted. Giving a boolean option without `=`_< value>_ is equivalent to giving it with `=true`.
If you add a `+` (plus sign) after `%` of a placeholder, a line-feed is inserted immediately before the expansion if and only if the placeholder expands to a non-empty string.
If you add a `-` (minus sign) after `%` of a placeholder, all consecutive line-feeds immediately preceding the expansion are deleted if and only if the placeholder expands to an empty string.
If you add a `%` of a placeholder, a space is inserted immediately before the expansion if and only if the placeholder expands to a non-empty string.
  * `tformat:`
The `tformat:` format works exactly like `format:`, except that it provides "terminator" semantics instead of "separator" semantics. In other words, each commit has the message terminator character (usually a newline) appended, rather than a separator placed between entries. This means that the final entry of a single-line format will be properly terminated with a new line, just as the "oneline" format does. For example:
```
$ git log -2 --pretty=format:%h 4da45bef \
  | perl -pe '$_ .= " -- NO NEWLINE\n" unless /\n/'
4da45be
7134973 -- NO NEWLINE

$ git log -2 --pretty=tformat:%h 4da45bef \
  | perl -pe '$_ .= " -- NO NEWLINE\n" unless /\n/'
4da45be
7134973
```

In addition, any unrecognized string that has a `%` in it is interpreted as if it has `tformat:` in front of it. For example, these two are equivalent:
```
$ git log -2 --pretty=tformat:%h 4da45bef
$ git log -2 --pretty=%h 4da45bef
```



##  [](https://git-scm.com/docs/git-rev-list#_examples)EXAMPLES
  * Print the list of commits reachable from the current branch.
```
git rev-list HEAD
```

  * Print the list of commits on this branch, but not present in the upstream branch.
```
git rev-list @{upstream}..HEAD
```

  * Format commits with their author and commit message (see also the porcelain [git-log[1]](https://git-scm.com/docs/git-log)).
```
git rev-list --format=medium HEAD
```

  * Format commits along with their diffs (see also the porcelain [git-log[1]](https://git-scm.com/docs/git-log), which can do this in a single process).
```
git rev-list HEAD |
git diff-tree --stdin --format=medium -p
```

  * Print the list of commits on the current branch that touched any file in the `Documentation` directory.
```
git rev-list HEAD -- Documentation/
```

  * Print the list of commits authored by you in the past year, on any branch, tag, or other ref.
```
git rev-list --author=you@example.com --since=1.year.ago --all
```

  * Print the list of objects reachable from the current branch (i.e., all commits and the blobs and trees they contain).
```
git rev-list --objects HEAD
```

  * Compare the disk size of all reachable objects, versus those reachable from reflogs, versus the total packed size. This can tell you whether running `git` `repack` `-ad` might reduce the repository size (by dropping unreachable objects), and whether expiring reflogs might help.
```
# reachable objects
git rev-list --disk-usage --objects --all
# plus reflogs
git rev-list --disk-usage --objects --all --reflog
# total disk size used
du -c .git/objects/pack/*.pack .git/objects/??/*
# alternative to du: add up "size" and "size-pack" fields
git count-objects -v
```

  * Report the disk size of each branch, not including objects used by the current branch. This can find outliers that are contributing to a bloated repository size (e.g., because somebody accidentally committed large build artifacts).
```
git for-each-ref --format='%(refname)' |
while read branch
do
	size=$(git rev-list --disk-usage --objects HEAD..$branch)
	echo "$size $branch"
done |
sort -n
```

  * Compare the on-disk size of branches in one group of refs, excluding another. If you co-mingle objects from multiple remotes in a single repository, this can show which remotes are contributing to the repository size (taking the size of `origin` as a baseline).
```
git rev-list --disk-usage --objects --remotes=$suspect --not --remotes=origin
```



##  [](https://git-scm.com/docs/git-rev-list#_git)GIT
Part of the [git[1]](https://git-scm.com/docs/git) suite
### rev-list
[About this site](https://git-scm.com/site)
Patches, suggestions, and comments are welcome.
Git is a member of [Software Freedom Conservancy](https://git-scm.com/sfc)
