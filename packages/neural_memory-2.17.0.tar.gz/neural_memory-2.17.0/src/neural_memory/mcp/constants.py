"""Shared constants for MCP handlers."""

# Maximum content length per field — prevents memory exhaustion.
MAX_CONTENT_LENGTH = 100_000
