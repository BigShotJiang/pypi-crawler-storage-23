"""Entry point for running NeuralMemory MCP server."""

from neural_memory.mcp.server import main

if __name__ == "__main__":
    main()
