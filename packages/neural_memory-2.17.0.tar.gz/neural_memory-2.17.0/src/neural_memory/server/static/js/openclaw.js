/**
 * NeuralMemory Dashboard — OpenClaw module (stub)
 * OpenClaw configuration is managed via OpenClaw itself.
 * NM dashboard only checks integration status.
 */

const NM_OPENCLAW = { init() {} };
