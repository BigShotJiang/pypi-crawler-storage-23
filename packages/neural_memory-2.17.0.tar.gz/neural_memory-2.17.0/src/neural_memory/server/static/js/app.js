/**
 * NeuralMemory Dashboard — Core Alpine.js application
 * Orchestrates tabs, stats, health, integrations status, brain management,
 * i18n, toasts, WebSocket real-time, timeline, diagrams.
 */

/** Global toast dispatch — usable from any module */
function nmToast(message, type = 'success') {
  document.dispatchEvent(new CustomEvent('nm-toast', { detail: { message, type } }));
}

function dashboardApp() {
  return {
    // State
    version: '',
    locale: 'en',
    activeTab: 'overview',
    activeBrain: null,
    brains: [],
    stats: { total_brains: 0, total_neurons: 0, total_synapses: 0, total_fibers: 0 },
    healthGrade: 'F',
    purityScore: 0,
    healthWarnings: [],
    healthRecommendations: [],
    integrations: [],
    activityLog: [],
    activityExpanded: false,
    setupWizards: [],
    importSources: [],
    selectedNode: null,
    graphSearch: '',
    graphFilter: '',
    graphEmpty: false,
    toasts: [],
    loading: { stats: true, health: true, graph: false, integrations: false, activity: false, timeline: false, evolution: false },
    _radarChart: null,
    _graphLoaded: false,
    _healthData: null,

    // WebSocket state
    wsState: 'disconnected',

    // Graph controls
    graphLayout: 'fcose',
    graphNodeLimit: 500,
    graphClustering: false,
    graphNodeCount: 0,
    graphTotalNodes: 0,
    graphEdgeCount: 0,

    // Timeline state
    timelineGroups: [],
    timelineFilteredCount: 0,
    timelineTotalCount: 0,
    timelineTypeFilter: '',
    timelinePlaying: false,
    timelineSpeed: 1,
    _timelineLoaded: false,

    // Diagrams state
    diagramFibers: [],
    diagramSelectedFiber: '',
    diagramType: 'fiber_structure',
    _diagramsLoaded: false,

    // Evolution state
    _evolutionData: null,
    _evolutionChart: null,
    _evolutionLoaded: false,

    // Tab definitions (8 tabs)
    tabs: [
      { id: 'overview', label: 'overview', icon: 'layout-dashboard' },
      { id: 'graph', label: 'neural_graph', icon: 'share-2' },
      { id: 'timeline', label: 'timeline', icon: 'clock' },
      { id: 'diagrams', label: 'diagrams', icon: 'git-branch' },
      { id: 'integrations', label: 'integrations', icon: 'puzzle' },
      { id: 'health', label: 'brain_health', icon: 'heart-pulse' },
      { id: 'evolution', label: 'evolution', icon: 'trending-up' },
      { id: 'settings', label: 'settings', icon: 'sliders-horizontal' },
    ],

    // Initialize
    async init() {
      await NM_I18N.init();
      this.locale = NM_I18N.locale;

      // Listen for toast events from other modules
      document.addEventListener('nm-toast', (e) => {
        this.toast(e.detail.message, e.detail.type);
      });

      // Listen for timeline updates
      document.addEventListener('nm-timeline-update', (e) => {
        this.timelineGroups = e.detail.entries || [];
        this.timelineFilteredCount = NM_TIMELINE.entryCount;
        this.timelineTotalCount = NM_TIMELINE.totalCount;
      });

      document.addEventListener('nm-timeline-playback', (e) => {
        this.timelinePlaying = e.detail.playing;
      });

      // Fetch version
      try {
        const resp = await fetch('/');
        if (resp.ok) {
          const data = await resp.json();
          this.version = data.version || '';
        }
      } catch {}

      await Promise.all([this.loadStats(), this.loadHealth()]);

      // Watch tab changes
      this.$watch('activeTab', (tab) => this.onTabChange(tab));

      // Init WebSocket connection
      this._initWebSocket();

      // Init Lucide icons
      this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
    },

    // ── Toast system ───────────────────────────────────

    toast(message, type = 'success') {
      const id = Date.now() + Math.random();
      this.toasts = [...this.toasts, { id, message, type }];
      setTimeout(() => {
        this.toasts = this.toasts.filter(t => t.id !== id);
      }, 4000);
    },

    toastIcon(type) {
      const map = { success: 'check-circle', error: 'alert-circle', info: 'info', warning: 'alert-triangle' };
      return map[type] || 'info';
    },

    toastColor(type) {
      const map = {
        success: 'border-nm-cta text-nm-cta',
        error: 'border-nm-danger text-nm-danger',
        warning: 'border-nm-warning text-nm-warning',
        info: 'border-nm-info text-nm-info',
      };
      return map[type] || 'border-nm-border text-nm-muted';
    },

    // ── WebSocket ────────────────────────────────────────

    _initWebSocket() {
      if (typeof NM_WS === 'undefined') return;

      NM_WS.on('state_change', (data) => {
        this.wsState = data.state;
      });

      // Auto-update stats on memory events
      NM_WS.on('memory_encoded', () => {
        this.loadStats();
        if (this.activeTab === 'timeline' && this._timelineLoaded) {
          NM_TIMELINE.loadEntries().then(() => {
            this.timelineFilteredCount = NM_TIMELINE.entryCount;
            this.timelineTotalCount = NM_TIMELINE.totalCount;
          });
        }
      });

      NM_WS.on('neuron_created', (data) => {
        if (this._graphLoaded && data.data) {
          NM_GRAPH.addNode(data.data);
          this._updateGraphCounts();
        }
        this.loadStats();
      });

      NM_WS.on('synapse_created', (data) => {
        if (this._graphLoaded && data.data) {
          NM_GRAPH.addEdge(data.data);
          this._updateGraphCounts();
        }
      });

      // Connect with active brain
      if (this.activeBrain) {
        NM_WS.connect(this.activeBrain);
      } else {
        // Will connect once we know the brain
        this.$watch('activeBrain', (brain) => {
          if (brain) {
            NM_WS.connect(brain);
          }
        });
      }
    },

    wsStatusClass() {
      const map = {
        connected: 'connected',
        connecting: 'connecting',
        disconnected: 'disconnected',
        reconnecting: 'reconnecting',
      };
      return map[this.wsState] || 'disconnected';
    },

    wsStatusText() {
      const map = {
        connected: 'ws_connected',
        connecting: 'ws_connecting',
        disconnected: 'ws_disconnected',
        reconnecting: 'ws_reconnecting',
      };
      return this.t(map[this.wsState] || 'ws_disconnected');
    },

    // ── Tab change handlers ────────────────────────────

    async onTabChange(tab) {
      this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });

      if (tab === 'graph' && !this._graphLoaded) {
        this._graphLoaded = true;
        this.loading = { ...this.loading, graph: true };
        await this.$nextTick();
        const cy = await NM_GRAPH.init('cy-graph');
        this.loading = { ...this.loading, graph: false };
        this.graphEmpty = NM_GRAPH.isEmpty();
        this._updateGraphCounts();
        if (cy) {
          NM_GRAPH.onNodeClick((node) => { this.selectedNode = node; });
        }
      }

      if (tab === 'timeline' && !this._timelineLoaded) {
        this._timelineLoaded = true;
        this.loading = { ...this.loading, timeline: true };
        await this.$nextTick();
        await NM_TIMELINE.init('timeline-slider');
        this.timelineFilteredCount = NM_TIMELINE.entryCount;
        this.timelineTotalCount = NM_TIMELINE.totalCount;
        this.loading = { ...this.loading, timeline: false };
      }

      if (tab === 'diagrams' && !this._diagramsLoaded) {
        this._diagramsLoaded = true;
        await NM_DIAGRAMS.init();
        this.diagramFibers = NM_DIAGRAMS.fibers;
        // Render type pie if stats available
        if (this._healthData) {
          await this._renderTypePie();
        }
      }

      if (tab === 'integrations') {
        if (this.integrations.length === 0) {
          await this.loadIntegrations();
        }
        this.initSetupWizards();
        this.initImportSources();
        await this.loadActivity();
      }

      if (tab === 'evolution' && !this._evolutionLoaded) {
        this._evolutionLoaded = true;
        await this.loadEvolution();
      }

      if (tab === 'health') {
        this.$nextTick(() => this.renderRadar());
      }
    },

    // ── i18n ───────────────────────────────────────────

    t(key) {
      return NM_I18N.t(key);
    },

    toggleLocale() {
      this.setLocale(this.locale === 'en' ? 'vi' : 'en');
    },

    async setLocale(locale) {
      await NM_I18N.setLocale(locale);
      this.locale = locale;
    },

    // ── Data loading ───────────────────────────────────

    async loadStats() {
      this.loading = { ...this.loading, stats: true };
      try {
        const resp = await fetch('/api/dashboard/stats');
        if (resp.ok) {
          const data = await resp.json();
          this.stats = data;
          this.activeBrain = data.active_brain;
          this.brains = data.brains || [];
          this.healthGrade = data.health_grade || 'F';
          this.purityScore = data.purity_score || 0;
        }
      } catch {
        this.toast(NM_I18N.t('connection_failed'), 'error');
      }
      this.loading = { ...this.loading, stats: false };
    },

    async loadHealth() {
      this.loading = { ...this.loading, health: true };
      try {
        const resp = await fetch('/api/dashboard/health');
        if (resp.ok) {
          const data = await resp.json();
          this.healthGrade = data.grade || 'F';
          this.purityScore = data.purity_score || 0;
          this.healthWarnings = data.warnings || [];
          this.healthRecommendations = data.recommendations || [];
          this._healthData = data;
        }
      } catch {
        // Health data optional — don't show error
      }
      this.loading = { ...this.loading, health: false };
    },

    async loadIntegrations() {
      this.loading = { ...this.loading, integrations: true };

      const [oauthResult, openclawResult] = await Promise.allSettled([
        fetch('/api/oauth/providers').then(r => r.ok ? r.json() : []),
        fetch('/api/openclaw/config').then(r => r.ok ? r.json() : null),
      ]);

      const providers = oauthResult.status === 'fulfilled' && Array.isArray(oauthResult.value) ? oauthResult.value : [];
      const config = openclawResult.status === 'fulfilled' ? openclawResult.value : null;

      const authCount = providers.filter(p => p.authenticated).length;
      const keyCount = config ? (config.api_keys || []).filter(k => k.enabled).length : 0;
      const tgEnabled = config?.telegram?.enabled || false;
      const dcEnabled = config?.discord?.enabled || false;

      this.integrations = [
        {
          id: 'mcp', name: 'MCP Server', icon: 'server',
          active: true,
          detail: this.version ? `v${this.version} — 16 tools` : '16 tools',
          color: '#22C55E', link: null, linkLabel: null,
        },
        {
          id: 'nanobot', name: 'Nanobot', icon: 'bot',
          active: true,
          detail: this.t('int_nanobot_detail'),
          color: '#3B82F6', link: null, linkLabel: null,
        },
        {
          id: 'cliproxy', name: 'CLIProxyAPI', icon: 'key',
          active: authCount > 0,
          detail: providers.length > 0
            ? `${authCount}/${providers.length} ` + this.t('int_providers_auth')
            : this.t('int_not_reachable'),
          color: '#D97757',
          link: 'http://127.0.0.1:8317',
          linkLabel: this.t('int_open_dashboard'),
        },
        {
          id: 'openclaw', name: 'OpenClaw', icon: 'terminal',
          active: keyCount > 0,
          detail: keyCount > 0
            ? `${keyCount} ` + this.t('int_api_keys_configured')
            : this.t('int_not_configured'),
          color: '#F59E0B',
          link: null, linkLabel: null,
        },
        {
          id: 'telegram', name: 'Telegram', icon: 'send',
          active: tgEnabled,
          detail: tgEnabled ? this.t('connected') : this.t('int_not_configured'),
          color: '#0088CC',
          link: tgEnabled ? null : 'http://127.0.0.1:8317',
          linkLabel: tgEnabled ? null : this.t('int_configure'),
        },
        {
          id: 'discord', name: 'Discord', icon: 'hash',
          active: dcEnabled,
          detail: dcEnabled ? this.t('connected') : this.t('int_not_configured'),
          color: '#5865F2',
          link: dcEnabled ? null : 'http://127.0.0.1:8317',
          linkLabel: dcEnabled ? null : this.t('int_configure'),
        },
      ];

      this.loading = { ...this.loading, integrations: false };
      this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
    },

    // ── Brain management ───────────────────────────────

    async switchBrain(name) {
      try {
        const resp = await fetch('/api/dashboard/brains/switch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ brain_name: name }),
        });
        if (resp.ok) {
          // Update WS subscription
          if (typeof NM_WS !== 'undefined' && this.activeBrain) {
            NM_WS.unsubscribe(this.activeBrain);
          }
          this.activeBrain = name;
          if (typeof NM_WS !== 'undefined') {
            NM_WS.subscribe(name);
          }
          await Promise.all([this.loadStats(), this.loadHealth()]);
          this.toast(NM_I18N.t('brain_switched') || 'Brain switched', 'success');
        }
      } catch {
        this.toast(NM_I18N.t('error_occurred'), 'error');
      }
    },

    async exportBrain() {
      if (!this.activeBrain) return;
      try {
        const resp = await fetch(`/brain/${encodeURIComponent(this.activeBrain)}/export`);
        if (resp.ok) {
          const data = await resp.json();
          const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${this.activeBrain}-brain-export.json`;
          a.click();
          URL.revokeObjectURL(url);
          this.toast(NM_I18N.t('export_success'), 'success');
        }
      } catch {
        this.toast(NM_I18N.t('error_occurred'), 'error');
      }
    },

    async importBrain(event) {
      const file = event.target.files?.[0];
      if (!file || !this.activeBrain) return;

      // Guard against excessively large files (50MB max)
      if (file.size > 50 * 1024 * 1024) {
        this.toast(NM_I18N.t('error_occurred'), 'error');
        return;
      }

      try {
        const text = await file.text();
        const snapshot = JSON.parse(text);
        const resp = await fetch(`/brain/${encodeURIComponent(this.activeBrain)}/import`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(snapshot),
        });
        if (resp.ok) {
          await Promise.all([this.loadStats(), this.loadHealth()]);
          this.toast(NM_I18N.t('import_success'), 'success');
        }
      } catch {
        this.toast(NM_I18N.t('error_occurred'), 'error');
      }
      event.target.value = '';
    },

    // ── Quick Actions ──────────────────────────────────

    async runHealthCheck() {
      await this.loadHealth();
      this.activeTab = 'health';
      this.$nextTick(() => this.renderRadar());
      this.toast(NM_I18N.t('health_check_done') || 'Health check done', 'success');
    },

    viewWarnings() {
      this.activeTab = 'health';
    },

    // ── Graph toolbar ──────────────────────────────────

    graphZoomIn() { NM_GRAPH.zoomIn(); },
    graphZoomOut() { NM_GRAPH.zoomOut(); },
    graphFit() { NM_GRAPH.fit(); },

    searchGraph() {
      if (!this.graphSearch) {
        NM_GRAPH.clearSearch();
        return;
      }
      NM_GRAPH.search(this.graphSearch);
    },

    filterGraph() {
      NM_GRAPH.filterByType(this.graphFilter || '');
    },

    async reloadGraph() {
      this.loading = { ...this.loading, graph: true };
      this.selectedNode = null;
      this.graphSearch = '';
      this.graphFilter = '';
      NM_GRAPH._currentLimit = this.graphNodeLimit;
      const cy = await NM_GRAPH.reload();
      this.loading = { ...this.loading, graph: false };
      this.graphEmpty = NM_GRAPH.isEmpty();
      this._updateGraphCounts();
      if (cy) {
        NM_GRAPH.onNodeClick((node) => { this.selectedNode = node; });
      }
    },

    changeGraphLayout(layout) {
      this.graphLayout = layout;
      NM_GRAPH.setLayout(layout);
    },

    changeNodeLimit(limit) {
      this.graphNodeLimit = parseInt(limit, 10);
    },

    async applyNodeLimit() {
      this.loading = { ...this.loading, graph: true };
      NM_GRAPH._currentLimit = this.graphNodeLimit;
      const cy = await NM_GRAPH.reload();
      this.loading = { ...this.loading, graph: false };
      this.graphEmpty = NM_GRAPH.isEmpty();
      this._updateGraphCounts();
      if (cy) {
        NM_GRAPH.onNodeClick((node) => { this.selectedNode = node; });
      }
    },

    async loadMoreNodes() {
      const count = await NM_GRAPH.loadMore(200);
      if (count > 0) {
        this._updateGraphCounts();
        this.toast(NM_I18N.t('nodes_loaded') || `Loaded ${count} more nodes`, 'info');
      }
    },

    toggleGraphClustering() {
      NM_GRAPH.toggleClustering();
      this.graphClustering = NM_GRAPH.isClusteringEnabled();
    },

    graphHasMore() {
      return NM_GRAPH.hasMore();
    },

    _updateGraphCounts() {
      this.graphNodeCount = NM_GRAPH.nodeCount();
      this.graphTotalNodes = NM_GRAPH.totalNodeCount();
      this.graphEdgeCount = NM_GRAPH.edgeCount();
    },

    // ── Timeline controls ──────────────────────────────

    timelinePlay() { NM_TIMELINE.play(); },
    timelinePause() { NM_TIMELINE.pause(); },
    timelineStepForward() { NM_TIMELINE.stepForward(); },
    timelineStepBackward() { NM_TIMELINE.stepBackward(); },

    setTimelineSpeed(speed) {
      this.timelineSpeed = speed;
      NM_TIMELINE.setSpeed(speed);
    },

    setTimelineTypeFilter(type) {
      this.timelineTypeFilter = type;
      NM_TIMELINE.setTypeFilter(type);
    },

    timelineIcon(type) {
      return NM_TIMELINE.getIcon(type);
    },

    timelineColor(type) {
      return NM_TIMELINE.getColor(type);
    },

    // ── Diagram controls ───────────────────────────────

    async selectDiagramFiber(fiberId) {
      this.diagramSelectedFiber = fiberId;
      if (!fiberId) return;

      if (this.diagramType === 'fiber_structure') {
        await NM_DIAGRAMS.renderFiberStructure(fiberId, 'diagram-container');
      } else if (this.diagramType === 'synapse_flow') {
        await NM_DIAGRAMS.renderSynapseFlow(fiberId, 'diagram-container');
      }
      this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
    },

    async changeDiagramType(type) {
      this.diagramType = type;

      if (type === 'type_distribution') {
        await this._renderTypePie();
      } else if (this.diagramSelectedFiber) {
        await this.selectDiagramFiber(this.diagramSelectedFiber);
      }
    },

    async _renderTypePie() {
      // Build type counts from health data or stats
      const typeCounts = {};
      if (this._healthData) {
        // Use neuron count by type — we'll estimate from graph data
        try {
          const resp = await fetch('/api/graph?limit=5000&offset=0');
          if (resp.ok) {
            const data = await resp.json();
            for (const n of (data.neurons || [])) {
              typeCounts[n.type] = (typeCounts[n.type] || 0) + 1;
            }
          }
        } catch {
          // Fallback — empty pie
        }
      }
      await NM_DIAGRAMS.renderTypePie('diagram-container', typeCounts);
    },

    // ── Integrations refresh ───────────────────────────

    async refreshIntegrations() {
      this.integrations = [];
      await this.loadIntegrations();
      await this.loadActivity();
      this.toast(this.t('int_status_refreshed'), 'success');
    },

    // ── Activity log ────────────────────────────────────

    async loadActivity() {
      this.loading = { ...this.loading, activity: true };
      try {
        const resp = await fetch('/api/dashboard/activity?limit=50');
        if (resp.ok) {
          const data = await resp.json();
          this.activityLog = data.activity || [];
          // Merge metrics into integrations (immutable)
          for (const m of (data.metrics || [])) {
            const idx = this.integrations.findIndex(i => i.id === m.integration_id);
            if (idx !== -1) {
              this.integrations = [
                ...this.integrations.slice(0, idx),
                { ...this.integrations[idx], metrics: m },
                ...this.integrations.slice(idx + 1),
              ];
            }
          }
        }
      } catch {
        // Activity data is optional
      }
      this.loading = { ...this.loading, activity: false };
      this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
    },

    async refreshActivity() {
      await this.loadActivity();
      this.toast(this.t('int_activity_refreshed'), 'success');
    },

    activityIcon(type) {
      const map = {
        remember: 'brain',
        recall: 'search',
        context: 'layers',
        auto: 'zap',
        process: 'cpu',
        todo: 'check-square',
      };
      return map[type] || 'activity';
    },

    formatTime(isoString) {
      if (!isoString) return '';
      const d = new Date(isoString);
      const now = new Date();
      const diffMs = now - d;
      if (diffMs < 60000) return this.t('just_now');
      if (diffMs < 3600000) return Math.floor(diffMs / 60000) + 'm ' + this.t('ago');
      if (diffMs < 86400000) return Math.floor(diffMs / 3600000) + 'h ' + this.t('ago');
      return d.toLocaleDateString();
    },

    // ── Setup wizards ───────────────────────────────────

    initSetupWizards() {
      if (this.setupWizards.length > 0) return;
      this.setupWizards = [
        {
          id: 'claude-code', name: 'Claude Code', icon: 'terminal', color: '#D97757', open: false,
          description: this.t('int_setup_claude_desc'),
          snippet: JSON.stringify({
            mcpServers: {
              'neural-memory': {
                command: 'python',
                args: ['-m', 'neural_memory.mcp'],
              },
            },
          }, null, 2),
        },
        {
          id: 'cursor', name: 'Cursor', icon: 'mouse-pointer', color: '#3B82F6', open: false,
          description: this.t('int_setup_cursor_desc'),
          snippet: JSON.stringify({
            mcpServers: {
              'neural-memory': {
                command: 'python',
                args: ['-m', 'neural_memory.mcp'],
              },
            },
          }, null, 2),
        },
        {
          id: 'openclaw', name: 'OpenClaw Plugin', icon: 'puzzle', color: '#F59E0B', open: false,
          description: this.t('int_setup_openclaw_desc'),
          snippet: '# Install the plugin\nnpm install -g @neuralmemory/openclaw-plugin\n\n# Add to ~/.openclaw/openclaw.json:\n' + JSON.stringify({
            plugins: {
              entries: {
                neuralmemory: { enabled: true, config: { brain: 'default', autoContext: true, autoCapture: true } },
              },
              slots: { memory: 'neuralmemory' },
            },
          }, null, 2),
        },
        {
          id: 'generic-mcp', name: 'Generic MCP', icon: 'server', color: '#22C55E', open: false,
          description: this.t('int_setup_generic_desc'),
          snippet: JSON.stringify({
            'neural-memory': {
              command: 'python',
              args: ['-m', 'neural_memory.mcp'],
              env: { NEURALMEMORY_BRAIN: 'default' },
            },
          }, null, 2),
        },
      ];
      this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
    },

    // ── Import sources ──────────────────────────────────

    initImportSources() {
      if (this.importSources.length > 0) return;
      this.importSources = [
        { id: 'chromadb', name: 'ChromaDB', detected: false },
        { id: 'mem0', name: 'Mem0', detected: false },
        { id: 'cognee', name: 'Cognee', detected: false },
        { id: 'graphiti', name: 'Graphiti', detected: false },
        { id: 'llamaindex', name: 'LlamaIndex', detected: false },
      ];
    },

    // ── Clipboard ───────────────────────────────────────

    async copySnippet(text) {
      try {
        await navigator.clipboard.writeText(text);
        this.toast(this.t('copied_to_clipboard'), 'success');
      } catch {
        this.toast(this.t('error_occurred'), 'error');
      }
    },

    // ── Health radar chart ─────────────────────────────

    renderRadar() {
      const canvas = document.getElementById('health-radar');
      if (!canvas || !this._healthData) return;

      if (this._radarChart) {
        this._radarChart.destroy();
      }

      const d = this._healthData;
      this._radarChart = new Chart(canvas, {
        type: 'radar',
        data: {
          labels: [
            this.t('connectivity'),
            this.t('diversity'),
            this.t('freshness'),
            this.t('consolidation'),
            this.t('activation'),
            this.t('recall'),
            '1 - ' + this.t('orphan_rate'),
          ],
          datasets: [{
            label: this.t('brain_health'),
            data: [
              d.connectivity || 0,
              d.diversity || 0,
              d.freshness || 0,
              d.consolidation_ratio || 0,
              d.activation_efficiency || 0,
              d.recall_confidence || 0,
              1.0 - (d.orphan_rate || 0),
            ],
            backgroundColor: 'rgba(34, 197, 94, 0.15)',
            borderColor: '#22C55E',
            pointBackgroundColor: '#22C55E',
            pointBorderColor: '#F8FAFC',
            pointBorderWidth: 1,
            borderWidth: 2,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            r: {
              beginAtZero: true,
              max: 1,
              ticks: {
                stepSize: 0.25,
                color: '#94A3B8',
                backdropColor: 'transparent',
                font: { family: 'Fira Code', size: 10 },
              },
              grid: { color: '#334155' },
              angleLines: { color: '#334155' },
              pointLabels: {
                color: '#F8FAFC',
                font: { family: 'Fira Sans', size: 11 },
              },
            },
          },
          plugins: {
            legend: { display: false },
          },
        },
      });
    },

    // ── Evolution ──────────────────────────────────────

    async loadEvolution() {
      this.loading = { ...this.loading, evolution: true };
      try {
        const resp = await fetch('/api/dashboard/evolution');
        if (resp.ok) {
          this._evolutionData = await resp.json();
          this.$nextTick(() => this.renderStageChart());
        }
      } catch (e) {
        console.error('Failed to load evolution data', e);
      }
      this.loading = { ...this.loading, evolution: false };
      this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
    },

    renderStageChart() {
      const canvas = document.getElementById('evolution-stage-chart');
      if (!canvas || !this._evolutionData?.stage_distribution) return;

      if (this._evolutionChart) {
        this._evolutionChart.destroy();
      }

      const sd = this._evolutionData.stage_distribution;
      this._evolutionChart = new Chart(canvas, {
        type: 'doughnut',
        data: {
          labels: ['Short-term', 'Working', 'Episodic', 'Semantic'],
          datasets: [{
            data: [sd.short_term, sd.working, sd.episodic, sd.semantic],
            backgroundColor: ['#94A3B8', '#F59E0B', '#3B82F6', '#22C55E'],
            borderColor: '#0F172A',
            borderWidth: 2,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                color: '#F8FAFC',
                font: { family: 'JetBrains Mono, monospace', size: 11 },
                padding: 16,
              },
            },
          },
        },
      });
    },

    stageList() {
      const sd = this._evolutionData?.stage_distribution;
      if (!sd) return [];
      const total = sd.total || 1;
      return [
        { key: 'short_term', label: 'Short-term', count: sd.short_term, color: '#94A3B8', pct: ((sd.short_term / total) * 100).toFixed(0) },
        { key: 'working', label: 'Working', count: sd.working, color: '#F59E0B', pct: ((sd.working / total) * 100).toFixed(0) },
        { key: 'episodic', label: 'Episodic', count: sd.episodic, color: '#3B82F6', pct: ((sd.episodic / total) * 100).toFixed(0) },
        { key: 'semantic', label: 'Semantic', count: sd.semantic, color: '#22C55E', pct: ((sd.semantic / total) * 100).toFixed(0) },
      ];
    },

    proficiencyColor(level) {
      const map = { junior: 'text-nm-muted', senior: 'text-nm-info', expert: 'text-nm-cta' };
      return map[level] || 'text-nm-muted';
    },

    proficiencyBarColor(level) {
      const map = { junior: 'bg-slate-400', senior: 'bg-blue-400', expert: 'bg-emerald-400' };
      return map[level] || 'bg-slate-400';
    },

    // ── Utility ────────────────────────────────────────

    gradeColor(grade) {
      const map = {
        A: 'text-nm-cta',
        B: 'text-nm-info',
        C: 'text-nm-warning',
        D: 'text-orange-500',
        F: 'text-nm-danger',
      };
      return map[grade] || 'text-nm-muted';
    },
  };
}
