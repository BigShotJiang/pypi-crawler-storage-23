"""FastAPI server for NeuralMemory."""

from neural_memory.server.app import create_app

__all__ = ["create_app"]
