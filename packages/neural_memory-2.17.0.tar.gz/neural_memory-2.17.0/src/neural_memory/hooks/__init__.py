"""Claude Code hook handlers for NeuralMemory.

Provides automatic memory capture on events like context compaction.
"""
