# squap
A python package for animated plots, focussed on simplicity and speed. Its name stands for Simple QUick Animated Plots. It is based on pyqtgraph using PySide6. It is much simpler and user-friendly than pyqtgraph, sacrificing as little performance as possible.
