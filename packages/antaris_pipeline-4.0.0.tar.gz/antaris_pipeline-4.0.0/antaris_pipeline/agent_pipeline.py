"""
AgentPipeline: Simple coordinator for agent workflows

This is the main class developers should use for integrating Antaris into their agents.
It provides simple pre_turn() and post_turn() methods that handle all the coordination.
"""

import sys
import time
import logging
from pathlib import Path
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass

# FIX 12: Route all warnings to stderr so they don't contaminate the NDJSON bridge protocol.
logging.basicConfig(stream=sys.stderr, level=logging.WARNING)
logger = logging.getLogger(__name__)

from .pipeline import AntarisPipeline, create_pipeline, PipelineConfig


def _get_relevance_score(r: dict) -> float:
    """Extract relevance score from a retrieval dict, trying multiple field names.

    Different retrieval backends may use different key names.  We try the most
    common ones in priority order so that the min_relevance filter is effective
    regardless of which backend produced the results.

    FIX r7/3: the previous filter used only ``r.get("relevance", 1.0)``, which
    silently passed every result from backends that use ``score``,
    ``similarity``, or ``relevance_score`` — because the missing key defaulted
    to 1.0 and always cleared the threshold.
    """
    for key in ("relevance", "score", "similarity", "relevance_score"):
        val = r.get(key)
        if val is not None:
            return float(val)
    return 1.0  # unknown — pass through by default


@dataclass
class PreTurnResult:
    """Result from pre_turn processing."""
    success: bool
    context: Optional[str] = None  # Enriched context to prepend to conversation
    blocked: bool = False  # If true, don't proceed with LLM call
    block_reason: Optional[str] = None
    memory_count: int = 0
    warnings: List[str] = None  # Infrastructure/component errors
    guard_issues: List[str] = None  # Guard-specific findings
    routing_recommendation: Optional[Dict] = None
    turn_state: Optional[Dict] = None  # Opaque token to pass back into post_turn()

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []
        if self.guard_issues is None:
            self.guard_issues = []
        if self.turn_state is None:
            self.turn_state = {}


@dataclass  
class PostTurnResult:
    """Result from post_turn processing."""
    success: bool
    stored_memories: int = 0
    warnings: List[str] = None  # Infrastructure/component errors
    guard_issues: List[str] = None  # Guard-specific findings
    blocked_output: bool = False
    safe_replacement: Optional[str] = None
    
    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []
        if self.guard_issues is None:
            self.guard_issues = []


class AgentPipeline:
    """
    Simple agent pipeline coordinator that handles the full Antaris workflow.
    
    This is the main entry point for developers who want to integrate Antaris
    into their agents. It provides a clean pre_turn/post_turn API.
    
    Example:
        pipeline = AgentPipeline(memory=True, guard=True, context=True)
        
        # Before LLM call
        pre_result = pipeline.pre_turn(user_message)
        if pre_result.blocked:
            return pre_result.block_reason
        
        # Add pre_result.context to your prompt if available
        full_prompt = pre_result.context + user_message if pre_result.context else user_message
        response = my_llm_call(full_prompt)
        
        # After LLM call  
        post_result = pipeline.post_turn(user_message, response)
        if post_result.blocked_output and post_result.safe_replacement:
            response = post_result.safe_replacement
    """
    
    def __init__(
        self,
        storage_path: Union[str, Path] = "./antaris_memory_store",
        memory: bool = True,
        guard: bool = False,
        context: bool = True,
        router: bool = False,  # Router is mainly for model selection, less needed in simple usage
        guard_mode: str = "monitor",  # "monitor" or "block"
        session_id: Optional[str] = None,
        config: Optional[PipelineConfig] = None,
        **kwargs
    ):
        """
        Initialize the agent pipeline.
        
        Args:
            storage_path: Where to store memories
            memory: Enable memory recall and ingestion
            guard: Enable safety monitoring  
            context: Enable context window optimization
            router: Enable smart model routing (advanced)
            guard_mode: "monitor" (log warnings) or "block" (prevent unsafe content)
            session_id: Optional session identifier
            config: Advanced pipeline configuration
            **kwargs: Additional config passed to underlying components
        """
        self.storage_path = Path(storage_path)
        self.enable_memory = memory
        self.enable_guard = guard
        self.enable_context = context
        self.enable_router = router
        self.guard_mode = guard_mode
        self.session_id = session_id
        
        # Create the underlying pipeline
        # Extract valid kwargs for create_pipeline
        valid_kwargs = {}
        for key in ["memory_config", "router_config", "guard_config", "context_config"]:
            if key in kwargs:
                valid_kwargs[key] = kwargs.pop(key)
        
        # FIX r7/4: create_pipeline() is EAGER — it imports and constructs all 4
        # Antaris packages (memory, router, guard, context) unconditionally at the
        # top of pipeline.py, regardless of which components are enabled here.
        # This means AgentPipeline(memory=False) can still raise an ImportError at
        # init time if any of the four packages is not installed.
        #
        # The minimal safe fix is to catch ImportError here and re-raise with a
        # clear, actionable message rather than letting a cryptic ImportError bubble
        # up from deep inside the package graph.
        #
        # A full lazy-import refactor of create_pipeline() would be the ideal long-
        # term fix; track as a follow-up task.
        try:
            self.pipeline = create_pipeline(
                storage_path=storage_path,
                pipeline_config=config,
                session_id=session_id,
                **valid_kwargs
            )
        except ImportError as exc:
            raise ImportError(
                f"AgentPipeline could not initialise because a required Antaris "
                f"package is missing: {exc}.  "
                f"All four packages must be installed even when individual "
                f"components are disabled via the memory/guard/context/router flags, "
                f"because create_pipeline() eagerly imports all of them.  "
                f"Run: pip install antaris-memory antaris-router antaris-guard antaris-context"
            ) from exc
        
        # Track state for graceful degradation
        self._last_error: Optional[str] = None
        self._components_available = {
            "memory": True,
            "guard": True, 
            "context": True,
            "router": True
        }
        
        # CONCURRENCY NOTE: The concurrency-safe path is to pass turn_state from
        # pre_turn() back into post_turn().  The instance variables below are
        # legacy backward-compat fallbacks; they race under concurrent access.
        # New callers should always use: post_turn(..., turn_state=pre_result.turn_state)
        #
        # Track guard result from pre_turn for use in post_turn (legacy fallback).
        # Safe ONLY because pipeline_bridge.py serializes all requests (NDJSON
        # loop processes one request at a time).
        self._last_input_guard_result: Optional[Dict] = None

        # FIX 9: Track routing result from pre_turn for use in post_turn memory_storage.
        # Same serialization-safe contract as _last_input_guard_result above (legacy fallback).
        self._last_routing_result: Optional[Dict] = None
        
        # Test components and mark unavailable ones
        self._test_components()
    
    def _test_components(self):
        """Test which components are available and working."""
        # Test memory
        if self.enable_memory:
            try:
                self.pipeline.memory.get_stats()
            except Exception as e:
                self._components_available["memory"] = False
                # FIX 12: use logger (stderr) — print() would contaminate the NDJSON bridge protocol
                logger.warning(f"antaris-memory not available: {e}")
        
        # Test guard
        if self.enable_guard:
            try:
                result = self.pipeline.guard.analyze("test")
                if not hasattr(result, 'is_safe'):
                    raise AttributeError("Invalid guard response")
            except Exception as e:
                self._components_available["guard"] = False
                logger.warning(f"antaris-guard not available: {e}")
        
        # Test context
        if self.enable_context:
            try:
                self.pipeline.context.get_usage_report()
            except Exception as e:
                self._components_available["context"] = False
                logger.warning(f"antaris-context not available: {e}")
                
        # Test router  
        if self.enable_router:
            try:
                decision = self.pipeline.router.route("test prompt")
                if not hasattr(decision, 'model'):
                    raise AttributeError("Invalid router response")
            except Exception as e:
                self._components_available["router"] = False
                logger.warning(f"antaris-router not available: {e}")
    
    def pre_turn(
        self,
        user_message: str,
        context_data: Optional[Dict] = None,
        auto_recall: bool = True,
        search_limit: int = 5,
        min_relevance: float = 0.0,
    ) -> PreTurnResult:
        """
        Process user input before LLM call.
        
        Handles:
        1. Input guard check (if enabled) 
        2. Memory recall (if enabled and auto_recall=True)
        3. Context assembly (if enabled)
        4. Routing recommendation (if enabled)
        
        Args:
            user_message: The user's input message
            context_data: Optional additional context data
            auto_recall: If False, skip memory retrieval entirely (FIX 4)
            search_limit: Max number of memories to retrieve (FIX 4)
            min_relevance: Minimum relevance score threshold for retrieved memories (FIX 4)
            
        Returns:
            PreTurnResult with enriched context and safety information
        """
        result = PreTurnResult(success=True)
        
        try:
            # Step 1: Guard input check
            if self.enable_guard and self._components_available["guard"]:
                try:
                    guard_result = self.pipeline.guard_input_scan(user_message)
                    # Store guard result: both in turn_state (concurrency-safe) and
                    # instance variable (legacy fallback — safe only while serialized).
                    self._last_input_guard_result = guard_result
                    result.turn_state["input_guard_result"] = guard_result
                    
                    if not guard_result.get("allowed", True):
                        if self.guard_mode == "block":
                            result.blocked = True
                            result.block_reason = "Input contains unsafe content and was blocked by security policies."
                            result.success = True  # Successfully blocked
                            return result
                        else:
                            # Monitor mode - just warn
                            result.guard_issues.append(f"Input warning: {guard_result.get('message', 'Security concern detected')}")
                            
                except Exception as e:
                    result.warnings.append(f"Guard check failed: {str(e)}")
            
            # Step 2: Memory retrieval
            # FIX 4: skip retrieval entirely when auto_recall=False.
            # FIX 7: preserve the full memory_data dict so it can be forwarded to
            # context_building() and smart_routing() — previously both were called with
            # {"retrievals": []} (fake empty list), discarding the real retrieved memories.
            memory_data: Dict = {}
            memory_context = ""
            if auto_recall and self.enable_memory and self._components_available["memory"]:
                try:
                    # FIX 4: pass search_limit to the underlying retrieval call when supported.
                    try:
                        memory_data = self.pipeline.memory_retrieval(user_message, context_data, limit=search_limit)
                    except TypeError:
                        # Older AntarisPipeline doesn't accept limit — call without it.
                        memory_data = self.pipeline.memory_retrieval(user_message, context_data)

                    # Apply search_limit as a post-retrieval cap.
                    # memory_retrieval() doesn't expose a limit param, so we slice here.
                    # search_limit=0 means "retrieve nothing" (effectively disables recall).
                    retrievals = memory_data.get("retrievals", [])
                    if search_limit == 0:
                        retrievals = []
                    elif search_limit > 0:
                        retrievals = retrievals[:search_limit]

                    # Apply min_relevance filter.
                    # Uses _get_relevance_score() to handle backends that store the score
                    # under different key names ("score", "similarity", "relevance_score").
                    if min_relevance > 0.0:
                        retrievals = [r for r in retrievals if _get_relevance_score(r) >= min_relevance]

                    memory_data = {**memory_data, "retrievals": retrievals}

                    result.memory_count = len(memory_data.get("retrievals", []))
                    
                    # Format memory context (for fallback use if context building fails)
                    if result.memory_count > 0:
                        context_packet = memory_data.get("context_packet", {})
                        memory_context = context_packet.get("rendered", "")
                        
                except Exception as e:
                    result.warnings.append(f"Memory recall failed: {str(e)}")
            
            # FIX 10/11: initialize context_result so utilization is available for routing
            # even when context building is skipped or raises.
            context_result: Dict = {}

            # Step 3: Context building (combines user input + memory)
            if self.enable_context and self._components_available["context"]:
                try:
                    # FIX 7: pass actual memory_data (contains real retrievals, context_packet,
                    # retrieved_count) instead of the previously hard-coded empty dict.
                    #
                    # FIX 10: context_building() IS stateful — it mutates self.pipeline.context's
                    # internal context-window store.  The subsequent render_context() call reads
                    # that mutated state to serialize items into the prompt.  These two calls are
                    # intentionally coupled; do not remove context_building() thinking it's a no-op.
                    context_result = self.pipeline.context_building(
                        user_message,
                        memory_data,  # FIX 7: real retrievals, not []
                    )
                    
                    # render_context() serializes the state staged by context_building() above.
                    assembled_context = self.pipeline.context.render_context(
                        query=user_message,
                        template="agent_with_tools"
                    )
                    
                    if assembled_context:
                        result.context = assembled_context
                    elif memory_context:
                        # Fallback to just memory context if context building failed
                        result.context = memory_context
                        
                except Exception as e:
                    result.warnings.append(f"Context building failed: {str(e)}")
                    # Fallback to memory context
                    if memory_context:
                        result.context = memory_context
            elif memory_context:
                # Context disabled but memory available
                result.context = memory_context
            
            # Step 4: Routing recommendation (optional)
            if self.enable_router and self._components_available["router"]:
                try:
                    routing_result = self.pipeline.smart_routing(
                        user_message,
                        memory_data,  # FIX 7: real retrievals, not []
                        # FIX 11: use actual utilization from context_result, not hardcoded 0.5
                        {"context_length": len(result.context or ""), "utilization": context_result.get("utilization", 0.5)}
                    )
                    result.routing_recommendation = routing_result
                    # Store routing result: both in turn_state (concurrency-safe) and
                    # instance variable (legacy fallback — see class note).
                    self._last_routing_result = routing_result
                    result.turn_state["routing_result"] = routing_result
                    
                except Exception as e:
                    result.warnings.append(f"Routing failed: {str(e)}")
        
        except Exception as e:
            result.success = False
            result.warnings.append(f"Pre-turn processing failed: {str(e)}")
            self._last_error = str(e)
        
        return result
    
    def post_turn(
        self,
        user_message: str,
        assistant_response: str,
        auto_ingest: bool = True,
        turn_state: Optional[Dict] = None,
    ) -> PostTurnResult:
        """
        Process after LLM call.
        
        Handles:
        1. Output guard check (if enabled)
        2. Memory ingestion (if enabled and auto_ingest=True)
        
        Args:
            user_message: The original user input
            assistant_response: The LLM's response
            auto_ingest: If False, skip memory storage entirely (FIX 1)
            
        Returns:
            PostTurnResult with storage and safety information
        """
        result = PostTurnResult(success=True)
        
        try:
            # Step 1: Guard output check
            if self.enable_guard and self._components_available["guard"]:
                try:
                    guard_result = self.pipeline.guard_output_scan(assistant_response)
                    
                    if not guard_result.get("allowed", True):
                        if self.guard_mode == "block":
                            result.blocked_output = True
                            result.safe_replacement = "I apologize, but I cannot provide that response due to safety policies. Please try rephrasing your request."
                        else:
                            result.guard_issues.append(f"Output warning: {guard_result.get('message', 'Response flagged by security policies')}")
                            
                except Exception as e:
                    result.warnings.append(f"Output guard check failed: {str(e)}")
            
            # Step 2: Memory ingestion
            # FIX 1: honour auto_ingest flag — skip storage entirely when False.
            if auto_ingest and self.enable_memory and self._components_available["memory"]:
                try:
                    # Prefer turn_state (concurrency-safe) over instance variables (legacy fallback).
                    _turn = turn_state or {}
                    input_guard_result = _turn.get("input_guard_result") or self._last_input_guard_result
                    routing_meta = _turn.get("routing_result") or self._last_routing_result or {
                        "selected_model": "unknown",
                        "tier": "unknown",
                        "estimated_cost": 0.0,
                    }
                    ingested = self.pipeline.memory_storage(
                        user_message,
                        assistant_response,
                        routing_meta,
                        input_guard_result=input_guard_result
                    )
                    # FIX 8: stored_memories was hardcoded to 1 regardless of what the storage
                    # layer actually did.  Use the returned count when available.
                    # FIX r7/2: properly handle None (skipped) and False (failed) returns —
                    # the old `else 1` branch would misreport those as 1 stored memory.
                    # NOTE: bool is a subclass of int in Python, so isinstance(False, int)
                    # Check bool before int — bool is a subclass of int in Python,
                    # so isinstance(True, int) is True. Checking bool first ensures
                    # True→1 and False→0 are handled explicitly and readably.
                    if isinstance(ingested, bool):
                        result.stored_memories = int(ingested)   # True→1, False→0
                    elif isinstance(ingested, int):
                        result.stored_memories = ingested
                    elif ingested is None:
                        # memory_storage() has no explicit return → None means
                        # "count unavailable, but no exception was raised" = success.
                        result.stored_memories = 1
                    else:
                        result.stored_memories = 1  # non-None, non-int, non-bool → assume success
                    
                except Exception as e:
                    result.warnings.append(f"Memory storage failed: {str(e)}")
                    # stored_memories intentionally stays at 0 — nothing was confirmed stored
        
        except Exception as e:
            result.success = False
            result.warnings.append(f"Post-turn processing failed: {str(e)}")
            self._last_error = str(e)
        finally:
            # Reset per-turn state after use (safe only while requests are serialized)
            self._last_input_guard_result = None
            self._last_routing_result = None  # FIX 9: reset alongside guard result
        
        return result
    
    def get_stats(self) -> Dict[str, Any]:
        """Get pipeline statistics."""
        stats = {
            "session_id": self.session_id,
            "components_enabled": {
                "memory": self.enable_memory,
                "guard": self.enable_guard, 
                "context": self.enable_context,
                "router": self.enable_router
            },
            "components_available": self._components_available,
            "guard_mode": self.guard_mode,
            "last_error": self._last_error
        }
        
        # Add component-specific stats if available
        if self.enable_memory and self._components_available["memory"]:
            try:
                stats["memory_stats"] = self.pipeline.memory.get_stats()
            except Exception:
                pass
                
        if self.enable_guard and self._components_available["guard"]:
            try:
                stats["guard_stats"] = self.pipeline.guard.get_stats()
            except Exception:
                pass
        
        return stats

    def on_session_start(self, summary: str = "") -> Dict[str, Any]:
        """
        Handle session start with optional compaction summary.
        
        Args:
            summary: Optional compaction summary from previous session
            
        Returns:
            Dict with prependContext for session restoration
        """
        try:
            if hasattr(self.pipeline, 'on_session_start'):
                # Forward summary so AntarisPipeline can include it in the restored context.
                return self.pipeline.on_session_start(summary=summary)
            else:
                # Fallback: no context restoration available
                return {"prependContext": ""}
        except Exception as e:
            self._last_error = str(e)
            return {"prependContext": ""}

    def close(self) -> None:
        """Explicitly release pipeline resources (memory file handles, etc.).

        Call this before discarding an AgentPipeline instance when a pipeline
        re-init is required (e.g., config change), so that antaris-memory can
        flush and close any SQLite/file handles before GC has a chance to do it
        non-deterministically.
        """
        try:
            if hasattr(self.pipeline, 'memory') and hasattr(self.pipeline.memory, 'save'):
                self.pipeline.memory.save()
            if hasattr(self.pipeline, 'close'):
                self.pipeline.close()
        except Exception as e:
            logger.warning(f"AgentPipeline.close() error: {e}")