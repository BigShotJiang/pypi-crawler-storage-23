"""
QuarterBit Model Loader - Load large models efficiently
========================================================

Helper to load HuggingFace models with INT8 quantization for memory efficiency.
Uses bitsandbytes when available, falls back to FP16 with a warning.

Usage:
    from quarterbit import load_model

    # Automatically uses INT8 if bitsandbytes is available
    model = load_model("EleutherAI/gpt-j-6b")

    # Force FP16 (no quantization)
    model = load_model("EleutherAI/gpt-j-6b", quantize=False)

Copyright 2026 Clouthier Simulation Labs
"""

import warnings
from typing import Optional, Union

import torch


def load_model(
    model_name_or_path: str,
    quantize: bool = True,
    dtype: Optional[torch.dtype] = None,
    device_map: str = "auto",
    trust_remote_code: bool = False,
    **kwargs
):
    """Load a HuggingFace model with optional INT8 quantization.

    This helper ensures models are loaded efficiently:
    - With bitsandbytes: Loads in INT8 (~50% memory savings)
    - Without bitsandbytes: Loads in FP16 with warning

    Args:
        model_name_or_path: HuggingFace model name or local path
        quantize: Use INT8 quantization if available (default: True)
        dtype: Force specific dtype (default: auto-select)
        device_map: Device placement strategy (default: "auto")
        trust_remote_code: Trust remote code in model (default: False)
        **kwargs: Additional args passed to from_pretrained

    Returns:
        Loaded model ready for training with AXIOM

    Example:
        from quarterbit import load_model, AXIOM

        # Load 6B model in INT8 (~6GB instead of 12GB)
        model = load_model("EleutherAI/gpt-j-6b")

        # Create AXIOM optimizer
        opt = AXIOM(model.parameters(), lr=1e-4)
        opt.register_hooks()
    """
    try:
        from transformers import AutoModelForCausalLM
    except ImportError:
        raise ImportError(
            "transformers is required for load_model. "
            "Install with: pip install transformers"
        )

    # Try INT8 quantization with bitsandbytes
    if quantize:
        try:
            from transformers import BitsAndBytesConfig
            import bitsandbytes  # Check it's installed

            print(f"Loading {model_name_or_path} in INT8 (bitsandbytes)...")
            quantization_config = BitsAndBytesConfig(load_in_8bit=True)

            model = AutoModelForCausalLM.from_pretrained(
                model_name_or_path,
                quantization_config=quantization_config,
                device_map=device_map,
                low_cpu_mem_usage=True,
                trust_remote_code=trust_remote_code,
                **kwargs
            )

            # Calculate memory
            mem_gb = sum(p.numel() * p.element_size() for p in model.parameters()) / 1e9
            print(f"Model loaded: {mem_gb:.1f} GB (INT8 quantized)")

            return model

        except ImportError:
            warnings.warn(
                "bitsandbytes not installed. Loading in FP16 instead.\n"
                "For 50% memory savings, install: pip install bitsandbytes\n"
                "Note: bitsandbytes requires Linux or WSL on Windows.",
                UserWarning
            )

    # Fallback to FP16
    if dtype is None:
        dtype = torch.float16

    print(f"Loading {model_name_or_path} in {dtype}...")

    model = AutoModelForCausalLM.from_pretrained(
        model_name_or_path,
        torch_dtype=dtype,
        device_map=device_map,
        low_cpu_mem_usage=True,
        trust_remote_code=trust_remote_code,
        **kwargs
    )

    mem_gb = sum(p.numel() * p.element_size() for p in model.parameters()) / 1e9
    print(f"Model loaded: {mem_gb:.1f} GB ({dtype})")

    return model


def estimate_memory(model_name_or_path: str) -> dict:
    """Estimate memory requirements for a model.

    Args:
        model_name_or_path: HuggingFace model name

    Returns:
        Dict with memory estimates for different configurations
    """
    try:
        from transformers import AutoConfig
        config = AutoConfig.from_pretrained(model_name_or_path)
    except:
        return {"error": "Could not load model config"}

    # Estimate parameter count
    # This is approximate - actual count depends on model architecture
    if hasattr(config, 'num_parameters'):
        params = config.num_parameters
    elif hasattr(config, 'n_params'):
        params = config.n_params
    else:
        # Rough estimate for transformer models
        hidden = getattr(config, 'hidden_size', getattr(config, 'n_embd', 768))
        layers = getattr(config, 'num_hidden_layers', getattr(config, 'n_layer', 12))
        vocab = getattr(config, 'vocab_size', 50257)
        # Rough formula: embeddings + layers * (4 * hidden^2)
        params = vocab * hidden + layers * 4 * hidden * hidden

    return {
        "estimated_params": params,
        "fp32_gb": params * 4 / 1e9,
        "fp16_gb": params * 2 / 1e9,
        "int8_gb": params * 1 / 1e9,
        "adamw_optimizer_gb": params * 8 / 1e9,  # m + v states
        "axiom_optimizer_mb": params / 128 * 3 / 1e6,  # ~0.023 bytes/param
        "recommendation": "int8" if params > 1e9 else "fp16",
    }
