# Project Report: clawagents

## Dependencies

* openai
* google-genai
* fastapi
* uvicorn
* python-dotenv
* pydantic