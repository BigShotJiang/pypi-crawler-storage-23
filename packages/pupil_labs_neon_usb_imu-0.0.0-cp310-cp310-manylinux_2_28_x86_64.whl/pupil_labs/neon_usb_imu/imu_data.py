import datetime
from typing import NamedTuple


class Data3D(NamedTuple):
    """3D data point with x, y, z coordinates."""

    x: float
    y: float
    z: float


class Quaternion(NamedTuple):
    """Quaternion data point with x, y, z, w coordinates."""

    x: float
    y: float
    z: float
    w: float


class IMUData(NamedTuple):
    """Data from the Inertial Measurement Unit (IMU).

    Contains gyroscope, accelerometer, and rotation data from the IMU sensor.
    """

    gyro_data: Data3D
    """Gyroscope data in deg/s."""
    accel_data: Data3D
    """Accelerometer data in m/s²."""
    quaternion: Quaternion
    """ Rotation represented as a quaternion."""
    timestamp_unix_seconds: float
    """Timestamp in seconds since Unix epoch."""

    @property
    def datetime(self) -> datetime.datetime:
        """Get timestamp as a datetime object."""
        return datetime.datetime.fromtimestamp(self.timestamp_unix_seconds)

    @property
    def timestamp_unix_ns(self) -> int:
        """Get timestamp in nanoseconds since Unix epoch."""
        return int(self.timestamp_unix_seconds * 1e9)
