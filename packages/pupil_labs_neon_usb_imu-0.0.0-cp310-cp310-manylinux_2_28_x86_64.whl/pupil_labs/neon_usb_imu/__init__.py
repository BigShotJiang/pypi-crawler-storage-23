from __future__ import annotations

import importlib.metadata

from .imu_data import Data3D, IMUData, Quaternion
from .neon_usb_imu import NeonUsbImu

try:
    __version__ = importlib.metadata.version(__name__)
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"


__all__ = ["Data3D", "IMUData", "NeonUsbImu", "Quaternion", "__version__"]
