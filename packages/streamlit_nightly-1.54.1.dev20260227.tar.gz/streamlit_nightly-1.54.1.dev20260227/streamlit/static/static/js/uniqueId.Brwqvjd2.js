import{I as i}from"./index.B7bjyXjG.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
