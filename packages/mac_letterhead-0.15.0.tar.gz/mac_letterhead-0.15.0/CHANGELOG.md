# [0.15.0](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.3...v0.15.0) (2026-03-01)


### Bug Fixes

* correct DXT manifest and build toolchain for mcpb packer ([2159ad7](https://github.com/easytocloud/Mac-letterhead/commit/2159ad756ee138acf41d752c3b03e368ac4b6fd8))


### Features

* add Desktop Extension (DXT) for one-click Claude installation ([d42104b](https://github.com/easytocloud/Mac-letterhead/commit/d42104b5928e53592cd18795afa7778edd9ba203))

## [0.14.3](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.2...v0.14.3) (2026-03-01)


### Bug Fixes

* pin cryptography>=46.0.5 to address subgroup attack vulnerability ([a6d26e3](https://github.com/easytocloud/Mac-letterhead/commit/a6d26e3c59c5cf8c309ecb75d489785196fdd981))

## [0.14.2](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.1...v0.14.2) (2026-03-01)


### Bug Fixes

* resolve remaining security vulnerabilities in transitive dependencies ([7348802](https://github.com/easytocloud/Mac-letterhead/commit/7348802a61886cb2cc220383e7e1296f7aa27fad))

## [0.14.1](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.0...v0.14.1) (2026-03-01)


### Bug Fixes

* upgrade dependencies to address security vulnerabilities ([ee95775](https://github.com/easytocloud/Mac-letterhead/commit/ee95775289f5a57f433d8a893eef6838a1d1cdb7))

# [0.14.0](https://github.com/easytocloud/Mac-letterhead/compare/v0.13.9...v0.14.0) (2025-10-12)


### Features

* publish Mac-letterhead to MCP Registry ([35325c5](https://github.com/easytocloud/Mac-letterhead/commit/35325c5a1feda4a39af62ae248defc941585c571))

# Changelog

All notable changes to this project will be managed automatically by semantic-release.
