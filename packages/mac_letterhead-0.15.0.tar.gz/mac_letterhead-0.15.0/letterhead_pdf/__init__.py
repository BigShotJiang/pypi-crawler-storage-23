"""Letterhead PDF merger for macOS with AppleScript droplet interface"""

__version__ = "0.15.0"
