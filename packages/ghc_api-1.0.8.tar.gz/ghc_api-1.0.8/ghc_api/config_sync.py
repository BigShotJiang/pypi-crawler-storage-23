"""
Config sync and backup helpers for Claude Code, Codex, and ghc-api.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import socket
import hashlib
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

from .utils import get_config_dir


TOOL_INSTALL_COMMANDS = {
    "codex": ["npm", "install", "-g", "@openai/codex"],
    "claude": ["npm", "install", "-g", "@anthropic-ai/claude-code"],
    "copilot-cli": ["npm", "install", "-g", "@github/copilot"],
}


@dataclass(frozen=True)
class ConfigEntry:
    key: str
    local_path: Path
    sync_filename: str


def _is_wsl() -> bool:
    return bool(os.environ.get("WSL_DISTRO_NAME")) or "microsoft" in platform.release().lower()


def _resolve_windows_user_homes_from_wsl() -> list[Path]:
    users_root = Path("/mnt/c/Users")
    if not users_root.exists():
        return []

    preferred_names = [name for name in [os.environ.get("USER"), os.environ.get("USERNAME")] if name]
    candidates = [p for p in users_root.iterdir() if p.is_dir()]
    preferred: list[Path] = []
    other: list[Path] = []
    for preferred in preferred_names:
        for candidate in candidates:
            if candidate.name.lower() == preferred.lower():
                preferred.append(candidate)
    preferred_set = {p.resolve() for p in preferred}
    for candidate in candidates:
        if candidate.resolve() not in preferred_set:
            other.append(candidate)
    return preferred + other


def get_onedrive_path() -> Optional[Path]:
    """Locate OneDrive root, preferring 'OneDrive - *' over 'OneDrive'."""
    if _is_wsl():
        base_homes = _resolve_windows_user_homes_from_wsl()
    else:
        base_homes = [Path.home()]

    for base_home in base_homes:
        if not base_home.exists():
            continue

        prefixed = sorted([p for p in base_home.glob("OneDrive - *") if p.is_dir()], key=lambda p: p.name.lower())
        plain = base_home / "OneDrive"

        if prefixed:
            return prefixed[0]
        if plain.is_dir():
            return plain
    return None


def get_sync_root() -> Optional[Path]:
    onedrive = get_onedrive_path()
    if not onedrive:
        return None
    return onedrive / ".ghc-api" / "configSync"


def _os_label() -> str:
    if _is_wsl():
        return "WSL"
    if platform.system() == "Windows":
        return "Win"
    return "Linux"


def get_agent_root() -> Optional[Path]:
    onedrive = get_onedrive_path()
    if not onedrive:
        return None
    host = socket.gethostname()
    return onedrive / ".ghc-api" / "agents" / f"{host}_{_os_label()}"


def _backup_file(path: Path) -> Optional[Path]:
    if not path.exists():
        return None
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = path.with_name(f"{path.name}.{timestamp}.bak")
    shutil.copy2(path, backup_path)
    return backup_path


def _read_bytes(path: Path) -> Optional[bytes]:
    if not path.exists() or not path.is_file():
        return None
    return path.read_bytes()


def _config_hash_text() -> str:
    entries = get_config_entries()
    sha1 = hashlib.sha1()
    for key in ["ghc-api", "claude", "codex"]:
        entry = entries[key]
        sha1.update(f"[{key}]".encode("utf-8"))
        if entry.local_path.exists():
            sha1.update(entry.local_path.read_bytes())
        else:
            sha1.update(b"<missing>")
    return sha1.hexdigest()


def _latest_local_config_mtime(entries: Dict[str, ConfigEntry]) -> Optional[float]:
    mtimes: list[float] = []
    for entry in entries.values():
        if entry.local_path.exists():
            mtimes.append(entry.local_path.stat().st_mtime)
    return max(mtimes) if mtimes else None


def _write_hash_file_if_stale(path: Path, latest_mtime: Optional[float]) -> tuple[bool, Optional[str]]:
    needs_refresh = not path.exists()
    if not needs_refresh and latest_mtime is not None:
        needs_refresh = latest_mtime > path.stat().st_mtime
    if not needs_refresh:
        return False, None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_config_hash_text(), encoding="utf-8")
        return True, None
    except Exception as e:
        return False, str(e)


def refresh_config_hash_files() -> Dict[str, object]:
    sync_root = get_sync_root()
    agent_root = get_agent_root()
    entries = get_config_entries()
    latest_mtime = _latest_local_config_mtime(entries)

    refreshed_paths: list[str] = []
    errors: list[str] = []
    hash_paths: Dict[str, Optional[str]] = {
        "config_sync_hash": None,
        "agent_hash": None,
    }

    if sync_root:
        sync_hash = sync_root / "config.sha1"
        hash_paths["config_sync_hash"] = str(sync_hash)
        refreshed, error = _write_hash_file_if_stale(sync_hash, latest_mtime)
        if refreshed:
            refreshed_paths.append(str(sync_hash))
        if error:
            errors.append(f"{sync_hash}: {error}")

    if agent_root:
        agent_hash = agent_root / "config.sha1"
        hash_paths["agent_hash"] = str(agent_hash)
        refreshed, error = _write_hash_file_if_stale(agent_hash, latest_mtime)
        if refreshed:
            refreshed_paths.append(str(agent_hash))
        if error:
            errors.append(f"{agent_hash}: {error}")

    return {
        "hash_paths": hash_paths,
        "refreshed_paths": refreshed_paths,
        "errors": errors,
    }


def get_config_entries() -> Dict[str, ConfigEntry]:
    ghc_config_dir = Path(get_config_dir())
    return {
        "claude": ConfigEntry("claude", Path.home() / ".claude" / "settings.json", "claude_settings.json"),
        "codex": ConfigEntry("codex", Path.home() / ".codex" / "config.toml", "codex_config.toml"),
        "ghc-api": ConfigEntry("ghc-api", ghc_config_dir / "config.yaml", "ghc_api_config.yaml"),
    }


def get_sync_status() -> Dict[str, object]:
    hash_refresh = refresh_config_hash_files()
    sync_root = get_sync_root()
    onedrive_path = get_onedrive_path()
    agent_root = get_agent_root()
    entries = get_config_entries()

    files: Dict[str, object] = {}
    has_sync_files = False
    has_differences = False

    for key, entry in entries.items():
        sync_path = sync_root / entry.sync_filename if sync_root else None
        local_exists = entry.local_path.exists()
        sync_exists = bool(sync_path and sync_path.exists())
        if sync_exists:
            has_sync_files = True

        different = False
        if sync_exists and local_exists:
            different = _read_bytes(sync_path) != _read_bytes(entry.local_path)
        elif sync_exists != local_exists:
            different = True

        if different:
            has_differences = True

        files[key] = {
            "local_path": str(entry.local_path),
            "sync_path": str(sync_path) if sync_path else None,
            "local_exists": local_exists,
            "sync_exists": sync_exists,
            "different": different,
        }

    return {
        "onedrive_path": str(onedrive_path) if onedrive_path else None,
        "sync_root": str(sync_root) if sync_root else None,
        "agent_root": str(agent_root) if agent_root else None,
        "has_sync_files": has_sync_files,
        "has_differences": has_differences,
        "files": files,
        "hash_paths": hash_refresh["hash_paths"],
        "hash_refreshed": hash_refresh["refreshed_paths"],
        "hash_errors": hash_refresh["errors"],
    }


def print_sync_diff_status() -> Dict[str, object]:
    status = get_sync_status()
    if status.get("hash_errors"):
        for err in status["hash_errors"]:
            print(f"[Config Sync] Failed to update hash file: {err}")
    if not status["onedrive_path"]:
        print("[Config Sync] OneDrive path not found.")
        return status

    if not status["has_sync_files"]:
        print(f"[Config Sync] No synced config files found in {status['sync_root']}.")
        return status

    if status["has_differences"]:
        print("[Config Sync] Local config differs from synced config:")
        for key, file_status in status["files"].items():
            if file_status["different"]:
                print(f"  - {key}: local={file_status['local_path']} sync={file_status['sync_path']}")
    else:
        print("[Config Sync] Local config matches synced config.")
    return status


def sync_local_to_onedrive() -> Dict[str, object]:
    sync_root = get_sync_root()
    if not sync_root:
        return {"ok": False, "error": "OneDrive path not found."}

    sync_root.mkdir(parents=True, exist_ok=True)
    entries = get_config_entries()
    copied: Dict[str, str] = {}
    skipped: Dict[str, str] = {}

    for key, entry in entries.items():
        if not entry.local_path.exists():
            skipped[key] = "Local config file not found."
            continue
        target = sync_root / entry.sync_filename
        shutil.copy2(entry.local_path, target)
        copied[key] = str(target)

    return {
        "ok": True,
        "sync_root": str(sync_root),
        "copied": copied,
        "skipped": skipped,
        "status": get_sync_status(),
    }


def sync_onedrive_to_local() -> Dict[str, object]:
    sync_root = get_sync_root()
    if not sync_root:
        return {"ok": False, "error": "OneDrive path not found."}
    if not sync_root.exists():
        return {"ok": False, "error": f"Sync folder not found: {sync_root}"}

    entries = get_config_entries()
    restored: Dict[str, str] = {}
    skipped: Dict[str, str] = {}
    backups: Dict[str, str] = {}

    for key, entry in entries.items():
        source = sync_root / entry.sync_filename
        if not source.exists():
            skipped[key] = "Synced file not found."
            continue

        entry.local_path.parent.mkdir(parents=True, exist_ok=True)
        backup_path = _backup_file(entry.local_path)
        if backup_path:
            backups[key] = str(backup_path)

        shutil.copy2(source, entry.local_path)
        restored[key] = str(entry.local_path)

    return {
        "ok": True,
        "sync_root": str(sync_root),
        "restored": restored,
        "skipped": skipped,
        "backups": backups,
        "status": get_sync_status(),
    }


def install_code_agents() -> Dict[str, object]:
    entries = get_config_entries()
    backups: Dict[str, str] = {}

    # Back up target config files first, before any install command may modify them.
    for key in ["claude", "codex"]:
        backup = _backup_file(entries[key].local_path)
        if backup:
            backups[key] = str(backup)

    command_results: Dict[str, object] = {}
    failures = 0

    for tool_name, command in TOOL_INSTALL_COMMANDS.items():
        try:
            proc = subprocess.run(command, capture_output=True, text=True, check=False)
            command_results[tool_name] = {
                "command": " ".join(command),
                "returncode": proc.returncode,
                "stdout": proc.stdout[-4000:],
                "stderr": proc.stderr[-4000:],
            }
            if proc.returncode != 0:
                failures += 1
        except Exception as e:
            failures += 1
            command_results[tool_name] = {
                "command": " ".join(command),
                "returncode": -1,
                "stdout": "",
                "stderr": str(e),
            }

    return {
        "ok": failures == 0,
        "backups": backups,
        "results": command_results,
    }
