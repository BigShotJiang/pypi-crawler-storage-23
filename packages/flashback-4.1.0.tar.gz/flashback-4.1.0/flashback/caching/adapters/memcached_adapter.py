from collections.abc import Sequence
import typing as t

from pymemcache.client.base import Client, check_key_helper
from pymemcache.exceptions import *  # noqa: F403
from pymemcache.exceptions import MemcacheUnexpectedCloseError, MemcacheServerError, MemcacheUnknownError

from .base import BaseAdapter


class MemcachedAdapter(BaseAdapter):
    """
    Exposes a cache store using Memcached.

    Exposes `pymemcache`'s exceptions.
    """

    def __init__(self, host: str = "localhost", port: int = 11211, **kwargs: t.Any) -> None:
        self.store = Client((host, port), **kwargs)

    def set(self, key: str, value: t.Any, ttl: int) -> bool:
        if ttl == -1:
            ttl = 0

        result = self.store.set(key, value, expire=ttl)

        # Returns True if True, but False if False or None
        return result is True

    def batch_set(self, keys: Sequence[str], values: Sequence[t.Any], ttls: Sequence[int]) -> bool:
        # There's two reasons to recode pymemcache.set_many():
        # - It returns a list of keys that failed to be inserted, and the base expects a boolean
        # - It only allows a unique ttl for all keys
        commands = []

        ttls = [0 if ttl == -1 else ttl for ttl in ttls]
        for key, value, ttl in zip(keys, values, ttls):
            stored_ttl = self.store._check_integer(ttl, "expire")  # noqa: SLF001
            stored_key = check_key_helper(key, self.store.allow_unicode_keys)
            stored_value, stored_flags = self.store.serde.serialize(key, value)

            command = b"set " + stored_key
            command += b" " + str(stored_flags).encode(self.store.encoding)
            command += b" " + stored_ttl
            command += b" " + str(len(stored_value)).encode(self.store.encoding) + b"\r\n"
            command += stored_value.encode(self.store.encoding) + b"\r\n"
            commands.append(command)

        results = self.store._misc_cmd(commands, b"set", False)  # noqa: SLF001

        return all(line != b"NOT_STORED" for line in results)

    def get(self, key: str) -> t.Any | None:
        return self.store.get(key)

    def batch_get(self, keys: Sequence[str]) -> Sequence[t.Any | None]:
        key_to_value = self.store.get_many(keys)
        return [key_to_value.get(key, None) for key in keys]

    def delete(self, key: str) -> bool:
        return self.store.delete(key, noreply=False)

    def batch_delete(self, keys: Sequence[str]) -> bool:
        # Here as well, pymemcache.delete_many() always returns True
        commands = []

        for key in keys:
            stored_key = check_key_helper(key, self.store.allow_unicode_keys)

            command = b"delete " + stored_key + b"\r\n"
            commands.append(command)

        results = self.store._misc_cmd(commands, b"delete", False)  # noqa: SLF001

        return all(line != b"NOT_FOUND" for line in results)

    def exists(self, key: str) -> bool:
        # Can't just cast to bool since we can store falsey values
        return self.store.get(key) is not None

    def flush(self) -> bool:
        return self.store.flush_all(noreply=False)

    def ping(self) -> bool:
        return bool(self.store.stats())

    @property
    def connection_exceptions(self) -> tuple[type[Exception], ...]:
        return (MemcacheUnexpectedCloseError, MemcacheServerError, MemcacheUnknownError)
