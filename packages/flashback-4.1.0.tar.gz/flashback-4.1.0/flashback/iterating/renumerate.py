from collections.abc import Iterator, Reversible, Sized
import typing as t


class SizedReversible[T](t.Protocol, Sized, Reversible[T]):
    pass


def renumerate[T](iterable: SizedReversible[T]) -> Iterator[tuple[int, T]]:
    """
    Enumerates an `iterable` starting from the end.

    Examples:
        ```python
        from flashback.iterating import renumerate

        # Drop-in replacement for enumerate()
        lst = ["a", "b", "c"]
        for index, item in renumerate(lst):
            print(index, item)
        #=> 2 "c"
        #=> 1 "b"
        #=> 0 "a"

        # Still returns an iterator
        iter = renumerate(lst)
        assert next(iter) == (2, "c")
        ```

    Params:
        iterable: the list to reverse and enumerate

    Returns:
        the iterator containing the reversed enumeration
    """
    return zip(range(len(iterable) - 1, -1, -1), reversed(iterable))
