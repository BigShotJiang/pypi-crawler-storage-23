from . import command, conf
from .command import rm
