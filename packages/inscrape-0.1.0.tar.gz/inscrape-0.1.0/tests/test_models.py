"""Tests for inscrape.models."""

import json
import pytest

from inscrape.models import (
    AuthError,
    ConnectionError,
    InscrapeError,
    QuotaExhaustedError,
    RateLimitError,
    ScrapeFailedError,
    ScrapeResult,
)


# ---------------------------------------------------------------------------
# ScrapeResult
# ---------------------------------------------------------------------------

class TestScrapeResult:
    def test_basic_creation(self):
        r = ScrapeResult(
            content="<html>hello</html>",
            status_code=200,
            content_type="text/html",
        )
        assert r.content == "<html>hello</html>"
        assert r.status_code == 200
        assert r.content_type == "text/html"
        assert r.credits_used is None
        assert r.latency_ms is None
        assert r.headers == {}

    def test_json_parsing(self):
        data = {"username": "test", "followers": 100}
        r = ScrapeResult(
            content=json.dumps(data),
            status_code=200,
            content_type="application/json",
        )
        parsed = r.json()
        assert parsed == data
        assert parsed["followers"] == 100

    def test_json_invalid_raises(self):
        r = ScrapeResult(content="not json", status_code=200, content_type="text/html")
        with pytest.raises(json.JSONDecodeError):
            r.json()

    def test_repr_truncation(self):
        long_content = "x" * 200
        r = ScrapeResult(content=long_content, status_code=200, content_type="text/html")
        repr_str = repr(r)
        assert "..." in repr_str
        assert "length=200" in repr_str

    def test_repr_short_content(self):
        r = ScrapeResult(content="short", status_code=200, content_type="text/html")
        repr_str = repr(r)
        assert "short" in repr_str

    def test_with_all_fields(self):
        r = ScrapeResult(
            content="data",
            status_code=200,
            content_type="text/plain",
            headers={"x-custom": "val"},
            credits_used=5,
            latency_ms=123.45,
        )
        assert r.credits_used == 5
        assert r.latency_ms == 123.45
        assert r.headers["x-custom"] == "val"


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class TestExceptions:
    def test_inscrape_error_basic(self):
        e = InscrapeError("something broke")
        assert str(e) == "something broke"
        assert e.message == "something broke"
        assert e.code is None
        assert e.status_code is None

    def test_inscrape_error_full(self):
        e = InscrapeError(
            message="rate limited",
            code="RATE_LIMITED",
            status_code=429,
            retry_after=30,
            request_id="req_abc",
        )
        assert e.code == "RATE_LIMITED"
        assert e.status_code == 429
        assert e.retry_after == 30
        assert e.request_id == "req_abc"

    def test_inscrape_error_repr(self):
        e = InscrapeError("fail", code="ERR", status_code=500, retry_after=10)
        repr_str = repr(e)
        assert "ERR" in repr_str
        assert "500" in repr_str
        assert "10s" in repr_str

    def test_auth_error_is_inscrape_error(self):
        e = AuthError("bad token", status_code=401)
        assert isinstance(e, InscrapeError)
        assert e.status_code == 401

    def test_rate_limit_error_is_inscrape_error(self):
        e = RateLimitError("slow down", retry_after=60)
        assert isinstance(e, InscrapeError)
        assert e.retry_after == 60

    def test_quota_exhausted_error(self):
        e = QuotaExhaustedError("quota used", code="QUOTA_EXHAUSTED", status_code=402)
        assert isinstance(e, InscrapeError)
        assert e.code == "QUOTA_EXHAUSTED"

    def test_scrape_failed_error(self):
        e = ScrapeFailedError("target down", status_code=500)
        assert isinstance(e, InscrapeError)

    def test_connection_error(self):
        e = ConnectionError("cannot connect", code="CONNECTION_ERROR")
        assert isinstance(e, InscrapeError)
        assert e.code == "CONNECTION_ERROR"

    def test_exception_hierarchy_catch_all(self):
        """All specific errors should be catchable as InscrapeError."""
        errors = [
            AuthError("a"),
            RateLimitError("b"),
            QuotaExhaustedError("c"),
            ScrapeFailedError("d"),
            ConnectionError("e"),
        ]
        for e in errors:
            with pytest.raises(InscrapeError):
                raise e
