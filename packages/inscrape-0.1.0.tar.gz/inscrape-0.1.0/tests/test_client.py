"""Tests for inscrape.client (sync Inscrape + async AsyncInscrape)."""

import json
import base64
import urllib.parse

import httpx
import pytest
import respx

from inscrape import (
    AsyncInscrape,
    AuthError,
    Inscrape,
    QuotaExhaustedError,
    RateLimitError,
    ScrapeFailedError,
    ScrapeResult,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

TEST_TOKEN = "sk_test_abcdef1234567890"
TEST_BASE = "https://mock-api.inscrape.io"


@pytest.fixture
def client():
    c = Inscrape(TEST_TOKEN, base_url=TEST_BASE, max_retries=0)
    yield c
    c.close()


@pytest.fixture
def async_client():
    return AsyncInscrape(TEST_TOKEN, base_url=TEST_BASE, max_retries=0)


# ---------------------------------------------------------------------------
# Sync Client: Inscrape
# ---------------------------------------------------------------------------

class TestInscrapeInit:
    def test_valid_token(self):
        c = Inscrape("sk_valid_token")
        assert "sk_val" in repr(c)
        c.close()

    def test_empty_token_raises(self):
        with pytest.raises(ValueError, match="token is required"):
            Inscrape("")

    def test_whitespace_token_raises(self):
        with pytest.raises(ValueError, match="token is required"):
            Inscrape("   ")

    def test_repr_masks_token(self):
        c = Inscrape("sk_abcdefghij1234567890")
        repr_str = repr(c)
        assert "sk_abc" in repr_str
        assert "7890" in repr_str
        assert "abcdefghij1234567890" not in repr_str
        c.close()

    def test_context_manager(self):
        with Inscrape("sk_test_token") as c:
            assert isinstance(c, Inscrape)


class TestScrape:
    @respx.mock
    def test_basic_scrape(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="<html>Hello</html>", headers={"content-type": "text/html"})
        )
        result = client.scrape("https://example.com")
        assert isinstance(result, ScrapeResult)
        assert result.content == "<html>Hello</html>"
        assert result.status_code == 200
        assert "text/html" in result.content_type

    @respx.mock
    def test_scrape_sends_token(self, client):
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="ok")
        )
        client.scrape("https://example.com")
        assert route.called
        request = route.calls[0].request
        assert f"token={TEST_TOKEN}" in str(request.url)

    @respx.mock
    def test_scrape_snake_case_params(self, client):
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="ok")
        )
        client.scrape(
            "https://example.com",
            render=True,
            super_proxy=True,
            geo_code="IN",
            wait_selector="div.main",
            block_resources=True,
        )
        url_str = str(route.calls[0].request.url)
        assert "render=true" in url_str
        assert "super=true" in url_str
        assert "geoCode=IN" in url_str
        assert "waitSelector=div.main" in url_str
        assert "blockResources=true" in url_str

    @respx.mock
    def test_scrape_with_credits_header(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(
                200,
                text="data",
                headers={"x-inscrape-credits-used": "50"},
            )
        )
        result = client.scrape("https://example.com", render=True, super_proxy=True)
        assert result.credits_used == 50

    @respx.mock
    def test_scrape_latency_tracked(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="ok")
        )
        result = client.scrape("https://example.com")
        assert result.latency_ms is not None
        assert result.latency_ms >= 0


class TestConvenienceMethods:
    @respx.mock
    def test_instagram(self, client):
        profile = {"username": "test", "followers": 1000, "bio": "Hello"}
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(
                200,
                text=json.dumps(profile),
                headers={"content-type": "application/json"},
            )
        )
        result = client.instagram("test")
        assert result == profile
        assert result["followers"] == 1000

        url_str = str(route.calls[0].request.url)
        assert "render=true" in url_str
        assert "super=true" in url_str
        assert "output=json" in url_str
        assert "instagram.com" in url_str

    @respx.mock
    def test_instagram_strips_at(self, client):
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="{}")
        )
        client.instagram("@gkhetawat1")
        url_str = urllib.parse.unquote(str(route.calls[0].request.url))
        assert "instagram.com/gkhetawat1/" in url_str
        assert "@" not in url_str.split("instagram.com")[1].split("&")[0]

    @respx.mock
    def test_twitter(self, client):
        user = {"username": "test", "name": "Test User", "followers": 500}
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text=json.dumps(user))
        )
        result = client.twitter("test")
        assert result["name"] == "Test User"

        url_str = urllib.parse.unquote(str(route.calls[0].request.url))
        assert "x.com/test" in url_str
        assert "render=true" in url_str
        assert "super=true" in url_str
        assert "output=json" in url_str
        assert "waitSelector" in url_str

    @respx.mock
    def test_screenshot_full_page(self, client):
        png_data = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100
        encoded = base64.b64encode(png_data).decode()
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text=encoded, headers={"content-type": "image/png"})
        )
        result = client.screenshot("https://example.com")
        assert isinstance(result, bytes)
        assert result == png_data

        url_str = str(route.calls[0].request.url)
        assert "fullScreenShot=true" in url_str
        assert "render=true" in url_str

    @respx.mock
    def test_screenshot_viewport(self, client):
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text=base64.b64encode(b"png").decode())
        )
        client.screenshot("https://example.com", full_page=False)
        url_str = str(route.calls[0].request.url)
        assert "screenShot=true" in url_str
        assert "fullScreenShot" not in url_str

    @respx.mock
    def test_screenshot_selector(self, client):
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text=base64.b64encode(b"png").decode())
        )
        client.screenshot("https://example.com", selector="div.hero")
        url_str = str(route.calls[0].request.url)
        assert "particularScreenShot" in url_str

    @respx.mock
    def test_markdown(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="# Hello\n\nWorld")
        )
        result = client.markdown("https://example.com")
        assert isinstance(result, str)
        assert "# Hello" in result

    @respx.mock
    def test_estimate(self, client):
        respx.get(f"{TEST_BASE}/estimate").mock(
            return_value=httpx.Response(
                200,
                json={"estimated_credits": 50, "message": "Pay only on success"},
            )
        )
        result = client.estimate("https://example.com", render=True, super_proxy=True)
        assert result["estimated_credits"] == 50


class TestErrorHandling:
    @respx.mock
    def test_401_raises_auth_error(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(
                401,
                json={"error": {"code": "INVALID_TOKEN", "message": "Bad token"}},
            )
        )
        with pytest.raises(AuthError) as exc_info:
            client.scrape("https://example.com")
        assert exc_info.value.status_code == 401
        assert exc_info.value.code == "INVALID_TOKEN"

    @respx.mock
    def test_402_raises_quota_error(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(
                402,
                json={"error": {"code": "QUOTA_EXHAUSTED", "message": "Quota used up"}},
            )
        )
        with pytest.raises(QuotaExhaustedError):
            client.scrape("https://example.com")

    @respx.mock
    def test_429_raises_rate_limit_error(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(
                429,
                json={"error": {"code": "RATE_LIMITED", "message": "Too fast", "retry_after": 30}},
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            client.scrape("https://example.com")
        assert exc_info.value.retry_after == 30

    @respx.mock
    def test_429_reads_retry_after_header(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(
                429,
                json={"error": {"code": "RATE_LIMITED", "message": "Too fast"}},
                headers={"Retry-After": "45"},
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            client.scrape("https://example.com")
        assert exc_info.value.retry_after == 45

    @respx.mock
    def test_500_raises_scrape_failed(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(
                500,
                json={"error": {"code": "SCRAPE_FAILED", "message": "Target unreachable"}},
            )
        )
        with pytest.raises(ScrapeFailedError):
            client.scrape("https://example.com")

    @respx.mock
    def test_non_json_error_body(self, client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(401, text="Unauthorized")
        )
        with pytest.raises(AuthError) as exc_info:
            client.scrape("https://example.com")
        assert "Unauthorized" in exc_info.value.message


class TestRetries:
    @respx.mock
    def test_retries_on_500(self):
        c = Inscrape(TEST_TOKEN, base_url=TEST_BASE, max_retries=2)
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            side_effect=[
                httpx.Response(500, json={"error": {"message": "fail"}}),
                httpx.Response(500, json={"error": {"message": "fail"}}),
                httpx.Response(200, text="success"),
            ]
        )
        result = c.scrape("https://example.com")
        assert result.content == "success"
        assert route.call_count == 3
        c.close()

    @respx.mock
    def test_no_retry_on_401(self):
        c = Inscrape(TEST_TOKEN, base_url=TEST_BASE, max_retries=2)
        route = respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(401, json={"error": {"message": "bad token"}})
        )
        with pytest.raises(AuthError):
            c.scrape("https://example.com")
        assert route.call_count == 1
        c.close()

    @respx.mock
    def test_max_retries_exhausted(self):
        c = Inscrape(TEST_TOKEN, base_url=TEST_BASE, max_retries=1)
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(500, json={"error": {"message": "always fail"}})
        )
        with pytest.raises(ScrapeFailedError):
            c.scrape("https://example.com")
        c.close()


# ---------------------------------------------------------------------------
# Async Client: AsyncInscrape
# ---------------------------------------------------------------------------

class TestAsyncInscrape:
    @respx.mock
    @pytest.mark.asyncio
    async def test_async_scrape(self, async_client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="async hello")
        )
        result = await async_client.scrape("https://example.com")
        assert result.content == "async hello"
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_instagram(self, async_client):
        profile = {"username": "test", "followers": 42}
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text=json.dumps(profile))
        )
        result = await async_client.instagram("test")
        assert result["followers"] == 42
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_twitter(self, async_client):
        user = {"username": "test", "name": "Tester"}
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text=json.dumps(user))
        )
        result = await async_client.twitter("test")
        assert result["name"] == "Tester"
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="ctx")
        )
        async with AsyncInscrape(TEST_TOKEN, base_url=TEST_BASE, max_retries=0) as c:
            result = await c.scrape("https://example.com")
            assert result.content == "ctx"

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_error_handling(self, async_client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(
                401,
                json={"error": {"code": "INVALID_TOKEN", "message": "bad"}},
            )
        )
        with pytest.raises(AuthError):
            await async_client.scrape("https://example.com")
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_markdown(self, async_client):
        respx.get(f"{TEST_BASE}/scrape").mock(
            return_value=httpx.Response(200, text="# Title\nBody")
        )
        result = await async_client.markdown("https://example.com")
        assert "# Title" in result
        await async_client.close()
