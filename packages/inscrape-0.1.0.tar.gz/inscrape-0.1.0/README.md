# inscrape

The official Python SDK for **[Inscrape](https://inscrape.io)** — the AI-first web scraping API for Instagram, X & beyond.

[![PyPI](https://img.shields.io/pypi/v/inscrape)](https://pypi.org/project/inscrape/)
[![Python](https://img.shields.io/pypi/pyversions/inscrape)](https://pypi.org/project/inscrape/)
[![License](https://img.shields.io/pypi/l/inscrape)](https://github.com/gkhetawat1/inscrape-python/blob/main/LICENSE)

## Features

- 🚀 **3-line usage** — scrape any site with one function call
- 📸 **Screenshots** — full-page or element-targeted PNG capture
- 📝 **Markdown** — get clean Markdown instead of raw HTML
- 📊 **Structured JSON** — first-class Instagram & X/Twitter profile parsing
- ⚡ **Async support** — `AsyncInscrape` for high-concurrency workflows
- 🛡️ **Smart errors** — typed exceptions for rate limits, auth, and quota

## Installation

```bash
pip install inscrape
```

For async + HTTP/2 support:

```bash
pip install "inscrape[async]"
```

## Quick Start

```python
from inscrape import Inscrape

client = Inscrape("sk_your_token_here")

# Scrape any URL
result = client.scrape("https://example.com")
print(result.content)

# Instagram profile → structured JSON
profile = client.instagram("gkhetawat1")
print(profile["followers"])

# X/Twitter profile → structured JSON
user = client.twitter("elonmusk")
print(user["bio"])

# Full-page screenshot → PNG bytes
png = client.screenshot("https://example.com")
with open("screenshot.png", "wb") as f:
    f.write(png)

# Get Markdown
md = client.markdown("https://example.com")
print(md)
```

## Async Usage

```python
import asyncio
from inscrape import AsyncInscrape

async def main():
    client = AsyncInscrape("sk_your_token_here")

    # All methods are async
    profile = await client.instagram("gkhetawat1")
    print(profile)

    # Concurrent scraping
    results = await asyncio.gather(
        client.scrape("https://example.com"),
        client.scrape("https://httpbin.org/get"),
        client.twitter("naval"),
    )
    for r in results:
        print(r)

    await client.close()

asyncio.run(main())
```

## API Reference

### `Inscrape(token, base_url="https://api.inscrape.io")`

Create a client instance.

### `client.scrape(url, **kwargs) → ScrapeResult`

Full-parameter scrape. Pass any Inscrape API parameter as a keyword argument:

```python
result = client.scrape(
    "https://example.com",
    render=True,
    super_proxy=True,      # maps to super=true
    geo_code="IN",         # maps to geoCode=IN
    wait_selector="div.content",
    block_resources=True,
    timeout=30000,
)
print(result.content)
print(result.status_code)
print(result.credits_used)
```

### `client.instagram(username, **kwargs) → dict`

Shortcut for Instagram profiles. Automatically sets `render=True`, `super=True`, `output=json`.

### `client.twitter(username, **kwargs) → dict`

Shortcut for X/Twitter profiles. Same smart defaults.

### `client.screenshot(url, full_page=True, **kwargs) → bytes`

Returns decoded PNG bytes.

### `client.markdown(url, **kwargs) → str`

Returns clean Markdown text.

### `client.estimate(url, **kwargs) → dict`

Get estimated credit cost before scraping.

## Error Handling

```python
from inscrape import Inscrape, AuthError, RateLimitError, QuotaExhaustedError, InscrapeError

client = Inscrape("sk_xxx")

try:
    result = client.scrape("https://example.com")
except AuthError:
    print("Invalid API token")
except RateLimitError as e:
    print(f"Rate limited — retry after {e.retry_after}s")
except QuotaExhaustedError:
    print("Monthly quota used up — upgrade your plan")
except InscrapeError as e:
    print(f"Scrape failed: {e.message} (code: {e.code})")
```

## License

MIT
