"""Inscrape SDK — Sync and Async HTTP clients."""

from __future__ import annotations

import base64
import time
from typing import Any, Dict, Optional

import httpx

from .constants import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    PARAM_MAP,
    RETRY_BACKOFF_FACTOR,
    SDK_USER_AGENT,
)
from .models import (
    AuthError,
    ConnectionError,
    InscrapeError,
    QuotaExhaustedError,
    RateLimitError,
    ScrapeFailedError,
    ScrapeResult,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _map_params(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Convert Python snake_case kwargs to Inscrape API camelCase query params."""
    mapped: Dict[str, Any] = {}
    for key, value in kwargs.items():
        if value is None:
            continue
        api_key = PARAM_MAP.get(key, key)
        # Convert booleans to lowercase strings for query params
        if isinstance(value, bool):
            mapped[api_key] = str(value).lower()
        else:
            mapped[api_key] = value
    return mapped


def _extract_error(response: httpx.Response) -> InscrapeError:
    """Parse an error response into the appropriate exception type."""
    code = None
    message = f"HTTP {response.status_code}"
    retry_after = None
    request_id = None

    try:
        body = response.json()
        err = body.get("error", body)
        code = err.get("code", code)
        message = err.get("message", message)
        retry_after = err.get("retry_after")
        request_id = err.get("request_id")
    except Exception:
        message = response.text[:200] if response.text else message

    error_kwargs = dict(
        message=message,
        code=code,
        status_code=response.status_code,
        retry_after=retry_after,
        request_id=request_id,
    )

    if response.status_code == 401:
        return AuthError(**error_kwargs)
    elif response.status_code == 402:
        return QuotaExhaustedError(**error_kwargs)
    elif response.status_code == 429:
        if retry_after is None:
            retry_after_header = response.headers.get("Retry-After")
            if retry_after_header:
                try:
                    error_kwargs["retry_after"] = int(retry_after_header)
                except ValueError:
                    pass
        return RateLimitError(**error_kwargs)
    elif response.status_code >= 500:
        return ScrapeFailedError(**error_kwargs)
    else:
        return InscrapeError(**error_kwargs)


def _build_result(response: httpx.Response, latency_ms: float) -> ScrapeResult:
    """Build a ScrapeResult from a successful httpx response."""
    content_type = response.headers.get("content-type", "text/html")
    credits_header = response.headers.get("x-inscrape-credits-used")
    credits_used = int(credits_header) if credits_header else None

    return ScrapeResult(
        content=response.text,
        status_code=response.status_code,
        content_type=content_type,
        headers=dict(response.headers),
        credits_used=credits_used,
        latency_ms=round(latency_ms, 2),
    )


# ---------------------------------------------------------------------------
# Sync Client
# ---------------------------------------------------------------------------

class Inscrape:
    """
    Synchronous Inscrape API client.

    Usage::

        from inscrape import Inscrape

        client = Inscrape("sk_your_token")
        result = client.scrape("https://example.com")
        print(result.content)
    """

    def __init__(
        self,
        token: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        if not token or not token.strip():
            raise ValueError("API token is required. Get one at https://inscrape.io")

        self._token = token
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.Client(
            timeout=timeout,
            headers={
                "User-Agent": SDK_USER_AGENT,
                "Accept": "application/json, text/html, */*",
            },
            follow_redirects=True,
        )

    # -- Core method --------------------------------------------------------

    def scrape(self, url: str, **kwargs: Any) -> ScrapeResult:
        """
        Scrape a URL with full parameter control.

        Args:
            url: Target URL to scrape.
            **kwargs: Any Inscrape API parameter in snake_case.
                e.g. render=True, super_proxy=True, geo_code="IN",
                     wait_selector="div.main", block_resources=True

        Returns:
            ScrapeResult with content, status_code, content_type, etc.

        Raises:
            AuthError: Invalid API token (401).
            RateLimitError: Rate limit exceeded (429).
            QuotaExhaustedError: Monthly credits used up (402).
            ScrapeFailedError: Scrape failed on target (500).
            InscrapeError: Any other API error.
        """
        params = _map_params(kwargs)
        params["token"] = self._token
        params["url"] = url

        return self._request_with_retries(params)

    # -- Convenience methods ------------------------------------------------

    def instagram(self, username: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Scrape an Instagram profile and return structured JSON.

        Args:
            username: Instagram username (without @).
            **kwargs: Additional API parameters.

        Returns:
            Dict with keys: username, full_name, bio, followers, following,
            posts_count, is_verified, profile_pic_url, etc.
        """
        username = username.lstrip("@").strip("/")
        url = f"https://www.instagram.com/{username}/"
        kwargs.setdefault("render", True)
        kwargs.setdefault("super_proxy", True)
        kwargs["output"] = "json"
        result = self.scrape(url, **kwargs)
        return result.json()

    def twitter(self, username: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Scrape an X/Twitter profile and return structured JSON.

        Args:
            username: Twitter/X username (without @).
            **kwargs: Additional API parameters.

        Returns:
            Dict with keys: username, name, bio, followers, following,
            posts_count, is_verified, profile_image_url, etc.
        """
        username = username.lstrip("@")
        url = f"https://x.com/{username}"
        kwargs.setdefault("render", True)
        kwargs.setdefault("super_proxy", True)
        kwargs.setdefault("wait_selector", '[data-testid="UserName"]')
        kwargs["output"] = "json"
        result = self.scrape(url, **kwargs)
        return result.json()

    def screenshot(
        self,
        url: str,
        *,
        full_page: bool = True,
        selector: Optional[str] = None,
        **kwargs: Any,
    ) -> bytes:
        """
        Capture a screenshot of a URL.

        Args:
            url: Target URL.
            full_page: If True, capture entire scrollable page. Default True.
            selector: CSS selector to screenshot a specific element.
            **kwargs: Additional API parameters.

        Returns:
            PNG image bytes (decoded from base64).
        """
        kwargs["render"] = True
        if selector:
            kwargs["particular_screen_shot"] = selector
        elif full_page:
            kwargs["full_screen_shot"] = True
        else:
            kwargs["screen_shot"] = True

        result = self.scrape(url, **kwargs)

        # API returns base64-encoded PNG
        try:
            return base64.b64decode(result.content)
        except Exception:
            # If content is raw bytes already
            return result.content.encode("latin-1")

    def markdown(self, url: str, **kwargs: Any) -> str:
        """
        Scrape a URL and return clean Markdown.

        Args:
            url: Target URL.
            **kwargs: Additional API parameters.

        Returns:
            Markdown text string.
        """
        kwargs["output"] = "markdown"
        result = self.scrape(url, **kwargs)
        return result.content

    def estimate(self, url: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Estimate credit cost for a scrape without executing it.

        Args:
            url: Target URL.
            **kwargs: Parameters that affect cost (render, super_proxy, screen_shot).

        Returns:
            Dict with estimated_credits and message.
        """
        params = _map_params(kwargs)
        params["url"] = url

        response = self._client.get(
            f"{self._base_url}/estimate",
            params=params,
        )
        if response.status_code != 200:
            raise _extract_error(response)
        return response.json()

    # -- Internal -----------------------------------------------------------

    def _request_with_retries(self, params: Dict[str, Any]) -> ScrapeResult:
        """Execute a request with automatic retries on transient failures."""
        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                start = time.monotonic()
                response = self._client.get(
                    f"{self._base_url}/scrape",
                    params=params,
                )
                latency_ms = (time.monotonic() - start) * 1000

                if response.status_code == 200:
                    return _build_result(response, latency_ms)

                error = _extract_error(response)

                # Don't retry client errors (except 429 with retry_after)
                if response.status_code < 500 and response.status_code != 429:
                    raise error

                # Retry on 5xx or 429
                last_error = error
                if attempt < self._max_retries:
                    backoff = RETRY_BACKOFF_FACTOR * (2 ** attempt)
                    if isinstance(error, RateLimitError) and error.retry_after:
                        backoff = max(backoff, error.retry_after)
                    time.sleep(backoff)

            except httpx.ConnectError as e:
                last_error = ConnectionError(
                    message=f"Cannot connect to Inscrape API at {self._base_url}: {e}",
                    code="CONNECTION_ERROR",
                )
                if attempt < self._max_retries:
                    time.sleep(RETRY_BACKOFF_FACTOR * (2 ** attempt))

            except httpx.TimeoutException as e:
                last_error = ConnectionError(
                    message=f"Request to Inscrape API timed out: {e}",
                    code="TIMEOUT",
                )
                if attempt < self._max_retries:
                    time.sleep(RETRY_BACKOFF_FACTOR * (2 ** attempt))

        # All retries exhausted
        if isinstance(last_error, InscrapeError):
            raise last_error
        raise InscrapeError(
            message=f"Request failed after {self._max_retries + 1} attempts: {last_error}",
            code="MAX_RETRIES_EXCEEDED",
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "Inscrape":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        masked = self._token[:6] + "..." + self._token[-4:] if len(self._token) > 10 else "***"
        return f"Inscrape(token='{masked}', base_url='{self._base_url}')"


# ---------------------------------------------------------------------------
# Async Client
# ---------------------------------------------------------------------------

class AsyncInscrape:
    """
    Asynchronous Inscrape API client.

    Usage::

        import asyncio
        from inscrape import AsyncInscrape

        async def main():
            client = AsyncInscrape("sk_your_token")
            result = await client.scrape("https://example.com")
            print(result.content)
            await client.close()

        asyncio.run(main())
    """

    def __init__(
        self,
        token: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        if not token or not token.strip():
            raise ValueError("API token is required. Get one at https://inscrape.io")

        self._token = token
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={
                "User-Agent": SDK_USER_AGENT,
                "Accept": "application/json, text/html, */*",
            },
            follow_redirects=True,
        )

    # -- Core method --------------------------------------------------------

    async def scrape(self, url: str, **kwargs: Any) -> ScrapeResult:
        """
        Scrape a URL with full parameter control (async).

        See :meth:`Inscrape.scrape` for full documentation.
        """
        params = _map_params(kwargs)
        params["token"] = self._token
        params["url"] = url

        return await self._request_with_retries(params)

    # -- Convenience methods ------------------------------------------------

    async def instagram(self, username: str, **kwargs: Any) -> Dict[str, Any]:
        """Scrape an Instagram profile → structured JSON (async)."""
        username = username.lstrip("@").strip("/")
        url = f"https://www.instagram.com/{username}/"
        kwargs.setdefault("render", True)
        kwargs.setdefault("super_proxy", True)
        kwargs["output"] = "json"
        result = await self.scrape(url, **kwargs)
        return result.json()

    async def twitter(self, username: str, **kwargs: Any) -> Dict[str, Any]:
        """Scrape an X/Twitter profile → structured JSON (async)."""
        username = username.lstrip("@")
        url = f"https://x.com/{username}"
        kwargs.setdefault("render", True)
        kwargs.setdefault("super_proxy", True)
        kwargs.setdefault("wait_selector", '[data-testid="UserName"]')
        kwargs["output"] = "json"
        result = await self.scrape(url, **kwargs)
        return result.json()

    async def screenshot(
        self,
        url: str,
        *,
        full_page: bool = True,
        selector: Optional[str] = None,
        **kwargs: Any,
    ) -> bytes:
        """Capture a screenshot (async). Returns PNG bytes."""
        kwargs["render"] = True
        if selector:
            kwargs["particular_screen_shot"] = selector
        elif full_page:
            kwargs["full_screen_shot"] = True
        else:
            kwargs["screen_shot"] = True

        result = await self.scrape(url, **kwargs)
        try:
            return base64.b64decode(result.content)
        except Exception:
            return result.content.encode("latin-1")

    async def markdown(self, url: str, **kwargs: Any) -> str:
        """Scrape a URL → clean Markdown (async)."""
        kwargs["output"] = "markdown"
        result = await self.scrape(url, **kwargs)
        return result.content

    async def estimate(self, url: str, **kwargs: Any) -> Dict[str, Any]:
        """Estimate credit cost (async)."""
        params = _map_params(kwargs)
        params["url"] = url

        response = await self._client.get(
            f"{self._base_url}/estimate",
            params=params,
        )
        if response.status_code != 200:
            raise _extract_error(response)
        return response.json()

    # -- Internal -----------------------------------------------------------

    async def _request_with_retries(self, params: Dict[str, Any]) -> ScrapeResult:
        """Execute a request with automatic retries on transient failures (async)."""
        import asyncio

        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                start = time.monotonic()
                response = await self._client.get(
                    f"{self._base_url}/scrape",
                    params=params,
                )
                latency_ms = (time.monotonic() - start) * 1000

                if response.status_code == 200:
                    return _build_result(response, latency_ms)

                error = _extract_error(response)

                if response.status_code < 500 and response.status_code != 429:
                    raise error

                last_error = error
                if attempt < self._max_retries:
                    backoff = RETRY_BACKOFF_FACTOR * (2 ** attempt)
                    if isinstance(error, RateLimitError) and error.retry_after:
                        backoff = max(backoff, error.retry_after)
                    await asyncio.sleep(backoff)

            except httpx.ConnectError as e:
                last_error = ConnectionError(
                    message=f"Cannot connect to Inscrape API at {self._base_url}: {e}",
                    code="CONNECTION_ERROR",
                )
                if attempt < self._max_retries:
                    await asyncio.sleep(RETRY_BACKOFF_FACTOR * (2 ** attempt))

            except httpx.TimeoutException as e:
                last_error = ConnectionError(
                    message=f"Request to Inscrape API timed out: {e}",
                    code="TIMEOUT",
                )
                if attempt < self._max_retries:
                    await asyncio.sleep(RETRY_BACKOFF_FACTOR * (2 ** attempt))

        if isinstance(last_error, InscrapeError):
            raise last_error
        raise InscrapeError(
            message=f"Request failed after {self._max_retries + 1} attempts: {last_error}",
            code="MAX_RETRIES_EXCEEDED",
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncInscrape":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def __repr__(self) -> str:
        masked = self._token[:6] + "..." + self._token[-4:] if len(self._token) > 10 else "***"
        return f"AsyncInscrape(token='{masked}', base_url='{self._base_url}')"
