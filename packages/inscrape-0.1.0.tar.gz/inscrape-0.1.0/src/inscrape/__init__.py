"""
Inscrape — The AI-first web scraping API for Instagram, X & beyond.

Usage::

    from inscrape import Inscrape

    client = Inscrape("sk_your_token")
    profile = client.instagram("gkhetawat1")
    print(profile)
"""

from .client import AsyncInscrape, Inscrape
from .constants import SDK_VERSION as __version__
from .models import (
    AuthError,
    ConnectionError,
    InscrapeError,
    QuotaExhaustedError,
    RateLimitError,
    ScrapeFailedError,
    ScrapeResult,
)

__all__ = [
    # Clients
    "Inscrape",
    "AsyncInscrape",
    # Models
    "ScrapeResult",
    # Errors
    "InscrapeError",
    "AuthError",
    "RateLimitError",
    "QuotaExhaustedError",
    "ScrapeFailedError",
    "ConnectionError",
    # Metadata
    "__version__",
]
