"""Inscrape SDK constants."""

# API
DEFAULT_BASE_URL = "https://api.inscrape.io"
API_VERSION = "v1"

# HTTP
DEFAULT_TIMEOUT = 60.0  # seconds (SDK-level timeout for the HTTP call to Inscrape API)
DEFAULT_MAX_RETRIES = 2
RETRY_STATUS_CODES = {500, 502, 503, 504}
RETRY_BACKOFF_FACTOR = 1.0  # seconds: 1s, 2s, 4s

# SDK
SDK_VERSION = "0.1.0"
SDK_USER_AGENT = f"inscrape-python/{SDK_VERSION}"

# Parameter name mapping: Python snake_case → Inscrape API camelCase
PARAM_MAP = {
    "super_proxy": "super",
    "geo_code": "geoCode",
    "regional_geo_code": "regionalGeoCode",
    "session_id": "sessionId",
    "custom_headers": "customHeaders",
    "extra_headers": "extraHeaders",
    "forward_headers": "forwardHeaders",
    "set_cookies": "setCookies",
    "disable_redirection": "disableRedirection",
    "retry_timeout": "retryTimeout",
    "disable_retry": "disableRetry",
    "wait_until": "waitUntil",
    "custom_wait": "customWait",
    "wait_selector": "waitSelector",
    "block_resources": "blockResources",
    "screen_shot": "screenShot",
    "full_screen_shot": "fullScreenShot",
    "particular_screen_shot": "particularScreenShot",
    "play_with_browser": "playWithBrowser",
    "transparent_response": "transparentResponse",
    "return_json": "returnJSON",
    "show_frames": "showFrames",
    "show_websocket_requests": "showWebsocketRequests",
    "pure_cookies": "pureCookies",
}
