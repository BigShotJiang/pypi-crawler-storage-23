"""Inscrape SDK data models and exceptions."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


# ---------------------------------------------------------------------------
# Result Model
# ---------------------------------------------------------------------------

@dataclass
class ScrapeResult:
    """Represents a successful scrape response from the Inscrape API."""

    content: str
    """The scraped content (HTML, Markdown, or JSON string)."""

    status_code: int
    """HTTP status code returned by the Inscrape API."""

    content_type: str
    """Content-Type header of the response."""

    headers: Dict[str, str] = field(default_factory=dict)
    """Full response headers."""

    credits_used: Optional[int] = None
    """Number of credits consumed (if reported by the API)."""

    latency_ms: Optional[float] = None
    """Round-trip latency in milliseconds."""

    def json(self) -> Any:
        """Parse content as JSON. Raises ValueError if not valid JSON."""
        import json
        return json.loads(self.content)

    def __repr__(self) -> str:
        preview = self.content[:80] + "..." if len(self.content) > 80 else self.content
        return (
            f"ScrapeResult(status_code={self.status_code}, "
            f"content_type='{self.content_type}', "
            f"length={len(self.content)}, "
            f"preview='{preview}')"
        )


# ---------------------------------------------------------------------------
# Exception Hierarchy
# ---------------------------------------------------------------------------

class InscrapeError(Exception):
    """Base exception for all Inscrape SDK errors."""

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        status_code: Optional[int] = None,
        retry_after: Optional[int] = None,
        request_id: Optional[str] = None,
    ):
        self.message = message
        self.code = code
        self.status_code = status_code
        self.retry_after = retry_after
        self.request_id = request_id
        super().__init__(self.message)

    def __repr__(self) -> str:
        parts = [f"InscrapeError('{self.message}'"]
        if self.code:
            parts.append(f"code='{self.code}'")
        if self.status_code:
            parts.append(f"status={self.status_code}")
        if self.retry_after:
            parts.append(f"retry_after={self.retry_after}s")
        return ", ".join(parts) + ")"


class AuthError(InscrapeError):
    """Raised when the API token is invalid, expired, or missing (HTTP 401)."""
    pass


class RateLimitError(InscrapeError):
    """Raised when rate limits are exceeded (HTTP 429). Check `retry_after`."""
    pass


class QuotaExhaustedError(InscrapeError):
    """Raised when the monthly credit quota is exhausted (HTTP 402)."""
    pass


class ScrapeFailedError(InscrapeError):
    """Raised when the scrape itself fails on the target site (HTTP 500 with scrape error)."""
    pass


class ConnectionError(InscrapeError):
    """Raised when the SDK cannot connect to the Inscrape API."""
    pass
