"""Unit tests for CheckEngine, format_report, and format_json.

Covers the orchestration engine and both output formatters.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from axm_init.checks._workspace import ProjectContext
from axm_init.core.checker import ALL_CHECKS, CheckEngine, format_json, format_report
from axm_init.models.check import CheckResult, Grade, ProjectResult

# ── helpers ──────────────────────────────────────────────────────────────────


def _make_result(
    project_path: Path,
    *,
    passed: bool = True,
    score: int = 100,
) -> ProjectResult:
    """Build a minimal ProjectResult for formatter tests."""
    checks = [
        CheckResult(
            name="test.check",
            category="test",
            passed=passed,
            weight=10,
            message="ok" if passed else "missing",
            details=[] if passed else ["detail line"],
            fix="" if passed else "Run fix command",
        ),
    ]
    return ProjectResult.from_checks(project_path, checks)


# ── Fixtures ─────────────────────────────────────────────────────────────────


@pytest.fixture()
def gold_project(tmp_path: Path) -> Path:
    """Minimal gold-standard project for engine tests."""
    # pyproject.toml
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "test-pkg"\ndynamic = ["version"]\n'
        "classifiers = [\n"
        '    "Development Status :: 3 - Alpha",\n'
        '    "Programming Language :: Python :: 3.12",\n'
        '    "Typing :: Typed",\n]\n'
        "\n[project.urls]\n"
        'Homepage = "https://github.com/org/test-pkg"\n'
        'Documentation = "https://org.github.io/test-pkg/"\n'
        'Repository = "https://github.com/org/test-pkg.git"\n'
        'Issues = "https://github.com/org/test-pkg/issues"\n'
        "\n[build-system]\n"
        'requires = ["hatchling", "hatch-vcs"]\n'
        'build-backend = "hatchling.build"\n'
        "\n[dependency-groups]\n"
        'dev = ["pytest>=8.0","pytest-cov>=4.0","ruff>=0.8","mypy>=1.14","pre-commit>=4.0"]\n'  # noqa: E501
        'docs = ["mkdocs-material>=9.0","mkdocstrings[python]>=0.27",'
        '"mkdocs-gen-files>=0.5","mkdocs-literate-nav>=0.6"]\n'
        "\n[tool.mypy]\nstrict = true\npretty = true\n"
        "disallow_incomplete_defs = true\ncheck_untyped_defs = true\n"
        "\n[tool.ruff.lint]\n"
        'select = ["E","F","W","I","UP","B","SIM","S","BLE","PLR","N","RUF"]\n'
        "[tool.ruff.lint.per-file-ignores]\n"
        '"tests/*" = ["S101"]\n'
        "[tool.ruff.lint.isort]\n"
        'known-first-party = ["test_pkg"]\n'
        "\n[tool.pytest.ini_options]\n"
        'addopts = ["--strict-markers","--strict-config","--import-mode=importlib"]\n'
        'pythonpath = ["src"]\nfilterwarnings = ["error"]\n'
        "\n[tool.coverage.run]\nbranch = true\nrelative_files = true\n"
        "[tool.coverage.xml]\n"
        'output = "coverage.xml"\n'
        "[tool.coverage.report]\n"
        'exclude_lines = ["pragma: no cover"]\n'
        '\n[tool.git-cliff.changelog]\nheader = "# Changelog"\n'
    )
    # mkdocs
    (tmp_path / "mkdocs.yml").write_text(
        "nav:\n  - Tutorials:\n    - t.md\n  - How-To Guides:\n    - h.md\n"
        "  - Reference:\n    - r.md\n  - Explanation:\n    - e.md\n"
        "plugins:\n  - gen-files:\n      scripts: [docs/gen_ref_pages.py]\n"
        "  - literate-nav:\n      nav_file: SUMMARY.md\n  - mkdocstrings:\n"
    )
    # pre-commit
    (tmp_path / ".pre-commit-config.yaml").write_text(
        "repos:\n"
        "  - repo: ruff\n    hooks:\n      - id: ruff\n      - id: ruff-format\n"
        "  - repo: mypy\n    hooks:\n      - id: mypy\n"
        "  - repo: conv\n    hooks:\n      - id: conventional-pre-commit\n"
        "  - repo: basic\n    hooks:\n      - id: trailing-whitespace\n"
        "      - id: end-of-file-fixer\n      - id: check-yaml\n"
    )
    # Makefile
    (tmp_path / "Makefile").write_text(
        ".PHONY: install check test format lint audit clean docs-serve\n"
        "install:\n\techo\ncheck:\n\techo\nlint:\n\techo\nformat:\n\techo\n"
        "test:\n\techo\naudit:\n\techo\nclean:\n\techo\ndocs-serve:\n\techo\n"
    )
    # CI
    ci_dir = tmp_path / ".github" / "workflows"
    ci_dir.mkdir(parents=True)
    (ci_dir / "ci.yml").write_text(
        "jobs:\n  lint:\n    steps:\n      - run: make lint\n"
        "  security:\n    steps:\n      - run: pip-audit\n"
        "  test:\n    strategy:\n      matrix:\n        python-version: ['3.12']\n"
        "    steps:\n      - run: pytest\n"
        "  coverage:\n    steps:\n      - uses: coverallsapp/github-action@v2\n"
    )
    (ci_dir / "publish.yml").write_text(
        "name: Publish\npermissions:\n  id-token: write\n"
    )
    (tmp_path / ".github" / "dependabot.yml").write_text(
        "version: 2\nupdates:\n  - package-ecosystem: pip\n"
    )
    # Files
    (tmp_path / "README.md").write_text(
        "# test-pkg\n\n**desc**\n\n---\n\n## Features\n\n"
        "## Installation\n\n## Quick Start\n\n## Development\n\n## License\n"
    )
    (tmp_path / "CONTRIBUTING.md").write_text("# Contributing\n")
    (tmp_path / "LICENSE").write_text("MIT\n")
    (tmp_path / "uv.lock").write_text("version = 1\n")
    (tmp_path / ".python-version").write_text("3.12\n")
    pkg = tmp_path / "src" / "test_pkg"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("")
    (pkg / "py.typed").write_text("")
    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_x.py").write_text("def test_x(): pass\n")
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "gen_ref_pages.py").write_text("")
    # git hooks
    hooks_dir = tmp_path / ".git" / "hooks"
    hooks_dir.mkdir(parents=True)
    (hooks_dir / "pre-commit").write_text("#!/bin/sh\n")
    return tmp_path


# ── CheckEngine tests ────────────────────────────────────────────────────────


class TestCheckEngineRun:
    """Tests for CheckEngine.run()."""

    def test_run_all_categories(self, gold_project: Path) -> None:
        """Gold project scores 100 with all 39 checks."""
        engine = CheckEngine(gold_project)
        result = engine.run()
        assert result.score == 100
        assert result.grade == Grade.A
        assert len(result.checks) == 39

    def test_run_single_category(self, gold_project: Path) -> None:
        """Filtering to tooling returns only tooling checks."""
        engine = CheckEngine(gold_project, category="tooling")
        result = engine.run()
        assert all(c.category == "tooling" for c in result.checks)
        assert len(result.checks) == 7

    def test_run_invalid_category(self, gold_project: Path) -> None:
        """Invalid category raises ValueError."""
        engine = CheckEngine(gold_project, category="invalid")
        with pytest.raises(ValueError, match="Unknown category"):
            engine.run()


# ── Formatter tests ──────────────────────────────────────────────────────────


class TestFormatReport:
    """Tests for format_report()."""

    def test_contains_score_and_grade(self, tmp_path: Path) -> None:
        result = _make_result(tmp_path, passed=True)
        report = format_report(result)
        assert "100" in report
        assert "A" in report

    def test_contains_failures(self, tmp_path: Path) -> None:
        result = _make_result(tmp_path, passed=False)
        report = format_report(result)
        assert "❌" in report
        assert "Run fix command" in report


class TestFormatJson:
    """Tests for format_json()."""

    def test_structure(self, tmp_path: Path) -> None:
        result = _make_result(tmp_path, passed=True)
        data = format_json(result)
        assert set(data.keys()) == {
            "project",
            "score",
            "grade",
            "context",
            "workspace_root",
            "excluded_checks",
            "categories",
            "checks",
            "failures",
        }
        assert data["score"] == 100
        assert data["grade"] == "A"

    def test_failures_list(self, tmp_path: Path) -> None:
        result = _make_result(tmp_path, passed=False)
        data = format_json(result)
        assert len(data["failures"]) == 1
        assert data["failures"][0]["fix"] == "Run fix command"


class TestFormatAgent:
    """Tests for format_agent() — compact agent output."""

    def test_format_agent_all_passed(self, tmp_path: Path) -> None:
        """All passing → failed=[], passed_count is count of checks."""
        from axm_init.core.checker import format_agent

        result = _make_result(tmp_path, passed=True)
        output = format_agent(result)
        assert output["failed"] == []
        assert output["passed_count"] == 1
        assert isinstance(output["passed_count"], int)

    def test_format_agent_with_failures(self, tmp_path: Path) -> None:
        """Failed items must have name, message, details, fix."""
        from axm_init.core.checker import format_agent

        result = _make_result(tmp_path, passed=False)
        output = format_agent(result)
        assert len(output["failed"]) == 1
        f = output["failed"][0]
        assert set(f.keys()) >= {"name", "message", "details", "fix"}

    def test_format_agent_has_required_keys(self, tmp_path: Path) -> None:
        """Agent output must have score, grade, context, passed_count, failed."""
        from axm_init.core.checker import format_agent

        result = _make_result(tmp_path, passed=True)
        output = format_agent(result)
        assert set(output.keys()) == {
            "score",
            "grade",
            "context",
            "workspace_root",
            "excluded_checks",
            "passed_count",
            "failed",
        }

    def test_format_agent_no_passed_key(self, tmp_path: Path) -> None:
        """Agent output must NOT have a 'passed' key (replaced by count)."""
        from axm_init.core.checker import format_agent

        result = _make_result(tmp_path, passed=True)
        output = format_agent(result)
        assert "passed" not in output


class TestFormatReportVerbose:
    """Tests for format_report() verbose flag."""

    def test_default_hides_individual_passed(self, tmp_path: Path) -> None:
        """Default output shows summary line, not individual check names."""
        result = _make_result(tmp_path, passed=True)
        report = format_report(result)
        assert "1 checks passed" in report
        assert "test.check" not in report

    def test_verbose_shows_individual_checks(self, tmp_path: Path) -> None:
        """Verbose output shows individual check names."""
        result = _make_result(tmp_path, passed=True)
        report = format_report(result, verbose=True)
        assert "test.check" in report
        assert "✅" in report

    def test_default_always_shows_failures(self, tmp_path: Path) -> None:
        """Failures are always shown in default mode."""
        result = _make_result(tmp_path, passed=False)
        report = format_report(result)
        assert "❌" in report
        assert "Run fix command" in report


# ── Auto-discovery tests ─────────────────────────────────────────────────────


class TestCheckDiscovery:
    """Tests for auto-discovery of check modules."""

    def test_check_discovery_finds_all(self) -> None:
        """Auto-discovery finds 39 checks across 7 categories."""
        total = sum(len(fns) for fns in ALL_CHECKS.values())
        assert total == 44
        assert len(ALL_CHECKS) == 8

    def test_discovery_categories(self) -> None:
        """All expected categories are discovered."""
        expected = {
            "pyproject",
            "ci",
            "tooling",
            "docs",
            "structure",
            "deps",
            "changelog",
            "workspace",
        }
        assert set(ALL_CHECKS.keys()) == expected

    def test_discovery_skips_private_modules(self) -> None:
        """Private modules like _utils are not included."""
        assert "_utils" not in ALL_CHECKS


# ── CLI lazy import tests ────────────────────────────────────────────────────


class TestCLILazyImports:
    """Verify CLI adapter imports are lazy."""

    def test_cli_scaffold_lazy(self) -> None:
        """Importing axm_init.cli does not eagerly import adapters/core."""
        # Force reimport by checking that the modules are NOT loaded
        # as a side-effect of importing cli
        lazy_modules = [
            "axm_init.adapters.copier",
            "axm_init.adapters.credentials",
            "axm_init.adapters.pypi",
            "axm_init.core.reserver",
            "axm_init.core.templates",
        ]
        # Remove from cache if present
        cached = {m: sys.modules.pop(m, None) for m in lazy_modules}
        # Also remove cli to force re-evaluation
        original_cli = sys.modules.pop("axm_init.cli", None)
        try:
            import importlib

            importlib.import_module("axm_init.cli")
            for mod in lazy_modules:
                assert mod not in sys.modules, (
                    f"{mod} was eagerly imported by axm_init.cli"
                )
        finally:
            # Restore cache — including CLI itself to avoid breaking
            # @patch("axm_init.cli.X") in subsequent tests
            if original_cli is not None:
                sys.modules["axm_init.cli"] = original_cli
            for m, v in cached.items():
                if v is not None:
                    sys.modules[m] = v


# ── Context-aware engine tests ───────────────────────────────────────────────


class TestEngineStandalone:
    """Standalone context must be fully regression-safe."""

    def test_engine_standalone_unchanged(self, gold_project: Path) -> None:
        """Standalone gold project still gets 39 checks, score 100."""
        engine = CheckEngine(gold_project)
        result = engine.run()
        assert result.score == 100
        assert result.grade == Grade.A
        assert len(result.checks) == 39
        assert result.context == "standalone"
        assert result.workspace_root is None
        assert result.excluded_checks == []


class TestEngineWorkspace:
    """Workspace context skips package-only checks."""

    def test_engine_workspace_skips_package_checks(self, gold_project: Path) -> None:
        """Workspace fixture skips SKIP_FOR_WORKSPACE checks."""
        # Add workspace section to make it a workspace root
        pyproject = gold_project / "pyproject.toml"
        content = pyproject.read_text()
        content += '\n[tool.uv.workspace]\nmembers = ["packages/*"]\n'
        pyproject.write_text(content)

        engine = CheckEngine(gold_project)
        assert engine.context == ProjectContext.WORKSPACE

        result = engine.run()
        check_names = {c.name for c in result.checks}
        from axm_init.core.checker import SKIP_FOR_WORKSPACE

        for skip_name in SKIP_FOR_WORKSPACE:
            assert skip_name not in check_names, (
                f"{skip_name} should be skipped for workspace"
            )


class TestEngineMember:
    """Member context redirects CI/tooling to workspace root."""

    def test_engine_member_redirects_ci(
        self, tmp_path: Path, gold_project: Path
    ) -> None:
        """Member CI checks run against workspace root."""
        # Create workspace structure: tmp_path is workspace root
        ws_root = tmp_path / "workspace"
        ws_root.mkdir()
        (ws_root / "pyproject.toml").write_text(
            '[project]\nname = "ws"\n[tool.uv.workspace]\nmembers = ["packages/*"]\n'
        )

        # Create member package
        member = ws_root / "packages" / "pkg"
        member.mkdir(parents=True)
        (member / "pyproject.toml").write_text('[project]\nname = "pkg"\n')

        engine = CheckEngine(member)
        assert engine.context == ProjectContext.MEMBER
        assert engine.workspace_root == ws_root


class TestWorkspaceSkipsNewEntries:
    """Workspace root skips pyproject.mypy, ruff, ruff_rules, changelog.gitcliff."""

    def test_workspace_skips_pyproject_mypy(self, gold_project: Path) -> None:
        """Workspace root must not report pyproject.mypy failure."""
        pyproject = gold_project / "pyproject.toml"
        content = pyproject.read_text()
        content += '\n[tool.uv.workspace]\nmembers = ["packages/*"]\n'
        pyproject.write_text(content)

        engine = CheckEngine(gold_project)
        result = engine.run()
        check_names = {c.name for c in result.checks}
        assert "pyproject.pyproject_mypy" not in check_names

    def test_workspace_skips_ruff_config(self, gold_project: Path) -> None:
        """Workspace root must not report pyproject.ruff or ruff_rules."""
        pyproject = gold_project / "pyproject.toml"
        content = pyproject.read_text()
        content += '\n[tool.uv.workspace]\nmembers = ["packages/*"]\n'
        pyproject.write_text(content)

        engine = CheckEngine(gold_project)
        result = engine.run()
        check_names = {c.name for c in result.checks}
        assert "pyproject.pyproject_ruff" not in check_names
        assert "pyproject.pyproject_ruff_rules" not in check_names

    def test_workspace_skips_gitcliff(self, gold_project: Path) -> None:
        """Workspace root must not report changelog.gitcliff."""
        pyproject = gold_project / "pyproject.toml"
        content = pyproject.read_text()
        content += '\n[tool.uv.workspace]\nmembers = ["packages/*"]\n'
        pyproject.write_text(content)

        engine = CheckEngine(gold_project)
        result = engine.run()
        check_names = {c.name for c in result.checks}
        assert "changelog.gitcliff_config" not in check_names

    def test_workspace_skips_diataxis_nav(self, gold_project: Path) -> None:
        """Workspace root must not report docs.diataxis_nav."""
        pyproject = gold_project / "pyproject.toml"
        content = pyproject.read_text()
        content += '\n[tool.uv.workspace]\nmembers = ["packages/*"]\n'
        pyproject.write_text(content)

        engine = CheckEngine(gold_project)
        result = engine.run()
        check_names = {c.name for c in result.checks}
        assert "docs.diataxis_nav" not in check_names


class TestMemberRedirectsStructure:
    """Member structure checks redirect to workspace root."""

    @pytest.fixture()
    def ws_with_member(self, tmp_path: Path) -> tuple[Path, Path]:
        """Workspace root with full tooling + bare member."""
        ws_root = tmp_path / "ws"
        ws_root.mkdir()
        (ws_root / "pyproject.toml").write_text(
            '[project]\nname = "ws"\n[tool.uv.workspace]\nmembers = ["packages/*"]\n'
        )
        (ws_root / "LICENSE").write_text("MIT\n")
        (ws_root / ".python-version").write_text("3.12\n")
        (ws_root / "CONTRIBUTING.md").write_text("# Contributing\n")
        (ws_root / "Makefile").write_text(
            ".PHONY: install check test format lint audit clean docs-serve\n"
            "install:\n\techo\ncheck:\n\techo\ntest:\n\techo\nformat:\n\techo\n"
            "lint:\n\techo\naudit:\n\techo\nclean:\n\techo\ndocs-serve:\n\techo\n"
        )
        hooks_dir = ws_root / ".git" / "hooks"
        hooks_dir.mkdir(parents=True)
        (hooks_dir / "pre-commit").write_text("#!/bin/sh\n")
        gh_dir = ws_root / ".github"
        gh_dir.mkdir(parents=True)
        (gh_dir / "dependabot.yml").write_text(
            "version: 2\nupdates:\n  - package-ecosystem: pip\n"
        )

        member = ws_root / "packages" / "pkg-a"
        member.mkdir(parents=True)
        (member / "pyproject.toml").write_text('[project]\nname = "pkg-a"\n')
        return ws_root, member

    def test_member_redirects_license(self, ws_with_member: tuple[Path, Path]) -> None:
        """Member without LICENSE passes when workspace root has it."""
        _ws_root, member = ws_with_member
        engine = CheckEngine(member)
        result = engine.run()
        license_checks = [c for c in result.checks if c.name == "structure.license"]
        assert len(license_checks) == 1
        assert license_checks[0].passed

    def test_member_redirects_python_version(
        self, ws_with_member: tuple[Path, Path]
    ) -> None:
        """Member without .python-version passes when workspace root has it."""
        _ws_root, member = ws_with_member
        engine = CheckEngine(member)
        result = engine.run()
        pv_checks = [c for c in result.checks if c.name == "structure.python_version"]
        assert len(pv_checks) == 1
        assert pv_checks[0].passed

    def test_member_redirects_contributing(
        self, ws_with_member: tuple[Path, Path]
    ) -> None:
        """Member without CONTRIBUTING passes when workspace root has it."""
        _ws_root, member = ws_with_member
        engine = CheckEngine(member)
        result = engine.run()
        contrib_checks = [
            c for c in result.checks if c.name == "structure.contributing"
        ]
        assert len(contrib_checks) == 1
        assert contrib_checks[0].passed

    def test_member_redirects_makefile(self, ws_with_member: tuple[Path, Path]) -> None:
        """Member without Makefile passes when workspace root has it."""
        _ws_root, member = ws_with_member
        engine = CheckEngine(member)
        result = engine.run()
        makefile_checks = [c for c in result.checks if c.name == "tooling.makefile"]
        assert len(makefile_checks) == 1
        assert makefile_checks[0].passed

    def test_member_redirects_precommit_installed(
        self, ws_with_member: tuple[Path, Path]
    ) -> None:
        """Member without .git/hooks/pre-commit passes when workspace root has it."""
        _ws_root, member = ws_with_member
        engine = CheckEngine(member)
        result = engine.run()
        precommit_checks = [
            c for c in result.checks if c.name == "tooling.precommit_installed"
        ]
        assert len(precommit_checks) == 1
        assert precommit_checks[0].passed

    def test_member_redirects_dependabot(
        self, ws_with_member: tuple[Path, Path]
    ) -> None:
        """Member without .github/dependabot.yml passes when workspace root has it."""
        _ws_root, member = ws_with_member
        engine = CheckEngine(member)
        result = engine.run()
        dependabot_checks = [c for c in result.checks if c.name == "ci.dependabot"]
        assert len(dependabot_checks) == 1
        assert dependabot_checks[0].passed


class TestEngineExclusion:
    """Exclusion config auto-passes excluded checks."""

    def test_engine_exclusion_auto_pass(self, gold_project: Path) -> None:
        """Excluded checks get passed=True, message='Excluded by config'."""
        pyproject = gold_project / "pyproject.toml"
        content = pyproject.read_text()
        content += '\n[tool.axm-init]\nexclude = ["cli"]\n'
        pyproject.write_text(content)

        engine = CheckEngine(gold_project)
        result = engine.run()

        # cli checks should be excluded
        cli_checks = [c for c in result.checks if c.name.startswith("cli")]
        # There are no cli checks in ALL_CHECKS currently, so we verify
        # excluded_checks list is populated
        assert result.excluded_checks == [] or all(
            c.message == "Excluded by config" for c in cli_checks
        )

    def test_exclusion_nonexistent_ignored(self, gold_project: Path) -> None:
        """Exclusion for non-existent check → no crash, no effect."""
        pyproject = gold_project / "pyproject.toml"
        content = pyproject.read_text()
        content += '\n[tool.axm-init]\nexclude = ["nonexistent"]\n'
        pyproject.write_text(content)

        engine = CheckEngine(gold_project)
        result = engine.run()
        assert result.score == 100
        assert len(result.checks) == 39


class TestProjectResultContext:
    """ProjectResult context fields."""

    def test_project_result_context_field(self, tmp_path: Path) -> None:
        """Context field is stored and accessible."""
        checks = [
            CheckResult(
                name="t.check",
                category="t",
                passed=True,
                weight=10,
                message="ok",
                details=[],
                fix="",
            )
        ]
        result = ProjectResult.from_checks(
            tmp_path, checks, context="workspace", workspace_root=tmp_path
        )
        assert result.context == "workspace"
        assert result.workspace_root == tmp_path
        assert result.excluded_checks == []


class TestFormatReportContext:
    """Format report shows context in header."""

    def test_format_report_context(self, tmp_path: Path) -> None:
        """Report header contains context info."""
        checks = [
            CheckResult(
                name="t.check",
                category="t",
                passed=True,
                weight=10,
                message="ok",
                details=[],
                fix="",
            )
        ]
        result = ProjectResult.from_checks(
            tmp_path, checks, context="workspace", workspace_root=tmp_path
        )
        report = format_report(result)
        assert "Context: WORKSPACE" in report


class TestFormatJsonContext:
    """Format JSON includes context fields."""

    def test_format_json_context(self, tmp_path: Path) -> None:
        """JSON output includes context, workspace_root."""
        checks = [
            CheckResult(
                name="t.check",
                category="t",
                passed=True,
                weight=10,
                message="ok",
                details=[],
                fix="",
            )
        ]
        result = ProjectResult.from_checks(tmp_path, checks, context="workspace")
        data = format_json(result)
        assert data["context"] == "workspace"
        assert "excluded_checks" in data


class TestFormatAgentContext:
    """Format agent includes context fields."""

    def test_format_agent_context(self, tmp_path: Path) -> None:
        """Agent output includes context."""
        from axm_init.core.checker import format_agent

        checks = [
            CheckResult(
                name="t.check",
                category="t",
                passed=True,
                weight=10,
                message="ok",
                details=[],
                fix="",
            )
        ]
        result = ProjectResult.from_checks(tmp_path, checks, context="member")
        output = format_agent(result)
        assert output["context"] == "member"
