from typing import Protocol

from bussdcc.context import ContextProtocol
from bussdcc.event import Event
from bussdcc.message import Message


class ProcessProtocol(Protocol):
    name: str

    def attach(self, ctx: ContextProtocol) -> None: ...
    def detach(self) -> None: ...

    def start(self, ctx: ContextProtocol) -> None: ...
    def stop(self, ctx: ContextProtocol) -> None: ...

    def handle_event(self, ctx: ContextProtocol, evt: Event[Message]) -> None: ...
