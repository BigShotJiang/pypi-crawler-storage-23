Welcome to xsdba's documentation!
=================================

`xsdba` is a Python library for statistical downscaling and bias adjustment. Leveraging `xarray`` and `dask`,
users can easily bias-adjust large datasets.

.. toctree::
   :hidden:

   self

.. toctree::
   :maxdepth: 0
   :caption: Table of Contents:

   readme
   installation
   usage
   xclim_migration_guide
   xsdba
   contributing
   releasing
   notebooks/index

.. toctree::
   :titlesonly:

   authors
   changelog
   references

.. toctree::
   :maxdepth: 1
   :caption: All Modules

   apidoc/modules

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
