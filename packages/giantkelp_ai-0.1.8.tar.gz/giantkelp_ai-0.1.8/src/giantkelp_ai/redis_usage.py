"""
Optional Redis stream integration for usage tracking.

This module provides functionality to send AI completion usage data
to a Redis stream for monitoring and analytics.
"""

import json
from datetime import datetime, timezone
from typing import Optional

_redis_client = None
_redis_config = None


class RedisUsageConfig:
    """Configuration for Redis usage tracking."""

    def __init__(
        self,
        redis_url: str,
        stream_key: str = "giantkelp:usage",
        client_id: str = "default"
    ):
        """
        Initialize Redis usage configuration.

        Args:
            redis_url: Redis connection URL (e.g., "redis://localhost:6379")
            stream_key: Redis stream key for usage events
            client_id: Identifier for the importing application/project
        """
        self.redis_url = redis_url
        self.stream_key = stream_key
        self.client_id = client_id


def configure_redis(config: RedisUsageConfig) -> None:
    """
    Initialize Redis client for usage tracking.
    Call this from your application before using AIAgent.

    Args:
        config: RedisUsageConfig instance with connection details

    Raises:
        ImportError: If redis package is not installed

    Example:
        from giantkelp_ai import configure_redis, RedisUsageConfig

        configure_redis(RedisUsageConfig(
            redis_url="redis://localhost:6379",
            stream_key="myapp:ai_usage",
            client_id="my_project_id"
        ))
    """
    global _redis_client, _redis_config

    try:
        import redis
    except ImportError:
        raise ImportError(
            "redis package not installed. "
            "Install with: pip install giantkelp-ai[redis]"
        )

    _redis_config = config
    _redis_client = redis.from_url(config.redis_url)


def send_usage_event(
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    agent_name: str = "general",
    message: str = ""
) -> Optional[str]:
    """
    Send usage event to Redis stream.

    Args:
        provider: LLM provider name (e.g., "anthropic", "openai")
        model: Model name used for completion
        input_tokens: Number of input/prompt tokens
        output_tokens: Number of output/completion tokens
        agent_name: Name of the agent that made the request
        message: First 100 characters of the user prompt

    Returns:
        Redis message ID if successful, None if Redis not configured
    """
    global _redis_client, _redis_config

    if _redis_client is None or _redis_config is None:
        return None

    job = {
        "type": "usage_event",
        "payload": {
            "provider": provider,
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "agent_name": agent_name,
            "client_id": _redis_config.client_id,
            "message": message[:100] if message else "",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    }

    message_id = _redis_client.xadd(
        _redis_config.stream_key,
        {"job": json.dumps(job)}
    )

    return message_id


def is_redis_configured() -> bool:
    """
    Check if Redis usage tracking is configured.

    Returns:
        True if Redis is configured, False otherwise
    """
    return _redis_client is not None
