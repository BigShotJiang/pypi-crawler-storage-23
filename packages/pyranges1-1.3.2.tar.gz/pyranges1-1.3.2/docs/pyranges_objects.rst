
PyRanges objects
----------------

The main object in pyranges1 is the PyRanges object.
It is a pandas DataFrame with additional methods for genomic operations.


.. autoclass:: pyranges1.core.pyranges_main.PyRanges
   :members:
