
Seqs: sequences
---------------

Utilities to process nucleotide or protein sequences.

.. automodule:: pyranges1.ext.seqs
    :members:
    :imported-members:

