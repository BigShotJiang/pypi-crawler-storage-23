
Stats: statistics
-----------------

Utilities for calculating statistics about genomic intervals.

.. automodule:: pyranges1.ext.stats
    :members:
    :imported-members:

