from .categorical import LabelEncodeRecommendation, OneHotEncodeRecommendation

__all__ = ["OneHotEncodeRecommendation", "LabelEncodeRecommendation"]
