"""
voicerun-completions: Unified LLM completion client with fallback support.
"""

from .client import (
    generate_chat_completion,
    generate_chat_completion_stream,
)

from .types.request import (
    CompletionsProvider,
    ChatCompletionRequest,
    ChatCompletionRequestDict,
    FallbackRequest,
    FallbackRequestDict,
    RetryConfiguration,
    RetryConfigurationDict,
    StreamOptions,
    StreamOptionsDict,
    ToolDefinition,
    ToolDefinitionDict,
    FunctionDefinition,
    FunctionDefinitionDict,
)

from .types.response import ChatCompletionResponse

from .types.streaming import (
    ChatCompletionChunk,
    AssistantMessageDeltaChunk,
    AssistantMessageSentenceChunk,
    ToolCallChunk,
    FinishReasonChunk,
    UsageChunk,
    FinalResponseChunk,
)

from .types.messages import (
    ConversationHistoryMessage,
    UserMessage,
    AssistantMessage,
    SystemMessage,
    ToolResultMessage,
    ToolCall,
    FunctionCall,
    ConversationHistory,
    serialize_conversation,
    deserialize_conversation,
)

from .types.errors import VoiceRunCompletionError
