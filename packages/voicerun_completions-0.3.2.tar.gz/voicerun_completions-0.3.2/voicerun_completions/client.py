from typing import Any, Optional, Union, AsyncIterable
from loguru import logger

from .types.request import (
    CompletionsProvider,
    ChatCompletionRequest,
    ChatCompletionRequestDict,
    StreamOptions,
    StreamOptionsDict,
)
from .types.streaming import ChatCompletionChunk, FinalResponseChunk
from .types.response import ChatCompletionResponse
from .providers.base import CompletionClient
from .providers.openai.client import OpenAiCompletionClient
from .providers.anthropic.client import AnthropicCompletionClient
from .providers.google.client import GoogleCompletionClient
from .providers.anthropic.vertex.client import AnthropicVertexCompletionClient
from .providers.alibaba.client import AlibabaCompletionClient
from .types.errors import InvalidProviderError, FallbackExhaustedError


def _get_client(provider: CompletionsProvider) -> CompletionClient:
    """Get the completion client for the given provider."""
    if provider == CompletionsProvider.OPENAI:
        return OpenAiCompletionClient()
    elif provider == CompletionsProvider.ANTHROPIC:
        return AnthropicCompletionClient()
    elif provider == CompletionsProvider.GOOGLE:
        return GoogleCompletionClient()
    elif provider == CompletionsProvider.ANTHROPIC_VERTEX:
        return AnthropicVertexCompletionClient()
    elif provider == CompletionsProvider.ALIBABA:
        return AlibabaCompletionClient()
    else:
        raise InvalidProviderError(str(provider))


async def generate_chat_completion(
    request: Union[ChatCompletionRequest, ChatCompletionRequestDict]
) -> ChatCompletionResponse:
    """
    Generate chat completion.

    Args:
        request: ChatCompletionRequest object or dict with request parameters

    Returns:
        ChatCompletionResponse with the complete response

    Raises:
        VoiceRunCompletionError: On error

    Note:
        Retry logic follows OpenAI's recommended exponential backoff pattern.
    """
    if isinstance(request, dict):
        request = ChatCompletionRequest(**request)

    completion_attempts: list[ChatCompletionRequest] = request._build_completion_attempts()
    last_exception = None
    providers_tried: list[str] = []

    for completion_request in completion_attempts:
        providers_tried.append(str(completion_request.provider))
        try:
            client = _get_client(completion_request.provider)
            response = await client.generate_chat_completion(completion_request)
            response.provider = completion_request.provider
            response.model = completion_request.model
            return response
        except Exception as e:
            logger.warning(f"Completion request failed with {str(e)}")
            last_exception = e

    # If no fallbacks were configured, raise the original error directly
    if len(providers_tried) == 1:
        logger.error(f"Completion failed: {last_exception}")
        raise last_exception

    error = FallbackExhaustedError(
        message=f"All providers failed. Last error: {str(last_exception)}",
        fallback_count=len(providers_tried) - 1,
        providers_tried=providers_tried,
        last_error=last_exception,
    )
    logger.error(f"Completion failed: {error}")
    raise error


async def generate_chat_completion_stream(
    request: Union[ChatCompletionRequest, ChatCompletionRequestDict],
    stream_options: Optional[Union[StreamOptions, StreamOptionsDict]] = None,
) -> AsyncIterable[ChatCompletionChunk]:
    """
    Generate streaming chat completion.

    Args:
        request: ChatCompletionRequest object or dict with request parameters
        stream_options: Options for configuring streaming behavior

    Returns:
        AsyncIterable of ChatCompletionChunk objects (typed chunks)

    Raises:
        VoiceRunCompletionError: On error

    Retry Behavior:
        When retry enabled, the function will retry ONLY the initial connection
        (before streaming starts). Retries use exponential backoff (1s, 2s, 4s, etc.).
        Once streaming begins, failures are NOT retried to prevent duplicate content.

        RETRIES (Initial Connection Failures):
           - Connection failures
           - Network errors before streaming starts
           - Rate limits (429)
           - Server errors (500, 502, 503)
           - Authentication errors (401)
           - Timeout errors

        NO RETRY (Mid-Stream Failures):
           - Once streaming begins, failures are NOT retried
           - This prevents duplicate content in real-time applications
           - Mid-stream failures raise exceptions immediately

        Example:
            # Connection retry attempt 1: Timeout
            # Wait 1 second...
            # Connection retry attempt 2: Success!
            # Stream chunk 1: "Hello..."
            # Stream chunk 2: "world..."
            # [If chunk 3 fails -> raises exception immediately, no retry]

        This ensures reliability without duplicate audio/messages.
    """
    if isinstance(request, dict):
        request = ChatCompletionRequest(**request)

    if stream_options and isinstance(stream_options, dict):
        stream_options = StreamOptions(**stream_options)

    completion_attempts: list[ChatCompletionRequest] = request._build_completion_attempts()

    async def _stream() -> AsyncIterable[ChatCompletionChunk]:
        last_exception = None
        providers_tried: list[str] = []

        for completion_request in completion_attempts:
            providers_tried.append(str(completion_request.provider))
            try:
                client = _get_client(completion_request.provider)
                stream = client.generate_chat_completion_stream(completion_request, stream_options)
                aiter = stream.__aiter__()
                first_chunk = await aiter.__anext__()
            except StopAsyncIteration:
                # Empty stream from this provider, try next fallback
                continue
            except Exception as e:
                logger.warning(f"Streaming connection failed with {str(e)}")
                last_exception = e
                continue

            # Connection established - yield chunks, stamping provider/model on FinalResponseChunk
            def _stamp(chunk):
                if isinstance(chunk, FinalResponseChunk):
                    chunk.response.provider = completion_request.provider
                    chunk.response.model = completion_request.model
                return chunk

            yield _stamp(first_chunk)
            async for chunk in aiter:
                yield _stamp(chunk)
            return

        # If no fallbacks were configured, raise the original error directly
        if len(providers_tried) == 1 and last_exception is not None:
            logger.error(f"Streaming failed: {last_exception}")
            raise last_exception

        error = FallbackExhaustedError(
            message=f"All providers failed to stream. Last error: {str(last_exception)}",
            fallback_count=len(providers_tried) - 1,
            providers_tried=providers_tried,
            last_error=last_exception,
        )
        logger.error(f"Streaming failed: {error}")
        raise error

    return _stream()
