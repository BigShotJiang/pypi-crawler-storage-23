"""
Custom error hierarchy for voicerun-completions.
"""
from typing import Optional

from openai import (
    OpenAIError,
    AuthenticationError as OpenAIAuthenticationError,
    RateLimitError as OpenAIRateLimitError,
    APITimeoutError as OpenAIAPITimeoutError,
    NotFoundError as OpenAINotFoundError,
    APIStatusError as OpenAIAPIStatusError,
    BadRequestError as OpenAIBadRequestError,
)
from anthropic import (
    APIError as AnthropicAPIError,
    AuthenticationError as AnthropicAuthenticationError,
    RateLimitError as AnthropicRateLimitError,
    APITimeoutError as AnthropicAPITimeoutError,
    NotFoundError as AnthropicNotFoundError,
    InternalServerError as AnthropicInternalServerError,
    BadRequestError as AnthropicBadRequestError,
)


# =============================================================================
# External-facing errors (exported via __init__.py)
# =============================================================================
__all__ = ["VoiceRunCompletionError"]


class VoiceRunCompletionError(Exception):
    """Base exception for all voicerun-completions errors."""

    def __init__(
        self,
        message: str,
        original_error: Optional[Exception] = None,
    ):
        self.message = message
        self.original_error = original_error
        super().__init__(message)

    def __str__(self) -> str:
        if self.original_error:
            return f"{self.message} (caused by: {self.original_error})"
        return self.message


# =============================================================================
# Configuration Errors
# =============================================================================

class ConfigurationError(VoiceRunCompletionError):
    """Error in client configuration."""
    pass


class InvalidProviderError(ConfigurationError):
    """Invalid or unsupported provider specified."""

    def __init__(
        self,
        provider: str,
        message: Optional[str] = None,
        original_error: Optional[Exception] = None,
    ):
        self.provider = provider
        message = message or f"Invalid provider: {provider}"
        super().__init__(message, original_error)


# =============================================================================
# Validation Errors
# =============================================================================

class ValidationError(VoiceRunCompletionError):
    """Error in request validation."""
    pass


class InvalidMessageError(ValidationError):
    """Invalid message format or content."""

    def __init__(
        self,
        message: str,
        details: Optional[str] = None,
        original_error: Optional[Exception] = None,
    ):
        self.details = details
        super().__init__(message, original_error)


class InvalidToolError(ValidationError):
    """Invalid tool definition."""

    def __init__(
        self,
        message: str,
        details: Optional[str] = None,
        original_error: Optional[Exception] = None,
    ):
        self.details = details
        super().__init__(message, original_error)


class InvalidRetryConfigError(ValidationError):
    """Invalid retry configuration."""
    pass


# =============================================================================
# Provider Errors
# =============================================================================

class ProviderError(VoiceRunCompletionError):
    """Error from an LLM provider."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        status_code: Optional[int] = None,
        original_error: Optional[Exception] = None,
    ):
        self.provider = provider
        self.status_code = status_code
        super().__init__(message, original_error)


class AuthenticationError(ProviderError):
    """Authentication failed (401)."""

    def __init__(
        self,
        message: str = "Authentication failed",
        provider: Optional[str] = None,
        original_error: Optional[Exception] = None,
    ):
        super().__init__(message, provider, 401, original_error)


class RateLimitError(ProviderError):
    """Rate limit exceeded (429)."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        provider: Optional[str] = None,
        retry_after: Optional[float] = None,
        original_error: Optional[Exception] = None,
    ):
        self.retry_after = retry_after
        super().__init__(message, provider, 429, original_error)


class ProviderUnavailableError(ProviderError):
    """Provider service unavailable (500/502/503)."""

    def __init__(
        self,
        message: str = "Provider service unavailable",
        provider: Optional[str] = None,
        status_code: int = 503,
        original_error: Optional[Exception] = None,
    ):
        super().__init__(message, provider, status_code, original_error)


class ModelNotFoundError(ProviderError):
    """Requested model not found (404)."""

    def __init__(
        self,
        model: str,
        message: Optional[str] = None,
        provider: Optional[str] = None,
        original_error: Optional[Exception] = None,
    ):
        self.model = model
        message = message or f"Model not found: {model}"
        super().__init__(message, provider, 404, original_error)


class ContentFilterError(ProviderError):
    """Content blocked by provider's content filter."""

    def __init__(
        self,
        message: str = "Content blocked by content filter",
        provider: Optional[str] = None,
        original_error: Optional[Exception] = None,
    ):
        super().__init__(message, provider, 400, original_error)


class TimeoutError(ProviderError):
    """Request timed out."""

    def __init__(
        self,
        message: str = "Request timed out",
        provider: Optional[str] = None,
        timeout_seconds: Optional[float] = None,
        original_error: Optional[Exception] = None,
    ):
        self.timeout_seconds = timeout_seconds
        super().__init__(message, provider, 408, original_error)


# =============================================================================
# Retry and Fallback Errors
# =============================================================================

class RetryExhaustedError(VoiceRunCompletionError):
    """All retry attempts exhausted."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        retry_count: int = 0,
        last_error: Optional[Exception] = None,
    ):
        self.provider = provider
        self.retry_count = retry_count
        self.last_error = last_error
        super().__init__(message, last_error)


class FallbackExhaustedError(VoiceRunCompletionError):
    """All fallback providers exhausted."""

    def __init__(
        self,
        message: str,
        fallback_count: int = 0,
        providers_tried: Optional[list[str]] = None,
        last_error: Optional[Exception] = None,
    ):
        self.fallback_count = fallback_count
        self.providers_tried = providers_tried or []
        self.last_error = last_error
        super().__init__(message, last_error)


# =============================================================================
# Streaming Errors
# =============================================================================

class StreamingError(VoiceRunCompletionError):
    """Error during streaming response."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        original_error: Optional[Exception] = None,
    ):
        self.provider = provider
        super().__init__(message, original_error)


class StreamConnectionError(StreamingError):
    """Failed to establish streaming connection."""
    pass


class StreamInterruptedError(StreamingError):
    """Stream was interrupted after connection established."""
    pass


# =============================================================================
# Error Mapping Functions
# =============================================================================

def map_openai_error(error: OpenAIError, provider: str = "openai") -> ProviderError:
    """Map OpenAI SDK exception to custom error type."""
    message = str(error)

    if isinstance(error, OpenAIAuthenticationError):
        return AuthenticationError(message, provider=provider, original_error=error)

    if isinstance(error, OpenAIRateLimitError):
        return RateLimitError(message, provider=provider, original_error=error)

    if isinstance(error, OpenAIAPITimeoutError):
        return TimeoutError(message, provider=provider, original_error=error)

    if isinstance(error, OpenAINotFoundError):
        return ModelNotFoundError(model="unknown", message=message, provider=provider, original_error=error)

    if isinstance(error, OpenAIAPIStatusError):
        status = getattr(error, 'status_code', None)

        if isinstance(error, OpenAIBadRequestError):
            error_body = getattr(error, 'body', {}) or {}
            if isinstance(error_body, dict):
                error_code = error_body.get('error', {}).get('code', '')
                if 'content_filter' in str(error_code).lower():
                    return ContentFilterError(message, provider=provider, original_error=error)

        if status in (500, 502, 503):
            return ProviderUnavailableError(message, provider=provider, status_code=status, original_error=error)

    return ProviderError(message, provider=provider, original_error=error)


def map_anthropic_error(error: AnthropicAPIError, provider: str = "anthropic") -> ProviderError:
    """Map Anthropic SDK exception to custom error type."""
    message = str(error)

    if isinstance(error, AnthropicAuthenticationError):
        return AuthenticationError(message, provider=provider, original_error=error)

    if isinstance(error, AnthropicRateLimitError):
        return RateLimitError(message, provider=provider, original_error=error)

    if isinstance(error, AnthropicAPITimeoutError):
        return TimeoutError(message, provider=provider, original_error=error)

    if isinstance(error, AnthropicNotFoundError):
        return ModelNotFoundError(model="unknown", message=message, provider=provider, original_error=error)

    if isinstance(error, AnthropicInternalServerError):
        return ProviderUnavailableError(message, provider=provider, status_code=500, original_error=error)

    if isinstance(error, AnthropicBadRequestError):
        return ValidationError(message, original_error=error)

    return ProviderError(message, provider=provider, original_error=error)
