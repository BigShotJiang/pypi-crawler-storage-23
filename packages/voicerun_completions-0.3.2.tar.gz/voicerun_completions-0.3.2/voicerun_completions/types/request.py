from typing import Any, Dict, List, Literal, Optional, Required, TypeAlias, TypedDict, Union
from enum import StrEnum
from dataclasses import dataclass

from openai.types.shared.reasoning_effort import ReasoningEffort as OpenAiReasoningEffort
from anthropic.types import ThinkingConfigParam as AnthropicThinkingConfig
from google.genai.types import ThinkingConfigDict as GoogleThinkingConfig

from .messages import ConversationHistory, ConversationHistoryDict, ConversationHistoryMessage
from .cache import CacheBreakpoint, CacheBreakpointDict
from .errors import (
    InvalidProviderError,
    InvalidMessageError,
    InvalidToolError,
    InvalidRetryConfigError,
)


def coalesce(a, b):
    """Return a if a is not None, otherwise return b."""
    return a if a is not None else b


class CompletionsProvider(StrEnum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    ANTHROPIC_VERTEX = "anthropic_vertex"
    ALIBABA = "alibaba"


class OpenAIKwargs(TypedDict, total=False):
    """OpenAI-specific keyword arguments.

    These are passed directly to the OpenAI chat completions API.

    Attributes:
        service_tier: Service tier for the request (e.g., "default", "flex")
        reasoning_effort: Reasoning effort level for o-series models

    See Also:
        Valid kwargs: https://platform.openai.com/docs/api-reference/chat/create
        Python SDK: openai.resources.chat.completions.AsyncCompletions.create()
    """
    service_tier: Literal["auto", "default", "flex", "scale", "priority"]
    reasoning_effort: OpenAiReasoningEffort


class AnthropicKwargs(TypedDict, total=False):
    """Anthropic-specific keyword arguments.

    These are passed directly to the Anthropic messages API.

    Attributes:
        thinking: Extended thinking configuration. Disabled by default in this client.
            To enable: {"type": "enabled", "budget_tokens": 10000}

    See Also:
        Valid kwargs: https://docs.anthropic.com/en/api/messages
        Python SDK: anthropic.resources.messages.AsyncMessages.create()
    """
    thinking: AnthropicThinkingConfig


class GoogleKwargs(TypedDict, total=False):
    """Google Gemini-specific keyword arguments.

    These are passed to the Google GenAI GenerateContentConfig.

    Attributes:
        thinking_config: Thinking configuration. Disabled by default in this client.
            To enable: {"thinking_budget": 10000, "include_thoughts": True}

    See Also:
        Valid kwargs: https://ai.google.dev/api/generate-content
        Python SDK: google.genai.types.GenerateContentConfigDict
    """
    thinking_config: GoogleThinkingConfig


class AnthropicVertexKwargs(TypedDict, total=False):
    """Vertex Anthropic-specific keyword arguments.

    These are passed to the Anthropic messages API via Vertex AI.

    Attributes:
        thinking: Extended thinking configuration. Disabled by default in this client.
            To enable: {"type": "enabled", "budget_tokens": 10000}
        project_id: GCP project ID
        region: GCP region (e.g., "us-central1", "us-east5")
        service_account_credentials: Dict from GCP service account JSON key file

    See Also:
        Valid kwargs: https://docs.anthropic.com/en/api/messages
        Python SDK: anthropic.resources.messages.AsyncMessages.create()
    """
    thinking: AnthropicThinkingConfig
    project_id: str
    region: str
    service_account_credentials: Dict[str, Any]


class AlibabaKwargs(TypedDict, total=False):
    """Alibaba Qwen (DashScope) specific keyword arguments.

    These are passed to the Qwen API via the OpenAI-compatible DashScope endpoint.

    Attributes:
        base_url: Override the DashScope regional endpoint.
            Defaults to Singapore (intl): https://dashscope-intl.aliyuncs.com/compatible-mode/v1
            Other regions:
              Virginia (US): https://dashscope-us.aliyuncs.com/compatible-mode/v1
              Beijing (CN): https://dashscope.aliyuncs.com/compatible-mode/v1
        enable_search: Enable Qwen's built-in web search capability.

    See Also:
        DashScope API: https://help.aliyun.com/zh/model-studio/getting-started/models
    """
    base_url: str
    enable_search: bool


class ProviderKwargs(TypedDict, total=False):
    """Provider-specific keyword arguments, keyed by provider name.

    Use this for provider-specific parameters that are not normalized in
    ChatCompletionRequest (e.g., service_tier, reasoning_effort, thinking).
    Only the kwargs for the active provider are used; others are ignored.

    This structure allows specifying kwargs for multiple providers in a single
    request, making it easier to switch between providers or configure fallbacks
    without passing invalid parameters to providers that don't support them.

    Example:
        provider_kwargs={
            "openai": {"service_tier": "priority", "reasoning_effort": "none"},
            "anthropic": {"thinking": {"type": "enabled", "budget_tokens": 10000}},
        }
    """
    openai: OpenAIKwargs
    anthropic: AnthropicKwargs
    google: GoogleKwargs
    anthropic_vertex: AnthropicVertexKwargs
    alibaba: AlibabaKwargs


class FunctionDefinitionDict(TypedDict, total=False):
    """TypedDict for `FunctionDefinition`."""
    name: Required[str]
    description: Required[str]
    parameters: Required[Dict[str, Any]]
    strict: bool


@dataclass
class FunctionDefinition:
    """Function definition for tool calling.

    Attributes:
        name: Name of the function
        description: Description of what the function does
        parameters: JSON schema describing the function's parameters
        strict: Whether to enable strict mode for parameter validation (OpenAI only)
    """
    name: str
    description: str
    parameters: Dict[str, Any]
    strict: Optional[bool] = None

    @classmethod
    def deserialize(cls, data: dict) -> "FunctionDefinition":
        """Deserialize function definition from dictionary representation."""
        return cls(
            name=data["name"],
            description=data["description"],
            parameters=data["parameters"],
            strict=data.get("strict", None),
        )


class ToolDefinitionDict(TypedDict, total=False):
    """TypedDict for `ToolDefinition`."""
    type: Required[Literal["function"]]
    function: Required[FunctionDefinitionDict]
    cache_breakpoint: CacheBreakpointDict


@dataclass
class ToolDefinition:
    """Tool definition for LLM tool calling.

    Attributes:
        type: Type of tool (always "function")
        function: Function definition containing name, description, and parameters
        cache_breakpoint: Optional Anthropic cache breakpoint for prompt caching optimization
    """
    type: Literal["function"]
    function: FunctionDefinition
    cache_breakpoint: Optional[CacheBreakpoint] = None

    @classmethod
    def deserialize(cls, data: dict) -> "ToolDefinition":
        """Deserialize tool definition from dictionary representation."""
        cache_breakpoint = None
        if data.get("cache_breakpoint"):
            cache_breakpoint = CacheBreakpoint.deserialize(data.get("cache_breakpoint"))
        return cls(
            type=data["type"],
            function=FunctionDefinition.deserialize(data["function"]),
            cache_breakpoint=cache_breakpoint,
        )


ToolChoice: TypeAlias = Union[Literal["none", "auto", "required"], str]


def _normalize_provider(provider: Union[str, CompletionsProvider]) -> CompletionsProvider:
    """Convert potential string provider into CompletionsProvider."""
    if isinstance(provider, CompletionsProvider):
        return provider
    if isinstance(provider, str):
        try:
            return CompletionsProvider(provider.lower())
        except ValueError:
            raise InvalidProviderError(provider)
    raise InvalidProviderError(str(provider))


def _normalize_messages(messages: list[Union[dict, ConversationHistoryMessage]]) -> ConversationHistory:
    """Convert list of dicts or message objects to normalized ConversationHistoryMessage objects."""
    normalized_messages: ConversationHistory = []

    for msg in messages:
        if isinstance(msg, ConversationHistoryMessage):
            normalized_messages.append(msg)
        elif isinstance(msg, dict):
            normalized_messages.append(ConversationHistoryMessage.deserialize(msg))
        else:
            raise InvalidMessageError(
                f"Messages must be dict or ConversationHistoryMessage, got {type(msg)}",
                details=f"Received type: {type(msg).__name__}",
            )

    return normalized_messages


def _normalize_tools(tools: Optional[list[Union[dict, ToolDefinition]]]) -> Optional[list[ToolDefinition]]:
    """Convert list of dicts or tool def objects to list of normalized ToolDefinitions."""
    if not tools:
        return None

    normalized_tools: list[ToolDefinition] = []
    for tool in tools:
        if isinstance(tool, ToolDefinition):
            normalized_tools.append(tool)
        elif isinstance(tool, dict):
            normalized_tools.append(ToolDefinition.deserialize(tool))
        else:
            raise InvalidToolError(
                f"Tools must be dict or ToolDefinition, got {type(tool)}",
                details=f"Received type: {type(tool).__name__}",
            )

    return normalized_tools


class StreamOptionsDict(TypedDict, total=False):
    """TypedDict for `StreamOptions`."""
    stream_sentences: bool = False
    clean_sentences: bool = True
    min_sentence_length: int = 6
    punctuation_marks: Optional[list[str]] = None
    punctuation_language: Optional[str] = None


@dataclass
class StreamOptions:
    """Options for configuring streaming behavior.

    Attributes:
        stream_sentences: Whether to stream response by sentences instead of tokens
        clean_sentences: Whether to clean markdown and special characters from sentences for speech
            Only applicable if stream_sentences = True
            Defaults to True
        min_sentence_length: Minimum length (in characters) for a sentence to be yielded
            Only applicable if stream_sentences = True
            Defaults to 6 characters
        punctuation_marks: Optional set of punctuation marks to use for sentence boundaries
            Only applicable if stream_sentences = True
            Defaults to comprehensive set covering most languages
        punctuation_language: Optional language code to use language-specific punctuation
            Only applicable if stream_sentences = True
            Supported: 'en', 'zh', 'ko', 'ja', 'es', 'fr', 'it', 'de'
    """
    stream_sentences: bool = False
    clean_sentences: bool = True
    min_sentence_length: int = 6
    punctuation_marks: Optional[list[str]] = None
    punctuation_language: Optional[str] = None


class RetryConfigurationDict(TypedDict, total=False):
    """TypedDict for `RetryConfiguration`."""
    enabled: bool = True
    max_retries: int = 3
    retry_delay: float = 1.0
    backoff_multiplier: float = 2.0


@dataclass
class RetryConfiguration:
    """ChatCompletionRequest retry configuration.

    Attributes:
        enabled: Enable retry (default: True)
        max_retries: Maximum number of retry attempts (default: 3)
        retry_delay: Initial delay between retries in seconds (default: 1.0)
        backoff_multiplier: Multiplier for exponential backoff (default: 2.0)

    Note:
        Retry logic follows OpenAI's recommended exponential backoff pattern.
    """
    enabled: bool = True
    max_retries: int = 3
    retry_delay: float = 1.0
    backoff_multiplier: float = 2.0


def _normalize_retry(retry: Optional[Union[RetryConfiguration, dict]]) -> Optional[RetryConfiguration]:
    """Convert dict to RetryConfiguration if needed."""
    if retry is None:
        return None
    if isinstance(retry, RetryConfiguration):
        return retry
    if isinstance(retry, dict):
        return RetryConfiguration(**retry)
    raise InvalidRetryConfigError(
        f"Retry must be dict or RetryConfiguration, got {type(retry)}"
    )


class FallbackRequestDict(TypedDict, total=False):
    """TypedDict for `FallbackRequest`."""
    provider: CompletionsProvider
    api_key: str
    model: str
    messages: Union[ConversationHistory, ConversationHistoryDict]
    temperature: float
    tools: list[Union[ToolDefinition, ToolDefinitionDict]]
    tool_choice: ToolChoice
    timeout: float
    max_tokens: int
    response_schema: Dict[str, Any]
    retry: Union[RetryConfiguration, RetryConfigurationDict]
    provider_kwargs: ProviderKwargs


@dataclass
class FallbackRequest:
    """Chat completion fallback request. Any parameters supplied in this request will override
    the original request parameters in the fallback completion request. Parameters not supplied
    in this fallback request will default to the parameters from the original completion request.

    Attributes:
        provider: LLM provider to use (OpenAI, Anthropic, or Google)
        api_key: API key for authentication with the provider
        model: Model name to use for completion
        messages: Conversation history as a list of messages
        temperature: Sampling temperature for response randomness (0.0 to 1.0)
        tools: Optional list of tool definitions for function calling
        tool_choice: How the model should choose which tools to call
        timeout: Request timeout in seconds
        max_tokens: Maximum number of tokens in the response
        response_schema: Optional JSON Schema dict for structured JSON output
        retry: Options for configuring retry behavior
        provider_kwargs: Provider-specific keyword arguments keyed by provider name
    """
    provider: Optional[CompletionsProvider] = None
    api_key: Optional[str] = None
    model: Optional[str] = None
    messages: Optional[ConversationHistory] = None
    temperature: Optional[float] = None
    tools: Optional[list[ToolDefinition]] = None
    tool_choice: Optional[ToolChoice] = None
    timeout: Optional[float] = None
    max_tokens: Optional[int] = None
    response_schema: Optional[Dict[str, Any]] = None
    retry: Optional[RetryConfiguration] = None
    provider_kwargs: Optional[ProviderKwargs] = None


class ChatCompletionRequestDict(TypedDict, total=False):
    """TypedDict for `ChatCompletionRequest`."""
    provider: Required[Union[str, CompletionsProvider]]
    api_key: Required[str]
    model: Required[str]
    messages: Required[Union[ConversationHistory, ConversationHistoryDict]]
    temperature: float
    tools: list[ToolDefinition]
    tool_choice: ToolChoice
    timeout: float
    max_tokens: int
    response_schema: Dict[str, Any]
    retry: Union[RetryConfiguration, RetryConfigurationDict]
    fallbacks: List[Union[FallbackRequest, FallbackRequestDict]]
    provider_kwargs: ProviderKwargs


@dataclass
class ChatCompletionRequest:
    """Normalized chat completion request for any LLM provider.

    Attributes:
        provider: LLM provider to use (OpenAI, Anthropic, or Google)
        api_key: API key for authentication with the provider
        model: Model name to use for completion
        messages: Conversation history as a list of messages
        temperature: Sampling temperature for response randomness (0.0 to 1.0)
        tools: Optional list of tool definitions for function calling
        tool_choice: How the model should choose which tools to call
        timeout: Request timeout in seconds
        max_tokens: Maximum number of tokens in the response
        response_schema: Optional JSON Schema dict for structured JSON output.
            When set, the provider is instructed to return JSON conforming to this schema.
            Denormalized per provider (OpenAI response_format, Anthropic output_config,
            Google response_schema with response_mime_type).
        retry: Options for configuring retry behavior
        fallbacks: Ordered list of fallback requests
        provider_kwargs: Provider-specific keyword arguments keyed by provider name
    """
    provider: CompletionsProvider
    api_key: str
    model: str
    messages: ConversationHistory
    temperature: Optional[float] = None
    tools: Optional[list[ToolDefinition]] = None
    tool_choice: Optional[ToolChoice] = None
    timeout: Optional[float] = None
    max_tokens: Optional[int] = None
    response_schema: Optional[Dict[str, Any]] = None
    retry: Optional[RetryConfiguration] = None
    fallbacks: Optional[List[FallbackRequest]] = None
    provider_kwargs: Optional[ProviderKwargs] = None

    def _apply_fallback(self, fallback: FallbackRequest) -> "ChatCompletionRequest":
        """Create a new ChatCompletionRequest with parameters overridden by the fallback.

        Non-None values from the FallbackRequest will override the corresponding
        fields in the original request. Fields not present in FallbackRequest
        or set to None will retain their original values.

        Args:
            fallback: FallbackRequest containing override parameters

        Returns:
            A new ChatCompletionRequest with merged parameters
        """
        if isinstance(fallback, dict):
            fallback = FallbackRequest(**fallback)
        return ChatCompletionRequest(
            provider=coalesce(fallback.provider, self.provider),
            api_key=coalesce(fallback.api_key, self.api_key),
            model=coalesce(fallback.model, self.model),
            messages=coalesce(fallback.messages, self.messages),
            temperature=coalesce(fallback.temperature, self.temperature),
            tools=coalesce(fallback.tools, self.tools),
            tool_choice=coalesce(fallback.tool_choice, self.tool_choice),
            timeout=coalesce(fallback.timeout, self.timeout),
            max_tokens=coalesce(fallback.max_tokens, self.max_tokens),
            response_schema=coalesce(fallback.response_schema, self.response_schema),
            retry=coalesce(fallback.retry, self.retry),
            # Do not carry forward the fallback chain
            fallbacks=None,
            provider_kwargs=coalesce(fallback.provider_kwargs, self.provider_kwargs),
        )

    def _normalize(self) -> "ChatCompletionRequest":
        """Normalize request fields in place.

        Returns:
            Self for method chaining
        """
        self.provider = _normalize_provider(self.provider)
        self.messages = _normalize_messages(self.messages)
        self.tools = _normalize_tools(self.tools)
        self.retry = _normalize_retry(self.retry)
        return self

    def _build_completion_attempts(self) -> List["ChatCompletionRequest"]:
        """Build list of completion attempts including fallbacks.

        Returns the original request (normalized) followed by any fallback
        variants, each normalized and ready for execution.

        Returns:
            List of normalized ChatCompletionRequests to attempt in order
        """
        attempts = [self._normalize()]
        if self.fallbacks:
            for fallback in self.fallbacks:
                attempts.append(self._apply_fallback(fallback)._normalize())
        return attempts
