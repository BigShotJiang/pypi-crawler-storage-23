from dataclasses import dataclass
from typing import Any, AsyncIterator, Optional, override
from google.genai import Client
from google.genai.types import (
    Candidate as GoogleResponseCandidate,
    Content as GoogleMessageContent,
    Part as GoogleMessagePart,
    GenerateContentResponse as GoogleContentResponse,
    GenerateContentConfigDict as GoogleRequestConfigDict,
    ThinkingConfigDict as GoogleThinkingConfigDict,
)

from ..base import CompletionClient, CompletionsProvider, ProviderCompletionRequest
from .stream_processor import GoogleStreamProcessor
from .utils import denormalize_conversation_history, denormalize_tools, denormalize_tool_choice, sanitize_parameters_schema
from ...types.messages import AssistantMessage, FunctionCall, ToolCall
from ...types.response import ChatCompletionResponse
from ...types.request import ChatCompletionRequest, StreamOptions
from ...types.errors import ProviderError


@dataclass
class GoogleCompletionRequest(ProviderCompletionRequest):
    """Provider-specific request for Google Gen AI completions.

    Use ``from_request`` to build from a ``ChatCompletionRequest``.
    Call ``get_kwargs(stream=...)`` to produce the kwargs dict for
    ``client.aio.models.generate_content()``.
    """

    api_key: str
    model: str
    contents: list[GoogleMessageContent]
    config: Optional[GoogleRequestConfigDict] = None

    @classmethod
    @override
    def get_known_provider_kwargs(cls) -> frozenset[str]:
        return frozenset({"thinking_config"})

    @classmethod
    def from_request(cls, request: ChatCompletionRequest) -> "GoogleCompletionRequest":
        contents, system_instruction = denormalize_conversation_history(request.messages)
        provider_kwargs = (request.provider_kwargs or {}).get("google", {})

        # Build config dict
        config_dict: dict[str, Any] = {}

        if request.temperature is not None:
            config_dict["temperature"] = request.temperature

        if request.max_tokens is not None:
            config_dict["max_output_tokens"] = request.max_tokens

        if request.tools:
            config_dict["tools"] = denormalize_tools(request.tools)

        if request.tool_choice:
            tool_config = denormalize_tool_choice(request.tool_choice)
            if tool_config:
                config_dict["tool_config"] = tool_config

        if request.timeout is not None:
            # Google takes timeout in ms
            timeout_ms = int(request.timeout * 1000)
            config_dict["http_options"] = {"timeout": timeout_ms}

        if system_instruction:
            config_dict["system_instruction"] = system_instruction

        # Structured JSON output via response_schema
        if request.response_schema is not None:
            config_dict["response_mime_type"] = "application/json"
            config_dict["response_schema"] = sanitize_parameters_schema(request.response_schema)

        # Google-specific kwargs
        if "thinking_config" in provider_kwargs:
            config_dict["thinking_config"] = provider_kwargs["thinking_config"]
        else:
            # Disable thinking by default
            config_dict["thinking_config"] = GoogleThinkingConfigDict(
                thinking_budget=0,  # 0 = DISABLED
                include_thoughts=False
            )

        # Pass through any other provider kwargs to config
        for key, value in provider_kwargs.items():
            if key not in cls.get_known_provider_kwargs():
                config_dict[key] = value

        config = GoogleRequestConfigDict(**config_dict) if config_dict else None

        return cls(
            api_key=request.api_key,
            model=request.model,
            contents=contents,
            config=config,
        )

    @override
    def get_kwargs(self, *, stream: bool = False) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "contents": self.contents,
        }

        if self.config is not None:
            kwargs["config"] = self.config

        return kwargs


class GoogleCompletionClient(CompletionClient):

    @override
    def get_provider(self) -> CompletionsProvider:
        return CompletionsProvider.GOOGLE

    @override
    def _denormalize_request(
        self,
        request: ChatCompletionRequest,
    ) -> GoogleCompletionRequest:
        """Convert ChatCompletionRequest to GoogleCompletionRequest."""
        return GoogleCompletionRequest.from_request(request)

    @override
    def _normalize_response(
        self,
        response: GoogleContentResponse,
    ) -> ChatCompletionResponse:
        """Convert Google GenerateContentResponse to normalized ChatCompletionResponse."""

        # Take only first candidate
        candidate: GoogleResponseCandidate = response.candidates[0]
        google_message: GoogleMessageContent = candidate.content
        google_message_parts: list[GoogleMessagePart] = google_message.parts

        # Extract text and function calls from parts
        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        tool_call_index: int = 0
        # For non-function-call responses, Gemini 3 returns thought_signature on the last part
        last_text_part_signature: bytes | None = None

        for part in google_message_parts:
            if part.text:
                text_parts.append(part.text)
                # Capture thought_signature from text parts (will keep the last one)
                if part.thought_signature:
                    last_text_part_signature = part.thought_signature
            elif part.function_call:
                # Convert function call to ToolCall
                # Store thought_signature as a custom field for Google compatibility
                tool_call = ToolCall(
                    id=part.function_call.id,
                    type="function",
                    function=FunctionCall(
                        name=part.function_call.name,
                        arguments=part.function_call.args
                    ),
                    index=tool_call_index,
                )
                # Preserve thought_signature if present (Google-specific field)
                if part.thought_signature:
                    tool_call.thought_signature = part.thought_signature
                tool_calls.append(tool_call)
                tool_call_index += 1

        # Combine text content
        content = "".join(text_parts) if text_parts else None

        # For text-only responses (no function calls), preserve thought_signature on AssistantMessage
        # For function call responses, signatures are preserved on individual ToolCall objects
        normalized_message = AssistantMessage(
            content=content,
            tool_calls=tool_calls if tool_calls else None,
            thought_signature=last_text_part_signature if not tool_calls else None
        )

        return ChatCompletionResponse(
            message=normalized_message,
            finish_reason=candidate.finish_reason,
            usage=response.usage_metadata.model_dump() if response.usage_metadata else None
        )

    @override
    async def _get_completion(
        self,
        request: GoogleCompletionRequest,
    ) -> GoogleContentResponse:
        """Generate content using Google Gen AI client.

        [Client](https://github.com/googleapis/python-genai)
        """
        try:
            async with Client(api_key=request.api_key).aio as async_client:
                return await async_client.models.generate_content(**request.get_kwargs())
        except Exception as e:
            raise ProviderError(str(e), provider=self.get_provider(), original_error=e) from e


    @override
    def _get_stream_processor(
        self,
        stream_options: Optional[StreamOptions] = None,
    ) -> GoogleStreamProcessor:
        """Get google-specific StreamProcessor."""
        return GoogleStreamProcessor(stream_options=stream_options)


    @override
    async def _get_completion_stream(
        self,
        request: GoogleCompletionRequest,
    ) -> AsyncIterator[GoogleContentResponse]:
        """Stream chat completion events from Google.

        [Client](https://github.com/googleapis/python-genai)

        Note: Creates a client for each stream and ensures proper cleanup
        to prevent resource leaks across multiple turns.
        """
        client = Client(api_key=request.api_key)

        try:
            stream = await client.aio.models.generate_content_stream(**request.get_kwargs(stream=True))
            async for chunk in stream:
                yield chunk
        except Exception as e:
            raise ProviderError(str(e), provider=self.get_provider(), original_error=e) from e
        finally:
            client.close()
