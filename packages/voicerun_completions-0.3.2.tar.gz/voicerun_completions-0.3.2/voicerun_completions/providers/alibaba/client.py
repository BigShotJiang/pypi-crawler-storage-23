from dataclasses import dataclass
from typing import Any, Optional, AsyncIterator, override
from openai import AsyncOpenAI, OpenAIError
from openai.types.chat import ChatCompletion
from openai.types.chat.chat_completion_chunk import ChatCompletionChunk as OpenAiCompletionChunk

from ..openai.client import OpenAiCompletionClient, OpenAiCompletionRequest
from ..openai.utils import (
    denormalize_conversation_history,
    denormalize_tools,
    denormalize_tool_choice,
)
from ..base import CompletionsProvider
from ...types.request import ChatCompletionRequest, StreamOptions
from ...types.errors import map_openai_error

DASHSCOPE_DEFAULT_BASE_URL = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"


@dataclass
class AlibabaCompletionRequest(OpenAiCompletionRequest):
    """Provider-specific request for Alibaba Qwen via DashScope API.

    Use ``from_request`` to build from a ``ChatCompletionRequest``.
    Call ``get_kwargs(stream=...)`` to produce the kwargs dict for
    ``client.chat.completions.create()``.
    """

    base_url: str = DASHSCOPE_DEFAULT_BASE_URL
    enable_search: Optional[bool] = None

    @classmethod
    @override
    def get_known_provider_kwargs(cls) -> frozenset[str]:
        return frozenset({"base_url", "enable_search"})

    @classmethod
    def from_request(cls, request: ChatCompletionRequest) -> "AlibabaCompletionRequest":
        provider_kwargs = (request.provider_kwargs or {}).get("alibaba", {})

        # Collect passthrough kwargs (not explicitly handled)
        extra_kwargs = {k: v for k, v in provider_kwargs.items() if k not in cls.get_known_provider_kwargs()}

        # Build response_format from response_schema (same as OpenAI)
        response_format = None
        if request.response_schema is not None:
            response_format = {
                "type": "json_schema",
                "json_schema": {
                    "name": "response_schema",
                    "schema": request.response_schema,
                    "strict": True,
                },
            }

        return cls(
            api_key=request.api_key,
            model=request.model,
            messages=denormalize_conversation_history(request.messages),
            tools=denormalize_tools(request.tools),
            tool_choice=denormalize_tool_choice(request.tool_choice),
            temperature=request.temperature if request.temperature else None,
            max_tokens=request.max_tokens,
            timeout=request.timeout,
            response_format=response_format,
            base_url=provider_kwargs.get("base_url", DASHSCOPE_DEFAULT_BASE_URL),
            enable_search=provider_kwargs.get("enable_search"),
            extra_kwargs=extra_kwargs,
        )

    @override
    def get_kwargs(self, *, stream: bool = False) -> dict[str, Any]:
        kwargs = super().get_kwargs(stream=stream)

        if self.enable_search is not None:
            kwargs["extra_body"] = {
                **(kwargs.get("extra_body") or {}),
                "enable_search": self.enable_search,
            }

        return kwargs


class AlibabaCompletionClient(OpenAiCompletionClient):
    """Alibaba Qwen completion client via DashScope API.

    Uses the OpenAI-compatible DashScope endpoint with a custom base_url.
    Auth via DASHSCOPE_API_KEY passed as api_key.
    """

    @override
    def get_provider(self) -> CompletionsProvider:
        return CompletionsProvider.ALIBABA

    @override
    def _denormalize_request(
        self,
        request: ChatCompletionRequest,
    ) -> AlibabaCompletionRequest:
        """Convert ChatCompletionRequest to AlibabaCompletionRequest."""
        return AlibabaCompletionRequest.from_request(request)

    @override
    async def _get_completion(
        self,
        request: AlibabaCompletionRequest,
    ) -> ChatCompletion:
        """Generate completion using DashScope OpenAI-compatible endpoint."""
        try:
            async with AsyncOpenAI(api_key=request.api_key, base_url=request.base_url) as client:
                return await client.chat.completions.create(**request.get_kwargs())
        except OpenAIError as e:
            raise map_openai_error(e, provider=self.get_provider()) from e

    @override
    async def _get_completion_stream(
        self,
        request: AlibabaCompletionRequest,
    ) -> AsyncIterator[OpenAiCompletionChunk]:
        """Stream chat completion chunks from DashScope.

        Note: Creates a client for each stream and ensures proper cleanup
        to prevent resource leaks across multiple turns.
        """
        client = AsyncOpenAI(api_key=request.api_key, base_url=request.base_url)

        try:
            stream = await client.chat.completions.create(**request.get_kwargs(stream=True))

            async for chunk in stream:
                yield chunk
        except OpenAIError as e:
            raise map_openai_error(e, provider=self.get_provider()) from e
        finally:
            await client.close()
