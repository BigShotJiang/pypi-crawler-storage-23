from dataclasses import dataclass, field
from typing import Any, Optional, AsyncIterator, override
from anthropic import AsyncAnthropic, APIError as AnthropicAPIError
from anthropic.types import (
    Message as AnthropicMessage,
    MessageParam as AnthropicMessageParam,
    TextBlockParam as AnthropicTextBlockParam,
    ToolParam as AnthropicToolDefinition,
    ToolChoiceParam as AnthropicToolChoice,
    TextBlock as AnthropicTextBlock,
    ToolUseBlock as AnthropicToolCall,
    RawMessageStreamEvent as AnthropicStreamEvent,
    ThinkingConfigParam,
)

from ..base import CompletionClient, CompletionsProvider, ProviderCompletionRequest
from .stream_processor import AnthropicStreamProcessor
from .utils import denormalize_conversation_history, denormalize_tools, denormalize_tool_choice
from ...types.messages import AssistantMessage, ToolCall, FunctionCall
from ...types.response import ChatCompletionResponse
from ...types.request import ChatCompletionRequest, StreamOptions
from ...types.errors import map_anthropic_error


@dataclass
class AnthropicCompletionRequest(ProviderCompletionRequest):
    """Provider-specific request for Anthropic chat completions.

    Use ``from_request`` to build from a ``ChatCompletionRequest``.
    Call ``get_kwargs(stream=...)`` to produce the kwargs dict for
    ``client.messages.create()``.
    """

    api_key: str
    model: str
    messages: list[AnthropicMessageParam]
    max_tokens: int
    tools: Optional[list[AnthropicToolDefinition]] = None
    tool_choice: Optional[AnthropicToolChoice] = None
    temperature: Optional[float] = None
    system: Optional[list[AnthropicTextBlockParam]] = None
    output_config: Optional[dict[str, Any]] = None
    # Anthropic-specific kwargs
    thinking: ThinkingConfigParam = field(default_factory=lambda: {"type": "disabled"})
    timeout: Optional[float] = None
    extra_kwargs: dict[str, Any] = field(default_factory=dict)

    @classmethod
    @override
    def get_known_provider_kwargs(cls) -> frozenset[str]:
        return frozenset({"thinking"})

    @classmethod
    def from_request(cls, request: ChatCompletionRequest) -> "AnthropicCompletionRequest":
        messages, system_prompt = denormalize_conversation_history(request.messages)
        provider_kwargs = (request.provider_kwargs or {}).get("anthropic", {})

        # Collect passthrough kwargs (not explicitly handled)
        extra_kwargs = {k: v for k, v in provider_kwargs.items() if k not in cls.get_known_provider_kwargs()}

        # Build output_config from response_schema
        output_config = None
        if request.response_schema is not None:
            output_config = {
                "format": {
                    "type": "json_schema",
                    "schema": request.response_schema,
                },
            }

        return cls(
            api_key=request.api_key,
            model=request.model,
            messages=messages,
            max_tokens=request.max_tokens if request.max_tokens else 4000,
            thinking=provider_kwargs.get("thinking", {"type": "disabled"}),
            tools=denormalize_tools(request.tools),
            tool_choice=denormalize_tool_choice(request.tool_choice),
            temperature=request.temperature if request.temperature else None,
            system=system_prompt if system_prompt else None,
            output_config=output_config,
            timeout=request.timeout,
            extra_kwargs=extra_kwargs,
        )

    @override
    def get_kwargs(self, *, stream: bool = False) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": self.messages,
            "max_tokens": self.max_tokens,
            "stream": stream,
            "thinking": self.thinking,
        }

        if self.tools is not None:
            kwargs["tools"] = self.tools
        if self.tool_choice is not None:
            kwargs["tool_choice"] = self.tool_choice
        if self.temperature is not None:
            kwargs["temperature"] = self.temperature
        if self.system is not None:
            kwargs["system"] = self.system
        if self.output_config is not None:
            kwargs["output_config"] = self.output_config
        if self.timeout is not None:
            kwargs["timeout"] = self.timeout

        kwargs.update(self.extra_kwargs)
        return kwargs


class AnthropicCompletionClient(CompletionClient):

    @override
    def get_provider(self) -> CompletionsProvider:
        return CompletionsProvider.ANTHROPIC

    @override
    def _denormalize_request(
        self,
        request: ChatCompletionRequest,
    ) -> AnthropicCompletionRequest:
        """Convert ChatCompletionRequest to AnthropicCompletionRequest."""
        return AnthropicCompletionRequest.from_request(request)


    @override
    def _normalize_response(
        self,
        response: AnthropicMessage,
    ) -> ChatCompletionResponse:
        """Convert Anthropic Message to normalized ChatCompletionResponse."""

        # Extract text content and tool calls from content blocks
        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        tool_call_index: int = 0

        for block in response.content:
            match block:
                case AnthropicTextBlock():
                    text_parts.append(block.text)
                case AnthropicToolCall():
                    tool_calls.append(ToolCall(
                        id=block.id,
                        type="function",
                        function=FunctionCall(
                            name=block.name,
                            arguments=block.input
                        ),
                        index=tool_call_index,
                    ))
                    tool_call_index += 1

        # Combine text content
        content = "".join(text_parts) if text_parts else None

        # Create normalized message
        normalized_message = AssistantMessage(
            content=content,
            tool_calls=tool_calls if tool_calls else None,
        )

        return ChatCompletionResponse(
            message=normalized_message,
            finish_reason=response.stop_reason,
            usage=response.usage.model_dump() if response.usage else None
        )


    @override
    async def _get_completion(
        self,
        request: AnthropicCompletionRequest,
    ) -> AnthropicMessage:
        """Generate completion using Anthropic client.

        [Client](https://github.com/anthropics/anthropic-sdk-python)
        """
        try:
            async with AsyncAnthropic(api_key=request.api_key) as client:
                return await client.messages.create(**request.get_kwargs())
        except AnthropicAPIError as e:
            raise map_anthropic_error(e, provider=self.get_provider()) from e


    @override
    def _get_stream_processor(
        self,
        stream_options: Optional[StreamOptions] = None,
    ) -> AnthropicStreamProcessor:
        """Get anthropic-specific StreamProcessor."""
        return AnthropicStreamProcessor(stream_options=stream_options)


    @override
    async def _get_completion_stream(
        self,
        request: AnthropicCompletionRequest,
    ) -> AsyncIterator[AnthropicStreamEvent]:
        """Stream chat response events from Anthropic.

        [Client](https://github.com/anthropics/anthropic-sdk-python)

        Note: Creates a client for each stream and ensures proper cleanup
        to prevent resource leaks across multiple turns.
        """
        client = AsyncAnthropic(api_key=request.api_key)

        try:
            stream = await client.messages.create(**request.get_kwargs(stream=True))

            async for chunk in stream:
                yield chunk
        except AnthropicAPIError as e:
            raise map_anthropic_error(e, provider=self.get_provider()) from e
        finally:
            await client.close()
