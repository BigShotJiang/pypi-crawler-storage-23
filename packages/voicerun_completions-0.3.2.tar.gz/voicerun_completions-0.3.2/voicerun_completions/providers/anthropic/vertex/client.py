from dataclasses import dataclass
from typing import Any, Optional, AsyncIterator, override
from anthropic import AsyncAnthropicVertex, APIError as AnthropicAPIError
from google.oauth2 import service_account as google_service_account
from anthropic.types import (
    Message as AnthropicMessage,
    RawMessageStreamEvent as AnthropicStreamEvent,
)

from ..client import AnthropicCompletionClient, AnthropicCompletionRequest, CompletionsProvider
from ..utils import denormalize_conversation_history, denormalize_tools, denormalize_tool_choice
from ....types.request import ChatCompletionRequest
from ....types.errors import ConfigurationError, map_anthropic_error


@dataclass
class AnthropicVertexCompletionRequest(AnthropicCompletionRequest):
    """Provider-specific request for Anthropic via Vertex AI.

    Use ``from_request`` to build from a ``ChatCompletionRequest``.
    Call ``get_kwargs(stream=...)`` to produce the kwargs dict for
    ``client.messages.create()``.
    """

    project_id: Optional[str] = None
    region: Optional[str] = None
    service_account_credentials: Optional[dict[str, Any]] = None

    @classmethod
    @override
    def get_known_provider_kwargs(cls) -> frozenset[str]:
        return super().get_known_provider_kwargs() | frozenset({
            "project_id", "region", "service_account_credentials",
        })

    @classmethod
    def from_request(cls, request: ChatCompletionRequest) -> "AnthropicVertexCompletionRequest":
        messages, system_prompt = denormalize_conversation_history(request.messages)
        provider_kwargs = (request.provider_kwargs or {}).get("anthropic_vertex", {})

        service_account_credentials = provider_kwargs.get("service_account_credentials")
        if service_account_credentials is None:
            raise ConfigurationError(
                "provider_kwargs['anthropic_vertex'] must include 'service_account_credentials' "
                "(a dict from a GCP service account JSON key file)"
            )

        # Collect passthrough kwargs (not explicitly handled)
        extra_kwargs = {k: v for k, v in provider_kwargs.items() if k not in cls.get_known_provider_kwargs()}

        # Build output_config from response_schema (same as Anthropic)
        output_config = None
        if request.response_schema is not None:
            output_config = {
                "format": {
                    "type": "json_schema",
                    "schema": request.response_schema,
                },
            }

        return cls(
            api_key="",  # Not used — auth via service account
            model=request.model,
            messages=messages,
            max_tokens=request.max_tokens if request.max_tokens else 4000,
            thinking=provider_kwargs.get("thinking", {"type": "disabled"}),
            tools=denormalize_tools(request.tools),
            tool_choice=denormalize_tool_choice(request.tool_choice),
            temperature=request.temperature if request.temperature else None,
            system=system_prompt if system_prompt else None,
            output_config=output_config,
            timeout=request.timeout,
            project_id=provider_kwargs.get("project_id"),
            region=provider_kwargs.get("region"),
            service_account_credentials=service_account_credentials,
            extra_kwargs=extra_kwargs,
        )


class AnthropicVertexCompletionClient(AnthropicCompletionClient):
    """Claude completion client via Google Vertex AI.

    Requires explicit service account credentials passed via
    ``provider_kwargs["anthropic_vertex"]["service_account_credentials"]``
    (a dict matching the contents of a GCP service account JSON key file).
    """

    @override
    def get_provider(self) -> CompletionsProvider:
        return CompletionsProvider.ANTHROPIC_VERTEX

    @override
    def _denormalize_request(
        self,
        request: ChatCompletionRequest,
    ) -> AnthropicVertexCompletionRequest:
        """Convert ChatCompletionRequest to AnthropicVertexCompletionRequest."""
        return AnthropicVertexCompletionRequest.from_request(request)

    def _build_vertex_client(self, request: AnthropicVertexCompletionRequest) -> AsyncAnthropicVertex:
        """Create a Vertex AI Anthropic client from the request credentials."""
        credentials = google_service_account.Credentials.from_service_account_info(
            request.service_account_credentials
        )
        client_kwargs: dict[str, Any] = {"region": request.region, "credentials": credentials}
        if request.project_id:
            client_kwargs["project_id"] = request.project_id
        return AsyncAnthropicVertex(**client_kwargs)

    @override
    async def _get_completion(
        self,
        request: AnthropicVertexCompletionRequest,
    ) -> AnthropicMessage:
        """Get completion via Vertex AI."""
        try:
            async with self._build_vertex_client(request) as client:
                return await client.messages.create(**request.get_kwargs())
        except AnthropicAPIError as e:
            raise map_anthropic_error(e, provider=self.get_provider()) from e

    @override
    async def _get_completion_stream(
        self,
        request: AnthropicVertexCompletionRequest,
    ) -> AsyncIterator[AnthropicStreamEvent]:
        """Stream chat response events from Vertex AI.

        Note: Creates a client for each stream and ensures proper cleanup
        to prevent resource leaks across multiple turns.
        """
        client = self._build_vertex_client(request)

        try:
            stream = await client.messages.create(**request.get_kwargs(stream=True))

            async for chunk in stream:
                yield chunk
        except AnthropicAPIError as e:
            raise map_anthropic_error(e, provider=self.get_provider()) from e
        finally:
            await client.close()
