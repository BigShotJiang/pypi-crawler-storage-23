from dataclasses import dataclass, field
from typing import Any, Literal, Optional, AsyncIterator, override
from openai import AsyncOpenAI, OpenAIError
from openai.types.chat import (
    ChatCompletion,
    ChatCompletionMessageParam,
    ChatCompletionFunctionToolParam,
    ChatCompletionToolChoiceOptionParam,
)
from openai.types.chat.chat_completion import (
    Choice as OpenAiChoice,
    ChatCompletionMessage as OpenAiChatCompletionMessage,
)
from openai.types.chat.chat_completion_chunk import ChatCompletionChunk as OpenAiCompletionChunk
from openai.types.shared.reasoning_effort import ReasoningEffort as OpenAiReasoningEffort

from ..base import CompletionClient, CompletionsProvider, ProviderCompletionRequest
from .stream_processor import OpenAiStreamProcessor
from .utils import (
    denormalize_conversation_history,
    denormalize_tools,
    denormalize_tool_choice,
    normalize_tool_calls,
)
from ...types.messages import AssistantMessage
from ...types.response import ChatCompletionResponse
from ...types.request import ChatCompletionRequest, StreamOptions
from ...types.errors import map_openai_error

@dataclass
class OpenAiCompletionRequest(ProviderCompletionRequest):
    """Provider-specific request for OpenAI chat completions.

    Use ``from_request`` to build from a ``ChatCompletionRequest``.
    Call ``get_kwargs(stream=...)`` to produce the kwargs dict for
    ``client.chat.completions.create()``.
    """

    api_key: str
    model: str
    messages: list[ChatCompletionMessageParam]
    tools: Optional[list[ChatCompletionFunctionToolParam]] = None
    tool_choice: Optional[ChatCompletionToolChoiceOptionParam] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    timeout: Optional[float] = None
    response_format: Optional[dict[str, Any]] = None
    # OpenAI-specific kwargs
    service_tier: Optional[Literal["auto", "default", "flex", "scale", "priority"]] = None
    reasoning_effort: Optional[OpenAiReasoningEffort] = None
    extra_kwargs: dict[str, Any] = field(default_factory=dict)

    @classmethod
    @override
    def get_known_provider_kwargs(cls) -> frozenset[str]:
        return frozenset({"service_tier", "reasoning_effort"})

    @classmethod
    def from_request(cls, request: ChatCompletionRequest) -> "OpenAiCompletionRequest":
        provider_kwargs = (request.provider_kwargs or {}).get("openai", {})

        # Collect passthrough kwargs (not explicitly handled)
        extra_kwargs = {k: v for k, v in provider_kwargs.items() if k not in cls.get_known_provider_kwargs()}

        # Build response_format from response_schema
        response_format = None
        if request.response_schema is not None:
            response_format = {
                "type": "json_schema",
                "json_schema": {
                    "name": "response_schema",
                    "schema": request.response_schema,
                    "strict": True,
                },
            }

        return cls(
            api_key=request.api_key,
            model=request.model,
            messages=denormalize_conversation_history(request.messages),
            tools=denormalize_tools(request.tools),
            tool_choice=denormalize_tool_choice(request.tool_choice),
            temperature=request.temperature if request.temperature else None,
            max_tokens=request.max_tokens,
            timeout=request.timeout,
            response_format=response_format,
            service_tier=provider_kwargs.get("service_tier"),
            reasoning_effort=provider_kwargs.get("reasoning_effort"),
            extra_kwargs=extra_kwargs,
        )

    @override
    def get_kwargs(self, *, stream: bool = False) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": self.messages,
            "stream": stream,
        }

        if self.tools is not None:
            kwargs["tools"] = self.tools
        if self.tool_choice is not None:
            kwargs["tool_choice"] = self.tool_choice
        if self.temperature is not None:
            kwargs["temperature"] = self.temperature
        if self.max_tokens is not None:
            kwargs["max_tokens"] = self.max_tokens
        if self.timeout is not None:
            kwargs["timeout"] = self.timeout
        if self.response_format is not None:
            kwargs["response_format"] = self.response_format
        if self.service_tier is not None:
            kwargs["service_tier"] = self.service_tier
        if self.reasoning_effort is not None:
            kwargs["reasoning_effort"] = self.reasoning_effort

        if stream:
            kwargs["stream_options"] = {"include_usage": True}
        else:
            kwargs["stream"] = False

        kwargs.update(self.extra_kwargs)
        return kwargs


class OpenAiCompletionClient(CompletionClient):

    @override
    def get_provider(self) -> CompletionsProvider:
        return CompletionsProvider.OPENAI

    @override
    def _denormalize_request(
        self,
        request: ChatCompletionRequest,
    ) -> OpenAiCompletionRequest:
        """Convert ChatCompletionRequest to OpenAiCompletionRequest."""
        return OpenAiCompletionRequest.from_request(request)


    @override
    def _normalize_response(
        self,
        response: ChatCompletion,
    ) -> ChatCompletionResponse:
        """Convert OpenAI ChatCompletion to normalized ChatCompletionResponse."""
        # Take only first choice
        choice: OpenAiChoice = response.choices[0]
        openai_message: OpenAiChatCompletionMessage = choice.message

        normalized_message = AssistantMessage(
            content=openai_message.content,
            tool_calls=normalize_tool_calls(openai_message.tool_calls)
        )

        return ChatCompletionResponse(
            message=normalized_message,
            finish_reason=choice.finish_reason,
            usage=response.usage.model_dump() if response.usage else None
        )


    @override
    async def _get_completion(
        self,
        request: OpenAiCompletionRequest,
    ) -> ChatCompletion:
        """Generate completion using OpenAI client.

        [Client](https://github.com/openai/openai-python)
        """
        try:
            async with AsyncOpenAI(api_key=request.api_key) as client:
                return await client.chat.completions.create(**request.get_kwargs())
        except OpenAIError as e:
            raise map_openai_error(e, provider=self.get_provider()) from e


    @override
    def _get_stream_processor(
        self,
        stream_options: Optional[StreamOptions] = None,
    ) -> OpenAiStreamProcessor:
        """Get openai-specific StreamProcessor."""
        return OpenAiStreamProcessor(stream_options=stream_options)


    @override
    async def _get_completion_stream(
        self,
        request: OpenAiCompletionRequest,
    ) -> AsyncIterator[OpenAiCompletionChunk]:
        """Stream chat completion chunks from OpenAI.

        Note: Creates a client for each stream and ensures proper cleanup
        to prevent resource leaks across multiple turns.
        """
        client = AsyncOpenAI(api_key=request.api_key)

        try:
            stream = await client.chat.completions.create(**request.get_kwargs(stream=True))

            async for chunk in stream:
                yield chunk
        except OpenAIError as e:
            raise map_openai_error(e, provider=self.get_provider()) from e
        finally:
            await client.close()
