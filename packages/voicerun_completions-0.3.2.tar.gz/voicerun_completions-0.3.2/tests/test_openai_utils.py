"""Unit tests for voicerun_completions/providers/openai/utils.py"""
import json
from types import SimpleNamespace

import pytest

from voicerun_completions.providers.openai.utils import (
    denormalize_conversation_history,
    denormalize_tools,
    denormalize_tool_choice,
    denormalize_tool_calls,
    normalize_tool_calls,
)
from voicerun_completions.types.messages import (
    UserMessage,
    AssistantMessage,
    SystemMessage,
    ToolResultMessage,
    ToolCall,
    FunctionCall,
)
from voicerun_completions.types.request import (
    ToolDefinition,
    FunctionDefinition,
)
from voicerun_completions.types.cache import CacheBreakpoint


# =============================================================================
# denormalize_conversation_history
# =============================================================================

class TestDenormalizeConversationHistory:
    def test_user_message(self):
        msgs = [UserMessage(content="Hello")]
        result = denormalize_conversation_history(msgs)
        assert len(result) == 1
        assert result[0]["role"] == "user"
        assert result[0]["content"] == "Hello"

    def test_assistant_message_text_only(self):
        msgs = [AssistantMessage(content="Hi there")]
        result = denormalize_conversation_history(msgs)
        assert result[0]["role"] == "assistant"
        assert result[0]["content"] == "Hi there"
        assert result[0].get("tool_calls") is None

    def test_assistant_message_with_tool_calls(self):
        tc = ToolCall(
            id="call_1", type="function",
            function=FunctionCall(name="get_weather", arguments={"city": "NYC"}),
        )
        msgs = [AssistantMessage(content=None, tool_calls=[tc])]
        result = denormalize_conversation_history(msgs)
        assert result[0]["role"] == "assistant"
        tool_calls = result[0]["tool_calls"]
        assert len(tool_calls) == 1
        assert tool_calls[0]["id"] == "call_1"
        assert tool_calls[0]["function"]["name"] == "get_weather"
        # Arguments should be JSON string in OpenAI format
        assert json.loads(tool_calls[0]["function"]["arguments"]) == {"city": "NYC"}

    def test_system_message(self):
        msgs = [SystemMessage(content="Be helpful")]
        result = denormalize_conversation_history(msgs)
        assert result[0]["role"] == "system"
        assert result[0]["content"] == "Be helpful"

    def test_tool_result_message(self):
        msgs = [ToolResultMessage(tool_call_id="call_1", content={"temp": 72})]
        result = denormalize_conversation_history(msgs)
        assert result[0]["role"] == "tool"
        assert result[0]["tool_call_id"] == "call_1"
        assert json.loads(result[0]["content"]) == {"temp": 72}

    def test_multi_message_preserves_order(self):
        msgs = [
            SystemMessage(content="sys"),
            UserMessage(content="hi"),
            AssistantMessage(content="hello"),
        ]
        result = denormalize_conversation_history(msgs)
        assert [m["role"] for m in result] == ["system", "user", "assistant"]


# =============================================================================
# denormalize_tools
# =============================================================================

class TestDenormalizeTools:
    def test_converts_tool_definitions(self):
        tools = [ToolDefinition(
            type="function",
            function=FunctionDefinition(
                name="get_weather",
                description="Get weather info",
                parameters={"type": "object", "properties": {"city": {"type": "string"}}},
                strict=True,
            ),
        )]
        result = denormalize_tools(tools)
        assert len(result) == 1
        assert result[0]["type"] == "function"
        assert result[0]["function"]["name"] == "get_weather"
        assert result[0]["function"]["strict"] is True

    def test_none_returns_none(self):
        assert denormalize_tools(None) is None


# =============================================================================
# denormalize_tool_choice
# =============================================================================

class TestDenormalizeToolChoice:
    def test_auto(self):
        assert denormalize_tool_choice("auto") == "auto"

    def test_none_literal(self):
        assert denormalize_tool_choice("none") == "none"

    def test_required(self):
        assert denormalize_tool_choice("required") == "required"

    def test_specific_name(self):
        result = denormalize_tool_choice("get_weather")
        assert result["type"] == "function"
        assert result["function"]["name"] == "get_weather"

    def test_none_value_returns_none(self):
        assert denormalize_tool_choice(None) is None


# =============================================================================
# normalize_tool_calls
# =============================================================================

class TestNormalizeToolCalls:
    def test_normalizes_openai_format(self):
        # Simulate OpenAI response objects with attribute access
        denormalized = [
            SimpleNamespace(
                id="call_1",
                type="function",
                function=SimpleNamespace(
                    name="get_weather",
                    arguments='{"city": "NYC"}',
                ),
            ),
        ]
        result = normalize_tool_calls(denormalized)
        assert len(result) == 1
        assert result[0].id == "call_1"
        assert result[0].function.name == "get_weather"
        assert result[0].function.arguments == {"city": "NYC"}
        assert result[0].index == 0

    def test_none_returns_none(self):
        assert normalize_tool_calls(None) is None

    def test_multiple_tool_calls_indexed(self):
        denormalized = [
            SimpleNamespace(
                id="call_1", type="function",
                function=SimpleNamespace(name="fn1", arguments='{}'),
            ),
            SimpleNamespace(
                id="call_2", type="function",
                function=SimpleNamespace(name="fn2", arguments='{"x": 1}'),
            ),
        ]
        result = normalize_tool_calls(denormalized)
        assert len(result) == 2
        assert result[0].index == 0
        assert result[1].index == 1
        assert result[1].function.arguments == {"x": 1}
