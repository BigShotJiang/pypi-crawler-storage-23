"""
Test script to validate streaming functionality.
"""

import os
from typing import Any

import pytest

from voicerun_completions.client import generate_chat_completion, generate_chat_completion_stream
from voicerun_completions.types.messages import (
    ConversationHistory,
    UserMessage,
    AssistantMessage,
    ToolCall,
    FunctionCall,
    SystemMessage,
    ToolResultMessage,
)
from voicerun_completions.types.cache import CacheBreakpoint
from voicerun_completions.types.request import ChatCompletionRequest
from voicerun_completions.types.streaming import FinalResponseChunk


def _get_api_key_or_skip(env_var: str) -> str:
    key = os.environ.get(env_var)
    if not key:
        pytest.skip(f"{env_var} not set")
    return key


PROVIDER_CONFIGS = [
    pytest.param("openai", "OPENAI_API_KEY", "gpt-4.1-mini", id="openai"),
    pytest.param("anthropic", "ANTHROPIC_API_KEY", "claude-haiku-4-5", id="anthropic"),
    pytest.param("google", "GEMINI_API_KEY", "gemini-2.5-flash", id="google"),
]


# =============================================================================
# Active tests (uncommented in original main())
# =============================================================================

@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming_long(provider, env_var, model):
    """Test streaming functionality with long response."""
    api_key = _get_api_key_or_skip(env_var)

    stream = await generate_chat_completion_stream(
        request={
            "provider": provider,
            "api_key": api_key,
            "model": model,
            "messages": [{"role": "user", "content": "Tell me a 500 word story"}],
        },
    )

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
async def test_streaming_long_google_sentences():
    """Test streaming with long response and sentence chunking (Google)."""
    api_key = _get_api_key_or_skip("GEMINI_API_KEY")

    stream = await generate_chat_completion_stream(
        request={
            "provider": "google",
            "api_key": api_key,
            "model": "gemini-2.5-flash",
            "messages": [{"role": "user", "content": "Tell me a 500 word story"}],
        },
        stream_options={
            "stream_sentences": True,
            "clean_sentences": True,
        },
    )

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_non_streaming(provider, env_var, model):
    """Test that existing non-streaming functionality still works."""
    api_key = _get_api_key_or_skip(env_var)

    response = await generate_chat_completion({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "Hello!"}],
    })
    assert response.message is not None


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming(provider, env_var, model):
    """Test the streaming functionality with sentence chunking."""
    api_key = _get_api_key_or_skip(env_var)

    stream = await generate_chat_completion_stream(
        request={
            "provider": provider,
            "api_key": api_key,
            "model": model,
            "messages": [{"role": "user", "content": "Say hello in five different languages."}],
        },
        stream_options={
            "stream_sentences": True,
            "clean_sentences": True,
        },
    )

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming_whitespace(provider, env_var, model):
    """Test streaming functionality with potential whitespace."""
    api_key = _get_api_key_or_skip(env_var)

    stream = await generate_chat_completion_stream(
        ChatCompletionRequest(
            provider=provider,
            api_key=api_key,
            model=model,
            messages=[{"role": "user", "content": "Count to 5 slowly"}],
        ),
    )

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming_dollars(provider, env_var, model):
    """Test streaming functionality with dollar amounts."""
    api_key = _get_api_key_or_skip(env_var)

    stream = await generate_chat_completion_stream(
        request={
            "provider": provider,
            "api_key": api_key,
            "model": model,
            "messages": [{
                "role": "user",
                "content": "Could you tell me the price of a single bitcoin for years 2015-2020 with $XX.XX precision. Complete sentences. No special formatting."
            }],
        },
        stream_options={
            "stream_sentences": True,
            "clean_sentences": True,
            "min_sentence_length": 0,
        },
    )

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming_with_tools(provider, env_var, model):
    """Test streaming with tool calls."""
    api_key = _get_api_key_or_skip(env_var)

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"],
                },
            },
        }
    ]

    stream = await generate_chat_completion_stream({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "What's the weather in NYC and in Boston?"}],
        "tools": tools,
        "tool_choice": "auto",
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
async def test_streaming_with_tools_and_content():
    """Test streaming with tool calls and content (OpenAI only)."""
    api_key = _get_api_key_or_skip("OPENAI_API_KEY")

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"],
                },
            },
        }
    ]

    stream = await generate_chat_completion_stream({
        "provider": "openai",
        "api_key": api_key,
        "model": "gpt-4.1-mini",
        "messages": [{"role": "user", "content": "Call get_weather and say Hello World in content in your response."}],
        "tools": tools,
        "tool_choice": "auto",
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_caching_with_tools_stream(provider, env_var, model):
    """Test caching with tool calls (streaming)."""
    api_key = _get_api_key_or_skip(env_var)

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"],
                },
            },
            "cache_breakpoint": {"ttl": "5m"},
        }
    ]

    messages: list[dict[str, Any]] = [
        {
            "role": "system",
            "content": "Give a summary of the user's content.",
            "cache_breakpoint": {"ttl": "5m"},
        },
        {
            "role": "user",
            "content": "<insert 4000 tokens here>",
            "cache_breakpoint": {"ttl": "5m"},
        },
    ]

    stream = await generate_chat_completion_stream({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": messages,
        "tools": tools,
        "tool_choice": "auto",
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_caching_with_tools_non_stream(provider, env_var, model):
    """Test caching with tool calls (non-streaming)."""
    api_key = _get_api_key_or_skip(env_var)

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"],
                },
            },
            "cache_breakpoint": {"ttl": "5m"},
        }
    ]

    messages: list[dict[str, Any]] = [
        {
            "role": "system",
            "content": "Give a summary of the user's content.",
            "cache_breakpoint": {"ttl": "5m"},
        },
        {
            "role": "user",
            "content": "<insert 4000 tokens here>",
            "cache_breakpoint": {"ttl": "5m"},
        },
    ]

    response = await generate_chat_completion({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": messages,
        "tools": tools,
        "tool_choice": "auto",
    })
    assert response is not None


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_cache_breakpoints_stream(provider, env_var, model):
    """Test cache breakpoints with typed messages (streaming)."""
    api_key = _get_api_key_or_skip(env_var)

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"],
                },
            },
            "cache_breakpoint": {"ttl": "5m"},
        }
    ]

    messages: ConversationHistory = [
        SystemMessage(
            content="Answer the user's question.",
            cache_breakpoint=CacheBreakpoint(ttl="5m"),
        ),
        UserMessage(content="What's the weather in NYC?"),
        AssistantMessage(
            content=None,
            tool_calls=[ToolCall(
                id="toolcall_0",
                type="function",
                index=0,
                function=FunctionCall(
                    name="get_weather",
                    arguments={"location": "NYC"},
                ),
            )],
        ),
        ToolResultMessage(
            tool_call_id="toolcall_0",
            name="get_weather",
            content={"success": True, "weather": "75 degrees and sunny"},
        ),
        UserMessage(
            content="Thanks.",
            cache_breakpoint=CacheBreakpoint(ttl="5m"),
        ),
    ]

    stream = await generate_chat_completion_stream({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": messages,
        "tools": tools,
        "tool_choice": "auto",
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_cache_breakpoints_non_stream(provider, env_var, model):
    """Test cache breakpoints with typed messages (non-streaming)."""
    api_key = _get_api_key_or_skip(env_var)

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"],
                },
            },
            "cache_breakpoint": {"ttl": "5m"},
        }
    ]

    messages: ConversationHistory = [
        SystemMessage(
            content="Answer the user's question.",
            cache_breakpoint=CacheBreakpoint(ttl="5m"),
        ),
        UserMessage(content="What's the weather in NYC?"),
        AssistantMessage(
            content=None,
            tool_calls=[ToolCall(
                id="toolcall_0",
                type="function",
                index=0,
                function=FunctionCall(
                    name="get_weather",
                    arguments={"location": "NYC"},
                ),
            )],
        ),
        ToolResultMessage(
            tool_call_id="toolcall_0",
            name="get_weather",
            content={"success": True, "weather": "75 degrees and sunny"},
        ),
        UserMessage(
            content="Thanks.",
            cache_breakpoint=CacheBreakpoint(ttl="5m"),
        ),
    ]

    response = await generate_chat_completion({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": messages,
        "tools": tools,
        "tool_choice": "auto",
    })
    assert response is not None


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming_empty_tool(provider, env_var, model):
    """Test streaming with tool that has no parameters."""
    api_key = _get_api_key_or_skip(env_var)

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_order_total",
                "description": "Calculate final order total with taxes and fees",
                "parameters": {"type": "object", "properties": {}},
            },
        }
    ]

    stream = await generate_chat_completion_stream({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "Can you check my order total."}],
        "tools": tools,
        "tool_choice": "auto",
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming_multi_turn(provider, env_var, model):
    """Test streaming functionality with multiple turns in the conversation."""
    api_key = _get_api_key_or_skip(env_var)

    messages: list[dict[str, Any]] = []
    user_prompts = [
        "Hello! Can you tell me what 2+2 is?",
        "Great! Now what about 5*5?",
        "Perfect! Can you summarize our conversation so far?",
    ]

    for user_prompt in user_prompts:
        messages.append({"role": "user", "content": user_prompt})

        stream = await generate_chat_completion_stream(
            {
                "provider": provider,
                "api_key": api_key,
                "model": model,
                "messages": messages,
            },
        )

        chunk_count = 0
        full_response = None

        async for chunk in stream:
            chunk_count += 1
            if isinstance(chunk, FinalResponseChunk):
                full_response = chunk.response.message.content

        assert chunk_count > 0

        if full_response:
            messages.append({"role": "assistant", "content": full_response})


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_thought_signature_stream(provider, env_var, model):
    """Test thought signature (streaming)."""
    api_key = _get_api_key_or_skip(env_var)

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"],
                },
            },
        }
    ]

    stream = await generate_chat_completion_stream({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "What's the weather in NYC and in Boston?"}],
        "tools": tools,
        "tool_choice": "auto",
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_thought_signature_non_stream(provider, env_var, model):
    """Test thought signature (non-streaming)."""
    api_key = _get_api_key_or_skip(env_var)

    tools: list[dict[str, Any]] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"],
                },
            },
        }
    ]

    response = await generate_chat_completion({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "What's the weather in NYC and in Boston?"}],
        "tools": tools,
        "tool_choice": "auto",
    })
    assert response is not None
