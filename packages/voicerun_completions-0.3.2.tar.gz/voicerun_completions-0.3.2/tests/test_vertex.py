"""
Test script for Anthropic Vertex AI provider.
Requires: GCP_SERVICE_ACCOUNT_JSON env var with service account key JSON.
"""

import os

import pytest

from voicerun_completions.client import generate_chat_completion_stream
from voicerun_completions.types.request import ToolDefinitionDict


# =============================================================================
# Unit Tests
# =============================================================================

async def test_missing_credentials():
    """Verify that omitting service_account_credentials raises an error."""
    with pytest.raises(Exception, match="service_account_credentials"):
        stream = await generate_chat_completion_stream({
            "provider": "anthropic_vertex",
            "api_key": "",
            "model": "claude-opus-4-5@20251101",
            "messages": [{"role": "user", "content": "Hello"}],
            "provider_kwargs": {
                "anthropic_vertex": {
                    "region": "us-east5",
                    "project_id": "some-project",
                    # service_account_credentials intentionally omitted
                }
            }
        })
        # Must iterate to trigger _denormalize_request
        async for _ in stream:
            pass


# =============================================================================
# Integration Tests - Requires GCP credentials
# =============================================================================

@pytest.mark.integration
@pytest.mark.parametrize("region", ["us-east5", "asia-southeast1"])
async def test_anthropic_vertex(region, gcp_service_account_json, gcp_project_id):
    """Test Anthropic Vertex AI provider."""
    stream = await generate_chat_completion_stream(
        {
            "provider": "anthropic_vertex",
            "api_key": "",  # Not used - auth via service account
            "model": "claude-opus-4-5@20251101",
            "messages": [{"role": "user", "content": "Say hello in one sentence."}],
            "provider_kwargs": {
                "anthropic_vertex": {
                    "region": region,
                    "project_id": gcp_project_id,
                    "service_account_credentials": gcp_service_account_json,
                }
            }
        },
    )

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
async def test_anthropic_vertex_with_tools(gcp_service_account_json, gcp_project_id):
    """Test Anthropic Vertex AI provider with tool calls."""
    tools: list[ToolDefinitionDict] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"]
                }
            }
        }
    ]

    stream = await generate_chat_completion_stream({
        "provider": "anthropic_vertex",
        "api_key": "",  # Not used - auth via service account
        "model": "claude-opus-4-5@20251101",
        "messages": [{"role": "user", "content": "What's the weather in NYC?"}],
        "tools": tools,
        "tool_choice": "auto",
        "provider_kwargs": {
            "anthropic_vertex": {
                "region": "us-east5",
                "project_id": gcp_project_id,
                "service_account_credentials": gcp_service_account_json,
            }
        }
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0
