"""Unit tests for voicerun_completions/providers/google/utils.py (non-sanitize functions)"""
import pytest

from voicerun_completions.providers.google.utils import (
    denormalize_conversation_history,
    denormalize_tools,
    denormalize_tool_choice,
)
from voicerun_completions.types.messages import (
    UserMessage,
    AssistantMessage,
    SystemMessage,
    ToolResultMessage,
    ToolCall,
    FunctionCall,
)
from voicerun_completions.types.request import (
    ToolDefinition,
    FunctionDefinition,
)


# =============================================================================
# denormalize_conversation_history
# =============================================================================

class TestDenormalizeConversationHistory:
    def test_user_message(self):
        msgs = [UserMessage(content="Hello")]
        contents, system_instruction = denormalize_conversation_history(msgs)
        assert len(contents) == 1
        assert contents[0].role == "user"
        assert len(contents[0].parts) == 1
        assert contents[0].parts[0].text == "Hello"

    def test_assistant_message_text(self):
        msgs = [AssistantMessage(content="Hi there")]
        contents, _ = denormalize_conversation_history(msgs)
        assert contents[0].role == "model"
        assert contents[0].parts[0].text == "Hi there"

    def test_assistant_message_with_tool_calls(self):
        tc = ToolCall(
            id="call_1", type="function",
            function=FunctionCall(name="get_weather", arguments={"city": "NYC"}),
        )
        msgs = [AssistantMessage(content=None, tool_calls=[tc])]
        contents, _ = denormalize_conversation_history(msgs)
        assert contents[0].role == "model"
        parts = contents[0].parts
        assert len(parts) == 1
        # The part should be a function_call part
        assert parts[0].function_call is not None
        assert parts[0].function_call.name == "get_weather"

    def test_assistant_message_with_tool_calls_thought_signature_fallback(self):
        # When no thought_signature, first tool call should get fallback
        tc = ToolCall(
            id="call_1", type="function",
            function=FunctionCall(name="fn", arguments={}),
        )
        msgs = [AssistantMessage(content=None, tool_calls=[tc])]
        contents, _ = denormalize_conversation_history(msgs)
        part = contents[0].parts[0]
        assert part.thought_signature == b"skip_thought_signature_validator"

    def test_system_message_extracted(self):
        msgs = [SystemMessage(content="Be helpful"), UserMessage(content="hi")]
        contents, system_instruction = denormalize_conversation_history(msgs)
        assert system_instruction == "Be helpful"
        # System message should not appear in contents
        assert len(contents) == 1
        assert contents[0].role == "user"

    def test_multiple_system_messages_joined(self):
        msgs = [
            SystemMessage(content="Rule 1"),
            SystemMessage(content="Rule 2"),
            UserMessage(content="hi"),
        ]
        _, system_instruction = denormalize_conversation_history(msgs)
        assert system_instruction == "Rule 1\nRule 2"

    def test_tool_result_message(self):
        msgs = [ToolResultMessage(tool_call_id="call_1", content={"temp": 72}, name="get_weather")]
        contents, _ = denormalize_conversation_history(msgs)
        assert len(contents) == 1
        assert contents[0].role == "user"
        part = contents[0].parts[0]
        assert part.function_response is not None

    def test_no_system_messages_returns_none(self):
        msgs = [UserMessage(content="hi")]
        _, system_instruction = denormalize_conversation_history(msgs)
        assert system_instruction is None


# =============================================================================
# denormalize_tools
# =============================================================================

class TestDenormalizeTools:
    def test_wraps_in_single_tool(self):
        tools = [
            ToolDefinition(
                type="function",
                function=FunctionDefinition(
                    name="get_weather",
                    description="Get weather",
                    parameters={"type": "object", "properties": {"city": {"type": "string"}}},
                ),
            ),
            ToolDefinition(
                type="function",
                function=FunctionDefinition(
                    name="search",
                    description="Search",
                    parameters={"type": "object", "properties": {}},
                ),
            ),
        ]
        result = denormalize_tools(tools)
        # Google wraps all function declarations in a single Tool
        assert len(result) == 1
        assert len(result[0].function_declarations) == 2

    def test_none_returns_none(self):
        assert denormalize_tools(None) is None


# =============================================================================
# denormalize_tool_choice
# =============================================================================

class TestDenormalizeToolChoice:
    def test_auto(self):
        result = denormalize_tool_choice("auto")
        assert result.function_calling_config.mode == "AUTO"

    def test_none_literal(self):
        result = denormalize_tool_choice("none")
        assert result.function_calling_config.mode == "NONE"

    def test_required_maps_to_any(self):
        result = denormalize_tool_choice("required")
        assert result.function_calling_config.mode == "ANY"

    def test_specific_name(self):
        result = denormalize_tool_choice("get_weather")
        assert result.function_calling_config.mode == "ANY"
        assert result.function_calling_config.allowed_function_names == ["get_weather"]

    def test_none_value_returns_none(self):
        assert denormalize_tool_choice(None) is None


# =============================================================================
# GoogleStreamProcessor._process_chunk edge cases
# =============================================================================

class TestGoogleStreamProcessorChunk:
    """Tests for GoogleStreamProcessor._process_chunk with mock Google types."""

    def _make_processor(self):
        from voicerun_completions.providers.google.stream_processor import GoogleStreamProcessor
        return GoogleStreamProcessor()

    def _make_chunk(self, *, finish_reason=None, content=None, candidates=True, usage_metadata=None):
        """Build a lightweight mock GoogleResponseChunk."""
        import types

        chunk = types.SimpleNamespace(usage_metadata=usage_metadata, candidates=None)
        if candidates:
            # finish_reason needs a .value attribute (it's an enum in real code)
            fr = None
            if finish_reason:
                fr = types.SimpleNamespace(value=finish_reason)

            candidate = types.SimpleNamespace(
                finish_reason=fr,
                content=content,
            )
            chunk.candidates = [candidate]
        return chunk

    def test_finish_reason_captured_when_content_is_none(self):
        """Finish reason on candidate should be captured even when content is None."""
        processor = self._make_processor()
        chunk = self._make_chunk(finish_reason="STOP", content=None)

        result = processor._process_chunk(chunk)

        assert result == []  # No content chunks emitted
        assert processor.finish_reason == "stop"

    def test_finish_reason_captured_when_content_has_no_parts(self):
        """Finish reason should be captured even when content.parts is None."""
        import types
        processor = self._make_processor()
        content = types.SimpleNamespace(parts=None)
        chunk = self._make_chunk(finish_reason="STOP", content=content)

        result = processor._process_chunk(chunk)

        assert result == []
        assert processor.finish_reason == "stop"

    def test_no_candidates_returns_empty(self):
        """Chunk with no candidates should return empty list."""
        processor = self._make_processor()
        chunk = self._make_chunk(candidates=False)

        result = processor._process_chunk(chunk)

        assert result == []
        assert processor.finish_reason == ""
