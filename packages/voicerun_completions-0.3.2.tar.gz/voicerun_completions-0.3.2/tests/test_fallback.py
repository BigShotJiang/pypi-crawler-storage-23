"""
Test script to validate fallback functionality.
"""

import pytest

from voicerun_completions.client import generate_chat_completion, generate_chat_completion_stream
from voicerun_completions.types.request import (
    ChatCompletionRequest,
    FallbackRequest,
    CompletionsProvider,
    RetryConfiguration,
)


# =============================================================================
# Unit Tests - No API calls
# =============================================================================

def test_apply_fallback_overrides_provider():
    """Test that fallback overrides provider correctly."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )

    fallback = FallbackRequest(
        provider=CompletionsProvider.ANTHROPIC,
        api_key="anthropic-key",
        model="claude-3",
    )

    result = request._apply_fallback(fallback)

    assert result.provider == CompletionsProvider.ANTHROPIC
    assert result.api_key == "anthropic-key"
    assert result.model == "claude-3"
    assert result.messages == request.messages  # Should inherit
    assert result.fallbacks is None  # Should not carry forward


def test_apply_fallback_preserves_unset_fields():
    """Test that fallback preserves fields not set in fallback."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        temperature=0.7,
        max_tokens=1000,
        timeout=30.0,
    )

    fallback = FallbackRequest(
        provider=CompletionsProvider.ANTHROPIC,
        # Only override provider, keep everything else
    )

    result = request._apply_fallback(fallback)

    assert result.provider == CompletionsProvider.ANTHROPIC
    assert result.api_key == "openai-key"  # Inherited
    assert result.model == "gpt-4"  # Inherited
    assert result.temperature == 0.7  # Inherited
    assert result.max_tokens == 1000  # Inherited
    assert result.timeout == 30.0  # Inherited


def test_apply_fallback_handles_falsy_values():
    """Test that fallback correctly handles falsy values like 0 or False."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        temperature=0.7,
    )

    fallback = FallbackRequest(
        temperature=0.0,  # Falsy but valid
    )

    result = request._apply_fallback(fallback)

    assert result.temperature == 0.0  # Should be 0, not 0.7


def test_build_completion_attempts_single():
    """Test building attempts with no fallbacks."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )

    attempts = request._build_completion_attempts()

    assert len(attempts) == 1
    assert attempts[0].provider == CompletionsProvider.OPENAI


def test_build_completion_attempts_with_fallbacks():
    """Test building attempts with multiple fallbacks."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        fallbacks=[
            FallbackRequest(
                provider=CompletionsProvider.ANTHROPIC,
                api_key="anthropic-key",
                model="claude-3",
            ),
            FallbackRequest(
                provider=CompletionsProvider.GOOGLE,
                api_key="google-key",
                model="gemini-pro",
            ),
        ],
    )

    attempts = request._build_completion_attempts()

    assert len(attempts) == 3
    assert attempts[0].provider == CompletionsProvider.OPENAI
    assert attempts[1].provider == CompletionsProvider.ANTHROPIC
    assert attempts[2].provider == CompletionsProvider.GOOGLE
    # Verify fallbacks are not carried forward
    assert attempts[1].fallbacks is None
    assert attempts[2].fallbacks is None


def test_normalize_retry_from_dict():
    """Test that retry config is normalized from dict."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        retry={"max_retries": 5, "retry_delay": 2.0},
    )

    request._normalize()

    assert isinstance(request.retry, RetryConfiguration)
    assert request.retry.max_retries == 5
    assert request.retry.retry_delay == 2.0


# =============================================================================
# Integration Tests - Requires API keys
# =============================================================================

@pytest.mark.integration
async def test_fallback_on_invalid_api_key(anthropic_api_key):
    """Test that fallback is triggered when first provider fails with invalid key."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": "invalid-key-12345",
        "model": "gpt-4",
        "messages": [{"role": "user", "content": "Hello"}],
        "fallbacks": [
            {
                "provider": "anthropic",
                "api_key": anthropic_api_key,
                "model": "claude-haiku-4-5",
            }
        ],
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_fallback_streaming_on_invalid_api_key(anthropic_api_key):
    """Test that streaming fallback is triggered when first provider fails."""
    stream = await generate_chat_completion_stream({
        "provider": "openai",
        "api_key": "invalid-key-12345",
        "model": "gpt-4",
        "messages": [{"role": "user", "content": "Say hello briefly"}],
        "fallbacks": [
            {
                "provider": "anthropic",
                "api_key": anthropic_api_key,
                "model": "claude-haiku-4-5",
            }
        ],
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
async def test_fallback_chain(gemini_api_key):
    """Test fallback chain with multiple providers."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": "invalid-key-1",
        "model": "gpt-4",
        "messages": [{"role": "user", "content": "Hello"}],
        "fallbacks": [
            {
                "provider": "anthropic",
                "api_key": "invalid-key-2",
                "model": "claude-3",
            },
            {
                "provider": "google",
                "api_key": gemini_api_key,
                "model": "gemini-2.0-flash",
            }
        ],
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_no_fallback_on_success(openai_api_key, anthropic_api_key):
    """Test that fallback is not triggered when first provider succeeds."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": openai_api_key,
        "model": "gpt-4.1-mini",
        "messages": [{"role": "user", "content": "Say 'primary provider' exactly"}],
        "fallbacks": [
            {
                "provider": "anthropic",
                "api_key": anthropic_api_key,
                "model": "claude-haiku-4-5",
            }
        ],
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_retry_with_fallback(anthropic_api_key):
    """Test retry configuration combined with fallback."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": "invalid-key",
        "model": "gpt-4",
        "messages": [{"role": "user", "content": "Hello"}],
        "retry": {
            "max_retries": 2,
            "retry_delay": 0.5,
        },
        "fallbacks": [
            {
                "provider": "anthropic",
                "api_key": anthropic_api_key,
                "model": "claude-haiku-4-5",
            }
        ],
    })
    assert response.message is not None
    assert response.message.content is not None
