"""
Tests for Google tool parameter schema sanitization.
"""

import pytest

from voicerun_completions.providers.google.utils import sanitize_parameters_schema
from voicerun_completions.types.errors import InvalidToolError


# =============================================================================
# additionalProperties
# =============================================================================

def test_strips_additional_properties_false():
    schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "additionalProperties": False,
    }
    result = sanitize_parameters_schema(schema)
    assert "additionalProperties" not in result


def test_raises_on_additional_properties_true():
    schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "additionalProperties": True,
    }
    with pytest.raises(InvalidToolError):
        sanitize_parameters_schema(schema)


def test_strips_nested_additional_properties_false():
    schema = {
        "type": "object",
        "properties": {
            "location": {
                "type": "object",
                "properties": {"city": {"type": "string"}},
                "additionalProperties": False,
            },
        },
        "additionalProperties": False,
    }
    result = sanitize_parameters_schema(schema)
    assert "additionalProperties" not in result
    assert "additionalProperties" not in result["properties"]["location"]


# =============================================================================
# const → single-value enum
# =============================================================================

def test_converts_const_to_enum():
    schema = {
        "type": "object",
        "properties": {
            "unit": {"type": "string", "const": "celsius"},
        },
    }
    result = sanitize_parameters_schema(schema)
    assert "const" not in result["properties"]["unit"]
    assert result["properties"]["unit"]["enum"] == ["celsius"]


def test_converts_numeric_const_to_string_enum():
    schema = {
        "type": "object",
        "properties": {
            "version": {"type": "integer", "const": 2},
        },
    }
    result = sanitize_parameters_schema(schema)
    assert result["properties"]["version"]["enum"] == ["2"]


# =============================================================================
# allOf
# =============================================================================

def test_raises_on_allof():
    schema = {
        "type": "object",
        "properties": {
            "location": {"allOf": [{"type": "string"}]},
        },
    }
    with pytest.raises(InvalidToolError):
        sanitize_parameters_schema(schema)


# =============================================================================
# Union type arrays → nullable
# =============================================================================

def test_converts_nullable_union_type():
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": ["string", "null"]},
        },
    }
    result = sanitize_parameters_schema(schema)
    assert result["properties"]["name"]["type"] == "string"
    assert result["properties"]["name"]["nullable"] is True


def test_converts_union_type_null_first():
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": ["null", "string"]},
        },
    }
    result = sanitize_parameters_schema(schema)
    assert result["properties"]["name"]["type"] == "string"
    assert result["properties"]["name"]["nullable"] is True


def test_converts_non_nullable_single_type_array():
    """A single-element type array without null."""
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": ["string"]},
        },
    }
    result = sanitize_parameters_schema(schema)
    assert result["properties"]["name"]["type"] == "string"
    assert "nullable" not in result["properties"]["name"]


def test_converts_multi_type_union_takes_first():
    """Multiple non-null types — takes the first."""
    schema = {
        "type": "object",
        "properties": {
            "value": {"type": ["string", "integer", "null"]},
        },
    }
    result = sanitize_parameters_schema(schema)
    assert result["properties"]["value"]["type"] == "string"
    assert result["properties"]["value"]["nullable"] is True


# =============================================================================
# Non-string enum values
# =============================================================================

def test_raises_on_integer_enum():
    schema = {
        "type": "object",
        "properties": {
            "days": {"type": "integer", "enum": [1, 3, 5, 7]},
        },
    }
    with pytest.raises(InvalidToolError):
        sanitize_parameters_schema(schema)


def test_raises_on_mixed_enum():
    schema = {
        "type": "object",
        "properties": {
            "value": {"enum": ["auto", 0, True]},
        },
    }
    with pytest.raises(InvalidToolError):
        sanitize_parameters_schema(schema)


def test_allows_string_enum():
    schema = {
        "type": "object",
        "properties": {
            "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
        },
    }
    result = sanitize_parameters_schema(schema)
    assert result["properties"]["unit"]["enum"] == ["celsius", "fahrenheit"]


# =============================================================================
# Recursion into nested structures
# =============================================================================

def test_sanitizes_array_items():
    schema = {
        "type": "object",
        "properties": {
            "tags": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {"name": {"type": "string"}},
                    "additionalProperties": False,
                },
            },
        },
    }
    result = sanitize_parameters_schema(schema)
    assert "additionalProperties" not in result["properties"]["tags"]["items"]


def test_sanitizes_anyof_variants():
    schema = {
        "type": "object",
        "properties": {
            "location": {
                "anyOf": [
                    {"type": "string"},
                    {
                        "type": "object",
                        "properties": {"lat": {"type": "number"}},
                        "additionalProperties": False,
                    },
                ],
            },
        },
    }
    result = sanitize_parameters_schema(schema)
    assert "additionalProperties" not in result["properties"]["location"]["anyOf"][1]


# =============================================================================
# Does not mutate original
# =============================================================================

def test_does_not_mutate_original():
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": ["string", "null"]},
        },
        "additionalProperties": False,
    }
    sanitize_parameters_schema(schema)
    assert schema["additionalProperties"] is False
    assert schema["properties"]["name"]["type"] == ["string", "null"]


# =============================================================================
# Passthrough — supported fields are preserved
# =============================================================================

def test_preserves_supported_fields():
    schema = {
        "type": "object",
        "properties": {
            "location": {
                "type": "string",
                "description": "City name",
                "minLength": 1,
                "maxLength": 100,
                "pattern": "^[A-Za-z ]+$",
                "format": "date",
                "default": "New York",
            },
            "days": {
                "type": "integer",
                "minimum": 1,
                "maximum": 7,
            },
        },
        "required": ["location"],
    }
    result = sanitize_parameters_schema(schema)
    loc = result["properties"]["location"]
    assert loc["description"] == "City name"
    assert loc["minLength"] == 1
    assert loc["maxLength"] == 100
    assert loc["pattern"] == "^[A-Za-z ]+$"
    assert loc["format"] == "date"
    assert loc["default"] == "New York"
    assert result["properties"]["days"]["minimum"] == 1
    assert result["properties"]["days"]["maximum"] == 7
    assert result["required"] == ["location"]
