"""
Tests for Alibaba Qwen (DashScope) provider.
Integration tests require: DASHSCOPE_API_KEY env var.
"""

import pytest

from voicerun_completions.client import _get_client, generate_chat_completion, generate_chat_completion_stream
from voicerun_completions.types.request import (
    ChatCompletionRequest,
    CompletionsProvider,
    ToolDefinitionDict,
)
from voicerun_completions.providers.alibaba.client import (
    AlibabaCompletionClient,
    AlibabaCompletionRequest,
    DASHSCOPE_DEFAULT_BASE_URL,
)


# =============================================================================
# Unit Tests
# =============================================================================


class TestGetClientAlibaba:
    def test_returns_alibaba_client(self):
        client = _get_client(CompletionsProvider.ALIBABA)
        assert isinstance(client, AlibabaCompletionClient)

    def test_provider_enum(self):
        client = AlibabaCompletionClient()
        assert client.get_provider() == CompletionsProvider.ALIBABA


class TestAlibabaCompletionRequest:
    def test_from_request_defaults(self):
        """Default base_url is the Singapore intl endpoint."""
        request = ChatCompletionRequest(
            provider=CompletionsProvider.ALIBABA,
            api_key="test-key",
            model="qwen3.5-plus",
            messages=[{"role": "user", "content": "Hello"}],
        )
        request._normalize()

        alibaba_req = AlibabaCompletionRequest.from_request(request)

        assert alibaba_req.api_key == "test-key"
        assert alibaba_req.model == "qwen3.5-plus"
        assert alibaba_req.base_url == DASHSCOPE_DEFAULT_BASE_URL
        assert alibaba_req.enable_search is None

    def test_custom_base_url(self):
        """Custom base_url overrides the default."""
        us_endpoint = "https://dashscope-us.aliyuncs.com/compatible-mode/v1"
        request = ChatCompletionRequest(
            provider=CompletionsProvider.ALIBABA,
            api_key="test-key",
            model="qwen3.5-plus",
            messages=[{"role": "user", "content": "Hello"}],
            provider_kwargs={
                "alibaba": {"base_url": us_endpoint},
            },
        )
        request._normalize()

        alibaba_req = AlibabaCompletionRequest.from_request(request)
        assert alibaba_req.base_url == us_endpoint

    def test_enable_search_kwarg(self):
        """enable_search is passed through to get_kwargs as extra_body."""
        request = ChatCompletionRequest(
            provider=CompletionsProvider.ALIBABA,
            api_key="test-key",
            model="qwen3.5-plus",
            messages=[{"role": "user", "content": "Hello"}],
            provider_kwargs={
                "alibaba": {"enable_search": True},
            },
        )
        request._normalize()

        alibaba_req = AlibabaCompletionRequest.from_request(request)
        assert alibaba_req.enable_search is True

        kwargs = alibaba_req.get_kwargs()
        assert kwargs["extra_body"]["enable_search"] is True

    def test_enable_search_not_in_kwargs_when_none(self):
        """When enable_search is not set, extra_body should not contain it."""
        request = ChatCompletionRequest(
            provider=CompletionsProvider.ALIBABA,
            api_key="test-key",
            model="qwen3.5-plus",
            messages=[{"role": "user", "content": "Hello"}],
        )
        request._normalize()

        alibaba_req = AlibabaCompletionRequest.from_request(request)
        kwargs = alibaba_req.get_kwargs()
        assert "extra_body" not in kwargs

    def test_passthrough_kwargs(self):
        """Unknown kwargs are passed through via extra_kwargs."""
        request = ChatCompletionRequest(
            provider=CompletionsProvider.ALIBABA,
            api_key="test-key",
            model="qwen3.5-plus",
            messages=[{"role": "user", "content": "Hello"}],
            provider_kwargs={
                "alibaba": {"top_k": 50},
            },
        )
        request._normalize()

        alibaba_req = AlibabaCompletionRequest.from_request(request)
        kwargs = alibaba_req.get_kwargs()
        assert kwargs["top_k"] == 50

    def test_denormalize_via_client(self):
        """AlibabaCompletionClient._denormalize_request produces AlibabaCompletionRequest."""
        request = ChatCompletionRequest(
            provider=CompletionsProvider.ALIBABA,
            api_key="test-key",
            model="qwen3.5-plus",
            messages=[{"role": "user", "content": "Hello"}],
            provider_kwargs={
                "alibaba": {"enable_search": True},
            },
        )
        request._normalize()

        client = AlibabaCompletionClient()
        denormalized = client._denormalize_request(request)

        assert isinstance(denormalized, AlibabaCompletionRequest)
        assert denormalized.enable_search is True
        assert denormalized.base_url == DASHSCOPE_DEFAULT_BASE_URL


# =============================================================================
# Integration Tests - Requires DASHSCOPE_API_KEY
# =============================================================================


@pytest.mark.integration
async def test_alibaba_completion(dashscope_api_key):
    """Test basic non-streaming completion via DashScope."""
    response = await generate_chat_completion({
        "provider": "alibaba",
        "api_key": dashscope_api_key,
        "model": "qwen3.5-plus",
        "messages": [{"role": "user", "content": "Say hello in one sentence."}],
    })

    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_alibaba_streaming(dashscope_api_key):
    """Test streaming completion via DashScope."""
    stream = await generate_chat_completion_stream({
        "provider": "alibaba",
        "api_key": dashscope_api_key,
        "model": "qwen3.5-plus",
        "messages": [{"role": "user", "content": "Count from 1 to 5."}],
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
async def test_alibaba_with_enable_search(dashscope_api_key):
    """Test completion with enable_search enabled."""
    response = await generate_chat_completion({
        "provider": "alibaba",
        "api_key": dashscope_api_key,
        "model": "qwen3.5-plus",
        "messages": [{"role": "user", "content": "What is the weather in Singapore today?"}],
        "provider_kwargs": {
            "alibaba": {"enable_search": True},
        },
    })

    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_alibaba_custom_base_url(dashscope_api_key):
    """Test completion with a custom regional endpoint."""
    response = await generate_chat_completion({
        "provider": "alibaba",
        "api_key": dashscope_api_key,
        "model": "qwen3.5-plus",
        "messages": [{"role": "user", "content": "Say hello in one sentence."}],
        "provider_kwargs": {
            "alibaba": {
                "base_url": "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
            },
        },
    })

    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_alibaba_with_tools(dashscope_api_key):
    """Test completion with tool calling (non-streaming, since DashScope has tools+stream limitation)."""
    tools: list[ToolDefinitionDict] = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"]
                }
            }
        }
    ]

    response = await generate_chat_completion({
        "provider": "alibaba",
        "api_key": dashscope_api_key,
        "model": "qwen3.5-plus",
        "messages": [{"role": "user", "content": "What's the weather in NYC?"}],
        "tools": tools,
        "tool_choice": "auto",
    })

    assert response.message is not None
