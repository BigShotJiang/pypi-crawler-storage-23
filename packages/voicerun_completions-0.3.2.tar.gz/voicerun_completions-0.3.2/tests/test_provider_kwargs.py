"""
Test script to validate provider_kwargs functionality.
"""

import os

import pytest

from voicerun_completions.client import generate_chat_completion, generate_chat_completion_stream
from voicerun_completions.types.request import (
    ChatCompletionRequest,
    FallbackRequest,
    CompletionsProvider,
    ProviderKwargs,
)
from voicerun_completions.providers.openai.client import OpenAiCompletionClient
from voicerun_completions.providers.anthropic.client import AnthropicCompletionClient
from voicerun_completions.providers.google.client import GoogleCompletionClient


# =============================================================================
# Unit Tests - No API calls
# =============================================================================

def test_provider_kwargs_structure():
    """Test that ProviderKwargs can be constructed with typed dicts."""
    kwargs: ProviderKwargs = {
        "openai": {"service_tier": "flex", "reasoning_effort": "low"},
        "anthropic": {"thinking": {"type": "disabled"}},
        "google": {"thinking_config": {"thinking_budget": 0, "include_thoughts": False}},
    }

    assert kwargs["openai"]["service_tier"] == "flex"
    assert kwargs["anthropic"]["thinking"]["type"] == "disabled"
    assert kwargs["google"]["thinking_config"]["thinking_budget"] == 0


def test_provider_kwargs_partial():
    """Test that ProviderKwargs works with only some providers specified."""
    kwargs: ProviderKwargs = {
        "openai": {"service_tier": "priority"},
    }

    assert kwargs["openai"]["service_tier"] == "priority"
    assert "anthropic" not in kwargs


def test_request_with_provider_kwargs():
    """Test creating a request with provider_kwargs."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="test-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        provider_kwargs={
            "openai": {"service_tier": "flex"},
            "anthropic": {"thinking": {"type": "enabled", "budget_tokens": 10000}},
        },
    )

    assert request.provider_kwargs["openai"]["service_tier"] == "flex"
    assert request.provider_kwargs["anthropic"]["thinking"]["type"] == "enabled"


def test_fallback_with_provider_kwargs():
    """Test that provider_kwargs work correctly with fallbacks."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        provider_kwargs={
            "openai": {"service_tier": "flex"},
            "anthropic": {"thinking": {"type": "enabled", "budget_tokens": 5000}},
        },
        fallbacks=[
            FallbackRequest(
                provider=CompletionsProvider.ANTHROPIC,
                api_key="anthropic-key",
                model="claude-3",
            ),
        ],
    )

    attempts = request._build_completion_attempts()

    # First attempt uses OpenAI
    assert attempts[0].provider == CompletionsProvider.OPENAI
    assert attempts[0].provider_kwargs["openai"]["service_tier"] == "flex"

    # Second attempt uses Anthropic, inherits provider_kwargs
    assert attempts[1].provider == CompletionsProvider.ANTHROPIC
    assert attempts[1].provider_kwargs["anthropic"]["thinking"]["type"] == "enabled"


def test_fallback_overrides_provider_kwargs():
    """Test that fallback can override provider_kwargs."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        provider_kwargs={
            "anthropic": {"thinking": {"type": "disabled"}},
        },
        fallbacks=[
            FallbackRequest(
                provider=CompletionsProvider.ANTHROPIC,
                provider_kwargs={
                    "anthropic": {"thinking": {"type": "enabled", "budget_tokens": 10000}},
                },
            ),
        ],
    )

    attempts = request._build_completion_attempts()

    # Fallback should override provider_kwargs
    assert attempts[1].provider_kwargs["anthropic"]["thinking"]["type"] == "enabled"


def test_provider_kwargs_isolation():
    """Test that only the active provider's kwargs are relevant."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="test-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        provider_kwargs={
            "openai": {"service_tier": "flex"},
            "anthropic": {"thinking": {"type": "enabled", "budget_tokens": 99999}},
            "google": {"thinking_config": {"thinking_budget": 99999}},
        },
    )

    # Request should contain all kwargs
    assert "openai" in request.provider_kwargs
    assert "anthropic" in request.provider_kwargs
    assert "google" in request.provider_kwargs


def test_openai_passthrough_kwargs():
    """Test that unlisted kwargs are passed through for OpenAI."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="test-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        provider_kwargs={
            "openai": {
                "service_tier": "flex",
                "store": True,  # Not explicitly defined — passthrough
                "metadata": {"user_id": "123"},  # Not explicitly defined — passthrough
            },
        },
    )

    client = OpenAiCompletionClient()
    denormalized = client._denormalize_request(request)

    assert denormalized.service_tier == "flex"
    kwargs = denormalized.get_kwargs()
    assert kwargs["store"] == True
    assert kwargs["metadata"] == {"user_id": "123"}


def test_anthropic_passthrough_kwargs():
    """Test that unlisted kwargs are passed through for Anthropic."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.ANTHROPIC,
        api_key="test-key",
        model="claude-3",
        messages=[{"role": "user", "content": "Hello"}],
        provider_kwargs={
            "anthropic": {
                "thinking": {"type": "disabled"},
                "metadata": {"user_id": "456"},  # Not explicitly defined — passthrough
            },
        },
    )

    client = AnthropicCompletionClient()
    denormalized = client._denormalize_request(request)

    assert denormalized.thinking == {"type": "disabled"}
    kwargs = denormalized.get_kwargs()
    assert kwargs["metadata"] == {"user_id": "456"}


def test_google_passthrough_kwargs():
    """Test that unlisted kwargs are passed through for Google."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.GOOGLE,
        api_key="test-key",
        model="gemini-pro",
        messages=[{"role": "user", "content": "Hello"}],
        provider_kwargs={
            "google": {
                "thinking_config": {"thinking_budget": 0, "include_thoughts": False},
                "safety_settings": [{"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"}],
            },
        },
    )

    client = GoogleCompletionClient()
    denormalized = client._denormalize_request(request)

    # Google puts kwargs into config
    assert denormalized.config["thinking_config"]["thinking_budget"] == 0
    assert "safety_settings" in denormalized.config


# =============================================================================
# Integration Tests - Requires API keys
# =============================================================================

@pytest.mark.integration
async def test_openai_service_tier(openai_api_key):
    """Test OpenAI with service_tier kwarg."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": openai_api_key,
        "model": "gpt-4.1-mini",
        "messages": [{"role": "user", "content": "Say 'hello' only"}],
        "provider_kwargs": {
            "openai": {"service_tier": "auto"},
        },
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_openai_reasoning_effort(openai_api_key):
    """Test OpenAI with reasoning_effort kwarg (for o-series models)."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": openai_api_key,
        "model": "o4-mini",
        "messages": [{"role": "user", "content": "What is 2+2?"}],
        "provider_kwargs": {
            "openai": {"reasoning_effort": "low"},
        },
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_anthropic_thinking_disabled(anthropic_api_key):
    """Test Anthropic with thinking disabled (default)."""
    response = await generate_chat_completion({
        "provider": "anthropic",
        "api_key": anthropic_api_key,
        "model": "claude-haiku-4-5",
        "messages": [{"role": "user", "content": "Say 'hello' only"}],
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_anthropic_thinking_enabled(anthropic_api_key):
    """Test Anthropic with thinking enabled."""
    response = await generate_chat_completion({
        "provider": "anthropic",
        "api_key": anthropic_api_key,
        "model": "claude-sonnet-4-5-20250929",
        "max_tokens": 16000,
        "messages": [{"role": "user", "content": "What is 15 * 17?"}],
        "provider_kwargs": {
            "anthropic": {
                "thinking": {"type": "enabled", "budget_tokens": 5000},
            },
        },
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_google_thinking_disabled(gemini_api_key):
    """Test Google with thinking disabled (default)."""
    response = await generate_chat_completion({
        "provider": "google",
        "api_key": gemini_api_key,
        "model": "gemini-2.0-flash",
        "messages": [{"role": "user", "content": "Say 'hello' only"}],
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_multi_provider_kwargs_with_fallback(anthropic_api_key):
    """Test that correct provider_kwargs are used during fallback."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": "invalid-key",  # Will fail, triggering fallback
        "model": "gpt-4",
        "messages": [{"role": "user", "content": "Say 'fallback worked'"}],
        "provider_kwargs": {
            "openai": {"service_tier": "flex"},  # Won't be used (invalid key)
            "anthropic": {"thinking": {"type": "disabled"}},  # Will be used
        },
        "fallbacks": [
            {
                "provider": "anthropic",
                "api_key": anthropic_api_key,
                "model": "claude-haiku-4-5",
            }
        ],
    })
    assert response.message is not None
    assert response.message.content is not None


@pytest.mark.integration
async def test_streaming_with_provider_kwargs(anthropic_api_key):
    """Test streaming with provider_kwargs."""
    stream = await generate_chat_completion_stream({
        "provider": "anthropic",
        "api_key": anthropic_api_key,
        "model": "claude-haiku-4-5",
        "messages": [{"role": "user", "content": "Count from 1 to 5"}],
        "provider_kwargs": {
            "anthropic": {"thinking": {"type": "disabled"}},
        },
    })

    chunk_count = 0
    async for chunk in stream:
        chunk_count += 1

    assert chunk_count > 0


@pytest.mark.integration
async def test_openai_passthrough_store(openai_api_key):
    """Test OpenAI with passthrough 'store' kwarg (not explicitly defined)."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": openai_api_key,
        "model": "gpt-4.1-mini",
        "messages": [{"role": "user", "content": "Say 'passthrough works'"}],
        "provider_kwargs": {
            "openai": {
                "store": False,  # Not in OpenAIKwargs, should pass through
            },
        },
    })
    assert response.message is not None
    assert response.message.content is not None
