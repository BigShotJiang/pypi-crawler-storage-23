"""Unit tests for voicerun_completions/providers/anthropic/utils.py"""
import json

import pytest

from voicerun_completions.providers.anthropic.utils import (
    denormalize_conversation_history,
    denormalize_tools,
    denormalize_tool_choice,
)
from voicerun_completions.types.messages import (
    UserMessage,
    AssistantMessage,
    SystemMessage,
    ToolResultMessage,
    ToolCall,
    FunctionCall,
)
from voicerun_completions.types.request import (
    ToolDefinition,
    FunctionDefinition,
)
from voicerun_completions.types.cache import CacheBreakpoint


# =============================================================================
# denormalize_conversation_history
# =============================================================================

class TestDenormalizeConversationHistory:
    def test_user_message(self):
        msgs = [UserMessage(content="Hello")]
        messages, system_prompt = denormalize_conversation_history(msgs)
        assert len(messages) == 1
        assert messages[0]["role"] == "user"
        content_block = messages[0]["content"][0]
        assert content_block["type"] == "text"
        assert content_block["text"] == "Hello"

    def test_user_message_with_cache_breakpoint(self):
        msgs = [UserMessage(content="Hello", cache_breakpoint=CacheBreakpoint(ttl="5m"))]
        messages, _ = denormalize_conversation_history(msgs)
        content_block = messages[0]["content"][0]
        assert content_block["cache_control"]["type"] == "ephemeral"
        assert content_block["cache_control"]["ttl"] == "5m"

    def test_assistant_message_text(self):
        msgs = [AssistantMessage(content="Hi there")]
        messages, _ = denormalize_conversation_history(msgs)
        assert messages[0]["role"] == "assistant"
        assert messages[0]["content"][0]["type"] == "text"
        assert messages[0]["content"][0]["text"] == "Hi there"

    def test_assistant_message_with_tool_calls(self):
        tc = ToolCall(
            id="call_1", type="function",
            function=FunctionCall(name="get_weather", arguments={"city": "NYC"}),
        )
        msgs = [AssistantMessage(content="Let me check.", tool_calls=[tc])]
        messages, _ = denormalize_conversation_history(msgs)
        content = messages[0]["content"]
        # Should have text block + tool_use block
        assert len(content) == 2
        assert content[0]["type"] == "text"
        assert content[1]["type"] == "tool_use"
        assert content[1]["name"] == "get_weather"
        assert content[1]["input"] == {"city": "NYC"}

    def test_system_message_extracted_to_system_prompt(self):
        msgs = [SystemMessage(content="Be helpful"), UserMessage(content="hi")]
        messages, system_prompt = denormalize_conversation_history(msgs)
        assert system_prompt is not None
        assert len(system_prompt) == 1
        assert system_prompt[0]["text"] == "Be helpful"
        # System message should not appear in messages list
        assert all(m["role"] != "system" for m in messages)

    def test_multiple_system_messages_combined(self):
        msgs = [
            SystemMessage(content="Rule 1"),
            SystemMessage(content="Rule 2"),
            UserMessage(content="hi"),
        ]
        messages, system_prompt = denormalize_conversation_history(msgs)
        assert len(system_prompt) == 2
        assert system_prompt[0]["text"] == "Rule 1"
        assert system_prompt[1]["text"] == "Rule 2"

    def test_consecutive_tool_results_grouped(self):
        msgs = [
            ToolResultMessage(tool_call_id="call_1", content={"temp": 72}),
            ToolResultMessage(tool_call_id="call_2", content={"wind": 5}),
        ]
        messages, _ = denormalize_conversation_history(msgs)
        # Should be grouped into a single user message
        assert len(messages) == 1
        assert messages[0]["role"] == "user"
        assert len(messages[0]["content"]) == 2
        assert messages[0]["content"][0]["type"] == "tool_result"
        assert messages[0]["content"][1]["type"] == "tool_result"

    def test_tool_result_with_cache_breakpoint(self):
        msgs = [
            ToolResultMessage(
                tool_call_id="call_1", content={"data": 1},
                cache_breakpoint=CacheBreakpoint(ttl="1h"),
            ),
        ]
        messages, _ = denormalize_conversation_history(msgs)
        tool_result = messages[0]["content"][0]
        assert tool_result["cache_control"]["type"] == "ephemeral"
        assert tool_result["cache_control"]["ttl"] == "1h"

    def test_no_system_messages_returns_none_system_prompt(self):
        msgs = [UserMessage(content="hi")]
        _, system_prompt = denormalize_conversation_history(msgs)
        assert system_prompt is None


# =============================================================================
# denormalize_tools
# =============================================================================

class TestDenormalizeTools:
    def test_converts_to_anthropic_format(self):
        tools = [ToolDefinition(
            type="function",
            function=FunctionDefinition(
                name="get_weather",
                description="Get weather",
                parameters={"type": "object", "properties": {}},
            ),
        )]
        result = denormalize_tools(tools)
        assert len(result) == 1
        assert result[0]["name"] == "get_weather"
        assert result[0]["description"] == "Get weather"
        assert result[0]["input_schema"] == {"type": "object", "properties": {}}

    def test_with_cache_breakpoint(self):
        tools = [ToolDefinition(
            type="function",
            function=FunctionDefinition(name="fn", description="d", parameters={}),
            cache_breakpoint=CacheBreakpoint(ttl="5m"),
        )]
        result = denormalize_tools(tools)
        assert result[0]["cache_control"]["type"] == "ephemeral"
        assert result[0]["cache_control"]["ttl"] == "5m"

    def test_none_returns_none(self):
        assert denormalize_tools(None) is None


# =============================================================================
# denormalize_tool_choice
# =============================================================================

class TestDenormalizeToolChoice:
    def test_auto(self):
        result = denormalize_tool_choice("auto")
        assert result["type"] == "auto"

    def test_none_literal(self):
        result = denormalize_tool_choice("none")
        assert result["type"] == "none"

    def test_required_maps_to_any(self):
        result = denormalize_tool_choice("required")
        assert result["type"] == "any"

    def test_specific_name(self):
        result = denormalize_tool_choice("get_weather")
        assert result["type"] == "tool"
        assert result["name"] == "get_weather"

    def test_none_value_returns_none(self):
        assert denormalize_tool_choice(None) is None
