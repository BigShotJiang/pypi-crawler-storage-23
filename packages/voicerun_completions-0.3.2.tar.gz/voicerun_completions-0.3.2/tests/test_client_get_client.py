"""Unit tests for _get_client in voicerun_completions/client.py"""
import pytest

from voicerun_completions.client import _get_client
from voicerun_completions.types.request import CompletionsProvider
from voicerun_completions.types.errors import InvalidProviderError
from voicerun_completions.providers.openai.client import OpenAiCompletionClient
from voicerun_completions.providers.anthropic.client import AnthropicCompletionClient
from voicerun_completions.providers.google.client import GoogleCompletionClient
from voicerun_completions.providers.anthropic.vertex.client import AnthropicVertexCompletionClient


class TestGetClient:
    def test_openai(self):
        client = _get_client(CompletionsProvider.OPENAI)
        assert isinstance(client, OpenAiCompletionClient)

    def test_anthropic(self):
        client = _get_client(CompletionsProvider.ANTHROPIC)
        assert isinstance(client, AnthropicCompletionClient)

    def test_google(self):
        client = _get_client(CompletionsProvider.GOOGLE)
        assert isinstance(client, GoogleCompletionClient)

    def test_anthropic_vertex(self):
        client = _get_client(CompletionsProvider.ANTHROPIC_VERTEX)
        assert isinstance(client, AnthropicVertexCompletionClient)

    def test_invalid_provider_raises(self):
        with pytest.raises(InvalidProviderError):
            _get_client("not_a_real_provider")
