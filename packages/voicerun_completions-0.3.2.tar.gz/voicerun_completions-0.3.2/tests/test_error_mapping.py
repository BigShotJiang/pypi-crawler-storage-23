"""Unit tests for map_openai_error and map_anthropic_error in voicerun_completions/types/errors.py"""
import httpx
import pytest

from openai import (
    OpenAIError,
    AuthenticationError as OpenAIAuthenticationError,
    RateLimitError as OpenAIRateLimitError,
    APITimeoutError as OpenAIAPITimeoutError,
    NotFoundError as OpenAINotFoundError,
    APIStatusError as OpenAIAPIStatusError,
    BadRequestError as OpenAIBadRequestError,
)
from anthropic import (
    APIError as AnthropicAPIError,
    AuthenticationError as AnthropicAuthenticationError,
    RateLimitError as AnthropicRateLimitError,
    APITimeoutError as AnthropicAPITimeoutError,
    NotFoundError as AnthropicNotFoundError,
    InternalServerError as AnthropicInternalServerError,
    BadRequestError as AnthropicBadRequestError,
)

from voicerun_completions.types.errors import (
    map_openai_error,
    map_anthropic_error,
    AuthenticationError,
    RateLimitError,
    TimeoutError,
    ModelNotFoundError,
    ContentFilterError,
    ProviderUnavailableError,
    ProviderError,
    ValidationError,
)


def _openai_response(status: int) -> httpx.Response:
    return httpx.Response(status, request=httpx.Request("POST", "https://api.openai.com/v1/chat/completions"))


def _anthropic_response(status: int) -> httpx.Response:
    return httpx.Response(status, request=httpx.Request("POST", "https://api.anthropic.com/v1/messages"))


# =============================================================================
# map_openai_error
# =============================================================================

class TestMapOpenaiError:
    def test_authentication_error(self):
        error = OpenAIAuthenticationError("bad key", response=_openai_response(401), body=None)
        result = map_openai_error(error)
        assert isinstance(result, AuthenticationError)
        assert result.original_error is error

    def test_rate_limit_error(self):
        error = OpenAIRateLimitError("rate limited", response=_openai_response(429), body=None)
        result = map_openai_error(error)
        assert isinstance(result, RateLimitError)

    def test_timeout_error(self):
        request = httpx.Request("POST", "https://api.openai.com/v1/chat/completions")
        error = OpenAIAPITimeoutError(request=request)
        result = map_openai_error(error)
        assert isinstance(result, TimeoutError)

    def test_not_found_error(self):
        error = OpenAINotFoundError("not found", response=_openai_response(404), body=None)
        result = map_openai_error(error)
        assert isinstance(result, ModelNotFoundError)

    def test_bad_request_content_filter(self):
        body = {"error": {"code": "content_filter", "message": "blocked"}}
        error = OpenAIBadRequestError("filtered", response=_openai_response(400), body=body)
        result = map_openai_error(error)
        assert isinstance(result, ContentFilterError)

    def test_status_500_provider_unavailable(self):
        error = OpenAIAPIStatusError("server error", response=_openai_response(500), body=None)
        result = map_openai_error(error)
        assert isinstance(result, ProviderUnavailableError)
        assert result.status_code == 500

    def test_status_503_provider_unavailable(self):
        error = OpenAIAPIStatusError("unavailable", response=_openai_response(503), body=None)
        result = map_openai_error(error)
        assert isinstance(result, ProviderUnavailableError)
        assert result.status_code == 503

    def test_unknown_openai_error_maps_to_provider_error(self):
        error = OpenAIError("unknown")
        result = map_openai_error(error)
        assert isinstance(result, ProviderError)
        assert result.original_error is error


# =============================================================================
# map_anthropic_error
# =============================================================================

class TestMapAnthropicError:
    def test_authentication_error(self):
        error = AnthropicAuthenticationError("bad key", response=_anthropic_response(401), body=None)
        result = map_anthropic_error(error)
        assert isinstance(result, AuthenticationError)

    def test_rate_limit_error(self):
        error = AnthropicRateLimitError("rate limited", response=_anthropic_response(429), body=None)
        result = map_anthropic_error(error)
        assert isinstance(result, RateLimitError)

    def test_timeout_error(self):
        request = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
        error = AnthropicAPITimeoutError(request=request)
        result = map_anthropic_error(error)
        assert isinstance(result, TimeoutError)

    def test_not_found_error(self):
        error = AnthropicNotFoundError("not found", response=_anthropic_response(404), body=None)
        result = map_anthropic_error(error)
        assert isinstance(result, ModelNotFoundError)

    def test_internal_server_error(self):
        error = AnthropicInternalServerError("server error", response=_anthropic_response(500), body=None)
        result = map_anthropic_error(error)
        assert isinstance(result, ProviderUnavailableError)
        assert result.status_code == 500
