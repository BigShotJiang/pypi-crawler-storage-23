"""
Test script to validate response_schema functionality.
"""

import json

import pytest

from voicerun_completions.client import generate_chat_completion
from voicerun_completions.types.request import (
    ChatCompletionRequest,
    FallbackRequest,
    CompletionsProvider,
)
from voicerun_completions.providers.openai.client import OpenAiCompletionRequest
from voicerun_completions.providers.anthropic.client import AnthropicCompletionRequest
from voicerun_completions.providers.google.client import GoogleCompletionRequest
from voicerun_completions.providers.alibaba.client import AlibabaCompletionRequest
from voicerun_completions.providers.anthropic.vertex.client import AnthropicVertexCompletionRequest


SAMPLE_SCHEMA = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer"},
    },
    "required": ["name", "age"],
    "additionalProperties": False,
}


# =============================================================================
# Unit Tests - No API calls
# =============================================================================

def test_response_schema_defaults_to_none():
    """Test that response_schema defaults to None on ChatCompletionRequest."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="test-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )
    assert request.response_schema is None


def test_response_schema_stored_on_request():
    """Test that response_schema is stored on ChatCompletionRequest."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="test-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
    )
    assert request.response_schema == SAMPLE_SCHEMA


def test_fallback_inherits_response_schema():
    """Test that fallback inherits response_schema from the original request."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
        fallbacks=[
            FallbackRequest(
                provider=CompletionsProvider.ANTHROPIC,
                api_key="anthropic-key",
                model="claude-3",
            ),
        ],
    )

    attempts = request._build_completion_attempts()
    assert attempts[1].response_schema == SAMPLE_SCHEMA


def test_fallback_overrides_response_schema():
    """Test that fallback can override response_schema."""
    other_schema = {"type": "object", "properties": {"color": {"type": "string"}}}

    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="openai-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
        fallbacks=[
            FallbackRequest(
                provider=CompletionsProvider.ANTHROPIC,
                api_key="anthropic-key",
                model="claude-3",
                response_schema=other_schema,
            ),
        ],
    )

    attempts = request._build_completion_attempts()
    assert attempts[0].response_schema == SAMPLE_SCHEMA
    assert attempts[1].response_schema == other_schema


# --- OpenAI ---

def test_openai_response_format_built():
    """Test that OpenAI builds response_format from response_schema."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="test-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
    )

    denormalized = OpenAiCompletionRequest.from_request(request)

    assert denormalized.response_format == {
        "type": "json_schema",
        "json_schema": {
            "name": "response_schema",
            "schema": SAMPLE_SCHEMA,
            "strict": True,
        },
    }


def test_openai_response_format_in_kwargs():
    """Test that response_format appears in OpenAI get_kwargs()."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="test-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
    )

    denormalized = OpenAiCompletionRequest.from_request(request)
    kwargs = denormalized.get_kwargs()

    assert "response_format" in kwargs
    assert kwargs["response_format"]["type"] == "json_schema"


def test_openai_no_response_format_when_none():
    """Test that response_format is absent when response_schema is None."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.OPENAI,
        api_key="test-key",
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )

    denormalized = OpenAiCompletionRequest.from_request(request)
    kwargs = denormalized.get_kwargs()

    assert "response_format" not in kwargs


# --- Anthropic ---

def test_anthropic_output_config_built():
    """Test that Anthropic builds output_config from response_schema."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.ANTHROPIC,
        api_key="test-key",
        model="claude-3",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
    )

    denormalized = AnthropicCompletionRequest.from_request(request)

    assert denormalized.output_config == {
        "format": {
            "type": "json_schema",
            "schema": SAMPLE_SCHEMA,
        },
    }


def test_anthropic_output_config_in_kwargs():
    """Test that output_config appears in Anthropic get_kwargs()."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.ANTHROPIC,
        api_key="test-key",
        model="claude-3",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
    )

    denormalized = AnthropicCompletionRequest.from_request(request)
    kwargs = denormalized.get_kwargs()

    assert "output_config" in kwargs
    assert kwargs["output_config"]["format"]["type"] == "json_schema"


def test_anthropic_no_output_config_when_none():
    """Test that output_config is absent when response_schema is None."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.ANTHROPIC,
        api_key="test-key",
        model="claude-3",
        messages=[{"role": "user", "content": "Hello"}],
    )

    denormalized = AnthropicCompletionRequest.from_request(request)
    kwargs = denormalized.get_kwargs()

    assert "output_config" not in kwargs


# --- Google ---

def test_google_response_schema_in_config():
    """Test that Google sets response_mime_type and sanitized response_schema in config."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.GOOGLE,
        api_key="test-key",
        model="gemini-pro",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
    )

    denormalized = GoogleCompletionRequest.from_request(request)

    assert denormalized.config["response_mime_type"] == "application/json"
    # additionalProperties: false should be stripped by sanitization
    assert "additionalProperties" not in denormalized.config["response_schema"]
    assert denormalized.config["response_schema"]["properties"] == SAMPLE_SCHEMA["properties"]


def test_google_no_response_schema_when_none():
    """Test that response_mime_type and response_schema are absent when response_schema is None."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.GOOGLE,
        api_key="test-key",
        model="gemini-pro",
        messages=[{"role": "user", "content": "Hello"}],
    )

    denormalized = GoogleCompletionRequest.from_request(request)

    assert "response_mime_type" not in denormalized.config
    assert "response_schema" not in denormalized.config


def test_google_response_schema_sanitizes_union_types():
    """Test that Google sanitization converts union type arrays to nullable."""
    schema_with_unions = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "nickname": {"type": ["string", "null"]},
        },
        "required": ["name"],
        "additionalProperties": False,
    }

    request = ChatCompletionRequest(
        provider=CompletionsProvider.GOOGLE,
        api_key="test-key",
        model="gemini-pro",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=schema_with_unions,
    )

    denormalized = GoogleCompletionRequest.from_request(request)
    sanitized = denormalized.config["response_schema"]

    # additionalProperties: false should be stripped
    assert "additionalProperties" not in sanitized
    # Union type ["string", "null"] should become type: "string" + nullable: true
    assert sanitized["properties"]["nickname"]["type"] == "string"
    assert sanitized["properties"]["nickname"]["nullable"] is True


def test_google_response_schema_sanitizes_const():
    """Test that Google sanitization converts const to single-value enum."""
    schema_with_const = {
        "type": "object",
        "properties": {
            "status": {"const": "active"},
        },
        "required": ["status"],
    }

    request = ChatCompletionRequest(
        provider=CompletionsProvider.GOOGLE,
        api_key="test-key",
        model="gemini-pro",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=schema_with_const,
    )

    denormalized = GoogleCompletionRequest.from_request(request)
    sanitized = denormalized.config["response_schema"]

    # const should be converted to single-value enum
    assert "const" not in sanitized["properties"]["status"]
    assert sanitized["properties"]["status"]["enum"] == ["active"]


def test_google_response_schema_does_not_mutate_original():
    """Test that Google sanitization does not mutate the original schema."""
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
        },
        "additionalProperties": False,
    }

    request = ChatCompletionRequest(
        provider=CompletionsProvider.GOOGLE,
        api_key="test-key",
        model="gemini-pro",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=schema,
    )

    GoogleCompletionRequest.from_request(request)

    # Original schema should be unchanged
    assert schema["additionalProperties"] is False


# --- Alibaba ---

def test_alibaba_response_format_built():
    """Test that Alibaba builds response_format from response_schema (same as OpenAI)."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.ALIBABA,
        api_key="test-key",
        model="qwen-max",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
    )

    denormalized = AlibabaCompletionRequest.from_request(request)

    assert denormalized.response_format == {
        "type": "json_schema",
        "json_schema": {
            "name": "response_schema",
            "schema": SAMPLE_SCHEMA,
            "strict": True,
        },
    }


def test_alibaba_no_response_format_when_none():
    """Test that response_format is absent when response_schema is None."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.ALIBABA,
        api_key="test-key",
        model="qwen-max",
        messages=[{"role": "user", "content": "Hello"}],
    )

    denormalized = AlibabaCompletionRequest.from_request(request)
    kwargs = denormalized.get_kwargs()

    assert "response_format" not in kwargs


# --- Vertex ---

def test_vertex_output_config_built():
    """Test that Vertex builds output_config from response_schema (same as Anthropic)."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.ANTHROPIC_VERTEX,
        api_key="test-key",
        model="claude-3",
        messages=[{"role": "user", "content": "Hello"}],
        response_schema=SAMPLE_SCHEMA,
        provider_kwargs={
            "anthropic_vertex": {
                "service_account_credentials": {"type": "service_account", "project_id": "test"},
                "region": "us-central1",
            },
        },
    )

    denormalized = AnthropicVertexCompletionRequest.from_request(request)

    assert denormalized.output_config == {
        "format": {
            "type": "json_schema",
            "schema": SAMPLE_SCHEMA,
        },
    }


def test_vertex_no_output_config_when_none():
    """Test that output_config is absent when response_schema is None."""
    request = ChatCompletionRequest(
        provider=CompletionsProvider.ANTHROPIC_VERTEX,
        api_key="test-key",
        model="claude-3",
        messages=[{"role": "user", "content": "Hello"}],
        provider_kwargs={
            "anthropic_vertex": {
                "service_account_credentials": {"type": "service_account", "project_id": "test"},
                "region": "us-central1",
            },
        },
    )

    denormalized = AnthropicVertexCompletionRequest.from_request(request)
    kwargs = denormalized.get_kwargs()

    assert "output_config" not in kwargs


# =============================================================================
# Integration Tests - Requires API keys
# =============================================================================

PERSON_SCHEMA = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer"},
        "city": {"type": "string"},
    },
    "required": ["name", "age", "city"],
    "additionalProperties": False,
}


@pytest.mark.integration
async def test_openai_response_schema_integration(openai_api_key):
    """Test OpenAI structured output with response_schema end-to-end."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": openai_api_key,
        "model": "gpt-4.1-mini",
        "messages": [
            {"role": "user", "content": "Invent a fictional person. Return JSON with name, age, city."},
        ],
        "response_schema": PERSON_SCHEMA,
    })

    assert response.message is not None
    assert response.message.content is not None

    data = json.loads(response.message.content)
    assert "name" in data
    assert "age" in data
    assert "city" in data
    assert isinstance(data["name"], str)
    assert isinstance(data["age"], int)


@pytest.mark.integration
async def test_anthropic_response_schema_integration(anthropic_api_key):
    """Test Anthropic structured output with response_schema end-to-end."""
    response = await generate_chat_completion({
        "provider": "anthropic",
        "api_key": anthropic_api_key,
        "model": "claude-haiku-4-5",
        "messages": [
            {"role": "user", "content": "Invent a fictional person. Return JSON with name, age, city."},
        ],
        "response_schema": PERSON_SCHEMA,
    })

    assert response.message is not None
    assert response.message.content is not None

    data = json.loads(response.message.content)
    assert "name" in data
    assert "age" in data
    assert "city" in data
    assert isinstance(data["name"], str)
    assert isinstance(data["age"], int)


@pytest.mark.integration
async def test_google_response_schema_integration(gemini_api_key):
    """Test Google structured output with response_schema end-to-end."""
    response = await generate_chat_completion({
        "provider": "google",
        "api_key": gemini_api_key,
        "model": "gemini-2.0-flash",
        "messages": [
            {"role": "user", "content": "Invent a fictional person. Return JSON with name, age, city."},
        ],
        "response_schema": PERSON_SCHEMA,
    })

    assert response.message is not None
    assert response.message.content is not None

    data = json.loads(response.message.content)
    assert "name" in data
    assert "age" in data
    assert "city" in data
    assert isinstance(data["name"], str)
    assert isinstance(data["age"], int)


@pytest.mark.integration
async def test_google_response_schema_sanitization_integration(gemini_api_key):
    """Test Google structured output with a schema that requires sanitization.

    Uses additionalProperties (stripped), union types (converted to nullable),
    and nested objects to verify the sanitization pipeline works end-to-end.
    """
    schema_needing_sanitization = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
            "nickname": {"type": ["string", "null"]},
            "address": {
                "type": "object",
                "properties": {
                    "city": {"type": "string"},
                    "zip": {"type": ["string", "null"]},
                },
                "required": ["city"],
                "additionalProperties": False,
            },
        },
        "required": ["name", "age", "address"],
        "additionalProperties": False,
    }

    response = await generate_chat_completion({
        "provider": "google",
        "api_key": gemini_api_key,
        "model": "gemini-2.0-flash",
        "messages": [
            {
                "role": "user",
                "content": (
                    "Invent a fictional person. Return JSON with name (string), "
                    "age (integer), nickname (string or null), and address "
                    "(object with city string and zip string or null)."
                ),
            },
        ],
        "response_schema": schema_needing_sanitization,
    })

    assert response.message is not None
    assert response.message.content is not None

    data = json.loads(response.message.content)
    assert isinstance(data["name"], str)
    assert isinstance(data["age"], int)
    assert isinstance(data["address"], dict)
    assert isinstance(data["address"]["city"], str)


@pytest.mark.integration
async def test_alibaba_response_schema_integration(dashscope_api_key):
    """Test Alibaba Qwen structured output with response_schema end-to-end."""
    response = await generate_chat_completion({
        "provider": "alibaba",
        "api_key": dashscope_api_key,
        "model": "qwen3.5-plus",
        "messages": [
            {"role": "user", "content": "Invent a fictional person. Return JSON with name, age, city."},
        ],
        "response_schema": PERSON_SCHEMA,
    })

    assert response.message is not None
    assert response.message.content is not None

    data = json.loads(response.message.content)
    assert "name" in data
    assert "age" in data
    assert "city" in data
    assert isinstance(data["name"], str)
    assert isinstance(data["age"], int)


@pytest.mark.integration
async def test_vertex_response_schema_integration(gcp_service_account_json, gcp_project_id):
    """Test Anthropic Vertex structured output with response_schema end-to-end."""
    response = await generate_chat_completion({
        "provider": "anthropic_vertex",
        "api_key": "",
        "model": "claude-opus-4-5@20251101",
        "messages": [
            {"role": "user", "content": "Invent a fictional person. Return JSON with name, age, city."},
        ],
        "response_schema": PERSON_SCHEMA,
        "provider_kwargs": {
            "anthropic_vertex": {
                "region": "us-east5",
                "project_id": gcp_project_id,
                "service_account_credentials": gcp_service_account_json,
            },
        },
    })

    assert response.message is not None
    assert response.message.content is not None

    data = json.loads(response.message.content)
    assert "name" in data
    assert "age" in data
    assert "city" in data
    assert isinstance(data["name"], str)
    assert isinstance(data["age"], int)
