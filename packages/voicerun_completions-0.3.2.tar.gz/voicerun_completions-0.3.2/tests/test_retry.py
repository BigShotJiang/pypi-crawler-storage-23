"""Unit tests for voicerun_completions/retry.py"""
import pytest
from unittest.mock import AsyncMock, patch

from voicerun_completions.retry import retry_with_backoff
from voicerun_completions.types.request import RetryConfiguration
from voicerun_completions.types.errors import RetryExhaustedError


class TestRetryWithBackoff:
    async def test_success_on_first_try(self):
        func = AsyncMock(return_value="ok")
        config = RetryConfiguration(max_retries=3, retry_delay=1.0, backoff_multiplier=2.0)

        result = await retry_with_backoff(func, config)
        assert result == "ok"
        assert func.call_count == 1

    async def test_success_on_second_try(self):
        func = AsyncMock(side_effect=[RuntimeError("fail"), "ok"])
        config = RetryConfiguration(max_retries=3, retry_delay=1.0, backoff_multiplier=2.0)

        with patch("voicerun_completions.retry.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            result = await retry_with_backoff(func, config)

        assert result == "ok"
        assert func.call_count == 2
        mock_sleep.assert_called_once_with(1.0)  # first retry delay

    async def test_all_retries_exhausted_raises_retry_exhausted_error(self):
        original_error = RuntimeError("always fails")
        func = AsyncMock(side_effect=original_error)
        config = RetryConfiguration(max_retries=2, retry_delay=1.0, backoff_multiplier=2.0)

        with patch("voicerun_completions.retry.asyncio.sleep", new_callable=AsyncMock):
            with pytest.raises(RetryExhaustedError) as exc_info:
                await retry_with_backoff(func, config)

        assert exc_info.value.retry_count == 2
        assert exc_info.value.last_error is original_error

    async def test_max_retries_zero_single_attempt(self):
        func = AsyncMock(side_effect=RuntimeError("fail"))
        config = RetryConfiguration(max_retries=0, retry_delay=1.0, backoff_multiplier=2.0)

        with pytest.raises(RetryExhaustedError) as exc_info:
            await retry_with_backoff(func, config)

        assert func.call_count == 1
        assert exc_info.value.retry_count == 0

    async def test_backoff_timing(self):
        func = AsyncMock(side_effect=[RuntimeError("1"), RuntimeError("2"), RuntimeError("3"), "ok"])
        config = RetryConfiguration(max_retries=3, retry_delay=1.0, backoff_multiplier=2.0)

        with patch("voicerun_completions.retry.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            result = await retry_with_backoff(func, config)

        assert result == "ok"
        # Delays: 1*2^0=1, 1*2^1=2, 1*2^2=4
        assert mock_sleep.call_count == 3
        mock_sleep.assert_any_call(1.0)
        mock_sleep.assert_any_call(2.0)
        mock_sleep.assert_any_call(4.0)

    async def test_return_value_preserved(self):
        expected = {"key": "value", "nested": [1, 2, 3]}
        func = AsyncMock(return_value=expected)
        config = RetryConfiguration(max_retries=1, retry_delay=0.1, backoff_multiplier=1.0)

        result = await retry_with_backoff(func, config)
        assert result == expected
