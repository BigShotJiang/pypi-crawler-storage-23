"""Unit tests for voicerun_completions/utils/streaming.py"""
import pytest

from voicerun_completions.utils.streaming import (
    update_sentence_buffer,
    clean_text_for_speech,
    _find_last_sentence_boundary,
    _is_abbreviation_period,
    _is_dollar_amount_period,
    _is_incomplete_abbreviation,
    _is_incomplete_dollar_amount,
    DEFAULT_PUNCTUATION,
)


# =============================================================================
# update_sentence_buffer
# =============================================================================

class TestUpdateSentenceBuffer:
    def test_no_punctuation_returns_buffer_and_none(self):
        buf, sentence = update_sentence_buffer("Hello world", "", DEFAULT_PUNCTUATION)
        assert buf == "Hello world"
        assert sentence is None

    def test_period_completes_sentence(self):
        buf, sentence = update_sentence_buffer(
            " end.", "Hello world", DEFAULT_PUNCTUATION, clean_text=False
        )
        assert sentence == "Hello world end."
        assert buf == ""

    def test_min_sentence_length_keeps_short_fragment_buffered(self):
        # When the complete sentence is shorter than min_sentence_length, it's
        # discarded (buffer is already advanced past the boundary) and None is returned.
        buf, sentence = update_sentence_buffer("Hi.", "", DEFAULT_PUNCTUATION, min_sentence_length=10)
        assert sentence is None

    def test_clean_text_false_skips_markdown_cleaning(self):
        buf, sentence = update_sentence_buffer(
            " done.", "**Bold text**", DEFAULT_PUNCTUATION, clean_text=False
        )
        assert sentence is not None
        assert "**Bold text**" in sentence

    def test_clean_text_true_strips_markdown(self):
        buf, sentence = update_sentence_buffer(
            " done.", "**Bold text**", DEFAULT_PUNCTUATION, clean_text=True, min_sentence_length=3
        )
        assert sentence is not None
        assert "**" not in sentence

    def test_chinese_punctuation(self):
        buf, sentence = update_sentence_buffer(
            "。", "你好世界", DEFAULT_PUNCTUATION, clean_text=False
        )
        assert sentence is not None
        assert "你好世界" in sentence

    def test_empty_content_returns_unchanged_buffer(self):
        buf, sentence = update_sentence_buffer("", "existing buffer", DEFAULT_PUNCTUATION)
        assert buf == "existing buffer"
        assert sentence is None

    def test_none_content_returns_unchanged_buffer(self):
        buf, sentence = update_sentence_buffer(None, "existing buffer", DEFAULT_PUNCTUATION)
        assert buf == "existing buffer"
        assert sentence is None


# =============================================================================
# clean_text_for_speech
# =============================================================================

class TestCleanTextForSpeech:
    def test_strips_bold_markdown(self):
        assert clean_text_for_speech("**bold text**") == "bold text"

    def test_strips_italic_markdown(self):
        result = clean_text_for_speech("*italic text*")
        assert "italic text" in result
        assert "*" not in result

    def test_strips_inline_code_backticks(self):
        result = clean_text_for_speech("`some code`")
        assert "some code" in result
        assert "`" not in result

    def test_strips_markdown_headers(self):
        result = clean_text_for_speech("## Header")
        assert "Header" in result
        assert "#" not in result

    def test_converts_percentage(self):
        result = clean_text_for_speech("50%")
        assert "50 percent" in result

    def test_converts_ampersand(self):
        # \b&\b requires word chars adjacent to &, e.g. "R&D"
        result = clean_text_for_speech("R&D")
        assert "and" in result

    def test_replaces_urls_with_link(self):
        # Note: "/" → " slash " replacement runs before URL regex, so URLs with
        # slashes get broken up. Test with www. prefix instead which has no slashes.
        result = clean_text_for_speech("Visit www.example.com for info.")
        assert "link" in result
        assert "www." not in result

    def test_replaces_email_with_email_address(self):
        result = clean_text_for_speech("Contact user@example.com today.")
        assert "email address" in result
        assert "@" not in result

    def test_returns_empty_for_no_meaningful_chars(self):
        assert clean_text_for_speech("***") == ""

    def test_preserves_dollar_amounts(self):
        result = clean_text_for_speech("$200")
        assert "$200" in result

    def test_empty_input(self):
        assert clean_text_for_speech("") == ""

    def test_none_input(self):
        assert clean_text_for_speech(None) is None


# =============================================================================
# _find_last_sentence_boundary
# =============================================================================

class TestFindLastSentenceBoundary:
    def test_finds_period_boundary(self):
        text = "Hello world. More text"
        idx = _find_last_sentence_boundary(text, DEFAULT_PUNCTUATION)
        assert idx == 11
        assert text[idx] == "."

    def test_skips_am_pm_abbreviation(self):
        # "a.m." at end of text - recognized as abbreviation
        text = "Meet at 6 a.m."
        idx = _find_last_sentence_boundary(text, DEFAULT_PUNCTUATION)
        # The function recognizes "a.m." as abbreviation but since preceded by number "6",
        # it returns the period position
        assert idx == len(text) - 1

    def test_skips_dollar_amount_period(self):
        text = "It costs $20.99 today"
        # The period in $20.99 should be skipped (dollar amount)
        # No other sentence boundary → returns -1
        idx = _find_last_sentence_boundary(text, ['.'])
        assert idx == -1

    def test_exclamation_as_boundary(self):
        text = "Wow! Amazing"
        idx = _find_last_sentence_boundary(text, ['!'])
        assert idx == 3
        assert text[idx] == "!"

    def test_question_mark_as_boundary(self):
        text = "How are you? Fine"
        idx = _find_last_sentence_boundary(text, ['?'])
        assert idx == 11
        assert text[idx] == "?"

    def test_returns_negative_one_when_no_boundary(self):
        text = "Hello world no punctuation"
        idx = _find_last_sentence_boundary(text, DEFAULT_PUNCTUATION)
        assert idx == -1

    def test_mixed_punctuation(self):
        text = "Really! Are you sure?"
        idx = _find_last_sentence_boundary(text, ['!', '?'])
        # rfind for '!' = 6, rfind for '?' = 20; max is 20
        assert idx == 20


# =============================================================================
# _is_abbreviation_period
# =============================================================================

class TestIsAbbreviationPeriod:
    @pytest.mark.parametrize("text", [
        "Mr.", "Dr.", "Inc.", "etc.", "vs.",
    ])
    def test_returns_true_for_known_abbreviations(self, text):
        assert _is_abbreviation_period(text) is True

    def test_returns_true_for_eg(self):
        assert _is_abbreviation_period("e.g.") is True

    def test_returns_true_for_ie(self):
        assert _is_abbreviation_period("i.e.") is True

    def test_returns_true_for_am(self):
        assert _is_abbreviation_period("a.m.") is True

    def test_returns_true_for_pm(self):
        assert _is_abbreviation_period("p.m.") is True

    def test_returns_false_for_normal_sentence_period(self):
        assert _is_abbreviation_period("world.") is False

    def test_returns_false_for_empty(self):
        assert _is_abbreviation_period("") is False


# =============================================================================
# _is_dollar_amount_period
# =============================================================================

class TestIsDollarAmountPeriod:
    def test_returns_true_for_dollar_decimal(self):
        text = "$20.99"
        assert _is_dollar_amount_period(text, 3) is True

    def test_returns_false_no_dollar_sign(self):
        text = "20.99"
        assert _is_dollar_amount_period(text, 2) is False

    def test_returns_false_no_digit_after(self):
        text = "$20. "
        assert _is_dollar_amount_period(text, 3) is False

    def test_returns_false_no_digit_before(self):
        text = "$.99"
        assert _is_dollar_amount_period(text, 1) is False


# =============================================================================
# _is_incomplete_abbreviation
# =============================================================================

class TestIsIncompleteAbbreviation:
    def test_returns_false_for_number_before_p_dot(self):
        # "6 p." preceded by a number → complete time phrase
        assert _is_incomplete_abbreviation("6 p.") is False

    def test_returns_true_for_single_letter_after_single_letter(self):
        # "a p." → single letter before single letter → might be incomplete
        assert _is_incomplete_abbreviation("a p.") is True

    def test_returns_false_for_non_ap_word(self):
        assert _is_incomplete_abbreviation("Hello world.") is False

    def test_returns_false_for_empty(self):
        assert _is_incomplete_abbreviation("") is False

    def test_returns_false_no_trailing_period(self):
        assert _is_incomplete_abbreviation("Hello") is False


# =============================================================================
# _is_incomplete_dollar_amount
# =============================================================================

class TestIsIncompleteDollarAmount:
    def test_returns_true_for_dollar_trailing_period(self):
        assert _is_incomplete_dollar_amount("$20.") is True

    def test_returns_true_for_dollar_with_commas(self):
        assert _is_incomplete_dollar_amount("Price: $4,000.") is True

    def test_returns_false_for_non_dollar_text(self):
        assert _is_incomplete_dollar_amount("Hello world.") is False

    def test_returns_false_for_empty(self):
        assert _is_incomplete_dollar_amount("") is False
