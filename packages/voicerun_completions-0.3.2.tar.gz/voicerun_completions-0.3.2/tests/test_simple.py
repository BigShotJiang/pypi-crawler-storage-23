"""
Simple test to verify basic completion functionality with imports from voicerun_completions.
"""

import pytest

from voicerun_completions import (
    generate_chat_completion,
    generate_chat_completion_stream,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionChunk,
    AssistantMessageDeltaChunk,
    AssistantMessageSentenceChunk,
    ToolCallChunk,
    FinishReasonChunk,
    UsageChunk,
    FinalResponseChunk,
    CompletionsProvider,
    UserMessage,
    AssistantMessage,
    StreamOptions,
    VoiceRunCompletionError,
)


@pytest.mark.integration
async def test_generate_chat_completion(openai_api_key):
    """Test non-streaming completion."""
    response: ChatCompletionResponse = await generate_chat_completion({
        "provider": "openai",
        "api_key": openai_api_key,
        "model": "gpt-4o-mini",
        "messages": [{"role": "user", "content": "Say hello in exactly 3 words."}],
        "max_tokens": 20,
    })

    assert response.message is not None
    assert response.message.content is not None
    assert len(response.message.content) > 0


@pytest.mark.integration
async def test_generate_chat_completion_stream(openai_api_key):
    """Test streaming completion."""
    stream = await generate_chat_completion_stream(
        request={
            "provider": "openai",
            "api_key": openai_api_key,
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "Say hello in exactly 3 words."}],
            "max_tokens": 20,
        },
    )

    chunks_received = []
    final_response = None

    async for chunk in stream:
        chunks_received.append(chunk)
        if isinstance(chunk, FinalResponseChunk):
            final_response = chunk.response

    assert len(chunks_received) > 0
    assert final_response is not None
    assert final_response.message.content is not None


@pytest.mark.integration
async def test_generate_chat_completion_stream_sentences(openai_api_key):
    """Test streaming completion with sentence chunking."""
    stream = await generate_chat_completion_stream(
        request={
            "provider": "openai",
            "api_key": openai_api_key,
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "Write two short sentences about the weather."}],
            "max_tokens": 50,
        },
        stream_options=StreamOptions(stream_sentences=True),
    )

    sentences = []
    async for chunk in stream:
        if isinstance(chunk, AssistantMessageSentenceChunk):
            sentences.append(chunk.sentence)

    assert len(sentences) > 0
