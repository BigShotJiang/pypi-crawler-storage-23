"""Unit tests for PartialToolCall in voicerun_completions/providers/base.py"""
import pytest

from voicerun_completions.providers.base import PartialToolCall


class TestPartialToolCallIsComplete:
    def test_valid_json_is_complete(self):
        ptc = PartialToolCall(
            id="call_1", type="function", function_name="fn",
            arguments_buffer='{"location": "NYC"}',
        )
        assert ptc.is_complete() is True

    def test_incomplete_json_is_not_complete(self):
        ptc = PartialToolCall(
            id="call_1", type="function", function_name="fn",
            arguments_buffer='{"location": ',
        )
        assert ptc.is_complete() is False

    def test_empty_object_is_complete(self):
        ptc = PartialToolCall(
            id="call_1", type="function", function_name="fn",
            arguments_buffer='{}',
        )
        assert ptc.is_complete() is True


class TestPartialToolCallToToolCall:
    def test_valid_json_parsed(self):
        ptc = PartialToolCall(
            id="call_1", type="function", function_name="get_weather",
            arguments_buffer='{"city": "NYC"}',
        )
        tc = ptc.to_tool_call()
        assert tc.id == "call_1"
        assert tc.type == "function"
        assert tc.function.name == "get_weather"
        assert tc.function.arguments == {"city": "NYC"}

    def test_invalid_json_uses_empty_arguments(self):
        ptc = PartialToolCall(
            id="call_2", type="function", function_name="fn",
            arguments_buffer='{"broken',
        )
        tc = ptc.to_tool_call()
        assert tc.function.arguments == {}

    def test_preserves_index(self):
        ptc = PartialToolCall(
            id="call_3", type="function", function_name="fn",
            arguments_buffer='{}', index=5,
        )
        tc = ptc.to_tool_call()
        assert tc.index == 5

    def test_preserves_id_and_type(self):
        ptc = PartialToolCall(
            id="my_id", type="function", function_name="my_func",
            arguments_buffer='{}',
        )
        tc = ptc.to_tool_call()
        assert tc.id == "my_id"
        assert tc.type == "function"
        assert tc.function.name == "my_func"
