"""Tests for provider and model fields on ChatCompletionResponse.

Verifies that generate_chat_completion and generate_chat_completion_stream
correctly stamp provider and model from the winning completion request,
including fallback scenarios.
"""

import os

import pytest
from unittest.mock import AsyncMock, patch

from voicerun_completions.client import generate_chat_completion, generate_chat_completion_stream
from voicerun_completions.types.request import (
    ChatCompletionRequest,
    CompletionsProvider,
    FallbackRequest,
)
from voicerun_completions.types.response import ChatCompletionResponse
from voicerun_completions.types.messages import AssistantMessage
from voicerun_completions.types.streaming import FinalResponseChunk


def _get_api_key_or_skip(env_var: str) -> str:
    key = os.environ.get(env_var)
    if not key:
        pytest.skip(f"{env_var} not set")
    return key


PROVIDER_CONFIGS = [
    pytest.param("openai", "OPENAI_API_KEY", "gpt-4.1-mini", id="openai"),
    pytest.param("anthropic", "ANTHROPIC_API_KEY", "claude-haiku-4-5", id="anthropic"),
    pytest.param("google", "GEMINI_API_KEY", "gemini-2.5-flash", id="google"),
]


def _make_response(**kwargs) -> ChatCompletionResponse:
    """Create a ChatCompletionResponse with defaults."""
    defaults = dict(
        message=AssistantMessage(content="hello"),
        finish_reason="stop",
    )
    defaults.update(kwargs)
    return ChatCompletionResponse(**defaults)


# =============================================================================
# Non-streaming tests
# =============================================================================


class TestNonStreamingProviderModel:
    async def test_provider_and_model_set_on_response(self):
        """Primary request stamps provider and model on the response."""
        mock_client = AsyncMock()
        mock_client.generate_chat_completion.return_value = _make_response()

        with patch("voicerun_completions.client._get_client", return_value=mock_client):
            response = await generate_chat_completion({
                "provider": "openai",
                "api_key": "test-key",
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "hi"}],
            })

        assert response.provider == CompletionsProvider.OPENAI
        assert response.model == "gpt-4o"

    async def test_provider_and_model_from_fallback(self):
        """When primary fails and fallback succeeds, response has fallback's provider/model."""
        mock_openai_client = AsyncMock()
        mock_openai_client.generate_chat_completion.side_effect = RuntimeError("primary failed")

        mock_anthropic_client = AsyncMock()
        mock_anthropic_client.generate_chat_completion.return_value = _make_response()

        def get_client(provider):
            if provider == CompletionsProvider.OPENAI:
                return mock_openai_client
            return mock_anthropic_client

        with patch("voicerun_completions.client._get_client", side_effect=get_client):
            response = await generate_chat_completion(ChatCompletionRequest(
                provider=CompletionsProvider.OPENAI,
                api_key="openai-key",
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                fallbacks=[
                    FallbackRequest(
                        provider=CompletionsProvider.ANTHROPIC,
                        api_key="anthropic-key",
                        model="claude-sonnet-4-20250514",
                    ),
                ],
            ))

        assert response.provider == CompletionsProvider.ANTHROPIC
        assert response.model == "claude-sonnet-4-20250514"

    async def test_provider_and_model_from_second_fallback(self):
        """When primary and first fallback fail, response has second fallback's provider/model."""
        fail_client = AsyncMock()
        fail_client.generate_chat_completion.side_effect = RuntimeError("fail")

        success_client = AsyncMock()
        success_client.generate_chat_completion.return_value = _make_response()

        call_count = 0

        def get_client(provider):
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                return fail_client
            return success_client

        with patch("voicerun_completions.client._get_client", side_effect=get_client):
            response = await generate_chat_completion(ChatCompletionRequest(
                provider=CompletionsProvider.OPENAI,
                api_key="k1",
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                fallbacks=[
                    FallbackRequest(
                        provider=CompletionsProvider.ANTHROPIC,
                        api_key="k2",
                        model="claude-sonnet-4-20250514",
                    ),
                    FallbackRequest(
                        provider=CompletionsProvider.GOOGLE,
                        api_key="k3",
                        model="gemini-2.0-flash",
                    ),
                ],
            ))

        assert response.provider == CompletionsProvider.GOOGLE
        assert response.model == "gemini-2.0-flash"

    async def test_fallback_inherits_model_when_not_overridden(self):
        """When fallback doesn't override model, response has original model with new provider."""
        fail_client = AsyncMock()
        fail_client.generate_chat_completion.side_effect = RuntimeError("fail")

        success_client = AsyncMock()
        success_client.generate_chat_completion.return_value = _make_response()

        def get_client(provider):
            if provider == CompletionsProvider.OPENAI:
                return fail_client
            return success_client

        with patch("voicerun_completions.client._get_client", side_effect=get_client):
            response = await generate_chat_completion(ChatCompletionRequest(
                provider=CompletionsProvider.OPENAI,
                api_key="key",
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                fallbacks=[
                    FallbackRequest(
                        provider=CompletionsProvider.ANTHROPIC,
                        # model not set — inherits "gpt-4o" from original
                    ),
                ],
            ))

        assert response.provider == CompletionsProvider.ANTHROPIC
        assert response.model == "gpt-4o"

    async def test_does_not_overwrite_usage(self):
        """Stamping provider/model doesn't affect other response fields."""
        mock_client = AsyncMock()
        mock_client.generate_chat_completion.return_value = _make_response(
            usage={"input_tokens": 10, "output_tokens": 5},
        )

        with patch("voicerun_completions.client._get_client", return_value=mock_client):
            response = await generate_chat_completion({
                "provider": "anthropic",
                "api_key": "key",
                "model": "claude-sonnet-4-20250514",
                "messages": [{"role": "user", "content": "hi"}],
            })

        assert response.provider == CompletionsProvider.ANTHROPIC
        assert response.model == "claude-sonnet-4-20250514"
        assert response.usage == {"input_tokens": 10, "output_tokens": 5}
        assert response.message.content == "hello"
        assert response.finish_reason == "stop"


# =============================================================================
# Streaming tests
# =============================================================================


async def _collect_stream(stream):
    """Collect all chunks from an async iterable."""
    chunks = []
    async for chunk in stream:
        chunks.append(chunk)
    return chunks


class TestStreamingProviderModel:
    async def test_final_response_chunk_has_provider_and_model(self):
        """FinalResponseChunk in stream has correct provider and model."""
        final_chunk = FinalResponseChunk(response=_make_response())

        async def fake_stream(request, stream_options=None):
            yield final_chunk

        mock_client = AsyncMock()
        mock_client.generate_chat_completion_stream = fake_stream

        with patch("voicerun_completions.client._get_client", return_value=mock_client):
            stream = await generate_chat_completion_stream({
                "provider": "openai",
                "api_key": "key",
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "hi"}],
            })

            chunks = await _collect_stream(stream)

        final_chunks = [c for c in chunks if isinstance(c, FinalResponseChunk)]
        assert len(final_chunks) == 1
        assert final_chunks[0].response.provider == CompletionsProvider.OPENAI
        assert final_chunks[0].response.model == "gpt-4o"

    async def test_streaming_fallback_stamps_correct_provider_and_model(self):
        """When streaming primary fails and fallback succeeds, FinalResponseChunk has fallback info."""
        final_chunk = FinalResponseChunk(response=_make_response())

        async def failing_stream(request, stream_options=None):
            raise RuntimeError("connection failed")
            yield  # pragma: no cover - make it a generator

        async def success_stream(request, stream_options=None):
            yield final_chunk

        def get_client(provider):
            mock = AsyncMock()
            if provider == CompletionsProvider.OPENAI:
                mock.generate_chat_completion_stream = failing_stream
            else:
                mock.generate_chat_completion_stream = success_stream
            return mock

        with patch("voicerun_completions.client._get_client", side_effect=get_client):
            stream = await generate_chat_completion_stream(ChatCompletionRequest(
                provider=CompletionsProvider.OPENAI,
                api_key="k1",
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                fallbacks=[
                    FallbackRequest(
                        provider=CompletionsProvider.ANTHROPIC,
                        api_key="k2",
                        model="claude-sonnet-4-20250514",
                    ),
                ],
            ))

            chunks = await _collect_stream(stream)

        final_chunks = [c for c in chunks if isinstance(c, FinalResponseChunk)]
        assert len(final_chunks) == 1
        assert final_chunks[0].response.provider == CompletionsProvider.ANTHROPIC
        assert final_chunks[0].response.model == "claude-sonnet-4-20250514"

    async def test_non_final_chunks_are_not_modified(self):
        """Only FinalResponseChunk gets provider/model stamped; other chunks pass through."""
        from voicerun_completions.types.streaming import (
            AssistantMessageDeltaChunk,
            FinishReasonChunk,
            UsageChunk,
        )

        delta = AssistantMessageDeltaChunk(content="hello")
        finish = FinishReasonChunk(finish_reason="stop")
        usage = UsageChunk(usage={"input_tokens": 5})
        final = FinalResponseChunk(response=_make_response())

        async def fake_stream(request, stream_options=None):
            yield delta
            yield finish
            yield usage
            yield final

        mock_client = AsyncMock()
        mock_client.generate_chat_completion_stream = fake_stream

        with patch("voicerun_completions.client._get_client", return_value=mock_client):
            stream = await generate_chat_completion_stream({
                "provider": "openai",
                "api_key": "key",
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "hi"}],
            })

            chunks = await _collect_stream(stream)

        assert len(chunks) == 4
        assert isinstance(chunks[0], AssistantMessageDeltaChunk)
        assert chunks[0].content == "hello"
        assert isinstance(chunks[1], FinishReasonChunk)
        assert isinstance(chunks[2], UsageChunk)
        assert isinstance(chunks[3], FinalResponseChunk)
        assert chunks[3].response.provider == CompletionsProvider.OPENAI
        assert chunks[3].response.model == "gpt-4o"


# =============================================================================
# Integration tests - Requires API keys
# =============================================================================


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_non_streaming_provider_and_model_integration(provider, env_var, model):
    """Non-streaming response has correct provider and model from actual API call."""
    api_key = _get_api_key_or_skip(env_var)

    response = await generate_chat_completion({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "Say hi."}],
        "max_tokens": 10,
    })

    assert response.provider == CompletionsProvider(provider)
    assert response.model == model


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming_provider_and_model_integration(provider, env_var, model):
    """Streaming FinalResponseChunk has correct provider and model from actual API call."""
    api_key = _get_api_key_or_skip(env_var)

    stream = await generate_chat_completion_stream({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "Say hi."}],
        "max_tokens": 10,
    })

    final_response = None
    async for chunk in stream:
        if isinstance(chunk, FinalResponseChunk):
            final_response = chunk.response

    assert final_response is not None
    assert final_response.provider == CompletionsProvider(provider)
    assert final_response.model == model


@pytest.mark.integration
async def test_fallback_provider_and_model_integration(anthropic_api_key):
    """Fallback response has the fallback's provider and model, not the primary's."""
    response = await generate_chat_completion({
        "provider": "openai",
        "api_key": "invalid-key-12345",
        "model": "gpt-4o",
        "messages": [{"role": "user", "content": "Say hi."}],
        "max_tokens": 10,
        "fallbacks": [
            {
                "provider": "anthropic",
                "api_key": anthropic_api_key,
                "model": "claude-haiku-4-5",
            }
        ],
    })

    assert response.provider == CompletionsProvider.ANTHROPIC
    assert response.model == "claude-haiku-4-5"
    assert response.message.content is not None


@pytest.mark.integration
async def test_fallback_streaming_provider_and_model_integration(anthropic_api_key):
    """Streaming fallback FinalResponseChunk has the fallback's provider and model."""
    stream = await generate_chat_completion_stream({
        "provider": "openai",
        "api_key": "invalid-key-12345",
        "model": "gpt-4o",
        "messages": [{"role": "user", "content": "Say hi."}],
        "max_tokens": 10,
        "fallbacks": [
            {
                "provider": "anthropic",
                "api_key": anthropic_api_key,
                "model": "claude-haiku-4-5",
            }
        ],
    })

    final_response = None
    async for chunk in stream:
        if isinstance(chunk, FinalResponseChunk):
            final_response = chunk.response

    assert final_response is not None
    assert final_response.provider == CompletionsProvider.ANTHROPIC
    assert final_response.model == "claude-haiku-4-5"
