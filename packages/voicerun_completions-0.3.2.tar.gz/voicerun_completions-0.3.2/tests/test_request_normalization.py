"""Unit tests for normalization functions in voicerun_completions/types/request.py"""
import pytest

from voicerun_completions.types.request import (
    coalesce,
    _normalize_provider,
    _normalize_messages,
    _normalize_tools,
    _normalize_retry,
    CompletionsProvider,
    FunctionDefinition,
    ToolDefinition,
    RetryConfiguration,
    ChatCompletionRequest,
    FallbackRequest,
)
from voicerun_completions.types.messages import (
    UserMessage,
    AssistantMessage,
    SystemMessage,
)
from voicerun_completions.types.cache import CacheBreakpoint
from voicerun_completions.types.errors import (
    InvalidProviderError,
    InvalidMessageError,
    InvalidToolError,
    InvalidRetryConfigError,
)


# =============================================================================
# coalesce
# =============================================================================

class TestCoalesce:
    def test_returns_a_when_not_none(self):
        assert coalesce("hello", "fallback") == "hello"

    def test_returns_b_when_a_is_none(self):
        assert coalesce(None, "fallback") == "fallback"

    def test_returns_none_when_both_none(self):
        assert coalesce(None, None) is None

    def test_preserves_falsy_non_none_values(self):
        assert coalesce(0, 42) == 0
        assert coalesce("", "fallback") == ""
        assert coalesce(False, True) is False


# =============================================================================
# _normalize_provider
# =============================================================================

class TestNormalizeProvider:
    def test_string_openai(self):
        assert _normalize_provider("openai") == CompletionsProvider.OPENAI

    def test_string_anthropic(self):
        assert _normalize_provider("anthropic") == CompletionsProvider.ANTHROPIC

    def test_string_google(self):
        assert _normalize_provider("google") == CompletionsProvider.GOOGLE

    def test_string_anthropic_vertex(self):
        assert _normalize_provider("anthropic_vertex") == CompletionsProvider.ANTHROPIC_VERTEX

    def test_already_enum_returned_as_is(self):
        provider = CompletionsProvider.OPENAI
        assert _normalize_provider(provider) is provider

    def test_invalid_string_raises(self):
        with pytest.raises(InvalidProviderError):
            _normalize_provider("invalid_provider")

    def test_case_insensitive(self):
        assert _normalize_provider("OpenAI") == CompletionsProvider.OPENAI
        assert _normalize_provider("ANTHROPIC") == CompletionsProvider.ANTHROPIC


# =============================================================================
# _normalize_messages
# =============================================================================

class TestNormalizeMessages:
    def test_list_of_dicts(self):
        msgs = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        result = _normalize_messages(msgs)
        assert len(result) == 2
        assert isinstance(result[0], UserMessage)
        assert isinstance(result[1], AssistantMessage)

    def test_mixed_dicts_and_objects(self):
        msgs = [
            UserMessage(content="hi"),
            {"role": "system", "content": "be helpful"},
        ]
        result = _normalize_messages(msgs)
        assert len(result) == 2
        assert isinstance(result[0], UserMessage)
        assert isinstance(result[1], SystemMessage)

    def test_invalid_type_raises(self):
        with pytest.raises(InvalidMessageError):
            _normalize_messages([42])


# =============================================================================
# _normalize_tools
# =============================================================================

class TestNormalizeTools:
    def test_none_returns_none(self):
        assert _normalize_tools(None) is None

    def test_empty_list_returns_none(self):
        assert _normalize_tools([]) is None

    def test_list_of_dicts(self):
        tools = [{
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather",
                "parameters": {"type": "object", "properties": {}},
            },
        }]
        result = _normalize_tools(tools)
        assert len(result) == 1
        assert isinstance(result[0], ToolDefinition)
        assert result[0].function.name == "get_weather"

    def test_mixed_dicts_and_objects(self):
        td = ToolDefinition(
            type="function",
            function=FunctionDefinition(name="fn1", description="d1", parameters={}),
        )
        tools = [
            td,
            {
                "type": "function",
                "function": {"name": "fn2", "description": "d2", "parameters": {}},
            },
        ]
        result = _normalize_tools(tools)
        assert len(result) == 2
        assert result[0] is td
        assert result[1].function.name == "fn2"

    def test_invalid_type_raises(self):
        with pytest.raises(InvalidToolError):
            _normalize_tools([123])


# =============================================================================
# _normalize_retry
# =============================================================================

class TestNormalizeRetry:
    def test_none_returns_none(self):
        assert _normalize_retry(None) is None

    def test_retry_config_returned_as_is(self):
        config = RetryConfiguration(max_retries=5)
        assert _normalize_retry(config) is config

    def test_dict_creates_retry_config(self):
        result = _normalize_retry({"max_retries": 5, "retry_delay": 0.5})
        assert isinstance(result, RetryConfiguration)
        assert result.max_retries == 5
        assert result.retry_delay == 0.5

    def test_invalid_type_raises(self):
        with pytest.raises(InvalidRetryConfigError):
            _normalize_retry(42)


# =============================================================================
# FunctionDefinition.deserialize
# =============================================================================

class TestFunctionDefinitionDeserialize:
    def test_basic(self):
        data = {"name": "fn", "description": "desc", "parameters": {"type": "object"}}
        fd = FunctionDefinition.deserialize(data)
        assert fd.name == "fn"
        assert fd.description == "desc"
        assert fd.strict is None

    def test_with_strict(self):
        data = {
            "name": "fn", "description": "desc",
            "parameters": {"type": "object"}, "strict": True,
        }
        fd = FunctionDefinition.deserialize(data)
        assert fd.strict is True


# =============================================================================
# ToolDefinition.deserialize
# =============================================================================

class TestToolDefinitionDeserialize:
    def test_basic(self):
        data = {
            "type": "function",
            "function": {"name": "fn", "description": "desc", "parameters": {}},
        }
        td = ToolDefinition.deserialize(data)
        assert td.type == "function"
        assert td.function.name == "fn"
        assert td.cache_breakpoint is None

    def test_with_cache_breakpoint(self):
        data = {
            "type": "function",
            "function": {"name": "fn", "description": "desc", "parameters": {}},
            "cache_breakpoint": {"ttl": "5m"},
        }
        td = ToolDefinition.deserialize(data)
        assert td.cache_breakpoint.ttl == "5m"


# =============================================================================
# ChatCompletionRequest._apply_fallback
# =============================================================================

class TestApplyFallback:
    def _base_request(self):
        return ChatCompletionRequest(
            provider=CompletionsProvider.OPENAI,
            api_key="key-1",
            model="gpt-4",
            messages=[UserMessage(content="hi")],
            temperature=0.7,
            max_tokens=100,
        )

    def test_fallback_overrides_provider_model_api_key(self):
        base = self._base_request()
        fallback = FallbackRequest(
            provider=CompletionsProvider.ANTHROPIC,
            api_key="key-2",
            model="claude-3",
        )
        result = base._apply_fallback(fallback)
        assert result.provider == CompletionsProvider.ANTHROPIC
        assert result.api_key == "key-2"
        assert result.model == "claude-3"

    def test_fallback_inherits_non_overridden_fields(self):
        base = self._base_request()
        fallback = FallbackRequest(provider=CompletionsProvider.ANTHROPIC)
        result = base._apply_fallback(fallback)
        assert result.api_key == "key-1"  # inherited
        assert result.model == "gpt-4"  # inherited
        assert result.temperature == 0.7  # inherited
        assert result.max_tokens == 100  # inherited

    def test_fallback_clears_fallbacks_chain(self):
        base = self._base_request()
        base.fallbacks = [FallbackRequest(model="other")]
        fallback = FallbackRequest(model="fallback-model")
        result = base._apply_fallback(fallback)
        assert result.fallbacks is None


# =============================================================================
# ChatCompletionRequest._build_completion_attempts
# =============================================================================

class TestBuildCompletionAttempts:
    def test_no_fallbacks_returns_single_attempt(self):
        req = ChatCompletionRequest(
            provider="openai",
            api_key="key",
            model="gpt-4",
            messages=[{"role": "user", "content": "hi"}],
        )
        attempts = req._build_completion_attempts()
        assert len(attempts) == 1
        assert attempts[0].provider == CompletionsProvider.OPENAI

    def test_with_fallbacks_returns_multiple_attempts(self):
        req = ChatCompletionRequest(
            provider="openai",
            api_key="key-1",
            model="gpt-4",
            messages=[{"role": "user", "content": "hi"}],
            fallbacks=[
                FallbackRequest(provider=CompletionsProvider.ANTHROPIC, api_key="key-2", model="claude-3"),
                FallbackRequest(provider=CompletionsProvider.GOOGLE, api_key="key-3", model="gemini"),
            ],
        )
        attempts = req._build_completion_attempts()
        assert len(attempts) == 3
        assert attempts[0].provider == CompletionsProvider.OPENAI
        assert attempts[1].provider == CompletionsProvider.ANTHROPIC
        assert attempts[2].provider == CompletionsProvider.GOOGLE
