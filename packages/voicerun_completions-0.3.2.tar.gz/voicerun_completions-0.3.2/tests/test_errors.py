"""
Test script to validate custom error hierarchy.
"""

import pytest

from voicerun_completions import (
    VoiceRunCompletionError,
    CompletionsProvider,
    ChatCompletionRequest,
)
from voicerun_completions.types.errors import (
    ConfigurationError,
    InvalidProviderError,
    ValidationError,
    InvalidMessageError,
    InvalidToolError,
    InvalidRetryConfigError,
    ProviderError,
    AuthenticationError,
    RateLimitError,
    ProviderUnavailableError,
    ModelNotFoundError,
    ContentFilterError,
    TimeoutError,
    RetryExhaustedError,
    FallbackExhaustedError,
    StreamingError,
    StreamConnectionError,
    StreamInterruptedError,
)
from voicerun_completions.types.messages import ConversationHistoryMessage
from voicerun_completions.client import generate_chat_completion


# =============================================================================
# Unit Tests - Error Classes
# =============================================================================

def test_voicerun_error_base():
    """Test base VoiceRunCompletionError."""
    error = VoiceRunCompletionError("Test error message")
    assert str(error) == "Test error message"
    assert error.message == "Test error message"
    assert error.original_error is None


def test_voicerun_error_with_original():
    """Test VoiceRunCompletionError with original exception."""
    original = ValueError("Original error")
    error = VoiceRunCompletionError("Wrapped error", original_error=original)
    assert error.original_error is original
    assert "caused by" in str(error)


def test_invalid_provider_error():
    """Test InvalidProviderError."""
    error = InvalidProviderError("unknown_provider")
    assert error.provider == "unknown_provider"
    assert "unknown_provider" in str(error)
    assert isinstance(error, ConfigurationError)
    assert isinstance(error, VoiceRunCompletionError)


def test_validation_errors():
    """Test validation error subclasses."""
    msg_error = InvalidMessageError("Invalid role", details="Expected user, got foo")
    assert msg_error.details == "Expected user, got foo"
    assert isinstance(msg_error, ValidationError)

    tool_error = InvalidToolError("Invalid tool format", details="Missing function")
    assert tool_error.details == "Missing function"
    assert isinstance(tool_error, ValidationError)

    retry_error = InvalidRetryConfigError("Invalid retry config")
    assert isinstance(retry_error, ValidationError)


def test_provider_error_attributes():
    """Test ProviderError attributes."""
    error = ProviderError(
        "API error",
        provider="openai",
        status_code=500,
    )
    assert error.provider == "openai"
    assert error.status_code == 500


def test_authentication_error():
    """Test AuthenticationError."""
    error = AuthenticationError(provider="anthropic")
    assert error.status_code == 401
    assert error.provider == "anthropic"
    assert isinstance(error, ProviderError)


def test_rate_limit_error():
    """Test RateLimitError."""
    error = RateLimitError(
        message="Rate limit exceeded",
        provider="openai",
        retry_after=30.0,
    )
    assert error.status_code == 429
    assert error.retry_after == 30.0


def test_provider_unavailable_error():
    """Test ProviderUnavailableError."""
    error = ProviderUnavailableError(
        message="Service down",
        provider="google",
        status_code=503,
    )
    assert error.status_code == 503


def test_model_not_found_error():
    """Test ModelNotFoundError."""
    error = ModelNotFoundError(
        model="gpt-5-turbo",
        provider="openai",
    )
    assert error.model == "gpt-5-turbo"
    assert error.status_code == 404
    assert "gpt-5-turbo" in str(error)


def test_content_filter_error():
    """Test ContentFilterError."""
    error = ContentFilterError(provider="openai")
    assert error.status_code == 400


def test_timeout_error():
    """Test TimeoutError."""
    error = TimeoutError(
        message="Request timed out after 30s",
        provider="anthropic",
        timeout_seconds=30.0,
    )
    assert error.timeout_seconds == 30.0
    assert error.status_code == 408


def test_retry_exhausted_error():
    """Test RetryExhaustedError."""
    original = AuthenticationError(provider="openai")
    error = RetryExhaustedError(
        message="All retries failed",
        provider="openai",
        retry_count=3,
        last_error=original,
    )
    assert error.retry_count == 3
    assert error.provider == "openai"
    assert error.last_error is original


def test_fallback_exhausted_error():
    """Test FallbackExhaustedError."""
    error = FallbackExhaustedError(
        message="All providers failed",
        fallback_count=2,
        providers_tried=["openai", "anthropic", "google"],
        last_error=ValueError("Last error"),
    )
    assert error.fallback_count == 2
    assert error.providers_tried == ["openai", "anthropic", "google"]


def test_streaming_errors():
    """Test streaming error subclasses."""
    conn_error = StreamConnectionError(
        "Failed to connect",
        provider="openai",
    )
    assert conn_error.provider == "openai"
    assert isinstance(conn_error, StreamingError)

    int_error = StreamInterruptedError(
        "Connection lost",
        provider="anthropic",
    )
    assert isinstance(int_error, StreamingError)


# =============================================================================
# Unit Tests - Validation Errors in Request
# =============================================================================

def test_invalid_provider_in_request():
    """Test that invalid provider raises InvalidProviderError."""
    with pytest.raises(InvalidProviderError, match="invalid_provider"):
        request = ChatCompletionRequest(
            provider="invalid_provider",
            api_key="key",
            model="model",
            messages=[{"role": "user", "content": "Hello"}],
        )
        request._normalize()


def test_invalid_message_role():
    """Test that invalid message role raises InvalidMessageError."""
    with pytest.raises(InvalidMessageError, match="invalid_role"):
        ConversationHistoryMessage.deserialize({"role": "invalid_role", "content": "test"})


def test_invalid_message_type():
    """Test that invalid message type raises InvalidMessageError."""
    with pytest.raises(InvalidMessageError):
        request = ChatCompletionRequest(
            provider=CompletionsProvider.OPENAI,
            api_key="key",
            model="model",
            messages=[123],  # Invalid: not dict or ConversationHistoryMessage
        )
        request._normalize()


def test_invalid_tool_type():
    """Test that invalid tool type raises InvalidToolError."""
    with pytest.raises(InvalidToolError):
        request = ChatCompletionRequest(
            provider=CompletionsProvider.OPENAI,
            api_key="key",
            model="model",
            messages=[{"role": "user", "content": "Hello"}],
            tools=[123],  # Invalid: not dict or ToolDefinition
        )
        request._normalize()


def test_invalid_retry_type():
    """Test that invalid retry type raises InvalidRetryConfigError."""
    with pytest.raises(InvalidRetryConfigError):
        request = ChatCompletionRequest(
            provider=CompletionsProvider.OPENAI,
            api_key="key",
            model="model",
            messages=[{"role": "user", "content": "Hello"}],
            retry="invalid",  # Invalid: not dict or RetryConfiguration
        )
        request._normalize()


# =============================================================================
# Integration Tests - Requires API keys
# =============================================================================

@pytest.mark.integration
async def test_authentication_error_integration():
    """Test that invalid API key raises an error."""
    with pytest.raises(Exception) as exc_info:
        await generate_chat_completion({
            "provider": "openai",
            "api_key": "invalid-key-12345",
            "model": "gpt-4",
            "messages": [{"role": "user", "content": "Hello"}],
        })
    if isinstance(exc_info.value, FallbackExhaustedError):
        assert len(exc_info.value.providers_tried) == 1
        assert exc_info.value.providers_tried[0] == "openai"


@pytest.mark.integration
async def test_fallback_exhausted_error_integration():
    """Test that all providers failing raises FallbackExhaustedError."""
    with pytest.raises(FallbackExhaustedError) as exc_info:
        await generate_chat_completion({
            "provider": "openai",
            "api_key": "invalid-key-1",
            "model": "gpt-4",
            "messages": [{"role": "user", "content": "Hello"}],
            "fallbacks": [
                {
                    "provider": "anthropic",
                    "api_key": "invalid-key-2",
                    "model": "claude-3",
                },
            ],
        })
    assert exc_info.value.fallback_count == 1
    assert len(exc_info.value.providers_tried) == 2
    assert "openai" in exc_info.value.providers_tried
    assert "anthropic" in exc_info.value.providers_tried
