"""MCP server for memento-ai — exposes project memory to any MCP client."""

from __future__ import annotations

from pathlib import Path

from mcp.server.fastmcp import FastMCP

from .config import find_memento_dir, get_api_key, get_project_root, load_config
from .memory import get_memory_dir, list_modules, read_all_memory, read_module
from .state import load_state

mcp = FastMCP("memento", instructions="Project memory powered by memento-ai")


def _require_memento() -> tuple[Path, dict]:
    """Find .memento dir and load config, or raise."""
    memento_dir = find_memento_dir()
    if memento_dir is None:
        raise RuntimeError("Not a memento project. Run `memento init` first.")
    config = load_config(memento_dir)
    return memento_dir, config


def _build_memory_text(memento_dir: Path, config: dict) -> str:
    """Build concatenated memory text from all modules."""
    memory_dir = get_memory_dir(memento_dir, config)
    all_memory = read_all_memory(memory_dir)
    if not all_memory:
        return "No memory found. Run `memento process` first."
    parts = []
    for name, content in all_memory.items():
        parts.append(f"## {name}\n{content}")
    return "\n\n".join(parts)


# --- Tools ---


@mcp.tool()
def memento_ask(question: str) -> str:
    """Ask a question about the project using its memory (uses LLM)."""
    from .providers import get_provider
    from .query import ask

    memento_dir, config = _require_memento()
    api_key = get_api_key(config)
    provider = get_provider(config, api_key=api_key)
    return ask(question, provider, memento_dir, config)


@mcp.tool()
def memento_search(query: str) -> str:
    """Search project memory for a text pattern (no LLM, fast grep)."""
    memento_dir, config = _require_memento()
    memory_dir = get_memory_dir(memento_dir, config)
    query_lower = query.lower()

    results = []
    for name in list_modules(memory_dir):
        content = read_module(memory_dir, name)
        if content is None:
            continue
        lines = content.splitlines()
        matches = [
            (i + 1, line)
            for i, line in enumerate(lines)
            if query_lower in line.lower()
        ]
        if matches:
            result_lines = [f"### {name}.md"]
            for lineno, line in matches[:10]:
                result_lines.append(f"  L{lineno}: {line.strip()}")
            results.append("\n".join(result_lines))

    if not results:
        return f"No matches for '{query}' in project memory."
    return "\n\n".join(results)


@mcp.tool()
def memento_status() -> str:
    """Show memento status: modules, commits processed, last run."""
    memento_dir, config = _require_memento()
    state = load_state(memento_dir)
    memory_dir = get_memory_dir(memento_dir, config)
    modules = list_modules(memory_dir)

    total_size = 0
    for name in modules:
        path = memory_dir / f"{name}.md"
        if path.exists():
            total_size += path.stat().st_size

    last = state.get("last_commit")
    return (
        f"Provider: {config.get('llm', {}).get('provider', 'unknown')}\n"
        f"Commits processed: {state.get('commits_processed', 0)}\n"
        f"Last commit: {last[:12] if last else 'none'}\n"
        f"Last run: {state.get('last_run', 'never')}\n"
        f"Modules ({len(modules)}): {', '.join(modules) if modules else 'none'}\n"
        f"Memory size: {total_size:,} bytes"
    )


@mcp.tool()
def memento_process() -> str:
    """Process new commits and update project memory on-demand."""
    from .git import get_commits
    from .processor import process_commits
    from .providers import get_provider

    memento_dir, config = _require_memento()
    repo_root = get_project_root(memento_dir)
    state = load_state(memento_dir)
    since = state.get("last_commit")

    commits = get_commits(since=since, cwd=repo_root)
    if not commits:
        return "No new commits to process."

    api_key = get_api_key(config)
    provider = get_provider(config, api_key=api_key)
    results = process_commits(commits, provider, memento_dir, config, repo_root=repo_root)

    processed = sum(1 for r in results if not r.get("skipped"))
    skipped = sum(1 for r in results if r.get("skipped"))
    return f"Processed {processed} commits ({skipped} skipped)."


# --- Resources ---


@mcp.resource("memento://summary")
def resource_summary() -> str:
    """Project summary (SUMMARY.md)."""
    memento_dir, config = _require_memento()
    memory_dir = get_memory_dir(memento_dir, config)
    content = read_module(memory_dir, "SUMMARY")
    return content or "No summary yet. Run `memento process` first."


@mcp.resource("memento://module/{name}")
def resource_module(name: str) -> str:
    """Read a specific memory module by name."""
    memento_dir, config = _require_memento()
    memory_dir = get_memory_dir(memento_dir, config)
    content = read_module(memory_dir, name)
    if content is None:
        modules = list_modules(memory_dir)
        return f"Module '{name}' not found. Available: {', '.join(modules)}"
    return content


@mcp.resource("memento://all")
def resource_all() -> str:
    """All project memory concatenated."""
    memento_dir, config = _require_memento()
    return _build_memory_text(memento_dir, config)


# --- Prompts ---


@mcp.prompt()
def project_context() -> str:
    """Inject full project memory as context for the LLM."""
    memento_dir, config = _require_memento()
    memory_text = _build_memory_text(memento_dir, config)
    return (
        "Below is the complete memory/documentation of the current project, "
        "maintained by memento-ai. Use this context to answer questions and "
        "assist with development.\n\n"
        + memory_text
    )


def main():
    """Entry point for memento-mcp command."""
    mcp.run()


if __name__ == "__main__":
    main()
