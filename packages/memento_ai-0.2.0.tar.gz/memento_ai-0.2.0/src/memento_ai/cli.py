"""Click CLI for memento-ai."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from . import __version__
from .config import find_memento_dir, get_api_key, get_project_root, load_config
from .git import get_commits, get_repo_root, install_hook, is_git_repo
from .memory import clear_memory, get_memory_dir, list_modules
from .processor import process_commits
from .providers import get_provider
from .query import ask
from .state import load_state, save_state

console = Console()


def _require_memento() -> Path:
    """Find .memento dir or exit with error."""
    memento_dir = find_memento_dir()
    if memento_dir is None:
        console.print("[red]Not a memento project. Run `memento init` first.[/red]")
        raise SystemExit(1)
    return memento_dir


@click.group()
@click.version_option(__version__, prog_name="memento-ai")
def cli():
    """memento-ai: Your codebase, remembered."""


@cli.command()
@click.option("--no-hook", is_flag=True, help="Don't install git post-commit hook")
def init(no_hook: bool):
    """Initialize memento in the current git repository."""
    if not is_git_repo():
        console.print("[red]Not a git repository. Run `git init` first.[/red]")
        raise SystemExit(1)

    repo_root = get_repo_root()
    memento_dir = repo_root / ".memento"

    if memento_dir.exists():
        console.print("[yellow].memento/ already exists.[/yellow]")
        return

    memento_dir.mkdir(parents=True)
    (memento_dir / "memory").mkdir()

    # Write default config
    config_content = """# memento-ai configuration
# Docs: https://github.com/hernanqwz/memento

[llm]
provider = "claude-cli"  # "openai", "anthropic", "claude-cli", "local"
# model = "gpt-4o-mini"
# base_url = "https://api.openai.com/v1"

[processing]
chunk_size = 4000
summary_every = 10
# ignore_patterns = ["*.lock", "dist/*"]

[memory]
dir = "memory"
max_module_size = 5000
"""
    (memento_dir / "config.toml").write_text(config_content)

    # Init state
    save_state(memento_dir, {
        "last_commit": None,
        "commits_processed": 0,
        "version": __version__,
    })

    # Add to .gitignore
    gitignore = repo_root / ".gitignore"
    ignore_line = ".memento/state.json"
    if gitignore.exists():
        content = gitignore.read_text()
        if ignore_line not in content:
            gitignore.write_text(content.rstrip() + f"\n{ignore_line}\n")
    else:
        gitignore.write_text(f"{ignore_line}\n")

    console.print("[green]Initialized .memento/[/green]")

    if not no_hook:
        if install_hook(repo_root):
            console.print("[green]Installed post-commit hook[/green]")
        else:
            console.print("[yellow]Post-commit hook already contains memento[/yellow]")

    console.print("\nNext: run [bold]memento process --all[/bold] to build memory from git history")


@cli.command()
@click.option("--all", "process_all", is_flag=True, help="Process entire git history")
def process(process_all: bool):
    """Process new commits and update project memory."""
    memento_dir = _require_memento()
    config = load_config(memento_dir)
    repo_root = get_project_root(memento_dir)

    state = load_state(memento_dir)
    since = None if process_all else state.get("last_commit")

    commits = get_commits(since=since, cwd=repo_root)

    if not commits:
        console.print("[yellow]No new commits to process.[/yellow]")
        return

    console.print(f"Processing [bold]{len(commits)}[/bold] commits...")

    api_key = get_api_key(config)
    provider = get_provider(config, api_key=api_key)
    console.print(f"Using provider: [cyan]{provider.name()}[/cyan]")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Processing...", total=len(commits))

        def on_progress(current, total, result):
            short = result.get("commit", "")
            msg = result.get("message", "")[:50]
            modules = result.get("modules_updated", [])
            if result.get("skipped"):
                progress.update(task, advance=1, description=f"[dim]{short} skipped[/dim]")
            else:
                progress.update(
                    task,
                    advance=1,
                    description=f"{short} {msg} -> {', '.join(modules) or 'no updates'}",
                )

        results = process_commits(
            commits, provider, memento_dir, config,
            repo_root=repo_root, on_progress=on_progress,
        )

    processed = sum(1 for r in results if not r.get("skipped"))
    skipped = sum(1 for r in results if r.get("skipped"))
    console.print(f"\n[green]Done![/green] {processed} processed, {skipped} skipped")

    memory_dir = get_memory_dir(memento_dir, config)
    modules = list_modules(memory_dir)
    if modules:
        console.print(f"Memory modules: [cyan]{', '.join(modules)}[/cyan]")


@cli.command(name="ask")
@click.argument("question")
def ask_cmd(question: str):
    """Ask a question about your project."""
    memento_dir = _require_memento()
    config = load_config(memento_dir)
    api_key = get_api_key(config)
    provider = get_provider(config, api_key=api_key)

    with console.status("Thinking..."):
        answer = ask(question, provider, memento_dir, config)

    console.print()
    console.print(answer)


@cli.command()
def status():
    """Show memento status for this project."""
    memento_dir = _require_memento()
    config = load_config(memento_dir)
    state = load_state(memento_dir)
    memory_dir = get_memory_dir(memento_dir, config)
    modules = list_modules(memory_dir)

    table = Table(title="memento status")
    table.add_column("Property", style="cyan")
    table.add_column("Value")

    table.add_row("Directory", str(memento_dir))
    table.add_row("Provider", config.get("llm", {}).get("provider", "unknown"))
    table.add_row("Commits processed", str(state.get("commits_processed", 0)))
    last = state.get("last_commit")
    table.add_row("Last commit", last[:12] if last else "none")
    table.add_row("Last run", state.get("last_run", "never"))
    table.add_row("Memory modules", str(len(modules)))

    if modules:
        table.add_row("Modules", ", ".join(modules))

    # Memory size
    total_size = 0
    for name in modules:
        path = memory_dir / f"{name}.md"
        if path.exists():
            total_size += path.stat().st_size
    table.add_row("Memory size", f"{total_size:,} bytes")

    console.print(table)


@cli.command()
@click.confirmation_option(prompt="Delete all memory and start fresh?")
def forget():
    """Delete all memory and reset state."""
    memento_dir = _require_memento()
    config = load_config(memento_dir)
    memory_dir = get_memory_dir(memento_dir, config)

    count = clear_memory(memory_dir)
    save_state(memento_dir, {
        "last_commit": None,
        "commits_processed": 0,
        "version": __version__,
    })

    console.print(f"[green]Cleared {count} memory files and reset state.[/green]")


@cli.command()
def serve():
    """Start the MCP server (stdio transport)."""
    try:
        from .mcp_server import main as mcp_main
    except ImportError:
        console.print(
            "[red]MCP dependencies not installed. "
            "Run: pip install memento-ai\\[mcp][/red]"
        )
        raise SystemExit(1)

    _require_memento()
    console.print("[cyan]Starting MCP server (stdio)...[/cyan]", stderr=True)
    mcp_main()


@cli.command(name="export")
@click.option(
    "--format", "fmt",
    type=click.Choice(["claude", "cursor", "copilot"]),
    required=True,
    help="Export format",
)
def export_cmd(fmt: str):
    """Export project memory for AI tools."""
    _require_memento()

    from .export import export_memory

    _, out_path = export_memory(fmt)
    console.print(f"[green]Exported to {out_path}[/green]")
