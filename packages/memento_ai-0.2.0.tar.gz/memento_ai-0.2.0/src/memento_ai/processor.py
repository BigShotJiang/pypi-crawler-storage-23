"""Core pipeline: diff -> LLM -> memory updates."""

from __future__ import annotations

import fnmatch
from pathlib import Path
from typing import Any

import yaml

from .chunker import chunk_diff
from .git import CommitInfo, get_changed_files, get_diff
from .memory import get_memory_dir, list_modules, read_all_memory, read_module, write_module
from .prompts import ANALYZE_DIFF, GENERATE_SUMMARY, ROUTE_MEMORY, UPDATE_MODULE
from .providers import LLMProvider
from .state import load_state, save_state


def _should_ignore(path: str, patterns: list[str]) -> bool:
    """Check if a file path matches any ignore pattern."""
    for pattern in patterns:
        if fnmatch.fnmatch(path, pattern):
            return True
    return False


def _filter_diff_files(diff: str, changed_files: list[str], patterns: list[str]) -> str:
    """Remove ignored files from a diff."""
    kept_files = [f for f in changed_files if not _should_ignore(f, patterns)]
    if len(kept_files) == len(changed_files):
        return diff

    if not kept_files:
        return ""

    # Filter diff sections
    sections = diff.split("\ndiff --git ")
    result_sections = []
    for i, section in enumerate(sections):
        prefix = "diff --git " if i > 0 else ""
        full = prefix + section
        # Check if this section belongs to a kept file
        for f in kept_files:
            if f in full.split("\n")[0]:
                result_sections.append(full)
                break

    return "\n".join(result_sections)


def _parse_yaml_response(text: str) -> dict[str, Any]:
    """Parse YAML from LLM response, handling common formatting issues."""
    # Strip markdown code fences
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = lines[1:]  # Remove opening fence
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)

    try:
        return yaml.safe_load(text) or {}
    except yaml.YAMLError:
        return {"summary": text, "modules_affected": [], "key_changes": []}


def process_commit(
    commit: CommitInfo,
    provider: LLMProvider,
    memento_dir: Path,
    config: dict[str, Any],
    repo_root: Path | None = None,
) -> dict[str, Any]:
    """Process a single commit through the full pipeline."""
    ignore_patterns = config.get("processing", {}).get("ignore_patterns", [])
    chunk_size = config.get("processing", {}).get("chunk_size", 4000)
    memory_dir = get_memory_dir(memento_dir, config)

    # 1. Get diff and changed files
    diff = get_diff(commit.hash, cwd=repo_root)
    changed_files = get_changed_files(commit.hash, cwd=repo_root)

    # 2. Filter ignored files
    diff = _filter_diff_files(diff, changed_files, ignore_patterns)
    if not diff.strip():
        return {"commit": commit.short_hash, "skipped": True, "reason": "all files ignored"}

    # 3. Chunk if needed
    chunks = chunk_diff(diff, max_size=chunk_size)

    # 4. Analyze each chunk
    analyses = []
    for chunk in chunks:
        prompt = ANALYZE_DIFF.replace("{commit_hash}", commit.short_hash)
        prompt = prompt.replace("{author}", commit.author)
        prompt = prompt.replace("{message}", commit.message)
        prompt = prompt.replace("{date}", commit.date)
        prompt = prompt.replace("{diff}", chunk)

        response = provider.complete("You are a precise code analyst.", prompt)
        analysis = _parse_yaml_response(response.content)
        analyses.append(analysis)

    # Merge analyses from multiple chunks
    merged = _merge_analyses(analyses)

    # 5. Route to memory modules
    existing = list_modules(memory_dir)
    route_prompt = ROUTE_MEMORY.replace(
        "{existing_modules}", ", ".join(existing) if existing else "(none yet)"
    )
    route_prompt = route_prompt.replace("{analysis}", yaml.dump(merged, default_flow_style=False))

    route_response = provider.complete("You are a memory manager.", route_prompt)
    routing = _parse_yaml_response(route_response.content)

    # 6. Update each module
    updates = routing.get("updates", [])
    modules_updated = []

    for update in updates:
        module_name = update.get("module", "").strip()
        if not module_name:
            continue

        current = read_module(memory_dir, module_name) or ""
        changes_text = yaml.dump(merged, default_flow_style=False)

        update_prompt = UPDATE_MODULE.replace("{module_name}", module_name)
        update_prompt = update_prompt.replace(
            "{current_content}", current if current else "(new module)"
        )
        update_prompt = update_prompt.replace("{changes}", changes_text)

        update_response = provider.complete("You are a technical writer.", update_prompt)
        write_module(memory_dir, module_name, update_response.content)
        modules_updated.append(module_name)

    return {
        "commit": commit.short_hash,
        "message": commit.message,
        "modules_updated": modules_updated,
        "analysis": merged,
    }


def _merge_analyses(analyses: list[dict]) -> dict:
    """Merge multiple chunk analyses into one."""
    if len(analyses) == 1:
        return analyses[0]

    merged = {
        "summary": "; ".join(a.get("summary", "") for a in analyses if a.get("summary")),
        "modules_affected": [],
        "key_changes": [],
        "patterns_noticed": [],
    }

    seen_modules = set()
    for a in analyses:
        for m in a.get("modules_affected", []):
            if m and m not in seen_modules:
                merged["modules_affected"].append(m)
                seen_modules.add(m)
        merged["key_changes"].extend(a.get("key_changes", []))
        merged["patterns_noticed"].extend(a.get("patterns_noticed", []))

    return merged


def generate_summary(provider: LLMProvider, memento_dir: Path, config: dict[str, Any]) -> None:
    """Regenerate SUMMARY.md from all memory modules."""
    memory_dir = get_memory_dir(memento_dir, config)
    all_memory = read_all_memory(memory_dir)

    if not all_memory:
        return

    memory_text = ""
    for name, content in all_memory.items():
        if name == "SUMMARY":
            continue
        memory_text += f"\n## Module: {name}\n{content}\n"

    prompt = GENERATE_SUMMARY.replace("{all_memory}", memory_text)
    response = provider.complete("You are a technical writer.", prompt)
    write_module(memory_dir, "SUMMARY", response.content)


def process_commits(
    commits: list[CommitInfo],
    provider: LLMProvider,
    memento_dir: Path,
    config: dict[str, Any],
    repo_root: Path | None = None,
    on_progress=None,
) -> list[dict[str, Any]]:
    """Process multiple commits, updating state after each."""
    summary_every = config.get("processing", {}).get("summary_every", 10)
    state = load_state(memento_dir)
    results = []

    for i, commit in enumerate(commits):
        result = process_commit(commit, provider, memento_dir, config, repo_root=repo_root)
        results.append(result)

        state["last_commit"] = commit.hash
        state["commits_processed"] = state.get("commits_processed", 0) + 1
        save_state(memento_dir, state)

        if on_progress:
            on_progress(i + 1, len(commits), result)

        # Regenerate summary periodically
        if (i + 1) % summary_every == 0:
            generate_summary(provider, memento_dir, config)

    # Final summary if we processed anything
    if results:
        generate_summary(provider, memento_dir, config)

    return results
