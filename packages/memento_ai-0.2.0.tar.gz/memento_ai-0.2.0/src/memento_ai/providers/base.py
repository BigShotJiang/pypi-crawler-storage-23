"""Abstract base for LLM providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class LLMResponse:
    content: str
    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    metadata: dict = field(default_factory=dict)


class LLMProvider(ABC):
    """Abstract LLM provider."""

    @abstractmethod
    def complete(self, system: str, user: str) -> LLMResponse:
        """Send a completion request and return the response."""

    @abstractmethod
    def name(self) -> str:
        """Provider display name."""
