"""Local embedded inference provider using llama-cpp-python."""

from __future__ import annotations

from .base import LLMProvider, LLMResponse

DEFAULT_REPO = "bartowski/Qwen2.5-Coder-3B-Instruct-GGUF"
DEFAULT_FILE = "Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf"


class LocalProvider(LLMProvider):
    def __init__(
        self,
        model: str | None = None,
        model_file: str | None = None,
        n_ctx: int = 8192,
        n_gpu_layers: int = -1,
        temperature: float = 0.3,
        max_tokens: int = 2048,
    ):
        self.repo = model or DEFAULT_REPO
        self.model_file = model_file or DEFAULT_FILE
        self.n_ctx = n_ctx
        self.n_gpu_layers = n_gpu_layers
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._llm = None

    def _get_llm(self):
        if self._llm is not None:
            return self._llm

        try:
            from llama_cpp import Llama
        except ImportError:
            raise RuntimeError(
                "llama-cpp-python not installed. Run: pip install memento-ai[local]"
            )

        self._llm = Llama.from_pretrained(
            repo_id=self.repo,
            filename=self.model_file,
            n_ctx=self.n_ctx,
            n_gpu_layers=self.n_gpu_layers,
            verbose=False,
        )
        return self._llm

    def name(self) -> str:
        return f"local ({self.repo})"

    def complete(self, system: str, user: str) -> LLMResponse:
        llm = self._get_llm()

        result = llm.create_chat_completion(
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )

        content = result["choices"][0]["message"]["content"]
        usage = result.get("usage", {})

        return LLMResponse(
            content=content,
            model=self.repo,
            input_tokens=usage.get("prompt_tokens", 0),
            output_tokens=usage.get("completion_tokens", 0),
        )
