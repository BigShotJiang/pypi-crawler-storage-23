"""LLM provider factory."""

from __future__ import annotations

from typing import Any

from .base import LLMProvider, LLMResponse

__all__ = ["LLMProvider", "LLMResponse", "get_provider"]


def get_provider(config: dict[str, Any], api_key: str | None = None) -> LLMProvider:
    """Create an LLM provider from config."""
    llm_config = config.get("llm", {})
    provider_name = llm_config.get("provider", "claude-cli")
    model = llm_config.get("model")
    temperature = llm_config.get("temperature", 0.3)
    max_tokens = llm_config.get("max_tokens", 2048)

    if provider_name == "openai":
        from .openai_compat import OpenAICompatProvider

        return OpenAICompatProvider(
            api_key=api_key,
            model=model or "gpt-4o-mini",
            base_url=llm_config.get("base_url", "https://api.openai.com/v1"),
            temperature=temperature,
            max_tokens=max_tokens,
        )

    if provider_name == "anthropic":
        from .anthropic import AnthropicProvider

        if not api_key:
            raise ValueError("Anthropic provider requires ANTHROPIC_API_KEY or MEMENTO_API_KEY")
        return AnthropicProvider(
            api_key=api_key,
            model=model or "claude-sonnet-4-20250514",
            temperature=temperature,
            max_tokens=max_tokens,
        )

    if provider_name == "claude-cli":
        from .claude_cli import ClaudeCLIProvider

        return ClaudeCLIProvider()

    if provider_name == "local":
        from .local import LocalProvider

        return LocalProvider(
            model=model,
            model_file=llm_config.get("model_file"),
            n_ctx=llm_config.get("n_ctx", 8192),
            n_gpu_layers=llm_config.get("n_gpu_layers", -1),
            temperature=temperature,
            max_tokens=max_tokens,
        )

    valid = "openai, anthropic, claude-cli, local"
    raise ValueError(f"Unknown provider: {provider_name}. Use: {valid}")
