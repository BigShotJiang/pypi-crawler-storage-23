"""Claude CLI provider — uses the claude command (free with Max/Pro plan)."""

from __future__ import annotations

import json
import os
import subprocess

from .base import LLMProvider, LLMResponse


class ClaudeCLIProvider(LLMProvider):
    def __init__(self, timeout: int = 120):
        self.timeout = timeout

    def name(self) -> str:
        return "claude-cli"

    def complete(self, system: str, user: str) -> LLMResponse:
        prompt = f"{system}\n\n{user}"

        # Unset CLAUDECODE to avoid nested session conflicts
        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}

        try:
            result = subprocess.run(
                ["claude", "-p", prompt, "--output-format", "json"],
                capture_output=True,
                text=True,
                timeout=self.timeout,
                env=env,
            )
        except FileNotFoundError:
            raise RuntimeError(
                "claude CLI not found. Install Claude Code: https://claude.ai/claude-code"
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"claude CLI timed out after {self.timeout}s")

        if result.returncode != 0:
            stderr = result.stderr.strip()
            raise RuntimeError(f"claude CLI failed (exit {result.returncode}): {stderr}")

        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            # Fallback: treat raw stdout as the response
            return LLMResponse(content=result.stdout.strip(), model="claude-cli")

        content = data.get("result", data.get("content", result.stdout.strip()))

        return LLMResponse(
            content=content,
            model="claude-cli",
            input_tokens=data.get("input_tokens", 0),
            output_tokens=data.get("output_tokens", 0),
            metadata={"session_id": data.get("session_id", "")},
        )
