"""Git operations via subprocess."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class CommitInfo:
    hash: str
    short_hash: str
    author: str
    date: str
    message: str


def run_git(args: list[str], cwd: Path | None = None) -> str:
    """Run a git command and return stdout."""
    result = subprocess.run(
        ["git", *args],
        capture_output=True,
        text=True,
        cwd=cwd,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def get_repo_root(cwd: Path | None = None) -> Path:
    """Get the root of the git repository."""
    root = run_git(["rev-parse", "--show-toplevel"], cwd=cwd)
    return Path(root)


def is_git_repo(cwd: Path | None = None) -> bool:
    """Check if we're inside a git repository."""
    try:
        run_git(["rev-parse", "--git-dir"], cwd=cwd)
        return True
    except RuntimeError:
        return False


def get_commits(since: str | None = None, cwd: Path | None = None) -> list[CommitInfo]:
    """Get list of commits, optionally since a given commit hash."""
    fmt = "%H%n%h%n%an%n%ai%n%s"
    args = ["log", f"--format={fmt}", "--reverse"]
    if since:
        args.append(f"{since}..HEAD")
    result = run_git(args, cwd=cwd)
    if not result:
        return []

    lines = result.split("\n")
    commits = []
    for i in range(0, len(lines), 5):
        if i + 4 >= len(lines):
            break
        commits.append(
            CommitInfo(
                hash=lines[i],
                short_hash=lines[i + 1],
                author=lines[i + 2],
                date=lines[i + 3],
                message=lines[i + 4],
            )
        )
    return commits


def get_diff(commit_hash: str, cwd: Path | None = None) -> str:
    """Get the diff for a specific commit."""
    return run_git(["diff-tree", "-p", "--no-commit-id", commit_hash], cwd=cwd)


def get_changed_files(commit_hash: str, cwd: Path | None = None) -> list[str]:
    """Get list of files changed in a commit."""
    result = run_git(["diff-tree", "--no-commit-id", "--name-only", "-r", commit_hash], cwd=cwd)
    if not result:
        return []
    return result.split("\n")


def get_current_commit(cwd: Path | None = None) -> str | None:
    """Get the current HEAD commit hash."""
    try:
        return run_git(["rev-parse", "HEAD"], cwd=cwd)
    except RuntimeError:
        return None


def install_hook(repo_root: Path) -> bool:
    """Install post-commit hook that runs memento process."""
    hooks_dir = repo_root / ".git" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_path = hooks_dir / "post-commit"

    hook_content = """#!/bin/sh
# memento-ai: auto-process commits
memento process 2>/dev/null &
"""

    if hook_path.exists():
        existing = hook_path.read_text()
        if "memento" in existing:
            return False
        hook_path.write_text(existing.rstrip() + "\n\n" + hook_content)
    else:
        hook_path.write_text(hook_content)

    hook_path.chmod(0o755)
    return True
