"""Tests for MCP server tools and resources."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from memento_ai.memory import write_module
from memento_ai.state import save_state

mcp = pytest.importorskip("mcp", reason="mcp not installed")

PATCH_TARGET = "memento_ai.mcp_server.find_memento_dir"


@pytest.fixture
def memento_project(tmp_path):
    """Create a minimal memento project structure."""
    memento_dir = tmp_path / ".memento"
    memento_dir.mkdir()
    memory_dir = memento_dir / "memory"
    memory_dir.mkdir()

    config_content = (
        '[llm]\nprovider = "claude-cli"\n\n[memory]\ndir = "memory"\n'
    )
    (memento_dir / "config.toml").write_text(config_content)
    save_state(
        memento_dir,
        {"last_commit": "abc123def456", "commits_processed": 5},
    )

    write_module(memory_dir, "SUMMARY", "# Project Summary\n\nA test project.")
    write_module(memory_dir, "core", "# Core\n\n- Main logic here\n- Uses patterns")
    write_module(memory_dir, "api", "# API\n\n- REST endpoints\n- Authentication layer")

    return tmp_path


def _patch_dir(memento_project):
    return patch(PATCH_TARGET, return_value=memento_project / ".memento")


class TestMementoSearch:
    def test_search_finds_matches(self, memento_project):
        from memento_ai.mcp_server import memento_search

        with _patch_dir(memento_project):
            result = memento_search("logic")
        assert "core.md" in result
        assert "logic" in result.lower()

    def test_search_no_matches(self, memento_project):
        from memento_ai.mcp_server import memento_search

        with _patch_dir(memento_project):
            result = memento_search("xyznonexistent")
        assert "No matches" in result

    def test_search_case_insensitive(self, memento_project):
        from memento_ai.mcp_server import memento_search

        with _patch_dir(memento_project):
            result = memento_search("REST")
        assert "api.md" in result


class TestMementoStatus:
    def test_status_returns_info(self, memento_project):
        from memento_ai.mcp_server import memento_status

        with _patch_dir(memento_project):
            result = memento_status()
        assert "Commits processed: 5" in result
        assert "abc123def456" in result
        assert "core" in result
        assert "api" in result


class TestResources:
    def test_resource_summary(self, memento_project):
        from memento_ai.mcp_server import resource_summary

        with _patch_dir(memento_project):
            result = resource_summary()
        assert "Project Summary" in result

    def test_resource_module(self, memento_project):
        from memento_ai.mcp_server import resource_module

        with _patch_dir(memento_project):
            result = resource_module("core")
        assert "Main logic" in result

    def test_resource_module_not_found(self, memento_project):
        from memento_ai.mcp_server import resource_module

        with _patch_dir(memento_project):
            result = resource_module("nonexistent")
        assert "not found" in result
        assert "core" in result

    def test_resource_all(self, memento_project):
        from memento_ai.mcp_server import resource_all

        with _patch_dir(memento_project):
            result = resource_all()
        assert "SUMMARY" in result
        assert "Core" in result
        assert "API" in result


class TestPrompt:
    def test_project_context(self, memento_project):
        from memento_ai.mcp_server import project_context

        with _patch_dir(memento_project):
            result = project_context()
        assert "memento-ai" in result
        assert "Core" in result


class TestRequireMemento:
    def test_raises_when_no_project(self):
        from memento_ai.mcp_server import _require_memento

        with patch(PATCH_TARGET, return_value=None):
            with pytest.raises(RuntimeError, match="Not a memento project"):
                _require_memento()
