"""Tests for memory exporters."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from memento_ai.export import export_claude, export_copilot, export_cursor, export_memory
from memento_ai.memory import write_module
from memento_ai.state import save_state


@pytest.fixture
def memento_project(tmp_path):
    """Create a minimal memento project structure."""
    memento_dir = tmp_path / ".memento"
    memento_dir.mkdir()
    memory_dir = memento_dir / "memory"
    memory_dir.mkdir()

    config_content = '[llm]\nprovider = "claude-cli"\n\n[memory]\ndir = "memory"\n'
    (memento_dir / "config.toml").write_text(config_content)
    save_state(memento_dir, {"last_commit": None, "commits_processed": 0})

    write_module(memory_dir, "SUMMARY", "# Project Summary\n\nA test project.")
    write_module(memory_dir, "core", "# Core Module\n\n- Main logic")
    write_module(memory_dir, "api", "# API Module\n\n- REST endpoints")

    return tmp_path


class TestExportClaude:
    def test_creates_claude_md(self, memento_project):
        memento_dir = memento_project / ".memento"
        from memento_ai.config import load_config

        config = load_config(memento_dir)
        content, path = export_claude(memento_dir, config)

        assert path == memento_project / "CLAUDE.md"
        assert path.exists()
        assert "memento-ai" in content
        assert "Project Summary" in content
        assert "Core Module" in content
        assert "API Module" in content

    def test_claude_md_has_warning(self, memento_project):
        memento_dir = memento_project / ".memento"
        from memento_ai.config import load_config

        config = load_config(memento_dir)
        content, _ = export_claude(memento_dir, config)
        assert "Do not edit manually" in content


class TestExportCursor:
    def test_creates_cursor_rules(self, memento_project):
        memento_dir = memento_project / ".memento"
        from memento_ai.config import load_config

        config = load_config(memento_dir)
        content, path = export_cursor(memento_dir, config)

        assert path == memento_project / ".cursor" / "rules" / "memento.mdc"
        assert path.exists()
        assert "alwaysApply: true" in content
        assert "Core Module" in content

    def test_cursor_has_frontmatter(self, memento_project):
        memento_dir = memento_project / ".memento"
        from memento_ai.config import load_config

        config = load_config(memento_dir)
        content, _ = export_cursor(memento_dir, config)
        assert content.startswith("---\n")
        assert "globs:" in content


class TestExportCopilot:
    def test_creates_copilot_instructions(self, memento_project):
        memento_dir = memento_project / ".memento"
        from memento_ai.config import load_config

        config = load_config(memento_dir)
        content, path = export_copilot(memento_dir, config)

        assert path == memento_project / ".github" / "copilot-instructions.md"
        assert path.exists()
        assert "Core Module" in content

    def test_copilot_creates_github_dir(self, memento_project):
        memento_dir = memento_project / ".memento"
        from memento_ai.config import load_config

        config = load_config(memento_dir)
        export_copilot(memento_dir, config)
        assert (memento_project / ".github").is_dir()


class TestExportMemory:
    def test_export_memory_claude(self, memento_project):
        with patch(
            "memento_ai.export.find_memento_dir",
            return_value=memento_project / ".memento",
        ):
            _, path = export_memory("claude")
        assert path.exists()

    def test_export_memory_invalid_format(self, memento_project):
        with patch(
            "memento_ai.export.find_memento_dir",
            return_value=memento_project / ".memento",
        ):
            with pytest.raises(ValueError, match="Unknown format"):
                export_memory("invalid")


class TestSummaryFirst:
    def test_summary_appears_first(self, memento_project):
        memento_dir = memento_project / ".memento"
        from memento_ai.config import load_config

        config = load_config(memento_dir)
        content, _ = export_claude(memento_dir, config)

        summary_pos = content.find("Project Summary")
        core_pos = content.find("Core Module")
        assert summary_pos < core_pos
