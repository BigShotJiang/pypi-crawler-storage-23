"""Tests for the processing pipeline."""

from memento_ai.config import DEFAULT_CONFIG
from memento_ai.git import get_commits
from memento_ai.memory import get_memory_dir, list_modules
from memento_ai.processor import process_commit, process_commits
from memento_ai.state import load_state


def test_process_single_commit(temp_git_repo, memento_dir, mock_provider):
    commits = get_commits(cwd=temp_git_repo)
    result = process_commit(
        commits[1], mock_provider, memento_dir, DEFAULT_CONFIG, repo_root=temp_git_repo
    )
    assert result["commit"] == commits[1].short_hash
    assert "core" in result["modules_updated"]
    assert len(mock_provider.calls) >= 2  # analyze + route + update


def test_process_multiple_commits(temp_git_repo, memento_dir, mock_provider):
    commits = get_commits(cwd=temp_git_repo)
    results = process_commits(
        commits[1:], mock_provider, memento_dir, DEFAULT_CONFIG, repo_root=temp_git_repo
    )
    assert len(results) == 2

    state = load_state(memento_dir)
    assert state["commits_processed"] == 2
    assert state["last_commit"] == commits[2].hash

    memory_dir = get_memory_dir(memento_dir, DEFAULT_CONFIG)
    modules = list_modules(memory_dir)
    assert "core" in modules
    assert "SUMMARY" in modules


def test_process_skips_ignored_files(temp_git_repo, memento_dir, mock_provider):
    """Commit with only ignored files should be skipped."""
    import os
    import subprocess

    env = {
        **os.environ,
        "GIT_AUTHOR_NAME": "Test",
        "GIT_AUTHOR_EMAIL": "test@test.com",
        "GIT_COMMITTER_NAME": "Test",
        "GIT_COMMITTER_EMAIL": "test@test.com",
    }
    (temp_git_repo / "package-lock.json").write_text("{}")
    subprocess.run(
        ["git", "add", "."], cwd=temp_git_repo, capture_output=True, env=env
    )
    subprocess.run(
        ["git", "commit", "-m", "Add lock file"],
        cwd=temp_git_repo, capture_output=True, env=env,
    )

    commits = get_commits(cwd=temp_git_repo)
    last_commit = commits[-1]
    result = process_commit(
        last_commit, mock_provider, memento_dir, DEFAULT_CONFIG, repo_root=temp_git_repo
    )
    assert result.get("skipped") is True
