#!/usr/bin/env python
# ******************************************************************************
# Copyright 2025 Brainchip Holdings Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ******************************************************************************
"""
Custom layers definitions.
"""

import math
import numpy as np
import tensorflow as tf
import tf_keras as keras

from tf_keras.layers import Layer, ReLU, Conv3D
from tf_keras.activations import swish, gelu
from tf_keras.utils import register_keras_serializable
from scipy.special import jacobi


def act_to_layer(act, **kwargs):
    """ Get activation layer from string.

    This is needed because one cannot serialize a class in layer.get_config, the string is thus
    serialized instead.

    Args:
        act (str): string that values in ['GeLU', 'ReLUx', 'swish'] and that allows to choose from
            GeLU, ReLUx or swish activation inside MLP.

    Returns:
        keras.layers: the activation layer class
    """
    if act == 'GeLU':
        act_funct = gelu
    elif 'ReLU' in act:
        if act == 'ReLU':
            max_value = None
        else:
            try:
                max_value = float(act[4:])
            except ValueError:
                raise ValueError("ReLU must be in the form 'ReLUx', where x is the max-value")
        act_funct = ReLU(max_value=max_value, **kwargs)
    elif act == 'swish':
        act_funct = swish
    else:
        raise NotImplementedError(
            f"act should be in ['GeLU', 'ReLUx', 'swish'] but received {act}.")

    return act_funct


def get_ortho_polynomials(length, degrees, alpha, beta):
    """ Generate the set of Jacobi orthogonal polynomials with shape (degrees + 1, length)

    Args:
        length (int): The length of the discretized temporal kernel,
            assuming the range [0, 1] for the polynomials.
        degrees (int): The maximum polynomial degree. Note that degrees + 1 polynomials
            will be generated (counting the constant).
        alpha (float): The alpha Jacobi parameter.
        beta (float): The beta Jacobi parameter.

    Returns:
        np.ndarray: shaped (degrees + 1, length)
    """
    coeffs = np.vstack([np.pad(np.flip(jacobi(degree, alpha, beta).coeffs), (0, degrees - degree))
                        for degree in range(degrees + 1)]).astype(np.float32)
    steps = np.linspace(0, 1, length + 1)
    X = np.stack([steps ** (i + 1) / (i + 1) for i in range(degrees + 1)])
    polynomials_integrated = coeffs @ X
    transform = np.diff(polynomials_integrated, 1, -1) * length
    return transform


@register_keras_serializable()
class PleiadesLayer(Conv3D):
    """A 3D convolutional layer utilizing orthogonal polynomials for kernel transformation.

    Inherits from `Conv3D` and modifies its kernel transformation before applying convolution.

    Args:
        filters (int): Number of output filters.
        kernel_size (tuple): Size of the convolution kernel.
        degrees (int): Degree of the orthogonal polynomials.
        alpha (float): Alpha parameter for the orthogonal polynomials.
        beta (float): Beta parameter for the orthogonal polynomials.
        **kwargs: Additional arguments passed to `Conv3D`.
    """
    def __init__(self, filters, kernel_size, degrees, alpha, beta, **kwargs):
        super().__init__(filters, kernel_size, **kwargs)

        self.degrees = degrees
        self.alpha = alpha
        self.beta = beta

    def build(self, input_shape):
        with tf.name_scope(self.name + '/'):
            super().build(input_shape)
            # Generate the transformation matrix
            transform = get_ortho_polynomials(self.kernel_size[0], self.degrees, self.alpha,
                                              self.beta)
            transform = tf.convert_to_tensor(transform, dtype=tf.float32)
            # Normalize transform based on input dimensions
            scale = tf.sqrt(tf.cast(input_shape[-1],
                                    tf.float32)) * tf.sqrt(tf.cast(self.kernel_size[0],
                                                                   tf.float32))
            self.transform = transform / scale
            new_kernel_shape = (self.kernel.shape[-2], self.filters, self.kernel_size[1],
                                self.kernel_size[2], self.degrees + 1)
            self.kernel = self.add_weight(shape=new_kernel_shape,
                                          initializer=self.kernel_initializer,
                                          trainable=True, name="kernel")

    def call(self, inputs):
        # Apply polynomial transformation to kernel
        kernel = tf.tensordot(self.kernel, self.transform, axes=[[4], [0]])
        kernel = tf.transpose(kernel, perm=[4, 2, 3, 0, 1])
        # Perform convolution with transformed kernel
        if self.groups > 1:
            # The '_jit_compiled_convolution_op' is a specialized operation that efficiently
            # handles grouped convolutions, addressing limitations in some TensorFlow versions
            # where grouped convolutions are not directly supported.
            conv_output = self._jit_compiled_convolution_op(inputs, kernel)
        else:
            conv_output = self.convolution_op(inputs, kernel)
        if self.use_bias:
            conv_output = tf.nn.bias_add(conv_output, self.bias)
        return conv_output

    def get_config(self):
        config = super().get_config()
        config.update({
            'degrees': self.degrees,
            'alpha': self.alpha,
            'beta': self.beta
        })
        return config


@keras.saving.register_keras_serializable()
class Kernelized(Layer):
    """ Temporal convolution layer where the temporal kernel is parameterized from a set of
    matrices/vectors, namely the (A, B, C, log_dt) parameters.

    In short, this layer performs the following core operations:

        1) building the temporal kernel from the (A, B, C, log_dt) parameters, which is done by
           calling :function:`kernelize`
        2) actually convolving the input with said kernel, which can be done efficiency by calling
           :function:`_padded_fft_corr`

    Args:
        num_coeffs (int): number of embedding coefficients
        out_channels (int): number of output channels
        repeat (int, optional): number of times to repeat the embedding coefficients. The total
            hidden dimension (the internal state units) is given simply by num_coeffs x repeat.
            Defaults to 2.
        speed (int, optional): hyperparameter for initializing the log_dt of the kernelized layer,
            allows to split internal states into block. Defaults to 4.
        speed_range (int, optional): hyperparameter for initializing the log_dt of the kernelized
            layer, allows to split internal states into block. Defaults to 8.
        force_full_conv (bool, optional): if True, force the layer to use the FFT-based full
            convolution path regardless of the runtime heuristic. Defaults to False.

    """

    def __init__(self, num_coeffs, out_channels, repeat=2, speed=4, speed_range=8,
                 force_full_conv=False, **kwargs):
        super().__init__(**kwargs)

        self.num_coeffs = num_coeffs
        self.out_channels = out_channels
        self.repeat = repeat
        self.speed = speed
        self.speed_range = speed_range
        self.force_full_conv = force_full_conv

    def build(self, input_shape):
        with tf.name_scope(self.name + '/'):
            super().build(input_shape)
            _, L, in_channels = input_shape

            # S4D state matrix (A) and input vector (B) initialization.
            A_real = 0.5 * np.ones(self.num_coeffs)
            A_imag = (math.pi * np.arange(self.num_coeffs)).astype('float32')
            log_A_real = np.log(A_real).astype('float32')
            B = np.ones(self.num_coeffs).astype('float32')

            A = np.stack([log_A_real, A_imag], -1)

            # initialize the (A, B, C) matrices with suitable scales
            # (hid_channels, 2)
            A = np.tile(A, (self.repeat, 1))
            B = B[np.newaxis, :] / np.sqrt(in_channels)
            # (in_channels, hid_channels)
            B = np.tile(B, (in_channels, self.repeat))
            hid_channels = self.num_coeffs * self.repeat
            # (hid_channels, out_channels)
            C = np.random.randn(hid_channels, self.out_channels) * np.sqrt(2 / hid_channels)

            # apply a different time step to each repeated set of coefficients
            log_dt = np.log(1 / (L - 1))
            log_dt = np.linspace(log_dt + np.log(self.speed),
                                 log_dt + np.log(self.speed) + np.log(self.speed_range),
                                 self.repeat)
            log_dt = log_dt.repeat(self.num_coeffs)  # (hid_channels)

            self.A = self.add_weight(name='A', shape=A.shape,
                                     initializer=tf.constant_initializer(A), trainable=True)
            self.B = self.add_weight(name='B', shape=B.shape,
                                     initializer=tf.constant_initializer(B), trainable=True)
            self.C = self.add_weight(name='C', shape=C.shape,
                                     initializer=tf.constant_initializer(C), trainable=True)
            self.log_dt = self.add_weight(name='log_dt', shape=log_dt.shape,
                                          initializer=tf.constant_initializer(log_dt),
                                          trainable=True)

    def call(self, inputs):
        # The reason why there are two separate paths for performing FFT convolution during
        # training is due to selecting the optimal order of operations (both memory and compute
        # wise) depending on the batch_size, in_channels, out_channels, and num_coeffs.

        # In depth explanation:
        # for the following contraction
        #       einsum('bcl,nc,nl,dn->bdl', input, B_hat, K, C)
        # there are essentially two viable contraction orders (here assuming FFT conv is of linear
        # cost):
        #       nc,dn,nl,bcl, or nc,dn->cnd,nl->cdl,bcl->bdl
        #       with cost: C_in * C_out * (N + N * L + B * L) or roughly C_in * C_out * L * (B + N)
        #
        #       bcl,nc,nl,dn, or bcl,nc->bnl,nl->bnl,dn->bdl
        #       with cost: B * L * N * (C_in + 1 + C_out) or roughly B * L * N * (C_in + C_out)
        #
        # So as a rule of thumb, one should choose option 1 over option 2 if:
        #       (1 / C_in) + (1 / C_out) > (1 / B) + (1 / N)

        # Note that the two paths are functionally exactly the same and only concern training and
        # have zero effect on inference  (or conversion to inference mode).
        _, length, in_channels = inputs.shape
        num_coeffs_total = self.C.shape[0]
        full_conv_flag = (1 / in_channels + 1 / self.out_channels) > \
            (1 / tf.shape(inputs)[0] + 1 / num_coeffs_total)
        full_conv_flag |= self.force_full_conv

        # generate the basis kernels and coefficients
        _, B_hat, dtA = zoh_discretize(self.A, self.B, self.log_dt)
        steps = tf.cast(tf.range(length, dtype=tf.float32), dtype=tf.complex64)
        # (L, N)
        K = tf.expand_dims(steps, axis=-1) * dtA
        K = tf.reverse(tf.exp(K), axis=tf.constant([0], dtype=tf.int32))

        if full_conv_flag:
            # performs FFT convolution with the input and the generated kernel
            K = tf.math.real(K)
            # kernels shaped (L, C_in, C_out)
            kernel = tf.einsum('cn,nd,ln->lcd', B_hat, self.C, K)
            inputs, kernel = tf.transpose(inputs, (0, 2, 1)), tf.transpose(kernel, (1, 2, 0))
            output = _padded_fft_corr(inputs, kernel)
            return tf.transpose(output, (0, 2, 1))

        else:
            # explicitly computes the internal states
            inputs_projected = tf.einsum('blc,cn->bnl', inputs, B_hat)
            internal_states = _padded_fft_corr(inputs_projected, tf.math.real(tf.transpose(K)))
            output = tf.einsum('bnl,nd->bld', internal_states, self.C)
            return output

    def get_config(self):
        config = super().get_config()
        config.update({
            'num_coeffs': self.num_coeffs,
            'out_channels': self.out_channels,
            'repeat': self.repeat,
            'speed': self.speed,
            'speed_range': self.speed_range,
            'force_full_conv': self.force_full_conv
        })
        return config


@keras.saving.register_keras_serializable()
class Stride(Layer):
    """ Layer for striding along the temporal (depth) dimension.

    Args:
        stride (int): the stride value
    """

    def __init__(self, stride, **kwargs):
        super().__init__(**kwargs)
        self.stride = stride

    def call(self, inputs):
        return inputs[:, (self.stride - 1)::self.stride, :]

    def get_config(self):
        config = super().get_config()
        config.update({'stride': self.stride})
        return config


@tf.function
def zoh_discretize(A, B, log_dt):
    """ Generates discretized input and state matrices using zero-order-hold (ZOH) method.

    Discretization is not the same as quantization:

        1) discretization is obtaining the state matrices evolving the system in discrete time
        2) quantization is using finite-precision to express the values of the matrix elements

    Args:
        A (tf.Tensor): the complex (view as real) state matrix shaped (N, 2)
        B (tf.Tensor): the input matrix shaped (C_in, N)
        log_dt (tf.Tensor): the logged step size

    Returns:
        tf.Tensor, tf.Tensor, tf.Tensor: A_hat, B_hat and dtA which are the discretized state
        matrix, the discretized input matrix and the log of A_hat, used to general the temporal
        kernel.
    """
    log_A_real, A_imag = A[:, 0], A[:, 1]
    dt = tf.exp(log_dt)

    # an arbitrary function to guarantee negativity, an alternative is to use softplus
    A_real = -tf.exp(log_A_real)
    A = tf.complex(A_real, A_imag)

    dtA = tf.cast(dt, dtype=tf.complex64) * A
    B_hat = dt * B
    A_hat = tf.exp(dtA)

    # the first two matrices (A_hat, B_hat) need to be quantized if A_hat is quantized, dtA needs to
    # be recomputed via, say, tf.log(A_hat + 1e-8)
    return A_hat, B_hat, dtA


@tf.function
def _padded_fft_corr(input, filters):
    """ Performs padded 1D FFT convolution ('SAME' type) between input and filters.

    Operation is based on the following einsum equation: 'bcl,cdl->bdl' (full convolution),
    or 'bcl,cl->bcl' (dw-separable convolution).

    The input will be zero-padded in front to length 2*L-1.
    The length dimension (L) must appear last in every term.

    Args:
        inputs (tf.Tensor): tensor generally expected to be shaped (batch, in_channels, length)
        filters (tf.Tensor): tensor generally expected to be shaped
            (in_channels, out_channels, length) or (in_channels, length)

    Returns:
        tf.Tensor: the output tensor
    """
    L = tf.expand_dims(tf.shape(filters)[-1], axis=0)
    # flip filters along length dimension, so convolution becomes correlation
    filters = tf.reverse(filters, axis=tf.constant([-1]))

    input_f = tf.signal.rfft(input, fft_length=2 * L)
    filters_f = tf.signal.rfft(filters, fft_length=2 * L)

    if tf.equal(tf.rank(filters_f), 3):
        output_f = tf.reduce_sum(tf.expand_dims(input_f, 2) * filters_f, 1)
    else:
        output_f = input_f * filters_f

    out = tf.signal.irfft(output_f, fft_length=2 * L)[..., :L[0]]
    out.set_shape((None,) + filters.shape[-2:])
    return out
