#!/usr/bin/env python
# ******************************************************************************
# Copyright 2023 Brainchip Holdings Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ******************************************************************************
"""
SC10 speech_commands dataset preprocessing.
"""

import numpy as np
import tensorflow as tf
import tensorflow_datasets as tfds


def _pad_to(input, length):
    """ Pad/crop an input sequence such that the length of the last axis is the desired length.

    The padding/cropping will always be applied to the beginning.

    Args:
        input (np.array): the input to be padded/cropped
        length (int): the desired length

    Returns:
        np.array: the padded/cropped sequence
    """
    input = input.numpy().astype('float32')
    old_length = input.shape[-1]

    # pad along the last axis
    if length > old_length:
        npad = [(0, 0)] * input.ndim
        npad[-1] = (0, length - old_length)
        return np.pad(input, npad)
    # crop along the last axis
    if length < old_length:
        return input[..., -length:]
    return input


def preprocess_sc10(length, path=None):
    """ Preprocess the SC10 speech_commands dataset.

    Args:
        length (int): data length (first dimension of input_shape)
        path (str, optional): data path. Defaults to None.

    Returns:
        tf.tensor, tf.tensor, tf.tensor, tf.tensor: data and labels for training and test sets
    """
    # waveforms needed to be padded/cropped to a length of power-of-2 so that it is possible to
    # apply FFT to it in the network
    raw_ds_train = tfds.load('speech_commands', split='train', data_dir=path, shuffle_files=True)
    raw_ds_test = tfds.load('speech_commands', split='test', data_dir=path, shuffle_files=False)

    # Filter the dataset to only include the 10 classes
    raw_ds_train = raw_ds_train.filter(lambda x: x['label'] < 10)
    raw_ds_test = raw_ds_test.filter(lambda x: x['label'] < 10)

    # grab the raw audio waveforms and signals and store them as numpy arrays
    X_train, y_train = zip(*[(_pad_to(data['audio'], length), data['label'].numpy())
                           for data in raw_ds_train])
    X_test, y_test = zip(*[(_pad_to(data['audio'], length), data['label'].numpy())
                         for data in raw_ds_test])
    X_train, y_train, X_test, y_test = [np.stack(arr) for arr in [X_train, y_train, X_test, y_test]]

    X_train, X_test = X_train[..., np.newaxis], X_test[..., np.newaxis]

    # convert to tf.tensor
    X_train, y_train, X_test, y_test = \
        [tf.convert_to_tensor(arr) for arr in [X_train, y_train, X_test, y_test]]

    return X_train, y_train, X_test, y_test
