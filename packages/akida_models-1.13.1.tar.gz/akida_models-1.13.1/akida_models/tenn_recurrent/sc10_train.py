#!/usr/bin/env python
# ******************************************************************************
# Copyright 2023 Brainchip Holdings Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ******************************************************************************
"""
Training script for SC10 recurrent TENNs.
"""

import os
import argparse
import numpy as np
import tensorflow as tf
import tf_keras as keras
import warnings

from contextlib import nullcontext
from tqdm import tqdm
from tf_keras.losses import SparseCategoricalCrossentropy
from tf_keras.metrics import SparseCategoricalAccuracy
from tf_keras.models import load_model

import akida
from cnn2snn import convert
from quantizeml.models.transforms.transforms_utils import get_layers_by_type
from quantizeml.layers import StatefulRecurrent, reset_states, update_batch_size

from .sc10_preprocessing import preprocess_sc10
from .convert_recurrent import convert_to_stateful
from ..param_scheduler import CosineDecayWithLinearWarmup
from ..utils import get_tensorboard_callback
from ..training import get_training_parser, print_history_stats, RestoreBest, save_model


def get_data(length, data_path, batch_size, timestep):
    """ Loads SC10 speech_commands data.

    Args:
        length (int): data length (first dimension of input_shape)
        data_path (str): path to data
        batch_size (int): the batch size
        timestep (int): split dataset in chunks.

    Returns:
        tf.dataset, tf.dataset, int, int, int: the train and test datasets, train, test steps
            and timestep per sample.
    """
    def split_batch_in_chunks(x, y):
        # Split x in chunks, following:
        # (B, signal_len, 1) -> (B, T, timesteps, 1)
        segments_per_sample = x.shape[1] // timestep
        x = tf.reshape(x, (-1, segments_per_sample, timestep, 1))
        # Transpose batch x temporal dims: (B, T, timestep) -> (T, B, timestep)
        x = tf.transpose(x, (1, 0, 2, 3))
        # Clone labels to match with (T, B)
        y = tf.tile([y], multiples=[segments_per_sample, 1])
        return x, y

    X_train, y_train, X_test, y_test = preprocess_sc10(length, data_path)

    n_train, n_test = X_train.shape[0], X_test.shape[0]
    train_inds = tf.data.Dataset.range(n_train)
    test_inds = tf.data.Dataset.range(n_test)

    signal_len = X_train.shape[1]
    segments_per_sample = signal_len / timestep
    assert signal_len % timestep == 0, f"Model timestep must be multiple of {signal_len}"
    train_steps = segments_per_sample * (n_train // batch_size)
    test_steps = segments_per_sample * (n_test // batch_size)

    train_ds = train_inds.shuffle(n_train).repeat().map(lambda ind: (X_train[ind], y_train[ind]))
    train_ds = train_ds.batch(batch_size, drop_remainder=True)
    train_ds = train_ds.map(split_batch_in_chunks).prefetch(tf.data.AUTOTUNE).unbatch()
    test_ds = test_inds.map(lambda ind: (X_test[ind], y_test[ind])).cache()
    test_ds = test_ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)
    test_ds = test_ds.map(split_batch_in_chunks).prefetch(tf.data.AUTOTUNE).unbatch()

    return train_ds, test_ds, train_steps, test_steps, segments_per_sample


def train_model(model, train_ds, val_ds, steps_per_epoch, epochs):
    """ Trains the model.

    Args:
        model (keras.Model): the model to train
        train_ds (tensorflow.dataset): train data
        val_ds (tensorflow.dataset): validation data
        steps_per_epoch (int): training steps
        epochs (int): the number of epochs
    """
    # Model checkpoints (save best model and retrieve it when training is complete)
    callbacks = [RestoreBest(model, monitor='val_sparse_categorical_accuracy')]

    # Add Tensorboard logs
    tensorboard = get_tensorboard_callback('logs', prefix='sc10')
    callbacks.append(tensorboard)

    history = model.fit(x=train_ds,
                        validation_data=val_ds,
                        epochs=epochs,
                        steps_per_epoch=steps_per_epoch,
                        callbacks=callbacks)
    print_history_stats(history)


def compile_model(model, total_steps):
    """ Compiles the model.

    Args:
        model (keras.Model): the model to compile
        total_steps (int): number of training steps
    """
    learning_rate = 0.01
    warm_up_ratio = 0.025
    scheduler = CosineDecayWithLinearWarmup(learning_rate, warm_up_ratio, total_steps)
    optimizer = keras.optimizers.experimental.AdamW(learning_rate=scheduler, weight_decay=0.05)

    model.compile(optimizer=optimizer,
                  loss=SparseCategoricalCrossentropy(from_logits=True),
                  metrics=[SparseCategoricalAccuracy()])


def evaluate_stateful_model(model, val_ds, total_steps, segments_per_sample, in_akida=False):
    """ Evaluates the model.

    Args:
        model (keras.model): model to evaluate
        val_ds (tf.dataset): validation data
        total_steps (int): total steps in validation data
        segments_per_sample (int): steps per each audio
        in_akida (bool, optional): True when the evaluation is done with akida.
            Defaults to False.
    """
    # Wrap the model call in a tf function to speed up the inference in Graph mode
    if in_akida:
        model = convert(model)
    else:
        model_func = tf.function(model)

    # Manual evaluation routine to prevent compilation
    cumulated_preds, correct, num_samples = 0, 0, 0
    pbar = tqdm(total=total_steps)

    for batch_id, (frame, label) in enumerate(val_ds):
        if in_akida:
            frame = frame.numpy().astype(np.int16)
            prediction = model.forward(np.expand_dims(frame, 0))
        else:
            prediction = model_func(frame)

        # Accumulate average predictions over time
        cumulated_preds += tf.math.reduce_sum(prediction, axis=1) / prediction.shape[1]

        reset = (batch_id % segments_per_sample) == (segments_per_sample - 1)
        if reset:
            # Compute average prediction over the sample
            correct += tf.math.reduce_sum(tf.cast(tf.math.argmax(cumulated_preds, -1) == label,
                                                  tf.int32)).numpy()
            num_samples += label.shape[0]
            cumulated_preds = 0
            if in_akida:
                model = akida.Model(model.layers)
            else:
                reset_states(model)
        pbar.update(1)

    print(f"Accuracy: {correct / num_samples * 100: .2f}%")


def extract_samples(out_file, train_ds, num_samples):
    """ Extract calibration samples from the train set.

    Samples are extracted from the middle of a word, e.g with a 8192 offset for the 16384 points.

    Args:
        out_file (str): name of output file
        train_ds (tf.dataset): set to extract samples from
        num_samples (int): number of desired samples per-word
    """
    samples_x, _ = next(train_ds.as_numpy_iterator())
    half_samples = samples_x.shape[1] // 2
    assert num_samples <= half_samples, f"Cannot extract {num_samples} from the dataset, maximum "\
        f"value is {half_samples}."

    samples = {"data": np.array(samples_x[:, half_samples:half_samples + num_samples, :], "int16")}
    np.savez(out_file, **samples)
    print(f"Samples saved as {out_file}")


def main():
    """ Entry point for script and CLI usage.

    Note: SC10 (Speech Commands 10-class subset): can be downloaded using
    [`tfds.datasets.speech_commands`](https://www.tensorflow.org/datasets/catalog/speech_commands),
    with the 10-class subset being extracted during dataset preprocessing, along with normalization
    of audio waveforms.
    """
    global_parser = argparse.ArgumentParser(add_help=False)
    global_parser.add_argument("-d", "--data", type=str, default=None,
                               help="Path to the SC10 speech_commands dataset.")
    parsers = get_training_parser(batch_size=128, extract=True, global_parser=global_parser)

    # Add an option to specify the number of samples to extract (per-word)
    extract_parser = parsers[4]
    extract_parser.add_argument("-ns", "--num_samples", type=int, default=1024,
                                help="Number of samples to extract per-word.")

    # Add a parser to allow conversion to "stateful" version
    subparsers = parsers[-1]
    convert_parser = subparsers.add_parser("convert", parents=[global_parser],
                                           help="Converts to a stateful model.")
    convert_parser.add_argument("-ts", "--timesteps", type=int,
                                default=256, help="Model timesteps.")

    args = parsers[0].parse_args()

    # Load the source model
    model = load_model(args.model)

    if args.action == "convert":
        model_stateful = convert_to_stateful(model, timesteps=args.timesteps)
        save_model(model_stateful, args.model, action_str='stateful')
        return

    is_stateful = get_layers_by_type(model, StatefulRecurrent)
    is_akida_eval = args.action == "eval" and args.akida
    if is_akida_eval and args.batch_size != 1:
        args.batch_size = 1
        warnings.warn("Batch size must be 1 for Akida evaluation, forcing it to 1 and continuing "
                      "execution.")

    # Hardcoded dataset length when model is already converted
    timestep = model.input_shape[1]
    length = timestep if not is_stateful else 16384

    # Force CPU execution when evaluating on Akida to allow parallelization
    with tf.device('/cpu:0') if is_akida_eval else nullcontext():
        # Load data
        train_ds, val_ds, train_steps, val_steps, segments_per_sample = get_data(
            length, args.data, args.batch_size, timestep)

        # Compile model
        if args.action == "train":
            total_steps = train_steps * args.epochs
        else:
            total_steps = val_steps
        compile_model(model, total_steps)

        # Disable QuantizeML assertions
        os.environ["ASSERT_ENABLED"] = "0"

        # Train model
        if args.action == "train":
            if is_stateful:
                raise NotImplementedError("Training of stateful model is not supported.")
            train_model(model, train_ds, val_ds, train_steps, args.epochs)
            save_model(model, args.model, args.savemodel, args.action)
        elif args.action == "eval":
            if is_stateful:
                model = update_batch_size(model, args.batch_size)
                evaluate_stateful_model(model, val_ds, total_steps, segments_per_sample, args.akida)
            else:
                history = model.evaluate(val_ds, steps=val_steps)
                print(history)
        elif args.action == 'extract':
            extract_samples(args.savefile, train_ds, args.num_samples)


if __name__ == "__main__":
    main()
