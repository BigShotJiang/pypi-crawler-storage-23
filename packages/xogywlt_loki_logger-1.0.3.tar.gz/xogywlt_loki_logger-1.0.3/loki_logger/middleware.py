"""
LoggingMiddleware: WSGI / ASGI middleware that logs every HTTP request.

WSGI usage (Flask, Django, etc.)
---------------------------------
::

    from loki_logger import get_logger, LoggingMiddleware

    app = Flask(__name__)
    app.wsgi_app = LoggingMiddleware(app.wsgi_app, logger=get_logger("http"))


ASGI usage (FastAPI, Starlette, etc.)
--------------------------------------
::

    from loki_logger import get_logger, LoggingMiddleware

    app = FastAPI()
    app.add_middleware(LoggingMiddleware, logger=get_logger("http"))
"""

import time
from typing import Any, Callable, Dict, Iterable, List, Optional, Set

from .levels import LogLevel
from .logger import Logger, get_logger


class LoggingMiddleware:
    """
    Dual WSGI / ASGI middleware that emits an INFO (or WARNING/ERROR on
    failure) log record for each HTTP request.

    Log record extra fields
    -----------------------
    ``method``, ``path``, ``status_code``, ``duration_ms``, ``remote_addr``
    """

    def __init__(
        self,
        app: Any,
        logger: Optional[Logger] = None,
        exclude_paths: Optional[Iterable[str]] = None,
    ) -> None:
        self._app = app
        self.logger = logger or get_logger("http")
        self._exclude: Set[str] = set(exclude_paths or [])

    # ---------------------------------------------------------------------- #
    # WSGI interface                                                           #
    # ---------------------------------------------------------------------- #

    def __call__(self, environ: Dict[str, Any], start_response: Callable[[str, List[str], Optional[Any]], Any]) -> Any:
        # Detect ASGI by checking for the scope / receive / send signature.
        # If ``environ`` is actually an ASGI scope dict, delegate to the async path.
        if environ.get("type") in ("http", "websocket"):
            # Called from an ASGI runner — return a coroutine.
            # import asyncio

            return self._asgi_call(environ, start_response)  # type: ignore[return-value]

        return self._wsgi_call(environ, start_response)

    def _wsgi_call(self, environ: Dict[str, Any], start_response: Callable[[str, List[str], Optional[Any]], Any]) -> Any:
        status_code = 200
        path = environ.get("PATH_INFO", "/")
        if path in self._exclude:
            return self._app(environ, start_response)

        method = environ.get("REQUEST_METHOD", "UNKNOWN")
        remote = environ.get("REMOTE_ADDR", "-")
        status_holder: List[str] = []

        def _start_response(status: str, headers: List[str], exc_info: Optional[Any] = None) -> Any:
            status_holder.append(status)
            return start_response(status, headers, exc_info)

        t0 = time.perf_counter()
        try:
            result = self._app(environ, _start_response)
            status_code = int(status_holder[0].split(" ")[0]) if status_holder else 0
            return result
        except Exception:
            status_code = 500
            raise
        finally:
            duration_ms = round((time.perf_counter() - t0) * 1000, 2)
            level = LogLevel.INFO if status_code < 400 else (
                LogLevel.WARNING if status_code < 500 else LogLevel.ERROR
            )
            self.logger.log(
                level,
                f"{method} {path} → {status_code}",
                method=method,
                path=path,
                status_code=status_code,
                duration_ms=duration_ms,
                remote_addr=remote,
            )

    # ---------------------------------------------------------------------- #
    # ASGI interface                                                           #
    # ---------------------------------------------------------------------- #

    async def _asgi_call(self, scope: Dict[str, Any], receive: Any, send: Any) -> None:
        status_code = 200
        if scope.get("type") != "http":
            await self._app(scope, receive, send)
            return

        path = scope.get("path", "/")
        if path in self._exclude:
            await self._app(scope, receive, send)
            return

        method = scope.get("method", "UNKNOWN")
        client = scope.get("client")
        remote = f"{client[0]}:{client[1]}" if client else "-"
        status_holder: List[int] = []

        async def _send(message: Dict[str, Any]) -> None:
            if message.get("type") == "http.response.start":
                status_holder.append(message.get("status", 0))
            await send(message)

        t0 = time.perf_counter()
        try:
            await self._app(scope, receive, _send)
            status_code = int(status_holder[0] if status_holder else 0)
        except Exception:
            status_code = 500
            raise
        finally:
            duration_ms = round((time.perf_counter() - t0) * 1000, 2)
            level = LogLevel.INFO if status_code < 400 else (
                LogLevel.WARNING if status_code < 500 else LogLevel.ERROR
            )
            self.logger.log(
                level,
                f"{method} {path} → {status_code}",
                method=method,
                path=path,
                status_code=status_code,
                duration_ms=duration_ms,
                remote_addr=remote,
            )
