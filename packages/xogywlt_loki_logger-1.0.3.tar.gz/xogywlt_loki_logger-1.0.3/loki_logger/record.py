"""
LogRecord: holds all metadata for a single log event.
"""

import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple, Type, Union

from .levels import LogLevel

ExcInfo = Union[Tuple[Type[BaseException], BaseException, Any], Tuple[None, None, None], None]

@dataclass
class LogRecord:
    """
    Represents a single log event with all associated metadata.

    Attributes:
        message:    The human-readable log message.
        level:      Severity level of the log event.
        logger_name: Name of the logger that produced this record.
        timestamp:  UTC datetime when the record was created.
        labels:     Key-value pairs used as Loki stream labels.
        extra:      Arbitrary structured fields (added to the log line).
        exc_info:   Tuple (type, value, traceback) if an exception is attached.
    """

    message: str
    level: LogLevel
    logger_name: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    labels: Dict[str, str] = field(default_factory=lambda: {})
    extra: Dict[str, Any] = field(default_factory=lambda: {})
    exc_info: ExcInfo = field(default=None, repr=False)

    # ------------------------------------------------------------------ #
    # Convenience helpers                                                  #
    # ------------------------------------------------------------------ #

    @property
    def timestamp_ns(self) -> int:
        """Return the timestamp as nanoseconds since Unix epoch (required by Loki)."""
        epoch = datetime(1970, 1, 1, tzinfo=timezone.utc)
        delta = self.timestamp - epoch
        return int(delta.total_seconds() * 1_000_000_000)

    @property
    def formatted_exception(self) -> Optional[str]:
        """Return the formatted exception traceback string, or None."""
        if self.exc_info and self.exc_info[0] is not None:
            return "".join(traceback.format_exception(*self.exc_info))
        return None

    def as_dict(self) -> Dict[str, Any]:
        """Serialize the record to a plain dictionary (useful for JSON formatters)."""
        data: Dict[str, Any] = {
            "timestamp": self.timestamp.isoformat(),
            "level": self.level.label(),
            "logger": self.logger_name,
            "message": self.message,
            **self.extra,
        }
        if self.formatted_exception:
            data["exception"] = self.formatted_exception
        return data

    def merged_labels(self, defaults: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """Return labels merged with an optional set of default labels."""
        merged = dict(defaults or {})
        merged.update(self.labels)
        # Always include the log level as a label so Loki can filter by it.
        merged.setdefault("level", self.level.label().lower())
        return merged
