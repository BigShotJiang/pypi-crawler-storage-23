"""
Logger: the main public interface for emitting log records.
"""

import sys
import threading
from typing import Any, Dict, List, Optional

from .context import get_context
from .handlers import BaseHandler, ConsoleHandler
from .levels import LogLevel
from .record import LogRecord


class Logger:
    """
    A named logger that dispatches :class:`~loki_logger.LogRecord` objects to
    one or more :class:`~loki_logger.BaseHandler` instances.

    Parameters
    ----------
    name:
        Logical name for this logger (e.g. ``"myapp.payments"``).
    level:
        Minimum severity that this logger will process. Records below this
        level are silently discarded before being passed to handlers.
    handlers:
        Initial list of handlers. If *None* and this is the root logger, a
        :class:`~loki_logger.ConsoleHandler` is added automatically.
    default_labels:
        Labels automatically merged into every record's label set.
    default_extra:
        Extra fields automatically merged into every record's ``extra`` dict.
    propagate:
        If ``True`` (default) and this logger has a parent, records are also
        forwarded to the parent's handlers after being processed locally.
    """

    def __init__(
        self,
        name: str,
        level: LogLevel = LogLevel.DEBUG,
        handlers: Optional[List[BaseHandler]] = None,
        default_labels: Optional[Dict[str, str]] = None,
        default_extra: Optional[Dict[str, Any]] = None,
        propagate: bool = True,
    ) -> None:
        self.name = name
        self.level = level
        self.handlers: List[BaseHandler] = list(handlers or [])
        self.default_labels: Dict[str, str] = default_labels or {}
        self.default_extra: Dict[str, Any] = default_extra or {}
        self.propagate = propagate
        self.parent: Optional["Logger"] = None
        self._lock = threading.Lock()

    # ---------------------------------------------------------------------- #
    # Handler management                                                       #
    # ---------------------------------------------------------------------- #

    def add_handler(self, handler: BaseHandler) -> "Logger":
        """Add *handler* and return *self* (fluent interface)."""
        with self._lock:
            self.handlers.append(handler)
        return self

    def remove_handler(self, handler: BaseHandler) -> "Logger":
        """Remove *handler* (no-op if not present) and return *self*."""
        with self._lock:
            try:
                self.handlers.remove(handler)
            except ValueError:
                pass
        return self

    def clear_handlers(self) -> "Logger":
        """Remove all handlers and return *self*."""
        with self._lock:
            self.handlers.clear()
        return self

    # ---------------------------------------------------------------------- #
    # Core logging methods                                                     #
    # ---------------------------------------------------------------------- #

    def log(
        self,
        level: LogLevel,
        message: str,
        labels: Optional[Dict[str, str]] = None,
        exc_info: Optional[bool] = False,
        **extra: Any,
    ) -> None:
        if level < self.level:
            return

        # Merge: context fields < default extra < call-site extra
        merged_extra = {**self.default_extra, **get_context(), **extra}
        merged_labels = {**self.default_labels, **(labels or {})}

        exc_tuple = None
        if exc_info:
            exc_tuple = sys.exc_info()

        record = LogRecord(
            message=message,
            level=level,
            logger_name=self.name,
            labels=merged_labels,
            extra=merged_extra,
            exc_info=exc_tuple,
        )

        self._dispatch(record)

    def _dispatch(self, record: LogRecord) -> None:
        with self._lock:
            handlers = list(self.handlers)

        for handler in handlers:
            handler.handle(record)

        if self.propagate and self.parent is not None:
            self.parent._dispatch(record)

    # ---------------------------------------------------------------------- #
    # Convenience methods                                                      #
    # ---------------------------------------------------------------------- #

    def debug(self, message: str, **extra: Any) -> None:
        """Emit a DEBUG-level record."""
        self.log(LogLevel.DEBUG, message, **extra)

    def info(self, message: str, **extra: Any) -> None:
        """Emit an INFO-level record."""
        self.log(LogLevel.INFO, message, **extra)

    def warning(self, message: str, **extra: Any) -> None:
        """Emit a WARNING-level record."""
        self.log(LogLevel.WARNING, message, **extra)

    # Alias
    warn = warning

    def error(self, message: str, exc_info: bool = False, **extra: Any) -> None:
        """
        Emit an ERROR-level record.

        Pass ``exc_info=True`` to attach the current exception's traceback.
        """
        self.log(LogLevel.ERROR, message, exc_info=exc_info, **extra)

    def critical(self, message: str, exc_info: bool = False, **extra: Any) -> None:
        """Emit a CRITICAL-level record."""
        self.log(LogLevel.CRITICAL, message, exc_info=exc_info, **extra)

    # Alias
    fatal = critical

    def exception(self, message: str, **extra: Any) -> None:
        """Emit an ERROR record with the current exception's traceback attached."""
        self.log(LogLevel.ERROR, message, exc_info=True, **extra)

    # ---------------------------------------------------------------------- #
    # Child logger                                                             #
    # ---------------------------------------------------------------------- #

    def get_child(self, suffix: str) -> "Logger":
        """
        Return a child logger whose name is ``<this.name>.<suffix>``.

        The child inherits this logger as its parent and propagates records to
        it by default.
        """
        child = Logger(name=f"{self.name}.{suffix}", level=self.level)
        child.parent = self
        return child

    def __repr__(self) -> str:
        return (
            f"<Logger name={self.name!r} level={self.level.label()} "
            f"handlers={len(self.handlers)}>"
        )


# --------------------------------------------------------------------------- #
# Global registry                                                              #
# --------------------------------------------------------------------------- #

_registry: Dict[str, Logger] = {}
_registry_lock = threading.Lock()
_root_logger: Optional[Logger] = None


def _get_root() -> Logger:
    global _root_logger
    if _root_logger is None:
        _root_logger = Logger(
            name="root",
            level=LogLevel.DEBUG,
            handlers=[ConsoleHandler()],
            propagate=False,
        )
    return _root_logger


def get_logger(name: str = "root") -> Logger:
    """
    Return a logger by name, creating it if it does not exist yet.

    Logger names support a dotted hierarchy (e.g. ``"myapp.db"``) but the
    hierarchy is purely cosmetic — parent linkage must be set up manually or
    via :func:`configure`.
    """
    if name == "root":
        return _get_root()

    with _registry_lock:
        if name not in _registry:
            logger = Logger(name=name)
            logger.parent = _get_root()
            _registry[name] = logger
        return _registry[name]


def configure(
    level: LogLevel = LogLevel.DEBUG,
    handlers: Optional[List[BaseHandler]] = None,
    default_labels: Optional[Dict[str, str]] = None,
    default_extra: Optional[Dict[str, Any]] = None,
) -> Logger:
    """
    Configure (and return) the root logger.

    Calling this function replaces the root logger's handlers with the
    provided ones, making it easy to set up the whole logging pipeline in one
    place::

        from loki_logger import configure, LokiHandler, LogLevel

        configure(
            level=LogLevel.INFO,
            handlers=[LokiHandler(url="http://localhost:3100", labels={"app": "myapp"})],
            default_labels={"env": "production"},
        )
    """
    root = _get_root()
    root.level = level
    if handlers is not None:
        root.clear_handlers()
        for h in handlers:
            root.add_handler(h)
    if default_labels is not None:
        root.default_labels = default_labels
    if default_extra is not None:
        root.default_extra = default_extra
    return root
