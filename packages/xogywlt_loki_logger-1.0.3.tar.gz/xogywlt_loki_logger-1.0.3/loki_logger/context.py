"""
Thread-local / async-safe context binding.

Allows attaching structured fields to the current execution context so that
every log record created on that thread/task automatically inherits them.

Usage::

    from loki_logger import bind_context, clear_context

    bind_context(request_id="abc123", user_id=42)
    logger.info("Processing request")   # ← record will include request_id & user_id
    clear_context()
"""

import threading
from contextlib import contextmanager
from typing import Any, Dict, Generator

_local = threading.local()


def _store() -> Dict[str, Any]:
    """Return (and lazily initialise) the thread-local context dict."""
    if not hasattr(_local, "context"):
        _local.context = {}
    
    return _local.context  # type: ignore[attr-defined]


def bind_context(**fields: Any) -> None:
    """Merge *fields* into the current thread-local context."""
    _store().update(fields)


def clear_context() -> None:
    """Remove all fields from the current thread-local context."""
    _store().clear()


def get_context() -> Dict[str, Any]:
    """Return a **copy** of the current thread-local context."""
    return dict(_store())


@contextmanager
def LogContext(**fields: Any) -> Generator[None, None, None]:
    """
    Context manager that binds *fields* for the duration of the block and
    restores the previous context on exit.

    Usage::

        with LogContext(request_id="xyz"):
            logger.info("Inside the block")
        # request_id is gone here
    """
    previous = dict(_store())
    bind_context(**fields)
    try:
        yield
    finally:
        _store().clear()
        _store().update(previous)
