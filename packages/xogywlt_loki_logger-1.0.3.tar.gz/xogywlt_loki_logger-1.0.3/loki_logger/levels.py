"""
Log level definitions.
"""

from enum import IntEnum


class LogLevel(IntEnum):
    """Enumeration of log severity levels."""

    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50

    @classmethod
    def from_string(cls, level: str) -> "LogLevel":
        """Parse a log level from string (case-insensitive)."""
        mapping = {
            "debug": cls.DEBUG,
            "info": cls.INFO,
            "warning": cls.WARNING,
            "warn": cls.WARNING,
            "error": cls.ERROR,
            "critical": cls.CRITICAL,
            "fatal": cls.CRITICAL,
        }
        normalized = level.strip().lower()
        if normalized not in mapping:
            raise ValueError(
                f"Unknown log level '{level}'. "
                f"Valid values: {list(mapping.keys())}"
            )
        return mapping[normalized]

    def label(self) -> str:
        """Return the human-readable label for this level."""
        return self.name.upper()
