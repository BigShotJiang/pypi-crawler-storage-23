"""
Formatters: convert a LogRecord to a string suitable for Loki log lines.
"""

import json
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from .record import LogRecord


class BaseFormatter(ABC):
    """Abstract base class for all formatters."""

    @abstractmethod
    def format(self, record: LogRecord) -> str:
        """Serialize *record* to a string log line."""
        ...

    def format_exception(self, record: LogRecord) -> Optional[str]:
        """Return formatted exception info (if any) as a string."""
        return record.formatted_exception


# --------------------------------------------------------------------------- #
# Concrete formatters                                                          #
# --------------------------------------------------------------------------- #


class JSONFormatter(BaseFormatter):
    """
    Formats log records as a single-line JSON object.

    Extra keyword arguments passed to the constructor are forwarded to
    ``json.dumps`` (e.g. ``sort_keys=True``).

    Example output::

        {"timestamp": "2024-01-01T00:00:00+00:00", "level": "INFO", ...}
    """
    _json_kwargs: Dict[str, Any]
    def __init__(self, **json_kwargs: Any) -> None:
        self._json_kwargs = {"ensure_ascii": False, **json_kwargs}

    def format(self, record: LogRecord) -> str:
        data = record.as_dict()
        return json.dumps(data, default=str, **self._json_kwargs)


class TextFormatter(BaseFormatter):
    """
    Formats log records as a human-readable text line.

    Default template::

        [2024-01-01T00:00:00+00:00] [INFO ] [my_logger] message text

    You can supply a custom *template* string with the following placeholders:
    ``{timestamp}``, ``{level}``, ``{logger}``, ``{message}``, ``{extra}``.
    """

    DEFAULT_TEMPLATE = "[{timestamp}] [{level:<8}] [{logger}] {message}"

    def __init__(self, template: Optional[str] = None) -> None:
        self._template = template or self.DEFAULT_TEMPLATE

    def format(self, record: LogRecord) -> str:
        extra_str = " ".join(f"{k}={v}" for k, v in record.extra.items())
        line = self._template.format(
            timestamp=record.timestamp.isoformat(),
            level=record.level.label(),
            logger=record.logger_name,
            message=record.message,
            extra=extra_str,
        )
        if extra_str and "{extra}" not in self._template:
            line = f"{line} {extra_str}"
        exc = record.formatted_exception
        if exc:
            line = f"{line}\n{exc.rstrip()}"
        return line


class LabelFormatter(BaseFormatter):
    """
    Formats log records as ``key=value`` pairs — handy when you want every
    field to be queryable via Loki's LogQL ``|= "key=value"`` filter.

    Example output::

        level=INFO logger=my_logger message="hello world" user_id=42
    """

    def format(self, record: LogRecord) -> str:
        parts: Dict[str, Any] = {
            "level": record.level.label(),
            "logger": record.logger_name,
            "message": record.message,
            **record.extra,
        }
        tokens: List[str] = []
        for k, v in parts.items():
            v_str = str(v)
            # Quote values that contain spaces.
            if " " in v_str:
                v_str = f'"{v_str}"'
            tokens.append(f"{k}={v_str}")

        line = " ".join(tokens)
        exc = record.formatted_exception
        if exc:
            line = f"{line}\n{exc.rstrip()}"
        return line
