from .cli import cli

cli()
