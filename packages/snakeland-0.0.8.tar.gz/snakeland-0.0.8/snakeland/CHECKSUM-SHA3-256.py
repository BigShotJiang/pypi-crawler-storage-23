'''
SHA3-256(/Volumes/thder_data/home_mike/svnwork/current/snakeland_guru/head/public/script/snakeland.py)= 9f866028280c555cbbf5cd0bfa0bd37a1da9ac7b5bbf8b4867bbdbe8ff30b7ae
SHA3-256(/Volumes/thder_data/home_mike/svnwork/current/snakeland_guru/head/public/pypi/snakeland/__init__.py)= 5b50b04d22ea53db316801534f95a297e25fa6ccf3aa2ee3be709773dd72412c
SHA3-256(/Volumes/thder_data/home_mike/svnwork/current/snakeland_guru/head/public/pypi/snakeland/__main__.py)= 2e715a79b0c69eff27a3088dbbfe76bb33480f57236feb29121f083ff8b2c17c
'''
