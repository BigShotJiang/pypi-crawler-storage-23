"""Shared fixtures for MCP server tests."""

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from augur_mcp import server


@pytest.fixture(autouse=True)
def _reset_server_state():
    """Reset module-level state before each test."""
    server.reset_state()
    yield
    server.reset_state()


@pytest.fixture()
def endpoints_dir():
    """Path to the bundled endpoints directory."""
    return Path(__file__).parent.parent / "src" / "augur_mcp" / "endpoints"


@pytest.fixture()
def mock_api():
    """Create a mock AugurAPI instance."""
    return MagicMock()
