"""Tests for the MCP server module."""

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, PropertyMock, patch

import pytest

from augur_mcp.server import (
    _find_creds_in_ancestors,
    _format_error,
    _load_creds_file,
    _read_creds_json,
    _resolve_creds_path,
    augur_create,
    augur_delete,
    augur_discover,
    augur_get,
    augur_list,
    augur_update,
    get_api,
    init_catalog,
    reset_state,
    set_api,
)


@pytest.fixture()
def _catalog_loaded(endpoints_dir):
    """Load the endpoints catalog for tests."""
    init_catalog(endpoints_dir)


@pytest.fixture()
def _mock_api_configured(mock_api):
    """Configure a mock API and set it."""
    set_api(mock_api)
    return mock_api


# --- init_catalog / reset_state ---


class TestCatalogInit:
    def test_init_loads_endpoints(self, endpoints_dir):
        init_catalog(endpoints_dir)
        result = json.loads(augur_discover())
        assert "services" in result
        assert len(result["services"]) > 0

    def test_reset_clears_state(self, endpoints_dir):
        init_catalog(endpoints_dir)
        reset_state()
        result = json.loads(augur_discover())
        assert result["services"] == []


# --- get_api / set_api ---


class TestReadCredsJson:
    def test_valid_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"siteId": "my-site", "jwt": "my-token"}, f)
            f.flush()
            creds = _read_creds_json(Path(f.name))
            assert creds == {"token": "my-token", "site_id": "my-site"}
            os.unlink(f.name)

    def test_missing_file(self):
        assert _read_creds_json(Path("/nonexistent/file.json")) is None

    def test_incomplete_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"siteId": "my-site"}, f)
            f.flush()
            assert _read_creds_json(Path(f.name)) is None
            os.unlink(f.name)

    def test_empty_values(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"siteId": "", "jwt": ""}, f)
            f.flush()
            assert _read_creds_json(Path(f.name)) is None
            os.unlink(f.name)


class TestFindCredsInAncestors:
    def test_finds_in_current_dir(self, tmp_path):
        protected = tmp_path / "protected"
        protected.mkdir()
        creds_file = protected / "site.json"
        creds_file.write_text(json.dumps({"siteId": "found-site", "jwt": "found-token"}))
        creds = _find_creds_in_ancestors(tmp_path)
        assert creds == {"token": "found-token", "site_id": "found-site"}

    def test_finds_in_parent_dir(self, tmp_path):
        protected = tmp_path / "protected"
        protected.mkdir()
        creds_file = protected / "site.json"
        creds_file.write_text(json.dumps({"siteId": "parent-site", "jwt": "parent-token"}))
        child = tmp_path / "subdir"
        child.mkdir()
        creds = _find_creds_in_ancestors(child)
        assert creds == {"token": "parent-token", "site_id": "parent-site"}

    def test_finds_in_grandparent(self, tmp_path):
        protected = tmp_path / "protected"
        protected.mkdir()
        creds_file = protected / "site.json"
        creds_file.write_text(json.dumps({"siteId": "gp-site", "jwt": "gp-token"}))
        deep = tmp_path / "a" / "b"
        deep.mkdir(parents=True)
        creds = _find_creds_in_ancestors(deep)
        assert creds == {"token": "gp-token", "site_id": "gp-site"}

    def test_closest_wins(self, tmp_path):
        """Closer protected/ dir takes priority over further one."""
        parent_protected = tmp_path / "protected"
        parent_protected.mkdir()
        (parent_protected / "parent.json").write_text(
            json.dumps({"siteId": "parent", "jwt": "parent-tok"})
        )
        child = tmp_path / "project"
        child.mkdir()
        child_protected = child / "protected"
        child_protected.mkdir()
        (child_protected / "child.json").write_text(
            json.dumps({"siteId": "child", "jwt": "child-tok"})
        )
        creds = _find_creds_in_ancestors(child)
        assert creds["site_id"] == "child"

    def test_skips_invalid_files(self, tmp_path):
        protected = tmp_path / "protected"
        protected.mkdir()
        (protected / "bad.json").write_text(json.dumps({"siteId": "only-site"}))
        (protected / "good.json").write_text(
            json.dumps({"siteId": "good-site", "jwt": "good-token"})
        )
        creds = _find_creds_in_ancestors(tmp_path)
        assert creds == {"token": "good-token", "site_id": "good-site"}

    def test_skips_non_json(self, tmp_path):
        protected = tmp_path / "protected"
        protected.mkdir()
        (protected / "notes.txt").write_text("not json")
        (protected / "site.json").write_text(
            json.dumps({"siteId": "s", "jwt": "t"})
        )
        creds = _find_creds_in_ancestors(tmp_path)
        assert creds == {"token": "t", "site_id": "s"}

    def test_no_protected_dir(self, tmp_path):
        child = tmp_path / "empty"
        child.mkdir()
        creds = _find_creds_in_ancestors(child)
        assert creds is None

    def test_empty_protected_dir(self, tmp_path):
        (tmp_path / "protected").mkdir()
        creds = _find_creds_in_ancestors(tmp_path)
        assert creds is None


class TestLoadCredsFile:
    def test_explicit_path(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"siteId": "my-site", "jwt": "my-token"}, f)
            f.flush()
            creds = _load_creds_file(Path(f.name))
            assert creds == {"token": "my-token", "site_id": "my-site"}
            os.unlink(f.name)

    def test_explicit_path_missing(self):
        assert _load_creds_file(Path("/nonexistent/file.json")) is None

    def test_env_var_path(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"siteId": "env-site", "jwt": "env-token"}, f)
            f.flush()
            with patch.dict(os.environ, {"AUGUR_CREDS_FILE": f.name}, clear=False):
                creds = _load_creds_file()
                assert creds == {"token": "env-token", "site_id": "env-site"}
            os.unlink(f.name)

    def test_env_var_missing_file(self):
        with patch.dict(os.environ, {"AUGUR_CREDS_FILE": "/nonexistent/creds.json"}, clear=False):
            # Patches ancestor walk to not accidentally find real creds
            assert _load_creds_file() is None

    def test_ancestor_walk(self, tmp_path):
        """Falls back to ancestor walk when no explicit path or env var."""
        protected = tmp_path / "protected"
        protected.mkdir()
        (protected / "site.json").write_text(
            json.dumps({"siteId": "walk-site", "jwt": "walk-token"})
        )
        with patch.dict(os.environ, {}, clear=True), patch(
            "augur_mcp.server.Path.cwd", return_value=tmp_path
        ):
            creds = _load_creds_file()
            assert creds == {"token": "walk-token", "site_id": "walk-site"}

    def test_falls_back_to_default(self):
        """Falls back to DEFAULT_CREDS_FILE when nothing else matches."""
        with patch.dict(os.environ, {}, clear=True), patch(
            "augur_mcp.server._find_creds_in_ancestors", return_value=None
        ), patch("augur_mcp.server._read_creds_json", return_value=None) as mock_read:
            result = _load_creds_file()
            assert result is None
            from augur_mcp.server import DEFAULT_CREDS_FILE

            mock_read.assert_called_with(DEFAULT_CREDS_FILE)

    def test_explicit_arg_overrides_env(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"siteId": "arg-site", "jwt": "arg-token"}, f)
            f.flush()
            with patch.dict(
                os.environ, {"AUGUR_CREDS_FILE": "/other/path.json"}, clear=False
            ):
                creds = _load_creds_file(Path(f.name))
                assert creds == {"token": "arg-token", "site_id": "arg-site"}
            os.unlink(f.name)

    def test_default_path_constant(self):
        from augur_mcp.server import DEFAULT_CREDS_FILE

        assert DEFAULT_CREDS_FILE.name == "augur-api.json"
        assert ".simpleapps" in str(DEFAULT_CREDS_FILE)


class TestResolveCredsPath:
    def test_explicit_path_wins(self):
        p = Path("/explicit/path.json")
        assert _resolve_creds_path(p) == p

    def test_env_var_wins_over_default(self):
        with patch.dict(os.environ, {"AUGUR_CREDS_FILE": "/env/creds.json"}, clear=False):
            assert _resolve_creds_path() == Path("/env/creds.json")

    def test_env_var_tilde_expansion(self):
        with patch.dict(os.environ, {"AUGUR_CREDS_FILE": "~/my-creds.json"}, clear=False):
            path = _resolve_creds_path()
            assert "~" not in str(path)
            assert str(path).endswith("my-creds.json")

    def test_default_when_no_env(self):
        with patch.dict(os.environ, {}, clear=True):
            from augur_mcp.server import DEFAULT_CREDS_FILE

            assert _resolve_creds_path() == DEFAULT_CREDS_FILE


class TestApiManagement:
    def test_get_api_missing_token(self):
        with patch.dict(os.environ, {"AUGUR_SITE_ID": "test"}, clear=True), patch(
            "augur_mcp.server._load_creds_file", return_value=None
        ):
            with pytest.raises(ValueError, match="No Augur token found"):
                get_api()

    def test_get_api_missing_site_id(self):
        with patch.dict(os.environ, {"AUGUR_TOKEN": "test"}, clear=True), patch(
            "augur_mcp.server._load_creds_file", return_value=None
        ):
            with pytest.raises(ValueError, match="No Augur site_id found"):
                get_api()

    def test_get_api_error_mentions_all_options(self):
        """Error message mentions all 4 auth resolution options."""
        with patch.dict(os.environ, {}, clear=True), patch(
            "augur_mcp.server._load_creds_file", return_value=None
        ):
            with pytest.raises(ValueError, match="AUGUR_CREDS_FILE"):
                get_api()
            reset_state()
            with pytest.raises(ValueError, match="protected/"):
                get_api()

    def test_get_api_from_custom_creds_file(self):
        """AUGUR_CREDS_FILE loads creds when no env vars set."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"siteId": "custom-site", "jwt": "custom-token"}, f)
            f.flush()
            with patch.dict(os.environ, {"AUGUR_CREDS_FILE": f.name}, clear=True):
                api = get_api()
                assert api.config.token == "custom-token"
                assert api.config.site_id == "custom-site"
            os.unlink(f.name)

    def test_get_api_creates_client_from_env(self):
        with patch.dict(
            os.environ,
            {"AUGUR_TOKEN": "test-token", "AUGUR_SITE_ID": "test-site"},
            clear=True,
        ):
            api = get_api()
            assert api is not None
            assert api.config.token == "test-token"
            assert api.config.site_id == "test-site"

    def test_get_api_creates_client_from_file(self):
        with patch.dict(os.environ, {}, clear=True), patch(
            "augur_mcp.server._load_creds_file",
            return_value={"token": "file-token", "site_id": "file-site"},
        ):
            api = get_api()
            assert api.config.token == "file-token"
            assert api.config.site_id == "file-site"

    def test_get_api_env_overrides_file(self):
        """Env vars take precedence over file."""
        with patch.dict(
            os.environ,
            {"AUGUR_TOKEN": "env-token", "AUGUR_SITE_ID": "env-site"},
            clear=True,
        ):
            api = get_api()
            assert api.config.token == "env-token"
            assert api.config.site_id == "env-site"

    def test_get_api_partial_env_falls_back_to_file(self):
        """If only token is in env, site_id comes from file."""
        with patch.dict(os.environ, {"AUGUR_TOKEN": "env-token"}, clear=True), patch(
            "augur_mcp.server._load_creds_file",
            return_value={"token": "file-token", "site_id": "file-site"},
        ):
            api = get_api()
            assert api.config.token == "env-token"
            assert api.config.site_id == "file-site"

    def test_get_api_caches_client(self):
        with patch.dict(
            os.environ,
            {"AUGUR_TOKEN": "test-token", "AUGUR_SITE_ID": "test-site"},
            clear=True,
        ):
            api1 = get_api()
            api2 = get_api()
            assert api1 is api2

    def test_set_api_overrides(self, mock_api):
        set_api(mock_api)
        assert get_api() is mock_api


# --- _format_error ---


class TestFormatError:
    def test_authentication_error(self):
        from augur_api.core.errors import AuthenticationError

        err = AuthenticationError("bad token", "agr-site", "/settings")
        result = json.loads(_format_error(err))
        assert result["error"] == "Authentication failed"

    def test_not_found_error(self):
        from augur_api.core.errors import NotFoundError

        err = NotFoundError("not found", "agr-site", "/settings/99")
        result = json.loads(_format_error(err))
        assert result["error"] == "Not found"

    def test_rate_limit_error(self):
        from augur_api.core.errors import RateLimitError

        err = RateLimitError("too many requests", "agr-site", "/settings")
        result = json.loads(_format_error(err))
        assert result["error"] == "Rate limited"

    def test_validation_error(self):
        from augur_api.core.errors import ValidationError

        err = ValidationError("bad input", "agr-site", "/settings", [{"msg": "invalid"}])
        result = json.loads(_format_error(err))
        assert result["error"] == "Validation error"

    def test_generic_augur_error(self):
        from augur_api.core.errors import AugurError

        err = AugurError("something broke", "API_ERROR", 500, "agr-site", "/settings")
        result = json.loads(_format_error(err))
        assert result["error"] == "API error"

    def test_value_error(self):
        err = ValueError("bad value")
        result = json.loads(_format_error(err))
        assert result["error"] == "Invalid request"

    def test_unexpected_error(self):
        err = RuntimeError("unexpected")
        result = json.loads(_format_error(err))
        assert result["error"] == "Unexpected error"


# --- augur_discover ---


class TestAugurDiscover:
    @pytest.mark.usefixtures("_catalog_loaded")
    def test_list_all_services(self):
        result = json.loads(augur_discover())
        assert "services" in result
        services = result["services"]
        names = [s["name"] for s in services]
        assert "agr-site" in names
        assert "agr-info" in names

    @pytest.mark.usefixtures("_catalog_loaded")
    def test_service_has_metadata(self):
        result = json.loads(augur_discover())
        svc = result["services"][0]
        assert "name" in svc
        assert "endpoints" in svc
        assert "resources" in svc

    @pytest.mark.usefixtures("_catalog_loaded")
    def test_specific_service(self):
        result = json.loads(augur_discover(service="agr-site"))
        assert result["service"] == "agr-site"
        assert "endpoints" in result
        assert len(result["endpoints"]) > 0

    @pytest.mark.usefixtures("_catalog_loaded")
    def test_specific_service_endpoint_structure(self):
        result = json.loads(augur_discover(service="agr-site"))
        ep = result["endpoints"][0]
        assert "resource" in ep
        assert "methods" in ep

    @pytest.mark.usefixtures("_catalog_loaded")
    def test_unknown_service(self):
        result = json.loads(augur_discover(service="nonexistent"))
        assert "error" in result
        assert "available" in result

    def test_empty_catalog(self):
        result = json.loads(augur_discover())
        assert result["services"] == []


# --- augur_list ---


class TestAugurList:
    @pytest.mark.usefixtures("_catalog_loaded")
    def test_list_success(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": [{"id": 1}], "count": 1, "total": 10}
        mock_resource = MagicMock()
        mock_resource.list.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(augur_list(service="agr-site", resource="settings"))
        assert result["count"] == 1
        assert result["total"] == 10

    @pytest.mark.usefixtures("_catalog_loaded")
    def test_list_with_params(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": [], "count": 0, "total": 0}
        mock_resource = MagicMock()
        mock_resource.list.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(
            augur_list(service="agr-site", resource="settings", params='{"limit": 5}')
        )
        mock_resource.list.assert_called_once_with({"limit": 5})

    def test_list_missing_token(self):
        with patch.dict(os.environ, {}, clear=True), patch(
            "augur_mcp.server._load_creds_file", return_value=None
        ):
            result = json.loads(augur_list(service="agr-site", resource="settings"))
            assert "error" in result

    def test_list_unknown_service(self, mock_api):
        set_api(mock_api)
        result = json.loads(augur_list(service="nonexistent", resource="items"))
        assert "error" in result
        assert "Unknown service" in result["detail"]


# --- augur_get ---


class TestAugurGet:
    @pytest.mark.usefixtures("_catalog_loaded")
    def test_get_success(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {"id": 5, "name": "test"}}
        mock_resource = MagicMock()
        mock_resource.get.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(augur_get(service="agr-site", resource="settings", record_id="5"))
        assert result["data"]["id"] == 5
        mock_resource.get.assert_called_once_with(5)

    def test_get_error(self, mock_api):
        set_api(mock_api)
        result = json.loads(augur_get(service="nonexistent", resource="x", record_id="1"))
        assert "error" in result


# --- augur_create ---


class TestAugurCreate:
    @pytest.mark.usefixtures("_catalog_loaded")
    def test_create_success(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {"id": 10, "name": "new"}}
        mock_resource = MagicMock()
        mock_resource.create.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(
            augur_create(service="agr-site", resource="settings", data='{"name": "new"}')
        )
        assert result["data"]["name"] == "new"
        mock_resource.create.assert_called_once_with({"name": "new"})

    def test_create_error(self, mock_api):
        set_api(mock_api)
        result = json.loads(
            augur_create(service="nonexistent", resource="x", data='{"a": 1}')
        )
        assert "error" in result


# --- augur_update ---


class TestAugurUpdate:
    @pytest.mark.usefixtures("_catalog_loaded")
    def test_update_success(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {"id": 5, "name": "updated"}}
        mock_resource = MagicMock()
        mock_resource.update.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(
            augur_update(
                service="agr-site",
                resource="settings",
                record_id="5",
                data='{"name": "updated"}',
            )
        )
        assert result["data"]["name"] == "updated"
        mock_resource.update.assert_called_once_with(5, {"name": "updated"})

    def test_update_error(self, mock_api):
        set_api(mock_api)
        result = json.loads(
            augur_update(service="nonexistent", resource="x", record_id="1", data='{"a": 1}')
        )
        assert "error" in result


# --- augur_delete ---


class TestAugurDelete:
    @pytest.mark.usefixtures("_catalog_loaded")
    def test_delete_success(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": True}
        mock_resource = MagicMock()
        mock_resource.delete.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(
            augur_delete(service="agr-site", resource="settings", record_id="5")
        )
        assert result["data"] is True
        mock_resource.delete.assert_called_once_with(5)

    def test_delete_error(self, mock_api):
        set_api(mock_api)
        result = json.loads(
            augur_delete(service="nonexistent", resource="x", record_id="1")
        )
        assert "error" in result


# --- augur_create / augur_update empty data ---


class TestEmptyData:
    @pytest.mark.usefixtures("_catalog_loaded")
    def test_create_empty_data(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {}}
        mock_resource = MagicMock()
        mock_resource.create.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(augur_create(service="agr-site", resource="settings", data=""))
        assert "data" in result
        mock_resource.create.assert_called_once_with({})

    @pytest.mark.usefixtures("_catalog_loaded")
    def test_update_empty_data(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {}}
        mock_resource = MagicMock()
        mock_resource.update.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(
            augur_update(service="agr-site", resource="settings", record_id="1", data="")
        )
        assert "data" in result

    @pytest.mark.usefixtures("_catalog_loaded")
    def test_list_empty_params(self, mock_api):
        set_api(mock_api)
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": [], "count": 0}
        mock_resource = MagicMock()
        mock_resource.list.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = json.loads(augur_list(service="agr-site", resource="settings", params=""))
        assert result["count"] == 0


# --- main entry point ---


class TestMain:
    def test_main_calls_init_and_run(self):
        from augur_mcp import server

        with patch.object(server, "init_catalog") as mock_init, patch.object(
            server.mcp, "run"
        ) as mock_run:
            server.main()
            mock_init.assert_called_once()
            mock_run.assert_called_once()
