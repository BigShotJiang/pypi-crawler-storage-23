# Augur MCP Server

FastMCP server exposing Augur API microservices as 6 generic MCP tools.

## Install

```bash
uvx simpleapps-com-augur-mcp
```

## Authentication

Credentials are resolved in this order (first match wins):

1. **Environment variables** — `AUGUR_TOKEN` + `AUGUR_SITE_ID`
2. **Explicit file** — `AUGUR_CREDS_FILE` env var pointing to a JSON file (supports `~`)
3. **Ancestor walk** — walks up from cwd looking for `protected/*.json`
4. **Default file** — `~/.simpleapps/augur-api.json`

Env vars and credentials files can be mixed — for example, `AUGUR_TOKEN` from
the environment and `site_id` from a credentials file.

### Credentials file format

All credentials files use the same format:

```json
{
  "siteId": "your-site-id",
  "jwt": "your-jwt-token"
}
```

### Ancestor walk

The server walks up the directory tree from the current working directory,
checking each level for a `protected/` folder containing `.json` files with
valid `siteId` and `jwt` keys. If multiple `.json` files exist, the first
valid one alphabetically is used. This lets you organize credentials per client:

```
projects/clients/
├── acme-corp/
│   └── protected/
│       └── acme-corp.json
└── other-site/
    └── protected/
        └── other-site.json
```

When the MCP runs from `projects/clients/acme-corp/` (or any subfolder),
it automatically finds and uses `protected/acme-corp.json`.

## MCP Configuration

Minimal — no env vars needed when using the ancestor walk or default file:

```json
{
  "mcpServers": {
    "augur-api": {
      "command": "uvx",
      "args": ["simpleapps-com-augur-mcp"]
    }
  }
}
```

You can also place a credentials file at `~/.simpleapps/augur-api.json` as a
global default.

### Override: specific credentials file

```json
{
  "mcpServers": {
    "augur-api": {
      "command": "uvx",
      "args": ["simpleapps-com-augur-mcp"],
      "env": {
        "AUGUR_CREDS_FILE": "~/projects/clients/acme-corp/protected/acme-corp.json"
      }
    }
  }
}
```

### Override: environment variables

```json
{
  "mcpServers": {
    "augur-api": {
      "command": "uvx",
      "args": ["simpleapps-com-augur-mcp"],
      "env": {
        "AUGUR_TOKEN": "your-jwt-token",
        "AUGUR_SITE_ID": "your-site-id"
      }
    }
  }
}
```

## Tools

| Tool | Purpose |
|------|---------|
| `augur_discover` | List services or endpoints for a service |
| `augur_list` | List records (GET collection) |
| `augur_get` | Get single record by ID |
| `augur_create` | Create record (POST) |
| `augur_update` | Update record (PUT) |
| `augur_delete` | Delete record (DELETE) |
