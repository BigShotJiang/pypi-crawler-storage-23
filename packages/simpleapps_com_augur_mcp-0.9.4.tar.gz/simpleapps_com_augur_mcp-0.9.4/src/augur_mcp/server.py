"""FastMCP server exposing Augur API as 6 generic tools.

Tools:
    augur_discover - List services or endpoints for a service
    augur_list     - List records (GET collection)
    augur_get      - Get single record by ID
    augur_create   - Create record (POST)
    augur_update   - Update record (PUT)
    augur_delete   - Delete record (DELETE)
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from augur_api import AugurAPI
from augur_api.core.errors import (
    AugurError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from mcp.server.fastmcp import FastMCP

from augur_mcp.router import (
    SERVICE_MAP,
    get_resource_map,
    load_catalog,
    resolve_and_call,
)

mcp = FastMCP("augur")

# Module-level state
_catalog: dict[str, list[dict[str, Any]]] = {}
_api: AugurAPI | None = None

DEFAULT_CREDS_FILE = Path(os.path.expanduser("~/.simpleapps/augur-api.json"))


def init_catalog(endpoints_dir: Path | None = None) -> None:
    """Initialize the endpoints catalog."""
    global _catalog  # noqa: PLW0603
    _catalog = load_catalog(endpoints_dir)


def _read_creds_json(path: Path) -> dict[str, str] | None:
    """Read and validate a single credentials JSON file.

    Expects {"siteId": "...", "jwt": "..."} format.

    Returns:
        Dict with "token" and "site_id" keys, or None if invalid.
    """
    if not path.is_file():
        return None
    with open(path) as f:
        data = json.load(f)
    token = data.get("jwt", "")
    site_id = data.get("siteId", "")
    if token and site_id:
        return {"token": token, "site_id": site_id}
    return None


def _find_creds_in_ancestors(start: Path | None = None) -> dict[str, str] | None:
    """Walk up from start directory looking for protected/*.json with valid creds.

    Checks each directory for a ``protected/`` subfolder containing JSON files
    with ``siteId`` and ``jwt`` keys. Stops at filesystem root.

    Args:
        start: Directory to start searching from. Defaults to cwd.

    Returns:
        Dict with "token" and "site_id" keys, or None if not found.
    """
    current = (start or Path.cwd()).resolve()
    while True:
        protected = current / "protected"
        if protected.is_dir():
            for f in sorted(protected.iterdir()):
                if f.suffix == ".json":
                    creds = _read_creds_json(f)
                    if creds:
                        return creds
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _resolve_creds_path(creds_path: Path | None = None) -> Path:
    """Resolve credentials file path (for error messages).

    Priority: explicit arg > AUGUR_CREDS_FILE env var > default.
    """
    if creds_path:
        return creds_path
    env_path = os.environ.get("AUGUR_CREDS_FILE", "")
    if env_path:
        return Path(os.path.expanduser(env_path))
    return DEFAULT_CREDS_FILE


def _load_creds_file(creds_path: Path | None = None) -> dict[str, str] | None:
    """Load credentials from a JSON file.

    Resolution order:
    1. Explicit creds_path argument
    2. AUGUR_CREDS_FILE env var
    3. Walk up from cwd looking for protected/*.json
    4. Default ~/.simpleapps/augur-api.json

    Returns:
        Dict with "token" and "site_id" keys, or None if not found.
    """
    # Explicit path or env var
    if creds_path:
        return _read_creds_json(creds_path)
    env_path = os.environ.get("AUGUR_CREDS_FILE", "")
    if env_path:
        return _read_creds_json(Path(os.path.expanduser(env_path)))

    # Walk up directory tree
    ancestor_creds = _find_creds_in_ancestors()
    if ancestor_creds:
        return ancestor_creds

    # Default location
    return _read_creds_json(DEFAULT_CREDS_FILE)


def get_api() -> AugurAPI:
    """Get or create the AugurAPI client.

    Auth resolution order:
    1. Environment variables (AUGUR_TOKEN + AUGUR_SITE_ID)
    2. AUGUR_CREDS_FILE env var pointing to a JSON file
    3. Ancestor walk — protected/*.json up from cwd
    4. Default file (~/.simpleapps/augur-api.json)

    Env vars and creds file can be mixed (e.g. token from env, site_id from file).
    """
    global _api  # noqa: PLW0603
    if _api is None:
        token = os.environ.get("AUGUR_TOKEN", "")
        site_id = os.environ.get("AUGUR_SITE_ID", "")

        # Fall back to credentials file
        if not token or not site_id:
            creds = _load_creds_file()
            if creds:
                token = token or creds["token"]
                site_id = site_id or creds["site_id"]

        if not token:
            msg = (
                "No Augur token found. Provide credentials via: "
                "(1) AUGUR_TOKEN + AUGUR_SITE_ID env vars, "
                "(2) AUGUR_CREDS_FILE env var, "
                "(3) protected/*.json in a parent directory, or "
                f"(4) {DEFAULT_CREDS_FILE}. "
                'File format: {"siteId": "...", "jwt": "..."}.'
            )
            raise ValueError(msg)
        if not site_id:
            msg = (
                "No Augur site_id found. Provide credentials via: "
                "(1) AUGUR_TOKEN + AUGUR_SITE_ID env vars, "
                "(2) AUGUR_CREDS_FILE env var, "
                "(3) protected/*.json in a parent directory, or "
                f"(4) {DEFAULT_CREDS_FILE}. "
                'File format: {"siteId": "...", "jwt": "..."}.'
            )
            raise ValueError(msg)
        _api = AugurAPI(token=token, site_id=site_id)
    return _api


def set_api(api: AugurAPI) -> None:
    """Set the AugurAPI client (for testing)."""
    global _api  # noqa: PLW0603
    _api = api


def reset_state() -> None:
    """Reset module state (for testing)."""
    global _api, _catalog  # noqa: PLW0603
    _api = None
    _catalog = {}


def _format_error(error: Exception) -> str:
    """Format an error as a JSON string for MCP response."""
    if isinstance(error, AuthenticationError):
        return json.dumps({"error": "Authentication failed", "detail": str(error)})
    if isinstance(error, NotFoundError):
        return json.dumps({"error": "Not found", "detail": str(error)})
    if isinstance(error, RateLimitError):
        return json.dumps({"error": "Rate limited", "detail": str(error)})
    if isinstance(error, ValidationError):
        return json.dumps({"error": "Validation error", "detail": str(error)})
    if isinstance(error, AugurError):
        return json.dumps({"error": "API error", "detail": str(error)})
    if isinstance(error, ValueError):
        return json.dumps({"error": "Invalid request", "detail": str(error)})
    return json.dumps({"error": "Unexpected error", "detail": str(error)})


@mcp.tool()
def augur_discover(service: str = "") -> str:
    """List available Augur API services, or list resources/endpoints for a specific service.

    Args:
        service: Service name (e.g., "items", "agr-site"). Omit to list all services.

    Returns:
        JSON with service catalog or resource map.
    """
    if not service:
        services = []
        for svc_name in sorted(_catalog.keys()):
            resource_map = get_resource_map(_catalog[svc_name])
            services.append({
                "name": svc_name,
                "endpoints": len(_catalog[svc_name]),
                "resources": len(resource_map),
            })
        return json.dumps({"services": services}, indent=2)

    if service not in _catalog:
        available = ", ".join(sorted(_catalog.keys()))
        return json.dumps({"error": f"Unknown service: {service}", "available": available})

    resource_map = get_resource_map(_catalog[service])
    endpoints = []
    for resource_path, methods in sorted(resource_map.items()):
        endpoints.append({"resource": resource_path, "methods": sorted(methods)})

    return json.dumps({"service": service, "endpoints": endpoints}, indent=2)


@mcp.tool()
def augur_list(service: str, resource: str, params: str = "") -> str:
    """List records from a service resource.

    Args:
        service: Service name (e.g., "agr-site", "items").
        resource: Resource path (e.g., "settings", "training/1/conversations").
        params: JSON string of query parameters (e.g., '{"limit": 10, "offset": 0}').

    Returns:
        JSON response with count, data, total.
    """
    try:
        api = get_api()
        parsed_params = json.loads(params) if params else None
        result = resolve_and_call(api, service, resource, "list", params=parsed_params)
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return _format_error(e)


@mcp.tool()
def augur_get(service: str, resource: str, record_id: str) -> str:
    """Get a single record by ID.

    Args:
        service: Service name (e.g., "agr-site", "items").
        resource: Resource path (e.g., "settings", "training/1/conversations").
        record_id: The record ID to retrieve.

    Returns:
        JSON response with the record data.
    """
    try:
        api = get_api()
        result = resolve_and_call(api, service, resource, "get", record_id=record_id)
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return _format_error(e)


@mcp.tool()
def augur_create(service: str, resource: str, data: str) -> str:
    """Create a new record.

    Args:
        service: Service name (e.g., "agr-site", "items").
        resource: Resource path (e.g., "settings", "training/1/conversations").
        data: JSON string of the record data to create.

    Returns:
        JSON response with the created record.
    """
    try:
        api = get_api()
        parsed_data = json.loads(data) if data else {}
        result = resolve_and_call(api, service, resource, "create", data=parsed_data)
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return _format_error(e)


@mcp.tool()
def augur_update(service: str, resource: str, record_id: str, data: str) -> str:
    """Update an existing record.

    Args:
        service: Service name (e.g., "agr-site", "items").
        resource: Resource path (e.g., "settings", "training/1/conversations").
        record_id: The record ID to update.
        data: JSON string of the fields to update.

    Returns:
        JSON response with the updated record.
    """
    try:
        api = get_api()
        parsed_data = json.loads(data) if data else {}
        result = resolve_and_call(
            api, service, resource, "update", record_id=record_id, data=parsed_data
        )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return _format_error(e)


@mcp.tool()
def augur_delete(service: str, resource: str, record_id: str) -> str:
    """Delete a record.

    Args:
        service: Service name (e.g., "agr-site", "items").
        resource: Resource path (e.g., "settings", "training/1/conversations").
        record_id: The record ID to delete.

    Returns:
        JSON response confirming deletion.
    """
    try:
        api = get_api()
        result = resolve_and_call(api, service, resource, "delete", record_id=record_id)
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return _format_error(e)


def main() -> None:
    """Entry point for the MCP server."""
    init_catalog()
    mcp.run()


if __name__ == "__main__":
    main()
