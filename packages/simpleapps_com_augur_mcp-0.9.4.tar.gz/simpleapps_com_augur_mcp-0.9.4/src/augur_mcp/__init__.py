"""Augur MCP Server.

FastMCP server exposing Augur API microservices as MCP tools.

Example:
    >>> # Run as MCP server
    >>> # uvx simpleapps-com-augur-mcp
"""

__version__ = "0.9.4"
__all__ = ["__version__"]
