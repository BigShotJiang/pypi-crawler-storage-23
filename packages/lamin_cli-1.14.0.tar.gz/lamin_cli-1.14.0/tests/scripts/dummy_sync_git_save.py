"""Dummy script for testing lamin save with LAMINDB_SYNC_GIT_REPO."""

print("dummy")
