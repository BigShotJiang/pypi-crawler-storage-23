"""
REST API package.

This package contains FastAPI routes and dependencies.
"""

# API implementations will be here
