"""Login command for the Cyberwave CLI."""

import sys
import time

import click
from rich.console import Console
from rich.prompt import Prompt

from ..auth import AuthClient, AuthenticationError, Workspace
from ..config import get_api_url
from ..credentials import (
    Credentials,
    collect_runtime_env_overrides,
    load_credentials,
    save_credentials,
)

console = Console()


def select_workspace(workspaces: list[Workspace]) -> Workspace:
    """Prompt user to select a workspace if multiple are available."""
    if len(workspaces) == 1:
        return workspaces[0]

    # Non-interactive: auto-select the first workspace when stdin is not a TTY.
    if not sys.stdin.isatty():
        console.print(f"[yellow]Auto-selecting workspace:[/yellow] {workspaces[0].name}")
        return workspaces[0]

    console.print("\n[bold]Select a workspace:[/bold]")
    for i, ws in enumerate(workspaces, 1):
        console.print(f"  {i}. {ws.name}")

    while True:
        choice = Prompt.ask(
            "\n[bold]Workspace number[/bold]",
            default="1",
        )
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(workspaces):
                return workspaces[idx]
            console.print(f"[red]Please enter a number between 1 and {len(workspaces)}[/red]")
        except ValueError:
            console.print("[red]Please enter a valid number[/red]")


def _is_retryable_workspace_token_error(error: AuthenticationError) -> bool:
    """Return True when API token creation should be retried."""
    return "HTTP error: 500" in str(error)


def _validate_stored_token(token: str) -> bool:
    """Validate a stored API token by making a lightweight SDK call."""
    try:
        from cyberwave import Cyberwave

        client = Cyberwave(base_url=get_api_url(), token=token)
        client.workspaces.list()
        return True
    except Exception:
        return False


def _stored_api_url(credentials: Credentials) -> str | None:
    """Read API URL override persisted in credentials (if any)."""
    return credentials.cyberwave_base_url


@click.command()
@click.option(
    "--email",
    "-e",
    help="Email address for login",
)
@click.option(
    "--password",
    "-p",
    help="Password (will prompt if not provided)",
    hide_input=True,
)
def login(email: str | None, password: str | None) -> None:
    """Authenticate with Cyberwave.

    Logs you in to Cyberwave and stores your credentials locally for future CLI operations.

    If email and password are not provided as options, you will be prompted to enter them.
    """
    # Check if already logged in by validating the stored API token via the SDK
    existing_creds = load_credentials()
    if existing_creds and existing_creds.token:
        # Validate against stored API URL first when present (edge/dev setups),
        # then fall back to the current process URL resolution.
        validate_token = existing_creds.token
        if _stored_api_url(existing_creds):
            try:
                from cyberwave import Cyberwave

                client = Cyberwave(base_url=_stored_api_url(existing_creds), token=validate_token)
                client.workspaces.list()
                is_valid = True
            except Exception:
                is_valid = _validate_stored_token(validate_token)
        else:
            is_valid = _validate_stored_token(validate_token)

        if is_valid:
            workspace_info = ""
            if existing_creds.workspace_name:
                workspace_info = f" (workspace: [bold]{existing_creds.workspace_name}[/bold])"
            display_email = existing_creds.email or "unknown"
            msg = f"\n[green]✓[/green] Already logged in as [bold]{display_email}[/bold]"
            console.print(f"{msg}{workspace_info}")
            # Non-interactive: proceed with re-login (no way to ask).
            if sys.stdin.isatty():
                if not click.confirm("Do you want to log in with a different account?"):
                    return

    # Prompt for credentials if not provided
    if not email:
        email = Prompt.ask("\n[bold]Email[/bold]")

    if not password:
        password = Prompt.ask("[bold]Password[/bold]", password=True)

    console.print("\n[dim]Authenticating...[/dim]")

    try:
        runtime_overrides = collect_runtime_env_overrides()
        with AuthClient() as client:
            # First, get a session token via OAuth
            session_token = client.login(email, password)

            # Get user info to confirm login
            user = client.get_current_user(session_token)

            # Get user's workspaces to create a permanent API token
            workspaces = client.get_workspaces(session_token)

            if not workspaces:
                console.print(
                    f"\n[yellow]⚠[/yellow] Logged in as [bold]{user.email}[/bold] "
                    "but no workspaces found."
                )
                console.print(
                    "[dim]Please create a workspace at https://cyberwave.com to use the CLI.[/dim]"
                )
                raise click.Abort()

            # Let user select a workspace if multiple are available.
            # If API token creation hits transient backend 500s, retry the
            # same workspace with a short backoff.
            workspace = select_workspace(workspaces)
            max_attempts = 3
            api_token = None

            for attempt in range(1, max_attempts + 1):
                if attempt == 1:
                    console.print(
                        f"\n[dim]Creating API token for workspace '{workspace.name}'...[/dim]"
                    )
                else:
                    console.print(
                        f"\n[dim]Retrying API token creation for workspace "
                        f"'{workspace.name}' (attempt {attempt}/{max_attempts})...[/dim]"
                    )

                try:
                    api_token = client.create_api_token(session_token, workspace.uuid)
                    break
                except AuthenticationError as exc:
                    if attempt == max_attempts or not _is_retryable_workspace_token_error(exc):
                        raise
                    wait_seconds = 2 * attempt
                    console.print(
                        f"[yellow]⚠[/yellow] Temporary token creation failure: {exc}. "
                        f"Retrying in {wait_seconds}s..."
                    )
                    time.sleep(wait_seconds)

            if api_token is None:
                raise AuthenticationError("Failed to create API token")

            # Save the permanent API token (not the session token which expires)
            save_credentials(
                Credentials(
                    token=api_token.token,
                    email=user.email,
                    workspace_uuid=workspace.uuid,
                    workspace_name=workspace.name,
                    cyberwave_environment=runtime_overrides.get("CYBERWAVE_ENVIRONMENT"),
                    cyberwave_edge_log_level=runtime_overrides.get("CYBERWAVE_EDGE_LOG_LEVEL"),
                    cyberwave_base_url=runtime_overrides.get("CYBERWAVE_BASE_URL"),
                    cyberwave_mqtt_host=runtime_overrides.get("CYBERWAVE_MQTT_HOST"),
                )
            )

            console.print(f"\n[green]✓[/green] Successfully logged in as [bold]{user.email}[/bold]")
            console.print(f"[dim]Workspace: {workspace.name}[/dim]")
            from ..config import CREDENTIALS_FILE

            console.print(f"[dim]API token saved to {CREDENTIALS_FILE}[/dim]")

    except AuthenticationError as e:
        console.print(f"\n[red]✗[/red] Login failed: {e}")
        raise click.Abort()
