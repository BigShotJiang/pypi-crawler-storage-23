# Wagtail Marketplace app for sharing blueprint and MCP config templates.

