# src/swarm/config/__init__.py

"""
Configuration module for Open Swarm MCP.
Handles loading, validating, and setting up configurations.
"""
