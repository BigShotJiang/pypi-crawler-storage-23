def prompt_user(prompt: str) -> str:
    """Prompt the user for input via CLI and return the response."""
    return input(prompt + " ")
