// src/swarm/static/rest_mode/js/modules/state.js

/**
 * Shared state variables.
 */
export let contextVariables = { active_agent_name: null };
export let chatHistory = [];
