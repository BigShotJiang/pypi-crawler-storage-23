# src/swarm/agent/__init__.py

"""
Agent module for Open Swarm MCP.
Initializes the agent package.
"""

