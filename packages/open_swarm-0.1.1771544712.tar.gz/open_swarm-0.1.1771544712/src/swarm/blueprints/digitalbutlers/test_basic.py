def test_import_blueprint():
    from .blueprint_digitalbutlers import DigitalButlersBlueprint
    assert DigitalButlersBlueprint is not None
