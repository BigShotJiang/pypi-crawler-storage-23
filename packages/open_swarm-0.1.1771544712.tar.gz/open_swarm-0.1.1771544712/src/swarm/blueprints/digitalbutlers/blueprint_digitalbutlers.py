"""
DigitalButlers Blueprint (stub)
"""

class DigitalButlersBlueprint:
    """Stub for DigitalButlers Blueprint."""
    pass
