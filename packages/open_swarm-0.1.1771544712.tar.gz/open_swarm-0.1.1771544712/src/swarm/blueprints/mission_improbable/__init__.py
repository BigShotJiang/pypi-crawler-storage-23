# Make this a regular package and expose submodule for attribute lookup in tests
from . import blueprint_mission_improbable  # noqa: F401
from .blueprint_mission_improbable import MissionImprobableBlueprint  # noqa: F401



