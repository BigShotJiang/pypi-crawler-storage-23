# Rue Code Blueprint

**Rue Code** is a blueprint that specializes in calculating token costs for LLM usage. Use it to estimate and manage your API expenses for OpenAI and other LLM providers.

## Special Feature
- **Token Cost Calculation**: Instantly estimate how much your LLM calls will cost.

---
