from django.apps import AppConfig


class ZeusConfig(AppConfig):
    name = "swarm.blueprints.zeus"
