def test_import_blueprint():
    from .blueprint_chucks_angels import ChucksAngelsBlueprint
    assert ChucksAngelsBlueprint is not None
