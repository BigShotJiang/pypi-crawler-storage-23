from django.apps import AppConfig


class DjangoChatConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "blueprints.django_chat"
    label = "blueprints_django_chat"
