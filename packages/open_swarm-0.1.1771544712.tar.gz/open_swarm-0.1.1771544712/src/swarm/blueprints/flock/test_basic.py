def test_import_blueprint():
    from .blueprint_flock import FlockBlueprint
    assert FlockBlueprint is not None
