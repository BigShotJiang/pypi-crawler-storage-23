"""
Flock Blueprint (stub)
"""

class FlockBlueprint:
    """Stub for Flock Blueprint."""
    pass
