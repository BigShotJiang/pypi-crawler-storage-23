# Geese Blueprint

This is the README stub for the Geese blueprint.

- **Purpose:** Collaborative agent team for Open Swarm.
- **Required Env Vars:** _Document if any._
- **Tests:** See `tests/blueprints/test_geese.py` (if exists).
- **Usage:** `swarm-cli run geese --instruction "ping"`

_Expand this README with configuration, usage, and extension details as needed._
