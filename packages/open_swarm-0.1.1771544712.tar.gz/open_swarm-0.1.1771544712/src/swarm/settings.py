"""
Django settings for swarm project.
"""

import json
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent # Points to src/

from swarm.utils.env_utils import *

# --- Load .env file ---
dotenv_path = BASE_DIR.parent / '.env'
load_dotenv(dotenv_path=dotenv_path)
# ---

SECRET_KEY = get_django_secret_key()
DEBUG = is_django_debug()
ALLOWED_HOSTS = get_django_allowed_hosts()

# --- Custom Swarm Settings ---
# Load the token from environment
_raw_api_token = get_api_auth_token()

# *** Only enable API auth if the token is actually set ***
ENABLE_API_AUTH = bool(_raw_api_token)
SWARM_API_KEY = _raw_api_token # Assign the loaded token (or None)

if ENABLE_API_AUTH:
    # Add assertion to satisfy type checkers within this block
    assert SWARM_API_KEY is not None, "SWARM_API_KEY cannot be None when ENABLE_API_AUTH is True"

SWARM_CONFIG_PATH = get_swarm_config_path()
BLUEPRINT_DIRECTORY = get_blueprint_directory()
# --- End Custom Swarm Settings ---

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'rest_framework.authtoken',
    'drf_spectacular',
    'swarm',
    'swarm.mcp',
]

# Optional Wagtail integration (marketplace). Disabled by default.
ENABLE_WAGTAIL = is_enable_wagtail()
if ENABLE_WAGTAIL:
    INSTALLED_APPS += [
        'wagtail',
        'wagtail.admin',
        'wagtail.users',
        'wagtail.images',
        'wagtail.documents',
        'wagtail.snippets',
        'wagtail.sites',
        'wagtail.contrib.modeladmin',
        'modelcluster',
        'taggit',
        'swarm.marketplace',
    ]
    WAGTAIL_SITE_NAME = 'Open Swarm'
    SITE_ID = get_django_site_id()

# Optional SAML IdP integration (djangosaml2idp). Disabled by default.
ENABLE_SAML_IDP = is_enable_saml_idp()
if ENABLE_SAML_IDP:
    try:
        INSTALLED_APPS += ['djangosaml2idp']
    except Exception:
        # Allow tests and environments without the package to proceed when disabled
        pass

# Minimal IdP config placeholders (template-only; no secrets). Real values should be
# provided via environment or admin configuration when deploying IdP.
# We expose a simple structure for tests/introspection; djangosaml2idp expects
# SAML_IDP_SPCONFIG mapping keyed by SP entity IDs.
SAML_IDP_SPCONFIG = {
    # Example template entry (disabled until explicitly configured):
    # os.getenv('SAML_SP_ENTITY_ID', 'sp-example') : {
    #     'acs_url': os.getenv('SAML_SP_ACS_URL', 'https://sp.example.com/saml/acs'),
    #     'audiences': [os.getenv('SAML_SP_AUDIENCE', 'https://sp.example.com')],
    #     'nameid_format': 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
    # }
}

# Optionally merge SP config entries from environment JSON (template-only)
_sp_json = get_saml_idp_spconfig_json()
if _sp_json:
    try:
        parsed = json.loads(_sp_json)
        if isinstance(parsed, dict):
            # Basic validation for known keys
            for sp_entity, cfg in list(parsed.items()):
                if not isinstance(cfg, dict):
                    # Remove invalid entries
                    parsed.pop(sp_entity, None)
                    continue
                if 'acs_url' not in cfg:
                    parsed.pop(sp_entity, None)
                    continue
                # audiences optional but should be list if provided
                if 'audiences' in cfg and not isinstance(cfg['audiences'], list | tuple):
                    cfg['audiences'] = [str(cfg['audiences'])]
            SAML_IDP_SPCONFIG.update(parsed)
    except Exception:
        # Ignore malformed JSON; callers can inspect logs elsewhere
        pass

# Optionally merge SP config entries from JSON file path
_sp_file = get_saml_idp_spconfig_file()
if _sp_file:
    try:
        with open(_sp_file, encoding='utf-8') as f:
            file_payload = f.read()
        parsed = json.loads(file_payload)
        if isinstance(parsed, dict):
            for sp_entity, cfg in list(parsed.items()):
                if not isinstance(cfg, dict) or 'acs_url' not in cfg:
                    parsed.pop(sp_entity, None)
                    continue
                if 'audiences' in cfg and not isinstance(cfg['audiences'], list | tuple):
                    cfg['audiences'] = [str(cfg['audiences'])]
            SAML_IDP_SPCONFIG.update(parsed)
    except Exception:
        pass

# Optional env-driven IdP base config (template-only)
SAML_IDP_ENTITY_ID = get_saml_idp_entity_id()
SAML_IDP_CERT_FILE = get_saml_idp_cert_file()  # filesystem path to public cert (do not commit)
SAML_IDP_PRIVATE_KEY_FILE = get_saml_idp_private_key_file()  # filesystem path to private key (do not commit)

# djangosaml2idp-compatible base config shell; populate via env
SAML_IDP_CONFIG = {
    'entityid': SAML_IDP_ENTITY_ID,
    # The following are template defaults; set files via env for real deployments
    'cert_file': SAML_IDP_CERT_FILE,
    'key_file': SAML_IDP_PRIVATE_KEY_FILE,
}

# Optional MCP server integration (django-mcp-server). Disabled by default.
ENABLE_MCP_SERVER = is_enable_mcp_server()
if ENABLE_MCP_SERVER:
    try:
        INSTALLED_APPS += ['django_mcp_server']
    except Exception:
        # Optional dependency; ignore when not available
        pass

# Optional GitHub marketplace discovery (disabled by default)
ENABLE_GITHUB_MARKETPLACE = is_enable_github_marketplace()
GITHUB_TOKEN = get_github_token()  # optional, for higher rate limits

def _csv_env(name: str, default: str = '') -> list[str]:
    val = os.getenv(name, default)
    if not val:
        return []
    return [x.strip() for x in val.split(',') if x.strip()]

GITHUB_MARKETPLACE_TOPICS = _csv_env('GITHUB_MARKETPLACE_TOPICS', 'open-swarm-blueprint,open-swarm-mcp-template')
GITHUB_MARKETPLACE_ORG_ALLOWLIST = _csv_env('GITHUB_MARKETPLACE_ORG_ALLOWLIST', '')

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    # Add custom middleware to handle async user loading after standard auth
    'swarm.middleware.AsyncAuthMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'swarm.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR.parent / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'swarm.wsgi.application'
ASGI_APPLICATION = 'swarm.asgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.environ.get('DJANGO_DB_NAME', '/tmp/db.sqlite3'),
        'TEST': {
            'NAME': os.environ.get('DJANGO_TEST_DB_NAME', '/tmp/test_db.sqlite3'),
            'OPTIONS': {
                'timeout': 20,
                'init_command': "PRAGMA journal_mode=WAL;",
            },
        },
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',},
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

STATIC_URL = 'static/'
STATIC_ROOT = BASE_DIR.parent / 'staticfiles'
STATICFILES_DIRS = [ BASE_DIR / "swarm" / "static", ]

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'swarm.auth.StaticTokenAuthentication',
        'swarm.auth.CustomSessionAuthentication',
    ],
    # *** IMPORTANT: Add DEFAULT_PERMISSION_CLASSES ***
    # If ENABLE_API_AUTH is False, we might want to allow any access for testing.
    # If ENABLE_API_AUTH is True, we require HasValidTokenOrSession.
    # We need to set this dynamically based on ENABLE_API_AUTH.
    # A simple way is to set it here, but a cleaner way might involve middleware
    # or overriding get_permissions in views. For now, let's adjust this:
    'DEFAULT_PERMISSION_CLASSES': [
         # If auth is enabled, require our custom permission
         'swarm.permissions.HasValidTokenOrSession' if ENABLE_API_AUTH else
         # Otherwise, allow anyone (useful for dev when token isn't set)
         'rest_framework.permissions.AllowAny'
    ],
    'DEFAULT_SCHEMA_CLASS': 'drf_spectacular.openapi.AutoSchema',
}

SPECTACULAR_SETTINGS = {
    'TITLE': 'Open Swarm API',
    'DESCRIPTION': 'API for managing autonomous agent swarms',
    'VERSION': '0.2.0',
    'SERVE_INCLUDE_SCHEMA': False,
}

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': { 'format': '[{levelname}] {asctime} - {name}:{lineno} - {message}', 'style': '{', },
        'simple': { 'format': '[{levelname}] {message}', 'style': '{', },
    },
    'handlers': {
        'console': { 'class': 'logging.StreamHandler', 'formatter': 'verbose', },
    },
    'loggers': {
        'django': { 'handlers': ['console'], 'level': get_django_log_level(), 'propagate': False, },
        'swarm': { 'handlers': ['console'], 'level': get_swarm_log_level(), 'propagate': False, },
        'swarm.auth': { 'handlers': ['console'], 'level': 'DEBUG', 'propagate': False, },
        'swarm.views': { 'handlers': ['console'], 'level': 'DEBUG', 'propagate': False, },
        'swarm.extensions': { 'handlers': ['console'], 'level': 'DEBUG', 'propagate': False, },
        'blueprint_django_chat': { 'handlers': ['console'], 'level': 'DEBUG', 'propagate': False, },
        'print_debug': { 'handlers': ['console'], 'level': 'DEBUG', 'propagate': False, },
    },
    'root': { 'handlers': ['console'], 'level': 'WARNING', },
}

REDIS_HOST = get_redis_host()
REDIS_PORT = get_redis_port()

LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/'
CSRF_TRUSTED_ORIGINS = get_django_csrf_trusted_origins()

# --- ComfyUI Configuration for Avatar Generation ---
COMFYUI_ENABLED = is_comfyui_enabled()
COMFYUI_HOST = get_comfyui_host()
COMFYUI_API_ENDPOINT = get_comfyui_api_endpoint()
COMFYUI_QUEUE_ENDPOINT = f"{COMFYUI_HOST}/queue"
COMFYUI_HISTORY_ENDPOINT = f"{COMFYUI_HOST}/history"

# Avatar generation settings
AVATAR_GENERATION_ENABLED = COMFYUI_ENABLED
AVATAR_STORAGE_PATH = BASE_DIR.parent / 'avatars'
AVATAR_URL_PREFIX = '/avatars/'

# Ensure avatar storage directory exists
AVATAR_STORAGE_PATH.mkdir(exist_ok=True)
