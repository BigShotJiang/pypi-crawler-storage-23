# Package initialization for swarm services
