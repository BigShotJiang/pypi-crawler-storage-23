#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/suggestion/blueprint_suggestion.py
