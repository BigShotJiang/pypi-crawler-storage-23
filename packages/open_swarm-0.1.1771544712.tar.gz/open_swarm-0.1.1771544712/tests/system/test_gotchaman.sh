#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/gotchaman/blueprint_gotchaman.py
