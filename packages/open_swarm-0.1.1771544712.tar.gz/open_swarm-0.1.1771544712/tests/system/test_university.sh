#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/university/blueprint_university.py
