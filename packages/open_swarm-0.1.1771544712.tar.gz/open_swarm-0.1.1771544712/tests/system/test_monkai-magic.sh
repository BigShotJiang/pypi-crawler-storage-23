#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/monkai-magic/blueprint_monkai_magic.py
