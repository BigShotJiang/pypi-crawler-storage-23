#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/dilbot_universe/blueprint_dilbot_universe.py
