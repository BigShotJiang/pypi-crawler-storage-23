#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/nebula_shellz/blueprint_nebula_shellz.py
