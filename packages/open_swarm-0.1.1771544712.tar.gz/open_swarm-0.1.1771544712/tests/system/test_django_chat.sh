#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/django_chat/blueprint_django_chat.py
