#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/gaggle/blueprint_gaggle.py
