#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/rue-code/blueprint_rue_code.py
