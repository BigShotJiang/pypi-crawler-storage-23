#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/divine_code/blueprint_divine_code.py
