#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/flock/blueprint_flock.py
