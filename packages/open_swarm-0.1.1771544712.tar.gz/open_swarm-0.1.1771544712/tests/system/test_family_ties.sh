#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/family_ties/blueprint_family_ties.py
