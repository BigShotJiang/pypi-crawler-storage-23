#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/echocraft/blueprint_echocraft.py
