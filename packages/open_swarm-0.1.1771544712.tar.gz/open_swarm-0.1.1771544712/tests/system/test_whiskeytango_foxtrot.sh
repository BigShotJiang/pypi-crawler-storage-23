#!/bin/bash
echo -e "what is your purpose\n/quit" | python blueprints/whiskeytango_foxtrot/blueprint_whiskeytango_foxtrot.py
