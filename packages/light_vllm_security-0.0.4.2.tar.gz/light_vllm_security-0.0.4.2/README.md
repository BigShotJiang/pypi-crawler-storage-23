# light-vllm-security

vLLM 模型加密与授权扩展包。为 vLLM 提供模型权重加密、离线授权验证和机器指纹绑定功能。

## 特性

- 🔐 **AES-256-GCM 加密** — 流式加密，支持大模型分片
- 📜 **RSA 签名授权** — 离线验证，无需联网
- 🖥️ **机器指纹绑定** — 防止授权文件被复制到其他机器
- 🤖 **自动检测** — 检测到 `.enc` 文件自动启用加密加载
- 🔌 **零侵入** — 不修改官方 vllm 源码，通过命名空间包扩展

## 安装

```bash
# 1. 安装官方 vllm
pip install vllm==0.8.5.post2

# 2. 安装本扩展包
pip install light-vllm-security
```

安装后自动生效，无需任何额外配置。

## 快速开始

### 第一步：生成厂商密钥对（一次性操作）

```bash
vllm-gen-license --gen-keypair \
    --private-key vendor_private.pem \
    --public-key vendor_public.pem
```

> ⚠️ **保管好 `vendor_private.pem`！** 这是你的签名私钥，泄露后无法撤销已签发的授权。

### 第二步：加密模型

```bash
# 加密 HuggingFace 格式模型目录
vllm-encrypt-model \
    --input ./my_model \
    --output ./my_model_encrypted

# 加密单个 GGUF 文件
vllm-encrypt-model \
    --input ./model.gguf \
    --output ./model.gguf.enc
```

加密后目录结构：
```
my_model_encrypted/
├── config.json          # 原样复制
├── tokenizer.json       # 原样复制
├── model.safetensors.enc  # 加密的权重文件
└── .model_key           # 密钥元数据（需妥善保管）
```

### 第三步：获取客户机器指纹（可选，用于机器绑定）

在客户机器上运行：

```bash
vllm-get-fingerprint
```

输出示例：
```
Machine Fingerprint: a1b2c3d4e5f6...
```

### 第四步：生成授权文件

```bash
# 无机器绑定（测试用）
vllm-gen-license \
    --model-dir ./my_model_encrypted \
    --vendor-key vendor_private.pem \
    --customer "客户名称" \
    --policy none \
    --out customer.lic

# 绑定到特定机器
vllm-gen-license \
    --model-dir ./my_model_encrypted \
    --vendor-key vendor_private.pem \
    --customer "客户名称" \
    --fingerprint a1b2c3d4e5f6... \
    --policy single \
    --expire 2027-12-31 \
    --out customer.lic
```

### 第五步：分发给客户

将以下文件发给客户：
- `my_model_encrypted/` — 加密模型目录
- `vendor_public.pem` — 厂商公钥（用于验证授权签名）
- `customer.lic` — 授权文件
- `vendor_secret.bin` — 厂商密钥（用于解密 DEK，**通过安全渠道传递**）

### 第六步：客户运行模型

```bash
# 方式一：环境变量（推荐）
export VLLM_VENDOR_SECRET=<vendor_secret_hex>
vllm serve ./my_model_encrypted \
    --load-format encrypted

# 方式二：命令行参数
vllm serve ./my_model_encrypted \
    --load-format encrypted \
    --model-loader-extra-config '{"vendor_secret": "<hex>", "license_path": "./customer.lic", "vendor_pubkey_path": "./vendor_public.pem"}'

# 方式三：自动检测（模型目录包含 .enc 文件时自动启用）
export VLLM_VENDOR_SECRET=<vendor_secret_hex>
vllm serve ./my_model_encrypted
```

授权文件和公钥默认从模型目录自动发现：
- `<model_dir>/model.lic` — 授权文件
- `<model_dir>/vendor_public.pem` — 厂商公钥

## 文件格式

### 加密文件格式（`.enc`）

```
[Header 32B]
  magic:     8B  "VLLMENC\x00"
  version:   1B  0x01
  algorithm: 1B  0x01 (AES-256-GCM)
  key_id:   16B  UUID
  reserved:  6B

[Chunk 1]
  size:  4B  (little-endian uint32, ciphertext+tag 长度)
  nonce: 12B
  data:  N B  (ciphertext + 16B GCM tag)

[Chunk 2] ...
```

### 授权文件格式（`.lic`）

JSON 格式，包含：
- `license_id` — 唯一授权 ID
- `customer` — 客户名称
- `model_key_id` — 对应模型的密钥 ID
- `dek_encrypted` — 加密的数据加密密钥
- `dek_hash` — DEK 完整性校验
- `issued_at` / `expire_at` — 签发/过期日期
- `fingerprint_policy` — 机器绑定策略
- `allowed_fingerprints` — 允许的机器指纹列表
- `signature` — RSA-PSS 签名

## 安全说明

| 组件 | 安全级别 | 说明 |
|------|---------|------|
| 模型权重 | AES-256-GCM | 工业级对称加密 |
| 授权签名 | RSA-3072 PSS | 防篡改 |
| DEK 保护 | HKDF + AES-256-GCM | 基于 vendor_secret 派生 |
| 机器绑定 | SHA-256 指纹 | 防止授权文件复制 |

**重要：** `vendor_secret` 的安全性等同于 `vendor_private.pem`，必须通过安全渠道传递给客户（如加密邮件、密钥管理服务等）。

## 与 vllm 版本兼容性

| light-vllm-security | 兼容 vllm 版本 |
|--------------------|--------------|
| 0.1.x              | 0.8.5.post1+ |

## 开发

```bash
git clone https://github.com/yourusername/light-vllm-security
cd light-vllm-security
pip install -e ".[dev]"
pytest tests/
```

## 许可证

Apache License 2.0
