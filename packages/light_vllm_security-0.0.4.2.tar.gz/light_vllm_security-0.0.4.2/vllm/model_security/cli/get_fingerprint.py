#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""
Machine fingerprint tool.

Generates a unique machine fingerprint for license binding.
Run this on the target deployment machine and send the output to the vendor.

Usage:
    python -m vllm.model_security.cli.get_fingerprint
    python -m vllm.model_security.cli.get_fingerprint --include-gpu
    python -m vllm.model_security.cli.get_fingerprint --json
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from vllm.model_security.fingerprint import get_machine_fingerprint, get_fingerprint_info


def main():
    parser = argparse.ArgumentParser(
        description="Get machine fingerprint for license binding",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Get basic fingerprint (recommended for most cases)
  python -m vllm.model_security.cli.get_fingerprint

  # Include GPU UUIDs in fingerprint
  python -m vllm.model_security.cli.get_fingerprint --include-gpu

  # Output as JSON for scripting
  python -m vllm.model_security.cli.get_fingerprint --json

  # Show all components used in fingerprint
  python -m vllm.model_security.cli.get_fingerprint --verbose
        """,
    )
    parser.add_argument(
        "--include-gpu", action="store_true",
        help="Include GPU UUIDs in fingerprint (may change if GPUs are replaced)"
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Output as JSON"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Show all fingerprint components"
    )

    args = parser.parse_args()

    if args.verbose or args.json:
        info = get_fingerprint_info()
        if args.json:
            print(json.dumps(info, indent=2))
        else:
            print("Machine Fingerprint Components:")
            print(f"  CPU ID:          {info['cpu_id']}")
            print(f"  MAC Addresses:   {', '.join(info['mac_addresses'])}")
            print(f"  Hostname:        {info['hostname']}")
            print(f"  GPU UUIDs:       {', '.join(info['gpu_uuids']) or '(none)'}")
            print(f"  Platform:        {info['platform']}")
            print()
            print(f"Fingerprint (no GPU):   {info['fingerprint']}")
            print(f"Fingerprint (with GPU): {info['fingerprint_with_gpu']}")
            print()
            if args.include_gpu:
                print(f"Use this fingerprint: {info['fingerprint_with_gpu']}")
            else:
                print(f"Use this fingerprint: {info['fingerprint']}")
    else:
        fp = get_machine_fingerprint(include_gpu=args.include_gpu)
        print(fp)


if __name__ == "__main__":
    main()
