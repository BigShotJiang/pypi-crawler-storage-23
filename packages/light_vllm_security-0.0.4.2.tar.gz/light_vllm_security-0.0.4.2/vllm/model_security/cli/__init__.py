# SPDX-License-Identifier: Apache-2.0
"""
Command-line tools for model encryption and license management.
"""
