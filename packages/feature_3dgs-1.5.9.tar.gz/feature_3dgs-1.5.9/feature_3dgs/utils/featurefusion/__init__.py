from .fusion import feature_fusion
from .average import feature_fusion_alpha_avg
from .maximum import feature_fusion_alpha_max
