"""Tests for runtime-core package."""
