"""Console reporter - re-exports from reporting context.

DEPRECATED: Import from venomqa.reporting instead.
"""

from venomqa.reporting.console import ConsoleReporter

__all__ = ["ConsoleReporter"]
