def main():

 import base64
import zlib
import os
import random
import string
from datetime import datetime
from colorama import Fore, Style, init
from pyfiglet import Figlet

init(autoreset=True)

# -------- BANNER --------

def banner():
    os.system("clear" if os.name == "posix" else "cls")

    f = Figlet(font="slant", width=120)
    text = f.renderText("Wasim")

    for line in text.split("\n"):
        print(Fore.RED + line.center(90))

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    print(Fore.CYAN + ("Date & Time : " + now).center(90))
    print(Fore.YELLOW + ("Author : Wasim").center(90))
    print(Fore.GREEN + ("Tool : Encryption Tool").center(90))
    print()

banner()


file_to_encrypt = input("Enter Python file name (example: mybot.py): ").strip()

if not os.path.isfile(file_to_encrypt):
    print("❌ File not found!")
    exit()

print("\n1. Set Expiry Date & Time")
print("2. Skip (No Expiry)")

option = input("Select option: ").strip()

expiry_code = ""

if option == "1":
    expiry_input = input("Enter expiry date & time (YYYY-MM-DD HH:MM): ").strip()
    try:
        expiry_datetime = datetime.strptime(expiry_input, "%Y-%m-%d %H:%M")
        expiry_code = f'''
from datetime import datetime
if datetime.now() > datetime.strptime("{expiry_datetime}", "%Y-%m-%d %H:%M:%S"):
    print("\\n⛔ Tool Expired!")
    exit()
'''
    except:
        print("❌ Invalid date format!")
        exit()

# Random variable names
def random_name():
    return ''.join(random.choice(string.ascii_letters) for _ in range(10))

v1 = random_name()
v2 = random_name()
v3 = random_name()
v4 = random_name()

# Read original file
with open(file_to_encrypt, "r", encoding="utf-8") as f:
    source = f.read()

# Multi-layer encoding
layer1 = base64.b64encode(source.encode())
layer2 = zlib.compress(layer1)
layer3 = base64.b64encode(layer2).decode()

# Protected stub
stub = f'''# 🔒 ENCODE BY @w4simg

import base64
import zlib

{expiry_code}

{v1} = "{layer3}"
{v2} = base64.b64decode({v1})
{v3} = zlib.decompress({v2})
{v4} = base64.b64decode({v3}).decode("utf-8")

exec({v4})

del {v1}
del {v2}
del {v3}
del {v4}
'''

output_file = "wasim_enc_" + file_to_encrypt

with open(output_file, "w", encoding="utf-8") as f:
    f.write(stub)

print(Fore.GREEN + f"\n✅ Protected file created: {output_file}\n")