"""File I/O for keephive data: daily logs, memory.md, rules.md.

All paths point to ~/.claude/hive/ by default. Same data files as the
bash version, no migration needed.
"""

from __future__ import annotations

import fcntl
import json
import os
import re
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path


def parse_date_arg(arg: str) -> str:
    """Parse a date argument into an ISO date string.

    Accepts:
        ""           -> today
        "today"      -> today
        "yesterday"  -> yesterday's date
        "3"          -> 3 days ago
        "2026-02-15" -> literal ISO date
    """
    if not arg or arg == "today":
        return date.today().isoformat()

    if arg == "yesterday":
        return (date.today() - timedelta(days=1)).isoformat()

    if arg.isdigit():
        days_ago = int(arg)
        return (date.today() - timedelta(days=days_ago)).isoformat()

    # Try ISO date
    if re.match(r"^\d{4}-\d{2}-\d{2}$", arg):
        try:
            date.fromisoformat(arg)
            return arg
        except ValueError:
            pass

    return arg  # Let it fail downstream with a clear message


def safe_read_text(path: Path) -> str:
    """Read file text, replacing bad bytes instead of crashing."""
    return path.read_text(errors="replace")


def hive_dir() -> Path:
    """Root hive directory, respecting HIVE_HOME env var."""
    return Path(os.environ.get("HIVE_HOME", Path.home() / ".claude" / "hive"))


def working_dir() -> Path:
    return hive_dir() / "working"


def daily_dir() -> Path:
    return hive_dir() / "daily"


def knowledge_dir() -> Path:
    return hive_dir() / "knowledge"


def guides_dir() -> Path:
    return knowledge_dir() / "guides"


def prompts_dir() -> Path:
    return knowledge_dir() / "prompts"


def archive_dir() -> Path:
    return hive_dir() / "archive"


def drafts_dir() -> Path:
    return working_dir() / "drafts"


def notes_dir() -> Path:
    return working_dir() / "notes"


NOTE_SLOT_COUNT = 10


def active_slot() -> int:
    """Read active note slot number (1-10). Default 1."""
    marker = working_dir() / ".note-active"
    if marker.exists():
        try:
            n = int(marker.read_text().strip())
            if 1 <= n <= NOTE_SLOT_COUNT:
                return n
        except (ValueError, OSError):
            pass
    return 1


def set_active_slot(n: int) -> None:
    """Write active note slot number (1-10)."""
    if not 1 <= n <= NOTE_SLOT_COUNT:
        raise ValueError(f"Slot must be 1-{NOTE_SLOT_COUNT}, got {n}")
    marker = working_dir() / ".note-active"
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(str(n))


def slot_file(n: int) -> Path:
    """Path to note slot file. Slots 1-10."""
    return working_dir() / f"note-{n}.md"


def ensure_dirs() -> None:
    """Create all required directories if they don't exist."""
    for d in [
        working_dir(),
        daily_dir(),
        knowledge_dir(),
        guides_dir(),
        prompts_dir(),
        archive_dir(),
        notes_dir(),
    ]:
        d.mkdir(parents=True, exist_ok=True)


def today() -> str:
    return date.today().isoformat()


def yesterday() -> str:
    return (date.today() - timedelta(days=1)).isoformat()


def daily_file(day: str | None = None) -> Path:
    """Path to a daily log file. Defaults to today."""
    if day is None:
        day = today()
    return daily_dir() / f"{day}.md"


def ensure_daily(day: str | None = None) -> Path:
    """Ensure today's daily file exists with header. Returns path."""
    ensure_dirs()
    path = daily_file(day)
    if not path.exists():
        path.write_text(f"# Daily Log: {day or today()}\n\n")
    return path


def memory_file() -> Path:
    return working_dir() / "memory.md"


def rules_file() -> Path:
    return working_dir() / "rules.md"


def read_memory() -> str:
    """Read working memory, empty string if missing."""
    f = memory_file()
    return f.read_text() if f.exists() else ""


def read_rules() -> str:
    """Read working rules, empty string if missing."""
    f = rules_file()
    return f.read_text() if f.exists() else ""


def backup_and_write(path: Path, content: str) -> None:
    """Backup a file then atomically write new content."""
    if path.exists():
        shutil.copy2(path, path.with_suffix(path.suffix + ".bak"))
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content)
    os.replace(str(tmp), str(path))


def append_to_daily(text: str, day: str | None = None) -> Path:
    """Append a line to the daily log. Returns the daily file path."""
    path = ensure_daily(day)
    with open(path, "a") as f:
        f.write(text + "\n")
    return path


def stale_days() -> int:
    return int(os.environ.get("HIVE_STALE_DAYS", "30"))


def capture_budget() -> int:
    return int(os.environ.get("HIVE_CAPTURE_BUDGET", "4000"))


# ---- Counting / querying ----


def count_stale_facts() -> int:
    """Count facts in memory.md with verified dates older than stale threshold."""
    mem = memory_file()
    if not mem.exists():
        return 0

    cutoff = date.today() - timedelta(days=stale_days())
    count = 0

    for line in mem.read_text().splitlines():
        m = re.search(r"\[verified:(\d{4}-\d{2}-\d{2})\]", line)
        if m:
            try:
                vdate = date.fromisoformat(m.group(1))
                if vdate < cutoff:
                    count += 1
            except ValueError:
                pass
    return count


def get_stale_facts() -> list[tuple[int, str, str]]:
    """Get stale facts with line numbers and the raw line.

    Returns list of (line_number_1based, fact_text, raw_line).
    """
    mem = memory_file()
    if not mem.exists():
        return []

    cutoff = date.today() - timedelta(days=stale_days())
    results = []

    for i, line in enumerate(mem.read_text().splitlines(), 1):
        m = re.search(r"\[verified:(\d{4}-\d{2}-\d{2})\]", line)
        if m:
            try:
                vdate = date.fromisoformat(m.group(1))
                if vdate < cutoff:
                    # Strip the verified tag to get the fact text
                    fact = (
                        re.sub(r"\s*\[verified:\d{4}-\d{2}-\d{2}\]", "", line).lstrip("- ").strip()
                    )
                    results.append((i, fact, line))
            except ValueError:
                pass
    return results


def get_all_verified_facts() -> list[tuple[int, str, str]]:
    """Get ALL facts with [verified:] tags, regardless of age.

    Returns list of (line_number_1based, fact_text, raw_line).
    """
    mem = memory_file()
    if not mem.exists():
        return []

    results = []

    for i, line in enumerate(mem.read_text().splitlines(), 1):
        m = re.search(r"\[verified:(\d{4}-\d{2}-\d{2})\]", line)
        if m:
            try:
                date.fromisoformat(m.group(1))  # validate date
                fact = re.sub(r"\s*\[verified:\d{4}-\d{2}-\d{2}\]", "", line).lstrip("- ").strip()
                results.append((i, fact, line))
            except ValueError:
                pass
    return results


def count_daily_entries(day: str | None = None, exclude_noise: bool = True) -> int:
    """Count meaningful entries in a daily log file."""
    path = daily_file(day)
    if not path.exists():
        return 0

    count = 0
    cats_re = re.compile(r"^- (DECISION|FACT|CORRECTION|TODO|INSIGHT):")

    for line in safe_read_text(path).splitlines():
        line = line.rstrip()
        m = re.match(r"^- \[(\d{2}:\d{2}:\d{2})\]\s*(.*)", line)
        if m:
            rest = m.group(2)
            upper = rest.upper()
            if exclude_noise and (
                "SESSION" in upper or "COMPACTED" in upper or "COMPACTION" in upper
            ):
                continue
            count += 1
        elif cats_re.match(line):
            count += 1
    return count


def get_meaningful_entries(day: str | None = None, limit: int = 8) -> list[str]:
    """Extract meaningful entries from a daily log, formatted for display.

    Returns formatted entry strings (with ~ prefix for categorized entries).
    """
    path = daily_file(day)
    if not path.exists():
        return []

    cats_re = re.compile(r"(DECISION|FACT|CORRECTION|TODO|INSIGHT):")
    entries: list[str] = []
    in_summary = False
    summary_is_clean: bool | None = None

    for line in safe_read_text(path).splitlines():
        line = line.rstrip()
        if line.startswith("### Session Summary"):
            in_summary = True
            summary_is_clean = None
            continue
        if line.startswith("### ") or line.startswith("# "):
            in_summary = False
            continue

        m = re.match(r"^- \[(\d{2}:\d{2}:\d{2})\]\s*(.*)", line)
        if m:
            ts, rest = m.group(1), m.group(2)
            upper = rest.upper()
            if "SESSION" in upper or "COMPACTED" in upper or "COMPACTION" in upper:
                continue
            if cats_re.match(rest):
                if in_summary:
                    if summary_is_clean is None:
                        summary_is_clean = True
                    if summary_is_clean:
                        entries.append(f"  ~ [{ts}] {rest}")
                else:
                    entries.append(f"  ~ [{ts}] {rest}")
            else:
                in_summary = False
                entries.append(f"  {line[2:]}")
            continue

        if re.match(r"^- " + r"(DECISION|FACT|CORRECTION|TODO|INSIGHT):", line):
            if in_summary:
                if summary_is_clean is None:
                    summary_is_clean = True
                if summary_is_clean:
                    entries.append(f"  ~ {line[2:]}")
            continue

        if in_summary and line.strip() and summary_is_clean is None:
            summary_is_clean = False

    # Truncate long entries, return last N
    result = []
    for e in entries[-limit:]:
        if len(e) > 120:
            result.append(e[:120] + "...")
        else:
            result.append(e)
    return result


def collect_todos() -> tuple[list[tuple[str, str, str]], set[str]]:
    """Collect all TODOs and DONEs from last 30 days of daily logs.

    Returns (todos_list, done_set) where todos_list is [(date_str, time_str, text)]
    and done_set is {text.lower()}. time_str is "HH:MM" or "" if no timestamp.
    """
    d = daily_dir()
    if not d.exists():
        return [], set()

    cutoff = (date.today() - timedelta(days=30)).isoformat()
    todos: list[tuple[str, str, str]] = []
    dones: set[str] = set()

    for fpath in sorted(d.glob("*.md")):
        fname = fpath.stem
        if fname < cutoff:
            continue
        for line in safe_read_text(fpath).splitlines():
            line = line.rstrip()
            # TODO entries with timestamp
            m = re.match(r"^- \[(\d{2}:\d{2}):\d{2}\]\s*TODO:\s*(.*)", line)
            if m:
                todos.append((fname, m.group(1), m.group(2).strip()))
                continue
            # TODO entries without timestamp
            m = re.match(r"^- TODO:\s*(.*)", line)
            if m:
                todos.append((fname, "", m.group(1).strip()))
                continue
            # DONE entries
            m = re.match(r"^- \[\d{2}:\d{2}:\d{2}\]\s*DONE:\s*(.*)", line)
            if m:
                dones.add(m.group(1).strip().lower())
                continue
            m = re.match(r"^- DONE:\s*(.*)", line)
            if m:
                dones.add(m.group(1).strip().lower())

    return todos, dones


def open_todos() -> list[tuple[str, str, str]]:
    """Return open TODOs (not completed), deduplicated.

    Returns list of (date_str, time_str, text).
    """
    todos, dones = collect_todos()
    open_list = [(d, t, text) for d, t, text in todos if text.lower() not in dones]
    return _dedup_todos(open_list)


def _normalize_todo_text(text: str) -> str:
    """Normalize TODO text for comparison.

    Strips common prefixes like [audit], [reflect], [daily], timestamps,
    normalizes whitespace and punctuation.
    """
    s = text.strip().lower()
    # Strip bracketed prefixes: [audit], [reflect], [daily], etc.
    s = re.sub(r"^\[[\w-]+\]\s*", "", s)
    # Strip leading timestamps if present
    s = re.sub(r"^\d{2}:\d{2}(:\d{2})?\s*", "", s)
    # Normalize whitespace
    s = re.sub(r"\s+", " ", s)
    # Strip trailing punctuation
    s = s.rstrip(".,;:!?")
    return s


def _dedup_todos(todos: list[tuple[str, str, str]]) -> list[tuple[str, str, str]]:
    """Remove near-duplicate TODOs, keeping most recent.

    Uses a two-pass approach:
    1. Fast exact-content dedup (after normalization)
    2. Fuzzy SequenceMatcher for remaining items (threshold 0.8)
    """
    from difflib import SequenceMatcher

    if not todos:
        return []

    # Pass 1: exact content dedup (after normalization)
    seen_normalized: dict[str, int] = {}  # normalized -> index in result
    result: list[tuple[str, str, str]] = []

    for d, t, text in todos:
        norm = _normalize_todo_text(text)
        if norm in seen_normalized:
            idx = seen_normalized[norm]
            rd, _, _ = result[idx]
            if d > rd:
                result[idx] = (d, t, text)
        else:
            seen_normalized[norm] = len(result)
            result.append((d, t, text))

    # Pass 2: fuzzy dedup on remaining items
    deduped: list[tuple[str, str, str]] = []
    for d, t, text in result:
        norm = _normalize_todo_text(text)
        is_dup = False
        for i, (rd, _, rtext) in enumerate(deduped):
            rnorm = _normalize_todo_text(rtext)
            if SequenceMatcher(None, norm, rnorm).ratio() >= 0.8:
                if d > rd:
                    deduped[i] = (d, t, text)
                is_dup = True
                break
        if not is_dup:
            deduped.append((d, t, text))

    return deduped


def recent_dones(days: int = 3) -> list[tuple[str, str]]:
    """Return recently completed TODOs from daily logs.

    Returns list of (date_str, text) for DONEs in the last N days.
    """
    cutoff = (date.today() - timedelta(days=days)).isoformat()
    dones: list[tuple[str, str]] = []
    d = daily_dir()
    if not d.exists():
        return dones
    for fpath in sorted(d.glob("*.md")):
        if fpath.stem < cutoff:
            continue
        for line in safe_read_text(fpath).splitlines():
            m = re.match(r"^- \[\d{2}:\d{2}:\d{2}\]\s*DONE:\s*(.*)", line)
            if m:
                dones.append((fpath.stem, m.group(1).strip()))
                continue
            m2 = re.match(r"^- DONE:\s*(.*)", line)
            if m2:
                dones.append((fpath.stem, m2.group(1).strip()))
    return dones


def undo_done(pattern: str = "") -> str | None:
    """Remove the most recent DONE entry matching pattern from daily logs.

    Searches recent files (newest first). If pattern is empty, removes the
    most recent DONE entry from today only.
    Returns undone text, or None if not found.
    """
    d = daily_dir()
    if not d.exists():
        return None

    files = sorted(d.glob("*.md"), reverse=True)
    # With no pattern, only search today; with pattern, search last 3 days
    search_files = files[:1] if not pattern else files[:3]

    for fpath in search_files:
        lines = safe_read_text(fpath).splitlines(keepends=True)
        match_idx = None
        match_text = None
        for i in range(len(lines) - 1, -1, -1):
            m = re.match(r"^- \[\d{2}:\d{2}:\d{2}\]\s*DONE:\s*(.*)", lines[i])
            if not m:
                m = re.match(r"^- DONE:\s*(.*)", lines[i])
            if m:
                text = m.group(1).strip()
                if not pattern or pattern.lower() in text.lower():
                    match_idx = i
                    match_text = text
                    break
        if match_idx is not None:
            del lines[match_idx]
            fpath.write_text("".join(lines))
            return match_text

    return None


# ---- Recurring tasks ----

FREQ_ALIASES = {"daily": 1.0, "weekly": 7.0, "monthly": 30.0}

# Regex for frequency strings: daily, weekly, monthly, 2d, 12h, etc.
FREQ_RE = re.compile(r"^(\d+)([dh])$")


def parse_freq(freq_str: str) -> float:
    """Parse a frequency string to interval in days.

    Accepts: daily, weekly, monthly, Nd (N days), Nh (N hours).
    Returns interval in fractional days.
    """
    if freq_str in FREQ_ALIASES:
        return FREQ_ALIASES[freq_str]
    m = FREQ_RE.match(freq_str)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        if unit == "d":
            return float(n)
        if unit == "h":
            return n / 24.0
    raise ValueError(f"Invalid frequency: {freq_str!r}. Use daily, weekly, monthly, Nd, or Nh.")


def is_valid_freq(freq_str: str) -> bool:
    """Check if a frequency string is valid."""
    try:
        parse_freq(freq_str)
        return True
    except ValueError:
        return False


def recurring_file() -> Path:
    return working_dir() / "recurring.md"


def _parse_recurring_status() -> list[tuple[str, str, float]]:
    """Parse recurring.md, return (freq, text, overdue_days_float) for all tasks.

    overdue_days >= 0: already due/overdue.
    overdue_days < 0: -(days until due).
    """
    rf = recurring_file()
    if not rf.exists():
        return []

    content = safe_read_text(rf)
    tasks: list[tuple[str, str]] = []
    last_done: dict[str, str] = {}  # text_lower -> date_or_datetime_str
    in_completed = False

    for line in content.splitlines():
        line = line.rstrip()
        if line.startswith("## Last Completed"):
            in_completed = True
            continue
        if line.startswith("## ") or line.startswith("# "):
            if in_completed:
                in_completed = False
            continue

        if not in_completed:
            m = re.match(r"^- \[([^\]]+)\]\s*(.*)", line)
            if m and is_valid_freq(m.group(1)):
                tasks.append((m.group(1), m.group(2).strip()))
        else:
            m = re.match(r"^- (.+?):\s*(\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2})?)", line)
            if m:
                last_done[m.group(1).strip().lower()] = m.group(2)

    result: list[tuple[str, str, float]] = []
    now = datetime.now()
    t = date.today()
    for freq, text in tasks:
        interval_days = parse_freq(freq)
        last = last_done.get(text.lower())
        if last:
            try:
                if "T" in last:
                    last_dt = datetime.fromisoformat(last)
                    elapsed_days = (now - last_dt).total_seconds() / 86400
                else:
                    last_date = date.fromisoformat(last)
                    elapsed_days = float((t - last_date).days)
                result.append((freq, text, elapsed_days - interval_days))
            except ValueError:
                result.append((freq, text, float(interval_days)))
        else:
            result.append((freq, text, float(interval_days)))

    return result


def due_recurring() -> list[tuple[str, str, int]]:
    """Return (frequency, text, days_overdue) for due recurring tasks."""
    return [(f, t, int(o)) for f, t, o in _parse_recurring_status() if o >= 0]


def all_recurring() -> list[tuple[str, str, int]]:
    """Return (freq, text, overdue_days) for ALL recurring tasks.

    overdue_days >= 0: due/overdue. overdue_days < 0: -(days until due).
    Sorted: most overdue first, then by time remaining ascending.
    """
    raw = _parse_recurring_status()
    result = [(f, t, int(o)) for f, t, o in raw]
    return sorted(result, key=lambda x: -x[2])


def mark_recurring_done(pattern: str) -> tuple[str, str] | None:
    """Mark a recurring task as done by pattern match.

    Returns (task_text, done_str) on success, None if no match.
    Pure data function: no console output.
    """
    rf = recurring_file()
    if not rf.exists():
        return None

    content = safe_read_text(rf)

    # Find matching task
    match_text = None
    match_freq = None
    task_re = re.compile(r"^- \[([^\]]+)\]\s*(.*)")
    for line in content.splitlines():
        m = task_re.match(line)
        if m and is_valid_freq(m.group(1)) and pattern.lower() in m.group(2).lower():
            match_freq = m.group(1)
            match_text = m.group(2).strip()
            break

    if not match_text:
        return None

    # Use datetime for hour-based tasks, date for day-based
    uses_hours = match_freq and match_freq.endswith("h")
    if uses_hours:
        done_str = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    else:
        done_str = date.today().isoformat()

    # Update or add Last Completed entry
    lines = content.splitlines(keepends=True)
    found_entry = False
    for i, line in enumerate(lines):
        m = re.match(r"^- (.+?):\s*\d{4}-\d{2}-\d{2}", line)
        if m and m.group(1).strip().lower() == match_text.lower():
            lines[i] = f"- {match_text}: {done_str}\n"
            found_entry = True
            break

    if not found_entry:
        if lines and not lines[-1].endswith("\n"):
            lines[-1] += "\n"
        lines.append(f"- {match_text}: {done_str}\n")

    rf.write_text("".join(lines))
    return (match_text, done_str)


def recent_daily_files(days: int = 7) -> list[Path]:
    """Return recent daily log files, most recent first."""
    d = daily_dir()
    if not d.exists():
        return []
    files = sorted(d.glob("*.md"), reverse=True)
    return files[:days]


def index_file() -> Path:
    return hive_dir() / ".index.json"


def version_context() -> str:
    """Gather system version info for verify/reflect prompts."""
    import subprocess

    lines = []
    for cmd, label in [
        (["node", "--version"], "Node.js"),
        (["python3", "--version"], "Python"),
        (["claude", "--version"], "Claude Code"),
        (["uv", "--version"], "uv"),
    ]:
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                lines.append(f"{label}: {r.stdout.strip()}")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    return "\n".join(lines)


def get_key_entries_past_days(days: int = 7, limit: int = 10) -> list[tuple[str, str]]:
    """FACT/CORRECTION/DECISION/INSIGHT entries from past N days.

    Excludes today. Skips TODOs (already shown in their own section).
    Returns list of (date_str, entry_line) most recent first.
    """
    dd = daily_dir()
    if not dd.exists():
        return []

    today_str = date.today().isoformat()
    cutoff = (date.today() - timedelta(days=days)).isoformat()

    results: list[tuple[str, str]] = []

    for fpath in sorted(dd.glob("*.md"), reverse=True):
        day_str = fpath.stem
        # Skip today (already shown) and files outside range
        if day_str >= today_str or day_str < cutoff:
            continue
        # Only date-named files
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", day_str):
            continue

        entries = get_meaningful_entries(day=day_str, limit=20)
        for entry in entries:
            # Only keep categorized entries (~ prefix), skip TODOs
            if not entry.strip().startswith("~"):
                continue
            if "TODO:" in entry:
                continue
            results.append((day_str, entry.strip()))
            if len(results) >= limit:
                return results

    return results


# ---- Usage Stats ----


def stats_file() -> Path:
    """Path to the stats JSON file."""
    return hive_dir() / ".stats.json"


def _detect_source() -> str:
    """Detect invocation context from environment."""
    if os.environ.get("CLAUDECODE"):
        return "claude_code"
    return "terminal"


def read_stats() -> dict:
    """Read stats from disk. Returns empty dict structure on missing/corrupt file."""
    sf = stats_file()
    if not sf.exists():
        return {"days": {}}
    try:
        with open(sf, "r") as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_SH)
            try:
                data = json.loads(f.read())
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        if "days" not in data:
            data["days"] = {}
        return data
    except (json.JSONDecodeError, OSError):
        return {"days": {}}


def _write_stats(data: dict) -> None:
    """Write stats atomically with exclusive lock."""
    sf = stats_file()
    sf.parent.mkdir(parents=True, exist_ok=True)
    with open(sf, "w") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            f.write(json.dumps(data, indent=2))
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def track_event(
    category: str,
    name: str,
    project: str = "",
    source: str = "",
) -> None:
    """Increment a daily counter. Handles nested project structure + source tracking.

    Args:
        category: Top-level category (commands, hooks, meta)
        name: Event name within category (e.g. "remember", "sessionstart")
        project: Full cwd path or ~ for home. Tracked per-project when provided.
        source: Invocation source (terminal, claude_code, mcp, hook). Auto-detected if empty.
    """
    try:
        data = read_stats()
        day = date.today().isoformat()

        if day not in data["days"]:
            data["days"][day] = {}
        day_data = data["days"][day]

        # Increment category counter
        if category not in day_data:
            day_data[category] = {}
        if name not in day_data[category]:
            day_data[category][name] = 0
        day_data[category][name] += 1

        # Track source
        src = source or _detect_source()
        if "sources" not in day_data:
            day_data["sources"] = {}
        if src not in day_data["sources"]:
            day_data["sources"][src] = 0
        day_data["sources"][src] += 1

        # Track per-project
        if project and category == "commands":
            # Normalize project path: replace home dir with ~
            home = str(Path.home())
            proj_key = project.replace(home, "~") if project.startswith(home) else project

            if "projects" not in day_data:
                day_data["projects"] = {}
            if proj_key not in day_data["projects"]:
                day_data["projects"][proj_key] = {
                    "commands": 0,
                    "sessions": 0,
                    "by_command": {},
                }
            proj = day_data["projects"][proj_key]
            proj["commands"] += 1
            if name not in proj["by_command"]:
                proj["by_command"][name] = 0
            proj["by_command"][name] += 1

        _write_stats(data)
    except Exception:
        pass  # Never block hooks or commands


# ---- FTS5 full-text search ----


def fts_db_path() -> Path:
    return hive_dir() / ".fts.db"


def rebuild_fts_index() -> None:
    """Build or rebuild FTS5 index from daily logs and archive."""
    import sqlite3

    db = fts_db_path()
    con = sqlite3.connect(str(db))
    try:
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS fts USING fts5(line, date, tier)")
        con.execute("DELETE FROM fts")
        for tier, directory in [("daily", daily_dir()), ("archive", archive_dir())]:
            if directory.exists():
                for f in directory.rglob("*.md"):
                    for line in safe_read_text(f).splitlines():
                        if line.strip():
                            con.execute(
                                "INSERT INTO fts VALUES (?, ?, ?)",
                                (line, f.stem, tier),
                            )
        con.commit()
    finally:
        con.close()


def fts_search(query: str, limit: int = 10) -> list[dict]:
    """FTS5 search over daily logs and archive. Falls back to [] on failure."""
    import sqlite3

    db = fts_db_path()
    if not db.exists():
        try:
            rebuild_fts_index()
        except Exception:
            return []
    try:
        con = sqlite3.connect(str(db))
        try:
            rows = con.execute(
                "SELECT line, date, tier, rank FROM fts WHERE fts MATCH ? ORDER BY rank LIMIT ?",
                (query, limit),
            ).fetchall()
        finally:
            con.close()
        results = []
        for line, date_str, tier, rank in rows:
            # rank is negative in FTS5; more negative = better match
            score = max(1, int(60 + rank * 5))
            results.append({"tier": tier, "line": line, "date": date_str, "score": score})
        return results
    except Exception:
        return []


# ---- Memory decay scoring ----

IMPORTANCE_WEIGHTS = {"CORRECTION": 1.5, "DECISION": 1.2, "FACT": 1.0, "INSIGHT": 1.0}


def _count_fact_references(fact_text: str) -> int:
    """Count how many times this fact is referenced in the last 30 daily log files."""
    keywords = [w.lower() for w in fact_text.split() if len(w) > 4]
    if not keywords:
        return 0
    dd = daily_dir()
    if not dd.exists():
        return 0
    files = sorted(dd.glob("*.md"), reverse=True)[:30]
    count = 0
    for f in files:
        text = safe_read_text(f).lower()
        if any(kw in text for kw in keywords):
            count += 1
    return count


def score_fact_decay(fact_text: str, verified_date_str: str) -> float:
    """Score a fact for decay. Lower score = better candidate for archiving.

    Components:
      recency (0.0-1.0, weight 0.5): 1.0 = today, 0.0 = 60+ days ago
      references (0.0-1.0, weight 0.3): how often it appears in daily logs
      importance (weight 0.2): by category prefix (CORRECTION > DECISION > FACT/INSIGHT)
    """
    try:
        vdate = date.fromisoformat(verified_date_str)
        days_old = (date.today() - vdate).days
        recency = max(0.0, 1.0 - days_old / 60.0)
    except ValueError:
        recency = 0.0

    refs = _count_fact_references(fact_text)
    ref_score = min(1.0, refs / 10.0)

    importance = 1.0
    for cat, weight in IMPORTANCE_WEIGHTS.items():
        if fact_text.upper().startswith(cat):
            importance = weight
            break

    return recency * 0.5 + ref_score * 0.3 + importance * 0.2
