import json
import uuid
from typing import Any, Dict, Optional, TypeVar

from agentswarm.agents.base_agent import BaseAgent, InputType, OutputType
from agentswarm.datamodels.context import Context
from agentswarm.llms.llm import LLM

try:
    from bedrock_agentcore.runtime.app import BedrockAgentCoreApp
    from bedrock_agentcore.runtime.context import BedrockAgentCoreContext
except ImportError:
    # Fallback or error if not installed
    BedrockAgentCoreApp = None
    BedrockAgentCoreContext = None


class AgentCoreBaseAgent(BaseAgent[InputType, OutputType]):
    """
    A base class for agents that use the simpler Bedrock AgentCore approach.
    It wraps the official BedrockAgentCoreApp and exposes it for serving.
    """

    def __init__(self, default_llm: Optional[LLM] = None):
        self.default_llm = default_llm
        self._app: Optional[Any] = None

    @property
    def app(self) -> Any:
        """
        Returns the BedrockAgentCoreApp instance.
        """
        if self._app is None:
            if BedrockAgentCoreApp is None:
                raise ImportError(
                    "bedrock-agentcore is not installed. "
                    "Please install it with: pip install bedrock-agentcore"
                )

            self._app = BedrockAgentCoreApp()

            @self._app.entrypoint
            async def handle_request(request: Dict[str, Any]) -> Dict[str, Any]:
                return await self.request(request)

        return self._app

    async def request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """
        Default implementation of the 'request' method.
        It expects a 'prompt' in the request and executes the agent.

        Args:
            request: The request dictionary from Bedrock AgentCore.

        Returns:
            A dictionary containing the agent's response.
        """
        from agentswarm.utils.tracing import LocalTracing
        from agentswarm.datamodels.local_store import LocalStore

        input_data = request.get("input") or request.get("prompt")
        user_id = request.get("user_id", "default_user")
        context_dict = request.get("context", {})

        # Use the Bedrock AgentCore context for session ID if available
        session_id = "unknown"
        if BedrockAgentCoreContext:
            session_id = BedrockAgentCoreContext.get_session_id() or request.get(
                "session_id", "unknown"
            )
        else:
            session_id = request.get("session_id", "unknown")

        if not context_dict:
            # Create a fresh context if none provided
            context = Context(
                trace_id=str(uuid.uuid4()),
                messages=[],
                store=LocalStore(),
                tracing=LocalTracing(),
                default_llm=self.default_llm,
            )
        else:
            # Ensure trace_id is present if from_dict is called
            if "trace_id" not in context_dict:
                context_dict["trace_id"] = str(uuid.uuid4())
            context = Context.from_dict(context_dict, default_llm=self.default_llm)

        # 3. Transform input to the expected InputType
        input_type = self._get_generic_type(0)
        validated_input = None

        if input_type:
            try:
                # Try to parse the whole request if it matches the schema
                validated_input = input_type.model_validate(request)
            except Exception:
                try:
                    # Try to parse the input itself as JSON if it's a string
                    if isinstance(input_data, str) and (
                        input_data.startswith("{") or input_data.startswith("[")
                    ):
                        try:
                            input_json_data = json.loads(input_data)
                            if isinstance(input_json_data, dict):
                                validated_input = input_type.model_validate(
                                    input_json_data
                                )
                        except Exception:
                            pass

                    if validated_input is None:
                        # Try to map 'input' to specific fields
                        fields = list(input_type.model_fields.keys())
                        if len(fields) == 1:
                            validated_input = input_type(**{fields[0]: input_data})
                        elif "input" in fields:
                            validated_input = input_type(input=input_data)
                        elif "query" in fields:
                            validated_input = input_type(query=input_data)
                        elif "prompt" in fields:
                            validated_input = input_type(prompt=input_data)
                        elif "value" in fields:
                            validated_input = input_type(value=input_data)
                        else:
                            # Fallback: pass as is
                            validated_input = input_data
                except Exception:
                    # Final fallback
                    validated_input = input_data

        result = await self.execute(
            user_id=user_id, context=context, input=validated_input
        )

        # We return a simple format compatible with the expected client response
        # Ensure result is serializable
        serialized_result = (
            result.model_dump() if hasattr(result, "model_dump") else result
        )

        return {
            "result": serialized_result,
            "session_id": session_id,
            "updated_context": context.to_dict(),
        }

    def serve(self, host: str = "0.0.0.0", port: int = 8000):
        """
        Starts the Bedrock AgentCore application server.
        """
        self.app.run(host=host, port=port)
