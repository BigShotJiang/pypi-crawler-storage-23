# ABOUTME: Tool layer for the dynagent reference architecture.
# ABOUTME: Contains state management, format conversion, and registry tools.
