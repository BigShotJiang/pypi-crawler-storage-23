# ABOUTME: LLM provider layer for the dynagent package.
# ABOUTME: Centralizes model construction for reuse across agents and tools.
