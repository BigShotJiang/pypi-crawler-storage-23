from typing import Optional, Any, Dict, Union

class State:
    def __init__(self, name: str):
        self.name = name
    def __repr__(self):
        return f"State('{self.name}')"

class StatesGroup:
    pass

class MemoryStorage:
    def __init__(self):
        self.data: Dict[int, Dict[str, Any]] = {}

    async def set_state(self, user_id: int, state: Optional[str]):
        if user_id not in self.data:
            self.data[user_id] = {"state": None, "data": {}}
        self.data[user_id]["state"] = state

    async def get_state(self, user_id: int) -> Optional[str]:
        return self.data.get(user_id, {}).get("state")

    async def set_data(self, user_id: int, data: Dict):
        if user_id not in self.data:
            self.data[user_id] = {"state": None, "data": {}}
        self.data[user_id]["data"] = data

    async def get_data(self, user_id: int) -> Dict:
        return self.data.get(user_id, {}).get("data", {})

    async def clear(self, user_id: int):
        if user_id in self.data:
            self.data[user_id] = {"state": None, "data": {}}

class FSMContext:
    def __init__(self, storage: MemoryStorage, user_id: int):
        self.storage = storage
        self.user_id = user_id

    async def set_state(self, state: Optional[Union[str, State]]):
        state_val = state.name if isinstance(state, State) else state
        await self.storage.set_state(self.user_id, state_val)

    async def get_state(self) -> Optional[str]:
        return await self.storage.get_state(self.user_id)

    async def set_data(self, data: Dict):
        await self.storage.set_data(self.user_id, data)

    async def update_data(self, **kwargs):
        data = await self.get_data()
        data.update(kwargs)
        await self.set_data(data)

    async def get_data(self) -> Dict:
        return await self.storage.get_data(self.user_id)

    async def clear(self):
        await self.storage.clear(self.user_id)