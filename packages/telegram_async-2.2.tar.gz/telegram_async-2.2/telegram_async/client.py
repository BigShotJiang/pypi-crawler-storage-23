import aiohttp
from typing import Optional, Dict, Any, Union, List
from .types import Update


class TelegramClient:
    """Klient API Telegram"""

    def __init__(self, token: str):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{token}"
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def _request(self, method: str, data: Dict[str, Any]) -> Dict:
        """Wykonuje zapytanie do API Telegram"""
        session = await self._get_session()
        try:
            async with session.post(f"{self.base_url}/{method}", json=data) as resp:
                result = await resp.json()
                if not result.get('ok'):
                    error_desc = result.get('description', 'Unknown error')
                    raise Exception(f"Telegram API error: {error_desc}")
                return result.get('result', {})
        except aiohttp.ClientError as e:
            raise Exception(f"HTTP error: {e}")

    async def get_updates(
            self,
            offset: Optional[int] = None,
            limit: int = 100,
            timeout: int = 0
    ) -> List[Dict]:
        """
        Pobiera aktualizacje z Telegram API

        Args:
            offset: Identyfikator pierwszej aktualizacji do pobrania
            limit: Maksymalna liczba aktualizacji (1-100)
            timeout: Timeout w sekundach dla long polling

        Returns:
            Lista aktualizacji
        """
        data = {
            'offset': offset,
            'limit': limit,
            'timeout': timeout
        }
        # Usuń None wartości
        data = {k: v for k, v in data.items() if v is not None}

        return await self._request('getUpdates', data)

    async def send_message(
            self,
            chat_id: Union[int, str],
            text: str,
            parse_mode: Optional[str] = None,
            reply_markup: Optional[Dict] = None
    ) -> Dict:
        """Wysyła wiadomość"""
        data = {
            'chat_id': chat_id,
            'text': text
        }
        if parse_mode:
            data['parse_mode'] = parse_mode
        if reply_markup:
            data['reply_markup'] = reply_markup

        return await self._request('sendMessage', data)

    async def answer_callback_query(
            self,
            callback_query_id: str,
            text: Optional[str] = None,
            show_alert: bool = False
    ) -> Dict:
        """Odpowiada na callback query"""
        data = {
            'callback_query_id': callback_query_id
        }
        if text:
            data['text'] = text
            data['show_alert'] = show_alert

        return await self._request('answerCallbackQuery', data)

    async def edit_message_text(
            self,
            text: str,
            chat_id: Optional[Union[int, str]] = None,
            message_id: Optional[int] = None,
            inline_message_id: Optional[str] = None,
            reply_markup: Optional[Dict] = None
    ) -> Dict:
        """Edytuje wiadomość"""
        data = {'text': text}

        if chat_id and message_id:
            data['chat_id'] = chat_id
            data['message_id'] = message_id
        elif inline_message_id:
            data['inline_message_id'] = inline_message_id

        if reply_markup:
            data['reply_markup'] = reply_markup

        return await self._request('editMessageText', data)

    async def close(self):
        """Zamyka sesję"""
        if self._session and not self._session.closed:
            await self._session.close()