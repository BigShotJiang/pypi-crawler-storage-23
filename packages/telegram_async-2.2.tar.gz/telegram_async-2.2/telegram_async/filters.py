from typing import Union, Optional
from .fsm import State


def state(state_value: Optional[Union[str, State, list]]):
    """Filtr sprawdzający stan użytkownika"""

    async def filter_func(obj):
        # Dispatcher musi wstrzyknąć fsm do contextu,
        # ale filtr otrzymuje zazwyczaj Message lub CallbackQuery.
        # W tej uproszczonej wersji sprawdzamy czy stan się zgadza.
        from .fsm import MemoryStorage
        # Uwaga: To wymaga dostępu do storage'u.
        # W profesjonalnych frameworkach filtr ma dostęp do middleware.
        return True  # Logika filtra zostanie obsłużona w dispatcherze dla uproszczenia

    # Dodajemy atrybut, żeby dispatcher wiedział, że to filtr stanu
    filter_func._state_filter = state_value
    return filter_func


def Command(name: str):
    async def filter_func(message):
        return message.text and message.text.startswith(f"/{name}")

    return filter_func