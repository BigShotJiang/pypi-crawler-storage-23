﻿from setuptools import setup, find_packages

setup(
    name="telegram-async",
    version="2.2",
    packages=find_packages(),
    install_requires=["aiohttp>=3.8.0", "rich>=10.0.0"],
    python_requires=">=3.8",
)
