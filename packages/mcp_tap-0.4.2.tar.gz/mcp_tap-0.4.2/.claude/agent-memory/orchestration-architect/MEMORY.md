# Orchestration Architect Memory — mcp-tap

## Project: mcp-tap (MCP meta-server)
- No complex orchestration yet. Fresh project.
