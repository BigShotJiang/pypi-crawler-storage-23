# LLM Integration Architect Memory — mcp-tap

## Project: mcp-tap (MCP meta-server)
- No direct LLM integration. The MCP server is consumed BY LLMs, not calling them.
- Future: project-aware setup may use LLM for stack analysis.
