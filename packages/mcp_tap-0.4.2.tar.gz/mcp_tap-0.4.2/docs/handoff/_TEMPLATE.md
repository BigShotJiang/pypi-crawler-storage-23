# Handoff — [TITULO DA SESSAO]

- **Date**: YYYY-MM-DD HH:MM
- **Session context**: (what was the goal of this session)
- **Context consumed**: ~XX%

## What Was Done

- (list of completed items with file paths)

## Where We Stopped

- **Current issue**: #N — [title]
- **Current branch**: `feature/...`
- **State**: (describe exactly what was in progress, what files were being edited)
- **Tests**: passing / failing / not run

## What To Do Next

1. (first thing to do when resuming)
2. (second thing)
3. (etc.)

## Open Questions / Blockers

- (anything unresolved that needs attention)

## Files Modified This Session

- `path/to/file.py` — what changed
