from mcp_tap import main

main()
