"""Inspector module -- fetch and extract config hints from server documentation."""
