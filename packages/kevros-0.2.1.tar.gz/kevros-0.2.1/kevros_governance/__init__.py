"""
Kevros Governance SDK — Agent-side client for the A2A Governance Gateway.

    pip install kevros

Usage:
    from kevros_governance import GovernanceClient

    client = GovernanceClient(api_key="kvrs_...")

    # Verify an action before executing
    result = client.verify(
        action_type="trade",
        action_payload={"symbol": "AAPL", "shares": 100, "price": 185.50},
        policy_context={"max_values": {"shares": 500, "price": 200.0}},
        agent_id="trading-bot-001",
    )
    print(result.decision)  # ALLOW, CLAMP, or DENY

    # Attest an action after executing
    attestation = client.attest(
        agent_id="trading-bot-001",
        action_description="Executed AAPL buy order",
        action_payload={"symbol": "AAPL", "shares": 100, "filled_price": 185.42},
    )
    print(attestation.hash_curr)  # hash-chained proof
"""

__version__ = "0.2.1"

from .auto_signup import get_or_create_api_key
from .client import GovernanceClient
from .models import (
    AttestResponse,
    BindIntentResponse,
    BundleResponse,
    Decision,
    GatewayHealth,
    IntentSource,
    IntentType,
    OutcomeStatus,
    VerifyOutcomeResponse,
    VerifyResponse,
)

__all__ = [
    "GovernanceClient",
    "get_or_create_api_key",
    "Decision",
    "IntentType",
    "IntentSource",
    "OutcomeStatus",
    "VerifyResponse",
    "AttestResponse",
    "BindIntentResponse",
    "VerifyOutcomeResponse",
    "BundleResponse",
    "GatewayHealth",
]
