"""
VLA - VIGIL Lossless Arithmetic
================================
Zero-error GPU compute for scientific computing.

Usage:
    from simgen import vla

    # Enable globally (patches torch ops)
    vla.enable()

    # Or use directly
    result = vla.sum(tensor)      # Exact sum
    result = vla.matmul(a, b)     # Exact matmul
    result = vla.dot(a, b)        # Exact dot product
"""

import torch
from typing import Optional

# Import from the runtime module
from ..vla_runtime import (
    # Core reductions
    vla_sum, vla_mean, vla_var, vla_std, vla_norm,
    vla_prod, vla_cumsum, vla_logsumexp,
    vla_min, vla_max, vla_argmin, vla_argmax,
    # Matrix ops
    vla_dot, vla_matmul, vla_bmm, vla_linear,
    # Convolution (signal processing)
    vla_conv2d, vla_conv_transpose2d,
    # Einsum
    vla_einsum,
    # Element-wise arithmetic
    vla_add, vla_sub, vla_mul, vla_div, vla_neg, vla_abs,
    vla_pow, vla_clamp, vla_fmod,
    # Transcendental
    vla_exp, vla_log, vla_sqrt, vla_rsqrt,
    # Trigonometric
    vla_sin, vla_cos, vla_tan,
    vla_asin, vla_acos, vla_atan, vla_atan2,
    # Hyperbolic
    vla_sinh, vla_cosh, vla_tanh,
    # Rounding
    vla_floor, vla_ceil, vla_round, vla_trunc,
    # Sign and comparison
    vla_sign, vla_eq, vla_ne, vla_lt, vla_le, vla_gt, vla_ge,
    vla_where,
    # Basic activations
    vla_relu, vla_sigmoid, vla_leaky_relu,
    # Signal processing
    vla_fft, vla_ifft, vla_rfft, vla_irfft,
    # Linear algebra
    vla_trace, vla_det, vla_inv, vla_solve,
    # Loss (general regression)
    vla_mse_loss,
    # Utility
    VLAResult,
    get_backend_info,
)

# Auto-shape module for universal drop-in
from .auto import enable_auto, disable_auto, auto_mode

_enabled = False
_original_ops = {}


# =============================================================================
# Clean API wrappers (remove vla_ prefix)
# =============================================================================

# Core reductions
def sum(x: torch.Tensor, dim: Optional[int] = None, keepdim: bool = False,
        return_vla: bool = False, exact: bool = True) -> torch.Tensor:
    """Exact sum with zero accumulation error."""
    return vla_sum(x, dim=dim, keepdim=keepdim, return_vla=return_vla, exact=exact)

def mean(x: torch.Tensor, dim: Optional[int] = None, keepdim: bool = False) -> torch.Tensor:
    """Exact mean."""
    return vla_mean(x, dim=dim, keepdim=keepdim)

def var(x: torch.Tensor, unbiased: bool = True) -> torch.Tensor:
    """Exact variance."""
    return vla_var(x, unbiased=unbiased)

def std(x: torch.Tensor, unbiased: bool = True) -> torch.Tensor:
    """Exact standard deviation."""
    return vla_std(x, unbiased=unbiased)

def norm(x: torch.Tensor, p: int = 2) -> torch.Tensor:
    """Exact Lp norm."""
    return vla_norm(x, p=p)

def prod(x: torch.Tensor) -> torch.Tensor:
    """Exact product."""
    return vla_prod(x)

def cumsum(x: torch.Tensor, dim: int = 0) -> torch.Tensor:
    """Exact cumulative sum."""
    return vla_cumsum(x)

def logsumexp(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """Numerically stable log-sum-exp."""
    return vla_logsumexp(x)

def min(x: torch.Tensor, dim: Optional[int] = None) -> torch.Tensor:
    """Min reduction."""
    return vla_min(x)

def max(x: torch.Tensor, dim: Optional[int] = None) -> torch.Tensor:
    """Max reduction."""
    return vla_max(x)

# Matrix ops
def dot(a: torch.Tensor, b: torch.Tensor, exact: bool = True) -> torch.Tensor:
    """Exact dot product with zero accumulation error."""
    return vla_dot(a, b, exact=exact)

def matmul(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Matrix multiplication with exact accumulation."""
    return vla_matmul(a, b)

def mm(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Alias for matmul."""
    return vla_matmul(a, b)

def bmm(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Batched matrix multiplication."""
    return vla_bmm(a, b)

def linear(x: torch.Tensor, weight: torch.Tensor, bias: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Linear layer: y = xW^T + b."""
    return vla_linear(x, weight, bias)

# Element-wise arithmetic
def add(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Element-wise addition with error capture."""
    return vla_add(a, b)

def sub(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Element-wise subtraction."""
    return vla_sub(a, b)

def mul(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Element-wise multiplication with error capture."""
    return vla_mul(a, b)

def div(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Element-wise division."""
    return vla_div(a, b)

def neg(x: torch.Tensor) -> torch.Tensor:
    """Element-wise negation."""
    return vla_neg(x)

def abs(x: torch.Tensor) -> torch.Tensor:
    """Element-wise absolute value."""
    return vla_abs(x)

def pow(x: torch.Tensor, exponent) -> torch.Tensor:
    """Element-wise power."""
    return vla_pow(x, exponent)

def clamp(x: torch.Tensor, min_val=None, max_val=None) -> torch.Tensor:
    """Element-wise clamp."""
    return vla_clamp(x, min_val, max_val)

def fmod(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Floating-point modulo."""
    return vla_fmod(x, y)

# Transcendental
def exp(x: torch.Tensor) -> torch.Tensor:
    """Element-wise exp."""
    return vla_exp(x)

def log(x: torch.Tensor) -> torch.Tensor:
    """Element-wise log."""
    return vla_log(x)

def sqrt(x: torch.Tensor) -> torch.Tensor:
    """Element-wise sqrt."""
    return vla_sqrt(x)

def rsqrt(x: torch.Tensor) -> torch.Tensor:
    """Element-wise reciprocal sqrt."""
    return vla_rsqrt(x)

# Trigonometric
def sin(x: torch.Tensor) -> torch.Tensor:
    """Sine function."""
    return vla_sin(x)

def cos(x: torch.Tensor) -> torch.Tensor:
    """Cosine function."""
    return vla_cos(x)

def tan(x: torch.Tensor) -> torch.Tensor:
    """Tangent function."""
    return vla_tan(x)

def asin(x: torch.Tensor) -> torch.Tensor:
    """Inverse sine."""
    return vla_asin(x)

def acos(x: torch.Tensor) -> torch.Tensor:
    """Inverse cosine."""
    return vla_acos(x)

def atan(x: torch.Tensor) -> torch.Tensor:
    """Inverse tangent."""
    return vla_atan(x)

def atan2(y: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
    """Two-argument inverse tangent."""
    return vla_atan2(y, x)

# Hyperbolic
def sinh(x: torch.Tensor) -> torch.Tensor:
    """Hyperbolic sine."""
    return vla_sinh(x)

def cosh(x: torch.Tensor) -> torch.Tensor:
    """Hyperbolic cosine."""
    return vla_cosh(x)

def tanh(x: torch.Tensor) -> torch.Tensor:
    """Hyperbolic tangent."""
    return vla_tanh(x)

# Rounding
def floor(x: torch.Tensor) -> torch.Tensor:
    """Floor function."""
    return vla_floor(x)

def ceil(x: torch.Tensor) -> torch.Tensor:
    """Ceiling function."""
    return vla_ceil(x)

def round(x: torch.Tensor) -> torch.Tensor:
    """Round to nearest integer."""
    return vla_round(x)

def trunc(x: torch.Tensor) -> torch.Tensor:
    """Truncate toward zero."""
    return vla_trunc(x)

# Sign and comparison
def sign(x: torch.Tensor) -> torch.Tensor:
    """Sign function."""
    return vla_sign(x)

def eq(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise equality."""
    return vla_eq(x, y)

def ne(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise not-equal."""
    return vla_ne(x, y)

def lt(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise less-than."""
    return vla_lt(x, y)

def le(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise less-than-or-equal."""
    return vla_le(x, y)

def gt(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise greater-than."""
    return vla_gt(x, y)

def ge(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise greater-than-or-equal."""
    return vla_ge(x, y)

def where(condition: torch.Tensor, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Conditional selection."""
    return vla_where(condition, x, y)

# Basic activations (math functions)
def relu(x: torch.Tensor) -> torch.Tensor:
    """ReLU activation."""
    return vla_relu(x)

def sigmoid(x: torch.Tensor) -> torch.Tensor:
    """Sigmoid function."""
    return vla_sigmoid(x)

def leaky_relu(x: torch.Tensor, negative_slope: float = 0.01) -> torch.Tensor:
    """Leaky ReLU."""
    return vla_leaky_relu(x, negative_slope)

# Signal processing
def fft(x: torch.Tensor, n: Optional[int] = None, dim: int = -1) -> torch.Tensor:
    """1D Fast Fourier Transform."""
    return vla_fft(x, n, dim)

def ifft(x: torch.Tensor, n: Optional[int] = None, dim: int = -1) -> torch.Tensor:
    """1D Inverse FFT."""
    return vla_ifft(x, n, dim)

def rfft(x: torch.Tensor, n: Optional[int] = None, dim: int = -1) -> torch.Tensor:
    """1D Real FFT."""
    return vla_rfft(x, n, dim)

def irfft(x: torch.Tensor, n: Optional[int] = None, dim: int = -1) -> torch.Tensor:
    """1D Inverse Real FFT."""
    return vla_irfft(x, n, dim)

# Convolution
def conv2d(x, weight, bias=None, stride=1, padding=0):
    """2D convolution."""
    return vla_conv2d(x, weight, stride, padding)

def conv_transpose2d(x, weight, bias=None, stride=1, padding=0):
    """2D transposed convolution."""
    return vla_conv_transpose2d(x, weight, stride, padding)

# Linear algebra
def trace(x: torch.Tensor) -> torch.Tensor:
    """Matrix trace."""
    return vla_trace(x)

def det(x: torch.Tensor) -> torch.Tensor:
    """Matrix determinant."""
    return vla_det(x)

def inv(x: torch.Tensor) -> torch.Tensor:
    """Matrix inverse."""
    return vla_inv(x)

def solve(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """Solve linear system Ax = B."""
    return vla_solve(A, B)

# Loss
def mse_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """Exact MSE loss."""
    return vla_mse_loss(pred, target)

# Einsum
def einsum(equation: str, *operands):
    """Einsum with VLA backends where possible."""
    return vla_einsum(equation, *operands)


# =============================================================================
# Global Enable/Disable
# =============================================================================

def enable(mode: str = 'auto'):
    """
    Enable VLA for all PyTorch operations.

    Args:
        mode: 'auto' - critical ops only (recommended)
              'full' - all ops
    """
    global _enabled, _original_ops

    if _enabled:
        return

    # Store originals
    _original_ops['sum'] = torch.sum
    _original_ops['matmul'] = torch.matmul
    _original_ops['mm'] = torch.mm
    _original_ops['bmm'] = torch.bmm

    # Patch (wrapping to match torch API)
    def _vla_sum_wrapper(input, *args, **kwargs):
        if input.is_cuda:
            return sum(input, *args, **kwargs)
        return _original_ops['sum'](input, *args, **kwargs)

    def _vla_matmul_wrapper(input, other):
        if input.is_cuda:
            return matmul(input, other)
        return _original_ops['matmul'](input, other)

    torch.sum = _vla_sum_wrapper
    torch.matmul = _vla_matmul_wrapper
    torch.mm = _vla_matmul_wrapper
    torch.bmm = bmm

    _enabled = True
    print("[VLA] Enabled - GPU ops now use zero-error arithmetic")


def disable():
    """Disable VLA and restore original PyTorch ops."""
    global _enabled, _original_ops

    if not _enabled:
        return

    torch.sum = _original_ops['sum']
    torch.matmul = _original_ops['matmul']
    torch.mm = _original_ops['mm']
    torch.bmm = _original_ops['bmm']

    _enabled = False
    print("[VLA] Disabled - using standard PyTorch ops")


class mode:
    """Context manager for VLA mode."""

    def __enter__(self):
        enable()
        return self

    def __exit__(self, *args):
        disable()


# =============================================================================
# Info
# =============================================================================

def info():
    """Print VLA system info."""
    backend_info = get_backend_info()
    print("=" * 60)
    print("VLA - VIGIL Lossless Arithmetic for Scientific Computing")
    print("=" * 60)
    print(f"Version: {backend_info.get('version', 'unknown')}")
    print(f"Backend: {backend_info.get('backend', 'unknown')}")
    if torch.cuda.is_available():
        print(f"Device: {torch.cuda.get_device_name()}")
        print(f"Architecture: {backend_info.get('native_arch', 'unknown')}")
    print()
    print("Categories:")
    print("  - Core: sum, mean, var, std, norm, dot, matmul")
    print("  - Trig: sin, cos, tan, asin, acos, atan, atan2")
    print("  - Hyper: sinh, cosh, tanh")
    print("  - Signal: fft, ifft, rfft, irfft, conv2d")
    print("  - LinAlg: trace, det, inv, solve")
    print("  - Compare: eq, ne, lt, le, gt, ge, where")
    print()
    print("Precision: Machine epsilon squared (10^-32 vs 10^-16)")
    print("=" * 60)


__all__ = [
    # Core ops
    'sum', 'mean', 'var', 'std', 'norm', 'prod', 'cumsum', 'logsumexp',
    'min', 'max', 'dot', 'matmul', 'mm', 'bmm', 'linear',
    # Arithmetic
    'add', 'sub', 'mul', 'div', 'neg', 'abs', 'pow', 'clamp', 'fmod',
    # Transcendental
    'exp', 'log', 'sqrt', 'rsqrt',
    # Trigonometric
    'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2',
    # Hyperbolic
    'sinh', 'cosh', 'tanh',
    # Rounding
    'floor', 'ceil', 'round', 'trunc',
    # Comparison
    'sign', 'eq', 'ne', 'lt', 'le', 'gt', 'ge', 'where',
    # Activations
    'relu', 'sigmoid', 'leaky_relu',
    # Signal processing
    'fft', 'ifft', 'rfft', 'irfft', 'conv2d', 'conv_transpose2d',
    # Linear algebra
    'trace', 'det', 'inv', 'solve',
    # Loss
    'mse_loss',
    # Einsum
    'einsum',
    # Utilities
    'enable', 'disable', 'mode', 'info',
    'VLAResult',
    # Auto-shape
    'enable_auto', 'disable_auto', 'auto_mode',
]
