#!/usr/bin/python
# coding: utf-8
from audio_transcriber.audio_transcriber_mcp import audio_transcriber_mcp

if __name__ == "__main__":
    audio_transcriber_mcp()
