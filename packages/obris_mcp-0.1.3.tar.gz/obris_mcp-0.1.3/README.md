# Obris MCP Server

An [MCP](https://modelcontextprotocol.io/) server that brings your saved [Obris](https://obris.ai) references into AI conversations on Claude, ChatGPT, Gemini, and any MCP-compatible client.

## Features

- **List projects** — Browse all your Obris projects to find the one you need
- **Pull in references** — Retrieve saved bookmarks, highlights, and notes as context for any conversation
- **Read-only** — The server only reads your data; it never modifies anything in your Obris account

## Setup

### 1. Get your API key

Generate an API key from your [Obris dashboard](https://app.obris.ai/api-keys). Don't have an account? [Sign up](https://app.obris.ai/signup).

### 2. Install and configure

#### Claude Desktop (Recommended)

Build and install the extension bundle:

```bash
npm install -g @anthropic-ai/mcpb
git clone https://github.com/obris-dev/obris-mcp.git
cd obris-mcp
mcpb pack .
```

Then in Claude Desktop, go to **Settings > Extensions > Install Extension** and select the generated `obris-mcp.mcpb` file. You'll be prompted to enter your [API key](https://app.obris.ai/api-keys) during setup.

#### Claude Desktop (Manual config)

Alternatively, add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "obris": {
      "command": "uvx",
      "args": ["obris-mcp"],
      "env": {
        "OBRIS_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

#### Other MCP clients

```bash
# Install
pip install obris-mcp

# Set your API key
export OBRIS_API_KEY=your_api_key_here

# Run
obris-mcp
```

## Tools

| Tool | Description |
|------|-------------|
| `list_projects` | List all your Obris projects |
| `get_project_references` | Get saved references for a specific project |

## Examples

### Example 1: Listing your projects

**Prompt:** "What Obris projects do I have?"

The `list_projects` tool is called and returns:

```
Projects:
- Marketing Strategy (id: proj_abc123)
- Product Roadmap (id: proj_def456)
- Competitive Analysis (id: proj_ghi789)
```

### Example 2: Getting references for a project

**Prompt:** "Pull in my saved references for the Marketing Strategy project."

The `list_projects` tool is called first to find the project ID, then `get_project_references` is called with `project_id: "proj_abc123"`:

```
### How to Build a Content Strategy
Content strategy starts with understanding your audience...
(source: https://example.com/content-strategy)
---
### SEO Best Practices 2025
Focus on search intent rather than keyword density...
(source: https://example.com/seo-guide)
```

### Example 3: Using references as context for a task

**Prompt:** "Using my Competitive Analysis references, summarize the key differentiators of our top 3 competitors."

The `list_projects` tool finds the Competitive Analysis project, then `get_project_references` retrieves all saved references. The AI uses those references as context to generate a structured summary of competitor differentiators based on your saved research.

## Development

```bash
# Clone and install
git clone https://github.com/obris-dev/obris-mcp.git
cd obris-mcp
cp .env.example .env  # Add your API key

# Install with uv
uv sync

# Run locally
uv run obris-mcp
```

## Privacy Policy

This server sends your Obris API key to the Obris API (`api.obris.ai`) to authenticate requests. It retrieves project and reference data from your account. No data is stored locally or sent to any third party.

For the full privacy policy, see [obris.ai/privacy](https://obris.ai/privacy).

## Support

For issues or questions, contact [support@obris.ai](mailto:support@obris.ai) or open an issue on [GitHub](https://github.com/obris-dev/obris-mcp/issues).

## License

MIT
