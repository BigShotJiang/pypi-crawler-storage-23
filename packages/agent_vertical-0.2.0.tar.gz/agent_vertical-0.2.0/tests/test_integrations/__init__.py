"""Tests for the integrations subpackage."""
