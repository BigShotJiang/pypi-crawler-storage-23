"""Test package for domain-complete agent templates (E18.1)."""
from __future__ import annotations
