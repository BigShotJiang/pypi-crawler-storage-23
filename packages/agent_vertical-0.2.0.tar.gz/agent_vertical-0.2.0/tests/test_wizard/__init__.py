"""Tests for the wizard subpackage."""
