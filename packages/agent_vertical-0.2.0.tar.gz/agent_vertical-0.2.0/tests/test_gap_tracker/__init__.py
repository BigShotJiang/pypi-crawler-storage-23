"""Tests for the gap_tracker subpackage."""
