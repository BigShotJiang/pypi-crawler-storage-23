"""Tests for the certification subpackage."""
