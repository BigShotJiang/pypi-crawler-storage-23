"""Spawnpoint — Spawn multi-repo worktree workspaces for feature development."""

try:
    from ._version import __version__
except ImportError:
    __version__ = "0.1.0"
