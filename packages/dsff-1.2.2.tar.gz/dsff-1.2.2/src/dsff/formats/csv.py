# -*- coding: UTF-8 -*-
from .__common__ import *


__all__ = ["from_csv", "is_csv", "to_csv"]


def from_csv(dsff, path=None, exclude=DEFAULT_EXCL):
    """ Populate the DSFF file from a CSV file. """
    dsff.write(path)
    features = {}
    for headers in dsff['data'].rows:
        for header in headers:
            if header.value in exclude:
                continue
            features[header.value] = ""
        break
    dsff.write(features=features)


@text_or_path
def is_csv(text):
    """ Check if the input text or path is a valid CSV. """
    try:
        dialect = csvmod.Sniffer().sniff(text := ensure_str(text))
        csvmod.Sniffer().has_header(text)
        return True
    except (csvmod.Error, UnicodeDecodeError):
        return False


def to_csv(dsff, path=None, text=False):
    """ Create a CSV from the data worksheet, saved as a file or output as a string. """
    with (StringIO() if text else open(path, 'w+')) as f:
        writer = csvmod.writer(f, delimiter=";")
        for row in dsff.data:
            writer.writerow(row)
        if text:
            return f.getvalue()

