"""Rich formatting and output utilities."""

from datetime import datetime
from typing import Any

from rich.console import Console, Group
from rich.table import Table
from rich.text import Text

console = Console()


def print_success(message: str) -> None:
    """Print success message in green."""
    console.print(f"[green]✓[/green] {message}")


def print_error(message: str) -> None:
    """Print error message in red."""
    console.print(f"[red]✗[/red] {message}")


def print_info(message: str) -> None:
    """Print info message."""
    console.print(message)


def print_environments_table(environments: list[dict[str, Any]]) -> None:
    """Print environments in a table."""
    table = Table(title="Environments")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Image Tag", style="blue")
    table.add_column("Created", style="magenta")

    for env in environments:
        table.add_row(
            env.get("id", ""),
            env.get("name", ""),
            env.get("status", ""),
            env.get("image_tag", ""),
            env.get("created_at", ""),
        )

    console.print(table)


def print_scenario_sets_table(scenario_sets: list[dict[str, Any]]) -> None:
    """Print scenario sets in a table."""
    table = Table(title="Scenario Sets")
    table.add_column("ID", style="cyan")
    table.add_column("Title", style="green")
    table.add_column("Scenarios", style="blue")
    table.add_column("Environment", style="yellow")
    table.add_column("Description", style="white")

    for ss in scenario_sets:
        desc = ss.get("description") or ""
        table.add_row(
            ss.get("id", ""),
            ss.get("title", ""),
            str(ss.get("scenario_count", 0)),
            ss.get("environment_id") or "—",
            desc[:50] + "..." if len(desc) > 50 else desc,
        )

    console.print(table)


def print_runs_table(runs: list[dict[str, Any]]) -> None:
    """Print runs in a table."""
    table = Table(title="Runs")
    table.add_column("ID", style="cyan")
    table.add_column("Scenario", style="green")
    table.add_column("Environment", style="blue")
    table.add_column("Status", style="yellow")
    table.add_column("Created", style="magenta")

    for run in runs:
        table.add_row(
            run.get("id", ""),
            run.get("scenario_id", ""),
            run.get("environment_id", ""),
            run.get("status", ""),
            run.get("created_at", ""),
        )

    console.print(table)


def print_run_details(run: dict[str, Any]) -> None:
    """Print detailed run information."""
    console.print("\n[bold]Run Details[/bold]")
    console.print(f"ID: [cyan]{run.get('id', '')}[/cyan]")
    console.print(f"Scenario: [green]{run.get('scenario_id', '')}[/green]")
    console.print(f"Environment: [blue]{run.get('environment_id', '')}[/blue]")
    console.print(f"Status: [yellow]{run.get('status', '')}[/yellow]")
    console.print(f"Concurrency: {run.get('concurrency', '')}")
    console.print(f"Created: [magenta]{run.get('created_at', '')}[/magenta]")
    if run.get("completed_at"):
        console.print(f"Completed: [magenta]{run.get('completed_at', '')}[/magenta]")


def build_run_details_group(run: dict[str, Any]) -> Group:
    """Build a Rich Group renderable for run details with a last_checked timestamp."""
    lines: list[Text] = []
    lines.append(Text.from_markup("\n[bold]Run Details[/bold]"))
    lines.append(Text.from_markup(f"ID: [cyan]{run.get('id', '')}[/cyan]"))
    lines.append(Text.from_markup(f"Scenario: [green]{run.get('scenario_id', '')}[/green]"))
    lines.append(Text.from_markup(f"Environment: [blue]{run.get('environment_id', '')}[/blue]"))
    lines.append(Text.from_markup(f"Status: [yellow]{run.get('status', '')}[/yellow]"))
    lines.append(Text.from_markup(f"Concurrency: {run.get('concurrency', '')}"))
    lines.append(Text.from_markup(f"Created: [magenta]{run.get('created_at', '')}[/magenta]"))
    if run.get("completed_at"):
        lines.append(
            Text.from_markup(f"Completed: [magenta]{run.get('completed_at', '')}[/magenta]")
        )
    now = datetime.now().strftime("%H:%M:%S")
    lines.append(Text.from_markup(f"Last checked: [dim]{now}[/dim]"))
    return Group(*lines)


def print_run_events(events: list[dict[str, Any]]) -> None:
    """Print run events/logs."""
    console.print("\n[bold]Run Events[/bold]\n")
    for event in events:
        timestamp = event.get("timestamp", "")
        event_type = event.get("event_type", "INFO")
        service = event.get("service", "")
        data = event.get("data", {})

        level_color = {
            "INFO": "blue",
            "WARNING": "yellow",
            "ERROR": "red",
            "SUCCESS": "green",
        }.get(event_type.upper(), "white")

        console.print(
            f"[dim]{timestamp}[/dim] [{level_color}]{service}:{event_type}[/{level_color}] {data}"
        )


def print_evaluation_runs_table(eval_runs: list[dict[str, Any]]) -> None:
    """Print evaluation runs in a table."""
    if not eval_runs:
        console.print("No evaluation runs found.")
        return

    table = Table(title="Evaluation Runs")
    table.add_column("ID", style="cyan")
    table.add_column("Grader ID", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Total", style="blue")
    table.add_column("Completed", style="green")
    table.add_column("Failed", style="red")
    table.add_column("Created", style="magenta")

    for er in eval_runs:
        table.add_row(
            er.get("id", ""),
            er.get("grader_id", ""),
            er.get("status", ""),
            str(er.get("total_evaluations", 0)),
            str(er.get("completed_evaluations", 0)),
            str(er.get("failed_evaluations", 0)),
            er.get("created_at", ""),
        )

    console.print(table)


def print_evaluation_run_details(data: dict[str, Any]) -> None:
    """Print detailed evaluation run info."""
    console.print("\n[bold]Evaluation Run[/bold]")
    console.print(f"ID:       [cyan]{data.get('id', '')}[/cyan]")
    console.print(f"Run:      [blue]{data.get('run_id', '')}[/blue]")
    console.print(f"Grader:   [green]{data.get('grader_id', '')}[/green]")
    console.print(f"Status:   [yellow]{data.get('status', '')}[/yellow]")
    console.print(
        f"Progress: {data.get('completed_evaluations', 0)}"
        f"/{data.get('total_evaluations', 0)} completed"
        f", {data.get('failed_evaluations', 0)} failed"
    )
    console.print(f"Created:  [magenta]{data.get('created_at', '')}[/magenta]")

    evaluations = data.get("evaluations", [])
    if evaluations:
        console.print(f"\n[bold]Evaluations ({len(evaluations)})[/bold]")
        table = Table()
        table.add_column("Simulation ID", style="cyan")
        table.add_column("Status", style="yellow")
        table.add_column("Result", style="white", max_width=60)

        for ev in evaluations:
            result_str = ""
            result = ev.get("result")
            if result:
                import json

                result_str = json.dumps(result, indent=None)[:60]
            table.add_row(
                ev.get("simulation_id", ""),
                ev.get("status", ""),
                result_str,
            )

        console.print(table)


def print_graders_table(graders: list[dict[str, Any]]) -> None:
    """Print graders in a table."""
    if not graders:
        console.print("No graders found.")
        return

    table = Table(title="Graders")
    table.add_column("ID", style="cyan")
    table.add_column("Environment", style="blue")
    table.add_column("Scenario Set", style="green")
    table.add_column("Tags", style="yellow")
    table.add_column("Created", style="magenta")

    for g in graders:
        tags = g.get("tags") or []
        table.add_row(
            g.get("id", ""),
            g.get("environment_id", ""),
            g.get("scenario_set_id") or "global",
            ", ".join(tags) if tags else "",
            g.get("created_at", ""),
        )

    console.print(table)
