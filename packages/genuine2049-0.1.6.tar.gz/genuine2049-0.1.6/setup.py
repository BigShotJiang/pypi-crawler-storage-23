from setuptools import setup, find_packages

setup(
    name="genuine2049",
    version="0.1.6", 
    author="Ghalib",
    description="A futuristic GUI framework inspired by 2049",
    # هذا السطر هو الأهم: يبحث عن المجلدات التي تحتوي على __init__.py
    packages=find_packages(), 
    # حذفنا py_modules لأننا نستخدم packages
    install_requires=[
        "pywebview",
    ],
    python_requires='>=3.6',
    include_package_data=True, # لضمان تضمين أي ملفات HTML أو CSS مستقبلاً
)