# Palette "Dark Research"
QUINK_COLORS = {
    "bg_figure": "#0E0D0D",
    "bg_axes": "#0C0C0C",
    "dark_green": "#1B5E63",
    "fancy_pink": "#E5A4C2",
}

PLOT_DEFAULTS = {
    "figsize": (8, 6),
    "dpi": 100,
}