# quink/viz/core.py
import matplotlib.pyplot as plt
from .config import QUINK_COLORS

def apply_quink_theme():
    """Apply dark research style"""
    plt.style.use("dark_background")
    plt.rcParams.update({
        'figure.facecolor': QUINK_COLORS["bg_figure"],
        'axes.facecolor': QUINK_COLORS["bg_axes"],
    })


def quink_setup(figsize=(8, 6), **kwargs):
    """
    Create a standard baseline for plots
    """
    apply_quink_theme()
    
    fig, ax = plt.subplots(
        figsize=figsize,
        **kwargs
    )

    ax.grid(
        linestyle=":",
        zorder=0,
        alpha=0.3
    )
    
    return fig, ax
