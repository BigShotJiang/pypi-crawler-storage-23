# quink

<p align="center">
<img src="https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python">
<img src="https://img.shields.io/badge/NumPy-013243?style=for-the-badge&logo=numpy&logoColor=white" alt="NumPy">
<img src="https://img.shields.io/badge/SciPy-8CAAE6?style=for-the-badge&logo=scipy&logoColor=white" alt="SciPy">
<img src="https://img.shields.io/badge/Matplotlib-ffffff?style=for-the-badge&logo=plotly&logoColor=black" alt="Matplotlib">
</p>

<p align="center">
  <i>
    quink is a specialized Python visualization library designed for quantitative research. It bridges the gap between raw financial data and publication-ready charts, providing a "dark-research" aesthetic out of the box.
  </i>
</p>

### 📦 Installation (PyPI Package)
------------
Install the package from **PyPI**:

```bash
pip install quink
```

### 🪪 License
------------
MIT © 2025 — Developed with ❤️ by Lorenzo Santarsieri
