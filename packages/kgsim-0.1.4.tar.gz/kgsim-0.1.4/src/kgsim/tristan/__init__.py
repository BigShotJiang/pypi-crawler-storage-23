from kgsim.tristan.tristan import Tristan, tristan_loader
from kgsim.tristan.kappa import KappaSim