These examples demonstate case studies with examples.




* example_1
    source mesh:
    raster file:
    configuration:

* example_2
    source mesh:
    raster file:
    configuration:

* example_3
    source mesh:
    raster file:
    configuration:

* example_4
    source mesh:
    raster file:
    configuration:

* example_5
    source mesh:
    raster file:
    configuration:

* example_6
    source mesh:
    raster file:
    configuration: