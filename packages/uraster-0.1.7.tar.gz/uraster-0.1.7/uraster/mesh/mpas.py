def convert_mpas_mesh(sFilename_mpas_mesh_netcdf, sFilename_out=None):
    return


def convert_back_to_mpas_mesh(sFilename_in, sFilename_out):
    return
