
$env:ENABLE_TOOL_SEARCH = "true"

claude