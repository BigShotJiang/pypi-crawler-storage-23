# [PROJECT NAME] 开发指南

由所有功能计划自动生成。最后更新：[DATE]

## 当前使用技术

[EXTRACTED FROM ALL PLAN.MD FILES]

## 项目结构

```text
[ACTUAL STRUCTURE FROM PLANS]
```

## 命令

[ONLY COMMANDS FOR ACTIVE TECHNOLOGIES]

## 代码风格

[LANGUAGE-SPECIFIC, ONLY FOR LANGUAGES IN USE]

## 最近变更

[LAST 3 FEATURES AND WHAT THEY ADDED]

<!-- 手动补充开始 -->
<!-- 手动补充结束 -->
