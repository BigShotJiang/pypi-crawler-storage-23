import asyncio
import logging
import os
from typing import Callable, cast

import pytest
import sanic_testing
import sanic_testing.testing
from nacl.public import PrivateKey
from websockets.exceptions import ConnectionClosedError, ConnectionClosedOK

from hetu.endpoint.definer import EndpointDefines
from hetu.safelogging.default import DEFAULT_LOGGING_CONFIG
from hetu.server import pipeline, worker_main
from hetu.system import SystemClusters

logger = logging.getLogger("HeTu.root")
logger.setLevel(logging.DEBUG)
assert logging.lastResort
logging.lastResort.setLevel(logging.DEBUG)


@pytest.fixture
def setup_websocket_proxy():
    # 设置ws测试routine方法

    async def websocket_proxy(url, *args, **kwargs):
        mimic = kwargs.pop("mimic", None)
        from websockets.legacy.client import connect

        class ProxyForWebsocketProxy:
            def __init__(self):
                self.wss = []

            async def close(self):
                [await ws.close() for ws in self.wss]

        ws_proxy = sanic_testing.websocket.WebsocketProxy(ProxyForWebsocketProxy())  # type: ignore

        async def new_connection():
            ws = await connect(url, *args, **kwargs)
            ws_proxy.ws.wss.append(ws)

            do_send = ws.send
            do_recv = ws.recv

            client_pipe = pipeline.MessagePipeline()
            client_pipe.add_layer(pipeline.JSONBinaryLayer())
            client_pipe.add_layer(pipeline.ZlibLayer())
            crypto_layer = pipeline.CryptoLayer()
            client_pipe.add_layer(crypto_layer)
            pipe_ctx = None
            print("客户端pipe", id(crypto_layer))

            async def handshake():
                nonlocal pipe_ctx
                # 生成密钥对
                private_key = PrivateKey.generate()
                public_key = private_key.public_key
                handshake_msg = [b""] * client_pipe.num_handshake_layers
                handshake_msg[-1] = public_key.encode()
                # 握手
                await do_send(client_pipe.encode(None, handshake_msg))
                data = cast(bytes, await do_recv())
                message = client_pipe.decode(None, data)
                assert type(message) is list
                ctx, msg = client_pipe.handshake(message)
                ctx[-1] = crypto_layer.client_handshake(
                    private_key.encode(), message[-1]
                )
                pipe_ctx = ctx

            async def send(data):
                logger.debug(f"> Sent: {data} [{len(repr(data))} bytes]")
                ws_proxy.client_sent.append(data)
                await do_send(client_pipe.encode(pipe_ctx, data))

            async def recv():
                data = cast(bytes, await do_recv())
                message = client_pipe.decode(pipe_ctx, data)
                logger.debug(f"< Received: {message} [{len(repr(message))} bytes]")
                ws_proxy.client_received.append(message)
                return message

            def clear_recv():
                ws_proxy.client_received.clear()

            await handshake()

            ws.send = send  # type: ignore
            ws.recv = recv  # type: ignore
            ws.clear_recv = clear_recv  # type: ignore

            return ws

        if mimic:
            mimic: Callable
            try:
                await mimic(new_connection)
            except ConnectionClosedOK:
                pass

        return ws_proxy

    sanic_testing.testing.websocket_proxy = websocket_proxy


@pytest.fixture
def test_server(setup_websocket_proxy, ses_redis_service):
    SystemClusters()._clear()
    EndpointDefines()._clear()
    import re

    match = re.match(r"redis://127\.0\.0\.1:(\d+)/0", ses_redis_service[0])
    assert match
    port = match.group(1)

    app_file = os.path.join(os.path.dirname(__file__), "app.py")
    logging_cfg = DEFAULT_LOGGING_CONFIG
    logging_cfg["loggers"]["HeTu.replay"]["level"] = logging.DEBUG
    server = worker_main(
        "Hetu-test",
        {
            "APP_FILE": app_file,
            "NAMESPACE": "pytest",
            "INSTANCES": ["pytest_1"],
            "LISTEN": f"0.0.0.0:874",
            "PACKET_LAYERS": [
                {"type": "jsonb"},
                {"type": "zlib"},
                {"type": "crypto"},
            ],
            "BACKENDS": {
                "Redis": {
                    "type": "Redis",
                    "master": f"redis://127.0.0.1:{port}/0",
                }
            },
            "CLIENT_SEND_LIMITS": [[10, 1], [27, 5], [100, 50], [300, 300]],
            "LOGGING": logging_cfg,
            "DEBUG": True,
            "WORKER_NUM": 4,
            "ACCESS_LOG": False,
        },
    )

    yield server

    server.stop()


def test_websocket_started(test_server):
    # 测试服务器是否正常启动
    # 这行future出现异常是正常的，因为下面的请求很快就关闭了
    request, response = test_server.test_client.get("/")
    assert request.method.lower() == "get"
    assert "Powered by HeTu" in response.body.decode()
    assert response.status == 200
    # 因为上面get("/")会启动future线程，也因此启动了redis，所以要切换下connection_pool
    # app.ctx.default_backend.reset_connection_pool() 优化了process，不再需要


@pytest.mark.timeout(20)
def test_websocket_call_system(test_server):
    # 测试call和结果
    async def normal_routine(connect):
        client1 = await connect()
        await client1.send(["rpc", "login", 1])
        await client1.recv()

        await client1.send(["sub", "RLSComp", "range", "owner", 1, 999])
        await client1.send(["sub", "IndexComp1", "range", "owner", 1, 999])
        await client1.recv()
        await client1.recv()

        await client1.send(["rpc", "add_rls_comp_value", 1])
        await client1.recv()  # 首次sub这里会卡至少0.5s等待连接
        await client1.recv()

        await client1.send(["rpc", "login", 2])  # 测试重复登录应该无效
        await client1.recv()

        # 正式开始接受sub消息
        await client1.send(["rpc", "add_rls_comp_value", 1])
        await client1.recv()
        await client1.recv()

        # 模拟其他用户修改了用户1订阅的数据
        client2 = await connect()
        await client2.send(["rpc", "login", 2])
        # 这个是rls数据，client1不会收到
        await client2.send(["rpc", "add_rls_comp_value", 9])
        # 这个client1应该收到
        await client2.send(["rpc", "create_row", 2, 9.1, "1"])
        await asyncio.sleep(0.1)

        await client1.recv()  # 因为客户端2并没订阅，测试用户1是否收到

    _, response1 = test_server.test_client.websocket(
        "/hetu/pytest_1", mimic=normal_routine
    )
    # print(response1.client_received)
    # 测试add_rls_comp_value调用了2次
    id1 = next(iter(response1.client_received[4][2].keys()))
    assert response1.client_received[4][2][id1] == {
        "id": int(id1),
        "owner": 1,
        "value": 101,
    }
    assert response1.client_received[7][2][id1] == {
        "id": int(id1),
        "owner": 1,
        "value": 102,
    }

    # 测试收到连接2的+9.1
    id2 = next(iter(response1.client_received[8][2].keys()))
    assert response1.client_received[8][2][id2] == {
        "id": int(id2),
        "owner": 2,
        "value": 9.1,
    }


def test_websocket_kick_connect(test_server):
    # 测试踢掉别人的连接
    async def kick_routine(connect):
        client1 = await connect()
        await client1.send(["rpc", "login", 1])
        await client1.send(["rpc", "add_rls_comp_value", 1])
        await asyncio.sleep(0.8)

        client2 = await connect()
        await client2.send(["rpc", "login", 1])
        await client2.send(["rpc", "add_rls_comp_value", 2])
        await asyncio.sleep(1)

        # 虽然上面的client2踢掉了client1，但是client1并不会主动断开连接，
        # 需要调用一次system才能发现自己被踢掉了
        await client1.send(["rpc", "add_rls_comp_value", 3])

        # 测试踢出成功
        await asyncio.sleep(0.2)
        with pytest.raises(ConnectionClosedError):
            await client1.send(["rpc", "add_rls_comp_value", 4])

    _, response1 = test_server.test_client.websocket(
        "/hetu/pytest_1", mimic=kick_routine
    )
    # 用来确定最后一行执行到了，不然在中途报错会被webserver catch跳过，导致test通过
    assert response1.client_sent[-1] == [
        "rpc",
        "add_rls_comp_value",
        4,
    ], "最后一行没执行到"


def test_call_flooding_lv1_normal(test_server):
    # 测试CLIENT_SEND_LIMITS配置
    # CLIENT_SEND_LIMITS:
    # - [ 10, 1 ]  <---测试该层
    # - [ 27, 5 ]
    # 登录后默认CLIENT_SEND_LIMITS值乘10,所以是100次/秒
    async def normal_routine(connect):
        client1 = await connect()
        for i in range(100):
            await client1.send(["rpc", "login", 1])
            await client1.recv()

    test_server.test_client.websocket("/hetu/pytest_1", mimic=normal_routine)


def test_call_flooding_lv1_flooding(test_server):
    # 因为同时启动2个websocket会报
    # sanic.exceptions.ServerError: Sanic server could not start: [Errno 98] Address already in use.
    # 所以分2个测试，或者可以尝试启动时用随机的port
    async def flooding_routine(connect):
        client1 = await connect()
        with pytest.raises(ConnectionClosedError):
            for i in range(101):
                await client1.send(["rpc", "login", 1])
                await client1.recv()

    test_server.test_client.websocket("/hetu/pytest_1", mimic=flooding_routine)


def test_call_flooding_lv2_normal(test_server):
    # 测试CLIENT_SEND_LIMITS配置
    # CLIENT_SEND_LIMITS:
    # - [ 10, 1 ]
    # - [ 27, 5 ]  <---测试该层
    # 登录后默认CLIENT_SEND_LIMITS值乘10,所以是270次/秒
    async def normal_routine_lv2(connect):
        client1 = await connect()
        for i in range(270):
            await client1.send(["rpc", "login", 1])
            await client1.recv()
            if i == 99:
                await asyncio.sleep(1)

    test_server.test_client.websocket("/hetu/pytest_1", mimic=normal_routine_lv2)


def test_call_flooding_lv2_flooding(test_server):
    async def flooding_routine_lv2(connect):
        client1 = await connect()
        with pytest.raises(ConnectionClosedError):
            for i in range(271):
                await client1.send(["rpc", "login", 1])
                await client1.recv()
                if i == 99:
                    await asyncio.sleep(1)

    test_server.test_client.websocket("/hetu/pytest_1", mimic=flooding_routine_lv2)
