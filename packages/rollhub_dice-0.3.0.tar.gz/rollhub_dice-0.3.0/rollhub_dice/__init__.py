"""Rollhub Dice — Python SDK for the Rollhub Dice Agent API."""

from .client import DiceAgent
from .exceptions import (
    AuthenticationError,
    InsufficientBalanceError,
    InvalidBetError,
    RateLimitError,
    RollhubError,
    ServerError,
    VerificationError,
)
from .models import Balance, Bet, BetResult, Proof, Registration, VerifyResult
from .verify import compute_roll, verify_bet, verify_server_seed

__version__ = "0.1.0"

__all__ = [
    "DiceAgent",
    "Balance",
    "Bet",
    "BetResult",
    "Proof",
    "Registration",
    "VerifyResult",
    "RollhubError",
    "AuthenticationError",
    "InsufficientBalanceError",
    "InvalidBetError",
    "RateLimitError",
    "ServerError",
    "VerificationError",
    "compute_roll",
    "verify_bet",
    "verify_server_seed",
    "__version__",
]
