from .new_rmsfact import _new_rmsfact

rmsfact = _new_rmsfact()

print(rmsfact())
