# Release History

## 1.0.0b2 (2026-02-12)

### Other Changes

- Python 2.7 is no longer supported. Please use Python version 3.7 or later.
- This package has been deprecated and will no longer be maintained after 10-01-2025. This package will only receive security fixes until 10-01-2025.

## 1.0.0b1 (2021-11-12)

### Features Added

- Initial release with support for authenticating with Mixed Reality services.
