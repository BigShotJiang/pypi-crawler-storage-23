import os

from dotenv import load_dotenv
import click


load_dotenv("app/.cfg")


@click.group()
def cli():
    """Global CLI Group"""
    pass


import app.src.presentation.routers.auth
import app.src.presentation.routers.task


def main():
    cli(prog_name="esdd")


if __name__ == "__main__":
    main()
