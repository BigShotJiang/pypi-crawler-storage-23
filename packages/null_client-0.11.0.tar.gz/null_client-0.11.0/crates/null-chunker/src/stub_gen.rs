use pyo3_stub_gen::Result;
use std::fs;
use std::path::Path;

fn main() -> Result<()> {
    let stub = _chunker::stub_info()?;
    stub.generate()?;

    let base = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../python/null_client");

    // Remove the auto-generated __init__.pyi which conflicts with our Python __init__.py
    let init_stub = base.join("__init__.pyi");
    if init_stub.exists() {
        fs::remove_file(&init_stub).ok();
    }

    // Fix ChunkIterator to properly implement Iterator[Chunk] for better type inference
    let chunker_stub = base.join("_chunker/__init__.pyi");
    if chunker_stub.exists() {
        let content = fs::read_to_string(&chunker_stub).unwrap();
        // Make ChunkIterator inherit from Iterator[Chunk] so list() infers list[Chunk]
        let fixed = content
            .replace(
                "class ChunkIterator:",
                "class ChunkIterator(typing.Iterator[Chunk]):",
            )
            // __next__ should return Chunk (StopIteration signals end, not None)
            .replace(
                "def __next__(self) -> typing.Optional[Chunk]:",
                "def __next__(self) -> Chunk:",
            );
        fs::write(&chunker_stub, fixed).unwrap();
    }

    Ok(())
}
