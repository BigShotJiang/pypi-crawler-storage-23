"""WASP2 allele counting module."""
