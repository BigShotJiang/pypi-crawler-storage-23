"""WASP2 mapping bias correction module."""
