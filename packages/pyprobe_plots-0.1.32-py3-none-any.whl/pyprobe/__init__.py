"""PyProbe: Variable probing based debugger for Python DSP debugging."""

__version__ = "0.1.0"
GITHUB_REPO_URL = "https://github.com/your-org/pyprobe"
