"""Allow running any2md as a module: python -m any2md."""

from any2md.cli import main

main()
