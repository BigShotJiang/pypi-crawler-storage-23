"""Convert PDF, DOCX, HTML, and TXT files to LLM-optimized Markdown."""

__version__ = "0.6.0"
