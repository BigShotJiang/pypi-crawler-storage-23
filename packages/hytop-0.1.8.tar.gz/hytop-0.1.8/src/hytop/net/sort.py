from __future__ import annotations


def split_iface_key(iface_key: str) -> tuple[str, str]:
    kind, _, name = iface_key.partition(":")
    return kind, name


def sort_net_keys_grouped(
    monitored_keys: set[tuple[str, str]],
    hosts: list[str],
) -> list[tuple[str, str]]:
    """Default grouped order: Host -> Mode -> NIC."""
    host_rank = {host: idx for idx, host in enumerate(hosts)}
    mode_rank = {"eth": 0, "ib": 1}
    return sorted(
        monitored_keys,
        key=lambda x: (
            host_rank.get(x[0], len(hosts)),
            mode_rank.get(split_iface_key(x[1])[0], 99),
            split_iface_key(x[1])[1],
        ),
    )
