from __future__ import annotations


def sort_gpu_keys_grouped(
    monitored_keys: set[tuple[str, int]],
    hosts: list[str],
) -> list[tuple[str, int]]:
    """Default grouped order: Host -> GPU."""
    host_rank = {host: idx for idx, host in enumerate(hosts)}
    return sorted(
        monitored_keys,
        key=lambda x: (host_rank.get(x[0], len(hosts)), x[1]),
    )
