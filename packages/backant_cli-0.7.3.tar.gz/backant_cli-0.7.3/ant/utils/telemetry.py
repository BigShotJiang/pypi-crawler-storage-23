"""
Opt-in anonymous telemetry for BackAnt CLI.

This module provides privacy-respecting telemetry that:
- Is strictly opt-in (requires explicit user consent)
- Respects DO_NOT_TRACK environment variable
- Never collects PII (no file paths, usernames, IPs, stack traces)
- Uses anonymized device identifiers
- Operates asynchronously and never blocks CLI operations
"""

import atexit
import functools
import hashlib
import json
import os
import time
import uuid
from pathlib import Path
from typing import Callable, Optional

import click

# Lazy import to avoid blocking startup
_posthog = None
_posthog_client = None  # PostHog client instance

# Runtime flag to disable telemetry for current session (--no-telemetry)
_session_telemetry_disabled = False

# Configuration - PostHog key is hardcoded for automatic telemetry
# Users can still opt-out via DO_NOT_TRACK=1 or declining the consent prompt
POSTHOG_API_KEY = os.environ.get(
    "BACKANT_POSTHOG_KEY", "phc_myKzNtyyxG0CUY9IXMKdo6q1ve5kDxVYEddtXrQ0ZNP"
)
POSTHOG_HOST = os.environ.get("BACKANT_POSTHOG_HOST", "https://us.i.posthog.com")
CONFIG_DIR = Path.home() / ".backant"
CONFIG_FILE = CONFIG_DIR / "config.json"

# Salt for hashing (changes per installation for extra privacy)
_HASH_SALT = "backant-cli-telemetry-v1"


def _get_posthog():
    """Lazy load PostHog to avoid blocking startup."""
    global _posthog
    if _posthog is None:
        try:
            import posthog

            _posthog = posthog
        except ImportError:
            return None
    return _posthog


def _get_posthog_client():
    """Get or create PostHog client instance."""
    global _posthog_client
    if _posthog_client is None:
        try:
            from posthog import Posthog

            _posthog_client = Posthog(POSTHOG_API_KEY, host=POSTHOG_HOST)
        except ImportError:
            return None
    return _posthog_client


def _ensure_config_dir() -> None:
    """Ensure the config directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _load_config() -> dict:
    """Load configuration from disk."""
    try:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
    except (json.JSONDecodeError, IOError):
        pass
    return {}


def _save_config(config: dict) -> None:
    """Save configuration to disk."""
    try:
        _ensure_config_dir()
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
    except IOError:
        pass


def _generate_device_id() -> str:
    """Generate a new anonymous device ID."""
    return str(uuid.uuid4())


def _hash_device_id(device_id: str) -> str:
    """Hash the device ID for extra anonymization."""
    return hashlib.sha256(f"{device_id}{_HASH_SALT}".encode()).hexdigest()[:32]


def get_device_id() -> str:
    """Get or create the anonymous device ID."""
    config = _load_config()

    if "device_id" not in config:
        config["device_id"] = _generate_device_id()
        _save_config(config)

    return config["device_id"]


def get_distinct_id() -> str:
    """Get the hashed distinct ID for PostHog."""
    return _hash_device_id(get_device_id())


def is_do_not_track_set() -> bool:
    """Check if DO_NOT_TRACK environment variable is set."""
    dnt = os.environ.get("DO_NOT_TRACK", "").lower()
    return dnt in ("1", "true", "yes")


def set_session_telemetry_disabled(disabled: bool) -> None:
    """Disable telemetry for the current session (--no-telemetry flag)."""
    global _session_telemetry_disabled
    _session_telemetry_disabled = disabled


def is_session_telemetry_disabled() -> bool:
    """Check if telemetry is disabled for the current session."""
    return _session_telemetry_disabled


def is_telemetry_enabled() -> bool:
    """Check if telemetry is enabled (consent given and not disabled)."""
    if is_session_telemetry_disabled():
        return False

    if is_do_not_track_set():
        return False

    config = _load_config()
    return config.get("telemetry_enabled", False)


def has_consent_been_asked() -> bool:
    """Check if user has been asked for telemetry consent."""
    config = _load_config()
    return "telemetry_enabled" in config


def set_telemetry_consent(enabled: bool) -> None:
    """Set the user's telemetry consent."""
    config = _load_config()
    config["telemetry_enabled"] = enabled
    config["consent_timestamp"] = time.time()
    _save_config(config)


def is_first_run() -> bool:
    """Check if this is the first run of the CLI."""
    config = _load_config()
    return not config.get("first_run_completed", False)


def mark_first_run_completed() -> None:
    """Mark that first run has been completed."""
    config = _load_config()
    config["first_run_completed"] = True
    _save_config(config)


def mark_api_generated() -> None:
    """Mark that the first API has been generated."""
    config = _load_config()
    if not config.get("first_api_generated", False):
        config["first_api_generated"] = True
        _save_config(config)
        track_event("api_generated")


def mark_onboarding_completed() -> None:
    """Mark onboarding as completed."""
    config = _load_config()
    if not config.get("onboarding_completed", False):
        config["onboarding_completed"] = True
        _save_config(config)
        track_event("onboarding_completed")


class TelemetryClient:
    """Telemetry client for sending events to PostHog."""

    _instance: Optional["TelemetryClient"] = None
    _initialized: bool = False
    _session_start: float = 0

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def initialize(self) -> bool:
        """Initialize the PostHog client."""
        if self._initialized:
            return True

        if not is_telemetry_enabled():
            return False

        if not POSTHOG_API_KEY:
            return False

        client = _get_posthog_client()
        if client is None:
            return False

        try:
            self._initialized = True
            self._session_start = time.time()

            # Register atexit handler for flushing
            atexit.register(self._flush_on_exit)

            return True
        except Exception:
            return False

    def _flush_on_exit(self) -> None:
        """Flush events on exit and track session duration."""
        if not self._initialized:
            return

        try:
            # Track session duration
            if self._session_start > 0:
                duration = time.time() - self._session_start
                self.capture(
                    "session_duration", {"duration_seconds": round(duration, 2)}
                )

            # Shutdown client (flushes remaining events)
            client = _get_posthog_client()
            if client:
                client.shutdown()
        except Exception:
            pass

    def capture(self, event: str, properties: Optional[dict] = None) -> None:
        """Capture an event."""
        if not self._initialized:
            if not self.initialize():
                return

        if not is_telemetry_enabled():
            return

        client = _get_posthog_client()
        if client is None:
            return

        try:
            safe_properties = properties or {}
            # Add CLI version if available
            try:
                from ant import __version__

                safe_properties["cli_version"] = __version__
            except (ImportError, AttributeError):
                safe_properties["cli_version"] = "unknown"

            client.capture(
                distinct_id=get_distinct_id(), event=event, properties=safe_properties
            )
        except Exception:
            # Silent fail - never block CLI operation
            pass

    def identify(self) -> None:
        """Identify the user (anonymously)."""
        if not self._initialized:
            return

        client = _get_posthog_client()
        if client is None:
            return

        try:
            client.identify(
                distinct_id=get_distinct_id(),
                properties={
                    "platform": os.name,
                },
            )
        except Exception:
            pass


# Global client instance
_client = TelemetryClient()


def track_event(event: str, properties: Optional[dict] = None) -> None:
    """Track an event (convenience function)."""
    _client.capture(event, properties)


def track_cli_installed() -> None:
    """Track CLI installation (first run)."""
    if is_first_run():
        track_event("cli_installed")
        mark_first_run_completed()


def track_command_executed(command_name: str, success: bool) -> None:
    """Track command execution."""
    track_event("command_executed", {"command": command_name, "success": success})


def track_error(error_type: str) -> None:
    """Track an error occurrence (type only, no details)."""
    track_event("error_occurred", {"error_type": error_type})


def initialize_telemetry() -> None:
    """Initialize telemetry if enabled."""
    _client.initialize()


def get_privacy_info() -> str:
    """Get human-readable privacy information."""
    config = _load_config()
    enabled = is_telemetry_enabled()
    dnt = is_do_not_track_set()

    lines = [
        "BackAnt CLI Telemetry Information",
        "=" * 35,
        "",
        f"Telemetry enabled: {'Yes' if enabled else 'No'}",
        f"DO_NOT_TRACK env var: {'Set (telemetry disabled)' if dnt else 'Not set'}",
        "",
        "What we collect (when enabled):",
        "  - Command names (e.g., 'generate api')",
        "  - Success/failure status",
        "  - Anonymous device ID (hashed)",
        "  - CLI version",
        "  - Session duration",
        "",
        "What we NEVER collect:",
        "  - File paths or project names",
        "  - Usernames or email addresses",
        "  - IP addresses",
        "  - Stack traces or error messages",
        "  - Any personally identifiable information",
        "",
        "How to change your preference:",
        "  - Set DO_NOT_TRACK=1 environment variable",
        "  - Or delete ~/.backant/config.json to reset",
        "",
        f"Config file: {CONFIG_FILE}",
    ]

    if config.get("consent_timestamp"):
        from datetime import datetime

        ts = datetime.fromtimestamp(config["consent_timestamp"])
        lines.append(f"Consent given: {ts.strftime('%Y-%m-%d %H:%M:%S')}")

    return "\n".join(lines)


def prompt_for_consent() -> bool:
    """Prompt user for telemetry consent on first run.

    Returns True if consent was given, False otherwise.
    """
    # Don't prompt if DO_NOT_TRACK is set
    if is_do_not_track_set():
        set_telemetry_consent(False)
        return False

    # Don't prompt if already asked
    if has_consent_been_asked():
        return is_telemetry_enabled()

    try:
        click.echo("")
        click.echo("Help improve BackAnt by sharing anonymous usage data? (y/n)")
        click.echo("(This can be changed later via DO_NOT_TRACK=1 or --privacy flag)")
        response = click.prompt("", type=str, default="n").lower().strip()

        enabled = response in ("y", "yes")
        set_telemetry_consent(enabled)

        if enabled:
            click.echo("Thanks! Anonymous telemetry enabled.")
            track_cli_installed()
        else:
            click.echo("No problem! Telemetry disabled.")

        click.echo("")
        return enabled
    except (click.Abort, EOFError, KeyboardInterrupt):
        # User cancelled - default to disabled
        set_telemetry_consent(False)
        return False


def telemetry_callback(ctx: click.Context, param: click.Parameter, value: bool) -> bool:
    """Click callback for --no-telemetry flag."""
    if value:
        set_session_telemetry_disabled(True)
    return value


def privacy_callback(ctx: click.Context, param: click.Parameter, value: bool) -> None:
    """Click callback for --privacy flag."""
    if value:
        click.echo(get_privacy_info())
        ctx.exit(0)


def with_telemetry(command_name: str) -> Callable:
    """Decorator to wrap Click commands with telemetry tracking.

    Usage:
        @cli.command()
        @with_telemetry("my_command")
        def my_command():
            ...
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Check for first run and prompt for consent if needed
            if not has_consent_been_asked() and not is_session_telemetry_disabled():
                prompt_for_consent()

            # Initialize telemetry
            initialize_telemetry()

            success = True
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                success = False
                # Track error type only, not the full error
                track_error(type(e).__name__)
                raise
            finally:
                track_command_executed(command_name, success)

        return wrapper

    return decorator


def telemetry_group_callback(ctx: click.Context) -> None:
    """Callback for Click group to handle telemetry initialization.

    Call this at the start of the main CLI group.
    """
    # Handle first-run consent prompt
    if not has_consent_been_asked() and not is_session_telemetry_disabled():
        # Only prompt if running interactively (stdin is a TTY)
        import sys

        if sys.stdin.isatty():
            prompt_for_consent()

    # Initialize telemetry
    initialize_telemetry()
