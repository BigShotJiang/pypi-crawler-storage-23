import click
from ant.commands.generate import generate
from ant.utils.telemetry import (
    telemetry_callback,
    privacy_callback,
    telemetry_group_callback,
)


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.option(
    "--report",
    is_flag=True,
    default=False,
    help="Output machine-readable JSON report to stdout",
)
@click.option(
    "--no-telemetry",
    is_flag=True,
    default=False,
    expose_value=False,
    is_eager=True,
    callback=telemetry_callback,
    help="Disable telemetry for this session",
)
@click.option(
    "--privacy",
    is_flag=True,
    default=False,
    expose_value=False,
    is_eager=True,
    callback=privacy_callback,
    help="Show telemetry and privacy information",
)
@click.pass_context
def main(ctx, report):
    """BackAnt CLI - Generate Flask REST API projects.

    A powerful command-line interface to streamline Flask-based REST API development.
    """
    ctx.ensure_object(dict)
    ctx.obj["report"] = report

    # Initialize telemetry (handles first-run consent prompt)
    telemetry_group_callback(ctx)


main.add_command(generate)

if __name__ == "__main__":
    main()
