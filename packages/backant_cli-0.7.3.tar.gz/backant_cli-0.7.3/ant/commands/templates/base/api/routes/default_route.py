from flask import Blueprint, jsonify
from services.default_service import myDefaultService

default_bp = Blueprint("default", __name__, url_prefix="/")


@default_bp.get("")
def default_page():
    response = myDefaultService.get_default()
    return jsonify(response)
