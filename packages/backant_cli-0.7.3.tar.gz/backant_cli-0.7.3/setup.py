from setuptools import setup, find_packages

setup(
    name="backant-cli",
    version="0.7.3",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["click", "pydantic>=2.0", "posthog>=3.0.0"],
    extras_require={
        "dev": [
            "ruff",
            "black",
            "pytest",
        ],
    },
    entry_points={"console_scripts": ["ant=ant.cli:main"]},
    author="Pavel Hegler",
    author_email="business@hegler.tech",
    description="A CLI tool to generate backant backend projects",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/backant/backant-cli",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
