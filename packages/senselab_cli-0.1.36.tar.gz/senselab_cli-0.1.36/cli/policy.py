from __future__ import annotations

from pathlib import Path
from typing import Any

from cli.api import APIError


def find_local_rego_files(policies_path: str) -> list[dict[str, str]]:
    """Find and read all .rego files in the local policies directory."""
    current_dir = Path.cwd()

    # Keep behavior parity with raia-cli: "/foo/bar" means "<cwd>/foo/bar".
    if policies_path.startswith("/"):
        full_policies_path = Path(f"{current_dir}{policies_path}").resolve()
    else:
        candidate = Path(policies_path)
        if candidate.is_absolute():
            full_policies_path = candidate.resolve()
        else:
            full_policies_path = (current_dir / candidate).resolve()

    if not full_policies_path.exists():
        raise APIError(
            f"Policies path not found: {policies_path} (resolved to: {full_policies_path})"
        )
    if not full_policies_path.is_dir():
        raise APIError(f"Policies path is not a directory: {policies_path}")

    policy_files: list[dict[str, str]] = []
    for rego_file in full_policies_path.rglob("*.rego"):
        try:
            content = rego_file.read_text(encoding="utf-8")
        except Exception as e:
            raise APIError(f"Could not read {rego_file}: {e}") from e
        policy_files.append(
            {
                "filename": rego_file.name,
                "file_path": policies_path,
                "content": content,
            }
        )

    return policy_files


def detect_policy_metadata(filename: str) -> dict[str, str]:
    """Detect policy metadata from filename."""
    filename_parts = filename.lower().replace(".rego", "").split("_")
    connector = filename_parts[0] if filename_parts else "*"
    phase = "pre"
    if len(filename_parts) > 1:
        last_part = filename_parts[-1]
        if last_part in {"pre", "post"}:
            phase = last_part
    return {
        "phase": phase,
        "connector": connector,
    }


def get_tool_cred_mappings(policy_files: list[dict[str, str]]) -> dict[str, str]:
    """Extract tool_cred_guid mappings from policy files."""
    mappings: dict[str, str] = {}
    for policy_file in policy_files:
        content = policy_file.get("content", "")
        filename = policy_file.get("filename", "")
        for line in content.splitlines():
            stripped = line.strip()
            if "tool_cred_guid" in stripped and ":=" in stripped:
                parts = stripped.split(":=", 1)
                value = parts[1].strip().strip('"').strip("'")
                if value:
                    mappings[filename] = value
                break
    return mappings


def policy_test_rows(
    policy_files: list[dict[str, str]],
    *,
    repo: str,
    branch: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for policy in policy_files:
        filename = str(policy.get("filename", ""))
        metadata = detect_policy_metadata(filename)
        rows.append(
            {
                "filename": filename,
                "path": str(policy.get("file_path", "")),
                "phase": metadata["phase"],
                "connector": metadata["connector"],
                "repo": repo,
                "branch": branch,
                "size_chars": len(str(policy.get("content", ""))),
            }
        )
    return rows
