import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


DEFAULT_API_URL = "https://prod-backend-api.app.raia.live"
DEFAULT_CONFIG_PATH = Path.home() / ".sense-cli" / "config.json"


@dataclass
class CLIConfig:
    base_url: str = DEFAULT_API_URL
    token: str | None = None
    default_project_guid: str | None = None
    email: str | None = None
    frontend_url: str | None = None
    telemetry_disabled: bool = False
    completion_prompted: bool = False
    lineage_enabled: bool = False
    lineage_mode: str = "metadata-only"
    lineage_last_repo: str | None = None

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "CLIConfig":
        return cls(
            base_url=raw.get("base_url", DEFAULT_API_URL),
            token=raw.get("token"),
            default_project_guid=raw.get("default_project_guid"),
            email=raw.get("email"),
            frontend_url=raw.get("frontend_url"),
            telemetry_disabled=bool(raw.get("telemetry_disabled", False)),
            completion_prompted=bool(raw.get("completion_prompted", False)),
            lineage_enabled=bool(raw.get("lineage_enabled", False)),
            lineage_mode=raw.get("lineage_mode", "metadata-only"),
            lineage_last_repo=raw.get("lineage_last_repo"),
        )


def _ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def get_config_path() -> Path:
    custom = os.getenv("SENSELAB_CONFIG_PATH")
    return Path(custom).expanduser() if custom else DEFAULT_CONFIG_PATH


def load_config() -> CLIConfig:
    path = get_config_path()
    if not path.exists():
        return CLIConfig()

    with path.open("r", encoding="utf-8") as f:
        raw = json.load(f)
    config = CLIConfig.from_dict(raw)

    env_api = os.getenv("SENSELAB_API_URL")
    env_token = os.getenv("SENSELAB_TOKEN")
    if env_api:
        config.base_url = env_api
    if env_token:
        config.token = env_token
    return config


def save_config(config: CLIConfig) -> None:
    path = get_config_path()
    _ensure_parent(path)
    with path.open("w", encoding="utf-8") as f:
        json.dump(asdict(config), f, indent=2, sort_keys=True)

