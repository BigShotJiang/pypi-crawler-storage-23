# SenseLab CLI

SenseLab CLI helps you manage AI agents and run specialist workflows from your terminal.

With this CLI you can:
- authenticate with your SenseLab account
- list your projects, agents, and functions
- chat with orchestrator or specific agents
- execute agent functions/workflows
- discover and connect integrations
- apply agent configuration from YAML
- manage Rego policies for CI/CD enforcement

## Install

### Recommended (pipx)

```bash
pipx install senselab-cli
```

### pip

```bash
pip install senselab-cli
```

## Quick start

1) Login:

```bash
sense-cli login --token "<YOUR_JWT_TOKEN>"
```

2) Check configuration and auth:

```bash
sense-cli config list -o json
```

3) List your project/agents/functions:

```bash
sense-cli projects
sense-cli agent list
sense-cli agent <agent_name_or_id> function --list
```

4) Chat with an agent:

```bash
sense-cli agent <agent_name_or_id> --chat "Summarize current production incidents"
```

or run a specific function on an agent:

```bash
sense-cli agent <agent_name_or_id> --run <function_name_or_id>
```

## Main commands

- `sense-cli login` - authenticate and save token
- `sense-cli logout` - clear local auth/session data
- `sense-cli config list` - show current CLI config + auth status
- `sense-cli projects` - list available project IDs
- `sense-cli agent list` - list available agents
- `sense-cli agent <agent> function --list` - list functions/workflows for a specific agent
- `sense-cli agent <agent> function` - same as above (default list behavior)
- `sense-cli agent <agent> --chat "<prompt>"` - chat with a specific agent
- `sense-cli agent <agent> --run <function>` - execute a function/workflow on a specific agent
- `sense-cli connectors list` - list available connector types
- `sense-cli connectors describe <connector>` - show connector setup requirements
- `sense-cli connectors add <type>` - open connector auth/config flow
- `sense-cli apply -f agent.yaml` - declaratively create/update agent setup
- `sense-cli policy test --repo <repo> --branch <branch> --commit <sha>` - parse local `.rego` files without uploading
- `sense-cli policy sync --repo <repo> --branch <branch> --commit <sha>` - sync local `.rego` files to backend
- `sense-cli policy list` - list project policies
- `sense-cli telemetry on|off` - enable/disable anonymous CLI telemetry
- `sense-cli completion auto --install` - auto-install shell completion

## Configuration

Environment variables:
- `SENSELAB_API_URL` - override API base URL
- `SENSELAB_TOKEN` - override auth token
- `SENSELAB_CONFIG_PATH` - custom config file path
- `BACKEND_URL` - backend base URL for policy sync (basic-auth parity)
- `TOKEN_NAME` - CI token name for policy sync/auto-assignment
- `TOKEN_SECRET` - CI token secret for policy sync/auto-assignment

Default config path:
- `~/.sense-cli/config.json`

## Help

```bash
sense-cli --help
sense-cli <command> --help
```

## CI/CD example (policy sync)

```bash
export BACKEND_URL="https://dev-backend-api.app.raia.live"
export TOKEN_NAME="<ci_token_name>"
export TOKEN_SECRET="<ci_token_secret>"

sense-cli policy test --repo "$GITHUB_SERVER_URL/$GITHUB_REPOSITORY" --branch "$GITHUB_REF_NAME" --commit "$GITHUB_SHA" --path ./raia/policies -o table
sense-cli policy sync --repo "$GITHUB_SERVER_URL/$GITHUB_REPOSITORY" --branch "$GITHUB_REF_NAME" --commit "$GITHUB_SHA" --path ./raia/policies --auto-assignment -o json
sense-cli policy list -o table
```
