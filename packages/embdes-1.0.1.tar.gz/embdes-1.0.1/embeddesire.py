import os, sys, tempfile, shutil, base64, zlib, pickle, logging, io, zipfile
from pathlib import Path
from typing import Dict, Optional
from enum import Enum

__version__ = "1.0.0"
__author__ = "Qarvexium Team"

class LogLevel(Enum):
    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR

logger = logging.getLogger("embeddesire")
logger.addHandler(logging.NullHandler())

def configure_logging(level: LogLevel = LogLevel.WARNING, format_string: Optional[str] = None) -> None:
    handler = logging.StreamHandler()
    if format_string is None:
        format_string = "%(asctime)s - embeddesire - %(levelname)s - %(message)s"
    handler.setFormatter(logging.Formatter(format_string))
    logger.addHandler(handler)
    logger.setLevel(level.value)

class EmbedDesireConfig:
    MAX_FILE_SIZE: int = 100 * 1024 * 1024
    MAX_CACHE_SIZE: int = 500 * 1024 * 1024
    COMPRESSION_LEVEL: int = 6
    PICKLE_PROTOCOL: int = pickle.HIGHEST_PROTOCOL

class EmbedDesireError(Exception): pass
class EmbedError(EmbedDesireError): pass
class ExtractError(EmbedDesireError): pass
class PersistenceError(EmbedDesireError): pass
class ValidationError(EmbedDesireError): pass

_embedded_data: Dict = {}
_runtime_mode: bool = False
_extracted_cache: Dict[str, str] = {}
_cache_stats = {"hits": 0, "misses": 0, "current_size": 0}

def set_runtime_mode(value: bool = True) -> None:
    global _runtime_mode
    _runtime_mode = value
    logger.debug(f"Runtime mode: {value}")

def embed(path: str, id: str, compress: bool = True) -> str:
    try:
        if _runtime_mode:
            logger.debug(f"Runtime mode: skipping embed for {id}")
            return path
        path = os.path.abspath(path)
        if not os.path.exists(path):
            raise EmbedError(f"Path not found: {path}")
        if os.path.isdir(path):
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, 'w') as zf:
                for root, dirs, files in os.walk(path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, path)
                        zf.write(file_path, arcname)
            data = buffer.getvalue()
        else:
            with open(path, 'rb') as f:
                data = f.read()
        if len(data) > EmbedDesireConfig.MAX_FILE_SIZE:
            raise EmbedError(f"File too large")
        encoded = base64.b64encode(data).decode('utf-8')
        _embedded_data[id] = (encoded, compress)
        logger.info(f"Embedded {id}: {len(data)} bytes")
        return path
    except Exception as e:
        logger.error(f"Embed error: {e}")
        raise EmbedError(f"Failed to embed {id}")

def extract(id: str, output_path: Optional[str] = None) -> str:
    try:
        if id in _extracted_cache:
            _cache_stats["hits"] += 1
            return _extracted_cache[id]
        _cache_stats["misses"] += 1
        if id not in _embedded_data:
            raise ExtractError(f"Resource not found: {id}")
        encoded, was_compressed = _embedded_data[id]
        data = base64.b64decode(encoded)
        if was_compressed:
            data = zlib.decompress(data)
        if output_path:
            output_path = os.path.abspath(output_path)
            os.makedirs(output_path, exist_ok=True)
        else:
            output_path = tempfile.mkdtemp(prefix=f"embdes_{id}_")
        try:
            with zipfile.ZipFile(io.BytesIO(data), 'r') as zf:
                zf.extractall(output_path)
        except:
            if not os.path.exists(output_path):
                os.makedirs(output_path)
            file_path = os.path.join(output_path, id)
            with open(file_path, 'wb') as f:
                f.write(data)
        _extracted_cache[id] = output_path
        logger.debug(f"Extracted {id} to {output_path}")
        return output_path
    except Exception as e:
        logger.error(f"Extract error: {e}")
        raise ExtractError(f"Failed to extract {id}")

def save_embedded(file_path: str) -> bool:
    try:
        os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
        with open(file_path, 'wb') as f:
            pickle.dump(_embedded_data, f, protocol=EmbedDesireConfig.PICKLE_PROTOCOL)
        logger.info(f"Saved embedded data to {file_path}")
        return True
    except Exception as e:
        logger.error(f"Save error: {e}")
        raise PersistenceError(f"Save failed")

def load_embedded(file_path: str) -> bool:
    global _embedded_data
    try:
        with open(file_path, 'rb') as f:
            _embedded_data = pickle.load(f)
        logger.info(f"Loaded embedded data from {file_path}")
        return True
    except Exception as e:
        logger.error(f"Load error: {e}")
        raise PersistenceError(f"Load failed")

def clear_cache() -> bool:
    global _extracted_cache, _cache_stats
    try:
        for path in _extracted_cache.values():
            if os.path.exists(path):
                shutil.rmtree(path, ignore_errors=True)
        _extracted_cache.clear()
        _cache_stats = {"hits": 0, "misses": 0, "current_size": 0}
        logger.info("Cache cleared")
        return True
    except Exception as e:
        logger.error(f"Clear error: {e}")
        return False

def get_cache_stats() -> Dict:
    return _cache_stats.copy()

def get_embedded_resources() -> list:
    return list(_embedded_data.keys())

def remove_embedded_resource(id: str) -> bool:
    try:
        if id in _embedded_data:
            del _embedded_data[id]
            if id in _extracted_cache:
                path = _extracted_cache[id]
                if os.path.exists(path):
                    shutil.rmtree(path, ignore_errors=True)
                del _extracted_cache[id]
            logger.info(f"Removed {id}")
            return True
        return False
    except Exception as e:
        logger.error(f"Remove error: {e}")
        return False

EmbedDesireConfig.MAX_FILE_SIZE = int(os.environ.get("EMBEDDESIRE_MAX_FILE_SIZE", EmbedDesireConfig.MAX_FILE_SIZE))
EmbedDesireConfig.MAX_CACHE_SIZE = int(os.environ.get("EMBEDDESIRE_MAX_CACHE_SIZE", EmbedDesireConfig.MAX_CACHE_SIZE))
EmbedDesireConfig.COMPRESSION_LEVEL = int(os.environ.get("EMBEDDESIRE_COMPRESSION_LEVEL", EmbedDesireConfig.COMPRESSION_LEVEL))

__all__ = ["embed", "extract", "set_runtime_mode", "save_embedded", "load_embedded", "clear_cache", "get_cache_stats", "get_embedded_resources", "remove_embedded_resource", "__version__"]
