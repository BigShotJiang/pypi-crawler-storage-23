import os, sys, ast, subprocess, logging, shutil
from pathlib import Path
from typing import List, Optional
from enum import Enum

if os.getcwd() not in sys.path:
    sys.path.insert(0, os.getcwd())

__version__ = "1.0.0"
__author__ = "EmbedDesire Team"

logger = logging.getLogger("embdes")
logger.addHandler(logging.NullHandler())

class LogLevel(Enum):
    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR

def configure_logging(level: LogLevel = LogLevel.INFO) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s - embdes - %(levelname)s - %(message)s"))
    logger.addHandler(handler)
    logger.setLevel(level.value)

class BuildConfig:
    ONE_FILE: bool = True
    WINDOWED: bool = False
    ICON: Optional[str] = None
    OUTPUT_DIR: str = "dist"
    BUILD_DIR: str = "build"

class BuildError(Exception): pass
class ValidationError(BuildError): pass
class ExecutionError(BuildError): pass
class PyInstallerError(BuildError): pass

def _validate_script_path(script_path: str) -> str:
    if not script_path:
        raise ValidationError("Script path cannot be empty")
    abs_path = os.path.abspath(script_path)
    if not os.path.exists(abs_path):
        raise ValidationError(f"Script not found: {script_path}")
    if not os.path.isfile(abs_path):
        raise ValidationError(f"Not a file: {script_path}")
    if not abs_path.endswith(".py"):
        raise ValidationError(f"Must be .py file: {script_path}")
    return abs_path

def _check_pyinstaller_available() -> bool:
    try:
        result = subprocess.run(["pyinstaller", "--version"], capture_output=True, timeout=5)
        return result.returncode == 0
    except:
        return False

def _find_embed_calls(script_path: str) -> List[str]:
    paths = []
    try:
        with open(script_path, "r") as f:
            content = f.read()
        tree = ast.parse(content)
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = getattr(node.func, "id", "")
                if func_name == "embed" and node.args:
                    try:
                        path = ast.literal_eval(node.args[0])
                        if isinstance(path, str):
                            paths.append(path)
                    except: pass
    except Exception as e:
        logger.warning(f"Failed to parse: {e}")
    return paths

class BuildProcess:
    def __init__(self, script_path: str, extra_args: Optional[List[str]] = None):
        self.script_path = _validate_script_path(script_path)
        self.extra_args = extra_args or []
        self.script_name = Path(script_path).stem
        logger.info(f"Build initialized for {script_path}")

    def validate(self) -> bool:
        try:
            logger.info("=" * 50)
            logger.info("EmbedDesire Build Tool v1.0.0")
            logger.info("=" * 50)
            if not _check_pyinstaller_available():
                raise ValidationError("PyInstaller not installed")
            logger.info("PyInstaller: OK")
            paths = _find_embed_calls(self.script_path)
            for path in paths:
                if not os.path.exists(path):
                    raise ValidationError(f"Embedded path not found: {path}")
            logger.info(f"Found {len(paths)} embed() call(s)")
            return True
        except Exception as e:
            logger.error(f"Validation failed: {e}")
            return False

    def execute_script(self) -> bool:
        try:
            logger.info(f"Executing {self.script_path}...")
            result = subprocess.run([sys.executable, self.script_path], capture_output=True, timeout=30)
            if result.returncode != 0:
                logger.warning(f"Script returned: {result.returncode}")
            logger.info("Script execution complete")
            return True
        except Exception as e:
            logger.error(f"Execution error: {e}")
            return False

    def save_embedded_data(self) -> bool:
        try:
            import embeddesire
            output_file = "embedded_data.pkl"
            embeddesire.save_embedded(output_file)
            logger.info(f"Saved embedded data")
            return True
        except Exception as e:
            logger.error(f"Save error: {e}")
            return False

    def build_command(self) -> List[str]:
        cmd = ["pyinstaller"]
        if BuildConfig.ONE_FILE:
            cmd.append("--onefile")
        if BuildConfig.WINDOWED:
            cmd.append("--windowed")
        if BuildConfig.ICON:
            cmd.extend(["--icon", BuildConfig.ICON])
        cmd.extend(["-d", "noarchive"])
        cmd.append(f"--add-data=embedded_data.pkl{os.pathsep}.")
        cmd.extend(self.extra_args)
        cmd.append(self.script_path)
        return cmd

    def run_pyinstaller(self) -> bool:
        try:
            cmd = self.build_command()
            logger.info(f"Running: {' '.join(cmd[:3])}...")
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                logger.error(f"PyInstaller failed")
                if result.stderr:
                    logger.error(result.stderr[:200])
                return False
            logger.info("PyInstaller: OK")
            return True
        except Exception as e:
            logger.error(f"Build error: {e}")
            return False

    def cleanup(self) -> None:
        try:
            for item in ["build", "embedded_data.pkl"]:
                if os.path.exists(item):
                    if os.path.isdir(item):
                        shutil.rmtree(item)
                    else:
                        os.remove(item)
            logger.info("Cleanup complete")
        except Exception as e:
            logger.warning(f"Cleanup error: {e}")

    def build(self) -> bool:
        try:
            if not self.validate():
                return False
            if not self.execute_script():
                return False
            if not self.save_embedded_data():
                return False
            if not self.run_pyinstaller():
                self.cleanup()
                return False
            self.cleanup()
            logger.info(f"Build successful: {BuildConfig.OUTPUT_DIR}/")
            return True
        except Exception as e:
            logger.error(f"Build failed: {e}")
            return False

def main() -> int:
    configure_logging(LogLevel.INFO)
    if len(sys.argv) < 2:
        print(f"EmbedDesire Build Tool v{__version__}")
        print()
        print("Usage: embdes <script.py> [pyinstaller args...]")
        print()
        print("Examples:")
        print("  embdes app.py")
        print("  embdes app.py --onefile")
        print("  embdes app.py --windowed --icon icon.ico")
        print()
        return 1
    try:
        builder = BuildProcess(sys.argv[1], sys.argv[2:])
        success = builder.build()
        return 0 if success else 1
    except Exception as e:
        logger.error(f"Fatal: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
