# vd-dlt-salesforce-schema

Schema and defaults for Salesforce connector.

## Installation

```bash
pip install vd-dlt-salesforce-schema
```

Typically installed as a dependency of vd-dlt-salesforce.
