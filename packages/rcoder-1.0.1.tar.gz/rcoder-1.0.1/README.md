# Rcoder - Remote Code Execution and Management System

## 📋 Project Overview

Rcoder is a powerful remote management system that allows you to directly communicate with remote hosts without a client, making it as simple to use remote hosts as it is to use local ones.

## ✨ Key Features

- **No MCP or skill configuration required**: Directly use by importing in Python
- **HTTPS disguise**: Supports custom ports, enhancing network security
- **Transfer server**: Supports transfer through other servers to solve network restriction issues
- **Batch command execution**: Execute multiple commands at once, improving efficiency
- **Asynchronous operations**: Support for asynchronous command execution without blocking the main thread
- **Monitoring and alerts**: Real-time system status monitoring to detect issues promptly
- **Key authentication**: Based on public-private key mechanism to ensure communication security
- **Local-like usage experience**: Provides wrappers for common commands like `ls`, `cat`, `mkdir`
- **Automatic network scenario detection**: Adapts to network conditions automatically

## 📚 Documentation

### English Documentation
- [Feature Documentation](README_RCODER_EN.md) - Detailed feature descriptions and usage guide
- [Module Documentation](rcoder/README_EN.md) - Module-level usage documentation

### Chinese Documentation
- [功能文档](README_RCODER.md) - 详细功能说明和使用指南
- [模块文档](rcoder/README.md) - 模块级使用文档

## 🚀 Quick Start

### Method 1: Command Line Tool (Recommended)

```bash
# Quick setup wizard
python -m rcoder.cli setup

# Execute command
python -m rcoder.cli run "ls -la"

# View system status
python -m rcoder.cli status

# Execute batch commands
python -m rcoder.cli batch "echo hello" "hostname" "date"
```

### Method 2: Direct Import Usage

```python
# Import module
from rcoder.utils import get_default_remote

# Get default remote host instance
remote = get_default_remote()

# Execute command
result = remote.run("ls -la")
print(result)

# Use convenience methods
print(remote.ls("."))      # List directory
print(remote.cat("file.txt"))  # View file
print(remote.uptime())     # View system uptime
```

## 🔧 Installation

```bash
# Install from PyPI
pip install rcoder

# Clone from GitHub
git clone https://github.com/YKaiXu/rcoder.git
cd rcoder
pip install -e .
```

## 📡 Network Optimization

Rcoder automatically detects network conditions and applies optimal strategies:

- **Low bandwidth**: Enables compression and connection pooling
- **High latency**: Adjusts timeout and retry settings
- **Unstable network**: Enables breakpoint resume and exponential backoff
- **Proxy transfer**: Optimizes routing through transfer servers

## 🔒 Security

- **HTTPS disguise**: Enhances network security and avoids firewall detection
- **Key authentication**: Based on public-private key mechanism
- **Password protection**: Optional password authentication for secure access
- **Connection pooling**: Reduces connection overhead and improves security

## 🛠️ System Requirements

- **Python**: 3.7 or higher
- **Network**: Ability to access remote servers (supports public IP or IPv6)
- **Permissions**: Execution permissions on remote servers

## 📄 License

MIT License

## 🤝 Contribution

Welcome to submit Issues and Pull Requests to improve Rcoder together!

## 📞 Support

- **GitHub Repository**: [https://github.com/YKaiXu/rcoder](https://github.com/YKaiXu/rcoder)
- **Email**: yukaixu@outlook.com

---

**Rcoder - Making remote management simpler!** 🚀