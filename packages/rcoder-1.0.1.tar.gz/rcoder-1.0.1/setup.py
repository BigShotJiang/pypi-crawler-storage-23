#!/usr/bin/env python3
"""
Rcoder 安装配置文件
用于 PyPI 发布
"""

from setuptools import setup, find_packages
import os

# 读取 README 文件
with open(os.path.join(os.path.dirname(__file__), 'README_RCODER.md'), 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    # 包信息
    name="rcoder",
    version="1.0.1",
    description="远程代码执行与管理系统，支持低带宽场景和中转服务器场景",
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    # 作者信息
    author="YuKaiXu",
    author_email="yukaixu@outlook.com",
    url="https://github.com/YKaiXu/rcoder",
    
    # 包结构
    packages=find_packages(),
    package_dir={"rcoder": "rcoder"},
    include_package_data=True,
    
    # 依赖项
    install_requires=[
        "psutil>=5.9.8",
        "python-daemon>=3.0.1"
    ],
    
    # 分类器
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: System :: Systems Administration",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP",
    ],
    
    # Python 版本要求
    python_requires=">=3.7",
    
    # 入口点
    entry_points={
        "console_scripts": [
            "rcoder=rcoder.cli:main",
        ],
    },
    
    # 关键词
    keywords=["remote", "code", "execution", "management", "proxy", "low-bandwidth"],
    
    # 项目URL
    project_urls={
        "Documentation": "https://github.com/YKaiXu/rcoder",
        "Source": "https://github.com/YKaiXu/rcoder",
        "Tracker": "https://github.com/YKaiXu/rcoder/issues",
    },
)
