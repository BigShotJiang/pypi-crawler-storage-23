"""Compatibility shim."""
