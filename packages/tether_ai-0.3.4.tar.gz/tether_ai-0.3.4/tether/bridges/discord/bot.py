"""Compatibility shim: re-exports from agent_tether.discord.bot."""
# ruff: noqa: F401
from agent_tether.discord.bot import DiscordBridge, DiscordConfig
