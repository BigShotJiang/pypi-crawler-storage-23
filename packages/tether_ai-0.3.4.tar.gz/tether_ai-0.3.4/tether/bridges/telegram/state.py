"""Compatibility shim: re-exports from agent_tether.telegram.state."""
# ruff: noqa: F401
from agent_tether.telegram.state import StateManager, TopicMapping
