"""Compatibility shim: re-exports from agent_tether.slack.bot."""
# ruff: noqa: F401
from agent_tether.slack.bot import SlackBridge
