"""Inter-agent communication systems."""
