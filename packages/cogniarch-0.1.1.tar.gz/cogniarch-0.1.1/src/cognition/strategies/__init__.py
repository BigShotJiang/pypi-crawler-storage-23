"""Decision-making strategies for agents."""
