"""Metacognition package — agents that reason about their own reasoning."""
