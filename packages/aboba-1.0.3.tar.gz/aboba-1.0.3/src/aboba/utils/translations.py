from typing import Dict, Literal

Language = Literal["en", "ru"]

TRANSLATIONS: Dict[str, Dict[Language, str]] = {
    "rejections": {"en": "rejections", "ru": "Доля отвержений"},
    "pvalue": {"en": "P-value", "ru": "P-value"},
    "pvalue_distribution": {"en": "pvalue distribution", "ru": "распределение pvalue"},
    "effect_size": {"en": "Effect Size", "ru": "Размер эффекта"},
    "effect_size_distribution": {"en": "Effect Size Distribution", "ru": "Распределение размера эффекта"},
    "frequency": {"en": "Frequency", "ru": "Частота"},
    "proportion": {"en": "Proportion", "ru": "Доля"},
    "iteration_number": {"en": "Iteration number", "ru": "Номер итерации"},
    "observed_effects": {"en": "Observed effects", "ru": "Наблюдаемые эффекты"},
    "mean": {"en": "Mean", "ru": "Среднее"},
    "median": {"en": "Median", "ru": "Медиана"},
    "true_effect": {"en": "True effect", "ru": "Истинный эффект"},
    "bias": {"en": "Bias", "ru": "Смещение"},
    "std": {"en": "Std", "ru": "Ст. откл."},
    "empirical_cdf": {"en": "Empirical CDF", "ru": "ЭФР"},
    "ecdf": {"en": "ECDF", "ru": "Эмп. функ. распределения"},
    "ecdf_of_pvalues": {"en": "ECDF of P-values", "ru": "ЭФР P-value"},
    "effect": {"en": "Effect", "ru": "Эффект"},
    "unknown_column_type": {"en": "Unknown column type", "ru": "Неизвестный тип столбца"},
    "no_effect_size_data": {"en": "No effect size data", "ru": "Нет данных о размере эффекта"},
    "no_pvalues_available": {"en": "No p-values available", "ru": "P-value недоступны"},
    "density": {"en": "Density", "ru": "Плотность"},
    "neither_significant": {"en": "Neither sig.", "ru": "Оба незнач."},
    "both_significant": {"en": "Both sig.", "ru": "Оба значимы"},
    "only_group1": {"en": "Only {}", "ru": "Только {}"},
    "only_group2": {"en": "Only {}", "ru": "Только {}"},
    "power": {"en": "Power", "ru": "Мощность"},
    "power_ci": {"en": "Power CI", "ru": "Дов. интервал мощности"},
    "target_power": {"en": "Target Power", "ru": "Целевая мощность"},
    "significance_level": {"en": "Significance Level", "ru": "Уровень значимости"},
    "power_curve": {"en": "Power Curve", "ru": "График мощности"},
    "power_curve_plot": {"en": "Power Curve", "ru": "График мощности"},
}


def t(key: str, lang: Language = "en") -> str:
    """
    Translate a key to the specified language.
    
    Args:
        key: Translation key
        lang: Target language ('en' or 'ru')
        
    Returns:
        Translated string, or the key itself if not found
    """
    return TRANSLATIONS.get(key, {}).get(lang, key)
