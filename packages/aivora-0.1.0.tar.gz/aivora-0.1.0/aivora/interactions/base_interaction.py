from abc import ABC, abstractmethod

class ModuleBase(ABC):
    @abstractmethod
    def __init__(self):
        ...
    @abstractmethod
    def fit(self, X, y=None):
        ...
    @abstractmethod
    def fit_transform(self, X):
        ...
    @abstractmethod
    def transform(self, X):
        ...