#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
cert_parse 命令单元测试。
"""
from __future__ import annotations

import datetime
import os
import tempfile

import pytest
from click.testing import CliRunner
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from easy_encryption_tool import cert_parse


runner = CliRunner()


def _create_self_signed_cert(tmp_path):
    """创建自签名证书用于测试"""
    key = rsa.generate_private_key(65537, 2048)
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "CN"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Test"),
        x509.NameAttribute(NameOID.COMMON_NAME, "test.example.com"),
    ])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.utcnow())
        .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=365))
        .sign(key, hashes.SHA256())
    )
    cert_pem = cert.public_bytes(serialization.Encoding.PEM)
    path = tmp_path / "test_cert.pem"
    path.write_bytes(cert_pem)
    return str(path)


class TestCertParse:
    """cert-parse 命令测试"""

    def test_parse_pem_cert(self, tmp_path):
        cert_path = _create_self_signed_cert(tmp_path)
        result = runner.invoke(
            cert_parse.parse_x509_cert_file,
            ["-f", cert_path, "-e", "pem"],
        )
        assert result.exit_code == 0
        assert "basic info" in result.output.lower() or "subject" in result.output.lower()

    def test_nonexistent_file_fails(self):
        result = runner.invoke(
            cert_parse.parse_x509_cert_file,
            ["-f", "/nonexistent/cert.pem"],
        )
        assert result.exit_code != 0 or "error" in result.output.lower() or "failed" in result.output.lower()


class TestCertParseHelpers:
    """cert_parse 辅助函数测试"""

    def test_load_cert_data(self, tmp_path):
        cert_path = _create_self_signed_cert(tmp_path)
        data = cert_parse.load_cert_data(cert_path)
        assert isinstance(data, bytes)
        assert b"BEGIN CERTIFICATE" in data

    def test_load_cert_data_too_large_fails(self, tmp_path):
        large_file = tmp_path / "large.pem"
        large_file.write_bytes(b"x" * (1024 * 11))  # > 10KB
        with pytest.raises(ValueError, match="too large"):
            cert_parse.load_cert_data(str(large_file))

    def test_parse_der_cert(self, tmp_path):
        cert_path = _create_self_signed_cert(tmp_path)
        cert_pem = (tmp_path / "test_cert.pem").read_bytes()
        from cryptography.hazmat.primitives import serialization
        from cryptography import x509
        cert = x509.load_pem_x509_certificate(cert_pem)
        cert_der = cert.public_bytes(serialization.Encoding.DER)
        der_path = tmp_path / "test_cert.der"
        der_path.write_bytes(cert_der)
        result = runner.invoke(
            cert_parse.parse_x509_cert_file,
            ["-f", str(der_path), "-e", "der"],
        )
        assert result.exit_code == 0

    def test_parse_cert_extensions(self, tmp_path):
        cert_path = _create_self_signed_cert(tmp_path)
        from cryptography import x509
        from cryptography.hazmat.primitives import serialization
        cert_pem = (tmp_path / "test_cert.pem").read_bytes()
        cert = x509.load_pem_x509_certificate(cert_pem)
        ext = cert.extensions
        ret = cert_parse.parse_cert_extensions(ext)
        assert isinstance(ret, dict)
