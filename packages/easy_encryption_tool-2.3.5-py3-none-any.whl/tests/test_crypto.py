#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
crypto 模块单元测试。
"""
from __future__ import annotations

import pytest

from easy_encryption_tool.crypto import process_key_iv


class TestCryptoModule:
    def test_process_key_iv_import(self):
        key, iv = process_key_iv(
            is_random=False,
            key="k" * 32,
            iv="v" * 16,
            key_len=32,
            iv_len=16,
        )
        assert len(key) == 32
        assert len(iv) == 16
