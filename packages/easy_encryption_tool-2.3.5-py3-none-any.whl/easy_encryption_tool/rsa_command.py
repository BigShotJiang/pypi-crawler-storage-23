#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-02 12:48:05
import base64
import time

import click
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa, utils as asym_utils

from easy_encryption_tool import command_perf, common, shell_completion
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error

rsa_key_size = ["2048", "3072", "4096"]
rsa_encryption_mode = ["oaep", "pkcs1v15"]
rsa_sign_mode = ["pss", "pkcs1v15"]

rsa_hash_map = {
    hashes.SHA1().name: hashes.SHA1,
    hashes.SHA224().name: hashes.SHA224,
    hashes.SHA256().name: hashes.SHA256,
    hashes.SHA384().name: hashes.SHA384,
    hashes.SHA512().name: hashes.SHA512,
}

rsa_digest_size_map = {
    hashes.SHA1().name: hashes.SHA1().digest_size,
    hashes.SHA224().name: hashes.SHA224().digest_size,
    hashes.SHA256().name: hashes.SHA256().digest_size,
    hashes.SHA384().name: hashes.SHA384().digest_size,
    hashes.SHA512().name: hashes.SHA512().digest_size,
}

# CipherHUB mode name mapping (RSAES_OAEP_SHA_256 -> oaep+sha256)
CIPHERHUB_RSA_ENC_MODE_MAP = {
    "RSAES_PKCS1_V1_5": "pkcs1v15",
    "RSAES_OAEP_SHA_1": "oaep",
    "RSAES_OAEP_SHA_224": "oaep",
    "RSAES_OAEP_SHA_256": "oaep",
    "RSAES_OAEP_SHA_384": "oaep",
    "RSAES_OAEP_SHA_512": "oaep",
}
CIPHERHUB_RSA_ENC_HASH_MAP = {
    "RSAES_OAEP_SHA_1": "sha1",
    "RSAES_OAEP_SHA_224": "sha224",
    "RSAES_OAEP_SHA_256": "sha256",
    "RSAES_OAEP_SHA_384": "sha384",
    "RSAES_OAEP_SHA_512": "sha512",
}


@click.group(name="rsa", short_help="RSA encrypt/decrypt and sign/verify")
def rsa_group():
    pass


@click.command(name="generate")
@click.option(
    "-s",
    "--size",
    type=click.Choice(list(rsa_key_size)),
    required=False,
    default="2048",
    show_default=True,
    help="Key size in bits",
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-f",
    "--file-name",
    required=False,
    type=click.STRING,
    default="demo",
    show_default=True,
    help="Output file name prefix for key pair",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    help="Private key password",
)
@click.option(
    "-r",
    "--random-password",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Generate random private key password (32 bytes); omit -p when used",
)
@output_format_options
@command_perf.timing_decorator
def generate_key_pair(
    size: click.STRING,
    encoding: click.STRING,
    file_name: click.STRING,
    password: click.STRING,
    random_password: click.BOOL,
    output_format: str | None,
):
    request_id = create_request_id()
    start = time.perf_counter()

    password, enc = common.private_key_password(random_password, password)

    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=int(size),
    )
    public_key = private_key.public_key()
    private_encoding = private_key.private_bytes(
        encoding=common.encoding_maps[encoding],
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=enc,
    )
    public_encoding = public_key.public_bytes(
        encoding=common.encoding_maps[encoding],
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    ok, public_file, private_file, password_out = common.write_asymmetric_key(
        file_name_prefix=file_name,
        asymmetric_type="rsa",
        encoding_type=encoding,
        is_private_encrypted=(password is not None and len(password) > 0),
        private_password=password,
        public_data=public_encoding,
        private_data=private_encoding,
    )
    if not ok:
        error("rsa generated failed")
        return

    duration_ms = (time.perf_counter() - start) * 1000
    metadata = build_metadata(
        operation="generate",
        algorithm="rsa",
        parameters={"key_size": int(size), "encoding": encoding},
    )
    result_data = {"public_file": public_file, "private_file": private_file}
    if password_out is not None:
        result_data["password"] = password_out
    result = build_result(**result_data)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="public_file")


def combine_if_not_empty(hash_mode: str, mode: str) -> str:
    if len(hash_mode) <= 0:
        return mode
    return "{}-{}".format(mode, hash_mode)


def get_encryption_max_plain_length(
    mode: str, key_length: int, hash_length: int
) -> int:
    """
    OAEP: max plain size = key_len - 2*hash_len - 2 (e.g. 2048-bit RSA + SHA256 = 190 bytes).
    PKCS#1 v1.5: max plain size = key_len - 11 (e.g. 2048-bit RSA = 245 bytes).
    """
    if mode == "oaep":
        return key_length - 2 * hash_length - 2
    if mode == "pkcs1v15":
        return key_length - 11
    pass


@click.command(name="encrypt")
@click.option(
    "-f",
    "--public-key",
    required=True,
    type=click.STRING,
    help="Public key file path",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input: string or base64 (use -e for base64)",
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length in MB (default 1), asymmetric not suitable for long data",
)
@click.option(
    "-m",
    "--mode",
    required=False,
    default="oaep",
    show_default=True,
    type=click.Choice(rsa_encryption_mode),
    help="Encryption padding mode, default oaep",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    default="sha256",
    show_default=True,
    type=click.Choice(list(rsa_hash_map.keys())),
    help="Only applies when -m is oaep",
)
@output_format_options
@command_perf.timing_decorator
def rsa_encrypt(
    public_key: click.STRING,
    encoding: click.STRING,
    input_data: click.STRING,
    is_base64_encoded: click.STRING,
    input_limit: click.INT,
    hash_alg: click.STRING,
    mode: click.STRING,
    output_format: str | None,
):
    request_id = create_request_id()
    start = time.perf_counter()

    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            error(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        error(
            "the data exceeds the maximum bytes limit, limited to:{}Bytes, now:{}Bytes".format(
                input_limit * 1024 * 1024, len(input_raw_bytes)
            )
        )
        return

    pub_key = common.load_public_key(encoding=encoding, file_path=public_key)
    if pub_key is None:
        return
    max_plain_size = get_encryption_max_plain_length(
        mode, pub_key.key_size // 8, rsa_digest_size_map[hash_alg]
    )
    padding_mode = (
        mode if mode == "pkcs1v15" else combine_if_not_empty(hash_alg, mode)
    )
    if len(input_raw_bytes) > max_plain_size:
        error(
            "plain size:{} exceeds max allowed:{} bytes for mode {}".format(
                len(input_raw_bytes),
                max_plain_size,
                combine_if_not_empty(hash_alg, mode),
            )
        )
        return
    cipher = None
    if mode == "oaep":
        rsa_oaep_padding = padding.OAEP(
            mgf=padding.MGF1(algorithm=rsa_hash_map[hash_alg]()),
            algorithm=rsa_hash_map[hash_alg](),
            label=None,
        )
        cipher = pub_key.encrypt(plaintext=input_raw_bytes, padding=rsa_oaep_padding)
    if mode == "pkcs1v15":
        hash_alg = ""
        cipher = pub_key.encrypt(plaintext=input_raw_bytes, padding=padding.PKCS1v15())
    cipher_b64 = base64.b64encode(cipher).decode("utf-8")

    duration_ms = (time.perf_counter() - start) * 1000
    padding_mode = (
        mode if mode == "pkcs1v15" else combine_if_not_empty(hash_alg, mode)
    )
    metadata = build_metadata(
        operation="encrypt",
        algorithm="rsa",
        encoding="base64",
        input_type="binary" if is_base64_encoded else "text",
        input_size=len(input_raw_bytes),
        parameters={
            "key_size": pub_key.key_size,
            "hash_digest_size": rsa_digest_size_map.get(hash_alg, 0),
            "max_plain_size": max_plain_size,
            "padding_mode": padding_mode,
        },
    )
    result = build_result(cipher=cipher_b64)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="cipher")


@click.command(name="decrypt")
@click.option(
    "-f",
    "--private-key",
    required=True,
    type=click.STRING,
    help="Private key file path",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Cipher data, must be base64-encoded",
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-m",
    "--mode",
    required=False,
    default="oaep",
    show_default=True,
    type=click.Choice(rsa_encryption_mode),
    help="Encryption padding mode, default oaep",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    default="sha256",
    show_default=True,
    type=click.Choice(list(rsa_hash_map.keys())),
    help="Only applies when -m is oaep",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="Private key password",
)
@output_format_options
@command_perf.timing_decorator
def rsa_decrypt(
    private_key: click.STRING,
    input_data: click.STRING,
    encoding: click.STRING,
    mode: click.STRING,
    hash_alg: click.STRING,
    password: click.STRING,
    output_format: str | None,
):
    request_id = create_request_id()
    start = time.perf_counter()

    if password is not None and len(password) > 0:
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = None
    plain = None
    try:  # Decode cipher
        input_raw_bytes = common.decode_b64_data(input_data)
    except BaseException as e:
        error(
            "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
        )
        return
    else:
        pri_key = common.load_private_key(
            encoding=encoding, file_path=private_key, password_bytes=password_bytes
        )
        if pri_key is None:
            return
        try:  # Decrypt with private key per encryption mode
            if mode == "oaep":
                rsa_oaep_padding = padding.OAEP(
                    mgf=padding.MGF1(algorithm=rsa_hash_map[hash_alg]()),
                    algorithm=rsa_hash_map[hash_alg](),
                    label=None,
                )
                plain = pri_key.decrypt(input_raw_bytes, rsa_oaep_padding)
            if mode == "pkcs1v15":
                plain = pri_key.decrypt(input_raw_bytes, padding.PKCS1v15())
        except BaseException:
            error(
                "decrypt failed (invalid ciphertext or key/mode mismatch)\nmode: {}".format(
                    combine_if_not_empty(hash_alg, mode)
                )
            )
            return
        else:  # Check if decrypted plaintext is string
            padding_mode = combine_if_not_empty(hash_alg, mode)
            be_str, ret = common.bytes_to_str(plain)

            duration_ms = (time.perf_counter() - start) * 1000
            metadata = build_metadata(
                operation="decrypt",
                algorithm="rsa",
                encoding="utf-8" if be_str else "base64",
                input_type="binary",
                input_size=len(input_raw_bytes),
                parameters={"key_size": pri_key.key_size, "padding_mode": padding_mode},
            )
            result = build_result(plain=ret)
            output = build_output(
                metadata=metadata,
                result=result,
                request_id=request_id,
                duration_ms=duration_ms,
            )
            render(output, mode=resolve_output_format(output_format), primary_key="plain")
            return


@click.command(name="sign")
@click.option(
    "-f",
    "--private-key",
    required=True,
    type=click.STRING,
    help="Private key file path",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-m",
    "--mode",
    required=True,
    default="pss",
    show_default=True,
    type=click.Choice(rsa_sign_mode),
    help="Signature padding mode",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    default="sha256",
    show_default=True,
    type=click.Choice(list(rsa_hash_map.keys())),
    help="Signature hash algorithm",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="Private key password",
)
@click.option(
    "-i", "--input-data", required=True, type=click.STRING, help="Data to sign"
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is pre-computed digest (not raw); must match -a hash-alg length",
)
@output_format_options
@command_perf.timing_decorator
def rsa_sign(
    private_key: click.STRING,
    input_data: click.STRING,
    mode: click.STRING,
    hash_alg: click.STRING,
    password: click.STRING,
    encoding: click.STRING,
    is_base64_encoded: click.BOOL,
    input_is_digest: click.BOOL,
    output_format: str | None,
):
    request_id = create_request_id()
    start = time.perf_counter()

    password_bytes = None
    if password is not None and len(password) > 0:
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = None

    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            error(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    digest_size = rsa_digest_size_map[hash_alg]
    if input_is_digest:
        if len(input_raw_bytes) != digest_size:
            error(
                "input-is-digest mode requires {} bytes ({} digest length), got: {} bytes".format(
                    digest_size, hash_alg, len(input_raw_bytes)
                )
            )
            return

    pri_key = common.load_private_key(
        encoding=encoding, file_path=private_key, password_bytes=password_bytes
    )
    if pri_key is None:
        return
    # Sign with private key per padding mode (raw vs pre-computed digest)
    try:
        signature = b""
        hash_alg_obj = rsa_hash_map[hash_alg]()
        sign_algorithm = asym_utils.Prehashed(hash_alg_obj) if input_is_digest else hash_alg_obj
        if mode == "pss":
            rsa_pss_padding = padding.PSS(
                mgf=padding.MGF1(algorithm=hash_alg_obj), salt_length=padding.PSS.MAX_LENGTH
            )
            signature = pri_key.sign(
                input_raw_bytes,
                rsa_pss_padding,
                sign_algorithm,
            )
        if mode == "pkcs1v15":
            signature = pri_key.sign(
                input_raw_bytes,
                padding.PKCS1v15(),
                sign_algorithm,
            )
    except BaseException as e:
        error(
            "sign failed: {} | mode: {}".format(e, combine_if_not_empty(hash_alg, mode))
        )
        return

    sig_b64 = base64.b64encode(signature).decode("utf-8")
    duration_ms = (time.perf_counter() - start) * 1000
    metadata = build_metadata(
        operation="sign",
        algorithm="rsa",
        encoding="base64",
        input_type="binary" if is_base64_encoded else "text",
        input_size=len(input_raw_bytes),
        parameters={
            "key_size": pri_key.key_size,
            "mode": combine_if_not_empty(hash_alg, mode),
        },
    )
    result = build_result(signature=sig_b64)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="signature")


@click.command(name="verify")
@click.option(
    "-f",
    "--public-key",
    required=True,
    type=click.STRING,
    help="Public key file path",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-m",
    "--mode",
    required=True,
    default="pss",
    show_default=True,
    type=click.Choice(rsa_sign_mode),
    help="Signature padding mode",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    default="sha256",
    show_default=True,
    type=click.Choice(list(rsa_hash_map.keys())),
    help="Signature hash algorithm",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Data to verify (raw or digest, use -d for digest)",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is pre-computed digest (not raw); must match -a hash-alg length",
)
@click.option(
    "-s",
    "--signature",
    required=True,
    type=click.STRING,
    help="Base64-encoded signature",
)
@output_format_options
@command_perf.timing_decorator
def rsa_verify(
    public_key: click.STRING,
    input_data: click.STRING,
    is_base64_encoded: click.BOOL,
    signature: click.STRING,
    mode: click.STRING,
    hash_alg: click.STRING,
    encoding: click.STRING,
    input_is_digest: click.BOOL,
    output_format: str | None,
):
    request_id = create_request_id()
    start = time.perf_counter()

    if not signature or len(signature.strip()) <= 0:
        error("signature cannot be empty")
        return
    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            error(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    digest_size = rsa_digest_size_map[hash_alg]
    if input_is_digest:
        if len(input_raw_bytes) != digest_size:
            error(
                "input-is-digest mode requires {} bytes ({} digest length), got: {} bytes".format(
                    digest_size, hash_alg, len(input_raw_bytes)
                )
            )
            return

    try:
        signature_raw_bytes = common.decode_b64_data(signature)
    except BaseException as e:
        error("invalid b64 encoded signature, decoded failed:{}".format(e))
        return
    if len(signature_raw_bytes) <= 0:
        error("signature is empty after decode")
        return

    pub_key = common.load_public_key(encoding=encoding, file_path=public_key)
    if pub_key is None:
        return
    # Verify with public key (raw vs pre-computed digest)
    hash_alg_obj = rsa_hash_map[hash_alg]()
    verify_algorithm = asym_utils.Prehashed(hash_alg_obj) if input_is_digest else hash_alg_obj
    try:
        if mode == "pss":
            rsa_pss_padding = padding.PSS(
                mgf=padding.MGF1(algorithm=hash_alg_obj), salt_length=padding.PSS.MAX_LENGTH
            )
            pub_key.verify(
                signature_raw_bytes,
                input_raw_bytes,
                rsa_pss_padding,
                verify_algorithm,
            )
        if mode == "pkcs1v15":
            pub_key.verify(
                signature_raw_bytes,
                input_raw_bytes,
                padding.PKCS1v15(),
                verify_algorithm,
            )
    except InvalidSignature as e:
        error(
            "{}\nInvalidSignature!\nkey size:{}\nmode:{}".format(
                "-" * 16, pub_key.key_size, combine_if_not_empty(hash_alg, mode)
            )
        )
        return

    duration_ms = (time.perf_counter() - start) * 1000
    metadata = build_metadata(
        operation="verify",
        algorithm="rsa",
        input_type="binary" if is_base64_encoded else "text",
        input_size=len(input_raw_bytes),
        parameters={
            "key_size": pub_key.key_size,
            "mode": combine_if_not_empty(hash_alg, mode),
        },
    )
    result = build_result(valid=True)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="valid")


if __name__ == "__main__":
    rsa_group.add_command(generate_key_pair)
    rsa_group.add_command(rsa_encrypt)
    rsa_group.add_command(rsa_decrypt)
    rsa_group.add_command(rsa_sign)
    rsa_group.add_command(rsa_verify)
    rsa_group()
