#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
CipherHUB CLI Output Builder.

Builds structured output dict conforming to JSON schema:
  - metadata: operation, algorithm, encoding, input (no secrets)
  - result: raw cryptographic outputs only
  - runtime: request_id, timestamp, duration_ms, optional host/version

Extensible: metadata.parameters and metadata support additionalProperties.
"""
from __future__ import annotations

import os
import socket
import uuid
from datetime import datetime, timezone
from typing import Any

from easy_encryption_tool import __version__


def build_metadata(
    operation: str,
    algorithm: str,
    *,
    encoding: str | None = None,
    input_type: str | None = None,
    input_size: int | None = None,
    parameters: dict[str, Any] | None = None,
    **extra: Any,
) -> dict[str, Any]:
    """
    Build metadata section. Must NOT contain secrets.

    :param operation: encrypt, decrypt, sign, verify, hash, hmac, derive, random
    :param algorithm: e.g. aes-gcm-256, sha256, sm3
    :param encoding: base64, hex, utf-8, binary
    :param input_type: text, file, binary, stdin
    :param input_size: size in bytes
    :param parameters: algorithm-specific (nonce size, tag size, curve name, etc.)
    :param extra: extensible fields (kid, aad, envelope info, compliance tags, etc.)
    """
    meta: dict[str, Any] = {
        "operation": operation,
        "algorithm": algorithm,
    }
    if encoding is not None:
        meta["encoding"] = encoding
    if input_type is not None or input_size is not None:
        meta["input"] = {}
        if input_type is not None:
            meta["input"]["type"] = input_type
        if input_size is not None:
            meta["input"]["size"] = input_size
    if parameters:
        meta["parameters"] = parameters
    meta.update(extra)
    return meta


def build_result(**kwargs: Any) -> dict[str, Any]:
    """
    Build result section. Raw cryptographic outputs only.
    No formatting, labels, prefixes, or decoration.
    Values must be complete and copy-safe.
    """
    return {k: v for k, v in kwargs.items() if v is not None}


def build_runtime(
    request_id: str,
    timestamp: str,
    duration_ms: float,
    *,
    host: str | None = None,
    version: str | None = None,
    **extra: Any,
) -> dict[str, Any]:
    """
    Build runtime section for auditing.

    :param request_id: UUID
    :param timestamp: ISO 8601 with local timezone
    :param duration_ms: duration in milliseconds
    :param host: optional hostname
    :param version: CLI version
    """
    rt: dict[str, Any] = {
        "request_id": request_id,
        "timestamp": timestamp,
        "duration_ms": round(duration_ms, 3),
    }
    if host is not None:
        rt["host"] = host
    if version is not None:
        rt["version"] = version
    rt.update(extra)
    return rt


def create_request_id() -> str:
    """Generate UUID for request tracking."""
    return str(uuid.uuid4())


def create_timestamp() -> str:
    """ISO 8601 timestamp with local timezone."""
    return datetime.now().astimezone().isoformat()


def get_hostname() -> str | None:
    """Optional hostname for auditing."""
    try:
        return socket.gethostname()
    except OSError:
        return None


def get_cli_version() -> str:
    """CLI version string."""
    v = __version__
    return v if str(v).startswith("v") else f"v{v}"


def build_output(
    metadata: dict[str, Any],
    result: dict[str, Any],
    request_id: str,
    duration_ms: float,
    *,
    host: str | None = None,
    version: str | None = None,
) -> dict[str, Any]:
    """
    Assemble full output dict.

    :param metadata: from build_metadata
    :param result: from build_result
    :param request_id: UUID
    :param duration_ms: duration in milliseconds
    """
    runtime = build_runtime(
        request_id=request_id,
        timestamp=create_timestamp(),
        duration_ms=duration_ms,
        host=host or get_hostname(),
        version=version or get_cli_version(),
    )
    return {
        "metadata": metadata,
        "result": result,
        "runtime": runtime,
    }
