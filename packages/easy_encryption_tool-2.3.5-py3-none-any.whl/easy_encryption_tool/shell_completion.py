#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Shell 补全辅助模块：为各子命令提供 tab 补全逻辑。
- 文件路径补全：显式列出匹配的文件/目录，兼容各 shell
- 条件补全：当 -f 指定输入为文件时，-i 才补全文件路径
- 满足实际使用依赖关系
"""
from __future__ import annotations

import os
from pathlib import Path

import click
from click.shell_completion import CompletionItem


def _list_path_completions(
    incomplete: str, dir_okay: bool = True
) -> list[CompletionItem]:
    """
    根据 incomplete 前缀列出匹配的文件和目录，返回 CompletionItem 列表。
    显式实现路径补全，避免依赖 shell 的 _path_files（在部分环境下可能不生效）。
    """
    if not incomplete:
        incomplete = "."
    path = Path(incomplete)
    try:
        if path.exists() and path.is_dir():
            parent = path
            prefix = ""
        else:
            parent = path.parent if path.parent else Path(".")
            prefix = path.name
        if not parent.exists() or not parent.is_dir():
            parent = Path(".")
            prefix = incomplete
        # 保留用户输入的目录前缀（如 ./ 或 subdir/）
        dir_str = str(parent)
        if dir_str in (".", ""):
            dir_prefix = "./" if incomplete.startswith(".") else ""
        else:
            dir_prefix = dir_str.rstrip(os.sep) + os.sep
        items = []
        for p in sorted(parent.iterdir()):
            name = p.name
            if not name.startswith(".") or (prefix and prefix.startswith(".")):
                if not prefix or name.lower().startswith(prefix.lower()):
                    full = dir_prefix + name
                    if p.is_dir():
                        items.append(CompletionItem(full + os.sep, type="dir"))
                    else:
                        items.append(CompletionItem(full, type="file"))
        return items
    except (OSError, PermissionError):
        return []


def complete_file_path(ctx: click.Context, param: click.Parameter, incomplete: str):
    """
    文件路径补全：显式列出匹配的文件和目录。
    用于 -o/--output-file、-f/--public-key、-f/--private-key、-f/--cert-file 等。
    """
    return _list_path_completions(incomplete, dir_okay=True)


def complete_file_path_if_input_is_file(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
    file_flag_param: str = "is_a_file",
):
    """
    条件文件路径补全：仅当 file_flag_param 为 True 时补全文件路径。
    用于 -i/--input-data：当用户已指定 -f（输入为文件）时，才补全文件路径；
    否则 -i 为明文/base64，不补全。
    """
    if ctx.params.get(file_flag_param):
        return _list_path_completions(incomplete, dir_okay=True)
    return []


def complete_dir_path(ctx: click.Context, param: click.Parameter, incomplete: str):
    """目录路径补全"""
    items = _list_path_completions(incomplete, dir_okay=True)
    return [c for c in items if c.type == "dir"]
