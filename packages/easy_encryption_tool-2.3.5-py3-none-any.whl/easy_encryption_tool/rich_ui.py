#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
统一 Rich 命令行输出模块。
提供 success/error/warning/info/hint 等风格化输出，以及 result_table、result_panel 等结构化展示。
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Sequence

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

# 统一主题：子命令、参数、成功、错误、警告、提示 风格一致
EET_THEME = Theme(
    {
        "cmd": "bold cyan",
        "param": "dim cyan",
        "success": "bold green",
        "error": "bold red",
        "warning": "bold yellow",
        "info": "dim white",
        "hint": "italic yellow",
        "key": "bold blue",
        "value": "white",
        "muted": "dim",
    }
)

console = Console(theme=EET_THEME, force_terminal=True)


def echo(text: str = "", **kwargs) -> None:
    """普通输出，兼容 click.echo"""
    console.print(text, **kwargs)


def success(msg: str, **kwargs) -> None:
    """成功信息"""
    console.print(f"[success]✓[/] {msg}", **kwargs)


def error(msg: str, **kwargs) -> None:
    """错误信息"""
    console.print(f"[error]✗[/] {msg}", **kwargs)


def warning(msg: str, **kwargs) -> None:
    """警告信息"""
    console.print(f"[warning]⚠[/] {msg}", **kwargs)


def info(msg: str, **kwargs) -> None:
    """普通信息"""
    console.print(f"[info]ℹ[/] {msg}", **kwargs)


def hint(msg: str, **kwargs) -> None:
    """提示信息"""
    console.print(f"[hint]→[/] {msg}", **kwargs)


def result_table(
    rows: Dict[str, Any],
    title: Optional[str] = None,
    show_header: bool = False,
    expand: bool = False,
    overflow: str = "ellipsis",
) -> None:
    """
    输出 key-value 表格，用于 AES/Hash/HMAC 等结构化结果。
    :param rows: {"plain size": 5, "key": "xxx", ...}
    :param title: 可选面板标题
    :param show_header: 是否显示表头
    :param expand: 是否展开（长内容换行）
    :param overflow: 列溢出处理，ellipsis(截断) 或 fold(换行)。
        输出到 stdout 时应使用 fold 以显示完整密文/明文；输出到文件时可使用 ellipsis 省略
    """
    table = Table(show_header=show_header, box=None, padding=(0, 2), expand=expand)
    table.add_column("Key", style="key")
    table.add_column("Value", style="value", overflow=overflow)
    for k, v in rows.items():
        str_val = str(v)
        if show_header:
            table.add_row(k, str_val)
        else:
            table.add_row(f"[key]{k}[/]:", str_val)
    if title:
        panel_title = title if isinstance(title, str) else "metadata"
        console.print(
            Panel(
                table,
                title=f" [cmd]{panel_title}[/] ",
                border_style="dim",
                title_align="left",
            )
        )
    else:
        console.print(table)


def result_panel(
    content: str | Table,
    title: str,
    border_style: str = "dim",
) -> None:
    """带标题的面板输出"""
    console.print(Panel(content, title=f" [cmd]{title}[/] ", border_style=border_style))


def result_simple(rows: Dict[str, Any]) -> None:
    """
    简单 key: value 输出，保持与原有格式兼容（便于脚本解析）。
    当需要纯文本输出时使用。
    """
    for k, v in rows.items():
        console.print(f"[key]{k}[/]: [value]{v}[/]")


def print_rule(style: str = "dim") -> None:
    """输出横线分隔"""
    console.print(Rule(style=style))


def plain_copyable_block(label: str, value: str) -> None:
    """
    输出可复制的纯文本块。
    顶部：Rich 风格横线+标签（左对齐）；中间：Rich 风格美化的内容；底部：分割线。
    长内容由终端软换行展示（不插入换行符），便于复制时无需手动去除换行符。
    """
    console.print()
    # 横线+标签，左对齐以与主要内容一致
    console.print(Rule(title=Text(label, style="bold cyan"), style="dim", align="left"))
    # soft_wrap: 终端软换行展示完整内容，Rich 不插入换行符，便于复制
    console.print(Text(value, style="param"), overflow="ignore", soft_wrap=True, crop=False)
    console.print(Rule(style="dim"))


def timing_begin(flag: str, now: str) -> None:
    """性能计时开始"""
    console.print(f"[muted]⏱ {flag} begin @ {now}[/]")


def timing_end(flag: str, ms: float) -> None:
    """性能计时结束"""
    console.print(f"[muted]⏱ {flag} took {ms:.3f} ms[/]")


def welcome_panel(commands: Sequence[tuple[str, str]]) -> None:
    """Welcome panel showing common command examples"""
    table = Table(show_header=True, box=None, padding=(0, 2))
    table.add_column("Command", style="cmd")
    table.add_column("Example", style="param")
    for cmd, example in commands:
        table.add_row(cmd, example)
    console.print(
        Panel(
            table,
            title=" [bold]easy_encryption_tool[/] · Common Command Examples ",
            border_style="cyan",
        )
    )


def suggestion_panel(suggestions: Iterable[str]) -> None:
    """命令纠错建议"""
    console.print(
        Panel(
            ", ".join(suggestions),
            title=" [warning]Did you mean?[/] ",
            border_style="yellow",
        )
    )
