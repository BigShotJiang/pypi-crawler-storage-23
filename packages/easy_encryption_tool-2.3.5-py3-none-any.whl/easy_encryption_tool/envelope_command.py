#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Envelope encryption: asymmetric key wraps DEK, DEK encrypts data.
Single envelope format with issuer metadata, struct checksum, plaintext binding.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import struct
import time

import click

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import random_str
from easy_encryption_tool import validators
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error
from easy_encryption_tool import shell_completion
from easy_encryption_tool import hints

# Envelope format constants
EET_MAGIC = b"EET"
FORMAT_VERSION = 0x01
ALGO_AES_256_GCM = 0x01
WRAP_RSA = 0x01

# RSA key sizes allowed
RSA_ALLOWED_SIZES = (2048, 3072, 4096)

# Unified error for all decrypt failures (no padding oracle)
DECRYPT_FAILED_MSG = "Decryption failed: invalid envelope or wrong key."

# Symmetric params (AES-256-GCM only)
AES_DEK_LEN = 32
GCM_NONCE_LEN = 12
HMAC_LEN = 32
SHA256_LEN = 32


def _get_eet_version() -> str:
    from easy_encryption_tool import __version__

    v = __version__
    return v if str(v).startswith("v") else f"v{v}"


def _load_rsa_public_key(file_path: str):
    """Load RSA public key via cryptography. Returns None if not RSA or error."""
    try:
        with open(file_path, "rb") as f:
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric import rsa
            from cryptography.hazmat.backends import default_backend

            key = serialization.load_pem_public_key(
                f.read(), backend=default_backend()
            )
            if isinstance(key, rsa.RSAPublicKey) and key.key_size in RSA_ALLOWED_SIZES:
                return key
    except Exception:
        pass
    return None


def _load_rsa_private_key(file_path: str, password: bytes | None):
    """Load RSA private key. Returns (key_obj,) or None."""
    try:
        from cryptography.hazmat.primitives.asymmetric import rsa

        pri = common.load_private_key(
            encoding="pem", file_path=file_path, password_bytes=password
        )
        if pri is not None and isinstance(pri, rsa.RSAPrivateKey) and pri.key_size in RSA_ALLOWED_SIZES:
            return pri
    except Exception:
        pass
    return None


def _rsa_encrypt_dek(pub_key, dek: bytes) -> bytes:
    """Encrypt DEK with RSA OAEP-SHA256."""
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives import hashes

    pad = padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None,
    )
    return pub_key.encrypt(plaintext=dek, padding=pad)


def _rsa_decrypt_dek(pri_key, enc_dek: bytes) -> bytes:
    """Decrypt DEK with RSA OAEP-SHA256."""
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives import hashes

    pad = padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None,
    )
    return pri_key.decrypt(ciphertext=enc_dek, padding=pad)


def _aes_gcm_encrypt(key: bytes, nonce: bytes, aad: bytes, plaintext: bytes) -> bytes:
    """AES-256-GCM encrypt. Returns ciphertext||tag."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    aes = AESGCM(key)
    return aes.encrypt(nonce=nonce, data=plaintext, associated_data=aad)


def _aes_gcm_decrypt(key: bytes, nonce: bytes, aad: bytes, cipher_with_tag: bytes) -> bytes:
    """AES-256-GCM decrypt."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    aes = AESGCM(key)
    return aes.decrypt(nonce=nonce, data=cipher_with_tag, associated_data=aad)


def _build_envelope(
    algo_id: int,
    wrap_key_type: int,
    eet_version: str,
    request_id: str,
    aad: bytes,
    nonce: bytes,
    enc_dek: bytes,
    plaintext_binding: bytes,
    ciphertext: bytes,
) -> bytes:
    """Build envelope binary. ciphertext = cipher||tag for GCM."""
    eet_ver_bytes = eet_version.encode("utf-8")
    req_id_bytes = request_id.encode("utf-8")

    parts = [
        EET_MAGIC,
        bytes([FORMAT_VERSION, algo_id, wrap_key_type]),
        bytes([len(eet_ver_bytes)]),
        eet_ver_bytes,
        bytes([len(req_id_bytes)]),
        req_id_bytes,
        struct.pack(">H", len(aad)),
        aad,
        nonce,
        struct.pack(">H", len(enc_dek)),
        enc_dek,
        plaintext_binding,
    ]
    body = b"".join(parts)
    body += struct.pack(">I", len(ciphertext))
    body += ciphertext

    checksum = hashlib.sha256(body).digest()
    return body + checksum


def _parse_envelope(data: bytes) -> dict | None:
    """
    Parse envelope. Returns dict with fields or None on any error.
    All errors lead to generic decrypt failure - no specific messages.
    """
    min_len = 3 + 1 + 1 + 1 + 1 + 1 + 36 + 2 + 12 + 2 + 32 + 32 + 4
    if len(data) < min_len:
        return None
    if data[:3] != EET_MAGIC:
        return None
    if data[3] != FORMAT_VERSION:
        return None

    off = 6
    eet_ver_len = data[off]
    off += 1
    if off + eet_ver_len > len(data):
        return None
    eet_version = data[off : off + eet_ver_len].decode("utf-8", errors="replace")
    off += eet_ver_len

    req_id_len = data[off]
    off += 1
    if off + req_id_len > len(data):
        return None
    request_id = data[off : off + req_id_len].decode("utf-8", errors="replace")
    off += req_id_len

    aad_len = struct.unpack(">H", data[off : off + 2])[0]
    off += 2
    if aad_len > 4096 or off + aad_len > len(data):
        return None
    aad = data[off : off + aad_len]
    off += aad_len

    nonce = data[off : off + GCM_NONCE_LEN]
    off += GCM_NONCE_LEN

    enc_dek_len = struct.unpack(">H", data[off : off + 2])[0]
    off += 2
    if enc_dek_len > 4096 or off + enc_dek_len > len(data):
        return None
    enc_dek = data[off : off + enc_dek_len]
    off += enc_dek_len

    plaintext_binding = data[off : off + HMAC_LEN]
    off += HMAC_LEN

    ciphertext_len = struct.unpack(">I", data[off : off + 4])[0]
    off += 4
    if ciphertext_len > 0x7FFFFFFF or off + ciphertext_len > len(data):
        return None
    ciphertext = data[off : off + ciphertext_len]
    off += ciphertext_len

    if off + SHA256_LEN != len(data):
        return None
    stored_checksum = data[off : off + SHA256_LEN]

    body_for_checksum = data[:off]
    computed = hashlib.sha256(body_for_checksum).digest()
    if not hmac.compare_digest(computed, stored_checksum):
        return None

    return {
        "algo_id": data[4],
        "wrap_key_type": data[5],
        "eet_version": eet_version,
        "request_id": request_id,
        "aad": aad,
        "nonce": nonce,
        "enc_dek": enc_dek,
        "plaintext_binding": plaintext_binding,
        "ciphertext": ciphertext,
    }


@click.group(name="envelope", short_help="Envelope encryption (asymmetric wraps DEK)")
def envelope_group():
    """Envelope encryption: public key encrypts DEK, DEK encrypts data."""
    pass


@click.command(name="encrypt")
@click.option(
    "-f",
    "--public-key",
    required=True,
    type=click.STRING,
    help="RSA public key file path (2048/3072/4096 bits)",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Plaintext, base64 (-e), or file path (--from-file)",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    is_flag=True,
    default=False,
    help="Input is base64-encoded; -e and --from-file are mutually exclusive",
)
@click.option(
    "--from-file",
    is_flag=True,
    default=False,
    help="Input is file path; -e and --from-file are mutually exclusive",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file; default stdout (base64)",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--aad",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_AAD,
    show_default=True,
    help="GCM AAD",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=64,
    show_default=True,
    help="Max input size in MB when not file",
)
@click.option("--no-force", is_flag=True, default=False, help="Do not overwrite output file")
@output_format_options
def envelope_encrypt(
    public_key: str,
    input_data: str,
    is_base64_encoded: bool,
    from_file: bool,
    output_file: str,
    aad: str,
    input_limit: int,
    no_force: bool,
    output_format: str | None,
):
    """Encrypt with envelope: DEK encrypted by public key, data by DEK."""
    request_id = create_request_id()
    start = time.perf_counter()

    pub_key = _load_rsa_public_key(public_key)
    if pub_key is None:
        error("Public key must be RSA 2048/3072/4096 bits")
        return

    algo_id = ALGO_AES_256_GCM
    wrap_key_type = WRAP_RSA

    ok, err = validators.validate_b64_or_file(is_base64_encoded, from_file, "envelope")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    if from_file:
        try:
            with common.read_from_file(input_data) as f:
                plaintext = f.read_n_bytes(input_limit * 1024 * 1024)
        except OSError as e:
            error("Cannot read input file: {}".format(e))
            return
        if len(output_file) == 0:
            error("Output file required when input is file")
            return
    elif is_base64_encoded:
        valid, plaintext = common.check_b64_data(input_data)
        if not valid:
            error("invalid base64 encoded input")
            hints.hint_invalid_b64("envelope")
            return
        if len(plaintext) > input_limit * 1024 * 1024:
            error("Input exceeds {} MB limit".format(input_limit))
            return
    else:
        try:
            plaintext = input_data.encode("utf-8")
        except UnicodeEncodeError:
            error("Input contains invalid UTF-8")
            return
        if len(plaintext) > input_limit * 1024 * 1024:
            error("Input exceeds {} MB limit".format(input_limit))
            return

    if len(plaintext) == 0:
        error("Empty input")
        return

    aad_bytes = aad.encode("utf-8")
    nonce = random_str.generate_random_bytes(GCM_NONCE_LEN)
    dek = random_str.generate_random_bytes(AES_DEK_LEN)
    ciphertext = _aes_gcm_encrypt(dek, nonce, aad_bytes, plaintext)

    plaintext_binding = hmac.new(dek, plaintext, hashlib.sha256).digest()
    enc_dek = _rsa_encrypt_dek(pub_key, dek)

    envelope = _build_envelope(
        algo_id=algo_id,
        wrap_key_type=wrap_key_type,
        eet_version=_get_eet_version(),
        request_id=request_id,
        aad=aad_bytes,
        nonce=nonce,
        enc_dek=enc_dek,
        plaintext_binding=plaintext_binding,
        ciphertext=ciphertext,
    )

    envelope_b64 = base64.b64encode(envelope).decode("utf-8")

    if output_file:
        try:
            with common.write_to_file(output_file, force=not no_force) as w:
                if not w.write_bytes(envelope):
                    return
        except OSError as e:
            error("Cannot write output: {}".format(e))
            return

    duration_ms = (time.perf_counter() - start) * 1000
    metadata = build_metadata(
        operation="encrypt",
        algorithm="envelope",
        encoding="base64",
        input_type="file" if from_file else ("binary" if is_base64_encoded else "text"),
        input_size=len(plaintext),
        parameters={
            "key_size": pub_key.key_size,
            "request_id": request_id,
        },
    )
    result_data = {"output_file": output_file} if output_file else {"envelope": envelope_b64}
    result = build_result(**result_data)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    mode_fmt = resolve_output_format(output_format)
    render(output, mode=mode_fmt, primary_key="envelope" if not output_file else "output_file")


@click.command(name="decrypt")
@click.option(
    "-f",
    "--private-key",
    required=True,
    type=click.STRING,
    help="RSA private key file path (2048/3072/4096 bits)",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="Private key password (optional for unencrypted key)",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Envelope data (base64) or file path (use --from-file)",
)
@click.option(
    "--from-file",
    is_flag=True,
    default=False,
    help="Input is file path",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file; default stdout",
    shell_complete=shell_completion.complete_file_path,
)
@click.option("--no-force", is_flag=True, default=False, help="Do not overwrite output file")
@output_format_options
def envelope_decrypt(
    private_key: str,
    password: str,
    input_data: str,
    from_file: bool,
    output_file: str,
    no_force: bool,
    output_format: str | None,
):
    """Decrypt envelope: private key decrypts DEK, DEK decrypts data."""
    request_id = create_request_id()
    start = time.perf_counter()

    if from_file:
        try:
            with common.read_from_file(input_data) as f:
                raw = f.read_n_bytes(64 * 1024 * 1024)
        except OSError:
            error(DECRYPT_FAILED_MSG)
            return
    else:
        try:
            raw = common.decode_b64_data(input_data)
        except Exception:
            error(DECRYPT_FAILED_MSG)
            return

    parsed = _parse_envelope(raw)
    if parsed is None:
        error(DECRYPT_FAILED_MSG)
        return

    if parsed["wrap_key_type"] != WRAP_RSA:
        error(DECRYPT_FAILED_MSG)
        return

    algo_id = parsed["algo_id"]
    if algo_id != ALGO_AES_256_GCM:
        error(DECRYPT_FAILED_MSG)
        return

    pw = password.encode("utf-8") if password else None
    pri_key = _load_rsa_private_key(private_key, pw)
    if pri_key is None:
        error(DECRYPT_FAILED_MSG)
        return

    try:
        dek = _rsa_decrypt_dek(pri_key, parsed["enc_dek"])
    except Exception:
        error(DECRYPT_FAILED_MSG)
        return

    aad = parsed["aad"]
    nonce = parsed["nonce"]
    ciphertext = parsed["ciphertext"]

    try:
        plaintext = _aes_gcm_decrypt(dek, nonce, aad, ciphertext)
    except Exception:
        error(DECRYPT_FAILED_MSG)
        return

    expected_binding = hmac.new(dek, plaintext, hashlib.sha256).digest()
    if not hmac.compare_digest(expected_binding, parsed["plaintext_binding"]):
        error(DECRYPT_FAILED_MSG)
        return

    if output_file:
        try:
            with common.write_to_file(output_file, force=not no_force) as w:
                if not w.write_bytes(plaintext):
                    error(DECRYPT_FAILED_MSG)
                    return
        except OSError:
            error("Cannot write output file")
            return

    duration_ms = (time.perf_counter() - start) * 1000
    be_str, ret = common.bytes_to_str(plaintext)

    metadata = build_metadata(
        operation="decrypt",
        algorithm="envelope",
        encoding="utf-8" if be_str else "base64",
        input_type="file" if from_file else "binary",
        input_size=len(raw),
        parameters={
            "request_id": parsed["request_id"],
            "eet_version": parsed["eet_version"],
        },
    )
    result_data = {"output_file": output_file, "plain_size": len(plaintext)} if output_file else {"plain": ret}
    result = build_result(**result_data)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    mode_fmt = resolve_output_format(output_format)
    render(output, mode=mode_fmt, primary_key="output_file" if output_file else "plain")


envelope_group.add_command(envelope_encrypt)
envelope_group.add_command(envelope_decrypt)
