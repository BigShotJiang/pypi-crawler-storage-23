#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
CipherHUB CLI Output Renderer.

Rendering modes:
  - pretty_json (default): rich colored JSON via console.print_json
  - json: single line JSON
  - raw: only primary result value (for piping/copy)
"""
from __future__ import annotations

import json
from typing import Any, Callable

import click

from easy_encryption_tool.rich_ui import console


OutputMode = str  # "pretty_json" | "json" | "raw"


def output_format_options(func: Callable) -> Callable:
    """Add --json, --pretty-json, --raw options. Mutually exclusive."""
    func = click.option(
        "--json",
        "output_format",
        flag_value="json",
        default=None,
        help="Output single-line JSON",
    )(func)
    func = click.option(
        "--pretty-json",
        "output_format",
        flag_value="pretty_json",
        default=None,
        help="Output colored pretty JSON (default)",
    )(func)
    func = click.option(
        "--raw",
        "output_format",
        flag_value="raw",
        default=None,
        help="Output only primary result value",
    )(func)
    return func


def resolve_output_format(output_format: str | None) -> OutputMode:
    """Resolve None to default pretty_json."""
    return output_format or "pretty_json"


def render(
    output: dict[str, Any],
    mode: OutputMode = "pretty_json",
    primary_key: str | None = None,
) -> None:
    """
    Render output according to mode.

    :param output: full output dict (metadata, result, runtime)
    :param mode: pretty_json | json | raw
    :param primary_key: key in result for --raw mode (e.g. digest, cipher, plain)
    """
    if mode == "raw" and primary_key:
        result = output.get("result", {})
        value = result.get(primary_key)
        if value is not None:
            print(str(value))
        return

    if mode == "json":
        # Plain output for piping/parsing, no Rich markup
        print(json.dumps(output, ensure_ascii=False))
        return

    # pretty_json (default): rich colored JSON, valid and copyable
    console.print_json(json.dumps(output, ensure_ascii=False, indent=2))


def get_primary_key_for_operation(operation: str, **ctx) -> str | None:
    """
    Map operation to primary result key for --raw mode.

    :param operation: encrypt, decrypt, sign, verify, hash, hmac, derive, random
    """
    mapping = {
        "encrypt": "cipher",
        "decrypt": "plain",
        "sign": "signature",
        "verify": "valid",
        "hash": "digest",
        "hmac": "hmac",
        "derive": "key",
        "random": "value",
    }
    return mapping.get(operation)
