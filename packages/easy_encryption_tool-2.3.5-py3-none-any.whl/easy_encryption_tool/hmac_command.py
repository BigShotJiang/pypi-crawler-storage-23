#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-02 10:57:19
import hashlib
import hmac
import time

import click
from click.core import ParameterSource

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import shell_completion
from easy_encryption_tool import random_str
from easy_encryption_tool import validators
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error

try:
    from easy_gmssl import EasySM3Hmac
    from easy_gmssl.gmssl import SM3_HMAC_MIN_KEY_SIZE, SM3_HMAC_MAX_KEY_SIZE

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

hash_maps = {
    hashlib.sha224().name: hashlib.sha224,
    hashlib.sha256().name: hashlib.sha256,
    hashlib.sha384().name: hashlib.sha384,
    hashlib.sha512().name: hashlib.sha512,
    hashlib.sha3_224().name: hashlib.sha3_224,
    hashlib.sha3_256().name: hashlib.sha3_256,
    hashlib.sha3_384().name: hashlib.sha3_384,
    hashlib.sha3_512().name: hashlib.sha3_512,
}
if EASY_GMSSL_AVAILABLE:
    hash_maps["sm3"] = "sm3"


def _compute_hmac_bytes(alg: str, key_bytes: bytes, data: bytes) -> str:
    """Compute HMAC, return hex string."""
    if alg == "sm3":
        h_sm3 = EasySM3Hmac(key=key_bytes)
        h_sm3.UpdateData(data)
        ret_bytes, _, _ = h_sm3.GetHmac()
        return ret_bytes.hex()
    h = hmac.new(key=key_bytes, digestmod=hash_maps[alg])
    h.update(data)
    return h.hexdigest()


def _compute_hmac_file(alg: str, key_bytes: bytes, file_path: str) -> tuple[str, int]:
    """Compute HMAC of file. Returns (hex_string, size_bytes)."""
    with common.read_from_file(file_path) as input_file:
        data_len = 0
        if alg == "sm3":
            h_sm3 = EasySM3Hmac(key=key_bytes)
            while True:
                data = input_file.read_n_bytes(4096)
                data_len += len(data)
                if len(data) > 0:
                    h_sm3.UpdateData(data)
                else:
                    ret_bytes, _, _ = h_sm3.GetHmac()
                    return ret_bytes.hex(), data_len
        else:
            h = hmac.new(key=key_bytes, digestmod=hash_maps[alg])
            while True:
                data = input_file.read_n_bytes(4096)
                data_len += len(data)
                if len(data) > 0:
                    h.update(data)
                else:
                    return h.hexdigest(), data_len


@click.command(name="hmac", short_help="HMAC message authentication code")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input: string, base64, or file path",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Input is base64-encoded; -e and -f mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    type=click.Choice(list(hash_maps.keys())),
    default=hashlib.sha256().name,
    show_default=True,
    help="Hash algorithm: sm3, sha256, sha384, sha512, etc.",
)
@click.option(
    "-k",
    "--key",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_HMAC_KEY,
    help="Key 32 bytes, CipherHUB compatible",
    show_default=True,
    is_flag=False,
    multiple=False,
)
@click.option(
    "-r",
    "--random-key",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Auto-generate random key (32 bytes)",
    multiple=False,
)
@click.option(
    "--key-b64",
    required=False,
    type=click.STRING,
    default=None,
    help="[Advanced] Key as base64-encoded bytes. Length must match algorithm (e.g. SM3: 1-512 bytes).",
)
@output_format_options
@click.pass_context
def hmac_command(
    ctx: click.Context,
    input_data: str,
    is_base64_encoded: bool,
    is_a_file: bool,
    random_key: bool,
    key: str,
    key_b64: str | None,
    hash_alg: str,
    output_format: str | None = None,
):
    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "HMAC")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    if random_key:
        if key_b64 is not None:
            error("HMAC: -r/--random-key cannot be used with --key-b64")
            return
        key = random_str.generate_random_str(32)
        key_bytes = key.encode("utf-8")
    elif key_b64 is not None:
        key_from_cli = ctx.get_parameter_source("key") == ParameterSource.COMMANDLINE
        if key_from_cli:
            error("HMAC: -k/--key and --key-b64 are mutually exclusive; specify one only")
            return
        if hash_alg == "sm3":
            if not EASY_GMSSL_AVAILABLE:
                hints.hint_missing_gmssl("SM3 HMAC")
                return
            ok, err, kb = common.decode_key_b64(
                key_b64,
                min_len=SM3_HMAC_MIN_KEY_SIZE,
                max_len=SM3_HMAC_MAX_KEY_SIZE,
            )
        else:
            ok, err, kb = common.decode_key_b64(key_b64, min_len=1, max_len=512)
        if not ok:
            error("HMAC: {}".format(err or ""))
            return
        key_bytes = kb
    else:
        key_bytes = key.encode("utf-8")

    if hash_alg == "sm3":
        if not EASY_GMSSL_AVAILABLE:
            hints.hint_missing_gmssl("SM3 HMAC")
            return
        if (
            len(key_bytes) < SM3_HMAC_MIN_KEY_SIZE
            or len(key_bytes) > SM3_HMAC_MAX_KEY_SIZE
        ):
            error(
                "SM3 HMAC key length must be {}-{} bytes".format(
                    SM3_HMAC_MIN_KEY_SIZE, SM3_HMAC_MAX_KEY_SIZE
                )
            )
            return

    request_id = create_request_id()
    start = time.perf_counter()

    hmac_value: str | None = None
    input_size: int = 0

    if not is_a_file:
        if not is_base64_encoded:
            try:
                input_raw_bytes = input_data.encode("utf-8")
            except UnicodeEncodeError:
                error("input contains invalid UTF-8 characters")
                return
        else:
            try:
                input_raw_bytes = common.decode_b64_data(input_data)
            except BaseException as e:
                error("invalid b64 encoded data: {}".format(e))
                hints.hint_invalid_b64("HMAC")
                return
        input_size = len(input_raw_bytes)
        hmac_value = _compute_hmac_bytes(hash_alg, key_bytes, input_raw_bytes)
    else:
        try:
            hmac_value, input_size = _compute_hmac_file(hash_alg, key_bytes, input_data)
        except OSError:
            error("file {} may not exist or may not be readable".format(input_data))
            return

    duration_ms = (time.perf_counter() - start) * 1000

    input_type = "file" if is_a_file else ("binary" if is_base64_encoded else "text")
    metadata = build_metadata(
        operation="hmac",
        algorithm=hash_alg,
        encoding="hex",
        input_type=input_type,
        input_size=input_size,
        parameters={"digest_size": len(hmac_value) // 2},
    )
    result_data = {"hmac": hmac_value}
    if random_key:
        result_data["key"] = key
    result = build_result(**result_data)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="hmac")


if __name__ == "__main__":
    hmac_command()
