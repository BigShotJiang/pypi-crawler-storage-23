"""JVA01-Capture screen recording module."""

from jva_capture.capture import JVACapture

__all__ = ["JVACapture"]
