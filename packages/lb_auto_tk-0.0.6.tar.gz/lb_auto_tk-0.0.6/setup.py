from setuptools import setup, find_packages

setup(
    name="lb_auto_tk",
    version="1.0.0",
    packages=find_packages(),
    description="Ultimate auto-GUI framework for students",
    author="abobus",
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)