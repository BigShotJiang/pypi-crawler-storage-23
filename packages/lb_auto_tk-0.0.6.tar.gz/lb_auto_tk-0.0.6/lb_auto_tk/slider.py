# lb_auto_tk/slider.py
import tkinter as tk
from tkinter import ttk
from .colors import COLORS

class Slider:
    def __init__(self, parent, label, start, end, step, callback):
        self.frame = tk.Frame(parent, bg=parent["bg"])
        self.frame.pack(fill="x", pady=10)
        
        self.label_text = label
        self.step = step
        self.callback = callback
        
        self.info = tk.Label(self.frame, text=f"{label}: {start}", bg=parent["bg"], fg=COLORS["text"])
        self.info.pack(anchor="w")
        
        self.s = ttk.Scale(self.frame, from_=start, to=end, command=self._update)
        self.s.pack(fill="x", pady=5)

    def _update(self, val):
        v = round(float(val) / self.step) * self.step
        v = round(v, 2)
        self.info.config(text=f"{self.label_text}: {v}")
        if self.callback: self.callback(v)