# lb_auto_tk/button.py
import tkinter as tk
from .colors import COLORS

class Button:
    def __init__(self, parent, text, func, type="primary"):
        bg = COLORS["accent"] if type == "primary" else COLORS["card"]
        self.btn = tk.Button(
            parent, text=text.upper(), command=func,
            bg=bg, fg=COLORS["text"], relief="flat",
            font=("Segoe UI", 10, "bold"), activebackground="#3a6aaa",
            cursor="hand2", bd=0
        )
        self.btn.pack(fill="x", pady=8, ipady=10)