# lb_auto_tk/utils.py
def validate_input(P, f_type):
    if P == "": return True
    if f_type == "digits": return P.isdigit()
    if f_type == "no digits": return not any(c.isdigit() for c in P)
    if f_type == "float":
        if P in [".", ""]: return True
        try: 
            float(P)
            return True
        except: return False
    return True