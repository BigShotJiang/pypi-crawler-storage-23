import tkinter as tk
from .colors import COLORS
from .button import Button
from .input import Input
from .slider import Slider
from .radio import Radio
# ДОБАВЬ ЭТИ ИМПОРТЫ:
from .dropdown import Dropdown
from .listbox import Listbox

class LbAutoTk:
    def __init__(self, title="App"):
        self.root = tk.Tk()
        self.root.title(f"{title} - made with lb_auto_tk")
        self.root.geometry("500x850")
        self.root.configure(bg=COLORS["bg"])
        
        self.main = tk.Frame(self.root, bg=COLORS["bg"], padx=30, pady=30)
        self.main.pack(fill="both", expand=True)

    def header(self, text):
        tk.Label(self.main, text=text, bg=COLORS["bg"], fg=COLORS["text"], 
                 font=("Segoe UI", 22, "bold")).pack(pady=(0, 20), anchor="w")

    # ДОБАВЬ ЭТИ МЕТОДЫ:
    def dropdown(self, label, options, callback):
        return Dropdown(self.main, label, options, callback)

    def listbox(self, label, height=6):
        return Listbox(self.main, label, height)

    # Остальные методы (input, button, slider, radio)...
    def input(self, label, f_type="any"):
        return Input(self.main, label, f_type)

    def button(self, text, func, type="primary"):
        return Button(self.main, text, func, type)

    def slider(self, label, start, end, step=1, callback=None):
        return Slider(self.main, label, start, end, step, callback)

    def radio(self, label, options):
        return Radio(self.main, label, options)

    def run(self):
        self.root.mainloop()