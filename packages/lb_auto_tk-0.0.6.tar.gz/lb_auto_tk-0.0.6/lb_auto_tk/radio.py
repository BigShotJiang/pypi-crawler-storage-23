# lb_auto_tk/radio.py
import tkinter as tk
from .colors import COLORS

class Radio:
    def __init__(self, parent, label, options):
        tk.Label(parent, text=label, bg=parent["bg"], fg=COLORS["dim"]).pack(anchor="w")
        self.var = tk.StringVar(value=options[0])
        f = tk.Frame(parent, bg=parent["bg"])
        f.pack(fill="x", pady=5)
        for o in options:
            tk.Radiobutton(
                f, text=o, variable=self.var, value=o, 
                bg=parent["bg"], fg=COLORS["text"], 
                selectcolor=COLORS["card"], activebackground=parent["bg"]
            ).pack(side="left", padx=10)