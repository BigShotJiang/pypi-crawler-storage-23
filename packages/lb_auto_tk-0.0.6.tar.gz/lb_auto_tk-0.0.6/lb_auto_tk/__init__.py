# lb_auto_tk/__init__.py
from .core import LbAutoTk