import tkinter as tk
from .colors import COLORS

class Listbox:
    def __init__(self, parent, label, height=6):
        self.frame = tk.Frame(parent, bg=parent["bg"])
        self.frame.pack(fill="x", pady=10)
        
        if label:
            tk.Label(self.frame, text=label.upper(), bg=parent["bg"], 
                     fg=COLORS["dim"], font=("Segoe UI", 8, "bold")).pack(anchor="w")
        
        # Контейнер для списка
        self.lb_frame = tk.Frame(self.frame, bg=COLORS["input_bg"], padx=5, pady=5)
        self.lb_frame.pack(fill="x", pady=5)
        
        self.lb = tk.Listbox(
            self.lb_frame, bg=COLORS["input_bg"], fg=COLORS["text"],
            borderwidth=0, height=height, font=("Consolas", 10),
            highlightthickness=0, selectbackground=COLORS["accent"]
        )
        self.lb.pack(side="left", fill="x", expand=True)
        
        # Скроллбар (чтобы логи не улетали в пустоту)
        sc = tk.Scrollbar(self.lb_frame, command=self.lb.yview, bg=COLORS["input_bg"])
        self.lb.config(yscrollcommand=sc.set)

    def add(self, text):
        self.lb.insert(0, f"> {text}")

    def clear(self):
        self.lb.delete(0, tk.END)