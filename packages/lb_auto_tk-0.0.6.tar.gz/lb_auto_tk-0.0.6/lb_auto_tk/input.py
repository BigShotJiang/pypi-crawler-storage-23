# lb_auto_tk/input.py
import tkinter as tk
from .colors import COLORS
from .utils import validate_input

class Input:
    def __init__(self, parent, label, f_type="any"):
        self.frame = tk.Frame(parent, bg=parent["bg"])
        self.frame.pack(fill="x", pady=5)
        
        if label:
            tk.Label(self.frame, text=label.upper(), bg=parent["bg"], 
                     fg=COLORS["dim"], font=("Segoe UI", 8, "bold")).pack(anchor="w")
        
        vcmd = (parent.register(validate_input), '%P', f_type)
        
        # Основное поле ввода
        self.entry = tk.Entry(
            self.frame, bg=COLORS["input_bg"], fg=COLORS["text"],
            insertbackground="white", relief="flat", borderwidth=0, 
            font=("Segoe UI", 11), validate="key", validatecommand=vcmd
        )
        # ipady создает внутреннее пространство сверху и снизу текста
        self.entry.pack(fill="x", pady=(2, 10), ipady=8) 

    def get(self):
        """Возвращает текст из поля"""
        return self.entry.get()

    def clear(self):
        """Полностью очищает поле (то, чего не хватало)"""
        self.entry.delete(0, tk.END)