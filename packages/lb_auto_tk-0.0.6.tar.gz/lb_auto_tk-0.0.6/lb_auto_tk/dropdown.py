import tkinter as tk
from tkinter import ttk
from .colors import COLORS

class Dropdown:
    def __init__(self, parent, label, options, callback):
        self.frame = tk.Frame(parent, bg=parent["bg"])
        self.frame.pack(fill="x", pady=5)
        
        if label:
            tk.Label(self.frame, text=label.upper(), bg=parent["bg"], 
                     fg=COLORS["dim"], font=("Segoe UI", 8, "bold")).pack(anchor="w")
        
        self.var = tk.StringVar(value=options[0])
        
        # Настройка стиля для выпадающего списка
        self.cb = ttk.Combobox(self.frame, textvariable=self.var, values=options, state="readonly")
        self.cb.bind("<<ComboboxSelected>>", lambda e: callback(self.var.get()))
        self.cb.pack(fill="x", pady=(2, 10), ipady=3)

    def get(self):
        return self.var.get()