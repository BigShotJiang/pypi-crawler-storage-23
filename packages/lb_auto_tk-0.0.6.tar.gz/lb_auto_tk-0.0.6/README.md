
# lb-auto-tk: lib for lazy

© Copyright logic-break 2026

https://logic-break.github.io

  

> lib made for lazy, by lazy

  

installation:

  

pip install lb-auto-tk

**NOTE: in code, you must import lb_auto_tk**

## Usage:

  

### 1. Main Application Class

  

-  **`LbAutoTk(title="App")`**

-  `title`: The text displayed on the window title bar.

  

----------

  

### 2. UI Components (Core Methods)

  

-  **`header(text)`**

-  `text`: Large, bold display text used as a section title inside the UI.

-  **`input(label, f_type="any")`**

-  `label`: The caption text above the input field.

-  `f_type`: Validation type. Options: `"any"`, `"float"` (numbers/decimals only), `"no digits"` (blocks numbers).

-  **`button(text, func, type="primary")`**

-  `text`: Label on the button.

-  `func`: The function to execute when clicked.

-  `type`: Styling choice. `"primary"` (Accent Blue) or `"secondary"` (Dark Gray).

-  **`dropdown(label, options, callback)`**

-  `label`: The caption above the selection menu.

-  `options`: A list of strings, e.g., `["High", "Medium", "Low"]`.

-  `callback`: Function that runs immediately when a value is selected.

-  **`slider(label, start, end, step=1, callback=None)`**

-  `label`: The name of the setting.

-  `start` / `end`: Range values (min/max).

-  `step`: The increment value (e.g., `1` or `0.5`).

-  `callback`: Function that runs while the slider is moving.

-  **`radio(label, options)`**

-  `label`: Title of the radio group.

-  `options`: List of strings for the selectable options.

-  **`listbox(label, height=6)`**

-  `label`: Title for the log/history window.

-  `height`: How many lines high the box should be.

  

----------

  

### 3. Widget Methods (Interaction)

  

-  **For Input:**

-  `.get()`: Returns the current string typed in the field.

-  `.clear()`: Erases all text from the field.

-  **For Dropdown:**

-  `.get()`: Returns the currently selected option string.

-  **For Listbox:**

-  `.add(text)`: Pushes a new line to the top of the box (adds `>` prefix automatically).

-  `.clear()`: Deletes all entries in the log.

-  **For Radio:**

-  `.var.get()`: Retrieves the string value of the selected radio button.

-  **For Slider:**

-  `.info.cget("text")`: Useful for grabbing the formatted "Label: Value" string from the UI.

  

----------

  

### 4. Execution

  

-  **`app.run()`**

- Starts the Tkinter main loop to display your window.

  

## Example:

  

    from lb_auto_tk import LbAutoTk
    
    # 1. Setup App
    
    app = LbAutoTk("AI Image Studio")
    
    app.header("Image Generator")
    
    # 2. Text Inputs
    
    prompt = app.input("Prompt", f_type="any")
    
    negative = app.input("Negative Prompt", f_type="any")
    
    # 3. Dropdown (Model Selection)
    
    def on_model_change(val):
    
    status.add(f"Switched to model: {val}")
    
    model = app.dropdown("AI Model", ["Stable Diffusion v2.1", "Midjourney v6", "DALL-E 3"], on_model_change)
    
    # 4. Radio Buttons (Aspect Ratio)
    
    ratio = app.radio("Aspect Ratio", ["1:1", "16:9", "9:16"])
    
    # 5. Slider (Sampling Steps)
    
    steps = app.slider("Sampling Steps", 10, 100, 1)
    
    # 6. Listbox (System Logs)
    
    status = app.listbox("System Status", height=5)
    
    # 7. Interaction Logic
    
    def generate():
    
    p = prompt.get()
    
    m = model.get()
    
    r = ratio.var.get()
    
    s = steps.info.cget("text") # Get value from slider label
    
    if not p:
    
    status.add("ERROR: Prompt is empty!")
    
    return
    
    status.add(f"Generating '{p}'...")
    
    status.add(f"Config: {m} | Ratio: {r} | {s}")
    
    # 8. Buttons
    
    app.button("GENERATE IMAGE", generate)
    
    app.button("CLEAR LOGS", lambda: status.clear(), type="secondary")
    
    app.run()
