"""kbx — local knowledge base CLI with hybrid search over markdown files."""
