"""Pluggable source adapters for indexing different content types."""
