# Changelog

## [0.1.1](https://github.com/tenfourty/kbx/compare/kbx-v0.1.0...kbx-v0.1.1) (2026-02-23)


### Features

* initial release of kbx — local knowledge base CLI ([d260f66](https://github.com/tenfourty/kbx/commit/d260f66d9dcdb4b876727bd95ec125f6d541a4ee))


### Bug Fixes

* add autouse fixture for fake mlx modules in tests ([3c1dd32](https://github.com/tenfourty/kbx/commit/3c1dd32e7217a0f3cf02871b8bd1433ad10c1ea9))
* MLX mock tests work without mlx installed ([89e12f3](https://github.com/tenfourty/kbx/commit/89e12f3eb64682f8e30e3ecf59128ddd778a4992))
* use NDArray type annotations for numpy compatibility ([4b407ed](https://github.com/tenfourty/kbx/commit/4b407ed9a5895afdef7136fa0456634766d3352b))
