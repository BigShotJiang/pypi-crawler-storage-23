"""External registry integrations for writ."""
