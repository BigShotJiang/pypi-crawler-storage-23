"""enwrit (writ) -- Agent instruction management CLI.

Compose, port, and score AI agent configs across tools, projects, and devices.
"""

__version__ = "0.2.0"
