"""Core business logic for writ."""
