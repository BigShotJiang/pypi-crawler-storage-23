#include <bits/stdc++.h>

using namespace std;

int32_t main() {
  int16_t a, b; // overflow
  cin >> a >> b;
  cout << a + b << endl;
}