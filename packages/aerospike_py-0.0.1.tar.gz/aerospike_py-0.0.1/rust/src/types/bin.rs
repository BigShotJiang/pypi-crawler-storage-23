//! Conversion from Python dicts to `aerospike_core::Bin` vectors.

use aerospike_core::Bin;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyString};

use super::value::py_to_value;

/// Convert a Python dict of bins to a Vec<Bin>.
/// Bin values of None (Nil) are passed through — the server treats them
/// as bin deletion requests, matching the official Python client behavior.
pub fn py_dict_to_bins(dict: &Bound<'_, PyDict>) -> PyResult<Vec<Bin>> {
    let mut bins = Vec::with_capacity(dict.len());
    for (key, val) in dict.iter() {
        let name: String = key.cast::<PyString>()?.to_str()?.to_owned();
        let value = py_to_value(&val)?;
        bins.push(Bin::new(name, value));
    }
    Ok(bins)
}
