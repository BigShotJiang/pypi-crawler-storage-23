"""Output formatters for Context Lint reports."""
