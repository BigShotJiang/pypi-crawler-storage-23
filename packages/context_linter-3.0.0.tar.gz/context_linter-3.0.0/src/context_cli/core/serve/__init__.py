"""Serve modes — proxy, middleware, and static generation for markdown delivery."""
