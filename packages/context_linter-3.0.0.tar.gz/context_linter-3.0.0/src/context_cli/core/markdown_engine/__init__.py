"""Markdown-for-Agents engine — HTML-to-Markdown conversion pipeline."""

from context_cli.core.markdown_engine.converter import convert_html_to_markdown

__all__ = ["convert_html_to_markdown"]
