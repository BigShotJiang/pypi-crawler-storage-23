"""CI/CD integration utilities for readiness lints."""
