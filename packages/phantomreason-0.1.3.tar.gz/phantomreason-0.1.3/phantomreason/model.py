from __future__ import annotations

import json
import re
import urllib.error

from .corpus import extract_dictionary_facts, fetch_url_text, iter_sentences, load_text_file
from .storage import GLOBAL_INDEX, GLOBAL_VOCAB, MODEL_STATE_PATH, vocabadder
from .stores import TraceStore
from .traces import (
    add,
    blank_vector,
    combine,
    compare,
    context_indices,
    erase,
    flip_index,
    format_result,
    is_present,
    n,
    score_distance,
    solve,
    subtract,
)


class PhantomLanguageModel:
    """PhantomTrace-native symbolic language core built on reusable trace stores."""

    def __init__(self, dim: int = 2048, sparsity: int = 32):
        self.dim = max(256, int(dim))
        self.sparsity = max(1, min(int(sparsity), self.dim))
        self.context_window = 4
        self.topic_window = 10
        self.recent_window = 6
        self.repetition_penalty = 1.0
        self.update_budget = 6
        self.fact_match_threshold = self.dim * 0.18
        self.max_relation_object = 4
        self.focus_mode = False
        self.focus_limit = 24
        self.focus_words: list[str] = []
        self.trace_store = TraceStore(
            dim=self.dim,
            sparsity=self.sparsity,
            bank_shapes={"context": 4, "topic": 2},
        )
        self.symbol_store = TraceStore(
            dim=self.dim,
            sparsity=self.sparsity,
            bank_shapes={"reason": 2},
            seed=19,
        )
        self.episode_store = TraceStore(
            dim=self.dim,
            sparsity=self.sparsity,
            bank_shapes={"context": 2},
            seed=31,
        )
        self.fact_store = TraceStore(
            dim=self.dim,
            sparsity=self.sparsity,
            bank_shapes={"forward": 2, "inverse": 2},
            seed=43,
        )
        self.active_words: set[str] = set()
        self.symbol_index: dict[str, int] = {}
        self.episode_index: dict[str, int] = {}
        self.episode_meta: dict[str, str] = {}
        self.episode_order: list[str] = []
        self.fact_index: dict[str, int] = {}
        self.fact_meta: dict[str, dict[str, object]] = {}
        self.fact_strength: dict[str, object] = {}
        self.fact_order: list[str] = []
        self.role_samples: dict[str, list[str]] = {
            "role:subject": [],
            "role:predicate": [],
            "role:object": [],
        }
        self.intent_anchors = {
            "intent:answer": ["what", "who", "when", "where", "why", "how"],
            "intent:continue": ["continue", "next", "then", "after"],
            "intent:teach": ["teach", "learn", "remember", "store"],
            "intent:inspect": ["inspect", "debug", "trace", "why"],
            "intent:focus": ["focus", "narrow", "local", "small"],
        }
        self.action_anchors = {
            "action:predict": ["answer", "predict", "next", "best"],
            "action:generate": ["continue", "extend", "sample", "write"],
            "action:inspect": ["inspect", "trace", "compare", "show"],
            "action:teach": ["teach", "learn", "remember", "update"],
            "action:clarify": ["clarify", "example", "more", "explain"],
        }
        self.form_anchors = {
            "form:question": ["what", "who", "when", "where", "why", "how"],
            "form:command": ["teach", "focus", "inspect", "show"],
            "form:statement": ["is", "are", "means", "becomes"],
            "form:fragment": ["example", "phrase", "token"],
        }
        self.query_anchors = {
            "query:what": ["what", "thing", "name"],
            "query:who": ["who", "person", "agent"],
            "query:when": ["when", "time", "date"],
            "query:where": ["where", "place", "location"],
            "query:why": ["why", "reason", "cause"],
            "query:how": ["how", "method", "process"],
        }
        self.role_anchors = {
            "role:subject": ["subject"],
            "role:predicate": ["predicate"],
            "role:object": ["object"],
        }
        self.command_words = {"teach", "focus", "inspect", "show", "tell", "explain", "remember"}
        self.question_words = {"what", "who", "when", "where", "why", "how"}
        self.relation_words = {"is", "are", "was", "were", "means", "mean", "becomes", "become", "has", "have"}
        self.function_words = {
            "a",
            "an",
            "the",
            "and",
            "or",
            "to",
            "of",
            "in",
            "on",
            "for",
            "with",
            "is",
            "are",
            "was",
            "were",
            "do",
            "does",
            "did",
            "please",
        }
        self.analysis_cache: dict[str, dict[str, object]] = {}
        self.semantic_probe_cache: dict[tuple[object, ...], list] = {}
        self._load_state()
        self._bootstrap_symbol_semantics()

    def tokenize(self, text: str) -> list[str]:
        return re.findall(r"[a-zA-Z']+", text.lower())

    def add_word(self, word: str) -> int:
        normalized = word.lower().strip()
        if not normalized:
            raise ValueError("word must be non-empty")
        index = vocabadder(normalized)
        self.active_words.add(normalized)
        self.trace_store.ensure(normalized, index)
        return index

    def set_focus_mode(self, enabled: bool) -> None:
        self.focus_mode = bool(enabled)

    def set_focus_text(self, text: str) -> None:
        self.focus_words = []
        for token in self.tokenize(text):
            self.add_word(token)
            self._remember_focus_word(token)

    def prime_focus(self, text: str) -> None:
        tokens = self.tokenize(text)
        if not tokens:
            return
        self.focus_words = []
        self.train_on_text(text, epochs=1)
        for token in tokens:
            self._remember_focus_word(token)

    def build_context(self, tokens: list[str]) -> list:
        return self._combine_tokens(tokens[-self.context_window :])

    def build_topic_context(self, tokens: list[str]) -> list:
        return self._combine_tokens(tokens[-self.topic_window :])

    def predict_next(self, tokens: list[str], recent_tokens: list[str] | None = None) -> str | None:
        ranked = self.rank_candidates(tokens, recent_tokens=recent_tokens, limit=1)
        return ranked[0][0] if ranked else None

    def infer_intent(self, prompt: str) -> tuple[str, float]:
        lowered = prompt.lower().strip()
        if lowered.startswith("teach "):
            return "intent:teach", 0.0
        if lowered.startswith("inspect "):
            return "intent:inspect", 0.0
        if lowered.startswith("focus ") or lowered in {"focus on", "focus off"}:
            return "intent:focus", 0.0
        if lowered.endswith("?") or lowered.startswith(("what ", "who ", "when ", "where ", "why ", "how ")):
            return "intent:answer", 0.0
        if any(marker in lowered for marker in ("continue", "go on", "next")):
            return "intent:continue", 0.0

        analysis = self.understand_input(prompt)
        probe = self.semantic_probe(analysis)
        best_symbol = "intent:answer"
        best_score = None
        for symbol in self.intent_anchors:
            sig, _ = self.symbol_store.best_bank_signature(symbol, "reason", probe)
            score = (0.65 * score_distance(self.dim, probe, sig)) + (
                0.35 * score_distance(self.dim, probe, self.symbol_store.primary_signature(symbol))
            )
            if best_score is None or score < best_score:
                best_score = score
                best_symbol = symbol
        return best_symbol, float(best_score or 0.0)

    def choose_action(self, prompt: str, intent_symbol: str) -> tuple[str, float]:
        implied = {
            "intent:teach": "action:teach",
            "intent:inspect": "action:inspect",
            "intent:focus": "action:clarify",
            "intent:continue": "action:generate",
            "intent:answer": "action:predict",
        }
        if intent_symbol in implied:
            return implied[intent_symbol], 0.0

        analysis = self.understand_input(prompt)
        probe = self.semantic_probe(analysis)
        best_symbol = "action:predict"
        best_score = None
        for symbol in self.action_anchors:
            sig, _ = self.symbol_store.best_bank_signature(symbol, "reason", probe)
            score = (0.65 * score_distance(self.dim, probe, sig)) + (
                0.35 * score_distance(self.dim, probe, self.symbol_store.primary_signature(symbol))
            )
            if best_score is None or score < best_score:
                best_score = score
                best_symbol = symbol
        return best_symbol, float(best_score or 0.0)

    def route_prompt(self, prompt: str) -> dict[str, object]:
        analysis = self.understand_input(prompt)
        intent, intent_score = self.infer_intent(prompt)
        action, action_score = self.choose_action(prompt, intent)
        tokens = list(analysis["tokens"])
        content_tokens = list(analysis["content_tokens"]) or tokens
        probe = self.semantic_probe(analysis)
        fact_answer = self.answer_with_facts(analysis)
        ranked: list[tuple[str, float]] = []
        prediction = fact_answer
        deliberated = fact_answer
        if fact_answer is None and action in {"action:predict", "action:generate", "action:inspect"}:
            ranked = self.rank_candidates(content_tokens, recent_tokens=content_tokens, limit=3)
            prediction = ranked[0][0] if ranked else None
            deliberated = self.deliberate_next(content_tokens, recent_tokens=content_tokens, ranked=ranked)
        episode_id, episode_hint = self.retrieve_episode(probe)
        if fact_answer is not None:
            sample = self.compose_answer(analysis, fact_answer)
        elif action == "action:generate" and content_tokens:
            sample = self.generate(" ".join(content_tokens), steps=4)
        elif action == "action:clarify":
            sample = "Please give a narrower example or a shorter local corpus."
        elif action == "action:inspect":
            best, rendered = self.inspect_best(" ".join(content_tokens) or prompt)
            sample = f"inspect best={best} compare={rendered}"
        elif action == "action:teach":
            sample = "Use `teach <text>` to add a new training example."
        elif content_tokens and prediction:
            sample = self.compose_uncertain_answer(analysis, prediction)
        else:
            sample = self.compose_uncertain_answer(analysis, None)
        return {
            "understanding": self.render_understanding(analysis),
            "intent": intent,
            "intent_score": intent_score,
            "action": action,
            "action_score": action_score,
            "fact_answer": fact_answer,
            "prediction": prediction,
            "deliberated": deliberated,
            "ranked": ranked,
            "episode_id": episode_id,
            "episode_hint": episode_hint,
            "sample": sample,
        }

    def understand_input(self, prompt: str) -> dict[str, object]:
        cache_key = prompt.strip().lower()
        cached = self.analysis_cache.get(cache_key)
        if cached is not None:
            return {
                "tokens": list(cached["tokens"]),
                "form": cached["form"],
                "query_word": cached["query_word"],
                "command_word": cached["command_word"],
                "content_tokens": list(cached["content_tokens"]),
                "subject": cached["subject"],
                "predicate": cached["predicate"],
                "object_tokens": list(cached["object_tokens"]),
            }
        tokens = self.tokenize(prompt)
        lowered = prompt.lower().strip()
        query_word = next((token for token in tokens if token in self.question_words), None)
        command_word = tokens[0] if tokens and tokens[0] in self.command_words else None
        if lowered.startswith(("teach ", "focus ", "inspect ")):
            form = "form:command"
        elif lowered.endswith("?") or query_word:
            form = "form:question"
        elif len(tokens) >= 2:
            form = "form:statement"
        else:
            form = "form:fragment"

        content_tokens = self._extract_content_tokens(tokens, query_word=query_word, command_word=command_word)
        if not content_tokens and command_word and len(tokens) > 1:
            content_tokens = tokens[1:]

        subject, predicate, object_tokens = self._parse_relation_fields(content_tokens, form=form, query_word=query_word)
        analysis = {
            "tokens": tokens,
            "form": form,
            "query_word": query_word,
            "command_word": command_word,
            "content_tokens": content_tokens,
            "subject": subject,
            "predicate": predicate,
            "object_tokens": object_tokens,
        }
        self.analysis_cache[cache_key] = {
            "tokens": list(tokens),
            "form": form,
            "query_word": query_word,
            "command_word": command_word,
            "content_tokens": list(content_tokens),
            "subject": subject,
            "predicate": predicate,
            "object_tokens": list(object_tokens),
        }
        return analysis

    def _extract_content_tokens(
        self,
        tokens: list[str],
        query_word: str | None,
        command_word: str | None,
    ) -> list[str]:
        content_tokens: list[str] = []
        query_consumed = False
        for index, token in enumerate(tokens):
            if index == 0 and token == command_word:
                continue
            if not query_consumed and index == 0 and token == query_word:
                query_consumed = True
                continue
            if token in self.function_words and token not in self.relation_words:
                continue
            content_tokens.append(token)
        return content_tokens

    def _trim_object_tokens(self, tokens: list[str]) -> list[str]:
        trimmed = list(tokens)
        while trimmed and trimmed[0] in {"a", "an", "the"}:
            trimmed = trimmed[1:]
        return trimmed

    def _canonical_predicate(self, token: str | None) -> str | None:
        if not token:
            return None
        aliases = {
            "are": "is",
            "was": "is",
            "were": "is",
            "mean": "means",
            "become": "becomes",
            "have": "has",
        }
        normalized = token.lower()
        return aliases.get(normalized, normalized)

    def _predicate_variants(self, predicate: str | None) -> set[str]:
        if not predicate:
            return set()
        canonical = self._canonical_predicate(predicate)
        variants = {canonical} if canonical else set()
        if canonical == "is":
            variants.update({"means", "becomes"})
        elif canonical in {"means", "becomes"}:
            variants.add("is")
        return variants

    def _parse_relation_fields(
        self,
        content_tokens: list[str],
        form: str,
        query_word: str | None,
    ) -> tuple[str | None, str | None, list[str]]:
        if not content_tokens:
            return None, None, []
        if len(content_tokens) == 1:
            return content_tokens[0], None, []
        if form == "form:statement" and len(content_tokens) == 3:
            middle = self._canonical_predicate(content_tokens[1])
            tail = self._canonical_predicate(content_tokens[2])
            if middle and tail:
                if self._predicate_distance(middle) <= self._predicate_distance(tail):
                    return content_tokens[0], middle, self._trim_object_tokens(content_tokens[2:])
                return " ".join(content_tokens[:2]), tail, []

        candidates: list[tuple[float, str, str, list[str]]] = []

        if query_word and content_tokens:
            leading_predicate = self._canonical_predicate(content_tokens[0])
            leading_subject_tokens = self._trim_object_tokens(content_tokens[1:])
            if leading_predicate and leading_subject_tokens:
                candidates.append(
                    (
                        self._score_relation_candidate(
                            leading_subject_tokens,
                            leading_predicate,
                            [],
                            form=form,
                            query_word=query_word,
                        ),
                        " ".join(leading_subject_tokens),
                        leading_predicate,
                        [],
                    )
                )

        max_predicate_index = min(len(content_tokens) - 1, 2)
        for predicate_index in range(1, max_predicate_index + 1):
            predicate = self._canonical_predicate(content_tokens[predicate_index])
            if not predicate:
                continue
            subject_tokens = content_tokens[:predicate_index]
            if not subject_tokens:
                continue
            object_tokens = self._trim_object_tokens(content_tokens[predicate_index + 1 :])
            score = self._score_relation_candidate(
                subject_tokens,
                predicate,
                object_tokens,
                form=form,
                query_word=query_word,
            )
            candidates.append((score, " ".join(subject_tokens), predicate, object_tokens))

        if not candidates:
            subject = content_tokens[0]
            predicate = self._canonical_predicate(content_tokens[1]) if len(content_tokens) > 1 else None
            object_tokens = self._trim_object_tokens(content_tokens[2:]) if len(content_tokens) > 2 else []
            return subject, predicate, object_tokens

        candidates.sort(key=lambda item: (item[0], len(item[1]), item[1]))
        _, subject, predicate, object_tokens = candidates[0]
        return subject, predicate, object_tokens

    def _looks_like_predicate(self, token: str) -> bool:
        lowered = token.lower()
        if lowered in self.relation_words:
            return True
        return self._predicate_distance(lowered) <= (self.dim * 0.82)

    def _predicate_distance(self, token: str) -> float:
        token_sig = self.build_reasoning_probe([token.lower()])
        predicate_sig = self._role_signature("role:predicate")
        return score_distance(self.dim, token_sig, predicate_sig)

    def _role_signature(self, symbol: str) -> list:
        samples = self.role_samples.get(symbol) or []
        if samples:
            probe = self.build_reasoning_probe(samples[- min(len(samples), self.topic_window) :])
            sig, _ = self.symbol_store.best_bank_signature(symbol, "reason", probe)
            return sig
        return self._symbol_signature(symbol)

    def _observe_role_tokens(self, symbol: str, tokens: list[str]) -> None:
        normalized = [token.lower().strip() for token in tokens if token.strip()]
        if not normalized:
            return
        known = [token for token in self.role_samples.get(symbol, []) if token.strip()]
        for token in normalized:
            if token in known:
                known = [item for item in known if item != token]
            known.append(token)
        self.role_samples[symbol] = known[-64:]

    def _refresh_role_symbols(self) -> None:
        for symbol, samples in self.role_samples.items():
            if samples:
                self._align_symbol(symbol, samples[- min(len(samples), self.topic_window) :])

    def _score_relation_candidate(
        self,
        subject_tokens: list[str],
        predicate: str,
        object_tokens: list[str],
        form: str,
        query_word: str | None,
    ) -> float:
        score = 0.0
        subject_sig = self.build_reasoning_probe(subject_tokens)
        predicate_distance = self._predicate_distance(predicate)
        score += 0.30 * score_distance(self.dim, subject_sig, self._role_signature("role:subject"))
        score += 0.45 * predicate_distance
        if object_tokens:
            object_sig = self.build_reasoning_probe(object_tokens)
            score += 0.20 * score_distance(self.dim, object_sig, self._role_signature("role:object"))
        else:
            score += self.dim * (0.08 if form == "form:statement" else 0.02)
            if form == "form:statement" and len(subject_tokens) > 1 and predicate not in self.relation_words:
                score += self.dim * 0.12

        if self._looks_like_predicate(predicate):
            score -= self.dim * 0.05
        if predicate in self.relation_words:
            score -= self.dim * 0.03
        if form == "form:statement" and len(subject_tokens) == 1 and len(object_tokens) == 1:
            score -= self.dim * 0.22
        if object_tokens:
            next_distance = self._predicate_distance(object_tokens[0])
            if next_distance + (self.dim * 0.02) < predicate_distance:
                score += 0.35 * (predicate_distance - next_distance)
            if self._looks_like_predicate(object_tokens[0]):
                score += self.dim * 0.18
                if len(subject_tokens) == 1 and predicate not in self.relation_words:
                    score += self.dim * 0.28
        if len(subject_tokens) == 1 and subject_tokens[0] in self.function_words:
            score += self.dim * 0.25
        if object_tokens and all(token in self.function_words for token in object_tokens):
            score += self.dim * 0.15
        if query_word and predicate in self.relation_words:
            score -= self.dim * 0.02
        if self._direct_fact_match(subject=" ".join(subject_tokens), predicate=predicate) is not None:
            score -= self.dim * 0.08
        if object_tokens and self._direct_fact_match(predicate=predicate, object_tokens=object_tokens) is not None:
            score -= self.dim * 0.05
        return score

    def semantic_probe(self, analysis: dict[str, object]) -> list:
        probe_key = (
            analysis["form"],
            analysis.get("query_word"),
            analysis.get("command_word"),
            tuple(analysis["content_tokens"]) or tuple(analysis["tokens"]),
        )
        cached = self.semantic_probe_cache.get(probe_key)
        if cached is not None:
            return cached
        base_tokens = list(analysis["content_tokens"]) or list(analysis["tokens"])
        probe = self.build_reasoning_probe(base_tokens)
        probe = add(probe, self._symbol_signature(str(analysis["form"])))
        query_word = analysis.get("query_word")
        if query_word:
            probe = add(probe, self._symbol_signature(f"query:{query_word}"))
        command_word = analysis.get("command_word")
        if command_word:
            probe = add(probe, self._symbol_signature(f"command:{command_word}"))
        self.semantic_probe_cache[probe_key] = probe
        return probe

    def render_understanding(self, analysis: dict[str, object]) -> str:
        parts = [str(analysis["form"]).split(":", 1)[1]]
        if analysis.get("query_word"):
            parts.append(f"query={analysis['query_word']}")
        if analysis.get("command_word"):
            parts.append(f"command={analysis['command_word']}")
        if analysis.get("subject"):
            parts.append(f"subject={analysis['subject']}")
        if analysis.get("predicate"):
            parts.append(f"predicate={analysis['predicate']}")
        object_tokens = list(analysis.get("object_tokens") or [])
        if object_tokens:
            parts.append(f"object={' '.join(object_tokens)}")
        return " | ".join(parts)

    def answer_with_facts(self, analysis: dict[str, object]) -> str | None:
        if not self.fact_order:
            return None
        if analysis.get("form") != "form:question":
            return None
        query_word = analysis.get("query_word")
        content_tokens = list(analysis.get("content_tokens") or [])
        subject = analysis.get("subject")
        predicate = analysis.get("predicate")
        object_tokens = list(analysis.get("object_tokens") or [])
        if not content_tokens:
            return None
        if content_tokens[:2] == ["comes", "after"] or content_tokens[:1] == ["next"]:
            return None

        direct = self._direct_fact_answer(
            query_word=query_word,
            content_tokens=content_tokens,
            subject=str(subject) if subject else None,
            predicate=str(predicate) if predicate else None,
            object_tokens=object_tokens,
        )
        if direct is not None:
            return direct

        candidates: list[tuple[float, str]] = []
        if subject and predicate:
            forward_probe = self.build_reasoning_probe([str(subject), str(predicate)])
            fact, score = self.retrieve_fact(forward_probe, direction="forward")
            if fact and score is not None and score <= self.fact_match_threshold:
                candidates.append((score, " ".join(str(token) for token in fact["object_tokens"])))

        if query_word in {"what", "who"} and predicate and object_tokens:
            inverse_probe = self.build_reasoning_probe([str(predicate)] + object_tokens)
            fact, score = self.retrieve_fact(inverse_probe, direction="inverse")
            if fact and score is not None and score <= self.fact_match_threshold:
                candidates.append((score, str(fact["subject"])))

        if candidates:
            candidates.sort(key=lambda item: (item[0], item[1]))
            return candidates[0][1]
        return None

    def compose_answer(self, analysis: dict[str, object], fact_answer: str) -> str:
        content_tokens = list(analysis.get("content_tokens") or [])
        query_word = analysis.get("query_word")
        if analysis.get("form") != "form:question":
            return self._ensure_terminal_punctuation(fact_answer)
        subject = analysis.get("subject")
        predicate = analysis.get("predicate")
        object_tokens = list(analysis.get("object_tokens") or [])
        if not subject or not predicate:
            return self._ensure_terminal_punctuation(fact_answer)

        direct = self._direct_fact_match(subject=str(subject), predicate=str(predicate))
        if direct is not None and " ".join(direct["object_tokens"]) == fact_answer:
            return self._ensure_terminal_punctuation(f"{subject} {predicate} {fact_answer}")

        if query_word in {"what", "who"} and object_tokens:
            inverse = self._direct_fact_match(predicate=str(predicate), object_tokens=object_tokens)
            if inverse is not None and inverse["subject"] == fact_answer:
                rendered_tail = " ".join([str(predicate), *object_tokens])
                return self._ensure_terminal_punctuation(f"{fact_answer} {rendered_tail}")

        if query_word in {"where", "how", "when"}:
            return self._ensure_terminal_punctuation(f"{subject} {predicate} {fact_answer}")
        return self._ensure_terminal_punctuation(fact_answer)

    def compose_uncertain_answer(self, analysis: dict[str, object], prediction: str | None) -> str:
        if analysis.get("form") == "form:question":
            if prediction:
                return f"I do not have a stable fact yet. The strongest trace continuation is '{prediction}'."
            return "I do not have a stable trace for that yet."
        if prediction:
            content_tokens = list(analysis.get("content_tokens") or [])
            stem = " ".join(content_tokens) if content_tokens else " ".join(analysis.get("tokens") or [])
            return self._ensure_terminal_punctuation(f"{stem} {prediction}".strip())
        return "I do not have a stable trace for that yet."

    def deliberate_next(
        self,
        tokens: list[str],
        recent_tokens: list[str] | None = None,
        width: int = 3,
        ranked: list[tuple[str, float]] | None = None,
    ) -> str | None:
        ranked = ranked or self.rank_candidates(tokens, recent_tokens=recent_tokens, limit=width)
        if not ranked:
            return None
        best_word = None
        best_score = None
        recent = list(recent_tokens or tokens)
        for word, score in ranked:
            future = self.rank_candidates(tokens + [word], recent_tokens=recent + [word], limit=1)
            future_score = future[0][1] if future else 0.0
            total = score + (0.35 * future_score)
            if best_score is None or total < best_score or (total == best_score and word < best_word):
                best_score = total
                best_word = word
        return best_word

    def rank_candidates(
        self, tokens: list[str], recent_tokens: list[str] | None = None, limit: int = 5
    ) -> list[tuple[str, float]]:
        candidates = self._candidate_words()
        if not candidates:
            return []
        context_sig = self.build_context(tokens)
        topic_sig = self.build_topic_context(tokens)
        recent = {(token.lower()) for token in (recent_tokens or tokens)[-self.recent_window :]}
        allow_fresh = any(word not in recent for word in candidates)
        ranked: list[tuple[str, float]] = []
        for word in candidates:
            lexical_sig = self.trace_store.primary_signature(word)
            context_bank_sig, _ = self.trace_store.best_bank_signature(word, "context", context_sig)
            topic_bank_sig, _ = self.trace_store.best_bank_signature(word, "topic", topic_sig)
            lexical_score = score_distance(self.dim, context_sig, lexical_sig)
            context_score = score_distance(self.dim, context_sig, context_bank_sig)
            topic_score = score_distance(self.dim, topic_sig, topic_bank_sig)
            total = (0.55 * context_score) + (0.25 * topic_score) + (0.20 * lexical_score)
            if allow_fresh and word in recent:
                total += self.repetition_penalty * self.dim
            ranked.append((word, total))
        ranked.sort(key=lambda item: (item[1], item[0]))
        return ranked[: max(1, int(limit))]

    def train_on_text(
        self,
        text: str,
        epochs: int,
        max_trace_updates: int | None = None,
        predict_during_training: bool = True,
        persist: bool = True,
    ) -> None:
        self.clear_runtime_caches()
        tokens = self.tokenize(text)
        if len(tokens) < 2:
            return
        for token in dict.fromkeys(tokens):
            self.add_word(token)
        for token in tokens[-self.focus_limit :]:
            self._remember_focus_word(token)
        self.register_facts_bulk(self.extract_relations(text))
        cursors = self._training_cursors(len(tokens), max_trace_updates)
        for _ in range(max(1, int(epochs))):
            for cursor in cursors:
                context_tokens = tokens[max(0, cursor - self.context_window) : cursor]
                topic_tokens = tokens[max(0, cursor - self.topic_window) : cursor]
                actual = tokens[cursor]
                predicted = (
                    self.predict_next(context_tokens, recent_tokens=context_tokens) if predict_during_training else actual
                )
                self.update_word_vector(actual, self.build_context(context_tokens), self.build_topic_context(topic_tokens), predicted)
        self.clear_runtime_caches()
        if persist:
            self.save_state()

    def train_corpus_fast(self, text: str, trace_budget: int = 192, persist: bool = True) -> None:
        self.train_on_text(
            text,
            epochs=1,
            max_trace_updates=max(1, int(trace_budget)),
            predict_during_training=False,
            persist=persist,
        )

    def update_word_vector(self, actual_word: str, context_sig: list, topic_sig: list, predicted_word: str | None) -> None:
        actual = actual_word.lower()
        self.add_word(actual)
        self._remember_focus_word(actual)
        actual_vector = list(self.trace_store.primary_vector(actual))
        context_sig_actual = self.trace_store.primary_signature(actual)
        context_row = self.trace_store.best_bank_signature(actual, "context", context_sig)[1]
        topic_row = self.trace_store.best_bank_signature(actual, "topic", topic_sig)[1]
        actual_context_row = list(self.trace_store.bank_row(actual, "context", context_row))
        actual_topic_row = list(self.trace_store.bank_row(actual, "topic", topic_row))
        context_marks = context_indices(context_sig)
        topic_marks = context_indices(topic_sig)
        promote = context_indices(compare(context_sig_actual, context_sig))
        prune = context_indices(compare(context_sig, context_sig_actual))

        for index in self._pick_indices(context_marks, actual_context_row, present=False):
            actual_context_row = flip_index(actual_context_row, index)
        for index in self._pick_indices(topic_marks, actual_topic_row, present=False):
            actual_topic_row = flip_index(actual_topic_row, index)
        self.trace_store.set_bank_row(actual, "context", context_row, self.trace_store.enforce_sparsity(actual_context_row))
        self.trace_store.set_bank_row(actual, "topic", topic_row, self.trace_store.enforce_sparsity(actual_topic_row))

        if predicted_word != actual:
            for index in self._pick_indices(promote, actual_vector, present=False):
                actual_vector = flip_index(actual_vector, index)
            for index in self._pick_indices(prune, actual_vector, present=True):
                actual_vector = flip_index(actual_vector, index)
            self.trace_store.set_primary(actual, self.trace_store.enforce_sparsity(actual_vector))
            self._inhibit_prediction(predicted_word, context_marks, topic_marks, context_sig, topic_sig)
        else:
            for index in self._pick_indices(promote, actual_vector, present=False):
                actual_vector = flip_index(actual_vector, index)
            self.trace_store.set_primary(actual, self.trace_store.enforce_sparsity(actual_vector))

    def generate(self, prompt: str, steps: int) -> str:
        generated = self.tokenize(prompt)
        for _ in range(max(0, int(steps))):
            next_word = self.deliberate_next(generated, recent_tokens=generated)
            if not next_word:
                break
            generated.append(next_word)
        return " ".join(generated)

    def average_sparsity(self) -> float:
        return self.trace_store.average_sparsity()

    def fact_count(self) -> int:
        return sum(1 for fact_id in self.fact_index if self._fact_is_active(fact_id))

    def clear_runtime_caches(self) -> None:
        self.analysis_cache.clear()
        self.semantic_probe_cache.clear()

    def warm_vocabulary(self, text: str) -> int:
        added = 0
        for token in dict.fromkeys(self.tokenize(text)):
            if token not in GLOBAL_INDEX:
                added += 1
            self.add_word(token)
        return added

    def ensure_vocabulary(self, tokens: list[str]) -> int:
        added = 0
        for token in tokens:
            normalized = token.lower().strip()
            if not normalized:
                continue
            if normalized not in GLOBAL_INDEX:
                added += 1
            self.add_word(normalized)
        return added

    def train_sentence_batch(
        self,
        sentences: list[str],
        trace_budget_per_sentence: int = 96,
        full_train_every: int = 8,
    ) -> dict[str, int]:
        if not sentences:
            return {"sentences": 0, "vocabulary_added": 0}
        vocab_added = 0
        accepted = 0
        interval = max(1, int(full_train_every))
        for index, sentence in enumerate(sentences, start=1):
            tokens = self.tokenize(sentence)
            if len(tokens) < 2:
                continue
            vocab_added += self.ensure_vocabulary(tokens)
            if index % interval == 0:
                self.train_on_text(
                    sentence,
                    epochs=1,
                    max_trace_updates=max(1, int(trace_budget_per_sentence)),
                    persist=False,
                )
            else:
                self.train_corpus_fast(
                    sentence,
                    trace_budget=max(1, int(trace_budget_per_sentence)),
                    persist=False,
                )
            accepted += 1
        if accepted:
            self.apply_fact_decay(keep_recent=48, amount=1)
        self.save_state()
        return {"sentences": accepted, "vocabulary_added": vocab_added}

    def ingest_text_corpus(
        self,
        text: str,
        trace_budget_per_sentence: int = 96,
        full_train_every: int = 8,
        sentence_limit: int | None = None,
    ) -> dict[str, int]:
        sentences = iter_sentences(text, max_sentences=sentence_limit)
        definition_sentences = extract_dictionary_facts(text, max_entries=sentence_limit or 256)
        merged: list[str] = []
        seen: set[str] = set()
        for sentence in [*definition_sentences, *sentences]:
            if sentence in seen:
                continue
            seen.add(sentence)
            merged.append(sentence)
        metrics = self.train_sentence_batch(
            merged,
            trace_budget_per_sentence=trace_budget_per_sentence,
            full_train_every=full_train_every,
        )
        metrics["facts"] = len(definition_sentences)
        return metrics

    def ingest_file(
        self,
        path: str,
        trace_budget_per_sentence: int = 96,
        full_train_every: int = 8,
        sentence_limit: int | None = None,
    ) -> dict[str, int]:
        return self.ingest_text_corpus(
            load_text_file(path),
            trace_budget_per_sentence=trace_budget_per_sentence,
            full_train_every=full_train_every,
            sentence_limit=sentence_limit,
        )

    def ingest_url(
        self,
        url: str,
        trace_budget_per_sentence: int = 96,
        full_train_every: int = 8,
        sentence_limit: int = 128,
    ) -> dict[str, int]:
        text = fetch_url_text(url)
        metrics = self.ingest_text_corpus(
            text,
            trace_budget_per_sentence=trace_budget_per_sentence,
            full_train_every=full_train_every,
            sentence_limit=sentence_limit,
        )
        metrics["url"] = 1
        return metrics

    def compare_distance_to(self, tokens: list[str], word: str) -> float:
        self.add_word(word)
        return score_distance(self.dim, self.build_context(tokens), self.trace_store.primary_signature(word.lower()))

    def extract_relations(self, text: str) -> list[tuple[str, str, list[str]]]:
        relations: list[tuple[str, str, list[str]]] = []
        for sentence in re.split(r"[.!?;\n]+", text):
            for clause in re.split(r"\band\b", sentence):
                tokens = self.tokenize(clause)
                content_tokens = self._extract_content_tokens(tokens, query_word=None, command_word=None)
                subject, predicate, object_tokens = self._parse_relation_fields(
                    content_tokens,
                    form="form:statement",
                    query_word=None,
                )
                if not subject or not predicate:
                    continue
                object_tokens = list(object_tokens[: self.max_relation_object])
                if not object_tokens:
                    continue
                if subject in self.function_words or predicate in self.function_words:
                    continue
                relations.append((subject, predicate, object_tokens))
        return relations

    def register_fact(self, subject: str, predicate: str, object_tokens: list[str]) -> str:
        fact_id = self._register_fact_internal(subject, predicate, object_tokens)
        self._refresh_role_symbols()
        self.clear_runtime_caches()
        return fact_id

    def register_facts_bulk(self, relations: list[tuple[str, str, list[str]]]) -> int:
        added = 0
        for subject, predicate, object_tokens in relations:
            self._register_fact_internal(subject, predicate, object_tokens)
            added += 1
        if added:
            self._refresh_role_symbols()
            self.clear_runtime_caches()
        return added

    def _register_fact_internal(self, subject: str, predicate: str, object_tokens: list[str]) -> str:
        normalized_subject = subject.lower()
        normalized_predicate = predicate.lower()
        normalized_object = [token.lower() for token in object_tokens if token.strip()]
        if not normalized_subject or not normalized_predicate or not normalized_object:
            raise ValueError("facts require subject, predicate, and object")
        for token in [normalized_subject, normalized_predicate, *normalized_object]:
            self.add_word(token)
        fact_key = f"{normalized_subject}|{normalized_predicate}|{' '.join(normalized_object)}"
        fact_id = self._ensure_fact(fact_key, normalized_subject, normalized_predicate, normalized_object)
        self._observe_role_tokens("role:subject", normalized_subject.split())
        self._observe_role_tokens("role:predicate", [normalized_predicate])
        self._observe_role_tokens("role:object", normalized_object)
        self._weaken_conflicting_facts(fact_id, normalized_subject, normalized_predicate, normalized_object)
        self._strengthen_fact(fact_id)
        primary = list(self.fact_store.primary_vector(fact_id))
        full_probe = self.build_reasoning_probe([normalized_subject, normalized_predicate] + normalized_object)
        forward_probe = self.build_reasoning_probe([normalized_subject, normalized_predicate])
        inverse_probe = self.build_reasoning_probe([normalized_predicate] + normalized_object)
        marks = context_indices(full_probe)
        for index in self._pick_indices(marks, primary, present=False):
            primary = flip_index(primary, index)
        self.fact_store.set_primary(fact_id, self.fact_store.enforce_sparsity(primary))
        self._align_fact_bank(fact_id, "forward", forward_probe)
        self._align_fact_bank(fact_id, "inverse", inverse_probe)
        self.fact_order = [known for known in self.fact_order if known != fact_id]
        self.fact_order.append(fact_id)
        self.fact_order = self.fact_order[-128:]
        return fact_id

    def retrieve_fact(self, probe: list, direction: str) -> tuple[dict[str, object] | None, float | None]:
        if direction not in {"forward", "inverse"}:
            raise ValueError("direction must be 'forward' or 'inverse'")
        best_id = None
        best_score = None
        for fact_id in self.fact_order[-64:]:
            if fact_id not in self.fact_index or not self._fact_is_active(fact_id):
                continue
            bank_sig, _ = self.fact_store.best_bank_signature(fact_id, direction, probe)
            lexical_sig = self.fact_store.primary_signature(fact_id)
            score = (0.75 * score_distance(self.dim, probe, bank_sig)) + (0.25 * score_distance(self.dim, probe, lexical_sig))
            score -= min(self.dim * 0.04, self._fact_strength_value(fact_id) * 4.0)
            if best_score is None or score < best_score:
                best_score = score
                best_id = fact_id
        if best_id is None:
            return None, None
        return self.fact_meta.get(best_id), float(best_score)

    def _direct_fact_answer(
        self,
        query_word: str | None,
        content_tokens: list[str],
        subject: str | None,
        predicate: str | None,
        object_tokens: list[str],
    ) -> str | None:
        if subject and predicate:
            forward = self._direct_fact_match(subject=subject, predicate=predicate)
            if forward is not None:
                return " ".join(str(token) for token in forward["object_tokens"])

        if len(content_tokens) < 2:
            return None

        if subject is None or predicate is None:
            subject = content_tokens[0]
            predicate = content_tokens[1]
        forward = self._direct_fact_match(subject=subject, predicate=predicate)
        if forward is not None:
            return " ".join(str(token) for token in forward["object_tokens"])

        if query_word in {"what", "who"} and object_tokens:
            inverse = self._direct_fact_match(predicate=predicate, object_tokens=object_tokens)
            if inverse is not None:
                return str(inverse["subject"])
        return None

    def _direct_fact_match(
        self,
        subject: str | None = None,
        predicate: str | None = None,
        object_tokens: list[str] | None = None,
    ) -> dict[str, object] | None:
        wanted_subject = subject.lower() if subject else None
        wanted_predicates = self._predicate_variants(predicate.lower()) if predicate else set()
        wanted_object = [token.lower() for token in (object_tokens or [])]
        for fact_id in reversed(self.fact_order):
            fact = self.fact_meta.get(fact_id)
            if fact is None:
                continue
            if not self._fact_is_active(fact_id):
                continue
            if wanted_subject is not None and fact["subject"] != wanted_subject:
                continue
            if wanted_predicates and fact["predicate"] not in wanted_predicates:
                continue
            if object_tokens is not None and fact["object_tokens"] != wanted_object:
                continue
            return fact
        return None

    def _fact_strength_value(self, fact_id: str) -> float:
        value = self.fact_strength.get(fact_id)
        if value is None:
            return 0.0
        if hasattr(value, "is_present") and getattr(value, "is_present", False):
            return float(getattr(value, "value", 0.0))
        return 0.0

    def _fact_is_active(self, fact_id: str) -> bool:
        return self._fact_strength_value(fact_id) > 0.0

    def _serialize_fact_strength(self, value: object) -> str:
        rendered = format_result(value)
        return "0" if rendered == "void" else rendered

    def _strengthen_fact(self, fact_id: str) -> None:
        current = self.fact_strength.get(fact_id)
        if current is None:
            self.fact_strength[fact_id] = n(1)
            return
        boosted = add(current, n(1))
        self.fact_strength[fact_id] = boosted if hasattr(boosted, "is_present") else current

    def _weaken_fact(self, fact_id: str, amount: int = 1) -> None:
        current = self.fact_strength.get(fact_id, n(1))
        result = current
        for _ in range(max(1, int(amount))):
            try:
                result = erase(result, n(1))
            except Exception:
                result = subtract(current, n(1))
                break
            current = self._normalize_fact_strength(result)
            result = current
        self.fact_strength[fact_id] = self._normalize_fact_strength(result)

    def _normalize_fact_strength(self, value: object) -> object:
        if hasattr(value, "is_present"):
            return value
        remainder = getattr(value, "remainder", None)
        if remainder is not None:
            return self._normalize_fact_strength(remainder)
        return solve("0")

    def _weaken_conflicting_facts(
        self,
        fact_id: str,
        subject: str,
        predicate: str,
        object_tokens: list[str],
    ) -> None:
        for known_id in list(self.fact_order):
            if known_id == fact_id:
                continue
            fact = self.fact_meta.get(known_id)
            if fact is None:
                continue
            if fact["subject"] != subject or fact["predicate"] != predicate:
                continue
            if fact["object_tokens"] == object_tokens:
                continue
            self._weaken_fact(known_id, amount=1)

    def apply_fact_decay(self, keep_recent: int = 32, amount: int = 1) -> int:
        decayed = 0
        cutoff = max(0, len(self.fact_order) - max(0, int(keep_recent)))
        for fact_id in self.fact_order[:cutoff]:
            if not self._fact_is_active(fact_id):
                continue
            self._weaken_fact(fact_id, amount=amount)
            decayed += 1
        return decayed

    def inspect_best(self, prompt: str) -> tuple[str | None, str]:
        tokens = self.tokenize(prompt)
        ranked = self.rank_candidates(tokens, recent_tokens=tokens, limit=1)
        if not ranked:
            return None, "[]"
        word = ranked[0][0]
        rendered = format_result(compare(self.build_context(tokens), self.trace_store.primary_signature(word)))
        if len(rendered) > 220:
            rendered = f"{rendered[:220]}..."
        return word, rendered

    def save_state(self) -> None:
        payload = {
            "dim": self.dim,
            "sparsity": self.sparsity,
            "focus_words": self.focus_words[-self.focus_limit :],
            "active_words": sorted(self.active_words),
            "trace_store": self.trace_store.snapshot(),
            "symbol_index": self.symbol_index,
            "symbol_store": self.symbol_store.snapshot(),
            "role_samples": self.role_samples,
            "episode_index": self.episode_index,
            "episode_meta": self.episode_meta,
            "episode_order": self.episode_order[-64:],
            "episode_store": self.episode_store.snapshot(),
            "fact_index": self.fact_index,
            "fact_meta": self.fact_meta,
            "fact_strength": {
                key: self._serialize_fact_strength(value)
                for key, value in self.fact_strength.items()
                if key in self.fact_index
            },
            "fact_order": self.fact_order[-128:],
            "fact_store": self.fact_store.snapshot(),
        }
        MODEL_STATE_PATH.write_text(json.dumps(payload), encoding="utf-8")

    def _load_state(self) -> None:
        if not MODEL_STATE_PATH.exists():
            return
        try:
            payload = json.loads(MODEL_STATE_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if payload.get("dim") != self.dim or payload.get("sparsity") != self.sparsity:
            return
        self.active_words = {
            word for word in payload.get("active_words", []) if isinstance(word, str) and word in GLOBAL_INDEX
        }
        self.symbol_index = {
            key: int(value)
            for key, value in payload.get("symbol_index", {}).items()
            if isinstance(key, str)
        }
        loaded_role_samples = payload.get("role_samples", {})
        if isinstance(loaded_role_samples, dict):
            for symbol in self.role_samples:
                values = loaded_role_samples.get(symbol, [])
                if isinstance(values, list):
                    self.role_samples[symbol] = [str(token).lower() for token in values if str(token).strip()][-64:]
        self.episode_index = {
            key: int(value)
            for key, value in payload.get("episode_index", {}).items()
            if isinstance(key, str)
        }
        self.episode_meta = {
            key: value for key, value in payload.get("episode_meta", {}).items() if isinstance(key, str) and isinstance(value, str)
        }
        self.episode_order = [
            key for key in payload.get("episode_order", []) if isinstance(key, str) and key in self.episode_index
        ][-64:]
        self.fact_index = {
            key: int(value)
            for key, value in payload.get("fact_index", {}).items()
            if isinstance(key, str)
        }
        self.fact_meta = {}
        for key, value in payload.get("fact_meta", {}).items():
            if not isinstance(key, str) or not isinstance(value, dict):
                continue
            subject = value.get("subject")
            predicate = value.get("predicate")
            object_tokens = value.get("object_tokens")
            if isinstance(subject, str) and isinstance(predicate, str) and isinstance(object_tokens, list):
                self.fact_meta[key] = {
                    "subject": subject,
                    "predicate": predicate,
                    "object_tokens": [str(token) for token in object_tokens],
                }
        self.fact_strength = {}
        for key, value in payload.get("fact_strength", {}).items():
            if not isinstance(key, str) or key not in self.fact_index or not isinstance(value, str):
                continue
            try:
                parsed = solve("0" if value == "void" else value)
            except Exception:
                continue
            self.fact_strength[key] = parsed
        self.fact_order = [
            key for key in payload.get("fact_order", []) if isinstance(key, str) and key in self.fact_index
        ][-128:]
        self.focus_words = [
            word for word in payload.get("focus_words", []) if isinstance(word, str) and word in GLOBAL_INDEX
        ][-self.focus_limit :]
        self.trace_store.restore(payload.get("trace_store", {}), self.active_words)
        self.symbol_store.restore(payload.get("symbol_store", {}), set(self.symbol_index))
        self.episode_store.restore(payload.get("episode_store", {}), set(self.episode_index))
        self.fact_store.restore(payload.get("fact_store", {}), set(self.fact_index))
        for word in list(self.active_words):
            self.trace_store.ensure(word, GLOBAL_INDEX[word])
        for symbol, index in self.symbol_index.items():
            self.symbol_store.ensure(symbol, index)
        self._refresh_role_symbols()
        for episode_id, index in self.episode_index.items():
            self.episode_store.ensure(episode_id, index)
        for fact_id, index in self.fact_index.items():
            self.fact_store.ensure(fact_id, index)
            if fact_id not in self.fact_strength:
                self.fact_strength[fact_id] = n(1)

    def _combine_tokens(self, tokens: list[str]) -> list:
        normalized = [token.lower() for token in tokens if token.strip()]
        if not normalized:
            blank = blank_vector(self.dim)
            return combine(blank, blank)
        context = None
        for token in normalized:
            self.add_word(token)
            vector = self.trace_store.primary_vector(token)
            context = vector if context is None else combine(context, vector)
        return combine(context, context)

    def _candidate_words(self) -> list[str]:
        if self.focus_mode and self.focus_words:
            return list(dict.fromkeys(self.focus_words))
        return sorted(self.active_words)

    def build_reasoning_probe(self, tokens: list[str]) -> list:
        return combine(self.build_context(tokens), self.build_topic_context(tokens))

    def _remember_focus_word(self, word: str) -> None:
        normalized = word.lower()
        self.focus_words = [known for known in self.focus_words if known != normalized]
        self.focus_words.append(normalized)
        if len(self.focus_words) > self.focus_limit:
            self.focus_words = self.focus_words[-self.focus_limit :]

    def retrieve_episode(self, probe: list) -> tuple[str | None, str | None]:
        if not self.episode_order:
            return None, None
        best_id = None
        best_score = None
        for episode_id in self.episode_order[-16:]:
            sig, _ = self.episode_store.best_bank_signature(episode_id, "context", probe)
            lexical = self.episode_store.primary_signature(episode_id)
            score = (0.7 * score_distance(self.dim, probe, sig)) + (0.3 * score_distance(self.dim, probe, lexical))
            if best_score is None or score < best_score:
                best_score = score
                best_id = episode_id
        return best_id, self.episode_meta.get(best_id) if best_id else None

    def register_episode(self, prompt: str, response: str, intent: str, action: str) -> str:
        tokens = self.tokenize(prompt)
        probe = self.build_reasoning_probe(tokens)
        self._register_symbol(intent)
        self._register_symbol(action)
        intent_sig = self.symbol_store.primary_signature(intent)
        action_sig = self.symbol_store.primary_signature(action)
        episode_probe = add(add(probe, intent_sig), action_sig)
        episode_id = f"episode:{len(self.episode_index)}"
        self.episode_index[episode_id] = len(self.episode_index)
        self.episode_store.ensure(episode_id, self.episode_index[episode_id])
        row_index = self.episode_store.best_bank_signature(episode_id, "context", episode_probe)[1]
        row = list(self.episode_store.bank_row(episode_id, "context", row_index))
        primary = list(self.episode_store.primary_vector(episode_id))
        marks = context_indices(episode_probe)
        for index in self._pick_indices(marks, row, present=False):
            row = flip_index(row, index)
        for index in self._pick_indices(marks, primary, present=False):
            primary = flip_index(primary, index)
        self.episode_store.set_bank_row(episode_id, "context", row_index, self.episode_store.enforce_sparsity(row))
        self.episode_store.set_primary(episode_id, self.episode_store.enforce_sparsity(primary))
        summary = f"{intent} | {action} | {prompt[:80]} -> {response[:80]}"
        self.episode_meta[episode_id] = summary
        self.episode_order.append(episode_id)
        self.episode_order = self.episode_order[-64:]
        self.save_state()
        return episode_id

    def _bootstrap_symbol_semantics(self) -> None:
        semantic_anchors = {
            **self.intent_anchors,
            **self.action_anchors,
            **self.form_anchors,
            **self.query_anchors,
            **self.role_anchors,
        }
        for command in sorted(self.command_words):
            semantic_anchors[f"command:{command}"] = [command, "command"]
        for symbol, anchors in semantic_anchors.items():
            created = self._register_symbol(symbol)
            if created or symbol.startswith("role:"):
                self._align_symbol(symbol, anchors)
        self.clear_runtime_caches()

    def _ensure_fact(self, fact_key: str, subject: str, predicate: str, object_tokens: list[str]) -> str:
        fact_id = f"fact:{fact_key}"
        created = fact_id not in self.fact_index
        if created:
            self.fact_index[fact_id] = len(self.fact_index)
        self.fact_store.ensure(fact_id, self.fact_index[fact_id])
        self.fact_meta[fact_id] = {
            "subject": subject,
            "predicate": predicate,
            "object_tokens": list(object_tokens),
        }
        if created:
            self.fact_order.append(fact_id)
        return fact_id

    def _align_fact_bank(self, fact_id: str, bank_name: str, probe: list) -> None:
        row_index = self.fact_store.best_bank_signature(fact_id, bank_name, probe)[1]
        row = list(self.fact_store.bank_row(fact_id, bank_name, row_index))
        marks = context_indices(probe)
        for index in self._pick_indices(marks, row, present=False):
            row = flip_index(row, index)
        self.fact_store.set_bank_row(fact_id, bank_name, row_index, self.fact_store.enforce_sparsity(row))

    def _register_symbol(self, symbol: str) -> bool:
        created = symbol not in self.symbol_index
        if created:
            self.symbol_index[symbol] = len(self.symbol_index)
        self.symbol_store.ensure(symbol, self.symbol_index[symbol])
        return created

    def _align_symbol(self, symbol: str, anchors: list[str]) -> None:
        for anchor in anchors:
            self.add_word(anchor)
        probe = self.build_reasoning_probe(anchors)
        primary = list(self.symbol_store.primary_vector(symbol))
        row_index = self.symbol_store.best_bank_signature(symbol, "reason", probe)[1]
        memory = list(self.symbol_store.bank_row(symbol, "reason", row_index))
        marks = context_indices(probe)
        primary_marks = context_indices(compare(self.symbol_store.primary_signature(symbol), probe))
        for index in self._pick_indices(marks, memory, present=False):
            memory = flip_index(memory, index)
        for index in self._pick_indices(primary_marks, primary, present=False):
            primary = flip_index(primary, index)
        self.symbol_store.set_bank_row(symbol, "reason", row_index, self.symbol_store.enforce_sparsity(memory))
        self.symbol_store.set_primary(symbol, self.symbol_store.enforce_sparsity(primary))
        self.clear_runtime_caches()

    def _symbol_signature(self, symbol: str) -> list:
        self._register_symbol(symbol)
        return self.symbol_store.primary_signature(symbol)

    def _ensure_terminal_punctuation(self, text: str) -> str:
        cleaned = text.strip()
        if not cleaned:
            return cleaned
        if cleaned[-1] in ".!?":
            return cleaned
        return f"{cleaned}."

    def _training_cursors(self, token_count: int, max_trace_updates: int | None) -> list[int]:
        if token_count < 2:
            return []
        available = token_count - 1
        if max_trace_updates is None:
            if available <= 256:
                budget = available
            else:
                budget = 256
        else:
            budget = max(1, min(int(max_trace_updates), available))
        if budget >= available:
            return list(range(1, token_count))
        cursors: list[int] = []
        seen: set[int] = set()
        for step in range(budget):
            cursor = 1 + ((step * available) // budget)
            if cursor >= token_count:
                cursor = token_count - 1
            if cursor in seen:
                continue
            seen.add(cursor)
            cursors.append(cursor)
        if (token_count - 1) not in seen:
            cursors.append(token_count - 1)
        return cursors

    def _pick_indices(self, candidates: list[int], vector: list, present: bool) -> list[int]:
        picked: list[int] = []
        present_slots = self._present(vector)
        for index in candidates:
            if (index in present_slots) != present:
                continue
            picked.append(index)
            if len(picked) >= self.update_budget:
                break
        return picked

    def _present(self, vector: list) -> set[int]:
        return {idx for idx, item in enumerate(vector) if is_present(item)}

    def _inhibit_prediction(
        self,
        predicted_word: str | None,
        context_marks: list[int],
        topic_marks: list[int],
        context_sig: list,
        topic_sig: list,
    ) -> None:
        if not predicted_word or predicted_word not in GLOBAL_INDEX:
            return
        predicted = predicted_word.lower()
        self.add_word(predicted)
        vector = list(self.trace_store.primary_vector(predicted))
        context_row = self.trace_store.best_bank_signature(predicted, "context", context_sig)[1]
        topic_row = self.trace_store.best_bank_signature(predicted, "topic", topic_sig)[1]
        context_memory = list(self.trace_store.bank_row(predicted, "context", context_row))
        topic_memory = list(self.trace_store.bank_row(predicted, "topic", topic_row))
        for index in self._pick_indices(context_marks, context_memory, present=True):
            context_memory = flip_index(context_memory, index)
        for index in self._pick_indices(topic_marks, topic_memory, present=True):
            topic_memory = flip_index(topic_memory, index)
        self.trace_store.set_bank_row(predicted, "context", context_row, self.trace_store.enforce_sparsity(context_memory))
        self.trace_store.set_bank_row(predicted, "topic", topic_row, self.trace_store.enforce_sparsity(topic_memory))
        blocked = set(context_indices(compare(self.trace_store.primary_signature(predicted), context_sig)))
        for index in self._pick_indices(context_marks, vector, present=True):
            vector = flip_index(vector, index)
        self.trace_store.set_primary(predicted, self.trace_store.enforce_sparsity(vector, blocked_additions=blocked))


def run_interactive_test(model: PhantomLanguageModel) -> None:
    print("Interactive test: type a prompt and press Enter. Type 'quit' to stop.")
    print("Commands: teach <text>, ingest <file>, scrape <url>, focus on, focus off, focus <text>, inspect <prompt>")
    while True:
        try:
            prompt = input("prompt> ").strip()
        except EOFError:
            print()
            break
        if not prompt:
            continue
        lowered = prompt.lower()
        if lowered in {"quit", "exit"}:
            break
        if lowered == "focus on":
            model.set_focus_mode(True)
            print(f"focus mode: on ({len(model._candidate_words())} candidates)")
            continue
        if lowered == "focus off":
            model.set_focus_mode(False)
            print(f"focus mode: off ({len(model._candidate_words())} candidates)")
            continue
        if lowered.startswith("focus "):
            lesson = prompt[6:].strip()
            if lesson:
                model.set_focus_text(lesson)
                model.prime_focus(lesson)
                model.set_focus_mode(True)
                print(f"focus mode: primed on {len(model._candidate_words())} candidates")
            continue
        if lowered.startswith("teach "):
            lesson = prompt[6:].strip()
            if lesson:
                model.train_on_text(lesson, epochs=1)
                print(f"learned: one incremental training pass complete ({model.fact_count()} facts)")
            continue
        if lowered.startswith("ingest "):
            source = prompt[7:].strip()
            if source:
                try:
                    metrics = model.ingest_file(source)
                except OSError as exc:
                    print(f"ingest failed: {exc}")
                else:
                    print(
                        "ingested: "
                        f"{metrics['sentences']} sentences, "
                        f"{metrics['vocabulary_added']} new words, "
                        f"{metrics['facts']} definition facts"
                    )
            continue
        if lowered.startswith("scrape "):
            source = prompt[7:].strip()
            if source:
                try:
                    metrics = model.ingest_url(source)
                except (OSError, ValueError, urllib.error.URLError) as exc:
                    print(f"scrape failed: {exc}")
                else:
                    print(
                        "scraped: "
                        f"{metrics['sentences']} sentences, "
                        f"{metrics['vocabulary_added']} new words, "
                        f"{metrics['facts']} definition facts"
                    )
            continue
        if lowered.startswith("inspect "):
            best, rendered = model.inspect_best(prompt[8:].strip())
            print(f"inspect best={best}")
            print(f"compare: {rendered}")
            continue
        routed = model.route_prompt(prompt)
        print(f"understanding: {routed['understanding']}")
        print(f"intent: {routed['intent']} ({routed['intent_score']:.1f})")
        print(f"action: {routed['action']} ({routed['action_score']:.1f})")
        if routed["episode_hint"]:
            print(f"memory: {routed['episode_hint']}")
        if routed["fact_answer"] is not None:
            print("memory: fact-match")
        print(f"next: {routed['prediction']}")
        print(f"deliberated: {routed['deliberated']}")
        ranked = routed["ranked"]
        print(f"top: {', '.join(f'{word} ({score:.1f})' for word, score in ranked)}")
        print(f"sample: {routed['sample']}")
        model.register_episode(prompt, str(routed["sample"]), str(routed["intent"]), str(routed["action"]))
