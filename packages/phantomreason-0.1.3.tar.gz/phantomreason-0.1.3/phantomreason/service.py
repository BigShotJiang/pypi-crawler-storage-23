from __future__ import annotations

import argparse
import hmac
import json
import os
import sys
import threading
import time
from dataclasses import dataclass, field
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from .evaluate import run_evaluation
from .model import PhantomLanguageModel


MAX_REQUEST_BYTES = 256_000
MAX_PROMPT_CHARS = 4_000
MAX_TEXT_CHARS = 200_000
MAX_EPOCHS = 8
MAX_TRACE_BUDGET = 256
MAX_FULL_TRAIN_EVERY = 32
MAX_SENTENCE_LIMIT = 512


@dataclass
class ServiceMetrics:
    started_at: float = field(default_factory=time.time)
    requests_total: int = 0
    query_total: int = 0
    mutate_total: int = 0
    error_total: int = 0
    last_error: str | None = None

    def snapshot(self) -> dict[str, Any]:
        return {
            "uptime_seconds": round(time.time() - self.started_at, 3),
            "requests_total": self.requests_total,
            "query_total": self.query_total,
            "mutate_total": self.mutate_total,
            "error_total": self.error_total,
            "last_error": self.last_error,
        }


class PhantomAgentService:
    def __init__(self, model: PhantomLanguageModel, api_token: str | None = None):
        self.model = model
        self.lock = threading.RLock()
        self.metrics = ServiceMetrics()
        self.api_token = api_token.strip() if api_token else None

    def health(self) -> dict[str, Any]:
        with self.lock:
            return {
                "status": "ok",
                "metrics": self.metrics.snapshot(),
                "model": {
                    "dim": self.model.dim,
                    "sparsity": self.model.sparsity,
                    "vocabulary_size": len(self.model.active_words),
                    "fact_count": self.model.fact_count(),
                    "focus_mode": self.model.focus_mode,
                    "auth_enabled": bool(self.api_token),
                },
            }

    def evaluate(self) -> dict[str, Any]:
        result = run_evaluation()
        return {"status": "ok", "evaluation": result}

    def query(self, prompt: str) -> dict[str, Any]:
        with self.lock:
            self.metrics.query_total += 1
            prompt = self._normalize_text_field(prompt, "prompt", MAX_PROMPT_CHARS)
            routed = self.model.route_prompt(prompt)
            self.model.register_episode(prompt, str(routed["sample"]), str(routed["intent"]), str(routed["action"]))
            return {"status": "ok", "result": routed}

    def teach(self, text: str, epochs: int = 1) -> dict[str, Any]:
        with self.lock:
            self.metrics.mutate_total += 1
            text = self._normalize_text_field(text, "text", MAX_TEXT_CHARS)
            bounded_epochs = max(1, min(int(epochs), MAX_EPOCHS))
            self.model.train_on_text(text, epochs=bounded_epochs)
            return {
                "status": "ok",
                "result": {
                    "trained": True,
                    "epochs": bounded_epochs,
                    "fact_count": self.model.fact_count(),
                    "vocabulary_size": len(self.model.active_words),
                },
            }

    def ingest(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self.metrics.mutate_total += 1
            trace_budget = self._bounded_int(payload.get("trace_budget_per_sentence", 96), 1, MAX_TRACE_BUDGET)
            full_train_every = self._bounded_int(payload.get("full_train_every", 8), 1, MAX_FULL_TRAIN_EVERY)
            sentence_limit = payload.get("sentence_limit")
            bounded_sentence_limit = None
            if sentence_limit is not None:
                bounded_sentence_limit = self._bounded_int(sentence_limit, 1, MAX_SENTENCE_LIMIT)
            if "text" in payload:
                text = self._normalize_text_field(str(payload["text"]), "text", MAX_TEXT_CHARS)
                metrics = self.model.ingest_text_corpus(
                    text,
                    trace_budget_per_sentence=trace_budget,
                    full_train_every=full_train_every,
                    sentence_limit=bounded_sentence_limit,
                )
            elif "path" in payload:
                path = self._normalize_text_field(str(payload["path"]), "path", 4_096)
                metrics = self.model.ingest_file(
                    path,
                    trace_budget_per_sentence=trace_budget,
                    full_train_every=full_train_every,
                    sentence_limit=bounded_sentence_limit,
                )
            elif "url" in payload:
                url = self._normalize_text_field(str(payload["url"]), "url", 4_096)
                metrics = self.model.ingest_url(
                    url,
                    trace_budget_per_sentence=trace_budget,
                    full_train_every=full_train_every,
                    sentence_limit=bounded_sentence_limit or 128,
                )
            else:
                raise ValueError("ingest requires one of: text, path, url")
            return {"status": "ok", "result": metrics}

    def focus(self, enabled: bool | None = None, text: str | None = None) -> dict[str, Any]:
        with self.lock:
            self.metrics.mutate_total += 1
            if text:
                text = self._normalize_text_field(text, "text", MAX_PROMPT_CHARS)
                self.model.set_focus_text(text)
                self.model.prime_focus(text)
                self.model.set_focus_mode(True)
            elif enabled is not None:
                self.model.set_focus_mode(bool(enabled))
            return {
                "status": "ok",
                "result": {
                    "focus_mode": self.model.focus_mode,
                    "focus_words": list(self.model.focus_words),
                    "candidate_count": len(self.model._candidate_words()),
                },
            }

    def checkpoint(self) -> dict[str, Any]:
        with self.lock:
            self.metrics.mutate_total += 1
            self.model.save_state()
            return {"status": "ok", "result": {"saved": True}}

    def handle_error(self, message: str) -> dict[str, Any]:
        self.metrics.error_total += 1
        self.metrics.last_error = message
        return {"status": "error", "error": message}

    def is_authorized(self, header_value: str | None) -> bool:
        if not self.api_token:
            return True
        if not header_value:
            return False
        prefix = "Bearer "
        if not header_value.startswith(prefix):
            return False
        provided = header_value[len(prefix) :].strip()
        if not provided:
            return False
        return hmac.compare_digest(provided, self.api_token)

    def _normalize_text_field(self, value: str, field_name: str, limit: int) -> str:
        normalized = str(value).strip()
        if not normalized:
            raise ValueError(f"{field_name} is required")
        if len(normalized) > limit:
            raise ValueError(f"{field_name} exceeds maximum length of {limit}")
        return normalized

    def _bounded_int(self, value: Any, lower: int, upper: int) -> int:
        parsed = int(value)
        return max(lower, min(parsed, upper))


class PhantomAgentHandler(BaseHTTPRequestHandler):
    service: PhantomAgentService

    def do_GET(self) -> None:
        self.service.metrics.requests_total += 1
        if self.path == "/health":
            self._send_json(HTTPStatus.OK, self.service.health())
            return
        if not self._authorized():
            return
        if self.path == "/evaluate":
            self._send_json(HTTPStatus.OK, self.service.evaluate())
            return
        self._send_json(HTTPStatus.NOT_FOUND, self.service.handle_error("unknown endpoint"))

    def do_POST(self) -> None:
        self.service.metrics.requests_total += 1
        if not self._authorized():
            return
        try:
            payload = self._read_json()
            if self.path == "/query":
                prompt = str(payload.get("prompt", "")).strip()
                if not prompt:
                    raise ValueError("prompt is required")
                self._send_json(HTTPStatus.OK, self.service.query(prompt))
                return
            if self.path == "/teach":
                text = str(payload.get("text", "")).strip()
                if not text:
                    raise ValueError("text is required")
                self._send_json(HTTPStatus.OK, self.service.teach(text, epochs=int(payload.get("epochs", 1))))
                return
            if self.path == "/ingest":
                self._send_json(HTTPStatus.OK, self.service.ingest(payload))
                return
            if self.path == "/focus":
                enabled = payload.get("enabled")
                text = payload.get("text")
                self._send_json(
                    HTTPStatus.OK,
                    self.service.focus(enabled=bool(enabled) if enabled is not None else None, text=text),
                )
                return
            if self.path == "/checkpoint":
                self._send_json(HTTPStatus.OK, self.service.checkpoint())
                return
            self._send_json(HTTPStatus.NOT_FOUND, self.service.handle_error("unknown endpoint"))
        except Exception as exc:
            self._send_json(HTTPStatus.BAD_REQUEST, self.service.handle_error(str(exc)))

    def log_message(self, format: str, *args: Any) -> None:
        record = {
            "ts": round(time.time(), 3),
            "remote": self.address_string(),
            "message": format % args,
        }
        sys.stdout.write(json.dumps(record) + "\n")
        sys.stdout.flush()

    def _read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length > MAX_REQUEST_BYTES:
            raise ValueError(f"request body exceeds maximum size of {MAX_REQUEST_BYTES} bytes")
        raw = self.rfile.read(length) if length else b"{}"
        if not raw:
            return {}
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("request body must be a JSON object")
        return data

    def _authorized(self) -> bool:
        if self.service.is_authorized(self.headers.get("Authorization")):
            return True
        self._send_json_with_headers(
            HTTPStatus.UNAUTHORIZED,
            self.service.handle_error("unauthorized"),
            extra_headers={"WWW-Authenticate": "Bearer"},
        )
        return False

    def _send_json(self, status: HTTPStatus, payload: dict[str, Any]) -> None:
        self._send_json_with_headers(status, payload, extra_headers=None)

    def _send_json_with_headers(
        self,
        status: HTTPStatus,
        payload: dict[str, Any],
        extra_headers: dict[str, str] | None,
    ) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)


class PhantomThreadingHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def build_server(host: str, port: int, dim: int, sparsity: int, api_token: str | None = None) -> ThreadingHTTPServer:
    service = PhantomAgentService(PhantomLanguageModel(dim=dim, sparsity=sparsity), api_token=api_token)

    class BoundHandler(PhantomAgentHandler):
        pass

    BoundHandler.service = service
    return PhantomThreadingHTTPServer((host, port), BoundHandler)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the PhantomTrace agent service.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--dim", type=int, default=512)
    parser.add_argument("--sparsity", type=int, default=47)
    parser.add_argument("--api-token", default=None)
    args = parser.parse_args()

    api_token = args.api_token or os.environ.get("PHANTOM_AGENT_API_TOKEN")
    server = build_server(args.host, args.port, args.dim, args.sparsity, api_token=api_token)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    finally:
        server.server_close()
    return 0


__all__ = ["PhantomAgentService", "build_server", "main"]
