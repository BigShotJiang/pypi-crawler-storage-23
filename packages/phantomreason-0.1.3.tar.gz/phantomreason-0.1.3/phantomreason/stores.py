from __future__ import annotations

import random

from .traces import blank_vector, combine, present_count, present_indices, score_distance, toggle_slot


class TraceStore:
    """Persistent sparse traces plus one or more PhantomTrace memory banks per symbol."""

    def __init__(self, dim: int, sparsity: int, bank_shapes: dict[str, int], seed: int = 7):
        self.dim = dim
        self.sparsity = sparsity
        self.bank_shapes = dict(bank_shapes)
        self._rng = random.Random(seed)
        self.primary: dict[str, list] = {}
        self.banks: dict[str, dict[str, list[list]]] = {name: {} for name in self.bank_shapes}
        self.primary_signature_cache: dict[str, list] = {}
        self.bank_signature_cache: dict[tuple[str, str], list[list]] = {}

    def ensure(self, key: str, index: int) -> None:
        if key not in self.primary:
            self.primary[key] = self._initialize_vector(key, index)
        for bank_name, rows in self.bank_shapes.items():
            if key not in self.banks[bank_name]:
                self.banks[bank_name][key] = self._initialize_matrix(key, index, rows, bank_name)

    def primary_vector(self, key: str) -> list:
        return self.primary[key]

    def primary_signature(self, key: str) -> list:
        if key not in self.primary_signature_cache:
            vector = self.primary_vector(key)
            self.primary_signature_cache[key] = combine(vector, vector)
        return self.primary_signature_cache[key]

    def best_bank_signature(self, key: str, bank_name: str, probe_sig: list) -> tuple[list, int]:
        self._ensure_bank_cache(key, bank_name)
        best_score = None
        best_index = 0
        best_sig = self.bank_signature_cache[(bank_name, key)][0]
        for row_index, row_sig in enumerate(self.bank_signature_cache[(bank_name, key)]):
            score = score_distance(self.dim, probe_sig, row_sig)
            if best_score is None or score < best_score:
                best_score = score
                best_index = row_index
                best_sig = row_sig
        return best_sig, best_index

    def bank_row(self, key: str, bank_name: str, row_index: int) -> list:
        return self.banks[bank_name][key][row_index]

    def set_primary(self, key: str, vector: list) -> None:
        self.primary[key] = vector
        self.primary_signature_cache.pop(key, None)

    def set_bank_row(self, key: str, bank_name: str, row_index: int, vector: list) -> None:
        rows = [list(row) for row in self.banks[bank_name][key]]
        rows[row_index] = vector
        self.banks[bank_name][key] = rows
        self.bank_signature_cache.pop((bank_name, key), None)

    def enforce_sparsity(self, vector: list, blocked_additions: set[int] | None = None) -> list:
        blocked_additions = blocked_additions or set()
        active = set(present_indices(vector))
        while len(active) > self.sparsity:
            drop_index = self._rng.choice(tuple(active))
            vector = toggle_slot(vector, drop_index)
            active.remove(drop_index)
        while len(active) < self.sparsity:
            available = [
                index for index in range(self.dim) if index not in blocked_additions and index not in active
            ]
            if not available:
                break
            add_index = self._rng.choice(available)
            vector = toggle_slot(vector, add_index)
            active.add(add_index)
        return vector

    def snapshot(self) -> dict[str, object]:
        return {
            "primary": {key: present_indices(vector) for key, vector in sorted(self.primary.items())},
            "banks": {
                bank_name: {
                    key: [present_indices(row) for row in rows]
                    for key, rows in sorted(store.items())
                }
                for bank_name, store in self.banks.items()
            },
        }

    def restore(self, payload: dict[str, object], known_keys: set[str]) -> None:
        for key, indices in payload.get("primary", {}).items():
            if key not in known_keys:
                continue
            self.primary[key] = self._restore_vector(indices)
        bank_payload = payload.get("banks", {})
        for bank_name, store in self.banks.items():
            saved_rows = bank_payload.get(bank_name, {})
            for key, rows in saved_rows.items():
                if key not in known_keys:
                    continue
                row_count = self.bank_shapes[bank_name]
                restored = [self._restore_vector(row) for row in rows[:row_count]]
                while len(restored) < row_count:
                    restored.append(blank_vector(self.dim))
                store[key] = restored

    def average_sparsity(self) -> float:
        total = 0
        count = 0
        for vector in self.primary.values():
            total += present_count(vector)
            count += 1
        for store in self.banks.values():
            for rows in store.values():
                for row in rows:
                    total += present_count(row)
                    count += 1
        return (total / count) if count else 0.0

    def _ensure_bank_cache(self, key: str, bank_name: str) -> None:
        cache_key = (bank_name, key)
        if cache_key not in self.bank_signature_cache:
            self.bank_signature_cache[cache_key] = [
                combine(row, row) for row in self.banks[bank_name][key]
            ]

    def _initialize_vector(self, key: str, index: int) -> list:
        vector = blank_vector(self.dim)
        seed = 17 + (index * 131) + sum((offset + 1) * ord(char) for offset, char in enumerate(key))
        init_rng = random.Random(seed)
        active = {index % self.dim}
        while len(active) < self.sparsity:
            active.add(init_rng.randrange(self.dim))
        for slot in sorted(active):
            vector = toggle_slot(vector, slot)
        return vector

    def _initialize_matrix(self, key: str, index: int, rows: int, salt: str) -> list[list]:
        matrix = []
        salt_value = sum(ord(char) for char in salt)
        for row_index in range(rows):
            row = blank_vector(self.dim)
            row_rng = random.Random((index * 193) + (row_index * 977) + salt_value + len(key))
            active: set[int] = set()
            while len(active) < self.sparsity:
                active.add(row_rng.randrange(self.dim))
            for slot in sorted(active):
                row = toggle_slot(row, slot)
            matrix.append(row)
        return matrix

    def _restore_vector(self, indices: list[int]) -> list:
        vector = blank_vector(self.dim)
        for raw_index in indices:
            index = int(raw_index)
            if 0 <= index < self.dim and index not in present_indices(vector):
                vector = toggle_slot(vector, index)
        return vector
