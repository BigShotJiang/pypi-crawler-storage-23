from __future__ import annotations

import os
from pathlib import Path


def _resolve_data_dir() -> Path:
    env_dir = os.environ.get("PHANTOM_DATA_DIR")
    if env_dir:
        resolved = Path(env_dir).resolve()
        resolved.mkdir(parents=True, exist_ok=True)
        return resolved
    return Path.cwd()


def _data_path(filename: str) -> Path:
    return _resolve_data_dir() / filename


WORDS_PATH = _data_path("words")
EXTRA_WORDS_PATH = _data_path("words.txt")
MODEL_STATE_PATH = _data_path("phantom_model_state.json")


def _load_vocabulary() -> tuple[list[str], dict[str, int]]:
    WORDS_PATH.touch(exist_ok=True)
    words: list[str] = []
    index_by_word: dict[str, int] = {}
    for raw_line in WORDS_PATH.read_text(encoding="utf-8").splitlines():
        word = raw_line.strip()
        if not word or word in index_by_word:
            continue
        index_by_word[word] = len(words)
        words.append(word)
    return words, index_by_word


GLOBAL_VOCAB, GLOBAL_INDEX = _load_vocabulary()


def vocabadder(word: str) -> int:
    word = word.strip()
    if not word:
        raise ValueError("vocabadder requires a non-empty word")

    known_index = GLOBAL_INDEX.get(word)
    if known_index is not None:
        return known_index

    new_index = len(GLOBAL_VOCAB)
    GLOBAL_VOCAB.append(word)
    GLOBAL_INDEX[word] = new_index
    with WORDS_PATH.open("a", encoding="utf-8") as handle:
        handle.write(f"{word}\n")
    return new_index
