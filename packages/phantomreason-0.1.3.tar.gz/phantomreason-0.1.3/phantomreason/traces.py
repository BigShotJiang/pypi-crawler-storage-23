from __future__ import annotations

try:
    from absence_calculator import count_present as phantom_count_present
except ImportError:
    phantom_count_present = None

from absence_calculator import Void, add, combine, compare, divide, erase, format_result, multiply, n, solve, subtract, toggle


def blank_vector(dim: int) -> list:
    return list(toggle.tensor(dim, fill="absent"))


def flip_index(vector: list, index: int) -> list:
    return toggle_slot(vector, index)


def toggle_slot(vector: list, index: int) -> list:
    result = list(vector)
    result[index] = result[index].toggle()
    return result


def state_value(item) -> float:
    if isinstance(item, Void):
        return 0.0
    if hasattr(item, "is_present"):
        return 1.0 if item.is_present else 0.0
    if hasattr(item, "left") and hasattr(item, "right"):
        return (state_value(item.left) + state_value(item.right)) / 2.0
    return 0.0


def is_present(item) -> bool:
    return bool(getattr(item, "is_present", False))


def present_indices(vector: list) -> list[int]:
    return [index for index, item in enumerate(vector) if is_present(item)]


def present_count(vector: list) -> int:
    if phantom_count_present is not None:
        try:
            return int(phantom_count_present(vector))
        except Exception:
            pass
    return len(present_indices(vector))


def score_distance(dim: int, left: list, right: list) -> float:
    # Compare yields directional present-surplus traces. Counting present surplus in
    # both directions gives a symbolic symmetric difference without manually walking
    # every slot state.
    forward = compare(left, right)
    backward = compare(right, left)
    return float(present_count(forward) + present_count(backward))


def context_indices(diff_vector: list, minimum: float = 0.5) -> list[int]:
    selected: list[int] = []
    for index, item in enumerate(diff_vector):
        if isinstance(item, Void):
            continue
        if state_value(item) >= minimum:
            selected.append(index)
    return selected


__all__ = [
    "add",
    "Void",
    "blank_vector",
    "combine",
    "compare",
    "context_indices",
    "divide",
    "erase",
    "flip_index",
    "format_result",
    "is_present",
    "multiply",
    "n",
    "present_count",
    "present_indices",
    "score_distance",
    "solve",
    "state_value",
    "subtract",
    "toggle",
    "toggle_slot",
]
