from __future__ import annotations

from .model import PhantomLanguageModel


def require(condition: bool, label: str, failures: list[str]) -> None:
    if not condition:
        failures.append(label)


def run_evaluation() -> dict[str, object]:
    model = PhantomLanguageModel(dim=512, sparsity=47)
    training_text = (
        "vector means an ordered list used for state. "
        "artist is a person who creates stories. "
        "sun rises east. "
        "north star guides sailors nightly. "
        "gardeners water orchids daily."
    )
    model.train_on_text(training_text, epochs=1, persist=False)
    failures: list[str] = []

    parsed = model.understand_input("north star guides sailors nightly")
    require(parsed["subject"] == "north star", "parse subject for two-word noun phrase", failures)
    require(parsed["predicate"] == "guides", "parse predicate for two-word noun phrase", failures)

    parsed = model.understand_input("what is vector?")
    require(parsed["subject"] == "vector", "parse copular question subject", failures)
    require(parsed["predicate"] == "is", "parse copular question predicate", failures)

    routed = model.route_prompt("what is vector?")
    require(routed["fact_answer"] is not None, "fact recall for learned definition", failures)

    model.register_fact("vector", "means", ["symbolic", "state"])
    require(
        not model._fact_is_active("fact:vector|means|ordered list"),
        "older contradictory fact should be inactive",
        failures,
    )
    require(
        model._fact_is_active("fact:vector|means|symbolic state"),
        "new contradictory fact should stay active",
        failures,
    )
    latest = model._direct_fact_match(subject="vector", predicate="means")
    require(
        latest is not None and latest["object_tokens"] == ["symbolic", "state"],
        "latest contradictory fact should dominate recall",
        failures,
    )

    before_decay = model._fact_strength_value("fact:vector|means|symbolic state")
    model.apply_fact_decay(keep_recent=0, amount=1)
    after_decay = model._fact_strength_value("fact:vector|means|symbolic state")
    require(after_decay <= before_decay, "decay should not increase fact strength", failures)

    if failures:
        return {
            "status": "FAIL",
            "failures": failures,
            "fact_count": model.fact_count(),
            "fact_answer": routed["fact_answer"],
            "parse": model.render_understanding(model.understand_input("north star guides sailors nightly")),
        }

    return {
        "status": "PASS",
        "failures": [],
        "fact_count": model.fact_count(),
        "fact_answer": routed["fact_answer"],
        "parse": model.render_understanding(model.understand_input("north star guides sailors nightly")),
    }


def main() -> int:
    result = run_evaluation()
    print(result["status"])
    for item in result["failures"]:
        print(f"- {item}")
    if result["status"] == "PASS":
        print(f"fact_count={result['fact_count']}")
        print(f"fact_answer={result['fact_answer']}")
        print(f"parse={result['parse']}")
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
