from __future__ import annotations

import html
import re
import urllib.error
import urllib.request
from pathlib import Path


DEFAULT_USER_AGENT = "phantomreason/1.0 (+symbolic-trace-ingest)"
DEFAULT_TIMEOUT_SECONDS = 15.0


def normalize_text(raw_text: str) -> str:
    cleaned = html.unescape(raw_text)
    cleaned = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", cleaned)
    cleaned = re.sub(r"(?s)<[^>]+>", " ", cleaned)
    cleaned = cleaned.replace("\r", "\n")
    cleaned = re.sub(r"[^\S\n]+", " ", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()


def tokenize_words(text: str) -> list[str]:
    return re.findall(r"[a-zA-Z']+", text.lower())


def iter_sentences(
    text: str,
    min_words: int = 3,
    max_words: int = 24,
    max_sentences: int | None = None,
) -> list[str]:
    normalized = normalize_text(text)
    if not normalized:
        return []
    sentence_like = re.split(r"(?<=[.!?])\s+|\n+", normalized)
    collected: list[str] = []
    seen: set[str] = set()
    for part in sentence_like:
        words = tokenize_words(part)
        if len(words) < min_words:
            continue
        while words:
            chunk = words[:max_words]
            words = words[max_words:]
            if len(chunk) < min_words:
                break
            sentence = " ".join(chunk)
            if sentence in seen:
                continue
            seen.add(sentence)
            collected.append(sentence)
            if max_sentences is not None and len(collected) >= max_sentences:
                return collected
    return collected


def load_text_file(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8")


def fetch_url_text(
    url: str,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
    user_agent: str = DEFAULT_USER_AGENT,
) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": user_agent})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        charset = response.headers.get_content_charset() or "utf-8"
        payload = response.read()
    return payload.decode(charset, errors="replace")


def extract_dictionary_facts(text: str, max_entries: int = 256) -> list[str]:
    facts: list[str] = []
    seen: set[str] = set()
    for raw_line in normalize_text(text).splitlines():
        line = raw_line.strip(" -:\t")
        if not line:
            continue
        match = re.match(r"^([A-Za-z][A-Za-z' -]{1,48})\s*[:\-]\s*(.+)$", line)
        if not match:
            continue
        term = " ".join(tokenize_words(match.group(1)))
        definition_tokens = tokenize_words(match.group(2))
        if not term or len(definition_tokens) < 2:
            continue
        definition = " ".join(definition_tokens[:10])
        sentence = f"{term} means {definition}"
        if sentence in seen:
            continue
        seen.add(sentence)
        facts.append(sentence)
        if len(facts) >= max_entries:
            break
    return facts


def load_local_corpus_candidates(root: Path) -> list[Path]:
    candidates: list[Path] = []
    for relative in ("words.txt", "words"):
        path = root / relative
        if path.exists() and path.is_file():
            candidates.append(path)
    return candidates


__all__ = [
    "DEFAULT_TIMEOUT_SECONDS",
    "DEFAULT_USER_AGENT",
    "extract_dictionary_facts",
    "fetch_url_text",
    "iter_sentences",
    "load_local_corpus_candidates",
    "load_text_file",
    "normalize_text",
    "tokenize_words",
]
