# Default

You're viewing default [vcorelib](https://github.com/vkottler/vcorelib)
[Markdown](https://daringfireball.net/projects/markdown/) contents (see also:
[Python-Markdown](https://python-markdown.github.io/)).
