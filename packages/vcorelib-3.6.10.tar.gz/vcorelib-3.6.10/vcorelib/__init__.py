# =====================================
# generator=datazen
# version=3.2.3
# hash=cd855c0e50568ff05b27ac788ef526ea
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "A collection of core Python utilities."
PKG_NAME = "vcorelib"
VERSION = "3.6.10"

# vcorelib-specific content.
DEFAULT_INDENT = 2
DEFAULT_ENCODING = "utf-8"
