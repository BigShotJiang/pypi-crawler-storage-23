<!--
    =====================================
    generator=datazen
    version=3.2.3
    hash=f9c4fc9b45b27badf517a460852bb350
    =====================================
-->

# vcorelib ([3.6.10](https://pypi.org/project/vcorelib/))

[![python](https://img.shields.io/pypi/pyversions/vcorelib.svg)](https://pypi.org/project/vcorelib/)
![Build Status](https://github.com/libre-embedded/vcorelib/workflows/Python%20Package/badge.svg)
[![codecov](https://codecov.io/gh/libre-embedded/vcorelib/branch/master/graphs/badge.svg?branch=master)](https://codecov.io/github/libre-embedded/vcorelib)
![PyPI - Status](https://img.shields.io/pypi/status/vcorelib)
![Dependents (via libraries.io)](https://img.shields.io/librariesio/dependents/pypi/vcorelib)

*A collection of core Python utilities.*

Consider [sponsoring development](https://github.com/sponsors/libre-embedded).

([interface documentation](https://libre-embedded.github.io/python/vcorelib))

## Python Version Support

This package is tested with the following Python minor versions:

* [`python3.13`](https://docs.python.org/3.13/)
* [`python3.14`](https://docs.python.org/3.14/)

## Platform Support

This package is tested on the following platforms:

* `ubuntu-latest`
* `macos-latest`
* `windows-latest`

# Introduction

Core technologies shared between a number of other Python packages.

# Internal Dependency Graph

A coarse view of the internal structure and scale of
`vcorelib`'s source.
Generated using [pydeps](https://github.com/thebjorn/pydeps) (via
`mk python-deps`).

![vcorelib's Dependency Graph](im/pydeps.svg)
