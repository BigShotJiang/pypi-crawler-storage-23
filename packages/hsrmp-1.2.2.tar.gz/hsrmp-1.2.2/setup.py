
from setuptools import setup, find_packages
setup(
    name='hsrmp',
    version='1.2.2',
    packages=find_packages(),
    install_requires=['psutil', 'taftp', 'hiosw-harp'],
    description='HioSW System Resource Monitoring Protocol. Pls, if you code not working, do it: import harp.discovery import taftp import hsrmp ',
    python_requires='>=3.12',
)
