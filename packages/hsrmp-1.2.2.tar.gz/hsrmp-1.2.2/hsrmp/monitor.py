
import tkinter as tk
from tkinter import ttk
import threading
import socket
import json
import psutil
import platform
import time

# ИМПОРТ ТВОИХ ЗАВИСИМОСТЕЙ
try:
    from taftp import TAFTPPacket
    from harp.discovery import HARPRadar
except ImportError:
    # Заглушка на случай, если библиотеки еще не установлены через pip
    class TAFTPPacket: pass
    class HARPRadar: pass

class _HSRMP_Core:
    def __init__(self):
        self.app_title = "HSRMP: Сетевой Монитор"
        self.msg_port = 5000
        self.harp_port = 5001
        self.nodes_data = {}

    def get_system_stats(self):
        """Сбор данных о нагрузке текущего ПК"""
        return {
            "cpu": f"{psutil.cpu_percent()}%",
            "ram": f"{psutil.virtual_memory().percent}%",
            "os": platform.system()
        }

    def _listen_handler(self):
        """Приемник запросов и ответов"""
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("", self.msg_port))
            while True:
                try:
                    data, addr = s.recvfrom(4096)
                    from taftp import TAFTPPacket # Импорт внутри для надежности
                    pkt = TAFTPPacket.unpack(data.decode())
                    if pkt and "SRM" in pkt.flags:
                        if "ACK" not in pkt.flags:
                            # Ответ на запрос статистики
                            resp = TAFTPPacket("SRM|ACK", 0, 0, json.dumps(self.get_system_stats())).pack()
                            s.sendto(resp.encode(), addr)
                        else:
                            # Получение данных от соседа
                            self.nodes_data[addr[0]] = json.loads(pkt.data)
                except: pass

    def run_interface(self):
        """Графическое окно мониторинга"""
        root = tk.Tk()
        root.title(self.app_title)
        root.geometry("600x400")
        root.configure(bg="#2c3e50")

        style = ttk.Style()
        style.theme_use("clam")

        cols = ("IP Адрес", "Нагрузка ЦПУ", "Память RAM", "ОС")
        tree = ttk.Treeview(root, columns=cols, show="headings")
        for col in cols: tree.heading(col, text=col)
        tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        def refresh():
            from harp.discovery import HARPRadar
            from taftp import TAFTPPacket
            
            # Поиск через HARP
            radar = HARPRadar(port=self.harp_port)
            radar.broadcast_scan()
            found = radar.listen_responses(timeout=1.0)
            
            # Запрос данных у всех найденных
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                for ip in found:
                    req = TAFTPPacket("SRM", 0, 0, "GET_STATS").pack()
                    s.sendto(req.encode(), (ip, self.msg_port))
            
            # Обновление таблицы
            for i in tree.get_children(): tree.delete(i)
            for ip, info in self.nodes_data.items():
                tree.insert("", tk.END, values=(ip, info['cpu'], info['ram'], info['os']))
            
            root.after(5000, refresh)

        threading.Thread(target=self._listen_handler, daemon=True).start()
        refresh()
        root.mainloop()

# Инициализация
_core = _HSRMP_Core()

# Публичные функции
def title(text): _core.app_title = text

class show:
    class lan:
        @staticmethod
        def monitor():
            _core.run_interface()
