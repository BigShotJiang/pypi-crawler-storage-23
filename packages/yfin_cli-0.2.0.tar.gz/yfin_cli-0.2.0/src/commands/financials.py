import yfinance as yf
from ..typer import (
    TickerType,
    FrequencyType,
    ExtendedFrequencyType,
    default_frequency,
    OffsetType,
    default_offset,
    LimitType,
    default_limit,
)
from ..utils import data_frame_to_list
from ..decorators import command


@command
def income_stmt(
    ticker: TickerType,
    frequency: ExtendedFrequencyType = default_frequency,
):
    """
    Get income statement for a ticker.
    """
    stock = yf.Ticker(ticker)
    data_frame = stock.get_income_stmt(pretty=True, freq=frequency)
    if data_frame is None:
        return None
    return data_frame_to_list(data_frame.T, index_name="Date")


@command
def balance_sheet(
    ticker: TickerType,
    frequency: FrequencyType = default_frequency,
):
    """
    Get balance sheet for a ticker.
    """
    stock = yf.Ticker(ticker)
    data_frame = stock.get_balance_sheet(pretty=True, freq=frequency)
    if data_frame is None:
        return None
    return data_frame_to_list(data_frame.T, index_name="Date")


@command
def cashflow(
    ticker: TickerType,
    frequency: ExtendedFrequencyType = default_frequency,
):
    """
    Get cash flow statement for a ticker.
    """
    stock = yf.Ticker(ticker)
    data_frame = stock.get_cashflow(pretty=True, freq=frequency)
    if data_frame is None:
        return None
    return data_frame_to_list(data_frame.T, index_name="Date")


@command
def earnings_dates(
    ticker: TickerType,
    limit: LimitType = default_limit,
    offset: OffsetType = default_offset,
):
    """
    Get earnings dates, estimates, and reported EPS for a ticker.
    """
    stock = yf.Ticker(ticker)
    data_frame = stock.get_earnings_dates(limit=limit, offset=offset)
    return data_frame_to_list(data_frame)


@command
def sec_filings(
    ticker: TickerType,
):
    """
    Get SEC filings for a ticker.
    """
    stock = yf.Ticker(ticker)
    return stock.get_sec_filings()
