# yfin CLI - A command-line wrapper for yfinance
