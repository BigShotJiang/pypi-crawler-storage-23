"""Version information for interposition_http_adapter."""

__version__ = "0.4.0"
