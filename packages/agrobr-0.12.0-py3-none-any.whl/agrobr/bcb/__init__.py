"""Módulo BCB — dados de crédito rural (SICOR)."""

from agrobr.bcb.api import credito_rural

__all__ = ["credito_rural"]
