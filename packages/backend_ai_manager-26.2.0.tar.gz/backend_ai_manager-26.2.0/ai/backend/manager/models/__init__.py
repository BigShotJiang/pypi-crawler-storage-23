# Models package for Backend.AI Manager
#
# IMPORTANT: Do NOT import symbols from this package directly.
# Use direct subpackage imports instead:
#   from ai.backend.manager.models.session import SessionRow
#   from ai.backend.manager.models.kernel import KernelRow
#
# For metadata with all tables registered:
#   from ai.backend.manager.models.metadata import metadata
