from __future__ import annotations

from .factory import get_container_registry_cls

__all__ = ["get_container_registry_cls"]
