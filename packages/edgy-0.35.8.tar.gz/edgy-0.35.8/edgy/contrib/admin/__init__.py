from .application import create_admin_app

__all__ = ["create_admin_app"]
