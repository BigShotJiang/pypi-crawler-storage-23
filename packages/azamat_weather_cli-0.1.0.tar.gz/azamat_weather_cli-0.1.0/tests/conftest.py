import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Проверяем импорт
try:
    from weather import WeatherAPI
    print("✅ Авто-импорт src настроен!")
except ImportError:
    pass