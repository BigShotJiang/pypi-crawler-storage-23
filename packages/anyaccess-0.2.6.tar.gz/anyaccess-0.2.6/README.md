# AnyAccess

A modular Flask backend for User Access Management. This package provides a pre-configured architecture using **MariaDB** for data, **Valkey** (Redis) for session management, and **Google OAuth2** for authentication.

## 🛠 Prerequisites

For fedora-minimal, Ensure the system can handle mariadb:

```bash
sudo dnf install python3 mariadb-connector-c
```

## ⚙️ Configuration (.env)
Create a .env file in your project root:

```bash
# File:Function to run the app
ANYACCESS=main:serve_app 

# Database & Cache
MARIA_KEY=mysql://user:password@localhost/dbname
VALKEY_HOST=localhost

# Flask Security
FLASK_SECRET_KEY=your_secure_random_string
GLOBAL_SESSION_VERSION=1

# Google OAuth Credentials
GOOGLE_CLIENT_ID=your_id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your_secret_key
CURRENT_URL=http://localhost:5000
GOOGLE_RETURN_FRONTEND=http://localhost:3000

# CORS Settings
ALLOWED_ORIGINS=http://localhost:3000,http://127.0.0.1:3000,http://192.168.128.35:3000,https://anyreact.khazu.net
```

## 🚀 Implementation Guide
A typical implementation involves two main files using the anyflask package.

1. init.py
This file initializes the core Flask application and its services.
```python
from flask import Flask, session
from anyaccess import AnyInit as AI

app = Flask(__name__)

# Modular Service Initialization
AI.initCORS(app)
AI.initValkey(app)
AI.initMariaDB(app)
AI.initAPILogin(app)

@app.before_request
def check_session_version():
  if session.get('ver') != AI.SESSION_VERSION:
    session.clear()
    session['ver'] = AI.SESSION_VERSION

def anyaccess_initcall():
  # Optional hook for custom initialization logic
  # will trigger when first user is created
  return True
```

2. main.py
This file handles the API routing and serves the application.
```python
from flask_restful import Api, Resource, reqparse
from init import app
from anyaccess import Account, Journal, AccountType, GoogleAuth, Authenticate

# Custom local resource example
class Test(Resource):
  test_data = reqparse.RequestParser()
  test_data.add_argument('test', required=True)

  def get(self):
    return {'status':'success'}

# API Registration
api = Api(app)
api.add_resource(Account, '/api/access/user')
api.add_resource(Journal, '/api/access/logs')
api.add_resource(AccountType, '/api/access/usertype')
api.add_resource(Authenticate, '/api/access/authenticate')
api.add_resource(GoogleAuth, '/api/access/google')
api.add_resource(Test, '/api/access/')

def serve_app():
  return app
```
## 🔐 Authentication Flow
First User: The first user registered via /api/access/user POST MUST be a superuser. This triggers the automatic initialization of the UserType table.

Google Login: Users can authenticate via Google. Accounts are automatically created with a google- prefix using the Google sub ID.