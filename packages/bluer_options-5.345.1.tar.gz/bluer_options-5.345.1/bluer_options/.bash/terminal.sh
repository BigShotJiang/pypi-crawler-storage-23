#! /usr/bin/env bash

function bluer_ai_badge() {
    local options=$1
    local do_clear=$(bluer_ai_option_int "$options" clear 0)
    local do_reset=$(bluer_ai_option_int "$options" reset 0)
    local do_save=$(bluer_ai_option_int "$options" save 0)
    local verbose=$(bluer_ai_option_int "$options" verbose 0)

    local badge=$2

    if [[ "$do_clear" == 1 ]]; then
        badge=""

        [[ "$verbose" == 1 ]] &&
            bluer_ai_log "cleared badge."
    fi

    if [[ "$do_reset" == 1 ]]; then
        badge=$BLUER_AI_BADGE_DEFAULT

        [[ "$verbose" == 1 ]] &&
            bluer_ai_log "resetting badge.",
    fi

    export BLUER_AI_BADGE=$badge

    if [[ "$do_save" == 1 ]]; then
        export BLUER_AI_BADGE_DEFAULT=$BLUER_AI_BADGE

        [[ "$verbose" == 1 ]] &&
            bluer_ai_log "saved badge."

        [[ -z "$badge" ]] &&
            return 0
    fi

    [[ "$verbose" == 1 ]] &&
        bluer_ai_log "badge: $badge"

    echo -e "\033]1337;SetBadgeFormat=$(echo -n "$badge" | base64)\a"
}

function bluer_ai_clear() {
    cd

    bluer_ai_update_terminal

    clear
}

function bluer_ai_get_icon() {
    local icon=""
    if [ "$abcli_is_docker" == true ]; then
        if [ "$abcli_is_sagemaker" == true ]; then
            if [ "$abcli_is_sagemaker_system" == true ]; then
                local icon="⚗️ "
            else
                local icon="🧪 "
            fi
        else
            local icon="🌠 "
        fi
    elif [ "$abcli_is_ec2" == true ]; then
        local icon="🌩️ "
    elif [ "$abcli_is_jetson" == true ] || [ "$abcli_is_rpi" == true ]; then
        local icon="🏹 "
    elif [ "$abcli_is_mac" == true ]; then
        local icon="💻 "
    fi

    echo "$BLUER_AI_STATUS_ICONS$icon"
}

function bluer_ai_set_background_color() {
    local color=${1:-000000}

    echo -e "\033]1337;SetColors=bg=${color}\a"
}

function bluer_ai_set_prompt() {
    # https://askubuntu.com/a/946716
    force_color_prompt=yes
    color_prompt=yes

    parse_git_branch() {
        git branch 2>/dev/null | sed -e '/^[^*]/d' -e 's/* \(.*\)/(\1)/'
    }

    # https://misc.flogisoft.com/bash/tip_colors_and_formatting
    if [ "$color_prompt" = yes ]; then
        PS1=$(bluer_ai_get_icon)'\[\033[00;32m\]$abcli_fullname\[\033[00m\]:${debian_chroot:+($debian_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[01;31m\]$(parse_git_branch)\[\033[00m\]\n > '
    else
        PS1=$(bluer_ai_get_icon)'$abcli_fullname${debian_chroot:+($debian_chroot)}\u@\h:\w$(parse_git_branch)\$ '
    fi
    unset color_prompt force_color_prompt
}

function bluer_ai_update_terminal() {
    bluer_ai_set_prompt

    local icon=$(bluer_ai_get_icon)

    [[ ! -z "$icon" ]] &&
        bluer_ai_badge save "$icon"

    local title="$icon $abcli_fullname"
    [[ "$abcli_is_sagemaker" == false ]] &&
        [[ "$abcli_is_shell" == false ]] &&
        local title="$title@$(hostname)"

    [ $# -gt 0 ] &&
        local title="$title | $@"

    echo -n -e "\033]0;$title\007"
}
