from bluer_options.timing.elapsed_timer import ElapsedTimer
from bluer_options.timing.classes import Timing

timing = Timing()
