unit_of = {
    "ambient light": "{} lux",
    "humidity": "{} %RH",
    "iteration": "{:,}",
    "pitch": "{} deg",
    "pressure": "{} hPa",
    "roll": "{} deg",
    "temperature": "{} 'C",
    "yaw": "{} deg",
}
