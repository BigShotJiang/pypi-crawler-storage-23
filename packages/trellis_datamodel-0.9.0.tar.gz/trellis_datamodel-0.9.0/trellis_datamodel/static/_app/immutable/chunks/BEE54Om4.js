const s=""+new URL("../assets/trellis_squared.CTOnsdDx.svg",import.meta.url).href;export{s as l};
