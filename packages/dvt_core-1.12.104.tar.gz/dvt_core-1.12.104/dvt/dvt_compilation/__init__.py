# DVT-specific Compiler subclass.
# Extends the standard dbt Compiler with target-aware compilation capabilities
# while keeping the base compilation.py rebase-compatible.
