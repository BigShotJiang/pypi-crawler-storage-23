def upgrade_manifest_json_dbt_version(manifest: dict) -> dict:
    return manifest
