from dvt.artifacts.schemas.upgrades.upgrade_manifest import upgrade_manifest_json
from dvt.artifacts.schemas.upgrades.upgrade_manifest_dbt_version import (
    upgrade_manifest_json_dbt_version,
)
