# Witness (One Pager)

## The problem

AI makes work faster — and harder to audit. "Trust me" doesn't scale.

## The idea

A neutral witness. Record events as signed facts:

- what was done (action)
- why it was done (declared intent)
- what went in and out (digests)
- who signed it (actor key)
- when it happened (self-reported timestamp + flags for anomalies)

## The result

Evidence-grade records that verify offline and can be audited later without specialized infrastructure.

## Why it matters

As AI becomes pervasive, accountability must become verifiable — without becoming surveillance.

## Link

https://github.com/mcp-tool-shop/witness
