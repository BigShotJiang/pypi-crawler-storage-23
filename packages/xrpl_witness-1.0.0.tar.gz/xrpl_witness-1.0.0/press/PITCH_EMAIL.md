# Pitch Email

**Subject:** Witness — offline-verifiable evidence trails for human-AI workflows

---

Hi [Name],

We just released Witness, a local-first append-only event journal that makes it possible to verify what happened in AI-assisted workflows—offline, without cloud dependencies.

Witness records events as canonical JSON with SHA-256 digests and Ed25519 signatures. It doesn't claim to prove intent—only record integrity—so auditors and developers can verify evidence without trusting screenshots or mutable logs.

Repo: https://github.com/mcp-tool-shop/witness

If you'd like, I can share a 60-second demo flow and the verification spec.

Best,
[Your Name]
