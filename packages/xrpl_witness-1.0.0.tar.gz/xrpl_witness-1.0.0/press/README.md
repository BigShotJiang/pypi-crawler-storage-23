# Press Kit

This folder contains ready-to-use materials for announcing Witness.

## Contents

| File | Purpose |
|------|---------|
| `PRESS_RELEASE.md` | Formal announcement (fill in date/location) |
| `FACT_SHEET.md` | Quick reference for journalists/bloggers |
| `FAQ.md` | Common questions and answers |
| `ONE_PAGER.md` | Executive summary (1 page) |
| `BOILERPLATE.md` | Standard description paragraph |
| `QUOTES.md` | Pull quotes for articles |
| `SOCIAL.md` | Ready-to-post social media copy |
| `PITCH_EMAIL.md` | Template for outreach |

## Usage

1. Fill in `[bracketed placeholders]` with actual values
2. Adjust tone/length as needed for your audience
3. Keep messaging consistent across channels

## Key messages

- **Local-first**: No cloud dependency
- **Append-only**: Immutable by design
- **Verifiable**: Offline cryptographic verification
- **Evidence-grade**: Designed for audit, not surveillance
