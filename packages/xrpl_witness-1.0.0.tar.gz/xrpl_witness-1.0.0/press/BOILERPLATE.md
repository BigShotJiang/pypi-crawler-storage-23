# Boilerplate

**Witness** is a local-first, append-only event journal for human-AI workflows. It records actions, artifacts, and context as cryptographically verifiable events using canonical JSON, SHA-256, and Ed25519. Witness is designed to be inspectable, offline-verifiable, and auditor-friendly.
