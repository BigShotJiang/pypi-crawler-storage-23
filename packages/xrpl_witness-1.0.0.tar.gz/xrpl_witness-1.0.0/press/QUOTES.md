# Quotes

**On the problem**

> "AI speeds up decisions, but it also collapses the paper trail. Witness exists to restore provable history without adding surveillance."

**On design**

> "Append-only isn't a feature. It's the constraint that makes integrity possible."

**On honesty**

> "Witness doesn't solve lying. It solves undetectable lying."
