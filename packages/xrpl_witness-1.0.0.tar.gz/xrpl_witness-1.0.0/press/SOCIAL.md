# Social Copy

## Short

Witness: local-first, append-only proof trails for human-AI work. Offline verifiable. No cloud required.

## Medium

Logs are mutable. Screenshots are theater. Witness records workflow events as signed, tamper-evident evidence — local-first and offline verifiable.

## Launch post

Today we're releasing Witness: a local-first 'truth recorder' for human-AI workflows. Signed events, artifact digests, append-only history, and offline verification. GitHub: https://github.com/mcp-tool-shop/witness
