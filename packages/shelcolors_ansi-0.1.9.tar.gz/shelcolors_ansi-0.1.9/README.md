# shelcolors-ansi



To install, type '`pip install shelcolors.ansi`'.

To use, type '`import shelcolors_ansi`'

---

Simple ANSI color helper.
`ANSI(color, text, funct)`
    `funct=print` on default
    Also if mode is anything but a string, it will return instead.

👇 `ANSI(…)` colors
<details>
    <summary>COLORS</summary>

    ### Mono-scale Colors

    Black = black

    White = white

    Gray = gray

    Light Gray = lightgray

    Dark Gray = darkgray



    ### Red Colors

    Red = red

    Bright Red = brightred

    Dark Red = darkred

    Maroon = maroon

    Crimson = crimson


    ### Yellow and Orange Colors

    Yellow = yellow

    Bright Yellow = brightyellow

    Orange = orange

    Dark Orange = darkorange

    Gold = gold

    Amber = amber

    Mustard = mustard



    ### Green Colors

    Green = green

    Bright Green = brightgreen

    Lime = lime

    Light Green = lightgreen

    Dark Green = darkgreen

    Olive = olive

    Mint = mint



    ### Blue Colors

    Blue = blue

    Bright Blue = brightblue

    Light Blue = lightblue

    Sky Blue = skyblue

    Cyan = cyan

    Aqua = aqua

    Teal = teal

    Navy = navy



    ### Purple and Pink Colors

    Magenta = magenta

    Bright Magenta = brightmagenta

    Purple = purple

    Violet = violet

    Lavender = lavender

    Pink = pink

    Hot Pink = hotpink



    ### Brown Colors

    Brown = brown

    Dark Brown = darkbrown

    Tan = tan

    Beige = beige

</details>


`get_colors()`
    GET ALL COLORS USED IN `ANSI(…)`

`clear_screen()`
    uh, clear screen using os