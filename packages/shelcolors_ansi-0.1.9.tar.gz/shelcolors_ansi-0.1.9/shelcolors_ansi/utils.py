import os

def clear_screen():
    """
    clears the screen using os.system
    """
    os.system("cls" if os.name == 'nt' else "clear")