import asyncio
from ws_bom_robot_app.llm.vector_store.integration.base import IntegrationStrategy, UnstructuredIngest
from unstructured_ingest.processes.connectors.confluence import ConfluenceIndexerConfig, ConfluenceIndexer, ConfluenceDownloaderConfig, ConfluenceConnectionConfig, ConfluenceAccessConfig, ConfluenceDownloader
from unstructured_ingest.pipeline.pipeline import Pipeline
from unstructured_ingest.pipeline.steps.download import DownloadStep
from langchain_core.documents import Document
from ws_bom_robot_app.llm.vector_store.loader.base import Loader
from typing import List, Optional, Union
from pydantic import BaseModel, Field, AliasChoices
from pathlib import Path

class ConfluenceParams(BaseModel):
  """
  ConfluenceParams is a data model for storing Confluence integration parameters.

  Attributes:
    url (str): The URL of the Confluence instance, e.g., 'https://example.atlassian.net'.
    username (str): The email address or username of the Confluence user
    password: Confluence password or Cloud API token, if filled, set the access_token to None and vice versa.
    access_token (str): The personal access token for authenticating with Confluence, e.g., 'AT....'
    spaces (list[str]): A list of Confluence spaces to interact with, e.g., ['SPACE1', 'SPACE2'].
    max_num_of_docs_from_each_space (int): The maximum number of documents to fetch from each space. Defaults to 500, with a maximum limit of 5000.
    extension (list[str], optional): A list of file extensions to filter by. Defaults to None, e.g., ['.pdf', '.docx'].
    cql_filter (str, optional): A CQL filter string to refine document selection. Defaults to None, e.g., "type = 'page' AND pageStatus = 'Verified'".
  """
  url: str
  username: str = Field(validation_alias=AliasChoices("userName","userEmail","username"))
  password: Optional[str] = None
  access_token: Optional[str] = Field(None, validation_alias=AliasChoices("accessToken","access_token"))
  spaces: list[str] = []
  max_num_of_docs_from_each_space: int = Field(default=500, ge=1, le=5000,validation_alias=AliasChoices("maxNumOfDocsFromEachSpace","max_num_of_docs_from_each_space"))
  extension: list[str] = Field(default=None)
  cql_filter: Optional[str] = Field(default=None, validation_alias=AliasChoices("cqlFilter","cql_filter"))
class Confluence(IntegrationStrategy):
  def __init__(self, knowledgebase_path: str, data: dict[str, Union[str,int,list]]):
    super().__init__(knowledgebase_path, data)
    self.__data = ConfluenceParams.model_validate(self.data)
    self.__unstructured_ingest = UnstructuredIngest(self.working_directory)
  def working_subdirectory(self) -> str:
    return 'confluence'
  def run(self) -> None:
    indexer_config = ConfluenceIndexerConfig(
      spaces=self.__data.spaces,
      max_num_of_docs_from_each_space=self.__data.max_num_of_docs_from_each_space
    )
    downloader_config = ConfluenceDownloaderConfig(
      download_dir=self.working_directory
    )
    connection_config = ConfluenceConnectionConfig(
      access_config=ConfluenceAccessConfig(password=self.__data.password, token=self.__data.access_token),
      url=self.__data.url,
      username=self.__data.username
    )
    pipeline: Pipeline = self.__unstructured_ingest.pipeline(
      indexer_config,
      downloader_config,
      connection_config,
      extension=self.__data.extension
    )
    pipeline.indexer_step.process = CustomConfluenceIndexer(**vars(pipeline.indexer_step.process), confluence_params=self.__data)
    pipeline.downloader_step = CustomDownloadStep(**vars(pipeline.downloader_step))
    pipeline.run()
  async def load(self) -> list[Document]:
      await asyncio.to_thread(self.run)
      await asyncio.sleep(1)
      return await Loader(self.working_directory).load()

class CustomConfluenceIndexer(ConfluenceIndexer):
  def __init__(self, **kwargs):
    self.confluence_params = kwargs.pop('confluence_params', None)
    for key, value in kwargs.items():
        try:
            setattr(super(), key, value)
        except AttributeError:
            setattr(self, key, value)
  def _get_docs_ids_within_one_space(self, space_key: str) -> List[dict]:
      with self.connection_config.get_client() as client:
          cql_query = f"space = '{space_key}'"
          if self.confluence_params and self.confluence_params.cql_filter:
              cql_query += f" AND {self.confluence_params.cql_filter}"
              pages = client.cql(cql_query, limit=self.index_config.max_num_of_docs_from_each_space)['results']
      limited_pages = pages[: self.index_config.max_num_of_docs_from_each_space]
      doc_ids = [{"space_id": space_key, "doc_id": page["content"]["id"]} for page in limited_pages]
      return doc_ids

class CustomDownloadStep(DownloadStep):
  """Additional handling for UTF-8 encoding in downloaded files."""
  def __init__(self, **kwargs):
    process = kwargs.pop('process')
    context = kwargs.pop('context')
    identifier = kwargs.pop('identifier', 'download')
    super().__init__(process=process, context=context, identifier=identifier)
    for key, value in kwargs.items():
        setattr(self, key, value)

  def update_file_data(self, file_data, file_data_path, download_path):
    file_data.local_download_path = str(download_path.resolve())
    file_size_bytes = download_path.stat().st_size
    if not file_data.metadata.filesize_bytes and file_size_bytes:
        file_data.metadata.filesize_bytes = file_size_bytes
    if (
        file_data.metadata.filesize_bytes
        and file_data.metadata.filesize_bytes != file_size_bytes
    ):
        file_data.metadata.filesize_bytes = file_size_bytes
    with file_data_path.open("w", encoding='utf-8') as file:
        file.write(file_data.model_dump_json(indent=2))

