from embedm.application.orchestration import main

main()
