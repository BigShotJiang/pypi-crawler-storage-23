from types import SimpleNamespace

str_resources = SimpleNamespace(err_path_not_allowed="path is not in allowed paths: '{path}'")
