from types import SimpleNamespace

str_resources = SimpleNamespace(err_unclosed_block="unclosed embedm block")
