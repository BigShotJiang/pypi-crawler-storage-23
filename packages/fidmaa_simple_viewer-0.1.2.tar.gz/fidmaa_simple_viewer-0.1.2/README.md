fidmaa-simple-viewer
--------------------

Simple viewer for HEIC images with depth data