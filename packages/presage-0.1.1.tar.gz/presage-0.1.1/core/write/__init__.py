# core/write/__init__.py
