..
   SPDX-FileCopyrightText: 2026 Andrew Grimberg <tykeal@bardicgrove.org>
   SPDX-License-Identifier: Apache-2.0

Configuration
=============

.. automodule:: pylocal_akuvox.config
   :members:
   :undoc-members:
   :show-inheritance:
