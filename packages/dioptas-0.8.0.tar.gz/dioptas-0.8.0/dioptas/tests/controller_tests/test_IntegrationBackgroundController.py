# SPDX-License-Identifier: MIT

from ..utility import QtTest, click_button
import os
import gc
import unittest

from qtpy import QtWidgets
from mock import MagicMock, patch

from ..utility import enter_value_into_text_field

from ...controller.integration import BackgroundController
from ...controller.integration import PatternController
from ...model.DioptasModel import DioptasModel
from ...widgets.integration import IntegrationWidget

unittest_path = os.path.dirname(__file__)
data_path = os.path.join(unittest_path, '../data')


class IntegrationBackgroundControllerTest(QtTest):

    def setUp(self):
        # Mocking the function which will block the unittest for some reason...
        # Use patch to ensure proper cleanup
        self.processEvents_patcher = patch.object(QtWidgets.QApplication, 'processEvents', MagicMock())
        self.processEvents_patcher.start()

        self.widget = IntegrationWidget()
        self.model = DioptasModel()

        self.pattern_controller = PatternController(self.widget, self.model)
        self.background_controller = BackgroundController(self.widget, self.model)
        self.overlay_tw = self.widget.overlay_tw

    def tearDown(self):
        # Stop the patcher to restore original behavior
        self.processEvents_patcher.stop()

        # Clean up widgets
        self.widget.close()
        self.widget.deleteLater()
        del self.pattern_controller
        del self.background_controller
        del self.widget
        del self.model
        gc.collect()

    def test_pattern_bkg_toggle_inspect_button(self):
        self.model.pattern_model.load_pattern(os.path.join(data_path, 'pattern_001.xy'))
        click_button(self.widget.qa_bkg_pattern_btn)
        click_button(self.widget.qa_bkg_pattern_inspect_btn)
        x_bkg, y_bkg = self.widget.pattern_widget.bkg_item.getData()
        self.assertGreater(len(x_bkg), 0)

        click_button(self.widget.qa_bkg_pattern_inspect_btn)
        x_bkg, y_bkg = self.widget.pattern_widget.bkg_item.getData()
        self.assertIsNone(x_bkg)
        self.assertIsNone(y_bkg)

    def test_pattern_bkg_inspect_btn_is_untoggled_when_disabling_pattern_gb(self):
        self.model.pattern_model.load_pattern(os.path.join(data_path, 'pattern_001.xy'))
        self.widget.bkg_pattern_gb.setChecked(True)
        self.widget.bkg_pattern_inspect_btn.toggle()
        self.widget.bkg_pattern_gb.setChecked(False)
        x_bkg, y_bkg = self.widget.pattern_widget.bkg_item.getData()
        self.assertIsNone(x_bkg)
        self.assertIsNone(y_bkg)

    def test_pattern_bkg_linear_region_changes_txt_fields(self):
        self.model.pattern_model.load_pattern(os.path.join(data_path, 'pattern_001.xy'))
        self.widget.bkg_pattern_gb.setChecked(True)
        self.widget.bkg_pattern_inspect_btn.toggle()

        self.widget.pattern_widget.set_bkg_roi(5, 11)

        x_min = float(str(self.widget.bkg_pattern_x_min_txt.text()))
        x_max = float(str(self.widget.bkg_pattern_x_max_txt.text()))

        self.assertAlmostEqual(x_min, 5,  delta=0.02)
        self.assertAlmostEqual(x_max, 11, delta=0.02)

    def test_pattern_bkg_txt_fields_change_linear_regions(self):
        self.model.pattern_model.load_pattern(os.path.join(data_path, 'pattern_001.xy'))
        self.widget.bkg_pattern_gb.setChecked(True)
        self.widget.bkg_pattern_inspect_btn.toggle()

        enter_value_into_text_field(self.widget.bkg_pattern_x_min_txt, '5')
        enter_value_into_text_field(self.widget.bkg_pattern_x_max_txt, '11')

        x_min, x_max = self.widget.pattern_widget.bkg_roi.getRegion()

        self.assertAlmostEqual(x_min, 5,  delta=0.02)
        self.assertAlmostEqual(x_max, 11, delta=0.02)

    def test_pattern_bkg_range_remains_when_loading_new_pattern(self):
        self.model.pattern_model.load_pattern(os.path.join(data_path, 'pattern_001.xy'))
        self.widget.bkg_pattern_gb.setChecked(True)
        self.widget.bkg_pattern_inspect_btn.toggle()

        enter_value_into_text_field(self.widget.bkg_pattern_x_min_txt, '5')
        enter_value_into_text_field(self.widget.bkg_pattern_x_max_txt, '11')

        x_min = self.widget.bkg_pattern_x_min_txt.text()
        x_max = self.widget.bkg_pattern_x_max_txt.text()

        self.model.pattern_model.load_pattern(os.path.join(data_path, 'pattern_001.xy'))
        self.assertEqual(x_min, self.widget.bkg_pattern_x_min_txt.text())
        self.assertEqual(x_max, self.widget.bkg_pattern_x_max_txt.text())



if __name__ == '__main__':
    unittest.main()
