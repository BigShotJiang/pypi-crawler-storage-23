"""MCP Orchestration Gateway - Aggregates and searches tools from multiple MCP servers."""

__version__ = "0.1.0"
