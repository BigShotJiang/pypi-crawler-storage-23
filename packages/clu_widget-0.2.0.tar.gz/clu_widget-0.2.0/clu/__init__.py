"""clu-widget — a tiny terminal widget for live Claude Code usage stats."""

__version__ = "0.2.0"
