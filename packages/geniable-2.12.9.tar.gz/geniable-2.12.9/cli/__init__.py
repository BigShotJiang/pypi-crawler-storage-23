"""CLI interface for the LangSmith Thread Analyzer."""

from cli.main import app

__all__ = ["app"]
