from argus_nano.cli import main

main()
