"""Argus Nano — A purpose-built SLM for secrets detection."""

__version__ = "0.1.6"

from argus_nano.patterns import PatternMatch, PatternRegistry
from argus_nano.scanner import Scanner, ScanResult
from argus_nano.semantic import SemanticMatch, SemanticScanner

__all__ = [
    "__version__",
    "Scanner",
    "ScanResult",
    "PatternRegistry",
    "PatternMatch",
    "SemanticScanner",
    "SemanticMatch",
]
