"""Node evaluation utilities and evaluation factories."""
