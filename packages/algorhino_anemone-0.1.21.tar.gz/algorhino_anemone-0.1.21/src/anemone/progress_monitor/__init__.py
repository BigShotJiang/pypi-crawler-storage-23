"""Provide progress monitor utilities and stopping criteria."""
