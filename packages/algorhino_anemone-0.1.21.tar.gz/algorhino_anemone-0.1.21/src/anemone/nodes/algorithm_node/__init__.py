"""init file for algorithm_node module."""

from .algorithm_node import AlgorithmNode

__all__ = ["AlgorithmNode"]
