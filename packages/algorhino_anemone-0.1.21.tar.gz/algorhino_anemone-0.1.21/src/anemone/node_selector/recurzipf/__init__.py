"""Provide RecurZipf-based node selector components."""
