.. _faq:

==================================
 Frequently Asked Questions (FAQ)
==================================

.. include:: includes/faq.txt
