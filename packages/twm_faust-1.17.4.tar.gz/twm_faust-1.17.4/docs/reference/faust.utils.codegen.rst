=====================================================
 ``faust.utils.codegen``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.codegen

.. automodule:: faust.utils.codegen
    :members:
    :undoc-members:
