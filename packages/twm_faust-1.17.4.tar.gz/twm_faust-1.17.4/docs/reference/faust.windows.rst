=====================================================
 ``faust.windows``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.windows

.. automodule:: faust.windows
    :members:
    :undoc-members:
