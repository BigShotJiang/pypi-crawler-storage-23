=====================================================
 ``faust.streams``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.streams

.. automodule:: faust.streams
    :members:
    :undoc-members:
