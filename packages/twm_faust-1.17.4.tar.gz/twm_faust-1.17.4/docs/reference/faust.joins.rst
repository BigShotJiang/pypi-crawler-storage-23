=====================================================
 ``faust.joins``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.joins

.. automodule:: faust.joins
    :members:
    :undoc-members:
