=====================================================
 ``faust.exceptions``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.exceptions

.. automodule:: faust.exceptions
    :members:
    :undoc-members:
