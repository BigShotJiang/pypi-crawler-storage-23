=====================================================
 ``faust.web.views``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.views

.. automodule:: faust.web.views
    :members:
    :undoc-members:
