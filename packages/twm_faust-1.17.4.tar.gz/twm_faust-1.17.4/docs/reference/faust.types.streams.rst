=====================================================
 ``faust.types.streams``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.streams

.. automodule:: faust.types.streams
    :members:
    :undoc-members:
