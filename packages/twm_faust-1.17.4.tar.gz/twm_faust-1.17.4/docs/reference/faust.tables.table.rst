=====================================================
 ``faust.tables.table``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables.table

.. automodule:: faust.tables.table
    :members:
    :undoc-members:
