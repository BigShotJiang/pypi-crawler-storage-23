=====================================================
 ``faust.cli.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.base

.. automodule:: faust.cli.base
    :members:
    :undoc-members:
