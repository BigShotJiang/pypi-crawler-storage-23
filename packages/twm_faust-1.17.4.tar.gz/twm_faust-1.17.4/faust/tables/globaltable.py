from faust.tables.table import Table
from faust.types.tables import GlobalTableT


class GlobalTable(Table, GlobalTableT):
    pass
