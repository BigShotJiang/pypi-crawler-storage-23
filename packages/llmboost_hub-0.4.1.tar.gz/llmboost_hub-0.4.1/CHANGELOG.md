# CHANGELOG

## [0.4.1] - 2026-02-17
### Added
- **Persistent Tuning Results**: Tuning data now automatically persists across container restarts and system reboots
- **Historical Data Merge**: New `--use-local-db` flag for `lbh run` and `lbh serve` to leverage past tuning results

### Changed
- `lbh tune` now automatically saves results - no manual action needed

### Removed
- `--merge-db` flag from `lbh tune` (automatic persistence replaces this)

## [0.4.0] - 2026-01-23
### Added
- **Docker Authentication for Cluster Install**: Enhanced `lbh cluster install` with flexible Docker registry authentication
  - Added `--docker-username`, `--docker-pat`, `--docker-email` flags for explicit credential provision
  - Automatic credential parsing from `~/.docker/config.json` as fallback option
  - Prevents image pull failures on worker nodes during cluster installation
- **Model Discovery**: New `lbh list --discover` feature enables automatic detection and registration of models from external directories
  - Recursively scans directories for model files and adds them to `model_paths.yaml`
  - Supports both flat and organization-based directory structures
  - Simplifies model discovery and importing from alternative locations
- **Consumer-Grade GPU Support**: Expanded GPU detection to support additional AMD GPUs including Radeon 9700 series

### Changed
- **Improved License Validation**: Enhanced license activation process with better error reporting and diagnostics
- **Enhanced GPU Detection**: Improved AMD GPU identification with informative warnings for unsupported hardware
- **Overall Stability**: Various internal improvements to ensure more reliable operation

## [0.3.0] - 2025-12-22
### Added
- **Cluster Commands**: Full multi-node deployment orchestration via Kubernetes and Helm
  - `lbh cluster install`: Install LLMBoost Helm chart and infrastructure
  - `lbh cluster deploy`: Deploy models across cluster based on configuration file
  - `lbh cluster status`: Show cluster deployment status with optional access credentials
  - `lbh cluster logs`: View logs from model and management pods
  - `lbh cluster remove`: Remove model deployments from cluster
  - `lbh cluster uninstall`: Uninstall cluster resources
- **Model Path Management**: Automatic model-to-path mapping system
  - Added `LBH_MODEL_PATHS` configuration variable (default: `$LBH_HOME/model_paths.yaml`)
  - `lbh prep` now auto-saves model paths after successful preparation
  - `lbh run` path resolution: checks `LBH_MODEL_PATHS` first, then falls back to `$LBH_MODELS/<repo>/<model>`
  - User-provided `--model_path` is automatically saved for future use
- **Kubernetes Utilities**: Added comprehensive Kubernetes helper functions in `kube_utils.py`
  - Cluster verification and GPU detection
  - CRD management and pod status queries
  - Secret management for cluster access credentials
- **Cluster Configuration**: Template configuration file at `$LBH_HOME/utils/template_cluster_config.jsonc`
  - Supports explicit node placement via `resource_selector`
  - Supports automatic distribution via `node_replicas`
  - Custom Docker images and model paths per deployment

### Changed
- **Test Endpoint**: Updated test command to use `/api/v1/chat/completions` instead of `/v1/chat/completions`
- **Container Utilities**: Enhanced container naming and status detection
- **CLI Structure**: Added cluster command group with subcommands
- **Documentation**: Updated README and docs with cluster deployment instructions and examples
- **Changelog**: Updated changelog format for clarity

### Fixed
- Model path resolution now consistently checks saved paths before using defaults
- Container status detection improved for cluster deployments

## [0.1.2] - 2025-11-25
### Added
- Changed `lbh search <model>` to `lbh fetch [model]`
  - "model" argument is now optional. Users can now authenticate and fetch all supported models from remote.
  - Updated help text and documentation accordingly.

### Fixed
- Fixed shell completions command help text formatting issue.
- Fixed minor documentation typos and formatting issues.

## [0.1.1] - 2025-11-07
This is the first beta release of LLMBoost Hub.

### Added
- attach: Attach to a running model container and open a shell.
- completions: Manage shell completions.
- list: List supported models, their docker images, and statuses.
- login: Validates LLMBoost license.
- prep: Prepare the Docker image and local model assets for a given model.
- run: Run a model container.
- search: Search for models in the LLMBoost registry.
- serve: Start llmboost server inside the model container.
- status: Show a compact status table for models.
- stop: Stops a running container for a given model.
- test: Call the running llmboost serve endpoint and print the raw JSON response.
- tune: Start autotuning for a given model inside its container.
