import asyncio
import logging
import sys
from typing import List, Dict
from urllib.parse import urlparse
from mcp.server.fastmcp import FastMCP
# 导入你现有的组件
from .config import BrowserConfig, CrawlConfig
from .crawler import AsyncMinimalCrawler

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
logger = logging.getLogger("CrawlerMCP")
import subprocess
from pathlib import Path


def ensure_playwright_browsers():
    """
    通用检测并自动安装 Playwright 浏览器环境。
    各阶段独立捕获异常，互不干扰，并打印详细日志。
    """

    # ── 1. 平台适配 ──────────────────────────────────────────
    if sys.platform == "win32":
        base_path = Path.home() / "AppData" / "Local" / "ms-playwright"
        browser_type = "chromium"
    elif sys.platform == "darwin":
        base_path = Path.home() / "Library" / "Caches" / "ms-playwright"
        browser_type = "chromium"
    else:
        base_path = Path.home() / ".cache" / "ms-playwright"
        browser_type = "chromium-headless-shell"

    # ── 2. 检查是否已安装 ─────────────────────────────────────
    has_browser = (
        any(base_path.glob(f"{browser_type.replace('-', '_')}-*"))
        if base_path.exists() else False
    )
    if has_browser:
        logger.info(f"[SKIP] Found existing {browser_type} at {base_path}, skipping setup.")
        return

    logger.info(f"[SETUP] {browser_type} not found. Starting one-time setup...")

    # ── 3. 安装浏览器本体 ─────────────────────────────────────
    logger.info(f"[STEP 1/3] Installing {browser_type} via playwright...")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", browser_type],
            capture_output=True,
            text=True
        )
        logger.debug(f"[STEP 1] STDOUT: {result.stdout}")
        logger.debug(f"[STEP 1] STDERR: {result.stderr}")
        if result.returncode != 0:
            logger.error(f"[STEP 1 FAILED] playwright install exited with code {result.returncode}")
            logger.error(f"[STEP 1] STDOUT: {result.stdout}")
            logger.error(f"[STEP 1] STDERR: {result.stderr}")
            return  # 浏览器本体装不上，后续无意义，直接退出
        logger.info(f"[STEP 1] {browser_type} installed successfully.")
    except Exception as e:
        logger.error(f"[STEP 1 EXCEPTION] Unexpected error during browser install: {e}")
        return

    # ── 4. Linux 依赖安装 ─────────────────────────────────────
    if not sys.platform.startswith("linux"):
        logger.info(f"[DONE] Non-Linux platform, skipping dependency installation.")
        return

    # 4-a. apt-get update（失败不阻断后续）
    logger.info("[STEP 2/3] Running apt-get update...")
    result = subprocess.run(       # ✅ 无 check=True，不会抛异常
        ["apt-get", "update"],
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        logger.warning(f"[STEP 2] apt-get update returned {result.returncode}, continuing anyway.")
        logger.warning(f"[STEP 2] STDERR: {result.stderr[:500]}")
    else:
        logger.info("[STEP 2] apt-get update succeeded.")

    # 4-b. 尝试 playwright install-deps
    logger.info("[STEP 3/3] Trying playwright install-deps...")
    result = subprocess.run(       # ✅ 无 check=True，失败走 fallback
        [sys.executable, "-m", "playwright", "install-deps", browser_type],
        capture_output=True,
        text=True
    )
    logger.debug(f"[STEP 3] STDOUT: {result.stdout}")
    logger.debug(f"[STEP 3] STDERR: {result.stderr}")

    if result.returncode == 0:
        logger.info("[STEP 3] playwright install-deps succeeded.")
        logger.info("[DONE] Playwright environment is ready.")
        return

    # 4-c. Fallback：bookworm 兼容包名（去掉 t64 后缀）
    logger.warning(f"[STEP 3] playwright install-deps failed (code {result.returncode}), activating fallback.")
    logger.warning(f"[STEP 3] STDERR: {result.stderr[:500]}")
    logger.info("[FALLBACK] Installing Debian bookworm compatible dependencies manually...")

    bookworm_deps = [
        "libasound2",           # trixie 改名为 libasound2t64
        "libatk-bridge2.0-0",  # trixie 改名为 libatk-bridge2.0-0t64
        "libatk1.0-0",         # trixie 改名为 libatk1.0-0t64
        "libatspi2.0-0",       # trixie 改名为 libatspi2.0-0t64
        "libcups2",            # trixie 改名为 libcups2t64
        "libdbus-1-3",
        "libdrm2",
        "libgbm1",
        "libglib2.0-0",
        "libnss3",
        "libx11-6",
        "libxcb1",
        "libxcomposite1",
        "libxdamage1",
        "libxext6",
        "libxfixes3",
        "libxkbcommon0",
        "libxrandr2",
    ]

    result = subprocess.run(
        ["apt-get", "install", "-y", "--no-install-recommends"] + bookworm_deps,
        capture_output=True,
        text=True
    )
    logger.debug(f"[FALLBACK] STDOUT: {result.stdout}")
    if result.returncode != 0:
        logger.error(f"[FALLBACK FAILED] apt-get install exited with code {result.returncode}")
        logger.error(f"[FALLBACK] STDERR: {result.stderr}")
    else:
        logger.info("[FALLBACK] Bookworm dependencies installed successfully.")

    logger.info("[DONE] Playwright environment setup complete.")


# 在初始化之前调用
ensure_playwright_browsers()

# 初始化 FastMCP
mcp = FastMCP("WebCrawlerService")


def is_valid_url(url: str) -> bool:
    """简单校验是否为合法的 HTTP/HTTPS 网页链接"""
    try:
        result = urlparse(url)
        return all([result.scheme in ["http", "https"], result.netloc])
    except:
        return False


@mcp.tool()
async def crawl_urls(urls: List[str]) -> Dict[str, str]:
    """
    抓取指定 URL 列表的内容并返回 Markdown 格式文本。

    Args:
        urls: 需要爬取的 URL 字符串列表。
    Returns:
        Dict: 键为 URL，值为页面内容或错误提示。
    """
    # 1. 过滤非法 URL
    valid_urls = []
    results_map = {}

    for url in urls:
        if is_valid_url(url):
            valid_urls.append(url)
        else:
            results_map[url] = "thi url is not a website"

    if not valid_urls:
        return results_map

    # 2. 初始化爬虫 (针对 2核4G 强制开启 headless)
    # 建议此处保持 headless=True 以节省内存
    crawler = AsyncMinimalCrawler(BrowserConfig(headless=True))

    try:
        logger.info(f"Start crawling  {len(valid_urls)} urls...")

        # 3. 调用你现有的 arun_many 方法
        crawl_results = await crawler.arun_many(
            valid_urls,
            config=CrawlConfig()
        )

        # 4. 解析结果
        for r in crawl_results:
            if r.error:
                results_map[r.url] = f"Crawl failed: {r.error}"
            else:
                # 优先返回 markdown，如果没有则返回 content
                results_map[r.url] = r.markdown if r.markdown else "empty page"
            logger.info(r.url)
            logger.info(r.markdown)
            logger.info(len(r.markdown))

    except Exception as e:
        logger.error(f"Crawler error: {str(e)}")
        for url in valid_urls:
            if url not in results_map:
                results_map[url] = f"System error: {str(e)}"
    finally:
        # 极其重要：在 4G 内存机器上必须确保浏览器关闭
        # 如果你的 AsyncMinimalCrawler 没有自动 close，建议在这里显式处理
        pass

    return results_map


if __name__ == "__main__":
    # 使用 stdio 传输协议，方便与 Claude Desktop 等客户端集成
    mcp.run(transport="stdio")
