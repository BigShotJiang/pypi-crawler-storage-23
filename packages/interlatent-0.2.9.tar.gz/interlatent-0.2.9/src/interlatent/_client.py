from __future__ import annotations

import os
import tempfile
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Sequence

from ._exceptions import APIError
from ._http import HTTPClient
from ._resources import (
    AuthResource,
    CheckpointsResource,
    EnvironmentsResource,
    EpisodesResource,
    IndexResource,
    LatentsResource,
    RunsResource,
)


def _get_sdk_version() -> str:
    try:
        from importlib import metadata
        return metadata.version("interlatent")
    except Exception:
        return "0.0.dev"


def _detect_framework(model) -> str | None:
    if model is None:
        return None
    cls_name = type(model).__module__
    if "stable_baselines3" in cls_name:
        return "sb3"
    try:
        import torch
        if isinstance(model, torch.nn.Module):
            return "pytorch"
    except ImportError:
        pass
    return None


def _detect_layer_width(model, layer_path: str) -> int | None:
    import torch

    root = getattr(model, "policy", model)
    mod = root
    for attr in layer_path.split("."):
        mod = getattr(mod, attr, None)
        if mod is None:
            return None

    if isinstance(mod, torch.nn.Linear):
        return mod.out_features

    w = getattr(mod, "weight", None)
    if w is not None and w.ndim >= 2:
        return w.shape[0]

    return None


class Interlatent:
    """SDK client for the hosted Interlatent API with local collection support.

    Example (HTTP-only):
        client = Interlatent(base_url="https://api.example.com", api_key="...")
        runs = client.environments.runs("ant-v5")

    Example (collection + upload):
        client = Interlatent(api_key="...", base_url="https://api.interlatent.dev")
        client.watch(model, env, layer="auto")
        model.learn(100_000, callback=client.sb3_callback(checkpoint_every=10_000))
        client.checkpoint()
        client.runs.wait(client.run_id)
        client.close()
    """

    _BASE_URL = "https://interlatent.com"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        timeout: float = 30.0,
        db_path: str | None = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = self._BASE_URL
        self._http = HTTPClient(base_url=self._BASE_URL, api_key=api_key, timeout=timeout)

        # Resource groups
        self.index = IndexResource(self._http)
        self.auth = AuthResource(self._http)
        self.environments = EnvironmentsResource(self._http)
        self.runs = RunsResource(self._http)
        self.episodes = EpisodesResource(self._http)
        self.latents = LatentsResource(self._http)
        self.checkpoints = CheckpointsResource(self._http)

        # Collection state (lazy-init)
        self._db_path_override = db_path
        self._db = None
        self._watcher = None
        self._taxonomy = None
        self._env_name: str = "Unknown"
        self._layer: str = ""
        self._model_ref = None
        self._collect_run_id: str | None = None
        self._collect_steps: int = 0
        self._collect_start_time: str | None = None
        self._sae_k: int = 32
        self._checkpoint_count = 0

        # Media / frame state (lazy-init)
        self._media: "MediaBuffer | None" = None
        self._frame_every: int = 1
        self._frame_quality: int = 85

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def db_path(self) -> str | None:
        if self._db is not None:
            return str(self._db._store._path)
        return self._db_path_override

    @property
    def run_id(self) -> str | None:
        if self._collect_run_id:
            return self._collect_run_id
        if self._watcher is not None:
            return self._watcher.run_id
        return None

    @property
    def step_count(self) -> int:
        if self._watcher is not None:
            return self._watcher.step
        return self._collect_steps

    # ------------------------------------------------------------------
    # Collection API
    # ------------------------------------------------------------------

    def watch(
        self,
        model,
        env=None,
        *,
        layer: str | Sequence[str] = "auto",
        env_name: str | None = None,
        metrics: list | None = None,
        failures: dict[str, str] | None = None,
        successes: dict[str, str] | None = None,
        context_fn: Callable[..., Dict[str, Any]] | None = None,
        max_channels: int | None = None,
        total_steps: int | None = None,
        capture_frames: bool = False,
        frame_every: int = 1,
        frame_quality: int = 85,
    ):
        """Hook a model and start capturing activations.

        Returns the Watcher instance (already started).
        """
        from ._failures import FailureTaxonomy, auto_failures
        from ._layer_detect import detect_hookable_layers
        from ._metrics import auto_metrics, extract_env_id
        from ._watcher import Watcher

        # Auto-detect layers
        if layer == "auto":
            layers = detect_hookable_layers(model)
            if not layers:
                raise ValueError(
                    "Could not auto-detect hookable layers. "
                    "Please specify layer= explicitly."
                )
        elif isinstance(layer, str):
            layers = [layer]
        else:
            layers = list(layer)

        # Resolve env name
        if env_name is not None:
            self._env_name = env_name
        elif env is not None:
            self._env_name = extract_env_id(env)
        else:
            self._env_name = "Unknown"

        # Auto-detect metrics
        if metrics is None and env is not None:
            metrics = auto_metrics(env)

        # Resolve failure taxonomy
        if isinstance(failures, dict):
            taxonomy = FailureTaxonomy(failures, successes=successes)
        elif env is not None:
            taxonomy = auto_failures(env)
        else:
            taxonomy = None
        self._taxonomy = taxonomy

        self._layer = layers[0]

        # Auto-set sae_k based on layer width
        width = _detect_layer_width(model, layers[0])
        if width is not None:
            self._sae_k = min(64, width)

        self._model_ref = model

        # Ensure DB exists
        self._ensure_db()

        # Initialise frame capture
        if capture_frames:
            from ._media import MediaBuffer
            self._media = MediaBuffer(tempfile.mkdtemp(prefix="interlatent_media_"))
            self._frame_every = frame_every
            self._frame_quality = frame_quality

        self._watcher = Watcher(
            model,
            layers=layers,
            env_name=self._env_name,
            db=self._db,
            metrics=metrics,
            taxonomy=taxonomy,
            context_fn=context_fn,
            max_channels=max_channels,
            total_steps=total_steps,
        )
        self._watcher.start()
        return self._watcher

    def collect(
        self,
        model,
        env,
        *,
        steps: int = 5000,
        layer: str | Sequence[str] | None = None,
        metrics: list | None = None,
        failures: dict[str, str] | None = None,
        successes: dict[str, str] | None = None,
        context_fn: Callable[..., Dict[str, Any]] | None = None,
        deterministic: bool = True,
        max_channels: int | None = None,
        capture_frames: bool = False,
        frame_every: int = 1,
        frame_quality: int = 85,
    ) -> dict:
        """Collect activations from a trained model doing rollouts.

        Drives the env loop — the model runs inference and the environment
        is stepped automatically.

        Returns a summary dict with run_id and step count.
        """
        from ._failures import FailureTaxonomy, auto_failures
        from ._layer_detect import detect_hookable_layers
        from ._metrics import auto_metrics, extract_env_id

        # Stop any active watcher
        if self._watcher is not None:
            self._watcher.stop()

        # Resolve layers
        if layer is not None:
            layers = [layer] if isinstance(layer, str) else list(layer)
        elif self._layer:
            layers = [self._layer]
        else:
            layers = detect_hookable_layers(model)
            if not layers:
                raise ValueError(
                    "Could not auto-detect hookable layers. "
                    "Please specify layer= explicitly."
                )
        self._layer = layers[0]

        # Resolve env name
        self._env_name = extract_env_id(env)

        # Auto-detect metrics
        if metrics is None:
            metrics = auto_metrics(env)

        # Resolve failure taxonomy
        if isinstance(failures, dict):
            taxonomy = FailureTaxonomy(failures, successes=successes)
        elif self._taxonomy is not None:
            taxonomy = self._taxonomy
        else:
            taxonomy = auto_failures(env)
        self._taxonomy = taxonomy

        self._model_ref = model
        self._ensure_db()

        # Initialise frame capture
        if capture_frames:
            from ._media import MediaBuffer
            self._media = MediaBuffer(tempfile.mkdtemp(prefix="interlatent_media_"))
            self._frame_every = frame_every
            self._frame_quality = frame_quality

        # Create a watcher for the collection run
        from ._watcher import Watcher

        watcher = Watcher(
            model,
            layers=layers,
            env_name=self._env_name,
            db=self._db,
            metrics=metrics,
            taxonomy=taxonomy,
            context_fn=context_fn,
            max_channels=max_channels,
        )
        watcher.start()

        # Drive the env loop
        obs, _ = env.reset()
        for step_i in range(steps):
            # SB3 predict or torch forward
            if hasattr(model, "predict"):
                action, _ = model.predict(obs, deterministic=deterministic)
            else:
                import torch
                with torch.no_grad():
                    action = model(torch.as_tensor(obs).float().unsqueeze(0))
                    if hasattr(action, "numpy"):
                        action = action.squeeze(0).numpy()

            obs, reward, done, truncated, info = env.step(action)

            # Auto-capture frame
            if (
                self._media is not None
                and self._frame_every > 0
                and step_i % self._frame_every == 0
            ):
                try:
                    frame = env.render()
                    if frame is not None:
                        self._media.add_frame(
                            step_i, frame, quality=self._frame_quality,
                        )
                except Exception:
                    pass  # render() may not be available

            watcher.tick(
                obs=obs, reward=float(reward),
                done=bool(done), truncated=bool(truncated), info=info,
            )

            if done or truncated:
                obs, _ = env.reset()

        watcher.stop()
        self._collect_run_id = watcher.run_id
        self._collect_steps = steps
        self._collect_start_time = watcher.start_time

        return {
            "run_id": watcher.run_id,
            "steps": steps,
            "env_name": self._env_name,
            "layer": self._layer,
            "start_time": watcher.start_time,
        }

    def tick(
        self,
        *,
        obs=None,
        reward: float = 0.0,
        done: bool = False,
        truncated: bool = False,
        info: dict | None = None,
        frame=None,
    ) -> None:
        """Shortcut for ``_watcher.tick()``.

        Args:
            frame: Optional rendered frame (numpy array, PIL Image, or path).
                Saved to the media buffer if one is active.
        """
        if self._watcher is None:
            raise RuntimeError("No active watcher. Call watch() first.")
        if frame is not None and self._media is not None:
            step = self._watcher.step
            self._media.add_frame(step, frame, quality=self._frame_quality)
        self._watcher.tick(
            obs=obs, reward=reward, done=done,
            truncated=truncated, info=info,
        )

    def add_frame(self, step: int, image, *, quality: int = 85) -> None:
        """Manually add a frame to the media buffer.

        Lazy-initialises the MediaBuffer if it doesn't exist yet.
        """
        if self._media is None:
            from ._media import MediaBuffer
            self._media = MediaBuffer(tempfile.mkdtemp(prefix="interlatent_media_"))
        self._media.add_frame(step, image, quality=quality)

    def checkpoint(
        self,
        *,
        label: str = "",
        run_id: str | None = None,
        sae_k: int | None = None,
    ) -> dict:
        """Flush data, upload to server, and trigger server-side processing.

        1. Flushes buffered activation data
        2. Uploads raw SQLite DB to the server
        3. Triggers server-side processing (SAE training, labeling, export)

        Returns a summary dict with run_id, job_id, status.
        """
        # Resolve run_id
        if run_id is None:
            if self._collect_run_id:
                run_id = self._collect_run_id
            elif self._watcher is not None:
                self._watcher._flush_contexts()
                run_id = self._watcher.run_id
            else:
                raise RuntimeError(
                    "No data to checkpoint. Call watch() or collect() first."
                )

        if self._db is not None:
            self._db.flush()

        self._checkpoint_count += 1
        step_count = self.step_count
        k = sae_k or self._sae_k

        # Upload raw data
        self.upload(run_id=run_id, label=label)

        # Trigger server-side processing
        job_data = self.runs.process(run_id, sae_k=k)

        return {
            "run_id": run_id,
            "job_id": job_data.get("job_id", ""),
            "status": job_data.get("status", "pending"),
            "checkpoint_count": self._checkpoint_count,
            "step_count": step_count,
        }

    def upload(
        self,
        *,
        run_id: str | None = None,
        tags: dict[str, str] | None = None,
        label: str = "",
        workers: int = 8,
    ) -> None:
        """Upload raw activation data to the Interlatent server.

        Registers the run, uploads the local SQLite DB via pre-signed URLs,
        then confirms the upload.
        """
        import requests
        from concurrent.futures import ThreadPoolExecutor, as_completed

        # Resolve run_id
        rid = run_id
        if rid is None:
            if self._collect_run_id:
                rid = self._collect_run_id
            elif self._watcher is not None:
                rid = self._watcher.run_id
            else:
                raise RuntimeError(
                    "No run to upload. Call watch() or collect() first."
                )

        # Build taxonomy dict for server
        taxonomy_dict = None
        if self._taxonomy is not None:
            taxonomy_dict = {r.name: r.expression for r in self._taxonomy.rules
                            if r.name not in self._taxonomy.success_outcomes}

        # Step 1: Register run
        try:
            self.runs.create(
                run_id=rid,
                environment=self._env_name,
                layer=self._layer,
                created_at=(
                    self._collect_start_time
                    if rid == self._collect_run_id and self._collect_start_time
                    else (
                        self._watcher.start_time
                        if self._watcher is not None and rid == self._watcher.run_id
                        else None
                    )
                ),
                collect_steps=self._collect_steps or None,
                tags=tags or {},
                sdk_version=_get_sdk_version(),
                model_framework=_detect_framework(self._model_ref),
                failure_taxonomy=taxonomy_dict,
            )
        except APIError as exc:
            if exc.status_code != 409:
                raise  # only swallow 409 (run already registered)

        # Step 2: Collect files to upload
        db_path = self.db_path
        if db_path is None:
            return

        files: list[dict[str, Any]] = []
        p = Path(db_path)
        if p.exists():
            files.append({
                "key": "db/raw.db",
                "local": str(p),
                "size": p.stat().st_size,
            })

        # Include media files (frames, etc.)
        if self._media is not None:
            files.extend(self._media.list_files())

        if not files:
            return

        # Step 3+4: Request pre-signed URLs in batches and upload in parallel
        key_to_local = {f["key"]: f["local"] for f in files}
        uploaded = 0
        batch_size = 100

        def _put_file(local_path: str, put_url: str) -> bool:
            with open(local_path, "rb") as fh:
                resp = requests.put(put_url, data=fh, timeout=300)
                return resp.ok

        with ThreadPoolExecutor(max_workers=workers) as pool:
            for i in range(0, len(files), batch_size):
                batch = files[i : i + batch_size]
                url_resp = self.runs.upload_urls(
                    rid,
                    files=[{"key": f["key"], "size": f["size"]} for f in batch],
                )
                presigned = url_resp.get("presigned_urls", {})

                futures = {}
                for key, put_url in presigned.items():
                    local = key_to_local.get(key)
                    if local:
                        fut = pool.submit(_put_file, local, put_url)
                        futures[fut] = key

                for fut in as_completed(futures):
                    if fut.result():
                        uploaded += 1

        # Step 5: Notify completion
        self.runs.upload_complete(rid)

    def sb3_callback(self, *, checkpoint_every: int = 10_000):
        """Return an SB3 BaseCallback that auto-feeds the watcher.

        Args:
            checkpoint_every: Run checkpoint() every N training steps.
                Set to 0 to disable auto-checkpointing.
        """
        client = self

        class _SB3Callback:
            """Minimal SB3-compatible callback for activation collection."""

            def __init__(self):
                self.n_calls = 0
                self.num_timesteps = 0
                # These are set by SB3 during init_callback
                self.model = None
                self.training_env = None
                self.logger = None

            def init_callback(self, model) -> None:
                self.model = model

            def _on_step(self) -> bool:
                self.n_calls += 1
                self.num_timesteps += 1

                # Get step data from SB3's locals
                if client._watcher is not None:
                    # SB3 provides these via the training env
                    try:
                        from stable_baselines3.common.vec_env import VecEnv
                        env = getattr(self.model, "env", None)
                        if env is not None:
                            # VecEnv: get info from buffer
                            obs = getattr(self, "_last_obs", None)
                            if obs is None and hasattr(self.model, "_last_obs"):
                                obs = self.model._last_obs
                                if obs is not None and hasattr(obs, "__len__") and len(obs) > 0:
                                    obs = obs[0]
                    except ImportError:
                        pass

                if (
                    checkpoint_every > 0
                    and self.n_calls % checkpoint_every == 0
                    and client._watcher is not None
                ):
                    try:
                        client.checkpoint()
                    except Exception:
                        pass

                return True

            # SB3 BaseCallback protocol
            def on_step(self) -> bool:
                return self._on_step()

            def on_training_start(self, locals_dict, globals_dict) -> None:
                pass

            def on_training_end(self) -> None:
                pass

            def on_rollout_start(self) -> None:
                pass

            def on_rollout_end(self) -> None:
                pass

        return _SB3Callback()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        if self._watcher is not None:
            self._watcher.close()
            self._watcher = None
        if self._db is not None:
            self._db.close()
            self._db = None
        if self._media is not None:
            self._media.cleanup()
            self._media = None
        self._http.close()

    def __enter__(self) -> "Interlatent":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _ensure_db(self) -> None:
        """Lazily create the CollectionDB on first use."""
        if self._db is not None:
            return
        from ._db import CollectionDB

        path = self._db_path_override
        if path is None:
            path = f"interlatent_{uuid.uuid4().hex[:8]}.db"
            self._db_path_override = path
        self._db = CollectionDB(path)
