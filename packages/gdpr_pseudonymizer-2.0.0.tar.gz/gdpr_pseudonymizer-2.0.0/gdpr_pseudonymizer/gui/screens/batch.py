"""Batch processing screen with file selection, progress dashboard, and summary.

Three-phase screen using QStackedWidget:
  0 = Selection (file discovery + output dir)
  1 = Processing (progress dashboard with pause/cancel)
  2 = Summary (batch results + export)
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from PySide6.QtCore import QEvent, Qt, QThreadPool
from PySide6.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from gdpr_pseudonymizer.gui.accessibility.focus_manager import setup_focus_order_batch
from gdpr_pseudonymizer.gui.i18n import qarg
from gdpr_pseudonymizer.gui.widgets.step_indicator import StepMode
from gdpr_pseudonymizer.gui.widgets.toast import Toast
from gdpr_pseudonymizer.gui.workers.batch_worker import (
    BatchResult,
    collect_files,
)
from gdpr_pseudonymizer.utils.logger import get_logger

if TYPE_CHECKING:
    from gdpr_pseudonymizer.gui.main_window import MainWindow
    from gdpr_pseudonymizer.nlp.entity_detector import DetectedEntity

logger = get_logger(__name__)


class BatchScreen(QWidget):
    """Batch processing screen: selection -> processing -> summary."""

    def __init__(self, main_window: MainWindow) -> None:
        super().__init__(main_window)
        self._main_window = main_window
        self._config = main_window.config

        self._files: list[Path] = []
        self._worker: Any = None
        self._batch_start_time: float = 0.0
        self._cumulative_validation_time: float = 0.0
        self._docs_completed: int = 0
        self._is_paused: bool = False

        self._build_ui()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_context(self, **kwargs: Any) -> None:
        """Accept navigation context (e.g., folder_path from home screen).

        Kwargs:
            folder_path: Pre-populate the folder input and discover files.
            reset: If True, clear all selection state for a fresh start.
        """
        if kwargs.get("reset"):
            self._reset_selection()

        folder_path = kwargs.get("folder_path")
        if folder_path:
            self._folder_input.setText(str(folder_path))
            self._discover_files()

        self._phases.setCurrentIndex(0)

    def _reset_selection(self) -> None:
        """Clear all selection state for a fresh batch run."""
        self._folder_input.blockSignals(True)
        self._folder_input.clear()
        self._folder_input.blockSignals(False)
        self._output_input.clear()
        self._files = []
        self._update_file_table()
        self._start_btn.setEnabled(False)
        self._worker = None

    # ------------------------------------------------------------------
    # UI Construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._phases = QStackedWidget()
        self._phases.addWidget(self._build_selection_phase())
        self._phases.addWidget(self._build_processing_phase())
        self._phases.addWidget(self._build_summary_phase())
        layout.addWidget(self._phases)

        # Set translatable text
        self.retranslateUi()

        # Configure keyboard navigation
        setup_focus_order_batch(self)

    # -- Phase 0: Selection --

    def _build_selection_phase(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 24, 40, 24)
        layout.setSpacing(16)

        # Header
        header = QHBoxLayout()
        self._sel_back_btn = QPushButton()
        self._sel_back_btn.setObjectName("secondaryButton")
        self._sel_back_btn.clicked.connect(
            lambda: self._main_window.navigate_to("home")
        )
        header.addWidget(self._sel_back_btn)
        header.addStretch()
        self._sel_title = QLabel()
        self._sel_title.setStyleSheet("font-size: 20px; font-weight: bold;")
        header.addWidget(self._sel_title)
        header.addStretch()
        layout.addLayout(header)

        # Folder input
        folder_row = QHBoxLayout()
        self._folder_label = QLabel()
        self._folder_label.setStyleSheet("font-weight: bold;")
        folder_row.addWidget(self._folder_label)

        self._folder_input = QLineEdit()
        self._folder_input.textChanged.connect(lambda _: self._discover_files())
        # Accessibility support (AC2 - Task 4.2)
        self._folder_input.setAccessibleName(self.tr("Dossier source"))
        self._folder_input.setAccessibleDescription(
            self.tr("Chemin du dossier contenant les fichiers à traiter")
        )
        folder_row.addWidget(self._folder_input, stretch=1)

        self._browse_folder_btn = QPushButton()
        self._browse_folder_btn.setObjectName("secondaryButton")
        self._browse_folder_btn.clicked.connect(self._browse_folder)
        # Accessibility support (AC2 - Task 4.2)
        self._browse_folder_btn.setAccessibleName(self.tr("Parcourir les dossiers"))
        self._browse_folder_btn.setAccessibleDescription(
            self.tr(
                "Ouvre un explorateur de fichiers pour sélectionner le dossier source"
            )
        )
        folder_row.addWidget(self._browse_folder_btn)

        self._add_files_btn = QPushButton()
        self._add_files_btn.setObjectName("secondaryButton")
        self._add_files_btn.clicked.connect(self._add_files)
        # Accessibility support (AC2 - Task 4.2)
        self._add_files_btn.setAccessibleName(self.tr("Ajouter des fichiers"))
        self._add_files_btn.setAccessibleDescription(
            self.tr(
                "Ouvre un sélecteur pour ajouter des fichiers individuels à traiter"
            )
        )
        folder_row.addWidget(self._add_files_btn)

        layout.addLayout(folder_row)

        # File count
        self._file_count_label = QLabel("")
        self._file_count_label.setObjectName("secondaryLabel")
        layout.addWidget(self._file_count_label)

        # File list table
        self._file_table = QTableWidget(0, 3)
        self._file_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Stretch
        )
        self._file_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.ResizeToContents
        )
        self._file_table.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.ResizeMode.ResizeToContents
        )
        self._file_table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        self._file_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        # Accessibility support (AC2 - Task 4.2)
        self._file_table.setAccessibleName(self.tr("Liste des fichiers à traiter"))
        self._file_table.setAccessibleDescription(
            self.tr("Affiche les fichiers sélectionnés avec leur taille et format")
        )
        layout.addWidget(self._file_table, stretch=1)

        # Per-document validation toggle (AC1, AC5)
        self._validate_checkbox = QCheckBox()
        self._validate_checkbox.setChecked(
            self._config.get("batch_validate_per_document", False)
        )
        self._validate_checkbox.setAccessibleName(
            self.tr("Valider les entités par document")
        )
        self._validate_checkbox.setAccessibleDescription(
            self.tr(
                "Lorsque activé, permet de vérifier les entités détectées "
                "dans chaque document avant la pseudonymisation"
            )
        )
        self._validate_checkbox.toggled.connect(self._on_validate_toggle_changed)
        layout.addWidget(self._validate_checkbox)

        # Output directory
        output_row = QHBoxLayout()
        self._output_label = QLabel()
        self._output_label.setStyleSheet("font-weight: bold;")
        output_row.addWidget(self._output_label)

        self._output_input = QLineEdit()
        # Accessibility support (AC2 - Task 4.2)
        self._output_input.setAccessibleName(self.tr("Dossier de sortie"))
        self._output_input.setAccessibleDescription(
            self.tr("Chemin du dossier où enregistrer les fichiers pseudonymisés")
        )
        output_row.addWidget(self._output_input, stretch=1)

        self._output_browse_btn = QPushButton()
        self._output_browse_btn.setObjectName("secondaryButton")
        self._output_browse_btn.clicked.connect(self._browse_output)
        # Accessibility support (AC2 - Task 4.2)
        self._output_browse_btn.setAccessibleName(
            self.tr("Parcourir le dossier de sortie")
        )
        self._output_browse_btn.setAccessibleDescription(
            self.tr("Ouvre un explorateur pour sélectionner le dossier de sortie")
        )
        output_row.addWidget(self._output_browse_btn)
        layout.addLayout(output_row)

        # Start button
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self._start_btn = QPushButton()
        self._start_btn.setEnabled(False)
        self._start_btn.clicked.connect(self._start_batch)
        # Accessibility support (AC2 - Task 4.2)
        self._start_btn.setAccessibleName(self.tr("Démarrer le traitement par lot"))
        self._start_btn.setAccessibleDescription(
            self.tr("Lance le traitement de tous les fichiers sélectionnés")
        )
        btn_row.addWidget(self._start_btn)
        layout.addLayout(btn_row)

        return page

    # -- Phase 1: Processing --

    def _build_processing_phase(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 24, 40, 24)
        layout.setSpacing(16)

        # Title
        self._proc_title = QLabel()
        self._proc_title.setStyleSheet("font-size: 20px; font-weight: bold;")
        self._proc_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self._proc_title)

        # Overall progress
        self._progress_label = QLabel("0/0 (0%)")
        self._progress_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._progress_label.setStyleSheet("font-size: 14px;")
        layout.addWidget(self._progress_label)

        self._progress_bar = QProgressBar()
        self._progress_bar.setMaximum(100)
        # Accessibility support (AC2 - Task 3.5)
        self._progress_bar.setAccessibleName(
            self.tr("Progression du traitement par lot")
        )
        self._progress_bar.setAccessibleDescription(
            self.tr("Barre de progression indiquant le nombre de fichiers traités")
        )
        layout.addWidget(self._progress_bar)

        # ETA
        self._eta_label = QLabel("")
        self._eta_label.setObjectName("secondaryLabel")
        self._eta_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self._eta_label)

        # Per-document table
        self._doc_table = QTableWidget(0, 4)
        self._doc_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.ResizeToContents
        )
        self._doc_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.Stretch
        )
        self._doc_table.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.ResizeMode.ResizeToContents
        )
        self._doc_table.horizontalHeader().setSectionResizeMode(
            3, QHeaderView.ResizeMode.ResizeToContents
        )
        self._doc_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._doc_table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        # Accessibility support (AC2 - Task 4.2)
        self._doc_table.setAccessibleName(self.tr("Progression par document"))
        self._doc_table.setAccessibleDescription(
            self.tr("Affiche l'état du traitement pour chaque document du lot")
        )
        layout.addWidget(self._doc_table, stretch=1)

        # Controls
        ctrl_row = QHBoxLayout()
        ctrl_row.addStretch()

        self._pause_btn = QPushButton()
        self._pause_btn.setObjectName("secondaryButton")
        self._pause_btn.clicked.connect(self._toggle_pause)
        # Accessibility support (AC2 - Task 4.2)
        self._pause_btn.setAccessibleName(self.tr("Suspendre le traitement"))
        self._pause_btn.setAccessibleDescription(
            self.tr("Met en pause ou reprend le traitement du lot")
        )
        ctrl_row.addWidget(self._pause_btn)

        self._cancel_btn = QPushButton()
        self._cancel_btn.setObjectName("secondaryButton")
        self._cancel_btn.clicked.connect(self._cancel_batch)
        # Accessibility support (AC2 - Task 4.2)
        self._cancel_btn.setAccessibleName(self.tr("Annuler le traitement par lot"))
        self._cancel_btn.setAccessibleDescription(
            self.tr("Annule le traitement en conservant les documents déjà traités")
        )
        ctrl_row.addWidget(self._cancel_btn)

        layout.addLayout(ctrl_row)

        return page

    # -- Phase 2: Summary --

    def _build_summary_phase(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 24, 40, 24)
        layout.setSpacing(16)

        self._summary_title = QLabel()
        self._summary_title.setStyleSheet("font-size: 20px; font-weight: bold;")
        self._summary_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self._summary_title)

        # Summary cards
        cards = QHBoxLayout()
        self._card_docs, self._card_docs_label = self._make_card("0")
        self._card_entities, self._card_entities_label = self._make_card("0")
        self._card_new, self._card_new_label = self._make_card("0")
        self._card_reused, self._card_reused_label = self._make_card("0")
        self._card_errors, self._card_errors_label = self._make_card("0")
        cards.addWidget(self._card_docs)
        cards.addWidget(self._card_entities)
        cards.addWidget(self._card_new)
        cards.addWidget(self._card_reused)
        cards.addWidget(self._card_errors)
        layout.addLayout(cards)

        # Per-document results table
        self._summary_table = QTableWidget(0, 4)
        self._summary_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Stretch
        )
        self._summary_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        # Accessibility support (AC2 - Task 4.2)
        self._summary_table.setAccessibleName(self.tr("Résultats par document"))
        self._summary_table.setAccessibleDescription(
            self.tr("Affiche le résumé du traitement pour chaque document du lot")
        )
        layout.addWidget(self._summary_table, stretch=1)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        self._export_btn = QPushButton()
        self._export_btn.setObjectName("secondaryButton")
        self._export_btn.clicked.connect(self._export_report)
        # Accessibility support (AC2 - Task 4.2)
        self._export_btn.setAccessibleName(self.tr("Exporter le rapport"))
        self._export_btn.setAccessibleDescription(
            self.tr("Exporte un rapport texte détaillé du traitement par lot")
        )
        btn_row.addWidget(self._export_btn)

        self._home_btn = QPushButton()
        self._home_btn.clicked.connect(self._go_home)
        # Accessibility support (AC2 - Task 4.2)
        self._home_btn.setAccessibleName(self.tr("Retour à l'accueil"))
        self._home_btn.setAccessibleDescription(self.tr("Retourne à l'écran d'accueil"))
        btn_row.addWidget(self._home_btn)

        layout.addLayout(btn_row)

        return page

    def _make_card(self, value: str) -> tuple[QWidget, QLabel]:
        """Create a summary card widget and return (card, label_widget)."""
        card = QWidget()
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(16, 12, 16, 12)
        val = QLabel(value)
        val.setObjectName("cardValue")
        val.setStyleSheet("font-size: 24px; font-weight: bold;")
        val.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(val)
        lbl = QLabel("")
        lbl.setObjectName("secondaryLabel")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(lbl)
        return card, lbl

    def retranslateUi(self) -> None:
        """Re-set all translatable static UI text."""
        # Phase 0: Selection
        self._sel_back_btn.setText(self.tr("\u25c0 Retour"))
        self._sel_title.setText(self.tr("Traitement par lot"))
        self._folder_label.setText(self.tr("Dossier source :"))
        self._folder_input.setPlaceholderText(self.tr("Sélectionnez un dossier..."))
        self._browse_folder_btn.setText(self.tr("Parcourir..."))
        self._add_files_btn.setText(self.tr("Ajouter des fichiers"))
        self._file_table.setHorizontalHeaderLabels(
            [self.tr("Fichier"), self.tr("Taille"), self.tr("Format")]
        )
        self._output_label.setText(self.tr("Dossier de sortie :"))
        self._output_input.setPlaceholderText(self.tr("_pseudonymized/ (par défaut)"))
        self._output_browse_btn.setText(self.tr("Parcourir..."))
        self._start_btn.setText(self.tr("Démarrer le traitement"))
        self._validate_checkbox.setText(self.tr("Valider les entités par document"))

        # Phase 1: Processing
        self._proc_title.setText(self.tr("Traitement en cours"))
        self._doc_table.setHorizontalHeaderLabels(
            [
                self.tr("#"),
                self.tr("Fichier"),
                self.tr("Entités"),
                self.tr("Statut"),
            ]
        )
        self._pause_btn.setText(self.tr("Suspendre"))
        self._cancel_btn.setText(self.tr("Annuler le lot"))

        # Phase 2: Summary
        self._summary_title.setText(self.tr("Résumé du traitement"))
        self._card_docs_label.setText(self.tr("Documents"))
        self._card_entities_label.setText(self.tr("Entités"))
        self._card_new_label.setText(self.tr("Nouvelles"))
        self._card_reused_label.setText(self.tr("Réutilisées"))
        self._card_errors_label.setText(self.tr("Erreurs"))
        self._summary_table.setHorizontalHeaderLabels(
            [
                self.tr("Fichier"),
                self.tr("Entités"),
                self.tr("Temps"),
                self.tr("Statut"),
            ]
        )
        self._export_btn.setText(self.tr("Exporter le rapport"))
        self._home_btn.setText(self.tr("Retour à l'accueil"))

    def changeEvent(self, event: QEvent) -> None:
        if event.type() == QEvent.Type.LanguageChange:
            self.retranslateUi()
        super().changeEvent(event)

    # ------------------------------------------------------------------
    # Selection Phase Logic
    # ------------------------------------------------------------------

    def _browse_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self, self.tr("Sélectionner un dossier")
        )
        if folder:
            self._folder_input.setText(folder)

    def _add_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(
            self,
            self.tr("Ajouter des fichiers"),
            "",
            self.tr("Documents (*.txt *.md *.pdf *.docx);;Tous (*)"),
        )
        if files:
            for f in files:
                p = Path(f)
                if p not in self._files and "_pseudonymized" not in p.stem:
                    self._files.append(p)
            self._update_file_table()
            self._start_btn.setEnabled(len(self._files) > 0)

    def _browse_output(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, self.tr("Dossier de sortie"))
        if folder:
            self._output_input.setText(folder)

    def _on_validate_toggle_changed(self, checked: bool) -> None:
        """Persist validation toggle state to config."""
        self._config["batch_validate_per_document"] = checked
        from gdpr_pseudonymizer.gui.config import save_gui_config

        save_gui_config(self._config)

    def _discover_files(self) -> None:
        folder_text = self._folder_input.text().strip()
        if not folder_text:
            self._files = []
            self._update_file_table()
            self._start_btn.setEnabled(False)
            return

        folder = Path(folder_text)
        if folder.is_dir():
            self._files = collect_files(folder)
            self._update_file_table()
            self._start_btn.setEnabled(len(self._files) > 0)

            # Pre-populate output dir
            if not self._output_input.text().strip():
                default_output = self._config.get("default_output_dir", "")
                if not default_output:
                    default_output = str(folder / "_pseudonymized")
                self._output_input.setText(default_output)
        else:
            self._files = []
            self._update_file_table()
            self._start_btn.setEnabled(False)

    def _update_file_table(self) -> None:
        self._file_table.setRowCount(len(self._files))
        supported_count = 0
        for row, fp in enumerate(self._files):
            name_item = QTableWidgetItem(fp.name)
            try:
                size = fp.stat().st_size
                if size < 1024:
                    size_str = qarg(self.tr("%1 o"), str(size))
                elif size < 1024 * 1024:
                    size_str = qarg(self.tr("%1 Ko"), f"{size / 1024:.1f}")
                else:
                    size_str = qarg(self.tr("%1 Mo"), f"{size / (1024 * 1024):.1f}")
            except OSError:
                size_str = "?"
            size_item = QTableWidgetItem(size_str)
            fmt_item = QTableWidgetItem(fp.suffix.upper().lstrip("."))

            self._file_table.setItem(row, 0, name_item)
            self._file_table.setItem(row, 1, size_item)
            self._file_table.setItem(row, 2, fmt_item)
            supported_count += 1

        self._file_count_label.setText(
            qarg(self.tr("%1 fichier(s) supporté(s)"), str(supported_count))
        )

    # ------------------------------------------------------------------
    # Processing Phase Logic
    # ------------------------------------------------------------------

    def _start_batch(self) -> None:
        if not self._files:
            return

        # Prompt for passphrase
        cached = self._main_window.cached_passphrase
        if cached is not None:
            db_path, passphrase = cached
            self._launch_worker(db_path, passphrase)
            return

        file_dir = self._folder_input.text().strip() or str(Path.home())

        from gdpr_pseudonymizer.gui.widgets.passphrase_dialog import PassphraseDialog

        dialog = PassphraseDialog(
            file_directory=file_dir,
            config=self._config,
            parent=self._main_window,
        )
        if dialog.exec() != dialog.DialogCode.Accepted:
            return

        result = dialog.get_result()
        if result is None:
            return

        db_path, passphrase, remember = result
        if remember:
            self._main_window.cached_passphrase = (db_path, passphrase)

        self._launch_worker(db_path, passphrase)

    def _launch_worker(self, db_path: str, passphrase: str) -> None:
        from gdpr_pseudonymizer.gui.workers.batch_worker import BatchWorker

        # Store for validation flow (Task 5.2)
        self._db_path = db_path
        self._passphrase = passphrase

        # Determine output dir
        output_text = self._output_input.text().strip()
        if output_text:
            output_dir = Path(output_text)
        else:
            folder = self._folder_input.text().strip()
            output_dir = Path(folder) / "_pseudonymized" if folder else Path(".")

        theme = self._config.get("default_theme", "neutral")
        continue_on_error = self._config.get("continue_on_error", True)
        validation_mode = self._config.get("batch_validation_mode", "per_document")
        validate_per_document = self._validate_checkbox.isChecked()

        # Switch to processing phase
        self._phases.setCurrentIndex(1)
        self._main_window.step_indicator.set_mode(StepMode.BATCH)
        self._main_window.step_indicator.set_step(1)

        # Initialize progress table
        self._docs_completed = 0
        self._batch_start_time = time.time()
        self._cumulative_validation_time = 0.0
        self._validation_pause_start: float | None = None
        self._validation_results: dict[int, list[DetectedEntity]] = {}
        self._validation_contexts: dict[int, dict[str, Any]] = {}
        self._doc_table.setRowCount(len(self._files))
        for row, fp in enumerate(self._files):
            self._doc_table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self._doc_table.setItem(row, 1, QTableWidgetItem(fp.name))
            self._doc_table.setItem(row, 2, QTableWidgetItem(""))
            status_item = QTableWidgetItem(self.tr("En attente"))
            status_item.setForeground(Qt.GlobalColor.gray)
            self._doc_table.setItem(row, 3, status_item)

        self._progress_bar.setValue(0)
        self._progress_label.setText(
            qarg(self.tr("%1/%2 (%3%)"), "0", str(len(self._files)), "0")
        )
        self._eta_label.setText("")
        self._pause_btn.setText(self.tr("Suspendre"))
        self._is_paused = False

        # Create and start worker
        self._worker = BatchWorker(
            files=self._files,
            output_dir=output_dir,
            db_path=db_path,
            passphrase=passphrase,
            theme=theme,
            continue_on_error=continue_on_error,
            validation_mode=validation_mode,
            validate_per_document=validate_per_document,
        )
        self._worker.signals.progress.connect(self._on_progress)
        self._worker.signals.finished.connect(self._on_finished)
        self._worker.signals.error.connect(self._on_error)

        # Connect validation signals if enabled
        if validate_per_document:
            from gdpr_pseudonymizer.gui.workers.signals import BatchValidationSignals

            assert isinstance(self._worker.signals, BatchValidationSignals)
            self._worker.signals.validation_required.connect(
                self._on_validation_required
            )

            # Connect ValidationScreen signals (disconnect first to prevent
            # duplicate connections across multiple batch runs — BUG-001)
            val_idx = self._main_window._screens.get("validation")
            if val_idx is not None:
                val_widget = self._main_window.stack.widget(val_idx)
                from gdpr_pseudonymizer.gui.screens.validation import ValidationScreen

                if isinstance(val_widget, ValidationScreen):
                    try:
                        val_widget.validation_complete.disconnect(
                            self._on_validation_complete
                        )
                    except RuntimeError:
                        pass  # Not connected yet
                    try:
                        val_widget.batch_cancel_requested.disconnect(self._do_cancel)
                    except RuntimeError:
                        pass  # Not connected yet
                    val_widget.validation_complete.connect(self._on_validation_complete)
                    val_widget.batch_cancel_requested.connect(self._do_cancel)

        QThreadPool.globalInstance().start(self._worker)

    def _on_progress(self, percent: int, message: str) -> None:
        """Handle progress signal from worker."""
        self._progress_bar.setValue(percent)

        if message.startswith("DOC_DONE:"):
            # Document completed
            idx = int(message.split(":")[1])
            self._docs_completed = idx + 1
            total = len(self._files)
            self._progress_label.setText(
                qarg(
                    self.tr("%1/%2 (%3%)"),
                    str(self._docs_completed),
                    str(total),
                    str(percent),
                )
            )

            # Update ETA (exclude cumulative validation pause time)
            elapsed = (
                time.time() - self._batch_start_time - self._cumulative_validation_time
            )
            if self._docs_completed > 0:
                avg_per_doc = elapsed / self._docs_completed
                remaining = (total - self._docs_completed) * avg_per_doc
                if remaining < 60:
                    eta_str = qarg(self.tr("~%1 secondes"), str(int(remaining)))
                else:
                    eta_str = qarg(self.tr("~%1 minutes"), str(int(remaining / 60)))
                self._eta_label.setText(
                    qarg(self.tr("Temps estimé restant : %1"), eta_str)
                )

            # Update document table row
            if self._worker is not None:
                status_item = QTableWidgetItem(self.tr("Traité"))
                status_item.setForeground(Qt.GlobalColor.darkGreen)
                self._doc_table.setItem(idx, 3, status_item)

            # Mark next document as "En cours"
            if self._docs_completed < total:
                status_item = QTableWidgetItem(self.tr("En cours"))
                status_item.setForeground(Qt.GlobalColor.blue)
                self._doc_table.setItem(self._docs_completed, 3, status_item)
        else:
            # Pre-processing message (e.g., loading model)
            if self._docs_completed == 0 and self._files:
                status_item = QTableWidgetItem(self.tr("En cours"))
                status_item.setForeground(Qt.GlobalColor.blue)
                self._doc_table.setItem(0, 3, status_item)

    def _on_finished(self, result: object) -> None:
        """Handle batch completion."""
        if not isinstance(result, BatchResult):
            return

        self._worker = None
        self._batch_result = result

        # Update doc table with final results
        processed_indices: set[int] = set()
        for doc_res in result.per_document_results:
            processed_indices.add(doc_res.index)
            if doc_res.success:
                entities = str(doc_res.entities_detected)
                self._doc_table.setItem(doc_res.index, 2, QTableWidgetItem(entities))
                if result.cancelled:
                    status_item = QTableWidgetItem(self.tr("Annulé"))
                    status_item.setForeground(Qt.GlobalColor.darkYellow)
                else:
                    status_item = QTableWidgetItem(self.tr("Traité"))
                    status_item.setForeground(Qt.GlobalColor.darkGreen)
            else:
                status_item = QTableWidgetItem(self.tr("Erreur"))
                status_item.setForeground(Qt.GlobalColor.red)
                status_item.setToolTip(doc_res.error_message)
            self._doc_table.setItem(doc_res.index, 3, status_item)

        # Mark unprocessed docs when cancelled
        if result.cancelled:
            for idx in range(len(self._files)):
                if idx not in processed_indices:
                    status_item = QTableWidgetItem(self.tr("Non traité"))
                    status_item.setForeground(Qt.GlobalColor.gray)
                    self._doc_table.setItem(idx, 3, status_item)

        self._progress_bar.setValue(100)
        total = str(len(self._files))
        self._progress_label.setText(qarg(self.tr("%1/%2 (%3%)"), total, total, "100"))
        self._eta_label.setText("")

        # Show summary
        self._show_summary(result)

    def _on_error(self, error_msg: str) -> None:
        """Handle fatal worker error."""
        self._worker = None

        # Clear cached passphrase on auth errors so user can retry
        if "passphrase" in error_msg.lower() or "decrypt" in error_msg.lower():
            self._main_window.cached_passphrase = None

        from gdpr_pseudonymizer.gui.widgets.confirm_dialog import ConfirmDialog

        ConfirmDialog.informational(
            self.tr("Erreur de traitement"),
            error_msg,
            parent=self._main_window,
        ).exec()

        self._phases.setCurrentIndex(0)

    def _toggle_pause(self) -> None:
        if self._worker is None:
            return

        if not self._is_paused:
            self._worker.pause()
            self._is_paused = True
            self._pause_btn.setText(self.tr("Reprendre"))
            self._eta_label.setText(self.tr("Traitement suspendu"))
        else:
            self._worker.resume()
            self._is_paused = False
            self._pause_btn.setText(self.tr("Suspendre"))
            self._eta_label.setText("")

    def _cancel_batch(self) -> None:
        from gdpr_pseudonymizer.gui.widgets.confirm_dialog import ConfirmDialog

        dlg = ConfirmDialog.destructive(
            self.tr("Annuler le traitement"),
            self.tr("Aucun fichier de sortie ne sera conservé."),
            self.tr("Annuler le lot"),
            parent=self._main_window,
        )
        if dlg.exec():
            self._do_cancel()

    def _do_cancel(self) -> None:
        """Shared cancel handler for BatchScreen and ValidationScreen cancel buttons."""
        if self._worker is not None:
            self._worker.cancel()
        # If we're on the validation screen, navigate back to batch
        if self._main_window.current_screen_name() == "validation":
            self._main_window.navigate_to("batch")

    # ------------------------------------------------------------------
    # Batch Validation Orchestration (AC2, AC3, AC4, AC6)
    # ------------------------------------------------------------------

    def _on_validation_required(
        self,
        entities: object,
        document_text: str,
        doc_index: int,
        total_docs: int,
    ) -> None:
        """Handle validation_required signal from BatchWorker.

        Generates pseudonym previews, then navigates to ValidationScreen
        in batch mode.
        """
        from gdpr_pseudonymizer.core.document_processor import DocumentProcessor

        entity_list: list[DetectedEntity] = entities  # type: ignore[assignment]

        # Track validation pause time for ETA exclusion
        self._validation_pause_start = time.time()

        # Update progress table to show "En attente de validation"
        if doc_index < self._doc_table.rowCount():
            status_item = QTableWidgetItem(self.tr("En attente de validation"))
            status_item.setForeground(Qt.GlobalColor.darkYellow)
            self._doc_table.setItem(doc_index, 3, status_item)

        # Generate pseudonym previews
        try:
            processor = DocumentProcessor(
                db_path=self._db_path,
                passphrase=self._passphrase,
            )
            previews = processor.build_pseudonym_previews(entity_list)
        except Exception:
            previews = {}
            logger.warning("batch_preview_generation_failed", doc_index=doc_index)

        # Cache full context for prev/next navigation (FUNC-001)
        doc_path = str(self._files[doc_index]) if doc_index < len(self._files) else ""
        context = {
            "entities": entity_list,
            "document_text": document_text,
            "document_path": doc_path,
            "pseudonym_previews": previews,
            "db_path": self._db_path,
            "passphrase": self._passphrase,
            "batch_mode": True,
            "doc_index": doc_index,
            "total_docs": total_docs,
        }
        self._validation_contexts[doc_index] = context

        # Navigate to ValidationScreen in batch mode
        self._main_window.navigate_to("validation", **context)

    def _on_validation_complete(self, validated_entities: object) -> None:
        """Handle validation_complete signal from ValidationScreen.

        Stores validated entities, submits them to the worker, and navigates
        back to the batch processing phase.
        """
        entity_list: list[DetectedEntity] = validated_entities  # type: ignore[assignment]

        # Track which doc was validated (current awaiting index)
        current_doc_idx = self._docs_completed
        self._validation_results[current_doc_idx] = entity_list

        # Update cached context with validated entities (FUNC-001)
        if current_doc_idx in self._validation_contexts:
            self._validation_contexts[current_doc_idx]["entities"] = entity_list

        # Exclude validation pause time from ETA calculation
        if self._validation_pause_start is not None:
            self._cumulative_validation_time += (
                time.time() - self._validation_pause_start
            )
            self._validation_pause_start = None

        # Update progress table
        if current_doc_idx < self._doc_table.rowCount():
            status_item = QTableWidgetItem(self.tr("Pseudonymisation"))
            status_item.setForeground(Qt.GlobalColor.blue)
            self._doc_table.setItem(current_doc_idx, 3, status_item)

        # Submit to worker and navigate back
        if self._worker is not None:
            self._worker.submit_validation_result(entity_list)

        self._main_window.navigate_to("batch")

    # ------------------------------------------------------------------
    # Summary Phase Logic
    # ------------------------------------------------------------------

    def _show_summary(self, result: BatchResult) -> None:
        self._phases.setCurrentIndex(2)
        self._main_window.step_indicator.set_step(3)

        if result.cancelled:
            self._summary_title.setText(self.tr("Traitement annulé"))

        # Update cards
        self._update_card(self._card_docs, str(result.successful_files))
        self._update_card(self._card_entities, str(result.total_entities))
        self._update_card(self._card_new, str(result.new_entities))
        self._update_card(self._card_reused, str(result.reused_entities))
        self._update_card(self._card_errors, str(result.failed_files))

        # Build lookup for per-document results by index
        doc_results_by_idx = {dr.index: dr for dr in result.per_document_results}

        # Show all files when cancelled, otherwise only processed ones
        total_rows = (
            result.total_files if result.cancelled else len(result.per_document_results)
        )
        self._summary_table.setRowCount(total_rows)

        for row in range(total_rows):
            doc_res = doc_results_by_idx.get(row)

            if doc_res is not None:
                time_str = f"{doc_res.processing_time:.1f}s"
                self._summary_table.setItem(row, 0, QTableWidgetItem(doc_res.filename))
                self._summary_table.setItem(
                    row, 1, QTableWidgetItem(str(doc_res.entities_detected))
                )
                self._summary_table.setItem(row, 2, QTableWidgetItem(time_str))

                if result.cancelled and doc_res.success:
                    status_item = QTableWidgetItem(self.tr("Annulé"))
                    status_item.setForeground(Qt.GlobalColor.darkYellow)
                elif doc_res.success:
                    status_item = QTableWidgetItem(self.tr("Traité"))
                    status_item.setForeground(Qt.GlobalColor.darkGreen)
                else:
                    status_item = QTableWidgetItem(self.tr("Erreur"))
                    status_item.setForeground(Qt.GlobalColor.red)
                    status_item.setToolTip(doc_res.error_message)
            else:
                # Unprocessed file (cancelled before reaching it)
                filename = (
                    self._files[row].name
                    if row < len(self._files)
                    else f"Document {row + 1}"
                )
                self._summary_table.setItem(row, 0, QTableWidgetItem(filename))
                self._summary_table.setItem(row, 1, QTableWidgetItem("\u2014"))
                self._summary_table.setItem(row, 2, QTableWidgetItem("\u2014"))
                status_item = QTableWidgetItem(self.tr("Non traité"))
                status_item.setForeground(Qt.GlobalColor.gray)

            self._summary_table.setItem(row, 3, status_item)

    @staticmethod
    def _update_card(card: QWidget, value: str) -> None:
        val_label = card.layout().itemAt(0).widget()
        if isinstance(val_label, QLabel):
            val_label.setText(value)

    def _export_report(self) -> None:
        if not hasattr(self, "_batch_result"):
            return

        filepath, _ = QFileDialog.getSaveFileName(
            self,
            self.tr("Exporter le rapport"),
            "batch_report.txt",
            self.tr("Texte (*.txt);;Tous (*)"),
        )
        if not filepath:
            return

        result = self._batch_result
        lines = [
            self.tr("GDPR Pseudonymizer — Rapport de traitement par lot"),
            "=" * 50,
            "",
            qarg(
                self.tr("Documents traités : %1/%2"),
                str(result.successful_files),
                str(result.total_files),
            ),
            qarg(self.tr("Entités détectées : %1"), str(result.total_entities)),
            qarg(self.tr("  - Nouvelles : %1"), str(result.new_entities)),
            qarg(self.tr("  - Réutilisées : %1"), str(result.reused_entities)),
            qarg(self.tr("Erreurs : %1"), str(result.failed_files)),
            qarg(
                self.tr("Temps total : %1s"),
                f"{result.total_time_seconds:.1f}",
            ),
            "",
            self.tr("Détails par document :"),
            "-" * 40,
        ]

        for doc_res in result.per_document_results:
            status = "OK" if doc_res.success else self.tr("ERREUR")
            line = qarg(
                self.tr("  %1: %2 | %3 entités | %4s"),
                doc_res.filename,
                status,
                str(doc_res.entities_detected),
                f"{doc_res.processing_time:.1f}",
            )
            if not doc_res.success:
                line += f" | {doc_res.error_message}"
            lines.append(line)

        if result.errors:
            lines.extend(["", self.tr("Erreurs :"), "-" * 40])
            for err in result.errors:
                lines.append(f"  \u2022 {err}")

        try:
            Path(filepath).write_text("\n".join(lines), encoding="utf-8")
            Toast.show_message(self.tr("Rapport exporté."), self._main_window)
        except OSError:
            Toast.show_message(
                self.tr("Erreur lors de l'export."),
                self._main_window,
                duration_ms=4000,
            )

    def _go_home(self) -> None:
        self._main_window.step_indicator.set_step(0)
        self._main_window.navigate_to("home")

    # -- Test accessors --

    @property
    def phases(self) -> QStackedWidget:
        return self._phases

    @property
    def folder_input(self) -> QLineEdit:
        return self._folder_input

    @property
    def output_input(self) -> QLineEdit:
        return self._output_input

    @property
    def file_table(self) -> QTableWidget:
        return self._file_table

    @property
    def start_button(self) -> QPushButton:
        return self._start_btn

    @property
    def progress_bar(self) -> QProgressBar:
        return self._progress_bar

    @property
    def progress_label(self) -> QLabel:
        return self._progress_label

    @property
    def eta_label(self) -> QLabel:
        return self._eta_label

    @property
    def doc_table(self) -> QTableWidget:
        return self._doc_table

    @property
    def pause_button(self) -> QPushButton:
        return self._pause_btn

    @property
    def cancel_button(self) -> QPushButton:
        return self._cancel_btn

    @property
    def summary_table(self) -> QTableWidget:
        return self._summary_table

    @property
    def export_button(self) -> QPushButton:
        return self._export_btn

    @property
    def file_count_label(self) -> QLabel:
        return self._file_count_label

    @property
    def validate_checkbox(self) -> QCheckBox:
        return self._validate_checkbox
