The duck image shown on the splash screen was obtained from:
https://commons.wikimedia.org/wiki/File:Rubber_duckies_So_many_ducks.jpg

The image is released under a cc-by-2.0 license.

The version used here has been modified from the original by cropping to a subset of the original image, and muting the colors.