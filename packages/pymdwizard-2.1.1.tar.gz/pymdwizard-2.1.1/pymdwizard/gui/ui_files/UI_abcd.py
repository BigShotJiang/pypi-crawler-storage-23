# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'abcd.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!
