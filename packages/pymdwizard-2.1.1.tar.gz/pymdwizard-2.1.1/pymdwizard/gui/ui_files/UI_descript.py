# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'descript.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_fgdc_descript(object):
    def setupUi(self, fgdc_descript):
        fgdc_descript.setObjectName("fgdc_descript")
        fgdc_descript.resize(181, 54)
        self.verticalLayout = QtWidgets.QVBoxLayout(fgdc_descript)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.retranslateUi(fgdc_descript)
        QtCore.QMetaObject.connectSlotsByName(fgdc_descript)

    def retranslateUi(self, fgdc_descript):
        _translate = QtCore.QCoreApplication.translate
        fgdc_descript.setWindowTitle(_translate("fgdc_descript", "Form"))
