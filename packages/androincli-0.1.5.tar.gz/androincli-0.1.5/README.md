# andro-cli — Source Package

This directory is the **uv project root**. It contains the source code, virtual environment, and package config.

## Quick Start

```bash
# Install dependencies
uv --directory src sync

# Run the app
uv --directory src run python main.py
```

Or from inside `src/`:
```bash
uv venv
source .venv/Scripts/activate   # Git Bash
uv sync
python main.py
```

## Structure

```
src/
├── main.py           # Entry point (API key check → TUI)
├── pyproject.toml    # Package config & dependencies
├── uv.lock           # Locked dependency versions
├── agent/            # Core agent logic
│   ├── config.py     # API key & config management
│   ├── setup.py      # Gemini AsyncOpenAI client
│   └── tools/        # Agent tools (files, network, system)
└── ui/               # Textual TUI
    ├── app.py        # AgentApp
    └── components/   # Reusable widgets
        ├── bubble.py      # Chat message bubble
        └── input_bar.py   # Input + send button
```

## Adding Dependencies

```bash
uv --directory src add <package>
```

## Running Tests

```bash
uv --directory src run pytest
```
