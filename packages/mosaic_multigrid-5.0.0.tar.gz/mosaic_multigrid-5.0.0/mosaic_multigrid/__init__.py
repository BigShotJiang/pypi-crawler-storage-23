"""MOSAIC multigrid -- research-grade multi-agent gridworld environments."""
