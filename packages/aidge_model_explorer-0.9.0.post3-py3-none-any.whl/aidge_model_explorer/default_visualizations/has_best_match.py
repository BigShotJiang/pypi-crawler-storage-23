from typing import Dict

import aidge_core
from aidge_model_explorer.config import config as gen_config
from aidge_model_explorer.converters.converter_config import ConverterConfig
from aidge_model_explorer.visualize import visualize_from_config


def has_best_match(graph: aidge_core.GraphView, backend: str = None) -> None:
    """
    Visualize an Aidge graph and annotate nodes whose operator implementation
    exactly matches its required specifications.

    Optionally temporarily sets all nodes' operator backend before conversion,
    restoring the original backend after visualization.

    :param graph: An `aidge_core.GraphView` representing the model graph to analyze.
    :param backend: (optional) Name of the backend to temporarily assign to all
                    operator nodes. If not provided or None, no re-assignment
                    is performed.
    :raises RuntimeError: If setting the backend fails on any node; restores
                          original backends before propagating the error.

    """
    original_backends: Dict[aidge_core.Node, str] = {}

    if backend is not None:
        try:
            # Save original backends
            for node in graph.get_nodes():
                original_backends[node] = node.get_operator().backend()

            # Try to set the backend
            for node in graph.get_nodes():
                node.get_operator().set_backend(backend)
        except Exception as e:
            # Restore previous backends on failure
            for node, original_backend in original_backends.items():
                node.set_backend(original_backend)
            raise RuntimeError(
                f"Failed to set backend '{backend}' for all nodes. Error: {e}"
            )

    def test_best_match(node):
        res = None
        # Skip node with a default impl
        if not node.get_operator().backend():
            return None
        try:
            op_impl = node.get_operator().get_impl()
            required_specs = op_impl.get_required_spec()
            get_best_match = op_impl.get_best_match(required_specs)
            if get_best_match == required_specs:
                res = f"Required specs:\n{required_specs}\nAvailable:\n{op_impl.get_available_impl_specs()}"
                ("model_explorer:")
        except Exception as e:
            res = "Error:\n{e}"
        return res

    def add_color(nodes):
        for node in nodes:
            if isinstance(node.get_operator(), aidge_core.MetaOperatorOp):
                add_color(node.get_operator().get_micro_graph().get_nodes())
                continue

            if node.get_operator().backend():
                op_impl = node.get_operator().get_impl()
                required_specs = op_impl.get_required_spec()
                get_best_match = op_impl.get_best_match(required_specs)
                if get_best_match == required_specs:
                    node.attributes().set_attr(
                        name="model_explorer:bg_color", value="#ff0800"
                    )

    add_color(graph.get_nodes())
    config = gen_config()

    converter_config = ConverterConfig()
    converter_config.add_attribute("fail_best_match", test_best_match)
    config.add_graphview(graph, "best_match", converter_config)
    visualize_from_config(config)
    if backend is not None:
        for node, original_backend in original_backends.items():
            if original_backend != "":
                node.get_operator().set_backend(original_backend)
