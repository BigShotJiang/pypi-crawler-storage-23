from typing import TypedDict

from model_explorer.config import ModelExplorerConfig
from typing_extensions import NotRequired, Optional

import aidge_core

from .consts import MODULE_ID
from .converters import ConverterConfig
from .main import AidgeAdapter

ModelSource = TypedDict("ModelSource", {"url": str, "adapterId": NotRequired[str]})


def config() -> ModelExplorerConfig:
    """Create a new config object."""
    return AidgeExplorerConfig()


class AidgeExplorerConfig(ModelExplorerConfig):
    """Stores the data to be visualized in Model Explorer."""

    # Required
    # pylint: disable=useless-parent-delegation
    def __init__(self) -> None:
        super().__init__()

    def add_graphview(
        self,
        graphview: aidge_core.GraphView,
        name: str,
        converter_config: Optional[ConverterConfig] = None,
    ) -> "ModelExplorerConfig":
        """Add a aidge_core.GraphView to the list of graph to visualize

        :param graphview: Graph view to add to the list
        :type graphview: aidge_core.GraphView
        :param name: Name to give to the graph in the model explorer interface
        :type name: str
        :param converter_config: Configuration for the converter that let the user define custom attributes, default=None
        :type converter_config: ConverterConfig, optional
        :return: Return a reference to itself
        :rtype: ModelExplorerConfig
        """
        aidge_core.Log.notice(f"Converting GraphView {name}...")
        adapter = AidgeAdapter()
        graphs_index = len(self.graphs_list)
        graphs = adapter.convert_graphview(
            graphview, {}, name=name, converter_config=converter_config
        )
        self.graphs_list.append(graphs)

        # Construct model source.
        #
        # The model source has a special format, in the form of:
        # graphs://{name}/{graphs_index}
        model_source: ModelSource = {
            "url": f"graphs://{name}/{graphs_index}",
            "adapterId": MODULE_ID,
        }
        self.model_sources.append(model_source)
        return self
