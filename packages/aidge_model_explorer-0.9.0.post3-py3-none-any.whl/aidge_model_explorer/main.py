from pathlib import Path
from typing import Dict, Optional

from model_explorer import Adapter, AdapterMetadata, ModelExplorerGraphs

from aidge_core import GraphView

from .consts import MODULE_DESCRIPTION, MODULE_ID, MODULE_NAME
from .converters import ConverterConfig, onnx_converter, runtime_converter


class AidgeAdapter(Adapter):
    """
    Adapter for converting ONNX models or `aidge_core.GraphView` objects into
    `ModelExplorerGraphs` format, for use in the ModelExplorer GUI.

    This adapter supports `.onnx` files and uses internal converters to transform
    models into the graph structure expected by the frontend.

    :cvar metadata: Metadata about the adapter, including name, description,
                    source repository, and supported file extensions.
    :vartype metadata: AdapterMetadata
    """

    metadata = AdapterMetadata(
        id=MODULE_ID,
        name=MODULE_NAME,
        description=MODULE_DESCRIPTION,
        source_repo="https://gitlab.eclipse.org/eclipse/aidge/aidge_model_explorer",
        fileExts=["onnx"],
    )

    def __init__(self):
        """
        Initialize the AidgeAdapter.
        """
        super().__init__()

    def convert(self, model_path: str, settings: Dict) -> ModelExplorerGraphs:
        """
        Convert an ONNX model file to a `ModelExplorerGraphs` object.

        :param model_path: Path to the ONNX model file.
        :type model_path: str
        :param settings: Dictionary of visualization or conversion settings.
        :type settings: Dict

        :return: A dictionary containing a list of converted graphs under the key `'graphs'`.
        :rtype: ModelExplorerGraphs

        :raises RuntimeError: If the file extension is not supported.
        """
        graph = None
        model_path = Path(model_path)
        if model_path.suffix == ".onnx":
            graph = onnx_converter.convert_onnx(model_path, settings)
        else:
            raise RuntimeError(
                f"{MODULE_NAME} does not support {model_path.suffix} files."
            )
        return {"graphs": [graph]}

    def convert_graphview(
        self,
        model: GraphView,
        settings: Dict,
        name: str = "",
        converter_config: Optional[ConverterConfig] = None,
    ) -> ModelExplorerGraphs:
        """
        Convert an in-memory `aidge_core.GraphView` object to `ModelExplorerGraphs`.

        :param model: The graph view to convert.
        :type model: GraphView
        :param settings: Dictionary of visualization or conversion settings.
        :type settings: Dict
        :param name: Optional name for the graph. Defaults to ''.
        :type name: str, optional
        :param converter_config: Optional configuration object defining custom attributes and metadata.
        :type converter_config: Optional[ConverterConfig]

        :return: A dictionary containing a list of converted graphs under the key `'graphs'`.
        :rtype: ModelExplorerGraphs
        """
        graph = runtime_converter.convert_graphview(
            model, name, converter_config=converter_config
        )
        return {"graphs": [graph]}
