MODULE_ID = "aidge_model_explorer"
MODULE_NAME = "Aidge adapter"
MODULE_DESCRIPTION = (
    "Plugin of the framework Google Model Explorer to visualize Aidge graphs."
)
DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8080
