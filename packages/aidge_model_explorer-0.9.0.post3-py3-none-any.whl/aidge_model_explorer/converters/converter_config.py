from dataclasses import dataclass
from typing import List, Optional, Protocol

import aidge_core


class MetadataCallable(Protocol):
    """
    A callable protocol that takes an ``aidge_core.Node`` and an ``aidge_core.Tensor`` and
    returns a string to be stored as output metadata in the ModelExplorer GUI.

    This callable is invoked for every output tensor of a node. If it returns ``None``,
    no metadata attribute will be added for that tensor.

    Example usage:

    .. code-block:: python

        def extract_tensor_name(node: aidge_core.Node, tensor: aidge_core.Tensor) -> Optional[str]:
            return tensor.name if tensor.name else None

        metadata_fn: MetadataCallable = extract_tensor_name

    :param node: The node that owns the output tensor.
    :type node: aidge_core.Node
    :param tensor: The output tensor for which metadata is being computed.
    :type tensor: aidge_core.Tensor
    :return: A string representing the metadata value to store, or ``None`` if no metadata should be created.
    :rtype: Optional[str]
    """

    def __call__(
        self, node: aidge_core.Node, tensor: aidge_core.Tensor
    ) -> Optional[str]: ...


class AttributeCallable(Protocol):
    """
    A callable protocol that, given an ``aidge_core.Node``, returns a string value to be stored
    as an attribute in the ModelExplorer GUI.

    This callable will be invoked on every node. If it returns ``None``, no attribute
    will be created for that node.

    Example usage:

    .. code-block:: python

        def get_label(node: aidge_core.Node) -> Optional[str]:
            return node.label if node.has_label else None

        callable_instance: AttributeCallable = get_label

    :param node: A node in the Aidge model graph.
    :type node: aidge_core.Node
    :return: A string representing the attribute to store, or ``None`` if no attribute should be created.
    :rtype: Optional[str]
    """

    def __call__(self, node: aidge_core.Node) -> Optional[str]: ...


@dataclass
class CustomOutMetadata:
    """
    A configuration container for customizing output metadata in the ModelExplorer GUI.

    :param metadata_name: The name of the metadata field to display.
    :type metadata_name: str
    :param metadata_callable: A callable that extracts the metadata value from a node and its output tensor.
                            If the callable returns ``None``, the metadata will not be displayed.
    :type metadata_callable: MetadataCallable
    """

    metadata_name: str
    metadata_callable: MetadataCallable


@dataclass
class CustomAttribute:
    """
    A configuration container for customizing node attributes in the ModelExplorer GUI.

    :param attr_name: The name of the attribute field to display.
    :type attr_name: str
    :param attr_callable: A callable that extracts an attribute value from a node.
                          If the callable returns ``None``, the attribute will not be added.
    :type attr_callable: AttributeCallable
    """

    attr_name: str
    attr_callable: AttributeCallable


class ConverterConfig:
    """
    Configuration object for customizing the ModelExplorer GUI.

    This class stores user-defined functions that compute additional
    metadata or attributes for nodes and their output tensors in a model graph.

    :ivar custom_output_metadata: A list of output metadata definitions, each specifying a name and a callable
                                  that extracts metadata from a node and its output tensor.
    :vartype custom_output_metadata: List[CustomOutMetadata]

    :ivar custom_attributes: A list of custom attribute definitions, each specifying a name and a callable
                             that extracts an attribute from a node.
    :vartype custom_attributes: List[CustomAttribute]
    """

    def __init__(self):
        """
        Initialize an empty :class:`ConverterConfig` with no custom metadata or attributes.
        """
        self.custom_output_metadata: List[CustomOutMetadata] = []
        self.custom_attributes: List[CustomAttribute] = []

    def add_output_metadata(
        self, meta_data_name: str, meta_data_callable: MetadataCallable
    ) -> None:
        """
        Add a custom output metadata extractor.

        :param meta_data_name: The name of the metadata field to be displayed in the GUI.
        :type meta_data_name: str
        :param meta_data_callable: A callable that takes a node and one of its output tensors, and returns
                                   a string to be used as metadata. If it returns ``None``, no metadata will be added.
        :type meta_data_callable: MetadataCallable
        """
        self.custom_output_metadata.append(
            CustomOutMetadata(meta_data_name, meta_data_callable)
        )

    def add_attribute(self, attr_name: str, attr_callable: AttributeCallable) -> None:
        """
        Add a custom attribute extractor for nodes.

        :param attr_name: The name of the attribute field to be displayed in the GUI.
        :type attr_name: str
        :param attr_callable: A callable that takes a node and returns a string to be used as an attribute.
                              If it returns ``None``, no attribute will be added.
        :type attr_callable: AttributeCallable
        """
        self.custom_attributes.append(CustomAttribute(attr_name, attr_callable))
