from pathlib import Path
from typing import Dict

from model_explorer import ModelExplorerGraphs

import aidge_onnx

from .runtime_converter import convert_graphview


def convert_onnx(model_path: Path, settings: Dict) -> ModelExplorerGraphs:
    return convert_graphview(aidge_onnx.load_onnx(model_path), name=model_path.stem)
