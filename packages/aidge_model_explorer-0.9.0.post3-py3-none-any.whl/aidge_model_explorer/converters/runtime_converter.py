import json

import numpy as np
from model_explorer import graph_builder
from typing_extensions import Optional

from aidge_core import (
    GenericOperatorOp,
    GraphView,
    Log,
    MetaOperatorOp,
    Node,
    ProducerOp,
    Tensor,
    expand_metaops,
)

from .converter_config import ConverterConfig


def _is_metaop(node: Node) -> bool:
    return isinstance(node.get_operator(), MetaOperatorOp)


def _get_unique_id(node: Node) -> str:
    """
    Given a node return a ``model_explorer:id``.
    Which can be different from its aidge_core.Node.id().
    For example a node already viewed that is cloned will keep
    its ``model_explorer:id`` even if it will have a different
    aidge_core.Node.id().
    """
    return node.attributes().get_attr("model_explorer:id")


def _set_unique_id(graph: GraphView) -> None:
    """For each node, set an attribute ``model_explorer:id``.
    This ``id`` is based on node.id().
    The reason why we save it as an attribute is so that it stay
    even after cloning the graph.

    This is useful for multiple reasons:
      - We need to clone the graph to "expand_metaops" when parsing
      nodes to connect them
      - Aidge graph modifications such as ``fuse_to_metaops`` call
      aidge_core.Node.clone(), keeping this id allow to then synchronize
      a graph after and before modifications.
    """
    for node in graph.get_nodes():
        if node.attributes().has_attr(name="model_explorer:id"):
            continue
        unique_id = node.id()
        if _is_metaop(node):
            _set_unique_id(node.get_operator().get_micro_graph())
        node.attributes().set_attr(name="model_explorer:id", value=unique_id)


def _generate_names(graphview: GraphView) -> None:
    def _rec_add(graphview: GraphView) -> GraphView:
        view = GraphView()
        view.add(graphview)
        for n in graphview.get_nodes():
            if _is_metaop(n):
                view.add(_rec_add(n.get_operator().get_micro_graph()))
        return view

    view_on_all_nodes = _rec_add(graphview)

    for node, formatted_name in view_on_all_nodes.get_ranked_nodes_name(
        "{1}_{2}", mark_non_unicity=True
    ).items():
        view_on_all_nodes.remove(node, include_learnable_parameters=False)

        current_name = node.name()
        if current_name:
            continue

        Log.debug(f"Setting node name: {formatted_name}")
        node.set_name(formatted_name)


def _tensor_to_json(tensor: Tensor) -> str:
    if not tensor.impl:
        Log.info("Tensor has no implementation; skipping value.")
        return ""
    try:
        array = np.array(tensor)
        size_limit = 20
        if size_limit < 0 or size_limit >= array.size:
            # Use separators=(',', ':') to remove spaces
            return json.dumps(array.tolist(), separators=(",", ":"))
        # Show the first `size_limit` elements if the tensor is too large
        return json.dumps(
            (array.flatten())[:size_limit].tolist(), separators=(",", ":")
        ).replace("]", ", ...]")
    except Exception as e:
        Log.warn("Failed to display tensor (%s): %s", tensor, e)
    return ""


def _get_in_name(aidge_node: Node, in_idx: int) -> str:
    inputs_name = []
    if hasattr(aidge_node.get_operator(), "get_inputs_name"):
        inputs_name = aidge_node.get_operator().get_inputs_name()
    in_name = f"Input#{in_idx}"
    if in_idx < len(inputs_name):
        in_name = inputs_name[in_idx]
    return in_name


def _get_out_name(aidge_node: Node, out_idx: int) -> str:
    outputs_name = []
    if hasattr(aidge_node.get_operator(), "get_outputs_name"):
        outputs_name = aidge_node.get_operator().get_outputs_name()
    out_name = f"Output#{out_idx}"
    if out_idx < len(outputs_name):
        out_name = outputs_name[out_idx]
    return out_name


def _convert_node(
    aidge_node: Node,
    namespace: str = "",
    converter_config: Optional[ConverterConfig] = None,
) -> dict[str, graph_builder.GraphNode]:
    aidge_operator = aidge_node.get_operator()
    node_name = aidge_node.name()
    # Convert nodes
    Log.debug(f"Converting {node_name} ...")
    converted_nodes: dict[str, graph_builder.GraphNode] = {}
    # if namespace != "": namespace += "/"
    if _is_metaop(aidge_node):
        # MetaOperator are handled by namespace
        if namespace != "":
            namespace += "/"
        # Recursive call for each sub node with the
        # namespace corresponding to the MetaOperator label
        for sub_node in aidge_node.get_operator().get_micro_graph().get_nodes():
            converted_nodes.update(
                _convert_node(
                    sub_node,
                    namespace=f"{namespace}{node_name}[{aidge_node.type()}]",
                    converter_config=converter_config,
                )
            )
    else:
        bg_color = ""
        border_color = ""
        # Border color on hover
        h_border_color = ""

        if isinstance(aidge_node.get_operator(), GenericOperatorOp):
            border_color = "#d9534f"
            bg_color = "#fbeaea"
        elif isinstance(aidge_node.get_operator(), ProducerOp):
            border_color = "#3d5160"
            bg_color = "#cae4f8"
        if aidge_node.attributes().has_attr("model_explorer:bg_color"):
            bg_color = aidge_node.attributes().get_attr("model_explorer:bg_color")
        if aidge_node.attributes().has_attr("model_explorer:border_color"):
            border_color = aidge_node.attributes().get_attr(
                "model_explorer:border_color"
            )
        if aidge_node.attributes().has_attr("model_explorer:h_border_color"):
            h_border_color = aidge_node.attributes().get_attr(
                "model_explorer:h_border_color"
            )

        # Create node
        converted_node = graph_builder.GraphNode(
            id=f"{_get_unique_id(aidge_node)}",
            label=node_name,
            namespace=namespace,
            style=graph_builder.GraphNodeStyle(
                backgroundColor=bg_color,
                borderColor=border_color,
                hoveredBorderColor=h_border_color,
            ),
        )
        # Add node attributes
        converted_node.attrs.append(
            graph_builder.KeyValue(key="type", value=aidge_node.type())
        )

        # Add operator attributes
        if aidge_operator.attr:
            Log.debug("Attributes:")
            for key, value in aidge_operator.attr.dict().items():
                Log.debug(f"\t- {key}: {value}")
                converted_node.attrs.append(
                    graph_builder.KeyValue(key=key, value=str(value))
                )

        # Add backend as an attribute
        if aidge_operator.backend():
            Log.debug(f"\t- backend: {aidge_operator.backend()}")
            converted_node.attrs.append(
                graph_builder.KeyValue(
                    key="backend", value=str(aidge_operator.backend())
                )
            )

        # Add user defined attributes
        if converter_config is not None:
            Log.debug("Adding custom attributes:")
            for custom_attr in converter_config.custom_attributes:
                custom_attr_name = custom_attr.attr_name

                try:
                    custom_attr_value = custom_attr.attr_callable(aidge_node)
                except Exception as e:
                    Log.warn(
                        f"Could not load attribute {custom_attr_name}, due to error:\n{e}"
                    )
                    continue
                if custom_attr_value is None:
                    continue

                Log.debug(f"\t- {custom_attr_name}: {custom_attr_value}")
                converted_node.attrs.append(
                    graph_builder.KeyValue(
                        key=custom_attr_name, value=custom_attr_value
                    )
                )

        # Add output information
        for out_id in range(aidge_node.get_nb_outputs()):
            out_tensor = aidge_node.get_operator().get_output(out_id)
            output_metadata = graph_builder.MetadataItem(
                id=str(out_id),
                attrs=[
                    graph_builder.KeyValue(
                        key="dformat", value=str(out_tensor.dformat)
                    ),
                    graph_builder.KeyValue(key="dtype", value=str(out_tensor.dtype)),
                    graph_builder.KeyValue(key="size", value=str(out_tensor.size)),
                    graph_builder.KeyValue(key="dims", value=str(out_tensor.dims)),
                    graph_builder.KeyValue(
                        key="backend", value=str(out_tensor.backend)
                    ),
                    # While interesting tensor values slow down the rendering of bug graphs
                    graph_builder.KeyValue(
                        key="values", value=_tensor_to_json(out_tensor)
                    ),
                    # __tensor_tag is a special tag that "name" the edge
                    graph_builder.KeyValue(
                        key="__tensor_tag", value=_get_out_name(aidge_node, out_id)
                    ),
                ],
            )
            converted_node.outputsMetadata.append(output_metadata)

        if converter_config is not None:
            Log.debug("Adding custom output metadata:")
            for custom_out_metadata in converter_config.custom_output_metadata:
                metadata_name = custom_out_metadata.metadata_name
                try:
                    metadata_value = custom_out_metadata.metadata_callable(
                        aidge_node, out_tensor
                    )
                except Exception as e:
                    Log.warn(
                        f"Could not load metadata {metadata_name}, due to error:\n{e}"
                    )
                    continue
                if metadata_value is None:
                    continue
                Log.debug(f"\t- {metadata_name}: {metadata_value}")
                output_metadata.attrs.append(
                    graph_builder.KeyValue(key=metadata_name, value=metadata_value)
                )

        Log.debug(f"Adding {node_name} to list of converted nodes.")
        converted_nodes[_get_unique_id(aidge_node)] = converted_node

    return converted_nodes


def convert_graphview(
    graphview: GraphView, name: str, converter_config: Optional[ConverterConfig] = None
) -> graph_builder.Graph:
    meg: graph_builder.Graph = graph_builder.Graph(id=name)
    converted_nodes = {}
    # Set unique names to every operator of the graph
    _generate_names(graphview)
    _set_unique_id(graphview)
    # First step convert aidge node
    for aidge_node in graphview.get_nodes():
        converted_nodes.update(
            _convert_node(aidge_node, converter_config=converter_config)
        )

    # Connect nodes together
    # Note: this is done after creating every nodes as we need
    # To know the id of every parents this is difficult to do for two reasons:
    # - 1. Inside of a MetaOperator we don't have access to parents and children of the MetaOp
    # - 2. GraphView.get_nodes returns an unordered list so we don't have guarantee that
    # the parent node id has been generated

    flatten_graphview = graphview.clone()
    expand_metaops(flatten_graphview, recursive=True)
    for aidge_node in flatten_graphview.get_nodes():
        # Connect nodes
        for in_id, (parent_node, out_id) in enumerate(aidge_node.inputs()):
            if parent_node:
                Log.debug(
                    f"Connecting {parent_node.name()}[{parent_node.type()}] -> {aidge_node.name()}[{aidge_node.type()}]"
                )
                converted_nodes[_get_unique_id(aidge_node)].incomingEdges.append(
                    graph_builder.IncomingEdge(
                        sourceNodeId=converted_nodes[_get_unique_id(parent_node)].id,
                        targetNodeInputId=str(in_id),
                        sourceNodeOutputId=str(out_id),
                    )
                )
            input_metadata = graph_builder.MetadataItem(
                id=str(in_id),
                attrs=[
                    graph_builder.KeyValue(
                        key="__tensor_tag", value=_get_in_name(aidge_node, in_id)
                    )
                ],
            )
            converted_nodes[_get_unique_id(aidge_node)].inputsMetadata.append(
                input_metadata
            )
    meg.nodes.extend(converted_nodes.values())

    return meg
