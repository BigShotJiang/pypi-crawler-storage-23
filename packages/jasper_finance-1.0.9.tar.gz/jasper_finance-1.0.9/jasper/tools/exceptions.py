class DataProviderError(Exception):
    """Raised when a data provider fails to return valid data."""
    pass
 