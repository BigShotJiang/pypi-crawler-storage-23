from .core import DworshakConfig

__all__ = [
    "DworshakConfig"
]