"""Google Sheets integration module."""
