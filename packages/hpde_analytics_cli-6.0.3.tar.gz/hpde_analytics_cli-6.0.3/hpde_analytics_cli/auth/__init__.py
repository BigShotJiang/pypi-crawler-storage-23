"""OAuth authentication module."""
