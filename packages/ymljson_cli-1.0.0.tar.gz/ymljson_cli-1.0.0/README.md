# ymljson-cli

A lightweight CLI tool for bidirectional **YAML ↔ JSON** conversion with optional JSON Schema validation.

## Installation

Requires Python >= 3.8.

```bash
pip install ymljson-cli
```

Or from source:

```bash
git clone <repo-url>
cd ymljson-cli
pip install .
```

## Usage

The input format (JSON or YAML) is auto-detected, and the output format is the opposite.

```
ymljson [-h] [-i INPUT] [-o OUTPUT] [--compact] [--schema SCHEMA] [-v]
```

### Options

| Flag | Description |
|------|-------------|
| `-i`, `--input PATH` | Input file path (default: stdin) |
| `-o`, `--output PATH` | Output file path (default: stdout) |
| `--compact` | Compact output — disables pretty-printing |
| `--schema PATH` | Path to a JSON Schema file to validate input against |
| `-v`, `--verbose` | Enable debug logging |

### Examples

**JSON → YAML (stdin/stdout):**
```bash
echo '{"name": "Alice", "age": 30}' | ymljson
```

**YAML → JSON from file:**
```bash
ymljson -i config.yaml -o config.json
```

**Compact JSON output:**
```bash
ymljson -i data.yaml --compact
```

**With schema validation:**
```bash
ymljson -i data.yaml --schema schema.json -o data.json
```

If validation fails, the tool exits with code `2` and logs the error. Any other error exits with code `1`.

## Dependencies

- [`pyyaml`](https://pypi.org/project/PyYAML/)
- [`jsonschema`](https://pypi.org/project/jsonschema/)

## License

MIT — see [LICENSE](LICENSE).
