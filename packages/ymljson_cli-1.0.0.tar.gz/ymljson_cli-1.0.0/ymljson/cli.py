import argparse
import json
import sys
import yaml
import logging
from jsonschema import validate, ValidationError

logger = logging.getLogger("ymljson")


def detect_format(content):
    try:
        json.loads(content)
        return "json"
    except json.JSONDecodeError:
        pass
    try:
        result = yaml.safe_load(content)
        if isinstance(result, (dict, list)):
            return "yaml"
    except yaml.YAMLError:
        pass
    raise ValueError("Unrecognized format (not valid JSON or YAML).")


def read_input(path):
    if not path:
        logger.debug("Reading input from stdin.")
        return sys.stdin.read()

    logger.debug(f"Reading input file: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def write_output(path, content):
    if not path:
        logger.debug("Writing output to stdout.")
        sys.stdout.write(content)
    else:
        logger.debug(f"Writing output file: {path}")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)


def validate_schema(data, schema_path):
    logger.debug(f"Validating against schema: {schema_path}")
    with open(schema_path, "r", encoding="utf-8") as f:
        schema = json.load(f)

    validate(instance=data, schema=schema)
    logger.debug("Schema validation successful.")


def convert(data, output_format, pretty):
    logger.debug(f"Converting to {output_format.upper()} format.")

    if output_format == "json":
        if pretty:
            return json.dumps(data, indent=4, ensure_ascii=False)
        return json.dumps(data, separators=(",", ":"), ensure_ascii=False)

    if output_format == "yaml":
        return yaml.safe_dump(
            data,
            sort_keys=False,
            allow_unicode=True,
            default_flow_style=not pretty
        )


def main():
    parser = argparse.ArgumentParser(description="Professional YAML ↔ JSON converter with schema validation")

    parser.add_argument(
        "-i", "--input",
        help="Input file path, if not specified stdin is used"
    )
    parser.add_argument(
        "-o", "--output",
        help="Output file path, if not specified stdout is used"
    )

    parser.add_argument(
        "--compact",
        action="store_true",
        help="Produce compact output (no pretty formatting)"
    )

    parser.add_argument(
        "--schema",
        help="Path to JSON Schema file for validation"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable debug logging"
    )


    args = parser.parse_args()

    # Configure logging
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s: %(message)s"
    )

    try:
        raw = read_input(args.input)
        input_format = detect_format(raw)

        output_format = "yaml" if input_format == "json" else "json"
        logger.debug(f"Output format: {output_format.upper()}")

        data = yaml.safe_load(raw)

        if args.schema:
            validate_schema(data, args.schema)

        result = convert(data, output_format, pretty=not args.compact)

        write_output(args.output, result)

        logger.debug("Conversion completed successfully.")

    except ValidationError as e:
        logger.error("Schema validation failed.")
        logger.debug(str(e))
        sys.exit(2)

    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
