from unittest.mock import patch

import pytest

from weather_scanner import InfoCuaca


@pytest.fixture
def app():
    return InfoCuaca()


@patch("requests.get")
def test_check_suhu_jkt(mock_get, app):
    mock_response = mock_get.return_value
    mock_response.status_code = 200

    mock_response.json.return_value = {"current_weather": {"temperature": 32.5}}
    result = app.checkweather("jakarta")

    assert "32.5" in result
    assert "Jakarta" in result


def test_city_not_found(app):
    result = app.checkweather("atlantis")
    assert result == "Sorry, city not register"
