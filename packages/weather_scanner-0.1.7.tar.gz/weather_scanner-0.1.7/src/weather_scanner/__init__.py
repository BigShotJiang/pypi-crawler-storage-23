from .weather import InfoCuaca as InfoCuaca
