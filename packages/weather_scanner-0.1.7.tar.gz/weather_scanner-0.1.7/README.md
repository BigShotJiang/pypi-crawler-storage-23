# Weather Scanner (Tester Package)

![PyPI - Version](https://img.shields.io)
![License](https://img.shields.io)

**DISCLAIMER: This is a tester package.**
This project is created for educational purposes to learn how to distribute Python libraries via PyPI. Features are limited and not intended for production use.

## Description
A simple Python library to check current temperatures for major cities in Indonesia using the Open-Meteo free API.


```py
from weather_scanner import InfoCuaca

app = InfoCuaca()
print(app.checkweather("jakarta"))
```