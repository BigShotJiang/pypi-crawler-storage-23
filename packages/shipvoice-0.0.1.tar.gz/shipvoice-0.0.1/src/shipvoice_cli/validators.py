from __future__ import annotations

import re
from pathlib import Path

NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _-]{2,49}$")


def validate_project_name(name: str) -> str:
    candidate = name.strip()
    if not NAME_PATTERN.match(candidate):
        raise ValueError(
            "Project name must be 3-50 chars and contain letters, numbers, spaces, '-' or '_'"
        )
    return candidate


def slugify(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "-", name.strip().lower()).strip("-")
    return re.sub(r"-{2,}", "-", s) or "shipvoice-app"


def package_prefix(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "_", name.strip().lower()).strip("_")
    return re.sub(r"_{2,}", "_", s) or "shipvoice_app"


def resolve_target_dir(target_dir: str | None, slug: str) -> Path:
    return Path(target_dir).expanduser().resolve() if target_dir else Path.cwd() / slug


def ensure_writable_destination(destination: Path, force: bool) -> None:
    if destination.exists():
        if destination.is_file():
            raise ValueError(f"Destination is a file: {destination}")
        has_contents = any(destination.iterdir())
        if has_contents and not force:
            raise ValueError(
                f"Destination '{destination}' is not empty. Use --force to overwrite."
            )
    else:
        destination.mkdir(parents=True, exist_ok=True)
