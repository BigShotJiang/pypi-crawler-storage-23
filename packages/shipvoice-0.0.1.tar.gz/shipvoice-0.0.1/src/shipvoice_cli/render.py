from __future__ import annotations

from pathlib import Path

TEXT_EXTENSIONS = {
    ".py",
    ".toml",
    ".md",
    ".yml",
    ".yaml",
    ".env",
    ".txt",
    ".json",
    ".gitignore",
}


def render_text(content: str, context: dict[str, str]) -> str:
    rendered = content
    for key, value in context.items():
        rendered = rendered.replace(f"{{{{{key}}}}}", value)
    return rendered


def is_text_file(path: Path) -> bool:
    return path.name in {".gitignore", ".env", ".env.example"} or path.suffix in TEXT_EXTENSIONS


def render_tree(
    template_root: Path,
    destination: Path,
    context: dict[str, str],
    *,
    force: bool = False,
) -> list[Path]:
    written: list[Path] = []

    for src in sorted(template_root.rglob("*")):
        rel = src.relative_to(template_root)
        dst = destination / rel

        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
            continue

        if dst.exists() and not force:
            raise ValueError(f"File already exists: {dst}")
        dst.parent.mkdir(parents=True, exist_ok=True)

        if is_text_file(src):
            text = src.read_text(encoding="utf-8")
            dst.write_text(render_text(text, context), encoding="utf-8")
        else:
            dst.write_bytes(src.read_bytes())

        written.append(dst)

    return written
