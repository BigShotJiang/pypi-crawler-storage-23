from __future__ import annotations

import typer

from .init_cmd import run_init

app = typer.Typer(help="ShipVoice project scaffolding CLI")


@app.command("init")
def init_command(
    target_dir: str | None = typer.Argument(None, help="Destination directory"),
    name: str | None = typer.Option(None, "--name", help="Human-friendly project name"),
    non_interactive: bool = typer.Option(
        False, "--non-interactive", help="Run without prompts"
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite existing files"),
    template: str = typer.Option("fullstack", "--template", help="Template name"),
    output: str = typer.Option("text", "--output", help="Output format: text|json"),
    no_git: bool = typer.Option(True, "--no-git", help="Reserved; git init disabled in v1"),
    with_docker: bool = typer.Option(True, "--with-docker", help="Reserved for future templates"),
    with_frontend: bool = typer.Option(True, "--with-frontend", help="Reserved for future templates"),
    with_backend: bool = typer.Option(True, "--with-backend", help="Reserved for future templates"),
    with_agent: bool = typer.Option(True, "--with-agent", help="Reserved for future templates"),
) -> None:
    _ = (no_git, with_docker, with_frontend, with_backend, with_agent, non_interactive)
    run_init(target_dir, name, non_interactive, force, template, output)


if __name__ == "__main__":
    app()
