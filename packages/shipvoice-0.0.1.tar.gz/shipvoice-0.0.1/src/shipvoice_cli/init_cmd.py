from __future__ import annotations

import json
from pathlib import Path

import typer
from .render import render_tree
from .validators import (
    ensure_writable_destination,
    package_prefix,
    resolve_target_dir,
    slugify,
    validate_project_name,
)


def _template_root() -> Path:
    return Path(__file__).resolve().parents[1] / "scaffold"


def _write_env(destination: Path, force: bool) -> None:
    env_example = destination / ".env.example"
    env_file = destination / ".env"

    if not env_example.exists():
        return
    if env_file.exists() and not force:
        return

    env_file.write_text(env_example.read_text(encoding="utf-8"), encoding="utf-8")


def run_init(
    target_dir: str | None,
    name: str | None,
    non_interactive: bool,
    force: bool,
    template: str,
    output: str,
) -> None:
    if template != "fullstack":
        raise typer.BadParameter("Only 'fullstack' template is supported in v1")

    project_name = validate_project_name(name or "ShipVoice App")
    project_slug = slugify(project_name)
    py_prefix = package_prefix(project_name)

    destination = resolve_target_dir(target_dir, project_slug)
    ensure_writable_destination(destination, force)

    context = {
        "PROJECT_NAME": project_name,
        "PROJECT_SLUG": project_slug,
        "PY_PACKAGE_PREFIX": py_prefix,
        "PYTHON_MIN_VERSION": "3.11",
    }

    written = render_tree(_template_root(), destination, context, force=force)
    _write_env(destination, force=force)

    summary = {
        "project_name": project_name,
        "destination": str(destination),
        "files_written": len(written),
        "next_steps": [
            f"cd {destination}",
            "uv sync --all-packages",
            "uv run --package backend python -m backend.main",
            "uv run --package frontend python -m frontend",
            "uv run --package agent python -m agent.main console",
        ],
    }

    if output == "json":
        typer.echo(json.dumps(summary, indent=2))
        return

    typer.echo(f"Initialized ShipVoice project at: {destination}")
    typer.echo("Next steps:")
    for step in summary["next_steps"]:
        typer.echo(f"  - {step}")
