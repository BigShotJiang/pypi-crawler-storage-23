# shipvoice

Bootstrap a ShipVoice full-stack project quickly.

```bash
uvx shipvoice init my-voice-app
```
