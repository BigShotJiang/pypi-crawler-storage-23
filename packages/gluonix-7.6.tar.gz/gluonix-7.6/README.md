# Gluonix V(7.6)
- Gluonix is a lightweight GUI library built on top of Tkinter for building desktop applications in Python. It provides reusable widgets and convenience utilities so you can build UIs faster with less boilerplate.

## Feedback
- If you have any thoughts or suggestions, we’d love to hear from you at [feedback@nucleonautomation.com](mailto:feedback@nucleonautomation.com). Your feedback is invaluable in helping us improve and enhance the library.

## Features
- Tkinter-based widgets: A set of ready-to-use UI components built on top of Tkinter.
- Higher-level utilities: Helper functions/classes to reduce repetitive Tkinter setup code.
- Layout helpers: Utilities and patterns to compose windows and dialogs more cleanly.
- Styling support: Common configuration helpers for fonts, colors, and consistent UI options.
- Image support: Works well with Pillow for loading and displaying images in UI components.

## Help
- See the [HELP](https://github.com/nucleonautomation/Gluonix-Designer/blob/main/Help.pdf) file for details.

## Installation Pypi
```
# Requires Python >=3.6
pip install Gluonix
```

## Requirements
```
pip install -r requirements.txt
```

## License
- This project is licensed under BSD 3-Clause License. See the [LICENSE](https://github.com/nucleonautomation/Gluonix-Designer/blob/main/LICENSE.md) file for details.

## Change Log
- See the [LOG](https://github.com/nucleonautomation/Gluonix-Designer/blob/main/LOG.md) file for details.
