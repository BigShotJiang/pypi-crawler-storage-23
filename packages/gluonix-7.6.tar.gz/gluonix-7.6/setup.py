from setuptools import setup, find_packages

setup(
    name="Gluonix",
    version="7.6",
    description="A GUI lib based on tkinter.",
    author="Nucleon Automation",
    author_email="jagroop@nucleonautomation.com",
    packages=find_packages(),
    python_requires=">=3.6",
    install_requires=[
        "pillow>=6.0.0"
    ],
)

'''
python -m build --sdist
twine upload dist/*
pip install dist/gluonix-7.6.tar.gz
'''