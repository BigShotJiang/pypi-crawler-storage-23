"""Plot widgets for data visualization."""
