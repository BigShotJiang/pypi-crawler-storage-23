"""Core modules for variable tracing and script execution."""
