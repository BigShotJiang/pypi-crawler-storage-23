#! /usr/bin/env python

import json
import os
import re
from tkinter import END, LEFT, filedialog

import ttkbootstrap as ttk
from qmenta.core import platform
from qmenta.core.auth import Needs2FAError
from qmenta.sdk.tool_maker.make_files import raise_if_false

# Import shared UI
from qmenta.sdk.tool_maker.base_ui import UnifiedToolWindow

MIN = 0
MAX_CORES = 10
MAX_RAM = 16
HELP_URL = (
    "https://docs.qmenta.com/sdk/guides_docs/tool_maker.html"
    "#publish-your-tool-in-the-qmenta-platform"
)

dir_name = None


def gui_tkinter():
    # Initialize the Shared Window
    gui = UnifiedToolWindow(
        title="Tool Publishing GUI",
        geometry="725x800",
        scrollable=True
    )

    # Logo, header and help button
    gui.add_logo()
    gui.add_header(
        "Publish your tool in the QMENTA Platform",
        help_url=HELP_URL,
        warning_text="(*) indicates mandatory field.",
    )

    # Credential Fields
    gui.add_section_label("QMENTA Platform Credentials")
    user_id_entry = gui.create_row("Username*")
    password_entry = gui.create_row("Password*", is_password=True)

    gui.add_separator()

    # Custom File Browse Row (Logic specific to this script)
    write_dir = ttk.StringVar()

    def browse_folder():
        global dir_name
        dir_name = filedialog.askdirectory()
        write_dir.set(dir_name)
        tool_id_entry.delete(0, END)
        tool_id_entry.insert(0, os.path.basename(dir_name))

        # checking version
        version_file = os.path.join(dir_name, "version")
        if os.path.exists(version_file):
            with open(version_file) as fv:
                version_ = fv.read().strip()
            tool_version_entry.delete(0, END)
            tool_version_entry.insert(0, version_)
            image_name_entry.delete(0, END)
            image_name_entry.insert(
                0, os.path.basename(dir_name) + f":{version_}"
            )

    folder_frame = ttk.Frame(master=gui.content_frame)
    folder_frame.pack(fill="x", pady=10)
    ttk.Label(folder_frame, text="Select tool folder*", width=30).pack(
        side=LEFT
    )
    ttk.Button(folder_frame, text="Browse Folder", command=browse_folder).pack(
        side=LEFT, padx=10
    )
    ttk.Label(folder_frame, textvariable=write_dir).pack(side=LEFT, padx=10)

    # Tool Info Fields
    tool_id_entry = gui.create_row("Specify the tool ID*")
    tool_version_entry = gui.create_row("Specify the tool version*")
    tool_name_entry = gui.create_row("Specify the tool name*")
    num_cores_entry = gui.create_row(
        f"Cores required (integer, max {MAX_CORES})", default="1"
    )
    memory_entry = gui.create_row(
        f"RAM required in GB (integer, max {MAX_RAM})", default="1"
    )
    image_name_entry = gui.create_row("Docker image name")

    gui.add_separator()

    # Docker Registry Fields
    gui.add_section_label("Docker Registry Credentials")
    docker_url_entry = gui.create_row(
        "Docker registry URL", default="hub.docker.com"
    )
    docker_user_entry = gui.create_row("Docker registry user")
    docker_password_entry = gui.create_row(
        "Docker registry password*", is_password=True
    )

    # --- Logic ---
    gui_content = {}

    def generate_output_object():
        return {
            "qmenta_user": user_id_entry.get(),
            "qmenta_password": password_entry.get(),
            "code": tool_id_entry.get(),
            "version": tool_version_entry.get(),
            "name": tool_name_entry.get(),
            "cores": num_cores_entry.get(),
            "memory": memory_entry.get(),
            "image_name": image_name_entry.get(),
            "docker_url": docker_url_entry.get(),
            "docker_user": docker_user_entry.get(),
            "docker_password": docker_password_entry.get(),
        }

    def perform_selection_check(values):
        try:
            raise_if_false(
                isinstance(values["code"], str), "Tool ID must be a string."
            )
            raise_if_false(values["code"] != "", "Tool ID must be defined.")
            raise_if_false(
                " " not in values["code"], "Tool ID can't have spaces."
            )
            values["code"] = values["code"].lower()
            values["short_name"] = values["code"].lower().replace(" ", "_")

            raise_if_false(
                isinstance(values["name"], str), "Tool name must be a string."
            )
            raise_if_false(values["name"] != "", "Tool name must be defined.")
            raise_if_false(
                values["version"] != "", "Tool version must be defined."
            )
            raise_if_false(
                re.search(r"^(\d+\.)?(\d+\.)?(\*|\d+)$", values["version"]),
                "Version format not valid.",
            )

            raise_if_false(values["cores"], "Number of cores must be defined.")
            raise_if_false(
                values["cores"].isnumeric(),
                "Number of cores must be an integer.",
            )
            raise_if_false(
                MAX_CORES >= int(values["cores"]) > MIN,
                f"Number of cores must be between {MIN} and {MAX_CORES}.",
            )

            raise_if_false(values["memory"], "RAM must be defined.")
            raise_if_false(
                values["memory"].isnumeric(), "RAM must be an integer."
            )
            raise_if_false(
                MAX_RAM >= int(values["memory"]) > MIN,
                f"RAM must be {MIN} and {MAX_RAM}.",
            )

            values["memory"] = int(values["memory"])
            values["image_name"] = (
                values["image_name"]
                or values["code"] + ":" + values["version"]
            )
            return values
        except AssertionError as e:
            gui.show_error("Error", f"AN EXCEPTION OCCURRED! {e}")
            return False

    def submit_form():
        gui_content.update(generate_output_object())
        res = perform_selection_check(gui_content)
        if res:
            gui_content.update(res)
            return True  # Signal to close window
        return False

    # Add Buttons & Run
    gui.add_action_buttons(
        submit_form, submit_text="Publish in QMENTA Platform"
    )
    gui.run()

    return gui_content


def main():
    content_build = gui_tkinter()
    if not content_build:
        exit()
    # Ensure dir_name was set by browse_folder
    if dir_name:
        os.chdir(dir_name)

    os.chdir(dir_name)

    user = content_build["qmenta_user"]
    password = content_build["qmenta_password"]
    try:
        auth = platform.Auth.login(
            username=user,
            password=password,
            base_url="https://platform.qmenta.com",
            ask_for_2fa_input=False,
        )
    except Needs2FAError as needs2faerror:
        gui_tkinter.show_info(
            "Message",
            str(needs2faerror)
            + " Please check the terminal to add the code sent to your phone.",
        )
        auth = platform.Auth.login(
            username=user,
            password=password,
            base_url="https://platform.qmenta.com",
            code_2fa=input("Input 2-FA code:"),
        )

    # Get information from the advanced options file.
    advanced_options = "settings.json"
    raise_if_false(
        os.path.exists(advanced_options),
        "Settings do not exist! Run the local test to create it.",
    )
    with open(advanced_options) as fr:
        content_build["advanced_options"] = fr.read()

    # Get information from the description file.
    with open("description.html") as fr:
        content_build["description"] = fr.read()

    with open("results_configuration.json", "r") as file:
        results_config = json.load(file)
    # The screen value is expected as a string with escaped chars (dict)
    results_config["screen"] = json.dumps(results_config["screen"])
    content_build["results_configuration"] = json.dumps(
        results_config
    ).replace("{}", "")

    content_build.update(
        {
            "start_condition_code": "output={'OK': True, 'code': 1}",
            "entry_point": "/root/entrypoint.sh",
            "tool_path": "tool:run",
        }
    )

    # After creating the workflow, the ID of the workflow must be requested
    # and added to the previous dictionary
    # otherwise it will keep creating new workflows on the platform
    # creating conflicts.
    res = platform.post(
        auth, "analysis_manager/upsert_user_tool", data=content_build
    )

    if res.json()["success"] == 1:
        print("Tool updated successfully!")
        print(
            "Tool name:",
            content_build["name"],
            "(",
            content_build["code"],
            ":",
            content_build["version"],
            ")",
        )
    else:
        print("ERROR setting the tool.")
        print(res.json())


if __name__ == "__main__":
    main()
