#! /usr/bin/env python

import os
import re
import sys

from qmenta.sdk.tool_maker.make_files import (
    build_description,
    build_local_dockerfile,
    build_local_requirements,
    build_script,
    build_test,
    raise_if_false,
)

# Import shared UI
from qmenta.sdk.tool_maker.base_ui import UnifiedToolWindow

HELP_URL = (
    "https://docs.qmenta.com/sdk/guides_docs/tool_maker.html"
    "#create-a-new-tool"
)
FOLDER = "local_tools"
sys.path.append(FOLDER)


def gui_tkinter():
    # Initialize Shared Window
    gui = UnifiedToolWindow(
        title="Tool Maker GUI", geometry="650x450", scrollable=False
    )

    # Logo, header and help button
    gui.add_logo()
    gui.add_header(
        "Tool Maker",
        help_url=HELP_URL,
        warning_text="(*) indicates mandatory field.",
    )

    # Inputs
    tool_id_entry = gui.create_row("Specify the tool ID*")
    tool_version_entry = gui.create_row(
        "Specify the tool version*", default="1.0"
    )

    # --- Logic ---
    gui_content = {}

    def generate_output_object():
        return {
            "tool_id": tool_id_entry.get(),
            "tool_version": tool_version_entry.get(),
        }

    def perform_selection_check(values):
        try:
            raise_if_false(
                isinstance(values["tool_id"], str), "Tool ID must be a string."
            )
            raise_if_false(values["tool_id"] != "", "Tool ID must be defined.")
            # Start with letter, contain at least 3 letters,
            # only a-z and _, cannot end with _
            values["tool_id"] = values["tool_id"].lower()

            # Regex validation
            raise_if_false(
                bool(
                    re.match(
                        r"^(?=(?:_*[a-z]){3})[a-z][a-z_]*[a-z]$",
                        values["tool_id"],
                    )
                ),
                "Tool ID can only contain letters and _",
            )

            values["folder"] = os.getcwd()
            if os.path.exists(
                os.path.join(values["folder"], values["tool_id"])
            ):
                gui.show_error(
                    "Python Error", "Error: Tool ID folder already exists!"
                )
                return False

            return values
        except AssertionError as e:
            gui.show_error("Error", f"AN EXCEPTION OCCURRED! {e}")
            return False

    def submit_form():
        gui_content.update(generate_output_object())
        res = perform_selection_check(gui_content)
        if res:
            gui_content.update(res)
            return True
        return False

    # Add Buttons & Run
    gui.add_action_buttons(submit_form, submit_text="Create")
    gui.run()

    return gui_content


def main():
    content_build = gui_tkinter()
    if not content_build:
        exit()

    os.makedirs(os.path.join(FOLDER, content_build["tool_id"]), exist_ok=True)
    os.chdir(os.path.join(FOLDER, content_build["tool_id"]))

    build_description()
    build_script(code=content_build["tool_id"])
    with open("version", "w") as f1:
        f1.write(content_build["tool_version"])

    os.makedirs("local", exist_ok=True)
    os.chdir("local")

    build_local_requirements()
    build_local_dockerfile()
    build_test(
        content_build["tool_id"],
        FOLDER,
        content_build["tool_version"],
    )


if __name__ == "__main__":
    main()
