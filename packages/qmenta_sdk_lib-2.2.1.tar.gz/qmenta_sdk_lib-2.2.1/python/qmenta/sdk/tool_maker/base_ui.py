import os
import webbrowser
from tkinter import BOTH, CENTER, LEFT, RIGHT, TOP, YES, X, Y, messagebox

import ttkbootstrap as ttk
from PIL import Image, ImageTk

# Constants for style
FONT_HEADER = "Helvetica 16 bold"
FONT_SUBHEADER = "Helvetica 12 bold"
PADDING_OUTER = 20
PADDING_ROW = 5


class UnifiedToolWindow:
    """
    A unified GUI window class that provides standardized styling
    and helper methods. Scrolling is optional.
    """

    def __init__(
        self,
        title="Tool GUI",
        geometry="725x800",
        theme="darkly",
        scrollable=True,
    ):
        self.window = ttk.Window(themename=theme)
        self.window.title(title)
        self.window.geometry(geometry)

        self.window.resizable(True, True)

        self.gui_content = {}
        self.scrollable = scrollable

        if self.scrollable:
            self._setup_scroll_area()
            self._setup_scroll_bindings()
        else:
            self._setup_static_area()

    def _setup_scroll_area(self):
        """Sets up the complex canvas and scrollbar structure."""
        self.main_container = ttk.Frame(self.window)
        self.main_container.pack(fill=BOTH, expand=YES)

        self.canvas = ttk.Canvas(self.main_container)
        self.vbar = ttk.Scrollbar(
            self.main_container, orient="vertical", command=self.canvas.yview
        )
        self.canvas.configure(yscrollcommand=self.vbar.set)

        self.vbar.pack(side=RIGHT, fill=Y)
        self.canvas.pack(side=LEFT, fill=BOTH, expand=YES)

        self.content_frame = ttk.Frame(self.canvas, padding=PADDING_OUTER)
        self.canvas_window_id = self.canvas.create_window(
            (0, 0), window=self.content_frame, anchor="nw", tags="inner_frame"
        )

    def _setup_static_area(self):
        """Sets up a simple frame without scrolling."""
        self.content_frame = ttk.Frame(self.window, padding=PADDING_OUTER)
        self.content_frame.pack(fill=BOTH, expand=YES)

    def _setup_scroll_bindings(self):
        """
        Sets up resize events and mousewheel scrolling
        Only for scrollable windows
        """
        self.content_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            ),
        )
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(
                self.canvas_window_id, width=e.width
            ),
        )

        def _on_mousewheel(event):
            if event.delta:  # Windows/macOS
                self.canvas.yview_scroll(
                    int(-1 * (event.delta / 120)), "units"
                )
            elif event.num == 4:  # Linux Up
                self.canvas.yview_scroll(-1, "units")
            elif event.num == 5:  # Linux Down
                self.canvas.yview_scroll(1, "units")

        self.window.bind_all("<MouseWheel>", _on_mousewheel)
        self.window.bind_all("<Button-4>", _on_mousewheel)
        self.window.bind_all("<Button-5>", _on_mousewheel)

    # --- Widget Helpers ---

    def add_logo(self, relative_path="templates_tool_maker/qmenta.png"):
        try:
            img_path = os.path.join(os.path.dirname(__file__), relative_path)
            if os.path.exists(img_path):
                logo = Image.open(img_path).resize((500, 110))
                img = ImageTk.PhotoImage(logo)
                lbl = ttk.Label(
                    master=self.content_frame, image=img, anchor=CENTER
                )
                lbl.image = img
                lbl.pack(side=TOP, pady=(0, 20))
        except Exception as e:
            print(f"Image load failed: {e}")

    def add_header(self, text, help_url=None, subtext=None, warning_text=None):
        """
        Places the header text in the absolute center and the help button
        floating in the top-right corner.
        """

        # Container frame for the top section
        header_container = ttk.Frame(self.content_frame)
        header_container.pack(fill="x", pady=5, padx=10, ipady=5)

        # Header Text
        ttk.Label(
            header_container,
            text=text,
            font=FONT_HEADER,
            anchor="center"
        ).pack(side="top")

        # Help Button
        if help_url:
            def open_help():
                webbrowser.open(help_url)

            help_btn = ttk.Button(
                header_container,
                text="Help",
                command=open_help,
                bootstyle="primary",
                width=4,
            )

            # relx=1.0: Position at 100% of the container's width (Far right)
            # rely=0.0: Position at the very top
            # anchor="ne": The "North East" (top-right) corner.
            help_btn.place(relx=1.0, rely=0, anchor="ne")

        # Subtitle text
        if subtext:
            ttk.Label(
                self.content_frame,
                text=subtext,
                bootstyle="info"
            ).pack(pady=(0, 5))

        # Warning Text
        if warning_text:
            ttk.Label(
                self.content_frame,
                text=warning_text,
                bootstyle="warning"
            ).pack(pady=(0, 20))

    def add_section_label(self, text):
        ttk.Label(self.content_frame, text=text, font=FONT_SUBHEADER).pack(
            pady=10
        )

    def create_row(self, label_text, is_password=False, default=None):
        frame = ttk.Frame(master=self.content_frame)
        frame.pack(fill=X, pady=PADDING_ROW)

        lbl = ttk.Label(master=frame, text=label_text, width=30)
        lbl.pack(side=LEFT)

        entry = ttk.Entry(master=frame, show="*" if is_password else None)
        if default:
            entry.insert(0, str(default))
        entry.pack(side=LEFT, fill=X, expand=YES, padx=10)
        return entry

    def add_separator(self):
        ttk.Separator(self.content_frame, orient="horizontal").pack(
            fill=X, pady=20
        )

    def add_action_buttons(
        self, submit_command, quit_command=None, submit_text="Publish"
    ):
        action_frame = ttk.Frame(master=self.content_frame)
        action_frame.pack(pady=20)

        def wrapped_submit():
            if submit_command():
                self.window.destroy()

        def wrapped_quit():
            if quit_command:
                quit_command()
            self.window.destroy()
            exit()

        ttk.Button(
            master=action_frame,
            text=submit_text,
            command=wrapped_submit,
            bootstyle="primary",
        ).pack(side=LEFT, padx=10)

        ttk.Button(
            master=action_frame,
            text="Quit",
            command=wrapped_quit,
            bootstyle="danger",
        ).pack(side=LEFT, padx=10)

    def run(self):
        self.window.mainloop()

    @staticmethod
    def show_error(title, message):
        messagebox.showerror(title, message)

    @staticmethod
    def show_info(title, message):
        messagebox.showinfo(title, message)
