
This is the core of datapizza-ai framework
