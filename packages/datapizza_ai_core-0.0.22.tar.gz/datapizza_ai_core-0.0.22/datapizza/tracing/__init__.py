from rich.console import Console

console = Console()

from datapizza.tracing.tracing import ContextTracing

__all__ = ["ContextTracing"]
