from .base import BaseEmbedder

__all__ = ["BaseEmbedder"]
