# Stark Core Python SDK

Welcome to the Stark Core Python SDK!
This tool offers the basic functionalities used by our starkbank and starkinfra Python SDKs to operate our APIs. 

# Help and Feedback

If you have any questions about our SDK, just send us an email.
We will respond you quickly, pinky promise. We are here to help you integrate with us ASAP.
We also love feedback, so don't be shy about sharing your thoughts with us.

Email: help@starkbank.com
