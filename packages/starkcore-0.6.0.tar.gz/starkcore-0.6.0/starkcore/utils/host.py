from .enum import Enum


class StarkHost(Enum):

    infra = "infra"
    bank = "bank"
    sign = "sign"
