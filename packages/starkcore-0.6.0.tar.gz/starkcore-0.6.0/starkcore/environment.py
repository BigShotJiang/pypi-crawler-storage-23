from starkcore.utils.enum import Enum


class Environment(Enum):

    sandbox = "sandbox"
    production = "production"
