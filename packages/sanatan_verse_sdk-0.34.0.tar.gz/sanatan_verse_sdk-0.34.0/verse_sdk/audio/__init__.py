"""Audio generation using ElevenLabs API."""

from .generate_audio import AudioGenerator

__all__ = ["AudioGenerator"]
