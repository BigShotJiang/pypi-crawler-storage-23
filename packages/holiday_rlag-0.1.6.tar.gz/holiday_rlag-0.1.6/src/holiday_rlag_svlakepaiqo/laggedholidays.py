import datetime
import holidays

def fetch_holidays(
    date_start: datetime.date, 
    date_end: datetime.date, 
    country_code = "DE", 
    reverse_lag = 7,
    col_is_easter = "is_easter",
    col_is_christmas = "is_christmas",
    col_is_bank_holiday = "is_bank_holiday",
    col_lag_prefix = "_in_next_",
    col_lag_suffix = "_days"
) -> list[dict]:
    """
    Fetches holidays for a given date range and country, with optional reverse lagging.

    Parameters:
    - date_start (datetime.date): The start date of the range.
    - date_end (datetime.date): The end date of the range.
    - country_code (str): The country code for which to fetch holidays. Default is "DE".
    - reverse_lag (int): The number of days to look back for reverse lagging. Default is 7.
    - col_is_easter (str): The column name for Easter flag. Default is "is_easter".
    - col_is_christmas (str): The column name for Christmas flag. Default is "is_christmas".
    - col_is_bank_holiday (str): The column name for bank holiday flag. Default is "is_bank_holiday".
    - col_lag_prefix (str): The prefix for lagged columns. Default is "_in_next_".
    - col_lag_suffix (str): The suffix for lagged columns. Default is "_days".

    Returns:
    - pd.DataFrame: A DataFrame containing holiday information with reverse lagging flags. This is not a complete date list, so make sure
    to fill all dates you need and apply `fillna(0)' to the resulting DataFrame.
    """
    at_holidays = holidays.country_holidays(
        country = country_code,
        years = range(date_start.year, date_end.year+1)
    )

    hd = {}
    for date, name in sorted(at_holidays.items()):
        print(type(date), type(name))
        is_easter = 1 if "Easter" in name else 0
        is_christmas = 1 if "Christmas" in name or "Saint Stephen" in name else 0
        is_bank_holiday = 1

        # initialize the date in the dictionary if it doesn't exist
        if not date in hd.keys():
            hd[date] = {
                "date": date,
            }

        # set the holiday flags for the current date
        hd[date][col_is_easter] = is_easter
        hd[date][col_is_christmas] = is_christmas
        hd[date][col_is_bank_holiday] = is_bank_holiday

        # set holiday reverse lagging flags for the current date
        for i in range(1, reverse_lag+1):
            col_extension = f"{col_lag_prefix}{i}{col_lag_suffix}"
            hd[date][f"{col_is_easter}{col_extension}"] = is_easter
            hd[date][f"{col_is_christmas}{col_extension}"] = is_christmas
            hd[date][f"{col_is_bank_holiday}{col_extension}"] = is_bank_holiday
                

        # set holiday reverse lagging flags for the previous dates within the lagging window
        for i in range(1, reverse_lag+1):    
            earlier_date = date - datetime.timedelta(days=i)

            # set earlier date if not yet present
            if not earlier_date in hd.keys():
                hd[earlier_date] = {
                    "date": earlier_date,
                }

            # iterate through the "visible" time window and set the flag
            for k in range(i, reverse_lag+1):
                col_extension = f"{col_lag_prefix}{k}{col_lag_suffix}"

                hd[earlier_date][f"{col_is_easter}{col_extension}"] = is_easter
                hd[earlier_date][f"{col_is_christmas}{col_extension}"] = is_christmas
                hd[earlier_date][f"{col_is_bank_holiday}{col_extension}"] = is_bank_holiday
            
    # everything else will be filled with zeros by default when converting to a DataFrame
    return [entry for entry in hd.values()]

if __name__ == "__main__":

    hd = fetch_holidays(date_start = datetime.date(2023, 1, 1), date_end = datetime.date(2023, 12, 31), reverse_lag=3)
    import json
    print(json.dumps(hd, indent=4, default=str))
