"""Protocols for communicating with Roborock devices."""

__all__: list[str] = []
