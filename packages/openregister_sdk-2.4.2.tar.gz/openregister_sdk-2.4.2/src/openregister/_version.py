# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "openregister"
__version__ = "2.4.2"  # x-release-please-version
