Add auto package creator in weighing operations
