# ai4scholar_mcp/academic_platforms/pubmed.py
from typing import List, Optional
from datetime import datetime
from ..paper import Paper
from ..context import current_api_key
import requests
import logging
import os

logger = logging.getLogger(__name__)


class PaperSource:
    """Abstract base class for paper sources"""

    def search(self, query: str, **kwargs) -> List[Paper]:
        raise NotImplementedError

    def download_pdf(self, paper_id: str, save_path: str) -> str:
        raise NotImplementedError

    def read_paper(self, paper_id: str, save_path: str) -> str:
        raise NotImplementedError


class PubMedSearcher(PaperSource):
    """PubMed paper search via ai4scholar.net proxy"""

    BASE_URL = "https://ai4scholar.net/pubmed/v1"

    def __init__(self):
        self.session = requests.Session()

    @staticmethod
    def get_api_key() -> Optional[str]:
        """Get API key from the per-request context (SSE mode) or the
        AI4SCHOLAR_API_KEY environment variable (stdio / local mode)."""
        # 1. SSE mode: use the token that the user sent in their Bearer header
        api_key = current_api_key.get()
        if api_key:
            return api_key

        # 2. stdio / local mode: fall back to environment variable
        api_key = os.getenv("AI4SCHOLAR_API_KEY")
        if not api_key or api_key.strip() == "":
            logger.warning(
                "No AI4SCHOLAR_API_KEY set. PubMed proxy requests may fail."
            )
            return None
        return api_key.strip()

    def _get_headers(self) -> dict:
        """Build request headers with API key."""
        headers = {"Content-Type": "application/json"}
        api_key = self.get_api_key()
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        return headers

    def _parse_date(self, date_str) -> Optional[datetime]:
        """Parse PubMed date strings in various formats."""
        if not date_str:
            return None
        date_str = str(date_str).strip()
        for fmt in ("%Y-%m-%d", "%Y-%b", "%Y-%b-%d", "%Y"):
            try:
                return datetime.strptime(date_str, fmt)
            except ValueError:
                continue
        logger.warning(f"Could not parse date: {date_str}")
        return None

    def _parse_paper(self, item: dict) -> Optional[Paper]:
        """Parse a single paper item from the ai4scholar PubMed API response."""
        try:
            authors = []
            for a in item.get("authors", []):
                fore = a.get("foreName", "")
                last = a.get("lastName", "")
                name = a.get("name", "") or f"{fore} {last}".strip()
                if name:
                    authors.append(name)

            journal = item.get("journal", {})
            journal_name = journal.get("title", "") if isinstance(journal, dict) else str(journal)

            pub_date = item.get("pubDate", "")
            if not pub_date and isinstance(journal, dict):
                pub_date = journal.get("pubDate", "")

            return Paper(
                paper_id=str(item.get("pmid", "")),
                title=item.get("title", ""),
                authors=authors,
                abstract=item.get("abstract", ""),
                doi=item.get("doi", ""),
                published_date=self._parse_date(pub_date),
                pdf_url="",
                url=f"https://pubmed.ncbi.nlm.nih.gov/{item.get('pmid', '')}/",
                source="pubmed",
                categories=item.get("meshTerms", []),
                keywords=item.get("keywords", []),
                extra={"journal": journal_name},
            )
        except Exception as e:
            logger.warning(f"Failed to parse PubMed paper: {e}")
            return None

    def search(self, query: str, max_results: int = 10) -> List[Paper]:
        """Search PubMed papers via ai4scholar.net proxy.

        Args:
            query: Search query string.
            max_results: Maximum number of results to return.

        Returns:
            List of Paper objects.
        """
        papers = []
        try:
            url = f"{self.BASE_URL}/paper/search"
            payload = {
                "query": query,
                "limit": max_results,
                "offset": 0,
                "sort": "relevance",
            }
            response = self.session.post(
                url, json=payload, headers=self._get_headers(), timeout=30
            )
            response.raise_for_status()
            data = response.json()

            for item in data.get("papers", []):
                paper = self._parse_paper(item)
                if paper:
                    papers.append(paper)
        except Exception as e:
            logger.error(f"PubMed search error: {e}")

        return papers[:max_results]

    def get_paper_detail(self, pmid: str) -> Optional[Paper]:
        """Get a single paper's detail by PMID.

        Args:
            pmid: PubMed ID.

        Returns:
            Paper object or None.
        """
        try:
            url = f"{self.BASE_URL}/paper/{pmid}"
            response = self.session.get(
                url, headers=self._get_headers(), timeout=30
            )
            response.raise_for_status()
            item = response.json()
            return self._parse_paper(item)
        except Exception as e:
            logger.error(f"PubMed paper detail error for {pmid}: {e}")
            return None

    def get_paper_citations(self, pmid: str, limit: int = 20) -> List[Paper]:
        """Get papers that cite the given PubMed paper.

        Args:
            pmid: PubMed ID.
            limit: Max results (default 20).

        Returns:
            List of Paper objects.
        """
        try:
            url = f"{self.BASE_URL}/paper/{pmid}/citations"
            response = self.session.get(
                url, params={"limit": limit}, headers=self._get_headers(), timeout=30
            )
            response.raise_for_status()
            items = response.json()
            if isinstance(items, dict):
                items = items.get("papers", items.get("data", []))
            papers = []
            for item in items:
                paper = self._parse_paper(item)
                if paper:
                    papers.append(paper)
            return papers
        except Exception as e:
            logger.error(f"PubMed citations error for {pmid}: {e}")
            return []

    def get_related_papers(self, pmid: str, limit: int = 20) -> List[Paper]:
        """Get papers related to the given PubMed paper.

        Args:
            pmid: PubMed ID.
            limit: Max results (default 20).

        Returns:
            List of Paper objects.
        """
        try:
            url = f"{self.BASE_URL}/paper/{pmid}/related"
            response = self.session.get(
                url, params={"limit": limit}, headers=self._get_headers(), timeout=30
            )
            response.raise_for_status()
            items = response.json()
            if isinstance(items, dict):
                items = items.get("papers", items.get("data", []))
            papers = []
            for item in items:
                paper = self._parse_paper(item)
                if paper:
                    papers.append(paper)
            return papers
        except Exception as e:
            logger.error(f"PubMed related papers error for {pmid}: {e}")
            return []

    def download_pdf(self, paper_id: str, save_path: str) -> str:
        """PubMed does not provide direct PDF downloads.

        Raises:
            NotImplementedError: Always.
        """
        raise NotImplementedError(
            "PubMed does not provide direct PDF downloads. "
            "Please use the paper's DOI or URL to access the publisher's website."
        )

    def read_paper(self, paper_id: str, save_path: str = "./downloads") -> str:
        """PubMed papers cannot be read directly.

        Returns:
            str: Message indicating reading is not supported.
        """
        return (
            "PubMed papers cannot be read directly through this tool. "
            "Only metadata and abstracts are available. "
            "Please use the paper's DOI or URL to access the full text."
        )
