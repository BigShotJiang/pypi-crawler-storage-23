from typing import List, Optional
from datetime import datetime
import os
import requests
import logging

from ..paper import Paper
from ..context import current_api_key

logger = logging.getLogger(__name__)

BASE_URL = "https://ai4scholar.net"


class GoogleScholarSearcher:
    """Google Scholar search via ai4scholar.net proxy API."""

    def __init__(self):
        self.session = requests.Session()

    @staticmethod
    def get_api_key() -> Optional[str]:
        api_key = current_api_key.get()
        if api_key:
            return api_key
        api_key = os.getenv("AI4SCHOLAR_API_KEY")
        if not api_key or api_key.strip() == "":
            logger.warning("No AI4SCHOLAR_API_KEY set; Google Scholar search will fail.")
            return None
        return api_key.strip()

    def _get_headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        api_key = self.get_api_key()
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        return headers

    def search(self, query: str, max_results: int = 10,
               year_from: Optional[int] = None,
               year_to: Optional[int] = None) -> List[Paper]:
        """Search Google Scholar via ai4scholar.net proxy.

        The API returns 10 results per page (Google Scholar limitation).
        We paginate automatically to collect up to max_results papers.
        """
        papers: List[Paper] = []
        page = 1
        per_page = 10

        while len(papers) < max_results:
            payload: dict = {"query": query, "page": page}
            if year_from is not None:
                payload["yearFrom"] = year_from
            if year_to is not None:
                payload["yearTo"] = year_to

            try:
                resp = self.session.post(
                    f"{BASE_URL}/google-scholar/v1/search",
                    headers=self._get_headers(),
                    json=payload,
                    timeout=30,
                )
                resp.raise_for_status()
                data = resp.json()
            except requests.RequestException as e:
                logger.error(f"Google Scholar API request failed: {e}")
                break

            results = data.get("results", [])
            if not results:
                break

            for item in results:
                if len(papers) >= max_results:
                    break

                year = item.get("year")
                pub_date = datetime(year, 1, 1) if year else None
                pub_info = item.get("publicationInfo", "")
                authors = [a.strip() for a in pub_info.split("-")[0].split(",")] if pub_info else []

                papers.append(Paper(
                    paper_id=f"gs_{hash(item.get('link', ''))}",
                    title=item.get("title", ""),
                    authors=authors,
                    abstract=item.get("snippet", ""),
                    url=item.get("link", ""),
                    pdf_url=item.get("pdfUrl") or "",
                    published_date=pub_date,
                    updated_date=None,
                    source="google_scholar",
                    categories=[],
                    keywords=[],
                    doi="",
                    citations=item.get("citedBy") or 0,
                ))

            if data.get("resultsCount", 0) < per_page:
                break
            page += 1

        return papers[:max_results]

    def download_pdf(self, paper_id: str, save_path: str) -> str:
        raise NotImplementedError(
            "Google Scholar doesn't provide direct PDF downloads. "
            "Please use the paper URL to access the publisher's website."
        )

    def read_paper(self, paper_id: str, save_path: str = "./downloads") -> str:
        return (
            "Google Scholar doesn't support direct paper reading. "
            "Please use the paper URL to access the full text on the publisher's website."
        )
