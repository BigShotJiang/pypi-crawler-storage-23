# ai4scholar_mcp/server.py
import argparse
import os
from typing import List, Dict, Optional

import httpx
import uvicorn
from mcp.server.fastmcp import FastMCP
from mcp.server.sse import SseServerTransport
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
from .academic_platforms.arxiv import ArxivSearcher
from .academic_platforms.pubmed import PubMedSearcher
from .academic_platforms.biorxiv import BioRxivSearcher
from .academic_platforms.medrxiv import MedRxivSearcher
from .academic_platforms.google_scholar import GoogleScholarSearcher
# TODO: IACR 暂时注释，后续按需启用
# from .academic_platforms.iacr import IACRSearcher
from .academic_platforms.semantic import SemanticSearcher
# TODO: CrossRef 暂时注释，后续按需启用
# from .academic_platforms.crossref import CrossRefSearcher

# from .academic_platforms.hub import SciHubSearcher
from .paper import Paper
from .context import current_api_key

# Initialize MCP server
mcp = FastMCP("ai4scholar_server")

# Instances of searchers
arxiv_searcher = ArxivSearcher()
pubmed_searcher = PubMedSearcher()
biorxiv_searcher = BioRxivSearcher()
medrxiv_searcher = MedRxivSearcher()
google_scholar_searcher = GoogleScholarSearcher()
# TODO: IACR 暂时注释，后续按需启用
# iacr_searcher = IACRSearcher()
semantic_searcher = SemanticSearcher()
# TODO: CrossRef 暂时注释，后续按需启用
# crossref_searcher = CrossRefSearcher()
# scihub_searcher = SciHubSearcher()


# Asynchronous helper to adapt synchronous searchers
async def async_search(searcher, query: str, max_results: int, **kwargs) -> List[Dict]:
    async with httpx.AsyncClient() as client:
        # Assuming searchers use requests internally; we'll call synchronously for now
        if 'year' in kwargs:
            papers = searcher.search(query, year=kwargs['year'], max_results=max_results)
        else:
            papers = searcher.search(query, max_results=max_results)
        return [paper.to_dict() for paper in papers]


# Tool definitions
@mcp.tool()
async def search_arxiv(query: str, max_results: int = 10) -> List[Dict]:
    """在 arXiv 上搜索学术论文。

    Args:
        query: 搜索关键词（如 'machine learning'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = await async_search(arxiv_searcher, query, max_results)
    return papers if papers else []


@mcp.tool()
async def search_pubmed(query: str, max_results: int = 10) -> List[Dict]:
    """在 PubMed 上搜索生物医学论文。

    Args:
        query: 搜索关键词（如 'cancer treatment'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = await async_search(pubmed_searcher, query, max_results)
    return papers if papers else []


@mcp.tool()
async def get_pubmed_paper_detail(pmid: str) -> Dict:
    """通过 PMID 获取 PubMed 论文的详细信息。

    Args:
        pmid: PubMed ID（如 '39575807'）。
    Returns:
        论文元数据（字典格式），未找到则返回空字典。
    """
    async with httpx.AsyncClient() as client:
        paper = pubmed_searcher.get_paper_detail(pmid)
        return paper.to_dict() if paper else {}


@mcp.tool()
async def search_biorxiv(query: str, max_results: int = 10) -> List[Dict]:
    """在 bioRxiv 上搜索生物学预印本论文。

    Args:
        query: 搜索关键词（如 'gene editing'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = await async_search(biorxiv_searcher, query, max_results)
    return papers if papers else []


@mcp.tool()
async def search_medrxiv(query: str, max_results: int = 10) -> List[Dict]:
    """在 medRxiv 上搜索医学与健康预印本论文。

    Args:
        query: 搜索关键词（如 'COVID-19 vaccine'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = await async_search(medrxiv_searcher, query, max_results)
    return papers if papers else []


@mcp.tool()
async def search_google_scholar(query: str, max_results: int = 10,
                                year_from: Optional[int] = None,
                                year_to: Optional[int] = None) -> List[Dict]:
    """通过 AI4Scholar 代理在 Google Scholar 上搜索学术论文，支持年份过滤。

    Args:
        query: 搜索关键词（如 'deep learning'）。
        max_results: 最大返回论文数量（默认 10）。
        year_from: 起始年份过滤（如 2020），不填则不限。
        year_to: 结束年份过滤（如 2025），不填则不限。
    Returns:
        论文元数据列表（字典格式），包含标题、作者、摘要、引用数、PDF 链接等。
    """
    papers = google_scholar_searcher.search(
        query, max_results=max_results, year_from=year_from, year_to=year_to
    )
    return [p.to_dict() for p in papers] if papers else []


# TODO: IACR 暂时注释，后续按需启用
# @mcp.tool()
# async def search_iacr(
#     query: str, max_results: int = 10, fetch_details: bool = True
# ) -> List[Dict]:
#     """Search academic papers from IACR ePrint Archive.
#
#     Args:
#         query: Search query string (e.g., 'cryptography', 'secret sharing').
#         max_results: Maximum number of papers to return (default: 10).
#         fetch_details: Whether to fetch detailed information for each paper (default: True).
#     Returns:
#         List of paper metadata in dictionary format.
#     """
#     async with httpx.AsyncClient() as client:
#         papers = iacr_searcher.search(query, max_results, fetch_details)
#         return [paper.to_dict() for paper in papers] if papers else []


@mcp.tool()
async def download_arxiv(paper_id: str, save_path: str = "./downloads") -> str:
    """下载 arXiv 论文的 PDF 文件。

    Args:
        paper_id: arXiv 论文 ID（如 '2106.12345'）。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载的 PDF 文件路径。
    """
    async with httpx.AsyncClient() as client:
        return arxiv_searcher.download_pdf(paper_id, save_path)


# PubMed 不支持 PDF 下载，注释掉
# @mcp.tool()
# async def download_pubmed(paper_id: str, save_path: str = "./downloads") -> str:
#     """Attempt to download PDF of a PubMed paper."""
#     try:
#         return pubmed_searcher.download_pdf(paper_id, save_path)
#     except NotImplementedError as e:
#         return str(e)


@mcp.tool()
async def download_biorxiv(paper_id: str, save_path: str = "./downloads") -> str:
    """下载 bioRxiv 论文的 PDF 文件。

    Args:
        paper_id: bioRxiv DOI。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载的 PDF 文件路径。
    """
    return biorxiv_searcher.download_pdf(paper_id, save_path)


@mcp.tool()
async def download_medrxiv(paper_id: str, save_path: str = "./downloads") -> str:
    """下载 medRxiv 论文的 PDF 文件。

    Args:
        paper_id: medRxiv DOI。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载的 PDF 文件路径。
    """
    return medrxiv_searcher.download_pdf(paper_id, save_path)


# TODO: IACR 暂时注释，后续按需启用
# @mcp.tool()
# async def download_iacr(paper_id: str, save_path: str = "./downloads") -> str:
#     """Download PDF of an IACR ePrint paper."""
#     return iacr_searcher.download_pdf(paper_id, save_path)


@mcp.tool()
async def read_arxiv_paper(paper_id: str, save_path: str = "./downloads") -> str:
    """下载并提取 arXiv 论文 PDF 的全文文本内容。

    Args:
        paper_id: arXiv 论文 ID（如 '2106.12345'）。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        提取的论文全文文本。
    """
    try:
        return arxiv_searcher.read_paper(paper_id, save_path)
    except Exception as e:
        print(f"Error reading paper {paper_id}: {e}")
        return ""


# PubMed 不支持直接阅读全文，注释掉
# @mcp.tool()
# async def read_pubmed_paper(paper_id: str, save_path: str = "./downloads") -> str:
#     """Read and extract text content from a PubMed paper."""
#     return pubmed_searcher.read_paper(paper_id, save_path)


@mcp.tool()
async def read_biorxiv_paper(paper_id: str, save_path: str = "./downloads") -> str:
    """下载并提取 bioRxiv 论文 PDF 的全文文本内容。

    Args:
        paper_id: bioRxiv DOI。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        提取的论文全文文本。
    """
    try:
        return biorxiv_searcher.read_paper(paper_id, save_path)
    except Exception as e:
        print(f"Error reading paper {paper_id}: {e}")
        return ""


@mcp.tool()
async def read_medrxiv_paper(paper_id: str, save_path: str = "./downloads") -> str:
    """下载并提取 medRxiv 论文 PDF 的全文文本内容。

    Args:
        paper_id: medRxiv DOI。
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        提取的论文全文文本。
    """
    try:
        return medrxiv_searcher.read_paper(paper_id, save_path)
    except Exception as e:
        print(f"Error reading paper {paper_id}: {e}")
        return ""


# TODO: IACR 暂时注释，后续按需启用
# @mcp.tool()
# async def read_iacr_paper(paper_id: str, save_path: str = "./downloads") -> str:
#     """Read and extract text content from an IACR ePrint paper PDF."""
#     try:
#         return iacr_searcher.read_paper(paper_id, save_path)
#     except Exception as e:
#         print(f"Error reading paper {paper_id}: {e}")
#         return ""


@mcp.tool()
async def search_semantic(query: str, year: Optional[str] = None, max_results: int = 10) -> List[Dict]:
    """在 Semantic Scholar 上搜索学术论文，支持年份过滤。

    Args:
        query: 搜索关键词（如 'machine learning'）。
        year: 可选年份过滤（如 '2019'、'2016-2020'、'2010-'、'-2015'）。
        max_results: 最大返回论文数量（默认 10）。
    Returns:
        论文元数据列表（字典格式）。
    """
    kwargs = {}
    if year is not None:
        kwargs['year'] = year
    papers = await async_search(semantic_searcher, query, max_results, **kwargs)
    return papers if papers else []


@mcp.tool()
async def download_semantic(paper_id: str, save_path: str = "./downloads") -> str:
    """下载 Semantic Scholar 论文的 PDF 文件。

    Args:
        paper_id: 论文标识符，支持以下格式：
            - Semantic Scholar ID（如 "649def34f8be52c8b66281af98ae884c09aef38b"）
            - DOI:<doi>（如 "DOI:10.18653/v1/N18-3011"）
            - ARXIV:<id>（如 "ARXIV:2106.15928"）
            - MAG:<id>（如 "MAG:112218234"）
            - ACL:<id>（如 "ACL:W12-3903"）
            - PMID:<id>（如 "PMID:19872477"）
            - PMCID:<id>（如 "PMCID:2323736"）
            - URL:<url>（如 "URL:https://arxiv.org/abs/2106.15928v1"）
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        下载的 PDF 文件路径。
    """ 
    return semantic_searcher.download_pdf(paper_id, save_path)


@mcp.tool()
async def read_semantic_paper(paper_id: str, save_path: str = "./downloads") -> str:
    """下载并提取 Semantic Scholar 论文 PDF 的全文文本内容。

    Args:
        paper_id: 论文标识符，支持以下格式：
            - Semantic Scholar ID（如 "649def34f8be52c8b66281af98ae884c09aef38b"）
            - DOI:<doi>（如 "DOI:10.18653/v1/N18-3011"）
            - ARXIV:<id>（如 "ARXIV:2106.15928"）
            - MAG:<id>（如 "MAG:112218234"）
            - ACL:<id>（如 "ACL:W12-3903"）
            - PMID:<id>（如 "PMID:19872477"）
            - PMCID:<id>（如 "PMCID:2323736"）
            - URL:<url>（如 "URL:https://arxiv.org/abs/2106.15928v1"）
        save_path: PDF 保存目录（默认 './downloads'）。
    Returns:
        提取的论文全文文本。
    """
    try:
        return semantic_searcher.read_paper(paper_id, save_path)
    except Exception as e:
        print(f"Error reading paper {paper_id}: {e}")
        return ""


@mcp.tool()
async def get_semantic_citations(paper_id: str, limit: int = 100, offset: int = 0) -> List[Dict]:
    """获取引用了指定论文的所有论文（Semantic Scholar 引用图谱）。

    Args:
        paper_id: 论文标识符（SHA、DOI:<doi>、ARXIV:<id>、PMID:<id> 等）。
        limit: 最大返回引用数量（默认 100，最大 1000）。
        offset: 分页偏移量（默认 0）。
    Returns:
        引用列表，每条包含引用上下文、意图、是否有影响力及引用论文信息。
    """
    return semantic_searcher.get_paper_citations(paper_id, limit=limit, offset=offset)


@mcp.tool()
async def get_semantic_references(paper_id: str, limit: int = 100, offset: int = 0) -> List[Dict]:
    """获取指定论文引用的所有参考文献（Semantic Scholar）。

    Args:
        paper_id: 论文标识符（SHA、DOI:<doi>、ARXIV:<id>、PMID:<id> 等）。
        limit: 最大返回参考文献数量（默认 100，最大 1000）。
        offset: 分页偏移量（默认 0）。
    Returns:
        参考文献列表，每条包含引用上下文、意图、是否有影响力及被引论文信息。
    """
    return semantic_searcher.get_paper_references(paper_id, limit=limit, offset=offset)


@mcp.tool()
async def search_semantic_authors(query: str, limit: int = 10) -> List[Dict]:
    """按姓名搜索学者（Semantic Scholar）。

    Args:
        query: 学者姓名（如 'Yann LeCun'）。
        limit: 最大返回学者数量（默认 10）。
    Returns:
        学者列表，包含作者 ID、姓名、机构、论文数、引用数、h-index。
    """
    return semantic_searcher.search_authors(query, limit=limit)


@mcp.tool()
async def get_semantic_author_papers(author_id: str, limit: int = 100, offset: int = 0) -> List[Dict]:
    """获取指定学者的所有论文列表（Semantic Scholar）。

    Args:
        author_id: Semantic Scholar 作者 ID（如 '1741101'）。
        limit: 最大返回论文数量（默认 100，最大 1000）。
        offset: 分页偏移量（默认 0）。
    Returns:
        论文列表（字典格式）。
    """
    return semantic_searcher.get_author_papers(author_id, limit=limit, offset=offset)


@mcp.tool()
async def get_semantic_recommendations(positive_paper_ids: List[str],
                                       negative_paper_ids: List[str] = None,
                                       limit: int = 100) -> List[Dict]:
    """基于正面/负面论文示例获取论文推荐（Semantic Scholar）。

    Args:
        positive_paper_ids: 作为正面示例的论文 ID 列表。
        negative_paper_ids: 可选，作为负面示例的论文 ID 列表。
        limit: 最大推荐数量（默认 100，最大 500）。
    Returns:
        推荐论文列表（字典格式）。
    """
    return semantic_searcher.get_recommendations(
        positive_paper_ids, negative_paper_ids=negative_paper_ids, limit=limit
    )


@mcp.tool()
async def get_semantic_recommendations_for_paper(paper_id: str, limit: int = 100,
                                                  pool: str = "recent") -> List[Dict]:
    """基于单篇论文获取相似论文推荐（Semantic Scholar）。

    Args:
        paper_id: 论文标识符（SHA、DOI:<doi>、ARXIV:<id> 等）。
        limit: 最大推荐数量（默认 100，最大 500）。
        pool: 推荐池 - 'recent'（最近论文）或 'all-cs'（全部计算机科学论文），默认 'recent'。
    Returns:
        推荐论文列表（字典格式）。
    """
    return semantic_searcher.get_recommendations_for_paper(paper_id, limit=limit, pool=pool)


@mcp.tool()
async def search_semantic_snippets(query: str, limit: int = 10) -> List[Dict]:
    """在论文全文中搜索文本片段（Semantic Scholar）。

    片段为约 500 词的摘录，来源于论文标题、摘要和正文。

    Args:
        query: 搜索关键词。
        limit: 最大返回片段数量（默认 10）。
    Returns:
        片段匹配列表，每条包含片段文本、匹配分数及论文信息。
    """
    return semantic_searcher.search_snippets(query, limit=limit)


@mcp.tool()
async def get_pubmed_citations(pmid: str, limit: int = 20) -> List[Dict]:
    """获取引用了指定 PubMed 论文的所有论文。

    Args:
        pmid: PubMed ID（如 '30102808'）。
        limit: 最大返回引用论文数量（默认 20）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = pubmed_searcher.get_paper_citations(pmid, limit=limit)
    return [p.to_dict() for p in papers]


@mcp.tool()
async def get_pubmed_related(pmid: str, limit: int = 20) -> List[Dict]:
    """获取与指定 PubMed 论文相关的论文。

    Args:
        pmid: PubMed ID（如 '30102808'）。
        limit: 最大返回相关论文数量（默认 20）。
    Returns:
        论文元数据列表（字典格式）。
    """
    papers = pubmed_searcher.get_related_papers(pmid, limit=limit)
    return [p.to_dict() for p in papers]


# TODO: CrossRef 暂时注释，后续按需启用
# @mcp.tool()
# async def search_crossref(query: str, max_results: int = 10, **kwargs) -> List[Dict]:
#     """Search academic papers from CrossRef database."""
#     papers = await async_search(crossref_searcher, query, max_results, **kwargs)
#     return papers if papers else []
#
#
# @mcp.tool()
# async def get_crossref_paper_by_doi(doi: str) -> Dict:
#     """Get a specific paper from CrossRef by its DOI."""
#     async with httpx.AsyncClient() as client:
#         paper = crossref_searcher.get_paper_by_doi(doi)
#         return paper.to_dict() if paper else {}
#
#
# @mcp.tool()
# async def download_crossref(paper_id: str, save_path: str = "./downloads") -> str:
#     """Attempt to download PDF of a CrossRef paper."""
#     try:
#         return crossref_searcher.download_pdf(paper_id, save_path)
#     except NotImplementedError as e:
#         return str(e)
#
#
# @mcp.tool()
# async def read_crossref_paper(paper_id: str, save_path: str = "./downloads") -> str:
#     """Attempt to read and extract text content from a CrossRef paper."""
#     return crossref_searcher.read_paper(paper_id, save_path)


# ---------------------------------------------------------------------------
# SSE transport: Auth middleware + Starlette app factory
# ---------------------------------------------------------------------------

class AuthMiddleware(BaseHTTPMiddleware):
    """Bearer token authentication middleware.

    Extracts the Bearer token from the Authorization header and stores it
    in the per-request ContextVar so that downstream searchers can forward
    it to ai4scholar.net on behalf of each individual user.

    The /health endpoint is exempt from authentication.
    Requests without a Bearer token are rejected with 401.
    """

    async def dispatch(self, request: Request, call_next):
        if request.url.path == "/health":
            return await call_next(request)

        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return JSONResponse(
                {"error": "Missing or invalid Authorization header"},
                status_code=401,
            )

        token = auth_header[len("Bearer "):]
        if not token:
            return JSONResponse(
                {"error": "Empty API key"},
                status_code=401,
            )

        # Store the user's token in the request context so that
        # handle_sse can pick it up and set the ContextVar.
        request.state.api_key = token

        return await call_next(request)


def create_starlette_app(mcp_server) -> Starlette:
    """Create a Starlette application that serves the MCP server over SSE."""
    sse = SseServerTransport("/messages/")

    async def handle_sse(request: Request):
        # Store the user's API key (set by AuthMiddleware) in the
        # ContextVar so all tool calls within this SSE session use it.
        api_key = getattr(request.state, "api_key", None)
        if api_key:
            current_api_key.set(api_key)

        async with sse.connect_sse(
            request.scope, request.receive, request._send
        ) as streams:
            await mcp_server.run(
                streams[0], streams[1], mcp_server.create_initialization_options()
            )

    async def handle_messages(request: Request):
        await sse.handle_post_message(request.scope, request.receive, request._send)

    async def handle_health(request: Request):
        return JSONResponse({"status": "ok"})

    app = Starlette(
        routes=[
            Route("/sse", endpoint=handle_sse),
            Route("/messages/", endpoint=handle_messages, methods=["POST"]),
            Route("/health", endpoint=handle_health),
        ],
        middleware=[Middleware(AuthMiddleware)],
    )
    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AI4Scholar MCP Server")
    parser.add_argument("--transport", choices=["stdio", "sse"], default="stdio",
                        help="Transport mode (default: stdio)")
    parser.add_argument("--host", default="0.0.0.0",
                        help="Host to bind SSE server (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000,
                        help="Port for SSE server (default: 8000)")
    args = parser.parse_args()

    if args.transport == "sse":
        app = create_starlette_app(mcp._mcp_server)
        uvicorn.run(app, host=args.host, port=args.port)
    else:
        mcp.run(transport="stdio")
