# ai4scholar_mcp/context.py
"""Per-request context for storing the user's API key.

In SSE mode, the Bearer token sent by the client is stored here so that
downstream searchers (PubMed, Semantic Scholar, etc.) can forward it to
ai4scholar.net on behalf of each individual user.

In stdio (local) mode the ContextVar is never set, so the searchers
fall back to the AI4SCHOLAR_API_KEY environment variable as before.
"""

from contextvars import ContextVar
from typing import Optional

# Stores the current user's AI4Scholar API key for the duration of one
# SSE session.  Each SSE connection runs in its own async task, so the
# ContextVar is naturally scoped per-user.
current_api_key: ContextVar[Optional[str]] = ContextVar(
    "current_api_key", default=None
)
