# AI4Scholar MCP Tools Reference

[English](#tools-reference) | [中文](#工具参考)

---

## Tools Reference

AI4Scholar MCP provides **24 tools** across 6 academic platforms. Below is a detailed reference for each tool.

### arXiv (3 tools)

| # | Tool | Description |
|---|------|-------------|
| 1 | `search_arxiv` | Search papers on arXiv by keyword. Returns title, authors, abstract, PDF URL, etc. |
| 2 | `download_arxiv` | Download the PDF of an arXiv paper by its paper ID (e.g., `2106.12345`). |
| 3 | `read_arxiv_paper` | Download and extract the full text content from an arXiv paper PDF. |

**Parameters:**

- `search_arxiv(query, max_results=10)` — `query`: search keywords; `max_results`: max papers to return.
- `download_arxiv(paper_id, save_path="./downloads")` — `paper_id`: arXiv ID (e.g., `2106.12345`).
- `read_arxiv_paper(paper_id, save_path="./downloads")` — same as above, returns extracted text.

---

### PubMed (4 tools)

| # | Tool | Description |
|---|------|-------------|
| 4 | `search_pubmed` | Search biomedical papers on PubMed by keyword. |
| 5 | `get_pubmed_paper_detail` | Get detailed metadata for a specific paper by its PMID. |
| 6 | `get_pubmed_citations` | Get papers that cite a given PubMed paper. |
| 7 | `get_pubmed_related` | Get papers related to a given PubMed paper. |

**Parameters:**

- `search_pubmed(query, max_results=10)` — `query`: search keywords.
- `get_pubmed_paper_detail(pmid)` — `pmid`: PubMed ID (e.g., `39575807`).
- `get_pubmed_citations(pmid, limit=20)` — `pmid`: PubMed ID; `limit`: max citing papers.
- `get_pubmed_related(pmid, limit=20)` — `pmid`: PubMed ID; `limit`: max related papers.

> Note: PubMed does not support direct PDF download or full-text extraction.

---

### Semantic Scholar (10 tools)

| # | Tool | Description |
|---|------|-------------|
| 8 | `search_semantic` | Search papers on Semantic Scholar. Supports year filtering (e.g., `2019`, `2016-2020`, `2010-`). |
| 9 | `download_semantic` | Download the PDF of a paper from Semantic Scholar. |
| 10 | `read_semantic_paper` | Download and extract full text from a Semantic Scholar paper PDF. |
| 11 | `get_semantic_citations` | Get all papers that cite a given paper (citation graph). |
| 12 | `get_semantic_references` | Get all papers referenced by a given paper (reference list). |
| 13 | `search_semantic_authors` | Search for authors by name. Returns author ID, affiliations, h-index, etc. |
| 14 | `get_semantic_author_papers` | Get all papers by a specific author. |
| 15 | `get_semantic_recommendations` | Get paper recommendations based on positive/negative paper examples. |
| 16 | `get_semantic_recommendations_for_paper` | Get paper recommendations based on a single paper. |
| 17 | `search_semantic_snippets` | Search for ~500-word text snippets within papers (titles, abstracts, body). |

**Parameters:**

- `search_semantic(query, year=None, max_results=10)` — `year`: optional filter, e.g., `"2019"`, `"2016-2020"`, `"2010-"`, `"-2015"`.
- `download_semantic(paper_id, save_path="./downloads")` — `paper_id` supports multiple formats:
  - Semantic Scholar ID: `649def34f8be52c8b66281af98ae884c09aef38b`
  - `DOI:10.18653/v1/N18-3011`
  - `ARXIV:2106.15928`
  - `PMID:19872477`
  - `URL:https://arxiv.org/abs/2106.15928v1`
- `read_semantic_paper(paper_id, save_path="./downloads")` — same ID formats as above.
- `get_semantic_citations(paper_id, limit=100, offset=0)` — paginated citation list.
- `get_semantic_references(paper_id, limit=100, offset=0)` — paginated reference list.
- `search_semantic_authors(query, limit=10)` — `query`: author name (e.g., `"Yann LeCun"`).
- `get_semantic_author_papers(author_id, limit=100, offset=0)` — `author_id`: Semantic Scholar author ID.
- `get_semantic_recommendations(positive_paper_ids, negative_paper_ids=None, limit=100)` — provide lists of paper IDs as examples.
- `get_semantic_recommendations_for_paper(paper_id, limit=100, pool="recent")` — `pool`: `"recent"` or `"all-cs"`.
- `search_semantic_snippets(query, limit=10)` — search within paper full text.

---

### Google Scholar (1 tool)

| # | Tool | Description |
|---|------|-------------|
| 18 | `search_google_scholar` | Search academic papers on Google Scholar via AI4Scholar proxy, with year filtering. |

**Parameters:**

- `search_google_scholar(query, max_results=10, year_from=None, year_to=None)` — `year_from`/`year_to`: optional year range filter.

---

### bioRxiv (3 tools)

| # | Tool | Description |
|---|------|-------------|
| 19 | `search_biorxiv` | Search preprint papers on bioRxiv (biology). |
| 20 | `download_biorxiv` | Download the PDF of a bioRxiv paper by its DOI. |
| 21 | `read_biorxiv_paper` | Download and extract full text from a bioRxiv paper PDF. |

**Parameters:**

- `search_biorxiv(query, max_results=10)` — `query`: search keywords.
- `download_biorxiv(paper_id, save_path="./downloads")` — `paper_id`: bioRxiv DOI.
- `read_biorxiv_paper(paper_id, save_path="./downloads")` — same as above, returns extracted text.

---

### medRxiv (3 tools)

| # | Tool | Description |
|---|------|-------------|
| 22 | `search_medrxiv` | Search preprint papers on medRxiv (medicine & health). |
| 23 | `download_medrxiv` | Download the PDF of a medRxiv paper by its DOI. |
| 24 | `read_medrxiv_paper` | Download and extract full text from a medRxiv paper PDF. |

**Parameters:**

- `search_medrxiv(query, max_results=10)` — `query`: search keywords.
- `download_medrxiv(paper_id, save_path="./downloads")` — `paper_id`: medRxiv DOI.
- `read_medrxiv_paper(paper_id, save_path="./downloads")` — same as above, returns extracted text.

---

## Usage Examples

Here are some natural language prompts you can use with AI assistants:

| Scenario | Prompt |
|----------|--------|
| Search papers | "Search for recent papers on large language models" |
| Google Scholar | "Search Google Scholar for deep learning papers from 2023 to 2025" |
| Year filter | "Find Semantic Scholar papers on transformers from 2023 to 2025" |
| Paper details | "Get the details of PubMed paper 39575807" |
| Download PDF | "Download the arXiv paper 2106.12345" |
| Read full text | "Read the full text of arXiv paper 2301.00234" |
| Citations | "What papers cite ARXIV:2106.15928?" |
| References | "Show me the references of this paper: DOI:10.18653/v1/N18-3011" |
| Author search | "Search for author Yann LeCun on Semantic Scholar" |
| Author papers | "List all papers by Semantic Scholar author 1741101" |
| Recommendations | "Recommend papers similar to ARXIV:2106.15928" |
| Snippet search | "Search for text snippets about 'attention mechanism' in papers" |
| Related papers | "Find papers related to PubMed paper 30102808" |

---
---

## 工具参考

AI4Scholar MCP 提供 **24 个工具**，覆盖 6 个学术平台。以下是每个工具的详细说明。

### arXiv（3 个工具）

| # | 工具 | 说明 |
|---|------|------|
| 1 | `search_arxiv` | 在 arXiv 上按关键词搜索论文，返回标题、作者、摘要、PDF 链接等。 |
| 2 | `download_arxiv` | 通过 arXiv 论文 ID（如 `2106.12345`）下载 PDF 文件。 |
| 3 | `read_arxiv_paper` | 下载 arXiv 论文 PDF 并提取全文文本内容。 |

**参数说明：**

- `search_arxiv(query, max_results=10)` — `query`：搜索关键词；`max_results`：最大返回数量。
- `download_arxiv(paper_id, save_path="./downloads")` — `paper_id`：arXiv ID（如 `2106.12345`）。
- `read_arxiv_paper(paper_id, save_path="./downloads")` — 同上，返回提取的文本内容。

---

### PubMed（4 个工具）

| # | 工具 | 说明 |
|---|------|------|
| 4 | `search_pubmed` | 在 PubMed 上按关键词搜索生物医学论文。 |
| 5 | `get_pubmed_paper_detail` | 通过 PMID 获取论文的详细元数据。 |
| 6 | `get_pubmed_citations` | 获取引用了指定 PubMed 论文的所有论文。 |
| 7 | `get_pubmed_related` | 获取与指定 PubMed 论文相关的论文。 |

**参数说明：**

- `search_pubmed(query, max_results=10)` — `query`：搜索关键词。
- `get_pubmed_paper_detail(pmid)` — `pmid`：PubMed ID（如 `39575807`）。
- `get_pubmed_citations(pmid, limit=20)` — `pmid`：PubMed ID；`limit`：最大引用论文数。
- `get_pubmed_related(pmid, limit=20)` — `pmid`：PubMed ID；`limit`：最大相关论文数。

> 注意：PubMed 不支持直接下载 PDF 或提取全文。

---

### Semantic Scholar（10 个工具）

| # | 工具 | 说明 |
|---|------|------|
| 8 | `search_semantic` | 在 Semantic Scholar 上搜索论文，支持年份过滤（如 `2019`、`2016-2020`、`2010-`）。 |
| 9 | `download_semantic` | 下载 Semantic Scholar 论文的 PDF。 |
| 10 | `read_semantic_paper` | 下载并提取 Semantic Scholar 论文 PDF 的全文内容。 |
| 11 | `get_semantic_citations` | 获取引用了指定论文的所有论文（引用图谱）。 |
| 12 | `get_semantic_references` | 获取指定论文引用的所有参考文献。 |
| 13 | `search_semantic_authors` | 按姓名搜索学者，返回作者 ID、机构、h-index 等。 |
| 14 | `get_semantic_author_papers` | 获取指定学者的所有论文列表。 |
| 15 | `get_semantic_recommendations` | 基于正面/负面论文示例获取论文推荐。 |
| 16 | `get_semantic_recommendations_for_paper` | 基于单篇论文获取相似论文推荐。 |
| 17 | `search_semantic_snippets` | 在论文全文中搜索约 500 词的文本片段（标题、摘要、正文）。 |

**参数说明：**

- `search_semantic(query, year=None, max_results=10)` — `year`：可选年份过滤，如 `"2019"`、`"2016-2020"`、`"2010-"`、`"-2015"`。
- `download_semantic(paper_id, save_path="./downloads")` — `paper_id` 支持多种格式：
  - Semantic Scholar ID：`649def34f8be52c8b66281af98ae884c09aef38b`
  - `DOI:10.18653/v1/N18-3011`
  - `ARXIV:2106.15928`
  - `PMID:19872477`
  - `URL:https://arxiv.org/abs/2106.15928v1`
- `read_semantic_paper(paper_id, save_path="./downloads")` — 同上述 ID 格式。
- `get_semantic_citations(paper_id, limit=100, offset=0)` — 分页获取引用列表。
- `get_semantic_references(paper_id, limit=100, offset=0)` — 分页获取参考文献列表。
- `search_semantic_authors(query, limit=10)` — `query`：学者姓名（如 `"Yann LeCun"`）。
- `get_semantic_author_papers(author_id, limit=100, offset=0)` — `author_id`：Semantic Scholar 作者 ID。
- `get_semantic_recommendations(positive_paper_ids, negative_paper_ids=None, limit=100)` — 提供论文 ID 列表作为示例。
- `get_semantic_recommendations_for_paper(paper_id, limit=100, pool="recent")` — `pool`：`"recent"` 或 `"all-cs"`。
- `search_semantic_snippets(query, limit=10)` — 在论文全文中搜索文本片段。

---

### Google Scholar（1 个工具）

| # | 工具 | 说明 |
|---|------|------|
| 18 | `search_google_scholar` | 通过 AI4Scholar 代理在 Google Scholar 上搜索学术论文，支持年份过滤。 |

**参数说明：**

- `search_google_scholar(query, max_results=10, year_from=None, year_to=None)` — `year_from`/`year_to`：可选年份范围过滤。

---

### bioRxiv（3 个工具）

| # | 工具 | 说明 |
|---|------|------|
| 19 | `search_biorxiv` | 在 bioRxiv 上搜索生物学预印本论文。 |
| 20 | `download_biorxiv` | 通过 DOI 下载 bioRxiv 论文的 PDF。 |
| 21 | `read_biorxiv_paper` | 下载并提取 bioRxiv 论文 PDF 的全文内容。 |

**参数说明：**

- `search_biorxiv(query, max_results=10)` — `query`：搜索关键词。
- `download_biorxiv(paper_id, save_path="./downloads")` — `paper_id`：bioRxiv DOI。
- `read_biorxiv_paper(paper_id, save_path="./downloads")` — 同上，返回提取的文本内容。

---

### medRxiv（3 个工具）

| # | 工具 | 说明 |
|---|------|------|
| 22 | `search_medrxiv` | 在 medRxiv 上搜索医学与健康预印本论文。 |
| 23 | `download_medrxiv` | 通过 DOI 下载 medRxiv 论文的 PDF。 |
| 24 | `read_medrxiv_paper` | 下载并提取 medRxiv 论文 PDF 的全文内容。 |

**参数说明：**

- `search_medrxiv(query, max_results=10)` — `query`：搜索关键词。
- `download_medrxiv(paper_id, save_path="./downloads")` — `paper_id`：medRxiv DOI。
- `read_medrxiv_paper(paper_id, save_path="./downloads")` — 同上，返回提取的文本内容。

---

### 使用示例

以下是一些你可以对 AI 助手说的自然语言指令：

| 场景 | 提示词 |
|------|--------|
| 搜索论文 | "帮我搜索关于大语言模型的最新论文" |
| Google Scholar | "在 Google Scholar 上搜索 2023-2025 年的深度学习论文" |
| 年份过滤 | "在 Semantic Scholar 上搜索 2023-2025 年关于 transformer 的论文" |
| 论文详情 | "查看 PubMed 论文 39575807 的详细信息" |
| 下载 PDF | "下载 arXiv 论文 2106.12345" |
| 阅读全文 | "阅读 arXiv 论文 2301.00234 的全文" |
| 引用查询 | "哪些论文引用了 ARXIV:2106.15928？" |
| 参考文献 | "列出这篇论文的参考文献：DOI:10.18653/v1/N18-3011" |
| 搜索学者 | "在 Semantic Scholar 上搜索学者 Yann LeCun" |
| 学者论文 | "列出 Semantic Scholar 作者 1741101 的所有论文" |
| 论文推荐 | "推荐与 ARXIV:2106.15928 类似的论文" |
| 片段搜索 | "搜索论文中关于 attention mechanism 的文本片段" |
| 相关论文 | "查找与 PubMed 论文 30102808 相关的论文" |
