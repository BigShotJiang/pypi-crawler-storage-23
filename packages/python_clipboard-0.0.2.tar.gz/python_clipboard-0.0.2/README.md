# python-clipboard

Python clipboard manager inspired by CLCL
