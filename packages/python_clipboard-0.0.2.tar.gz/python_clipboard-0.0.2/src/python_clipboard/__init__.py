"""python-clipboard: Python clipboard manager inspired by CLCL"""

from importlib.metadata import version

__version__ = version("python-clipboard")
