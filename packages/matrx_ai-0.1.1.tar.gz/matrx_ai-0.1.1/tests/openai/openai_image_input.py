import os

from dotenv import load_dotenv
from matrx_utils import clear_terminal, vcprint
from openai import OpenAI

load_dotenv()
clear_terminal()

test_user_id = os.environ.get("TEST_USER_ID", "")

client = OpenAI()

response = client.responses.create(
    model="gpt-4.1-mini",
    input=[
        {
            "role": "user",
            "content": [
                { 
                 "type": "input_text", 
                 "text": "what is in this image?" 
                 },
                {
                    "type": "input_image",
                    "image_url": f"https://txzxabzwovsujtloxrus.supabase.co/storage/v1/object/public/user-public-assets/user-{test_user_id}/mcp-logo.png"
                }
            ]
        }
    ]
)

vcprint(response, "Response", color="green")

text_content = response.output[0].content[0].text
print("\n")
print(text_content)
print("\n")
