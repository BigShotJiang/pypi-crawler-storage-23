from matrx_orm.schema_builder import run_schema_generation

run_schema_generation("matrx_orm.yaml")
