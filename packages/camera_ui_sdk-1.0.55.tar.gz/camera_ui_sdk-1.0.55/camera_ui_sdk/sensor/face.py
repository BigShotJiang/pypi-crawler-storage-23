from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, NotRequired, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType
from .motion import Detection, VideoFrameData
from .spec import ModelSpec


class FaceProperty(str, Enum):
    """Properties for face detection sensors."""

    Detected = "detected"
    Faces = "faces"


class FaceLandmarks(TypedDict):
    """Facial landmark coordinates (normalized 0-1)."""

    leftEye: tuple[float, float]
    rightEye: tuple[float, float]
    nose: tuple[float, float]
    leftMouth: tuple[float, float]
    rightMouth: tuple[float, float]


class FaceDetection(Detection):
    """A face detection result, extending Detection with face-specific fields."""

    identity: NotRequired[str]
    embedding: NotRequired[list[float]]
    landmarks: NotRequired[FaceLandmarks]


class FaceSensorProperties(TypedDict):
    detected: bool
    faces: list[FaceDetection]


class FacePropertyChangeData(TypedDict):
    """Emitted on FaceSensorLike.onPropertyChanged."""

    property: str  # FaceProperty value
    value: bool | list[FaceDetection]


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class FaceSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for a face sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.Face

    @overload
    def getPropertyValue(self, property: Literal[FaceProperty.Detected]) -> bool | None: ...
    @overload
    def getPropertyValue(self, property: Literal[FaceProperty.Faces]) -> list[FaceDetection] | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[FacePropertyChangeData]: ...


class FaceSensor(Sensor[FaceSensorProperties, TStorage, str], Generic[TStorage]):
    """Face sensor that reports detected faces and optional identity matches."""

    _requires_frames = False

    def __init__(self, name: str = "Face Sensor") -> None:
        super().__init__(name)
        self.props.detected = False
        self.props.faces = []

    @property
    def type(self) -> SensorType:
        return SensorType.Face

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return self.props.detected  # type: ignore[no-any-return]

    @detected.setter
    def detected(self, value: bool) -> None:
        self.props.detected = value

    @property
    def faces(self) -> list[FaceDetection]:
        return self.props.faces  # type: ignore[no-any-return]

    @faces.setter
    def faces(self, value: list[FaceDetection]) -> None:
        self.props.faces = value


class FaceResult(TypedDict):
    """Return type for FaceDetectorSensor.detectFaces()."""

    detected: bool
    faces: list[FaceDetection]


class FaceDetectorSensor(FaceSensor[TStorage], Generic[TStorage]):
    """Face detector that receives video frames. Implement detectFaces() for face detection and recognition."""

    _requires_frames = True

    @property
    @abstractmethod
    def modelSpec(self) -> ModelSpec:
        """Declares expected input dimensions and output labels. The backend scales frames to match."""
        ...

    @abstractmethod
    async def detectFaces(
        self, frame: VideoFrameData, personRegions: list[Detection] | None = None
    ) -> FaceResult:
        """Analyze a video frame for faces. Called by the backend at the configured interval."""
        ...
