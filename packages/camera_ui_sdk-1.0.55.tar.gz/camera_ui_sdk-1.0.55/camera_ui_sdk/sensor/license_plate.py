from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType
from .motion import Detection, VideoFrameData
from .spec import ModelSpec


class LicensePlateProperty(str, Enum):
    """Properties for license plate sensors."""

    Detected = "detected"
    Plates = "plates"


class LicensePlateDetection(Detection):
    """A license plate detection result, extending Detection with OCR fields."""

    plateText: str
    plateConfidence: float


class LicensePlateSensorProperties(TypedDict):
    detected: bool
    plates: list[LicensePlateDetection]


class LicensePlatePropertyChangeData(TypedDict):
    """Emitted on LicensePlateSensorLike.onPropertyChanged."""

    property: str  # LicensePlateProperty value
    value: bool | list[LicensePlateDetection]


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class LicensePlateSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for a license plate sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.LicensePlate

    @overload
    def getPropertyValue(self, property: Literal[LicensePlateProperty.Detected]) -> bool | None: ...
    @overload
    def getPropertyValue(
        self, property: Literal[LicensePlateProperty.Plates]
    ) -> list[LicensePlateDetection] | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[LicensePlatePropertyChangeData]: ...


class LicensePlateSensor(Sensor[LicensePlateSensorProperties, TStorage, str], Generic[TStorage]):
    """License plate sensor that reports detected plates with OCR text."""

    _requires_frames = False

    def __init__(self, name: str = "License Plate Sensor") -> None:
        super().__init__(name)
        self.props.detected = False
        self.props.plates = []

    @property
    def type(self) -> SensorType:
        return SensorType.LicensePlate

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return self.props.detected  # type: ignore[no-any-return]

    @detected.setter
    def detected(self, value: bool) -> None:
        self.props.detected = value

    @property
    def plates(self) -> list[LicensePlateDetection]:
        return self.props.plates  # type: ignore[no-any-return]

    @plates.setter
    def plates(self, value: list[LicensePlateDetection]) -> None:
        self.props.plates = value


class LicensePlateResult(TypedDict):
    """Return type for LicensePlateDetectorSensor.detectLicensePlates()."""

    detected: bool
    plates: list[LicensePlateDetection]


class LicensePlateDetectorSensor(LicensePlateSensor[TStorage], Generic[TStorage]):
    """License plate detector that receives video frames. Implement detectLicensePlates()."""

    _requires_frames = True

    @property
    @abstractmethod
    def modelSpec(self) -> ModelSpec:
        """Declares expected input dimensions and output labels. The backend scales frames to match."""
        ...

    @abstractmethod
    async def detectLicensePlates(
        self, frame: VideoFrameData, vehicleRegions: list[Detection] | None = None
    ) -> LicensePlateResult:
        """Analyze a video frame for license plates. Called by the backend at the configured interval."""
        ...
