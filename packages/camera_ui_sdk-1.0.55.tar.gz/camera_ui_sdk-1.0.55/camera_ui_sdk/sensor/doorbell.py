from __future__ import annotations

from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType


class DoorbellProperty(str, Enum):
    """Properties for doorbell triggers."""

    Ring = "ring"


class DoorbellTriggerProperties(TypedDict):
    ring: bool


class DoorbellPropertyChangeData(TypedDict):
    """Emitted on DoorbellTriggerLike.onPropertyChanged."""

    property: str  # DoorbellProperty value
    value: bool


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class DoorbellTriggerLike(SensorLike, Protocol):
    """Read-only proxy interface for a doorbell trigger."""

    @property
    def type(self) -> SensorType:
        return SensorType.Doorbell

    @overload
    def getPropertyValue(self, property: Literal[DoorbellProperty.Ring]) -> bool | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[DoorbellPropertyChangeData]: ...


class DoorbellTrigger(Sensor[DoorbellTriggerProperties, TStorage, str], Generic[TStorage]):
    """Doorbell trigger sensor. Set ring = True to trigger a doorbell event."""

    _requires_frames = False

    def __init__(self, name: str = "Doorbell") -> None:
        super().__init__(name)
        self.props.ring = False

    @property
    def type(self) -> SensorType:
        return SensorType.Doorbell

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Trigger

    @property
    def ring(self) -> bool:
        return self.props.ring  # type: ignore[no-any-return]

    @ring.setter
    def ring(self, value: bool) -> None:
        self.props.ring = value
