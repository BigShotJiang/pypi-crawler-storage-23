from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, NotRequired, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType


class PTZCapability(str, Enum):
    """Optional capabilities for PTZ controls."""

    Pan = "pan"
    Tilt = "tilt"
    Zoom = "zoom"
    Presets = "presets"
    Home = "home"


class PTZProperty(str, Enum):
    """Properties for PTZ controls."""

    Position = "position"
    Moving = "moving"
    Presets = "presets"
    Velocity = "velocity"
    TargetPreset = "targetPreset"


class PTZPosition(TypedDict):
    """Absolute PTZ position."""

    pan: float
    tilt: float
    zoom: float


class PTZDirection(TypedDict):
    """PTZ movement speed for continuous move commands."""

    panSpeed: float
    tiltSpeed: float
    zoomSpeed: float


class PTZControlProperties(TypedDict):
    position: PTZPosition
    moving: bool
    presets: list[str]
    velocity: NotRequired[PTZDirection | None]
    targetPreset: NotRequired[str | None]


class PTZPropertyChangeData(TypedDict):
    """Emitted on PTZControlLike.onPropertyChanged."""

    property: str  # PTZProperty value
    value: PTZPosition | bool | list[str] | PTZDirection | str | None


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class PTZControlLike(SensorLike, Protocol):
    """Read-only proxy interface for a PTZ control."""

    @property
    def type(self) -> SensorType:
        return SensorType.PTZ

    @overload
    def getPropertyValue(self, property: Literal[PTZProperty.Position]) -> PTZPosition | None: ...
    @overload
    def getPropertyValue(self, property: Literal[PTZProperty.Moving]) -> bool | None: ...
    @overload
    def getPropertyValue(self, property: Literal[PTZProperty.Presets]) -> list[str] | None: ...
    @overload
    def getPropertyValue(self, property: Literal[PTZProperty.Velocity]) -> PTZDirection | None: ...
    @overload
    def getPropertyValue(self, property: Literal[PTZProperty.TargetPreset]) -> str | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @overload
    async def setPropertyValue(self, property: Literal[PTZProperty.Position], value: PTZPosition) -> None: ...
    @overload
    async def setPropertyValue(self, property: Literal[PTZProperty.Moving], value: bool) -> None: ...
    @overload
    async def setPropertyValue(self, property: Literal[PTZProperty.Presets], value: list[str]) -> None: ...
    @overload
    async def setPropertyValue(
        self, property: Literal[PTZProperty.Velocity], value: PTZDirection
    ) -> None: ...
    @overload
    async def setPropertyValue(self, property: Literal[PTZProperty.TargetPreset], value: str) -> None: ...
    @overload
    async def setPropertyValue(self, property: str, value: Any) -> None: ...

    @property
    def onPropertyChanged(self) -> Observable[PTZPropertyChangeData]: ...

    @property
    def onCapabilitiesChanged(self) -> Observable[list[PTZCapability]]: ...


class PTZControl(Sensor[PTZControlProperties, TStorage, PTZCapability], Generic[TStorage]):
    """Pan-tilt-zoom camera control. Extend this and implement setPosition()."""

    _requires_frames = False

    def __init__(self, name: str = "PTZ") -> None:
        super().__init__(name)
        self.props.position = {"pan": 0, "tilt": 0, "zoom": 0}
        self.props.moving = False
        self.props.presets = []

    @property
    def type(self) -> SensorType:
        return SensorType.PTZ

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Control

    @property
    def position(self) -> PTZPosition:
        return self.props.position  # type: ignore[no-any-return]

    @position.setter
    def position(self, value: PTZPosition) -> None:
        self.props.position = value

    @property
    def moving(self) -> bool:
        return self.props.moving  # type: ignore[no-any-return]

    @moving.setter
    def moving(self, value: bool) -> None:
        self.props.moving = value

    @property
    def presets(self) -> list[str]:
        return self.props.presets  # type: ignore[no-any-return]

    @presets.setter
    def presets(self, value: list[str]) -> None:
        self.props.presets = value

    @property
    def velocity(self) -> PTZDirection | None:
        return self.props.velocity  # type: ignore[no-any-return]

    @velocity.setter
    def velocity(self, value: PTZDirection | None) -> None:
        self.props.velocity = value

    @property
    def targetPreset(self) -> str | None:
        return self.props.targetPreset  # type: ignore[no-any-return]

    @targetPreset.setter
    def targetPreset(self, value: str | None) -> None:
        self.props.targetPreset = value

    @abstractmethod
    async def setPosition(self, value: PTZPosition) -> None:
        """Implement to handle absolute position move commands from the backend/UI."""
        ...

    async def setVelocity(self, value: PTZDirection | None) -> None:
        self.velocity = value

    async def setTargetPreset(self, value: str | None) -> None:
        self.targetPreset = value

    async def goHome(self) -> None:
        """Move the camera to the home position (pan=0, tilt=0, zoom=0)."""
        await self.setPosition({"pan": 0, "tilt": 0, "zoom": 0})
