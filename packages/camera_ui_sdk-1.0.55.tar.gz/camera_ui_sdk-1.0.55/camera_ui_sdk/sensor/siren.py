from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType


class SirenCapability(str, Enum):
    """Optional capabilities for siren controls."""

    Volume = "volume"


class SirenProperty(str, Enum):
    """Properties for siren controls."""

    Active = "active"
    Volume = "volume"


class SirenControlProperties(TypedDict):
    active: bool
    volume: int


class SirenPropertyChangeData(TypedDict):
    """Emitted on SirenControlLike.onPropertyChanged."""

    property: str  # SirenProperty value
    value: bool | int


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class SirenControlLike(SensorLike, Protocol):
    """Read-only proxy interface for a siren control."""

    @property
    def type(self) -> SensorType:
        return SensorType.Siren

    @overload
    def getPropertyValue(self, property: Literal[SirenProperty.Active]) -> bool | None: ...
    @overload
    def getPropertyValue(self, property: Literal[SirenProperty.Volume]) -> int | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @overload
    async def setPropertyValue(self, property: Literal[SirenProperty.Active], value: bool) -> None: ...
    @overload
    async def setPropertyValue(self, property: Literal[SirenProperty.Volume], value: int) -> None: ...
    @overload
    async def setPropertyValue(self, property: str, value: Any) -> None: ...

    @property
    def onPropertyChanged(self) -> Observable[SirenPropertyChangeData]: ...

    @property
    def onCapabilitiesChanged(self) -> Observable[list[SirenCapability]]: ...


class SirenControl(Sensor[SirenControlProperties, TStorage, SirenCapability], Generic[TStorage]):
    """Siren control sensor. Extend this and implement setActive()."""

    _requires_frames = False

    def __init__(self, name: str = "Siren") -> None:
        super().__init__(name)
        self.props.active = False
        self.props.volume = 100

    @property
    def type(self) -> SensorType:
        return SensorType.Siren

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Control

    @property
    def active(self) -> bool:
        return self.props.active  # type: ignore[no-any-return]

    @active.setter
    def active(self, value: bool) -> None:
        self.props.active = value

    @property
    def volume(self) -> int:
        return self.props.volume  # type: ignore[no-any-return]

    @volume.setter
    def volume(self, value: int) -> None:
        self.props.volume = max(0, min(100, value))

    @abstractmethod
    async def setActive(self, value: bool) -> None:
        """Implement to handle activate/deactivate commands from the backend/UI."""
        ...

    async def setVolume(self, value: int) -> None:
        self.volume = value
