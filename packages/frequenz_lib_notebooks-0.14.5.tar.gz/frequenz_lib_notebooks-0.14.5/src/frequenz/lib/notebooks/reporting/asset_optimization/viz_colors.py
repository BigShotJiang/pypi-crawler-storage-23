# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Color palette for asset optimization visualizations."""

CHP = "rgba(100, 149, 237, 1)"
PV = "rgba(255, 243, 138, 1)"
CONSUMPTION = "rgba(0, 0, 0, 1)"
GRID = "rgba(128, 128, 128, 1)"
CHARGE = "rgba(236, 0, 140, 0.45)"
DISCHARGE = "rgba(146, 219, 68, 0.45)"
BUY = "rgba(139, 0, 0, 1)"
SELL = "rgba(0, 100, 0, 1)"
SOC = "rgba(0, 204, 150, 1)"
AVAILABLE = "rgba(0, 0, 0, 1)"
ZERO_LINE = "rgba(128, 128, 128, 1)"
TRANSPARENT = "rgba(0,0,0,0)"
