#!/bin/bash
python -m cstar.entrypoint.worker.worker "$@"
