Release notes
#############

.. include:: releases/v0.3.0.rst

.. include:: releases/v0.1.0.rst

.. include:: releases/v0.0.8-alpha.rst

.. include:: releases/v0.0.3-alpha.rst

.. include:: releases/v0.0.1-alpha.rst
