{{ fullname | underline }}

.. currentmodule:: {{ module }}

.. envvar-table:: {{ fullname }}
