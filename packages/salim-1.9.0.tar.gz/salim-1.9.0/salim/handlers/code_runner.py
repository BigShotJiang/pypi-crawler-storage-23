"""
Salim Code Runner — AI writes comprehensive, production-quality code then executes it.

/code <description>        — AI writes + runs the code, sends output + file
/run python <code>         — Run Python code directly
/run js <code>             — Run JavaScript via Node.js
/run bash <code>           — Run bash (same as /run)
/code save                 — Save last generated code to Desktop
/code last                 — Re-run last code

The AI prompt is specifically engineered to produce:
  - Full working implementations (not toy examples)
  - Proper error handling
  - Comprehensive output / data
  - Well-commented, readable code
  - Real libraries (requests, pandas, matplotlib, etc.)
  - Multi-function scripts, not single-liners
"""
from __future__ import annotations

import asyncio
import io
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
import textwrap
import time
from pathlib import Path
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, truncate

logger = logging.getLogger("salim.coderunner")

# Per-user last code storage
_last_code: dict[int, dict] = {}   # user_id → {lang, code, description}

CODE_SYSTEM_PROMPT = """You are an expert programmer writing production-quality scripts for a user who will execute them immediately on their laptop.

RULES — CRITICAL:
1. Write COMPLETE, FULLY WORKING code. No placeholders. No "TODO". No "# Add your logic here".
2. Handle ALL errors with try/except and informative messages.
3. Use real libraries when needed (requests, pandas, matplotlib, BeautifulSoup, etc.)
4. Include rich, descriptive print() output so the user sees what happened.
5. Scripts must be self-contained — no user input required to run.
6. For data tasks: generate realistic sample data if no real data source available.
7. For file tasks: save to ~/Desktop/ and print the full path.
8. For network tasks: include timeout and retry logic.
9. Add a clear header comment explaining what the script does.
10. Minimum 30 lines of real logic. Never write a 5-line prototype.

OUTPUT FORMAT:
Return ONLY a JSON object, nothing else:
{
  "lang": "python",
  "description": "one-line description of what the script does",
  "code": "full script as a string with \\n for newlines",
  "install": ["requests", "pandas"]   // pip packages to auto-install (can be empty [])
}

LANGUAGE SELECTION:
- Data analysis, files, system tasks → python
- Web scraping → python (requests + BeautifulSoup4)
- CLI tools, file processing → python
- JSON/API work → python
- Simple automation → python or bash
- Node/npm ecosystem tasks → javascript

EXAMPLE — if asked "count word frequency in a text":
Return Python that: reads a hardcoded paragraph of Lorem Ipsum, splits into words,
counts with collections.Counter, prints top-20 as a formatted table, saves CSV to Desktop.
Never return just: `Counter(text.split())` — that's not a complete script."""

EXECUTION_TIMEOUT = 30   # seconds for code execution
MAX_OUTPUT_CHARS = 4000


def _auto_install_packages(packages: list[str]) -> tuple[bool, str]:
    """Install missing pip packages. Returns (all_ok, error_message)."""
    if not packages:
        return True, ""
    for pkg in packages:
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg, "--quiet"],
                capture_output=True, text=True, timeout=60
            )
            if result.returncode != 0:
                return False, f"Failed to install {pkg}: {result.stderr[:200]}"
        except Exception as e:
            return False, str(e)
    return True, ""


async def _run_python(code: str, timeout: int = EXECUTION_TIMEOUT) -> tuple[str, int, str]:
    """Execute Python code. Returns (output, exit_code, error)."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        script_path = f.name

    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, script_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(Path.home() / "Desktop"),
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            return "", -1, f"Execution timed out after {timeout}s"

        out = stdout.decode(errors="replace")
        err = stderr.decode(errors="replace")
        combined = out + (("\n--- stderr ---\n" + err) if err.strip() else "")
        return combined, proc.returncode, err

    finally:
        try:
            os.unlink(script_path)
        except Exception:
            pass


async def _run_javascript(code: str, timeout: int = EXECUTION_TIMEOUT) -> tuple[str, int, str]:
    """Execute JavaScript via Node.js."""
    import shutil
    if not shutil.which("node"):
        return "", -1, "Node.js not found. Install: https://nodejs.org"

    with tempfile.NamedTemporaryFile(mode="w", suffix=".js", delete=False) as f:
        f.write(code)
        script_path = f.name

    try:
        proc = await asyncio.create_subprocess_exec(
            "node", script_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            return "", -1, f"Execution timed out after {timeout}s"

        out = stdout.decode(errors="replace")
        err = stderr.decode(errors="replace")
        combined = out + (("\n--- stderr ---\n" + err) if err.strip() else "")
        return combined, proc.returncode, err
    finally:
        try:
            os.unlink(script_path)
        except Exception:
            pass


async def _generate_code(user_request: str, ai) -> dict | None:
    """Ask AI to write the code. Returns parsed JSON dict or None."""
    messages = [{"role": "user", "content": user_request}]
    try:
        raw, provider = await ai._call_with_fallback(
            messages,
            CODE_SYSTEM_PROMPT,
            max_tokens=4096,
            temperature=0.2,
        )
        # Strip markdown fences
        raw = re.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
        # Find JSON object
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        if m:
            raw = m.group(0)
        data = json.loads(raw)
        data["_provider"] = provider
        return data
    except Exception as e:
        logger.error(f"Code generation failed: {e}")
        return None


class CodeRunnerHandlers:

    @require_auth
    async def cmd_code(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /code <description>   — AI writes comprehensive code and runs it
        /code save            — Save last generated code to Desktop
        /code last            — Re-run last generated code
        """
        user_id = update.effective_user.id
        args = ctx.args or []
        msg = update.effective_message

        if not args:
            await msg.reply_text(
                "🧑‍💻 <b>AI Code Runner</b>\n\n"
                "Usage: <code>/code &lt;describe what you want&gt;</code>\n\n"
                "<b>Examples:</b>\n"
                "• <code>/code scrape top 10 HackerNews stories and save as CSV</code>\n"
                "• <code>/code analyze disk usage and show largest folders</code>\n"
                "• <code>/code generate a PDF report of system stats</code>\n"
                "• <code>/code download all images from a URL and save to Desktop</code>\n"
                "• <code>/code create a word frequency analysis of a long text</code>\n"
                "• <code>/code find all duplicate files in my Downloads folder</code>\n"
                "• <code>/code send a GET request to an API and format the JSON</code>\n\n"
                "<i>AI writes complete, production-quality code — not prototypes.</i>",
                parse_mode="HTML"
            )
            return

        sub = args[0].lower()

        if sub == "save" and user_id in _last_code:
            await self._save_code(msg, user_id)
            return

        if sub == "last" and user_id in _last_code:
            await self._rerun_code(msg, user_id)
            return

        description = " ".join(args)

        # Get AI instance
        from salim.ai import SalimAI
        ai = SalimAI(self.config)

        if not ai.is_configured():
            await msg.reply_text(
                "❌ AI not configured. Run <code>salim setup</code> to add API keys.",
                parse_mode="HTML"
            )
            return

        status = await msg.reply_text(
            f"🤖 <i>Writing code for: \"{description}\"...</i>",
            parse_mode="HTML"
        )

        # Generate code
        code_data = await _generate_code(description, ai)

        if not code_data or "code" not in code_data:
            await status.edit_text(
                "❌ AI failed to generate code. Try rephrasing your request.",
                parse_mode="HTML"
            )
            return

        lang = code_data.get("lang", "python").lower()
        code = code_data.get("code", "")
        desc = code_data.get("description", description)
        packages = code_data.get("install", [])
        provider = code_data.get("_provider", "AI")

        # Store for /code save and /code last
        _last_code[user_id] = {
            "lang": lang,
            "code": code,
            "description": desc,
        }

        # Show the code first
        lang_display = lang.title()
        code_preview = code[:800] + ("..." if len(code) > 800 else "")

        await status.edit_text(
            f"📝 <b>{lang_display} code generated</b> <i>[{provider}]</i>\n"
            f"<i>{desc}</i>\n\n"
            f"<pre><code>{_escape_html(code_preview)}</code></pre>\n\n"
            f"⚙️ <i>Installing dependencies & running...</i>",
            parse_mode="HTML"
        )

        # Auto-install required packages
        if packages and lang == "python":
            install_ok, install_err = await asyncio.get_event_loop().run_in_executor(
                None, _auto_install_packages, packages
            )
            if not install_ok:
                await msg.reply_text(
                    f"⚠️ Package install warning: <code>{install_err[:200]}</code>\n"
                    "Attempting to run anyway...",
                    parse_mode="HTML"
                )

        # Execute
        start_time = time.time()
        if lang == "python":
            output, exit_code, stderr = await _run_python(code)
        elif lang in ("javascript", "js", "node"):
            output, exit_code, stderr = await _run_javascript(code)
        elif lang in ("bash", "shell", "sh"):
            output, exit_code = await run_shell_async(code, timeout=EXECUTION_TIMEOUT)
            stderr = ""
        else:
            output, exit_code, stderr = await _run_python(code)

        elapsed = time.time() - start_time
        icon = "✅" if exit_code == 0 else "❌"

        # Format output
        output_clean = output.strip() if output else "(no output)"
        output_truncated = truncate(output_clean, MAX_OUTPUT_CHARS)

        # Send result
        result_text = (
            f"{icon} <b>Execution complete</b> · {elapsed:.2f}s\n"
            f"<i>{desc}</i>\n\n"
            f"<b>Output:</b>\n<pre>{_escape_html(output_truncated)}</pre>"
        )

        if len(result_text) > 4000:
            # Send output as file
            buf = io.BytesIO(output_clean.encode("utf-8"))
            buf.name = f"output_{int(time.time())}.txt"
            await msg.reply_document(
                document=buf,
                filename=buf.name,
                caption=f"{icon} Code executed · {elapsed:.2f}s · {len(output_clean)} chars output"
            )
        else:
            await msg.reply_text(result_text, parse_mode="HTML")

        # Send the full code as a downloadable file
        ext = {"python": "py", "javascript": "js", "js": "js", "bash": "sh"}.get(lang, "txt")
        code_buf = io.BytesIO(code.encode("utf-8"))
        code_buf.name = f"salim_code_{int(time.time())}.{ext}"
        await msg.reply_document(
            document=code_buf,
            filename=code_buf.name,
            caption=f"📄 Full {lang_display} code · {len(code)} chars\n"
                    f"Use /code save to save to Desktop"
        )

        # Inline buttons
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("▶️ Run again", callback_data=f"code_rerun:{user_id}"),
            InlineKeyboardButton("💾 Save to Desktop", callback_data=f"code_save:{user_id}"),
        ]])
        await msg.reply_text(
            "💡 <i>What next?</i>",
            parse_mode="HTML",
            reply_markup=keyboard
        )

    async def _save_code(self, msg, user_id: int):
        """Save last generated code to Desktop."""
        data = _last_code.get(user_id)
        if not data:
            await msg.reply_text("❌ No code to save. Generate code first with /code")
            return

        lang = data["lang"]
        code = data["code"]
        ext = {"python": "py", "javascript": "js", "bash": "sh"}.get(lang, "txt")
        desktop = Path.home() / "Desktop"
        desktop.mkdir(exist_ok=True)
        filename = f"salim_code_{int(time.time())}.{ext}"
        path = desktop / filename
        path.write_text(code, encoding="utf-8")

        await msg.reply_text(
            f"💾 Saved to <code>{path}</code>",
            parse_mode="HTML"
        )

    async def _rerun_code(self, msg, user_id: int):
        """Re-run last generated code."""
        data = _last_code.get(user_id)
        if not data:
            await msg.reply_text("❌ No previous code. Generate code first with /code")
            return

        lang = data["lang"]
        code = data["code"]
        desc = data["description"]

        status = await msg.reply_text(f"▶️ <i>Re-running: {desc}...</i>", parse_mode="HTML")

        start = time.time()
        if lang == "python":
            output, exit_code, _ = await _run_python(code)
        elif lang in ("javascript", "js"):
            output, exit_code, _ = await _run_javascript(code)
        else:
            output, exit_code = await run_shell_async(code)

        elapsed = time.time() - start
        icon = "✅" if exit_code == 0 else "❌"
        output_clean = truncate(output.strip() or "(no output)", MAX_OUTPUT_CHARS)

        await status.edit_text(
            f"{icon} <b>Re-run complete</b> · {elapsed:.2f}s\n\n"
            f"<pre>{_escape_html(output_clean)}</pre>",
            parse_mode="HTML"
        )

    async def handle_code_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data or ""

        if data.startswith("code_save:"):
            user_id = int(data.split(":")[1])
            await self._save_code(update.effective_message, user_id)

        elif data.startswith("code_rerun:"):
            user_id = int(data.split(":")[1])
            await self._rerun_code(update.effective_message, user_id)


def _escape_html(text: str) -> str:
    import html
    return html.escape(text)
