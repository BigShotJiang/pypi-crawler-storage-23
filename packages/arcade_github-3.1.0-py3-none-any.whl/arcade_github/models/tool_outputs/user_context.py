from typing_extensions import TypedDict


class UserProfileData(TypedDict, total=False):
    """Core user profile information."""

    login: str
    """GitHub username."""

    name: str
    """Display name."""

    email: str
    """Primary email address."""

    id: int
    """Unique user identifier."""

    html_url: str
    """GitHub profile URL."""

    avatar_url: str
    """Profile avatar URL."""

    bio: str
    """User biography."""

    company: str
    """Company name."""

    location: str
    """Location."""

    blog: str
    """Blog/website URL."""

    twitter_username: str
    """Twitter username."""

    created_at: str
    """ISO 8601 account creation date."""

    type: str
    """Account type (User/Organization)."""


class RepositorySummary(TypedDict, total=False):
    """Summary of a repository."""

    name: str
    """Repository name."""

    full_name: str
    """Full repository name (owner/repo)."""

    html_url: str
    """GitHub web URL."""

    description: str
    """Repository description."""

    updated_at: str
    """ISO 8601 last update timestamp."""

    stargazers_count: int
    """Number of stars."""

    language: str
    """Primary programming language."""

    private: bool
    """Whether repository is private."""


class OrganizationMembership(TypedDict, total=False):
    """Organization membership information."""

    login: str
    """Organization name."""

    html_url: str
    """Organization URL."""

    description: str
    """Organization description (truncated to 100 chars)."""


class TeamMembership(TypedDict, total=False):
    """Team membership information."""

    name: str
    """Team name."""

    slug: str
    """Team slug."""

    organization: str
    """Organization name."""

    description: str
    """Team description."""

    privacy: str
    """Privacy setting (closed/secret)."""

    permission: str
    """Permission level (pull/push/admin)."""

    html_url: str
    """Team URL."""


class PullRequestSummary(TypedDict, total=False):
    """Summary of a pull request."""

    number: int
    """Pull request number."""

    title: str
    """Pull request title."""

    repository: str
    """Repository name (owner/repo)."""

    state: str
    """State (open/closed/merged)."""

    created_at: str
    """Creation timestamp."""

    updated_at: str
    """Last update timestamp."""

    html_url: str
    """Web URL."""

    draft: bool
    """Whether PR is a draft."""


class IssueSummary(TypedDict, total=False):
    """Summary of an issue."""

    number: int
    """Issue number."""

    title: str
    """Issue title."""

    repository: str
    """Repository name (owner/repo)."""

    state: str
    """State (open/closed)."""

    created_at: str
    """Creation timestamp."""

    updated_at: str
    """Last update timestamp."""

    html_url: str
    """Web URL."""


class CommitSummary(TypedDict, total=False):
    """Summary of a commit."""

    sha: str
    """Commit SHA."""

    message: str
    """Commit message (truncated)."""

    repository: str
    """Repository name (owner/repo)."""

    date: str
    """Commit date."""

    html_url: str
    """Web URL."""


class WhoAmIOutput(TypedDict, total=False):
    """Output for who_am_i tool."""

    profile: UserProfileData
    """User profile information."""

    organizations: dict
    """Organization memberships."""

    teams: dict
    """Team memberships."""


class RecentActivityOutput(TypedDict, total=False):
    """Output for get_user_recent_activity tool."""

    recent_pull_requests: list[PullRequestSummary]
    """List of pull requests created by the user."""

    recent_merged_pull_requests: list[PullRequestSummary]
    """List of pull requests merged by the user."""

    recent_reviewed_pull_requests: list[PullRequestSummary]
    """List of pull requests reviewed by the user."""

    recent_pull_requests_count: int
    """Count of recent pull requests created."""

    recent_issues: list[IssueSummary]
    """List of issues created by the user."""

    recent_issues_count: int
    """Count of recent issues created."""

    recent_commits: list[CommitSummary]
    """List of recent commits by the user."""

    days_searched: int
    """Number of days looked back."""


class OpenItemsOutput(TypedDict, total=False):
    """Output for get_user_open_items tool."""

    open_pull_requests: list[PullRequestSummary]
    """List of open pull requests."""

    open_pull_requests_count: int
    """Count of open pull requests."""

    open_issues: list[IssueSummary]
    """List of open issues."""

    open_issues_count: int
    """Count of open issues."""
