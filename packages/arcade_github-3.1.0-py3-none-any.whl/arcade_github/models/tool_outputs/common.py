from typing_extensions import TypedDict


class PaginationInfo(TypedDict, total=False):
    """Pagination information for paginated responses."""

    page: int
    """Current page number."""

    per_page: int
    """Items per page."""

    total_count: int
    """Total number of items available."""

    has_next_page: bool
    """Whether more pages are available."""
