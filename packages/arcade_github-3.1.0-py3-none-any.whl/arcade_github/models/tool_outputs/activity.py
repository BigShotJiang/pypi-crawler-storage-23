from typing_extensions import TypedDict

from arcade_github.models.tool_outputs.common import PaginationInfo


class StargazerData(TypedDict, total=False):
    """Individual stargazer information."""

    login: str
    """GitHub username of the stargazer."""

    id: int
    """Unique identifier for the user."""

    node_id: str
    """Global node ID for GraphQL API."""

    html_url: str
    """GitHub profile URL."""


class StargazersListOutput(TypedDict, total=False):
    """Output for list_stargazers tool with pagination."""

    stargazers: list[StargazerData]
    """List of stargazer information for the current page."""

    pagination: PaginationInfo
    """Pagination information."""


class SetStarredOutput(TypedDict, total=False):
    """Output for set_starred tool."""

    starred: bool
    """Whether the repository is now starred."""

    repository: str
    """The full name of the repository (owner/name)."""

    message: str
    """Confirmation message."""
