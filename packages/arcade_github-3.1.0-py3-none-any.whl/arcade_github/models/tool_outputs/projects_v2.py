from typing import Any

from typing_extensions import TypedDict


class ProjectData(TypedDict, total=False):
    """GitHub Project V2 data for tool responses."""

    id: int
    """Project ID."""

    number: int
    """Project number."""

    title: str
    """Project title."""

    description: str | None
    """Project description."""

    state: str
    """Project state (open, closed)."""

    public: bool
    """Whether the project is public."""

    html_url: str
    """GitHub web URL for the project."""

    created_at: str
    """ISO 8601 timestamp when project was created."""

    updated_at: str
    """ISO 8601 timestamp when project was last updated."""

    scope_type: str
    """Scope where project lives (organization, user)."""

    owner: str | None
    """Owner identifier (org name or username)."""

    confidence: float | None
    """Match confidence when located via fuzzy search."""


class ProjectsSummary(TypedDict, total=False):
    """Summary information for project searches."""

    total_count: str
    """Total number of projects returned."""

    projects_returned: int
    """Number of projects in this response."""


class ProjectSearchSuggestion(TypedDict, total=False):
    """Suggested project when fuzzy matching falls back."""

    number: int | None
    """Project number."""

    title: str | None
    """Project title."""

    scope_type: str | None
    """Scope where project was found."""

    owner: str | None
    """Owner identifier."""

    confidence: float
    """Similarity score for the suggestion."""


class PaginationInfo(TypedDict, total=False):
    """Pagination information for cursor-based pagination."""

    has_next_page: bool
    """Whether more pages are available."""

    has_prev_page: bool
    """Whether previous pages are available."""

    next_cursor: str | None
    """Cursor for the next page (pass to cursor parameter)."""

    prev_cursor: str | None
    """Cursor for the previous page."""


class ProjectsSearchOutput(TypedDict, total=False):
    """Output payload for project search."""

    matched_project: ProjectData | None
    """First/best matched project."""

    summary: ProjectsSummary
    """Aggregated project counts."""

    projects: list[ProjectData]
    """Projects returned for the request."""

    pagination: PaginationInfo
    """Pagination information."""

    suggestions: list[ProjectSearchSuggestion]
    """Alternative projects recommended when fuzzy search is used."""


class ProjectItemData(TypedDict, total=False):
    """GitHub Project V2 item data."""

    id: int
    """Item ID."""

    title: str
    """Item title."""

    content_type: str
    """Type of content (Issue, PullRequest, DraftIssue)."""

    content_url: str | None
    """URL of the linked issue or pull request."""

    field_values: dict[str, Any]
    """Field values for the item."""

    project_number: int
    """Parent project number."""

    project_title: str | None
    """Parent project title."""

    created_at: str
    """ISO 8601 timestamp when item was created."""

    updated_at: str
    """ISO 8601 timestamp when item was last updated."""

    confidence: float | None
    """Match confidence when located via fuzzy search."""


class ProjectItemsSummary(TypedDict, total=False):
    """Summary information for project items."""

    total_count: str
    """Total count (may be 'not available' for V2)."""

    items_returned: int
    """Number of items in this response."""

    is_partial: bool
    """True if item collection was capped at MAX_SUMMARY_ITEMS limit."""

    content_type_breakdown: dict[str, int]
    """Item counts grouped by content type."""


class ProjectItemsListOutput(TypedDict, total=False):
    """Output payload for project item listings."""

    project_number: int
    """Parent project number."""

    project_title: str | None
    """Parent project title."""

    summary: ProjectItemsSummary
    """Summary of the item listing."""

    items: list[ProjectItemData]
    """Items matching the request."""

    pagination: PaginationInfo
    """Pagination information."""


class ProjectItemSearchOutput(TypedDict, total=False):
    """Output payload for item search."""

    matched_item: ProjectItemData | None
    """Matched item or None if no confident match."""

    suggestions: list[ProjectItemData]
    """Alternative items when threshold not met."""


class ProjectItemUpdateOutput(TypedDict, total=False):
    """Output payload for item field updates."""

    item: ProjectItemData
    """Updated item with new field values."""

    updated_fields: list[str]
    """Names of fields that were updated."""


class ProjectFieldOption(TypedDict, total=False):
    """Option for select or iteration field."""

    id: str
    """Option ID."""

    name: str
    """Option name."""

    description: str | None
    """Option description."""


class ProjectFieldData(TypedDict, total=False):
    """Project field metadata."""

    id: int
    """Field ID."""

    name: str
    """Field name."""

    type: str
    """Field type (text, number, date, single_select, iteration)."""

    options: list[ProjectFieldOption]
    """Available options for select/iteration fields."""


class ProjectFieldsListOutput(TypedDict, total=False):
    """Output for list_project_fields tool."""

    project_number: int
    """Parent project number."""

    project_title: str | None
    """Parent project title."""

    fields: list[ProjectFieldData]
    """Project fields."""

    summary: dict[str, int]
    """Count of fields by type."""
