from typing_extensions import TypedDict

from arcade_github.models.tool_outputs.common import PaginationInfo


class RecentBranchData(TypedDict, total=False):
    """Recent branch metadata."""

    name: str
    """Branch name."""

    commit_sha: str
    """Latest commit SHA on the branch."""

    committed_at: str
    """ISO 8601 timestamp of the latest commit."""

    committer: str | None
    """Name of the committer for the latest commit."""


class RepositoryOutput(TypedDict, total=False):
    """Cleaned repository data for tool responses."""

    name: str
    """Repository name."""

    full_name: str
    """Full repository name (owner/repo)."""

    html_url: str
    """GitHub web URL for the repository."""

    description: str
    """Repository description."""

    clone_url: str
    """Git clone URL."""

    private: bool
    """Whether the repository is private."""

    created_at: str
    """ISO 8601 timestamp when repository was created."""

    updated_at: str
    """ISO 8601 timestamp when repository was last updated."""

    pushed_at: str
    """ISO 8601 timestamp of last push."""

    stargazers_count: int
    """Number of stars."""

    watchers_count: int
    """Number of watchers."""

    forks_count: int
    """Number of forks."""

    recent_branches: list[RecentBranchData]
    """Recent branches for this repository (when requested)."""


class RepoSearchOutput(TypedDict, total=False):
    """Output for search_my_repos tool."""

    matched_repository: RepositoryOutput | None
    """Best match when confidence meets threshold."""

    suggestions: list[RepositoryOutput]
    """Ordered repository suggestions."""

    confidence: float
    """Confidence score for the best match."""

    sources_searched: list[str]
    """Sources searched e.g. user:jottakka, organization:github."""

    total_repos_searched: int
    """Total repositories evaluated."""

    search_scope: str
    """Scope used for the search."""


class RepositoriesListOutput(TypedDict, total=False):
    """Output for list_org_repositories tool."""

    repositories: list[RepositoryOutput]
    """List of repositories."""


class ActivityData(TypedDict, total=False):
    """Individual repository activity data."""

    id: int
    """Unique identifier for the activity."""

    node_id: str
    """Global node ID."""

    before: str
    """SHA before the activity."""

    after: str
    """SHA after the activity."""

    ref: str
    """Git ref involved in the activity."""

    timestamp: str
    """ISO 8601 timestamp of the activity."""

    activity_type: str
    """Type of activity (push, force_push, branch_creation, etc.)."""

    actor: str
    """Login of the user who performed the activity."""


class ActivitiesListOutput(TypedDict, total=False):
    """Output for list_repository_activities tool."""

    activities: list[ActivityData]
    """List of repository activities."""


class ReviewCommentData(TypedDict, total=False):
    """Individual review comment data."""

    id: int
    """Unique identifier for the comment."""

    url: str
    """API URL for the comment."""

    diff_hunk: str
    """Diff hunk the comment is about."""

    path: str
    """File path the comment is on."""

    position: int
    """Position in the diff."""

    original_position: int
    """Original position in the diff."""

    commit_id: str
    """SHA of the commit the comment is on."""

    original_commit_id: str
    """SHA of the original commit."""

    in_reply_to_id: int
    """ID of the comment this is replying to."""

    user: str
    """Login of the user who created the comment."""

    body: str
    """Content of the comment."""

    created_at: str
    """ISO 8601 timestamp when comment was created."""

    updated_at: str
    """ISO 8601 timestamp when comment was last updated."""

    html_url: str
    """GitHub web URL for the comment."""

    line: int
    """Line number the comment is on."""

    side: str
    """Side of the diff (LEFT or RIGHT)."""

    pull_request_url: str
    """API URL of the associated pull request."""


class ReviewCommentsOutput(TypedDict, total=False):
    """Output for list_review_comments_in_a_repository tool."""

    review_comments: list[ReviewCommentData]
    """List of review comments."""


class CollaboratorOutput(TypedDict, total=False):
    """Details about a repository collaborator."""

    login: str
    """GitHub username."""

    id: int
    """User ID."""

    name: str
    """User's real name (enriched from profile)."""

    email: str
    """User's email address (enriched from profile)."""

    type: str
    """User type (User, Bot, etc.)."""

    site_admin: bool
    """Whether user is a GitHub site admin."""

    permissions: dict[str, bool]
    """Repository permissions (admin, maintain, push, triage, pull)."""

    role_name: str
    """Custom repository role name if applicable."""


class TeamOutput(TypedDict, total=False):
    """Details about a repository team."""

    id: int
    """Team ID."""

    slug: str
    """Team slug (identifier for requesting reviews)."""

    name: str
    """Team display name."""

    description: str
    """Team description."""

    privacy: str
    """Team privacy (secret or closed)."""

    permission: str
    """Team permission level on repository."""

    members_count: int
    """Number of team members."""

    html_url: str
    """GitHub web URL for the team."""


class CollaboratorsListOutput(TypedDict, total=False):
    """Output for list_repository_collaborators tool."""

    collaborators: list[CollaboratorOutput]
    """List of repository collaborators who can review PRs."""

    teams: list[TeamOutput]
    """List of teams that can review PRs (when include_teams=True)."""

    total_collaborators: int
    """Number of individual collaborators returned."""

    total_teams: int
    """Number of teams returned (when include_teams=True)."""

    teams_error: str
    """Error message if teams fetch failed (when include_teams=True)."""

    org_members_error: str
    """Error message if org members fetch failed (when include_org_members=True)."""

    pagination: PaginationInfo
    """Pagination information for collaborators."""
