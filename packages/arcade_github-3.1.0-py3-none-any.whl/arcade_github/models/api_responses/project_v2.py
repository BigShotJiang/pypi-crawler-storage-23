from typing import Any

from typing_extensions import TypedDict


class ProjectV2Response(TypedDict, total=False):
    """GitHub Projects V2 API response."""

    id: int
    number: int
    node_id: str
    title: str
    description: str | None
    short_description: str | None
    state: str
    public: bool
    owner: dict[str, Any]
    creator: dict[str, Any]
    created_at: str
    updated_at: str
    closed_at: str | None
    deleted_at: str | None
    deleted_by: dict[str, Any] | None
    is_template: bool
    latest_status_update: dict[str, Any] | None


class ProjectV2ItemResponse(TypedDict, total=False):
    """GitHub Projects V2 item API response."""

    id: int
    node_id: str
    content: dict[str, Any] | None
    content_type: str
    field_values: dict[str, Any]
    created_at: str
    updated_at: str
    archived_at: str | None
    creator: dict[str, Any]


class ProjectV2FieldResponse(TypedDict, total=False):
    """GitHub Projects V2 field API response."""

    id: str
    node_id: str
    name: str
    data_type: str
    options: list[dict[str, Any]]
    created_at: str
    updated_at: str
