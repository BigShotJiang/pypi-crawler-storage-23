from typing import Any

from typing_extensions import TypedDict


class UserResponse(TypedDict, total=False):
    login: str
    id: int
    node_id: str
    avatar_url: str
    html_url: str
    name: str
    email: str
    bio: str
    company: str
    location: str
    blog: str
    twitter_username: str
    public_repos: int
    public_gists: int
    followers: int
    following: int
    created_at: str
    updated_at: str
    private_gists: int
    total_private_repos: int
    owned_private_repos: int
    disk_usage: int
    collaborators: int
    two_factor_authentication: bool
    type: str


class OrganizationResponse(TypedDict, total=False):
    login: str
    id: int
    node_id: str
    url: str
    repos_url: str
    events_url: str
    hooks_url: str
    issues_url: str
    members_url: str
    public_members_url: str
    avatar_url: str
    description: str
    html_url: str


class TeamResponse(TypedDict, total=False):
    id: int
    node_id: str
    name: str
    slug: str
    description: str
    privacy: str
    permission: str
    url: str
    html_url: str
    members_url: str
    repositories_url: str
    parent: dict[str, Any] | None
    organization: dict[str, Any]


class SearchResultResponse(TypedDict, total=False):
    total_count: int
    incomplete_results: bool
    items: list[dict[str, Any]]
