from typing import Any, cast

import httpx
from arcade_tdk.errors import RetryableToolError

from arcade_github.utils.github_api_client import GitHubAPIClient


async def validate_branch_exists(
    client: GitHubAPIClient, owner: str, repo: str, branch: str, branch_type: str
) -> None:
    try:
        await client.get_branch(owner, repo, branch)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            message = f"The {branch_type} branch '{branch}' does not exist in {owner}/{repo}."
            raise RetryableToolError(
                message=message,
                additional_prompt_content=(
                    f"Please verify the {branch_type} branch name. "
                    "You may want to list available branches first."
                ),
            )
        raise


async def validate_issue_exists(
    client: GitHubAPIClient, owner: str, repo: str, issue_number: int
) -> None:
    try:
        await client.get_repository_issue(owner, repo, issue_number)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            message = f"Issue #{issue_number} does not exist in {owner}/{repo}."
            raise RetryableToolError(
                message=message,
                additional_prompt_content=(
                    "Please verify the issue number. You may want to list issues first to find "
                    "the correct issue number."
                ),
            )
        raise


def format_auto_link_body(body: str | None, issue: int | None) -> str | None:
    if issue is None:
        return body

    link_text = f"Closes #{issue}"

    if body:
        return f"{link_text}\n\n{body}"

    return link_text


def interpret_mergeable_state(mergeable_state: str) -> tuple[str, list[str]]:
    status_map = {
        "clean": ("merged", []),
        "unstable": ("checks_failed", ["Some status checks have not completed or have failed"]),
        "dirty": ("conflict", ["This pull request has merge conflicts that must be resolved"]),
        "blocked": (
            "blocked",
            ["Pull request is blocked by required status checks or review requirements"],
        ),
        "behind": ("behind", ["Pull request branch is out of date with the base branch"]),
        "unknown": ("unknown", ["GitHub is still computing merge status, please try again"]),
    }

    result = status_map.get(mergeable_state, ("unknown", [f"Unknown state: {mergeable_state}"]))
    status, reasons = cast(tuple[str, list[str]], result)
    return status, reasons


def _process_legacy_statuses(
    statuses: list[dict[str, Any]],
) -> tuple[int, int, int, int, list[str]]:
    total = len(statuses)
    passed = 0
    failed = 0
    pending = 0
    failed_names = []

    for status in statuses:
        state = status.get("state", "")
        if state == "success":
            passed += 1
        elif state in ["failure", "error"]:
            failed += 1
            failed_names.append(status.get("context", "Unknown check"))
        else:
            pending += 1

    return total, passed, failed, pending, failed_names


def build_check_details(
    combined_status: dict[str, Any], check_runs: dict[str, Any]
) -> list[dict[str, Any]]:
    """
    Build detailed check information from combined status and check runs.

    Returns a list of check details with name, status, conclusion, and URL.
    """
    checks_details = []

    for status in combined_status.get("statuses", []):
        checks_details.append({
            "name": status.get("context", ""),
            "status": "completed",
            "conclusion": status.get("state", ""),
            "html_url": status.get("target_url", ""),
        })

    for check_run in check_runs.get("check_runs", []):
        checks_details.append({
            "name": check_run.get("name", ""),
            "status": check_run.get("status", ""),
            "conclusion": check_run.get("conclusion", ""),
            "html_url": check_run.get("html_url", ""),
        })

    return checks_details


def _process_check_runs(check_runs: list[dict[str, Any]]) -> tuple[int, int, int, int, list[str]]:
    total = len(check_runs)
    passed = 0
    failed = 0
    pending = 0
    failed_names = []

    for check_run in check_runs:
        conclusion = check_run.get("conclusion", "")
        if conclusion == "success":
            passed += 1
        elif conclusion in ["failure", "cancelled", "timed_out"]:
            failed += 1
            failed_names.append(check_run.get("name", "Unknown check"))
        elif conclusion in ["skipped", "neutral"]:
            passed += 1
        else:
            pending += 1

    return total, passed, failed, pending, failed_names


def _determine_conclusion(total: int, passed: int, failed: int, pending: int) -> str:
    if failed > 0:
        return "failure"
    if pending > 0:
        return "pending"
    if total > 0:
        return "success"
    return "none"


def aggregate_check_status(
    combined_status: dict[str, Any], check_runs: dict[str, Any]
) -> tuple[dict[str, Any], list[str]]:
    checks_summary: dict[str, Any] = {
        "total": 0,
        "passed": 0,
        "failed": 0,
        "pending": 0,
        "conclusion": "pending",
    }
    failed_check_names = []

    statuses = combined_status.get("statuses", [])
    if statuses:
        total, passed, failed, pending, names = _process_legacy_statuses(statuses)
        checks_summary["total"] = cast(int, checks_summary["total"]) + total
        checks_summary["passed"] = cast(int, checks_summary["passed"]) + passed
        checks_summary["failed"] = cast(int, checks_summary["failed"]) + failed
        checks_summary["pending"] = cast(int, checks_summary["pending"]) + pending
        failed_check_names.extend(names)

    check_run_items = check_runs.get("check_runs", [])
    if check_run_items:
        total, passed, failed, pending, names = _process_check_runs(check_run_items)
        checks_summary["total"] = cast(int, checks_summary["total"]) + total
        checks_summary["passed"] = cast(int, checks_summary["passed"]) + passed
        checks_summary["failed"] = cast(int, checks_summary["failed"]) + failed
        checks_summary["pending"] = cast(int, checks_summary["pending"]) + pending
        failed_check_names.extend(names)

    checks_summary["conclusion"] = _determine_conclusion(
        cast(int, checks_summary["total"]),
        cast(int, checks_summary["passed"]),
        cast(int, checks_summary["failed"]),
        cast(int, checks_summary["pending"]),
    )

    return checks_summary, failed_check_names


def format_blocking_reasons(
    mergeable: bool | None,
    mergeable_state: str,
    checks_summary: dict[str, Any],
    failed_checks: list[str],
    reviews_summary: dict[str, Any],
) -> list[str]:
    reasons = []

    if mergeable is None:
        reasons.append("GitHub is still computing merge status, please check again in a moment")
        return reasons

    if not mergeable:
        _, state_reasons = interpret_mergeable_state(mergeable_state)
        reasons.extend(state_reasons)

    if checks_summary.get("failed", 0) > 0:
        if failed_checks:
            check_list = ", ".join(failed_checks[:5])
            if len(failed_checks) > 5:
                check_list += f" and {len(failed_checks) - 5} more"
            reasons.append(f"Status checks failing: {check_list}")
        else:
            reasons.append(f"{checks_summary['failed']} status check(s) are failing")

    if checks_summary.get("pending", 0) > 0:
        reasons.append(f"{checks_summary['pending']} status check(s) are still pending")

    required_approvals = reviews_summary.get("required_approvals")
    approved_count = reviews_summary.get("approved_count", 0)
    if required_approvals and approved_count < required_approvals:
        reasons.append(
            f"Requires {required_approvals} approving review(s), currently has {approved_count}"
        )

    if reviews_summary.get("changes_requested_count", 0) > 0:
        reasons.append(
            f"{reviews_summary['changes_requested_count']} review(s) have requested changes"
        )

    return reasons


def suggest_actions(blocking_reasons: list[str], mergeable_state: str) -> list[str]:
    actions = []

    for reason in blocking_reasons:
        if "conflict" in reason.lower():
            actions.append("Resolve merge conflicts locally and push changes")
        elif "behind" in reason.lower() or "out of date" in reason.lower():
            actions.append("Update PR branch with latest changes from base branch")
        elif "status check" in reason.lower() and "failing" in reason.lower():
            actions.append("Review failed check logs and fix the issues")
        elif "pending" in reason.lower():
            actions.append("Wait for pending checks to complete")
        elif "review" in reason.lower() and "requires" in reason.lower():
            actions.append("Request reviews from code owners or team members")
        elif "changes" in reason.lower() and "requested" in reason.lower():
            actions.append("Address the requested changes and push updates")

    if not actions and mergeable_state == "clean":
        actions.append("PR is ready to merge")

    return actions


def extract_reviews_summary(pr_data: dict[str, Any]) -> dict[str, Any]:
    """
    Extract review approval status from PR data.

    Note: Reviews data must be fetched separately as it's not included
    in the standard PR endpoint response. If reviews data is not present,
    returns default values indicating no review data available.
    """
    reviews = pr_data.get("reviews", [])

    if not reviews:
        return {
            "approved_count": 0,
            "changes_requested_count": 0,
            "required_approvals": None,
            "requirements_met": True,
        }

    latest_reviews: dict[str, dict[str, Any]] = {}
    for review in reviews:
        user_data = review.get("user", {})
        if not isinstance(user_data, dict):
            continue
        user = user_data.get("login")
        state = review.get("state", "")
        submitted_at = review.get("submitted_at", "")

        if not user:
            continue

        if user not in latest_reviews or (
            submitted_at and submitted_at > latest_reviews.get(user, {}).get("submitted_at", "")
        ):
            latest_reviews[user] = {
                "state": state,
                "submitted_at": submitted_at,
            }

    approved_count = sum(
        1 for review in latest_reviews.values() if review.get("state") == "APPROVED"
    )
    changes_requested_count = sum(
        1 for review in latest_reviews.values() if review.get("state") == "CHANGES_REQUESTED"
    )

    requirements_met = approved_count > 0 and changes_requested_count == 0

    return {
        "approved_count": approved_count,
        "changes_requested_count": changes_requested_count,
        "required_approvals": None,
        "requirements_met": requirements_met,
    }


async def delete_branch_after_merge(
    client: GitHubAPIClient, owner: str, repo: str, branch_name: str
) -> tuple[bool, str | None]:
    """
    Delete a branch after successful merge.

    Returns tuple of (success: bool, error_message: str | None).
    """
    if not branch_name:
        return False, "Branch name is empty"

    try:
        await client.delete_git_ref(owner, repo, f"heads/{branch_name}")
    except Exception as e:
        return False, f"Failed to delete branch: {e!s}"
    else:
        return True, None


async def validate_no_existing_pr(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    head: str,
    base: str,
) -> None:
    """
    Check if an open PR already exists between head and base branches.

    Raises RetryableToolError if duplicate found.
    """
    try:
        formatted_head = head if ":" in head else f"{owner}:{head}"
        existing_prs = await client.list_repository_pull_requests(
            owner=owner,
            repo=repo,
            state="open",
            head=formatted_head,
            base=base,
            per_page=1,
        )

        if existing_prs:
            pr_number = existing_prs[0].get("number")
            pr_url = existing_prs[0].get("html_url")
            message = (
                f"An open pull request already exists from '{head}' to '{base}' (PR #{pr_number})."
            )
            raise RetryableToolError(
                message=message,
                additional_prompt_content=(
                    f"A pull request already exists between these branches. "
                    f"See: {pr_url}\n"
                    "Consider updating the existing PR or closing it first."
                ),
            )
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            pass
        else:
            raise


async def validate_branches_have_commits(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    head: str,
    base: str,
) -> None:
    """
    Check if head branch has commits ahead of base branch.

    Raises RetryableToolError if no commits between branches.
    """
    try:
        comparison = await client.compare_commits(owner, repo, base, head)

        ahead_by = comparison.get("ahead_by", 0)
        behind_by = comparison.get("behind_by", 0)
        status = comparison.get("status", "")

        if status == "behind":
            message = (
                f"Cannot create pull request: Branch '{head}' is behind '{base}' by {behind_by} "
                f"commit(s). The head branch must be ahead of the base branch."
            )
            raise RetryableToolError(
                message=message,
                additional_prompt_content=(
                    "Update the head branch with the base branch first (merge or rebase), "
                    "or you may need to swap the head and base branches."
                ),
            )

        if ahead_by == 0 or status == "identical":
            message = (
                f"Cannot create pull request: No commits between '{base}' and '{head}'. "
                f"The branches are identical."
            )
            raise RetryableToolError(
                message=message,
                additional_prompt_content=(
                    "The head branch must have commits that the base branch doesn't have. "
                    "Make commits to the head branch first, or verify the correct branch names."
                ),
            )

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            message = "Could not compare branches. One of the branches might not exist."
            raise RetryableToolError(
                message=message,
                additional_prompt_content="Verify both branch names are correct.",
            ) from e


async def build_appended_body(
    client: GitHubAPIClient, owner: str, repo: str, pull_number: int, new_body: str
) -> str:
    """
    Build appended body by fetching current PR body and appending new content.

    Returns the combined body text with double newline separator.
    """
    current_pr = await client.get_pull_request(owner, repo, pull_number)
    current_body = current_pr.get("body") or ""

    if current_body:
        return f"{current_body}\n\n{new_body}"
    return new_body
