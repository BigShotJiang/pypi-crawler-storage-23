from arcade_tdk.auth import GitHub

from arcade_github.constants import USE_OAUTH_APP_AUTH


def get_github_auth(scopes: list[str] | None = None) -> GitHub:
    """
    Get GitHub authentication configuration.

    When USE_OAUTH_APP_AUTH is False (default), returns GitHub() without scopes
    for GitHub Apps compatibility. When True, returns GitHub(scopes=...) for
    OAuth Apps compatibility.

    Args:
        scopes: List of required scopes for OAuth Apps. Used only when
                USE_OAUTH_APP_AUTH is True.

    Returns:
        GitHub authentication configuration instance.
    """
    if USE_OAUTH_APP_AUTH:
        return GitHub(scopes=scopes or [])
    return GitHub()
