import logging
from typing import Any

from rapidfuzz import fuzz

from arcade_github.constants import (
    FUZZY_MATCH_THRESHOLD,
    PERFECT_MATCH_CONFIDENCE,
    USER_RESOLUTION_API_NAME_BASE_CONFIDENCE,
    USER_RESOLUTION_CONFIDENCE_DECREMENT,
    USER_RESOLUTION_MAX_SUGGESTIONS,
    USER_RESOLUTION_MIN_CONFIDENCE,
    USER_RESOLUTION_SCOPED_NAME_CONFIDENCE,
    USER_RESOLUTION_SCOPED_NAME_REMAINDER_CONFIDENCE,
    USER_RESOLUTION_SCOPED_PRIMARY_CONFIDENCE,
)
from arcade_github.utils.github_api_client import GitHubAPIClient

logger = logging.getLogger(__name__)


def _extract_email_prefix(text: str) -> str | None:
    """
    Extract the username part from an email address.

    Args:
        text: Potential email address (e.g., "francisco@arcade.dev")

    Returns:
        Email prefix without @ and domain (e.g., "francisco"), or None if not an email
    """
    if "@" in text:
        return text.split("@")[0].strip()
    return None


def fuzzy_match_users(
    query: str, users: list[dict[str, Any]], threshold: float = FUZZY_MATCH_THRESHOLD
) -> list[dict[str, Any]]:
    scored_users = []

    email_prefix = _extract_email_prefix(query)

    for user in users:
        login = user.get("login", "").lower()
        login_score = fuzz.ratio(query.lower(), login) / 100.0
        name_score = 0.0
        email_score = 0.0
        email_prefix_score = 0.0

        if user.get("name"):
            name_score = fuzz.ratio(query.lower(), user.get("name", "").lower()) / 100.0

        if user.get("email"):
            email_score = fuzz.ratio(query.lower(), user.get("email", "").lower()) / 100.0

        if email_prefix:
            email_prefix_score = fuzz.ratio(email_prefix.lower(), login) / 100.0

        max_score = max(login_score, name_score, email_score, email_prefix_score)

        match_method = "login"
        if max_score == email_score and email_score >= threshold:
            match_method = "email"
        elif max_score == email_prefix_score and email_prefix_score >= threshold:
            match_method = "email_prefix"
        elif max_score == name_score and name_score >= threshold:
            match_method = "name"

        if max_score >= threshold:
            user_with_score = user.copy()
            user_with_score["confidence_score"] = max_score
            user_with_score["match_method"] = match_method
            scored_users.append(user_with_score)

    scored_users.sort(key=lambda x: x["confidence_score"], reverse=True)

    return scored_users[:USER_RESOLUTION_MAX_SUGGESTIONS]


async def search_users_by_email(
    client: GitHubAPIClient, email: str, per_page: int = 30
) -> list[dict[str, Any]]:
    query = f"{email} in:email"
    result = await client.search_users(query, per_page=per_page)
    return result.get("items", [])


async def search_users_by_name(
    client: GitHubAPIClient, name: str, per_page: int = 30
) -> list[dict[str, Any]]:
    query = f"{name} in:fullname"
    result = await client.search_users(query, per_page=per_page)
    return result.get("items", [])


async def get_all_repository_users(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    include_org_members: bool = True,
    enrich_profiles: bool = False,
    max_enrich: int = 30,
    affiliation: str | None = None,
    permission: str | None = None,
    per_page: int = 100,
    page: int = 1,
) -> tuple[list[dict[str, Any]], str | None]:
    """
    Get all users who can be assigned to issues/PRs in a repository.

    IMPORTANT: When include_org_members=True, organization members are added
    without applying affiliation/permission filters, as GitHub's organization
    members endpoint does not support these filters. This means the returned
    list may include users who don't match the requested affiliation/permission
    criteria.

    Args:
        client: GitHub API client
        owner: Repository owner
        repo: Repository name
        include_org_members: Whether to include all org members (bypasses filters)
        enrich_profiles: Whether to enrich with full profile data (name, email)
        max_enrich: Maximum users to enrich (to limit API calls)
        affiliation: Filter for direct collaborators only (not applied to org members)
        permission: Filter for direct collaborators only (not applied to org members)
        per_page: Items per page for collaborators list
        page: Page number for collaborators list

    Returns:
        Tuple of (list of users, error message if org members failed)
    """
    org_members_error = None

    try:
        collaborators = await client.list_repository_collaborators(
            owner=owner,
            repo=repo,
            affiliation=affiliation,
            permission=permission,
            per_page=per_page,
            page=page,
        )
    except Exception as e:
        logger.warning(
            f"Failed to fetch collaborators for {owner}/{repo}: {e}. "
            "Returning empty list for fallback."
        )
        return [], None

    all_users = collaborators

    if include_org_members:
        try:
            org_members = await client.list_organization_members(org=owner, per_page=100)
            collaborator_logins = {c.get("login", "").lower() for c in collaborators}
            additional_members = [
                m for m in org_members if m.get("login", "").lower() not in collaborator_logins
            ]
            all_users = collaborators + additional_members
        except Exception as e:
            org_members_error = f"Could not fetch org members: {e!s}"

    if enrich_profiles and all_users:
        try:
            from arcade_github.utils.user_enrichment_utils import enrich_users_batch

            users_to_enrich = all_users[:max_enrich]
            enriched = await enrich_users_batch(client, users_to_enrich, max_concurrent=5)
            if len(all_users) > max_enrich:
                all_users = enriched + all_users[max_enrich:]
            else:
                all_users = enriched
        except Exception as e:
            logger.warning(f"Failed to enrich user profiles: {e}. Continuing without enrichment.")

    return all_users, org_members_error


async def get_repo_collaborators(
    client: GitHubAPIClient, owner: str, repo: str, include_org_members: bool = True
) -> list[dict[str, Any]]:
    """
    Get all users who can be assigned to issues/PRs in a repository.

    Args:
        client: GitHub API client
        owner: Repository owner
        repo: Repository name
        include_org_members: Whether to include all org members (default: True)

    Returns:
        List of users (collaborators + org members if requested)
    """
    users, _ = await get_all_repository_users(
        client, owner, repo, include_org_members=include_org_members, enrich_profiles=False
    )
    return users


async def get_org_members(client: GitHubAPIClient, org: str) -> list[dict[str, Any]]:
    try:
        return await client.list_organization_members(org, per_page=100)
    except Exception as e:
        logger.warning(
            f"Failed to fetch members for organization {org}: {e}. "
            "Returning empty list for fallback."
        )
        return []


async def resolve_user_by_username(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    username: str,
    match_threshold: float,
    auto_accept_confidence: float,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str]:
    from arcade_github.utils.user_enrichment_utils import enrich_users_batch

    collaborators = await get_repo_collaborators(client, owner, repo, include_org_members=True)

    exact_match = next(
        (u for u in collaborators if u.get("login", "").lower() == username.lower()), None
    )
    if exact_match:
        exact_match["confidence_score"] = PERFECT_MATCH_CONFIDENCE
        return exact_match, [], "collaborators"

    enriched_collaborators = await enrich_users_batch(client, collaborators[:30], max_concurrent=3)

    suggestions = fuzzy_match_users(username, enriched_collaborators, match_threshold)

    if suggestions and suggestions[0]["confidence_score"] >= auto_accept_confidence:
        return suggestions[0], suggestions[1:], "collaborators"

    return None, suggestions, "collaborators"


async def resolve_user_by_email(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    email: str,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str]:
    api_results = await search_users_by_email(client, email, per_page=30)

    if not api_results:
        return None, [], "collaborators"

    collaborators = await get_repo_collaborators(client, owner, repo, include_org_members=True)

    collaborator_logins = {c.get("login", "").lower() for c in collaborators}
    scoped_results = [u for u in api_results if u.get("login", "").lower() in collaborator_logins]

    if scoped_results:
        best_match = scoped_results[0]
        best_match["confidence_score"] = PERFECT_MATCH_CONFIDENCE
        return (
            best_match,
            _assign_confidence_scores(
                scoped_results[1:], USER_RESOLUTION_SCOPED_PRIMARY_CONFIDENCE
            ),
            "collaborators",
        )

    return None, [], "collaborators"


async def resolve_user_by_name(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    name: str,
    match_threshold: float,
    auto_accept_confidence: float,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str]:
    from arcade_github.utils.user_enrichment_utils import enrich_users_batch

    collaborators = await get_repo_collaborators(client, owner, repo, include_org_members=True)

    enriched_collaborators = await enrich_users_batch(client, collaborators[:30], max_concurrent=3)

    suggestions = fuzzy_match_users(name, enriched_collaborators, match_threshold)

    if suggestions and suggestions[0]["confidence_score"] >= auto_accept_confidence:
        return suggestions[0], suggestions[1:], "collaborators"

    api_results = await search_users_by_name(client, name, per_page=30)

    if api_results:
        collaborator_logins = {c.get("login", "").lower() for c in enriched_collaborators}
        scoped_results = [
            u for u in api_results if u.get("login", "").lower() in collaborator_logins
        ]

        if scoped_results:
            best_match = scoped_results[0]
            best_match["confidence_score"] = USER_RESOLUTION_SCOPED_NAME_CONFIDENCE
            if best_match["confidence_score"] >= auto_accept_confidence:
                remaining = _assign_confidence_scores(
                    scoped_results[1:], USER_RESOLUTION_SCOPED_NAME_REMAINDER_CONFIDENCE
                )
                return best_match, remaining + suggestions, "collaborators"

            enriched_scoped = _assign_confidence_scores(
                scoped_results[:USER_RESOLUTION_MAX_SUGGESTIONS],
                USER_RESOLUTION_API_NAME_BASE_CONFIDENCE,
            )
            return None, suggestions + enriched_scoped, "collaborators"

    return None, suggestions, "collaborators"


async def resolve_user(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    identifier: str,
    search_mode: str,
    match_threshold: float,
    auto_accept_confidence: float,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str]:
    if search_mode == "username":
        return await resolve_user_by_username(
            client, owner, repo, identifier, match_threshold, auto_accept_confidence
        )
    elif search_mode == "email":
        return await resolve_user_by_email(client, owner, repo, identifier)
    elif search_mode == "name":
        return await resolve_user_by_name(
            client, owner, repo, identifier, match_threshold, auto_accept_confidence
        )
    elif search_mode == "id":
        try:
            user_id = int(identifier)
            collaborators = await get_repo_collaborators(
                client, owner, repo, include_org_members=True
            )
            user = next((u for u in collaborators if u.get("id") == user_id), None)
        except ValueError:
            return None, [], "collaborators"
        else:
            if user:
                user["confidence_score"] = PERFECT_MATCH_CONFIDENCE
                return user, [], "collaborators"
            return None, [], "collaborators"

    return None, [], "unknown"


def map_user_to_data(user: dict[str, Any]) -> dict[str, Any]:
    return {
        "login": user.get("login", ""),
        "name": user.get("name"),
        "email": user.get("email"),
        "id": user.get("id"),
        "html_url": user.get("html_url", ""),
        "match_method": user.get("match_method"),
    }


def map_user_to_suggestion(user: dict[str, Any]) -> dict[str, Any]:
    return {
        "login": user.get("login", ""),
        "name": user.get("name"),
        "email": user.get("email"),
        "confidence_score": user.get("confidence_score", 0.0),
        "match_method": user.get("match_method"),
        "html_url": user.get("html_url", ""),
    }


def _assign_confidence_scores(
    users: list[dict[str, Any]],
    start_score: float,
    decrement: float = USER_RESOLUTION_CONFIDENCE_DECREMENT,
    min_score: float = USER_RESOLUTION_MIN_CONFIDENCE,
) -> list[dict[str, Any]]:
    enriched_users: list[dict[str, Any]] = []
    for index, user in enumerate(users):
        if "confidence_score" in user:
            enriched_users.append(user)
            continue

        user_copy = user.copy()
        user_copy["confidence_score"] = max(min_score, start_score - (index * decrement))
        enriched_users.append(user_copy)
    return enriched_users
