import asyncio
import logging
from typing import Any, cast

from arcade_github.utils.github_api_client import GitHubAPIClient

logger = logging.getLogger(__name__)


async def fetch_review_workload_issues(
    client: GitHubAPIClient,
    username: str,
    per_page: int = 50,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """
    Fetch pending and recently reviewed PRs for a user.

    Returns two lists: pending PRs and reviewed PRs.
    """

    pending_result, reviewed_result = cast(
        tuple[dict[str, Any] | Exception, dict[str, Any] | Exception],
        await asyncio.gather(
            client.search_issues(
                f"type:pr state:open review-requested:{username}", per_page=per_page
            ),
            client.search_issues(f"type:pr state:open reviewed-by:{username}", per_page=per_page),
            return_exceptions=True,
        ),
    )

    if isinstance(pending_result, Exception):
        logger.warning(f"Failed to fetch pending reviews for {username}: {pending_result}")
        pending_prs = []
    else:
        pending_prs = pending_result.get("items", [])

    if isinstance(reviewed_result, Exception):
        logger.warning(f"Failed to fetch reviewed PRs for {username}: {reviewed_result}")
        reviewed_prs = []
    else:
        reviewed_prs = reviewed_result.get("items", [])

    return pending_prs, reviewed_prs
