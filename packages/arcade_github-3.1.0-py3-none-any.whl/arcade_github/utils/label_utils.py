from typing import Any

from arcade_tdk.errors import RetryableToolError
from rapidfuzz import fuzz

from arcade_github.constants import FUZZY_MATCH_THRESHOLD
from arcade_github.utils.github_api_client import GitHubAPIClient


def fuzzy_match_labels(
    query: str, labels: list[dict[str, Any]], threshold: float = FUZZY_MATCH_THRESHOLD
) -> list[dict[str, Any]]:
    """
    Fuzzy match a label name against repository labels.

    Args:
        query: Label name to search for
        labels: List of label dictionaries from GitHub API
        threshold: Minimum confidence score (0.0-1.0)

    Returns:
        List of matching labels with confidence scores, sorted by score
    """
    scored_labels = []

    for label in labels:
        label_name = label.get("name", "")
        score = fuzz.ratio(query.lower(), label_name.lower()) / 100.0

        if score >= threshold:
            label_with_score = label.copy()
            label_with_score["confidence_score"] = score
            scored_labels.append(label_with_score)

    scored_labels.sort(key=lambda x: x["confidence_score"], reverse=True)
    return scored_labels[:5]


async def resolve_labels_with_fuzzy(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    label_names: list[str],
    auto_accept_confidence: float,
    match_threshold: float,
) -> tuple[list[str], dict[str, dict[str, Any]], dict[str, list[dict[str, Any]]]]:
    """
    Resolve label names with fuzzy matching against repository labels.

    Args:
        client: GitHub API client
        owner: Repository owner
        repo: Repository name
        label_names: List of label names to resolve
        auto_accept_confidence: Confidence threshold for auto-accepting matches
        match_threshold: Minimum confidence threshold for suggestions

    Returns:
        Tuple of:
        - List of resolved label names
        - Dict of fuzzy matches used {input: {matched: str, confidence: float}}
        - Dict of suggestions for unmatched {input: [suggestions]}
    """
    repo_labels_response = await client.list_repository_labels(owner, repo, per_page=100)
    repo_labels: list[dict[str, Any]] = [dict(label) for label in repo_labels_response]

    # Create case-insensitive lookup
    label_lookup = {label["name"].lower(): label["name"] for label in repo_labels}

    resolved_labels = []
    fuzzy_matches = {}
    suggestions = {}

    for label_name in label_names:
        # Exact match (case-insensitive)
        if label_name.lower() in label_lookup:
            resolved_name = label_lookup[label_name.lower()]
            resolved_labels.append(resolved_name)
            if resolved_name != label_name:
                fuzzy_matches[label_name] = {
                    "matched": resolved_name,
                    "confidence": 1.0,
                }
            continue

        # Fuzzy match
        matches = fuzzy_match_labels(label_name, repo_labels, match_threshold)

        if matches and matches[0]["confidence_score"] >= auto_accept_confidence:
            best_match = matches[0]
            resolved_labels.append(best_match["name"])
            fuzzy_matches[label_name] = {
                "matched": best_match["name"],
                "confidence": best_match["confidence_score"],
            }
        else:
            # Store suggestions for error message
            suggestions[label_name] = matches

    return resolved_labels, fuzzy_matches, suggestions


def format_label_suggestions_error(label_name: str, suggestions: list[dict[str, Any]]) -> str:
    """
    Format suggestions for a label that couldn't be matched.

    Args:
        label_name: The label name that wasn't found
        suggestions: List of suggested labels with confidence scores

    Returns:
        Formatted error message with suggestions
    """
    if not suggestions:
        return f"Label '{label_name}' not found in repository. No similar labels found."

    suggestion_strings = [f"{s['name']} ({s['confidence_score']:.2f})" for s in suggestions[:5]]
    suggestions_text = ", ".join(suggestion_strings)

    return (
        f"Label '{label_name}' not found in repository. "
        f"Did you mean: {suggestions_text}? "
        f"Set auto_accept_matches=True to automatically use high-confidence matches."
    )


def validate_and_raise_label_errors(
    suggestions_dict: dict[str, list[dict[str, Any]]],
) -> None:
    """
    Raise RetryableToolError if there are unresolved labels.

    Args:
        suggestions_dict: Dictionary of unresolved labels with their suggestions
    """
    if not suggestions_dict:
        return

    error_parts = []
    additional_prompt_parts = []

    for label_name, suggestions in suggestions_dict.items():
        error_parts.append(format_label_suggestions_error(label_name, suggestions))

        if suggestions:
            suggestion_names = [s["name"] for s in suggestions[:3]]
            additional_prompt_parts.append(
                f"For '{label_name}', consider using: {', '.join(suggestion_names)}"
            )

    message = " ".join(error_parts)
    additional_content = " ".join(additional_prompt_parts) if additional_prompt_parts else None

    raise RetryableToolError(
        message=message,
        additional_prompt_content=additional_content,
    )
