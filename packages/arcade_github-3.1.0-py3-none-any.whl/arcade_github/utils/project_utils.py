from typing import Any, NamedTuple, cast

from arcade_tdk.errors import RetryableToolError, ToolExecutionError
from rapidfuzz import fuzz

from arcade_github.constants import (
    FUZZY_AUTO_ACCEPT_CONFIDENCE,
    FUZZY_MATCH_THRESHOLD,
    PROJECT_MAX_SUGGESTIONS,
    PROJECT_SUGGESTION_THRESHOLD_MULTIPLIER,
)
from arcade_github.models.api_responses import ProjectV2ItemResponse, ProjectV2Response
from arcade_github.models.models import (
    ProjectItemLookupMode,
    ProjectLookupMode,
    ProjectScopeTarget,
)
from arcade_github.models.tool_outputs.projects_v2 import ProjectSearchSuggestion
from arcade_github.utils.github_api_client import GitHubAPIClient


class ProjectCandidate(NamedTuple):
    score: float
    project: ProjectV2Response
    scope_target: ProjectScopeTarget
    owner: str | None


class ItemCandidate(NamedTuple):
    score: float
    item: ProjectV2ItemResponse
    project_number: int


def build_query_filter(
    filter_assignee: str | None,
    filter_status: str | None,
    filter_labels: list[str] | None,
    filter_is_open: bool | None,
    advanced_query: str | None,
) -> str | None:
    """Build V2 query string from structured filters."""
    if advanced_query:
        return advanced_query

    parts = []
    if filter_assignee:
        parts.append(f"assignee:{filter_assignee}")
    if filter_status:
        escaped = filter_status.replace('"', '\\"')
        parts.append(f'status:"{escaped}"')
    if filter_labels:
        for label in filter_labels:
            parts.append(f"label:{label}")
    if filter_is_open is not None:
        parts.append("is:open" if filter_is_open else "is:closed")

    return " ".join(parts) if parts else None


async def _resolve_project_by_number(
    client: GitHubAPIClient,
    identifier: str,
    scope_target: ProjectScopeTarget,
    scope_identifier: str,
    query_filter: str | None,
) -> tuple[
    ProjectV2Response | None,
    ProjectScopeTarget | None,
    str | None,
    list[ProjectSearchSuggestion],
]:
    """Resolve project by number."""
    if not identifier or not identifier.strip():
        raise ToolExecutionError("Project identifier cannot be empty when using NUMBER lookup mode")

    if not identifier.strip().lstrip("-").isdigit():
        raise ToolExecutionError(
            f"Invalid project number: '{identifier}' is not a valid number. "
            "Use NAME lookup mode for text-based project names."
        )

    try:
        project_number = int(identifier)
        if scope_target == ProjectScopeTarget.ORGANIZATION:
            project = await client.get_project_v2("organization", scope_identifier, project_number)
            return project, ProjectScopeTarget.ORGANIZATION, scope_identifier, []
        elif scope_target == ProjectScopeTarget.USER:
            project = await client.get_project_v2("user", scope_identifier, project_number)
            return project, ProjectScopeTarget.USER, scope_identifier, []
        else:
            candidates = await _collect_project_v2_candidates(
                client, scope_target, scope_identifier, str(project_number), query_filter
            )
            for candidate in candidates:
                if candidate.project.get("number") == project_number:
                    return (
                        candidate.project,
                        candidate.scope_target,
                        candidate.owner,
                        [],
                    )
            raise ToolExecutionError(f"Project number {project_number} not found")
    except ValueError as e:
        raise ToolExecutionError(f"Invalid project number: {identifier}") from e


async def _resolve_project_by_name(
    client: GitHubAPIClient,
    identifier: str,
    scope_target: ProjectScopeTarget,
    scope_identifier: str,
    query_filter: str | None,
    auto_accept_confidence: float,
    require_match: bool,
) -> tuple[
    ProjectV2Response | None,
    ProjectScopeTarget | None,
    str | None,
    list[ProjectSearchSuggestion],
]:
    """Resolve project by fuzzy name matching."""
    candidates = await _collect_project_v2_candidates(
        client, scope_target, scope_identifier, identifier, query_filter
    )

    if not candidates:
        return None, None, None, []

    candidates.sort(key=lambda c: c.score, reverse=True)
    best_match = candidates[0]

    suggestions = _build_project_v2_suggestions(candidates, FUZZY_MATCH_THRESHOLD)

    if best_match.score >= auto_accept_confidence:
        return (
            best_match.project,
            best_match.scope_target,
            best_match.owner,
            suggestions,
        )

    if require_match:
        raise ToolExecutionError(
            f"No project matched '{identifier}' with confidence >= {auto_accept_confidence}. "
            f"Check suggestions and retry with exact project number."
        )

    return None, None, None, suggestions


async def resolve_project_v2(
    client: GitHubAPIClient,
    lookup_mode: ProjectLookupMode,
    identifier: str,
    scope_target: ProjectScopeTarget,
    scope_identifier: str,
    query_filter: str | None = None,
    auto_accept_confidence: float = FUZZY_AUTO_ACCEPT_CONFIDENCE,
    require_match: bool = False,
) -> tuple[
    ProjectV2Response | None,
    ProjectScopeTarget | None,
    str | None,
    list[ProjectSearchSuggestion],
]:
    """Resolve V2 project using NUMBER or fuzzy NAME matching."""
    if lookup_mode == ProjectLookupMode.NUMBER:
        return await _resolve_project_by_number(
            client, identifier, scope_target, scope_identifier, query_filter
        )

    return await _resolve_project_by_name(
        client,
        identifier,
        scope_target,
        scope_identifier,
        query_filter,
        auto_accept_confidence,
        require_match,
    )


async def collect_items_for_project(
    client: GitHubAPIClient,
    scope_target: ProjectScopeTarget,
    identifier: str,
    project_number: int,
    query_filter: str | None = None,
    max_items: int | None = None,
) -> tuple[list[ItemCandidate], bool]:
    """Collect items for a V2 project with optional limit."""
    items: list[ProjectV2ItemResponse] = []
    cursor: str | None = None
    is_partial = False

    scope_str = "organization" if scope_target == ProjectScopeTarget.ORGANIZATION else "user"

    while True:
        batch, next_cursor, _ = await client.list_project_v2_items(
            scope_target=scope_str,
            identifier=identifier,
            project_number=project_number,
            q=query_filter,
            after=cursor,
            per_page=100,
        )

        items.extend(batch)

        if max_items and len(items) >= max_items:
            items = items[:max_items]
            is_partial = True
            break

        if not next_cursor:
            break

        cursor = next_cursor

    candidates = [
        ItemCandidate(score=1.0, item=item, project_number=project_number) for item in items
    ]

    return candidates, is_partial


async def search_project_v2_item(
    client: GitHubAPIClient,
    scope_target: ProjectScopeTarget,
    identifier: str,
    project_number: int,
    item_lookup_mode: ProjectItemLookupMode,
    item_identifier: str,
    auto_accept_confidence: float = FUZZY_AUTO_ACCEPT_CONFIDENCE,
) -> tuple[ItemCandidate | None, list[ItemCandidate]]:
    """Search for a specific item in a V2 project."""
    all_items, _ = await collect_items_for_project(
        client, scope_target, identifier, project_number, max_items=None
    )

    if item_lookup_mode == ProjectItemLookupMode.ID:
        try:
            item_id = int(item_identifier)
        except ValueError:
            item_id = None

        for candidate in all_items:
            if (
                candidate.item.get("id") == item_id
                or str(candidate.item.get("id")) == item_identifier
            ):
                return candidate, []
        return None, all_items[:10]

    search_term = item_identifier.lower()
    scored_items = []
    for candidate in all_items:
        content = candidate.item.get("content") or {}
        title = content.get("title", "")
        if title:
            score = fuzz.ratio(search_term, title.lower()) / 100.0
            scored_items.append(
                ItemCandidate(score=score, item=candidate.item, project_number=project_number)
            )

    scored_items.sort(key=lambda c: c.score, reverse=True)

    if scored_items and scored_items[0].score >= auto_accept_confidence:
        return scored_items[0], scored_items[:10]

    return None, scored_items[:10]


async def _collect_project_v2_candidates(
    client: GitHubAPIClient,
    scope_target: ProjectScopeTarget,
    scope_identifier: str,
    search_term: str,
    api_query_filter: str | None = None,
) -> list[ProjectCandidate]:
    """Collect V2 project candidates from specified scopes."""
    candidates: list[ProjectCandidate] = []
    search_lower = search_term.lower()

    if scope_target in [ProjectScopeTarget.ORGANIZATION, ProjectScopeTarget.ALL]:
        projects, _, _ = await client.list_organization_projects_v2(
            org=scope_identifier, q=api_query_filter
        )
        for project in projects:
            title = project.get("title", "")
            score = fuzz.ratio(search_lower, title.lower()) / 100.0
            candidates.append(
                ProjectCandidate(
                    score=score,
                    project=project,
                    scope_target=ProjectScopeTarget.ORGANIZATION,
                    owner=scope_identifier,
                )
            )

    if scope_target in [ProjectScopeTarget.USER, ProjectScopeTarget.ALL]:
        projects, _, _ = await client.list_user_projects_v2(
            username=scope_identifier, q=api_query_filter
        )
        for project in projects:
            title = project.get("title", "")
            score = fuzz.ratio(search_lower, title.lower()) / 100.0
            candidates.append(
                ProjectCandidate(
                    score=score,
                    project=project,
                    scope_target=ProjectScopeTarget.USER,
                    owner=scope_identifier,
                )
            )

    return candidates


def _build_project_v2_suggestions(
    candidates: list[ProjectCandidate], threshold: float
) -> list[ProjectSearchSuggestion]:
    """Build search suggestions from project candidates."""
    suggestions: list[ProjectSearchSuggestion] = []
    for candidate in candidates[:PROJECT_MAX_SUGGESTIONS]:
        if candidate.score >= threshold * PROJECT_SUGGESTION_THRESHOLD_MULTIPLIER:
            suggestions.append(
                cast(
                    ProjectSearchSuggestion,
                    {
                        "number": candidate.project.get("number"),
                        "title": candidate.project.get("title"),
                        "scope_type": candidate.scope_target.value,
                        "owner": candidate.owner,
                        "confidence": round(candidate.score, 2),
                    },
                )
            )
    return suggestions


def clamp_per_page(per_page: int) -> int:
    """Clamp per_page value to valid range [1, 100]."""
    return max(1, min(per_page, 100))


def parse_numeric_identifier(identifier: str, label: str) -> int:
    """Parse a numeric identifier with helpful error messages."""
    try:
        return int(identifier)
    except ValueError as e:
        raise ToolExecutionError(f"Invalid {label}: '{identifier}' is not a number") from e


def find_field_by_name(fields: list[dict], name: str) -> dict | None:
    """Find field by name (case-insensitive)."""
    name_lower = name.lower()
    for field in fields:
        if field.get("name", "").lower() == name_lower:
            return field
    return None


def find_option_by_name(options: list[dict], name: str) -> dict | None:
    """Find option by name (case-insensitive)."""
    name_lower = name.lower()
    for option in options:
        if option.get("name", "").lower() == name_lower:
            return option
    return None


def _normalize_field_updates(
    field_updates: list[dict[str, str | int | bool | None]] | dict[str, Any],
) -> dict[str, Any]:
    """Convert field_updates to dict format regardless of input type."""
    if isinstance(field_updates, list):
        result: dict[str, Any] = {}
        for item in field_updates:
            field_name = item.get("field_name")
            if field_name and isinstance(field_name, str):
                result[field_name] = item.get("field_value")
        return result
    return field_updates


def build_field_updates_with_validation(
    fields: list[dict],
    field_updates: list[dict[str, str | int | bool | None]] | dict[str, Any],
) -> list[dict[str, Any]]:
    """
    Build API field updates with validation and helpful errors.

    Raises RetryableToolError if field name or option is invalid,
    including available options in the error message.
    """
    api_updates = []
    updates_dict = _normalize_field_updates(field_updates)

    for field_name, field_value in updates_dict.items():
        field = find_field_by_name(fields, field_name)
        if not field:
            available = [f.get("name") for f in fields if f.get("name")]
            available_str = ", ".join(str(name) for name in available if name is not None)
            raise RetryableToolError(
                message=f"Field '{field_name}' not found in project.",
                additional_prompt_content=f"Available fields: {available_str}",
            )

        field_id = field["id"]
        field_type = field["type"]

        if field_type in ["text", "number", "date"]:
            api_updates.append({"id": field_id, "value": field_value})

        elif field_type == "single_select":
            if field_value is None:
                api_updates.append({"id": field_id, "value": None})
            else:
                options = field.get("options", [])
                option = find_option_by_name(options, str(field_value))
                if not option:
                    available_options = [opt.get("name") for opt in options if opt.get("name")]
                    options_str = ", ".join(available_options)
                    raise RetryableToolError(
                        message=f"Option '{field_value}' not valid for field '{field_name}'.",
                        additional_prompt_content=f"Available options: {options_str}",
                    )
                api_updates.append({"id": field_id, "value": option["id"]})

        elif field_type == "iteration":
            if field_value is None:
                api_updates.append({"id": field_id, "value": None})
            else:
                iterations = field.get("configuration", {}).get("iterations", [])
                iteration = find_option_by_name(iterations, str(field_value))
                if not iteration:
                    available_iterations = [it.get("title") for it in iterations if it.get("title")]
                    iterations_str = ", ".join(available_iterations)
                    raise RetryableToolError(
                        message=f"Iteration '{field_value}' not valid for field '{field_name}'.",
                        additional_prompt_content=f"Available iterations: {iterations_str}",
                    )
                api_updates.append({"id": field_id, "value": iteration["id"]})

        else:
            raise ToolExecutionError(f"Field type '{field_type}' not yet supported")

    return api_updates
