"""Utilities for file content manipulation."""

DEFAULT_LINE_RANGE_SPAN = 20


class LineRangeError(ValueError):
    """Raised when a requested line range is invalid."""

    def __init__(self, message: str, additional_prompt: str | None = None) -> None:
        super().__init__(message)
        self.additional_prompt = additional_prompt


def replace_file_lines(
    file_content: str,
    start_line: int,
    end_line: int,
    new_content: str,
) -> tuple[str, int, int]:
    """
    Replace lines in file content preserving structure.

    Args:
        file_content: Original file content
        start_line: First line to replace (1-indexed, inclusive)
        end_line: Last line to replace (1-indexed, inclusive)
        new_content: Replacement text (newlines optional)

    Returns:
        Tuple of (updated_content, old_line_count, new_line_count)

    Raises:
        ValueError: If line range is invalid
    """
    existing_lines = file_content.splitlines()
    ends_with_newline = file_content.endswith("\n")

    if end_line > len(existing_lines):
        msg = (
            f"Line range {start_line}-{end_line} exceeds file length ({len(existing_lines)} lines)"
        )
        raise ValueError(msg)

    start_idx = start_line - 1
    end_idx = end_line
    old_segment = existing_lines[start_idx:end_idx]
    new_lines = new_content.splitlines() if new_content else []

    updated_lines = existing_lines[:start_idx] + new_lines + existing_lines[end_idx:]
    updated_content = "\n".join(updated_lines)
    if ends_with_newline and updated_content:
        updated_content += "\n"

    return updated_content, len(old_segment), len(new_lines)


def slice_content_with_line_range(
    content: str,
    start_line: int | None,
    end_line: int | None,
    default_span: int = DEFAULT_LINE_RANGE_SPAN,
) -> tuple[str, dict[str, int], list[str]]:
    """
    Slice decoded file content according to the requested line range.

    Returns:
        A tuple containing (selected_content, {"start": int, "end": int}, warnings).
    """
    lines = content.splitlines()
    total_lines = len(lines)
    range_warnings: list[str] = []

    effective_start = start_line
    if start_line is not None and start_line < 1:
        effective_start = 1
        range_warnings.append("start_line less than 1 detected. Defaulted to 1.")

    if effective_start is not None:
        max_start = max(1, total_lines)
        if effective_start > max_start:
            raise LineRangeError(
                f"start_line {effective_start} exceeds file length ({total_lines} lines).",
                f"Use values between 1 and {max_start}.",
            )

    effective_end = end_line
    if end_line is not None and end_line < 1:
        base_start = effective_start or 1
        effective_end = base_start + default_span - 1
        range_warnings.append(
            f"end_line less than 1 detected. Returning up to {default_span} lines from the start."
        )

    if effective_start and effective_end and effective_start > effective_end:
        raise LineRangeError(
            f"start_line {effective_start} must be <= end_line {effective_end}.",
            "Ensure start_line is less than or equal to end_line.",
        )

    start_idx = (effective_start - 1) if effective_start else 0
    end_idx = min(effective_end, total_lines) if effective_end is not None else total_lines

    selected_lines = lines[start_idx:end_idx]
    selected_content = "\n".join(selected_lines)
    line_range = {"start": effective_start or 1, "end": end_idx or 0}

    return selected_content, line_range, range_warnings


def validate_update_line_request(
    start_line: int,
    end_line: int,
    total_lines: int,
    append_mode: bool,
) -> None:
    """
    Validate the requested line range for update_file_lines operations.
    """
    if append_mode:
        if start_line != -1 or end_line != -1:
            raise LineRangeError(
                "When appending, both start_line and end_line must be -1.",
                "Set start_line=-1 and end_line=-1 to append.",
            )
        return

    if start_line < 1:
        raise LineRangeError("start_line must be >= 1.", "Provide valid line numbers.")

    if end_line < start_line:
        raise LineRangeError("end_line must be >= start_line.", "Adjust the line range.")

    max_hint = max(1, total_lines)
    if start_line > total_lines:
        raise LineRangeError(
            f"start_line {start_line} exceeds file length ({total_lines} lines).",
            f"Use values between 1 and {max_hint}.",
        )

    if end_line > total_lines:
        raise LineRangeError(
            f"end_line {end_line} exceeds file length ({total_lines} lines).",
            f"Use values between 1 and {max_hint}.",
        )
