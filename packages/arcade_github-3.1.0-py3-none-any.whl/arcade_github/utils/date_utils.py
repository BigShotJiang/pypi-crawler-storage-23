from datetime import datetime, timedelta, timezone

from arcade_github.models.models import RelativeDate


def parse_flexible_date(date_str: str) -> str:
    """
    Parse flexible date input and return ISO 8601 format in UTC.

    Supports:
    - Relative dates: "today", "yesterday", "last_week", "last_7_days", "last_30_days", "last_month"
    - ISO 8601: "2025-11-10T00:00:00Z"
    - Simple dates: "2025-11-10"

    Returns:
        ISO 8601 formatted datetime string in UTC (YYYY-MM-DDTHH:MM:SSZ)
    """
    if not date_str:
        return ""

    date_str_lower = date_str.lower().strip()

    now = datetime.now(timezone.utc)

    relative_dates = {
        RelativeDate.TODAY.value: now.replace(hour=0, minute=0, second=0, microsecond=0),
        RelativeDate.YESTERDAY.value: (now - timedelta(days=1)).replace(
            hour=0, minute=0, second=0, microsecond=0
        ),
        RelativeDate.LAST_WEEK.value: now - timedelta(days=7),
        RelativeDate.LAST_7_DAYS.value: now - timedelta(days=7),
        RelativeDate.LAST_30_DAYS.value: now - timedelta(days=30),
        RelativeDate.LAST_MONTH.value: now - timedelta(days=30),
    }

    if date_str_lower in relative_dates:
        dt = relative_dates[date_str_lower]
        return dt.strftime("%Y-%m-%dT%H:%M:%SZ")

    if "T" in date_str and "Z" in date_str:
        # Already has UTC timezone indicator, verify it's UTC
        try:
            dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
            if dt.tzinfo != timezone.utc:
                dt = dt.astimezone(timezone.utc)
            return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            return date_str

    if "T" in date_str:
        # Has time but no timezone - parse and ensure UTC
        try:
            dt = datetime.fromisoformat(date_str)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            else:
                dt = dt.astimezone(timezone.utc)
            return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            return f"{date_str}Z"

    try:
        # Simple date format - treat as UTC midnight
        dt = datetime.fromisoformat(date_str).replace(tzinfo=timezone.utc)
        return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        return date_str
