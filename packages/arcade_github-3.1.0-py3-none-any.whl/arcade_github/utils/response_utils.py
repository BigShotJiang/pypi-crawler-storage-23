from typing import TypeVar, cast

T = TypeVar("T")


def remove_none_values_recursive(data: T) -> T:
    """
    Recursively remove None values, empty lists, and empty dicts to save tokens.

    Removes:
    - None values
    - Empty lists []
    - Empty dicts {}

    Keeps:
    - Empty strings "" (meaningful - different from missing)
    - False, 0 (meaningful falsy values)

    :param data: Dictionary or list to clean
    :return: Cleaned dictionary or list with bloat removed
    """
    if isinstance(data, dict):
        cleaned = {}
        for k, v in data.items():
            # Skip None, empty lists, empty dicts BEFORE recursion
            if v is None or v == [] or v == {}:
                continue
            # Recursively clean the value
            cleaned_value = remove_none_values_recursive(v)
            # Skip if cleaning resulted in empty list/dict
            if cleaned_value == [] or cleaned_value == {}:
                continue
            cleaned[k] = cleaned_value
        return cast(T, cleaned)
    if isinstance(data, list):
        cleaned_items = []
        for item in data:
            if item is None:
                continue
            cleaned_item = remove_none_values_recursive(item)
            # Skip if cleaning resulted in empty list/dict
            if cleaned_item == [] or cleaned_item == {}:
                continue
            cleaned_items.append(cleaned_item)
        return cast(T, cleaned_items)
    return data
