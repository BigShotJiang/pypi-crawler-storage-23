from typing import Annotated, cast

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.errors import RetryableToolError

from arcade_github.models.mappers import (
    map_commit,
    map_pull_request,
    map_pull_request_for_update,
    map_review_comment,
    map_review_thread_comments,
)
from arcade_github.models.models import (
    DiffSide,
    PRSortProperty,
    PRState,
    ReviewCommentSortProperty,
    ReviewCommentSubjectType,
    SortDirection,
)
from arcade_github.models.tool_outputs.pull_requests import (
    CommitsListOutput,
    PullRequestOutput,
    PullRequestsListOutput,
    ReviewCommentOutput,
    ReviewCommentsListOutput,
)
from arcade_github.utils import pull_request_utils
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.date_utils import parse_flexible_date
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.pagination_utils import build_pagination_info
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # GET /repos/{owner}/{repo}/pulls (for private repos)
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_pull_requests(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    state: Annotated[
        PRState | None,
        ("The state of the pull requests to return. Default is open."),
    ] = PRState.OPEN,
    head: Annotated[
        str | None,
        "Filter pulls by head user or head organization and branch name in the format of "
        "user:ref-name or organization:ref-name.",
    ] = None,
    base: Annotated[str | None, "Filter pulls by base branch name. Default is main."] = "main",
    sort: Annotated[
        PRSortProperty | None, "The property to sort the results by."
    ] = PRSortProperty.CREATED,
    direction: Annotated[SortDirection | None, "The direction of the sort."] = SortDirection.DESC,
    per_page: Annotated[
        int,
        "The number of results per page (max 100). Default is 30.",
    ] = 30,
    page: Annotated[int, "The page number of the results to fetch. Default is 1."] = 1,
    search_org_wide: Annotated[
        bool,
        "Search across all organization repositories instead of just one repository. "
        "Default is False.",
    ] = False,
) -> Annotated[PullRequestsListOutput, "List of pull requests"]:
    """
    List pull requests in a GitHub repository.

    By default returns newest pull requests first (direction=DESC).
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page_clamped = min(max(1, per_page), 100)

    total_count = None
    if search_org_wide:
        # Build search query for organization-wide search
        query_parts = [f"org:{owner}", "type:pr"]

        if state and state != PRState.ALL:
            query_parts.append(f"state:{state.value}")

        if head:
            query_parts.append(f"head:{head}")

        if base:
            query_parts.append(f"base:{base}")

        query = " ".join(query_parts)
        search_result = await client.search_issues(
            query=query, per_page=per_page_clamped, page=page
        )
        pull_requests = search_result.get("items", [])
        total_count = search_result.get("total_count")  # Search API provides total count!
    else:
        pull_requests = await client.list_repository_pull_requests(
            owner=owner,
            repo=repo,
            state=state.value if state else None,
            head=head,
            base=base,
            sort=sort.value if sort else None,
            direction=direction.value if direction else None,
            per_page=per_page_clamped,
            page=page,
        )

    result: PullRequestsListOutput = {
        "pull_requests": [
            cast(PullRequestOutput, remove_none_values_recursive(map_pull_request(pr)))
            for pr in pull_requests
        ],
        "pagination": build_pagination_info(page, per_page_clamped, pull_requests, total_count),
    }
    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # GET /repos/{owner}/{repo}/pulls/{pull_number} (for private repos)
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_pull_request(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    pull_number: Annotated[int, "The number that identifies the pull request."],
    include_diff_content: Annotated[
        bool | None,
        "If true, return the diff content of the pull request. Default is False.",
    ] = False,
) -> Annotated[PullRequestOutput, "Pull request details"]:
    """
    Get details of a pull request in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    pr_data = await client.get_pull_request(owner=owner, repo=repo, pull_number=pull_number)

    diff_content = None
    if include_diff_content:
        diff_content = await client.get_pull_request_diff(
            owner=owner, repo=repo, pull_number=pull_number
        )

    return cast(
        PullRequestOutput,
        remove_none_values_recursive(map_pull_request(pr_data, diff_content)),
    )


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # PATCH /repos/{owner}/{repo}/pulls/{pull_number}
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def update_pull_request(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    pull_number: Annotated[int, "The number that identifies the pull request."],
    title: Annotated[str | None, "The title of the pull request."] = None,
    body: Annotated[str | None, "The contents of the pull request."] = None,
    append_body: Annotated[
        bool, "If True, append to existing body instead of replacing it. Default is False."
    ] = False,
    state: Annotated[PRState | None, "State of this Pull Request."] = None,
    base: Annotated[str | None, "The name of the branch you want your changes pulled into."] = None,
) -> Annotated[PullRequestOutput, "Updated pull request details"]:
    """
    Update a pull request in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    final_body = body
    if append_body and body:
        current_pr = await client.get_pull_request(owner=owner, repo=repo, pull_number=pull_number)
        current_body = current_pr.get("body", "")
        final_body = f"{current_body}\n\n{body}" if current_body else body

    pr_data = await client.update_pull_request(
        owner=owner,
        repo=repo,
        pull_number=pull_number,
        title=title,
        body=final_body,
        state=state.value if state else None,
        base=base,
    )
    return cast(
        PullRequestOutput,
        remove_none_values_recursive(map_pull_request_for_update(pr_data)),
    )


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # GET /repos/{owner}/{repo}/pulls/{pull_number}/commits (for private repos)
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_pull_request_commits(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    pull_number: Annotated[int, "The number that identifies the pull request."],
    per_page: Annotated[int, "The number of results per page (max 100). Default is 30."] = 30,
    page: Annotated[int, "The page number of the results to fetch. Default is 1."] = 1,
) -> Annotated[CommitsListOutput, "List of commits on the pull request"]:
    """
    List commits (from oldest to newest) on a pull request in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    commits = await client.list_pull_request_commits(
        owner=owner,
        repo=repo,
        pull_number=pull_number,
        per_page=max(1, min(100, per_page)),
        page=page,
    )

    result: CommitsListOutput = {"commits": [map_commit(commit) for commit in commits]}
    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # POST .../pulls/{pull_number}/comments/{comment_id}/replies
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_reply_for_review_comment(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    pull_number: Annotated[int, "The number that identifies the pull request."],
    comment_id: Annotated[int, "The unique identifier of the comment."],
    body: Annotated[str, "The text of the review comment."],
    thread_id: Annotated[
        str | None,
        "Optional GraphQL Node ID of the review thread to resolve after replying.",
    ] = None,
    resolve_thread: Annotated[
        bool, "Whether to resolve the thread after replying. Default is False."
    ] = False,
) -> Annotated[ReviewCommentOutput, "Created reply comment details"]:
    """
    Create a reply to a review comment for a pull request.

    Optionally resolve the conversation thread after replying by setting resolve_thread=True
    and providing the thread_id (GraphQL Node ID).
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    response = await client.create_pull_request_review_comment_reply(
        owner=owner, repo=repo, pull_number=pull_number, comment_id=comment_id, body=body
    )

    if resolve_thread and thread_id:
        mutation = """
        mutation($threadId: ID!) {
          resolveReviewThread(input: {threadId: $threadId}) {
            thread { id isResolved }
          }
        }
        """
        await client.execute_graphql(mutation, {"threadId": thread_id})

    return remove_none_values_recursive(map_review_comment(response))


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # GET /repos/{owner}/{repo}/pulls/{pull_number}/comments (for private repos)
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_review_comments_on_pull_request(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    pull_number: Annotated[int, "The number that identifies the pull request."],
    sort: Annotated[
        ReviewCommentSortProperty | None,
        "The property to sort the results by. Default is created.",
    ] = ReviewCommentSortProperty.CREATED,
    direction: Annotated[
        SortDirection | None,
        "The direction to sort results. Default is desc.",
    ] = SortDirection.DESC,
    since: Annotated[
        str | None,
        "Only show results updated after this time. "
        "Supports: relative dates ('today', 'yesterday', 'last_week', 'last_30_days'), "
        "ISO 8601 ('2025-11-10T00:00:00Z'), or simple dates ('2025-11-10').",
    ] = None,
    per_page: Annotated[int, "The number of results per page (max 100). Default is 30."] = 30,
    page: Annotated[int, "The page number of the results to fetch. Default is 1."] = 1,
    show_resolved: Annotated[
        bool | None,
        (
            "Filter by resolution status. True=resolved only, "
            "False=unresolved only, None=all. Default is None."
        ),
    ] = None,
) -> Annotated[ReviewCommentsListOutput, "List of review comments on the pull request"]:
    """
    List review comments on a pull request in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    # Fetch review threads via GraphQL (exceptions bubble up)
    threads = await client.get_pull_request_review_threads(owner, repo, pull_number)

    if not threads:
        empty_result: ReviewCommentsListOutput = {
            "review_comments": [],
            "pagination": {
                "page": page,
                "per_page": per_page,
                "has_next_page": False,
                "total_count": 0,
            },
            "total_threads": 0,
        }
        return remove_none_values_recursive(empty_result)

    # Map and filter comments
    parsed_since = parse_flexible_date(since) if since else None
    reverse = direction == SortDirection.DESC
    sort_key = "created_at" if sort == ReviewCommentSortProperty.CREATED else "updated_at"

    all_comments = map_review_thread_comments(
        threads, sort_key, reverse, parsed_since, show_resolved
    )

    # Paginate
    per_page_clamped = max(1, min(100, per_page))
    start_idx = (page - 1) * per_page_clamped
    end_idx = start_idx + per_page_clamped
    page_comments = all_comments[start_idx:end_idx]

    # Count unique threads
    unique_threads = len({c.get("thread_node_id") for c in all_comments if c.get("thread_node_id")})

    result: ReviewCommentsListOutput = {
        "review_comments": page_comments,
        "pagination": {
            "page": page,
            "per_page": per_page_clamped,
            "has_next_page": end_idx < len(all_comments),
            "total_count": len(all_comments),
        },
        "total_threads": unique_threads,
    }
    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # POST /repos/{owner}/{repo}/pulls/{pull_number}/comments
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_review_comment(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    pull_number: Annotated[int, "The number that identifies the pull request."],
    body: Annotated[str, "The text of the review comment."],
    path: Annotated[str, "The relative path to the file that necessitates a comment."],
    commit_id: Annotated[
        str | None,
        "The SHA of the commit needing a comment. If not provided, the latest commit SHA from the "
        "PR will be used.",
    ] = None,
    start_line: Annotated[
        int | None,
        "The start line of the range of lines in the pull request diff that the "
        "comment applies to. Required unless 'subject_type' is 'file'.",
    ] = None,
    end_line: Annotated[
        int | None,
        "The end line of the range of lines in the pull request diff that the "
        "comment applies to. Required unless 'subject_type' is 'file'.",
    ] = None,
    side: Annotated[
        DiffSide | None,
        "The side of the diff that the pull request's changes appear on. "
        "Use LEFT for deletions that appear in red. Use RIGHT for additions that appear in green "
        "or unchanged lines that appear in white and are shown for context. Default is RIGHT.",
    ] = DiffSide.RIGHT,
    start_side: Annotated[
        str | None, "The starting side of the diff that the comment applies to."
    ] = None,
    subject_type: Annotated[
        ReviewCommentSubjectType | None,
        "The type of subject that the comment applies to. Default is file.",
    ] = ReviewCommentSubjectType.FILE,
) -> Annotated[ReviewCommentOutput, "Created review comment details"]:
    """
    Create a review comment for a pull request in a GitHub repository.

    IMPORTANT: Line numbers must be part of the diff (changed lines only).
    GitHub's API requires line numbers that exist in the pull request diff, not just any line
    in the file. If the line wasn't changed in the PR, the comment will fail with 422 error.

    If the subject_type is not 'file', then the start_line and end_line parameters are required.
    If the subject_type is 'file', then the start_line and end_line parameters are ignored.
    If the commit_id is not provided, the latest commit SHA from the PR will be used.

    TIP: Use subject_type='file' to comment on the entire file if unsure about line positions.
    """
    # If the subject_type is 'file', then the line_range parameter is ignored
    start_line, end_line = pull_request_utils.normalize_review_comment_range(
        subject_type=subject_type,
        start_line=start_line,
        end_line=end_line,
    )

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    pr_files = await client.list_pull_request_files(owner, repo, pull_number, per_page=100)
    valid_paths = [file.get("filename") for file in pr_files if file.get("filename")]

    if path not in valid_paths:
        paths_list = "\n".join(f"  - {p}" for p in valid_paths[:20])
        if len(valid_paths) > 20:
            paths_list += f"\n  ... and {len(valid_paths) - 20} more files"

        message = (
            f"The file path '{path}' is not among the files modified in PR #{pull_number}. "
            f"Review comments can only be added to files that were changed in this PR.\n\n"
            f"Files changed in this PR:\n{paths_list}"
        )
        raise RetryableToolError(
            message=message,
            developer_message=message,
            additional_prompt_content=(
                "Please use one of the valid file paths listed above that were changed in this PR."
            ),
        )

    # Get the latest commit SHA of the PR's base branch and use that for the commit_id
    if not commit_id:
        commits_output = await list_pull_request_commits(context, owner, repo, pull_number)
        commits = commits_output.get("commits", [])
        latest_commit = commits[-1] if commits else {}
        commit_id = latest_commit.get("sha")

    if not commit_id:
        message = (
            f"Failed to get the latest commit SHA of PR {pull_number} in repo {repo} owned by "
            f"{owner}. Does the PR exist?"
        )
        raise RetryableToolError(
            message=message,
            developer_message=message,
            additional_prompt_content=(
                "Please verify that the pull request exists and has commits. You may need to "
                "check the pull request number or repository details."
            ),
        )

    comment_data = await client.create_pull_request_review_comment(
        owner=owner,
        repo=repo,
        pull_number=pull_number,
        body=body,
        commit_id=commit_id,
        path=path,
        line=end_line if end_line else None,
        side=side,
        start_line=start_line if start_line and start_line != end_line else None,
        start_side=start_side,
        subject_type=subject_type,
    )
    return remove_none_values_recursive(map_review_comment(comment_data))
