from typing import Annotated

import httpx
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.errors import RetryableToolError, ToolExecutionError

from arcade_github.models.mappers import map_file_content, map_file_update
from arcade_github.models.models import FileMode, FileUpdateMode
from arcade_github.models.tool_outputs.files import FileContentOutput, FileUpdateOutput
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.file_utils import (
    LineRangeError,
    replace_file_lines,
    slice_content_with_line_range,
    validate_update_line_request,
)
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.repo_name_utils import normalize_repo_name
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # Contents: Read - /repos/{owner}/{repo}/contents/{path}
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_file_contents(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    path: Annotated[
        str,
        "Path within the repository relative to its root; omit owner/repo prefixes.",
    ],
    ref: Annotated[
        str | None, "The name of the commit/branch/tag. Default: the repository's default branch."
    ] = None,
    start_line: Annotated[
        int | None, "First line to retrieve (1-indexed). Default: None (entire file)."
    ] = None,
    end_line: Annotated[
        int | None, "Last line to retrieve (1-indexed, inclusive). Default: None (entire file)."
    ] = None,
) -> Annotated[FileContentOutput, "File content and metadata"]:
    """
    Get the contents of a file in a repository.

    Returns the decoded content (if text) along with metadata like SHA, size, and line count.
    For large files, use start_line and end_line to retrieve specific line ranges.
    """
    repo = normalize_repo_name(repo)
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    try:
        file_data = await client.get_file_contents(owner, repo, path, ref)
        result = map_file_content(file_data)

        # Apply line range if requested
        if start_line is not None or end_line is not None:
            try:
                selected_content, line_range, range_warnings = slice_content_with_line_range(
                    result.get("content", ""),
                    start_line,
                    end_line,
                )
            except LineRangeError as exc:
                raise RetryableToolError(
                    message=str(exc),
                    additional_prompt_content=exc.additional_prompt,
                ) from exc

            result["content"] = selected_content
            result["line_range"] = line_range
            if range_warnings:
                result["line_range_warnings"] = range_warnings

        return remove_none_values_recursive(result)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise RetryableToolError(
                message=(f"File '{path}' not found in {owner}/{repo} at ref '{ref or 'default'}'"),
                additional_prompt_content="Check the file path and branch name.",
            ) from e
        raise


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # Contents: Write - /repos/{owner}/{repo}/contents/{path}
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_file(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    path: Annotated[str, "The content path."],
    content: Annotated[str, "The content of the file."],
    message: Annotated[str, "The commit message."],
    branch: Annotated[str, "The branch name."],
    mode: Annotated[
        FileMode,
        ("How to handle existing files. Default is FileMode.CREATE"),
    ] = FileMode.CREATE,
) -> Annotated[FileUpdateOutput, "File creation/update result"]:
    """
    Create a new file or overwrite an existing file in a repository.

    The explicit mode parameter reduces accidental data loss: the default CREATE mode refuses to
    touch existing files, while OVERWRITE must be chosen intentionally.
    """
    repo = normalize_repo_name(repo)
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    sha = None

    # Check if file exists and get necessary data
    try:
        metadata = await client.get_file_metadata(owner, repo, path, branch)
        sha = metadata.get("sha")

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            # File doesn't exist
            sha = None
        else:
            raise

    # Guardrail: default mode refuses to touch existing files unless explicitly overridden.
    if mode == FileMode.CREATE and sha:
        raise RetryableToolError(
            message=(f"File '{path}' already exists in {owner}/{repo} on branch '{branch}'."),
            additional_prompt_content="Set mode='overwrite' if you intend to replace it.",
        )

    result = await client.update_file(
        owner=owner,
        repo=repo,
        path=path,
        content=content,
        message=message,
        branch=branch,
        sha=sha,
    )

    return remove_none_values_recursive(map_file_update(result))


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # Contents: Write - /repos/{owner}/{repo}/contents/{path}
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def update_file_lines(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    path: Annotated[str, "The content path."],
    branch: Annotated[str, "The branch to update."],
    new_content: Annotated[str, "The replacement lines (no need to include trailing newline)."],
    message: Annotated[str, "The commit message describing the change."],
    start_line: Annotated[
        int | None,
        (
            "First line to replace (1-indexed). Required when mode is FileUpdateMode.REPLACE; "
            "ignored when mode is FileUpdateMode.APPEND."
        ),
    ] = None,
    end_line: Annotated[
        int | None,
        (
            "Last line to replace (1-indexed, inclusive). Required when mode is "
            "FileUpdateMode.REPLACE; ignored when mode is FileUpdateMode.APPEND."
        ),
    ] = None,
    mode: Annotated[
        FileUpdateMode,
        ("How to apply the change. Default is FileUpdateMode.REPLACE"),
    ] = FileUpdateMode.REPLACE,
) -> Annotated[FileUpdateOutput, "Partial file update result"]:
    """
    Replace a block of lines within a file (1-indexed, inclusive). Set mode=FileUpdateMode.APPEND
    to add new content to the end of the file.
    """
    sentinel_append = start_line == -1 and end_line == -1
    append_mode = mode == FileUpdateMode.APPEND or sentinel_append
    effective_start: int
    effective_end: int
    if append_mode:
        effective_start = -1
        effective_end = -1
    else:
        if start_line is None or end_line is None:
            raise RetryableToolError(
                message="start_line and end_line are required when mode='replace'.",
                additional_prompt_content="Provide both line numbers or set mode='append'.",
            )
        effective_start = start_line
        effective_end = end_line

    repo = normalize_repo_name(repo)
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    try:
        existing_file = await client.get_file_contents(owner, repo, path, branch)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise RetryableToolError(
                message=f"File '{path}' not found on branch '{branch}'.",
                additional_prompt_content="Verify the file path and branch.",
            ) from e
        raise

    file_output = map_file_content(existing_file)
    file_content = file_output.get("content", "")
    total_lines = len(file_content.splitlines())

    try:
        validate_update_line_request(effective_start, effective_end, total_lines, append_mode)
    except LineRangeError as exc:
        raise RetryableToolError(
            message=str(exc),
            additional_prompt_content=exc.additional_prompt,
        ) from exc

    if append_mode:
        if file_content and not file_content.endswith("\n"):
            updated_content = file_content + "\n" + new_content
        else:
            updated_content = file_content + new_content
        old_line_count = 0
        new_line_count = len(new_content.splitlines()) if new_content else 0
    else:
        try:
            updated_content, old_line_count, new_line_count = replace_file_lines(
                file_content, effective_start, effective_end, new_content
            )
        except ValueError as exc:
            raise RetryableToolError(
                message=str(exc),
                additional_prompt_content="Check the line numbers and file length.",
            ) from exc

    sha = file_output.get("sha")
    if not sha:
        raise ToolExecutionError("Unable to determine file SHA from the fetched file content.")

    result = await client.update_file(
        owner=owner,
        repo=repo,
        path=path,
        content=updated_content,
        message=message,
        branch=branch,
        sha=sha,
    )
    mapped = map_file_update(result)
    mapped["lines_changed"] = {
        "start_line": effective_start,
        "end_line": effective_end,
        "old_line_count": old_line_count,
        "new_line_count": new_line_count,
    }
    return remove_none_values_recursive(mapped)
