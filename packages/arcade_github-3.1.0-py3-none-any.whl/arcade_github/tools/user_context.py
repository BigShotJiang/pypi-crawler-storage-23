import asyncio
from datetime import datetime, timedelta, timezone
from typing import Annotated, Any, cast

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool

from arcade_github.models.mappers import (
    map_commit_summary,
    map_issue_summary,
    map_organization_membership,
    map_pull_request_summary,
    map_team_membership,
    map_user_profile,
)
from arcade_github.models.tool_outputs.user_context import (
    OpenItemsOutput,
    RecentActivityOutput,
    WhoAmIOutput,
)
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "read:org",
            "read:user",
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def who_am_i(
    context: ToolContext,
) -> Annotated[WhoAmIOutput, "User profile with organizations and teams"]:
    """
    Get information about the authenticated GitHub user.

    Returns profile, organizations, and teams.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    user, orgs, teams = await asyncio.gather(
        client.get_authenticated_user(),
        client.list_user_organizations(per_page=30),
        client.list_user_teams(per_page=30),
    )

    result: WhoAmIOutput = {
        "profile": map_user_profile(user),
        "organizations": {
            "count": len(orgs),
            "organizations": [map_organization_membership(org) for org in orgs],
        },
        "teams": {
            "count": len(teams),
            "teams": [map_team_membership(team) for team in teams],
        },
    }

    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "read:user",
            "repo",
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_user_recent_activity(
    context: ToolContext,
    days: Annotated[int, "Number of days to look back. Default is 30."] = 30,
    per_page: Annotated[
        int, "Number of items per category (PRs and issues). Default is 10, max 50."
    ] = 10,
) -> Annotated[RecentActivityOutput, "Recent pull requests, reviews, issues, and commits"]:
    """
    Get the authenticated user's recent pull requests, reviews, issues, and commits.

    Returns PRs they authored, merged PRs, PRs they reviewed, issues they opened, and commits pushed
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page), 50)
    days = max(1, days)

    user_data = await client.get_authenticated_user()
    username = user_data.get("login", "")

    date_threshold = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")

    # Prepare search queries
    created_prs_query = f"is:pr author:@me created:>{date_threshold}"
    merged_prs_query = f"is:pr is:merged author:@me merged:>{date_threshold}"
    reviewed_prs_query = f"is:pr reviewed-by:@me updated:>{date_threshold} -author:@me"
    issues_query = f"is:issue author:@me created:>{date_threshold}"
    commits_query = f"author:{username} committer-date:>{date_threshold}"

    # Execute searches in parallel
    results = await asyncio.gather(
        client.search_issues(
            query=created_prs_query, sort="created", order="desc", per_page=per_page
        ),
        client.search_issues(
            query=merged_prs_query, sort="updated", order="desc", per_page=per_page
        ),
        client.search_issues(
            query=reviewed_prs_query, sort="updated", order="desc", per_page=per_page
        ),
        client.search_issues(query=issues_query, sort="created", order="desc", per_page=per_page),
        client.search_commits(
            query=commits_query, sort="committer-date", order="desc", per_page=per_page
        ),
        return_exceptions=True,
    )

    (
        created_prs_result,
        merged_prs_result,
        reviewed_prs_result,
        issues_result,
        commits_result,
    ) = results

    # Helper to extract items safely
    def get_items(res: Any) -> list[dict[str, Any]]:
        if isinstance(res, Exception):
            return []
        items = res.get("items", [])
        return cast(list[dict[str, Any]], items)

    # Map results
    created_prs = [map_pull_request_summary(item) for item in get_items(created_prs_result)]
    merged_prs = [map_pull_request_summary(item) for item in get_items(merged_prs_result)]
    reviewed_prs = [map_pull_request_summary(item) for item in get_items(reviewed_prs_result)]
    issues = [map_issue_summary(item) for item in get_items(issues_result)]
    commits = [map_commit_summary(item) for item in get_items(commits_result)]

    result: RecentActivityOutput = {
        "recent_pull_requests": created_prs,
        "recent_merged_pull_requests": merged_prs,
        "recent_reviewed_pull_requests": reviewed_prs,
        "recent_pull_requests_count": len(created_prs),
        "recent_issues": issues,
        "recent_issues_count": len(issues),
        "recent_commits": commits,
        "days_searched": days,
    }

    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "read:user",
            "repo",
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_user_open_items(
    context: ToolContext,
    per_page: Annotated[
        int, "Number of items per category (PRs and issues). Default is 30, max 100."
    ] = 30,
) -> Annotated[OpenItemsOutput, "User's currently open pull requests and issues"]:
    """
    Get user's currently open pull requests and issues across all repositories.

    Returns open PRs and issues authored by the authenticated user.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page), 100)

    user_data = await client.get_authenticated_user()
    username = user_data.get("login", "")

    open_prs_result, open_issues_result = await asyncio.gather(
        client.search_issues(f"author:{username} type:pr state:open", per_page=per_page),
        client.search_issues(f"author:{username} type:issue state:open", per_page=per_page),
        return_exceptions=True,
    )

    open_prs = (
        open_prs_result.get("items", []) if not isinstance(open_prs_result, Exception) else []
    )
    open_issues = (
        open_issues_result.get("items", []) if not isinstance(open_issues_result, Exception) else []
    )

    result: OpenItemsOutput = {
        "open_pull_requests": [map_pull_request_summary(pr) for pr in open_prs],
        "open_pull_requests_count": len(open_prs),
        "open_issues": [map_issue_summary(issue) for issue in open_issues],
        "open_issues_count": len(open_issues),
    }

    return remove_none_values_recursive(result)
