from typing import Annotated, Any, cast

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.errors import ToolExecutionError

from arcade_github.constants import (
    DISABLE_AUTO_ACCEPT_THRESHOLD,
    FUZZY_AUTO_ACCEPT_CONFIDENCE,
    MAX_SUMMARY_ITEMS,
)
from arcade_github.models.mappers import map_project_v2, map_project_v2_item
from arcade_github.models.models import (
    ProjectItemLookupMode,
    ProjectLookupMode,
    ProjectScopeTarget,
    ProjectState,
)
from arcade_github.models.tool_outputs.projects_v2 import (
    ProjectFieldsListOutput,
    ProjectItemSearchOutput,
    ProjectItemsListOutput,
    ProjectsSearchOutput,
)
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.project_utils import (
    build_query_filter,
    clamp_per_page,
    resolve_project_v2,
    search_project_v2_item,
)
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",
            "read:org",
            "project",
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_projects(
    context: ToolContext,
    search_mode: Annotated[ProjectLookupMode, "Select search by number or name"],
    scope_target: Annotated[ProjectScopeTarget, "Where the project lives"],
    scope_identifier: Annotated[str, "Owner reference (org name or username)"],
    project_identifier: Annotated[str | None, "Project number or title"] = None,
    query_filter: Annotated[str | None, "Filter projects (e.g., 'template')"] = None,
    state: Annotated[ProjectState | None, "Project state filter"] = None,
    per_page: Annotated[int, "Items per page (max 100). Default is 30."] = 30,
    cursor: Annotated[str | None, "Cursor for next page"] = None,
    auto_accept_matches: Annotated[
        bool,
        f"Auto-accept fuzzy matches above {FUZZY_AUTO_ACCEPT_CONFIDENCE} confidence. "
        "Default is False",
    ] = False,
) -> Annotated[ProjectsSearchOutput, "Projects with summary and pagination"]:
    """
    List Projects V2 across organization or user scopes.
    """
    if search_mode == ProjectLookupMode.NUMBER and not project_identifier:
        raise ToolExecutionError("Provide a project_identifier when search_mode is NUMBER.")

    per_page = clamp_per_page(per_page)

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    scope_str = "organization" if scope_target == ProjectScopeTarget.ORGANIZATION else "user"

    if search_mode == ProjectLookupMode.NUMBER:
        auto_accept = (
            FUZZY_AUTO_ACCEPT_CONFIDENCE if auto_accept_matches else DISABLE_AUTO_ACCEPT_THRESHOLD
        )
        project, _, owner, _ = await resolve_project_v2(
            client=client,
            lookup_mode=search_mode,
            identifier=project_identifier or "",
            scope_target=scope_target,
            scope_identifier=scope_identifier,
            query_filter=query_filter,
            auto_accept_confidence=auto_accept,
        )

        if not project:
            raise ToolExecutionError(f"Project {project_identifier} not found")

        mapped = map_project_v2(project, scope_str, owner)

        return cast(
            ProjectsSearchOutput,
            remove_none_values_recursive({
                "matched_project": mapped,
                "projects": [mapped],
                "summary": {
                    "total_count": "1",
                    "projects_returned": 1,
                },
                "pagination": {
                    "next_cursor": None,
                    "prev_cursor": None,
                    "has_next_page": False,
                    "has_prev_page": False,
                },
                "suggestions": [],
            }),
        )

    if scope_target == ProjectScopeTarget.ORGANIZATION:
        projects, next_cur, prev_cur = await client.list_organization_projects_v2(
            org=scope_identifier, q=query_filter, after=cursor, per_page=per_page
        )
    else:
        projects, next_cur, prev_cur = await client.list_user_projects_v2(
            username=scope_identifier, q=query_filter, after=cursor, per_page=per_page
        )

    if state:
        projects = [p for p in projects if p.get("state") == state.value]

    mapped_projects = [map_project_v2(p, scope_str, scope_identifier) for p in projects]

    return cast(
        ProjectsSearchOutput,
        remove_none_values_recursive({
            "matched_project": mapped_projects[0] if mapped_projects else None,
            "projects": mapped_projects,
            "summary": {
                "total_count": "not available",
                "projects_returned": len(mapped_projects),
            },
            "pagination": {
                "next_cursor": next_cur,
                "prev_cursor": prev_cur,
                "has_next_page": next_cur is not None,
                "has_prev_page": prev_cur is not None,
            },
            "suggestions": [],
        }),
    )


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",
            "read:org",
            "project",
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_project_items(
    context: ToolContext,
    project_search_mode: Annotated[ProjectLookupMode, "Select project lookup by number or name"],
    project_identifier: Annotated[str, "Project number or title"],
    scope_target: Annotated[ProjectScopeTarget, "Where the project lives"],
    scope_identifier: Annotated[str, "Owner reference"],
    filter_assignee: Annotated[str | None, "Filter by assignee ('@me' or username)"] = None,
    filter_status: Annotated[str | None, "Filter by status field value"] = None,
    filter_labels: Annotated[list[str] | None, "Filter by labels"] = None,
    filter_is_open: Annotated[bool | None, "Filter by open/closed state"] = None,
    advanced_query: Annotated[str | None, "Advanced query (overrides filters)"] = None,
    per_page: Annotated[int, "Items per page (max 100). Default is 30."] = 30,
    cursor: Annotated[str | None, "Cursor for next page"] = None,
    auto_accept_matches: Annotated[
        bool,
        f"Auto-accept fuzzy matches above {FUZZY_AUTO_ACCEPT_CONFIDENCE} confidence. "
        "Default is False",
    ] = False,
) -> Annotated[ProjectItemsListOutput, "Project items with summary and pagination"]:
    """
    List items for a Projects V2 project with optional filtering.
    """

    per_page = clamp_per_page(per_page)

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    auto_accept = (
        FUZZY_AUTO_ACCEPT_CONFIDENCE if auto_accept_matches else DISABLE_AUTO_ACCEPT_THRESHOLD
    )
    project, _, _, project_suggestions = await resolve_project_v2(
        client=client,
        lookup_mode=project_search_mode,
        identifier=project_identifier,
        scope_target=scope_target,
        scope_identifier=scope_identifier,
        auto_accept_confidence=auto_accept,
    )

    if not project:
        if project_suggestions:
            raise ToolExecutionError(
                f"Project '{project_identifier}' fuzzy match confidence too low. "
                f"Found {len(project_suggestions)} suggestions. "
                f"Please use exact project number or refine search."
            )
        raise ToolExecutionError(f"Project '{project_identifier}' not found")

    project_number = project.get("number")
    project_title = project.get("title")

    if not project_number:
        raise ToolExecutionError("Project number not found in response")

    query = build_query_filter(
        filter_assignee, filter_status, filter_labels, filter_is_open, advanced_query
    )

    scope_str = "organization" if scope_target == ProjectScopeTarget.ORGANIZATION else "user"

    items, next_cur, prev_cur = await client.list_project_v2_items(
        scope_target=scope_str,
        identifier=scope_identifier,
        project_number=project_number,
        q=query,
        after=cursor,
        per_page=per_page,
    )

    is_partial = len(items) >= MAX_SUMMARY_ITEMS

    mapped_items = [
        map_project_v2_item(item, project_number, project_title)
        for item in items[:MAX_SUMMARY_ITEMS]
    ]

    content_types: dict[str, int] = {}
    for item in items:
        content_type = item.get("content_type", "unknown")
        content_types[content_type] = content_types.get(content_type, 0) + 1

    return cast(
        ProjectItemsListOutput,
        remove_none_values_recursive({
            "project_number": project_number,
            "project_title": project_title,
            "items": mapped_items,
            "summary": {
                "total_count": "not available",
                "items_returned": len(mapped_items),
                "is_partial": is_partial,
                "content_type_breakdown": content_types,
            },
            "pagination": {
                "next_cursor": next_cur,
                "prev_cursor": prev_cur,
                "has_next_page": next_cur is not None,
                "has_prev_page": prev_cur is not None,
            },
        }),
    )


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",
            "read:org",
            "project",
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def search_project_item(
    context: ToolContext,
    project_search_mode: Annotated[ProjectLookupMode, "Select project lookup by number or name"],
    project_identifier: Annotated[str, "Project number or title"],
    item_search_mode: Annotated[ProjectItemLookupMode, "Select item lookup by ID or title"],
    item_identifier: Annotated[str, "Item ID or title"],
    scope_target: Annotated[ProjectScopeTarget, "Where the project lives"],
    scope_identifier: Annotated[str, "Owner reference"],
    auto_accept_matches: Annotated[
        bool,
        f"Auto-accept fuzzy matches above {FUZZY_AUTO_ACCEPT_CONFIDENCE} confidence. "
        "Default is False",
    ] = False,
) -> Annotated[ProjectItemSearchOutput, "Single item or suggestions"]:
    """
    Search for a specific item in a Projects V2 project.
    """

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    auto_accept = (
        FUZZY_AUTO_ACCEPT_CONFIDENCE if auto_accept_matches else DISABLE_AUTO_ACCEPT_THRESHOLD
    )
    project, _, _, project_suggestions = await resolve_project_v2(
        client=client,
        lookup_mode=project_search_mode,
        identifier=project_identifier,
        scope_target=scope_target,
        scope_identifier=scope_identifier,
        auto_accept_confidence=auto_accept,
    )

    if not project:
        if project_suggestions:
            raise ToolExecutionError(
                f"Project '{project_identifier}' fuzzy match confidence too low. "
                f"Found {len(project_suggestions)} suggestions. "
                f"Please use exact project number or refine search."
            )
        raise ToolExecutionError(f"Project '{project_identifier}' not found")

    project_number = project.get("number")
    project_title = project.get("title")

    if not project_number:
        raise ToolExecutionError("Project number not found in response")

    matched_item, suggestions = await search_project_v2_item(
        client=client,
        scope_target=scope_target,
        identifier=scope_identifier,
        project_number=project_number,
        item_lookup_mode=item_search_mode,
        item_identifier=item_identifier,
        auto_accept_confidence=auto_accept,
    )

    if matched_item:
        mapped = map_project_v2_item(
            matched_item.item, project_number, project_title, matched_item.score
        )
        return cast(
            ProjectItemSearchOutput,
            remove_none_values_recursive({
                "matched_item": mapped,
                "suggestions": [],
            }),
        )

    suggestion_items = [
        map_project_v2_item(s.item, project_number, project_title, s.score) for s in suggestions
    ]

    return cast(
        ProjectItemSearchOutput,
        remove_none_values_recursive({
            "matched_item": None,
            "suggestions": suggestion_items,
        }),
    )


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",
            "read:org",
            "project",
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_project_fields(
    context: ToolContext,
    project_search_mode: Annotated[ProjectLookupMode, "Select project lookup by number or name"],
    project_identifier: Annotated[str, "Project number or title"],
    scope_target: Annotated[ProjectScopeTarget, "Where the project lives"],
    scope_identifier: Annotated[str, "Owner reference"],
    auto_accept_matches: Annotated[
        bool,
        f"Auto-accept fuzzy matches above {FUZZY_AUTO_ACCEPT_CONFIDENCE} confidence. "
        "Default is False",
    ] = False,
) -> Annotated[ProjectFieldsListOutput, "Project fields with options"]:
    """
    List fields for a Projects V2 project.

    Returns all custom fields configured for the project, including field types
    and available options for select/iteration fields.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    auto_accept = (
        FUZZY_AUTO_ACCEPT_CONFIDENCE if auto_accept_matches else DISABLE_AUTO_ACCEPT_THRESHOLD
    )
    project, _, _, project_suggestions = await resolve_project_v2(
        client=client,
        lookup_mode=project_search_mode,
        identifier=project_identifier,
        scope_target=scope_target,
        scope_identifier=scope_identifier,
        auto_accept_confidence=auto_accept,
    )

    if not project:
        if project_suggestions:
            raise ToolExecutionError(
                f"Project '{project_identifier}' fuzzy match confidence too low. "
                f"Found {len(project_suggestions)} suggestions. "
                f"Please use exact project number or refine search."
            )
        raise ToolExecutionError(f"Project '{project_identifier}' not found")

    project_number = project.get("number")
    project_title = project.get("title")

    if not project_number:
        raise ToolExecutionError("Project number not found in response")

    scope_str = "organization" if scope_target == ProjectScopeTarget.ORGANIZATION else "user"

    fields = await client.list_project_v2_fields(
        scope_target=scope_str,
        identifier=scope_identifier,
        project_number=project_number,
    )

    mapped_fields = []
    field_type_counts: dict[str, int] = {}

    for field in fields:
        field_type = str(field.get("type", "unknown"))
        field_type_counts[field_type] = field_type_counts.get(field_type, 0) + 1

        mapped_field: dict[str, Any] = {
            "id": field.get("id"),
            "name": field.get("name"),
            "type": field_type,
        }

        if "options" in field:
            mapped_options = []
            for opt in field["options"]:
                name_val = opt.get("name")
                desc_val = opt.get("description")
                mapped_options.append({
                    "id": opt.get("id"),
                    "name": name_val.get("raw") if isinstance(name_val, dict) else name_val,
                    "description": desc_val.get("raw") if isinstance(desc_val, dict) else desc_val,
                })
            mapped_field["options"] = mapped_options

        mapped_fields.append(mapped_field)

    return cast(
        ProjectFieldsListOutput,
        remove_none_values_recursive({
            "project_number": project_number,
            "project_title": project_title,
            "fields": mapped_fields,
            "summary": field_type_counts,
        }),
    )
