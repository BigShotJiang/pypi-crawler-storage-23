from typing import Annotated

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool

from arcade_github.models.mappers import map_branch
from arcade_github.models.tool_outputs.files import BranchOutput
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.repo_name_utils import normalize_repo_name
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_branch(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    branch: Annotated[str, "The name of the new branch."],
    from_branch: Annotated[
        str | None, "The name of the branch to branch off of. Default: repository default branch."
    ] = None,
) -> Annotated[BranchOutput, "Created branch details"]:
    """
    Create a new branch in a repository.
    """
    repo = normalize_repo_name(repo)

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    # Get repository to find default branch or source branch
    repo_data = await client.get_repository(owner, repo)
    source_branch_name = from_branch or repo_data.get("default_branch", "main")

    # Get the source branch to find its SHA
    branch_data = await client.get_branch(owner, repo, source_branch_name)
    from_sha = branch_data.get("commit", {}).get("sha")

    if not from_sha:
        from arcade_tdk.errors import ToolExecutionError

        raise ToolExecutionError(f"Could not find SHA for branch '{source_branch_name}'")

    # Create the new branch
    result = await client.create_branch(owner, repo, branch, from_sha)

    return remove_none_values_recursive(map_branch(result))
