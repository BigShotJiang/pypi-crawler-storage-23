import asyncio
from typing import Annotated, Any, cast

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.errors import RetryableToolError, ToolExecutionError

from arcade_github.constants import (
    DISABLE_AUTO_ACCEPT_THRESHOLD,
    FUZZY_AUTO_ACCEPT_CONFIDENCE,
    FUZZY_MATCH_THRESHOLD,
)
from arcade_github.models.mappers import map_pull_request
from arcade_github.models.models import MergeMethod, ReviewEvent, UserSearchMode
from arcade_github.models.tool_outputs.pull_requests import (
    AssigneeOutput,
    MergeCheckOutput,
    MergeStatusOutput,
    PullRequestOutput,
    ReviewersOutput,
    ReviewOutput,
    UserData,
)
from arcade_github.utils import pr_lifecycle_utils, user_resolution_utils
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # POST /repos/{owner}/{repo}/pulls, POST .../requested_reviewers
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_pull_request(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    title: Annotated[str, "The title of the pull request."],
    head: Annotated[
        str,
        "The name of the branch where your changes are implemented. "
        "For cross-repository PRs, use format: username:branch.",
    ],
    base: Annotated[str, "The name of the branch you want the changes pulled into."],
    body: Annotated[str | None, "The contents/description of the pull request."] = None,
    draft: Annotated[bool, "Create as a draft pull request. Default is False."] = False,
    maintainer_can_modify: Annotated[
        bool, "Allow repository maintainers to modify the pull request branch. Default is True."
    ] = True,
    issue: Annotated[
        int | None,
        "Issue number to auto-link. Will prepend 'Closes #{issue}' to the PR body.",
    ] = None,
    reviewers: Annotated[list[str] | None, "List of user logins to request reviews from."] = None,
    team_reviewers: Annotated[
        list[str] | None, "List of team slugs to request reviews from."
    ] = None,
) -> Annotated[PullRequestOutput, "Created pull request details"]:
    """
    Create a pull request in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    validation_tasks = [
        pr_lifecycle_utils.validate_branch_exists(client, owner, repo, head, "head"),
        pr_lifecycle_utils.validate_branch_exists(client, owner, repo, base, "base"),
        pr_lifecycle_utils.validate_no_existing_pr(client, owner, repo, head, base),
        pr_lifecycle_utils.validate_branches_have_commits(client, owner, repo, head, base),
    ]

    if issue is not None:
        validation_tasks.append(
            pr_lifecycle_utils.validate_issue_exists(client, owner, repo, issue)
        )

    await asyncio.gather(*validation_tasks)

    final_body = pr_lifecycle_utils.format_auto_link_body(body, issue)

    pr_data = await client.create_pull_request(
        owner=owner,
        repo=repo,
        title=title,
        head=head,
        base=base,
        body=final_body,
        draft=draft,
        maintainer_can_modify=maintainer_can_modify,
    )

    reviewer_request_errors: list[str] = []
    if reviewers or team_reviewers:
        try:
            await client.request_pull_request_reviewers(
                owner=owner,
                repo=repo,
                pull_number=pr_data["number"],
                reviewers=reviewers,
                team_reviewers=team_reviewers,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            reviewer_request_errors.append(f"Failed to request reviewers: {exc!s}")

    pr_output = map_pull_request(pr_data)
    if reviewer_request_errors:
        pr_output["reviewer_request_errors"] = reviewer_request_errors

    return remove_none_values_recursive(pr_output)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # PUT /repos/{owner}/{repo}/pulls/{pull_number}/merge, DELETE .../git/refs
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def merge_pull_request(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    pull_request_number: Annotated[int, "The number that identifies the pull request."],
    merge_method: Annotated[
        MergeMethod, "The merge method to use. Default is merge."
    ] = MergeMethod.MERGE,
    commit_title: Annotated[str | None, "Title for the merge commit."] = None,
    commit_message: Annotated[str | None, "Extra detail for the merge commit message."] = None,
    sha: Annotated[
        str | None, "Expected head SHA to ensure merge safety. Merge fails if SHA doesn't match."
    ] = None,
    delete_branch: Annotated[
        bool, "Delete the head branch after successful merge. Default is False."
    ] = False,
) -> Annotated[MergeStatusOutput, "Merge operation status and details"]:
    """
    Merge a pull request in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    pr_data = await client.get_pull_request(owner, repo, pull_request_number)

    mergeable = cast(bool | None, pr_data.get("mergeable"))
    mergeable_state = cast(str, pr_data.get("mergeable_state", "unknown"))
    head_ref = pr_data.get("head", {}).get("ref", "")
    head_sha = pr_data.get("head", {}).get("sha", "")

    if mergeable is None:
        return cast(
            MergeStatusOutput,
            remove_none_values_recursive({
                "success": False,
                "merged": False,
                "status": "pending",
                "blocking_reasons": [
                    "GitHub is still computing merge status. Please try again in a moment."
                ],
                "branch_deleted": False,
            }),
        )

    if not mergeable or mergeable_state not in ["clean", "unstable"]:
        status, base_reasons = pr_lifecycle_utils.interpret_mergeable_state(mergeable_state)

        try:
            combined_status = await client.get_combined_status(owner, repo, head_sha)
            check_runs = await client.list_check_runs_for_ref(owner, repo, head_sha, per_page=100)
        except Exception:
            combined_status = {}
            check_runs = {}

        checks_summary, failed_checks = pr_lifecycle_utils.aggregate_check_status(
            combined_status, check_runs
        )
        reviews_summary = pr_lifecycle_utils.extract_reviews_summary(cast(dict[str, Any], pr_data))

        blocking_reasons = pr_lifecycle_utils.format_blocking_reasons(
            cast(bool | None, mergeable),
            cast(str, mergeable_state),
            checks_summary,
            failed_checks,
            reviews_summary,
        )

        if not blocking_reasons:
            blocking_reasons = base_reasons

        return cast(
            MergeStatusOutput,
            remove_none_values_recursive({
                "success": False,
                "merged": False,
                "status": status,
                "blocking_reasons": blocking_reasons,
                "failed_checks": failed_checks,
                "branch_deleted": False,
            }),
        )

    try:
        merge_result = await client.merge_pull_request(
            owner=owner,
            repo=repo,
            pull_number=pull_request_number,
            commit_title=commit_title,
            commit_message=commit_message,
            sha=sha,
            merge_method=merge_method.value,
        )

        branch_deleted = False
        branch_delete_error = None
        if delete_branch and head_ref:
            (
                branch_deleted,
                branch_delete_error,
            ) = await pr_lifecycle_utils.delete_branch_after_merge(client, owner, repo, head_ref)

        result_data: dict[str, Any] = {
            "success": True,
            "merged": True,
            "merge_commit_sha": merge_result.get("sha"),
            "status": "merged",
            "blocking_reasons": [branch_delete_error] if branch_delete_error else [],
            "failed_checks": [],
            "branch_deleted": branch_deleted,
        }

        return cast(MergeStatusOutput, remove_none_values_recursive(result_data))

    except Exception as e:
        error_message = str(e)
        if "405" in error_message or "not allowed" in error_message.lower():
            return cast(
                MergeStatusOutput,
                remove_none_values_recursive({
                    "success": False,
                    "merged": False,
                    "status": "blocked",
                    "blocking_reasons": [
                        "Merge method not allowed for this repository or pull request"
                    ],
                    "branch_deleted": False,
                }),
            )

        return cast(
            MergeStatusOutput,
            remove_none_values_recursive({
                "success": False,
                "merged": False,
                "status": "error",
                "blocking_reasons": [f"Failed to merge: {error_message}"],
                "branch_deleted": False,
            }),
        )


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # POST /repos/{owner}/{repo}/pulls/{pull_number}/reviews
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def submit_pull_request_review(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    pull_request_number: Annotated[int, "The number that identifies the pull request."],
    event: Annotated[ReviewEvent, "The review action to perform."],
    body: Annotated[
        str | None,
        "The body text of the review. Required when event is REQUEST_CHANGES or COMMENT.",
    ] = None,
) -> Annotated[ReviewOutput, "Submitted review details"]:
    """
    Submit a review for a pull request.
    """
    if event in [ReviewEvent.REQUEST_CHANGES, ReviewEvent.COMMENT] and not body:
        message = f"The 'body' parameter is required when event is {event.value}."
        raise RetryableToolError(
            message=message,
            additional_prompt_content="Please provide a body text for the review comment.",
        )

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    pr_data = await client.get_pull_request(owner, repo, pull_request_number)
    pr_author = pr_data.get("user", {}).get("login", "")

    current_user = await client.get_authenticated_user()
    current_username = current_user.get("login", "")

    if pr_author == current_username and event == ReviewEvent.APPROVE:
        message = "Cannot approve your own pull request. Please ask another user to review it."
        raise RetryableToolError(
            message=message,
            additional_prompt_content=(
                "Pull request authors cannot approve their own PRs. "
                "Request review from a collaborator instead."
            ),
        )

    review_data = await client.create_pull_request_review(
        owner=owner,
        repo=repo,
        pull_number=pull_request_number,
        event=event.value,
        body=body,
    )

    result: ReviewOutput = {
        "id": review_data.get("id", 0),
        "state": review_data.get("state", ""),
        "body": review_data.get("body", ""),
        "user": review_data.get("user", {}).get("login", ""),
        "submitted_at": review_data.get("submitted_at", ""),
        "html_url": review_data.get("html_url", ""),
    }

    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # POST/DELETE /repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def manage_pull_request_reviewers(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    pull_request_number: Annotated[int, "The number that identifies the pull request."],
    add_reviewers: Annotated[list[str] | None, "List of user logins to add as reviewers."] = None,
    add_team_reviewers: Annotated[
        list[str] | None, "List of team slugs to add as reviewers."
    ] = None,
    remove_reviewers: Annotated[
        list[str] | None, "List of user logins to remove as reviewers."
    ] = None,
    remove_team_reviewers: Annotated[
        list[str] | None, "List of team slugs to remove as reviewers."
    ] = None,
) -> Annotated[ReviewersOutput, "Updated reviewers information"]:
    """
    Manage reviewers for a pull request.
    """
    if not any([add_reviewers, add_team_reviewers, remove_reviewers, remove_team_reviewers]):
        raise ToolExecutionError(
            "At least one of add_reviewers, add_team_reviewers, remove_reviewers, "
            "or remove_team_reviewers must be provided."
        )

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    pr_data = await client.get_pull_request(owner, repo, pull_request_number)
    pr_author = pr_data.get("user", {}).get("login", "")

    if add_reviewers or add_team_reviewers:
        if add_reviewers and pr_author in add_reviewers:
            message = (
                f"Cannot request review from '{pr_author}' - they are the PR author. "
                f"Please select a different user to review this PR."
            )
            raise RetryableToolError(
                message=message,
                additional_prompt_content=(
                    "Choose a different user who is not the PR author. "
                    "You may want to list repository collaborators first."
                ),
            )

        await client.request_pull_request_reviewers(
            owner, repo, pull_request_number, add_reviewers, add_team_reviewers
        )

    if remove_reviewers or remove_team_reviewers:
        await client.remove_pull_request_reviewers(
            owner, repo, pull_request_number, remove_reviewers, remove_team_reviewers
        )
    updated_pr_data = await client.get_pull_request(owner, repo, pull_request_number)
    requested_reviewers = [
        u.get("login", "")
        for u in cast(list[dict[str, Any]], updated_pr_data.get("requested_reviewers", []))
    ]
    requested_teams = [
        t.get("slug", "")
        for t in cast(list[dict[str, Any]], updated_pr_data.get("requested_teams", []))
    ]

    result: ReviewersOutput = {
        "requested_reviewers": requested_reviewers,
        "requested_team_reviewers": requested_teams,
        "reviewers_added": add_reviewers or [],
        "teams_added": add_team_reviewers or [],
        "reviewers_removed": remove_reviewers or [],
        "teams_removed": remove_team_reviewers or [],
    }

    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # POST /repos/{owner}/{repo}/issues/{issue_number}/assignees, GET .../assignees
            "read:org",  # GET /search/users, GET /repos/{owner}/{repo}/collaborators
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def assign_pull_request_user(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    pull_request_number: Annotated[int, "The number that identifies the pull request."],
    assignee_identifier: Annotated[str, "The user identifier: username, email, name, or ID."],
    search_mode: Annotated[UserSearchMode, "How to interpret the assignee_identifier."],
    auto_accept_matches: Annotated[
        bool,
        f"Auto-accept fuzzy matches above {FUZZY_AUTO_ACCEPT_CONFIDENCE} confidence. "
        "Default is False",
    ] = False,
) -> Annotated[AssigneeOutput, "Assignment result with user details or suggestions"]:
    """
    Assign a user to a pull request with intelligent search and fuzzy matching.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    auto_accept = (
        FUZZY_AUTO_ACCEPT_CONFIDENCE if auto_accept_matches else DISABLE_AUTO_ACCEPT_THRESHOLD
    )

    user, suggestions, scope = await user_resolution_utils.resolve_user(
        client,
        owner,
        repo,
        assignee_identifier,
        search_mode.value,
        FUZZY_MATCH_THRESHOLD,
        auto_accept,
    )

    if not user and not suggestions:
        message = f"Could not find any users matching '{assignee_identifier}' in the repository."
        raise RetryableToolError(
            message=message,
            additional_prompt_content=(
                "Try using a different search mode or check the identifier spelling. "
                "You may want to list repository collaborators first."
            ),
        )

    if not user:
        suggestions_list = [
            f"  - {s.get('login', 'unknown')} ({s.get('name', 'No name')}) "
            f"- confidence: {s.get('confidence_score', 0):.2f}"
            for s in suggestions[:10]
        ]
        suggestions_text = "\n".join(suggestions_list)

        message = (
            f"No confident match found for '{assignee_identifier}'. "
            f"Top suggestions:\n{suggestions_text}"
        )
        raise RetryableToolError(
            message=message,
            additional_prompt_content=(
                "Please select one of the suggested usernames and try again using "
                "search_mode='username'."
            ),
        )

    username = user.get("login", "")

    validation_performed = await client.check_assignee(owner, repo, username)

    if not validation_performed:
        message = f"User '{username}' cannot be assigned to issues in {owner}/{repo}."
        raise RetryableToolError(
            message=message,
            additional_prompt_content=(
                "This user may not have the required permissions. "
                "Try a different user or check repository settings."
            ),
        )

    await client.add_issue_assignees(owner, repo, pull_request_number, [username])

    result: AssigneeOutput = {
        "success": True,
        "assigned_user": cast(UserData, user_resolution_utils.map_user_to_data(user)),
        "suggestions": [],
        "search_scope": scope,
        "validation_performed": validation_performed,
    }

    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # GET /repos/{owner}/{repo}/pulls/{pull_number}, GET .../commits/{ref}/status
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def check_pull_request_merge_status(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    pull_request_number: Annotated[int, "The number that identifies the pull request."],
    include_check_details: Annotated[
        bool, "Include individual check run details in the response. Default is False."
    ] = False,
) -> Annotated[MergeCheckOutput, "Comprehensive merge readiness status"]:
    """
    Check if a pull request is ready to merge without attempting the merge.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    pr_data = await client.get_pull_request(owner, repo, pull_request_number)

    mergeable = cast(bool | None, pr_data.get("mergeable"))
    mergeable_state = cast(str, pr_data.get("mergeable_state", "unknown"))
    head_sha = pr_data.get("head", {}).get("sha", "")

    try:
        combined_status = await client.get_combined_status(owner, repo, head_sha)
        check_runs = await client.list_check_runs_for_ref(owner, repo, head_sha, per_page=100)
    except Exception:
        combined_status = {}
        check_runs = {}

    checks_summary, failed_checks = pr_lifecycle_utils.aggregate_check_status(
        combined_status, check_runs
    )
    reviews_summary = pr_lifecycle_utils.extract_reviews_summary(cast(dict[str, Any], pr_data))

    blocking_reasons = pr_lifecycle_utils.format_blocking_reasons(
        mergeable, mergeable_state, checks_summary, failed_checks, reviews_summary
    )

    suggested_actions = pr_lifecycle_utils.suggest_actions(blocking_reasons, mergeable_state)

    ready_to_merge = (
        mergeable is not None
        and mergeable
        and mergeable_state in ["clean", "unstable"]
        and checks_summary.get("conclusion") in ["success", "none"]
        and reviews_summary.get("requirements_met", True)
    )

    conflicts = mergeable_state == "dirty"

    checks_details = []
    if include_check_details:
        for status in combined_status.get("statuses", []):
            checks_details.append({
                "name": status.get("context", ""),
                "status": "completed",
                "conclusion": status.get("state", ""),
                "html_url": status.get("target_url", ""),
            })

        for check_run in check_runs.get("check_runs", []):
            checks_details.append({
                "name": check_run.get("name", ""),
                "status": check_run.get("status", ""),
                "conclusion": check_run.get("conclusion", ""),
                "html_url": check_run.get("html_url", ""),
            })

    result: MergeCheckOutput = cast(
        MergeCheckOutput,
        {
            "ready_to_merge": ready_to_merge,
            "mergeable": mergeable,
            "mergeable_state": mergeable_state,
            "checks_summary": checks_summary,
            "checks_details": checks_details,
            "reviews_summary": reviews_summary,
            "conflicts": conflicts,
            "behind_by": None,
            "blocking_reasons": blocking_reasons,
            "suggested_actions": suggested_actions,
        },
    )

    return cast(MergeCheckOutput, remove_none_values_recursive(result))
