from typing import Annotated

import httpx
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.errors import RetryableToolError, ToolExecutionError

from arcade_github.constants import (
    DISABLE_AUTO_ACCEPT_THRESHOLD,
    FUZZY_AUTO_ACCEPT_CONFIDENCE,
)
from arcade_github.models.mappers import (
    map_activity,
    map_collaborator,
    map_repository,
    map_review_comment_for_repos,
    map_team,
)
from arcade_github.models.models import (
    ActivityType,
    CollaboratorAffiliation,
    CollaboratorDetailLevel,
    CollaboratorPermission,
    RepoSearchScope,
    RepoSortProperty,
    RepoTimePeriod,
    RepoType,
    ReviewCommentSortProperty,
    SortDirection,
)
from arcade_github.models.tool_outputs.repositories import (
    ActivitiesListOutput,
    CollaboratorsListOutput,
    RepoSearchOutput,
    RepositoriesListOutput,
    RepositoryOutput,
    ReviewCommentsOutput,
)
from arcade_github.utils import repo_utils, repositories_utils
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.date_utils import parse_flexible_date
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.response_utils import remove_none_values_recursive
from arcade_github.utils.user_resolution_utils import get_all_repository_users


@tool(
    requires_auth=get_github_auth(),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def count_stargazers(
    context: ToolContext,
    owner: Annotated[str, "The owner of the repository"],
    name: Annotated[str, "The name of the repository"],
) -> Annotated[int, "The number of stargazers (stars) for the specified repository"]:
    """Count the number of stargazers (stars) for a GitHub repository."""
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    data = await client.get_repository(owner=owner, repo=name)
    stargazers_count = data.get("stargazers_count", 0)
    return int(stargazers_count)


@tool(
    requires_auth=get_github_auth(),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_org_repositories(
    context: ToolContext,
    org: Annotated[str, "The organization name. The name is not case sensitive"],
    repo_type: Annotated[
        RepoType, "The types of repositories you want returned. Default is all repositories."
    ] = RepoType.ALL,
    sort: Annotated[
        RepoSortProperty, "The property to sort the results by. Default is created."
    ] = RepoSortProperty.CREATED,
    sort_direction: Annotated[
        SortDirection, "The order to sort by. Default is asc."
    ] = SortDirection.ASC,
    per_page: Annotated[int, "The number of results per page. Default is 30."] = 30,
    page: Annotated[int, "The page number of the results to fetch. Default is 1."] = 1,
) -> Annotated[RepositoriesListOutput, "List of organization repositories"]:
    """List repositories for the specified organization."""
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page), 100)
    repos = await client.list_organization_repositories(
        org=org,
        repo_type=repo_type.value,
        sort=sort.value,
        direction=sort_direction.value,
        per_page=per_page,
        page=page,
    )

    result: RepositoriesListOutput = {"repositories": [map_repository(repo) for repo in repos]}
    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_repository(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
) -> Annotated[RepositoryOutput, "Repository details"]:
    """Get a repository.

    Retrieves detailed information about a repository using the GitHub API.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    repo_data = await client.get_repository(owner=owner, repo=repo)
    return remove_none_values_recursive(map_repository(repo_data))


@tool(
    requires_auth=get_github_auth(),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_repository_activities(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    direction: Annotated[
        SortDirection | None, "The direction to sort the results by. Default is desc."
    ] = SortDirection.DESC,
    per_page: Annotated[int, "The number of results per page (max 100). Default is 30."] = 30,
    before: Annotated[
        str | None,
        "A cursor (unique ID, e.g., a SHA of a commit) to search for results before this cursor.",
    ] = None,
    after: Annotated[
        str | None,
        "A cursor (unique ID, e.g., a SHA of a commit) to search for results after this cursor.",
    ] = None,
    ref: Annotated[
        str | None,
        "The Git reference for the activities you want to list. The ref for a branch can be "
        "formatted either as refs/heads/BRANCH_NAME or BRANCH_NAME, where BRANCH_NAME is the name "
        "of your branch.",
    ] = None,
    actor: Annotated[
        str | None, "The GitHub username to filter by the actor who performed the activity."
    ] = None,
    time_period: Annotated[RepoTimePeriod | None, "The time period to filter by."] = None,
    activity_type: Annotated[ActivityType | None, "The activity type to filter by."] = None,
) -> Annotated[ActivitiesListOutput, "List of repository activities"]:
    """List repository activities.

    Retrieves a detailed history of changes to a repository, such as pushes, merges,
    force pushes, and branch changes, and associates these changes with commits and users.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page), 100)
    activities = await client.list_repository_activities(
        owner=owner,
        repo=repo,
        direction=direction.value if direction else None,
        per_page=per_page,
        before=before,
        after=after,
        ref=ref,
        actor=actor,
        time_period=time_period.value if time_period else None,
        activity_type=activity_type.value if activity_type else None,
    )

    result: ActivitiesListOutput = {
        "activities": [map_activity(activity) for activity in activities]
    }
    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_review_comments_in_a_repository(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    sort: Annotated[
        ReviewCommentSortProperty | None, "The property to sort the results by. Default is created."
    ] = ReviewCommentSortProperty.CREATED,
    direction: Annotated[
        SortDirection | None,
        "The direction to sort results. Ignored without sort parameter. Default is desc.",
    ] = SortDirection.DESC,
    since: Annotated[
        str | None,
        "Only show results updated after this time. "
        "Supports: relative dates ('today', 'yesterday', 'last_week', 'last_30_days'), "
        "ISO 8601 ('2025-11-10T00:00:00Z'), or simple dates ('2025-11-10').",
    ] = None,
    per_page: Annotated[int, "The number of results per page (max 100). Default is 30."] = 30,
    page: Annotated[int, "The page number of the results to fetch. Default is 1."] = 1,
) -> Annotated[ReviewCommentsOutput, "List of review comments in the repository"]:
    """
    List review comments in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    parsed_since = parse_flexible_date(since) if since else None

    per_page = min(max(1, per_page), 100)
    review_comments = await client.list_repository_review_comments(
        owner=owner,
        repo=repo,
        sort=sort.value if sort else None,
        direction=direction.value if direction else None,
        since=parsed_since,
        per_page=per_page,
        page=page,
    )

    result: ReviewCommentsOutput = {
        "review_comments": [map_review_comment_for_repos(comment) for comment in review_comments]
    }
    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # GET /repos/{owner}/{repo}/collaborators, /teams (for private repos)
            "read:org",  # For organization repositories and teams
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_repository_collaborators(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    affiliation: Annotated[
        CollaboratorAffiliation | None,
        "Filter by affiliation type. Default is all.",
    ] = None,
    permission: Annotated[
        CollaboratorPermission | None,
        "Filter by permission level. Default returns all permission levels.",
    ] = None,
    detail_level: Annotated[
        CollaboratorDetailLevel,
        "Detail level to include when listing collaborators. Default is include_org_members.",
    ] = CollaboratorDetailLevel.INCLUDE_ORG_MEMBERS,
    include_teams: Annotated[
        bool,
        "Include teams that have access to the repository. Teams can be requested as "
        "reviewers using their slug. Default is True.",
    ] = True,
    per_page: Annotated[int, "Number of collaborators per page (max 100). Default is 30."] = 30,
    page: Annotated[int, "Page number of results to fetch. Default is 1."] = 1,
) -> Annotated[
    CollaboratorsListOutput, "List of repository collaborators and teams who can review PRs"
]:
    """
    List collaborators for a repository.

    Returns users who have access to the repository and can be requested as reviewers
    for pull requests. Useful for discovering who can review your PR.

    Detail levels:
    - basic: Only explicit collaborators (fast, minimal API calls)
    - include_org_members: Add all org members (default, moderate API calls)
    - full_profiles: Add org members + enrich with names/emails (slow, many API calls)
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page), 100)
    page = max(1, page)

    include_org_members = detail_level != CollaboratorDetailLevel.BASIC
    enrich_profiles = detail_level == CollaboratorDetailLevel.FULL_PROFILES

    all_users, org_members_error = await get_all_repository_users(
        client=client,
        owner=owner,
        repo=repo,
        include_org_members=include_org_members,
        enrich_profiles=enrich_profiles,
        max_enrich=100,
        affiliation=affiliation.value if affiliation else None,
        permission=permission.value if permission else None,
        per_page=per_page,
        page=page,
    )

    collaborators_raw = all_users

    result: CollaboratorsListOutput = {
        "collaborators": [map_collaborator(collab) for collab in all_users],
        "total_collaborators": len(all_users),
        "pagination": {
            "page": page,
            "per_page": per_page,
            "has_next_page": len(collaborators_raw) == per_page,
        },
    }

    if org_members_error:
        result["org_members_error"] = org_members_error

    if include_teams:
        try:
            teams = await client.list_repository_teams(
                owner=owner,
                repo=repo,
                per_page=100,
                page=1,
            )
            result["teams"] = [map_team(team) for team in teams]
            result["total_teams"] = len(teams)
        except httpx.HTTPStatusError as e:
            result["teams"] = []
            result["total_teams"] = 0
            if e.response.status_code == 403:
                result["teams_error"] = (
                    "403 Forbidden: Missing 'Organization → Members (read)' permission. "
                    "GitHub Apps require this organization-level permission to access team data. "
                    "Add the permission in your app settings and get org admin approval."
                )
            elif e.response.status_code == 404:
                result["teams_error"] = (
                    "404 Not Found: This repository might not be organization-owned. "
                    "Teams are only available for organization repositories."
                )
            else:
                result["teams_error"] = f"Unable to fetch teams: HTTP {e.response.status_code}"
        except Exception as e:
            result["teams"] = []
            result["total_teams"] = 0
            result["teams_error"] = f"Unable to fetch teams: {e!s}"

    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(scopes=["repo", "read:org"]),
    requires_secrets=["GITHUB_SERVER_URL"],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.SOURCE_CODE],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def search_my_repos(
    context: ToolContext,
    repo_name: Annotated[str, "Repository name or partial name to search for"],
    scope: Annotated[
        RepoSearchScope,
        "Where to search. Default is all.",
    ] = RepoSearchScope.ALL,
    organization: Annotated[
        str | None,
        (
            "Organization name when scope is 'organization'. "
            "If omitted, searches all of your organizations."
        ),
    ] = None,
    auto_accept_matches: Annotated[
        bool,
        (
            f"Auto-accept fuzzy matches above {FUZZY_AUTO_ACCEPT_CONFIDENCE} confidence. "
            "Default is False"
        ),
    ] = False,
    include_recent_branches: Annotated[
        int,
        "Include up to this many recent branches per repository (0 disables, default 10, max 30).",
    ] = 10,
) -> Annotated[RepoSearchOutput, "Fuzzy repository search results"]:
    """
    Search repositories accessible to the authenticated user with fuzzy matching.
    """

    search_term = repo_name.strip()
    if not search_term:
        raise RetryableToolError(
            message="Please provide a repository name to search for.",
            additional_prompt_content="Try specifying part of the repository name, e.g., 'tools'.",
        )

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    user_data = await client.get_authenticated_user()
    username = user_data.get("login")
    if not username:
        raise ToolExecutionError("Unable to determine the authenticated user.")

    needs_orgs = scope != RepoSearchScope.PERSONAL or organization is not None
    user_org_logins: list[str] = []

    if needs_orgs:
        user_org_logins = await repo_utils.get_user_org_logins(client)

    org_targets = repo_utils.resolve_org_targets(scope, organization, user_org_logins)

    repo_sources = await repo_utils.collect_repo_sources(
        client=client,
        scope=scope,
        username=username,
        org_logins=org_targets,
    )

    if not repo_sources:
        raise RetryableToolError(
            message="No repositories found for the selected scope.",
            additional_prompt_content=(
                "Try changing the scope or verify that you have access to repositories."
            ),
        )

    matches = repo_utils.score_repository_sources(repo_sources, search_term)
    auto_accept_threshold = (
        FUZZY_AUTO_ACCEPT_CONFIDENCE if auto_accept_matches else DISABLE_AUTO_ACCEPT_THRESHOLD
    )
    best_match, suggestions = repo_utils.select_best_match(matches, auto_accept_threshold)

    sources_list = sorted({source.source for source in repo_sources})

    branch_limit = min(max(include_recent_branches, 0), 30)

    result = await repositories_utils.build_repo_search_result(
        client=client,
        scope_value=scope.value,
        repo_sources=repo_sources,
        best_match=best_match,
        suggestions=suggestions,
        branch_limit=branch_limit,
        sources_list=sources_list,
    )

    return remove_none_values_recursive(result)
