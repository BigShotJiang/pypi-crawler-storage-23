"""Version information for pulse-openai."""

__version__ = "0.1.0"
__version_info__ = (0, 1, 0)
