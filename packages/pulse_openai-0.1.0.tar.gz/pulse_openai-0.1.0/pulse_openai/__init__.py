"""
PULSE-OpenAI Adapter.

Bridge PULSE Protocol messages to OpenAI API.
Send a PULSE message, get an AI response — zero OpenAI boilerplate.

Example:
    >>> from pulse_openai import OpenAIAdapter
    >>> adapter = OpenAIAdapter(api_key="sk-...")
    >>> from pulse import PulseMessage
    >>> msg = PulseMessage(action="ACT.QUERY.DATA", parameters={"query": "What is PULSE?"})
    >>> response = adapter.send(msg)
    >>> print(response.content["parameters"]["result"])
"""

from pulse_openai.adapter import OpenAIAdapter
from pulse_openai.version import __version__

__all__ = ["OpenAIAdapter", "__version__"]
