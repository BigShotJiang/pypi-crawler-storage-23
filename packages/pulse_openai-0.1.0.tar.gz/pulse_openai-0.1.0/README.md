# pulse-openai

OpenAI adapter for [PULSE Protocol](https://github.com/pulseprotocolorg-cyber/pulse-python).

Send PULSE semantic messages, get AI responses. Zero OpenAI boilerplate.

## Install

```bash
pip install pulse-openai
```

## Quick Start

```python
from pulse import PulseMessage
from pulse_openai import OpenAIAdapter

adapter = OpenAIAdapter(api_key="sk-...")

# Ask a question
msg = PulseMessage(
    action="ACT.QUERY.DATA",
    parameters={"query": "What is quantum computing?"}
)
response = adapter.send(msg)
print(response.content["parameters"]["result"])

# Analyze sentiment
msg = PulseMessage(
    action="ACT.ANALYZE.SENTIMENT",
    parameters={"text": "I love this product!"}
)
response = adapter.send(msg)
print(response.content["parameters"]["result"])
```

## Supported Actions

| PULSE Action | What it does | Default Model |
|---|---|---|
| `ACT.QUERY.DATA` | Ask a question | gpt-4o-mini |
| `ACT.CREATE.TEXT` | Generate text | gpt-4o |
| `ACT.ANALYZE.SENTIMENT` | Analyze sentiment | gpt-4o-mini |
| `ACT.ANALYZE.PATTERN` | Find patterns | gpt-4o |
| `ACT.TRANSFORM.TRANSLATE` | Translate text | gpt-4o-mini |
| `ACT.TRANSFORM.SUMMARIZE` | Summarize text | gpt-4o-mini |

## Parameters

```python
# Override model
parameters={"query": "...", "model": "gpt-4o"}

# Set temperature
parameters={"query": "...", "temperature": 0.9}

# Limit tokens
parameters={"query": "...", "max_tokens": 500}

# Custom system prompt
parameters={"text": "...", "system_prompt": "You are a helpful assistant."}

# Translation target
parameters={"text": "Hello!", "target_language": "Spanish"}
```

## Why?

Your code speaks PULSE. Today it uses OpenAI. Tomorrow you swap in `pulse-anthropic` or `pulse-local` — zero code changes.

```python
# adapter = OpenAIAdapter(api_key="sk-...")
adapter = AnthropicAdapter(api_key="sk-ant-...")  # Same code works
```

## License

Apache 2.0
