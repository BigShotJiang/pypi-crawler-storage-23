"""Custom exceptions."""


class DatabaseError(Exception):
    pass
