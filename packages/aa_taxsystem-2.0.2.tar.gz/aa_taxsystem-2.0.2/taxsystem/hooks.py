"""AA Hooks"""
