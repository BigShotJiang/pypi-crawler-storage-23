## [0.12.7](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.6...v0.12.7) (2026-02-21)


### Bug Fixes

* add laps readers to table and adjust maq text ([2586914](https://github.com/l4rm4nd/PyADRecon/commit/25869149ce6a8c16923b3cace2bcb0e1e5db5025))

## [0.12.6](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.5...v0.12.6) (2026-02-21)


### Bug Fixes

* hide non-issue tiles and add maq finding ([9929546](https://github.com/l4rm4nd/PyADRecon/commit/9929546c58bfe7d29d70e0ecf7be045bf244b2be))

## [0.12.5](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.4...v0.12.5) (2026-02-21)


### Bug Fixes

* counter for security findings in navigation ([b856c3d](https://github.com/l4rm4nd/PyADRecon/commit/b856c3d4395b093cb0545c8ed716aaed3f868223))

## [0.12.4](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.3...v0.12.4) (2026-02-21)


### Bug Fixes

* show detected cleartext pws in description/info fields ([d681224](https://github.com/l4rm4nd/PyADRecon/commit/d6812246687d1c73af910dbc906b3a843cf7a7f1))

## [0.12.3](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.2...v0.12.3) (2026-02-21)


### Bug Fixes

* add krbtgt rotation and protected users group to dashboard ([03e3046](https://github.com/l4rm4nd/PyADRecon/commit/03e30466f1f1f9033e0aa3341dba7521f855a62e))

