from outlook_desktop_mcp.server import main

main()
