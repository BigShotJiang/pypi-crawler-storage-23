from .pipeline import ChunkingPipeline

__all__ = ["ChunkingPipeline"]
