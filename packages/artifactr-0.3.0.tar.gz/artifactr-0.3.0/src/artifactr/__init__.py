"""Artifactr - CLI tool for managing AI project artifacts."""

__version__ = "0.3.0"
