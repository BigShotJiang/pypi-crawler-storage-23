
compression_extension_list = [".zip", ".tgz", ".tar.gz", ".gz", ".rar", ".7z"]
archive_extension_list = [".zip", ".tgz", ".tar.gz", ".rar", ".7z"]
common_dataset_extensions = [
    ".csv",
    ".xlsx",
    ".xls",
    ".ods",
    ".shp",
    ".gpkg",
    ".geojson",
]
