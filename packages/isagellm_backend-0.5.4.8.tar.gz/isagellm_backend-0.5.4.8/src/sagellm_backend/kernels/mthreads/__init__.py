"""Moore Threads MUSA kernels module.

Provides optimized kernel wrappers for Moore Threads MTT GPU devices using MUSA.
MUSA (Moore Threads Unified System Architecture) provides a CUDA-like programming
model for Moore Threads GPUs (MTT S80, S4000 series).

Key kernels:
- GEMM/MatMul via MUSA BLAS
- Attention via torch_musa SDPA
- Normalization (RMSNorm, LayerNorm)

Supported dtypes:
  - FP32, FP16, INT8 (BF16 varies by device generation)
"""

from __future__ import annotations

from sagellm_backend.kernels.mthreads.attention import MThreadsAttentionKernel
from sagellm_backend.kernels.mthreads.matmul import MThreadsGemmKernel, MThreadsMatMulKernel

__all__ = [
    "MThreadsMatMulKernel",
    "MThreadsGemmKernel",
    "MThreadsAttentionKernel",
]
