"""华为昇腾 CANN 算子实现。

本模块提供基于 CANN (Compute Architecture for Neural Networks) 的算子实现：
- CANNAttentionKernel: 基于 CANN 的 Attention 算子
- CANNMatMulKernel: 基于 CANN 的 MatMul/GEMM 算子

这些算子利用昇腾 NPU 的专有特性：
- AI Core: 矢量和张量计算单元
- Cube Engine: 矩阵乘法加速单元
- Vector Core: SIMD 向量处理单元
- TIK (Tensor Iterator Kernel): 昇腾算子开发语言

依赖:
    - torch_npu: PyTorch 昇腾扩展
    - CANN Toolkit: 昇腾计算架构工具包

Example:
    >>> from sagellm_backend.kernels.ascend import CANNAttentionKernel
    >>> attn_kernel = CANNAttentionKernel()
    >>> output = attn_kernel(query, key, value, attn_mask)
"""

from __future__ import annotations

from sagellm_backend.kernels.ascend.attention import CANNAttentionKernel
from sagellm_backend.kernels.ascend.matmul import CANNMatMulKernel

__all__ = [
    "CANNAttentionKernel",
    "CANNMatMulKernel",
]
