"""Version information for sagellm-backend."""

__version__ = "0.5.4.8"
