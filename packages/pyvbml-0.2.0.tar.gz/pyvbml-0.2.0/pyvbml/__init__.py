"""Python VBML module."""

from __future__ import annotations

from . import vbml
from .types import Align, Justify

__all__ = ["vbml", "Align", "Justify"]

__version__ = "0.2.0"
