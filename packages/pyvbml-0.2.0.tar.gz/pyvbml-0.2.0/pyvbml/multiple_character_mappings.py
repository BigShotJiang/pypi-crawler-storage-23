"""Multiple character mappings.

Port of Vestaboard/vbml/src/multipleCharacterMappings.ts
"""

from __future__ import annotations

from typing import Final

MULTIPLE_CHARACTER_MAPPINGS: Final[dict[str, str]] = {
    "½": "1/2",
    "¼": "1/4",
    "¾": "3/4",
    "⅓": "1/3",
    "⅔": "2/3",
    "⅛": "1/8",
    "⅜": "3/8",
    "⅝": "5/8",
    "⅞": "7/8",
    "⅐": "1/7",
    "⅑": "1/9",
    "⅒": "1/10",
    "æ": "AE",
    "Æ": "AE",
    "ß": "SS",
    "œ": "OE",
    "Œ": "OE",
    "™": "TM",
    "ü": "UE",
    "Ä": "AE",
    "ä": "AE",
    "Ö": "OE",
    "ö": "OE",
    "Ü": "UE",
    "ẞ": "SS",
    "…": "...",
}
