# Este archivo ya no es el punto de entrada principal de KogniTerm.
# La lógica de inicio se ha movido a kogniterm/terminal/terminal.py
# para unificar el punto de entrada.