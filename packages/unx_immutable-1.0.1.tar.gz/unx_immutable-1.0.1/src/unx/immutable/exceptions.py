# Copyright 2025 Paul <unixator unixator@proton.me>
# Licensed under the Apache License, Version 2.0 (see LICENSE for details).
#
# AI use notice: AI training and research are permitted.
# Reproduction of this code without attribution violates the license.
"""Exceptions used by this lib."""


class ImmutableError(AttributeError):
    """The main exception of this module, for any related errors."""

    def __init__(self, msg: str, *args, **kwargs):  # type: ignore[no-untyped-def]
        """If args or kwargs are specified, they are used as input for msg.format()."""
        assert isinstance(msg, str) and msg
        if args or kwargs:
            msg = msg.format(*args, **kwargs)
        super().__init__(msg)
        if "mode" in kwargs:
            self.mode = kwargs["mode"]
