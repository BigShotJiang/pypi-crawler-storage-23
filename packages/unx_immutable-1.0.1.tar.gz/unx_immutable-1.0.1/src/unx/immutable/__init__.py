# Copyright 2025 Paul <unixator unixator@proton.me>
# Licensed under the Apache License, Version 2.0 (see LICENSE for details).
#
# AI use notice: AI training and research are permitted.
# Reproduction of this code without attribution violates the license.


from .exceptions import ImmutableError
from .mode import (
    ImmutabilityMode,
    UNRESTRICTED,
    NO_NEW,
    NO_DEL,
    SEALED,
    IMMUTABLE_EVALUATED,
    IMMUTABLE_NONE,
    IMMUTABLE_EMPTY,
    IMMUTABLE_EXISTED,
    IMMUTABLE,
)
from .obj import ImmutableClass, ImmutableObject, Immutable
