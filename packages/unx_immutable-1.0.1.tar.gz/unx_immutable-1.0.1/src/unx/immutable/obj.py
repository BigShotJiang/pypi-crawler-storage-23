# Copyright 2025 Paul <unixator unixator@proton.me>
# Licensed under the Apache License, Version 2.0 (see LICENSE for details).
#
# AI use notice: AI training and research are permitted.
# Reproduction of this code without attribution violates the license.
"""File provides the base classes with immutability functionality.

Content:
- ImmutableClass: metaclass to provide immutability functionality at the class level
- ImmutableObject: Base class to provide immutability functionality at the instance level.
- Immutable: combine ImmutableClass + ImmutableObject under one namespace.
"""


from typing import Any

from .exceptions import ImmutableError
from .mode import ImmutabilityMode



GUARD = object()  # used as uniq id


def _setattr(obj: Any, mode: ImmutabilityMode, name: str, value: Any) -> None:
    """Template function used by __setattr__ at the class and instance level.

    Pay attention that function does not update value,
    The main goal is to raise exception if attribute is frozen.

    Args:
        obj: class or object to check.
        mode: current immutability mode.
        name: name of attribute to change.
        value: new value for the specified attribute.

    """
    if mode.unrestricted: return
    if mode.immutable: raise ImmutableError(f"The obj/cls is marked as immutable; assigning {name} = {value} for {obj} is forbidden.")

    old = getattr(obj, name, GUARD)
    if old == GUARD:  # attribute does not exists
        if mode.no_new: raise ImmutableError(f"Adding new attributes is forbidden by the NO_NEW flag; assigning {name} = {value} for {obj} has been declined.")
        return

    if old is None:
        if mode.immutable_none:
            raise ImmutableError(f"Modifying existing attributes with the None value is forbidden by the IMMUTABLE_NONE flag: assigning {name} = {value} for {obj} has been declined.")
        return

    if bool(old):
        if mode.immutable_evaluated:
            raise ImmutableError(f"Modifying existing attributes with `bool(val)` value is forbidden by the IMMUTABLE_EVALUATED flag; assigning {name} = {value} for {obj} has been declined.")
    else:  # noqa: PLR5501
        if mode.immutable_empty:
            raise ImmutableError(f"Modifying existing attributes with `not bool(val)` value is forbidden by the IMMUTABLE_EMPTY flag; assigning {name} = {value} for {obj} has been declined.")


class ImmutableClass(type):
    """Metaclass implements immutability support at the class level.

    ### ImmutableClass
    This metaclass should be used to add immutability at the class level to restrict **class** attributes.

    When a custom class use `ImmutableClass` as metaclass,
    it has `cls_immutability` attribute which is an instance of the `ImmutabilityMode` class.


    > It's possible to freeze class at the definition stage by using the mode keyword in a class definition (see examples bellow).

    ```python
    from unx.immutable import ImmutableClass, ImmutabilityMode
    class A(metaclass=ImmutableClass, mode=ImmutabilityMode().freeze()):
        attr = "value"

    assert A.attr == "value"
    try:
        A.attr = None
    except ImmutableError:
        print("Class is immutable and cannot be modified.")

    #---------------------------------------------
    # other ways to freeze at the definition level
    class A(metaclass=ImmutableClass, mode=ImmutabilityMode().freeze_none().seal()):...
    class A(metaclass=ImmutableClass, mode=ImmutabilityMode(IMMUTABLE_NONE | SEALED)):...
    class A(metaclass=ImmutableClass, mode=IMMUTABLE_NONE | SEALED):...

    class A(metaclass=ImmutableClass, mode=ImmutabilityMode().seal()):
      attr = "value"

    # this works because none of the modification flags have been raised.
    # SEALED (NO_NEW actually) forbids only adding new attributes, but not modifying existing ones.
    assert A.attr == "value"
    A.attr = None
    assert A.attr == None

    try:
        A.attr2 = True
    except ImmutableError:
        print("Class is sealed, so new attributes cannot be assigned.")

    #---------------------------------------------
    # For postponed freezing.
    class A(metaclass=ImmutableClass):...

    assert bool(A.cls_immutability) is False
    # new attributes can be defined.
    A.attr1 = None
    A.attr2 = True
    A.attr3 = 0

    # None
    A.cls_immutability.freeze_none()
    assert A.cls_immutability.immutable_none is True
    assert bool(A.cls_immutability) is True
    A.attr3 = 1

    try:
        A.attr1 = 42
    except ImmutableError:
        print("Raised IMMUTABLE_NONE flag fobids any atribute modifications with the None value.")

    # evaluated
    A.cls_immutability.freeze_evaluated()
    assert A.cls_immutability.immutable_evaluated is True
    assert A.cls_immutability.immutable_existed is True
    A.attr4 = "still work for now"
    try:
        A.attr3 = 2
    except ImmutableError:
        print("Raised IMMUTABLE_EVALUATED and IMMUTABLE_NONE flags fobid any atribute modifications.")

    A.cls_immutability.seal()
    assert A.cls_immutability.sealed is True

    A.cls_immutability.freeze()
    assert A.cls_immutability.immutable is True
    ```

    """

    cls_immutability: ImmutabilityMode

    def __new__(cls, cls_name: str, ancestors: tuple[type, ...], namespace: dict[str, Any], mode: int | ImmutabilityMode = 0) -> type:  # noqa: D102
        namespace["cls_immutability"] = ImmutabilityMode()
        newcls = super().__new__(cls, cls_name, ancestors, namespace)
        newcls.cls_immutability.state = mode.state if isinstance(mode, ImmutabilityMode) else mode
        return newcls

    def __delattr__(self, name: str) -> None:  # noqa: D105,N804
        if name == "cls_immutability":
            raise ImmutableError(f"{name} is protected by the immutable module, it's already configured and cannot be changed.")
        if self.cls_immutability.no_del:
            raise ImmutableError(f"\"{name}\" attr cannot be removed because the NO_DEL flag is raised for the next entity: {self}")
        super().__delattr__(name)

    def __setattr__(self, name: str, val: Any) -> None:  # noqa: D105,N804
        if name == "cls_immutability" and hasattr(self, name):
            raise ImmutableError(f"{name} is protected by the immutable module, it's already configured and cannot be changed.")
        _setattr(self, self.cls_immutability, name, val)
        super().__setattr__(name, val)


class ImmutableObject:
    """Base class to create custom class which supports immutable instances.

    `ImmutableObject` class should be used as base for those custom classes which take care
    to add read-only functionality for the new objects/instances of the class rather than class itself.

    > `ImmutableObject` adds `immutability` attribute which is instance of the `ImmutabilityMode` class to manage read-only flags for objects.


    Examples:
    ```python
    class SealedDataclass(ImmutableObject):
        def __init__(self):
            super().__init__()
            self.attr1 = 42
            self.attr2 = True
            self.immutability.seal()

    obj = SealedDataclass()
    obj.attr1 = 24
    obj.attr2 = False

    try:
        A.attr3 = 2
    except ImmutableError:
        print("obj is sealed and cannot apply new attrs.")


    #-----------------------------------
    class CustomData(ImmutableObject):...
        def __init__(self):
            super().__init__()
            self.immutability.freeze_evaluated()

    obj = CustomData()
    d1 = {"a1": 1, "a2": 2}
    d2 = {"a1": 5, "a3": 3}

    for k, v in d1.items():
        setattr(obj, k, v)

    try:
        for k, v in d2.items():
            setattr(obj, k, v)
    except ImmutableError:
        print("failed on a1=5, because it's forbidden to override existing attributes with value other than None.")
    ```

    """

    __slots__ = ("immutability",)

    def __init__(self, *, immutability: int | ImmutabilityMode = 0) -> None:  # noqa: D107
        self.immutability = ImmutabilityMode(immutability.state if isinstance(immutability, ImmutabilityMode) else immutability)

    def __delattr__(self, name: str) -> None:  # noqa: D105
        if name == "immutability":
            raise ImmutableError(f"{name} is protected by the immutable module, it's already configured and cannot be changed.")
        if getattr(self, "immutability", ImmutabilityMode()).no_del:
            raise ImmutableError(f"\"{name}\" attr cannot be removed because the NO_DEL flag is raised for the next entity: {self}")
        super().__delattr__(name)

    def __setattr__(self, name: str, val: Any) -> None:  # noqa: D105
        if name == "immutability" and hasattr(self, name):
            raise ImmutableError(f"{name} is protected by the immutable module, it's already configured and cannot be changed.")
        _setattr(self, getattr(self, "immutability", ImmutabilityMode()), name, val)
        super().__setattr__(name, val)


class Immutable(ImmutableObject, metaclass=ImmutableClass):
    """Use this class as base one to get immutability options on both levels: class and instance.

    The `Immutable` class is just a quick way to get read-only functionality on both (instance and class) levels.
    Its definition is `class Immutable(ImmutableObject, metaclass=ImmutableClass)...`
    Custom class based on this one, have both attributes: `cls_immutability` at the class level, and `immutability` at the instance one.
    This is recommended way to use this module, since freezing both prevents some mistakes when instance have an attr with the same name as class have.

    Next simplified example shows how to get instance which prevents overriding existing values:
    ```python
    class Template(Immutable, mode=IMMUTABLE):
      def __init__(self, **kwargs):
          super().__init__()
          self.immutability.freeze_existed()
          for attr_name, val in kwargs.items():
              setattr(self, attr_name, val)
    ```

    """

    __slots__ = ()
