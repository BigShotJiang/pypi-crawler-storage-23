import pandas as pd


def model(dbt, session):
    return pd.DataFrame(columns=["col"])
