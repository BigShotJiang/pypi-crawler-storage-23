def multiply(value, factor):
    return value * factor
