---
title: Checker
description: A checker, to detect if a string is a url, or just a plain query.
---

# Checker

::: ongaku.ext.checker
