---
title: Creation
description: Creating custom extensions for ongaku
---

# How to create an extension

Coming soon...
