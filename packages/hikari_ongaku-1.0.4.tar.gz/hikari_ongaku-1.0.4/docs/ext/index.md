---
title: Extensions
description: Home page for extensions
---

# Extensions

This section, is all about custom ongaku extensions. This ranges from plugin support, to general helpful-ness around building an ongaku bot.
