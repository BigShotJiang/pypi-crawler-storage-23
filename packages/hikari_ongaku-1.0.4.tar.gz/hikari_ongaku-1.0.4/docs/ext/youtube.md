---
title: Youtube
description: Additional endpoints, for youtube tokens.
---

# Youtube

::: ongaku.ext.youtube