# Injection

::: ongaku.ext.injection
