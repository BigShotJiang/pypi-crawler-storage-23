---
title: API References
description: API Reference home
---

# All the API References

If you see this "![Lavalink](../assets/lavalink_logo.png){ .twemoji }" logo, anywhere within this API, that is a reference to lavalink's documentation.
