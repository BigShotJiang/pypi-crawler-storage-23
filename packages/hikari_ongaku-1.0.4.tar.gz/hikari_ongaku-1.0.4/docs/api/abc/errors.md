---
title: Errors ABC
description: Abstract Base Classes API Reference
---

# Error

::: ongaku.abc.errors
