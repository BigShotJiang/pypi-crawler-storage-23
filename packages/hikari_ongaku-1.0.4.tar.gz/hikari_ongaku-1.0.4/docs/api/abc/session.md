---
title: Session ABC
description: Abstract Base Classes API Reference
---

# Session

::: ongaku.abc.session
