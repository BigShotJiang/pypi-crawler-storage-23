---
title: Info ABC
description: Abstract Base Classes API Reference
---

# Info

::: ongaku.abc.info
