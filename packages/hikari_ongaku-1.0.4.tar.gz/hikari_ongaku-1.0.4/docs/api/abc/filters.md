---
title: Filters ABC
description: Abstract Base Classes API Reference
---

# Filters

:::ongaku.abc.filters
