---
title: Statistics ABC
description: Abstract Base Classes API Reference
---

# Statistics

::: ongaku.abc.statistics
