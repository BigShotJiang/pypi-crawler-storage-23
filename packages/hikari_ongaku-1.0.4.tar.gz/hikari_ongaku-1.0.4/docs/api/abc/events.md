---
title: Events ABC
description: Abstract Base Classes API Reference
---

# Events

:::ongaku.abc.events
