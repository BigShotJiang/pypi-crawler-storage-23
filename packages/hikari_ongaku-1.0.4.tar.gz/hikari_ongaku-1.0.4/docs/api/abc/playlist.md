---
title: Playlist ABC
description: Abstract Base Classes API Reference
---

# Playlist

::: ongaku.abc.playlist
