---
title: Handler ABC
description: Abstract Base Classes API Reference
---

# Handler

::: ongaku.abc.handler
