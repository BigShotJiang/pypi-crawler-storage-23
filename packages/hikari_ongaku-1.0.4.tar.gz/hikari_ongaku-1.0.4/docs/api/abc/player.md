---
title: Player ABC
description: Abstract Base Classes API Reference
---

# Player

::: ongaku.abc.player
