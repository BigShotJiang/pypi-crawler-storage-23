---
title: Session
description: Lavalink session handlers
---

# Session

::: ongaku.session
