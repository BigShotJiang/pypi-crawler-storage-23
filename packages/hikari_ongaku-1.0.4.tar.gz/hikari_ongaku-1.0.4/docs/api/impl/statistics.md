---
title: Statistics Impl
description: Implementation of abstract class.
---

# Statistics

::: ongaku.impl.statistics
