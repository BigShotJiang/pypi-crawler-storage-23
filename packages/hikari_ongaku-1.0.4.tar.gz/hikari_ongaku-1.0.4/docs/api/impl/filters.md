---
title: Filters Impl
description: Implementation of abstract class.
---

# Filters

::: ongaku.impl.filters