---
title: Session Impl
description: Implementation of abstract class.
---

# Session

::: ongaku.impl.session
