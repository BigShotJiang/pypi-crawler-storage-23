---
title: Player Impl
description: Implementation of abstract class.
---

# Player

::: ongaku.impl.player
