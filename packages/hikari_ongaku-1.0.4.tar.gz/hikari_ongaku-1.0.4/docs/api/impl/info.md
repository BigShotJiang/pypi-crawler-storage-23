---
title: Info Impl
description: Implementation of abstract class.
---

# Info

::: ongaku.impl.info
