---
title: Track Impl
description: Implementation of abstract class.
---

# Track

::: ongaku.impl.track
