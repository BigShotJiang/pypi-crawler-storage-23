---
title: Route Planner Impl
description: Implementation of abstract class.
---

# Route Planner

::: ongaku.impl.routeplanner
