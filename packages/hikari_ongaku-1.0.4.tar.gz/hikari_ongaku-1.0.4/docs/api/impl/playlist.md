---
title: Playlist Impl
description: Implementation of abstract class.
---

# Playlist

::: ongaku.impl.playlist
