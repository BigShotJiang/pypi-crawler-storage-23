---
title: Types
description: Types for ongaku.
---

# Types

::: ongaku.internal.types
