---
title: Errors
description: Errors and exceptions
---

# errors

::: ongaku.errors
