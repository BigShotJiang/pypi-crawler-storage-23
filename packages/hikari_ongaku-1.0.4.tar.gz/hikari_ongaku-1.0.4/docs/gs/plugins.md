---
title: Plugins
description: All plugin information, and how to make a plugin.
---

# Plugins

All of the information of how to make a custom plugin for ongaku is listed below.
