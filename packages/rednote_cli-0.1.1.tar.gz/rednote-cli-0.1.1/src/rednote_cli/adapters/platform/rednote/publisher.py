from __future__ import annotations

from rednote_cli._runtime.services import scraper_service


class RednotePublisherAdapter:
    async def publish_note(
        self,
        *,
        target: str,
        image_list: list[str],
        title: str = "",
        content: str = "",
        tags: list[str] | None = None,
        schedule_at: str | None = None,
        account_uid: str | None = None,
    ) -> dict:
        return await scraper_service.publish_note(
            target=target,
            image_list=image_list,
            title=title,
            content=content,
            tags=tags,
            schedule_at=schedule_at,
            account_uid=account_uid,
        )
