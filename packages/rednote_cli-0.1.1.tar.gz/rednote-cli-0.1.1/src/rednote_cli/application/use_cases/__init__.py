"""Use cases for CLI commands."""
