from __future__ import annotations

from rednote_cli.adapters.persistence.file_account_repo import FileAccountRepository
from rednote_cli.infra.platforms import REDNOTE_PLATFORM


def execute_account_list(only_active: bool = True) -> list[dict]:
    repo = FileAccountRepository()
    return repo.list_accounts(platform=REDNOTE_PLATFORM, only_active=only_active)
