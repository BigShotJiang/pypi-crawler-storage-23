from __future__ import annotations

import importlib.util
import platform
import shutil

from rednote_cli._runtime.common.app_utils import get_system_chrome_path
from rednote_cli._runtime.core.database.manager import init_db
from rednote_cli.infra.paths import APP_HOME, LOG_DIR, OUTPUT_DIR, configure_legacy_data_paths, ensure_runtime_dirs



def execute_doctor() -> dict:
    ensure_runtime_dirs()
    configure_legacy_data_paths()
    init_db()
    checks = {
        "python": {
            "ok": True,
            "version": platform.python_version(),
        },
        "playwright": {
            "ok": importlib.util.find_spec("playwright") is not None,
            "installed": importlib.util.find_spec("playwright") is not None,
        },
        "chrome": {
            "ok": bool(get_system_chrome_path()),
            "path": get_system_chrome_path() or "",
        },
        "uv": {
            "ok": shutil.which("uv") is not None,
            "path": shutil.which("uv") or "",
        },
        "runtime_dirs": {
            "ok": True,
            "app_home": str(APP_HOME),
            "log_dir": str(LOG_DIR),
            "output_dir": str(OUTPUT_DIR),
        },
        "storage": {
            "ok": True,
            "mode": "file_primary",
            "accounts_dir": str(APP_HOME / "accounts"),
            "settings_file": str(APP_HOME / "settings.json"),
            "task_schedules_file": str(APP_HOME / "task_schedules.json"),
        },
    }
    checks["overall_ok"] = all(item.get("ok", False) for item in checks.values() if isinstance(item, dict))
    return checks
