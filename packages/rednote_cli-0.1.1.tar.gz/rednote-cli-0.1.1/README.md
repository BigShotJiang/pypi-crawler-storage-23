# rednote-cli

Rednote 平台专用 CLI 包（独立安装、独立升级）。

## 安装

```bash
brew install pipx
pipx ensurepath
exec zsh

pipx install rednote-cli
```

## 快速开始

```bash
rednote-cli init runtime
rednote-cli doctor run --format json
rednote-cli account login
rednote-cli account status --format json
rednote-cli account list --only-active true
rednote-cli account list --only-active false
rednote-cli search note --keyword 旅行 --size 10 --sort-by latest --note-type image_text --format json
rednote-cli publish --target image --account user_001 --image-list /abs/a.jpg,/abs/b.jpg --title 标题 --content 正文 --format json
rednote-cli publish --target video --account user_001 --video /abs/demo.mp4 --title 标题 --content 正文 --format json
```

命令结构（当前版本）：
- `note` / `user` 作为详情查询入口，`search note|user` 作为统一搜索入口。
- 旧层级 `note get|search`、`user get|search` 已移除。

空参数行为（统一约定）：
- `rednote-cli note`、`rednote-cli publish`、`rednote-cli account activate` 等缺少业务参数时，输出帮助文本并返回退出码 `0`。
- 非空调用但参数非法时，返回 JSON `INVALID_ARGS`（退出码 `2`）。

`account status` 会实时打开浏览器检查登录态并刷新账号存储（`is_logged_in/check_time/storage_state`），输出结构与 `account list --only-active false` 对齐。

`account list` 的 `--only-active` 支持显式 `true|false`（默认 `true`）。

发布能力说明：
- `publish --target image`：图文发布，支持本地/URL 图片，`--account` 必填。
- `publish --target video`：视频发布，支持本地/URL 视频（仅 `mp4/mov`），`--account` 必填。

## 自动化建议

```bash
rednote-cli --format json --trace-id req-001 <command> ...
```

`--input`（面向 AI/Agent）：
- 作用：从 JSON 文件或 stdin 读取参数，适合复杂命令的程序化调用。
- 优先级：显式 CLI 参数 > `--input` JSON > 默认值。
- 范围：`--input` 不是全局参数，仅 `search note|user`、`note`、`user`、`publish` 支持。

示例：

```bash
rednote-cli --format json --trace-id req-001 search note --input payload.json
cat payload.json | rednote-cli --format json --trace-id req-002 publish --input - --account user_001
```

## 文档

完整文档请查看仓库根目录：
- `README.md`
- `DESIGN.md`
- `DEV.md`
- `USER_GUIDE.md`
