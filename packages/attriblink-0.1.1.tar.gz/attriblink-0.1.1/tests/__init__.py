"""Tests for attriblink."""
