"""Linking methods for attriblink."""

from .carino import carino_link

__all__ = ["carino_link"]
