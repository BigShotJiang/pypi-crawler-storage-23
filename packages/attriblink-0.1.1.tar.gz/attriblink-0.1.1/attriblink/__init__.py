"""attriblink - Multi-period attribution linking for portfolio returns."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .core import link
from .exceptions import (
    AlignmentError,
    AttributionError,
    EffectsSumMismatchError,
    InvalidEffectsError,
    InvalidMethodError,
    InvalidReturnsError,
    ZeroExcessReturnError,
)
from .result import AttributionResult

__version__ = "0.2.0"

__all__ = [
    "link",
    "AttributionResult",
    "AttributionError",
    "AlignmentError",
    "EffectsSumMismatchError",
    "InvalidEffectsError",
    "InvalidMethodError",
    "InvalidReturnsError",
    "ZeroExcessReturnError",
]
