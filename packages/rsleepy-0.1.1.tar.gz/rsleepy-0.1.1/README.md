# slee[py]

small commandline utility for progress bar enriched sleep
