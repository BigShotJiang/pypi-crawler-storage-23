import sys
import time

from rich.progress import track

def main():
    if len(sys.argv) < 2:
        return 1

    sleep_time = int(sys.argv[1])

    for i in track(range(sleep_time * 10), description="sleeping..."):
        time.sleep(0.1)


if __name__ == "__main__":
    raise SystemExit(main())
