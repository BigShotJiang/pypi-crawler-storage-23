"""
Playwright-compatible Browser class for Owl Browser.

Maps Playwright's Browser API to Owl Browser context lifecycle,
providing new_context() with full options mapping (proxy, viewport,
user_agent, locale, timezone_id, geolocation, permissions, color_scheme,
record_video, storage_state, extra_http_headers), new_page(), and
connection management.
"""

from __future__ import annotations

import contextlib
import json as _json
import types
from typing import TYPE_CHECKING, Any

from .context import BrowserContext

if TYPE_CHECKING:
    from ..client import OwlBrowser
    from .page import Page
    from .types import (
        BrowserContextOptions,
        Geolocation,
        ProxySettings,
        RecordVideoOptions,
        StorageState,
        ViewportSize,
    )


class Browser:
    """Represents a connected browser instance.

    Manages browser contexts (isolated sessions) and provides
    convenience methods for creating pages. Each Browser holds a
    reference to the underlying OwlBrowser client for tool execution.

    Supports the full Playwright Browser API surface: new_context
    with comprehensive options mapping, new_page convenience method,
    context listing, version info, connection status, and graceful
    shutdown.
    """

    __slots__ = ("_client", "_contexts", "_connected", "_version")

    def __init__(self, client: OwlBrowser) -> None:
        """Initialize Browser.

        Args:
            client: Connected OwlBrowser client instance.
        """
        self._client = client
        self._contexts: list[BrowserContext] = []
        self._connected = True
        self._version = "owl-browser"

    # ---- Async context manager ----

    async def __aenter__(self) -> Browser:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: types.TracebackType | None,
    ) -> None:
        await self.close()

    # ---- Properties ----

    @property
    def contexts(self) -> list[BrowserContext]:
        """All open browser contexts."""
        return list(self._contexts)

    @property
    def version(self) -> str:
        """The browser engine version string."""
        return self._version

    # ---- Context management ----

    async def new_context(self, **kwargs: Any) -> BrowserContext:
        """Create a new isolated browser context.

        Each context gets its own cookies, storage, proxy, and
        fingerprint configuration. Maps BrowserContextOptions to
        Owl Browser create_context parameters.

        Supported options:
            proxy: ProxySettings (server, username, password, bypass)
            viewport: ViewportSize (width, height) or None
            user_agent: Custom User-Agent string
            locale: Browser locale (e.g., 'en-US')
            timezone_id: IANA timezone (e.g., 'America/New_York')
            geolocation: Geolocation dict (latitude, longitude, accuracy)
            permissions: List of permission strings
            color_scheme: 'light', 'dark', or 'no-preference'
            device_scale_factor: Device pixel ratio
            is_mobile: Enable mobile emulation
            has_touch: Enable touch events
            java_script_enabled: Enable/disable JavaScript
            ignore_https_errors: Ignore TLS certificate errors
            extra_http_headers: Headers to send with every request
            record_video: RecordVideoOptions (dir, size)
            storage_state: StorageState or path to JSON file
            base_url: Base URL for relative navigations
            service_workers: 'allow' or 'block'
            bypass_csp: Bypass Content Security Policy

        Args:
            **kwargs: BrowserContextOptions.

        Returns:
            A new BrowserContext instance.
        """
        params: dict[str, Any] = {}

        # -- Proxy mapping --
        proxy = kwargs.get("proxy")
        if isinstance(proxy, dict):
            server = proxy.get("server", "")
            if server:
                if "://" in server:
                    proto, rest = server.split("://", 1)
                    params["proxy_type"] = proto.lower()
                    if ":" in rest:
                        host, port = rest.rsplit(":", 1)
                        params["proxy_host"] = host
                        params["proxy_port"] = port
                    else:
                        params["proxy_host"] = rest
                else:
                    params["proxy_host"] = server
            if (username := proxy.get("username")):
                params["proxy_username"] = username
            if (password := proxy.get("password")):
                params["proxy_password"] = password

        # -- Timezone --
        if (timezone_id := kwargs.get("timezone_id")) is not None:
            params["timezone"] = timezone_id

        # -- Screen size from viewport --
        viewport = kwargs.get("viewport")
        if isinstance(viewport, dict):
            w = viewport.get("width", 1280)
            h = viewport.get("height", 720)
            params["screen_size"] = f"{w}x{h}"

        # -- User agent --
        if (ua := kwargs.get("user_agent")) is not None:
            params["user_agent"] = ua

        # -- Locale --
        if (locale := kwargs.get("locale")) is not None:
            params["locale"] = locale

        # -- Color scheme --
        if (color_scheme := kwargs.get("color_scheme")) is not None:
            params["color_scheme"] = color_scheme

        # -- Geolocation --
        geolocation = kwargs.get("geolocation")
        if isinstance(geolocation, dict):
            if "latitude" in geolocation:
                params["latitude"] = str(geolocation["latitude"])
            if "longitude" in geolocation:
                params["longitude"] = str(geolocation["longitude"])

        # -- Device scale factor --
        if (dsf := kwargs.get("device_scale_factor")) is not None:
            params["device_scale_factor"] = str(dsf)

        # -- OS / mobile hint --
        if kwargs.get("is_mobile"):
            params["os"] = "android"

        # -- Create the context --
        result: Any = await self._client.execute("browser_create_context", **params)

        context_id: str = ""
        if isinstance(result, dict):
            context_id = result.get("context_id", "")
        elif isinstance(result, str):
            context_id = result

        base_url = kwargs.get("base_url", "")
        service_workers = kwargs.get("service_workers")

        ctx = BrowserContext(
            self._client,
            context_id,
            browser_ref=self,
            base_url=str(base_url),
            service_workers=str(service_workers) if service_workers else None,
        )
        self._contexts.append(ctx)

        # -- Post-creation configuration --

        # Set viewport if specified
        if isinstance(viewport, dict):
            page = await ctx.new_page()
            await page.set_viewport_size(viewport)
            # Don't return the page yet, just configure viewport
            # The page is already tracked in ctx._pages

        # Extra HTTP headers
        if (extra_headers := kwargs.get("extra_http_headers")):
            await ctx.set_extra_http_headers(extra_headers)

        # Storage state restoration
        storage_state = kwargs.get("storage_state")
        if storage_state is not None:
            await self._restore_storage_state(ctx, storage_state)

        # Video recording
        record_video = kwargs.get("record_video")
        if isinstance(record_video, dict):
            await ctx.start_video_recording(**record_video)

        # Geolocation set
        if isinstance(geolocation, dict):
            await ctx.set_geolocation(geolocation)

        return ctx

    async def _restore_storage_state(
        self,
        ctx: BrowserContext,
        state: StorageState | str,
    ) -> None:
        """Restore cookies from a storage state dict or JSON file.

        Args:
            ctx: Target BrowserContext.
            state: StorageState dict or path to JSON file.
        """
        if isinstance(state, str):
            import pathlib
            raw = pathlib.Path(state).read_text(encoding="utf-8")
            state = _json.loads(raw)

        if isinstance(state, dict):
            cookies = state.get("cookies", [])
            if cookies:
                await ctx.add_cookies(cookies)

    async def new_page(self, **kwargs: Any) -> Page:
        """Convenience: create a new context and page in one call.

        Creates a context with the given options and returns the first
        page. The context is accessible via page.context (if needed).

        Args:
            **kwargs: BrowserContextOptions passed to new_context().

        Returns:
            A new Page instance.
        """
        ctx = await self.new_context(**kwargs)
        # If viewport was set, a page was already created
        if ctx.pages:
            return ctx.pages[0]
        return await ctx.new_page()

    # ---- Lifecycle ----

    async def close(self) -> None:
        """Close all contexts and disconnect from the browser.

        Gracefully closes each context, then closes the underlying
        OwlBrowser client connection.
        """
        for ctx in list(self._contexts):
            with contextlib.suppress(Exception):
                await ctx.close()
        self._contexts.clear()

        with contextlib.suppress(Exception):
            await self._client.close()
        self._connected = False

    def is_connected(self) -> bool:
        """Check if the browser connection is still active.

        Returns:
            True if connected.
        """
        return self._connected

    # ---- Tracing (stubs for Playwright API compat) ----

    async def start_tracing(self, **kwargs: Any) -> None:
        """Start browser-level tracing (stub).

        Chromium tracing is not supported by Owl Browser. This method
        exists for API compatibility.

        Args:
            **kwargs: TracingOptions (page, path, screenshots, categories).
        """

    async def stop_tracing(self) -> bytes:
        """Stop browser-level tracing (stub).

        Returns:
            Empty bytes (tracing not supported).
        """
        return b""

    def __repr__(self) -> str:
        status = "connected" if self._connected else "disconnected"
        return f"<Browser status={status} contexts={len(self._contexts)}>"
