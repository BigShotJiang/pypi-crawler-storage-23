"""
Playwright-compatible Keyboard class for Owl Browser.

Maps Playwright Keyboard API methods to Owl Browser tool executions
for key press, type, combo, and modifier key operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..client import OwlBrowser


# Mapping from Playwright key names to Owl Browser key names.
_KEY_MAP: dict[str, str] = {
    "ArrowDown": "Down",
    "ArrowUp": "Up",
    "ArrowLeft": "Left",
    "ArrowRight": "Right",
    "Backspace": "Backspace",
    "Delete": "Delete",
    "End": "End",
    "Enter": "Enter",
    "Escape": "Escape",
    "Home": "Home",
    "Insert": "Insert",
    "PageDown": "PageDown",
    "PageUp": "PageUp",
    "Tab": "Tab",
    " ": "Space",
    "Space": "Space",
}

# Named special keys recognized by browser_press_key.
# The tool also accepts single character keys natively.
_SPECIAL_KEYS: frozenset[str] = frozenset({
    "Enter", "Return", "Tab", "Escape", "Esc",
    "Backspace", "Delete", "Del",
    "Up", "Down", "Left", "Right",
    "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight",
    "Space", "Home", "End", "PageUp", "PageDown",
})

# Modifier keys recognized by Playwright
_MODIFIERS: frozenset[str] = frozenset({
    "Alt", "Control", "Meta", "Shift",
    "Ctrl", "Cmd", "Command",
})

# Normalize modifier names to Owl Browser format
_MODIFIER_NORMALIZE: dict[str, str] = {
    "Ctrl": "Ctrl",
    "Control": "Ctrl",
    "Cmd": "Meta",
    "Command": "Meta",
    "Meta": "Meta",
    "Alt": "Alt",
    "Shift": "Shift",
}


def _translate_key(key: str) -> str:
    """Translate a Playwright key name to an Owl Browser key name.

    Handles modifier combos like 'Control+a' by translating each part
    and building the appropriate combo string.

    Args:
        key: Playwright key identifier (e.g., 'Enter', 'Control+a').

    Returns:
        Translated key string for browser_press_key or browser_keyboard_combo.
    """
    if "+" in key:
        parts = key.split("+")
        translated: list[str] = []
        for part in parts:
            stripped = part.strip()
            if stripped in _MODIFIER_NORMALIZE:
                translated.append(_MODIFIER_NORMALIZE[stripped])
            else:
                translated.append(_KEY_MAP.get(stripped, stripped))
        return "+".join(translated)
    return _KEY_MAP.get(key, key)


def _is_combo(key: str) -> bool:
    """Determine if a key string represents a modifier combo.

    Args:
        key: Translated key string.

    Returns:
        True if the key contains modifier + key combination.
    """
    if "+" not in key:
        return False
    parts = key.split("+")
    return any(p in {"Ctrl", "Meta", "Alt", "Shift"} for p in parts)


def _is_special_key(key: str) -> bool:
    """Check if the key is a named special key (Enter, Tab, etc.).

    browser_press_key now accepts both special keys and single character
    keys natively, so this function is primarily used for classification.

    Args:
        key: Translated key string.

    Returns:
        True if the key is a recognized named special key.
    """
    return key in _SPECIAL_KEYS


class Keyboard:
    """Provides methods for keyboard interaction within a browser page.

    Maps Playwright's Keyboard API to Owl Browser press_key, type, and
    keyboard_combo tools. Tracks modifier key state for down()/up() sequences.
    """

    __slots__ = ("_client", "_context_id", "_pressed_keys")

    def __init__(self, client: OwlBrowser, context_id: str) -> None:
        """Initialize Keyboard.

        Args:
            client: The OwlBrowser client instance.
            context_id: Browser context identifier for tool execution.
        """
        self._client = client
        self._context_id = context_id
        self._pressed_keys: list[str] = []

    async def press(self, key: str, **kwargs: Any) -> None:
        """Press a key (keydown + keyup).

        Supports modifier combos like 'Control+a', 'Shift+ArrowDown'.
        If modifier keys are held via down(), they are included automatically.
        Uses browser_press_key for all keys including single characters,
        since the native tool now supports character key input.

        Args:
            key: Key to press (e.g., 'Enter', 'Tab', 'Control+c', 'a').
            **kwargs: Additional options (delay, etc.) -- accepted for compat.
        """
        translated = _translate_key(key)

        # Prepend held modifiers if not already in the combo
        if self._pressed_keys and not _is_combo(translated):
            combo_parts = [_MODIFIER_NORMALIZE.get(k, k) for k in self._pressed_keys]
            combo_parts.append(translated)
            combo = "+".join(combo_parts)
            await self._client.execute(
                "browser_keyboard_combo",
                context_id=self._context_id,
                combo=combo,
            )
            return

        if _is_combo(translated):
            await self._client.execute(
                "browser_keyboard_combo",
                context_id=self._context_id,
                combo=translated,
            )
        else:
            await self._client.execute(
                "browser_press_key",
                context_id=self._context_id,
                key=translated,
            )

    async def type(self, text: str, **kwargs: Any) -> None:
        """Type text character by character with human-like delays.

        Unlike fill(), this dispatches individual key events for each character.
        Types into the currently focused element by omitting the selector,
        which causes browser_type to target the active element natively.
        No evaluate fallback.

        Args:
            text: Text string to type.
            **kwargs: Additional options (delay, etc.) -- accepted for compat.
        """
        await self._client.execute(
            "browser_type",
            context_id=self._context_id,
            text=text,
        )

    async def insert_text(self, text: str) -> None:
        """Insert text at the current cursor position.

        Dispatches an input event with the given text without individual
        key events for each character.

        Args:
            text: Text to insert.
        """
        await self.type(text)

    async def down(self, key: str) -> None:
        """Press and hold a modifier key.

        The key remains logically held until up() is called.
        Subsequent press() calls will include held modifiers.

        Args:
            key: Modifier key to hold (e.g., 'Shift', 'Control', 'Alt', 'Meta').
        """
        if key not in self._pressed_keys:
            self._pressed_keys.append(key)

    async def up(self, key: str) -> None:
        """Release a previously held modifier key.

        Args:
            key: Modifier key to release.
        """
        if key in self._pressed_keys:
            self._pressed_keys.remove(key)
