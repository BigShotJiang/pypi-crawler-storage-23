"""
Playwright-compatible Mouse class for Owl Browser.

Maps Playwright Mouse API methods to Owl Browser tool executions
for click, double-click, move, drag, and scroll operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from ..client import OwlBrowser


class Mouse:
    """Provides methods for mouse interaction within a browser page.

    Maps Playwright's Mouse API to Owl Browser click, mouse_move,
    drag_drop, and scroll_by tools. Tracks the last known cursor
    position for operations that require a starting coordinate.
    """

    __slots__ = ("_client", "_context_id", "_x", "_y")

    def __init__(self, client: OwlBrowser, context_id: str) -> None:
        """Initialize Mouse.

        Args:
            client: The OwlBrowser client instance.
            context_id: Browser context identifier for tool execution.
        """
        self._client = client
        self._context_id = context_id
        self._x: float = 0.0
        self._y: float = 0.0

    @property
    def x(self) -> float:
        """Current X position of the mouse cursor."""
        return self._x

    @property
    def y(self) -> float:
        """Current Y position of the mouse cursor."""
        return self._y

    async def click(
        self,
        x: float,
        y: float,
        *,
        button: Literal["left", "right", "middle"] = "left",
        click_count: int = 1,
        delay: float = 0,
        **kwargs: Any,
    ) -> None:
        """Click at the specified coordinates.

        Args:
            x: X coordinate in pixels.
            y: Y coordinate in pixels.
            button: Mouse button ('left', 'right', 'middle').
            click_count: Number of clicks (2 for double-click).
            delay: Delay between mousedown and mouseup in ms.
            **kwargs: Additional options for API compatibility.
        """
        self._x = x
        self._y = y
        selector = f"{int(x)}x{int(y)}"

        if button == "right":
            await self._client.execute(
                "browser_right_click",
                context_id=self._context_id,
                selector=selector,
            )
        elif click_count >= 2:
            await self._client.execute(
                "browser_double_click",
                context_id=self._context_id,
                selector=selector,
            )
        else:
            await self._client.execute(
                "browser_click",
                context_id=self._context_id,
                selector=selector,
            )

    async def dblclick(
        self,
        x: float,
        y: float,
        *,
        button: Literal["left", "right", "middle"] = "left",
        delay: float = 0,
        **kwargs: Any,
    ) -> None:
        """Double-click at the specified coordinates.

        Args:
            x: X coordinate in pixels.
            y: Y coordinate in pixels.
            button: Mouse button.
            delay: Delay between clicks in ms.
            **kwargs: Additional options for API compatibility.
        """
        self._x = x
        self._y = y
        selector = f"{int(x)}x{int(y)}"
        await self._client.execute(
            "browser_double_click",
            context_id=self._context_id,
            selector=selector,
        )

    async def move(self, x: float, y: float, *, steps: int = 1, **kwargs: Any) -> None:
        """Move the mouse cursor to the specified coordinates.

        Uses natural curved path with bezier curves for human-like movement.

        Args:
            x: Target X coordinate in pixels.
            y: Target Y coordinate in pixels.
            steps: Number of intermediate movement steps.
            **kwargs: Additional options for API compatibility.
        """
        await self._client.execute(
            "browser_mouse_move",
            context_id=self._context_id,
            start_x=self._x,
            start_y=self._y,
            end_x=x,
            end_y=y,
            steps=steps,
        )
        self._x = x
        self._y = y

    async def down(
        self,
        *,
        button: Literal["left", "right", "middle"] = "left",
        click_count: int = 1,
        **kwargs: Any,
    ) -> None:
        """Press the mouse button (mousedown event).

        Stub: Owl Browser handles press/release atomically in click.

        Args:
            button: Mouse button to press.
            click_count: Click count.
            **kwargs: Additional options.
        """

    async def up(
        self,
        *,
        button: Literal["left", "right", "middle"] = "left",
        click_count: int = 1,
        **kwargs: Any,
    ) -> None:
        """Release the mouse button (mouseup event).

        Stub: Owl Browser handles press/release atomically in click.

        Args:
            button: Mouse button to release.
            click_count: Click count.
            **kwargs: Additional options.
        """

    async def wheel(self, delta_x: float, delta_y: float, **kwargs: Any) -> None:
        """Scroll the page using the mouse wheel.

        Args:
            delta_x: Horizontal scroll amount in pixels (positive = right).
            delta_y: Vertical scroll amount in pixels (positive = down).
            **kwargs: Additional options for API compatibility.
        """
        await self._client.execute(
            "browser_scroll_by",
            context_id=self._context_id,
            x=int(delta_x),
            y=int(delta_y),
        )
