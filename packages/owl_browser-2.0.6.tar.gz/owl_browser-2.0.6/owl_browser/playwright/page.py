"""
Playwright-compatible Page class for Owl Browser.

The central class of the compatibility layer. Maps Playwright's Page API
surface to Owl Browser tool executions via the OwlBrowser client.
Covers navigation, interaction, content extraction, screenshots,
evaluation, waiting, viewport, network, dialogs, downloads, video,
clipboard, scrolling, zoom, tabs, frames, and event handling.
"""

from __future__ import annotations

import asyncio
import base64
import json as _json
from collections import defaultdict
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from .frame import Frame, FrameLocator
from .keyboard import Keyboard, _is_combo, _translate_key
from .locator import Locator, _convert_selector
from .mouse import Mouse
from .page_events import ConsoleMessage, Dialog, Download, Route, Video
from .response import Response

if TYPE_CHECKING:
    from ..client import OwlBrowser


class Page:
    """Represents a single browser page (tab) within a context.

    Provides the full Playwright Page API surface, translating each
    method call into the corresponding Owl Browser tool execution.
    Holds references to Keyboard, Mouse, and Video sub-objects.
    """

    __slots__ = (
        "_client", "_context_id", "_tab_id", "_url",
        "_keyboard", "_mouse", "_viewport_size", "_closed",
        "_event_handlers", "_video", "_route_rules",
        "_network_logging_enabled", "_dialog_auto_action",
    )

    def __init__(
        self,
        client: OwlBrowser,
        context_id: str,
        tab_id: str | None = None,
        url: str = "about:blank",
    ) -> None:
        """Initialize Page.

        Args:
            client: The OwlBrowser client instance.
            context_id: Browser context identifier.
            tab_id: Tab identifier within the context.
            url: Initial URL of the page.
        """
        self._client = client
        self._context_id = context_id
        self._tab_id = tab_id
        self._url = url
        self._keyboard = Keyboard(client, context_id)
        self._mouse = Mouse(client, context_id)
        self._viewport_size: dict[str, int] | None = None
        self._closed = False
        self._event_handlers: dict[str, list[Callable[..., Any]]] = defaultdict(list)
        self._video: Video | None = None
        self._route_rules: list[str] = []
        self._network_logging_enabled = False
        self._dialog_auto_action: str | None = None

    # ---- Properties ----

    @property
    def url(self) -> str:
        """The current URL of the page."""
        return self._url

    @property
    def keyboard(self) -> Keyboard:
        """Keyboard input interface."""
        return self._keyboard

    @property
    def mouse(self) -> Mouse:
        """Mouse input interface."""
        return self._mouse

    @property
    def viewport_size(self) -> dict[str, int] | None:
        """The viewport size, or None if not set."""
        return self._viewport_size

    @property
    def video(self) -> Video | None:
        """Video recording object, or None if not recording."""
        return self._video

    # ---- Navigation ----

    async def goto(self, url: str, **kwargs: Any) -> Response | None:
        """Navigate to a URL.

        Waits for the page to reach a stable state after navigation,
        matching Playwright's default behavior of waiting for 'load'.

        Args:
            url: URL to navigate to (must include protocol).
            **kwargs: GotoOptions (timeout, wait_until, referer).

        Returns:
            Response object for the navigation, or None on failure.
        """
        params: dict[str, Any] = {"context_id": self._context_id, "url": url}
        wait_until = kwargs.get("wait_until")
        if wait_until is not None:
            params["wait_until"] = wait_until
        timeout = kwargs.get("timeout")
        if timeout is not None:
            params["timeout"] = int(timeout)

        result: Any = await self._client.execute("browser_navigate", **params)
        self._url = url
        # Wait for page load to complete (Owl Browser navigate returns
        # immediately with "Navigation started").  For non-http URLs like
        # about:blank, a short sleep suffices.
        if url.startswith(("http://", "https://")):
            try:
                await self._client.execute(
                    "browser_wait_for_network_idle",
                    context_id=self._context_id,
                )
            except Exception:
                # Network idle timeout is non-fatal for goto
                pass

        # Update URL from actual browser state (handles redirects)
        try:
            info: Any = await self._client.execute(
                "browser_get_page_info", context_id=self._context_id,
            )
            if isinstance(info, dict) and "url" in info:
                self._url = info["url"]
        except Exception:
            pass

        data = result if isinstance(result, dict) else {}
        return Response(self._url, data)

    async def go_back(self, **kwargs: Any) -> Response | None:
        """Navigate back in history.

        Args:
            **kwargs: Navigation options (timeout, wait_until).

        Returns:
            Response object or None.
        """
        params: dict[str, Any] = {"context_id": self._context_id}
        if (wu := kwargs.get("wait_until")) is not None:
            params["wait_until"] = wu
        if (t := kwargs.get("timeout")) is not None:
            params["timeout"] = int(t)

        result: Any = await self._client.execute("browser_go_back", **params)
        data = result if isinstance(result, dict) else {}
        if isinstance(data, dict) and "url" in data:
            self._url = data["url"]
        return Response(self._url, data)

    async def go_forward(self, **kwargs: Any) -> Response | None:
        """Navigate forward in history.

        Args:
            **kwargs: Navigation options (timeout, wait_until).

        Returns:
            Response object or None.
        """
        params: dict[str, Any] = {"context_id": self._context_id}
        if (wu := kwargs.get("wait_until")) is not None:
            params["wait_until"] = wu
        if (t := kwargs.get("timeout")) is not None:
            params["timeout"] = int(t)

        result: Any = await self._client.execute("browser_go_forward", **params)
        data = result if isinstance(result, dict) else {}
        if isinstance(data, dict) and "url" in data:
            self._url = data["url"]
        return Response(self._url, data)

    async def reload(self, **kwargs: Any) -> Response | None:
        """Reload the page.

        Args:
            **kwargs: Navigation options (timeout, wait_until).

        Returns:
            Response object or None.
        """
        params: dict[str, Any] = {"context_id": self._context_id}
        if (wu := kwargs.get("wait_until")) is not None:
            params["wait_until"] = wu
        if (t := kwargs.get("timeout")) is not None:
            params["timeout"] = int(t)

        result: Any = await self._client.execute("browser_reload", **params)
        data = result if isinstance(result, dict) else {}
        return Response(self._url, data)

    # ---- Internal helpers ----

    async def _refresh_url(self) -> None:
        """Refresh the cached URL from the browser's actual state."""
        try:
            info: Any = await self._client.execute(
                "browser_get_page_info", context_id=self._context_id,
            )
            if isinstance(info, dict) and "url" in info:
                self._url = info["url"]
        except Exception:
            pass

    # ---- Page info ----

    async def title(self) -> str:
        """Get the page title.

        Returns:
            Page title string.
        """
        result: Any = await self._client.execute(
            "browser_get_page_info", context_id=self._context_id,
        )
        if isinstance(result, dict):
            return str(result.get("title", ""))
        return ""

    async def content(self) -> str:
        """Get the full HTML content of the page.

        Returns:
            HTML content string.
        """
        result: Any = await self._client.execute(
            "browser_get_html", context_id=self._context_id,
        )
        if isinstance(result, dict):
            return str(result.get("html", result.get("content", "")))
        return str(result)

    # ---- Interactions ----

    async def click(self, selector: str, **kwargs: Any) -> None:
        """Click an element.

        Args:
            selector: CSS selector, coordinates, or natural language.
            **kwargs: ClickOptions (button, click_count, delay, etc.).
        """
        sel = _convert_selector(selector)
        button = kwargs.get("button", "left")
        click_count = kwargs.get("click_count", 1)
        if button == "right":
            await self._client.execute(
                "browser_right_click", context_id=self._context_id, selector=sel,
            )
        elif click_count >= 2:
            await self._client.execute(
                "browser_double_click", context_id=self._context_id, selector=sel,
            )
        else:
            await self._client.execute(
                "browser_click", context_id=self._context_id, selector=sel,
            )
        # Refresh URL in case click triggered navigation
        try:
            await self._client.execute(
                "browser_wait_for_network_idle",
                context_id=self._context_id,
                timeout=1000,
            )
        except Exception:
            pass
        await self._refresh_url()

    async def dblclick(self, selector: str, **kwargs: Any) -> None:
        """Double-click an element.

        Args:
            selector: CSS selector, coordinates, or natural language.
            **kwargs: ClickOptions.
        """
        await self._client.execute(
            "browser_double_click", context_id=self._context_id, selector=selector,
        )

    async def fill(self, selector: str, value: str, **kwargs: Any) -> None:
        """Clear an input field and type new text.

        Args:
            selector: CSS selector for the input element.
            value: Text to fill in.
            **kwargs: FillOptions.
        """
        await self._client.execute(
            "browser_clear_input", context_id=self._context_id, selector=selector,
        )
        await self._client.execute(
            "browser_type", context_id=self._context_id, selector=selector, text=value,
        )

    async def type(self, selector: str, text: str, **kwargs: Any) -> None:
        """Type text into an element without clearing first.

        Args:
            selector: CSS selector for the input element.
            text: Text to type.
            **kwargs: TypeOptions.
        """
        await self._client.execute(
            "browser_type", context_id=self._context_id, selector=selector, text=text,
        )

    async def press(self, selector: str, key: str, **kwargs: Any) -> None:
        """Focus an element and press a key.

        For modifier combos (Control+a, Shift+Enter) uses browser_keyboard_combo.
        For all other keys (special and character) uses browser_press_key,
        which now supports single character key input natively.

        Args:
            selector: CSS selector for the element to focus.
            key: Key to press (e.g., 'Enter', 'Tab', 'Control+a', 'a').
            **kwargs: PressOptions.
        """
        await self._client.execute(
            "browser_focus", context_id=self._context_id, selector=selector,
        )
        translated = _translate_key(key)
        if _is_combo(translated):
            await self._client.execute(
                "browser_keyboard_combo", context_id=self._context_id, combo=translated,
            )
        else:
            await self._client.execute(
                "browser_press_key", context_id=self._context_id, key=translated,
            )

    async def hover(self, selector: str, **kwargs: Any) -> None:
        """Hover over an element.

        Args:
            selector: CSS selector or natural language description.
            **kwargs: HoverOptions.
        """
        sel = _convert_selector(selector)
        await self._client.execute(
            "browser_hover", context_id=self._context_id, selector=sel,
        )

    async def focus(self, selector: str, **kwargs: Any) -> None:
        """Focus an element.

        Args:
            selector: CSS selector or natural language description.
            **kwargs: FocusOptions.
        """
        await self._client.execute(
            "browser_focus", context_id=self._context_id, selector=selector,
        )

    # ---- Content extraction ----

    async def text_content(self, selector: str, **kwargs: Any) -> str | None:
        """Get the text content of an element.

        Args:
            selector: CSS selector for the element.

        Returns:
            Text content string, or None if not found.
        """
        result: Any = await self._client.execute(
            "browser_extract_text", context_id=self._context_id, selector=selector,
        )
        if isinstance(result, dict):
            return result.get("text", result.get("content"))
        return str(result) if result is not None else None

    async def inner_html(self, selector: str, **kwargs: Any) -> str:
        """Get the inner HTML of an element.

        Uses browser_get_html with a selector parameter, which returns
        the innerHTML of the matched element as a JSON-encoded string.

        Args:
            selector: CSS selector for the element.

        Returns:
            Inner HTML string.
        """
        result: Any = await self._client.execute(
            "browser_get_html", context_id=self._context_id, selector=selector,
        )
        if isinstance(result, str):
            # browser_get_html with selector returns a JSON-encoded string
            # (e.g., '"<b>bold</b> text"'). Decode it.
            try:
                decoded = _json.loads(result)
                if isinstance(decoded, str):
                    return decoded
            except (ValueError, TypeError):
                pass
            return result
        if isinstance(result, dict):
            return str(result.get("html", result.get("content", "")))
        return str(result) if result is not None else ""

    async def inner_text(self, selector: str, **kwargs: Any) -> str:
        """Get the inner text of an element.

        Args:
            selector: CSS selector for the element.

        Returns:
            Inner text string.
        """
        result = await self.text_content(selector, **kwargs)
        return result or ""

    async def get_attribute(self, selector: str, name: str, **kwargs: Any) -> str | None:
        """Get an attribute value from an element.

        Uses browser_get_attribute natively. No evaluate fallback.

        Args:
            selector: CSS selector for the element.
            name: Attribute name to retrieve.

        Returns:
            Attribute value or None if not present.
        """
        result: Any = await self._client.execute(
            "browser_get_attribute", context_id=self._context_id,
            selector=selector, attribute=name,
        )
        if isinstance(result, dict):
            val = result.get("value", result.get("attribute"))
            if val is not None and str(val):
                return str(val)
            return None
        if isinstance(result, str) and result:
            return result
        return None

    # ---- Schema-driven extraction ----

    async def query_all(
        self,
        selector: str,
        fields: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Extract structured data from all elements matching a CSS selector.

        Fetches the page HTML once and parses it SDK-side using BeautifulSoup.
        Each matching container element has the given fields extracted from it.

        Field syntax (string specs):
            ``"selector"``       -> textContent of the matched child element
            ``"selector@attr"``  -> attribute value of the matched child element
            ``"@attr"``          -> attribute on the container element itself

        Object specs support: type coercion, regex, transforms, nested extraction.

        Args:
            selector: CSS selector for repeating container elements.
            fields: Mapping of output names to extraction specs (string or dict).

        Returns:
            List of dicts with extracted values.

        Example::

            products = await page.query_all(".product-card", {
                "name": "h2",
                "price": {"selector": ".price .current", "type": "number"},
                "image": "img@src",
                "link": "a@href",
            })
        """
        from .extractor import query_all as _query_all

        html = await self.content()
        return _query_all(html, selector, fields)

    async def query_first(
        self,
        selector: str,
        fields: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Extract structured data from the first element matching a CSS selector.

        Args:
            selector: CSS selector for the container element.
            fields: Mapping of output names to extraction specs.

        Returns:
            Single dict or None if no match.
        """
        from .extractor import query_first as _query_first

        html = await self.content()
        return _query_first(html, selector, fields)

    async def extract_table(
        self,
        selector: str = "table",
        *,
        headers: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Extract a <table> as an array of records.

        Args:
            selector: CSS selector for the table.
            headers: Optional headers override.

        Returns:
            List of records with header keys.
        """
        from .extractor import extract_table as _extract_table

        html = await self.content()
        return _extract_table(html, selector, headers)

    async def extract_structured_data(self) -> list[object]:
        """Extract JSON-LD structured data from the page.

        Returns:
            List of parsed JSON-LD objects.
        """
        from .extractor import extract_structured_data as _extract_structured_data

        html = await self.content()
        return _extract_structured_data(html)

    async def extract_meta(self) -> dict[str, Any]:
        """Extract meta tags from the page.

        Returns:
            Dict with title, description, canonical, og, twitter, other.
        """
        from .extractor import extract_meta as _extract_meta

        html = await self.content()
        return _extract_meta(html)

    async def count(self, selector: str) -> int:
        """Count elements matching a CSS selector.

        Args:
            selector: CSS selector.

        Returns:
            Number of matching elements.
        """
        from .extractor import count_elements as _count_elements

        html = await self.content()
        return _count_elements(html, selector)

    async def scrape(
        self,
        selector: str,
        fields: dict[str, Any],
        *,
        next: str | None = None,
        max_pages: int = 10,
        wait: int = 2000,
        scroll: bool = False,
        max_scrolls: int = 20,
        scroll_wait: int = 2000,
        urls: list[str] | None = None,
        url_pattern: str | None = None,
        start_page: int = 1,
        end_page: int | None = None,
        page_step: int = 1,
        follow: dict[str, Any] | None = None,
        on_page_done: Callable[..., Any] | None = None,
        retries: int = 0,
        retry_delay: int = 1000,
    ) -> list[dict[str, Any]]:
        """Extract structured data across multiple pages or scroll loads.

        Supports three pagination modes:

        - **Click-next**: clicks a "next" button and waits for page update.
        - **Infinite scroll**: scrolls to the bottom and waits for new content.
        - **URL pagination**: visits explicit URLs or URL template with {page}/{offset}.

        Optionally follows links to detail pages for additional extraction.

        Args:
            selector: CSS selector for repeating container elements.
            fields: Mapping of output names to extraction specs.
            next: CSS selector for the "next page" button (click-next mode).
            max_pages: Maximum pages to scrape in click-next mode.
            wait: Milliseconds to wait after clicking next.
            scroll: Enable infinite scroll mode.
            max_scrolls: Maximum scroll iterations.
            scroll_wait: Milliseconds to wait after each scroll.
            urls: Explicit list of URLs to visit.
            url_pattern: URL template with {page}, {offset} placeholders.
            start_page: Starting page number (default: 1).
            end_page: Ending page number.
            page_step: Page increment (default: 1).
            follow: Detail page following config with url_selector, fields, wait.
            on_page_done: Callback after each page (page, new_items, total_items).
            retries: Retry failed pages (default: 0).
            retry_delay: Delay between retries in ms (default: 1000).

        Returns:
            Deduplicated list of all extracted records across pages.
        """
        from .extractor import query_all as _query_all
        from .extractor import query_first as _query_first

        all_items: list[dict[str, Any]] = []
        seen: set[str] = set()

        async def extract_page(page_num: int) -> int:
            html = await self.content()
            items = _query_all(html, selector, fields)
            new_count = 0
            for item in items:
                key = str(sorted(item.items()))
                if key not in seen:
                    seen.add(key)
                    all_items.append(item)
                    new_count += 1
            if on_page_done:
                on_page_done(page=page_num, new_items=new_count, total_items=len(all_items))
            return new_count

        async def with_retry(fn: Callable[..., Any]) -> Any:
            last_error: Exception | None = None
            for attempt in range(retries + 1):
                try:
                    return await fn()
                except Exception as e:
                    last_error = e
                    if attempt < retries:
                        await asyncio.sleep(retry_delay / 1000.0)
            if last_error:
                raise last_error

        # Mode 3: URL pagination
        if urls or url_pattern:
            url_list: list[str] = []
            if urls:
                url_list.extend(urls)
            elif url_pattern:
                end = end_page if end_page is not None else (start_page + max_pages - 1)
                p = start_page
                while p <= end:
                    offset = (p - 1) * page_step
                    url_list.append(
                        url_pattern
                        .replace("{page}", str(p))
                        .replace("{offset}", str(offset))
                    )
                    p += page_step

            for i, page_url in enumerate(url_list):
                async def _nav(u: str = page_url) -> None:
                    await self.goto(u)
                    await self.wait_for_load_state()
                    if wait > 0:
                        await asyncio.sleep(wait / 1000.0)
                await with_retry(_nav)
                new_count = await extract_page(i + 1)
                if new_count == 0:
                    break

        # Mode 1 & 2: Click-next or Infinite scroll
        else:
            limit = max_scrolls if scroll else max_pages
            for i in range(limit):
                new_count = await extract_page(i + 1)
                if new_count == 0:
                    break

                if scroll:
                    await self.scroll_to_bottom()
                    await asyncio.sleep(scroll_wait / 1000.0)
                elif next is not None:
                    loc = self.locator(next)
                    try:
                        cnt = await loc.count()
                    except Exception:
                        break
                    if cnt == 0:
                        break
                    if not await loc.is_visible() or not await loc.is_enabled():
                        break
                    await loc.click()
                    await self.wait_for_load_state()
                    await asyncio.sleep(wait / 1000.0)
                else:
                    break

        # Detail page following
        if follow:
            follow_url_sel = follow.get("url_selector", "")
            follow_fields = follow.get("fields", {})
            follow_wait = follow.get("wait", 1000)

            for item in all_items:
                detail_url = item.get(follow_url_sel)
                if not detail_url or not isinstance(detail_url, str):
                    # Try extracting from the page HTML
                    html = await self.content()
                    first = _query_first(html, selector, {"_url": follow_url_sel})
                    detail_url = first.get("_url") if first else None
                if not detail_url or not isinstance(detail_url, str):
                    continue

                # Resolve relative URLs
                if not detail_url.startswith(("http://", "https://")):
                    from urllib.parse import urljoin
                    detail_url = urljoin(self._url, detail_url)

                prev_url = self._url
                try:
                    async def _nav_detail(u: str = detail_url) -> None:
                        await self.goto(u)
                        await self.wait_for_load_state()
                        if follow_wait > 0:
                            await asyncio.sleep(follow_wait / 1000.0)
                    await with_retry(_nav_detail)
                    detail_html = await self.content()
                    detail_data = (
                        _query_first(detail_html, "body", follow_fields)
                        or _query_first(detail_html, selector, follow_fields)
                    )
                    if detail_data:
                        item.update(detail_data)
                except Exception:
                    pass
                # Navigate back
                try:
                    await self.goto(prev_url)
                    await self.wait_for_load_state()
                except Exception:
                    pass

        return all_items

    # ---- Element state checks ----

    async def is_visible(self, selector: str, **kwargs: Any) -> bool:
        """Check if an element is visible.

        Returns False (not an error) when the element does not exist,
        matching Playwright's behavior where is_visible on a missing
        element returns False.

        Uses browser_is_visible natively. No evaluate fallback.
        """
        try:
            result: Any = await self._client.execute(
                "browser_is_visible", context_id=self._context_id, selector=selector,
            )
        except Exception:
            return False
        if isinstance(result, dict):
            if result.get("status") == "element_not_found":
                return False
            if "error_code" in result:
                return result["error_code"] == "visible"
            if "visible" in result:
                return bool(result["visible"])
            return bool(result.get("success", False))
        return bool(result)

    async def is_enabled(self, selector: str, **kwargs: Any) -> bool:
        """Check if an element is enabled.

        Returns False for missing elements.
        Uses browser_is_enabled natively. No evaluate fallback.
        """
        try:
            result: Any = await self._client.execute(
                "browser_is_enabled", context_id=self._context_id, selector=selector,
            )
        except Exception:
            return False
        if isinstance(result, dict):
            if result.get("status") == "element_not_found":
                return False
            if "error_code" in result:
                return result["error_code"] == "enabled"
            if "enabled" in result:
                return bool(result["enabled"])
            return bool(result.get("success", False))
        return bool(result)

    async def is_checked(self, selector: str, **kwargs: Any) -> bool:
        """Check if a checkbox or radio element is checked.

        Uses browser_is_checked natively. No evaluate fallback.
        The native tool supports compound CSS selectors including
        attribute selectors like ``input[type="checkbox"]``.
        """
        try:
            result: Any = await self._client.execute(
                "browser_is_checked", context_id=self._context_id, selector=selector,
            )
        except Exception:
            return False
        if isinstance(result, dict):
            if result.get("status") == "element_not_found":
                return False
            if "error_code" in result:
                return result["error_code"] == "checked"
            if "checked" in result:
                return bool(result["checked"])
            return False
        return bool(result)

    # ---- Bounding box ----

    async def bounding_box(self, selector: str, **kwargs: Any) -> dict[str, float] | None:
        """Get the bounding box of an element.

        Args:
            selector: CSS selector for the element.

        Returns:
            Dict with x, y, width, height or None.
        """
        result: Any = await self._client.execute(
            "browser_get_bounding_box", context_id=self._context_id, selector=selector,
        )
        if isinstance(result, dict) and "x" in result:
            return {
                "x": float(result["x"]),
                "y": float(result["y"]),
                "width": float(result.get("width", 0)),
                "height": float(result.get("height", 0)),
            }
        return None

    # ---- Screenshot ----

    async def screenshot(self, **kwargs: Any) -> bytes:
        """Capture a screenshot of the page or a specific element.

        Args:
            **kwargs: ScreenshotOptions (path, full_page, clip, type, quality).

        Returns:
            PNG image data as bytes.
        """
        params: dict[str, Any] = {"context_id": self._context_id}
        selector = kwargs.get("selector")
        if selector is not None:
            params["mode"] = "element"
            params["selector"] = selector
        elif kwargs.get("full_page"):
            params["mode"] = "fullpage"
        else:
            params["mode"] = "viewport"

        result: Any = await self._client.execute("browser_screenshot", **params)
        image_data = ""
        if isinstance(result, dict):
            raw = result.get("image", result.get("data", result.get("base64", "")))
            image_data = str(raw) if raw is not None else ""
        elif isinstance(result, str):
            image_data = result

        image_bytes = base64.b64decode(image_data) if image_data else b""
        if (path := kwargs.get("path")) is not None:
            Path(path).write_bytes(image_bytes)
        return image_bytes

    # ---- JavaScript evaluation ----

    async def evaluate(self, expression: str, arg: Any = None) -> Any:
        """Evaluate a JavaScript expression in the page context.

        Supports bare expressions, arrow functions, function expressions,
        and async functions. When ``arg`` is provided, it is serialized to
        JSON and injected as the first parameter of the function.

        For async functions, uses a polling mechanism because the browser's
        evaluate endpoint does not resolve Promises natively (returns ``{}``
        for unresolved promises).

        Args:
            expression: JavaScript expression or function body.
            arg: Optional argument to pass to the function.

        Returns:
            The evaluation result.
        """
        if callable(expression):
            name = getattr(expression, "__name__", None) or str(expression)
            expression = f"({name})()"

        params: dict[str, Any] = {"context_id": self._context_id}

        expr = expression.strip()

        # Detect if the expression is a function (arrow or traditional)
        # that needs to be wrapped in an IIFE to execute.
        is_async = (
            expr.startswith("async ")
            or expr.startswith("async(")
        )
        is_function = (
            expr.startswith("()")
            or expr.startswith("async ")
            or expr.startswith("function")
            or (expr.startswith("(") and "=>" in expr.split("\n", 1)[0])
        )

        if is_function:
            if is_async:
                # Async function: the browser_evaluate cannot resolve
                # Promises. Store the resolved value in a global variable,
                # then poll for it in a second evaluate call.
                arg_part = _json.dumps(arg) if arg is not None else ""
                call = f"({expr})({arg_part})" if arg_part else f"({expr})()"
                key = f"__owl_async_{id(expression) & 0xFFFFFF}_{asyncio.get_event_loop().time()!s}".replace(".", "_")
                # Launch the async function and store result in window
                setup_expr = (
                    f"(async () => {{"
                    f"  try {{"
                    f"    window[{key!r}] = {{ done: false }};"
                    f"    const r = await {call};"
                    f"    window[{key!r}] = {{ done: true, value: r }};"
                    f"  }} catch(e) {{"
                    f"    window[{key!r}] = {{ done: true, error: e.message }};"
                    f"  }}"
                    f"}})()"
                )
                await self._client.execute(
                    "browser_evaluate",
                    context_id=self._context_id,
                    expression=setup_expr,
                )
                # Poll for the result (up to 10 seconds)
                for _ in range(100):
                    await asyncio.sleep(0.1)
                    poll_result: Any = await self._client.execute(
                        "browser_evaluate",
                        context_id=self._context_id,
                        expression=f"window[{key!r}]",
                    )
                    if isinstance(poll_result, dict) and poll_result.get("done"):
                        # Clean up
                        await self._client.execute(
                            "browser_evaluate",
                            context_id=self._context_id,
                            expression=f"delete window[{key!r}]",
                        )
                        if "error" in poll_result:
                            return None
                        return poll_result.get("value")
                return None
            else:
                if arg is not None:
                    arg_json = _json.dumps(arg)
                    expr = f"({expr})({arg_json})"
                else:
                    expr = f"({expr})()"

        params["expression"] = expr

        result: Any = await self._client.execute("browser_evaluate", **params)
        # The transport already unwraps {"success": true, "result": <value>}
        # so `result` here is the raw evaluation result: int, float, str,
        # bool, None, list, or dict.  Return it directly.
        #
        # The only special case: if the browser reports an evaluation error,
        # the result is {"error": "..."} with a single key.  Return None
        # in that case to signal failure without raising.
        if isinstance(result, dict) and "error" in result and len(result) == 1:
            return None
        return result

    async def evaluate_handle(self, expression: str, arg: Any = None) -> Any:
        """Evaluate expression and return a handle (delegates to evaluate)."""
        return await self.evaluate(expression, arg)

    # ---- Wait methods ----

    async def wait_for_selector(self, selector: str, **kwargs: Any) -> Locator | None:
        """Wait for an element matching the selector to appear.

        Args:
            selector: CSS selector or natural language description.
            **kwargs: WaitForSelectorOptions (state, timeout, strict).

        Returns:
            Locator for the found element.
        """
        params: dict[str, Any] = {"context_id": self._context_id, "selector": selector}
        if (t := kwargs.get("timeout")) is not None:
            params["timeout"] = int(t)
        await self._client.execute("browser_wait_for_selector", **params)
        return Locator(self, selector)

    async def wait_for_timeout(self, timeout: float) -> None:
        """Wait for a fixed duration in milliseconds."""
        await self._client.execute(
            "browser_wait", context_id=self._context_id, timeout=int(timeout),
        )

    async def wait_for_url(self, url: str, **kwargs: Any) -> None:
        """Wait for the page URL to match a pattern."""
        params: dict[str, Any] = {"context_id": self._context_id, "url_pattern": url}
        if (t := kwargs.get("timeout")) is not None:
            params["timeout"] = int(t)
        await self._client.execute("browser_wait_for_url", **params)

    async def wait_for_function(self, expression: str, **kwargs: Any) -> Any:
        """Wait for a JavaScript function to return a truthy value."""
        params: dict[str, Any] = {"context_id": self._context_id, "js_function": expression}
        if (p := kwargs.get("polling")) is not None and isinstance(p, int | float):
            params["polling"] = int(p)
        if (t := kwargs.get("timeout")) is not None:
            params["timeout"] = int(t)
        return await self._client.execute("browser_wait_for_function", **params)

    async def wait_for_load_state(self, state: str | None = None, **kwargs: Any) -> None:
        """Wait for the page to reach a specific load state."""
        params: dict[str, Any] = {"context_id": self._context_id}
        if (t := kwargs.get("timeout")) is not None:
            params["timeout"] = int(t)
        await self._client.execute("browser_wait_for_network_idle", **params)

    async def wait_for_event(self, event: str, **kwargs: Any) -> Any:
        """Wait for a page event. Limited support via polling."""
        if event == "download":
            return await self._wait_for_download(**kwargs)
        if event == "dialog":
            return await self._wait_for_dialog(**kwargs)
        return None

    async def _wait_for_download(self, **kwargs: Any) -> Download:
        """Poll for a new download to appear."""
        timeout_ms = kwargs.get("timeout", 30000)
        result: Any = await self._client.execute(
            "browser_get_downloads", context_id=self._context_id,
        )
        downloads_before = set()
        if isinstance(result, dict):
            for dl in result.get("downloads", []):
                downloads_before.add(str(dl.get("download_id", dl.get("id", ""))))
        elif isinstance(result, list):
            for dl in result:
                downloads_before.add(str(dl.get("download_id", dl.get("id", ""))))

        elapsed = 0
        while elapsed < timeout_ms:
            await asyncio.sleep(0.5)
            elapsed += 500
            result = await self._client.execute(
                "browser_get_downloads", context_id=self._context_id,
            )
            current = result.get("downloads", []) if isinstance(result, dict) else (result if isinstance(result, list) else [])
            for dl in current:
                dl_id = str(dl.get("download_id", dl.get("id", "")))
                if dl_id not in downloads_before:
                    return Download(self._client, self._context_id, dl)
        return Download(self._client, self._context_id, {})

    async def _wait_for_dialog(self, **kwargs: Any) -> Dialog:
        """Wait for a dialog to appear."""
        timeout = kwargs.get("timeout", 5000)
        result: Any = await self._client.execute(
            "browser_wait_for_dialog",
            context_id=self._context_id,
            timeout=int(timeout),
        )
        data = result if isinstance(result, dict) else {}
        return Dialog(self._client, self._context_id, data)

    # ---- Viewport ----

    async def set_viewport_size(self, viewport_size: dict[str, int]) -> None:
        """Set the browser viewport dimensions."""
        w, h = viewport_size["width"], viewport_size["height"]
        await self._client.execute(
            "browser_set_viewport", context_id=self._context_id,
            width=int(w), height=int(h),
        )
        self._viewport_size = {"width": w, "height": h}

    # ---- Select / Check / Uncheck ----

    async def select_option(self, selector: str, value: str | list[str] | None = None, **kwargs: Any) -> None:
        """Select an option from a dropdown."""
        pick_value = ""
        if isinstance(value, list):
            pick_value = value[0] if value else ""
        elif value is not None:
            pick_value = value
        elif (label := kwargs.get("label")) is not None:
            pick_value = label[0] if isinstance(label, list) and label else str(label)
        await self._client.execute(
            "browser_pick", context_id=self._context_id, selector=selector, value=pick_value,
        )

    async def check(self, selector: str, **kwargs: Any) -> None:
        """Check a checkbox (no-op if already checked).

        Uses browser_click natively to toggle the checkbox.
        No evaluate fallback.
        """
        if not await self.is_checked(selector):
            await self._client.execute(
                "browser_click", context_id=self._context_id, selector=selector,
            )

    async def uncheck(self, selector: str, **kwargs: Any) -> None:
        """Uncheck a checkbox (no-op if already unchecked).

        Uses browser_click natively to toggle the checkbox.
        No evaluate fallback.
        """
        if await self.is_checked(selector):
            await self._client.execute(
                "browser_click", context_id=self._context_id, selector=selector,
            )

    # ---- File upload ----

    async def set_input_files(self, selector: str, files: str | list[str], **kwargs: Any) -> None:
        """Upload files to a file input element.

        Args:
            selector: CSS selector for the file input.
            files: File path or list of file paths.
            **kwargs: Options.
        """
        file_list = [files] if isinstance(files, str) else files
        await self._client.execute(
            "browser_upload_file", context_id=self._context_id,
            selector=selector, file_paths=_json.dumps(file_list),
        )

    # ---- Drag and drop ----

    async def drag_and_drop(self, source: str, target: str, **kwargs: Any) -> None:
        """Drag from one element to another using HTML5 drag events."""
        await self._client.execute(
            "browser_html5_drag_drop", context_id=self._context_id,
            source_selector=source, target_selector=target,
        )

    # ---- Content injection ----

    async def set_content(self, html: str, **kwargs: Any) -> None:
        """Set the page content from an HTML string.

        Uses browser_set_content natively. No evaluate fallback.
        """
        await self._client.execute(
            "browser_set_content", context_id=self._context_id, html=html,
        )
        self._url = "about:blank"

    # ---- Locators ----

    def locator(self, selector: str) -> Locator:
        """Create a locator for the given selector."""
        return Locator(self, selector)

    def frame_locator(self, selector: str) -> FrameLocator:
        """Create a frame locator for an iframe element.

        Args:
            selector: CSS selector for the iframe.

        Returns:
            FrameLocator scoped to the iframe.
        """
        return FrameLocator(self._client, self._context_id, selector, self)

    def get_by_text(self, text: str, **kwargs: Any) -> Locator:
        """Locate element by text content."""
        return Locator(self, f"text={text}")

    def get_by_role(self, role: str, **kwargs: Any) -> Locator:
        """Locate element by ARIA role."""
        name = kwargs.get("name")
        if name:
            return Locator(self, f'[role="{role}"][aria-label="{name}"]')
        return Locator(self, f'[role="{role}"]')

    def get_by_placeholder(self, text: str, **kwargs: Any) -> Locator:
        """Locate element by placeholder text."""
        return Locator(self, f'[placeholder="{text}"]')

    def get_by_label(self, text: str, **kwargs: Any) -> Locator:
        """Locate element by label text."""
        return Locator(self, f"label={text}")

    def get_by_test_id(self, test_id: str) -> Locator:
        """Locate element by data-testid attribute."""
        return Locator(self, f'[data-testid="{test_id}"]')

    def get_by_alt_text(self, text: str, **kwargs: Any) -> Locator:
        """Locate element by alt text."""
        return Locator(self, f'[alt="{text}"]')

    def get_by_title(self, text: str, **kwargs: Any) -> Locator:
        """Locate element by title attribute."""
        return Locator(self, f'[title="{text}"]')

    async def query_selector(self, selector: str) -> Locator | None:
        """Find a single element matching the selector."""
        return Locator(self, selector)

    async def query_selector_all(self, selector: str) -> list[Locator]:
        """Find all elements matching the selector."""
        return [Locator(self, selector)]

    # ---- Network interception ----

    async def route(self, url: str, handler: Callable[..., Any], **kwargs: Any) -> None:
        """Intercept network requests matching a URL pattern.

        For simple abort/fulfill patterns, the handler is called immediately
        with a Route object. The Route.abort()/fulfill()/continue_() calls
        create corresponding Owl Browser network rules.

        Args:
            url: URL glob pattern (e.g., '**/*.png', '**/api/**').
            handler: Async or sync callback receiving a Route object.
            **kwargs: RouteOptions.
        """
        route = Route(self._client, self._context_id, url)
        result = handler(route)
        if asyncio.iscoroutine(result):
            await result

    async def unroute(self, url: str, **kwargs: Any) -> None:
        """Remove a previously registered route."""
        rules: Any = await self._client.execute(
            "browser_get_network_rules", context_id=self._context_id,
        )
        rule_list = rules.get("rules", []) if isinstance(rules, dict) else (rules if isinstance(rules, list) else [])
        for rule in rule_list:
            if rule.get("url_pattern") == url:
                await self._client.execute(
                    "browser_remove_network_rule",
                    context_id=self._context_id,
                    rule_id=str(rule.get("rule_id", rule.get("id", ""))),
                )

    # ---- Event system ----

    def on(self, event: str, handler: Callable[..., Any]) -> None:
        """Register an event handler.

        Supported events: dialog, console, download, popup, request, response, close.

        Args:
            event: Event name.
            handler: Callback function.
        """
        self._event_handlers[event].append(handler)
        if event == "dialog":
            # Set auto-accept so dialogs don't block
            asyncio.ensure_future(self._setup_dialog_handling())

    def off(self, event: str, handler: Callable[..., Any]) -> None:
        """Unregister an event handler.

        Args:
            event: Event name.
            handler: Callback to remove.
        """
        handlers = self._event_handlers.get(event, [])
        if handler in handlers:
            handlers.remove(handler)

    def once(self, event: str, handler: Callable[..., Any]) -> None:
        """Register a one-time event handler.

        Args:
            event: Event name.
            handler: Callback (removed after first invocation).
        """
        def wrapper(*args: Any, **kw: Any) -> Any:
            self.off(event, wrapper)
            return handler(*args, **kw)
        self.on(event, wrapper)

    async def _setup_dialog_handling(self) -> None:
        """Configure automatic dialog acceptance for event dispatch."""
        await self._client.execute(
            "browser_set_dialog_action",
            context_id=self._context_id,
            dialog_type="alert",
            action="accept",
        )

    # ---- Clipboard ----

    async def clipboard_read(self) -> str:
        """Read text from the clipboard.

        Returns:
            Clipboard text content.
        """
        result: Any = await self._client.execute(
            "browser_clipboard_read", context_id=self._context_id,
        )
        if isinstance(result, dict):
            return str(result.get("text", result.get("content", "")))
        return str(result) if result is not None else ""

    async def clipboard_write(self, text: str) -> None:
        """Write text to the clipboard.

        Args:
            text: Text to write.
        """
        await self._client.execute(
            "browser_clipboard_write", context_id=self._context_id, text=text,
        )

    # ---- Scroll ----

    async def scroll_to_top(self) -> None:
        """Scroll to the top of the page."""
        await self._client.execute(
            "browser_scroll_to_top", context_id=self._context_id,
        )

    async def scroll_to_bottom(self) -> None:
        """Scroll to the bottom of the page."""
        await self._client.execute(
            "browser_scroll_to_bottom", context_id=self._context_id,
        )

    # ---- Zoom (Owl Browser extension) ----

    async def zoom_in(self) -> None:
        """Zoom in by 10%."""
        await self._client.execute(
            "browser_zoom_in", context_id=self._context_id,
        )

    async def zoom_out(self) -> None:
        """Zoom out by 10%."""
        await self._client.execute(
            "browser_zoom_out", context_id=self._context_id,
        )

    async def zoom_reset(self) -> None:
        """Reset zoom to 100%."""
        await self._client.execute(
            "browser_zoom_reset", context_id=self._context_id,
        )

    # ---- Console logs ----

    async def console_messages(self, **kwargs: Any) -> list[ConsoleMessage]:
        """Get console log messages.

        Returns:
            List of ConsoleMessage objects.
        """
        result: Any = await self._client.execute(
            "browser_get_console_log", context_id=self._context_id,
        )
        entries = result.get("logs", result.get("entries", [])) if isinstance(result, dict) else (result if isinstance(result, list) else [])
        return [ConsoleMessage(entry) for entry in entries]

    # ---- Page lifecycle ----

    async def close(self) -> None:
        """Close this page (tab)."""
        self._closed = True

    def is_closed(self) -> bool:
        """Check if the page has been closed."""
        return self._closed

    async def bring_to_front(self) -> None:
        """Bring this page's tab to the foreground."""
        if self._tab_id is not None:
            await self._client.execute(
                "browser_switch_tab", context_id=self._context_id, tab_id=self._tab_id,
            )

    # ---- Frame access ----

    @property
    def main_frame(self) -> Page:
        """The main frame (self, for Playwright API compatibility)."""
        return self

    @property
    def frames(self) -> list[Page]:
        """All frames (returns [self] for API compatibility)."""
        return [self]

    def frame(self, **kwargs: Any) -> Page | None:
        """Get a frame by name or URL."""
        return self

    # ---- Video recording (Owl Browser extension) ----

    async def start_video_recording(self, **kwargs: Any) -> Video:
        """Start recording a video of this page.

        Returns:
            Video object for the recording.
        """
        params: dict[str, Any] = {"context_id": self._context_id}
        if (fps := kwargs.get("fps")) is not None:
            params["fps"] = str(fps)
        await self._client.execute("browser_start_video_recording", **params)
        self._video = Video(self._client, self._context_id)
        return self._video

    async def stop_video_recording(self) -> Video | None:
        """Stop video recording.

        Returns:
            Video object with the recording path.
        """
        await self._client.execute(
            "browser_stop_video_recording", context_id=self._context_id,
        )
        return self._video

    def __repr__(self) -> str:
        return f"<Page url={self._url!r} context_id={self._context_id!r}>"
