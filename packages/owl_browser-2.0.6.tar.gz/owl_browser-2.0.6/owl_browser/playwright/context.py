"""
Playwright-compatible BrowserContext class for Owl Browser.

Maps Playwright's BrowserContext API to Owl Browser context lifecycle
management, cookie operations, network interception, geolocation,
permissions, storage state, video recording, and page (tab) creation.
"""

from __future__ import annotations

import asyncio
import contextlib
import json as _json
import types
from typing import TYPE_CHECKING, Any, Callable

from .page import Page
from .page_events import Route

if TYPE_CHECKING:
    from ..client import OwlBrowser
    from .browser import Browser
    from .types import Cookie, Geolocation, StorageState


class _TracingStub:
    """Stub for Playwright's context.tracing API.

    Owl Browser does not support Chromium tracing, so these methods
    are no-ops that accept the same arguments for API compatibility.
    """

    __slots__ = ("_client", "_context_id")

    def __init__(self, client: OwlBrowser, context_id: str) -> None:
        self._client = client
        self._context_id = context_id

    async def start(self, **kwargs: Any) -> None:
        """Start tracing (stub).

        Args:
            **kwargs: TracingStartOptions (name, screenshots, snapshots, sources).
        """

    async def stop(self, **kwargs: Any) -> None:
        """Stop tracing (stub).

        Args:
            **kwargs: TracingStopOptions (path).
        """

    async def start_chunk(self, **kwargs: Any) -> None:
        """Start a new tracing chunk (stub).

        Args:
            **kwargs: TracingStartChunkOptions (title, name).
        """

    async def stop_chunk(self, **kwargs: Any) -> None:
        """Stop the current tracing chunk (stub).

        Args:
            **kwargs: TracingStopChunkOptions (path).
        """

    def __repr__(self) -> str:
        return "<Tracing (stub)>"


class BrowserContext:
    """Represents an isolated browser context (session).

    Each context has its own cookies, storage, proxy, and fingerprint
    configuration. Pages created within a context share these resources.
    Closing the context destroys all associated pages and releases resources.

    Supports Playwright's full context API surface: cookies, network
    interception (route/unroute), storage state, geolocation, permissions,
    extra HTTP headers, offline mode, init scripts, event system (on/off/once),
    tracing stubs, and video recording integration.
    """

    __slots__ = (
        "_client", "_context_id", "_browser_ref", "_pages",
        "_first_page_created", "_closed", "_event_handlers",
        "_route_rules", "_init_scripts", "_tracing",
        "_extra_headers", "_offline", "_service_workers",
        "_base_url", "_default_timeout",
    )

    def __init__(
        self,
        client: OwlBrowser,
        context_id: str,
        browser_ref: Browser | None = None,
        *,
        base_url: str = "",
        service_workers: str | None = None,
    ) -> None:
        """Initialize BrowserContext.

        Args:
            client: The OwlBrowser client instance.
            context_id: Owl Browser context identifier (e.g., 'ctx_000001').
            browser_ref: Parent Browser instance reference.
            base_url: Base URL for relative navigations within this context.
            service_workers: Service worker policy ('allow' or 'block').
        """
        self._client = client
        self._context_id = context_id
        self._browser_ref = browser_ref
        self._pages: list[Page] = []
        self._first_page_created = False
        self._closed = False
        self._event_handlers: dict[str, list[Callable[..., Any]]] = {}
        self._route_rules: list[str] = []
        self._init_scripts: list[str] = []
        self._tracing = _TracingStub(client, context_id)
        self._extra_headers: dict[str, str] = {}
        self._offline = False
        self._service_workers = service_workers
        self._base_url = base_url
        self._default_timeout: float = 30000

    # ---- Async context manager ----

    async def __aenter__(self) -> BrowserContext:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: types.TracebackType | None,
    ) -> None:
        await self.close()

    # ---- Properties ----

    @property
    def pages(self) -> list[Page]:
        """All pages (tabs) created in this context."""
        return list(self._pages)

    @property
    def browser(self) -> Browser | None:
        """The parent Browser instance, or None."""
        return self._browser_ref

    @property
    def tracing(self) -> _TracingStub:
        """Tracing API (stub for Playwright compatibility)."""
        return self._tracing

    # ---- Timeout ----

    def set_default_timeout(self, timeout: float) -> None:
        """Set the default maximum timeout for all operations.

        Args:
            timeout: Timeout in milliseconds.
        """
        self._default_timeout = timeout

    def set_default_navigation_timeout(self, timeout: float) -> None:
        """Set the default maximum navigation timeout.

        Args:
            timeout: Timeout in milliseconds.
        """
        self._default_timeout = timeout

    # ---- Page management ----

    async def new_page(self) -> Page:
        """Create a new page (tab) in this context.

        The first call returns a Page using the default tab that was
        created with the context. Subsequent calls open new tabs via
        browser_new_tab.

        Returns:
            A new Page instance.
        """
        if not self._first_page_created:
            self._first_page_created = True
            page = Page(self._client, self._context_id)
            self._pages.append(page)
            # Execute init scripts on new page
            for script in self._init_scripts:
                await page.evaluate(script)
            # Fire 'page' event handlers
            await self._fire_event("page", page)
            return page

        result: Any = await self._client.execute(
            "browser_new_tab",
            context_id=self._context_id,
        )
        tab_id: str | None = None
        if isinstance(result, dict):
            tab_id = result.get("tab_id", result.get("id"))

        page = Page(self._client, self._context_id, tab_id=tab_id)
        self._pages.append(page)
        # Execute init scripts on new page
        for script in self._init_scripts:
            await page.evaluate(script)
        # Fire 'page' event handlers
        await self._fire_event("page", page)
        return page

    # ---- Context lifecycle ----

    async def close(self) -> None:
        """Close this context and all its pages.

        Releases browser resources associated with this context.
        Fires the 'close' event before cleanup.
        """
        if self._closed:
            return
        self._closed = True

        await self._fire_event("close")

        for page in self._pages:
            page._closed = True  # noqa: SLF001
        self._pages.clear()

        with contextlib.suppress(Exception):
            await self._client.execute(
                "browser_close_context",
                context_id=self._context_id,
            )

    # ---- Cookie operations ----

    async def cookies(self, urls: str | list[str] | None = None) -> list[dict[str, Any]]:
        """Get cookies from this context.

        Args:
            urls: Optional URL or list of URLs to filter cookies.

        Returns:
            List of cookie dictionaries.
        """
        params: dict[str, Any] = {"context_id": self._context_id}
        if urls is not None:
            if isinstance(urls, list):
                params["url"] = urls[0] if urls else ""
            else:
                params["url"] = urls

        result: Any = await self._client.execute("browser_get_cookies", **params)
        if isinstance(result, list):
            return result
        if isinstance(result, dict):
            return result.get("cookies", [])
        return []

    async def add_cookies(self, cookies: list[Cookie]) -> None:
        """Add cookies to this context.

        Args:
            cookies: List of Cookie TypedDicts to set.
        """
        for cookie in cookies:
            params: dict[str, Any] = {
                "context_id": self._context_id,
                "name": cookie["name"],
                "value": cookie["value"],
                "url": cookie.get("url", ""),
            }
            if (domain := cookie.get("domain")) is not None:
                params["domain"] = domain
            if (path := cookie.get("path")) is not None:
                params["path"] = path
            if (secure := cookie.get("secure")) is not None:
                params["secure"] = secure
            if (http_only := cookie.get("httpOnly")) is not None:
                params["httpOnly"] = http_only
            if (same_site := cookie.get("sameSite")) is not None:
                params["sameSite"] = same_site.lower()
            if (expires := cookie.get("expires")) is not None:
                params["expires"] = int(expires)

            await self._client.execute("browser_set_cookie", **params)

    async def clear_cookies(self) -> None:
        """Delete all cookies from this context."""
        await self._client.execute(
            "browser_delete_cookies",
            context_id=self._context_id,
        )

    # ---- Storage state ----

    async def storage_state(self, **kwargs: Any) -> StorageState:
        """Get the storage state (cookies + local storage) for persistence.

        Serializes the current context's cookies into a StorageState
        dictionary that can be saved and restored in a new context.

        Args:
            **kwargs: Options (path: optional file path to save JSON).

        Returns:
            StorageState TypedDict with cookies and origins.
        """
        cookie_list = await self.cookies()
        state: StorageState = {"cookies": cookie_list, "origins": []}
        if (path := kwargs.get("path")) is not None:
            import pathlib
            pathlib.Path(path).write_text(_json.dumps(state, indent=2))
        return state

    # ---- Network interception ----

    async def route(self, url: str, handler: Callable[..., Any], **kwargs: Any) -> None:
        """Intercept network requests matching a URL pattern.

        Creates an Owl Browser network rule and calls the handler with
        a Route object. The handler can abort, fulfill, or continue
        the intercepted request.

        Args:
            url: URL glob pattern (e.g., '**/*.png', '**/api/**').
            handler: Async or sync callback receiving a Route object.
            **kwargs: RouteOptions.
        """
        route = Route(self._client, self._context_id, url)
        result = handler(route)
        if asyncio.iscoroutine(result):
            await result

    async def unroute(self, url: str, handler: Callable[..., Any] | None = None, **kwargs: Any) -> None:
        """Remove a previously registered network route.

        Args:
            url: URL pattern to unregister.
            handler: Specific handler to remove (ignored -- removes all for pattern).
            **kwargs: Options for API compatibility.
        """
        rules: Any = await self._client.execute(
            "browser_get_network_rules", context_id=self._context_id,
        )
        rule_list = rules.get("rules", []) if isinstance(rules, dict) else (rules if isinstance(rules, list) else [])
        for rule in rule_list:
            if rule.get("url_pattern") == url:
                await self._client.execute(
                    "browser_remove_network_rule",
                    context_id=self._context_id,
                    rule_id=str(rule.get("rule_id", rule.get("id", ""))),
                )

    async def set_offline(self, offline: bool) -> None:
        """Set the context to offline mode.

        When offline, all network requests will be blocked.

        Args:
            offline: True to go offline, False to restore connectivity.
        """
        self._offline = offline
        if offline:
            await self._client.execute(
                "browser_add_network_rule",
                context_id=self._context_id,
                url_pattern="*",
                action="block",
            )
        else:
            # Remove the block-all rule
            rules: Any = await self._client.execute(
                "browser_get_network_rules", context_id=self._context_id,
            )
            rule_list = rules.get("rules", []) if isinstance(rules, dict) else (rules if isinstance(rules, list) else [])
            for rule in rule_list:
                if rule.get("url_pattern") == "*" and rule.get("action") == "block":
                    await self._client.execute(
                        "browser_remove_network_rule",
                        context_id=self._context_id,
                        rule_id=str(rule.get("rule_id", rule.get("id", ""))),
                    )

    # ---- Geolocation ----

    async def set_geolocation(self, geolocation: Geolocation | None) -> None:
        """Set geolocation override.

        Geolocation is primarily configured at context creation time
        in Owl Browser. This method issues browser_set_location if
        the tool is available, otherwise acts as a stub.

        Args:
            geolocation: Geolocation coordinates or None to clear.
        """
        if geolocation is not None:
            with contextlib.suppress(Exception):
                await self._client.execute(
                    "browser_set_location",
                    context_id=self._context_id,
                    latitude=str(geolocation.get("latitude", 0)),
                    longitude=str(geolocation.get("longitude", 0)),
                )

    # ---- Permissions ----

    async def grant_permissions(
        self,
        permissions: list[str],
        origin: str | None = None,
    ) -> None:
        """Grant permissions to the context (stub).

        Permission management is not directly applicable to Owl Browser
        contexts. Permissions are configured at browser level.

        Args:
            permissions: List of permission names.
            origin: Optional origin URL to scope permissions.
        """

    async def clear_permissions(self) -> None:
        """Clear granted permissions (stub)."""

    # ---- Extra HTTP headers ----

    async def set_extra_http_headers(self, headers: dict[str, str]) -> None:
        """Set extra HTTP headers to be sent with every request.

        Uses Owl Browser's network interception to inject headers
        via modify rules where supported. Stores headers for reference.

        Args:
            headers: Header name-value pairs.
        """
        self._extra_headers = dict(headers)

    # ---- Init scripts ----

    async def add_init_script(self, script: str = "", **kwargs: Any) -> None:
        """Add a script to be evaluated on every new document.

        The script is evaluated before any page scripts run. Stored
        and executed on each new page created in this context.

        Args:
            script: JavaScript code string.
            **kwargs: Options (path: file path to load script from).
        """
        if not script and (path := kwargs.get("path")):
            import pathlib
            script = pathlib.Path(path).read_text(encoding="utf-8")
        if script:
            self._init_scripts.append(script)

    # ---- Function binding ----

    async def expose_function(self, name: str, callback: Callable[..., Any]) -> None:
        """Expose a Python function to all pages in this context.

        Registers a JavaScript function in the page that, when called,
        invokes the Python callback. Implemented by injecting a polling
        bridge script.

        Args:
            name: Name of the function to expose in JavaScript.
            callback: Python function to call when the JS function is invoked.
        """
        # Register the function binding as an init script
        # The actual callback invocation requires event loop integration
        # which is limited in Owl Browser's architecture
        binding_script = f"window.{name} = (...args) => {{}}"
        self._init_scripts.append(binding_script)

    async def expose_binding(
        self,
        name: str,
        callback: Callable[..., Any],
        *,
        handle: bool = False,
    ) -> None:
        """Expose a Python function binding to all pages.

        Args:
            name: Name of the function to expose.
            callback: Python function to call.
            handle: Whether to pass a handle argument.
        """
        await self.expose_function(name, callback)

    # ---- Event system ----

    def on(self, event: str, handler: Callable[..., Any]) -> None:
        """Register an event handler.

        Supported events: page, close, request, response, console,
        dialog, download.

        Args:
            event: Event name.
            handler: Callback function.
        """
        if event not in self._event_handlers:
            self._event_handlers[event] = []
        self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable[..., Any]) -> None:
        """Unregister an event handler.

        Args:
            event: Event name.
            handler: Callback to remove.
        """
        handlers = self._event_handlers.get(event, [])
        if handler in handlers:
            handlers.remove(handler)

    def once(self, event: str, handler: Callable[..., Any]) -> None:
        """Register a one-time event handler.

        Args:
            event: Event name.
            handler: Callback (removed after first invocation).
        """
        def wrapper(*args: Any, **kw: Any) -> Any:
            self.off(event, wrapper)
            return handler(*args, **kw)
        self.on(event, wrapper)

    async def _fire_event(self, event: str, *args: Any) -> None:
        """Invoke all registered handlers for an event.

        Args:
            event: Event name.
            *args: Arguments to pass to handlers.
        """
        for handler in self._event_handlers.get(event, []):
            result = handler(*args)
            if asyncio.iscoroutine(result):
                await result

    # ---- Wait for event ----

    async def wait_for_event(self, event: str, **kwargs: Any) -> Any:
        """Wait for a context-level event.

        Args:
            event: Event name ('page', 'close', etc.).
            **kwargs: Options (predicate, timeout).

        Returns:
            The event data.
        """
        timeout = kwargs.get("timeout", self._default_timeout)
        predicate = kwargs.get("predicate")
        future: asyncio.Future[Any] = asyncio.get_event_loop().create_future()

        def _handler(*args: Any) -> None:
            value = args[0] if args else None
            if predicate is not None:
                try:
                    if not predicate(value):
                        return
                except Exception:
                    return
            if not future.done():
                future.set_result(value)

        self.once(event, _handler)
        return await asyncio.wait_for(future, timeout=timeout / 1000)

    async def expect_page(self, **kwargs: Any) -> Any:
        """Wait for a new page to be created in this context.

        Args:
            **kwargs: Options (predicate, timeout).

        Returns:
            The new Page instance.
        """
        return await self.wait_for_event("page", **kwargs)

    # ---- Popup policy ----

    async def set_popup_policy(self, policy: str = "allow") -> None:
        """Set the popup window policy for this context.

        Args:
            policy: 'allow' or 'deny'.
        """
        await self._client.execute(
            "browser_set_popup_policy",
            context_id=self._context_id,
            policy=policy,
        )

    # ---- Video recording integration ----

    async def start_video_recording(self, **kwargs: Any) -> None:
        """Start video recording for this context.

        Args:
            **kwargs: RecordVideoOptions (fps, dir, size).
        """
        params: dict[str, Any] = {"context_id": self._context_id}
        if (fps := kwargs.get("fps")) is not None:
            params["fps"] = str(fps)
        await self._client.execute("browser_start_video_recording", **params)

    async def stop_video_recording(self) -> None:
        """Stop video recording for this context."""
        await self._client.execute(
            "browser_stop_video_recording",
            context_id=self._context_id,
        )

    def __repr__(self) -> str:
        status = "closed" if self._closed else "open"
        return f"<BrowserContext id={self._context_id!r} status={status}>"
