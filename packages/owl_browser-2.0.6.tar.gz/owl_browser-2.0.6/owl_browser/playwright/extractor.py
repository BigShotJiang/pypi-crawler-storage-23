"""
Schema-driven HTML data extraction using BeautifulSoup.

Pure functions for extracting structured data from HTML strings using
a declarative field schema. No side effects, no browser interaction.

String field syntax (backward compatible):
    "selector"       -> textContent of the matched element
    "selector@attr"  -> attribute value of the matched element
    "@attr"          -> attribute value of the container itself

Object field specs add: type coercion, regex, transforms, nested
extraction, multi-value collection, and defaults.
"""

from __future__ import annotations

import json
import re
import unicodedata
from typing import Any, TypedDict, Union

from bs4 import BeautifulSoup, Tag


# ==================== Types ====================

class NestedSpec(TypedDict, total=False):
    """Nested extraction configuration."""
    selector: str
    fields: dict[str, FieldSpec]
    limit: int


class ObjectFieldSpec(TypedDict, total=False):
    """Object-based field spec for advanced extraction."""
    selector: str
    attribute: str
    all: bool
    type: str  # 'text' | 'number' | 'html' | 'innerHtml'
    pattern: str
    group: int
    transform: Union[str, list[str]]  # Transform or list of Transform
    default: Union[str, int, float, None]
    nested: NestedSpec


# A field spec is either a string shorthand or an ObjectFieldSpec dict
FieldSpec = Union[str, ObjectFieldSpec]

# Transform names
Transform = str  # 'trim' | 'lowercase' | 'uppercase' | 'number' | 'clean' | 'slug'


class MetaData(TypedDict):
    """Meta tag extraction result."""
    title: str | None
    description: str | None
    canonical: str | None
    og: dict[str, str]
    twitter: dict[str, str]
    other: dict[str, str]


# ==================== Public Functions ====================

def query_all(
    html: str,
    container_selector: str,
    fields: dict[str, FieldSpec],
) -> list[dict[str, Any]]:
    """Extract structured data from all elements matching container_selector.

    Args:
        html: Raw HTML string to parse.
        container_selector: CSS selector for repeating container elements.
        fields: Mapping of output field names to extraction specs.

    Returns:
        List of dicts, one per matched container, with extracted field values.
    """
    soup = BeautifulSoup(html, "html.parser")
    containers = soup.select(container_selector)
    return [_extract_item(c, fields) for c in containers]


def query_first(
    html: str,
    container_selector: str,
    fields: dict[str, FieldSpec],
) -> dict[str, Any] | None:
    """Extract structured data from the first element matching container_selector.

    Args:
        html: Raw HTML string to parse.
        container_selector: CSS selector for the container element.
        fields: Mapping of output field names to extraction specs.

    Returns:
        Single dict or None if no match.
    """
    soup = BeautifulSoup(html, "html.parser")
    container = soup.select_one(container_selector)
    if container is None:
        return None
    return _extract_item(container, fields)


def extract_table(
    html: str,
    selector: str = "table",
    headers: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Extract a <table> as an array of records.

    Auto-detects headers from <th> or the first row. Handles colspan/rowspan.

    Args:
        html: Raw HTML string.
        selector: CSS selector for the table.
        headers: Optional headers override.

    Returns:
        List of records with header keys.
    """
    soup = BeautifulSoup(html, "html.parser")
    table = soup.select_one(selector)
    if table is None:
        return []

    hdrs: list[str] = list(headers) if headers else []

    # Auto-detect headers from <th> elements
    if not hdrs:
        thead = table.find("thead")
        if thead and isinstance(thead, Tag):
            th_els = thead.find_all("th")
        else:
            first_row = table.find("tr")
            th_els = first_row.find_all("th") if first_row else []
        for th in th_els:
            hdrs.append(th.get_text(strip=True))

    # Collect all rows
    rows = table.find_all("tr")
    start_idx = 0

    # If still no headers, use first row cells as headers
    if not hdrs and rows:
        first_row = rows[0]
        for cell in first_row.find_all(["td", "th"]):
            hdrs.append(cell.get_text(strip=True))
        start_idx = 1

    # Identify data rows (skip header rows)
    data_rows: list[Tag] = []
    for i, row in enumerate(rows):
        if i < start_idx:
            continue
        tds = row.find_all("td")
        ths = row.find_all("th")
        if not tds and ths:
            continue  # Skip pure-header rows
        data_rows.append(row)

    # Build grid to handle colspan/rowspan
    grid: list[list[str | None]] = [[] for _ in range(len(data_rows))]

    for r, row in enumerate(data_rows):
        cells = row.find_all(["td", "th"])
        cell_idx = 0
        for cell in cells:
            colspan = int(cell.get("colspan", 1) or 1)
            rowspan = int(cell.get("rowspan", 1) or 1)
            text = cell.get_text(strip=True)

            # Find next empty column
            while cell_idx < len(grid[r]) and grid[r][cell_idx] is not None:
                cell_idx += 1

            for dr in range(rowspan):
                if r + dr >= len(grid):
                    grid.append([])
                row_grid = grid[r + dr]
                for dc in range(colspan):
                    col = cell_idx + dc
                    # Extend row if needed
                    while len(row_grid) <= col:
                        row_grid.append(None)
                    row_grid[col] = text

            cell_idx += colspan

    # Convert grid to records
    results: list[dict[str, Any]] = []
    for row_data in grid:
        record: dict[str, Any] = {}
        for c in range(len(hdrs)):
            key = hdrs[c] or f"col_{c}"
            record[key] = row_data[c] if c < len(row_data) else None
        results.append(record)

    return results


def extract_meta(html: str) -> MetaData:
    """Extract meta tags from HTML.

    Args:
        html: Raw HTML string.

    Returns:
        MetaData dict with title, description, canonical, og, twitter, other.
    """
    soup = BeautifulSoup(html, "html.parser")

    result: MetaData = {
        "title": None,
        "description": None,
        "canonical": None,
        "og": {},
        "twitter": {},
        "other": {},
    }

    # Title
    title_el = soup.find("title")
    if title_el:
        result["title"] = title_el.get_text(strip=True) or None

    # Canonical
    canonical_el = soup.find("link", rel="canonical")
    if canonical_el and isinstance(canonical_el, Tag):
        result["canonical"] = canonical_el.get("href")  # type: ignore[assignment]

    # Meta tags
    for meta in soup.find_all("meta"):
        if not isinstance(meta, Tag):
            continue
        name = meta.get("name") or meta.get("property") or ""
        content = meta.get("content") or ""
        if isinstance(name, list):
            name = name[0] if name else ""
        if isinstance(content, list):
            content = content[0] if content else ""
        if not name or not content:
            continue

        if name == "description":
            result["description"] = content
        elif name.startswith("og:"):
            result["og"][name[3:]] = content
        elif name.startswith("twitter:"):
            result["twitter"][name[8:]] = content
        else:
            result["other"][name] = content

    return result


def extract_structured_data(html: str) -> list[object]:
    """Extract JSON-LD structured data from HTML.

    Args:
        html: Raw HTML string.

    Returns:
        List of parsed JSON-LD objects.
    """
    soup = BeautifulSoup(html, "html.parser")
    results: list[object] = []

    for script in soup.find_all("script", type="application/ld+json"):
        text = script.string
        if not text:
            continue
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                results.extend(parsed)
            elif isinstance(parsed, dict):
                results.append(parsed)
        except (json.JSONDecodeError, ValueError):
            pass

    return results


def count_elements(html: str, selector: str) -> int:
    """Count elements matching a CSS selector.

    Args:
        html: Raw HTML string.
        selector: CSS selector.

    Returns:
        Number of matching elements.
    """
    soup = BeautifulSoup(html, "html.parser")
    return len(soup.select(selector))


# ==================== Internal Helpers ====================

def _extract_item(
    container: Tag,
    fields: dict[str, FieldSpec],
) -> dict[str, Any]:
    """Extract all fields from a single container element."""
    return {name: _resolve_field(container, spec) for name, spec in fields.items()}


def _resolve_field(container: Tag, spec: FieldSpec) -> Any:
    """Resolve a field spec (string or object) to a value."""
    if isinstance(spec, str):
        return _extract_string_field(container, spec)
    return _extract_object_field(container, spec)


def _extract_string_field(container: Tag, spec: str) -> str | None:
    """Extract a single field value from a container using string spec.

    Backward compatible with the original implementation.
    """
    at_pos = spec.rfind("@")
    if at_pos >= 0:
        sel = spec[:at_pos].strip()
        attr = spec[at_pos + 1:]
        target = container if not sel else container.select_one(sel)
        if target is None:
            return None
        if attr == "outerHTML":
            return str(target)
        if attr == "innerHTML":
            return target.decode_contents()
        val = target.get(attr)
        if isinstance(val, list):
            return " ".join(val)
        return val  # type: ignore[return-value]
    # No '@' -> extract text content
    el = container.select_one(spec) if spec.strip() else container
    return el.get_text(strip=True) if el else None


def _extract_object_field(container: Tag, spec: ObjectFieldSpec) -> Any:
    """Extract a field value using an object spec."""
    # Handle nested extraction
    nested = spec.get("nested")
    if nested:
        return _extract_nested(container, nested)

    sel = spec.get("selector")
    attr = spec.get("attribute")
    field_type = spec.get("type")
    default = spec.get("default")

    if spec.get("all"):
        # Multi-value: return list of all matches
        values: list[Any] = []
        targets = container.select(sel) if sel else [container]
        for el in targets:
            raw = _extract_raw_value(el, attr, field_type)
            raw = _apply_pattern(raw, spec.get("pattern"), spec.get("group"))
            raw = _apply_transforms(raw, spec.get("transform"))
            raw = _coerce_type(raw, field_type)
            values.append(raw if raw is not None else default)
        return values

    # Single value
    target = container.select_one(sel) if sel else container
    if target is None:
        return default

    raw = _extract_raw_value(target, attr, field_type)
    raw = _apply_pattern(raw, spec.get("pattern"), spec.get("group"))
    raw = _apply_transforms(raw, spec.get("transform"))
    raw = _coerce_type(raw, field_type)

    return raw if raw is not None else default


def _extract_raw_value(
    el: Tag,
    attr: str | None = None,
    field_type: str | None = None,
) -> str | None:
    """Extract the raw value from an element."""
    if field_type == "html":
        return str(el)
    if field_type == "innerHtml":
        return el.decode_contents()

    if attr:
        if attr == "outerHTML":
            return str(el)
        if attr == "innerHTML":
            return el.decode_contents()
        val = el.get(attr)
        if isinstance(val, list):
            return " ".join(val)
        return val  # type: ignore[return-value]

    return el.get_text(strip=True) or None


def _apply_pattern(
    value: str | None,
    pattern: str | None,
    group: int | None = None,
) -> str | None:
    """Apply a regex pattern to extract a substring."""
    if pattern is None or value is None:
        return value
    try:
        match = re.search(pattern, value)
        if not match:
            return None
        return match.group(group or 0)
    except (re.error, IndexError):
        return value


def _apply_transforms(
    value: str | None,
    transforms: str | list[str] | None,
) -> str | None:
    """Apply a pipeline of transforms to a string value."""
    if transforms is None or value is None:
        return value
    pipeline = [transforms] if isinstance(transforms, str) else transforms
    result: str | None = value
    for t in pipeline:
        if result is None:
            break
        result = _apply_one_transform(result, t)
    return result


def _apply_one_transform(value: str, transform: str) -> str | None:
    """Apply a single transform to a string."""
    if transform == "trim":
        return value.strip()
    if transform == "lowercase":
        return value.lower()
    if transform == "uppercase":
        return value.upper()
    if transform == "number":
        cleaned = re.sub(r"[^0-9.\-,]", "", value).replace(",", "")
        try:
            return str(float(cleaned))
        except ValueError:
            return None
    if transform == "clean":
        return re.sub(r"\s+", " ", value).strip()
    if transform == "slug":
        result = value.lower()
        result = unicodedata.normalize("NFKD", result)
        result = re.sub(r"[^a-z0-9]+", "-", result)
        return result.strip("-")
    return value


def _coerce_type(value: str | None, field_type: str | None) -> Any:
    """Coerce a value to the specified type."""
    if value is None:
        return None
    if field_type == "number":
        cleaned = re.sub(r"[^0-9.\-,]", "", value).replace(",", "")
        try:
            return float(cleaned)
        except ValueError:
            return None
    return value


def _extract_nested(
    container: Tag,
    nested: NestedSpec,
) -> list[dict[str, Any]]:
    """Extract nested sub-items within a container."""
    selector = nested.get("selector", "")
    fields = nested.get("fields", {})
    limit = nested.get("limit")

    elements = container.select(selector)
    if limit is not None:
        elements = elements[:limit]

    return [_extract_item(el, fields) for el in elements]
