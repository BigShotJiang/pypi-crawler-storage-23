"""
Playwright-compatible Response and Request wrappers for Owl Browser.

Wraps navigation and network data into Response/Request objects
that mirror the Playwright API surface for seamless migration.
"""

from __future__ import annotations

from typing import Any


class Request:
    """HTTP request associated with a network event.

    Wraps request data from Owl Browser network logging into a
    Playwright-compatible Request object with url, method, headers,
    post_data, resource_type, and timing properties.
    """

    __slots__ = (
        "_url",
        "_method",
        "_headers",
        "_post_data",
        "_resource_type",
        "_response",
        "_raw",
    )

    def __init__(self, data: dict[str, Any] | None = None) -> None:
        """Initialize Request from network log data.

        Args:
            data: Raw request dictionary from browser_get_network_log.
        """
        self._raw = data or {}
        self._url: str = str(self._raw.get("url", ""))
        self._method: str = str(self._raw.get("method", "GET")).upper()
        self._headers: dict[str, str] = self._raw.get("headers", {})
        self._post_data: str | None = self._raw.get("post_data") or self._raw.get("postData")
        self._resource_type: str = str(self._raw.get("resource_type", self._raw.get("resourceType", "other")))
        self._response: Response | None = None

    @property
    def url(self) -> str:
        """The URL of the request."""
        return self._url

    @property
    def method(self) -> str:
        """HTTP method (GET, POST, etc.)."""
        return self._method

    @property
    def headers(self) -> dict[str, str]:
        """Request headers as a dictionary."""
        return self._headers

    @property
    def post_data(self) -> str | None:
        """POST request body, if any."""
        return self._post_data

    @property
    def resource_type(self) -> str:
        """Resource type (document, script, image, etc.)."""
        return self._resource_type

    @property
    def response(self) -> Response | None:
        """The Response for this request, if available."""
        return self._response

    async def all_headers(self) -> dict[str, str]:
        """Return all request headers.

        Returns:
            Headers dictionary.
        """
        return dict(self._headers)

    def header_value(self, name: str) -> str | None:
        """Return a header value by name (case-insensitive).

        Args:
            name: Header name.

        Returns:
            Header value or None.
        """
        lower_name = name.lower()
        for key, value in self._headers.items():
            if key.lower() == lower_name:
                return value
        return None

    def __repr__(self) -> str:
        return f"<Request method={self._method!r} url={self._url!r}>"


class Response:
    """HTTP response returned by navigation and network operations.

    Wraps the result dictionary from browser_navigate or network log
    entries to expose Playwright-compatible properties for status, URL,
    headers, and body content.
    """

    __slots__ = (
        "_url",
        "_status",
        "_status_text",
        "_headers",
        "_ok",
        "_raw",
        "_request",
        "_body",
    )

    def __init__(
        self,
        url: str,
        data: dict[str, Any] | None = None,
        request: Request | None = None,
    ) -> None:
        """Initialize Response from navigation result data.

        Args:
            url: The URL that was navigated to.
            data: Raw result dictionary from the browser tool execution.
            request: Associated Request object.
        """
        self._url = url
        self._raw = data or {}
        # The Owl Browser result dict uses "status" for action status (e.g., "ok"),
        # not HTTP status codes.  Prefer "http_status" if present; fall back to
        # inferring 200 for "ok"/success and 0 otherwise.
        raw_http = self._raw.get("http_status")
        if raw_http is not None:
            self._status: int = int(raw_http)
        else:
            action_status = self._raw.get("status", "")
            success_flag = self._raw.get("success", True)
            if action_status == "ok" or success_flag:
                self._status = 200
            else:
                self._status = 0
        self._status_text: str = str(self._raw.get("status_text", "OK"))
        self._headers: dict[str, str] = self._raw.get("headers", {})
        self._ok = 200 <= self._status < 300
        self._request = request
        self._body: str | None = self._raw.get("body")

    @property
    def url(self) -> str:
        """The URL of the response."""
        return self._url

    @property
    def status(self) -> int:
        """HTTP status code (e.g., 200, 404, 500)."""
        return self._status

    @property
    def status_text(self) -> str:
        """HTTP status text (e.g., 'OK', 'Not Found')."""
        return self._status_text

    @property
    def ok(self) -> bool:
        """Whether the response status is in the 2xx range."""
        return self._ok

    @property
    def headers(self) -> dict[str, str]:
        """Response headers as a dictionary."""
        return self._headers

    @property
    def request(self) -> Request | None:
        """The Request that produced this response."""
        return self._request

    def header_value(self, name: str) -> str | None:
        """Return a header value by name (case-insensitive).

        Args:
            name: Header name to look up.

        Returns:
            Header value or None if not found.
        """
        lower_name = name.lower()
        for key, value in self._headers.items():
            if key.lower() == lower_name:
                return value
        return None

    async def all_headers(self) -> dict[str, str]:
        """Return all response headers.

        Returns:
            Headers dictionary.
        """
        return dict(self._headers)

    async def body(self) -> bytes:
        """Return the response body as bytes.

        Returns:
            Response body bytes (empty if not captured).
        """
        if self._body is not None:
            return self._body.encode("utf-8") if isinstance(self._body, str) else self._body
        return b""

    async def text(self) -> str:
        """Return the response body as text.

        Returns:
            Response body string.
        """
        raw = await self.body()
        return raw.decode("utf-8", errors="replace")

    async def json(self) -> Any:
        """Parse the response body as JSON.

        Returns:
            Parsed JSON value.

        Raises:
            ValueError: If body is not valid JSON.
        """
        import json as _json

        return _json.loads(await self.text())

    async def finished(self) -> None:
        """Wait for the response to finish. No-op for Owl Browser."""

    def __repr__(self) -> str:
        return f"<Response url={self._url!r} status={self._status}>"
