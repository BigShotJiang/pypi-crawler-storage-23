"""
Playwright-compatible BrowserType class for Owl Browser.

Provides the connect() entry point that creates an OwlBrowser client,
establishes the connection, and returns a Browser instance. Also provides
connect_over_cdp() as an alias, launch() with a clear error, and
launch_persistent_context() as a stub.
"""

from __future__ import annotations

from typing import Any

from ..client import OwlBrowser
from ..types import RemoteConfig
from .browser import Browser
from .context import BrowserContext
from .page import Page


class BrowserType:
    """Factory for creating browser connections.

    Mirrors Playwright's BrowserType (chromium, firefox, webkit) pattern.
    In Owl Browser, only connect() is supported -- launch() raises an
    error since the browser process is managed externally (Docker, CLI,
    or desktop application).

    Usage:
        ```python
        from owl_browser.playwright import chromium

        browser = await chromium.connect(
            ws_endpoint='http://localhost:8080',
            token='your-token',
        )
        ```
    """

    __slots__ = ("_name",)

    def __init__(self, name: str = "chromium") -> None:
        """Initialize BrowserType.

        Args:
            name: Engine name identifier (e.g., 'chromium').
        """
        self._name = name

    @property
    def name(self) -> str:
        """The browser engine name."""
        return self._name

    async def connect(
        self,
        ws_endpoint: str = "",
        *,
        token: str | None = None,
        timeout: float = 30.0,
        slow_mo: float = 0,
        headers: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> Browser:
        """Connect to a running Owl Browser instance.

        Creates an OwlBrowser client, connects to the server, and
        returns a Browser ready for context creation.

        Args:
            ws_endpoint: The HTTP/WS URL of the Owl Browser server
                         (e.g., 'http://localhost:8080').
            token: Bearer token for authentication. Required unless
                   provided via kwargs.
            timeout: Connection timeout in seconds.
            slow_mo: Slow down operations by this many ms (accepted for compat).
            headers: Additional HTTP headers for the connection.
            **kwargs: Additional BrowserConnectOptions.

        Returns:
            Connected Browser instance.

        Raises:
            ValueError: If token is not provided.
            ConnectionError: If connection to the server fails.
        """
        if not token:
            token = kwargs.get("token")
        if not token:
            raise ValueError(
                "Authentication token is required. "
                "Pass token= to connect() or set OWL_HTTP_TOKEN env variable."
            )

        url = ws_endpoint or kwargs.get("url", "http://localhost:8080")
        # Normalize URL
        url = url.rstrip("/")
        if url.endswith("/ws"):
            url = url[:-3]

        config = RemoteConfig(
            url=url,
            token=token,
            timeout=timeout,
            api_prefix="",
        )
        client = OwlBrowser(config)
        await client.connect()

        return Browser(client)

    async def connect_over_cdp(
        self,
        endpoint_url: str,
        *,
        token: str | None = None,
        timeout: float = 30.0,
        slow_mo: float = 0,
        headers: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> Browser:
        """Connect via CDP endpoint (redirects to connect()).

        Provided for Playwright API compatibility. Owl Browser uses
        its own HTTP/WS transport internally, not raw CDP.

        Args:
            endpoint_url: Browser server URL.
            token: Authentication token.
            timeout: Connection timeout in seconds.
            slow_mo: Operation delay in ms.
            headers: Additional HTTP headers.
            **kwargs: Additional connection options.

        Returns:
            Connected Browser instance.
        """
        return await self.connect(
            ws_endpoint=endpoint_url,
            token=token,
            timeout=timeout,
            slow_mo=slow_mo,
            headers=headers,
            **kwargs,
        )

    async def launch(self, **kwargs: Any) -> Browser:
        """Launch a new browser (NOT SUPPORTED).

        Owl Browser processes are managed externally (Docker container,
        CLI, or desktop application). Use connect() instead.

        Args:
            **kwargs: Launch options (ignored).

        Raises:
            NotImplementedError: Always, with guidance to use connect().
        """
        raise NotImplementedError(
            "Owl Browser does not support launch(). "
            "The browser process is managed externally. "
            "Use connect(ws_endpoint='http://host:port', token='...') instead."
        )

    async def launch_persistent_context(
        self,
        user_data_dir: str,
        **kwargs: Any,
    ) -> BrowserContext:
        """Launch a persistent browser context (NOT SUPPORTED).

        Owl Browser manages profiles through its own profile system
        (browser_create_profile, browser_load_profile). This method
        raises an error with guidance.

        Args:
            user_data_dir: Path to user data directory (ignored).
            **kwargs: Context options.

        Raises:
            NotImplementedError: Always, with guidance to use profiles.
        """
        raise NotImplementedError(
            "Owl Browser does not support launch_persistent_context(). "
            "Use connect() to get a Browser, then new_context() to create "
            "contexts. For persistent sessions, use browser_create_profile "
            "and browser_load_profile tools via the OwlBrowser client."
        )

    @property
    def executable_path(self) -> str:
        """Path to the browser executable (not applicable).

        Returns:
            Empty string (Owl Browser is managed externally).
        """
        return ""

    def __repr__(self) -> str:
        return f"<BrowserType name={self._name!r}>"
