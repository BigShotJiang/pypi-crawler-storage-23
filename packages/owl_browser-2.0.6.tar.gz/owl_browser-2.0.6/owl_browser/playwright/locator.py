"""
Playwright-compatible Locator class for Owl Browser.

Provides lazy element references that store a selector and delegate
all operations to the parent Page instance on invocation. Supports
Playwright selector engines: text=, css=, xpath=, data-testid=, etc.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .page import Page


_HAS_TEXT_RE = re.compile(r':has-text\([\'"](.+?)[\'"]\)')


def _convert_has_text(selector: str) -> str:
    """Convert Playwright :has-text() pseudo-selector to text for semantic matching.

    The browser does not support XPath or :has-text() CSS pseudo-selectors.
    Instead, extract the text content and pass it to the semantic matcher
    which finds elements by text content natively.

    ``button:has-text('Enable')`` → ``Enable button``
    ``:has-text('foo')``          → ``foo``

    If no :has-text() is present, returns the selector unchanged.
    """
    m = _HAS_TEXT_RE.search(selector)
    if not m:
        return selector
    text = m.group(1)
    # Preserve tag prefix as semantic context (e.g., "button" → "Enable button")
    prefix = selector[:m.start()].strip()
    if prefix and prefix.isalpha():
        return f"{text} {prefix}"
    return text


def _convert_selector(selector: str) -> str:
    """Convert Playwright selector syntax to CSS/XPath that Owl understands.

    Playwright supports prefix-based selector engines:
    - text=Sign In -> natural language / text-based selector
    - css=#button -> CSS selector
    - xpath=//div -> XPath selector
    - role=button -> [role="button"]
    - data-testid=submit -> [data-testid="submit"]
    - id=main -> #main
    - placeholder=Email -> input[placeholder="Email"]
    - alt=Logo -> img[alt="Logo"]
    - title=Close -> [title="Close"]
    - label=Username -> label text-based (natural language)

    Also converts Playwright pseudo-selectors:
    - :has-text('...') -> XPath contains()

    Selectors without a recognized prefix are passed through as-is,
    which works because Owl Browser's selector engine accepts CSS
    selectors and natural language descriptions natively.

    Args:
        selector: Playwright-style selector string.

    Returns:
        Converted selector for Owl Browser.
    """
    if not selector:
        return selector

    # Handle :has-text() pseudo-selector first
    if ":has-text(" in selector:
        return _convert_has_text(selector)

    # Check for engine prefix pattern "engine=value"
    match = re.match(r'^(\w[\w-]*)=(.+)$', selector)
    if not match:
        return selector

    engine, value = match.group(1), match.group(2)

    match engine:
        case "css":
            return value
        case "xpath":
            return value  # Owl accepts XPath directly
        case "text":
            # Pass as natural language -- Owl semantic matcher handles it
            return value
        case "id":
            return f"#{value}"
        case "data-testid":
            return f'[data-testid="{value}"]'
        case "role":
            return f'[role="{value}"]'
        case "placeholder":
            return f'[placeholder="{value}"]'
        case "alt":
            return f'[alt="{value}"]'
        case "title":
            return f'[title="{value}"]'
        case "label":
            # Use as natural language description
            return value
        case _:
            # Unknown engine, pass through as-is
            return selector


class Locator:
    """Lazy element reference that delegates operations to a Page.

    Locators are the primary way to find and interact with elements in
    Playwright. They store a selector string and only resolve it when
    an action is performed, making them resilient to DOM changes.

    All action methods are async and delegate to the corresponding
    Page method with the stored selector.
    """

    __slots__ = ("_page", "_selector", "_nth_index", "_has_text", "_has_not_text")

    def __init__(
        self,
        page: Page,
        selector: str,
        nth_index: int | None = None,
        has_text: str | None = None,
        has_not_text: str | None = None,
    ) -> None:
        """Initialize Locator.

        Args:
            page: Parent Page instance for tool execution.
            selector: CSS selector, XPath, or text description.
            nth_index: If set, targets the nth matching element (0-based).
            has_text: Filter to elements containing this text.
            has_not_text: Filter to elements NOT containing this text.
        """
        self._page = page
        self._selector = _convert_selector(selector)
        self._nth_index = nth_index
        self._has_text = has_text
        self._has_not_text = has_not_text

    @property
    def _effective_selector(self) -> str:
        """Build the effective selector.

        When ``_nth_index`` is set, the selector is unchanged here --
        the nth selection is handled at execution time via JavaScript
        in methods that need it. For simple first-match semantics the
        browser's querySelector already returns the first match, so
        nth_index=0 just uses the base selector.
        """
        return self._selector

    @property
    def first(self) -> Locator:
        """Return a locator targeting the first matching element.

        Uses nth_index=0 which delegates to the base selector -- the
        browser's querySelector naturally returns the first match.
        """
        return Locator(self._page, self._selector, nth_index=0)

    @property
    def last(self) -> Locator:
        """Return a locator targeting the last matching element."""
        return Locator(self._page, self._selector, nth_index=-1)

    def nth(self, index: int) -> Locator:
        """Return a locator targeting the nth matching element (0-based).

        Args:
            index: Zero-based index of the element to target.

        Returns:
            New Locator targeting the specified element.
        """
        return Locator(self._page, self._selector, nth_index=index)

    def locator(self, selector: str) -> Locator:
        """Create a chained locator by combining selectors.

        Args:
            selector: Additional selector to scope within this element.

        Returns:
            New Locator with combined selector.
        """
        child = _convert_selector(selector)
        combined = f"{self._effective_selector} {child}"
        return Locator(self._page, combined)

    def filter(
        self,
        *,
        has_text: str | re.Pattern[str] | None = None,
        has_not_text: str | re.Pattern[str] | None = None,
        has: Locator | None = None,
        has_not: Locator | None = None,
    ) -> Locator:
        """Filter the locator to a subset of matching elements.

        Args:
            has_text: Require element text to contain this string/pattern.
            has_not_text: Require element text NOT to contain this.
            has: Require a descendant matching this locator.
            has_not: Require NO descendant matching this locator.

        Returns:
            Filtered Locator.
        """
        text_filter = None
        not_text_filter = None
        if has_text is not None:
            text_filter = has_text.pattern if isinstance(has_text, re.Pattern) else has_text
        if has_not_text is not None:
            not_text_filter = has_not_text.pattern if isinstance(has_not_text, re.Pattern) else has_not_text

        # Build combined selector with :has() pseudo-class for descendant filters
        sel = self._effective_selector
        if has is not None:
            sel = f"{sel}:has({has._effective_selector})"
        if has_not is not None:
            sel = f"{sel}:not(:has({has_not._effective_selector}))"

        return Locator(self._page, sel, has_text=text_filter, has_not_text=not_text_filter)

    def or_(self, locator: Locator) -> Locator:
        """Create a locator matching either this or the given locator.

        Uses CSS comma combinator for union matching.

        Args:
            locator: Alternative locator.

        Returns:
            New Locator matching either selector.
        """
        combined = f"{self._effective_selector}, {locator._effective_selector}"
        return Locator(self._page, combined)

    def and_(self, locator: Locator) -> Locator:
        """Create a locator matching both this and the given locator.

        Concatenates selectors (CSS compound selector).

        Args:
            locator: Additional selector constraint.

        Returns:
            New Locator matching both selectors.
        """
        combined = f"{self._effective_selector}{locator._effective_selector}"
        return Locator(self._page, combined)

    def _tool_params(self, **extra: Any) -> dict[str, Any]:
        """Build common tool parameters including optional index.

        When ``_nth_index`` is set (and is not 0/None), includes the
        ``index`` parameter so the browser targets the Nth match natively.

        Args:
            **extra: Additional tool-specific parameters.

        Returns:
            Dict of parameters for ``_client.execute()``.
        """
        params: dict[str, Any] = {
            "context_id": self._page._context_id,
            "selector": self._selector,
        }
        if self._nth_index is not None and self._nth_index != 0:
            params["index"] = self._nth_index
        params.update(extra)
        return params

    # ---- Actions ----

    async def click(self, **kwargs: Any) -> None:
        """Click the element.

        Args:
            **kwargs: Click options (button, click_count, delay, etc.).
        """
        button = kwargs.get("button", "left")
        click_count = kwargs.get("click_count", 1)
        if button == "right":
            await self._page._client.execute(
                "browser_right_click", **self._tool_params(),
            )
        elif click_count >= 2:
            await self._page._client.execute(
                "browser_double_click", **self._tool_params(),
            )
        else:
            await self._page._client.execute(
                "browser_click", **self._tool_params(),
            )
        # Refresh parent page URL in case click triggered navigation
        try:
            await self._page._client.execute(
                "browser_wait_for_network_idle",
                context_id=self._page._context_id,
                timeout=1000,
            )
        except Exception:
            pass
        await self._page._refresh_url()

    async def dblclick(self, **kwargs: Any) -> None:
        """Double-click the element.

        Args:
            **kwargs: Click options.
        """
        await self._page._client.execute(
            "browser_double_click", **self._tool_params(),
        )

    async def fill(self, value: str, **kwargs: Any) -> None:
        """Clear the element and fill it with the given text.

        Args:
            value: Text to fill.
            **kwargs: Fill options.
        """
        await self._page._client.execute(
            "browser_clear_input", **self._tool_params(),
        )
        await self._page._client.execute(
            "browser_type", **self._tool_params(text=value),
        )

    async def type(self, text: str, **kwargs: Any) -> None:
        """Type text into the element character by character.

        Args:
            text: Text to type.
            **kwargs: Type options.
        """
        await self._page._client.execute(
            "browser_type", **self._tool_params(text=text),
        )

    async def press(self, key: str, **kwargs: Any) -> None:
        """Focus the element and press a key.

        Args:
            key: Key to press (e.g., 'Enter', 'Tab', 'Control+a').
            **kwargs: Press options.
        """
        await self._page._client.execute(
            "browser_focus", **self._tool_params(),
        )
        await self._page.keyboard.press(key)

    async def hover(self, **kwargs: Any) -> None:
        """Hover over the element.

        Args:
            **kwargs: Hover options.
        """
        await self._page._client.execute(
            "browser_hover", **self._tool_params(),
        )

    async def focus(self, **kwargs: Any) -> None:
        """Focus the element.

        Args:
            **kwargs: Focus options.
        """
        await self._page._client.execute(
            "browser_focus", **self._tool_params(),
        )

    async def select_option(
        self,
        value: str | list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Select an option in a <select> element.

        Args:
            value: Option value(s) to select.
            **kwargs: Options for API compatibility.
        """
        pick_value = ""
        if isinstance(value, list):
            pick_value = value[0] if value else ""
        elif value is not None:
            pick_value = value
        elif (label := kwargs.get("label")) is not None:
            pick_value = label[0] if isinstance(label, list) and label else str(label)
        await self._page._client.execute(
            "browser_pick", **self._tool_params(value=pick_value),
        )

    async def set_input_files(
        self,
        files: str | list[str],
        **kwargs: Any,
    ) -> None:
        """Upload files to a file input element.

        Args:
            files: File path(s) to upload.
            **kwargs: Options for API compatibility.
        """
        import json as _json
        file_list = [files] if isinstance(files, str) else files
        await self._page._client.execute(
            "browser_upload_file",
            **self._tool_params(file_paths=_json.dumps(file_list)),
        )

    # ---- Content extraction ----

    async def text_content(self, **kwargs: Any) -> str | None:
        """Get the text content of the element.

        Returns:
            Text content string or None.
        """
        result: Any = await self._page._client.execute(
            "browser_extract_text", **self._tool_params(),
        )
        if isinstance(result, dict):
            return result.get("text", result.get("content"))
        return str(result) if result is not None else None

    async def inner_html(self, **kwargs: Any) -> str:
        """Get the inner HTML of the element.

        Returns:
            Inner HTML string.
        """
        import json as _json
        result: Any = await self._page._client.execute(
            "browser_get_html", **self._tool_params(),
        )
        if isinstance(result, str):
            try:
                decoded = _json.loads(result)
                if isinstance(decoded, str):
                    return decoded
            except (ValueError, TypeError):
                pass
            return result
        if isinstance(result, dict):
            return str(result.get("html", result.get("content", "")))
        return str(result) if result is not None else ""

    async def inner_text(self, **kwargs: Any) -> str:
        """Get the inner text of the element.

        Returns:
            Inner text string.
        """
        result = await self.text_content(**kwargs)
        return result or ""

    async def get_attribute(self, name: str, **kwargs: Any) -> str | None:
        """Get an attribute value from the element.

        Args:
            name: Attribute name.

        Returns:
            Attribute value or None.
        """
        result: Any = await self._page._client.execute(
            "browser_get_attribute", **self._tool_params(attribute=name),
        )
        if isinstance(result, dict):
            val = result.get("value", result.get("attribute"))
            if val is not None and str(val):
                return str(val)
            return None
        if isinstance(result, str) and result:
            return result
        return None

    async def input_value(self, **kwargs: Any) -> str:
        """Get the current value of an input element.

        Uses browser_get_attribute with attribute='value' to read the
        DOM .value property natively (not the HTML attribute).

        Returns:
            Current input value string.
        """
        result: Any = await self._page._client.execute(
            "browser_get_attribute", **self._tool_params(attribute="value"),
        )
        if isinstance(result, dict):
            val = result.get("value", result.get("attribute"))
            return str(val) if val is not None else ""
        return str(result) if result else ""

    # ---- State checks ----

    async def is_visible(self, **kwargs: Any) -> bool:
        """Check whether the element is visible.

        Returns False for non-existent elements (matching Playwright).

        Returns:
            True if visible.
        """
        try:
            result: Any = await self._page._client.execute(
                "browser_is_visible", **self._tool_params(),
            )
        except Exception:
            return False
        if isinstance(result, dict):
            if result.get("status") == "element_not_found":
                return False
            if "error_code" in result:
                return result["error_code"] == "visible"
            if "visible" in result:
                return bool(result["visible"])
            return bool(result.get("success", False))
        return bool(result)

    async def is_enabled(self, **kwargs: Any) -> bool:
        """Check whether the element is enabled.

        Returns:
            True if enabled.
        """
        try:
            result: Any = await self._page._client.execute(
                "browser_is_enabled", **self._tool_params(),
            )
        except Exception:
            return False
        if isinstance(result, dict):
            if result.get("status") == "element_not_found":
                return False
            if "error_code" in result:
                return result["error_code"] == "enabled"
            if "enabled" in result:
                return bool(result["enabled"])
            return bool(result.get("success", False))
        return bool(result)

    async def is_checked(self, **kwargs: Any) -> bool:
        """Check whether a checkbox/radio element is checked.

        Returns:
            True if checked.
        """
        try:
            result: Any = await self._page._client.execute(
                "browser_is_checked", **self._tool_params(),
            )
        except Exception:
            return False
        if isinstance(result, dict):
            if result.get("status") == "element_not_found":
                return False
            if "error_code" in result:
                return result["error_code"] == "checked"
            if "checked" in result:
                return bool(result["checked"])
            return False
        return bool(result)

    async def is_hidden(self, **kwargs: Any) -> bool:
        """Check whether the element is hidden.

        Returns:
            True if hidden.
        """
        return not await self.is_visible(**kwargs)

    async def is_disabled(self, **kwargs: Any) -> bool:
        """Check whether the element is disabled.

        Returns:
            True if disabled.
        """
        return not await self.is_enabled(**kwargs)

    async def is_editable(self, **kwargs: Any) -> bool:
        """Check whether the element is editable.

        Uses browser_is_editable natively. Returns True when the tool
        reports error_code='editable'.

        Returns:
            True if editable.
        """
        try:
            result: Any = await self._page._client.execute(
                "browser_is_editable", **self._tool_params(),
            )
        except Exception:
            return False
        if isinstance(result, dict):
            return result.get("error_code") == "editable"
        return False

    # ---- Check/Uncheck ----

    async def check(self, **kwargs: Any) -> None:
        """Check a checkbox element (no-op if already checked).

        Args:
            **kwargs: Options for API compatibility.
        """
        if not await self.is_checked():
            await self._page._client.execute(
                "browser_click", **self._tool_params(),
            )

    async def uncheck(self, **kwargs: Any) -> None:
        """Uncheck a checkbox element (no-op if already unchecked).

        Args:
            **kwargs: Options for API compatibility.
        """
        if await self.is_checked():
            await self._page._client.execute(
                "browser_click", **self._tool_params(),
            )

    # ---- Bounding box & scroll ----

    async def bounding_box(self, **kwargs: Any) -> dict[str, float] | None:
        """Get the bounding box of the element.

        Returns:
            Dict with x, y, width, height or None if not visible.
        """
        result: Any = await self._page._client.execute(
            "browser_get_bounding_box", **self._tool_params(),
        )
        if isinstance(result, dict) and "x" in result:
            return {
                "x": float(result["x"]),
                "y": float(result["y"]),
                "width": float(result.get("width", 0)),
                "height": float(result.get("height", 0)),
            }
        return None

    async def scroll_into_view_if_needed(self, **kwargs: Any) -> None:
        """Scroll the element into view if not currently visible.

        Args:
            **kwargs: Options for API compatibility.
        """
        await self._page._client.execute(
            "browser_scroll_to_element", **self._tool_params(),
        )

    async def highlight(self, **kwargs: Any) -> None:
        """Visually highlight the element for debugging.

        Args:
            **kwargs: Options for API compatibility.
        """
        await self._page._client.execute(
            "browser_highlight", **self._tool_params(),
        )

    async def select_text(self, **kwargs: Any) -> None:
        """Select all text within the element.

        Args:
            **kwargs: Options for API compatibility.
        """
        await self._page._client.execute(
            "browser_select_all", **self._tool_params(),
        )

    async def dispatch_event(self, event_type: str, **kwargs: Any) -> None:
        """Dispatch a DOM event on the element.

        Uses browser_dispatch_event natively.

        Args:
            event_type: Event type (e.g., 'click', 'input', 'change').
            **kwargs: Event properties (bubbles, etc.).
        """
        await self._page._client.execute(
            "browser_dispatch_event",
            **self._tool_params(
                event_type=event_type,
                bubbles=kwargs.get("bubbles", True),
            ),
        )

    # ---- Wait ----

    async def wait_for(self, **kwargs: Any) -> None:
        """Wait for the element to satisfy a state condition.

        Args:
            **kwargs: WaitForSelectorOptions (state, timeout, etc.).
        """
        timeout = kwargs.get("timeout")
        params: dict[str, Any] = {"selector": self._selector}
        if timeout is not None:
            params["timeout"] = timeout
        await self._page.wait_for_selector(**params)

    # ---- Count / All ----

    async def count(self) -> int:
        """Return the number of elements matching this locator.

        Uses browser_count_elements for native element counting.

        Returns:
            Number of matching elements.
        """
        try:
            result: Any = await self._page._client.execute(
                "browser_count_elements",
                context_id=self._page._context_id,
                selector=self._selector,
            )
            if isinstance(result, dict):
                raw = result.get("error_code", result.get("count", result.get("total", "0")))
                return int(raw)
            return int(result) if result is not None else 0
        except Exception:
            return 0

    async def all(self) -> list[Locator]:
        """Resolve all matching elements as individual locators.

        Returns:
            List of Locator objects, one per matching element.
        """
        n = await self.count()
        return [Locator(self._page, self._selector, nth_index=i) for i in range(n)]

    # ---- Screenshot ----

    async def screenshot(self, **kwargs: Any) -> bytes:
        """Take a screenshot of the element.

        Args:
            **kwargs: ScreenshotOptions (path, type, quality, etc.).

        Returns:
            PNG image data as bytes.
        """
        kwargs["selector"] = self._selector
        if self._nth_index is not None and self._nth_index != 0:
            kwargs["index"] = self._nth_index
        return await self._page.screenshot(**kwargs)

    def __repr__(self) -> str:
        return f"<Locator selector={self._effective_selector!r}>"
