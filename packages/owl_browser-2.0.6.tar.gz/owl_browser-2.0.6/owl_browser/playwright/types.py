"""
Playwright-compatible type definitions for Owl Browser.

TypedDict definitions that mirror Playwright's Python API option types,
enabling drop-in compatibility for code migrating from Playwright.
All types use modern Python 3.12+ syntax with strict typing.
"""

from __future__ import annotations

from typing import Literal, NotRequired, TypedDict


# ==================== Viewport & Geometry ====================


class ViewportSize(TypedDict):
    """Viewport dimensions in pixels."""

    width: int
    height: int


class Position(TypedDict, total=False):
    """XY position for click/hover operations."""

    x: float
    y: float


class BoundingBox(TypedDict):
    """Element bounding box in viewport coordinates."""

    x: float
    y: float
    width: float
    height: float


# ==================== Navigation ====================


class GotoOptions(TypedDict, total=False):
    """Options for page.goto() navigation."""

    timeout: float
    wait_until: Literal["load", "domcontentloaded", "networkidle", "commit"]
    referer: str


# ==================== Interaction ====================


class ClickOptions(TypedDict, total=False):
    """Options for page.click() interaction."""

    button: Literal["left", "right", "middle"]
    click_count: int
    delay: float
    force: bool
    modifiers: list[Literal["Alt", "Control", "Meta", "Shift"]]
    no_wait_after: bool
    position: Position
    strict: bool
    timeout: float
    trial: bool


class FillOptions(TypedDict, total=False):
    """Options for page.fill() text input."""

    force: bool
    no_wait_after: bool
    strict: bool
    timeout: float


class TypeOptions(TypedDict, total=False):
    """Options for page.type() keystroke simulation."""

    delay: float
    no_wait_after: bool
    strict: bool
    timeout: float


class PressOptions(TypedDict, total=False):
    """Options for page.press() key input."""

    delay: float
    no_wait_after: bool
    strict: bool
    timeout: float


class HoverOptions(TypedDict, total=False):
    """Options for page.hover()."""

    force: bool
    modifiers: list[Literal["Alt", "Control", "Meta", "Shift"]]
    no_wait_after: bool
    position: Position
    strict: bool
    timeout: float
    trial: bool


class FocusOptions(TypedDict, total=False):
    """Options for page.focus()."""

    strict: bool
    timeout: float


class DragOptions(TypedDict, total=False):
    """Options for page.drag_and_drop()."""

    force: bool
    no_wait_after: bool
    source_position: Position
    target_position: Position
    strict: bool
    timeout: float


class SelectOption(TypedDict, total=False):
    """Option specification for select_option()."""

    value: str
    label: str
    index: int


class InputFileSpec(TypedDict):
    """File specification for set_input_files()."""

    name: str
    mimeType: str
    buffer: bytes


# ==================== Screenshot ====================


class ScreenshotOptions(TypedDict, total=False):
    """Options for page.screenshot() capture."""

    path: str
    full_page: bool
    clip: dict[str, float]
    type: Literal["png", "jpeg"]
    quality: int
    scale: Literal["css", "device"]
    timeout: float
    mask: list[str]


# ==================== Wait ====================


class WaitForSelectorOptions(TypedDict, total=False):
    """Options for page.wait_for_selector()."""

    state: Literal["attached", "detached", "hidden", "visible"]
    strict: bool
    timeout: float


class WaitForFunctionOptions(TypedDict, total=False):
    """Options for page.wait_for_function()."""

    polling: float | Literal["raf"]
    timeout: float


class WaitForURLOptions(TypedDict, total=False):
    """Options for page.wait_for_url()."""

    timeout: float
    wait_until: Literal["load", "domcontentloaded", "networkidle", "commit"]


class WaitForLoadStateOptions(TypedDict, total=False):
    """Options for page.wait_for_load_state()."""

    timeout: float


# ==================== Cookie ====================


class Cookie(TypedDict):
    """Cookie definition for context cookie operations."""

    name: str
    value: str
    url: NotRequired[str]
    domain: NotRequired[str]
    path: NotRequired[str]
    expires: NotRequired[float]
    httpOnly: NotRequired[bool]
    secure: NotRequired[bool]
    sameSite: NotRequired[Literal["Strict", "Lax", "None"]]


class StorageState(TypedDict, total=False):
    """Browser storage state for persistence across sessions."""

    cookies: list[Cookie]
    origins: list[dict[str, object]]


# ==================== Geolocation & Locale ====================


class Geolocation(TypedDict, total=False):
    """Geolocation coordinates."""

    latitude: float
    longitude: float
    accuracy: float


# ==================== Proxy ====================


class ProxySettings(TypedDict, total=False):
    """Proxy configuration for browser context."""

    server: str
    username: str
    password: str
    bypass: str


# ==================== Video / HAR Recording ====================


class RecordVideoOptions(TypedDict, total=False):
    """Options for recording video of browser sessions."""

    dir: str
    size: ViewportSize


class RecordHarOptions(TypedDict, total=False):
    """Options for recording HAR (HTTP Archive) files."""

    path: str
    omit_content: bool
    content: Literal["omit", "embed", "attach"]
    mode: Literal["full", "minimal"]
    url_filter: str


# ==================== Network ====================


class RouteOptions(TypedDict, total=False):
    """Options for page.route() network interception."""

    times: int


class FulfillOptions(TypedDict, total=False):
    """Options for route.fulfill() mock response."""

    status: int
    headers: dict[str, str]
    content_type: str
    body: str | bytes
    path: str
    response: object


class ContinueOptions(TypedDict, total=False):
    """Options for route.continue_() request modification."""

    url: str
    method: str
    headers: dict[str, str]
    post_data: str | bytes


class AbortOptions(TypedDict, total=False):
    """Options for route.abort() request cancellation."""

    error_code: str


# ==================== Connect / Launch ====================


class BrowserConnectOptions(TypedDict, total=False):
    """Options for BrowserType.connect()."""

    timeout: float
    slow_mo: float
    headers: dict[str, str]


class LaunchOptions(TypedDict, total=False):
    """Options for BrowserType.launch()."""

    headless: bool
    channel: str
    executable_path: str
    args: list[str]
    timeout: float
    slow_mo: float


# ==================== Context ====================


class BrowserContextOptions(TypedDict, total=False):
    """Options for Browser.new_context()."""

    viewport: ViewportSize | None
    user_agent: str
    locale: str
    timezone_id: str
    geolocation: Geolocation
    permissions: list[str]
    color_scheme: Literal["light", "dark", "no-preference"]
    reduced_motion: Literal["reduce", "no-preference"]
    forced_colors: Literal["active", "none"]
    proxy: ProxySettings
    ignore_https_errors: bool
    java_script_enabled: bool
    bypass_csp: bool
    device_scale_factor: float
    is_mobile: bool
    has_touch: bool
    extra_http_headers: dict[str, str]
    record_video: RecordVideoOptions
    record_har: RecordHarOptions
    storage_state: StorageState | str
    strict_selectors: bool
    service_workers: Literal["allow", "block"]
    base_url: str


# ==================== Device Descriptor ====================


class DeviceDescriptor(TypedDict, total=False):
    """Device emulation descriptor (viewport + user agent)."""

    user_agent: str
    viewport: ViewportSize
    device_scale_factor: float
    is_mobile: bool
    has_touch: bool
    default_browser_type: str
