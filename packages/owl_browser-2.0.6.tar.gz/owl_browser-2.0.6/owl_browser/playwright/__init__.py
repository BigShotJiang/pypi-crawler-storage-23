"""
Playwright-compatible API layer for Owl Browser.

Provides a drop-in replacement for Playwright's Python API, mapping
Playwright method calls to Owl Browser tool executions. Enables
migration from Playwright to Owl Browser with minimal code changes.

All core classes, event objects, type definitions, and module-level
singletons (chromium, firefox, webkit) are exported from this package.

Example:
    ```python
    from owl_browser.playwright import chromium

    async def main():
        browser = await chromium.connect(
            ws_endpoint='http://localhost:8080',
            token='your-secret-token',
        )
        context = await browser.new_context()
        page = await context.new_page()

        await page.goto('https://example.com')
        await page.click('#button')
        title = await page.title()

        await browser.close()
    ```

Device emulation:
    ```python
    from owl_browser.playwright import chromium, devices

    iphone = devices['iPhone 14']
    browser = await chromium.connect(ws_endpoint=url, token=token)
    context = await browser.new_context(**iphone)
    page = await context.new_page()
    ```
"""

from .browser import Browser
from .browser_type import BrowserType
from .context import BrowserContext
from .extractor import (
    count_elements,
    extract_meta,
    extract_structured_data,
    extract_table,
    query_all,
    query_first,
)
from .frame import Frame, FrameLocator
from .keyboard import Keyboard
from .locator import Locator
from .mouse import Mouse
from .page import Page
from .page_events import ConsoleMessage, Dialog, Download, Route, Video
from .response import Request, Response
from .types import (
    AbortOptions,
    BoundingBox,
    BrowserConnectOptions,
    BrowserContextOptions,
    ClickOptions,
    ContinueOptions,
    Cookie,
    DeviceDescriptor,
    DragOptions,
    FillOptions,
    FocusOptions,
    FulfillOptions,
    Geolocation,
    GotoOptions,
    HoverOptions,
    InputFileSpec,
    LaunchOptions,
    Position,
    PressOptions,
    ProxySettings,
    RecordHarOptions,
    RecordVideoOptions,
    RouteOptions,
    ScreenshotOptions,
    SelectOption,
    StorageState,
    TypeOptions,
    ViewportSize,
    WaitForFunctionOptions,
    WaitForLoadStateOptions,
    WaitForSelectorOptions,
    WaitForURLOptions,
)

# ---- Singleton BrowserType instances ----
# Mirrors Playwright's module-level chromium/firefox/webkit objects.
# All three point to Owl Browser's Chromium-based engine.

chromium: BrowserType = BrowserType("chromium")
firefox: BrowserType = BrowserType("firefox")
webkit: BrowserType = BrowserType("webkit")


# ---- TimeoutError re-export ----

class TimeoutError(Exception):
    """Timeout error for Playwright API compatibility.

    Raised when an operation exceeds the configured timeout. This
    mirrors playwright.async_api.TimeoutError for drop-in compatibility.
    """


# ---- Device descriptors ----
# Common device configurations for emulation via browser.new_context(**devices['name'])

devices: dict[str, DeviceDescriptor] = {
    "Desktop Chrome": {
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "viewport": {"width": 1280, "height": 720},
        "device_scale_factor": 1,
        "is_mobile": False,
        "has_touch": False,
        "default_browser_type": "chromium",
    },
    "Desktop Chrome HiDPI": {
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "viewport": {"width": 1280, "height": 720},
        "device_scale_factor": 2,
        "is_mobile": False,
        "has_touch": False,
        "default_browser_type": "chromium",
    },
    "Desktop Firefox": {
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
        "viewport": {"width": 1280, "height": 720},
        "device_scale_factor": 1,
        "is_mobile": False,
        "has_touch": False,
        "default_browser_type": "firefox",
    },
    "Desktop Safari": {
        "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
        "viewport": {"width": 1280, "height": 720},
        "device_scale_factor": 1,
        "is_mobile": False,
        "has_touch": False,
        "default_browser_type": "webkit",
    },
    "Desktop Edge": {
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
        "viewport": {"width": 1280, "height": 720},
        "device_scale_factor": 1,
        "is_mobile": False,
        "has_touch": False,
        "default_browser_type": "chromium",
    },
    "iPhone 14": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 390, "height": 844},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPhone 14 Pro": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 393, "height": 852},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPhone 14 Pro Max": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 430, "height": 932},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPhone 15": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 393, "height": 852},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPhone 15 Pro": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 393, "height": 852},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPhone 15 Pro Max": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 430, "height": 932},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPhone SE": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 375, "height": 667},
        "device_scale_factor": 2,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPhone 12": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 390, "height": 844},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPhone 13": {
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 390, "height": 844},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPad (gen 7)": {
        "user_agent": "Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 810, "height": 1080},
        "device_scale_factor": 2,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPad Pro 11": {
        "user_agent": "Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 834, "height": 1194},
        "device_scale_factor": 2,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "iPad Mini": {
        "user_agent": "Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "viewport": {"width": 768, "height": 1024},
        "device_scale_factor": 2,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "webkit",
    },
    "Pixel 7": {
        "user_agent": "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "viewport": {"width": 412, "height": 915},
        "device_scale_factor": 2.625,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "chromium",
    },
    "Pixel 8": {
        "user_agent": "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "viewport": {"width": 412, "height": 915},
        "device_scale_factor": 2.625,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "chromium",
    },
    "Galaxy S23": {
        "user_agent": "Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "viewport": {"width": 360, "height": 780},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "chromium",
    },
    "Galaxy S23 Ultra": {
        "user_agent": "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "viewport": {"width": 384, "height": 824},
        "device_scale_factor": 3,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "chromium",
    },
    "Galaxy Tab S9": {
        "user_agent": "Mozilla/5.0 (Linux; Android 14; SM-X710) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "viewport": {"width": 800, "height": 1280},
        "device_scale_factor": 2,
        "is_mobile": True,
        "has_touch": True,
        "default_browser_type": "chromium",
    },
}


__all__ = [
    # Entry points
    "chromium",
    "firefox",
    "webkit",
    # Core classes
    "BrowserType",
    "Browser",
    "BrowserContext",
    "Page",
    "Frame",
    "FrameLocator",
    "Locator",
    "Keyboard",
    "Mouse",
    # Event objects
    "Dialog",
    "ConsoleMessage",
    "Download",
    "Video",
    "Route",
    # Network
    "Request",
    "Response",
    # Extraction functions
    "query_all",
    "query_first",
    "extract_table",
    "extract_meta",
    "extract_structured_data",
    "count_elements",
    # Devices
    "devices",
    # Errors
    "TimeoutError",
    # Type definitions
    "AbortOptions",
    "BoundingBox",
    "BrowserConnectOptions",
    "BrowserContextOptions",
    "ClickOptions",
    "ContinueOptions",
    "Cookie",
    "DeviceDescriptor",
    "DragOptions",
    "FillOptions",
    "FocusOptions",
    "FulfillOptions",
    "Geolocation",
    "GotoOptions",
    "HoverOptions",
    "InputFileSpec",
    "LaunchOptions",
    "Position",
    "PressOptions",
    "ProxySettings",
    "RecordHarOptions",
    "RecordVideoOptions",
    "RouteOptions",
    "ScreenshotOptions",
    "SelectOption",
    "StorageState",
    "TypeOptions",
    "ViewportSize",
    "WaitForFunctionOptions",
    "WaitForLoadStateOptions",
    "WaitForSelectorOptions",
    "WaitForURLOptions",
]
