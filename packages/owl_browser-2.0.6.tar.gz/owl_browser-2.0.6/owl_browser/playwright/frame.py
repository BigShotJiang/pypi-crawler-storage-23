"""
Playwright-compatible Frame and FrameLocator classes for Owl Browser.

Provides Frame abstraction with automatic frame switching, and
FrameLocator for scoped element interaction within iframes.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..client import OwlBrowser
    from .locator import Locator


class FrameLocator:
    """Locator scoped to a specific iframe.

    FrameLocator objects are created via page.frame_locator(selector).
    They switch to the target iframe before each operation and return
    to the main frame afterward. Supports chained locator() calls.
    """

    __slots__ = ("_client", "_context_id", "_frame_selector", "_page")

    def __init__(
        self,
        client: OwlBrowser,
        context_id: str,
        frame_selector: str,
        page: Any,
    ) -> None:
        """Initialize FrameLocator.

        Args:
            client: The OwlBrowser client instance.
            context_id: Browser context identifier.
            frame_selector: CSS selector for the iframe element.
            page: Parent Page instance for creating Locators.
        """
        self._client = client
        self._context_id = context_id
        self._frame_selector = frame_selector
        self._page = page

    def locator(self, selector: str) -> _FrameScopedLocator:
        """Create a locator scoped to this frame.

        The returned locator automatically switches to the frame before
        executing operations and returns to main frame afterward.

        Args:
            selector: CSS selector within the iframe.

        Returns:
            A FrameScopedLocator for the element.
        """
        return _FrameScopedLocator(
            client=self._client,
            context_id=self._context_id,
            frame_selector=self._frame_selector,
            selector=selector,
            page=self._page,
        )

    def frame_locator(self, selector: str) -> FrameLocator:
        """Create a nested frame locator for iframes within this frame.

        Args:
            selector: CSS selector for nested iframe.

        Returns:
            New FrameLocator for the nested iframe.
        """
        return FrameLocator(
            client=self._client,
            context_id=self._context_id,
            frame_selector=selector,
            page=self._page,
        )

    @property
    def first(self) -> FrameLocator:
        """Return a frame locator targeting the first matching iframe."""
        return FrameLocator(
            self._client, self._context_id,
            f"{self._frame_selector}:first-of-type", self._page,
        )

    @property
    def last(self) -> FrameLocator:
        """Return a frame locator targeting the last matching iframe."""
        return FrameLocator(
            self._client, self._context_id,
            f"{self._frame_selector}:last-of-type", self._page,
        )

    def nth(self, index: int) -> FrameLocator:
        """Return a frame locator targeting the nth matching iframe.

        Args:
            index: Zero-based index.

        Returns:
            FrameLocator for the specified iframe.
        """
        return FrameLocator(
            self._client, self._context_id,
            f"{self._frame_selector}:nth-of-type({index + 1})", self._page,
        )

    def __repr__(self) -> str:
        return f"<FrameLocator frame={self._frame_selector!r}>"


class _FrameScopedLocator:
    """Locator that operates within an iframe context.

    Automatically switches to the parent frame before each action and
    returns to the main frame afterward. Not exposed publicly -- users
    interact with it through FrameLocator.locator().
    """

    __slots__ = ("_client", "_context_id", "_frame_selector", "_selector", "_page")

    def __init__(
        self,
        client: OwlBrowser,
        context_id: str,
        frame_selector: str,
        selector: str,
        page: Any,
    ) -> None:
        self._client = client
        self._context_id = context_id
        self._frame_selector = frame_selector
        self._selector = selector
        self._page = page

    async def _enter_frame(self) -> None:
        """Switch to the target iframe."""
        await self._client.execute(
            "browser_switch_to_frame",
            context_id=self._context_id,
            frame_selector=self._frame_selector,
        )

    async def _leave_frame(self) -> None:
        """Return to the main frame."""
        await self._client.execute(
            "browser_switch_to_main_frame",
            context_id=self._context_id,
        )

    async def click(self, **kwargs: Any) -> None:
        """Click the element within the frame.

        Args:
            **kwargs: Click options.
        """
        await self._enter_frame()
        try:
            await self._client.execute(
                "browser_click",
                context_id=self._context_id,
                selector=self._selector,
            )
        finally:
            await self._leave_frame()

    async def fill(self, value: str, **kwargs: Any) -> None:
        """Clear and fill an input within the frame.

        Uses native frame switching with browser_clear_input and
        browser_type. No evaluate/contentDocument fallback.

        Args:
            value: Text to fill.
            **kwargs: Fill options.
        """
        await self._enter_frame()
        try:
            await self._client.execute(
                "browser_clear_input",
                context_id=self._context_id,
                selector=self._selector,
            )
            await self._client.execute(
                "browser_type",
                context_id=self._context_id,
                selector=self._selector,
                text=value,
            )
        finally:
            await self._leave_frame()

    async def type(self, text: str, **kwargs: Any) -> None:
        """Type text into an element within the frame.

        Args:
            text: Text to type.
            **kwargs: Type options.
        """
        await self._enter_frame()
        try:
            await self._client.execute(
                "browser_type",
                context_id=self._context_id,
                selector=self._selector,
                text=text,
            )
        finally:
            await self._leave_frame()

    async def press(self, key: str, **kwargs: Any) -> None:
        """Focus and press a key within the frame.

        Args:
            key: Key to press.
            **kwargs: Press options.
        """
        from .keyboard import _translate_key

        await self._enter_frame()
        try:
            await self._client.execute(
                "browser_focus",
                context_id=self._context_id,
                selector=self._selector,
            )
            await self._client.execute(
                "browser_press_key",
                context_id=self._context_id,
                key=_translate_key(key),
            )
        finally:
            await self._leave_frame()

    async def hover(self, **kwargs: Any) -> None:
        """Hover over the element within the frame.

        Args:
            **kwargs: Hover options.
        """
        await self._enter_frame()
        try:
            await self._client.execute(
                "browser_hover",
                context_id=self._context_id,
                selector=self._selector,
            )
        finally:
            await self._leave_frame()

    async def is_visible(self, **kwargs: Any) -> bool:
        """Check if the element is visible within the frame.

        Returns:
            True if visible.
        """
        await self._enter_frame()
        try:
            result: Any = await self._client.execute(
                "browser_is_visible",
                context_id=self._context_id,
                selector=self._selector,
            )
            if isinstance(result, dict):
                return bool(result.get("visible", False))
            return bool(result)
        finally:
            await self._leave_frame()

    async def text_content(self, **kwargs: Any) -> str | None:
        """Get text content of the element within the frame.

        Uses native frame switching with browser_extract_text.
        No evaluate/contentDocument fallback.

        Returns:
            Text content or None.
        """
        await self._enter_frame()
        try:
            result: Any = await self._client.execute(
                "browser_extract_text",
                context_id=self._context_id,
                selector=self._selector,
            )
            if isinstance(result, dict):
                return result.get("text", result.get("content"))
            return str(result) if result is not None else None
        finally:
            await self._leave_frame()

    async def wait_for(self, **kwargs: Any) -> None:
        """Wait for the element within the frame.

        Args:
            **kwargs: Wait options (timeout, state).
        """
        await self._enter_frame()
        try:
            params: dict[str, Any] = {
                "context_id": self._context_id,
                "selector": self._selector,
            }
            timeout = kwargs.get("timeout")
            if timeout is not None:
                params["timeout"] = int(timeout)
            await self._client.execute("browser_wait_for_selector", **params)
        finally:
            await self._leave_frame()

    def locator(self, selector: str) -> _FrameScopedLocator:
        """Chain a sub-locator within this frame-scoped locator.

        Args:
            selector: Sub-selector within this element.

        Returns:
            New FrameScopedLocator with combined selector.
        """
        combined = f"{self._selector} {selector}"
        return _FrameScopedLocator(
            self._client, self._context_id,
            self._frame_selector, combined, self._page,
        )

    def __repr__(self) -> str:
        return f"<FrameScopedLocator frame={self._frame_selector!r} selector={self._selector!r}>"


class Frame:
    """Represents a frame within a page.

    Wraps basic page operations, switching to the correct frame context
    before executing browser tools. For the main frame, frame_id is
    None and no switching occurs.
    """

    __slots__ = (
        "_client", "_context_id", "_frame_id",
        "_name", "_url", "_parent_frame",
    )

    def __init__(
        self,
        client: OwlBrowser,
        context_id: str,
        frame_id: str | None = None,
        name: str = "",
        url: str = "",
        parent_frame: Frame | None = None,
    ) -> None:
        """Initialize Frame.

        Args:
            client: The OwlBrowser client instance.
            context_id: Browser context identifier.
            frame_id: Frame identifier for switching. None for main frame.
            name: Frame name attribute.
            url: Current URL of the frame.
            parent_frame: Parent frame reference.
        """
        self._client = client
        self._context_id = context_id
        self._frame_id = frame_id
        self._name = name
        self._url = url
        self._parent_frame = parent_frame

    @property
    def name(self) -> str:
        """The frame's name attribute."""
        return self._name

    @property
    def url(self) -> str:
        """The frame's current URL."""
        return self._url

    @property
    def parent_frame(self) -> Frame | None:
        """The parent frame, or None for the main frame."""
        return self._parent_frame

    def is_detached(self) -> bool:
        """Whether the frame has been detached from the page."""
        return False

    async def _ensure_frame(self) -> None:
        """Switch to this frame if it is not the main frame."""
        if self._frame_id is not None:
            await self._client.execute(
                "browser_switch_to_frame",
                context_id=self._context_id,
                frame_selector=self._frame_id,
            )

    async def _return_to_main(self) -> None:
        """Switch back to the main frame after an operation."""
        if self._frame_id is not None:
            await self._client.execute(
                "browser_switch_to_main_frame",
                context_id=self._context_id,
            )

    async def evaluate(self, expression: str, arg: Any = None) -> Any:
        """Evaluate JavaScript in this frame's context.

        Args:
            expression: JavaScript expression to evaluate.
            arg: Optional argument (accepted for compat).

        Returns:
            The evaluation result.
        """
        await self._ensure_frame()
        try:
            result: Any = await self._client.execute(
                "browser_evaluate",
                context_id=self._context_id,
                expression=expression,
            )
            # Transport already unwraps the result. Return directly.
            if isinstance(result, dict) and "error" in result and len(result) == 1:
                return None
            return result
        finally:
            await self._return_to_main()

    async def content(self) -> str:
        """Get the full HTML content of this frame.

        Returns:
            HTML content string.
        """
        await self._ensure_frame()
        try:
            result: Any = await self._client.execute(
                "browser_get_html",
                context_id=self._context_id,
            )
            if isinstance(result, dict):
                return str(result.get("html", result.get("content", "")))
            return str(result)
        finally:
            await self._return_to_main()

    async def click(self, selector: str, **kwargs: Any) -> None:
        """Click an element within this frame.

        Args:
            selector: CSS selector or natural language description.
            **kwargs: Click options for API compatibility.
        """
        await self._ensure_frame()
        try:
            await self._client.execute(
                "browser_click",
                context_id=self._context_id,
                selector=selector,
            )
        finally:
            await self._return_to_main()

    async def fill(self, selector: str, value: str, **kwargs: Any) -> None:
        """Clear and fill a text input in this frame.

        Args:
            selector: CSS selector for the input element.
            value: Text value to fill.
            **kwargs: Fill options for API compatibility.
        """
        await self._ensure_frame()
        try:
            await self._client.execute(
                "browser_clear_input",
                context_id=self._context_id,
                selector=selector,
            )
            await self._client.execute(
                "browser_type",
                context_id=self._context_id,
                selector=selector,
                text=value,
            )
        finally:
            await self._return_to_main()

    async def wait_for_selector(self, selector: str, **kwargs: Any) -> None:
        """Wait for an element in this frame.

        Args:
            selector: CSS selector to wait for.
            **kwargs: Wait options for API compatibility.
        """
        await self._ensure_frame()
        try:
            params: dict[str, Any] = {
                "context_id": self._context_id,
                "selector": selector,
            }
            timeout = kwargs.get("timeout")
            if timeout is not None:
                params["timeout"] = int(timeout)
            await self._client.execute("browser_wait_for_selector", **params)
        finally:
            await self._return_to_main()

    def __repr__(self) -> str:
        frame_desc = self._frame_id or "main"
        return f"<Frame id={frame_desc!r} name={self._name!r} url={self._url!r}>"
