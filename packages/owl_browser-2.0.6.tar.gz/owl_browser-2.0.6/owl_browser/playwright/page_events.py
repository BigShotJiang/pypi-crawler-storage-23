"""
Playwright-compatible event objects for Owl Browser.

Contains Dialog, ConsoleMessage, Download, Video, and Route classes
that are used by Page event handlers and returned by page methods.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..client import OwlBrowser


class Dialog:
    """Represents a JavaScript dialog (alert, confirm, prompt, beforeunload).

    Dialog objects are passed to 'dialog' event handlers registered via
    page.on('dialog', handler). Use accept() or dismiss() to close.
    """

    __slots__ = (
        "_client", "_context_id", "_dialog_id",
        "_type", "_message", "_default_value", "_handled",
    )

    def __init__(
        self,
        client: OwlBrowser,
        context_id: str,
        data: dict[str, Any],
    ) -> None:
        """Initialize Dialog from browser dialog data.

        Args:
            client: OwlBrowser client.
            context_id: Browser context ID.
            data: Dialog data from browser_get_pending_dialog or browser_wait_for_dialog.
        """
        self._client = client
        self._context_id = context_id
        self._dialog_id: str = str(data.get("dialog_id", data.get("id", "")))
        self._type: str = str(data.get("type", data.get("dialog_type", "alert")))
        self._message: str = str(data.get("message", data.get("text", "")))
        self._default_value: str = str(data.get("default_value", data.get("defaultValue", "")))
        self._handled = False

    @property
    def type(self) -> str:
        """Dialog type: 'alert', 'confirm', 'prompt', or 'beforeunload'."""
        return self._type

    @property
    def message(self) -> str:
        """The dialog message text."""
        return self._message

    @property
    def default_value(self) -> str:
        """Default value for prompt dialogs."""
        return self._default_value

    async def accept(self, prompt_text: str | None = None) -> None:
        """Accept (click OK/Yes on) the dialog.

        Args:
            prompt_text: Text to enter for prompt dialogs before accepting.
        """
        if self._handled:
            return
        self._handled = True
        params: dict[str, Any] = {
            "dialog_id": self._dialog_id,
            "accept": True,
        }
        if prompt_text is not None:
            params["response_text"] = prompt_text
        await self._client.execute("browser_handle_dialog", **params)

    async def dismiss(self) -> None:
        """Dismiss (click Cancel/No on) the dialog."""
        if self._handled:
            return
        self._handled = True
        await self._client.execute(
            "browser_handle_dialog",
            dialog_id=self._dialog_id,
            accept=False,
        )

    def __repr__(self) -> str:
        return f"<Dialog type={self._type!r} message={self._message!r}>"


class ConsoleMessage:
    """Represents a browser console message (log, warn, error, etc.).

    ConsoleMessage objects are passed to 'console' event handlers.
    """

    __slots__ = ("_type", "_text", "_args", "_location")

    def __init__(self, data: dict[str, Any]) -> None:
        """Initialize ConsoleMessage from console log entry.

        Args:
            data: Console log entry from browser_get_console_log.
        """
        self._type: str = str(data.get("level", data.get("type", "log")))
        self._text: str = str(data.get("message", data.get("text", "")))
        self._args: list[str] = data.get("args", [])
        self._location: dict[str, Any] = data.get("location", {})

    @property
    def type(self) -> str:
        """Console message type: 'log', 'warn', 'error', 'info', 'debug'."""
        return self._type

    @property
    def text(self) -> str:
        """The message text."""
        return self._text

    @property
    def args(self) -> list[str]:
        """Message arguments."""
        return self._args

    @property
    def location(self) -> dict[str, Any]:
        """Source location of the console call."""
        return self._location

    def __repr__(self) -> str:
        return f"<ConsoleMessage type={self._type!r} text={self._text!r}>"


class Download:
    """Represents a file download triggered by the browser.

    Download objects are returned by page.expect_download() and
    passed to 'download' event handlers.
    """

    __slots__ = (
        "_client", "_context_id", "_download_id",
        "_url", "_suggested_filename", "_path", "_state",
    )

    def __init__(
        self,
        client: OwlBrowser,
        context_id: str,
        data: dict[str, Any],
    ) -> None:
        """Initialize Download from download data.

        Args:
            client: OwlBrowser client.
            context_id: Browser context ID.
            data: Download info from browser_get_downloads.
        """
        self._client = client
        self._context_id = context_id
        self._download_id: str = str(data.get("download_id", data.get("id", "")))
        self._url: str = str(data.get("url", ""))
        self._suggested_filename: str = str(data.get("filename", data.get("suggestedFilename", "")))
        self._path: str | None = data.get("path") or data.get("file_path")
        self._state: str = str(data.get("state", data.get("status", "pending")))

    @property
    def url(self) -> str:
        """URL that triggered the download."""
        return self._url

    @property
    def suggested_filename(self) -> str:
        """Suggested filename for the download."""
        return self._suggested_filename

    async def path(self) -> str | None:
        """Get the path to the downloaded file.

        Returns:
            File path or None if not yet complete.
        """
        if self._path:
            return self._path
        result: Any = await self._client.execute(
            "browser_get_downloads",
            context_id=self._context_id,
        )
        if isinstance(result, dict):
            downloads = result.get("downloads", [])
        elif isinstance(result, list):
            downloads = result
        else:
            downloads = []
        for dl in downloads:
            if str(dl.get("download_id", dl.get("id", ""))) == self._download_id:
                self._path = dl.get("path") or dl.get("file_path")
                return self._path
        return None

    async def save_as(self, path: str) -> None:
        """Save the downloaded file to a specific path.

        This copies the downloaded file to the target path.

        Args:
            path: Target file path.
        """
        import shutil
        src = await self.path()
        if src:
            shutil.copy2(src, path)

    async def cancel(self) -> None:
        """Cancel the download if still in progress."""
        await self._client.execute(
            "browser_cancel_download",
            download_id=self._download_id,
        )

    async def failure(self) -> str | None:
        """Return the failure reason, or None if successful.

        Returns:
            Error message or None.
        """
        if self._state in ("failed", "cancelled"):
            return self._state
        return None

    def __repr__(self) -> str:
        return f"<Download url={self._url!r} filename={self._suggested_filename!r}>"


class Video:
    """Represents a video recording of a browser context.

    Video objects are accessed via page.video and provide methods
    to get the recording path and save the video.
    """

    __slots__ = ("_client", "_context_id", "_path")

    def __init__(self, client: OwlBrowser, context_id: str) -> None:
        """Initialize Video.

        Args:
            client: OwlBrowser client.
            context_id: Browser context ID.
        """
        self._client = client
        self._context_id = context_id
        self._path: str | None = None

    async def path(self) -> str | None:
        """Get the path to the recorded video file.

        Returns:
            File path or None if recording has not been started/stopped.
        """
        if self._path:
            return self._path
        result: Any = await self._client.execute(
            "browser_get_video_recording_stats",
            context_id=self._context_id,
        )
        if isinstance(result, dict):
            self._path = result.get("path") or result.get("file_path")
        return self._path

    async def save_as(self, path: str) -> None:
        """Save the recorded video to a specific path.

        Args:
            path: Target file path.
        """
        import shutil
        src = await self.path()
        if src:
            shutil.copy2(src, path)

    async def delete(self) -> None:
        """Delete the recorded video file."""
        import os
        src = await self.path()
        if src and os.path.exists(src):
            os.remove(src)

    def __repr__(self) -> str:
        return f"<Video context_id={self._context_id!r} path={self._path!r}>"


class Route:
    """Represents an intercepted network route.

    Route objects are passed to route handlers registered via
    page.route() or context.route(). They provide methods to
    abort, continue, or fulfill the intercepted request.
    """

    __slots__ = ("_client", "_context_id", "_url_pattern", "_rule_id", "_request_data")

    def __init__(
        self,
        client: OwlBrowser,
        context_id: str,
        url_pattern: str,
        rule_id: str = "",
        request_data: dict[str, Any] | None = None,
    ) -> None:
        """Initialize Route.

        Args:
            client: OwlBrowser client.
            context_id: Browser context ID.
            url_pattern: URL pattern this route matches.
            rule_id: Owl Browser network rule ID.
            request_data: Request data for this route.
        """
        self._client = client
        self._context_id = context_id
        self._url_pattern = url_pattern
        self._rule_id = rule_id
        self._request_data = request_data or {}

    async def abort(self, error_code: str = "failed") -> None:
        """Abort the request with an error.

        Args:
            error_code: Error code string (default: 'failed').
        """
        await self._client.execute(
            "browser_add_network_rule",
            context_id=self._context_id,
            url_pattern=self._url_pattern,
            action="block",
        )

    async def fulfill(
        self,
        *,
        status: int = 200,
        headers: dict[str, str] | None = None,
        content_type: str = "text/plain",
        body: str | bytes = "",
        **kwargs: Any,
    ) -> None:
        """Fulfill the request with a mock response.

        Args:
            status: HTTP status code.
            headers: Response headers.
            content_type: Content-Type header value.
            body: Response body.
            **kwargs: Additional options.
        """
        body_str = body.decode("utf-8") if isinstance(body, bytes) else body
        await self._client.execute(
            "browser_add_network_rule",
            context_id=self._context_id,
            url_pattern=self._url_pattern,
            action="mock",
            mock_body=body_str,
            mock_status=str(status),
            mock_content_type=content_type,
        )

    async def continue_(
        self,
        *,
        url: str | None = None,
        method: str | None = None,
        headers: dict[str, str] | None = None,
        post_data: str | bytes | None = None,
    ) -> None:
        """Continue the request, optionally modifying it.

        For Owl Browser, if a redirect URL is given, uses redirect action.
        Otherwise, the request passes through normally.

        Args:
            url: Override URL.
            method: Override HTTP method.
            headers: Override headers.
            post_data: Override POST body.
        """
        if url:
            await self._client.execute(
                "browser_add_network_rule",
                context_id=self._context_id,
                url_pattern=self._url_pattern,
                action="redirect",
                redirect_url=url,
            )
        # No modification needed -- request passes through

    def __repr__(self) -> str:
        return f"<Route pattern={self._url_pattern!r}>"
