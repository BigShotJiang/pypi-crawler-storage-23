"""
Main Extractor class — the primary entry point for the extraction module.

Constructs and coordinates all extraction strategies:
select, table, meta, detect, lists, scrape, clean, and more.

No AI dependencies — uses only deterministic browser tools and
client-side HTML parsing (BeautifulSoup).
"""

from __future__ import annotations

from typing import Any

from ..client import OwlBrowser
from .content_cleaner import remove_obstructions
from .html_processor import HTMLProcessor
from .list_extractor import extract as list_extract
from .meta_extractor import extract_json_ld, extract_meta
from .pagination import detect_pagination
from .pattern_detector import detect as detect_patterns
from .pattern_detector import detect_and_extract
from .scrape_session import ScrapeSession
from .selector_engine import count as selector_count
from .selector_engine import extract_all, extract_first
from .table_extractor import (
    detect_tables,
    extract_definition_list,
    extract_grid,
    extract_table,
)
from .types import (
    CleanOptions,
    CleanResult,
    DetectedPattern,
    DetectOptions,
    ExtractionResult,
    FieldSpec,
    ListOptions,
    MetaData,
    ScrapeOptions,
    TableOptions,
)


class Extractor:
    """Universal data extraction from any website.

    Example::

        from owl_browser import OwlBrowser, RemoteConfig
        from owl_browser.extraction import Extractor

        async with OwlBrowser(RemoteConfig(url="...", token="...")) as browser:
            ctx = await browser.create_context()
            ex = Extractor(browser, ctx["context_id"])

            await ex.goto("https://example.com/products")

            # Manual extraction with CSS selectors
            products = await ex.select(".product-card", {
                "name": "h3",
                "price": ".price",
                "image": "img@src",
                "link": "a@href",
            })

            # Auto-detect repeating patterns
            patterns = await ex.detect()

            # Multi-page scraping
            result = await ex.scrape(".product-card", {
                "fields": {"name": "h3", "price": ".price"},
                "max_pages": 5,
            })
    """

    __slots__ = ("_proc", "_scrape_session")

    def __init__(self, client: OwlBrowser, context_id: str) -> None:
        self._proc = HTMLProcessor(client, context_id)
        self._scrape_session: ScrapeSession | None = None

    # ==================== Navigation ====================

    async def goto(self, url: str, wait_for_idle: bool = True) -> None:
        """Navigate to a URL and wait for network idle."""
        await self._proc.goto(url, wait_for_idle)

    # ==================== Manual Extraction ====================

    async def select(
        self,
        container_selector: str,
        fields: dict[str, FieldSpec],
    ) -> list[dict[str, Any]]:
        """Extract structured data from all elements matching a selector."""
        html = await self._proc.get_html("basic")
        return extract_all(html, container_selector, fields)

    async def select_first(
        self,
        container_selector: str,
        fields: dict[str, FieldSpec],
    ) -> dict[str, Any] | None:
        """Extract structured data from the first matching element."""
        html = await self._proc.get_html("basic")
        return extract_first(html, container_selector, fields)

    async def count(self, selector: str) -> int:
        """Count elements matching a selector."""
        html = await self._proc.get_html("basic")
        return selector_count(html, selector)

    # ==================== Tables ====================

    async def table(
        self,
        selector: str | None = None,
        options: TableOptions | None = None,
    ) -> list[dict[str, Any]]:
        """Extract a <table> as structured records."""
        html = await self._proc.get_html("basic")
        return extract_table(html, selector or "table", options)

    async def grid(
        self,
        container_selector: str,
        item_selector: str | None = None,
    ) -> list[dict[str, Any]]:
        """Extract a CSS grid/flexbox table."""
        html = await self._proc.get_html("basic")
        return extract_grid(html, container_selector, item_selector)

    async def definition_list(self, selector: str | None = None) -> dict[str, Any]:
        """Extract a <dl>/<dt>/<dd> definition list as key-value pairs."""
        html = await self._proc.get_html("basic")
        return extract_definition_list(html, selector or "dl")

    async def detect_tables(self) -> list[dict[str, Any]]:
        """Auto-detect all table-like structures on the page."""
        html = await self._proc.get_html("basic")
        return detect_tables(html)

    # ==================== Metadata ====================

    async def meta(self) -> MetaData:
        """Extract all structured metadata."""
        html = await self._proc.get_html("minimal")
        return extract_meta(html)

    async def json_ld(self) -> list[object]:
        """Extract JSON-LD structured data."""
        html = await self._proc.get_html("minimal")
        return extract_json_ld(html)

    # ==================== Auto-Detection ====================

    async def detect(self, options: DetectOptions | None = None) -> list[DetectedPattern]:
        """Detect repeating patterns on the page."""
        html = await self._proc.get_html("aggressive")
        return detect_patterns(html, options)

    async def detect_and_extract(
        self, options: DetectOptions | None = None
    ) -> list[dict[str, Any]]:
        """Detect the best pattern and immediately extract all items."""
        html = await self._proc.get_html("aggressive")
        return detect_and_extract(html, options)

    # ==================== Lists ====================

    async def lists(
        self,
        container_selector: str,
        options: ListOptions | None = None,
    ) -> list[dict[str, Any]]:
        """Extract items from a list/card container with auto-field detection."""
        html = await self._proc.get_html("basic")
        return list_extract(html, container_selector, options)

    # ==================== Multi-Page ====================

    async def scrape(
        self,
        container_selector: str,
        options: ScrapeOptions | None = None,
    ) -> ExtractionResult:
        """Run a multi-page scrape."""
        self._scrape_session = ScrapeSession(self._proc)
        try:
            return await self._scrape_session.scrape(container_selector, options)
        finally:
            self._scrape_session = None

    def abort_scrape(self) -> None:
        """Abort a running scrape session."""
        if self._scrape_session:
            self._scrape_session.abort()

    # ==================== Content Cleaning ====================

    async def clean(self, options: CleanOptions | None = None) -> CleanResult:
        """Remove obstructions (cookie banners, modals, fixed elements, ads)."""
        return await remove_obstructions(self._proc, options)

    # ==================== Raw Content ====================

    async def html(self, clean_level: str | None = None) -> str:
        """Get page HTML."""
        return await self._proc.get_html(clean_level)

    async def markdown(self) -> str:
        """Get page content as markdown."""
        return await self._proc.get_markdown()

    async def text(self, selector: str | None = None, regex: str | None = None) -> str:
        """Get text content, optionally filtered by selector and regex."""
        return await self._proc.get_text(selector, regex)

    # ==================== Site Templates ====================

    async def detect_site(self) -> str:
        """Detect the site type (e.g., 'google', 'amazon', 'wikipedia')."""
        return await self._proc.detect_site()

    async def site_data(self, template: str | None = None) -> Any:
        """Extract structured data using built-in site templates."""
        return await self._proc.extract_json(template)
