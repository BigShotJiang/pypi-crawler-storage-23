"""
Shared type definitions for the extraction module.
"""

from __future__ import annotations

from typing import Any, Callable, Literal, TypedDict, Union


# ==================== Transform Types ====================

Transform = Literal[
    "trim", "lowercase", "uppercase", "number", "clean", "slug",
    "date", "price", "url", "email", "stripHtml",
]

# ==================== Field Specs ====================


class NestedSpec(TypedDict, total=False):
    """Nested extraction configuration."""
    selector: str
    fields: dict[str, FieldSpec]
    limit: int


class ObjectFieldSpec(TypedDict, total=False):
    """Object-based field spec for advanced extraction."""
    selector: str
    attribute: str
    all: bool
    type: Literal["text", "number", "html", "innerHtml"]
    pattern: str
    group: int
    transform: Union[str, list[str]]
    default: Union[str, int, float, None]
    nested: NestedSpec


FieldSpec = Union[str, ObjectFieldSpec]

# Extracted record — values can be string, number, None, list, or nested dicts
ExtractedRecord = dict[str, Any]


# ==================== Extraction Results ====================


class ExtractionResult(TypedDict):
    """Result of an extraction operation."""
    items: list[dict[str, Any]]
    total_items: int
    pages_scraped: int
    page_urls: list[str]
    complete: bool
    duration_ms: float


# ==================== Metadata ====================


class FeedLink(TypedDict):
    """RSS/Atom feed link."""
    type: Literal["rss", "atom", "unknown"]
    href: str
    title: str | None


class MetaData(TypedDict):
    """Meta tag extraction result."""
    title: str | None
    description: str | None
    canonical: str | None
    og: dict[str, str]
    twitter: dict[str, str]
    json_ld: list[object]
    microdata: list[dict[str, Any]]
    feeds: list[FeedLink]
    favicon: str | None
    other: dict[str, str]


# ==================== Pattern Detection ====================


class DetectedPattern(TypedDict):
    """Detected repeating DOM pattern."""
    container_selector: str
    item_selector: str
    item_count: int
    confidence: float
    fields: dict[str, FieldSpec]
    sample: list[dict[str, Any]]


class DetectOptions(TypedDict, total=False):
    """Options for pattern detection."""
    min_count: int
    min_confidence: float
    hint: str
    region: str


# ==================== Table ====================


class TableOptions(TypedDict, total=False):
    """Options for table extraction."""
    headers: list[str]
    skip_rows: int
    max_rows: int
    transpose: bool
    column_types: dict[str, Literal["text", "number"]]


# ==================== Content Cleaning ====================


class CleanOptions(TypedDict, total=False):
    """Options for content cleaning."""
    cookie_banners: bool
    modals: bool
    fixed_elements: bool
    ads: bool
    lazy_load: bool
    lazy_load_scrolls: int
    lazy_load_wait: int


class CleanResult(TypedDict):
    """Result of content cleaning."""
    removed_count: int
    removed_types: list[str]


# ==================== Scraping ====================


class PaginationConfig(TypedDict, total=False):
    """Pagination configuration."""
    type: Literal["click-next", "url-pattern", "infinite-scroll", "load-more", "url-list"]
    next_selector: str
    url_pattern: str
    start_page: int
    urls: list[str]
    scroll_selector: str
    wait_after: int


class FollowConfig(TypedDict, total=False):
    """Configuration for following detail page links."""
    selector: str
    attribute: str
    fields: dict[str, FieldSpec]
    container_selector: str
    wait_after: int


class ScrapeOptions(TypedDict, total=False):
    """Options for multi-page scraping."""
    fields: dict[str, FieldSpec]
    pagination: PaginationConfig
    max_pages: int
    max_items: int
    clean: bool
    page_delay: int
    deduplicate_by: str
    follow: FollowConfig
    on_page: Callable[[int, list[dict[str, Any]]], None]
    on_item: Callable[[dict[str, Any]], None]


class PageInfo(TypedDict):
    """Page info returned by browser."""
    url: str
    title: str


class ListOptions(TypedDict, total=False):
    """Options for list extraction."""
    item_selector: str
    fields: dict[str, FieldSpec]
    limit: int
