"""
Pagination detection and navigation.

Detects pagination type from DOM heuristics: next links, page numbers,
scroll markers, load-more buttons, rel="next".
"""

from __future__ import annotations

import json
import re
from urllib.parse import urlparse, parse_qs

from .html_processor import HTMLProcessor
from .types import PaginationConfig

NEXT_LINK_PATTERNS = [
    'a[rel="next"]',
    'link[rel="next"]',
    '[class*="next"] a',
    '[class*="pagination"] a[class*="next"]',
    'a[aria-label*="next" i]',
    'a[aria-label*="Next"]',
    'button[aria-label*="next" i]',
    'button[aria-label*="Next"]',
    'nav[class*="pagination"] a:last-child',
    ".pagination .next a",
    ".pagination a.next",
    ".pager .next a",
    "a.next-page",
    'a[class*="next-page"]',
    "button.next-page",
    'button[class*="next-page"]',
]

LOAD_MORE_PATTERNS = [
    'button[class*="load-more"]',
    'button[class*="loadmore"]',
    'a[class*="load-more"]',
    '[class*="load-more"] button',
    '[data-action="load-more"]',
    'button[class*="show-more"]',
    'a[class*="show-more"]',
]


async def detect_pagination(proc: HTMLProcessor) -> PaginationConfig | None:
    """Auto-detect pagination type from the current page DOM.

    Uses a single browser evaluate() call to check all DOM-based patterns
    (rel="next", known selectors, text-based detection, load-more) at once,
    reducing round-trips from ~20 to 1.
    """
    url = await proc.get_url()

    next_selectors_json = json.dumps(NEXT_LINK_PATTERNS)
    load_more_json = json.dumps(LOAD_MORE_PATTERNS)

    # Single JS call that checks all patterns at once
    result = await proc.evaluate(f"""
    (function() {{
      var result = {{ type: null, selector: null, href: null }};

      // 1. rel="next" link
      var relNext = document.querySelector('a[rel="next"], link[rel="next"]');
      if (relNext) {{
        result.type = 'rel-next';
        result.href = relNext.href || null;
        result.selector = 'a[rel="next"]';
        return result;
      }}

      // 2. Check known next-button selectors
      var nextSelectors = {next_selectors_json};
      for (var i = 0; i < nextSelectors.length; i++) {{
        try {{
          var el = document.querySelector(nextSelectors[i]);
          if (el && el.offsetParent !== null) {{
            result.type = 'click-next';
            result.selector = nextSelectors[i];
            return result;
          }}
        }} catch(e) {{}}
      }}

      // 3. Text-based "next" detection in pagination containers (with i18n)
      var nextTexts = ['next', 'siguiente', 'suivant', 'weiter', 'volgende', 'avanti', '\\u0434\\u0430\\u043b\\u0435\\u0435', '\\u6b21\\u3078', '\\u4e0b\\u4e00\\u9875', '\\u45e4\\u44eb'];
      var arrowTexts = ['>', '>>', '\\u203a', '\\u2192', '\\u276f'];
      var containers = document.querySelectorAll(
        'nav, [class*="pagination"], [class*="pager"], [role="navigation"]'
      );
      for (var i = 0; i < containers.length; i++) {{
        var clickables = containers[i].querySelectorAll('a, button');
        for (var j = 0; j < clickables.length; j++) {{
          var el = clickables[j];
          if (el.disabled) continue;
          var text = (el.textContent || '').trim().toLowerCase();
          var ariaLabel = (el.getAttribute('aria-label') || '').toLowerCase();

          var isNext = false;
          for (var k = 0; k < nextTexts.length; k++) {{
            if (text.indexOf(nextTexts[k]) === 0 || ariaLabel.indexOf(nextTexts[k]) === 0) {{
              isNext = true;
              break;
            }}
          }}
          if (!isNext) {{
            for (var k = 0; k < arrowTexts.length; k++) {{
              if (text === arrowTexts[k]) {{ isNext = true; break; }}
            }}
          }}

          if (isNext) {{
            // Build a precise selector
            var tag = el.tagName.toLowerCase();
            var sel = tag;
            if (el.id) {{
              sel = tag + '#' + el.id;
            }} else if (el.getAttribute('aria-label')) {{
              sel = tag + '[aria-label="' + el.getAttribute('aria-label').replace(/"/g, '\\\\"') + '"]';
            }} else {{
              // Use classes + nth-child for precision
              var cls = Array.from(el.classList).slice(0, 3).join('.');
              if (cls) {{
                sel = tag + '.' + cls;
                // Check uniqueness
                var matches = document.querySelectorAll(sel);
                if (matches.length > 1) {{
                  var parent = el.parentElement;
                  if (parent) {{
                    var siblings = parent.querySelectorAll(':scope > ' + sel);
                    for (var s = 0; s < siblings.length; s++) {{
                      if (siblings[s] === el) {{
                        sel = tag + '.' + cls + ':nth-child(' + (s + 1) + ')';
                        break;
                      }}
                    }}
                  }}
                }}
              }} else {{
                // No classes — use parent context + nth-child
                var parent = el.parentElement;
                if (parent) {{
                  var siblings = parent.querySelectorAll(':scope > ' + tag);
                  for (var s = 0; s < siblings.length; s++) {{
                    if (siblings[s] === el) {{
                      var parentSel = '';
                      if (parent.id) parentSel = '#' + parent.id;
                      else if (parent.classList.length > 0) parentSel = parent.tagName.toLowerCase() + '.' + Array.from(parent.classList).slice(0, 2).join('.');
                      else parentSel = parent.tagName.toLowerCase();
                      sel = parentSel + ' > ' + tag + ':nth-child(' + (s + 1) + ')';
                      break;
                    }}
                  }}
                }}
              }}
            }}
            result.type = 'click-next';
            result.selector = sel;
            return result;
          }}
        }}
      }}

      // 4. Load-more buttons
      var loadMoreSelectors = {load_more_json};
      for (var i = 0; i < loadMoreSelectors.length; i++) {{
        try {{
          var el = document.querySelector(loadMoreSelectors[i]);
          if (el && el.offsetParent !== null) {{
            result.type = 'load-more';
            result.selector = loadMoreSelectors[i];
            return result;
          }}
        }} catch(e) {{}}
      }}

      return null;
    }})()
    """)

    if result and isinstance(result, dict):
        rtype = result.get("type")
        selector = result.get("selector")
        href = result.get("href")

        if rtype == "rel-next" and href:
            pattern = _detect_url_pattern(url, str(href))
            if pattern:
                return {
                    "type": "url-pattern",
                    "url_pattern": pattern["pattern"],
                    "start_page": pattern["current_page"],
                }
            return {"type": "click-next", "next_selector": selector}

        if rtype == "click-next":
            return {"type": "click-next", "next_selector": selector}

        if rtype == "load-more":
            return {"type": "load-more", "next_selector": selector}

    # 5. Check for URL-based pagination
    url_match = re.search(r"[?&](page|p)=(\d+)", url)
    if url_match:
        param = url_match.group(1)
        current_page = int(url_match.group(2))
        pattern = re.sub(
            rf"([?&]){param}=\d+",
            rf"\g<1>{param}={{page}}",
            url,
        )
        return {
            "type": "url-pattern",
            "url_pattern": pattern,
            "start_page": current_page,
        }

    # 6. Check for /page/N pattern
    path_match = re.search(r"/page/(\d+)", url)
    if path_match:
        return {
            "type": "url-pattern",
            "url_pattern": re.sub(r"/page/\d+", "/page/{page}", url),
            "start_page": int(path_match.group(1)),
        }

    # 7. Check for offset-based pagination
    offset_match = re.search(r"[?&](offset|start|skip)=(\d+)", url)
    if offset_match:
        param = offset_match.group(1)
        current_offset = int(offset_match.group(2))
        # Try to detect limit param
        limit_match = re.search(r"[?&](limit|count|size)=(\d+)", url)
        limit = int(limit_match.group(2)) if limit_match else 20
        pattern = re.sub(
            rf"([?&]){param}=\d+",
            rf"\g<1>{param}={{page}}",
            url,
        )
        return {
            "type": "url-pattern",
            "url_pattern": pattern,
            "start_page": current_offset,
        }

    return None


async def has_next_page(
    proc: HTMLProcessor,
    config: PaginationConfig,
    current_page: int,
) -> bool:
    """Check if there's a next page available."""
    ptype = config.get("type", "")

    if ptype == "url-list":
        urls = config.get("urls", [])
        return current_page < len(urls)

    if ptype == "url-pattern":
        return True

    if ptype in ("click-next", "load-more"):
        selector = config.get("next_selector")
        if not selector:
            return False
        exists = await proc.evaluate(f"""
            (function() {{
                var el = document.querySelector({json.dumps(selector)});
                return el && el.offsetParent !== null && !el.disabled;
            }})()
        """)
        return bool(exists)

    if ptype == "infinite-scroll":
        return True

    return False


async def go_to_next_page(
    proc: HTMLProcessor,
    config: PaginationConfig,
    current_page: int,
) -> bool:
    """Navigate to the next page."""
    ptype = config.get("type", "")
    wait_after = config.get("wait_after", 1000)

    try:
        if ptype in ("click-next", "load-more"):
            selector = config.get("next_selector")
            if not selector:
                return False
            await proc.click(selector)
            await proc.wait(wait_after)
            return True

        if ptype == "url-pattern":
            next_page = current_page + 1
            url = resolve_page_url(config.get("url_pattern", ""), next_page)
            await proc.goto(url)
            await proc.wait(wait_after)
            return True

        if ptype == "url-list":
            urls = config.get("urls", [])
            if current_page >= len(urls):
                return False
            await proc.goto(urls[current_page])
            await proc.wait(wait_after)
            return True

        if ptype == "infinite-scroll":
            await proc.scroll_to_bottom()
            await proc.wait(config.get("wait_after", 1500))
            return True

    except Exception:
        return False

    return False


def resolve_page_url(pattern: str, page: int) -> str:
    """Resolve a URL pattern with a page number."""
    return pattern.replace("{page}", str(page))


# ==================== Internal ====================


def _detect_url_pattern(
    current_url: str, next_url: str
) -> dict[str, object] | None:
    """Detect URL pagination pattern from current and next URLs."""
    try:
        current = urlparse(current_url)
        nxt = urlparse(next_url)

        current_params = parse_qs(current.query)
        next_params = parse_qs(nxt.query)

        for key, values in next_params.items():
            current_values = current_params.get(key, [])
            if values and current_values:
                try:
                    next_num = int(values[0])
                    current_num = int(current_values[0])
                    if next_num == current_num + 1:
                        pattern = re.sub(
                            rf"([?&]){key}={current_num}",
                            rf"\g<1>{key}={{page}}",
                            current_url,
                        )
                        return {"pattern": pattern, "current_page": current_num}
                except ValueError:
                    continue

        # Check /page/N path pattern
        current_match = re.search(r"/page/(\d+)", current.path)
        next_match = re.search(r"/page/(\d+)", nxt.path)
        if current_match and next_match:
            current_page = int(current_match.group(1))
            return {
                "pattern": re.sub(r"/page/\d+", "/page/{page}", current_url),
                "current_page": current_page,
            }
    except Exception:
        pass

    return None
