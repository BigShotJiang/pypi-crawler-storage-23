"""
Specialized table extraction.

Handles <table> with colspan/rowspan, headerless tables, key-value transpose,
CSS grid/flexbox "tables", and <dl>/<dt>/<dd> definition lists.
"""

from __future__ import annotations

from typing import Any

from bs4 import BeautifulSoup, Tag

from .types import ExtractedRecord, TableOptions


def extract_table(
    html: str,
    selector: str = "table",
    options: TableOptions | None = None,
) -> list[dict[str, Any]]:
    """Extract a <table> as an array of records."""
    opts = options or {}
    soup = BeautifulSoup(html, "html.parser")
    table = soup.select_one(selector)
    if table is None:
        return []

    headers: list[str] = list(opts.get("headers", []))

    # Extract caption
    caption_el = table.find("caption", recursive=False)
    caption_text = caption_el.get_text(strip=True) if caption_el and isinstance(caption_el, Tag) else None

    # Auto-detect headers from <th> elements
    if not headers:
        thead_el = table.find("thead", recursive=False)
        if thead_el and isinstance(thead_el, Tag):
            header_rows = thead_el.find_all("tr", recursive=False)
            if len(header_rows) > 1:
                # Multi-row header: combine into composite headers
                header_grid: list[list[str]] = []
                for row in header_rows:
                    row_headers = [th.get_text(strip=True) for th in row.find_all("th", recursive=False)]
                    header_grid.append(row_headers)
                max_cols = max((len(r) for r in header_grid), default=0)
                for c in range(max_cols):
                    parts: list[str] = []
                    for row_h in header_grid:
                        val = row_h[c].strip() if c < len(row_h) else ""
                        if val and val not in parts:
                            parts.append(val)
                    headers.append(" / ".join(parts))
            else:
                # Single header row
                if header_rows:
                    for th in header_rows[0].find_all("th", recursive=False):
                        headers.append(th.get_text(strip=True))
        else:
            # No thead — check first row
            tbody_el = table.find("tbody", recursive=False)
            first_row = None
            if tbody_el and isinstance(tbody_el, Tag):
                first_row = tbody_el.find("tr", recursive=False)
            if first_row is None:
                first_row = table.find("tr", recursive=False)
            if first_row and isinstance(first_row, Tag):
                th_els = first_row.find_all("th", recursive=False)
                for th in th_els:
                    headers.append(th.get_text(strip=True))

    # Use direct children to avoid nested table rows
    tbody_el = table.find("tbody", recursive=False)
    if tbody_el and isinstance(tbody_el, Tag):
        rows = tbody_el.find_all("tr", recursive=False)
    else:
        rows = table.find_all("tr", recursive=False)
    start_idx = 0

    if not headers and rows:
        first_row = rows[0]
        tds = first_row.find_all("td", recursive=False)
        ths = first_row.find_all("th", recursive=False)
        if ths and not tds:
            # First row is a header row
            for cell in ths:
                headers.append(cell.get_text(strip=True))
            start_idx = 1
        else:
            # First row is data — generate column names
            col_count = len(tds) or len(first_row.find_all(["td", "th"], recursive=False))
            for c in range(col_count):
                headers.append(f"col_{c}")
            start_idx = 0

    # Collect data rows
    data_rows: list[Tag] = []
    for i, row in enumerate(rows):
        if i < start_idx:
            continue
        tds = row.find_all("td")
        ths = row.find_all("th")
        if not tds and ths:
            continue
        data_rows.append(row)

    # Apply skip_rows
    skip = opts.get("skip_rows", 0)
    data_rows = data_rows[skip:]

    # Apply max_rows
    max_rows = opts.get("max_rows")
    if max_rows:
        data_rows = data_rows[:max_rows]

    # Build grid for colspan/rowspan
    grid: list[list[str | None]] = [[] for _ in range(len(data_rows))]

    for r, row in enumerate(data_rows):
        cells = row.find_all(["td", "th"])
        cell_idx = 0
        for cell in cells:
            colspan = int(cell.get("colspan", 1) or 1)
            rowspan = int(cell.get("rowspan", 1) or 1)
            text = cell.get_text(strip=True)

            while cell_idx < len(grid[r]) and grid[r][cell_idx] is not None:
                cell_idx += 1

            for dr in range(rowspan):
                if r + dr >= len(grid):
                    grid.append([])
                row_grid = grid[r + dr]
                for dc in range(colspan):
                    col = cell_idx + dc
                    while len(row_grid) <= col:
                        row_grid.append(None)
                    row_grid[col] = text

            cell_idx += colspan

    # Transpose if requested
    if opts.get("transpose"):
        return _transpose_grid(grid)

    # Convert grid to records
    column_types = opts.get("column_types", {})
    results: list[dict[str, Any]] = []
    for row_data in grid:
        record: dict[str, Any] = {}
        for c in range(len(headers)):
            key = headers[c] or f"col_{c}"
            value: Any = row_data[c] if c < len(row_data) else None
            if column_types.get(key) == "number" and isinstance(value, str):
                import re
                cleaned = re.sub(r"[^0-9.\-]", "", value)
                try:
                    value = float(cleaned)
                except ValueError:
                    pass
            record[key] = value
        results.append(record)

    if caption_text and results:
        results[0]["_caption"] = caption_text

    return results


def extract_grid(
    html: str,
    container_selector: str,
    item_selector: str | None = None,
) -> list[dict[str, Any]]:
    """Extract a CSS grid/flexbox 'table' (div-based layout)."""
    soup = BeautifulSoup(html, "html.parser")
    container = soup.select_one(container_selector)
    if container is None:
        return []

    items = container.select(item_selector) if item_selector else list(container.children)
    results: list[dict[str, Any]] = []

    for el in items:
        if not isinstance(el, Tag):
            continue
        record: dict[str, Any] = {}
        for j, child in enumerate(el.children):
            if not isinstance(child, Tag):
                continue
            text = child.get_text(strip=True)
            key = (
                child.get("data-field")
                or child.get("aria-label")
                or _infer_field_key(child, j)
            )
            if isinstance(key, list):
                key = key[0] if key else f"field_{j}"
            record[key] = text or None
        if record:
            results.append(record)

    return results


def extract_definition_list(
    html: str,
    selector: str = "dl",
) -> dict[str, Any]:
    """Extract a <dl>/<dt>/<dd> definition list as key-value pairs."""
    soup = BeautifulSoup(html, "html.parser")
    dl = soup.select_one(selector)
    if dl is None:
        return {}

    record: dict[str, Any] = {}
    current_key: str | None = None

    for el in dl.children:
        if not isinstance(el, Tag):
            continue
        if el.name == "dt":
            current_key = el.get_text(strip=True)
        elif el.name == "dd" and current_key:
            record[current_key] = el.get_text(strip=True) or None
            current_key = None

    return record


def detect_tables(html: str) -> list[dict[str, Any]]:
    """Auto-detect all table-like structures on the page."""
    soup = BeautifulSoup(html, "html.parser")
    results: list[dict[str, Any]] = []

    for i, table in enumerate(soup.find_all("table")):
        if not isinstance(table, Tag):
            continue
        rows = len(table.find_all("tr"))
        first_row = table.find("tr")
        cols = len(first_row.find_all(["td", "th"])) if first_row else 0
        tid = table.get("id")
        cls = (table.get("class") or [None])[0]  # type: ignore[index]
        if tid:
            sel = f"table#{tid}"
        elif cls:
            sel = f"table.{cls}"
        elif i > 0:
            sel = f"table:nth-of-type({i + 1})"
        else:
            sel = "table"
        results.append({
            "selector": sel,
            "type": "table",
            "row_count": rows,
            "column_count": cols,
        })

    for i, dl in enumerate(soup.find_all("dl")):
        if not isinstance(dl, Tag):
            continue
        dt_count = len(dl.find_all("dt"))
        did = dl.get("id")
        cls = (dl.get("class") or [None])[0]  # type: ignore[index]
        if did:
            sel = f"dl#{did}"
        elif cls:
            sel = f"dl.{cls}"
        elif i > 0:
            sel = f"dl:nth-of-type({i + 1})"
        else:
            sel = "dl"
        results.append({
            "selector": sel,
            "type": "definition-list",
            "row_count": dt_count,
            "column_count": 2,
        })

    return results


# ==================== Internal ====================


def _transpose_grid(grid: list[list[str | None]]) -> list[dict[str, Any]]:
    """Transpose a grid: first column becomes keys."""
    if not grid:
        return []
    col_count = max((len(r) for r in grid), default=0)
    results: list[dict[str, Any]] = []
    for c in range(1, col_count):
        record: dict[str, Any] = {}
        for r in range(len(grid)):
            key = grid[r][0] if grid[r] else f"row_{r}"
            record[key or f"row_{r}"] = grid[r][c] if c < len(grid[r]) else None
        results.append(record)
    return results


def _infer_field_key(el: Tag, index: int) -> str:
    """Infer a field key from element classes."""
    classes = el.get("class")
    if classes and isinstance(classes, list) and classes[0]:
        return str(classes[0])
    return f"field_{index}"
