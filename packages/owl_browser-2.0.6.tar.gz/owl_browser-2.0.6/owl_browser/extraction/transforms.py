"""
Pure value transform pipeline for extraction.

No browser dependency. All functions are stateless and side-effect free.

Built-in transforms:
- trim, lowercase, uppercase, number, clean, slug
- date: parse various date formats to ISO-8601 (including relative dates)
- price: "$1,299.99" → 1299.99
- url: resolve relative URLs to absolute
- email: extract email address from text
- stripHtml: remove HTML tags and decode all HTML entities
- boolean: normalize truthy/falsy strings to "true"/"false"
- compact: remove ALL whitespace (including newlines, tabs)
"""

from __future__ import annotations

import re
import unicodedata
from datetime import datetime
from typing import Any
from urllib.parse import urljoin


def apply_transform(value: str, transform: str) -> str | None:
    """Apply a single named transform to a string value."""
    if transform == "trim":
        return value.strip()
    if transform == "lowercase":
        return value.lower()
    if transform == "uppercase":
        return value.upper()
    if transform == "number":
        cleaned = re.sub(r"[^0-9.\-,]", "", value).replace(",", "")
        try:
            return str(float(cleaned))
        except ValueError:
            return None
    if transform == "clean":
        return re.sub(r"\s+", " ", value).strip()
    if transform == "slug":
        result = value.lower()
        result = unicodedata.normalize("NFKD", result)
        result = re.sub(r"[^a-z0-9]+", "-", result)
        return result.strip("-")
    if transform == "date":
        return parse_date(value)
    if transform == "price":
        n = parse_price(value)
        return str(n) if n is not None else None
    if transform == "url":
        return value.strip()
    if transform == "email":
        return extract_email(value)
    if transform == "stripHtml":
        return strip_html(value)
    if transform == "boolean":
        lower = value.strip().lower()
        truthy = {"yes", "true", "1", "on", "enabled", "\u2713", "\u2714", "\u2611"}
        falsy = {"no", "false", "0", "off", "disabled", "\u2717", "\u2718", "\u2610"}
        if lower in truthy:
            return "true"
        if lower in falsy:
            return "false"
        return "true" if value else "false"
    if transform == "compact":
        return re.sub(r"\s+", "", value)
    return value


def apply_transforms(
    value: str | None,
    transforms: str | list[str] | None = None,
) -> str | None:
    """Apply a pipeline of transforms to a string value."""
    if transforms is None or value is None:
        return value
    pipeline = [transforms] if isinstance(transforms, str) else transforms
    result: str | None = value
    for t in pipeline:
        if result is None:
            break
        result = apply_transform(result, t)
    return result


def apply_pattern(
    value: str | None,
    pattern: str | None = None,
    group: int | None = None,
) -> str | None:
    """Apply a regex pattern to extract a substring."""
    if pattern is None or value is None:
        return value
    try:
        match = re.search(pattern, value)
        if not match:
            return None
        return match.group(group or 0)
    except (re.error, IndexError):
        return value


def coerce_type(value: str | None, field_type: str | None = None) -> Any:
    """Coerce a string to the specified type."""
    if value is None:
        return None
    if field_type == "number":
        cleaned = re.sub(r"[^0-9.\-,]", "", value).replace(",", "")
        try:
            return float(cleaned)
        except ValueError:
            return None
    return value


def parse_price(value: str) -> float | None:
    """Parse a price string to a number.

    Handles: "$1,299.99", "EUR 1.299,99", "1 299,99 kr", etc.
    """
    cleaned = re.sub(r"[^0-9.,\-\s]", "", value).strip()
    if not cleaned:
        return None

    comma_pos = cleaned.rfind(",")
    dot_pos = cleaned.rfind(".")

    if comma_pos > dot_pos and comma_pos > 0:
        # Comma is the decimal separator (European)
        cleaned = re.sub(r"[.\s]", "", cleaned).replace(",", ".")
    else:
        # Dot is the decimal separator (US/UK)
        cleaned = re.sub(r"[,\s]", "", cleaned)

    try:
        return float(cleaned)
    except ValueError:
        return None


def parse_date(value: str) -> str | None:
    """Parse a date string to ISO-8601 format."""
    trimmed = value.strip()
    if not trimmed:
        return None

    # Relative date patterns
    relative = _parse_relative_date(trimmed)
    if relative:
        return relative

    # Common formats to try
    formats = [
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S%z",
        "%b %d, %Y",
        "%B %d, %Y",
        "%d %b %Y",
        "%d %B %Y",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%m-%d-%Y",
        "%d-%m-%Y",
        "%Y/%m/%d",
        "%b %d %Y",
        "%d.%m.%Y",
    ]

    for fmt in formats:
        try:
            dt = datetime.strptime(trimmed, fmt)
            return dt.isoformat() + ("Z" if "Z" not in fmt and "%z" not in fmt else "")
        except ValueError:
            continue

    return None


def resolve_url(relative: str, base_url: str) -> str:
    """Resolve a relative URL against a base URL."""
    try:
        return urljoin(base_url, relative)
    except Exception:
        return relative


# ==================== Internal Helpers ====================


def _parse_relative_date(text: str) -> str | None:
    """Parse relative date expressions like '3 days ago', 'yesterday', 'just now'."""
    from datetime import timedelta

    lower = text.lower().strip()
    now = datetime.utcnow()

    if lower in ("just now", "now"):
        return now.isoformat() + "Z"
    if lower == "today":
        return now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat() + "Z"
    if lower == "yesterday":
        d = now - timedelta(days=1)
        return d.replace(hour=0, minute=0, second=0, microsecond=0).isoformat() + "Z"

    ago_match = re.match(r"^(\d+)\s+(second|minute|hour|day|week|month|year)s?\s+ago$", lower)
    if ago_match:
        amount = int(ago_match.group(1))
        unit = ago_match.group(2)
        if unit == "second":
            d = now - timedelta(seconds=amount)
        elif unit == "minute":
            d = now - timedelta(minutes=amount)
        elif unit == "hour":
            d = now - timedelta(hours=amount)
        elif unit == "day":
            d = now - timedelta(days=amount)
        elif unit == "week":
            d = now - timedelta(weeks=amount)
        elif unit == "month":
            d = now - timedelta(days=amount * 30)
        elif unit == "year":
            d = now - timedelta(days=amount * 365)
        else:
            return None
        return d.isoformat() + "Z"

    return None


def extract_email(value: str) -> str | None:
    """Extract an email address from text."""
    match = re.search(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", value)
    return match.group(0) if match else None


def strip_html(value: str) -> str:
    """Remove HTML tags and decode all entities from a string."""
    import html as html_module

    result = re.sub(r"<script[^>]*>[\s\S]*?</script>", "", value, flags=re.IGNORECASE)
    result = re.sub(r"<style[^>]*>[\s\S]*?</style>", "", result, flags=re.IGNORECASE)
    result = re.sub(r"<[^>]+>", "", result)
    # Use Python's html.unescape which handles ALL named + numeric entities
    result = html_module.unescape(result)
    return re.sub(r"\s+", " ", result).strip()
