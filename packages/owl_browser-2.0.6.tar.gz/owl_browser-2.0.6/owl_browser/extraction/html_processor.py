"""
Browser communication layer for extraction.

Wraps browser tools (get_html, get_markdown, evaluate, navigate, etc.)
into a clean async interface used by all extraction modules.
"""

from __future__ import annotations

from typing import Any

from ..client import OwlBrowser
from .types import PageInfo


def _unwrap_string(result: Any) -> str:
    """Unwrap a tool result that may be a plain string or dict with known keys."""
    if isinstance(result, str):
        return result
    if isinstance(result, dict):
        for key in ("html", "markdown", "text", "content"):
            if isinstance(result.get(key), str):
                return result[key]
    return str(result) if result else ""


class HTMLProcessor:
    """Async interface to browser content tools."""

    __slots__ = ("_client", "_context_id")

    def __init__(self, client: OwlBrowser, context_id: str) -> None:
        self._client = client
        self._context_id = context_id

    async def get_html(self, clean_level: str | None = None) -> str:
        """Get page HTML from browser.

        Args:
            clean_level: 'minimal', 'basic', or 'aggressive' (default: 'basic').
        """
        params: dict[str, Any] = {"context_id": self._context_id}
        if clean_level:
            params["clean_level"] = clean_level
        result = await self._client.execute("browser_get_html", **params)
        return _unwrap_string(result)

    async def get_markdown(self) -> str:
        """Get page content as markdown."""
        result = await self._client.execute(
            "browser_get_markdown", context_id=self._context_id
        )
        return _unwrap_string(result)

    async def get_text(
        self, selector: str | None = None, regex: str | None = None
    ) -> str:
        """Extract text from page, optionally filtered by selector and regex."""
        params: dict[str, Any] = {"context_id": self._context_id}
        if selector:
            params["selector"] = selector
        if regex:
            params["regex"] = regex
        result = await self._client.execute("browser_extract_text", **params)
        return _unwrap_string(result)

    async def get_page_info(self) -> PageInfo:
        """Get current page URL and title."""
        result = await self._client.execute(
            "browser_get_page_info", context_id=self._context_id
        )
        if isinstance(result, dict):
            return {
                "url": str(result.get("url") or ""),
                "title": str(result.get("title") or ""),
            }
        return {"url": "", "title": ""}

    async def get_url(self) -> str:
        """Get current page URL."""
        info = await self.get_page_info()
        return info["url"]

    async def evaluate(self, expression: str) -> Any:
        """Execute JavaScript in the page and return the result."""
        result = await self._client.execute(
            "browser_evaluate",
            context_id=self._context_id,
            expression=expression,
        )
        if isinstance(result, dict):
            return result.get("result", result)
        return result

    async def goto(self, url: str, wait_for_idle: bool = True) -> None:
        """Navigate to a URL and optionally wait for network idle."""
        await self._client.execute(
            "browser_navigate", context_id=self._context_id, url=url
        )
        if wait_for_idle:
            await self.wait_for_network_idle()

    async def wait_for_selector(
        self, selector: str, timeout: int | None = None
    ) -> None:
        """Wait for a CSS selector to appear in the DOM."""
        params: dict[str, Any] = {
            "context_id": self._context_id,
            "selector": selector,
        }
        if timeout is not None:
            params["timeout"] = timeout
        await self._client.execute("browser_wait_for_selector", **params)

    async def wait_for_network_idle(self, timeout: int | None = None) -> None:
        """Wait for network to become idle."""
        params: dict[str, Any] = {"context_id": self._context_id}
        if timeout is not None:
            params["timeout"] = timeout
        await self._client.execute("browser_wait_for_network_idle", **params)

    async def wait(self, ms: int) -> None:
        """Wait for a specified number of milliseconds."""
        await self._client.execute(
            "browser_wait", context_id=self._context_id, timeout=ms
        )

    async def click(self, selector: str) -> None:
        """Click an element by CSS selector."""
        await self._client.execute(
            "browser_click", context_id=self._context_id, selector=selector
        )

    async def scroll_by(self, x: int, y: int) -> None:
        """Scroll down by a number of pixels."""
        await self._client.execute(
            "browser_scroll_by", context_id=self._context_id, x=x, y=y
        )

    async def scroll_to_bottom(self) -> None:
        """Scroll to the bottom of the page."""
        await self._client.execute(
            "browser_scroll_to_bottom", context_id=self._context_id
        )

    async def detect_site(self) -> str:
        """Detect the site type (e.g., 'google', 'amazon', 'wikipedia')."""
        result = await self._client.execute(
            "browser_detect_site", context_id=self._context_id
        )
        if isinstance(result, str):
            return result
        if isinstance(result, dict):
            return str(result.get("site_type") or result.get("type") or "unknown")
        return "unknown"

    async def extract_json(self, template: str | None = None) -> Any:
        """Extract structured JSON using built-in site templates."""
        params: dict[str, Any] = {"context_id": self._context_id}
        if template:
            params["template"] = template
        return await self._client.execute("browser_extract_json", **params)
