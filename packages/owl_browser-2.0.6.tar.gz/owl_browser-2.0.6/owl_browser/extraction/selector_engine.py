"""
Core CSS selector extraction engine using BeautifulSoup.

All functions are pure — they parse HTML and return extracted data.
Reuses the transform pipeline from transforms.py.
"""

from __future__ import annotations

from typing import Any, Union

from bs4 import BeautifulSoup, Tag

from .transforms import apply_pattern, apply_transforms, coerce_type
from .types import ExtractedRecord, FieldSpec, ObjectFieldSpec


def extract_all(
    html: str,
    container_selector: str,
    fields: dict[str, FieldSpec],
) -> list[dict[str, Any]]:
    """Extract structured data from all elements matching container_selector."""
    soup = BeautifulSoup(html, "html.parser")
    containers = soup.select(container_selector)
    return [_extract_item(c, fields) for c in containers]


def extract_first(
    html: str,
    container_selector: str,
    fields: dict[str, FieldSpec],
) -> dict[str, Any] | None:
    """Extract structured data from the first element matching container_selector."""
    soup = BeautifulSoup(html, "html.parser")
    container = soup.select_one(container_selector)
    if container is None:
        return None
    return _extract_item(container, fields)


def count(html: str, selector: str) -> int:
    """Count elements matching a CSS selector."""
    soup = BeautifulSoup(html, "html.parser")
    return len(soup.select(selector))


# ==================== Internal ====================


def _extract_item(
    container: Tag,
    fields: dict[str, FieldSpec],
) -> dict[str, Any]:
    """Extract all fields from a single container element."""
    return {name: resolve_field(container, spec) for name, spec in fields.items()}


def resolve_field(container: Tag, spec: FieldSpec) -> Any:
    """Resolve a field spec (string or object) to a value."""
    if isinstance(spec, str):
        return _extract_string_field(container, spec)
    return _extract_object_field(container, spec)


def _extract_string_field(container: Tag, spec: str) -> str | None:
    """Extract a field value using a string spec."""
    at_pos = spec.rfind("@")
    if at_pos >= 0:
        sel = spec[:at_pos].strip()
        attr = spec[at_pos + 1 :]
        target = container if not sel else container.select_one(sel)
        if target is None:
            return None
        if attr == "outerHTML":
            return str(target)
        if attr == "innerHTML":
            return target.decode_contents()
        val = target.get(attr)
        if isinstance(val, list):
            return " ".join(val)
        return val  # type: ignore[return-value]
    el = container.select_one(spec) if spec.strip() else container
    return el.get_text(strip=True) if el else None


def _extract_object_field(container: Tag, spec: ObjectFieldSpec) -> Any:
    """Extract a field value using an object spec."""
    nested = spec.get("nested")
    if nested:
        return _extract_nested(container, nested)

    sel = spec.get("selector")
    attr = spec.get("attribute")
    field_type = spec.get("type")
    default = spec.get("default")

    if spec.get("all"):
        values: list[Any] = []
        targets = container.select(sel) if sel else [container]
        for el in targets:
            raw = _extract_raw_value(el, attr, field_type)
            raw = apply_pattern(raw, spec.get("pattern"), spec.get("group"))
            raw = apply_transforms(raw, spec.get("transform"))
            raw = coerce_type(raw, field_type)
            values.append(raw if raw is not None else default)
        return values

    target = container.select_one(sel) if sel else container
    if target is None:
        return default

    raw = _extract_raw_value(target, attr, field_type)
    raw = apply_pattern(raw, spec.get("pattern"), spec.get("group"))
    raw = apply_transforms(raw, spec.get("transform"))
    raw = coerce_type(raw, field_type)
    return raw if raw is not None else default


def _extract_raw_value(
    el: Tag,
    attr: str | None = None,
    field_type: str | None = None,
) -> str | None:
    """Extract the raw value from an element."""
    if field_type == "html":
        return str(el)
    if field_type == "innerHtml":
        return el.decode_contents()
    if attr:
        if attr == "outerHTML":
            return str(el)
        if attr == "innerHTML":
            return el.decode_contents()
        val = el.get(attr)
        if isinstance(val, list):
            return " ".join(val)
        return val  # type: ignore[return-value]
    return el.get_text(strip=True) or None


def _extract_nested(
    container: Tag,
    nested: dict[str, Any],
) -> list[dict[str, Any]]:
    """Extract nested sub-items within a container."""
    selector = nested.get("selector", "")
    fields = nested.get("fields", {})
    limit = nested.get("limit")

    elements = container.select(selector)
    if limit is not None:
        elements = elements[:limit]

    return [_extract_item(el, fields) for el in elements]
