"""
Universal extraction system for Owl Browser Python SDK.

Provides structured data extraction from any website using CSS selectors,
pattern detection, table parsing, metadata extraction, and multi-page scraping.
"""

from .extractor import Extractor
from .types import (
    CleanOptions,
    CleanResult,
    DetectedPattern,
    DetectOptions,
    ExtractionResult,
    FieldSpec,
    FollowConfig,
    ListOptions,
    MetaData,
    ObjectFieldSpec,
    PaginationConfig,
    ScrapeOptions,
    TableOptions,
    Transform,
)

__all__ = [
    "Extractor",
    "CleanOptions",
    "CleanResult",
    "DetectedPattern",
    "DetectOptions",
    "ExtractionResult",
    "FieldSpec",
    "FollowConfig",
    "ListOptions",
    "MetaData",
    "ObjectFieldSpec",
    "PaginationConfig",
    "ScrapeOptions",
    "TableOptions",
    "Transform",
]
