"""
Remove obstructions from live pages via browser_evaluate JS injection.

Handles cookie banners, modals, fixed elements, ads, and lazy loading.
"""

from __future__ import annotations

import json

from .html_processor import HTMLProcessor
from .types import CleanOptions, CleanResult

# Common cookie consent button selectors
COOKIE_SELECTORS = [
    '[class*="cookie"] button[class*="accept"]',
    '[class*="cookie"] button[class*="agree"]',
    '[class*="cookie"] button[class*="allow"]',
    '[class*="consent"] button[class*="accept"]',
    '[class*="consent"] button[class*="agree"]',
    '[id*="cookie"] button',
    '[id*="consent"] button',
    "#onetrust-accept-btn-handler",
    "#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll",
    ".cc-accept",
    ".cc-btn.cc-dismiss",
    "#accept-cookies",
    "#acceptAllCookies",
    ".cookie-accept",
    ".cookie-consent-accept",
    '[data-action="accept-cookies"]',
    '[data-testid="cookie-accept"]',
    ".gdpr-accept",
    "#gdpr-accept",
    '[class*="gdpr"] button[class*="accept"]',
    # i18n consent buttons
    'button[class*="accept"]',
    'button[class*="agree"]',
    'button[class*="allow"]',
]

MODAL_SELECTORS = [
    "dialog[open]",
    '[class*="modal"][class*="overlay"]',
    '[class*="popup"][class*="overlay"]',
    '[class*="modal-backdrop"]',
    '[class*="overlay"][style*="z-index"]',
    '[role="dialog"]',
]


async def remove_obstructions(
    proc: HTMLProcessor,
    options: CleanOptions | None = None,
) -> CleanResult:
    """Remove all obstructions from the page."""
    opts: CleanOptions = {
        "cookie_banners": True,
        "modals": True,
        "fixed_elements": True,
        "ads": False,
        "lazy_load": False,
    }
    if options:
        opts.update(options)

    removed_types: list[str] = []
    total_removed = 0

    if opts.get("cookie_banners", True):
        n = await dismiss_cookie_banners(proc)
        if n > 0:
            removed_types.append("cookie-banners")
            total_removed += n

    if opts.get("modals", True):
        n = await close_modals(proc)
        if n > 0:
            removed_types.append("modals")
            total_removed += n

    # Newsletter popups (always on by default)
    n = await dismiss_newsletter_popups(proc)
    if n > 0:
        removed_types.append("newsletter-popups")
        total_removed += n

    # Paywall overlays (always on by default)
    n = await remove_paywall_overlays(proc)
    if n > 0:
        removed_types.append("paywall-overlays")
        total_removed += n

    if opts.get("fixed_elements", True):
        n = await remove_fixed_elements(proc)
        if n > 0:
            removed_types.append("fixed-elements")
            total_removed += n

    if opts.get("ads", False):
        n = await remove_ads(proc)
        if n > 0:
            removed_types.append("ads")
            total_removed += n

    if opts.get("lazy_load", False):
        await trigger_lazy_load(
            proc,
            scrolls=opts.get("lazy_load_scrolls", 3),
            wait=opts.get("lazy_load_wait", 500),
        )
        removed_types.append("lazy-load-triggered")

    return {"removed_count": total_removed, "removed_types": removed_types}


async def dismiss_cookie_banners(proc: HTMLProcessor) -> int:
    """Try to dismiss cookie consent banners by clicking accept buttons."""
    js = f"""
    (function() {{
      var selectors = {json.dumps(COOKIE_SELECTORS)};
      var removed = 0;
      for (var i = 0; i < selectors.length; i++) {{
        try {{
          var els = document.querySelectorAll(selectors[i]);
          for (var j = 0; j < els.length; j++) {{
            var el = els[j];
            if (el.offsetParent !== null) {{
              el.click();
              removed++;
            }}
          }}
        }} catch(e) {{}}
      }}
      // i18n text-based cookie accept detection
      var acceptTexts = [
        'accept', 'agree', 'allow', 'ok', 'got it', 'i understand',
        'akzeptieren', 'zustimmen', 'einverstanden',
        'accepter', 'accepte',
        'aceptar', 'acepto',
        'accetta', 'accetto',
        'accepteren',
        'godk\\u00e4nn', 'acceptera',
        '\\u043f\\u0440\\u0438\\u043d\\u044f\\u0442\\u044c', '\\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u0435\\u043d',
      ];
      var cookieContainers = document.querySelectorAll(
        '[class*="cookie"], [class*="consent"], [class*="gdpr"], [class*="privacy"], [id*="cookie"], [id*="consent"]'
      );
      for (var c = 0; c < cookieContainers.length; c++) {{
        var buttons = cookieContainers[c].querySelectorAll('button, a[role="button"], [class*="btn"]');
        for (var b = 0; b < buttons.length; b++) {{
          var btn = buttons[b];
          if (btn.offsetParent === null) continue;
          var text = (btn.textContent || '').trim().toLowerCase();
          for (var t = 0; t < acceptTexts.length; t++) {{
            if (text.indexOf(acceptTexts[t]) !== -1) {{
              btn.click();
              removed++;
              break;
            }}
          }}
        }}
      }}
      // Remove common banner containers
      var bannerSels = [
        '[class*="cookie-banner"]', '[class*="cookie-notice"]',
        '[class*="cookie-bar"]', '[id*="cookie-banner"]',
        '[class*="consent-banner"]', '[class*="consent-bar"]',
      ];
      for (var i = 0; i < bannerSels.length; i++) {{
        try {{
          var els = document.querySelectorAll(bannerSels[i]);
          for (var j = 0; j < els.length; j++) {{
            els[j].remove();
            removed++;
          }}
        }} catch(e) {{}}
      }}
      return removed;
    }})()
    """
    result = await proc.evaluate(js)
    return result if isinstance(result, int) else 0


async def close_modals(proc: HTMLProcessor) -> int:
    """Close modal dialogs and overlays."""
    js = f"""
    (function() {{
      var selectors = {json.dumps(MODAL_SELECTORS)};
      var removed = 0;
      for (var i = 0; i < selectors.length; i++) {{
        var els = document.querySelectorAll(selectors[i]);
        for (var j = 0; j < els.length; j++) {{
          els[j].remove();
          removed++;
        }}
      }}
      var dialogs = document.querySelectorAll('dialog[open]');
      for (var i = 0; i < dialogs.length; i++) {{
        dialogs[i].close();
        removed++;
      }}
      return removed;
    }})()
    """
    result = await proc.evaluate(js)
    return result if isinstance(result, int) else 0


async def remove_fixed_elements(proc: HTMLProcessor) -> int:
    """Remove position:fixed/sticky elements with high z-index."""
    js = """
    (function() {
      var removed = 0;
      // Strategy 1: Check elements with known fixed/sticky class patterns first
      var knownPatterns = [
        '[class*="sticky"]', '[class*="fixed"]', '[class*="toolbar"]',
        '[class*="header"]', '[class*="navbar"]', '[class*="topbar"]',
        '[class*="bottombar"]', '[class*="footer"]', '[class*="dock"]',
        '[class*="float"]', '[class*="overlay"]',
      ];
      var checked = new Set();
      for (var p = 0; p < knownPatterns.length; p++) {
        try {
          var els = document.querySelectorAll(knownPatterns[p]);
          for (var i = 0; i < els.length; i++) {
            var el = els[i];
            if (checked.has(el)) continue;
            checked.add(el);
            if (el === document.body || el === document.documentElement) continue;
            var style = window.getComputedStyle(el);
            var pos = style.position;
            if (pos === 'fixed' || pos === 'sticky') {
              var zIndex = parseInt(style.zIndex) || 0;
              var rect = el.getBoundingClientRect();
              if ((rect.width > 200 || rect.height > 50) && zIndex >= 100) {
                el.remove();
                removed++;
              }
            }
          }
        } catch(e) {}
      }
      // Strategy 2: Limited scan — top-level children + first 500 elements
      var fallback = document.body ? document.body.children : [];
      var toCheck = Array.from(fallback);
      // Also grab up to 500 elements total
      var allEls = document.querySelectorAll('body > *, body > * > *');
      for (var i = 0; i < Math.min(allEls.length, 500); i++) {
        if (!checked.has(allEls[i])) toCheck.push(allEls[i]);
      }
      for (var i = 0; i < toCheck.length; i++) {
        var el = toCheck[i];
        if (checked.has(el)) continue;
        checked.add(el);
        if (el === document.body || el === document.documentElement) continue;
        try {
          var style = window.getComputedStyle(el);
          var pos = style.position;
          if (pos === 'fixed' || pos === 'sticky') {
            var zIndex = parseInt(style.zIndex) || 0;
            var rect = el.getBoundingClientRect();
            if ((rect.width > 200 || rect.height > 50) && zIndex >= 100) {
              el.remove();
              removed++;
            }
          }
        } catch(e) {}
      }
      return removed;
    })()
    """
    result = await proc.evaluate(js)
    return result if isinstance(result, int) else 0


async def dismiss_newsletter_popups(proc: HTMLProcessor) -> int:
    """Dismiss newsletter signup popups and overlays."""
    js = """
    (function() {
      var removed = 0;
      var selectors = [
        '[class*="newsletter"][class*="modal"]',
        '[class*="newsletter"][class*="popup"]',
        '[class*="newsletter"][class*="overlay"]',
        '[class*="subscribe"][class*="modal"]',
        '[class*="subscribe"][class*="popup"]',
        '[class*="signup"][class*="modal"]',
        '[class*="signup"][class*="popup"]',
        '[class*="email-capture"]',
        '[class*="newsletter-signup"]',
      ];
      for (var i = 0; i < selectors.length; i++) {
        try {
          var els = document.querySelectorAll(selectors[i]);
          for (var j = 0; j < els.length; j++) {
            els[j].remove();
            removed++;
          }
        } catch(e) {}
      }
      // Also try to find and click close buttons within newsletter popups
      var containers = document.querySelectorAll('[class*="newsletter"], [class*="subscribe"]');
      for (var i = 0; i < containers.length; i++) {
        var close = containers[i].querySelector('[class*="close"], [aria-label*="close" i], button[class*="dismiss"]');
        if (close) {
          close.click();
          removed++;
        }
      }
      return removed;
    })()
    """
    result = await proc.evaluate(js)
    return result if isinstance(result, int) else 0


async def remove_paywall_overlays(proc: HTMLProcessor) -> int:
    """Remove paywall overlays and restore scrolling."""
    js = """
    (function() {
      var removed = 0;
      var selectors = [
        '[class*="paywall"]',
        '[class*="regwall"]',
        '[class*="gate"][class*="overlay"]',
        '[class*="gate"][class*="modal"]',
        '[id*="paywall"]',
        '[data-testid*="paywall"]',
        '[class*="metered"]',
      ];
      for (var i = 0; i < selectors.length; i++) {
        try {
          var els = document.querySelectorAll(selectors[i]);
          for (var j = 0; j < els.length; j++) {
            els[j].remove();
            removed++;
          }
        } catch(e) {}
      }
      // Remove body overflow:hidden that paywalls often set
      if (document.body) {
        var bodyStyle = window.getComputedStyle(document.body);
        if (bodyStyle.overflow === 'hidden') {
          document.body.style.overflow = '';
          removed++;
        }
      }
      return removed;
    })()
    """
    result = await proc.evaluate(js)
    return result if isinstance(result, int) else 0


async def remove_ads(proc: HTMLProcessor) -> int:
    """Remove common ad network elements."""
    js = """
    (function() {
      var selectors = [
        '[class*="ad-container"]', '[class*="ad-wrapper"]',
        '[class*="advertisement"]', '[id*="google_ads"]',
        '[id*="ad-slot"]', 'ins.adsbygoogle',
        '[data-ad]', '[class*="sponsored"]',
        'iframe[src*="doubleclick"]', 'iframe[src*="googlesyndication"]',
      ];
      var removed = 0;
      for (var i = 0; i < selectors.length; i++) {
        var els = document.querySelectorAll(selectors[i]);
        for (var j = 0; j < els.length; j++) {
          els[j].remove();
          removed++;
        }
      }
      return removed;
    })()
    """
    result = await proc.evaluate(js)
    return result if isinstance(result, int) else 0


async def trigger_lazy_load(
    proc: HTMLProcessor,
    scrolls: int = 3,
    wait: int = 500,
) -> None:
    """Trigger lazy-loaded content by scrolling the page."""
    for _ in range(scrolls):
        await proc.scroll_by(0, 800)
        await proc.wait(wait)
    await proc.evaluate("window.scrollTo(0, 0)")
