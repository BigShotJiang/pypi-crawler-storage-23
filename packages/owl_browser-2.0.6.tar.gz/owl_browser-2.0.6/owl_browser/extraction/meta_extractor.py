"""
Structured metadata extraction from HTML.

Extracts JSON-LD, OpenGraph, Twitter Card, microdata (itemprop/itemscope),
canonical URLs, favicons, and RSS/Atom feeds.
"""

from __future__ import annotations

import json
from typing import Any

from bs4 import BeautifulSoup, Tag

from .types import FeedLink, MetaData


def extract_meta(html: str) -> MetaData:
    """Extract all structured metadata from HTML."""
    soup = BeautifulSoup(html, "html.parser")

    result: MetaData = {
        "title": None,
        "description": None,
        "canonical": None,
        "og": {},
        "twitter": {},
        "json_ld": [],
        "microdata": [],
        "feeds": [],
        "favicon": None,
        "other": {},
    }

    # Title
    title_el = soup.find("title")
    if title_el:
        result["title"] = title_el.get_text(strip=True) or None

    # Canonical
    canonical_el = soup.find("link", rel="canonical")
    if canonical_el and isinstance(canonical_el, Tag):
        result["canonical"] = canonical_el.get("href")  # type: ignore[assignment]

    # Favicon
    favicon_el = soup.find("link", rel=lambda x: x and ("icon" in str(x)))
    if favicon_el and isinstance(favicon_el, Tag):
        result["favicon"] = favicon_el.get("href")  # type: ignore[assignment]

    # Meta tags
    for meta in soup.find_all("meta"):
        if not isinstance(meta, Tag):
            continue
        name = meta.get("name") or meta.get("property") or ""
        content = meta.get("content") or ""
        if isinstance(name, list):
            name = name[0] if name else ""
        if isinstance(content, list):
            content = content[0] if content else ""
        if not name or not content:
            continue

        if name == "description":
            result["description"] = content
        elif name.startswith("og:"):
            result["og"][name[3:]] = content
        elif name.startswith("twitter:"):
            result["twitter"][name[8:]] = content
        else:
            result["other"][name] = content

    result["json_ld"] = extract_json_ld(html)
    result["microdata"] = extract_microdata(html)
    result["feeds"] = extract_feeds(html)

    return result


def extract_json_ld(html: str) -> list[object]:
    """Extract JSON-LD structured data."""
    soup = BeautifulSoup(html, "html.parser")
    results: list[object] = []

    for script in soup.find_all("script", type="application/ld+json"):
        text = script.string
        if not text:
            continue
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                results.extend(parsed)
            elif isinstance(parsed, dict):
                results.append(parsed)
        except (json.JSONDecodeError, ValueError):
            pass

    return results


def extract_open_graph(html: str) -> dict[str, str]:
    """Extract OpenGraph meta tags."""
    soup = BeautifulSoup(html, "html.parser")
    og: dict[str, str] = {}

    for meta in soup.find_all("meta", property=lambda x: x and str(x).startswith("og:")):
        if not isinstance(meta, Tag):
            continue
        prop = str(meta.get("property") or "")
        content = str(meta.get("content") or "")
        if prop and content:
            og[prop[3:]] = content

    return og


def extract_twitter_card(html: str) -> dict[str, str]:
    """Extract Twitter Card meta tags."""
    soup = BeautifulSoup(html, "html.parser")
    twitter: dict[str, str] = {}

    for meta in soup.find_all("meta", attrs={"name": lambda x: x and str(x).startswith("twitter:")}):
        if not isinstance(meta, Tag):
            continue
        name = str(meta.get("name") or "")
        content = str(meta.get("content") or "")
        if name and content:
            twitter[name[8:]] = content

    return twitter


def extract_microdata(html: str) -> list[dict[str, Any]]:
    """Extract microdata (itemprop/itemscope) from HTML."""
    soup = BeautifulSoup(html, "html.parser")
    results: list[dict[str, Any]] = []

    for el in soup.find_all(attrs={"itemscope": True}):
        if not isinstance(el, Tag):
            continue
        # Skip nested itemscopes
        if el.find_parent(attrs={"itemscope": True}):
            continue

        record: dict[str, Any] = {}
        item_type = el.get("itemtype")
        if item_type:
            record["@type"] = item_type

        for prop in el.find_all(attrs={"itemprop": True}):
            if not isinstance(prop, Tag):
                continue
            # Skip props belonging to nested itemscopes
            closest = prop.find_parent(attrs={"itemscope": True})
            if closest and closest != el:
                continue

            name = str(prop.get("itemprop") or "")
            if not name:
                continue

            value: str | None = None
            tag = prop.name
            if tag == "meta":
                value = str(prop.get("content") or "")
            elif tag in ("a", "link"):
                value = str(prop.get("href") or "")
            elif tag == "img":
                value = str(prop.get("src") or "")
            elif tag == "time":
                value = str(prop.get("datetime") or prop.get_text(strip=True) or "")
            else:
                value = prop.get_text(strip=True) or None

            record[name] = value

        if record:
            results.append(record)

    return results


def extract_feeds(html: str) -> list[FeedLink]:
    """Extract RSS/Atom feed links."""
    soup = BeautifulSoup(html, "html.parser")
    feeds: list[FeedLink] = []

    for link in soup.find_all("link", rel="alternate"):
        if not isinstance(link, Tag):
            continue
        link_type = str(link.get("type") or "")
        href = link.get("href")
        if not href:
            continue

        feed_type: str
        if "rss" in link_type:
            feed_type = "rss"
        elif "atom" in link_type:
            feed_type = "atom"
        else:
            continue

        title = link.get("title")
        feeds.append({
            "type": feed_type,  # type: ignore[typeddict-item]
            "href": str(href),
            "title": str(title) if title else None,
        })

    return feeds


def extract_canonical(html: str) -> str | None:
    """Extract the canonical URL."""
    soup = BeautifulSoup(html, "html.parser")
    el = soup.find("link", rel="canonical")
    if el and isinstance(el, Tag):
        href = el.get("href")
        return str(href) if href else None
    return None


def extract_favicon(html: str) -> str | None:
    """Extract the favicon URL."""
    soup = BeautifulSoup(html, "html.parser")
    el = soup.find("link", rel=lambda x: x and ("icon" in str(x)))
    if el and isinstance(el, Tag):
        href = el.get("href")
        return str(href) if href else None
    return None
