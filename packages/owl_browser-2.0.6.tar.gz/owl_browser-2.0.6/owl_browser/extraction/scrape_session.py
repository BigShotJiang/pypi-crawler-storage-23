"""
Multi-page scraping orchestrator.

Combines content cleaning, extraction, pagination, deduplication,
and optional detail-page following into a single scrape() call.
"""

from __future__ import annotations

import json
import time
from typing import Any

from .content_cleaner import remove_obstructions
from .html_processor import HTMLProcessor
from .pagination import detect_pagination, go_to_next_page, has_next_page
from .selector_engine import extract_all, extract_first
from .transforms import resolve_url
from .types import ExtractionResult, ScrapeOptions


class ScrapeSession:
    """Multi-page scraping orchestrator."""

    __slots__ = ("_proc", "_aborted")

    def __init__(self, proc: HTMLProcessor) -> None:
        self._proc = proc
        self._aborted = False

    def abort(self) -> None:
        """Cancel a running scrape."""
        self._aborted = True

    async def scrape(
        self,
        container_selector: str,
        options: ScrapeOptions | None = None,
    ) -> ExtractionResult:
        """Run a multi-page scrape."""
        self._aborted = False
        start_time = time.monotonic()
        opts = options or {}

        max_pages = opts.get("max_pages", 10)
        max_items = opts.get("max_items", float("inf"))
        should_clean = opts.get("clean", True)
        page_delay = opts.get("page_delay", 500)
        deduplicate_by = opts.get("deduplicate_by")
        fields = opts.get("fields", {})

        all_items: list[dict[str, Any]] = []
        page_urls: list[str] = []
        seen_keys: set[str] = set()
        complete = True
        prev_page_signatures: set[str] | None = None

        pagination = opts.get("pagination") or await detect_pagination(self._proc)

        on_page = opts.get("on_page")
        on_item = opts.get("on_item")

        for page in range(max_pages):
            if self._aborted:
                complete = False
                break

            current_url = await self._proc.get_url()
            page_urls.append(current_url)

            if should_clean and page == 0:
                await remove_obstructions(self._proc)

            # Wait for container to appear
            try:
                await self._proc.wait_for_selector(container_selector, 5000)
            except Exception:
                pass  # Timeout — try extracting anyway

            html = await self._proc.get_html("basic")
            page_items = extract_all(html, container_selector, fields)

            # Empty page guard
            if not page_items:
                if page > 0:
                    await self._proc.wait(2000)
                    retry_html = await self._proc.get_html("basic")
                    page_items = extract_all(retry_html, container_selector, fields)
                if not page_items:
                    if page > 0:
                        complete = False
                    break

            # Stale page guard — detect if page didn't actually change
            current_signatures = set(
                json.dumps(item, sort_keys=True) for item in page_items
            )
            if prev_page_signatures and prev_page_signatures:
                overlap = len(current_signatures & prev_page_signatures)
                overlap_ratio = overlap / max(len(current_signatures), 1)
                if overlap_ratio > 0.8:
                    complete = False
                    break
            prev_page_signatures = current_signatures

            # Deduplicate
            if deduplicate_by:
                deduped: list[dict[str, Any]] = []
                for item in page_items:
                    key = str(item.get(deduplicate_by, ""))
                    if key and key not in seen_keys:
                        seen_keys.add(key)
                        deduped.append(item)
                page_items = deduped

            # Follow detail pages
            follow = opts.get("follow")
            if follow:
                page_items = await self._follow_detail_pages(
                    html, container_selector, page_items, follow, current_url
                )

            # Collect items
            for item in page_items:
                if len(all_items) >= max_items:
                    complete = False
                    break
                all_items.append(item)
                if on_item:
                    on_item(item)

            if on_page:
                on_page(page + 1, page_items)

            if len(all_items) >= max_items:
                complete = False
                break

            # Navigate to next page
            if page < max_pages - 1 and pagination:
                current_page_num = pagination.get("start_page", 1) + page
                has_more = await has_next_page(self._proc, pagination, current_page_num)
                if not has_more:
                    break

                success = await go_to_next_page(
                    self._proc, pagination, current_page_num
                )
                if not success:
                    break

                if page_delay > 0:
                    await self._proc.wait(page_delay)
            elif not pagination:
                break

        elapsed = (time.monotonic() - start_time) * 1000

        return {
            "items": all_items,
            "total_items": len(all_items),
            "pages_scraped": len(page_urls),
            "page_urls": page_urls,
            "complete": complete,
            "duration_ms": elapsed,
        }

    async def _follow_detail_pages(
        self,
        html: str,
        container_selector: str,
        items: list[dict[str, Any]],
        follow: dict[str, Any],
        base_url: str,
    ) -> list[dict[str, Any]]:
        """Follow detail page links and merge extracted fields."""
        enriched: list[dict[str, Any]] = []
        wait_after = follow.get("wait_after", 1000)
        detail_fields = follow.get("fields", {})
        detail_container = follow.get("container_selector", "body")

        for item in items:
            if self._aborted:
                enriched.append(item)
                continue

            # Try to find a URL from the item (typically 'link' field)
            detail_url: str | None = None
            for key in ("link", "url", "href"):
                val = item.get(key)
                if isinstance(val, str) and val:
                    detail_url = resolve_url(val, base_url)
                    break

            if not detail_url:
                enriched.append(item)
                continue

            try:
                await self._proc.goto(detail_url)
                await self._proc.wait(wait_after)

                detail_html = await self._proc.get_html("basic")
                detail_data = extract_first(detail_html, detail_container, detail_fields)

                merged = {**item, **(detail_data or {})}
                enriched.append(merged)

                await self._proc.evaluate("window.history.back()")
                await self._proc.wait(500)
            except Exception:
                enriched.append(item)

        return enriched
