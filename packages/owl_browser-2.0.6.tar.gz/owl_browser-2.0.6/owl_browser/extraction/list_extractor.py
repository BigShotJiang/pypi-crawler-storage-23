"""
Extract from lists, cards, grids — any repeating DOM pattern with a known container.

Provides auto-field detection: infers field names from child element semantics
(headings -> title, img -> image, a -> link, price-like -> price, etc.).
"""

from __future__ import annotations

from typing import Any

from bs4 import BeautifulSoup, Tag

from .selector_engine import extract_all
from .types import FieldSpec, ListOptions


def extract(
    html: str,
    container_selector: str,
    options: ListOptions | None = None,
) -> list[dict[str, Any]]:
    """Extract items from a container with optional auto-field detection."""
    opts = options or {}
    soup = BeautifulSoup(html, "html.parser")
    container = soup.select_one(container_selector)
    if container is None:
        return []

    item_selector = opts.get("item_selector") or _detect_item_selector(container)
    if not item_selector:
        return []

    fields = opts.get("fields") or analyze_structure(html, container_selector, item_selector)

    # Handle direct child selectors (BS4 needs :scope prefix for > combinator)
    if item_selector.startswith("> "):
        items = container.select(f":scope {item_selector}")
        from .selector_engine import resolve_field
        results = []
        for item in items:
            record = {name: resolve_field(item, spec) for name, spec in fields.items()}
            results.append(record)
    else:
        results = extract_all(html, f"{container_selector} {item_selector}", fields)

    limit = opts.get("limit")
    if limit:
        results = results[:limit]

    return results


def analyze_structure(
    html: str,
    container_selector: str,
    item_selector: str | None = None,
) -> dict[str, FieldSpec]:
    """Analyze child elements to infer field names and selectors."""
    soup = BeautifulSoup(html, "html.parser")
    container = soup.select_one(container_selector)
    if container is None:
        return {}

    effective = item_selector or _detect_item_selector(container)
    if not effective:
        return {}

    # BS4 needs :scope prefix for > combinator at start of selector
    sel = f":scope {effective}" if effective.startswith("> ") else effective
    items = container.select(sel)
    if not items:
        return {}

    return _infer_fields(items[0])


def extract_list(html: str, selector: str | None = None) -> list[str]:
    """Extract a simple <ul>/<ol> list as string[]."""
    soup = BeautifulSoup(html, "html.parser")
    list_el = soup.select_one(selector or "ul, ol")
    if list_el is None:
        return []

    items: list[str] = []
    for li in list_el.find_all("li"):
        text = li.get_text(strip=True)
        if text:
            items.append(text)
    return items


def extract_cards(
    html: str,
    container_selector: str,
    card_selector: str | None = None,
) -> list[dict[str, Any]]:
    """Extract card-like repeating structures."""
    return extract(html, container_selector, {"item_selector": card_selector} if card_selector else None)


# ==================== Internal ====================


def _css_escape(value: str) -> str:
    """Escape special characters in a CSS identifier."""
    import re
    return re.sub(r'([!"#$%&\'()*+,./:;<=>?@\[\\\]^`{|}~])', r'\\\1', value)


def _detect_item_selector(container: Tag) -> str | None:
    """Detect the most likely item selector within a container."""
    children = [c for c in container.children if isinstance(c, Tag)]
    if not children:
        return None

    combo_counts: dict[str, int] = {}
    for el in children:
        tag = el.name
        raw_cls = (el.get("class") or [None])[0]  # type: ignore[index]
        key = f"{tag}.{_css_escape(str(raw_cls))}" if raw_cls else tag
        combo_counts[key] = combo_counts.get(key, 0) + 1

    best_selector: str | None = None
    best_count = 1
    for selector, count in combo_counts.items():
        if count > best_count:
            best_count = count
            best_selector = selector

    if not best_selector:
        li_count = len(container.select(":scope > li"))
        if li_count >= 2:
            return "> li"
        tr_count = len(container.select(":scope > tr"))
        if tr_count >= 2:
            return "> tr"

    return f"> {best_selector}" if best_selector else None


def _infer_fields(item: Tag) -> dict[str, FieldSpec]:
    """Infer field names from the structure of a representative item element."""
    import re

    fields: dict[str, FieldSpec] = {}
    used_names: set[str] = set()
    item_tag = item.name

    # If the item itself is an <a>, treat it as a link with title
    if item_tag == "a":
        fields["link"] = "@href"
        fields["title"] = ""  # empty = item's own text
        used_names.update(("link", "title"))

    # If the item itself is a heading
    if "title" not in used_names and item_tag and re.match(r"^h[1-6]$", item_tag):
        fields["title"] = ""
        used_names.add("title")

    # --- Microdata / schema.org detection (itemprop attributes) ---
    microdata_map: dict[str, str] = {
        "name": "title",
        "headline": "title",
        "price": "price",
        "description": "description",
        "image": "image",
        "url": "link",
        "datePublished": "date",
        "dateCreated": "date",
    }

    for prop, field_name in microdata_map.items():
        if field_name in used_names:
            continue
        el = item.select_one(f'[itemprop="{prop}"]')
        if el is None:
            continue

        tag = el.name
        if field_name == "image" and tag == "img":
            fields[field_name] = f'[itemprop="{prop}"]@src'
        elif field_name == "link" and tag == "a":
            fields[field_name] = f'[itemprop="{prop}"]@href'
        elif field_name == "date" and tag == "time":
            fields[field_name] = {"selector": f'[itemprop="{prop}"]', "attribute": "datetime"}
        elif field_name == "price":
            content = el.get("content")
            if content:
                fields[field_name] = {"selector": f'[itemprop="{prop}"]', "attribute": "content"}
            else:
                fields[field_name] = f'[itemprop="{prop}"]'
        else:
            fields[field_name] = f'[itemprop="{prop}"]'
        used_names.add(field_name)

    # --- Standard field detection ---

    # Check for headings -> title
    if "title" not in used_names:
        heading = item.find(["h1", "h2", "h3", "h4", "h5", "h6"])
        if heading and isinstance(heading, Tag):
            fields["title"] = heading.name
            used_names.add("title")

    # Check for images -> image
    if "image" not in used_names:
        img = item.find("img")
        if img:
            fields["image"] = "img@src"
            used_names.add("image")

    # Check for links -> link
    if "link" not in used_names:
        link = item.find("a")
        if link and isinstance(link, Tag):
            fields["link"] = "a@href"
            if "title" not in used_names and link.get_text(strip=True):
                fields["title"] = "a"
                used_names.add("title")
            used_names.add("link")

    # Check for price-like content — first by class, then by text pattern
    if "price" not in used_names:
        price_el = item.select_one('[class*="price"], [data-price]')
        if price_el:
            cls = (price_el.get("class") or [None])[0]  # type: ignore[index]
            fields["price"] = f".{_css_escape(str(cls))}" if cls else '[class*="price"]'
            used_names.add("price")
        else:
            # Text-based price detection: look for currency symbols + digits
            price_regex = re.compile(r'[$€£¥₹₩]\s*[\d,.]+|[\d,.]+\s*[$€£¥₹₩]')
            for desc in item.find_all(True):
                if "price" in used_names:
                    break
                if not isinstance(desc, Tag):
                    continue
                # Only consider leaf-ish elements (no children or only text children)
                if len(list(desc.children)) > 3:  # tag children + text nodes
                    child_tags = [c for c in desc.children if isinstance(c, Tag)]
                    if len(child_tags) > 2:
                        continue
                text = desc.get_text(strip=True)
                if price_regex.search(text) and len(text) < 30:
                    cls = (desc.get("class") or [None])[0]  # type: ignore[index]
                    fields["price"] = f".{_css_escape(str(cls))}" if cls else desc.name
                    used_names.add("price")

    # Check for time/date elements
    if "date" not in used_names:
        time_el = item.select_one('time, [class*="date"], [class*="time"]')
        if time_el and isinstance(time_el, Tag):
            if time_el.name == "time":
                fields["date"] = {"selector": "time", "attribute": "datetime"}
            else:
                cls = (time_el.get("class") or [None])[0]  # type: ignore[index]
                fields["date"] = f".{cls}" if cls else '[class*="date"]'
            used_names.add("date")

    # Check for rating/star content
    if "rating" not in used_names:
        rating_el = item.select_one(
            '[class*="rating"], [class*="star"], [data-rating],'
            ' [aria-label*="rating"], [aria-label*="star"]'
        )
        if rating_el and isinstance(rating_el, Tag):
            data_rating = rating_el.get("data-rating")
            if data_rating:
                fields["rating"] = {"selector": "[data-rating]", "attribute": "data-rating"}
            else:
                aria_label = rating_el.get("aria-label")
                if aria_label:
                    fields["rating"] = {"selector": "[aria-label]", "attribute": "aria-label"}
                else:
                    cls = (rating_el.get("class") or [None])[0]  # type: ignore[index]
                    fields["rating"] = f".{_css_escape(str(cls))}" if cls else '[class*="rating"]'
            used_names.add("rating")

    # Check for badges/status/tags
    if "badge" not in used_names:
        badge_el = item.select_one(
            '[class*="badge"]:not(a), [class*="status"]:not(a),'
            ' [class*="label"]:not(label):not(a), [class*="chip"]:not(a)'
        )
        if badge_el and isinstance(badge_el, Tag):
            cls = (badge_el.get("class") or [None])[0]  # type: ignore[index]
            fields["badge"] = f".{_css_escape(str(cls))}" if cls else '[class*="badge"]'
            used_names.add("badge")

    # Check for description/body text (longer text blocks or <p> elements)
    if "description" not in used_names:
        # First, look for <p> elements anywhere in the item (up to depth 3)
        p_el = item.find("p")
        if p_el and isinstance(p_el, Tag) and len(p_el.get_text(strip=True)) > 10:
            fields["description"] = "p"
            used_names.add("description")

        # Fallback: check all descendant elements for longer text (threshold lowered to 20)
        if "description" not in used_names:
            for desc in item.find_all(True):
                if "description" in used_names:
                    break
                if not isinstance(desc, Tag):
                    continue
                if desc.name in ("h1", "h2", "h3", "h4", "h5", "h6", "img", "a", "time", "p"):
                    continue
                if desc.find(["h1", "h2", "h3", "h4", "h5", "h6", "img"]):
                    continue  # Skip containers of other fields
                text = desc.get_text(strip=True)
                if len(text) > 20:
                    cls = (desc.get("class") or [None])[0]  # type: ignore[index]
                    fields["description"] = f".{_css_escape(str(cls))}" if cls else desc.name
                    used_names.add("description")

    return fields
