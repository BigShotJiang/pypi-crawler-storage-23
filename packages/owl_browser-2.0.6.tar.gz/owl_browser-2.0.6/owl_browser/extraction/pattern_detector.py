"""
Zero-config auto pattern discovery via pure DOM analysis.

Finds repeating DOM structures without any AI — uses tag+class frequency,
child consistency scoring, and semantic field inference.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Any

from bs4 import BeautifulSoup, Tag

from .list_extractor import analyze_structure
from .selector_engine import extract_all
from .types import DetectedPattern, DetectOptions, FieldSpec


def detect(
    html: str,
    options: DetectOptions | None = None,
) -> list[DetectedPattern]:
    """Detect repeating patterns on the page."""
    opts = options or {}
    min_count = opts.get("min_count", 3)
    min_confidence = opts.get("min_confidence", 0.5)
    region = opts.get("region")

    soup = BeautifulSoup(html, "html.parser")
    root = soup.select_one(region) if region else soup.find("body")
    if root is None or not isinstance(root, Tag):
        return []

    candidates = _find_candidates(root, min_count)

    patterns: list[DetectedPattern] = []
    for candidate in candidates:
        try:
            container_sel = candidate["container_selector"]
            item_sel = candidate["item_selector"]
            items = candidate["items"]
            if len(items) < min_count:
                continue

            confidence = _score_candidate(items)
            if confidence < min_confidence:
                continue

            fields = analyze_structure(html, container_sel, item_sel)
            if not fields:
                continue

            full_selector = f"{container_sel} {item_sel}"
            sample = extract_all(html, full_selector, fields)[:3]

            patterns.append({
                "container_selector": container_sel,
                "item_selector": full_selector,
                "item_count": len(items),
                "confidence": confidence,
                "fields": fields,
                "sample": sample,
            })
        except Exception:
            # Skip candidates with invalid selectors
            continue

    patterns.sort(key=lambda p: (-p["confidence"], -p["item_count"]))
    return patterns


def detect_and_extract(
    html: str,
    options: DetectOptions | None = None,
) -> list[dict[str, Any]]:
    """Detect patterns and immediately extract the best one."""
    patterns = detect(html, options)
    if not patterns:
        return []
    best = patterns[0]
    return extract_all(html, best["item_selector"], best["fields"])


# ==================== Internal ====================

# --- Utility class detection for multi-class matching ---

_UTILITY_PREFIXES = re.compile(
    r"^(p|m|w|h|min|max|flex|grid|text|bg|border|rounded|shadow|gap|space|"
    r"overflow|z|opacity|cursor|font|leading|tracking|transition|duration|"
    r"ease|scale|rotate|translate|skew|origin|ring|outline|decoration|"
    r"placeholder|divide|sr)-"
)

_UTILITY_WORDS = frozenset([
    "flex", "block", "hidden", "relative", "absolute", "fixed", "sticky",
    "inline", "grid", "table", "contents", "static", "visible", "invisible",
    "isolate", "truncate", "antialiased", "italic", "underline", "uppercase",
    "lowercase", "capitalize", "ordinal",
])


def _is_semantic_class(cls: str) -> bool:
    """Return True if the class looks like a semantic (non-utility) class."""
    if len(cls) <= 1:
        return False
    if _UTILITY_PREFIXES.match(cls):
        return False
    if cls in _UTILITY_WORDS:
        return False
    return True


def _find_candidates(
    root: Tag, min_count: int
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()

    # Strategy 1: Find elements with multiple same-tag+class children
    for el in root.find_all(True):
        if not isinstance(el, Tag):
            continue
        children = [c for c in el.children if isinstance(c, Tag)]
        if len(children) < min_count:
            continue

        combo_counts: dict[str, list[Tag]] = {}
        for child in children:
            tag = child.name
            all_classes = child.get("class") or []
            if not isinstance(all_classes, list):
                all_classes = []
            semantic_classes = [c for c in all_classes if _is_semantic_class(c)][:3]
            if semantic_classes:
                key = f"{tag}.{'.'.join(_css_escape(c) for c in semantic_classes)}"
            elif all_classes:
                key = f"{tag}.{_css_escape(str(all_classes[0]))}"
            else:
                key = tag
            combo_counts.setdefault(key, []).append(child)

        for item_key, items in combo_counts.items():
            if len(items) < min_count:
                continue
            container_sel = _build_selector(el)
            full_key = f"{container_sel}|{item_key}"
            if full_key in seen:
                continue
            seen.add(full_key)

            candidates.append({
                "container_selector": container_sel,
                "item_selector": f"> {item_key}",
                "items": items,
            })

    # Strategy 2: Common list patterns
    for ul in root.find_all(["ul", "ol"]):
        if not isinstance(ul, Tag):
            continue
        lis = ul.find_all("li", recursive=False)
        if len(lis) >= min_count:
            sel = _build_selector(ul)
            key = f"{sel}|li"
            if key not in seen:
                seen.add(key)
                candidates.append({
                    "container_selector": sel,
                    "item_selector": "> li",
                    "items": lis,
                })

    for tbody in root.find_all("tbody"):
        if not isinstance(tbody, Tag):
            continue
        trs = tbody.find_all("tr", recursive=False)
        if len(trs) >= min_count:
            sel = _build_selector(tbody)
            key = f"{sel}|tr"
            if key not in seen:
                seen.add(key)
                candidates.append({
                    "container_selector": sel,
                    "item_selector": "> tr",
                    "items": trs,
                })

    # Strategy 3: Deeper nesting — search grandchildren when direct children are wrapper divs
    for el in root.find_all(True):
        if not isinstance(el, Tag):
            continue
        children = [c for c in el.children if isinstance(c, Tag)]
        # Only try deeper search if children are generic wrappers (divs/spans/li)
        div_children = [
            c for c in children
            if isinstance(c, Tag) and c.name in ("div", "span", "li")
        ]
        if len(div_children) < min_count:
            continue

        # Look at grandchildren for consistent patterns
        grand_combo_counts: dict[str, dict[str, Any]] = {}
        for wrapper in div_children:
            grandchildren = [gc for gc in wrapper.children if isinstance(gc, Tag)]
            if not grandchildren:
                continue
            # Use the wrapper's first grandchild tag+class as the pattern
            first_grand = grandchildren[0]
            if not isinstance(first_grand, Tag):
                continue
            g_tag = first_grand.name
            g_all_classes = first_grand.get("class") or []
            if not isinstance(g_all_classes, list):
                g_all_classes = []
            g_semantic = [c for c in g_all_classes if _is_semantic_class(c)][:3]
            # g_key used only for grouping consistency (not in output)

            # Count the wrapper, not the grandchild — the wrapper IS the item
            w_tag = wrapper.name
            w_all_classes = wrapper.get("class") or []
            if not isinstance(w_all_classes, list):
                w_all_classes = []
            w_semantic = [c for c in w_all_classes if _is_semantic_class(c)][:3]
            if w_semantic:
                w_key = f"{w_tag}.{'.'.join(_css_escape(c) for c in w_semantic)}"
            else:
                w_key = w_tag

            if w_key in grand_combo_counts:
                grand_combo_counts[w_key]["count"] += 1
                grand_combo_counts[w_key]["items"].append(wrapper)
            else:
                grand_combo_counts[w_key] = {"count": 1, "items": [wrapper]}

        for item_key, data in grand_combo_counts.items():
            if data["count"] < min_count:
                continue
            container_sel = _build_selector(el)
            full_key = f"{container_sel}|deep|{item_key}"
            if full_key in seen:
                continue
            seen.add(full_key)
            candidates.append({
                "container_selector": container_sel,
                "item_selector": f"> {item_key}",
                "items": data["items"],
            })

    # Strategy 4: ARIA role detection
    aria_roles = ["listitem", "article", "row", "option", "menuitem", "tab"]
    for role in aria_roles:
        for el in root.find_all(attrs={"role": role}):
            if not isinstance(el, Tag):
                continue
            parent = el.parent
            if parent is None or not isinstance(parent, Tag):
                continue
            siblings = parent.find_all(
                attrs={"role": role}, recursive=False
            )
            if len(siblings) < min_count:
                continue

            container_sel = _build_selector(parent)
            item_key = f'[role="{role}"]'
            full_key = f"{container_sel}|{item_key}"
            if full_key in seen:
                continue
            seen.add(full_key)

            candidates.append({
                "container_selector": container_sel,
                "item_selector": f"> {item_key}",
                "items": siblings,
            })

    # Strategy 5: Data-attribute patterns
    data_attrs = ["data-testid", "data-id", "data-index", "data-item", "data-row"]
    for attr in data_attrs:
        attr_els = root.find_all(attrs={attr: True})
        if len(attr_els) < min_count:
            continue

        # Group by parent
        parent_groups: dict[str, dict[str, Any]] = {}
        for el in attr_els:
            if not isinstance(el, Tag):
                continue
            parent = el.parent
            if parent is None or not isinstance(parent, Tag):
                continue
            p_key = _build_selector(parent)
            if p_key in parent_groups:
                parent_groups[p_key]["items"].append(el)
            else:
                parent_groups[p_key] = {"parent": parent, "items": [el]}

        for container_sel, data in parent_groups.items():
            if len(data["items"]) < min_count:
                continue
            item_key = f"[{attr}]"
            full_key = f"{container_sel}|{item_key}"
            if full_key in seen:
                continue
            seen.add(full_key)
            candidates.append({
                "container_selector": container_sel,
                "item_selector": f"> {item_key}",
                "items": data["items"],
            })

    return candidates


def _score_candidate(items: list[Tag]) -> float:
    """Score a candidate by child consistency and content richness."""
    if not items:
        return 0.0

    score = 0.0

    # 1. Child tag structure consistency (0-0.4)
    structures = []
    for item in items:
        tags = [c.name for c in item.children if isinstance(c, Tag)]
        structures.append(",".join(tags))

    if structures:
        counter = Counter(structures)
        most_common = counter.most_common(1)[0][0]
        consistency = counter[most_common] / len(structures)
        score += consistency * 0.4

    # 2. Average text content (0-0.2)
    text_count = sum(1 for item in items if len(item.get_text(strip=True)) > 10)
    avg_text = text_count / len(items)
    score += min(avg_text, 1.0) * 0.2

    # 3. Presence of links (0-0.15)
    link_count = sum(1 for item in items if item.find("a"))
    score += (link_count / len(items)) * 0.15

    # 4. Presence of images (0-0.1)
    img_count = sum(1 for item in items if item.find("img"))
    score += (img_count / len(items)) * 0.1

    # 5. Item count bonus (0-0.15)
    score += min(len(items) / 20, 1.0) * 0.15

    # 6. ARIA role consistency (0-0.1)
    role_count = sum(1 for item in items if isinstance(item, Tag) and item.get("role"))
    score += (role_count / len(items)) * 0.1

    # 7. Data-attribute consistency (0-0.1)
    data_attr_count = sum(
        1 for item in items
        if isinstance(item, Tag) and any(k.startswith("data-") for k in item.attrs)
    )
    score += (data_attr_count / len(items)) * 0.1

    return round(score, 2)


def _css_escape(value: str) -> str:
    """Escape special characters in a CSS identifier."""
    return re.sub(r'([!"#$%&\'()*+,./:;<=>?@\[\\\]^`{|}~])', r'\\\1', value)


def _build_selector(el: Tag) -> str:
    """Build a CSS selector for an element."""
    tag = el.name
    eid = el.get("id")
    if eid:
        return f"{tag}#{_css_escape(str(eid))}"

    all_classes = el.get("class")
    if not isinstance(all_classes, list):
        all_classes = []

    semantic_classes = [c for c in all_classes if _is_semantic_class(c)][:2]
    if semantic_classes:
        cls = ".".join(_css_escape(str(c)) for c in semantic_classes)
    elif all_classes:
        cls = ".".join(_css_escape(str(c)) for c in all_classes[:2])
    else:
        cls = ""

    selector = f"{tag}.{cls}" if cls else tag

    # Check uniqueness — if multiple matches, add nth-of-type
    try:
        # Navigate up to the root document for select()
        root = el
        while root.parent is not None:
            root = root.parent
        matches = root.select(selector)
        if len(matches) > 1:
            try:
                index = matches.index(el)
                selector = f"{selector}:nth-of-type({index + 1})"
            except ValueError:
                pass
    except Exception:
        # Skip uniqueness check on invalid selectors
        pass

    return selector
