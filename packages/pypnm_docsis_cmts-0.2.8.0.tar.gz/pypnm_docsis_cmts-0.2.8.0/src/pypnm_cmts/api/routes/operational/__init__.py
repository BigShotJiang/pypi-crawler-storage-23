
from __future__ import annotations

# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2025 Maurice Garcia
from pypnm_cmts.api.routes.operational.router import router

__all__ = ["router"]
