# mako-renderer

CLI tool to render `.mako` templates to files.

## Install

```bash
pip install majia
