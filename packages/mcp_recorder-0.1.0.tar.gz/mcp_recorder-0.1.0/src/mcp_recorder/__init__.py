"""mcp-recorder: Record and replay MCP server interactions for deterministic testing."""

from importlib.metadata import version

__version__ = version("mcp-recorder")
