/**
 * BizyDraft 统一 Fetch
 */
import { getCookie } from "../utils.js";

const WHITELIST = [];

function isWhitelisted(url) {
  return WHITELIST.some((item) => url.includes(item));
}

function notifyLogin() {
  if (typeof window !== "undefined" && window.parent) {
    window.parent.postMessage({ type: "openLogin" }, "*");
  }
}

function isFullUrl(url) {
  return (
    typeof url === "string" &&
    (url.startsWith("http://") || url.startsWith("https://"))
  );
}

/**
 * @param {string} url - API 路径如 /x/v1/... 或完整 URL 如 https://...
 * @param {Object} [options]
 * @param {string} [options.method='GET']
 * @param {Object} [options.param] - query 参数
 * @param {any} [options.body] - 请求体，会 JSON.stringify
 * @param {Object} [options.headers]
 * @param {RequestCredentials} [options.credentials]
 * @param {'json'|'stream'|'blob'|'response'} [options.type='json']
 * @param {AbortSignal} [options.signal]
 * @param {boolean} [options.skipShowErrorToast]
 * @returns {Promise<any>}
 */
export async function draftFetch(url, options = {}) {
  const opts = { ...options };
  opts.method = opts.method || "GET";
  const isExternal = isFullUrl(url);

  if (opts.param) {
    const urlParams = new URLSearchParams();
    for (const key in opts.param) {
      if (opts.param[key] != null && opts.param[key] !== undefined) {
        if (Array.isArray(opts.param[key])) {
          opts.param[key].forEach((value) => {
            urlParams.append(key, String(value));
          });
        } else {
          urlParams.append(key, String(opts.param[key]));
        }
      }
    }
    url += `?${urlParams.toString()}`;
    delete opts.param;
  }

  opts.headers = opts.headers || {};
  if (opts.body && !(opts.body instanceof FormData)) {
    opts.body = JSON.stringify(opts.body);
    if (!opts.headers["Content-Type"]) {
      opts.headers["Content-Type"] = "application/json";
    }
  }
  if (!isExternal) {
    const authToken = getCookie("auth_token");
    if (authToken) {
      opts.headers["Authorization"] = `Bearer ${authToken}`;
    }
  }

  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const fullUrl = isExternal ? url : `${origin}${url}`;
  const fetchOptions = {
    method: opts.method,
    headers: opts.headers,
    body: opts.body,
    credentials: opts.credentials,
    signal: opts.signal,
  };

  const response = await fetch(fullUrl, fetchOptions);

  if (response.status === 401 && !isExternal && !isWhitelisted(url)) {
    notifyLogin();
    return { code: 401, message: "请先登录", data: null };
  }

  if (response.status === 502 || response.status === 503) {
    let parsedBody = null;
    let textBody = null;
    try {
      parsedBody = await response.clone().json();
    } catch {
      textBody = await response.clone().text();
    }
    const errorMessage =
      (parsedBody?.message || parsedBody?.data?.message || textBody || "")
        .toString()
        .trim() || "服务开小差了，请稍后重试。";
    return { code: response.status, message: errorMessage, data: null };
  }

  if (opts.type === "stream") return response.body;
  if (opts.type === "blob") return response.blob();
  if (opts.type === "response") return response;

  const data = await response.json();

  if (isExternal) {
    if (!response.ok) {
      throw new Error(data?.message || `HTTP ${response.status}`);
    }
    return data;
  }

  if (!isWhitelisted(url)) {
    if (data?.code == "401") notifyLogin();
    if (data?.data?.code == "401") notifyLogin();
    if (data?.data?.error?.code == "401") notifyLogin();
  }

  if (
    data &&
    typeof data.code !== "undefined" &&
    data.code != 20000 &&
    data.code != 200
  ) {
    if (data.code == "401" && isWhitelisted(url)) {
      return data;
    }
    if (!opts.skipShowErrorToast) {
      console.warn("[draftFetch]", data.message || "请求失败，请稍后重试");
    }
    throw new Error(data.message || "请求失败，请稍后重试");
  }

  return data;
}
