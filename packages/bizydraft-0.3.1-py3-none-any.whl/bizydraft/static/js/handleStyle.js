import { app } from "../../scripts/app.js";
const styleMenus = `
    /* 隐藏Panel内容容器，但排除选择工具箱 */
    .p-panel:not(.selection-toolbox) .p-panel-content-container{
        display: none;
    }
    // .side-tool-bar-container.small-sidebar{
    //     display: none;
    // }
    .comfyui-menu.flex.items-center{
        display: none;
    }
    .p-dialog-mask.p-overlay-mask.p-overlay-mask-enter.p-dialog-bottomright{
        display: none !important;
    }
    body .bizyair-comfy-floating-button{
        display: none;
    }
    .bizy-select-title-container{
        display: none;
    }
    .workflow-tabs-container{
        display: none;
    }
    body .comfyui-body-bottom{
        display: none;
    }
    #comfyui-body-bottom{
        display: none;
    }
    /* 隐藏左侧的工作流按钮 */
    .p-button.p-component.p-button-icon-only.p-button-text.workflows-tab-button.side-bar-button.p-button-secondary{
        display: none;
    }
    /* 隐藏左侧的输入输出按钮 */
    .p-button.p-component.p-button-icon-only.p-button-text.mtb-inputs-outputs-tab-button.side-bar-button.p-button-secondary{
        display: none;
    }
    body div.side-tool-bar-end{
        display: none;
    }
    body .tydev-utils-log-console-container{
        display: none;
    }
    .p-dialog-mask.p-overlay-mask.p-overlay-mask-enter[data-pc-name="dialog"]{
        display: none !important;
    }
    .p-button.p-component.p-button-icon-only.p-button-text.templates-tab-button.side-bar-button.p-button-secondary{
        display: none;
    }
    .p-button.p-component.p-button-icon-only.p-button-text.queue-tab-button.side-bar-button.p-button-secondary{
        display: none;
    }
    .w-full.flex.content-end{
        display: none;
    }
    .side-tool-bar-container.small-sidebar .side-bar-button-label{
        display: none;
    }
    /* 隐藏整个comfy-menu-button-wrapper元素 */
    .comfy-menu-button-wrapper{
        display: none;
    }
    /* 隐藏帮助中心按钮 */
    .comfy-help-center-btn{
        display: none;
    }
    /* 隐藏底部面板(Console)按钮 */
    button[aria-label="底部面板"]{
        display: none;
    }
    /* 隐藏键盘快捷键按钮 */
    button[aria-label^="键盘快捷键"]{
        display: none;
    }
    /* 隐藏右下角按钮组(包含鼠标指针、适应视图、缩放控制、小地图、隐藏链接等按钮) */
    .p-buttongroup.absolute.right-0.bottom-0{
        display: none;
    }
    .pointer-events-auto.relative.w-full.h-10.bg-gradient-to-r.from-blue-600.to-blue-700.flex.items-center.justify-center.px-4 {
        display: none;
    }
    /* 暂时注释，避免隐藏面包屑 */
    /* .p-splitterpanel.p-splitterpanel-nested.flex.flex-col .ml-1.flex.pt-1{
        display: none;
    } */

    /* 隐藏面包屑下拉菜单容器（直接隐藏整个下拉菜单） */
    .p-menu.p-menu-overlay {
        display: none !important;
    }
    /* 隐藏面包屑中的下拉箭头图标 */
    .pi.pi-angle-down {
        display: none !important;
    }

    /* 隐藏actionbar容器 */
    .actionbar-container.pointer-events-auto.flex.h-12.items-center.rounded-lg.border.border-interface-stroke.bg-comfy-menu-bg.px-2.shadow-interface{
        display: none;
    }
    .p-button.p-component.p-button-text.size-8.bg-primary-background.text-white.p-0{
        display: none;
    }
    .p-button.p-component.p-button-secondary.p-button-text.h-8.w-8.px-0{
        display: none;
    }

    /* 隐藏左侧的资产按钮 */
    .p-button.p-component.p-button-icon-only.p-button-text.assets-tab-button.side-bar-button.p-button-secondary {
        display: none;
    }
    /* 隐藏左侧的模型库按钮 */
    .p-button.p-component.p-button-icon-only.p-button-text.model-library-tab-button.side-bar-button.p-button-secondary{
        display: none;
    }
    body .comfy-img-preview video{
      width: 100%;
      height: 100%;
    }
    button[aria-label^="设置 (Ctrl + ,)"]{
      display: none;
    }
    body .p-toast-message.p-toast-message-error{
        display: none;
    }
    body .bizyair-toaster-container{
        display: none;
    }
    /* 隐藏actionbar容器（无背景色版本） */
    .actionbar-container.pointer-events-auto.flex.h-12.items-center.rounded-lg.border.border-interface-stroke.px-2.shadow-interface{
        display: none;
    }
    .text-muted-foreground.bg-transparent.h-8.rounded-lg.p-2.text-xs.side-bar-button.cursor-pointer.border-none.templates-tab-button{
        display: none;
    }
    .text-muted-foreground.bg-transparent.h-8.rounded-lg.p-2.text-xs.side-bar-button.cursor-pointer.border-none.mtb-inputs-outputs-tab-button{
        display: none;
    }
    .text-muted-foreground.bg-transparent.h-8.rounded-lg.p-2.text-xs.side-bar-button.cursor-pointer.border-none.workflows-tab-button{
        display: none;
    }
    .text-muted-foreground.bg-transparent.h-8.rounded-lg.p-2.text-xs.side-bar-button.cursor-pointer.border-none.assets-tab-button{
        display: none;
    }
    .text-base-foreground.hover\:bg-primary-background-hover.h-8.rounded-lg.p-2.text-xs {
        display: none;
    }
    button[aria-label="更多选项"]{
        display: none;
    }
    .p-panel-content.p-2.h-12.flex.flex-row.gap-1 .relative.inline-flex.items-center.justify-center.gap-2.cursor-pointer.whitespace-nowrap.appearance-none.border-none.font-medium.font-inter.transition-colors.bg-primary-background.text-base-foreground.h-8.rounded-lg.p-2.text-xs{
        display: none;
    }
    button[aria-label^="将选区转换为子图"]{
      display: none;
    }
    /*暂时先将画布顶部的面包屑和任务列表隐藏*/
    .flex.justify-end.w-full.pointer-events-none{
        display: none;
    }
    .p-breadcrumb-list{
        display: none;
    }
`;
app.registerExtension({
  name: "comfy.BizyAir.Style",
  async setup() {
    const styleElement = document.createElement("style");
    console.log("styleElement123456");
    styleElement.textContent = styleMenus;
    document.head.appendChild(styleElement);
    const getCloseBtn = () => {
      // let temp = null
      // document.querySelectorAll('h2').forEach(e => {
      //     if (e.innerHTML == "<span>模板</span>") {
      //         const dialogContent = e.closest('.p-dialog-content')
      //         if (dialogContent) {
      //             temp = dialogContent.querySelector('i.pi.pi-times.text-sm')
      //         }
      //     }
      // })
      return document.querySelector("i.pi.pi-times.text-sm");
    };
    const getFengrossmentBtn = () => {
      let temp = null;
      document.querySelectorAll("button").forEach((e) => {
        if (e.getAttribute("aria-label") == "专注模式 (F)") {
          temp = e;
        }
      });
      return temp;
    };
    const getBreadcrumbItem = () => {
      const breadcrumbLabel = document.querySelector(
        ".p-breadcrumb-item-label.px-2"
      );
      if (breadcrumbLabel) {
        return breadcrumbLabel.parentElement?.parentElement;
      }
      return null;
    };

    /**
     * 初始化面包屑功能：替换第一个面包屑项为"默认画布"
     */
    const initBreadcrumbCustomization = () => {
      const breadcrumbItem = getBreadcrumbItem();
      if (!breadcrumbItem) {
        return false;
      }

      // 检查是否已经添加过，避免重复添加
      if (breadcrumbItem.querySelector(".bizy-default-canvas-label")) {
        return true;
      }

      // 获取原有的面包屑链接元素
      const breadcrumbLink = breadcrumbItem.querySelector(
        ".p-breadcrumb-item-link"
      );
      if (!breadcrumbLink) {
        return false;
      }

      // 创建"默认画布"标签元素
      const defaultCanvasLabel = document.createElement("span");
      defaultCanvasLabel.className = "bizy-default-canvas-label";
      defaultCanvasLabel.textContent = "默认画布";
      defaultCanvasLabel.style.cssText =
        "padding: 0 8px; display: flex; align-items: center; height: 48px; color: var(--text-primary, inherit); cursor: pointer;";

      // 添加点击事件：切换到根图并触发原元素事件
      defaultCanvasLabel.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();

        // 切换到根图（默认画布）
        if (app.canvas && app.canvas.graph) {
          try {
            const rootGraph = app.canvas.graph.rootGraph;
            if (rootGraph) {
              app.canvas.setGraph(rootGraph);
            }
          } catch (error) {
            console.warn("Failed to switch to root graph:", error);
          }
        }

        // 触发原面包屑链接元素的事件
        const clickEvent = new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window,
          detail: e.detail,
          button: e.button,
          buttons: e.buttons,
          clientX: e.clientX,
          clientY: e.clientY,
          ctrlKey: e.ctrlKey,
          shiftKey: e.shiftKey,
          altKey: e.altKey,
          metaKey: e.metaKey,
        });
        breadcrumbLink.dispatchEvent(clickEvent);
      });

      // 添加鼠标悬停效果
      defaultCanvasLabel.addEventListener("mouseenter", () => {
        defaultCanvasLabel.style.backgroundColor = "rgba(255, 255, 255, 0.1)";
      });
      defaultCanvasLabel.addEventListener("mouseleave", () => {
        defaultCanvasLabel.style.backgroundColor = "transparent";
      });

      // 添加新元素并隐藏原元素
      breadcrumbItem.appendChild(defaultCanvasLabel);
      breadcrumbLink.style.display = "none";

      return true;
    };

    /**
     * 使用定时器等待并初始化面包屑功能
     */
    const waitAndInitBreadcrumb = (maxAttempts = 10, interval = 300) => {
      let attemptCount = 0;
      const timer = setInterval(() => {
        attemptCount++;
        if (attemptCount > maxAttempts) {
          clearInterval(timer);
          return;
        }
        if (initBreadcrumbCustomization()) {
          clearInterval(timer);
        }
      }, interval);
      return timer;
    };

    let indexCloseLayout = 0;
    let indexAddSmlBar = 0;
    let indexFengrossment = 0;
    let iTimer = setInterval(() => {
      indexCloseLayout++;
      if (indexCloseLayout > 10) {
        clearInterval(iTimer);
        return;
      }
      if (getCloseBtn()) {
        getCloseBtn().click();
        clearInterval(iTimer);
      }
    }, 300);
    let iTimerSmlBar = setInterval(() => {
      indexAddSmlBar++;
      if (indexAddSmlBar > 10) {
        clearInterval(iTimerSmlBar);
        return;
      }
      if (document.querySelector(".side-tool-bar-container")) {
        document
          .querySelector(".side-tool-bar-container")
          .classList.add("small-sidebar");
        clearInterval(iTimerSmlBar);
      }
    }, 300);
    let iTimerFengrossment = setInterval(() => {
      indexFengrossment++;
      if (indexFengrossment > 10) {
        clearInterval(iTimerFengrossment);
        return;
      }
      if (getFengrossmentBtn()) {
        getFengrossmentBtn().style.display = "none";
        clearInterval(iTimerFengrossment);
      }
    }, 300);
    // 初始化面包屑功能
    waitAndInitBreadcrumb();

    // 隐藏"转换为子工作流"菜单项
    const hideSubworkflowMenuItem = () => {
      // 方法1: 查找所有包含"转换为子工作流"的元素
      const allElements = document.querySelectorAll("*");
      allElements.forEach((element) => {
        // 检查直接文本内容
        if (element.childNodes.length > 0) {
          element.childNodes.forEach((node) => {
            if (
              node.nodeType === 3 &&
              node.textContent.includes("转换为子工作流")
            ) {
              // 隐藏包含此文本的最近父元素（菜单项）
              let parent = element;
              while (
                parent &&
                !parent.classList.contains("p-menu-item") &&
                !parent.classList.contains("litemenu-entry")
              ) {
                parent = parent.parentElement;
              }
              if (parent) {
                parent.style.display = "none";
              }
            }
          });
        }

        // 检查元素的直接文本内容
        const text = element.textContent;
        if (
          text &&
          text.trim() === "转换为子工作流" &&
          element.tagName !== "STYLE" &&
          element.tagName !== "SCRIPT"
        ) {
          // 找到最近的菜单项元素
          let menuItem = element.closest(
            '[class*="menu-item"], [class*="litemenu"], [class*="submenu"]'
          );
          if (!menuItem) {
            menuItem = element.parentElement;
          }
          if (menuItem) {
            menuItem.style.display = "none";
          } else {
            element.style.display = "none";
          }
        }
      });
    };

    // 使用定时器和MutationObserver监听DOM变化
    let hideMenuAttempts = 0;
    const hideMenuTimer = setInterval(() => {
      hideMenuAttempts++;
      hideSubworkflowMenuItem();
      if (hideMenuAttempts > 50) {
        clearInterval(hideMenuTimer);
      }
    }, 200);

    // 使用MutationObserver持续监听菜单的动态添加
    const observer = new MutationObserver(() => {
      hideSubworkflowMenuItem();
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: false,
    });
  },
});
