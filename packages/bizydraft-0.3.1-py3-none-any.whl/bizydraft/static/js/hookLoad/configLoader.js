import { getCookie } from "../utils.js";
import { draftFetch } from "../utils/draftFetch.js";
// 统一的配置缓存
let fullConfigCache = null;
let configLoadPromise = null;
// AI模型节点配置缓存
export let aiModelConfigCache = null;
export let aiModelConfigLoadPromise = null;
// 节点配置缓存
export let nodeConfigCache = null;
let nodeConfigLoadPromise = null;

// API配置（统一使用一个域名，根据实际需要调整）
const CONFIG_API_URL =
  "https://storage.bizyair.cn/config/comfyagent_node_config.json?t=" +
  Math.floor(Date.now() / 60000);

// 获取完整配置的API函数（返回包含 weight_load_nodes 和 media_load_nodes 的完整对象）
export async function fetchFullConfig() {
  if (fullConfigCache) {
    return fullConfigCache;
  }

  if (configLoadPromise) {
    return configLoadPromise;
  }

  configLoadPromise = (async () => {
    try {
      // 检查Cookie中是否有自定义配置URL
      const customConfigUrl = getCookie("config_url");
      const finalUrl = customConfigUrl || CONFIG_API_URL;

      console.log("正在从API获取完整节点配置...", finalUrl);
      const result = await draftFetch(finalUrl);
      const configData =
        result?.code === 20000 && result?.data ? result.data : result;
      if (configData) {
        fullConfigCache = {
          weight_load_nodes: configData.weight_load_nodes || {},
          media_load_nodes: configData.media_load_nodes || {},
          ai_model_nodes: configData.ai_model_nodes || {},
        };
        console.log("完整配置加载成功:", {
          weight_nodes: Object.keys(fullConfigCache.weight_load_nodes).length,
          media_nodes: Object.keys(fullConfigCache.media_load_nodes).length,
          ai_model_nodes: Object.keys(fullConfigCache.ai_model_nodes).length,
        });
        return fullConfigCache;
      } else {
        throw new Error("API返回数据格式不正确");
      }
    } catch (error) {
      console.error("获取完整配置失败:", error);
      fullConfigCache = null;
      return null;
    }
  })();

  return configLoadPromise;
}

// 获取模型节点配置（从完整配置中提取 weight_load_nodes）
export async function fetchNodeConfig() {
  const fullConfig = await fetchFullConfig();
  return fullConfig ? fullConfig.weight_load_nodes : null;
}

// 获取节点配置的API函数（带缓存）
export async function fetchNodeConfigWithCache() {
  if (nodeConfigCache) {
    return nodeConfigCache;
  }

  if (nodeConfigLoadPromise) {
    return nodeConfigLoadPromise;
  }

  nodeConfigLoadPromise = (async () => {
    const config = await fetchNodeConfig();
    if (config) {
      nodeConfigCache = config;
      console.log(
        "节点配置加载成功:",
        Object.keys(nodeConfigCache).length,
        "个节点"
      );
    }
    return config;
  })();

  return nodeConfigLoadPromise;
}

// 获取媒体节点配置（从完整配置中提取 media_load_nodes）
export async function fetchMediaConfig() {
  const fullConfig = await fetchFullConfig();
  return fullConfig ? fullConfig.media_load_nodes : null;
}
// 获取AI模型节点配置
export async function fetchAiModelConfig() {
  if (aiModelConfigCache) {
    return aiModelConfigCache;
  }

  if (aiModelConfigLoadPromise) {
    return aiModelConfigLoadPromise;
  }

  aiModelConfigLoadPromise = (async () => {
    const fullConfig = await fetchFullConfig();
    const config = fullConfig ? fullConfig.ai_model_nodes : null;
    if (config) {
      aiModelConfigCache = config;
    }
    return config;
  })();

  return aiModelConfigLoadPromise;
}

/**
 * 统一的配置加载检查函数
 * 封装"触发加载 + 检查缓存"的重复逻辑
 * @param {string} configType - 配置类型: 'aiModel' | 'node'
 * @param {string} nodeName - 节点名称（可选，用于检查特定节点是否在缓存中）
 * @returns {boolean} 如果配置已加载且节点在缓存中（如果提供了nodeName），返回true
 */
export function ensureConfigLoaded(configType, nodeName = null) {
  try {
    if (configType === "aiModel") {
      // 触发AI模型配置加载
      void fetchAiModelConfig();

      // 如果提供了节点名，检查是否在缓存中
      if (nodeName && aiModelConfigCache && aiModelConfigCache[nodeName]) {
        return true;
      } else {
        return false;
      }
    } else if (configType === "node") {
      // 触发节点配置加载
      void fetchNodeConfigWithCache();

      // 如果提供了节点名，检查是否在缓存中
      if (
        nodeName &&
        nodeConfigCache &&
        nodeConfigCache[nodeName] &&
        nodeConfigCache[nodeName].inputs
      ) {
        return true;
      } else {
        return false;
      }
    }
  } catch (e) {
    // 静默处理错误
  }
  return false;
}

// 启动时后台预取（不阻塞后续逻辑）
try {
  void fetchFullConfig();
  void fetchAiModelConfig();
  void fetchNodeConfigWithCache();
} catch (e) {
  /* noop */
}
