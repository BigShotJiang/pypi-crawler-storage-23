Installation
============

To use AttiPy, first install it using pip:

.. code-block:: console

   $ pip install attipy
