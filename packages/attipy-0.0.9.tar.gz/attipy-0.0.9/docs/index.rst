AttiPy documentation
====================

AttiPy is a lightweight Python library for representing and estimating the attitude
(orientation) and linear motion of a moving body using IMU measurements with optional
external aiding. It includes a multiplicative extended Kalman filter (MEKF) for position,
velocity, and attitude (PVA) estimation, and a clean, explicit attitude abstraction
with well-defined reference frames and rotation conventions.

.. toctree::
   :hidden:
   :maxdepth: 2

   installation
