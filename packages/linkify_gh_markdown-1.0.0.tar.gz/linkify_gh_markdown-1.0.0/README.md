# Linkify GitHub Markdown

<p align="center">
  <a href="https://github.com/browniebroke/linkify-gh-markdown/actions/workflows/ci.yml?query=branch%3Amain">
    <img src="https://img.shields.io/github/actions/workflow/status/browniebroke/linkify-gh-markdown/ci.yml?branch=main&label=CI&logo=github&style=flat-square" alt="CI Status" >
  </a>
  <a href="https://codecov.io/gh/browniebroke/linkify-gh-markdown">
    <img src="https://img.shields.io/codecov/c/github/browniebroke/linkify-gh-markdown.svg?logo=codecov&logoColor=fff&style=flat-square" alt="Test coverage percentage">
  </a>
</p>
<p align="center">
  <a href="https://github.com/astral-sh/uv">
    <img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json" alt="uv">
  </a>
  <a href="https://github.com/astral-sh/ruff">
    <img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json" alt="Ruff">
  </a>
  <a href="https://github.com/pre-commit/pre-commit">
    <img src="https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white&style=flat-square" alt="pre-commit">
  </a>
</p>
<p align="center">
  <a href="https://pypi.org/project/linkify-gh-markdown/">
    <img src="https://img.shields.io/pypi/v/linkify-gh-markdown.svg?logo=python&logoColor=fff&style=flat-square" alt="PyPI Version">
  </a>
  <img src="https://img.shields.io/pypi/pyversions/linkify-gh-markdown.svg?style=flat-square&logo=python&amp;logoColor=fff" alt="Supported Python versions">
  <img src="https://img.shields.io/pypi/l/linkify-gh-markdown.svg?style=flat-square" alt="License">
</p>

---

**Source Code**: <a href="https://github.com/browniebroke/linkify-gh-markdown" target="_blank">https://github.com/browniebroke/linkify-gh-markdown </a>

---

Turn URLs and handles in GitHub markdown into actual links to GitHub issues, pull requests or user profiles.

## Installation

Install this via pip (or your favourite package manager):

`pip install linkify-gh-markdown`

## Usage

This tool processes a markdown file and converts plain text GitHub references into proper markdown links:

- `@username` mentions become `[@username](https://github.com/username)`
- Pull request URLs like `https://github.com/owner/repo/pull/123` become `[#123](https://github.com/owner/repo/pull/123)`

The result is printed to stdout.

```bash
linkify-gh-markdown path/to/file.md
```

```
 Usage: linkify-gh-markdown [OPTIONS] INPUT_PATH

 Add the arguments and print the result.

╭─ Arguments ─────────────────────────────────────────────────────╮
│ *    input_path      TEXT  [required]                           │
╰─────────────────────────────────────────────────────────────────╯
╭─ Options ───────────────────────────────────────────────────────╮
│ --install-completion    Install completion for the current      │
│                         shell.                                  │
│ --show-completion       Show completion for the current shell,  │
│                         to copy it or customize the             │
│                         installation.                           │
│ --help                  Show this message and exit.             │
╰─────────────────────────────────────────────────────────────────╯
```

## Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- prettier-ignore-start -->
<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tbody>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://browniebroke.com/"><img src="https://avatars.githubusercontent.com/u/861044?v=4?s=80" width="80px;" alt="Bruno Alla"/><br /><sub><b>Bruno Alla</b></sub></a><br /><a href="https://github.com/browniebroke/linkify-gh-markdown/commits?author=browniebroke" title="Code">💻</a> <a href="#ideas-browniebroke" title="Ideas, Planning, & Feedback">🤔</a> <a href="https://github.com/browniebroke/linkify-gh-markdown/commits?author=browniebroke" title="Documentation">📖</a></td>
    </tr>
  </tbody>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->
<!-- prettier-ignore-end -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!

## Credits

[![Copier](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/copier-org/copier/master/img/badge/badge-grayscale-inverted-border-orange.json)](https://github.com/copier-org/copier)

This package was created with
[Copier](https://copier.readthedocs.io/) and the
[browniebroke/pypackage-template](https://github.com/browniebroke/pypackage-template)
project template.
