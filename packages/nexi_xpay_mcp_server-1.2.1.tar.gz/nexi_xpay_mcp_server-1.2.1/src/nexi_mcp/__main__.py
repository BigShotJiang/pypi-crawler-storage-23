from nexi_mcp.server import main

main()
