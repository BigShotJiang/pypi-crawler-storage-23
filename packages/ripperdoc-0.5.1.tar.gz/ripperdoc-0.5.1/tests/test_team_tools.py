"""Tests for team persistence and team/task integration."""

from __future__ import annotations

import asyncio
import json

import pytest

from ripperdoc.core.tool import ToolUseContext
from ripperdoc.tools.task_graph_tool import TaskCreateInput, TaskCreateTool, TaskUpdateInput, TaskUpdateTool
from ripperdoc.tools.team_tool import (
    SendMessageInput,
    SendMessageTool,
    TeamCreateInput,
    TeamCreateTool,
    TeamDeleteInput,
    TeamDeleteTool,
)
from ripperdoc.utils.messaging.pending_messages import PendingMessageQueue
from ripperdoc.utils.collaboration.teams import (
    TeamMember,
    clear_active_team_name,
    create_team,
    list_team_messages,
    register_team_message_listener,
    send_team_message,
    team_config_path,
    unregister_team_message_listener,
    upsert_team_member,
)


def test_team_tools_create_and_send_message(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    send_tool = SendMessageTool()
    context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        created = None
        async for output in create_tool.call(
            TeamCreateInput(
                team_name="alpha",
                description="auth refactor",
                agent_type="general-purpose",
            ),
            context,
        ):
            created = output

        assert created is not None
        assert created.data.team_name == "alpha"
        assert created.data.lead_agent_id == "team-lead@alpha"
        upsert_team_member(
            "alpha",
            TeamMember(name="dev-a", agent_type="general-purpose", active=True),
        )

        sent = None
        async for output in send_tool.call(
            SendMessageInput(
                type="message",
                recipient="dev-a",
                content="Please pick task 1",
                summary="Please pick up task one now",
            ),
            context,
        ):
            sent = output

        assert sent is not None
        assert sent.data.success is True
        assert sent.data.routing is not None
        assert sent.data.routing.target == "@dev-a"

    asyncio.run(_run())

    messages = list_team_messages("alpha", limit=10)
    assert messages
    assert messages[-1].message_type == "message"


def test_task_update_owner_emits_assignment_message(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    team_create = TeamCreateTool()
    task_create = TaskCreateTool()
    task_update = TaskUpdateTool()
    context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        async for _ in team_create.call(
            TeamCreateInput(team_name="alpha", description="demo"),
            context,
        ):
            pass

        created = None
        async for output in task_create.call(
            TaskCreateInput(subject="do work", description="implement feature"),
            context,
        ):
            created = output

        assert created is not None
        assert created.data.task is not None
        task_id = created.data.task.id

        async for _ in task_update.call(
            TaskUpdateInput(task_id=task_id, owner="dev-a"),
            context,
        ):
            pass

    asyncio.run(_run())

    messages = list_team_messages("alpha", limit=20)
    assignment_messages = [msg for msg in messages if msg.message_type == "task_assignment"]
    assert assignment_messages
    assert assignment_messages[-1].recipients == ["dev-a"]


def test_send_message_summary_validation():
    send_tool = SendMessageTool()

    async def _run() -> None:
        valid_message = await send_tool.validate_input(
            SendMessageInput(
                type="message",
                recipient="dev-a",
                content="Please investigate auth failures.",
                summary="Please investigate auth regression failures first",
            )
        )
        assert valid_message.result is True

        short_summary_message = await send_tool.validate_input(
            SendMessageInput(
                type="message",
                recipient="dev-a",
                content="Please investigate auth failures.",
                summary="auth regression fix now",
            )
        )
        assert short_summary_message.result is True

        missing_summary = await send_tool.validate_input(
            SendMessageInput(
                type="broadcast",
                content="Pause all commits while we fix build.",
            )
        )
        assert missing_summary.result is False
        assert "summary is required" in (missing_summary.message or "")

    asyncio.run(_run())


def test_team_create_allows_new_team_when_only_singleton_team_exists(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("RIPPERDOC_TEAM_NAME", raising=False)

    create_tool = TeamCreateTool()

    async def _run() -> None:
        context_a = ToolUseContext(agent_id="lead-a")
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), context_a):
            pass

        clear_active_team_name("alpha")

        created = None
        context_b = ToolUseContext(agent_id="lead-b")
        async for output in create_tool.call(TeamCreateInput(team_name="beta"), context_b):
            created = output

        assert created is not None
        assert created.data.team_name == "beta"

    asyncio.run(_run())


def test_team_delete_requires_no_active_members(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    delete_tool = TeamDeleteTool()
    context = ToolUseContext(agent_id="team-lead")
    monkeypatch.setattr(
        "ripperdoc.tools.task_tool.list_running_team_members",
        lambda _team_name=None: ["dev-a"],
    )

    async def _run() -> None:
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), context):
            pass

        upsert_team_member(
            "alpha",
            TeamMember(name="dev-a", agent_type="general-purpose", active=True),
        )

        failed = None
        async for output in delete_tool.call(TeamDeleteInput(), context):
            failed = output

        assert failed is not None
        assert failed.data.success is False
        assert "active member" in failed.data.message

        upsert_team_member(
            "alpha",
            TeamMember(name="dev-a", agent_type="general-purpose", active=False),
        )

        deleted = None
        async for output in delete_tool.call(TeamDeleteInput(), context):
            deleted = output

        assert deleted is not None
        assert deleted.data.success is True

    asyncio.run(_run())


def test_team_tool_descriptions_and_examples():
    async def _run() -> None:
        create_tool = TeamCreateTool()
        send_tool = SendMessageTool()

        create_desc = await create_tool.description()
        send_desc = await send_tool.description()

        assert "team" in create_desc.lower()
        assert "message" in send_desc.lower() or "protocol" in send_desc.lower()
        assert len(create_tool.input_examples()) > 0
        assert len(send_tool.input_examples()) > 0

    asyncio.run(_run())


def test_send_team_message_live_listener_delivery(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_team(name="alpha")
    queue = PendingMessageQueue()
    register_team_message_listener("alpha", "dev-a", queue)
    try:
        send_team_message(
            team_name="alpha",
            sender="team-lead",
            recipients=["dev-a"],
            message_type="message",
            content="Please pick task 1",
            metadata={"summary": "Please pick up task one now"},
        )
    finally:
        unregister_team_message_listener("alpha", "dev-a", queue)

    drained = queue.drain()
    assert drained
    first = drained[0]
    assert getattr(first, "type", "") == "user"
    assert "Please pick task 1" in str(getattr(first.message, "content", ""))


def test_send_shutdown_request_writes_structured_payload(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    send_tool = SendMessageTool()
    context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), context):
            pass
        upsert_team_member(
            "alpha",
            TeamMember(name="dev-a", agent_type="general-purpose", active=True),
        )
        async for _ in send_tool.call(
            SendMessageInput(
                type="shutdown_request",
                recipient="dev-a",
                content="Task complete, please shut down",
            ),
            context,
        ):
            pass

    asyncio.run(_run())

    messages = list_team_messages("alpha", limit=10)
    assert messages
    payload = json.loads(messages[-1].content)
    assert payload.get("type") == "shutdown_request"
    assert payload.get("requestId")
    assert payload.get("from") == "team-lead"
    assert payload.get("reason") == "Task complete, please shut down"


def test_send_shutdown_response_uses_shutdown_approved_payload(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    send_tool = SendMessageTool()
    lead_context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), lead_context):
            pass
        upsert_team_member(
            "alpha",
            TeamMember(
                name="dev-a",
                agent_id="dev-a@alpha",
                agent_type="general-purpose",
                backend_type="in-process",
                active=True,
            ),
        )
        teammate_context = ToolUseContext(agent_id="dev-a", team_name="alpha", teammate_name="dev-a")
        async for _ in send_tool.call(
            SendMessageInput(
                type="shutdown_response",
                request_id="req_123",
                approve=True,
            ),
            teammate_context,
        ):
            pass

    asyncio.run(_run())

    messages = list_team_messages("alpha", limit=10)
    assert messages
    payload = json.loads(messages[-1].content)
    assert payload.get("type") == "shutdown_approved"
    assert payload.get("requestId") == "req_123"
    assert payload.get("from") == "dev-a"
    assert payload.get("backendType") == "in-process"


def test_send_shutdown_response_uses_shutdown_rejected_payload(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    send_tool = SendMessageTool()
    lead_context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), lead_context):
            pass
        upsert_team_member(
            "alpha",
            TeamMember(name="dev-a", agent_id="dev-a@alpha", agent_type="general-purpose", active=True),
        )
        teammate_context = ToolUseContext(agent_id="dev-a", team_name="alpha", teammate_name="dev-a")
        async for _ in send_tool.call(
            SendMessageInput(
                type="shutdown_response",
                request_id="req_456",
                approve=False,
                content="Still working",
            ),
            teammate_context,
        ):
            pass

    asyncio.run(_run())

    messages = list_team_messages("alpha", limit=10)
    assert messages
    payload = json.loads(messages[-1].content)
    assert payload.get("type") == "shutdown_rejected"
    assert payload.get("requestId") == "req_456"
    assert payload.get("from") == "dev-a"
    assert payload.get("reason") == "Still working"


def test_send_plan_approval_response_uses_protocol_payload(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    send_tool = SendMessageTool()
    context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), context):
            pass
        upsert_team_member(
            "alpha",
            TeamMember(name="dev-a", agent_id="dev-a@alpha", agent_type="general-purpose", active=True),
        )
        async for _ in send_tool.call(
            SendMessageInput(
                type="plan_approval_response",
                request_id="req_plan_1",
                recipient="dev-a",
                approve=True,
            ),
            context,
        ):
            pass

    asyncio.run(_run())

    messages = list_team_messages("alpha", limit=10)
    assert messages
    payload = json.loads(messages[-1].content)
    assert payload.get("type") == "plan_approval_response"
    assert payload.get("requestId") == "req_plan_1"
    assert payload.get("approved") is True
    assert payload.get("permissionMode") == "default"


def test_team_member_persistence_includes_extended_fields(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), context):
            pass

    asyncio.run(_run())

    config_payload = json.loads(team_config_path("alpha").read_text(encoding="utf-8"))
    members = config_payload.get("members") or []
    assert members
    lead = members[0]
    assert lead.get("agentId") == "team-lead@alpha"
    assert lead.get("backendType") == "in-process"
    assert lead.get("isActive") is True


def test_send_message_recipient_alias_resolution(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    send_tool = SendMessageTool()
    context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), context):
            pass
        upsert_team_member(
            "alpha",
            TeamMember(name="agent-a", agent_type="general-purpose", active=True),
        )
        async for _ in send_tool.call(
            SendMessageInput(
                type="message",
                recipient="AGENT-A@alpha",
                content="Please pick task 3",
                summary="Quick check",
            ),
            context,
        ):
            pass

    asyncio.run(_run())

    messages = list_team_messages("alpha", limit=10)
    assert messages
    assert messages[-1].recipients == ["agent-a"]


def test_send_message_rejects_unknown_recipient(tmp_path, monkeypatch):
    monkeypatch.setattr("ripperdoc.utils.collaboration.tasks.Path.home", lambda: tmp_path)
    monkeypatch.setattr("ripperdoc.utils.collaboration.teams.Path.home", lambda: tmp_path)
    monkeypatch.chdir(tmp_path)

    create_tool = TeamCreateTool()
    send_tool = SendMessageTool()
    context = ToolUseContext(agent_id="team-lead")

    async def _run() -> None:
        async for _ in create_tool.call(TeamCreateInput(team_name="alpha"), context):
            pass
        async for _ in send_tool.call(
            SendMessageInput(
                type="message",
                recipient="ghost",
                content="test",
                summary="test",
            ),
            context,
        ):
            pass

    with pytest.raises(ValueError, match="Unknown recipient"):
        asyncio.run(_run())
