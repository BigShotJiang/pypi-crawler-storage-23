"""Core timing primitives: Timer and Collector."""
from .timer import Timer, TimingRecord
from .collector import Collector, default_collector
