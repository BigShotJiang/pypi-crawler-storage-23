"""Provider abstraction layer for agent-budget-guard."""
