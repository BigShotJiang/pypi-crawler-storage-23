## Summary

## Changes
-

## Test plan
- [ ] `uv run pytest tests/ -m unit`
- [ ] `uv run pre-commit run --all-files`
- [ ] `uv run mypy src/ --strict`

## Related issues
Closes #
