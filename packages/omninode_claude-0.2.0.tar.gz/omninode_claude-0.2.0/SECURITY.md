# Security Policy

## Reporting a Vulnerability

Do not report security vulnerabilities via public GitHub issues.

Email **contact@omninode.ai** with:
- Description of the vulnerability
- Steps to reproduce
- Potential impact

We will respond within 5 business days.
