#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT

"""
Log Agent Action Skill - Unified Event Adapter Version

Publishes agent actions using the unified HookEventAdapter.

Usage:
  /log-agent-action --agent AGENT_NAME --action-type TYPE --action-name NAME --details JSON

Options:
  --agent: Agent name performing the action (required)
  --action-type: Type of action (tool_call|decision|error|success) (required)
  --action-name: Specific action name (required)
  --details: JSON object with action-specific details (optional)
  --correlation-id: Correlation ID for tracking (optional, auto-generated)
  --duration-ms: How long the action took in milliseconds (optional)
  --success: Whether action succeeded (default: true)

Project context (optional):
  --project-path: Absolute path to project directory (optional)
  --project-name: Project name (optional)
  --working-directory: Current working directory (optional)
"""

import argparse
import json
import sys
from enum import Enum
from pathlib import Path

# Add claude/hooks/lib to path (4 parents from claude/skills/agent-tracking/log-agent-action/)
# Path: execute_unified.py -> log-agent-action -> agent-tracking -> skills -> claude -> hooks/lib
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "hooks" / "lib"))
from hook_event_adapter import get_hook_event_adapter

# Add _shared to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "_shared"))
from db_helper import get_correlation_id, parse_json_param


class ActionType(str, Enum):
    """Action types for agent actions."""

    TOOL_CALL = "tool_call"
    DECISION = "decision"
    ERROR = "error"
    SUCCESS = "success"


def main():
    parser = argparse.ArgumentParser(
        description="Log agent action via unified event adapter",
    )

    # Required arguments
    parser.add_argument("--agent", required=True, help="Agent name")
    parser.add_argument(
        "--action-type",
        required=True,
        choices=[at.value for at in ActionType],
        help="Action type (tool_call, decision, error, success)",
    )
    parser.add_argument("--action-name", required=True, help="Action name")

    # Optional arguments
    parser.add_argument("--details", help="JSON object with details")
    parser.add_argument("--correlation-id", help="Correlation ID")
    parser.add_argument("--duration-ms", type=int, help="Duration in milliseconds")
    parser.add_argument(
        "--success",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Success flag (use --no-success to set False)",
    )

    # Project context arguments
    parser.add_argument("--project-path", help="Absolute path to project directory")
    parser.add_argument("--project-name", help="Project name")
    parser.add_argument("--working-directory", help="Current working directory")

    args = parser.parse_args()

    # Get or generate correlation ID
    correlation_id = args.correlation_id or get_correlation_id()

    # Parse details
    action_details = parse_json_param(args.details) if args.details else {}

    # Get adapter and publish (argparse guarantees attributes exist, even if None)
    adapter = get_hook_event_adapter()
    success = adapter.publish_agent_action(
        agent_name=args.agent,
        action_type=args.action_type,
        action_name=args.action_name,
        correlation_id=correlation_id,
        action_details=action_details,
        duration_ms=args.duration_ms,
        success=args.success,
        project_path=args.project_path or None,
        project_name=args.project_name or None,
        working_directory=args.working_directory or None,
    )

    if success:
        print(
            json.dumps(
                {
                    "success": True,
                    "correlation_id": correlation_id,
                    "agent_name": args.agent,
                    "action_type": args.action_type,
                    "published_via": "unified_event_adapter",
                },
                indent=2,
            )
        )
        return 0
    else:
        print(
            json.dumps(
                {
                    "success": False,
                    "error": "Failed to publish agent action event",
                }
            ),
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
