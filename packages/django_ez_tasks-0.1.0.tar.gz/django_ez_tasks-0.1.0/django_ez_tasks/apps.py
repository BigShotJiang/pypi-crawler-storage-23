from django.apps import AppConfig


class DjangoEzTasksConfig(AppConfig):
    """
    Configuration class for the django_ez_tasks app.
    """

    default_auto_field = "django.db.models.BigAutoField"
    name = "django_ez_tasks"
    verbose_name = "Django EZ Tasks"
