"""
Django EZ Tasks

A reusable Django app providing simple background task execution with multiple backends.
Uses Django 6's BackgroundTask API and provides additional task backends for flexible execution.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__license__ = "MIT"

default_app_config = "django_ez_tasks.apps.DjangoEzTasksConfig"
