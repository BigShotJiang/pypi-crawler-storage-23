"""magic-spec: Specification-Driven Development (SDD) Workflow Installer."""
__version__ = "1.4.2"
