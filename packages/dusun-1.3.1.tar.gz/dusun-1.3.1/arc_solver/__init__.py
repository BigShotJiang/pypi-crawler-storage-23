"""ARC-AGI solver — three-phase architecture for grid transformation.

Architecture maps to three-phase actualization (AX2–AX4):
  İlim  (Distinguishing)  →  grid.py   — perception layer
  İrade (Specifying)       →  dsl.py + synthesis.py — program synthesis
  Kudret (Effecting)       →  solver.py — search / execution engine
"""

from .types import (
    BBox,
    Color,
    Grid,
    GridInfo,
    Object,
    Pair,
    PairClues,
    Point,
    Solution,
    Task,
    Transform,
)
from .solver import ArcSolver

__all__ = [
    "ArcSolver",
    "BBox",
    "Color",
    "Grid",
    "GridInfo",
    "Object",
    "Pair",
    "PairClues",
    "Point",
    "Solution",
    "Task",
    "Transform",
]
