"""
fw_server — MCP server bridge for the AGENTS.md framework engine.

Exposes the 7-lens analytical apparatus, bileshke composite engine,
kavaid constraints, inference chains, and Holographic Context Protocol
as MCP tools callable from VS Code Copilot via @dusun/fw-engine.

Usage:
    python -m fw_server.server   # start MCP stdio server

Public API (for direct Python use):
    from fw_server.adapters import run_lens, ADAPTER_MAP
    from fw_server.grade_map import score_to_grade, pass_ratio_to_grade
    from fw_server.server import mcp
"""

from fw_server.adapters import ADAPTER_MAP, run_lens
from fw_server.grade_map import (
    grade_to_string,
    pass_ratio_to_grade,
    score_to_grade,
)
from fw_server.types import LENS_IDS, VALID_GRADES

__all__ = [
    "ADAPTER_MAP",
    "run_lens",
    "score_to_grade",
    "pass_ratio_to_grade",
    "grade_to_string",
    "LENS_IDS",
    "VALID_GRADES",
]
