# Import basic logger components first to avoid circular imports
from ts_sdk_connectors_python.logger._base import CloudWatchLoggingAdapter, get_logger

# Other package-level exports
# Avoid importing anything here that might cause circular dependencies
#
# NOTE: Do NOT import SqlConnector or other connector classes here!
# They should be imported directly from their modules to avoid circular imports:
#   from ts_sdk_connectors_python.sql import SqlConnector
#
# Reason: SqlConnector → TdpApi → tdp_api_base → CloudWatchLoggingAdapter (from __init__)
# This creates a circular dependency that only works due to import order.

__all__ = [
    "CloudWatchLoggingAdapter",
    "get_logger",
    # Add other symbols to export at package level
    # Do NOT add connector classes here - import them from their modules instead
]
