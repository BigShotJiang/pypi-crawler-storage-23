from contextlib import asynccontextmanager, contextmanager
from typing import Any, AsyncIterator, Iterator, Optional, Union

import httpx
from httpx._client import UseClientDefault

from ts_sdk_connectors_python.logger import get_logger

logger = get_logger(__name__)


class ContentTypeMismatchException(Exception):
    """Base exception raised when response Content-Type doesn't match request Accept header."""

    def __init__(
        self,
        request_accept: Optional[str],
        url: str,
    ):
        self.request_accept = request_accept
        self.url = url
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        """Build the exception message. Subclasses should override this."""
        return f"Content-Type mismatch for {self.url}"


class AcceptMismatchException(ContentTypeMismatchException):
    """Exception raised when response Content-Type doesn't match any value in request Accept header."""

    def __init__(
        self,
        request_accept: Optional[str],
        response_content_type: str,
        url: str,
    ):
        self.response_content_type = response_content_type
        super().__init__(request_accept, url)

    def _build_message(self) -> str:
        return (
            f"Content-Type mismatch for {self.url}: "
            f"request Accept header='{self.request_accept}', "
            f"response Content-Type='{self.response_content_type}'"
        )


class NotAcceptableException(ContentTypeMismatchException):
    """Exception raised when server returns HTTP 406 Not Acceptable."""

    def __init__(
        self,
        request_accept: Optional[str],
        url: str,
        response_content_type: Optional[str] = None,
    ):
        self.response_content_type = response_content_type
        super().__init__(request_accept, url)

    def _build_message(self) -> str:
        message = (
            f"Server returned 406 Not Acceptable for {self.url}: "
            f"request Accept header='{self.request_accept}'"
        )
        if self.response_content_type:
            message += f", response Content-Type='{self.response_content_type}'"
        return message


def _extract_media_type(header_value: Optional[str]) -> Optional[str]:
    """
    Extract the base media type from a header value, ignoring parameters like charset.

    Examples:
        "application/json; charset=utf-8" -> "application/json"
        "text/html" -> "text/html"
    """
    if not header_value:
        return None

    # Split on semicolon to remove parameters like charset
    media_type = header_value.split(";")[0].strip().lower()
    return media_type if media_type else None


def _parse_accept_header(accept_header: Optional[str]) -> list[str]:
    """
    Parse Accept header into a list of media types.

    Examples:
        "application/json" -> ["application/json"]
        "application/json, text/html" -> ["application/json", "text/html"]
        "application/json; charset=utf-8, text/html" -> ["application/json", "text/html"]
    """
    if not accept_header:
        return []

    media_types = []
    # Split on comma to get individual media types
    for value in accept_header.split(","):
        # Extract media type (ignore quality parameters and other attributes)
        media_type = _extract_media_type(value)
        if media_type:
            media_types.append(media_type)

    return media_types


def _matches_accept(accept_media_type: str, response_content_type: str) -> bool:
    """
    Check if a response content-type matches an accept media type.

    Handles wildcards like */* or application/*.
    """
    if accept_media_type == "*/*":
        # Accept anything
        return True
    elif accept_media_type.endswith("/*"):
        # Accept any subtype of the main type (e.g., application/*)
        accept_main_type = accept_media_type.split("/")[0]
        response_main_type = response_content_type.split("/")[0]
        return accept_main_type == response_main_type
    else:
        # Exact match required
        return accept_media_type == response_content_type


def _log_response_text_if_mismatched(
    response: httpx.Response, max_bytes: int = 2048
) -> None:
    """
    Log the response text (or first max_bytes) for debugging purposes.

    Args:
        response: The HTTP response
        max_bytes: Maximum number of bytes to log (default: 2KB)

    Note:
        For streaming responses, we cannot read the response text without consuming
        the stream, so we only log headers.
    """
    try:
        # Check if this is a streaming response that hasn't been read yet
        # httpx.Response.is_stream_consumed is False for unread streaming responses
        if hasattr(response, "is_stream_consumed") and not response.is_stream_consumed:
            # This is a streaming response that hasn't been read yet
            # We can't read the text without consuming the stream
            logger.error(
                f"Response validation failed for {response.url} (streaming response, cannot preview content)",
                extra={
                    "status_code": response.status_code,
                    "response_headers": dict(response.headers),
                },
            )
        else:
            # Try to read response text for non-streaming or already-consumed responses
            response_text = response.text
            if len(response_text) > max_bytes:
                logged_text = response_text[:max_bytes] + "... (truncated)"
            else:
                logged_text = response_text

            logger.error(
                f"Response validation failed for {response.url}",
                extra={
                    "status_code": response.status_code,
                    "response_text_preview": logged_text,
                    "response_headers": dict(response.headers),
                },
            )
    except Exception as e:
        # If we can't read the response text, log what we can
        logger.error(
            f"Response validation failed for {response.url} (could not read response text: {e})",
            extra={
                "status_code": response.status_code,
                "response_headers": dict(response.headers),
            },
        )


def _validate_accept_content_type(
    request: httpx.Request, response: httpx.Response
) -> None:
    """
    Validate that response Content-Type matches at least one value in request Accept header.

    Raises NotAcceptableException if server returns 406.
    Raises AcceptMismatchException if there's a Content-Type mismatch.
    """
    accept_header = request.headers.get("accept")

    # Check for HTTP 406 Not Acceptable - server explicitly rejected the Accept header
    if response.status_code == 406:
        _log_response_text_if_mismatched(response)
        raise NotAcceptableException(
            request_accept=accept_header,
            url=str(request.url),
            response_content_type=_extract_media_type(
                response.headers.get("content-type")
            ),
        )

    response_content_type = _extract_media_type(response.headers.get("content-type"))

    # Only validate if both request Accept and response Content-Type headers exist
    if accept_header and response_content_type:
        # Parse all accepted media types
        accepted_types = _parse_accept_header(accept_header)

        if not accepted_types:
            # No valid accept types found, skip validation
            return

        # Check if response content-type matches any of the accepted types
        for accept_type in accepted_types:
            if _matches_accept(accept_type, response_content_type):
                # Found a match, validation passes
                return

        # No match found, raise exception
        _log_response_text_if_mismatched(response)
        raise AcceptMismatchException(
            request_accept=accept_header,
            response_content_type=response_content_type,
            url=str(request.url),
        )


class WrappedHttpxAsyncClient(httpx.AsyncClient):
    """
    Async HTTP client that validates response Content-Type matches request Accept header.

    This wrapper extends httpx.AsyncClient to add automatic validation that ensures
    the Content-Type of responses matches the Accept header of requests.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    async def request(
        self,
        method: str,
        url: Union[httpx.URL, str],
        *,
        content: Optional[httpx._types.RequestContent] = None,
        data: Optional[httpx._types.RequestData] = None,
        files: Optional[httpx._types.RequestFiles] = None,
        json: Optional[Any] = None,
        params: Optional[httpx._types.QueryParamTypes] = None,
        headers: Optional[httpx._types.HeaderTypes] = None,
        cookies: Optional[httpx._types.CookieTypes] = None,
        auth: Union[
            httpx._types.AuthTypes, UseClientDefault, None
        ] = httpx._client.USE_CLIENT_DEFAULT,
        follow_redirects: Union[
            bool, UseClientDefault
        ] = httpx._client.USE_CLIENT_DEFAULT,
        timeout: Union[
            httpx._types.TimeoutTypes, UseClientDefault
        ] = httpx._client.USE_CLIENT_DEFAULT,
        extensions: Optional[httpx._types.RequestExtensions] = None,
    ) -> httpx.Response:
        """
        Send an HTTP request with Accept/Content-Type validation.

        This method wraps the parent request method and adds validation to ensure
        the response Content-Type matches the request Accept header.
        """
        response = await super().request(
            method=method,
            url=url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            auth=auth,
            follow_redirects=follow_redirects,
            timeout=timeout,
            extensions=extensions,
        )

        _validate_accept_content_type(response.request, response)
        return response

    @asynccontextmanager
    async def stream(
        self,
        method: str,
        url: Union[httpx.URL, str],
        *,
        content: Optional[httpx._types.RequestContent] = None,
        data: Optional[httpx._types.RequestData] = None,
        files: Optional[httpx._types.RequestFiles] = None,
        json: Optional[Any] = None,
        params: Optional[httpx._types.QueryParamTypes] = None,
        headers: Optional[httpx._types.HeaderTypes] = None,
        cookies: Optional[httpx._types.CookieTypes] = None,
        auth: Union[
            httpx._types.AuthTypes, UseClientDefault, None
        ] = httpx._client.USE_CLIENT_DEFAULT,
        follow_redirects: Union[
            bool, UseClientDefault
        ] = httpx._client.USE_CLIENT_DEFAULT,
        timeout: Union[
            httpx._types.TimeoutTypes, UseClientDefault
        ] = httpx._client.USE_CLIENT_DEFAULT,
        extensions: Optional[httpx._types.RequestExtensions] = None,
    ) -> AsyncIterator[httpx.Response]:
        """
        Stream an HTTP request with Accept/Content-Type validation.

        This method wraps the parent stream method and adds validation to ensure
        the response Content-Type matches the request Accept header.
        """
        async with super().stream(
            method=method,
            url=url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            auth=auth,
            follow_redirects=follow_redirects,
            timeout=timeout,
            extensions=extensions,
        ) as response:
            _validate_accept_content_type(response.request, response)
            yield response


class WrappedHttpxClient(httpx.Client):
    """
    Synchronous HTTP client that validates response Content-Type matches request Accept header.

    This wrapper extends httpx.Client to add automatic validation that ensures
    the Content-Type of responses matches the Accept header of requests.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def request(
        self,
        method: str,
        url: Union[httpx.URL, str],
        *,
        content: Optional[httpx._types.RequestContent] = None,
        data: Optional[httpx._types.RequestData] = None,
        files: Optional[httpx._types.RequestFiles] = None,
        json: Optional[Any] = None,
        params: Optional[httpx._types.QueryParamTypes] = None,
        headers: Optional[httpx._types.HeaderTypes] = None,
        cookies: Optional[httpx._types.CookieTypes] = None,
        auth: Union[
            httpx._types.AuthTypes, UseClientDefault, None
        ] = httpx._client.USE_CLIENT_DEFAULT,
        follow_redirects: Union[
            bool, UseClientDefault
        ] = httpx._client.USE_CLIENT_DEFAULT,
        timeout: Union[
            httpx._types.TimeoutTypes, UseClientDefault
        ] = httpx._client.USE_CLIENT_DEFAULT,
        extensions: Optional[httpx._types.RequestExtensions] = None,
    ) -> httpx.Response:
        """
        Send an HTTP request with Accept/Content-Type validation.

        This method wraps the parent request method and adds validation to ensure
        the response Content-Type matches the request Accept header.
        """
        response = super().request(
            method=method,
            url=url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            auth=auth,
            follow_redirects=follow_redirects,
            timeout=timeout,
            extensions=extensions,
        )

        _validate_accept_content_type(response.request, response)
        return response

    @contextmanager
    def stream(
        self,
        method: str,
        url: Union[httpx.URL, str],
        *,
        content: Optional[httpx._types.RequestContent] = None,
        data: Optional[httpx._types.RequestData] = None,
        files: Optional[httpx._types.RequestFiles] = None,
        json: Optional[Any] = None,
        params: Optional[httpx._types.QueryParamTypes] = None,
        headers: Optional[httpx._types.HeaderTypes] = None,
        cookies: Optional[httpx._types.CookieTypes] = None,
        auth: Union[
            httpx._types.AuthTypes, UseClientDefault, None
        ] = httpx._client.USE_CLIENT_DEFAULT,
        follow_redirects: Union[
            bool, UseClientDefault
        ] = httpx._client.USE_CLIENT_DEFAULT,
        timeout: Union[
            httpx._types.TimeoutTypes, UseClientDefault
        ] = httpx._client.USE_CLIENT_DEFAULT,
        extensions: Optional[httpx._types.RequestExtensions] = None,
    ) -> Iterator[httpx.Response]:
        """
        Stream an HTTP request with Accept/Content-Type validation.

        This method wraps the parent stream method and adds validation to ensure
        the response Content-Type matches the request Accept header.
        """
        with super().stream(
            method=method,
            url=url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            auth=auth,
            follow_redirects=follow_redirects,
            timeout=timeout,
            extensions=extensions,
        ) as response:
            _validate_accept_content_type(response.request, response)
            yield response


__all__ = [
    "ContentTypeMismatchException",
    "AcceptMismatchException",
    "NotAcceptableException",
    "WrappedHttpxAsyncClient",
    "WrappedHttpxClient",
]
