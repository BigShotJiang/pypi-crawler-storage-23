"""
SQL Connector implementation using inheritance pattern.

This module provides the SqlConnector abstract base class that developers extend
to create SQL-based connectors. Developers implement three abstract methods to
provide database-specific logic, while the SDK handles connection pooling,
query execution, watermark persistence, and file upload.
"""

import asyncio
import json
import logging
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from uuid import uuid4

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_fixed,
)

from ts_sdk_connectors_python.connector import (
    Connector,
    ConnectorError,
    ConnectorOptions,
)
from ts_sdk_connectors_python.file_uploader import UploadFileRequest
from ts_sdk_connectors_python.models import OperatingStatus
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.connector_details_dto import (
    ConnectorDetailsDto,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.connector_file_dto_status import (
    ConnectorFileDtoStatus,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.save_connector_file_request import (
    SaveConnectorFileRequest,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.save_connector_file_request_metadata import (
    SaveConnectorFileRequestMetadata,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.update_connector_health_request import (
    UpdateConnectorHealthRequest,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.update_connector_health_request_status import (
    UpdateConnectorHealthRequestStatus,
)
from ts_sdk_connectors_python.tdp_api import TdpApi
from ts_sdk_connectors_python.utils import Poll

# Delay in seconds before restarting poll after stopping it
# This allows in-flight requests to complete gracefully
POLL_RESTART_DELAY_SEC = 2

# Exponential backoff configuration for file processing retries
# Backoff delay = min(BASE_BACKOFF_SECONDS * 2^(error_count-1), MAX_BACKOFF_SECONDS)
# Examples: 60s, 120s, 240s, 480s, 960s, 1920s, 3600s (capped)
BASE_BACKOFF_SECONDS = 60  # 1 minute
MAX_BACKOFF_SECONDS = 3600  # 1 hour

# Threshold for transitioning from WARNING to CRITICAL health status
# Below this threshold: WARNING (transient issue, retrying)
# At or above this threshold: CRITICAL (persistent issue, needs attention)
CRITICAL_ERROR_THRESHOLD = 5


class SqlConnector(Connector, ABC):
    """
    Abstract base class for SQL-based connectors using inheritance pattern.

    Developers extend this class and implement three abstract methods:
    - get_connection_string(): Return SQLAlchemy connection string
    - get_connector_query(watermark): Build SQL query with watermark logic
    - get_watermark(last_row): Extract watermark from query results

    The SDK handles:
    - Connection pooling with SQLAlchemy
    - Query execution
    - Watermark persistence
    - Polling mechanism
    - File upload to TDP

    Configuration Parameters (in connector_details.config):
    - polling_interval_minutes (int, optional): Polling interval in minutes.
      Default: 10
    - source_type (str, optional): Source type for uploaded files.
      Default: "sql_query_results"
    - initial_watermark (dict, optional): Initial watermark to use on first poll
      when no saved watermark exists. Useful for backfilling from a specific point.
      Default: None
      Example: {"created_date": "2024-01-01 00:00:00"}

    Implementation Note - Synchronous SQLAlchemy:
        This implementation uses synchronous SQLAlchemy with sync database drivers.
        While the connector methods are async, database operations (connect, execute)
        are synchronous and will block the event loop during query execution.

        Why sync instead of async?
        - Async drivers are not available for all databases (e.g., SQL Server with
          pyodbc, Oracle with cx_oracle)
        - Simpler developer experience with familiar sync drivers
        - For typical polling intervals (5-10 minutes), blocking impact is minimal
        - BYO (Bring Your Own) approach works with all existing sync drivers

        Trade-offs:
        - Event loop is blocked during query execution (typically 1-30 seconds)
        - Cannot handle concurrent operations during query execution
        - Not ideal async practice, but acceptable for polling use cases

        Future Enhancement:
        - A future version may use asyncio.to_thread() to run sync database
          operations in a thread pool, avoiding event loop blocking while
          maintaining compatibility with all database drivers.

    Example:
        ```python
        class PostgresConnector(SqlConnector):
            def get_connection_string(self) -> str:
                config = self.connector_details.config
                return f"postgresql://{config['user']}:{config['password']}@..."

            def get_connector_query(self, watermark: Optional[Dict]) -> str:
                if watermark:
                    return f"SELECT * FROM table WHERE id > {watermark['id']}"
                return "SELECT * FROM table LIMIT 1000"

            def get_watermark(self, last_row: Dict) -> Dict:
                return {"id": last_row["id"]}
        ```
    """

    def __init__(
        self,
        tdp_api: TdpApi,
        options: Optional[ConnectorOptions] = None,
    ):
        super().__init__(tdp_api=tdp_api, options=options)
        self.poll: Optional[Poll] = None
        self.engine: Optional[Engine] = None
        self.watermark: Optional[Dict[str, Any]] = None

    @abstractmethod
    def get_connection_string(self) -> str:
        """
        Return SQLAlchemy connection string for the database.

        This method must be implemented by subclasses to provide the database
        connection string. The connection string format depends on the database
        type and driver. This is a BYO (Bring Your Own) approach - developers
        must ensure the appropriate database driver is installed.

        Common formats:
        - PostgreSQL: "postgresql://user:password@localhost:5432/dbname"
        - PostgreSQL (psycopg2): "postgresql+psycopg2://user:password@localhost:5432/dbname"
        - MySQL: "mysql+pymysql://user:password@localhost:3306/dbname"
        - SQL Server: "mssql+pyodbc://user:password@localhost:1433/dbname?driver=ODBC+Driver+17+for+SQL+Server"
        - Oracle: "oracle+cx_oracle://user:password@localhost:1521/dbname"
        - SQLite: "sqlite:///path/to/database.db"

        You can access connector configuration via self.connector_details.config

        Returns:
            SQLAlchemy connection string

        Raises:
            ValueError: If required configuration is missing

        Example:
            ```python
            def get_connection_string(self) -> str:
                config = self.connector_details.config
                return (
                    f"postgresql+psycopg2://"
                    f"{config['username']}:{config['password']}"
                    f"@{config['server']}:{config['port']}"
                    f"/{config['database']}"
                )
            ```
        """

    @abstractmethod
    def get_connector_query(self, watermark: Optional[Dict[str, Any]]) -> str:
        """
        Build SQL query with watermark logic for incremental data retrieval.

        This method is called during each polling interval to construct the SQL
        query. The query should use the watermark to retrieve only new or updated
        data since the last poll.

        Best practices:
        - Consider adding LIMIT/FETCH FIRST to avoid retrieving too much data
        - Handle the case where watermark is None (initial poll)

        Security considerations:
        - Watermark values come from get_watermark() which extracts data from
          query results, so they originate from the database itself
        - Validate watermark values match expected types (datetime, int, etc.)
        - Consider using SQLAlchemy's literal() for values if needed
        - Avoid incorporating untrusted external input into queries

        Args:
            watermark: Dictionary containing watermark values from previous poll.
                      None on the first poll or if no previous watermark exists.
                      Example: {"created_date": "2023-10-31 10:00:00", "id": 12345}

        Returns:
            SQL query string with watermark conditions

        Example:
            ```python
            def get_connector_query(self, watermark: Optional[Dict]) -> str:
                if watermark and "created_date" in watermark:
                    # Watermark values come from database, but validate type
                    created_date = watermark['created_date']
                    if not isinstance(created_date, (str, datetime)):
                        raise ValueError(f"Invalid watermark type: {type(created_date)}")

                    return f'''
                        SELECT * FROM assay_results
                        WHERE created_date >= '{created_date}'
                        ORDER BY created_date ASC
                        LIMIT 1000
                    '''
                else:
                    return '''
                        SELECT * FROM assay_results
                        ORDER BY created_date ASC
                        LIMIT 1000
                    '''
            ```
        """

    @abstractmethod
    def get_watermark(self, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Extract watermark from query results.

        The watermark represents the position in the dataset for the next poll.
        You have full flexibility in implementing your watermark strategy.
        The SDK provides all rows from the query results, allowing you to:
        - Use the last row: `rows[-1]["id"]`
        - Find max value: `max(row["ts"] for row in rows)`
        - Count rows: `len(rows)`
        - Any other aggregation or logic

        Two constraints:
        1. The watermark must be derivable from the query results alone. You
           cannot make additional database queries to determine the watermark.
           You may use constants, configuration, or computed values from the
           row data.
        2. The watermark must be JSON-serializable (passed through json.dumps).
           Convert datetime objects to strings (e.g., using isoformat()).

        Examples:
        - ID-based (last row):
            `return {"id": rows[-1]["id"]}`
        - Timestamp-based (last row, convert datetime to string):
            `return {"modified_at": rows[-1]["modified_at"].isoformat()}`
        - Max timestamp across all rows:
            `return {"max_ts": max(row["ts"].isoformat() for row in rows)}`
        - Composite (last row):
            `return {"ts": rows[-1]["ts"].isoformat(), "id": rows[-1]["id"]}`

        Args:
            rows: List of dictionaries representing all rows from query results.

        Returns:
            Dictionary containing watermark values (must be JSON-serializable).
        """

    async def on_initialized(self):
        """
        Connector fully initialized.

        Note: Database engine creation is deferred to on_start() to avoid a race
        condition. The engine is only needed when the connector is RUNNING, and
        creating it in on_start() ensures proper lifecycle management.
        """
        await super().on_initialized()

    def _create_engine(self) -> Engine:
        """
        Create SQLAlchemy engine with connection pooling and timeout configuration.

        The engine is configured to keep connections alive between poll cycles for efficiency.
        For SQLite, uses SingletonThreadPool (one connection per thread, reused across polls).
        For production databases, uses QueuePool with pool_size=1 (sequential execution).

        Connection pooling prevents expensive reconnection overhead on each poll cycle.
        For example, PostgreSQL connection setup can take 50-200ms, so reusing connections
        saves significant time over the connector's lifetime.

        Note: pool_size=1 is sufficient because the Poll class ensures sequential query
        execution. Each poll cycle waits for the query to complete (via await) before
        starting the next cycle, making concurrent queries impossible.

        Timeout Configuration:
        By default, most database drivers have NO timeout, which means queries can hang
        indefinitely. It is STRONGLY RECOMMENDED to configure timeout via 'connect_args'
        in connector config. See README.md for database-specific timeout configuration
        examples.

        Returns:
            Engine: Configured SQLAlchemy engine

        Raises:
            ValueError: If get_connection_string() returns invalid connection string
        """
        # Get connection string from subclass implementation
        connection_string = self.get_connection_string()

        if not connection_string:
            raise ValueError(
                "Connection string cannot be empty. "
                "Ensure get_connection_string() returns a valid SQLAlchemy connection string."
            )

        # Get connection arguments from connector config (timeout, SSL, etc.)
        connect_args = self._get_connect_args()

        # Build engine config - keep connections alive for polling
        engine_config = {
            "pool_pre_ping": True,  # Verify connection before use
            "pool_recycle": 3600,  # Recycle connections after 1 hour
            "connect_args": connect_args,  # Database-specific timeout
        }

        # SQLite uses SingletonThreadPool by default (one connection per thread)
        # Production databases need explicit pool_size configuration
        if not connection_string.startswith("sqlite"):
            engine_config.update(
                {
                    "pool_size": 1,  # Only 1 connection needed (sequential execution)
                    "max_overflow": 0,  # No additional connections needed
                }
            )

        engine = create_engine(connection_string, **engine_config)

        # Test connection immediately to fail fast on bad configuration.
        # Behavior on connection failure:
        # - If database rejects connection (wrong credentials, unreachable, etc.):
        #   SQLAlchemy throws exception, which is caught and logged in on_start()
        # - If connection hangs (network issues, firewall blocking, etc.):
        #   Blocks until timeout expires. User MUST configure timeout via connect_args
        #   to prevent indefinite hanging (see README.md for database-specific examples)
        #   We strongly recommend setting a timeout to prevent hanging.
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))

        self.logger.info(
            "Database connection established successfully with timeout config keys: %s",
            list(connect_args.keys())
            if isinstance(connect_args, dict)
            else f"ERROR: Expected dict but got {type(connect_args).__name__}",
        )

        return engine

    def _get_connect_args(self) -> Dict[str, Any]:
        """
        Get connection arguments from connector config.

        Returns the 'connect_args' dictionary from connector config, which is passed
        directly to SQLAlchemy's create_engine(). This can include any driver-specific
        connection parameters such as:
        - Timeout settings (connect_timeout, statement_timeout)
        - SSL/TLS configuration
        - Character set and encoding
        - Other driver-specific options

        Note: By default, most database drivers have NO timeout or very long timeouts.
        It is STRONGLY RECOMMENDED to configure timeout via 'connect_args'.
        See README.md for database-specific configuration examples.

        Returns:
            Dictionary of connection arguments from config, or empty dict if not configured
        """
        # Check if connector_details is loaded (may not be in integration tests or direct method calls)
        if not self.connector_details_are_loaded():
            return {}

        # Check if user provided custom connect_args
        # config can be either dict or ConnectorDetailsDtoConfig (both support 'in' and '[]')
        if "connect_args" in self.connector_details.config:  # type: ignore
            connect_args = self.connector_details.config["connect_args"]  # type: ignore
            self.logger.info(
                "Using custom connect_args from config with keys: %s",
                list(connect_args.keys())
                if isinstance(connect_args, dict)
                else f"ERROR: Expected dict but got {type(connect_args).__name__}",
            )
            return connect_args

        # No timeout configured - warn user
        self.logger.warning(
            "No timeout configured for database connection. "
            "Queries may hang indefinitely. "
            "It is STRONGLY RECOMMENDED to configure timeout via 'connect_args' in connector config. "
            "See README.md for database-specific timeout configuration examples."
        )
        return {}

    async def on_stop(self):
        """Stop polling."""
        await super().on_stop()
        self._stop_polling()

    async def on_shutdown(self):
        """Clean up database connection."""
        if self.engine:
            self.engine.dispose()
            self.logger.info("Database connection closed")

        await super().on_shutdown()

    async def on_connector_updated(self, prev: ConnectorDetailsDto | None):
        """
        Handle connector configuration updates.

        This method is called when the connector's configuration is updated.
        When the connector is RUNNING, we initialize or reinitialize polling to pick up
        configuration changes such as polling interval or connection parameters.

        If connection configuration (host, port, database, credentials) has changed,
        we recreate the database engine to use the new connection parameters.

        This method also handles initial setup on connector start, since super().on_start()
        calls load_connector_details() which triggers this method.

        Args:
            prev: Previous connector details (None on first call)
        """
        await super().on_connector_updated(prev)

        if self.connector_details.operating_status == OperatingStatus.RUNNING:
            # Check if connection configuration changed
            if prev and self._connection_config_changed(prev):
                self.logger.info(
                    "Connection configuration changed, recreating database engine"
                )
                self._close_engine()
                self.engine = None  # Will be recreated in _initialize_poll

            self.logger.info("Connector configuration updated, initializing poll")
            await self._initialize_poll()

    async def _initialize_poll(self):
        """
        Initialize or reinitialize the polling mechanism.

        This method is called when:
        1. Connector configuration is updated (via on_connector_updated)
        2. Connector starts (via on_start → on_connector_updated)

        If a poll already exists, we stop it first and wait briefly to allow
        any in-flight requests to complete before starting a new poll with
        the updated configuration.

        This method handles:
        - Creating the database engine (if not already created)
        - Loading the watermark from connector state
        - Starting the polling loop
        """
        self.logger.info("Initializing SQL connector polling loop")

        if self.poll:
            self.logger.warning("Stopping existing poll before reinitializing")
            self._stop_polling()
            # Wait briefly to allow in-flight requests to complete
            await asyncio.sleep(POLL_RESTART_DELAY_SEC)

        try:
            # Create engine if it was closed due to config change or first initialization
            if not self.engine:
                self.engine = self._create_engine()

            # Load watermark from connector state
            await self._load_watermark()

            # Start polling with current configuration
            self._start_polling()

        except Exception as exc:
            self.logger.error(f"Failed to initialize SQL connector polling: {exc}")
            raise

    def _connection_config_changed(self, prev: ConnectorDetailsDto) -> bool:
        """
        Check if connection configuration has changed.

        This method compares the entire configuration dictionary to detect changes.
        This is a conservative approach - any configuration change will trigger
        database engine recreation, even if the change doesn't affect the connection
        (e.g., changing polling_interval_minutes).

        This ensures we never miss a connection parameter change, at the cost of
        potentially recreating the engine more often than strictly necessary.

        Developers can override this method to implement more granular detection
        logic if needed. For example, to only check specific connection-related
        configuration keys:

        Example override:
            def _connection_config_changed(self, prev):
                current = self.connector_details.config
                prev_cfg = prev.config

                # Only check connection-specific parameters
                connection_keys = ['db_host', 'db_port', 'db_name',
                                   'db_user', 'db_password']
                for key in connection_keys:
                    if current.get(key) != prev_cfg.get(key):
                        return True
                return False

        Args:
            prev: Previous connector details

        Returns:
            True if configuration changed, False otherwise
        """
        # Compare the entire config dictionary (conservative approach)
        current_config = (
            self.connector_details.config
            if isinstance(self.connector_details.config, dict)
            else {}
        )
        prev_config = prev.config if isinstance(prev.config, dict) else {}

        changed = current_config != prev_config
        if changed:
            self.logger.info(
                "Connector configuration changed, will recreate database engine"
            )

        return changed

    def _close_engine(self):
        """
        Close the SQLAlchemy engine and dispose of the connection pool.

        This should be called when the connection configuration changes
        or when the connector is shutting down.
        """
        if self.engine:
            self.logger.info("Closing database engine and disposing connection pool")
            self.engine.dispose()
            self.logger.debug("Database engine closed successfully")

    def _start_polling(self):
        """
        Start the polling mechanism.

        The Poll class ensures sequential query execution by waiting for each
        query to complete (via await) before starting the next poll cycle.
        This means queries cannot overlap, even if a query takes longer than
        the polling interval. If a query execution time exceeds the interval,
        the next query will start immediately after the previous one completes.

        Example timeline with 10-minute interval:
        T=0m 00s:  Query 1 starts
        T=0m 15s:  Query 1 finishes (took 15 seconds)
        T=10m 00s: Query 2 starts (slept ~9m 45s to maintain 10-minute interval)
        T=10m 20s: Query 2 finishes (took 20 seconds)
        T=20m 00s: Query 3 starts (slept ~9m 40s to maintain 10-minute interval)
        """
        # Get polling interval from config, default to 10 minutes
        polling_interval_minutes = (
            self.connector_details.config["polling_interval_minutes"]
            if "polling_interval_minutes" in self.connector_details.config
            else 10
        )
        polling_interval_seconds = polling_interval_minutes * 60

        self.poll = Poll(
            target=self._get_file_and_process,
            interval=polling_interval_seconds,
            on_error=lambda exc: self.logger.error(
                f"Error during polling: {exc}", exc_info=True
            ),
            name="SqlConnectorPoll",
        )
        self.poll.start()
        self.logger.info(
            f"Started polling with interval: {polling_interval_minutes} minutes"
        )

    def _stop_polling(self):
        """Stop the polling mechanism."""
        if self.poll:
            self.poll.stop()
            self.poll = None
            self.logger.info("Stopped polling")

    def _execute_query(self, query: str) -> List[Dict[str, Any]]:
        """
        Execute SQL query and return results as list of dictionaries.

        This method executes a SQL query using the connector's engine and returns
        the results as a list of dictionaries, where each dictionary represents a row.

        Args:
            query: SQL query string to execute

        Returns:
            List of dictionaries, where each dict represents a row with column names as keys

        Raises:
            SQLAlchemyError: If query execution fails
        """
        with self.engine.connect() as conn:
            result = conn.execute(text(query))
            # pylint: disable=protected-access
            rows = [dict(row._mapping) for row in result]
        return rows

    async def _get_file_and_process(self):
        """
        Get or create a PENDING file and process it.

        This method is called by the Poll object at regular intervals.
        It follows a single-open-file pattern:
        1. Check for existing PENDING file (from previous failed attempt)
        2. If PENDING file exists, process it first (retry scenario)
        3. If no PENDING file, create a new one and process it

        Single Open File Pattern:
        - At most one PENDING file exists at any time
        - This ensures clean retry semantics and prevents data duplication
        - If a previous upload failed, we retry with the same watermark
        - Only after successful processing do we move to the next query

        TODO (Future Enhancement - Data Duplication Prevention):
        To prevent data duplication, we could check if a file was already uploaded
        before re-uploading. However, this has a known platform limitation:

        **Label/File ID Issue**: When re-saving a file with the same fileId but
        different content, the platform's fileInfo lambda performs an S3 CopyObject
        to a new file with a NEW random fileId. The labels file (stored at
        `labels/{fileId}.labels`) is NOT copied, causing labels to be lost.

        See: https://tetrascience.slack.com/archives/C063W40KT18/p1755877257508699
        """
        # Step 1: Check for existing PENDING file (indicates previous failure)
        # TODO: Consider handling rare edge cases where multiple PENDING files exist
        # (e.g., from a bug, manual intervention, or migration from older version).
        # Options: process oldest first, mark extras as ERROR, or log warning.
        # For now, we only process the first one found and assume single PENDING file.
        try:
            files_response = await self.get_files(
                statuses=[ConnectorFileDtoStatus.PENDING],
                max_results=1,
                paginate=False,
            )

            if files_response and files_response.files:
                # PENDING file exists - process it first (retry scenario)
                self.logger.info(
                    f"Found existing PENDING file {files_response.files[0].id}, "
                    "processing it before creating new file"
                )
                await self._process_file(files_response.files[0])
                return

        except Exception as exc:
            self.logger.error(
                f"Failed to check for existing PENDING files: {exc}", exc_info=True
            )
            await self._update_health_status(
                UpdateConnectorHealthRequestStatus.CRITICAL,
                error_code="FileRetrievalError",
            )
            return

        # Step 2: No PENDING file exists - create a new one
        file_id = None
        try:
            file_id = str(uuid4())
            timestamp = datetime.now(timezone.utc).isoformat()
            source_type = (
                self.connector_details.config.get("source_type", "sql_query_results")
                if isinstance(self.connector_details.config, dict)
                else "sql_query_results"
            )
            file_path = f"/{source_type}/{timestamp}.json"

            # Create metadata object with current watermark
            # watermark_before is used for retry if upload fails
            pending_metadata = SaveConnectorFileRequestMetadata()
            pending_metadata.additional_properties.update(
                {
                    "watermark_before": self.watermark,
                    "query_timestamp": timestamp,
                }
            )

            await self.save_files(
                [
                    SaveConnectorFileRequest(
                        id=file_id,
                        unique_external_id=timestamp,
                        filepath=file_path,
                        status=ConnectorFileDtoStatus.PENDING,
                        metadata=pending_metadata,
                    )
                ]
            )
            self.logger.debug(f"Registered file entry {file_id} with PENDING status")

        except Exception as exc:
            self.logger.error(
                f"Failed to register pending file entry: {exc}", exc_info=True
            )
            await self._update_health_status(
                UpdateConnectorHealthRequestStatus.CRITICAL,
                error_code="FileRegistrationError",
            )
            return

        # Step 3: Retrieve the newly created file and process it
        try:
            files_response = await self.get_files(
                statuses=[ConnectorFileDtoStatus.PENDING],
                max_results=1,
                paginate=False,
            )

            if not files_response or not files_response.files:
                self.logger.warning("No PENDING file found after registration")
                return

            await self._process_file(files_response.files[0])

        except Exception as exc:
            self.logger.error(
                f"Failed to retrieve or process file: {exc}", exc_info=True
            )
            await self._update_health_status(
                UpdateConnectorHealthRequestStatus.CRITICAL,
                error_code="FileRetrievalError",
            )
            return

    async def _process_file(self, file_dto):
        """
        Process a single PENDING file.

        This method executes the query with the watermark stored in the file's metadata,
        saves the new watermark, uploads the results, and updates the file status.

        Operation Order (to prevent data loss):
        1. Execute query with watermark from file metadata
        2. Save new watermark to connector state FIRST
           - If fails: ABORT, file stays PENDING, retry next poll with same watermark
        3. Upload file to S3
        4. Mark file as SUCCESS
           - If 3 or 4 fails: file stays PENDING, retry using file metadata watermark_before

        Single Open File Pattern:
        - Only one PENDING file exists at a time
        - If processing fails, the file stays PENDING for retry
        - Watermark in file metadata is used for retry (not connector state)

        Args:
            file_dto: ConnectorFileDto object to process
        """
        try:
            self.logger.info(
                f"Processing file {file_dto.id} (status: {file_dto.status})"
            )

            # Extract metadata from the file entry
            # Use file metadata watermark_before for retry scenarios
            metadata = file_dto.metadata or {}
            watermark = metadata.get("watermark_before", self.watermark)
            file_path = file_dto.filepath

            # Execute query with the watermark from the file entry
            query = self.get_connector_query(watermark)
            self.logger.debug(f"Executing query for file {file_dto.id}")

            rows = self._execute_query(query)

            if not rows:
                self.logger.info(f"No data found for file {file_dto.id}")

                # Upload file with empty data for transparency
                # This allows users to see that a query was executed but returned no rows
                # Note: Since no data was returned, the watermark remains unchanged.
                # The next poll cycle will execute the same query with the same watermark,
                # which is the expected behavior for polling connectors waiting for new data.
                file_content = json.dumps(
                    {
                        "query": query,
                        "watermark": watermark,
                        "data": [],  # Empty data array
                    },
                    indent=2,
                    default=str,
                )

                # Determine source_type
                source_type = (
                    self.connector_details.config.get(
                        "source_type", "sql_query_results"
                    )
                    if isinstance(self.connector_details.config, dict)
                    else "sql_query_results"
                )

                # Upload file even with no data
                upload_request = UploadFileRequest(
                    filepath=file_path,
                    content=file_content.encode("utf-8"),
                    source_type=source_type,
                    file_id=file_dto.id,
                )
                await self.upload_file(upload_request)
                self.logger.info(f"Uploaded file with no data rows: {file_path}")

                # Mark as SUCCESS with no data
                no_data_metadata = SaveConnectorFileRequestMetadata()
                no_data_metadata.additional_properties.update(
                    {
                        "row_count": 0,
                        "watermark": watermark,
                    }
                )
                await self.save_files(
                    [
                        SaveConnectorFileRequest(
                            id=file_dto.id,
                            status=ConnectorFileDtoStatus.SUCCESS,
                            metadata=no_data_metadata,
                        )
                    ]
                )
                await self._update_health_status(
                    UpdateConnectorHealthRequestStatus.HEALTHY
                )
                return

            self.logger.info(f"Retrieved {len(rows)} rows for file {file_dto.id}")

            # Get new watermark and prepare file content
            new_watermark = self.get_watermark(rows)
            file_content = json.dumps(
                {
                    "query": query,
                    "watermark": watermark,  # Watermark used for THIS query
                    "data": rows,
                },
                indent=2,
                default=str,
            )

            # Determine source_type
            source_type = (
                self.connector_details.config.get("source_type", "sql_query_results")
                if isinstance(self.connector_details.config, dict)
                else "sql_query_results"
            )

            # IMPORTANT: Save watermark to connector state BEFORE upload
            # This ensures we don't lose data if upload fails:
            # - If watermark save fails: ABORT, file stays PENDING, retry with same watermark
            # - If watermark save succeeds but upload fails: file stays PENDING, but we've
            #   already moved the watermark forward. On retry, we use file metadata watermark_before.
            if new_watermark != self.watermark:
                prev_watermark = self.watermark
                self.watermark = new_watermark
                try:
                    await self._save_watermark()
                    self.logger.debug(f"Saved watermark before upload: {new_watermark}")
                except Exception as wm_exc:
                    # Watermark save failed - ABORT processing
                    # Revert in-memory watermark to maintain consistency
                    # This ensures that if the PENDING file is lost, we use the last
                    # successfully persisted watermark instead of the unpersisted one
                    self.watermark = prev_watermark
                    # File stays PENDING, will retry next poll with same watermark
                    # NOTE: Future enhancement - consider adding exponential backoff for
                    # watermark save failures. Currently, the poll interval (default 10 min)
                    # provides natural spacing between retries.
                    self.logger.error(
                        f"Failed to save watermark, aborting file processing: {wm_exc}",
                        exc_info=True,
                    )
                    await self._update_health_status(
                        UpdateConnectorHealthRequestStatus.WARNING,
                        error_code="WatermarkSaveError",
                    )
                    return

            # Upload file to TDP
            upload_request = UploadFileRequest(
                filepath=file_path,
                content=file_content.encode("utf-8"),
                source_type=source_type,
                file_id=file_dto.id,
            )

            await self.upload_file(upload_request)
            self.logger.info(f"Uploaded file: {file_path}")

            # Mark file as SUCCESS
            # Store both watermarks for clarity:
            # - watermark_before: the watermark used for the query
            # - watermark_after: the new watermark calculated from results
            success_metadata = SaveConnectorFileRequestMetadata()
            success_metadata.additional_properties.update(
                {
                    "row_count": len(rows),
                    "watermark_before": watermark,
                    "watermark_after": new_watermark,
                }
            )
            await self.save_files(
                [
                    SaveConnectorFileRequest(
                        id=file_dto.id,
                        status=ConnectorFileDtoStatus.SUCCESS,
                        metadata=success_metadata,
                    )
                ]
            )

            # File processed successfully
            await self._update_health_status(UpdateConnectorHealthRequestStatus.HEALTHY)

        except Exception as exc:
            self.logger.error(
                f"Failed to process file {file_dto.id}: {exc}", exc_info=True
            )

            # Get current error count and increment
            existing_error_count = 0
            if hasattr(file_dto, "error_count") and file_dto.error_count is not None:
                existing_error_count = file_dto.error_count
            new_error_count = existing_error_count + 1

            # Calculate exponential backoff delay
            # Delay = min(BASE_BACKOFF_SECONDS * 2^(error_count-1), MAX_BACKOFF_SECONDS)
            backoff_delay = min(
                BASE_BACKOFF_SECONDS * (2 ** (new_error_count - 1)),
                MAX_BACKOFF_SECONDS,
            )

            # Log with appropriate severity based on error count
            file_watermark_before = (file_dto.metadata or {}).get("watermark_before")
            if new_error_count >= CRITICAL_ERROR_THRESHOLD:
                self.logger.error(
                    f"File {file_dto.id} failed (attempt {new_error_count}). "
                    f"Persistent failure - will retry in {backoff_delay}s. "
                    f"File metadata watermark_before: {file_watermark_before}, "
                    f"Connector state watermark: {self.watermark}. "
                    f"Error: {str(exc)[:200]}"
                )
            else:
                self.logger.warning(
                    f"File {file_dto.id} failed (attempt {new_error_count}), "
                    f"will retry in {backoff_delay}s"
                )

            # Update file with error info - keep as PENDING for retry
            # Preserve existing metadata (including watermark_before) for retry
            existing_metadata = file_dto.metadata or {}
            error_metadata = SaveConnectorFileRequestMetadata()
            error_metadata.additional_properties.update(existing_metadata)

            try:
                await self.save_files(
                    [
                        SaveConnectorFileRequest(
                            id=file_dto.id,
                            status=ConnectorFileDtoStatus.PENDING,
                            error_message=str(exc)[:500],
                            error_count=new_error_count,
                            metadata=error_metadata,
                        )
                    ]
                )
            except Exception as save_exc:
                self.logger.error(
                    f"Failed to update file {file_dto.id} error count: {save_exc}",
                    exc_info=True,
                )

            # Set health status based on error count
            if new_error_count >= CRITICAL_ERROR_THRESHOLD:
                await self._update_health_status(
                    UpdateConnectorHealthRequestStatus.CRITICAL,
                    error_code="PersistentFileProcessingError",
                )
            else:
                await self._update_health_status(
                    UpdateConnectorHealthRequestStatus.WARNING,
                    error_code="FileProcessingError",
                )

            # Sleep before returning to Poll loop to implement exponential backoff.
            # After this sleep, the function returns and Poll waits for its interval.
            # The retry happens in the next poll iteration when it finds this PENDING file.
            # Total wait between retries = backoff_delay + poll_interval
            self.logger.info(f"Backing off for {backoff_delay}s before next retry")
            await asyncio.sleep(backoff_delay)

    async def _update_health_status(
        self,
        status: UpdateConnectorHealthRequestStatus,
        error_code: Optional[str] = None,
    ):
        """
        Update the connector health status in TDP.

        Args:
            status: The health status to set (HEALTHY, WARNING, CRITICAL)
            error_code: Optional error code for WARNING or CRITICAL status
        """
        try:
            if not self.connector_id:
                self.logger.warning("Cannot update health status: connector_id is None")
                return

            # Build request - only include error_code if provided
            request = UpdateConnectorHealthRequest(status=status)
            if error_code is not None:
                request.error_code = error_code

            await self.tdp_api.update_health(self.connector_id, request)
            self.logger.debug(f"Updated health status to {status}")
        except Exception as exc:
            self.logger.error(
                f"Failed to update health status to {status}: {exc}", exc_info=True
            )

    @retry(
        retry=retry_if_exception_type(ConnectorError),
        stop=stop_after_attempt(3),
        wait=wait_fixed(2),
        before_sleep=before_sleep_log(logging.getLogger(__name__), logging.WARNING),
        reraise=True,
    )
    async def _load_watermark(self):
        """
        Load watermark from connector state on startup.

        This loads the in-memory watermark from connector state. This watermark is used
        when creating NEW PENDING files (for the query).

        IMPORTANT: The in-memory watermark is NOT used when processing existing PENDING
        files. When a PENDING file exists, _process_file() uses the watermark stored in
        the file's metadata, not this in-memory value. This ensures retry scenarios use
        the correct starting point (the watermark at the time the file was created).

        Watermark Source Summary:
        - For NEW files: connector state watermark (loaded here, stored in file metadata)
        - For PENDING files (retry): file.metadata.watermark_before (checked every poll cycle)

        Implements retry logic for transient TDP API failures (ConnectorError).
        Uses tenacity decorator for automatic retry.

        Strategy:
        - Retry up to 3 times with 2-second delay for ConnectorError (TDP API errors)
        - Fail fast for unexpected exceptions (no retry)

        Raises:
            ConnectorError: If watermark load fails after retries
            Exception: If unexpected error occurs (fails immediately without retry)
        """
        watermark_value = await self.get_value("watermark")
        if watermark_value and watermark_value.value:
            # The value is stored as a dict in ConnectorValueDto
            self.watermark = watermark_value.value.to_dict()
            self.logger.info(f"Loaded watermark from connector state: {self.watermark}")
        else:
            # Use initial watermark from config if available
            # config can be either dict or ConnectorDetailsDtoConfig (both support 'in' and '[]')
            self.watermark = (
                self.connector_details.config["initial_watermark"]  # type: ignore
                if "initial_watermark" in self.connector_details.config  # type: ignore
                else None
            )
            self.logger.info(f"No saved watermark, using initial: {self.watermark}")

    async def _save_watermark(self):
        """
        Save watermark to connector state.

        This is called BEFORE uploading the file to S3 (see _process_file).
        If save fails, the file stays PENDING and will be retried on next poll.

        Raises:
            Exception: If watermark save fails (caught by caller)
        """
        try:
            await self.save_value("watermark", self.watermark or {}, secure=False)
            self.logger.debug(f"Saved watermark: {self.watermark}")

        except Exception as exc:
            self.logger.error(
                f"Failed to save watermark: {exc}. File will stay PENDING for retry.",
                exc_info=True,
            )
            raise
