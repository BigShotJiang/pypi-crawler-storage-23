"""
SQL Connector module for the TetraScience Connector SDK.

This module provides an inheritance-based SQL connector framework that allows
developers to easily build SQL-based connectors by extending the SqlConnector
class and implementing three abstract methods.
"""

from ts_sdk_connectors_python.sql.connector import SqlConnector

__all__ = ["SqlConnector"]
