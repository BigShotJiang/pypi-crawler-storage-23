"""Command-line interface for Agent Berlin SDK.

This module provides CLI commands for downloading workflows and uploading reports.
"""

import json
from pathlib import Path
from typing import Optional

import click
import requests

from .config import DEFAULT_BASE_URL
from .session import load_session_config


@click.group()
@click.version_option()
def main() -> None:
    """Agent Berlin CLI - Download and manage workflows."""
    pass


@main.command()
@click.argument("workflow_id")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--output", "-o", type=click.Path(), help="Output directory")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def download_workflow(
    workflow_id: str,
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a workflow to local files.

    WORKFLOW_ID is the workflow identifier.

    This downloads the workflow definition to local files that can be read
    by an LLM to understand and execute the workflow locally.
    """
    # Resolve token (same as SDK)
    if not token:
        config = load_session_config()
        token = config.get("token")

    if not token:
        raise click.ClickException(
            "No API token found. Set AGENTBERLIN_TOKEN or configure session first."
        )

    # Fetch workflow from API
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{base_url}/workflows/{workflow_id}/download"

    try:
        resp = requests.get(url, headers=headers, timeout=30)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found or access denied.")
    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")

    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"API request failed: {e}")

    data = resp.json()

    # Determine output directory
    if output:
        out_dir = Path(output)
    else:
        out_dir = Path.cwd() / ".agentberlin" / "workflows" / workflow_id

    out_dir.mkdir(parents=True, exist_ok=True)
    scripts_dir = out_dir / "scripts"
    scripts_dir.mkdir(exist_ok=True)

    # Write scripts as individual .py files
    script_files: list[str] = []
    for script in data.get("scripts", []):
        name = script["name"].replace(" ", "_").lower()
        filename = f"{name}.py"
        script_files.append(filename)

        # Add header comment to script
        deps = ", ".join(script.get("dependencies", []))
        header = f'''# Script: {script["name"]}
# Description: {script.get("description", "")}
# Dependencies: {deps}

'''
        (scripts_dir / filename).write_text(header + script.get("script", ""))

    # Generate README.md with all workflow content
    readme = _generate_readme(data, script_files)
    (out_dir / "README.md").write_text(readme)

    # Print confirmation
    click.echo(f"Downloaded workflow: {data.get('name', workflow_id)}")
    click.echo(f"Location: {out_dir}")
    click.echo("Files:")
    click.echo("  - README.md")
    for sf in script_files:
        click.echo(f"  - scripts/{sf}")


@main.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--description", "-d", required=True, help="Report description")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def save_report(
    file_path: str,
    description: str,
    token: Optional[str],
    base_url: str,
) -> None:
    """Upload a file as a report to Agent Berlin.

    FILE_PATH is the path to the file to upload.

    This uploads the file to Agent Berlin's storage and registers it
    so users can download it from the Agent Berlin UI.
    """
    # Resolve token
    if not token:
        config = load_session_config()
        token = config.get("token")

    if not token:
        raise click.ClickException(
            "No API token found. Set AGENTBERLIN_TOKEN or configure session first."
        )

    source = Path(file_path)
    if not source.exists():
        raise click.ClickException(f"File not found: {file_path}")

    # Upload file to backend API
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{base_url}/reports/upload"

    try:
        with open(source, "rb") as f:
            files = {"file": (source.name, f)}
            form_data = {"description": description}
            resp = requests.post(
                url, headers=headers, files=files, data=form_data, timeout=120
            )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_msg = resp.json().get("error", "Bad request")
        raise click.ClickException(f"Upload failed: {error_msg}")

    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"API request failed: {e}")

    result = resp.json()
    click.echo(f"Report uploaded: {source.name}")
    click.echo(f"Description: {description}")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


def _generate_readme(data: dict, script_files: list[str]) -> str:
    """Generate README.md with workflow instruction, sub-agents, and config."""
    lines = [
        f"# {data.get('name', 'Workflow')}",
        "",
        "## Main Agent Instruction",
        "",
        data.get("instruction", ""),
        "",
    ]

    # Sub-agents section
    subagents = data.get("subagents", [])
    if subagents:
        lines.append("## Sub-Agents")
        lines.append("")
        for sa in subagents:
            lines.append(f"### {sa['name']}")
            lines.append("")
            lines.append(sa.get("processing_guide", ""))
            lines.append("")

    # Scripts section (just list them, code is in separate files)
    if script_files:
        lines.append("## Scripts")
        lines.append("")
        for script in data.get("scripts", []):
            name = script["name"].replace(" ", "_").lower()
            desc = script.get("description", "")
            lines.append(f"- **{script['name']}** (`scripts/{name}.py`): {desc}")
        lines.append("")

    # Configuration section
    config: dict = {}
    inputs = data.get("inputs", [])
    if inputs:
        config["inputs"] = inputs

    built_in_tools = data.get("built_in_tools", [])
    if built_in_tools:
        config["built_in_tools"] = built_in_tools

    if config:
        lines.append("## Configuration")
        lines.append("")
        lines.append("```json")
        lines.append(json.dumps(config, indent=2))
        lines.append("```")

    return "\n".join(lines)


if __name__ == "__main__":
    main()
