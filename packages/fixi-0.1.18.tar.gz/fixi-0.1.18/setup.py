"""
Setup script for heal package - for backward compatibility.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
