from typing import List
from judgeval.v1.internal.api.api_types import TraceSpan

Trace = List[TraceSpan]
