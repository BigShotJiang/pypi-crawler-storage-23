from judgeval.utils.version_check import check_latest_version
from judgeval.v1 import Judgeval

check_latest_version()


__all__ = ["Judgeval"]
