__version__ = "0.28.0"


def get_version() -> str:
    return __version__
