#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TEMU评价有礼金活动详情表模型
frozenType: review_subsidy_reserve
"""

from sqlalchemy import create_engine, Column, String, Text, DateTime, Integer, DECIMAL, Date, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime, date
import json
import re

Base = declarative_base()


class TemuRestrictReviewSubsidyReserve(Base):
    """
    TEMU评价有礼金活动详情表
    """
    __tablename__ = 'temu_restrict_review_subsidy_reserve'

    # 主键ID (自增)
    id = Column(Integer, primary_key=True, autoincrement=True, comment='主键ID')

    # 商城和日期
    mall_id = Column(String(50), nullable=False, comment='商城ID')
    record_date = Column(Date, nullable=False, comment='记录日期')

    # 详情字段
    activity_name = Column(String(200), nullable=True, comment='活动名称')
    activity_begin_time = Column(String(50), nullable=True, comment='活动开始时间')
    activity_expected_end_time = Column(String(50), nullable=True, comment='活动预计结束时间')
    amount = Column(String(50), nullable=True, comment='限制金额文本')
    amount_value = Column(DECIMAL(12, 2), nullable=True, comment='限制金额数值')
    currency = Column(String(10), nullable=True, comment='货币类型')
    state = Column(String(50), nullable=True, comment='状态')
    freeze_start_time = Column(DateTime, nullable=True, comment='限制开始时间')
    source_dr = Column(String(50), nullable=True, comment='地区')

    # 时间戳
    created_at = Column(DateTime, default=datetime.now, comment='创建时间')
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment='更新时间')

    # 定义索引
    __table_args__ = (
        Index('ix_review_subsidy_mall_id', 'mall_id'),
        Index('ix_review_subsidy_record_date', 'record_date'),
        Index('ix_review_subsidy_activity_name', 'activity_name'),
        Index('ix_review_subsidy_mall_date', 'mall_id', 'record_date'),
        Index('ix_review_subsidy_unique', 'mall_id', 'record_date', 'activity_name', 'activity_begin_time', unique=True),
    )

    def __repr__(self):
        return f"<TemuRestrictReviewSubsidyReserve(id={self.id}, activity_name='{self.activity_name}')>"


class TemuRestrictReviewSubsidyReserveManager:
    """
    TEMU评价有礼金活动数据管理器
    """

    def __init__(self, database_url):
        self.engine = create_engine(database_url, echo=False)
        self.Session = sessionmaker(bind=self.engine)

    def create_tables(self):
        Base.metadata.create_all(self.engine)
        print("TEMU评价有礼金活动表创建成功！")

    def drop_tables(self):
        Base.metadata.drop_all(self.engine)
        print("TEMU评价有礼金活动表删除成功！")

    def _parse_amount_value(self, amount_str):
        if not amount_str:
            return None
        try:
            cleaned = re.sub(r'[￥¥$€£+,\s]', '', str(amount_str))
            return float(cleaned) if cleaned else None
        except:
            return None

    def _parse_timestamp(self, timestamp_ms):
        if not timestamp_ms:
            return None
        try:
            return datetime.fromtimestamp(timestamp_ms / 1000)
        except:
            return None

    def upsert_data(self, mall_id, record_date, data):
        """
        插入或更新数据
        """
        session = self.Session()
        try:
            details_rows = data.get('detailsRows', [])
            insert_count = 0
            update_count = 0

            for row in details_rows:
                activity_name = row.get('activityName')
                activity_begin_time = row.get('activityBeginTime')

                existing = session.query(TemuRestrictReviewSubsidyReserve).filter_by(
                    mall_id=mall_id,
                    record_date=record_date,
                    activity_name=activity_name,
                    activity_begin_time=activity_begin_time
                ).first()

                if existing:
                    existing.activity_expected_end_time = row.get('activityExpectedEndTime')
                    existing.amount = row.get('amount')
                    existing.amount_value = self._parse_amount_value(row.get('amount'))
                    existing.currency = row.get('currency')
                    existing.state = row.get('state')
                    existing.freeze_start_time = self._parse_timestamp(row.get('freezeStartTime'))
                    existing.source_dr = row.get('sourceDR')
                    existing.updated_at = datetime.now()
                    update_count += 1
                else:
                    new_record = TemuRestrictReviewSubsidyReserve(
                        mall_id=mall_id,
                        record_date=record_date,
                        activity_name=activity_name,
                        activity_begin_time=activity_begin_time,
                        activity_expected_end_time=row.get('activityExpectedEndTime'),
                        amount=row.get('amount'),
                        amount_value=self._parse_amount_value(row.get('amount')),
                        currency=row.get('currency'),
                        state=row.get('state'),
                        freeze_start_time=self._parse_timestamp(row.get('freezeStartTime')),
                        source_dr=row.get('sourceDR')
                    )
                    session.add(new_record)
                    insert_count += 1

            session.commit()
            print(f"TEMU评价有礼金活动: 新增 {insert_count} 条，更新 {update_count} 条")

        except Exception as e:
            session.rollback()
            print(f"处理数据失败: {e}")
            raise
        finally:
            session.close()

    def import_from_json_file(self, json_file_path, mall_id, record_date):
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            self.upsert_data(mall_id, record_date, data)
