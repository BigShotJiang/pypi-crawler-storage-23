"""AI tutor prompts for Claude Desktop."""
