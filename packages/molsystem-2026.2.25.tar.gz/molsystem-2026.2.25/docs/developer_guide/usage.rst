=====
Usage
=====

To use MolSystem in a project::

    import molsystem
