Developer Documentation
=======================

Contents:

.. toctree::
   :maxdepth: 4

   installation
   usage
   contributing

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
