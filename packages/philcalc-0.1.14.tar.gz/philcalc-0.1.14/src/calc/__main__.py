from .cli import run

raise SystemExit(run())
