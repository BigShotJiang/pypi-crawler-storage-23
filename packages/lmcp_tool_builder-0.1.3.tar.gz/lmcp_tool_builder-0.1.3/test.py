from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from lmcp_tool_builder import LMCPToolBuilder # lmcp_tool_builder
import asyncio

import os
from dotenv import load_dotenv

load_dotenv()

# 到lmcp平台注册创建应用、绑定工具、获得api_key（略）
print(f'[LMCP] 开始更新工具...')

# 创建工具构建器
builder = LMCPToolBuilder(
    server_url="http://aicity.wang:8000",
    api_key="aca8942ed1b43ab16f796eb223db10dc12edaa0c3fad7d41b85215bcb6aceefb",
    local_tools_file=os.getenv("LMCP_LOCAL_TOOLS_FILE", "bot_tools.py"),
    debug=True,
    auto_update=True
)

# 构建并加载工具
tools = builder.build_and_load_tools()

for i in tools:
    # 安全地获取工具名称：优先使用 name 属性，否则使用 __name__
    tool_name = getattr(i, 'name', getattr(i, '__name__', str(i)))
    print(f"工具: {tool_name}")
    
agent = create_agent(
    model=ChatOpenAI(
        model="deepseek-chat",
        api_key="sk-fa809b363fd64e27b3bdcaa8194057f5",
        base_url="https://api.deepseek.com/v1"
    ),
    tools=tools
)

async def stream_agent():
    async for message, metadata in agent.astream(
        {"messages": [("user", "你必须使用工具，异步计算2+8=？告诉我你使用哪工具")]}, 
        stream_mode="messages"
    ):
        # 实时打印 Token
        if message.content:
            print(message.content, end="", flush=True)

# # 打字机效果流式输出
# for token, metadata in agent.stream(
#     {"messages": [{"role": "user", "content": "1+2=?"}]},
#     stream_mode="messages" #update
# ):
#     if token.content:
#         print(token.content, end="", flush=True)





if __name__ == "__main__":
    asyncio.run(stream_agent())
    
    
