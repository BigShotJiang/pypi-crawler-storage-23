
"""
自动生成的工具模块
包含从LMCP服务器同步的工具
"""
from langchain_core.tools import BaseTool # lmcp_tool_builder 1.1.2 版之后必须引入，以支持类工具
from pydantic import BaseModel, Field # lmcp_tool_builder 1.1.2 版之后必须引入，以支持类工具

# 让类同时继承 BaseTool 和 BaseModel
class AsyncCalculator(BaseTool, BaseModel):
    name: str = "async_calculator"
    description: str = "用于计算两个数字的和。输入应为两个数字。"

    # 直接在这里定义业务职责需要的参数
    # 它们既是类的属性，也会被 LangChain 自动识别为工具参数
    a: int = Field(..., description="第一个加数，必须为整数")
    b: int = Field(..., description="第二个加数，必须为整数")

    def _run(self, a: int, b: int) -> str:
        """同步执行逻辑"""
        return f"结果是: {a + b}"

    async def _arun(self, a: int, b: int) -> str:
        """异步执行逻辑"""
        import asyncio
        await asyncio.sleep(1) 
        return self._run(a, b)

def _run(self, a: int, b: int) -> str:
    """同步执行逻辑"""
    return f'结果是: {a + b}'

def get_current_time():
    """获取当前时间
    
    返回当前系统时间，格式为YYYY-MM-DD HH:MM:SS
    
    Returns:
        str: 当前时间字符串
    """
    from datetime import datetime
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
