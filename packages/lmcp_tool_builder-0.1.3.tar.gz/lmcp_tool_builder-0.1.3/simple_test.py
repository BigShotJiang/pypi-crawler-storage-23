#!/usr/bin/env python3
"""
简单测试类工具加载
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lmcp_tool_builder import LMCPToolBuilder

# 创建工具构建器
builder = LMCPToolBuilder(
    server_url="http://aicity.wang:8000",
    api_key="test_key",
    local_tools_file="bot_tools.py",
    debug=True,
    auto_update=False
)

print("加载工具...")
tools = builder.load_tools_from_module()

print(f"\n加载的工具总数: {len(tools)}")

# 检查每个工具的类型
for i, tool in enumerate(tools, 1):
    print(f"\n工具 {i}:")
    print(f"  类型: {type(tool)}")
    print(f"  str表示: {str(tool)[:100]}...")
    
    # 检查是否是函数
    if hasattr(tool, '__name__'):
        print(f"  函数名: {tool.__name__}")
    
    # 检查是否是类实例
    if hasattr(tool, 'name'):
        print(f"  工具名: {tool.name}")
    
    # 检查是否有 _run 方法
    if hasattr(tool, '_run'):
        print(f"  有 _run 方法: 是")
        # 尝试调用 _run 方法
        try:
            result = tool._run("测试输入")
            print(f"  _run 结果: {result}")
        except Exception as e:
            print(f"  _run 调用失败: {e}")
    else:
        print(f"  有 _run 方法: 否")
    
    # 检查是否有 _arun 方法
    if hasattr(tool, '_arun'):
        print(f"  有 _arun 方法: 是")
    else:
        print(f"  有 _arun 方法: 否")

# 检查是否有 TestClassTool
print("\n\n检查是否有 TestClassTool 实例:")
class_tools = [t for t in tools if hasattr(t, 'name') and t.name == 'test_class_tool']
print(f"找到 TestClassTool 实例: {len(class_tools)} 个")
