# agent 使用类工具


import asyncio
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field # 引入pydantic对类工具参数数据类型进行约束，如果出错，在第一时间拒绝，节省函数继续执行过程才发现错误消耗的时长和token
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI


# 让类同时继承 BaseTool 和 BaseModel
class AsyncCalculator(BaseTool, BaseModel):
    name: str = "async_calculator"
    description: str = "用于计算两个数字的和。输入应为两个数字。"

    # 直接在这里定义业务职责需要的参数
    # 它们既是类的属性，也会被 LangChain 自动识别为工具参数
    a: int = Field(..., description="第一个加数，必须为整数")
    b: int = Field(..., description="第二个加数，必须为整数")

    def _run(self, a: int, b: int) -> str:
        """同步执行逻辑"""
        return f"结果是: {a + b}"

    async def _arun(self, a: int, b: int) -> str:
        """异步执行逻辑"""
        await asyncio.sleep(1) 
        return self._run(a, b)


def get_current_time():
    """获取当前时间
    
    返回当前系统时间，格式为YYYY-MM-DD HH:MM:SS
    
    Returns:
        str: 当前时间字符串
    """
    from datetime import datetime
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


# 2. 最简 Agent 异步实现
async def run_agent():
    llm=ChatOpenAI(
        model="deepseek-chat",
        api_key="sk-fa809b363fd64e27b3bdcaa8194057f5",
        base_url="https://api.deepseek.com/v1"
    )
    tools = [AsyncCalculator(), get_current_time]
    
    # 创建 Agent
    agent = create_agent(llm, tools=tools)

    # 异步调用 Agent，它会自动寻找并执行工具的 _arun 方法
    response = await agent.ainvoke(
        {"messages": [("user", "现在刘德华50岁，5年后，刘德华多少岁？请尝试先用字符类型的参数执行工具")]}
    )
    
    print(response["messages"][-1].content)

# 运行异步主函数
if __name__ == "__main__":
    asyncio.run(run_agent())
