#!/usr/bin/env python3
"""
LMCP 工具构建器
封装工具发现、构建和加载功能
"""

import os
import ast
import inspect
import requests
from typing import List, Dict, Any, Optional
import importlib.util


class LMCPToolBuilder:
    """LMCP 工具构建器类"""
    
    def __init__(self, 
                 server_url: str = "http://localhost:8000",
                 api_key: str = "",
                 local_tools_file: str = "bot_tools.py",
                 debug: bool = False,
                 auto_update: bool = False): # 如果auto_update=True，则每次运行都会从服务器获取工具并更新本地文件，如果False，则仅在本地文件不存在时从服务器获取
        """
        初始化工具构建器
        
        Args:
            server_url: LMCP服务器地址
            api_key: API密钥
            local_tools_file: 本地工具文件路径
            debug: 是否输出调试信息
            auto_update: 是否自动更新本地工具文件
        """
        self.server_url = server_url.rstrip('/')
        self.api_key = api_key
        self.local_tools_file = local_tools_file
        self.debug = debug
        self.auto_update = auto_update
    
    def _print_debug(self, message: str):
        """打印调试信息（仅在debug=True时输出）"""
        if self.debug:
            print(f"[DEBUG] {message}")
    
    def _print_info(self, message: str):
        """打印信息（始终输出）"""
        print(f"[INFO] {message}")
    
    def discover_tools(self) -> List[str]:
        """
        从LMCP服务器发现工具
        如果auto_update=False且本地文件存在，则直接使用本地工具
        如果auto_update=True或本地文件不存在，则尝试从服务器获取
        
        Returns:
            List[str]: 工具代码列表
        """
        # 检查是否应该直接使用本地工具
        if not self.auto_update and os.path.exists(self.local_tools_file):
            self._print_info(f"auto_update=False，使用本地工具文件: {self.local_tools_file}")
            try:
                with open(self.local_tools_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 提取所有函数和类代码
                local_tools = []
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    # 提取函数定义
                    if isinstance(node, ast.FunctionDef):
                        func_code = ast.unparse(node)
                        local_tools.append(func_code)
                    # 提取类定义
                    elif isinstance(node, ast.ClassDef):
                        class_code = ast.unparse(node)
                        local_tools.append(class_code)
                
                self._print_info(f"加载 {len(local_tools)} 个本地工具（包含函数和类）")
                return local_tools
                
            except Exception as e:
                self._print_info(f"加载本地工具失败: {e}")
                # 加载失败，继续尝试从服务器获取
        
        # auto_update=True 或本地文件不存在，尝试从服务器获取
        self._print_info(f"从服务器发现工具...")
        
        try:
            response = requests.get(
                f"{self.server_url}/api/tools/discover",
                headers={"X-API-Key": self.api_key},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    tools = data.get("tools", [])
                    self._print_info(f"发现 {len(tools)} 个工具")
                    return tools
                else:
                    self._print_info(f"发现失败: {data.get('error')}")
            elif response.status_code == 401:
                self._print_info(f"认证失败 (HTTP 401): API密钥可能无效或缺失")
            elif response.status_code == 404:
                self._print_info(f"端点未找到 (HTTP 404): 请检查服务器URL和端点路径")
            else:
                self._print_info(f"HTTP错误 {response.status_code}: 服务器返回错误状态")
                
        except requests.exceptions.ConnectionError as e:
            self._print_info(f"连接失败: 无法连接到服务器 {self.server_url}")
            self._print_info(f"错误详情: {e}")
        except requests.exceptions.Timeout as e:
            self._print_info(f"连接超时: 服务器响应时间过长")
        except Exception as e:
            self._print_info(f"请求失败: {e}")
        
        # 服务器请求失败，回退到本地工具（如果存在）
        self._print_info("服务器请求失败，尝试使用本地工具")
        if os.path.exists(self.local_tools_file):
            self._print_info(f"使用本地工具文件: {self.local_tools_file}")
            try:
                with open(self.local_tools_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 提取所有函数和类代码
                local_tools = []
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    # 提取函数定义
                    if isinstance(node, ast.FunctionDef):
                        func_code = ast.unparse(node)
                        local_tools.append(func_code)
                    # 提取类定义
                    elif isinstance(node, ast.ClassDef):
                        class_code = ast.unparse(node)
                        local_tools.append(class_code)
                
                self._print_info(f"加载 {len(local_tools)} 个本地工具（包含函数和类）")
                return local_tools
                
            except Exception as e:
                self._print_info(f"加载本地工具失败: {e}")
        else:
            self._print_info(f"本地工具文件不存在: {self.local_tools_file}")
        
        return []
    
    def _extract_tool_name(self, code: str) -> str:
        """从代码中提取工具名（函数名或类名）"""
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    return node.name
                elif isinstance(node, ast.ClassDef):
                    return node.name
        except:
            pass
        return ""
    
    def _extract_tool_code(self, code: str) -> str:
        """从代码中提取完整的工具定义（函数或类）"""
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) or isinstance(node, ast.ClassDef):
                    return ast.unparse(node)
        except:
            pass
        return code
    
    def _compare_tools(self, tool1: str, tool2: str) -> bool:
        """比较两个工具是否相同"""
        name1 = self._extract_tool_name(tool1)
        name2 = self._extract_tool_name(tool2)
        
        if name1 != name2:
            return False
        
        code1 = self._extract_tool_code(tool1)
        code2 = self._extract_tool_code(tool2)
        
        return code1.strip() == code2.strip()
    
    def _load_local_tools(self) -> Dict[str, str]:
        """加载本地工具文件中的函数和类"""
        local_tools = {}
        
        if not os.path.exists(self.local_tools_file):
            self._print_debug(f"{self.local_tools_file} 不存在")
            return local_tools
        
        try:
            with open(self.local_tools_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 解析所有函数和类
            tree = ast.parse(content)
            for node in ast.walk(tree):
                # 提取函数定义
                if isinstance(node, ast.FunctionDef):
                    func_name = node.name
                    func_code = ast.unparse(node)
                    local_tools[func_name] = func_code
                # 提取类定义
                elif isinstance(node, ast.ClassDef):
                    class_name = node.name
                    class_code = ast.unparse(node)
                    local_tools[class_name] = class_code
            
            self._print_debug(f"加载 {len(local_tools)} 个本地工具（包含函数和类）")
            
        except Exception as e:
            self._print_debug(f"加载本地工具失败: {e}")
        
        return local_tools
    
    def build_tools_module(self, server_tools: List[str]) -> str:
        """构建工具模块"""
        self._print_info(f"构建工具模块...")
        
        # 加载本地工具
        local_tools = self._load_local_tools()
        
        # 分析服务器工具
        server_tool_dict = {}
        for tool_code in server_tools:
            tool_name = self._extract_tool_name(tool_code)
            if tool_name:
                server_tool_dict[tool_name] = tool_code
        
        # 合并工具（服务器优先）
        merged_tools = {}
        updated_count = 0
        new_count = 0
        
        # 首先添加所有服务器工具
        for tool_name, tool_code in server_tool_dict.items():
            if tool_name in local_tools:
                # 比较内容
                if self._compare_tools(tool_code, local_tools[tool_name]):
                    # 内容相同，使用本地版本
                    merged_tools[tool_name] = local_tools[tool_name]
                else:
                    # 内容不同，使用服务器版本
                    merged_tools[tool_name] = tool_code
                    updated_count += 1
                    self._print_debug(f"更新工具: {tool_name}")
            else:
                # 新工具
                merged_tools[tool_name] = tool_code
                new_count += 1
                self._print_debug(f"新增工具: {tool_name}")
        
        # 添加本地独有的工具
        for tool_name, tool_code in local_tools.items():
            if tool_name not in merged_tools:
                merged_tools[tool_name] = tool_code
        
        # 生成模块代码
        module_code = '''
"""
自动生成的工具模块
包含从LMCP服务器同步的工具
"""
from langchain_core.tools import BaseTool # lmcp_tool_builder 1.1.2 版之后必须引入，以支持类工具
from pydantic import BaseModel, Field # lmcp_tool_builder 1.1.2 版之后必须引入，以支持类工具
'''
        
        # 按工具名排序
        for tool_name in sorted(merged_tools.keys()):
            module_code += f"\n{merged_tools[tool_name]}\n"
        
        self._print_info(f"构建完成: {len(merged_tools)} 个工具")
        if updated_count > 0:
            self._print_debug(f"更新: {updated_count} 个")
        if new_count > 0:
            self._print_debug(f"新增: {new_count} 个")
        
        return module_code
    
    def save_tools_module(self, module_code: str):
        """保存工具模块到文件"""
        try:
            with open(self.local_tools_file, 'w', encoding='utf-8') as f:
                f.write(module_code)
            self._print_info(f"已保存到 {self.local_tools_file}")
        except Exception as e:
            self._print_info(f"保存失败: {e}")
    
    def load_tools_from_module(self) -> List:
        """从模块中加载工具函数和类工具"""
        tools = []
        
        if not os.path.exists(self.local_tools_file):
            self._print_info(f"{self.local_tools_file} 不存在")
            return tools
        
        try:
            # 动态导入
            spec = importlib.util.spec_from_file_location("bot_tools", self.local_tools_file)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # 获取所有成员
            for name, obj in inspect.getmembers(module):
                # 跳过私有成员和导入的模块/类（如 Field, BaseTool 等）
                if name.startswith('_'):
                    continue
                
                # 跳过导入的类（如 BaseTool, BaseModel, Field 等）
                # 这些通常在模块顶部导入，不是我们定义的工具
                if name in ['BaseTool', 'BaseModel', 'Field']:
                    continue
                
                # 1. 函数工具
                if inspect.isfunction(obj):
                    # 检查是否是真正的函数工具（不是导入的函数）
                    # 通过检查函数是否在模块中定义
                    if hasattr(obj, '__module__') and obj.__module__ == module.__name__:
                        tools.append(obj)
                        self._print_debug(f"加载函数工具: {name}")
                
                # 2. 类工具
                elif inspect.isclass(obj):
                    # 检查是否是在模块中定义的类（不是导入的类）
                    if hasattr(obj, '__module__') and obj.__module__ == module.__name__:
                        # 检查是否继承自 BaseTool（这是 LangChain 工具类的标准基类）
                        is_base_tool_subclass = False
                        try:
                            # 检查类或其父类是否继承自 BaseTool
                            from langchain_core.tools import BaseTool as LangChainBaseTool
                            is_base_tool_subclass = issubclass(obj, LangChainBaseTool)
                        except ImportError:
                            # 如果无法导入 BaseTool，使用其他检测方法
                            pass
                        
                        # 检查是否具有工具的基本要素
                        # 对于类工具，我们需要检查类定义中是否有这些属性
                        # 1. 检查类是否有 name 属性（类变量或实例属性）
                        has_name = False
                        if hasattr(obj, 'name'):
                            name_value = getattr(obj, 'name')
                            if isinstance(name_value, str) and name_value:
                                has_name = True
                        elif 'name' in obj.__annotations__:
                            # 检查类型注解
                            has_name = True
                        
                        # 2. 检查类是否有 description 属性
                        has_description = False
                        if hasattr(obj, 'description'):
                            desc_value = getattr(obj, 'description')
                            if isinstance(desc_value, str) and desc_value:
                                has_description = True
                        elif 'description' in obj.__annotations__:
                            # 检查类型注解
                            has_description = True
                        
                        # 3. 检查是否有 _run 方法
                        has_run = hasattr(obj, '_run') and callable(getattr(obj, '_run', None))
                        
                        # 4. 检查是否有 _arun 方法
                        has_arun = hasattr(obj, '_arun') and callable(getattr(obj, '_arun', None))
                        
                        # 如果是 BaseTool 的子类，或者具有所有工具特征，则认为是类工具
                        if is_base_tool_subclass or (has_name and has_description and has_run and has_arun):
                            try:
                                # 实例化类工具
                                # 对于有必需参数的类，尝试使用默认值或空值
                                try:
                                    tool_instance = obj()
                                except Exception as init_error:
                                    # 如果无参实例化失败，尝试提供默认参数
                                    self._print_debug(f"无参实例化失败，尝试提供默认参数: {init_error}")
                                    # 检查类是否有 __annotations__ 来获取参数信息
                                    if hasattr(obj, '__annotations__'):
                                        # 尝试使用默认值实例化
                                        init_kwargs = {}
                                        for param_name, param_type in obj.__annotations__.items():
                                            if param_name not in ['name', 'description', 'return']:
                                                # 为参数提供默认值
                                                if param_type == str:
                                                    init_kwargs[param_name] = ""
                                                elif param_type == int:
                                                    init_kwargs[param_name] = 0
                                                elif param_type == float:
                                                    init_kwargs[param_name] = 0.0
                                                elif param_type == bool:
                                                    init_kwargs[param_name] = False
                                                else:
                                                    init_kwargs[param_name] = None
                                        tool_instance = obj(**init_kwargs)
                                    else:
                                        # 无法获取参数信息，重新抛出异常
                                        raise init_error
                                
                                tools.append(tool_instance)
                                self._print_debug(f"加载类工具: {name} (实例化)")
                            except Exception as e:
                                self._print_debug(f"实例化类工具 {name} 失败: {e}")
                        else:
                            self._print_debug(f"跳过类 {name}: 缺少工具特征 (BaseTool子类={is_base_tool_subclass}, name={has_name}, desc={has_description}, run={has_run}, arun={has_arun})")
            
            self._print_info(f"加载 {len(tools)} 个工具（包含函数和类）")
            
        except Exception as e:
            self._print_info(f"加载工具失败: {e}")
        
        return tools
    
    def build_and_load_tools(self) -> List:
        """
        构建并加载工具
        主要流程：
        1. 发现工具（已集成本地回退）
        2. 如果是服务器工具，构建并保存模块
        3. 加载工具函数
        
        Returns:
            List: 工具函数列表
        """
        self._print_info("=" * 50)
        self._print_info("LMCP 工具构建")
        self._print_info("=" * 50)
        
        # 1. 发现工具（已集成本地回退）
        tools_list = self.discover_tools()
        
        if not tools_list:
            self._print_info("无可用工具")
            return []
        
        # 2. 判断是否需要构建和保存模块
        # 只有当工具来自服务器时才需要构建和保存模块
        # 如果auto_update=False且本地文件存在，工具来自本地，不需要重新构建
        need_build_module = True
        
        if not self.auto_update and os.path.exists(self.local_tools_file):
            # auto_update=False且本地文件存在，工具应该来自本地
            # 检查工具列表是否包含完整的函数定义（本地工具也会有）
            has_function_def = any('def ' in tool for tool in tools_list)
            if has_function_def:
                # 有函数定义，但来自本地，不需要构建模块
                need_build_module = False
                self._print_info("工具来自本地文件，跳过模块构建")
        
        # 如果需要构建模块（工具来自服务器）
        if need_build_module:
            # 构建工具模块
            module_code = self.build_tools_module(tools_list)
            
            # 保存模块
            self.save_tools_module(module_code)
        
        # 3. 加载工具函数
        tools = self.load_tools_from_module()
        
        return tools
    
    def test_tools(self, tools: List):
        """测试工具函数"""
        if not tools:
            self._print_info("没有可测试的工具")
            return
        
        self._print_info("\n测试工具函数:")
        
        for tool in tools:
            func_name = tool.__name__
            self._print_info(f"\n  {func_name}")
            
            # 获取参数
            sig = inspect.signature(tool)
            params = list(sig.parameters.keys())
            
            # 准备测试参数
            test_args = {}
            if "city" in params:
                test_args["city"] = "北京"
            if "query" in params:
                test_args["query"] = "测试"
            if "text" in params:
                test_args["text"] = "测试文本"
            if "a" in params and "b" in params:
                test_args["a"] = 10
                test_args["b"] = 20
            if "expression" in params:
                test_args["expression"] = "2 + 3"
            
            try:
                if test_args:
                    result = tool(**test_args)
                else:
                    result = tool()
                self._print_info(f"     结果: {result}")
            except Exception as e:
                self._print_info(f"     错误: {e}")
                

if __name__ == "__main__":
    import os
    from dotenv import load_dotenv

    load_dotenv()

    # 到lmcp平台注册创建应用、绑定工具、获得api_key（略）
    print(f'[LMCP] 开始更新工具...')

    # 创建工具构建器
    builder = LMCPToolBuilder(
        server_url="http://aicity.wang:8000",
        api_key=os.getenv("LMCP_API_KEY", "6b3200c9ebdadb063315bb79607b797d943ed825ecb6a6fa91e515d608a08552"),
        local_tools_file=os.getenv("LMCP_LOCAL_TOOLS_FILE", "bot_tools.py"),
        debug=True,
        auto_update=True
    )

    # 构建并加载工具
    tools = builder.build_and_load_tools()
    
    for i in tools:
        # 安全地获取工具名称：优先使用 name 属性，否则使用 __name__
        tool_name = getattr(i, 'name', getattr(i, '__name__', str(i)))
        print(f"工具: {tool_name}")
