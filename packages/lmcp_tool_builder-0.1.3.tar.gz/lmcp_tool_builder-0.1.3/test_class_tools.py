#!/usr/bin/env python3
"""
测试类工具兼容性
验证LMCP工具构建器是否能正确加载和使用类工具
"""

import os
import sys
from lmcp_tool_builder import LMCPToolBuilder

def test_class_tool_compatibility():
    """测试类工具兼容性"""
    print("=" * 60)
    print("测试类工具兼容性")
    print("=" * 60)
    
    # 创建工具构建器
    builder = LMCPToolBuilder(
        server_url="http://aicity.wang:8000",
        api_key="test_key",
        local_tools_file="bot_tools.py",
        debug=True,
        auto_update=False  # 使用本地文件
    )
    
    print("\n1. 加载工具...")
    tools = builder.load_tools_from_module()
    
    print(f"\n2. 加载的工具数量: {len(tools)}")
    
    # 统计函数工具和类工具
    function_tools = []
    class_tools = []
    
    for tool in tools:
        if hasattr(tool, '__name__') and callable(tool):
            # 函数工具
            function_tools.append(tool)
        elif hasattr(tool, 'name') and hasattr(tool, '_run'):
            # 类工具实例
            class_tools.append(tool)
    
    print(f"   函数工具: {len(function_tools)} 个")
    print(f"   类工具: {len(class_tools)} 个")
    
    # 显示工具详情
    print("\n3. 工具详情:")
    for i, tool in enumerate(tools, 1):
        if hasattr(tool, '__name__'):
            # 函数工具
            print(f"   {i}. 函数工具: {tool.__name__}")
            # 显示函数签名
            import inspect
            sig = inspect.signature(tool)
            print(f"      签名: {sig}")
        elif hasattr(tool, 'name'):
            # 类工具
            print(f"   {i}. 类工具: {tool.name}")
            print(f"      描述: {getattr(tool, 'description', '无描述')}")
            print(f"      类型: {type(tool).__name__}")
    
    # 测试类工具功能
    print("\n4. 测试类工具功能:")
    for tool in class_tools:
        print(f"\n   测试工具: {tool.name}")
        try:
            # 测试同步执行
            if hasattr(tool, '_run'):
                result = tool._run("测试输入")
                print(f"      同步执行结果: {result}")
            
            # 检查是否有异步方法
            if hasattr(tool, '_arun'):
                print(f"      支持异步执行: 是")
            else:
                print(f"      支持异步执行: 否")
                
        except Exception as e:
            print(f"      测试失败: {e}")
    
    # 测试向后兼容性 - 确保函数工具仍然工作
    print("\n5. 测试向后兼容性 (函数工具):")
    for tool in function_tools[:2]:  # 只测试前两个函数工具
        if hasattr(tool, '__name__'):
            print(f"\n   测试函数工具: {tool.__name__}")
            try:
                # 根据函数名准备测试参数
                if tool.__name__ == 'calculator':
                    result = tool("2 + 3 * 4")
                elif tool.__name__ == 'get_current_time':
                    result = tool()
                elif 'search' in tool.__name__.lower():
                    result = tool("测试")
                else:
                    # 默认测试
                    import inspect
                    sig = inspect.signature(tool)
                    params = list(sig.parameters.keys())
                    if not params:
                        result = tool()
                    else:
                        # 跳过需要复杂参数的函数
                        result = "跳过测试（需要特定参数）"
                
                print(f"      执行结果: {result}")
            except Exception as e:
                print(f"      测试失败: {e}")
    
    print("\n" + "=" * 60)
    print("测试完成!")
    print("=" * 60)
    
    # 总结
    if len(class_tools) > 0:
        print(f"\n✅ 成功加载 {len(class_tools)} 个类工具")
        return True
    else:
        print(f"\n❌ 未加载到类工具，可能需要检查类工具检测逻辑")
        return False

if __name__ == "__main__":
    # 确保当前目录在Python路径中
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    
    success = test_class_tool_compatibility()
    
    if success:
        print("\n✅ 类工具兼容性测试通过!")
        sys.exit(0)
    else:
        print("\n❌ 类工具兼容性测试失败!")
        sys.exit(1)
