"""LLM-powered entity and relation extraction."""
