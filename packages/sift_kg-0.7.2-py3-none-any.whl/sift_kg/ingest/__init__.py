"""Document ingestion — reading and chunking documents for LLM processing."""
