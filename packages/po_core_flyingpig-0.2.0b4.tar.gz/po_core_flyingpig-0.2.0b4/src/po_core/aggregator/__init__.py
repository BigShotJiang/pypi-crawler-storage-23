"""Aggregator module for combining proposals."""

from po_core.aggregator.weighted_vote import WeightedVoteAggregator

__all__ = ["WeightedVoteAggregator"]
