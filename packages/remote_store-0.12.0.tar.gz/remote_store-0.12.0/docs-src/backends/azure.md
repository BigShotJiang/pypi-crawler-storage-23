{%
   include-markdown "../../guides/backends/azure.md"
   rewrite-relative-urls=false
%}

## API Reference

::: remote_store.backends.AzureBackend
