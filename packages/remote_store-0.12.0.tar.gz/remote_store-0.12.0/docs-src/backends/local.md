{%
   include-markdown "../../guides/backends/local.md"
   rewrite-relative-urls=false
%}

## API Reference

::: remote_store.backends.LocalBackend
