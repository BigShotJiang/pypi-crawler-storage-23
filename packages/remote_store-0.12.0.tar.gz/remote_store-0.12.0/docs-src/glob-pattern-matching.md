{%
   include-markdown "../guides/glob-pattern-matching.md"
   rewrite-relative-urls=false
%}
