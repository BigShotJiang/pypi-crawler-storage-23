# Models

::: remote_store.FileInfo

::: remote_store.FolderInfo
