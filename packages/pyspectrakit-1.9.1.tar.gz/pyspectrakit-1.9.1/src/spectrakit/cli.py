"""SpectraKit command-line interface."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any


def _get_app() -> Any:
    """Lazy-import typer to avoid hard dependency."""
    try:
        import typer
    except ImportError:
        print(
            "CLI requires typer. Install with: pip install spectrakit[cli]",
            file=sys.stderr,
        )
        sys.exit(1)
    return typer.Typer(
        name="spectrakit",
        help="SpectraKit: spectral data processing toolkit.",
        add_completion=False,
    )


app = _get_app()


@app.command()  # type: ignore[untyped-decorator]
def info(path: str) -> None:
    """Print metadata and summary statistics for a spectral file."""
    from spectrakit.io.auto import read_spectrum

    file_path = Path(path)

    try:
        spec = read_spectrum(file_path)
    except (FileNotFoundError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)

    print(f"File:       {file_path.name}")
    print(f"Format:     {spec.source_format}")
    print(f"Shape:      {spec.shape}")
    print(f"N spectra:  {spec.n_spectra}")
    print(f"N points:   {spec.n_points}")
    if spec.wavenumbers is not None:
        print(f"X range:    {spec.wavenumbers.min():.2f} - {spec.wavenumbers.max():.2f}")
    print(f"Y range:    {spec.intensities.min():.6f} - {spec.intensities.max():.6f}")
    print(f"Y mean:     {spec.intensities.mean():.6f}")
    print(f"Y std:      {spec.intensities.std():.6f}")
    if spec.metadata:
        print("Metadata:")
        for key, value in list(spec.metadata.items())[:10]:
            print(f"  {key}: {value}")


@app.command()  # type: ignore[untyped-decorator]
def convert(input_path: str, output_path: str) -> None:
    """Convert a spectral file to HDF5 format."""
    from spectrakit.io.auto import read_spectrum

    file_path = Path(input_path)

    try:
        spec = read_spectrum(file_path)
    except (FileNotFoundError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)

    from spectrakit.io.hdf5 import write_hdf5

    write_hdf5(spec, output_path)
    print(f"Converted {file_path.name} -> {output_path}")


if __name__ == "__main__":  # pragma: no cover
    app()
