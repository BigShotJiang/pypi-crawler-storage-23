#!/usr/bin/env python3
"""Generate a Telegram session string for the MCP server.

This script authenticates with Telegram and generates a session string
that can be used with the MCP server.

Usage:
    uv run scripts/generate_session.py
"""

import os
import sys
import asyncio

from telethon import TelegramClient
from telethon.sessions import StringSession


async def generate_session():
    """Interactive session string generator."""
    print("=" * 60)
    print("Telegram Session String Generator")
    print("=" * 60)
    print()
    print("This script will help you generate a session string for")
    print("authenticating with Telegram.")
    print()
    print("You'll need your API credentials from https://my.telegram.org/apps")
    print()

    # Get API credentials
    api_id = os.environ.get("TELEGRAM_API_ID")
    api_hash = os.environ.get("TELEGRAM_API_HASH")

    if not api_id:
        api_id = input("Enter your API ID: ").strip()
    else:
        print(f"Using API ID from environment: {api_id}")

    if not api_hash:
        api_hash = input("Enter your API Hash: ").strip()
    else:
        print(f"Using API Hash from environment: {api_hash[:8]}...")

    try:
        api_id = int(api_id)
    except ValueError:
        print("Error: API ID must be a number")
        sys.exit(1)

    print()
    print("Connecting to Telegram...")

    # Create client with empty session (will generate new one)
    client = TelegramClient(
        StringSession(),
        api_id,
        api_hash,
        device_model="Claude Code MCP",
        app_version="1.0.0",
    )

    await client.connect()

    if not await client.is_user_authorized():
        print()
        phone = input("Enter your phone number (with country code, e.g., +1234567890): ").strip()

        await client.send_code_request(phone)
        print()
        print("A verification code has been sent to your Telegram account.")

        code = input("Enter the verification code: ").strip()

        try:
            await client.sign_in(phone, code)
        except Exception as e:
            error_name = type(e).__name__
            if "SessionPasswordNeeded" in error_name or "Two-step verification" in str(e) or "2FA" in str(e) or "password" in str(e).lower():
                print()
                print("Two-factor authentication is enabled.")
                password = input("Enter your 2FA password: ").strip()
                await client.sign_in(password=password)
            else:
                raise

    # Get session string
    session_string = client.session.save()

    # Get user info
    me = await client.get_me()

    print()
    print("=" * 60)
    print("SUCCESS! Session generated.")
    print("=" * 60)
    print()
    print(f"Logged in as: {me.first_name} (@{me.username or 'no username'})")
    print()
    print("Your session string (keep this secret!):")
    print("-" * 60)
    print(session_string)
    print("-" * 60)
    print()

    # Offer to save to .env file
    save_to_env = input("Save to .env file? (y/n): ").strip().lower()

    if save_to_env == 'y':
        env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env")

        env_content = f"""# Telegram API credentials
TELEGRAM_API_ID={api_id}
TELEGRAM_API_HASH={api_hash}
TELEGRAM_SESSION_STRING={session_string}
"""
        with open(env_path, 'w') as f:
            f.write(env_content)

        print(f"Saved to: {env_path}")
        print()
        print("IMPORTANT: Keep your .env file secure and never commit it to git!")

    print()
    print("Next steps:")
    print("1. Add the MCP server to Claude Code:")
    print("   claude mcp add telegram -- uv --directory ~/telegram-mcp run src/server.py")
    print()
    print("2. Set environment variables (if not using .env):")
    print("   export TELEGRAM_API_ID=<your-api-id>")
    print("   export TELEGRAM_API_HASH=<your-api-hash>")
    print("   export TELEGRAM_SESSION_STRING=<your-session-string>")
    print()

    await client.disconnect()


def main():
    """Entry point."""
    asyncio.run(generate_session())


if __name__ == "__main__":
    main()
