"""Scripts for Telegram MCP."""
