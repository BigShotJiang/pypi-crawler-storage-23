"""Advanced tools for Telegram MCP (reactions, polls, scheduled messages, etc.)."""

import json
from typing import Optional, List
from datetime import datetime

from telethon.tl.functions.messages import (
    SendReactionRequest,
    GetScheduledHistoryRequest,
    DeleteScheduledMessagesRequest,
    SaveDraftRequest,
    GetAllDraftsRequest,
    SetTypingRequest,
    ReadHistoryRequest,
    SendVoteRequest,
)
from telethon.tl.types import (
    ReactionEmoji,
    InputMediaPoll,
    Poll,
    PollAnswer,
    SendMessageTypingAction,
    SendMessageCancelAction,
    UpdateDraftMessage,
)

from src.client import get_client as get_client_async
from src.utils.validators import parse_chat_id, parse_message_id, parse_limit
from src.utils.formatters import format_message


async def send_reaction(
    chat_id: str,
    message_id: str,
    emoji: str,
    big: bool = False,
) -> str:
    """React to a message with an emoji.

    Args:
        chat_id: Chat ID or username
        message_id: ID of the message to react to
        emoji: Reaction emoji (e.g., "👍", "❤️", "😂", "🔥", "👏")
        big: If True, show a big animated reaction

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    msg_id = parse_message_id(message_id)

    chat_entity = await client.get_entity(chat)

    # Empty emoji removes reaction
    reaction = [ReactionEmoji(emoticon=emoji)] if emoji else []

    await client(SendReactionRequest(
        peer=chat_entity,
        msg_id=msg_id,
        reaction=reaction,
        big=big,
    ))

    return json.dumps({
        "success": True,
        "action": "reacted" if emoji else "removed_reaction",
        "emoji": emoji,
        "message_id": msg_id,
    }, indent=2)


async def create_poll(
    chat_id: str,
    question: str,
    options: str,
    anonymous: bool = True,
    multiple_choice: bool = False,
    quiz: bool = False,
    correct_option: Optional[int] = None,
) -> str:
    """Create and send a poll.

    Args:
        chat_id: Chat ID or username
        question: Poll question
        options: Comma-separated poll options (e.g., "Option 1,Option 2,Option 3")
        anonymous: If True, votes are anonymous
        multiple_choice: If True, allow multiple answers
        quiz: If True, create a quiz with a correct answer
        correct_option: Index of correct option (0-based, required if quiz=True)

    Returns:
        JSON string with sent poll details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    option_list = [opt.strip() for opt in options.split(",")]

    if len(option_list) < 2:
        return json.dumps({
            "success": False,
            "error": "At least 2 options are required",
        }, indent=2)

    if len(option_list) > 10:
        return json.dumps({
            "success": False,
            "error": "Maximum 10 options allowed",
        }, indent=2)

    if quiz and correct_option is None:
        return json.dumps({
            "success": False,
            "error": "correct_option is required for quiz polls",
        }, indent=2)

    poll_answers = [
        PollAnswer(text=opt, option=bytes([i]))
        for i, opt in enumerate(option_list)
    ]

    poll = Poll(
        id=0,
        question=question,
        answers=poll_answers,
        public_voters=not anonymous,
        multiple_choice=multiple_choice,
        quiz=quiz,
    )

    message = await client.send_file(
        chat,
        InputMediaPoll(
            poll=poll,
            correct_answers=[bytes([correct_option])] if quiz and correct_option is not None else None,
        ),
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
        "poll_type": "quiz" if quiz else "regular",
    }, indent=2)


async def schedule_message(
    chat_id: str,
    text: str,
    schedule_time: int,
    parse_mode: str = "markdown",
) -> str:
    """Schedule a message to be sent at a future time.

    Args:
        chat_id: Chat ID or username
        text: Message text
        schedule_time: Unix timestamp for when to send the message
        parse_mode: Text formatting: "markdown", "html", or "text"

    Returns:
        JSON string with scheduled message details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    schedule_dt = datetime.fromtimestamp(schedule_time)

    if schedule_dt <= datetime.now():
        return json.dumps({
            "success": False,
            "error": "Schedule time must be in the future",
        }, indent=2)

    pm = None
    if parse_mode.lower() == "markdown":
        pm = "md"
    elif parse_mode.lower() == "html":
        pm = "html"

    message = await client.send_message(
        chat,
        text,
        parse_mode=pm,
        schedule=schedule_dt,
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
        "scheduled_for": schedule_dt.isoformat(),
    }, indent=2)


async def get_scheduled_messages(chat_id: str) -> str:
    """Get all scheduled messages in a chat.

    Args:
        chat_id: Chat ID or username

    Returns:
        JSON string with list of scheduled messages
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    chat_entity = await client.get_entity(chat)

    result = await client(GetScheduledHistoryRequest(
        peer=chat_entity,
        hash=0,
    ))

    messages = [format_message(m) for m in result.messages]

    return json.dumps({
        "success": True,
        "count": len(messages),
        "scheduled_messages": messages,
    }, indent=2)


async def delete_scheduled_message(
    chat_id: str,
    message_ids: str,
) -> str:
    """Delete scheduled messages.

    Args:
        chat_id: Chat ID or username
        message_ids: Comma-separated IDs of scheduled messages to delete

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    chat_entity = await client.get_entity(chat)
    ids = [parse_message_id(mid.strip()) for mid in message_ids.split(",")]

    await client(DeleteScheduledMessagesRequest(
        peer=chat_entity,
        id=ids,
    ))

    return json.dumps({
        "success": True,
        "action": "deleted",
        "message_ids": ids,
    }, indent=2)


async def set_typing(
    chat_id: str,
    typing: bool = True,
) -> str:
    """Show or hide typing indicator.

    Args:
        chat_id: Chat ID or username
        typing: If True, show typing; if False, cancel typing indicator

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    chat_entity = await client.get_entity(chat)

    action = SendMessageTypingAction() if typing else SendMessageCancelAction()

    await client(SetTypingRequest(
        peer=chat_entity,
        action=action,
    ))

    return json.dumps({
        "success": True,
        "action": "typing" if typing else "stopped_typing",
        "chat_id": str(chat),
    }, indent=2)


async def mark_as_read(
    chat_id: str,
    max_id: Optional[int] = None,
) -> str:
    """Mark messages as read in a chat.

    Args:
        chat_id: Chat ID or username
        max_id: Mark all messages up to this ID as read (default: all)

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    chat_entity = await client.get_entity(chat)

    if max_id is None:
        # Get the latest message ID
        messages = await client.get_messages(chat_entity, limit=1)
        max_id = messages[0].id if messages else 0

    await client(ReadHistoryRequest(
        peer=chat_entity,
        max_id=max_id,
    ))

    return json.dumps({
        "success": True,
        "action": "marked_read",
        "chat_id": str(chat),
        "up_to_message_id": max_id,
    }, indent=2)


async def get_drafts() -> str:
    """Get all saved message drafts.

    Returns:
        JSON string with list of drafts
    """
    client = await get_client_async()

    result = await client(GetAllDraftsRequest())

    drafts = []
    for update in result.updates:
        if isinstance(update, UpdateDraftMessage):
            draft_info = {
                "chat_id": update.peer,
                "text": update.draft.message if hasattr(update.draft, 'message') else None,
                "date": update.draft.date.isoformat() if hasattr(update.draft, 'date') and update.draft.date else None,
                "reply_to_msg_id": update.draft.reply_to_msg_id if hasattr(update.draft, 'reply_to_msg_id') else None,
            }
            drafts.append(draft_info)

    return json.dumps({
        "success": True,
        "count": len(drafts),
        "drafts": drafts,
    }, indent=2)


async def save_draft(
    chat_id: str,
    text: str,
    reply_to_msg_id: Optional[int] = None,
) -> str:
    """Save a message draft.

    Args:
        chat_id: Chat ID or username
        text: Draft message text
        reply_to_msg_id: Optional message ID to reply to

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    chat_entity = await client.get_entity(chat)

    from telethon.tl.types import DraftMessage, InputReplyToMessage

    reply_to = None
    if reply_to_msg_id:
        reply_to = InputReplyToMessage(reply_to_msg_id=reply_to_msg_id)

    await client(SaveDraftRequest(
        peer=chat_entity,
        message=text,
        reply_to=reply_to,
    ))

    return json.dumps({
        "success": True,
        "action": "draft_saved",
        "chat_id": str(chat),
        "text": text[:100] + "..." if len(text) > 100 else text,
    }, indent=2)
