"""Messaging tools for Telegram MCP."""

import json
from typing import Optional, List

from telethon.tl.types import Message

from src.client import get_client as get_client_async
from src.utils.validators import parse_chat_id, parse_message_id, parse_limit
from src.utils.formatters import format_message


async def send_message(
    chat_id: str,
    text: str,
    parse_mode: str = "markdown",
    disable_preview: bool = False,
) -> str:
    """Send a text message to a Telegram chat.

    Args:
        chat_id: Chat ID or username (e.g., "@username" or "123456789")
        text: Message text to send (supports markdown formatting)
        parse_mode: Text formatting mode: "markdown", "html", or "text"
        disable_preview: If True, disable link preview in message

    Returns:
        JSON string with sent message details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    pm = None
    if parse_mode.lower() == "markdown":
        pm = "md"
    elif parse_mode.lower() == "html":
        pm = "html"

    message = await client.send_message(
        chat,
        text,
        parse_mode=pm,
        link_preview=not disable_preview,
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
    }, indent=2)


async def edit_message(
    chat_id: str,
    message_id: str,
    new_text: str,
    parse_mode: str = "markdown",
) -> str:
    """Edit an existing message.

    Args:
        chat_id: Chat ID or username
        message_id: ID of the message to edit
        new_text: New text for the message
        parse_mode: Text formatting mode: "markdown", "html", or "text"

    Returns:
        JSON string with edited message details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    msg_id = parse_message_id(message_id)

    pm = None
    if parse_mode.lower() == "markdown":
        pm = "md"
    elif parse_mode.lower() == "html":
        pm = "html"

    message = await client.edit_message(
        chat,
        msg_id,
        new_text,
        parse_mode=pm,
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
    }, indent=2)


async def delete_message(
    chat_id: str,
    message_ids: str,
    revoke: bool = True,
) -> str:
    """Delete one or more messages.

    Args:
        chat_id: Chat ID or username
        message_ids: Comma-separated message IDs to delete (e.g., "123,456,789")
        revoke: If True, delete for everyone; if False, delete only for yourself

    Returns:
        JSON string with deletion result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    ids = [parse_message_id(mid.strip()) for mid in message_ids.split(",")]

    result = await client.delete_messages(chat, ids, revoke=revoke)

    return json.dumps({
        "success": True,
        "deleted_count": len(result) if result else len(ids),
        "message_ids": ids,
    }, indent=2)


async def forward_message(
    from_chat_id: str,
    to_chat_id: str,
    message_ids: str,
) -> str:
    """Forward messages from one chat to another.

    Args:
        from_chat_id: Source chat ID or username
        to_chat_id: Destination chat ID or username
        message_ids: Comma-separated message IDs to forward

    Returns:
        JSON string with forwarded message details
    """
    client = await get_client_async()
    from_chat = parse_chat_id(from_chat_id)
    to_chat = parse_chat_id(to_chat_id)

    ids = [parse_message_id(mid.strip()) for mid in message_ids.split(",")]

    messages = await client.forward_messages(to_chat, ids, from_chat)

    if isinstance(messages, Message):
        messages = [messages]

    return json.dumps({
        "success": True,
        "forwarded_count": len(messages),
        "messages": [format_message(m) for m in messages],
    }, indent=2)


async def reply_to_message(
    chat_id: str,
    message_id: str,
    text: str,
    parse_mode: str = "markdown",
) -> str:
    """Reply to a specific message.

    Args:
        chat_id: Chat ID or username
        message_id: ID of the message to reply to
        text: Reply text
        parse_mode: Text formatting mode: "markdown", "html", or "text"

    Returns:
        JSON string with reply message details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    msg_id = parse_message_id(message_id)

    pm = None
    if parse_mode.lower() == "markdown":
        pm = "md"
    elif parse_mode.lower() == "html":
        pm = "html"

    message = await client.send_message(
        chat,
        text,
        reply_to=msg_id,
        parse_mode=pm,
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
    }, indent=2)


async def get_messages(
    chat_id: str,
    limit: int = 20,
    offset_id: Optional[int] = None,
    min_id: Optional[int] = None,
    max_id: Optional[int] = None,
) -> str:
    """Get recent messages from a chat.

    Args:
        chat_id: Chat ID or username
        limit: Maximum number of messages to retrieve (1-100, default: 20)
        offset_id: Offset message ID for pagination
        min_id: Minimum message ID to fetch
        max_id: Maximum message ID to fetch

    Returns:
        JSON string with list of messages
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    limit = parse_limit(limit, default=20, max_limit=100)

    messages = await client.get_messages(
        chat,
        limit=limit,
        offset_id=offset_id,
        min_id=min_id,
        max_id=max_id,
    )

    return json.dumps({
        "success": True,
        "count": len(messages),
        "messages": [format_message(m) for m in messages],
    }, indent=2)


async def search_messages(
    query: str,
    chat_id: Optional[str] = None,
    limit: int = 20,
    from_user: Optional[str] = None,
) -> str:
    """Search for messages containing specific text.

    Args:
        query: Search query text
        chat_id: Optional chat ID to search in (searches globally if not provided)
        limit: Maximum number of results (1-100, default: 20)
        from_user: Optional user ID/username to filter by sender

    Returns:
        JSON string with search results
    """
    client = await get_client_async()
    limit = parse_limit(limit, default=20, max_limit=100)

    chat = parse_chat_id(chat_id) if chat_id else None
    from_entity = parse_chat_id(from_user) if from_user else None

    messages = await client.get_messages(
        chat,
        limit=limit,
        search=query,
        from_user=from_entity,
    )

    return json.dumps({
        "success": True,
        "query": query,
        "count": len(messages),
        "messages": [format_message(m) for m in messages],
    }, indent=2)


async def pin_message(
    chat_id: str,
    message_id: str,
    unpin: bool = False,
    notify: bool = False,
) -> str:
    """Pin or unpin a message in a chat.

    Args:
        chat_id: Chat ID or username
        message_id: ID of the message to pin/unpin
        unpin: If True, unpin the message instead of pinning
        notify: If True, notify all members about the pin

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    msg_id = parse_message_id(message_id)

    if unpin:
        await client.unpin_message(chat, msg_id)
        action = "unpinned"
    else:
        await client.pin_message(chat, msg_id, notify=notify)
        action = "pinned"

    return json.dumps({
        "success": True,
        "action": action,
        "message_id": msg_id,
        "chat_id": str(chat),
    }, indent=2)
