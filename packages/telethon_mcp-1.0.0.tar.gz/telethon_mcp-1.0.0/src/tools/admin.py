"""Admin/moderation tools for Telegram MCP."""

import json
import os
from typing import Optional
from datetime import datetime, timedelta

from telethon.tl.functions.channels import (
    EditBannedRequest,
    EditAdminRequest,
    EditTitleRequest,
    EditPhotoRequest,
    InviteToChannelRequest,
    GetParticipantsRequest,
)
from telethon.tl.functions.messages import (
    AddChatUserRequest,
    DeleteChatUserRequest,
    EditChatAdminRequest,
)
from telethon.tl.types import (
    ChatBannedRights,
    ChatAdminRights,
    ChannelParticipantsSearch,
    InputChatUploadedPhoto,
)

from src.client import get_client as get_client_async
from src.utils.validators import parse_chat_id, parse_limit
from src.utils.formatters import format_user, format_participant


async def ban_user(
    chat_id: str,
    user_id: str,
    until_date: Optional[int] = None,
) -> str:
    """Ban a user from a group/channel.

    Args:
        chat_id: Chat ID or username
        user_id: User ID or username to ban
        until_date: Unix timestamp until when the ban lasts (default: forever)

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    user = parse_chat_id(user_id)

    chat_entity = await client.get_entity(chat)
    user_entity = await client.get_entity(user)

    if until_date:
        until_dt = datetime.fromtimestamp(until_date)
    else:
        until_dt = datetime.now() + timedelta(days=366)  # Essentially forever

    rights = ChatBannedRights(
        until_date=until_dt,
        view_messages=True,
        send_messages=True,
        send_media=True,
        send_stickers=True,
        send_gifs=True,
        send_games=True,
        send_inline=True,
        embed_links=True,
    )

    await client(EditBannedRequest(
        channel=chat_entity,
        participant=user_entity,
        banned_rights=rights,
    ))

    return json.dumps({
        "success": True,
        "action": "banned",
        "user_id": str(user),
        "chat_id": str(chat),
    }, indent=2)


async def unban_user(chat_id: str, user_id: str) -> str:
    """Unban a user from a group/channel.

    Args:
        chat_id: Chat ID or username
        user_id: User ID or username to unban

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    user = parse_chat_id(user_id)

    chat_entity = await client.get_entity(chat)
    user_entity = await client.get_entity(user)

    rights = ChatBannedRights(
        until_date=None,
        view_messages=False,
    )

    await client(EditBannedRequest(
        channel=chat_entity,
        participant=user_entity,
        banned_rights=rights,
    ))

    return json.dumps({
        "success": True,
        "action": "unbanned",
        "user_id": str(user),
        "chat_id": str(chat),
    }, indent=2)


async def kick_user(chat_id: str, user_id: str) -> str:
    """Kick a user from a group (they can rejoin).

    Args:
        chat_id: Chat ID or username
        user_id: User ID or username to kick

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    user = parse_chat_id(user_id)

    chat_entity = await client.get_entity(chat)
    user_entity = await client.get_entity(user)

    # For channels/supergroups
    if hasattr(chat_entity, 'megagroup') or hasattr(chat_entity, 'broadcast'):
        # Ban and immediately unban = kick
        rights = ChatBannedRights(
            until_date=datetime.now() + timedelta(seconds=30),
            view_messages=True,
        )
        await client(EditBannedRequest(
            channel=chat_entity,
            participant=user_entity,
            banned_rights=rights,
        ))
    else:
        # For regular groups
        await client(DeleteChatUserRequest(
            chat_id=chat_entity.id,
            user_id=user_entity,
        ))

    return json.dumps({
        "success": True,
        "action": "kicked",
        "user_id": str(user),
        "chat_id": str(chat),
    }, indent=2)


async def promote_admin(
    chat_id: str,
    user_id: str,
    title: str = "",
    can_change_info: bool = True,
    can_delete_messages: bool = True,
    can_ban_users: bool = True,
    can_invite_users: bool = True,
    can_pin_messages: bool = True,
    can_manage_call: bool = True,
) -> str:
    """Promote a user to admin.

    Args:
        chat_id: Chat ID or username
        user_id: User ID or username to promote
        title: Custom admin title (optional)
        can_change_info: Can change group info
        can_delete_messages: Can delete other's messages
        can_ban_users: Can ban/restrict users
        can_invite_users: Can add users
        can_pin_messages: Can pin messages
        can_manage_call: Can manage voice chats

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    user = parse_chat_id(user_id)

    chat_entity = await client.get_entity(chat)
    user_entity = await client.get_entity(user)

    rights = ChatAdminRights(
        change_info=can_change_info,
        delete_messages=can_delete_messages,
        ban_users=can_ban_users,
        invite_users=can_invite_users,
        pin_messages=can_pin_messages,
        manage_call=can_manage_call,
        add_admins=False,  # Safer default
    )

    await client(EditAdminRequest(
        channel=chat_entity,
        user_id=user_entity,
        admin_rights=rights,
        rank=title,
    ))

    return json.dumps({
        "success": True,
        "action": "promoted",
        "user_id": str(user),
        "chat_id": str(chat),
        "title": title,
    }, indent=2)


async def demote_admin(chat_id: str, user_id: str) -> str:
    """Remove admin rights from a user.

    Args:
        chat_id: Chat ID or username
        user_id: User ID or username to demote

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    user = parse_chat_id(user_id)

    chat_entity = await client.get_entity(chat)
    user_entity = await client.get_entity(user)

    # Empty rights = regular member
    rights = ChatAdminRights()

    await client(EditAdminRequest(
        channel=chat_entity,
        user_id=user_entity,
        admin_rights=rights,
        rank="",
    ))

    return json.dumps({
        "success": True,
        "action": "demoted",
        "user_id": str(user),
        "chat_id": str(chat),
    }, indent=2)


async def set_chat_title(chat_id: str, title: str) -> str:
    """Change a chat's title.

    Args:
        chat_id: Chat ID or username
        title: New title for the chat

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    chat_entity = await client.get_entity(chat)

    await client(EditTitleRequest(
        channel=chat_entity,
        title=title,
    ))

    return json.dumps({
        "success": True,
        "action": "title_changed",
        "chat_id": str(chat),
        "new_title": title,
    }, indent=2)


async def set_chat_photo(chat_id: str, file_path: str) -> str:
    """Change a chat's photo.

    Args:
        chat_id: Chat ID or username
        file_path: Absolute path to the new photo

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    if not os.path.exists(file_path):
        return json.dumps({
            "success": False,
            "error": f"File not found: {file_path}",
        }, indent=2)

    chat_entity = await client.get_entity(chat)

    # Upload the photo first
    uploaded_file = await client.upload_file(file_path)

    await client(EditPhotoRequest(
        channel=chat_entity,
        photo=InputChatUploadedPhoto(file=uploaded_file),
    ))

    return json.dumps({
        "success": True,
        "action": "photo_changed",
        "chat_id": str(chat),
    }, indent=2)


async def get_participants(
    chat_id: str,
    limit: int = 100,
    search: str = "",
) -> str:
    """Get list of chat participants/members.

    Args:
        chat_id: Chat ID or username
        limit: Maximum number of participants (1-200, default: 100)
        search: Optional search query to filter by name

    Returns:
        JSON string with list of participants
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    limit = parse_limit(limit, default=100, max_limit=200)

    chat_entity = await client.get_entity(chat)

    participants = await client.get_participants(
        chat_entity,
        limit=limit,
        search=search,
    )

    return json.dumps({
        "success": True,
        "count": len(participants),
        "participants": [format_participant(p) for p in participants],
    }, indent=2)


async def invite_user(chat_id: str, user_ids: str) -> str:
    """Invite users to a chat.

    Args:
        chat_id: Chat ID or username
        user_ids: Comma-separated user IDs or usernames to invite

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    chat_entity = await client.get_entity(chat)
    users = [parse_chat_id(u.strip()) for u in user_ids.split(",")]
    user_entities = [await client.get_entity(u) for u in users]

    if hasattr(chat_entity, 'megagroup') or hasattr(chat_entity, 'broadcast'):
        await client(InviteToChannelRequest(
            channel=chat_entity,
            users=user_entities,
        ))
    else:
        for user_entity in user_entities:
            await client(AddChatUserRequest(
                chat_id=chat_entity.id,
                user_id=user_entity,
                fwd_limit=50,
            ))

    return json.dumps({
        "success": True,
        "action": "invited",
        "chat_id": str(chat),
        "users_invited": len(user_entities),
    }, indent=2)
