"""Chat management tools for Telegram MCP."""

import json
from typing import Optional
from datetime import datetime, timedelta

from telethon.tl.functions.messages import (
    CreateChatRequest,
    EditChatTitleRequest,
)
from telethon.tl.functions.channels import (
    CreateChannelRequest,
    JoinChannelRequest,
    LeaveChannelRequest,
)
from telethon.tl.functions.account import UpdateNotifySettingsRequest
from telethon.tl.types import InputPeerNotifySettings, InputNotifyPeer

from src.client import get_client as get_client_async
from src.utils.validators import parse_chat_id, parse_limit
from src.utils.formatters import format_dialog, format_chat


async def list_chats(
    limit: int = 50,
    archived: bool = False,
    folder_id: Optional[int] = None,
) -> str:
    """List all chats/dialogs.

    Args:
        limit: Maximum number of chats to retrieve (1-200, default: 50)
        archived: If True, list only archived chats
        folder_id: Optional folder ID to filter by

    Returns:
        JSON string with list of chats
    """
    client = await get_client_async()
    limit = parse_limit(limit, default=50, max_limit=200)

    dialogs = await client.get_dialogs(
        limit=limit,
        archived=archived,
        folder=folder_id,
    )

    return json.dumps({
        "success": True,
        "count": len(dialogs),
        "chats": [format_dialog(d) for d in dialogs],
    }, indent=2)


async def get_chat_info(chat_id: str) -> str:
    """Get detailed information about a chat.

    Args:
        chat_id: Chat ID or username

    Returns:
        JSON string with chat details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    entity = await client.get_entity(chat)
    full_chat = await client.get_entity(chat)

    info = format_chat(entity)

    # Try to get additional info
    try:
        if hasattr(entity, 'photo') and entity.photo:
            info["has_photo"] = True
        if hasattr(entity, 'about'):
            info["about"] = entity.about
        if hasattr(entity, 'participants_count'):
            info["participants_count"] = entity.participants_count
    except Exception:
        pass

    return json.dumps({
        "success": True,
        "chat": info,
    }, indent=2)


async def create_group(
    title: str,
    users: str,
) -> str:
    """Create a new group chat.

    Args:
        title: Group title/name
        users: Comma-separated user IDs or usernames to add

    Returns:
        JSON string with created group details
    """
    client = await get_client_async()

    user_list = [parse_chat_id(u.strip()) for u in users.split(",")]
    user_entities = [await client.get_entity(u) for u in user_list]

    result = await client(CreateChatRequest(
        users=user_entities,
        title=title,
    ))

    chat = result.chats[0]

    return json.dumps({
        "success": True,
        "chat": format_chat(chat),
    }, indent=2)


async def create_channel(
    title: str,
    about: str = "",
    megagroup: bool = False,
) -> str:
    """Create a new channel or supergroup.

    Args:
        title: Channel/supergroup title
        about: Channel description
        megagroup: If True, create a supergroup instead of channel

    Returns:
        JSON string with created channel details
    """
    client = await get_client_async()

    result = await client(CreateChannelRequest(
        title=title,
        about=about,
        megagroup=megagroup,
        broadcast=not megagroup,
    ))

    channel = result.chats[0]

    return json.dumps({
        "success": True,
        "chat": format_chat(channel),
        "type": "supergroup" if megagroup else "channel",
    }, indent=2)


async def join_chat(invite_link: str) -> str:
    """Join a chat using an invite link or username.

    Args:
        invite_link: Invite link (t.me/+xxx or t.me/joinchat/xxx) or @username

    Returns:
        JSON string with joined chat details
    """
    client = await get_client_async()

    # Handle different link formats
    if "t.me/" in invite_link or "telegram.me/" in invite_link:
        # It's an invite link
        from telethon.tl.functions.messages import ImportChatInviteRequest, CheckChatInviteRequest

        # Extract hash from link
        hash_part = invite_link.split("/")[-1]
        if hash_part.startswith("+"):
            hash_part = hash_part[1:]
        if hash_part.startswith("joinchat/"):
            hash_part = hash_part.replace("joinchat/", "")

        result = await client(ImportChatInviteRequest(hash=hash_part))
        chat = result.chats[0]
    else:
        # It's a username
        chat = parse_chat_id(invite_link)
        entity = await client.get_entity(chat)

        if hasattr(entity, 'megagroup') or hasattr(entity, 'broadcast'):
            await client(JoinChannelRequest(entity))
        chat = await client.get_entity(chat)

    return json.dumps({
        "success": True,
        "chat": format_chat(chat),
    }, indent=2)


async def leave_chat(chat_id: str, delete_dialog: bool = False) -> str:
    """Leave a chat.

    Args:
        chat_id: Chat ID or username
        delete_dialog: If True, also delete the chat from dialog list

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    entity = await client.get_entity(chat)

    if hasattr(entity, 'megagroup') or hasattr(entity, 'broadcast'):
        await client(LeaveChannelRequest(entity))
    else:
        # For regular groups, just delete the dialog
        delete_dialog = True

    if delete_dialog:
        await client.delete_dialog(entity)

    return json.dumps({
        "success": True,
        "action": "left",
        "chat_id": str(chat),
    }, indent=2)


async def archive_chat(chat_id: str, unarchive: bool = False) -> str:
    """Archive or unarchive a chat.

    Args:
        chat_id: Chat ID or username
        unarchive: If True, unarchive the chat instead

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    entity = await client.get_entity(chat)
    folder_id = 0 if unarchive else 1  # 0 = main, 1 = archive

    await client.edit_folder(entity, folder_id)

    return json.dumps({
        "success": True,
        "action": "unarchived" if unarchive else "archived",
        "chat_id": str(chat),
    }, indent=2)


async def mute_chat(
    chat_id: str,
    unmute: bool = False,
    mute_until: Optional[int] = None,
) -> str:
    """Mute or unmute notifications for a chat.

    Args:
        chat_id: Chat ID or username
        unmute: If True, unmute the chat
        mute_until: Unix timestamp until when to mute (default: forever)

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    entity = await client.get_entity(chat)

    if unmute:
        mute_until_dt = None
    else:
        if mute_until:
            mute_until_dt = datetime.fromtimestamp(mute_until)
        else:
            # Mute for a very long time (essentially forever)
            mute_until_dt = datetime.now() + timedelta(days=365 * 10)

    await client(UpdateNotifySettingsRequest(
        peer=InputNotifyPeer(peer=await client.get_input_entity(entity)),
        settings=InputPeerNotifySettings(
            mute_until=int(mute_until_dt.timestamp()) if mute_until_dt else 0,
        ),
    ))

    return json.dumps({
        "success": True,
        "action": "unmuted" if unmute else "muted",
        "chat_id": str(chat),
    }, indent=2)
