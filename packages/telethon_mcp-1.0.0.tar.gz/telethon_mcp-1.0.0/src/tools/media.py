"""Media handling tools for Telegram MCP."""

import json
import os
from typing import Optional

from src.client import get_client as get_client_async
from src.utils.validators import parse_chat_id, parse_message_id
from src.utils.formatters import format_message


async def send_photo(
    chat_id: str,
    file_path: str,
    caption: str = "",
    parse_mode: str = "markdown",
) -> str:
    """Send a photo to a chat.

    Args:
        chat_id: Chat ID or username
        file_path: Absolute path to the image file
        caption: Photo caption (optional)
        parse_mode: Caption formatting: "markdown", "html", or "text"

    Returns:
        JSON string with sent message details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    if not os.path.exists(file_path):
        return json.dumps({
            "success": False,
            "error": f"File not found: {file_path}",
        }, indent=2)

    pm = None
    if parse_mode.lower() == "markdown":
        pm = "md"
    elif parse_mode.lower() == "html":
        pm = "html"

    message = await client.send_file(
        chat,
        file_path,
        caption=caption,
        parse_mode=pm,
        force_document=False,
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
    }, indent=2)


async def send_document(
    chat_id: str,
    file_path: str,
    caption: str = "",
    filename: Optional[str] = None,
) -> str:
    """Send a document/file to a chat.

    Args:
        chat_id: Chat ID or username
        file_path: Absolute path to the file
        caption: File caption (optional)
        filename: Custom filename to display (optional)

    Returns:
        JSON string with sent message details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    if not os.path.exists(file_path):
        return json.dumps({
            "success": False,
            "error": f"File not found: {file_path}",
        }, indent=2)

    attributes = []
    if filename:
        from telethon.tl.types import DocumentAttributeFilename
        attributes.append(DocumentAttributeFilename(filename))

    message = await client.send_file(
        chat,
        file_path,
        caption=caption,
        force_document=True,
        attributes=attributes if attributes else None,
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
    }, indent=2)


async def send_voice(
    chat_id: str,
    file_path: str,
) -> str:
    """Send a voice message to a chat.

    Args:
        chat_id: Chat ID or username
        file_path: Absolute path to the audio file (ogg/opus preferred)

    Returns:
        JSON string with sent message details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    if not os.path.exists(file_path):
        return json.dumps({
            "success": False,
            "error": f"File not found: {file_path}",
        }, indent=2)

    message = await client.send_file(
        chat,
        file_path,
        voice_note=True,
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
    }, indent=2)


async def send_video(
    chat_id: str,
    file_path: str,
    caption: str = "",
    video_note: bool = False,
) -> str:
    """Send a video to a chat.

    Args:
        chat_id: Chat ID or username
        file_path: Absolute path to the video file
        caption: Video caption (optional)
        video_note: If True, send as a video note (round video)

    Returns:
        JSON string with sent message details
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)

    if not os.path.exists(file_path):
        return json.dumps({
            "success": False,
            "error": f"File not found: {file_path}",
        }, indent=2)

    message = await client.send_file(
        chat,
        file_path,
        caption=caption if not video_note else None,
        video_note=video_note,
    )

    return json.dumps({
        "success": True,
        "message": format_message(message),
    }, indent=2)


async def download_media(
    chat_id: str,
    message_id: str,
    download_path: Optional[str] = None,
) -> str:
    """Download media from a message.

    Args:
        chat_id: Chat ID or username
        message_id: ID of the message containing media
        download_path: Optional path to save the file (default: ~/Downloads)

    Returns:
        JSON string with download result and file path
    """
    client = await get_client_async()
    chat = parse_chat_id(chat_id)
    msg_id = parse_message_id(message_id)

    messages = await client.get_messages(chat, ids=msg_id)
    message = messages[0] if messages else None

    if not message:
        return json.dumps({
            "success": False,
            "error": f"Message not found: {message_id}",
        }, indent=2)

    if not message.media:
        return json.dumps({
            "success": False,
            "error": "Message has no media",
        }, indent=2)

    if download_path is None:
        download_path = os.path.expanduser("~/Downloads")

    os.makedirs(download_path, exist_ok=True)

    file_path = await client.download_media(
        message,
        file=download_path,
    )

    return json.dumps({
        "success": True,
        "file_path": file_path,
        "message_id": msg_id,
    }, indent=2)


async def get_profile_photo(
    user_id: str,
    download_path: Optional[str] = None,
) -> str:
    """Download a user's or chat's profile photo.

    Args:
        user_id: User/chat ID or username
        download_path: Optional path to save the photo (default: ~/Downloads)

    Returns:
        JSON string with download result and file path
    """
    client = await get_client_async()
    user = parse_chat_id(user_id)

    entity = await client.get_entity(user)

    if not hasattr(entity, 'photo') or not entity.photo:
        return json.dumps({
            "success": False,
            "error": "No profile photo found",
        }, indent=2)

    if download_path is None:
        download_path = os.path.expanduser("~/Downloads")

    os.makedirs(download_path, exist_ok=True)

    file_path = await client.download_profile_photo(
        entity,
        file=download_path,
    )

    return json.dumps({
        "success": True,
        "file_path": file_path,
        "user_id": str(user),
    }, indent=2)
