"""Contact management tools for Telegram MCP."""

import json
from typing import Optional

from telethon.tl.functions.contacts import (
    GetContactsRequest,
    AddContactRequest,
    DeleteContactsRequest,
    BlockRequest,
    UnblockRequest,
    GetBlockedRequest,
)
from telethon.tl.types import InputPhoneContact

from src.client import get_client as get_client_async
from src.utils.validators import parse_chat_id, parse_limit, validate_phone_number
from src.utils.formatters import format_user, format_contact


async def list_contacts(limit: int = 100) -> str:
    """List all contacts.

    Args:
        limit: Maximum number of contacts to retrieve (1-500, default: 100)

    Returns:
        JSON string with list of contacts
    """
    client = await get_client_async()
    limit = parse_limit(limit, default=100, max_limit=500)

    result = await client(GetContactsRequest(hash=0))

    contacts = []
    for user in result.users[:limit]:
        contacts.append(format_user(user))

    return json.dumps({
        "success": True,
        "count": len(contacts),
        "contacts": contacts,
    }, indent=2)


async def add_contact(
    phone: str,
    first_name: str,
    last_name: str = "",
) -> str:
    """Add a new contact.

    Args:
        phone: Phone number with country code (e.g., "+1234567890")
        first_name: Contact's first name
        last_name: Contact's last name (optional)

    Returns:
        JSON string with added contact details
    """
    client = await get_client_async()
    phone = validate_phone_number(phone)

    result = await client(AddContactRequest(
        id=InputPhoneContact(
            client_id=0,
            phone=phone,
            first_name=first_name,
            last_name=last_name,
        ),
        first_name=first_name,
        last_name=last_name,
        phone=phone,
        add_phone_privacy_exception=True,
    ))

    user = result.users[0] if result.users else None

    return json.dumps({
        "success": True,
        "contact": format_user(user) if user else {"phone": phone, "name": f"{first_name} {last_name}".strip()},
    }, indent=2)


async def delete_contact(user_id: str) -> str:
    """Delete a contact.

    Args:
        user_id: User ID or username of the contact to delete

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    user = parse_chat_id(user_id)

    entity = await client.get_entity(user)
    await client(DeleteContactsRequest(id=[entity]))

    return json.dumps({
        "success": True,
        "action": "deleted",
        "user_id": str(user),
    }, indent=2)


async def block_user(user_id: str) -> str:
    """Block a user.

    Args:
        user_id: User ID or username to block

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    user = parse_chat_id(user_id)

    entity = await client.get_entity(user)
    await client(BlockRequest(id=entity))

    return json.dumps({
        "success": True,
        "action": "blocked",
        "user_id": str(user),
    }, indent=2)


async def unblock_user(user_id: str) -> str:
    """Unblock a user.

    Args:
        user_id: User ID or username to unblock

    Returns:
        JSON string with result
    """
    client = await get_client_async()
    user = parse_chat_id(user_id)

    entity = await client.get_entity(user)
    await client(UnblockRequest(id=entity))

    return json.dumps({
        "success": True,
        "action": "unblocked",
        "user_id": str(user),
    }, indent=2)


async def get_user_info(user_id: str) -> str:
    """Get detailed information about a user.

    Args:
        user_id: User ID or username

    Returns:
        JSON string with user details
    """
    client = await get_client_async()
    user = parse_chat_id(user_id)

    entity = await client.get_entity(user)
    full_user = await client.get_entity(user)

    info = format_user(entity)

    # Try to get additional info
    try:
        if hasattr(full_user, 'about'):
            info["bio"] = full_user.about
        if hasattr(entity, 'status'):
            status_type = type(entity.status).__name__
            info["status"] = status_type.replace("UserStatus", "").lower()
        if hasattr(entity, 'photo') and entity.photo:
            info["has_photo"] = True
        if hasattr(entity, 'lang_code'):
            info["language_code"] = entity.lang_code
    except Exception:
        pass

    return json.dumps({
        "success": True,
        "user": info,
    }, indent=2)
