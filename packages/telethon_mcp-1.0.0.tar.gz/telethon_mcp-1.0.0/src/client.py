"""Telethon client wrapper for Telegram MCP."""

import os
import logging
from typing import Optional
from contextlib import asynccontextmanager

from telethon import TelegramClient
from telethon.sessions import StringSession

logger = logging.getLogger(__name__)


class TelegramClientManager:
    """Singleton manager for Telethon client."""

    _instance: Optional["TelegramClientManager"] = None
    _client: Optional[TelegramClient] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @property
    def client(self) -> TelegramClient:
        """Get the Telethon client instance."""
        if self._client is None:
            raise RuntimeError("Client not initialized. Call initialize() first.")
        return self._client

    async def initialize(self) -> TelegramClient:
        """Initialize the Telethon client.

        Returns:
            Connected TelegramClient instance

        Raises:
            ValueError: If required environment variables are missing
            ConnectionError: If client fails to connect
        """
        if self._client is not None and self._client.is_connected():
            return self._client

        api_id = os.environ.get("TELEGRAM_API_ID")
        api_hash = os.environ.get("TELEGRAM_API_HASH")
        session_string = os.environ.get("TELEGRAM_SESSION_STRING")

        if not api_id or not api_hash:
            raise ValueError(
                "TELEGRAM_API_ID and TELEGRAM_API_HASH environment variables are required. "
                "Get them from https://my.telegram.org/apps"
            )

        if not session_string:
            raise ValueError(
                "TELEGRAM_SESSION_STRING environment variable is required. "
                "Run 'uv run scripts/generate_session.py' to generate one."
            )

        try:
            api_id = int(api_id)
        except ValueError:
            raise ValueError("TELEGRAM_API_ID must be a valid integer")

        logger.info("Initializing Telegram client...")

        self._client = TelegramClient(
            StringSession(session_string),
            api_id,
            api_hash,
            device_model="Claude Code MCP",
            app_version="1.0.0",
        )

        await self._client.connect()

        if not await self._client.is_user_authorized():
            raise ConnectionError(
                "Session is not authorized. Please regenerate your session string "
                "by running 'uv run scripts/generate_session.py'"
            )

        me = await self._client.get_me()
        logger.info(f"Connected as: {me.first_name} (@{me.username or 'no username'})")

        return self._client

    async def disconnect(self):
        """Disconnect the Telethon client."""
        if self._client is not None:
            logger.info("Disconnecting Telegram client...")
            await self._client.disconnect()
            self._client = None

    def is_connected(self) -> bool:
        """Check if client is connected."""
        return self._client is not None and self._client.is_connected()


# Global client manager instance
client_manager = TelegramClientManager()


async def get_client() -> TelegramClient:
    """Get the current Telethon client, initializing if needed.

    Returns:
        TelegramClient instance
    """
    if not client_manager.is_connected():
        await client_manager.initialize()
    return client_manager.client


@asynccontextmanager
async def telegram_session():
    """Context manager for Telegram client session.

    Yields:
        Connected TelegramClient instance
    """
    client = await client_manager.initialize()
    try:
        yield client
    finally:
        pass  # Don't disconnect - keep session alive for MCP
