"""Response formatting utilities for Telegram MCP."""

from datetime import datetime
from typing import Any, Dict, List, Optional


def format_user(user: Any) -> Dict[str, Any]:
    """Format a Telethon User object to a dictionary.

    Args:
        user: Telethon User entity

    Returns:
        Formatted user dictionary
    """
    if user is None:
        return {"error": "User not found"}

    return {
        "id": user.id,
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "phone": getattr(user, 'phone', None),
        "is_bot": getattr(user, 'bot', False),
        "is_verified": getattr(user, 'verified', False),
        "is_premium": getattr(user, 'premium', False),
    }


def format_chat(chat: Any) -> Dict[str, Any]:
    """Format a Telethon Chat/Channel object to a dictionary.

    Args:
        chat: Telethon Chat or Channel entity

    Returns:
        Formatted chat dictionary
    """
    if chat is None:
        return {"error": "Chat not found"}

    chat_type = "unknown"
    if hasattr(chat, 'megagroup') and chat.megagroup:
        chat_type = "supergroup"
    elif hasattr(chat, 'broadcast') and chat.broadcast:
        chat_type = "channel"
    elif hasattr(chat, 'gigagroup') and chat.gigagroup:
        chat_type = "gigagroup"
    elif hasattr(chat, 'id'):
        if chat.id > 0:
            chat_type = "user"
        else:
            chat_type = "group"

    return {
        "id": chat.id,
        "title": getattr(chat, 'title', None) or getattr(chat, 'first_name', 'Unknown'),
        "username": getattr(chat, 'username', None),
        "type": chat_type,
        "participants_count": getattr(chat, 'participants_count', None),
    }


def format_message(message: Any) -> Dict[str, Any]:
    """Format a Telethon Message object to a dictionary.

    Args:
        message: Telethon Message object

    Returns:
        Formatted message dictionary
    """
    if message is None:
        return {"error": "Message not found"}

    media_type = None
    if message.media:
        media_type = type(message.media).__name__.replace('MessageMedia', '').lower()

    return {
        "id": message.id,
        "chat_id": message.chat_id,
        "sender_id": message.sender_id,
        "text": message.text or message.message,
        "date": format_datetime(message.date),
        "is_outgoing": message.out,
        "reply_to_msg_id": message.reply_to_msg_id if message.reply_to else None,
        "has_media": message.media is not None,
        "media_type": media_type,
        "views": getattr(message, 'views', None),
        "forwards": getattr(message, 'forwards', None),
        "is_pinned": getattr(message, 'pinned', False),
    }


def format_dialog(dialog: Any) -> Dict[str, Any]:
    """Format a Telethon Dialog object to a dictionary.

    Args:
        dialog: Telethon Dialog object

    Returns:
        Formatted dialog dictionary
    """
    if dialog is None:
        return {"error": "Dialog not found"}

    return {
        "id": dialog.id,
        "name": dialog.name,
        "unread_count": dialog.unread_count,
        "is_pinned": dialog.pinned,
        "is_archived": dialog.archived,
        "is_muted": dialog.dialog.notify_settings.mute_until is not None if hasattr(dialog.dialog, 'notify_settings') else False,
        "last_message": format_message(dialog.message) if dialog.message else None,
        **format_chat(dialog.entity),
    }


def format_datetime(dt: Optional[datetime]) -> Optional[str]:
    """Format datetime to ISO string.

    Args:
        dt: Datetime object

    Returns:
        ISO formatted string or None
    """
    if dt is None:
        return None
    return dt.isoformat()


def format_participant(participant: Any) -> Dict[str, Any]:
    """Format a chat participant to a dictionary.

    Args:
        participant: Telethon participant object

    Returns:
        Formatted participant dictionary
    """
    user = format_user(participant)

    # Add participant-specific info
    participant_type = type(participant).__name__
    is_admin = 'Admin' in participant_type or 'Creator' in participant_type
    is_creator = 'Creator' in participant_type

    return {
        **user,
        "is_admin": is_admin,
        "is_creator": is_creator,
    }


def format_contact(contact: Any) -> Dict[str, Any]:
    """Format a contact to a dictionary.

    Args:
        contact: Telethon contact object

    Returns:
        Formatted contact dictionary
    """
    return {
        "id": contact.id,
        "first_name": contact.first_name,
        "last_name": contact.last_name,
        "phone": getattr(contact, 'phone', None),
        "username": getattr(contact, 'username', None),
        "is_mutual": getattr(contact, 'mutual_contact', False),
    }


def truncate_text(text: str, max_length: int = 200) -> str:
    """Truncate text to a maximum length.

    Args:
        text: Text to truncate
        max_length: Maximum length

    Returns:
        Truncated text with ellipsis if needed
    """
    if not text or len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."
