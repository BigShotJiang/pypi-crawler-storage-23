"""Input validation utilities for Telegram MCP."""

import re
from typing import Union


def parse_chat_id(chat_id: Union[str, int]) -> Union[str, int]:
    """Parse and validate a chat ID or username.

    Args:
        chat_id: Chat ID (int or string) or username (with or without @)

    Returns:
        Parsed chat identifier
    """
    if isinstance(chat_id, int):
        return chat_id

    chat_id = str(chat_id).strip()

    # If it's a numeric string, convert to int
    if chat_id.lstrip('-').isdigit():
        return int(chat_id)

    # If it's a username, ensure it starts with @
    if not chat_id.startswith('@'):
        chat_id = f"@{chat_id}"

    return chat_id


def parse_message_id(message_id: Union[str, int]) -> int:
    """Parse and validate a message ID.

    Args:
        message_id: Message ID as string or int

    Returns:
        Message ID as integer

    Raises:
        ValueError: If message_id is not a valid integer
    """
    if isinstance(message_id, int):
        return message_id

    try:
        return int(str(message_id).strip())
    except ValueError:
        raise ValueError(f"Invalid message ID: {message_id}")


def validate_phone_number(phone: str) -> str:
    """Validate and normalize phone number.

    Args:
        phone: Phone number string

    Returns:
        Normalized phone number with + prefix

    Raises:
        ValueError: If phone number format is invalid
    """
    phone = re.sub(r'[\s\-\(\)]', '', phone)

    if not phone.startswith('+'):
        phone = f"+{phone}"

    if not re.match(r'^\+\d{10,15}$', phone):
        raise ValueError(f"Invalid phone number format: {phone}")

    return phone


def parse_limit(limit: Union[str, int, None], default: int = 20, max_limit: int = 100) -> int:
    """Parse and validate a limit parameter.

    Args:
        limit: Limit value
        default: Default value if limit is None
        max_limit: Maximum allowed value

    Returns:
        Validated limit value
    """
    if limit is None:
        return default

    try:
        limit = int(limit)
    except (ValueError, TypeError):
        return default

    return max(1, min(limit, max_limit))
