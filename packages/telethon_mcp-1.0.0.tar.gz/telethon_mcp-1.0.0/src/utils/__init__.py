"""Utility functions for Telegram MCP."""
