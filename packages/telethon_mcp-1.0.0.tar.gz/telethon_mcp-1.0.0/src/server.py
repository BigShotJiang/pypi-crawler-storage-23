"""Main MCP server for Telegram integration."""

import os
import sys
import logging
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from src.client import client_manager

# Configure logging to stderr (stdout is reserved for MCP protocol)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()


@asynccontextmanager
async def lifespan(mcp: FastMCP):
    """Manage server lifecycle - connect/disconnect Telegram client."""
    logger.info("Starting Telegram MCP server...")

    try:
        await client_manager.initialize()
        logger.info("Telegram client connected successfully")
    except Exception as e:
        logger.error(f"Failed to initialize Telegram client: {e}")
        raise

    yield

    logger.info("Shutting down Telegram MCP server...")
    await client_manager.disconnect()


# Initialize FastMCP server
mcp = FastMCP("telegram-mcp")


# Import and register all tools
from src.tools.messaging import (
    send_message,
    edit_message,
    delete_message,
    forward_message,
    reply_to_message,
    get_messages,
    search_messages,
    pin_message,
)
from src.tools.chats import (
    list_chats,
    get_chat_info,
    create_group,
    create_channel,
    join_chat,
    leave_chat,
    archive_chat,
    mute_chat,
)
from src.tools.contacts import (
    list_contacts,
    add_contact,
    delete_contact,
    block_user,
    unblock_user,
    get_user_info,
)
from src.tools.media import (
    send_photo,
    send_document,
    send_voice,
    send_video,
    download_media,
    get_profile_photo,
)
from src.tools.admin import (
    ban_user,
    unban_user,
    kick_user,
    promote_admin,
    demote_admin,
    set_chat_title,
    set_chat_photo,
    get_participants,
    invite_user,
)
from src.tools.advanced import (
    send_reaction,
    create_poll,
    schedule_message,
    get_scheduled_messages,
    delete_scheduled_message,
    set_typing,
    mark_as_read,
    get_drafts,
    save_draft,
)

# Register all tools with MCP
# Messaging tools
mcp.tool()(send_message)
mcp.tool()(edit_message)
mcp.tool()(delete_message)
mcp.tool()(forward_message)
mcp.tool()(reply_to_message)
mcp.tool()(get_messages)
mcp.tool()(search_messages)
mcp.tool()(pin_message)

# Chat tools
mcp.tool()(list_chats)
mcp.tool()(get_chat_info)
mcp.tool()(create_group)
mcp.tool()(create_channel)
mcp.tool()(join_chat)
mcp.tool()(leave_chat)
mcp.tool()(archive_chat)
mcp.tool()(mute_chat)

# Contact tools
mcp.tool()(list_contacts)
mcp.tool()(add_contact)
mcp.tool()(delete_contact)
mcp.tool()(block_user)
mcp.tool()(unblock_user)
mcp.tool()(get_user_info)

# Media tools
mcp.tool()(send_photo)
mcp.tool()(send_document)
mcp.tool()(send_voice)
mcp.tool()(send_video)
mcp.tool()(download_media)
mcp.tool()(get_profile_photo)

# Admin tools
mcp.tool()(ban_user)
mcp.tool()(unban_user)
mcp.tool()(kick_user)
mcp.tool()(promote_admin)
mcp.tool()(demote_admin)
mcp.tool()(set_chat_title)
mcp.tool()(set_chat_photo)
mcp.tool()(get_participants)
mcp.tool()(invite_user)

# Advanced tools
mcp.tool()(send_reaction)
mcp.tool()(create_poll)
mcp.tool()(schedule_message)
mcp.tool()(get_scheduled_messages)
mcp.tool()(delete_scheduled_message)
mcp.tool()(set_typing)
mcp.tool()(mark_as_read)
mcp.tool()(get_drafts)
mcp.tool()(save_draft)


def main():
    """Main entry point for the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
