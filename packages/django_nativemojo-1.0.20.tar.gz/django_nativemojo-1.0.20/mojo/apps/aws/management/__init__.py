"""
Management package for mojo.apps.aws.

This exists so Django discovers management commands shipped with the framework.
"""