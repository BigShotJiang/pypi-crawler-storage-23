"""
DocIt - Documentation Management System

A Django-MOJO app for creating, organizing, and managing documentation
with hierarchical pages, version control, and asset management.
"""
