"""
Kanbus Python package.

:module: kanbus

This patch is a no-op change to trigger a release build.
"""

__version__ = "0.9.0"
