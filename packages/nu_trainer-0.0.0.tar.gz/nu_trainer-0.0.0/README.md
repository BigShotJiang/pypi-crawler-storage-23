# nu_trainer 🤓

A simple Pytorch trainer.