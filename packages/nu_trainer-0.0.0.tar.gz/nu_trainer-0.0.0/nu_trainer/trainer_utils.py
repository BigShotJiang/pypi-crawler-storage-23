import torch
from torch.utils.data import DataLoader
import sys
from dataclasses import dataclass, asdict
import random
import numpy as np

@dataclass
class NuTrainer:
    device: any ="cuda:0"
    dtype: any=32
    epoch: any =1
    batch_size: any =2
    effective_batch_size: any = 32
    accumulated_steps: any = None
    num_workers: any = 4
    prefetch_factor: any = 8

    def __post_init__(self):
        self.accumulated_steps = self.effective_batch_size // self.batch_size
        for key, value in asdict(self).items():
            print(f"{key}: {value}")
        print(f"{'-'*100}\n")
        self.dtype = torch.float32 if self.dtype == 32 else torch.bfloat16
    
    def fix_seed(self, seed=42):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    def print_trainable(self, model):
        total = 0
        trainable = 0
        for p in model.parameters():
            total += p.numel()
            if p.requires_grad:
                trainable += p.numel()
        result = f"Trainable {trainable} / {total} ({trainable/total*100:.4f})%"
        print(result)
        return result

    def transfer_tensor(self, tensor):
        return {key: value.to(device=self.device, dtype=self.dtype if value.dtype == torch.float32 else value.dtype) if isinstance(value, torch.Tensor) else value for key, value in tensor.items()}
    
    def create_dataloader(self, dataset, drop_last=True, is_shuffle=True):
        if 'debugpy' in sys.modules:
            num_workers = 0
            prefetch_factor = None
            persistent_workers = False
        else:
            num_workers = self.num_workers
            prefetch_factor = self.prefetch_factor
            persistent_workers = True if num_workers > 0 else False
        dataloader = DataLoader(
            dataset, 
            shuffle=is_shuffle, 
            batch_size=self.batch_size,
            num_workers=num_workers,
            prefetch_factor=prefetch_factor,
            persistent_workers=persistent_workers,
            pin_memory=True,
            drop_last=drop_last,
        )
        return dataloader