# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, List, Optional

from pydantic import Field as FieldInfo

from .meta import Meta
from .._models import BaseModel

__all__ = ["BulkExportFinancialsJsonResponse", "Data"]


class Data(BaseModel):
    edinet_code: str

    fiscal_year: int

    name_jp: str

    accounting_standard: Optional[str] = None

    name_en: Optional[str] = None

    period_end: Optional[str] = None

    sector: Optional[str] = None

    securities_code: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class BulkExportFinancialsJsonResponse(BaseModel):
    data: List[Data]

    meta: Meta
