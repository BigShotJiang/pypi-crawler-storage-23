"""Debug exception definitions."""


class UiPathDebugQuitError(Exception):
    """Raised when user quits the debugger."""

    pass
