
UNITTEST_JUNK_FOLDER = "tests/junk"
UNITTEST_PATH_1VII_PDB = "tests/data/1vii.pdb"
UNITTEST_PATH_1VII_CIF = "tests/data/1vii.cif"
