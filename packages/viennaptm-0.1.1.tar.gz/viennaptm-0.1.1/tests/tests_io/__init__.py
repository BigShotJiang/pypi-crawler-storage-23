from tests.tests_io.test_iostructure import *
from tests.tests_io.test_resources import *
