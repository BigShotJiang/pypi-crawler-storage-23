{{ name }}  {# this becomes the heading/sidebar entry #}
{{ "=" * name|length }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ name }}
