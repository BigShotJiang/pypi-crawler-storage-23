=======
History
=======
2026.3.1 -- Internal: switching from deprecated library pkg_resources to importlib

2023.3.30 -- Initial working version, with documentation.

    With the following functionality:

        * Creation of QCArchive datasets from SEAMM
	* Adding structures to entries in a dataset
	* Retrieving structures from a QCArchive dataset back into SEAMM
