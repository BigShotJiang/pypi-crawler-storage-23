"""Rebrew — compiler-in-the-loop decompilation workbench."""

__version__ = "0.0.1"
