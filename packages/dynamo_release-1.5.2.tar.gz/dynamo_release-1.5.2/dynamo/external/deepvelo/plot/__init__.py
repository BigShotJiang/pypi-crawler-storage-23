from .plot import (
    parula_map,
    parula_map_r,
    statplot,
    compare_plot,
    dist_plot,
    gene_scatter,
    draw_var_dist,
)
from .scatter import scatter
