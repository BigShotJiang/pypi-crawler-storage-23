class CharacteristicMissingError(Exception):
    """Raised when a characteristic is missing."""
