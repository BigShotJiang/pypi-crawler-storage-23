from __future__ import annotations

import pytest

from artificer.queue_operations import (
    _create_queue,
    _delete_queue,
    _get_queue,
    _list_queues,
    _update_queue,
)


class TestListQueues:
    def test_returns_list_of_queue_dicts(self, adapter):
        result = _list_queues(adapter)
        assert isinstance(result, list)
        names = {q["name"] for q in result}
        assert "Bugs" in names
        assert "In Progress" in names
        assert "Done" in names

    def test_correct_task_counts(self, adapter):
        result = _list_queues(adapter)
        by_name = {q["name"]: q for q in result}
        assert by_name["Bugs"]["task_count"] == 1
        assert by_name["In Progress"]["task_count"] == 0
        assert by_name["Done"]["task_count"] == 0


class TestGetQueue:
    def test_returns_queue_dict(self, adapter):
        result = _get_queue(adapter, "Bugs")
        assert result["name"] == "Bugs"
        assert result["task_count"] == 1

    def test_not_found_raises_key_error(self, adapter):
        with pytest.raises(KeyError):
            _get_queue(adapter, "Nonexistent")


class TestCreateQueue:
    def test_creates_queue(self, adapter):
        result = _create_queue(adapter, "New Queue")
        assert result["name"] == "New Queue"
        assert result["task_count"] == 0

    def test_duplicate_raises_value_error(self, adapter):
        with pytest.raises(ValueError):
            _create_queue(adapter, "Bugs")


class TestUpdateQueue:
    def test_renames_queue(self, adapter):
        result = _update_queue(adapter, "In Progress", new_name="Working")
        assert result["name"] == "Working"
        assert result["task_count"] == 0

    def test_not_found_raises_key_error(self, adapter):
        with pytest.raises(KeyError):
            _update_queue(adapter, "Nonexistent", new_name="New")

    def test_duplicate_name_raises_value_error(self, adapter):
        with pytest.raises(ValueError):
            _update_queue(adapter, "In Progress", new_name="Bugs")


class TestDeleteQueue:
    def test_deletes_empty_queue(self, adapter):
        result = _delete_queue(adapter, "Done")
        assert "Done" in result
        # Verify it's gone
        with pytest.raises(KeyError):
            _get_queue(adapter, "Done")

    def test_not_found_raises_key_error(self, adapter):
        with pytest.raises(KeyError):
            _delete_queue(adapter, "Nonexistent")

    def test_non_empty_raises_value_error(self, adapter):
        with pytest.raises(ValueError):
            _delete_queue(adapter, "Bugs")
