from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from artificer.agents.claude import ClaudeAgentAdapter
from artificer.agents.default import DefaultAgentAdapter
from artificer.config import RouteConfig

if TYPE_CHECKING:
    from artificer.adapters.base import Task, TaskAdapter
    from artificer.agents.base import AgentAdapter

log = logging.getLogger(__name__)


@dataclass
class AgentProcess:
    task_id: str
    process: asyncio.subprocess.Process
    command: str = ""
    session_id: str | None = None
    started_at: float = field(default_factory=time.time)
    expected_timeout: int | None = None


class Router:
    def __init__(
        self,
        adapter: TaskAdapter,
        *,
        routes: list[RouteConfig],
        poll_interval: int,
        max_concurrent_agents: int,
        default_agent_timeout: int | None = None,
        default_max_retries: int = 0,
        default_dead_letter_queue: str | None = None,
        agent_adapters: dict[str, AgentAdapter] | None = None,
    ) -> None:
        self._adapter = adapter
        self._routes = routes
        self._poll_interval = poll_interval
        self._max_concurrent_agents = max_concurrent_agents
        self._default_agent_timeout = default_agent_timeout
        self._default_max_retries = default_max_retries
        self._default_dead_letter_queue = default_dead_letter_queue
        self._active: dict[str, AgentProcess] = {}
        self._seen_ids: set[str] = set()
        self._monitor_tasks: dict[str, asyncio.Task] = {}
        self._last_poll_times: dict[str, float] = {}
        self._route_priority: dict[str, int] = {
            route.queue_name: route.priority if route.priority is not None else i
            for i, route in enumerate(self._routes)
        }
        self._tick_interval: int = min(
            (self._effective_poll_interval(r) for r in self._routes),
            default=self._poll_interval,
        )
        # Agent adapter registry: built-in adapters, then user overrides
        self._agent_adapters: dict[str, AgentAdapter] = {
            "claude": ClaudeAgentAdapter(),
        }
        if agent_adapters:
            self._agent_adapters.update(agent_adapters)
        self._default_agent_adapter = DefaultAgentAdapter()

    @property
    def available_slots(self) -> int:
        return self._max_concurrent_agents - len(self._active)

    def _effective_poll_interval(self, route: RouteConfig) -> int:
        """Return the effective poll interval for a route, falling back to global."""
        return route.poll_interval if route.poll_interval is not None else self._poll_interval

    def _effective_max_retries(self, route: RouteConfig) -> int:
        """Return the effective max_retries for a route, falling back to global."""
        return route.max_retries if route.max_retries is not None else self._default_max_retries

    def _effective_dead_letter_queue(self, route: RouteConfig) -> str | None:
        """Return the effective dead_letter_queue for a route, falling back to global."""
        return route.dead_letter_queue if route.dead_letter_queue is not None else self._default_dead_letter_queue

    def _adapter_for_command(self, command: str) -> AgentAdapter:
        """Select the appropriate agent adapter based on command."""
        return self._agent_adapters.get(command, self._default_agent_adapter)

    def get_status(self) -> dict:
        now = time.time()
        agents = []
        for agent in self._active.values():
            agent_adapter = self._adapter_for_command(agent.command)
            status = {
                "task_id": agent.task_id,
                "pid": agent.process.pid,
                "command": agent.command,
                "running_for_seconds": round(now - agent.started_at),
            }
            # Add adapter-specific status extras
            status.update(agent_adapter.get_status_extras(agent))
            agents.append(status)
        return {
            "active_agents": agents,
            "available_slots": self.available_slots,
            "max_concurrent_agents": self._max_concurrent_agents,
        }

    async def run(self) -> None:
        log.info(
            "Router started: max %d agents, tick every %ds",
            self._max_concurrent_agents,
            self._tick_interval,
        )
        for route in self._routes:
            interval = self._effective_poll_interval(route)
            effective_priority = self._route_priority[route.queue_name]
            log.info(
                "  Queue %r: priority %d, poll every %ds%s",
                route.queue_name,
                effective_priority,
                interval,
                "" if route.poll_interval is not None else " (global default)",
            )
        try:
            while True:
                try:
                    await self._poll_once()
                except asyncio.CancelledError:
                    raise
                except Exception:
                    log.exception("Poll failed")
                await asyncio.sleep(self._tick_interval)
        except asyncio.CancelledError:
            log.info("Router cancelled, shutting down")
            await self._shutdown()

    def _check_stale_slots(self) -> None:
        """Scan active agents for any that have exceeded their expected timeout + 2min buffer.

        Raises RuntimeError on detection to crash the router and force investigation.
        """
        now = time.time()
        for task_id, agent in self._active.items():
            if agent.expected_timeout is None:
                continue
            elapsed = now - agent.started_at
            deadline = agent.expected_timeout + 120
            if elapsed > deadline:
                log.error(
                    "Stale slot detected: task=%s pid=%s started_at=%.1f expected_timeout=%s "
                    "elapsed=%.1fs deadline=%.1fs active=%r monitor_tasks=%r seen_ids=%r",
                    task_id,
                    agent.process.pid,
                    agent.started_at,
                    agent.expected_timeout,
                    elapsed,
                    deadline,
                    {k: {"pid": v.process.pid, "started_at": v.started_at, "expected_timeout": v.expected_timeout} for k, v in self._active.items()},
                    list(self._monitor_tasks.keys()),
                    self._seen_ids,
                )
                raise RuntimeError(
                    f"Stale slot detected for task {task_id} (pid={agent.process.pid}): "
                    f"elapsed {elapsed:.0f}s > deadline {deadline:.0f}s "
                    f"(expected_timeout={agent.expected_timeout} + 120s buffer)"
                )

    async def _poll_once(self) -> None:
        self._check_stale_slots()

        if self.available_slots <= 0:
            log.debug("No available slots, skipping poll")
            return

        now = time.time()
        due_queues = []
        for route in self._routes:
            interval = self._effective_poll_interval(route)
            last = self._last_poll_times.get(route.queue_name, 0.0)
            if now - last >= interval:
                due_queues.append(route.queue_name)

        if not due_queues:
            log.debug("No queues due for polling")
            return

        tasks = self._adapter.get_ready_tasks(due_queues)

        # Sort tasks by route priority (lower integer = higher priority).
        # Stable sort preserves original order for tasks with equal priority.
        tasks.sort(key=lambda t: self._route_priority.get(t.source_queue, len(self._routes)))

        # Mark all due queues as polled (even if they returned no tasks)
        for qn in due_queues:
            self._last_poll_times[qn] = now

        for task in tasks:
            if self.available_slots <= 0:
                break
            if task.id in self._seen_ids or task.id in self._active:
                continue
            await self._spawn_agent(task)

    def _route_for_queue(self, queue_name: str) -> RouteConfig | None:
        for route in self._routes:
            if route.queue_name == queue_name:
                return route
        return None

    async def _spawn_agent(self, task: Task) -> None:
        route = self._route_for_queue(task.source_queue)
        if route is None:
            log.warning("No route for queue %r, skipping task %s", task.source_queue, task.id)
            return

        self._adapter.move_task(task.id, route.in_progress_queue)
        try:
            self._adapter.update_task(task.id, assignees=["me"])
            log.info("Moved and assigned task %s to %r", task.id, route.in_progress_queue)
        except Exception:
            log.warning("Moved task %s but assignment failed", task.id, exc_info=True)

        cmd = route.format_command(
            task_id=task.id,
            task_name=task.name,
            task_url=task.url,
        )

        # Select adapter and augment command with agent-specific flags
        agent_adapter = self._adapter_for_command(route.command)
        cmd = agent_adapter.augment_command(cmd, route)

        try:
            cmd_str = " ".join(cmd)
            comment = agent_adapter.format_spawn_comment(cmd_str)
            self._adapter.add_comment(task.id, comment)
        except Exception:
            log.warning("Failed to add spawn comment for task %s", task.id, exc_info=True)

        log.info("Spawning agent for task %s: %s", task.id, cmd)
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
        )

        # Determine timeout: route-specific > default > None
        timeout = route.timeout
        if timeout is None:
            timeout = self._default_agent_timeout

        agent = AgentProcess(task_id=task.id, process=process, command=route.command, expected_timeout=timeout)
        self._active[task.id] = agent
        self._seen_ids.add(task.id)
        log.debug("Slot acquired: task=%s pid=%s slots_remaining=%d", task.id, process.pid, self.available_slots)

        monitor = asyncio.create_task(self._monitor_agent(task, process, timeout, route))
        self._monitor_tasks[task.id] = monitor

    async def _monitor_agent(self, task: Task, process: asyncio.subprocess.Process, timeout: int | None = None, route: RouteConfig | None = None) -> None:
        agent = self._active.get(task.id)
        timed_out = False
        cancelled = False
        stdout_task = None
        log.debug("Monitor started: task=%s pid=%s timeout=%s", task.id, process.pid, timeout)

        async def read_stdout():
            """Read stdout line by line and let adapter process it."""
            if agent and process.stdout:
                agent_adapter = self._adapter_for_command(agent.command)
                try:
                    async for raw_line in process.stdout:
                        line = raw_line.decode(errors="replace").strip()
                        agent_adapter.process_stdout_line(line, agent, task, self._adapter)
                except asyncio.CancelledError:
                    pass  # Stdout reader cancelled, likely due to timeout

        try:
            # Run stdout reading concurrently with process waiting
            stdout_task = asyncio.create_task(read_stdout())

            # Wait for process with optional timeout
            if timeout is not None:
                try:
                    await asyncio.wait_for(process.wait(), timeout=timeout)
                except TimeoutError:
                    timed_out = True
                    log.warning("Agent for task %s timed out after %d seconds", task.id, timeout)
                    log.debug("Timeout fired: task=%s pid=%s elapsed=%d", task.id, process.pid, timeout)
                    try:
                        process.terminate()
                        log.debug("Sent SIGTERM: task=%s pid=%s", task.id, process.pid)
                    except ProcessLookupError:
                        log.debug("Process for task %s already exited before terminate (pid=%s)", task.id, process.pid)
                    try:
                        await asyncio.wait_for(process.wait(), timeout=5)
                    except TimeoutError:
                        log.warning("Agent for task %s did not terminate gracefully, killing", task.id)
                        try:
                            process.kill()
                            log.debug("Sent SIGKILL: task=%s pid=%s", task.id, process.pid)
                        except ProcessLookupError:
                            log.debug("Process for task %s already exited before kill (pid=%s)", task.id, process.pid)
                        try:
                            await asyncio.wait_for(process.wait(), timeout=10)
                            log.debug("Post-kill wait returned: task=%s pid=%s", task.id, process.pid)
                        except TimeoutError:
                            log.error("Process for task %s did not exit after SIGKILL (pid=%s), forcibly releasing slot", task.id, process.pid)
            else:
                await process.wait()

            rc = process.returncode
            log.info("Agent for task %s exited with code %d", task.id, rc)
        except asyncio.CancelledError:
            cancelled = True
            log.info("Monitor cancelled for task %s, terminating process", task.id)
            try:
                process.terminate()
                log.debug("Sent SIGTERM (cancel): task=%s pid=%s", task.id, process.pid)
            except ProcessLookupError:
                log.debug("Process for task %s already exited before terminate (pid=%s)", task.id, process.pid)
            try:
                await asyncio.wait_for(process.wait(), timeout=5)
            except TimeoutError:
                try:
                    process.kill()
                    log.debug("Sent SIGKILL (cancel): task=%s pid=%s", task.id, process.pid)
                except ProcessLookupError:
                    log.debug("Process for task %s already exited before kill (pid=%s)", task.id, process.pid)
                try:
                    await asyncio.wait_for(process.wait(), timeout=10)
                    log.debug("Post-kill wait returned (cancel): task=%s pid=%s", task.id, process.pid)
                except TimeoutError:
                    log.error("Process for task %s did not exit after SIGKILL (pid=%s), forcibly releasing slot", task.id, process.pid)
        finally:
            # Clean up stdout reader in all paths
            if stdout_task is not None and not stdout_task.done():
                stdout_task.cancel()
                try:
                    await stdout_task
                except asyncio.CancelledError:
                    pass
            elif stdout_task is not None:
                try:
                    await asyncio.wait_for(stdout_task, timeout=5)
                except (TimeoutError, asyncio.CancelledError):
                    pass
            try:
                if agent:
                    agent_adapter = self._adapter_for_command(agent.command)
                    comment = agent_adapter.format_exit_comment(
                        agent, timed_out, timeout, "", ""
                    )
                    self._adapter.add_comment(task.id, comment)
            except Exception:
                log.warning("Failed to add exit comment for task %s", task.id, exc_info=True)

            rc = process.returncode or 0
            elapsed = time.time() - agent.started_at if agent else 0

            # Retry logic: only when agent failed/timed out and not cancelled
            if (timed_out or rc != 0) and not cancelled and route is not None:
                max_retries = self._effective_max_retries(route)
                dlq = self._effective_dead_letter_queue(route)

                if max_retries > 0 and task.retry_count < max_retries:
                    new_count = task.retry_count + 1
                    try:
                        self._adapter.update_task(task.id, retry_count=new_count)
                        self._adapter.add_comment(
                            task.id,
                            f"Retry {new_count}/{max_retries}: "
                            f"{'timed out' if timed_out else f'exited with code {rc}'}. "
                            f"Moving back to source queue for retry.",
                        )
                        self._adapter.move_task(task.id, route.queue_name)
                    except Exception:
                        log.warning("Failed to retry task %s", task.id, exc_info=True)
                elif max_retries > 0 and task.retry_count >= max_retries:
                    if dlq:
                        try:
                            self._adapter.add_comment(
                                task.id,
                                f"Max retries ({max_retries}) exhausted. "
                                f"Moving to dead-letter queue.",
                            )
                            self._adapter.move_task(task.id, dlq)
                        except Exception:
                            log.warning(
                                "Failed to move task %s to dead-letter queue %r, leaving in place",
                                task.id,
                                dlq,
                                exc_info=True,
                            )
                    else:
                        try:
                            self._adapter.add_comment(
                                task.id,
                                f"Max retries ({max_retries}) exhausted. "
                                f"No dead-letter queue configured; leaving in place.",
                            )
                        except Exception:
                            log.warning("Failed to add exhaustion comment for task %s", task.id, exc_info=True)
            log.debug(
                "Slot released: task=%s pid=%s rc=%s timed_out=%s cancelled=%s elapsed=%.1fs slots_after=%d",
                task.id, process.pid, rc, timed_out, cancelled, elapsed,
                self.available_slots + 1,  # +1 because we haven't popped yet
            )
            self._active.pop(task.id, None)
            self._monitor_tasks.pop(task.id, None)
            self._seen_ids.discard(task.id)

    async def _shutdown(self) -> None:
        for monitor in list(self._monitor_tasks.values()):
            monitor.cancel()
        if self._monitor_tasks:
            await asyncio.gather(*self._monitor_tasks.values(), return_exceptions=True)
        log.info("Router shut down, all agents terminated")
