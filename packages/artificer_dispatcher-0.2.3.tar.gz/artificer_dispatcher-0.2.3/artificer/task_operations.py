from __future__ import annotations

from artificer.adapters.base import TaskAdapter


def _get_task_details(adapter: TaskAdapter, task_id: str) -> dict:
    task = adapter.get_task(task_id)
    return {
        "id": task.id,
        "name": task.name,
        "description": task.description,
        "url": task.url,
        "source_queue": task.source_queue,
        "labels": task.labels,
        "assignees": task.assignees,
        "comments": [
            {"author": c.author, "text": c.text, "created_at": c.created_at}
            for c in task.comments
        ],
    }


def _add_comment(adapter: TaskAdapter, task_id: str, comment: str) -> str:
    adapter.add_comment(task_id, comment)
    return f"Comment added to task {task_id}"


def _move_task(adapter: TaskAdapter, task_id: str, target_queue: str) -> str:
    adapter.move_task(task_id, target_queue)
    return f"Task {task_id} moved to {target_queue!r}"


def _update_task(
    adapter: TaskAdapter,
    task_id: str,
    *,
    assignees: list[str] | None = None,
    name: str | None = None,
    description: str | None = None,
    labels: list[str] | None = None,
) -> dict:
    adapter.update_task(
        task_id,
        assignees=assignees,
        name=name,
        description=description,
        labels=labels,
    )
    # Return the updated task
    task = adapter.get_task(task_id)
    return {
        "id": task.id,
        "name": task.name,
        "description": task.description,
        "url": task.url,
        "source_queue": task.source_queue,
        "labels": task.labels,
        "assignees": task.assignees,
        "comments": [
            {"author": c.author, "text": c.text, "created_at": c.created_at}
            for c in task.comments
        ],
    }


def _create_task(adapter: TaskAdapter, queue_name: str, name: str, description: str) -> dict:
    task = adapter.create_task(queue_name, name, description)
    return {
        "id": task.id,
        "name": task.name,
        "description": task.description,
        "url": task.url,
        "source_queue": task.source_queue,
    }
