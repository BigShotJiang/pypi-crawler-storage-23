from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from artificer.adapters.base import TaskAdapter
from artificer.queue_operations import (
    _create_queue,
    _delete_queue,
    _get_queue,
    _list_queues,
    _update_queue,
)
from artificer.task_operations import (
    _add_comment,
    _create_task,
    _get_task_details,
    _move_task,
    _update_task,
)

if TYPE_CHECKING:
    from artificer.router import Router


def create_app(
    adapter: TaskAdapter,
    router: Router | None = None,
    *,
    enable_queue_management: bool = False,
) -> Starlette:

    async def get_task_details(request: Request) -> JSONResponse:
        task_id = request.path_params["task_id"]
        try:
            result = _get_task_details(adapter, task_id)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result)

    async def add_comment(request: Request) -> JSONResponse:
        task_id = request.path_params["task_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        comment = body.get("comment")
        if not comment:
            return JSONResponse(
                {"error": "Missing required field: comment"}, status_code=400
            )
        try:
            result = _add_comment(adapter, task_id, comment)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse({"message": result})

    async def move_task(request: Request) -> JSONResponse:
        task_id = request.path_params["task_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        target_queue = body.get("target_queue")
        if not target_queue:
            return JSONResponse(
                {"error": "Missing required field: target_queue"}, status_code=400
            )
        try:
            result = _move_task(adapter, task_id, target_queue)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse({"message": result})

    async def create_task(request: Request) -> JSONResponse:
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        missing = [
            f for f in ("queue_name", "name", "description") if not body.get(f)
        ]
        if missing:
            return JSONResponse(
                {"error": f"Missing required fields: {', '.join(missing)}"},
                status_code=400,
            )
        try:
            result = _create_task(
                adapter, body["queue_name"], body["name"], body["description"]
            )
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result, status_code=201)

    async def update_task(request: Request) -> JSONResponse:
        task_id = request.path_params["task_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        UPDATABLE_FIELDS = {"assignees", "name", "description", "labels"}
        kwargs = {k: v for k, v in body.items() if k in UPDATABLE_FIELDS}
        if not kwargs:
            return JSONResponse(
                {"error": "No updatable fields provided"}, status_code=400
            )
        try:
            result = _update_task(adapter, task_id, **kwargs)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result)

    async def status(request: Request) -> JSONResponse:
        if router is None:
            return JSONResponse({"error": "Router not available"}, status_code=503)
        return JSONResponse(router.get_status())

    # --- Queue management handlers ---

    async def list_queues(request: Request) -> JSONResponse:
        try:
            result = _list_queues(adapter)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result)

    async def get_queue(request: Request) -> JSONResponse:
        queue_name = request.path_params["queue_name"]
        try:
            result = _get_queue(adapter, queue_name)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result)

    async def create_queue(request: Request) -> JSONResponse:
        if not enable_queue_management:
            return JSONResponse(
                {"error": "Queue management is disabled. Start with --enable-queue-management to enable."},
                status_code=403,
            )
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        name = body.get("name")
        if not name:
            return JSONResponse(
                {"error": "Missing required field: name"}, status_code=400
            )
        try:
            result = _create_queue(adapter, name)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result, status_code=201)

    async def update_queue(request: Request) -> JSONResponse:
        if not enable_queue_management:
            return JSONResponse(
                {"error": "Queue management is disabled. Start with --enable-queue-management to enable."},
                status_code=403,
            )
        queue_name = request.path_params["queue_name"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        new_name = body.get("name")
        if not new_name:
            return JSONResponse(
                {"error": "No updatable fields provided"}, status_code=400
            )
        try:
            result = _update_queue(adapter, queue_name, new_name=new_name)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result)

    async def delete_queue(request: Request) -> JSONResponse:
        if not enable_queue_management:
            return JSONResponse(
                {"error": "Queue management is disabled. Start with --enable-queue-management to enable."},
                status_code=403,
            )
        queue_name = request.path_params["queue_name"]
        try:
            result = _delete_queue(adapter, queue_name)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse({"message": result})

    routes = [
        Route("/status", status, methods=["GET"]),
        Route("/tasks/{task_id}/comments", add_comment, methods=["POST"]),
        Route("/tasks/{task_id}/move", move_task, methods=["POST"]),
        Route("/tasks/{task_id}", update_task, methods=["PATCH"]),
        Route("/tasks/{task_id}", get_task_details, methods=["GET"]),
        Route("/tasks", create_task, methods=["POST"]),
        Route("/queues", list_queues, methods=["GET"]),
        Route("/queues", create_queue, methods=["POST"]),
        Route("/queues/{queue_name:path}", get_queue, methods=["GET"]),
        Route("/queues/{queue_name:path}", update_queue, methods=["PATCH"]),
        Route("/queues/{queue_name:path}", delete_queue, methods=["DELETE"]),
    ]

    return Starlette(routes=routes)
