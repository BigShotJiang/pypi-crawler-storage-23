"""Planka backend for artificer-dispatcher.

This is a user-land file — it is not part of the ``artificer`` library.
It requires ``plankapy>=2.3.0`` to be installed separately::

    uv pip install plankapy>=2.3.0

Contains:
- ``PlankaCredentials`` — dataclass for Planka authentication
- ``PlankaAdapter`` — ``TaskAdapter`` implementation for Planka
- ``PlankaBackend`` — convenience wrapper for ``AgentDispatcher``
"""

from __future__ import annotations

import logging
import os
import re
from collections.abc import Sequence
from dataclasses import dataclass

from plankapy.v2 import Planka

from artificer.adapters.base import Queue, Task, TaskAdapter, TaskComment

log = logging.getLogger(__name__)


@dataclass
class PlankaCredentials:
    token: str | None = None
    username: str | None = None
    password: str | None = None

    @classmethod
    def from_env(cls) -> PlankaCredentials:
        token = os.environ.get("PLANKA_TOKEN")
        if token:
            return cls(token=token)
        username = os.environ.get("PLANKA_USER")
        password = os.environ.get("PLANKA_PASSWORD")
        if username and password:
            return cls(username=username, password=password)
        raise EnvironmentError(
            "Set PLANKA_TOKEN or both PLANKA_USER and PLANKA_PASSWORD"
        )


def _parse_queue(queue_name: str) -> tuple[str, str, str]:
    """Parse a dotted queue name into (project, board, list)."""
    parts = queue_name.split(".")
    if len(parts) != 3:
        raise ValueError(
            f"Planka queue name must be 'project.board.list', got: {queue_name!r}"
        )
    return parts[0], parts[1], parts[2]


class PlankaAdapter:
    def __init__(self, url: str, credentials: PlankaCredentials) -> None:
        auth_type = "token" if credentials.token else "password"
        log.debug("Connecting to Planka at %s (auth: %s)", url, auth_type)

        self._planka = Planka(url)
        if credentials.token:
            self._planka.login(api_key=credentials.token)
        else:
            self._planka.login(username=credentials.username, password=credentials.password)

        self._project_cache: dict[str, object] = {}
        self._board_cache: dict[tuple[str, str], object] = {}
        self._card_cache: dict[str, object] = {}
        log.debug("Planka adapter initialized")

    def _resolve_board(self, project_name: str, board_name: str):
        key = (project_name, board_name)
        if key not in self._board_cache:
            if project_name not in self._project_cache:
                log.debug("Resolving project=%r", project_name)
                project = self._planka.projects[{"name": project_name}].dpop()
                if project is None:
                    raise ValueError(f"Project not found: {project_name!r}")
                log.debug("Found project: %s (id=%s)", project.name, project.id)
                self._project_cache[project_name] = project
                # Eagerly cache all boards to avoid dpop() consuming the collection
                for board in project.boards:
                    bkey = (project_name, board.name)
                    log.debug("Cached board: %s (id=%s)", board.name, board.id)
                    self._board_cache[bkey] = board
            if key not in self._board_cache:
                raise ValueError(f"Board not found: {board_name!r} in project {project_name!r}")
        return self._board_cache[key]

    def _resolve_list(self, queue_name: str):
        project_name, board_name, list_name = _parse_queue(queue_name)
        board = self._resolve_board(project_name, board_name)
        log.debug("Resolving list=%r on board=%r", list_name, board_name)
        lst = board.lists[{"name": list_name}].dpop()
        if lst is None:
            raise KeyError(f"List not found: {list_name!r} on board {board_name!r}")
        log.debug("Found list: %s (id=%s)", lst.name, lst.id)
        return board, lst

    def _find_card(self, task_id: str):
        log.debug("Looking up card id=%s", task_id)
        if task_id in self._card_cache:
            card = self._card_cache[task_id]
            log.debug("Found card in cache: %s (id=%s)", card.name, card.id)
            return card
        # Search across cached boards
        for board in self._board_cache.values():
            card = board.cards[task_id]
            if card is not None:
                log.debug("Found card: %s (id=%s)", card.name, card.id)
                self._card_cache[task_id] = card
                return card
        raise KeyError(f"Card not found: {task_id}")

    def get_ready_tasks(self, queue_names: Sequence[str]) -> list[Task]:
        log.debug("Polling queues: %s", queue_names)
        tasks = []
        for queue_name in queue_names:
            try:
                _, lst = self._resolve_list(queue_name)
            except (KeyError, ValueError) as e:
                log.debug("Skipping queue %r: %s", queue_name, e)
                continue
            cards = list(lst.cards)
            log.debug("Queue %r: found %d cards", queue_name, len(cards))
            for card in cards:
                self._card_cache[card.id] = card
                tasks.append(self._card_to_task(card, source_queue=queue_name))
        log.debug("Total ready tasks: %d", len(tasks))
        return tasks

    def get_task(self, task_id: str) -> Task:
        card = self._find_card(task_id)
        return self._card_to_task(card)

    def move_task(self, task_id: str, target_queue: str) -> None:
        log.debug("Moving task %s -> %r", task_id, target_queue)
        card = self._find_card(task_id)
        _, target_list = self._resolve_list(target_queue)
        card.move(target_list)
        log.debug("Moved task %s to %r", task_id, target_queue)

    def add_comment(self, task_id: str, text: str) -> None:
        log.debug("Adding comment to task %s: %r", task_id, text[:80])
        card = self._find_card(task_id)
        card.comment(text)

    def update_task(
        self,
        task_id: str,
        *,
        assignees: list[str] | None = None,
        name: str | None = None,
        description: str | None = None,
        labels: list[str] | None = None,
        retry_count: int | None = None,
    ) -> None:
        card = self._find_card(task_id)

        if name is not None:
            log.debug("Updating name of task %s to %r", task_id, name)
            card.update(name=name)

        if description is not None:
            log.debug("Updating description of task %s", task_id)
            card.update(description=description)

        if assignees is not None:
            desired_users = [self._resolve_user(u) for u in assignees]
            current_members = {m.id for m in card.members}
            desired_ids = {u.id for u in desired_users}
            for user in desired_users:
                if user.id not in current_members:
                    log.debug("Adding member %s to task %s", user.name, task_id)
                    card.add_member(user)
            for member in card.members:
                if member.id not in desired_ids:
                    log.debug("Removing member %s from task %s", member.name, task_id)
                    card.remove_member(member)

        if labels is not None:
            board_labels = {lbl.name: lbl for lbl in card.board.labels}
            desired_labels = []
            for label_name in labels:
                if label_name not in board_labels:
                    raise ValueError(f"Label not found: {label_name!r}")
                desired_labels.append(board_labels[label_name])
            current_label_ids = {lbl.id for lbl in card.labels}
            desired_label_ids = {lbl.id for lbl in desired_labels}
            for lbl in desired_labels:
                if lbl.id not in current_label_ids:
                    log.debug("Adding label %s to task %s", lbl.name, task_id)
                    card.add_label(lbl)
            for lbl in card.labels:
                if lbl.id not in desired_label_ids:
                    log.debug("Removing label %s from task %s", lbl.name, task_id)
                    card.remove_label(lbl)

        if retry_count is not None:
            log.debug("Setting retry_count=%d on task %s via comment", retry_count, task_id)
            card.comment(f"[artificer:retry_count={retry_count}]")

    def _resolve_user(self, username: str):
        """Resolve a username string to a plankapy User object.

        The special value ``"me"`` resolves to the currently authenticated user.
        """
        if username == "me":
            return self._planka.me
        for user in self._planka.users:
            if user.name == username or user.username == username:
                return user
        raise ValueError(f"User not found: {username!r}")

    def create_task(self, queue_name: str, name: str, description: str = "") -> Task:
        log.debug("Creating task %r on queue %r", name, queue_name)
        _, lst = self._resolve_list(queue_name)
        card = lst.create_card(name=name, description=description or None)
        self._card_cache[card.id] = card
        log.debug("Created card %s (id=%s) on %r", card.name, card.id, queue_name)
        return self._card_to_task(card, source_queue=queue_name)

    def list_queues(self) -> list[Queue]:
        """Return all queues from cached boards.

        Note: This can only return queues from boards that have already been
        resolved/cached (i.e., boards referenced in the config routes).
        Queues on boards NOT in the config won't appear.
        """
        queues: list[Queue] = []
        for (project_name, board_name), board in self._board_cache.items():
            for lst in board.lists:
                name = f"{project_name}.{board_name}.{lst.name}"
                task_count = len(list(lst.cards))
                queues.append(Queue(name=name, task_count=task_count))
        return queues

    def get_queue(self, queue_name: str) -> Queue:
        _, lst = self._resolve_list(queue_name)
        return Queue(name=queue_name, task_count=len(list(lst.cards)))

    def create_queue(self, queue_name: str) -> Queue:
        project_name, board_name, list_name = _parse_queue(queue_name)
        board = self._resolve_board(project_name, board_name)
        # Check if list already exists
        existing = board.lists[{"name": list_name}].dpop()
        if existing is not None:
            raise ValueError(f"Queue already exists: {queue_name!r}")
        log.debug("Creating list %r on board %r", list_name, board_name)
        board.create_list(name=list_name)
        return Queue(name=queue_name, task_count=0)

    def update_queue(self, queue_name: str, *, new_name: str | None = None) -> Queue:
        project_name, board_name, list_name = _parse_queue(queue_name)
        _, lst = self._resolve_list(queue_name)
        if new_name is not None:
            _, _, new_list_name = _parse_queue(new_name)
            # Check if the new list name already exists on this board
            board = self._resolve_board(project_name, board_name)
            existing = board.lists[{"name": new_list_name}].dpop()
            if existing is not None:
                raise ValueError(f"Queue already exists: {new_name!r}")
            log.debug("Renaming list %r to %r on board %r", list_name, new_list_name, board_name)
            lst.update(name=new_list_name)
            task_count = len(list(lst.cards))
            return Queue(name=new_name, task_count=task_count)
        task_count = len(list(lst.cards))
        return Queue(name=queue_name, task_count=task_count)

    def delete_queue(self, queue_name: str) -> None:
        project_name, board_name, _ = _parse_queue(queue_name)
        board, lst = self._resolve_list(queue_name)
        cards = list(lst.cards)
        if cards:
            raise ValueError(f"Queue is not empty: {queue_name!r}")
        log.debug("Deleting list %r from board %r", lst.name, board_name)
        board.remove_list(lst)

    def _card_to_task(self, card, source_queue: str = "") -> Task:
        description = card.description or ""
        checklist_lines = []
        for t in card.tasks:
            mark = "x" if t.is_completed else " "
            checklist_lines.append(f"- [{mark}] {t.name}")
        if checklist_lines:
            suffix = "\n\n## Checklist\n" + "\n".join(checklist_lines)
            description = (description + suffix) if description else suffix.lstrip("\n")
        comments = [
            TaskComment(
                author=c.user.name,
                text=c.text,
                created_at=str(c.created_at) if c.created_at else "",
            )
            for c in card.comments
        ]

        # Extract retry_count from structured comment markers
        retry_count = 0
        for c in card.comments:
            match = re.search(r"\[artificer:retry_count=(\d+)\]", c.text)
            if match:
                retry_count = int(match.group(1))

        return Task(
            id=card.id,
            name=card.name,
            description=description,
            url=card.url or "",
            source_queue=source_queue,
            labels=[label.name for label in card.labels],
            assignees=[user.name for user in card.members],
            comments=comments,
            retry_count=retry_count,
        )


class PlankaBackend:
    """Convenience wrapper for configuring the Planka task backend.

    Credentials can be supplied directly or resolved from environment
    variables at ``create_adapter()`` time (i.e. when ``dispatcher.run()``
    is called).

    Args:
        url: The Planka server URL (e.g. ``"http://localhost:3000"``).
        token: Optional API token for authentication.
        username: Optional username for password authentication.
        password: Optional password for password authentication.
    """

    def __init__(
        self,
        url: str,
        *,
        token: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> None:
        self.url = url
        self._token = token
        self._username = username
        self._password = password

    def create_adapter(self) -> PlankaAdapter:
        if self._token or self._username:
            credentials = PlankaCredentials(
                token=self._token,
                username=self._username,
                password=self._password,
            )
        else:
            credentials = PlankaCredentials.from_env()
        return PlankaAdapter(self.url, credentials)
