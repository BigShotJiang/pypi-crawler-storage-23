"""Data models for the PyCharter worker service."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class JobStatus(str, Enum):
    """Lifecycle status of a validation job."""

    PENDING = "pending"
    CLAIMED = "claimed"
    COMPLETED = "completed"
    FAILED = "failed"
    DEAD_LETTER = "dead_letter"
    CANCELLED = "cancelled"


@dataclass
class ValidationJob:
    """Envelope for submitting a validation job."""

    contract_name: str
    contract_version: str
    data_source: str
    options: dict[str, Any] | None = None
    job_id: str | None = None
    fires_at: datetime | None = None
    idempotency_key: str | None = None
    max_attempts: int = 5


@dataclass
class ClaimedJob:
    """A job that has been atomically claimed by a worker."""

    event_id: str
    contract_name: str
    contract_version: str
    data_source: str
    options: dict[str, Any] | None
    attempt: int
    max_attempts: int
    fires_at: datetime
    claimed_at: datetime
