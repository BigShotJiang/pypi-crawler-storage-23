"""
Ontology artifact for pycharter-wiki.

Provides data models, parsing, validation, and taxonomy for
semantic annotations on data contract fields.
"""

from __future__ import annotations

from pycharter.wiki.ontology.models import (
    ConceptDefinition,
    ConceptScheme,
    ConceptTier,
    FieldOntology,
    Lineage,
    OntologyArtifact,
    Relationship,
    RelationshipType,
)
from pycharter.wiki.ontology.parser import parse_ontology, parse_ontology_file
from pycharter.wiki.ontology.taxonomy import (
    classify_concept,
    get_concept_hierarchy,
    list_core_concepts,
    register_core_concept,
)
from pycharter.wiki.ontology.validator import (
    validate_ontology,
    validate_ontology_artifact,
)

__all__ = [
    # Models
    "ConceptDefinition",
    "ConceptScheme",
    "ConceptTier",
    "RelationshipType",
    "Lineage",
    "Relationship",
    "FieldOntology",
    "OntologyArtifact",
    # Parser
    "parse_ontology",
    "parse_ontology_file",
    # Validator
    "validate_ontology",
    "validate_ontology_artifact",
    # Taxonomy
    "classify_concept",
    "register_core_concept",
    "list_core_concepts",
    "get_concept_hierarchy",
]
