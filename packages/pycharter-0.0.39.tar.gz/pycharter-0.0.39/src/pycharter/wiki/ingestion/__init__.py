"""
Ingestion layer for pycharter-wiki.

Bridges pycharter contracts with the wiki knowledge system by
importing ontology files and materializing them into the knowledge graph.
"""

from __future__ import annotations

from pycharter.wiki.ingestion.importer import OntologyImporter

__all__ = [
    "OntologyImporter",
]
