"""
RDF / JSON-LD / SHACL support for pycharter-wiki.

Provides conversion between YAML-authored ontologies and standards-based
RDF formats (JSON-LD, Turtle) plus SHACL validation.

All functions in this package require the ``ontology`` optional dependency
group (``rdflib``, ``pyshacl``).  Core pycharter works without them.
"""

from __future__ import annotations


def _check_rdflib() -> None:
    try:
        import rdflib  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "The 'rdflib' package is required for RDF/JSON-LD support. "
            "Install it with: pip install pycharter[ontology]"
        ) from exc


def _check_pyshacl() -> None:
    try:
        import pyshacl  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "The 'pyshacl' package is required for SHACL validation. "
            "Install it with: pip install pycharter[ontology]"
        ) from exc
