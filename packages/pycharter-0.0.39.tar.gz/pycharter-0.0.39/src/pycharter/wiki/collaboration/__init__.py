"""
Collaboration module for pycharter-wiki.

Provides proposal/review workflows and tiered governance:
- ProposalManager: CRUD for proposals (change requests)
- ReviewWorkflow: Submit reviews and check approval status
- PermissionChecker: Tiered governance enforcement
"""

from __future__ import annotations

from pycharter.wiki.collaboration.conflicts import (
    detect_proposal_conflicts,
    suggest_resolution,
)
from pycharter.wiki.collaboration.permissions import PermissionChecker
from pycharter.wiki.collaboration.proposals import ProposalManager
from pycharter.wiki.collaboration.review import ReviewWorkflow

__all__ = [
    "ProposalManager",
    "ReviewWorkflow",
    "PermissionChecker",
    "detect_proposal_conflicts",
    "suggest_resolution",
]
