"""
Versioning engine for pycharter-wiki.

Provides git-like version control for ontology artifacts:
- Diff: Field-level comparison between ontology versions
- Merge: Three-way merge with conflict detection
- History: Version tracking with branches
"""

from __future__ import annotations

from pycharter.wiki.versioning.diff import compute_ontology_diff
from pycharter.wiki.versioning.merge import merge_ontologies
from pycharter.wiki.versioning.models import (
    BranchInfo,
    FieldChange,
    OntologyDiff,
    OntologyMergeResult,
    VersionInfo,
)

__all__ = [
    # Models
    "VersionInfo",
    "BranchInfo",
    "FieldChange",
    "OntologyDiff",
    "OntologyMergeResult",
    # Diff
    "compute_ontology_diff",
    # Merge
    "merge_ontologies",
]
