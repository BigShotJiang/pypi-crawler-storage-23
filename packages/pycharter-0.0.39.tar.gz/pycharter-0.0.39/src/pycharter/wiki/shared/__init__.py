"""
Shared utilities used across all pycharter-wiki services.

Includes:
- Protocols (interface definitions for extensible components)
- Error handling (exception hierarchy, error modes, context managers)
"""

from __future__ import annotations

from pycharter.wiki.shared.errors import (
    CollaborationError,
    ErrorContext,
    ErrorMode,
    GraphError,
    IngestionError,
    LenientMode,
    MergeConflictError,
    OntologyError,
    OntologyValidationError,
    PyCharterWikiError,
    StrictMode,
    VersioningError,
    get_error_context,
    handle_error,
    handle_warning,
    set_error_mode,
)
from pycharter.wiki.shared.protocols import (
    ConflictResolver,
    GraphTraverser,
    OntologyStore,
    VersionStore,
)

__all__ = [
    # Protocols
    "OntologyStore",
    "VersionStore",
    "GraphTraverser",
    "ConflictResolver",
    # Exception hierarchy
    "PyCharterWikiError",
    "OntologyError",
    "OntologyValidationError",
    "VersioningError",
    "MergeConflictError",
    "CollaborationError",
    "GraphError",
    "IngestionError",
    # Error handling
    "ErrorMode",
    "ErrorContext",
    "get_error_context",
    "set_error_mode",
    "handle_error",
    "handle_warning",
    "StrictMode",
    "LenientMode",
]
