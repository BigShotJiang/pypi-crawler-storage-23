"""Wiki API routes and dependencies."""

from __future__ import annotations
