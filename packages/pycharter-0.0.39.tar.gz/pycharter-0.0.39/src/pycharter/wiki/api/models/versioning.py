"""Pydantic models for versioning API endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class CreateVersionRequest(BaseModel):
    """Request to create a new version."""

    contract_id: str
    content: dict[str, Any] | None
    message: str
    author: str
    parent_id: str | None = None
    branch_id: str | None = None


class CreateBranchRequest(BaseModel):
    """Request to create a branch."""

    contract_id: str
    name: str
    base_version_id: str | None = None
    created_by: str | None = None


class DiffRequest(BaseModel):
    """Request to compute a diff."""

    old_content: dict[str, Any] | None
    new_content: dict[str, Any] | None


class MergeRequest(BaseModel):
    """Request to perform a three-way merge."""

    base: dict[str, Any] | None
    ours: dict[str, Any] | None
    theirs: dict[str, Any] | None


class VersionResponse(BaseModel):
    """Version info response."""

    version_id: str
    contract_id: str
    parent_id: str | None = None
    message: str
    author: str
    created_at: str | None = None
