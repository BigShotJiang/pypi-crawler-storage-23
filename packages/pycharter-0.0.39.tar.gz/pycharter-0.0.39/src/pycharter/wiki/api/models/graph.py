"""Pydantic models for graph API endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ConceptTreeResponse(BaseModel):
    """Response containing the concept hierarchy tree."""

    roots: list[dict[str, Any]]
