"""Pydantic models for ontology API endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class OntologyParseRequest(BaseModel):
    """Request to parse ontology data."""

    data: dict[str, Any] | None


class OntologyValidateRequest(BaseModel):
    """Request to validate ontology data."""

    data: dict[str, Any] | None


class OntologyValidateResponse(BaseModel):
    """Response from ontology validation."""

    valid: bool
    errors: list[dict[str, str]]


class OntologyResponse(BaseModel):
    """Parsed ontology response."""

    version: str
    fields: dict[str, Any] | None
