"""Pydantic models for proposals API endpoints."""

from __future__ import annotations

from pydantic import BaseModel


class CreateProposalRequest(BaseModel):
    """Request to create a proposal."""

    contract_id: str
    title: str
    author: str
    description: str | None = None
    source_branch_id: str | None = None
    target_branch_id: str | None = None


class UpdateProposalStatusRequest(BaseModel):
    """Request to update proposal status."""

    status: str
    updated_by: str | None = None
