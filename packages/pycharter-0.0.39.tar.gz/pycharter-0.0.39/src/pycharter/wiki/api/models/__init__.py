"""Pydantic models for wiki API endpoints."""

from __future__ import annotations
