"""Reviews API routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query

from pycharter.wiki.api.dependencies import get_db_session
from pycharter.wiki.api.models.reviews import SubmitReviewRequest
from pycharter.wiki.collaboration.review import ReviewWorkflow
from pycharter.wiki.shared.errors import CollaborationError

router = APIRouter(tags=["Wiki"])


@router.post("/")
async def submit_review(request: SubmitReviewRequest, session=Depends(get_db_session)):
    """Submit a review on a proposal."""
    try:
        rw = ReviewWorkflow(session)
        review_id = rw.submit_review(
            proposal_id=request.proposal_id,
            reviewer=request.reviewer,
            decision=request.decision,
            comment=request.comment,
        )
        return {"review_id": review_id}
    except CollaborationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/proposal/{proposal_id}")
async def get_reviews(proposal_id: str, session=Depends(get_db_session)):
    """Get all reviews for a proposal."""
    rw = ReviewWorkflow(session)
    return rw.get_reviews(proposal_id)


@router.get("/proposal/{proposal_id}/status")
async def check_approval(
    proposal_id: str,
    required: int = Query(1),
    session=Depends(get_db_session),
):
    """Check approval status for a proposal."""
    rw = ReviewWorkflow(session)
    return rw.check_approval_status(proposal_id, required_approvals=required)
