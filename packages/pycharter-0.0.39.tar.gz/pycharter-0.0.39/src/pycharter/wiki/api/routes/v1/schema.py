"""Knowledge schema info API routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from pycharter.wiki.ontology.schema_loader import (
    get_node_kinds,
    get_relationship_types,
    load_knowledge_schema,
)

router = APIRouter(tags=["Wiki - Schema"])


@router.get("/relationship-types")
async def list_relationship_types():
    """List all available relationship types with metadata."""
    try:
        types = get_relationship_types()
        return {
            name: {
                "meaning": info.meaning,
                "graph_shape": info.graph_shape,
                "inverse": info.inverse,
                "symmetric": info.symmetric,
            }
            for name, info in types.items()
        }
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/node-kinds")
async def list_node_kinds():
    """List all available node kinds with descriptions."""
    try:
        return get_node_kinds()
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/version")
async def get_schema_version():
    """Get the current knowledge schema version."""
    try:
        schema = load_knowledge_schema()
        return {
            "version": schema.version,
            "relationship_type_count": len(schema.relationship_types),
            "node_kind_count": len(schema.node_kinds),
        }
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))
