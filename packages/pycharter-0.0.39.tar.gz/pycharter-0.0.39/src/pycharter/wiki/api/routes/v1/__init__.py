"""Wiki API v1 route modules."""

from __future__ import annotations
