"""Wiki API route modules."""

from __future__ import annotations
