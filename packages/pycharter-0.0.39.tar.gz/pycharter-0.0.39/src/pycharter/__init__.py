"""
PyCharter - Data Contract Management, ETL Pipelines, and Validation

Core Services:
1. ETL Pipelines - Build and run ETL pipelines with | operator
2. Contract Parser - Reads and decomposes data contract files
3. Contract Builder - Constructs consolidated contracts from separate artifacts
4. Metadata Store - Database operations for metadata storage
5. Pydantic Generator - Generates Pydantic models from JSON Schema
6. JSON Schema Converter - Converts Pydantic models to JSON Schema
7. Runtime Validator - Validation utilities
8. Quality Assurance - Data quality checking and monitoring

ETL API:
    >>> from pycharter import Pipeline, HTTPExtractor, PostgresLoader, Rename, AddField
    >>>
    >>> # Programmatic pipeline with | operator
    >>> pipeline = (
    ...     Pipeline(HTTPExtractor(url="https://api.example.com/data"))
    ...     | Rename({"old": "new"})
    ...     | AddField("processed_at", "now()")
    ...     | PostgresLoader(connection_string="...", table="users")
    ... )
    >>> result = await pipeline.run()  # run() is async; use asyncio.run() from scripts
    >>>
    >>> # Config-driven (explicit files)
    >>> pipeline = Pipeline.from_config_files(
    ...     extract="configs/extract.yaml",
    ...     load="configs/load.yaml",
    ...     variables={"API_KEY": "secret"}
    ... )
    >>>
    >>> # Config-driven (directory with extract.yaml, transform.yaml, load.yaml)
    >>> pipeline = Pipeline.from_config_dir("pipelines/users/")
    >>>
    >>> # Config-driven (single file)
    >>> pipeline = Pipeline.from_config_file("pipelines/users/pipeline.yaml")

Validator API:
    >>> from pycharter import Validator
    >>>
    >>> # From explicit files
    >>> validator = Validator.from_files(schema="schema.yaml")
    >>>
    >>> # From directory
    >>> validator = Validator.from_dir("contracts/users/")
    >>>
    >>> result = validator.validate({"name": "Alice", "age": 30})
"""

from __future__ import annotations

__version__ = "0.1.0"

# ============================================================================
# ETL PIPELINES
# ============================================================================

# Contract Builder
from pycharter.contract_builder import (
    ContractArtifacts,
    build_contract,
    build_contract_from_store,
)

# Contract Parser
from pycharter.contract_parser import (
    ContractMetadata,
    parse_contract,
    parse_contract_file,
)
from pycharter.etl_generator import (  # Core; Protocols; Extractors; Transformers; Loaders
    AddField,
    BaseExtractor,
    BaseLoader,
    BaseTransformer,
    BatchResult,
    CloudStorageExtractor,
    CloudStorageLoader,
    Convert,
    CustomFunction,
    DatabaseExtractor,
    DatabaseLoader,
    Default,
    Drop,
    Extractor,
    FileExtractor,
    FileLoader,
    Filter,
    FlatMap,
    HTTPExtractor,
    Loader,
    LoadResult,
    Map,
    Pipeline,
    PipelineBuilder,
    PipelineContext,
    PipelineResult,
    PostgresLoader,
    Rename,
    Select,
    Transformer,
    TransformerChain,
)

# JSON Schema Converter - Output type helpers (convenience)
from pycharter.json_schema_converter import model_to_schema  # Advanced: core conversion
from pycharter.json_schema_converter import to_dict  # Quick: schema to dict
from pycharter.json_schema_converter import to_file  # Quick: schema to file
from pycharter.json_schema_converter import to_json  # Quick: schema to JSON string

# Metadata Store (PRIMARY INTERFACE)
from pycharter.metadata_store import MetadataStoreClient

# Pydantic Generator - Input type helpers (convenience)
from pycharter.pydantic_generator import from_dict  # Quick: schema from dict
from pycharter.pydantic_generator import from_file  # Quick: schema from file
from pycharter.pydantic_generator import from_json  # Quick: schema from JSON string
from pycharter.pydantic_generator import from_url  # Quick: schema from URL
from pycharter.pydantic_generator import (
    generate_model,  # Advanced: when you need more control
)
from pycharter.pydantic_generator import generate_model_file

# Quality Assurance (PRIMARY INTERFACE)
from pycharter.quality import QualityCheck  # ⭐ PRIMARY: Use this for quality checks
from pycharter.quality import QualityCheckOptions, QualityReport, QualityThresholds

# Runtime Validator (PRIMARY INTERFACE)
from pycharter.runtime_validator import Validator  # ⭐ PRIMARY: Use this for validation
from pycharter.runtime_validator import (
    ValidatorBuilder,  # Fluent API for building validators
)
from pycharter.runtime_validator import (
    get_model_from_contract,  # Quick: get model from contract
)
from pycharter.runtime_validator import (
    get_model_from_store,  # Quick: get model from store
)
from pycharter.runtime_validator import (
    validate,  # Low-level: validate with existing model
)
from pycharter.runtime_validator import (
    validate_batch,  # Low-level: batch validate with existing model
)
from pycharter.runtime_validator import (
    validate_batch_with_contract,  # Quick: batch validate with contract file/dict
)
from pycharter.runtime_validator import (
    validate_batch_with_store,  # Quick: batch validate with metadata store
)
from pycharter.runtime_validator import (
    validate_with_contract,  # Quick: validate with contract file/dict
)
from pycharter.runtime_validator import (
    validate_with_store,  # Quick: validate with metadata store
)
from pycharter.runtime_validator import (  # Quick validation functions (use Validator class for multiple validations); Decorators; Schema utilities
    ValidationResult,
    create_validator,
    get_merged_schema_from_contract,
    merge_rules_into_schema,
    validate_input,
    validate_output,
    validate_with_contract_decorator,
)

# ============================================================================
# TIER 1: PRIMARY INTERFACES (Classes - Use these for best performance)
# ============================================================================

# ============================================================================
# TIER 2: CONVENIENCE FUNCTIONS (Quick start - one-off use cases)
# ============================================================================

# ============================================================================
# TIER 3: LOW-LEVEL UTILITIES (When you already have models/schemas)
# ============================================================================

# ============================================================================
# METADATA STORE IMPLEMENTATIONS
# ============================================================================

try:
    from pycharter.metadata_store import InMemoryMetadataStore
except ImportError:
    InMemoryMetadataStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.metadata_store import MongoDBMetadataStore
except ImportError:
    MongoDBMetadataStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.metadata_store import PostgresMetadataStore
except ImportError:
    PostgresMetadataStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.metadata_store import RedisMetadataStore
except ImportError:
    RedisMetadataStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.metadata_store import SQLiteMetadataStore
except ImportError:
    SQLiteMetadataStore = None  # type: ignore[assignment,misc]

# ============================================================================
# QUALITY ASSURANCE - Additional utilities (if needed for advanced use)
# ============================================================================

from pycharter.docs_generator import (
    DocsGenerator,
    HTMLRenderer,
    MarkdownRenderer,
    generate_docs,
)
from pycharter.domain import (
    DEFAULT_STATE_FIELD,
    check_state_alignment,
    get_domain_entity_info,
    get_lifecycle_binding,
    validate_lifecycle_binding,
)
from pycharter.quality import (  # Tracking submodule
    DataProfiler,
    FieldQualityMetrics,
    InMemoryMetricsStore,
    MetricsCollector,
    MetricsSummary,
    QualityMetrics,
    QualityScore,
    SQLiteMetricsStore,
    ValidationMetric,
    ViolationRecord,
    ViolationTracker,
)
from pycharter.schema_evolution import (
    ChangeType,
    CompatibilityMode,
    CompatibilityResult,
    SchemaChange,
    SchemaDiff,
    check_compatibility,
    compute_diff,
)
from pycharter.shared import (  # Protocols for extensibility; Exception hierarchy (catch PyCharterError for any pycharter failure); Error handling
    CoercionRegistry,
    ConfigError,
    ConfigLoadError,
    ConfigValidationError,
    DataValidator,
    ErrorContext,
    ErrorMode,
    ExpressionError,
    LenientMode,
    MetadataStore,
    PyCharterError,
    StrictMode,
    ValidationRegistry,
    set_error_mode,
)

# ============================================================================
# DOCUMENTATION GENERATION
# ============================================================================

# ============================================================================
# DOMAIN ENTITY LIFECYCLE (engine-agnostic)
# ============================================================================

# ============================================================================
# SCHEMA EVOLUTION
# ============================================================================

# ============================================================================
# PROTOCOLS AND ERROR HANDLING
# ============================================================================

__all__ = [
    # ========================================================================
    # ETL PIPELINES
    # ========================================================================
    # Core
    "Pipeline",
    "PipelineBuilder",
    "PipelineContext",
    "PipelineResult",
    "BatchResult",
    "LoadResult",
    # Protocols
    "Extractor",
    "Transformer",
    "Loader",
    # Extractors
    "BaseExtractor",
    "HTTPExtractor",
    "FileExtractor",
    "DatabaseExtractor",
    "CloudStorageExtractor",
    # Transformers
    "BaseTransformer",
    "TransformerChain",
    "Rename",
    "AddField",
    "Drop",
    "Select",
    "Filter",
    "Convert",
    "Default",
    "Map",
    "FlatMap",
    "CustomFunction",
    # Loaders
    "BaseLoader",
    "PostgresLoader",
    "DatabaseLoader",
    "FileLoader",
    "CloudStorageLoader",
    # Exceptions and error handling
    "PyCharterError",
    "ConfigError",
    "ConfigValidationError",
    "ConfigLoadError",
    "ExpressionError",
    "ErrorMode",
    "ErrorContext",
    "StrictMode",
    "LenientMode",
    "set_error_mode",
    # ========================================================================
    # DATA CONTRACT SERVICES
    # ========================================================================
    # Validation
    "Validator",
    "ValidatorBuilder",
    "create_validator",
    "ValidationResult",
    "validate_with_store",
    "validate_batch_with_store",
    "validate_with_contract",
    "validate_batch_with_contract",
    "get_model_from_store",
    "get_model_from_contract",
    "validate",
    "validate_batch",
    "validate_input",
    "validate_output",
    "validate_with_contract_decorator",
    # Schema utilities
    "merge_rules_into_schema",
    "get_merged_schema_from_contract",
    # Quality
    "QualityCheck",
    "QualityCheckOptions",
    "QualityReport",
    "QualityThresholds",
    "QualityMetrics",
    "QualityScore",
    "FieldQualityMetrics",
    "ViolationTracker",
    "ViolationRecord",
    "DataProfiler",
    # Contract Management
    "parse_contract",
    "parse_contract_file",
    "ContractMetadata",
    "build_contract",
    "build_contract_from_store",
    "ContractArtifacts",
    # Pydantic Generator
    "from_dict",
    "from_file",
    "from_json",
    "from_url",
    "generate_model",
    "generate_model_file",
    # JSON Schema Converter
    "to_dict",
    "to_file",
    "to_json",
    "model_to_schema",
    # Metadata Store
    "MetadataStoreClient",
    "InMemoryMetadataStore",
    "MongoDBMetadataStore",
    "PostgresMetadataStore",
    "RedisMetadataStore",
    "SQLiteMetadataStore",
    # Protocols
    "MetadataStore",
    "CoercionRegistry",
    "ValidationRegistry",
    "DataValidator",
    # Error handling
    "ErrorMode",
    "ErrorContext",
    "StrictMode",
    "LenientMode",
    "set_error_mode",
    # ========================================================================
    # QUALITY TRACKING
    # ========================================================================
    "MetricsCollector",
    "ValidationMetric",
    "MetricsSummary",
    "InMemoryMetricsStore",
    "SQLiteMetricsStore",
    # ========================================================================
    # DOCUMENTATION GENERATION
    # ========================================================================
    "DocsGenerator",
    "generate_docs",
    "MarkdownRenderer",
    "HTMLRenderer",
    # ========================================================================
    # SCHEMA EVOLUTION
    # ========================================================================
    "check_compatibility",
    "compute_diff",
    "CompatibilityResult",
    "SchemaDiff",
    "SchemaChange",
    "ChangeType",
    "CompatibilityMode",
    # ========================================================================
    # DOMAIN ENTITY LIFECYCLE
    # ========================================================================
    "DEFAULT_STATE_FIELD",
    "get_lifecycle_binding",
    "get_domain_entity_info",
    "check_state_alignment",
    "validate_lifecycle_binding",
]
