from unittest.mock import MagicMock, mock_open, patch

import httpx

from nacho.api_client import APIClient


def _make_response(status_code=200, json_data=None, content=b""):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    resp.content = content
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    return resp


# ── Headers ─────────────────────────────────────────────────────────


def test_headers_with_token():
    with patch("nacho.api_client.load_token", return_value="nacho_tok123"):
        client = APIClient()
    h = client.headers
    assert h["Authorization"] == "Bearer nacho_tok123"
    assert h["Content-Type"] == "application/json"


def test_headers_without_token():
    with patch("nacho.api_client.load_token", return_value=None):
        client = APIClient()
    h = client.headers
    assert "Authorization" not in h
    assert h["Content-Type"] == "application/json"


# ── login ───────────────────────────────────────────────────────────


def test_login_success():
    resp = _make_response(json_data={"access_token": "jwt123", "refresh_token": "ref456"})
    with (
        patch("nacho.api_client.load_token", return_value=None),
        patch("httpx.post", return_value=resp) as mock_post,
    ):
        client = APIClient()
        result = client.login("user@example.com", "password123")

    mock_post.assert_called_once()
    assert result["access_token"] == "jwt123"


def test_login_wrong_credentials():
    resp = _make_response(status_code=401)
    with (
        patch("nacho.api_client.load_token", return_value=None),
        patch("httpx.post", return_value=resp),
    ):
        client = APIClient()
        try:
            client.login("user@example.com", "wrong")
            assert False, "Should have raised"
        except httpx.HTTPStatusError:
            pass


# ── push ────────────────────────────────────────────────────────────


def test_push_creates_context(tmp_path):
    md_file = tmp_path / "context.md"
    md_file.write_text("# Hello")

    resp_data = {
        "context": {"owner_username": "me", "name": "ctx", "id": "abc"},
        "version": {"version": 1},
    }
    resp = _make_response(json_data=resp_data)
    with (
        patch("nacho.api_client.load_token", return_value="tok"),
        patch("httpx.post", return_value=resp) as mock_post,
    ):
        client = APIClient()
        result = client.push(str(md_file), "ctx", "My Context", tags="python")

    assert result["context"]["name"] == "ctx"
    call_kwargs = mock_post.call_args
    assert call_kwargs.kwargs["data"]["tags"] == "python"


def test_push_version(tmp_path):
    md_file = tmp_path / "v2.md"
    md_file.write_text("# v2")

    resp = _make_response(json_data={"version": 2, "changelog": "update"})
    with (
        patch("nacho.api_client.load_token", return_value="tok"),
        patch("httpx.post", return_value=resp) as mock_post,
    ):
        client = APIClient()
        result = client.push_version("ctx-id-123", str(md_file), changelog="update")

    assert result["version"] == 2
    assert "ctx-id-123/versions" in mock_post.call_args.args[0]


# ── get_my_context ──────────────────────────────────────────────────


def test_get_my_context_found():
    me_resp = _make_response(json_data={"username": "alice"})
    ctx_resp = _make_response(json_data={"id": "abc", "name": "my-ctx"})

    with (
        patch("nacho.api_client.load_token", return_value="tok"),
        patch("httpx.get", side_effect=[me_resp, ctx_resp]),
    ):
        client = APIClient()
        result = client.get_my_context("my-ctx")

    assert result["name"] == "my-ctx"


def test_get_my_context_not_found():
    me_resp = _make_response(json_data={"username": "alice"})
    ctx_resp = _make_response(status_code=404)
    # Override raise_for_status to not raise for 404 (the method handles it)
    ctx_resp.raise_for_status = MagicMock()

    with (
        patch("nacho.api_client.load_token", return_value="tok"),
        patch("httpx.get", side_effect=[me_resp, ctx_resp]),
    ):
        client = APIClient()
        result = client.get_my_context("no-such")

    assert result is None


# ── pull ────────────────────────────────────────────────────────────


def test_pull_downloads_content():
    ctx_resp = _make_response(json_data={"id": "abc"})
    dl_resp = _make_response(content=b"# My context content")

    with (
        patch("nacho.api_client.load_token", return_value="tok"),
        patch("httpx.get", side_effect=[ctx_resp, dl_resp]),
    ):
        client = APIClient()
        content = client.pull("alice", "my-ctx")

    assert content == b"# My context content"


def test_pull_specific_version():
    ctx_resp = _make_response(json_data={"id": "abc"})
    dl_resp = _make_response(content=b"# v1 content")

    with (
        patch("nacho.api_client.load_token", return_value="tok"),
        patch("httpx.get", side_effect=[ctx_resp, dl_resp]) as mock_get,
    ):
        client = APIClient()
        content = client.pull("alice", "my-ctx", version=1)

    # Second call should include version param
    assert mock_get.call_args_list[1].kwargs.get("params") == {"version": 1}
    assert content == b"# v1 content"


# ── search ──────────────────────────────────────────────────────────


def test_search_returns_results():
    resp = _make_response(json_data={
        "items": [{"name": "ctx1", "title": "Context 1"}],
        "total": 1,
        "page": 1,
        "pages": 1,
    })
    with (
        patch("nacho.api_client.load_token", return_value=None),
        patch("httpx.get", return_value=resp) as mock_get,
    ):
        client = APIClient()
        result = client.search("python")

    assert len(result["items"]) == 1
    assert mock_get.call_args.kwargs["params"] == {"q": "python", "page": 1}


def test_search_custom_page():
    resp = _make_response(json_data={"items": [], "total": 0, "page": 3, "pages": 3})
    with (
        patch("nacho.api_client.load_token", return_value=None),
        patch("httpx.get", return_value=resp) as mock_get,
    ):
        client = APIClient()
        client.search("python", page=3)

    assert mock_get.call_args.kwargs["params"]["page"] == 3
