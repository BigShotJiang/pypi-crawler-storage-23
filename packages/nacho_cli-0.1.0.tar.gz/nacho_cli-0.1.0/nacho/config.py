import os
from pathlib import Path

import yaml

DEFAULT_API_URL = "https://nacho.bot/api"
CREDENTIALS_DIR = Path.home() / ".nacho"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials"


def get_api_url() -> str:
    return os.environ.get("NACHO_API_URL", DEFAULT_API_URL)


def save_token(token: str) -> None:
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(token)
    CREDENTIALS_FILE.chmod(0o600)


def load_token() -> str | None:
    if CREDENTIALS_FILE.exists():
        return CREDENTIALS_FILE.read_text().strip()
    return None


def clear_token() -> None:
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def load_context_config(path: str = ".") -> dict:
    """Load .nacho.yml from the given directory."""
    config_path = Path(path) / ".nacho.yml"
    if not config_path.exists():
        return {}
    with open(config_path) as f:
        return yaml.safe_load(f) or {}


NACHO_DIR = Path(".nacho")
CONTEXTS_FILE = NACHO_DIR / "contexts.yml"


def load_tracked_contexts(path: str = ".") -> dict:
    """Read .nacho/contexts.yml and return dict keyed by file path."""
    contexts_file = Path(path) / CONTEXTS_FILE
    if not contexts_file.exists():
        return {}
    with open(contexts_file) as f:
        data = yaml.safe_load(f) or {}
    return data.get("contexts", {})


def save_tracked_context(file_path: str, metadata: dict, path: str = ".") -> None:
    """Upsert one entry into .nacho/contexts.yml, creating .nacho/ dir if needed."""
    nacho_dir = Path(path) / NACHO_DIR
    contexts_file = Path(path) / CONTEXTS_FILE

    nacho_dir.mkdir(parents=True, exist_ok=True)

    existing = {}
    if contexts_file.exists():
        with open(contexts_file) as f:
            existing = yaml.safe_load(f) or {}

    contexts = existing.get("contexts", {})
    contexts[file_path] = metadata

    with open(contexts_file, "w") as f:
        yaml.dump({"contexts": contexts}, f, default_flow_style=False)
