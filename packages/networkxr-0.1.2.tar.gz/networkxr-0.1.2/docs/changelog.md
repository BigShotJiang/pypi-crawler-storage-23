# Changelog

All notable changes are documented here.
This project follows [Semantic Versioning](https://semver.org/).

---

### 🚀 Features

- add faker-powered graph generators

### 🚀 Features

- networkxr with Rust SIMD, Rayon parallelism, FxHashMap — 10x-100x faster than NetworkX
- Implement interactive graph plotting functionality using Plotly with new documentation and tests.
- add Plotly drawing support + cookbook + README examples

