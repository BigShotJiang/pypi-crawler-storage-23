# xpute

Minimal `printf/sprintf`-like formatter.

Repository: https://github.com/xpute/xpute

## Install

```bash
pip install xpute
```

## Usage

```py
from xpute import printf, sprintf

printf("hello %s %d\n", "xpute", 123)
s = sprintf("0x%08x\n", 0x1234)
```

## Notes

Portable subset, not a full C `printf`.
