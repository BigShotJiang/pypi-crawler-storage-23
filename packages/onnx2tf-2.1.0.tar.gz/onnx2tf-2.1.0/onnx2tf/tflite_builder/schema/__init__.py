"""Bundled TFLite schema artifacts for flatbuffer_direct."""
