"""Dailybot CLI commands."""
