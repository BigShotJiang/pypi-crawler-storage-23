"""Parsing context: Robot Framework suite parsing and text representation."""
