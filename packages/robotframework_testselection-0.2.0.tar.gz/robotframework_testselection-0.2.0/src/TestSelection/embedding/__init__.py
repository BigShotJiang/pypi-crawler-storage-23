"""Embedding bounded context: vector embedding of test case text representations."""
