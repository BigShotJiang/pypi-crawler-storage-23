"""Vector-based diverse test case selection for Robot Framework."""

__version__ = "0.2.0"
