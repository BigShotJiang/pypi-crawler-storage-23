class UnitNotFoundError(Exception):
    """Raised when a unit is not found in the registry."""
