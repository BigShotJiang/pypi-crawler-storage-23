"""Catalog of default units."""

_SI_BASE_UNITS = [
    # Length
    {"symbol": "m", "formula": "L", "name": "meter"},
    # Electric current
    {"symbol": "A", "formula": "I", "name": "ampere"},
    # Luminous intensity
    {"symbol": "cd", "formula": "J", "name": "candela"},
    # Mass
    {"symbol": "kg", "formula": "M", "name": "gram", "prefix": "k"},
    # Amount of substance
    {"symbol": "mol", "formula": "N", "name": "mole"},
    # Thermodynamic temperature
    {"symbol": "K", "formula": "Th", "name": "kelvin"},
    # Time
    {"symbol": "s", "formula": "T", "name": "second"},
]

_DERIVED_UNITS = [
    # Temperature
    {"symbol": "°C", "formula": "Th", "name": "degree Celsius", "si_offset": 273.15},
    {
        "symbol": "°F",
        "formula": "Th",
        "name": "degree Fahrenheit",
        "si_factor": 5 / 9,
        "si_offset": 255.372,
    },
    # Time
    {"symbol": "min", "formula": "T", "name": "minute", "si_factor": 60},
    {"symbol": "h", "formula": "T", "name": "hour", "si_factor": 3600},
    # Plane angle
    {"symbol": "rad", "formula": "-", "name": "radian"},
    # Solid angle
    {"symbol": "sr", "formula": "-", "name": "steradian"},
    # Frequency
    {"symbol": "Hz", "formula": "T^-1", "name": "hertz"},
    # Force
    {"symbol": "N", "formula": "M.L.T^-2", "name": "newton"},
    # Pressure
    {"symbol": "Pa", "formula": "M.L^-1.T^-2", "name": "pascal"},
    # Energy
    {"symbol": "J", "formula": "M.L^2.T^-2", "name": "joule"},
    # Power
    {"symbol": "W", "formula": "M.L^2.T^-3", "name": "watt"},
    # Electric charge
    {"symbol": "C", "formula": "I.T", "name": "coulomb"},
    # Electric potential difference
    {"symbol": "V", "formula": "M.L^2.I^-1.T^-3", "name": "volt"},
    # Capacitance
    {"symbol": "F", "formula": "M^-1.L^-2.I^2.T^4", "name": "farad"},
    # Electric resistance
    {"symbol": "Ω", "formula": "M.L^2.I^-2.T^-3", "name": "ohm"},
    {"symbol": "ohm", "formula": "M.L^2.I^-2.T^-3", "name": "ohm", "alias": "Ω"},
    # Conductance
    {"symbol": "S", "formula": "M^-1.L^-2.I^2.T^3", "name": "siemens"},
    # Magnetic flux
    {"symbol": "Wb", "formula": "M.L^2.I^-1.T^-2", "name": "weber"},
    # Magnetic flux density
    {"symbol": "T", "formula": "M.I^-1.T^-2", "name": "tesla"},
    # Inductance
    {"symbol": "H", "formula": "M.L^2.I^-2.T^-2", "name": "henry"},
    # Luminous flux
    {"symbol": "lm", "formula": "J", "name": "lumen"},
    # Illuminance
    {"symbol": "lx", "formula": "J.L^-2", "name": "lux"},
    # Activity of a radionuclide
    {"symbol": "Bq", "formula": "T^-1", "name": "becquerel"},
    # Absorbed dose
    {"symbol": "Gy", "formula": "L^2.T^-2", "name": "gray"},
    # Equivalent dose
    {"symbol": "Sv", "formula": "L^2.T^-2", "name": "sievert"},
    # Catalytic activity
    {"symbol": "kat", "formula": "N.T^-1", "name": "katal"},
]

_KNOWN_UNITS = _SI_BASE_UNITS + _DERIVED_UNITS
