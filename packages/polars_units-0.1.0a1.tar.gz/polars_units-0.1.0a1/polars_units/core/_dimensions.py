from enum import Enum
from typing import Self

import regex


class BaseDimension(str, Enum):
    LENGTH = "L"
    CURRENT = "I"
    LUMINOSITY = "J"
    MASS = "M"
    AMOUNT = "N"
    TEMPERATURE = "Th"
    TIME = "T"


class Dimension:
    def __init__(self, dimension: str | dict[BaseDimension, int] | Self) -> None:
        if isinstance(dimension, str):
            self._components = self._parse_dimension_string(dimension)
        elif isinstance(dimension, Dimension):
            self._components = dimension._components
        else:
            self._components = dimension

    def _parse_dimension_string(self, dimension: str) -> dict[BaseDimension, int]:
        """Parse a dimension string into its component base dimensions and their
        exponents."""
        if dimension == "-":
            return {}

        components = {}
        _symbols = set(item.value for item in BaseDimension)

        for part in dimension.split("."):
            match = regex.fullmatch(rf"({'|'.join(_symbols)})(?:\^?(-?\d+))?", part)

            if not match:
                raise ValueError(f"Invalid dimension part: {part}")

            symbol, exponent = match.groups()
            components[BaseDimension(symbol)] = int(exponent) if exponent else 1

        return components

    def __str__(self) -> str:
        components = []
        for symbol in BaseDimension:
            exponent = self._components.get(symbol, 0)
            if exponent != 0:
                if exponent == 1:
                    components.append(f"{symbol.value}")
                else:
                    components.append(f"{symbol.value}^{exponent}")

        if components:
            return ".".join(components)

        return "-"

    def __repr__(self):
        return f"Dimension({self._components})"

    def serialize(self) -> dict[str, int]:
        """Serialize the dimension to a dictionary for storage in Polars metadata."""
        _mapping = {
            "L": "length",
            "I": "current",
            "J": "luminosity",
            "M": "mass",
            "N": "amount",
            "Th": "temperature",
            "T": "time",
        }
        return {
            _mapping[symbol.value]: exponent
            for symbol, exponent in self._components.items()
        }
