"""Extension type for physical quantities with units."""

import json
from typing import Self

import polars as pl
from polars._typing import PolarsDataType

from polars_units._config import config
from polars_units.core._units import Unit


class Quantity(pl.datatypes.BaseExtension):
    """
    Extension type for representing physical quantities with units.

    This extension type wraps Float64 values and attaches unit metadata
    to columns, enabling unit-aware operations and conversions.

    Parameters
    ----------
    unit : str
        The symbol representing the unit (e.g., "m", "kg", "m/s2").

    Examples
    --------
    >>> import polars as pl
    >>> import polars_units as pu
    >>>
    >>> # Create a series with meters
    >>> s = pl.Series("distance", [1.0, 2.0, 3.0], dtype=pu.Quantity("m"))
    >>>
    >>> # Create a DataFrame with units
    >>> df = pl.DataFrame(
    ...     {"distance": [1.0, 2.0], "time": [0.5, 1.0]},
    ...     schema={"distance": pu.Quantity("m"), "time": pu.Quantity("s")}
    ... )
    """

    def __init__(self, unit: str):
        """
        Initialize a Quantity extension type.

        Parameters
        ----------
        unit : str
            The symbol representing the unit (e.g., "m", "kg", "m/s2").
        """
        # Check that the unit is known
        self._unit = config.registry.get(unit)

        metadata = json.dumps(self._unit.serialize())

        super().__init__(
            name="polars_units.quantity", storage=pl.Float64, metadata=metadata
        )

    @property
    def unit(self) -> Unit:
        """Get the unit for this quantity type."""
        return self._unit

    def __repr__(self) -> str:
        return f"Quantity({self._unit})"

    def _string_repr(self) -> str:
        """Short string representation used in DataFrame display."""
        return f"q['{self._unit}']"

    @classmethod
    def ext_from_params(
        cls, name: str, storage: PolarsDataType, metadata: str | None
    ) -> Self:
        """
        Reconstruct a Quantity type from its parameters.

        This is called internally by Polars when deserializing the extension type.
        """
        if metadata is None:
            raise ValueError("Quantity extension type requires unit metadata")

        data = json.loads(metadata)
        return cls(data["symbol"])


pl.register_extension_type("polars_units.quantity", Quantity)
