from typing import Optional, TypedDict

from polars_units.core.registry import DefaultRegistry, Registry


class ConfigParameters(TypedDict, total=False):
    """Configuration parameters for polars-units."""

    registry: Optional[Registry] = None


class Config:
    """
    Configuration class for polars-units.

    This class holds global settings that affect the behavior of the library.
    """

    def __init__(self, parameters: Optional[ConfigParameters] = None):
        if parameters is None:
            parameters = ConfigParameters()

        self._registry = parameters.get("registry", DefaultRegistry())

    @property
    def registry(self) -> Registry:
        """Get the current unit registry."""
        return self._registry

    @registry.setter
    def registry(self, registry: Registry):
        """Set a new unit registry."""
        self._registry = registry


config = Config()
