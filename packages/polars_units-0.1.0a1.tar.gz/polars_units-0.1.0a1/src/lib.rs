use polars::datatypes::extension::register_extension_type;
use polars::prelude::*;
use pyo3::prelude::*;
use pyo3_polars::derive::polars_expr;
use serde::Deserialize;
use std::sync::{Arc, Once};

mod extension;
use extension::{ensure_quantity, Quantity, QuantityFactory};

static REGISTER: Once = Once::new();

#[pymodule]
#[pyo3(name = "_registration")]
fn _polars_units(_py: Python, _m: &Bound<'_, PyModule>) -> PyResult<()> {
    REGISTER.call_once(|| {
        let _ = register_extension_type(
            "polars_units.quantity",
            Some(Arc::new(QuantityFactory)),
        );
    });
    Ok(())
}

/// Extract the unit symbol from `polars_units.quantity` series
#[polars_expr(output_type=String)]
fn unit_symbol(inputs: &[Series]) -> PolarsResult<Series> {
    let series = &inputs[0];
    let quantity = ensure_quantity(series)?;
    
    Ok(StringChunked::full(
        series.name().clone(),
        quantity.symbol.as_str(),
        series.len(),
    )
    .into_series())
}

fn output_type_from_target(input_fields: &[Field], args: ConvertArgs) -> PolarsResult<Field> {
    Ok(Field::new(
        input_fields[0].name().clone(),
        DataType::Extension(
            ExtensionTypeInstance(Box::new(args.target)),
            Box::new(DataType::Float64),
        ),
    ))
}

#[derive(Deserialize)]
struct ConvertArgs {
    target: Quantity,
}

#[polars_expr(output_type_func_with_kwargs=output_type_from_target)]
fn unit_convert(inputs: &[Series], kwargs: ConvertArgs) -> PolarsResult<Series> {
    let series = &inputs[0];
    let from = ensure_quantity(series)?;
    let to = kwargs.target;

    convert(series, from, to)
}

// Convert a series from a unit to another of the same dimension
fn convert(series: &Series, from: Quantity, to: Quantity) -> PolarsResult<Series> {
    if from.dimension != to.dimension {
        return Err(PolarsError::ComputeError(
            format!(
                "Dimensions of both units must be the same:\n\t> left: {:?},\n\t> right: {:?}",
                from.dimension, to.dimension
            )
            .into(),
        ));
    }

    let factor = _factor(&from.components) / _factor(&to.components);
    let offset = _offset(&from.components) - _offset(&to.components);

    Ok(ExtensionChunked::from_storage(
        ExtensionTypeInstance(Box::new(to.clone())),
        (series * factor + offset).clone(),
    )
    .into_series())
}

fn _factor(components: &[extension::Component]) -> f64 {
    components.iter().fold(1.0, |factor, component| {
        factor * component.si_factor.powi(component.exponent as i32)
    })
}

fn _offset(components: &[extension::Component]) -> f64 {
    components.iter().fold(0.0, |offset, component| {
        offset + component.si_offset * component.si_factor.powi(component.exponent as i32)
    })
}

fn output_type_from_input(input_fields: &[Field]) -> PolarsResult<Field> {
    Ok(input_fields[0].clone())
}

#[polars_expr(output_type_func=output_type_from_input)]
fn unit_add(inputs: &[Series]) -> PolarsResult<Series> {
    let left = &inputs[0];
    let lq = ensure_quantity(left)?;
    let right = &inputs[1];
    let rq = ensure_quantity(right)?;

    match left.to_storage() + convert(right, rq, lq.clone())?.to_storage() {
        Ok(out) => Ok(
            ExtensionChunked::from_storage(ExtensionTypeInstance(Box::new(lq)), out).into_series(),
        ),
        Err(err) => Err(PolarsError::ComputeError(
            format!("`add` operation failed: {}", err).into(),
        )),
    }
}

#[polars_expr(output_type_func=output_type_from_input)]
fn unit_sub(inputs: &[Series]) -> PolarsResult<Series> {
    let left = &inputs[0];
    let lq = ensure_quantity(left)?;
    let right = &inputs[1];
    let rq = ensure_quantity(right)?;

    match left.to_storage() - convert(right, rq, lq.clone())?.to_storage() {
        Ok(out) => Ok(
            ExtensionChunked::from_storage(ExtensionTypeInstance(Box::new(lq)), out).into_series(),
        ),
        Err(err) => Err(PolarsError::ComputeError(
            format!("`sub` operation failed: {}", err).into(),
        )),
    }
}

#[polars_expr(output_type_func=output_type_from_input)]
fn unit_mul(inputs: &[Series]) -> PolarsResult<Series> {
    let left = &inputs[0];
    let lq = ensure_quantity(left)?;
    let right = &inputs[1];
    let rq = ensure_quantity(right)?;

    match left.to_storage() * right.to_storage() {
        Ok(out) => Ok(
            ExtensionChunked::from_storage(ExtensionTypeInstance(Box::new(lq * rq)), out).into_series(),
        ),
        Err(err) => Err(PolarsError::ComputeError(
            format!("`mul` operation failed: {}", err).into(),
        )),
    }
}