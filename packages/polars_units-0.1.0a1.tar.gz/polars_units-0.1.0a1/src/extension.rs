use polars::datatypes::extension::{ExtensionTypeFactory, ExtensionTypeImpl};
use polars::prelude::*;
use serde::{Deserialize, Serialize};
use serde_json;
use std::{any::Any, borrow::Cow, hash::*, ops::Mul};

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Component {
    pub symbol: String,
    pub exponent: i8,
    pub si_factor: f64,
    pub si_offset: f64,
}

impl Hash for Component {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.symbol.hash(state);
        self.exponent.hash(state);
        self.si_factor.to_bits().hash(state);
        self.si_offset.to_bits().hash(state);
    }
}

#[derive(Clone, Debug, Hash, Serialize, Deserialize, PartialEq)]
pub struct Dimension {
    #[serde(default)]
    pub length: i8,
    #[serde(default)]
    pub current: i8,
    #[serde(default)]
    pub luminosity: i8,
    #[serde(default)]
    pub mass: i8,
    #[serde(default)]
    pub amount: i8,
    #[serde(default)]
    pub temperature: i8,
    #[serde(default)]
    pub time: i8,
}

impl Mul for Dimension {
    type Output = Self;

    fn mul(self, rhs: Self) -> Self::Output {
        Dimension {
            length: self.length + rhs.length,
            current: self.current + rhs.current,
            luminosity: self.luminosity + rhs.luminosity,
            mass: self.mass + rhs.mass,
            amount: self.amount + rhs.amount,
            temperature: self.temperature + rhs.temperature,
            time: self.time + rhs.time,
        }
    }
}

#[derive(Clone, Debug, Hash, Serialize, Deserialize, PartialEq)]
pub struct Quantity {
    pub components: Vec<Component>,
    pub symbol: String,
    pub dimension: Dimension,
}

impl Mul for Quantity {
    type Output = Self;

    fn mul(self, rhs: Self) -> Self::Output {
        let mut components = self.components.clone();

        for r_component in rhs.components {
            if let Some(l_component) = components.iter_mut().find(|c| c.symbol == r_component.symbol) {
                l_component.exponent += r_component.exponent;
            } else {
                components.push(r_component);
            }
        }

        Quantity {
            components,
            symbol: format!("{}.{}", self.symbol, rhs.symbol),
            dimension: self.dimension * rhs.dimension,
        }
    }
}

pub struct QuantityFactory;

impl ExtensionTypeFactory for QuantityFactory {
    fn create_type_instance(
        &self,
        _name: &str,
        _storage: &DataType,
        metadata: Option<&str>,
    ) -> Box<dyn ExtensionTypeImpl> {
        let quantity: Quantity = metadata.and_then(|m| serde_json::from_str(m).ok()).unwrap();
        Box::new(quantity)
    }
}

impl ExtensionTypeImpl for Quantity {
    fn name(&self) -> Cow<'_, str> {
        Cow::Borrowed("polars_units.quantity")
    }

    fn serialize_metadata(&self) -> Option<Cow<'_, str>> {
        let metadata = serde_json::to_string(&self).ok()?;
        Some(Cow::Owned(metadata))
    }

    fn dyn_clone(&self) -> Box<dyn ExtensionTypeImpl> {
        Box::new(self.clone())
    }

    fn dyn_eq(&self, other: &dyn ExtensionTypeImpl) -> bool {
        if let Some(other) = (other as &dyn Any).downcast_ref::<Quantity>() {
            self == other
        } else {
            false
        }
    }

    fn dyn_hash(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.hash(&mut hasher);
        hasher.finish()
    }

    fn dyn_display(&self) -> std::borrow::Cow<'_, str> {
        Cow::Owned(format!("q['{}']", self.symbol))
    }

    fn dyn_debug(&self) -> std::borrow::Cow<'_, str> {
        Cow::Owned(format!("ExtensionType({:?})", self))
    }
}

// Helper function to extract `Quantity` from a series
pub fn ensure_quantity(series: &Series) -> PolarsResult<Quantity> {
    let dtype = series.ext()?.extension_type();

    if let Some(metadata) = dtype.serialize_metadata() {
        match serde_json::from_str::<Quantity>(metadata.as_ref()) {
            Ok(quantity) => Ok(quantity),
            Err(err) => Err(PolarsError::ComputeError(
                format!("Cannot parse Quantity metadata: {}", err).into(),
            )),
        }
    } else {
        Err(PolarsError::ComputeError(
            "Extension type does not have metadata".into(),
        ))
    }
}
