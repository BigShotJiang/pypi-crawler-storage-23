from ptop3.monitor import main

main()
