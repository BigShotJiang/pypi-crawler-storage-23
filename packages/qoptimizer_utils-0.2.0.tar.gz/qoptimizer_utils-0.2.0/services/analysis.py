from __future__ import annotations

from shared.connectors.base import (
    BaseQueryRecord,
    PGQueryRecord,
    SFQueryRecord,
    CHQueryRecord,
    BQQueryRecord,
)
from shared.constants.thresholds import (
    SLOW_QUERY_MS,
    HIGH_MEMORY_BYTES,
    FULL_SCAN_RATIO,
    HIGH_IO_RATIO,
    HIGH_ROW_COUNT,
    HIGH_EXECUTION_COUNT,
    BQ_HIGH_BYTES_PROCESSED,
)
from shared.constants.issues import SEVERITY_BONUS


def detect_issues(record: BaseQueryRecord, vendor: str) -> list[str]:
    """Detect performance issues based on query metrics."""
    issues = []

    # Slow query: avg > threshold
    if record.avg_time_ms > SLOW_QUERY_MS:
        issues.append("slow_query")

    # PostgreSQL-specific checks
    if isinstance(record, PGQueryRecord):
        # High IO (cache miss ratio)
        total_blocks = record.shared_blks_hit + record.shared_blks_read
        if total_blocks > 0 and record.shared_blks_read / total_blocks > HIGH_IO_RATIO:
            issues.append("high_io")

        # Temp spill
        if record.temp_blks_written > 0:
            issues.append("temp_spill")

        # Cache miss (high block read time)
        if record.blk_read_time > 0 and total_blocks > 0:
            read_ratio = record.shared_blks_read / total_blocks
            if read_ratio > HIGH_IO_RATIO:
                issues.append("cache_miss")

    # Snowflake-specific checks
    elif isinstance(record, SFQueryRecord):
        # Full scan (low partition pruning)
        if record.partitions_total > 0:
            ratio = record.partitions_scanned / record.partitions_total
            if ratio > FULL_SCAN_RATIO:
                issues.append("full_scan")

        # Spill detected
        if record.bytes_spilled_local > 0 or record.bytes_spilled_remote > 0:
            issues.append("spill_detected")

    # ClickHouse-specific checks
    elif isinstance(record, CHQueryRecord):
        # High memory usage
        if record.memory_usage > HIGH_MEMORY_BYTES:
            issues.append("high_io")

        # High write IO
        if record.written_bytes > HIGH_MEMORY_BYTES:
            issues.append("high_write_io")

    # BigQuery-specific checks
    elif isinstance(record, BQQueryRecord):
        if record.total_bytes_processed > BQ_HIGH_BYTES_PROCESSED:
            issues.append("full_scan")

    # High row count
    if record.rows_returned > HIGH_ROW_COUNT:
        issues.append("high_row_count")

    # Frequent query
    if record.execution_count > HIGH_EXECUTION_COUNT:
        issues.append("frequent_query")

    return issues


def calculate_priority_score(record: BaseQueryRecord, issues: list[str]) -> float:
    """Calculate a priority score (0-100) for optimization ranking."""
    score = 0.0

    # Time impact: total_time_ms normalized (log scale)
    import math
    if record.total_time_ms > 0:
        score += min(30, math.log10(record.total_time_ms + 1) * 5)

    # Frequency impact
    if record.execution_count > 0:
        score += min(20, math.log10(record.execution_count + 1) * 5)

    # Issue severity bonus
    for issue in issues:
        score += SEVERITY_BONUS.get(issue, 2)

    return min(100.0, round(score, 2))
