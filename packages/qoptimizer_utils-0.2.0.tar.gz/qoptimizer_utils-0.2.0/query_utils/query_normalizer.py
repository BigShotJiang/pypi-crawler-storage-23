"""Single source of truth for query normalization."""
import re


def normalize_query(sql: str) -> str:
    """Replace literals with placeholders for pattern grouping."""
    # Remove comments
    sql = re.sub(r'--.*$', '', sql, flags=re.MULTILINE)
    sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
    # Collapse whitespace
    sql = re.sub(r'\s+', ' ', sql).strip()
    # Replace string literals
    sql = re.sub(r"'[^']*'", "'?'", sql)
    # Replace numeric literals (but not table/column identifiers)
    sql = re.sub(r'\b\d+\.?\d*\b', '?', sql)
    return sql
