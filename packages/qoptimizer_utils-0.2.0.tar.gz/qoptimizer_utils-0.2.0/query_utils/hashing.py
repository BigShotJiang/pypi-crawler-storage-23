"""Single source of truth for query hash computation."""
import hashlib


def compute_hash(normalized_query: str) -> str:
    """Compute SHA-256 hash of a normalized query string."""
    return hashlib.sha256(normalized_query.encode()).hexdigest()
