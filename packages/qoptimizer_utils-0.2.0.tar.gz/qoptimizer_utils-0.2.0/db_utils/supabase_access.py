"""Supabase connection code.

Connects directly to the Supabase PostgreSQL database via psycopg2.
Used for reading user info and vendor metadata only.
Vendor DB credentials come from AWS Secrets Manager (keyed by user.id), NOT from Supabase.

Env vars (from zshrc):
    SUPABASE_API_URL  — e.g. https://xxxx.supabase.co  (used to derive DB host)
    SUPABASE_DB_PASSWORD — Supabase database password
"""

import os
import re
import logging
from contextlib import contextmanager

import psycopg2
from psycopg2.extras import RealDictCursor

logger = logging.getLogger(__name__)


def _get_db_host() -> str:
    """Derive the Supabase direct DB host from SUPABASE_API_URL.

    ``https://xxxx.supabase.co`` → ``db.xxxx.supabase.co``
    """
    api_url = os.environ.get("SUPABASE_API_URL", "")
    m = re.search(r"https?://([^.]+)\.supabase\.co", api_url)
    if m:
        return f"db.{m.group(1)}.supabase.co"
    raise ValueError(
        f"Cannot derive DB host from SUPABASE_API_URL={api_url!r}. "
        "Set SUPABASE_API_URL=https://<project>.supabase.co"
    )


def supabase_connect():
    """Get a psycopg2 connection to the Supabase PostgreSQL database.

    Returns a wrapper object with a ``.table()`` API compatible with
    the pipeline code that calls ``db.table("vendors").select(...).eq(...).execute()``.
    """
    return SupabaseClient(
        host=_get_db_host(),
        port=5432,
        dbname="postgres",
        user="postgres",
        password=os.environ.get("SUPABASE_DB_PASSWORD", ""),
    )


def get_user_int_id(user_uuid: str) -> int | None:
    """Resolve user UUID (public_id) to BIGSERIAL id (Int64).

    Flow: user UUID → public.users WHERE public_id = UUID → id (BIGSERIAL).

    Args:
        user_uuid: Supabase auth.users id (UUID string).

    Returns:
        Integer user id, or None if user not found.
    """
    client = supabase_connect()
    result = client.table("users").select("id").eq("public_id", user_uuid).limit(1).execute()
    if not result.data or len(result.data) == 0:
        return None
    row = result.data[0]
    uid = row.get("id")
    return int(uid) if uid is not None else None


# Backward compat alias
def get_user_id_from_supabase(user_uuid: str) -> int | None:
    return get_user_int_id(user_uuid)


class _QueryResult:
    """Mimics Supabase ``.execute()`` result with ``.data`` attribute."""
    def __init__(self, data: list[dict]):
        self.data = data


class _TableQuery:
    """Minimal Supabase table query builder over psycopg2."""

    def __init__(self, conn_params: dict, table_name: str):
        self._conn_params = conn_params
        self._table = table_name
        self._select_cols = "*"
        self._filters: list[tuple[str, str, str]] = []
        self._limit_val: int | None = None

    def select(self, cols: str) -> "_TableQuery":
        self._select_cols = cols
        return self

    def eq(self, col: str, val) -> "_TableQuery":
        self._filters.append((col, "=", val))
        return self

    def limit(self, n: int) -> "_TableQuery":
        self._limit_val = n
        return self

    def execute(self) -> _QueryResult:
        sql = f"SELECT {self._select_cols} FROM public.{self._table}"
        params: list = []
        if self._filters:
            clauses = []
            for col, op, val in self._filters:
                clauses.append(f"{col} {op} %s")
                params.append(val)
            sql += " WHERE " + " AND ".join(clauses)
        if self._limit_val:
            sql += f" LIMIT {self._limit_val}"

        conn = psycopg2.connect(**self._conn_params, sslmode="require")
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(sql, params)
                rows = [dict(r) for r in cur.fetchall()]
        finally:
            conn.close()

        return _QueryResult(rows)


class SupabaseClient:
    """Minimal Supabase-compatible client backed by psycopg2."""

    def __init__(self, **conn_params):
        self._conn_params = conn_params

    def table(self, name: str) -> _TableQuery:
        return _TableQuery(self._conn_params, name)


@contextmanager
def get_supabase_client(**kwargs):
    """Get Supabase client context."""
    client = supabase_connect()
    yield client


if __name__ == "__main__":
    client = supabase_connect()
    result = client.table("vendors").select("id, type, owner").execute()
    print(f"vendors: {len(result.data)} rows")
    for row in result.data:
        print(f"  id={row['id']}  type={row['type']}  owner={row['owner']}")
