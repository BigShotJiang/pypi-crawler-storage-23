"""Implements functions for logging."""

import datetime
import logging


class Logger:
    """Logger with info, skip, select, insert, update, delete, error, exception, stack_trace."""

    def __init__(self, name: str) -> None:
        self._log = logging.getLogger(name)

    def info(self, msg: str, *args) -> None:
        self._log.info(msg, *args)

    def skip(self, msg: str) -> None:
        self._log.info("skip: %s", msg)

    def select(self, msg: str) -> None:
        self._log.info("select: %s", msg)

    def insert(self, msg: str) -> None:
        self._log.info("insert: %s", msg)

    def update(self, msg: str) -> None:
        self._log.info("update: %s", msg)

    def delete(self, msg: str) -> None:
        self._log.info("delete: %s", msg)
        
    def debug(self, msg: str, *args) -> None:
        self._log.debug(msg, *args)

    def error(self, msg: str, *args) -> None:
        self._log.error(msg, *args)

    def exception(self, msg: str) -> None:
        self._log.exception(msg)

    def stack_trace(self) -> None:
        self._log.info("stack_trace", exc_info=True)



def _init_logger(name: str) -> Logger:
    """Initialize the logger.

    Parameters
    ----------
    name : str
        Name of the logger

    Returns
    -------
    Logger
        Initialized logger instance
    """
    return Logger(name)


def log_with_print(message: str) -> None:
    """Print the message with a timestamp prepended to it.

    Parameters
    ----------
    message : str
        message to log
    """
    print(f"{datetime.datetime.now(tz=datetime.timezone.utc)} {message}")


if __name__ == "__main__":
    logger = _init_logger(__file__)

    logger.info("start processing")
    logger.skip("update=False - spotify_track_id=56Kjskx12ksQss")
    logger.select("spotify_artist - tier=1 - artists_count=30")
    logger.insert("spotify_artist_insights - id=3963, timestp=2022-08-30")
    logger.update("spotify_artist_insights - id=3963, timestp=2022-08-30")
    logger.delete("spotify_artist_insights - id=3963, timestp=2022-08-30")
    logger.error("spotify_artist - tier=1 - artists_count=30")

    try:
        x = [1, 2, 3]
        print(x[5])  # This will raise an IndexError
    except IndexError:
        logger.exception("As expected, an error occurred while accessing the list.")

    logger.stack_trace()
