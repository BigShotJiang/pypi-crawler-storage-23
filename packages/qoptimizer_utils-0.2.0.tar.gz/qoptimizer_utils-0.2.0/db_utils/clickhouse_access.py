"""ClickHouseCloud connection code."""

import os
import sys

from clickhouse_driver import Client

_here = os.path.dirname(os.path.abspath(__file__))
if _here not in sys.path:
    sys.path.insert(0, _here)
from db_utils.config import get_env_var  # noqa: E402
from db_utils.logger import _init_logger  # noqa: E402

logger = _init_logger(__file__)

DEFAULT_SERVICE = "rw-standard"
SERVICES = {
    DEFAULT_SERVICE: "grkyl47mbo.us-west-2.aws.clickhouse.cloud",
    "rw-burst": "el5bpab3my.us-west-2.aws.clickhouse.cloud",
}


def get_ch_config(service: str = DEFAULT_SERVICE, **kwargs: dict) -> dict:
    """Get ClickHouse configuration.

    Parameters
    ----------
    service : str, optional
        The ClickHouse service to connect to, by default DEFAULT_SERVICE.
    **kwargs : dict
        Additional keyword arguments to override default configuration.

    Returns
    -------
    dict
        ClickHouse configuration
    """
    if service not in SERVICES:
        msg = f"Invalid service name: {service}. Available services: {list(SERVICES.keys())}"
        raise ValueError(msg)

    logger.info(f"Connecting to ClickHouse service: {service}")

    config = {
        "host": SERVICES.get(service, SERVICES[DEFAULT_SERVICE]),
        "username": get_env_var("ch_user", secret=True),
        "password": get_env_var("ch_password", secret=True),
    }
    config.update(kwargs)
    return config


def clickhouse_connect(**kwargs: dict) -> Client:
    """Get a connection to ClickHouseCloud.

    Returns
    -------
    clickhouse_driver.Client
        ClickHouse connection client
    """
    config = get_ch_config(**kwargs)

    return Client(
        host=config["host"],
        user=config["username"],
        password=config["password"],
        send_receive_timeout=3300,
        secure=True,
    )


def run_ch_sql(
    query: str,
    *,
    with_column_types: bool = False,
    return_dataframe: bool = False,
    return_dict: bool = False,
    **kwargs: dict,
) -> list | tuple:
    """Run a SQL query on ClickHouseCloud.

    Parameters
    ----------
    query : str
        The SQL query to be executed on ClickHouse.
    with_column_types : bool, optional
        If True, include column types in the results, by default False.
    return_dataframe : bool, optional
        If True, return results as a pandas DataFrame and column names, by default False.
    return_dict : bool, optional
        If True, return results as a list of dictionaries, by default False.
    **kwargs
        Additional keyword arguments to pass to the ClickHouse connection.

    Returns
    -------
    list or tuple
        list of tuples with query results

        If return_dataframe is True:
            tuple containing (DataFrame, list of column names)

    Examples
    --------
        >>> run_ch_sql('query', return_dataframe=True)
        '[ {name: 'John', age: 25}, {name: 'Jane', age: 22} ]'
    """
    con = clickhouse_connect(**kwargs)

    if return_dataframe:
        result = _run_ch_sql_as_dataframe(con, query)
    elif return_dict:
        result = _run_ch_sql_as_dict(con, query)
    else:
        result = con.execute(query, with_column_types=with_column_types)

    con.disconnect_connection()
    return result


def _run_ch_sql_as_dataframe(con: Client, query: str) -> tuple:
    """Run a SQL query on ClickHouseCloud and return results as a DataFrame.

    Parameters
    ----------
    con : clickhouse_driver.Client
        The ClickHouse connection client.
    query : str
        The SQL query to be executed on ClickHouse.

    Returns
    -------
    DataFrame, list
        A tuple containing a pandas DataFrame and a list of column names.
    """
    from pandas import DataFrame  # inline import since Pandas can be heavy

    result, columns = con.execute(query, with_column_types=True)

    column_names = [c[0] for c in columns]
    dict_result = DataFrame(result, columns=column_names).to_dict(orient="records")

    return dict_result, column_names


def _run_ch_sql_as_dict(con: Client, query: str) -> list[dict]:
    """Run a SQL query on ClickHouseCloud and return results as a list of dictionaries.

    Parameters
    ----------
    con : clickhouse_driver.Client
        The ClickHouse connection client.
    query : str
        The SQL query to be executed on ClickHouse.

    Returns
    -------
    list
        A list of dictionaries representing the query results.
    """
    from clickhouse_driver.dbapi.extras import DictCursor

    cur = DictCursor(con, connection=None)
    cur.execute(query)
    return cur.fetchall()


if __name__ == "__main__":
    con = clickhouse_connect()
    result = con.execute("select current_date();")
    print(result)
    con.disconnect_connection()

    with clickhouse_connect() as ch_con:
        result = ch_con.execute("select current_date();")
        print(result)

    print(run_ch_sql("select current_date();", return_results=True, service="rw-burst"))
