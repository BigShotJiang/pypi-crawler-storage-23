"""Neo4j connection code."""

from contextlib import contextmanager

from neo4j import GraphDatabase

from .config import get_env_var
from .logger import _init_logger

logger = _init_logger(__file__)


def user_id_to_neo4j_db(user_id: int | str) -> str:
    """Convert a user id to a Neo4j database name.

    Neo4j database names must be lowercase alphanumeric + dots.
    Format: ``user.<id>`` for int ids, ``user.<uuid_hex>`` for legacy UUID strings.

    Example: ``42`` → ``"user.42"``
    """
    if isinstance(user_id, int):
        return f"user.{user_id}"
    # Legacy UUID string support
    hex_id = str(user_id).replace("-", "").lower()
    return f"user.{hex_id}"


def ensure_user_database(driver, user_id: str) -> str:
    """Create a per-user Neo4j database if it does not exist.

    Must run against the ``system`` database.
    Returns the database name, or ``None`` if the instance does not support
    multi-database (e.g. Neo4j Aura Free/Pro).
    """
    db_name = user_id_to_neo4j_db(user_id)
    try:
        with driver.session(database="system") as session:
            session.run(f"CREATE DATABASE `{db_name}` IF NOT EXISTS")
        logger.info("ensure_user_database: created %s", db_name)
        return db_name
    except Exception as e:
        if "not supported" in str(e).lower() or "UnsupportedAdministration" in str(e):
            logger.info(
                "ensure_user_database: CREATE DATABASE not supported "
                "(Neo4j Aura?). Using default database.",
            )
            return None
        raise


def get_neo4j_config(**kwargs) -> dict:
    """Get Neo4j configuration.

    Parameters
    ----------
    kwargs
        Customizable Neo4j configuration keys:
        - uri
        - user
        - password

    Returns
    -------
    dict
        Neo4j configuration
    """
    config = {
        "uri": get_env_var("neo4j_uri"),
        "user": get_env_var("neo4j_user") or "neo4j",
        "password": get_env_var("neo4j_password", secret=True),
    }
    config.update(kwargs)
    return config


def neo4j_connect(**kwargs):
    """Get a Neo4j driver.

    Returns
    -------
    neo4j.BoltDriver
        Neo4j driver
    """
    config = get_neo4j_config(**kwargs)
    return GraphDatabase.driver(
        config["uri"],
        auth=(config["user"], config["password"]),
    )


@contextmanager
def get_neo4j_session(database: str | None = None, **kwargs):
    """Get Neo4j session context (auto-closes driver).

    Parameters
    ----------
    database : str, optional
        Target Neo4j database name. ``None`` uses the server default.

    Yields
    ------
    neo4j.Session
        Neo4j session
    """
    driver = neo4j_connect(**kwargs)
    try:
        session_kwargs = {}
        if database:
            session_kwargs["database"] = database
        with driver.session(**session_kwargs) as session:
            yield session
    finally:
        driver.close()


def run_neo4j_query(query: str, params: dict = None, database: str | None = None, **kwargs):
    """Run a Cypher query and return results.

    Parameters
    ----------
    query : str
        Cypher query
    params : dict, optional
        Query parameters
    database : str, optional
        Target Neo4j database name.
    **kwargs
        Additional keyword arguments for connection

    Returns
    -------
    list
        List of record dicts
    """
    with get_neo4j_session(database=database, **kwargs) as session:
        result = session.run(query, params or {})
        return [dict(record) for record in result]


if __name__ == "__main__":
    driver = neo4j_connect()
    with driver.session() as s:
        result = s.run("MATCH (n) RETURN labels(n)[0] AS label, count(n) AS cnt ORDER BY label")
        for rec in result:
            print(f"  {rec['label']}: {rec['cnt']}")
    driver.close()
