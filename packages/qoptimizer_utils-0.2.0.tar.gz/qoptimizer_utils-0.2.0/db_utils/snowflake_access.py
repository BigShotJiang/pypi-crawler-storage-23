"""Snowflake connector."""

from contextlib import contextmanager
from typing import Optional

import pandas as pd
from snowflake.connector import DictCursor, connect
from snowflake.snowpark import Session
from snowflake.snowpark.dataframe import DataFrame
from snowflake.snowpark.functions import when_matched, when_not_matched

from .config import get_env_var

SNOWFLAKE_DATABASE = "chartmetric"
SNOWFLAKE_WAREHOUSE = "ETL"
SNOWFLAKE_SCHEMA = "raw_data"
SNOWFLAKE_PARAMSTYLE = "pyformat"
SNOWFLAKE_ACCOUNT = "ona20116"


def get_snowflake_config(**kwargs):  # noqa: ANN003, ANN201
    """Get Snowflake configuration.

    Parameters
    ----------
    kwargs
        Customizable Snowflake configuration keys:
        - database
        - warehouse
        - schema
        - paramstyle
        - account
        - user
        - password

    Returns
    -------
    dict
        Snowflake configuration
    """
    config = {
        "database": SNOWFLAKE_DATABASE,
        "warehouse": SNOWFLAKE_WAREHOUSE,
        "schema": SNOWFLAKE_SCHEMA,
        "paramstyle": SNOWFLAKE_PARAMSTYLE,
        "account": SNOWFLAKE_ACCOUNT,
        "private_key_file": get_env_var("sf_private_key_path"),
        "private_key_password": get_env_var("sf_private_key_password"),
        "user": get_env_var("sf_user", secret=True),
        "password": get_env_var("sf_password", secret=True),
    }
    config.update(kwargs)
    return config


def snowflake_connect(**kwargs):  # noqa: ANN003, ANN201
    """Get Snowflake connection.

    Returns
    -------
    connection
        Snowflake connection
    """
    config = get_snowflake_config(**kwargs)

    use_private_key = False
    if config["private_key_file"]:
        use_private_key = True

    return connect(
        database=config["database"],
        user=config["user"],
        private_key_file=config["private_key_file"] if use_private_key else None,
        private_key_password=config["private_key_password"] if use_private_key else None,
        password=config["password"] if not use_private_key else None,
        account=config["account"],
        warehouse=config["warehouse"],
        schema=config["schema"],
        paramstyle=config["paramstyle"],
        session_parameters={"QUERY_TAG": kwargs.get("tag")},
    )


def snowflake_disconnect(con) -> None:  # noqa: ANN001
    """Disconnect Snowflake.

    Parameters
    ----------
    con : connection
        Snowflake connection
    """
    if con:
        con.close()


@contextmanager
def get_snowflake_connect(**kwargs):  # noqa: ANN003, ANN201
    """Get Snowflake connection context.

    Yields
    ------
    connection
        Snowflake connection
    """
    con = None
    exception = None
    try:
        con = snowflake_connect(**kwargs)
        if con:
            yield con
        else:
            msg = "Failed to establish a Snowflake connection."
            raise ConnectionError(msg)
    except Exception as e:
        exception = e
    finally:
        if con:
            snowflake_disconnect(con)
        if exception:
            raise exception


@contextmanager
def get_snowflake_cursor(commit=None, **kwargs):  # noqa: ANN001, ANN003, ANN201
    """Get Snowflake cursor context.

    Parameters
    ----------
    commit : boolean, optional
        whether to auto-commit at the end, by default False

    Yields
    ------
    cursor
        Snowflake cursor
    """
    with snowflake_connect(**kwargs) as con:
        cursor = con.cursor(DictCursor)
        try:
            yield cursor
            if commit:
                con.commit()
        finally:
            cursor.close()


def snowflake_connect_east(**kwargs):  # noqa: ANN003, ANN201
    """Get Snowflake connection (East).

    Returns
    -------
    connection
        Snowflake connection
    """
    config_east = {
        "database": "CHARTMETRIC_DS",
        "user": "airflow3",
        "password": get_env_var("sf_east_password"),
        "account": "chartmetric.us-east-1",
        "warehouse": "LOAD_WH",
        "schema": SNOWFLAKE_SCHEMA,
        "paramstyle": SNOWFLAKE_PARAMSTYLE,
    }
    config_east.update(kwargs)

    return connect(
        database=config_east["database"] if "database" not in kwargs else kwargs["database"],
        user=config_east["user"],
        password=config_east["password"],
        account=config_east["account"],
        warehouse=config_east["warehouse"],
        schema=config_east["schema"],
        paramstyle=config_east["paramstyle"],
    )


def get_snowpark_session(**kwargs):  # noqa: ANN003, ANN201
    """Get Snowpark session.

    Parameters
    ----------
    warehouse : str, optional
        Snowflake warehouse, by default SNOWFLAKE_CONFIGS["warehouse"]
    schema : str, optional
        Snowflake schema, by default SNOWFLAKE_CONFIGS["schema"]

    Returns
    -------
    Session
        Snowpark session
    """
    config = get_snowflake_config(**kwargs)
    return Session.builder.configs(config).create()


def run_sf_sql(query: str, return_results: Optional[bool] = None, **kwargs):  # noqa: ANN003, ANN201
    """Run a query on Snowflake and return results, if needed.

    Parameters
    ----------
    query : str
        SQL query
    return_results : bool, optional
        whether to return results, by default False
    database : str, optional
        database name, by default SNOWFLAKE_DATABASE
    warehouse : str, optional
        SF warehouse to use, by default SNOWFLAKE_WAREHOUSE

    Returns
    -------
    list
        list of records if return_results is True, else None
    """
    with get_snowflake_connect(**kwargs) as con, con.cursor() as cur:
        cur.execute(query)
        if return_results:
            return cur.fetchall()
        return None


def run_sf_sql_pandas(query: str, **kwargs: dict) -> pd.DataFrame:
    """Run a query on Snowflake and return results as a pandas DataFrame.

    Parameters
    ----------
    query : str
        SQL query
    **kwargs : dict
        Additional keyword arguments to pass to the Snowflake connection.

    Returns
    -------
    pd.DataFrame
        DataFrame with query results.
    """
    with get_snowflake_connect(**kwargs) as con, con.cursor() as cur:
        cur.execute(query)
        cols = [desc[0] for desc in cur.description]
        data = cur.fetchall()
    return pd.DataFrame(data, columns=cols)


def merge_table(
    session: Session, source_df: DataFrame, target_table: str, merge_columns: list, schema: str = "RAW_DATA"
) -> None:
    """Merge source dataframe into target table.

    Args:
        session: Snowpark session
        source_df: Source dataframe to merge
        target_table: Target table name to merge into
        merge_columns: List of columns to use as merge key
        schema: Schema name, by default "RAW_DATA"
    """
    target = session.table(f"{schema}.{target_table}")

    # Build merge condition
    merge_condition = None
    for column in merge_columns:
        condition = target[column] == source_df[column]
        merge_condition = condition if merge_condition is None else merge_condition & condition

    # Create update and insert dicts using each column
    update_dict = {col_name: source_df[col_name] for col_name in source_df.schema.names}
    insert_dict = {col_name: source_df[col_name] for col_name in source_df.schema.names}

    # Perform merge operation
    target.merge(
        source_df, merge_condition, [when_matched().update(update_dict), when_not_matched().insert(insert_dict)]
    )


if __name__ == "__main__":
    con = snowflake_connect(warehouse="COMPUTE_XS", tag="test1")
    cur = con.cursor()
    cur.execute("select current_date;")
    print(cur.fetchall())
    snowflake_disconnect(con)

    with get_snowflake_connect(tag="test2") as sf_con:
        cur = sf_con.cursor()
        cur.execute("select current_date;")
        print(cur.fetchall())

    # con = snowflake_connect_east()
    # cur = con.cursor()
    # cur.execute("select current_date;")
    # print(cur.fetchall())
    # snowflake_disconnect(con)
