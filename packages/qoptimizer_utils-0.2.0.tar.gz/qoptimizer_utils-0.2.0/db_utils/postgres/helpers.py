"""Postgres helpers."""

from collections.abc import Iterable
from typing import Optional, Union

import psycopg2
from psycopg2.extensions import UNICODE, connection
from psycopg2.extras import RealDictCursor, execute_values

from ..config import get_env_var
from ..logger import _init_logger
from .queries import QUERY_ADD_COLUMS_TO_TABLE, QUERY_ADD_TRIGGER_FUNCTION
from .types import Column, CreateTableWithSeqOption

psycopg2.extensions.register_type(UNICODE)

BATCH_SIZE = 10**4
MAX_CLIENTS = 50


logger = _init_logger(__file__)


class _DB_USERNAMES:
    """Internal DB usernames that use a fixed password (e.g. for RDS IAM)."""

    _internal_usernames: frozenset[str] = frozenset()


def disconnect(con: connection) -> None:
    """Disconnect Postgres.

    Parameters
    ----------
    con : psycopg2.extensions.connection
        Postgres connection
    """
    if con:
        con.close()


def insert_data(con: connection, data: list[dict], query: str, columns: list[str], page_size: int = BATCH_SIZE) -> None:
    """Insert data into the database using the specified query and columns.

    This function will dynamically generate VALUES pages based on
    the columns and page_size, then execute one page at a time.

    The query should contain a single %s for the VALUES page.

    The columns array is used to place dict values into the correct order,
    so it's highly recommended to use the same columns list directly in the
    query (see example) to ensure alignment.

    Examples
    --------
    >>> with get_db_connection() as con:
    ...     data = [
    ...         {"id": 1, "name": "Alice"},
    ...         {"id": 2, "name": "Bob"},
    ...     ]
    ...     columns = ["id", "name"]
    ...     query = "INSERT INTO users ({', '.join(columns)}) VALUES %s"
    ...     insert_data(con, data, query, columns)

    Parameters
    ----------
    con : psycopg2.extensions.connection
        Postgres connection
    data : list
        List of row dictionaries
    query : str
        Query to execute
    columns : list
        List of columns to use from the data
    page_size : int
        Number of rows to insert at once, default is 10,000
    """
    assert all(col in data[0] for col in columns)

    formatted_columns = [f"%({column})s" for column in columns]
    template = f"({', '.join(formatted_columns)})"
    execute_values(con.cursor(), query, data, template, page_size)
    con.commit()


def get_batches(
    con: connection,
    query: str,
    params: Union[tuple, None] = None,
    batch_size: int = 1000,
) -> Iterable[list[dict]]:
    """Get batches of rows from the database.

    By using fetchmany, at most batch_size rows are kept in Airflow memory
    at once. The entire result set is stored in memory on Postgres while we
    iterate over it.

    Parameters
    ----------
    con : psycopg2.extensions.connection
        Postgres connection
    query : str
        Query to execute
    params : dict
        Query parameters
    batch_size : int
        Number of rows to fetch at once
    """
    cur = con.cursor(cursor_factory=RealDictCursor)
    cur.execute(query, params)
    try:
        while True:
            rows = cur.fetchmany(batch_size)
            if not rows:
                break
            yield list(map(dict, rows))
    finally:
        cur.close()


def get_password(username: str, password: str) -> str:
    """Get appropriate password for username.

    Parameters
    ----------
    username : str
        Username
    password : str
        Password

    Returns
    -------
    str
        Password
    """
    DB_USERNAMES = _DB_USERNAMES()
    if username in DB_USERNAMES._internal_usernames:
        return "8AqS77SaRRMMzbzaBc3G"
    return password


def get_config(writer: Optional[bool] = None, **kwargs: dict) -> dict:
    """Get DB configuration.

    Parameters
    ----------
    writer : bool, optional
        get config for writer node, by default False
    kwargs
        Customizable RDS writer configuration keys:
        - database
        - user
        - password
        - host
        - port

    Returns
    -------
    dict
        RDS writer configuration
    """
    prefix = kwargs.get("prefix", "psql")
    host = f"{prefix}_writer_host" if writer else f"{prefix}_reader_host"
    config = {
        "database": kwargs.get("database", "chartmetric"),
        "user": kwargs.get("user", get_env_var(f"{prefix}_user", secret=True)),
        "host": kwargs.get("host", get_env_var(host)),
        "port": kwargs.get("port", 5432),
    }

    assert config["user"], f"Environment variable `{prefix}_user` must be set."

    password = kwargs.get("password", get_env_var(f"{prefix}_password", secret=True))
    config["password"] = get_password(config["user"], password)

    assert config["password"], f"Environment variable `{prefix}_password` must be set."

    return config


def create_table(
    con: connection,
    schema: str,
    table_name: str,
    columns: list[Column],
    with_seq_id: Optional[CreateTableWithSeqOption] = CreateTableWithSeqOption.WITH_SEQ_ID,
) -> None:
    """Create table in the RDS if it doesn't exist.

    Parameters
    ----------
    con : psycopg2.extensions.connection
        Postgres connection
    schema : str
        Schema name
    table_name : str
        Table name
    columns : List[Column]
        List of columns. Use TEXT as default type if col_type is not specified.
    """
    with con.cursor() as cur:
        query = f"""
        CREATE TABLE IF NOT EXISTS {schema}.{table_name} (
            {"id SERIAL PRIMARY KEY," if with_seq_id else ""}
            {", ".join([f"{col['col_name']} {col['col_type'] if col['col_type'] else 'TEXT'} {col['constraint'] if col.get('constraint') else ''}" for col in columns])}
        )
        """

        cur.execute(query)
        con.commit()


def add_column(
    con: connection, table_reference: str, column: str, type_: str, constraint: Optional[str] = None
) -> None:
    """Add a column to the table with optional constraint.

    Parameters
    ----------
    con : psycopg2.extensions.connection
        Postgres connection
    table_reference : str
        Table reference
    column : str
        Column name
    type_ : str
        Column type
    constraint : str, optional
        Column constraint, by default None

    """
    with con.cursor() as cur:
        query = f"ALTER TABLE {table_reference} ADD COLUMN IF NOT EXISTS {column} {type_}"
        if constraint:
            query += f" {constraint}"
        cur.execute(query)


def update_row(
    con: connection,
    table_reference: str,
    condition_column: str,
    condition_value: str,
    column: str,
    value: str,
) -> None:
    """Update a row in the table.

    Parameters
    ----------
    con : psycopg2.extensions.connection
        Postgres connection
    table_reference : str
        Table reference
    condition_column : str
        Condition column name
    condition_value : str
        Condition column value
    column : str
        Column to update
    value : str
        New value for the column
    """
    with con.cursor() as cur:
        query = f"UPDATE {table_reference} SET {column} = %(value)s WHERE {condition_column} = %(condition_value)s"
        cur.execute(query, {"value": value, "condition_value": condition_value})
        con.commit()


def add_timestamp_columns(con: connection, schema: str, table_name: str) -> None:
    """
    Add created_at and modified_at timestamp columns to an existing table and create update trigger.

    Parameters
    ----------
    con: con
        Database con object
    schema : str
        The name of the schema containing the table
    table_name : str
        The name of the table to add timestamp columns to

    Raises
    ------
    ValueError
        If there's an error adding the timestamp columns or creating the trigger
    """
    try:
        with con.cursor() as cur:
            modified_trigger = "update_%s_modified_time"
            cur.execute(QUERY_ADD_COLUMS_TO_TABLE.format(schema=schema, tableName=table_name))
            con.commit()
            logger.info(f"Added created_at and modified_at column to {table_name}")

            modified_trigger = modified_trigger % table_name
            cur.execute(
                QUERY_ADD_TRIGGER_FUNCTION.format(
                    modifiedTriggerName=modified_trigger, schema=schema, tableName=table_name
                )
            )
            con.commit()
            logger.info(f"Added trigger function to {table_name}")

            logger.info("Done.")

    except Exception as e:
        con.rollback()
        raise e
