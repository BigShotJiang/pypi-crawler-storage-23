"""Postgres connection code."""

from collections.abc import Generator
from contextlib import contextmanager
from typing import Any, Optional

import psycopg2
from psycopg2 import connect as _connect
from psycopg2.extensions import UNICODE, connection
from psycopg2.extras import RealDictCursor
from psycopg2.pool import ThreadedConnectionPool

from .helpers import MAX_CLIENTS, get_config

psycopg2.extensions.register_type(UNICODE)


def db_connect(**kwargs: dict) -> connection:
    """Connect Postgres (Reader).

    Parameters
    ----------
    user : str, optional
        Postgres user, by default DB_USER

    Returns
    -------
    psycopg2.extensions.connection
        Postgres connection
    """
    config = get_config(**kwargs)
    return _connect(
        database=config["database"],
        user=config["user"],
        password=config["password"],
        host=config["host"],
        port=config["port"],
    )


@contextmanager
def get_connection(**kwargs: dict) -> Generator[connection, None, None]:
    """Get Postgres connection (Reader).

    Parameters
    ----------
    user : str, optional
        Postgres user, by default DB_USER

    Yields
    ------
    psycopg2.extensions.connection
        Postgres connection
    """
    config = get_config(**kwargs)
    pool = ThreadedConnectionPool(
        1,
        MAX_CLIENTS,
        database=config["database"],
        user=config["user"],
        password=config["password"],
        host=config["host"],
        port=config["port"],
    )
    try:
        conn = pool.getconn()
        yield conn
    finally:
        pool.putconn(conn, close=True)


@contextmanager
def get_cursor(commit: Optional[bool] = None, **kwargs: dict) -> Generator[RealDictCursor, None, None]:
    """Get Postgres cursor (Reader).

    Parameters
    ----------
    commit : boolean, optional
        whether to auto-commit at the end, by default False

    Yields
    ------
    psycopg2.extras.RealDictCursor
        Postgres cursor
    """
    with get_connection(**kwargs) as conn:
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        try:
            yield cursor
            if commit:
                conn.commit()
        finally:
            cursor.close()


def run_pg_sql(
    query: str, *, writer: bool = False, return_results: bool = False, **kwargs: dict
) -> Optional[list[dict[str, Any]]]:
    """Get data from the database for the specified query.

    Parameters
    ----------
    query : str
        Query
    user : str, optional
        Postgres user, by default DB_USER
    writer : bool, optional
        whether to connect to the writer node, by default False
    return_results : bool, optional
        whether to return the query results, by default False

    Returns
    -------
    list
        list of {column: value} dicts
    """
    with get_connection(writer=writer, **kwargs) as con, con.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute(query)
        if writer:
            con.commit()
        if return_results:
            return cur.fetchall()
        return None


if __name__ == "__main__":
    con = db_connect()
    cur = con.cursor()
    cur.execute("select current_date;")
    print(cur.fetchall())
    con.close()

    with get_connection() as pg_con:
        cur = pg_con.cursor()
        cur.execute("select current_date;")
        print(cur.fetchall())

    print(run_pg_sql("select current_date;", return_results=True))
