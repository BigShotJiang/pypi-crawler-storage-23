"""Postgres writer."""

from collections.abc import Generator
from contextlib import contextmanager

from psycopg2.extensions import connection
from psycopg2.extras import RealDictCursor

from .connect import db_connect as base_db_connect
from .connect import get_connection as base_get_connection
from .connect import get_cursor as base_get_cursor


def db_connect(**kwargs: dict) -> connection:
    """Connect Postgres (Writer).

    Parameters
    ----------
    user : str, optional
        Postgres user, by default DB_USER

    Returns
    -------
    psycopg2.extensions.connection
        Postgres connection
    """
    return base_db_connect(writer=True, **kwargs)


@contextmanager
def get_db_connection(**kwargs: dict) -> Generator[connection, None, None]:
    """Get Postgres connection (Writer).

    Parameters
    ----------
    user : str, optional
        Postgres user, by default DB_USER

    Yields
    ------
    psycopg2.extensions.connection
        Postgres connection
    """
    with base_get_connection(writer=True, **kwargs) as conn:
        yield conn


@contextmanager
def get_db_cursor(**kwargs: dict) -> Generator[RealDictCursor, None, None]:
    """Get Postgres cursor (Writer).

    Parameters
    ----------
    commit : boolean, optional
        whether to auto-commit at the end, by default False

    Yields
    ------
    psycopg2.extras.RealDictCursor
        Postgres cursor
    """
    with base_get_cursor(writer=True, **kwargs) as cursor:
        yield cursor


if __name__ == "__main__":
    con = db_connect()
    cur = con.cursor()
    cur.execute("select current_date;")
    print(cur.fetchall())
    con.close()

    with get_db_connection() as pg_con:
        cur = pg_con.cursor()
        cur.execute("select current_date;")
        print(cur.fetchall())
