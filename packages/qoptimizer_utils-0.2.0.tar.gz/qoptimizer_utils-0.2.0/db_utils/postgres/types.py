"""Types definition for postgres module."""

from enum import Enum

from typing_extensions import TypedDict


class Column(TypedDict):
    """Column type definition."""

    col_name: str
    col_type: str
    constraint: str


class CreateTableWithSeqOption(Enum):
    """Create Table Option."""

    WITH_SEQ_ID = True
    WITHOUT_SEQ_ID = False
