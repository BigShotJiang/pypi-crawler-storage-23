"""Queries used in the postgres helper functions."""

QUERY_ADD_COLUMS_TO_TABLE = """
  BEGIN;
  ALTER TABLE {schema}.{tableName} ADD COLUMN created_at timestamp;
  ALTER TABLE {schema}.{tableName} ALTER COLUMN created_at SET DEFAULT now();
  ALTER TABLE {schema}.{tableName} ADD COLUMN modified_at timestamp;
  ALTER TABLE {schema}.{tableName} ALTER COLUMN modified_at SET DEFAULT now();
  COMMIT;
"""

QUERY_ADD_TRIGGER_FUNCTION = """
  BEGIN;
  CREATE TRIGGER {modifiedTriggerName} BEFORE UPDATE ON {schema}.{tableName} FOR EACH ROW EXECUTE PROCEDURE update_modified_column();
  COMMIT;
"""
