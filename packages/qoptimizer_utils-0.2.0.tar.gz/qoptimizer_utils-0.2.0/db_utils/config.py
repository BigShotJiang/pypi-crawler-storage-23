"""Configuration."""

import json
import os
from typing import Optional
from .logger import _init_logger

logger = _init_logger(__file__)

# Vendor-related env keys: always from AWS Secrets Manager (SecretId = user_id or AWS_VENDOR_SECRET_ID).


def _is_vendor_key(env_var: str) -> bool:
    if env_var.startswith("PSQL_") or env_var.startswith("SF_") or env_var.startswith("BQ_"):
        return True
    if env_var in ("CH_HOST", "CH_USERNAME", "CH_PASSWORD", "CH_USER"):
        return True
    if env_var.startswith("CH_") and not env_var.startswith("CH_ANALYTICS_"):
        return True
    return False


def _get_secret_from_aws(secret_id: str) -> dict:
    """Fetch secret JSON from AWS Secrets Manager."""
    import boto3
    from botocore.exceptions import ClientError
    region = os.environ.get("AWS_REGION", "us-east-1")
    client = boto3.client("secretsmanager", region_name=region)
    try:
        resp = client.get_secret_value(SecretId=secret_id)
        raw = resp.get("SecretString") or "{}"
        return json.loads(raw)
    except ClientError as e:
        logger.debug("AWS SM get_secret_value %s: %s", secret_id, e)
        return {}
    except json.JSONDecodeError:
        return {}


def get_chartmetric_data_script_path() -> str:
    """Get local directory path for chartmetric_data_script.

    Returns
    -------
    str
        local directory path
    """
    return os.environ.get("CHARTMETRIC_DATA_SCRIPT_PATH", "/home/ec2-user/chartmetric_data_script")


def get_env_var(name: str, secret: Optional[bool] = None, user_id: Optional[str] = None) -> Optional[str]:
    """Get value from AWS Secrets Manager (vendor keys) or environment.

    Vendor-related keys (PSQL_*, SF_*, CH_* except CH_ANALYTICS_*, BQ_*):
      - Fetched from AWS SM. SecretId = user_id or env AWS_VENDOR_SECRET_ID.
    Other keys:
      - From os.environ only.

    Parameters
    ----------
    name : str
        variable name (e.g. psql_user, ch_password)
    secret : bool, optional
        unused; kept for API compatibility
    user_id : str, optional
        user UUID for per-user secret; if None, uses AWS_VENDOR_SECRET_ID (system secret)

    Returns
    -------
    str or None
        value if found, else None
    """
    assert name, "name cannot be empty."
    env_var = name.upper()

    if _is_vendor_key(env_var):
        secret_id = user_id or os.environ.get("AWS_VENDOR_SECRET_ID")
        if secret_id:
            secrets = _get_secret_from_aws(secret_id)
            if secrets:
                val = secrets.get(env_var) or (secrets.get("CH_USERNAME") if env_var == "CH_USER" else None)
                if val is not None and str(val).strip():
                    logger.debug("Using %s from AWS SM (secret_id=%s)", env_var, secret_id)
                    return str(val).strip()

    if value := os.environ.get(env_var):
        logger.info("Found %s in environment variables.", env_var)
        return value

    logger.error("Could not find %s in AWS SM or environment.", name)
    return None


if __name__ == "__main__":
    # test with python3 -m 'src.db_utils.config'
    assert get_env_var("psql_writer_host") == "prod2.cluster-cni52ceaa2ty.us-west-2.rds.amazonaws.com"
    assert get_env_var("chartmetric_api_username") == "data-eng@chartmetric.com"
