from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime

from shared.utils.query_normalizer import normalize_query
from shared.utils.hashing import compute_hash


@dataclass
class ConnectionParams:
    host: str | None = None
    port: int | None = None
    database: str | None = None
    schema_name: str | None = None
    warehouse: str | None = None
    project_id: str | None = None
    region: str | None = None
    credentials: dict | None = None  # decrypted credentials


@dataclass
class BaseQueryRecord:
    """Common fields shared by all vendor query records."""
    normalized_query: str = ""
    sample_query: str = ""
    query_hash: str = ""
    execution_count: int = 0
    total_time_ms: float = 0.0
    avg_time_ms: float = 0.0
    max_time_ms: float = 0.0
    rows_returned: int = 0
    snapshot_start_at: datetime | None = None
    snapshot_end_at: datetime | None = None


@dataclass
class PGQueryRecord(BaseQueryRecord):
    """PostgreSQL-specific query record (pg_stat_statements)."""
    queryid: int = 0
    min_exec_time: float = 0.0
    mean_exec_time: float = 0.0
    shared_blks_hit: int = 0
    shared_blks_read: int = 0
    shared_blks_written: int = 0
    local_blks_hit: int = 0
    local_blks_read: int = 0
    temp_blks_read: int = 0
    temp_blks_written: int = 0
    blk_read_time: float = 0.0
    blk_write_time: float = 0.0
    stats_since: datetime | None = None


@dataclass
class SFQueryRecord(BaseQueryRecord):
    """Snowflake-specific query record (QUERY_HISTORY)."""
    warehouse_name: str = ""
    warehouse_size: str = ""
    bytes_scanned: int = 0
    partitions_scanned: int = 0
    partitions_total: int = 0
    bytes_written: int = 0
    bytes_spilled_local: int = 0
    bytes_spilled_remote: int = 0
    compilation_time: float = 0.0
    queued_overload_time: float = 0.0
    credits_used_compute: float = 0.0
    credits_used_cloud: float = 0.0
    error_count: int = 0


@dataclass
class CHQueryRecord(BaseQueryRecord):
    """ClickHouse-specific query record (system.query_log)."""
    read_rows: int = 0
    read_bytes: int = 0
    written_rows: int = 0
    written_bytes: int = 0
    result_bytes: int = 0
    memory_usage: int = 0
    databases: list[str] = field(default_factory=list)
    tables: list[str] = field(default_factory=list)
    columns: list[str] = field(default_factory=list)


@dataclass
class BQQueryRecord(BaseQueryRecord):
    """BigQuery-specific query record (INFORMATION_SCHEMA.JOBS)."""
    total_bytes_processed: int = 0
    total_bytes_billed: int = 0
    slot_ms: int = 0


# ── Infrastructure / Instance-level records ───────────────────────────────────


@dataclass
class SFWarehouseMeteringRecord:
    """Snowflake WAREHOUSE_METERING_HISTORY row."""
    warehouse_name: str = ""
    start_time: datetime | None = None
    end_time: datetime | None = None
    credits_used: float = 0.0
    credits_used_compute: float = 0.0
    credits_used_cloud_services: float = 0.0


@dataclass
class SFWarehouseLoadRecord:
    """Snowflake WAREHOUSE_LOAD_HISTORY row."""
    warehouse_name: str = ""
    start_time: datetime | None = None
    avg_running: float = 0.0
    avg_queued_load: float = 0.0
    avg_blocked: float = 0.0


@dataclass
class PGDatabaseStatsRecord:
    """PostgreSQL pg_stat_database row."""
    datname: str = ""
    numbackends: int = 0
    xact_commit: int = 0
    xact_rollback: int = 0
    blks_read: int = 0
    blks_hit: int = 0
    tup_returned: int = 0
    tup_inserted: int = 0
    tup_updated: int = 0
    tup_deleted: int = 0


@dataclass
class PGTableStatsRecord:
    """PostgreSQL pg_stat_user_tables row."""
    schemaname: str = ""
    relname: str = ""
    seq_scan: int = 0
    seq_tup_read: int = 0
    idx_scan: int = 0
    idx_tup_fetch: int = 0
    n_tup_ins: int = 0
    n_tup_upd: int = 0
    n_tup_del: int = 0
    n_live_tup: int = 0
    n_dead_tup: int = 0
    last_vacuum: datetime | None = None
    last_analyze: datetime | None = None


@dataclass
class PGTableIOStatsRecord:
    """PostgreSQL pg_statio_user_tables row."""
    schemaname: str = ""
    relname: str = ""
    heap_blks_read: int = 0
    heap_blks_hit: int = 0
    idx_blks_read: int = 0
    idx_blks_hit: int = 0
    toast_blks_read: int = 0
    toast_blks_hit: int = 0
    tidx_blks_read: int = 0
    tidx_blks_hit: int = 0


@dataclass
class CHQueryThreadRecord:
    """ClickHouse system.query_thread_log row (aggregated per query)."""
    query_hash: str = ""
    thread_count: int = 0
    peak_memory_usage: int = 0
    read_rows: int = 0
    read_bytes: int = 0
    snapshot_start_at: datetime | None = None
    snapshot_end_at: datetime | None = None


@dataclass
class CHQueryViewRecord:
    """ClickHouse system.query_views_log row (materialized view tracking)."""
    view_name: str = ""
    query_count: int = 0
    read_rows: int = 0
    read_bytes: int = 0
    snapshot_start_at: datetime | None = None
    snapshot_end_at: datetime | None = None


@dataclass
class CHSystemMetricRecord:
    """ClickHouse system.metrics row (point-in-time value)."""
    metric: str = ""
    value: int = 0
    description: str = ""


@dataclass
class CHSystemEventRecord:
    """ClickHouse system.events row (cumulative counter)."""
    event: str = ""
    value: int = 0
    description: str = ""


@dataclass
class CHTablePartsRecord:
    """ClickHouse system.parts aggregated per table."""
    database: str = ""
    table: str = ""
    engine: str = ""
    partition_key: str = ""
    sorting_key: str = ""
    part_count: int = 0
    total_rows: int = 0
    bytes_on_disk: int = 0
    data_compressed_bytes: int = 0
    data_uncompressed_bytes: int = 0
    pk_bytes_in_memory: int = 0


@dataclass
class CHDiskRecord:
    """ClickHouse system.disks row."""
    name: str = ""
    path: str = ""
    free_space: int = 0
    total_space: int = 0
    disk_type: str = ""


@dataclass
class CHReplicaRecord:
    """ClickHouse system.replicas row."""
    database: str = ""
    table: str = ""
    is_leader: bool = False
    is_readonly: bool = False
    queue_size: int = 0
    inserts_in_queue: int = 0
    merges_in_queue: int = 0
    total_replicas: int = 0
    active_replicas: int = 0


# Backward-compatible alias (deprecated)
RawQueryRecord = BaseQueryRecord


class BaseConnector(ABC):
    def __init__(self, params: ConnectionParams):
        self.params = params

    @abstractmethod
    async def test_connection(self) -> bool:
        """Test connectivity. Returns True or raises."""
        ...

    @abstractmethod
    async def fetch_query_history(self, lookback_hours: int = 24) -> list[BaseQueryRecord]:
        """Fetch query history from the DB monitoring view."""
        ...

    @abstractmethod
    async def explain_query(self, query: str) -> dict:
        """Run EXPLAIN on query and return execution plan as structured dict."""
        ...

    @abstractmethod
    async def dry_run_query(self, query: str) -> dict:
        """Validate query can execute without actually running it.

        Returns {"success": bool, "error": str | None, "plan_summary": dict | None}.
        """
        ...

    @abstractmethod
    async def sample_query(self, query: str, limit: int = 100) -> dict:
        """Execute query with LIMIT and return sample results for comparison.

        Returns {"success": bool, "columns": list[str], "rows": list[list],
                 "row_count": int, "error": str | None}.
        """
        ...

    @staticmethod
    def normalize_query(sql: str) -> str:
        """Replace literals with placeholders for pattern grouping."""
        return normalize_query(sql)

    @staticmethod
    def compute_hash(normalized_query: str) -> str:
        return compute_hash(normalized_query)
