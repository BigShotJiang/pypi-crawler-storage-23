from __future__ import annotations

import asyncio
from datetime import datetime, timezone, timedelta
from functools import partial
from typing import Any

import snowflake.connector
import structlog
from snowflake.connector import DictCursor

from shared.connectors.base import (
    BaseConnector, ConnectionParams, SFQueryRecord,
    SFWarehouseMeteringRecord, SFWarehouseLoadRecord,
)
from shared.queries.snowflake import (
    fetch_query_history as build_sf_query,
    fetch_warehouse_metering as build_sf_metering_query,
    fetch_warehouse_load as build_sf_load_query,
)

logger = structlog.get_logger(__name__)


class SnowflakeConnector(BaseConnector):
    def __init__(self, params: ConnectionParams):
        super().__init__(params)

    def _make_connection(self) -> snowflake.connector.SnowflakeConnection:
        credentials = self.params.credentials or {}
        private_key_path = credentials.get("private_key_path")
        password = credentials.get("password")

        connect_kwargs: dict[str, Any] = {
            "user": credentials.get("username"),
            "account": self.params.host,
            "warehouse": self.params.warehouse,
            "database": self.params.database,
        }

        if private_key_path:
            connect_kwargs["private_key_file"] = private_key_path
        if password:
            connect_kwargs["password"] = password

        return snowflake.connector.connect(**connect_kwargs)

    async def test_connection(self) -> bool:
        """Test connectivity by connecting and running SELECT CURRENT_VERSION()."""
        loop = asyncio.get_event_loop()
        try:
            def _test() -> str:
                conn = self._make_connection()
                try:
                    cur = conn.cursor()
                    cur.execute("SELECT CURRENT_VERSION()")
                    return cur.fetchone()[0]
                finally:
                    conn.close()

            await loop.run_in_executor(None, _test)
            return True
        except snowflake.connector.errors.Error as exc:
            raise ConnectionError(f"Snowflake connection failed: {exc}") from exc

    async def fetch_query_history(self, lookback_hours: int = 24) -> list[SFQueryRecord]:
        """
        Fetch query history from SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY,
        grouped by QUERY_PARAMETERIZED_HASH for the last lookback_hours.
        """
        query = build_sf_query(lookback_hours)

        loop = asyncio.get_event_loop()
        try:
            def _fetch() -> list[dict]:
                conn = self._make_connection()
                try:
                    cur = conn.cursor(DictCursor)
                    cur.execute(query)
                    return cur.fetchall()
                finally:
                    conn.close()

            rows: list[dict] = await loop.run_in_executor(None, _fetch)
        except snowflake.connector.errors.Error as exc:
            raise RuntimeError(f"Snowflake fetch_query_history failed: {exc}") from exc

        records: list[SFQueryRecord] = []
        for row in rows:
            sample_query: str = row.get("SAMPLE_QUERY") or ""
            normalized = self.normalize_query(sample_query)
            query_hash = self.compute_hash(normalized)

            record = SFQueryRecord(
                normalized_query=normalized,
                sample_query=sample_query,
                query_hash=query_hash,
                execution_count=int(row.get("EXECUTION_COUNT") or 0),
                total_time_ms=float(row.get("TOTAL_EXECUTION_TIME_MS") or 0.0),
                avg_time_ms=float(row.get("AVG_EXECUTION_TIME_MS") or 0.0),
                max_time_ms=float(row.get("MAX_EXECUTION_TIME_MS") or 0.0),
                rows_returned=int(row.get("ROWS_PRODUCED") or 0),
                bytes_scanned=int(row.get("BYTES_SCANNED") or 0),
                partitions_scanned=int(row.get("PARTITIONS_SCANNED") or 0),
                partitions_total=int(row.get("PARTITIONS_TOTAL") or 0),
                warehouse_name=row.get("WAREHOUSE_NAME") or "",
                warehouse_size=row.get("WAREHOUSE_SIZE") or "",
                bytes_written=int(row.get("BYTES_WRITTEN") or 0),
                bytes_spilled_local=int(row.get("BYTES_SPILLED_LOCAL") or 0),
                bytes_spilled_remote=int(row.get("BYTES_SPILLED_REMOTE") or 0),
                compilation_time=float(row.get("COMPILATION_TIME") or 0.0),
                queued_overload_time=float(row.get("QUEUED_OVERLOAD_TIME") or 0.0),
                credits_used_compute=float(row.get("CREDITS_USED_COMPUTE") or 0.0),
                credits_used_cloud=float(row.get("CREDITS_USED_CLOUD") or 0.0),
                error_count=int(row.get("ERROR_COUNT") or 0),
                snapshot_start_at=row.get("SNAPSHOT_START_AT"),
                snapshot_end_at=row.get("SNAPSHOT_END_AT"),
            )
            records.append(record)

        return records

    async def fetch_warehouse_metering(
        self, lookback_hours: int = 24,
    ) -> list[SFWarehouseMeteringRecord]:
        """Fetch warehouse credit usage from WAREHOUSE_METERING_HISTORY."""
        query = build_sf_metering_query(lookback_hours)
        loop = asyncio.get_event_loop()

        def _fetch() -> list[dict]:
            conn = self._make_connection()
            try:
                cur = conn.cursor(DictCursor)
                cur.execute(query)
                return cur.fetchall()
            finally:
                conn.close()

        rows: list[dict] = await loop.run_in_executor(None, _fetch)
        records: list[SFWarehouseMeteringRecord] = []
        for row in rows:
            records.append(SFWarehouseMeteringRecord(
                warehouse_name=row.get("WAREHOUSE_NAME") or "",
                start_time=row.get("START_TIME"),
                end_time=row.get("END_TIME"),
                credits_used=float(row.get("CREDITS_USED") or 0.0),
                credits_used_compute=float(row.get("CREDITS_USED_COMPUTE") or 0.0),
                credits_used_cloud_services=float(
                    row.get("CREDITS_USED_CLOUD_SERVICES") or 0.0
                ),
            ))
        return records

    async def fetch_warehouse_load(
        self, lookback_hours: int = 24,
    ) -> list[SFWarehouseLoadRecord]:
        """Fetch warehouse load/concurrency from WAREHOUSE_LOAD_HISTORY."""
        query = build_sf_load_query(lookback_hours)
        loop = asyncio.get_event_loop()

        def _fetch() -> list[dict]:
            conn = self._make_connection()
            try:
                cur = conn.cursor(DictCursor)
                cur.execute(query)
                return cur.fetchall()
            finally:
                conn.close()

        rows: list[dict] = await loop.run_in_executor(None, _fetch)
        records: list[SFWarehouseLoadRecord] = []
        for row in rows:
            records.append(SFWarehouseLoadRecord(
                warehouse_name=row.get("WAREHOUSE_NAME") or "",
                start_time=row.get("START_TIME"),
                avg_running=float(row.get("AVG_RUNNING") or 0.0),
                avg_queued_load=float(row.get("AVG_QUEUED_LOAD") or 0.0),
                avg_blocked=float(row.get("AVG_BLOCKED") or 0.0),
            ))
        return records

    async def explain_query(self, query: str) -> dict:
        """Run EXPLAIN on a query and return the tabular plan as structured data."""
        loop = asyncio.get_event_loop()
        try:
            def _explain() -> list[dict]:
                conn = self._make_connection()
                try:
                    cur = conn.cursor(DictCursor)
                    cur.execute(f"EXPLAIN {query}")
                    return cur.fetchall()
                finally:
                    conn.close()

            rows: list[dict] = await loop.run_in_executor(None, _explain)

            # Build a summary from the EXPLAIN rows.
            operations = [r.get("operation", "") for r in rows]
            return {
                "plan": rows,
                "operations": operations,
                "step_count": len(rows),
            }
        except Exception as exc:
            logger.error("snowflake.explain_query.failed", error=str(exc))
            return {
                "plan": None,
                "operations": [],
                "step_count": 0,
                "error": str(exc),
            }

    async def dry_run_query(self, query: str) -> dict:
        """Validate a query by running EXPLAIN (parse only, no execution)."""
        loop = asyncio.get_event_loop()
        try:
            def _dry_run() -> list[dict]:
                conn = self._make_connection()
                try:
                    cur = conn.cursor(DictCursor)
                    cur.execute(f"EXPLAIN {query}")
                    return cur.fetchall()
                finally:
                    conn.close()

            rows = await loop.run_in_executor(None, _dry_run)
            return {
                "success": True,
                "error": None,
                "plan_summary": {"step_count": len(rows)},
            }
        except Exception as exc:
            logger.error("snowflake.dry_run_query.failed", error=str(exc))
            return {"success": False, "error": str(exc), "plan_summary": None}

    async def sample_query(self, query: str, limit: int = 100) -> dict:
        """Execute the query with a LIMIT and return sample results."""
        loop = asyncio.get_event_loop()
        try:
            def _sample() -> tuple[list[str], list[list]]:
                conn = self._make_connection()
                try:
                    cur = conn.cursor()
                    cur.execute(f"SELECT * FROM ({query}) LIMIT {int(limit)}")
                    columns = [desc[0] for desc in cur.description] if cur.description else []
                    rows = [list(row) for row in cur.fetchall()]
                    return columns, rows
                finally:
                    conn.close()

            columns, rows = await loop.run_in_executor(None, _sample)
            return {
                "success": True,
                "columns": columns,
                "rows": rows,
                "row_count": len(rows),
                "error": None,
            }
        except Exception as exc:
            logger.error("snowflake.sample_query.failed", error=str(exc))
            return {
                "success": False,
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": str(exc),
            }
