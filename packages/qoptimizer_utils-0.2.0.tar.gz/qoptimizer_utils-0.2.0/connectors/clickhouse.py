from __future__ import annotations

import asyncio
from datetime import datetime, timezone, timedelta
from typing import Any

import structlog
from clickhouse_driver import Client

from shared.connectors.base import (
    BaseConnector, ConnectionParams, CHQueryRecord,
    CHQueryThreadRecord, CHQueryViewRecord,
    CHSystemMetricRecord, CHSystemEventRecord,
    CHTablePartsRecord, CHDiskRecord, CHReplicaRecord,
)
from shared.queries.clickhouse import (
    FETCH_QUERY_HISTORY, FETCH_QUERY_THREADS, FETCH_QUERY_VIEWS,
    FETCH_SYSTEM_METRICS, FETCH_SYSTEM_EVENTS,
    FETCH_TABLE_PARTS, FETCH_DISKS, FETCH_REPLICAS,
)

logger = structlog.get_logger(__name__)


class ClickHouseConnector(BaseConnector):
    def __init__(self, params: ConnectionParams):
        super().__init__(params)

    def _make_client(self) -> Client:
        credentials = self.params.credentials or {}
        kwargs: dict[str, Any] = {
            "host": self.params.host or "localhost",
            "database": self.params.database or "default",
            "user": credentials.get("username", "default"),
            "password": credentials.get("password", ""),
            "secure": True,
        }
        if self.params.port:
            kwargs["port"] = self.params.port
        return Client(**kwargs)

    async def test_connection(self) -> bool:
        """Test connectivity by connecting and running SELECT 1."""
        loop = asyncio.get_event_loop()
        try:
            def _test() -> Any:
                client = self._make_client()
                return client.execute("SELECT 1")

            await loop.run_in_executor(None, _test)
            return True
        except Exception as exc:
            raise ConnectionError(f"ClickHouse connection failed: {exc}") from exc

    async def fetch_query_history(self, lookback_hours: int = 24) -> list[CHQueryRecord]:
        """
        Fetch query history from system.query_log where type='QueryFinish',
        grouped by normalized_query_hash for the last lookback_hours.
        """
        loop = asyncio.get_event_loop()
        try:
            def _fetch() -> list[dict]:
                client = self._make_client()
                rows = client.execute(
                    FETCH_QUERY_HISTORY,
                    {"lookback_hours": lookback_hours},
                    with_column_types=False,
                    settings={"use_client_time_zone": True},
                )
                columns = [
                    "normalized_query_hash",
                    "sample_query",
                    "normalized_query",
                    "execution_count",
                    "total_time_ms",
                    "avg_time_ms",
                    "max_time_ms",
                    "rows_returned",
                    "read_rows",
                    "read_bytes",
                    "written_rows",
                    "written_bytes",
                    "result_bytes",
                    "memory_usage",
                    "databases",
                    "tables",
                    "columns",
                    "snapshot_start_at",
                    "snapshot_end_at",
                ]
                return [dict(zip(columns, row)) for row in rows]

            rows: list[dict] = await loop.run_in_executor(None, _fetch)
        except Exception as exc:
            raise RuntimeError(f"ClickHouse fetch_query_history failed: {exc}") from exc

        records: list[CHQueryRecord] = []
        for row in rows:
            sample_query: str = row.get("sample_query") or ""
            # Prefer ClickHouse's own normalized_query; fall back to our normalizer.
            ch_normalized: str = row.get("normalized_query") or ""
            normalized = ch_normalized if ch_normalized else self.normalize_query(sample_query)
            query_hash = self.compute_hash(normalized)

            record = CHQueryRecord(
                normalized_query=normalized,
                sample_query=sample_query,
                query_hash=query_hash,
                execution_count=int(row.get("execution_count") or 0),
                total_time_ms=float(row.get("total_time_ms") or 0.0),
                avg_time_ms=float(row.get("avg_time_ms") or 0.0),
                max_time_ms=float(row.get("max_time_ms") or 0.0),
                rows_returned=int(row.get("rows_returned") or 0),
                read_rows=int(row.get("read_rows") or 0),
                read_bytes=int(row.get("read_bytes") or 0),
                written_rows=int(row.get("written_rows") or 0),
                written_bytes=int(row.get("written_bytes") or 0),
                result_bytes=int(row.get("result_bytes") or 0),
                memory_usage=int(row.get("memory_usage") or 0),
                databases=row.get("databases") or [],
                tables=row.get("tables") or [],
                columns=row.get("columns") or [],
                snapshot_start_at=row.get("snapshot_start_at"),
                snapshot_end_at=row.get("snapshot_end_at"),
            )
            records.append(record)

        return records

    async def fetch_query_threads(
        self, lookback_hours: int = 24,
    ) -> list[CHQueryThreadRecord]:
        """Fetch thread-level execution details from system.query_thread_log."""
        loop = asyncio.get_event_loop()

        def _fetch() -> list[dict]:
            client = self._make_client()
            rows = client.execute(
                FETCH_QUERY_THREADS,
                {"lookback_hours": lookback_hours},
                with_column_types=False,
                settings={"use_client_time_zone": True},
            )
            columns = [
                "normalized_query_hash", "thread_count", "peak_memory_usage",
                "read_rows", "read_bytes", "snapshot_start_at", "snapshot_end_at",
            ]
            return [dict(zip(columns, row)) for row in rows]

        rows: list[dict] = await loop.run_in_executor(None, _fetch)
        records: list[CHQueryThreadRecord] = []
        for row in rows:
            records.append(CHQueryThreadRecord(
                query_hash=str(row.get("normalized_query_hash") or ""),
                thread_count=int(row.get("thread_count") or 0),
                peak_memory_usage=int(row.get("peak_memory_usage") or 0),
                read_rows=int(row.get("read_rows") or 0),
                read_bytes=int(row.get("read_bytes") or 0),
                snapshot_start_at=row.get("snapshot_start_at"),
                snapshot_end_at=row.get("snapshot_end_at"),
            ))
        return records

    async def fetch_query_views(
        self, lookback_hours: int = 24,
    ) -> list[CHQueryViewRecord]:
        """Fetch materialized view tracking from system.query_views_log."""
        loop = asyncio.get_event_loop()

        def _fetch() -> list[dict]:
            client = self._make_client()
            rows = client.execute(
                FETCH_QUERY_VIEWS,
                {"lookback_hours": lookback_hours},
                with_column_types=False,
                settings={"use_client_time_zone": True},
            )
            columns = [
                "view_name", "query_count", "read_rows", "read_bytes",
                "snapshot_start_at", "snapshot_end_at",
            ]
            return [dict(zip(columns, row)) for row in rows]

        rows: list[dict] = await loop.run_in_executor(None, _fetch)
        records: list[CHQueryViewRecord] = []
        for row in rows:
            records.append(CHQueryViewRecord(
                view_name=row.get("view_name") or "",
                query_count=int(row.get("query_count") or 0),
                read_rows=int(row.get("read_rows") or 0),
                read_bytes=int(row.get("read_bytes") or 0),
                snapshot_start_at=row.get("snapshot_start_at"),
                snapshot_end_at=row.get("snapshot_end_at"),
            ))
        return records

    async def fetch_system_metrics(self) -> list[CHSystemMetricRecord]:
        """Fetch current system.metrics snapshot."""
        loop = asyncio.get_event_loop()

        def _fetch() -> list[CHSystemMetricRecord]:
            client = self._make_client()
            rows = client.execute(FETCH_SYSTEM_METRICS)
            return [
                CHSystemMetricRecord(
                    metric=r[0], value=int(r[1]), description=r[2],
                )
                for r in rows
            ]

        return await loop.run_in_executor(None, _fetch)

    async def fetch_system_events(self) -> list[CHSystemEventRecord]:
        """Fetch cumulative system.events snapshot."""
        loop = asyncio.get_event_loop()

        def _fetch() -> list[CHSystemEventRecord]:
            client = self._make_client()
            rows = client.execute(FETCH_SYSTEM_EVENTS)
            return [
                CHSystemEventRecord(
                    event=r[0], value=int(r[1]), description=r[2],
                )
                for r in rows
            ]

        return await loop.run_in_executor(None, _fetch)

    async def fetch_table_parts(self) -> list[CHTablePartsRecord]:
        """Fetch aggregated table part stats from system.parts + system.tables."""
        loop = asyncio.get_event_loop()

        def _fetch() -> list[CHTablePartsRecord]:
            client = self._make_client()
            rows = client.execute(FETCH_TABLE_PARTS)
            return [
                CHTablePartsRecord(
                    database=r[0], table=r[1], engine=r[2],
                    partition_key=r[3], sorting_key=r[4],
                    part_count=int(r[5]), total_rows=int(r[6]),
                    bytes_on_disk=int(r[7]),
                    data_compressed_bytes=int(r[8]),
                    data_uncompressed_bytes=int(r[9]),
                    pk_bytes_in_memory=int(r[10]),
                )
                for r in rows
            ]

        return await loop.run_in_executor(None, _fetch)

    async def fetch_disks(self) -> list[CHDiskRecord]:
        """Fetch disk info from system.disks."""
        loop = asyncio.get_event_loop()

        def _fetch() -> list[CHDiskRecord]:
            client = self._make_client()
            rows = client.execute(FETCH_DISKS)
            return [
                CHDiskRecord(
                    name=r[0], path=r[1],
                    free_space=int(r[2]), total_space=int(r[3]),
                    disk_type=r[4],
                )
                for r in rows
            ]

        return await loop.run_in_executor(None, _fetch)

    async def fetch_replicas(self) -> list[CHReplicaRecord]:
        """Fetch replication status from system.replicas."""
        loop = asyncio.get_event_loop()

        def _fetch() -> list[CHReplicaRecord]:
            client = self._make_client()
            rows = client.execute(FETCH_REPLICAS)
            return [
                CHReplicaRecord(
                    database=r[0], table=r[1],
                    is_leader=bool(r[2]), is_readonly=bool(r[3]),
                    queue_size=int(r[4]), inserts_in_queue=int(r[5]),
                    merges_in_queue=int(r[6]),
                    total_replicas=int(r[7]), active_replicas=int(r[8]),
                )
                for r in rows
            ]

        return await loop.run_in_executor(None, _fetch)

    async def explain_query(self, query: str) -> dict:
        """Run EXPLAIN PLAN and EXPLAIN PIPELINE and return both plans."""
        loop = asyncio.get_event_loop()
        try:
            def _explain() -> dict:
                client = self._make_client()
                plan_rows = client.execute(f"EXPLAIN PLAN {query}")
                plan_lines = [r[0] if isinstance(r, (list, tuple)) else str(r) for r in plan_rows]

                pipeline_rows = client.execute(f"EXPLAIN PIPELINE {query}")
                pipeline_lines = [
                    r[0] if isinstance(r, (list, tuple)) else str(r) for r in pipeline_rows
                ]
                return {
                    "logical_plan": "\n".join(plan_lines),
                    "pipeline": "\n".join(pipeline_lines),
                }

            result = await loop.run_in_executor(None, _explain)
            return {
                "logical_plan": result["logical_plan"],
                "pipeline": result["pipeline"],
            }
        except Exception as exc:
            logger.error("clickhouse.explain_query.failed", error=str(exc))
            return {
                "logical_plan": None,
                "pipeline": None,
                "error": str(exc),
            }

    async def dry_run_query(self, query: str) -> dict:
        """Validate a query using EXPLAIN PLAN (parse without executing)."""
        loop = asyncio.get_event_loop()
        try:
            def _dry_run() -> list:
                client = self._make_client()
                return client.execute(f"EXPLAIN PLAN {query}")

            rows = await loop.run_in_executor(None, _dry_run)
            return {
                "success": True,
                "error": None,
                "plan_summary": {"step_count": len(rows)},
            }
        except Exception as exc:
            logger.error("clickhouse.dry_run_query.failed", error=str(exc))
            return {"success": False, "error": str(exc), "plan_summary": None}

    async def sample_query(self, query: str, limit: int = 100) -> dict:
        """Execute the query with a LIMIT and return sample results."""
        loop = asyncio.get_event_loop()
        try:
            def _sample() -> tuple[list[str], list[list]]:
                client = self._make_client()
                result = client.execute(
                    f"SELECT * FROM ({query}) AS _sample LIMIT {int(limit)}",
                    with_column_types=True,
                )
                # clickhouse_driver returns (data, columns) when with_column_types=True
                data, col_types = result
                columns = [name for name, _ in col_types]
                rows = [list(row) for row in data]
                return columns, rows

            columns, rows = await loop.run_in_executor(None, _sample)
            return {
                "success": True,
                "columns": columns,
                "rows": rows,
                "row_count": len(rows),
                "error": None,
            }
        except Exception as exc:
            logger.error("clickhouse.sample_query.failed", error=str(exc))
            return {
                "success": False,
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": str(exc),
            }
