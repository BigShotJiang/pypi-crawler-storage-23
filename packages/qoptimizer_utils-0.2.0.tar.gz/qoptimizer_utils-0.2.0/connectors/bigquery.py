from __future__ import annotations

import asyncio
from datetime import datetime, timezone, timedelta
from typing import Any

import structlog
from google.cloud import bigquery
from google.oauth2 import service_account

from shared.connectors.base import BaseConnector, ConnectionParams, BQQueryRecord
from shared.queries.bigquery import fetch_query_history as build_bq_query

logger = structlog.get_logger(__name__)


class BigQueryConnector(BaseConnector):
    def __init__(self, params: ConnectionParams):
        super().__init__(params)

    def _make_client(self) -> bigquery.Client:
        credentials_info: dict = self.params.credentials or {}
        credentials = service_account.Credentials.from_service_account_info(
            credentials_info,
            scopes=["https://www.googleapis.com/auth/bigquery.readonly"],
        )
        return bigquery.Client(
            project=self.params.project_id,
            credentials=credentials,
        )

    async def test_connection(self) -> bool:
        """Test connectivity by running SELECT 1 via the BigQuery client."""
        loop = asyncio.get_event_loop()
        try:
            def _test() -> None:
                client = self._make_client()
                client.query("SELECT 1").result()

            await loop.run_in_executor(None, _test)
            return True
        except Exception as exc:
            raise ConnectionError(f"BigQuery connection failed: {exc}") from exc

    async def fetch_query_history(self, lookback_hours: int = 24) -> list[BQQueryRecord]:
        """
        Fetch query history from the region-specific INFORMATION_SCHEMA.JOBS view,
        filtered for completed query jobs within the last lookback_hours, then
        grouped by a SHA-256 hash of the normalized query text.
        """
        region = self.params.region or "us"
        sql = build_bq_query(region, lookback_hours)

        loop = asyncio.get_event_loop()
        try:
            def _fetch() -> list[dict]:
                client = self._make_client()
                query_job = client.query(sql)
                results = query_job.result()
                return [dict(row) for row in results]

            rows: list[dict] = await loop.run_in_executor(None, _fetch)
        except Exception as exc:
            raise RuntimeError(f"BigQuery fetch_query_history failed: {exc}") from exc

        records: list[BQQueryRecord] = []
        for row in rows:
            sample_query: str = row.get("sample_query") or ""
            normalized = self.normalize_query(sample_query)
            query_hash = self.compute_hash(normalized)

            record = BQQueryRecord(
                normalized_query=normalized,
                sample_query=sample_query,
                query_hash=query_hash,
                execution_count=int(row.get("execution_count") or 0),
                total_bytes_processed=int(row.get("total_bytes_processed") or 0),
                total_bytes_billed=int(row.get("total_bytes_billed") or 0),
                slot_ms=int(row.get("total_slot_ms") or 0),
                snapshot_start_at=row.get("snapshot_start_at"),
                snapshot_end_at=row.get("snapshot_end_at"),
            )
            records.append(record)

        return records

    async def explain_query(self, query: str) -> dict:
        """Use BigQuery dry-run to extract execution plan metadata.

        BigQuery does not support a traditional EXPLAIN statement. Instead we submit
        the query as a dry run and inspect the job metadata for schema, bytes
        processed, and (when available) query plan stages.
        """
        loop = asyncio.get_event_loop()
        try:
            def _explain() -> dict:
                client = self._make_client()
                job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)
                job = client.query(query, job_config=job_config)

                # job.query_plan may be None for dry runs but we try anyway.
                stages = []
                if job.query_plan:
                    for stage in job.query_plan:
                        stages.append({
                            "name": stage.name,
                            "entry_id": stage.entry_id,
                            "status": stage.status,
                            "input_stages": list(stage.input_stages or []),
                            "records_read": stage.records_read,
                            "records_written": stage.records_written,
                        })

                schema_fields = []
                if job.schema:
                    schema_fields = [
                        {"name": f.name, "type": f.field_type} for f in job.schema
                    ]

                return {
                    "total_bytes_processed": job.total_bytes_processed or 0,
                    "schema": schema_fields,
                    "query_plan_stages": stages,
                }

            result = await loop.run_in_executor(None, _explain)
            return result
        except Exception as exc:
            logger.error("bigquery.explain_query.failed", error=str(exc))
            return {
                "total_bytes_processed": 0,
                "schema": [],
                "query_plan_stages": [],
                "error": str(exc),
            }

    async def dry_run_query(self, query: str) -> dict:
        """Validate a query using BigQuery's dryRun mode."""
        loop = asyncio.get_event_loop()
        try:
            def _dry_run() -> dict:
                client = self._make_client()
                job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)
                job = client.query(query, job_config=job_config)
                return {
                    "bytes_processed": job.total_bytes_processed or 0,
                }

            info = await loop.run_in_executor(None, _dry_run)
            return {
                "success": True,
                "error": None,
                "plan_summary": {"bytes_processed": info["bytes_processed"]},
            }
        except Exception as exc:
            logger.error("bigquery.dry_run_query.failed", error=str(exc))
            return {"success": False, "error": str(exc), "plan_summary": None}

    async def sample_query(self, query: str, limit: int = 100) -> dict:
        """Execute the query with a LIMIT and return sample results."""
        loop = asyncio.get_event_loop()
        try:
            def _sample() -> tuple[list[str], list[list]]:
                client = self._make_client()
                sql = f"SELECT * FROM ({query}) LIMIT {int(limit)}"
                query_job = client.query(sql)
                results = query_job.result()
                columns = [field.name for field in results.schema]
                rows = [list(row.values()) for row in results]
                return columns, rows

            columns, rows = await loop.run_in_executor(None, _sample)
            return {
                "success": True,
                "columns": columns,
                "rows": rows,
                "row_count": len(rows),
                "error": None,
            }
        except Exception as exc:
            logger.error("bigquery.sample_query.failed", error=str(exc))
            return {
                "success": False,
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": str(exc),
            }
