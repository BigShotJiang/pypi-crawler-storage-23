from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from shared.connectors.base import BaseConnector


def get_connector(vendor: str) -> type[BaseConnector]:
    if vendor == "postgresql":
        from shared.connectors.postgresql import PostgreSQLConnector
        return PostgreSQLConnector
    elif vendor == "snowflake":
        from shared.connectors.snowflake import SnowflakeConnector
        return SnowflakeConnector
    elif vendor == "clickhouse":
        from shared.connectors.clickhouse import ClickHouseConnector
        return ClickHouseConnector
    elif vendor == "bigquery":
        from shared.connectors.bigquery import BigQueryConnector
        return BigQueryConnector
    else:
        raise ValueError(f"Unsupported vendor: {vendor}")
