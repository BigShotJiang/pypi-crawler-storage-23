from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from typing import Any

import asyncpg
import structlog

from shared.connectors.base import (
    BaseConnector, ConnectionParams, PGQueryRecord, PGDatabaseStatsRecord,
    PGTableStatsRecord, PGTableIOStatsRecord,
)
from shared.queries.postgresql import (
    FETCH_QUERY_HISTORY, FETCH_DATABASE_STATS,
    FETCH_TABLE_STATS, FETCH_TABLE_IO_STATS,
)

logger = structlog.get_logger(__name__)


class PostgreSQLConnector(BaseConnector):
    def __init__(self, params: ConnectionParams):
        super().__init__(params)

    async def _get_connection(self) -> asyncpg.Connection:
        credentials = self.params.credentials or {}
        return await asyncpg.connect(
            host=self.params.host,
            port=self.params.port or 5432,
            database=self.params.database,
            user=credentials.get("username"),
            password=credentials.get("password"),
        )

    async def test_connection(self) -> bool:
        """Test connectivity by connecting and running SELECT 1."""
        try:
            conn = await self._get_connection()
            try:
                await conn.fetchval("SELECT 1")
            finally:
                await conn.close()
            return True
        except asyncpg.PostgresError as exc:
            raise ConnectionError(f"PostgreSQL connection failed: {exc}") from exc
        except OSError as exc:
            raise ConnectionError(f"PostgreSQL connection failed: {exc}") from exc

    async def fetch_query_history(self, lookback_hours: int = 24) -> list[PGQueryRecord]:
        """
        Fetch query history from pg_stat_statements joined with pg_database.
        Requires the pg_stat_statements extension to be enabled on the server.
        """
        try:
            conn = await self._get_connection()
            try:
                rows = await conn.fetch(FETCH_QUERY_HISTORY, self.params.database)
            finally:
                await conn.close()
        except asyncpg.PostgresError as exc:
            raise RuntimeError(f"PostgreSQL fetch_query_history failed: {exc}") from exc

        now = datetime.now(tz=timezone.utc)
        snapshot_start = now - timedelta(hours=lookback_hours)

        records: list[PGQueryRecord] = []
        for row in rows:
            sample_query: str = row["query"] or ""
            normalized = self.normalize_query(sample_query)
            query_hash = self.compute_hash(normalized)

            calls: int = row["calls"] or 0
            total_exec_time: float = row["total_exec_time"] or 0.0
            avg_time_ms = total_exec_time / calls if calls > 0 else 0.0

            record = PGQueryRecord(
                normalized_query=normalized,
                sample_query=sample_query,
                query_hash=query_hash,
                execution_count=calls,
                total_time_ms=total_exec_time,
                avg_time_ms=avg_time_ms,
                max_time_ms=row["max_exec_time"] or 0.0,
                rows_returned=row["rows"] or 0,
                snapshot_start_at=snapshot_start,
                snapshot_end_at=now,
                queryid=row["queryid"] or 0,
                min_exec_time=row["min_exec_time"] or 0.0,
                mean_exec_time=row["mean_exec_time"] or 0.0,
                shared_blks_hit=row["shared_blks_hit"] or 0,
                shared_blks_read=row["shared_blks_read"] or 0,
                shared_blks_written=row["shared_blks_written"] or 0,
                local_blks_hit=row["local_blks_hit"] or 0,
                local_blks_read=row["local_blks_read"] or 0,
                temp_blks_read=row["temp_blks_read"] or 0,
                temp_blks_written=row["temp_blks_written"] or 0,
                blk_read_time=row["blk_read_time"] or 0.0,
                blk_write_time=row["blk_write_time"] or 0.0,
                stats_since=row.get("stats_since"),
            )
            records.append(record)

        return records

    async def fetch_database_stats(self) -> list[PGDatabaseStatsRecord]:
        """Fetch database-level statistics from pg_stat_database."""
        try:
            conn = await self._get_connection()
            try:
                rows = await conn.fetch(FETCH_DATABASE_STATS)
            finally:
                await conn.close()
        except asyncpg.PostgresError as exc:
            raise RuntimeError(f"PostgreSQL fetch_database_stats failed: {exc}") from exc

        records: list[PGDatabaseStatsRecord] = []
        for row in rows:
            records.append(PGDatabaseStatsRecord(
                datname=row["datname"] or "",
                numbackends=row["numbackends"] or 0,
                xact_commit=row["xact_commit"] or 0,
                xact_rollback=row["xact_rollback"] or 0,
                blks_read=row["blks_read"] or 0,
                blks_hit=row["blks_hit"] or 0,
                tup_returned=row["tup_returned"] or 0,
                tup_inserted=row["tup_inserted"] or 0,
                tup_updated=row["tup_updated"] or 0,
                tup_deleted=row["tup_deleted"] or 0,
            ))
        return records

    async def fetch_table_stats(self) -> list[PGTableStatsRecord]:
        """Fetch table-level statistics from pg_stat_user_tables."""
        try:
            conn = await self._get_connection()
            try:
                rows = await conn.fetch(FETCH_TABLE_STATS)
            finally:
                await conn.close()
        except asyncpg.PostgresError as exc:
            raise RuntimeError(f"PostgreSQL fetch_table_stats failed: {exc}") from exc

        records: list[PGTableStatsRecord] = []
        for row in rows:
            records.append(PGTableStatsRecord(
                schemaname=row["schemaname"] or "",
                relname=row["relname"] or "",
                seq_scan=row["seq_scan"],
                seq_tup_read=row["seq_tup_read"],
                idx_scan=row["idx_scan"],
                idx_tup_fetch=row["idx_tup_fetch"],
                n_tup_ins=row["n_tup_ins"],
                n_tup_upd=row["n_tup_upd"],
                n_tup_del=row["n_tup_del"],
                n_live_tup=row["n_live_tup"],
                n_dead_tup=row["n_dead_tup"],
                last_vacuum=row["last_vacuum"],
                last_analyze=row["last_analyze"],
            ))
        return records

    async def fetch_table_io_stats(self) -> list[PGTableIOStatsRecord]:
        """Fetch table-level I/O statistics from pg_statio_user_tables."""
        try:
            conn = await self._get_connection()
            try:
                rows = await conn.fetch(FETCH_TABLE_IO_STATS)
            finally:
                await conn.close()
        except asyncpg.PostgresError as exc:
            raise RuntimeError(f"PostgreSQL fetch_table_io_stats failed: {exc}") from exc

        records: list[PGTableIOStatsRecord] = []
        for row in rows:
            records.append(PGTableIOStatsRecord(
                schemaname=row["schemaname"] or "",
                relname=row["relname"] or "",
                heap_blks_read=row["heap_blks_read"],
                heap_blks_hit=row["heap_blks_hit"],
                idx_blks_read=row["idx_blks_read"],
                idx_blks_hit=row["idx_blks_hit"],
                toast_blks_read=row["toast_blks_read"],
                toast_blks_hit=row["toast_blks_hit"],
                tidx_blks_read=row["tidx_blks_read"],
                tidx_blks_hit=row["tidx_blks_hit"],
            ))
        return records

    async def explain_query(self, query: str) -> dict:
        """Run EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) inside a READ ONLY transaction.

        The transaction is always rolled back so the database is never mutated.
        """
        try:
            conn = await self._get_connection()
            try:
                await conn.execute("BEGIN TRANSACTION READ ONLY")
                try:
                    row = await conn.fetchval(
                        f"EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) {query}"
                    )
                finally:
                    await conn.execute("ROLLBACK")

                plan_json = json.loads(row) if isinstance(row, str) else row
                plan = plan_json[0] if isinstance(plan_json, list) else plan_json

                # Extract useful summary fields from the top-level plan node.
                top_plan = plan.get("Plan", {})
                planning_time = plan.get("Planning Time", 0.0)
                execution_time = plan.get("Execution Time", 0.0)

                scan_types: list[str] = []
                self._collect_scan_types(top_plan, scan_types)

                return {
                    "plan": plan,
                    "total_cost": top_plan.get("Total Cost", 0.0),
                    "execution_time_ms": execution_time,
                    "planning_time_ms": planning_time,
                    "scan_types": sorted(set(scan_types)),
                    "rows_estimate": top_plan.get("Plan Rows", 0),
                }
            finally:
                await conn.close()
        except Exception as exc:
            logger.error("postgresql.explain_query.failed", error=str(exc))
            return {
                "plan": None,
                "total_cost": 0.0,
                "execution_time_ms": 0.0,
                "planning_time_ms": 0.0,
                "scan_types": [],
                "rows_estimate": 0,
                "error": str(exc),
            }

    @staticmethod
    def _collect_scan_types(node: dict, result: list[str]) -> None:
        """Recursively collect scan/join node types from an EXPLAIN plan."""
        node_type = node.get("Node Type", "")
        if node_type:
            result.append(node_type)
        for child in node.get("Plans", []):
            PostgreSQLConnector._collect_scan_types(child, result)

    async def dry_run_query(self, query: str) -> dict:
        """Validate a query using EXPLAIN (no ANALYZE) without executing it."""
        try:
            conn = await self._get_connection()
            try:
                rows = await conn.fetch(f"EXPLAIN {query}")
                plan_lines = [r[0] for r in rows]
                return {
                    "success": True,
                    "error": None,
                    "plan_summary": {"plan_text": "\n".join(plan_lines)},
                }
            finally:
                await conn.close()
        except Exception as exc:
            logger.error("postgresql.dry_run_query.failed", error=str(exc))
            return {"success": False, "error": str(exc), "plan_summary": None}

    async def sample_query(self, query: str, limit: int = 100) -> dict:
        """Execute the query with a LIMIT inside a READ ONLY transaction."""
        try:
            conn = await self._get_connection()
            try:
                await conn.execute("BEGIN TRANSACTION READ ONLY")
                try:
                    stmt = await conn.prepare(
                        f"SELECT * FROM ({query}) AS _sample LIMIT {int(limit)}"
                    )
                    columns = [attr.name for attr in stmt.get_attributes()]
                    records = await stmt.fetch()
                    rows = [list(r.values()) for r in records]
                finally:
                    await conn.execute("ROLLBACK")

                return {
                    "success": True,
                    "columns": columns,
                    "rows": rows,
                    "row_count": len(rows),
                    "error": None,
                }
            finally:
                await conn.close()
        except Exception as exc:
            logger.error("postgresql.sample_query.failed", error=str(exc))
            return {
                "success": False,
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": str(exc),
            }
