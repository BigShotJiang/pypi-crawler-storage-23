from cryptography.fernet import Fernet

from shared.config import settings

_fernet = Fernet(settings.credential_encryption_key.encode())


def encrypt_credentials(plaintext: str) -> bytes:
    return _fernet.encrypt(plaintext.encode())


def decrypt_credentials(ciphertext: bytes) -> str:
    return _fernet.decrypt(ciphertext).decode()
