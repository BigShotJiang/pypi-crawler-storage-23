from shared.constants.thresholds import (
    SLOW_QUERY_MS,
    HIGH_MEMORY_BYTES,
    FULL_SCAN_RATIO,
    HIGH_IO_RATIO,
    HIGH_ROW_COUNT,
    HIGH_EXECUTION_COUNT,
    BQ_HIGH_BYTES_PROCESSED,
)
from shared.constants.issues import (
    SEVERITY_BONUS,
    SEVERITY_MAP,
    SEVERITY_ORDER,
)
from shared.constants.vendors import SUPPORTED_VENDORS
