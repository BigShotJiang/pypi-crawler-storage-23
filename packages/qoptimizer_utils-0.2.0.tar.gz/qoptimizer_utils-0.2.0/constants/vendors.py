"""Database vendor constants."""

SUPPORTED_VENDORS = ("postgresql", "snowflake", "clickhouse", "bigquery")
