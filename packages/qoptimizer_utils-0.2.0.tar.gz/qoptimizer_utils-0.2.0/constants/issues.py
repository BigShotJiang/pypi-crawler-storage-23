"""Issue types and severity mappings."""

# Priority score bonus per issue type
SEVERITY_BONUS: dict[str, int] = {
    "full_scan": 15,
    "temp_spill": 15,
    "spill_detected": 15,
    "high_io": 10,
    "high_write_io": 10,
    "cache_miss": 10,
    "slow_query": 10,
    "high_row_count": 5,
    "frequent_query": 5,
}

# Issue type → severity level mapping
SEVERITY_MAP: dict[str, str] = {
    "full_scan": "high",
    "temp_spill": "high",
    "spill_detected": "high",
    "high_io": "medium",
    "high_write_io": "medium",
    "cache_miss": "medium",
    "slow_query": "medium",
    "high_row_count": "low",
    "frequent_query": "low",
}

# Severity order (highest first)
SEVERITY_ORDER: list[str] = ["critical", "high", "medium", "low", "none"]
