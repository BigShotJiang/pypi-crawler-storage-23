"""Performance thresholds for issue detection."""

# Slow query: avg execution time in milliseconds
SLOW_QUERY_MS = 1000

# High memory usage in bytes (ClickHouse)
HIGH_MEMORY_BYTES = 1_000_000_000

# Full scan: partition scan ratio (Snowflake)
FULL_SCAN_RATIO = 0.8

# High IO: block read ratio (PostgreSQL)
HIGH_IO_RATIO = 0.5

# High row count threshold
HIGH_ROW_COUNT = 100_000

# High execution count threshold
HIGH_EXECUTION_COUNT = 10_000

# BigQuery: bytes processed threshold (10 GB)
BQ_HIGH_BYTES_PROCESSED = 10_000_000_000
