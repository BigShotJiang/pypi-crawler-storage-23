import enum


class LatticeKind(enum.Enum):
    """ """

    VOLUME = 1
    SEGMENTATION = 2
