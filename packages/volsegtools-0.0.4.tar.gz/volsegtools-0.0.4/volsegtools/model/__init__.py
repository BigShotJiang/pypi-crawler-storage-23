from .chunking_mode import ChunkingMode

# from .downsampling_data import Data, ChannelInfo, FlatChannelIterator
from .metadata import (
    ChannelMetadata,
    DescriptiveStatistics,
    Metadata,
    OriginalTimeFrameMetadata,
    TimeFrameMetadata,
)
from .opaque_data_handle import ChannelInfo, FlatChannelIterator, OpaqueDataHandle
from .storing_parameters import StoringParameters
from .working_store import WorkingStore
