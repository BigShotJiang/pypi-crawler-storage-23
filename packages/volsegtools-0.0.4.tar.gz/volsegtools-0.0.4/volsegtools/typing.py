from typing import Union

import numpy as np

StorableDType = Union[
    np.uint8,
    np.uint16,
    np.uint32,
    np.int8,
    np.int16,
    np.int32,
]
