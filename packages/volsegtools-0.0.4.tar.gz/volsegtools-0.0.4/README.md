# Volseg Tools

A library used for preprocessing of volumes and segmentations for further usage.
