# ADR-NNN: [Title]

## Status

[Proposed | Accepted | Deprecated | Superseded]

Date: YYYY-MM-DD

## Context

[Describe the issue motivating this decision. What is the problem we're trying to solve? What constraints exist? What forces are at play?]

## Decision

[Describe the change proposed or decision made. Be specific about what will be done, not just the general direction.]

## Consequences

### Positive

- [List beneficial outcomes]

### Negative

- [List drawbacks or costs]

### Neutral

- [List side effects that are neither positive nor negative]

## Alternatives Considered

[Optional section. List other options that were considered and why they were rejected.]

## References

[Optional section. Link to related documents, issues, or external resources.]
