import yaml
from pathlib import Path
from typing import Any

from fluxconf import ConfigIO, VersionedBaseModel
from missim_config import MissimConfig, MissimConfigIO


def test_round_trip(tmp_path: Path):
    """Write a config and read it back — values should match."""
    io = MissimConfigIO(tmp_path)
    original = MissimConfig()
    io.write(original)
    loaded = io.read()
    assert loaded.mode == original.mode
    assert loaded.log_level == original.log_level
    assert loaded.version == 0


def test_version_field_always_present(tmp_path: Path):
    """The 'version' field must appear in the YAML even when it matches the default."""
    io = MissimConfigIO(tmp_path)
    io.write(MissimConfig())
    raw = yaml.safe_load((tmp_path / "missim.yml").read_text())
    assert "version" in raw
    assert raw["version"] == 0


def test_schema_header_present(tmp_path: Path):
    """Written files should start with the yaml-language-server schema comment."""
    io = MissimConfigIO(tmp_path)
    io.write(MissimConfig())
    content = (tmp_path / "missim.yml").read_text()
    assert content.startswith("# yaml-language-server: $schema=")


def test_old_config_without_version(tmp_path: Path):
    """A YAML file missing 'version' should parse with version=0."""
    io = MissimConfigIO(tmp_path)
    (tmp_path / "missim.yml").write_text("log_level: info\nmode: low-fidelity\n")
    config = io.read()
    assert config.version == 0


def test_serialise_returns_yaml_string(tmp_path: Path):
    """serialise() should return a valid YAML string (no file write)."""
    io = MissimConfigIO(tmp_path)
    config = MissimConfig()
    result = io.serialise(config)
    assert isinstance(result, str)
    parsed = yaml.safe_load(result)
    assert parsed["mode"] == "low-fidelity"


def test_write_with_include_defaults(tmp_path: Path):
    """write(include_defaults=True) should include all fields."""
    io = MissimConfigIO(tmp_path)
    io.write(MissimConfig(), include_defaults=True)
    raw = yaml.safe_load((tmp_path / "missim.yml").read_text())
    assert "discovery" in raw
    assert "proxy" in raw
    assert "log_level" in raw


def test_write_stamps_latest_version(tmp_path: Path):
    """write() should set version to the latest migration, not 0."""

    class MyConfig(VersionedBaseModel):
        name: str = "default"

    def _migrate_1(data: dict[str, Any]) -> dict[str, Any]:
        data.setdefault("name", "migrated")
        return data

    class MyConfigIO(ConfigIO[MyConfig]):
        file_name = "my.yml"
        config_type = MyConfig
        migrations = {"1_add_name": _migrate_1}

    io = MyConfigIO(tmp_path)
    config = MyConfig()
    assert config.version == 0

    io.write(config)
    raw = yaml.safe_load((tmp_path / "my.yml").read_text())
    assert raw["version"] == 1


def test_write_does_not_downgrade_version(tmp_path: Path):
    """write() should not lower a version that is already above latest."""

    class MyConfig(VersionedBaseModel):
        name: str = "default"

    class MyConfigIO(ConfigIO[MyConfig]):
        file_name = "my.yml"
        config_type = MyConfig

    io = MyConfigIO(tmp_path)
    config = MyConfig(version=5)
    io.write(config)
    raw = yaml.safe_load((tmp_path / "my.yml").read_text())
    assert raw["version"] == 5
