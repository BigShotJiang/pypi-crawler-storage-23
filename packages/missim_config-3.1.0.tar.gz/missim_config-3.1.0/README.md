# Missim Config

Configuration management for MISSIM, backed by [fluxconf](https://github.com/Greenroom-Robotics/fluxconf).

Config is stored in `~/.config/greenroom/missim.yml`.

## Install

```bash
pip install -e ./packages/missim_config
```

## Usage

### Reading config

```python
from missim_config import config_io

config = config_io.read()
```

### Writing config

```python
from missim_config import config_io, MissimConfig

config = MissimConfig()
config_io.write(config)
```

### Getting the config path

```python
from missim_config import config_io

path = config_io.get_path()
```

### Generating schemas

After changing the dataclasses, you can generate the schemas with:

```bash
python3 -m missim_config.generate_schemas
```

## Migrations

Schema migrations live in `missim_config/migrations/`. To add a migration:

1. Create a file named `N_description.py` (e.g. `1_add_new_field.py`)
2. Define a `migrate(data: dict) -> dict` function that transforms the raw config dict
3. The `version` field is managed automatically by fluxconf
