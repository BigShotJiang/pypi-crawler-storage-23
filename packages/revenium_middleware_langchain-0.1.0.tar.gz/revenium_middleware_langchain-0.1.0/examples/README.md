# Revenium LangChain Middleware Examples

This directory contains example scripts demonstrating how to use the Revenium LangChain middleware to meter AI usage.

## Getting Started - Step by Step

### 1. Create a project directory

```bash
mkdir my-langchain-project
cd my-langchain-project
```

### 2. Create and activate a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate    # On macOS/Linux
# .venv\Scripts\activate     # On Windows
```

### 3. Install the middleware

```bash
# Install from PyPI
pip install revenium-middleware-langchain

# Or install from source (for development)
cd /path/to/revenium-middleware-langchain-internal
pip install -e ".[dev]"
```

### 4. Install your LLM provider

```bash
# For OpenAI (used in examples)
pip install langchain-openai

# For Anthropic
pip install langchain-anthropic

# For Google
pip install langchain-google-genai

# For agents (used in agent_example.py)
pip install langgraph
```

### 5. Configure environment variables

```bash
# Copy the example .env file
cp .env.example .env

# Edit .env with your actual keys
export REVENIUM_METERING_API_KEY=hak_your_api_key_here
export OPENAI_API_KEY=sk-your_openai_key_here    # For the examples below
```

Or create a `.env` file:

```bash
REVENIUM_METERING_API_KEY=hak_your_api_key_here
OPENAI_API_KEY=sk-your_openai_key_here
```

## Available Examples

### `basic_llm.py` - Simple LLM Integration

Demonstrates the simplest way to meter LLM calls with Revenium.

**What it shows:**
- Creating a `ReveniumCallbackHandler` with environment variables
- Alternative: explicit `ReveniumConfig` configuration
- Single LLM call with automatic metering
- Multiple calls grouped by `trace_id`

**Run:**
```bash
python examples/basic_llm.py
```

### `agent_example.py` - Agent with Tools

Demonstrates metering in a more complex setup with LangChain agents and tools.

**What it shows:**
- Using the handler with LangGraph's `create_react_agent`
- Automatic metering of all LLM calls made by the agent
- Tool invocations (weather lookup, calculator)
- Multi-turn conversation tracking
- Parent-child transaction linking

**Run:**
```bash
python examples/agent_example.py
```

## Prerequisites

| Example | Required Packages | Required API Keys |
|---------|-------------------|-------------------|
| `basic_llm.py` | `langchain-openai` | `REVENIUM_METERING_API_KEY`, `OPENAI_API_KEY` |
| `agent_example.py` | `langchain-openai`, `langgraph` | `REVENIUM_METERING_API_KEY`, `OPENAI_API_KEY` |
| `chain_example.py` | `langchain-openai` | `REVENIUM_METERING_API_KEY`, `OPENAI_API_KEY` |
| `prompt_capture_example.py` | `langchain-openai` | `REVENIUM_METERING_API_KEY`, `OPENAI_API_KEY` |
| `trace_visualization_example.py` | `langchain-openai` | `REVENIUM_METERING_API_KEY`, `OPENAI_API_KEY` |

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `REVENIUM_METERING_API_KEY` | Yes | Your Revenium API key (must start with `hak_`) |
| `REVENIUM_METERING_BASE_URL` | No | API base URL (default: `https://api.revenium.ai`) |
| `REVENIUM_LOG_LEVEL` | No | Log level (`DEBUG`, `INFO`, `WARNING`, `ERROR`) |
| `REVENIUM_CAPTURE_PROMPTS` | No | Capture prompts and responses (`true`/`false`) |
| `OPENAI_API_KEY` | Yes* | OpenAI API key (*required for the included examples) |

## Testing Your Setup

After configuration, verify everything works:

```bash
python examples/basic_llm.py
```

**Expected output:**
```
Making LLM call...

Response: The capital of France is Paris.

Metering data has been sent to Revenium!
```

If you enable debug logging (`REVENIUM_LOG_LEVEL=DEBUG`), you'll see additional output showing the metering payload being sent to Revenium.

## Troubleshooting

- **`ValueError: API key must start with 'hak_'`** - Check your `REVENIUM_METERING_API_KEY` is correct
- **`openai.AuthenticationError`** - Verify your `OPENAI_API_KEY` is valid
- **`ModuleNotFoundError: No module named 'langchain_openai'`** - Run `pip install langchain-openai`
- **`ModuleNotFoundError: No module named 'langgraph'`** - Run `pip install langgraph` (for agent example)
- **No metering data appearing** - Set `REVENIUM_LOG_LEVEL=DEBUG` to see what's being sent

## Additional Resources

- [Revenium Documentation](https://docs.revenium.io)
- [LangChain Documentation](https://python.langchain.com/docs/)
- [LangGraph Documentation](https://langchain-ai.github.io/langgraph/)
