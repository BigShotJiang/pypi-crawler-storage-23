#!/usr/bin/env python3
"""
LangChain Basic LLM Example

Shows how to use the Revenium callback handler with LangChain ChatOpenAI.
Demonstrates simple LLM calls with automatic metering.

Prerequisites:
    Create a .env file with:
        REVENIUM_METERING_API_KEY="hak_your_key"
        OPENAI_API_KEY="sk-your_key"
        REVENIUM_LOG_LEVEL=DEBUG
"""

import os
import time
from dotenv import load_dotenv

load_dotenv()

from langchain_openai import ChatOpenAI
from revenium_middleware_langchain import ReveniumCallbackHandler


def basic_llm_example():
    """Basic LLM call with automatic metering."""
    print("=" * 70)
    print("LangChain Middleware - Basic LLM Example")
    print("=" * 70)
    print()

    openai_key = os.getenv("OPENAI_API_KEY")
    revenium_key = os.getenv("REVENIUM_METERING_API_KEY")

    if not openai_key:
        print("Error: OPENAI_API_KEY not set")
        print('   Add it to your .env file: OPENAI_API_KEY="sk-..."')
        return

    if not revenium_key:
        print("Error: REVENIUM_METERING_API_KEY not set")
        print('   Add it to your .env file: REVENIUM_METERING_API_KEY="hak_..."')
        return

    print(f"  OpenAI API Key: {'*' * (len(openai_key) - 4)}{openai_key[-4:]}")
    print(f"  Revenium API Key: {'*' * (len(revenium_key) - 4)}{revenium_key[-4:]}")
    print()

    # Example 1: Simple LLM call
    print("=== Example 1: Simple LLM Call ===")
    print()

    handler = ReveniumCallbackHandler(
        trace_id=f"basic-{int(time.time() * 1000)}",
        trace_name="basic_llm_example",
        agent_name="basic_agent",
    )

    llm = ChatOpenAI(model="gpt-4o-mini", callbacks=[handler])

    response = llm.invoke("What is the capital of France? Answer in one sentence.")
    print(f"  Response: {response.content}")
    print("  Metering data sent to Revenium")
    print()

    # Example 2: Multiple calls with the same handler (grouped by trace_id)
    print("=== Example 2: Multiple Calls (Same Trace) ===")
    print()

    handler = ReveniumCallbackHandler(
        trace_id=f"multi-{int(time.time() * 1000)}",
        trace_name="multi_call_example",
        agent_name="multi_agent",
    )

    llm = ChatOpenAI(model="gpt-4o-mini", callbacks=[handler])

    questions = [
        "What is 2 + 2?",
        "Name a programming language.",
        "What color is the sky?",
    ]

    for i, question in enumerate(questions, 1):
        response = llm.invoke(question)
        print(f"  Q{i}: {question}")
        print(f"  A{i}: {response.content}")
        print()

    print("  All 3 calls metered under the same trace_id")
    print()

    # Example 3: Different model
    print("=== Example 3: Different Model (gpt-4o) ===")
    print()

    handler = ReveniumCallbackHandler(
        trace_id=f"model-test-{int(time.time() * 1000)}",
        agent_name="model_test_agent",
    )

    llm = ChatOpenAI(model="gpt-4o", callbacks=[handler])

    response = llm.invoke("Explain middleware in one sentence.")
    print(f"  Response: {response.content}")
    print("  Metered with model=gpt-4o, provider=openai")
    print()

    # Summary
    print("=" * 70)
    print("Summary:")
    print("  - Simple LLM calls are automatically metered")
    print("  - Multiple calls share a trace_id for grouping")
    print("  - Model name and provider are auto-detected")
    print("  - Check your Revenium dashboard to see the data")
    print("=" * 70)


if __name__ == "__main__":
    basic_llm_example()
