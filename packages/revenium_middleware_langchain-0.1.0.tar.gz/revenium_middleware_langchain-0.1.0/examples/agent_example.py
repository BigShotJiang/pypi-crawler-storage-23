#!/usr/bin/env python3
"""
LangChain Agent Example

Shows how to use the Revenium callback handler with LangGraph agents
that use tools. All LLM calls made by the agent are automatically metered
with parent-child transaction relationships.

Prerequisites:
    pip install langgraph

    Create a .env file with:
        REVENIUM_METERING_API_KEY="hak_your_key"
        OPENAI_API_KEY="sk-your_key"
        REVENIUM_LOG_LEVEL=DEBUG
"""

import os
import time
from dotenv import load_dotenv

load_dotenv()

from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage
from langgraph.prebuilt import create_react_agent
from revenium_middleware_langchain import ReveniumCallbackHandler


@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city.

    Args:
        city: The city to get weather for.
    """
    weather_data = {
        "new york": "Sunny, 72F",
        "london": "Cloudy, 58F",
        "tokyo": "Partly cloudy, 68F",
        "paris": "Rainy, 55F",
        "san francisco": "Foggy, 61F",
    }
    return weather_data.get(city.lower(), f"Weather data not available for {city}")


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression.

    Args:
        expression: A mathematical expression to evaluate (e.g., '15 * 23').
    """
    try:
        # NOTE: eval() is used here for demo purposes only with a restricted
        # character set. Do not use eval() in production — use a safe math
        # parser instead (e.g., sympy, asteval, or numexpr).
        allowed_chars = set("0123456789+-*/(). ")
        if not all(c in allowed_chars for c in expression):
            return f"Error: invalid characters in expression"
        result = eval(expression)  # noqa: S307
        return str(result)
    except Exception as e:
        return f"Error: {e}"


def agent_example():
    """Agent example with tools and automatic metering."""
    print("=" * 70)
    print("LangChain Middleware - Agent Example (LangGraph)")
    print("=" * 70)
    print()

    openai_key = os.getenv("OPENAI_API_KEY")
    revenium_key = os.getenv("REVENIUM_METERING_API_KEY")

    if not openai_key:
        print("Error: OPENAI_API_KEY not set")
        return
    if not revenium_key:
        print("Error: REVENIUM_METERING_API_KEY not set")
        return

    print(f"  OpenAI API Key: {'*' * (len(openai_key) - 4)}{openai_key[-4:]}")
    print(f"  Revenium API Key: {'*' * (len(revenium_key) - 4)}{revenium_key[-4:]}")
    print()

    # Example 1: Agent with tool calls
    print("=== Example 1: Agent with Tool Calls ===")
    print()

    handler = ReveniumCallbackHandler(
        trace_id=f"agent-{int(time.time() * 1000)}",
        trace_name="weather_calculator_agent",
        agent_name="assistant",
    )

    llm = ChatOpenAI(model="gpt-4o-mini")
    tools = [get_weather, calculate]
    agent = create_react_agent(llm, tools)

    print("  Query: What's the weather in Tokyo? Also, what is 15 * 23?")
    result = agent.invoke(
        {"messages": [HumanMessage(content="What's the weather in Tokyo? Also, what is 15 * 23?")]},
        config={"callbacks": [handler]},
    )

    final_message = result["messages"][-1]
    print(f"  Agent: {final_message.content}")
    print()
    print("  The agent made multiple LLM calls (decide tool -> process result)")
    print("  Each call is metered with parent-child transaction IDs")
    print()

    # Example 2: Multi-turn agent conversation
    print("=== Example 2: Multi-Turn Agent Conversation ===")
    print()

    handler = ReveniumCallbackHandler(
        trace_id=f"conversation-{int(time.time() * 1000)}",
        trace_name="multi_turn_agent",
        agent_name="conversational_assistant",
    )

    llm = ChatOpenAI(model="gpt-4o-mini")
    agent = create_react_agent(llm, tools)

    messages = []
    queries = [
        "What's the weather in New York?",
        "How about Paris?",
        "What's the temperature difference between them? Use the calculator.",
    ]

    for query in queries:
        print(f"  User: {query}")
        messages.append(HumanMessage(content=query))

        result = agent.invoke(
            {"messages": messages},
            config={"callbacks": [handler]},
        )

        new_messages = result["messages"][len(messages):]
        messages.extend(new_messages)

        assistant_response = new_messages[-1].content
        print(f"  Agent: {assistant_response}")
        print()

    print("  All turns metered under the same trace_id for grouping")
    print()

    # Summary
    print("=" * 70)
    print("Summary:")
    print("  - Agent LLM calls are automatically metered")
    print("  - Tool calls are tracked (no token metering for tools)")
    print("  - Parent-child transaction IDs link agent reasoning steps")
    print("  - Multi-turn conversations share a trace_id")
    print("  - Check your Revenium dashboard to see the agent trace")
    print("=" * 70)


if __name__ == "__main__":
    agent_example()
