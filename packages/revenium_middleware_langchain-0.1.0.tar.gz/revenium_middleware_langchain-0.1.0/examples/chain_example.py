#!/usr/bin/env python3
"""
LangChain Chain Example

Shows how to use the Revenium callback handler with LangChain chains
(prompt | llm | parser). Demonstrates automatic trace context propagation
through chain pipelines.

Prerequisites:
    Create a .env file with:
        REVENIUM_METERING_API_KEY="hak_your_key"
        OPENAI_API_KEY="sk-your_key"
        REVENIUM_LOG_LEVEL=DEBUG
"""

import os
import time
from dotenv import load_dotenv

load_dotenv()

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from revenium_middleware_langchain import ReveniumCallbackHandler


def chain_example():
    """Chain example with prompt | llm | parser."""
    print("=" * 70)
    print("LangChain Middleware - Chain Example")
    print("=" * 70)
    print()

    openai_key = os.getenv("OPENAI_API_KEY")
    revenium_key = os.getenv("REVENIUM_METERING_API_KEY")

    if not openai_key:
        print("Error: OPENAI_API_KEY not set")
        return
    if not revenium_key:
        print("Error: REVENIUM_METERING_API_KEY not set")
        return

    print(f"  OpenAI API Key: {'*' * (len(openai_key) - 4)}{openai_key[-4:]}")
    print(f"  Revenium API Key: {'*' * (len(revenium_key) - 4)}{revenium_key[-4:]}")
    print()

    # Example 1: Simple chain (prompt | llm | parser)
    print("=== Example 1: Simple Chain (prompt | llm | parser) ===")
    print()

    handler = ReveniumCallbackHandler(
        trace_id=f"chain-{int(time.time() * 1000)}",
        trace_name="simple_chain",
        agent_name="chain_agent",
    )

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful assistant that explains topics concisely."),
        ("user", "Explain {topic} in exactly two sentences."),
    ])

    llm = ChatOpenAI(model="gpt-4o-mini")
    parser = StrOutputParser()

    chain = prompt | llm | parser

    result = chain.invoke(
        {"topic": "quantum computing"},
        config={"callbacks": [handler]},
    )
    print(f"  Topic: quantum computing")
    print(f"  Response: {result}")
    print("  Chain metered with parent-child trace context")
    print()

    # Example 2: Multiple chain invocations under one trace
    print("=== Example 2: Multiple Chain Invocations (Same Trace) ===")
    print()

    handler = ReveniumCallbackHandler(
        trace_id=f"multi-chain-{int(time.time() * 1000)}",
        trace_name="multi_chain_workflow",
        agent_name="chain_agent",
    )

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a {role}. Keep answers under 20 words."),
        ("user", "{question}"),
    ])

    llm = ChatOpenAI(model="gpt-4o-mini")
    chain = prompt | llm | parser

    invocations = [
        {"role": "historian", "question": "When was the internet invented?"},
        {"role": "scientist", "question": "What causes rain?"},
        {"role": "chef", "question": "What makes bread rise?"},
    ]

    for inv in invocations:
        result = chain.invoke(inv, config={"callbacks": [handler]})
        print(f"  [{inv['role']}] {inv['question']}")
        print(f"  Answer: {result}")
        print()

    print("  All 3 chain calls grouped under the same trace_id")
    print()

    # Summary
    print("=" * 70)
    print("Summary:")
    print("  - Chains (prompt | llm | parser) are automatically metered")
    print("  - Pass handler via config={'callbacks': [handler]} at invoke time")
    print("  - Parent-child relationships are tracked through the chain")
    print("  - Multiple invocations can share a trace_id")
    print("=" * 70)


if __name__ == "__main__":
    chain_example()
