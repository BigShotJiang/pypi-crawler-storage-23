#!/usr/bin/env python3
"""
LangChain Prompt Capture Example

Shows how to enable prompt capture to store prompts and responses
in Revenium for analytics and debugging.

Prerequisites:
    Create a .env file with:
        REVENIUM_METERING_API_KEY="hak_your_key"
        OPENAI_API_KEY="sk-your_key"
        REVENIUM_CAPTURE_PROMPTS=true
        REVENIUM_LOG_LEVEL=DEBUG
"""

import os
import time
from dotenv import load_dotenv

load_dotenv()

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from revenium_middleware_langchain import ReveniumCallbackHandler, ReveniumConfig


def prompt_capture_example():
    """Demonstrate prompt capture functionality."""
    print("=" * 70)
    print("LangChain Middleware - Prompt Capture Example")
    print("=" * 70)
    print()

    openai_key = os.getenv("OPENAI_API_KEY")
    revenium_key = os.getenv("REVENIUM_METERING_API_KEY")

    if not openai_key:
        print("Error: OPENAI_API_KEY not set")
        return
    if not revenium_key:
        print("Error: REVENIUM_METERING_API_KEY not set")
        return

    capture_enabled = os.getenv("REVENIUM_CAPTURE_PROMPTS", "false").lower() in (
        "true", "1", "yes", "on"
    )

    print(f"  OpenAI API Key: {'*' * (len(openai_key) - 4)}{openai_key[-4:]}")
    print(f"  Revenium API Key: {'*' * (len(revenium_key) - 4)}{revenium_key[-4:]}")
    print(f"  Prompt Capture: {'ENABLED' if capture_enabled else 'DISABLED'}")
    print()

    # Example 1: Without prompt capture (explicitly disabled)
    print("=== Example 1: Prompt Capture Disabled ===")
    print()

    config_no_capture = ReveniumConfig(
        api_key=revenium_key,
        base_url=os.getenv("REVENIUM_METERING_BASE_URL", "https://api.revenium.ai"),
        log_level=os.getenv("REVENIUM_LOG_LEVEL", "INFO"),
        capture_prompts=False,
    )

    handler = ReveniumCallbackHandler(
        config=config_no_capture,
        trace_id=f"no-capture-{int(time.time() * 1000)}",
        agent_name="no_capture_agent",
    )

    llm = ChatOpenAI(model="gpt-4o-mini", callbacks=[handler])
    response = llm.invoke("What is the capital of Spain?")
    print(f"  Response: {response.content}")
    print("  Tokens and timing tracked, but prompts NOT captured")
    print()

    # Example 2: With prompt capture enabled via config
    print("=== Example 2: Prompt Capture Enabled (Programmatic) ===")
    print()
    print("  You can enable capture programmatically, regardless of the env var:")
    print()

    config = ReveniumConfig(
        api_key=revenium_key,
        base_url=os.getenv("REVENIUM_METERING_BASE_URL", "https://api.revenium.ai"),
        log_level=os.getenv("REVENIUM_LOG_LEVEL", "INFO"),
        capture_prompts=True,
    )

    handler = ReveniumCallbackHandler(
        config=config,
        trace_id=f"capture-on-{int(time.time() * 1000)}",
        agent_name="capture_agent",
    )

    llm = ChatOpenAI(model="gpt-4o-mini", callbacks=[handler])

    response = llm.invoke([
        SystemMessage(content="You are a geography expert."),
        HumanMessage(content="What is the capital of Japan?"),
    ])
    print(f"  Response: {response.content}")
    print("  Prompts and response captured and sent to Revenium")
    print()

    # Example 3: Multi-message conversation with capture
    print("=== Example 3: Multi-Message Conversation with Capture ===")
    print()

    handler = ReveniumCallbackHandler(
        config=config,
        trace_id=f"conversation-capture-{int(time.time() * 1000)}",
        agent_name="conversation_agent",
    )

    llm = ChatOpenAI(model="gpt-4o-mini", callbacks=[handler])

    messages = [
        SystemMessage(content="You are a helpful math tutor. Be concise."),
        HumanMessage(content="What is the Pythagorean theorem?"),
    ]

    response = llm.invoke(messages)
    print(f"  User: What is the Pythagorean theorem?")
    print(f"  Assistant: {response.content}")
    print()
    print("  Full message history (system + user + response) captured")
    print()

    # Summary
    print("=" * 70)
    print("Summary:")
    print("  - Set REVENIUM_CAPTURE_PROMPTS=true or config.capture_prompts=True")
    print("  - System prompts, user messages, and responses are captured")
    print("  - SECURITY: Prompts may contain sensitive data")
    print("  - Only enable in trusted environments")
    print("  - Check your Revenium dashboard to see captured prompts")
    print("=" * 70)


if __name__ == "__main__":
    prompt_capture_example()
