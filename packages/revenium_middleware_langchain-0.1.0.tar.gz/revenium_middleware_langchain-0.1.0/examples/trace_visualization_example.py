#!/usr/bin/env python3
"""
LangChain Trace Visualization Example

Shows how to use tracing fields for:
- Distributed tracing with parent_transaction_id
- Multi-step workflows under a single trace
- Organization and subscriber metadata
- Linking sequential agent calls

Prerequisites:
    pip install langgraph

    Create a .env file with:
        REVENIUM_METERING_API_KEY="hak_your_key"
        OPENAI_API_KEY="sk-your_key"
        REVENIUM_LOG_LEVEL=DEBUG
"""

import os
import time
from dotenv import load_dotenv

load_dotenv()

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from revenium_middleware_langchain import ReveniumCallbackHandler, ReveniumConfig


def example_1_multi_step_workflow():
    """Multi-step workflow with parent-child transaction linking."""
    print("=== Example 1: Multi-Step Workflow ===")
    print()

    workflow_id = f"workflow-{int(time.time() * 1000)}"

    # Step 1: Research
    print("  Step 1: Research")
    handler_1 = ReveniumCallbackHandler(
        trace_id=workflow_id,
        trace_name="document_analysis",
        agent_name="researcher",
    )

    llm = ChatOpenAI(model="gpt-4o-mini")
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a research assistant. Be concise."),
        ("user", "List 3 key facts about {topic}."),
    ])
    chain = prompt | llm | StrOutputParser()

    result_1 = chain.invoke(
        {"topic": "renewable energy"},
        config={"callbacks": [handler_1]},
    )
    print(f"  Research: {result_1[:100]}...")
    parent_txn = handler_1.last_transaction_id
    print(f"  Transaction ID: {parent_txn}")
    print()

    # Step 2: Summarize (child of step 1)
    print("  Step 2: Summarize (linked to Step 1)")
    handler_2 = ReveniumCallbackHandler(
        trace_id=workflow_id,
        trace_name="document_analysis",
        agent_name="summarizer",
        parent_transaction_id=parent_txn,
    )

    llm = ChatOpenAI(model="gpt-4o-mini")
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a summarizer. Write exactly one sentence."),
        ("user", "Summarize: {text}"),
    ])
    chain = prompt | llm | StrOutputParser()

    result_2 = chain.invoke(
        {"text": result_1},
        config={"callbacks": [handler_2]},
    )
    print(f"  Summary: {result_2}")
    child_txn = handler_2.last_transaction_id
    print(f"  Transaction ID: {child_txn} -> parent: {parent_txn}")
    print()

    print(f"  Trace ID: {workflow_id}")
    print(f"  Both steps linked in the Revenium dashboard")
    print()


def example_2_subscriber_tracking():
    """Track different subscribers/users making LLM calls."""
    print("=== Example 2: Subscriber Tracking ===")
    print()

    revenium_key = os.getenv("REVENIUM_METERING_API_KEY")
    base_url = os.getenv("REVENIUM_METERING_BASE_URL", "https://api.revenium.ai")

    users = [
        {"id": "user-001", "email": "alice@company.com"},
        {"id": "user-002", "email": "bob@company.com"},
    ]

    for user in users:
        from revenium_middleware_langchain.config import SubscriberConfig

        config = ReveniumConfig(
            api_key=revenium_key,
            base_url=base_url,
            log_level=os.getenv("REVENIUM_LOG_LEVEL", "INFO"),
            environment="production",
            organization_name="AcmeCorp",
            product_name="customer-chatbot",
            subscriber=SubscriberConfig(
                id=user["id"],
                email=user["email"],
            ),
        )

        handler = ReveniumCallbackHandler(
            config=config,
            trace_id=f"user-{user['id']}-{int(time.time() * 1000)}",
            trace_name=f"Session for {user['email']}",
            agent_name="support_agent",
        )

        llm = ChatOpenAI(model="gpt-4o-mini")
        response = llm.invoke(
            f"Hello, my user ID is {user['id']}. Say hi back briefly.",
            config={"callbacks": [handler]},
        )
        print(f"  {user['email']}: {response.content}")

    print()
    print("  Each call tagged with subscriber info for per-user analytics")
    print()


def example_3_organization_metadata():
    """Demonstrate organization, product, and environment metadata."""
    print("=== Example 3: Organization Metadata ===")
    print()

    revenium_key = os.getenv("REVENIUM_METERING_API_KEY")
    base_url = os.getenv("REVENIUM_METERING_BASE_URL", "https://api.revenium.ai")

    config = ReveniumConfig(
        api_key=revenium_key,
        base_url=base_url,
        log_level=os.getenv("REVENIUM_LOG_LEVEL", "INFO"),
        environment="staging",
        organization_name="AcmeCorp",
        subscription_id="sub_enterprise_001",
        product_name="internal-knowledge-base",
    )

    handler = ReveniumCallbackHandler(
        config=config,
        trace_id=f"org-meta-{int(time.time() * 1000)}",
        trace_name="knowledge_base_query",
        agent_name="kb_agent",
    )

    llm = ChatOpenAI(model="gpt-4o-mini", callbacks=[handler])
    response = llm.invoke("What is a knowledge base? One sentence.")

    print(f"  Response: {response.content}")
    print()
    print("  Metering data includes:")
    print("    organization_name: AcmeCorp")
    print("    product_name: internal-knowledge-base")
    print("    subscription_id: sub_enterprise_001")
    print("    environment: staging")
    print()


def trace_visualization_example():
    """Run all trace visualization examples."""
    print("=" * 70)
    print("LangChain Middleware - Trace Visualization Examples")
    print("=" * 70)
    print()

    openai_key = os.getenv("OPENAI_API_KEY")
    revenium_key = os.getenv("REVENIUM_METERING_API_KEY")

    if not openai_key:
        print("Error: OPENAI_API_KEY not set")
        return
    if not revenium_key:
        print("Error: REVENIUM_METERING_API_KEY not set")
        return

    print(f"  OpenAI API Key: {'*' * (len(openai_key) - 4)}{openai_key[-4:]}")
    print(f"  Revenium API Key: {'*' * (len(revenium_key) - 4)}{revenium_key[-4:]}")
    print()

    example_1_multi_step_workflow()
    example_2_subscriber_tracking()
    example_3_organization_metadata()

    print("=" * 70)
    print("Key Takeaways:")
    print("  1. Use trace_id to group related calls into a single trace")
    print("  2. Use parent_transaction_id to link sequential agent steps")
    print("  3. Use SubscriberConfig to track per-user usage")
    print("  4. Use organization/product/environment for business context")
    print("  5. Check your Revenium dashboard to see trace visualizations")
    print("=" * 70)


if __name__ == "__main__":
    trace_visualization_example()
