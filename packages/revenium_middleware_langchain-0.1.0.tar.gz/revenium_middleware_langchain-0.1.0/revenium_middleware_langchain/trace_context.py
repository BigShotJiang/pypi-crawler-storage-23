"""Trace context management for parent-child relationship tracking."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Optional
from uuid import UUID


@dataclass
class TraceInfo:
    """Information about a single trace entry."""

    run_id: UUID
    trace_id: Optional[str] = None
    trace_name: Optional[str] = None
    transaction_id: Optional[str] = None
    parent_run_id: Optional[UUID] = None
    start_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    event_type: Optional[str] = None  # llm, chain, tool, agent
    model_name: Optional[str] = None  # LLM model name if available
    class_name: Optional[str] = None  # LLM class name (e.g., ChatOpenAI)
    input_prompt: Optional[str] = None  # Input prompt/messages for logging


class TraceContextManager:
    """Thread-safe manager for trace context and parent-child relationships.

    This class tracks the hierarchy of LangChain runs (LLM calls, chains, tools)
    to enable proper trace context propagation in metering payloads.
    """

    def __init__(self) -> None:
        """Initialize the trace context manager."""
        self._traces: Dict[UUID, TraceInfo] = {}
        self._lock = threading.RLock()

    def register_trace(
        self,
        run_id: UUID,
        trace_id: Optional[str] = None,
        trace_name: Optional[str] = None,
        transaction_id: Optional[str] = None,
        event_type: Optional[str] = None,
        model_name: Optional[str] = None,
        class_name: Optional[str] = None,
        input_prompt: Optional[str] = None,
    ) -> TraceInfo:
        """Register a new trace entry.

        Args:
            run_id: The unique run ID from LangChain.
            trace_id: Optional trace ID for grouping related operations.
            trace_name: Optional name for the trace.
            transaction_id: Optional transaction ID for this specific operation.
            event_type: Type of event (llm, chain, tool, agent).
            model_name: Optional model name for LLM calls.
            class_name: Optional LLM class name (e.g., ChatOpenAI).
            input_prompt: Optional input prompt/messages for logging.

        Returns:
            The created TraceInfo object.
        """
        with self._lock:
            info = TraceInfo(
                run_id=run_id,
                trace_id=trace_id,
                trace_name=trace_name,
                transaction_id=transaction_id,
                event_type=event_type,
                model_name=model_name,
                class_name=class_name,
                input_prompt=input_prompt,
            )
            self._traces[run_id] = info
            return info

    def register_parent(self, child_run_id: UUID, parent_run_id: UUID) -> None:
        """Register a parent-child relationship between runs.

        Args:
            child_run_id: The child run ID.
            parent_run_id: The parent run ID.
        """
        with self._lock:
            if child_run_id in self._traces:
                self._traces[child_run_id].parent_run_id = parent_run_id

    def get_trace_info(self, run_id: UUID) -> Optional[TraceInfo]:
        """Get trace info for a run, inheriting from parent chain if needed.

        This method walks up the parent chain to inherit trace_id and trace_name
        if they are not set on the current trace.

        Args:
            run_id: The run ID to look up.

        Returns:
            TraceInfo with inherited values, or None if not found.
        """
        with self._lock:
            info = self._traces.get(run_id)
            if info is None:
                return None

            # If we have all the info we need, return it
            if info.trace_id is not None and info.trace_name is not None:
                return info

            # Walk up the parent chain to inherit values
            inherited_trace_id = info.trace_id
            inherited_trace_name = info.trace_name
            current = info

            while current.parent_run_id is not None:
                parent = self._traces.get(current.parent_run_id)
                if parent is None:
                    break

                if inherited_trace_id is None and parent.trace_id is not None:
                    inherited_trace_id = parent.trace_id
                if inherited_trace_name is None and parent.trace_name is not None:
                    inherited_trace_name = parent.trace_name

                # If we've found both, stop searching
                if inherited_trace_id is not None and inherited_trace_name is not None:
                    break

                current = parent

            # Create a new TraceInfo with inherited values (don't mutate original)
            return TraceInfo(
                run_id=info.run_id,
                trace_id=inherited_trace_id,
                trace_name=inherited_trace_name,
                transaction_id=info.transaction_id,
                parent_run_id=info.parent_run_id,
                start_time=info.start_time,
                event_type=info.event_type,
                model_name=info.model_name,
                class_name=info.class_name,
                input_prompt=info.input_prompt,
            )

    def get_model_name(self, run_id: UUID) -> Optional[str]:
        """Get the model name for a run.

        Args:
            run_id: The run ID to look up.

        Returns:
            The model name, or None if not found.
        """
        with self._lock:
            info = self._traces.get(run_id)
            return info.model_name if info else None

    def get_class_name(self, run_id: UUID) -> Optional[str]:
        """Get the LLM class name for a run.

        Args:
            run_id: The run ID to look up.

        Returns:
            The LLM class name, or None if not found.
        """
        with self._lock:
            info = self._traces.get(run_id)
            return info.class_name if info else None

    def get_input_prompt(self, run_id: UUID) -> Optional[str]:
        """Get the input prompt for a run.

        Args:
            run_id: The run ID to look up.

        Returns:
            The input prompt, or None if not found.
        """
        with self._lock:
            info = self._traces.get(run_id)
            return info.input_prompt if info else None

    def get_parent_transaction_id(self, run_id: UUID) -> Optional[str]:
        """Get the transaction ID of the parent run.

        Args:
            run_id: The run ID to look up the parent for.

        Returns:
            The parent's transaction ID, or None if no parent or no transaction ID.
        """
        with self._lock:
            info = self._traces.get(run_id)
            if info is None or info.parent_run_id is None:
                return None

            parent = self._traces.get(info.parent_run_id)
            if parent is None:
                return None

            return parent.transaction_id

    def get_start_time(self, run_id: UUID) -> Optional[datetime]:
        """Get the start time for a run.

        Args:
            run_id: The run ID to look up.

        Returns:
            The start time, or None if not found.
        """
        with self._lock:
            info = self._traces.get(run_id)
            return info.start_time if info else None

    def update_transaction_id(self, run_id: UUID, transaction_id: str) -> None:
        """Update the transaction ID for a run.

        Args:
            run_id: The run ID to update.
            transaction_id: The new transaction ID.
        """
        with self._lock:
            if run_id in self._traces:
                self._traces[run_id].transaction_id = transaction_id

    def unregister_trace(self, run_id: UUID) -> Optional[TraceInfo]:
        """Unregister a trace entry and clean up.

        Args:
            run_id: The run ID to unregister.

        Returns:
            The removed TraceInfo, or None if not found.
        """
        with self._lock:
            return self._traces.pop(run_id, None)

    def clear(self) -> None:
        """Clear all trace entries."""
        with self._lock:
            self._traces.clear()

    def __len__(self) -> int:
        """Return the number of registered traces."""
        with self._lock:
            return len(self._traces)
