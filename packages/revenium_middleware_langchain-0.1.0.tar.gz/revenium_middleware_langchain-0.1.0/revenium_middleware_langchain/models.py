"""Data models for Revenium metering payloads."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional


# Mapping of LangChain finish reasons to Revenium stop reason enum values
STOP_REASON_MAP: Dict[str, str] = {
    "stop": "STOP",
    "end_turn": "STOP",
    "length": "MAX_TOKENS",
    "max_tokens": "MAX_TOKENS",
    "tool_calls": "TOOL_USE",
    "function_call": "TOOL_USE",
    "content_filter": "CONTENT_FILTERED",
    "error": "ERROR",
}


def map_stop_reason(langchain_reason: Optional[str]) -> Optional[str]:
    """Map LangChain finish reason to Revenium stop reason enum.

    Args:
        langchain_reason: The finish reason from LangChain.

    Returns:
        The corresponding Revenium stop reason, or None if not mapped.
    """
    if langchain_reason is None:
        return None
    return STOP_REASON_MAP.get(langchain_reason.lower(), "OTHER")


@dataclass
class MeteringPayload:
    """Payload for the Revenium AI completions metering API.

    This matches the /meter/v2/ai/completions endpoint schema.
    """

    # Token counts
    input_token_count: Optional[int] = None
    output_token_count: Optional[int] = None
    total_token_count: Optional[int] = None

    # Timing (ISO 8601 format strings)
    request_time: Optional[str] = None
    completion_start_time: Optional[str] = None
    response_time: Optional[str] = None
    request_duration: Optional[int] = None  # milliseconds

    # Model information
    model: Optional[str] = None
    provider: Optional[str] = None
    stop_reason: Optional[str] = None
    is_streamed: bool = False

    # Trace information
    transaction_id: Optional[str] = None
    trace_id: Optional[str] = None
    parent_transaction_id: Optional[str] = None
    trace_name: Optional[str] = None
    trace_type: Optional[str] = None

    # Metadata
    agent: Optional[str] = None
    environment: Optional[str] = None
    organization_name: Optional[str] = None
    subscription_id: Optional[str] = None
    product_name: Optional[str] = None

    # Subscriber info
    subscriber_id: Optional[str] = None
    subscriber_email: Optional[str] = None
    subscriber_credential: Optional[str] = None

    # Prompts (optional, for debugging)
    prompt: Optional[str] = None
    response: Optional[str] = None

    # Additional metadata
    metadata: Dict[str, Any] = field(default_factory=dict)


def format_timestamp(dt: datetime) -> str:
    """Format a datetime as an ISO 8601 string.

    Args:
        dt: The datetime to format.

    Returns:
        ISO 8601 formatted string.
    """
    return dt.isoformat()
