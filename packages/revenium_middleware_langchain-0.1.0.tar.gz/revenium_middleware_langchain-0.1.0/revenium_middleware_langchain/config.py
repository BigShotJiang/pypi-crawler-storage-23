"""Configuration management for Revenium LangChain middleware."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SubscriberConfig:
    """Subscriber configuration for metering."""

    id: Optional[str] = None
    email: Optional[str] = None
    credential: Optional[str] = None


@dataclass
class ReveniumConfig:
    """Configuration for the Revenium callback handler.

    Attributes:
        api_key: Revenium API key (must start with 'hak_')
        base_url: Revenium API base URL
        environment: Environment name (e.g., 'production', 'staging')
        organization_name: Organization name for metering
        subscription_id: Subscription ID for metering
        product_name: Product name for metering
        subscriber: Subscriber configuration
        log_level: Log level (e.g., 'DEBUG', 'INFO', 'WARNING')
        capture_prompts: Capture prompts and responses (use with caution in production)
    """

    api_key: str
    base_url: str = "https://api.revenium.ai"
    environment: Optional[str] = None
    organization_name: Optional[str] = None
    subscription_id: Optional[str] = None
    product_name: Optional[str] = None
    subscriber: SubscriberConfig = field(default_factory=SubscriberConfig)
    log_level: str = "INFO"
    capture_prompts: bool = False

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        self.validate()

    def validate(self) -> None:
        """Validate the configuration.

        Raises:
            ValueError: If the API key is missing or invalid.
        """
        if not self.api_key:
            raise ValueError("REVENIUM_METERING_API_KEY is required")
        if not self.api_key.startswith("hak_"):
            raise ValueError("REVENIUM_METERING_API_KEY must start with 'hak_'")

    @property
    def is_debug(self) -> bool:
        """Check if debug logging is enabled."""
        return self.log_level.upper() == "DEBUG"

    @classmethod
    def from_env(cls) -> ReveniumConfig:
        """Create configuration from environment variables.

        Environment Variables:
            REVENIUM_METERING_API_KEY: Required API key
            REVENIUM_METERING_BASE_URL: API base URL (default: https://api.revenium.ai)
            REVENIUM_LOG_LEVEL: Log level (default: INFO)
            REVENIUM_CAPTURE_PROMPTS: Capture prompts (true/false)
            REVENIUM_ENVIRONMENT: Environment name
            REVENIUM_ORGANIZATION_NAME: Organization name
            REVENIUM_SUBSCRIPTION_ID: Subscription ID
            REVENIUM_PRODUCT_NAME: Product name
            REVENIUM_SUBSCRIBER_ID: Subscriber ID
            REVENIUM_SUBSCRIBER_EMAIL: Subscriber email
            REVENIUM_SUBSCRIBER_CREDENTIAL: Subscriber credential

        Returns:
            ReveniumConfig instance configured from environment variables.

        Raises:
            ValueError: If required environment variables are missing.
        """
        api_key = os.environ.get("REVENIUM_METERING_API_KEY", "")

        subscriber = SubscriberConfig(
            id=os.environ.get("REVENIUM_SUBSCRIBER_ID"),
            email=os.environ.get("REVENIUM_SUBSCRIBER_EMAIL"),
            credential=os.environ.get("REVENIUM_SUBSCRIBER_CREDENTIAL"),
        )

        return cls(
            api_key=api_key,
            base_url=os.environ.get("REVENIUM_METERING_BASE_URL", "https://api.revenium.ai"),
            environment=os.environ.get("REVENIUM_ENVIRONMENT"),
            organization_name=os.environ.get("REVENIUM_ORGANIZATION_NAME"),
            subscription_id=os.environ.get("REVENIUM_SUBSCRIPTION_ID"),
            product_name=os.environ.get("REVENIUM_PRODUCT_NAME"),
            subscriber=subscriber,
            log_level=os.environ.get("REVENIUM_LOG_LEVEL", "INFO"),
            capture_prompts=os.environ.get("REVENIUM_CAPTURE_PROMPTS", "false").lower() in ("true", "1", "yes", "on"),
        )
