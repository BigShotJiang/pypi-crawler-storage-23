"""Revenium middleware for LangChain - AI metering and usage tracking.

This package provides a LangChain callback handler that sends metering data
to Revenium's AI metering API. It tracks LLM calls (tokens, timing, model info),
chains, tools, and agent actions.

Example:
    >>> from langchain_openai import ChatOpenAI
    >>> from revenium_middleware_langchain import ReveniumCallbackHandler
    >>>
    >>> handler = ReveniumCallbackHandler(
    ...     trace_id="session-123",
    ...     agent_name="support_agent"
    ... )
    >>> llm = ChatOpenAI(model="gpt-4", callbacks=[handler])
    >>> response = llm.invoke("Hello!")
"""

import logging

from .config import ReveniumConfig, SubscriberConfig
from .handler import AsyncReveniumCallbackHandler, ReveniumCallbackHandler
from .models import MeteringPayload, map_stop_reason
from .trace_context import TraceContextManager, TraceInfo

__version__ = "0.1.0"

__all__ = [
    # Main handler classes
    "ReveniumCallbackHandler",
    "AsyncReveniumCallbackHandler",
    # Configuration
    "ReveniumConfig",
    "SubscriberConfig",
    # Models
    "MeteringPayload",
    "map_stop_reason",
    # Trace context
    "TraceContextManager",
    "TraceInfo",
]

# Configure logging
logging.getLogger(__name__).addHandler(logging.NullHandler())
