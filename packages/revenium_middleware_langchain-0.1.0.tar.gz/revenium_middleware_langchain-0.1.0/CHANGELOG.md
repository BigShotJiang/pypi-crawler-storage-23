# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-17

### Added
- Initial release of Revenium Middleware for LangChain
- `ReveniumCallbackHandler` for synchronous LangChain operations
- `AsyncReveniumCallbackHandler` for async LangChain operations
- Automatic token count extraction from LLM responses
- Multi-provider support: OpenAI, Anthropic, Google, AWS Bedrock, Azure OpenAI, Cohere, HuggingFace, Ollama
- Request timing (start time, response time, duration in milliseconds)
- Trace context management with parent-child transaction tracking
- Chain and agent lifecycle tracking
- Tool invocation tracking
- Optional prompt and response capture
- Thread-safe `TraceContextManager` for concurrent operations
- Flexible configuration via environment variables or `ReveniumConfig`
- Comprehensive test suite
- Usage examples for basic LLM, chains, and agents

[0.1.0]: https://github.com/revenium/revenium-middleware-langchain/releases/tag/v0.1.0
