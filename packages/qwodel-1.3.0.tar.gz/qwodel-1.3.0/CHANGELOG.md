# CHANGELOG

<!-- version list -->

## v1.3.0 (2026-02-25)


## v1.2.0 (2026-02-25)

### Features

- Updated Licenses
  ([`6e47bd5`](https://github.com/Qwodel/qwodel/commit/6e47bd58a24ad445b322d59ffa2d0752f25ed055))


## v1.1.0 (2026-02-25)

### Features

- Updated Licenses
  ([`a5c1c2d`](https://github.com/Qwodel/qwodel/commit/a5c1c2de3ec254d7f4b1bfd59331cfa6c21c786a))


## v1.0.0 (2026-02-20)

- Initial Release
