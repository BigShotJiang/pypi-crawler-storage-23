"""CLI module for sarathy."""
