"""User interface command parsers."""


def add_user_interface_parsers(subparsers):
    """Add user interface command parsers (for human users)"""
    pass
