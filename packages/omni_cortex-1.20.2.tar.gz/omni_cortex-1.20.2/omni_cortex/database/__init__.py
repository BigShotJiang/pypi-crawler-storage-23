"""Database layer for Omni Cortex - SQLite with FTS5."""

from .connection import close_connection, execute_with_retry, get_connection, init_database
from .schema import SCHEMA_VERSION, get_schema_sql
from .sync import (
    delete_memory_from_global,
    get_global_stats,
    search_global_memories,
    sync_all_project_memories,
    sync_memory_to_global,
)

__all__ = [
    "get_connection",
    "init_database",
    "close_connection",
    "SCHEMA_VERSION",
    "get_schema_sql",
    "sync_memory_to_global",
    "delete_memory_from_global",
    "search_global_memories",
    "get_global_stats",
    "sync_all_project_memories",
    "execute_with_retry",
]
