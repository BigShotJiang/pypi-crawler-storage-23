"""Memory relationship model and operations."""

import json
import re
import sqlite3
from typing import Optional, Union, Any
from pydantic import BaseModel, Field, ConfigDict

from ..utils.ids import generate_relationship_id
from ..utils.timestamps import now_iso


def extract_memory_ids(text: str) -> set[str]:
    """Extract memory IDs from text content.

    Finds all mem_XXXX_YYYY patterns where XXXX is 13 digits and YYYY is 8 hex chars.

    Args:
        text: Text to scan for memory ID references

    Returns:
        Set of unique memory IDs found
    """
    pattern = r'mem_\d{13}_[0-9a-f]{8}'
    return set(re.findall(pattern, text))


class MemoryRelationship(BaseModel):
    """Memory relationship model."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
    )

    id: str
    source_memory_id: str
    target_memory_id: str
    relationship_type: str  # related_to, supersedes, derived_from, contradicts
    strength: float = 1.0
    created_at: str
    metadata: Optional[dict[str, Any]] = None


class LinkMemoriesInput(BaseModel):
    """Input for linking two memories."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
    )

    source_id: str = Field(..., description="Source memory ID")
    target_id: str = Field(..., description="Target memory ID")
    relationship_type: str = Field(
        ...,
        description="Relationship type: related_to, supersedes, derived_from, contradicts",
    )
    strength: float = Field(1.0, description="Relationship strength 0.0-1.0", ge=0.0, le=1.0)


VALID_RELATIONSHIP_TYPES = ["related_to", "supersedes", "derived_from", "contradicts"]


def create_relationship(
    conn: sqlite3.Connection,
    source_id: str,
    target_id: str,
    relationship_type: str,
    strength: float = 1.0,
) -> Union[MemoryRelationship, dict, None]:
    """Create a relationship between two memories.

    Args:
        conn: Database connection
        source_id: Source memory ID
        target_id: Target memory ID
        relationship_type: Type of relationship
        strength: Relationship strength

    Returns:
        Created relationship, error dict with missing_ids if memories not found, or None
    """
    if relationship_type not in VALID_RELATIONSHIP_TYPES:
        raise ValueError(f"Invalid relationship type: {relationship_type}")

    # Verify both memories exist
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM memories WHERE id IN (?, ?)", (source_id, target_id))
    found = {row[0] for row in cursor.fetchall()}
    missing = []
    if source_id not in found:
        missing.append(source_id)
    if target_id not in found:
        missing.append(target_id)
    if missing:
        return {"error": "not_found", "missing_ids": missing}

    rel_id = generate_relationship_id()
    now = now_iso()

    try:
        cursor.execute(
            """
            INSERT INTO memory_relationships (
                id, source_memory_id, target_memory_id,
                relationship_type, strength, created_at
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (rel_id, source_id, target_id, relationship_type, strength, now),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        # Relationship already exists
        cursor.execute(
            """
            SELECT * FROM memory_relationships
            WHERE source_memory_id = ? AND target_memory_id = ? AND relationship_type = ?
            """,
            (source_id, target_id, relationship_type),
        )
        row = cursor.fetchone()
        if row:
            return _row_to_relationship(row)
        return None

    return MemoryRelationship(
        id=rel_id,
        source_memory_id=source_id,
        target_memory_id=target_id,
        relationship_type=relationship_type,
        strength=strength,
        created_at=now,
    )


def get_relationships(
    conn: sqlite3.Connection,
    memory_id: str,
    as_source: bool = True,
    as_target: bool = True,
) -> list[MemoryRelationship]:
    """Get all relationships for a memory.

    Args:
        conn: Database connection
        memory_id: Memory ID
        as_source: Include relationships where memory is source
        as_target: Include relationships where memory is target

    Returns:
        List of relationships
    """
    cursor = conn.cursor()
    relationships = []

    if as_source:
        cursor.execute(
            "SELECT * FROM memory_relationships WHERE source_memory_id = ?",
            (memory_id,),
        )
        relationships.extend([_row_to_relationship(row) for row in cursor.fetchall()])

    if as_target:
        cursor.execute(
            "SELECT * FROM memory_relationships WHERE target_memory_id = ?",
            (memory_id,),
        )
        relationships.extend([_row_to_relationship(row) for row in cursor.fetchall()])

    return relationships


def delete_relationship(
    conn: sqlite3.Connection,
    source_id: str,
    target_id: str,
    relationship_type: Optional[str] = None,
) -> int:
    """Delete relationships between memories.

    Args:
        conn: Database connection
        source_id: Source memory ID
        target_id: Target memory ID
        relationship_type: Optional type filter

    Returns:
        Number of relationships deleted
    """
    cursor = conn.cursor()

    if relationship_type:
        cursor.execute(
            """
            DELETE FROM memory_relationships
            WHERE source_memory_id = ? AND target_memory_id = ? AND relationship_type = ?
            """,
            (source_id, target_id, relationship_type),
        )
    else:
        cursor.execute(
            """
            DELETE FROM memory_relationships
            WHERE source_memory_id = ? AND target_memory_id = ?
            """,
            (source_id, target_id),
        )

    conn.commit()
    return cursor.rowcount


def create_global_relationship(
    global_conn: sqlite3.Connection,
    source_id: str,
    source_project: str,
    target_id: str,
    target_project: str,
    relationship_type: str,
    strength: float = 1.0,
) -> Optional[MemoryRelationship]:
    """Create a cross-project relationship in the global database.

    Args:
        global_conn: Global database connection
        source_id: Source memory ID
        source_project: Normalized project path of source
        target_id: Target memory ID
        target_project: Normalized project path of target
        relationship_type: Type of relationship
        strength: Relationship strength

    Returns:
        Created relationship or None if duplicate
    """
    if relationship_type not in VALID_RELATIONSHIP_TYPES:
        raise ValueError(f"Invalid relationship type: {relationship_type}")

    rel_id = generate_relationship_id()
    now = now_iso()

    try:
        global_conn.execute(
            """
            INSERT INTO global_relationships (
                id, source_memory_id, source_project,
                target_memory_id, target_project,
                relationship_type, strength, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (rel_id, source_id, source_project, target_id, target_project,
             relationship_type, strength, now),
        )
        global_conn.commit()
    except sqlite3.IntegrityError:
        # Relationship already exists — return existing
        cursor = global_conn.cursor()
        cursor.execute(
            """
            SELECT * FROM global_relationships
            WHERE source_memory_id = ? AND target_memory_id = ? AND relationship_type = ?
            """,
            (source_id, target_id, relationship_type),
        )
        row = cursor.fetchone()
        if row:
            return _global_row_to_relationship(row)
        return None

    return MemoryRelationship(
        id=rel_id,
        source_memory_id=source_id,
        target_memory_id=target_id,
        relationship_type=relationship_type,
        strength=strength,
        created_at=now,
    )


def get_global_relationships(
    global_conn: sqlite3.Connection,
    memory_id: str,
) -> list[dict]:
    """Get cross-project relationships for a memory from the global DB.

    Returns dicts with extra source_project/target_project fields.

    Args:
        global_conn: Global database connection
        memory_id: Memory ID to look up

    Returns:
        List of relationship dicts with project context
    """
    cursor = global_conn.cursor()
    results = []

    cursor.execute(
        """
        SELECT * FROM global_relationships
        WHERE source_memory_id = ? OR target_memory_id = ?
        """,
        (memory_id, memory_id),
    )

    for row in cursor.fetchall():
        results.append({
            "id": row["id"],
            "source_memory_id": row["source_memory_id"],
            "source_project": row["source_project"],
            "target_memory_id": row["target_memory_id"],
            "target_project": row["target_project"],
            "relationship_type": row["relationship_type"],
            "strength": row["strength"],
            "created_at": row["created_at"],
        })

    return results


def _global_row_to_relationship(row: sqlite3.Row) -> MemoryRelationship:
    """Convert global_relationships row to MemoryRelationship object."""
    return MemoryRelationship(
        id=row["id"],
        source_memory_id=row["source_memory_id"],
        target_memory_id=row["target_memory_id"],
        relationship_type=row["relationship_type"],
        strength=row["strength"],
        created_at=row["created_at"],
    )


def _row_to_relationship(row: sqlite3.Row) -> MemoryRelationship:
    """Convert database row to MemoryRelationship object."""
    metadata = row["metadata"]
    if metadata and isinstance(metadata, str):
        metadata = json.loads(metadata)

    return MemoryRelationship(
        id=row["id"],
        source_memory_id=row["source_memory_id"],
        target_memory_id=row["target_memory_id"],
        relationship_type=row["relationship_type"],
        strength=row["strength"],
        created_at=row["created_at"],
        metadata=metadata,
    )
