# Demo Oil & Gas Corp - Knowledge Base Notes

Industry: oil_gas_upstream
ERP System: SAP S/4HANA

## Notes

