"""
Data Versioning MCP Tools - Phase 30 + Phase 3D-1 Consolidation.

Provides 3 unified MCP tools:
- version_manage: 6 actions (create, create_hierarchy, create_catalog_asset, get, list, stats)
- version_diff: 4 actions (diff, diff_latest, preview_rollback, rollback)
- version_meta: 2 actions (tag, search)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_version_manage,
    dispatch_version_diff,
    dispatch_version_meta,
    register_unified_versioning_tools,
)

logger = logging.getLogger(__name__)


def register_versioning_tools(mcp):
    """Register all versioning MCP tools."""

    # Register the 3 unified tools; returns manager instance
    manager = register_unified_versioning_tools(mcp)

    logger.info("Registered 3 versioning MCP tools")
    return manager
