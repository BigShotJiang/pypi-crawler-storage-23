"""
Data Versioning Module - Phase 30 + Phase 3D-1 Consolidation.
Unified version control for DataBridge objects.
"""
from .types import (
    VersionedObjectType,
    ChangeType,
    VersionBump,
    Version,
    VersionHistory,
    VersionDiff,
    VersionQuery,
    VersionStats,
    RollbackPreview,
)
from .version_store import VersionStore
from .version_manager import VersionManager
from .mcp_tools import register_versioning_tools
from .unified import (
    dispatch_version_manage,
    dispatch_version_diff,
    dispatch_version_meta,
    register_unified_versioning_tools,
    _MANAGE_ACTIONS,
    _DIFF_ACTIONS,
    _META_ACTIONS,
)

__all__ = [
    "VersionedObjectType",
    "ChangeType",
    "VersionBump",
    "Version",
    "VersionHistory",
    "VersionDiff",
    "VersionQuery",
    "VersionStore",
    "VersionManager",
    "register_versioning_tools",
    "dispatch_version_manage",
    "dispatch_version_diff",
    "dispatch_version_meta",
    "register_unified_versioning_tools",
    "_MANAGE_ACTIONS",
    "_DIFF_ACTIONS",
    "_META_ACTIONS",
]
