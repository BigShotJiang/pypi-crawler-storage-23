"""Security and tenancy utilities (Phase 6)."""

from .tenancy import TenantRegistry

__all__ = ["TenantRegistry"]
