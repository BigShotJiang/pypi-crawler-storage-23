"""Backward compatibility — canonical location is src.tenancy (Phase 2A)."""
from src.tenancy.registry import TenantRegistry

__all__ = ["TenantRegistry"]
