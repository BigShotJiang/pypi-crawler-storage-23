"""Snowflake lineage extraction plugin."""

from .mcp_tools import register_snowflake_lineage_tools

__all__ = ["register_snowflake_lineage_tools"]

