"""Faux Objects: Generate standard Snowflake objects that wrap Semantic Views for BI tool consumption."""

from .unified import (
    dispatch_faux_project,
    dispatch_semantic_view,
    register_unified_faux_tools,
    _PROJECT_ACTIONS,
    _SV_ACTIONS,
)
