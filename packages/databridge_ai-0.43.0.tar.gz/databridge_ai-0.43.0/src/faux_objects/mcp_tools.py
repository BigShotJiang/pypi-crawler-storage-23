"""
MCP tools for Faux Objects - Semantic View wrapper generation.

Provides 2 unified MCP tools:
- faux_project: 10 actions (create, list, get, delete, add_object, remove_object,
                generate_scripts, generate_bundle, generate_ddl, export)
- semantic_view: 8 actions (define, add_table, add_column, add_relationship,
                detect_sql, from_sql, to_project, convert)
"""

import logging

from .unified import (
    dispatch_faux_project,
    dispatch_semantic_view,
    register_unified_faux_tools,
)

logger = logging.getLogger(__name__)


def register_faux_objects_tools(mcp, data_dir: str = "data"):
    """Register all Faux Objects MCP tools."""

    # Register the 2 unified tools; returns service instance
    service = register_unified_faux_tools(mcp, data_dir)

    logger.info("Registered 2 Faux Objects MCP tools (2 unified)")
    return service
