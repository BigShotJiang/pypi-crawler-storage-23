"""DataShield - Offline Pre-AI Data Masking Module

DataShield ensures that client data is scrambled BEFORE it is sent to AI
for processing through DataBridge. For clients who are not comfortable
sending raw proprietary data to AI directly, DataShield provides the
assurance that AI only ever sees post-processed (scrambled) data.

Before masking, DataShield stores the summary and purpose of each table
so that context is preserved after scrambling — patterns, metadata,
cardinality, distributions, and referential integrity all remain intact
for data warehouse design to work normally.

The post-processed data persisted to Snowflake (e.g. AKHAN) contains no
real client data — it is entirely scrambled/synthetic with no correlation
to the original. This data is used by DataBridge for relationship
discovery, profiling, hierarchy building, and data warehouse design.

Phase 33 of DataBridge AI. Requires Pro license.

Six scrambling strategies:
- format_preserving_hash: Strings (codes, IDs, invoice numbers)
- numeric_scaling: Measures (amounts, quantities, rates)
- synthetic_substitution: Names, places (map to synthetic lookup)
- date_shift: Dates (shift by key-derived offset)
- pattern_preserving: Regex-structured values (phone, SSN format)
- passthrough: No scrambling (safe columns)

MCP Tools (15):
- Unified: shield_project, shield_table, shield_deploy
- Legacy: create_shield_project, list_shield_projects, get_shield_project,
  delete_shield_project, auto_classify_table, add_table_shield,
  remove_table_shield, preview_scrambled_data, generate_shield_ddl,
  deploy_shield_to_snowflake, shield_local_file, get_shield_status
"""

from .types import (
    ScrambleStrategy,
    ColumnClassification,
    ShieldScope,
    TrustLane,
    ColumnRule,
    TableShieldConfig,
    ShieldProject,
    DataAttestation,
    CLASSIFICATION_STRATEGY_MAP,
)
from .engine import ScrambleEngine
from .key_manager import KeyManager
from .classifier import auto_classify_columns
from .service import ShieldService
from .snowflake_generator import generate_full_ddl, generate_udfs
from .interceptor import DataShieldInterceptor
from .mcp_tools import register_datashield_tools
from .unified import (
    dispatch_shield_project,
    dispatch_shield_table,
    dispatch_shield_deploy,
    register_unified_datashield_tools,
    _PROJECT_ACTIONS,
    _TABLE_ACTIONS,
    _DEPLOY_ACTIONS,
)
from .policy_engine import mask_value, mask_row, mask_rows, is_pii_column
from .policy_engine import resolve_lane, enforce_attestation
from .attestation import (
    compute_input_hash,
    create_attestation,
    verify_attestation,
    persist_attestation_event,
)

__all__ = [
    # Enums
    "ScrambleStrategy",
    "ColumnClassification",
    "ShieldScope",
    "TrustLane",
    # Models
    "ColumnRule",
    "TableShieldConfig",
    "ShieldProject",
    "DataAttestation",
    "CLASSIFICATION_STRATEGY_MAP",
    # Core
    "ScrambleEngine",
    "KeyManager",
    "ShieldService",
    "DataShieldInterceptor",
    # Functions
    "auto_classify_columns",
    "generate_full_ddl",
    "generate_udfs",
    # Registration
    "register_datashield_tools",
    # Unified (Phase 3D-6)
    "dispatch_shield_project",
    "dispatch_shield_table",
    "dispatch_shield_deploy",
    "register_unified_datashield_tools",
    # Simple masking
    "mask_value",
    "mask_row",
    "mask_rows",
    "is_pii_column",
    "resolve_lane",
    "enforce_attestation",
    "compute_input_hash",
    "create_attestation",
    "verify_attestation",
    "persist_attestation_event",
]
