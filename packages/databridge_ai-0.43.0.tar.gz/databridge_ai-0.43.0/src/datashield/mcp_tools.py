"""DataShield MCP Tools - Phase 33 (with Phase 3D-6 unified consolidation)

Provides 3 unified MCP tools:
- shield_project: 4 actions (create, list, get, delete)
- shield_table: 4 actions (auto_classify, add, remove, preview)
- shield_deploy: 4 actions (generate_ddl, deploy, shield_file, status)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_shield_project,
    dispatch_shield_table,
    dispatch_shield_deploy,
    register_unified_datashield_tools,
)

logger = logging.getLogger(__name__)


def register_datashield_tools(mcp, settings):
    """Register all DataShield MCP tools."""

    # Register the 3 unified tools
    service = register_unified_datashield_tools(mcp, settings)

    logger.info("Registered 3 DataShield MCP tools")
    return service
