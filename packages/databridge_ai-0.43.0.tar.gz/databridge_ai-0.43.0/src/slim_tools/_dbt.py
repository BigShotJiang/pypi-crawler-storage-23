"""Slim tool: generate_dbt — Generate dbt models and project scaffolding."""
import json
from typing import Any, Optional


def generate_dbt(
    project_name: str,
    database: Optional[str] = None,
    schema_name: Optional[str] = None,
    tables: str = "",
    include_cicd: bool = False,
) -> str:
    """Generate dbt project with staging models for specified tables.

    Args:
        project_name: Name for the dbt project.
        database: Optional database name.
        schema_name: Optional schema name.
        tables: Optional comma-separated table names to generate models for.
        include_cicd: Whether to include CI/CD configuration (default False).

    Returns:
        JSON with generated dbt project structure, models, and optional CI/CD config.
    """
    from databridge.modeling import dbt_generate, dbt_project

    table_list = [t.strip() for t in tables.split(",") if t.strip()] if tables else None
    result: dict[str, Any] = {}

    result["project"] = dbt_project(
        project_name=project_name,
        database=database,
        schema_name=schema_name,
        tables=table_list,
        include_cicd=include_cicd,
    )

    if table_list:
        result["models"] = []
        for table in table_list:
            model = dbt_generate(
                action="model",
                model_type="staging",
                table_name=table,
                source_name=project_name,
                database=database,
                schema_name=schema_name,
            )
            result["models"].append(model)

    return json.dumps(result, indent=2, default=str)
