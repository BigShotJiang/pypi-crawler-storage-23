"""Slim tool: assess_quality — Profile data, detect drift, generate expectations."""
import json
from typing import Any, Optional


def assess_quality(
    source_path: str,
    baseline_path: Optional[str] = None,
    suite_name: Optional[str] = None,
) -> str:
    """Assess data quality: profile, detect schema drift, and generate expectations.

    Args:
        source_path: Path to the data file to assess.
        baseline_path: Optional path to baseline file for drift detection.
        suite_name: Optional name for the generated expectation suite.

    Returns:
        JSON with profile, optional drift report, and optional expectation suite.
    """
    from databridge.profiler import profile_data, detect_schema_drift, generate_expectation_suite

    result: dict[str, Any] = {}

    result["profile"] = profile_data(source_path)

    if baseline_path:
        result["drift"] = detect_schema_drift(baseline_path, source_path)

    if suite_name:
        result["expectations"] = generate_expectation_suite(name=suite_name)

    return json.dumps(result, indent=2, default=str)
