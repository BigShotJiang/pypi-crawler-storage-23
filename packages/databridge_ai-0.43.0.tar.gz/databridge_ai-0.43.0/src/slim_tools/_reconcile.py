"""Slim tool: reconcile — Compare hashes, find orphans, detect conflicts."""
import json
from typing import Any


def reconcile(source_a: str, source_b: str, key_columns: str, compare_columns: str = "") -> str:
    """Reconcile two data sources: compare hashes, find orphans, detect conflicts.

    Args:
        source_a: Path to source A CSV file.
        source_b: Path to source B CSV file.
        key_columns: Comma-separated key column names for matching rows.
        compare_columns: Optional comma-separated columns to compare (default: all non-key).

    Returns:
        Unified reconciliation report with summary, orphans, and conflicts.
    """
    from databridge.reconciler import compare_hashes, get_orphan_details, get_conflict_details

    summary = compare_hashes(source_a, source_b, key_columns, compare_columns)
    result: dict[str, Any] = {"summary": summary}

    stats = summary.get("statistics", {})
    if stats.get("total_orphans", 0) > 0:
        result["orphans"] = get_orphan_details(source_a, source_b, key_columns)
    if stats.get("conflicts", 0) > 0:
        result["conflicts"] = get_conflict_details(source_a, source_b, key_columns, compare_columns)

    return json.dumps(result, indent=2, default=str)
