"""Slim tool: agent_communicate — Register an agent and send messages."""
import json
from typing import Any, Optional


def agent_communicate(
    agent_name: str,
    target_agent: str = "",
    message_type: str = "info",
    payload: str = "{}",
    capabilities: str = "[]",
) -> str:
    """Register an agent with the orchestrator and optionally send a message.

    Args:
        agent_name: Name of the agent to register.
        target_agent: Optional target agent to send a message to.
        message_type: Message type (default "info").
        payload: JSON string of message payload.
        capabilities: JSON string of agent capabilities list.

    Returns:
        JSON with registration result and optional message delivery status.
    """
    from databridge.orchestrator import register_agent, send_message

    result: dict[str, Any] = {}

    parsed_capabilities = json.loads(capabilities) if isinstance(capabilities, str) else capabilities
    result["registration"] = register_agent(
        agent_name=agent_name,
        capabilities=parsed_capabilities,
    )

    if target_agent:
        parsed_payload = json.loads(payload) if isinstance(payload, str) else payload
        result["message"] = send_message(
            target_agent=target_agent,
            message_type=message_type,
            payload=parsed_payload,
        )

    return json.dumps(result, indent=2, default=str)
