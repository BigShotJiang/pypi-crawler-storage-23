"""Slim Tools — 12 workflow-oriented MCP tools built on the databridge library.

Each tool orchestrates multiple library calls into a single, high-level operation.
Registered as a plugin via plugin.json (phase 99, CE tier).
"""

from ._onboard import onboard_data
from ._reconcile import reconcile
from ._knowledge import search_knowledge
from ._review import review_knowledge
from ._model import discover_model
from ._dbt import generate_dbt
from ._quality import assess_quality
from ._entities import resolve_entities
from ._documents import extract_documents
from ._workflow import run_workflow
from ._sql import generate_sql
from ._communicate import agent_communicate


def register_slim_tools(mcp):
    """Register all 12 slim tools with the MCP server."""

    mcp.tool()(onboard_data)
    mcp.tool()(reconcile)
    mcp.tool()(search_knowledge)
    mcp.tool()(review_knowledge)
    mcp.tool()(discover_model)
    mcp.tool()(generate_dbt)
    mcp.tool()(assess_quality)
    mcp.tool()(resolve_entities)
    mcp.tool()(extract_documents)
    mcp.tool()(run_workflow)
    mcp.tool()(generate_sql)
    mcp.tool()(agent_communicate)

    print("[Plugin] slim_tools registered 12 tools")
    return {"tools_registered": 12}
