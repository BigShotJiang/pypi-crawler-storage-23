"""Slim tool: onboard_data — Load, profile, and fuzzy-match a CSV in one step."""
import json
from typing import Any


def onboard_data(file_path: str, match_against: str = "", match_column: str = "", threshold: int = 80) -> str:
    """Onboard a CSV file: load it, profile the data, and optionally fuzzy-match columns against another source.

    Args:
        file_path: Path to the CSV file to onboard.
        match_against: Optional path to a second CSV for column matching.
        match_column: Column name to fuzzy-match (required if match_against is set).
        threshold: Fuzzy match threshold (0-100, default 80).

    Returns:
        JSON report with load summary, profile, and optional match results.
    """
    from databridge.ingestion import load_csv
    from databridge.profiler import profile_data

    result: dict[str, Any] = {}

    result["load"] = load_csv(file_path)
    result["profile"] = profile_data(file_path)

    if match_against and match_column:
        from databridge.reconciler import fuzzy_match_columns
        result["fuzzy_matches"] = fuzzy_match_columns(
            file_path, match_against, match_column, match_column, threshold
        )

    return json.dumps(result, indent=2, default=str)
