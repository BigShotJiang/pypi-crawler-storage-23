"""Slim tool: resolve_entities — Deduplicate and fuzzy-match entity records."""
import json
from typing import Any


def resolve_entities(
    source_path: str,
    column: str,
    match_against: str = "",
    match_column: str = "",
    threshold: int = 90,
    limit: int = 10,
) -> str:
    """Resolve entities: deduplicate within a source and optionally match across sources.

    Args:
        source_path: Path to the CSV file with entities to resolve.
        column: Column name containing entity values to deduplicate.
        match_against: Optional path to a second CSV for cross-source matching.
        match_column: Column in the second source to match against.
        threshold: Similarity threshold (0-100, default 90).
        limit: Maximum results to return (default 10).

    Returns:
        JSON with deduplication clusters and optional cross-source matches.
    """
    from databridge.reconciler import fuzzy_deduplicate, fuzzy_match_columns

    result: dict[str, Any] = {}

    result["deduplication"] = fuzzy_deduplicate(source_path, column, threshold=threshold, limit=limit)

    if match_against and match_column:
        result["cross_match"] = fuzzy_match_columns(
            source_path, match_against, column, match_column,
            threshold=threshold, limit=limit,
        )

    return json.dumps(result, indent=2, default=str)
