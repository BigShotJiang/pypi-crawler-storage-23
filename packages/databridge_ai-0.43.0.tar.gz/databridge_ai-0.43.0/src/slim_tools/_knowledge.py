"""Slim tool: search_knowledge — Search the knowledge graph."""
import json


def search_knowledge(query: str, top_k: int = 5, include_evidence: bool = True) -> str:
    """Search the knowledge graph for relevant entities, facts, and relationships.

    Args:
        query: Natural language search query.
        top_k: Maximum number of results to return (default 5).
        include_evidence: Whether to include supporting evidence (default True).

    Returns:
        JSON with search results, relevance scores, and optional evidence.
    """
    from databridge.graphrag import search

    result = search(query, top_k=top_k, include_evidence=include_evidence)
    return json.dumps(result, indent=2, default=str)
