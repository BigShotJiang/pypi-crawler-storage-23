"""Slim tool: run_workflow — Create and execute a workflow in one step."""
import json
from typing import Any, Optional


def run_workflow(
    name: str,
    steps: str = "[]",
    description: Optional[str] = None,
    parameters: str = "{}",
) -> str:
    """Create and immediately execute a workflow.

    Args:
        name: Workflow name.
        steps: JSON string of workflow steps (list of step dicts).
        description: Optional workflow description.
        parameters: JSON string of execution parameters.

    Returns:
        JSON with workflow creation result and execution status.
    """
    from databridge.orchestrator import create_workflow, execute_workflow

    result: dict[str, Any] = {}

    parsed_steps = json.loads(steps) if isinstance(steps, str) else steps
    parsed_params = json.loads(parameters) if isinstance(parameters, str) else parameters

    creation = create_workflow(name=name, description=description, steps=parsed_steps)
    result["workflow"] = creation

    workflow_id = creation.get("workflow_id") or creation.get("id", "")
    if workflow_id:
        result["execution"] = execute_workflow(
            workflow_id=str(workflow_id),
            parameters=parsed_params,
        )

    return json.dumps(result, indent=2, default=str)
