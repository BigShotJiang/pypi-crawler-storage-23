"""Slim tool: review_knowledge — Deep review with closure loop and trust scoring."""
import json
from typing import Any


def review_knowledge(query: str, max_iterations: int = 3, include_trust: bool = True) -> str:
    """Deep review of a knowledge query: iterative search, closure loop, and trust explanation.

    Args:
        query: The question or topic to review.
        max_iterations: Maximum review iterations (default 3).
        include_trust: Whether to include trust metrics (default True).

    Returns:
        JSON with review findings, closure status, and trust explanations.
    """
    from databridge.graphrag import review, closure_loop, trust_explain

    result: dict[str, Any] = {}

    result["review"] = review(query, max_iterations=max_iterations, include_evidence=True)

    finding = result["review"].get("finding", query)
    result["closure"] = closure_loop(finding, max_iterations=max_iterations)

    if include_trust:
        entity_id = result["review"].get("primary_entity_id")
        if entity_id:
            result["trust"] = trust_explain(entity_id)

    return json.dumps(result, indent=2, default=str)
