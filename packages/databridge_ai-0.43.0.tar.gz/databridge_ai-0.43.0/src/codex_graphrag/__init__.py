"""Codex GraphRAG plugin package."""

from .mcp_tools import register_codex_graphrag_tools

__all__ = ["register_codex_graphrag_tools"]

