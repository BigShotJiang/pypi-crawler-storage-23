"""
MCP Tools for CortexAgent.

Provides 3 unified MCP tools:
- cortex_config: 2 actions (configure, status)
- cortex_function: 5 types (complete, summarize, sentiment, translate, extract_answer)
- cortex_reason: 5 actions (reason, analyze_data, clean_data, get_console_log, get_conversation)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_cortex_config,
    dispatch_cortex_function,
    dispatch_cortex_reason,
    register_unified_cortex_agent_tools,
)

logger = logging.getLogger(__name__)


def register_cortex_agent_tools(mcp, settings):
    """Register all Cortex Agent MCP tools."""

    # Register 3 unified tools
    register_unified_cortex_agent_tools(mcp, settings)

    logger.info("Registered 3 Cortex Agent MCP tools")
    return {
        "tools_registered": 3,
        "unified_tools": ["cortex_config", "cortex_function", "cortex_reason"],
    }
