"""
MCP Tools for Cortex Analyst.

Provides 3 unified MCP tools:
- semantic_model: 5 actions (create, add_table, deploy, list, validate)
- analyst_query: 3 actions (ask, ask_and_run, conversation)
- generate_semantic_model: 6 types (from_hierarchy, from_schema, from_faux, bootstrap, list_templates, from_template)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_semantic_model,
    dispatch_analyst_query,
    dispatch_generate_semantic_model,
    register_unified_cortex_analyst_tools,
)

logger = logging.getLogger(__name__)


def register_analyst_tools(mcp, settings):
    """Register all Cortex Analyst MCP tools."""

    # Register 3 unified tools
    register_unified_cortex_analyst_tools(mcp, settings)

    logger.info("Registered 3 Cortex Analyst MCP tools (3 unified)")
    return {
        "tools_registered": 3,
        "unified_tools": ["semantic_model", "analyst_query", "generate_semantic_model"],
    }
