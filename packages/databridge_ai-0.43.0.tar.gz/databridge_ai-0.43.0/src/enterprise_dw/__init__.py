"""
Enterprise DW Consolidation Engine.

Merges per-system data warehouses (built by BLCE) into a single enterprise DW
with conformed dimensions, harmonized facts, and an enterprise bus matrix.
"""
from .contracts import (
    GrainSpec,
    GrainComparison,
    FactAlignment,
    ConformedDimension,
    EnterpriseKeyMap,
    EnterpriseBusMatrixEntry,
    CrossGrainValidation,
)

__all__ = [
    "GrainSpec",
    "GrainComparison",
    "FactAlignment",
    "ConformedDimension",
    "EnterpriseKeyMap",
    "EnterpriseBusMatrixEntry",
    "CrossGrainValidation",
]
