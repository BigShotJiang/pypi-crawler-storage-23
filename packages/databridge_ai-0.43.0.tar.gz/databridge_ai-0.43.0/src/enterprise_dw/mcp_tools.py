"""MCP tool registration for Enterprise DW Consolidation Engine.

Provides 3 unified MCP tools (12 actions):
- enterprise_dw: 4 actions (analyze_grain, align_facts, generate_union_sql, validate_cross_grain)
- enterprise_dim: 4 actions (master_dimension, generate_key_map, detect_overlap, generate_dim_ddl)
- enterprise_matrix: 4 actions (build_matrix, conformance_report, generate_all_ddl, deploy)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .unified import (
    dispatch_enterprise_dw,
    dispatch_enterprise_dim,
    dispatch_enterprise_matrix,
)

logger = logging.getLogger(__name__)


def register_enterprise_dw_tools(mcp, settings):
    """Register the 3 unified enterprise DW MCP tools."""

    @mcp.tool()
    def enterprise_dw(
        action: str,
        systems_json: Optional[str] = None,
        comparison_json: Optional[str] = None,
        columns_a_json: Optional[str] = None,
        columns_b_json: Optional[str] = None,
        alignment_json: Optional[str] = None,
        target_table: Optional[str] = None,
        schema_prefix: Optional[str] = None,
        fact_table: Optional[str] = None,
        fine_grain: Optional[str] = None,
        coarse_grain: Optional[str] = None,
        measures_json: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Enterprise DW fact table operations.

        Actions:
        - analyze_grain: Detect and compare grain across system fact tables (requires systems_json)
        - align_facts: Generate fact alignment plan with column mapping (requires comparison_json, columns_a_json, columns_b_json)
        - generate_union_sql: Produce UNION ALL SQL with grain bridging (requires alignment_json)
        - validate_cross_grain: Verify rollup totals match across grain levels (requires fact_table, measures_json)
        """
        return dispatch_enterprise_dw(settings, action, **{
            k: v for k, v in {
                "systems_json": systems_json,
                "comparison_json": comparison_json,
                "columns_a_json": columns_a_json,
                "columns_b_json": columns_b_json,
                "alignment_json": alignment_json,
                "target_table": target_table,
                "schema_prefix": schema_prefix,
                "fact_table": fact_table,
                "fine_grain": fine_grain,
                "coarse_grain": coarse_grain,
                "measures_json": measures_json,
            }.items() if v is not None
        })

    @mcp.tool()
    def enterprise_dim(
        action: str,
        dimension_json: Optional[str] = None,
        system_data_json: Optional[str] = None,
        strategy: Optional[str] = None,
        priority_system: Optional[str] = None,
        systems_json: Optional[str] = None,
        schema_prefix: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Enterprise conformed dimension operations.

        Actions:
        - master_dimension: Create conformed enterprise dimension with surrogate keys (requires dimension_json)
        - generate_key_map: Produce natural-to-enterprise key mapping (requires dimension_json)
        - detect_overlap: Find members appearing in multiple systems (requires systems_json)
        - generate_dim_ddl: Generate enterprise dimension DDL (requires dimension_json)
        """
        return dispatch_enterprise_dim(settings, action, **{
            k: v for k, v in {
                "dimension_json": dimension_json,
                "system_data_json": system_data_json,
                "strategy": strategy,
                "priority_system": priority_system,
                "systems_json": systems_json,
                "schema_prefix": schema_prefix,
            }.items() if v is not None
        })

    @mcp.tool()
    def enterprise_matrix(
        action: str,
        facts_json: Optional[str] = None,
        dimensions_json: Optional[str] = None,
        schema_prefix: Optional[str] = None,
        ddl_json: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Enterprise bus matrix and DDL operations.

        Actions:
        - build_matrix: Generate enterprise bus matrix spanning all systems (requires facts_json)
        - conformance_report: Produce conformance scoring report
        - generate_all_ddl: Generate complete enterprise schema DDL (facts_json, dimensions_json)
        - deploy: Execute DDL via blce_execute_ddl pattern (requires ddl_json)
        """
        return dispatch_enterprise_matrix(settings, action, **{
            k: v for k, v in {
                "facts_json": facts_json,
                "dimensions_json": dimensions_json,
                "schema_prefix": schema_prefix,
                "ddl_json": ddl_json,
            }.items() if v is not None
        })

    logger.info("Registered 3 unified enterprise DW tools: enterprise_dw, enterprise_dim, enterprise_matrix")
    return {
        "tools_registered": 3,
        "unified_tools": ["enterprise_dw", "enterprise_dim", "enterprise_matrix"],
    }
