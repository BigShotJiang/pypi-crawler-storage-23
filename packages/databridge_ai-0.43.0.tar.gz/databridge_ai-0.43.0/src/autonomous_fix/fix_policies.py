"""Centralized policy for FixGenerator and closure verification."""

from __future__ import annotations

from typing import Optional

POLICY_VERSION = "phase3_balanced_gate_v1"

TRUST_REPLAY_MIN_CONFIDENCE = 0.7
CLOSURE_ACHIEVED_MIN_CONFIDENCE = 0.8
CLOSURE_LIKELY_MIN_CONFIDENCE = 0.72


def should_use_trust_replay(confidence: float, similar_case_count: int) -> bool:
    return similar_case_count > 0 and confidence >= TRUST_REPLAY_MIN_CONFIDENCE


def should_mark_closure_achieved(fix_type: str, confidence: float, similar_case_count: int) -> bool:
    return fix_type in {"trust_replay", "replay_proven"} and confidence >= CLOSURE_ACHIEVED_MIN_CONFIDENCE and similar_case_count > 0


def should_mark_closure_likely(fix_type: str, confidence: float, similar_case_count: int) -> bool:
    if fix_type in {"trust_replay", "replay_proven"}:
        return confidence >= CLOSURE_LIKELY_MIN_CONFIDENCE
    if fix_type == "relationship_rag":
        return confidence >= CLOSURE_LIKELY_MIN_CONFIDENCE
    return False


def human_approval_required(risk_tier: str, fix_type: Optional[str] = None) -> bool:
    risk = (risk_tier or "").strip().lower()
    if fix_type == "cortex_ai":
        return True
    return risk in {"high"}
