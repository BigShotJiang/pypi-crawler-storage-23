"""Multi-tenancy foundations (Phase 2A).

Public API::

    from src.tenancy import TenantContext, TenantRegistry, get_current_tenant
"""
from .context import (
    DEFAULT_TENANT_ID,
    TenantContext,
    get_current_tenant,
    reset_current_tenant,
    set_current_tenant,
)
from .registry import TenantRegistry

__all__ = [
    "DEFAULT_TENANT_ID",
    "TenantContext",
    "TenantRegistry",
    "get_current_tenant",
    "reset_current_tenant",
    "set_current_tenant",
]
