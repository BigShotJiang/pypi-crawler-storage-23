"""
MCP Tools for Data Observability.

Provides 4 unified MCP tools:
- obs_metric: 4 actions (record, query, stats, list)
- obs_alert: 5 actions (create_rule, list_rules, list_active, acknowledge, history)
- obs_anomaly: 3 actions (detect, report, configure)
- obs_health: 3 actions (asset, system, trends)
"""

import logging
from typing import Any, Dict

from .unified import (
    _ensure_metrics_store,
    _ensure_alert_manager,
    _ensure_anomaly_detector,
    _ensure_health_scorer,
    dispatch_obs_metric,
    dispatch_obs_alert,
    dispatch_obs_anomaly,
    dispatch_obs_health,
    register_unified_observability_tools,
)

logger = logging.getLogger(__name__)


def register_observability_tools(mcp, settings=None):
    """Register all observability MCP tools.

    Args:
        mcp: FastMCP instance
        settings: Optional settings object with data_dir

    Returns:
        Dict with registration summary
    """

    # Register the 4 unified tools
    register_unified_observability_tools(mcp, settings)

    logger.info("Registered 4 Data Observability MCP tools (4 unified)")
    return {
        "tools_registered": 4,
        "unified_tools": ["obs_metric", "obs_alert", "obs_anomaly", "obs_health"],
        "categories": {
            "metrics": ["obs_metric"],
            "alerting": ["obs_alert"],
            "anomaly_detection": ["obs_anomaly"],
            "health_scoring": ["obs_health"],
        },
    }
