"""
GraphRAG MCP Tools - 3 unified tools for RAG-enhanced AI interactions.

Provides 3 unified MCP tools:
- rag_index: index/config/hybrid sync actions
- rag_search: retrieval/explanation actions
- rag_ops: validation/health/calibration actions
"""
import logging
from typing import Any, Dict

from .unified import (
    # Dispatch functions
    dispatch_rag_index,
    dispatch_rag_search,
    dispatch_rag_ops,
    # Registration
    register_unified_graphrag_tools,
    # Module-level globals (re-exported for hierarchy bootstrap)
    _vector_store as _unified_vector_store,
    _embedder as _unified_embedder,
)

# Re-export module-level globals so hierarchy bootstrap import still works:
#   from ..graphrag.mcp_tools import _vector_store, _embedder
# These are module-level references that update when unified.py mutates them,
# but we need to use a property-like pattern via the unified module.
import src.graphrag.unified as _unified_mod

logger = logging.getLogger(__name__)


def __getattr__(name):
    """Module-level __getattr__ to proxy _vector_store and _embedder to unified.py."""
    if name == "_vector_store":
        return _unified_mod._vector_store
    if name == "_embedder":
        return _unified_mod._embedder
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def register_graphrag_tools(mcp, settings) -> Dict[str, Any]:
    """Register all GraphRAG MCP tools."""

    # Register the 3 unified tools
    register_unified_graphrag_tools(mcp, settings)

    logger.info("Registered 3 GraphRAG MCP tools")
    return {
        "tools_registered": 3,
        "unified_tools": ["rag_index", "rag_search", "rag_ops"],
        "tools": [
            "rag_index", "rag_search", "rag_ops",
        ],
    }
