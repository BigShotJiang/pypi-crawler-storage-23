"""LangGraph multi-agent workflow framework for DataBridge AI.

This package provides a LangGraph StateGraph-based alternative to the
sequential PlatformOrchestrator. It is **entirely optional** — when
``langgraph`` is not installed, the existing orchestrator remains the default.

Usage::

    from src.langgraph_agents import LANGGRAPH_AVAILABLE

    if LANGGRAPH_AVAILABLE:
        from src.langgraph_agents import (
            build_workflow_graph,
            run_graph,
            list_available_agents,
            register_langgraph_tools,
        )
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Availability flag — safe to import even without langgraph installed
# ---------------------------------------------------------------------------

LANGGRAPH_AVAILABLE = False

try:
    import langgraph  # noqa: F401
    import langchain_core  # noqa: F401
    LANGGRAPH_AVAILABLE = True
except ImportError:
    pass

# ---------------------------------------------------------------------------
# Conditional exports
# ---------------------------------------------------------------------------

if LANGGRAPH_AVAILABLE:
    try:
        from .state_schema import WorkflowState, create_initial_state
        from .message_protocol import AgentMessage, route_message
        from .base_agent import BaseDataBridgeAgent
        from .orchestrator_graph import (
            build_workflow_graph,
            run_graph,
            list_available_agents,
            PHASE_ORDER,
        )
        from .state_persistence import DataBridgeCheckpointSaver
        from .conversation_memory import ConversationMemory
        from .streaming_handler import StreamingProgressHandler
        from .mcp_tools import register_langgraph_tools

        # Agent classes
        from .data_modeling_agent import DataModelingAgent
        from .hierarchy_agent import HierarchyAgent
        from .dbt_agent import DbtAgent
        from .snowflake_agent import SnowflakeAgent
        from .qa_agent import QAAgent
        from .cortex_llm_agent import CortexLLMAgent
        from .cortex_analyst_agent import CortexAnalystAgent
        from .cortex_search_agent import CortexSearchAgent

        __all__ = [
            "LANGGRAPH_AVAILABLE",
            "WorkflowState",
            "create_initial_state",
            "AgentMessage",
            "route_message",
            "BaseDataBridgeAgent",
            "build_workflow_graph",
            "run_graph",
            "list_available_agents",
            "PHASE_ORDER",
            "DataBridgeCheckpointSaver",
            "ConversationMemory",
            "StreamingProgressHandler",
            "register_langgraph_tools",
            "DataModelingAgent",
            "HierarchyAgent",
            "DbtAgent",
            "SnowflakeAgent",
            "QAAgent",
            "CortexLLMAgent",
            "CortexAnalystAgent",
            "CortexSearchAgent",
        ]

        logger.info("[LangGraph] ✓ Multi-agent framework available (%d agents)", 8)

    except Exception as e:
        logger.warning("[LangGraph] Import error (degrading gracefully): %s", e)
        LANGGRAPH_AVAILABLE = False
else:
    # Minimal exports when langgraph is not installed
    from .mcp_tools import register_langgraph_tools  # noqa: F401 — still registers stubs

    __all__ = [
        "LANGGRAPH_AVAILABLE",
        "register_langgraph_tools",
    ]

    logger.debug("[LangGraph] Not installed — using PlatformOrchestrator")
