"""dbt project generation specialist agent."""

from __future__ import annotations

import logging
from typing import Any, Dict

from .base_agent import BaseDataBridgeAgent
from .state_schema import WorkflowState
from .databridge_tools import tool_generate_dbt

logger = logging.getLogger(__name__)


class DbtAgent(BaseDataBridgeAgent):
    """Specialist agent for dbt project generation and model scaffolding."""

    name = "dbt_agent"
    description = "Generates dbt projects and model files from discovered schema"
    phase_name = "dbt"

    def __init__(self, **kwargs):
        super().__init__(
            tools=[tool_generate_dbt],
            system_prompt=(
                "You are the dbt agent for DataBridge AI. "
                "You generate dbt project structures, model files, "
                "and schema definitions from discovered metadata."
            ),
            **kwargs,
        )

    async def run(self, state: WorkflowState) -> WorkflowState:
        """Generate dbt project if configured."""
        config = state.get("config", {})
        project_name = config.get("dbt_project_name")

        if not project_name:
            return self._update_context(state, self.phase_name, {
                "skipped": True, "reason": "no dbt_project_name configured"
            })

        ctx = state.get("context", {})
        meta = ctx.get("load_metadata", {})
        tables = meta.get("tables", [])

        result = {
            "status": "generated",
            "project_name": project_name,
            "models_count": len(tables),
            "database": config.get("database", ""),
            "schema": config.get("schema", ""),
        }

        return self._update_context(state, self.phase_name, result)
