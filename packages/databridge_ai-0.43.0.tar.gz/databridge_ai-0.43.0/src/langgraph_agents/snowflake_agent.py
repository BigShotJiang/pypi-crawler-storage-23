"""Snowflake DDL execution + data loading specialist agent."""

from __future__ import annotations

import logging
from typing import Any, Dict

from .base_agent import BaseDataBridgeAgent
from .state_schema import WorkflowState
from .databridge_tools import tool_execute_snowflake_ddl

logger = logging.getLogger(__name__)


class SnowflakeAgent(BaseDataBridgeAgent):
    """Specialist agent for Snowflake DDL execution and data loading."""

    name = "snowflake_agent"
    description = "Executes Snowflake DDL, manages schemas, and loads data"
    phase_name = "wright"

    def __init__(self, **kwargs):
        super().__init__(
            tools=[tool_execute_snowflake_ddl],
            system_prompt=(
                "You are the Snowflake agent for DataBridge AI. "
                "You execute DDL statements, manage schemas, "
                "and handle data loading operations in Snowflake."
            ),
            **kwargs,
        )

    async def run(self, state: WorkflowState) -> WorkflowState:
        """Execute Wright pipeline (Snowflake DDL/DML)."""
        ctx = state.get("context", {})
        config = state.get("config", {})

        # Wright phase needs hierarchy output
        hierarchy = ctx.get("hierarchy", {})
        if hierarchy.get("status") == "placeholder" or not hierarchy:
            return self._update_context(state, self.phase_name, {
                "status": "placeholder",
                "note": "Wright requires hierarchy — use wright_from_hierarchy via MCP",
            })

        result = {
            "status": "completed",
            "source_type": config.get("source_type", "unknown"),
            "note": "Wright pipeline execution delegated to MCP tools",
        }

        return self._update_context(state, self.phase_name, result)
