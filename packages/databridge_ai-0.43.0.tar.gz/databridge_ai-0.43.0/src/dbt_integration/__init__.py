"""
dbt Integration Module.

Generates dbt projects from DataBridge hierarchies:
- Project scaffolding (dbt_project.yml, profiles.yml)
- SQL model generation (staging, intermediate, marts)
- Source definitions (sources.yml)
- Schema documentation (schema.yml)
- Metrics from formula groups
- CI/CD pipelines (GitHub Actions, GitLab CI, Azure DevOps)

Components:
- DbtProjectGenerator: Project scaffolding
- DbtModelGenerator: SQL model generation
- DbtSourceGenerator: Source definitions
- DbtMetricsGenerator: Metrics from formulas
- CiCdGenerator: CI/CD pipeline generation
"""

from .types import (
    # Enums
    DbtMaterialization,
    DbtModelType,
    CiCdPlatform,
    # Project configuration
    DbtProjectConfig,
    DbtProject,
    # Sources
    DbtSource,
    DbtSourceTable,
    DbtColumn,
    # Models
    DbtModelConfig,
    # Metrics and tests
    DbtMetric,
    DbtTest,
    # CI/CD
    CiCdConfig,
    # Validation
    ValidationResult,
)

from .project_generator import DbtProjectGenerator
from .model_generator import DbtModelGenerator
from .source_generator import DbtSourceGenerator, DbtMetricsGenerator
from .cicd_generator import CiCdGenerator
from .mcp_tools import register_dbt_tools
from .unified import (
    dispatch_dbt_project,
    dispatch_dbt_generate,
    register_unified_dbt_tools,
    _PROJECT_ACTIONS,
    _GENERATE_TYPES,
)
from .runner import ensure_profiles_yml, run_dbt_command, load_run_results
from .orchestrator_bridge import orchestrator_to_dbt_vars

__all__ = [
    # Types - Enums
    "DbtMaterialization",
    "DbtModelType",
    "CiCdPlatform",
    # Types - Configuration
    "DbtProjectConfig",
    "DbtProject",
    "DbtSource",
    "DbtSourceTable",
    "DbtColumn",
    "DbtModelConfig",
    "DbtMetric",
    "DbtTest",
    "CiCdConfig",
    "ValidationResult",
    # Generators
    "DbtProjectGenerator",
    "DbtModelGenerator",
    "DbtSourceGenerator",
    "DbtMetricsGenerator",
    "CiCdGenerator",
    # MCP
    "register_dbt_tools",
    "dispatch_dbt_project",
    "dispatch_dbt_generate",
    "register_unified_dbt_tools",
    "ensure_profiles_yml",
    "run_dbt_command",
    "load_run_results",
    "orchestrator_to_dbt_vars",
]

from .scaffold import generate_dbt_scaffold
