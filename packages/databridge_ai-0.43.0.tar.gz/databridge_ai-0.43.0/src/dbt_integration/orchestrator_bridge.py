"""Bridge orchestrator output into dbt project context."""
from __future__ import annotations

from typing import Any, Dict


def orchestrator_to_dbt_vars(orchestrator_output: Dict[str, Any], prompt: str) -> Dict[str, Any]:
    """Convert orchestrator output into dbt vars for dbt_project.yml."""
    route = orchestrator_output.get("route")
    envelopes = orchestrator_output.get("envelopes", {})
    retrieval = envelopes.get("retrieval")
    synthesis = envelopes.get("synthesis")

    return {
        "orchestrator_prompt": prompt,
        "orchestrator_mode": getattr(route, "mode", None) if route else None,
        "retrieval_items": getattr(retrieval, "items", []) if retrieval else [],
        "synthesis_items": getattr(synthesis, "items", []) if synthesis else [],
    }

