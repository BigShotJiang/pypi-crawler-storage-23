"""
MCP Tools for dbt Integration.

Provides 2 unified MCP tools:
- dbt_project: 3 actions (create, validate, export)
- dbt_generate: 5 types (model, sources, schema, metrics, cicd)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_dbt_project,
    dispatch_dbt_generate,
    register_unified_dbt_tools,
)

logger = logging.getLogger(__name__)


def register_dbt_tools(mcp, settings=None) -> Dict[str, Any]:
    """Register all dbt integration MCP tools."""

    # Register the 2 unified tools
    register_unified_dbt_tools(mcp, settings)

    logger.info("Registered 2 dbt MCP tools")
    return {
        "tools_registered": 2,
        "unified_tools": ["dbt_project", "dbt_generate"],
        "tools": [
            "dbt_project", "dbt_generate",
        ],
    }
