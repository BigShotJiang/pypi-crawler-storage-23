"""Phase 5: dbt scaffold generator (minimal)."""
from __future__ import annotations

from pathlib import Path


def generate_dbt_scaffold(output_dir: str) -> dict:
    """Create a minimal dbt project scaffold."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "models").mkdir(exist_ok=True)
    (out / "models" / "stg_gl_accounts.sql").write_text(
        "select * from {{ source('raw','gl_accounts') }}",
        encoding="utf-8",
    )
    (out / "dbt_project.yml").write_text(
        "name: databridge_demo\n"
        "version: 1.0\n"
        "profile: databridge_demo\n",
        encoding="utf-8",
    )
    return {"status": "ok", "path": str(out)}
