"""
MCP Tools for Data Catalog.

Provides 3 unified MCP tools:
- catalog_asset: 14 actions (create, get, update, list, delete, search, stats,
                 scan_connection, scan_table, refresh, add_tag, remove_tag, list_tags, create_tag)
- catalog_term: 4 actions (create, get, list, link)
- catalog_lineage: 4 actions (from_sql, from_dbt, visualize, impact)
"""

import logging
from typing import Any, Dict

from .unified import (
    _ensure_catalog,
    _ensure_scanner,
    dispatch_catalog_asset,
    dispatch_catalog_term,
    dispatch_catalog_lineage,
    register_unified_catalog_tools,
)

logger = logging.getLogger(__name__)


def register_data_catalog_tools(mcp, settings):
    """Register all Data Catalog MCP tools."""

    # Register the 3 unified tools
    register_unified_catalog_tools(mcp, settings)

    logger.info("Registered 3 Data Catalog MCP tools (3 unified)")
    return {
        "tools_registered": 3,
        "unified_tools": ["catalog_asset", "catalog_term", "catalog_lineage"],
        "categories": {
            "asset_management": ["catalog_asset"],
            "glossary": ["catalog_term"],
            "lineage": ["catalog_lineage"],
        },
    }
