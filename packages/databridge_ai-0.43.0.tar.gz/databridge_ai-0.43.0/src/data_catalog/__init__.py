"""
Data Catalog - Centralized metadata registry for DataBridge.

This module provides:
1. Data Asset Registry - Catalog tables, views, hierarchies, semantic models
2. Business Glossary - Define and manage business terms
3. Data Discovery - Scan data sources to auto-catalog assets
4. Search & Discovery - Find assets by name, description, tags
5. Data Ownership - Track owners, stewards, and access policies
6. Data Classification - Classify data by sensitivity (PII, PHI, PCI)
7. Quality Metrics - Track data quality scores
8. Automated Lineage - Extract lineage from SQL and dbt artifacts

Phase 29 of DataBridge AI (updated with Phase 3A tool consolidation).

MCP Tools (22 = 3 unified + 19 legacy wrappers):
- Unified: catalog_asset (14 actions), catalog_term (4 actions), catalog_lineage (4 actions)
- Legacy wrappers: catalog_create_asset, catalog_get_asset, catalog_update_asset,
                   catalog_list_assets, catalog_delete_asset, catalog_scan_connection,
                   catalog_scan_table, catalog_refresh_asset, catalog_create_term,
                   catalog_get_term, catalog_list_terms, catalog_link_term,
                   catalog_search, catalog_get_stats, catalog_manage_tags,
                   catalog_auto_lineage_from_sql, catalog_auto_lineage_from_dbt,
                   catalog_lineage_visualization, catalog_impact_from_asset
"""

from .types import (
    # Enums
    AssetType,
    DataClassification,
    DataQualityTier,
    OwnershipRole,
    TermStatus,
    # Core models
    Tag,
    Owner,
    QualityMetrics,
    ColumnProfile,
    DataAsset,
    # Glossary
    GlossaryTerm,
    GlossaryDomain,
    # Search
    SearchQuery,
    SearchResult,
    SearchResults,
    # Scanning
    ScanConfig,
    ScanResult,
    # Stats
    CatalogStats,
)

from .catalog_store import CatalogStore
from .scanner import CatalogScanner
from .lineage_extractor import (
    SQLLineageExtractor,
    DbtLineageExtractor,
    LineageGraphBuilder,
)
from .mcp_tools import register_data_catalog_tools
from .unified import (
    register_unified_catalog_tools,
    dispatch_catalog_asset,
    dispatch_catalog_term,
    dispatch_catalog_lineage,
)

__all__ = [
    # Enums
    "AssetType",
    "DataClassification",
    "DataQualityTier",
    "OwnershipRole",
    "TermStatus",
    # Core models
    "Tag",
    "Owner",
    "QualityMetrics",
    "ColumnProfile",
    "DataAsset",
    # Glossary
    "GlossaryTerm",
    "GlossaryDomain",
    # Search
    "SearchQuery",
    "SearchResult",
    "SearchResults",
    # Scanning
    "ScanConfig",
    "ScanResult",
    # Stats
    "CatalogStats",
    # Classes
    "CatalogStore",
    "CatalogScanner",
    # Lineage Extraction
    "SQLLineageExtractor",
    "DbtLineageExtractor",
    "LineageGraphBuilder",
    # Registration
    "register_data_catalog_tools",
    # Unified tools (Phase 3A)
    "register_unified_catalog_tools",
    "dispatch_catalog_asset",
    "dispatch_catalog_term",
    "dispatch_catalog_lineage",
]
