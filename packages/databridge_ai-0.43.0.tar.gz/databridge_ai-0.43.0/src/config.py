"""Configuration management using Pydantic Settings."""
from pydantic_settings import BaseSettings
from pydantic import Field
from pathlib import Path


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Database connections
    database_url: str = Field(default="", description="SQLAlchemy database connection string")

    # OCR Configuration
    tesseract_path: str = Field(default="", description="Path to Tesseract executable")

    # API Keys (for LangChain/OpenAI if needed)
    openai_api_key: str = Field(default="", description="OpenAI API key for LangChain")

    # Application paths
    data_dir: Path = Field(default=Path("data"), description="Directory for data storage")
    workflow_file: Path = Field(default=Path("data/workflow.json"), description="Workflow recipes file")
    audit_log: Path = Field(default=Path("data/audit_trail.csv"), description="Audit trail log")

    # Fuzzy matching defaults
    fuzzy_threshold: int = Field(default=80, ge=0, le=100, description="Default fuzzy match threshold")

    # Context sensitivity
    max_rows_display: int = Field(default=10, description="Maximum rows to return to LLM")

    # NestJS Backend Sync Configuration
    nestjs_backend_url: str = Field(
        default="http://localhost:3002/api",
        description="NestJS backend API URL for sync"
    )
    nestjs_api_key: str = Field(
        default="dev-key-1",
        description="API key for authenticating with NestJS backend"
    )
    nestjs_sync_enabled: bool = Field(
        default=True,
        description="Enable automatic sync with NestJS backend"
    )

    # Additional NestJS endpoints for Hierarchy Knowledge Base
    nestjs_connections_endpoint: str = Field(
        default="/connections",
        description="Connections API endpoint"
    )
    nestjs_schema_matcher_endpoint: str = Field(
        default="/schema-matcher",
        description="Schema Matcher API endpoint"
    )
    nestjs_data_matcher_endpoint: str = Field(
        default="/data-matcher",
        description="Data Matcher API endpoint"
    )

    # Cortex Agent Configuration
    cortex_default_model: str = Field(
        default="mistral-large",
        description="Default Cortex model (mistral-large, claude-3-sonnet, llama3-70b)"
    )
    cortex_max_reasoning_steps: int = Field(
        default=10,
        ge=1,
        le=50,
        description="Maximum steps in reasoning loop"
    )
    cortex_console_enabled: bool = Field(
        default=True,
        description="Enable communication console"
    )
    cortex_console_log_path: Path = Field(
        default=Path("data/cortex_agent/console.jsonl"),
        description="Console log file path"
    )

    # Trust enforcement (DataShield attestations)
    trust_enforcement_enabled: bool = Field(
        default=True,
        description="Require trust attestations for protected AI lanes"
    )
    trust_enforcement_mode: str = Field(
        default="hard_fail",
        description="Trust enforcement mode: hard_fail | warn"
    )
    trust_public_key_registry_path: Path = Field(
        default=Path("data/datashield/trust_public_keys.json"),
        description="JSON file mapping key_id -> Ed25519 public key PEM"
    )

    # Knowledge Base backends
    kb_vector_backend: str = Field(
        default="chroma",
        description="Vector backend: file, weaviate, chroma"
    )
    kb_graph_backend: str = Field(
        default="neo4j",
        description="Graph backend: file, neo4j, snowflake"
    )
    weaviate_url: str = Field(default="http://localhost:8080", description="Weaviate base URL")
    weaviate_api_key: str = Field(default="", description="Weaviate API key")
    chroma_path: Path = Field(default=Path("data/chroma"), description="Chroma local path")
    neo4j_uri: str = Field(default="bolt://localhost:7687", description="Neo4j bolt URI")
    neo4j_user: str = Field(default="", description="Neo4j username")
    neo4j_password: str = Field(default="", description="Neo4j password")
    snowflake_graph_database: str = Field(default="", description="Snowflake graph database")
    snowflake_graph_schema: str = Field(default="", description="Snowflake graph schema")

    # Persistence backends
    persistence_backend: str = Field(
        default="file",
        description="Persistence backend: file | snowflake"
    )
    persistence_snowflake_database: str = Field(default="", description="Snowflake database for persistence")
    persistence_snowflake_schema: str = Field(default="", description="Snowflake schema for persistence")

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore"
    }


# Global settings instance
settings = Settings()
