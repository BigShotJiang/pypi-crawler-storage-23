"""DataBridge AI utilities."""

from .tool_wrapper import safe_tool

__all__ = ["safe_tool"]
