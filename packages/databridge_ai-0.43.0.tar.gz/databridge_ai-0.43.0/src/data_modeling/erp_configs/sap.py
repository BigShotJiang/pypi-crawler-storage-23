"""SAP ERP inference configuration.

Pre-tuned suffix/prefix patterns for SAP ECC / S4HANA
(FI, CO, MM, SD, PP modules).
"""

from __future__ import annotations

from ..focus_config import FocusConfig, InferenceConfig

_SAP_PREFIXES = [
    "bkpf", "bseg", "bsik", "bsid", "bsak", "bsad",
    "mara", "marc", "mard", "makt",
    "ekko", "ekpo",
    "vbak", "vbap", "vbrk", "vbrp",
    "likp", "lips",
    "kna1", "knb1", "lfa1", "lfb1",
    "csks", "cska", "anlc", "anla",
    "t001",
]

SAP_CONFIG = InferenceConfig(
    key_suffixes=["nr", "num", "_id", "bukrs", "mandt", "kunnr", "lifnr", "matnr"],
    strip_prefixes=_SAP_PREFIXES,
    exclude_columns=["MANDT", "ERDAT", "ERZET", "ERNAM", "AEDAT", "LAEDA"],
    min_overlap=0.25,
)

SAP_FOCUS = FocusConfig(
    patterns=["BSEG", "EKPO", "VBAP", "MSEG", "ACDOCA", "BKPF"],
    sample_limit=100,
    overlap_threshold=0.05,
)
