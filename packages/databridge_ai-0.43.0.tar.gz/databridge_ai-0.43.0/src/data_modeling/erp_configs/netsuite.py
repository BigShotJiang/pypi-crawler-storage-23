"""NetSuite ERP inference configuration.

Pre-tuned suffix/prefix patterns for Oracle NetSuite
(GL, AR, AP, inventory, revenue recognition).
"""

from __future__ import annotations

from ..focus_config import FocusConfig, InferenceConfig

_NETSUITE_PREFIXES = [
    "transaction", "account", "customer", "vendor", "item",
    "department", "location", "subsidiary", "class",
    "employee", "currency", "period",
]

NETSUITE_CONFIG = InferenceConfig(
    key_suffixes=["_id", "_key", "id", "_internal_id", "_extid"],
    strip_prefixes=_NETSUITE_PREFIXES,
    exclude_columns=["DATE_LAST_MODIFIED", "LAST_MODIFIED_DATE", "_FIVETRAN_SYNCED"],
    min_overlap=0.3,
)

NETSUITE_FOCUS = FocusConfig(
    patterns=["TRANSACTION", "TRANSACTION_LINE", "GL_IMPACT", "REVENUE"],
    sample_limit=100,
    overlap_threshold=0.05,
)
