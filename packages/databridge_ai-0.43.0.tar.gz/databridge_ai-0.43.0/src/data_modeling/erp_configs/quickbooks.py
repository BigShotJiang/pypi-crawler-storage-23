"""QuickBooks ERP inference configuration.

Pre-tuned suffix/prefix patterns for Intuit QuickBooks Online / Desktop
(invoicing, billing, payments, journal entries).
"""

from __future__ import annotations

from ..focus_config import FocusConfig, InferenceConfig

_QUICKBOOKS_PREFIXES = [
    "invoice", "bill", "payment", "account", "customer", "vendor",
    "item", "journal", "estimate", "credit", "deposit", "purchase",
    "transfer", "check",
]

QUICKBOOKS_CONFIG = InferenceConfig(
    key_suffixes=["_id", "_ref", "id", "_num", "_number"],
    strip_prefixes=_QUICKBOOKS_PREFIXES,
    exclude_columns=["SYNC_TOKEN", "META_CREATE_TIME", "META_LAST_UPDATED_TIME"],
    min_overlap=0.3,
)

QUICKBOOKS_FOCUS = FocusConfig(
    patterns=["LINE", "JOURNAL", "INVOICE", "BILL", "PAYMENT"],
    sample_limit=100,
    overlap_threshold=0.05,
)
