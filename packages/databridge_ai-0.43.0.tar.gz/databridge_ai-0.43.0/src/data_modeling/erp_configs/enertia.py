"""Enertia ERP inference configuration.

Pre-tuned suffix/prefix patterns and focus config derived from
the Enertia E2E test (134 relationships, 71 tables).
"""

from __future__ import annotations

from ..focus_config import FocusConfig, InferenceConfig

# All known Enertia 2-letter table prefixes (lowercase for strip matching)
_ENERTIA_PREFIXES = [
    "aa", "gl", "rv", "jb", "pd", "ae", "fb", "lc", "tx", "pr",
    "txn", "txnhdr", "txndtl", "mas", "mashdr", "masdtl",
]

ENERTIA_CONFIG = InferenceConfig(
    key_suffixes=["tid", "hid", "code", "_id", "_num", "_key"],
    strip_prefixes=_ENERTIA_PREFIXES,
    exclude_columns=["LASTUPDATEID", "RECORD_ID", "CREATEID", "_FIVETRAN_SYNCED"],
    min_overlap=0.3,
)

ENERTIA_FOCUS = FocusConfig(
    patterns=["TXN", "TRANS", "FCT", "DTL"],
    sample_limit=100,
    overlap_threshold=0.05,
)
