"""ERP-specific inference configuration presets.

Provides pre-tuned InferenceConfig + FocusConfig for common ERP systems
(Enertia, SAP, Oracle EBS) so relationship detection works out of the box.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

from ..focus_config import FocusConfig, InferenceConfig
from .registry import detect_erp_type, get_erp_config, list_erp_configs, register_erp_config

__all__ = [
    "detect_erp_type",
    "get_erp_config",
    "list_erp_configs",
    "register_erp_config",
]
