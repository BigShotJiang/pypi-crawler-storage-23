"""WolfePak ERP inference configuration.

Pre-tuned suffix/prefix patterns for WolfePak oil & gas accounting
(well management, revenue, JIB, production, GL).
"""

from __future__ import annotations

from ..focus_config import FocusConfig, InferenceConfig

_WOLFEPAK_PREFIXES = [
    "wp", "wpk", "wolf", "wlf", "rev", "prod", "jib", "afe", "gl", "ap", "ar",
]

WOLFEPAK_CONFIG = InferenceConfig(
    key_suffixes=["_id", "_key", "_code", "_num", "_no", "id"],
    strip_prefixes=_WOLFEPAK_PREFIXES,
    exclude_columns=["LAST_MODIFIED_BY", "CREATED_BY", "RECORD_STATUS", "_FIVETRAN_SYNCED"],
    min_overlap=0.3,
)

WOLFEPAK_FOCUS = FocusConfig(
    patterns=["TXN", "TRANS", "DETAIL", "DTL", "JIB", "REV"],
    sample_limit=100,
    overlap_threshold=0.05,
)
