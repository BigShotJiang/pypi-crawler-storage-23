"""Configurable heuristics for relationship inference."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class InferenceConfig:
    """Configurable suffix/prefix patterns for relationship inference.

    Replaces hardcoded lists in relationship_inferer.py so patterns
    can be tuned per-ERP (Enertia, SAP, Oracle, etc.).
    """

    key_suffixes: List[str] = field(
        default_factory=lambda: ["_id", "_code", "_num", "tid", "hid"]
    )
    strip_prefixes: List[str] = field(
        default_factory=lambda: [
            "txn", "txnhdr", "txndtl", "rv", "aa", "lc", "gl", "jb", "pd", "ae", "fb"
        ]
    )
    exclude_columns: List[str] = field(
        default_factory=lambda: ["LASTUPDATEID", "RECORD_ID", "CREATEID"]
    )
    min_overlap: float = 0.5


@dataclass
class FocusConfig:
    """Transaction-focused inference overrides.

    Tables matching focus patterns get higher sample limits and lower
    overlap thresholds for more accurate FK detection on high-volume
    transaction tables.
    """

    patterns: List[str] = field(
        default_factory=lambda: ["TXN", "TRANS", "FCT"]
    )
    sample_limit: int = 50
    overlap_threshold: float = 0.05
