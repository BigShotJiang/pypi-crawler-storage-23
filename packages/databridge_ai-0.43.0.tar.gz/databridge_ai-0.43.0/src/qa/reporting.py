"""QA report aggregation for workflow and dbt results."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional


def build_qa_report(
    orchestrator_summary: Optional[Dict[str, Any]] = None,
    dbt_results: Optional[Dict[str, Any]] = None,
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a QA report payload from pipeline outputs."""
    return {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "orchestrator": orchestrator_summary or {},
        "dbt_results": dbt_results or {},
        "notes": notes or "",
    }


def write_qa_report(report: Dict[str, Any], output_path: Path) -> Path:
    """Persist QA report to disk."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return output_path

