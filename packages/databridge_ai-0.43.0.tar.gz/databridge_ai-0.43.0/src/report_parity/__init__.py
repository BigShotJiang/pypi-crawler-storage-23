"""
Report Parity & Progressive Validation Engine.

Progressive state-machine validation that verifies enterprise DW
reproduces the same numbers as existing reports, with automatic
root-cause classification and fix-loop integration.
"""
from .contracts import (
    ReportLineItem,
    ReportSpec,
    ValidationScope,
    ValidationPeriod,
    ValidationSlice,
    ParityTestResult,
    DiscrepancyType,
    Discrepancy,
    GateStatus,
    ParityGate,
    ProgressiveValidationState,
    GATE_TRANSITIONS,
    GATE_SEQUENCE,
)

__all__ = [
    "ReportLineItem",
    "ReportSpec",
    "ValidationScope",
    "ValidationPeriod",
    "ValidationSlice",
    "ParityTestResult",
    "DiscrepancyType",
    "Discrepancy",
    "GateStatus",
    "ParityGate",
    "ProgressiveValidationState",
    "GATE_TRANSITIONS",
    "GATE_SEQUENCE",
]
