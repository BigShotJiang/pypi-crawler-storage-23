"""
MCP Tools for Lineage & Impact Analysis.

Provides 3 unified MCP tools:
- lineage_graph: 3 actions (add_node, list, validate)
- lineage_track: 5 actions (track_column, get_column, get_table, downstream_impact, upstream_deps)
- lineage_visualize: 3 actions (change_impact, build_graph, export_diagram)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_lineage_graph,
    dispatch_lineage_track,
    dispatch_lineage_visualize,
    register_unified_lineage_tools,
)

logger = logging.getLogger(__name__)


def register_lineage_tools(mcp, settings=None) -> Dict[str, Any]:
    """Register all Lineage & Impact Analysis MCP tools."""

    # Register the 3 unified tools
    register_unified_lineage_tools(mcp, settings)

    logger.info("Registered 3 Lineage MCP tools")
    return {
        "tools_registered": 3,
        "unified_tools": ["lineage_graph", "lineage_track", "lineage_visualize"],
        "tools": [
            "lineage_graph", "lineage_track", "lineage_visualize",
        ],
    }
