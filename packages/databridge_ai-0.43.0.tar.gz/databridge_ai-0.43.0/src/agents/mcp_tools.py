"""
MCP Tools for the PlannerAgent.

Provides 3 unified MCP tools:
- planner_workflow: 3 actions (plan, analyze, suggest_agents)
- planner_transform: 3 operations (explain, optimize, to_workflow_def)
- planner_manage: 5 actions (list_agents, register_agent, status, history, configure)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_planner_workflow,
    dispatch_planner_transform,
    dispatch_planner_manage,
    register_unified_planner_tools,
)

logger = logging.getLogger(__name__)


def register_planner_tools(mcp: Any) -> Dict[str, Any]:
    """Register all PlannerAgent MCP tools."""

    # Register the 3 unified tools
    register_unified_planner_tools(mcp)

    logger.info("Registered 3 PlannerAgent MCP tools")
    return {
        "tools_registered": 3,
        "unified_tools": ["planner_workflow", "planner_transform", "planner_manage"],
        "tools": [
            "planner_workflow", "planner_transform", "planner_manage",
        ],
    }
