"""
MCP Tools for Unified AI Agent.

Provides 3 unified MCP tools:
- book_sync: 4 actions (checkout, promote, sync, diff)
- book_research: 3 types (analyze, compare_to_db, profile_sources)
- unified_workflow: 3 actions (create, execute, get_context)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_book_sync,
    dispatch_book_research,
    dispatch_unified_workflow,
    register_unified_agent_unified_tools,
)

logger = logging.getLogger("unified_agent.tools")


def register_unified_agent_tools(mcp):
    """Register all Unified Agent MCP tools."""

    # Register the 3 unified tools
    register_unified_agent_unified_tools(mcp)

    logger.info("Registered 3 Unified Agent MCP tools")
