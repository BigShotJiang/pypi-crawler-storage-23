"""
Unified AI Agent for DataBridge AI.

This module provides a single AI agent that operates across Book (Python),
Librarian (NestJS), and Researcher (NestJS) components, enabling seamless
workflows like "analyze Book -> promote to Librarian -> validate with Researcher".

Components:
- UnifiedAgentContext: Tracks state across all three systems
- LibrarianBridge: Converts between Book and Librarian data models
- ResearcherBridge: Provides analytics on Book/Librarian data
- MCP Tools: 3 unified + 10 legacy wrappers (13 total)
- Unified dispatch: book_sync, book_research, unified_workflow
"""

from .context import UnifiedAgentContext
from .bridges.librarian_bridge import LibrarianBridge
from .bridges.researcher_bridge import ResearcherBridge
from .unified import (
    dispatch_book_sync,
    dispatch_book_research,
    dispatch_unified_workflow,
    register_unified_agent_unified_tools,
    _SYNC_ACTIONS,
    _RESEARCH_TYPES,
    _WORKFLOW_ACTIONS,
)

__all__ = [
    "UnifiedAgentContext",
    "LibrarianBridge",
    "ResearcherBridge",
    "dispatch_book_sync",
    "dispatch_book_research",
    "dispatch_unified_workflow",
    "register_unified_agent_unified_tools",
    "_SYNC_ACTIONS",
    "_RESEARCH_TYPES",
    "_WORKFLOW_ACTIONS",
]
