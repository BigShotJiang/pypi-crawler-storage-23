"""
DataBridge AI Agents Module.

This module provides AI-powered agents for intelligent workflow planning
and task execution.
"""

from .planner_agent import (
    PlannerAgent,
    PlannerConfig,
    PlannerCapability,
    PlannerState,
    AgentInfo,
    PlannedStep,
    WorkflowPlan,
    plan_workflow,
)

from .unified import (
    dispatch_planner_workflow,
    dispatch_planner_transform,
    dispatch_planner_manage,
    register_unified_planner_tools,
)

# PydanticAI agents (optional)
try:
    from .pydantic_agents import (
        PYDANTIC_AI_AVAILABLE,
        PlanOutput,
        PlanStepOutput,
        SQLOutput,
        run_planner_agent,
        run_sql_agent,
    )
except ImportError:
    PYDANTIC_AI_AVAILABLE = False  # type: ignore[misc]

__all__ = [
    "PlannerAgent",
    "PlannerConfig",
    "PlannerCapability",
    "PlannerState",
    "AgentInfo",
    "PlannedStep",
    "WorkflowPlan",
    "plan_workflow",
    # Unified (Phase 3D-2)
    "dispatch_planner_workflow",
    "dispatch_planner_transform",
    "dispatch_planner_manage",
    "register_unified_planner_tools",
    # PydanticAI (optional)
    "PYDANTIC_AI_AVAILABLE",
    "PlanOutput",
    "PlanStepOutput",
    "SQLOutput",
    "run_planner_agent",
    "run_sql_agent",
]
