"""Table Grouping CE plugin — group ERP tables by prefix or custom strategy."""
