-- ============================================================================
-- BLCE Snowflake Schema — v1 uses VARIANT pattern (single table + typed views)
-- Schema: EDW.BUSINESS_LOGIC_AI_PROCESS
-- ============================================================================

-- v1: Single VARIANT table for all BLCE artifacts (proven pattern from E2E v2)
CREATE TABLE IF NOT EXISTS EDW.BUSINESS_LOGIC_AI_PROCESS.BLCE_RUN_DATA (
    RUN_ID          VARCHAR(64)     NOT NULL,
    ARTIFACT_TYPE   VARCHAR(32)     NOT NULL,  -- 'logic_artifact', 'cross_reference', 'measure', 'grain_contract', 'evidence_sample', 'governance_decision', 'run_summary'
    ARTIFACT_ID     VARCHAR(64)     NOT NULL,
    CLIENT_ID       VARCHAR(64),
    DATA            VARIANT         NOT NULL,  -- Full JSON payload
    CREATED_AT      TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP(),
    CONSTRAINT pk_blce_run_data PRIMARY KEY (RUN_ID, ARTIFACT_TYPE, ARTIFACT_ID)
);

-- Model alteration log (Phase 14 — separate table for query efficiency)
CREATE TABLE IF NOT EXISTS EDW.BUSINESS_LOGIC_AI_PROCESS.BLCE_MODEL_ALTERATIONS (
    ALTERATION_ID       VARCHAR(64)     NOT NULL PRIMARY KEY,
    RUN_ID              VARCHAR(64)     NOT NULL,
    E2E_RUN_ID          VARCHAR(64),                -- Links back to Part 1
    ALTERATION_TYPE     VARCHAR(32)     NOT NULL,    -- rename_table, add_relationship, reclassify, add_measure
    TARGET_TABLE        VARCHAR(128),
    TARGET_COLUMN       VARCHAR(128),
    OLD_VALUE           VARIANT,
    NEW_VALUE           VARIANT,
    REASON              VARCHAR(2000),
    SOURCE_ARTIFACT_ID  VARCHAR(64),
    CONFIDENCE          FLOAT,
    APPLIED_AT          TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP(),
    REVERSED_AT         TIMESTAMP_NTZ               -- NULL if still active
);

-- Convenience views (split VARIANT by type)

CREATE OR REPLACE VIEW EDW.BUSINESS_LOGIC_AI_PROCESS.V_BLCE_LOGIC_ARTIFACTS AS
SELECT
    RUN_ID,
    ARTIFACT_ID,
    CLIENT_ID,
    DATA:source_type::VARCHAR       AS SOURCE_TYPE,
    DATA:source_path::VARCHAR       AS SOURCE_PATH,
    DATA:source_name::VARCHAR       AS SOURCE_NAME,
    DATA:confidence::FLOAT          AS CONFIDENCE,
    DATA:grain::VARCHAR             AS GRAIN,
    DATA:explanation::VARCHAR       AS EXPLANATION,
    ARRAY_SIZE(DATA:objects:measures)    AS MEASURE_COUNT,
    ARRAY_SIZE(DATA:objects:filters)     AS FILTER_COUNT,
    ARRAY_SIZE(DATA:objects:joins)       AS JOIN_COUNT,
    CREATED_AT
FROM EDW.BUSINESS_LOGIC_AI_PROCESS.BLCE_RUN_DATA
WHERE ARTIFACT_TYPE = 'logic_artifact';

CREATE OR REPLACE VIEW EDW.BUSINESS_LOGIC_AI_PROCESS.V_BLCE_CROSS_REFERENCES AS
SELECT
    RUN_ID,
    ARTIFACT_ID     AS XREF_ID,
    CLIENT_ID,
    DATA:domain::VARCHAR            AS DOMAIN,
    DATA:source_system::VARCHAR     AS SOURCE_SYSTEM,
    DATA:source_key::VARCHAR        AS SOURCE_KEY,
    DATA:target_system::VARCHAR     AS TARGET_SYSTEM,
    DATA:target_key::VARCHAR        AS TARGET_KEY,
    DATA:mapping_type::VARCHAR      AS MAPPING_TYPE,
    DATA:confidence::FLOAT          AS CONFIDENCE,
    DATA:rationale::VARCHAR         AS RATIONALE,
    CREATED_AT
FROM EDW.BUSINESS_LOGIC_AI_PROCESS.BLCE_RUN_DATA
WHERE ARTIFACT_TYPE = 'cross_reference';

CREATE OR REPLACE VIEW EDW.BUSINESS_LOGIC_AI_PROCESS.V_BLCE_MEASURES AS
SELECT
    RUN_ID,
    ARTIFACT_ID     AS MEASURE_ID,
    CLIENT_ID,
    DATA:canonical_name::VARCHAR    AS CANONICAL_NAME,
    DATA:business_name::VARCHAR     AS BUSINESS_NAME,
    DATA:definition::VARCHAR        AS DEFINITION,
    DATA:confidence::FLOAT          AS CONFIDENCE,
    ARRAY_SIZE(DATA:source_artifacts)   AS SOURCE_COUNT,
    CREATED_AT
FROM EDW.BUSINESS_LOGIC_AI_PROCESS.BLCE_RUN_DATA
WHERE ARTIFACT_TYPE = 'measure';

CREATE OR REPLACE VIEW EDW.BUSINESS_LOGIC_AI_PROCESS.V_BLCE_RUN_SUMMARIES AS
SELECT
    RUN_ID,
    CLIENT_ID,
    DATA:started_at::VARCHAR            AS STARTED_AT,
    DATA:completed_at::VARCHAR          AS COMPLETED_AT,
    DATA:duration_seconds::FLOAT        AS DURATION_SECONDS,
    DATA:source_files::INT              AS SOURCE_FILES,
    DATA:artifacts_extracted::INT       AS ARTIFACTS_EXTRACTED,
    DATA:measures_found::INT            AS MEASURES_FOUND,
    DATA:cross_references::INT          AS CROSS_REFERENCES,
    CREATED_AT
FROM EDW.BUSINESS_LOGIC_AI_PROCESS.BLCE_RUN_DATA
WHERE ARTIFACT_TYPE = 'run_summary';
