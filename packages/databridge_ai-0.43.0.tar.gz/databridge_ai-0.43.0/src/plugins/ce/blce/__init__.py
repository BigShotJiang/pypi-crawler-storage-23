"""BLCE — Business Logic Comprehension Engine (CE plugin)."""
