"""BLCE Known Report Pattern Library.

Provides pattern dictionaries for common ERP report types so
the ReportProcessor can match extracted KPIs/dimensions to
known structures.
"""
from __future__ import annotations

from typing import Dict, List


# ---------------------------------------------------------------------------
# Pattern definitions — expected measures/dimensions/grain per report type
# ---------------------------------------------------------------------------

REPORT_PATTERNS: Dict[str, Dict[str, object]] = {
    "lease_operating_statement": {
        "expected_measures": [
            "revenue", "royalties", "taxes", "deductions", "loe",
            "net_revenue", "operating_expense", "net_income",
        ],
        "expected_dimensions": ["well", "account", "date", "cost_center"],
        "expected_grain": "well x month x account",
        "keywords": ["los", "lease operating", "well economics", "loe"],
    },
    "income_statement": {
        "expected_measures": [
            "revenue", "cogs", "gross_profit", "operating_expense",
            "ebitda", "net_income", "depreciation", "amortization",
        ],
        "expected_dimensions": ["account", "date", "entity", "department"],
        "expected_grain": "account x month x entity",
        "keywords": ["income statement", "p&l", "profit and loss"],
    },
    "balance_sheet": {
        "expected_measures": [
            "assets", "liabilities", "equity", "current_assets",
            "current_liabilities", "retained_earnings",
        ],
        "expected_dimensions": ["account", "date", "entity"],
        "expected_grain": "account x period x entity",
        "keywords": ["balance sheet", "statement of position"],
    },
    "afe_tracker": {
        "expected_measures": [
            "budget_amount", "actual_amount", "variance",
            "committed", "remaining", "pct_complete",
        ],
        "expected_dimensions": ["afe", "well", "date", "vendor", "account"],
        "expected_grain": "afe x account x month",
        "keywords": ["afe", "authorization for expenditure", "capital tracker"],
    },
    "production_report": {
        "expected_measures": [
            "oil_volume", "gas_volume", "water_volume",
            "boe", "nri_volume", "gross_volume",
        ],
        "expected_dimensions": ["well", "date", "product", "property"],
        "expected_grain": "well x month x product",
        "keywords": ["production", "volumes", "boe", "oil and gas"],
    },
    "decline_curve": {
        "expected_measures": [
            "initial_rate", "decline_rate", "b_factor",
            "eur", "cumulative_production",
        ],
        "expected_dimensions": ["well", "date", "product"],
        "expected_grain": "well x month",
        "keywords": ["decline", "type curve", "eur", "reserves"],
    },
}


# ---------------------------------------------------------------------------
# Dimension keyword → target dimension name mapping
# ---------------------------------------------------------------------------

DIMENSION_KEYWORD_MAP: Dict[str, str] = {
    "well": "DIM_WELL",
    "account": "DIM_ACCOUNT",
    "date": "DIM_DATE",
    "month": "DIM_DATE",
    "period": "DIM_DATE",
    "product": "DIM_PRODUCT",
    "cost_center": "DIM_COST_CENTER",
    "entity": "DIM_ENTITY",
    "department": "DIM_DEPARTMENT",
    "vendor": "DIM_VENDOR",
    "owner": "DIM_OWNER",
    "property": "DIM_PROPERTY",
    "afe": "DIM_AFE",
    "purchaser": "DIM_PURCHASER",
    "meter": "DIM_METER",
    "area": "DIM_AREA",
    "basin": "DIM_BASIN",
    "field": "DIM_FIELD",
    "county": "DIM_COUNTY",
    "state": "DIM_STATE",
}


# ---------------------------------------------------------------------------
# Measure keyword → canonical measure name
# ---------------------------------------------------------------------------

MEASURE_KEYWORD_MAP: Dict[str, str] = {
    "revenue": "REVENUE",
    "net revenue": "NET_REVENUE",
    "royalties": "ROYALTIES",
    "taxes": "SEVERANCE_TAX",
    "deductions": "DEDUCTIONS",
    "loe": "LEASE_OPERATING_EXPENSE",
    "operating expense": "OPERATING_EXPENSE",
    "net income": "NET_INCOME",
    "ebitda": "EBITDA",
    "volume": "VOLUME",
    "oil": "OIL_VOLUME",
    "gas": "GAS_VOLUME",
    "water": "WATER_VOLUME",
    "boe": "BOE",
    "budget": "BUDGET_AMOUNT",
    "actual": "ACTUAL_AMOUNT",
    "variance": "VARIANCE",
}
