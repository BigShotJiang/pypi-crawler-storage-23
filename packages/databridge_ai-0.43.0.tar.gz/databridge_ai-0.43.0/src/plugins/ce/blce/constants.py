"""BLCE constants, enums, and thresholds."""
from __future__ import annotations

from enum import Enum


# ---------------------------------------------------------------------------
# Source types
# ---------------------------------------------------------------------------

class SourceType(str, Enum):
    """Type of source artifact ingested by BLCE."""
    SQL = "sql"
    PYTHON = "python"
    EXCEL = "excel"
    CSV = "csv"
    DAX = "dax"
    MDX = "mdx"
    PDF = "pdf"


# ---------------------------------------------------------------------------
# Logic object types
# ---------------------------------------------------------------------------

class MeasureAggregation(str, Enum):
    """SQL aggregation type for a measure."""
    SUM = "SUM"
    COUNT = "COUNT"
    COUNT_DISTINCT = "COUNT_DISTINCT"
    AVG = "AVG"
    MIN = "MIN"
    MAX = "MAX"
    CUSTOM = "CUSTOM"


class JoinType(str, Enum):
    """SQL join type."""
    INNER = "INNER"
    LEFT = "LEFT"
    RIGHT = "RIGHT"
    FULL = "FULL"
    CROSS = "CROSS"


class FilterOperator(str, Enum):
    """Operator used in a filter predicate."""
    EQ = "="
    NEQ = "!="
    GT = ">"
    GTE = ">="
    LT = "<"
    LTE = "<="
    IN = "IN"
    NOT_IN = "NOT IN"
    LIKE = "LIKE"
    IS_NULL = "IS NULL"
    IS_NOT_NULL = "IS NOT NULL"
    BETWEEN = "BETWEEN"


# ---------------------------------------------------------------------------
# Cross-reference mapping types
# ---------------------------------------------------------------------------

class MappingType(str, Enum):
    """How a cross-reference maps between systems."""
    DIRECT = "direct"           # Same grain, 1:1
    AGGREGATE = "aggregate"     # Child -> parent grain
    ALLOCATE = "allocate"       # Parent -> child with driver


# ---------------------------------------------------------------------------
# Governance classification
# ---------------------------------------------------------------------------

class ToolClassification(str, Enum):
    """Whether a tool/logic belongs to core platform or client-custom."""
    CORE = "core"
    CUSTOM = "custom"
    CANDIDATE = "candidate"     # Under review


# ---------------------------------------------------------------------------
# Confidence thresholds
# ---------------------------------------------------------------------------

CONFIDENCE_HIGH = 0.85
CONFIDENCE_MEDIUM = 0.60
CONFIDENCE_LOW = 0.30

# Minimum confidence to auto-promote a mapping
XREF_AUTO_PROMOTE_THRESHOLD = 0.70

# Maximum CTE depth for SQL parser
MAX_CTE_DEPTH = 10

# Maximum Excel formula nesting depth
MAX_FORMULA_DEPTH = 3

# Evidence sample defaults
EVIDENCE_SAMPLE_MONTHS = 2
EVIDENCE_SAMPLE_MAX_ROWS = 500


# ---------------------------------------------------------------------------
# Consultant intake sections
# ---------------------------------------------------------------------------

class IntakeSection(str, Enum):
    """Sections of the consultant intake questionnaire."""
    ORGANIZATION = "A"
    CURRENT_STATE = "B"
    BUSINESS_QUESTIONS = "C"
    DIMENSIONS = "D"
    DATA_QUALITY = "E"
    SECURITY = "F"
    FUTURE_STATE = "G"


# ---------------------------------------------------------------------------
# Report pattern types
# ---------------------------------------------------------------------------

class ReportPatternType(str, Enum):
    """Known report patterns from ERP systems."""
    LEASE_OPERATING_STATEMENT = "lease_operating_statement"
    INCOME_STATEMENT = "income_statement"
    BALANCE_SHEET = "balance_sheet"
    AFE_TRACKER = "afe_tracker"
    PRODUCTION_REPORT = "production_report"
    DECLINE_CURVE = "decline_curve"
    CUSTOM = "custom"
