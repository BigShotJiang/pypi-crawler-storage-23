"""Client Interaction Layer — Phase 15 of BLCE.

Deterministic tools that assemble structured context from BLCE infrastructure
so MCP clients can understand, query, and evolve their data models.
"""
from __future__ import annotations

from .skill_context_injector import SkillContextInjector, parse_change_description
from .query_builder import QueryBuilder
from .report_suggester import ReportSuggester
from .model_evolution import ModelEvolutionTracker

__all__ = [
    "SkillContextInjector",
    "QueryBuilder",
    "ReportSuggester",
    "ModelEvolutionTracker",
    "parse_change_description",
]
