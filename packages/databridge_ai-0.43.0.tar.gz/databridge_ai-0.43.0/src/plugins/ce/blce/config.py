"""BLCE configuration dataclass."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class BLCEConfig:
    """Configuration for a BLCE pipeline run."""

    # --- Identity ---
    client_id: str = ""
    run_id: str = ""

    # --- Source paths ---
    sql_paths: List[str] = field(default_factory=list)
    python_paths: List[str] = field(default_factory=list)
    excel_paths: List[str] = field(default_factory=list)
    csv_paths: List[str] = field(default_factory=list)
    dax_paths: List[str] = field(default_factory=list)
    mdx_paths: List[str] = field(default_factory=list)
    pdf_paths: List[str] = field(default_factory=list)

    # --- Parser settings ---
    sql_dialect: str = "snowflake"
    max_cte_depth: int = 10
    max_formula_depth: int = 3
    include_views: bool = True

    # --- Evidence sampling ---
    evidence_sample_months: int = 2
    evidence_sample_max_rows: int = 500
    mask_samples: bool = True               # Use DataShield masking

    # --- Snowflake (for persistence) ---
    dest_account: str = ""                  # e.g. "zf07542.south-central-us.azure"
    dest_database: str = "EDW"
    dest_schema: str = "BUSINESS_LOGIC_AI_PROCESS"

    # --- Persistence targets ---
    persist_to_graph: bool = True
    persist_to_snowflake: bool = True
    persist_to_file: bool = True
    output_dir: str = "data/blce_runs"

    # --- E2E handoff (if chaining Part 1 -> Part 2) ---
    e2e_run_id: Optional[str] = None
    e2e_run_dir: Optional[str] = None

    # --- Orchestrator ---
    skip_phases: List[str] = field(default_factory=list)
    parallel_groups: Optional[Dict[str, List[str]]] = None
    mode: str = "analyze_only"              # "analyze_only" | "full"

    # --- Runtime ---
    max_workers: int = 4                    # ThreadPoolExecutor pool size
    runtime_timeout: int = 300              # Per-task timeout (seconds)

    # --- Thresholds ---
    confidence_threshold: float = 0.60      # Below this, flag for AI enrichment
    xref_auto_promote: float = 0.70         # Above this, auto-accept cross-reference

    # --- Consultant intake ---
    intake_dir: str = ""
    questionnaire_path: str = ""
    meeting_notes_paths: List[str] = field(default_factory=list)
    report_paths: List[str] = field(default_factory=list)

    # --- Excel Logic Wizard ---
    excel_wizard_enabled: bool = True
    excel_wizard_use_copilot: bool = True
    excel_wizard_copilot_mode: str = "guarded"  # guarded | off
    excel_wizard_high_confidence_threshold: float = 0.80
    excel_wizard_review_threshold: float = 0.55
    excel_wizard_max_chunks: int = 2000
    excel_wizard_gateway_url: str = ""

    # --- Model generation ---
    erp_type_override: str = ""
    target_schema: str = "EDW"

    # --- Reconciliation ---
    reconciliation_enabled: bool = True
    reconciliation_tolerance_pct: float = 0.01
    reconciliation_jobs: List[Dict[str, Any]] = field(default_factory=list)
