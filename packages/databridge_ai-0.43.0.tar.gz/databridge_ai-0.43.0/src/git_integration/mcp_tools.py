"""
MCP Tools for Git/CI-CD Integration.

Provides 2 unified MCP tools:
- git: 8 actions (configure, status, commit, branch, push,
       generate_dbt_workflow, generate_deploy_workflow, generate_mart_workflow)
- github_pr: 4 actions (create, status, list, merge)
"""

import logging
from typing import Any, Dict

from .unified import (
    dispatch_git,
    dispatch_github_pr,
    register_unified_git_tools,
)

logger = logging.getLogger(__name__)


def register_git_integration_tools(mcp, settings=None) -> Dict[str, Any]:
    """Register all Git/CI-CD Integration MCP tools."""

    # Register the 2 unified tools
    register_unified_git_tools(mcp, settings)

    logger.info("Registered 2 Git MCP tools (2 unified)")
    return {
        "tools_registered": 2,
        "unified_tools": ["git", "github_pr"],
        "tools": [
            "git", "github_pr",
        ],
    }
