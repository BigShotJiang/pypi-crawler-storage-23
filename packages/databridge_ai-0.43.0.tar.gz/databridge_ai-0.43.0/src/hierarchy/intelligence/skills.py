"""Skill routing and baseline recommendation generators."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .contracts import RecommendationEvidence, RecommendationItem, SkillContext


@dataclass(frozen=True)
class Skill:
    name: str
    category: str


class SkillRouter:
    """Routes baseline system/industry/role skills for recommendations."""

    def route(self, ctx: SkillContext) -> List[Skill]:
        skills = [Skill(name=f"system:{ctx.system.lower()}", category="system")]
        skills.append(Skill(name=f"industry:{ctx.industry.lower()}", category="industry"))
        skills.append(Skill(name=f"role:{ctx.role.lower()}", category="role"))
        return skills


def recommend_report_pack(ctx: SkillContext) -> List[RecommendationItem]:
    role = ctx.role.lower()
    base = [
        RecommendationItem(
            id="report_pnl_driver_tree",
            title="P&L Driver Tree",
            rationale="Map revenue and cost hierarchies to explain margin movement.",
            impact="Improves executive visibility into profitability drivers.",
            risk="low",
            confidence=0.86,
            dependencies=["hierarchy dimensions", "fact mappings", "measure definitions"],
            evidence=[
                RecommendationEvidence(
                    source="internal",
                    reference=f"project:{ctx.project_id}",
                    confidence=0.85,
                    note="Hierarchy and mapping structure available.",
                )
            ],
        ),
        RecommendationItem(
            id="report_working_capital_waterfall",
            title="Working Capital Waterfall",
            rationale="Connect AR/AP/inventory hierarchies for cash conversion analysis.",
            impact="Supports CFO cash optimization initiatives.",
            risk="medium",
            confidence=0.8,
            dependencies=["AR/AP hierarchies", "inventory metrics", "aging facts"],
            evidence=[
                RecommendationEvidence(
                    source="internal",
                    reference=f"project:{ctx.project_id}",
                    confidence=0.78,
                    note="Requires complete receivable/payable mappings.",
                )
            ],
        ),
    ]
    if role == "cio":
        base.append(
            RecommendationItem(
                id="report_data_reliability_scorecard",
                title="Data Reliability Scorecard",
                rationale="Track latency, lineage coverage, and reconciliation pass rates.",
                impact="Improves governance and platform operating discipline.",
                risk="low",
                confidence=0.82,
                dependencies=["lineage metadata", "closure metrics"],
                evidence=[RecommendationEvidence(source="internal", reference="closure_metrics")],
            )
        )
    if role == "ceo":
        base.append(
            RecommendationItem(
                id="report_growth_margin_bridge",
                title="Growth vs Margin Bridge",
                rationale="Tie top-line growth to margin quality by business hierarchy.",
                impact="Supports strategic allocation decisions.",
                risk="medium",
                confidence=0.79,
                dependencies=["segment hierarchy", "sales and cost facts"],
                evidence=[RecommendationEvidence(source="internal", reference=f"project:{ctx.project_id}")],
            )
        )
    return base


def recommend_workflow_changes(ctx: SkillContext) -> List[RecommendationItem]:
    return [
        RecommendationItem(
            id="workflow_shift_left_reconciliation",
            title="Shift-Left Reconciliation Checks",
            rationale="Run discrepancy checks immediately after hierarchy/fact load.",
            impact="Reduces late-stage rework and improves trust.",
            risk="low",
            confidence=0.88,
            dependencies=["closure loop", "lineage trace"],
            evidence=[RecommendationEvidence(source="internal", reference="closure_loop")],
        ),
        RecommendationItem(
            id="workflow_semantic_release_gate",
            title="Semantic Release Gate",
            rationale="Require hierarchy/fact/measure contract validation before release.",
            impact="Improves executive confidence in metric consistency.",
            risk="medium",
            confidence=0.84,
            dependencies=["contract tests", "approval policy"],
            evidence=[RecommendationEvidence(source="internal", reference="test_suite")],
        ),
    ]

