"""Hierarchy intelligence advisory outputs (reports, process, executive)."""

from __future__ import annotations

from typing import Any, Dict, List

from .contracts import ExecutiveBrief, RecommendationItem, SkillContext
from .skills import SkillRouter, recommend_report_pack, recommend_workflow_changes


def suggest_reports(ctx: SkillContext) -> Dict[str, Any]:
    router = SkillRouter()
    skills = router.route(ctx)
    recs = recommend_report_pack(ctx)
    return {
        "status": "ok",
        "project_id": ctx.project_id,
        "role": ctx.role,
        "system": ctx.system,
        "industry": ctx.industry,
        "skills_applied": [s.name for s in skills],
        "report_candidates": [r.to_dict() for r in recs],
    }


def suggest_workflow_improvements(ctx: SkillContext) -> Dict[str, Any]:
    router = SkillRouter()
    skills = router.route(ctx)
    recs = recommend_workflow_changes(ctx)
    return {
        "status": "ok",
        "project_id": ctx.project_id,
        "role": ctx.role,
        "system": ctx.system,
        "industry": ctx.industry,
        "skills_applied": [s.name for s in skills],
        "improvements": [r.to_dict() for r in recs],
    }


def build_executive_brief(ctx: SkillContext) -> Dict[str, Any]:
    report_recs = [RecommendationItem(**r) if isinstance(r, dict) else r for r in recommend_report_pack(ctx)]
    workflow_recs = [RecommendationItem(**r) if isinstance(r, dict) else r for r in recommend_workflow_changes(ctx)]
    top = (report_recs + workflow_recs)[:8]

    role = ctx.role.lower()
    if role == "cio":
        summary = "Focus on governance, reliability, and scalable data operating model."
    elif role == "cfo":
        summary = "Focus on reconciliation, close acceleration, and financial trust controls."
    elif role == "ceo":
        summary = "Focus on growth, margin quality, and strategic performance levers."
    else:
        summary = "Balanced intelligence view across operations, trust, and business outcomes."

    brief = ExecutiveBrief(
        project_id=ctx.project_id,
        role=ctx.role,
        summary=summary,
        recommendations=top,
        guardrails=[
            "High-risk production actions require explicit approval.",
            "Recommendations without evidence should not be auto-executed.",
        ],
        citations=[e.reference for r in top for e in r.evidence],
    )
    return {"status": "ok", **brief.to_dict()}

