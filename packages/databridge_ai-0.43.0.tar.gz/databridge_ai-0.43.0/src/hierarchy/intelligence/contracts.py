"""Contracts for hierarchy intelligence recommendations."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any, Dict, List, Literal


RoleType = Literal["cio", "cfo", "ceo", "technical", "balanced"]


@dataclass
class SkillContext:
    project_id: str
    role: RoleType = "balanced"
    system: str = "unknown"
    industry: str = "general"
    objective: str = ""
    data_dir: str = "data"


@dataclass
class RecommendationEvidence:
    source: str
    reference: str
    confidence: float = 0.7
    note: str = ""


@dataclass
class RecommendationItem:
    id: str
    title: str
    rationale: str
    impact: str
    risk: str = "medium"
    confidence: float = 0.7
    dependencies: List[str] = field(default_factory=list)
    evidence: List[RecommendationEvidence] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["evidence"] = [asdict(e) for e in self.evidence]
        return payload


@dataclass
class ExecutiveBrief:
    project_id: str
    role: RoleType
    summary: str
    recommendations: List[RecommendationItem]
    guardrails: List[str] = field(default_factory=list)
    citations: List[str] = field(default_factory=list)
    generated_at_utc: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "project_id": self.project_id,
            "role": self.role,
            "summary": self.summary,
            "recommendations": [r.to_dict() for r in self.recommendations],
            "guardrails": list(self.guardrails),
            "citations": list(self.citations),
            "generated_at_utc": self.generated_at_utc,
        }

