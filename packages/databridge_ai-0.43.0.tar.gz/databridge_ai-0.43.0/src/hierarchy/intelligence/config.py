"""Configuration defaults for hierarchy intelligence."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class HierarchyIntelligenceConfig:
    hierarchy_rag_index_path: str = "data/hierarchy_rag/index.json"
    web_research_enabled: bool = False
    require_citations: bool = True
    high_risk_auto_execute_enabled: bool = False
    max_recommendations: int = 10

    def index_path(self) -> Path:
        return Path(self.hierarchy_rag_index_path)


DEFAULT_CONFIG = HierarchyIntelligenceConfig()

