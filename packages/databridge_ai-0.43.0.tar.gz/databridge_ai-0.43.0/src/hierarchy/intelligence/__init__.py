"""Hierarchy intelligence package: contracts, skills, and hierarchy-centric RAG."""

from .contracts import SkillContext, RecommendationEvidence, RecommendationItem, ExecutiveBrief
from .hierarchy_rag import build_hierarchy_rag, search_hierarchy_rag
from .skills import SkillRouter

__all__ = [
    "SkillContext",
    "RecommendationEvidence",
    "RecommendationItem",
    "ExecutiveBrief",
    "build_hierarchy_rag",
    "search_hierarchy_rag",
    "SkillRouter",
]

