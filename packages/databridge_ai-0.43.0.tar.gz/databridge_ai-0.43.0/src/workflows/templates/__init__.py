"""Workflow templates — reusable parameterised pipelines."""

from .full_platform_template import FullPlatformTemplate

__all__ = ["FullPlatformTemplate"]
