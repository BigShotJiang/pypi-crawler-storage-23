"""
MCP tools for the platform workflow orchestrator.

Provides 2 unified MCP tools:
- workflow_run: 2 modes (platform, e2e_assessment)
- workflow_manage: 4 actions (status, list_runs, list_phases, save_run)
"""

from __future__ import annotations

import logging
from typing import Any, Dict

from .unified import (
    dispatch_workflow_run,
    dispatch_workflow_manage,
    register_unified_workflow_tools,
)

logger = logging.getLogger(__name__)


def register_workflow_tools(mcp, mcp_settings):
    """Register all workflow MCP tools."""

    # Register the 2 unified tools
    register_unified_workflow_tools(mcp, mcp_settings)

    logger.info("Registered 2 workflow MCP tools")
    return {
        "tools_registered": 2,
        "unified_tools": ["workflow_run", "workflow_manage"],
        "tools": [
            "workflow_run", "workflow_manage",
        ],
    }
