# BLCE Analysis Templates

Reusable templates for running BLCE (Business Logic Comprehension Engine)
analysis on any client's Snowflake environment.

## Quick Start

1. **Configure**: Edit `config/analysis_config.json` with your connection details
2. **Run**: `python special_projects/run_enertia_blce_analysis.py`
3. **Review**: Check `data/blce_runs/<project>/` for results

## Structure

```
templates/blce_analysis/
├── README.md                  # This file
├── prompt_template.md         # Copy-paste prompt for Claude
├── config/
│   └── analysis_config.json   # Parameterized config
├── workflow/
│   ├── phase_01_extraction.md
│   ├── phase_02_lineage.md
│   ├── phase_03_blce_parse.md
│   ├── phase_04_hierarchy_wright.md
│   ├── phase_05_union_patterns.md
│   ├── phase_06_blce_engine.md
│   ├── phase_07_analysis.md
│   └── phase_08_templates.md
└── workings/
    ├── extraction/
    ├── lineage/
    ├── parsing/
    ├── analysis/
    └── recommendations/
```

## 8-Phase Pipeline

| Phase | Name | Description |
|-------|------|-------------|
| 1 | Extraction | DDL + column metadata from Snowflake |
| 2 | Lineage | Table reference tracing to source ERP |
| 3 | BLCE Parse | SQL parsing: measures, filters, joins, grain |
| 4 | Hierarchy & Wright | Wright naming + Kimball classification |
| 5 | Union Patterns | UNION/UNION ALL multi-source analysis |
| 6 | Engine Run | Normalizers, governance, skill generation |
| 7 | Analysis | Bus matrix, SWOT, quality, recommendations |
| 8 | Templates | Generate reusable templates |

## Requirements

- Python 3.10+
- DataBridge AI with BLCE module
- Snowflake CLI connection configured
- Access to target schemas

## First Run (Enertia)

The first run was performed on Aethon Energy's Enertia system:
- Connection: tc43062 (Aethon Energy Snowflake)
- Schemas: TRANSFORMATION.CORE_FINANCIAL, EDW.FINANCIAL, EDW.ANALYTICS
- Source: ENERTIA_RAW.ENERTIA_DBO (111 tables)
- Results: `data/blce_runs/enertia_analysis/`
