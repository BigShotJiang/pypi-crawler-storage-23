# Phase 6: Full BLCE Engine Run

## Objective
Run normalizers, governance, and skill generation.

## Steps
1. MeasureNormalizer — deduplicate measures
2. FilterNormalizer — find common filter patterns
3. GovernanceEngine — CORE/CUSTOM/CANDIDATE classification
4. SkillGenerator — auto-generate skills from CORE
5. (Optional) BLCEOrchestrator full run

## Outputs
- `phase_06_blce_engine.md`
- `artifacts/blce/normalized_measures.json`
- `artifacts/blce/governance_decisions.json`
