# Phase 5: UNION/UNION ALL Patterns

## Objective
Analyze UNION patterns for multi-source fact merging.

## Steps
1. Scan DDL for UNION/UNION ALL
2. Split into branches and identify sources per branch
3. Document pattern for reuse

## Outputs
- `phase_05_union_patterns.md`
