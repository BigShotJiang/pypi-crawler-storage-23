# Phase 3: BLCE Parsing

## Objective
Parse all DDL with BLCE SQLLogicExtractor.

## Steps
1. Initialize SQLLogicExtractor(dialect='snowflake')
2. Extract measures, filters, joins, grain from each DDL
3. Aggregate statistics and build measure inventory

## Outputs
- `phase_03_blce_parse.md` — per-object stats + global inventory
- `artifacts/blce/*.json` — per-object LogicArtifact
