# Phase 2: Lineage Tracing

## Objective
Trace table references in DDL back to source ERP tables.

## Steps
1. Parse FROM/JOIN clauses with regex
2. Build directed dependency graph
3. Identify CTE names to exclude
4. Calculate ENERTIA_DBO coverage

## Outputs
- `phase_02_lineage.md` — ASCII lineage tree + coverage
- `artifacts/lineage/lineage_graph.json`
