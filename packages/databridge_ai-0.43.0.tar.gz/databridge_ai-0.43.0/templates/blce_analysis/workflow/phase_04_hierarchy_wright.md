# Phase 4: Hierarchy & Wright Analysis

## Objective
Detect Wright naming patterns and classify objects as FACT/DIM.

## Steps
1. Check for Wright 4-object naming (VW_1_, DT_2_, DT_3A_, DT_3_)
2. Classify by column heuristics (dim/fact indicators)
3. Detect hierarchy-like columns

## Outputs
- `phase_04_hierarchy_wright.md`
