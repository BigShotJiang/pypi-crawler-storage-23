# Phase 1: Schema Extraction

## Objective
Extract DDL and column metadata from all target schemas.

## Steps
1. Query INFORMATION_SCHEMA.TABLES for each target schema
2. GET_DDL for each object (try VIEW first, fall back to TABLE)
3. Query INFORMATION_SCHEMA.COLUMNS for column metadata
4. Save DDL files to artifacts/ddl/

## Outputs
- `phase_01_extraction.md` — object inventory with column counts
- `artifacts/ddl/*.sql` — individual DDL files
- `artifacts/phase_01_extraction.json` — structured results
