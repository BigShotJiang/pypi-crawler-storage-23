# BLCE Analysis — Client Assessment Prompt

Use this prompt with Claude to run a complete BLCE analysis on a new client.

## Prerequisites

1. Snowflake CLI connection configured in `~/.snowflake/config.toml`
2. DataBridge AI project with BLCE module installed
3. Access to client's Snowflake schemas

## Prompt

```
I need to run a BLCE (Business Logic Comprehension Engine) analysis on
a new client's Snowflake environment.

**Connection Details:**
- Snowflake connection name: <CONNECTION_NAME>
- Warehouse: <WAREHOUSE_NAME>
- Target schemas to analyze:
  - <DATABASE_1>.<SCHEMA_1>
  - <DATABASE_2>.<SCHEMA_2>
- Source ERP schema: <SOURCE_DB>.<SOURCE_SCHEMA>

**Run the 8-phase BLCE analysis pipeline:**

1. **Schema Extraction** — Extract DDL and column metadata from target schemas
2. **Lineage Tracing** — Trace table references back to source ERP tables
3. **BLCE Parsing** — Parse all DDL with SQLLogicExtractor (measures, filters, joins, grain)
4. **Hierarchy & Wright** — Detect Wright naming patterns and Kimball classification
5. **UNION Patterns** — Analyze UNION/UNION ALL patterns for multi-source merging
6. **Engine Run** — Run normalizers, governance classification, and skill generation
7. **Analysis** — Bus matrix, SWOT, business rules, quality patterns, recommendations
8. **Templates** — Generate reusable templates for future analyses

Use the script at `special_projects/run_enertia_blce_analysis.py` as a reference.
Output results to `data/blce_runs/<project_name>/`.
```

## Expected Outputs

- 8 phase markdown summaries (`phase_01_*.md` through `phase_08_*.md`)
- `final_report.md` — executive summary
- `artifacts/ddl/` — individual DDL files
- `artifacts/blce/` — BLCE parsing artifacts (JSON)
- `artifacts/lineage/` — lineage graph (JSON)
- `artifacts/bus_matrix/` — bus matrix (JSON)

## Customization

Edit `templates/blce_analysis/config/analysis_config.json` to set:
- Snowflake connection name
- Target schemas
- Source ERP schema
- ERP type (for naming pattern detection)
- Output directory

## Example

```bash
# Run the analysis
python special_projects/run_enertia_blce_analysis.py

# Run specific phases only
python special_projects/run_enertia_blce_analysis.py --phases 1,2,3
```
