# rdsl

[![Release](https://img.shields.io/github/v/release/finlayiainmaclean/rdsl)](https://img.shields.io/github/v/release/finlayiainmaclean/rdsl)
[![Build status](https://img.shields.io/github/actions/workflow/status/finlayiainmaclean/rdsl/main.yml?branch=main)](https://github.com/finlayiainmaclean/rdsl/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/finlayiainmaclean/rdsl)](https://img.shields.io/github/commit-activity/m/finlayiainmaclean/rdsl)
[![License](https://img.shields.io/github/license/finlayiainmaclean/rdsl)](https://img.shields.io/github/license/finlayiainmaclean/rdsl)

This is a template repository for Python projects that use uv for their dependency management.
