"""Default configuration values and config loading utilities."""

from __future__ import annotations

from archex.models import Config, IndexConfig

DEFAULT_CONFIG = Config()

DEFAULT_INDEX_CONFIG = IndexConfig()

# TODO: Implement config loading from TOML/env in Phase 2
