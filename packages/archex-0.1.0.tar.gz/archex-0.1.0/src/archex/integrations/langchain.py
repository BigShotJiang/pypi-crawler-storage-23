"""LangChain integration: expose ArchProfile and ContextBundle as LangChain retrievers and tools."""

from __future__ import annotations

# TODO: Implement in Phase 4
