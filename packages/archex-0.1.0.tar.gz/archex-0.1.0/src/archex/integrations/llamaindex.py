"""LlamaIndex integration: wrap archex indexes as LlamaIndex QueryEngine and Index types."""

from __future__ import annotations

# TODO: Implement in Phase 4
