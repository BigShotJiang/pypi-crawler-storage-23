"""Integrations package: adapters for LangChain, LlamaIndex, and MCP tool protocols."""

from __future__ import annotations

# TODO: Implement in Phase 4
