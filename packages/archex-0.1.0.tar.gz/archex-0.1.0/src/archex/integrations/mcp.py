"""MCP integration: expose archex capabilities as Model Context Protocol tools."""

from __future__ import annotations

# TODO: Implement in Phase 4
