"""Index package: chunking, BM25, vector search, dependency graph, and unified store."""

from __future__ import annotations

# TODO: Implement in Phase 2
