"""Embeddings sub-package: base protocol and provider-specific implementations."""

from __future__ import annotations

from archex.index.embeddings.base import Embedder

__all__ = [
    "Embedder",
]
