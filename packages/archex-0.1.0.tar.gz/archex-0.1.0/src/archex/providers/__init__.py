"""Provider registry: resolve and instantiate LLM provider clients by name."""

from __future__ import annotations

# TODO: Implement in Phase 3
