from pypong import demo

demo()
