"""Trace renderers."""

from .console import render_trace

__all__ = ["render_trace"]
