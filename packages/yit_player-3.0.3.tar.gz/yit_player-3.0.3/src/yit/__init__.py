# Copyright (C) 2026 Vijayaraj Paramasivam. Licensed under the GNU GPLv3.

from .utils import __version__
from .cli import main

__all__ = ["__version__", "main"]
