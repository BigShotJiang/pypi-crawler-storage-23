ENG:

A Tool Python to Decompress/Compress AOV/ROV file with library Python Zstandard (pyzstd)

VI:

1 công cụ Python dùng để Giải mã hoá/Mã hoá tệp với thư viện Python Zstandard (pyzstd)



\# **Update 0.0.5**

ENG:

* Added new alias package "aovt"
* Fix bug

VI:

* Thêm tên gọi gói mới "aovt"
* Sửa lỗi



\# **Update 0.0.6**

ENG:

* Fix bug

VI:

* Sửa lỗi



\# **Update 0.0.7**

ENG:

* Fix bug

VI:

* Sửa lỗi
