from src.api.router.admin.router import get_router
