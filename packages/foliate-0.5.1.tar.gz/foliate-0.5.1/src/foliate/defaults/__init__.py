"""Bundled default resources for foliate."""
