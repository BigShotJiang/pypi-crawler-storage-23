from aixtools.utils.config_util import get_variable_env

DEFAULT_SKILL_SANDBOX_IMAGE = get_variable_env("DEFAULT_SKILL_SANDBOX_IMAGE", default="sandbox-linux-base")
DEFAULT_SKILL_SANDBOX_NETWORK = get_variable_env("DEFAULT_SKILL_SANDBOX_NETWORK", default="navari-net-isolated")
