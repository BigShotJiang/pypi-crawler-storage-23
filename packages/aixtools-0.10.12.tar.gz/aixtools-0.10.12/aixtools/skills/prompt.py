"""Skills related system prompt generation."""

from aixtools.skills.registry import SkillRegistry

SKILL_SYSTEM_PROMPT = """
# Skills

Available Skills:
_skill_list_

To activate the skill and get further instructions, use skill_activate(skill_name) tool and make decisions based on
retrieved information.
DO NOT try to activate a skill with skill_activate tool until you discovered that the skill is needed for the task.

## After Activation - Understanding Skill Type

Once you activate a skill, carefully examine the instructions to determine how to use it:

**If the skill instructions mention executable scripts** (e.g., `python3 ./scripts/foo.py`, files in `scripts/` dir):
- Use skill_exec(skill_name, command) to run those scripts in a sandbox container
- Commands run from working directory `/skills/<skill_name>/`
- Example: skill_exec("pptx", "python3 ./scripts/visual_preview.py assets/template.pptx /workspace/output")
- Use skill_read_file(skill_name, file_path) to read files from the skill directory (configs, assets, etc.)

**If the skill only provides guidance, templates, documentation, or examples** (no scripts/ directory mentioned):
- DO NOT try to use skill_exec or make up script commands
- Use skill_read_file(skill_name, file_path) to read reference materials (e.g., REFERENCE.md, examples)
- The skill is a knowledge resource, not an executable tool

**Important**: Never fabricate or assume scripts exist.
Only use skill_exec if the skill's instructions explicitly describe executable scripts.
"""


def get_skills_system_prompt(registry: SkillRegistry) -> str:
    """Generate a system prompt section describing available skills.

    Returns a formatted string that can be included in a system prompt to inform
    the LLM about available skills and how to use them.
    """
    skills = registry.list_skills()
    if not skills:
        return ""

    skills_list = [f"- {skill.name}: {skill.description}\n" for skill in skills]

    return SKILL_SYSTEM_PROMPT.replace("_skill_list_", "".join(skills_list))
