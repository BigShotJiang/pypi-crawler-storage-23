"""Archive file processor - handles multi-file archives."""

import tarfile
import zipfile
from collections.abc import Callable
from pathlib import Path

from aixtools.agents.context.data_models import FileExtractionResult, FileType
from aixtools.agents.context.processors.common import create_file_metadata, human_readable_size

# Multi-file archive extensions
MULTI_FILE_ARCHIVES = {".zip", ".tar", ".7z", ".rar"}


def _is_tar_archive(file_path: Path) -> bool:
    """Check if a .gz/.bz2/.xz file is actually a tar archive."""
    suffixes = [s.lower() for s in file_path.suffixes]
    if ".tar" in suffixes:
        return True

    # Try to open as tar
    suffix = file_path.suffix.lower()
    if suffix in {".gz", ".bz2", ".xz"}:
        try:
            with tarfile.open(file_path, "r:*"):
                return True
        except tarfile.TarError:
            return False

    return False


def _list_archive_files(file_path: Path, max_files: int = 50) -> tuple[list[tuple[str, int]], int]:
    """List files in an archive.

    Returns tuple of (list of (filename, size) tuples, total_count).
    Only returns up to max_files entries.
    """
    suffix = file_path.suffix.lower()
    entries: list[tuple[str, int]] = []
    total_count = 0

    try:
        if suffix == ".zip":
            with zipfile.ZipFile(file_path, "r") as zf:
                for info in zf.infolist():
                    if not info.is_dir():
                        total_count += 1
                        if len(entries) < max_files:
                            entries.append((info.filename, info.file_size))
        elif _is_tar_archive(file_path):
            with tarfile.open(file_path, "r:*") as tf:
                for member in tf.getmembers():
                    if member.isfile():
                        total_count += 1
                        if len(entries) < max_files:
                            entries.append((member.name, member.size))
    except Exception:
        # Gracefully handle corrupted archives or unsupported formats (7z, rar)
        pass

    return entries, total_count


def _sanitize_archive_path(name: str) -> str:
    """Sanitize archive member path for safe display.

    Removes path traversal sequences and absolute paths to prevent
    displaying potentially misleading or sensitive path information.
    """
    # Remove leading slashes and normalize path
    sanitized = name.lstrip("/\\")
    # Remove any .. components
    parts = []
    for part in sanitized.replace("\\", "/").split("/"):
        if part == "..":
            continue
        if part and part != ".":
            parts.append(part)
    return "/".join(parts) if parts else "(unnamed)"


def _format_file_list(entries: list[tuple[str, int]], total_count: int, max_shown: int) -> str:
    """Format file list for display."""
    if not entries:
        return ""

    lines = []
    for name, size in entries:
        sanitized_name = _sanitize_archive_path(name)
        size_str = human_readable_size(size)
        lines.append(f"  - {sanitized_name} ({size_str})")

    if total_count > max_shown:
        lines.append(f"  ... and {total_count - max_shown} more files")

    return "\n".join(lines)


def process_archive(
    file_path: Path,
    tokenizer: Callable[[str], int] | None = None,
    max_total_output: int | None = None,
    **kwargs,
) -> FileExtractionResult:
    """Process archive file - returns error with file listing.

    Args:
        file_path: Path to archive file
        tokenizer: Optional tokenizer function (unused)
        max_total_output: Maximum output length (unused)
        **kwargs: Additional arguments (unused)

    Returns:
        FileExtractionResult with error for archives, including file listing
    """
    suffix = file_path.suffix.lower()
    metadata = create_file_metadata(file_path)

    # Determine archive type for error message
    if suffix == ".zip":
        archive_type = "ZIP"
    elif _is_tar_archive(file_path):
        archive_type = "TAR"
    elif suffix == ".7z":
        archive_type = "7z"
    elif suffix == ".rar":
        archive_type = "RAR"
    else:
        archive_type = suffix.upper().lstrip(".")

    # List files in archive
    max_files_to_show = 50
    entries, total_count = _list_archive_files(file_path, max_files_to_show)
    file_list = _format_file_list(entries, total_count, max_files_to_show)

    # Get archive file size
    archive_size = human_readable_size(file_path.stat().st_size)

    if file_list:
        error_msg = (
            f"Cannot directly read {archive_type} archive ({archive_size}) containing {total_count} files.\n"
            f"Extract the archive first and read individual files.\n\n"
            f"Archive contents:\n{file_list}"
        )
    else:
        # 7z and RAR formats don't support content listing without external libraries
        error_msg = (
            f"Cannot directly read {archive_type} archive ({archive_size}). "
            f"Extract the archive first and read individual files."
        )

    return FileExtractionResult(
        content=None,
        success=False,
        error_message=error_msg,
        file_type=FileType.ARCHIVE,
        metadata=metadata,
    )
