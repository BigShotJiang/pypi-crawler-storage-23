"""
Run 4D relative seismic inversion (base and monitor).
The inversion parameters specified in the config file need field specific tuning.

The output is 4Drelai (in time) for each diffdate.

JRIV/EZA/RNYB
Adapted to fmu-sim2seis by HFLE
"""

import sys

from fmu.pem.pem_utilities import restore_dir
from fmu.sim2seis.utilities import (
    check_startup_dir,
    cube_export,
    parse_arguments,
    read_yaml_file,
    retrieve_result_objects,
)

from ._dump_results import _dump_results
from ._retrieve_results import retrieve_seismic_forward_results
from .depth_convert_rel_ai import depth_convert_ai
from .relative_seismic_inversion import run_relative_inversion_si4ti


def main(arguments=None):
    if arguments is None:
        arguments = sys.argv[1:]
    args = parse_arguments(
        arguments=arguments,
        extra_arguments=[
            "verbose",
            "global_dir",
            "global_file",
        ],
    )

    run_folder = check_startup_dir(args.config_dir)

    with restore_dir(run_folder):
        conf = read_yaml_file(
            sim2seis_config_dir=args.config_dir,
            sim2seis_config_file=args.config_file,
            global_config_dir=args.global_dir,
            global_config_file=args.global_file,
        )

        # Retrieve the seismic time cubes from seismic forward modelling
        seismic_time_cubes = retrieve_seismic_forward_results(config=conf)

        # Use python interface to relative seismic inversion
        rel_ai_time_dict = run_relative_inversion_si4ti(
            time_cubes=seismic_time_cubes,
            config=conf,
            config_dir=run_folder,
        )

        # Depth conversion, as the inversion is run in time domain
        velocity_model = retrieve_result_objects(
            input_path=conf.paths.pickle_file_output_dir,
            file_name=conf.pickle_file_prefix.seismic_forward + "_velocity_model.pkl",
        )
        rel_ai_depth_dict = depth_convert_ai(
            velocity_model=velocity_model,
            config=conf,
            difference_cubes=rel_ai_time_dict,
        )

        # Dump all resulting objects to pickle files
        _dump_results(
            config=conf,
            time_object=rel_ai_time_dict,
            depth_object=rel_ai_depth_dict,
        )

        # Export inverted depth converted cubes in segy format
        cube_export(
            config_file=conf,
            export_cubes=rel_ai_depth_dict,
            config_dir=run_folder,
            is_observed=False,
        )

        if args.verbose:
            print("Finished running seismic inversion")


if __name__ == "__main__":
    main()
