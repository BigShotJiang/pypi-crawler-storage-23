from pathlib import Path
from shutil import copy2, move as rename

import xtgeo
from seismic_forward.simulation import run_simulation

from fmu.sim2seis.utilities import (
    SeismicDate,
    SeismicName,
    Sim2SeisConfig,
    SingleSeismic,
)
from fmu.tools import DomainConversion


def exe_seismic_forward(
    config_file: Sim2SeisConfig,
    config_dir: Path,
    velocity_model: DomainConversion,
    verbose: bool = False,
) -> tuple[dict[SeismicName, SingleSeismic], dict[SeismicName, SingleSeismic]]:
    """
    Run seismic forward model, perform domain conversion on the depth
    cubes to time, return both depth and time cubes
    """

    depth_cubes = {}
    time_cubes = {}

    formatted_seis_dates = [
        str(s_date).replace("-", "") for s_date in config_file.global_params.mod_dates
    ]

    for date in formatted_seis_dates:
        # Copy the right vintage PEM output file to generic pem.grdecl
        copy2(
            src=config_file.paths.pem_output_dir / Path("pem--" + date + ".grdecl"),
            dst=config_file.paths.pem_output_dir / Path("pem.grdecl"),
        )

        if date == config_file.global_params.mod_dates[0]:
            # Generate a twt framework for the initial conditions
            model_file = config_dir / "model_file_twt.xml"
            result = run_simulation(model_file)
            assert result["success"]  # Success == True

        # Resolve the cubes directory once so subsequent path operations
        # are explicit and independent of the current working directory.
        cubes_dir = (config_dir / config_file.paths.modelled_seismic_dir).resolve()

        for stack, model in config_file.seismic_fwd.stack_models.items():
            result = run_simulation(model)
            assert result["success"]
            if verbose:
                print(result)

            # Modify name of synthetic seismic segy files output
            s_depth_src = cubes_dir / config_file.seismic_fwd.segy_depth
            depth_name_str = f"seismic--amplitude_{stack}_depth--{date}.segy"
            new_depth_name = SeismicName.parse_name(depth_name_str)
            s_depth_file = cubes_dir / depth_name_str
            rename(s_depth_src, s_depth_file)
            depth_cube = xtgeo.cube_from_file(s_depth_file)
            depth_cubes[new_depth_name] = SingleSeismic(
                from_dir=config_file.paths.modelled_seismic_dir,
                cube_name=new_depth_name,
                date=SeismicDate(date),
                cube=depth_cube,
            )
            # To get consistent depth/time conversion, we use the method in fmu-tools
            time_cube = velocity_model.time_convert_cube(
                incube=depth_cube,
                tinc=config_file.depth_conversion.t_inc,
                tmax=config_file.depth_conversion.max_time,
                tmin=config_file.depth_conversion.min_time,
            )
            time_name_str = f"seismic--amplitude_{stack}_time--{date}.segy"
            new_time_name = SeismicName.parse_name(time_name_str)
            time_cubes[new_time_name] = SingleSeismic(
                from_dir=config_file.paths.modelled_seismic_dir,
                cube_name=new_time_name,
                date=SeismicDate(date),
                cube=time_cube,
            )

    # return depth_cubes, time_cubes
    return depth_cubes, time_cubes


def read_time_and_depth_horizons(
    config: Sim2SeisConfig,
) -> tuple[dict[str, xtgeo.RegularSurface], dict[str, xtgeo.RegularSurface]]:
    """
    Read the time and depth surfaces that are listed in the configuration file
    for time/depth conversions
    """
    time_surfs = {}
    depth_surfs = {}
    for horizon in config.depth_conversion.horizon_names:
        time_name = config.paths.modelled_horizon_dir.joinpath(
            horizon.lower() + config.depth_conversion.time_suffix
        )
        time_surf = xtgeo.surface_from_file(str(time_name))
        time_surf.name = horizon
        time_surfs[time_name.name] = time_surf

        depth_name = config.depth_conversion.horizon_dir.joinpath(
            horizon.lower() + config.depth_conversion.depth_suffix
        )
        depth_surf = xtgeo.surface_from_file(str(depth_name))
        depth_surf.name = horizon
        depth_surfs[depth_name.name] = depth_surf

    return time_surfs, depth_surfs
