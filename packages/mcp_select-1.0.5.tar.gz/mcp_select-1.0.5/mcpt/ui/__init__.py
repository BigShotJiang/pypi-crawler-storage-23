"""UI components for MCPT CLI."""
