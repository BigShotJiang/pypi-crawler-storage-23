"""MCPT CLI - CLI for discovering and running MCP Tool Shop tools."""

__version__ = "1.0.3"
