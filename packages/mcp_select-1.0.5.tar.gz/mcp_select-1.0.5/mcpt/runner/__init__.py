"""Runner for MCP tools."""

from .stub import stub_run, generate_run_plan

__all__ = ["stub_run", "generate_run_plan"]
