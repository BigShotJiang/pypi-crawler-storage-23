# don't modify this file
import math
import re

from lxml import etree as ET

from pantoqa_bridge.server_synced_models.data_models.misc import BoxCoord, Coord

from .node_element import NodeElements


def get_box_center(coord: BoxCoord) -> Coord:
  """Return the center point (cx, cy) of the box."""
  divider = 2
  cx = int((coord.x1 + coord.x2) / divider)
  cy = int((coord.y1 + coord.y2) / divider)

  return Coord(x=cx, y=cy)


def distance_from_point(coords: BoxCoord, point: Coord) -> float:
  c = get_box_center(coords)
  return math.hypot(c.x - point.x, c.y - point.y)


def sort_by_distance(items: NodeElements, point: Coord) -> NodeElements:
  return sorted(items, key=lambda item: distance_from_point(item.coord, point))


def normalise_xml_dump(xml_dump: str) -> str | None:
  xml_root = ET.fromstring(xml_dump.encode('utf-8')) if xml_dump else None
  if xml_root is None:
    return None
  for node in xml_root.iter():
    class_attrib = node.attrib.get("class")
    if node.tag == "node" and class_attrib:
      try:
        node.tag = class_attrib
      except ValueError:
        node.tag = re.sub(r"[^a-zA-Z0-9_.-]", ".", class_attrib)
  normalise_xml_dump = ET.tostring(xml_root, encoding="unicode")
  return normalise_xml_dump
