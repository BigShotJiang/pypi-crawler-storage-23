from onlyone.core.models import BoostMode, DeduplicationMode

BOOST_ALIASES = {
    "size": BoostMode.SAME_SIZE,
    "extension": BoostMode.SAME_SIZE_PLUS_EXT,
    "filename": BoostMode.SAME_SIZE_PLUS_FILENAME,
    "fuzzy-filename": BoostMode.SAME_SIZE_PLUS_FUZZY_FILENAME,
    "fuzzy": BoostMode.SAME_SIZE_PLUS_FUZZY_FILENAME,
}

BOOST_CHOICES = list(BOOST_ALIASES.keys())

BOOST_HELP_TEXT = (
    "Initial file grouping criteria:\n"
    "  size       : Compare only files of the same size\n"
    "  extension  : Compare files of the same size and extension\n"
    "  filename   : Compare files of the same size and filename\n"
    "  fuzzy      : Compare files of the same size and similar filename\n"

    "Example    : %(prog)s -i ~/Downloads --boost filename -m 500K -M 10M -x .jpg\n"
)

DEDUP_MODE_ALIASES = {
    "normal": DeduplicationMode.NORMAL,
    "full": DeduplicationMode.FULL,
}

DEDUP_MODE_CHOICES = list(DEDUP_MODE_ALIASES.keys())

DEDUP_MODE_HELP_TEXT = (
    "Deduplication mode (depth of analysis):\n"
    "  normal             : Initial -> Front -> Middle -> End Hash (balanced)\n"
    "  full               : Initial -> Front -> Middle -> End -> Full Hash\n"
    "Example:\n"
    "  %(prog)s -i ~/Downloads --mode fast -m 500K -M 10M"
)

EPILOG_TEXT = """
Examples:
  Basic usage - find and show duplicates from Downloads folder
  %(prog)s -i ~/Downloads
  
  Find and show duplicates from Downloads, Documents and Videos folders:  
  `onlyone -i ~/Downloads ~/Documents ~/Videos`  
  
  Dry run with ascii-compilant output
  %(prog)s -i ~/Downloads --dry-run --ascii
  
  Filter files by size, exclude(^ inverts whitelist to blacklist) extensions jpg and png and find duplicates
  %(prog)s -i ~/Downloads -m 500KB -M 10MB -x ^ .jpg .png --dry-run

  Filter files by size and extensions and find duplicates
  %(prog)s -i ~/Downloads -m 500KB -M 10MB -x .jpg .png --dry-run
  
  Same as above + move duplicates to trash (with confirmation prompt)
  %(prog)s -i ~/Downloads -m 500KB -M 10MB -x .jpg .png --keep-one

  Same as above but without confirmation and with output to a file (for scripts)
  %(prog)s -i ~/Downloads -m 500KB -M 10MB -x .jpg .png --keep-one --force > ~/Downloads/report.txt
  
  Filter files by size, compare only files of the same filename
  %(prog)s -i ~/Downloads/ -m 1K -M 15M --boost filename
  
  For more information check official OnlyOne github page
"""
