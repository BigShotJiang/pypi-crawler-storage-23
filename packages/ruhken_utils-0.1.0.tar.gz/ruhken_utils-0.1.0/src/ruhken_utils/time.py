﻿import pandas as pd
from pandas import Timestamp

def current_time() -> Timestamp:
    return pd.Timestamp.now(tz='UTC')

def current_time_str() -> str:
    return current_time().isoformat()