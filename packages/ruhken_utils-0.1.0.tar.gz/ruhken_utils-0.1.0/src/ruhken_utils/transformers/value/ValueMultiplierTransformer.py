﻿from sklearn.base import BaseEstimator, TransformerMixin


class ValueMultiplierTransformer(BaseEstimator, TransformerMixin):
    """
    Multiplies the value of all features for each row and creates a new feature containing the result
    columns: array i.e. ['name', 'cabin', 'ticket', 'sex']
    """
    def __init__(self, columns):
        self.columns = columns

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()
        product = X[self.columns[0]].copy()
        for col in self.columns[1:]:
            product *= X[col]
        X["__".join(self.columns)] = product

        return X
