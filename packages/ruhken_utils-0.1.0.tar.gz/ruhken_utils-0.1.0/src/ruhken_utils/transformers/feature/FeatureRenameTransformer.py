﻿from sklearn.base import BaseEstimator, TransformerMixin


class FeatureRenameTransformer(BaseEstimator, TransformerMixin):
    """
    Rename DataFrame columns using a provided mapping inside an sklearn pipeline.

    The transformer validates that all keys of `rename_map` exist in `X.columns` and
    raises a ValueError otherwise.

    Parameters
    ----------
    rename_map : dict
        Mapping of old column name -> new column name.
    """
    def __init__(self, rename_map):
        """
        rename_map: dict mapping old feature names to new feature names
                    Example: {"BloodPressure": "blood_pressure",
                              "SkinThickness": "skin_thickness"}
        """
        self.rename_map = rename_map

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()

        missing_cols = set(self.rename_map.keys()) - set(X.columns)
        if missing_cols:
            raise ValueError(
                f"The following columns are not present in the DataFrame: {missing_cols}"
            )

        X = X.rename(columns=self.rename_map)
        return X
