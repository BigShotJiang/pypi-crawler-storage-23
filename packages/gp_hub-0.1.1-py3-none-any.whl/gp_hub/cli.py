from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Optional

from gp_hub.builder import build_package
try:
    from gp_hub.cloud_server import run_cloud_server
except ImportError:
    def run_cloud_server(*args, **kwargs):
        raise ImportError(
            "Flask is required for the serve-cloud command. "
            "Install it with: pip install gp_hub[cloud] or pip install flask"
        )
from gp_hub.config import get_default_cloud_url, get_default_repo_dir, get_default_target, load_config
from gp_hub.installer import (
    get_installed_package_info,
    install_package,
    list_installed_packages,
    search_installed_packages,
    uninstall_package,
)
from gp_hub.repository import (
    default_cloud_url,
    get_package_info_with_target,
    list_packages_with_target,
    publish_package,
    search_packages_with_target,
)


def build_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器。"""
    parser = argparse.ArgumentParser(
        prog="gp-hub",
        description="一个本地优先的极简包管理系统（MVP）",
    )
    sub = parser.add_subparsers(dest="command")

    # ========== build ==========
    p_build = sub.add_parser("build", help="构建当前项目为 tar.gz 包")
    p_build.add_argument("--project-dir", default=".", help="项目目录，默认当前目录")
    p_build.add_argument("--dist-dir", default="dist", help="构建输出目录，默认 dist")

    # ========== publish ==========
    p_publish = sub.add_parser("publish", help="发布构建产物到仓库（本地/云）")
    p_publish.add_argument("artifact", help="构建产物路径（tar.gz）")
    p_publish.add_argument("--target", choices=["local", "cloud"], default=None, help="发布目标，默认取配置")
    p_publish.add_argument("--repo-dir", default=None, help="本地仓库目录，默认 .gp_hub_repo")
    p_publish.add_argument("--cloud-url", default=None, help="云服务地址，默认取配置或 http://127.0.0.1:5000")
    p_publish.add_argument("--cloud-token", default=None, help="云服务鉴权 token（可选）")

    # ========== serve-cloud ==========
    p_serve_cloud = sub.add_parser("serve-cloud", help="启动本地模拟云服务（Flask）")
    p_serve_cloud.add_argument("--host", default="127.0.0.1", help="监听地址，默认 127.0.0.1")
    p_serve_cloud.add_argument("--port", type=int, default=5000, help="监听端口，默认 5000")
    p_serve_cloud.add_argument("--storage-dir", default=".gp_hub_cloud", help="云存储目录，默认 .gp_hub_cloud")
    p_serve_cloud.add_argument("--token", default=None, help="鉴权 token（可选）")

    # ========== install ==========
    p_install = sub.add_parser("install", help="从仓库安装包（本地/云）")
    p_install.add_argument("name", help="包名")
    p_install.add_argument("--version", default=None, help="安装指定版本")
    p_install.add_argument("--target", choices=["local", "cloud"], default=None, help="安装来源仓库类型，默认取配置")
    p_install.add_argument("--repo-dir", default=None, help="本地仓库目录，默认 .gp_hub_repo")
    p_install.add_argument("--cloud-url", default=None, help="云服务地址，默认取配置或 http://127.0.0.1:5000")
    p_install.add_argument("--cloud-token", default=None, help="云服务鉴权 token（可选）")
    p_install.add_argument("--project-dir", default=".", help="安装目标项目目录，默认当前目录")

    # ========== list ==========
    p_list = sub.add_parser("list", help="列出仓库中的所有包（本地/云）")
    p_list.add_argument("--target", choices=["local", "cloud"], default=None, help="仓库类型，默认取配置")
    p_list.add_argument("--repo-dir", default=None, help="本地仓库目录，默认 .gp_hub_repo")
    p_list.add_argument("--cloud-url", default=None, help="云服务地址，默认取配置或 http://127.0.0.1:5000")
    p_list.add_argument("--cloud-token", default=None, help="云服务鉴权 token（可选）")

    # ========== search ==========
    p_search = sub.add_parser("search", help="按关键字搜索仓库包（本地/云）")
    p_search.add_argument("query", help="搜索关键字（匹配 name/version）")
    p_search.add_argument("--target", choices=["local", "cloud"], default=None, help="仓库类型，默认取配置")
    p_search.add_argument("--repo-dir", default=None, help="本地仓库目录，默认 .gp_hub_repo")
    p_search.add_argument("--cloud-url", default=None, help="云服务地址，默认取配置或 http://127.0.0.1:5000")
    p_search.add_argument("--cloud-token", default=None, help="云服务鉴权 token（可选）")

    # ========== info ==========
    p_info = sub.add_parser("info", help="查看指定包的版本信息（本地/云）")
    p_info.add_argument("name", help="包名")
    p_info.add_argument("--target", choices=["local", "cloud"], default=None, help="仓库类型，默认取配置")
    p_info.add_argument("--repo-dir", default=None, help="本地仓库目录，默认 .gp_hub_repo")
    p_info.add_argument("--cloud-url", default=None, help="云服务地址，默认取配置或 http://127.0.0.1:5000")
    p_info.add_argument("--cloud-token", default=None, help="云服务鉴权 token（可选）")

    # ========== installed-list ==========
    p_installed_list = sub.add_parser("installed-list", help="列出当前项目已安装包")
    p_installed_list.add_argument("--project-dir", default=".", help="项目目录，默认当前目录")

    # ========== installed-search ==========
    p_installed_search = sub.add_parser("installed-search", help="按关键字搜索当前项目已安装包")
    p_installed_search.add_argument("query", help="搜索关键字（匹配 name/version）")
    p_installed_search.add_argument("--project-dir", default=".", help="项目目录，默认当前目录")

    # ========== installed-info ==========
    p_installed_info = sub.add_parser("installed-info", help="查看当前项目已安装包信息")
    p_installed_info.add_argument("name", help="包名")
    p_installed_info.add_argument("--project-dir", default=".", help="项目目录，默认当前目录")

    # ========== uninstall ==========
    p_uninstall = sub.add_parser("uninstall", help="卸载当前项目已安装包")
    p_uninstall.add_argument("name", help="包名")
    p_uninstall.add_argument("--version", default=None, help="卸载指定版本；不传则卸载该包全部已安装版本")
    p_uninstall.add_argument("--project-dir", default=".", help="项目目录，默认当前目录")

    return parser


def main() -> int:
    """命令行入口。"""
    parser = build_parser()
    args = parser.parse_args()
    config = load_config()

    resolved_target = _resolve_target(args, config)
    resolved_repo_dir = _resolve_repo_dir(args, config)
    resolved_cloud_url = _resolve_cloud_url(args, config)

    if args.command == "build":
        info = build_package(project_dir=args.project_dir, dist_dir=args.dist_dir)
        print("[build] ok")
        print("  name:", info.name)
        print("  version:", info.version)
        print("  artifact:", str(info.artifact_path))
        return 0

    if args.command == "publish":
        published = publish_package(
            artifact_path=args.artifact,
            repo_dir=resolved_repo_dir,
            target=resolved_target,
            cloud_url=resolved_cloud_url,
            cloud_token=args.cloud_token,
        )
        print("[publish] ok")
        print("  target:", resolved_target)
        print("  artifact:", str(Path(args.artifact).resolve()))
        print("  repo_path:", str(published))
        return 0

    if args.command == "serve-cloud":
        run_cloud_server(
            host=args.host,
            port=args.port,
            storage_dir=Path(args.storage_dir),
            token=args.token,
        )
        return 0

    if args.command == "install":
        result = install_package(
            package_name=args.name,
            version=args.version,
            repo_dir=resolved_repo_dir,
            project_dir=args.project_dir,
            target=resolved_target,
            cloud_url=resolved_cloud_url,
            cloud_token=args.cloud_token,
        )
        print("[install] ok")
        print("  target:", resolved_target)
        print("  name:", result.name)
        print("  version:", result.version)
        if result.source.target == "cloud" and result.source.url:
            display_source = result.source.url
        else:
            display_source = "%s/%s" % (result.source.repo.rstrip("/\\"), result.source.artifact)
        print("  source:", display_source)
        print("  source_target:", result.source.target)
        print("  source_repo:", result.source.repo)
        print("  install_dir:", str(result.install_dir))
        return 0

    if args.command == "list":
        rows = list_packages_with_target(
            repo_dir=resolved_repo_dir,
            target=resolved_target,
            cloud_url=resolved_cloud_url,
            cloud_token=args.cloud_token,
        )
        print("[list] ok")
        print("  target:", resolved_target)
        print(json.dumps({"packages": rows}, ensure_ascii=False, indent=2))
        return 0

    if args.command == "search":
        rows = search_packages_with_target(
            query=args.query,
            repo_dir=resolved_repo_dir,
            target=resolved_target,
            cloud_url=resolved_cloud_url,
            cloud_token=args.cloud_token,
        )
        print("[search] ok")
        print("  target:", resolved_target)
        print(json.dumps({"packages": rows}, ensure_ascii=False, indent=2))
        return 0

    if args.command == "info":
        info = get_package_info_with_target(
            package_name=args.name,
            repo_dir=resolved_repo_dir,
            target=resolved_target,
            cloud_url=resolved_cloud_url,
            cloud_token=args.cloud_token,
        )
        print("[info] ok")
        print("  target:", resolved_target)
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0

    if args.command == "installed-list":
        rows = list_installed_packages(project_dir=args.project_dir)
        print("[installed-list] ok")
        print("  project_dir:", str(Path(args.project_dir).resolve()))
        print(json.dumps({"packages": rows}, ensure_ascii=False, indent=2))
        return 0

    if args.command == "installed-search":
        rows = search_installed_packages(query=args.query, project_dir=args.project_dir)
        print("[installed-search] ok")
        print("  project_dir:", str(Path(args.project_dir).resolve()))
        print(json.dumps({"packages": rows}, ensure_ascii=False, indent=2))
        return 0

    if args.command == "installed-info":
        info = get_installed_package_info(package_name=args.name, project_dir=args.project_dir)
        print("[installed-info] ok")
        print("  project_dir:", str(Path(args.project_dir).resolve()))
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0

    if args.command == "uninstall":
        result = uninstall_package(
            package_name=args.name,
            version=args.version,
            project_dir=args.project_dir,
        )
        print("[uninstall] ok")
        print("  project_dir:", str(Path(args.project_dir).resolve()))
        print("  name:", result.get("name", ""))
        if args.version:
            print("  version:", args.version)
        print("  removed_count:", result.get("removed_count", 0))
        return 0

    parser.print_help()
    return 1


# ========== 默认值解析 ==========

def _resolve_target(args: argparse.Namespace, config: Dict[str, str]) -> str:
    cli_target = getattr(args, "target", None)
    if cli_target:
        return str(cli_target)
    return get_default_target(config)


def _resolve_repo_dir(args: argparse.Namespace, config: Dict[str, str]) -> Optional[str]:
    cli_repo_dir = getattr(args, "repo_dir", None)
    if cli_repo_dir:
        return str(cli_repo_dir)
    return get_default_repo_dir(config)


def _resolve_cloud_url(args: argparse.Namespace, config: Dict[str, str]) -> str:
    cli_cloud_url = getattr(args, "cloud_url", None)
    if cli_cloud_url:
        return str(cli_cloud_url)
    configured = get_default_cloud_url(config)
    if configured:
        return configured
    return default_cloud_url()


if __name__ == "__main__":
    raise SystemExit(main())
