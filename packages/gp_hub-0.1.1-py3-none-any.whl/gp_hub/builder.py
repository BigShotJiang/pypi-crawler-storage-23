from __future__ import annotations

import json
import re
import tarfile
from pathlib import Path
from typing import List, Union

from gp_hub.models import ArtifactInfo, PackageMeta


def read_project_meta(project_dir: Path) -> PackageMeta:
    """读取项目元信息（name/version）。"""
    pyproject_path = project_dir / "pyproject.toml"
    if not pyproject_path.exists():
        raise FileNotFoundError(f"未找到 pyproject.toml: {pyproject_path}")

    name = _read_value_from_project_section(pyproject_path, "name")
    version = _read_value_from_project_section(pyproject_path, "version")
    if not name or not version:
        raise ValueError("pyproject.toml 缺少 project.name 或 project.version")
    return PackageMeta(name=name, version=version)


def _read_value_from_project_section(pyproject_path: Path, key: str) -> str:
    """从 [project] 区块中读取简单 key="value" 字段。"""
    text = pyproject_path.read_text(encoding="utf-8")
    in_project = False
    key_pattern = re.compile(r'^\s*%s\s*=\s*["\']([^"\']+)["\']\s*$' % re.escape(key))
    section_pattern = re.compile(r"^\s*\[([^\]]+)]\s*$")

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue

        section_match = section_pattern.match(line)
        if section_match:
            in_project = section_match.group(1).strip() == "project"
            continue

        if not in_project:
            continue

        match = key_pattern.match(raw_line)
        if match:
            return match.group(1).strip()

    return ""


def _artifact_name(meta: PackageMeta) -> str:
    safe_name = meta.name.replace("-", "_")
    return f"{safe_name}-{meta.version}.tar.gz"


def build_package(project_dir: Union[Path, str] = ".", dist_dir: Union[Path, str] = "dist") -> ArtifactInfo:
    """构建简化包产物（tar.gz）。"""
    project_path = Path(project_dir).resolve()
    dist_path = Path(dist_dir)
    if not dist_path.is_absolute():
        dist_path = project_path / dist_path
    dist_path.mkdir(parents=True, exist_ok=True)

    meta = read_project_meta(project_path)
    artifact_path = dist_path / _artifact_name(meta)

    package_dir_name = meta.name.replace("-", "_")
    candidate_package_dir = project_path / package_dir_name
    include_paths = [project_path / "pyproject.toml"]  # type: List[Path]
    if (project_path / "README.md").exists():
        include_paths.append(project_path / "README.md")
    if candidate_package_dir.exists() and candidate_package_dir.is_dir():
        include_paths.append(candidate_package_dir)

    manifest = {
        "name": meta.name,
        "version": meta.version,
        "files": [p.name for p in include_paths],
    }

    with tarfile.open(artifact_path, "w:gz") as tar:
        metadata_json = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        info = tarfile.TarInfo(name="metadata.json")
        info.size = len(metadata_json)
        tar.addfile(info, fileobj=_BytesReader(metadata_json))

        for path in include_paths:
            if path.is_file():
                tar.add(path, arcname=f"source/{path.name}")
                continue
            for child in path.rglob("*"):
                if child.is_file():
                    arcname = child.relative_to(project_path)
                    tar.add(child, arcname=f"source/{arcname.as_posix()}")

    return ArtifactInfo(name=meta.name, version=meta.version, artifact_path=artifact_path)


class _BytesReader:
    """为 tarfile.addfile 提供最小 file-like 接口。"""

    def __init__(self, payload: bytes):
        self._payload = payload
        self._cursor = 0

    def read(self, size=-1):
        if size < 0:
            size = len(self._payload) - self._cursor
        chunk = self._payload[self._cursor : self._cursor + size]
        self._cursor += len(chunk)
        return chunk
