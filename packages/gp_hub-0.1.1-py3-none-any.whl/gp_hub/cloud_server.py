from __future__ import annotations

import base64
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from flask import Flask, Response, jsonify, request, send_file


INDEX_FILE = "index.json"


def create_app(storage_dir: Path, token: Optional[str] = None) -> Flask:
    """创建本地模拟云服务（HTTP）。"""
    app = Flask(__name__)
    app.config["STORAGE_DIR"] = storage_dir.resolve()
    app.config["TOKEN"] = token

    @app.get("/health")
    def health() -> Tuple[Dict[str, str], int]:
        return {"status": "ok"}, 200

    @app.post("/api/publish")
    def publish() -> Tuple[Any, int]:
        if not _is_authorized(app):
            return jsonify({"error": "unauthorized"}), 401

        payload = request.get_json(silent=True) or {}
        filename = str(payload.get("filename", ""))
        content_base64 = str(payload.get("content_base64", ""))
        if not filename or not content_base64:
            return jsonify({"error": "filename/content_base64 required"}), 400

        try:
            content = base64.b64decode(content_base64.encode("ascii"), validate=True)
        except Exception:
            return jsonify({"error": "invalid base64 content"}), 400

        try:
            artifact_rel_path = _store_artifact(
                app.config["STORAGE_DIR"],
                filename=filename,
                content=content,
            )
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400

        return jsonify({"ok": True, "artifact": artifact_rel_path}), 200

    @app.get("/api/list")
    def list_api() -> Tuple[Any, int]:
        if not _is_authorized(app):
            return jsonify({"error": "unauthorized"}), 401
        records = _package_records(app.config["STORAGE_DIR"])
        return jsonify({"packages": records}), 200

    @app.get("/api/search")
    def search_api() -> Tuple[Any, int]:
        if not _is_authorized(app):
            return jsonify({"error": "unauthorized"}), 401
        query = str(request.args.get("q", "")).strip().lower()
        records = _package_records(app.config["STORAGE_DIR"])
        if not query:
            return jsonify({"packages": records}), 200
        matched = [
            item
            for item in records
            if query in str(item.get("name", "")).lower() or query in str(item.get("version", "")).lower()
        ]
        return jsonify({"packages": matched}), 200

    @app.get("/api/info")
    def info_api() -> Tuple[Any, int]:
        if not _is_authorized(app):
            return jsonify({"error": "unauthorized"}), 401
        name = str(request.args.get("name", "")).strip()
        if not name:
            return jsonify({"error": "name required"}), 400
        normalized_name = name.replace("_", "-")
        records = _package_records(app.config["STORAGE_DIR"])
        matched = [item for item in records if str(item.get("name", "")).replace("_", "-") == normalized_name]
        if not matched:
            return jsonify({"error": "not found"}), 404
        versions = sorted(matched, key=lambda x: x.get("version", ""), reverse=True)
        return (
            jsonify(
                {
                    "name": normalized_name,
                    "latest_version": versions[0].get("version", ""),
                    "versions": versions,
                }
            ),
            200,
        )

    @app.get("/api/artifact")
    def artifact_api() -> Union[Tuple[Any, int], Response]:
        if not _is_authorized(app):
            return jsonify({"error": "unauthorized"}), 401
        name = str(request.args.get("name", "")).strip()
        version = str(request.args.get("version", "")).strip()
        if not name:
            return jsonify({"error": "name required"}), 400

        normalized_name = name.replace("_", "-")
        records = _package_records(app.config["STORAGE_DIR"])
        candidates = [item for item in records if str(item.get("name", "")).replace("_", "-") == normalized_name]
        if version:
            candidates = [item for item in candidates if str(item.get("version", "")) == version]
        if not candidates:
            return jsonify({"error": "not found"}), 404

        selected = sorted(candidates, key=lambda x: x.get("version", ""), reverse=True)[0]
        artifact_rel = str(selected.get("artifact", ""))
        artifact_path = app.config["STORAGE_DIR"] / artifact_rel
        if not artifact_path.exists():
            return jsonify({"error": "artifact missing"}), 404

        return Response(artifact_path.read_bytes(), mimetype="application/gzip")

    @app.get("/")
    def index() -> Response:
        """根路径重定向到 /browse"""
        from flask import redirect
        return redirect("/browse")

    @app.get("/browse")
    @app.get("/browse/<path:subpath>")
    def browse(subpath: str = "") -> str:
        """浏览存储目录内容。"""
        storage_dir = app.config["STORAGE_DIR"]
        
        # 构建当前浏览的路径
        if subpath:
            browse_path = storage_dir / subpath
            # 确保路径在存储目录内
            try:
                browse_path.resolve().relative_to(storage_dir.resolve())
            except ValueError:
                return "Invalid path", 400
        else:
            browse_path = storage_dir

        if not browse_path.exists():
            return "Not found", 404
        
        if browse_path.is_file():
            return send_file(browse_path)

        # 生成面包屑导航
        breadcrumbs = []
        if subpath:
            path_parts = subpath.split("/")
            for i, part in enumerate(path_parts):
                if i == 0:
                    breadcrumbs.append(f'<a href="/browse/{part}">{part}</a>')
                else:
                    parent_path = "/".join(path_parts[:i])
                    breadcrumbs.append(f'<a href="/browse/{parent_path}/{part}">{part}</a>')
        
        breadcrumb_html = " / ".join(["<a href='/browse'>Home</a>"] + breadcrumbs)
        
        # 读取目录内容
        items = []
        for item in sorted(browse_path.iterdir()):
            item_name = item.name
            item_link = f'/browse/{subpath}/{item_name}' if subpath else f'/browse/{item_name}'
            if item.is_dir():
                items.append(f'<div><a href="{item_link}">{item_name}/</a></div>')
            else:
                items.append(f'<div><a href="{item_link}">{item_name}</a></div>')
        
        # 生成HTML
        html = f"""
        <html>
        <head><title>GP Hub Cloud Storage</title></head>
        <body>
            <h1>GP Hub Cloud Storage</h1>
            <div style="margin-bottom: 20px;">
                <strong>Current Path:</strong> {breadcrumb_html}
            </div>
            <div>
                {''.join(items) if items else '<p>Empty directory</p>'}
            </div>
        </body>
        </html>
        """
        
        return html

    return app


def _is_authorized(app: Flask) -> bool:
    expected_token = app.config.get("TOKEN")
    if not expected_token:
        return True
    auth = request.headers.get("Authorization", "")
    return auth == "Bearer %s" % expected_token


def _store_artifact(storage_dir: Path, filename: str, content: bytes) -> str:
    name, version = _parse_artifact_filename(filename)
    package_dir = storage_dir / name / version
    package_dir.mkdir(parents=True, exist_ok=True)

    dst = package_dir / filename
    dst.write_bytes(content)

    index_data = _load_index(storage_dir)
    packages = index_data.setdefault("packages", [])
    record = {
        "name": name,
        "version": version,
        "artifact": str(dst.relative_to(storage_dir).as_posix()),
    }
    filtered = [
        item
        for item in packages
        if not (item.get("name") == record["name"] and item.get("version") == record["version"])
    ]
    filtered.append(record)
    index_data["packages"] = filtered
    _save_index(storage_dir, index_data)
    return record["artifact"]


def _parse_artifact_filename(filename: str) -> Tuple[str, str]:
    pattern = re.compile(r"^(?P<name>.+)-(?P<version>\d[\w\.-]*)\.tar\.gz$")
    match = pattern.match(filename)
    if not match:
        raise ValueError("产物文件名不符合约定: %s" % filename)
    return match.group("name").replace("_", "-"), match.group("version")


def _index_path(storage_dir: Path) -> Path:
    return storage_dir / INDEX_FILE


def _load_index(storage_dir: Path) -> Dict[str, Any]:
    path = _index_path(storage_dir)
    if not path.exists():
        return {"packages": []}
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict) or "packages" not in data:
        return {"packages": []}
    return data


def _package_records(storage_dir: Path) -> List[Dict[str, str]]:
    """读取并规范化仓库包记录。"""
    index_data = _load_index(storage_dir)
    records: List[Dict[str, str]] = []
    for item in index_data.get("packages", []):
        name = item.get("name")
        version = item.get("version")
        artifact = item.get("artifact")
        if not name or not version or not artifact:
            continue
        records.append(
            {
                "name": str(name).replace("_", "-"),
                "version": str(version),
                "artifact": str(artifact),
            }
        )
    return sorted(records, key=lambda x: (x.get("name", ""), x.get("version", "")), reverse=False)


def _save_index(storage_dir: Path, data: Dict[str, Any]) -> None:
    storage_dir.mkdir(parents=True, exist_ok=True)
    with _index_path(storage_dir).open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def run_cloud_server(host: str = "127.0.0.1", port: int = 5000, storage_dir: Path = Path(".gp_hub_cloud"), token: Optional[str] = None) -> None:
    """启动本地模拟云 HTTP 服务。"""
    app = create_app(storage_dir=storage_dir, token=token)
    app.run(host=host, port=port)
