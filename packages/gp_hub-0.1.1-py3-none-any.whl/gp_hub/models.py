from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class PackageMeta:
    """包元信息。"""

    name: str
    version: str


@dataclass(frozen=True)
class ArtifactInfo:
    """构建产物信息。"""

    name: str
    version: str
    artifact_path: Path


@dataclass(frozen=True)
class InstallInfo:
    """安装结果信息。"""

    name: str
    version: str
    artifact_path: Path
    install_dir: Path
    source: "InstallSource"


@dataclass(frozen=True)
class InstallSource:
    """安装来源信息。"""

    target: str
    repo: str
    artifact: str
    url: Optional[str] = None
