from __future__ import annotations

import base64
import json
import re
import shutil
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from gp_hub.models import ArtifactInfo


INDEX_FILE = "index.json"


def default_repo_dir() -> Path:
    """默认本地仓库目录。"""
    return Path(".gp_hub_repo").resolve()


def default_cloud_url() -> str:
    """默认本地云服务地址（用于模拟云端 HTTP 服务）。"""
    return "http://127.0.0.1:5000"


def _safe_name(name: str) -> str:
    return _normalize_name(name)


def _normalize_name(name: str) -> str:
    """统一包名，兼容下划线与中划线。"""
    return name.replace("_", "-")


def _parse_artifact_name(artifact_path: Path) -> ArtifactInfo:
    """从产物文件名解析 name/version。"""
    # 约定格式: <name>-<version>.tar.gz，version 必须以数字开头。
    pattern = re.compile(r"^(?P<name>.+)-(?P<version>\d[\w\.-]*)\.tar\.gz$")
    match = pattern.match(artifact_path.name)
    if not match:
        raise ValueError("产物文件名不符合约定: %s" % artifact_path.name)
    return ArtifactInfo(
        name=_normalize_name(match.group("name")),
        version=match.group("version"),
        artifact_path=artifact_path,
    )


def _index_path(repo_dir: Path) -> Path:
    return repo_dir / INDEX_FILE


def _load_index(repo_dir: Path) -> Dict[str, List[Dict[str, str]]]:
    path = _index_path(repo_dir)
    if not path.exists():
        return {"packages": []}
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict) or "packages" not in data:
        return {"packages": []}
    return data


def _save_index(repo_dir: Path, index_data: Dict[str, List[Dict[str, str]]]) -> None:
    path = _index_path(repo_dir)
    with path.open("w", encoding="utf-8") as f:
        json.dump(index_data, f, ensure_ascii=False, indent=2)


def _package_records(repo_dir: Path) -> List[Dict[str, str]]:
    """读取并规范化仓库包记录。"""
    index_data = _load_index(repo_dir)
    records: List[Dict[str, str]] = []
    for item in index_data.get("packages", []):
        name = item.get("name")
        version = item.get("version")
        artifact = item.get("artifact")
        if not name or not version or not artifact:
            continue
        records.append(
            {
                "name": _normalize_name(str(name)),
                "version": str(version),
                "artifact": str(artifact),
            }
        )
    return records


def _http_get_json(url: str, cloud_token: Optional[str] = None) -> Dict[str, Any]:
    req = urllib.request.Request(url, method="GET")
    if cloud_token:
        req.add_header("Authorization", "Bearer %s" % cloud_token)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="ignore")
        raise RuntimeError("云查询失败（HTTP %s）: %s" % (exc.code, body)) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("云查询失败，无法连接云服务: %s" % exc.reason) from exc
    data = json.loads(raw) if raw else {}
    if not isinstance(data, dict):
        raise RuntimeError("云查询失败：返回格式非法")
    return data


def _http_get_bytes(url: str, cloud_token: Optional[str] = None) -> bytes:
    req = urllib.request.Request(url, method="GET")
    if cloud_token:
        req.add_header("Authorization", "Bearer %s" % cloud_token)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.read()
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="ignore")
        raise RuntimeError("云下载失败（HTTP %s）: %s" % (exc.code, body)) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("云下载失败，无法连接云服务: %s" % exc.reason) from exc


def publish_package(
    artifact_path: Union[Path, str],
    repo_dir: Optional[Union[Path, str]] = None,
    target: str = "local",
    cloud_url: Optional[str] = None,
    cloud_token: Optional[str] = None,
) -> Path:
    """发布产物到目标仓库（local/cloud），并更新 index.json。"""
    src = Path(artifact_path).resolve()
    if not src.exists():
        raise FileNotFoundError("产物不存在: %s" % src)

    normalized_target = target.strip().lower()
    if normalized_target == "local":
        base_repo = Path(repo_dir).resolve() if repo_dir else default_repo_dir()
        return _publish_to_directory(src, base_repo)
    elif normalized_target == "cloud":
        endpoint = cloud_url or default_cloud_url()
        return _publish_to_cloud_http(src, endpoint, cloud_token)
    else:
        raise ValueError("不支持的 publish target: %s（仅支持 local/cloud）" % target)


def _publish_to_directory(src: Path, base_repo: Path) -> Path:
    parsed = _parse_artifact_name(src)
    package_repo_dir = base_repo / _safe_name(parsed.name) / parsed.version
    package_repo_dir.mkdir(parents=True, exist_ok=True)

    dst = package_repo_dir / src.name
    shutil.copy2(str(src), str(dst))

    index_data = _load_index(base_repo)
    packages = index_data.setdefault("packages", [])
    record = {
        "name": parsed.name,
        "version": parsed.version,
        "artifact": str(dst.relative_to(base_repo).as_posix()),
    }

    # 覆盖同名同版本记录
    filtered = [
        item
        for item in packages
        if not (item.get("name") == record["name"] and item.get("version") == record["version"])
    ]
    filtered.append(record)
    index_data["packages"] = filtered
    _save_index(base_repo, index_data)
    return dst


def _publish_to_cloud_http(src: Path, cloud_url: str, cloud_token: Optional[str]) -> Path:
    api_url = cloud_url.rstrip("/") + "/api/publish"
    payload = {
        "filename": src.name,
        "content_base64": base64.b64encode(src.read_bytes()).decode("ascii"),
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(api_url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if cloud_token:
        req.add_header("Authorization", "Bearer %s" % cloud_token)

    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="ignore")
        raise RuntimeError("云发布失败（HTTP %s）: %s" % (exc.code, body)) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("云发布失败，无法连接云服务: %s" % exc.reason) from exc

    result = json.loads(raw) if raw else {}
    artifact = result.get("artifact")
    if not artifact:
        raise RuntimeError("云发布失败：服务端返回缺少 artifact")
    return Path(str(artifact))


def list_packages(repo_dir: Optional[Union[Path, str]] = None) -> List[Dict[str, str]]:
    """列出仓库中所有包记录（name/version/artifact）。"""
    return list_packages_with_target(repo_dir=repo_dir)


def list_packages_with_target(
    repo_dir: Optional[Union[Path, str]] = None,
    target: str = "local",
    cloud_url: Optional[str] = None,
    cloud_token: Optional[str] = None,
) -> List[Dict[str, str]]:
    """按 target 列出仓库包记录。"""
    normalized_target = target.strip().lower()
    if normalized_target == "local":
        base_repo = Path(repo_dir).resolve() if repo_dir else default_repo_dir()
        records = _package_records(base_repo)
        return sorted(records, key=lambda x: (x.get("name", ""), x.get("version", "")), reverse=False)

    if normalized_target == "cloud":
        endpoint = (cloud_url or default_cloud_url()).rstrip("/") + "/api/list"
        data = _http_get_json(endpoint, cloud_token=cloud_token)
        rows = data.get("packages", [])
        if not isinstance(rows, list):
            return []
        records = [
            {
                "name": str(item.get("name", "")),
                "version": str(item.get("version", "")),
                "artifact": str(item.get("artifact", "")),
            }
            for item in rows
            if item.get("name") and item.get("version") and item.get("artifact")
        ]
        return sorted(records, key=lambda x: (x.get("name", ""), x.get("version", "")), reverse=False)

    raise ValueError("不支持的 target: %s（仅支持 local/cloud）" % target)


def search_packages(query: str, repo_dir: Optional[Union[Path, str]] = None) -> List[Dict[str, str]]:
    """按关键字搜索仓库包，匹配 name/version。"""
    return search_packages_with_target(query=query, repo_dir=repo_dir)


def search_packages_with_target(
    query: str,
    repo_dir: Optional[Union[Path, str]] = None,
    target: str = "local",
    cloud_url: Optional[str] = None,
    cloud_token: Optional[str] = None,
) -> List[Dict[str, str]]:
    """按 target 搜索仓库包，匹配 name/version。"""
    normalized_target = target.strip().lower()
    if normalized_target == "local":
        base_repo = Path(repo_dir).resolve() if repo_dir else default_repo_dir()
        keyword = query.strip().lower()
        records = _package_records(base_repo)
        if not keyword:
            return records
        matched = [
            item
            for item in records
            if keyword in item.get("name", "").lower() or keyword in item.get("version", "").lower()
        ]
        return sorted(matched, key=lambda x: (x.get("name", ""), x.get("version", "")), reverse=False)

    if normalized_target == "cloud":
        endpoint = (cloud_url or default_cloud_url()).rstrip("/") + "/api/search?q=%s" % urllib.parse.quote(query)
        data = _http_get_json(endpoint, cloud_token=cloud_token)
        rows = data.get("packages", [])
        if not isinstance(rows, list):
            return []
        records = [
            {
                "name": str(item.get("name", "")),
                "version": str(item.get("version", "")),
                "artifact": str(item.get("artifact", "")),
            }
            for item in rows
            if item.get("name") and item.get("version") and item.get("artifact")
        ]
        return sorted(records, key=lambda x: (x.get("name", ""), x.get("version", "")), reverse=False)

    raise ValueError("不支持的 target: %s（仅支持 local/cloud）" % target)


def get_package_info(
    package_name: str,
    repo_dir: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """获取单个包信息，包含所有版本及最新版本。"""
    return get_package_info_with_target(package_name=package_name, repo_dir=repo_dir)


def get_package_info_with_target(
    package_name: str,
    repo_dir: Optional[Union[Path, str]] = None,
    target: str = "local",
    cloud_url: Optional[str] = None,
    cloud_token: Optional[str] = None,
) -> Dict[str, Any]:
    """按 target 获取单个包信息，包含所有版本及最新版本。"""
    normalized_target = target.strip().lower()
    if normalized_target == "local":
        base_repo = Path(repo_dir).resolve() if repo_dir else default_repo_dir()
        normalized_name = _normalize_name(package_name)
        records = _package_records(base_repo)
        matched = [item for item in records if _normalize_name(item.get("name", "")) == normalized_name]
        if not matched:
            raise FileNotFoundError("仓库中未找到包: %s" % package_name)

        versions = sorted(matched, key=lambda x: x.get("version", ""), reverse=True)
        return {
            "name": normalized_name,
            "latest_version": versions[0].get("version", ""),
            "versions": versions,
        }

    if normalized_target == "cloud":
        endpoint = (cloud_url or default_cloud_url()).rstrip("/") + "/api/info?name=%s" % urllib.parse.quote(package_name)
        data = _http_get_json(endpoint, cloud_token=cloud_token)
        if not data.get("name"):
            raise FileNotFoundError("仓库中未找到包: %s" % package_name)
        return {
            "name": str(data.get("name")),
            "latest_version": str(data.get("latest_version", "")),
            "versions": data.get("versions", []),
        }

    raise ValueError("不支持的 target: %s（仅支持 local/cloud）" % target)


def find_artifact(
    package_name: str,
    version: Optional[str] = None,
    repo_dir: Optional[Union[Path, str]] = None,
    target: str = "local",
    cloud_url: Optional[str] = None,
    cloud_token: Optional[str] = None,
) -> Path:
    """在本地仓库查找产物，未指定 version 时取最新（按字符串排序）。"""
    normalized_target = target.strip().lower()
    if normalized_target == "local":
        base_repo = Path(repo_dir).resolve() if repo_dir else default_repo_dir()
        index_data = _load_index(base_repo)
        normalized_name = _normalize_name(package_name)
        candidates = [
            item
            for item in index_data.get("packages", [])
            if _normalize_name(item.get("name", "")) == normalized_name
        ]
        if version:
            candidates = [item for item in candidates if item.get("version") == version]
        if not candidates:
            raise FileNotFoundError("仓库中未找到包: %s %s" % (package_name, version or ""))

        selected = sorted(candidates, key=lambda x: x.get("version", ""), reverse=True)[0]
        return base_repo / selected["artifact"]

    if normalized_target == "cloud":
        target_info = get_package_info_with_target(
            package_name=package_name,
            target="cloud",
            cloud_url=cloud_url,
            cloud_token=cloud_token,
        )
        versions = target_info.get("versions", []) if isinstance(target_info, dict) else []
        selected = None
        if version:
            for item in versions:
                if str(item.get("version", "")) == version:
                    selected = item
                    break
        else:
            selected = versions[0] if versions else None

        if not selected:
            raise FileNotFoundError("仓库中未找到包: %s %s" % (package_name, version or ""))

        query_parts = ["name=%s" % urllib.parse.quote(package_name)]
        selected_version = str(selected.get("version", ""))
        if selected_version:
            query_parts.append("version=%s" % urllib.parse.quote(selected_version))
        endpoint = (cloud_url or default_cloud_url()).rstrip("/") + "/api/artifact?%s" % "&".join(query_parts)
        content = _http_get_bytes(endpoint, cloud_token=cloud_token)

        artifact_name = Path(str(selected.get("artifact", "artifact.tar.gz"))).name
        temp_dir = Path(tempfile.mkdtemp(prefix="gp_hub_artifact_"))
        temp_file = temp_dir / artifact_name
        temp_file.write_bytes(content)
        return temp_file

    raise ValueError("不支持的 target: %s（仅支持 local/cloud）" % target)
