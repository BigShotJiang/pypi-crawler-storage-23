from __future__ import annotations

import json
import shutil
import tarfile
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from gp_hub.models import InstallInfo, InstallSource
from gp_hub.repository import default_cloud_url, default_repo_dir, find_artifact, get_package_info_with_target


def install_package(
    package_name: str,
    version: Optional[str] = None,
    repo_dir: Optional[Union[Path, str]] = None,
    project_dir: Union[Path, str] = ".",
    target: str = "local",
    cloud_url: Optional[str] = None,
    cloud_token: Optional[str] = None,
) -> InstallInfo:
    normalized_target = target.strip().lower()
    normalized_name = _normalize_name(package_name)
    artifact_path = find_artifact(
        package_name=normalized_name,
        version=version,
        repo_dir=repo_dir,
        target=normalized_target,
        cloud_url=cloud_url,
        cloud_token=cloud_token,
    )

    project_path = Path(project_dir).resolve()
    packages_root = project_path / ".gp_hub" / "packages"
    resolved_version = _extract_version_from_artifact(artifact_path.name)
    install_dir = packages_root / normalized_name / resolved_version
    install_dir.mkdir(parents=True, exist_ok=True)

    with tarfile.open(str(artifact_path), "r:gz") as tar:
        tar.extractall(path=str(install_dir))

    source = _resolve_install_source(
        package_name=normalized_name,
        version=resolved_version,
        target=normalized_target,
        repo_dir=repo_dir,
        cloud_url=cloud_url,
        cloud_token=cloud_token,
    )
    install_info = InstallInfo(
        name=normalized_name,
        version=resolved_version,
        artifact_path=artifact_path,
        install_dir=install_dir,
        source=source,
    )
    _update_install_record(project_path, install_info)
    return install_info


def list_installed_packages(project_dir: Union[Path, str] = ".") -> List[Dict[str, Any]]:
    """列出当前项目已安装包记录。"""
    project_path = Path(project_dir).resolve()
    lock_path = project_path / ".gp_hub" / "installed.json"
    data = _load_lock(lock_path)
    records = _normalize_installed_records(data.get("installed", []))
    return sorted(records, key=lambda x: (x.get("name", ""), x.get("version", "")), reverse=False)


def search_installed_packages(query: str, project_dir: Union[Path, str] = ".") -> List[Dict[str, Any]]:
    """按关键字搜索当前项目已安装包，匹配 name/version。"""
    keyword = query.strip().lower()
    rows = list_installed_packages(project_dir=project_dir)
    if not keyword:
        return rows
    return [
        item
        for item in rows
        if keyword in item.get("name", "").lower() or keyword in item.get("version", "").lower()
    ]


def get_installed_package_info(package_name: str, project_dir: Union[Path, str] = ".") -> Dict[str, Any]:
    """获取单个已安装包信息，包含已安装版本及最新版本。"""
    normalized_name = _normalize_name(package_name)
    rows = list_installed_packages(project_dir=project_dir)
    matched = [item for item in rows if _normalize_name(item.get("name", "")) == normalized_name]
    if not matched:
        raise FileNotFoundError("已安装记录中未找到包: %s" % package_name)

    versions = sorted(matched, key=lambda x: x.get("version", ""), reverse=True)
    return {
        "name": normalized_name,
        "latest_version": versions[0].get("version", ""),
        "versions": versions,
    }


def uninstall_package(
    package_name: str,
    version: Optional[str] = None,
    project_dir: Union[Path, str] = ".",
) -> Dict[str, Any]:
    """卸载当前项目中的已安装包记录与目录。"""
    normalized_name = _normalize_name(package_name)
    normalized_version = version.strip() if isinstance(version, str) else None

    project_path = Path(project_dir).resolve()
    lock_path = project_path / ".gp_hub" / "installed.json"
    data = _load_lock(lock_path)
    records = data.get("installed", [])

    removed: List[Dict[str, str]] = []
    kept: List[Dict[str, str]] = []
    for item in records:
        item_name = _normalize_name(str(item.get("name", "")))
        item_version = str(item.get("version", ""))
        matched_name = item_name == normalized_name
        matched_version = normalized_version is None or item_version == normalized_version
        if matched_name and matched_version:
            removed.append(item)
            continue
        kept.append(item)

    if not removed:
        raise FileNotFoundError("已安装记录中未找到包: %s" % package_name)

    for item in removed:
        install_dir = str(item.get("install_dir", "")).strip()
        if not install_dir:
            continue
        install_path = Path(install_dir)
        if install_path.exists():
            shutil.rmtree(install_path, ignore_errors=True)

    data["installed"] = kept
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    return {
        "name": normalized_name,
        "version": normalized_version,
        "removed_count": len(removed),
        "removed": _normalize_installed_records(removed),
    }


def _extract_version_from_artifact(filename: str) -> str:
    no_suffix = filename[: -len(".tar.gz")] if filename.endswith(".tar.gz") else filename
    if "-" not in no_suffix:
        return "unknown"
    return no_suffix.rsplit("-", 1)[1]


def _update_install_record(
    project_path: Path,
    install_info: InstallInfo,
) -> None:
    lock_path = project_path / ".gp_hub" / "installed.json"
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    data = _load_lock(lock_path)
    records = data.setdefault("installed", [])
    record = {
        "name": install_info.name,
        "version": install_info.version,
        "source": {
            "target": install_info.source.target,
            "repo": install_info.source.repo,
            "artifact": install_info.source.artifact,
            "url": install_info.source.url,
        },
        "install_dir": str(install_info.install_dir),
    }
    filtered = [
        item
        for item in records
        if not (item.get("name") == record["name"] and item.get("version") == record["version"])
    ]
    filtered.append(record)
    data["installed"] = filtered

    with lock_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _load_lock(lock_path: Path) -> Dict[str, List[Dict[str, Any]]]:
    if not lock_path.exists():
        return {"installed": []}
    with lock_path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        return {"installed": []}
    if "installed" not in data or not isinstance(data.get("installed"), list):
        data["installed"] = []
    return data


def _normalize_installed_records(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    normalized: List[Dict[str, Any]] = []
    for item in rows:
        name = item.get("name")
        version = item.get("version")
        source = item.get("source")
        install_dir = item.get("install_dir")
        if not isinstance(source, dict):
            continue
        source_target = str(source.get("target", "")).strip().lower()
        source_repo = str(source.get("repo", "")).strip()
        source_artifact = str(source.get("artifact", "")).strip()
        source_url_raw = source.get("url")
        source_url = str(source_url_raw).strip() if source_url_raw else None
        if not name or not version:
            continue
        if source_target not in {"local", "cloud"}:
            continue
        if not source_repo or not source_artifact:
            continue
        normalized.append(
            {
                "name": _normalize_name(str(name)),
                "version": str(version),
                "source": {
                    "target": source_target,
                    "repo": source_repo,
                    "artifact": source_artifact,
                    "url": source_url,
                },
                "install_dir": str(install_dir or ""),
            }
        )
    return normalized


def _normalize_name(name: str) -> str:
    return name.replace("_", "-")


def _resolve_install_source(
    package_name: str,
    version: str,
    target: str,
    repo_dir: Optional[Union[Path, str]],
    cloud_url: Optional[str],
    cloud_token: Optional[str],
) -> InstallSource:
    if target != "cloud":
        base_repo = Path(repo_dir).resolve() if repo_dir else default_repo_dir()
        artifact = "%s/%s/%s-%s.tar.gz" % (package_name, version, package_name.replace("-", "_"), version)
        return InstallSource(target="local", repo=str(base_repo), artifact=artifact, url=None)

    endpoint_base = (cloud_url or default_cloud_url()).rstrip("/")
    package_info = get_package_info_with_target(
        package_name=package_name,
        target="cloud",
        cloud_url=cloud_url,
        cloud_token=cloud_token,
    )
    versions = package_info.get("versions", []) if isinstance(package_info, dict) else []
    for item in versions:
        if str(item.get("version", "")) == version:
            artifact = str(item.get("artifact", "")).strip()
            if artifact:
                url = endpoint_base + "/api/artifact?name=%s&version=%s" % (
                    urllib.parse.quote(package_name),
                    urllib.parse.quote(version),
                )
                return InstallSource(target="cloud", repo=endpoint_base, artifact=artifact, url=url)

    raise FileNotFoundError("云仓库中未找到安装来源: %s %s" % (package_name, version))
