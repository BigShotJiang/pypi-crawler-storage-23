from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Optional


CONFIG_FILE_NAME = "gp_hub.conf"


# ========== 配置文件发现与解析 ==========

def discover_config_path(cwd: Optional[Path] = None, home: Optional[Path] = None) -> Optional[Path]:
    """按优先级发现配置文件路径：当前目录优先，其次 HOME/.gp_hub。"""
    current_dir = (cwd or Path.cwd()).resolve()
    home_dir = (home or Path(os.path.expanduser("~"))).resolve()

    candidates = [
        current_dir / CONFIG_FILE_NAME,
        home_dir / ".gp_hub" / CONFIG_FILE_NAME,
    ]
    for path in candidates:
        if path.exists() and path.is_file():
            return path
    return None


def parse_config_text(content: str) -> Dict[str, str]:
    """解析 key=value 文本配置；支持空行与 # 注释。"""
    data: Dict[str, str] = {}
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if "#" in value:
            value = value.split("#", 1)[0].strip()
        if not key:
            continue
        if not value:
            continue
        data[key] = value
    return data


def load_config(cwd: Optional[Path] = None, home: Optional[Path] = None) -> Dict[str, str]:
    """加载配置文件，不存在时返回空字典。"""
    path = discover_config_path(cwd=cwd, home=home)
    if not path:
        return {}
    return parse_config_text(path.read_text(encoding="utf-8"))


# ========== 配置值读取 ==========

def get_default_target(config: Dict[str, str]) -> str:
    value = str(config.get("default_target", "")).strip().lower()
    return value if value in {"local", "cloud"} else "local"


def get_default_repo_dir(config: Dict[str, str]) -> Optional[str]:
    value = str(config.get("default_repo_dir", "")).strip()
    return value or None


def get_default_cloud_url(config: Dict[str, str]) -> Optional[str]:
    value = str(config.get("default_cloud_url", "")).strip()
    return value or None
