"""
Lumera SDK Integrations

Third-party service integrations with Lumera credential management.

Each integration module provides:
- A `get_*_client()` or `get_*_service()` function that returns an authenticated client
- Optional helper functions for common Lumera patterns

Quick start — use ``get_credentials`` for any provider::

    from lumera.integrations import get_credentials

    # Works for bearer tokens, basic auth, or any configured provider
    creds = get_credentials("my_provider")
    resp = requests.get(url, headers=creds.as_header_dict())

    # Inspect the credential type if needed
    if creds.type == "basic_auth":
        print(f"Authenticated as {creds.username}")

For Google services, use the dedicated helpers::

    from lumera.integrations import google

    sheets = google.get_sheets_service()
    drive = google.get_drive_service()

Legacy usage (still supported)::

    from lumera.integrations import get_access_token

    # Returns just the raw token string
    token = get_access_token("slack")

Available integrations:
- ``google`` - Google APIs (Sheets, Drive)

Utilities:
- ``get_credentials(provider)`` - Get a ``Credentials`` object with auth type, ready-to-use headers, and metadata (recommended)
- ``get_access_token(provider)`` - Get raw token string for any Lumera-connected provider (backward compatible)
- ``Credentials`` - Dataclass returned by ``get_credentials()``
"""

from .._utils import Credentials, get_access_token, get_credentials
from . import google

__all__ = ["Credentials", "get_access_token", "get_credentials", "google"]
