"""
File input types for Lumera automations.

These types are used with Pydantic models to define file inputs for automations.
They generate the correct JSON schema format that the frontend recognizes for
file picker UI.

Example:
    from pydantic import BaseModel, Field
    from lumera import LumeraFile, LumeraFiles

    class ProcessInputs(BaseModel):
        report: LumeraFile = Field(..., description="Excel report to process")
        attachments: LumeraFiles = Field(default=[], description="Additional files")

    def main(inputs: ProcessInputs):
        # inputs.report is a string path like "/tmp/lumera-files/report.xlsx"
        with open(inputs.report) as f:
            ...
"""

from typing import Annotated, Any

# Check if Pydantic is available
try:
    from pydantic import GetJsonSchemaHandler
    from pydantic.json_schema import JsonSchemaValue
    from pydantic_core import CoreSchema

    _HAS_PYDANTIC = True
except ImportError:
    _HAS_PYDANTIC = False


if _HAS_PYDANTIC:

    class _LumeraFileSchema:
        """
        Pydantic JSON schema handler for single file inputs.

        Generates: {"type": "string", "format": "file"}

        The frontend recognizes this schema and renders a file picker.
        At runtime, the value is a string path to the downloaded file.
        """

        @classmethod
        def __get_pydantic_json_schema__(
            cls, core_schema: CoreSchema, handler: GetJsonSchemaHandler
        ) -> JsonSchemaValue:
            return {"type": "string", "format": "file"}

    class _LumeraFilesSchema:
        """
        Pydantic JSON schema handler for multiple file inputs.

        Generates: {"type": "array", "items": {"type": "string", "format": "file"}}

        The frontend recognizes this schema and renders a multi-file picker.
        At runtime, the value is a list of string paths to downloaded files.
        """

        @classmethod
        def __get_pydantic_json_schema__(
            cls, core_schema: CoreSchema, handler: GetJsonSchemaHandler
        ) -> JsonSchemaValue:
            return {"type": "array", "items": {"type": "string", "format": "file"}}

    # Public types using Annotated to attach schema handlers
    LumeraFile: Any = Annotated[str, _LumeraFileSchema()]
    """
    Type for single file input in Pydantic models.

    At runtime, this is a string containing the local file path.
    In JSON schema, generates {"type": "string", "format": "file"}.

    Example:
        class Inputs(BaseModel):
            document: LumeraFile = Field(..., description="PDF to process")
    """

    LumeraFiles: Any = Annotated[list[str], _LumeraFilesSchema()]
    """
    Type for multiple file inputs in Pydantic models.

    At runtime, this is a list of strings containing local file paths.
    In JSON schema, generates {"type": "array", "items": {"type": "string", "format": "file"}}.

    Example:
        class Inputs(BaseModel):
            documents: LumeraFiles = Field(default=[], description="PDFs to merge")
    """

else:
    # Fallback when Pydantic is not installed - types are just aliases
    LumeraFile: Any = str
    LumeraFiles: Any = list
