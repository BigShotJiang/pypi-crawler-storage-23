"""
Email sending for Lumera automations.

Send transactional emails through the Lumera platform using AWS SES infrastructure.
Emails are logged to the lm_email_logs collection for auditing and debugging.

Functions:
    send()  - Send an email with HTML/text content and optional attachments

Example:
    >>> from lumera import email
    >>>
    >>> # Send a simple email
    >>> result = email.send(
    ...     to="user@example.com",
    ...     subject="Welcome to Lumera!",
    ...     body_html="<h1>Hello!</h1><p>Welcome aboard.</p>"
    ... )
    >>> print(result.message_id)
    >>>
    >>> # Send with attachments
    >>> result = email.send(
    ...     to="user@example.com",
    ...     subject="Monthly Report",
    ...     body_html="<p>See attached report.</p>",
    ...     attachments=[
    ...         "/tmp/lumera-files/report.pdf",
    ...         {"object_key": "pb/col/rec/field/data.xlsx"},
    ...     ]
    ... )
"""

from __future__ import annotations

import base64
import mimetypes
import os
from typing import Any

from ._utils import _api_request

__all__ = [
    "send",
    "SendResult",
]

_MAX_ATTACHMENTS = 10


class SendResult:
    """Result of sending an email.

    Attributes:
        message_id: The unique identifier from AWS SES for the sent email.
        log_id: The PocketBase record ID in lm_email_logs for auditing.
    """

    def __init__(self, data: dict[str, Any]):
        self.message_id: str = data.get("message_id", "")
        self.log_id: str = data.get("log_id", "")
        self._raw = data

    def __repr__(self) -> str:
        return f"SendResult(message_id={self.message_id!r}, log_id={self.log_id!r})"


def send(
    to: list[str] | str,
    subject: str,
    *,
    body_html: str | None = None,
    body_text: str | None = None,
    cc: list[str] | str | None = None,
    bcc: list[str] | str | None = None,
    from_address: str | None = None,
    from_name: str | None = None,
    reply_to: str | None = None,
    tags: dict[str, str] | None = None,
    attachments: list[str | dict[str, Any]] | None = None,
) -> SendResult:
    """Send an email.

    At least one of body_html or body_text must be provided. If only body_html
    is provided, a plain text version will be auto-generated.

    Args:
        to: Recipient email address(es). Can be a single string or list.
        subject: Email subject line.
        body_html: HTML body content (optional if body_text provided).
        body_text: Plain text body content (optional, auto-generated from HTML).
        cc: CC recipient(s) (optional).
        bcc: BCC recipient(s) (optional).
        from_address: Sender email address (optional, uses platform default).
        from_name: Sender display name (optional, uses platform default).
        reply_to: Reply-to address (optional).
        tags: Custom key-value pairs for tracking/filtering in logs (optional).
        attachments: File attachments (optional, max 10). Each item can be:
            - A file path string (reads file, auto-detects MIME type)
            - A dict with "object_key" (references existing file in storage)
            - A dict with "filename", "data" (base64 string), and optional "content_type"

    Returns:
        SendResult with message_id and log_id.

    Raises:
        ValueError: If required fields are missing or invalid.
        LumeraAPIError: If the API request fails.

    Example:
        >>> # Simple email
        >>> result = email.send(
        ...     to="user@example.com",
        ...     subject="Password Reset",
        ...     body_html="<p>Click <a href='...'>here</a> to reset.</p>"
        ... )
        >>>
        >>> # Email with attachments
        >>> result = email.send(
        ...     to="user@example.com",
        ...     subject="Report",
        ...     body_html="<p>See attached.</p>",
        ...     attachments=[
        ...         "/tmp/lumera-files/report.pdf",
        ...         {"object_key": "pb/col/rec/field/data.xlsx"},
        ...         {"filename": "note.txt", "data": "SGVsbG8=", "content_type": "text/plain"},
        ...     ]
        ... )
    """
    # Normalize to lists
    to_list = [to] if isinstance(to, str) else list(to) if to else []
    cc_list = [cc] if isinstance(cc, str) else (list(cc) if cc else None)
    bcc_list = [bcc] if isinstance(bcc, str) else (list(bcc) if bcc else None)

    # Validate
    if not to_list:
        raise ValueError("at least one recipient is required")
    if not subject or not subject.strip():
        raise ValueError("subject is required")
    if not body_html and not body_text:
        raise ValueError("at least one of body_html or body_text is required")

    # Normalize and validate attachments
    att_list = _normalize_attachments(attachments) if attachments else None

    # Build payload
    payload: dict[str, Any] = {
        "to": to_list,
        "subject": subject.strip(),
    }

    if body_html:
        payload["body_html"] = body_html
    if body_text:
        payload["body_text"] = body_text
    if cc_list:
        payload["cc"] = cc_list
    if bcc_list:
        payload["bcc"] = bcc_list
    if from_address:
        payload["from"] = from_address.strip()
    if from_name:
        payload["from_name"] = from_name.strip()
    if reply_to:
        payload["reply_to"] = reply_to.strip()
    if tags:
        payload["tags"] = tags
    if att_list:
        payload["attachments"] = att_list

    result = _api_request("POST", "email/send", json_body=payload)
    if not isinstance(result, dict):
        raise RuntimeError("unexpected response from email/send")

    return SendResult(result)


def _normalize_attachments(
    attachments: list[str | dict[str, Any]],
) -> list[dict[str, Any]]:
    """Normalize attachment inputs into API-ready dicts.

    Accepts:
      - str: local file path → read, base64-encode, detect MIME
      - dict with "object_key": pass through as-is
      - dict with "filename" + "data": pass through (validate)
    """
    if len(attachments) > _MAX_ATTACHMENTS:
        raise ValueError(
            f"too many attachments: {len(attachments)} (max {_MAX_ATTACHMENTS})"
        )

    result: list[dict[str, Any]] = []

    for i, att in enumerate(attachments):
        if isinstance(att, str):
            # File path
            result.append(_file_path_to_attachment(att, i))
        elif isinstance(att, dict):
            if "object_key" in att and "data" in att:
                raise ValueError(
                    f"attachment {i}: provide either 'data' or 'object_key', not both"
                )
            if "object_key" in att:
                # S3 object key reference — pass through
                entry: dict[str, Any] = {"object_key": att["object_key"]}
                if "filename" in att:
                    entry["filename"] = att["filename"]
                if "content_type" in att:
                    entry["content_type"] = att["content_type"]
                result.append(entry)
            elif "data" in att:
                # Inline base64 data
                if "filename" not in att:
                    raise ValueError(
                        f"attachment {i}: 'filename' is required when providing inline data"
                    )
                entry = {
                    "filename": att["filename"],
                    "data": att["data"],
                }
                if "content_type" in att:
                    entry["content_type"] = att["content_type"]
                result.append(entry)
            else:
                raise ValueError(
                    f"attachment {i}: must provide either 'data' or 'object_key'"
                )
        else:
            raise ValueError(
                f"attachment {i}: expected str (file path) or dict, got {type(att).__name__}"
            )

    return result


_MAX_ATTACHMENT_FILE_SIZE = 10 * 1024 * 1024  # 10 MB (SES raw message limit)


def _file_path_to_attachment(file_path: str, index: int) -> dict[str, Any]:
    """Read a local file and convert to an inline attachment dict."""
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"attachment {index}: file not found: {file_path}")

    file_size = os.path.getsize(file_path)
    if file_size > _MAX_ATTACHMENT_FILE_SIZE:
        raise ValueError(
            f"attachment {index}: file too large ({file_size // (1024 * 1024)} MB), "
            f"max {_MAX_ATTACHMENT_FILE_SIZE // (1024 * 1024)} MB"
        )

    content_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
    filename = os.path.basename(file_path)

    with open(file_path, "rb") as f:
        data = f.read()

    return {
        "filename": filename,
        "content_type": content_type,
        "data": base64.b64encode(data).decode("ascii"),
    }
