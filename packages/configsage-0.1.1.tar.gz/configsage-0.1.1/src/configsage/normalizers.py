"""
Normalization helper functions callable by the schema to align the values for a checking.
Other normalization functions can be added by the developer using the library, according to the needs.
These functions can be called on the needed value by the schema in schema.py
"""

import configsage.common_decorators as cdec
from configsage.config_callables import wrap_name_fmt 

@cdec.wrap_with_name(formatter=wrap_name_fmt)
def trim_lower(value: str) -> str:
    """
    Trim and convert to lower the characters only if it's a string
    Params:
        value(str): value to trim and convert
    Returns:
        the modifed string or the value as is if not a string
    """
    if isinstance(value, str):
        return value.strip().lower()
    return value
