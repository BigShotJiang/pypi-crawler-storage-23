"""
Callables (functions) used to configure functionalities across the whole package
"""

def wrap_name_fmt(name: str, e: Exception) -> str: 
    """
    Callable to format the output
    Params:
        name(str): function name
        e(Exception): error, can be any type of it
    Returns:
        The formatted string
    """
    return f"[{name}] -> {e!r}"