"""
Validation functions callable by the schema to validate the config values.
Other validation functions can be added by the developer using the library, according to the needs.
These functions can be called on the needed value by the schema in schema.py
"""

import os

import configsage.common_decorators as cdec
from configsage.config_callables import wrap_name_fmt 


@cdec.wrap_with_name(formatter=wrap_name_fmt)
def ensure_nonempty(value: str) -> None:
    """
    Validates the value exists
    Params:
        value(str): value to verify, it must have a value
    Returns:
        None
    Raises: 
        ValueError if the value is empty
    """
    if value is None or (isinstance(value, str) and value.strip() == ""):
        raise ValueError("value cannot be empty")

@cdec.wrap_with_name(formatter=wrap_name_fmt)
def path_exists(value: str) -> None:
    """
    Validates the path exists
    Params:
        value(str): path to verify, it must exist
    Returns:
        None
    Raises: 
        ValueError if the folder pointed by the path does not exist
    """
    # You can relax this for cross-platform tests or inject a base dir as needed
    if not isinstance(value, str) or not os.path.exists(value):
        raise ValueError(f"path does not exist: {value!r}")