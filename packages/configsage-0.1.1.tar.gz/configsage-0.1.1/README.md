# ConfigSage
`configsage` is a `pyyaml` wrapper converting the configuration parameters taken by a *yaml* file in a *python* object.  
The object reflects the *yaml* hierarchy, allowing the access to the items by a dotted notation.  

!!! example
    The following example shows a simple *yaml* configuration file with all the use-cases and how they can be accessed by *python* using the `configsage` as configuration parser.  

    ```yaml
    ```
    