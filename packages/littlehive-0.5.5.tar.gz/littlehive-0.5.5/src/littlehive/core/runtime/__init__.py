"""Runtime stubs."""
