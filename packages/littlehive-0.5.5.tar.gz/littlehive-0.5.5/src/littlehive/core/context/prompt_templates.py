"""Prompt template placeholders."""
