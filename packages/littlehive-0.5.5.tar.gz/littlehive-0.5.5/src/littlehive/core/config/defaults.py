from __future__ import annotations

from pathlib import Path


def default_config_path() -> Path:
    return Path("config/defaults.yaml")
