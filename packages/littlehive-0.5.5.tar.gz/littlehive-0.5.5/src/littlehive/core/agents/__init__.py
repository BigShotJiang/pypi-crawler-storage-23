"""Agent stubs."""
