"""Admin/operator service surface for dashboard and APIs."""

from littlehive.core.admin.service import AdminService

__all__ = ["AdminService"]
