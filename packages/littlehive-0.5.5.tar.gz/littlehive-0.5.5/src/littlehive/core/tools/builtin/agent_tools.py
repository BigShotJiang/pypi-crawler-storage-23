"""Reserved for future cross-agent helper tools."""
