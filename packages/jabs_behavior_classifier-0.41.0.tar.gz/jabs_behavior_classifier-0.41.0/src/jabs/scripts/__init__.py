"""jabs scripts module"""
