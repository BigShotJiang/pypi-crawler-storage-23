"""Package for jabs-cli command

Note: jabs-cli is the preferred location for new command line functionality, and
  existing stand-alone scripts may be migrated here over time.
"""

from .cli import main
