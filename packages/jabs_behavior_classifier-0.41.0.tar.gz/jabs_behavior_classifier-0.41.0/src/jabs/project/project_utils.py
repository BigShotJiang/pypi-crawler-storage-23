from jabs.core.utils import to_safe_name

__all__ = ["to_safe_name"]
