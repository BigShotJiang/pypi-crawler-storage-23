# these are settings keys stored in QSettings for the JABS GUI
LICENSE_ACCEPTED_KEY = "license_accepted"
LICENSE_VERSION_KEY = "license_version"
RECENT_PROJECTS_KEY = "recent_projects"
SESSION_TRACKING_ENABLED_KEY = "session_tracking_enabled"
WINDOW_SIZE_KEY = "main_window_size"
