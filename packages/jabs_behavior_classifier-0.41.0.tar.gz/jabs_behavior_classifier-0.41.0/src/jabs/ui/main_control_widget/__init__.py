"""JABS Main Control Widget"""

from .main_control_widget import MainControlWidget

__all__ = ["MainControlWidget"]
