from lsusd.cli import main

main()
