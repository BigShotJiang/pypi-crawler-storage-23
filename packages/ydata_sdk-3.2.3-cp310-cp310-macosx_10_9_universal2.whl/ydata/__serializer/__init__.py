from ydata.__serializer.serializer import SerializerMixin

__all__ = [
    "SerializerMixin",
]
