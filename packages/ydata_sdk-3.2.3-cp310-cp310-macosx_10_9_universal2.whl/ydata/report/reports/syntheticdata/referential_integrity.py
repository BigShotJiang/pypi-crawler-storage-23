"""Referential Integrity Validator for synthetic multi-table data.

This module provides validation for referential integrity in synthetic multi-table datasets,
checking primary key uniqueness/nullability and foreign key referential integrity.
"""
from dask import compute
from pandas import DataFrame
from pandas.api.types import is_numeric_dtype

from ydata.dataset import MultiDataset
from ydata.metadata import MultiMetadata
from ydata.report.logger import logger


class ReferentialIntegrityValidator:
    """Validator for referential integrity in synthetic multi-table datasets.
    
    This class validates:
    1. Primary Key constraints: uniqueness and non-nullability
    2. Foreign Key constraints: orphan records (FKs that don't reference valid PKs)
    3. Relationship quality metrics: parent coverage, children per parent, etc.
    
    Args:
        synthetic_data (MultiDataset): The synthetic multi-table dataset to validate
        metadata (MultiMetadata): Metadata object containing schema information
    """
    
    def __init__(self, synthetic_data: MultiDataset, metadata: MultiMetadata):
        self.synthetic_data = synthetic_data
        self.metadata = metadata
        self.schema = metadata.schema
        
    def validate(self) -> dict:
        """Run validation and return comprehensive results.
        
        Returns:
            dict: Validation results with structure:
            {
                "summary": {
                    "total_pk_violations": int,
                    "total_fk_violations": int,
                    "pk_integrity_score": float,  # 0-1
                    "fk_integrity_score": float,  # 0-1
                    "overall_integrity_score": float  # 0-1
                },
                "tables": {
                    "table_name": {
                        "primary_keys": {
                            "violations": int,
                            "total_rows": int,
                            "violation_rate": float,
                            "is_valid": bool,
                            "duplicate_count": int,
                            "null_count": int
                        },
                        "foreign_keys": {
                            "fk_column": {
                                "orphan_count": int,
                                "total_rows": int,
                                "orphan_rate": float,
                                "is_valid": bool,
                                "parent_coverage": float,
                                "avg_children_per_parent": float,
                                "orphan_parents_count": int,
                                "cardinality_preserved": bool
                            }
                        }
                    }
                }
            }
        """
        logger.info("[REFERENTIAL_INTEGRITY] - Starting validation")
        
        results = {
            "summary": {
                "total_pk_violations": 0,
                "total_fk_violations": 0,
                "pk_integrity_score": 1.0,
                "fk_integrity_score": 1.0,
                "overall_integrity_score": 1.0
            },
            "tables": {}
        }
        
        # Validate each table
        for table_name in self.schema.keys():
            if table_name not in self.synthetic_data:
                logger.warning(f"[REFERENTIAL_INTEGRITY] - Table {table_name} not found in synthetic data")
                continue
                
            table_results = {
                "primary_keys": {},
                "foreign_keys": {}
            }
            
            # Validate primary keys
            pk_results = self._validate_primary_keys(table_name)
            table_results["primary_keys"] = pk_results
            results["summary"]["total_pk_violations"] += pk_results["violations"]
            
            # Validate foreign keys
            fk_results = self._validate_foreign_keys(table_name)
            table_results["foreign_keys"] = fk_results
            for fk_col, fk_data in fk_results.items():
                results["summary"]["total_fk_violations"] += fk_data["orphan_count"]
            
            results["tables"][table_name] = table_results
        
        # Calculate summary scores
        total_tables = len([t for t in results["tables"].values() if t["primary_keys"]])
        if total_tables > 0:
            pk_violation_rate = results["summary"]["total_pk_violations"] / max(
                sum(t["primary_keys"].get("total_rows", 0) for t in results["tables"].values() if t["primary_keys"]), 1
            )
            results["summary"]["pk_integrity_score"] = max(0.0, 1.0 - pk_violation_rate)
        
        total_fk_rows = sum(
            fk_data.get("total_rows", 0)
            for table in results["tables"].values()
            for fk_data in table["foreign_keys"].values()
        )
        if total_fk_rows > 0:
            fk_violation_rate = results["summary"]["total_fk_violations"] / total_fk_rows
            results["summary"]["fk_integrity_score"] = max(0.0, 1.0 - fk_violation_rate)
        
        # Overall score is the average of PK and FK scores
        results["summary"]["overall_integrity_score"] = (
            results["summary"]["pk_integrity_score"] + results["summary"]["fk_integrity_score"]
        ) / 2.0
        
        logger.info(f"[REFERENTIAL_INTEGRITY] - Validation complete. Overall score: {results['summary']['overall_integrity_score']:.2f}")
        
        return results
    
    def _validate_primary_keys(self, table_name: str) -> dict:
        """Validate primary keys for a table.
        
        Args:
            table_name: Name of the table to validate
            
        Returns:
            dict: PK validation results
        """
        table_schema = self.schema.get(table_name)
        if not table_schema or not table_schema.primary_keys:
            return {}
        
        dataset = self.synthetic_data[table_name]
        total_rows = len(dataset)
        
        if total_rows == 0:
            return {
                "violations": 0,
                "total_rows": 0,
                "violation_rate": 0.0,
                "is_valid": True,
                "duplicate_count": 0,
                "null_count": 0
            }
        
        # Convert to dask for efficient computation
        dask_df = dataset.to_dask()
        
        # Check for nulls and duplicates
        pk_columns = table_schema.primary_keys
        
        # Handle single vs multiple PK columns
        if len(pk_columns) == 1:
            pk_col = pk_columns[0]
            pk_series = dask_df[pk_col]
            
            # Count nulls
            null_count = pk_series.isna().sum().compute()
            
            # Count duplicates (including nulls in duplicate count)
            non_null_series = pk_series.dropna()
            unique_count = non_null_series.nunique().compute()
            total_non_null = len(non_null_series)
            duplicate_count = total_non_null - unique_count if total_non_null > 0 else 0
            
        else:
            # Composite primary key
            pk_df = dask_df[pk_columns]
            
            # Count nulls (any null in any PK column makes the row invalid)
            null_count = pk_df.isna().any(axis=1).sum().compute()
            
            # Count duplicates
            non_null_df = pk_df.dropna()
            unique_count = non_null_df.drop_duplicates().shape[0].compute()
            total_non_null = non_null_df.shape[0].compute()
            duplicate_count = total_non_null - unique_count if total_non_null > 0 else 0
        
        violations = int(null_count) + int(duplicate_count)
        violation_rate = violations / total_rows if total_rows > 0 else 0.0
        
        return {
            "violations": violations,
            "total_rows": total_rows,
            "violation_rate": violation_rate,
            "is_valid": violations == 0,
            "duplicate_count": int(duplicate_count),
            "null_count": int(null_count)
        }
    
    def _validate_foreign_keys(self, table_name: str) -> dict:
        """Validate foreign keys for a table.
        
        Args:
            table_name: Name of the table to validate
            
        Returns:
            dict: FK validation results per foreign key column
        """
        table_schema = self.schema.get(table_name)
        if not table_schema or not table_schema.foreign_keys:
            return {}
        
        results = {}
        
        for fk in table_schema.foreign_keys:
            fk_col = fk.column
            parent_table = fk.parent_table
            parent_col = fk.parent_column
            relation_type = fk.relation_type
            
            # Check if tables exist
            if table_name not in self.synthetic_data:
                logger.warning(f"[REFERENTIAL_INTEGRITY] - Child table {table_name} not found")
                continue
            if parent_table not in self.synthetic_data:
                logger.warning(f"[REFERENTIAL_INTEGRITY] - Parent table {parent_table} not found")
                continue
            
            child_dataset = self.synthetic_data[table_name]
            parent_dataset = self.synthetic_data[parent_table]
            
            # Convert to dask for efficient computation
            child_dask = child_dataset.to_dask()
            parent_dask = parent_dataset.to_dask()
            
            # Get FK values from child table
            if fk_col not in child_dask.columns:
                logger.warning(f"[REFERENTIAL_INTEGRITY] - FK column {fk_col} not found in table {table_name}")
                continue
            
            child_fk_values = child_dask[fk_col]
            total_rows = child_fk_values.shape[0].compute()
            
            if total_rows == 0:
                results[fk_col] = {
                    "orphan_count": 0,
                    "total_rows": 0,
                    "orphan_rate": 0.0,
                    "is_valid": True,
                    "parent_coverage": 0.0,
                    "avg_children_per_parent": 0.0,
                    "orphan_parents_count": 0,
                    "cardinality_preserved": True
                }
                continue
            
            # Get parent PK values
            if parent_col not in parent_dask.columns:
                logger.warning(f"[REFERENTIAL_INTEGRITY] - Parent column {parent_col} not found in table {parent_table}")
                continue
            
            parent_pk_values = parent_dask[parent_col]
            
            # Convert to same type for comparison
            def column_conversion(x):
                return x.astype(float) if is_numeric_dtype(x) else x
            
            # Get non-null FK values for comparison
            child_fk_non_null = child_fk_values.dropna()
            total_non_null_fks = child_fk_non_null.shape[0].compute()
            
            child_fk_converted = column_conversion(child_fk_non_null)
            parent_pk_unique = column_conversion(parent_pk_values.dropna().unique())
            
            # Check for orphan records (FKs that don't exist in parent PKs)
            # Use categorical conversion for efficient checking
            child_fk_categorical = child_fk_converted.astype('category').cat.set_categories(parent_pk_unique)
            # Valid FKs are those that match parent PKs (not NaN after categorical conversion)
            valid_fk_count = child_fk_categorical.dropna().shape[0].compute()
            # Orphan count = non-null FKs that don't match any parent PK
            orphan_count = total_non_null_fks - valid_fk_count
            
            # Calculate parent coverage (percentage of parent PKs that are referenced)
            parent_pk_count = len(parent_pk_unique)
            if parent_pk_count > 0:
                referenced_parents = child_fk_categorical.dropna().unique().compute()
                parent_coverage = len(referenced_parents) / parent_pk_count if len(referenced_parents) > 0 else 0.0
            else:
                parent_coverage = 0.0
            
            # Calculate average children per parent (for 1:N relationships)
            if relation_type.value == '1-n' and parent_pk_count > 0:
                # Count children per parent
                child_fk_value_counts = child_fk_categorical.dropna().value_counts().compute()
                avg_children_per_parent = float(child_fk_value_counts.mean()) if len(child_fk_value_counts) > 0 else 0.0
                
                # Count orphan parents (parents with no children)
                referenced_parents_unique = child_fk_categorical.dropna().unique().compute()
                referenced_parent_set = set(referenced_parents_unique) if len(referenced_parents_unique) > 0 else set()
                all_parent_set = set(parent_pk_unique)
                orphan_parents_count = len(all_parent_set - referenced_parent_set)
            else:
                avg_children_per_parent = 0.0
                orphan_parents_count = 0
            
            # Check cardinality preservation (simplified check)
            # For 1:1 relationships, each parent should have at most 1 child
            # For 1:N, multiple children per parent is expected
            cardinality_preserved = True
            if relation_type.value == '1-1' and parent_pk_count > 0:
                child_fk_value_counts = child_fk_categorical.dropna().value_counts().compute()
                if len(child_fk_value_counts) > 0:
                    max_children = float(child_fk_value_counts.max())
                    cardinality_preserved = max_children <= 1
            
            orphan_rate = orphan_count / total_rows if total_rows > 0 else 0.0
            
            results[fk_col] = {
                "orphan_count": int(orphan_count),
                "total_rows": total_rows,
                "orphan_rate": orphan_rate,
                "is_valid": orphan_count == 0,
                "parent_coverage": float(parent_coverage),
                "avg_children_per_parent": float(avg_children_per_parent),
                "orphan_parents_count": int(orphan_parents_count),
                "cardinality_preserved": bool(cardinality_preserved)
            }
        
        return results

