"""Synthetic data report modules."""
from ydata.report.reports.syntheticdata.referential_integrity import ReferentialIntegrityValidator

__all__ = ["ReferentialIntegrityValidator"]
