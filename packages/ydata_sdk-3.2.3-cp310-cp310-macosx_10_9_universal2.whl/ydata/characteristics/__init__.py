from ydata.datascience.common import ColumnCharacteristic

__all__ = ["ColumnCharacteristic"]
