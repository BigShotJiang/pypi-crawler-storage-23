"""CLR API resources."""

from .credentials import CredentialsResource
from .discovery import DiscoveryResource

__all__ = [
    "CredentialsResource",
    "DiscoveryResource",
]
