"""
CLR Transport Layer

HTTP transport for CLR API communication.
CLR uses the IMS Global error format, handled by the base transport's
built-in IMS error parsing. No custom pagination is needed since CLR
endpoints don't return paginated results.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from timeback_common import BaseTransport, ClrPaths, TokenManager

if TYPE_CHECKING:
    import httpx


class Transport(BaseTransport):
    """HTTP transport layer for CLR API communication."""

    def __init__(
        self,
        *,
        base_url: str,
        token_manager: TokenManager | None = None,
        paths: ClrPaths,
        timeout: float = 30.0,
        http_client: httpx.AsyncClient | None = None,
        no_auth: bool = False,
    ) -> None:
        super().__init__(
            base_url=base_url,
            timeout=timeout,
            token_manager=token_manager,
            http_client=http_client,
            no_auth=no_auth,
        )
        self.paths = paths


__all__ = ["Transport"]
