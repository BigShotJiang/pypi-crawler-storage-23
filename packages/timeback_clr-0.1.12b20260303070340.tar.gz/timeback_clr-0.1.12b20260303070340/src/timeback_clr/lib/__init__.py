"""CLR internal library."""
