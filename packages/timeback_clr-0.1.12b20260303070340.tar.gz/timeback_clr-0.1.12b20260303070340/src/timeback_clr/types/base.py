"""
CLR Base Types

Common types shared across CLR resources.
"""

from typing import Literal

AssociationType = Literal[
    "exactMatchOf",
    "isChildOf",
    "isParentOf",
    "isPartOf",
    "isPeerOf",
    "isRelatedTo",
    "precedes",
    "replacedBy",
]

ACHIEVEMENT_TYPES: list[str] = [
    "Achievement",
    "ApprenticeshipCertificate",
    "Assessment",
    "Assignment",
    "AssociateDegree",
    "Award",
    "Badge",
    "BachelorDegree",
    "Certificate",
    "CertificateOfCompletion",
    "Certification",
    "CommunityService",
    "Competency",
    "Course",
    "CoCurricular",
    "Degree",
    "Diploma",
    "DoctoralDegree",
    "Fieldwork",
    "GeneralEducationDevelopment",
    "JourneymanCertificate",
    "LearningProgram",
    "License",
    "Membership",
    "ProfessionalDoctorate",
    "QualityAssuranceCredential",
    "MasterCertificate",
    "MasterDegree",
    "MicroCredential",
    "ResearchDoctorate",
    "SecondarySchoolDiploma",
]

AchievementType = str
