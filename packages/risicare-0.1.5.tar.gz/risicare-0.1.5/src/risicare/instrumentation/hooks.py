"""
Import hooks for automatic instrumentation.

This module provides automatic instrumentation of LLM provider SDKs
by wrapping builtins.__import__ to intercept imports and apply
instrumentation after modules are loaded.

Based on ARCHITECTURE_V2.md Section 6: Auto-Instrumentation Engine.

Usage:
    # Automatic via environment variable:
    RISICARE_TRACING=true python app.py

    # Programmatic:
    from risicare.instrumentation.hooks import install_import_hooks
    install_import_hooks()

    import openai  # Automatically instrumented
"""

from __future__ import annotations

import builtins
import importlib
import logging
import sys
import warnings
from typing import Any, Callable, Dict, Optional, Set

logger = logging.getLogger(__name__)


# Type alias for instrumentor functions
Instrumentor = Callable[[object], None]

# Module name -> instrumentation function mapping
# Functions are lazy-loaded from providers submodule
_INSTRUMENTORS: Optional[Dict[str, str]] = None

# Reverse map: instrumentor_path -> set of module names using it.
# Pre-computed once to support sibling pre-marking (prevents cross-key re-entry
# when multiple module names share the same instrumentor, e.g.
# "langchain" + "langchain_core" both map to instrument_langchain).
_INSTRUMENTOR_SIBLINGS: Optional[Dict[str, Set[str]]] = None

# Tracks which instrumentor paths are currently executing on this thread.
# Used to detect re-entrant calls: if wrapt.wrap_function_wrapper() triggers
# __import__() internally, the re-entrant hook call will see the path already
# in this set and bail out safely instead of deadlocking.
#
# Access is always from the same thread (Python's import lock serialises
# imports), so a plain set is safe here.
_active_instrumentors: Set[str] = set()


def _get_instrumentors() -> Dict[str, str]:
    """
    Get the instrumentor function mapping.

    Maps module names to the function path that instruments them.
    Functions are lazy-loaded to avoid import cycles.
    """
    global _INSTRUMENTORS
    if _INSTRUMENTORS is None:
        _INSTRUMENTORS = {
            # LLM Providers (original 5)
            "openai": "risicare.instrumentation.providers.openai:instrument_openai",
            "anthropic": "risicare.instrumentation.providers.anthropic:instrument_anthropic",
            "cohere": "risicare.instrumentation.providers.cohere:instrument_cohere",
            "google.generativeai": "risicare.instrumentation.providers.google:instrument_google",
            "mistralai": "risicare.instrumentation.providers.mistral:instrument_mistral",
            # LLM Providers (GAP-07 additions)
            "groq": "risicare.instrumentation.providers.groq:instrument_groq",
            "together": "risicare.instrumentation.providers.together:instrument_together",
            "ollama": "risicare.instrumentation.providers.ollama:instrument_ollama",
            "botocore": "risicare.instrumentation.providers.bedrock:instrument_bedrock",
            "vertexai": "risicare.instrumentation.providers.vertex_ai:instrument_vertex_ai",
            # LLM Providers (extended provider parity)
            "cerebras": "risicare.instrumentation.providers.cerebras:instrument_cerebras",
            "huggingface_hub": "risicare.instrumentation.providers.huggingface:instrument_huggingface",
            # Agent Frameworks (in-SDK integrations)
            "langchain": "risicare.integrations.langchain:instrument_langchain",
            "langchain_core": "risicare.integrations.langchain:instrument_langchain",
            "langgraph": "risicare.integrations.langgraph:instrument_langgraph",
            "crewai": "risicare.integrations.crewai:instrument_crewai",
            "autogen": "risicare.integrations.autogen:instrument_autogen",
            "autogen_agentchat": "risicare.integrations.autogen:instrument_autogen",
            "agents": "risicare.integrations.openai_agents:instrument_openai_agents",
            # AI Frameworks (Tier 1 additions)
            "instructor": "risicare.integrations.instructor:instrument_instructor",
            "litellm": "risicare.integrations.litellm:instrument_litellm",
            "dspy": "risicare.integrations.dspy:instrument_dspy",
            "pydantic_ai": "risicare.integrations.pydantic_ai:instrument_pydantic_ai",
            "llama_index": "risicare.integrations.llamaindex:instrument_llamaindex",
            "llama_index.core": "risicare.integrations.llamaindex:instrument_llamaindex",
            # OpenTelemetry bridge (opt-in via otel_bridge=True)
            "opentelemetry": "risicare.integrations.otel:instrument_opentelemetry",
        }
    return _INSTRUMENTORS


def _get_instrumentor_siblings() -> Dict[str, Set[str]]:
    """
    Build (once) the reverse map: instrumentor_path -> set of module names.

    This lets us pre-mark all sibling module names when we begin
    instrumenting any one of them.  For example, when "langchain" triggers
    instrument_langchain, we pre-mark "langchain_core" too so that a
    wrapt-triggered __import__("langchain_core") is silently skipped.
    """
    global _INSTRUMENTOR_SIBLINGS
    if _INSTRUMENTOR_SIBLINGS is None:
        groups: Dict[str, Set[str]] = {}
        for mod_name, inst_path in _get_instrumentors().items():
            groups.setdefault(inst_path, set()).add(mod_name)
        _INSTRUMENTOR_SIBLINGS = groups
    return _INSTRUMENTOR_SIBLINGS


def _load_instrumentor(path: str) -> Optional[Instrumentor]:
    """
    Load an instrumentor function from a module path.

    Args:
        path: Path in format "module.path:function_name"

    Returns:
        The instrumentor function or None if loading fails.
    """
    try:
        module_path, func_name = path.rsplit(":", 1)
        module = importlib.import_module(module_path)
        return getattr(module, func_name)
    except Exception as e:
        logger.debug(f"Failed to load instrumentor {path}: {e}")
        return None


# Kept for backward compatibility (referenced in __init__.py exports)
class RisicareImportFinder:
    """Tracks instrumented modules. No longer used as a MetaPathFinder."""

    def __init__(self, allowed_modules: Optional[Set[str]] = None) -> None:
        instrumentors = _get_instrumentors()
        self.allowed_modules = allowed_modules or set(instrumentors.keys())
        self._instrumented: Set[str] = set()


# Global state
_finder: Optional[RisicareImportFinder] = None
_original_import: Optional[Any] = None
_hooks_installed: bool = False


def _run_instrumentor(
    target: str,
    module: Any,
    instrumentor_path: str,
    instrumentor: Instrumentor,
) -> None:
    """
    Execute an instrumentor with full re-entrancy protection.

    This function is the single chokepoint through which ALL instrumentation
    calls flow — both from _instrumented_import and instrument_already_imported.

    Re-entrancy protection (three layers):
    1. _active_instrumentors: if this path is already executing on this thread,
       we are being called re-entrantly (e.g. wrapt triggered __import__ for a
       sub-module).  Mark the target and return immediately.
    2. Sibling pre-marking: before calling the instrumentor, mark all module
       names that share the same instrumentor path.  This stops cross-key
       re-entry (langchain_core being re-triggered while langchain is running).
    3. The integration __init__.py files also have RLock + _instrumented guard
       as an independent last line of defence.

    Args:
        target:           The canonical module name being instrumented.
        module:           The live module object from sys.modules.
        instrumentor_path: "pkg.module:function" string identifier.
        instrumentor:     The callable to invoke.
    """
    if _finder is None:
        return

    # Layer 1: re-entrancy guard — same instrumentor already executing
    if instrumentor_path in _active_instrumentors:
        # We are being called from within the instrumentor (via wrapt __import__).
        # Safely mark the target so the outer check won't retry it.
        _finder._instrumented.add(target)
        logger.debug(f"Skipping re-entrant instrumentation of {target}")
        return

    # Layer 2: pre-mark target + all siblings before calling the instrumentor.
    # Any import the instrumentor triggers for a sibling module name will
    # find it already in _instrumented and skip cleanly.
    siblings = _get_instrumentor_siblings().get(instrumentor_path, set())
    pre_marked = siblings - _finder._instrumented
    _finder._instrumented.update(pre_marked)

    _active_instrumentors.add(instrumentor_path)
    try:
        instrumentor(module)
        logger.debug(f"Instrumented {target}")
    except Exception as e:
        # Rollback only the targets we just pre-marked (siblings that were not
        # previously instrumented stay unmarked so they can be retried).
        _finder._instrumented -= pre_marked
        warnings.warn(
            f"Failed to instrument {target}: {e}",
            RuntimeWarning,
        )
    finally:
        _active_instrumentors.discard(instrumentor_path)


def _instrumented_import(name: str, *args: Any, **kwargs: Any) -> Any:
    """
    Replacement for builtins.__import__ that instruments LLM provider modules
    after they are loaded by the normal import system.
    """
    result = _original_import(name, *args, **kwargs)

    # Check if this is a module we should instrument
    instrumentors = _get_instrumentors()
    base_module = name.split(".")[0]

    # Check if base module or full name matches
    target = None
    if name in instrumentors:
        target = name
    elif base_module in instrumentors:
        target = base_module

    if target and _finder and target not in _finder._instrumented:
        # Module is now in sys.modules, instrument it
        if target in sys.modules:
            module = sys.modules[target]
            instrumentor_path = instrumentors[target]
            instrumentor = _load_instrumentor(instrumentor_path)
            if instrumentor:
                _run_instrumentor(target, module, instrumentor_path, instrumentor)

    return result


def install_import_hooks(
    allowed_modules: Optional[Set[str]] = None,
) -> RisicareImportFinder:
    """
    Install instrumentation import hooks.

    Wraps builtins.__import__ to automatically instrument LLM provider
    modules when they are imported.

    Args:
        allowed_modules: Set of module names to instrument.
                        If None, all supported modules are instrumented.

    Returns:
        The tracker instance.
    """
    global _finder, _original_import, _hooks_installed

    if _hooks_installed:
        if allowed_modules and _finder and allowed_modules != _finder.allowed_modules:
            logger.warning(
                "import_hooks already installed with different allowed_modules. "
                "Call remove_import_hooks() first to change modules."
            )
        if _finder is None:
            _finder = RisicareImportFinder(allowed_modules)
        return _finder

    _finder = RisicareImportFinder(allowed_modules)

    # Store original import ONCE — never overwrite on reinstall
    if _original_import is None:
        _original_import = builtins.__import__
    builtins.__import__ = _instrumented_import
    _hooks_installed = True
    logger.debug("Installed Risicare import hooks")

    # Instrument any already-imported modules
    instrument_already_imported()

    return _finder


def remove_import_hooks() -> None:
    """Remove instrumentation import hooks."""
    global _finder, _original_import, _hooks_installed

    if _original_import is not None:
        builtins.__import__ = _original_import
        _original_import = None

    _finder = None
    _hooks_installed = False
    logger.debug("Removed Risicare import hooks")


def instrument_already_imported() -> int:
    """
    Instrument modules that are already imported.

    This handles the case where modules are imported before hooks are installed.

    Returns:
        Number of modules instrumented.
    """
    instrumented_count = 0
    instrumentors = _get_instrumentors()

    for module_name, instrumentor_path in instrumentors.items():
        if module_name in sys.modules:
            module = sys.modules[module_name]

            # Skip if already instrumented
            if _finder and module_name in _finder._instrumented:
                continue

            instrumentor = _load_instrumentor(instrumentor_path)
            if instrumentor:
                _run_instrumentor(module_name, module, instrumentor_path, instrumentor)
                if _finder and module_name in _finder._instrumented:
                    instrumented_count += 1

    return instrumented_count


def is_instrumented(module_name: str) -> bool:
    """Check if a module has been instrumented."""
    if _finder is None:
        return False
    return module_name in _finder._instrumented


def get_instrumented_modules() -> Set[str]:
    """Get the set of instrumented module names."""
    if _finder is None:
        return set()
    return _finder._instrumented.copy()


def get_supported_modules() -> Set[str]:
    """Get the set of module names that can be instrumented."""
    return set(_get_instrumentors().keys())
