"""
Decorators for agent observability.

These decorators provide progressive integration for AI agents:
- @agent: Agent identity (Tier 2)
- @session: Session grouping (Tier 3)
- @trace_think/@trace_decide/@trace_act: Decision phases (Tier 4)
- @trace_message/@trace_delegate: Multi-agent (Tier 5)
"""

from __future__ import annotations

import functools
import inspect
import logging
import uuid
from typing import Any, Callable, Dict, Optional, TypeVar, Union, overload

from risicare_core import (
    SemanticPhase,
    SpanKind,
    agent_context,
    async_agent_context,
    async_session_context,
    generate_agent_id,
    phase_context,
    session_context,
)

from risicare.tracer import get_tracer

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


# =============================================================================
# @agent Decorator
# =============================================================================

@overload
def agent(func: F) -> F: ...

@overload
def agent(
    *,
    name: Optional[str] = None,
    role: Optional[str] = None,
    agent_type: Optional[str] = None,
    version: Optional[int] = None,
) -> Callable[[F], F]: ...


def agent(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
    role: Optional[str] = None,
    agent_type: Optional[str] = None,
    version: Optional[int] = None,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator to mark a function as an agent.

    Sets up agent context for the duration of the function.
    All spans created within will be attributed to this agent.

    Can be used with or without arguments:
        @agent
        def my_agent(): ...

        @agent(name="researcher", role="worker")
        def research_agent(): ...

    Args:
        func: The function to decorate (when used without arguments).
        name: Agent name (defaults to function name).
        role: Agent role (orchestrator, worker, reviewer, etc.).
        agent_type: Framework type (langgraph, crewai, autogen, custom).
        version: Agent version number.

    Returns:
        Decorated function with agent context.

    Example:
        @agent(name="research_agent", role="worker")
        def research(query: str) -> str:
            return llm.invoke(query)

        @agent(role="orchestrator")
        async def orchestrate(task: str):
            result = await research(task)
            return summarize(result)
    """
    def decorator(fn: F) -> F:
        agent_name = name or fn.__name__
        agent_id = generate_agent_id(prefix=agent_name)

        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                async with async_agent_context(
                    agent_id=agent_id,
                    agent_name=agent_name,
                    agent_role=role,
                    agent_type=agent_type,
                    version=version,
                ):
                    tracer = get_tracer()
                    with tracer.start_span(
                        name=f"agent:{agent_name}",
                        kind=SpanKind.AGENT,
                    ):
                        return await fn(*args, **kwargs)
            return async_wrapper  # type: ignore
        else:
            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                with agent_context(
                    agent_id=agent_id,
                    agent_name=agent_name,
                    agent_role=role,
                    agent_type=agent_type,
                    version=version,
                ):
                    tracer = get_tracer()
                    with tracer.start_span(
                        name=f"agent:{agent_name}",
                        kind=SpanKind.AGENT,
                    ):
                        return fn(*args, **kwargs)
            return sync_wrapper  # type: ignore

    if func is not None:
        return decorator(func)
    return decorator


# =============================================================================
# @session Decorator
# =============================================================================

@overload
def session(func: F) -> F: ...

@overload
def session(
    *,
    session_id: Optional[str] = None,
    session_id_arg: str = "session_id",
    user_id_arg: Optional[str] = "user_id",
    auto_generate: bool = False,
) -> Callable[[F], F]: ...


def session(
    func: Optional[F] = None,
    *,
    session_id: Optional[str] = None,
    session_id_arg: str = "session_id",
    user_id_arg: Optional[str] = "user_id",
    auto_generate: bool = False,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator to create session context.

    Session ID resolution priority (first match wins):
    1. ``session_id`` kwarg — use it directly (no arg inspection needed)
    2. ``session_id_arg`` found in function's bound arguments
    3. ``auto_generate=True`` — generate a fresh UUID per call
    4. Nothing found — run without session context (debug log)

    Can be used with or without arguments:
        @session
        def handle_request(session_id: str): ...

        @session(session_id="AAPL-analysis")
        def analyze(ticker): ...           # no session_id param needed

        @session(auto_generate=True)
        def process(query): ...            # new UUID each call

        @session(session_id_arg="sid", user_id_arg="uid")
        def handle(sid: str, uid: str): ...

    For advanced session features (metadata, parent_session_id, turn_number),
    use ``session_context()`` from risicare_core instead.

    Args:
        func: The function to decorate (when used without arguments).
        session_id: Explicit session ID — bypasses arg inspection entirely.
        session_id_arg: Name of argument containing session ID.
        user_id_arg: Name of argument containing user ID (optional).
        auto_generate: Generate a fresh UUID if no session_id is found.

    Returns:
        Decorated function with session context.

    Example:
        @session
        def handle_request(session_id: str, query: str) -> str:
            return process(query)

        @session(session_id="ticker-AAPL")
        def analyze(ticker: str) -> str:   # no session_id param required
            return process(ticker)

        @session(session_id_arg="sid")
        async def handle(sid: str, message: str):
            return await process(message)
    """
    def decorator(fn: F) -> F:
        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                # Resolution priority: explicit kwarg → arg extraction → auto_generate
                if session_id is not None:
                    sid: Optional[str] = session_id
                    uid: Optional[str] = None
                else:
                    sig = inspect.signature(fn)
                    bound = sig.bind(*args, **kwargs)
                    bound.apply_defaults()
                    sid = bound.arguments.get(session_id_arg)
                    uid = bound.arguments.get(user_id_arg) if user_id_arg else None
                    if sid is None and auto_generate:
                        sid = str(uuid.uuid4())

                if sid is None:
                    logger.debug("@session: session_id is None, running without session context")
                    return await fn(*args, **kwargs)

                async with async_session_context(
                    session_id=str(sid),
                    user_id=str(uid) if uid else None,
                ):
                    return await fn(*args, **kwargs)
            return async_wrapper  # type: ignore
        else:
            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                # Resolution priority: explicit kwarg → arg extraction → auto_generate
                if session_id is not None:
                    sid: Optional[str] = session_id
                    uid: Optional[str] = None
                else:
                    sig = inspect.signature(fn)
                    bound = sig.bind(*args, **kwargs)
                    bound.apply_defaults()
                    sid = bound.arguments.get(session_id_arg)
                    uid = bound.arguments.get(user_id_arg) if user_id_arg else None
                    if sid is None and auto_generate:
                        sid = str(uuid.uuid4())

                if sid is None:
                    logger.debug("@session: session_id is None, running without session context")
                    return fn(*args, **kwargs)

                with session_context(
                    session_id=str(sid),
                    user_id=str(uid) if uid else None,
                ):
                    return fn(*args, **kwargs)
            return sync_wrapper  # type: ignore

    if func is not None:
        return decorator(func)
    return decorator


# =============================================================================
# @trace Decorator (Generic) — also a context manager
# =============================================================================

class _TraceWrapper:
    """
    Dual-mode trace wrapper — supports both decorator and context manager usage.

    As a decorator::

        @trace
        def my_pipeline(query): ...

        @trace(name="pipeline")
        def my_pipeline(query): ...

        @trace(kind=SpanKind.AGENT)
        async def orchestrate(): ...

    As a context manager::

        with trace("analysis"):
            result = client.chat.completions.create(...)   # child span

        with trace(name="pipeline") as span:
            span.set_attribute("ticker", "AAPL")
            result = client.chat.completions.create(...)   # child span
    """

    def __init__(
        self,
        name: Optional[str] = None,
        kind: SpanKind = SpanKind.INTERNAL,
        attributes: Optional[dict] = None,
    ) -> None:
        self._name = name
        self._kind = kind
        self._attributes = attributes
        self._active_cm: Any = None

    def __call__(self, fn: F) -> F:
        """Decorator mode: wrap fn so every call creates a span."""
        span_name = self._name or fn.__name__
        kind = self._kind
        attributes = self._attributes

        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                tracer = get_tracer()
                with tracer.start_span(name=span_name, kind=kind, attributes=attributes):
                    return await fn(*args, **kwargs)
            return async_wrapper  # type: ignore
        else:
            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                tracer = get_tracer()
                with tracer.start_span(name=span_name, kind=kind, attributes=attributes):
                    return fn(*args, **kwargs)
            return sync_wrapper  # type: ignore

    def __enter__(self) -> Any:
        """Context manager entry: open a span and set it as current."""
        span_name = self._name or "trace"
        self._active_cm = get_tracer().start_span(
            name=span_name,
            kind=self._kind,
            attributes=self._attributes,
        )
        return self._active_cm.__enter__()

    def __exit__(self, *exc_info: Any) -> Optional[bool]:
        """Context manager exit: end the span."""
        if self._active_cm is not None:
            result = self._active_cm.__exit__(*exc_info)
            self._active_cm = None
            return result
        return None


def trace(
    func_or_name: Union[F, str, None] = None,
    *,
    name: Optional[str] = None,
    kind: SpanKind = SpanKind.INTERNAL,
    attributes: Optional[dict] = None,
) -> Union[F, _TraceWrapper]:
    """
    Decorator and context manager for tracing operations.

    Supports all four usage patterns:

        @trace                                  # bare decorator
        def my_pipeline(query): ...

        @trace(name="pipeline")                 # decorator with explicit name
        def my_pipeline(query): ...

        with trace("analysis"):                 # context manager
            result = llm.call(query)            # LLM call becomes child span

        with trace(name="pipeline") as span:    # context manager with span access
            span.set_attribute("model", "gpt-4o")
            result = llm.call(query)

    This is the minimum useful Tier 1 primitive. Without ``@trace`` or
    ``with trace()``, each LLM call becomes its own independent trace (no
    hierarchy). Use this to group related calls into a single trace.

    Args:
        func_or_name: Function (bare ``@trace``) or span name string.
        kind: Span kind.
        attributes: Static attributes to add to span.

    Returns:
        Decorated function, or a ``_TraceWrapper`` (decorator/context-manager).

    Example:
        @trace
        def research_pipeline(query: str) -> str:
            return openai_client.chat.completions.create(...)  # child span

        with trace("investment-analysis"):
            call1 = client.chat.completions.create(...)   # child span
            call2 = client.chat.completions.create(...)   # child span
        # Result: 1 trace, 3 spans (root + 2 LLM)
    """
    if callable(func_or_name):
        # @trace (bare, no parentheses) — function passed directly
        return _TraceWrapper(name=name, kind=kind, attributes=attributes)(func_or_name)
    # trace("name"), trace(name="name"), trace(), or with trace("name"):
    # Positional string takes precedence over the name= kwarg
    resolved_name = func_or_name if isinstance(func_or_name, str) else name
    return _TraceWrapper(name=resolved_name, kind=kind, attributes=attributes)  # type: ignore


# =============================================================================
# Phase Decorators (Tier 4)
# =============================================================================

def _phase_decorator(
    phase: SemanticPhase,
    kind: SpanKind,
    name: Optional[str] = None,
    extra_attributes: Optional[Dict[str, Any]] = None,
) -> Callable[[F], F]:
    """Internal factory for phase decorators."""
    def decorator(fn: F) -> F:
        span_name = name or f"{phase.value}:{fn.__name__}"

        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                with phase_context(phase):
                    tracer = get_tracer()
                    with tracer.start_span(
                        name=span_name,
                        kind=kind,
                    ) as span:
                        span.semantic_phase = phase
                        if extra_attributes:
                            span.set_attributes(extra_attributes)
                        return await fn(*args, **kwargs)
            return async_wrapper  # type: ignore
        else:
            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                with phase_context(phase):
                    tracer = get_tracer()
                    with tracer.start_span(
                        name=span_name,
                        kind=kind,
                    ) as span:
                        span.semantic_phase = phase
                        if extra_attributes:
                            span.set_attributes(extra_attributes)
                        return fn(*args, **kwargs)
            return sync_wrapper  # type: ignore

    return decorator


@overload
def trace_think(func: F) -> F: ...

@overload
def trace_think(*, name: Optional[str] = None) -> Callable[[F], F]: ...


def trace_think(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator for THINK phase operations.

    Use for reasoning, planning, and analysis operations.

    Example:
        @trace_think
        def analyze(data: dict) -> dict:
            return {"analysis": llm.invoke(f"Analyze: {data}")}

        @trace_think(name="strategic_planning")
        async def plan(goal: str):
            return await llm.ainvoke(f"Plan to achieve: {goal}")
    """
    decorator = _phase_decorator(
        phase=SemanticPhase.THINK,
        kind=SpanKind.THINK,
        name=name,
    )
    if func is not None:
        return decorator(func)
    return decorator


@overload
def trace_decide(func: F) -> F: ...

@overload
def trace_decide(*, name: Optional[str] = None) -> Callable[[F], F]: ...


def trace_decide(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator for DECIDE phase operations.

    Use for decision-making and choice selection operations.

    Example:
        @trace_decide
        def select_tool(options: list) -> str:
            return llm.invoke(f"Select best tool from: {options}")
    """
    decorator = _phase_decorator(
        phase=SemanticPhase.DECIDE,
        kind=SpanKind.DECIDE,
        name=name,
    )
    if func is not None:
        return decorator(func)
    return decorator


@overload
def trace_act(func: F) -> F: ...

@overload
def trace_act(*, name: Optional[str] = None) -> Callable[[F], F]: ...


def trace_act(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator for ACT phase operations.

    Use for action execution (tool calls, API calls, etc.).

    Example:
        @trace_act
        def execute_search(query: str) -> list:
            return search_api.search(query)

        @trace_act(name="database_write")
        async def save(data: dict):
            await db.insert(data)
    """
    decorator = _phase_decorator(
        phase=SemanticPhase.ACT,
        kind=SpanKind.TOOL_CALL,
        name=name,
    )
    if func is not None:
        return decorator(func)
    return decorator


# =============================================================================
# Multi-Agent Decorators (Tier 5)
# =============================================================================

@overload
def trace_message(func: F) -> F: ...

@overload
def trace_message(
    *,
    name: Optional[str] = None,
    target: Optional[str] = None,
    target_name: Optional[str] = None,
) -> Callable[[F], F]: ...


def trace_message(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
    target: Optional[str] = None,
    target_name: Optional[str] = None,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator for inter-agent message operations.

    Use for functions that send or receive messages between agents.

    Args:
        name: Custom span name.
        target: Target agent ID for the message recipient.
        target_name: Human-readable name of the target agent.

    Example:
        @trace_message
        def send_to_reviewer(message: str) -> str:
            return reviewer_agent.receive(message)

        @trace_message(target="reviewer", target_name="Code Reviewer")
        def send_review_request(code: str) -> str:
            return reviewer.review(code)
    """
    attrs: Dict[str, Any] = {}
    if target:
        attrs["message.target_agent_id"] = target
    if target_name:
        attrs["message.target_agent_name"] = target_name

    decorator = _phase_decorator(
        phase=SemanticPhase.COMMUNICATE,
        kind=SpanKind.MESSAGE,
        name=name,
        extra_attributes=attrs or None,
    )
    if func is not None:
        return decorator(func)
    return decorator


@overload
def trace_delegate(func: F) -> F: ...

@overload
def trace_delegate(
    *,
    name: Optional[str] = None,
    target: Optional[str] = None,
    target_name: Optional[str] = None,
) -> Callable[[F], F]: ...


def trace_delegate(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
    target: Optional[str] = None,
    target_name: Optional[str] = None,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator for task delegation operations.

    Use for functions that delegate work to other agents.

    Args:
        name: Custom span name.
        target: Target agent ID that work is delegated to.
        target_name: Human-readable name of the target agent.

    Example:
        @trace_delegate
        def delegate_research(topic: str) -> str:
            return research_agent.run(topic)

        @trace_delegate(target="research-agent", name="parallel_delegation")
        async def delegate_all(tasks: list):
            return await asyncio.gather(*[agent.run(t) for t in tasks])
    """
    attrs: Dict[str, Any] = {}
    if target:
        attrs["message.target_agent_id"] = target
    if target_name:
        attrs["message.target_agent_name"] = target_name

    decorator = _phase_decorator(
        phase=SemanticPhase.COORDINATE,
        kind=SpanKind.DELEGATION,
        name=name,
        extra_attributes=attrs or None,
    )
    if func is not None:
        return decorator(func)
    return decorator


@overload
def trace_observe(func: F) -> F: ...

@overload
def trace_observe(*, name: Optional[str] = None) -> Callable[[F], F]: ...


def trace_observe(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator for OBSERVE phase operations.

    Use for environment observation, state reading, and information gathering.

    Example:
        @trace_observe
        def check_environment() -> dict:
            return {"status": get_system_status()}

        @trace_observe(name="read_user_state")
        async def get_user_context(user_id: str):
            return await db.get_user(user_id)
    """
    decorator = _phase_decorator(
        phase=SemanticPhase.OBSERVE,
        kind=SpanKind.OBSERVE,
        name=name,
    )
    if func is not None:
        return decorator(func)
    return decorator


@overload
def trace_coordinate(func: F) -> F: ...

@overload
def trace_coordinate(*, name: Optional[str] = None) -> Callable[[F], F]: ...


def trace_coordinate(
    func: Optional[F] = None,
    *,
    name: Optional[str] = None,
) -> Union[F, Callable[[F], F]]:
    """
    Decorator for multi-agent coordination operations.

    Use for consensus building, voting, resource allocation, and synchronization.

    Example:
        @trace_coordinate
        def gather_votes(proposal: str) -> list:
            return [agent.vote(proposal) for agent in self.agents]

        @trace_coordinate(name="consensus_building")
        async def reach_consensus(options: list):
            votes = await asyncio.gather(*[a.vote(options) for a in agents])
            return majority_vote(votes)
    """
    decorator = _phase_decorator(
        phase=SemanticPhase.COORDINATE,
        kind=SpanKind.COORDINATION,
        name=name,
    )
    if func is not None:
        return decorator(func)
    return decorator
