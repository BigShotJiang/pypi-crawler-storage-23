from .types import IndirectInstructionType
