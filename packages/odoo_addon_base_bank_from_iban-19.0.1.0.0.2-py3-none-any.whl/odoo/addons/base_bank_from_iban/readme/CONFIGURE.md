1.  Go to *Contacts \> Configuration \> Bank Accounts \> Banks*.
2.  Create or modify a bank.
3.  Put the corresponding code for that bank in the field "Code".
