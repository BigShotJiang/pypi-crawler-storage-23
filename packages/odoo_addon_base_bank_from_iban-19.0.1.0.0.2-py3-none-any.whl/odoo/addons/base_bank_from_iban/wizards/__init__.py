# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl-3).

from . import account_setup_bank_manual_config
