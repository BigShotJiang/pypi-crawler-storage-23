"""
Shared utilities for Salim.
"""

from __future__ import annotations

import io
import os
import sys
import time
import asyncio
import logging
import platform
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger("salim")

OS = platform.system()  # 'Windows' | 'Darwin' | 'Linux'


# ── Shell execution ──────────────────────────────────────────────────────────

def run_shell(cmd: str, timeout: int = 60, cwd: str | None = None, shell_bin: str | None = None) -> tuple[str, int]:
    """
    Execute a shell command. Returns (output, returncode).
    Merges stdout + stderr. Supports custom shell and cwd.
    """
    effective_shell = shell_bin or os.environ.get("SHELL", "/bin/bash")
    try:
        proc = subprocess.run(
            cmd,
            shell=True,
            executable=effective_shell if OS != "Windows" else None,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        return out.strip() or "(no output)", proc.returncode
    except subprocess.TimeoutExpired:
        return f"⏱ Command timed out after {timeout}s", -1
    except Exception as e:
        return f"❌ Error: {e}", -1


async def run_shell_async(cmd: str, timeout: int = 60, cwd: str | None = None) -> tuple[str, int]:
    """Async version of run_shell — non-blocking."""
    effective_shell = os.environ.get("SHELL", "/bin/bash")
    try:
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
            executable=effective_shell if OS != "Windows" else None,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            return f"⏱ Command timed out after {timeout}s", -1
        out = (stdout.decode(errors="replace") + stderr.decode(errors="replace")).strip()
        return out or "(no output)", proc.returncode or 0
    except Exception as e:
        return f"❌ Error: {e}", -1


# ── Formatting helpers ───────────────────────────────────────────────────────

def bytes_to_human(n: int | float) -> str:
    """Convert bytes to human-readable string."""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def truncate(text: str, max_chars: int = 3800) -> str:
    """Truncate text for Telegram messages (4096 char limit)."""
    if len(text) <= max_chars:
        return text
    half = max_chars // 2
    return text[:half] + f"\n\n... [{len(text) - max_chars} chars truncated] ...\n\n" + text[-half:]


def escape_md(text: str) -> str:
    """Escape MarkdownV2 special characters."""
    specials = r"\_*[]()~`>#+-=|{}.!"
    return "".join(f"\\{c}" if c in specials else c for c in text)


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def short_time() -> str:
    return datetime.now().strftime("%H:%M:%S")


# ── OS detection helpers ─────────────────────────────────────────────────────

def is_mac()     -> bool: return OS == "Darwin"
def is_windows() -> bool: return OS == "Windows"
def is_linux()   -> bool: return OS == "Linux"


# ── File utilities ───────────────────────────────────────────────────────────

def safe_read(path: str | Path, max_bytes: int = 100_000) -> tuple[str, bool]:
    """
    Read a file safely. Returns (content, is_binary).
    Limits to max_bytes to avoid huge outputs.
    """
    p = Path(path)
    try:
        raw = p.read_bytes()[:max_bytes]
        try:
            text = raw.decode("utf-8")
            truncated = len(p.read_bytes()) > max_bytes
            return text + ("\n\n[...truncated...]" if truncated else ""), False
        except UnicodeDecodeError:
            return f"[Binary file: {bytes_to_human(p.stat().st_size)}]", True
    except Exception as e:
        return f"Error reading file: {e}", False


def human_permissions(mode: int) -> str:
    """Convert file mode to rwxr-xr-x style string."""
    perms = ""
    for i in range(8, -1, -1):
        perms += "-rwx"[(mode >> i) & 1 + (i % 3 == 2) * 2] if False else ""
    # simpler approach
    bits = ["r", "w", "x"]
    result = ""
    for group in range(3):
        for bit in range(3):
            shift = 6 - group * 3 - bit
            result += bits[bit] if (mode >> shift) & 1 else "-"
    return result
