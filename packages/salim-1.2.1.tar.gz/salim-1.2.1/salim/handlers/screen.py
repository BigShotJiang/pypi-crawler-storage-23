"""
Screen & UI handlers — screenshot, type, click, scroll, notify, volume, brightness.
Uses HTML parse_mode throughout.
"""
from __future__ import annotations

import asyncio
import html
import io
import platform

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, is_mac, is_linux, is_windows

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

OS = platform.system()


class ScreenHandlers:

    @require_auth
    async def cmd_screenshot(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        delay = 0
        if ctx.args:
            try: delay = int(ctx.args[0])
            except ValueError: pass
        if delay:
            await update.effective_message.reply_text(f"📸 Screenshot in {delay}s...")
            await asyncio.sleep(delay)
        try:
            import pyautogui
            shot = pyautogui.screenshot()
            if len(ctx.args) >= 4:
                try:
                    x, y, w, h = [int(a) for a in ctx.args[:4]]
                    shot = shot.crop((x, y, x + w, y + h))
                except Exception:
                    pass
            buf = io.BytesIO()
            shot.save(buf, format="JPEG", quality=self.config.screenshot_quality, optimize=True)
            buf.seek(0)
            size = buf.getbuffer().nbytes
            w, h = shot.size
            await update.effective_message.reply_photo(photo=buf, caption=f"📸 {w}×{h} · {size // 1024}KB")
        except ImportError:
            await update.effective_message.reply_text(
                "❌ Missing: <code>pip install pyautogui Pillow</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ Screenshot failed: {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_type(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/type &lt;text to type&gt;</code>", parse_mode=H
            )
            return
        text = " ".join(ctx.args)
        try:
            import pyautogui
            pyautogui.write(text, interval=0.03)
            await update.effective_message.reply_text(f"⌨️ Typed: <code>{esc(text[:100])}</code>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_key(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/key &lt;shortcut&gt;</code>\n"
                "Examples: <code>/key ctrl+c</code>  <code>/key cmd+space</code>  <code>/key enter</code>",
                parse_mode=H
            )
            return
        combo = ctx.args[0].lower()
        try:
            import pyautogui
            if "+" in combo:
                pyautogui.hotkey(*combo.split("+"))
            else:
                pyautogui.press(combo)
            await update.effective_message.reply_text(f"⌨️ Pressed: <code>{esc(combo)}</code>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_click(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text(
                "Usage: <code>/click &lt;x&gt; &lt;y&gt; [left|right|middle] [clicks]</code>", parse_mode=H
            )
            return
        try:
            import pyautogui
            x = int(ctx.args[0]); y = int(ctx.args[1])
            button = ctx.args[2] if len(ctx.args) > 2 else "left"
            clicks = int(ctx.args[3]) if len(ctx.args) > 3 else 1
            pyautogui.click(x, y, button=button, clicks=clicks, interval=0.1)
            await update.effective_message.reply_text(
                f"🖱️ Clicked <code>{esc(button)}×{clicks}</code> at ({x}, {y})", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_scroll(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/scroll &lt;amount&gt;</code> (positive=up, negative=down)", parse_mode=H
            )
            return
        try:
            import pyautogui
            amount = int(ctx.args[0])
            if len(ctx.args) >= 3:
                pyautogui.scroll(amount, x=int(ctx.args[1]), y=int(ctx.args[2]))
            else:
                pyautogui.scroll(amount)
            direction = "up" if amount > 0 else "down"
            await update.effective_message.reply_text(f"🖱️ Scrolled {direction} by {abs(amount)}")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_move(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: <code>/move &lt;x&gt; &lt;y&gt;</code>", parse_mode=H)
            return
        try:
            import pyautogui
            x, y = int(ctx.args[0]), int(ctx.args[1])
            pyautogui.moveTo(x, y, duration=0.3)
            await update.effective_message.reply_text(f"🖱️ Moved to ({x}, {y})")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_mousepos(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            import pyautogui
            x, y = pyautogui.position()
            w, h = pyautogui.size()
            await update.effective_message.reply_text(f"🖱️ Mouse: ({x}, {y})\n📐 Screen: {w}×{h}")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_notify(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/notify &lt;title&gt; | &lt;message&gt;</code>", parse_mode=H
            )
            return
        full = " ".join(ctx.args)
        if "|" in full:
            title, msg = full.split("|", 1)
        else:
            title, msg = "Salim", full
        title = title.strip(); msg = msg.strip()

        if is_mac():
            await run_shell_async(f'osascript -e \'display notification "{msg}" with title "{title}"\'')
        elif is_windows():
            await run_shell_async(
                f'powershell -command "Add-Type -AssemblyName System.Windows.Forms; '
                f'[System.Windows.Forms.MessageBox]::Show(\'{msg}\', \'{title}\')"'
            )
        else:
            await run_shell_async(f'notify-send "{title}" "{msg}"')

        await update.effective_message.reply_text(
            f"🔔 Notification sent: <b>{esc(title)}</b>\n<i>{esc(msg)}</i>", parse_mode=H
        )

    @require_auth
    async def cmd_volume(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            if is_mac():
                out, _ = await run_shell_async("osascript -e 'output volume of (get volume settings)'")
            elif is_linux():
                out, _ = await run_shell_async("amixer get Master | grep -o '[0-9]*%' | head -1")
            else:
                out, _ = await run_shell_async("(Get-AudioDevice -Playback).Volume")
            await update.effective_message.reply_text(f"🔊 Volume: <code>{esc(out.strip())}</code>", parse_mode=H)
            return

        level = ctx.args[0].lower()
        if is_mac():
            if level == "mute":    cmd = "osascript -e 'set volume output muted true'"
            elif level == "up":    cmd = "osascript -e 'set volume output volume (output volume of (get volume settings) + 10)'"
            elif level == "down":  cmd = "osascript -e 'set volume output volume (output volume of (get volume settings) - 10)'"
            else:                  cmd = f"osascript -e 'set volume output volume {level}'"
        elif is_linux():
            lmap = {"up": "+10%", "down": "-10%", "mute": "toggle"}
            cmd = f"amixer set Master {lmap.get(level, level + '%')}"
        else:
            cmd = 'powershell -c "$obj = New-Object -com wscript.shell; $obj.SendKeys([char]174)"'
        await run_shell_async(cmd)
        await update.effective_message.reply_text(f"🔊 Volume set to <code>{esc(level)}</code>", parse_mode=H)

    @require_auth
    async def cmd_brightness(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/brightness &lt;0-100&gt;</code>", parse_mode=H
            )
            return
        level = ctx.args[0]
        if is_mac():
            cmd = f"osascript -e 'tell application \"System Events\" to set brightness to {int(level)/100}'"
        elif is_linux():
            out, _ = await run_shell_async("ls /sys/class/backlight/")
            device = out.split("\n")[0].strip()
            if device:
                max_b, _ = await run_shell_async(f"cat /sys/class/backlight/{device}/max_brightness")
                val = int(max_b.strip()) * int(level) // 100
                cmd = f"echo {val} | sudo tee /sys/class/backlight/{device}/brightness"
            else:
                cmd = f"xrandr --output $(xrandr | grep ' connected' | head -1 | cut -d' ' -f1) --brightness {int(level)/100}"
        else:
            cmd = f'powershell -c "(Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{level})"'
        await run_shell_async(cmd)
        await update.effective_message.reply_text(f"💡 Brightness → <code>{esc(level)}%</code>", parse_mode=H)

    @require_auth
    async def cmd_copy(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: <code>/copy &lt;text&gt;</code>", parse_mode=H)
            return
        text = " ".join(ctx.args)
        try:
            import pyperclip
            pyperclip.copy(text)
            await update.effective_message.reply_text(
                f"📋 Copied: <code>{esc(text[:200])}</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_paste(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            import pyperclip
            content = pyperclip.paste()
            if not content:
                await update.effective_message.reply_text("📋 Clipboard is empty.")
                return
            await update.effective_message.reply_text(
                f"📋 <b>Clipboard</b>\n\n<pre>{esc(content[:2000])}</pre>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_open(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/open &lt;app|file|url&gt;</code>\n"
                "Examples: <code>/open chrome</code>, <code>/open spotify</code>, "
                "<code>/open https://youtube.com</code>, <code>/open ~/Desktop/file.pdf</code>",
                parse_mode=H
            )
            return

        import shutil
        from pathlib import Path

        raw = " ".join(ctx.args).strip()

        # ── Smart app name resolver ──────────────────────────────────────────
        # Maps common natural names → actual executable / app name per OS
        APP_MAP_LINUX = {
            "chrome": ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"],
            "google chrome": ["google-chrome", "google-chrome-stable", "chromium-browser"],
            "chromium": ["chromium", "chromium-browser"],
            "firefox": ["firefox"],
            "safari": ["safari"],
            "brave": ["brave-browser", "brave"],
            "edge": ["microsoft-edge", "msedge"],
            "opera": ["opera"],
            "browser": ["google-chrome", "firefox", "chromium", "brave-browser"],
            "vscode": ["code"],
            "vs code": ["code"],
            "visual studio code": ["code"],
            "code": ["code"],
            "spotify": ["spotify"],
            "discord": ["discord"],
            "slack": ["slack"],
            "zoom": ["zoom"],
            "telegram": ["telegram-desktop", "telegram"],
            "vlc": ["vlc"],
            "gimp": ["gimp"],
            "obs": ["obs"],
            "obs studio": ["obs"],
            "terminal": ["x-terminal-emulator", "gnome-terminal", "konsole", "xterm"],
            "bash": ["gnome-terminal", "x-terminal-emulator", "xterm"],
            "console": ["gnome-terminal", "x-terminal-emulator"],
            "files": ["nautilus", "thunar", "nemo", "dolphin"],
            "file manager": ["nautilus", "thunar", "nemo"],
            "nautilus": ["nautilus"],
            "finder": ["nautilus"],
            "explorer": ["nautilus", "thunar"],
            "calculator": ["gnome-calculator", "kcalc", "galculator"],
            "settings": ["gnome-control-center", "systemsettings5"],
            "system settings": ["gnome-control-center"],
            "text editor": ["gedit", "kate", "mousepad", "xed"],
            "notepad": ["gedit", "kate", "mousepad"],
            "gedit": ["gedit"],
            "steam": ["steam"],
            "skype": ["skype"],
            "thunderbird": ["thunderbird"],
            "libreoffice": ["libreoffice"],
            "word": ["libreoffice --writer"],
            "excel": ["libreoffice --calc"],
            "powerpoint": ["libreoffice --impress"],
        }

        APP_MAP_MAC = {
            "chrome": "Google Chrome",
            "google chrome": "Google Chrome",
            "chromium": "Chromium",
            "firefox": "Firefox",
            "safari": "Safari",
            "brave": "Brave Browser",
            "edge": "Microsoft Edge",
            "opera": "Opera",
            "browser": "Google Chrome",
            "vscode": "Visual Studio Code",
            "vs code": "Visual Studio Code",
            "visual studio code": "Visual Studio Code",
            "code": "Visual Studio Code",
            "spotify": "Spotify",
            "discord": "Discord",
            "slack": "Slack",
            "zoom": "zoom.us",
            "telegram": "Telegram",
            "vlc": "VLC",
            "gimp": "GIMP",
            "obs": "OBS",
            "obs studio": "OBS",
            "terminal": "Terminal",
            "bash": "Terminal",
            "console": "Terminal",
            "iterm": "iTerm",
            "files": "Finder",
            "file manager": "Finder",
            "finder": "Finder",
            "explorer": "Finder",
            "calculator": "Calculator",
            "settings": "System Preferences",
            "system settings": "System Preferences",
            "preferences": "System Preferences",
            "text editor": "TextEdit",
            "notepad": "TextEdit",
            "textedit": "TextEdit",
            "steam": "Steam",
            "skype": "Skype",
            "thunderbird": "Thunderbird",
            "libreoffice": "LibreOffice",
            "word": "Microsoft Word",
            "excel": "Microsoft Excel",
            "powerpoint": "Microsoft PowerPoint",
            "pages": "Pages",
            "numbers": "Numbers",
            "keynote": "Keynote",
            "xcode": "Xcode",
            "maps": "Maps",
            "music": "Music",
            "photos": "Photos",
        }

        key = raw.lower().strip("'\"")

        # URLs — pass straight through
        if key.startswith(("http://", "https://", "www.")):
            resolved = raw
        # File paths — pass straight through
        elif key.startswith(("/", "~", "./")) or Path(raw).expanduser().exists():
            resolved = str(Path(raw).expanduser())
        # App name lookup
        elif is_mac():
            if key in APP_MAP_MAC:
                resolved = APP_MAP_MAC[key]
                cmd = f"open -a '{resolved}' 2>/dev/null || open '{resolved}'"
            else:
                # Try as-is with `open -a`
                resolved = raw
                cmd = f"open -a '{resolved}' 2>/dev/null || open '{resolved}'"
            out, rc = await run_shell_async(cmd)
            icon = "🚀" if rc == 0 else "❌"
            status = "opened" if rc == 0 else "failed to open"
            await update.effective_message.reply_text(
                f"{icon} {status.title()}: <code>{esc(resolved)}</code>",
                parse_mode=H
            )
            return
        elif is_windows():
            resolved = raw
            cmd = f"start '' \"{resolved}\""
            out, rc = await run_shell_async(cmd)
            await update.effective_message.reply_text(
                f"{'🚀' if rc == 0 else '❌'} <code>{esc(resolved)}</code>", parse_mode=H
            )
            return
        else:
            # Linux: try candidates in order until one works
            resolved = raw
            if key in APP_MAP_LINUX:
                candidates = APP_MAP_LINUX[key]
                # Find first installed candidate
                found = None
                for cand in candidates:
                    exe = cand.split()[0]  # handle "libreoffice --writer"
                    if shutil.which(exe):
                        found = cand
                        break
                if found:
                    resolved = found
                # else fall through with raw input

        # Linux default: use xdg-open for URLs/files, direct exec for apps
        if is_linux():
            if resolved.startswith(("http://", "https://", "www.", "/")):
                cmd = f"xdg-open '{resolved}' >/dev/null 2>&1 &"
            elif Path(resolved).expanduser().exists():
                cmd = f"xdg-open '{Path(resolved).expanduser()}' >/dev/null 2>&1 &"
            else:
                # Launch as application directly
                cmd = f"nohup {resolved} >/dev/null 2>&1 &"

            out, rc = await run_shell_async(cmd, timeout=5)
            # xdg-open launched in background — rc 0 means launched, not necessarily opened
            if rc in (0, -1):  # -1 = timeout (process launched successfully in bg)
                await update.effective_message.reply_text(
                    f"🚀 Launched: <code>{esc(resolved)}</code>", parse_mode=H
                )
            else:
                await update.effective_message.reply_text(
                    f"❌ Could not open <code>{esc(raw)}</code>\n"
                    f"<i>Make sure it's installed: <code>which {esc(raw.split()[0])}</code></i>",
                    parse_mode=H
                )
        else:
            # Fallback for any other OS
            out, rc = await run_shell_async(f"xdg-open '{resolved}' &")
            await update.effective_message.reply_text(
                f"{'🚀' if rc == 0 else '❌'} <code>{esc(resolved)}</code>", parse_mode=H
            )
