"""
File system handlers — browse, read, write, transfer, archive, search.
Uses HTML parse_mode to avoid Markdown entity errors with special chars in paths/filenames.
"""

from __future__ import annotations

import html
import io
import os
import shutil
import stat
import zipfile
from datetime import datetime
from pathlib import Path

import aiofiles
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import bytes_to_human, safe_read, run_shell_async

H = "HTML"

def esc(v) -> str:
    return html.escape(str(v), quote=False)


class FileHandlers:

    # ── /ls ──────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_ls(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = list(ctx.args or [])
        show_hidden = "-a" in args
        sort_size   = "-s" in args
        args = [a for a in args if not a.startswith("-")]
        path_str = " ".join(args) if args else self._cwd
        path = Path(path_str).expanduser().resolve()

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Path not found: <code>{esc(path)}</code>", parse_mode=H)
            return
        if not path.is_dir():
            ctx.args = [str(path)]
            await self.cmd_stat(update, ctx)
            return

        try:
            entries = list(path.iterdir())
        except PermissionError:
            await update.effective_message.reply_text("❌ Permission denied.")
            return

        if not show_hidden:
            entries = [e for e in entries if not e.name.startswith(".")]

        dirs  = sorted([e for e in entries if e.is_dir()],  key=lambda x: x.name)
        files = sorted([e for e in entries if e.is_file()], key=lambda x: (-x.stat().st_size if sort_size else x.name))

        lines = []
        for d in dirs[:50]:
            try:
                n = sum(1 for _ in d.iterdir())
                lines.append(f"📁 <code>{esc(d.name)}/</code> ({n} items)")
            except Exception:
                lines.append(f"📁 <code>{esc(d.name)}/</code>")

        for f in files[:50]:
            try:
                st  = f.stat()
                mod = datetime.fromtimestamp(st.st_mtime).strftime("%m-%d %H:%M")
                lines.append(f"📄 <code>{esc(f.name)}</code> {esc(bytes_to_human(st.st_size))} {mod}")
            except Exception:
                lines.append(f"📄 <code>{esc(f.name)}</code>")

        total = len(dirs) + len(files)
        header = f"📂 <b>{esc(path)}</b>\n<i>{total} items</i>\n\n"
        content = "\n".join(lines) or "<i>Empty directory</i>"
        if len(content) > 3000:
            content = content[:3000] + f"\n\n<i>...{total - 100} more items</i>"

        await update.effective_message.reply_text(header + content, parse_mode=H)

    # ── /cd ──────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_cd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        path = " ".join(ctx.args) if ctx.args else str(Path.home())
        resolved = Path(path).expanduser().resolve()
        if not resolved.is_dir():
            await update.effective_message.reply_text(f"❌ Not a directory: <code>{esc(resolved)}</code>", parse_mode=H)
            return
        self._cwd = str(resolved)
        try:
            count = sum(1 for _ in resolved.iterdir())
        except Exception:
            count = 0
        await update.effective_message.reply_text(
            f"📂 Now in: <code>{esc(resolved)}</code> ({count} items)", parse_mode=H
        )

    # ── /pwd ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_pwd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.reply_text(f"📂 <code>{esc(self._cwd)}</code>", parse_mode=H)

    # ── /cat ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_cat(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: <code>/cat &lt;file&gt;</code>", parse_mode=H)
            return
        path_str = " ".join(ctx.args)
        path = Path(path_str).expanduser() if path_str.startswith(("/", "~")) else Path(self._cwd) / path_str

        if not path.exists():
            await update.effective_message.reply_text(f"❌ File not found: <code>{esc(path)}</code>", parse_mode=H)
            return

        content, is_binary = safe_read(path)
        if is_binary:
            await update.effective_message.reply_text(
                f"⚠️ Binary file: {esc(content)}\nUse <code>/download {esc(path)}</code> to get it.", parse_mode=H
            )
            return

        if len(content) > 3500:
            buf = io.BytesIO(content.encode())
            buf.name = path.name
            await update.effective_message.reply_document(document=buf, filename=path.name)
        else:
            await update.effective_message.reply_text(
                f"📄 <code>{esc(path.name)}</code>\n\n<pre>{esc(content)}</pre>", parse_mode=H
            )

    # ── /stat ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_stat(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: <code>/stat &lt;path&gt;</code>", parse_mode=H)
            return
        path_str = " ".join(ctx.args)
        path = Path(path_str).expanduser()

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Not found: <code>{esc(path_str)}</code>", parse_mode=H)
            return

        st   = path.stat()
        mode = oct(stat.S_IMODE(st.st_mode))
        kind = "Directory" if path.is_dir() else ("Symlink" if path.is_symlink() else "File")

        text = (
            f"📋 <b>{esc(path.name)}</b>\n\n"
            f"Type:     {kind}\n"
            f"Path:     <code>{esc(path)}</code>\n"
            f"Size:     {esc(bytes_to_human(st.st_size))}\n"
            f"Mode:     {mode}\n"
            f"Modified: {datetime.fromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Created:  {datetime.fromtimestamp(st.st_ctime).strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Owner:    UID {st.st_uid} / GID {st.st_gid}"
        )
        if path.is_dir():
            try:
                total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
                text += f"\nDisk use: {esc(bytes_to_human(total))}"
            except Exception:
                pass
        await update.effective_message.reply_text(text, parse_mode=H)

    # ── /find ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_find(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/find &lt;pattern&gt; [in &lt;dir&gt;]</code>\n"
                "Example: <code>/find *.py in ~/Projects</code>", parse_mode=H
            )
            return

        args = list(ctx.args)
        pattern = args[0]
        search_dir = self._cwd
        if "in" in args[1:]:
            idx = args.index("in", 1)
            search_dir = " ".join(args[idx + 1:])

        await update.effective_message.reply_text(
            f"🔍 Searching for <code>{esc(pattern)}</code> in <code>{esc(search_dir)}</code>...", parse_mode=H
        )
        out, rc = await run_shell_async(f'find {search_dir!r} -name "{pattern}" 2>/dev/null | head -50')
        if not out or out == "(no output)":
            await update.effective_message.reply_text("🔍 No files found.")
        else:
            lines = out.split("\n")
            await update.effective_message.reply_text(
                f"🔍 <b>Found {len(lines)} result(s)</b>\n\n<pre>{esc(out[:2000])}</pre>", parse_mode=H
            )

    # ── /grep ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_grep(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/grep &lt;pattern&gt; [path]</code>", parse_mode=H
            )
            return
        pattern = ctx.args[0]
        path    = ctx.args[1] if len(ctx.args) > 1 else self._cwd
        flags   = " ".join(ctx.args[2:]) if len(ctx.args) > 2 else "-rn --color=never"
        cmd     = f"grep {flags} {pattern!r} {path!r} 2>/dev/null | head -40"

        out, rc = await run_shell_async(cmd)
        if not out or out == "(no output)":
            await update.effective_message.reply_text(f"🔍 No matches for <code>{esc(pattern)}</code>", parse_mode=H)
        else:
            await update.effective_message.reply_text(
                f"🔍 <code>{esc(pattern)}</code>\n\n<pre>{esc(out[:2500])}</pre>", parse_mode=H
            )

    # ── /mkdir ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_mkdir(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: <code>/mkdir &lt;dirname&gt;</code>", parse_mode=H)
            return
        path = Path(self._cwd) / " ".join(ctx.args)
        try:
            path.mkdir(parents=True, exist_ok=True)
            await update.effective_message.reply_text(f"✅ Created <code>{esc(path)}</code>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}")

    # ── /rm ──────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_rm(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: <code>/rm &lt;path&gt; [-r]</code>", parse_mode=H)
            return
        recursive = "-r" in ctx.args
        args = [a for a in ctx.args if a != "-r"]
        path = Path(" ".join(args)).expanduser()

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Not found: <code>{esc(path)}</code>", parse_mode=H)
            return

        keyboard = [[
            InlineKeyboardButton("✅ Yes, delete", callback_data=f"rm_confirm:{path}:{recursive}"),
            InlineKeyboardButton("❌ Cancel",       callback_data="rm_cancel")
        ]]
        await update.effective_message.reply_text(
            f"⚠️ Delete <code>{esc(path)}</code>?{'  <i>(recursive)</i>' if recursive else ''}",
            parse_mode=H,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    async def cb_rm_confirm(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data.replace("rm_confirm:", "").split(":")
        path_str, recursive_str = data[0], data[1]
        path = Path(path_str)
        recursive = recursive_str == "True"
        try:
            if path.is_dir() and recursive:
                shutil.rmtree(path)
            elif path.is_file():
                path.unlink()
            else:
                await query.edit_message_text("❌ Use -r flag to delete directories.")
                return
            await query.edit_message_text(f"✅ Deleted <code>{esc(path)}</code>", parse_mode=H)
        except Exception as e:
            await query.edit_message_text(f"❌ {esc(e)}")

    # ── /mv / /cp ────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_mv(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: <code>/mv &lt;src&gt; &lt;dst&gt;</code>", parse_mode=H)
            return
        mid = len(ctx.args) // 2
        src = Path(" ".join(ctx.args[:mid])).expanduser()
        dst = Path(" ".join(ctx.args[mid:])).expanduser()
        try:
            shutil.move(str(src), str(dst))
            await update.effective_message.reply_text(
                f"✅ Moved <code>{esc(src.name)}</code> → <code>{esc(dst)}</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}")

    @require_auth
    async def cmd_cp(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: <code>/cp &lt;src&gt; &lt;dst&gt;</code>", parse_mode=H)
            return
        mid = len(ctx.args) // 2
        src = Path(" ".join(ctx.args[:mid])).expanduser()
        dst = Path(" ".join(ctx.args[mid:])).expanduser()
        try:
            if src.is_dir():
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            await update.effective_message.reply_text(
                f"✅ Copied <code>{esc(src.name)}</code> → <code>{esc(dst)}</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}")

    # ── /download ────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_download(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: <code>/download &lt;filepath&gt;</code>", parse_mode=H)
            return
        path_str = " ".join(ctx.args)
        path = Path(path_str).expanduser() if path_str.startswith(("/", "~")) else Path(self._cwd) / path_str

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Not found: <code>{esc(path)}</code>", parse_mode=H)
            return

        if path.is_dir():
            await update.effective_message.reply_text(f"📦 Zipping <code>{esc(path.name)}</code>...", parse_mode=H)
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in path.rglob("*"):
                    if f.is_file():
                        zf.write(f, f.relative_to(path))
            buf.seek(0)
            await update.effective_message.reply_document(
                document=buf, filename=path.name + ".zip",
                caption=f"📦 {esc(path.name)}/ (zipped)"
            )
            return

        size = path.stat().st_size
        max_bytes = self.config.max_file_mb * 1024 * 1024
        if size > max_bytes:
            await update.effective_message.reply_text(
                f"❌ File too large ({esc(bytes_to_human(size))}). Max: {self.config.max_file_mb}MB.\n"
                f"Adjust with <code>/config set max_file_mb &lt;n&gt;</code>", parse_mode=H
            )
            return

        await update.effective_message.reply_text(f"📤 Sending <code>{esc(path.name)}</code>...", parse_mode=H)
        async with aiofiles.open(path, "rb") as f:
            data = await f.read()
        buf = io.BytesIO(data)
        buf.name = path.name
        await update.effective_message.reply_document(
            document=buf, filename=path.name,
            caption=f"📥 {esc(path.name)} · {esc(bytes_to_human(size))}"
        )

    # ── /upload ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_upload_prompt(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.reply_text(
            f"📤 Send me any file now and I'll save it to:\n<code>{esc(self.config.upload_dir)}</code>",
            parse_mode=H
        )

    async def handle_document(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if not self.auth.is_allowed(user.id):
            return
        doc  = update.effective_message.document
        dest = Path(str(self.config.upload_dir)) / doc.file_name

        await update.effective_message.reply_text(f"📥 Saving <code>{esc(doc.file_name)}</code>...", parse_mode=H)
        file_obj = await ctx.bot.get_file(doc.file_id)
        buf = io.BytesIO()
        await file_obj.download_to_memory(buf)
        buf.seek(0)

        async with aiofiles.open(dest, "wb") as f:
            await f.write(buf.read())

        await update.effective_message.reply_text(
            f"✅ Saved to <code>{esc(dest)}</code> ({esc(bytes_to_human(dest.stat().st_size))})",
            parse_mode=H
        )

    # ── /zip / /unzip ────────────────────────────────────────────────────────
    @require_auth
    async def cmd_zip(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/zip &lt;source_path&gt; [output.zip]</code>", parse_mode=H
            )
            return
        src_path = Path(" ".join(ctx.args)).expanduser()
        out_path = Path(self._cwd) / (src_path.name + ".zip")

        if not src_path.exists():
            await update.effective_message.reply_text(f"❌ Not found: <code>{esc(src_path)}</code>", parse_mode=H)
            return

        await update.effective_message.reply_text(f"📦 Zipping <code>{esc(src_path.name)}</code>...", parse_mode=H)
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
            if src_path.is_dir():
                for f in src_path.rglob("*"):
                    if f.is_file():
                        zf.write(f, f.relative_to(src_path.parent))
            else:
                zf.write(src_path, src_path.name)

        await update.effective_message.reply_text(
            f"✅ Created <code>{esc(out_path.name)}</code> ({esc(bytes_to_human(out_path.stat().st_size))})",
            parse_mode=H
        )

    @require_auth
    async def cmd_unzip(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/unzip &lt;file.zip&gt; [destination]</code>", parse_mode=H
            )
            return
        zip_path = Path(ctx.args[0]).expanduser()
        dest     = Path(ctx.args[1]).expanduser() if len(ctx.args) > 1 else Path(self._cwd)
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(dest)
                names = zf.namelist()
            await update.effective_message.reply_text(
                f"✅ Extracted {len(names)} files → <code>{esc(dest)}</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}")

    # ── /write ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_write(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text(
                "Usage: <code>/write &lt;filename&gt; &lt;content&gt;</code>", parse_mode=H
            )
            return
        filename = ctx.args[0]
        content  = " ".join(ctx.args[1:])
        path = Path(self._cwd) / filename
        try:
            path.write_text(content)
            await update.effective_message.reply_text(
                f"✅ Written to <code>{esc(path)}</code> ({len(content)} chars)", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}")
