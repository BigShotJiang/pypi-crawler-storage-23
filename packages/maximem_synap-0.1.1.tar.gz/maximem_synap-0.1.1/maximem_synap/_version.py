"""Version information for MaximemSynap SDK."""

__version__ = "0.1.1"
