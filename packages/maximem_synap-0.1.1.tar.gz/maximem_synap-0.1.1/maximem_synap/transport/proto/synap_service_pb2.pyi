from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StreamEvent(_message.Message):
    __slots__ = ("conversation_event", "heartbeat_ping", "session_control")
    CONVERSATION_EVENT_FIELD_NUMBER: _ClassVar[int]
    HEARTBEAT_PING_FIELD_NUMBER: _ClassVar[int]
    SESSION_CONTROL_FIELD_NUMBER: _ClassVar[int]
    conversation_event: ConversationEvent
    heartbeat_ping: HeartbeatPing
    session_control: SessionControl
    def __init__(self, conversation_event: _Optional[_Union[ConversationEvent, _Mapping]] = ..., heartbeat_ping: _Optional[_Union[HeartbeatPing, _Mapping]] = ..., session_control: _Optional[_Union[SessionControl, _Mapping]] = ...) -> None: ...

class ConversationEvent(_message.Message):
    __slots__ = ("event_type", "conversation_id", "user_id", "role", "content", "customer_id", "session_id", "metadata", "timestamp_ms", "tool_name", "tool_args_json", "search_queries", "context_types")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    CUSTOMER_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_MS_FIELD_NUMBER: _ClassVar[int]
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    TOOL_ARGS_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_QUERIES_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_TYPES_FIELD_NUMBER: _ClassVar[int]
    event_type: str
    conversation_id: str
    user_id: str
    role: str
    content: str
    customer_id: str
    session_id: str
    metadata: _containers.ScalarMap[str, str]
    timestamp_ms: int
    tool_name: str
    tool_args_json: str
    search_queries: _containers.RepeatedScalarFieldContainer[str]
    context_types: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, event_type: _Optional[str] = ..., conversation_id: _Optional[str] = ..., user_id: _Optional[str] = ..., role: _Optional[str] = ..., content: _Optional[str] = ..., customer_id: _Optional[str] = ..., session_id: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., timestamp_ms: _Optional[int] = ..., tool_name: _Optional[str] = ..., tool_args_json: _Optional[str] = ..., search_queries: _Optional[_Iterable[str]] = ..., context_types: _Optional[_Iterable[str]] = ...) -> None: ...

class HeartbeatPing(_message.Message):
    __slots__ = ("timestamp_ms",)
    TIMESTAMP_MS_FIELD_NUMBER: _ClassVar[int]
    timestamp_ms: int
    def __init__(self, timestamp_ms: _Optional[int] = ...) -> None: ...

class SessionControl(_message.Message):
    __slots__ = ("action", "session_id", "conversation_id", "user_id", "customer_id")
    ACTION_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    CONVERSATION_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    CUSTOMER_ID_FIELD_NUMBER: _ClassVar[int]
    action: str
    session_id: str
    conversation_id: str
    user_id: str
    customer_id: str
    def __init__(self, action: _Optional[str] = ..., session_id: _Optional[str] = ..., conversation_id: _Optional[str] = ..., user_id: _Optional[str] = ..., customer_id: _Optional[str] = ...) -> None: ...

class StreamResponse(_message.Message):
    __slots__ = ("context_bundle", "heartbeat_pong", "signal")
    CONTEXT_BUNDLE_FIELD_NUMBER: _ClassVar[int]
    HEARTBEAT_PONG_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_FIELD_NUMBER: _ClassVar[int]
    context_bundle: ContextBundleProto
    heartbeat_pong: HeartbeatPong
    signal: StreamSignal
    def __init__(self, context_bundle: _Optional[_Union[ContextBundleProto, _Mapping]] = ..., heartbeat_pong: _Optional[_Union[HeartbeatPong, _Mapping]] = ..., signal: _Optional[_Union[StreamSignal, _Mapping]] = ...) -> None: ...

class HeartbeatPong(_message.Message):
    __slots__ = ("timestamp_ms",)
    TIMESTAMP_MS_FIELD_NUMBER: _ClassVar[int]
    timestamp_ms: int
    def __init__(self, timestamp_ms: _Optional[int] = ...) -> None: ...

class StreamSignal(_message.Message):
    __slots__ = ("signal_type", "reason", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    SIGNAL_TYPE_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    signal_type: str
    reason: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, signal_type: _Optional[str] = ..., reason: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class ContextBundleProto(_message.Message):
    __slots__ = ("bundle_id", "decision_id", "items_by_type", "total_tokens", "token_budget", "budget_exceeded", "retrieval_mode", "sources_queried", "degradation_level", "warnings", "created_at", "retrieval_time_ms", "cache_hit")
    class ItemsByTypeEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: ContextItemList
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[ContextItemList, _Mapping]] = ...) -> None: ...
    BUNDLE_ID_FIELD_NUMBER: _ClassVar[int]
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    ITEMS_BY_TYPE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOKEN_BUDGET_FIELD_NUMBER: _ClassVar[int]
    BUDGET_EXCEEDED_FIELD_NUMBER: _ClassVar[int]
    RETRIEVAL_MODE_FIELD_NUMBER: _ClassVar[int]
    SOURCES_QUERIED_FIELD_NUMBER: _ClassVar[int]
    DEGRADATION_LEVEL_FIELD_NUMBER: _ClassVar[int]
    WARNINGS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    RETRIEVAL_TIME_MS_FIELD_NUMBER: _ClassVar[int]
    CACHE_HIT_FIELD_NUMBER: _ClassVar[int]
    bundle_id: str
    decision_id: str
    items_by_type: _containers.MessageMap[str, ContextItemList]
    total_tokens: int
    token_budget: int
    budget_exceeded: bool
    retrieval_mode: str
    sources_queried: _containers.RepeatedScalarFieldContainer[str]
    degradation_level: str
    warnings: _containers.RepeatedScalarFieldContainer[str]
    created_at: str
    retrieval_time_ms: int
    cache_hit: bool
    def __init__(self, bundle_id: _Optional[str] = ..., decision_id: _Optional[str] = ..., items_by_type: _Optional[_Mapping[str, ContextItemList]] = ..., total_tokens: _Optional[int] = ..., token_budget: _Optional[int] = ..., budget_exceeded: bool = ..., retrieval_mode: _Optional[str] = ..., sources_queried: _Optional[_Iterable[str]] = ..., degradation_level: _Optional[str] = ..., warnings: _Optional[_Iterable[str]] = ..., created_at: _Optional[str] = ..., retrieval_time_ms: _Optional[int] = ..., cache_hit: bool = ...) -> None: ...

class ContextItemList(_message.Message):
    __slots__ = ("items",)
    ITEMS_FIELD_NUMBER: _ClassVar[int]
    items: _containers.RepeatedCompositeFieldContainer[ContextItemProto]
    def __init__(self, items: _Optional[_Iterable[_Union[ContextItemProto, _Mapping]]] = ...) -> None: ...

class ContextItemProto(_message.Message):
    __slots__ = ("item_id", "content", "context_type", "source", "similarity_score", "relevance_score", "confidence", "scope", "entity_id", "created_at")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_TYPE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    SIMILARITY_SCORE_FIELD_NUMBER: _ClassVar[int]
    RELEVANCE_SCORE_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    content: str
    context_type: str
    source: str
    similarity_score: float
    relevance_score: float
    confidence: float
    scope: str
    entity_id: str
    created_at: str
    def __init__(self, item_id: _Optional[str] = ..., content: _Optional[str] = ..., context_type: _Optional[str] = ..., source: _Optional[str] = ..., similarity_score: _Optional[float] = ..., relevance_score: _Optional[float] = ..., confidence: _Optional[float] = ..., scope: _Optional[str] = ..., entity_id: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class TelemetryEvent(_message.Message):
    __slots__ = ("event_type", "instance_id", "client_id", "correlation_id", "timestamp_ms", "latency_ms", "status", "error_code", "scope", "cache_status", "attempt", "http_method", "http_path", "http_status_code", "metadata", "sdk_version", "batch_id")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    INSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    CORRELATION_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_MS_FIELD_NUMBER: _ClassVar[int]
    LATENCY_MS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_FIELD_NUMBER: _ClassVar[int]
    CACHE_STATUS_FIELD_NUMBER: _ClassVar[int]
    ATTEMPT_FIELD_NUMBER: _ClassVar[int]
    HTTP_METHOD_FIELD_NUMBER: _ClassVar[int]
    HTTP_PATH_FIELD_NUMBER: _ClassVar[int]
    HTTP_STATUS_CODE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    SDK_VERSION_FIELD_NUMBER: _ClassVar[int]
    BATCH_ID_FIELD_NUMBER: _ClassVar[int]
    event_type: str
    instance_id: str
    client_id: str
    correlation_id: str
    timestamp_ms: int
    latency_ms: int
    status: str
    error_code: str
    scope: str
    cache_status: str
    attempt: int
    http_method: str
    http_path: str
    http_status_code: int
    metadata: _containers.ScalarMap[str, str]
    sdk_version: str
    batch_id: str
    def __init__(self, event_type: _Optional[str] = ..., instance_id: _Optional[str] = ..., client_id: _Optional[str] = ..., correlation_id: _Optional[str] = ..., timestamp_ms: _Optional[int] = ..., latency_ms: _Optional[int] = ..., status: _Optional[str] = ..., error_code: _Optional[str] = ..., scope: _Optional[str] = ..., cache_status: _Optional[str] = ..., attempt: _Optional[int] = ..., http_method: _Optional[str] = ..., http_path: _Optional[str] = ..., http_status_code: _Optional[int] = ..., metadata: _Optional[_Mapping[str, str]] = ..., sdk_version: _Optional[str] = ..., batch_id: _Optional[str] = ...) -> None: ...

class TelemetryAck(_message.Message):
    __slots__ = ("status", "events_received")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    EVENTS_RECEIVED_FIELD_NUMBER: _ClassVar[int]
    status: str
    events_received: int
    def __init__(self, status: _Optional[str] = ..., events_received: _Optional[int] = ...) -> None: ...
