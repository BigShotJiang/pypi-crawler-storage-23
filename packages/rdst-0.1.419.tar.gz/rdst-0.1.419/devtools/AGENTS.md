# Devtools Instructions

## Storybook HTML Export

To render the RDST design system gallery HTML, run:

```bash
uv run devtools/render_storybook_html.py
```

This writes `devtools/storybook_output.html`.
