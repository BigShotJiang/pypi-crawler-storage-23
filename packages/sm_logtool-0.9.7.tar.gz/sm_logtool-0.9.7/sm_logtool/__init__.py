"""Core package for the sm-logtool application."""

__all__ = [
    "__version__",
]

__version__ = "0.9.7"
