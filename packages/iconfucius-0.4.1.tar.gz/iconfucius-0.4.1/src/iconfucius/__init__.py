"""IConfucius | Wisdom for Bitcoin Markets"""

__version__ = "0.4.1"
