import sympy
from sympy import Symbol

class Equation(str):
    def __new__(cls, object):
        return super().__new__(cls, object)

symbols: dict[str, Symbol] = {}
def defsym(syms: list[str]) -> list[Symbol]:
    symstrlst: list[str] = syms.replace("\n", "").replace(" ", "").split(",")
    symlst: list[Symbol] = sympy.symbols(syms)

    for onestmstr, onesym in zip(symstrlst, symlst):
        symbols[onestmstr] = onesym
    return list(symlst)

def defequ(equs: list[str]) -> list[Equation]:
    result: list[Equation] = []
    for equ in equs.replace("\n", "").replace(" ", "").split(","):
        result.append(Equation(equ))

    return result

def solve(syms: list[Symbol], equation: list[str], tostr: bool = True) -> dict[Symbol, int]:
    eqexprs: list[Symbol] = []
    for eq in equation:
        eqclean: str = eq.replace("\n", "").replace(" ", "")
        
        if '=' in eqclean:
            left, right = eqclean.split('=', 1)
            expr: str = f"{left} - ({right})"
        else:
            expr: str = eqclean
        
        exprsympy: Symbol = sympy.sympify(expr)
        eqexprs.append(exprsympy)
    
    solutions: dict[Symbol, int] = sympy.solve(eqexprs, syms)

    if tostr:
        result: dict[Symbol, int] = {}
        for key, val in solutions.items():
            result[str(key)] = val
    else:
        result = solutions

    return result

# cnfunc