from setuptools import setup, find_packages

setup(
    name="cnfunc",
    version="0.0.1",
    packages=find_packages(),
    description="A Python library for solving equations",
    long_description=open("README.md", encoding="UTF-8").read(),
    long_description_content_type="text/markdown",
    author="Negative Acknowledge",
    author_email="18114055256@163.com",
    url="https://github.com/JimmyJimmy666/cnfunc",
    license="MIT",
    install_requires=[
        "sympy"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)