# The origin of **cnfunc**'s name
This name is made up of two parts, **cn** and **func**  

**cn** is the international abbreviation for **China**  
**func** is function, and it is a pun on China's "**方程 (equation)**"

> Equations first appeared in China's **《九章算术》("Nine Chapters on the Mathematical Art")**.  
> The concept of "equations" in The **《九章算术》("Nine Chapters on the Mathematical Art")** appeared about **1500** years earlier than in the West.

# Author
Made by **Negative Acknowledge (NAK)**

# Function/Equation
Based on **sympy**, a more concise method is provided

# Download
Github repository page `https://github.com/JimmyJimmy666/cnfunc.git`  
Github cmdline `git clone https://github.com/JimmyJimmy666/cnfunc.git`  
System cmdline `https://codeload.github.com/JimmyJimmy666/cnfunc/zip/refs/heads/main`  
Pip `pip install cnfunc`  

# A simple demo of cnfunc
```python
import cnfunc
print(Math.solve(Math.defsym("x, y"), 
                 Math.defequ("x + 1 = 2, x = y")
))
```

> If you need to quickly get an answer, it is recommended to use "**import Math**". For medium to large projects, it is recommended to use "**from Math import Symbol, Equation**".