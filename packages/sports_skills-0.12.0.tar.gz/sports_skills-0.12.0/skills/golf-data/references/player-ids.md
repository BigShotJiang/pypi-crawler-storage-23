# Common Golf Player IDs (ESPN)

| Player | ID | Player | ID |
|--------|-----|--------|-----|
| Scottie Scheffler | 9478 | Nelly Korda | 9012 |
| Rory McIlroy | 3470 | Jin Young Ko | 9758 |
| Jon Rahm | 9780 | Lydia Ko | 7956 |
| Collin Morikawa | 10592 | Lilia Vu | 9401 |
| Xander Schauffele | 10404 | Nasa Hataoka | 10484 |
| Viktor Hovland | 10503 | Atthaya Thitikul | 10982 |
| Hideki Matsuyama | 5765 | Celine Boutier | 9133 |
| Ludvig Aberg | 4686088 | Lexi Thompson | 6843 |

**Tip:** Use `get_leaderboard` to find current player IDs from the active tournament.
