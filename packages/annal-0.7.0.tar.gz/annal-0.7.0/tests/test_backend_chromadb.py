"""ChromaDB-specific backend tests.

Shared conformance tests live in test_backend_conformance.py.
This file exists for any ChromaDB-specific behavior not covered there.
"""
