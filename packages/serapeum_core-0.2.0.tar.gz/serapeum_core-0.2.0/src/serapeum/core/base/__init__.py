"""Base abstractions and shared types for LLM backends."""
