import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Annotated, Literal, TypeVar, Union
from pydantic import BaseModel, Field, NatsDsn, SecretStr, AnyUrl
from pydantic_settings import BaseSettings

if TYPE_CHECKING:
    from prometheus_client import CollectorRegistry  # type: ignore[import-untyped]

class Tags:
    supporting_infra = "supporting_infra"


class ResourceTags(str, Enum):
    mysql_dsn = "MySQLDsn"
    mysql_username = "mysql_username"
    mysql_password = "mysql_password"
    mysql_host = "mysql_host"
    mysql_port = "mysql_port"
    mysql_db = "mysql_db"

    redis_dsn = "RedisDsn"
    redis_username = "redis_username"
    redis_password = "redis_password"
    redis_host = "redis_host"
    redis_port = "redis_port"

    mongo_dsn = "MongoDsn"

    mongo_host = "mongo_host"
    mongo_password = "mongo_password"
    mongo_username = "mongo_username"
    mongo_port = "mongo_port"
    mongo_ssl = "mongo_ssl"

    psql_dsn = "PostgresDsn"

    psql_host = "psql_host"
    psql_name = "psql_name"
    psql_password = "psql_password"
    psql_username = "psql_username"
    psql_ssl = "psql_ssl"
    psql_port = "psql_port"

    sqs_endpoint = "sqs_endpoint"
    sqs_access_key = "sqs_access_key"
    sqs_secret_key = "sqs_secret_key"
    sqs_region_name = "sqs_region_name"

    s3_endpoint = "s3_endpoint"
    s3_access_key = "s3_access_key"
    s3_secret_key = "s3_secret_key"
    s3_region_name = "s3_region_name"
    s3_bucket_name = "s3_bucket_name"

    mlflow_tracking_uri = "mlflow_tracking_uri"
    mlflow_registry_uri = "mlflow_registry_uri"

    nats_dsn = "NatsDsn"
    nats_creds_file = "nats_creds_file"

    loki_push_endpoint = "loki_push_endpoint"
    loki_base_url = "loki_base_url"
    loki_user = "loki_user"
    loki_token = "loki_token"

    mimir_base_url = "mimir_base_url"
    mimir_token = "mimir_token"

    slack_webhook_url = "slack_webhook_url"
    discord_webhook_url = "discord_webhook_url"
    teams_webhook_url = "teams_webhook_url"

    database_host = "database_host"
    database_name = "database_name"
    database_password = "database_password"
    database_username = "database_username"
    database_ssl = "database_ssl"
    database_port = "database_port"

    opensearch_url = "opensearch_url"
    opensearch_host = "opensearch_host"
    opensearch_port = "opensearch_port"
    opensearch_user = "opensearch_user"
    opensearch_password = "opensearch_password"

    kafka_dsn = "KafkaDsn"
    kafka_bootstrap_servers = "kafka_bootstrap_servers"
    kafka_host = "kafka_host"
    kafka_port = "kafka_port"

    clickhouse_dsn = "ClickHouseDsn"
    clickhouse_host = "clickhouse_host"
    clickhouse_port = "clickhouse_port"
    clickhouse_username = "clickhouse_username"
    clickhouse_password = "clickhouse_password"
    clickhouse_database = "clickhouse_database"

    spark_connect_url = "spark_connect_url"
    spark_master_url = "spark_master_url"
    spark_ui_url = "spark_ui_url"

    llm_base_api = "llm_base_api" # With /api/v1 aka. OpenAI compatible
    llm_base_url = "llm_base_url" # Without the /api/va aka. anthropic compatible
    llm_token = "llm_token"

    environment = "environment"

    @staticmethod
    def is_tag(tag: str) -> bool:
        try:
            ResourceTags(tag)
            return True
        except ValueError:
            return False

    

Environments = Literal["dev", "test", "prod", "qa"]

OpenSearchUrl = Annotated[AnyUrl, ResourceTags.opensearch_url]
OpenSearchHost = Annotated[str, ResourceTags.opensearch_host]
OpenSearchPassword = Annotated[SecretStr, ResourceTags.opensearch_password]
OpenSearchUser = Annotated[str, ResourceTags.opensearch_user]
OpenSearchPort = Annotated[int, ResourceTags.opensearch_port]

KafkaBootstrapServers = Annotated[str, ResourceTags.kafka_bootstrap_servers]
KafkaHost = Annotated[str, ResourceTags.kafka_host]
KafkaPort = Annotated[int, ResourceTags.kafka_port]

ClickhouseHost = Annotated[str, ResourceTags.clickhouse_host]
ClickhousePort = Annotated[int, ResourceTags.clickhouse_port]
ClickhouseUsername = Annotated[str, ResourceTags.clickhouse_username]
ClickhousePassword = Annotated[SecretStr, ResourceTags.clickhouse_password]
ClickhouseDatabase = Annotated[str, ResourceTags.clickhouse_database]

SparkConnectUrl = Annotated[str, ResourceTags.spark_connect_url]
SparkMasterUrl = Annotated[str, ResourceTags.spark_master_url]
SparkUiUrl = Annotated[str, ResourceTags.spark_ui_url]

SqsEndpoint = Annotated[AnyUrl, ResourceTags.sqs_endpoint]
SqsAccessKey = Annotated[str, ResourceTags.sqs_access_key]
SqsSecretKey = Annotated[SecretStr, ResourceTags.sqs_secret_key]
SqsRegionName = Annotated[str, ResourceTags.sqs_region_name]

S3Endpoint = Annotated[AnyUrl, ResourceTags.s3_endpoint]
S3AccessKey = Annotated[str, ResourceTags.s3_access_key]
S3SecretKey = Annotated[SecretStr, ResourceTags.s3_secret_key]
S3RegionName = Annotated[str, ResourceTags.s3_region_name]
S3BucketName = Annotated[str, ResourceTags.s3_bucket_name]

MlflowTrackingUri = Annotated[AnyUrl, ResourceTags.mlflow_tracking_uri]
MlflowRegistryUri = Annotated[AnyUrl, ResourceTags.mlflow_registry_uri]

NatsCredsFile = Annotated[str, ResourceTags.nats_creds_file]

LokiPushEndpoint = Annotated[str, ResourceTags.loki_push_endpoint]
LokiUser = Annotated[str | None, ResourceTags.loki_user]
LokiToken = Annotated[SecretStr | None, ResourceTags.loki_token]

MimirBaseUrl = Annotated[str, ResourceTags.mimir_base_url]
MimirToken = Annotated[SecretStr | None, ResourceTags.mimir_token]

SlackWebhookUrl = Annotated[str, ResourceTags.slack_webhook_url]
DiscordWebhookUrl = Annotated[str, ResourceTags.discord_webhook_url]
TeamsWebhookUrl = Annotated[str, ResourceTags.teams_webhook_url]

DatabaseHost = Annotated[str, ResourceTags.database_host]
DatabaseName = Annotated[str, ResourceTags.database_name]
DatabaseUsername = Annotated[str, ResourceTags.database_username]
DatabasePassword = Annotated[str, ResourceTags.database_password]
DatabaseSsl = Annotated[str, ResourceTags.database_ssl]

PostgresHost = Annotated[str, ResourceTags.psql_host]
PostgresName = Annotated[str, ResourceTags.psql_name]
PostgresUsername = Annotated[str, ResourceTags.psql_username]
PostgresPassword = Annotated[SecretStr, ResourceTags.psql_password]
PostgresSsl = Annotated[str, ResourceTags.psql_ssl]

LLMBaseAPI = Annotated[AnyUrl, ResourceTags.llm_base_api]
LLMBaseUrl = Annotated[AnyUrl, ResourceTags.llm_base_url]
LLMToken = Annotated[SecretStr, ResourceTags.llm_token]

AiBaseAPI = Annotated[AnyUrl, ResourceTags.llm_base_api]
AiBaseUrl = Annotated[AnyUrl, ResourceTags.llm_base_url]
AiToken = Annotated[SecretStr, ResourceTags.llm_token]

TakkChatModels = Literal["qwen3-235b-a22b-instruct-2507", "gpt-oss-120b", "mistral-small-3.2-24b-instruct-2506", "devstral-2-123b-instruct-2512", "holo2-30b-a3b", "llama-3.3-70b-instruct", "qwen3-coder-30b-a3b-instruct", "pixtral-12b-2409", "voxtral-small-24b-2507", "gemma-3-27b-it"]
TakkLlmModels = TakkChatModels
TakkEmbeddingModels = Literal["qwen3-embedding-8b", "bge-multilingual-gemma2"]
TakkVisionModels = Literal["mistral-small-3.2-24b-instruct-2506", "holo2-30b-a3b", "pixtral-12b-2409", "gemma-3-27b-it"]
TakkAudioTranscriptionModels = Literal["voxtral-small-24b-2507", "whisper-large-v3"]


T = TypeVar("T", bound=BaseModel)


@dataclass
class ResourceRef:
    tag: ResourceTags
    name: str = field(default="default")

    def __hash__(self) -> int:
        return hash(self.to_string())

    def __str__(self) -> str:
        return self.to_string()

    def to_string(self) -> str:
        return f"{self.tag.value}:{self.name}"

    @staticmethod
    def from_string(val: str) -> "ResourceRef":
        tag, _, name = val.partition(":") 
        if name:
            return ResourceRef(ResourceTags(tag), name)
        else:
            return ResourceRef(ResourceTags(tag))


@dataclass
class ServiceUrl:

    value: str
    url_type: Literal["internal", "external"]

    def __str__(self) -> str:
        return self.to_string()

    def to_string(self) -> str:
        return f"service:{self.value}:{self.url_type}"

    @staticmethod
    def from_string(val: str) -> Union["ServiceUrl", None]:
        if not val.startswith("service:"):
            return None
        val, url_type = val.removeprefix("service:").split(":")
        return ServiceUrl(val, url_type) # type: ignore


def settings_for_resources(resources: dict[str, str], settings_type: type[T]) -> T:
    from takk.models import settings_for_secrets, secrets_for

    vals = {
        key.lower(): val
        for key, val in settings_for_secrets(
            secrets_for(settings_type),
            resources
        ).items()
    }
    return settings_type.model_validate(vals)


class NatsConfig(BaseSettings):
    nats_url: NatsDsn
    nats_credentials: NatsCredsFile | None = Field(default=None)


class SqsConfig(BaseSettings):
    sqs_endpoint: SqsEndpoint
    sqs_access_key: SqsAccessKey
    sqs_secret_key: SqsSecretKey
    sqs_region_name: SqsRegionName


class SqsQueueSettings(BaseModel):

    wait_time_seconds: int = Field(default=10)
    max_message_size_kbs: int = Field(default=258)
    max_number_of_messages: int = Field(default=1)
    visibility_timeout_seconds: int = Field(default=30)
    message_retention_period_seconds: int = Field(default=60)


    def attributes(self) -> dict[str, str]:
        return {
            "VisibilityTimeout": str(self.visibility_timeout_seconds),
            "MessageRetentionPeriod": str(self.message_retention_period_seconds),
            "MaximumMessageSize": str(self.max_message_size_kbs * (2 ^ 10)),
            "ReceiveMessageWaitTimeSeconds": str(self.wait_time_seconds)
        }


class UnleashConfig(BaseSettings):
    database_host: DatabaseHost
    database_name: DatabaseName
    database_password: DatabasePassword
    database_username: DatabaseUsername
    database_ssl: DatabaseSsl


class ObjectStorageConfig(BaseSettings):
    object_storage_access_key: S3AccessKey
    object_storage_secret_key: S3SecretKey
    object_storage_region: S3RegionName


class S3StorageConfig(BaseSettings):
    s3_access_key: S3AccessKey
    s3_secret_key: S3SecretKey
    s3_region: S3RegionName
    s3_endpoint: Annotated[AnyUrl | None, ResourceTags.s3_endpoint] = None
    s3_bucket: Annotated[str | None, ResourceTags.s3_bucket_name] = None


class MlflowConfig(BaseSettings):
    mlflow_tracking_uri: MlflowTrackingUri
    mlflow_registry_uri: MlflowRegistryUri


class LokiLoggerConfig(BaseSettings):
    loki_push_endpoint: LokiPushEndpoint
    loki_user: LokiUser = Field(default=None)
    loki_token: LokiToken = Field(default=None)
    loki_logger_version: int = Field(default=1)

    def setup_logger(self, *, logger: logging.Logger | None = None, tags: dict | None = None) -> None:
        from logging_loki import LokiHandler  # type: ignore[import-untyped]

        auth = None
        if self.loki_user and self.loki_token:
            auth = (self.loki_user, self.loki_token.get_secret_value())

        handler = LokiHandler(
            url=self.loki_push_endpoint,
            auth=auth,
            tags=tags,
            version=f"{self.loki_logger_version}"
        )
        (logger or logging.getLogger("")).addHandler(handler)


class MimirConfiguration(BaseSettings):
    mimir_base_url: MimirBaseUrl
    mimir_token: MimirToken = Field(default=None)

    def push_metrics(self, registry: "CollectorRegistry", job: str):
        from prometheus_client import push_to_gateway  # type: ignore[import-untyped]

        push_to_gateway(self.mimir_base_url, job=job, registry=registry)


class SlackWebhook(BaseSettings):
    slack_webhook_url: SlackWebhookUrl

class TeamsWebhook(BaseSettings):
    teams_webhook_url: TeamsWebhookUrl

class DiscordWebhook(BaseSettings):
    discord_webhook_url: DiscordWebhookUrl

