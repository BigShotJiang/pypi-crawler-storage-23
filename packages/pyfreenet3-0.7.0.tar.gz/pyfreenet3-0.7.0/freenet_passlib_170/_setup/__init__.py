"""freenet_passlib_170.setup - helpers used by passlib's setup.py script"""
