# msd2

## Summary of number of types of unit ids in the MSD Dataset

"Valid" unit ids are those with unique plans which have only valid geometries and more than one area.

---

all_unit_ids 18903
valid_geoms 17797
sufficient_areas 18652
unique_plans 5372
num_valid_ids 5043

---
