﻿# AIOptimize - Reduce LLM API Costs by 90%

**Drop-in SDK that automatically tracks costs, recommends cheaper models, and optimizes AI workflows.**

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: Proprietary](https://img.shields.io/badge/License-Proprietary-red.svg)](LICENSE)

---

## 🚀 Quick Start

```bash
pip install llmoptimize
```

```python
import llmoptimize

# Your code works exactly the same
import openai
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)

# See your costs and savings
llmoptimize.report()
```

**Output:**
```
💰 COST REPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total Calls:     47
Total Cost:      $2.34
Potential Savings: $2.11 (90%)

💡 RECOMMENDATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Use gpt-3.5-turbo instead of gpt-4 for simple tasks
✓ Estimated savings: $1.85/day
```

---

## ✨ Features

### 🎯 **Magic Mode** (Default)
Zero code changes - just `import llmoptimize` and it works.

### 🤖 **AI-Powered Recommendations**
Smart analysis of each API call with confidence scores and reasoning.

### 📊 **Comprehensive Tracking**
- Real-time cost tracking
- Token usage analytics  
- Model performance insights
- Automatic report generation

### 🔍 **Code Auditing**
Analyze Python code BEFORE running to find optimization opportunities.

### 🎭 **Agent Optimization**
Track multi-step AI agent workflows with loop detection and context optimization.

---

## 🎁 Free Trial

**100 calls with full access to all features - no credit card required.**

After 100 calls, choose your plan:
- **Starter:** 200/month - Unlimited calls + dashboard

---

## 📦 Supported Providers

✅ **OpenAI** (GPT-4, GPT-4o, o1, o3, embeddings)
✅ **Anthropic** (Claude 3, Claude 3.5)
✅ **Google** (Gemini 1.5, 2.0)
✅ **Groq** (Llama, Mixtral, Gemma)
✅ **Mistral** (Large, Small, Nemo)
✅ **Cohere** (Command R+)

**72+ models tracked automatically.**

---

## 🔐 Privacy & Security

✅ **No prompt content sent** - Only categories
✅ **API keys stay local** - Never sent to our servers
✅ **Anonymized data only** - Random session IDs
✅ **GDPR compliant** - Full data export available

---

## 📝 License

Proprietary - See [LICENSE](LICENSE) file.

Free 100-call trial included. Paid license required for continued use.

---

## 🤝 Support

- 📧 Email: hakrudra@gmail.com
- 📚 Docs: [Full documentation](#)
- 🐛 Issues: [GitHub Issues](https://github.com/hackrudra1234/aioptimize/issues)

---

**Made with ❤️ by llmOptimize Team**