# Rcoder 功能文档

## 1. 系统概述

Rcoder 是一个强大的远程代码执行与管理系统，专为低带宽场景和中转服务器场景优化设计。系统支持异步通讯、批量执行、实时监控等功能，提供了友好的用户界面和完善的系统进程管理能力。

### 核心特性

- ✅ 低带宽场景优化（数据压缩、连接池）
- ✅ 中转服务器场景支持（异步通讯机制）
- ✅ 消息队列机制（确保命令顺序执行）
- ✅ 系统进程管理（守护进程、系统服务）
- ✅ 服务器别名管理（方便编程引用）
- ✅ 跨平台支持（Linux、Windows、Mac）

## 2. 功能详细说明

### 2.1 主菜单功能

```
=== Rcoder 主界面 ===
1. 对话式配置
2. 自动优化连接
3. 异步代理测试
4. 管理服务器和中转服务器
5. 系统进程管理
6. 退出
```

#### 1. 对话式配置
- 交互式配置系统参数
- 支持服务器连接设置
- 自动保存配置信息

#### 2. 自动优化连接
- 智能检测网络场景
- 自动应用优化策略
- 支持中转服务器配置

#### 3. 异步代理测试
- 测试四步异步通讯流程
- 支持批量命令执行
- 实时显示执行状态

#### 4. 管理服务器和中转服务器
- 添加服务器（目标服务器或中转服务器）
- 修改服务器配置
- 查看服务器列表
- 删除服务器

#### 5. 系统进程管理
- 启动守护进程（后台运行）
- 停止进程
- 删除系统进程（完全移除）
- 重启进程
- 查看进程状态
- 注册系统服务（开机自启）
- 注销系统服务

### 2.2 服务器管理功能

```
=== 服务器和中转服务器管理 ===
1. 添加服务器
2. 修改服务器配置
3. 查看服务器列表
4. 删除服务器
5. 返回主菜单
```

#### 1. 添加服务器
- 输入服务器别名（方便编程引用）
- 输入服务器地址和端口
- 设置服务器密码
- 指定服务器类型（目标服务器或中转服务器）

#### 2. 修改服务器配置
- 选择要修改的服务器别名
- 修改服务器地址、端口、密码等配置
- 支持修改服务器类型

#### 3. 查看服务器列表
- 显示所有已配置的服务器
- 展示详细配置信息
- 区分目标服务器和中转服务器

#### 4. 删除服务器
- 输入要删除的服务器别名
- 确认删除操作
- 自动清理服务器配置

### 2.3 系统进程管理功能

```
=== 系统进程管理 ===
1. 启动守护进程
2. 停止进程
3. 删除系统进程
4. 重启进程
5. 查看进程状态
6. 注册系统服务
7. 注销系统服务
8. 返回主菜单
```

#### 1. 启动守护进程
- 以后台模式启动Rcoder
- 自动创建PID文件和日志文件
- 支持后台监控和任务执行

#### 2. 停止进程
- 停止正在运行的Rcoder进程
- 清理进程资源
- 保留配置信息

#### 3. 删除系统进程
- 完全移除Rcoder进程
- 清理PID文件
- 释放系统资源

#### 4. 重启进程
- 先停止现有进程
- 启动新的进程实例
- 保持配置不变

#### 5. 查看进程状态
- 显示进程PID
- 展示内存和CPU使用情况
- 显示进程启动时间

#### 6. 注册系统服务
- 支持 Linux (systemd)、Windows、Mac (launchd)
- 实现开机自启
- 系统级进程管理

#### 7. 注销系统服务
- 停止系统服务
- 移除服务注册
- 清理相关文件

### 2.4 异步通讯机制

#### 四步通讯流程
1. **Trae → 中转服务器**：发送命令并等待
2. **中转服务器 → 目标服务器**：推送命令执行
3. **目标服务器 → 中转服务器**：执行完成后发送反馈
4. **中转服务器 → Trae**：将结果返回给Trae

#### 消息队列机制
- 确保命令按顺序执行
- 防止命令丢失
- 支持命令重试
- 批量命令并发执行

## 3. 使用方法

### 3.1 基本使用

```bash
# 启动Rcoder主界面
python rcoder.py

# 以守护进程模式运行
python rcoder.py --daemon

# 查看进程状态
python rcoder.py --status

# 停止进程
python rcoder.py --stop
```

### 3.2 服务器配置

1. 启动Rcoder主界面
2. 选择 "4. 管理服务器和中转服务器"
3. 选择 "1. 添加服务器"
4. 输入服务器别名、地址、端口、密码
5. 指定服务器类型（目标服务器或中转服务器）

### 3.3 系统服务注册

```bash
# 注册为系统服务（开机自启）
python rcoder.py --register-service

# 注销系统服务
python rcoder.py --unregister-service
```

### 3.4 编程引用

```python
from rcoder.core_optimized import get_remote_host

# 通过服务器别名连接
host_config = SERVER_ALIASES.get('proxy_server')
if host_config:
    remote = get_remote_host(
        host=host_config['host'],
        port=host_config['port'],
        password=host_config['password']
    )
    result = remote.run('ls -la')
    print(result)
```

## 4. 配置选项

### 4.1 核心配置参数

| 参数 | 描述 | 默认值 |
|------|------|--------|
| host | 服务器地址 | 192.168.1.8 |
| port | 服务器端口 | 443 |
| use_https_disguise | HTTPS伪装 | True |
| enable_compression | 数据压缩 | True |
| enable_connection_pool | 连接池 | True |
| connection_pool_size | 连接池大小 | 5 |
| password | 认证密码 | None |
| proxy_server | 中转服务器 | None |

### 4.2 网络优化参数

| 参数 | 描述 | 默认值 |
|------|------|--------|
| enable_minimal_payload | 最小化负载 | False |
| enable_exponential_backoff | 指数退避 | False |
| enable_breakpoint_resume | 断点续传 | False |

## 5. 依赖管理

### 5.1 必要依赖

```
# requirements.txt
psutil==5.9.8
python-daemon==3.0.1
```

### 5.2 安装依赖

```bash
pip install -r requirements.txt
```

## 6. 安全风险说明

### 6.1 潜在安全风险

1. **远程代码执行风险**
   - 系统允许执行远程命令，可能被恶意利用
   - 建议只在受信任的网络环境中使用
   - 确保服务器密码强度

2. **网络传输风险**
   - 虽然支持HTTPS伪装，但仍可能被网络监控
   - 建议在安全的网络环境中使用
   - 避免传输敏感信息

3. **系统服务风险**
   - 注册为系统服务后，进程具有较高权限
   - 确保系统服务配置正确
   - 定期检查服务状态

4. **密码存储风险**
   - 服务器密码以明文形式存储在内存中
   - 建议使用强密码
   - 避免在公共环境中使用

### 6.2 安全建议

- **使用强密码**：为所有服务器配置强密码
- **网络隔离**：在隔离网络环境中使用
- **定期更新**：保持系统和依赖包更新
- **权限控制**：限制Rcoder的运行权限
- **日志监控**：定期检查系统日志

## 7. 法律责任声明

### 7.1 使用责任

1. **用户责任**
   - 用户必须合法使用本软件，遵守相关法律法规
   - 不得用于任何违法活动
   - 对使用本软件产生的后果负全部责任

2. **免责声明**
   - 本软件仅供技术研究和合法用途
   - 作者不对任何滥用行为负责
   - 使用本软件即表示同意本声明

### 7.2 许可证

本软件采用 MIT 许可证开源，具体条款如下：

```
MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### 7.3 限制条款

- **不得用于违法目的**：包括但不限于未授权访问、数据窃取等
- **不得损害他人利益**：尊重他人知识产权和隐私
- **不得规避安全措施**：遵守网络安全法规
- **不得滥用系统资源**：合理使用服务器资源

## 8. 故障排除

### 8.1 常见问题

| 问题 | 可能原因 | 解决方案 |
|------|----------|----------|
| 连接失败 | 服务器未运行 | 启动服务器服务 |
| 认证失败 | 密码错误 | 检查服务器密码 |
| 进程启动失败 | 权限不足 | 使用管理员权限运行 |
| 系统服务注册失败 | 权限不足 | 使用sudo或管理员权限 |
| 命令执行超时 | 网络不稳定 | 检查网络连接或增加超时时间 |

### 8.2 日志查看

```bash
# 查看Rcoder日志
cat rcoder.log

# 查看系统服务日志（Linux）
systemctl status rcoder.service

# 查看Windows服务日志
eventvwr.msc
```

## 9. 版本信息

### 9.1 当前版本

- **版本号**：1.0.0
- **发布日期**：2026-02-22
- **开发团队**：Trae Team

### 9.2 更新日志

#### v1.0.0 (2026-02-22)
- ✅ 初始版本发布
- ✅ 低带宽场景优化
- ✅ 中转服务器场景支持
- ✅ 系统进程管理
- ✅ 服务器别名管理
- ✅ 异步通讯机制
- ✅ 消息队列机制

## 10. 联系方式

### 10.1 技术支持

- **GitHub**：https://github.com/trae-team/rcoder
- **Email**：support@trae.io
- **文档**：https://docs.trae.io/rcoder

### 10.2 贡献指南

欢迎贡献代码、报告问题或提出建议！请访问 GitHub 仓库了解详细的贡献流程。

---

**使用本软件即表示您已阅读并同意本文档中的安全风险说明和法律责任声明。**
