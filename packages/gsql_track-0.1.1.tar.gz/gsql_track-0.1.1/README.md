# gsql-track

Lightweight experiment tracking backed by SQLite. Zero dependencies beyond the Python standard library.

## Install

```bash
pip install gsql-track
```

## Quick Start

```python
from gsql_track import GsqlTrack

t = GsqlTrack("my-experiment")
run = t.start_run("baseline")
run.log_params({"lr": 0.001, "bs": 64})

for step in range(100):
    run.log(step=step, loss=loss, acc=acc)

run.finish()
t.close()
```

## Log Predictions (for mistake analysis)

```python
run.log_predictions([
    {"id": "e1", "pred": "A", "label": "A", "conf": 0.95, "text": "..."},
    {"id": "e2", "pred": "B", "label": "A", "conf": 0.60, "text": "..."},
])
```

## Web Dashboard

View results in the browser with the companion Go CLI:

```bash
gsql track serve
```

## Wrapper API

Wrap an existing tracker class to automatically log to gsql:

```python
from gsql_track import tracked
tracker = tracked(MyTracker(config), experiment="mnist")
```
