"""River Algorithm pipeline modules."""
