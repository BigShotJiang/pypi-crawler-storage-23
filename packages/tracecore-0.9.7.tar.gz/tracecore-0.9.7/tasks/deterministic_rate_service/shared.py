"""Shared keys for deterministic rate service task."""

SERVICE_KEY = "deterministic_rate_service_service"
README_PATH = "/app/DRS_README.md"
PAYLOAD_KEY = "deterministic_rate_service_payload"
HANDSHAKE_TEMPLATE_KEY = "deterministic_rate_service_handshake_template"
SECRET_KEY = "deterministic_rate_service_secret"
OUTPUT_KEY = "ACCESS_TOKEN"
