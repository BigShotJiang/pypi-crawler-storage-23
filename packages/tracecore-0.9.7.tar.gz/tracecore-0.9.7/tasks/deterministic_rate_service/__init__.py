"""Deterministic rate service task package."""
