﻿"""Hidden state container (stub)."""

class HiddenState(dict):
    pass
