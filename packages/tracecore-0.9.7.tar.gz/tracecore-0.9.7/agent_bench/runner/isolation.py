﻿"""Isolation hooks (stub)."""

def enforce_isolation():
    return None
