"""Minimal FastAPI UI wrapper for TraceCore."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, Form, HTTPException, Request, Response
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from pydantic import BaseModel, ConfigDict
from fastapi.templating import Jinja2Templates

from agent_bench.ledger import list_entries
from agent_bench.pairings import list_pairings
from agent_bench.runner.baseline import (
    build_baselines,
    diff_runs,
    load_latest_baseline,
    load_run_artifact,
)
from agent_bench.runner.failures import FAILURE_TYPES
from agent_bench.runner.runlog import list_runs, load_run, persist_run
from agent_bench.runner.runner import run
from agent_bench.tasks.registry import list_task_descriptors
import agent_bench.agents as _bundled_agents_pkg

TEMPLATES_DIR = Path(__file__).with_suffix("").with_name("templates")
TASKS_ROOT = Path("tasks")
AGENTS_ROOT = Path("agents")

templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
app = FastAPI(title="TraceCore UI", version="0.9.6")


class PairingSummary(BaseModel):
    name: str
    agent: str
    task: str
    description: str
    last_run_id: str | None = None
    last_success: bool | None = None
    last_seed: int | None = None


class LedgerTask(BaseModel):
    task_ref: str
    success_rate: float
    avg_steps: float | None = None
    avg_tool_calls: float | None = None
    run_count: int | None = None
    seed: int | None = None
    run_artifact: str | None = None
    bundle_sha256: str | None = None
    bundle_signature: str | None = None
    signed_at: str | None = None


class LedgerEntryPayload(BaseModel):
    agent: str
    description: str | None = None
    suite: str | None = None
    harness_version: str | None = None
    published_at: str | None = None
    maintainer: str | None = None
    bundle_sha256: str | None = None
    bundle_signature: str | None = None
    signed_at: str | None = None
    tasks: list[LedgerTask] = []


class TraceRunPayload(BaseModel):
    model_config = ConfigDict(extra="allow")

    run_id: str | None = None


class ErrorPayload(BaseModel):
    error: str

GUIDE_ENTRIES = [
    {
        "agent": "agents/toy_agent.py",
        "success": ["filesystem_hidden_config@1"],
        "notes": "Filesystem discovery reference; should succeed on the hidden config task.",
    },
    {
        "agent": "agents/naive_llm_agent.py",
        "success": ["filesystem_hidden_config@1"],
        "notes": "Minimal baseline; may fail if retries are exhausted.",
    },
    {
        "agent": "agents/rate_limit_agent.py",
        "success": ["rate_limited_api@1"],
        "notes": "Rate-limit retry flow reference; tuned for the API task.",
    },
    {
        "agent": "agents/chain_agent.py",
        "success": ["rate_limited_chain@1", "deterministic_rate_service@1"],
        "notes": "Handshake + rate-limit reference; should solve chained API tasks.",
    },
    {
        "agent": "agents/planner_agent.py",
        "success": ["rate_limited_chain@1"],
        "notes": "Planner-style scaffold; may fail depending on budgets or drift.",
    },
    {
        "agent": "agents/ops_triage_agent.py",
        "success": [
            "log_alert_triage@1",
            "config_drift_remediation@1",
            "incident_recovery_chain@1",
        ],
        "notes": "Operations triage reference; should succeed on ops suite tasks.",
    },
    {
        "agent": "agents/log_stream_monitor_agent.py",
        "success": ["log_stream_monitor@1"],
        "notes": "Log stream patrol reference; polls pages, ignores noise, fires on CRITICAL entry.",
    },
    {
        "agent": "agents/runbook_verifier_agent.py",
        "success": ["runbook_verifier@1"],
        "notes": "Runbook verification reference; stitches phase codes, ACK ID, and handoff token into a checksum.",
    },
    {
        "agent": "agents/sandboxed_code_auditor_agent.py",
        "success": ["sandboxed_code_auditor@1"],
        "notes": "Sandbox audit reference; extracts ISSUE_ID from source and AUDIT_CODE from log, emits combined token.",
    },
    {
        "agent": "agents/cheater_agent.py",
        "success": [],
        "notes": "Expected to fail with sandbox violation; use for defense checks.",
    },
]


def _parse_task_yaml(path: Path) -> dict[str, Any]:
    # Reuse loader-like parsing to avoid external YAML dependency.
    text = path.read_text(encoding="utf-8").splitlines()
    data: dict[str, Any] = {}
    i = 0
    while i < len(text):
        line = text[i].rstrip()
        i += 1
        if not line or line.lstrip().startswith("#"):
            continue
        if line.startswith("description:") and line.endswith("|"):
            desc_lines = []
            while i < len(text):
                raw = text[i]
                if not raw.startswith("  "):
                    break
                desc_lines.append(raw[2:])
                i += 1
            data["description"] = "\n".join(desc_lines).strip()
            continue
        if line.startswith("default_budget:"):
            budget = {}
            while i < len(text):
                raw = text[i]
                if not raw.startswith("  "):
                    break
                key, val = raw.strip().split(":", 1)
                budget[key.strip()] = int(val.strip())
                i += 1
            data["default_budget"] = budget
            continue
        if ":" in line:
            key, val = line.split(":", 1)
            key = key.strip()
            val = val.strip()
            if key == "version":
                data[key] = int(val)
            else:
                data[key] = val
    return data


def _parse_task_toml(path: Path) -> dict[str, Any]:
    try:
        import tomllib  # type: ignore[attr-defined]
    except ModuleNotFoundError:  # pragma: no cover
        import tomli as tomllib  # type: ignore[assignment]
    return tomllib.loads(path.read_text(encoding="utf-8"))


def get_task_options() -> list[dict[str, Any]]:
    options: list[dict[str, Any]] = []
    if TASKS_ROOT.exists():
        for task_dir in sorted(TASKS_ROOT.iterdir()):
            toml_path = task_dir / "task.toml"
            yaml_path = task_dir / "task.yaml"
            if toml_path.exists():
                meta = _parse_task_toml(toml_path)
            elif yaml_path.exists():
                meta = _parse_task_yaml(yaml_path)
            else:
                continue
            if meta.get("internal"):
                continue
            entry = {
                "id": meta.get("id", task_dir.name),
                "suite": meta.get("suite", ""),
                "version": meta.get("version", 1),
                "description": meta.get("description", ""),
            }
            entry["ref"] = f"{entry['id']}@{entry['version']}"
            options.append(entry)

    if not options:
        for descriptor in list_task_descriptors():
            options.append({
                "id": descriptor.id,
                "suite": descriptor.suite,
                "version": descriptor.version,
                "description": descriptor.description,
                "ref": f"{descriptor.id}@{descriptor.version}",
            })
    return options


def get_agent_options() -> list[str]:
    # First try local agents directory (like tasks logic)
    if AGENTS_ROOT.exists():
        paths = sorted(AGENTS_ROOT.glob("*.py"))
        if paths:
            return [f"agents/{p.name}" for p in paths]
    
    # Fallback to bundled agents (like tasks registry fallback)
    bundled_root = Path(_bundled_agents_pkg.__file__).parent
    return [f"agents/{p.name}" for p in sorted(bundled_root.glob("*.py")) if p.name != "__init__.py"]

def _build_budget_series(trace_run: dict | None) -> list[dict[str, int]]:
    if not trace_run:
        return []
    series: list[dict[str, int]] = []
    for entry in trace_run.get("action_trace") or []:
        observation = entry.get("observation") or {}
        remaining = observation.get("budget_remaining") or {}
        steps = remaining.get("steps")
        tools = remaining.get("tool_calls")
        if steps is None or tools is None:
            continue
        series.append({
            "step": entry.get("step", len(series) + 1),
            "steps": steps,
            "tool_calls": tools,
        })
    return series


def _normalize_io_entry(raw: Any) -> dict | None:
    if not isinstance(raw, dict):
        return None
    entry: dict[str, str] = {}
    for key in ("type", "op", "path", "host"):
        value = raw.get(key)
        if isinstance(value, str) and value.strip():
            entry[key] = value.strip()
    return entry or None


def _summarize_io_audit(trace_run: dict | None) -> dict | None:
    if not trace_run:
        return None
    action_trace = trace_run.get("action_trace") or []
    if not action_trace:
        return None
    total = filesystem = network = 0
    step_entries: list[dict[str, Any]] = []
    for entry in action_trace:
        if not isinstance(entry, dict):
            continue
        normalized: list[dict] = []
        for raw in entry.get("io_audit") or []:
            info = _normalize_io_entry(raw)
            if not info:
                continue
            normalized.append(info)
            total += 1
            audit_type = info.get("type")
            if audit_type == "fs":
                filesystem += 1
            elif audit_type == "net":
                network += 1
        if normalized:
            step_entries.append(
                {
                    "step": entry.get("step"),
                    "action": (entry.get("action") or {}).get("type"),
                    "io": normalized,
                }
            )
    if not step_entries:
        return None
    return {
        "total": total,
        "filesystem": filesystem,
        "network": network,
        "steps": step_entries,
    }


def _taxonomy_badge(trace_run: dict | None) -> dict[str, str] | None:
    if not trace_run:
        return None
    success = bool(trace_run.get("success"))
    failure_type = trace_run.get("failure_type")
    if success:
        return {"label": "Success", "kind": "success"}
    if failure_type:
        return {"label": failure_type, "kind": failure_type}
    return {"label": "unknown", "kind": "unknown"}


def _template_context(request: Request, **extra: Any) -> dict[str, Any]:
    tasks = get_task_options()
    agents = get_agent_options()
    recent_filters = extra.pop("recent_filters", None) or {}
    baseline_filters = extra.pop("baseline_filters", None) or {}
    recent_runs = list_runs(
        limit=8,
        agent=recent_filters.get("agent"),
        task_ref=recent_filters.get("task_ref"),
        failure_type=recent_filters.get("failure_type"),
    )
    baselines = build_baselines(
        max_runs=400,
        agent=baseline_filters.get("agent"),
        task_ref=baseline_filters.get("task_ref"),
    )
    published_baseline = load_latest_baseline()
    selected_task_ref = extra.get("selected_task")
    if selected_task_ref is None and tasks:
        selected_task_ref = tasks[0]["ref"]
    selected_task_meta = next((t for t in tasks if t["ref"] == selected_task_ref), None)
    extra = dict(extra)
    extra.pop("selected_task", None)
    compare_inputs = extra.pop("compare_inputs", None) or {"run_a": "", "run_b": ""}
    pairing_cards = []
    for p in list_pairings():
        last = list_runs(agent=p.agent, task_ref=p.task, limit=1)
        last_run = last[0] if last else None
        pairing_cards.append({
            "name": p.name,
            "agent": p.agent,
            "task": p.task,
            "description": p.description,
            "last_run_id": last_run["run_id"] if last_run else None,
            "last_success": (last_run.get("failure_type") is None) if last_run else None,
            "last_seed": last_run.get("seed") if last_run else None,
        })
    compare_diff = extra.get("compare_diff")
    compare_delta = None
    compare_step_summary: list[dict[str, Any]] = []
    if compare_diff:
        summary = compare_diff.get("summary", {})
        steps = summary.get("steps", {})
        tools = summary.get("tool_calls", {})
        compare_delta = {
            "steps_a": steps.get("run_a"),
            "steps_b": steps.get("run_b"),
            "tools_a": tools.get("run_a"),
            "tools_b": tools.get("run_b"),
            "steps_delta": (steps.get("run_b") or 0) - (steps.get("run_a") or 0),
            "tools_delta": (tools.get("run_b") or 0) - (tools.get("run_a") or 0),
        }
        for entry in (compare_diff.get("step_diffs") or [])[:10]:
            run_a = entry.get("run_a") or {}
            run_b = entry.get("run_b") or {}
            action_a = (run_a.get("action") or {}).get("type")
            action_b = (run_b.get("action") or {}).get("type")
            result_a = run_a.get("result")
            result_b = run_b.get("result")
            compare_step_summary.append({
                "step": entry.get("step"),
                "action_a": action_a,
                "action_b": action_b,
                "result_changed": (result_a != result_b),
            })

    trace_run = extra.get("trace_run")
    trace_budget_series = _build_budget_series(trace_run)
    trace_taxonomy = _taxonomy_badge(trace_run)
    trace_io_summary = _summarize_io_audit(trace_run)

    base = {
        "request": request,
        "tasks": tasks,
        "agents": agents,
        "pairings": pairing_cards,
        "selected_task": selected_task_ref,
        "selected_task_meta": selected_task_meta,
        "recent_runs": recent_runs,
        "baselines": baselines,
        "published_baseline": published_baseline,
        "compare_diff": compare_diff,
        "compare_delta": compare_delta,
        "compare_step_summary": compare_step_summary,
        "compare_error": extra.get("compare_error"),
        "compare_inputs": compare_inputs,
        "recent_filters": recent_filters,
        "baseline_filters": baseline_filters,
        "failure_types": FAILURE_TYPES,
        "trace_budget_series": trace_budget_series,
        "trace_taxonomy": trace_taxonomy,
        "trace_io_summary": trace_io_summary,
    }
    base.update(extra)
    return base


def _load_trace(run_id: str | None) -> tuple[dict | None, str | None]:
    if not run_id:
        return None, None
    try:
        return load_run(run_id), None
    except FileNotFoundError:
        return None, f"Trace {run_id} not found."
    except Exception as exc:
        return None, f"Failed to load trace: {exc}"


def _strip_io_audit(trace_run: dict | None) -> dict | None:
    if not trace_run:
        return trace_run
    clone = dict(trace_run)
    trace = []
    for entry in clone.get("action_trace") or []:
        if not isinstance(entry, dict):
            continue
        trimmed = {k: v for k, v in entry.items() if k != "io_audit"}
        trace.append(trimmed)
    clone["action_trace"] = trace
    return clone


@app.get("/api/pairings", response_model=list[PairingSummary])
async def api_pairings() -> list[PairingSummary]:
    result: list[PairingSummary] = []
    for p in list_pairings():
        last = list_runs(agent=p.agent, task_ref=p.task, limit=1)
        last_run = last[0] if last else None
        result.append(
            PairingSummary(
                name=p.name,
                agent=p.agent,
                task=p.task,
                description=p.description,
                last_run_id=last_run["run_id"] if last_run else None,
                last_success=(last_run.get("failure_type") is None) if last_run else None,
                last_seed=last_run.get("seed") if last_run else None,
            )
        )
    return result


@app.get("/", response_class=HTMLResponse)
async def index(request: Request) -> HTMLResponse:
    trace_id = request.query_params.get("trace_id")
    recent_filters = {
        "agent": request.query_params.get("recent_agent") or None,
        "task_ref": request.query_params.get("recent_task") or None,
        "failure_type": request.query_params.get("recent_failure") or None,
    }
    baseline_filters = {
        "agent": request.query_params.get("baseline_agent") or None,
        "task_ref": request.query_params.get("baseline_task") or None,
    }
    baseline_submitted = any(param in request.query_params for param in ("baseline_agent", "baseline_task"))
    trace_run, trace_error = _load_trace(trace_id)
    return templates.TemplateResponse(
        "index.html",
        _template_context(
            request,
            trace_run=trace_run,
            trace_error=trace_error,
            trace_id=trace_id,
            recent_filters=recent_filters,
            baseline_filters=baseline_filters,
            baseline_submitted=baseline_submitted,
        ),
    )


@app.get("/run", response_class=HTMLResponse)
async def run_task_redirect() -> RedirectResponse:
    """Browsers sometimes prefetch GET /run; send them back to the dashboard."""
    return RedirectResponse(url="/", status_code=307)


@app.post("/run", response_class=HTMLResponse)
async def run_task(
    request: Request,
    agent: str = Form(""),
    task: str = Form(""),
    seed: int | None = Form(None),
    replay: str | None = Form(None),
) -> HTMLResponse:
    result: dict[str, Any] | None = None
    error: str | None = None
    trace_run: dict[str, Any] | None = None

    try:
        if replay:
            artifact = load_run(replay)
            recorded_agent = artifact.get("agent")
            recorded_task = artifact.get("task_ref")
            recorded_seed = artifact.get("seed", 0)

            agent = agent or recorded_agent or ""
            task = task or recorded_task or ""
            seed = recorded_seed if seed is None else seed

            if not agent or not task:
                raise ValueError("Replay requires artifact with agent/task or explicit overrides")
        else:
            if not agent or not task:
                raise ValueError("Agent and task are required (or provide a replay run_id)")
            seed = 0 if seed is None else seed

        result = run(agent, task, seed=seed)
        try:
            persist_run(result)
        except Exception as exc:  # pragma: no cover - best-effort logging
            error = f"run succeeded but failed to persist artifact: {exc}"
        trace_run = result
    except Exception as exc:  # pragma: no cover - defensive for UI feedback
        error = str(exc)

    return templates.TemplateResponse(
        "index.html",
        _template_context(
            request,
            selected_agent=agent,
            selected_task=task,
            selected_seed=seed if seed is not None else 0,
            result=result,
            error=error,
            trace_run=trace_run,
            trace_id=trace_run.get("run_id") if trace_run else None,
            result_download_id=trace_run.get("run_id") if trace_run else None,
        ),
    )


@app.get("/traces/{run_id}", response_class=HTMLResponse)
async def view_trace(request: Request, run_id: str) -> HTMLResponse:
    trace_run, trace_error = _load_trace(run_id)
    return templates.TemplateResponse(
        "index.html",
        _template_context(
            request,
            trace_run=trace_run,
            trace_error=trace_error,
            trace_id=run_id,
        ),
    )


@app.get(
    "/api/traces/{run_id}",
    response_model=TraceRunPayload | ErrorPayload,
)
async def trace_api(run_id: str, response: Response, include_io: bool = False) -> TraceRunPayload | ErrorPayload:
    trace_run, trace_error = _load_trace(run_id)
    if trace_run:
        payload = trace_run if include_io else _strip_io_audit(trace_run)
        return TraceRunPayload.model_validate(payload)
    status_code = 404 if "not found" in (trace_error or "").lower() else 500
    response.status_code = status_code
    return ErrorPayload(error=trace_error or "unknown_error")


@app.get("/api/runs/diff")
async def api_runs_diff(a: str, b: str, response: Response) -> dict | ErrorPayload:
    """Return a structured IO-audit diff between two run artifacts.

    Query params: ``a`` and ``b`` are run_ids or paths.
    """
    try:
        artifact_a = load_run_artifact(a)
        artifact_b = load_run_artifact(b)
        return diff_runs(artifact_a, artifact_b)
    except FileNotFoundError as exc:
        response.status_code = 404
        return ErrorPayload(error=str(exc))
    except Exception as exc:
        response.status_code = 500
        return ErrorPayload(error=str(exc))


@app.get("/api/runs/{run_id}/io-audit")
async def api_run_io_audit(run_id: str, response: Response) -> dict | ErrorPayload:
    """Return per-step IO audit entries for a single run.

    Response shape::

        {
          "run_id": "...",
          "task_ref": "...",
          "steps": [
            {
              "step": 1,
              "action": "read_file",
              "io_audit": [{"type": "fs", "op": "read", "path": "..."}, ...]
            },
            ...
          ],
          "summary": {"total": N, "filesystem": N, "network": N}
        }
    """
    run = load_run(run_id)
    if not run:
        response.status_code = 404
        return ErrorPayload(error=f"Run {run_id!r} not found")

    steps = []
    total = fs_count = net_count = 0
    for entry in run.get("action_trace") or []:
        io = entry.get("io_audit") or []
        action_type = (entry.get("action") or {}).get("type", "")
        steps.append({
            "step": entry.get("step"),
            "action": action_type,
            "io_audit": io,
        })
        for item in io:
            total += 1
            if item.get("type") == "fs":
                fs_count += 1
            elif item.get("type") == "net":
                net_count += 1

    return {
        "run_id": run.get("run_id"),
        "task_ref": run.get("task_ref"),
        "steps": steps,
        "summary": {"total": total, "filesystem": fs_count, "network": net_count},
    }


@app.get("/baselines/latest")
async def download_latest_baseline() -> FileResponse:
    payload = load_latest_baseline()
    if not payload:
        raise HTTPException(status_code=404, detail="No baseline export found")
    path = Path(payload["_path"])
    if not path.exists():
        raise HTTPException(status_code=404, detail="Baseline file missing")
    return FileResponse(path, media_type="application/json", filename=payload.get("_filename", path.name))


@app.get("/api/ledger", response_model=list[LedgerEntryPayload])
async def api_ledger() -> list[LedgerEntryPayload]:
    return [LedgerEntryPayload.model_validate(entry) for entry in list_entries()]


@app.get("/ledger", response_class=HTMLResponse)
async def ledger(request: Request) -> HTMLResponse:
    entries = list_entries()
    return templates.TemplateResponse(
        "ledger.html",
        {
            "request": request,
            "entries": entries,
        },
    )


@app.get("/guide", response_class=HTMLResponse)
async def guide(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        "guide.html",
        {
            "request": request,
            "guide_entries": GUIDE_ENTRIES,
        },
    )


@app.post("/compare", response_class=HTMLResponse)
async def compare_runs(request: Request, run_a: str = Form(""), run_b: str = Form("")) -> HTMLResponse:
    compare_error: str | None = None
    diff: dict | None = None
    try:
        if not run_a or not run_b:
            raise ValueError("Both run references are required")
        artifact_a = load_run_artifact(run_a)
        artifact_b = load_run_artifact(run_b)
        diff = diff_runs(artifact_a, artifact_b)
    except FileNotFoundError:
        compare_error = "One of the provided run references could not be found."
    except Exception as exc:  # pragma: no cover - defensive feedback
        compare_error = str(exc)

    return templates.TemplateResponse(
        "index.html",
        _template_context(
            request,
            compare_diff=diff,
            compare_error=compare_error,
            compare_inputs={"run_a": run_a, "run_b": run_b},
            selected_task=request.query_params.get("task"),
        ),
    )
