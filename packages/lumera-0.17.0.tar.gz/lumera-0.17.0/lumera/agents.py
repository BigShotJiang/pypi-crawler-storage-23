"""
Agent invocation and management for Lumera.

This module provides a high-level interface for invoking and managing Lumera
agents (AI-powered assistants with tools and skills).

Invocation:
    invoke()  - Invoke an agent synchronously, returns structured response

Agent management:
    list()    - List all agents
    get()     - Get agent by ID

Example:
    >>> from lumera import agents
    >>>
    >>> # Invoke an agent
    >>> result = agents.invoke("agent_id", "Categorize this invoice")
    >>> print(result.output)
    >>>
    >>> # List available agents
    >>> for agent in agents.list():
    ...     print(agent.name)
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "invoke",
    "list",
    "get",
    "InvokeResult",
    "Agent",
]

from ._utils import _api_request


# ============================================================================
# InvokeResult Class
# ============================================================================


class InvokeResult:
    """Result from invoking an agent.

    Attributes:
        output: The agent's text response.
        tool_calls: List of tool calls made during the invocation.
        usage: Token usage statistics (input, output, cache, cost).
        session_id: The session ID used for the invocation.
        success: Whether the invocation completed successfully.
        error: Error message if the invocation failed.
    """

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def output(self) -> str:
        """The agent's text response."""
        return self._data.get("output", "")

    @property
    def tool_calls(self) -> list[dict[str, Any]]:
        """Tool calls made during the invocation."""
        return self._data.get("tool_calls", [])

    @property
    def usage(self) -> dict[str, Any] | None:
        """Token usage statistics."""
        return self._data.get("usage")

    @property
    def session_id(self) -> str:
        """The session ID used for this invocation."""
        return self._data.get("session_id", "")

    @property
    def success(self) -> bool:
        """Whether the invocation completed successfully."""
        return self._data.get("success", False)

    @property
    def error(self) -> str | None:
        """Error message if the invocation failed."""
        return self._data.get("error")

    def __repr__(self) -> str:
        status = "ok" if self.success else f"error: {self.error}"
        preview = self.output[:60] + "..." if len(self.output) > 60 else self.output
        return f"InvokeResult({status}, output={preview!r})"


# ============================================================================
# Agent Class
# ============================================================================


class Agent:
    """An agent record.

    Attributes:
        id: The agent's unique identifier.
        name: The agent's display name.
        description: A short description of the agent's purpose.
    """

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def id(self) -> str:
        return self._data["id"]

    @property
    def name(self) -> str:
        return self._data.get("name", "")

    @property
    def description(self) -> str:
        return self._data.get("description", "")

    @property
    def managed(self) -> bool:
        return self._data.get("managed", False)

    def invoke(
        self,
        message: str,
        *,
        session_id: str | None = None,
        timeout: int = 300,
    ) -> InvokeResult:
        """Invoke this agent with a message.

        Args:
            message: The user message to send.
            session_id: Optional session ID for conversation continuity.
            timeout: Request timeout in seconds (default 300).

        Returns:
            InvokeResult with the agent's response.
        """
        return invoke(self.id, message, session_id=session_id, timeout=timeout)

    def __repr__(self) -> str:
        return f"Agent(id={self.id!r}, name={self.name!r})"


# ============================================================================
# Module-level functions
# ============================================================================


def invoke(
    agent_id: str,
    message: str,
    *,
    session_id: str | None = None,
    timeout: int = 300,
) -> InvokeResult:
    """Invoke an agent synchronously and return structured result.

    Blocks until the agent completes its turn. The agent may use tools
    (lumera_api, bash, read, etc.) during processing.

    Args:
        agent_id: The agent to invoke.
        message: The user message to send.
        session_id: Optional session ID for conversation continuity.
            If omitted, uses the "default" session.
        timeout: Request timeout in seconds (default 300).

    Returns:
        InvokeResult with output, tool_calls, usage, and success status.

    Example:
        >>> result = agents.invoke("agent_xyz", "Summarize last month's expenses")
        >>> print(result.output)
        >>> print(f"Used {result.usage['totalTokens']} tokens")
    """
    payload: dict[str, Any] = {"message": message}
    if session_id:
        payload["session_id"] = session_id
    result = _api_request(
        "POST",
        f"agents/{agent_id}/invoke",
        json_body=payload,
        timeout=timeout,
    )
    return InvokeResult(result)


def list(*, limit: int = 50, offset: int = 0) -> list[Agent]:
    """List all agents.

    Args:
        limit: Maximum number of agents to return (default 50).
        offset: Number of agents to skip (default 0).

    Returns:
        List of Agent objects.
    """
    result = _api_request("GET", "agents", params={"limit": limit, "offset": offset})
    agents_data = result.get("agents", []) if isinstance(result, dict) else result
    return [Agent(a) for a in agents_data]


def get(agent_id: str) -> Agent:
    """Get an agent by ID.

    Args:
        agent_id: The agent's unique identifier.

    Returns:
        Agent object.
    """
    result = _api_request("GET", f"agents/{agent_id}")
    return Agent(result)
