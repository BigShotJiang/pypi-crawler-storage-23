"""
Lumera Agent SDK

This SDK provides helpers for automations running within the Lumera environment
to interact with the Lumera API and define dynamic user interfaces.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("lumera")
except PackageNotFoundError:
    __version__ = "unknown"  # Not installed (e.g., running from source)

# Import new modules (as modules, not individual functions)
from . import agents, automations, email, exceptions, integrations, llm, locks, pb, storage, webhooks
from ._utils import (
    Credentials,
    LumeraAPIError,
    RecordNotUniqueError,
    get_access_token,
    get_credentials,
    get_google_access_token,
    log_timed,
)

# Import specific exceptions for convenience
from .exceptions import (
    LockHeldError,
    LumeraError,
    RecordNotFoundError,
    UniqueConstraintError,
    ValidationError,
)

# Import file types for Pydantic automation inputs
from .files import LumeraFile, LumeraFiles

# Import key SDK helpers to expose them at the package root.
from .sdk import (
    CollectionField,
    HookReplayResult,
    create_collection,
    create_record,
    delete_collection,
    delete_record,
    get_automation_run,
    get_collection,
    get_record,
    get_record_by_external_id,
    list_collections,
    list_records,
    query_sql,
    replay_hook,
    run_automation,
    save_to_lumera,
    update_automation_run,
    update_collection,
    update_record,
    upload_lumera_file,
    upsert_record,
)

# Define what `from lumera import *` imports.
__all__ = [
    # Authentication & utilities
    "Credentials",
    "get_access_token",
    "get_credentials",
    "get_google_access_token",  # Kept for backwards compatibility
    "log_timed",
    # Collections (low-level API)
    "list_collections",
    "get_collection",
    "create_collection",
    "update_collection",
    "delete_collection",
    # Records (low-level API)
    "list_records",
    "get_record",
    "get_record_by_external_id",
    "create_record",
    "update_record",
    "upsert_record",
    "delete_record",
    # Other operations
    "replay_hook",
    "query_sql",
    "run_automation",
    "get_automation_run",
    "update_automation_run",
    "upload_lumera_file",
    "save_to_lumera",
    # Type definitions
    "CollectionField",
    "HookReplayResult",
    "LumeraFile",
    "LumeraFiles",
    # Exceptions
    "LumeraAPIError",
    "RecordNotUniqueError",
    "LumeraError",
    "ValidationError",
    "UniqueConstraintError",
    "RecordNotFoundError",
    "LockHeldError",
    # New modules (use as lumera.pb, lumera.storage, etc.)
    "agents",
    "automations",
    "email",
    "pb",
    "storage",
    "llm",
    "locks",
    "exceptions",
    "webhooks",
    "integrations",
]
