from .main import DisjointSet, InvalidInitialMappingError

name = "disjoint_set"
__all__ = ["DisjointSet", "InvalidInitialMappingError"]
__version__ = "0.9.0"
