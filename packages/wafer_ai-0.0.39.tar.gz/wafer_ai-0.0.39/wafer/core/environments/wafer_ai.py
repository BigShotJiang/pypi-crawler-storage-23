"""Wafer AI environment with minimal toolset for code editing tasks.
Tools: read, write, edit, glob, grep, bash, sandbox, skill, eval_task, subagent
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

import trio

from wafer.core.rollouts.dtypes import (
    AgentState,
    Message,
    RunConfig,
    Tool,
    ToolCall,
    ToolResult,
)
from wafer.cli.agent_config import SubagentConfig
from wafer.core.tools import (
    BASH_TOOL,
    EDIT_TOOL,
    EVAL_TOOL,
    GLOB_TOOL,
    GREP_TOOL,
    READ_TOOL,
    SANDBOX_TOOL,
    SKILL_TOOL,
    SUBAGENT_TOOL,
    WRITE_TOOL,
    ApprovalCallback,
    exec_bash,
    exec_edit,
    exec_eval,
    exec_glob,
    exec_grep,
    exec_read,
    exec_sandbox,
    exec_skill,
    exec_subagent,
    exec_write,
)


def _shorten_path(path: str) -> str:
    """Convert absolute path to tilde notation if in home directory."""
    home = os.path.expanduser("~")
    if path.startswith(home):
        return "~" + path[len(home) :]
    return path


# Tool definitions are imported from wafer.core.tools
ALL_TOOLS = {
    "read": READ_TOOL,
    "write": WRITE_TOOL,
    "edit": EDIT_TOOL,
    "glob": GLOB_TOOL,
    "grep": GREP_TOOL,
    "bash": BASH_TOOL,
    "skill": SKILL_TOOL,
    "eval_task": EVAL_TOOL,
    "sandbox": SANDBOX_TOOL,
    "subagent": SUBAGENT_TOOL,
}


@dataclass
class CodingEnvironment:
    """Local filesystem environment with read, write, edit, glob, grep, bash tools.
    Args:
        working_dir: Working directory for file operations and commands.
        enabled_tools: List of tool names to enable. If None, all tools enabled.
            Valid tools: read, write, edit, glob, grep, bash.
        bash_allowlist: List of allowed bash command prefixes. Commands matching
            these prefixes execute without prompting.
        bash_denylist: List of denied bash command prefixes. Commands matching
            these prefixes are always blocked.
        bash_approval_callback: Optional callback for "ask" tier approval.
            If None, commands not in allowlist are denied (headless mode).
    """
    working_dir: Path = field(default_factory=Path.cwd)
    enabled_tools: list[str] | None = None
    bash_allowlist: list[str] | None = None
    bash_denylist: list[str] | None = None
    bash_approval_callback: ApprovalCallback | None = None
    bash_default_timeout: int = 180
    ssh_target: str | None = None
    ssh_key: str | None = None
    target_name: str | None = None
    gpu_type: str | None = None
    subagent_configs: dict[str, SubagentConfig] = field(default_factory=dict)
    confirm_tools: list[str] | None = None
    _sandbox_session: "SandboxSession | None" = field(default=None, repr=False)
    _sandbox_sessions: dict[str, "SandboxSession"] = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        """Validate enabled_tools."""
        if self.enabled_tools is not None:
            valid_tools = set(ALL_TOOLS.keys())
            unknown = set(self.enabled_tools) - valid_tools
            if unknown:
                raise ValueError(
                    f"Unknown tools: {sorted(unknown)}. Available: {sorted(valid_tools)}"
                )

    def get_name(self) -> str:
        """Return environment name identifier."""
        return "coding"

    def get_status_info(self) -> dict[str, str] | None:
        info: dict[str, str] = {}
        if self.target_name:
            info["target"] = self.target_name
        if self.gpu_type:
            info["accelerator"] = self.gpu_type
        return info or None

    async def serialize(self) -> dict:
        return {
            "working_dir": str(self.working_dir),
            "enabled_tools": self.enabled_tools,
            "bash_allowlist": self.bash_allowlist,
            "bash_denylist": self.bash_denylist,
            "ssh_target": self.ssh_target,
            "ssh_key": self.ssh_key,
            "target_name": self.target_name,
            "gpu_type": self.gpu_type,
        }

    @staticmethod
    async def deserialize(data: dict) -> CodingEnvironment:
        return CodingEnvironment(
            working_dir=Path(data["working_dir"]),
            enabled_tools=data.get("enabled_tools"),
            bash_allowlist=data.get("bash_allowlist"),
            bash_denylist=data.get("bash_denylist"),
            ssh_target=data.get("ssh_target"),
            ssh_key=data.get("ssh_key"),
            target_name=data.get("target_name"),
            gpu_type=data.get("gpu_type"),
        )

    def copy_runtime_from(self, other: WaferAiEnvironment) -> None:
        """Preserve sandbox SSH sessions across serialize/deserialize cycles."""
        self._sandbox_session = other._sandbox_session
        self._sandbox_sessions = other._sandbox_sessions

    async def close(self) -> None:
        """Close all sandbox sessions. Marks each destroyed in DB."""
        from wafer.cli.sandboxes_api import db_destroy_sandbox
        for session in self._sandbox_sessions.values():
            sandbox_id = session._sandbox.id
            await session.close()
            db_destroy_sandbox(sandbox_id)
        self._sandbox_sessions.clear()
        if self._sandbox_session is not None:
            if self._sandbox_session._sandbox.id not in {
                s._sandbox.id for s in self._sandbox_sessions.values()
            }:
                sandbox_id = self._sandbox_session._sandbox.id
                await self._sandbox_session.close()
                db_destroy_sandbox(sandbox_id)
            self._sandbox_session = None

    def _resolve_target_credentials(
        self, target_name: str | None,
    ) -> tuple[str, str, str]:
        """Resolve SSH credentials for a target name.
        Returns (target_name, ssh_target, ssh_key).
        Uses the named target if given, otherwise falls back to the environment default.
        """
        if target_name and target_name != self.target_name:
            from wafer.cli.targets import load_target
            target = load_target(target_name)
            assert hasattr(target, "ssh_target"), f"Target '{target_name}' has no SSH config"
            return target.name, target.ssh_target, target.ssh_key
        assert self.ssh_target is not None, "sandbox requires ssh_target"
        assert self.ssh_key is not None, "sandbox requires ssh_key"
        return self.target_name or "default", self.ssh_target, self.ssh_key

    async def _get_or_create_session(
        self, resolved_name: str, ssh_target: str, ssh_key: str,
    ) -> "SandboxSession":
        """Get existing session for target or create a new one."""
        if resolved_name in self._sandbox_sessions:
            return self._sandbox_sessions[resolved_name]
        if (
            self._sandbox_session is not None
            and self._sandbox_session._sandbox.target_name == resolved_name
        ):
            self._sandbox_sessions[resolved_name] = self._sandbox_session
            return self._sandbox_session
        from wafer.core.sandbox import SandboxSession, create_sandbox
        sandbox = create_sandbox(
            target_name=resolved_name,
            ssh_target=ssh_target,
            ssh_key=ssh_key,
        )
        session = SandboxSession(sandbox)
        await session.start()
        from wafer.cli.sandboxes_api import db_register_sandbox
        db_register_sandbox(
            sandbox_id=sandbox.id,
            target_name=sandbox.target_name,
            tmux_session=sandbox.tmux_session,
            timeout_hours=sandbox.timeout_hours,
            created_at=sandbox.created_at,
        )
        self._sandbox_sessions[resolved_name] = session
        if self._sandbox_session is None:
            self._sandbox_session = session
        return session

    async def _exec_sandbox(
        self,
        tool_call: ToolCall,
        on_output: object = None,
    ) -> ToolResult:
        """Execute sandbox tool. Supports per-target sessions via the 'target' arg."""
        requested_target = tool_call.args.get("target")
        try:
            resolved_name, ssh_target, ssh_key = self._resolve_target_credentials(requested_target)
        except (AssertionError, FileNotFoundError, Exception) as e:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=str(e),
            )
        session = await self._get_or_create_session(resolved_name, ssh_target, ssh_key)
        result = await exec_sandbox(tool_call, session, on_output=on_output)
        from wafer.cli.sandboxes_api import db_touch_sandbox
        db_touch_sandbox(session._sandbox.id, session._sandbox.timeout_hours)
        return result

    def requires_confirmation(self, tool_call: ToolCall) -> bool:
        if self.confirm_tools is not None:
            return tool_call.name in self.confirm_tools
        return tool_call.name == "bash"

    def get_tools(self) -> list[Tool]:
        """Return enabled tools."""
        if self.enabled_tools is None:
            return list(ALL_TOOLS.values())
        return [ALL_TOOLS[name] for name in self.enabled_tools if name in ALL_TOOLS]

    async def on_assistant_message(self, message: Message, state: AgentState) -> AgentState:
        """No feedback needed for coding environment."""
        return state

    async def exec_tool(
        self,
        tool_call: ToolCall,
        current_state: AgentState,
        run_config: RunConfig,
        cancel_scope: trio.CancelScope | None = None,
    ) -> ToolResult:
        """Execute tool call."""
        if self.enabled_tools is not None and tool_call.name not in self.enabled_tools:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Tool '{tool_call.name}' is not enabled. Enabled tools: {', '.join(self.enabled_tools)}",
            )
        # Dispatch to pure function handlers
        # All file tools receive working_dir for relative path resolution
        handlers = {
            "read": lambda tc: exec_read(tc, self.working_dir),
            "write": lambda tc: exec_write(tc, self.working_dir),
            "edit": lambda tc: exec_edit(tc, self.working_dir),
            "glob": lambda tc: exec_glob(tc, self.working_dir),
            "grep": lambda tc: exec_grep(tc, self.working_dir),
            "bash": lambda tc: exec_bash(
                tc,
                self.working_dir,
                cancel_scope,
                self.bash_allowlist,
                self.bash_denylist,
                self.bash_approval_callback,
                None,
                self.bash_default_timeout,
            ),
            "skill": lambda tc: exec_skill(tc),
            "eval_task": lambda tc: exec_eval(tc, self.working_dir),
            "sandbox": lambda tc: self._exec_sandbox(tc, on_output=run_config.on_chunk),
            "subagent": lambda tc: exec_subagent(
                tc, self.working_dir, self.subagent_configs,
                on_output=lambda delta: run_config.on_chunk(delta),
                api_url=os.environ.get("WAFER_API_URL"),
                auth_token=os.environ.get("WAFER_AUTH_TOKEN"),
            ),
        }
        handler = handlers.get(tool_call.name)
        if handler is None:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Unknown tool: {tool_call.name}",
            )
        try:
            return await handler(tool_call)
        except Exception as e:
            return ToolResult(tool_call_id=tool_call.id, is_error=True, content="", error=str(e))


WaferAiEnvironment = CodingEnvironment
