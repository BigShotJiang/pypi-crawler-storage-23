"""Shared client for streaming SSE from wafer API endpoints.

Provides:
    parse_sse_line()   — pure SSE line parser (sync, usable anywhere)
    stream_wafer_api() — async generator for POST + SSE streaming
"""
from __future__ import annotations

import json
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any


class WaferApiError(Exception):
    """Raised when the wafer API returns a non-200 response."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"Wafer API error {status_code}: {detail}")


@dataclass(frozen=True)
class SSEEvent:
    """A parsed SSE event from a wafer API stream."""
    event_type: str
    data: dict[str, Any]


_DONE_SENTINEL = SSEEvent(event_type="done", data={})


def parse_sse_line(line: str) -> SSEEvent | None:
    """Parse a single SSE line into an SSEEvent.

    Returns None for non-data lines (comments, empty lines, etc.).
    Returns _DONE_SENTINEL for [DONE] marker.
    """
    line = line.strip()
    if not line or not line.startswith("data: "):
        return None

    payload = line[len("data: "):]
    if payload == "[DONE]":
        return _DONE_SENTINEL

    parsed = json.loads(payload)
    event_type = parsed.get("type", "unknown")
    return SSEEvent(event_type=event_type, data=parsed)


async def stream_wafer_api(
    *,
    api_url: str,
    auth_token: str,
    endpoint: str,
    body: dict[str, Any],
) -> AsyncIterator[SSEEvent]:
    """POST to a wafer API endpoint and yield SSE events.

    Args:
        api_url: Base API URL (e.g. "https://www.api.wafer.ai")
        auth_token: Bearer token for authentication
        endpoint: API path (e.g. "/v1/cloud-agent/run")
        body: JSON request body
    """
    import httpx

    url = f"{api_url.rstrip('/')}{endpoint}"
    headers = {
        "Authorization": f"Bearer {auth_token}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=httpx.Timeout(600.0, connect=30.0)) as client:
        async with client.stream("POST", url, json=body, headers=headers) as response:
            if response.status_code != 200:
                raw = await response.aread()
                raise WaferApiError(response.status_code, raw.decode(errors="replace")[:500])

            async for line in response.aiter_lines():
                event = parse_sse_line(line)
                if event is None:
                    continue
                if event is _DONE_SENTINEL:
                    return
                yield event
