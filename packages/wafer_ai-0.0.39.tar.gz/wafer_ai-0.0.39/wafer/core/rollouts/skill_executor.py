"""Skill executor — resolves /skill-name into an invocation and executes it."""
from __future__ import annotations

import re
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wafer.cli.agent_config import SubagentConfig

    from .skills import Skill


@dataclass(frozen=True)
class SkillInvocation:
    """Result of resolving a / command."""
    skill: Skill
    substituted_content: str
    context: str  # "inline" or "fork"
    allowed_tools: list[str] | None


def substitute_args(content: str, args: list[str]) -> str:
    """Replace $ARGUMENTS (all args joined), $ARGUMENTS[N], $N shorthand."""
    result = content.replace("$ARGUMENTS", " ".join(args))

    def _replace_indexed(match: re.Match[str]) -> str:
        idx = int(match.group(1))
        return args[idx] if idx < len(args) else ""

    result = re.sub(r"\$ARGUMENTS\[(\d+)\]", _replace_indexed, result)
    result = re.sub(r"\$(\d+)", _replace_indexed, result)
    return result


def _parse_command_text(text: str) -> tuple[str, list[str]]:
    """Split '/name arg1 arg2' into (name, [arg1, arg2])."""
    assert text.startswith("/")
    stripped = text[1:]
    space_idx = stripped.find(" ")
    if space_idx == -1:
        return stripped, []
    name = stripped[:space_idx]
    raw_args = stripped[space_idx + 1:].strip()
    if not raw_args:
        return name, []
    # Simple space-split (respects quoted strings)
    args: list[str] = []
    current = ""
    in_quote: str | None = None
    for char in raw_args:
        if in_quote:
            if char == in_quote:
                in_quote = None
            else:
                current += char
        elif char in "\"'":
            in_quote = char
        elif char in " \t":
            if current:
                args.append(current)
                current = ""
        else:
            current += char
    if current:
        args.append(current)
    return name, args


def resolve_skill_command(text: str) -> tuple[SkillInvocation | None, str | None]:
    """Parse '/name args', find skill, substitute args.
    Returns (invocation, None) on success, (None, error_msg) on failure.
    """
    from .skills import get_user_invocable_skills, load_skill

    name, args = _parse_command_text(text)
    skill = load_skill(name)
    if skill is None:
        available = get_user_invocable_skills()
        # Fuzzy suggestion: prefix match
        suggestions = [s.name for s in available if s.name.startswith(name[:2])]
        if suggestions:
            return None, f"Unknown skill: /{name}\nDid you mean /{suggestions[0]}?"
        available_names = [s.name for s in available]
        if available_names:
            return None, f"Unknown skill: /{name}\nAvailable: {', '.join(available_names)}"
        return None, f"Unknown skill: /{name}\nNo skills installed."

    if not skill.user_invocable:
        return None, f"Skill '{name}' cannot be invoked directly."

    substituted = substitute_args(skill.content, args)
    return SkillInvocation(
        skill=skill,
        substituted_content=substituted,
        context=skill.context,
        allowed_tools=skill.allowed_tools,
    ), None


async def execute_forked_skill(
    invocation: SkillInvocation,
    working_dir: Path,
    subagent_configs: dict[str, SubagentConfig],
    on_output: Callable[[str], Awaitable[None]] | None = None,
) -> str:
    """Execute a skill in a forked subagent context.
    Uses the first available subagent config, or falls back to 'claude' if available.
    Returns the subagent's text output.
    """
    from wafer.core.rollouts.dtypes import ToolCall, ToolResultDelta
    from wafer.core.tools.subagent_tool import exec_subagent

    assert subagent_configs, (
        f"No subagent configs available for forked skill '{invocation.skill.name}'. "
        "Configure [subagents.*] in your agent TOML."
    )
    # Pick the first subagent config as the execution backend
    agent_name = next(iter(subagent_configs))

    tool_call = ToolCall(
        id=f"skill-fork-{uuid.uuid4().hex[:8]}",
        name="subagent",
        args={"agent": agent_name, "prompt": invocation.substituted_content},
    )

    async def _on_delta(delta: ToolResultDelta) -> None:
        if on_output:
            await on_output(delta.delta)

    import os
    result = await exec_subagent(
        tool_call,
        working_dir,
        subagent_configs,
        on_output=_on_delta,
        api_url=os.environ.get("WAFER_API_URL"),
        auth_token=os.environ.get("WAFER_AUTH_TOKEN"),
    )
    if result.is_error:
        return f"[Fork execution error] {result.error}"
    return result.content
