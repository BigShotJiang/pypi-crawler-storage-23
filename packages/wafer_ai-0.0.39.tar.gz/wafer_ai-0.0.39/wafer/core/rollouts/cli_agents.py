"""CLI Agent Adapter for Evaluation.

Runs wafer, Claude Code, or Codex as subprocess and parses output into Trajectory format.
Claude/Codex can be top-level agents or subagents via the subagent tool.
"""
from __future__ import annotations

import json
import logging
import shlex
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from .cli_commands import build_claude_cli_args, build_codex_cli_args
from .dtypes import (
    Message,
    Sample,
    Score,
    TextContent,
    ToolCallContent,
    Trajectory,
)
from .eval_utils import write_sample_started
from .parsers import (
    parse_claude_code_stream_json,
    parse_codex_json,
    parse_raw_text_fallback,
    parse_wafer_stream_json,
)

logger = logging.getLogger(__name__)
# ── Types ─────────────────────────────────────────────────────────────────────
AgentName = Literal["wafer", "claude", "codex"]


@dataclass(frozen=True)
class CLIAgentConfig:
    """Configuration for CLI agent execution.
    Frozen dataclass: immutable, serializable, explicit.
    """
    agent: AgentName
    model: str | None = None
    system_prompt: str | None = None
    timeout_sec: float = 600.0
    allowed_tools: list[str] | None = None
    extra_args: list[str] = field(default_factory=list)
    use_modal: bool = False

    @classmethod
    def from_toml(cls, path: Path, *, timeout_sec: float = 600.0) -> "CLIAgentConfig":
        """Build CLIAgentConfig from a TOML config file.
        For wafer: passes -t <path> so wafer reads all settings from the file.
        For claude/codex: reads model, system_prompt at load time.
        """
        from wafer.cli.agent_config import load_agent_config

        path = path.resolve()
        assert path.exists(), f"Config file not found: {path}"
        file_config = load_agent_config(path)
        agent = file_config.agent or "wafer"
        assert agent in ("wafer", "claude", "codex"), (
            f"agent must be wafer, claude, or codex. Got: {agent!r}"
        )
        if agent == "wafer":
            return cls(
                agent="wafer",
                model=None,
                system_prompt=None,
                timeout_sec=timeout_sec,
                allowed_tools=None,
                extra_args=["-t", str(path)],
                use_modal=False,
            )
        return cls(
            agent=agent,
            model=file_config.model,
            system_prompt=file_config.system_prompt,
            timeout_sec=timeout_sec,
            allowed_tools=None,
            extra_args=[],
            use_modal=False,
        )

    @classmethod
    def for_template(
        cls,
        template_name: str,
        *,
        timeout_sec: float = 600.0,
        config_template_args: dict[str, str] | None = None,
    ) -> "CLIAgentConfig":
        """Build CLIAgentConfig for wafer agent with a bundled template.
        Uses -t template_name so the sandbox resolves from its installed package.
        config_template_args become --args KEY=VALUE for template variable substitution.
        Single-turn is implied by --output-format stream-json (set by build_cli_command).
        Raises ValueError if template not found.
        """
        from wafer.cli.agent_config import get_bundled_template_path

        path = get_bundled_template_path(template_name)
        if path is None:
            from wafer.cli.agent_config import list_bundled_templates
            available = list_bundled_templates()
            raise ValueError(
                f"Template not found: {template_name}. "
                f"Available: {', '.join(available) if available else '(none)'}"
            )
        extra_args: list[str] = ["-t", template_name]
        if config_template_args:
            for k, v in config_template_args.items():
                extra_args.extend(["--args", f"{k}={v}"])
        return cls(
            agent="wafer",
            model=None,
            timeout_sec=timeout_sec,
            allowed_tools=None,
            extra_args=extra_args,
            use_modal=False,
        )


@dataclass(frozen=True)
class CLIAgentResult:
    """Result of running a CLI agent.
    Frozen dataclass: all fields explicit, immutable after creation.
    """
    trajectory: Trajectory
    raw_output: str
    duration_sec: float
    exit_code: int
    error: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens + self.cache_read_tokens + self.cache_write_tokens


@dataclass(frozen=True)
class CLIEvalConfig:
    """Configuration for CLI-agent-based evaluation runs.

    Configures the RUNNER (orchestration, output, concurrency).
    Agent behavior is configured via CLIAgentConfig + agent config TOML files.
    """
    agents: list[CLIAgentConfig]
    build_instruction: Callable[[dict[str, Any]], str]
    code_scorer: Callable[[Sample], Score] | None = None
    trajectory_scorer: Callable[[Sample], Score] | None = None

    prepare_working_dir: Callable[[dict[str, Any], Path], None] | None = None

    max_concurrent: int = 4
    max_samples: int | None = None
    timeout_override: float | None = None

    eval_name: str = "evaluation"
    output_dir: Path | None = None
    working_dir: Path | None = None
    report_batch_size: int = 1

    resume_dir: Path | None = None

    show_progress: bool = True
    verbose: bool = True

    upload_to_supabase: bool = False

    max_sample_retries: int = 3

    samples_per_task: int = 1

    metadata: dict[str, Any] | None = None

    on_sample_complete: Callable[[Sample], None] | None = None

    use_cloud: bool = False


# ── Command Building (Pure) ───────────────────────────────────────────────────
def build_cli_command(
    config: CLIAgentConfig,
    instruction: str,
    *,
    use_cloud: bool = False,
    working_dir: Path | None = None,
) -> list[str]:
    """Build CLI command for the specified agent.
    Pure function: config + instruction -> command list.
    When use_cloud, injects --cloud and --dir for wafer agent.
    """
    assert config is not None, "config must not be None"
    assert instruction is not None, "instruction must not be None"
    assert len(instruction) > 0, "instruction must not be empty"
    if config.agent == "wafer":
        cmd = _build_wafer_command(config, instruction)
        if use_cloud and working_dir is not None:
            cmd = cmd[:2] + ["--cloud", "--dir", str(working_dir)] + cmd[2:]
        return cmd
    if config.agent == "claude":
        return build_claude_cli_args(
            instruction,
            model=config.model,
            allowed_tools=config.allowed_tools,
        )
    assert config.agent == "codex"
    return build_codex_cli_args(
        instruction,
        model=config.model,
    )


def _build_wafer_command(config: CLIAgentConfig, instruction: str) -> list[str]:
    """Build wafer-cli agent command.
    wafer agent "instruction" --output-format stream-json [extra_args]
    Agent config (model, tools) comes from -t in extra_args.
    stream-json implies single-turn.
    """
    cmd = [
        "wafer",
        "agent",
        instruction,
        "--output-format",
        "stream-json",
    ]
    cmd.extend(config.extra_args)
    return cmd


# ── Agent Execution ───────────────────────────────────────────────────────────
_USE_COLOR = sys.stdout.isatty()
_RESET = "\033[0m"
_DIM = "\033[2m"
_RED = "\033[31m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_BLUE = "\033[34m"
_MAGENTA = "\033[35m"
_CYAN = "\033[36m"


def _color(code: str, text: str) -> str:
    return f"{code}{text}{_RESET}" if _USE_COLOR and code else text


def _prefixed_write(
    text: str,
    output_prefix: str | None,
    at_line_start: list[bool],
    stdout_lock: threading.Lock | None = None,
    prefix_color: str = "",
) -> None:
    """Write text to stdout, prefixing each line with [output_prefix] when set."""
    if not text:
        return

    def _do_write() -> None:
        if output_prefix and at_line_start[0]:
            prefix = f"[{output_prefix}] "
            sys.stdout.write(_color(prefix_color or _CYAN, prefix))
            at_line_start[0] = False
        sys.stdout.write(text)
        sys.stdout.flush()
        at_line_start[0] = text.endswith("\n")

    if stdout_lock is not None:
        with stdout_lock:
            _do_write()
    else:
        _do_write()


async def run_cli_agent(
    config: CLIAgentConfig,
    instruction: str,
    working_dir: Path,
    on_stream_line: Callable[[dict[str, Any]], None] | None = None,
    output_prefix: str | None = None,
    stdout_lock: threading.Lock | None = None,
    use_modal: bool = False,
    use_cloud: bool = False,
) -> CLIAgentResult:
    """Run CLI agent and return structured result.
    Args:
        config: Agent configuration (agent name, model, timeout)
        instruction: Task instruction for the agent
        working_dir: Directory where agent will execute
        on_stream_line: Optional callback for each parsed JSON line from agent stdout
        output_prefix: When set, prefix each line of stdout (for concurrent runs)
        use_modal: When True, run inside a Modal Sandbox instead of local subprocess
    Returns:
        CLIAgentResult with trajectory, raw output, timing, exit code
    """
    import trio

    assert config is not None
    assert instruction is not None
    assert len(instruction) > 0

    if use_modal:
        from .modal_runner import run_cli_agent_modal
        return await run_cli_agent_modal(
            config=config,
            instruction=instruction,
            working_dir=working_dir,
            on_stream_line=on_stream_line,
        )

    assert working_dir.exists()  # noqa: ASYNC240 - sync assertion before async work
    assert working_dir.is_dir()  # noqa: ASYNC240 - sync assertion before async work
    cmd = build_cli_command(
        config, instruction,
        use_cloud=use_cloud,
        working_dir=working_dir if use_cloud else None,
    )
    if output_prefix:
        flat = instruction.replace("\n", " ").strip()
        if len(flat) > 200:
            flat = flat[:200] + "..."
        logger.info(f"[{output_prefix}] {flat}")
    else:
        logger.info(f"Running {config.agent}: {shlex.join(cmd[:5])}...")
    start_time = time.perf_counter()
    raw_output_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []
    stdout_line_buf = ""
    at_line_start: list[bool] = [True]
    text_buffer: list[str] = []
    pending_tool_call: list[str] = []  # ["  > grep("] when tool_call_start seen
    turn_count: list[int] = [0]
    result_input_tokens: list[int] = [0]
    result_output_tokens: list[int] = [0]
    result_cache_read_tokens: list[int] = [0]
    result_cache_write_tokens: list[int] = [0]

    def _truncate_content(content: str, max_lines: int = 3, max_chars: int = 200) -> str:
        """Truncate content for terminal display. Returns string with trailing newline."""
        if not content:
            return ""
        lines = content.splitlines()
        if len(lines) <= max_lines and len(content) <= max_chars:
            return content.rstrip() + ("\n" if not content.endswith("\n") else "")
        preview = "\n".join(lines[:max_lines])
        if len(preview) > max_chars:
            preview = preview[:max_chars] + "..."
        suffix = f" ({len(lines)} lines)" if len(lines) > max_lines else ""
        return preview + suffix + "\n"

    def _format_tool_args(tool_name: str, args: dict[str, Any]) -> str:
        """Format tool args for display: compact, no full file content."""
        if not isinstance(args, dict):
            return str(args)
        if tool_name == "write":
            path = args.get("path", "")
            content = args.get("content", "")
            size = len(content) if isinstance(content, str) else 0
            return f"path={path!r}, {size} bytes"
        if tool_name == "edit":
            path = args.get("path", "")
            content = args.get("content", "")
            size = len(content) if isinstance(content, str) else 0
            return f"path={path!r}, {size} bytes"
        if tool_name == "bash":
            cmd = args.get("command", "")
            return cmd[:80] + ("..." if len(str(cmd)) > 80 else "")
        if tool_name == "read":
            path = args.get("path", "")
            return f"path={path!r}"
        if tool_name == "grep":
            pattern = args.get("pattern", "")
            path = args.get("path", "")
            parts = [f"pattern={pattern!r}"] if pattern else []
            if path:
                parts.append(f"path={path!r}")
            return ", ".join(parts) if parts else str(args)
        if tool_name == "glob":
            pattern = args.get("pattern", "")
            return f"pattern={pattern!r}" if pattern else str(args)
        return ", ".join(f"{k}={v!r}" for k, v in args.items())

    def _flush_text_buffer() -> None:
        if text_buffer:
            text = "".join(text_buffer)
            if len(text) > 500:
                text = text[:500] + "..."
            if text and not text.endswith("\n"):
                text += "\n"
            _prefixed_write(
                _color(_BLUE, text),
                output_prefix,
                at_line_start,
                stdout_lock,
            )
            text_buffer.clear()

    def _out(text: str, color: str = "") -> None:
        out = _color(color, text) if color else text
        _prefixed_write(out, output_prefix, at_line_start, stdout_lock)

    def _out_assistant_or_user(obj: dict[str, Any], role: str) -> None:
        """Pretty-print assistant or user message content."""
        msg = obj.get("message") or {}
        content = msg.get("content", []) if isinstance(msg, dict) else []
        for block in content[:5]:
            if not isinstance(block, dict):
                continue
            bt = block.get("type", "")
            if bt == "text":
                text = block.get("text", "")
                if text:
                    display = _truncate_content(text, max_lines=3, max_chars=200)
                    _out(f"  [{role}] {display}", _BLUE)
            elif bt == "tool_use":
                name = block.get("name", "?")
                inp = block.get("input", {}) or {}
                path = inp.get("path", "")
                args_preview = f"path={path}" if path else ""
                _out(f"  > {name}({args_preview})\n", _YELLOW)
            elif bt == "tool_result":
                c = block.get("content", "")
                display = _truncate_content(c, max_lines=3, max_chars=200)
                _out(f"  => {display}", _GREEN)

    def _flush_line(line: str) -> None:
        """Pretty-print a single NDJSON line from the agent stream."""
        stripped = line.strip()
        if not stripped:
            return
        try:
            obj = json.loads(stripped)
        except json.JSONDecodeError:
            _flush_text_buffer()
            out = line if line.endswith("\n") else line + "\n"
            _out(out, _DIM)
            return
        if on_stream_line is not None:
            on_stream_line(obj)
        t = obj.get("type", "")
        if t == "text_delta":
            text_buffer.append(obj.get("delta", ""))
        elif t == "status":
            _flush_text_buffer()
            _out(f"\n  [{obj.get('message', '')}]\n", _DIM)
        elif t == "tool_call_start":
            _flush_text_buffer()
            turn_count[0] += 1
            turn_pref = f"[turn {turn_count[0]}] " if turn_count[0] > 0 else ""
            pending_tool_call.append(f"\n  {turn_pref}> {obj.get('tool_name', '')}(")
        elif t == "tool_call_end":
            args = obj.get("args", {})
            tool_name = obj.get("tool_name", "")
            args_str = _format_tool_args(tool_name, args)
            if pending_tool_call:
                _out(pending_tool_call.pop() + f"{args_str})\n", _YELLOW)
            else:
                _out(f"  {args_str}\n", _YELLOW)
        elif t == "tool_result":
            _flush_text_buffer()
            content = obj.get("content", "")
            is_err = obj.get("is_error", False)
            pfx = "  ERR " if is_err else "  => "
            color = _RED if is_err else _GREEN
            if is_err:
                full = content if content.endswith("\n") else content + "\n"
            else:
                full = _truncate_content(content, max_lines=3, max_chars=200)
            _out(f"{pfx}{full}", color)
        elif t == "initializing":
            _out("  initializing...\n", _DIM)
        elif t == "tool_exec_start":
            pass
        elif t == "tool_call_delta":
            pass  # suppress per-token streaming deltas (extremely verbose)
        elif t == "result":
            _flush_text_buffer()
            subtype = obj.get("subtype", "done")
            usage = obj.get("usage", {})
            result_input_tokens[0] = usage.get("input_tokens", 0)
            result_output_tokens[0] = usage.get("output_tokens", 0)
            result_cache_read_tokens[0] = usage.get("cache_read_tokens", 0)
            result_cache_write_tokens[0] = usage.get("cache_write_tokens", 0)
            _out(f"  Agent completed ({subtype})\n", _MAGENTA)
        elif t == "assistant":
            _flush_text_buffer()
            _out_assistant_or_user(obj, "assistant")
        elif t == "user":
            _flush_text_buffer()
            _out_assistant_or_user(obj, "user")
        elif t == "system":
            _flush_text_buffer()
            subtype = obj.get("subtype", "")
            if subtype == "init":
                pass
            else:
                _out(f"  [system: {subtype or 'event'}]\n", _DIM)
        elif t in ("content_block_start", "content_block_stop",
                    "content_block_delta", "message_start", "message_delta",
                    "message_stop", "input_json_delta", "ping"):
            pass  # suppress Anthropic streaming protocol noise
        else:
            _flush_text_buffer()
            _out(f"  {stripped}\n", _DIM)

    process = await trio.lowlevel.open_process(
        cmd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(working_dir),
    )
    assert process.stdout is not None
    assert process.stderr is not None

    async def read_stdout() -> None:
        nonlocal stdout_line_buf
        async for chunk in process.stdout:
            raw_output_chunks.append(chunk)
            text = chunk.decode("utf-8", errors="replace")
            stdout_line_buf += text
            while "\n" in stdout_line_buf:
                line, stdout_line_buf = stdout_line_buf.split("\n", 1)
                _flush_line(line)

    async def read_stderr() -> None:
        async for chunk in process.stderr:
            stderr_chunks.append(chunk)
            sys.stderr.buffer.write(chunk)
            sys.stderr.flush()

    with trio.move_on_after(config.timeout_sec) as cancel_scope:
        async with trio.open_nursery() as nursery:
            nursery.start_soon(read_stdout)
            nursery.start_soon(read_stderr)
    if stdout_line_buf.strip():
        _flush_line(stdout_line_buf)
        stdout_line_buf = ""
    sys.stdout.write("\n")
    sys.stdout.flush()
    if cancel_scope.cancelled_caught:
        process.terminate()
        with trio.move_on_after(5):
            await process.wait()
        if process.returncode is None:
            process.kill()
            await process.wait()
        duration_sec = time.perf_counter() - start_time
        raw_output = b"".join(raw_output_chunks).decode("utf-8", errors="replace")
        return CLIAgentResult(
            trajectory=Trajectory(messages=[]),
            raw_output=raw_output,
            duration_sec=duration_sec,
            exit_code=-1,
            error=f"Timeout after {config.timeout_sec}s",
            input_tokens=result_input_tokens[0],
            output_tokens=result_output_tokens[0],
            cache_read_tokens=result_cache_read_tokens[0],
            cache_write_tokens=result_cache_write_tokens[0],
        )

    await process.wait()
    duration_sec = time.perf_counter() - start_time
    raw_output = b"".join(raw_output_chunks).decode("utf-8", errors="replace")
    stderr = b"".join(stderr_chunks).decode("utf-8", errors="replace")
    messages = _parse_agent_output(config.agent, raw_output)
    error = None
    if process.returncode != 0:
        error = f"Exit code {process.returncode}: {stderr[:500]}"
    return CLIAgentResult(
        trajectory=Trajectory(messages=messages),
        raw_output=raw_output,
        duration_sec=duration_sec,
        exit_code=process.returncode or 0,
        error=error,
        input_tokens=result_input_tokens[0],
        output_tokens=result_output_tokens[0],
        cache_read_tokens=result_cache_read_tokens[0],
        cache_write_tokens=result_cache_write_tokens[0],
    )


def _parse_agent_output(agent: AgentName, output: str) -> list[Message]:
    """Parse agent output into Messages."""
    if agent == "claude":
        messages = parse_claude_code_stream_json(output)
        if not messages and output.strip():
            messages = parse_raw_text_fallback(output)
        return messages
    if agent == "codex":
        messages = parse_codex_json(output)
        if not messages and output.strip():
            messages = parse_raw_text_fallback(output)
        return messages
    assert agent == "wafer"
    messages = parse_claude_code_stream_json(output)
    if not messages:
        messages = parse_wafer_stream_json(output)
    if not messages and output.strip():
        messages = parse_raw_text_fallback(output)
    return messages


# ── Evaluation Integration ────────────────────────────────────────────────────
async def evaluate_cli_agent_sample(
    config: CLIAgentConfig,
    sample_data: dict[str, Any],
    sample_id: str,
    working_dir: Path,
    build_instruction: Callable[[dict[str, Any]], str],
    code_scorer: Callable[[Sample], Score] | None = None,
    trajectory_scorer: Callable[[Sample], Score] | None = None,
    on_stream_line: Callable[[dict[str, Any]], None] | None = None,
    output_prefix: str | None = None,
    stdout_lock: threading.Lock | None = None,
    eval_logger: logging.Logger | None = None,
    use_cloud: bool = False,
) -> Sample:
    """Evaluate a single sample with a CLI agent.
    Drop-in replacement for evaluate_sample() but uses CLI agent instead of LLM API.
    Args:
        config: CLI agent configuration
        sample_data: Raw sample data (problem definition)
        sample_id: Unique identifier for this sample
        working_dir: Directory where agent executes
        build_instruction: Function that builds instruction from sample_data
        code_scorer: Extracts benchmark/artifact score from turn_scores (Sample -> Score)
        trajectory_scorer: LLM judge on agent's conversation (Sample -> Score)
        on_stream_line: Optional callback for each parsed JSON line from agent
        output_prefix: When set, prefix each line of agent stdout (for concurrent runs)
        use_cloud: When True, add --cloud --dir to wafer agent command
    Returns:
        Sample with trajectory, score, and metadata
    """
    assert config is not None
    assert sample_data is not None
    assert sample_id is not None
    assert working_dir.exists()  # noqa: ASYNC240 - sync assertion before async work
    instruction = build_instruction(sample_data)
    assert instruction is not None
    assert len(instruction) > 0
    if config.agent in ("claude", "codex") and config.system_prompt:
        instruction = f"{config.system_prompt}\n\n---\n\nTask:\n\n{instruction}"
    result = await run_cli_agent(
        config, instruction, working_dir,
        on_stream_line=on_stream_line,
        output_prefix=output_prefix,
        stdout_lock=stdout_lock,
        use_modal=config.use_modal,
        use_cloud=use_cloud,
    )
    turns_used = len(result.trajectory.messages)
    sample = Sample(
        id=sample_id,
        input=sample_data,
        trajectory=result.trajectory,
        ground_truth=sample_data.get("expected_answer") or sample_data.get("ground_truth"),
        metadata={
            "agent": config.agent,
            "model": config.model,
            "duration_sec": result.duration_sec,
            "exit_code": result.exit_code,
            "error": result.error,
            "status": "success" if result.error is None else "failed",
            "turns_used": turns_used,
            "input_tokens": result.input_tokens,
            "output_tokens": result.output_tokens,
            "cache_read_tokens": result.cache_read_tokens,
            "cache_write_tokens": result.cache_write_tokens,
            "total_tokens": result.total_tokens,
        },
    )
    from wafer.core.rollouts.scoring import extract_turn_scores
    sample.turn_scores = extract_turn_scores(sample)

    import inspect

    # Run code scorer (extracts benchmark result from turn_scores)
    if code_scorer is not None:
        code_result = code_scorer(sample)
        if inspect.iscoroutine(code_result):
            sample.code_score = await code_result
        else:
            sample.code_score = code_result

    # Run trajectory scorer (LLM judge on conversation)
    if trajectory_scorer is not None:
        run_dir = working_dir.parent
        events_path = run_dir / "events.jsonl"

        def _write_judge_event(obj: dict) -> None:
            if events_path.exists():
                with open(events_path, "a") as f:
                    f.write(json.dumps(obj, default=str) + "\n")
                    f.flush()

        if output_prefix is not None and stdout_lock is not None:
            _prefixed_write(
                _color(_MAGENTA, "  [Judge running...]\n"),
                output_prefix,
                [True],
                stdout_lock,
            )

        if events_path.exists():
            _write_judge_event({
                "message": "judge_start",
                "type": "judge_start",
                "id": sample_id,
                "sample_id": sample_id,
            })

        judge_at_line_start: list[bool] = [True]

        def _on_judge_chunk(chunk: str) -> None:
            _write_judge_event({
                "type": "judge_result_delta",
                "id": sample_id,
                "sample_id": sample_id,
                "delta": chunk,
            })
            if output_prefix is not None and stdout_lock is not None:
                _prefixed_write(
                    _color(_MAGENTA, chunk),
                    output_prefix,
                    judge_at_line_start,
                    stdout_lock,
                )

        traj_result = trajectory_scorer(sample, on_chunk=_on_judge_chunk)
        if inspect.iscoroutine(traj_result):
            sample.trajectory_score = await traj_result
        else:
            sample.trajectory_score = traj_result

        if eval_logger is not None and sample.metadata.get("judge_output"):
            eval_logger.info(
                "judge_result",
                extra={
                    "type": "judge_result",
                    "id": sample_id,
                    "sample_id": sample_id,
                    "judge_output": sample.metadata["judge_output"],
                    "reward": sample.reward,
                },
            )
        judge_out = sample.metadata.get("judge_output", "")
        if output_prefix is not None and stdout_lock is not None and judge_out:
            full = judge_out if judge_out.endswith("\n") else judge_out + "\n"
            _prefixed_write(
                _color(_MAGENTA, f"  Judge: {full}"),
                output_prefix,
                [True],
                stdout_lock,
            )

    # Primary score: code_score takes precedence over trajectory_score
    sample.score = sample.code_score or sample.trajectory_score
    assert sample.score is not None, "At least one of code_scorer or trajectory_scorer must be set"
    sample.reward = sample.score.reward
    if sample.reward > 0 and sample.metadata.get("status") == "failed":
        sample.metadata["status"] = "completed"
    return sample


async def evaluate_cli_agents(
    dataset: list[dict[str, Any]],
    config: CLIEvalConfig,
    working_dir: Path | None = None,
) -> EvalReport:
    """Production-grade CLI agent evaluation runner.

    Replaces evaluate() for all CLI-agent-based evals. Features:
    - Resume support (skip completed samples)
    - Per-sample file streaming (live observability)
    - Partial report writing (interrupt recovery)
    - Retry failed samples with exponential backoff
    - Progress display
    - Summary metrics
    - Supabase upload
    """
    from .eval_utils import (
        EvalReport,
        compute_summary_metrics,
        load_completed_sample_ids,
        load_streamed_samples,
        stream_sample_to_file,
        write_partial_report,
    )

    assert config.agents is not None
    assert len(config.agents) > 0
    assert dataset is not None
    assert len(dataset) > 0

    output_dir = config.output_dir or (
        Path(f"results/{config.eval_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    if working_dir is None:
        working_dir = config.working_dir or (output_dir / "workdirs")
    working_dir.mkdir(parents=True, exist_ok=True)

    # Resume: load completed sample IDs
    completed_ids: set[str] = set()
    resumed_samples: list[Sample] = []
    if config.resume_dir:
        completed_ids = load_completed_sample_ids(config.resume_dir)
        resumed_samples = load_streamed_samples(config.resume_dir)
        logger.info(f"Resuming: {len(completed_ids)} completed samples found")

    # Build work list (with pass@k support via samples_per_task)
    samples_to_eval: list[tuple[str, CLIAgentConfig, dict[str, Any]]] = []
    effective_dataset = dataset[: config.max_samples] if config.max_samples else dataset
    k_range = range(config.samples_per_task)
    for agent_config in config.agents:
        for idx, sample_data in enumerate(effective_dataset):
            for k in k_range:
                if config.samples_per_task > 1:
                    sample_id = f"{agent_config.agent}_{idx:04d}_k{k:02d}"
                else:
                    sample_id = f"{agent_config.agent}_{idx:04d}"
                if sample_id in completed_ids:
                    continue
                samples_to_eval.append((sample_id, agent_config, sample_data))

    if not samples_to_eval:
        logger.info("All samples already completed")
        return EvalReport(
            eval_name=config.eval_name,
            total_samples=len(effective_dataset) * len(config.agents),
            summary_metrics=compute_summary_metrics(resumed_samples),
            sample_results=resumed_samples,
            metadata=config.metadata,
        )

    from ._logging.logging_config import setup_eval_logging

    eval_logging_ctx = setup_eval_logging(output_dir)
    eval_logger = logging.getLogger("wafer.eval.events")
    total_to_run = len(samples_to_eval) + len(resumed_samples)
    eval_logger.info(
        "eval_start",
        extra={
            "type": "eval_start",
            "id": "",
            "eval_name": config.eval_name,
            "total": total_to_run,
        },
    )

    import trio

    resumed = len(completed_ids)
    if resumed:
        logger.info(f"Evaluating {len(samples_to_eval)} samples ({resumed} already done)")
    else:
        logger.info(f"Evaluating {len(samples_to_eval)} samples")

    all_results: list[Sample] = list(resumed_samples)
    last_report_count = len(all_results)
    interrupted = False
    limiter = trio.CapacityLimiter(config.max_concurrent)
    stdout_lock = threading.Lock() if config.max_concurrent > 1 else None

    try:

        async def _run_one(
            sample_id: str,
            agent_config: CLIAgentConfig,
            sample_data: dict[str, Any],
        ) -> Sample:
            nonlocal last_report_count
            eval_logger.info(
                "sample_start",
                extra={"type": "sample_start", "id": sample_id, "sample_id": sample_id},
            )
            write_sample_started(sample_id, sample_data, output_dir)
            async with limiter:
                sample_dir = working_dir / sample_id
                sample_dir.mkdir(parents=True, exist_ok=True)
                if config.prepare_working_dir:
                    config.prepare_working_dir(sample_data, sample_dir)
                effective_config = agent_config
                if config.timeout_override:
                    effective_config = CLIAgentConfig(
                        agent=agent_config.agent,
                        model=agent_config.model,
                        system_prompt=agent_config.system_prompt,
                        allowed_tools=agent_config.allowed_tools,
                        timeout_sec=config.timeout_override,
                        extra_args=agent_config.extra_args,
                    )
                _LOG_RECORD_RESERVED = frozenset({
                    "name", "msg", "args", "created", "filename", "funcName",
                    "levelname", "levelno", "lineno", "module", "msecs",
                    "pathname", "process", "processName", "relativeCreated",
                    "stack_info", "thread", "threadName", "exc_info", "exc_text",
                    "message", "asctime", "taskName",
                })

                _EVENTS_SKIP_LOG = frozenset({
                    "tool_call_delta", "text_delta",
                    "content_block_start", "content_block_delta", "content_block_stop",
                    "message_start", "message_delta", "message_stop",
                    "input_json_delta", "ping",
                })

                def _on_agent_line(obj: dict[str, Any], _sid: str = sample_id) -> None:
                    event_type = obj.get("type", "unknown")
                    if event_type in _EVENTS_SKIP_LOG:
                        return
                    extra: dict[str, Any] = {"type": event_type, "id": _sid, "sample_id": _sid}
                    for k, v in obj.items():
                        key = f"evt_{k}" if k in _LOG_RECORD_RESERVED else k
                        if k == "message":
                            extra["msg_payload"] = v
                        else:
                            extra[key] = v
                    eval_logger.info(event_type, extra=extra)

                prefix = sample_id if config.max_concurrent > 1 else None
                sample = await evaluate_cli_agent_sample(
                    config=effective_config,
                    sample_data=sample_data,
                    sample_id=sample_id,
                    working_dir=sample_dir,
                    build_instruction=config.build_instruction,
                    code_scorer=config.code_scorer,
                    trajectory_scorer=config.trajectory_scorer,
                    on_stream_line=_on_agent_line,
                    output_prefix=prefix,
                    stdout_lock=stdout_lock,
                    eval_logger=eval_logger,
                    use_cloud=config.use_cloud,
                )
                stream_sample_to_file(sample, output_dir)
                all_results.append(sample)
                reward = sample.reward
                end_extra: dict[str, Any] = {
                    "type": "sample_end",
                    "id": sample_id,
                    "sample_id": sample_id,
                    "score": reward,
                    "reward": reward,
                }
                if sample.code_score is not None:
                    end_extra["code_reward"] = sample.code_score.reward
                if sample.trajectory_score is not None:
                    end_extra["trajectory_reward"] = sample.trajectory_score.reward
                eval_logger.info("sample_end", extra=end_extra)
                if config.on_sample_complete:
                    config.on_sample_complete(sample)
                if len(all_results) - last_report_count >= config.report_batch_size:
                    write_partial_report(
                        output_dir, all_results, config.eval_name,
                        metadata=config.metadata,
                    )
                    last_report_count = len(all_results)
                return sample

        # Run batch with interrupt handling
        try:
            async with trio.open_nursery() as nursery:
                for sample_id, agent_config, sample_data in samples_to_eval:
                    async def task(
                        sid: str = sample_id,
                        acfg: CLIAgentConfig = agent_config,
                        sdata: dict[str, Any] = sample_data,
                    ) -> None:
                        await _run_one(sid, acfg, sdata)
                    nursery.start_soon(task)
        except KeyboardInterrupt:
            interrupted = True
            logger.warning("Evaluation interrupted by user")
        except BaseExceptionGroup as eg:
            if eg.subgroup(KeyboardInterrupt) is not None:
                interrupted = True
                logger.warning("Evaluation interrupted by user (from nursery)")
            else:
                raise

        # Retry failed samples
        if not interrupted and config.max_sample_retries > 0:
            for retry_attempt in range(config.max_sample_retries):
                provider_errors = [
                    (s.id, s.input)
                    for s in all_results
                    if s.metadata.get("status") == "provider_error"
                ]
                if not provider_errors:
                    break
                wait_seconds = min(30 * (2 ** retry_attempt), 120)
                logger.info(
                    f"Retry {retry_attempt + 1}/{config.max_sample_retries}: "
                    f"{len(provider_errors)} provider errors, waiting {wait_seconds}s"
                )
                await trio.sleep(wait_seconds)
                for err_id, err_input in provider_errors:
                    matching = [
                        (sid, acfg, sdata)
                        for sid, acfg, sdata in samples_to_eval
                        if sid == err_id
                    ]
                    if matching:
                        _, acfg, sdata = matching[0]
                        all_results = [r for r in all_results if r.id != err_id]
                        await _run_one(err_id, acfg, sdata)

        # Write final report
        summary_metrics = compute_summary_metrics(all_results)
        report = EvalReport(
            eval_name=config.eval_name,
            total_samples=len(effective_dataset) * len(config.agents),
            summary_metrics=summary_metrics,
            sample_results=all_results,
            metadata=config.metadata,
        )

        if output_dir:
            await report.save(output_dir)
            if interrupted:
                write_partial_report(
                    output_dir, all_results, config.eval_name,
                    interrupted=True, metadata=config.metadata,
                )

        eval_logger.info(
            "eval_end",
            extra={
                "type": "eval_end",
                "id": "",
                "eval_name": config.eval_name,
                "total": len(all_results),
                "mean_reward": summary_metrics.get("mean_reward", 0.0),
                "interrupted": interrupted,
            },
        )
    finally:
        eval_logging_ctx.teardown()

    # Upload
    if config.upload_to_supabase and output_dir:
        from .upload import upload_results_to_supabase
        upload_results_to_supabase(output_dir)

    logger.info(f"Complete: {len(all_results)} samples, mean_reward={summary_metrics.get('mean_reward', 0.0):.3f}")
    return report


# ── Convenience Functions ─────────────────────────────────────────────────────
def trajectory_to_text(trajectory: Trajectory) -> str:
    """Convert trajectory to human-readable text.
    Useful for logging and debugging.
    Pure function: trajectory -> string.
    """
    assert trajectory is not None
    lines = []
    for msg in trajectory.messages:
        role = msg.role.upper()
        if isinstance(msg.content, str):
            lines.append(f"[{role}]\n{msg.content}\n")
        elif isinstance(msg.content, list):
            parts = []
            for block in msg.content:
                if isinstance(block, TextContent):
                    parts.append(block.text)
                elif isinstance(block, ToolCallContent):
                    parts.append(f"[TOOL: {block.name}({json.dumps(block.arguments)})]")
            lines.append(f"[{role}]\n{''.join(parts)}\n")
        else:
            lines.append(f"[{role}]\n{msg.content}\n")
    return "\n".join(lines)
