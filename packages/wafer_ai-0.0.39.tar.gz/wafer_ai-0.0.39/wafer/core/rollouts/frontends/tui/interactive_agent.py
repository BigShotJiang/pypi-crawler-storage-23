# ruff: noqa: PLR0913
# PLR0913 (too many arguments) is suppressed because TUI runner functions
# need to accept many configuration parameters.
"""
Interactive TUI agent runner.
Provides a complete interactive agent loop with TUI rendering.
Session persistence is handled by run_agent() via RunConfig.session_store.
"""
from __future__ import annotations

import signal
import sys
import time as _time
from pathlib import Path
from types import FrameType
from typing import TYPE_CHECKING

import trio

from ...agents import Actor, AgentState, run_agent
from ...dtypes import (
    DetailLevel,
    Endpoint,
    Environment,
    Message,
    RunConfig,
    StopReason,
    StreamEvent,
    ToolCall,
    ToolConfirmResult,
    ToolResult,
    Trajectory,
)
from ...models import get_model
from .agent_renderer import AgentRenderer
from .components.input import Input, expand_file_markers
from .components.loader_container import LoaderContainer
from .components.spacer import Spacer
from .control_flow_types import (
    AgentCompleted,
    AgentError,
    AgentExited,
    AgentInterrupted,
    AgentOutcome,
    InputMessage,
    InputResult,
)
from .terminal import ProcessTerminal, set_active_session_id
from .tui import TUI

if TYPE_CHECKING:
    from ...store import SessionStore
    from .components.status_line import StatusLine


class MessageQueue:
    """FIFO queue for user messages with trio notification.

    The deque is the source of truth. The trio channel (buffer=1) is a
    pure notification mechanism so the consumer can ``await`` without polling.
    """

    def __init__(self) -> None:
        self._messages: list[str] = []
        self._notify_send: trio.MemorySendChannel[None] | None = None
        self._notify_receive: trio.MemoryReceiveChannel[None] | None = None

    def init_channels(self) -> None:
        self._notify_send, self._notify_receive = trio.open_memory_channel[None](1)

    def enqueue(self, msg: str) -> None:
        assert self._notify_send is not None
        self._messages.append(msg)
        try:
            self._notify_send.send_nowait(None)
        except trio.WouldBlock:
            pass  # notification already pending

    def pop_next(self) -> str | None:
        return self._messages.pop(0) if self._messages else None

    def clear(self) -> list[str]:
        cleared = list(self._messages)
        self._messages.clear()
        return cleared

    def pending(self) -> int:
        return len(self._messages)

    async def wait_for_message(self) -> None:
        """Block until the deque is non-empty.

        Loops to handle stale notifications (e.g. notification sent by an
        enqueue whose message was already popped synchronously).
        """
        assert self._notify_receive is not None
        while not self._messages:
            await self._notify_receive.receive()


class InteractiveAgentRunner:
    """Interactive agent runner with TUI."""
    def __init__(
        self,
        initial_trajectory: Trajectory,
        endpoint: Endpoint,
        environment: Environment | None = None,
        session_store: SessionStore | None = None,
        session_id: str | None = None,
        theme_name: str = "dark",
        debug: bool = False,
        debug_layout: bool = False,
        parent_session_id: str | None = None,
        branch_point: int | None = None,
        confirm_tools: bool = False,
        initial_prompt: str | None = None,
    ) -> None:
        """Initialize interactive agent runner.
        Args:
            initial_trajectory: Initial conversation trajectory
            endpoint: LLM endpoint configuration
            environment: Optional environment for tool execution
            session_store: Optional session store for persistence
            session_id: Optional session ID (required if session_store is set)
            theme_name: Theme name (dark or rounded)
            debug: Enable debug logging and chat state dumps
            debug_layout: Show component boundaries and spacing
            parent_session_id: Parent session ID when forking
            branch_point: Message index where forking from parent
            confirm_tools: Require confirmation before executing tools
            initial_prompt: Optional initial prompt to send immediately
        """
        self.initial_trajectory = initial_trajectory
        self.endpoint = endpoint
        self.theme_name = theme_name
        self.environment = environment
        self.session_store = session_store
        self.session_id = session_id
        if session_id:
            set_active_session_id(session_id)  # For crash reporting
        self.debug = debug
        self.debug_layout = debug_layout
        self.parent_session_id = parent_session_id
        self.branch_point = branch_point
        self.confirm_tools = confirm_tools
        self.initial_prompt = initial_prompt
        # TUI components
        self.terminal: ProcessTerminal | None = None
        self.tui: TUI | None = None
        self.renderer: AgentRenderer | None = None
        self.input_component: Input | None = None
        self.loader_container: LoaderContainer | None = None
        self.status_line: StatusLine | None = None
        # Message queue for user input (replaces trio channel buffer)
        self._queue = MessageQueue()
        self.input_pending: bool = False
        self.is_first_user_message = True
        # Cancellation - separate scope for agent vs entire TUI
        self.cancel_scope: trio.CancelScope | None = None  # Outer nursery scope
        self.agent_cancel_scope: trio.CancelScope | None = None  # Inner agent scope
        self.escape_pressed: bool = False  # Track if Escape (not Ctrl+C) triggered cancel
        self._exiting_via_ctrl_c: bool = False
        self._ctrl_c_pending: bool = False
        self._ctrl_c_time: float = 0.0
        _CTRL_C_WINDOW_SECS = 2.0  # noqa: N806 — seconds to wait for second Ctrl+C

        self._current_trajectory: Trajectory | None = None

        # Plan mode — when True, user messages are prefixed with a plan-only instruction.
        self._plan_mode: bool = False
        # Tab completion cycling state
        self._tab_cycle_matches: list[str] = []  # Current list of matches
        self._tab_cycle_index: int = 0  # Current position in cycle
        self._tab_cycle_prefix: str = ""  # Original prefix before cycling started
        # Global detail level for tool outputs (toggled with +/-)
        self._detail_level: DetailLevel = DetailLevel.STANDARD

    @property
    def trajectory(self) -> Trajectory:
        if self._current_trajectory:
            return self._current_trajectory
        return self.initial_trajectory

    def _handle_input_submit(self, text: str) -> None:
        """Handle input submission from TUI.
        Enqueues the message. If the agent is busy, it shows a queued
        indicator above the input box; the message auto-runs when the
        agent finishes its current turn.
        """
        if not text.strip():
            return
        cwd = (
            self.environment.working_dir
            if self.environment and hasattr(self.environment, "working_dir")
            else Path.cwd()
        )
        expanded = expand_file_markers(text.strip(), cwd)
        self._queue.enqueue(expanded)
        if not self.input_pending and self.input_component:
            preview = expanded[:80] + ("..." if len(expanded) > 80 else "")
            self.input_component.add_queued_message(preview)
            if self.tui:
                self.tui.request_render()

    def _handle_open_editor(self, current_text: str) -> None:
        """Handle Ctrl+G to open external editor for message composition."""
        from .utils import strip_terminal_control_sequences
        if not self.terminal:
            return
        # Run editor (this temporarily exits raw mode)
        edited_content = self.terminal.run_external_editor(current_text)
        # Reset TUI state before redrawing - this clears cached render state
        # that may be invalid after returning from the external editor
        if self.tui:
            self.tui.reset_render_state()
        # If user saved content, update input and optionally submit
        if edited_content:
            # Strip any terminal control sequences that may have leaked in
            # (e.g., bracketed paste sequences from the editor session)
            edited_content = strip_terminal_control_sequences(edited_content)
            if self.input_component:
                self.input_component.set_text(edited_content)
            # Auto-submit the edited content
            self._handle_input_submit(edited_content)
            # Clear input after submit
            if self.input_component:
                self.input_component.set_text("")
        # Force full redraw
        if self.tui:
            self.tui.request_render()

    def _handle_input_change(self, text: str) -> None:
        """Handle input text change — update ghost text for skill autocomplete."""
        if not self.input_component:
            return
        is_cycling = False
        if self._tab_cycle_matches and self._tab_cycle_index < len(self._tab_cycle_matches):
            current_match = self._tab_cycle_matches[self._tab_cycle_index]
            if text == f"/{current_match}" or text == f"/{current_match} ":
                is_cycling = True
        if not is_cycling:
            self._tab_cycle_matches = []
            self._tab_cycle_index = 0
            self._tab_cycle_prefix = ""
        ghost_text = self._compute_ghost_text(text)
        self.input_component.set_ghost_text(ghost_text)
        if self.tui:
            self.tui.request_render()

    _BUILTIN_COMMANDS: list[tuple[str, str]] = [
        ("resume", "<session_id>"),
        ("sessions", ""),
        ("plan", ""),
        ("execute", ""),
    ]

    def _all_completable_names(self) -> list[tuple[str, str]]:
        """Return (name, arg_hint) for all slash-completable items: builtins + skills."""
        from ...skills import get_user_invocable_skills
        items: list[tuple[str, str]] = list(self._BUILTIN_COMMANDS)
        for s in get_user_invocable_skills():
            items.append((s.name, s.argument_hint or ""))
        return items

    def _compute_ghost_text(self, text: str) -> str:
        """Compute ghost text hint for slash commands (builtins + skills)."""
        if not text.startswith("/"):
            return ""
        if " " not in text:
            prefix = text[1:]
            items = self._all_completable_names()
            if not prefix:
                return items[0][0] if items else ""
            matches = [(name, hint) for name, hint in items if name.startswith(prefix)]
            if not matches:
                return ""
            first_name, first_hint = matches[0]
            suffix = first_name[len(prefix):]
            if not suffix and first_hint:
                return f" {first_hint}"
            return suffix
        space_idx = text.index(" ")
        cmd_name = text[1:space_idx]
        arg_text = text[space_idx + 1:]
        if not arg_text:
            for name, hint in self._all_completable_names():
                if name == cmd_name and hint:
                    return hint
        return ""

    def _handle_tab_complete(self, text: str) -> str | None:
        """Tab completion for slash commands. Supports cycling through matches."""
        if not text.startswith("/"):
            return None
        if " " in text:
            return None
        prefix = text[1:]
        if (
            self._tab_cycle_matches
            and text.rstrip() == f"/{self._tab_cycle_matches[self._tab_cycle_index]}"
        ):
            self._tab_cycle_index = (self._tab_cycle_index + 1) % len(self._tab_cycle_matches)
            return f"/{self._tab_cycle_matches[self._tab_cycle_index]}"
        items = self._all_completable_names()
        matches = [name for name, _ in items if name.startswith(prefix)]
        if not matches:
            return None
        self._tab_cycle_matches = matches
        self._tab_cycle_index = 0
        self._tab_cycle_prefix = text
        return f"/{matches[0]}"

    def _increase_detail_level(self) -> None:
        """Increase detail level for all tool outputs (+ key)."""
        if self._detail_level < DetailLevel.EXPANDED:
            self._detail_level = DetailLevel(self._detail_level + 1)
            self._update_all_detail_levels()
            if self.renderer:
                level_name = self._detail_level.name.lower()
                self.renderer.add_system_message(f"Detail level: {level_name}")

    def _decrease_detail_level(self) -> None:
        """Decrease detail level for all tool outputs (- key)."""
        if self._detail_level > DetailLevel.COMPACT:
            self._detail_level = DetailLevel(self._detail_level - 1)
            self._update_all_detail_levels()
            if self.renderer:
                level_name = self._detail_level.name.lower()
                self.renderer.add_system_message(f"Detail level: {level_name}")

    def _update_all_detail_levels(self) -> None:
        """Update detail level on all tool execution components in chat.
        Currently applies global detail level to all components.
        Future: Add per-component expansion (scroll to component, expand just that one).
        """
        if not self.renderer or not self.renderer.chat_container:
            return
        from .components.tool_execution import ToolExecution
        for child in self.renderer.chat_container.children:
            if isinstance(child, ToolExecution):
                child.set_detail_level(self._detail_level)
        if self.tui:
            self.tui.request_render()

    async def _resolve_and_execute_skill(self, text: str) -> tuple[str | None, str | None]:
        """Resolve a / command, execute it (inline or fork), return expanded text.
        Returns (expanded_text, None) on success, (None, error_msg) on failure.
        """
        from ...skill_executor import execute_forked_skill, resolve_skill_command
        invocation, err = resolve_skill_command(text)
        if err:
            return None, err
        assert invocation is not None
        if invocation.context == "fork":
            if not self.environment or not hasattr(self.environment, "subagent_configs"):
                return None, f"Fork execution requires subagent configs (skill: {invocation.skill.name})"
            working_dir = (
                self.environment.working_dir
                if hasattr(self.environment, "working_dir")
                else Path.cwd()
            )
            if self.renderer:
                self.renderer.add_ghost_message(f"Running /{invocation.skill.name} in subagent...")
                if self.tui:
                    self.tui.request_render()
            result_text = await execute_forked_skill(
                invocation,
                working_dir,
                self.environment.subagent_configs,
            )
            return result_text, None
        return invocation.substituted_content, None

    async def _tui_input_handler(self, prompt: str) -> str:
        """Async input handler for RunConfig.on_input."""
        from .utils import strip_terminal_control_sequences
        assert self._queue._notify_receive is not None, "MessageQueue channels not initialized"
        while True:
            user_input = await self._get_next_input()
            user_input = strip_terminal_control_sequences(user_input)
            if user_input.startswith("/"):
                expanded, err = await self._resolve_and_execute_skill(user_input)
                if err:
                    if self.renderer:
                        self.renderer.add_ghost_message(err)
                    continue
                if expanded:
                    user_input = expanded
            break
        if self.renderer:
            self.renderer.add_user_message(user_input, is_first=self.is_first_user_message)
            self.is_first_user_message = False
        return user_input

    async def _get_next_input(self) -> str:
        """Get the next user input, either from queue or by waiting.

        If the queue has messages (user typed ahead while agent was busy),
        returns the first one immediately -- this is how auto-chaining works.
        Otherwise blocks until the user submits something.
        """
        queued = self._queue.pop_next()
        if queued:
            if self.input_component:
                self.input_component.pop_queued_message()
            if self.tui:
                self.tui.request_render()
            return queued
        # Nothing queued -- wait for user input
        self.input_pending = True
        if self.input_component and self.tui:
            self.tui.set_focus(self.input_component)
            self.tui.request_render()
        await self._queue.wait_for_message()  # returns only when deque is non-empty
        self.input_pending = False
        msg = self._queue.pop_next()
        assert msg is not None
        if self.input_component:
            self.input_component.set_text("")
        return msg

    async def _get_input_result(self, current_state: AgentState | None) -> InputResult:
        """Get user input and return explicit result type.
        Returns:
            InputMessage: User message to send to LLM (may be skill-expanded)
        """
        from .utils import strip_terminal_control_sequences
        assert self._queue._notify_receive is not None, "MessageQueue channels not initialized"
        while True:
            user_input = await self._get_next_input()
            user_input = strip_terminal_control_sequences(user_input)
            # ── Built-in commands ──────────────────────────────────────
            builtin_handled = self._handle_builtin_command(user_input)
            if builtin_handled:
                continue
            # ── Skill / slash commands ─────────────────────────────────
            if user_input.startswith("/"):
                expanded, err = await self._resolve_and_execute_skill(user_input)
                if err:
                    if self.renderer:
                        self.renderer.add_ghost_message(err)
                        if self.tui:
                            self.tui.request_render()
                    continue
                if expanded:
                    user_input = expanded
            # ── Plan mode prefix ───────────────────────────────────────
            if self._plan_mode:
                user_input = (
                    "[PLAN MODE] Only describe what you would do. Do NOT call any tools. "
                    "List the files you would change and the approach, then stop.\n\n"
                    + user_input
                )
            if self.renderer:
                self.renderer.add_user_message(user_input, is_first=self.is_first_user_message)
                self.is_first_user_message = False
            return InputMessage(text=user_input)

    # ── Built-in TUI commands ──────────────────────────────────────────────

    def _handle_builtin_command(self, text: str) -> bool:
        """Handle built-in slash commands. Returns True if handled (caller should loop)."""
        stripped = text.strip()

        # /plan — enable plan mode
        if stripped == "/plan":
            self._plan_mode = True
            if self.renderer:
                self.renderer.add_system_message("Plan mode ON — agent will describe changes without executing tools")
            if self.status_line:
                self.status_line.set_mode("plan")
            if self.tui:
                self.tui.request_render()
            return True

        # /execute — disable plan mode (default)
        if stripped in ("/execute", "/exec"):
            self._plan_mode = False
            if self.renderer:
                self.renderer.add_system_message("Plan mode OFF — agent will execute normally")
            if self.status_line:
                self.status_line.set_mode(None)
            if self.tui:
                self.tui.request_render()
            return True

        # /resume [id] — resume a previous session
        if stripped == "/resume" or stripped.startswith("/resume "):
            self._handle_resume_command(stripped)
            return True

        # /sessions — list recent sessions
        if stripped == "/sessions":
            self._handle_sessions_command()
            return True

        return False

    def _handle_resume_command(self, text: str) -> None:
        """Handle /resume [id] — reload a previous session.
        No argument: resume most recent session.
        Partial ID: match by prefix.
        """
        parts = text.split(maxsplit=1)
        target = parts[1].strip() if len(parts) > 1 else None
        if not self.session_store:
            self._show_system("No session store configured — cannot resume")
            return
        if not hasattr(self.session_store, "get_latest_id_sync"):
            self._show_system("Session store does not support resume")
            return
        if target is None or target == "last":
            session_id = self.session_store.get_latest_id_sync()
            if not session_id:
                self._show_system("No previous sessions found. Use /sessions to list.")
                return
        else:
            session_id = self._resolve_session_id_prefix(target)
            if not session_id:
                return
        assert session_id is not None
        loaded = self.session_store.load_sync(session_id) if hasattr(self.session_store, "load_sync") else None
        if not loaded:
            self._show_system(f"Session {session_id[:8]}… could not be loaded. Use /sessions to list available.")
            return
        self.session_id = session_id
        set_active_session_id(session_id)
        self.initial_trajectory = loaded
        self._current_trajectory = loaded
        msg_count = len([m for m in loaded.messages if m.role == "user"])
        self._show_system(f"Resumed session {session_id[:8]}… ({msg_count} user messages)")
        if self.status_line:
            self.status_line.set_session_id(session_id)
        if self.tui:
            self.tui.request_render()

    def _resolve_session_id_prefix(self, prefix: str) -> str | None:
        """Resolve a partial session ID prefix to a full ID."""
        assert self.session_store is not None
        if not hasattr(self.session_store, "list_sync"):
            self._show_system("Session listing not available")
            return None
        sessions = self.session_store.list_sync(limit=50)
        matches = [s for s in sessions if s.session_id.startswith(prefix)]
        if len(matches) == 1:
            return matches[0].session_id
        if len(matches) > 1:
            ids = [s.session_id[:16] + "…" for s in matches[:5]]
            self._show_system(f"Ambiguous prefix '{prefix}' — matches: {', '.join(ids)}")
            return None
        self._show_system(f"No session matching '{prefix}'. Use /sessions to list.")
        return None

    def _show_system(self, msg: str) -> None:
        """Show a system message in the TUI."""
        if self.renderer:
            self.renderer.add_system_message(msg)
        if self.tui:
            self.tui.request_render()

    def _handle_sessions_command(self) -> None:
        """Handle /sessions command — list recent sessions with previews."""
        if not self.session_store:
            self._show_system("No session store configured")
            return
        if not hasattr(self.session_store, "list_sync"):
            self._show_system("Session listing not supported by this store")
            return
        sessions = self.session_store.list_sync(limit=10)
        if not sessions:
            self._show_system("No sessions found")
            return
        lines = ["Recent sessions:"]
        for s in sessions:
            sid = getattr(s, "session_id", str(s))
            preview = ""
            for msg in getattr(s, "messages", []):
                if msg.role == "user" and isinstance(msg.content, str):
                    preview = msg.content[:60].replace("\n", " ")
                    if len(msg.content) > 60:
                        preview += "…"
                    break
            display = f"  {sid[:16]}  {preview}" if preview else f"  {sid[:16]}"
            lines.append(display)
        lines.append("")
        lines.append("Resume: /resume <id-prefix>  or  /resume (most recent)")
        self._show_system("\n".join(lines))

    async def _run_agent_with_outcome(self, state: AgentState) -> AgentOutcome:
        """Run agent and return explicit outcome type.
        This wraps run_agent() and converts the various exit conditions
        (exceptions, stop reasons, cancellation) into explicit AgentOutcome types.
        Args:
            state: Current agent state to run from
        Returns:
            AgentOutcome indicating what happened:
            - AgentCompleted: Normal completion (task done or no tools)
            - AgentInterrupted: User pressed Escape
            - AgentExited: User pressed Ctrl+C
            - AgentError: Recoverable error (context too long, OAuth expired)
        """
        self.agent_cancel_scope = trio.CancelScope()
        run_config = self._create_run_config()
        agent_states: list[AgentState] = []
        try:
            with self.agent_cancel_scope:
                agent_states = await run_agent(state, run_config)

            if agent_states:
                self._current_trajectory = agent_states[-1].actor.trajectory
        except Exception as e:
            from ...providers.base import ContextTooLongError
            if isinstance(e, ContextTooLongError):
                return AgentError(
                    states=agent_states or [state],
                    error=e,
                    error_kind="context_too_long",
                )
            from ...frontends.tui.oauth import OAuthExpiredError
            if isinstance(e, OAuthExpiredError):
                return AgentError(
                    states=agent_states or [state],
                    error=e,
                    error_kind="oauth_expired",
                )
            # Re-raise other exceptions
            raise
        finally:
            self.agent_cancel_scope = None
        if agent_states and agent_states[-1].stop == StopReason.ABORTED:

            if agent_states[-1].session_id:
                self.session_id = agent_states[-1].session_id
                set_active_session_id(self.session_id)
                if self.status_line:
                    self.status_line.set_session_id(self.session_id)
            if self.escape_pressed:
                # Escape key - interrupted but can continue
                self.escape_pressed = False
                partial_response = None
                if self.renderer:
                    partial_response = self.renderer.get_partial_response()
                    self.renderer.finalize_partial_response()
                return AgentInterrupted(
                    states=agent_states,
                    partial_response=partial_response,
                )
            else:
                # Ctrl+C - exit entirely
                return AgentExited(states=agent_states)
        # Normal completion (TASK_COMPLETED, MAX_TURNS, or no stop reason)
        return AgentCompleted(states=agent_states)

    async def _handle_stream_event(self, event: StreamEvent) -> None:
        """Handle streaming event - render to TUI.
        Session persistence is handled by run_agent() via RunConfig.session_store.
        """
        if self.renderer:
            await self.renderer.handle_event(event)

    def _handle_sigint(self, signum: int, frame: FrameType | None) -> None:
        """Handle SIGINT (Ctrl+C) - cancel agent.
        Note: In raw terminal mode, SIGINT is not generated by Ctrl+C.
        Ctrl+C is handled as input data (ASCII 3) in the input_reading_loop.
        """
        self._exiting_via_ctrl_c = True
        if self.cancel_scope:
            self.cancel_scope.cancel()

    def _update_token_counts(self, state: AgentState) -> None:
        """Update status line with cumulative token counts and cost from trajectory."""
        import logging
        logger = logging.getLogger(__name__)
        if not self.status_line:
            logger.debug("_update_token_counts: no status_line")
            return
        total_input = 0
        total_output = 0
        total_cost = 0.0
        completions = state.actor.trajectory.completions
        logger.debug(f"_update_token_counts: {len(completions)} completions")
        for completion in completions:
            if completion.usage:
                logger.debug(
                    f"  usage: in={completion.usage.input_tokens} out={completion.usage.output_tokens} cost={completion.usage.cost.total}"
                )
                total_input += completion.usage.input_tokens + completion.usage.cache_read_tokens
                total_output += completion.usage.output_tokens + completion.usage.reasoning_tokens
                total_cost += completion.usage.cost.total
        logger.debug(
            f"_update_token_counts: setting tokens {total_input}/{total_output} cost={total_cost}"
        )
        self.status_line.set_tokens(total_input, total_output, total_cost)

    def _update_env_status_info(self) -> None:
        """Update status line with environment info."""
        if self.status_line and self.environment:
            if hasattr(self.environment, "get_status_info"):
                env_info = self.environment.get_status_info()
                if env_info:
                    self.status_line.set_env_info(env_info)

    async def run(self) -> list[AgentState]:
        """Run interactive agent loop.
        Returns:
            List of agent states from the run
        """
        self._setup_tui()
        agent_states: list[AgentState] = []
        try:
            agent_states = await self._run_agent_loop()
        finally:
            await self._cleanup_and_print_session(agent_states)
        return agent_states

    async def _run_agent_loop(self) -> list[AgentState]:
        """Main agent loop with explicit control flow.
        Two-phase loop:
        1. Get user input (handles slash commands, returns InputResult)
        2. Run agent (returns AgentOutcome)
        Both phases return explicit types instead of using flags.
        """
        self._queue.init_channels()
        if self.initial_prompt:
            self._queue.enqueue(self.initial_prompt)
        all_states: list[AgentState] = []
        state: AgentState | None = None
        async with trio.open_nursery() as nursery:
            self.cancel_scope = nursery.cancel_scope
            nursery.start_soon(self._input_reading_loop)
            nursery.start_soon(self.tui.run_animation_loop)
            if self.input_component and self.tui:
                self.tui.set_focus(self.input_component)
                self.tui.request_render()
            # ══════════════════════════════════════════════════════════════
            # MAIN LOOP - two phases: get input, run agent
            # ══════════════════════════════════════════════════════════════
            while True:
                # Refresh env status (target/accelerator) every iteration
                # so changes made mid-session are reflected immediately.
                self._update_env_status_info()
                # ─── PHASE 1: Get user input ──────────────────────────────
                input_result = await self._get_input_result(state)
                match input_result:
                    case InputMessage(text):
                        if state is None:
                            state = self._create_initial_state(text)
                        else:
                            state = self._add_user_message(state, text)
                # ─── PHASE 2: Run agent ───────────────────────────────────
                assert state is not None, "State must be set after InputMessage"
                self._ctrl_c_pending = False  # reset two-stage flag before each run
                outcome = await self._run_agent_with_outcome(state)
                all_states.extend(outcome.states)
                from dataclasses import replace as dc_replace
                match outcome:
                    case AgentCompleted(states):
                        # Normal completion - update state for next iteration
                        state = states[-1] if states else state
                        self._update_final_state(states)
                        if states and states[-1].stop == StopReason.TASK_COMPLETED:
                            # Show final answer if present
                            self._show_task_completed(states[-1])
                        # Always clear stop reason so next run continues
                        # (Interactive mode continues conversation after any completion)
                        state = dc_replace(state, stop=None)
                    case AgentInterrupted(states, _partial_response):
                        # User pressed Escape - show interrupt message and continue
                        state = states[-1] if states else state
                        if self.renderer:
                            self.renderer.add_system_message("Interrupted")
                        if self.tui:
                            self.tui.hide_loader()
                        self._update_final_state(states)
                        # Clear stop reason so next run continues
                        state = dc_replace(state, stop=None)
                        # Loop back to get next input
                    case AgentExited(states):
                        # User pressed Ctrl+C - exit the loop
                        self._update_final_state(states)
                        break
                    case AgentError(states, error, error_kind):
                        # Recoverable error - show message and continue
                        state = states[-1] if states else state
                        self._show_agent_error(error, error_kind)
                        # Clear stop reason so next run continues
                        state = dc_replace(state, stop=None)
                        # Loop back to get next input

        if all_states and all_states[-1].session_id:
            self.session_id = all_states[-1].session_id
            set_active_session_id(self.session_id)

            if self.status_line:
                self.status_line.set_session_id(self.session_id)
                if self.tui:
                    self.tui.request_render()
        return all_states

    def _add_user_message(self, state: AgentState, text: str) -> AgentState:
        """Add a user message to the agent state."""
        from dataclasses import replace as dc_replace
        new_messages = state.actor.trajectory.messages + [Message(role="user", content=text)]
        new_trajectory = Trajectory(messages=new_messages)
        return dc_replace(
            state,
            actor=dc_replace(state.actor, trajectory=new_trajectory),
        )

    def _show_task_completed(self, state: AgentState) -> None:
        """Show task completion UI if there's a final answer."""
        if state.environment and hasattr(state.environment, "_final_answer"):
            final_answer = getattr(state.environment, "_final_answer", None)
            if final_answer and self.renderer:
                self.renderer.add_final_answer(final_answer)
                if self.tui:
                    self.tui.request_render()

    def _show_agent_error(self, error: Exception, error_kind: str) -> None:
        """Show error message for recoverable agent errors."""
        if self.tui:
            self.tui.hide_loader()
        if error_kind == "context_too_long":
            from ...providers.base import ContextTooLongError
            error_msg = "[warn] Context too long"
            if isinstance(error, ContextTooLongError):
                if error.current_tokens and error.max_tokens:
                    error_msg += f" ({error.current_tokens:,} tokens, max {error.max_tokens:,})"
            if self.renderer:
                self.renderer.add_system_message(
                    f"{error_msg}\n\n"
                    "The conversation has grown too long for the model's context window.\n"
                    "Please start a new conversation."
                )
        elif error_kind == "oauth_expired":
            if self.renderer:
                self.renderer.add_system_message(
                    "OAuth token expired and refresh failed. Please re-authenticate."
                )
        else:
            if self.renderer:
                self.renderer.add_system_message(f"Error: {error}")
        if self.tui:
            self.tui.request_render()

    async def _input_reading_loop(self) -> None:
        """Read terminal input and route to TUI."""
        while True:  # noqa: PLR1702
            if self.terminal and self.terminal._running:
                input_data = self.terminal.read_input()
                if input_data:
                    if len(input_data) > 0 and ord(input_data[0]) == 3:
                        now = _time.monotonic()
                        # Two-stage Ctrl+C: first press cancels agent, second exits.
                        if self.agent_cancel_scope and not self._ctrl_c_pending:
                            self._ctrl_c_pending = True
                            self._ctrl_c_time = now
                            self.escape_pressed = True
                            self.agent_cancel_scope.cancel()
                            if self.renderer:
                                self.renderer.add_system_message(
                                    "Interrupted — press Ctrl+C again to exit"
                                )
                            if self.tui:
                                self.tui.show_loader(
                                    "Interrupting...",
                                    spinner_color_fn=self.tui.theme.accent_fg,
                                    text_color_fn=self.tui.theme.accent_fg,
                                )
                                self.tui.request_render()
                            continue
                        # Second Ctrl+C (or no active agent run, or window expired)
                        self._exiting_via_ctrl_c = True
                        if self.cancel_scope:
                            self.cancel_scope.cancel()
                        return
                    # Only handle when input is empty (not while typing)
                    if input_data in ("+", "=") and self.input_component:
                        if not self.input_component.get_text().strip():
                            self._increase_detail_level()
                            continue
                    if input_data == "-" and self.input_component:
                        if not self.input_component.get_text().strip():
                            self._decrease_detail_level()
                            continue
                    # But if there's a focused component that handles escape (like question selector),
                    # route escape to it instead. The Input component doesn't handle escape,
                    # so we skip routing to it to allow the interrupt to work.
                    if input_data == "\x1b":
                        if (
                            self.tui
                            and self.tui._focused_component is not None
                            and self.tui._focused_component is not self.input_component
                        ):
                            self.tui._handle_input(input_data)
                            continue
                        # Esc with queued messages: clear queue first
                        if self._queue.pending() > 0:
                            cleared = self._queue.clear()
                            if self.input_component:
                                for _ in cleared:
                                    self.input_component.pop_queued_message()
                            if self.renderer:
                                self.renderer.add_system_message(
                                    f"Cleared {len(cleared)} queued message(s)"
                                )
                            if self.tui:
                                self.tui.request_render()
                            continue
                        # Queue empty: interrupt agent
                        if self.agent_cancel_scope:
                            self.escape_pressed = True
                            self.agent_cancel_scope.cancel()
                            if self.tui:
                                self.tui.show_loader(
                                    "Interrupting...",
                                    spinner_color_fn=self.tui.theme.accent_fg,
                                    text_color_fn=self.tui.theme.accent_fg,
                                )
                                self.tui.request_render()
                        else:
                            if self.renderer:
                                self.renderer.add_system_message(
                                    "Nothing to interrupt (no active operation)"
                                )
                            if self.tui:
                                self.tui.request_render()
                        continue
                    if self.tui:
                        self.tui._handle_input(input_data)
            await trio.sleep(0.01)

    def _update_final_state(self, agent_states: list[AgentState]) -> None:
        """Update session_id and token counts from final agent state."""
        if not agent_states:
            return
        final_state = agent_states[-1]
        if final_state.session_id and final_state.session_id != self.session_id:
            self.session_id = final_state.session_id
            set_active_session_id(self.session_id)
            if self.status_line:
                self.status_line.set_session_id(self.session_id)
            self._update_env_status_info()
        if self.status_line and self.tui:
            self._update_token_counts(final_state)
            self.tui.request_render()

    def _handle_stop(self, state: AgentState) -> AgentState:
        """Handle stop condition. No max turns limit in interactive mode."""
        return state

    def _setup_tui(self) -> None:
        """Initialize terminal, TUI, and all UI components."""
        from .components.status_line import StatusLine
        from .theme import DARK_THEME, MINIMAL_THEME, ROUNDED_THEME
        if self.theme_name == "rounded":
            theme = ROUNDED_THEME
        elif self.theme_name == "minimal":
            theme = MINIMAL_THEME
        else:
            theme = DARK_THEME
        self.terminal = ProcessTerminal()
        self.tui = TUI(self.terminal, theme=theme, debug=self.debug, debug_layout=self.debug_layout)
        self.renderer = AgentRenderer(
            self.tui, environment=self.environment, debug_layout=self.debug_layout
        )
        # Render history from initial trajectory (for resumed sessions)
        has_history = any(m.role == "user" for m in self.initial_trajectory.messages)
        if has_history:
            self.renderer.render_history(self.initial_trajectory.messages, skip_system=False)
            self.is_first_user_message = False
            if self.debug:
                self.renderer.debug_dump_chat()
        else:
            # New session - show welcome banner with context
            import os
            import subprocess
            from pathlib import Path
            from ... import __version__

            # Shorten working dir with ~ for home
            cwd = os.getcwd()
            home = str(Path.home())
            if cwd.startswith(home):
                cwd = "~" + cwd[len(home):]

            # Get git branch (None if not in a repo)
            git_branch = None
            try:
                result = subprocess.run(
                    ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                    capture_output=True,
                    text=True,
                    timeout=2,
                )
                if result.returncode == 0:
                    git_branch = result.stdout.strip()
            except Exception:
                pass

            self.renderer.add_welcome_banner(
                title="Wafer Agent",
                version=__version__,
                working_dir=cwd,
                git_branch=git_branch,
                model=None,
            )
        self.loader_container = LoaderContainer(
            spinner_color_fn=self.tui.theme.accent_fg,
            text_color_fn=self.tui.theme.muted_fg,
        )
        self.tui.set_loader_container(self.loader_container)
        self.tui.add_child(self.loader_container)
        # Spacer before input box (always present)
        self.tui.add_child(Spacer(1, debug_label="before-input"))
        self.input_component = Input(theme=self.tui.theme)
        input_cwd = (
            self.environment.working_dir
            if self.environment and hasattr(self.environment, "working_dir")
            else Path.cwd()
        )
        self.input_component.set_cwd(input_cwd)
        self.input_component.set_on_submit(self._handle_input_submit)
        self.input_component.set_on_editor(self._handle_open_editor)
        self.input_component.set_on_tab_complete(self._handle_tab_complete)
        self.input_component.set_on_change(self._handle_input_change)
        self.tui.add_child(self.input_component)
        self.status_line = StatusLine(theme=self.tui.theme)
        self.status_line.set_session_id(self.session_id)
        model_meta = get_model(self.endpoint.provider, self.endpoint.model)  # type: ignore[arg-type]
        context_window = model_meta.context_window if model_meta else None
        self.status_line._context_window = context_window
        if self.environment and hasattr(self.environment, "get_status_info"):
            env_info = self.environment.get_status_info()
            if env_info:
                self.status_line.set_env_info(env_info)
        self.tui.add_child(self.status_line)
        self.tui.add_child(Spacer(3, debug_label="after-status"))

        signal.signal(signal.SIGINT, self._handle_sigint)
        # Start TUI
        self.tui.start()

    def _create_initial_state(self, first_message: str) -> AgentState:
        """Create initial agent state with first user message."""
        initial_trajectory_with_user = Trajectory(
            messages=self.initial_trajectory.messages
            + [Message(role="user", content=first_message)]
        )
        return AgentState(
            actor=Actor(
                trajectory=initial_trajectory_with_user,
                endpoint=self.endpoint,
                tools=self.environment.get_tools() if self.environment else [],
            ),
            environment=self.environment,
            session_id=self.session_id,
            parent_session_id=self.parent_session_id,
            branch_point=self.branch_point,
            confirm_tools=self.confirm_tools,
        )

    def _create_run_config(self) -> RunConfig:
        """Create RunConfig with all handlers."""
        async def auto_confirm_tool(
            tc: ToolCall, state: AgentState, rcfg: RunConfig
        ) -> tuple[AgentState, ToolConfirmResult]:
            return state, ToolConfirmResult(proceed=True)

        async def confirm_tool_tui(
            tc: ToolCall, state: AgentState, rcfg: RunConfig
        ) -> tuple[AgentState, ToolConfirmResult]:
            """Interactive tool confirmation in TUI."""
            if self.renderer:
                self.renderer.add_system_message(
                    f"[warn] Tool: {tc.name}({tc.args})\n   [y] execute  [n] reject  [s] skip"
                )
            resp = await rcfg.on_input("Confirm tool? ")
            resp = resp.strip().lower()
            if resp in ("y", "yes", ""):
                return state, ToolConfirmResult(proceed=True)
            elif resp in ("n", "no"):
                feedback = await rcfg.on_input("Feedback for LLM: ")
                return state, ToolConfirmResult(
                    proceed=False,
                    tool_result=ToolResult(
                        tool_call_id=tc.id, is_error=True, error="Rejected by user"
                    ),
                    user_message=feedback.strip() if feedback.strip() else None,
                )
            else:
                return state, ToolConfirmResult(
                    proceed=False,
                    tool_result=ToolResult(
                        tool_call_id=tc.id, is_error=True, error="Skipped by user"
                    ),
                )

        async def handle_no_tool_interactive(state: AgentState, rcfg: RunConfig) -> AgentState:
            """Signal that agent needs user input - return immediately without blocking.
            Instead of blocking here to wait for input, we return with NEEDS_INPUT
            so the outer loop can handle input gathering in one place.
            """
            from dataclasses import replace as dc_replace

            if state.session_id and state.session_id != self.session_id:
                self.session_id = state.session_id
                set_active_session_id(self.session_id)
                if self.status_line:
                    self.status_line.set_session_id(self.session_id)
            self._update_token_counts(state)
            if self.tui:
                self.tui.request_render()
            return dc_replace(state, stop=StopReason.NEEDS_INPUT)
        confirm_handler = confirm_tool_tui if self.confirm_tools else auto_confirm_tool
        return RunConfig(
            on_chunk=self._handle_stream_event,
            on_input=self._tui_input_handler,
            confirm_tool=confirm_handler,
            handle_stop=self._handle_stop,
            handle_no_tool=handle_no_tool_interactive,
            session_store=self.session_store,
            cancel_scope=self.agent_cancel_scope,
        )

    # NOTE: Old handler methods (_handle_agent_interrupt, _handle_task_completed,
    # _handle_context_too_long) were removed. The new _run_agent_loop handles these
    # cases via the AgentOutcome match statement in a cleaner way.
    async def _handle_oauth_expired(
        self, error: Exception, current_state: AgentState
    ) -> AgentState:
        """Handle OAuth token expiration gracefully.
        Shows an error message and prompts user to re-login via /login command.
        After login, retries the last user message.
        """
        if self.tui:
            self.tui.hide_loader()
        # Display error message with login instructions
        if self.renderer:
            self.renderer.add_system_message(
                "OAuth token expired and refresh failed. Please re-authenticate."
            )
            if self.tui:
                self.tui.request_render()
        _ = await self._tui_input_handler("Continue: ")
        # so when they re-authenticate and hit enter, it will retry
        return current_state

    async def _cleanup_and_print_session(self, agent_states: list[AgentState]) -> None:
        """Stop TUI and print session info. Skips exit survey on Ctrl+C for fast exit."""
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        if self.tui:
            self.tui.stop()
        if self.terminal:
            self.terminal.stop()
        sys.stdout.flush()
        if agent_states and not self._exiting_via_ctrl_c:
            final_state = agent_states[-1]
            exit_reason = "unknown"
            if final_state.stop:
                exit_reason = str(final_state.stop).split(".")[-1].lower()
            try:
                from ...feedback import run_exit_survey
                await run_exit_survey(
                    final_state,
                    self.endpoint,
                    exit_reason,
                    session_id=self.session_id,
                    skip_check=True,
                )
            except Exception:
                pass
        if self.session_id:
            print(f"\nResume: --session {self.session_id}")
            set_active_session_id(None)
        signal.signal(signal.SIGINT, signal.SIG_DFL)


async def run_interactive_agent(
    initial_trajectory: Trajectory,
    endpoint: Endpoint,
    environment: Environment | None = None,
    session_store: SessionStore | None = None,
    session_id: str | None = None,
    theme_name: str = "dark",
    debug: bool = False,
    debug_layout: bool = False,
    parent_session_id: str | None = None,
    branch_point: int | None = None,
    confirm_tools: bool = False,
    initial_prompt: str | None = None,
) -> list[AgentState]:
    """Run an interactive agent with TUI.
    Args:
        initial_trajectory: Initial conversation trajectory
        endpoint: LLM endpoint configuration
        environment: Optional environment for tool execution
        session_store: Optional session store for persistence
        session_id: Optional session ID (required if session_store is set)
        theme_name: Theme name (dark or rounded)
        debug: Enable debug logging and chat state dumps
        debug_layout: Show component boundaries and spacing
        parent_session_id: Parent session ID when forking
        branch_point: Message index where forking from parent
        confirm_tools: Require confirmation before executing tools
        initial_prompt: Optional initial prompt to send immediately
    Returns:
        List of agent states from the run
    """
    runner = InteractiveAgentRunner(
        initial_trajectory=initial_trajectory,
        endpoint=endpoint,
        environment=environment,
        session_store=session_store,
        session_id=session_id,
        theme_name=theme_name,
        debug=debug,
        debug_layout=debug_layout,
        parent_session_id=parent_session_id,
        branch_point=branch_point,
        confirm_tools=confirm_tools,
        initial_prompt=initial_prompt,
    )
    return await runner.run()
