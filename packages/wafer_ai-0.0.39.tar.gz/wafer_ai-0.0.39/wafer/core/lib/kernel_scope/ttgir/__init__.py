"""TTGIR (Triton GPU IR) parsing and analysis.

Parses Triton's GPU-specific intermediate representation to extract
tiling strategy, memory layout decisions, and block dimensions.
"""

from wafer.core.lib.kernel_scope.ttgir.analyzer import TTGIRAnalysis, analyze_ttgir
from wafer.core.lib.kernel_scope.ttgir.parser import parse_ttgir_file, parse_ttgir_text
from wafer.core.lib.kernel_scope.ttgir.types import TritonOperation, TTGIRParseResult

__all__ = [
    "parse_ttgir_file",
    "parse_ttgir_text",
    "analyze_ttgir",
    "TTGIRAnalysis",
    "TTGIRParseResult",
    "TritonOperation",
]
