"""Subagent tool: delegate tasks to Claude, Codex, or wafer-api subagents.

Spawns a named subagent (configured in agent TOML) as a subprocess or
streams from the wafer API. Returns final text as ToolResult.
"""
from __future__ import annotations

import shutil
import subprocess
import time
from collections.abc import Awaitable, Callable
from pathlib import Path

import trio

from wafer.cli.agent_config import SubagentConfig
from wafer.core.rollouts.cli_commands import build_claude_cli_args, build_codex_cli_args
from wafer.core.rollouts.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
    ToolResultDelta,
)
from wafer.core.rollouts.parsers import extract_text_from_claude_stream, extract_text_from_codex_stream

SUBAGENT_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="subagent",
        description=(
            "Delegate a task to a named subagent. Subagents are configured "
            "in the agent TOML under [subagents.*]. Use 'plan' subagents for "
            "analysis/planning (read-only) and 'execute' subagents for focused implementation."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "agent": {"type": "string", "description": "Name of the subagent (from config)"},
                "prompt": {"type": "string", "description": "Task for the subagent"},
            },
        ),
        required=["agent", "prompt"],
    ),
)


async def exec_subagent(
    tool_call: ToolCall,
    working_dir: Path,
    subagent_configs: dict[str, SubagentConfig],
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None = None,
    *,
    api_url: str | None = None,
    auth_token: str | None = None,
) -> ToolResult:
    """Execute a named subagent as a subprocess or via wafer API."""
    agent_name = tool_call.args.get("agent", "")
    prompt = tool_call.args.get("prompt", "")
    assert agent_name, "subagent 'agent' argument is required"
    assert prompt, "subagent 'prompt' argument is required"

    config = subagent_configs.get(agent_name)
    assert config is not None, (
        f"Unknown subagent '{agent_name}'. "
        f"Available: {sorted(subagent_configs.keys()) if subagent_configs else '(none)'}"
    )

    if config.backend == "wafer-api":
        return await _exec_wafer_api_subagent(
            tool_call, config, prompt, on_output,
            api_url=api_url, auth_token=auth_token,
        )

    binary = "claude" if config.backend == "claude" else "codex"
    assert shutil.which(binary), f"'{binary}' CLI not found on PATH. Install it to use {config.backend} subagents."

    if config.backend == "claude":
        cmd = build_claude_cli_args(
            prompt,
            model=config.model,
            allowed_tools=config.allowed_tools,
        )
    else:
        cmd = build_codex_cli_args(
            prompt,
            model=config.model,
            sandbox=config.sandbox,
        )

    start = time.perf_counter()
    raw_chunks: list[str] = []

    process = await trio.lowlevel.open_process(
        cmd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(working_dir),
    )

    try:
        with trio.move_on_after(config.timeout) as cancel_scope:
            assert process.stdout is not None
            buf = ""
            async for chunk in process.stdout:
                text = chunk.decode("utf-8", errors="replace")
                raw_chunks.append(text)
                buf += text
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    if on_output and line.strip():
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=line + "\n",
                        ))

        if cancel_scope.cancelled_caught:
            process.kill()
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Subagent '{agent_name}' timed out after {config.timeout}s",
            )

        await process.wait()
    except Exception as e:
        process.kill()
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Subagent '{agent_name}' failed: {e}",
        )

    duration = time.perf_counter() - start
    raw_output = "".join(raw_chunks)

    if process.returncode != 0:
        stderr_bytes = b""
        if process.stderr:
            stderr_bytes = await process.stderr.receive_some(65536)
        stderr_text = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Subagent '{agent_name}' exited {process.returncode} ({duration:.1f}s): {stderr_text[:500]}",
        )

    if config.backend == "claude":
        result_text = extract_text_from_claude_stream(raw_output)
    else:
        result_text = extract_text_from_codex_stream(raw_output)

    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=result_text,
    )


async def _exec_wafer_api_subagent(
    tool_call: ToolCall,
    config: SubagentConfig,
    prompt: str,
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None,
    *,
    api_url: str | None,
    auth_token: str | None,
) -> ToolResult:
    """Execute a subagent via the wafer API (POST /v1/cloud-agent/run)."""
    assert api_url, "api_url is required for wafer-api subagent backend"
    assert auth_token, "auth_token is required for wafer-api subagent backend"
    assert config.config, "SubagentConfig.config (template name) is required for wafer-api backend"

    from wafer.core.api_client import WaferApiError, stream_wafer_api

    body = {
        "prompt": prompt,
        "config": config.config,
        "mode": "empty",
    }

    text_chunks: list[str] = []
    try:
        async for event in stream_wafer_api(
            api_url=api_url,
            auth_token=auth_token,
            endpoint="/v1/cloud-agent/run",
            body=body,
        ):
            if event.event_type == "text_delta":
                text = event.data.get("text", "")
                if text:
                    text_chunks.append(text)
                    if on_output:
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=text,
                        ))
            elif event.event_type == "error":
                error_msg = event.data.get("error", "Unknown error from wafer API")
                return ToolResult(
                    tool_call_id=tool_call.id,
                    is_error=True,
                    content="",
                    error=error_msg,
                )
    except WaferApiError as e:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=str(e),
        )

    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content="".join(text_chunks),
    )
