"""Sandbox tool: run commands, read files, write files, and send interactive input on the remote GPU machine."""
from __future__ import annotations

from collections.abc import Awaitable, Callable

import trio

from wafer.core.rollouts.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)
from wafer.core.sandbox.session import HARD_TIMEOUT_EXIT_CODE, IDLE_EXIT_CODE, SandboxSession
from wafer.core.tools._output import truncate_output

OnOutputCallback = Callable[[str], Awaitable[None]]

SANDBOX_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="sandbox",
        description=(
            "Interact with a remote accelerator machine. Four operations:\n"
            " - Run a command: set 'command'\n"
            " - Write a file: set 'write_path' and 'content'\n"
            " - Read a file: set 'read_path'\n"
            " - Send input to a running command: set 'input' (e.g. 'Y', 'C-c', 'C-z')\n"
            "Optionally set 'target' to specify which target machine to use "
            "(defaults to the default target). Each target gets its own persistent session.\n"
            "Environment variables set with 'export' persist across commands."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "command": {
                    "type": "string",
                    "description": "Command to run on the remote machine. Use && to chain commands.",
                },
                "input": {
                    "type": "string",
                    "description": (
                        "Send input to a running command (e.g. 'Y', 'C-c', 'C-z'). "
                        "Use after a command returns idle to respond to prompts or kill hung processes."
                    ),
                },
                "timeout": {
                    "type": "integer",
                    "description": "Hard timeout in seconds (default: 180)",
                },
                "no_change_timeout": {
                    "type": "integer",
                    "description": (
                        "Seconds to wait with no new output before returning idle (default: 30). "
                        "Set to 0 to disable idle detection. Set higher for slow compilations."
                    ),
                },
                "target": {
                    "type": "string",
                    "description": "Target name to run on (e.g. 'mi300x', 'trn2'). Defaults to the default target.",
                },
                "read_path": {
                    "type": "string",
                    "description": "Remote file path to read (e.g. '~/gemm/kernel.cu'). Returns the file content.",
                },
                "write_path": {
                    "type": "string",
                    "description": "Remote file path to write content to (e.g. '~/gemm/kernel.cu'). Use with content.",
                },
                "content": {
                    "type": "string",
                    "description": "File content to write to write_path. Transferred via SSH, works for any size.",
                },
                "upload_path": {
                    "type": "string",
                    "description": "Alias for write_path (backward compat). Remote file path to write content to.",
                },
                "upload_content": {
                    "type": "string",
                    "description": "Alias for content (backward compat). File content to write to upload_path.",
                },
            },
        ),
        required=[],
    ),
)


async def _resolve_remote_path(session: SandboxSession, path: str) -> str:
    """Resolve ~ to $HOME on the remote machine."""
    assert session._client is not None, "SandboxSession not started"
    if path.startswith("~"):
        home_result = await session._client.exec("printf '%s' \"$HOME\"")
        home = home_result.stdout.strip()
        assert home, "failed to resolve $HOME on remote"
        return home + path[1:]
    return path


def format_observation(
    output: str,
    exit_code: int,
    metadata: dict,
    session: SandboxSession,
    no_change_timeout: int = 30,
) -> str:
    """Format command output with sandbox context header and exit status footer."""
    sandbox_id = session._sandbox.id
    target = session._sandbox.target_name
    cwd = metadata.get("cwd", "unknown")

    header = f"[sandbox: {sandbox_id} | target: {target} | cwd: {cwd}]"

    if exit_code == IDLE_EXIT_CODE:
        footer = (
            f"\n[command idle for {no_change_timeout}s -- "
            f'send input with sandbox(input="Y") or kill with sandbox(input="C-c")]'
        )
    elif exit_code == HARD_TIMEOUT_EXIT_CODE:
        footer = "\n[command timed out]"
    else:
        footer = f"\n[exit code: {exit_code}]"

    return f"{header}\n{output}{footer}"


async def exec_sandbox(
    tool_call: ToolCall,
    session: SandboxSession,
    on_output: OnOutputCallback | None = None,
) -> ToolResult:
    """Execute sandbox tool call. Returns ToolResult."""
    input_text = tool_call.args.get("input")
    if input_text:
        return await _handle_input(tool_call, session, input_text)

    read_path = tool_call.args.get("read_path")
    if read_path:
        return await _handle_read(tool_call, session, read_path)

    write_path = tool_call.args.get("write_path") or tool_call.args.get("upload_path")
    write_content = tool_call.args.get("content") if tool_call.args.get("write_path") else tool_call.args.get("upload_content")
    if write_content is None:
        write_content = tool_call.args.get("upload_content")

    if write_path and write_content is not None:
        return await _handle_upload(tool_call, session, write_path, write_content)

    command = tool_call.args.get("command", "")
    if not command:
        error_msg = "sandbox requires 'command', 'input', 'read_path', or 'write_path'+'content'"
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=error_msg,
            error=error_msg,
        )

    timeout = tool_call.args.get("timeout", 180)
    no_change_timeout = tool_call.args.get("no_change_timeout", 30)
    output, exit_code, metadata = await session.run_command(
        command, timeout, no_change_timeout=no_change_timeout, on_output=on_output,
    )
    output = truncate_output(output)
    observation = format_observation(output, exit_code, metadata, session, no_change_timeout)

    if exit_code == HARD_TIMEOUT_EXIT_CODE:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=observation,
            error=f"Command timed out after {timeout} seconds",
        )
    if exit_code == IDLE_EXIT_CODE:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=False,
            content=observation,
        )
    if exit_code != 0:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=observation,
            error=f"Command exited with code {exit_code}",
        )
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=observation if output else format_observation("(no output)", exit_code, metadata, session),
    )


async def _handle_input(
    tool_call: ToolCall,
    session: SandboxSession,
    input_text: str,
) -> ToolResult:
    """Send interactive input to a running command in the sandbox."""
    await session.send_input(input_text)
    await trio.sleep(0.5)
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=f"Sent input: {input_text!r}",
    )


async def _handle_read(
    tool_call: ToolCall,
    session: SandboxSession,
    read_path: str,
) -> ToolResult:
    """Read file content from sandbox via SSH exec."""
    assert session._client is not None, "SandboxSession not started"
    import shlex as _shlex

    from wafer.core.async_ssh import _trio_wrap

    resolved_path = await _resolve_remote_path(session, read_path)
    conn = await session._client._get_connection()
    result = await _trio_wrap(conn.run)(f"cat {_shlex.quote(resolved_path)}", check=False)
    exit_code = result.exit_status or 0
    if exit_code != 0:
        error_msg = f"Failed to read {read_path}: file not found or not readable"
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=error_msg,
            error=error_msg,
        )
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=truncate_output(result.stdout or ""),
    )


async def _handle_upload(
    tool_call: ToolCall,
    session: SandboxSession,
    upload_path: str,
    upload_content: str,
) -> ToolResult:
    """Upload file content to sandbox via SSH exec with stdin piping."""
    assert session._client is not None, "SandboxSession not started"
    import shlex as _shlex

    from wafer.core.async_ssh import _trio_wrap

    resolved_path = await _resolve_remote_path(session, upload_path)

    parent_dir = "/".join(resolved_path.rsplit("/", 1)[:-1])
    if parent_dir:
        await session._client.exec(f"mkdir -p {_shlex.quote(parent_dir)}")

    conn = await session._client._get_connection()
    write_cmd = f"cat > {_shlex.quote(resolved_path)}"
    result = await _trio_wrap(conn.run)(write_cmd, input=upload_content, check=False)
    exit_code = result.exit_status or 0
    if exit_code != 0:
        stderr = result.stderr or ""
        error_msg = f"Upload failed (exit {exit_code}): {stderr}"
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=error_msg,
            error=error_msg,
        )

    byte_count = len(upload_content.encode("utf-8"))
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=f"Uploaded {byte_count} bytes to {resolved_path}",
    )
