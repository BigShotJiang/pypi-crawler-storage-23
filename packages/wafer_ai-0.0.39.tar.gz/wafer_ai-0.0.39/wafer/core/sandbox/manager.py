"""Stateless lifecycle functions for sandboxes. Used by CLI and agent environment."""
from __future__ import annotations

import shlex
from datetime import datetime, timezone
from uuid import uuid4

from wafer.core.async_ssh import AsyncSSHClient
from wafer.core.sandbox.types import Sandbox


DEFAULT_TIMEOUT_HOURS = 4
MIN_TIMEOUT_HOURS = 1
MAX_SANDBOXES = 5


def create_sandbox(
    target_name: str,
    ssh_target: str,
    ssh_key: str,
    timeout_hours: int = DEFAULT_TIMEOUT_HOURS,
) -> Sandbox:
    """Generate Sandbox dataclass. Does NOT start tmux - SandboxSession.start() does that.
    timeout_hours is clamped to at least MIN_TIMEOUT_HOURS to ensure auto-destruct always runs.
    """
    assert isinstance(timeout_hours, int), "timeout_hours must be int"
    timeout_hours = max(MIN_TIMEOUT_HOURS, timeout_hours)
    suffix = uuid4().hex[:8]
    sandbox_id = f"sandbox-{suffix}"
    tmux_session = f"wafer-{sandbox_id}"
    created_at = datetime.now(timezone.utc).isoformat()
    return Sandbox(
        id=sandbox_id,
        target_name=target_name,
        tmux_session=tmux_session,
        ssh_target=ssh_target,
        ssh_key=ssh_key,
        created_at=created_at,
        timeout_hours=timeout_hours,
    )


async def list_sandboxes(ssh_target: str, ssh_key: str) -> list[str]:
    """List wafer sandbox tmux sessions on the target."""
    async with AsyncSSHClient(ssh_target, ssh_key) as client:
        result = await client.exec(
            "tmux list-sessions -F '#{session_name}' 2>/dev/null | grep wafer-sandbox- || true"
        )
        lines = (result.stdout or "").strip().splitlines()
        return [line.strip() for line in lines if line.strip()]


async def destroy_sandbox(
    ssh_target: str,
    ssh_key: str,
    tmux_session: str,
) -> None:
    """Kill a sandbox tmux session, its destroy-timer process, and its temp dir."""
    async with AsyncSSHClient(ssh_target, ssh_key) as client:
        await _destroy_sandbox_on(client, tmux_session)


async def _destroy_sandbox_on(client: AsyncSSHClient, tmux_session: str) -> None:
    """Core destroy logic using an existing SSH client. Kills session, timer, and temp dir."""
    quoted = shlex.quote(tmux_session)
    tmp_dir = f"/tmp/.wafer_sandbox/{tmux_session}"
    pid_file = f"{tmp_dir}/destroy.pid"
    # Kill the destroy-timer by PID (precise, avoids killing other sandboxes' timers)
    pid_result = await client.exec(f"cat {pid_file} 2>/dev/null")
    if pid_result.exit_code == 0 and pid_result.stdout.strip():
        await client.exec(f"kill {pid_result.stdout.strip()} 2>/dev/null || true")
    await client.exec(f"tmux kill-session -t {quoted} 2>/dev/null || true")
    await client.exec(f"rm -rf {tmp_dir} 2>/dev/null || true")


async def destroy_all_sandboxes(ssh_target: str, ssh_key: str) -> int:
    """List and destroy all wafer-sandbox-* sessions. Uses a single SSH connection."""
    async with AsyncSSHClient(ssh_target, ssh_key) as client:
        result = await client.exec(
            "tmux list-sessions -F '#{session_name}' 2>/dev/null | grep wafer-sandbox- || true"
        )
        lines = (result.stdout or "").strip().splitlines()
        sessions = [line.strip() for line in lines if line.strip()]
        for session in sessions:
            await _destroy_sandbox_on(client, session)
        return len(sessions)
