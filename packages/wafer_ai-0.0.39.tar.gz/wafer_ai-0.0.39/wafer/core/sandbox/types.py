"""Sandbox types. A sandbox is a tmux session on a remote GPU machine."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Sandbox:
    """A sandbox is a persistent tmux session on a target machine."""

    id: str  # "sandbox-a1b2c3d4" (8-char hex suffix)
    target_name: str  # which target this runs on
    tmux_session: str  # "wafer-sandbox-a1b2c3d4"
    ssh_target: str  # "user@host:port"
    ssh_key: str  # path to SSH key
    created_at: str  # ISO timestamp
    timeout_hours: int  # self-destruct timer (default 4)
