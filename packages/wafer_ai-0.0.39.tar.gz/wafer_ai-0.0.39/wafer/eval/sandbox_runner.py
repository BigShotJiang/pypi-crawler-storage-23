"""Run commands on a remote GPU sandbox from within eval scorers.

Usage in a custom scorer.py:

    from pathlib import Path
    from wafer.eval import Score, Metric
    from wafer.eval.sandbox_runner import sandbox_run

    async def score(work_dir: Path) -> Score:
        output = await sandbox_run(
            "cd solution && nvcc -O3 gemm.cu -o gemm -lcublas && ./gemm",
            sync_path=work_dir,
        )
        # Parse output, return Score
        ...

When sync_path is provided, the local directory is synced to /tmp/<dirname>
on the remote before the command runs. No manual upload needed.
"""
from __future__ import annotations

import asyncio
from pathlib import Path


async def sandbox_run(
    command: str,
    *,
    target: str | None = None,
    timeout: int = 300,
    sync_path: str | Path | None = None,
) -> str:
    """Execute a command on the remote sandbox and return its stdout.

    Uses `wafer sandbox run` under the hood. When sync_path is provided,
    syncs the local directory to /tmp/<dirname> on the remote before running;
    the command runs with that directory as cwd.
    """
    assert command, "command must not be empty"

    cli_args = ["wafer", "sandbox", "run"]
    if target:
        cli_args.extend(["--target", target])
    if sync_path is not None:
        path = Path(sync_path).resolve()
        assert path.is_dir(), f"sync_path must be a directory: {path}"
        cli_args.extend(["--sync", str(path)])
    cli_args.extend(["--timeout-sec", str(timeout), "--", command])

    proc = await asyncio.create_subprocess_exec(
        *cli_args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_bytes, stderr_bytes = await proc.communicate()
    stdout = stdout_bytes.decode(errors="replace")
    stderr = stderr_bytes.decode(errors="replace")

    if proc.returncode != 0:
        detail = stderr.strip() or stdout.strip() or "(no output)"
        raise RuntimeError(
            f"sandbox command failed (exit {proc.returncode}): {detail}"
        )

    return stdout


async def sandbox_run_all(
    commands: list[str],
    *,
    target: str | None = None,
    timeout: int = 300,
) -> list[str]:
    """Run multiple commands sequentially on the sandbox, return all outputs."""
    assert commands, "commands must not be empty"
    results: list[str] = []
    for cmd in commands:
        out = await sandbox_run(cmd, target=target, timeout=timeout)
        results.append(out)
    return results
