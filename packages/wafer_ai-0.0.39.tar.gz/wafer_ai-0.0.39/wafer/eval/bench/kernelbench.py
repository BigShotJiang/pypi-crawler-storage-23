"""KernelBench bench script.

Runs in a directory containing impl.py (ModelNew) and ref.py (Model + get_inputs + get_init_inputs).
Outputs JSON with: correct, speedup, runtime_ms, reference_runtime_ms, error.

Usage: python -m wafer.eval.bench.kernelbench [--benchmark] [--seed 42] [--num-trials 10]
"""
from __future__ import annotations

import argparse
import gc
import importlib.util
import json
import os
import statistics
import sys
import uuid
from pathlib import Path

unique_cache_dir = f"/tmp/torch_extensions_{uuid.uuid4().hex[:8]}"
os.environ["TORCH_EXTENSIONS_DIR"] = unique_cache_dir


def _load_module(path: Path, name: str) -> object:
    """Load a Python module from a file path."""
    assert path.exists(), f"File not found: {path}"
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None, f"Cannot create module spec from {path}"
    assert spec.loader is not None, f"Module spec has no loader: {path}"
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _calculate_timing_stats(times: list[float]) -> dict:
    """Calculate median and IQR from timing samples."""
    assert len(times) > 0, "times must be non-empty"
    sorted_times = sorted(times)
    n = len(sorted_times)
    median = statistics.median(sorted_times)
    q1_idx = (n - 1) * 0.25
    q3_idx = (n - 1) * 0.75
    q1_low = int(q1_idx)
    q1_frac = q1_idx - q1_low
    iqr_low = sorted_times[q1_low] * (1 - q1_frac) + sorted_times[min(q1_low + 1, n - 1)] * q1_frac
    q3_low = int(q3_idx)
    q3_frac = q3_idx - q3_low
    iqr_high = sorted_times[q3_low] * (1 - q3_frac) + sorted_times[min(q3_low + 1, n - 1)] * q3_frac
    return {
        "median": median,
        "iqr_low": iqr_low,
        "iqr_high": iqr_high,
        "mean": statistics.mean(sorted_times),
        "min": min(sorted_times),
        "max": max(sorted_times),
        "std": statistics.stdev(sorted_times) if n > 1 else 0,
    }


def main() -> None:
    import torch

    if torch.cuda.is_available():
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()

    parser = argparse.ArgumentParser(description="KernelBench evaluation")
    parser.add_argument("--impl", default="impl.py", help="Implementation file (default: impl.py)")
    parser.add_argument("--reference", default="ref.py", help="Reference file (default: ref.py)")
    parser.add_argument("--benchmark", action="store_true", help="Run performance benchmarks")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-correct-trials", type=int, default=3)
    parser.add_argument("--num-perf-trials", type=int, default=10)
    args = parser.parse_args()

    impl_path = Path(args.impl)
    ref_path = Path(args.reference)

    results: dict = {
        "correct": False,
        "speedup": None,
        "runtime_ms": None,
        "reference_runtime_ms": None,
        "error": None,
    }

    try:
        ref_module = _load_module(ref_path, "reference")
        Model = ref_module.Model  # type: ignore[attr-defined]
        get_inputs = ref_module.get_inputs  # type: ignore[attr-defined]
        get_init_inputs = ref_module.get_init_inputs  # type: ignore[attr-defined]

        impl_module = _load_module(impl_path, "implementation")
        ModelNew = impl_module.ModelNew  # type: ignore[attr-defined]

        seed = args.seed
        init_inputs = get_init_inputs()
        with torch.no_grad():
            torch.manual_seed(seed)
            torch.cuda.manual_seed(seed)
            ref_model = Model(*init_inputs).cuda().eval()
            torch.manual_seed(seed)
            torch.cuda.manual_seed(seed)
            new_model = ModelNew(*init_inputs).cuda().eval()

        all_correct = True
        for trial in range(args.num_correct_trials):
            inputs = get_inputs()
            inputs = [x.cuda() if isinstance(x, torch.Tensor) else x for x in inputs]
            with torch.no_grad():
                ref_output = ref_model(*inputs)
                new_output = new_model(*inputs)

            if isinstance(ref_output, torch.Tensor):
                if not torch.allclose(ref_output, new_output, rtol=1e-3, atol=1e-3):
                    all_correct = False
                    diff = (ref_output - new_output).abs()
                    results["error"] = f"Correctness failed trial {trial + 1}: max diff = {diff.max().item()}"
                    break
            else:
                for i, (r, n) in enumerate(zip(ref_output, new_output)):
                    if isinstance(r, torch.Tensor) and not torch.allclose(r, n, rtol=1e-3, atol=1e-3):
                        all_correct = False
                        diff = (r - n).abs()
                        results["error"] = f"Correctness failed trial {trial + 1}, output {i}: max diff = {diff.max().item()}"
                        break
                if not all_correct:
                    break

        results["correct"] = all_correct

        if args.benchmark and all_correct:
            inputs = get_inputs()
            inputs = [x.cuda() if isinstance(x, torch.Tensor) else x for x in inputs]

            for _ in range(5):
                with torch.no_grad():
                    _ = new_model(*inputs)
                    _ = ref_model(*inputs)
            torch.cuda.synchronize()

            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)

            new_times = []
            for _ in range(args.num_perf_trials):
                start.record()
                with torch.no_grad():
                    _ = new_model(*inputs)
                end.record()
                torch.cuda.synchronize()
                new_times.append(start.elapsed_time(end))

            ref_times = []
            for _ in range(args.num_perf_trials):
                start.record()
                with torch.no_grad():
                    _ = ref_model(*inputs)
                end.record()
                torch.cuda.synchronize()
                ref_times.append(start.elapsed_time(end))

            new_stats = _calculate_timing_stats(new_times)
            ref_stats = _calculate_timing_stats(ref_times)

            results["runtime_ms"] = new_stats["median"]
            results["reference_runtime_ms"] = ref_stats["median"]
            results["speedup"] = ref_stats["median"] / new_stats["median"] if new_stats["median"] > 0 else 0

    except Exception as e:
        import traceback
        results["error"] = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        results["correct"] = False

    try:
        del ref_model, new_model  # noqa: F821
    except NameError:
        pass
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    print(f"EVAL_RESULT_JSON:{json.dumps(results)}")


if __name__ == "__main__":
    main()
