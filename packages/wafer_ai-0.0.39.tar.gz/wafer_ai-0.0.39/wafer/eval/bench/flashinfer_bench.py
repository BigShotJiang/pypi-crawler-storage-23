"""FlashInfer-Bench bench script.

Runs in a directory containing a flashinfer-bench starter-kit layout with a solution.
Calls `flashinfer-bench run --local` and parses output for correctness + speedup.
Emits EVAL_RESULT_JSON with: correct, speedup, runtime_ms, reference_runtime_ms, error.

Usage: python -m wafer.eval.bench.flashinfer_bench [--definition <slug>] [--dataset-path <path>]
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path


def _find_dataset_path(directory: str | None = None) -> str:
    """Resolve FlashInfer-Trace dataset path.

    Search order:
    1. FIB_DATASET_PATH env var
    2. flashinfer-trace/ symlink in the solution directory (placed by eval harness)
    3. Walk up from cwd looking for research/flashinfer-trace/
    """
    env_path = os.environ.get("FIB_DATASET_PATH")
    if env_path and os.path.isdir(env_path):
        return env_path

    if directory:
        local_link = Path(directory) / "flashinfer-trace"
        if local_link.is_dir():
            return str(local_link.resolve())

    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        candidate = parent / "research" / "flashinfer-trace"
        if candidate.is_dir():
            return str(candidate)

    raise AssertionError(
        "FlashInfer-Trace dataset not found.\n"
        "FIB_DATASET_PATH not set, no flashinfer-trace/ in working dir, "
        "no research/flashinfer-trace/ found.\n"
        "Install: pip install flashinfer-bench\n"
        "Clone dataset: git clone https://huggingface.co/datasets/flashinfer-ai/mlsys26-contest"
    )


def _read_definition_slug(directory: str) -> str:
    """Read the definition slug from config.toml in the working directory."""
    config_path = os.path.join(directory, "config.toml")
    assert os.path.exists(config_path), f"config.toml not found in {directory}"
    with open(config_path) as f:
        content = f.read()
    match = re.search(r'definition\s*=\s*"([^"]+)"', content)
    assert match is not None, f"No definition found in config.toml:\n{content}"
    return match.group(1)


def _parse_flashinfer_bench_output(stdout: str, stderr: str) -> dict:
    """Parse flashinfer-bench run output for correctness and speedup metrics."""
    results: dict = {
        "correct": False,
        "speedup": None,
        "runtime_ms": None,
        "reference_runtime_ms": None,
        "error": None,
    }

    combined = stdout + "\n" + stderr

    for line in combined.splitlines():
        stripped = line.strip()

        if "correctness" in stripped.lower() and "pass" in stripped.lower():
            results["correct"] = True
        if "correctness" in stripped.lower() and "fail" in stripped.lower():
            results["correct"] = False

        speedup_match = re.search(r"speedup[:\s]+(\d+\.?\d*)", stripped, re.IGNORECASE)
        if speedup_match:
            results["speedup"] = float(speedup_match.group(1))

        runtime_match = re.search(r"(?:solution|kernel)\s+(?:runtime|latency|time)[:\s]+(\d+\.?\d*)\s*ms", stripped, re.IGNORECASE)
        if runtime_match:
            results["runtime_ms"] = float(runtime_match.group(1))

        ref_match = re.search(r"(?:reference|baseline)\s+(?:runtime|latency|time)[:\s]+(\d+\.?\d*)\s*ms", stripped, re.IGNORECASE)
        if ref_match:
            results["reference_runtime_ms"] = float(ref_match.group(1))

    for line in combined.splitlines():
        stripped = line.strip()
        if stripped.startswith("{"):
            try:
                data = json.loads(stripped)
                if isinstance(data, dict):
                    if "speedup_factor" in data:
                        results["speedup"] = float(data["speedup_factor"])
                    elif "speedup" in data:
                        results["speedup"] = float(data["speedup"])
                    if "correct" in data:
                        results["correct"] = bool(data["correct"])
                    if "correctness" in data:
                        results["correct"] = data["correctness"] in (True, "pass", "passed")
                    if "solution_runtime_ms" in data:
                        results["runtime_ms"] = float(data["solution_runtime_ms"])
                    if "reference_runtime_ms" in data:
                        results["reference_runtime_ms"] = float(data["reference_runtime_ms"])
            except (json.JSONDecodeError, ValueError):
                pass

    if results["speedup"] is None and results["runtime_ms"] and results["reference_runtime_ms"]:
        assert results["runtime_ms"] > 0
        results["speedup"] = results["reference_runtime_ms"] / results["runtime_ms"]

    return results


def main() -> None:
    parser = argparse.ArgumentParser(description="FlashInfer-Bench evaluation")
    parser.add_argument("directory", nargs="?", default=".", help="Solution directory (default: .)")
    parser.add_argument("--definition", default=None, help="Definition slug (auto-detected from config.toml if not provided)")
    parser.add_argument("--dataset-path", default=None, help="Path to FlashInfer-Trace dataset")
    parser.add_argument("--warmup-runs", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=100)
    parser.add_argument("--num-trials", type=int, default=5)
    parser.add_argument("--rtol", type=float, default=1e-3)
    parser.add_argument("--atol", type=float, default=1e-3)
    args = parser.parse_args()

    directory = os.path.abspath(args.directory)
    assert os.path.isdir(directory), f"Not a directory: {directory}"

    dataset_path = args.dataset_path or _find_dataset_path(directory)
    definition = args.definition or _read_definition_slug(directory)

    results: dict = {
        "correct": False,
        "speedup": None,
        "runtime_ms": None,
        "reference_runtime_ms": None,
        "error": None,
    }

    try:
        cmd = [
            "flashinfer-bench", "run",
            "--local", dataset_path,
            "--definitions", definition,
            "--warmup-runs", str(args.warmup_runs),
            "--iterations", str(args.iterations),
            "--num-trials", str(args.num_trials),
            "--rtol", str(args.rtol),
            "--atol", str(args.atol),
        ]

        proc = subprocess.run(
            cmd,
            cwd=directory,
            capture_output=True,
            text=True,
            timeout=600,
        )

        results = _parse_flashinfer_bench_output(proc.stdout, proc.stderr)

        if proc.returncode != 0 and results["error"] is None:
            results["error"] = f"flashinfer-bench exited with code {proc.returncode}\nstderr: {proc.stderr[-1000:]}"

    except FileNotFoundError:
        results["error"] = "flashinfer-bench not found. Install with: pip install flashinfer-bench"
    except subprocess.TimeoutExpired:
        results["error"] = "flashinfer-bench timed out after 600 seconds"
    except Exception as e:
        import traceback
        results["error"] = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"

    print(f"EVAL_RESULT_JSON:{json.dumps(results)}")


if __name__ == "__main__":
    main()
