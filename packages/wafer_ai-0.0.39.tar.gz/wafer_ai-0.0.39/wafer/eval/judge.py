"""LLM judge scoring utilities.

Building blocks for trajectory-based evaluation via LLM judges.
Three layers:
  1. Trajectory formatting: sample_to_trajectory_text(), truncate()
  2. Common parsers: parse_numeric_score(), parse_rubric_score(), parse_binary_score()
  3. Judge pipeline: judge_score() — format + call LLM + parse -> Score
"""
from __future__ import annotations

import re
from typing import Any, Callable

from wafer.core.rollouts.dtypes import Metric, Score

_MAX_BLOCK_CHARS = 4_000
_MAX_TRAJECTORY_CHARS = 600_000


def truncate(text: str, limit: int = _MAX_BLOCK_CHARS) -> str:
    """Smart truncation: keep first half + last half with indicator in middle."""
    if len(text) <= limit:
        return text
    half = limit // 2
    return text[:half] + f"\n\n... [{len(text) - limit} chars truncated] ...\n\n" + text[-half:]


def sample_to_trajectory_text(sample: Any) -> str:
    """Format a sample's trajectory as readable text for LLM judge evaluation."""
    trajectory = sample.trajectory
    assert trajectory is not None, "Sample must have trajectory"
    assert trajectory.messages, "Trajectory must have messages"
    lines: list[str] = []
    for msg in trajectory.messages:
        role = msg.role if hasattr(msg, "role") else msg["role"]
        content = msg.content if hasattr(msg, "content") else msg["content"]
        if isinstance(content, list):
            text_parts = []
            for block in content:
                if hasattr(block, "text"):
                    text_parts.append(block.text)
                elif isinstance(block, dict):
                    if "text" in block:
                        text_parts.append(block["text"])
                    elif block.get("type") == "toolCall":
                        assert "name" in block, "toolCall block must have 'name'"
                        name = block["name"]
                        args = block.get("arguments", {})
                        args_str = ", ".join(f"{k}={v!r}" for k, v in args.items())
                        text_parts.append(f"[Tool: {name}({args_str})]")
            content = "\n".join(text_parts)
        content = str(content) if content else ""
        if role == "tool":
            content = truncate(content)
        lines.append(f"=== {role} ===")
        lines.append(content)
        lines.append("")
    result = "\n".join(lines)
    return truncate(result, _MAX_TRAJECTORY_CHARS)


# ── Parsers ───────────────────────────────────────────────────────────────────

def parse_numeric_score(output: str, *, scale: int = 10, key: str = "score") -> Score:
    """Parse {"score": N, "reasoning": "..."} from judge output.

    Normalizes to 0-1 range for the weighted metric.
    """
    match = re.search(rf'"{key}"\s*:\s*(\d+)', output)
    assert match, f"No '{key}' found in judge response:\n{output[:500]}"
    raw = int(match.group(1))
    assert 0 <= raw <= scale, f"Score {raw} out of range 0-{scale}"
    return Score(metrics=(
        Metric("raw_score", float(raw)),
        Metric("score", raw / scale, weight=1.0),
    ))


def parse_rubric_score(output: str, *, dimensions: dict[str, float]) -> Score:
    """Parse multi-dimension rubric from judge output.

    dimensions maps dimension name to weight, e.g.
    {"correctness": 0.4, "methodology": 0.3, "actionability": 0.3}.
    Each dimension expected as 0-10 integer in the JSON response.
    """
    metrics: list[Metric] = []
    for dim, weight in dimensions.items():
        match = re.search(rf'"{dim}"\s*:\s*(\d+)', output)
        assert match, f"No '{dim}' found in judge response:\n{output[:500]}"
        raw = int(match.group(1))
        assert 0 <= raw <= 10, f"{dim} score {raw} out of range 0-10"
        metrics.append(Metric(dim, raw / 10.0, weight=weight))
    return Score(metrics=tuple(metrics))


def parse_binary_score(output: str, *, key: str = "passed") -> Score:
    """Parse {"passed": true/false, "reasoning": "..."} from judge output."""
    match = re.search(rf'"{key}"\s*:\s*(true|false)', output, re.IGNORECASE)
    assert match, f"No '{key}' found in judge response:\n{output[:500]}"
    passed = match.group(1).lower() == "true"
    return Score(metrics=(
        Metric("correct", 1.0 if passed else 0.0, weight=1.0),
    ))


# ── Judge pipeline ────────────────────────────────────────────────────────────

async def _call_llm(
    prompt: str,
    *,
    model: str,
    max_tokens: int,
    on_chunk: Any = None,
) -> str:
    """Call Anthropic API with optional streaming."""
    import anthropic

    client = anthropic.AsyncAnthropic()
    messages = [{"role": "user", "content": prompt}]
    if on_chunk is not None:
        chunks: list[str] = []
        async with client.messages.stream(
            model=model,
            max_tokens=max_tokens,
            messages=messages,
        ) as stream:
            async for event in stream:
                if getattr(event, "type", None) == "content_block_delta":
                    delta = getattr(event, "delta", None)
                    if delta is not None and getattr(delta, "type", None) == "text_delta":
                        text = getattr(delta, "text", "") or ""
                        if text:
                            chunks.append(text)
                            on_chunk(text)
            return "".join(chunks)
    response = await client.messages.create(
        model=model,
        max_tokens=max_tokens,
        messages=messages,
    )
    return response.content[0].text


async def judge_score(
    sample: Any,
    *,
    prompt: str,
    model: str = "claude-sonnet-4-20250514",
    max_tokens: int = 2048,
    parse_fn: Callable[[str], Score] = parse_numeric_score,
    trajectory_fn: Callable[..., str] = sample_to_trajectory_text,
    on_chunk: Any = None,
) -> Score:
    """Full judge pipeline: format trajectory -> call LLM -> parse Score.

    The prompt must contain a {trajectory} placeholder.
    """
    trajectory_text = trajectory_fn(sample)
    formatted = prompt.format(trajectory=trajectory_text)

    judge_output = await _call_llm(
        formatted, model=model, max_tokens=max_tokens, on_chunk=on_chunk,
    )

    if hasattr(sample, "metadata") and sample.metadata is not None:
        sample.metadata["judge_output"] = judge_output

    return parse_fn(judge_output)
