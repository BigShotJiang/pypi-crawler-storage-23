"""KernelBench scorer.

Expects directory with impl.py (ModelNew) and ref.py (Model + get_inputs + get_init_inputs).
Runs the kernelbench bench script and parses JSON output.
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.eval import extract_eval_result


async def _run_benchmark(work_dir: Path) -> str:
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "wafer.eval.bench.kernelbench", "--benchmark",
        cwd=str(work_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    return extract_eval_result(stdout.decode())


async def score(
    work_dir: Path,
    *,
    baseline_dir: Path | None = None,
) -> Score:
    """Score a KernelBench solution directory."""
    assert work_dir.is_dir(), f"Not a directory: {work_dir}"
    output = await _run_benchmark(work_dir)
    after = json.loads(output)
    assert "correct" in after, f"Missing 'correct' in output: {after}"

    correct = 1.0 if after.get("correct") else 0.0

    if baseline_dir is not None:
        assert baseline_dir.is_dir(), f"Baseline not a directory: {baseline_dir}"
        baseline_output = await _run_benchmark(baseline_dir)
        before = json.loads(baseline_output)
        assert "runtime_ms" in before, f"Missing 'runtime_ms' in baseline: {before}"
        assert "runtime_ms" in after, f"Missing 'runtime_ms' in output: {after}"
        assert before["runtime_ms"] > 0, "Baseline runtime_ms must be positive"
        assert after["runtime_ms"] > 0, "After runtime_ms must be positive"
        speedup = before["runtime_ms"] / after["runtime_ms"]
    else:
        raw = after.get("speedup")
        assert raw is not None, f"Missing 'speedup' in output: {after}"
        speedup = float(raw)

    composite = correct + (speedup if correct > 0 else 0.0)
    return Score(metrics=(
        Metric("correct", correct),
        Metric("speedup", speedup),
        Metric("score", composite, weight=1.0),
    ))
