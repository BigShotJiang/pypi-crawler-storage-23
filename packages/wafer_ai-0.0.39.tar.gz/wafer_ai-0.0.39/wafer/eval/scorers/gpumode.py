"""GPUMode scorer.

Expects directory with kernel.py, reference.py, test_cases.json.
Runs the gpumode bench script and parses JSON output.
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.eval import extract_eval_result


async def _run_benchmark(work_dir: Path) -> str:
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "wafer.eval.bench.gpumode", "--benchmark",
        cwd=str(work_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    return extract_eval_result(stdout.decode())


async def score(
    work_dir: Path,
    *,
    baseline_dir: Path | None = None,
) -> Score:
    """Score a GPUMode solution directory."""
    assert work_dir.is_dir(), f"Not a directory: {work_dir}"
    output = await _run_benchmark(work_dir)
    after = json.loads(output)
    assert "all_correct" in after, f"Missing 'all_correct' in output: {after}"
    assert "geomean_speedup" in after, f"Missing 'geomean_speedup' in output: {after}"

    correct_val = 1.0 if after["all_correct"] else 0.0

    if baseline_dir is not None:
        assert baseline_dir.is_dir(), f"Baseline not a directory: {baseline_dir}"
        baseline_output = await _run_benchmark(baseline_dir)
        before = json.loads(baseline_output)
        assert "geomean_speedup" in before, f"Missing 'geomean_speedup' in baseline: {before}"
        before_speedup = float(before["geomean_speedup"])
        assert before_speedup > 0, "Baseline geomean_speedup must be positive"
        speedup = float(after["geomean_speedup"]) / before_speedup
    else:
        speedup = float(after["geomean_speedup"])

    composite = correct_val + (speedup if after["all_correct"] else 0.0)
    return Score(metrics=(
        Metric("correct", correct_val),
        Metric("speedup", speedup),
        Metric("score", composite, weight=1.0),
    ))
