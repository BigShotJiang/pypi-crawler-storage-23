"""Shared agent defaults for kernel tasks.

Single source of truth for bash allowlists and enabled tools used by both:
- CLI templates (packages/wafer-ai/wafer/cli/templates/toml/*.toml)
- Eval configs (research/eval-harness/evals/*_eval/*.py)

Import from here instead of defining your own copy.
"""

from __future__ import annotations

# Tools available to the agent (coding environment tools)
ENABLED_TOOLS: list[str] = ["read", "write", "edit", "glob", "grep", "bash"]

# vLLM-specific tools
VLLM_ENABLED_TOOLS: list[str] = ["read", "write", "edit", "glob", "grep", "bash"]

# ── Shared base command lists ────────────────────────────────────────────────
# Compose allowlists from these bases to reduce duplication.

_BASE_READONLY: list[str] = ["ls", "cat", "head", "tail", "wc", "pwd", "which"]
_BASE_SEARCH: list[str] = ["find", "grep", "rg", "tree", "diff", "sort"]
_BASE_FILESYSTEM: list[str] = ["mkdir", "cp", "mv"]
_BASE_GIT_READONLY: list[str] = ["git diff", "git status", "git log"]
_BASE_COMPILE: list[str] = ["g++", "gcc", "clang"]
_BASE_PYTHON: list[str] = ["python", "python3"]
_BASE_EXEC: list[str] = ["./"]
_BASE_WAFER_AMD: list[str] = [
    "wafer tool rocprof-compute",
    "wafer tool rocprof-sdk",
    "wafer tool rocprof-systems",
]
_BASE_WAFER_NVIDIA: list[str] = []

# ── Allowlists (composed from bases) ────────────────────────────────────────

# Bash commands allowed for kernel optimization agents.
# Uses prefix matching — "wafer tool eval" allows all eval subcommands.
KERNELBENCH_BASH_ALLOWLIST: list[str] = [
    # GPU target (required for kernelbench — no local GPU)
    "wafer sandbox run",
    # Kernel evaluation (unified primitive)
    "wafer tool eval",
    # Profiling — AMD
    "wafer tool rocprof-compute",
    "wafer tool rocprof-sdk",
    "wafer tool rocprof-systems",
    # Analysis
    "wafer compiler-analyze",
    # General utilities
    *_BASE_PYTHON,
    "timeout",
    *_BASE_READONLY,
]

# Tools available to aiter optimization agents (full coding environment)
AITER_ENABLED_TOOLS: list[str] = ["read", "write", "edit", "glob", "grep", "bash"]

# System prompt for aiter optimization (shared between eval and template)
# Uses {op_name}, {test_file}, {target_flag} placeholders
AITER_SYSTEM_PROMPT = """\
You are a GPU kernel optimization expert specializing in AMD MI300X and the aiter library.

## Context

aiter (ROCm/aiter) is AMD's centralized repository for high-performance AI operators.
Operators are implemented using Triton kernels, Composable Kernel (CK), or HIP/ROCm.

Each operator has a test in `op_tests/test_{{op}}.py` that validates correctness and
measures performance against a reference implementation.

## Your Task

1. **Understand the operator**: Read the test file and trace imports to find implementation
2. **Establish baseline**: Run the evaluation to measure current performance
   ```bash
   # Quick check with one shape (fast iteration)
   wafer tool eval --task aiter -- python op_tests/test_{{op}}.py -mnk 128,32,8192

   # Full test suite (final validation)
   wafer tool eval --task aiter -- python op_tests/test_{{op}}.py
   ```
3. **Identify optimizations**: Look for memory access patterns, occupancy, instruction selection
4. **Implement changes**: Modify the operator to improve performance
5. **Validate**: Re-run evaluation to verify correctness and measure speedup
6. **Iterate**: Use quick checks during development, full suite for final validation

## Finding Source Files

The aiter codebase structure varies by operator. To find implementation files:

1. **Start with the test file**: `op_tests/test_{{op}}.py`
   - Read imports to see what modules are used
   - Look for the main function being tested

2. **Check common locations** (not all ops have all of these):
   - `aiter/ops/{{op}}.py` — High-level Python API (some ops)
   - `aiter/triton_kernels/` — Triton kernel implementations
   - `csrc/kernels/` — CUDA/HIP kernel implementations
   - `csrc/py_itfs_cu/` — Python interface CUDA files
   - `csrc/cktile_*/` — Composable Kernel tile implementations

3. **Search for the op name**:
   ```bash
   find . -name "*{{op}}*" -type f | grep -v __pycache__
   grep -r "def {{function_name}}" aiter/ csrc/ --include="*.py" --include="*.cu"
   ```

## Output

Your goal is to produce:
1. Modified operator code with optimizations
2. Benchmark results showing correctness and speedup
3. A summary of what you changed and why

The optimization should be correct (pass the op_test) and faster than baseline."""

# Bash commands allowed for aiter optimization agents.
AITER_BASH_ALLOWLIST: list[str] = [
    *_BASE_READONLY,
    *_BASE_SEARCH,
    *_BASE_FILESYSTEM,
    *_BASE_GIT_READONLY,
    # Compilation
    "hipcc",
    *_BASE_COMPILE,
    *_BASE_PYTHON,
    "pip",
    "pytest",
    *_BASE_EXEC,
    # Kernel evaluation (unified primitive)
    "wafer tool eval",
    # Profiling — AMD
    "wafer tool rocprof-compute",
    "wafer tool rocprof-sdk",
    "wafer tool rocprof-systems",
    "wafer tool isa",
    # Misc
    "timeout",
]

# Bash commands allowed for vLLM kernel optimization agents.
VLLM_BASH_ALLOWLIST: list[str] = [
    # Kernel evaluation (unified primitive)
    "wafer tool eval",
    # vLLM's own test and benchmark commands (run inside vllm dir)
    "pytest",
    # Profiling — AMD
    "wafer tool rocprof-compute",
    "wafer tool rocprof-sdk",
    "wafer tool rocprof-systems",
    # Analysis
    "wafer compiler-analyze",
    # General utilities
    *_BASE_PYTHON,
    "pip",
    "timeout",
    *_BASE_READONLY,
    "cd",
    "git",
]

# Tools available to FlashInfer optimization agents (full coding environment)
FLASHINFER_ENABLED_TOOLS: list[str] = ["read", "write", "edit", "glob", "grep", "bash"]

# Bash commands allowed for FlashInfer kernel optimization agents.
FLASHINFER_BASH_ALLOWLIST: list[str] = [
    *_BASE_READONLY,
    *_BASE_SEARCH,
    *_BASE_FILESYSTEM,
    *_BASE_GIT_READONLY,
    "git checkout",
    # Compilation (FlashInfer uses JIT, but may need manual builds)
    "nvcc",
    *_BASE_COMPILE,
    "ninja",
    "cmake",
    "make",
    *_BASE_PYTHON,
    "pip",
    "pytest",
    *_BASE_EXEC,
    # Analysis
    "wafer compiler-analyze",
    # Kernel evaluation (unified primitive)
    "wafer tool eval",
    # Misc
    "timeout",
]

# Tools available to FlashInfer-Bench contest agents (full coding environment)
FLASHINFER_BENCH_ENABLED_TOOLS: list[str] = ["read", "write", "edit", "glob", "grep", "bash"]

# Bash commands allowed for FlashInfer-Bench contest agents.
FLASHINFER_BENCH_BASH_ALLOWLIST: list[str] = [
    *_BASE_READONLY,
    *_BASE_SEARCH,
    *_BASE_FILESYSTEM,
    *_BASE_GIT_READONLY,
    "git checkout",
    # Compilation — any language (CUDA, Triton, CuTe DSL, Cutlass, cuTile, Tilelang)
    "nvcc",
    *_BASE_COMPILE,
    "ninja",
    "cmake",
    "make",
    *_BASE_PYTHON,
    "pip",
    "pytest",
    *_BASE_EXEC,
    # FlashInfer-Bench CLI
    "flashinfer-bench",
    # Modal (cloud B200 benchmarking)
    "modal",
    # GPU target routing
    "wafer target run",
    # Kernel evaluation (unified primitive)
    "wafer tool eval",
    # Analysis
    "wafer compiler-analyze",
    # Misc
    "timeout",
]

# Tools available to hipBLASLt optimization agents (full coding environment)
HIPBLASLT_ENABLED_TOOLS: list[str] = ["read", "write", "edit", "glob", "grep", "bash"]

# System prompt for hipBLASLt optimization
# Uses {shape}, {workspace_flag} placeholders
HIPBLASLT_SYSTEM_PROMPT = """\
You are a GPU kernel optimization expert specializing in AMD MI300X and the hipBLASLt library.

## Context

hipBLASLt (ROCm/hipBLASLt) is AMD's high-performance BLAS library for General Matrix Multiply (GEMM)
operations. It provides optimized kernels for various data types (FP16, BF16, INT8) and matrix
shapes commonly used in LLM inference and training.

## Your Task

1. **Understand the kernel**: Read the source code in the hipBLASLt library
2. **Establish baseline**: Run evaluation to measure current performance
   ```bash
   wafer tool eval --task hipblaslt -- --shape {shape}
   ```
3. **Profile bottlenecks**: Use profiling tools
   ```bash
   wafer tool rocprof-compute profile ...
   wafer tool isa analyze <kernel.co>
   ```
4. **Implement changes**: Modify kernels to improve performance
5. **Validate**: Re-run evaluation to verify correctness and measure speedup

## Evaluation Command

The evaluation uses `wafer target run` for GPU command queueing, ensuring:
- No GPU conflicts between concurrent evaluations
- Automatic workspace selection (or specify with --workspace)
- Consistent environment across runs

## hipBLASLt Repository Structure

- `library/src/amd_detail/` — AMD-specific implementations
  - `rocblaslt/src/Tensile/` — Tensile kernel implementations
  - `rocblaslt/src/include/` — Header files
- `library/include/` — Public headers
- `clients/` — Test clients and benchmarks
  - `clients/benchmarks/` — Performance benchmarks
  - `clients/gtest/` — Unit tests
- `tensilelite/` — Tensile code generation

## Key Kernel Locations

For GEMM kernels, look in:
- `library/src/amd_detail/rocblaslt/src/Tensile/` — Main kernel sources
- Assembly kernels may be generated via Tensile

## Common Optimization Patterns

1. **No-Op Removal**: Remove redundant operations (x * 1, x + 0, unnecessary syncs)
2. **Vectorization**: Use wider loads/stores (float4 instead of float)
3. **Loop Unrolling**: Add `#pragma unroll` or manually unroll hot loops
4. **Shared Memory Tiling**: Stage data in LDS for reuse
5. **Register Blocking**: Increase register tile size for data reuse
6. **Memory Coalescing**: Ensure threads access contiguous memory
7. **Sync Optimization**: Remove unnecessary __syncthreads()

## Output

Your goal is to produce:
1. Modified kernel code with optimizations
2. Benchmark results showing correctness and speedup
3. A summary of what you changed and why

The optimization should be correct (pass benchmarks) and faster than baseline."""

# Bash commands allowed for hipBLASLt kernel optimization agents.
HIPBLASLT_BASH_ALLOWLIST: list[str] = [
    *_BASE_READONLY,
    *_BASE_SEARCH,
    *_BASE_FILESYSTEM,
    *_BASE_GIT_READONLY,
    "git show",
    "git checkout",
    # Compilation
    "hipcc",
    "cmake",
    "make",
    "ninja",
    *_BASE_COMPILE,
    *_BASE_PYTHON,
    "pip",
    "pytest",
    *_BASE_EXEC,
    # Kernel evaluation (unified primitive)
    "wafer tool eval",
    # Profiling — AMD
    "wafer tool rocprof-compute",
    "wafer tool rocprof-sdk",
    "wafer tool rocprof-systems",
    "wafer tool isa",
    # Misc
    "timeout",
]


# Tools available to audit agents (read-only + bash for compilation/profiling)
AUDIT_ENABLED_TOOLS: list[str] = ["read", "glob", "grep", "bash"]

# Bash commands allowed for kernel audit agents.
AUDIT_BASH_ALLOWLIST: list[str] = [
    *_BASE_READONLY,
    *_BASE_SEARCH,
    # Filesystem
    "mkdir",
    # Compilation
    "make",
    "cmake",
    "nvcc",
    "hipcc",
    *_BASE_COMPILE,
    *_BASE_PYTHON,
    *_BASE_EXEC,
    # Profiling
    "wafer tool eval",
    "wafer tool rocprof-compute",
    "wafer tool rocprof-sdk",
    "wafer tool rocprof-systems",
    "wafer tool isa",
    "wafer compiler-analyze",
    # Remote execution (for ISA compilation on GPU targets)
    "wafer sandbox run",
    # Misc
    "timeout",
]
