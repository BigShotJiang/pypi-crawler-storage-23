# ruff: noqa: PLR0913
"""Demo commands for Wafer CLI - interactive demos for Wafer workflows."""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import typer

if TYPE_CHECKING:
    from types import ModuleType

demo_app = typer.Typer(help="Interactive demos for Wafer workflows.")

DEMO_TRACES_URL = "https://github.com/wafer-ai/wafer/raw/main/packages/wafer-ai/wafer/cli/demo_data"
DEMO_DIR = Path.home() / ".cache" / "wafer" / "demo"


@demo_app.command("setup")
def demo_setup() -> None:
    """Download sample data for demos and tutorials."""
    import shutil
    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    # For now, copy bundled demo data from package
    # In future, could download from GitHub releases
    demo_source = Path(__file__).parent / "demo_data"
    if demo_source.exists():
        for f in demo_source.iterdir():
            dest = DEMO_DIR / f.name
            if not dest.exists():
                shutil.copy(f, dest)
                typer.echo(f"  + {f.name}")
        typer.echo(f"\nDemo data ready at: {DEMO_DIR}")
    else:
        # Fallback: create minimal synthetic trace
        sample_trace = DEMO_DIR / "sample_trace.json"
        if not sample_trace.exists():
            sample_trace.write_text("""{
  "traceEvents": [
    {"name": "matmul_kernel", "cat": "kernel", "ph": "X", "ts": 0, "dur": 1500000, "pid": 1, "tid": 1},
    {"name": "relu_kernel", "cat": "kernel", "ph": "X", "ts": 1600000, "dur": 50000, "pid": 1, "tid": 1},
    {"name": "softmax_kernel", "cat": "kernel", "ph": "X", "ts": 1700000, "dur": 200000, "pid": 1, "tid": 1},
    {"name": "attention_kernel", "cat": "kernel", "ph": "X", "ts": 2000000, "dur": 3000000, "pid": 1, "tid": 1},
    {"name": "layernorm_kernel", "cat": "kernel", "ph": "X", "ts": 5100000, "dur": 100000, "pid": 1, "tid": 1}
  ]
}""")
            typer.echo("  + sample_trace.json (synthetic)")
        typer.echo(f"\nDemo data ready at: {DEMO_DIR}")
    typer.echo("\nTry these commands:")
    typer.echo(f"  wafer tool perfetto tables {DEMO_DIR}/sample_trace.json")
    typer.echo(
        f"  wafer tool perfetto query {DEMO_DIR}/sample_trace.json "
        '"SELECT name, dur/1e6 as ms FROM slice ORDER BY dur DESC"'
    )


@demo_app.command("traces")
def demo_traces(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List available demo traces."""
    from .output import json_error, json_response
    if not DEMO_DIR.exists():
        if json_output:
            typer.echo(json_error("No demo data found. Run: wafer demo setup"))
        else:
            typer.echo("No demo data found. Run: wafer demo setup")
        raise typer.Exit(1)
    traces = list(DEMO_DIR.glob("*.json"))
    if not traces:
        if json_output:
            typer.echo(json_error("No traces found. Run: wafer demo setup"))
        else:
            typer.echo("No traces found. Run: wafer demo setup")
        raise typer.Exit(1)

    if json_output:
        trace_list = []
        for trace in sorted(traces):
            trace_list.append({
                "name": trace.name,
                "path": str(trace),
                "size_bytes": trace.stat().st_size,
            })
        typer.echo(json_response(data={"traces": trace_list, "demo_dir": str(DEMO_DIR)}))
        return

    typer.echo("Available demo traces:\n")
    for trace in sorted(traces):
        size_kb = trace.stat().st_size / 1024
        typer.echo(f"  {trace.name} ({size_kb:.1f} KB)")
        typer.echo(f"    {trace}")
    typer.echo("\nExample queries:")
    typer.echo("  # Slowest operations")
    typer.echo(
        f'  wafer tool perfetto query {traces[0]} "SELECT name, dur/1e6 as ms FROM slice ORDER BY dur DESC LIMIT 10"'
    )
    typer.echo("")
    typer.echo("  # Time breakdown by category")
    typer.echo(
        f'  wafer tool perfetto query {traces[0]} "SELECT cat, SUM(dur)/1e6 as total_ms FROM slice GROUP BY cat ORDER BY total_ms DESC"'
    )


@demo_app.command("trace")
def demo_trace(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Demo: Analyze a performance trace."""
    import subprocess
    if not yes:
        typer.echo("This demo will:")
        typer.echo("  1. Create a sample PyTorch-style trace")
        typer.echo("  2. Run SQL queries to find slowest kernels")
        typer.echo("")
        if not typer.confirm("Continue?"):
            raise typer.Exit(0)
    # Step 1: Setup demo data
    typer.echo("\n[1/2] Creating sample trace...")
    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    sample_trace = DEMO_DIR / "sample_trace.json"
    sample_trace.write_text("""{
  "traceEvents": [
    {"name": "matmul_kernel", "cat": "kernel", "ph": "X", "ts": 0, "dur": 1500000, "pid": 1, "tid": 1},
    {"name": "relu_kernel", "cat": "kernel", "ph": "X", "ts": 1600000, "dur": 50000, "pid": 1, "tid": 1},
    {"name": "softmax_kernel", "cat": "kernel", "ph": "X", "ts": 1700000, "dur": 200000, "pid": 1, "tid": 1},
    {"name": "attention_kernel", "cat": "kernel", "ph": "X", "ts": 2000000, "dur": 3000000, "pid": 1, "tid": 1},
    {"name": "layernorm_kernel", "cat": "kernel", "ph": "X", "ts": 5100000, "dur": 100000, "pid": 1, "tid": 1}
  ]
}""")
    typer.echo(f"  Created: {sample_trace}")
    # Step 2: Query the trace
    typer.echo("\n[2/2] Finding slowest kernels...\n")
    typer.echo("-" * 60)
    result = subprocess.run(
        [
            "wafer",
            "tool",
            "perfetto",
            "query",
            str(sample_trace),
            "SELECT name, dur/1e6 as duration_ms FROM slice ORDER BY dur DESC",
        ],
        check=False,
    )
    typer.echo("-" * 60)
    if result.returncode == 0:
        typer.echo("\n[ok] Demo complete! Try your own traces:")
        typer.echo('  wafer tool perfetto query <your_trace.json> "SELECT name, dur FROM slice"')
        typer.echo("")
        typer.echo("  Or use AI-assisted analysis:")
        typer.echo('  wafer agent -t trace-analyze --args trace=<your_trace.json> "What\'s slow?"')
    else:
        typer.echo("\n[fail] Demo failed.")
        raise typer.Exit(1)


def _demo_eval_confirm() -> None:
    typer.echo("This demo will:")
    typer.echo("  1. Create a cloud GPU workspace (B200)")
    typer.echo("  2. Generate and upload a sample Triton kernel")
    typer.echo("  3. Run correctness + performance evaluation")
    typer.echo("  4. Delete the workspace")
    typer.echo("")
    typer.echo("  Note: Workspace usage is billed. Demo takes ~2-3 minutes.")
    typer.echo("")
    if not typer.confirm("Continue?"):
        raise typer.Exit(0)


def _demo_eval_create_workspace(subprocess: ModuleType, workspace_name: str) -> str:
    assert hasattr(subprocess, "run"), "subprocess must have a run method"
    assert isinstance(workspace_name, str) and workspace_name, "workspace_name must be a non-empty string"

    import json
    typer.echo(f"\n[1/4] Creating workspace '{workspace_name}'...")
    result = subprocess.run(
        ["wafer", "target", "init", "workspace", workspace_name, "--gpu", "B200", "--json"],
        capture_output=True, text=True, check=True,
    )
    ws_info = json.loads(result.stdout)
    workspace_id = ws_info.get("id", workspace_name)
    typer.echo(f"  Created: {workspace_id}")
    return workspace_id


_DEMO_TEST_SCRIPT = """\
import torch
import kernel
import reference
print(f"GPU: {torch.cuda.get_device_name(0)}")
inputs = reference.generate_input(n=1048576, seed=42)
out = kernel.custom_kernel(inputs)
ref = reference.ref_kernel(inputs)
correct = torch.allclose(out, ref)
print(f"Correctness: {correct}")
import time
for _ in range(10):
    kernel.custom_kernel(inputs)
torch.cuda.synchronize()
t0 = time.perf_counter()
for _ in range(100):
    kernel.custom_kernel(inputs)
torch.cuda.synchronize()
t1 = time.perf_counter()
print(f"Performance: {(t1-t0)/100*1e6:.1f} us/iter")
"""


def _demo_eval_run_kernel(subprocess: ModuleType, workspace_name: str, kernel_dir: Path) -> Any:
    """Run kernel eval on workspace via sync + exec (no wafer target run)."""
    assert isinstance(workspace_name, str) and workspace_name, "workspace_name must be a non-empty string"
    assert isinstance(kernel_dir, Path), "kernel_dir must be a Path"

    typer.echo("\n[3/4] Running evaluation on cloud GPU...\n")
    typer.echo("-" * 60)
    test_script = kernel_dir / "run_test.py"
    test_script.write_text(_DEMO_TEST_SCRIPT)
    from .workspaces import exec_command, sync_files

    sync_files(workspace_name, kernel_dir.resolve())
    exit_code = exec_command(
        workspace_name,
        "cd /workspace && uv pip install -q --system triton && python run_test.py",
        timeout_seconds=120,
    )
    typer.echo("-" * 60)
    return type("Result", (), {"returncode": exit_code})()


def _demo_eval_cleanup(subprocess: ModuleType, workspace_name: str, workspace_id: str, eval_result: Any) -> None:
    assert isinstance(workspace_name, str) and workspace_name, "workspace_name must be a non-empty string"
    assert isinstance(workspace_id, str) and workspace_id, "workspace_id must be a non-empty string"

    typer.echo(f"\n[4/4] Deleting workspace '{workspace_name}'...")
    subprocess.run(
        ["wafer", "target", "remove", "--yes", workspace_id],
        capture_output=True, check=False,
    )
    typer.echo("  Deleted")
    if eval_result.returncode == 0:
        typer.echo("\nDemo complete! To evaluate your own kernels:")
        typer.echo("")
        typer.echo("  # Using SSH target + sandbox (set default: wafer target default <name>):")
        typer.echo("  wafer target init ssh my-gpu --host user@host:22")
        typer.echo("  wafer agent  # sandbox tool runs on default target")
        typer.echo("")
        typer.echo("  # Or run one-off: wafer sandbox run --target <name> -- python my_test.py")
    else:
        typer.echo("\nEvaluation failed, but workspace was cleaned up.")
        raise typer.Exit(1)


def _demo_eval_force_cleanup(subprocess: ModuleType, workspace_name: str) -> None:
    assert hasattr(subprocess, "run"), "subprocess must have a run method"
    assert isinstance(workspace_name, str) and workspace_name, "workspace_name must be a non-empty string"

    typer.echo(f"Attempting to cleanup workspace '{workspace_name}'...")
    subprocess.run(
        ["wafer", "target", "remove", "--yes", workspace_name],
        capture_output=True, check=False,
    )


def _write_demo_kernel_files(kernel_dir: Path) -> None:
    """Write demo kernel files for the eval demo."""
    (kernel_dir / "kernel.py").write_text(
        "import torch\nimport triton\nimport triton.language as tl\n\n"
        "@triton.jit\ndef add_kernel(x_ptr, y_ptr, out_ptr, n, BLOCK: tl.constexpr):\n"
        "    pid = tl.program_id(0)\n    offsets = pid * BLOCK + tl.arange(0, BLOCK)\n"
        "    mask = offsets < n\n    x = tl.load(x_ptr + offsets, mask=mask)\n"
        "    y = tl.load(y_ptr + offsets, mask=mask)\n"
        "    tl.store(out_ptr + offsets, x + y, mask=mask)\n\n"
        "def custom_kernel(inputs):\n    x, y = inputs\n    out = torch.empty_like(x)\n"
        "    n = x.numel()\n    add_kernel[(n + 1023) // 1024,](x, y, out, n, BLOCK=1024)\n"
        "    return out\n"
    )
    (kernel_dir / "reference.py").write_text(
        "import torch\n\ndef ref_kernel(inputs):\n    x, y = inputs\n    return x + y\n\n"
        "def generate_input(n=1048576, seed=42):\n    torch.manual_seed(seed)\n"
        "    return torch.randn(n, device='cuda'), torch.randn(n, device='cuda')\n"
    )


@demo_app.command("eval")
def demo_eval(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Demo: Evaluate a kernel on a cloud GPU (requires login)."""
    import subprocess
    import tempfile
    import time

    from .auth import load_credentials
    creds = load_credentials()
    if not creds:
        typer.echo("Error: Not authenticated. Run: wafer login")
        raise typer.Exit(1)
    if not yes:
        _demo_eval_confirm()
    workspace_name = f"wafer-demo-{int(time.time()) % 100000}"
    try:
        workspace_id = _demo_eval_create_workspace(subprocess, workspace_name)
        typer.echo("\n[2/4] Generating sample kernel...")
        with tempfile.TemporaryDirectory() as tmpdir:
            kernel_dir = Path(tmpdir) / "demo-kernel"
            kernel_dir.mkdir(parents=True)
            _write_demo_kernel_files(kernel_dir)
            typer.echo("  Generated Triton vector-add kernel")
            eval_result = _demo_eval_run_kernel(subprocess, workspace_name, kernel_dir)
        _demo_eval_cleanup(subprocess, workspace_name, workspace_id, eval_result)
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() if e.stderr else str(e)
        typer.echo(f"\n Error: {error_msg}")
        _demo_eval_force_cleanup(subprocess, workspace_name)
        raise typer.Exit(1) from None
    except KeyboardInterrupt:
        typer.echo(f"\n\nInterrupted. Cleaning up workspace '{workspace_name}'...")
        _demo_eval_force_cleanup(subprocess, workspace_name)
        raise typer.Exit(1) from None
