<!-- AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
     Regenerate with: just generate-skill
     Source template: SKILL.md.template -->

# Command Reference

### `wafer tool eval`
Evaluate kernel correctness and performance

Options:
  --task/-t TEXT  Task name (built-in) or path to .py file (required unless --list-tasks)
  --after/-a PATH  Directory to evaluate (default: current directory)
  --before/-b PATH  Baseline directory for comparison (optional)
  --list-tasks  List available built-in tasks and exit

### `wafer tool`
Run profiling, evaluation, and analysis tools.

Subcommands:
  wafer tool roofline  Analyze kernel performance against roofline model.
  wafer tool perfetto  Perfetto trace analysis and SQL queries
  wafer tool tracelens  TraceLens performance reports
  wafer tool isa  ISA analysis for AMD GPU kernels (.co, .s, .ll, .ttgir files)
  wafer tool compare  Compare GPU traces across platforms (AMD vs NVIDIA)
  wafer tool eval  Evaluate kernel correctness and performance
  wafer tool baseline  Discover what kernel PyTorch dispatches for a given operation.
  wafer tool nvidia-distributed-traces  Analyze NCCL collective operations in distributed training traces
  wafer tool problems  Download and list kernel optimization problems for wafer tool eval.
  wafer tool amd-distributed-traces  Analyze RCCL collective operations in distributed training traces
  wafer tool rocprof-sdk  ROCprofiler-SDK profiling tool commands
  wafer tool rocprof-systems  ROCprofiler-Systems profiling tool commands
  wafer tool rocprof-compute  ROCprofiler-Compute profiling tool commands
  wafer tool autotuner  Hyperparameter sweep for performance engineering
  wafer tool capture  Capture execution snapshots for reproducibility and comparison.

### `wafer sandbox`
Execute commands on SSH targets via tmux sandboxes (wafer target init ssh). Does NOT support workspaces.

Subcommands:
  wafer sandbox run  Run a command in a sandbox on a target (creates sandbox if needed).
  wafer sandbox list  List sandboxes (optionally filtered by --target).
  wafer sandbox attach  Attach to an existing sandbox session.
  wafer sandbox delete  Delete a sandbox.
  wafer sandbox create  Create a new sandbox on a target.

### `wafer target`
Create, manage, and sync code on GPU targets (use wafer sandbox for remote execution).

Subcommands:
  wafer target init ssh  Initialize an SSH target for your own GPU hardware (auto-detects GPU, probes target).
  wafer target verify  Verify target connectivity.
  wafer target list  List all targets (workspaces + hosts + user targets).
  wafer target show  Show details for a target (workspace or host).
  wafer target remove  Remove a target (workspace or host).
  wafer target default  Set the default target, or show the current default.
  wafer target ssh  SSH into a target (workspace or host).
  wafer target sync  Sync local files to a target.
  wafer target pull  Pull files from a target to local machine.
  wafer target init  Initialize a new accelerator target.

### `wafer agent`
AI assistant for GPU kernel development.

Examples:
    wafer agent                          # interactive TUI
    wafer agent "optimize this kernel"   # with initial prompt
    wafer agent --cloud -t optimize ...  # run on cloud

Options:
  --interactive/-i  Launch full interactive TUI mode (default when no prompt given)
  --simple  Use simple stdout mode instead of TUI (for scripts/pipes)
  --resume/-r TEXT  Resume session by ID (or 'last' for most recent)
  --list-sessions  List recent sessions and exit
  --get-session TEXT  Get session by ID and print messages (use with --json)
  --allow-spawn  Allow wafer tool to spawn sub-agents (nested wafer agent calls)
  --max-tool-fails INTEGER  Exit after N consecutive tool failures
  --json/-j  Output in JSON format (stream-json style)
  --list-templates  List available templates with descriptions and args, then exit
  --template/-t TEXT  Run with template (use --list-templates to see all available)
  --args TEXT  Template variable (KEY=VALUE, can be repeated)
  --output-format TEXT  Output format: 'stream-json' (Claude Code-compatible NDJSON) or 'chunk' (real-time deltas)
  --single-turn  Answer once and exit (no interactive follow-up). Required for stream-json/cloud.
  --cloud  Run agent on remote server via cloud API
  --repo TEXT  Clone repo on cloud server (use with --cloud)
  --dir/-d PATH  Upload local directory to cloud agent (use with --cloud, e.g. --dir . for cwd, respects .gitignore)

### `wafer settings skill`
Manage AI coding assistant skills (Claude Code, Codex)

Subcommands:
  wafer settings skill install  Install the wafer-guide skill for AI coding assistants.
  wafer settings skill uninstall  Uninstall the wafer-guide skill.
  wafer settings skill status  Show installation status of the wafer-guide skill.
