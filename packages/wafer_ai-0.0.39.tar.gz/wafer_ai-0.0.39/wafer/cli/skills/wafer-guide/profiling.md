# Profiling Workflows

## Trace Analysis

Analyze PyTorch profiler or Perfetto traces:

```bash
# Direct trace queries (PyTorch/Perfetto JSON)
wafer tool perfetto query trace.json \
  "SELECT name, dur/1e6 as ms FROM slice WHERE cat='kernel' ORDER BY dur DESC LIMIT 10"
```

## Roofline Analysis

Analyze kernel performance against hardware limits:

```bash
# Compute-bound kernel (e.g., large matmul)
wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85

# Memory-bound kernel (e.g., elementwise op)
wafer tool roofline --gpu H100 --bytes 4e9 --flops 1e9 --time-ms 2

# JSON output for scripting
wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85 --json

# List supported GPUs
wafer tool roofline --list-gpus
```

Output includes: peak specs, achieved compute/bandwidth with % of peak, bottleneck classification (COMPUTE BOUND / MEMORY BOUND), and efficiency assessment.

## Documentation Lookup

Query GPU documentation (uses wafer API — no local download needed):

```bash
wafer agent -t ask-docs "What is warp divergence?"
wafer agent -t ask-docs "What is a TiledMma in CUTLASS?"
```
