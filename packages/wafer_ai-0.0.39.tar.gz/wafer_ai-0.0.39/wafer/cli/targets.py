"""Target management for Wafer CLI.

Targets are stored in Supabase (user_targets) via the API.
Default target and pools remain in ~/.wafer/config.toml.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import tomllib

from wafer.core.utils.kernel_utils.targets.config import (
    BaremetalTarget,
    ModalTarget,
    TargetConfig,
    VMTarget,
    WorkspaceTarget,
)

_log = logging.getLogger(__name__)

WAFER_DIR = Path.home() / ".wafer"
CONFIG_FILE = WAFER_DIR / "config.toml"

_SENTINEL = object()
_cache_default_target: object = _SENTINEL
_cache_target_names: list[str] | None = None
_cache_loaded_targets: dict[str, TargetConfig | None] = {}


def invalidate_target_cache() -> None:
    """Reset all target caches. Call after mutating targets (create, delete, set-default)."""
    global _cache_default_target, _cache_target_names, _cache_loaded_targets  # noqa: PLW0603
    _cache_default_target = _SENTINEL
    _cache_target_names = None
    _cache_loaded_targets.clear()


def load_target(name: str) -> TargetConfig:
    """Load target config by name from the API. Results are cached for the process lifetime."""
    if name in _cache_loaded_targets:
        cached = _cache_loaded_targets[name]
        if cached is None:
            raise FileNotFoundError(
                f"Target not found: {name}\n"
                f"  Register with: wafer target init ssh --name {name} --host <user>@<host>"
            )
        return cached
    from wafer.cli.user_targets_api import get_target_by_name, user_target_to_baremetal_target
    t = get_target_by_name(name)
    if t is None:
        _cache_loaded_targets[name] = None
        raise FileNotFoundError(
            f"Target not found: {name}\n"
            f"  Register with: wafer target init ssh --name {name} --host <user>@<host>"
        )
    result = user_target_to_baremetal_target(t)
    _cache_loaded_targets[name] = result
    return result


def list_targets() -> list[str]:
    """List all configured target names from the API.
    Returns empty list when not authenticated (avoids crashing target/sandbox list).
    Results are cached for the process lifetime.
    """
    global _cache_target_names  # noqa: PLW0603
    if _cache_target_names is not None:
        return list(_cache_target_names)
    import httpx

    from wafer.cli.user_targets_api import list_targets as list_user_targets

    try:
        raw = list_user_targets()
    except RuntimeError:
        _cache_target_names = []
        return []
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            _cache_target_names = []
            return []
        raise
    result: list[str] = []
    for t in raw:
        name = t.get("name")
        if name:
            result.append(name)
    _cache_target_names = sorted(result)
    return list(_cache_target_names)


def remove_target(name: str) -> None:
    """Remove target via API."""
    from wafer.cli.user_targets_api import delete_target as api_delete_target
    api_delete_target(name)
    invalidate_target_cache()


def get_default_target() -> str | None:
    """Get default target name. Tries API first, falls back to local config.toml for offline/workspace.
    Results are cached for the process lifetime.
    """
    global _cache_default_target  # noqa: PLW0603
    if _cache_default_target is not _SENTINEL:
        return _cache_default_target  # type: ignore[return-value]
    result: str | None = None
    try:
        from wafer.cli.user_targets_api import get_default_target_api
        t = get_default_target_api()
        if t:
            result = t.get("name")
    except (RuntimeError, Exception):
        pass
    if result is None and CONFIG_FILE.exists():
        with open(CONFIG_FILE, "rb") as f:
            data = tomllib.load(f)
        default = data.get("default_target")
        if default:
            result = default
    _cache_default_target = result
    return result


def get_target_type(name: str) -> str | None:
    """Get the type of a target without fully loading it."""
    try:
        from wafer.cli.user_targets_api import get_target_by_name
        if get_target_by_name(name) is not None:
            return "baremetal"
    except (RuntimeError, Exception):
        pass
    return None




def _write_toml(path: Path, data: dict[str, Any]) -> None:
    """Write dict as flat TOML file. Used for config.toml."""
    lines = []
    for key, value in data.items():
        if value is None:
            continue
        if isinstance(value, bool):
            lines.append(f"{key} = {str(value).lower()}")
        elif isinstance(value, int | float):
            lines.append(f"{key} = {value}")
        elif isinstance(value, str):
            lines.append(f'{key} = "{value}"')
        elif isinstance(value, list):
            if all(isinstance(v, int) for v in value):
                lines.append(f"{key} = {value}")
            else:
                formatted = ", ".join(f'"{v}"' if isinstance(v, str) else str(v) for v in value)
                lines.append(f"{key} = [{formatted}]")
    path.write_text("\n".join(lines) + "\n")


def set_default_target(name: str) -> None:
    """Set default target via API (user_targets only). Also caches in config.toml for offline/workspace fallback."""
    invalidate_target_cache()
    from wafer.cli.user_targets_api import get_target_by_name, set_default_target_api
    t = get_target_by_name(name)
    if t is None:
        try:
            from .workspaces import _list_workspaces_raw
            ws_names = [ws.get("name") for ws in _list_workspaces_raw()]
            if name not in ws_names:
                raise FileNotFoundError(
                    f"Target not found: {name}\n"
                    "  List targets: wafer target list"
                )
        except (ImportError, RuntimeError, OSError):
            raise FileNotFoundError(
                f"Target not found: {name}\n"
                "  List targets: wafer target list"
            )
    else:
        set_default_target_api(t["id"])
    WAFER_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "rb") as f:
            data = tomllib.load(f)
    else:
        data = {}
    data["default_target"] = name
    _write_toml(CONFIG_FILE, data)


def get_target_info(target: TargetConfig) -> dict[str, str]:
    info = {}
    if isinstance(target, BaremetalTarget):
        info["Type"] = "Baremetal"
        info["SSH"] = target.ssh_target
        info["GPU"] = target.gpu_type
        info["Device IDs"] = ", ".join(str(g) for g in target.gpu_ids)
        info["NCU"] = "Yes" if target.ncu_available else "No"
        if target.docker_image:
            info["Docker"] = target.docker_image
            if target.pip_packages:
                info["Packages"] = ", ".join(target.pip_packages)
            if target.torch_package:
                info["Torch"] = target.torch_package
    elif isinstance(target, VMTarget):
        info["Type"] = "VM"
        info["SSH"] = target.ssh_target
        info["GPU"] = target.gpu_type
        info["Device IDs"] = ", ".join(str(g) for g in target.gpu_ids)
        info["NCU"] = "Yes" if target.ncu_available else "No"
        if target.docker_image:
            info["Docker"] = target.docker_image
            if target.pip_packages:
                info["Packages"] = ", ".join(target.pip_packages)
            if target.torch_package:
                info["Torch"] = target.torch_package
    elif isinstance(target, ModalTarget):
        info["Type"] = "Modal"
        info["App"] = target.modal_app_name
        info["GPU"] = target.gpu_type
        info["Timeout"] = f"{target.timeout_seconds}s"
        info["NCU"] = "No (Modal)"
    elif isinstance(target, WorkspaceTarget):
        info["Type"] = "Workspace"
        info["Workspace ID"] = target.workspace_id
        info["GPU"] = target.gpu_type
        info["Timeout"] = f"{target.timeout_seconds}s"
        info["NCU"] = "No (Workspace)"
    compute_cap = getattr(target, "compute_capability", "")
    if compute_cap:
        info["Compute"] = compute_cap
    return info


_PROBE_SCRIPT = """
import json
import shutil
import sys
def probe():
    result = {
        "python_version": sys.version.split()[0],
        "backends": {},
        "packages": {},
    }
    try:
        import triton
        result["backends"]["triton"] = triton.__version__
    except ImportError:
        result["backends"]["triton"] = None
    try:
        import torch
        result["packages"]["torch"] = torch.__version__
        result["backends"]["torch"] = torch.__version__
        result["cuda_available"] = torch.cuda.is_available()
        if torch.cuda.is_available():
            result["gpu_name"] = torch.cuda.get_device_name(0)
            props = torch.cuda.get_device_properties(0)
            result["compute_capability"] = f"{props.major}.{props.minor}"
    except ImportError:
        result["packages"]["torch"] = None
    hipcc = shutil.which("hipcc")
    result["backends"]["hipcc"] = hipcc
    nvcc = shutil.which("nvcc")
    result["backends"]["nvcc"] = nvcc
    try:
        with open("/opt/rocm/.info/version", "r") as f:
            result["rocm_version"] = f.read().strip()
    except Exception:
        result["rocm_version"] = None
    if nvcc:
        import subprocess
        try:
            out = subprocess.check_output([nvcc, "--version"], text=True)
            for line in out.split("\\n"):
                if "release" in line.lower():
                    parts = line.split("release")
                    if len(parts) > 1:
                        result["cuda_version"] = parts[1].split(",")[0].strip()
                    break
        except Exception:
            pass
    print(json.dumps(result))
if __name__ == "__main__":
    probe()
"""


class ProbeError(Exception):
    pass


def _run_ssh_cmd(
    ssh_target: str, port: str, key_path: str, cmd: str, timeout_hint: str,
) -> tuple[int, str, str]:
    assert ssh_target, "ssh_target must be a non-empty string"
    assert port, "port must be a non-empty string"
    assert key_path, "key_path must be a non-empty string"
    assert cmd, "cmd must be a non-empty string"
    import subprocess
    try:
        result = subprocess.run(
            [
                "ssh",
                "-o", "StrictHostKeyChecking=no",
                "-o", "UserKnownHostsFile=/dev/null",
                "-o", "ConnectTimeout=30",
                "-i", str(key_path),
                "-p", str(port),
                ssh_target,
                cmd,
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        raise ProbeError(
            f"SSH connection timed out\n"
            f"  Host: {ssh_target}:{port}\n"
            f"  Hint: {timeout_hint}"
        ) from None


def _run_probe_and_parse(
    ssh_target: str, port: str, key_path: str, python_exe: str, target_name: str,
) -> dict[str, Any]:
    assert ssh_target, "ssh_target must be a non-empty string"
    assert python_exe, "python_exe must be a non-empty string"
    assert target_name, "target_name must be a non-empty string"
    import json
    escaped_script = _PROBE_SCRIPT.replace("'", "'\"'\"'")
    code, out, err = _run_ssh_cmd(
        ssh_target, port, key_path,
        f"{python_exe} -c '{escaped_script}'",
        "Check if the host is reachable and SSH is running.",
    )
    if code != 0:
        raise ProbeError(
            f"Probe script failed on target '{target_name}'\n"
            f"  Exit code: {code}\n"
            f"  Error: {err.strip() if err else 'unknown'}\n"
            f"  Hint: Ensure python3 is installed on the target."
        )
    try:
        return json.loads(out)
    except json.JSONDecodeError as e:
        raise ProbeError(
            f"Failed to parse probe output from '{target_name}'\n"
            f"  Error: {e}\n"
            f"  Output: {out[:200]}..."
        ) from None


def _probe_ssh_target(target: BaremetalTarget | VMTarget) -> dict[str, Any]:
    from wafer.core.ssh_utils import parse_ssh_target

    assert target is not None, "SSH target required"
    assert target.ssh_target, "target must have a non-empty ssh_target"
    parsed = parse_ssh_target(target.ssh_target)
    user, host, port = parsed.user, parsed.host, str(parsed.port)
    ssh_target = f"{user}@{host}"
    key_path = str(target.ssh_key)
    code, _, err = _run_ssh_cmd(
        ssh_target, port, key_path, "echo OK",
        "Check if the host is reachable and SSH is running.",
    )
    if code != 0:
        raise ProbeError(
            f"SSH connection failed to target '{target.name}'\n"
            f"  Host: {user}@{host}:{port}\n"
            f"  Key: {target.ssh_key}\n"
            f"  Error: {err.strip() if err else 'connection refused or timeout'}\n"
            f"  Hint: Verify the host is reachable and the SSH key is authorized."
        )
    return _run_probe_and_parse(ssh_target, port, key_path, "python3", target.name)


async def probe_target_capabilities(target: TargetConfig) -> dict[str, Any]:
    if isinstance(target, (BaremetalTarget, VMTarget)):
        return _probe_ssh_target(target)
    raise ProbeError(
        f"Probing not supported for target type: {type(target).__name__}\n"
        f"  Supported types: Baremetal, VM"
    )
