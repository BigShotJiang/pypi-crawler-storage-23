# Gems (Custom System Prompts)

## Overview

Gems are custom personas / system prompts in Gemini. Users can create, list,
update, and delete custom Gems. System-provided Gems are also accessible.

## RPC Calls

All Gems operations use the batchexecute endpoint.

### List Gems (CNgdBe)

**RPC ID**: `CNgdBe` (LIST_GEMS)

Two separate calls needed:

```python
# System (predefined) gems
payload = "[null, 0]"

# Custom (user-created) gems
payload = "[null, 1]"
```

**Response structure** (per gem in `part_body[2]`):

| Path | Content |
|------|---------|
| `gem[0]` | Gem ID |
| `gem[1][0]` | Name |
| `gem[1][1]` | Description |
| `gem[2][0]` | System prompt |

### Create Gem (oMH3Zd)

**RPC ID**: `oMH3Zd` (CREATE_GEM)

```python
payload = json.dumps([name, description, prompt, None, None, None, None, None, 1])
```

### Update Gem (kHv0Vd)

**RPC ID**: `kHv0Vd` (UPDATE_GEM)

```python
payload = json.dumps([gem_id, [name, description, prompt, None, None, None, None, None, 1]])
```

### Delete Gem (UXcSJb)

**RPC ID**: `UXcSJb` (DELETE_GEM)

```python
payload = json.dumps([gem_id])
```

## Using a Gem in Chat

To use a Gem in a chat, set `inner_req_list[19] = gem_id` in the StreamGenerate
request. This applies the Gem's system prompt to the conversation.

## Data Model

```python
class Gem:
    id: str           # Unique identifier
    name: str         # Display name
    description: str  # Short description
    prompt: str       # System prompt text
    predefined: bool  # True for system gems, False for custom
```

## GemJar (Collection)

A dictionary of Gems keyed by ID, with helper methods:
- `get(id)` or `get(name)` - Find gem by ID or name
- `filter(predefined=True)` - Filter by type
- `filter(name="...")` - Filter by name substring
