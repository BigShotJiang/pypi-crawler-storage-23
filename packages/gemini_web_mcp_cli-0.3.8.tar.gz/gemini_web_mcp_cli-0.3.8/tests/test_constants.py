"""Tests for core constants."""

from gemini_web_mcp_cli.core.constants import (
    DEFAULT_MODEL,
    GEMINI_HEADERS,
    MODELS,
    RESPONSE_PATHS,
    RPC,
    Endpoint,
    ErrorCode,
    Model,
    get_model,
)


class TestEndpoints:
    def test_init_endpoint(self):
        assert Endpoint.INIT == "https://gemini.google.com/app"

    def test_generate_endpoint(self):
        assert "StreamGenerate" in Endpoint.GENERATE

    def test_batch_exec_endpoint(self):
        assert "batchexecute" in Endpoint.BATCH_EXEC

    def test_upload_endpoint(self):
        assert "content-push.googleapis.com" in Endpoint.UPLOAD

    def test_rotate_cookies_endpoint(self):
        assert "RotateCookies" in Endpoint.ROTATE_COOKIES


class TestRPCIds:
    def test_known_rpcs_from_gemini_webapi(self):
        assert RPC.LIST_CHATS == "MaZiqc"
        assert RPC.READ_CHAT == "hNvQHb"
        assert RPC.DELETE_CHAT == "GzXR5e"
        assert RPC.LIST_GEMS == "CNgdBe"
        assert RPC.CREATE_GEM == "oMH3Zd"
        assert RPC.UPDATE_GEM == "kHv0Vd"
        assert RPC.DELETE_GEM == "UXcSJb"
        assert RPC.BARD_ACTIVITY == "ESY5D"

    def test_discovered_rpcs(self):
        assert RPC.STATUS_POLL == "aPya6c"
        assert RPC.ASYNC_POLL == "kwDCne"
        assert RPC.POST_PROCESS == "PCck7e"
        assert RPC.INIT_CONFIG == "otAQ7b"


class TestModels:
    def test_known_models(self):
        assert "fast" in MODELS
        assert "thinking" in MODELS
        assert "pro" in MODELS
        assert "unspecified" in MODELS

    def test_model_header(self):
        model = MODELS["pro"]
        header = model.header
        assert "x-goog-ext-525001261-jspb" in header
        assert "e6fa609c3fa255c0" in header["x-goog-ext-525001261-jspb"]

    def test_thinking_model_hash(self):
        model = MODELS["thinking"]
        assert model.hash == "e051ce1aa80aa576"

    def test_fast_model_hash(self):
        model = MODELS["fast"]
        assert model.hash == "56fdd199312815e2"

    def test_unspecified_model_has_no_header(self):
        model = MODELS["unspecified"]
        assert model.header == {}

    def test_default_model(self):
        assert DEFAULT_MODEL.name == "fast"
        assert DEFAULT_MODEL.hash == "56fdd199312815e2"

    def test_get_model_valid(self):
        model = get_model("pro")
        assert model.name == "pro"

    def test_get_model_by_alias(self):
        assert get_model("flash").name == "fast"
        assert get_model("default").name == "fast"

    def test_get_model_invalid(self):
        try:
            get_model("nonexistent-model")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "nonexistent-model" in str(e)

    def test_model_equality(self):
        a = Model("test", "abc")
        b = Model("test", "abc")
        assert a == b

    def test_model_repr(self):
        m = Model("test", "abc123")
        assert "test" in repr(m)
        assert "abc123" in repr(m)


class TestErrorCodes:
    def test_error_code_values(self):
        assert ErrorCode.TEMPORARY_ERROR == 1013
        assert ErrorCode.USAGE_LIMIT_EXCEEDED == 1037
        assert ErrorCode.MODEL_INCONSISTENT == 1050
        assert ErrorCode.MODEL_HEADER_INVALID == 1052
        assert ErrorCode.IP_TEMPORARILY_BLOCKED == 1060


class TestHeaders:
    def test_gemini_headers_has_required_fields(self):
        assert "Content-Type" in GEMINI_HEADERS
        assert "Host" in GEMINI_HEADERS
        assert "Origin" in GEMINI_HEADERS
        assert "X-Same-Domain" in GEMINI_HEADERS

    def test_user_agent_is_chrome(self):
        assert "Chrome" in GEMINI_HEADERS["User-Agent"]


class TestResponsePaths:
    def test_required_paths_exist(self):
        assert "metadata" in RESPONSE_PATHS
        assert "candidates" in RESPONSE_PATHS
        assert "error_code" in RESPONSE_PATHS
        assert "candidate_text" in RESPONSE_PATHS
        assert "candidate_generated_images" in RESPONSE_PATHS
