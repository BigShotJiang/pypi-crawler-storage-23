"""Tests for watermark removal pipeline."""

import io

import pytest
from PIL import Image

from gemini_web_mcp_cli.core.watermark import (
    _ALPHA_MAPS,
    LOGO_VALUE,
    _alpha_map_cache,
    _decode_alpha_map,
    _get_watermark_params,
    _reverse_alpha_blend,
    remove_watermark,
)


class TestAlphaMapDecoding:
    """Test base64 alpha map decoding."""

    def setup_method(self):
        """Clear cache between tests."""
        _alpha_map_cache.clear()

    def test_small_map_exists(self):
        assert 48 in _ALPHA_MAPS

    def test_large_map_exists(self):
        assert 96 in _ALPHA_MAPS

    def test_decode_small_map_length(self):
        alpha = _decode_alpha_map(_ALPHA_MAPS[48], 48)
        assert len(alpha) == 48 * 48

    def test_decode_large_map_length(self):
        alpha = _decode_alpha_map(_ALPHA_MAPS[96], 96)
        assert len(alpha) == 96 * 96

    def test_decoded_values_normalized(self):
        alpha = _decode_alpha_map(_ALPHA_MAPS[48], 48)
        for v in alpha:
            assert 0.0 <= v <= 1.0

    def test_decoded_values_not_all_zero(self):
        alpha = _decode_alpha_map(_ALPHA_MAPS[48], 48)
        assert any(v > 0.0 for v in alpha)

    def test_decode_caches_result(self):
        a1 = _decode_alpha_map(_ALPHA_MAPS[48], 48)
        a2 = _decode_alpha_map(_ALPHA_MAPS[48], 48)
        assert a1 is a2


class TestSizeDetection:
    """Test watermark size auto-detection and positioning."""

    def test_small_image_gets_48(self):
        logo_size, margin, x, y = _get_watermark_params(512, 512)
        assert logo_size == 48
        assert margin == 32

    def test_one_dim_small_gets_48(self):
        logo_size, _, _, _ = _get_watermark_params(2048, 512)
        assert logo_size == 48

    def test_large_image_gets_96(self):
        logo_size, margin, x, y = _get_watermark_params(2048, 2048)
        assert logo_size == 96
        assert margin == 64

    def test_position_bottom_right(self):
        logo_size, margin, x, y = _get_watermark_params(1000, 800)
        assert x == 1000 - 32 - 48
        assert y == 800 - 32 - 48

    def test_force_size_overrides(self):
        logo_size, _, _, _ = _get_watermark_params(100, 100, force_size=96)
        assert logo_size == 96

    def test_force_size_invalid_raises(self):
        with pytest.raises(ValueError, match="No alpha map"):
            _get_watermark_params(100, 100, force_size=999)


class TestReverseAlphaBlend:
    """Test the core reverse alpha compositing math."""

    def test_no_change_below_threshold(self):
        img = Image.new("RGB", (10, 10), (128, 128, 128))
        alpha_map = [0.0] * 100
        result = _reverse_alpha_blend(img, 0, 0, 10, 10, alpha_map)
        raw = result.tobytes()
        for i in range(0, len(raw), 3):
            assert (raw[i], raw[i + 1], raw[i + 2]) == (128, 128, 128)

    def test_reversal_with_known_alpha(self):
        original_color = (100, 150, 200)
        alpha = 0.5
        composited = tuple(
            int(alpha * LOGO_VALUE + (1 - alpha) * c) for c in original_color
        )
        img = Image.new("RGB", (1, 1), composited)
        alpha_map = [alpha]
        result = _reverse_alpha_blend(img, 0, 0, 1, 1, alpha_map)
        raw = result.tobytes()
        recovered = (raw[0], raw[1], raw[2])
        for orig, rec in zip(original_color, recovered):
            assert abs(orig - rec) <= 1


class TestRemoveWatermark:
    """Test the public remove_watermark function."""

    def test_returns_png_bytes(self):
        img = Image.new("RGB", (512, 512), (200, 200, 200))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        result = remove_watermark(buf.getvalue())
        assert result[:8] == b"\x89PNG\r\n\x1a\n"

    def test_fallback_on_invalid_input(self):
        bad_data = b"not an image at all"
        result = remove_watermark(bad_data)
        assert result == bad_data

    def test_preserves_dimensions(self):
        img = Image.new("RGB", (800, 600), (100, 100, 100))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        result = remove_watermark(buf.getvalue())
        out = Image.open(io.BytesIO(result))
        assert out.size == (800, 600)

    def test_force_size_parameter(self):
        img = Image.new("RGB", (200, 200), (100, 100, 100))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        result = remove_watermark(buf.getvalue(), force_size=48)
        assert result[:8] == b"\x89PNG\r\n\x1a\n"
