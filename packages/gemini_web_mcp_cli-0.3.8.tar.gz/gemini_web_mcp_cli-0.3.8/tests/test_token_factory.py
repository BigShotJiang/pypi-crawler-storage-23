"""Tests for the Token Factory: constants, dataclass, and routing logic."""

import base64
import hashlib

from gemini_web_mcp_cli.core.constants import (
    CHROME_HEADERS,
    CHROME_USER_AGENT,
    TOKEN_FACTORY_MODELS,
    XBV_API_KEY,
    compute_xbv,
)
from gemini_web_mcp_cli.core.token_factory import CapturedRequest


class TestComputeXbv:
    """Tests for the x-browser-validation computation."""

    def test_known_answer(self):
        """Verify compute_xbv produces BASE64(SHA1(API_KEY + UA))."""
        expected = base64.b64encode(
            hashlib.sha1((XBV_API_KEY + CHROME_USER_AGENT).encode()).digest()
        ).decode()
        assert compute_xbv(CHROME_USER_AGENT) == expected

    def test_deterministic(self):
        """Same input always produces same output."""
        result1 = compute_xbv(CHROME_USER_AGENT)
        result2 = compute_xbv(CHROME_USER_AGENT)
        assert result1 == result2

    def test_different_ua_different_result(self):
        """Different user agents produce different results."""
        result1 = compute_xbv(CHROME_USER_AGENT)
        result2 = compute_xbv("SomeOtherUA/1.0")
        assert result1 != result2

    def test_result_is_base64(self):
        """Result should be valid base64."""
        result = compute_xbv(CHROME_USER_AGENT)
        # Should be decodable as base64
        decoded = base64.b64decode(result)
        # SHA-1 produces 20 bytes
        assert len(decoded) == 20


class TestCapturedRequest:
    """Tests for the CapturedRequest dataclass."""

    def test_construction(self):
        """CapturedRequest can be constructed with all fields."""
        req = CapturedRequest(
            url="https://gemini.google.com/_/BardChatUi/data/StreamGenerate",
            body="f.req=test&at=token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            cookies={"__Secure-1PSID": "abc123"},
        )
        assert "StreamGenerate" in req.url
        assert req.body == "f.req=test&at=token"
        assert req.headers["Content-Type"] == "application/x-www-form-urlencoded"
        assert req.cookies["__Secure-1PSID"] == "abc123"

    def test_field_access(self):
        """All fields are accessible."""
        req = CapturedRequest(
            url="https://example.com",
            body="body",
            headers={"h1": "v1", "h2": "v2"},
            cookies={"c1": "v1"},
        )
        assert req.url == "https://example.com"
        assert req.body == "body"
        assert len(req.headers) == 2
        assert len(req.cookies) == 1


class TestChromeHeaders:
    """Tests for CHROME_HEADERS completeness."""

    def test_required_headers_present(self):
        """All headers needed for Chrome-like requests are present."""
        required = [
            "Accept",
            "Accept-Language",
            "Content-Type",
            "Origin",
            "Referer",
            "User-Agent",
            "X-Same-Domain",
            "x-browser-channel",
            "x-browser-year",
            "x-client-data",
            "Sec-Ch-Ua",
            "Sec-Ch-Ua-Mobile",
            "Sec-Ch-Ua-Platform",
            "Sec-Fetch-Dest",
            "Sec-Fetch-Mode",
            "Sec-Fetch-Site",
        ]
        for header in required:
            assert header in CHROME_HEADERS, f"Missing header: {header}"

    def test_origin_is_gemini(self):
        assert CHROME_HEADERS["Origin"] == "https://gemini.google.com"

    def test_user_agent_is_chrome(self):
        assert CHROME_HEADERS["User-Agent"] == CHROME_USER_AGENT
        assert "Chrome" in CHROME_USER_AGENT

    def test_content_type(self):
        assert "x-www-form-urlencoded" in CHROME_HEADERS["Content-Type"]


class TestTokenFactoryModels:
    """Tests for TOKEN_FACTORY_MODELS set."""

    def test_pro_requires_token_factory(self):
        assert "pro" in TOKEN_FACTORY_MODELS

    def test_thinking_requires_token_factory(self):
        assert "thinking" in TOKEN_FACTORY_MODELS

    def test_fast_does_not_require(self):
        assert "fast" not in TOKEN_FACTORY_MODELS

    def test_unspecified_does_not_require(self):
        assert "unspecified" not in TOKEN_FACTORY_MODELS


class TestNeedsTokenFactory:
    """Test the _needs_token_factory routing logic on GeminiClient."""

    def test_pro_needs_token_factory(self):
        from gemini_web_mcp_cli.core.client import GeminiClient
        from gemini_web_mcp_cli.core.constants import MODELS

        client = GeminiClient.__new__(GeminiClient)
        assert client._needs_token_factory(MODELS["pro"]) is True

    def test_thinking_needs_token_factory(self):
        from gemini_web_mcp_cli.core.client import GeminiClient
        from gemini_web_mcp_cli.core.constants import MODELS

        client = GeminiClient.__new__(GeminiClient)
        assert client._needs_token_factory(MODELS["thinking"]) is True

    def test_fast_does_not_need(self):
        from gemini_web_mcp_cli.core.client import GeminiClient
        from gemini_web_mcp_cli.core.constants import MODELS

        client = GeminiClient.__new__(GeminiClient)
        assert client._needs_token_factory(MODELS["fast"]) is False

    def test_unspecified_does_not_need(self):
        from gemini_web_mcp_cli.core.client import GeminiClient
        from gemini_web_mcp_cli.core.constants import MODELS

        client = GeminiClient.__new__(GeminiClient)
        assert client._needs_token_factory(MODELS["unspecified"]) is False
