"""Tests for the Chrome daemon manager."""

from __future__ import annotations

import json
import os
import time
from unittest.mock import patch

from gemini_web_mcp_cli.core.chrome_manager import (
    ChromeDaemonInfo,
    check_daemon_health,
    clear_daemon_info,
    is_process_alive,
    load_daemon_info,
    save_daemon_info,
)


class TestChromeDaemonInfo:
    """Tests for ChromeDaemonInfo dataclass."""

    def test_construction(self):
        info = ChromeDaemonInfo(
            pid=12345,
            port=9222,
            profile_name="personal",
            started_at=1708300000.0,
            headless=True,
            chrome_profile_path="/path/to/profile",
        )
        assert info.pid == 12345
        assert info.port == 9222
        assert info.profile_name == "personal"
        assert info.headless is True
        assert info.chrome_profile_path == "/path/to/profile"

    def test_to_dict(self):
        info = ChromeDaemonInfo(
            pid=42,
            port=9225,
            profile_name="work",
            started_at=1708300000.0,
            headless=False,
            chrome_profile_path="/test/path",
        )
        d = info.to_dict()
        assert d["pid"] == 42
        assert d["port"] == 9225
        assert d["profile_name"] == "work"
        assert d["headless"] is False
        assert d["chrome_profile_path"] == "/test/path"

    def test_from_dict(self):
        data = {
            "pid": 99,
            "port": 9223,
            "profile_name": "test",
            "started_at": 1708300000.0,
            "headless": True,
            "chrome_profile_path": "/some/path",
        }
        info = ChromeDaemonInfo.from_dict(data)
        assert info.pid == 99
        assert info.port == 9223
        assert info.profile_name == "test"

    def test_roundtrip(self):
        original = ChromeDaemonInfo(
            pid=777,
            port=9224,
            profile_name="roundtrip",
            started_at=time.time(),
            headless=True,
            chrome_profile_path="/round/trip",
        )
        d = original.to_dict()
        restored = ChromeDaemonInfo.from_dict(d)
        assert restored.pid == original.pid
        assert restored.port == original.port
        assert restored.profile_name == original.profile_name
        assert restored.headless == original.headless
        assert restored.started_at == original.started_at
        assert restored.chrome_profile_path == original.chrome_profile_path


class TestDaemonFilePersistence:
    """Tests for load/save/clear daemon info."""

    def test_load_nonexistent_returns_none(self, tmp_path):
        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=tmp_path / "chrome-daemon.json",
        ):
            assert load_daemon_info() is None

    def test_save_and_load_roundtrip(self, tmp_path):
        daemon_path = tmp_path / "chrome-daemon.json"
        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=daemon_path,
        ):
            info = ChromeDaemonInfo(
                pid=42,
                port=9222,
                profile_name="test",
                started_at=time.time(),
                headless=True,
                chrome_profile_path="/test",
            )
            save_daemon_info(info)
            assert daemon_path.exists()

            loaded = load_daemon_info()
            assert loaded is not None
            assert loaded.pid == 42
            assert loaded.port == 9222
            assert loaded.profile_name == "test"

    def test_load_corrupt_json_returns_none(self, tmp_path):
        daemon_path = tmp_path / "chrome-daemon.json"
        daemon_path.write_text("not valid json{{{")
        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=daemon_path,
        ):
            assert load_daemon_info() is None

    def test_load_missing_fields_returns_none(self, tmp_path):
        daemon_path = tmp_path / "chrome-daemon.json"
        daemon_path.write_text(json.dumps({"pid": 1}))
        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=daemon_path,
        ):
            assert load_daemon_info() is None

    def test_clear_removes_file(self, tmp_path):
        daemon_path = tmp_path / "chrome-daemon.json"
        daemon_path.write_text("{}")
        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=daemon_path,
        ):
            clear_daemon_info()
            assert not daemon_path.exists()

    def test_clear_nonexistent_is_noop(self, tmp_path):
        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=tmp_path / "chrome-daemon.json",
        ):
            # Should not raise
            clear_daemon_info()

    def test_save_creates_parent_dirs(self, tmp_path):
        daemon_path = tmp_path / "nested" / "dir" / "chrome-daemon.json"
        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=daemon_path,
        ):
            info = ChromeDaemonInfo(
                pid=1,
                port=9222,
                profile_name="test",
                started_at=time.time(),
                headless=True,
                chrome_profile_path="/test",
            )
            save_daemon_info(info)
            assert daemon_path.exists()


class TestIsProcessAlive:
    """Tests for process liveness checking."""

    def test_current_process_is_alive(self):
        # Our own PID is always alive, but won't have "chrome" in comm.
        # is_process_alive checks for "chrome" in ps output, so this will
        # return False for a python process. That's correct behavior.
        # We test the os.kill(pid, 0) path separately.
        pid = os.getpid()
        # os.kill should not raise for our own process
        try:
            os.kill(pid, 0)
            alive = True
        except OSError:
            alive = False
        assert alive is True

    def test_nonexistent_pid_is_not_alive(self):
        # PID 99999999 should not exist on any system
        assert is_process_alive(99999999) is False

    def test_chrome_process_detected(self):
        """Verify that a process with 'chrome' in comm is detected."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.stdout = "Google Chrome"
            with patch("os.kill"):  # Don't actually send signals
                assert is_process_alive(12345) is True

    def test_non_chrome_process_rejected(self):
        """Verify that a non-Chrome process is rejected (recycled PID protection)."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.stdout = "python3"
            with patch("os.kill"):
                assert is_process_alive(12345) is False


class TestCheckDaemonHealth:
    """Tests for the health check logic."""

    def test_no_daemon_file(self, tmp_path):
        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=tmp_path / "chrome-daemon.json",
        ):
            info, status = check_daemon_health()
            assert info is None
            assert status == "not_running"

    def test_stale_daemon_auto_cleans(self, tmp_path):
        daemon_path = tmp_path / "chrome-daemon.json"
        stale_info = ChromeDaemonInfo(
            pid=99999999,
            port=9222,
            profile_name="test",
            started_at=time.time(),
            headless=True,
            chrome_profile_path="/test",
        )
        daemon_path.write_text(json.dumps(stale_info.to_dict()))

        with patch(
            "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
            return_value=daemon_path,
        ):
            info, status = check_daemon_health()
            assert status == "stale"
            assert info is not None
            assert info.pid == 99999999
            # Daemon file should be auto-cleaned
            assert not daemon_path.exists()

    def test_running_daemon(self, tmp_path):
        daemon_path = tmp_path / "chrome-daemon.json"
        info = ChromeDaemonInfo(
            pid=12345,
            port=9222,
            profile_name="test",
            started_at=time.time(),
            headless=True,
            chrome_profile_path="/test",
        )
        daemon_path.write_text(json.dumps(info.to_dict()))

        with (
            patch(
                "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
                return_value=daemon_path,
            ),
            patch(
                "gemini_web_mcp_cli.core.chrome_manager.is_process_alive",
                return_value=True,
            ),
            patch(
                "gemini_web_mcp_cli.core.chrome_manager.is_chrome_responsive",
                return_value=True,
            ),
        ):
            loaded, status = check_daemon_health()
            assert status == "running"
            assert loaded.pid == 12345

    def test_unresponsive_daemon(self, tmp_path):
        daemon_path = tmp_path / "chrome-daemon.json"
        info = ChromeDaemonInfo(
            pid=12345,
            port=9222,
            profile_name="test",
            started_at=time.time(),
            headless=True,
            chrome_profile_path="/test",
        )
        daemon_path.write_text(json.dumps(info.to_dict()))

        with (
            patch(
                "gemini_web_mcp_cli.core.chrome_manager._daemon_file_path",
                return_value=daemon_path,
            ),
            patch(
                "gemini_web_mcp_cli.core.chrome_manager.is_process_alive",
                return_value=True,
            ),
            patch(
                "gemini_web_mcp_cli.core.chrome_manager.is_chrome_responsive",
                return_value=False,
            ),
        ):
            loaded, status = check_daemon_health()
            assert status == "unresponsive"
            assert loaded.pid == 12345
