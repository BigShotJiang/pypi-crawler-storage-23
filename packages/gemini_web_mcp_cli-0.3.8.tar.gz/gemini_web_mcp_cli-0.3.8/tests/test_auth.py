"""Tests for authentication manager."""

import pytest

from gemini_web_mcp_cli.core.auth import (
    AuthState,
    AuthTokens,
    extract_tokens,
)
from gemini_web_mcp_cli.core.exceptions import AuthError


class TestExtractTokens:
    def test_extracts_all_tokens(self):
        html = '''
        some content
        "SNlM0e":"token_abc_123"
        more content
        "cfb2h":"build_label_456"
        "FdrFJe":"session_id_789"
        '''
        tokens = extract_tokens(html)
        assert tokens.snlm0e == "token_abc_123"
        assert tokens.cfb2h == "build_label_456"
        assert tokens.fdrfje == "session_id_789"

    def test_extracts_snlm0e_with_spaces(self):
        html = '"SNlM0e": "spaced_token"'
        tokens = extract_tokens(html)
        assert tokens.snlm0e == "spaced_token"

    def test_missing_snlm0e_raises(self):
        html = '"cfb2h":"build_label"'
        with pytest.raises(AuthError, match="SNlM0e"):
            extract_tokens(html)

    def test_missing_optional_tokens_ok(self):
        html = '"SNlM0e":"token_only"'
        tokens = extract_tokens(html)
        assert tokens.snlm0e == "token_only"
        assert tokens.cfb2h == ""
        assert tokens.fdrfje == ""

    def test_empty_html_raises(self):
        with pytest.raises(AuthError):
            extract_tokens("")


class TestAuthTokens:
    def test_defaults(self):
        tokens = AuthTokens()
        assert tokens.snlm0e == ""
        assert tokens.cfb2h == ""
        assert tokens.fdrfje == ""


class TestAuthState:
    def test_to_dict_and_back(self):
        state = AuthState(
            cookies={"__Secure-1PSID": "cookie_val"},
            tokens=AuthTokens(snlm0e="tok", cfb2h="bl", fdrfje="sid"),
            chrome_profile_path="/path/to/profile",
        )
        d = state.to_dict()
        restored = AuthState.from_dict(d)
        assert restored.cookies["__Secure-1PSID"] == "cookie_val"
        assert restored.tokens.snlm0e == "tok"
        assert restored.tokens.cfb2h == "bl"
        assert restored.chrome_profile_path == "/path/to/profile"

    def test_is_valid_with_cookies_and_token(self):
        state = AuthState(
            cookies={"__Secure-1PSID": "val"},
            tokens=AuthTokens(snlm0e="tok"),
        )
        assert state.is_valid

    def test_is_valid_missing_cookie(self):
        state = AuthState(
            cookies={},
            tokens=AuthTokens(snlm0e="tok"),
        )
        assert not state.is_valid

    def test_is_valid_missing_token(self):
        state = AuthState(
            cookies={"__Secure-1PSID": "val"},
            tokens=AuthTokens(),
        )
        assert not state.is_valid

    def test_from_dict_empty(self):
        state = AuthState.from_dict({})
        assert not state.is_valid
        assert state.cookies == {}

    def test_from_dict_partial(self):
        state = AuthState.from_dict({"cookies": {"x": "y"}})
        assert state.cookies == {"x": "y"}
        assert state.tokens.snlm0e == ""
