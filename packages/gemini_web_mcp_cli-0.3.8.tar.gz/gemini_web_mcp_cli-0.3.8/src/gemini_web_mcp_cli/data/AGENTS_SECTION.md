<!-- gemini-skill-start -->

## Gemini Web MCP - CLI & MCP Expert

**Triggers:** "gemcli", "gemini web mcp", "gemini chat", "image generation", "video generation", "music generation", "deep research", "gems"

This section provides guidance for using Google Gemini via the `gemcli` CLI and `gemini-web-mcp` MCP server.

### Quick Reference

```bash
gemcli --ai                # Full AI-optimized documentation
gemcli --help              # List all commands
gemcli doctor              # Diagnose installation and auth
```

### Critical Rules

1. **Always authenticate first**: Run `gemcli login` before any operations
2. **Session expiry**: Re-run `gemcli login` if commands fail with auth errors
3. **Model selection**: Flash is default (no setup needed). Pro/Thinking require Token Factory
4. **Music generation requires Chrome**: Run `gemcli chrome start` first (BotGuard needed even on Flash)
5. **Background processes**: If running from LaunchAgent/cron, start persistent Chrome from interactive terminal first
6. **Use `--help` when unsure**: `gemcli <command> --help`

### Key Commands

```bash
# Chat
gemcli chat "prompt"                    # Single message
gemcli chat "prompt" -m gemini-3.0-pro  # Use Pro model
gemcli chat                             # Interactive REPL

# Image Generation
gemcli image "A sunset" -o sunset.png

# Video Generation (Veo 3.1)
gemcli video "Ocean waves" -o video.mp4

# Music Generation (Lyria 3)
gemcli music "A comical R&B slow jam about a sock"
gemcli music "Cats playing games" -s 8-bit -o track.mp3
gemcli music "Summer vibes" -s k-pop -o video.mp4 -f video
gemcli music --list-styles                  # Show all 16 style presets

# Deep Research
gemcli research "AI advances in 2026"

# Gems Management
gemcli gems list
gemcli gems create --name "Reviewer" --prompt "You are a code reviewer..."
gemcli gems delete <gem_id>

# Profile Management
gemcli profile list
gemcli profile switch <name>

# Persistent Chrome (required for music generation and background processes)
gemcli chrome start              # Start headless Chrome daemon
gemcli chrome status             # Check health and auth
gemcli chrome stop               # Stop daemon

# Diagnostics & Setup
gemcli doctor
gemcli setup add <tool>
gemcli skill install <tool>
```

### MCP Tools (when available)

| Tool | Actions | Key Parameters |
|------|---------|---------------|
| `chat` | send | prompt, model, conversation_id, extensions |
| `image` | generate, download | prompt, model, output_path, image_url |
| `video` | generate, status, download | prompt, model, output_path |
| `music` | generate, list_styles, download | prompt, style, output_path, download_url |
| `research` | start, status | query, model |
| `gems` | list, create, update, delete | gem_id, name, system_prompt |

### Common Workflows

**First-time setup:**
```bash
gemcli login && gemcli doctor
```

**Image generation pipeline:**
```bash
gemcli image "A futuristic cityscape" -o city.png
```

**Music generation pipeline:**
```bash
gemcli music "An upbeat pop song about coding" -o track.mp3
gemcli music "Epic battle theme" -s cinematic -o battle.mp3
```

**Research pipeline:**
```bash
gemcli research "Latest breakthroughs in quantum computing"
```

### Error Recovery

| Error | Solution |
|-------|----------|
| Auth expired | `gemcli login` |
| Model invalid | Check model name: flash, pro, thinking |
| Rate limited | Wait 30s, retry |
| Chrome error | Close Chrome, retry or use `--manual` |
| TokenFactoryError (background) | Start persistent Chrome: `gemcli chrome start` |

For full documentation, install the complete skill: `gemcli skill install <tool>`

<!-- gemini-skill-end -->
