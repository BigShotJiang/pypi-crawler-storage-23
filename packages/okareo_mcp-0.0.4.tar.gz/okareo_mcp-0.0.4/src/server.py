"""FastMCP server entry point for the Okareo MCP server.

Validates the API key at startup, registers all MCP tools, and runs the server.
Supports stdio (default) and SSE transports via the TRANSPORT environment variable.
"""

import os
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP

from src.key_registry import scan_provider_keys
from src.okareo_client import create_okareo_client
from src.tools import docs, models, scenarios, simulations, tests

_server_ready = False


@asynccontextmanager
async def lifespan(server: FastMCP):
    """Validate API key and initialize Okareo client at startup."""
    global _server_ready

    api_key = os.environ.get("OKAREO_API_KEY", "").strip()

    if not api_key:
        print(
            "OKAREO_API_KEY environment variable is not set. "
            "Get your API key from app.okareo.com and configure it "
            "in your MCP server settings."
        )
        raise SystemExit(1)

    base_url = os.environ.get("OKAREO_BASE_URL")

    try:
        okareo = create_okareo_client(api_key, base_url)
    except TypeError:
        print(
            "OKAREO_API_KEY is invalid. The Okareo API rejected the "
            "provided key. Verify your key at app.okareo.com."
        )
        raise SystemExit(1)
    except Exception as e:
        error_name = type(e).__name__
        if error_name in ("ConnectError", "TimeoutException", "ConnectTimeout"):
            target = base_url or "https://api.okareo.com"
            print(
                f"Cannot connect to the Okareo API at {target}. "
                "Check your network connection."
            )
            raise SystemExit(1)
        raise

    key_registry = scan_provider_keys()
    if key_registry:
        provider_names = ", ".join(sorted(key_registry.keys()))
        print(f"Provider keys loaded: {provider_names}")
    else:
        print("No provider API keys configured.")

    transport = os.environ.get("TRANSPORT", "stdio")
    port = os.environ.get("PORT", "8000")
    print(
        f"Okareo MCP server started successfully. "
        f"Transport: {transport}, Port: {port}"
    )
    _server_ready = True
    yield {"okareo": okareo, "key_registry": key_registry}
    _server_ready = False


mcp = FastMCP(
    "okareo-mcp",
    lifespan=lifespan,
    host=os.environ.get("FASTMCP_HOST", "127.0.0.1"),
    port=int(os.environ.get("FASTMCP_PORT", "8000")),
)

# Register all tools
tests.register_tools(mcp)
scenarios.register_tools(mcp)
models.register_tools(mcp)
simulations.register_tools(mcp)
docs.register_tools(mcp)


def main():
    """CLI entry point for okareo-mcp."""
    transport = os.environ.get("TRANSPORT", "stdio")

    if transport == "sse":
        from src.sse_middleware import SSEKeyMiddleware

        app = mcp.sse_app()
        app = SSEKeyMiddleware(app)
        import uvicorn

        host = os.environ.get("FASTMCP_HOST", "127.0.0.1")
        port = int(os.environ.get("FASTMCP_PORT", "8000"))
        uvicorn.run(app, host=host, port=port)
    else:
        mcp.run(transport=transport)


if __name__ == "__main__":
    main()
