"""Simulation tools for the Okareo MCP server.

Provides eight MCP tools for the multi-turn simulation workflow:

- create_target: Create or update a Target (Generation, Custom Endpoint, or Voice) by name
- get_target: Retrieve a Target's configuration by name (all types)
- list_targets: List all simulation targets (voice and custom_endpoint) in the project
- delete_target: Remove a simulation target and all its related test data
- create_driver: Create or update a Driver persona by name
- get_driver: Retrieve a Driver's configuration by name
- list_drivers: List all Drivers in the project
- run_simulation: Run a multi-turn simulation (or rerun an existing one with overrides)
"""

import json
from typing import Optional

from mcp.server.fastmcp import Context, FastMCP

from src.key_registry import sanitize_error
from src.okareo_client import get_okareo_client, resolve_project_id


def _get_attr(obj, attr, default=None):
    """Get an attribute, returning default if Unset."""
    val = getattr(obj, attr, default)
    if type(val).__name__ == "Unset":
        return default
    return val


def _serialize_value(val):
    """Serialize a value that may be Unset, a complex object, or a primitive."""
    if val is None:
        return None
    if type(val).__name__ == "Unset":
        return None
    if hasattr(val, "additional_properties"):
        return dict(val.additional_properties)
    if hasattr(val, "to_dict"):
        return val.to_dict()
    if isinstance(val, (dict, list, str, int, float, bool)):
        return val
    return str(val)


TWILIO_SENSITIVE_FIELDS = [
    "apikey",
    "authorization",
    "clientid",
    "clientsecret",
    "password",
    "secret",
    "token",
    "accesstoken",
    "refreshtoken",
]


def register_tools(mcp: FastMCP) -> None:
    """Register all simulation tools with the FastMCP server."""

    @mcp.tool()
    def create_target(
        name: str,
        type: str,
        # Generation target fields
        model_id: Optional[str] = None,
        temperature: float = 0.0,
        system_prompt_template: Optional[str] = None,
        user_prompt_template: Optional[str] = None,
        dialog_template: Optional[str] = None,
        tools: Optional[list] = None,
        # Custom endpoint fields (nested params)
        next_message_params: Optional[dict] = None,
        start_session_params: Optional[dict] = None,
        end_session_params: Optional[dict] = None,
        max_parallel_requests: Optional[int] = None,
        # Voice fields
        edge_type: Optional[str] = None,
        model: Optional[str] = None,
        output_voice: Optional[str] = None,
        instructions: Optional[str] = None,
        # Voice Twilio fields
        to_phone_number: Optional[str] = None,
        account_sid: Optional[str] = None,
        auth_token: Optional[str] = None,
        from_phone_number: Optional[str] = None,
    ) -> str:
        """Create or update a Target — the AI system you want to evaluate in a simulation.

        Calling create_target with the same name as an existing Target will update it
        (upsert semantics). Supported types: 'generation' (foundation model),
        'custom_endpoint' (your own REST API), and 'voice' (voice-based targets via
        OpenAI, Deepgram, or Twilio).

        Args:
            name: Unique name for this target.
            type: Target type — 'generation', 'custom_endpoint', or 'voice'.

            model_id: (generation targets) Foundation model ID, e.g. 'gpt-4o-mini'.
            temperature: (generation targets) Response randomness, default 0.
            system_prompt_template: (generation targets) System instructions; mustache
                syntax supported, e.g. '{scenario_input}'.
            user_prompt_template: (generation targets) User prompt template.
            dialog_template: (generation targets) Dialog formatting template.
            tools: (generation targets) Tool definitions for function calling.

            next_message_params: (custom_endpoint) Nested HTTP config for each
                conversation turn. Required keys: 'url', 'method'. Optional:
                'headers', 'body', 'status_code', 'response_message_path',
                'response_tool_calls_path'.
            start_session_params: (custom_endpoint, optional) Nested HTTP config to
                initialise a session. Required key: 'url'.
            end_session_params: (custom_endpoint, optional) Nested HTTP config to
                close a session after the last turn.
            max_parallel_requests: (custom_endpoint, twilio) Concurrency limit.

            edge_type: (voice targets) Voice provider — 'openai', 'deepgram',
                or 'twilio'.
            model: (voice openai/deepgram) Model identifier.
            output_voice: (voice openai/deepgram) Voice identifier.
            instructions: (voice openai/deepgram) Voice interaction instructions.

            to_phone_number: (voice twilio) Destination phone number (required).
            account_sid: (voice twilio, custom only) Twilio account SID. If provided,
                auth_token and from_phone_number are also required (all-or-nothing).
                Omit for generic Twilio targets using Okareo's managed integration.
            auth_token: (voice twilio, custom only) Twilio auth token. Required with
                account_sid and from_phone_number.
            from_phone_number: (voice twilio, custom only) Caller phone number. Required
                with account_sid and auth_token.
        """
        # --- Per-type validation (FR-017) ---
        if type not in ("generation", "custom_endpoint", "voice"):
            return json.dumps({
                "error": "type must be 'generation', 'custom_endpoint', or 'voice'.",
            })

        if type == "generation":
            if not model_id:
                return json.dumps({
                    "error": "model_id is required for generation targets.",
                })

        elif type == "custom_endpoint":
            if not next_message_params or not isinstance(next_message_params, dict):
                return json.dumps({
                    "error": "next_message_params with 'url' and 'method' is required for custom_endpoint targets.",
                })
            if "url" not in next_message_params or "method" not in next_message_params:
                return json.dumps({
                    "error": "next_message_params with 'url' and 'method' is required for custom_endpoint targets.",
                })

        elif type == "voice":
            if not edge_type:
                return json.dumps({
                    "error": "edge_type is required for voice targets.",
                })
            if edge_type in ("openai", "deepgram"):
                if not model or not output_voice:
                    return json.dumps({
                        "error": "model and output_voice are required for openai/deepgram voice targets.",
                    })
            elif edge_type == "twilio":
                if not to_phone_number:
                    return json.dumps({
                        "error": "to_phone_number is required for twilio voice targets.",
                    })
                if max_parallel_requests is None or max_parallel_requests < 1:
                    return json.dumps({
                        "error": "max_parallel_requests (integer >= 1) is required for twilio voice targets.",
                    })
                # Credential triple: all-or-nothing
                cred_values = [account_sid, auth_token, from_phone_number]
                cred_provided = [bool(v) for v in cred_values]
                if any(cred_provided) and not all(cred_provided):
                    return json.dumps({
                        "error": "Custom Twilio requires account_sid, auth_token, and from_phone_number together.",
                    })
            else:
                return json.dumps({
                    "error": "edge_type must be 'openai', 'deepgram', or 'twilio'.",
                })

        # --- Build target implementation ---
        from okareo.model_under_test import (
            CustomEndpointTarget,
            DeepgramVoiceTarget,
            EndSessionConfig,
            GenerationModel,
            OpenAIVoiceTarget,
            SessionConfig,
            Target,
            TurnConfig,
            TwilioVoiceTarget,
        )

        if type == "generation":
            gen_kwargs = dict(
                model_id=model_id,
                temperature=temperature,
            )
            if system_prompt_template is not None:
                gen_kwargs["system_prompt_template"] = system_prompt_template
            if user_prompt_template is not None:
                gen_kwargs["user_prompt_template"] = user_prompt_template
            if dialog_template is not None:
                gen_kwargs["dialog_template"] = dialog_template
            if tools is not None:
                gen_kwargs["tools"] = tools
            target_impl = GenerationModel(**gen_kwargs)

        elif type == "custom_endpoint":
            nmp = next_message_params
            # Auto-convert dict bodies to JSON strings
            nmp_body = nmp.get("body")
            if isinstance(nmp_body, dict):
                nmp_body = json.dumps(nmp_body)
            turn_config = TurnConfig(
                url=nmp["url"],
                method=nmp["method"],
                headers=nmp.get("headers"),
                body=nmp_body or "{}",
                status_code=nmp.get("status_code"),
                response_message_path=nmp.get("response_message_path", ""),
                response_tool_calls_path=nmp.get("response_tool_calls_path", ""),
            )

            session_config = None
            if start_session_params and isinstance(start_session_params, dict):
                ssp = start_session_params
                ssp_body = ssp.get("body")
                if isinstance(ssp_body, dict):
                    ssp_body = json.dumps(ssp_body)
                session_config = SessionConfig(
                    url=ssp["url"],
                    method=ssp.get("method", "POST"),
                    headers=ssp.get("headers"),
                    body=ssp_body or "{}",
                    status_code=ssp.get("status_code"),
                    response_session_id_path=ssp.get("response_session_id_path", ""),
                    response_message_path=ssp.get("response_message_path", ""),
                )
            else:
                # SDK requires start_session; create a minimal one from next_message_params URL
                session_config = SessionConfig(
                    url=nmp["url"],
                    body="{}",
                    response_session_id_path="",
                )

            end_config = None
            if end_session_params and isinstance(end_session_params, dict):
                esp = end_session_params
                esp_body = esp.get("body")
                if isinstance(esp_body, dict):
                    esp_body = json.dumps(esp_body)
                end_config = EndSessionConfig(
                    url=esp["url"],
                    method=esp.get("method", "POST"),
                    headers=esp.get("headers"),
                    body=esp_body or "{}",
                    status_code=esp.get("status_code"),
                    response_session_id_path=esp.get("response_session_id_path", ""),
                )

            target_impl = CustomEndpointTarget(
                start_session=session_config,
                next_turn=turn_config,
                end_session=end_config,
                max_parallel_requests=max_parallel_requests,
            )

        elif type == "voice":
            if edge_type == "openai":
                target_impl = OpenAIVoiceTarget(
                    model=model,
                    output_voice=output_voice,
                    instructions=instructions or "Be brief and helpful.",
                )
            elif edge_type == "deepgram":
                target_impl = DeepgramVoiceTarget(
                    model=model,
                    output_voice=output_voice,
                    instructions=instructions or "Be brief and helpful.",
                )
            elif edge_type == "twilio":
                target_impl = TwilioVoiceTarget(
                    to_phone_number=to_phone_number,
                    account_sid=account_sid or "",
                    auth_token=auth_token or "",
                    from_phone_number=from_phone_number or "",
                    max_parallel_requests=max_parallel_requests,
                )

        try:
            okareo = get_okareo_client()
        except Exception as e:
            return json.dumps({"error": str(e)})

        try:
            target = Target(name=name, target=target_impl)
            create_kwargs = {}
            if type == "voice" and edge_type == "twilio":
                create_kwargs["sensitive_fields"] = TWILIO_SENSITIVE_FIELDS
            result = okareo.create_or_update_target(target, **create_kwargs)
        except Exception as e:
            return json.dumps({"error": f"Failed to create/update target: {e}"})

        response = {
            "target_id": _get_attr(result, "id", ""),
            "name": _get_attr(result, "name", name),
            "type": type,
            "created": True,
            "message": f"Target '{name}' saved.",
        }
        if type == "voice" and edge_type:
            response["edge_type"] = edge_type
        return json.dumps(response)

    @mcp.tool()
    def get_target(name: str) -> str:
        """Check the current configuration of a test target.

        Retrieves a Target by name. Works for all target types (Generation,
        Custom Endpoint, and Voice).

        Args:
            name: Name of the target to retrieve.
        """
        from okareo_api_client.api.default import (
            get_all_models_under_test_v0_models_under_test_get,
        )
        from okareo_api_client.errors import UnexpectedStatus

        try:
            okareo = get_okareo_client()
            project_id = resolve_project_id(okareo)
        except Exception as e:
            return json.dumps({"error": str(e)})

        try:
            muts = get_all_models_under_test_v0_models_under_test_get.sync(
                client=okareo.client,
                project_id=project_id,
                api_key=okareo.api_key,
            )
        except UnexpectedStatus as e:
            if e.status_code == 200:
                muts = json.loads(e.content)
            else:
                return json.dumps({"error": f"Failed to retrieve targets: HTTP {e.status_code}"})
        except Exception as e:
            return json.dumps({"error": f"Failed to retrieve target: {e}"})

        if not muts or isinstance(muts, Exception):
            return json.dumps({
                "error": (
                    f"Target '{name}' not found. "
                    "Use create_target to create it first."
                ),
            })

        # Find by name
        for m in muts:
            if isinstance(m, dict):
                mut_name = m.get("name", "")
            else:
                mut_name = _get_attr(m, "name", "")
            if mut_name == name:
                if isinstance(m, dict):
                    target_id = m.get("id", "")
                    models_dict = m.get("models", {})
                else:
                    target_id = _get_attr(m, "id", "")
                    models_dict = _serialize_value(_get_attr(m, "models")) or {}

                # Determine target type and extract config
                target_type = None
                target_config = {}
                if isinstance(models_dict, dict):
                    for ttype in ("voice", "custom_endpoint", "generation"):
                        if ttype in models_dict:
                            target_type = ttype
                            raw = models_dict[ttype]
                            target_config = _serialize_value(raw) if raw else {}
                            break

                return json.dumps({
                    "target_id": target_id,
                    "name": mut_name,
                    "type": target_type,
                    "target": target_config,
                }, default=str)

        return json.dumps({
            "error": (
                f"Target '{name}' not found. "
                "Use create_target to create it first."
            ),
        })

    @mcp.tool()
    def list_targets() -> str:
        """Browse all simulation targets available in this project.

        Returns all simulation targets (voice and custom_endpoint types)
        created via create_target. Does not include generation models
        registered via register_generation_model — use list_generation_models
        for those.
        """
        from okareo_api_client.api.default import (
            get_all_models_under_test_v0_models_under_test_get,
        )
        from okareo_api_client.errors import UnexpectedStatus

        try:
            okareo = get_okareo_client()
            project_id = resolve_project_id(okareo)
        except Exception as e:
            return json.dumps({"error": str(e)})

        try:
            muts = get_all_models_under_test_v0_models_under_test_get.sync(
                client=okareo.client,
                project_id=project_id,
                api_key=okareo.api_key,
            )
        except UnexpectedStatus as e:
            if e.status_code == 200:
                muts = json.loads(e.content)
            else:
                return json.dumps({"error": f"Failed to list targets: HTTP {e.status_code}"})
        except Exception as e:
            return json.dumps({"error": f"Failed to list targets: {e}"})

        if not muts or isinstance(muts, Exception):
            return json.dumps({
                "targets": [],
                "count": 0,
                "message": "No simulation targets found. Use create_target to create one.",
            })

        target_type_keys = {"voice", "custom_endpoint"}
        result = []
        for m in muts:
            if isinstance(m, dict):
                models_dict = m.get("models", {})
            else:
                models_dict = _serialize_value(_get_attr(m, "models")) or {}

            if not isinstance(models_dict, dict):
                continue

            matched_types = target_type_keys.intersection(models_dict.keys())
            if not matched_types:
                continue

            target_type = next(iter(matched_types))
            if isinstance(m, dict):
                result.append({
                    "target_id": m.get("id", ""),
                    "name": m.get("name", ""),
                    "type": target_type,
                    "time_created": str(m.get("time_created", "")),
                })
            else:
                result.append({
                    "target_id": _get_attr(m, "id", ""),
                    "name": _get_attr(m, "name", ""),
                    "type": target_type,
                    "time_created": str(_get_attr(m, "time_created", "")),
                })

        if not result:
            return json.dumps({
                "targets": [],
                "count": 0,
                "message": "No simulation targets found. Use create_target to create one.",
            })

        return json.dumps({"targets": result, "count": len(result)}, default=str)

    @mcp.tool()
    def delete_target(name: str) -> str:
        """Remove a simulation target and all its related test data.

        Permanently deletes the target and cascades to associated
        test runs and test data points. This cannot be undone.

        Args:
            name: Name of the target to delete.
        """
        from okareo_api_client.api.default import (
            delete_model_under_test_v0_models_under_test_mut_id_delete,
        )

        try:
            okareo = get_okareo_client()
        except Exception as e:
            return json.dumps({"error": str(e)})

        # Look up target by name to get ID
        try:
            mut = okareo.get_model(name=name)
            mut_id = _get_attr(mut, "mut_id", "")
        except Exception:
            return json.dumps({
                "error": f"Target '{name}' not found. "
                "Use list_targets to see available targets.",
            })

        if not mut_id:
            return json.dumps({
                "error": f"Target '{name}' not found. "
                "Use list_targets to see available targets.",
            })

        # Delete
        try:
            delete_model_under_test_v0_models_under_test_mut_id_delete.sync(
                mut_id=mut_id,
                client=okareo.client,
                api_key=okareo.api_key,
            )
        except Exception as e:
            return json.dumps({"error": f"Failed to delete target: {e}"})

        return json.dumps({
            "deleted": True,
            "name": name,
            "message": (
                f"Deleted target '{name}'. Associated test runs and "
                "data points were also deleted."
            ),
        })

    @mcp.tool()
    def create_driver(
        name: str,
        prompt_template: str,
        model_id: Optional[str] = None,
        temperature: float = 0.6,
        voice_instructions: Optional[str] = None,
        voice_profile: Optional[str] = None,
        voice: Optional[str] = None,
    ) -> str:
        """Define a simulated user persona that will interact with your target.

        Creates or updates a Driver by name (upsert). The prompt_template is the full
        persona definition — include the persona's role, objectives, tactics, and
        behavioural constraints.

        Args:
            name: Unique name for this driver.
            prompt_template: Full driver persona prompt describing the simulated user's
                role, primary objectives, conversational tactics, and hard rules.
            model_id: Foundation model to power the driver (defaults to project default).
            temperature: Response randomness, default 0.6.
            voice_instructions: Voice-specific instructions for voice simulation scenarios.
            voice_profile: Voice profile identifier for voice simulations.
            voice: Voice identifier for voice simulations.
        """
        from okareo.model_under_test import Driver

        if not name:
            return json.dumps({"error": "name is required."})
        if not prompt_template:
            return json.dumps({"error": "prompt_template is required."})

        try:
            okareo = get_okareo_client()
        except Exception as e:
            return json.dumps({"error": str(e)})

        try:
            driver_kwargs = dict(
                name=name,
                prompt_template=prompt_template,
                model_id=model_id,
                temperature=temperature,
            )
            if voice_instructions is not None:
                driver_kwargs["voice_instructions"] = voice_instructions
            if voice_profile is not None:
                driver_kwargs["voice_profile"] = voice_profile
            if voice is not None:
                driver_kwargs["voice"] = voice
            driver = Driver(**driver_kwargs)
            result = okareo.create_or_update_driver(driver)
        except Exception as e:
            return json.dumps({"error": f"Failed to create/update driver: {e}"})

        return json.dumps({
            "driver_id": _get_attr(result, "id", ""),
            "name": _get_attr(result, "name", name),
            "model_id": _get_attr(result, "model_id", model_id),
            "temperature": _get_attr(result, "temperature", temperature),
            "time_created": str(_get_attr(result, "time_created", "")),
            "voice_instructions": _get_attr(result, "voice_instructions"),
            "voice_profile": _get_attr(result, "voice_profile"),
            "voice": _get_attr(result, "voice"),
            "created": True,
            "message": f"Driver '{name}' saved.",
        })

    @mcp.tool()
    def get_driver(name: str) -> str:
        """Retrieve a driver persona you've already configured.

        Retrieves a Driver by name, returning its full configuration including the
        persona prompt.

        Args:
            name: Name of the driver to retrieve.
        """
        try:
            okareo = get_okareo_client()
        except Exception as e:
            return json.dumps({"error": str(e)})

        try:
            result = okareo.get_driver_by_name(name)
        except Exception as e:
            error_str = str(e)
            if "not found" in error_str.lower() or "404" in error_str:
                return json.dumps({
                    "error": (
                        f"Driver '{name}' not found. "
                        "Use list_drivers to see available drivers."
                    ),
                })
            return json.dumps({"error": f"Failed to retrieve driver: {e}"})

        if result is None:
            return json.dumps({
                "error": (
                    f"Driver '{name}' not found. "
                    "Use list_drivers to see available drivers."
                ),
            })

        return json.dumps({
            "driver_id": _get_attr(result, "id", ""),
            "name": _get_attr(result, "name", name),
            "prompt_template": _get_attr(result, "prompt_template", ""),
            "model_id": _get_attr(result, "model_id"),
            "temperature": _get_attr(result, "temperature", 0.6),
            "time_created": str(_get_attr(result, "time_created", "")),
            "voice_instructions": _get_attr(result, "voice_instructions"),
            "voice_profile": _get_attr(result, "voice_profile"),
            "voice": _get_attr(result, "voice"),
        }, default=str)

    @mcp.tool()
    def list_drivers() -> str:
        """See what driver personas are available in this project.

        Returns all Drivers with their names, IDs, model, and temperature.
        """
        from okareo_api_client.api.default import (
            get_all_drivers_v0_drivers_get,
        )

        try:
            okareo = get_okareo_client()
            project_id = resolve_project_id(okareo)
        except Exception as e:
            return json.dumps({"error": str(e)})

        try:
            drivers = get_all_drivers_v0_drivers_get.sync(
                client=okareo.client,
                project_id=project_id,
                api_key=okareo.api_key,
            )
        except Exception as e:
            return json.dumps({"error": f"Failed to list drivers: {e}"})

        if not drivers or isinstance(drivers, Exception):
            return json.dumps({
                "drivers": [],
                "count": 0,
                "message": "No drivers found in project.",
            })

        result = []
        for d in drivers:
            if isinstance(d, dict):
                result.append({
                    "driver_id": d.get("id", ""),
                    "name": d.get("name", ""),
                    "model_id": d.get("model_id"),
                    "temperature": d.get("temperature", 0.6),
                    "time_created": d.get("time_created", ""),
                    "voice_instructions": d.get("voice_instructions"),
                    "voice_profile": d.get("voice_profile"),
                    "voice": d.get("voice"),
                })
            else:
                result.append({
                    "driver_id": _get_attr(d, "id", ""),
                    "name": _get_attr(d, "name", ""),
                    "model_id": _get_attr(d, "model_id"),
                    "temperature": _get_attr(d, "temperature", 0.6),
                    "time_created": str(_get_attr(d, "time_created", "")),
                    "voice_instructions": _get_attr(d, "voice_instructions"),
                    "voice_profile": _get_attr(d, "voice_profile"),
                    "voice": _get_attr(d, "voice"),
                })

        return json.dumps({"drivers": result, "count": len(result)}, default=str)

    @mcp.tool()
    def run_simulation(
        name: str,
        scenario_name: Optional[str] = None,
        target_name: Optional[str] = None,
        driver_name: Optional[str] = None,
        checks: Optional[list[str]] = None,
        repeats: int = 1,
        max_turns: int = 5,
        first_turn: str = "target",
        based_on_run_id: Optional[str] = None,
        ctx: Context = None,
    ) -> str:
        """Run a multi-turn conversation evaluation of your AI agent.

        Combines a Target (the system under test), a Driver (the simulated user),
        and a Scenario (the test cases) to generate realistic multi-turn conversations
        and evaluate them with quality checks. Runs synchronously and returns aggregate
        results. Use get_test_run_results with the returned test_run_id for full
        conversation transcripts.

        To rerun a previous simulation — keeping its configuration but changing one or
        more parameters — pass based_on_run_id with the original run's ID and supply
        only the values you want to override. If scenario_name or target_name are
        omitted and based_on_run_id is provided, they will be resolved from the
        original run.

        Args:
            name: Human-readable name for this simulation run.
            scenario_name: Name of the scenario to use. Required unless based_on_run_id
                is provided and the original run's scenario can be resolved.
            target_name: Name of the target to evaluate. Required unless based_on_run_id
                is provided and the original run's target can be resolved.
            driver_name: Name of the driver persona. If omitted, the project default
                driver is used.
            checks: List of check names to apply (from list_checks).
            repeats: Number of times to run each scenario row, default 1.
            max_turns: Maximum conversation turns per simulation, default 5.
            first_turn: Who speaks first — 'target' or 'driver', default 'target'.
            based_on_run_id: ID of a previous simulation run to reuse parameters from.
                Explicitly supplied values override the original run's parameters.
        """
        from okareo_api_client.api.default import (
            find_test_run_v0_find_test_runs_post,
            get_scenario_sets_v0_scenario_sets_get,
        )
        from okareo_api_client.errors import UnexpectedStatus
        from okareo_api_client.models.general_find_payload import GeneralFindPayload

        try:
            okareo = get_okareo_client()
            project_id = resolve_project_id(okareo)
        except Exception as e:
            return json.dumps({"error": str(e)})

        resolved_scenario_name = scenario_name
        resolved_target_name = target_name
        resolved_driver_name = driver_name

        # If rerunning, fetch original run params as defaults
        if based_on_run_id:
            try:
                payload = GeneralFindPayload(
                    id=based_on_run_id,
                    project_id=project_id,
                    return_model_metrics=True,
                )
                try:
                    runs = find_test_run_v0_find_test_runs_post.sync(
                        client=okareo.client,
                        json_body=payload,
                        api_key=okareo.api_key,
                    )
                except UnexpectedStatus as ue:
                    runs = json.loads(ue.content) if ue.status_code == 200 else None

                if not runs or isinstance(runs, Exception) or len(runs) == 0:
                    return json.dumps({
                        "error": (
                            f"Simulation run '{based_on_run_id}' not found. "
                            "Use list_test_runs to find available runs."
                        ),
                    })

                original = runs[0]
                original_is_dict = isinstance(original, dict)

                # Resolve scenario name from original run if not overridden
                if not resolved_scenario_name:
                    orig_scenario_id = (
                        original.get("scenario_set_id")
                        if original_is_dict
                        else _get_attr(original, "scenario_set_id")
                    )
                    if orig_scenario_id:
                        try:
                            all_scenarios = get_scenario_sets_v0_scenario_sets_get.sync(
                                client=okareo.client,
                                project_id=project_id,
                                api_key=okareo.api_key,
                            )
                            if all_scenarios and not isinstance(all_scenarios, Exception):
                                for s in all_scenarios:
                                    if _get_attr(s, "scenario_id") == orig_scenario_id:
                                        resolved_scenario_name = _get_attr(s, "name")
                                        break
                        except Exception:
                            pass

                # Resolve target name from original run if not overridden
                if not resolved_target_name:
                    orig_mut_id = (
                        original.get("mut_id")
                        if original_is_dict
                        else _get_attr(original, "mut_id")
                    )
                    if orig_mut_id:
                        try:
                            orig_target = okareo.get_target_by_name(
                                original.get("name", "") if original_is_dict else _get_attr(original, "name", "")
                            )
                            if orig_target:
                                resolved_target_name = _get_attr(orig_target, "name")
                        except Exception:
                            pass

                # Resolve driver name from original run if not overridden
                if not resolved_driver_name:
                    orig_driver_id = (
                        original.get("driver_id")
                        if original_is_dict
                        else _get_attr(original, "driver_id")
                    )
                    if orig_driver_id:
                        try:
                            orig_driver = okareo.get_driver_by_name(orig_driver_id)
                            if orig_driver:
                                resolved_driver_name = _get_attr(orig_driver, "name")
                        except Exception:
                            pass

            except Exception as e:
                return json.dumps({
                    "error": f"Failed to fetch original simulation run: {e}",
                })

        # Validate required fields after rerun resolution
        if not resolved_scenario_name:
            return json.dumps({
                "error": (
                    "scenario_name is required. "
                    "Provide it directly or via based_on_run_id."
                ),
            })
        if not resolved_target_name:
            return json.dumps({
                "error": (
                    "target_name is required. "
                    "Provide it directly or via based_on_run_id."
                ),
            })

        # Resolve scenario object
        try:
            all_scenarios = get_scenario_sets_v0_scenario_sets_get.sync(
                client=okareo.client,
                project_id=project_id,
                api_key=okareo.api_key,
            )
        except Exception as e:
            return json.dumps({"error": f"Failed to list scenarios: {e}"})

        resolved_scenario = None
        if all_scenarios and not isinstance(all_scenarios, Exception):
            for s in all_scenarios:
                if _get_attr(s, "name") == resolved_scenario_name:
                    resolved_scenario = s
                    break

        if resolved_scenario is None:
            return json.dumps({
                "error": (
                    f"Scenario '{resolved_scenario_name}' not found. "
                    "Use list_scenarios to see available scenarios."
                ),
            })

        row_count = _get_attr(resolved_scenario, "scenario_count", 0)
        if row_count == 0:
            return json.dumps({
                "error": (
                    f"Scenario '{resolved_scenario_name}' has zero rows. "
                    "Add rows before running a simulation."
                ),
            })

        # Get provider keys from lifespan context + SSE headers
        key_registry = {}
        if ctx and hasattr(ctx, "request_context"):
            lifespan_ctx = getattr(ctx.request_context, "lifespan_context", None)
            if lifespan_ctx and isinstance(lifespan_ctx, dict):
                key_registry = dict(lifespan_ctx.get("key_registry", {}))
        # Merge SSE header keys (take precedence over env vars)
        try:
            from src.sse_middleware import sse_provider_keys
            header_keys = sse_provider_keys.get()
            if header_keys:
                key_registry = {**key_registry, **header_keys}
        except (ImportError, LookupError):
            pass

        # Run the simulation
        try:
            sim_kwargs = dict(
                name=name,
                scenario=resolved_scenario,
                target=resolved_target_name,
                driver=resolved_driver_name,
                checks=checks or [],
                repeats=repeats,
                max_turns=max_turns,
                first_turn=first_turn,
            )
            if key_registry:
                sim_kwargs["api_keys"] = key_registry
            result = okareo.run_simulation(**sim_kwargs)
        except Exception as e:
            return json.dumps({
                "error": sanitize_error(f"Simulation failed: {e}", key_registry),
            })

        total_conversations = _get_attr(result, "test_data_point_count", 0)
        response = {
            "test_run_id": _get_attr(result, "id", ""),
            "name": _get_attr(result, "name", name),
            "status": str(_get_attr(result, "status", "")),
            "type": "MULTI_TURN",
            "test_data_point_count": total_conversations,
            "model_metrics": _serialize_value(_get_attr(result, "model_metrics")),
            "start_time": str(_get_attr(result, "start_time", "")),
            "end_time": str(_get_attr(result, "end_time", "")),
            "app_link": _get_attr(result, "app_link", ""),
            "message": (
                f"Simulation complete. {total_conversations} conversation(s) run. "
                "Use get_test_run_results with test_run_id for full transcripts."
            ),
        }

        if based_on_run_id:
            response["based_on_run_id"] = based_on_run_id

        return json.dumps(response, default=str)

    return None
