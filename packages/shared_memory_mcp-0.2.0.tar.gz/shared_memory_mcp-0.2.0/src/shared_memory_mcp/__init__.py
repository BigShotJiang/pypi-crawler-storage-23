# -*- coding: utf-8 -*-
"""shared-memory-mcp: Cross-IDE shared memory MCP Server for AI Agents."""
