## types-opencv

This is an OpenCV stubs project.

Generated based on `pyopencv_signatures.json` from OpenCV documentation build, together with the XML documents generated after the build, my local Python environment, and my patches.

github: https://github.com/tiandic/types-opencv-python
