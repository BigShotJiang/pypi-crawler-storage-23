## [0.14.2](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.1...v0.14.2) (2026-03-01)


### Bug Fixes

* resolve remaining security vulnerabilities in transitive dependencies ([7348802](https://github.com/easytocloud/Mac-letterhead/commit/7348802a61886cb2cc220383e7e1296f7aa27fad))

## [0.14.1](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.0...v0.14.1) (2026-03-01)


### Bug Fixes

* upgrade dependencies to address security vulnerabilities ([ee95775](https://github.com/easytocloud/Mac-letterhead/commit/ee95775289f5a57f433d8a893eef6838a1d1cdb7))

# [0.14.0](https://github.com/easytocloud/Mac-letterhead/compare/v0.13.9...v0.14.0) (2025-10-12)


### Features

* publish Mac-letterhead to MCP Registry ([35325c5](https://github.com/easytocloud/Mac-letterhead/commit/35325c5a1feda4a39af62ae248defc941585c571))

# Changelog

All notable changes to this project will be managed automatically by semantic-release.
