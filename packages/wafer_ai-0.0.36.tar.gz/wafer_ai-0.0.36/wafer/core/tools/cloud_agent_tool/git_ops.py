"""Git operations for the cloud agent tool.

Provides async helpers for branch creation, committing, pushing,
and repository validation using trio subprocess execution.
"""
from __future__ import annotations

import re
import subprocess
import tempfile
import time
from pathlib import Path

import trio


# Patterns that indicate a remote URL rather than a local path
_REMOTE_URL_PATTERNS = (
    "https://",
    "http://",
    "git@",
    "ssh://",
    "git://",
)


async def _run_git(repo_path: Path, *args: str) -> tuple[int, str, str]:
    """Run a git command in the repo directory.

    Returns (returncode, stdout, stderr).
    """
    process = await trio.lowlevel.open_process(
        ["git", *args],
        cwd=str(repo_path),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    stdout_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []

    async def _read(stream: trio.abc.ReceiveStream | None, out: list[bytes]) -> None:
        if stream is None:
            return
        try:
            async for chunk in stream:
                out.append(chunk)
        except trio.ClosedResourceError:
            pass

    async with trio.open_nursery() as nursery:
        nursery.start_soon(_read, process.stdout, stdout_chunks)
        nursery.start_soon(_read, process.stderr, stderr_chunks)

    await process.wait()
    return (
        process.returncode,
        b"".join(stdout_chunks).decode("utf-8", errors="replace").strip(),
        b"".join(stderr_chunks).decode("utf-8", errors="replace").strip(),
    )


async def validate_repo(repo_path: Path) -> tuple[str, str]:
    """Validate that repo_path is a git repo with a pushable remote.

    Returns:
        (remote_url, current_branch)

    Raises:
        ValueError: If the directory is not a valid git repo or has no remote.
    """
    repo_path = repo_path.resolve()
    if not repo_path.is_dir():
        raise ValueError(f"Not a directory: {repo_path}")

    # Check if it's a git repo
    rc, _, stderr = await _run_git(repo_path, "rev-parse", "--is-inside-work-tree")
    if rc != 0:
        raise ValueError(f"Not a git repository: {repo_path}")

    # Get current branch
    rc, branch, _ = await _run_git(repo_path, "rev-parse", "--abbrev-ref", "HEAD")
    if rc != 0 or not branch:
        raise ValueError("Could not determine current branch")

    # Get remote URL (prefer origin)
    rc, remote_url, _ = await _run_git(repo_path, "remote", "get-url", "origin")
    if rc != 0 or not remote_url:
        # Try first available remote
        rc, remotes, _ = await _run_git(repo_path, "remote")
        if rc != 0 or not remotes:
            raise ValueError("No git remote configured. Add one with: git remote add origin <url>")
        first_remote = remotes.splitlines()[0].strip()
        rc, remote_url, _ = await _run_git(repo_path, "remote", "get-url", first_remote)
        if rc != 0 or not remote_url:
            raise ValueError(f"Could not get URL for remote '{first_remote}'")

    return remote_url, branch


def generate_branch_name(prompt: str) -> str:
    """Generate a branch name from the prompt.

    Returns something like: cloud-agent/fix-auth-bug-1708123456
    """
    # Slugify: lowercase, replace non-alphanumeric with hyphens, collapse, trim
    slug = re.sub(r"[^a-z0-9]+", "-", prompt.lower().strip())
    slug = slug.strip("-")[:40]
    if not slug:
        slug = "changes"
    timestamp = int(time.time())
    return f"cloud-agent/{slug}-{timestamp}"


async def create_branch(
    repo_path: Path, branch_name: str, base_branch: str | None = None
) -> str:
    """Create and checkout a new branch.

    Args:
        repo_path: Path to the git repo.
        branch_name: Name for the new branch.
        base_branch: Branch to base off of. If None, uses current HEAD.

    Returns:
        The branch name that was created.

    Raises:
        RuntimeError: If branch creation fails.
    """
    if base_branch:
        rc, _, stderr = await _run_git(repo_path, "checkout", "-b", branch_name, base_branch)
    else:
        rc, _, stderr = await _run_git(repo_path, "checkout", "-b", branch_name)

    if rc != 0:
        raise RuntimeError(f"Failed to create branch '{branch_name}': {stderr}")

    return branch_name


async def commit_changes(repo_path: Path, message: str) -> str | None:
    """Stage all changes and commit.

    Returns:
        The commit hash, or None if there were no changes to commit.

    Raises:
        RuntimeError: If git add or commit fails unexpectedly.
    """
    # Stage all changes
    rc, _, stderr = await _run_git(repo_path, "add", ".")
    if rc != 0:
        raise RuntimeError(f"git add failed: {stderr}")

    # Check if there's anything to commit
    rc, status, _ = await _run_git(repo_path, "status", "--porcelain")
    if not status:
        return None  # Nothing to commit

    # Commit
    rc, _, stderr = await _run_git(repo_path, "commit", "-m", message)
    if rc != 0:
        raise RuntimeError(f"git commit failed: {stderr}")

    # Get commit hash
    rc, commit_hash, _ = await _run_git(repo_path, "rev-parse", "HEAD")
    if rc != 0:
        return "unknown"

    return commit_hash


async def push_branch(
    repo_path: Path, branch_name: str, remote: str = "origin"
) -> None:
    """Push a branch to the remote.

    Raises:
        RuntimeError: If push fails.
    """
    rc, _, stderr = await _run_git(repo_path, "push", "-u", remote, branch_name)
    if rc != 0:
        raise RuntimeError(f"git push failed: {stderr}")


async def get_diff_summary(repo_path: Path, base_branch: str) -> str:
    """Get a diff summary (stat) between current HEAD and base branch.

    Returns:
        The output of git diff --stat, or empty string if no diff.
    """
    rc, diff_stat, _ = await _run_git(repo_path, "diff", "--stat", f"{base_branch}...HEAD")
    if rc != 0:
        return ""
    return diff_stat


async def restore_branch(repo_path: Path, branch_name: str) -> None:
    """Checkout back to a branch (for cleanup on failure).

    Best-effort — errors are silently ignored.
    """
    await _run_git(repo_path, "checkout", branch_name)


def is_remote_url(repo: str) -> bool:
    """Check if the repo string is a remote URL (not a local path)."""
    return any(repo.startswith(prefix) for prefix in _REMOTE_URL_PATTERNS)


async def clone_repo(url: str, target_dir: Path | None = None) -> Path:
    """Clone a remote repo into a local directory.

    Args:
        url: Remote git URL (HTTPS or SSH).
        target_dir: Where to clone. If None, uses a temp directory.

    Returns:
        Path to the cloned repo.

    Raises:
        RuntimeError: If clone fails.
    """
    if target_dir is None:
        target_dir = Path(tempfile.mkdtemp(prefix="cloud-agent-"))

    process = await trio.lowlevel.open_process(
        ["git", "clone", url, str(target_dir)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    stderr_chunks: list[bytes] = []

    async def _read_stderr() -> None:
        if process.stderr is None:
            return
        try:
            async for chunk in process.stderr:
                stderr_chunks.append(chunk)
        except trio.ClosedResourceError:
            pass

    async with trio.open_nursery() as nursery:
        nursery.start_soon(_read_stderr)
        # Drain stdout too
        if process.stdout:
            try:
                async for _ in process.stdout:
                    pass
            except trio.ClosedResourceError:
                pass

    await process.wait()

    if process.returncode != 0:
        stderr = b"".join(stderr_chunks).decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"git clone failed: {stderr}")

    return target_dir


async def resolve_repo(repo: str) -> tuple[Path, bool]:
    """Resolve a repo argument to a local path, cloning if it's a remote URL.

    Args:
        repo: Either a local path or a remote git URL.

    Returns:
        (repo_path, was_cloned) — the local path and whether we cloned it.

    Raises:
        RuntimeError: If cloning fails.
    """
    if is_remote_url(repo):
        cloned_path = await clone_repo(repo)
        return cloned_path, True
    return Path(repo).resolve(), False
