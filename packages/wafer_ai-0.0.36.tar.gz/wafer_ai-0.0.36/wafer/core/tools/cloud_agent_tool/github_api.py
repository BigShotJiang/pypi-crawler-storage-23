"""GitHub REST API client for creating pull requests.

Uses httpx for async HTTP. No dependency on `gh` CLI.
"""
from __future__ import annotations

import os
import re
import subprocess

import httpx
import trio

GITHUB_API_BASE = "https://api.github.com"


def parse_github_remote(remote_url: str) -> tuple[str, str]:
    """Parse owner and repo name from a GitHub remote URL.

    Handles:
        - https://github.com/owner/repo.git
        - https://github.com/owner/repo
        - git@github.com:owner/repo.git
        - ssh://git@github.com/owner/repo.git

    Returns:
        (owner, repo)

    Raises:
        ValueError: If the URL is not a recognized GitHub remote format.
    """
    # SSH format: git@github.com:owner/repo.git
    ssh_match = re.match(r"git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$", remote_url)
    if ssh_match:
        return ssh_match.group(1), ssh_match.group(2)

    # HTTPS format: https://github.com/owner/repo.git
    https_match = re.match(
        r"https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?$", remote_url
    )
    if https_match:
        return https_match.group(1), https_match.group(2)

    # SSH with ssh:// prefix
    ssh_url_match = re.match(
        r"ssh://git@github\.com/([^/]+)/([^/]+?)(?:\.git)?$", remote_url
    )
    if ssh_url_match:
        return ssh_url_match.group(1), ssh_url_match.group(2)

    raise ValueError(
        f"Could not parse GitHub owner/repo from remote URL: {remote_url}\n"
        "Expected format: https://github.com/owner/repo or git@github.com:owner/repo"
    )


async def get_github_token() -> str:
    """Get a GitHub token for API authentication.

    Resolution order:
        1. GITHUB_TOKEN environment variable
        2. Wafer credentials (~/.wafer/credentials.json provider_token)
        3. `gh auth token` subprocess (if gh CLI is installed)

    Returns:
        The GitHub token.

    Raises:
        ValueError: If no token could be found.
    """
    # 1. Environment variable
    token = os.environ.get("GITHUB_TOKEN")
    if token:
        return token

    # 2. Wafer credentials (GitHub provider token from `wafer login`)
    try:
        from wafer.cli.auth import load_credentials

        creds = load_credentials()
        if creds and creds.provider_token:
            return creds.provider_token
    except ImportError:
        pass  # wafer CLI not installed

    # 3. gh CLI
    try:
        process = await trio.lowlevel.open_process(
            ["gh", "auth", "token"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        stdout_chunks: list[bytes] = []
        if process.stdout:
            try:
                async for chunk in process.stdout:
                    stdout_chunks.append(chunk)
            except trio.ClosedResourceError:
                pass
        await process.wait()
        if process.returncode == 0:
            token = b"".join(stdout_chunks).decode().strip()
            if token:
                return token
    except FileNotFoundError:
        pass  # gh not installed

    raise ValueError(
        "No GitHub token found. Either:\n"
        "  - Run `wafer login` (re-login to capture GitHub token)\n"
        "  - Set GITHUB_TOKEN environment variable\n"
        "  - Install and authenticate GitHub CLI: gh auth login"
    )


async def create_pull_request(
    remote_url: str,
    branch: str,
    base: str,
    title: str,
    body: str,
    github_token: str | None = None,
) -> str:
    """Create a pull request via the GitHub REST API.

    Args:
        remote_url: The git remote URL (used to determine owner/repo).
        branch: The head branch name.
        base: The base branch to merge into.
        title: PR title.
        body: PR body (markdown).
        github_token: GitHub token. If None, resolves automatically.

    Returns:
        The URL of the created pull request.

    Raises:
        ValueError: If token resolution fails or the remote URL can't be parsed.
        RuntimeError: If the API call fails.
    """
    owner, repo = parse_github_remote(remote_url)

    if github_token is None:
        github_token = await get_github_token()

    url = f"{GITHUB_API_BASE}/repos/{owner}/{repo}/pulls"
    headers = {
        "Authorization": f"Bearer {github_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    payload = {
        "title": title,
        "body": body,
        "head": branch,
        "base": base,
    }

    async with httpx.AsyncClient() as client:
        response = await client.post(url, json=payload, headers=headers, timeout=30)

    if response.status_code == 201:
        data = response.json()
        return data["html_url"]

    # Handle common errors with helpful messages
    if response.status_code == 401:
        raise RuntimeError(
            "GitHub API authentication failed (401). "
            "Check that your GITHUB_TOKEN or `gh auth` token has repo scope."
        )
    if response.status_code == 403:
        raise RuntimeError(
            "GitHub API forbidden (403). "
            "Your token may lack permissions for this repository."
        )
    if response.status_code == 404:
        raise RuntimeError(
            f"GitHub API not found (404). "
            f"Repository '{owner}/{repo}' may not exist or you lack access."
        )
    if response.status_code == 422:
        # Validation error — often means PR already exists or branch not pushed
        try:
            errors = response.json().get("errors", [])
            messages = [e.get("message", str(e)) for e in errors]
            detail = "; ".join(messages) if messages else response.text
        except Exception:
            detail = response.text
        raise RuntimeError(f"GitHub API validation error (422): {detail}")

    raise RuntimeError(
        f"GitHub API error ({response.status_code}): {response.text[:500]}"
    )
