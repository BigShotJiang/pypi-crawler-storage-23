# ruff: noqa: PLR0913, E402
# PLR0913 (too many arguments) is suppressed because Typer CLI commands
# naturally have many parameters - each --flag becomes a function argument.
# E402 (module level import not at top) is suppressed because we intentionally
# load .env files before importing other modules that may read env vars.
"""Wafer CLI - GPU development toolkit for LLM coding agents.

Top-level commands:
  wafer login/logout/whoami/status/guide   Auth and onboarding
  wafer target    Create and manage GPU targets and workspaces
  wafer tool      Run profiling, evaluation, and analysis tools
  wafer agent     AI assistant for GPU kernel development
  wafer settings  Config, billing, deps, and provider management
"""
from __future__ import annotations

import atexit
import os
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

import typer

if TYPE_CHECKING:
    from types import ModuleType

from dotenv import load_dotenv

load_dotenv()  # cwd/.env
load_dotenv(Path.home() / ".wafer" / ".env")  # ~/.wafer/.env

app = typer.Typer(
    help="GPU development toolkit for LLM coding agents",
    no_args_is_help=False,
    pretty_exceptions_show_locals=False,
    add_completion=True,
)

_command_start_time: float | None = None
_command_outcome: str = "failure"
_command_failure_details: dict[str, str | int] | None = None


def _exit_with_error(msg: str) -> None:
    """Print error to stderr and exit with code 1."""
    typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1) from None


def _show_version(json_output: bool = False) -> None:
    """Show CLI version and environment, then exit."""
    from .analytics import _get_cli_version
    from .global_config import load_global_config
    from .output import json_response
    version = _get_cli_version()
    config = load_global_config()
    environment = config.environment
    if json_output:
        typer.echo(json_response(data={"version": version, "environment": environment}))
    else:
        typer.echo(f"wafer-ai {version} ({environment})")
    raise typer.Exit()


def _show_welcome() -> None:
    """Show first-run welcome message for unauthenticated users."""
    from .analytics import _get_cli_version

    version = _get_cli_version()
    typer.echo(f"Wafer CLI v{version} — GPU development toolkit for LLM coding agents")
    typer.echo("")
    typer.echo("Get started:")
    typer.echo("  wafer login                       Authenticate with GitHub")
    typer.echo("  wafer guide quickstart            Quick start guide")
    typer.echo("  wafer demo                        Interactive demos")
    typer.echo("  wafer settings deps check         Check local tool dependencies")
    typer.echo("")
    typer.echo("Works without login:")
    typer.echo("  wafer tool roofline ...           Roofline analysis")
    typer.echo("  wafer guide                       CLI usage guide")
    typer.echo("")
    typer.echo("Run wafer --help to see all commands.")


def _get_command_path(ctx: typer.Context) -> tuple[str, str | None]:
    invoked = ctx.invoked_subcommand
    info_name = ctx.info_name or ""
    parent_cmd = None
    if ctx.parent and ctx.parent.info_name and ctx.parent.info_name != "wafer":
        parent_cmd = ctx.parent.info_name
    if parent_cmd:
        return parent_cmd, info_name
    return info_name or "unknown", invoked


def _mark_command_success() -> None:
    global _command_outcome
    _command_outcome = "success"


def _make_excepthook(
    original_excepthook: Callable[..., Any],
) -> Callable[..., Any]:
    assert callable(original_excepthook), "original_excepthook must be callable"
    assert original_excepthook is not None, "original_excepthook must not be None"

    def custom_excepthook(
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_traceback: object,
    ) -> None:
        global _command_outcome, _command_failure_details
        if exc_type is SystemExit:
            exit_code = exc_value.code if hasattr(exc_value, "code") else 1
            if exit_code != 0 and exit_code is not None:
                _command_outcome = "failure"
                _command_failure_details = {
                    "error_type": "SystemExit",
                    "error_message": str(exc_value),
                }
                if isinstance(exit_code, int):
                    _command_failure_details["exit_code"] = exit_code
        else:
            _command_outcome = "failure"
            _command_failure_details = {
                "error_type": exc_type.__name__,
                "error_message": str(exc_value),
                "exit_code": 1,
            }
            if os.environ.get("NO_COLOR"):
                print(f"\n>>> ERROR: {exc_type.__name__}: {exc_value}\n", file=sys.stderr)
            else:
                print(
                    f"\n\033[1;31m>>> ERROR: {exc_type.__name__}: {exc_value}\033[0m\n",
                    file=sys.stderr,
                )
        original_excepthook(exc_type, exc_value, exc_traceback)
    return custom_excepthook


def _make_exit_tracker(ctx: typer.Context, analytics: ModuleType) -> Callable[[], None]:
    assert ctx is not None, "ctx must not be None"
    assert hasattr(analytics, "track_command"), "analytics module must have track_command"

    def track_on_exit() -> None:
        command, subcommand = _get_command_path(ctx)
        if ctx.resilient_parsing:
            return
        duration_ms = None
        if _command_start_time is not None:
            duration_ms = int((time.time() - _command_start_time) * 1000)
        failure_props = _command_failure_details or {}
        exit_code = failure_props.get("exit_code")
        error_type = failure_props.get("error_type")
        error_message = failure_props.get("error_message")
        typed_exit_code = exit_code if isinstance(exit_code, int) else None
        typed_error_type = error_type if isinstance(error_type, str) else None
        typed_error_message = error_message if isinstance(error_message, str) else None
        analytics.track_command(
            command=command,
            subcommand=subcommand,
            outcome=_command_outcome,
            duration_ms=duration_ms,
            properties=failure_props if _command_outcome == "failure" else None,
        )
        if _command_outcome == "failure":
            analytics.track_command_failure(
                command=command,
                subcommand=subcommand,
                error_type=typed_error_type,
                error_message=typed_error_message,
                exit_code=typed_exit_code,
                duration_ms=duration_ms,
            )
    return track_on_exit


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        help="Show version and exit",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON (used with --version or subcommands)",
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        help="Suppress colored output",
    ),
) -> None:
    """Initialize analytics and track command execution."""
    if no_color:
        os.environ["NO_COLOR"] = "1"
    if version:
        _show_version(json_output=json_output)
        return

    if ctx.invoked_subcommand is None and not ctx.resilient_parsing:
        from .auth import load_credentials

        creds = load_credentials()
        if creds is None:
            _show_welcome()
        else:
            typer.echo(ctx.get_help())
        raise typer.Exit(0)

    global _command_start_time, _command_outcome, _command_failure_details
    _command_start_time = time.time()
    _command_outcome = "success"
    _command_failure_details = None

    from . import analytics
    analytics.init_analytics()
    sys.excepthook = _make_excepthook(sys.excepthook)
    atexit.register(_make_exit_tracker(ctx, analytics))


# ---------------------------------------------------------------------------
# Mount sub-apps from dedicated command modules
# ---------------------------------------------------------------------------
from .cmd_target import target_app
from .cmd_settings import settings_app, login, logout, whoami, status, guide
from .cmd_tool import tool_app
from .cmd_demo import demo_app
from .cmd_agent import register_agent_command
from .sandbox_cli import sandbox_app
from .deps import deps_app

app.add_typer(target_app, name="target")
app.add_typer(tool_app, name="tool")
app.add_typer(settings_app, name="settings")
app.add_typer(sandbox_app, name="sandbox")
app.add_typer(demo_app, name="demo")

settings_app.add_typer(deps_app, name="deps")

app.command("login")(login)
app.command("logout")(logout)
app.command("whoami")(whoami)
app.command("status")(status)
app.command("guide")(guide)

register_agent_command(app)

# Re-export agent symbols used by tests and external code
from .cmd_agent import (  # noqa: E402, F401
    _handle_cloud_agent,
    _format_template_entry,
    _format_template_variable,
    _validate_template_name,
    agent,
)


def main() -> None:
    """Entry point for wafer CLI."""
    global _command_outcome, _command_failure_details

    try:
        app()
    except KeyboardInterrupt:
        sys.exit(0)
    except SystemExit as exc:
        exit_code = exc.code if hasattr(exc, "code") else 1
        if exit_code not in (0, None):
            _command_outcome = "failure"
            if _command_failure_details is None:
                _command_failure_details = {
                    "error_type": "SystemExit",
                    "error_message": str(exc),
                }
                if isinstance(exit_code, int):
                    _command_failure_details["exit_code"] = exit_code
        raise
    except Exception as exc:
        _command_outcome = "failure"
        if _command_failure_details is None:
            _command_failure_details = {
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "exit_code": 1,
            }
        raise


if __name__ == "__main__":
    main()
