"""Wafer Wevin CLI - thin wrapper that calls rollouts in-process.
Adds:
- Wafer auth (proxy token from ~/.wafer/credentials.json)
- Wafer templates (ask-docs, optimize-kernel, trace-analyze)
"""
from __future__ import annotations

import json
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    import httpx

    from wafer.core.rollouts import Endpoint, Environment
    from wafer.core.rollouts.dtypes import AgentSession, StreamEvent, ToolCall, Trajectory
    from wafer.core.rollouts.store import FileSessionStore
    from wafer.core.rollouts.templates import TemplateConfig


class StreamingChunkFrontend:
    """Frontend that emits real-time JSON chunk events.
    Designed for programmatic consumption by extensions/UIs.
    Emits events in the format expected by wevin-extension handleWevinEvent:
    - {type: 'session_start', session_id: '...', model: '...'}
    - {type: 'text_delta', delta: '...'}
    - {type: 'tool_call_start', tool_name: '...'}
    - {type: 'tool_call_end', tool_name: '...', args: {...}}
    - {type: 'tool_result', is_error: bool}
    - {type: 'session_end'}
    - {type: 'error', error: '...'}
    """
    def __init__(self, session_id: str | None = None, model: str | None = None) -> None:
        self._current_tool_call: dict | None = None
        self._session_id = session_id
        self._model = model

    def _emit(self, obj: dict) -> None:
        """Emit a single NDJSON line."""
        print(json.dumps(obj, ensure_ascii=False), flush=True)

    async def start(self) -> None:
        """Initialize frontend and emit session_start if session_id is known."""
        if self._session_id:
            self._emit({
                "type": "session_start",
                "session_id": self._session_id,
                "model": self._model,
            })

    def emit_session_start(self, session_id: str, model: str | None = None) -> None:
        """Emit session_start event (for new sessions created during run)."""
        self._emit({
            "type": "session_start",
            "session_id": session_id,
            "model": model or self._model,
        })

    async def stop(self) -> None:
        """Emit session_end event."""
        self._emit({"type": "session_end"})

    async def handle_event(self, event: StreamEvent) -> None:
        """Handle streaming event by emitting JSON."""
        from wafer.core.rollouts.dtypes import (
            StreamDone,
            StreamError,
            TextDelta,
            ThinkingDelta,
            ToolCallEnd,
            ToolCallStart,
            ToolResultReceived,
        )
        if isinstance(event, TextDelta):
            # Emit text delta immediately for real-time streaming
            self._emit({"type": "text_delta", "delta": event.delta})
        elif isinstance(event, ThinkingDelta):

            pass
        elif isinstance(event, ToolCallStart):
            # Emit tool_call_start (tool_name and name for consumer compatibility)
            self._current_tool_call = {
                "id": event.tool_call_id,
                "name": event.tool_name,
            }
            self._emit({
                "type": "tool_call_start",
                "tool_name": event.tool_name,
                "name": event.tool_name,
            })
        elif isinstance(event, ToolCallEnd):
            # Emit tool_call_end (tool_name and name for consumer compatibility)
            tool_call = event.tool_call
            name = tool_call.name
            self._emit({
                "type": "tool_call_end",
                "tool_name": name,
                "name": name,
                "args": tool_call.args if tool_call.args else {},
            })
        elif isinstance(event, ToolResultReceived):
            # Emit tool_result event with error details
            result_event = {"type": "tool_result", "is_error": event.is_error}
            # Include error message and content if available
            if event.error:
                result_event["error"] = event.error
            if event.content:
                if isinstance(event.content, list):
                    result_event["content"] = "\n".join(
                        str(item) if not isinstance(item, dict) else item.get("text", str(item))
                        for item in event.content
                    )
                else:
                    result_event["content"] = str(event.content)
            self._emit(result_event)
        elif isinstance(event, StreamDone):
            # Will be handled by stop()
            pass
        elif isinstance(event, StreamError):
            self._emit({"type": "error", "error": str(event.error)})

    async def get_input(self, prompt: str = "") -> str:
        """Get user input - not supported in JSON mode."""
        raise RuntimeError(
            "StreamingChunkFrontend does not support interactive input. "
            "Use -p to provide input or use a single-turn template (e.g. trace-analyze)."
        )

    async def confirm_tool(self, tool_call: ToolCall) -> bool:
        """Auto-approve all tools in JSON mode."""
        return True

    def show_loader(self, text: str) -> None:
        """No-op for JSON mode."""
        pass

    def hide_loader(self) -> None:
        """No-op for JSON mode."""
        pass


def _make_wafer_token_refresh() -> Callable[[], Awaitable[str | None]]:
    from .auth import load_credentials, refresh_access_token, save_credentials
    assert callable(load_credentials), "load_credentials must be callable"
    assert callable(refresh_access_token), "refresh_access_token must be callable"

    async def _refresh() -> str | None:
        creds = load_credentials()
        if not creds or not creds.refresh_token:
            return None
        try:
            new_access, new_refresh = refresh_access_token(creds.refresh_token)
            save_credentials(new_access, new_refresh, creds.email)
            return new_access
        except Exception as exc:
            logging.getLogger(__name__).warning("wafer token refresh failed: %s", exc)
            return None
    return _refresh


def _track_auth_failure(error_type: str, *, had_credentials: bool, source: str) -> None:
    assert error_type, "error_type must not be empty"
    assert source, "source must not be empty"
    from .analytics import track_event
    track_event("cli_auth_failure", {
        "error_type": error_type,
        "had_credentials": had_credentials,
        "source": source,
    })


def _resolve_wafer_token() -> tuple[str, str | None, bool, bool]:
    assert os.environ is not None, "os.environ must be available"
    assert callable(os.environ.get), "os.environ.get must be callable"
    from .auth import get_valid_token, load_credentials
    wafer_token = os.environ.get("WAFER_AUTH_TOKEN", "")
    token_source = "WAFER_AUTH_TOKEN" if wafer_token else None
    had_credentials = False
    uses_credentials_file = False
    if not wafer_token:
        try:
            creds = load_credentials()
            had_credentials = creds is not None and bool(creds.access_token)
        except Exception:
            pass
        wafer_token = get_valid_token()
        if wafer_token:
            token_source = "~/.wafer/credentials.json"
            uses_credentials_file = True
    return wafer_token, token_source, had_credentials, uses_credentials_file


def _get_wafer_auth(
) -> tuple[str | None, str | None, Callable[[], Awaitable[str | None]] | None]:
    assert sys.stderr is not None, "stderr must be available"
    from .global_config import get_api_url
    wafer_token, token_source, had_credentials, uses_credentials_file = _resolve_wafer_token()
    if wafer_token:
        api_url = get_api_url()
        refresh = _make_wafer_token_refresh() if uses_credentials_file else None
        return f"{api_url}/v1/anthropic", wafer_token, refresh
    if had_credentials:
        print(
            "Error: Wafer credentials expired and refresh failed.\n"
            "  Run 'wafer login' to re-authenticate.\n",
            file=sys.stderr,
        )
        _track_auth_failure("credentials_expired_refresh_failed", had_credentials=True, source="proxy")
    else:
        print("Error: No API credentials found", file=sys.stderr)
        print("  Run 'wafer login' to authenticate.\n", file=sys.stderr)
        _track_auth_failure("no_credentials", had_credentials=False, source="proxy")
    return None, None, None


def _get_session_preview(session: AgentSession) -> str:
    assert session is not None, "session must not be None"
    assert hasattr(session, "messages"), "session must have messages attribute"
    messages = getattr(session, "messages", None)
    if not messages:
        return ""
    for msg in messages:
        if msg.role == "user" and isinstance(msg.content, str):
            preview = msg.content[:50].replace("\n", " ")
            if len(msg.content) > 50:
                preview += "..."
            return preview
    return ""


def _get_log_file_path() -> Path:
    assert Path.home().exists(), "home directory must exist"
    assert Path.home().is_dir(), "home path must be a directory"
    log_dir = Path.home() / ".wafer" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir / "wevin_debug.log"


def _setup_logging(verbose_env: bool = False) -> None:
    assert isinstance(verbose_env, bool), "verbose_env must be a bool"
    assert callable(_get_log_file_path), "_get_log_file_path must be callable"
    import logging.config
    log_file = _get_log_file_path()
    handlers: dict = {
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(log_file),
            "maxBytes": 10_000_000,
            "backupCount": 3,
            "formatter": "json",
            "level": "DEBUG",
        },
    }
    if verbose_env:
        handlers["stderr"] = {
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stderr",
            "formatter": "brief",
            "level": "INFO",
        }
    wafer_handler_list = ["file", "stderr"] if verbose_env else ["file"]
    logging.config.dictConfig({
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json": {
                "format": '{"ts": "%(asctime)s", "level": "%(levelname)s", "logger": "%(name)s", "msg": "%(message)s"}',
            },
            "brief": {
                "format": "%(asctime)s %(levelname)-5s %(name)s: %(message)s",
                "datefmt": "%H:%M:%S",
            },
        },
        "handlers": handlers,
        "loggers": {
            # wafer loggers: DEBUG to file, INFO+ to stderr when verbose
            "wafer": {"level": "DEBUG", "handlers": wafer_handler_list, "propagate": False},
            # Suppress noisy third-party loggers
            "hpack": {"level": "WARNING"},
            "grpclib": {"level": "WARNING"},
            "modal": {"level": "INFO"},
        },
        "root": {"level": "WARNING", "handlers": ["file"]},
    })


def _unwrap_exception(e: BaseException) -> BaseException:
    assert e is not None, "exception must not be None"
    assert isinstance(e, BaseException), "e must be a BaseException"
    actual = e
    while isinstance(actual, ExceptionGroup) and actual.exceptions:
        actual = actual.exceptions[0]
    return actual


def _build_endpoint(
    tpl: TemplateConfig,
    model_override: str | None,
    api_base: str,
    api_key: str,
    api_key_refresh: Callable[[], Awaitable[str | None]] | None = None,
    file_config: object | None = None,
) -> Endpoint:
    assert tpl is not None, "template config must not be None"
    assert api_base, "api_base must not be empty"
    from wafer.core.rollouts import Endpoint
    resolved_model = model_override or tpl.model
    provider, model_id = resolved_model.split("/", 1)
    thinking_config = (
        {"type": "enabled", "budget_tokens": tpl.thinking_budget} if tpl.thinking else None
    )
    temperature = getattr(file_config, "temperature", None) if file_config else None
    max_completion_tokens = getattr(file_config, "max_completion_tokens", None) if file_config else None
    reasoning_effort = getattr(file_config, "reasoning_effort", None) if file_config else None
    context_management = None
    if provider == "anthropic":
        # compact_20260112 only supported on Opus 4.6 and Sonnet 4.6
        # clear_tool_uses / clear_thinking supported on all Claude 4+ models
        supports_compaction = model_id in ("claude-opus-4-6", "claude-sonnet-4-6")
        edits: list[dict[str, Any]] = []
        if tpl.thinking:
            edits.append({"type": "clear_thinking_20251015", "keep": {"type": "thinking_turns", "value": 2}})
        edits.append({
            "type": "clear_tool_uses_20250919",
            "trigger": {"type": "input_tokens", "value": 100000},
            "keep": {"type": "tool_uses", "value": 5},
            "clear_at_least": {"type": "input_tokens", "value": 10000},
        })
        if supports_compaction:
            edits.append({
                "type": "compact_20260112",
                "trigger": {"type": "input_tokens", "value": 150000},
                "pause_after_compaction": True,
            })
        context_management = {"edits": edits}
    return Endpoint(
        provider=provider,
        model=model_id,
        api_base=api_base,
        api_key=api_key,
        api_key_refresh=api_key_refresh,
        thinking=thinking_config,
        max_tokens=tpl.max_tokens,
        temperature=temperature if temperature is not None else 1.0,
        max_completion_tokens=max_completion_tokens,
        reasoning_effort=reasoning_effort,
        context_management=context_management,
    )


def _build_environment(  # noqa: PLR0913
    tpl: TemplateConfig,
    tools_override: list[str] | None,
    has_target: bool = False,
    template_args: dict[str, str] | None = None,
    env_type: str | None = None,
    workspace_id: str | None = None,
) -> Environment:
    assert tpl is not None, "template config must not be None"
    dir_arg = (template_args or {}).get("dir")
    if dir_arg:
        working_dir = Path(dir_arg).resolve()
    else:
        working_dir = Path.cwd()
    resolved_tools = list(tools_override or tpl.tools)
    if env_type == "workspace":
        raise ValueError(
            "--env workspace is no longer supported. Use the sandbox tool for GPU execution."
        )
    ssh_target = None
    ssh_key = None
    target_name_resolved = None
    if has_target:
        try:
            from wafer.cli.targets import get_default_target, load_target

            default = get_default_target()
            if default:
                target = load_target(default)
                if hasattr(target, "ssh_target"):
                    ssh_target = target.ssh_target
                    ssh_key = target.ssh_key
                    target_name_resolved = target.name
        except Exception as exc:
            logging.getLogger("wafer.agent").warning("Failed to load default target: %s", exc)
    if ssh_target is not None and "sandbox" not in resolved_tools:
        resolved_tools = list(resolved_tools) + ["sandbox"]
    from wafer.core.environments.wafer_ai import WaferAiEnvironment
    from wafer.core.rollouts.templates import DANGEROUS_BASH_COMMANDS
    if tpl.include_skills and "skill" not in resolved_tools:
        resolved_tools = list(resolved_tools) + ["skill"]
    allow_network = has_target or "ask_docs" in resolved_tools
    env = WaferAiEnvironment(
        working_dir=working_dir,
        enabled_tools=resolved_tools,
        bash_allowlist=tpl.bash_allowlist,
        bash_denylist=DANGEROUS_BASH_COMMANDS,
        allow_network=allow_network,
        ssh_target=ssh_target,
        ssh_key=ssh_key,
        target_name=target_name_resolved,
    )  # type: ignore[assignment]
    return env


def _resolve_session_id(resume: str | None, session_store: FileSessionStore) -> str | None:
    assert session_store is not None, "session_store must not be None"
    assert isinstance(resume, (str, type(None))), "resume must be a string or None"
    if not resume:
        return None
    session_id = resume if resume != "last" else session_store.get_latest_id_sync()  # type: ignore[union-attr]
    if not session_id:
        print("Error: No session to resume", file=sys.stderr)
        sys.exit(1)
    return session_id


def _get_default_template() -> TemplateConfig:
    """Load default template from bundled TOML (default.toml)."""
    from wafer.core.rollouts.templates import load_template

    return load_template("default")


def _load_template(
    template_name: str, template_args: dict[str, str] | None = None
) -> tuple[TemplateConfig | None, str | None]:
    assert template_name, "template_name must not be empty"
    assert isinstance(template_name, str), "template_name must be a string"
    try:
        from wafer.core.rollouts.templates import load_template

        template: TemplateConfig = load_template(template_name)
        _ = template.interpolate_prompt(template_args or {})  # validates variables exist
        return template, None
    except Exception as e:
        return None, str(e)


async def _check_direct_response_status(response: httpx.Response) -> None:
    assert response is not None, "response must not be None"
    assert hasattr(response, "status_code"), "response must have status_code"
    if response.status_code == 401:
        print("Error: Authentication failed. Run 'wafer login'.", file=sys.stderr)
        sys.exit(1)
    if response.status_code == 402:
        print("Error: Insufficient credits. Check 'wafer settings billing'.", file=sys.stderr)
        sys.exit(1)
    if response.status_code != 200:
        raw = await response.aread()
        print(f"Error: API returned {response.status_code}: {raw.decode(errors='replace')[:500]}", file=sys.stderr)
        sys.exit(1)


def _dispatch_sse_event_json(frontend: StreamingChunkFrontend, event: dict[str, Any]) -> bool:
    assert frontend is not None, "frontend must not be None"
    assert isinstance(event, dict), "event must be a dict"
    event_type = event.get("type", "")
    if event_type == "tool_call":
        frontend._emit({"type": "tool_call_end", "tool_name": event.get("name", ""), "args": event.get("input", {})})
    elif event_type == "tool_result":
        result_event: dict[str, Any] = {"type": "tool_result", "is_error": False}
        if event.get("content"):
            result_event["content"] = event["content"]
        frontend._emit(result_event)
    elif event_type == "text":
        frontend._emit({"type": "text_delta", "delta": event.get("content", "")})
    elif event_type == "error":
        frontend._emit({"type": "error", "error": event.get("content", "Unknown error")})
    elif event_type == "turn_start":
        frontend._emit({"type": "status", "message": f"Turn {event.get('turn', '?')}/{event.get('max_turns', '?')}"})
    elif event_type == "tool_call_start":
        frontend._emit({"type": "tool_call_start", "tool_name": event.get("name", "")})
    elif event_type == "tool_exec_start":
        frontend._emit({"type": "tool_exec_start", "tool_name": event.get("name", ""), "index": event.get("index", "?"), "total": event.get("total", "?")})
    elif event_type == "sources":
        frontend._emit({"type": "sources", "files": event.get("files", [])})
    elif event_type == "done":
        return True
    return False


def _dispatch_sse_event_terminal(event: dict[str, Any]) -> bool:
    assert isinstance(event, dict), "event must be a dict"
    assert sys.stderr is not None, "stderr must be available"
    event_type = event.get("type", "")
    if event_type == "tool_call":
        summary = _format_tool_call_summary(event.get("name", ""), event.get("input", {}))
        print(f"\033[2m  {summary}\033[0m", file=sys.stderr)
    elif event_type == "tool_result":
        summary = _format_tool_result_summary(event.get("name", ""), event.get("content", ""))
        print(f"\033[2m  {summary}\033[0m", file=sys.stderr)
    elif event_type == "text":
        print(event.get("content", ""), end="", flush=True)
    elif event_type == "error":
        print(f"\nError: {event.get('content', 'Unknown error')}", file=sys.stderr)
    elif event_type == "turn_start":
        print(f"\033[2m  [Turn {event.get('turn', '?')}] Searching documentation...\033[0m", file=sys.stderr)
    elif event_type == "tool_call_start":
        print(f"\033[2m  Calling {event.get('name', '')}...\033[0m", file=sys.stderr)
    elif event_type == "tool_exec_start":
        print(f"\033[2m  Executing {event.get('name', '')} ({event.get('index', '?')}/{event.get('total', '?')})...\033[0m", file=sys.stderr)
    elif event_type == "sources":
        files = event.get("files", [])
        if files:
            print("\033[2m  Sources:\033[0m", file=sys.stderr)
            for f in files:
                print(f"\033[2m    {f}\033[0m", file=sys.stderr)
    elif event_type == "done":
        return True
    return False


async def _stream_direct_endpoint(
    api_url: str,
    auth_token: str,
    endpoint_path: str,
    query: str,
    template_args: dict[str, str] | None,
    defaults: dict[str, str] | None,
    json_output: bool,
) -> None:
    assert api_url, "api_url must not be empty"
    assert auth_token, "auth_token must not be empty"
    import httpx
    url = f"{api_url.rstrip('/')}{endpoint_path}"
    body: dict[str, str] = {}
    if defaults:
        body.update(defaults)
    if template_args:
        body.update(template_args)
    body["query"] = query
    headers = {
        "Authorization": f"Bearer {auth_token}",
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
    }
    frontend: StreamingChunkFrontend | None = None
    if json_output:
        frontend = StreamingChunkFrontend()
    async with httpx.AsyncClient(timeout=180.0) as client:
        async with client.stream("POST", url, json=body, headers=headers) as response:
            await _check_direct_response_status(response)
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[len("data: "):]
                if data_str == "[DONE]":
                    break
                event = json.loads(data_str)
                if json_output:
                    assert frontend is not None
                    if _dispatch_sse_event_json(frontend, event):
                        break
                else:
                    if _dispatch_sse_event_terminal(event):
                        break
    if json_output:
        assert frontend is not None
        frontend._emit({"type": "session_end"})
    else:
        print()  # trailing newline after streamed text


def _format_tool_call_summary(tool_name: str, tool_input: dict[str, Any]) -> str:
    assert isinstance(tool_name, str), "tool_name must be a string"
    assert isinstance(tool_input, dict), "tool_input must be a dict"
    if tool_name == "grep":
        pattern = tool_input.get("pattern", "")
        return f'searching: grep("{pattern}")...'
    if tool_name == "read_file":
        path = tool_input.get("path", "")
        return f"reading: {path}..."
    if tool_name == "list_files":
        pattern = tool_input.get("pattern", "*")
        return f'listing: find("{pattern}")...'
    return f"{tool_name}({json.dumps(tool_input)})..."


def _format_tool_result_summary(tool_name: str, content: str) -> str:
    assert isinstance(tool_name, str), "tool_name must be a string"
    assert isinstance(content, str), "content must be a string"
    if "No matches found" in content or "No files found" in content:
        return "no results"
    if "Error:" in content:
        return content[:80]
    line_count = content.count("\n")
    if tool_name == "grep":
        return f"found {line_count} matches"
    if tool_name == "read_file":
        return f"read {line_count} lines"
    if tool_name == "list_files":
        return f"found {line_count} files"
    return f"got {len(content)} chars"


def _handle_get_session(
    get_session: str, json_output: bool, session_store: FileSessionStore
) -> None:
    assert get_session, "get_session must not be empty"
    assert session_store is not None, "session_store must not be None"
    from dataclasses import asdict

    import trio

    async def _get_session() -> None:
        try:
            session, err = await session_store.get(get_session)  # type: ignore[union-attr]
            if err or not session:
                _print_error(err or f"Session {get_session} not found", json_output)
                sys.exit(1)
            if json_output:
                _print_session_json(session, asdict)
            else:
                _print_session_text(session)
        except KeyboardInterrupt:
            sys.exit(130)
        except Exception as e:
            _print_error(f"Failed to load session {get_session}: {e}", json_output)
            sys.exit(1)
    try:
        trio.run(_get_session)
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        _print_error(f"Failed to run session loader: {e}", json_output)
        sys.exit(1)


def _print_error(msg: str, json_output: bool) -> None:
    assert isinstance(msg, str), "msg must be a string"
    assert isinstance(json_output, bool), "json_output must be a bool"
    if json_output:
        from .output import json_error
        print(json_error(msg))
    else:
        print(f"Error: {msg}", file=sys.stderr)


def _print_session_json(session: AgentSession, asdict: Callable[..., dict[str, Any]]) -> None:
    assert session is not None, "session must not be None"
    assert callable(asdict), "asdict must be callable"
    try:
        messages_data = [asdict(msg) for msg in session.messages]
    except Exception as e:
        from .output import json_error
        print(json_error(f"Failed to serialize messages: {e}"))
        sys.exit(1)
    from .output import json_response
    print(
        json_response(data={
            "session_id": session.session_id,
            "status": session.status.value,
            "model": session.endpoint.model if session.endpoint else None,
            "created_at": session.created_at,
            "updated_at": session.updated_at,
            "messages": messages_data,
            "tags": session.tags,
        })
    )


def _print_session_text(session: AgentSession) -> None:
    assert session is not None, "session must not be None"
    assert hasattr(session, "session_id"), "session must have session_id"
    print(f"Session: {session.session_id}")
    print(f"Status: {session.status.value}")
    print(f"Messages: {len(session.messages)}")
    for i, msg in enumerate(session.messages):
        content_preview = str(msg.content)[:100] if msg.content else ""
        print(f"  [{i}] {msg.role}: {content_preview}...")


def _handle_list_sessions(json_output: bool, session_store: FileSessionStore) -> None:
    assert isinstance(json_output, bool), "json_output must be a bool"
    assert session_store is not None, "session_store must not be None"
    sessions = session_store.list_sync(limit=50)  # type: ignore[union-attr]
    if json_output:
        sessions_data = []
        for s in sessions:
            sessions_data.append({
                "session_id": s.session_id,
                "status": s.status.value,
                "model": s.endpoint.model if s.endpoint else None,
                "created_at": s.created_at if hasattr(s, "created_at") else None,
                "updated_at": s.updated_at if hasattr(s, "updated_at") else None,
                "message_count": len(s.messages),
                "preview": _get_session_preview(s),
            })
        from .output import json_response
        print(json_response(data={"sessions": sessions_data}))
    else:
        if not sessions:
            print("No sessions found.")
        else:
            print("Recent sessions:")
            for s in sessions:
                preview = _get_session_preview(s)
                print(f"  {s.session_id}  {preview}")


def _setup_wafer_env_vars() -> None:
    assert os.environ is not None, "os.environ must be available"
    from .global_config import get_api_url
    if "WAFER_API_URL" not in os.environ:
        os.environ["WAFER_API_URL"] = get_api_url()
    if "WAFER_AUTH_TOKEN" not in os.environ:
        from .auth import get_valid_token
        _token = get_valid_token()
        if _token:
            os.environ["WAFER_AUTH_TOKEN"] = _token


def _load_and_validate_template(
    template: str,
    template_args: dict[str, str] | None,
    prompt: str | None,
) -> TemplateConfig:
    assert template, "template name must not be empty"
    assert isinstance(template, str), "template must be a string"
    loaded_template, err = _load_template(template, template_args)
    if err or loaded_template is None:
        from wafer.cli.agent_config import list_bundled_templates

        print(f"Error: Template not found: {template}", file=sys.stderr)
        print(f"  Detail: {err}", file=sys.stderr)
        available = list_bundled_templates()
        if available:
            print(f"  Available templates: {', '.join(available)}", file=sys.stderr)
        sys.exit(1)
    tpl = loaded_template
    if not prompt and tpl.description:
        print(f"Template: {tpl.name}", file=sys.stderr)
        print(f"  {tpl.description}", file=sys.stderr)
        print(file=sys.stderr)
    return tpl


def _run_direct_endpoint(
    tpl: TemplateConfig,
    prompt: str,
    template_args: dict[str, str] | None,
    json_output: bool,
) -> None:
    assert tpl is not None, "template config must not be None"
    assert prompt, "prompt must not be empty"
    from .global_config import get_api_url
    wafer_api_url = os.environ.get("WAFER_API_URL", get_api_url())
    wafer_auth_token = os.environ.get("WAFER_AUTH_TOKEN", "")
    assert wafer_auth_token, "WAFER_AUTH_TOKEN not set. Run 'wafer login' first."

    async def _run_direct() -> None:
        await _stream_direct_endpoint(
            api_url=wafer_api_url,
            auth_token=wafer_auth_token,
            endpoint_path=tpl.direct_endpoint,
            query=prompt,
            template_args=template_args,
            defaults=tpl.defaults if tpl.defaults else None,
            json_output=json_output,
        )
    import trio
    trio.run(_run_direct)


def _resolve_system_prompt(tpl: TemplateConfig, base_system_prompt: str) -> str:
    assert tpl is not None, "template config must not be None"
    assert isinstance(base_system_prompt, str), "base_system_prompt must be a string"
    if tpl.include_skills:
        from wafer.core.rollouts.skills import discover_skills, format_skill_metadata_for_prompt
        skill_metadata = discover_skills()
        if skill_metadata:
            skill_section = format_skill_metadata_for_prompt(skill_metadata)
            return base_system_prompt + "\n\n" + skill_section
    return base_system_prompt


def _build_run_environment(
    tpl: TemplateConfig,
    tools: list[str] | None,
    template_args: dict[str, str] | None,
    _agent_logger: logging.Logger,
) -> Environment:
    assert tpl is not None, "template config must not be None"
    assert _agent_logger is not None, "_agent_logger must not be None"
    has_target = False
    try:
        from wafer.cli.targets import get_default_target
        has_target = get_default_target() is not None
    except Exception as exc:
        _agent_logger.warning("Failed to check default target: %s", exc)
    return _build_environment(
        tpl, tools, has_target=has_target, template_args=template_args
    )


def _execute_with_trio(run: Callable[[], Awaitable[None]]) -> None:
    assert callable(run), "run must be callable"
    import trio
    import trio_asyncio

    async def _with_asyncio_bridge() -> None:
        async with trio_asyncio.open_loop():
            await run()

    try:
        trio.run(_with_asyncio_bridge)
    except KeyboardInterrupt:
        pass


async def _init_trajectory(
    session_id: str | None,
    session_store: FileSessionStore,
    system_prompt: str,
) -> Trajectory:
    assert session_store is not None, "session_store must not be None"
    assert isinstance(system_prompt, str), "system_prompt must be a string"
    from wafer.core.rollouts import Message, Trajectory
    if session_id:
        existing_session, err = await session_store.get(session_id)  # type: ignore[union-attr]
        if err:
            print(f"Error loading session: {err}", file=sys.stderr)
            sys.exit(1)
        assert existing_session is not None
        return Trajectory(messages=existing_session.messages)
    return Trajectory(messages=[Message(role="system", content=system_prompt)])


async def _run_noninteractive(  # noqa: PLR0913
    trajectory: Trajectory,
    endpoint: Endpoint,
    environment: Environment,
    session_store: FileSessionStore,
    session_id: str | None,
    prompt: str | None,
    json_output: bool,
    output_format: str | None,
    resolved_single_turn: bool,
    _agent_logger: logging.Logger,
) -> None:
    assert trajectory is not None, "trajectory must not be None"
    assert endpoint is not None, "endpoint must not be None"
    from wafer.core.rollouts.agent_session import AgentSessionConfig, run_agent_session
    from wafer.core.rollouts.frontends import NoneFrontend

    if output_format == "stream-json":
        from wafer.core.rollouts.frontends.json_frontend import JsonFrontend
        frontend = JsonFrontend(include_thinking=False, include_timing=True)
    elif json_output:
        model_name = endpoint.model if hasattr(endpoint, "model") else None
        frontend = StreamingChunkFrontend(session_id=session_id, model=model_name)
    else:
        frontend = NoneFrontend(show_tool_calls=True, show_thinking=False)

    system_prompt = trajectory.messages[0].content if trajectory.messages else ""
    assert isinstance(system_prompt, str), "system_prompt must be a string"

    session_config = AgentSessionConfig(
        prompt=prompt or "",
        system_prompt=system_prompt,
        endpoint=endpoint,
        environment=environment,
        frontend=frontend,
        session_store=session_store,
        session_id=session_id,
        single_turn=resolved_single_turn,
    )

    _agent_logger.info(
        "Starting run_agent_session (single_turn=%s, prompt=%s)",
        resolved_single_turn,
        bool(prompt),
    )
    result = await run_agent_session(session_config)
    _agent_logger.info("run_agent_session completed (%d states)", len(result.states))

    if json_output and isinstance(frontend, StreamingChunkFrontend):
        first_session_id = (
            result.states[0].session_id if result.states and result.states[0].session_id else None
        )
        if first_session_id and not session_id:
            model_name = endpoint.model if hasattr(endpoint, "model") else None
            frontend.emit_session_start(first_session_id, model_name)
    if result.session_id:
        print(f"\nResume with: wafer agent --resume {result.session_id}")


def _apply_file_config_overrides(
    tpl: TemplateConfig,
    base_system_prompt: str,
    file_config: object | None,
) -> tuple[TemplateConfig, str]:
    """Apply config file overrides to template."""
    if file_config is None:
        return tpl, base_system_prompt

    from dataclasses import replace as dc_replace

    replacements: dict = {}

    fc_model = getattr(file_config, "model", None)
    if fc_model:
        replacements["model"] = fc_model

    fc_max_tokens = getattr(file_config, "max_tokens", None)
    if fc_max_tokens is not None:
        replacements["max_tokens"] = fc_max_tokens

    fc_tools = getattr(file_config, "tools", None)
    if fc_tools:
        replacements["tools"] = fc_tools

    fc_bash = getattr(file_config, "bash_allowlist", None)
    if fc_bash:
        replacements["bash_allowlist"] = fc_bash

    fc_single = getattr(file_config, "single_turn", None)
    if fc_single is not None:
        replacements["single_turn"] = fc_single

    fc_thinking = getattr(file_config, "thinking_enabled", None)
    if fc_thinking is not None:
        replacements["thinking"] = fc_thinking

    fc_budget = getattr(file_config, "thinking_budget_tokens", None)
    if fc_budget is not None:
        replacements["thinking_budget"] = fc_budget

    fc_network = getattr(file_config, "allow_network", None)
    if fc_network is not None:
        replacements["allow_network"] = fc_network

    if replacements:
        tpl = dc_replace(tpl, **replacements)

    fc_system = getattr(file_config, "system_prompt", None)
    if fc_system:
        base_system_prompt = fc_system

    return tpl, base_system_prompt


def _resolve_template_and_prompt(
    template: str | None,
    template_args: dict[str, str] | None,
    prompt: str | None,
    json_output: bool,
    file_config: object | None = None,
) -> tuple[TemplateConfig, str, bool]:
    assert isinstance(json_output, bool), "json_output must be a bool"
    assert isinstance(template, (str, type(None))), "template must be a string or None"
    if template:
        loaded_template, err = _load_template(template, template_args)
        if loaded_template is None:
            _load_and_validate_template(template, template_args, prompt)
            raise AssertionError("unreachable")
        tpl = loaded_template
        base_system_prompt = tpl.interpolate_prompt(template_args or {})
        if tpl.direct_endpoint is not None:
            assert prompt, (
                f"Template '{tpl.name}' uses direct streaming and requires a prompt. "
                f"Usage: wafer agent -t {tpl.name} \"your question\""
            )
            _run_direct_endpoint(tpl, prompt, template_args, json_output)
            return tpl, base_system_prompt, True
    else:
        tpl = _get_default_template()
        base_system_prompt = tpl.system_prompt
    return tpl, base_system_prompt, False


def _init_auth_and_env(
) -> tuple[str, str, Callable[[], Awaitable[str | None]] | None]:
    _setup_logging(verbose_env=False)
    api_base, api_key, api_key_refresh = _get_wafer_auth()
    if not api_base or not api_key:
        sys.exit(1)
    assert api_base is not None
    assert api_key is not None
    _setup_wafer_env_vars()
    return api_base, api_key, api_key_refresh


async def _run_agent_loop(  # noqa: PLR0913
    environment: Environment,
    session_id: str | None,
    session_store: FileSessionStore,
    system_prompt: str,
    interactive: bool,
    endpoint: Endpoint,
    prompt: str | None,
    json_output: bool,
    output_format: str | None,
    resolved_single_turn: bool,
    _agent_logger: logging.Logger,
) -> None:
    assert environment is not None, "environment must not be None"
    assert endpoint is not None, "endpoint must not be None"
    if hasattr(environment, "setup"):
        await environment.setup()
    trajectory = await _init_trajectory(session_id, session_store, system_prompt)
    try:
        if interactive:
            from wafer.core.rollouts.frontends.tui.interactive_agent import (
                run_interactive_agent,
            )
            await run_interactive_agent(
                trajectory, endpoint, environment, session_store,
                session_id, theme_name="minimal", debug=False,
                debug_layout=False, initial_prompt=prompt,
            )
        else:
            await _run_noninteractive(
                trajectory, endpoint, environment, session_store,
                session_id, prompt, json_output, output_format,
                resolved_single_turn, _agent_logger,
            )
    except KeyboardInterrupt:
        pass
    except BaseException as e:
        actual_error = _unwrap_exception(e)
        print(f"\n{type(actual_error).__name__}: {actual_error}", file=sys.stderr)
        sys.exit(1)


def main(  # noqa: PLR0913
    prompt: str | None = None,
    interactive: bool = False,
    resume: str | None = None,
    allow_spawn: bool = False,
    max_tool_fails: int | None = None,
    template: str | None = None,
    template_args: dict[str, str] | None = None,
    list_sessions: bool = False,
    get_session: str | None = None,
    json_output: bool = False,
    output_format: str | None = None,
    single_turn_override: bool | None = None,
    file_config: object | None = None,
) -> None:
    """Run wevin agent in-process via rollouts."""
    from wafer.core.rollouts import FileSessionStore
    session_store = FileSessionStore()
    if get_session:
        _handle_get_session(get_session, json_output, session_store)
        return
    if list_sessions:
        _handle_list_sessions(json_output, session_store)
        return
    structured_output = json_output or output_format == "stream-json"
    if structured_output:
        print(json.dumps({"type": "initializing"}), flush=True)
    _agent_logger = logging.getLogger("wafer.agent")
    api_base, api_key, api_key_refresh = _init_auth_and_env()
    tpl, base_system_prompt, did_direct = _resolve_template_and_prompt(
        template, template_args, prompt, structured_output, file_config=file_config,
    )
    if did_direct:
        return

    # Apply config file overrides (config file > template)
    tpl, base_system_prompt = _apply_file_config_overrides(
        tpl, base_system_prompt, file_config,
    )

    system_prompt = _resolve_system_prompt(tpl, base_system_prompt)
    structured_output = json_output or output_format == "stream-json"
    resolved_single_turn = (
        single_turn_override if single_turn_override is not None
        else (True if structured_output else tpl.single_turn)
    )
    if not sys.stdin.isatty():
        resolved_single_turn = True
    endpoint = _build_endpoint(tpl, None, api_base, api_key, api_key_refresh, file_config)
    environment = _build_run_environment(tpl, None, template_args, _agent_logger)
    subagent_configs = getattr(file_config, "subagents", None) or {}
    if subagent_configs and hasattr(environment, "subagent_configs"):
        environment.subagent_configs = subagent_configs
    working_dir = getattr(environment, "working_dir", Path.cwd())
    system_prompt = system_prompt + f"\n\n## Working directory\nYour working directory is `{working_dir.resolve()}`. Use relative paths (e.g. `./flashinfer`, `flashinfer`) for file operations - never assume paths like /home/user."
    try:
        from wafer.cli.targets import get_default_target, get_target_info, list_targets, load_target
        target_names = list_targets()
        default_target = get_default_target()
        if target_names:
            target_lines: list[str] = []
            for name in target_names:
                try:
                    target = load_target(name)
                    info = get_target_info(target)
                    marker = " (default)" if name == default_target else ""
                    target_lines.append(f"- `{name}`{marker}: {info['GPU']}, {info.get('Type', 'unknown')}")
                except Exception:
                    pass
            if target_lines:
                system_prompt += "\n\n## Available targets\n" + "\n".join(target_lines)
                if default_target:
                    system_prompt += f"\nDefault target: `{default_target}`"
    except Exception:
        pass
    session_store = FileSessionStore()
    session_id = _resolve_session_id(resume, session_store)

    async def run() -> None:
        await _run_agent_loop(
            environment, session_id, session_store, system_prompt,
            interactive, endpoint, prompt, json_output,
            output_format, resolved_single_turn, _agent_logger,
        )

    _execute_with_trio(run)
