"""Target operations for exec/ssh/sync commands.
This module provides the business logic for running commands on targets,
getting SSH credentials, and syncing files. It handles:
- Baremetal/VM: Direct SSH with configured credentials
- Workspace: Delegate to workspace API
- Modal: Not supported (no SSH access)
"""
from __future__ import annotations

import logging
import shlex
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wafer.core.async_ssh import SyncSSHClient
    from wafer.core.utils.kernel_utils.targets.config import (
        BaremetalTarget,
        TargetConfig,
        VMTarget,
    )
logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TargetSSHInfo:
    """SSH connection info for a target."""
    host: str
    port: int
    user: str
    key_path: Path


class TargetExecError(Exception):
    """Error during target operation (exec/ssh/sync)."""
    pass


def _expand_key_path(ssh_key: str) -> Path:
    """Expand SSH key path (synchronous, fast operation)."""
    return Path(ssh_key).expanduser()


async def get_target_ssh_info(target: TargetConfig) -> TargetSSHInfo:
    """Get SSH connection info for a target.
    For Baremetal/VM: Returns configured SSH info directly.
    For Modal/Workspace: Raises (no SSH access).
    Args:
        target: Target configuration
    Returns:
        TargetSSHInfo with host, port, user, key_path
    Raises:
        TargetExecError: If target type doesn't support SSH
    """
    from wafer.core.utils.kernel_utils.targets.config import (
        BaremetalTarget,
        ModalTarget,
        VMTarget,
        WorkspaceTarget,
    )
    if isinstance(target, (BaremetalTarget, VMTarget)):
        return _get_direct_ssh_info(target)
    elif isinstance(target, WorkspaceTarget):
        raise TargetExecError(
            f"WorkspaceTarget '{target.name}' uses API-based access.\n"
            "Use wafer target sync for file transfer. For command execution, use the sandbox tool."
        )
    elif isinstance(target, ModalTarget):
        raise TargetExecError(
            f"ModalTarget '{target.name}' is serverless and has no SSH access.\n"
            "Use 'wafer tool eval' to run code on Modal targets."
        )
    raise TargetExecError(f"Unknown target type: {type(target).__name__}")


def _get_direct_ssh_info(target: BaremetalTarget | VMTarget) -> TargetSSHInfo:
    """Get SSH info for Baremetal/VM target (no provisioning needed)."""
    from wafer.core.ssh_utils import parse_ssh_target

    parsed = parse_ssh_target(target.ssh_target)
    key_path = _expand_key_path(target.ssh_key)
    if not key_path.exists():
        raise TargetExecError(f"SSH key not found: {key_path}")
    return TargetSSHInfo(
        host=parsed.host,
        port=parsed.port,
        user=parsed.user,
        key_path=key_path,
    )


def _make_client(ssh_info: TargetSSHInfo) -> "SyncSSHClient":
    """Create a SyncSSHClient from TargetSSHInfo."""
    from wafer.core.async_ssh import SyncSSHClient
    connection_str = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
    return SyncSSHClient(connection_str, str(ssh_info.key_path))


def exec_on_target_sync(
    ssh_info: TargetSSHInfo,
    command: str,
    timeout_seconds: int | None = None,
) -> int:
    """Execute a command on target via SSH (synchronous).
    Returns exit code from the remote command.
    """
    client = _make_client(ssh_info)
    try:
        result = client.exec(command)
        if result.stdout:
            print(result.stdout, end="")
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr)
        return result.exit_code
    except Exception as e:
        raise TargetExecError(f"SSH exec failed: {e}") from e
    finally:
        client.close()


def sync_to_target(
    ssh_info: TargetSSHInfo,
    local_path: Path,
    remote_path: str | None = None,
    on_progress: Callable[[str], None] | None = None,
) -> int:
    """Sync files to target via SyncSSHClient (rsync under the hood).
    Returns number of files synced.
    """
    if remote_path is None:
        remote_path = f"/tmp/{local_path.name}"
    if on_progress:
        on_progress(f"Syncing {local_path} to {ssh_info.host}:{remote_path}")
    client = _make_client(ssh_info)
    try:
        result = client.upload_files(
            local_path=str(local_path.resolve()),
            remote_path=remote_path,
            recursive=local_path.is_dir(),
        )
        if not result.success:
            raise TargetExecError(f"Upload failed: {result.error_message}")
        if on_progress:
            on_progress(f"Synced {result.files_copied} files")
        return result.files_copied
    finally:
        client.close()


def pull_from_target(
    ssh_info: TargetSSHInfo,
    remote_path: str,
    local_path: Path,
    on_progress: Callable[[str], None] | None = None,
) -> int:
    """Pull files from target via SyncSSHClient (reverse of sync_to_target)."""
    assert remote_path, "Remote path must be non-empty"
    assert ssh_info.host, "SSH host must be non-empty"
    if on_progress:
        on_progress(f"Pulling {remote_path} from {ssh_info.host}")
    client = _make_client(ssh_info)
    try:
        is_dir = client.exec(f"test -d {shlex.quote(remote_path)}").exit_code == 0
        result = client.download_files(
            remote_path=remote_path,
            local_path=str(local_path),
            recursive=is_dir,
        )
        if not result.success:
            raise TargetExecError(f"Download failed: {result.error_message}")
        if on_progress:
            on_progress(f"Pulled {result.files_copied} files")
        return result.files_copied
    finally:
        client.close()


def parse_scp_path(path: str) -> tuple[str | None, str]:
    """Parse scp-style path into (target_name, path).
    Returns (None, path) for local paths, (target_name, remote_path) for remote.
    Examples:
        "./local/file" -> (None, "./local/file")
        "target:/remote/path" -> ("target", "/remote/path")
        "my-target:/tmp/foo" -> ("my-target", "/tmp/foo")
    """
    if ":" in path:

        if len(path) >= 2 and path[1] == ":" and path[0].isalpha():
            return (None, path)
        target, remote_path = path.split(":", 1)
        return (target, remote_path)
    return (None, path)


def _has_glob_chars(path: str) -> bool:
    """Check if path contains glob characters."""
    return any(c in path for c in "*?[]")


def _sanitize_glob_pattern(pattern: str) -> str:
    """Sanitize a glob pattern for safe shell execution.
    Escapes dangerous shell metacharacters while preserving glob characters (* ? [ ]).
    This prevents command injection while allowing glob expansion.
    """
    # Characters that could enable command injection
    dangerous_chars = {
        ";": r"\;",
        "$": r"\$",
        "`": r"\`",
        "|": r"\|",
        "&": r"\&",
        "(": r"\(",
        ")": r"\)",
        "{": r"\{",
        "}": r"\}",
        "<": r"\<",
        ">": r"\>",
        "\n": "",  # Remove newlines entirely
        "\r": "",
    }
    result = pattern
    for char, escaped in dangerous_chars.items():
        result = result.replace(char, escaped)
    return result


def _expand_remote_glob(ssh_info: TargetSSHInfo, pattern: str) -> list[str]:
    """Expand a glob pattern on the remote host.
    Returns list of matching file paths, empty if no matches.
    """
    safe_pattern = _sanitize_glob_pattern(pattern)
    client = _make_client(ssh_info)
    try:
        result = client.exec(f"ls -1d {safe_pattern} 2>/dev/null")
        if result.exit_code != 0 or not result.stdout.strip():
            return []
        return result.stdout.strip().split("\n")
    finally:
        client.close()


def _scp_single_file(
    ssh_info: TargetSSHInfo,
    remote_path: str,
    local_dest: str,
    recursive: bool,
) -> None:
    """Download a single file/dir from remote."""
    client = _make_client(ssh_info)
    try:
        result = client.download_files(
            remote_path=remote_path,
            local_path=local_dest,
            recursive=recursive,
        )
        if not result.success:
            raise TargetExecError(f"Download failed for {remote_path}: {result.error_message}")
    finally:
        client.close()


def _scp_glob_download(
    ssh_info: TargetSSHInfo,
    remote_pattern: str,
    local_dest: str,
    recursive: bool,
) -> None:
    """Download files matching a glob pattern from remote.
    Expands the glob on the remote host, then downloads each file.
    """
    files = _expand_remote_glob(ssh_info, remote_pattern)
    if not files:
        logger.warning(f"No files matched pattern: {remote_pattern}")
        return
    for remote_file in files:
        _scp_single_file(ssh_info, remote_file, local_dest, recursive)


def scp_transfer(
    ssh_info: TargetSSHInfo,
    source: str,
    dest: str,
    is_download: bool,
    recursive: bool = False,
) -> None:
    """Transfer files via SyncSSHClient. Supports glob patterns for downloads."""
    if is_download and _has_glob_chars(source):
        return _scp_glob_download(ssh_info, source, dest, recursive)
    client = _make_client(ssh_info)
    try:
        if is_download:
            result = client.download_files(
                remote_path=source,
                local_path=dest,
                recursive=recursive,
            )
            if not result.success:
                raise TargetExecError(f"Download failed: {result.error_message}")
        else:
            result = client.upload_files(
                local_path=source,
                remote_path=dest,
                recursive=recursive,
            )
            if not result.success:
                raise TargetExecError(f"Upload failed: {result.error_message}")
    finally:
        client.close()


# =============================================================================
# Tool Registry for `wafer settings deps install --target`
# =============================================================================
@dataclass(frozen=True)
class ToolSpec:
    """Specification for a tool that can be installed on a target."""
    name: str
    check_cmd: str  # Command to check if installed (exit 0 = installed)
    install_cmd: str | None  # Command to install (None = can't auto-install)
    verify_cmd: str | None = None  # Command to verify after install
    platform: str = "any"  # "amd", "nvidia", or "any"
    description: str = ""


TOOL_REGISTRY: dict[str, ToolSpec] = {
    # AMD Tools
    "rocprof-compute": ToolSpec(
        name="rocprof-compute",
        check_cmd="which rocprof-compute",
        # rocprofiler-compute requires ROCm >= 6.3 and apt install (not pip)
        # For older ROCm, users need to upgrade or install manually
        install_cmd="apt-get update && apt-get install -y rocprofiler-compute && python3 -m pip install -r /opt/rocm/libexec/rocprofiler-compute/requirements.txt",
        verify_cmd="rocprof-compute --version",
        platform="amd",
        description="AMD GPU profiling (roofline, memory, etc.) - requires ROCm >= 6.3",
    ),
    "rocprof-systems": ToolSpec(
        name="rocprof-systems",
        check_cmd="which rocprof-systems",
        # rocprofiler-systems also requires apt install on ROCm >= 6.3
        install_cmd="apt-get update && apt-get install -y rocprofiler-systems && python3 -m pip install -r /opt/rocm/libexec/rocprofiler-systems/requirements.txt",
        verify_cmd="rocprof-systems --version",
        platform="amd",
        description="AMD system-wide tracing - requires ROCm >= 6.3",
    ),
    "rocprof": ToolSpec(
        name="rocprof",
        check_cmd="which rocprof",
        install_cmd=None,  # Part of ROCm base install
        platform="amd",
        description="AMD kernel profiling (part of ROCm)",
    ),
    # NVIDIA Tools
    "ncu": ToolSpec(
        name="ncu",
        check_cmd="which ncu",
        install_cmd=None,  # Part of CUDA toolkit
        platform="nvidia",
        description="NVIDIA Nsight Compute (part of CUDA toolkit)",
    ),
    "nsys": ToolSpec(
        name="nsys",
        check_cmd="which nsys",
        install_cmd=None,  # Part of CUDA toolkit
        platform="nvidia",
        description="NVIDIA Nsight Systems (part of CUDA toolkit)",
    ),
    "nvtx": ToolSpec(
        name="nvtx",
        check_cmd='python -c "import nvtx"',
        install_cmd="pip install nvtx",
        verify_cmd='python -c "import nvtx; print(nvtx.__version__)"',
        platform="nvidia",
        description="NVIDIA Tools Extension (Python)",
    ),
    # Cross-platform Python packages
    "triton": ToolSpec(
        name="triton",
        check_cmd='python -c "import triton"',
        install_cmd="pip install triton",
        verify_cmd='python -c "import triton; print(triton.__version__)"',
        platform="any",
        description="OpenAI Triton compiler",
    ),
    "torch": ToolSpec(
        name="torch",
        check_cmd='python -c "import torch"',
        install_cmd="pip install torch",
        verify_cmd='python -c "import torch; print(torch.__version__)"',
        platform="any",
        description="PyTorch",
    ),
}


def get_target_platform(target: TargetConfig) -> str:
    """Determine platform (nvidia/amd/trainium/tpu/other) from target config."""
    from wafer.core.utils.kernel_utils.targets.config import get_target_platform as _get_platform
    return _get_platform(target)


@dataclass
class EnsureResult:
    """Result of ensure_tool operation."""
    tool: str
    already_installed: bool
    installed: bool
    verified: bool
    error: str | None = None


def ensure_tool(
    ssh_info: TargetSSHInfo,
    tool: str,
    force: bool = False,
    timeout: int = 300,
) -> EnsureResult:
    """Ensure a tool is installed on target.
    Args:
        ssh_info: SSH connection info
        tool: Tool name from TOOL_REGISTRY
        force: If True, reinstall even if present
        timeout: Timeout for install command
    Returns:
        EnsureResult with status
    """
    if tool not in TOOL_REGISTRY:
        return EnsureResult(
            tool=tool,
            already_installed=False,
            installed=False,
            verified=False,
            error=f"Unknown tool: {tool}. Available: {', '.join(sorted(TOOL_REGISTRY.keys()))}",
        )
    spec = TOOL_REGISTRY[tool]

    if not force:
        exit_code = exec_on_target_sync(ssh_info, spec.check_cmd, timeout_seconds=30)
        if exit_code == 0:
            return EnsureResult(
                tool=tool,
                already_installed=True,
                installed=False,
                verified=True,
            )
    # Can't auto-install
    if spec.install_cmd is None:
        return EnsureResult(
            tool=tool,
            already_installed=False,
            installed=False,
            verified=False,
            error=f"{tool} cannot be auto-installed. It's part of the base platform (ROCm/CUDA).",
        )
    # Install
    exit_code = exec_on_target_sync(ssh_info, spec.install_cmd, timeout_seconds=timeout)
    if exit_code != 0:
        return EnsureResult(
            tool=tool,
            already_installed=False,
            installed=False,
            verified=False,
            error=f"Installation failed (exit code {exit_code})",
        )
    # Verify
    verified = True
    if spec.verify_cmd:
        exit_code = exec_on_target_sync(ssh_info, spec.verify_cmd, timeout_seconds=30)
        verified = exit_code == 0
    return EnsureResult(
        tool=tool,
        already_installed=False,
        installed=True,
        verified=verified,
        error=None if verified else "Installation succeeded but verification failed",
    )
