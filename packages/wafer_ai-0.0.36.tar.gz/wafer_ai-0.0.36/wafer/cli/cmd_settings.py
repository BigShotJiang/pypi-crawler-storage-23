# ruff: noqa: PLR0913, E402
"""Wafer settings sub-commands – auth, config, billing, deps, and onboarding."""
from __future__ import annotations

import json
import os
import shutil
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

import typer

if TYPE_CHECKING:
    from .global_config import ApiEnvironment, GlobalConfig

# ---------------------------------------------------------------------------
# Typer sub-app definitions
# ---------------------------------------------------------------------------

settings_app = typer.Typer(
    name="settings",
    help="Config, billing, deps, and provider management.",
    no_args_is_help=True,
)

config_app = typer.Typer(help="Manage CLI configuration")
ssh_keys_app = typer.Typer(help="Manage SSH keys (user keys for workspace access + agent keys for cloud agents).")
github_app = typer.Typer(
    help="Connect GitHub App and list repos for cloud agent.",
)
billing_app = typer.Typer(help="Manage billing, credits, and subscription")
skill_app = typer.Typer(help="Manage AI coding assistant skills (Claude Code, Codex)")
provider_auth_app = typer.Typer(help="Manage API keys for cloud GPU providers")

# ---------------------------------------------------------------------------
# Sub-app registrations on settings_app
# ---------------------------------------------------------------------------

settings_app.add_typer(config_app, name="config")
settings_app.add_typer(billing_app, name="billing")
settings_app.add_typer(ssh_keys_app, name="ssh-keys")
settings_app.add_typer(github_app, name="github")
settings_app.add_typer(skill_app, name="skill")
settings_app.add_typer(provider_auth_app, name="auth")

# deps_app is registered by app.py after import:
#   from .deps import deps_app
#   settings_app.add_typer(deps_app, name="deps")

# ---------------------------------------------------------------------------
# Shared helpers (imported from app at call-time to avoid circular imports)
# ---------------------------------------------------------------------------


def _mark_command_success() -> None:
    from .app import _mark_command_success as _impl
    _impl()


def _cloud_auth_headers() -> tuple[str, dict[str, str]]:
    from .cmd_agent import _cloud_auth_headers as _impl
    return _impl()


# ============================================================================
# Telemetry command (single command: --on/--off to set, bare to show status)
# ============================================================================


@settings_app.command("telemetry")
def telemetry(
    on: bool = typer.Option(False, "--on", help="Enable analytics and data retention"),
    off: bool = typer.Option(False, "--off", help="Disable analytics and data retention"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show or toggle analytics and data retention. Use --on or --off to change."""
    from .global_config import (
        GlobalConfig,
        load_global_config,
        save_global_config,
    )
    from .output import json_response

    assert not (on and off), "Cannot pass both --on and --off"

    config = load_global_config()

    if on or off:
        enabled = on
        new_prefs = config.preferences.__class__(
            mode=config.preferences.mode,
            analytics_enabled=enabled,
            data_retention_enabled=enabled,
        )
        new_config = GlobalConfig(
            environment=config.environment,
            environments=config.environments,
            preferences=new_prefs,
            defaults=config.defaults,
        )
        save_global_config(new_config)
        label = "enabled" if enabled else "disabled"
        if json_output:
            typer.echo(json_response(data={
                "analytics_enabled": enabled,
                "data_retention_enabled": enabled,
            }))
        else:
            typer.echo(f"Telemetry {label}.")
            typer.echo(f"  Analytics: {label}")
            typer.echo(f"  Data retention: {label}")
        return

    analytics = config.preferences.analytics_enabled
    retention = config.preferences.data_retention_enabled
    if json_output:
        typer.echo(json_response(data={
            "analytics_enabled": analytics,
            "data_retention_enabled": retention,
        }))
    else:
        a_status = "enabled" if analytics else "disabled"
        r_status = "enabled" if retention else "disabled"
        typer.echo(f"Analytics: {a_status}")
        typer.echo(f"Data retention: {r_status}")


# ============================================================================
# Skill commands
# ============================================================================


@skill_app.command("install")
def skill_install(
    target: str = typer.Option(
        "all",
        "--target",
        "-t",
        help="Target tool: claude, codex, cursor, or all",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing skill"),
) -> None:
    """Install the wafer-guide skill for AI coding assistants."""
    skill_source = Path(__file__).parent / "skills" / "wafer-guide"
    if not skill_source.exists():
        typer.echo("Error: Bundled skill not found. Package may be corrupted.", err=True)
        raise typer.Exit(1)
    targets_to_install: list[tuple[str, Path]] = []
    if target in ("all", "claude"):
        targets_to_install.append((
            "Claude Code",
            Path.home() / ".claude" / "skills" / "wafer-guide",
        ))
    if target in ("all", "codex"):
        targets_to_install.append(("Codex CLI", Path.home() / ".codex" / "skills" / "wafer-guide"))
    if target in ("all", "cursor"):
        targets_to_install.append(("Cursor", Path.home() / ".cursor" / "skills" / "wafer-guide"))
    if not targets_to_install:
        typer.echo(
            f"Error: Unknown target '{target}'. Use: claude, codex, cursor, or all", err=True
        )
        raise typer.Exit(1)
    for tool_name, dest_path in targets_to_install:
        if dest_path.exists() or dest_path.is_symlink():
            if not force:
                typer.echo(f"  {tool_name}: Already installed at {dest_path}")
                typer.echo("             Use --force to overwrite")
                continue
            if dest_path.is_symlink():
                dest_path.unlink()
            else:
                shutil.rmtree(dest_path)
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        dest_path.symlink_to(skill_source)
        typer.echo(f"  {tool_name}: Installed at {dest_path}")
    typer.echo("")
    typer.echo("Restart your AI assistant to load the new skill.")


@skill_app.command("uninstall")
def skill_uninstall(
    target: str = typer.Option(
        "all",
        "--target",
        "-t",
        help="Target tool: claude, codex, cursor, or all",
    ),
) -> None:
    """Uninstall the wafer-guide skill."""
    targets_to_uninstall: list[tuple[str, Path]] = []
    if target in ("all", "claude"):
        targets_to_uninstall.append((
            "Claude Code",
            Path.home() / ".claude" / "skills" / "wafer-guide",
        ))
    if target in ("all", "codex"):
        targets_to_uninstall.append((
            "Codex CLI",
            Path.home() / ".codex" / "skills" / "wafer-guide",
        ))
    if target in ("all", "cursor"):
        targets_to_uninstall.append((
            "Cursor",
            Path.home() / ".cursor" / "skills" / "wafer-guide",
        ))
    if not targets_to_uninstall:
        typer.echo(
            f"Error: Unknown target '{target}'. Use: claude, codex, cursor, or all", err=True
        )
        raise typer.Exit(1)
    for tool_name, dest_path in targets_to_uninstall:
        if not dest_path.exists():
            typer.echo(f"  {tool_name}: Not installed")
            continue
        if dest_path.is_symlink():
            dest_path.unlink()
        else:
            shutil.rmtree(dest_path)
        typer.echo(f"  {tool_name}: Uninstalled from {dest_path}")


@skill_app.command("status")
def skill_status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show installation status of the wafer-guide skill."""
    from .output import json_response
    skill_source = Path(__file__).parent / "skills" / "wafer-guide"

    assert skill_source.exists(), f"Bundled skill missing at {skill_source}"

    installations = [
        ("Cursor", "cursor", Path.home() / ".cursor" / "skills" / "wafer-guide"),
        ("Claude Code", "claude", Path.home() / ".claude" / "skills" / "wafer-guide"),
        ("Codex CLI", "codex", Path.home() / ".codex" / "skills" / "wafer-guide"),
    ]

    if json_output:
        tools = []
        for display_name, flag, path in installations:
            installed = path.exists() or path.is_symlink()
            tools.append({
                "tool": display_name,
                "flag": flag,
                "installed": installed,
                "path": str(path),
            })
        typer.echo(json_response(data={
            "skill": "wafer-guide",
            "description": "GPU kernel development knowledge for AI coding assistants.",
            "bundled": True,
            "installations": tools,
        }))
        return

    typer.echo("wafer-guide (bundled)")
    typer.echo("  GPU kernel development knowledge for AI coding assistants.")
    typer.echo("")

    typer.echo("Installed for:")
    for display_name, flag, path in installations:
        if path.exists() or path.is_symlink():
            typer.echo(f"  {display_name + ':':<14} Installed")
        else:
            typer.echo(f"  {display_name + ':':<14} Not installed  (run: wafer settings skill install -t {flag})")


# ============================================================================
# Provider auth commands
# ============================================================================


@provider_auth_app.command("login")
def provider_auth_login(
    provider: str = typer.Argument(
        ...,
        help="Provider name: modal, anthropic, or openai",
    ),
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        "-k",
        help="API key (if not provided, reads from stdin)",
    ),
) -> None:
    """Save API key for a provider."""
    import sys

    from wafer.core.auth import PROVIDERS, save_api_key
    if provider not in PROVIDERS:
        typer.echo(f"Error: Unknown provider '{provider}'", err=True)
        typer.echo(f"Valid providers: {', '.join(PROVIDERS.keys())}", err=True)
        raise typer.Exit(1)
    if api_key is None:
        if sys.stdin.isatty():
            typer.echo(f"Enter API key for {PROVIDERS[provider]['display_name']}:")
            api_key = typer.prompt("API key", hide_input=True)
        else:
            api_key = sys.stdin.read().strip()
    if not api_key:
        typer.echo("Error: No API key provided", err=True)
        raise typer.Exit(1)
    save_api_key(provider, api_key)
    typer.echo(f"API key saved for {PROVIDERS[provider]['display_name']}")
    typer.echo("Stored in: ~/.wafer/auth.json")


@provider_auth_app.command("logout")
def provider_auth_logout(
    provider: str = typer.Argument(
        ...,
        help="Provider name: modal, anthropic, or openai",
    ),
) -> None:
    """Remove stored API key for a provider."""
    from wafer.core.auth import PROVIDERS, remove_api_key
    if provider not in PROVIDERS:
        typer.echo(f"Error: Unknown provider '{provider}'", err=True)
        typer.echo(f"Valid providers: {', '.join(PROVIDERS.keys())}", err=True)
        raise typer.Exit(1)
    if remove_api_key(provider):
        typer.echo(f"API key removed for {PROVIDERS[provider]['display_name']}")
    else:
        typer.echo(f"No stored API key found for {PROVIDERS[provider]['display_name']}")


@provider_auth_app.command("status")
def provider_auth_status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show authentication status for all providers."""
    from wafer.core.auth import get_all_auth_status

    from .output import json_response
    statuses = get_all_auth_status()

    if json_output:
        providers = []
        for s in statuses:
            providers.append({
                "provider": s.provider,
                "display_name": s.display_name,
                "authenticated": s.is_authenticated,
                "source": s.source if s.is_authenticated else None,
                "key_preview": s.key_preview if s.is_authenticated else None,
            })
        typer.echo(json_response(data={"providers": providers}))
        return

    typer.echo("Cloud GPU Provider Authentication Status")
    typer.echo("=" * 45)
    for status in statuses:
        if status.is_authenticated:
            source_str = f"({status.source})" if status.source else ""
            typer.echo(f"  {status.display_name}: [ok] {status.key_preview} {source_str}")
        else:
            typer.echo(f"  {status.display_name}: [fail] Not configured")
            typer.echo(f"      Run: wafer settings auth login {status.provider}")
            typer.echo(f"      Or set: {status.key_url}")
    typer.echo("")
    typer.echo("Note: Environment variables take precedence over stored keys.")


# ============================================================================
# Config commands
# ============================================================================


def _format_target_summary(target: object) -> str:
    """Format a single target as a one-line summary string."""
    _TYPE_MAP = {
        "BaremetalTarget": "baremetal",
        "VMTarget": "vm",
        "ModalTarget": "modal",
        "WorkspaceTarget": "workspace",
    }
    target_type = _TYPE_MAP.get(type(target).__name__, "unknown")

    details = ""
    if hasattr(target, "ssh_target"):
        details = f"  {target.ssh_target}"
    elif hasattr(target, "workspace_id"):
        details = f"  workspace:{target.workspace_id}"
    elif hasattr(target, "modal_app_name"):
        details = f"  app:{target.modal_app_name}"

    gpu = getattr(target, "gpu_type", None)
    if gpu:
        details += f"  ({gpu})"

    return f"[{target_type}]{details}"


def _show_targets() -> list[str]:
    """Return lines describing configured targets."""
    import httpx

    from .targets import get_default_target
    from .user_targets_api import list_targets as api_list_targets, user_target_to_baremetal_target

    lines: list[str] = []
    try:
        all_targets = api_list_targets()
    except RuntimeError:
        lines.append("  (not authenticated)")
        return lines
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            lines.append("  (not authenticated)")
            return lines
        raise

    if not all_targets:
        lines.append("  None configured")
        lines.append("  Run 'wafer target init' to set up a target.")
        return lines

    default_target = get_default_target()
    for t in all_targets:
        name = t.get("name", "?")
        marker = " (default)" if name == default_target else ""
        try:
            target = user_target_to_baremetal_target(t)
            summary = _format_target_summary(target)
            lines.append(f"  {name}{marker}  {summary}")
        except (ValueError, TypeError, KeyError) as exc:
            lines.append(f"  {name}{marker}  (error: {exc})")

    return lines


def _show_docker_config() -> list[str]:
    """Return lines describing Docker execution configuration."""
    config_path = Path.home() / ".wafer" / "config.toml"
    if not config_path.exists():
        return ["  Not configured"]

    try:
        from wafer.core.config import WaferConfig, load_config

        _, project_cfg = load_config(config_path.parent)
        if project_cfg is None:
            return ["  Not configured"]
    except (ImportError, TypeError, FileNotFoundError, OSError):
        return ["  Not configured"]

    lines: list[str] = []
    if project_cfg.allowlist.allow:
        lines.append("  Allowlist:   " + ", ".join(project_cfg.allowlist.allow))
    if project_cfg.allowlist.block:
        lines.append("  Blocklist:   " + ", ".join(project_cfg.allowlist.block))
    if not lines:
        lines.append("  Default settings")
    return lines


def _show_cloud_providers() -> list[str]:
    """Return lines describing cloud provider auth status."""
    from wafer.core.auth import get_all_auth_status

    cloud_providers = {"modal"}
    lines: list[str] = []
    for status in get_all_auth_status():
        if status.provider not in cloud_providers:
            continue
        if status.is_authenticated:
            source_hint = f" (from {status.source})" if status.source else ""
            lines.append(f"  {status.display_name + ':':<20} Configured{source_hint}")
        else:
            lines.append(f"  {status.display_name + ':':<20} Not configured")
    return lines


def _config_show_json(global_cfg: GlobalConfig, api_env: ApiEnvironment, creds: Any, config_file: Path) -> dict[str, Any]:
    assert global_cfg is not None, "global_cfg must not be None"
    assert isinstance(config_file, Path), "config_file must be a Path"

    from .targets import get_default_target, list_targets, load_target
    target_names = list_targets()
    default_target = get_default_target()
    targets_data: list[dict[str, Any]] = []
    for name in target_names:
        entry: dict[str, Any] = {"name": name, "default": name == default_target}
        try:
            t = load_target(name)
            entry["type"] = type(t).__name__
            if hasattr(t, "ssh_target"):
                entry["ssh_target"] = t.ssh_target
            if hasattr(t, "gpu_type") and t.gpu_type:
                entry["gpu_type"] = t.gpu_type
        except (FileNotFoundError, ValueError, TypeError, OSError):
            entry["error"] = "failed to load config"
        targets_data.append(entry)
    providers_data: list[dict[str, Any]] = []
    try:
        from wafer.core.auth import get_all_auth_status
        cloud_providers = {"modal"}
        for s in get_all_auth_status():
            if s.provider not in cloud_providers:
                continue
            providers_data.append({
                "provider": s.provider,
                "display_name": s.display_name,
                "configured": s.is_authenticated,
                "source": s.source if s.is_authenticated else None,
            })
    except (ImportError, OSError, ValueError):
        pass
    return {
        "config_file": str(config_file),
        "config_file_exists": config_file.exists(),
        "api": {
            "environment": global_cfg.environment,
            "api_url": api_env.api_url,
            "authenticated": creds is not None,
            "email": creds.email if creds else None,
        },
        "defaults": {
            "mode": global_cfg.preferences.mode,
            "workspace": global_cfg.defaults.workspace,
            "repo": global_cfg.defaults.repo,
            "gpu": global_cfg.defaults.gpu,
            "exec_timeout": global_cfg.defaults.exec_timeout,
        },
        "targets": targets_data,
        "cloud_providers": providers_data,
    }


def _config_show_text(global_cfg: GlobalConfig, api_env: ApiEnvironment, auth_line: str, config_file: Path) -> None:
    assert isinstance(auth_line, str), "auth_line must be a string"
    assert isinstance(config_file, Path), "config_file must be a Path"

    if config_file.exists():
        typer.echo(f"Config: {config_file}")
    else:
        typer.echo(f"Config: {config_file} (not found, using defaults)")
        typer.echo("  Run 'wafer settings config show' to check your config.")
    typer.echo("\nAPI:")
    typer.echo(f"  Environment: {global_cfg.environment}")
    typer.echo(f"  API URL:     {api_env.api_url}")
    typer.echo(f"  Auth:        {auth_line}")
    mode = global_cfg.preferences.mode
    mode_desc = (
        "verbose status messages" if mode == "explicit" else "quiet output, use -v for details"
    )
    typer.echo("\nDefaults:")
    typer.echo(f"  Mode:        {mode} ({mode_desc})")
    if global_cfg.defaults.workspace:
        typer.echo(f"  Workspace:   {global_cfg.defaults.workspace}")
    if global_cfg.defaults.repo:
        typer.echo(f"  Repo:        {global_cfg.defaults.repo}")
    typer.echo(f"  GPU:         {global_cfg.defaults.gpu}")
    typer.echo(f"  Timeout:     {global_cfg.defaults.exec_timeout}s")
    typer.echo("\nTargets:")
    for line in _show_targets():
        typer.echo(line)
    typer.echo("\nDocker:")
    for line in _show_docker_config():
        typer.echo(line)
    typer.echo("\nCloud Providers:")
    try:
        for line in _show_cloud_providers():
            typer.echo(line)
    except (ImportError, OSError, ValueError):
        typer.echo("  (unable to check provider status)")


@config_app.command("show")
def config_show_new(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current configuration.

    Displays a unified view of all Wafer configuration: API settings,
    authentication, targets, Docker environments, and cloud providers.
    """
    from .auth import load_credentials
    from .global_config import CONFIG_FILE, load_global_config
    from .output import json_response

    global_cfg: GlobalConfig = load_global_config()
    api_env = global_cfg.get_api_environment()
    creds = load_credentials()

    if creds and creds.email:
        auth_line = creds.email
    elif creds:
        auth_line = "Logged in (run 'wafer whoami --verify' to check)"
    else:
        auth_line = "Not logged in (run 'wafer login')"

    if json_output:
        typer.echo(json_response(data=_config_show_json(global_cfg, api_env, creds, CONFIG_FILE)))
        return
    _config_show_text(global_cfg, api_env, auth_line, CONFIG_FILE)


def _config_set_field(config: GlobalConfig, section: str, field: str, value: str) -> GlobalConfig:
    assert isinstance(section, str) and section, "section must be a non-empty string"
    assert isinstance(field, str) and field, "field must be a non-empty string"

    from dataclasses import replace
    if section == "api":
        if field == "environment":
            if value not in config.environments:
                typer.echo(
                    f"Error: Unknown environment '{value}'. "
                    f"Available: {', '.join(config.environments.keys())}",
                    err=True,
                )
                raise typer.Exit(1)
            return replace(config, environment=value)
        typer.echo(f"Error: Unknown api field '{field}'. Available: environment", err=True)
        raise typer.Exit(1)
    if section == "defaults":
        if field == "workspace":
            new_defaults = replace(config.defaults, workspace=value if value else None)
            return replace(config, defaults=new_defaults)
        elif field == "repo":
            new_defaults = replace(config.defaults, repo=value if value else None)
            return replace(config, defaults=new_defaults)
        elif field == "gpu":
            return replace(config, defaults=replace(config.defaults, gpu=value))
        elif field == "exec_timeout":
            try:
                timeout = int(value)
                assert timeout > 0, "timeout must be positive"
            except (ValueError, AssertionError) as e:
                typer.echo(f"Error: exec_timeout must be a positive integer: {e}", err=True)
                raise typer.Exit(1) from None
            return replace(config, defaults=replace(config.defaults, exec_timeout=timeout))
        typer.echo(
            f"Error: Unknown defaults field '{field}'. Available: workspace, repo, gpu, exec_timeout",
            err=True,
        )
        raise typer.Exit(1)
    if section == "preferences":
        if field == "mode":
            if value not in ("explicit", "implicit"):
                typer.echo(
                    f"Error: mode must be 'explicit' or 'implicit', got '{value}'", err=True,
                )
                raise typer.Exit(1)
            return replace(config, preferences=replace(config.preferences, mode=value))
        typer.echo(f"Error: Unknown preferences field '{field}'. Available: mode", err=True)
        raise typer.Exit(1)
    typer.echo(
        f"Error: Unknown section '{section}'. Available: api, defaults, preferences",
        err=True,
    )
    raise typer.Exit(1)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (e.g., api.environment, defaults.workspace)"),
    value: str = typer.Argument(..., help="Value to set"),
) -> None:
    """Set a configuration value."""
    from .global_config import (
        CONFIG_FILE,
        GlobalConfig,
        clear_config_cache,
        load_global_config,
        save_global_config,
    )
    if CONFIG_FILE.exists():
        config = load_global_config()
    else:
        config = GlobalConfig()
    parts = key.split(".")
    if len(parts) != 2:
        typer.echo(f"Error: Invalid key format '{key}'. Use 'section.key' format.", err=True)
        typer.echo("Examples: api.environment, defaults.workspace, preferences.mode", err=True)
        raise typer.Exit(1)
    section, field = parts
    config = _config_set_field(config, section, field, value)
    save_global_config(config)
    clear_config_cache()
    typer.echo(f"Set {key} = {value}")


# ============================================================================
# Login / logout / whoami / status / guide
# ============================================================================


def _login_interactive(port: int | None, no_device_code: bool) -> tuple[str, str | None, str | None]:
    assert isinstance(no_device_code, bool), "no_device_code must be a bool"
    assert port is None or isinstance(port, int), "port must be int or None"

    from .auth import browser_login, device_code_login
    from .global_config import load_global_config
    is_ssh = bool(os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_CLIENT"))
    is_local = load_global_config().environment == "local"
    try:
        if is_ssh and not no_device_code:
            typer.echo("SSH session detected - using device code authentication")
            typer.echo("   (No port forwarding required!)")
            typer.echo("")
            return device_code_login()
        if is_local and not no_device_code:
            typer.echo("Local environment - using device code flow (redirects to wafer-app)")
            typer.echo("")
            return device_code_login()
        if is_ssh:
            typer.echo("SSH session detected - using browser authentication")
            typer.echo("   Make sure you have port forwarding set up:")
            if port is None:
                port = 8765
            typer.echo(f"   ssh -L {port}:localhost:{port} user@host")
            typer.echo("")
        return browser_login(port=port)
    except (TimeoutError, RuntimeError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except KeyboardInterrupt:
        typer.echo("\nCancelled", err=True)
        raise typer.Exit(1) from None


def _login_verify_token(token: str, verify_fn: Callable[..., Any]) -> Any:
    assert isinstance(token, str) and token.strip(), "token must be a non-empty string"
    assert callable(verify_fn), "verify_fn must be callable"

    import httpx
    typer.echo("Verifying token...")
    try:
        return verify_fn(token)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            typer.echo("Error: Invalid token", err=True)
        else:
            typer.echo(f"Error: API returned {e.response.status_code}", err=True)
        raise typer.Exit(1) from None
    except httpx.RequestError as e:
        typer.echo(f"Error: Could not reach API: {e}", err=True)
        raise typer.Exit(1) from None


def login(
    token: str | None = typer.Option(
        None, "--token", "-t", help="Access token (skip browser OAuth)"
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        "-p",
        help="Port for OAuth callback server (local only, ignored for SSH)",
    ),
    no_device_code: bool = typer.Option(
        False,
        "--no-device-code",
        help="Force browser OAuth even on SSH (requires port forwarding)",
    ),
) -> None:
    """Authenticate CLI with wafer-api via GitHub OAuth."""
    from .auth import save_credentials, verify_token
    from .global_config import get_api_url, get_supabase_url, load_global_config
    config = load_global_config()
    typer.echo(f"Environment: {config.environment}")
    typer.echo(f"API: {get_api_url()}")
    typer.echo(f"Auth: {get_supabase_url()}")
    typer.echo("")
    if token is None:
        token, refresh_token, provider_token = _login_interactive(port, no_device_code)
    else:
        refresh_token = None
        provider_token = None
    if not token.strip():
        typer.echo("Error: Token cannot be empty", err=True)
        raise typer.Exit(1)
    token = token.strip()
    user_info = _login_verify_token(token, verify_token)
    save_credentials(token, refresh_token, user_info.email, provider_token)
    from . import analytics
    analytics.track_login(user_info.user_id, user_info.email)
    if user_info.email:
        typer.echo(f"Logged in as {user_info.email}")
    else:
        typer.echo(f"Logged in (user_id: {user_info.user_id})")
    typer.echo("Token saved to ~/.wafer/credentials.json")


def logout() -> None:
    """Remove stored credentials."""
    from . import analytics
    from .auth import clear_credentials

    analytics.track_logout()
    if clear_credentials():
        typer.echo("Logged out. Credentials removed.")
    else:
        typer.echo("Not logged in (no credentials found).")


def _whoami_token_status(creds: Any, token_expired_fn: Callable[..., bool]) -> tuple[bool, str | None]:
    assert creds is not None, "creds must not be None"
    assert callable(token_expired_fn), "token_expired_fn must be callable"

    import json as json_module
    token_valid = not token_expired_fn(creds.access_token)
    expires_in_str = None
    if creds.access_token:
        try:
            import base64
            payload_b64 = creds.access_token.split(".")[1]
            padded = payload_b64 + "=" * (-len(payload_b64) % 4)
            payload = json_module.loads(base64.urlsafe_b64decode(padded))
            remaining = payload["exp"] - time.time()
            if remaining > 0:
                if remaining < 60:
                    expires_in_str = f"{int(remaining)}s"
                elif remaining < 3600:
                    expires_in_str = f"{int(remaining / 60)}m"
                elif remaining < 86400:
                    expires_in_str = f"{int(remaining / 3600)}h {int((remaining % 3600) / 60)}m"
                else:
                    expires_in_str = f"{int(remaining / 86400)}d"
            else:
                expires_in_str = "expired"
                token_valid = False
        except Exception:
            pass
    return token_valid, expires_in_str


def _whoami_billing_info(token_valid: bool) -> tuple[str | None, str | None]:
    assert isinstance(token_valid, bool), "token_valid must be a bool"
    assert token_valid is True or token_valid is False, "token_valid must be exactly True or False"

    import json as json_module
    if not token_valid:
        return None, None
    try:
        from .billing import get_usage
        usage_json = get_usage(json_output=True)
        envelope = json_module.loads(usage_json)
        usage = envelope.get("data", {})
        tier = usage.get("tier", "unknown")
        tier_info = "Hacker" if tier.lower() == "start" else tier.capitalize()
        status = usage.get("status", "unknown")
        credits_limit = usage.get("credits_limit_cents", 0)
        if credits_limit == -1 or tier.lower() == "enterprise":
            credits_remaining = "unlimited"
        else:
            credits_cents = usage.get("credits_remaining_cents", 0)
            credits_remaining = f"${credits_cents / 100:.2f}"
        if status in ["past_due", "inactive", "cancelled"]:
            tier_info = f"{tier_info} ({status})"
        return tier_info, credits_remaining
    except Exception:
        return None, None


def _whoami_json(
    creds: Any, env_name: str, api_url: str, token_valid: bool,
    expires_in_str: str | None, tier_info: str | None, credits_remaining: str | None,
) -> None:
    assert creds is not None, "creds must not be None"
    assert isinstance(env_name, str) and env_name, "env_name must be a non-empty string"

    from .output import json_response
    result: dict = {
        "email": creds.email or "unknown",
        "environment": env_name,
        "api_url": api_url,
        "token_valid": token_valid,
    }
    if expires_in_str:
        result["token_expires_in"] = expires_in_str
    if tier_info:
        result["tier"] = tier_info
    if credits_remaining:
        result["credits_remaining"] = credits_remaining
    typer.echo(json_response(data=result))


def _whoami_text(
    creds: Any, env_name: str, api_url: str, token_valid: bool,
    expires_in_str: str | None, tier_info: str | None, credits_remaining: str | None,
) -> None:
    assert creds is not None, "creds must not be None"
    assert isinstance(env_name, str) and env_name, "env_name must be a non-empty string"

    lines = [creds.email or "Logged in"]
    lines.append(f"  Environment: {env_name} ({api_url})")
    if token_valid:
        if expires_in_str and expires_in_str != "expired":
            lines.append(f"  Token: valid (expires in {expires_in_str})")
        else:
            lines.append("  Token: valid")
    else:
        lines.append("  WARNING: Token expired. Run 'wafer login' to re-authenticate.")
    if tier_info:
        lines.append(f"  Tier: {tier_info}")
    if credits_remaining:
        if credits_remaining == "unlimited":
            lines.append("  Credits: unlimited")
        else:
            lines.append(f"  Credits: {credits_remaining} remaining")
    typer.echo("\n".join(lines))
    if not token_valid:
        raise typer.Exit(1)


def whoami(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current authenticated user and account information."""
    from .auth import _token_expired, load_credentials
    from .global_config import get_api_url, load_global_config
    creds = load_credentials()
    if creds is None:
        if json_output:
            from .output import json_error
            typer.echo(json_error("Not logged in"))
        else:
            typer.echo("Not logged in. Run: wafer login")
        raise typer.Exit(1)
    config = load_global_config()
    env_name = config.environment
    api_url = get_api_url()
    token_valid, expires_in_str = _whoami_token_status(creds, _token_expired)
    tier_info, credits_remaining = _whoami_billing_info(token_valid)
    if json_output:
        _whoami_json(creds, env_name, api_url, token_valid, expires_in_str, tier_info, credits_remaining)
    else:
        _whoami_text(creds, env_name, api_url, token_valid, expires_in_str, tier_info, credits_remaining)


def _status_check_config(checks: list[dict[str, Any]], config_dir: Path) -> None:
    assert isinstance(checks, list), "checks must be a list"
    assert isinstance(config_dir, Path), "config_dir must be a Path"

    if config_dir.exists() and config_dir.is_dir():
        checks.append({"name": "config_directory", "ok": True, "detail": str(config_dir)})
    else:
        checks.append({"name": "config_directory", "ok": False, "detail": f"{config_dir} not found"})


def _status_check_auth(checks: list[dict[str, Any]], load_creds_fn: Callable[..., Any], token_expired_fn: Callable[..., bool]) -> None:
    assert isinstance(checks, list), "checks must be a list"
    assert callable(load_creds_fn), "load_creds_fn must be callable"

    creds = load_creds_fn()
    if creds is None:
        checks.append({"name": "authentication", "ok": False, "detail": "Not logged in"})
    elif token_expired_fn(creds.access_token):
        checks.append({"name": "authentication", "ok": False, "detail": "Token expired"})
    else:
        checks.append({"name": "authentication", "ok": True, "detail": creds.email or "Authenticated"})


def _status_check_api(checks: list[dict[str, Any]], api_url: str) -> None:
    assert isinstance(checks, list), "checks must be a list"
    assert isinstance(api_url, str) and api_url, "api_url must be a non-empty string"

    import httpx
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(f"{api_url}/health")
        if resp.status_code == 200:
            checks.append({"name": "api_reachable", "ok": True, "detail": api_url})
        else:
            checks.append({"name": "api_reachable", "ok": False, "detail": f"HTTP {resp.status_code}"})
    except httpx.ConnectError:
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Connection failed ({api_url})"})
    except httpx.TimeoutException:
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Timeout ({api_url})"})
    except httpx.RequestError as e:
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Request failed: {e}"})


def _status_check_deps(checks: list[dict[str, Any]]) -> None:
    assert isinstance(checks, list), "checks must be a list"
    assert all(isinstance(c, dict) for c in checks), "all checks must be dicts"

    import platform as platform_module
    plat = platform_module.system().lower()
    deps_ok = True
    deps_detail = "OK"
    if plat == "linux":
        from .deps import DEPS_REGISTRY
        gpu_tools = ["ncu", "nsys", "rocprof", "rocprofv3"]
        any_gpu_tool = any(
            shutil.which(DEPS_REGISTRY[n].check_cmd) is not None
            for n in gpu_tools
            if n in DEPS_REGISTRY
        )
        if not any_gpu_tool:
            deps_ok = False
            deps_detail = "No GPU tools found (optional; run 'wafer settings deps check')"
    checks.append({"name": "deps", "ok": deps_ok, "detail": deps_detail})


def _status_print_text(checks: list[dict[str, Any]], all_ok: bool, check_sym: str, cross_sym: str) -> None:
    assert isinstance(checks, list) and checks, "checks must be a non-empty list"
    assert isinstance(all_ok, bool), "all_ok must be a bool"

    typer.echo("Wafer CLI Status")
    typer.echo("\u2500" * 30)
    for check in checks:
        symbol = check_sym if check["ok"] else cross_sym
        typer.echo(f"  {symbol} {check['name']}: {check['detail']}")
    if not all_ok:
        typer.echo("")
        typer.echo("Next steps:")
        for c in checks:
            if not c["ok"] and c["name"] == "authentication":
                typer.echo("  - Not logged in? Run: wafer login")
            elif not c["ok"] and c["name"] == "deps":
                typer.echo("  - Missing tools? Run: wafer settings deps check")
            elif not c["ok"] and c["name"] == "api_reachable":
                typer.echo("  - API unreachable. Check network or run: wafer login")


def status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check CLI health: version, config, auth, and API connectivity."""

    from .analytics import _get_cli_version
    from .auth import CHECK, CROSS, _token_expired, load_credentials
    from .global_config import CONFIG_DIR, get_api_url

    checks: list[dict] = []
    version = _get_cli_version()
    checks.append({"name": "cli_version", "ok": True, "detail": version})
    _status_check_config(checks, CONFIG_DIR)
    _status_check_auth(checks, load_credentials, _token_expired)
    _status_check_api(checks, get_api_url())
    _status_check_deps(checks)
    all_ok = all(c["ok"] for c in checks)
    if json_output:
        from .output import json_response
        data = {"cli_version": version, "all_ok": all_ok, "checks": checks}
        typer.echo(json_response(data=data, status="ok" if all_ok else "error"))
    else:
        _status_print_text(checks, all_ok, CHECK, CROSS)
    if all_ok:
        _mark_command_success()
    else:
        raise typer.Exit(1)


# ============================================================================
# Guide command
# ============================================================================


_GUIDE_SECTION_MAP = {
    "quickstart": "Quick Start", "quick": "Quick Start", "cloud": "Quick Start",
    "run": "Running Code on a GPU", "running": "Running Code on a GPU",
    "targets": "Managing Targets", "target": "Managing Targets", "manage": "Managing Targets",
    "docs": "Documentation Lookup", "documentation": "Documentation Lookup",
    "trace": "Trace Analysis", "analyze": "Trace Analysis", "analysis": "Trace Analysis",
    "evaluate": "Kernel Evaluation", "eval": "Kernel Evaluation",
    "optimize": "Kernel Optimization (AI-assisted)", "optimization": "Kernel Optimization (AI-assisted)",
    "commands": "Command Reference", "reference": "Command Reference", "ref": "Command Reference",
}


def _render_guide_markdown(content: str) -> None:
    assert isinstance(content, str) and content, "content must be a non-empty string"
    assert "#" in content, "content must contain markdown headers"

    from rich.console import Console
    from rich.markdown import Markdown
    Console().print(Markdown(content))


def _render_guide_section(content: str, section: str) -> None:
    assert isinstance(content, str) and content, "content must be a non-empty string"
    assert isinstance(section, str) and section, "section must be a non-empty string"

    from rich.console import Console
    from rich.markdown import Markdown
    section_lower = section.lower()
    if section_lower not in _GUIDE_SECTION_MAP:
        typer.echo(f"Error: Unknown section '{section}'", err=True)
        typer.echo("\nAvailable sections:", err=True)
        typer.echo("  quickstart, run, targets, docs, trace, evaluate, optimize, commands", err=True)
        raise typer.Exit(1)
    header = _GUIDE_SECTION_MAP[section_lower]
    section_content = _extract_section(content, header)
    if not section_content:
        typer.echo(f"Error: Section '{header}' not found in guide", err=True)
        raise typer.Exit(1)
    Console().print(Markdown(section_content))


def guide(
    section: str | None = typer.Argument(
        None,
        help="Show specific section: quickstart, run, targets, docs, trace, evaluate, optimize, commands",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        "-f",
        help="Show full guide with rich formatting",
    ),
) -> None:
    """Show the Wafer CLI usage guide.

    Examples:
        wafer guide quickstart
        wafer guide --full
    """
    guide_path = Path(__file__).parent / "GUIDE.md"
    if not guide_path.exists():
        typer.echo("Error: GUIDE.md not found", err=True)
        raise typer.Exit(1)
    content = guide_path.read_text()
    if full:
        _render_guide_markdown(content)
        return
    if section:
        _render_guide_section(content, section)
        return
    _show_guide_toc(content)


def _extract_section(content: str, header: str) -> str:
    """Extract a specific section from the guide markdown.
    Args:
        content: Full guide markdown content
        header: Section header to extract (e.g., "Quick Start")
    Returns:
        Section content including the header, up to the next ## header
    """
    lines = content.split("\n")
    section_lines = []
    in_section = False
    header_pattern = f"## {header}"
    for line in lines:
        if line.startswith(header_pattern):
            in_section = True
            section_lines.append(line)
        elif in_section:
            if line.startswith("## "):
                break
            section_lines.append(line)
    return "\n".join(section_lines).strip()


def _show_guide_toc(content: str) -> None:
    """Show table of contents for the guide.
    Args:
        content: Full guide markdown content
    """
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    lines = content.split("\n")
    title = ""
    sections = []
    for line in lines:
        if line.startswith("# "):
            title = line[2:].strip()
        elif line.startswith("## "):
            sections.append(line[3:].strip())
    console = Console()
    title_text = Text(title, style="bold cyan")
    console.print()
    console.print(title_text)
    console.print()
    console.print("Available sections:", style="bold")
    console.print()
    section_aliases = [
        ("quickstart", "Quick Start"),
        ("run", "Running Code on a GPU"),
        ("targets", "Managing Targets"),
        ("docs", "Documentation Lookup"),
        ("trace", "Trace Analysis"),
        ("evaluate", "Kernel Evaluation"),
        ("optimize", "Kernel Optimization (AI-assisted)"),
        ("commands", "Command Reference"),
    ]
    for alias, section_name in section_aliases:
        console.print(f"  [cyan]wafer guide {alias:12}[/cyan]  {section_name}")
    console.print()
    hint = Panel(
        "[dim]Use [cyan]wafer guide <section>[/cyan] to see specific content\n"
        "Use [cyan]wafer guide --full[/cyan] to see the entire guide with formatting[/dim]",
        border_style="dim",
    )
    console.print(hint)


# ============================================================================
# Billing commands
# ============================================================================


@billing_app.callback(invoke_without_command=True)
def billing_usage(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current billing usage and subscription info.
    Example:
        wafer billing
        wafer billing --json
    """
    if ctx.invoked_subcommand is not None:
        return
    from .billing import get_usage
    try:
        result = get_usage(json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@billing_app.command("topup")
def billing_topup(
    amount: int = typer.Argument(25, help="Amount in dollars ($10-$500)"),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Print URL instead of opening browser"
    ),
) -> None:
    """Add credits to your account."""
    import webbrowser

    from .billing import create_topup, validate_topup_amount
    amount_cents = amount * 100
    try:
        validate_topup_amount(amount_cents)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    try:
        result = create_topup(amount_cents)
        checkout_url = result.get("checkout_url")
        if not checkout_url:
            typer.echo("Error: No checkout URL received from API", err=True)
            raise typer.Exit(1) from None
        if no_browser:
            typer.echo(f"Complete your purchase at:\n{checkout_url}")
        else:
            typer.echo(f"Opening checkout for ${amount}...")
            webbrowser.open(checkout_url)
            typer.echo("Browser opened. Complete your purchase there.")
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@billing_app.command("portal")
def billing_portal(
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Print URL instead of opening browser"
    ),
) -> None:
    """Open Stripe billing portal."""
    import webbrowser

    from .billing import get_portal_url
    try:
        result = get_portal_url()
        portal_url = result.get("portal_url")
        if not portal_url:
            typer.echo("Error: No portal URL received from API", err=True)
            raise typer.Exit(1) from None
        if no_browser:
            typer.echo(f"Billing portal:\n{portal_url}")
        else:
            typer.echo("Opening billing portal...")
            webbrowser.open(portal_url)
            typer.echo("Browser opened.")
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ============================================================================
# SSH keys commands
# ============================================================================


@ssh_keys_app.command("list")
def ssh_keys_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List all registered SSH public keys."""
    from .ssh_keys import list_ssh_keys
    try:
        result = list_ssh_keys(json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@ssh_keys_app.command("add")
def ssh_keys_add(
    pubkey_path: Path | None = typer.Argument(
        None, help="Path to public key file (auto-detects ~/.ssh/id_ed25519.pub if not specified)"
    ),
    name: str | None = typer.Option(None, "--name", "-n", help="Friendly name for the key"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Add an SSH public key."""
    from .ssh_keys import add_ssh_key
    try:
        result = add_ssh_key(pubkey_path=pubkey_path, name=name, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@ssh_keys_app.command("remove")
def ssh_keys_remove(
    key_id: str = typer.Argument(..., help="UUID of the SSH key to remove"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Remove an SSH public key."""
    from .ssh_keys import remove_ssh_key
    try:
        result = remove_ssh_key(key_id=key_id, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


# ============================================================================
# Agent key commands (Wafer-generated keys for cloud agents)
# ============================================================================


@ssh_keys_app.command("agent-list")
def ssh_keys_agent_list() -> None:
    """List Wafer-generated SSH keys (used by cloud agents)."""
    from .user_targets_api import list_wafer_keys
    keys = list_wafer_keys()
    if not keys:
        typer.echo("  No agent keys. Create one: wafer settings ssh-keys agent-create <name>")
        return
    typer.echo("  Wafer-managed agent keys:\n")
    for k in keys:
        typer.echo(f"    {k.get('name', ''):<20} {k.get('fingerprint', '')}")


@ssh_keys_app.command("agent-create")
def ssh_keys_agent_create(
    name: str = typer.Argument(..., help="Key name"),
) -> None:
    """Generate a Wafer SSH keypair for cloud agents. Private key returned once."""
    from .user_targets_api import generate_wafer_key
    key = generate_wafer_key(name)
    keys_dir = Path.home() / ".wafer" / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    key_path = keys_dir / name
    if key.get("private_key"):
        key_path.write_text(key["private_key"])
        key_path.chmod(0o600)
        typer.echo(f"  Wafer key saved to: {key_path}")
    typer.echo(f"  Public key: {key.get('public_key', '')}")
    typer.echo(f"  Fingerprint: {key.get('fingerprint', '')}")


@ssh_keys_app.command("agent-delete")
def ssh_keys_agent_delete(
    key_id: str = typer.Argument(..., help="Key ID or name"),
) -> None:
    """Delete a Wafer-generated agent key."""
    from .user_targets_api import delete_wafer_key, list_wafer_keys
    keys = list_wafer_keys()
    key_id_resolved = key_id
    for k in keys:
        if k.get("id") == key_id or k.get("name") == key_id:
            key_id_resolved = k["id"]
            break
    delete_wafer_key(key_id_resolved)
    typer.echo(f"  Deleted key: {key_id}")


# ============================================================================
# GitHub commands
# ============================================================================


@github_app.command("connect")
def github_connect() -> None:
    """Open browser to install the Wafer GitHub App."""
    import webbrowser

    api_base, headers = _cloud_auth_headers()
    import httpx

    resp = httpx.get(f"{api_base}/v1/github/install-url", headers=headers, timeout=30.0)
    if resp.status_code != 200:
        typer.echo(f"Error: Failed to get install URL: {resp.status_code} {resp.text}", err=True)
        raise typer.Exit(1)
    data = resp.json()
    install_url = data.get("install_url")
    if not install_url:
        typer.echo("Error: No install_url in response", err=True)
        raise typer.Exit(1)
    typer.echo("Opening GitHub App install page in browser...")
    webbrowser.open(install_url)
    typer.echo("After installing, run 'wafer settings github list' to see your repos.")


@github_app.command("list")
def github_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List repos accessible via your GitHub App installations."""
    api_base, headers = _cloud_auth_headers()
    import httpx

    resp = httpx.get(f"{api_base}/v1/github/repos", headers=headers, timeout=30.0)
    if resp.status_code != 200:
        typer.echo(f"Error: Failed to list repos: {resp.status_code} {resp.text}", err=True)
        raise typer.Exit(1)
    data = resp.json()
    repos = data.get("repos", [])
    if json_output:
        typer.echo(json.dumps({"repos": repos}, indent=2))
        return
    if not repos:
        typer.echo("No repos found. Run 'wafer settings github connect' to install the GitHub App.")
        return
    for r in repos:
        typer.echo(f"  {r.get('full_name', r.get('name', '?'))}")
