"""Sandbox CLI: create, manage, and run commands in tmux sandboxes on remote GPU machines."""
from __future__ import annotations

import os
import shlex
from pathlib import Path
from typing import TYPE_CHECKING

import typer

if TYPE_CHECKING:
    from wafer.core.sandbox.session import SandboxSession
    from wafer.core.sandbox.types import Sandbox

sandbox_app = typer.Typer(
    name="sandbox",
    help="Create, manage, and run commands in tmux sandboxes on SSH targets (wafer target init ssh).",
    no_args_is_help=True,
)


def _get_ssh_creds(target_name: str) -> tuple[str, str]:
    """Load target and return (ssh_target, ssh_key)."""
    from wafer.cli.targets import load_target

    target = load_target(target_name)
    assert target.ssh_target, f"Target '{target_name}' has no SSH credentials"
    return target.ssh_target, target.ssh_key


def _resolve_ssh_target(target: str | None) -> tuple[str, str, str]:
    """Resolve target to SSH credentials. Errors if workspace (sandbox is SSH-only).
    Returns (target_name, ssh_target, ssh_key).
    """
    from wafer.cli.target_resolve import resolve_target

    target_name, kind = resolve_target(name=target)
    if kind == "workspace":
        typer.echo(
            f"Error: Sandbox only supports SSH targets. '{target_name}' is a workspace.\n"
            "  For workspaces: wafer target sync, wafer target ssh (interactive)\n"
            "  For sandbox:    wafer target init ssh --name <name> --host user@host:22",
            err=True,
        )
        raise typer.Exit(1) from None
    ssh_target, ssh_key = _get_ssh_creds(target_name)
    return target_name, ssh_target, ssh_key


def _run_async(async_fn):
    """Run an async function (not a coroutine) via trio with trio_asyncio bridge."""
    import trio
    import trio_asyncio

    async def _wrapper():
        async with trio_asyncio.open_loop():
            return await async_fn()

    return trio.run(_wrapper)


def _age_str(metadata: dict | None) -> str:
    """Format sandbox age from metadata. Returns '-' if no metadata."""
    if not metadata:
        return "-"
    created_at = metadata.get("created_at")
    if not created_at:
        return "-"
    try:
        from datetime import datetime, timezone

        created = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        delta = datetime.now(timezone.utc) - created
        hours = delta.total_seconds() / 3600
        if hours < 1:
            return f"{int(delta.total_seconds() / 60)}m"
        if hours < 24:
            return f"{hours:.1f}h"
        return f"{hours / 24:.1f}d"
    except (ValueError, TypeError):
        return "-"


@sandbox_app.command("create")
def sandbox_create(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
    timeout: int = typer.Option(4, "--timeout-hours", help="Self-destruct timeout in hours"),
) -> None:
    """Create a new sandbox on an SSH target."""
    from wafer.core.sandbox import SandboxSession, create_sandbox

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None

    sandbox = create_sandbox(target_name, ssh_target, ssh_key, timeout)

    async def _create():
        session = SandboxSession(sandbox)
        await session.start()

    _run_async(_create)
    typer.echo(
        f"Sandbox {sandbox.id} created on {target_name}. "
        f"Attach: wafer sandbox attach {sandbox.id} --target {target_name}"
    )


@sandbox_app.command("list")
def sandbox_list(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show extra details (tmp dir path)"),
) -> None:
    """List sandboxes on SSH targets. With --target, list on that target only."""
    import json as json_mod

    from wafer.core.sandbox import list_sandboxes_with_metadata

    rows: list[tuple[str, str, dict | None]] = []

    if target:
        try:
            target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
        except typer.Exit:
            raise
        except RuntimeError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None

        async def _list():
            return await list_sandboxes_with_metadata(ssh_target, ssh_key)

        items = _run_async(_list)
        rows.extend((sid, target_name, meta) for sid, meta in items)
    else:
        from wafer.cli.targets import list_targets

        for tname in list_targets():
            try:
                _, ssh_target, ssh_key = _resolve_ssh_target(tname)

                async def _list_target(st=ssh_target, sk=ssh_key):
                    return await list_sandboxes_with_metadata(st, sk)

                items = _run_async(_list_target)
                rows.extend((sid, tname, meta) for sid, meta in items)
            except Exception:
                pass

    if json_output:
        items = [
            {"id": sid, "target": tname, "status": "active", "age": _age_str(meta), "tmp_dir": f"/tmp/.wafer_sandbox/{sid}"}
            if verbose
            else {"id": sid, "target": tname, "status": "active", "age": _age_str(meta)}
            for sid, tname, meta in rows
        ]
        typer.echo(json_mod.dumps({"sandboxes": items}))
        return

    if not rows:
        typer.echo("No sandboxes found.")
        return

    if verbose:
        typer.echo(f"{'ID':<40} {'TARGET':<22} {'STATUS':<8} {'AGE':<8} TMP_DIR")
        typer.echo(f"{'-'*40} {'-'*22} {'-'*8} {'-'*8} {'-'*40}")
        for sid, tname, meta in rows:
            typer.echo(f"{sid:<40} {tname:<22} {'active':<8} {_age_str(meta):<8} /tmp/.wafer_sandbox/{sid}")
    else:
        typer.echo(f"{'ID':<40} {'TARGET':<22} {'STATUS':<8} AGE")
        typer.echo(f"{'-'*40} {'-'*22} {'-'*8} {'-'*8}")
        for sid, tname, meta in rows:
            typer.echo(f"{sid:<40} {tname:<22} {'active':<8} {_age_str(meta)}")



@sandbox_app.command("attach")
def sandbox_attach(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID (e.g. sandbox-abc12345)"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
) -> None:
    """Attach to a sandbox tmux session (interactive)."""
    from wafer.core.ssh_utils import parse_ssh_target

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("Set default: wafer target default <name>", err=True)
        raise typer.Exit(1) from None
    parsed = parse_ssh_target(ssh_target)
    key_path = str(Path(ssh_key).expanduser().resolve())
    tmux_session = sandbox_id if sandbox_id.startswith("wafer-") else f"wafer-{sandbox_id}"
    os.execvp(
        "ssh",
        [
            "ssh",
            "-t",
            "-p",
            str(parsed.port),
            "-i",
            key_path,
            "-o",
            "StrictHostKeyChecking=no",
            "-o",
            "UserKnownHostsFile=/dev/null",
            f"{parsed.user}@{parsed.host}",
            f"tmux attach -t {tmux_session}",
        ],
    )


@sandbox_app.command("delete")
def sandbox_delete(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or 'all'"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
) -> None:
    """Delete a sandbox (or all with sandbox_id=all)."""
    from wafer.core.sandbox import destroy_all_sandboxes, destroy_sandbox, list_sandboxes

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("Set default: wafer target default <name>", err=True)
        raise typer.Exit(1) from None
    if sandbox_id.lower() == "all":

        async def _destroy_all():
            return await destroy_all_sandboxes(ssh_target, ssh_key)

        count = _run_async(_destroy_all)
        typer.echo(f"Destroyed {count} sandbox(es)")
    else:
        tmux_session = sandbox_id if sandbox_id.startswith("wafer-") else f"wafer-{sandbox_id}"

        async def _check_and_destroy():
            sessions = await list_sandboxes(ssh_target, ssh_key)
            if tmux_session not in sessions:
                return False
            await destroy_sandbox(ssh_target, ssh_key, tmux_session)
            return True

        existed = _run_async(_check_and_destroy)
        if existed:
            typer.echo(f"Destroyed {sandbox_id}")
        else:
            typer.echo(f"Sandbox {sandbox_id} not found (may already be destroyed)")


@sandbox_app.command("gc")
def sandbox_gc(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
    max_age_hours: int = typer.Option(4, "--max-age", help="Destroy sandboxes older than this many hours"),
) -> None:
    """Garbage-collect stale sandboxes. Destroys those exceeding max-age. No metadata = stale."""
    from datetime import datetime, timezone

    from wafer.core.sandbox import destroy_sandbox, list_sandboxes_with_metadata

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None

    async def _gc():
        items = await list_sandboxes_with_metadata(ssh_target, ssh_key)
        now = datetime.now(timezone.utc)
        destroyed = 0
        for session, metadata in items:
            if metadata is None:
                await destroy_sandbox(ssh_target, ssh_key, session)
                destroyed += 1
                continue
            created_at = metadata.get("created_at")
            if not created_at:
                await destroy_sandbox(ssh_target, ssh_key, session)
                destroyed += 1
                continue
            try:
                created = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                age_hours = (now - created).total_seconds() / 3600
                if age_hours > max_age_hours:
                    await destroy_sandbox(ssh_target, ssh_key, session)
                    destroyed += 1
            except (ValueError, TypeError):
                await destroy_sandbox(ssh_target, ssh_key, session)
                destroyed += 1
        return destroyed

    count = _run_async(_gc)
    typer.echo(f"Destroyed {count} stale sandbox(es)")


@sandbox_app.command("run")
def sandbox_run(
    command: list[str] = typer.Argument(..., help="Command to run"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
    sandbox_id: str | None = typer.Option(None, "--sandbox", "-s", help="Sandbox ID to run in (default: first available)"),
    sync_path: Path | None = typer.Option(None, "--sync", help="Path to sync before run"),
    cd_path: str | None = typer.Option(None, "--cd", help="Working directory for command (auto-set to /tmp/<folder> when --sync without --cd)"),
    timeout: int = typer.Option(300, "--timeout-sec", help="Command timeout in seconds (default: 300)"),
) -> None:
    """Run a command in a sandbox on an SSH target. Creates one if none exists."""
    from wafer.cli.targets import load_target
    from wafer.cli.targets_ops import get_target_ssh_info, sync_to_target
    from wafer.core.sandbox import SandboxSession, create_sandbox, destroy_sandbox, list_sandboxes
    from wafer.core.sandbox.manager import DEFAULT_TIMEOUT_HOURS, MAX_SANDBOXES
    from wafer.core.sandbox.types import Sandbox

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None

    work_dir: str | None = cd_path
    if sync_path and sync_path.exists():
        t = load_target(target_name)

        async def _get_info():
            return await get_target_ssh_info(t)

        ssh_info = _run_async(_get_info)
        if work_dir is None:
            work_dir = f"/tmp/{sync_path.name}"
        sync_to_target(ssh_info, sync_path.resolve(), remote_path=work_dir)
        typer.echo(f"Synced to {ssh_info.host}:{work_dir}", err=True)

    cmd_str = shlex.join(command) if len(command) > 1 else (command[0] if command else "")
    if work_dir:
        cmd_str = f"cd {shlex.quote(work_dir)} && {cmd_str}"

    async def _run_in_sandbox():
        sessions = await list_sandboxes(ssh_target, ssh_key)
        if len(sessions) > MAX_SANDBOXES:
            for excess in sessions[MAX_SANDBOXES:]:
                await destroy_sandbox(ssh_target, ssh_key, excess)
            sessions = sessions[:MAX_SANDBOXES]
        if sandbox_id:
            tmux_session = sandbox_id if sandbox_id.startswith("wafer-") else f"wafer-{sandbox_id}"
            if tmux_session not in sessions:
                typer.echo(f"Error: Sandbox {sandbox_id} not found on {target_name}", err=True)
                typer.echo("  List sandboxes: wafer sandbox list --target " + target_name, err=True)
                raise typer.Exit(1)
        elif sessions:
            tmux_session = sessions[0]
        else:
            tmux_session = None

        if tmux_session:
            suffix = tmux_session.replace("wafer-sandbox-", "")
            sandbox = Sandbox(
                id=f"sandbox-{suffix}",
                target_name=target_name,
                tmux_session=tmux_session,
                ssh_target=ssh_target,
                ssh_key=ssh_key,
                created_at="",
                timeout_hours=DEFAULT_TIMEOUT_HOURS,
            )
            sb = SandboxSession(sandbox)
            await sb.connect()
        else:
            sandbox = create_sandbox(target_name, ssh_target, ssh_key)
            sb = SandboxSession(sandbox)
            await sb.start()

        try:
            output, exit_code = await sb.run_command(cmd_str, timeout)
        finally:
            if sb._client is not None:
                await sb._client.close()

        typer.echo(output)
        return exit_code

    exit_code = _run_async(_run_in_sandbox)
    raise typer.Exit(exit_code if exit_code >= 0 else 1)
