# Kernel Evaluation

Test correctness and measure speedup against a reference using the unified eval primitive:

```bash
# List available evaluation tasks
wafer tool eval --list-tasks

# Run evaluation for a specific task
wafer tool eval --task gpumode
wafer tool eval --task kernelbench

# Run evaluation on an SSH target (compose with sandbox run)
wafer sandbox run --target my-gpu -- wafer tool eval --task gpumode

# Sync files and run (cd into /tmp/<dirname>/ where synced files land)
wafer sandbox run --target my-gpu --sync ./my-kernel -- bash -c "cd /tmp/my-kernel && wafer tool eval --task kernelbench"
```

## SSH Target + Evaluate Integration

Run eval on an SSH target by composing `wafer sandbox run --target` with `wafer tool eval`:

```bash
# Step 1: Register SSH target
wafer target init ssh --name my-gpu --host user@host:22

# Step 2: Run eval on the SSH target
wafer sandbox run --target my-gpu -- wafer tool eval --task gpumode

# Or sync files first and run
wafer target sync my-gpu ./my-kernel
wafer sandbox run --target my-gpu --sync ./my-kernel -- bash -c "cd /tmp/my-kernel && wafer tool eval --task kernelbench"
```

**Alternative:** Use `wafer sandbox run --target` with a custom benchmark script:

```bash
wafer sandbox run --target my-gpu --sync ./my-kernel -- bash -c "cd /tmp/my-kernel && python run_benchmark.py"
```

## GPUMode Function Signatures

The GPUMode format requires these specific function names:
- `custom_kernel()` — your optimized kernel implementation
- `ref_kernel()` — reference implementation (in reference.py)
- `generate_input()` — input generator (in reference.py)

## Target Configuration

Targets define GPU access methods. Initialize with:

```bash
wafer target init ssh                # Your own GPU via SSH
wafer target init workspace          # Cloud GPU workspace
```

Then use: `wafer sandbox run --target <name> -- wafer tool eval --task gpumode` (SSH targets only; workspaces use `wafer target sync` + `wafer target ssh`)
