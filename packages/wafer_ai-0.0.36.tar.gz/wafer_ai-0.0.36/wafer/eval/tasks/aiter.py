"""Aiter operator eval task.

Evaluates aiter operator optimizations on AMD MI300X.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.eval import Task


class Aiter(Task):
    """Aiter: AMD operator optimization benchmark."""

    async def produce(self, args: list[str]) -> str:
        assert len(args) >= 2, "aiter requires directory path as first arg and command as remaining args"
        directory = Path(args[0])
        assert directory.is_dir(), f"Not a directory: {directory}"
        proc = await asyncio.create_subprocess_exec(
            *args[1:],
            cwd=str(directory),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return stdout.decode()

    def score(self, output: str, baseline: str | None = None) -> Score:
        after = json.loads(output)
        assert "correct" in after, f"Missing 'correct' in output: {after}"
        assert "passed_tests" in after, f"Missing 'passed_tests' in output: {after}"
        assert "total_tests" in after, f"Missing 'total_tests' in output: {after}"

        correct_val = 1.0 if after["correct"] else 0.0
        passed = int(after["passed_tests"])
        total = int(after["total_tests"])
        assert total > 0, "total_tests must be positive"
        pass_rate = passed / total

        composite = correct_val + (pass_rate if after["correct"] else 0.0)
        return Score(metrics=(
            Metric("correct", correct_val),
            Metric("passed_tests", float(passed)),
            Metric("total_tests", float(total)),
            Metric("pass_rate", pass_rate),
            Metric("score", composite, weight=1.0),
        ))
