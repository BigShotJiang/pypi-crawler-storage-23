"""KernelBench eval task.

Expects directory with impl.py (ModelNew) and ref.py (Model + get_inputs + get_init_inputs).
Runs the kernelbench bench script and parses JSON output.
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.eval import Task, extract_eval_result


class Kernelbench(Task):
    """KernelBench: CUDA kernel optimization benchmark."""

    async def produce(self, args: list[str]) -> str:
        assert len(args) >= 1, "kernelbench requires directory path as first arg"
        directory = Path(args[0])
        assert directory.is_dir(), f"Not a directory: {directory}"
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "wafer.eval.bench.kernelbench", "--benchmark",
            cwd=str(directory),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return extract_eval_result(stdout.decode())

    def score(self, output: str, baseline: str | None = None) -> Score:
        after = json.loads(output)
        assert "correct" in after, f"Missing 'correct' in output: {after}"
        assert "runtime_ms" in after, f"Missing 'runtime_ms' in output: {after}"

        correct = 1.0 if after.get("correct") else 0.0

        if baseline:
            before = json.loads(baseline)
            assert "runtime_ms" in before, f"Missing 'runtime_ms' in baseline: {before}"
            assert before["runtime_ms"] > 0, "Baseline runtime_ms must be positive"
            assert after["runtime_ms"] > 0, "After runtime_ms must be positive"
            speedup = before["runtime_ms"] / after["runtime_ms"]
        else:
            raw = after.get("speedup")
            assert raw is not None, f"Missing 'speedup' in output: {after}"
            speedup = float(raw)

        composite = correct + (speedup if correct > 0 else 0.0)
        return Score(metrics=(
            Metric("correct", correct),
            Metric("speedup", speedup),
            Metric("score", composite, weight=1.0),
        ))
