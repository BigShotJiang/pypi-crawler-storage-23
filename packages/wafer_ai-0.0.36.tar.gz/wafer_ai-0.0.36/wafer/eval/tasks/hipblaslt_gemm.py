"""hipBLASLt GEMM eval task.

Benchmark-style: evaluates GEMM kernel TFLOPS improvements.
Scores based on relative TFLOPS improvement over baseline.
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.eval import Task, extract_eval_result


class HipblasltGemm(Task):
    """HipblasltGemm: GEMM kernel optimization benchmark."""

    async def produce(self, args: list[str]) -> str:
        assert len(args) >= 1, "hipblaslt_gemm requires directory path as first arg"
        directory = Path(args[0])
        assert directory.is_dir(), f"Not a directory: {directory}"
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "wafer.eval.bench.hipblaslt", *args[1:],
            cwd=str(directory),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return extract_eval_result(stdout.decode())

    def score(self, output: str, baseline: str | None = None) -> Score:
        after = json.loads(output)
        assert "correct" in after, f"Missing 'correct' in output: {after}"
        assert "tflops" in after, f"Missing 'tflops' in output: {after}"
        correct_val = 1.0 if after["correct"] else 0.0
        tflops = float(after["tflops"])

        if baseline:
            before = json.loads(baseline)
            assert "tflops" in before, f"Missing 'tflops' in baseline: {before}"
            before_tflops = float(before["tflops"])
            assert before_tflops > 0, "Baseline tflops must be positive"
            speedup = tflops / before_tflops
            improvement = max(0.0, speedup - 1.0) * 10
        else:
            speedup = tflops
            improvement = tflops

        composite = improvement if after["correct"] else 0.0
        return Score(metrics=(
            Metric("correct", correct_val),
            Metric("tflops", tflops),
            Metric("speedup", speedup),
            Metric("score", composite, weight=1.0),
        ))
