"""Unified eval primitive: flat Task class + discovery.

Public API for eval authors:
    Task        Base class with produce() + score()
    Score       Return type from score()
    Metric      Individual metric inside a Score
    load_tasks  Load task data from JSON file or list
    extract_eval_result  Parse EVAL_RESULT_JSON: prefix from stdout
"""
from __future__ import annotations

import importlib
import importlib.util
import os
from typing import Any

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.core.rollouts.eval_helpers import load_tasks
from wafer.eval.sandbox_runner import sandbox_run

__all__ = [
    "Task",
    "Score",
    "Metric",
    "extract_eval_result",
    "load_tasks",
    "load_task",
    "list_tasks",
    "sandbox_run",
]


EVAL_RESULT_PREFIX = "EVAL_RESULT_JSON:"


def extract_eval_result(stdout: str) -> str:
    """Extract JSON from bench script stdout that uses EVAL_RESULT_JSON: prefix."""
    for line in stdout.splitlines():
        if line.startswith(EVAL_RESULT_PREFIX):
            return line[len(EVAL_RESULT_PREFIX):]
    assert False, f"No {EVAL_RESULT_PREFIX} line found in output:\n{stdout[-500:]}"


class Task:
    """Base class for all eval tasks. Two methods: produce + score.

    Each task implements its own arg parsing in produce().
    score() returns a Score with Metrics: individual components at weight=0
    (tracking) and a composite "score" Metric at weight=1.0 (the reward).
    """

    async def produce(self, args: list[str], *, on_chunk: Any = None) -> str:
        """Produce raw output from args. Each task defines its own arg format.
        When on_chunk is provided, call it with each text chunk for streaming.
        """
        raise NotImplementedError

    def score(self, output: str, baseline: str | None = None) -> Score:
        """Score the raw output. Returns Score with metrics."""
        raise NotImplementedError


_BUILTIN_TASKS: dict[str, str] = {
    "kernelbench": "wafer.eval.tasks.kernelbench",
    "gpumode": "wafer.eval.tasks.gpumode",
    "aiter": "wafer.eval.tasks.aiter",
    "hipblaslt-gemm": "wafer.eval.tasks.hipblaslt_gemm",
}


def load_task(name: str, *, resolve_from_dir: str | os.PathLike | None = None) -> Task:
    """Load a task by built-in name or file path.

    When name is a .py path (e.g. ./task.py), resolve it relative to resolve_from_dir
    if the path does not exist in the current working directory.
    """
    if name in _BUILTIN_TASKS:
        module = importlib.import_module(_BUILTIN_TASKS[name])
    elif name.endswith(".py"):
        from pathlib import Path
        if resolve_from_dir is not None:
            path = (Path(resolve_from_dir) / name).resolve()
        else:
            path = Path(name).expanduser().resolve()
        assert path.is_file(), (
            f"Task file not found: {name!r} (resolved: {path}). "
            f"Ensure the task .py file exists in the --after directory."
        )
        spec = importlib.util.spec_from_file_location("user_task", str(path))
        assert spec is not None, f"Failed to load spec from {path}"
        assert spec.loader is not None, f"No loader for {path}"
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    else:
        assert False, f"Unknown task: {name!r}. Built-in: {list(_BUILTIN_TASKS)}. Or pass a .py file path."

    task_cls = None
    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if isinstance(attr, type) and issubclass(attr, Task) and attr is not Task:
            task_cls = attr
            break
    assert task_cls is not None, f"No Task subclass found in {name}"
    return task_cls()


def list_tasks() -> list[str]:
    """List all built-in task names."""
    return sorted(_BUILTIN_TASKS.keys())
