import traceback
from abc import ABC
from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.params import Header, Depends
from langchain_core.messages import BaseMessage, HumanMessage
from langgraph.graph import MessagesState
from langgraph.graph.state import CompiledStateGraph
from openkosmos_core.auth import AuthTokenConfig, AuthToken
from starlette.responses import StreamingResponse

from openkosmos_ai.api.model import ChatCompletionResponse, FinishReason, \
    ModelInfoList, ModelInfo, ChatCompletionRequest
from openkosmos_ai.common.model import AIBaseConfig
from openkosmos_ai.common.util import create_run_config


class GraphProcessorConfig(AIBaseConfig, ABC):
    tags: Optional[list[str]] = ["default"]
    auth: Optional[AuthTokenConfig] = None


class GraphStreamProcessor:

    def on_task_start(self, node_name: str, input: dict):
        return f"### {node_name} 开始: \n"

    def on_task_stop(self, node_name: str, result: dict):
        return f"### {node_name} 结束\n"

    def on_message(self, node_name: str, meta_info: dict, message: BaseMessage):
        return message.content

    def on_create_agent_state(self, request: ChatCompletionRequest):
        return MessagesState(messages=[HumanMessage(request.messages[0].content)])


class AppInfo:

    def __init__(self, app: CompiledStateGraph,
                 stream_processor: GraphStreamProcessor = GraphStreamProcessor()):
        self.app = app
        self.stream_processor = stream_processor

    def name(self):
        return self.app.name


class GraphProcessor:

    def __init__(self, config: GraphProcessorConfig = GraphProcessorConfig()):
        self._config = config
        self.app_map: dict[str, AppInfo] = {}
        self.model_info_list = ModelInfoList()
        if config.auth is not None:
            self._auth_token = AuthToken(config.auth)

    def config(self) -> GraphProcessorConfig:
        return self._config

    def add_app(self, app: AppInfo):
        self.app_map[app.name()] = app
        return self

    def agent_model_name(self):
        return self.model_info_list.model_dump()

    def get_model_list(self):
        return ModelInfoList(data=[ModelInfo(id=a.name()) for a in self.app_map.values()]).model_dump()

    def create_response(self, request: ChatCompletionRequest, config=None, context=None):
        current_app_info = self.app_map.get(request.model)
        run_config = self.create_app_config(current_app_info, request) if config is None else config
        run_context = self.create_app_context(current_app_info, request) if context is None else context

        if request.stream:
            return StreamingResponse(
                self.stream_generator(current_app_info, request, run_config, run_context),
                media_type="text/event-stream")
        else:
            response = current_app_info.app.invoke(
                current_app_info.stream_processor.on_create_agent_state(request),
                context=run_context, config=run_config)

            return ChatCompletionResponse(model=current_app_info.name()).default_content(
                response["messages"][1].content).default_finish_reason(FinishReason.STOP).model_dump()

    def create_app_config(self, app_info: AppInfo, request: ChatCompletionRequest):
        return create_run_config(app_info.name())

    def create_app_context(self, app_info: AppInfo, request: ChatCompletionRequest):
        return None

    async def stream_generator(self, app_info: AppInfo, request: ChatCompletionRequest, config, context):
        try:
            flow_result = app_info.app.astream(
                app_info.stream_processor.on_create_agent_state(request),
                config=config,
                context=context,
                stream_mode=["messages", "tasks"])

            response_data = ChatCompletionResponse(model=app_info.name())

            yield response_data.get_message()

            async for mode, payload in flow_result:
                # print("\n---------------------------\n")
                # print(":", mode, payload)
                match mode:
                    case "tasks":
                        if payload.get("input") is None:
                            content = app_info.stream_processor.on_task_stop(
                                payload["name"], payload["result"])
                        else:
                            content = app_info.stream_processor.on_task_start(
                                payload["name"], payload["input"])
                        yield response_data.get_message(phase=payload["name"], content=content)
                    case "messages":
                        message: BaseMessage = payload[0]
                        meta_info = payload[1]
                        # print("::", message, meta_info)
                        for content_blocks in message.content_blocks:
                            # print(":::", content_blocks)
                            match content_blocks["type"]:
                                case "text":
                                    yield response_data.get_message(
                                        content=app_info.stream_processor.on_message(
                                            meta_info["langgraph_node"], meta_info=meta_info,
                                            message=message))

            yield response_data.get_message(finish_reason=FinishReason.STOP, with_done=True)

        except Exception as e:
            traceback.print_exc()
            yield f"data: {str(e)} \n\n"

    async def _validate_auth_token(self, header_token: str = Header(default=None, alias="Authorization")):
        if self.config().auth is None:
            return None
        try:
            return self._auth_token.retrieve(header_token[6:])
        except:
            raise HTTPException(status_code=401, detail="invalid token")

    def create_api_router(self, tags: list[str] = None):
        _router = APIRouter(tags=self.config().tags if tags is None else tags)

        @_router.post("/chat/completions")
        async def _chat_completions(request: ChatCompletionRequest,
                                    token_payload=Depends(self._validate_auth_token)):
            return self.create_response(request)

        @_router.get("/models")
        async def _models(token_payload=Depends(self._validate_auth_token)):
            return self.get_model_list()

        @_router.post("/responses")
        async def _responses(request, token_payload=Depends(self._validate_auth_token)):
            pass

        return _router
