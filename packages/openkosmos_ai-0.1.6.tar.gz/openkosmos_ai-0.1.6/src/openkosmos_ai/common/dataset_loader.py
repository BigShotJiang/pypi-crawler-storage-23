import langfuse
from langfuse.api import DatasetItem


class DatasetLoader:
    pass


if __name__ == '__main__':
    langfuse_client = langfuse.get_client()
    item = DatasetItem()
    item.input
