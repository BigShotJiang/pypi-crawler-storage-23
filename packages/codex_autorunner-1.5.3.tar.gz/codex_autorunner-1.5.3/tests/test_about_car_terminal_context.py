from pathlib import Path

from codex_autorunner.core.about_car import (
    ABOUT_CAR_GENERATED_MARKER,
    ABOUT_CAR_REL_PATH,
    DESTINATION_QUICKSTART_GENERATED_MARKER,
    DESTINATION_QUICKSTART_REL_PATH,
)
from codex_autorunner.core.runtime import RuntimeContext
from codex_autorunner.surfaces.web.routes.shared import build_codex_terminal_cmd


def test_about_car_is_seeded(repo: Path):
    about_path = repo / ABOUT_CAR_REL_PATH
    assert about_path.exists()
    text = about_path.read_text(encoding="utf-8")
    assert ABOUT_CAR_GENERATED_MARKER in text
    assert "ABOUT_CAR" in text
    assert ".codex-autorunner/contextspace/active_context.md" in text
    assert ".codex-autorunner/contextspace/decisions.md" in text
    assert ".codex-autorunner/contextspace/spec.md" in text
    assert "lint ticket frontmatter" in text.lower()
    assert ".codex-autorunner/DESTINATION_QUICKSTART.md" in text

    destination_quickstart_path = repo / DESTINATION_QUICKSTART_REL_PATH
    assert destination_quickstart_path.exists()
    destination_quickstart = destination_quickstart_path.read_text(encoding="utf-8")
    assert DESTINATION_QUICKSTART_GENERATED_MARKER in destination_quickstart
    assert "car hub destination set <repo_id> docker --image" in destination_quickstart
    assert "car hub destination set --help" in destination_quickstart


def test_terminal_new_cmd_does_not_seed_about_prompt(repo: Path):
    engine = RuntimeContext(repo)
    about_text = (repo / ABOUT_CAR_REL_PATH).read_text(encoding="utf-8")
    cmd = build_codex_terminal_cmd(engine, resume_mode=False)
    assert "--input" not in cmd
    assert about_text not in cmd


def test_terminal_resume_cmd_does_not_seed_about_prompt(repo: Path):
    engine = RuntimeContext(repo)
    about_text = (repo / ABOUT_CAR_REL_PATH).read_text(encoding="utf-8")
    cmd = build_codex_terminal_cmd(engine, resume_mode=True)
    assert "resume" in cmd
    assert about_text not in cmd
