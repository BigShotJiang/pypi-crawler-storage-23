from __future__ import annotations
from contextlib import nullcontext
from pathlib import Path

import click
from ema_pytorch import EMA

import torch
import torch.nn.functional as F
from torch import nn, cat, stack, tensor, einsum, Tensor
from torch.nn import Module, ModuleList

from einops import rearrange, repeat, pack, unpack, reduce
from einops.layers.torch import Rearrange, Reduce

from einx import subtract, divide

import numpy as np
from PIL import Image
from torchvision import transforms as T

from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from accelerate import Accelerator

from torch_einops_utils.save_load import save_load
from torch_einops_utils import pack_with_inverse
from memmap_replay_buffer import ReplayBuffer

from hl_gauss_pytorch import HLGaussLoss

# helpers

def exists(v):
    return v is not None

def default(v, d):
    return v if exists(v) else d

def pair(t):
    return t if isinstance(t, tuple) else (t, t)

def cycle(dl):
    while True:
        for data in dl:
            yield data

# loss module registry

LOSS_MODULES = dict()

def register_loss_module(name, loss_module_class):
    assert name not in {'mse', 'hlgauss', 'categorical'}, f'"{name}" is a reserved loss module name'
    assert name not in LOSS_MODULES, f'loss module "{name}" already registered'
    
    LOSS_MODULES[name] = loss_module_class

# loss modules

class MSELossModule(Module):
    def __init__(self, dim):
        super().__init__()
        self.to_value = nn.Sequential(
            nn.Linear(dim, 1),
            Rearrange('b 1 -> b')
        )

    def forward(self, x, target = None, reduction = 'mean'):
        pred = self.to_value(x)

        if not exists(target):
            return pred

        return F.mse_loss(pred, target, reduction = reduction)

    def value_to_prob(self, value):
        return value

    def decode(self, prob):
        return prob

class HLGaussLossModule(Module):
    def __init__(
        self,
        dim,
        num_bins = 51,
        min_value = 0.,
        max_value = 1.,
        sigma = None
    ):
        super().__init__()
        self.to_logits = nn.Linear(dim, num_bins)
        self.loss_fn = HLGaussLoss(
            min_value = min_value,
            max_value = max_value,
            num_bins = num_bins,
            sigma = sigma
        )

    def forward(self, x, target = None, reduction = 'mean'):
        logits = self.to_logits(x)

        if not exists(target):
            return self.loss_fn(logits)

        return self.loss_fn(logits, target, reduction = reduction)

    def value_to_prob(self, value):
        return self.loss_fn.transform_to_probs(value)

    def decode(self, prob):
        return self.loss_fn.transform_from_probs(prob)

class CategoricalLossModule(Module):
    def __init__(
        self,
        dim,
        num_bins = 201,
        min_value = 0.,
        max_value = 1.,
        encoding = 'two_hot', # 'two_hot' or 'gaussian'
        temperature = 0.1,    # Only used if encoding == 'gaussian'
        use_symexp = False
    ):
        super().__init__()
        assert encoding in {'two_hot', 'gaussian'}, "encoding must be 'two_hot' or 'gaussian'"

        self.num_bins = num_bins
        self.min_value = min_value
        self.max_value = max_value
        self.encoding = encoding
        self.temperature = temperature
        self.use_symexp = use_symexp

        self.to_logits = nn.Linear(dim, num_bins)

        bins = torch.linspace(min_value, max_value, num_bins)
        self.register_buffer('bins', bins, persistent = False)

    def sym_log(self, x):
        return torch.sign(x) * torch.log(torch.abs(x) + 1.0)

    def sym_exp(self, x):
        return torch.sign(x) * (torch.exp(torch.abs(x)) - 1.0)

    def value_to_prob(self, value):
        if self.use_symexp:
            value = self.sym_log(value)

        if self.encoding == 'gaussian':
            dist = subtract('n, ... -> ... n', self.bins, value).abs()
            return (dist / -self.temperature).softmax(dim = -1)

        elif self.encoding == 'two_hot':
            value = value.clamp(self.min_value, self.max_value)

            bin_range = self.max_value - self.min_value
            normalized_value = (value - self.min_value) / bin_range
            continuous_idx = normalized_value * (self.num_bins - 1)

            lower_idx = continuous_idx.floor().long()
            upper_idx = continuous_idx.ceil().long()

            upper_weight = continuous_idx - lower_idx
            lower_weight = 1.0 - upper_weight

            target_prob = torch.zeros(*value.shape, self.num_bins, device = value.device, dtype = value.dtype)

            target_prob.scatter_add_(-1, lower_idx.unsqueeze(-1), lower_weight.unsqueeze(-1))
            target_prob.scatter_add_(-1, upper_idx.unsqueeze(-1), upper_weight.unsqueeze(-1))

            return target_prob

    def forward(self, x, target = None, reduction = 'mean'):
        logits = self.to_logits(x)

        if not exists(target):
            prob = logits.softmax(dim = -1)
            return self.decode(prob)

        target_prob = self.value_to_prob(target)

        # Safe cross-entropy calculation over the last dimension
        log_probs = F.log_softmax(logits, dim = -1)
        loss = -(target_prob * log_probs).sum(dim = -1)

        if reduction == 'mean':
            return loss.mean()
        elif reduction == 'sum':
            return loss.sum()
        return loss

    def decode(self, prob):
        value = (prob * self.bins).sum(dim = -1)

        if self.use_symexp:
            value = self.sym_exp(value)

        return value

# attention

class Attention(Module):
    def __init__(
        self,
        dim,
        dim_context = None,
        heads = 8,
        dim_head = 64,
        dropout = 0.,
        norm_eps = 1e-6,
        gate_attn = False
    ):
        super().__init__()
        self.heads = heads
        self.scale = dim_head ** -0.5
        inner_dim = dim_head * heads

        self.norm = nn.LayerNorm(dim, eps = norm_eps)

        self.is_cross_attn = exists(dim_context)
        dim_context = default(dim_context, dim)
        self.norm_context = nn.LayerNorm(dim_context, eps = norm_eps) if self.is_cross_attn else None

        self.to_q = nn.Linear(dim, inner_dim)
        self.to_kv = nn.Linear(dim_context, inner_dim * 2)

        self.to_out_gates = nn.Sequential(
            nn.Linear(dim, heads),
            Rearrange('b ... h -> b h ... 1'),
            nn.Sigmoid()
        ) if gate_attn else None

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x, context = None):
        x = self.norm(x)

        if self.is_cross_attn:
            assert exists(context)
            context = self.norm_context(context)
        else:
            context = x

        q = self.to_q(x)
        k, v = self.to_kv(context).chunk(2, dim = -1)

        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), (q, k, v))

        sim = einsum('b h i d, b h j d -> b h i j', q, k) * self.scale
        attn = sim.softmax(dim = -1)

        out = einsum('b h i j, b h j d -> b h i d', attn, v)

        if exists(self.to_out_gates):
            out = out * self.to_out_gates(x) # https://arxiv.org/abs/2505.06708

        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)

def FeedForward(
        dim,
        dim_inner,
        norm_eps = 1e-6
    ):
    return nn.Sequential(
            nn.LayerNorm(dim, eps = norm_eps),
            nn.Linear(dim, dim_inner),
            nn.GELU(approximate = 'tanh'),
            nn.Linear(dim_inner, dim)
        )

class SigLIP(Module):
    def __init__(
        self,
        image_size = 224,
        patch_size = 14,
        dim = 1152,
        depth = 27,
        heads = 16,
        mlp_dim = 4304,
        norm_eps = 1e-6
    ):
        super().__init__()
        self.dim = dim
        self.depth = depth
        num_patches = (image_size // patch_size) ** 2
        dim_head = dim // heads

        self.to_patch_embed = nn.Sequential(
            Rearrange('b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1 = patch_size, p2 = patch_size),
            nn.Linear(patch_size * patch_size * 3, dim)
        )

        self.pos_embed = nn.Parameter(torch.randn(num_patches, dim))

        self.layers = ModuleList([])
        for _ in range(depth):
            self.layers.append(ModuleList([
                Attention(dim, heads = heads, dim_head = dim_head, norm_eps = norm_eps),
                FeedForward(dim = dim, dim_inner = mlp_dim, norm_eps = norm_eps)
            ]))

        self.norm = nn.LayerNorm(dim, eps = norm_eps)

    def forward(self, x):
        x = self.to_patch_embed(x)
        num_patches = x.shape[1]

        x = x + self.pos_embed[:num_patches]

        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x

        return self.norm(x)

    @torch.no_grad()
    def load_siglip_weights(
        self,
        repo_id = 'google/siglip-so400m-patch14-224',
        folder = 'checkpoints/siglip'
    ):
        folder = Path(folder)
        if not folder.exists():
            from huggingface_hub import snapshot_download
            snapshot_download(
                repo_id = repo_id,
                local_dir = folder,
                allow_patterns = ['config.json', 'model.safetensors']
            )

        from safetensors import safe_open
        weights_path = folder / 'model.safetensors'

        with safe_open(weights_path, framework = 'pt') as f:
            keys = f.keys()
            
            # auto-detect prefix
            vi_p = ''
            for candidate in (
                'paligemma_with_expert.paligemma.model.vision_tower.vision_model.',
                'vision_model.'
            ):
                if any(k.startswith(candidate) for k in keys):
                    vi_p = candidate
                    break
            
            state = self.state_dict()

            def copy_weight_bias(pz_prefix, vi_prefix):
                for suffix in ('.weight', '.bias'):
                    state[f'{pz_prefix}{suffix}'].copy_(f.get_tensor(f'{vi_prefix}{suffix}'))

            # patch embedding
            patch_weight = rearrange(f.get_tensor(f'{vi_p}embeddings.patch_embedding.weight'), 'd c h w -> d (h w c)')
            state['to_patch_embed.1.weight'].copy_(patch_weight)
            state['to_patch_embed.1.bias'].copy_(f.get_tensor(f'{vi_p}embeddings.patch_embedding.bias'))

            # position embedding
            state['pos_embed'].copy_(f.get_tensor(f'{vi_p}embeddings.position_embedding.weight'))

            # transformer layers
            for i in range(self.depth):
                v_pi = f'{vi_p}encoder.layers.{i}'
                v_pz = f'layers.{i}'

                # attention
                copy_weight_bias(f'{v_pz}.0.norm', f'{v_pi}.layer_norm1')
                copy_weight_bias(f'{v_pz}.0.to_q', f'{v_pi}.self_attn.q_proj')

                vk, vv = [f.get_tensor(f'{v_pi}.self_attn.{x}_proj.weight') for x in ('k', 'v')]
                bk, bv = [f.get_tensor(f'{v_pi}.self_attn.{x}_proj.bias') for x in ('k', 'v')]

                state[f'{v_pz}.0.to_kv.weight'].copy_(cat((vk, vv), dim = 0))
                state[f'{v_pz}.0.to_kv.bias'].copy_(cat((bk, bv), dim = 0))

                copy_weight_bias(f'{v_pz}.0.to_out.0', f'{v_pi}.self_attn.out_proj')

                # feedforward
                copy_weight_bias(f'{v_pz}.1.0', f'{v_pi}.layer_norm2')
                copy_weight_bias(f'{v_pz}.1.1', f'{v_pi}.mlp.fc1')
                copy_weight_bias(f'{v_pz}.1.3', f'{v_pi}.mlp.fc2')

            # post-layernorm
            copy_weight_bias('norm', f'{vi_p}post_layernorm')

        print(f'Successfully loaded SigLIP weights from {repo_id}')

@save_load()
class SigLIPValueNetwork(Module):
    def __init__(
        self,
        *,
        siglip_image_size = 224,
        siglip_patch_size = 14,
        siglip_dim = 1152,
        siglip_depth = 27,
        siglip_heads = 16,
        siglip_mlp_dim = 4304,
        siglip_norm_eps = 1e-6,
        loss_module_name = 'mse',
        loss_module_kwargs: dict = dict(),
        multiview_combine_strategy = 'mean',
        num_views: int | None = None
    ):
        super().__init__()

        self.multiview_combine_strategy = multiview_combine_strategy
        self.num_views = num_views

        if multiview_combine_strategy == 'concat':
            assert exists(num_views), 'num_views must be provided if multiview_combine_strategy is "concat"'
            self.to_multiview_concat = nn.Linear(num_views * siglip_dim, siglip_dim)

        self.vit = SigLIP(
            image_size = siglip_image_size,
            patch_size = siglip_patch_size,
            dim = siglip_dim,
            depth = siglip_depth,
            heads = siglip_heads,
            mlp_dim = siglip_mlp_dim,
            norm_eps = siglip_norm_eps
        )

        self.pool = Reduce('b n d -> b d', 'mean')

        if loss_module_name == 'mse':
            loss_module_class = MSELossModule
        elif loss_module_name == 'hlgauss':
            loss_module_class = HLGaussLossModule
        elif loss_module_name == 'categorical':
            loss_module_class = CategoricalLossModule
        elif loss_module_name in LOSS_MODULES:
            loss_module_class = LOSS_MODULES[loss_module_name]
        else:
            raise ValueError(f'unknown loss module {loss_module_name}')

        self.loss_module = loss_module_class(siglip_dim, **loss_module_kwargs)

    def load_siglip(self, **kwargs):
        self.vit.load_siglip_weights(**kwargs)

    def forward(
        self,
        images,
        targets: Tensor | list[Tensor] | tuple[Tensor, ...] | None = None,
        freeze_vit = False,
        return_unreduced_loss = False
    ):
        if images.dtype == torch.uint8:
            images = images.float() / 255.0

        is_multi_view = images.ndim == 5

        if is_multi_view:
            images, inverse_pack = pack_with_inverse(images, '* c h w')

        vit_forward_context = torch.no_grad if freeze_vit else nullcontext

        with vit_forward_context():
            embeds = self.vit(images)

        pooled = self.pool(embeds)

        if is_multi_view:
            pooled = inverse_pack(pooled, '* d')

            if self.multiview_combine_strategy == 'mean':
                pooled = reduce(pooled, 'b v d -> b d', 'mean')
            elif self.multiview_combine_strategy == 'concat':
                pooled = rearrange(pooled, 'b v d -> b (v d)')
                pooled = self.to_multiview_concat(pooled)

        if not exists(targets):
            return self.loss_module(pooled)

        reduction = 'none' if return_unreduced_loss else 'mean'

        is_single_target = not isinstance(targets, (list, tuple))

        if is_single_target:
            return self.loss_module(pooled, targets, reduction = reduction)

        losses = [self.loss_module(pooled, target, reduction = reduction) for target in targets]
        return losses

# image preprocessing

def preprocess_image(image, image_size = 224):
    if not torch.is_tensor(image):
        image = torch.from_numpy(image)

    # detect batch/multi-view dims
    if image.ndim > 3:
        return stack([preprocess_image(img, image_size) for img in image.unbind(dim = 0)])

    if image.dtype == torch.uint8:
        image = image.float() / 255.0
    
    # pad to square
    c, h, w = image.shape
    max_dim = max(h, w)
    pad_h = (max_dim - h) // 2
    pad_w = (max_dim - w) // 2
    
    if pad_h > 0 or pad_w > 0:
        image = F.pad(image, (pad_w, max_dim - w - pad_w, pad_h, max_dim - h - pad_h), value = 0.0)

    if image.shape[-2:] != (image_size, image_size):
        image = F.interpolate(
            image.unsqueeze(0),
            size = (image_size, image_size),
            mode = 'bilinear',
            align_corners = False,
            antialias = True
        ).squeeze(0)

    return image

# dataset and trainer

class TrainingDataset(Dataset):
    def __init__(
        self,
        replay_dataset,
        image_size = 224,
        include_success = False
    ):
        self.replay_dataset = replay_dataset
        self.transform = T.Compose([
            T.ToPILImage(),
            T.Pad(padding = 0, padding_mode = 'edge'), # will be updated per image
            T.Resize((image_size, image_size)),
            T.ToTensor()
        ])
        self.image_size = image_size
        self.include_success = include_success

    def __len__(self):
        return len(self.replay_dataset)

    def __getitem__(self, idx):
        data = self.replay_dataset[idx]
        image = data['images'] # (C, H, W)
        image_tensor = preprocess_image(image, self.image_size)
        
        progress = torch.as_tensor(data['progress'], dtype = torch.float32)
        
        if not self.include_success:
            return image_tensor, progress

        success = torch.tensor(data['success'], dtype = torch.bool)
        return image_tensor, progress, success


class ValueNetworkTrainer(Module):
    def __init__(
        self,
        model,
        replay_buffer: str | Path | ReplayBuffer,
        batch_size = 16,
        lr = 1e-4,
        max_grad_norm = 0.5,
        wd = 0.01,
        image_size = 224
    ):
        super().__init__()
        self.accelerator = Accelerator()
        
        # replay buffer and dataset

        if isinstance(replay_buffer, (str, Path)):
            replay_buffer = ReplayBuffer.from_folder(replay_buffer)

        replay_dataset = replay_buffer.dataset(timestep_level = True, filter_meta = dict(success = True))
        dataset = TrainingDataset(replay_dataset, image_size = image_size)

        # model and optimizer

        self.model = model
        self.optimizer = AdamW(model.parameters(), lr = lr, weight_decay = wd)
        
        self.dataloader = DataLoader(dataset, batch_size = batch_size, shuffle = True)
        
        self.model, self.optimizer, self.dataloader = self.accelerator.prepare(
            self.model, self.optimizer, self.dataloader
        )
        
        self.max_grad_norm = max_grad_norm

    def train(self, num_train_steps = 1000):
        self.model.train()
        
        iter_dataloader = cycle(self.dataloader)
        
        with click.progressbar(range(num_train_steps), label = 'training') as bar:
            for _ in bar:
                images, progress = next(iter_dataloader)

                with self.accelerator.autocast():
                    loss = self.model(images, targets = progress)

                self.accelerator.backward(loss)
                
                if exists(self.max_grad_norm):
                    self.accelerator.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                
                self.optimizer.step()
                self.optimizer.zero_grad()

                bar.label = f'training (loss: {loss.item():.4f})'

class TDDataset(Dataset):
    def __init__(
        self,
        replay_buffer,
        image_size = 224
    ):
        self.replay_buffer = replay_buffer
        self.image_size = image_size
        
        # calculate valid transition indices (those that don't cross episode boundaries)

        episode_lens = replay_buffer.meta_data['episode_lens']
        
        curr_idx = 0
        valid_indices = []

        for length in episode_lens:
            valid_indices.extend(range(curr_idx, curr_idx + length - 1))
            curr_idx += length
            
        self.valid_indices = valid_indices
        self.replay_dataset = replay_buffer.dataset(timestep_level = True)

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        base_idx = self.valid_indices[idx]
        
        data_t = self.replay_dataset[base_idx]
        data_next = self.replay_dataset[base_idx + 1]
        
        image_t = preprocess_image(data_t['images'], self.image_size)
        image_next = preprocess_image(data_next['images'], self.image_size)
        
        reward_next = torch.as_tensor(data_next['rewards'], dtype = torch.float32)
        progress_t = torch.as_tensor(data_t['progress'], dtype = torch.float32)
        success_t = torch.as_tensor(data_t['success'], dtype = torch.bool)
        
        return image_t, image_next, reward_next, progress_t, success_t

class ValueNetworkTrainerWithTD(Module):
    def __init__(
        self,
        model,
        replay_buffer: str | Path | ReplayBuffer,
        batch_size = 16,
        lr = 1e-4,
        max_grad_norm = 0.5,
        wd = 0.01,
        image_size = 224,
        discount_factor = 0.99,
        use_ema = True,
        ema_kwargs: dict = dict(
            beta = 0.999,
            update_after_step = 10,
            update_every = 1
        ),
        td_loss_weight = 1.0
    ):
        super().__init__()
        self.accelerator = Accelerator()
        
        # replay buffer and dataset

        if isinstance(replay_buffer, (str, Path)):
            replay_buffer = ReplayBuffer.from_folder(replay_buffer)

        self.dataset = TDDataset(replay_buffer, image_size = image_size)
        self.discount_factor = discount_factor
        self.td_loss_weight = td_loss_weight

        # model and optimizer

        self.model = model
        self.optimizer = AdamW(model.parameters(), lr = lr, weight_decay = wd)
        
        self.dataloader = DataLoader(self.dataset, batch_size = batch_size, shuffle = True)
        
        self.model, self.optimizer, self.dataloader = self.accelerator.prepare(
            self.model, self.optimizer, self.dataloader
        )

        # optional ema

        self.ema_model = None

        if use_ema:
            self.ema_model = EMA(model, **ema_kwargs)
            self.ema_model = self.accelerator.prepare(self.ema_model)
        
        self.max_grad_norm = max_grad_norm

    def train(self, num_train_steps = 1000):
        self.model.train()
        
        iter_dataloader = cycle(self.dataloader)
        
        with click.progressbar(range(num_train_steps), label = 'training') as bar:
            for _ in bar:
                images_t, images_next, rewards_next, progress, success = next(iter_dataloader)

                with torch.no_grad():
                    target_model = self.ema_model if exists(self.ema_model) else self.model
                    v_next = target_model(images_next)

                td_target = rewards_next + self.discount_factor * v_next

                with self.accelerator.autocast():
                    # get both losses: progress loss and TD loss
                    
                    progress_loss, td_loss = self.model(
                        images_t,
                        targets = [progress, td_target],
                        return_unreduced_loss = True
                    )
                    
                    # only the first one is masked by the success, the second stays the same

                    success_progress_loss = progress_loss[success].mean()
                    td_loss = td_loss.mean()
                    
                    loss = success_progress_loss + td_loss * self.td_loss_weight

                self.accelerator.backward(loss)
                
                if exists(self.max_grad_norm):
                    self.accelerator.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                
                self.optimizer.step()
                self.optimizer.zero_grad()

                if exists(self.ema_model):
                    self.ema_model.update()

                bar.label = f'training (loss: {loss.item():.4f})'
