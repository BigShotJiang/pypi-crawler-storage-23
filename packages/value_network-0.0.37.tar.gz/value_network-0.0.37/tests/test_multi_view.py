import os
import torch
import numpy as np
import av
from pathlib import Path
from click.testing import CliRunner
from value_network.cli import main
from value_network.value_network import SigLIPValueNetwork
import shutil
import pytest

def create_mock_video(path, frames = 5, width = 64, height = 64):
    container = av.open(str(path), mode = 'w')
    stream = container.add_stream('libx264', rate = 10)
    stream.width = width
    stream.height = height
    stream.pix_fmt = 'yuv420p'

    for _ in range(frames):
        img = np.random.randint(0, 255, (height, width, 3), dtype = np.uint8)
        frame = av.VideoFrame.from_ndarray(img, format = 'rgb24')
        for packet in stream.encode(frame):
            container.mux(packet)

    # Flush stream
    for packet in stream.encode():
        container.mux(packet)
    container.close()

def create_multiview_data(data_dir):
    data_dir.mkdir(parents = True, exist_ok = True)
    
    # traj_0: view1 (success 0), view3 (success 0)
    create_mock_video(data_dir / "traj_0.view1.0.mp4")
    create_mock_video(data_dir / "traj_0.view3.0.mp4")
    
    # traj_1: view1 (success 1), view3 (success 1), view2 (ignored)
    create_mock_video(data_dir / "traj_1.view1.1.mp4")
    create_mock_video(data_dir / "traj_1.view2.1.mp4")
    create_mock_video(data_dir / "traj_1.view3.1.mp4")
    
    return data_dir

@pytest.fixture
def multiview_data(tmp_path):
    return create_multiview_data(tmp_path / "multiview_data")

@pytest.mark.parametrize('multiview_combine_strategy', ['mean', 'concat'])
def test_multi_view_model_support(multiview_combine_strategy):
    batch = 2
    num_views = 3
    image_size = 224
    dim = 64
    
    # Initialize network with small dimensions for testing
    net = SigLIPValueNetwork(
        siglip_depth = 1,
        siglip_dim = dim,
        siglip_heads = 2,
        siglip_mlp_dim = 128,
        siglip_image_size = image_size,
        multiview_combine_strategy = multiview_combine_strategy,
        num_views = num_views if multiview_combine_strategy == 'concat' else None
    )
    
    # Input shape: (batch, num_views, channels, height, width)
    images = torch.randn(batch, num_views, 3, image_size, image_size)
    
    # Forward pass
    output = net(images)
    
    # Verify output shape is (batch,)
    assert output.shape == (batch,)
    
    # Verify backprop
    targets = torch.randn(batch)
    loss = net(images, targets = targets)
    loss.backward()

    # 4D case should still work (if mean)
    if multiview_combine_strategy == 'mean':
        images_4d = torch.randn(batch, 3, image_size, image_size)
        output_4d = net(images_4d)
        assert output_4d.shape == (batch,)

def test_generate_memmap_multiview(multiview_data, tmp_path):
    runner = CliRunner()
    output_buffer = tmp_path / "replay_buffer"
    
    result = runner.invoke(main, [
        'generate-memmap-files',
        str(multiview_data),
        '--output-folder', str(output_buffer),
        '--match-views', 'view1',
        '--match-views', 'view3',
        '--max-episodes', '10',
        '--max-timesteps', '20'
    ])
    
    assert result.exit_code == 0
    assert output_buffer.exists()
    
    # Check buffer metadata or structure
    from memmap_replay_buffer import ReplayBuffer
    rb = ReplayBuffer.from_folder(str(output_buffer))
    
    # 2 trajectories matched (traj_0 and traj_1)
    assert rb.num_episodes == 2
    
    # Images shape: (max_episodes, max_timesteps, V=2, C=3, H=64, W=64)
    # We check the field shape specifically
    assert rb.data['images'].shape[2:] == (2, 3, 64, 64)

def test_train_multiview(multiview_data, tmp_path):
    runner = CliRunner()
    model_path = tmp_path / "model.pt"
    
    # Run training for 1 step
    result = runner.invoke(main, [
        'train',
        str(multiview_data),
        '--model-output-path', str(model_path),
        '--max-steps', '1',
        '--batch-size', '1',
        '--match-views', 'view1',
        '--match-views', 'view3'
    ])
    
    assert result.exit_code == 0
    assert model_path.exists()

def test_predict_multiview(multiview_data, tmp_path):
    # First train a dummy model
    model_path = tmp_path / "model.pt"
    runner = CliRunner()
    runner.invoke(main, [
        'train',
        str(multiview_data),
        '--model-output-path', str(model_path),
        '--max-steps', '1',
        '--batch-size', '1',
        '--match-views', 'view1',
        '--match-views', 'view3'
    ])
    
    # Predict with 2 views
    result = runner.invoke(main, [
        'predict-value',
        str(model_path),
        str(multiview_data / "traj_0.view1.0.mp4"),
        str(multiview_data / "traj_0.view3.0.mp4")
    ])
    
    assert result.exit_code == 0
    assert "predicted values saved to" in result.output
