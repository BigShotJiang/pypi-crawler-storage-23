import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from utils import *

class RegressionMLP(nn.Module):
    def __init__(self, in_dim):
        super().__init__()

        self.mlp = nn.Sequential(
            nn.Linear(in_dim, 256),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(128, 64),
            nn.ReLU(),

            nn.Linear(64, 1)   # regression output
        )

    def forward(self, x):
        return self.mlp(x)
    

class MutationConvNet(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()

        # in_dim = số channel input (thường = 1)
        # out_dim = dimension embedding cuối (vd 100)

        self.conv1 = nn.Conv1d(in_dim, 32, kernel_size=9, stride=2, padding=4)
        self.bn1 = nn.BatchNorm1d(32)

        self.conv2 = nn.Conv1d(32, 64, kernel_size=7, stride=2, padding=3)
        self.bn2 = nn.BatchNorm1d(64)

        self.conv3 = nn.Conv1d(64, 128, kernel_size=5, stride=2, padding=2)
        self.bn3 = nn.BatchNorm1d(128)

        # ép về kích thước cố định
        self.global_pool = nn.AdaptiveAvgPool1d(1)

        self.fc = nn.Linear(128, out_dim)

    def forward(self, x):
        # x shape: (batch, in_dim, length)

        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))

        x = self.global_pool(x)  # (B, 128, 1)
        x = x.squeeze(-1)        # (B, 128)

        x = self.fc(x)           # (B, out_dim)

        return x
    
    
    
class GraphConv(nn.Module):
    def __init__(self, in_features, out_features):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x, adj):
        I = torch.eye(adj.size(-1), device=adj.device)
        adj = adj + I

        degree = torch.sum(adj, dim=-1)
        D_inv_sqrt = torch.pow(degree, -0.5)
        D_inv_sqrt[torch.isinf(D_inv_sqrt)] = 0.

        D_inv_sqrt = torch.diag_embed(D_inv_sqrt)
        adj_norm = torch.bmm(torch.bmm(D_inv_sqrt, adj), D_inv_sqrt)

        out = torch.bmm(adj_norm, x)
        out = self.linear(out)

        return out
    
    

class DeepCDR(nn.Module):
    def __init__(
        self,
        config,
        use_mut=True,
        use_gexp=True,
        use_methy=True,
        regr=True,
        use_relu=True,
        use_bn=True,
        use_GMP=True,
    ):
        super(DeepCDR, self).__init__()

        
        
        drug_dim        = config["drug_dim"]
        mutation_dim    = config["mutation_dim"]
        gexpr_dim       = config["gexpr_dim"]
        methy_dim       = config["methy_dim"]
        units_list      = config["units_list"]
        
        
        
        self.use_mut = use_mut
        self.use_gexp = use_gexp
        self.use_methy = use_methy
        self.regr = regr
        self.use_relu = use_relu
        self.use_bn = use_bn
        self.use_GMP = use_GMP

        # --------- GCN Layers ----------
        self.gcn_layers = nn.ModuleList()
        in_dim = drug_dim

        for u in units_list:
            self.gcn_layers.append(GraphConv(in_dim, u))  # bạn phải có GraphConv torch
            in_dim = u

        self.gcn_layers.append(GraphConv(in_dim, 100))
        self.gcn_dropout = nn.Dropout(0.1)

        # -------- Mutation CNN ----------
        
        
        self.mut_conv = MutationConvNet(mutation_dim, 100)
        # -------- Gene Expression ----------
        self.gexp_fc1 = nn.Linear(gexpr_dim, 256)
        self.gexp_bn = nn.BatchNorm1d(256)
        self.gexp_fc2 = nn.Linear(256, 100)

        # -------- Methylation ----------
        self.meth_fc1 = nn.Linear(methy_dim, 256)
        self.meth_bn = nn.BatchNorm1d(256)
        self.meth_fc2 = nn.Linear(256, 100)

        # -------- Fusion ----------
        fusion_dim = 100
        if use_mut:
            fusion_dim += 100
        if use_gexp:
            fusion_dim += 100
        if use_methy:
            fusion_dim += 100
        self.fc_fusion = RegressionMLP(fusion_dim)


    # ---------------------------------------------------

    def forward(self, drug_feat, drug_adj, mutation, gexpr, methy):
        
        # print(drug_feat.shape, drug_adj.shape, mutation.shape, gexpr.shape, methy.shape)
        # -------- GCN ----------
        x = drug_feat
        for gcn in self.gcn_layers:
            x = gcn(x, drug_adj)
            x = F.relu(x) if self.use_relu else torch.tanh(x)
            x = self.gcn_dropout(x)

        if self.use_GMP:
            x_drug = torch.max(x, dim=1)[0]
        else:
            x_drug = torch.mean(x, dim=1)
        # -------- Mutation ----------
        x_mut = self.mut_conv(mutation)
        # -------- Gene Expression ----------
        x_gexpr = torch.tanh(self.gexp_fc1(gexpr))
        x_gexpr = self.gexp_bn(x_gexpr)
        x_gexpr = F.dropout(x_gexpr, 0.1)
        x_gexpr = F.relu(self.gexp_fc2(x_gexpr))

        # -------- Methylation ----------
        x_meth = torch.tanh(self.meth_fc1(methy))
        x_meth = self.meth_bn(x_meth)
        x_meth = F.dropout(x_meth, 0.1)
        x_meth = F.relu(self.meth_fc2(x_meth))
        # -------- Fusion ----------
        x_all = x_drug
        if self.use_mut:
            x_all = torch.cat([x_all, x_mut], dim=1)
        if self.use_gexp:
            x_all = torch.cat([x_all, x_gexpr], dim=1)
        if self.use_methy:
            x_all = torch.cat([x_all, x_meth], dim=1)
        out = self.fc_fusion(x_all)

        if not self.regr:
            out = torch.sigmoid(out)
            
        return out
    # ---------------------------------------------------

    def _calc_mut_dim(self, mutation_dim):
        # Bạn nên tính đúng theo shape thực tế
        return 30 * 1 * 1  # placeholder → nên sửa đúng theo input

    def _calc_final_dim(self):
        # placeholder → nên forward dummy tensor để tính chính xác
        return 5 * 1 * 1