import torch
from utils import *
from torch.utils.data import Dataset

class DeepCDRDataLoader(Dataset):
    def __init__(self, drug_feat, drug_adj, mut, gexp, meth, y):
        self.drug_feat = torch.tensor(drug_feat)
        self.drug_adj  = torch.tensor(drug_adj)
        self.mut       = torch.tensor(mut)
        self.gexp      = torch.tensor(gexp)
        self.meth      = torch.tensor(meth)
        self.y         = torch.tensor(y)

    def __len__(self):
        return self.y.shape[0]

    def __getitem__(self, idx):
        return (
            self.drug_feat[idx],
            self.drug_adj[idx],
            self.mut[idx],
            self.gexp[idx],
            self.meth[idx],
            self.y[idx]
        )
        
        
