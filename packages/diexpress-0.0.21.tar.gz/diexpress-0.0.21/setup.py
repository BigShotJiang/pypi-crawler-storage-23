from setuptools import setup, find_packages

setup(
    name="DiExpress",
    version="0.0.18",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.23",
        "pandas>=1.5",
        "scikit-learn>=1.2"
    ],
)


# pip install torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cu126
# pip install scipy
# pip install scikit-learn
# pip install hickle
# pip install pandas