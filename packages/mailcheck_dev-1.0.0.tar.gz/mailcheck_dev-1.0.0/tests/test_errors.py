"""Tests for MailCheck error handling."""

import pytest
from mailcheck import MailCheckError


class TestMailCheckError:
    """Tests for MailCheckError exception class."""
    
    def test_error_initialization(self):
        """Test MailCheckError initialization."""
        error = MailCheckError(400, "invalid_email", "Email format is invalid")
        
        assert error.status == 400
        assert error.code == "invalid_email"
        assert str(error) == "Email format is invalid"
    
    def test_error_string_representation(self):
        """Test string representation of MailCheckError."""
        error = MailCheckError(401, "unauthorized", "Invalid API key")
        
        assert str(error) == "Invalid API key"
    
    def test_error_repr(self):
        """Test detailed repr of MailCheckError."""
        error = MailCheckError(404, "not_found", "Resource not found")
        
        expected = "MailCheckError(status=404, code='not_found', message='Resource not found')"
        assert repr(error) == expected
    
    def test_error_is_exception_subclass(self):
        """Test that MailCheckError inherits from Exception."""
        error = MailCheckError(500, "server_error", "Internal server error")
        
        assert isinstance(error, Exception)
        assert isinstance(error, MailCheckError)
    
    def test_error_message_access(self):
        """Test accessing error message through args."""
        message = "Rate limit exceeded"
        error = MailCheckError(429, "rate_limit", message)
        
        assert error.args[0] == message
    
    def test_error_with_empty_code(self):
        """Test error handling with empty code."""
        error = MailCheckError(400, "", "Bad request")
        
        assert error.code == ""
        assert error.status == 400
    
    def test_error_with_special_characters(self):
        """Test error with special characters in message."""
        message = "Email contains invalid characters: @#$%"
        error = MailCheckError(400, "invalid_format", message)
        
        assert str(error) == message
    
    def test_error_comparison(self):
        """Test that errors can be compared."""
        error1 = MailCheckError(400, "invalid", "Test message")
        error2 = MailCheckError(400, "invalid", "Test message")
        error3 = MailCheckError(401, "unauthorized", "Different message")
        
        # These are different objects, so they won't be equal
        assert error1 is not error2
        assert error1.status == error2.status
        assert error1.code == error2.code
        assert error1.status != error3.status