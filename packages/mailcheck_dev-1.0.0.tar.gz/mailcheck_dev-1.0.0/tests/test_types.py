"""Tests for MailCheck type definitions."""

import pytest
from typing import get_type_hints
from mailcheck.types import (
    MailCheckOptions,
    VerifyResult,
    BulkVerifyOptions,
    BulkVerifyResult,
    VerifyAuthOptions,
    VerifyAuthResult,
    MailCheckErrorBody,
)


class TestMailCheckOptions:
    """Tests for MailCheckOptions TypedDict."""
    
    def test_mailcheck_options_structure(self):
        """Test MailCheckOptions has correct structure."""
        options: MailCheckOptions = {
            "base_url": "https://api.example.com",
            "timeout": 60
        }
        
        assert options["base_url"] == "https://api.example.com"
        assert options["timeout"] == 60
    
    def test_mailcheck_options_optional_fields(self):
        """Test MailCheckOptions fields are optional."""
        # Should work with empty dict
        options: MailCheckOptions = {}
        assert isinstance(options, dict)
        
        # Should work with partial fields
        options_partial: MailCheckOptions = {"base_url": "https://test.com"}
        assert options_partial["base_url"] == "https://test.com"


class TestVerifyResult:
    """Tests for VerifyResult TypedDict."""
    
    def test_verify_result_structure(self):
        """Test VerifyResult has required fields."""
        result: VerifyResult = {
            "email": "test@example.com",
            "valid": True,
            "score": 85,
            "reason": "Valid email",
            "checks": {
                "syntax": "pass",
                "disposable": "pass",
                "mx": "pass",
                "smtp": "pass",
                "role": "skip",
                "free_provider": False
            },
            "details": {
                "risk_level": "low",
                "is_catch_all": False
            },
            "cached": False,
            "credits_remaining": 99
        }
        
        assert result["email"] == "test@example.com"
        assert result["valid"] is True
        assert result["score"] == 85
        assert result["checks"]["syntax"] == "pass"
        assert result["details"]["risk_level"] == "low"


class TestBulkVerifyOptions:
    """Tests for BulkVerifyOptions TypedDict."""
    
    def test_bulk_verify_options_structure(self):
        """Test BulkVerifyOptions structure."""
        options: BulkVerifyOptions = {
            "webhook_url": "https://example.com/webhook"
        }
        
        assert options["webhook_url"] == "https://example.com/webhook"
    
    def test_bulk_verify_options_empty(self):
        """Test BulkVerifyOptions can be empty."""
        options: BulkVerifyOptions = {}
        assert isinstance(options, dict)


class TestBulkVerifyResult:
    """Tests for BulkVerifyResult TypedDict."""
    
    def test_bulk_verify_result_structure(self):
        """Test BulkVerifyResult structure."""
        result: BulkVerifyResult = {
            "job_id": "job_123",
            "results": [{
                "email": "test@example.com",
                "valid": True,
                "score": 85,
                "reason": "Valid email",
                "checks": {
                    "syntax": "pass",
                    "disposable": "pass",
                    "mx": "pass",
                    "smtp": "pass",
                    "role": "skip",
                    "free_provider": False
                },
                "details": {
                    "risk_level": "low"
                },
                "cached": False,
                "credits_remaining": 99
            }],
            "total": 1,
            "unique_verified": 1,
            "credits_remaining": 99
        }
        
        assert result["job_id"] == "job_123"
        assert len(result["results"]) == 1
        assert result["total"] == 1


class TestVerifyAuthOptions:
    """Tests for VerifyAuthOptions TypedDict."""
    
    def test_verify_auth_options_with_headers(self):
        """Test VerifyAuthOptions with headers."""
        options: VerifyAuthOptions = {
            "headers": "From: sender@example.com\nTo: recipient@test.com"
        }
        
        assert "From: sender@example.com" in options["headers"]
    
    def test_verify_auth_options_with_raw_email(self):
        """Test VerifyAuthOptions with raw email."""
        options: VerifyAuthOptions = {
            "raw_email": "Full email content here..."
        }
        
        assert options["raw_email"] == "Full email content here..."
    
    def test_verify_auth_options_with_trusted_domains(self):
        """Test VerifyAuthOptions with trusted domains."""
        options: VerifyAuthOptions = {
            "headers": "From: sender@example.com",
            "trusted_domains": ["example.com", "test.com"]
        }
        
        assert len(options["trusted_domains"]) == 2
        assert "example.com" in options["trusted_domains"]


class TestVerifyAuthResult:
    """Tests for VerifyAuthResult TypedDict."""
    
    def test_verify_auth_result_structure(self):
        """Test VerifyAuthResult structure."""
        result: VerifyAuthResult = {
            "trust_score": 85,
            "verdict": "trusted",
            "from_": {
                "address": "sender@example.com",
                "display_name": "John Doe",
                "domain": "example.com"
            },
            "authentication": {
                "spf": {
                    "result": "pass",
                    "domain": "example.com"
                },
                "dkim": {
                    "result": "present",
                    "has_public_key": True
                },
                "dmarc": {
                    "has_policy": True,
                    "policy": "quarantine"
                }
            },
            "anomalies": [],
            "lookalike": {
                "is_lookalike": False
            },
            "privacy": {
                "body_processed": False,
                "headers_only": True
            },
            "credits_remaining": 98
        }
        
        assert result["trust_score"] == 85
        assert result["verdict"] == "trusted"
        assert result["from_"]["address"] == "sender@example.com"
        assert result["authentication"]["spf"]["result"] == "pass"
        assert len(result["anomalies"]) == 0


class TestMailCheckErrorBody:
    """Tests for MailCheckErrorBody TypedDict."""
    
    def test_error_body_with_all_fields(self):
        """Test error body with all fields."""
        error: MailCheckErrorBody = {
            "code": "invalid_email",
            "error": "validation_error",
            "message": "Email format is invalid"
        }
        
        assert error["code"] == "invalid_email"
        assert error["error"] == "validation_error"
        assert error["message"] == "Email format is invalid"
    
    def test_error_body_minimal(self):
        """Test error body with minimal fields."""
        error: MailCheckErrorBody = {
            "message": "Something went wrong"
        }
        
        assert error["message"] == "Something went wrong"


class TestTypeHints:
    """Tests to verify type hints are working correctly."""
    
    def test_type_hints_exist(self):
        """Test that type hints are properly defined."""
        # This will raise if type hints are not available
        hints = get_type_hints(VerifyResult)
        assert 'email' in hints
        assert 'valid' in hints
        assert 'score' in hints
    
    def test_optional_types(self):
        """Test that optional types work correctly."""
        # Test that None is acceptable for optional fields
        options: MailCheckOptions = {}
        
        # Should not raise any type errors
        base_url = options.get("base_url")
        timeout = options.get("timeout")
        
        assert base_url is None
        assert timeout is None