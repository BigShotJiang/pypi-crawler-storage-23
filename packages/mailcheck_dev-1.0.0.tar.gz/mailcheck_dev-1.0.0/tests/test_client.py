"""Tests for the MailCheck client."""

import json
import pytest
from unittest.mock import patch, MagicMock
import requests

from mailcheck import MailCheck, MailCheckError


class TestMailCheckConstructor:
    """Tests for MailCheck constructor."""
    
    def test_constructor_with_api_key(self):
        """Test constructor with valid API key."""
        mc = MailCheck("sk_live_test123")
        assert mc._api_key == "sk_live_test123"
        assert mc._base_url == "https://api.mailcheck.dev"
        assert mc._timeout == 30
        assert mc.bulk is not None
    
    def test_constructor_with_options(self):
        """Test constructor with custom options."""
        options = {
            "base_url": "https://custom.api.com",
            "timeout": 60
        }
        mc = MailCheck("sk_live_test123", options)
        assert mc._base_url == "https://custom.api.com"
        assert mc._timeout == 60
    
    def test_constructor_strips_trailing_slash(self):
        """Test that trailing slashes are removed from base URL."""
        options = {"base_url": "https://api.example.com/"}
        mc = MailCheck("sk_live_test123", options)
        assert mc._base_url == "https://api.example.com"
    
    def test_constructor_missing_api_key(self):
        """Test constructor raises error with missing API key."""
        with pytest.raises(ValueError, match="API key is required"):
            MailCheck("")
        
        with pytest.raises(ValueError, match="API key is required"):
            MailCheck(None)  # type: ignore


class TestMailCheckVerify:
    """Tests for single email verification."""
    
    @patch('mailcheck.client.requests.request')
    def test_verify_success(self, mock_request):
        """Test successful email verification."""
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "email": "test@example.com",
            "valid": True,
            "score": 85,
            "reason": "Valid email",
            "checks": {
                "syntax": "pass",
                "disposable": "pass",
                "mx": "pass",
                "smtp": "pass",
                "role": "skip",
                "free_provider": False
            },
            "details": {
                "risk_level": "low",
                "is_catch_all": False
            },
            "cached": False,
            "credits_remaining": 99
        }
        mock_request.return_value = mock_response
        
        mc = MailCheck("sk_live_test123")
        result = mc.verify("test@example.com")
        
        assert result["email"] == "test@example.com"
        assert result["valid"] is True
        assert result["score"] == 85
        assert result["credits_remaining"] == 99
    
    @patch('mailcheck.client.requests.request')
    def test_verify_http_error(self, mock_request):
        """Test verification with HTTP error response."""
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = 400
        mock_response.reason = "Bad Request"
        mock_response.json.return_value = {
            "code": "invalid_email",
            "message": "Email format is invalid"
        }
        mock_request.return_value = mock_response
        
        mc = MailCheck("sk_live_test123")
        with pytest.raises(MailCheckError) as exc_info:
            mc.verify("invalid-email")
        
        assert exc_info.value.status == 400
        assert exc_info.value.code == "invalid_email"
        assert "Email format is invalid" in str(exc_info.value)
    
    @patch('mailcheck.client.requests.request')
    def test_verify_timeout(self, mock_request):
        """Test verification with timeout."""
        mock_request.side_effect = requests.exceptions.Timeout()
        
        mc = MailCheck("sk_live_test123")
        with pytest.raises(MailCheckError) as exc_info:
            mc.verify("test@example.com")
        
        assert exc_info.value.status == 0
        assert exc_info.value.code == "timeout"
        assert "timed out" in str(exc_info.value)
    
    @patch('mailcheck.client.requests.request')
    def test_verify_network_error(self, mock_request):
        """Test verification with network error."""
        mock_request.side_effect = requests.exceptions.ConnectionError("Connection refused")
        
        mc = MailCheck("sk_live_test123")
        with pytest.raises(MailCheckError) as exc_info:
            mc.verify("test@example.com")
        
        assert exc_info.value.status == 0
        assert exc_info.value.code == "network_error"


class TestMailCheckVerifyAuth:
    """Tests for email authentication verification."""
    
    @patch('mailcheck.client.requests.request')
    def test_verify_auth_success(self, mock_request):
        """Test successful auth verification."""
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "trust_score": 85,
            "verdict": "trusted",
            "from": {
                "address": "sender@example.com",
                "display_name": "John Doe",
                "domain": "example.com"
            },
            "authentication": {
                "spf": {
                    "result": "pass",
                    "domain": "example.com"
                },
                "dkim": {
                    "result": "present",
                    "has_public_key": True
                },
                "dmarc": {
                    "has_policy": True,
                    "policy": "quarantine"
                }
            },
            "anomalies": [],
            "lookalike": {
                "is_lookalike": False
            },
            "privacy": {
                "body_processed": False,
                "headers_only": True
            },
            "credits_remaining": 98
        }
        mock_request.return_value = mock_response
        
        mc = MailCheck("sk_live_test123")
        result = mc.verify_auth({"headers": "From: sender@example.com"})
        
        assert result["trust_score"] == 85
        assert result["verdict"] == "trusted"
        assert result["from_"]["address"] == "sender@example.com"  # Note: 'from' becomes 'from_'
        assert result["credits_remaining"] == 98
    
    @patch('mailcheck.client.requests.request')
    def test_verify_auth_with_all_options(self, mock_request):
        """Test auth verification with all options."""
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "trust_score": 70,
            "verdict": "suspicious",
            "authentication": {
                "spf": {"result": "fail", "domain": "example.com"},
                "dkim": {"result": "missing", "has_public_key": False},
                "dmarc": {"has_policy": False, "policy": None}
            },
            "anomalies": [{
                "type": "suspicious_domain",
                "severity": "medium",
                "message": "Domain has suspicious characteristics"
            }],
            "lookalike": {"is_lookalike": True, "similar_to": "gmail.com"},
            "privacy": {"body_processed": False, "headers_only": True},
            "credits_remaining": 97
        }
        mock_request.return_value = mock_response
        
        mc = MailCheck("sk_live_test123")
        options = {
            "headers": "From: sender@suspicious.com",
            "raw_email": "Full email content...",
            "trusted_domains": ["example.com", "trusted.com"]
        }
        result = mc.verify_auth(options)
        
        assert result["trust_score"] == 70
        assert result["verdict"] == "suspicious"
        assert len(result["anomalies"]) == 1
        assert result["lookalike"]["is_lookalike"] is True


class TestBulkClient:
    """Tests for bulk email verification."""
    
    @patch('mailcheck.client.requests.request')
    def test_bulk_verify_success(self, mock_request):
        """Test successful bulk verification."""
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "job_id": "job_123",
            "results": [
                {
                    "email": "test1@example.com",
                    "valid": True,
                    "score": 85,
                    "reason": "Valid email",
                    "checks": {
                        "syntax": "pass",
                        "disposable": "pass",
                        "mx": "pass",
                        "smtp": "pass",
                        "role": "skip",
                        "free_provider": False
                    },
                    "details": {"risk_level": "low"},
                    "cached": False
                }
            ],
            "total": 1,
            "unique_verified": 1,
            "credits_remaining": 95
        }
        mock_request.return_value = mock_response
        
        mc = MailCheck("sk_live_test123")
        result = mc.bulk.verify(["test1@example.com"])
        
        assert result["job_id"] == "job_123"
        assert len(result["results"]) == 1
        assert result["total"] == 1
        assert result["credits_remaining"] == 95
    
    @patch('mailcheck.client.requests.request')
    def test_bulk_verify_with_webhook(self, mock_request):
        """Test bulk verification with webhook URL."""
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "job_id": "job_456",
            "results": [],
            "total": 2,
            "unique_verified": 2,
            "credits_remaining": 93
        }
        mock_request.return_value = mock_response
        
        mc = MailCheck("sk_live_test123")
        options = {"webhook_url": "https://example.com/webhook"}
        result = mc.bulk.verify(["test1@example.com", "test2@example.com"], options)
        
        assert result["job_id"] == "job_456"
        assert result["unique_verified"] == 2


class TestRequestMethod:
    """Tests for the internal _request method."""
    
    @patch('mailcheck.client.requests.request')
    def test_request_headers_set_correctly(self, mock_request):
        """Test that request headers are set correctly."""
        mc = MailCheck("sk_live_test123")
        
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"status": "ok"}
        mock_request.return_value = mock_response
        
        mc._request("/test", method="POST", body={"test": "data"})
        
        # Verify the request was called with correct headers
        mock_request.assert_called_once()
        call_args = mock_request.call_args
        headers = call_args[1]['headers']
        
        assert headers['Authorization'] == 'Bearer sk_live_test123'
        assert headers['Content-Type'] == 'application/json'
        assert 'User-Agent' in headers