"""Type definitions for the MailCheck SDK."""

from typing import Dict, List, Optional, Union, Any, Literal
from typing_extensions import TypedDict, NotRequired


class MailCheckOptions(TypedDict, total=False):
    """Configuration options for MailCheck client."""
    base_url: str
    timeout: int


class VerifyChecks(TypedDict):
    """Email verification checks results."""
    syntax: Literal['pass', 'fail', 'skip']
    disposable: Literal['pass', 'fail', 'skip']
    mx: Literal['pass', 'fail', 'skip']
    smtp: Literal['pass', 'fail', 'skip']
    role: Literal['pass', 'warn', 'skip']
    free_provider: bool


class VerifyDetails(TypedDict, total=False):
    """Detailed verification information."""
    mxHost: str
    isDisposable: bool
    catchAll: Optional[bool]
    catch_all: Optional[bool]
    smtpError: str
    is_role: bool
    role: str
    is_free_provider: bool
    free_provider_name: str
    is_disposable: bool
    has_typo_suggestion: bool
    typo_suggestion: str
    risk_level: Literal['low', 'medium', 'high']
    is_catch_all: bool


class VerifyResult(TypedDict):
    """Single email verification result."""
    email: str
    valid: bool
    score: int
    reason: str
    checks: VerifyChecks
    details: VerifyDetails
    cached: bool
    credits_remaining: int


class BulkVerifyOptions(TypedDict, total=False):
    """Options for bulk email verification."""
    webhook_url: str


class BulkVerifyResult(TypedDict):
    """Bulk email verification result."""
    job_id: str
    results: List[VerifyResult]
    total: int
    unique_verified: int
    credits_remaining: int


class VerifyAuthOptions(TypedDict, total=False):
    """Options for email authentication verification."""
    headers: str
    raw_email: str
    trusted_domains: List[str]


class VerifyAuthFrom(TypedDict):
    """From field information in auth verification."""
    address: str
    display_name: Optional[str]
    domain: str


class VerifyAuthSPF(TypedDict):
    """SPF authentication result."""
    result: Literal['pass', 'fail', 'softfail', 'neutral', 'none', 'temperror', 'permerror']
    domain: str
    ip: NotRequired[str]


class VerifyAuthDKIM(TypedDict):
    """DKIM authentication result."""
    result: Literal['present', 'missing', 'dns_error']
    domain: NotRequired[str]
    selector: NotRequired[str]
    has_public_key: bool


class VerifyAuthDMARC(TypedDict):
    """DMARC authentication result."""
    has_policy: bool
    policy: Optional[Literal['none', 'quarantine', 'reject']]
    record: NotRequired[str]


class VerifyAuthAuthentication(TypedDict):
    """Authentication check results."""
    spf: VerifyAuthSPF
    dkim: VerifyAuthDKIM
    dmarc: VerifyAuthDMARC


class VerifyAuthAnomaly(TypedDict):
    """Authentication anomaly."""
    type: str
    severity: Literal['low', 'medium', 'high', 'critical']
    message: str


class VerifyAuthLookalike(TypedDict):
    """Lookalike domain analysis."""
    is_lookalike: bool
    similar_to: NotRequired[str]
    technique: NotRequired[str]


class VerifyAuthPrivacy(TypedDict):
    """Privacy information about processing."""
    body_processed: Literal[False]
    headers_only: Literal[True]
    body_stripped: NotRequired[bool]


class VerifyAuthResult(TypedDict):
    """Email authentication verification result."""
    trust_score: int
    verdict: Literal['trusted', 'suspicious', 'dangerous']
    from_: Optional[VerifyAuthFrom]  # Note: 'from' is renamed to 'from_' to avoid Python keyword
    authentication: VerifyAuthAuthentication
    anomalies: List[VerifyAuthAnomaly]
    lookalike: VerifyAuthLookalike
    privacy: VerifyAuthPrivacy
    credits_remaining: int


class MailCheckErrorBody(TypedDict, total=False):
    """Error response body from API."""
    code: str
    error: str
    message: str