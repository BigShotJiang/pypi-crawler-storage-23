"""MailCheck API client implementation."""

import json
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:
    raise ImportError(
        "The 'requests' library is required. Install it with: pip install requests"
    )

from .types import (
    MailCheckOptions,
    VerifyResult,
    BulkVerifyOptions,
    BulkVerifyResult,
    VerifyAuthOptions,
    VerifyAuthResult,
    MailCheckErrorBody,
)
from .errors import MailCheckError

DEFAULT_BASE_URL = "https://api.mailcheck.dev"
DEFAULT_TIMEOUT = 30


class BulkClient:
    """Client for bulk email verification operations."""
    
    def __init__(self, mc: 'MailCheck') -> None:
        """Initialize the BulkClient with a reference to the main client."""
        self._mc = mc
    
    def verify(self, emails: List[str], options: Optional[BulkVerifyOptions] = None) -> BulkVerifyResult:
        """Submit a bulk email verification job.
        
        Args:
            emails: List of email addresses to verify.
            options: Optional configuration for the bulk verification.
        
        Returns:
            Bulk verification result including job ID and results.
        
        Raises:
            MailCheckError: If the API request fails.
        """
        if options is None:
            options = {}
        
        body: Dict[str, Any] = {"emails": emails}
        if options.get("webhook_url"):
            body["webhook_url"] = options["webhook_url"]
        
        return self._mc._request("/v1/verify/bulk", method="POST", body=body)


class MailCheck:
    """MailCheck API client for email verification services."""
    
    def __init__(self, api_key: str, options: Optional[MailCheckOptions] = None) -> None:
        """Initialize the MailCheck client.
        
        Args:
            api_key: Your MailCheck API key (starts with sk_live_).
            options: Optional configuration settings.
        
        Raises:
            ValueError: If the API key is missing or empty.
        """
        if not api_key:
            raise ValueError("API key is required")
        
        if options is None:
            options = {}
        
        self._api_key = api_key
        self._base_url = options.get("base_url", DEFAULT_BASE_URL).rstrip("/")
        self._timeout = options.get("timeout", DEFAULT_TIMEOUT)
        
        # Initialize sub-clients
        self.bulk = BulkClient(self)
    
    def verify(self, email: str) -> VerifyResult:
        """Verify a single email address.
        
        Args:
            email: The email address to verify.
        
        Returns:
            Verification result with validity, score, and detailed checks.
        
        Raises:
            MailCheckError: If the API request fails.
        """
        return self._request("/v1/verify", method="POST", body={"email": email})
    
    def verify_auth(self, options: VerifyAuthOptions) -> VerifyAuthResult:
        """Check email authentication (SPF/DKIM/DMARC) from raw email headers.
        
        Args:
            options: Authentication verification options including headers or raw_email.
        
        Returns:
            Authentication verification result with trust score and verdict.
        
        Raises:
            MailCheckError: If the API request fails.
        """
        body: Dict[str, Any] = {}
        
        if options.get("headers"):
            body["headers"] = options["headers"]
        if options.get("raw_email"):
            body["raw_email"] = options["raw_email"]
        if options.get("trusted_domains"):
            body["trusted_domains"] = options["trusted_domains"]
        
        result = self._request("/v1/verify/auth", method="POST", body=body)
        
        # Handle the 'from' field which is a Python keyword
        if "from" in result:
            result["from_"] = result.pop("from")
        
        return result
    
    def _request(self, path: str, method: str = "GET", body: Optional[Dict[str, Any]] = None) -> Any:
        """Make an HTTP request to the MailCheck API.
        
        Args:
            path: API endpoint path.
            method: HTTP method (GET, POST, etc.).
            body: Optional request body (will be JSON encoded).
        
        Returns:
            Parsed JSON response.
        
        Raises:
            MailCheckError: If the API request fails.
        """
        url = f"{self._base_url}{path}"
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._api_key}",
            "User-Agent": "mailcheck-python/1.0.0",
        }
        
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=body,
                timeout=self._timeout
            )
            
            # Handle successful response
            if response.ok:
                return response.json()
            
            # Handle HTTP error responses
            try:
                error_body = response.json()
            except (ValueError, requests.exceptions.JSONDecodeError):
                error_body = {"message": response.reason or "HTTP Error"}
            
            code = error_body.get("code") or error_body.get("error") or "unknown_error"
            message = error_body.get("message", response.reason or "HTTP Error")
            raise MailCheckError(response.status_code, code, message)
        
        except requests.exceptions.Timeout as e:
            raise MailCheckError(0, "timeout", f"Request to {path} timed out after {self._timeout}s") from e
        
        except requests.exceptions.ConnectionError as e:
            raise MailCheckError(0, "network_error", f"Network error: {str(e)}") from e
        
        except requests.exceptions.RequestException as e:
            raise MailCheckError(0, "request_error", f"Request error: {str(e)}") from e
        
        except MailCheckError:
            # Re-raise MailCheckError as-is to avoid double-wrapping
            raise
        
        except Exception as e:
            raise MailCheckError(0, "unknown_error", f"Unexpected error: {str(e)}") from e