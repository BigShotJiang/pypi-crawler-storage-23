"""MailCheck Python SDK for email verification."""

from .client import MailCheck
from .errors import MailCheckError

__version__ = "1.0.0"
__all__ = ["MailCheck", "MailCheckError"]