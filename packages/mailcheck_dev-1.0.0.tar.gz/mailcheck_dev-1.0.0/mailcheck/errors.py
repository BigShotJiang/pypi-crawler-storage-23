"""Exception classes for the MailCheck SDK."""


class MailCheckError(Exception):
    """Exception raised for errors returned by the MailCheck API."""
    
    def __init__(self, status: int, code: str, message: str) -> None:
        """Initialize the MailCheckError.
        
        Args:
            status: HTTP status code of the error response.
            code: Error code from the API response.
            message: Human-readable error message.
        """
        super().__init__(message)
        self.status = status
        self.code = code
    
    def __str__(self) -> str:
        """Return a string representation of the error."""
        return super().__str__()
    
    def __repr__(self) -> str:
        """Return a detailed string representation of the error."""
        return f"MailCheckError(status={self.status}, code='{self.code}', message='{super().__str__()}')"