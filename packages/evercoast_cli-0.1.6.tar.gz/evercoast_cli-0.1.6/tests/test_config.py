"""Tests for config file management."""

import os
import platform
import stat

import pytest

from evercoast_cli.config import Config, _parse_toml, _serialize_toml


class TestTomlParser:
    def test_parse_empty(self):
        assert _parse_toml("") == {}

    def test_parse_single_section(self):
        text = '[default]\napi_url = "https://example.com"\ntoken = "abc123"'
        result = _parse_toml(text)
        assert result == {
            "default": {
                "api_url": "https://example.com",
                "token": "abc123",
            }
        }

    def test_parse_multiple_sections(self):
        text = (
            '[default]\ntoken = "prod-token"\n\n'
            '[staging]\ntoken = "staging-token"'
        )
        result = _parse_toml(text)
        assert result["default"]["token"] == "prod-token"
        assert result["staging"]["token"] == "staging-token"

    def test_parse_ignores_comments(self):
        text = '# comment\n[default]\n# another\ntoken = "abc"'
        result = _parse_toml(text)
        assert result == {"default": {"token": "abc"}}

    def test_parse_handles_escaped_quotes(self):
        text = '[default]\nvalue = "has \\"quotes\\""'
        result = _parse_toml(text)
        assert result["default"]["value"] == 'has "quotes"'

    def test_roundtrip(self):
        original = {
            "default": {
                "api_url": "https://api.example.com",
                "token": "my-token-123",
                "bucket": "my-bucket",
            },
            "staging": {
                "api_url": "https://staging.example.com",
                "token": "staging-token",
            },
        }
        text = _serialize_toml(original)
        parsed = _parse_toml(text)
        assert parsed == original


class TestConfig:
    def test_save_and_read_profile(self, tmp_config):
        config = Config(config_path=tmp_config)
        config.save_profile(
            profile="default",
            api_url="https://api.example.com",
            token="my-token",
            bucket="my-bucket",
            region="us-east-1",
        )

        # Read it back
        config2 = Config(config_path=tmp_config)
        profile = config2.get_profile("default")
        assert profile is not None
        assert profile["api_url"] == "https://api.example.com"
        assert profile["token"] == "my-token"
        assert profile["bucket"] == "my-bucket"
        assert profile["region"] == "us-east-1"
        assert profile["upload_path"] == "client-uploads/"

    def test_multiple_profiles(self, tmp_config):
        config = Config(config_path=tmp_config)
        config.save_profile("default", "https://prod.com", "prod-tok", "prod-bucket", "us-east-1")
        config.save_profile("staging", "https://staging.com", "stg-tok", "stg-bucket", "us-west-2")

        config2 = Config(config_path=tmp_config)
        assert config2.get_profile("default")["token"] == "prod-tok"
        assert config2.get_profile("staging")["token"] == "stg-tok"

    def test_missing_profile_returns_none(self, tmp_config):
        config = Config(config_path=tmp_config)
        assert config.get_profile("nonexistent") is None

    def test_has_profile(self, tmp_config):
        config = Config(config_path=tmp_config)
        config.save_profile("default", "url", "tok", "bucket", "region")
        assert config.has_profile("default") is True
        assert config.has_profile("staging") is False

    def test_get_set_value(self, tmp_config):
        config = Config(config_path=tmp_config)
        config.save_profile("default", "url", "tok", "bucket", "region")
        config.set_value("default", "last_type", "takes")

        config2 = Config(config_path=tmp_config)
        assert config2.get_value("default", "last_type") == "takes"

    def test_get_value_missing_key(self, tmp_config):
        config = Config(config_path=tmp_config)
        config.save_profile("default", "url", "tok", "bucket", "region")
        assert config.get_value("default", "nonexistent") is None

    def test_get_value_missing_profile(self, tmp_config):
        config = Config(config_path=tmp_config)
        assert config.get_value("nonexistent", "key") is None

    def test_profile_name_helper(self, tmp_config):
        config = Config(config_path=tmp_config)
        assert config.get_profile_name(staging=False) == "default"
        assert config.get_profile_name(staging=True) == "staging"

    def test_api_url_helper(self, tmp_config):
        config = Config(config_path=tmp_config)
        assert "staging" in config.get_api_url(staging=True)
        assert "staging" not in config.get_api_url(staging=False)

    @pytest.mark.skipif(platform.system() == "Windows", reason="Unix permissions only")
    def test_file_permissions(self, tmp_config):
        config = Config(config_path=tmp_config)
        config.save_profile("default", "url", "tok", "bucket", "region")
        mode = os.stat(tmp_config).st_mode
        # Should be owner read/write only (0600)
        assert mode & stat.S_IRWXU == stat.S_IRUSR | stat.S_IWUSR
        assert mode & stat.S_IRWXG == 0
        assert mode & stat.S_IRWXO == 0

    def test_nonexistent_config_file(self, tmp_path):
        config = Config(config_path=tmp_path / "nonexistent" / "config.toml")
        assert config.get_profile("default") is None

    def test_overwrite_profile(self, tmp_config):
        config = Config(config_path=tmp_config)
        config.save_profile("default", "url1", "tok1", "bucket1", "region1")
        config.save_profile("default", "url2", "tok2", "bucket2", "region2")

        config2 = Config(config_path=tmp_config)
        assert config2.get_profile("default")["token"] == "tok2"
