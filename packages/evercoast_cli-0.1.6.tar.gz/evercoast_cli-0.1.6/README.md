# Evercoast CLI

Upload files to your company's S3 bucket with resumable uploads, checksum validation, and automatic credential management.

## Requirements

- Python 3.9+
- An active Evercoast account with S3 direct upload enabled by Evercoast support

## Install

```bash
pip install evercoast-cli
```

## Quick Start

### 1. Login (one-time setup)

```bash
evercoast login
```

You'll be prompted for your Evercoast email and password. You only need to do this once — credentials are saved and refresh automatically.

### 2. Upload

```bash
evercoast upload ./session-42/ --type takes
```

That's it. The CLI handles credentials, checksums, progress, and retries automatically.

---

## Upload Guide

### Data types

Choose a data type to route files to the right location:

```bash
evercoast upload ./session-42/ --type takes      # Raw capture data
evercoast upload ./meshes/ --type renders         # PLY or OBJ sequences
evercoast upload notes.zip --type other           # Anything else
```

If you don't pass `--type`, the CLI prompts you:

```
What type of data are you uploading?

  1) Raw take data (images, videos, calibration, 2D data)
  2) PLY or OBJ sequences
  3) Other data

Select [1-3] (default: 1):
```

Your last choice is remembered for next time.

| Type | Destination |
|------|-------------|
| `takes` | `client-uploads/takes/<folder-name>/` |
| `renders` | `client-uploads/renders/<folder-name>/` |
| `other` | `client-uploads/<folder-name>/` |

Use `--to` to specify a custom destination:

```bash
evercoast upload ./data/ --to my/custom/path
# → uploads to client-uploads/my/custom/path/
```

### Resumable uploads

Directories are synced. If an upload is interrupted (Ctrl+C, network drop, laptop sleep), re-run the same command and only the remaining files are uploaded:

```bash
# First run: uploads 847 files
evercoast upload ./session-42/ --type takes

# Second run: skips everything
evercoast upload ./session-42/ --type takes
# → "Nothing to upload — all 847 files already exist at destination."
```

### Checksum validation

SHA256 checksums are enabled by default. The CLI calculates a checksum locally and the server validates it — if data is corrupted in transit, the upload is rejected and retried.

Disable with `--no-checksum` if needed (not recommended).

### Network resilience

If the network drops during an upload, the CLI:

1. Detects the failure
2. Waits for connectivity to return
3. Retries with increasing delays (up to 5 minutes between attempts)

Retries continue indefinitely until the upload succeeds or you cancel with Ctrl+C. If you cancel, re-run the same command to resume where you left off.

### Dry run

Preview what would be uploaded without actually uploading:

```bash
evercoast upload ./session-42/ --type takes --dry-run
```

### Exclude files

Skip files matching glob patterns:

```bash
evercoast upload ./data/ --type takes --exclude "*.tmp" --exclude ".DS_Store"
```

### Skip confirmation

Uploads over 1 GB prompt for confirmation. Skip with `--yes`:

```bash
evercoast upload ./large-dataset/ --type takes --yes
```

---

## All Options

```
evercoast login
  Authenticate and save credentials (one-time setup)

evercoast upload <path> [options]
  --type [takes|renders|other]   Data type (prompted if omitted)
  --to TEXT                      Custom destination path
  --dry-run                      Preview without uploading
  --no-checksum                  Disable SHA256 checksum validation
  --exclude TEXT                 Exclude glob pattern (repeatable)
  -y, --yes                      Skip confirmation prompt
  --help                         Show help
```

## Troubleshooting

### "Not configured. Run 'evercoast login' first."

You haven't logged in yet. Run `evercoast login` and enter your Evercoast credentials.

### "Authentication expired."

Your saved credentials are no longer valid. Run `evercoast login` again.

### "S3 direct upload is not enabled for your company."

Contact Evercoast support to enable this feature for your company.

### Upload seems stuck

Large files use multipart upload — the progress bar may pause between parts. This is normal. If the upload truly stalls, Ctrl+C and re-run the same command to resume.

## Support

Contact Evercoast support or your account representative for help.
