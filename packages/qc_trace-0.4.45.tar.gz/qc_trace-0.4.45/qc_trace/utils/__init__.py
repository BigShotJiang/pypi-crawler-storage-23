"""Utility functions for QC Trace."""
