"""Unit tests for weight estimation module."""
