"""Enumeration constants for nonconform.

This module provides enum classes used throughout the package.
"""

from enum import Enum, auto


class Distribution(Enum):
    """Probability distributions for validation set sizes in randomized strategies.

    Attributes:
        BETA_BINOMIAL: Beta-binomial distribution for drawing validation fractions.
        UNIFORM: Discrete uniform distribution over a specified range.
        GRID: Discrete distribution over a specified set of values.
    """

    BETA_BINOMIAL = auto()
    UNIFORM = auto()
    GRID = auto()


class ScorePolarity(Enum):
    """Score direction conventions for anomaly detectors.

    Attributes:
        AUTO: Infer polarity from known detector families.
        HIGHER_IS_ANOMALOUS: Higher scores indicate more anomalous samples.
        HIGHER_IS_NORMAL: Higher scores indicate more normal samples.
    """

    AUTO = auto()
    HIGHER_IS_ANOMALOUS = auto()
    HIGHER_IS_NORMAL = auto()


class Pruning(Enum):
    """Pruning strategies for weighted FDR control.

    Attributes:
        HETEROGENEOUS: Remove elements based on independent random checks per item.
        HOMOGENEOUS: Apply one shared random decision to all items.
        DETERMINISTIC: Remove items using a fixed rule with no randomness.
    """

    HETEROGENEOUS = auto()
    HOMOGENEOUS = auto()
    DETERMINISTIC = auto()


class ConformalMode(Enum):
    """Model retention modes for conformal resampling strategies.

    Attributes:
        PLUS: Keep all calibration-time models for inference (Jackknife+/CV+ style).
        SINGLE_MODEL: Fit and retain one final model after calibration.
    """

    PLUS = "plus"
    SINGLE_MODEL = "single_model"


class TieBreakMode(Enum):
    """Tie-breaking modes for empirical p-value estimation.

    Attributes:
        CLASSICAL: Deterministic empirical conformal formula.
        RANDOMIZED: Randomized smoothing with uniform tie-breaking.
    """

    CLASSICAL = "classical"
    RANDOMIZED = "randomized"


class Kernel(Enum):
    """Kernel functions for KDE-based p-value computation.

    Attributes:
        GAUSSIAN: Gaussian (normal) kernel.
        EXPONENTIAL: Exponential kernel.
        BOX: Box (uniform) kernel.
        TRIANGULAR: Triangular kernel.
        EPANECHNIKOV: Epanechnikov kernel.
        BIWEIGHT: Biweight (quartic) kernel.
        TRIWEIGHT: Triweight kernel.
        TRICUBE: Tricube kernel.
        COSINE: Cosine kernel.
    """

    GAUSSIAN = "gaussian"
    EXPONENTIAL = "exponential"
    BOX = "box"
    TRIANGULAR = "tri"
    EPANECHNIKOV = "epa"
    BIWEIGHT = "biweight"
    TRIWEIGHT = "triweight"
    TRICUBE = "tricube"
    COSINE = "cosine"


__all__ = [
    "ConformalMode",
    "Distribution",
    "Kernel",
    "Pruning",
    "ScorePolarity",
    "TieBreakMode",
]
