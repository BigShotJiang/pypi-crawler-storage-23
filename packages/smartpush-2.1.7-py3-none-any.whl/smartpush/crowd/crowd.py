import json
import time

from tenacity import retry, stop_after_attempt, wait_fixed

from smartpush.base.request_base import CrowdRequestBase, RequestBase
from smartpush.base.url_enum import URL
from smartpush.export.basic.ExcelExportChecker import compare_dicts
from smartpush.export.basic.GetOssUrl import log_attempt
from smartpush.utils import ListDictUtils


class Crowd(CrowdRequestBase):

    def callEditCrowdPackage(self, crowdName="", groupRules=None, groupRelation="$AND",
                             triggerStock=False):
        """
        更新群组条件id
        :param triggerStock:
        :param crowdName:
        :param groupRules:
        :param groupRelation:
        :return:
        """
        requestParam = {"id": self.crowd_id, "crowdName": crowdName, "groupRelation": groupRelation,
                        "groupRules": groupRules, "triggerStock": triggerStock}
        result = self.request(method=URL.Crowd.editCrowdPackage.method, path=URL.Crowd.editCrowdPackage.url,
                              data=requestParam)
        return result['resultData']

    def callCrowdPersonListInPackage(self, page=1, pageSize=20, filter_type=None, operator='eq', filter_value=None):
        """
        获取群组联系人列表
        :param operator:操作符：eq/in/invalidPerson/subscribeStatusEnum/
        :param page:
        :param pageSize:
        :param filter_type: 过滤类型，email、sms、
        :param filter_value:具体值
        :return:
        """
        requestParam = {"id": self.crowd_id, "page": page, "pageSize": pageSize}
        if filter_value is not None:
            requestParam["filter"] = {filter_type: {operator: filter_value}}
        result = self.request(method=URL.Crowd.crowdPersonListInPackage.method,
                              path=URL.Crowd.crowdPersonListInPackage.url,
                              data=requestParam)
        resultData = result['resultData']
        return resultData

    def callCrowdPackageDetail(self, page=1, pageSize=20):
        """
        获取群组详情
        :param page:
        :param pageSize:
        :return:
        """
        requestParam = {"id": self.crowd_id, "page": page, "pageSize": pageSize, "filter": {}}
        # if filter_value is not None:
        #     requestParam["filter"] = {filter_type: {"in": filter_value}}
        result = self.request(method=URL.Crowd.crowdPackageDetail.method, path=URL.Crowd.crowdPackageDetail.url,
                              data=requestParam)
        resultData = result['resultData']
        return resultData

    def check_crowd(self, expected_rule, expected_ids=None, sleep=5):
        """校验群组结果"""
        result = {}
        # 校验群组详情条件
        crowd_detail = self.callCrowdPackageDetail()
        if crowd_detail["groupRules"] == expected_rule:
            result["rule"] = True
        else:
            result["rule"] = {"条件断言": False, "实际条件": crowd_detail["groupRules"]}
        # 校验群组筛选人群
        time.sleep(sleep)
        crowd_persons = self.callCrowdPersonListInPackage()
        if expected_ids is not None:
            crowd_person_ids = [person["id"] for person in crowd_persons["responseResult"]]
            crowd_person_uids = [person["uid"] for person in crowd_persons["responseResult"]]
            print("expected_ids", expected_ids, type(expected_ids))
            print("crowd_person_ids+crowd_person_uids", crowd_person_ids + crowd_person_uids)
            result["联系人断言"] = ListDictUtils.check_values_in_list_set(
                a=expected_ids, b=crowd_person_ids + crowd_person_uids)
        else:
            result["联系人断言"] = [True, "接口返回正常"]
        return result


class CrowdList(RequestBase):
    def callCrowdPackageList(self, page=1, pageSize=20):
        """
        获取群组联系人列表
        :param page:
        :param pageSize:
        :param filter_type:
        :param filter_value:
        :return:
        """
        requestParam = {"page": page, "pageSize": pageSize}
        result = self.request(method=URL.Crowd.crowdPackageList.method, path=URL.Crowd.crowdPackageList.url,
                              data=requestParam)
        resultData = result['resultData']
        return resultData


class AssertCrowd(Crowd):
    def __init__(self, crowd_id, host, headers, **kwargs):
        super(AssertCrowd, self).__init__(crowd_id=crowd_id, host=host, headers=headers, **kwargs)
        self.crowd_id = crowd_id

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(3), after=log_attempt)
    def assert_filter_value_in_person_package(self, page=1, pageSize=20, filter_type=None, operator='eq',
                                              filter_value=None):
        try:
            crowd_persons = super.callCrowdPersonListInPackage(page=page, pageSize=pageSize, filter_type=filter_type,
                                                               operator=operator, filter_value=filter_value)
            assert crowd_persons['num'] >= 1
            assert crowd_persons['responseResult'][0][filter_type] == filter_value
        except:
            raise
