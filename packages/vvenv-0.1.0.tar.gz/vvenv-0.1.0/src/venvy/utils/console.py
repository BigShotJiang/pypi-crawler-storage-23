"""Shared console instance for consistent output. Uses Rich if available, fallback otherwise."""

try:
    from rich.console import Console
    console = Console()
except ImportError:
    class _FallbackConsole:  # type: ignore
        """Minimal fallback console when Rich is not installed."""
        def print(self, *args, **kwargs):
            # Strip rich markup
            import re
            text = " ".join(str(a) for a in args)
            text = re.sub(r"\[/?[a-zA-Z0-9_ ]*\]", "", text)
            print(text)
        def input(self, prompt=""):
            return input(prompt)
    console = _FallbackConsole()  # type: ignore
