"""
venvy — Smart Python virtual environment manager.

Like package.json for Python projects.
"""

__version__ = "0.1.0"
__author__ = "venvy contributors"
__all__ = ["__version__"]
