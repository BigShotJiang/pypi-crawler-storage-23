"""
`venvy status` — show current venv and requirements info.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from venvy.core.config import load_config, find_project_root
from venvy.core.requirements_manager import list_requirements
from venvy.core.venv_manager import find_venv, get_venv_python
from venvy.utils.console import console
from venvy.utils.platform_utils import get_active_venv


def status_command() -> None:
    cwd = Path.cwd()
    root = find_project_root(cwd)
    config = load_config(root) if root else None

    console.print("\n[bold cyan]venvy status[/bold cyan]")
    console.print("─" * 40)

    # Project root
    if root:
        console.print(f"  Project root   : [bold]{root}[/bold]")
    else:
        console.print(f"  Project root   : [dim]not initialized (run venvy create venv)[/dim]")

    # Config
    if config:
        console.print(f"  Venv name      : [bold]{config.venv_name}[/bold]")
        console.print(f"  Requirements   : [bold]{config.requirements_file}[/bold]")
        console.print(f"  ipykernel      : [bold]{'yes' if config.install_ipykernel else 'no'}[/bold]")
    
    # Active venv
    active = get_active_venv()
    if active:
        console.print(f"  Active venv    : [green bold]{active}[/green bold]")
    else:
        venv_path = find_venv(root or cwd)
        if venv_path:
            console.print(f"  Found venv     : [yellow]{venv_path}[/yellow] [dim](not active)[/dim]")
        else:
            console.print(f"  Venv           : [red]not found[/red]")

    # Python version in venv
    venv_path = Path(active) if active else find_venv(root or cwd)
    if venv_path:
        python = get_venv_python(venv_path)
        if python.exists():
            result = subprocess.run([str(python), "--version"], capture_output=True, text=True)
            version = result.stdout.strip() or result.stderr.strip()
            console.print(f"  Python         : [bold]{version}[/bold]")

    # Requirements
    console.print()
    req_name = config.requirements_file if config else "requirements.txt"
    req_file = (root or cwd) / req_name
    list_requirements(req_file)
