"""
Shell integration commands:
- `venvy shell-init` — print shell functions to eval
- `venvy _find-venv`  — internal helper used by shell functions
- `venvy +` / `venvy -` — hints for activation/deactivation
"""

from __future__ import annotations

from pathlib import Path
import platform

from venvy.core.venv_manager import find_venv
from venvy.utils.console import console
from venvy.utils.platform_utils import (
    get_shell_init_script,
    get_shell_init_script_windows,
    IS_WINDOWS,
    get_active_venv,
)


def shell_init_command() -> None:
    """Print shell integration script to stdout (user evals or sources it)."""
    if IS_WINDOWS:
        print(get_shell_init_script_windows())
    else:
        print(get_shell_init_script())
    
    if not IS_WINDOWS:
        console.print(
            "\n[dim]Add to your ~/.bashrc or ~/.zshrc:[/dim]\n"
            '  [bold cyan]eval "$(venvy shell-init)"[/bold cyan]\n'
            "[dim]Then restart your terminal.[/dim]",
            highlight=False,
        )
    else:
        console.print(
            "\n[dim]Add to your $PROFILE:[/dim]\n"
            "  [bold cyan]venvy shell-init | Invoke-Expression[/bold cyan]\n"
            "[dim]Then restart PowerShell.[/dim]",
            highlight=False,
        )


def find_venv_command() -> None:
    """
    Internal command used by shell functions.
    Prints the path of the venv if found (no decoration).
    """
    venv_path = find_venv()
    if venv_path:
        print(str(venv_path))


def activate_hint_command() -> None:
    """Show how to activate the venv."""
    venv_path = find_venv()
    if not venv_path:
        console.print(
            "[red]✗[/red] No virtual environment found.\n"
            "   Run [bold]venvy create venv[/bold] to create one."
        )
        return

    active = get_active_venv()
    if active and Path(active).resolve() == venv_path.resolve():
        console.print(f"[green]✓[/green] Already active: [bold]{venv_path}[/bold]")
        return

    if IS_WINDOWS:
        script = venv_path / "Scripts" / "activate.bat"
        console.print(
            f"[cyan]→[/cyan] To activate, run:\n"
            f"  [bold cyan]{script}[/bold cyan]\n\n"
            f"[dim]Or add shell integration (venvy shell-init) and use:[/dim]\n"
            f"  [bold cyan]venvy +[/bold cyan]"
        )
    else:
        script = venv_path / "bin" / "activate"
        console.print(
            f"[cyan]→[/cyan] To activate, run:\n"
            f"  [bold cyan]source {script}[/bold cyan]\n\n"
            f"[dim]Or add shell integration (venvy shell-init) and use:[/dim]\n"
            f"  [bold cyan]venvy +[/bold cyan]"
        )


def deactivate_hint_command() -> None:
    """Show how to deactivate the venv."""
    active = get_active_venv()
    if not active:
        console.print("[yellow]⚠[/yellow]  No active virtual environment.")
        return
    console.print(
        f"[cyan]→[/cyan] To deactivate, run:\n"
        f"  [bold cyan]deactivate[/bold cyan]\n\n"
        f"[dim]Or with shell integration:[/dim]\n"
        f"  [bold cyan]venvy -[/bold cyan]"
    )
