"""
`venvy create venv` command.
Interactively creates a virtual environment.
"""

from __future__ import annotations

from pathlib import Path

import typer
from rich.prompt import Confirm, Prompt

from venvy.core.config import (
    DEFAULT_REQ_FILE,
    DEFAULT_VENV_NAME,
    VenvyConfig,
    load_config,
)
from venvy.core.venv_manager import create_venv
from venvy.utils.console import console


def create_venv_command(
    venv_name: str = DEFAULT_VENV_NAME,
    req_file: str = "",
    ipykernel: bool = False,
    yes: bool = False,
) -> None:
    """Interactive virtual environment creation."""
    cwd = Path.cwd()

    # Check if already initialized
    existing = load_config(cwd)
    if existing:
        console.print(
            f"[yellow]⚠[/yellow]  venvy is already initialized in this directory.\n"
            f"   Venv: [bold]{existing.venv_name}[/bold]  |  "
            f"Requirements: [bold]{existing.requirements_file}[/bold]"
        )
        if not yes:
            overwrite = Confirm.ask("Reinitialize?", default=False)
            if not overwrite:
                raise typer.Exit()

    console.print(
        "\n[bold cyan]venvy[/bold cyan] — virtual environment setup\n"
        + "─" * 40
    )

    # Question 1: ipykernel
    if not yes:
        install_ipy = Confirm.ask(
            "  [1/2] Install [bold]ipykernel[/bold] (for Jupyter notebook support)?",
            default=ipykernel,
        )
    else:
        install_ipy = ipykernel

    # Question 2: requirements file name
    if not yes:
        chosen_req = Prompt.ask(
            "  [2/2] Requirements file name",
            default=req_file or DEFAULT_REQ_FILE,
        )
    else:
        chosen_req = req_file or DEFAULT_REQ_FILE

    console.print()

    config = VenvyConfig(
        venv_name=venv_name,
        requirements_file=chosen_req,
        install_ipykernel=install_ipy,
    )

    success = create_venv(cwd, config)
    if not success:
        raise typer.Exit(code=1)
