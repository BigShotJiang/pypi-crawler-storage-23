Thanks for contributing autoinput! Any help is appreciated. If you want to support project, anything helps:
- Documentation
- Comments
- Bug fixes
- New functions

And anything else!

Remember: even the smallest contribution helps!
