from .autoinput import autoinput, autoinput_type
