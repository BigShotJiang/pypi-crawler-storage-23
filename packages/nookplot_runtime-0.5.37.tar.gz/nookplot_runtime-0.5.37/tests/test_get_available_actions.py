"""Tests for get_available_actions() — verifies contextual action lists per signal type."""
from __future__ import annotations

from nookplot_runtime.autonomous import get_available_actions


class TestGetAvailableActions:
    def test_dm_received_rich_action_set(self):
        actions = get_available_actions("dm_received")
        assert "reply" in actions
        assert "create_project" in actions
        assert "link_project_to_guild" in actions
        assert "propose_guild" in actions
        assert "create_bounty" in actions
        assert "execute_tool" in actions
        assert len(actions) > 15
        assert actions[-1] == "ignore"

    def test_channel_message_expanded(self):
        actions = get_available_actions("channel_message")
        assert "reply" in actions
        assert "publish" in actions
        assert "create_project" in actions
        assert "link_project_to_guild" in actions
        assert len(actions) > 10

    def test_new_follower(self):
        actions = get_available_actions("new_follower")
        assert "follow_back" in actions
        assert "send_dm" in actions

    def test_attestation_received(self):
        actions = get_available_actions("attestation_received")
        assert "attest_back" in actions

    def test_files_committed(self):
        actions = get_available_actions("files_committed")
        assert "review" in actions
        assert "request_ai_review" in actions

    def test_bounty(self):
        actions = get_available_actions("bounty")
        assert "claim" in actions
        assert "apply_bounty" in actions

    def test_directive_has_many_actions(self):
        actions = get_available_actions("directive")
        assert len(actions) >= 40
        assert "execute" in actions
        assert "create_project" in actions
        assert "egress_request" in actions
        assert "launch_token" in actions
        assert "query_oracle" in actions
        assert actions[-1] == "ignore"

    def test_unknown_type_returns_fallback(self):
        actions = get_available_actions("totally_unknown_signal")
        assert actions == ["reply", "ignore"]

    def test_agreement_created(self):
        actions = get_available_actions("agreement_created")
        assert "deliver_work" in actions
        assert "cancel_agreement" in actions

    def test_work_delivered(self):
        actions = get_available_actions("work_delivered")
        assert "settle_agreement" in actions
        assert "dispute_agreement" in actions

    def test_time_to_post(self):
        actions = get_available_actions("time_to_post")
        assert "create_post" in actions
        assert "publish_insight" in actions

    def test_bounty_application_submitted(self):
        actions = get_available_actions("bounty_application_submitted")
        assert "approve_bounty_application" in actions
        assert "reject_bounty_application" in actions

    def test_bounty_claimed(self):
        actions = get_available_actions("bounty_claimed")
        assert "approve_bounty_work" in actions
        assert "dispute_bounty_work" in actions

    def test_guild_opportunity(self):
        actions = get_available_actions("guild_opportunity")
        assert "join_guild" in actions
        assert "propose_guild" in actions

    def test_intent_matched(self):
        actions = get_available_actions("intent_matched")
        assert "submit_proposal" in actions
        assert "browse_intents" in actions

    def test_all_lists_end_with_ignore(self):
        """Every signal type's action list should end with 'ignore'."""
        signal_types = [
            "dm_received", "channel_message", "new_follower",
            "files_committed", "bounty", "directive",
            "agreement_created", "work_delivered",
            "time_to_post", "guild_opportunity",
        ]
        for sig in signal_types:
            actions = get_available_actions(sig)
            assert actions[-1] == "ignore", f"{sig} does not end with 'ignore'"

    def test_webhook_received(self):
        actions = get_available_actions("webhook_received")
        assert "egress_request" in actions
        assert "execute_tool" in actions
