# TIBET LLM Router

> Smart LLM routing with TIBET provenance - route queries to Ollama/OpenAI/Anthropic automatically

[![PyPI](https://img.shields.io/pypi/v/tibet-llm-router.svg)](https://pypi.org/project/tibet-llm-router/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Note:** This package replaces `tibet-router`. The name `tibet-router` is reserved for TIBET token routing (like jis-router for RABEL).

## Quick Start

```python
from llm_router import LLMRouter

# Simple usage
llm = LLMRouter()
response = llm.generate("Hello!")

# Auto-routing (picks best model for your query)
llm = LLMRouter(auto_route=True)
response = llm.generate("Write a Python function")  # Routes to code model
response = llm.generate("Quick question")  # Routes to fast model
```

## Installation

```bash
pip install tibet-llm-router

# With TIBET provenance tracking
pip install tibet-llm-router[tibet]
```

## Features

- **Auto-Routing**: Automatically selects the best model for your query
- **Code Detection**: Routes code queries to specialized code models
- **Complexity Analysis**: Complex queries go to reasoning models
- **TIBET Provenance**: Full audit trail of all LLM calls
- **Ollama Integration**: Works with any Ollama-compatible backend

## CLI Usage

```bash
# Generate text
llm-router gen "Write a haiku about AI"

# Auto-route
llm-router gen --auto "Complex philosophical question"

# Preview routing
llm-router route "Write Python code"
# Output: Model: deepseek-coder:6.7b, Reason: code query detected

# Interactive chat
llm-router chat --auto

# Check status
llm-router status
```

## With TIBET Provenance

```python
from llm_router import LLMRouter
from tibet_core import Provider

# Track all LLM calls
tibet = Provider(actor="my_app")
llm = LLMRouter(tibet=tibet, auto_route=True)

response = llm.generate("Explain quantum computing")
# Full provenance chain: who, what, when, why
```

## Model Configuration

```python
from llm_router import LLMRouter, ModelRouter, ModelConfig, ModelCapability

# Custom router
router = ModelRouter()
router.add_model(ModelConfig(
    name="my-custom-model:7b",
    size="7b",
    capabilities=[ModelCapability.CODE, ModelCapability.FAST],
    priority=50  # Higher = preferred
))

llm = LLMRouter(router=router, auto_route=True)
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OLLAMA_URL` | `http://localhost:11434` | Ollama API URL |

## Part of Humotica Stack

LLM Router is part of the Humotica AI ecosystem:

| Package | Description |
|---------|-------------|
| [tibet-core](https://pypi.org/project/tibet-core/) | TIBET provenance tracking |
| [oomllama](https://pypi.org/project/oomllama/) | .oom format Q2/Q4 quantization |
| [rapid-rag](https://pypi.org/project/rapid-rag/) | Local RAG with semantic search |

## Links

- [PyPI Package](https://pypi.org/project/tibet-llm-router/)
- [Humotica](https://humotica.com)
- [TIBET Documentation](https://humotica.com/docs/tibet)

---

**One Love, One fAmIly**

Built by Humotica AI Lab - Jasper, Claude, Gemini
