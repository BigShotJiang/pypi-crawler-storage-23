
# 打包上传 python setup.py sdist upload
# 打包并安装 python setup.py sdist install
############################################# pip3.8 install kwebsp==3.1.62 -i https://pypi.org/simple
import os,sys
from setuptools import setup
from kwebsp import kwebspinfo
confkcws={}
confkcws['name']=kwebspinfo['name']                             #项目的名称 
confkcws['version']=kwebspinfo['version']							#项目版本
confkcws['description']=kwebspinfo['description']       #项目的简单描述
confkcws['long_description']=kwebspinfo['long_description']     #项目详细描述
confkcws['license']=kwebspinfo['license']                    #开源协议   mit开源
confkcws['url']=kwebspinfo['url']
confkcws['author']=kwebspinfo['author']  					 #名字
confkcws['author_email']=kwebspinfo['author_email'] 	     #邮件地址
confkcws['maintainer']=kwebspinfo['maintainer'] 						 #维护人员的名字
confkcws['maintainer_email']=kwebspinfo['maintainer_email']    #维护人员的邮件地址
def get_file(folder='./',lists=[]):
    lis=os.listdir(folder)
    for files in lis:
        if not os.path.isfile(folder+"/"+files):
            if files=='__pycache__' or files=='.git':
                pass
            else:
                lists.append(folder+"/"+files)
                get_file(folder+"/"+files,lists)
        else:
            pass
    return lists
def start():
    b=get_file("kwebsp",['kwebsp'])
    setup(
        name = confkcws["name"],
        version = confkcws["version"],
        keywords = "kwebsp"+confkcws['version'],
        description = confkcws["description"],
        long_description = confkcws["long_description"],
        license = confkcws["license"],
        author = confkcws["author"],
        author_email = confkcws["author_email"],
        maintainer = confkcws["maintainer"],
        maintainer_email = confkcws["maintainer_email"],
        url=confkcws['url'],
        packages =  b,
        install_requires = ['kwebs>=1.3','pyOpenSSL==23.2.0','cryptography==41.0.7','chardet==4.0.0','apscheduler==3.6.3','oss2>=2.12.1','websocket-client==1.8.0','pillow==10.4.0'], #第三方包 'pyOpenSSL==23.2.0','cryptography==41.0.7'
        package_data = {
            '': ['*.html', '*.js','*.css','*.jpg','*.png','*.gif','server.bat','*.sh','*.md','*sqlite/app','*sqlite/index_index','*.config','*file/config.conf','*.TTF'],
        },
        entry_points = {
            'console_scripts':[
                'kwebsp = kwebsp.kwebsp:cill_start'
            ]
        }
    )
start()