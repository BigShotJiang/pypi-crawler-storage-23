from .app import *
from .. import kwebspinfo as kwebsp


fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=kwebsp['name'] #不要修改改参数，否则无法上传模块和插件

