# -*- coding: utf-8 -*-
__version__ = '1.1'
kwebspinfo={}
kwebspinfo['name']='kwebsp'                             #项目的名称
kwebspinfo['version']=__version__							#项目版本
kwebspinfo['description']='kwebsp是建立在 kwebs 框架的基础上研发的一套 linux 服务器容器系统'       #项目的简单描述
kwebspinfo['long_description']='kwebsp是建立在 kwebs 框架的基础上研发的一套 linux 服务器容器系统,其目的是为了解决可视化部署和架构的过程，系统本身是一款服务端管理软件，通过 web 可视化方式管理服务器，提升运维效率'     #项目详细描述
kwebspinfo['license']='Apache License 2.0'                    #开源协议
kwebspinfo['url']='https://docs.kwebapp.cn/index/index/3'
kwebspinfo['author']='百里-坤坤'  					 #名字
kwebspinfo['author_email']='kwebs@kwebapp.cn' 	     #邮件地址
kwebspinfo['maintainer']='百里' 						 #维护人员的名字
kwebspinfo['maintainer_email']='fk1402936534@qq.com'    #维护人员的邮件地址