# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from dataclasses import replace
from typing import Annotated, Literal, TypeVar

from pydantic import Discriminator
from pydantic.dataclasses import dataclass

from boulderopalscaleupsdk.utils.showable import Showable


@dataclass
class ConstantWaveform(Showable):  # pragma: no cover
    r"""
    A constant-amplitude pulse waveform.

    This waveform maintains a constant amplitude value for the entire duration,
    producing a rectangular pulse shape.

    Attributes
    ----------
    duration_ns : int
        Duration of the waveform in nanoseconds. Must be positive.
        Typical values: 20-100 ns for gates, 1000-2000 ns for measurements.
    amplitude : float
        Amplitude of the constant waveform. Dimensionless, typically
        normalized in the range [0, 1]. Common values: 0.1-0.4.
    waveform_type : Literal["Constant"]
        Type discriminator for serialization.

    Notes
    -----
    The waveform is mathematically defined as:

    $$f(t) = A$$

    where: $A$ is the amplitude and $t \in [0, \text{duration\_ns}]$.

    This is the simplest waveform type, useful for testing and basic
    pulse sequences where pulse shaping is not required.

    See Also
    --------
    GaussianWaveform : For shaped pulses with smooth edges
    """

    duration_ns: int
    amplitude: float
    waveform_type: Literal["Constant"] = "Constant"

    def show(self):
        return f"ConstantWaveform(duration_ns={self.duration_ns}, amplitude={self.amplitude})"


@dataclass
class LinearRampedWaveform(Showable):  # pragma: no cover
    duration_ns: int
    start_amplitude: float
    amplitude: float  # end amplitude
    waveform_type: Literal["LinearRamped"] = "LinearRamped"

    def show(self):
        return (
            f"RampedWaveform(duration_ns={self.duration_ns}, "
            f"start_amplitude={self.start_amplitude}, amplitude={self.amplitude})"
        )


@dataclass
class GaussianWaveform(Showable):  # pragma: no cover
    r"""
    A Gaussian-shaped pulse waveform.

    Gaussian pulses provide smooth edges that minimize spectral leakage
    and reduce transitions to unwanted energy levels in quantum systems.

    Attributes
    ----------
    duration_ns : int
        Total duration of the waveform in nanoseconds. Must be positive.
        The pulse is centered at `duration_ns / 2`.
        Typical values: 20-100 ns.
    amplitude : float
        Peak amplitude of the Gaussian pulse. Dimensionless, typically
        normalized in the range [0, 1]. Common values: 0.1-0.4.
    sigma : float
        Standard deviation of the Gaussian envelope in nanoseconds.
        Controls the width of the pulse. For well-contained pulses,
        use $\sigma < \text{duration\_ns} / 4$.
        Typical values: 5-20 ns.
    waveform_type : Literal["Gaussian"]
        Type discriminator for serialization.

    Notes
    -----
    The waveform is mathematically defined as:

    $$f(t) = A \cdot \exp\left(-\frac{(t - t_{\text{center}})^2}{2\sigma^2}\right)$$

    where $A$ is the amplitude, $t_{\text{center}} = \text{duration\_ns} / 2$ is the pulse center,
    $\sigma$ is the standard deviation and $t \in [0, \text{duration\_ns}]$.

    The pulse is automatically centered within the duration window.

    See Also
    --------
    DragCosineWaveform : For DRAG pulses with leakage suppression
    GaussianFlattopWaveform : For flat-top pulses with Gaussian ramps
    """

    duration_ns: int
    amplitude: float
    sigma: float
    waveform_type: Literal["Gaussian"] = "Gaussian"

    def show(self):
        return (
            f"GaussianWaveform(duration_ns={self.duration_ns}, "
            f"amplitude={self.amplitude}, sigma={self.sigma})"
        )


@dataclass
class DragCosineWaveform(Showable):  # pragma: no cover
    r"""
    A DRAG (Derivative Removal by Adiabatic Gate) pulse with cosine envelope.

    DRAG pulses suppress leakage to higher energy levels in multi-level quantum
    systems by adding a quadrature component proportional to the derivative of
    the in-phase component.

    Attributes
    ----------
    duration_ns : int
        Total duration of the waveform in nanoseconds, including buffers.
        Must be positive. Typical values: 20-100 ns.
    amplitude : float
        Peak amplitude of the in-phase component. Dimensionless, typically
        normalized in the range [0, 1]. Common values: 0.1-0.4.
    drag : float
        DRAG coefficient that scales the quadrature component.
        Often calculated as $\alpha = 1 / \Delta$ where $\Delta$ is the
        anharmonicity of the qubit. Typical values: small values around 0-0.1.
    buffer_ns : int
        Time reserved at the start and end of the pulse in nanoseconds.
        The buffer regions are padded with zeros for smooth transitions.
        Must satisfy `buffer_ns < duration_ns / 2`. Typical value: 2 ns.
    center : float
        Time at which the waveform is centered in nanoseconds.
        Typical value: `duration_ns / 2` for symmetric pulses.
        Can be adjusted for asymmetric pulse profiles.
    waveform_type : Literal["DragCosineWaveform"]
        Type discriminator for serialization.

    Notes
    -----
    The effective gate duration is $T_g = \text{duration\_ns} - 2 \cdot \text{buffer\_ns}$.

    The in-phase component is:

    $$I(t) = A \cdot \frac{1 - \cos\left(\frac{2\pi(t - t_c + T_g/2)}{T_g}\right)}{2}$$

    The quadrature component is the scaled derivative:

    $$Q(t) = \frac{0.5 \alpha A}{T_g} \cdot \sin\left(\frac{2\pi(t - t_c + T_g/2)}{T_g}\right)$$

    where $A$ is the amplitude, $\alpha$ is the DRAG coefficient, $t_c$ is the center time,
    $T_g$ is the effective gate duration, and $t \in [\text{buffer\_ns},
    \text{duration\_ns} - \text{buffer\_ns}]$.

    The buffer regions at the start and end are padded with zeros.

    See Also
    --------
    GaussianWaveform : For simple Gaussian-shaped pulses
    """

    duration_ns: int
    amplitude: float
    drag: float
    buffer_ns: int
    center: float
    waveform_type: Literal["DragCosineWaveform"] = "DragCosineWaveform"

    def show(self):
        return (
            f"DragCosineWaveform(duration_ns={self.duration_ns}, amplitude={self.amplitude}, "
            f"drag={self.drag}, buffer_ns={self.buffer_ns}, center={self.center})"
        )


@dataclass
class GaussianFlattopWaveform(Showable):  # pragma: no cover
    r"""
    A flat-top pulse with Gaussian ramps.

    This waveform combines a constant-amplitude plateau with smooth Gaussian
    ramps at the start and end. It provides robustness to timing errors while
    maintaining smooth transitions.

    Attributes
    ----------
    flat_top_duration_ns : float
        Duration of the constant-amplitude plateau in nanoseconds.
        Must be positive. This is the primary "on" time of the pulse.
        Typical values: 20-50 ns.
    ramp_duration_ns : float
        Duration of each Gaussian ramp (both up and down) in nanoseconds.
        Must be positive. Typical values: 10-30 ns.
    sigma : float
        Standard deviation of the Gaussian ramps in nanoseconds.
        Controls the smoothness of the transitions.
        For well-contained ramps, use $\sigma < \text{ramp\_duration\_ns} / 2$.
        Typical values: 5-15 ns.
    amplitude : float
        Peak amplitude of the plateau. Dimensionless, typically
        normalized in the range [0, 1]. Common values: 0.1-0.4.
    waveform_type : Literal["GaussianFlattopWaveform"]
        Type discriminator for serialization.

    Notes
    -----
    The total duration is
    $T_{\text{total}} = \text{flat\_top\_duration\_ns} + 2 \cdot \text{ramp\_duration\_ns}$.

    The waveform has three regions:

    1. **Ramp-up** ($t \in [0, T_{\text{ramp}}]$):

    $$f(t) = A \cdot \exp\left(-\frac{(t - T_{\text{ramp}})^2}{2\sigma^2}\right)$$

    2. **Flat-top** ($t \in [T_{\text{ramp}}, T_{\text{ramp}} + T_{\text{flat}}]$):

    $$f(t) = A$$

    3. **Ramp-down** ($t \in [T_{\text{ramp}} + T_{\text{flat}}, T_{\text{total}}]$):

    $$f(t) = A \cdot \exp\left(-\frac{(t - T_{\text{ramp}} - T_{\text{flat}})^2}{2\sigma^2}\right)$$

    where $A$ is the amplitude, $T_{\text{ramp}}$ is `ramp_duration_ns`,
    $T_{\text{flat}}$ is `flat_top_duration_ns`, and $\sigma$ is the standard deviation.

    This waveform type is robust to timing errors because the flat-top region
    provides tolerance for gate execution timing variations.

    See Also
    --------
    ConstantWaveform : For simple rectangular pulses
    GaussianWaveform : For smooth Gaussian pulses without flat-top
    """

    flat_top_duration_ns: float
    ramp_duration_ns: float
    sigma: float
    amplitude: float
    waveform_type: Literal["GaussianFlattopWaveform"] = "GaussianFlattopWaveform"

    def show(self):
        return (
            f"GaussianFlattopWaveform(flat_top_duration_ns={self.flat_top_duration_ns}, "
            f"ramp_duration_ns={self.ramp_duration_ns}, sigma={self.sigma}, "
            f"amplitude={self.amplitude})"
        )


Waveform = Annotated[
    ConstantWaveform
    | LinearRampedWaveform
    | GaussianWaveform
    | DragCosineWaveform
    | GaussianFlattopWaveform,
    Discriminator("waveform_type"),
]

T = TypeVar("T", bound=Waveform)


def update_amplitude(waveform: T, amplitude: float) -> T:
    """
    Update the amplitude of a waveform.
    """
    return replace(waveform, amplitude=amplitude)
