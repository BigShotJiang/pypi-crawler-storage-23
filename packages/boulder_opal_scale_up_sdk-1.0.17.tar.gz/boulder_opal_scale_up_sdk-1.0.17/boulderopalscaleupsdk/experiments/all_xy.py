# Copyright 2025 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from typing import Literal

from pydantic import PrivateAttr

from .common import Experiment
from .waveforms import ConstantWaveform


class AllXY(Experiment):
    """
    AllXY experiment class for running the AllXY calibration protocol on a transmon qubit.

    This experiment applies a sequence of gate pairs to the specified transmon and measures
    the resulting state.
    It is commonly used to diagnose and calibrate single-qubit gate errors.

    Attributes:
    -----------
    transmon : str
        Identifier for the transmon qubit to be calibrated.
    recycle_delay_ns : int
        Delay time (in ns) between shots to allow the qubit to relax. Default is 100,000 ns.
    shot_count : int
        Number of measurement shots per gate pair. Default is 500.
    measure_waveform : ConstantWaveform or None, optional
        The waveform to use for the measurement pulse.
        Defaults to the measurement defcal.
    update : "auto" or "off" or "prompt", optional
        How the device should be updated after an experiment run. Defaults to auto.
    """

    _experiment_name: str = PrivateAttr("all_xy")

    transmon: str
    recycle_delay_ns: int = 200_000
    shot_count: int = 500
    measure_waveform: ConstantWaveform | None = None
    update: Literal["auto", "off", "prompt"] = "auto"
