# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

import re
from abc import abstractmethod
from dataclasses import dataclass
from typing import Annotated, ClassVar, Generic, Literal, Protocol, TypeVar

from pydantic import AfterValidator, AnyUrl, BaseModel, UrlConstraints

# ------------
# Port address
# ------------


class Address(Protocol):
    @abstractmethod
    def to_uri(self) -> str:
        raise NotImplementedError


@dataclass
class QBLOXClusterAddr:
    name: str
    host: str | None = None
    port: int | None = None

    def to_uri(self) -> str:
        host_str = ""
        if self.host:
            host_str += f"@{self.host}"
            if self.port:
                host_str += f":{self.port}"
        return f"qblox://{self.name}{host_str}"


# TODO: Add module address.


@dataclass
class QBLOXPortAddr:
    cluster: QBLOXClusterAddr
    slot: int
    direction: Literal["in", "out"]
    port_id: int

    def to_uri(self) -> str:
        direction = "I" if self.direction == "in" else "O"
        return f"{self.cluster.to_uri()}/{self.slot}/p{direction}{self.port_id}"


@dataclass
class QmControllerAddr:
    name: str
    type: Literal["opx", "opx1000"]
    host: str | None = None
    port: int | None = None

    def to_uri(self) -> str:
        host_str = ""
        if self.host:
            host_str += f"@{self.host}"
            if self.port:
                host_str += f":{self.port}"
        return f"{self.type}://{self.name}{host_str}"


@dataclass
class OPXPortAddr:
    controller: QmControllerAddr
    port_id: int

    def to_uri(self) -> str:
        return f"{self.controller.to_uri()}/a{self.port_id}"


# TODO: Add FEM address.


@dataclass
class OPX1000PortAddr:
    controller: QmControllerAddr
    fem_id: int
    port_id: int

    def to_uri(self) -> str:
        return f"{self.controller.to_uri()}/fem{self.fem_id}/{self.port_id}"


PortAddr = QBLOXPortAddr | OPXPortAddr | OPX1000PortAddr


# --------
# Port URI
# --------


_A = TypeVar("_A", bound=Address)


class BaseUri(AnyUrl, Generic[_A]):
    """
    Base class for the URI for each controller type.

    Each subclass should have a unique `cls.scheme` identifying the controller type
    and a `cls._regex_pattern` that shows how to parse the rest of the URI. The full
    port URI will have the form:
    `(cls.scheme)://(actual_name)@(actual_host):port/(_path_pattern)`

    You must also provide a `unmarshal` method that provides the corresponding
    Address dataclass for a given URI.
    """

    _path_pattern: ClassVar[str]

    def __init_subclass__(cls, schemes: list[str]) -> None:
        cls._constraints = UrlConstraints(allowed_schemes=schemes)

    @property
    def actual_name(self) -> str:
        if self.username is not None:
            return self.username
        return self.host or ""

    @property
    def actual_host(self) -> str | None:
        return self.host if (self.username is not None) else None

    def match_regex(self) -> list[str]:
        """
        Matches the path against the `_regex_pattern` and returns the matched groups.
        """
        path = self.path or "/"
        if not (result := re.match(self._path_pattern, path)):
            raise ValueError(
                f"Path {path} does not match the regex pattern {self._path_pattern}.",
            )
        return [str(v) for v in result.groups()]

    @abstractmethod
    def unmarshal(self) -> _A:
        raise NotImplementedError


def _validate_with_regex(v: BaseUri) -> BaseUri:
    v.match_regex()
    # cannot have a port without host
    if v.port and (not v.actual_host):
        raise ValueError("Name not defined in the URI.")
    return v


PortUriValidator = AfterValidator(_validate_with_regex)


class _QBLOXClusterUri(BaseUri[QBLOXClusterAddr], schemes=["qblox"]):
    _path_pattern = r"^/$"

    def unmarshal(self) -> QBLOXClusterAddr:
        return QBLOXClusterAddr(
            self.actual_name,
            self.actual_host,
            self.port,
        )


QBLOXClusterUri = Annotated[_QBLOXClusterUri, PortUriValidator]


# TODO: Add module URI class.


class _QBLOXPortUri(BaseUri[QBLOXPortAddr], schemes=["qblox"]):
    _path_pattern = r"^/([\d]+)/p([IO])([\d]+)$"

    def unmarshal(self) -> QBLOXPortAddr:
        args = self.match_regex()
        return QBLOXPortAddr(
            cluster=QBLOXClusterAddr(self.actual_name, self.actual_host, self.port),
            slot=int(args[0]),
            direction=("in" if args[1] == "I" else "out"),
            port_id=int(args[2]),
        )


QBLOXPortUri = Annotated[_QBLOXPortUri, PortUriValidator]


class _QmControllerUri(BaseUri[QmControllerAddr], schemes=["opx", "opx1000"]):
    _path_pattern = r"^/$"

    def unmarshal(self) -> QmControllerAddr:
        match self.scheme:
            case "opx":
                return QmControllerAddr(
                    self.actual_name,
                    "opx",
                    self.actual_host,
                    self.port,
                )
            case "opx1000":
                return QmControllerAddr(
                    self.actual_name,
                    "opx1000",
                    self.actual_host,
                    self.port,
                )
            case _:
                raise ValueError("Invalid scheme for QM.")


QmControllerUri = Annotated[_QmControllerUri, PortUriValidator]


class _OPXPortUri(BaseUri[OPXPortAddr], schemes=["opx"]):
    _path_pattern = r"^/a([\d]+)$"

    def unmarshal(self) -> OPXPortAddr:
        args = self.match_regex()
        return OPXPortAddr(
            controller=QmControllerAddr(self.actual_name, "opx", self.actual_host, self.port),
            port_id=int(args[0]),
        )


OPXPortUri = Annotated[_OPXPortUri, PortUriValidator]


# TODO: Add FEM URI class.


class _OPX1000PortUri(BaseUri[OPX1000PortAddr], schemes=["opx1000"]):
    _path_pattern = r"^/fem([\d]+)/([\d]+)$"

    def unmarshal(self) -> OPX1000PortAddr:
        args = self.match_regex()
        return OPX1000PortAddr(
            controller=QmControllerAddr(self.actual_name, "opx1000", self.actual_host, self.port),
            fem_id=int(args[0]),
            port_id=int(args[1]),
        )


OPX1000PortUri = Annotated[_OPX1000PortUri, PortUriValidator]


PortUri = QBLOXPortUri | OPXPortUri | OPX1000PortUri
ClusterUri = QmControllerUri | QBLOXClusterUri
AllUris = PortUri | ClusterUri


# -----------
# Connections
# -----------

# TODO: This connections config schema is work in progress.
#       Remove this TODO notice after the schema is stable and ready for use.


class AcquisitionSource(BaseModel):
    mode: Literal["acquisition"] = "acquisition"
    acq_port: PortUri


class DCSource(BaseModel):
    mode: Literal["DC"] = "DC"
    dc_port: PortUri


class IQSource(BaseModel):
    mode: Literal["IQ"] = "IQ"
    i_port: PortUri
    q_port: PortUri


class TeeSource(BaseModel):
    mode: Literal["tee"] = "tee"
    dc_source: DCSource
    iq_source: IQSource


ConnectionSource = AcquisitionSource | DCSource | IQSource | TeeSource


class Connection(BaseModel):
    """
    Configuration information for one connection between a QPU port and the primary
    system in the control stack.

    Note that each QPU port can connect to multiple ports in the control stack,
    represented here by the `source`.

    Attributes
    ----------
    signal_type : str
        Either `"RF"` or `"DC"`.
    direction : str
        Either `"out"` or `"in"`, from the point of view of the QPU.
    source : ConnectionSource
        Information about all the port in the primary system of the control stack that
        connect to this port in the QPU.
    delay_ns : int | None
        The amount of nanoseconds it takes for a signal to travel across this connection.
        Defaults to None, in which case it is assumed to be unknown.
    """

    signal_type: Literal["RF", "DC"]
    direction: Literal["in", "out"]
    source: ConnectionSource
    delay_ns: int | None = None


class ConnectionInfo(BaseModel):
    """
    Configuration information for the connections between the QPU ports and the primary
    systems in the control stack.

    Each key of the dictionary should correspond to the name of the corresponding QPU port.
    """

    connections: dict[str, Connection]
