# Boulder Opal Scale Up SDK

The Boulder Opal Scale Up SDK package is a Python SDK for Q-CTRL Boulder Opal Scale Up. Scale Up provides a tailored solution to characterize and calibrate quantum hardware.
