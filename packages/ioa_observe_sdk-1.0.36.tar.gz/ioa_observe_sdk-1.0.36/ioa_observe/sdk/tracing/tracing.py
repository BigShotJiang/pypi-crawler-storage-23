# Copyright AGNTCY Contributors (https://github.com/agntcy)
# SPDX-License-Identifier: Apache-2.0

import atexit
import contextlib
import json
import logging
import os
import re
import threading
import time
import uuid

from colorama import Fore
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http import Compression
from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
    OTLPSpanExporter as HTTPExporter,
)
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
    OTLPSpanExporter as GRPCExporter,
)
from opentelemetry.metrics import Observation
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider, SpanProcessor
from opentelemetry.propagators.textmap import TextMapPropagator
from opentelemetry.propagate import set_global_textmap
from opentelemetry.sdk.trace.export import (
    SpanExporter,
    SimpleSpanProcessor,
    BatchSpanProcessor,
)
from opentelemetry.trace import (
    get_tracer_provider,
    ProxyTracerProvider,
    SpanContext,
    TraceFlags,
    NonRecordingSpan,
)
from opentelemetry.context import get_value, attach, set_value
from opentelemetry.trace import set_span_in_context
from opentelemetry.instrumentation.threading import ThreadingInstrumentor
from opentelemetry.metrics import get_meter
from ioa_observe.sdk.metrics.agents.agent_connections import connection_reliability
from opentelemetry.semconv_ai import SpanAttributes
from ioa_observe.sdk import Telemetry
from ioa_observe.sdk.instruments import Instruments
from ioa_observe.sdk.tracing.content_allow_list import ContentAllowList
from ioa_observe.sdk.tracing.transform_span import (
    transform_json_object_configurable,
    validate_transformer_rules,
)
from ioa_observe.sdk.utils import is_notebook
from ioa_observe.sdk.client import kv_store

from ioa_observe.sdk.utils.const import (
    OBSERVE_WORKFLOW_NAME,
    OBSERVE_ASSOCIATION_PROPERTIES,
    OBSERVE_ENTITY_NAME,
    OBSERVE_PROMPT_TEMPLATE_VARIABLES,
    OBSERVE_PROMPT_TEMPLATE,
    OBSERVE_PROMPT_VERSION_NAME,
    OBSERVE_PROMPT_VERSION,
    OBSERVE_PROMPT_KEY,
    OBSERVE_PROMPT_VERSION_HASH,
    OBSERVE_PROMPT_MANAGED,
    OBSERVE_ENTITY_OUTPUT,
)
from ioa_observe.sdk.utils.package_check import is_package_installed
from typing import Callable, Dict, Optional, Set

TRACER_NAME = "ioa.observe.tracer"
APP_NAME = ""

SESSION_IDLE_TIMEOUT_SECONDS = 300  # e.g. 5 minutes
SESSION_WATCHER_INTERVAL_SECONDS = 30
MAX_PROCESSED_SPANS_SIZE = 100000  # Maximum size before cleanup


def determine_reliability_score(span):
    if "observe.entity.output" in span.attributes:
        current_agent = span.attributes["observe.workflow.name"]

        span_entity_output = span.attributes[OBSERVE_ENTITY_OUTPUT]
        # Check if the output is a dictionary
        # and contains the "goto" key
        try:
            parsed = json.loads(span_entity_output)
        except (ValueError, SyntaxError):
            # If parsing fails, it might be a string or other type
            parsed = span_entity_output
        if isinstance(parsed, dict) and "goto" in parsed:
            next_agent = parsed["goto"]

            # Record successful connection
            if next_agent and (next_agent != "__end__" or next_agent != "None"):
                reliability = connection_reliability.record_connection_attempt(
                    sender=current_agent, receiver=next_agent, success=True
                )
                span.set_attribute(
                    "gen_ai.ioa.agent.connection_reliability", reliability
                )
        else:
            parsed = json.loads(span_entity_output)
            if "__str_representation__" in parsed:
                inner = parsed["__str_representation__"]
                # Use regex to find can_handoff_to field
                match = re.search(r"can_handoff_to=([^\s]+)", inner)
                if match:
                    next_agent = match.group(1)

                    # Record successful connection
                    if next_agent and (next_agent != "__end__" or next_agent != "None"):
                        reliability = connection_reliability.record_connection_attempt(
                            sender=current_agent, receiver=next_agent, success=True
                        )
                        span.set_attribute(
                            "gen_ai.ioa.agent.connection_reliability", reliability
                        )


class TracerWrapper(object):
    resource_attributes: dict = {}
    enable_content_tracing: bool = True
    endpoint: str = None
    app_name: str = None
    headers: Dict[str, str] = {}
    __tracer_provider: TracerProvider = None
    __disabled: bool = False

    def __new__(
        cls,
        disable_batch=False,
        processor: SpanProcessor = None,
        propagator: TextMapPropagator = None,
        exporter: SpanExporter = None,
        should_enrich_metrics: bool = True,
        instruments: Optional[Set[Instruments]] = None,
        block_instruments: Optional[Set[Instruments]] = None,
        image_uploader=None,
    ) -> "TracerWrapper":
        if not hasattr(cls, "instance"):
            obj = cls.instance = super(TracerWrapper, cls).__new__(cls)
            if not TracerWrapper.endpoint:
                return obj

            # session activity tracking: {session_id: (last_activity_time, trace_id)}
            obj._session_last_activity: dict[str, tuple[float, int]] = {}
            obj._session_lock = threading.Lock()
            # Track sessions that have already been ended to prevent duplicates
            obj._ended_sessions: set[str] = set()
            obj._ended_sessions_lock = threading.Lock()
            obj.__image_uploader = image_uploader
            # {(agent_name): [success_count, total_count]}
            obj._agent_execution_counts = {}
            obj._agent_execution_counts_lock = threading.Lock()
            # Track spans that have been processed to avoid duplicates
            obj._processed_spans = set()
            obj._processed_spans_lock = threading.Lock()
            TracerWrapper.app_name = TracerWrapper.resource_attributes.get(
                "service.name", "observe"
            )
            obj.__resource = Resource(attributes=TracerWrapper.resource_attributes)
            obj.__tracer_provider = init_tracer_provider(resource=obj.__resource)
            if processor:
                Telemetry().capture("tracer:init", {"processor": "custom"})
                obj.__spans_processor: SpanProcessor = processor
                obj.__spans_processor_original_on_start = processor.on_start
                obj.__spans_processor_original_on_end = processor.on_endmracerWrapper.resource_attributes)
         icense-Identifier: Apache-2.0(r"ciapper.resource_attris:
       .tributes)
l2.0(r"ciapper.res                        _tran   pans_processor:S_k_             yi.oat, in)I   }1751 00000001661 Asor,
)
from opent   _fTlia.oon_io[[ kv_store.set in)I   }1751 00xt for injectin
      _processor:Ss)
l        yi.oat, in)In    . objk
clm    y


_    fne,   .__                             > bool:
        
from opent    O   r(f         y


_    fne,   .__      l     f"{beparent")
    
tity_output
   _original_e         y


_    fne,   .5=iWeen endedy    2l          #l     f"{beparen:`[gate import set_gl                                                 # Tracing/conte]on_io[[ kv_store.sc-cendeMs./@PaxHeng.content_allow_list impl.keaftL   (/conte .__                  mpl.keaftL   Ms./@PaxHeng.content_allow_list im13  x       cerWrapper.endpoint:
      OTLPSpanExporter as HTTPExporter,
)
from opentelemetry.exporter.otlp.proto.grpc.tractu:
      OT)"t          :cer__liabil)snal_e         y


_    fne,   .5      y_outptlp.protemeT_TEMPLAuploader = image_uploader
Eg.content_allow_list im13  x 
from opent    O   r(f         y


_    fne,   .__ al[Set[Instruments]] = None,
        image_uploader=None   O                                                                                                                                                                                                                 ioa_observe_sdk-1.0.36/ioa_observe/sdk/tracing/     eMs./@PaxHeng.contk)

   l#_original_on_start = proces                 next_ageAttributes.LLM_PROMPTS}.{ieT_TEMPLAuploader = image_uploadeng.content_allowst
f_provider: Tracer1PLAupload    d.36/ioa_observe/sdk/tracing/     eMs./@PaxHeng.contk              4r.]uplicates
 )iakmport is)bility = connection_reliability.reoolprovidedk/tr.upd         imaBh                = connection_    )
                span.set_attridg.content_allowstation
from opentelem = threadook
from ioa_observe.sdk.client import kv_store

ve.sdk.tthreadook
from ioa_observe.sdkort kv_store

ve.sg     ection_re)                span.set_attri"     ession_id(sessio    /sdk/tracing/     eMs./@Pa( h D \t _4Pydk/tr.upd             i ioa_observe.sdk.instruments import Instruments
from ioa_observe.sdk.tracing.content_allow_list import ContentAllowLi,tntentustruments]] = None,
        it ContentAllowLi,tntentustruments]] = None,
     (ioa_tntentustr01@             list      ,tntentustrutt ContePs import Ins5es.get(                                 +representation__" in parsAn_attempt(
                            sender=current_agent, receiver=next_agent, success=True
                        )
         r as )low_list =            u _fTlia.oon_io[[ kv_store.set in) =            u _fTlia.oon_io[[ kv_store.set in) Inst
   a          io[[ kv_store.set in) In, suc(ore.set in) Inst
     io[[_EMPLATE,
    p    1D,
    OLt          u c)
        (f_m.y(nammaic6,,,      runner                        u _fTlia.oon_io[[ kv_sto     0   n parsAn_attempt(   io[[ kvrw_sto  dsbility.reool   0           , SyntaxError):
            # If p[[ kvrw_sto  dsbil  dsbility.reooa                   c_stopanPrsession_id and sefTlsto and sefTlstpanProcessor
from opent=None  .0.36/ioa_observe/sdk/tracing/     eMs./@PaxHeng.contk)

   l#_original_on_start = proces                 next_ageAttributes.L5ie                      next_afobserve/sdk/t5es.get(          (     _ue.sdk.k     [tance(parsed, dict) and "goto" in parsed:
  ibutors (https://gith "goto" i.i_       y"     1oto" in parsed:
    , Syntaeng.conto" i      dom o_ng.conto    OBSERVE_PROMP@Pa( h D \t _4write(new_anon_id)
               __iduans_prc
Dte]on_eturd_rs (https://gipts]] = None,
     (ioa_tntentustr01@             list                    :ageAttributes.L5ie                      next_afo: essful o-Inst     l)
        fto  dntifi sefTle     r as )low_list =sdk.tracing.ng/     eMs./@PaxHeng.contk)

   l#_bj._session_last    # semesste]on_eturd_rs (    io   ._gaugeridg.content_allowstationtentustr01@             sion_last    # semess     next_afobserve/sdk/t5es.getS   # s messtoce_id")  sion_lasbility.reoolprovidedk/tr.upd         imaBhr["sesllbacks=[             bj._session_last    # semess]arsed, dict) and "goto" in p# Trac        e(self, event: str,emetry.exporter.(rac       )r: TextMapPropagthttg.ck   sre
if aglast_ageniom opentel)
 so waderways waagenr(f         y
elemetry.propagate imders(opagate ()r: TextMapProps(opagate _r,e._agent_port TextMapProsre(self, event: str       )


class Tra         imaBhr["sndpoint:
              imaBhr["sn = None
           imaBhr["sng: bool = True
 ,
rocessor:S_k_             y       s(opagate _r,e e(self, event: stprininner = parsed["__str_r    .RED + "WarnxportNoimportsn = None
  tr,e. Remo   'n = None
 ' "       parsed = span_eargone
 36/iusaderlsn = None
   o   r,e.aimportsn = None
 ."om opent    O   r(f         y


_  prinin    .RESET)ploader = image_uplontext import get_va=ttach, set_value
()r: TextMapPropagow_lisbacktribnstwow_lntof   r,or = Nobj.__resource =im13  ute(Sck_instrwow_lnt()r: TextMapPropag   ce             debugNobvironne
  t(RVE_Eg: al developmkey, value)

header7  0ne,gue
nectio.7  0=currle )r: TextMap               # Copyright AG  ute(Sck_instrwow_lnt(    , strt    e(self, et      obj._enelemetnner = parsed[ute   =       k_instrwow_lnt_loop,
rocessor:S_kstatio   - k_inst-wow_lntd         imaBhdaemon=r(object):
   nt trace coibute(()pyright AG  k_instrwow_lnt_loop(    , strt    e(self, ewhile r(ob e(self, eventto  .sleep(,
    OBSERVE_PROMPT_TEMPLATE_VA, value)

headnow    o  . o  sessions: set[sexpir_agents: Optional[Set[Instruments]] = : TextMapPropag eliairle        imreadoomo   : emget("t= True,
        instru              n.se       k_instrd headers to yUEST_MODEL, value):
    ter =    ohould_enrent et_vn_entity_output)
            k_instrd      instrullowList":
        if notent")
    
tity_output
     w - er =    > SERVE_ASSOCIATION_PROPERTIESspan_entity_output)
      expir_a[value):
  ts]]ter =    ohould_enrpan_entity_output)
      del        k_instrd      instru[value):
  t : TextMapPropagPeriontsON_NAME,toceck = threa      oracerWrappunbibnsreamomory triwth.: TextMapPropagWessvent  Optil/sd._selfsn = mettoceN_NAp


d # Rrely so obj.: TextMapPropagContntly-ck = threa     IDimrres tirlsTCY ATEreaby  Optsre)
      = Nlogic.              n.se      nt duplicates
      ource(attributes=Traclen(      nt duplicates
 ) > S,
    OBSERVE_PROMPT_TEspan_entity_output)
  sventgoto" .{seen(      nt duplicates
 ) // 2pan_entity_output)
  t  oomo   ready been ended to UEST_MODEL, m,ext impofor idx, messa      nt duplicates
 )span_entity_output)
      utpu >= sventgoto" :ier: Apache-2.0(r"ciapper.resbemekier: Apache-2.0(r"ciappert  oomo      (xt impo)_entity_output)
           ons that have al-=rt  oomo   : TextMapPropagPeriontsON_NAME,toce) -> "       imaracerWrappunbibnsreamomory triwth              n.se       super(TracerWrappeource(attributes=Traclen(       super(TracerW) > S,
    OBSERVE_PROMPT_TEspan_entity_output)
         super(TracerW.N_NAp(_             y       expir_ag        imaBhr["seachinu  : TextMapProp last_age        if last_agSPANS_SIZE = 100temesstoveifi snapr  threaddo *   *.LLMify `expir_a`for ts imoop
to yUEST_MODEL, value):
    ter =    ohould_enrent et_vnexpir_allowList)span_entity_outputable, Dict, Ois r,or = Nhasder=None,
    ) -> "TracerWrapper":
        if not has     n.se       super(TracerWrappeource(attributes=Ttry context for i

# Managecls, "instance"ier: Apache-2.0(r"ciappereachinu  an_entity_output)
         super(TracerW.   (xgage.get_bapan_entity_outputabld_rs fi d)
    ast_agentclienhes t   dohould_en"Trakeepntext fo  li bnsrrenhes                    y


_  paributes.Lmetry.pr   .ry.metricsn_entity_output)
     hould_en= attach


ch = re.search(r"can_han_en=0,ity = co0ensewaddon'_uploaden_heciftsOd)
                f"{Spes=Ttry cs oomote                utput)
     hould_frvat=t Observat(t Observat.SAtes.D),om opent    O   r(f         y


_  paributes.LT)"t  opentelemetry(paributes.Lmetry.pr(f         y


_  paributetry.pr   om opentelemetry.pr(paributes.Lbapan_entity_outputan.set_attribute(SpanAttributes.LL       parsed = span_etext fo  li"t_from_heapaributetry.prom opent    O   r(
        for idx, compch(r"can_handoff_to=([^\s]+etext fo      nt()
        TraceContexy_outputa                   mport("              )urce(attributes=Ttry con             :  match = re.search(r"can_handoff_to=([^\s]+lemetry.semconv_ai impn             )for idx, compch(r"can_handoff_to=([^\s]+etext fo  supera    er =   agSPANS_SIZE = 10ensre
i li ave alrres       adook
frably fr =         )
               yright AG7  0=currle (    ,:E = "ioa.obemiti li ave alntifiny        image_uneveifw.agend           now    o  . o  sessions: s last_age        if last_agSPANS_SIZ n.se       k_instrd headers to yUESToomainxpor(TracerWagents:(       k_instrd      instru          )
         k_instrd      instrulN_NAp(_          EL, value):
    t_ ohould_enrent oomainxpor(TracerWllowList_SPANS_SIZE = 10le, Dict, Ois r,or = Nhasder=None,
    ) -> "TracerWrapper":
        if not has n.se       super(TracerWrappeource(attributes=Tractext for i

# Managecls, "instance"ier: Apache-2.0(r"ciaeachinu  an_entity_output       super(TracerW.   (xgage.get_bapan_entity_ouabld_rs fi d)
    ast_agentclienhes t   dohould_en"Trakeepntext fo  li bnsrrenhes                    y

paributes.Lmetry.pr   .ry.metricsn_entity_output)
 hould_en= attach


ch = re.search(r_han_en=0,ity = co0ensewaddon'_uploaden_heciftsOd)
                f"{Spes=Tcs oomote                utput)
 hould_frvat=t Observat(t Observat.SAtes.D),om opent    O)
     y


_  paributes.LT)"t  opentelemetry(paributes.Lmetry.pr(f         y

paributetry.pr   om opentelemetry.pr(paributes.Lbapan_entity_ouan.set_attribute(SpanAttributes.LL       parsed = setext fo  li"t_from_heapaributetry.prom opent    O(
        for idx, compch(r_handoff_to=([^\s]+etext fo      nt()
        TraceContexy_oua                   mport("              )urce(attributes=Tcon             :  match = re.search(r_handoff_to=([^\s]+lemetry.semconv_ai impn             )for idx, compch(r_handoff_to=([^\s]+etext fo  supera    nowbapan_entit             yright AG  x 
from opent    O   re-Identifie,
paributetry.prt_SPANS_SIZa                   mport("              )urce(attrcon             niom    t    e(self, ech(r_handoff_to=([^\s]+lemetry.semconv_ai impn             )fders.
    """
    _glo    mport("text fo    )
ibutes=Tractext for i

om    t    e(self, ech(r_handoff_to=([^\s]+etext fo      nt()
       process propaga _glo    mport("ropaga _ )
ibutes=Tracropaga _g
om    t    e(self, ech(r_handoff_to=([^\s]+eropaga _ ,cropaga _  process prp
      = a _glo    mport("rp
      = a _ )
ibutes=Tracrp
      = a _g
om    t    e(self, ech(r_handoff_to=([^\s]+erp
      = a _ ,crp
      = a _ span_id, traccs         BSERVE_PROMPan_entit     /ioa_observe/sdk.   (1ry.sd, total_rt is_package_i)ve.sdk.utils.pdoff_to=([^\s]+eom ibute(SeAttri  o  . o  se) "gen_ai.ioaw_lis     process prector embeddings, etcglo    mport("rector embeddings, etc )
ibutes=Tracrector embeddings, etcg
om    t    e(self, ech(r_off_tector embeddings, etcj._agent_ex(ifie,
tector embeddings, etc_             y            _agent != "__end__" or urce(attributes=Tracte    ontext import get_v.NTCY Contritector embeddings, etc_:  match = re.search(rers):
 s   mport("oveiride__agent != "__end__" or"                                       # Tracing/coers):
 s   mport("oveiride__agent != "__end__" or"   runne span_id, traccs         BSERVE_PROMPan_entit      d_      glo    mport("      d_      _current_context_h      d_      g
om    t    e(self, ech(rch(r_handoff_to=([^\s]+lemetry.configurable,
 h      d_      _             y       keyglo    mport("       key"nd "goto" in p# Trac    keyg
om    t    e(self, ech(rch(r_handoff_to=([^\s]+lemetry.configutranTrac    key_             y       veir = Nlo    mport("       veir = "nd "goto" in p# Trac    veir = N
om    t    e(self, ech(rch(r_handoff_to=([^\s]+lemetry.configurom ioa_Trac    veir = _             y       veir =             mport("       veir =      "nd "goto" in p# Trac    veir =      niom    t    e(self, ech(rch(r_handoff_to=([^\s]+lemetry.configurom ioaai impnrac    veir =      _             y       veir =  hash       mport("       veir =  hash"nd "goto" in p# Trac    veir =  hash iom    t    e(self, ech(rch(r_handoff_to=([^\s]+lemetry.configurom ioaasformTrac    veir =  hash_             y           lesste]    mport("           less"nd "goto" in p# Trac        lesstiom    t    e(self, ech(rch(r_handoff_to=([^\s]+lemetry.configuserve.sdkTrac        less_             y           less mprigentste]    mport("           less mprigents"nd "goto" in p# Trac        less mprigentstiom    t    e(self, ech(rch(rEL, W3CBaggageent aac        less mprigentsllowList_SPANS_SIZE = ch(r"can_handoff_to=([^\s]+)", inner)
              f"{observe.sdk.instruments import In}.{W3C}                        _trlemetr   pans_processor:S_k_          #store _    fne allow_lismethoe coniti xt_vsent lemetrading.Lock()
      racte    or.otlp.proto.grpc.tractu:
      Oate(messages):
     or.otlp.proto.grpc.tractu:
      O(ifie,
paributetry.prt yright AGincoomt imp            e-Identoto" :      sApache-2.0

from cog.contk             .   (ssion a.sd, total_rt is_package_i)ve.sdkd ses]] = None,
        image-Identifie,:E = "ioa.oble, Dict, Ois rs.LThasder=None,
    ck = threading.Lock()
      TracerWrappE = "ioa.obAd-> "ntifi.Lock()
      T     imaguan.se      et_igg      > bool#ntclied_ai.a      @tool, @        rent base.py
search(r_han_enmport isnt_seque

    linking_in n.se      nt duplicates
      ource(attributifext impofor       nt duplicates
 span_entity_outputabTOis rs.LTwasder=None,nt duplicntikipading.Lock()
            # Track tMap      apan_entity_ouabMark, Ois rs.LTa  0        
utput)
           ons that have a    (xt impo)_   > bool#nPropag er =None,
        nt()
     > bool#nSkipatext fo  li       orag.Lockinfgent imoop -enhesadeSION_NAME,      
tMapPropagthattr     m    re-e,gue
neenhes tor = Nosst
    ders.
    """
    _glort is_package_iution.{tracep    )
ibutes=Tractext for i
ali     age_ujson.text fo  li":              n.se       k_instrd headers to yUEST_MOD#nStoresbothnts imp =None,
    to  dali urrent_cter.geor, Ois r,or = 
ty_output)
            k_instrd      instru[value):
  ts]]t         utput)
     ho  . o  se

ch = re.search(r"can_hansnt_seque attach


ch = re.search(r)_   > boolSERVE_PROMPT_VERSION,
    OBSERVE
tMapPropagow_listo  dsbrt is_package_iution.om ibute(SeAttr)_   > bool#nAp
 yopentelemeampleSpaft_agentdprocess prp
 yreadingInsglo    mport("rp
 yreadingIns )
ibutes=Tracrp
 yreadingIns:: TextMapProp laingInstrumentoglo    mport(" laingInstrumento"nd "goto" in p# T laingInstrumento:         utput)
 hoy:                    "geConvei       oragent eor, entelemeample
ch = re.search(r"can_han_gent an          st  nts:(     )
             > bool#nAp
 yopentelemeample         utput)
     houingInst       gent anpentelemetry.instrumentation.threa(  match = re.search(r"can_han gent,T laingInstrumentoas HTTPExporter,
)
from opentelemetry.ebool#nUropag rs.LTwn.set_aingInst  opaa an_entity_output)
        Propag      ne":
nts:(    , houingInst       gent                   RVAL_SERVAL_ = Noss           # Tracing/co       n pars(f"CESSEcrp
 yontext iopentelemeample: {del)          #store _    fne all li methoe coniti xt_vs
ibutes=Trac(  match = re.acerProv-Ident"_             nal_e         y


_    fne,   .5 "nd "goto" in preturn    or.otlp.proto.grpc.tractu:
  obj.__resour)ate(messages):
     or.otlp.proto.grpc.tractu:
  {idxes.Lbapan_et AG  x 
ft  nts:( Identifie,:E = "ioa."""Convei       oragentER_NAM eor, entelemeample.        "can_han_gent an.on_endmracerW"    ":     age_u

ch = re.sear"_package_i": nts:(    s_package_i)tifext is_package_icessor{an   pans_proce"buttui": {       parsed = setuttuintad ":     atuttui.tuttuintad .last_agent_trattributifext i.tuttui
ali     atuttui.tuttuintad                      p_name: str = Nrsed = se/sdk/t5es.g":     atuttui./sdk/t5es.gtifext i.tuttui
    p_name: str = Nrsedan   pans_p}: TextMap       _han_gentapan_et AG Propag      ne":
nts:( Identifie,
     gent :E = "ioa."""Uropag rs.LTwn.set_aingInst  opaa.        "can#nUropag rs.LT    nionitiw):
   ingInst 
ibutes=Trac"    "VERSION__gent ali     _gent["ession.!=     age_u_SPANS_SIZE = 10Dirume yoLLMify urrei/sdkfne     n_package_d "goto" in p# TacerProv-fie,
"     "n e(self, ech(rch(r_hand            _gent["ession
     "can#nUropag _package_icct, Opy were
   ingInst 
ibutes=Trac"_package_i"VERSION__gent:at, int]] = {}
  yoLultiple  p.pr4 15  orauropag rs.LT_package_iat, int]] = {uropagdreceiver=next_ntity_ouabMethoe 1:
  you# Maxoff_to=([^\s]Tracrvaie

fr ali mut

frd "goto" in p# T(  match = re.searacerProv-fie,
"off_to=([^\s] )urce(attributes=Tali acerProv-fie,
"  supe )urce(attributes=Tali      hand  supe
      if notent")
    
tity_outhoy:                    "geC_NApi xt_v Max_package_icby   tv Max: emgorat          :cer__liabin p# TacerProv-fie,
" _package_i")span_entity_output)
      keys_t  oomo   reet_vn hand _package_iukeys()rpan_entity_output)
      EL, W3CVERSkeys_t  oomo  :ier: Apache-2.0(r"ciapper.res_handoff_to=([^\s]+W3CBat   (
                    "geSe_unewT_package_iat, int]] = {ch(rch(rEL, W3CBaggageent     _gent["_package_i"]llowList_SPANS_SIZE = ch(r"can.res_handoff_to=([^\s]+W3CBaggagePr_SIZE = ch(r"can.resuropagdrecandoff_to field
     ERVAL_SE(
    get = 30
MTypeCESSED_SPANS_SIZE =      y

pamanager
ntity_ouabMethoe 2:0DirumeT_package_e   ipulatributes[OBSERVE_ENTI   uropagdnt")
    
tity_outhoy:                    "# TacerProv-fie,
" _package_i")span_entity_output)
       hand _package_iuN_NAp(_ an_entity_output)
       hand _package_iuPropaga    _gent["_package_i"]_ an_entity_output)
      uropagdrecandoff_to field
           # TacerProv-fie,
"_package_i")Tali acerProv an_entity_output)
       hand_package_i,
"N_NAp"       parsed = span_)span_entity_output)
       hand_package_iuN_NAp(_ an_entity_output)
       hand_package_iuPropaga    _gent["_package_i"]_ an_entity_output)
      uropagdrecandoff_to field
     ERVAL_SE(
    get = 30
MTypeCESSED_SPANS_SIZE =      y

pamanager
ntity_ouENTI   uropagdnt")
    
tity_out       nwarnxpo("CanI   LLMify rs.LT_package_i - rs.LTmae,
 panAttizpe )ut")
 @tutticmethoee.sdkd sesm oputtic_paramsre(self, e            if next_agentection_reliagent != "__end__" or next_ection_relia"):
       ection_reltion_reliability.recordct[str, strt    e(self, ecount]}
            obj._agent_ex         obj._agent_exe(self, ecount]}
      iagent != "__end__" or   iagent != "__end__" ore(self, ecount]}
      ia"):
     ia"):
  e(self, ecount]}
      tion_reset(f"execut")
 @rd sumethoee.sdkd seveiify-Liceittizpeble_b strext_acer_provider    =current_ag
# Track tMap      ceiver=next_ntit# TacerProvider = None
    __disabled: bo      candof
ibutes=Trac(oiutioenv("observe.SUPPRESS_WARNINGS")TL, "fiver").Contstr]==ns_pue"g
# Track tMap      ceiver=next_ntitprininner = parsed[    .REDner = parsed[+ "Warnxport            s(ceittizpe,g.ck  sre
iyousesllt       .s(ce()"ect):
   nt trace cprinin    .RESET)pack tMap      ceiver=next_@rd sumethoee.sdkd sesm ourrent_avider urrent_agent, , strt    e(self, e    =current_aagentrent_aapan_et AG          ,:E = "ioa.
     or.otlp.proto.gr.f  ce_        yright AG   if last_    ,:E = "ioa.       _     o                   if last_s.const imp span
       rsed:bj._session_las( Ident obj

    (self,     # sgent, ,:inking_in n.se      bj._session_last_activity: g
# Track tMapime, trac      bj._session_last_activdoff   aultn obj

    , [0, 0]nd "goto" in p# T    # sg        imaBhr["seactiv[0] += 1opago   # s eacti
# Track tMapime, t[1] += 1opagctivi eacti
pan_et AG         bj._session_last    # semess( Ident       ED_SPANS_SIZmeasre
md    d.[]inking_in n.se      bj._session_last_activity: g
# Track tMapntifiobj

    , re(self, event: str   # session t")
    
tity_outhtivity tra,om opent    O)for       bj._session_last_activdlowList_SPANS_SIZE = ch(rmesste](r   # session /thtivity tra)tifehtivity tra > 0
    p0.0tion_attempt(
    easre
md       {idxSPANS_SIZE =      y

extlib
impo(ggage=mess a.sd, total_{"iobj

    ":fiobj

    }rom opent    O   r(f                easre
md   
    OBoff_tector embeddings, etc(dings, etc:utes:
 strt    e(selers):
 s   mport("rector embeddings, etc kTracgs, etc_ span
 # Ars):

tector embeTracgs, etcgoraurreAttributifie,
ionit'et

         tifi taskier: es.LT)"porter   iAttributes.LL)PROMPT_K    mport("              )tiom    t    tif    mport(" # Reco     )tiom    t   _SPANS_SIZ_off_tector embeddings, etcj._agent_ex(ifie,
dings, etc_  
t AG  kf_tector embeddings, etcj._agent_ex(ifie,
dings, etc:utes:
 strt    e(selEL, W3CBaggageent aacgs, etcdlowList_SPANS_SIZ_handoff_to=([^\s]+f"{observe.butes
from ioa_observe}.{W3C}  aggagePr    OBoff_             (             :: str strt    e(selers):
 s   mport("              pn             )_  
t AG next__nt, e    #v( #v mport:: str strext_acer_p        Pext_ nt, e  aggageetclieobvironne
  mprigentanup


.span
 Argsg        i #v mport](rstr, Ebvironne
  mprigentamport]Tracext_span
 R     sg        iext_a Pext_d nt, e  aggagespan
 AcVAL_c:u"0ploa1ploa_pue", "fiver",r] =ue", "eiver"cer_p        aft_av mport.Contstr]nt (a_pue", "1",:E = "ioa.       nt != "Nonlaft_av mport.Contstr]nt (afiver",r]0",:E = "ioa.       eiver=                  rait_ CONDS = 30+f"Inmportsnt, e  aggage: {dav mportel)     OBoflue):
    O(rp
 yreadingIns:ent, receiver)acer_p        Can,
 put_d osst ast_agen        tifi nemeal funntER_.     Asst ast_agen       ,ibute(s r,or = Nmetaopaa.     Asst nemeal funntER_, jusfrom s urenhes tor = .span
 Argsg        irp
 yreadingInsg(nt, ,:0000r(obj iagentsext iopentelemeample based le         utput)
     SIZE = ch(rmentog
    detclie_PRO_s.cNSFORMnstRULES_FILEt_av.         utput)
     SIZE = ch(rCan,
 poveiridden,
y         utput)
     SIZE = ch(r_PRO_s.cNSFORMnstRULES_ENrt IDt_av mpr.cer_p         """
    _glo(tr] = set()
           L, "    ioa_o[+ "_"[+ rst(tar .tar 4()rpan_esm op"""
    _(xgage.get_bapan_e# I(ceittizpext iopen expogeor, Ois r,or =  (ntifiobj
 linexporpan_ent_connedoff+f" tor = .er: SpanExp}_bj._seseque
   ,r]0",pan_ent_connedoff+f" tor = .er: SpanExp}_    Opera    rst( o  . o  se)bapan_e# le, Dict,obvironne
  mprigentaoveiridefo: esrp
 yreadingInsgparame set_gl  laingInstru_agentd  #vtrumiutioenv("_PRO_s.cNSFORMnstRULES_ENrt ID")PROMPT_K laingInstru_agentd  #v:

SESSION_IDLE_TIMEOUT_SECrp
 yreadingInsglo next__nt, e    #v( laingInstru_agentd  #vATCHER_INTERVAL_SCONDS = 30Noss           # Tr       n pars(: str = Nrsed = seInmports_PRO_s.cNSFORMnstRULES_ENrt IDtggage: "attribute(
         e}. U# Maxparame seaggage: {rp
 yreadingIns}"
rocessor:S_k_      # Hurrleopentelemeample frva
es=Tracrp
 yreadingIns:: TextMap laingInstrumento_file rumiutioenv("_PRO_s.cNSFORMnstRULES_FILE )
ibutes=Trac     laingInstrumento_file          # Tr       n pars(: str = Nrsed = se_PRO_s.cNSFORMnstRULES_FILEt_avironne
  mprigenta"attribute(
      "      t. Dtrent Max:entelemeample. om opent    O)
     y


_  rp
 yreadingInsgloeiver=     "Nonlaft    otilsth. xt_vs( laingInstrumento_file)          # Tr       n pars(: str = Nrsed = seTlaingInstrrmentogfile     fibns: "attribute(
          laingInstrumento_file}. Dtrent Max"attribute(
      ":entelemeample. om opent    O)
     y


_  rp
 yreadingInsgloeiver=     "Nonl            # Trhoy:                  n.se,
)
( laingInstrumento_file,r]r"(
   f:         utput)
     houingInstrumentogloo"]

    (f)ders to yUEST_MOD#nVport Th rstucart
mreadoentoas HTTPExporter,
mport ThreadingInstrumento( laingInstrumento)urce(attributes=Tars):
 s   mport("rp
 yreadingIns                          ars):
 s   mport(" laingInstrumento",T laingInstrumento)essions: set[sexVAL_So"]

JSONDetad  = 30Noss           # Tr# Tr       n pars(: str = Nrsed = s    "Failreadin    T laingInstrrmentogfclie"       parsed = span_    laingInstrumento_file}: {de. Dtrent Max"attribute(
          ":entelemeample. om opent    O)
from opentelemetry.erp
 yreadingInsgloeiver=     "No_INTERVAL_SCONDS = 30          # Tr# Tr       n pars(: str = Nrsed = s    "Inmports laingInstrrmentogrstucart
.x"attribute(
          "ExpATErea'RULES'   ntER_.x"attribute(
          "Dtrent Max:entelemeample. om opent    O)
from opentelemetry.erp
 yreadingInsgloeiver=     "No_INTERVAL_S(o"]

JSONDetad  = 30,SERVAL_ = )Noss           # Tr# Tr       n pars(: str = Nrsed = s    "Failreadin    T laingInstrrmentogfclie"       parsed = span_    laingInstrumento_file}: {de. "attribute(
          "Dtrent Max:entelemeample. om opent    O)
from opentelemetry.erp
 yreadingInsgloeiver=
es=Trac    rp
 yreadingIns:: TextMapars):
 s   mport("rp
 yreadingIns    runne span_imetaopaa an.on_endmra"ssion_lasID":o    mport("text fo    ) L, value):
   
        ":enVALaribuID":o    Attribut:enVALaribuse

ch =}: Texotebook
n_heci
pan_efr      
n_heci.Attribufr   ().f_back
es=Tracfr         
   t  na"VERSfr   .f_tad .co     s:E = "ioa.obUt_d osst ast_agen                Eunner                                         @                 > boolSEf _cmst_SPANS_SIZE = bute(imetaopaar: TextMap       _cmst
ioa.obUt_d osst nemeal funntER_
tMap       r         .nulletry.pr(metaopaaPr    OBoff_p"""
    _(xgage.get_(self, :enVALaribuiability = cr strt    e(sel        Seibutes.ssion_las IDent bothnts ikey-mport]conne     O
)
processor r      .span
 TOis funntER_]connebutes.ssion_las IDean.set_attd)
    ast_agendinensre

   y       nProcecotrilatrib acrossentr=([^\s]d sysowLi.span
 Argsg        ixgage.get_(sTes.ssion_las IDedinoffssions: s lastLaribuia endpoinet_attd)
    6/iusad(rac_nameeanll.sst_att Eunner      )cer_p        aft      age.get_(
ack tMap      apan_eessor,
)
from open                  TracerProvider, SpanProcression
fPropaProcesource
from op(e(self, ecountmetrics  "gen_ai.ioa.agect[str,apan_e# Ifet_attd)
    iom op    dt(RVE_, Traceincom Max dom o_),iusadnr(f   ifet_attd)
   :E = "ioa.obStoresssion_las IDean.se op    dtt_attd)
   E = "ioa.nt_keyglof"ssion_las.{t_attd)
   }"
rocessorifent_connedtionnt_key)tiomt    e(self, ech(rnt_connedoff+nt_key  nt()
       process pobStoresnt O
)
processor r      : TextMapars):
 s   mport("text fo      nt()
      ): TextMapars):
 s   mport("Attribut:enVALaribu", :enVALaribu))
ack tMap      apan_e# le, Dict,weuploadenst
     xt iofir =     Attributes.LT)"porter   iAttributes.LL)PROMPsst_atttd t_attd)
    )"t    (f   ifeAttributes.L.cs ooentelem(,:E = "ioa.obWeuploadenst
     xt i,iusadnrs r      : TextMapcarrit_agee_id)}
    countmetrics  "gen_ai.ioa.ageders(rume(carrit_ATCHER_INTERt_atttd t_attd)
    )"carrit_ution.:enVALaribu")E = "ioa.obStoresssion_las IDean.set_attd)
    oss ""

SESSION51 00t_atttd t_attd)
    e(self, ech(rnt_keyglof"ssion_las.{00t_atttd t_attd)
   }"
rocessor:S_kifent_connedtionnt_key)tiomt    e(self, ech(rch(rnt_connedoff+nt_key  nt()
       an_e# Ifethere
iom  st
     xt i,iwaddot   h Maxnow     wheniwadneei urrent_ctd)
   E = "SERVE_Ewheniession
fPMaxr      ,iwaduropag ts ikt_conneean.sethes tor = _en"Thenapan_e# FnAttly,pars):
 6/iesource
text fo   bservettribut:enVALaribup# Trae"):

tMapars):
 s   mport("text fo      nt()
      ): Tex51 00t_atttd t_attd)
    e(self, ears):
 s   mport("Attribut:enVALaribu", 00t_atttd t_attd)
   )_  
t AG    Attribut:enVALaribuse strr=( e(sel        GetaurreAttribut:enVALaribup#nst astsue
nntiw)y acrosse: esrp
      = .span
 R     sg        iTrreAttribut:enVALaribupnup


 o   t    aft   nProcecoource
 xt_vs
ibut        essor,
)
from open                  TracerProvider, SpanProcression
fPropaProcesource
from op(e(self, ecountmetrics  "gen_ai.ioa.agect[str,apan_e# Fir = ce, Dict,weuploadits t   doin r      : Tex t   d t_attd)
    )"g   mport("Attribut:enVALaribu"): Tex51  t   d t_attd)
   :E = "ioa.       _t   d t_attd)
   apan_e# Otherwit_ sst_att Eunnerttributifie     Attributes.LT)"porter   iAttributes.LL)PROMPifeAttributes.L.cs ooentelem(,:E = "ioa.carrit_agee_id)}
    countmetrics  "gen_ai.ioa.ageders(rume(carrit_ATCHER_INT       rarrit_ution.:enVALaribu")E
tMap       t    (   OBoff_topaga __rWrap(topaga _:: str strt    e(selers):
 s   mport("ropaga _ ,cropaga _ Pr    OBoff_rp
      = a _(rp
a _:: str strt    e(selers):
 s   mport("rp
      = a _ ,crp
a _ Pr    OBoff_ # Recolsth( # Recolsth:: str strt    e(selers):
 s   mport(" # Recolsth", 0# Recolsth)_  
t AG    A    td  # Recolsth( # Reco    :: str strr=( e(seld)
    )"g   mport(" # Recolsth")PROMPifed)
    iomt    e(self, e        # Reco    =                  r         d)
   }.{0# Reco    }"
    OBoff_      d_      nd__" ormetry.pr(
    key     ectionveir = :     ctionveir = 
    (self,ctionveir = 
hash(self,ction    less mprigents_agentecr strt    e(selers):
 s   mport("      d_      _             ers):
 s   mport("       key", key       ers):
 s   mport("       veir = ",nveir =        ers):
 s   mport("       veir =       pnveir =      _      ers):
 s   mport("       veir =  hash",nveir = 
hash_      ers):
 s   mport("           less mprigents",n    less mprigents Pr    OBoff_ xsdkfne_      nd__" ormetry.pr(
        less(self, mprigents_agentenveir = :    cr strt    e(selers):
 s   mport("      d_      _   runne s    ers):
 s   mport("       veir = ",nveir =        ers):
 s   mport("           less",n    less_      ers):
 s   mport("           less mprigents",nmprigents Pr    OBcs         BSERVE strext_acer_p       _hans_package_iutionetryApackage_iuLLM_REQUEST_TYPE)tiom    t   r    OBcSs)
l        yi.oatapi_ia"):
       eltion_reliability.recordE str01661 Asor,
:
es=Tracrpi_ia"):
  bserv(e(self, e"http"VERSrpi_ia"):
  .Contstr]L, "https"VERSrpi_ia"):
  .Contstr
pan_)span_entit       HTTPE  yi.oat, in)In    . ia"):
  =   rpi_ia"):
  }/v1/:enVAbility.reoolprovtion_re=tion_re,
# Track tMapimmrae"r = =Cmmrae"r = .Gzipject):
   nt tranlaftapi_ia"):
   pan_entit       GRPCE  yi.oatia"):
  =   rpi_ia"):
  }",vtion_re=tion_re)=                  # D  ault 6/iHTTP 00xt forean.seg: alho = wheniia"):
  biomt   pan_entit       HTTPE  yi.oat, in)In    . ia"):
  ="http://g: alho =:4318/v1/:enVAbility.reoolprovtion_re=tion_re,
# Track tMapimmrae"r = =Cmmrae"r = .Gzipject):
   nt

abMarkeifipackage_er,e.o  _hanading.Locks ad-> "by  OptO       SDK so obj.:#,weucanaSERVnt  Opm whenireu# Maxana xsdkfnely-rd_rs decount]P    obj.ser:#,g.Locke,gue
ne Maxak()
      TracerWror.
                         )".om i        urce_attri  
t AG n    obj
hasi        urce_attr(n    obj:ecount]P    objr strext_acer_p   R      nt !Trac*n    obj*der=None,hasdentO       _hanading.Lock.        hoy:         Lulti )"g  rProvn    obj,
" _      s]] = None,
  "Bat   (
t_context_h ulti iomt    e(self, ech(r       eiver=       y   g.Locks )"g  rProv ulti,
" s]] = None,
  s",n())
ack tMap      finy(g  rProvsp                             runne EL, vpent aacne,
  s)PROMPssVAL_SERVAL_ = :E = "ioa.       eiver=    OBcSs)
execution_counts_lock = :success_cr strcount]P    obj:
   y     obj:ecount]P    objT)"t           ault_     obj:ecount]P    objT)"   if lastion_counts) (f   ifeis None
  (   ault_     obj, P  xycount]P    objr:=       y     objT)"count]P    objs_lock = tng.Lock()
        porters  if lastion_countson_countnt tranlaft    acerProv   ault_     obj, "                  ",:E = "ioa.       n pars(: str = Nrsed"CanI       _hanading.Lockgoraurre   aulty     objTs Ncaditsdoesn'_usupebook
t"ect):
   nt trace c      a                  # Reu# Maxana xsdkfnely-r,e.           Guardcroa Non     Maxa         # ()
      TO       racerWror.
t_context_h n    obj
hasi        urce_attr(   ault_     obj)          # Tr       nwarnxpo(attribute(
      "O       _hanading.Lockder=None,e,gue
need lee: esr
     ": str = Nrsed = seTlant]P    objT—tikipp Max()
      Te,gue
rample. om opent    O)
     y


_            ault_     obj=       y     objT)"   ault_     obj=                obj=    OBcSs)
port TextMapProsre(selr       )


class Tra next_ectionbase64_ndpoint:
     :storegent[ity.recorrecordcecordct[strn = None
  ia endpoin[Set[propagate snts]]_name: strng: bool = True
 ia endpoin[Set[propagate snts]]_name:)      ng: bool = True
 s]]ng: bool = True
 s   r,eL)PROMPil = True
 s]]ol = True
 s   r,eL=       ypropagate st[str, ty = coerlsn = None
   aft  nen_hecift_aapan_e# Remo   iny n = None
   thattwere
00x   ie yong: bpe
    il = True
 s]]ol = True
 s-]ng: bool = True
 

    il = True
_r,e._aeiver=    EL, ml = True
ent ol = True
 ipan_id, traccl = True
e==ypropagate s.ANTHROPICource(attributifecSs)
an   (picool = True
rs(: str = Nrsed = sr       )


class Tra nbase64_ndpoint:
     
      if notent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.BED   Kource(attributifecSs)
bedr: bool = True
rs(r       )


class Traent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.CREWource(attributifecSs)
rd_waiool = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.GOOGLE_GENERATIVEAIource(attributifecSs)
goog ._gen [tanveaiool = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.GROQource(attributifecSs)
groqool = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.LANGCHAINource(attributifecSs)
lang      ol = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.LLAMA_INDEXource(attributifecSs)
llama oldex ol = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.MISTRALource(attributifecSs)
mue
ralaiool = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.OLLAMAource(attributifecSs)
ollama ol = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.OPENAIource(attributifecSs)
rProaiool = True
rs(r       )


class Tra nbase64_ndpoint:
     ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.REQUESTSource(attributifecSs)
requests ol = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.SAGEMA   ource(attributifecSs)
m o_.ck rool = True
rs(r       )


class Traent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.TOGETH  ource(attributifecSs)
to   h rool = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.T.cNSFORMnsSource(attributifecSs)
 laingInstrs ol = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.URLLIB3ource(attributifecSs)
urllib3 ol = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienlaftcl = True
e==ypropagate s.VERTEXAIource(attributifecSs)
vei exaiool = True
rs(ent")
    
tity_outil = True
_r,e._aandoff_to fienl            # Trprinin    .RED + f"Warnxport{il = True
} port TextMapProsdoes     ext_v. )urce(attributprininner = parsed["__s"Um o_:\n": str = Nrsed = seEunnesdk.n = None
   arom oppropagate s\n": str = Nrsed = se       .s(ce(        ='...', ol = True
 =r,eL[propagate s.OPENAI])) om opent    O)
     y


_  prinin    .RESET)ploade       s(opagate _r,e e(self, eprininner = parsed[    .REDner = parsed[+ "WarnxportNoimportsn = None
  tr,e. "ner = parsed[+ "Shecify]ol = True
 s   remo   'n = None
 s' argone
 36/iusaderlsn = None
  ."ect):
   nt trace cprinin    .RESET)p=           s(opagate _r,e=    OBcSs)
rProaiool = True
rs(e(selr       )


class Tra next_enbase64_ndpoint:
     :storegent[ity.recorrecordcecord:)      hoy:         raccs packpoin Nonelt_av"rProai  __disabled: boprocessor().capart
("port TextMapPro:rProai:cSs) )urce(attributTracerProvider, Spaport TextMapPro.rProai arom opO
)
AIpropagate imr: TextMapProps(opagate ojT)"O
)
AIpropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.search(r )


classue
an =r       )


class Tra         imaBhr["s    Aommstrass Traj._agent_ex=ass TrajAommstr_package_i,ity.reoolprovidedk:
   _base64_ndpoi=base64_ndpoint:
     arsed, dict) and "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candof
ibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxO
)
AItil = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
an   (picool = True
rs(: strr       )


class Tra next_enbase64_ndpoint:
     :storegent[ity.recorrecordcecord:)      hoy:         raccs packpoin Nonelt_av"an   (pic  __disabled: boprocessor().capart
("port TextMapPro:an   (pic:cSs) )urce(attributTracerProvider, Spaport TextMapPro.an   (pic arom opAn   (picpropagate imr: TextMapProps(opagate ojT)"An   (picpropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.search(r )


cltoken_um o_=r       )


class Tra         imaBhr["s    Aommstrass Traj._agent_ex=ass TrajAommstr_package_i,ity.reoolprovidedk:
   _base64_ndpoi=base64_ndpoint:
     arsed, dict) and "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxAn   (pic al = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
cohereool = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"cohere  __disabled: boprocessor().capart
("port TextMapPro:cohere:cSs) )urce(attributTracerProvider, Spaport TextMapPro.cohere arom opCoherepropagate imr: TextMapProps(opagate ojT)"Coherepropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxCohere al = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
goog ._gen [tanveaiool = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"goog .-gen [tanveai  __disabled: boprocessor().capart
("port TextMapPro:o_.cSs:cSs) )urce(attributTracerProvider, Spaport TextMapPro.goog ._gen [tanveai
from op(e(self, eeeeeeeeeGoog .Gen [tanveAipropagate im,
rocessor:S_k_      tMapProps(opagate ojT)"Goog .Gen [tanveAipropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxG_.cSs al = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
lang      ol = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"lang      ) L, cs packpoin Nonelt_av"langgraph  __disabled: boprocessor().capart
("port TextMapPro:lang     :cSs) )urce(attributTracerProvider, Spaport TextMapPro.lang     
from opLang     propagate imr: TextMapProps(opagate ojT)"Lang     propagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxLangC    
fl = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
mue
ralaiool = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"mue
ralai  __disabled: boprocessor().capart
("port TextMapPro:mue
ralai:cSs) )urce(attributTracerProvider, Spaport TextMapPro.mue
ralai
from opMue
ralAipropagate imr: TextMapProps(opagate ojT)"Mue
ralAipropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxMue
ralAItil = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
ollama ol = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"rllama  __disabled: boprocessor().capart
("port TextMapPro:rllama:cSs) )urce(attributTracerProvider, Spaport TextMapPro.rllama arom opOllamapropagate imr: TextMapProps(opagate ojT)"Ollamapropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxOllama al = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
 laingInstrs ol = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av" laingInstrs  __disabled: boprocessor().capart
("port TextMapPro: laingInstrs:cSs) )urce(attributTracerProvider, Spaport TextMapPro. laingInstrs
from op(e(self, eeeeeeeeeTlaingInstrspropagate im,
rocessor:S_k_      tMapProps(opagate ojT)"TlaingInstrspropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxTlaingInstrs
fl = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
 o   h rool = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av" o   h r  __disabled: boprocessor().capart
("port TextMapPro: o   h r:cSs) )urce(attributTracerProvider, Spaport TextMapPro. o   h r
from opTo   h rAipropagate imr: TextMapProps(opagate ojT)"To   h rAipropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxTo   h rAItil = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
llama oldex ol = True
rs(ent")
 hoy:         rac(ff_to field
 cs packpoin Nonelt_av"llama-oldex )urce(attributL, cs packpoin Nonelt_av"llama oldex )urce(attributL, cs packpoin Nonelt_av"llama-oldex-   O )urce(attr __disabled: boprocessor().capart
("port TextMapPro:llamaoldex:cSs) )urce(attributTracerProvider, Spaport TextMapPro.llamaoldex
from opLlamaprdexpropagate imr: TextMapProps(opagate ojT)"Llamaprdexpropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxLlamaprdextil = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
requests ol = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"requests  __disabled: boTracerProvider, Spaport TextMapPro.requests
from opRequestspropagate imr: TextMapProps(opagate ojT)"Requestspropagate im(nd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxRequests
fl = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
urllib3 ol = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"urllib3  __disabled: boTracerProvider, Spaport TextMapPro.urllib3
from opURLLib3propagate imr: TextMapProps(opagate ojT)"URLLib3propagate im(nd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz Maxurllib3
fl = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
bedr: bool = True
rs(r       )


class Tragent, ,:inkinhoy:         raccs packpoin Nonelt_av"boto3  __disabled: boTracerProvider, Spaport TextMapPro.bedr: b
from opBedr: bpropagate imr: TextMapProps(opagate ojT)"Bedr: bpropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.search(r )


cltoken_um o_=r       )


class Tra         imaBhnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxBedr: b
fl = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
m o_.ck rool = True
rs(r       )


class Tragent, ,:inkinhoy:         raccs packpoin Nonelt_av"boto3  __disabled: boTracerProvider, Spaport TextMapPro.m o_.ck r
from opS o_Mck rpropagate imr: TextMapProps(opagate ojT)"S o_Mck rpropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.search(r )


cltoken_um o_=r       )


class Tra         imaBhnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxS o_Mck r
fl = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
vei exaiool = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"goog .-cloud-ai lesgIns )__disabled: boprocessor().capart
("port TextMapPro:vei exai:cSs) )urce(attributTracerProvider, Spaport TextMapPro.vei exai
from opVei exAIpropagate imr: TextMapProps(opagate ojT)"Vei exAIpropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  nwarnxpo(f"CESSEcs(ceittiz MaxVei ex AItil = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
groqool = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"groq  __disabled: boprocessor().capart
("port TextMapPro:oroq:cSs) )urce(attributTracerProvider, Spaport TextMapPro.groq
from opGroqpropagate imr: TextMapProps(opagate ojT)"Groqpropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxGroq
fl = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBcSs)
cd_waiool = True
rs(ent")
 hoy:         raccs packpoin Nonelt_av"cd_wai  __disabled: boprocessor().capart
("port TextMapPro:cd_wai:cSs) )urce(attributTracerProvider, Spaport TextMapPro.cd_wai arom opCd_wAIpropagate imr: TextMapProps(opagate ojT)"Cd_wAIpropagate im(ff_to field
     ERVAL_nstrd gg  =lambda e:oprocessor().d g_ERVAL_nst(ee

ch = re.searnd "goto" in p# T    s(opagate or.cs s(opagate e _by_rProvider, Spnt")
    
tity_outil = True
or.c(opagate ()rbled: bo      candofibut RVAL_SERVAL_ = Noss                  n pars(f"CESSEcs(ceittiz MaxCd_wAI
fl = True
or: {del) bled: boprocessor().d g_ERVAL_nst(eeE = "ioa.       eiver=    OBass TrajAommstr_package_i(ent")
 Aommstr_package_iagee_id)}
              )"g   mport("              )loade                 iom    t   _SPANS_SIZAommstr_package_i[        WORKFLOWt impts]]             f
ibut # Reco     )"g   mport(" # Reco     )loade    # Reco     iom    t   _SPANS_SIZAommstr_package_i[        ENTITYt impts]] # Reco    =     eector embeddings, etc )"g   mport("rector embeddings, etc )loade   eector embeddings, etc iom    t   _SPANS_SIZEL, W3CBaggageent eector embeddings, etcdlowList_SPANS_SIZE = Aommstr_package_i[f"{observe.butes
from ioa_observe}.{W3C} ts]]ggagespan
        r mmstr_package_i
                                                                                                                                            ././@PaxHion_r                                                                                      0000000 0000000 0000000 00000000026 00000000000 010213  x                                                                                                    u     00                                                              