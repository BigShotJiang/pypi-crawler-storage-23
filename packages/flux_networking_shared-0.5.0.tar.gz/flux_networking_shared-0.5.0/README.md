# flux-networking-shared

Shared networking utilities for Flux daemon and TUI.

This package contains platform-independent networking code that can be used by both the flux-configd daemon and the flux_iso_networking TUI package.

## Components

- `UpnpQuerier` - UPnP port mapping discovery
- `NetworkObserver` - Network interface change observation (via probert)
- `IcmpPacketSender` - Raw ICMP ping utilities
- `SystemdConfigParser` - Parse systemd network configurations
- Network models (Route, NetworkInterface, FluxShapingPolicy, etc.)

## Platform Support

- **Linux**: Full functionality with real probert dependency
- **macOS**: Development support with stub probert implementation
