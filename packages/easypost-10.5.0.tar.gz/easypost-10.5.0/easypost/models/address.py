from easypost.easypost_object import EasyPostObject


class Address(EasyPostObject):
    pass
