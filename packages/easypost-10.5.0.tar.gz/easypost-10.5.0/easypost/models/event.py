from easypost.easypost_object import EasyPostObject


class Event(EasyPostObject):
    pass
