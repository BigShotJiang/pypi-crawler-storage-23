from easypost.easypost_object import EasyPostObject


class Report(EasyPostObject):
    pass
