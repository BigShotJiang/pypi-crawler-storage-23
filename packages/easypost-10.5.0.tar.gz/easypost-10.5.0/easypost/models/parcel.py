from easypost.easypost_object import EasyPostObject


class Parcel(EasyPostObject):
    pass
