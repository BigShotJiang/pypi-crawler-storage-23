from easypost.easypost_object import EasyPostObject


class Brand(EasyPostObject):
    pass
