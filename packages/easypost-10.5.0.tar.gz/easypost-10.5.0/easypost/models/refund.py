from easypost.easypost_object import EasyPostObject


class Refund(EasyPostObject):
    pass
