from easypost.easypost_object import EasyPostObject


class PickupRate(EasyPostObject):
    pass
