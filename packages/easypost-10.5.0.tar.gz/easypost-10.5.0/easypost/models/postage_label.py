from easypost.easypost_object import EasyPostObject


class PostageLabel(EasyPostObject):
    pass
