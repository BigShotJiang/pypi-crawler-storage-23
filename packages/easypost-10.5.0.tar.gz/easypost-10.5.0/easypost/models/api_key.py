from easypost.easypost_object import EasyPostObject


class ApiKey(EasyPostObject):
    pass
