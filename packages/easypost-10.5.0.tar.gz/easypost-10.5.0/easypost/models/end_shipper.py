from easypost.easypost_object import EasyPostObject


class EndShipper(EasyPostObject):
    pass
