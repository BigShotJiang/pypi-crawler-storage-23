from easypost.easypost_object import EasyPostObject


class Payload(EasyPostObject):
    pass
