from easypost.easypost_object import EasyPostObject


class Batch(EasyPostObject):
    pass
