from easypost.easypost_object import EasyPostObject


class Claim(EasyPostObject):
    pass
