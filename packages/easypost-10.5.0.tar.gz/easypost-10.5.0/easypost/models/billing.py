from easypost.easypost_object import EasyPostObject


class Billing(EasyPostObject):
    pass
