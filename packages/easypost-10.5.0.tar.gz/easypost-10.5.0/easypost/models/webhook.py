from easypost.easypost_object import EasyPostObject


class Webhook(EasyPostObject):
    pass
