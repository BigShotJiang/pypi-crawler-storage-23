from easypost.easypost_object import EasyPostObject


class CustomsInfo(EasyPostObject):
    pass
