from easypost.easypost_object import EasyPostObject


class CustomsItem(EasyPostObject):
    pass
