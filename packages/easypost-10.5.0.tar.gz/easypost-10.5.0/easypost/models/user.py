from easypost.easypost_object import EasyPostObject


class User(EasyPostObject):
    pass
