from easypost.hooks import EventHook


class RequestHook(EventHook):
    """An event that gets triggered when an HTTP request begins."""

    pass
