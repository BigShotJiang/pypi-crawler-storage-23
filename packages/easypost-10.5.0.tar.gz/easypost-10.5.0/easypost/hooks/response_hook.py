from easypost.hooks import EventHook


class ResponseHook(EventHook):
    """An event that gets triggered when an HTTP response is returned."""

    pass
