from easypost.errors.general.easypost_error import EasyPostError


class InvalidObjectError(EasyPostError):
    pass
