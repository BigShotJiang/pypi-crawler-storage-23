from easypost.errors.general.easypost_error import EasyPostError


class MissingParameterError(EasyPostError):
    pass
