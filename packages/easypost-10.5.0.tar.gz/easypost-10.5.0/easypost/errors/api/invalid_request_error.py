from easypost.errors.api.api_error import ApiError


class InvalidRequestError(ApiError):
    pass
