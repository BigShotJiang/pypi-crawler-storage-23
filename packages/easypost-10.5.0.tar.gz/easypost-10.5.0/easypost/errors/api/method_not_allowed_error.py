from easypost.errors.api.api_error import ApiError


class MethodNotAllowedError(ApiError):
    pass
