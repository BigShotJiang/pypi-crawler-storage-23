from easypost.errors.api.api_error import ApiError


class RateLimitError(ApiError):
    pass
