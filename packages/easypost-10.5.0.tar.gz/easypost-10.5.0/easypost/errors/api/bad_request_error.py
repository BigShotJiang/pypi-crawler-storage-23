from easypost.errors.api.api_error import ApiError


class BadRequestError(ApiError):
    pass
