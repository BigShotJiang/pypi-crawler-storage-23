from easypost.errors.api.api_error import ApiError


class JsonError(ApiError):
    pass
