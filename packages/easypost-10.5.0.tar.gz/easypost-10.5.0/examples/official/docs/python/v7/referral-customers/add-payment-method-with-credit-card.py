import easypost

easypost.api_key = "EASYPOST_API_KEY"

payment_method = easypost.beta.Referral.add_payment_method(
    stripe_customer_id="cus_...",
    payment_method_reference="card_...",
    primary_or_secondary="primary",
)

print(payment_method)
