import easypost

easypost.api_key = "EASYPOST_API_KEY"

easypost.Referral.update_email(
    "new_email@example.com",
    "user_...",
)
