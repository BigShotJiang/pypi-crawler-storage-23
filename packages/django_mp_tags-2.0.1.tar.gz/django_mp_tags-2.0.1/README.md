# MP-tags

Django tags app.

### Installation

Install with pip:

```
pip install django-mp-tags
```
