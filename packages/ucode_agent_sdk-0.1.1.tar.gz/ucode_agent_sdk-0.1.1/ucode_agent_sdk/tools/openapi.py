"""OpenAPI Toolkit — dynamically builds LangChain tools from an OpenAPI spec.

Each operation in the spec becomes a callable tool that makes real HTTP requests.
Auth is resolved from pre-decrypted secret values in the config.
"""

from __future__ import annotations

import json
import logging
from typing import Annotated, Any

import httpx
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, BeforeValidator, create_model


def _coerce_to_dict(v: Any) -> Any:
    """Coerce a JSON string to a dict; pass dicts through unchanged."""
    if isinstance(v, str):
        try:
            parsed = json.loads(v)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, ValueError):
            pass
    return v


# Annotated type that auto-parses JSON strings into dicts
JsonBody = Annotated[dict, BeforeValidator(_coerce_to_dict)]

logger = logging.getLogger(__name__)


def build_openapi_tools(config: dict[str, Any]) -> list:
    """Build LangChain tools from a stored OpenAPI toolkit config.

    Config shape:
    {
        "spec": { ... inline parsed spec ... },   # from UI editor
        "spec_url": "...",                         # legacy
        "base_url": "...",                         # explicit override
        "auth": {"type": "header", "name": "Authorization", "value": "<decrypted>"},
        "tools_manifest": [ ... ]                  # injected by runner before calling SDK
    }
    """
    auth_config = config.get("auth", {})
    manifest = config.get("tools_manifest", [])
    toolkit_description = config.get("description", "").strip()

    if not manifest:
        return []

    # Resolve base_url: explicit > spec.servers[0] > spec_url origin
    base_url = config.get("base_url", "").rstrip("/")
    if not base_url:
        inline_spec = config.get("spec")
        if isinstance(inline_spec, dict):
            servers = inline_spec.get("servers", [])
            if servers and isinstance(servers[0], dict):
                base_url = servers[0].get("url", "").rstrip("/")
    if not base_url:
        spec_url = config.get("spec_url", "")
        if spec_url:
            from urllib.parse import urlparse
            p = urlparse(spec_url)
            base_url = f"{p.scheme}://{p.netloc}"

    tools = []
    for entry in manifest:
        name = entry.get("name", "")
        base_description = entry.get("description", "")
        description = (
            f"{toolkit_description}\n\n{base_description}"
            if toolkit_description and base_description
            else toolkit_description or base_description
        )
        parameters = entry.get("parameters", {})
        meta = entry.get("_meta", {})

        path = meta.get("path", "")
        method = meta.get("method", "get")

        if not name or not path:
            continue

        tool_fn = _make_http_tool(
            name=name,
            description=description,
            path=path,
            method=method,
            base_url=base_url,
            auth_config=auth_config,
            parameters_schema=parameters,
        )
        if tool_fn:
            tools.append(tool_fn)

    return tools


def _make_http_tool(
    name: str,
    description: str,
    path: str,
    method: str,
    base_url: str,
    auth_config: dict,
    parameters_schema: dict,
) -> StructuredTool | None:
    """Create a single LangChain StructuredTool for an HTTP operation."""

    field_definitions: dict[str, Any] = {}
    props = parameters_schema.get("properties", {})
    required_fields = set(parameters_schema.get("required", []))

    for field_name, field_schema in props.items():
        field_type = _json_type_to_python(field_schema.get("type", "string"))
        field_desc = field_schema.get("description", "")
        # Use JsonBody for object/dict fields so JSON-string inputs are auto-parsed
        if field_type is dict:
            effective_type = JsonBody
            optional_type = JsonBody | None
        else:
            effective_type = field_type
            optional_type = field_type | None
        if field_name in required_fields:
            field_definitions[field_name] = (effective_type, ...,)
        else:
            field_definitions[field_name] = (optional_type, None,)

    if not field_definitions:
        field_definitions["_placeholder"] = (str | None, None,)

    try:
        ArgsModel = create_model(f"{name}_args", **field_definitions)
    except Exception:
        ArgsModel = create_model(
            f"{name}_args", _placeholder=(str | None, None))

    def _call(**kwargs: Any) -> str:
        url = base_url + path
        for k, v in kwargs.items():
            if v is not None and f"{{{k}}}" in url:
                url = url.replace(f"{{{k}}}", str(v))

        headers: dict[str, str] = {}
        _apply_auth(headers, auth_config)

        body = kwargs.get("body")
        # Defensive coercion: if LLM passed body as a JSON string, parse it
        if isinstance(body, str):
            try:
                parsed = json.loads(body)
                if isinstance(parsed, dict):
                    body = parsed
            except (json.JSONDecodeError, ValueError):
                pass
        query_params = {
            k: v for k, v in kwargs.items()
            if k != "body" and k != "_placeholder" and v is not None
            and f"{{{k}}}" not in path
        }

        try:
            with httpx.Client(timeout=30) as client:
                response = client.request(
                    method=method.upper(),
                    url=url,
                    headers=headers,
                    params=query_params or None,
                    json=body if body else None,
                )
                text = response.text[:4000]
                return f"HTTP {response.status_code}\n{text}"
        except Exception as e:
            return f"Request failed: {e}"

    return StructuredTool.from_function(
        func=_call,
        name=name,
        description=description,
        args_schema=ArgsModel,
    )


def _apply_auth(headers: dict[str, str], auth_config: dict) -> None:
    """Apply authentication to request headers."""
    auth_type = auth_config.get("type", "none")

    if auth_type in ("apikey", "header"):
        key_name = auth_config.get("name", "X-API-Key")
        key_value = auth_config.get("value", "")
        location = auth_config.get("in", "header")
        if location == "header" and key_value:
            headers[key_name] = key_value

    elif auth_type == "bearer":
        token = auth_config.get("value", "")
        if token:
            headers["Authorization"] = f"Bearer {token}"


def _json_type_to_python(json_type: str) -> type:
    """Map JSON Schema type to Python type."""
    mapping = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }
    return mapping.get(json_type, str)
