"""Artifact Toolkit — 10 file-operation tools for MinIO project buckets.

Each tool is a LangChain @tool that receives a bound storage_client
and bucket_name at construction time via closures. Tools return plain
strings for LLM readability.
"""

from __future__ import annotations

import io
import mimetypes
import re
from typing import Any

from langchain_core.tools import tool


def build_artifact_tools(
    storage_client: Any,
    bucket_name: str,
    project_id: str,
) -> list:
    """Build all 10 artifact tools bound to a specific bucket.

    Args:
        storage_client: A MinIO-compatible client with get/put/remove/list methods.
        bucket_name: The bucket (already created in MinIO).
        project_id: The owning project's ID.

    Returns:
        List of LangChain BaseTool instances ready for .bind_tools().
    """

    @tool
    def createFile(path: str, content: str) -> str:
        """Create a new file in the bucket with the given content."""
        data = content.encode("utf-8")
        storage_client.put_object(
            bucket_name, path, io.BytesIO(data), len(data),
            content_type="text/plain",
        )
        return f"Created {path} ({len(data)} bytes)"

    @tool
    def edit_file(path: str, content: str) -> str:
        """Overwrite the entire content of an existing file."""
        data = content.encode("utf-8")
        storage_client.put_object(
            bucket_name, path, io.BytesIO(data), len(data),
            content_type="text/plain",
        )
        return f"Updated {path} ({len(data)} bytes)"

    @tool
    def readFile(path: str) -> str:
        """Read the text content of a file."""
        try:
            response = storage_client.get_object(bucket_name, path)
            data = response.read()
            response.close()
            response.release_conn()
            return data.decode("utf-8", errors="replace")
        except Exception as e:
            return f"Error reading {path}: {e}"

    @tool
    def read_multiple_files(paths: list[str]) -> str:
        """Read multiple files at once and return their contents."""
        results = []
        for p in paths:
            try:
                response = storage_client.get_object(bucket_name, p)
                data = response.read()
                response.close()
                response.release_conn()
                results.append(f"=== {p} ===\n{data.decode('utf-8', errors='replace')}")
            except Exception as e:
                results.append(f"=== {p} ===\nError: {e}")
        return "\n\n".join(results)

    @tool
    def appendData(path: str, content: str) -> str:
        """Append text to the end of an existing file."""
        try:
            response = storage_client.get_object(bucket_name, path)
            existing = response.read()
            response.close()
            response.release_conn()
        except Exception:
            existing = b""
        new_data = existing + content.encode("utf-8")
        storage_client.put_object(
            bucket_name, path, io.BytesIO(new_data), len(new_data),
            content_type="text/plain",
        )
        return f"Appended to {path} (now {len(new_data)} bytes)"

    @tool
    def listFiles(prefix: str = "") -> str:
        """List all files in the bucket, optionally filtering by prefix."""
        objects = storage_client.list_objects(bucket_name, prefix=prefix, recursive=True)
        files = []
        for obj in objects:
            files.append(f"{obj.object_name}  ({obj.size} bytes)")
        if not files:
            return "No files found."
        return "\n".join(files)

    @tool
    def grep_file(path: str, pattern: str) -> str:
        """Search for a regex pattern in a file and return matching lines."""
        try:
            compiled = re.compile(pattern, re.MULTILINE)
        except re.error as e:
            return f"Invalid regex: {e}"
        try:
            response = storage_client.get_object(bucket_name, path)
            text = response.read().decode("utf-8", errors="replace")
            response.close()
            response.release_conn()
        except Exception as e:
            return f"Error reading {path}: {e}"
        matches = []
        for i, line in enumerate(text.splitlines(), 1):
            if compiled.search(line):
                matches.append(f"{i}: {line}")
        if not matches:
            return f"No matches for '{pattern}' in {path}"
        return "\n".join(matches[:100])  # cap output

    @tool
    def get_file_type(path: str) -> str:
        """Return the MIME type of a file."""
        mime, _ = mimetypes.guess_type(path)
        if mime:
            return f"{path}: {mime}"
        try:
            stat = storage_client.stat_object(bucket_name, path)
            return f"{path}: {stat.content_type}"
        except Exception:
            return f"{path}: unknown"

    @tool
    def deleteFile(path: str) -> str:
        """Delete a file from the bucket."""
        try:
            storage_client.remove_object(bucket_name, path)
            return f"Deleted {path}"
        except Exception as e:
            return f"Error deleting {path}: {e}"

    @tool
    def createNewBucket(name: str) -> str:
        """Create a new storage bucket in the project."""
        full_name = f"{project_id}-{name}"
        try:
            if not storage_client.bucket_exists(full_name):
                storage_client.make_bucket(full_name)
            return f"Bucket '{name}' created (internal: {full_name})"
        except Exception as e:
            return f"Error creating bucket '{name}': {e}"

    return [
        createFile,
        edit_file,
        readFile,
        read_multiple_files,
        appendData,
        listFiles,
        grep_file,
        get_file_type,
        deleteFile,
        createNewBucket,
    ]
