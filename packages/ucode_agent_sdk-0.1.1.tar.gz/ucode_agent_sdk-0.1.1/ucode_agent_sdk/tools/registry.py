"""Tool registry — resolves toolkit configs into runnable LangChain tools.

Entry point called by the runner's tool_resolver to convert stored
toolkit configurations into actual BaseTool instances.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def get_toolkit_tools(
    toolkit_type: str,
    toolkit_config: dict[str, Any],
    runtime_context: dict[str, Any] | None = None,
) -> list:
    """Build LangChain tools for a given toolkit type and config.

    Args:
        toolkit_type: "artifact", "openapi", or "mcp".
        toolkit_config: Type-specific configuration dict.
        runtime_context: Runtime dependencies (minio_client, project_id, etc.).

    Returns:
        List of LangChain BaseTool instances.
    """
    ctx = runtime_context or {}

    if toolkit_type == "artifact":
        return _build_artifact_tools(toolkit_config, ctx)
    elif toolkit_type == "openapi":
        return _build_openapi_tools(toolkit_config, ctx)
    else:
        logger.warning(f"Unknown toolkit type: {toolkit_type}")
        return []


def _build_artifact_tools(
    config: dict[str, Any], ctx: dict[str, Any]
) -> list:
    """Build artifact tools from config and runtime context."""
    from ucode_agent_sdk.tools.artifact import build_artifact_tools

    storage_client = ctx.get("storage_client")
    if not storage_client:
        logger.error(
            "No storage_client in runtime_context — cannot build artifact tools")
        return []

    project_id = ctx.get("project_id", "")

    # Resolve the MinIO bucket name.
    # Priority: explicit bucket_name in config > bucket_id in config (converted to MinIO name)
    # > project-level fallback from runtime context.
    # MinIO naming convention (mirrors api/app/core/storage.py):
    #   ucode-{bucket_id_hex_no_dashes}
    bucket_name = config.get("bucket_name", "")
    if not bucket_name:
        bucket_id = config.get("bucket_id", "")
        if bucket_id:
            bucket_name = f"ucode-{str(bucket_id).replace('-', '')}"
        else:
            # Fall back to project-level bucket only when no bucket_id provided
            bucket_name = ctx.get("bucket_name", "")

    # Ensure the bucket exists in MinIO (create if absent)
    if bucket_name:
        try:
            if not storage_client.bucket_exists(bucket_name):
                storage_client.make_bucket(bucket_name)
                logger.info(f"Auto-created MinIO bucket: {bucket_name}")
        except Exception as e:
            logger.warning(
                f"Could not ensure bucket '{bucket_name}' exists: {e}")

    return build_artifact_tools(
        storage_client=storage_client,
        bucket_name=bucket_name,
        project_id=str(project_id),
    )


def _build_openapi_tools(
    config: dict[str, Any], ctx: dict[str, Any]
) -> list:
    """Build OpenAPI tools from config."""
    from ucode_agent_sdk.tools.openapi import build_openapi_tools
    return build_openapi_tools(config)
