"""MCP Toolkit — wraps MCP server tools as LangChain tools.

Connects to an MCP server (SSE or stdio), lists its tools, and wraps
each as a LangChain StructuredTool.

Session strategy
----------------
Each unique MCP server gets a *single* persistent connection that is
shared across all tool calls.  This is required for stateful servers
like Playwright (stdio) where the browser session must survive between
tool invocations.

Implementation: a dedicated background thread runs its own event loop
and holds the MCP context-managers open indefinitely.  Tool calls are
dispatched to that loop via ``asyncio.run_coroutine_threadsafe``.

Call ``close_all_sessions()`` when the agent run finishes to clean up.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any

from langchain_core.tools import StructuredTool
from pydantic import create_model

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Persistent session
# ---------------------------------------------------------------------------

class _PersistentSession:
    """Keeps an MCP connection alive on a dedicated background thread/loop."""

    def __init__(self) -> None:
        self._loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._thread: threading.Thread | None = None
        self._session: Any = None
        self._ready = threading.Event()
        self._error: Exception | None = None
        self._close_event: asyncio.Event | None = None

    def start_stdio(self, command: str, args: list, env: dict | None) -> None:
        self._thread = threading.Thread(
            target=self._run_stdio, args=(command, args, env), daemon=True
        )
        self._thread.start()
        if not self._ready.wait(timeout=30):
            raise RuntimeError(
                f"MCP stdio session did not become ready (command={command!r})"
            )
        if self._error:
            raise self._error

    def start_sse(self, url: str, config: dict) -> None:
        self._thread = threading.Thread(
            target=self._run_sse, args=(url, config), daemon=True
        )
        self._thread.start()
        if not self._ready.wait(timeout=30):
            raise RuntimeError(
                f"MCP SSE session did not become ready (url={url!r})"
            )
        if self._error:
            raise self._error

    def call_tool(self, tool_name: str, arguments: dict, timeout: int = 120) -> str:
        if self._session is None:
            raise RuntimeError("MCP session is not initialised")
        future = asyncio.run_coroutine_threadsafe(
            self._do_call(tool_name, arguments), self._loop
        )
        return future.result(timeout=timeout)

    async def _do_call(self, tool_name: str, arguments: dict) -> str:
        result = await self._session.call_tool(tool_name, arguments)
        return _result_to_str(result)

    def close(self) -> None:
        if self._loop and self._close_event:
            self._loop.call_soon_threadsafe(self._close_event.set)
        if self._thread:
            self._thread.join(timeout=10)

    # -- background loops --------------------------------------------------

    def _run_stdio(self, command: str, args: list, env: dict | None) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._stdio_lifecycle(command, args, env))

    async def _stdio_lifecycle(self, command: str, args: list, env: dict | None) -> None:
        from mcp import ClientSession
        from mcp.client.stdio import stdio_client, StdioServerParameters

        self._close_event = asyncio.Event()
        params = StdioServerParameters(command=command, args=args, env=env)
        try:
            async with stdio_client(params) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    self._session = session
                    self._ready.set()
                    await self._close_event.wait()   # keep alive until closed
        except Exception as exc:
            self._error = exc
            self._ready.set()

    def _run_sse(self, url: str, config: dict) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._sse_lifecycle(url, config))

    async def _sse_lifecycle(self, url: str, config: dict) -> None:
        from mcp import ClientSession

        self._close_event = asyncio.Event()
        try:
            connected = False
            try:
                from mcp.client.streamable_http import streamable_http_client
                async with streamable_http_client(url) as (read, write, _):
                    async with ClientSession(read, write) as session:
                        await session.initialize()
                        self._session = session
                        self._ready.set()
                        connected = True
                        await self._close_event.wait()
            except Exception as e:
                if connected:
                    raise
                logger.debug(f"Streamable HTTP failed, trying legacy SSE: {e}")

            if not connected:
                from mcp.client.sse import sse_client
                async with sse_client(url) as (read, write):
                    async with ClientSession(read, write) as session:
                        await session.initialize()
                        self._session = session
                        self._ready.set()
                        await self._close_event.wait()
        except Exception as exc:
            self._error = exc
            self._ready.set()


# ---------------------------------------------------------------------------
# Session registry
# ---------------------------------------------------------------------------

_SESSIONS: dict[str, _PersistentSession] = {}
_SESSIONS_LOCK = threading.Lock()


def _stdio_key(command: str, args: list, env: dict | None) -> str:
    env_part = ",".join(f"{k}={v}" for k, v in sorted((env or {}).items()))
    return f"stdio::{command}::{' '.join(args)}::{env_part}"


def _sse_key(url: str) -> str:
    return f"sse::{url}"


def _get_or_create_stdio_session(
    command: str, args: list, env: dict | None
) -> _PersistentSession:
    key = _stdio_key(command, args, env)
    with _SESSIONS_LOCK:
        if key not in _SESSIONS:
            sess = _PersistentSession()
            sess.start_stdio(command, args, env)
            _SESSIONS[key] = sess
            logger.info(f"MCP stdio session started: {key}")
        return _SESSIONS[key]


def _get_or_create_sse_session(url: str, config: dict) -> _PersistentSession:
    key = _sse_key(url)
    with _SESSIONS_LOCK:
        if key not in _SESSIONS:
            sess = _PersistentSession()
            sess.start_sse(url, config)
            _SESSIONS[key] = sess
            logger.info(f"MCP SSE session started: {key}")
        return _SESSIONS[key]


def close_all_sessions() -> None:
    """Close all persistent MCP sessions. Call this after an agent run ends."""
    with _SESSIONS_LOCK:
        for key in list(_SESSIONS.keys()):
            try:
                _SESSIONS.pop(key).close()
                logger.info(f"MCP session closed: {key}")
            except Exception as e:
                logger.warning(f"Error closing MCP session {key}: {e}")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def get_mcp_tools(server_config: dict[str, Any]) -> list:
    """Discover an MCP server's tools and return LangChain wrappers.

    All returned tools share one persistent connection so stateful servers
    (e.g. Playwright) maintain their session between calls.
    """
    transport = server_config.get("transport", "sse")
    config = server_config.get("config", {})

    try:
        if transport == "sse":
            return await _discover_sse_tools(config)
        elif transport == "stdio":
            return await _discover_stdio_tools(config)
        else:
            logger.warning(f"Unknown MCP transport: {transport}")
            return []
    except ImportError:
        logger.warning("mcp package not installed — MCP tools unavailable")
        return []
    except Exception as e:
        logger.exception(f"Failed to build MCP tools ({transport}): {e}")
        return []


# ---------------------------------------------------------------------------
# Discovery  (short-lived connection just to enumerate tools)
# ---------------------------------------------------------------------------

async def _discover_sse_tools(config: dict) -> list:
    from mcp import ClientSession

    url = config.get("url", "")
    if not url:
        logger.warning("SSE MCP server: no 'url' in config")
        return []

    # Warm up (or reuse) the persistent session
    try:
        session_obj = _get_or_create_sse_session(url, config)
    except Exception as e:
        logger.exception(f"Could not connect to SSE MCP server {url}: {e}")
        return []

    # Short-lived connection only to list tools
    tools_list = []
    try:
        from mcp.client.streamable_http import streamable_http_client
        async with streamable_http_client(url) as (read, write, _):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                tools_list = result.tools
    except Exception:
        try:
            from mcp.client.sse import sse_client
            async with sse_client(url) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.list_tools()
                    tools_list = result.tools
        except Exception as e:
            logger.exception(f"Failed to list tools from SSE server {url}: {e}")
            return []

    return [_make_tool(tool, session_obj) for tool in tools_list]


async def _discover_stdio_tools(config: dict) -> list:
    from mcp import ClientSession
    from mcp.client.stdio import stdio_client, StdioServerParameters

    command = config.get("command", "")
    args = config.get("args", [])
    env = config.get("env")
    if not command:
        logger.warning("Stdio MCP server: no 'command' in config")
        return []

    # Warm up (or reuse) the persistent session
    try:
        session_obj = _get_or_create_stdio_session(command, args, env)
    except Exception as e:
        logger.exception(f"Could not connect to stdio MCP server {command!r}: {e}")
        return []

    # Short-lived second connection only to list tools
    params = StdioServerParameters(command=command, args=args, env=env)
    try:
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                tools_list = result.tools
    except Exception as e:
        logger.exception(f"Failed to list tools from stdio server {command!r}: {e}")
        return []

    return [_make_tool(tool, session_obj) for tool in tools_list]


# ---------------------------------------------------------------------------
# Tool factory
# ---------------------------------------------------------------------------

def _make_tool(mcp_tool: Any, session_obj: _PersistentSession) -> StructuredTool:
    """Create a LangChain tool that routes calls through the persistent session."""
    args_schema, tool_name, description = _extract_tool_meta(mcp_tool)

    def _call(**kwargs: Any) -> str:
        clean = {k: v for k, v in kwargs.items() if v is not None}
        try:
            return session_obj.call_tool(tool_name, clean)
        except Exception as e:
            logger.exception(f"MCP tool '{tool_name}' failed: {e}")
            return f"MCP tool error: {e}"

    return StructuredTool.from_function(
        func=_call,
        name=tool_name,
        description=description,
        args_schema=args_schema,
    )


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def _result_to_str(result: Any) -> str:
    if hasattr(result, "content"):
        parts = []
        for item in result.content:
            if hasattr(item, "text"):
                parts.append(item.text)
            else:
                parts.append(str(item))
        return "\n".join(parts) if parts else "OK"
    return str(result)


def _extract_tool_meta(mcp_tool: Any) -> tuple:
    name = mcp_tool.name
    description = mcp_tool.description or f"MCP tool: {name}"
    input_schema = mcp_tool.inputSchema or {}

    field_definitions: dict[str, Any] = {}
    props = input_schema.get("properties", {})
    required_fields = set(input_schema.get("required", []))

    for field_name, field_schema in props.items():
        field_type = _json_type_to_python(field_schema.get("type", "string"))
        if field_name in required_fields:
            field_definitions[field_name] = (field_type, ...)
        else:
            field_definitions[field_name] = (field_type | None, None)

    if not field_definitions:
        field_definitions["input"] = (str | None, None)

    try:
        schema = create_model(f"mcp_{name}_args", **field_definitions)
    except Exception:
        schema = create_model(f"mcp_{name}_args", input=(str | None, None))

    return schema, name, description


def _json_type_to_python(json_type: str) -> type:
    mapping = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }
    return mapping.get(json_type, str)
