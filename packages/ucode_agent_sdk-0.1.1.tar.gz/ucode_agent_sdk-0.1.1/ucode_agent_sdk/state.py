"""Pipeline state definition for LangGraph."""

from __future__ import annotations

from typing import Annotated, Any, TypedDict

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages


class PipelineState(TypedDict):
    """State that flows through a pipeline graph.

    Attributes:
        messages: Conversation history (uses LangGraph's add_messages reducer).
        user_input: The original user input that started this pipeline run.
        node_outputs: Mapping of node_id -> output from each executed node.
        current_node: ID of the currently executing node.
        interrupted: Whether the pipeline is currently interrupted.
        thread_id: Thread identifier for checkpointing.
    """

    messages: Annotated[list[BaseMessage], add_messages]
    user_input: str
    node_outputs: dict[str, Any]
    current_node: str
    interrupted: bool
    thread_id: str
