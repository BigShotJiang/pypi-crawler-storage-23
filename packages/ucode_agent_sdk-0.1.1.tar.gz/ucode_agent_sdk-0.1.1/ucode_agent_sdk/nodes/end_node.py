"""End node - marks pipeline completion."""

from __future__ import annotations

from typing import Any

from ucode_agent_sdk.nodes.registry import register_node_type
from ucode_agent_sdk.state import PipelineState


@register_node_type("end")
def create_end_node(node_config: dict[str, Any], **kwargs):
    """Create an end node function.

    The end node marks the pipeline as complete and records final status.
    """
    node_id = node_config["id"]

    async def end_node(state: PipelineState) -> dict:
        return {
            "current_node": node_id,
            "node_outputs": {
                **state.get("node_outputs", {}),
                node_id: {"status": "completed"},
            },
        }

    return end_node
