"""Conditional node - routes to different branches based on expressions."""

from __future__ import annotations

from typing import Any

from ucode_agent_sdk.nodes.registry import register_node_type
from ucode_agent_sdk.state import PipelineState


def _safe_eval(expression: str, context: dict[str, Any]) -> bool:
    """Safely evaluate a simple conditional expression.

    Supports:
    - String containment: "keyword" in output
    - Equality: output == "value"
    - Boolean: true/false
    - Default: always true
    """
    expression = expression.strip()

    if not expression or expression.lower() in ("true", "default"):
        return True
    if expression.lower() == "false":
        return False

    output = context.get("output", "")
    if not isinstance(output, str):
        output = str(output)

    # "keyword" in output
    if " in " in expression:
        parts = expression.split(" in ", 1)
        keyword = parts[0].strip().strip("\"'")
        return keyword.lower() in output.lower()

    # output == "value"
    if "==" in expression:
        parts = expression.split("==", 1)
        value = parts[1].strip().strip("\"'")
        return output.strip().lower() == value.lower()

    # output != "value"
    if "!=" in expression:
        parts = expression.split("!=", 1)
        value = parts[1].strip().strip("\"'")
        return output.strip().lower() != value.lower()

    return True


@register_node_type("conditional")
def create_conditional_node(node_config: dict[str, Any], **kwargs):
    """Create a conditional routing function.

    This returns a string label used by LangGraph's add_conditional_edges
    to route to the next node.

    Args:
        node_config: Node definition including:
            - id: Node identifier
            - data.conditions: List of {label, expression} dicts
    """
    node_id = node_config["id"]
    data = node_config.get("data", {})
    conditions = data.get("conditions", [])

    async def conditional_node(state: PipelineState) -> str:
        """Evaluate conditions and return the matching branch label."""
        # Get the last node's output for context
        node_outputs = state.get("node_outputs", {})

        # Find the most recent non-conditional output
        last_output = ""
        for nid in reversed(list(node_outputs.keys())):
            if nid != node_id and "output" in node_outputs.get(nid, {}):
                last_output = node_outputs[nid]["output"]
                break

        context = {"output": last_output}

        # Evaluate each condition in order
        for condition in conditions:
            label = condition.get("label", "default")
            expression = condition.get("expression", "true")
            if _safe_eval(expression, context):
                return label

        return "default"

    return conditional_node
