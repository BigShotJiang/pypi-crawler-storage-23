"""Agent node - invokes an agent (LLM call) within a pipeline."""

from __future__ import annotations

import os
from typing import Any

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from ucode_agent_sdk.nodes.registry import register_node_type
from ucode_agent_sdk.state import PipelineState


@register_node_type("agent")
def create_agent_node(node_config: dict[str, Any], **kwargs):
    """Create an agent node function.

    Args:
        node_config: Node definition from pipeline_schema, including:
            - id: Node identifier
            - data.agent_id: UUID of the agent to use
            - data.version_id: UUID of the agent version to use
            - data.label: Display label for this node
        **kwargs:
            - agent_loader: async callable(agent_id, version_id) -> dict
              Returns agent config with instructions, llm_settings, etc.
    """
    node_id = node_config["id"]
    data = node_config.get("data", {})
    agent_id = data.get("agent_id")
    version_id = data.get("version_id")
    label = data.get("label", node_id)
    agent_loader = kwargs.get("agent_loader")

    async def agent_node(state: PipelineState) -> dict:
        # Load agent config at runtime
        if agent_loader is None:
            raise RuntimeError(f"Agent node '{node_id}' requires an agent_loader")

        if not agent_id or not version_id:
            raise RuntimeError(f"Agent node '{node_id}' missing agent_id or version_id in data")

        config = await agent_loader(agent_id, version_id)

        instructions = config.get("instructions", "")
        llm_settings = config.get("llm_settings", {})

        deployment_name = llm_settings.get(
            "deployment_name",
            llm_settings.get("model_name", "gpt-4o-mini"),
        )
        max_tokens = llm_settings.get("max_tokens", 1024)
        temperature = llm_settings.get("temperature", 0.7)

        # Build messages for LLM call
        from langchain_openai import AzureChatOpenAI

        llm = AzureChatOpenAI(
            azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT", ""),
            api_key=os.environ.get("AZURE_OPENAI_API_KEY", ""),
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
            azure_deployment=deployment_name,
            temperature=temperature,
            extra_body={"max_tokens": max_tokens},
        )

        messages = []
        if instructions:
            messages.append(SystemMessage(content=instructions))

        # Add context from previous node outputs
        node_outputs = state.get("node_outputs", {})
        if node_outputs:
            context_parts = []
            for nid, output in node_outputs.items():
                if nid != node_id and isinstance(output, dict) and "output" in output:
                    context_parts.append(f"[{nid}]: {output['output']}")
            if context_parts:
                messages.append(SystemMessage(content="Previous node outputs:\n" + "\n".join(context_parts)))

        # Add conversation history
        for msg in state.get("messages", []):
            messages.append(msg)

        # Add user input if no messages yet
        if not state.get("messages"):
            messages.append(HumanMessage(content=state.get("user_input", "")))

        # Call LLM
        response = await llm.ainvoke(messages)
        output_text = response.content or ""

        return {
            "current_node": node_id,
            "messages": [AIMessage(content=output_text, name=label)],
            "node_outputs": {
                **node_outputs,
                node_id: {
                    "output": output_text,
                    "label": label,
                    "agent_id": agent_id,
                    "version_id": version_id,
                },
            },
        }

    return agent_node
