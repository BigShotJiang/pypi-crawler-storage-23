"""Start node - entry point of a pipeline."""

from __future__ import annotations

from typing import Any

from ucode_agent_sdk.nodes.registry import register_node_type
from ucode_agent_sdk.state import PipelineState


@register_node_type("start")
def create_start_node(node_config: dict[str, Any], **kwargs):
    """Create a start node function.

    The start node is a pass-through that sets the current_node
    and records that the pipeline has begun.
    """
    node_id = node_config["id"]

    async def start_node(state: PipelineState) -> dict:
        return {
            "current_node": node_id,
            "node_outputs": {
                **state.get("node_outputs", {}),
                node_id: {"status": "started"},
            },
        }

    return start_node
