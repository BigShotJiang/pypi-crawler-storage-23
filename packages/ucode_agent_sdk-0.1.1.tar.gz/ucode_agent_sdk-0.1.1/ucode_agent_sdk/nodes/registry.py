"""Node type registry for pipeline nodes."""

from __future__ import annotations

from typing import Any, Callable

_NODE_REGISTRY: dict[str, Callable] = {}


def register_node_type(type_name: str):
    """Decorator to register a node factory.

    Usage:
        @register_node_type("agent")
        def create_agent_node(node_config, **kwargs):
            async def node_fn(state):
                ...
            return node_fn
    """
    def decorator(factory: Callable) -> Callable:
        _NODE_REGISTRY[type_name] = factory
        return factory
    return decorator


def get_node_factory(type_name: str) -> Callable:
    """Look up a node factory by type name."""
    if type_name not in _NODE_REGISTRY:
        raise ValueError(f"Unknown node type: {type_name}. Registered: {list(_NODE_REGISTRY.keys())}")
    return _NODE_REGISTRY[type_name]


def list_node_types() -> list[str]:
    """List all registered node types."""
    return list(_NODE_REGISTRY.keys())
