"""ucode-agent-sdk – agent execution library for UCode."""

__version__ = "0.1.0"

from ucode_agent_sdk.agent import (
    AgentExecutor,
    RunResult,
    run,
    # Stream event types
    StreamEvent,
    MessageEvent,
    ToolCallEvent,
    ToolResultEvent,
    DoneEvent,
    ErrorEvent,
)
from ucode_agent_sdk.graph import build_graph, build_single_agent_graph
from ucode_agent_sdk.pipeline_executor import PipelineExecutor
from ucode_agent_sdk.state import PipelineState
from ucode_agent_sdk.nodes.registry import register_node_type
from ucode_agent_sdk.tools.registry import get_toolkit_tools

__all__ = [
    "AgentExecutor",
    "RunResult",
    "run",
    "build_graph",
    "build_single_agent_graph",
    # Pipeline
    "PipelineExecutor",
    "PipelineState",
    "register_node_type",
    # Stream events
    "StreamEvent",
    "MessageEvent",
    "ToolCallEvent",
    "ToolResultEvent",
    "DoneEvent",
    "ErrorEvent",
    # Tools
    "get_toolkit_tools",
]
