"""Graph builder - compiles pipeline schemas into LangGraph StateGraphs."""

from __future__ import annotations

import os
from typing import Any, Callable

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END

from ucode_agent_sdk.state import PipelineState
from ucode_agent_sdk.nodes import get_node_factory


def build_graph(
    pipeline_schema: dict[str, Any],
    agent_loader: Callable | None = None,
    checkpointer: Any = None,
) -> Any:
    """Build a compiled LangGraph graph from a pipeline schema.

    Args:
        pipeline_schema: Dict with nodes, edges, metadata from PipelineVersion.
        agent_loader: Async callable (agent_id, version_id) -> config dict.
            Required for pipelines with agent nodes.
        checkpointer: Optional LangGraph checkpointer for persistence.

    Returns:
        A compiled StateGraph ready for invocation.
    """
    nodes = pipeline_schema.get("nodes", [])
    edges = pipeline_schema.get("edges", [])
    metadata = pipeline_schema.get("metadata", {})

    # Build lookup tables
    node_map = {n["id"]: n for n in nodes}
    entry_point = metadata.get("entry_point", "start")
    interrupt_before = metadata.get("interrupt_before", [])
    interrupt_after = metadata.get("interrupt_after", [])

    # Build edge adjacency: source -> [targets]
    outgoing_edges: dict[str, list[dict]] = {}
    for edge in edges:
        src = edge["source"]
        outgoing_edges.setdefault(src, []).append(edge)

    # Create the StateGraph
    graph = StateGraph(PipelineState)

    # Identify end nodes (will map to LangGraph END)
    end_node_ids = {n["id"] for n in nodes if n["type"] == "end"}
    conditional_node_ids = {n["id"]
                            for n in nodes if n["type"] == "conditional"}

    # Add nodes (except end nodes which map to END)
    for node in nodes:
        nid = node["id"]
        ntype = node["type"]

        if ntype == "end":
            # End nodes still need to run their function, then route to END
            factory = get_node_factory(ntype)
            node_fn = factory(node, agent_loader=agent_loader)
            graph.add_node(nid, node_fn)
            continue

        if ntype == "conditional":
            # Conditional nodes are handled as routing functions, not graph nodes
            # But we still need a node to hold state
            async def _conditional_passthrough(state: PipelineState, _nid=nid) -> dict:
                return {"current_node": _nid}
            graph.add_node(nid, _conditional_passthrough)
            continue

        factory = get_node_factory(ntype)
        node_fn = factory(node, agent_loader=agent_loader)
        graph.add_node(nid, node_fn)

    # Set entry point
    graph.set_entry_point(entry_point)

    # Add edges
    for node in nodes:
        nid = node["id"]

        if nid in end_node_ids:
            # End nodes route to LangGraph END
            graph.add_edge(nid, END)
            continue

        if nid in conditional_node_ids:
            # Conditional nodes use add_conditional_edges
            factory = get_node_factory("conditional")
            routing_fn = factory(node, agent_loader=agent_loader)

            # Build path map from edges: sourceHandle (label) -> target node
            node_edges = outgoing_edges.get(nid, [])
            path_map = {}
            for edge in node_edges:
                handle = edge.get("sourceHandle", "default")
                target = edge["target"]
                path_map[handle] = target

            if path_map:
                graph.add_conditional_edges(nid, routing_fn, path_map)
            continue

        # Regular nodes: add edges to all targets
        node_edges = outgoing_edges.get(nid, [])
        if len(node_edges) == 1:
            target = node_edges[0]["target"]
            graph.add_edge(nid, target)
        elif len(node_edges) > 1:
            # Multiple outgoing edges from a non-conditional node
            # Use the first edge (pipeline should be well-formed)
            target = node_edges[0]["target"]
            graph.add_edge(nid, target)

    # Compile
    compile_kwargs = {}
    if checkpointer:
        compile_kwargs["checkpointer"] = checkpointer
    if interrupt_before:
        compile_kwargs["interrupt_before"] = interrupt_before
    if interrupt_after:
        compile_kwargs["interrupt_after"] = interrupt_after

    return graph.compile(**compile_kwargs)


def build_single_agent_graph(
    instructions: str,
    llm_settings: dict[str, Any],
    tools: list[dict[str, Any]] | None = None,
    checkpointer: Any = None,
) -> Any:
    """Build a simple one-node graph for single-agent execution.

    Backward-compatible with the existing AgentExecutor approach but
    using LangGraph for consistency.

    Args:
        instructions: System prompt for the agent.
        llm_settings: LLM configuration dict.
        tools: Optional list of tool configs (not yet used).
        checkpointer: Optional LangGraph checkpointer.

    Returns:
        A compiled StateGraph with a single agent node.
    """
    from langchain_openai import AzureChatOpenAI

    deployment_name = llm_settings.get(
        "deployment_name",
        llm_settings.get(
            "model_name", "anthropic.claude-haiku-4-5-20251001-v1:0"),
    )
    max_tokens = llm_settings.get("max_tokens", 1024)
    temperature = llm_settings.get("temperature", 0.7)

    llm = AzureChatOpenAI(
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT", ""),
        api_key=os.environ.get("AZURE_OPENAI_API_KEY", ""),
        api_version=os.environ.get(
            "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
        azure_deployment=deployment_name,
        temperature=temperature,
        extra_body={"max_tokens": max_tokens},
    )

    async def agent_node(state: PipelineState) -> dict:
        messages = []
        if instructions:
            messages.append(SystemMessage(content=instructions))

        for msg in state.get("messages", []):
            messages.append(msg)

        if not state.get("messages"):
            messages.append(HumanMessage(content=state.get("user_input", "")))

        response = await llm.ainvoke(messages)
        return {
            "messages": [response],
            "current_node": "agent",
            "node_outputs": {"agent": {"output": response.content or ""}},
        }

    graph = StateGraph(PipelineState)
    graph.add_node("agent", agent_node)
    graph.set_entry_point("agent")
    graph.add_edge("agent", END)

    compile_kwargs = {}
    if checkpointer:
        compile_kwargs["checkpointer"] = checkpointer

    return graph.compile(**compile_kwargs)
