"""Agent executor - main entry point for running agents.

Plain LLM call when no tools.
LangGraph ReAct loop with tool execution + streaming when tools are present.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Literal

from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage, SystemMessage
from openai import AsyncAzureOpenAI
from ucode_agent_sdk.prompts.personas import get_persona_prompt
from ucode_agent_sdk.state import PipelineState


@dataclass
class RunResult:
    """Result from agent execution."""

    output: str
    thread_id: str
    usage: dict | None = None


@dataclass
class StreamEvent:
    """Base class for stream events."""

    event_type: str


@dataclass
class MessageEvent(StreamEvent):
    """Content delta event."""

    event_type: Literal["message"] = "message"
    delta: str = ""


@dataclass
class ToolCallEvent(StreamEvent):
    """Tool call event — LLM decided to invoke a tool."""

    event_type: Literal["tool_call"] = "tool_call"
    tool_call_id: str = ""
    tool_name: str = ""
    tool_args: dict = field(default_factory=dict)


@dataclass
class ToolResultEvent(StreamEvent):
    """Tool result event — tool execution completed."""

    event_type: Literal["tool_result"] = "tool_result"
    tool_call_id: str = ""
    tool_name: str = ""
    result: str = ""
    is_error: bool = False


@dataclass
class DoneEvent(StreamEvent):
    """Stream completion event."""

    event_type: Literal["done"] = "done"
    output: str = ""
    thread_id: str = ""
    usage: dict | None = None


@dataclass
class ErrorEvent(StreamEvent):
    """Error event during streaming."""

    event_type: Literal["error"] = "error"
    code: str = ""
    message: str = ""


def _get_llm_params(llm_settings: dict) -> dict:
    """Extract common LLM parameters from settings."""
    return {
        "deployment_name": llm_settings.get(
            "deployment_name",
            llm_settings.get("model_name", "gpt-4o-mini"),
        ),
        "max_tokens": llm_settings.get("max_tokens", 1024),
        "temperature": llm_settings.get("temperature", 0.7),
    }


def _build_messages(
    instructions: str,
    user_input: str,
    history: list[dict[str, str]] | None = None,
) -> list[dict[str, str]]:
    """Build the messages list for the OpenAI API."""
    messages = []
    if instructions:
        messages.append({"role": "system", "content": instructions})
    if history:
        for msg in history:
            messages.append({"role": msg["role"], "content": msg["content"]})
    messages.append({"role": "user", "content": user_input})
    return messages


def _build_langchain_messages(
    instructions: str,
    user_input: str,
    history: list[dict[str, str]] | None = None,
) -> list:
    """Build LangChain message objects for the graph-based flow."""
    messages = []
    if instructions:
        messages.append(SystemMessage(content=instructions))
    if history:
        for msg in history:
            if msg["role"] == "user":
                messages.append(HumanMessage(content=msg["content"]))
            elif msg["role"] == "assistant":
                messages.append(AIMessage(content=msg["content"]))
            else:
                messages.append(SystemMessage(content=msg["content"]))
    messages.append(HumanMessage(content=user_input))
    return messages


_TOOL_USE_ADDENDUM = """

## Tool Use Policy
You have access to tools. Follow these rules without exception:
- When a user's request could be fulfilled by one of your tools, **always call the tool** — do not respond from memory or training data alone.
- Never say "I don't have access to real-time information", "I can't browse the internet", or "I lack the ability to X" when a relevant tool is available. Use the tool first, then respond.
- If multiple tools could help, prefer the most specific one.
- Only decline a tool call if no available tool is relevant to the request."""


def _build_react_graph(llm_with_tools, tools, instructions: str):
    """Build a LangGraph ReAct graph for tool-calling agents."""
    from langgraph.graph import StateGraph, END
    from langgraph.prebuilt import ToolNode

    tool_node = ToolNode(tools)

    async def agent_node(state: dict) -> dict:
        msgs = list(state.get("messages", []))
        if not any(isinstance(m, SystemMessage) for m in msgs):
            system_content = (instructions or "") + _TOOL_USE_ADDENDUM
            msgs.insert(0, SystemMessage(content=system_content.strip()))
        response = await llm_with_tools.ainvoke(msgs)
        return {"messages": [response]}

    def should_continue(state: dict) -> str:
        last = state["messages"][-1]
        if hasattr(last, "tool_calls") and last.tool_calls:
            return "tools"
        return END

    graph = StateGraph(PipelineState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", tool_node)
    graph.set_entry_point("agent")
    graph.add_conditional_edges("agent", should_continue, {
                                "tools": "tools", END: END})
    graph.add_edge("tools", "agent")
    return graph.compile()


@dataclass
class AgentExecutor:
    """Executes an agent given a version config.

    When tools are provided (list of LangChain BaseTool instances), the executor
    runs a LangGraph ReAct loop. Otherwise falls back to a plain LLM call.

    Args:
        instructions: User-defined agent instructions.
        llm_settings: LLM configuration (deployment, temperature, max_tokens).
        tools: LangChain BaseTool instances to expose to the agent.
        persona: Optional persona key (e.g. "default", "qa", "nerdy",
                 "cynical", "quirky"). The persona prompt is appended to
                 ``instructions`` at runtime.
    """

    instructions: str = ""
    llm_settings: dict[str, Any] = field(default_factory=dict)
    tools: list[Any] = field(default_factory=list)
    persona: str = ""

    def _effective_instructions(self) -> str:
        """Combine user instructions with the selected persona prompt."""
        base = self.instructions or ""
        persona_prompt = get_persona_prompt(self.persona)
        if persona_prompt:
            return base.rstrip() + "\n" + persona_prompt
        return base

    def run(
        self,
        user_input: str,
        thread_id: str | None = None,
        history: list[dict[str, str]] | None = None,
    ) -> RunResult:
        """Run agent synchronously."""
        import asyncio
        return asyncio.get_event_loop().run_until_complete(
            self.arun(user_input, thread_id, history)
        )

    async def arun(
        self,
        user_input: str,
        thread_id: str | None = None,
        history: list[dict[str, str]] | None = None,
    ) -> RunResult:
        """Run agent asynchronously."""
        if self.tools and _has_langchain_tools(self.tools):
            return await self._arun_with_tools(user_input, thread_id, history)
        return await self._arun_plain(user_input, thread_id, history)

    async def _arun_plain(
        self,
        user_input: str,
        thread_id: str | None = None,
        history: list[dict[str, str]] | None = None,
    ) -> RunResult:
        """Plain LLM call (no tools)."""
        params = _get_llm_params(self.llm_settings)

        client = AsyncAzureOpenAI(
            azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
            api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
            api_version=os.environ.get(
                "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
        )

        messages = _build_messages(
            self._effective_instructions(), user_input, history)

        response = await client.chat.completions.create(
            model=params["deployment_name"],
            messages=messages,
            max_tokens=params["max_tokens"],
            temperature=params["temperature"],
        )

        output = response.choices[0].message.content or ""
        usage = None
        if response.usage:
            usage = {
                "input_tokens": response.usage.prompt_tokens,
                "output_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            }

        return RunResult(
            output=output,
            thread_id=thread_id or "default",
            usage=usage,
        )

    async def _arun_with_tools(
        self,
        user_input: str,
        thread_id: str | None = None,
        history: list[dict[str, str]] | None = None,
    ) -> RunResult:
        """LangGraph ReAct loop with tool execution."""
        from langchain_openai import AzureChatOpenAI

        params = _get_llm_params(self.llm_settings)

        llm = AzureChatOpenAI(
            azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT", ""),
            api_key=os.environ.get("AZURE_OPENAI_API_KEY", ""),
            api_version=os.environ.get(
                "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
            azure_deployment=params["deployment_name"],
            temperature=params["temperature"],
            max_tokens=params["max_tokens"],
        )

        compiled = _build_react_graph(llm.bind_tools(
            self.tools), self.tools, self._effective_instructions())
        messages = _build_langchain_messages(
            self._effective_instructions(), user_input, history)
        result = await compiled.ainvoke({"messages": messages})

        final_messages = result.get("messages", [])
        output = ""
        for msg in reversed(final_messages):
            if isinstance(msg, AIMessage) and msg.content and not getattr(msg, "tool_calls", None):
                output = msg.content
                break

        return RunResult(
            output=output,
            thread_id=thread_id or "default",
            usage=None,
        )

    async def arun_stream(
        self,
        user_input: str,
        thread_id: str | None = None,
        history: list[dict[str, str]] | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """Run agent with streaming output, including tool call events."""
        if self.tools and _has_langchain_tools(self.tools):
            async for event in self._arun_stream_with_tools(user_input, thread_id, history):
                yield event
        else:
            async for event in self._arun_stream_plain(user_input, thread_id, history):
                yield event

    async def _arun_stream_plain(
        self,
        user_input: str,
        thread_id: str | None = None,
        history: list[dict[str, str]] | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """Streaming without tools — direct OpenAI streaming."""
        params = _get_llm_params(self.llm_settings)

        client = AsyncAzureOpenAI(
            azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
            api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
            api_version=os.environ.get(
                "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
        )

        messages = _build_messages(
            self._effective_instructions(), user_input, history)

        try:
            stream = await client.chat.completions.create(
                model=params["deployment_name"],
                messages=messages,
                max_tokens=params["max_tokens"],
                temperature=params["temperature"],
                stream=True,
            )

            full_output = ""
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    delta = chunk.choices[0].delta.content
                    full_output += delta
                    yield MessageEvent(delta=delta)

            yield DoneEvent(
                output=full_output,
                thread_id=thread_id or "default",
                usage=None,
            )

        except Exception as e:
            yield ErrorEvent(code="stream_error", message=str(e))

    async def _arun_stream_with_tools(
        self,
        user_input: str,
        thread_id: str | None = None,
        history: list[dict[str, str]] | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """Streaming ReAct loop — yields tool_call, tool_result, and message events."""
        try:
            from langchain_openai import AzureChatOpenAI
            from langchain_core.messages import ToolMessage

            params = _get_llm_params(self.llm_settings)

            llm = AzureChatOpenAI(
                azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT", ""),
                api_key=os.environ.get("AZURE_OPENAI_API_KEY", ""),
                api_version=os.environ.get(
                    "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
                azure_deployment=params["deployment_name"],
                temperature=params["temperature"],
                max_tokens=params["max_tokens"],
            )

            compiled = _build_react_graph(
                llm.bind_tools(
                    self.tools), self.tools, self._effective_instructions()
            )
            messages = _build_langchain_messages(
                self._effective_instructions(), user_input, history)

            full_output = ""

            async for event in compiled.astream_events(
                {"messages": messages}, version="v2"
            ):
                kind = event["event"]

                if kind == "on_chat_model_end":
                    msg = event["data"]["output"]
                    if isinstance(msg, AIMessage) and msg.tool_calls:
                        for tc in msg.tool_calls:
                            yield ToolCallEvent(
                                tool_call_id=tc.get("id", ""),
                                tool_name=tc.get("name", ""),
                                tool_args=tc.get("args", {}),
                            )

                elif kind == "on_chat_model_stream":
                    chunk = event["data"]["chunk"]
                    if isinstance(chunk, AIMessageChunk) and chunk.content:
                        tc_chunks = getattr(chunk, "tool_call_chunks", None)
                        if not tc_chunks:
                            full_output += chunk.content
                            yield MessageEvent(delta=chunk.content)

                elif kind == "on_tool_end":
                    output = event["data"].get("output", "")
                    if isinstance(output, ToolMessage):
                        yield ToolResultEvent(
                            tool_call_id=output.tool_call_id or "",
                            tool_name=output.name or event.get("name", ""),
                            result=str(output.content),
                            is_error=output.status == "error" if hasattr(
                                output, "status") else False,
                        )
                    else:
                        yield ToolResultEvent(
                            tool_call_id="",
                            tool_name=event.get("name", ""),
                            result=str(output),
                        )

            yield DoneEvent(
                output=full_output,
                thread_id=thread_id or "default",
                usage=None,
            )

        except Exception as e:
            yield ErrorEvent(code="tool_stream_error", message=str(e))


def _has_langchain_tools(tools: list) -> bool:
    """Check if tools list contains LangChain BaseTool instances (not raw dicts)."""
    if not tools:
        return False
    from langchain_core.tools import BaseTool
    return any(isinstance(t, BaseTool) for t in tools)


async def run(
    instructions: str,
    user_input: str,
    llm_settings: dict | None = None,
    tools: list | None = None,
    thread_id: str | None = None,
    persona: str = "",
) -> RunResult:
    """Convenience function to run an agent."""
    executor = AgentExecutor(
        instructions=instructions,
        llm_settings=llm_settings or {},
        tools=tools or [],
        persona=persona,
    )
    return await executor.arun(user_input, thread_id)
