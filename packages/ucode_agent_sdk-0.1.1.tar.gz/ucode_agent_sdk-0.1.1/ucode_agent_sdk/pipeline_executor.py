"""Pipeline executor - runs full pipeline graphs."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable

from langchain_core.messages import HumanMessage

from ucode_agent_sdk.agent import RunResult, StreamEvent, MessageEvent, DoneEvent, ErrorEvent
from ucode_agent_sdk.graph import build_graph
from ucode_agent_sdk.state import PipelineState


@dataclass
class PipelineExecutor:
    """Executes a pipeline defined by a pipeline_schema.

    The pipeline_schema contains nodes, edges, and metadata as defined
    in PipelineVersion.pipeline_schema. Agent nodes load their configs
    at runtime via the agent_loader callable.

    Args:
        pipeline_schema: The pipeline graph definition.
        agent_loader: Async callable (agent_id, version_id) -> config dict.
        checkpointer: Optional LangGraph checkpointer for persistence.
    """

    pipeline_schema: dict[str, Any] = field(default_factory=dict)
    agent_loader: Callable | None = None
    checkpointer: Any = None

    async def arun(
        self,
        user_input: str,
        thread_id: str | None = None,
    ) -> RunResult:
        """Run the pipeline to completion.

        Args:
            user_input: The user's message.
            thread_id: Optional thread identifier for checkpointing.

        Returns:
            RunResult with the final output.
        """
        thread_id = thread_id or str(uuid.uuid4())

        compiled_graph = build_graph(
            pipeline_schema=self.pipeline_schema,
            agent_loader=self.agent_loader,
            checkpointer=self.checkpointer,
        )

        initial_state: PipelineState = {
            "messages": [HumanMessage(content=user_input)],
            "user_input": user_input,
            "node_outputs": {},
            "current_node": "",
            "interrupted": False,
            "thread_id": thread_id,
        }

        config = {"configurable": {"thread_id": thread_id}}

        try:
            result = await compiled_graph.ainvoke(initial_state, config=config)

            # Extract final output from the last message or node_outputs
            output = ""
            if result.get("messages"):
                # Get the last AI message
                for msg in reversed(result["messages"]):
                    if hasattr(msg, "content") and msg.content:
                        output = msg.content
                        break

            if not output and result.get("node_outputs"):
                # Fallback: get last node output
                for nid in reversed(list(result["node_outputs"].keys())):
                    node_out = result["node_outputs"][nid]
                    if isinstance(node_out, dict) and "output" in node_out:
                        output = node_out["output"]
                        break

            return RunResult(
                output=output,
                thread_id=thread_id,
                usage=None,
            )

        except Exception as e:
            return RunResult(
                output=f"Pipeline execution error: {e}",
                thread_id=thread_id,
                usage=None,
            )

    async def arun_stream(
        self,
        user_input: str,
        thread_id: str | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """Run the pipeline with streaming output.

        Yields MessageEvent for content from agent nodes, then DoneEvent.

        Args:
            user_input: The user's message.
            thread_id: Optional thread identifier.

        Yields:
            StreamEvent instances (MessageEvent, DoneEvent, ErrorEvent).
        """
        thread_id = thread_id or str(uuid.uuid4())

        try:
            compiled_graph = build_graph(
                pipeline_schema=self.pipeline_schema,
                agent_loader=self.agent_loader,
                checkpointer=self.checkpointer,
            )

            initial_state: PipelineState = {
                "messages": [HumanMessage(content=user_input)],
                "user_input": user_input,
                "node_outputs": {},
                "current_node": "",
                "interrupted": False,
                "thread_id": thread_id,
            }

            config = {"configurable": {"thread_id": thread_id}}

            full_output = ""

            async for event in compiled_graph.astream_events(
                initial_state, config=config, version="v2"
            ):
                kind = event.get("event", "")

                # Capture chat model stream events
                if kind == "on_chat_model_stream":
                    chunk = event.get("data", {}).get("chunk")
                    if chunk and hasattr(chunk, "content") and chunk.content:
                        delta = chunk.content
                        full_output += delta
                        yield MessageEvent(delta=delta)

                # Capture node completion for non-streaming info
                elif kind == "on_chain_end":
                    pass  # Node completed

            yield DoneEvent(
                output=full_output,
                thread_id=thread_id,
                usage=None,
            )

        except Exception as e:
            yield ErrorEvent(
                code="pipeline_error",
                message=str(e),
            )
