from ucode_agent_sdk import AgentExecutor


def test_agent_stub():
    agent = AgentExecutor(instructions="You are a helper.")
    result = agent.run("hello")
    assert "hello" in result
