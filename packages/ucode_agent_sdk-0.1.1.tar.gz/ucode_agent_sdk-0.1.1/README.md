# ucode-agent-sdk

Agent execution SDK for **UCode**. Wraps LangGraph for building and running agents, pipelines, and (later) multi-agent systems.

Published to **private PyPI**. Consumed by the **ucode runner**.

## Install

```bash
pip install -e ".[dev]"
```

## Test

```bash
pytest
```

## Layout

```
ucode_agent_sdk/
  __init__.py       Package exports
  agent.py          AgentExecutor – main entry point for the runner
  graph.py          build_graph – compiles LangGraph from version config
tests/
```

## What this will do (later phases)

- Build LangGraph graphs from agent version config (instructions, LLM settings, tools)
- Support single-agent, pipeline (with interrupt/continue), and multi-agent modes
- Tool resolution, MCP integration, checkpoint management
- Streaming output (content deltas, interrupt events, done)
