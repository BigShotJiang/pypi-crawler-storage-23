---
name: ceo-web-search
description: Step 3 — web search for commercial roles, board memberships, and news.
---

# Step 3: Web Search for Commercial Roles

Run these searches using `WebSearch` (use the exact `author_name`):

1. `"[name]" CEO OR founder OR "co-founder"`
2. `"[name]" "board of directors" OR "advisory board" company`
3. `"[name]" "[institution]" spin-off OR startup`
4. `"[name]" LinkedIn` — if accessible via WebFetch, check the Experience section.

**Counts as evidence:** company website, press release, or LinkedIn listing an executive, founder,
or director role at a private company.

**Ignore:** journal editorial boards, grant review panels, conference sponsorships, and funding acknowledgements.

Record the source URL and a brief quote for any positive finding.
