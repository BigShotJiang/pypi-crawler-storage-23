---
name: ceo-paper-fetcher
description: Helper — access paper content from a DOI to retrieve COI sections.
---

# Paper Fetcher: Access Paper Content

For each DOI from Step 1, try in order until one works:

1. `WebFetch("https://doi.org/[DOI]")` — journal landing page (abstract + section headers usually visible)
2. `WebFetch("https://europepmc.org/search?query=DOI:[DOI]")` — open-access full text
3. `WebFetch("https://pubmed.ncbi.nlm.nih.gov/?term=[DOI]")` — and follow any PMC link

If a page is inaccessible, note it and move on. Do not infer anything from inaccessibility alone.
