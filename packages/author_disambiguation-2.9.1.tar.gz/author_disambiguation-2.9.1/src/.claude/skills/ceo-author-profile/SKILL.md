---
name: ceo-author-profile
description: Step 1 — get the author's OpenAlex profile and recent papers.
---

# Step 1: Get Author Profile and Recent Papers

1. Call `mcp__openalex_mcp__get_author_details(author_id=openalex_author_id)`.
   Note: current institution name/type, h-index, research topics.

2. Call `mcp__openalex_mcp__get_author_recent_works(author_id=openalex_author_id, per_page=10)`.
   For each work, collect the DOI (needed for Step 2) and note any co-affiliation with a private company.

Flag immediately if:
- The current institution is a company (not a university, hospital, or government lab).
- Any paper lists the author with both an academic AND a company affiliation.
