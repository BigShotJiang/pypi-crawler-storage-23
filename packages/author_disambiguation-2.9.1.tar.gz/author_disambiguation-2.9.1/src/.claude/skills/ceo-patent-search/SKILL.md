---
name: ceo-patent-search
description: Step 4 (optional) — search patent databases for patents assigned to private companies.
---

# Step 4: Patent Search

Only run this step when `use_patents=true` is set. Skip entirely otherwise.

Search for patents where the researcher is named as inventor:

1. `WebFetch("https://patents.google.com/?inventor=[FirstName+LastName]")`
2. `WebSearch("\"[name]\" inventor patent")` as a fallback.

**Counts as evidence:** a patent where the **assignee is a private company** (not a university or government lab).

**Does NOT count:** patents assigned to a university or listed as unassigned.

Record the patent title, assignee, year, and URL for any relevant finding.
