---
name: ceo-coi-reader
description: Step 2 — read Conflict of Interest sections from the fetched papers.
---

# Step 2: Read COI Sections

For each paper fetched in Step 1 (using the paper-fetcher skill), look for a section headed:
"Conflict of Interest", "Competing Interests", "Disclosure", or "Financial Interests".

**Counts as evidence:**
- Co-founder, CEO, board member, shareholder, or employee of a private company.
- Consulting fees or equity in a private company.

**Does NOT count:**
- "No competing interests declared."
- Funding from a company (funding ≠ role).
- Advisory boards for journals, universities, or grant bodies.

Record the exact quoted text and company name for any positive finding.
