#!/usr/bin/env python3
"""
CEO / Commercial-Interest Check Agent

Given an OpenAlex author ID (and optionally the author's name), searches for
evidence that the researcher holds executive roles, board positions, equity
stakes, or patents in commercial entities.

Sources searched (via modular skills):
  Step 1 — ceo-author-profile:  OpenAlex author profile and recent papers
  Step 2 — ceo-paper-fetcher:   Access paper full text / landing pages from DOIs
           ceo-coi-reader:      Conflict of Interest sections of recent papers
  Step 3 — ceo-web-search:      Web search for commercial roles, boards, news
  Step 4 — ceo-patent-search:   Patent databases (optional; off by default)

Output:
  {
    "possibility_of_ceo": true | false | null,
    "comment": "Detailed explanation of what was found and why",
    "_metadata": { ... }
  }

  possibility_of_ceo values:
    true  — evidence of commercial role / patent with a company assignee was found
    false — no evidence found after thorough search
    null  — search was inconclusive (access errors, too little info, ambiguous name)
"""

import os
import sys
import json
import asyncio
from dotenv import load_dotenv

from claude_agent_sdk import (
    ClaudeSDKClient,
    ClaudeAgentOptions,
)

# Add src directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from openalex_mcp import OPENALEX_MCP_OPTIONS

load_dotenv()

# ── Skill loading ────────────────────────────────────────────────────────────

_SKILLS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".claude", "skills")

# Ordered list of skills that make up each research step
_CORE_SKILLS = [
    "ceo-author-profile",   # Step 1 — OpenAlex profile
    "ceo-paper-fetcher",    # Helper — access paper content
    "ceo-coi-reader",       # Step 2 — COI sections
    "ceo-web-search",       # Step 3 — web search
]

_PATENT_SKILL = "ceo-patent-search"  # Step 4 — optional


def _load_skill(skill_name: str) -> str:
    """Load and return the body of a SKILL.md file (strips YAML front-matter)."""
    skill_file = os.path.join(_SKILLS_DIR, skill_name, "SKILL.md")
    if not os.path.exists(skill_file):
        return f"[Warning: skill '{skill_name}' not found at {skill_file}]"
    with open(skill_file, "r", encoding="utf-8") as f:
        content = f.read()
    # Strip YAML front-matter block (--- ... ---)
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            content = parts[2].strip()
    return content


def build_ceo_system_prompt(use_patents: bool = False) -> str:
    """
    Assemble the CEO-check system prompt from individual skill files.

    Each skill file contains one self-contained step.  Embedding their content
    directly into the prompt ensures the agent always has the full instructions,
    regardless of SDK skill-loading behaviour.

    Args:
        use_patents: When True, includes Step 4 (patent search) in the prompt.

    Returns:
        A complete system prompt string.
    """
    skill_names = list(_CORE_SKILLS)
    if use_patents:
        skill_names.append(_PATENT_SKILL)

    skill_blocks = "\n\n---\n\n".join(_load_skill(s) for s in skill_names)

    patent_note = (
        "\n- **Step 4 (patents)** is **enabled** for this run — complete it after Step 3."
        if use_patents
        else "\n- **Step 4 (patent search) is disabled** for this run — skip it entirely."
    )

    return f"""# Commercial Interest & CEO Check Agent

Your job is to determine whether a life-sciences researcher has **commercial interests** —
such as company executive roles (CEO, CTO, CSO, COO), board memberships in private companies,
co-founder / investor positions, or patents assigned to a private company.
Return a brief, structured JSON result.

## Input Fields

You will receive:
- `openalex_author_id`: The OpenAlex author ID (e.g. "A5074091984")
- `author_name`: Full name of the researcher (for web searches)

## Search Strategy

Follow the steps described in the skill sections below **in order**.{patent_note}

{skill_blocks}

---

## Decision Rules

Set `possibility_of_ceo` to:
- **true** if ANY of the following are found:
  - A named executive / founder / board role at a private company in a COI section or credible web source
  - A patent assigned to a private company with the researcher as inventor (only if Step 4 is enabled)
  - A company listed under their LinkedIn "Experience" in a non-academic role
- **false** if no evidence is found after completing all applicable steps
- **null** if the search could not be completed reliably (access errors on most sources,
  very common name with too many ambiguous results, etc.)

## CRITICAL: Output Format

Return ONLY valid JSON in this exact format — no prose, no markdown fences:

{{
  "possibility_of_ceo": true,
  "comment": "Found COI disclosure in Smith 2023 (doi:10.1234/xyz) stating 'J. Smith is a board member of BioTech Inc. and holds equity in Pharma Co.' Also confirmed via web search: appointed CEO of BioTech Inc. in 2021 (source: www.biotech.com/news/ceo-appointment)."
}}

or if nothing found:

{{
  "possibility_of_ceo": false,
  "comment": "No commercial roles found. COI sections in 5 recent papers state no competing interests. Web searches for CEO, founder, board member, and advisory roles returned no relevant results."
}}

## CRITICAL Rules

1. **NEVER skip the COI search** — it is the most reliable source.
2. **Only count credible sources**: COI disclosures, company websites, press releases, official registries.
   Do NOT count unverified forum posts or social media speculation.
3. **Academic advisory boards** (journals, grant bodies, universities) are NOT commercial interests.
4. **University-assigned patents** are NOT commercial interests — only count patents assigned to private companies.
5. Output must be valid JSON with exactly the two fields shown above.
"""


# ── JSON output schema ────────────────────────────────────────────────────────

CEO_RESULT_SCHEMA = {
    "type": "object",
    "properties": {
        "possibility_of_ceo": {
            "type": ["boolean", "null"],
            "description": "True if commercial interest evidence found, false if none found, null if inconclusive",
        },
        "comment": {
            "type": "string",
            "description": "Detailed explanation of search findings and reasoning",
        },
    },
    "required": ["possibility_of_ceo", "comment"],
}


# ── Main agent function ───────────────────────────────────────────────────────

async def check_ceo_status(
    openalex_author_id: str,
    author_name: str = None,
    use_patents: bool = False,
    max_iterations: int = 20,
    max_concurrent: int = None,
) -> dict:
    """
    Check whether a researcher has commercial interests (CEO, board member, patents, etc.).

    Args:
        openalex_author_id: OpenAlex author ID, e.g. "A5074091984"
        author_name:        Full name of the researcher (improves web search quality)
        use_patents:        When True, enables Step 4 (patent database search).
                            Disabled by default because patent searches are slow.
        max_iterations:     Maximum agent iterations (default: 20 — CEO search is web-heavy)
        max_concurrent:     Maximum concurrent SDK initialisations (default: None for single call)

    Returns:
        Dict with keys:
          - "possibility_of_ceo": bool | None
          - "comment": str
          - "_metadata": dict with iteration and token stats
    """
    if not openalex_author_id:
        raise ValueError("openalex_author_id is required")

    system_prompt = build_ceo_system_prompt(use_patents=use_patents)

    user_message = "Check the commercial interests of this researcher:\n\n"
    user_message += f"openalex_author_id: {openalex_author_id}\n"
    if author_name:
        user_message += f"author_name: {author_name}\n"

    print(f"\n{'='*80}")
    print("CEO / COMMERCIAL INTEREST CHECK")
    print(f"{'='*80}")
    print(f"OpenAlex ID : {openalex_author_id}")
    if author_name:
        print(f"Name        : {author_name}")
    print(f"Patent step : {'enabled' if use_patents else 'disabled'}")
    print(f"{'='*80}\n")

    agent_options = ClaudeAgentOptions(
        mcp_servers=OPENALEX_MCP_OPTIONS.mcp_servers,
        allowed_tools=OPENALEX_MCP_OPTIONS.allowed_tools,
        system_prompt=system_prompt,
        output_format=CEO_RESULT_SCHEMA,
    )

    stats = {"input_tokens": 0, "output_tokens": 0, "iterations": 0}
    all_text = ""
    final_json = None

    try:
        async def _run():
            nonlocal all_text
            async with ClaudeSDKClient(options=agent_options) as client:
                await client.query(user_message)
                all_text = ""
                async for message in client.receive_response():
                    stats["iterations"] += 1

                    if hasattr(message, "content"):
                        for block in message.content:
                            block_type = type(block).__name__
                            if block_type == "TextBlock" and hasattr(block, "text"):
                                print(block.text)
                                all_text += block.text
                            elif block_type == "ToolUseBlock":
                                print(f"[Tool: {getattr(block, 'name', '?')}]")
                            elif hasattr(block, "type") and block.type == "text":
                                print(block.text)
                                all_text += block.text

                    if hasattr(message, "usage"):
                        if hasattr(message.usage, "input_tokens"):
                            stats["input_tokens"] += message.usage.input_tokens
                        if hasattr(message.usage, "output_tokens"):
                            stats["output_tokens"] += message.usage.output_tokens

                # Parse JSON from collected text
                text = all_text.strip()
                if text.startswith("```json"):
                    text = text[7:]
                elif text.startswith("```"):
                    text = text[3:]
                if text.endswith("```"):
                    text = text[:-3]
                text = text.strip()

                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    import re
                    m = re.search(r"\{.*\}", text, re.DOTALL)
                    if m:
                        try:
                            return json.loads(m.group())
                        except Exception:
                            pass
                return None

        if max_concurrent is not None:
            sem = asyncio.Semaphore(max_concurrent)
            async with sem:
                final_json = await _run()
        else:
            final_json = await _run()

    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
        return {
            "possibility_of_ceo": None,
            "comment": f"Search failed due to an error: {e}",
            "_metadata": {
                "openalex_author_id": openalex_author_id,
                "author_name": author_name,
                "use_patents": use_patents,
                "iterations": stats["iterations"],
                "stats": stats,
            },
        }

    if not final_json:
        final_json = {
            "possibility_of_ceo": None,
            "comment": f"Could not parse agent response. Raw text: {all_text[:500]}",
        }

    final_json["_metadata"] = {
        "openalex_author_id": openalex_author_id,
        "author_name": author_name,
        "use_patents": use_patents,
        "iterations": stats["iterations"],
        "stats": stats,
    }
    return final_json


# ── CLI entry point ───────────────────────────────────────────────────────────

def main():
    """CLI entry point."""
    if len(sys.argv) < 2:
        print("Usage: check-ceo-status --id <openalex_id> [OPTIONS]")
        print("\nRequired:")
        print('  --id "A5074091984"     OpenAlex author ID')
        print("\nOptions:")
        print('  --name "Full Name"     Author name (improves web search quality)')
        print('  --patents              Enable patent search (Step 4, slower)')
        print("\nExamples:")
        print('  check-ceo-status --id "A5074091984"')
        print('  check-ceo-status --id "A5074091984" --name "Yves-Alain Barde"')
        print('  check-ceo-status --id "A5074091984" --name "Yves-Alain Barde" --patents')
        sys.exit(1)

    openalex_id = None
    author_name = None
    use_patents = False

    i = 1
    while i < len(sys.argv):
        if sys.argv[i] == "--id" and i + 1 < len(sys.argv):
            openalex_id = sys.argv[i + 1]
            i += 2
        elif sys.argv[i] == "--name" and i + 1 < len(sys.argv):
            author_name = sys.argv[i + 1]
            i += 2
        elif sys.argv[i] == "--patents":
            use_patents = True
            i += 1
        else:
            i += 1

    if not openalex_id:
        print("Error: --id is required")
        sys.exit(1)

    try:
        result = asyncio.run(check_ceo_status(
            openalex_author_id=openalex_id,
            author_name=author_name,
            use_patents=use_patents,
        ))

        print(f"\n{'='*80}")
        print("CEO / COMMERCIAL INTEREST RESULT")
        print(f"{'='*80}\n")
        print(json.dumps(result, indent=2))
        print(f"\n{'='*80}\n")

        name_for_file = (author_name or openalex_id).replace(" ", "_")
        output_file = f"ceo_result_{name_for_file}.json"
        with open(output_file, "w") as f:
            json.dump(result, f, indent=2)
        print(f"Saved to: {output_file}\n")

    except KeyboardInterrupt:
        print("\nInterrupted")
        sys.exit(1)
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
