#!/usr/bin/env python3
"""
PubPeer Search

Direct HTTP function (no agent) to check whether OpenAlex works have
PubPeer comments.

PubPeer does not expose a public JSON API, but its Vue.js frontend uses
an internal endpoint:

    GET https://pubpeer.com/api/search/?q={raw_doi}&token={csrf}

A CSRF token (rotating, session-scoped) is extracted from the home page
on first use and reused for all subsequent requests in the same process.

A paper is considered "in PubPeer" (has_comments=True) only when
``comments_total > 0`` in the response. Papers are indexed by PubPeer
even without comments, so an indexed-but-silent paper is treated as
not having PubPeer discussion.

Accepts either:
  - OpenAlex Work  ID (W*): returns boolean + details for one work
  - OpenAlex Author ID (A*): returns all author works with status for
    each
"""

import os
import re
import sys
import json
import time
import asyncio
import html as _html
import requests
from typing import Optional, List, Dict, Any

import pyalex
from pyalex import Works, Authors
from dotenv import load_dotenv

load_dotenv()

PUBPEER_BASE_URL = "https://pubpeer.com"
PUBPEER_API_PATH = "/api/search/"
PUBPEER_SEARCH_URL = "https://pubpeer.com/search"
PUBPEER_REQUEST_TIMEOUT = 20

DEFAULT_DELAY = 0.5   # seconds between API calls

# Module-level session + CSRF cache (reused across calls in same process)
_session: Optional[requests.Session] = None
_csrf_token: Optional[str] = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _init_pyalex() -> None:
    """Configure pyalex with the polite-pool email."""
    email = os.getenv("OPENALEX_API_KEY")
    if not email:
        raise ValueError(
            "OPENALEX_API_KEY environment variable must be set "
            "(your email address for polite pool access)."
        )
    pyalex.config.email = email


def _normalize_doi(doi: Optional[str]) -> Optional[str]:
    """Strip doi.org prefix, returning the raw DOI string."""
    if not doi:
        return None
    for prefix in ("https://doi.org/", "http://doi.org/"):
        if doi.startswith(prefix):
            return doi[len(prefix):]
    return doi


def _get_session() -> tuple:
    """
    Return (session, csrf_token), initialising if necessary.

    Fetches the PubPeer home page once per process to obtain a rotating
    CSRF token stored in ``window.App.csrfToken``.
    """
    global _session, _csrf_token
    if _session is not None and _csrf_token:
        return _session, _csrf_token

    sess = requests.Session()
    sess.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120 Safari/537.36"
        ),
        "Accept-Language": "en-US,en;q=0.9",
    })
    try:
        resp = sess.get(PUBPEER_BASE_URL + "/", timeout=PUBPEER_REQUEST_TIMEOUT)
        m = re.search(r'"csrfToken":"([^"]+)"', resp.text)
        if not m:
            raise ValueError("CSRF token not found in PubPeer home page")
        _session = sess
        _csrf_token = m.group(1)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to initialise PubPeer session: {exc}"
        ) from exc

    return _session, _csrf_token


def _check_pubpeer_doi(doi: str) -> Dict[str, Any]:
    """
    Query the PubPeer internal search API for a single DOI.

    Returns a dict with:
      - in_pubpeer:    bool | None  (None on error)
      - comment_count: int
      - pubpeer_url:   str | None   (direct URL if comments found)
      - error:         str | None   (only on failure)
    """
    raw_doi = _normalize_doi(doi)
    if not raw_doi:
        return {
            "in_pubpeer": None,
            "comment_count": 0,
            "pubpeer_url": None,
            "error": "Empty DOI",
        }

    search_url = f"{PUBPEER_SEARCH_URL}?q={raw_doi}"

    try:
        sess, csrf = _get_session()
        api_url = (
            f"{PUBPEER_BASE_URL}{PUBPEER_API_PATH}"
            f"?q={raw_doi}&token={csrf}"
        )
        resp = sess.get(
            api_url,
            timeout=PUBPEER_REQUEST_TIMEOUT,
            headers={
                "Accept": "application/json",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": search_url,
            },
        )
    except Exception as exc:
        return {
            "in_pubpeer": None,
            "comment_count": 0,
            "pubpeer_url": None,
            "error": str(exc),
        }

    if resp.status_code != 200:
        return {
            "in_pubpeer": None,
            "comment_count": 0,
            "pubpeer_url": None,
            "error": f"HTTP {resp.status_code}",
        }

    try:
        data = resp.json()
    except ValueError:
        return {
            "in_pubpeer": None,
            "comment_count": 0,
            "pubpeer_url": None,
            "error": "Invalid JSON response",
        }

    pubs = data.get("publications", [])
    if not pubs:
        return {
            "in_pubpeer": False,
            "comment_count": 0,
            "pubpeer_url": None,
        }

    # Papers with comments_total > 0 have actual PubPeer discussion
    pub = pubs[0]
    comment_count = pub.get("comments_total", 0) or 0
    if comment_count > 0:
        link = pub.get("link_with_hash", "")
        pub_url = (
            f"{PUBPEER_BASE_URL}{link}" if link else search_url
        )
        return {
            "in_pubpeer": True,
            "comment_count": comment_count,
            "pubpeer_url": pub_url,
        }

    return {
        "in_pubpeer": False,
        "comment_count": 0,
        "pubpeer_url": None,
    }


# ---------------------------------------------------------------------------
# Public function
# ---------------------------------------------------------------------------

def search_in_pubpeer(
    openalex_id: str,
    max_works: Optional[int] = None,
    delay: float = DEFAULT_DELAY,
) -> Dict[str, Any]:
    """
    Check whether OpenAlex work(s) have PubPeer comments.

    Uses the PubPeer internal API (session-based CSRF token, no login
    required). Only papers with at least one comment are reported as
    ``in_pubpeer: true``.

    Args:
        openalex_id: Either:
            - OpenAlex Work  ID (starts with "W"): check one work
            - OpenAlex Author ID (starts with "A"): check all works
        max_works: For author IDs — limit works checked (default: all).
        delay: Seconds between API calls (default: 0.5).

    Returns:
        For a Work ID:
            {
              "openalex_id":        "W...",
              "doi":                str | null,
              "title":              str,
              "year":               int | null,
              "in_pubpeer":         bool | null,
              "comment_count":      int,
              "pubpeer_url":        str | null,
              "pubpeer_search_url": str | null,
            }

        For an Author ID:
            {
              "author_id":           "A...",
              "author_name":         str | null,
              "total_works_checked": int,
              "works_in_pubpeer":    int,
              "works": [
                {
                  "openalex_id":   "W...",
                  "doi":           str | null,
                  "title":         str,
                  "year":          int | null,
                  "in_pubpeer":    bool | null,
                  "comment_count": int,
                  "pubpeer_url":   str | null,
                },
                ...
              ]
            }
    """
    _init_pyalex()

    clean_id = openalex_id.strip()

    # ------------------------------------------------------------------
    # Work ID branch (W*)
    # ------------------------------------------------------------------
    if clean_id.startswith("W") or "openalex.org/W" in clean_id:
        normalized = (
            clean_id if clean_id.startswith("https://")
            else f"https://openalex.org/{clean_id}"
        )
        try:
            work = Works()[normalized]
        except Exception as exc:
            return {
                "openalex_id": clean_id,
                "error": f"Work not found: {exc}",
                "in_pubpeer": None,
            }

        doi = work.get("doi")
        raw_doi = _normalize_doi(doi)
        work_id = work.get("id", "").split("/")[-1]

        if doi:
            pp = _check_pubpeer_doi(doi)
        else:
            pp = {
                "in_pubpeer": None,
                "comment_count": 0,
                "pubpeer_url": None,
                "error": "No DOI available",
            }

        result: Dict[str, Any] = {
            "openalex_id": work_id,
            "doi": doi,
            "title": work.get("title", ""),
            "year": work.get("publication_year"),
            "in_pubpeer": pp["in_pubpeer"],
            "comment_count": pp.get("comment_count", 0),
            "pubpeer_url": pp.get("pubpeer_url"),
            "pubpeer_search_url": (
                f"{PUBPEER_SEARCH_URL}?q={raw_doi}" if raw_doi else None
            ),
        }
        if pp.get("error"):
            result["error"] = pp["error"]
        return result

    # ------------------------------------------------------------------
    # Author ID branch (A*)
    # ------------------------------------------------------------------
    elif clean_id.startswith("A") or "openalex.org/A" in clean_id:
        normalized = (
            clean_id if clean_id.startswith("https://")
            else f"https://openalex.org/{clean_id}"
        )
        short_id = normalized.split("/")[-1]

        author_name: Optional[str] = None
        try:
            author_name = Authors()[normalized].get("display_name")
        except Exception:
            pass

        all_works: List[Dict[str, Any]] = []
        try:
            for page in (
                Works()
                .filter(authorships={"author": {"id": normalized}})
                .sort(publication_date="desc")
                .paginate(per_page=200)
            ):
                for w in page:
                    all_works.append(w)
                    if max_works and len(all_works) >= max_works:
                        break
                if max_works and len(all_works) >= max_works:
                    break
        except Exception as exc:
            return {
                "author_id": short_id,
                "author_name": author_name,
                "error": f"Failed to retrieve works: {exc}",
                "total_works_checked": 0,
                "works_in_pubpeer": 0,
                "works": [],
            }

        entries: List[Dict[str, Any]] = []
        works_in_pubpeer = 0

        for w in all_works:
            doi = w.get("doi")
            raw_doi = _normalize_doi(doi)
            work_id = w.get("id", "").split("/")[-1]

            if doi:
                pp = _check_pubpeer_doi(doi)
                if delay > 0:
                    time.sleep(delay)
            else:
                pp = {
                    "in_pubpeer": None,
                    "comment_count": 0,
                    "pubpeer_url": None,
                }

            if pp.get("in_pubpeer") is True:
                works_in_pubpeer += 1

            entry: Dict[str, Any] = {
                "openalex_id": work_id,
                "doi": doi,
                "title": w.get("title", ""),
                "year": w.get("publication_year"),
                "in_pubpeer": pp["in_pubpeer"],
                "comment_count": pp.get("comment_count", 0),
                "pubpeer_url": pp.get("pubpeer_url"),
            }
            if not entry["pubpeer_url"] and raw_doi:
                entry["pubpeer_search_url"] = (
                    f"{PUBPEER_SEARCH_URL}?q={raw_doi}"
                )
            if pp.get("error"):
                entry["error"] = pp["error"]
            entries.append(entry)

        return {
            "author_id": short_id,
            "author_name": author_name,
            "total_works_checked": len(entries),
            "works_in_pubpeer": works_in_pubpeer,
            "works": entries,
        }

    # ------------------------------------------------------------------
    # Unrecognised ID format
    # ------------------------------------------------------------------
    else:
        return {
            "error": (
                f"Invalid OpenAlex ID format: '{openalex_id}'. "
                "Must start with 'A' (author) or 'W' (work)."
            )
        }


# ---------------------------------------------------------------------------
# AI-based comment analysis
# ---------------------------------------------------------------------------

# PubPeer is a Vue.js SPA — WebFetch on a publication URL returns only
# "Loading...".  We instead use the same internal JSON API that the SPA
# itself calls to retrieve the comment bodies, then pass the raw text to
# Claude directly (no agent / no WebFetch needed).

_COMMENT_ANALYSIS_SYSTEM_PROMPT = """You are a scientific integrity analyst.

You will be given the raw text of PubPeer comments for a scientific paper.
Classify the primary concern and write a brief summary.

Classify as ONE of:
- "data_integrity"    — image manipulation, band splicing, data fabrication, plagiarism, or falsification.
- "data_presentation" — concerns about statistics, figure labelling, unclear methods, or misleading presentation (but not outright fraud).
- "novelty"           — comments questioning whether the findings are truly new or merely reproduce prior work.
- "other"             — comments that do not fit any of the above (e.g. authorship disputes, errata, general discussion).

If multiple concerns exist, pick the most serious one and mention the others in the summary.

Return ONLY valid JSON — no prose, no markdown fences:

{"type": "data_integrity", "summary": "Two comments raise concerns about Western blot band splicing in Figures 2 and 4."}
"""


def _extract_pub_id_from_url(pubpeer_url: str) -> Optional[str]:
    """
    Extract the PubPeer publication hash from a URL.

    e.g. "https://pubpeer.com/publications/E2D1D5F580D8571DF5EA6523563554#0"
         → "E2D1D5F580D8571DF5EA6523563554"
    """
    without_fragment = pubpeer_url.split("#")[0].rstrip("/")
    parts = without_fragment.split("/")
    return parts[-1] if parts else None


def _fetch_pubpeer_comment_text(pub_id: str) -> str:
    """
    Fetch raw comment text by parsing the PubPeer publication HTML page.

    PubPeer server-renders all comment data into the HTML as a JSON-encoded
    Vue component prop on the ``<comment-timeline>`` element:

        <comment-timeline :data-comments="[{&quot;id&quot;:...,&quot;markdown&quot;:&quot;...&quot;}]" ...>

    We extract that attribute, HTML-unescape it, and JSON-decode it to get
    the ``markdown`` field of each comment — clean plain text, no HTML tags.

    Returns all comment bodies joined by separators, or an empty string on
    failure.
    """
    try:
        sess, _ = _get_session()
        url = f"{PUBPEER_BASE_URL}/publications/{pub_id}"
        resp = sess.get(
            url,
            timeout=PUBPEER_REQUEST_TIMEOUT,
            headers={"Accept": "text/html", "Referer": PUBPEER_BASE_URL},
        )
        if resp.status_code != 200:
            return ""

        # The attribute value uses &quot; as the inner quote, so the outer "
        # delimiter is unambiguous — safe to match greedily up to the next ".
        m = re.search(r':data-comments="(\[.*?\])"', resp.text, re.DOTALL)
        if not m:
            return ""

        # HTML-unescape converts &quot;→" &lt;→< &#039;→' &amp;→& etc.
        json_str = _html.unescape(m.group(1))
        comments = json.loads(json_str)

        texts = []
        for c in comments:
            # Prefer the pre-rendered plain-text markdown field
            text = c.get("markdown") or ""
            if not text:
                # Fall back to stripping HTML tags from the html field
                raw_html = c.get("html") or ""
                text = re.sub(r"<[^>]+>", " ", raw_html).strip()
            text = text.strip()
            if text:
                texts.append(text)

        return "\n\n---\n\n".join(texts)
    except Exception:
        return ""


async def analyze_pubpeer_comments(
    pubpeer_url: str,
    paper_title: str = None,
) -> Dict[str, Any]:
    """
    Fetch and classify PubPeer comments for one paper.

    Uses the PubPeer internal JSON API to retrieve comment text (bypassing
    the Vue.js SPA that WebFetch cannot render), then calls the Anthropic
    API directly to classify and summarise the discussion.

    Args:
        pubpeer_url:  Direct URL to the PubPeer page (from search_in_pubpeer result).
        paper_title:  Optional title for context.

    Returns:
        {
          "type":    "data_integrity" | "data_presentation" | "novelty" | "other",
          "summary": "Brief description of what the comments say."
        }
        or {"error": "..."} on failure.
    """
    import anthropic  # local import — not required for the non-analysis path

    pub_id = _extract_pub_id_from_url(pubpeer_url)
    if not pub_id:
        return {
            "type": "other",
            "summary": "Could not extract publication ID from URL.",
            "error": "invalid_url",
        }

    comment_text = _fetch_pubpeer_comment_text(pub_id)
    if not comment_text:
        return {
            "type": "other",
            "summary": "Could not retrieve comment text from PubPeer API.",
            "error": "no_comment_text",
        }

    user_content = (
        f"Paper: {paper_title or 'Unknown'}\n\n"
        f"PubPeer comments:\n\n{comment_text}"
    )

    try:
        client = anthropic.AsyncAnthropic()
        response = await client.messages.create(
            model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-5"),
            max_tokens=300,
            system=_COMMENT_ANALYSIS_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_content}],
        )

        text = response.content[0].text.strip()
        if text.startswith("```json"):
            text = text[7:]
        elif text.startswith("```"):
            text = text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        try:
            return json.loads(text)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", text, re.DOTALL)
            if m:
                try:
                    return json.loads(m.group())
                except Exception:
                    pass
        return {"type": "other", "summary": text[:300], "error": "json_parse_failed"}

    except Exception as exc:
        return {"error": str(exc)}


async def search_and_analyze_pubpeer(
    openalex_id: str,
    max_works: Optional[int] = None,
    delay: float = DEFAULT_DELAY,
) -> Dict[str, Any]:
    """
    Like search_in_pubpeer, but adds AI-based comment analysis for every
    paper that has PubPeer mentions.

    For each paper where ``in_pubpeer=True``, a ``comment_analysis`` field
    is added:

        "comment_analysis": {
          "type":    "data_integrity" | "data_presentation" | "novelty" | "other",
          "summary": "Brief description of the comments."
        }

    Args:
        openalex_id: OpenAlex Work ID (W*) or Author ID (A*).
        max_works:   For author IDs — limit the number of works checked.
        delay:       Seconds between PubPeer API calls (default: 0.5).

    Returns:
        Same structure as search_in_pubpeer, with ``comment_analysis`` added
        to any paper that has PubPeer comments.
    """
    result = search_in_pubpeer(openalex_id, max_works=max_works, delay=delay)

    # Single Work ID branch
    if "doi" in result and result.get("in_pubpeer") and result.get("pubpeer_url"):
        result["comment_analysis"] = await analyze_pubpeer_comments(
            result["pubpeer_url"],
            paper_title=result.get("title"),
        )

    # Author ID branch — enrich each positive paper
    elif "works" in result:
        for work in result["works"]:
            if work.get("in_pubpeer") and work.get("pubpeer_url"):
                work["comment_analysis"] = await analyze_pubpeer_comments(
                    work["pubpeer_url"],
                    paper_title=work.get("title"),
                )

    return result


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    """CLI entry point for the search-pubpeer command."""
    if len(sys.argv) < 2:
        print("Usage: search-pubpeer --id <OPENALEX_ID> [OPTIONS]")
        print("\nRequired:")
        print('  --id "A5074091984"     OpenAlex Author ID  (A*)')
        print('  --id "W1234567890"     OpenAlex Work   ID  (W*)')
        print("\nOptions:")
        print(
            "  --max-works N    "
            "Limit works checked for author ID (default: all)"
        )
        print(
            "  --delay SECONDS  "
            "Delay between PubPeer requests (default: 0.5)"
        )
        print(
            "  --analyze        "
            "Use AI to classify and summarise each PubPeer discussion"
        )
        print("\nExamples:")
        print('  search-pubpeer --id "W1234567890"')
        print('  search-pubpeer --id "A5074091984"')
        print('  search-pubpeer --id "A5074091984" --max-works 50')
        print('  search-pubpeer --id "A5074091984" --max-works 10 --analyze')
        sys.exit(1)

    openalex_id = None
    max_works: Optional[int] = None
    delay = DEFAULT_DELAY
    analyze = False

    i = 1
    while i < len(sys.argv):
        if sys.argv[i] == "--id" and i + 1 < len(sys.argv):
            openalex_id = sys.argv[i + 1]
            i += 2
        elif sys.argv[i] == "--max-works" and i + 1 < len(sys.argv):
            max_works = int(sys.argv[i + 1])
            i += 2
        elif sys.argv[i] == "--delay" and i + 1 < len(sys.argv):
            delay = float(sys.argv[i + 1])
            i += 2
        elif sys.argv[i] == "--analyze":
            analyze = True
            i += 1
        else:
            i += 1

    if not openalex_id:
        print("Error: --id is required")
        sys.exit(1)

    print(f"\n{'='*80}")
    print("PUBPEER SEARCH")
    print(f"{'='*80}")
    print(f"OpenAlex ID : {openalex_id}")
    if max_works:
        print(f"Max works   : {max_works}")
    print(f"AI analysis : {'enabled' if analyze else 'disabled'}")
    print(f"{'='*80}\n")

    try:
        if analyze:
            result = asyncio.run(search_and_analyze_pubpeer(
                openalex_id=openalex_id,
                max_works=max_works,
                delay=delay,
            ))
        else:
            result = search_in_pubpeer(
                openalex_id=openalex_id,
                max_works=max_works,
                delay=delay,
            )

        print(f"\n{'='*80}")
        print("PUBPEER RESULT")
        print(f"{'='*80}\n")
        print(json.dumps(result, indent=2))
        print(f"\n{'='*80}\n")

        safe_id = openalex_id.replace("/", "_").replace(":", "_")
        output_file = f"pubpeer_{safe_id}.json"
        with open(output_file, "w") as f:
            json.dump(result, f, indent=2)
        print(f"Saved to: {output_file}\n")

    except KeyboardInterrupt:
        print("\nInterrupted")
        sys.exit(1)
    except Exception as exc:
        print(f"\nError: {exc}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
