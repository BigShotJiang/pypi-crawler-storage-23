# sage_setup: distribution = sagemath-database-stein-watkins-mini

from sage.all__sagemath_database_stein_watkins_mini import *
