# t14go-conta-letra

CLI para contar caracteres ou apenas letras em textos multilinha.
