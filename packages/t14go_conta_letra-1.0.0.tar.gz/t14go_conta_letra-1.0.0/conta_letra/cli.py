#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aplicativo CLI para contagem de caracteres ou letras em um texto.

Nome: conta-letra
Descrição: Programa que conta caracteres totais ou apenas letras de um texto multilinha.
Compatibilidade: Termux, Pydroid 3, PC (qualquer terminal que execute Python 3)
"""

import sys


def exibir_titulo():
    """
    Exibe o título do programa no início da execução.
    O título é exibido com emoji para visualização melhor no terminal.
    """
    print("📝 CONTA-LETRA")
    print("=" * 40)
    print()


def obter_opcao():
    """
    Solicita ao usuário que escolha o tipo de contagem.
    
    Retorna:
        int: 0 para contar todos os caracteres, 1 para contar apenas letras
    
    O loop continua até que o usuário informe uma opção válida (0 ou 1).
    """
    # Loop para garantir que o usuário informe uma opção válida
    while True:
        # Exibe as opções disponíveis
        print("Escolha o tipo de contagem:")
        print("  0 → Contar TODOS os caracteres")
        print("  1 → Contar APENAS letras")
        print()
        
        # Solicita a opção do usuário
        opcao = input("Digite sua opção (0 ou 1): ").strip()
        
        # Verifica se a opção é válida
        if opcao == "0":
            return 0
        elif opcao == "1":
            return 1
        else:
            # Mensagem de erro para opção inválida
            print()
            print("⚠️ Opção inválida. Escolha 0 ou 1.")
            print()


def obter_texto_multilinha():
    """
    Obtém texto multilinha do usuário.
    
    O usuário pode colar ou digitar várias linhas de texto.
    A entrada é encerrada quando o usuário pressiona ENTER em uma linha vazia
    (após ter colado o texto completo).
    
    Retorna:
        str: O texto informado pelo usuário
    
    Limite:
        O programa aceita até 50.000 caracteres. Se o texto exceder esse limite,
        uma mensagem de aviso será exibida.
    """
    print("Cole ou digite seu texto (pressione ENTER em linha vazia para finalizar):")
    print("-" * 40)
    
    # Lista para armazenar todas as linhas digitadas
    linhas = []
    
    # Loop para ler linhas de texto
    # O usuário pode colar texto multilinha e pressionar ENTER em linha vazia para encerrar
    while True:
        try:
            # Lê cada linha do texto
            linha = sys.stdin.readline()
            
            # Se a linha for None, significa EOF (fim de arquivo)
            if linha is None:
                break
            
            # Remove o caractere de nova linha no final
            linha = linha.rstrip('\n')
            
            # Se a linha estiver vazia e já temos conteúdo, encerra a entrada
            # Isso permite que o usuário pressione ENTER em linha vazia para finalizar
            if linha == '' and linhas:
                break
            
            # Adiciona a linha à lista (incluindo a quebra de linha para preservar formato)
            linhas.append(linha + '\n')
            
        except EOFError:
            # Tratamento para quando há EOF (fim da entrada)
            break
        except KeyboardInterrupt:
            # Tratamento para quando o usuário pressiona Ctrl+C
            print("\n\nOperação cancelada pelo usuário.")
            sys.exit(0)
    
    # Concatena todas as linhas em uma única string
    texto = ''.join(linhas)
    
    # Remove a última quebra de linha se existir (para textos que terminam com ENTER)
    if texto.endswith('\n'):
        texto = texto[:-1]
    
    return texto


def validar_limite(texto):
    """
    Valida se o texto está dentro do limite de 50.000 caracteres.
    
    Argumentos:
        texto (str): O texto a ser validado
    
    Retorna:
        bool: True se o texto estiver dentro do limite, False caso contrário
    
    Se o texto exceder o limite, uma mensagem de aviso é exibida.
    """
    LIMITE_MAXIMO = 50000  # Limite de 50.000 caracteres
    tamanho = len(texto)
    
    if tamanho > LIMITE_MAXIMO:
        print()
        print(f"⚠️ Erro: Texto excede {LIMITE_MAXIMO} caracteres.")
        print(f"   Tamanho atual: {tamanho} caracteres")
        print("   Por favor, reduza o tamanho do texto e tente novamente.")
        return False
    
    return True


def contar_todos_caracteres(texto):
    """
    Conta todos os caracteres do texto, incluindo espaços e quebras de linha.
    
    Argumentos:
        texto (str): O texto a ser analisado
    
    Retorna:
        int: O número total de caracteres no texto
    """
    return len(texto)


def contar_apenas_letras(texto):
    """
    Conta apenas os caracteres alfabéticos (letras) no texto.
    
    Ignora: espaços, números, pontuação e símbolos.
    Utiliza o método isalpha() para identificar letras.
    
    Argumentos:
        texto (str): O texto a ser analisado
    
    Retorna:
        int: O número de letras no texto
    """
    contador = 0
    
    # Itera por cada caractere do texto
    for caractere in texto:
        # Verifica se o caractere é uma letra (alfabético)
        if caractere.isalpha():
            contador += 1
    
    return contador


def exibir_resultado(tipo_contagem, quantidade):
    """
    Exibe o resultado da contagem de acordo com o tipo escolhido.
    
    Argumentos:
        tipo_contagem (int): 0 para todos os caracteres, 1 para apenas letras
        quantidade (int): A quantidade contada
    """
    print()
    
    if tipo_contagem == 0:
        # Exibe o total de todos os caracteres
        print(f"📊 Total de caracteres: {quantidade}")
    else:
        # Exibe o total apenas de letras
        print(f"📊 Total de letras: {quantidade}")


def main():
    """
    Função principal do programa que coordena toda a execução.
    
    Fluxo de execução:
        1. Exibe o título do programa
        2. Obtém a opção de contagem do usuário
        3. Obtém o texto multilinha do usuário
        4. Valida o limite de caracteres
        5. Realiza a contagem sesuai a opção escolhida
        6. Exibe o resultado
    
    Esta é a função de entrada do programa.
    """
    # Passo 1: Exibe o título
    exibir_titulo()
    
    # Passo 2: Obtém a opção de contagem
    opcao = obter_opcao()
    
    # Passo 3: Obtém o texto do usuário
    texto = obter_texto_multilinha()
    
    # Passo 4: Valida o limite de caracteres
    if not validar_limite(texto):
        # Encerra o programa se o texto exceder o limite
        sys.exit(1)
    
    # Passo 5: Realiza a contagem conforme a opção
    if opcao == 0:
        # Conta todos os caracteres
        resultado = contar_todos_caracteres(texto)
    else:
        # Conta apenas letras
        resultado = contar_apenas_letras(texto)
    
    # Passo 6: Exibe o resultado
    exibir_resultado(opcao, resultado)


# Ponto de entrada do programa
# Garante que main() seja chamada apenas quando o arquivo for executado diretamente,
# e não quando for importado como módulo
if __name__ == "__main__":
    main()
