from maxo.routing.signals.base import BaseSignal


class BeforeStartup(BaseSignal):
    pass


class AfterStartup(BaseSignal):
    pass
