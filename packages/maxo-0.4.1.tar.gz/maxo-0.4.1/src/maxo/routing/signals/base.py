from maxo.routing.updates.base import BaseUpdate


class BaseSignal(BaseUpdate):
    pass
