"""Network connectivity and API health utilities."""

import socket
import requests
from typing import Optional, Dict
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class NetworkStatus:
    """Track network connectivity status."""

    _last_check: Optional[datetime] = None
    _is_online: bool = True
    _check_interval_seconds: int = 60  # Cache status for 1 minute

    @classmethod
    def is_online(cls, force_check: bool = False) -> bool:
        """
        Check if network is available.

        Args:
            force_check: Force immediate check, bypass cache

        Returns:
            True if online, False if offline
        """
        now = datetime.now()

        # Use cached result if recent
        if not force_check and cls._last_check:
            if (now - cls._last_check).total_seconds() < cls._check_interval_seconds:
                return cls._is_online

        # Perform actual connectivity check
        cls._is_online = cls._check_internet_connection()
        cls._last_check = now

        return cls._is_online

    @classmethod
    def _check_internet_connection(cls) -> bool:
        """
        Check internet connectivity using multiple methods.

        Returns:
            True if connected, False otherwise
        """
        # Method 1: Try to resolve a reliable domain
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            pass

        # Method 2: Try HTTP HEAD request to reliable endpoint
        try:
            response = requests.head("https://www.google.com", timeout=3)
            return response.status_code < 500
        except Exception:
            pass

        return False

    @classmethod
    def check_api_health(cls, url: str, timeout: int = 5) -> bool:
        """
        Check if specific API endpoint is reachable.

        Args:
            url: API base URL to check
            timeout: Request timeout in seconds

        Returns:
            True if API is healthy, False otherwise
        """
        try:
            response = requests.head(url, timeout=timeout)
            return response.status_code < 500
        except Exception as e:
            logger.debug(f"API health check failed for {url}: {e}")
            return False


class APIErrorHandler:
    """Centralized API error handling with retry logic."""

    def __init__(self, max_retries: int = 3, backoff_factor: float = 1.5):
        """
        Initialize error handler.

        Args:
            max_retries: Maximum number of retry attempts
            backoff_factor: Exponential backoff multiplier
        """
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.error_counts: Dict[str, int] = {}
        self.last_errors: Dict[str, datetime] = {}

    def should_retry(self, api_name: str, error: Exception) -> bool:
        """
        Determine if request should be retried.

        Args:
            api_name: Name of API endpoint
            error: Exception that occurred

        Returns:
            True if retry is recommended
        """
        # Don't retry if offline
        if not NetworkStatus.is_online():
            return False

        # Retry on network errors
        if isinstance(error, (requests.ConnectionError, requests.Timeout)):
            return True

        # Retry on server errors (5xx)
        if isinstance(error, requests.HTTPError):
            if error.response and error.response.status_code >= 500:
                return True

        return False

    def throttle_errors(self, api_name: str, threshold: int = 5, window_seconds: int = 300) -> bool:
        """
        Throttle error logging to prevent spam.

        Args:
            api_name: API endpoint name
            threshold: Max errors before throttling
            window_seconds: Time window for counting errors

        Returns:
            True if error should be logged, False if throttled
        """
        now = datetime.now()

        # Reset counter if outside window
        if api_name in self.last_errors:
            elapsed = (now - self.last_errors[api_name]).total_seconds()
            if elapsed > window_seconds:
                self.error_counts[api_name] = 0

        # Increment counter
        self.error_counts[api_name] = self.error_counts.get(api_name, 0) + 1
        self.last_errors[api_name] = now

        # Allow logging if under threshold
        return self.error_counts[api_name] <= threshold


__all__ = [
    'NetworkStatus',
    'APIErrorHandler',
]
