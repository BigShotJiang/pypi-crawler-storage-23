"""Server middleware - authentication, etc."""
