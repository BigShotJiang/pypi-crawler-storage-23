# Security Policy

## Supported Versions

| Component | Minimum Supported Version |
|-----------|--------------------------|
| FAVA Trails | 0.4.0+ |
| Python | 3.11+ |
| JJ (Jujutsu) | 0.28.0+ |

Older versions do not receive security updates. Please upgrade to the latest release.

## Reporting a Vulnerability

**Do not report security vulnerabilities via public GitHub Issues.**

Please use [GitHub Security Advisories](https://github.com/MachineWisdomAI/fava-trails/security/advisories/new) to report vulnerabilities privately. This allows us to investigate and prepare a fix before public disclosure.

Include in your report:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

We will acknowledge your report within 48 hours and aim to release a fix within 14 days for critical issues.
