"""Compatibility module for HTTP client exports."""

from databricks_api.http_client import HttpClient

__all__ = ["HttpClient"]
