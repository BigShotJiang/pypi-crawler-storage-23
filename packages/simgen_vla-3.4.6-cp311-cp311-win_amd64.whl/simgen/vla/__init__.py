"""
VLA - VIGIL Lossless Arithmetic
================================
Zero-error GPU compute for scientific computing.

Usage:
    from simgen import vla

    # Enable globally (patches torch ops)
    vla.enable()

    # Or use directly
    result = vla.sum(tensor)      # Exact sum
    result = vla.matmul(a, b)     # Exact matmul
    result = vla.dot(a, b)        # Exact dot product
"""

import torch
from typing import Optional

# Import from the runtime module
from ..vla_runtime import (
    # Version
    __version__ as _runtime_version,
    # Reproducibility & Verification (KILLER FEATURE)
    vla_checksum, vla_verify, vla_checksum_hex, VLAVerifiedResult,
    # Core reductions
    vla_sum, vla_mean, vla_var, vla_std, vla_norm,
    vla_prod, vla_cumsum, vla_logsumexp,
    vla_min, vla_max, vla_argmin, vla_argmax,
    # TRUE ZERO ERROR functions (return Decimal)
    vla_sum_exact, vla_dot_exact, vla_mean_exact, vla_matmul_exact,
    vla_var_exact, vla_std_exact, vla_norm_exact, vla_prod_exact,
    vla_cumsum_exact, vla_trace_exact, vla_bmm_exact, vla_logsumexp_exact,
    # Matrix ops
    vla_dot, vla_matmul, vla_bmm, vla_linear,
    # Convolution (signal processing)
    vla_conv2d, vla_conv_transpose2d,
    # Einsum
    vla_einsum,
    # Element-wise arithmetic
    vla_add, vla_sub, vla_mul, vla_div, vla_neg, vla_abs,
    vla_pow, vla_clamp, vla_fmod,
    # Transcendental
    vla_exp, vla_log, vla_sqrt, vla_rsqrt,
    # Trigonometric
    vla_sin, vla_cos, vla_tan,
    vla_asin, vla_acos, vla_atan, vla_atan2,
    # Hyperbolic
    vla_sinh, vla_cosh, vla_tanh,
    # Rounding
    vla_floor, vla_ceil, vla_round, vla_trunc,
    # Sign and comparison
    vla_sign, vla_eq, vla_ne, vla_lt, vla_le, vla_gt, vla_ge,
    vla_where,
    # Basic activations
    vla_relu, vla_sigmoid, vla_leaky_relu,
    # Signal processing
    vla_fft, vla_ifft, vla_rfft, vla_irfft,
    # Linear algebra
    vla_trace, vla_det, vla_inv, vla_solve,
    # Loss (general regression)
    vla_mse_loss,
    # Utility
    VLAResult,
    get_backend_info,
)

# Auto-shape module for universal drop-in
from .auto import enable_auto, disable_auto, auto_mode

_enabled = False
_original_ops = {}


# =============================================================================
# Clean API wrappers (remove vla_ prefix)
# =============================================================================

# Core reductions
def sum(x: torch.Tensor, dim: Optional[int] = None, keepdim: bool = False,
        return_vla: bool = False, exact: bool = True) -> torch.Tensor:
    """Exact sum with zero accumulation error."""
    return vla_sum(x, dim=dim, keepdim=keepdim, return_vla=return_vla, exact=exact)

def mean(x: torch.Tensor, dim: Optional[int] = None, keepdim: bool = False) -> torch.Tensor:
    """Exact mean."""
    return vla_mean(x, dim=dim, keepdim=keepdim)

def var(x: torch.Tensor, unbiased: bool = True) -> torch.Tensor:
    """Exact variance."""
    return vla_var(x, unbiased=unbiased)

def std(x: torch.Tensor, unbiased: bool = True) -> torch.Tensor:
    """Exact standard deviation."""
    return vla_std(x, unbiased=unbiased)

def norm(x: torch.Tensor, p: int = 2) -> torch.Tensor:
    """Exact Lp norm."""
    return vla_norm(x, p=p)

def prod(x: torch.Tensor) -> torch.Tensor:
    """Exact product."""
    return vla_prod(x)

def cumsum(x: torch.Tensor, dim: int = 0) -> torch.Tensor:
    """Exact cumulative sum."""
    return vla_cumsum(x)

def logsumexp(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """Numerically stable log-sum-exp."""
    return vla_logsumexp(x)

def min(x: torch.Tensor, dim: Optional[int] = None) -> torch.Tensor:
    """Min reduction."""
    return vla_min(x)

def max(x: torch.Tensor, dim: Optional[int] = None) -> torch.Tensor:
    """Max reduction."""
    return vla_max(x)

# Matrix ops
def dot(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False, exact: bool = True):
    """Exact dot product with zero accumulation error."""
    return vla_dot(a, b, return_vla=return_vla, exact=exact)

def matmul(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False):
    """Matrix multiplication with exact accumulation."""
    return vla_matmul(a, b, return_vla=return_vla)

def mm(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False):
    """Alias for matmul."""
    return vla_matmul(a, b, return_vla=return_vla)

def bmm(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False):
    """Batched matrix multiplication."""
    return vla_bmm(a, b, return_vla=return_vla)

def linear(x: torch.Tensor, weight: torch.Tensor, bias: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Linear layer: y = xW^T + b."""
    return vla_linear(x, weight, bias)

# Element-wise arithmetic
def add(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False):
    """Element-wise addition with error capture."""
    return vla_add(a, b, return_vla=return_vla)

def sub(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False):
    """Element-wise subtraction."""
    return vla_sub(a, b, return_vla=return_vla)

def mul(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False):
    """Element-wise multiplication with error capture."""
    return vla_mul(a, b, return_vla=return_vla)

def div(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False):
    """Element-wise division."""
    return vla_div(a, b, return_vla=return_vla)

def neg(x: torch.Tensor, return_vla: bool = False):
    """Element-wise negation."""
    return vla_neg(x, return_vla=return_vla)

def abs(x: torch.Tensor, return_vla: bool = False):
    """Element-wise absolute value."""
    return vla_abs(x, return_vla=return_vla)

def pow(x: torch.Tensor, exponent, return_vla: bool = False):
    """Element-wise power."""
    return vla_pow(x, exponent, return_vla=return_vla)

def clamp(x: torch.Tensor, min_val=None, max_val=None, return_vla: bool = False):
    """Element-wise clamp."""
    return vla_clamp(x, min_val, max_val, return_vla=return_vla)

def fmod(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False):
    """Floating-point modulo."""
    return vla_fmod(x, y, return_vla=return_vla)

# Transcendental
def exp(x: torch.Tensor, return_vla: bool = False):
    """Element-wise exp."""
    return vla_exp(x, return_vla=return_vla)

def log(x: torch.Tensor, return_vla: bool = False):
    """Element-wise log."""
    return vla_log(x, return_vla=return_vla)

def sqrt(x: torch.Tensor, return_vla: bool = False):
    """Element-wise sqrt."""
    return vla_sqrt(x, return_vla=return_vla)

def rsqrt(x: torch.Tensor, return_vla: bool = False):
    """Element-wise reciprocal sqrt."""
    return vla_rsqrt(x, return_vla=return_vla)

# Trigonometric
def sin(x: torch.Tensor, return_vla: bool = False):
    """Sine function."""
    return vla_sin(x, return_vla=return_vla)

def cos(x: torch.Tensor, return_vla: bool = False):
    """Cosine function."""
    return vla_cos(x, return_vla=return_vla)

def tan(x: torch.Tensor, return_vla: bool = False):
    """Tangent function."""
    return vla_tan(x, return_vla=return_vla)

def asin(x: torch.Tensor, return_vla: bool = False):
    """Inverse sine."""
    return vla_asin(x, return_vla=return_vla)

def acos(x: torch.Tensor, return_vla: bool = False):
    """Inverse cosine."""
    return vla_acos(x, return_vla=return_vla)

def atan(x: torch.Tensor, return_vla: bool = False):
    """Inverse tangent."""
    return vla_atan(x, return_vla=return_vla)

def atan2(y: torch.Tensor, x: torch.Tensor, return_vla: bool = False):
    """Two-argument inverse tangent."""
    return vla_atan2(y, x, return_vla=return_vla)

# Hyperbolic
def sinh(x: torch.Tensor, return_vla: bool = False):
    """Hyperbolic sine."""
    return vla_sinh(x, return_vla=return_vla)

def cosh(x: torch.Tensor, return_vla: bool = False):
    """Hyperbolic cosine."""
    return vla_cosh(x, return_vla=return_vla)

def tanh(x: torch.Tensor, return_vla: bool = False):
    """Hyperbolic tangent."""
    return vla_tanh(x, return_vla=return_vla)

# Rounding
def floor(x: torch.Tensor, return_vla: bool = False):
    """Floor function."""
    return vla_floor(x, return_vla=return_vla)

def ceil(x: torch.Tensor, return_vla: bool = False):
    """Ceiling function."""
    return vla_ceil(x, return_vla=return_vla)

def round(x: torch.Tensor, return_vla: bool = False):
    """Round to nearest integer."""
    return vla_round(x, return_vla=return_vla)

def trunc(x: torch.Tensor, return_vla: bool = False):
    """Truncate toward zero."""
    return vla_trunc(x, return_vla=return_vla)

# Sign and comparison
def sign(x: torch.Tensor) -> torch.Tensor:
    """Sign function."""
    return vla_sign(x)

def eq(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise equality."""
    return vla_eq(x, y)

def ne(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise not-equal."""
    return vla_ne(x, y)

def lt(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise less-than."""
    return vla_lt(x, y)

def le(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise less-than-or-equal."""
    return vla_le(x, y)

def gt(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise greater-than."""
    return vla_gt(x, y)

def ge(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Element-wise greater-than-or-equal."""
    return vla_ge(x, y)

def where(condition: torch.Tensor, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Conditional selection."""
    return vla_where(condition, x, y)

# Basic activations (math functions)
def relu(x: torch.Tensor, return_vla: bool = False):
    """ReLU activation."""
    return vla_relu(x, return_vla=return_vla)

def sigmoid(x: torch.Tensor, return_vla: bool = False):
    """Sigmoid function."""
    return vla_sigmoid(x, return_vla=return_vla)

def leaky_relu(x: torch.Tensor, negative_slope: float = 0.01, return_vla: bool = False):
    """Leaky ReLU."""
    return vla_leaky_relu(x, negative_slope, return_vla=return_vla)

# Signal processing
def fft(x: torch.Tensor, n: Optional[int] = None, dim: int = -1) -> torch.Tensor:
    """1D Fast Fourier Transform."""
    return vla_fft(x, n, dim)

def ifft(x: torch.Tensor, n: Optional[int] = None, dim: int = -1) -> torch.Tensor:
    """1D Inverse FFT."""
    return vla_ifft(x, n, dim)

def rfft(x: torch.Tensor, n: Optional[int] = None, dim: int = -1) -> torch.Tensor:
    """1D Real FFT."""
    return vla_rfft(x, n, dim)

def irfft(x: torch.Tensor, n: Optional[int] = None, dim: int = -1) -> torch.Tensor:
    """1D Inverse Real FFT."""
    return vla_irfft(x, n, dim)

# Convolution
def conv2d(x, weight, bias=None, stride=1, padding=0):
    """2D convolution."""
    return vla_conv2d(x, weight, stride, padding)

def conv_transpose2d(x, weight, bias=None, stride=1, padding=0):
    """2D transposed convolution."""
    return vla_conv_transpose2d(x, weight, stride, padding)

# Linear algebra
def trace(x: torch.Tensor) -> torch.Tensor:
    """Matrix trace."""
    return vla_trace(x)

def det(x: torch.Tensor) -> torch.Tensor:
    """Matrix determinant."""
    return vla_det(x)

def inv(x: torch.Tensor) -> torch.Tensor:
    """Matrix inverse."""
    return vla_inv(x)

def solve(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """Solve linear system Ax = B."""
    return vla_solve(A, B)

# Loss
def mse_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """Exact MSE loss."""
    return vla_mse_loss(pred, target)

# Einsum
def einsum(equation: str, *operands):
    """Einsum with VLA backends where possible."""
    return vla_einsum(equation, *operands)


# =============================================================================
# Global Enable/Disable
# =============================================================================

def enable(mode: str = 'auto'):
    """
    Enable VLA for all PyTorch operations.

    Args:
        mode: 'auto' - critical ops only (recommended)
              'full' - all ops
    """
    global _enabled, _original_ops

    if _enabled:
        return

    # Store originals
    _original_ops['sum'] = torch.sum
    _original_ops['matmul'] = torch.matmul
    _original_ops['mm'] = torch.mm
    _original_ops['bmm'] = torch.bmm

    # Patch (wrapping to match torch API)
    def _vla_sum_wrapper(input, *args, **kwargs):
        if input.is_cuda:
            return sum(input, *args, **kwargs)
        return _original_ops['sum'](input, *args, **kwargs)

    def _vla_matmul_wrapper(input, other):
        if input.is_cuda:
            return matmul(input, other)
        return _original_ops['matmul'](input, other)

    torch.sum = _vla_sum_wrapper
    torch.matmul = _vla_matmul_wrapper
    torch.mm = _vla_matmul_wrapper
    torch.bmm = bmm

    _enabled = True
    print("[VLA] Enabled - GPU ops now use zero-error arithmetic")


def disable():
    """Disable VLA and restore original PyTorch ops."""
    global _enabled, _original_ops

    if not _enabled:
        return

    torch.sum = _original_ops['sum']
    torch.matmul = _original_ops['matmul']
    torch.mm = _original_ops['mm']
    torch.bmm = _original_ops['bmm']

    _enabled = False
    print("[VLA] Disabled - using standard PyTorch ops")


class mode:
    """Context manager for VLA mode."""

    def __enter__(self):
        enable()
        return self

    def __exit__(self, *args):
        disable()


# =============================================================================
# Info
# =============================================================================

def info():
    """Print VLA system info."""
    backend_info = get_backend_info()
    print("=" * 60)
    print("VLA - VIGIL Lossless Arithmetic for Scientific Computing")
    print("=" * 60)
    print(f"Version: {backend_info.get('version', 'unknown')}")
    print(f"Backend: {backend_info.get('backend', 'unknown')}")
    if torch.cuda.is_available():
        print(f"Device: {torch.cuda.get_device_name()}")
        print(f"Architecture: {backend_info.get('native_arch', 'unknown')}")
    print()
    print("Categories:")
    print("  - Core: sum, mean, var, std, norm, dot, matmul")
    print("  - Trig: sin, cos, tan, asin, acos, atan, atan2")
    print("  - Hyper: sinh, cosh, tanh")
    print("  - Signal: fft, ifft, rfft, irfft, conv2d")
    print("  - LinAlg: trace, det, inv, solve")
    print("  - Compare: eq, ne, lt, le, gt, ge, where")
    print("  - Verify: checksum, verify (cross-GPU reproducibility)")
    print()
    print("Precision: Machine epsilon squared (10^-32 vs 10^-16)")
    print("=" * 60)


# =============================================================================
# Reproducibility & Verification (KILLER FEATURE)
# =============================================================================

def checksum(x, truncate: int = 16) -> str:
    """
    Compute SHA256 checksum of VLA result for reproducibility verification.
    This is the KILLER FEATURE: same checksum on ANY GPU architecture.

    Args:
        x: Tensor or VLAResult
        truncate: Number of hex characters to return (default 16)

    Returns:
        Hex checksum string (truncated to `truncate` chars)

    Example:
        >>> result = vla.matmul(A, B)
        >>> cs = vla.checksum(result)  # '6ece6956f187064f'
        >>> # Same checksum on RTX 4070, Tesla T4, A100, etc!
    """
    return vla_checksum(x, truncate=truncate)


def checksum_hex(x) -> str:
    """Return full 64-character SHA256 hex checksum."""
    return vla_checksum_hex(x)


def verify(x, expected: str, truncate: int = 16, raise_on_mismatch: bool = True) -> bool:
    """
    Verify that a VLA result matches an expected checksum.

    Args:
        x: Tensor or VLAResult to verify
        expected: Expected checksum string
        truncate: Number of chars to compare
        raise_on_mismatch: If True, raise ValueError on mismatch

    Returns:
        True if checksums match

    Example:
        >>> vla.verify(result, '6ece6956f187064f')  # True or raises
    """
    return vla_verify(x, expected, truncate=truncate, raise_on_mismatch=raise_on_mismatch)


# =============================================================================
# TRUE ZERO ERROR functions (return Decimal for infinite precision)
# =============================================================================

def sum_exact(x):
    """Exact sum returning Decimal (infinite precision)."""
    return vla_sum_exact(x)

def dot_exact(a, b):
    """Exact dot product returning Decimal."""
    return vla_dot_exact(a, b)

def mean_exact(x):
    """Exact mean returning Decimal."""
    return vla_mean_exact(x)

def matmul_exact(a, b):
    """Exact matrix multiply returning Decimal matrix."""
    return vla_matmul_exact(a, b)

def var_exact(x, unbiased=True):
    """Exact variance returning Decimal."""
    return vla_var_exact(x, unbiased=unbiased)

def std_exact(x, unbiased=True):
    """Exact std dev returning Decimal."""
    return vla_std_exact(x, unbiased=unbiased)

def norm_exact(x, p=2):
    """Exact norm returning Decimal."""
    return vla_norm_exact(x, p=p)

def prod_exact(x):
    """Exact product returning Decimal."""
    return vla_prod_exact(x)

def cumsum_exact(x):
    """Exact cumsum returning Decimal array."""
    return vla_cumsum_exact(x)

def trace_exact(x):
    """Exact matrix trace returning Decimal."""
    return vla_trace_exact(x)

def bmm_exact(a, b):
    """Exact batched matmul returning Decimal."""
    return vla_bmm_exact(a, b)

def logsumexp_exact(x):
    """Exact logsumexp returning Decimal."""
    return vla_logsumexp_exact(x)


# argmin/argmax wrappers
def argmin(x, dim=None):
    """Argmin reduction."""
    return vla_argmin(x)

def argmax(x, dim=None):
    """Argmax reduction."""
    return vla_argmax(x)


__all__ = [
    # Reproducibility & Verification (KILLER FEATURE)
    'checksum', 'checksum_hex', 'verify', 'VLAVerifiedResult',
    # Core ops
    'sum', 'mean', 'var', 'std', 'norm', 'prod', 'cumsum', 'logsumexp',
    'min', 'max', 'argmin', 'argmax', 'dot', 'matmul', 'mm', 'bmm', 'linear',
    # TRUE ZERO ERROR (Decimal precision)
    'sum_exact', 'dot_exact', 'mean_exact', 'matmul_exact',
    'var_exact', 'std_exact', 'norm_exact', 'prod_exact',
    'cumsum_exact', 'trace_exact', 'bmm_exact', 'logsumexp_exact',
    # Arithmetic
    'add', 'sub', 'mul', 'div', 'neg', 'abs', 'pow', 'clamp', 'fmod',
    # Transcendental
    'exp', 'log', 'sqrt', 'rsqrt',
    # Trigonometric
    'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2',
    # Hyperbolic
    'sinh', 'cosh', 'tanh',
    # Rounding
    'floor', 'ceil', 'round', 'trunc',
    # Comparison
    'sign', 'eq', 'ne', 'lt', 'le', 'gt', 'ge', 'where',
    # Activations
    'relu', 'sigmoid', 'leaky_relu',
    # Signal processing
    'fft', 'ifft', 'rfft', 'irfft', 'conv2d', 'conv_transpose2d',
    # Linear algebra
    'trace', 'det', 'inv', 'solve',
    # Loss
    'mse_loss',
    # Einsum
    'einsum',
    # Utilities
    'enable', 'disable', 'mode', 'info',
    'VLAResult',
    # Auto-shape
    'enable_auto', 'disable_auto', 'auto_mode',
]
