# python_actions (Python)

Python utilities for server actions backed by Vercel Python functions.

## Install

```bash
uv add python_actions
```

## Usage

```python
from pydantic import BaseModel
from python_actions import action


class HelloInput(BaseModel):
    name: str


class HelloOutput(BaseModel):
    greeting: str


@action()
def hello(input: HelloInput) -> HelloOutput:
    return HelloOutput(greeting=f"Hello, {input.name}!")
```

## Export actions

```bash
python_actions export --root .
```

## Publish

```bash
uv build
uv publish
```
