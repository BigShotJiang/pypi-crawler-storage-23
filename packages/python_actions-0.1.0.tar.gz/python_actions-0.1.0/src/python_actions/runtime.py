import inspect
import json
from http.server import BaseHTTPRequestHandler
from typing import Any, Callable, Dict, Optional, Tuple

from pydantic import BaseModel, ValidationError


def _read_json_body(handler: BaseHTTPRequestHandler) -> Dict[str, Any]:
    length = int(handler.headers.get("content-length", "0"))
    if length == 0:
        return {}

    raw = handler.rfile.read(length)
    if not raw:
        return {}

    payload = json.loads(raw.decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("JSON body must be an object.")
    return payload


def _extract_models(func: Callable[..., Any]) -> Tuple[Optional[type], type]:
    signature = inspect.signature(func)
    parameters = list(signature.parameters.values())
    if len(parameters) > 1:
        raise RuntimeError("Action must accept zero or one argument.")

    if parameters and parameters[0].kind in (
        parameters[0].VAR_POSITIONAL,
        parameters[0].VAR_KEYWORD,
    ):
        raise RuntimeError("Action parameters must be explicit.")

    input_annotation = parameters[0].annotation if parameters else None
    output_model = signature.return_annotation

    if input_annotation is not None and (
        input_annotation is inspect._empty
        or not isinstance(input_annotation, type)
        or not issubclass(input_annotation, BaseModel)
    ):
        raise RuntimeError("Action input must be a Pydantic BaseModel.")
    if (
        output_model is inspect._empty
        or not isinstance(output_model, type)
        or not issubclass(output_model, BaseModel)
    ):
        raise RuntimeError("Action return must be a Pydantic BaseModel.")

    return input_annotation, output_model


def create_handler(func: Callable[..., Any]) -> type[BaseHTTPRequestHandler]:
    meta = getattr(func, "__py_action__", None)
    if meta is None:
        raise RuntimeError("Action metadata missing.")

    input_model = meta.get("input_model")
    output_model = meta.get("output_model")
    if output_model is None:
        raise RuntimeError("Action output model missing.")

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self._handle_method_not_allowed()

        def do_POST(self):
            self._handle_action()

        def do_PUT(self):
            self._handle_method_not_allowed()

        def do_PATCH(self):
            self._handle_method_not_allowed()

        def do_DELETE(self):
            self._handle_method_not_allowed()

        def _handle_method_not_allowed(self):
            self.send_response(405)
            self.send_header("Content-Type", "application/json")
            self.send_header("Allow", "POST")
            self.end_headers()
            payload = {"error": "Method Not Allowed"}
            self.wfile.write(json.dumps(payload).encode("utf-8"))

        def _handle_action(self):
            try:
                payload = _read_json_body(self)
                if input_model is None:
                    result = func()
                else:
                    parsed_input = input_model.model_validate(payload)
                    result = func(parsed_input)

                if not isinstance(result, output_model):
                    result = output_model.model_validate(result)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(result.model_dump_json().encode("utf-8"))
            except ValidationError as error:
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(error.json().encode("utf-8"))
            except ValueError as error:
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                payload = {"error": str(error)}
                self.wfile.write(json.dumps(payload).encode("utf-8"))
            except Exception as error:  # noqa: BLE001
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                payload = {"error": "Internal Server Error", "detail": str(error)}
                self.wfile.write(json.dumps(payload).encode("utf-8"))

    return Handler


def action() -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        module = inspect.getmodule(func)
        input_model, output_model = _extract_models(func)
        setattr(
            func,
            "__py_action__",
            {
                "input_model": input_model,
                "output_model": output_model,
                "name": func.__name__,
            },
        )

        if module is not None:
            setattr(module, "handler", create_handler(func))
        return func

    return decorator
