import base64
import io
import json
import sys
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import List, Tuple

from python_actions.loader import load_module


RESPONSE_PREFIX = "__PY_ACTIONS_RESPONSE__:"


class FakeSocket:
    def __init__(self, request_bytes: bytes):
        self._rfile = io.BytesIO(request_bytes)
        self._wfile = io.BytesIO()

    def makefile(self, mode: str, *args, **kwargs):
        if "r" in mode:
            return self._rfile
        return self._wfile

    def sendall(self, data: bytes):
        self._wfile.write(data)

    def close(self):
        return


class FakeServer:
    def __init__(self):
        self.server_name = "python-actions"
        self.server_port = 0


def build_request_bytes(
    method: str,
    path: str,
    headers: List[Tuple[str, str]],
    body: bytes,
):
    header_map = {key.lower(): value for key, value in headers}
    if "host" not in header_map:
        headers.append(("Host", "localhost"))
    if "content-length" not in header_map:
        headers.append(("Content-Length", str(len(body))))
    if "connection" not in header_map:
        headers.append(("Connection", "close"))

    header_lines = [f"{key}: {value}" for key, value in headers]
    request_line = f"{method} {path} HTTP/1.1"
    raw = "\r\n".join([request_line, *header_lines, "", ""]).encode("utf-8")
    return raw + body


def parse_response_bytes(response_bytes: bytes):
    header_end = response_bytes.find(b"\r\n\r\n")
    if header_end == -1:
        raise RuntimeError("Malformed response from handler.")

    header_block = response_bytes[:header_end].split(b"\r\n")
    status_line = header_block[0].decode("iso-8859-1")
    status_parts = status_line.split(" ", 2)
    status = int(status_parts[1]) if len(status_parts) > 1 else 200

    headers: List[Tuple[str, str]] = []
    for line in header_block[1:]:
        if not line:
            continue
        key, _, value = line.partition(b":")
        headers.append(
            (key.decode("iso-8859-1"), value.lstrip().decode("iso-8859-1"))
        )

    body = response_bytes[header_end + 4 :]
    return status, headers, body


def run_handler(
    handler_cls: type,
    method: str,
    path: str,
    headers: List[Tuple[str, str]],
    body: bytes,
):
    request_bytes = build_request_bytes(method, path, headers, body)
    socket = FakeSocket(request_bytes)
    server = FakeServer()
    handler_cls(socket, ("127.0.0.1", 0), server)
    response_bytes = socket._wfile.getvalue()
    return parse_response_bytes(response_bytes)


def main() -> None:
    raw_input = sys.stdin.read()
    data = json.loads(raw_input)

    file_path = Path(data["filePath"]).resolve()
    method = data.get("method", "POST")
    path = data.get("path", "/")
    headers = data.get("headers", [])
    body_data = data.get("body", "")
    is_base64 = data.get("isBase64", False)
    body = base64.b64decode(body_data) if is_base64 and body_data else b""

    module = load_module(file_path)
    handler_cls = getattr(module, "handler", None)
    if handler_cls is None or not issubclass(handler_cls, BaseHTTPRequestHandler):
        raise RuntimeError("handler must inherit from BaseHTTPRequestHandler")

    status, response_headers, response_body = run_handler(
        handler_cls, method, path, headers, body
    )

    output = {
        "status": status,
        "headers": response_headers,
        "body": base64.b64encode(response_body).decode("ascii"),
        "isBase64": True,
    }
    sys.stdout.write(f"{RESPONSE_PREFIX}{json.dumps(output)}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        error_payload = {
            "status": 500,
            "headers": [("Content-Type", "text/plain")],
            "body": base64.b64encode(str(exc).encode("utf-8")).decode("ascii"),
            "isBase64": True,
        }
        sys.stdout.write(f"{RESPONSE_PREFIX}{json.dumps(error_payload)}")
