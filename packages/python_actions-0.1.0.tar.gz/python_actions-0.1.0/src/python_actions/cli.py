import argparse
import sys

from python_actions.export import export_json


def main() -> None:
    parser = argparse.ArgumentParser(prog="python_actions")
    subparsers = parser.add_subparsers(dest="command", required=True)

    export_parser = subparsers.add_parser("export", help="Export actions as JSON")
    export_parser.add_argument("--root", default=None)
    export_parser.add_argument("--include", action="append", default=[])
    export_parser.add_argument("--exclude", action="append", default=[])

    args = parser.parse_args()

    if args.command == "export":
        output = export_json(args.root, args.include, args.exclude)
        sys.stdout.write(output)


if __name__ == "__main__":
    main()
