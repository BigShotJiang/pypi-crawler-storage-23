import hashlib
import importlib.util
import sys
from pathlib import Path
from types import ModuleType


def load_module(file_path: Path) -> ModuleType:
    module_id = "python_actions_" + hashlib.sha256(
        str(file_path).encode("utf-8")
    ).hexdigest()
    spec = importlib.util.spec_from_file_location(module_id, file_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load module: {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_id] = module
    spec.loader.exec_module(module)
    return module
