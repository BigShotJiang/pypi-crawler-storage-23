import fnmatch
import hashlib
import json
import os
from pathlib import Path
from typing import Iterable

from python_actions.loader import load_module


DEFAULT_INCLUDE = ["src/**/*.py"]
DEFAULT_EXCLUDE = [
    "**/.venv/**",
    "**/.next/**",
    "**/.vercel/**",
    "**/node_modules/**",
    "**/api/py_actions/**",
    "**/__pycache__/**",
    "**/*.pyc",
]


def _normalize_patterns(values: Iterable[str]) -> list[str]:
    patterns: list[str] = []
    for value in values:
        if not value:
            continue
        for part in value.split(","):
            part = part.strip()
            if part:
                patterns.append(part)
    return patterns


def _is_excluded(relative_path: str, excludes: list[str]) -> bool:
    for pattern in excludes:
        if fnmatch.fnmatch(relative_path, pattern):
            return True
    return False


def _collect_files(root: Path, includes: list[str], excludes: list[str]) -> list[Path]:
    files: set[Path] = set()
    for pattern in includes:
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            rel_path = path.relative_to(root).as_posix()
            if _is_excluded(rel_path, excludes):
                continue
            files.add(path)
    return sorted(files)


def export_actions(root: Path, includes: list[str], excludes: list[str]) -> dict:
    actions = []
    files = _collect_files(root, includes, excludes)
    for file_path in files:
        module = load_module(file_path)
        for value in module.__dict__.values():
            meta = getattr(value, "__py_action__", None)
            if meta is None:
                continue
            if getattr(value, "__module__", None) != module.__name__:
                continue

            input_model = meta.get("input_model")
            output_model = meta.get("output_model")
            if output_model is None:
                continue

            input_fields = []
            input_schema = None
            if input_model is not None:
                input_fields = list(input_model.model_fields.keys())
                input_schema = input_model.model_json_schema()

            output_fields = list(output_model.model_fields.keys())
            output_schema = output_model.model_json_schema()

            rel_path = file_path.relative_to(root).as_posix()
            action_key = f"{rel_path}:{value.__name__}"
            action_id = "py_" + hashlib.sha256(
                action_key.encode("utf-8")
            ).hexdigest()[:8]

            actions.append(
                {
                    "id": action_id,
                    "file": rel_path,
                    "name": value.__name__,
                    "input": {
                        "fields": input_fields,
                        "schema": input_schema,
                    }
                    if input_model is not None
                    else None,
                    "output": {
                        "fields": output_fields,
                        "schema": output_schema,
                    },
                }
            )

    return {"actions": actions}


def export_json(
    root: str | None = None,
    include: Iterable[str] | None = None,
    exclude: Iterable[str] | None = None,
) -> str:
    root_path = Path(root or os.getcwd())
    includes = _normalize_patterns(include or []) or DEFAULT_INCLUDE
    excludes = _normalize_patterns(exclude or []) or DEFAULT_EXCLUDE
    payload = export_actions(root_path, includes, excludes)
    return json.dumps(payload)
