# dependencies
import xarrayspecs


def test_namespace() -> None:
    # submodules
    xarrayspecs.api
    xarrayspecs.spec
    # aliases
    xarrayspecs.Dims
    xarrayspecs.Dtype
    xarrayspecs.asarray
    xarrayspecs.asset
    xarrayspecs.attrs
    xarrayspecs.dims
    xarrayspecs.dtype
    xarrayspecs.name
    xarrayspecs.node
    xarrayspecs.parse
    xarrayspecs.use
