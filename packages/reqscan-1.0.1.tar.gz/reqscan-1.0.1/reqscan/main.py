import ast
import os
import sys
import sysconfig
import importlib.metadata
import importlib.util
import argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

# Enable ANSI colors
if os.name == 'nt':
    os.system("")

class C:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

SKIP_DIRS = {
    ".git", "venv", ".venv", "env", ".env", "envs", "node_modules", 
    "__pycache__", "build", "dist", ".idea", ".vscode", "site-packages"
}

def print_banner():
    # 'r' prefix prevents SyntaxWarning for backslashes
    banner = fr"""{C.CYAN}{C.BOLD}
  _____             _____                 
 |  __ \           / ____|                
 | |__) |___  __ _| (___   ___ __ _ _ __  
 |  _  // _ \/ _` |\___ \ / __/ _` | '_ \ 
 | | \ \  __/ (_| |____) | (_| (_| | | | |
 |_|  \_\___|\__, |_____/ \___\__,_|_| |_|
                | |                       
                |_|                       

 | Developed by : turnt ducky 🦆 |{C.RESET}"""
    print(banner)

def draw_progress_bar(current, total, bar_length=40):
    fraction = current / total
    arrow = int(fraction * bar_length - 1) * "=" + ">"
    padding = int(bar_length - len(arrow)) * " "
    ending = "\n" if current == total else "\r"
    print(f" {C.CYAN}[*]{C.RESET} Progress: [{C.GREEN}{arrow}{padding}{C.RESET}] {int(fraction*100)}%", end=ending)

def is_venv(dir_path):
    path = Path(dir_path)
    return (path / "pyvenv.cfg").exists() or (path / "bin" / "python").exists() or (path / "Scripts" / "python.exe").exists()

def get_python_files(root):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not is_venv(os.path.join(dirpath, d))]
        for file in filenames:
            if file.endswith(".py"):
                yield os.path.join(dirpath, file)

def extract_imports(file_path):
    imports = set()
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            tree = ast.parse(f.read())
    except Exception:
        return imports
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for name in node.names:
                imports.add(name.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:
                imports.add(node.module.split(".")[0])
    return imports

def get_stdlib_modules():
    return set(sys.stdlib_module_names)

def get_local_modules(project_root):
    local = {Path(project_root).name}
    for dirpath, dirnames, filenames in os.walk(project_root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for d in dirnames: local.add(d)
        for f in filenames:
            if f.endswith(".py"): local.add(os.path.splitext(f)[0])
    return local

def get_package_map():
    mapping = {}
    for dist in importlib.metadata.distributions():
        package_name = dist.metadata.get("Name")
        if not package_name: continue
        try:
            top_level = dist.read_text("top_level.txt")
            if top_level:
                for line in top_level.splitlines():
                    name = line.strip()
                    if name: mapping.setdefault(name, package_name)
            else:
                mapping.setdefault(package_name.lower().replace("-", "_"), package_name)
        except Exception: continue
    return mapping

def main():
    parser = argparse.ArgumentParser(description="Scan a directory for Python dependencies.")
    parser.add_argument("path", nargs="?", default=".", help="Target directory to scan (default: current)")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing requirements.txt without asking")
    args = parser.parse_args()

    print_banner()
    project_root = Path(args.path).resolve()
    output_file = project_root / "requirements.txt"

    if not project_root.is_dir():
        print(f" {C.RED}[!]{C.RESET} Error: {project_root} is not a directory.")
        return

    print(f" {C.CYAN}[*]{C.RESET} Scanning: {C.YELLOW}{project_root}{C.RESET}")
    
    py_files = list(get_python_files(project_root))
    total_files = len(py_files)
    
    if total_files == 0:
        print(f" {C.RED}[!]{C.RESET} No Python files found.")
        return

    all_imports = set()
    completed_count = 0
    
    with ProcessPoolExecutor() as executor:
        # Create a list of tasks
        futures = {executor.submit(extract_imports, f): f for f in py_files}
        
        # Update progress bar as they complete
        for future in as_completed(futures):
            completed_count += 1
            draw_progress_bar(completed_count, total_files)
            all_imports.update(future.result())

    stdlib = get_stdlib_modules()
    local_modules = get_local_modules(project_root)
    pkg_map = get_package_map()

    external_imports = {imp for imp in all_imports if imp not in stdlib and imp not in local_modules}
    
    final_requirements = {}
    for imp in external_imports:
        actual_package = pkg_map.get(imp, imp)
        try:
            version = importlib.metadata.version(actual_package).split("+")[0]
            final_requirements[actual_package] = f"=={version}"
        except importlib.metadata.PackageNotFoundError:
            continue

    # Merge Logic
    merged = {}
    if output_file.exists() and not args.overwrite:
        with open(output_file, "r") as f:
            for line in f:
                if line.strip() and not line.startswith("#"):
                    p = line.split("==")[0].split(">=")[0].strip()
                    merged[p] = line.strip()

    for pkg, ver in final_requirements.items():
        merged[pkg] = f"{pkg}{ver}"

    with open(output_file, "w") as f:
        for line in sorted(merged.values(), key=lambda x: x.lower()):
            f.write(line + "\n")

    print(f" {C.GREEN}[✓]{C.RESET} Success! Generated {C.YELLOW}{output_file}{C.RESET}")

if __name__ == "__main__":
    main()