from __future__ import annotations

from inferagni import __version__


def test_version():
    assert __version__
