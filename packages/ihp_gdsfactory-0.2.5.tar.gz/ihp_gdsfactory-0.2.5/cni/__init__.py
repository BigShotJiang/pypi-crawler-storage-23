# CNI compatibility layer for IHP PDK PyCells
# Auto-register the SG13 technology on import
from cni import sg13_tech  # noqa: F401
