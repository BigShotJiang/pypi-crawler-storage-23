# BBB-Nuke Integration Guide

Three ways to use BBB-Nuke: REST API, Claude Code (MCP), and OpenAI Codex (MCP).

---

## Prerequisites

```bash
# Clone and install
git clone https://github.com/ATTN-Lab/BBB-nuke.git
cd BBB-nuke/bbnuke
pip install -e ".[api]"
```

Verify the install:

```bash
python -c "import bbnuke; print(bbnuke.__version__)"
# 0.7.2
```

---

## 1. REST API

The FastAPI server exposes the pipeline over HTTP. Works with any language or client.

### Step 1: Start the server

```bash
uvicorn bbnuke.api.app:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000/docs for the interactive Swagger UI.

### Step 2: Health check

```bash
curl http://127.0.0.1:8000/v1/health
```

```json
{"status": "ok"}
```

### Step 3: Check pipeline version

```bash
curl http://127.0.0.1:8000/v1/version
```

```json
{
  "pipeline_version": "0.7.2",
  "api_version": "1.0.0",
  "hyperparameters": {
    "logistic_k": 0.1352,
    "efflux_veto_threshold": 0.7,
    "mpo_gain_coeff": 2.0,
    "mpo_filter_cutoff": 3.0
  }
}
```

### Step 4: Score a compound

```bash
curl -X POST http://127.0.0.1:8000/v1/score \
  -H "Content-Type: application/json" \
  -d '{"smiles": "CN1C=NC2=C1C(=O)N(C(=O)N2C)C"}'
```

```json
{
  "result": {
    "compound_id": "query",
    "smiles_standardized": "Cn1c(=O)c2c(ncn2C)n(C)c1=O",
    "properties": {
      "mw": 194.194,
      "logp": -1.0293,
      "tpsa": 61.82,
      "hbd": 0,
      "hba": 6
    },
    "cns_mpo": {
      "score": 6.0,
      "passed_filter": true
    },
    "heuristic": {
      "p_bbb": 0.692365,
      "diagnostics": {
        "reason": "MPO-only (no affinity scores)",
        "veto": false,
        "score_bind": 0.0,
        "score_mpo": 6.0,
        "score_total": 6.0
      }
    },
    "passed_mpo_filter": true
  }
}
```

### Step 5: Score with affinity data

Pass `include_affinity: true` to use pre-computed PSICHIC binding data (599 compounds, 65 proteins):

```bash
curl -X POST http://127.0.0.1:8000/v1/score \
  -H "Content-Type: application/json" \
  -d '{"smiles": "Cn1c(=O)c2c(ncn2C)n(C)c1=O", "include_affinity": true}'
```

If the compound is in the dataset, you'll get per-protein binding scores, efflux veto checks, and a more accurate P_BBB. If not found, it falls back to MPO-only scoring.

### Step 6: Python client example

```python
import httpx

resp = httpx.post("http://127.0.0.1:8000/v1/score", json={
    "smiles": "CN1C=NC2=C1C(=O)N(C(=O)N2C)C",
    "include_affinity": True,
})
result = resp.json()["result"]
print(f"P_BBB = {result['heuristic']['p_bbb']:.3f}")
print(f"CNS-MPO = {result['cns_mpo']['score']:.1f}/6.0")
```

### Endpoints reference

| Method | Path | Description |
|--------|------|-------------|
| GET | `/v1/health` | Liveness probe |
| GET | `/v1/version` | Pipeline version + hyperparameters |
| POST | `/v1/score` | Score a single compound |
| POST | `/v1/batch` | Submit batch job (requires Redis) |
| GET | `/v1/batch/{job_id}` | Poll batch progress |

---

## 2. Claude Code (MCP)

Use BBB-Nuke as a tool inside Claude Code. Claude calls the pipeline in natural language.

### Step 1: Install the MCP SDK

The MCP SDK requires Python 3.10+. If your default Python is 3.9, use a newer version:

```bash
python3.11 -m pip install mcp
python3.11 -m pip install -e .
```

### Step 2: Register the MCP server (one-liner, done once)

```bash
claude mcp add \
  --transport stdio \
  --scope user \
  --env PYTHONPATH=/path/to/BBB-nuke/bbnuke/src \
  bbnuke \
  -- python3.11 -m bbnuke.mcp_server
```

Replace `/path/to/BBB-nuke` with your actual path.

### Step 3: Verify

```bash
claude mcp list
```

```
bbnuke: python3.11 -m bbnuke.mcp_server - ✓ Connected
```

### Step 4: Start Claude Code

```bash
claude
```

### Step 5: Use it

Just talk. Claude will call the tools automatically.

```
You: Score caffeine for BBB penetration

Claude: [calls score_compound] Caffeine scores P_BBB = 0.692 with a
        perfect CNS-MPO of 6.0/6.0...

You: Explain why donepezil gets a lower score

Claude: [calls explain_score] Donepezil's main weakness is its cLogD
        subscore (0.25). At pH 7.4, the protonated piperidine...

You: What version of the pipeline are we running?

Claude: [calls get_pipeline_info] BBB-Nuke v0.7.2, PSICHIC affinity
        model, max 100 compounds for real-time inference...
```

### Available tools

| Tool | What it does |
|------|-------------|
| `score_compound` | Score one molecule (CPU-only, fast) |
| `score_with_affinity` | Score with PSICHIC affinity lookup (599 pre-computed compounds) |
| `get_pipeline_info` | Pipeline version, hyperparameters, capabilities |
| `explain_score` | Detailed human-readable breakdown of a score |

### Remote access (optional)

To run the MCP server over HTTP instead of stdio:

```bash
python3.11 -m bbnuke.mcp_server --http --port 8080 --path /mcp
```

Then register as HTTP:

```bash
claude mcp add --transport http bbnuke http://localhost:8080/mcp
```

### Unregister

```bash
claude mcp remove bbnuke
```

---

## 3. OpenAI Codex (MCP)

Use BBB-Nuke inside Codex CLI. Same MCP server, different client.

### Step 1: Install (same as Claude)

```bash
python3.11 -m pip install mcp
python3.11 -m pip install -e .
```

### Step 2a: Register via CLI (one-liner)

```bash
codex mcp add bbnuke \
  --env PYTHONPATH=/path/to/BBB-nuke/bbnuke/src \
  -- python3.11 -m bbnuke.mcp_server
```

### Step 2b: Or register via config.toml

Add to `~/.codex/config.toml`:

```toml
[mcp_servers.bbnuke]
command = "python3.11"
args = ["-m", "bbnuke.mcp_server"]

[mcp_servers.bbnuke.env]
PYTHONPATH = "/path/to/BBB-nuke/bbnuke/src"
```

For project-scoped config, put the same block in `.codex/config.toml` at your project root.

### Step 3: Start Codex

```bash
codex
```

### Step 4: Use it

Same natural language experience as Claude:

```
You: Score aspirin for BBB penetration

Codex: [calls score_compound with SMILES CC(=O)OC1=CC=CC=C1C(=O)O]
       Aspirin scores P_BBB = 0.618, CNS-MPO 4.52/6.0 (PASS)...

You: Now score ibuprofen and compare

Codex: [calls score_compound] Ibuprofen P_BBB = 0.645, CNS-MPO 5.12/6.0.
       Higher than aspirin due to lower TPSA and better LogP balance...

You: Explain the score for the one with higher P_BBB

Codex: [calls explain_score] Ibuprofen's strengths: MW=206.3 (excellent),
       TPSA=37.3 (very low), HBD=1. Weakness: cLogD...
```

### Codex-specific options

```toml
# Timeouts (in config.toml)
[mcp_servers.bbnuke]
command = "python3.11"
args = ["-m", "bbnuke.mcp_server"]
startup_timeout_sec = 15
tool_timeout_sec = 120        # PSICHIC inference can take time

[mcp_servers.bbnuke.env]
PYTHONPATH = "/path/to/BBB-nuke/bbnuke/src"
```

### Alternative: OpenAI functions server

If you prefer the OpenAI function-calling format (e.g., for custom agents built with the OpenAI SDK), BBB-Nuke also ships a standalone FastAPI server:

```bash
bbnuke-openai --port 8081
```

This exposes:

| Endpoint | Description |
|----------|-------------|
| `GET /v1/functions` | List available tool schemas |
| `POST /v1/tools/{name}` | Call a tool directly |
| `POST /v1/chat/completions` | OpenAI-compatible chat completions with tool_calls |

Point any OpenAI-compatible client at it:

```python
from openai import OpenAI

client = OpenAI(base_url="http://localhost:8081/v1", api_key="unused")
```

Tools: `score_compound`, `score_with_affinity` (real-time PSICHIC, up to 100 compounds), `get_pipeline_info`, `explain_score`, `import_compounds` (local/ChEMBL/PubChem/COCONUT/DUD-E).

---

## Quick Reference

| Integration | Command | Port |
|-------------|---------|------|
| REST API | `uvicorn bbnuke.api.app:app` | 8000 |
| MCP (stdio) | `python3.11 -m bbnuke.mcp_server` | — |
| MCP (HTTP) | `python3.11 -m bbnuke.mcp_server --http` | 8080 |
| OpenAI functions | `bbnuke-openai` | 8081 |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `BBNUKE_HOST` | `0.0.0.0` | API bind address |
| `BBNUKE_PORT` | `8000` | API port |
| `BBNUKE_DEBUG` | `false` | Debug mode |
| `BBNUKE_API_KEY` | — | API key (optional) |
| `BBNUKE_PSICHIC_REPO` | `~/Documents/PSICHIC` | Path to PSICHIC repo |
| `BBNUKE_PSICHIC_MODEL` | `~/Documents/PSICHIC/trained_weights/multitask_PSICHIC` | Trained model |
| `BBNUKE_MOLGPKA_DIR` | `~/Documents/MolGpKa/src` | MolGpKa source dir |
| `BBNUKE_MOLGPKA_PYTHON` | `~/opt/anaconda3/bin/python` | Python with torch |
