"""BBB-Nuke OpenAI-compatible function-calling server.

Exposes the BBB-Nuke pipeline as OpenAI-style tool calls via:
  - POST /v1/chat/completions  (OpenAI tool_calls format)
  - GET  /v1/functions         (schema discovery)
  - POST /v1/tools/{name}      (direct invocation)

Usage:
  python -m bbnuke.openai_functions --port 8081
"""

from __future__ import annotations

import csv
import json
import logging
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import httpx
import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# OpenAI function schemas
# ---------------------------------------------------------------------------

FUNCTION_SCHEMAS: List[Dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "score_compound",
            "description": (
                "Score a molecule for blood-brain barrier penetration (CPU-only, no affinity). "
                "Runs: Standardize -> Properties -> pKa -> CNS-MPO -> Heuristic -> P_BBB."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "smiles": {
                        "type": "string",
                        "description": "SMILES string of the molecule to score.",
                    },
                    "compound_id": {
                        "type": "string",
                        "description": "Optional identifier for the compound.",
                        "default": "query",
                    },
                },
                "required": ["smiles"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "score_with_affinity",
            "description": (
                "Score compounds with real-time PSICHIC protein-ligand affinity inference on CPU. "
                "Accepts up to 100 compounds. Runs the full pipeline: Standardize -> Properties "
                "-> pKa -> CNS-MPO -> filter >= 3 -> PSICHIC affinity -> Heuristic -> P_BBB."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "smiles_list": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of SMILES strings (max 100).",
                    },
                    "compound_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional list of identifiers (same length as smiles_list).",
                    },
                },
                "required": ["smiles_list"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_pipeline_info",
            "description": "Get BBB-Nuke pipeline version, hyperparameters, and capabilities.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "explain_score",
            "description": (
                "Get a detailed human-readable explanation of a molecule's BBB score. "
                "Breaks down each pipeline stage and highlights key factors."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "smiles": {
                        "type": "string",
                        "description": "SMILES string of the molecule to explain.",
                    },
                },
                "required": ["smiles"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "import_compounds",
            "description": (
                "Import compounds for screening from public databases or local files. "
                "Sources: 'local' (CSV/SDF file), 'chembl', 'pubchem', 'coconut', 'dude'. "
                "Returns a list of compounds with SMILES for the user to select which to score."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "source": {
                        "type": "string",
                        "enum": ["local", "chembl", "pubchem", "coconut", "dude"],
                        "description": "Data source to import from.",
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query (molecule name, target, CID, etc.). Required for DB sources.",
                    },
                    "file_path": {
                        "type": "string",
                        "description": "Path to local CSV or SDF file. Required when source='local'.",
                    },
                    "smiles_col": {
                        "type": "string",
                        "description": "Column name for SMILES in local CSV (default: auto-detect).",
                    },
                    "id_col": {
                        "type": "string",
                        "description": "Column name for compound IDs in local CSV (default: auto-detect).",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of compounds to return (default: 50).",
                        "default": 50,
                    },
                },
                "required": ["source"],
                "additionalProperties": False,
            },
        },
    },
]


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

def _score_compound(smiles: str, compound_id: str = "query", **kwargs: Any) -> dict:
    from bbnuke.core.schemas import CompoundInput
    from bbnuke.pipeline.runner import run_single

    compound = CompoundInput(compound_id=compound_id, smiles=smiles)
    result = run_single(compound)
    return _format_result(result)


def _score_with_affinity(
    smiles_list: List[str],
    compound_ids: Optional[List[str]] = None,
    **kwargs: Any,
) -> dict:
    from bbnuke.core.config import settings
    from bbnuke.core.schemas import CompoundInput
    from bbnuke.modules.affinity import prepare_filtered_ligands_csv, run_psichic
    from bbnuke.modules.standardize import standardize_smiles
    from bbnuke.pipeline.runner import run_batch

    if len(smiles_list) > 100:
        return {"error": f"Maximum 100 compounds allowed, got {len(smiles_list)}."}

    if compound_ids and len(compound_ids) != len(smiles_list):
        return {"error": "compound_ids must be same length as smiles_list."}

    if not compound_ids:
        compound_ids = [f"cpd_{i}" for i in range(len(smiles_list))]

    compounds = [
        CompoundInput(compound_id=cid, smiles=smi)
        for cid, smi in zip(compound_ids, smiles_list)
    ]

    # First pass: properties + pKa + CNS-MPO (no affinity yet)
    first_pass = run_batch(compounds)

    # Prepare filtered compounds for PSICHIC
    passing = [r for r in first_pass if r.passed_mpo_filter]
    if not passing:
        return {
            "total": len(smiles_list),
            "passed_mpo_filter": 0,
            "results": [_format_result(r) for r in first_pass],
            "affinity_source": "none — no compounds passed CNS-MPO filter",
        }

    # Check PSICHIC availability
    psichic_repo = settings.psichic_repo
    psichic_model = settings.psichic_model_path
    proteins_csv_path = str(
        Path(__file__).resolve().parent.parent / "data" / "BBB_proteins_merged.csv"
    )

    if not psichic_repo or not Path(psichic_repo).expanduser().exists():
        return {
            "total": len(smiles_list),
            "passed_mpo_filter": len(passing),
            "results": [_format_result(r) for r in first_pass],
            "affinity_source": "unavailable — PSICHIC repo not found",
        }

    # Run PSICHIC on filtered compounds
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            ligands_csv = str(Path(tmpdir) / "ligands.csv")
            prepare_filtered_ligands_csv(first_pass, ligands_csv)

            affinity_map = run_psichic(
                proteins_csv=proteins_csv_path,
                ligands_csv=ligands_csv,
                outdir=str(Path(tmpdir) / "psichic_out"),
                psichic_repo=psichic_repo,
                trained_model_path=psichic_model,
                device="cpu",
                batch_size=16,
            )

        # Second pass with affinity data
        final_results = run_batch(
            compounds,
            affinity_map=affinity_map,
        )

        return {
            "total": len(smiles_list),
            "passed_mpo_filter": len(passing),
            "scored_with_affinity": len(affinity_map),
            "results": [_format_result(r) for r in final_results],
            "affinity_source": "real-time PSICHIC (CPU)",
        }

    except Exception as exc:
        logger.exception("PSICHIC inference failed")
        return {
            "total": len(smiles_list),
            "passed_mpo_filter": len(passing),
            "results": [_format_result(r) for r in first_pass],
            "affinity_source": f"failed — {exc}",
        }


def _get_pipeline_info(**kwargs: Any) -> dict:
    from bbnuke import __version__
    from bbnuke.core.constants import (
        EFFLUX_VETO_THRESHOLD,
        LOGISTIC_K,
        MPO_FILTER_CUTOFF,
        MPO_GAIN_COEFF,
    )

    return {
        "pipeline_version": __version__,
        "hyperparameters": {
            "logistic_k": LOGISTIC_K,
            "efflux_veto_threshold": EFFLUX_VETO_THRESHOLD,
            "mpo_gain_coeff": MPO_GAIN_COEFF,
            "mpo_filter_cutoff": MPO_FILTER_CUTOFF,
        },
        "capabilities": {
            "cpu_scoring": True,
            "realtime_affinity": True,
            "affinity_model": "PSICHIC",
            "max_realtime_compounds": 100,
        },
        "pipeline": (
            "Standardize -> Properties -> pKa (MolGpKa) -> CNS-MPO "
            "-> filter >= 3 -> PSICHIC affinity -> Heuristic -> P_BBB"
        ),
    }


def _explain_score(smiles: str, **kwargs: Any) -> dict:
    from bbnuke.api.affinity_cache import lookup_affinity
    from bbnuke.core.schemas import CompoundInput
    from bbnuke.modules.standardize import standardize_smiles
    from bbnuke.pipeline.runner import run_single

    compound = CompoundInput(compound_id="query", smiles=smiles)

    std_smiles = standardize_smiles(smiles)
    affinity_scores, pka_data, matched_id = lookup_affinity(std_smiles)

    result = run_single(
        compound,
        pka_data=pka_data,
        affinity_scores=affinity_scores,
    )

    explanation = []
    explanation.append(f"Molecule: {result.smiles_standardized}")
    explanation.append("")

    p = result.properties
    explanation.append("1. PHYSICOCHEMICAL PROPERTIES")
    explanation.append(
        f"   MW={p.mw:.1f} Da, LogP={p.logp:.2f}, TPSA={p.tpsa:.1f}, HBD={p.hbd}, HBA={p.hba}"
    )

    mpo = result.cns_mpo
    explanation.append("")
    explanation.append(
        f"2. CNS-MPO SCORE: {mpo.score:.2f}/6.0 {'PASS' if mpo.passed_filter else 'FAIL'}"
    )
    s = mpo.subscores
    explanation.append(
        f"   Subscores: MW={s.mw:.2f} LogP={s.logp:.2f} TPSA={s.tpsa:.2f} "
        f"HBD={s.hbd:.2f} pKa={s.pka:.2f} cLogD={s.clogd:.2f}"
    )
    if not mpo.passed_filter:
        explanation.append(f"   BLOCKED: CNS-MPO {mpo.score:.2f} < 3.0 cutoff. P_BBB = 0.")

    explanation.append("")
    if result.affinity and result.affinity.scores:
        explanation.append(
            f"3. PROTEIN AFFINITY ({len(result.affinity.scores)} proteins, source: PSICHIC)"
        )
        top = sorted(result.affinity.scores, key=lambda x: -x.score_norm)[:5]
        for sc in top:
            explanation.append(f"   {sc.protein_id}: {sc.score_norm:.3f}")
    else:
        explanation.append("3. PROTEIN AFFINITY: No data available (MPO-only scoring)")

    explanation.append("")
    if result.heuristic:
        h = result.heuristic
        d = h.diagnostics
        explanation.append(f"4. BBB PENETRATION: P_BBB = {h.p_bbb:.4f}")
        if d.veto:
            explanation.append(
                f"   VETOED by efflux protein {d.veto_protein} (binding prob {d.veto_prob:.3f})"
            )
        else:
            explanation.append(
                f"   S_bind={d.score_bind:.2f}, S_mpo={d.score_mpo:.2f}, S_total={d.score_total:.2f}"
            )
            active = [c for c in d.contributions if abs(c.weighted_contribution) > 0.01]
            if active:
                explanation.append(f"   Active protein contributions: {len(active)}")
                for c in sorted(active, key=lambda x: -abs(x.weighted_contribution))[:5]:
                    sign = "+" if c.weighted_contribution > 0 else ""
                    explanation.append(
                        f"     {c.canonical_id}: {c.category} w={c.weight:+.0f} "
                        f"p={c.binding_prob:.3f} -> {sign}{c.weighted_contribution:.3f}"
                    )
    else:
        explanation.append("4. BBB PENETRATION: Not computed (failed MPO filter)")

    return {
        "explanation": "\n".join(explanation),
        "p_bbb": result.heuristic.p_bbb if result.heuristic else 0.0,
        "passed_mpo": result.passed_mpo_filter,
        "has_affinity": result.affinity is not None and len(result.affinity.scores) > 0,
    }


def _import_compounds(
    source: str,
    query: Optional[str] = None,
    file_path: Optional[str] = None,
    smiles_col: Optional[str] = None,
    id_col: Optional[str] = None,
    limit: int = 50,
    **kwargs: Any,
) -> dict:
    """Import compounds from public databases or local files."""
    if source == "local":
        return _import_local(file_path, smiles_col, id_col, limit)
    elif source == "chembl":
        return _import_chembl(query, limit)
    elif source == "pubchem":
        return _import_pubchem(query, limit)
    elif source == "coconut":
        return _import_coconut(query, limit)
    elif source == "dude":
        return _import_dude(query, limit)
    else:
        return {"error": f"Unknown source: {source}. Use: local, chembl, pubchem, coconut, dude"}


# ---------------------------------------------------------------------------
# Import helpers
# ---------------------------------------------------------------------------

def _import_local(
    file_path: Optional[str],
    smiles_col: Optional[str],
    id_col: Optional[str],
    limit: int,
) -> dict:
    if not file_path:
        return {"error": "file_path is required when source='local'"}

    p = Path(file_path).expanduser().resolve()
    if not p.exists():
        return {"error": f"File not found: {p}"}

    suffix = p.suffix.lower()

    if suffix in (".csv", ".tsv"):
        sep = "\t" if suffix == ".tsv" else ","
        df = pd.read_csv(str(p), sep=sep, nrows=limit)

        # Auto-detect SMILES column
        if smiles_col and smiles_col in df.columns:
            smi_col = smiles_col
        else:
            smi_col = _detect_col(df.columns, [
                "smiles", "SMILES", "Smiles", "canonical_smiles",
                "CanonicalSMILES", "smi", "mol", "structure",
            ])

        if not smi_col:
            return {
                "error": f"Cannot detect SMILES column. Columns: {list(df.columns)}. "
                "Pass smiles_col explicitly.",
            }

        # Auto-detect ID column
        if id_col and id_col in df.columns:
            cid_col = id_col
        else:
            cid_col = _detect_col(df.columns, [
                "compound_id", "Compound_ID", "compound_name", "name",
                "Name", "ID", "id", "CID", "chembl_id", "ChEMBL_ID",
                "molecule_chembl_id",
            ])

        compounds = []
        for i, row in df.iterrows():
            smi = str(row[smi_col]).strip()
            if not smi or smi == "nan":
                continue
            cid = str(row[cid_col]).strip() if cid_col else f"local_{i}"
            compounds.append({
                "compound_id": cid,
                "smiles": smi,
                "source": "local",
                "name": cid,
            })

        return {
            "source": "local",
            "file": str(p),
            "total_found": len(compounds),
            "compounds": compounds[:limit],
        }

    elif suffix == ".sdf":
        try:
            from rdkit import Chem
        except ImportError:
            return {"error": "rdkit required for SDF parsing"}

        suppl = Chem.SDMolSupplier(str(p))
        compounds = []
        for i, mol in enumerate(suppl):
            if mol is None:
                continue
            smi = Chem.MolToSmiles(mol)
            name = mol.GetProp("_Name") if mol.HasProp("_Name") else f"sdf_{i}"
            compounds.append({
                "compound_id": name,
                "smiles": smi,
                "source": "local",
                "name": name,
            })
            if len(compounds) >= limit:
                break

        return {
            "source": "local",
            "file": str(p),
            "total_found": len(compounds),
            "compounds": compounds,
        }
    else:
        return {"error": f"Unsupported file format: {suffix}. Use .csv, .tsv, or .sdf"}


def _import_chembl(query: Optional[str], limit: int) -> dict:
    if not query:
        return {"error": "query is required for ChEMBL search"}

    url = "https://www.ebi.ac.uk/chembl/api/data/molecule/search.json"
    try:
        resp = httpx.get(url, params={"q": query, "limit": limit}, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        return {"error": f"ChEMBL API error: {exc}"}

    compounds = []
    for mol in data.get("molecules", []):
        structs = mol.get("molecule_structures") or {}
        smi = structs.get("canonical_smiles")
        if not smi:
            continue
        compounds.append({
            "compound_id": mol.get("molecule_chembl_id", ""),
            "smiles": smi,
            "source": "chembl",
            "name": mol.get("pref_name") or mol.get("molecule_chembl_id", ""),
        })

    return {
        "source": "chembl",
        "query": query,
        "total_found": len(compounds),
        "compounds": compounds[:limit],
    }


def _import_pubchem(query: Optional[str], limit: int) -> dict:
    if not query:
        return {"error": "query is required for PubChem search"}

    # Try name search first
    url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{query}/property/CanonicalSMILES,IUPACName,CID/JSON"
    try:
        resp = httpx.get(url, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            props = data.get("PropertyTable", {}).get("Properties", [])
            compounds = []
            for p in props[:limit]:
                compounds.append({
                    "compound_id": f"CID_{p.get('CID', '')}",
                    "smiles": p.get("CanonicalSMILES", ""),
                    "source": "pubchem",
                    "name": p.get("IUPACName") or f"CID_{p.get('CID', '')}",
                })
            return {
                "source": "pubchem",
                "query": query,
                "total_found": len(compounds),
                "compounds": compounds,
            }
    except Exception:
        pass

    # Fallback: auto-complete search
    url2 = "https://pubchem.ncbi.nlm.nih.gov/rest/autocomplete/compound/" + query
    try:
        resp2 = httpx.get(url2, params={"limit": limit}, timeout=30)
        resp2.raise_for_status()
        data2 = resp2.json()
        suggestions = data2.get("dictionary_terms", {}).get("compound", [])
        return {
            "source": "pubchem",
            "query": query,
            "suggestions": suggestions[:limit],
            "note": "Exact match not found. Try one of these names with import_compounds.",
        }
    except Exception as exc:
        return {"error": f"PubChem API error: {exc}"}


def _import_coconut(query: Optional[str], limit: int) -> dict:
    if not query:
        return {"error": "query is required for COCONUT search"}

    url = "https://coconut.naturalproducts.net/api/search/simple"
    try:
        resp = httpx.get(url, params={"query": query, "limit": limit}, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        return {"error": f"COCONUT API error: {exc}"}

    compounds = []
    items = data if isinstance(data, list) else data.get("naturalProducts", data.get("items", []))
    for item in items:
        smi = item.get("smiles") or item.get("canonical_smiles")
        if not smi:
            continue
        compounds.append({
            "compound_id": item.get("coconut_id") or item.get("id", ""),
            "smiles": smi,
            "source": "coconut",
            "name": item.get("name") or item.get("coconut_id", ""),
        })
        if len(compounds) >= limit:
            break

    return {
        "source": "coconut",
        "query": query,
        "total_found": len(compounds),
        "compounds": compounds,
    }


def _import_dude(query: Optional[str], limit: int) -> dict:
    if not query:
        return {"error": "query (target name) is required for DUD-E"}

    target = query.lower().strip()
    url = f"http://dude.docking.org/targets/{target}/actives_final.ism"
    try:
        resp = httpx.get(url, timeout=30, follow_redirects=True)
        resp.raise_for_status()
    except Exception as exc:
        return {"error": f"DUD-E download error for target '{target}': {exc}"}

    compounds = []
    for line in resp.text.strip().split("\n"):
        parts = line.strip().split()
        if len(parts) >= 1:
            smi = parts[0]
            cid = parts[1] if len(parts) > 1 else f"dude_{len(compounds)}"
            compounds.append({
                "compound_id": cid,
                "smiles": smi,
                "source": "dude",
                "name": cid,
            })
            if len(compounds) >= limit:
                break

    return {
        "source": "dude",
        "query": query,
        "total_found": len(compounds),
        "compounds": compounds,
    }


def _detect_col(columns, candidates: List[str]) -> Optional[str]:
    for c in candidates:
        if c in columns:
            return c
    # Case-insensitive fallback
    col_lower = {str(c).lower(): c for c in columns}
    for c in candidates:
        if c.lower() in col_lower:
            return col_lower[c.lower()]
    return None


# ---------------------------------------------------------------------------
# Result formatter (shared with MCP server)
# ---------------------------------------------------------------------------

def _format_result(result: Any) -> dict:
    output: Dict[str, Any] = {
        "compound_id": result.compound_id,
        "smiles_input": result.smiles_input,
        "smiles_standardized": result.smiles_standardized,
        "properties": {
            "mw": result.properties.mw,
            "logp": result.properties.logp,
            "tpsa": result.properties.tpsa,
            "hbd": result.properties.hbd,
            "hba": result.properties.hba,
        },
        "cns_mpo": {
            "score": result.cns_mpo.score,
            "passed_filter": result.cns_mpo.passed_filter,
            "subscores": result.cns_mpo.subscores.model_dump(),
        },
        "passed_mpo_filter": result.passed_mpo_filter,
    }

    if result.affinity and result.affinity.scores:
        output["affinity"] = {
            "model": result.affinity.model.value,
            "n_proteins": len(result.affinity.scores),
            "top_5": [
                {"protein": s.protein_id, "score": round(s.score_norm, 4)}
                for s in sorted(result.affinity.scores, key=lambda x: -x.score_norm)[:5]
            ],
        }
    else:
        output["affinity"] = None

    if result.heuristic:
        d = result.heuristic.diagnostics
        output["heuristic"] = {
            "p_bbb": result.heuristic.p_bbb,
            "reason": d.reason,
            "veto": d.veto,
            "veto_protein": d.veto_protein,
            "score_bind": d.score_bind,
            "score_mpo": d.score_mpo,
            "score_total": d.score_total,
        }
    else:
        output["heuristic"] = None

    return output


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

TOOL_DISPATCH: Dict[str, Callable[..., dict]] = {
    "score_compound": _score_compound,
    "score_with_affinity": _score_with_affinity,
    "get_pipeline_info": _get_pipeline_info,
    "explain_score": _explain_score,
    "import_compounds": _import_compounds,
}


def _execute_tool(name: str, arguments: Dict[str, Any]) -> dict:
    """Execute a tool by name with error handling."""
    fn = TOOL_DISPATCH.get(name)
    if fn is None:
        return {"error": f"Unknown function: {name}"}
    try:
        return fn(**arguments)
    except Exception as exc:
        logger.exception("Tool %s failed", name)
        return {"error": f"{name} failed: {exc}"}


# ---------------------------------------------------------------------------
# Pydantic models for OpenAI chat completions
# ---------------------------------------------------------------------------

class ToolCallFunction(BaseModel):
    name: str
    arguments: str  # JSON-encoded string per OpenAI spec


class ToolCall(BaseModel):
    id: str
    type: str = "function"
    function: ToolCallFunction


class Message(BaseModel):
    role: str
    content: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    tool_call_id: Optional[str] = None
    name: Optional[str] = None


class ChatCompletionRequest(BaseModel):
    model: str = "bbnuke"
    messages: List[Message]
    tools: Optional[List[dict]] = None
    tool_choice: Optional[Any] = None
    stream: bool = False


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(
    title="BBB-Nuke OpenAI Functions",
    description="OpenAI-compatible function-calling interface for the BBB-Nuke pipeline.",
    version="0.1.0",
)


@app.get("/v1/functions")
def get_functions() -> dict:
    """Return available function schemas in OpenAI tools format."""
    return {"functions": FUNCTION_SCHEMAS}


@app.post("/v1/tools/{function_name}")
async def call_tool(function_name: str, request: Request) -> dict:
    """Invoke a tool directly by name with JSON arguments."""
    if function_name not in TOOL_DISPATCH:
        raise HTTPException(404, f"Unknown function: {function_name}")

    try:
        body = await request.json()
    except Exception:
        body = {}

    return _execute_tool(function_name, body)


@app.post("/v1/chat/completions")
async def chat_completions(req: ChatCompletionRequest) -> dict:
    """OpenAI-compatible chat completions endpoint.

    Scans messages for tool_calls, executes them, and returns results
    in OpenAI response format. Does NOT proxy to an LLM.
    """
    if req.stream:
        raise HTTPException(400, "Streaming is not supported.")

    # Find tool_calls in messages
    tool_calls_to_execute: List[ToolCall] = []
    for msg in reversed(req.messages):
        if msg.tool_calls:
            tool_calls_to_execute = msg.tool_calls
            break

    if not tool_calls_to_execute:
        # No tool_calls found — return available tools as guidance
        tool_names = [s["function"]["name"] for s in FUNCTION_SCHEMAS]
        return _chat_response(
            content=(
                "BBB-Nuke tool server. Available tools: "
                + ", ".join(tool_names)
                + ". Send a message with tool_calls to execute."
            ),
            finish_reason="stop",
        )

    # Execute each tool call
    results = []
    for tc in tool_calls_to_execute:
        try:
            args = json.loads(tc.function.arguments) if tc.function.arguments else {}
        except json.JSONDecodeError:
            args = {}

        result = _execute_tool(tc.function.name, args)
        results.append({
            "id": tc.id,
            "type": "function",
            "function": {
                "name": tc.function.name,
                "arguments": json.dumps(result),
            },
        })

    return _chat_response(tool_calls=results, finish_reason="tool_calls")


def _chat_response(
    content: Optional[str] = None,
    tool_calls: Optional[List[dict]] = None,
    finish_reason: str = "stop",
) -> dict:
    """Build an OpenAI-format chat completion response."""
    message: Dict[str, Any] = {"role": "assistant"}
    if content is not None:
        message["content"] = content
    else:
        message["content"] = None
    if tool_calls:
        message["tool_calls"] = tool_calls

    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:12]}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": "bbnuke",
        "choices": [
            {
                "index": 0,
                "message": message,
                "finish_reason": finish_reason,
            }
        ],
        "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    import argparse

    import uvicorn

    parser = argparse.ArgumentParser(description="BBB-Nuke OpenAI Functions Server")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8081, help="Port (default: 8081)")
    parser.add_argument("--reload", action="store_true", help="Auto-reload on changes")
    args = parser.parse_args()

    uvicorn.run(
        "bbnuke.openai_functions:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
