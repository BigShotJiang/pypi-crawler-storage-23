"""Allow running as: python -m bbnuke.openai_functions"""

from bbnuke.openai_functions import main

main()
