"""Workflow step: batch_score — run the scoring pipeline on a compound set."""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from bbnuke.core.schemas import CompoundInput, PipelineConfig
from bbnuke.pipeline.runner import run_batch
from bbnuke.workflows.engine import register_step
from bbnuke.workflows.models import StepType, WorkflowStep

logger = logging.getLogger(__name__)


@register_step(StepType.batch_score)
async def handle_batch_score(
    step: WorkflowStep, context: Dict[str, Any]
) -> Dict[str, Any]:
    """Score a list of compounds through the CPU pipeline.

    Config keys:
        compounds: List[dict] — each with "compound_id" and "smiles"
        config: Optional[dict] — PipelineConfig overrides
        input_from: Optional[str] — step ID to pull compounds from (overrides compounds)
    """
    config_dict = step.config.get("config", {})
    config = PipelineConfig(**(config_dict or {}))

    # Resolve compound list — either from config or from a prior step
    input_from = step.config.get("input_from")
    if input_from and input_from in context:
        compounds_data: List[Dict[str, str]] = context[input_from].get("compounds", [])
    else:
        compounds_data = step.config.get("compounds", [])

    if not compounds_data:
        return {"compounds": [], "count": 0, "error": "No compounds provided"}

    compounds = [CompoundInput(**c) for c in compounds_data]
    logger.info("Step %s: scoring %d compounds", step.id, len(compounds))

    results = run_batch(compounds, weights_path=config.weights_path)
    results_dicts = [r.model_dump(mode="json") for r in results]

    passing = [r for r in results_dicts if r.get("passed_mpo_filter", False)]

    return {
        "compounds": [
            {"compound_id": r["compound_id"], "smiles": r["smiles"]}
            for r in results_dicts
        ],
        "results": results_dicts,
        "count": len(results_dicts),
        "passed_mpo": len(passing),
    }
