"""Workflow step: parameter_sweep — run N parallel batch jobs with varied hyperparameters."""

from __future__ import annotations

import copy
import logging
from typing import Any, Dict, List

from bbnuke.core.schemas import CompoundInput, PipelineConfig
from bbnuke.pipeline.runner import run_batch
from bbnuke.workflows.engine import register_step
from bbnuke.workflows.models import StepType, WorkflowStep

logger = logging.getLogger(__name__)


@register_step(StepType.parameter_sweep)
async def handle_parameter_sweep(
    step: WorkflowStep, context: Dict[str, Any]
) -> Dict[str, Any]:
    """Run the pipeline multiple times, varying one or more parameters.

    Config keys:
        compounds: List[dict] — each with "compound_id" and "smiles"
        input_from: Optional[str] — step ID to pull compounds from
        sweep_param: str — dot-separated path to the parameter to sweep (e.g. "efflux_veto_threshold")
        sweep_values: List[float|int|str] — values to test
        base_config: Optional[dict] — base PipelineConfig overrides
    """
    # Resolve compounds
    input_from = step.config.get("input_from")
    if input_from and input_from in context:
        compounds_data: List[Dict[str, str]] = context[input_from].get("compounds", [])
    else:
        compounds_data = step.config.get("compounds", [])

    if not compounds_data:
        return {"sweeps": [], "error": "No compounds provided"}

    sweep_param = step.config.get("sweep_param", "")
    sweep_values = step.config.get("sweep_values", [])
    base_config = step.config.get("base_config", {})

    if not sweep_param or not sweep_values:
        return {"sweeps": [], "error": "sweep_param and sweep_values required"}

    compounds = [CompoundInput(**c) for c in compounds_data]
    sweep_results: List[Dict[str, Any]] = []

    for value in sweep_values:
        # Build config with swept parameter
        cfg_dict = copy.deepcopy(base_config)
        cfg_dict[sweep_param] = value
        config = PipelineConfig(**cfg_dict)

        logger.info(
            "Step %s: sweep %s=%s (%d compounds)",
            step.id, sweep_param, value, len(compounds),
        )

        results = run_batch(compounds, weights_path=config.weights_path)
        results_dicts = [r.model_dump(mode="json") for r in results]
        passing = [r for r in results_dicts if r.get("passed_mpo_filter", False)]

        sweep_results.append({
            "param_value": value,
            "results": results_dicts,
            "count": len(results_dicts),
            "passed_mpo": len(passing),
            "mean_p_bbb": _safe_mean([
                r.get("p_bbb") for r in results_dicts if r.get("p_bbb") is not None
            ]),
        })

    return {
        "sweep_param": sweep_param,
        "sweep_values": sweep_values,
        "sweeps": sweep_results,
        "total_runs": len(sweep_results),
    }


def _safe_mean(values: List[float]) -> float:
    """Compute mean, returning 0.0 for empty list."""
    if not values:
        return 0.0
    return sum(values) / len(values)
