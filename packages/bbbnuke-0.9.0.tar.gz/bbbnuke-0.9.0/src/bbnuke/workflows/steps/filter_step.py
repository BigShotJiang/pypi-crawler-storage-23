"""Workflow step: filter — select compounds by metric threshold or top-K."""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from bbnuke.workflows.engine import register_step
from bbnuke.workflows.models import StepType, WorkflowStep

logger = logging.getLogger(__name__)


@register_step(StepType.filter)
async def handle_filter(
    step: WorkflowStep, context: Dict[str, Any]
) -> Dict[str, Any]:
    """Filter compounds from a prior step's results.

    Config keys:
        input_from: str — step ID to pull results from (required)
        metric: str — key in result dict to filter on (e.g. "p_bbb", "cns_mpo.score")
        min_value: Optional[float] — keep compounds with metric >= this
        max_value: Optional[float] — keep compounds with metric <= this
        top_k: Optional[int] — keep only top K by metric (descending)
    """
    input_from = step.config.get("input_from", "")
    if not input_from or input_from not in context:
        return {"compounds": [], "results": [], "error": "input_from step not found"}

    source = context[input_from]
    results: List[Dict[str, Any]] = source.get("results", [])

    if not results:
        return {"compounds": [], "results": [], "count": 0, "filtered_from": 0}

    metric = step.config.get("metric", "p_bbb")
    min_value = step.config.get("min_value")
    max_value = step.config.get("max_value")
    top_k = step.config.get("top_k")

    # Extract metric values using dot-notation
    def _get_metric(r: Dict[str, Any]) -> Any:
        val = r
        for key in metric.split("."):
            if isinstance(val, dict):
                val = val.get(key)
            else:
                return None
        return val

    # Apply threshold filters
    filtered = []
    for r in results:
        val = _get_metric(r)
        if val is None:
            continue
        if min_value is not None and val < min_value:
            continue
        if max_value is not None and val > max_value:
            continue
        filtered.append(r)

    # Apply top-K
    if top_k is not None and top_k > 0:
        filtered.sort(key=lambda r: _get_metric(r) or 0, reverse=True)
        filtered = filtered[:top_k]

    logger.info(
        "Step %s: filtered %d → %d compounds (metric=%s)",
        step.id, len(results), len(filtered), metric,
    )

    return {
        "compounds": [
            {"compound_id": r.get("compound_id", ""), "smiles": r.get("smiles", "")}
            for r in filtered
        ],
        "results": filtered,
        "count": len(filtered),
        "filtered_from": len(results),
    }
