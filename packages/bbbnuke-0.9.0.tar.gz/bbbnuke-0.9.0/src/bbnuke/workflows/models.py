"""Workflow definition models.

Workflows are declarative DAGs of steps, stored as JSON in the database.
The engine executes them by dispatching each step to the appropriate queue.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class StepType(str, Enum):
    batch_score = "batch_score"
    parameter_sweep = "parameter_sweep"
    filter = "filter"
    branch = "branch"
    loop = "loop"


class StepStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    skipped = "skipped"


class WorkflowStep(BaseModel):
    """A single step in a workflow DAG."""

    id: str = Field(description="Unique step ID within the workflow")
    type: StepType
    name: str = ""
    config: Dict[str, Any] = Field(default_factory=dict)
    depends_on: List[str] = Field(
        default_factory=list,
        description="Step IDs that must complete before this step runs",
    )
    status: StepStatus = StepStatus.pending
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class WorkflowDefinition(BaseModel):
    """A complete workflow definition (DAG)."""

    name: str
    description: str = ""
    steps: List[WorkflowStep]
    max_iterations: int = Field(default=5, ge=1, le=100)

    def get_step(self, step_id: str) -> Optional[WorkflowStep]:
        for step in self.steps:
            if step.id == step_id:
                return step
        return None

    def ready_steps(self) -> List[WorkflowStep]:
        """Return steps whose dependencies are all completed."""
        completed = {s.id for s in self.steps if s.status == StepStatus.completed}
        return [
            s for s in self.steps
            if s.status == StepStatus.pending
            and all(dep in completed for dep in s.depends_on)
        ]

    @property
    def is_complete(self) -> bool:
        return all(
            s.status in (StepStatus.completed, StepStatus.skipped, StepStatus.failed)
            for s in self.steps
        )
