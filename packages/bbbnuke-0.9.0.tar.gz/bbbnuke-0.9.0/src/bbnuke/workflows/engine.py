"""Workflow DAG executor.

Walks the DAG, dispatches ready steps, collects results, advances state.
Designed to be called by the orchestrator worker.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from bbnuke.workflows.models import (
    StepStatus,
    StepType,
    WorkflowDefinition,
    WorkflowStep,
)

logger = logging.getLogger(__name__)


# Step handler registry
_STEP_HANDLERS: Dict[StepType, Any] = {}


def register_step(step_type: StepType):
    """Decorator to register a step handler function."""
    def decorator(func):
        _STEP_HANDLERS[step_type] = func
        return func
    return decorator


async def execute_step(step: WorkflowStep, context: Dict[str, Any]) -> Dict[str, Any]:
    """Execute a single workflow step.

    Args:
        step: The step to execute.
        context: Shared workflow context (accumulated results from prior steps).

    Returns:
        Step result dict.
    """
    handler = _STEP_HANDLERS.get(step.type)
    if handler is None:
        raise ValueError(f"No handler registered for step type: {step.type}")

    return await handler(step, context)


async def run_workflow(
    definition: WorkflowDefinition,
    initial_context: Optional[Dict[str, Any]] = None,
) -> WorkflowDefinition:
    """Execute a workflow to completion.

    Walks the DAG, executing ready steps in dependency order.
    Returns the updated definition with all step statuses and results.

    Args:
        definition: The workflow definition to execute.
        initial_context: Initial data available to all steps.

    Returns:
        Updated WorkflowDefinition with results.
    """
    context: Dict[str, Any] = initial_context or {}
    iteration = 0

    while not definition.is_complete and iteration < definition.max_iterations:
        ready = definition.ready_steps()
        if not ready:
            logger.warning("Workflow stalled: no ready steps but not complete")
            break

        for step in ready:
            step.status = StepStatus.running
            logger.info("Executing step %s (%s)", step.id, step.type)

            try:
                result = await execute_step(step, context)
                step.result = result
                step.status = StepStatus.completed
                # Merge step results into context for downstream steps
                context[step.id] = result
                logger.info("Step %s completed", step.id)
            except Exception as e:
                step.error = str(e)
                step.status = StepStatus.failed
                logger.error("Step %s failed: %s", step.id, e)

        iteration += 1

    return definition


# Import step implementations to trigger registration
from bbnuke.workflows.steps import batch_score, parameter_sweep, filter_step  # noqa: E402, F401
