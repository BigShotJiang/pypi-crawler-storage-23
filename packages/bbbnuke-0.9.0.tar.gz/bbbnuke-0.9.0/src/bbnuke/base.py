from abc import ABC, abstractmethod

class ProfilerABC(ABC):
    def __init__(self, smiles: str | list[str]) -> None:
        self.smiles = smiles

    @abstractmethod
    def get_profile(self) -> float | list[float]:
        """Score method to be implemented by subclasses."""
        pass
    @abstractmethod
    def classify(self) -> bool:
        """Classify method to be implemented by subclasses."""
        pass

class PropPredABC(ABC):
    def __init__(self, smiles: str | list[str]) -> None:
        self.smiles = smiles

    @abstractmethod
    def predict(self) -> float | list[float]:
        """Score method to be implemented by subclasses."""
        pass

class OptimizerABC(ABC):
    def __init__(self, smiles: str | list[str]) ->None:
        self.smiles = smiles

    @abstractmethod
    def optimize(self) ->  str | list[str]:
        """Optimize method to be implemented by subclasses."""
        pass

class StandardizerABC(ABC):
    def __init__(self, smiles: str | list[str]) -> None:
        self.smiles = smiles

    @abstractmethod
    def standardize(self) -> str | list[str]:
        """Standardize method to be implemented by subclasses."""
        pass
