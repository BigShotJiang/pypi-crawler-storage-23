"""BBB-Nuke constants: protein aliases, default hyperparameters."""

from __future__ import annotations

# Canonical alias mapping: canonical_name -> set of known variants
# Maps UniProt mnemonics, gene symbols, and common names to the canonical
# name used in BBB_protein_core_table.xlsx.
PROTEIN_ALIASES: dict[str, set[str]] = {
    # --- Efflux transporters ---
    "MDR1": {"MDR1", "ABCB1", "P-GP", "PGP", "MDR-1"},
    "ABCG2": {"ABCG2", "BCRP"},
    "MRP1": {"MRP1", "ABCC1"},
    "MRP2": {"MRP2", "ABCC2"},
    "MRP4": {"MRP4", "ABCC4"},
    "MRP5": {"MRP5", "ABCC5"},

    # --- Carriers (SLC family → common names) ---
    "MATE1": {"MATE1", "SLC47A1", "S47A1"},
    "LAT1": {"LAT1", "SLC7A5"},
    "OATP1A2": {"OATP1A2", "SO1A2", "SLCO1A2"},
    "OATP2B1": {"OATP2B1", "SO2B1", "SLCO2B1"},
    "OATP1C1": {"OATP1C1", "SO1C1", "SLCO1C1"},
    "OATP3A1": {"OATP3A1", "SO3A1", "SLCO3A1"},
    "OAT3": {"OAT3", "S22A8", "SLC22A8"},
    "MCT2": {"MCT2", "MOT2", "SLC16A7"},
    "PMAT": {"PMAT", "S29A4", "SLC29A4"},
    "EAAT1": {"EAAT1", "EAA1", "SLC1A3"},

    # --- Enzymes (UniProt mnemonic → common name) ---
    "ENPEP": {"ENPEP", "AMPE"},
    "ANPEP": {"ANPEP", "AMPN"},
    "ALPL": {"ALPL", "PPBT"},
    "NT5E": {"NT5E", "5NTD"},
    "ENTPD1": {"ENTPD1", "ENTP1"},
    "BCHE": {"BCHE", "CHLE"},

    # --- Other ---
    "CYP2E1": {"CYP2E1", "CYTOCHROME P450 2E1"},
}

# Heuristic hyperparameters
LOGISTIC_K: float = 0.1352
EFFLUX_VETO_THRESHOLD: float = 0.7
MPO_GAIN_COEFF: float = 3.5
MPO_FILTER_CUTOFF: float = 3.0

# Per-protein veto threshold overrides (canonical name -> threshold).
# Proteins not listed here use the default EFFLUX_VETO_THRESHOLD.
EFFLUX_VETO_OVERRIDES: dict[str, float] = {
    "MATE1": 0.85,
}
