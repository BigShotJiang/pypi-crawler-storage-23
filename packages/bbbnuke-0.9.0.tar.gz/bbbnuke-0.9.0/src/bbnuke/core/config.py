"""Environment-based configuration for BBB-Nuke API server."""

from __future__ import annotations

import os
from typing import List, Optional


class Settings:
    """Application settings loaded from environment variables.

    All settings have sensible defaults for local development.
    In production, override via environment variables prefixed with BBNUKE_.
    """

    def __init__(self) -> None:
        self.host: str = os.getenv("BBNUKE_HOST", "0.0.0.0")
        self.port: int = int(os.getenv("BBNUKE_PORT", "8000"))
        self.debug: bool = os.getenv("BBNUKE_DEBUG", "false").lower() in ("true", "1", "yes")
        self.workers: int = int(os.getenv("BBNUKE_WORKERS", "1"))

        # CORS
        cors_origins = os.getenv("BBNUKE_CORS_ORIGINS", "*")
        self.cors_origins: List[str] = [o.strip() for o in cors_origins.split(",")]

        # API key (Tier A: single key; Tier B: database-backed)
        self.api_key: Optional[str] = os.getenv("BBNUKE_API_KEY")

        # Rate limiting
        self.rate_limit_rpm: int = int(os.getenv("BBNUKE_RATE_LIMIT_RPM", "100"))

        # Pipeline defaults
        self.weights_path: Optional[str] = os.getenv("BBNUKE_WEIGHTS_PATH")

        # Batch limits
        self.max_batch_size: int = int(os.getenv("BBNUKE_MAX_BATCH_SIZE", "10000"))

        # Database
        self.database_url: str = os.getenv(
            "BBNUKE_DATABASE_URL", "sqlite+aiosqlite:///bbnuke.db"
        )

        # Redis
        self.redis_url: str = os.getenv("BBNUKE_REDIS_URL", "redis://localhost:6379")

        # Agent runs directory
        self.runs_dir: str = os.getenv("BBNUKE_RUNS_DIR", "runs")

        # PSICHIC affinity inference
        self.psichic_repo: Optional[str] = os.getenv(
            "BBNUKE_PSICHIC_REPO",
            os.path.expanduser("~/Documents/PSICHIC"),
        )
        self.psichic_model_path: Optional[str] = os.getenv(
            "BBNUKE_PSICHIC_MODEL",
            os.path.expanduser("~/Documents/PSICHIC/trained_weights/multitask_PSICHIC"),
        )
        self.psichic_device: str = os.getenv("BBNUKE_PSICHIC_DEVICE", "cpu")
        self.psichic_batch_size: int = int(os.getenv("BBNUKE_PSICHIC_BATCH_SIZE", "16"))

        # MolGpKa pKa prediction
        self.molgpka_dir: Optional[str] = os.getenv(
            "BBNUKE_MOLGPKA_DIR",
            os.path.expanduser("~/Documents/MolGpKa/src"),
        )
        self.molgpka_python: str = os.getenv(
            "BBNUKE_MOLGPKA_PYTHON",
            os.path.expanduser("~/opt/anaconda3/bin/python"),
        )


# Singleton
settings = Settings()
