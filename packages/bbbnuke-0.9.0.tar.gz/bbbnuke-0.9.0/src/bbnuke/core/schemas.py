"""Pydantic data models for the BBB-Nuke pipeline.

These models define the contract between every stage of the pipeline.
All inter-module communication flows through these types.

Hierarchy:
    CompoundInput          → pipeline entry point
    StandardizationResult  → after SMILES canonicalization
    PropertyResult         → RDKit descriptors
    PkaResult              → MolGpKa pKa predictions
    CnsMpoResult           → CNS-MPO desirability scoring
    AffinityScore          → per-protein binding score (PSICHIC / AQAffinity)
    AffinityResult         → all scores for one compound + model metadata
    HeuristicResult        → BBB penetration probability + diagnostics
    PipelineResult         → complete per-compound output record
    PipelineConfig         → runtime configuration / hyperparameters
    BatchResult            → collection of PipelineResults + run metadata
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ProteinCategory(str, Enum):
    """Biological role of a BBB protein target."""
    carrier = "carrier"
    efflux = "efflux"
    enzyme = "enzyme"


class PkaSource(str, Enum):
    """Origin of the pKa value used in CNS-MPO."""
    molgpka = "molgpka"
    provided = "provided"
    placeholder = "placeholder"


class AffinityModel(str, Enum):
    """Which affinity model produced the score."""
    psichic = "psichic"
    aqaffinity = "aqaffinity"
    other = "other"


# ---------------------------------------------------------------------------
# Pipeline Input
# ---------------------------------------------------------------------------

class CompoundInput(BaseModel):
    """A single compound entering the pipeline."""

    compound_id: str = Field(min_length=1, description="Stable unique identifier")
    smiles: str = Field(min_length=1, description="Input SMILES string")

    @field_validator("smiles")
    @classmethod
    def smiles_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("SMILES must not be blank")
        return v.strip()


# ---------------------------------------------------------------------------
# Stage 1: Standardization
# ---------------------------------------------------------------------------

class StandardizationResult(BaseModel):
    """Result of SMILES standardization (canonicalization, salt strip, neutralize)."""

    input_smiles: str
    standardized_smiles: str
    is_valid: bool = True
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Stage 2: Physicochemical Properties
# ---------------------------------------------------------------------------

class PropertyResult(BaseModel):
    """RDKit physicochemical descriptors."""

    mw: float = Field(ge=0, description="Molecular weight (Da)")
    logp: float = Field(description="Crippen LogP")
    tpsa: float = Field(ge=0, description="Topological polar surface area (A^2)")
    hbd: int = Field(ge=0, description="Hydrogen bond donors")
    hba: int = Field(ge=0, description="Hydrogen bond acceptors")
    rotatable_bonds: int = Field(default=0, ge=0, description="Number of rotatable bonds")
    num_rings: int = Field(default=0, ge=0, description="Total ring count")
    aromatic_rings: int = Field(default=0, ge=0, description="Aromatic ring count")
    heavy_atoms: int = Field(default=0, ge=0, description="Heavy atom count")
    fsp3: float = Field(default=0.0, ge=0, le=1, description="Fraction of sp3 carbons")


# ---------------------------------------------------------------------------
# Stage 3: pKa Prediction
# ---------------------------------------------------------------------------

class PkaResult(BaseModel):
    """pKa prediction output for a compound."""

    acid_pkas: List[float] = Field(default_factory=list, description="Predicted acidic pKa values")
    base_pkas: List[float] = Field(default_factory=list, description="Predicted basic pKa values")
    representative_pka: Optional[float] = Field(
        default=None,
        description="Single pKa selected for CNS-MPO (max basic > min acidic > None)",
    )
    source: PkaSource = PkaSource.placeholder


# ---------------------------------------------------------------------------
# Stage 4: CNS-MPO Scoring
# ---------------------------------------------------------------------------

class CnsMpoSubscores(BaseModel):
    """Individual desirability subscores (0–1 each) for CNS-MPO."""

    mw: float = Field(ge=0, le=1)
    logp: float = Field(ge=0, le=1)
    tpsa: float = Field(ge=0, le=1)
    hbd: float = Field(ge=0, le=1)
    pka: float = Field(ge=0, le=1)
    clogd: float = Field(ge=0, le=1)


class CnsMpoResult(BaseModel):
    """CNS-MPO scoring result.

    Total score is the sum of 6 desirability subscores (range 0–6).
    Compounds scoring >= 3.0 pass the property checkpoint.
    """

    score: float = Field(ge=0, le=6, description="Total CNS-MPO score (0–6)")
    subscores: CnsMpoSubscores
    pka_used: Optional[float] = Field(default=None, description="Representative pKa value used")
    clogd: Optional[float] = Field(default=None, description="Computed cLogD at pH 7.4")
    pka_source: PkaSource = PkaSource.placeholder
    passed_filter: bool = Field(default=False, description="True if score >= cutoff (default 3.0)")


# ---------------------------------------------------------------------------
# Stage 5: Protein–Ligand Affinity
# ---------------------------------------------------------------------------

class AffinityScore(BaseModel):
    """A single protein–ligand affinity score."""

    protein_id: str = Field(min_length=1, description="Protein identifier (e.g. UniProt mnemonic)")
    score_raw: float = Field(description="Raw model score (e.g. 0–10 for PSICHIC)")
    score_norm: float = Field(ge=0, le=1, description="Normalized score (0–1)")
    model: AffinityModel = AffinityModel.psichic


class AffinityResult(BaseModel):
    """All affinity scores for a single compound, plus model metadata."""

    model: AffinityModel = AffinityModel.psichic
    model_version: Optional[str] = Field(default=None, description="e.g. PDBv2020_PSICHIC")
    device: Optional[str] = Field(default=None, description="cpu / cuda:0")
    scores: List[AffinityScore] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Stage 6: Heuristic Confidence Layer
# ---------------------------------------------------------------------------

class ProteinContribution(BaseModel):
    """Contribution of a single protein to the heuristic binding score."""

    protein_id: str = Field(description="Original protein ID from affinity input")
    canonical_id: str = Field(description="Resolved canonical name (after alias mapping)")
    binding_prob: float = Field(ge=0, le=1)
    weight: float = Field(description="Weight from protein core table (-3 to 5)")
    category: ProteinCategory
    weighted_contribution: float = Field(
        default=0.0,
        description="w * 2p (this protein's contribution to S_bind)",
    )


class HeuristicDiagnostics(BaseModel):
    """Full diagnostics from the heuristic confidence layer.

    Score breakdown:
        S_bind = sum(w_i * 2 * p_i)      — weighted binding contributions
        S_mpo  = c_mpo * (mpo - 3.0)     — MPO gain above baseline
        S_total = S_bind + S_mpo
        P_BBB  = 1 / (1 + exp(-k * S_total))
    """

    reason: str = Field(description="'OK', 'Efflux veto triggered', 'CNS-MPO < 3 cutoff', etc.")
    veto: bool = False
    veto_protein: Optional[str] = Field(default=None, description="Canonical ID of the efflux protein that triggered veto")
    veto_prob: Optional[float] = Field(default=None, description="Binding probability that triggered veto")
    score_bind: float = 0.0
    score_mpo: float = 0.0
    score_total: float = 0.0
    contributions: List[ProteinContribution] = Field(default_factory=list)

    # Hyperparameters used (for reproducibility)
    k: Optional[float] = Field(default=None, description="Logistic slope")
    c_mpo: Optional[float] = Field(default=None, description="MPO gain coefficient")
    threshold: Optional[float] = Field(default=None, description="Efflux veto threshold")


class HeuristicResult(BaseModel):
    """Output of the heuristic confidence layer."""

    p_bbb: float = Field(ge=0, le=1, description="BBB penetration probability")
    diagnostics: HeuristicDiagnostics


# ---------------------------------------------------------------------------
# Full Pipeline Output
# ---------------------------------------------------------------------------

class PipelineResult(BaseModel):
    """Complete per-compound output record.

    This is the production JSON contract. One record per compound.
    Downstream consumers (API, GUI, batch exports) serialize from this model.
    """

    compound_id: str
    smiles_input: str
    smiles_standardized: str
    properties: PropertyResult
    pka: Optional[PkaResult] = None
    cns_mpo: CnsMpoResult
    affinity: Optional[AffinityResult] = None
    heuristic: Optional[HeuristicResult] = None
    passed_mpo_filter: bool = Field(description="True if CNS-MPO >= cutoff")

    # Kept for backward compat with existing code — flat list view of scores
    @property
    def affinity_scores(self) -> List[AffinityScore]:
        if self.affinity is None:
            return []
        return self.affinity.scores

    model_config = ConfigDict(json_schema_extra={
            "example": {
                "compound_id": "risperidone",
                "smiles_input": "c1ccc2c(c1)Cc1ccccc1C2=O",
                "smiles_standardized": "O=C1c2ccccc2Cc2ccccc21",
                "properties": {
                    "mw": 410.49,
                    "logp": 2.73,
                    "tpsa": 55.31,
                    "hbd": 1,
                    "hba": 4,
                },
                "pka": {
                    "acid_pkas": [],
                    "base_pkas": [8.123, 6.5],
                    "representative_pka": 8.123,
                    "source": "molgpka",
                },
                "cns_mpo": {
                    "score": 4.53,
                    "subscores": {"mw": 0.64, "logp": 1.0, "tpsa": 1.0, "hbd": 0.75, "pka": 0.94, "clogd": 0.64},
                    "pka_used": 8.123,
                    "pka_source": "molgpka",
                    "passed_filter": True,
                },
                "affinity": {
                    "model": "psichic",
                    "model_version": "PDBv2020_PSICHIC",
                    "device": "cpu",
                    "scores": [
                        {"protein_id": "LAT1", "score_raw": 6.8, "score_norm": 0.68, "model": "psichic"},
                        {"protein_id": "GTR1", "score_raw": 4.1, "score_norm": 0.41, "model": "psichic"},
                    ],
                },
                "heuristic": {
                    "p_bbb": 0.826,
                    "diagnostics": {
                        "reason": "OK",
                        "veto": False,
                        "score_bind": 12.2,
                        "score_mpo": 3.06,
                        "score_total": 15.26,
                        "contributions": [],
                        "k": 0.1352,
                        "c_mpo": 2.0,
                        "threshold": 0.7,
                    },
                },
                "passed_mpo_filter": True,
            }
        })


# ---------------------------------------------------------------------------
# Pipeline Configuration
# ---------------------------------------------------------------------------

class PipelineConfig(BaseModel):
    """Runtime configuration for the BBB-Nuke pipeline.

    Serialized alongside results for full reproducibility.
    """

    # CNS-MPO
    mpo_cutoff: float = Field(default=3.0, description="Minimum CNS-MPO to proceed to affinity scoring")

    # Heuristic
    logistic_k: float = Field(default=0.1352, description="Logistic slope parameter")
    efflux_veto_threshold: float = Field(default=0.7, description="Binding prob above which efflux proteins trigger veto")
    mpo_gain_coeff: float = Field(default=2.0, description="Coefficient for MPO gain term")

    # pKa
    pka_source: PkaSource = Field(default=PkaSource.placeholder, description="Default pKa source if not provided")

    # Affinity
    affinity_model: AffinityModel = Field(default=AffinityModel.psichic)
    affinity_score_scale: float = Field(default=10.0, description="Raw score max for normalization")

    # Weights table
    weights_path: Optional[str] = Field(default=None, description="Path to protein weights Excel; None = bundled default")


# ---------------------------------------------------------------------------
# Batch Output
# ---------------------------------------------------------------------------

class BatchResult(BaseModel):
    """Collection of pipeline results for a batch run, plus run metadata."""

    results: List[PipelineResult]
    config: PipelineConfig = Field(default_factory=PipelineConfig)
    run_metadata: Dict[str, Any] = Field(default_factory=dict)
    timestamp: Optional[str] = Field(default=None)
    version: str = Field(default="0.1.0")

    @property
    def n_compounds(self) -> int:
        return len(self.results)

    @property
    def n_passed_mpo(self) -> int:
        return sum(1 for r in self.results if r.passed_mpo_filter)

    @property
    def n_vetoed(self) -> int:
        return sum(
            1 for r in self.results
            if r.heuristic is not None and r.heuristic.diagnostics.veto
        )

    def summary(self) -> Dict[str, Any]:
        return {
            "n_compounds": self.n_compounds,
            "n_passed_mpo": self.n_passed_mpo,
            "n_vetoed": self.n_vetoed,
            "version": self.version,
            "timestamp": self.timestamp,
        }
