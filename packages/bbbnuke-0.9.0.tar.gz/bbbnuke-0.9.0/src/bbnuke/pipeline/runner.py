"""BBB-Nuke pipeline orchestrator.

Chains: standardize → properties → pKa → CNS-MPO (with cLogD) → efflux screen → heuristic → result.

When no pre-computed affinity data is provided, the pipeline automatically runs
PSICHIC inference against 9 efflux transporter proteins (if PSICHIC is installed).
"""

from __future__ import annotations

from typing import List, Optional

from bbnuke.core.constants import MPO_FILTER_CUTOFF
from bbnuke.core.schemas import (
    AffinityResult,
    AffinityScore,
    CompoundInput,
    PipelineResult,
    PkaResult,
    PkaSource,
)
from bbnuke.modules.cns_mpo import compute_cns_mpo
from bbnuke.modules.heuristic import compute_classifier_heuristic, compute_heuristic
from bbnuke.modules.pka import PkaData, predict_single_pka
from bbnuke.modules.properties import compute_properties
from bbnuke.modules.standardize import standardize_smiles


def run_single(
    compound: CompoundInput,
    pka: float | None = None,
    pka_data: PkaData | None = None,
    affinity_scores: list[AffinityScore] | None = None,
    weights_path: str | None = None,
    run_efflux: bool = True,
) -> PipelineResult:
    """Run the full BBB-Nuke pipeline for a single compound.

    Args:
        compound: Input compound (id + SMILES).
        pka: Representative pKa (e.g., from MolGpKa). None = placeholder.
        pka_data: Full pKa data (acid/base lists) for cLogD calculation.
                  If provided, overrides pka with pka_data.representative.
        affinity_scores: Pre-computed protein-ligand affinity scores.
        weights_path: Path to protein weights table. None = bundled default.
        run_efflux: If True and no affinity_scores provided, automatically run
                    PSICHIC inference against 9 efflux transporter proteins.

    Returns:
        PipelineResult with all intermediate and final results.
    """
    # Step 1: Standardize
    std_smiles = standardize_smiles(compound.smiles)

    # Step 2: Properties
    props = compute_properties(std_smiles)

    # Step 3: pKa
    acid_pkas: Optional[List[float]] = None
    base_pkas: Optional[List[float]] = None
    pka_result = None

    if pka_data is not None:
        pka = pka_data.representative
        acid_pkas = pka_data.acid_pkas or None
        base_pkas = pka_data.base_pkas or None
        pka_result = PkaResult(
            acid_pkas=pka_data.acid_pkas,
            base_pkas=pka_data.base_pkas,
            representative_pka=pka_data.representative,
            source=PkaSource.provided if pka is not None else PkaSource.placeholder,
        )
    elif pka is not None:
        pka_result = PkaResult(
            representative_pka=pka,
            source=PkaSource.provided,
        )
    else:
        # No pKa data provided — run MolGpKa on-the-fly
        pka_data = predict_single_pka(std_smiles)
        if pka_data.representative is not None:
            pka = pka_data.representative
            acid_pkas = pka_data.acid_pkas or None
            base_pkas = pka_data.base_pkas or None
            pka_result = PkaResult(
                acid_pkas=pka_data.acid_pkas,
                base_pkas=pka_data.base_pkas,
                representative_pka=pka_data.representative,
                source=PkaSource.molgpka,
            )

    # Step 4: CNS-MPO (now with proper cLogD from Henderson-Hasselbalch)
    mpo = compute_cns_mpo(
        props,
        pka=pka,
        acid_pkas=acid_pkas,
        base_pkas=base_pkas,
    )

    passed = mpo.score >= MPO_FILTER_CUTOFF

    # Step 5: Affinity — use pre-computed or run live efflux screen
    if affinity_scores is None and run_efflux and passed:
        from bbnuke.modules.efflux import run_efflux_screen
        affinity_scores = run_efflux_screen(std_smiles, compound.compound_id)

    affinity_result = None
    if affinity_scores:
        affinity_result = AffinityResult(scores=affinity_scores)

    # Step 6: Heuristic — classifier-based (uses RDKit descriptors)
    # Efflux veto from PSICHIC data still applies.
    heuristic = compute_classifier_heuristic(
        properties=props,
        affinity_scores=affinity_scores if passed else None,
        weights_path=weights_path,
    )

    return PipelineResult(
        compound_id=compound.compound_id,
        smiles_input=compound.smiles,
        smiles_standardized=std_smiles,
        properties=props,
        pka=pka_result,
        cns_mpo=mpo,
        affinity=affinity_result,
        heuristic=heuristic,
        passed_mpo_filter=passed,
    )


def run_batch(
    compounds: list[CompoundInput],
    pka_map: dict[str, float] | None = None,
    pka_data_map: dict[str, PkaData] | None = None,
    affinity_map: dict[str, list[AffinityScore]] | None = None,
    weights_path: str | None = None,
    run_efflux: bool = True,
) -> list[PipelineResult]:
    """Run the pipeline for a batch of compounds.

    Args:
        compounds: List of input compounds.
        pka_map: {compound_id: representative_pka}. Used if pka_data_map not provided.
        pka_data_map: {compound_id: PkaData} with full acid/base lists for cLogD.
                      Takes precedence over pka_map.
        affinity_map: {compound_id: [AffinityScore, ...]}. Missing = no scoring.
        weights_path: Path to protein weights table.
        run_efflux: If True, run PSICHIC efflux screening for compounds without
                    pre-computed affinity data (batched for efficiency).

    Returns:
        List of PipelineResult, one per compound.
    """
    pka_map = pka_map or {}
    pka_data_map = pka_data_map or {}
    affinity_map = affinity_map or {}

    # Phase 1: Run standardize + properties + pKa + CNS-MPO for all compounds
    # to identify which ones pass MPO and need efflux screening
    pre_results: list[dict] = []
    for compound in compounds:
        pka_data = pka_data_map.get(compound.compound_id)
        pka_val = pka_map.get(compound.compound_id) if pka_data is None else None
        std_smiles = standardize_smiles(compound.smiles)
        props = compute_properties(std_smiles)

        acid_pkas: Optional[List[float]] = None
        base_pkas: Optional[List[float]] = None
        pka_result = None
        rep_pka = pka_val

        if pka_data is not None:
            rep_pka = pka_data.representative
            acid_pkas = pka_data.acid_pkas or None
            base_pkas = pka_data.base_pkas or None
            pka_result = PkaResult(
                acid_pkas=pka_data.acid_pkas,
                base_pkas=pka_data.base_pkas,
                representative_pka=pka_data.representative,
                source=PkaSource.provided if rep_pka is not None else PkaSource.placeholder,
            )
        elif rep_pka is not None:
            pka_result = PkaResult(
                representative_pka=rep_pka,
                source=PkaSource.provided,
            )
        else:
            from bbnuke.modules.pka import predict_single_pka as _predict_pka
            _pka_data = _predict_pka(std_smiles)
            if _pka_data.representative is not None:
                rep_pka = _pka_data.representative
                acid_pkas = _pka_data.acid_pkas or None
                base_pkas = _pka_data.base_pkas or None
                pka_result = PkaResult(
                    acid_pkas=_pka_data.acid_pkas,
                    base_pkas=_pka_data.base_pkas,
                    representative_pka=_pka_data.representative,
                    source=PkaSource.molgpka,
                )

        mpo = compute_cns_mpo(props, pka=rep_pka, acid_pkas=acid_pkas, base_pkas=base_pkas)
        passed = mpo.score >= MPO_FILTER_CUTOFF

        pre_results.append({
            "compound": compound,
            "std_smiles": std_smiles,
            "props": props,
            "pka_result": pka_result,
            "mpo": mpo,
            "passed": passed,
        })

    # Phase 2: Batch efflux screening for compounds that need it
    efflux_map: dict[str, list[AffinityScore]] = {}
    if run_efflux:
        need_efflux = [
            (pr["compound"].compound_id, pr["std_smiles"])
            for pr in pre_results
            if pr["passed"]
            and pr["compound"].compound_id not in affinity_map
        ]
        if need_efflux:
            from bbnuke.modules.efflux import run_efflux_screen_batch
            efflux_map = run_efflux_screen_batch(need_efflux)

    # Phase 3: Final scoring
    results = []
    for pr in pre_results:
        cid = pr["compound"].compound_id
        aff_scores = affinity_map.get(cid) or efflux_map.get(cid)

        affinity_result = None
        if aff_scores:
            affinity_result = AffinityResult(scores=aff_scores)

        heuristic = compute_classifier_heuristic(
            properties=pr["props"],
            affinity_scores=aff_scores if pr["passed"] else None,
            weights_path=weights_path,
        )

        results.append(PipelineResult(
            compound_id=cid,
            smiles_input=pr["compound"].smiles,
            smiles_standardized=pr["std_smiles"],
            properties=pr["props"],
            pka=pr["pka_result"],
            cns_mpo=pr["mpo"],
            affinity=affinity_result,
            heuristic=heuristic,
            passed_mpo_filter=pr["passed"],
        ))

    return results
