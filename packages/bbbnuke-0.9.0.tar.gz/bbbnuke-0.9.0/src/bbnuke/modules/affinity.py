"""PSICHIC protein-ligand affinity adapter.

Two modes of operation:
  1. **Read pre-computed CSV** — reads PSICHIC screening_master.csv output.
  2. **Run PSICHIC subprocess** — invokes psichic_workflow_infer.py.

PSICHIC produces regression scores in [0, 10]. We normalize to [0, 1]:
    score_norm = score_raw / 10.0

The adapter returns an affinity_map: {compound_id: [AffinityScore, ...]}.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from bbnuke.core.schemas import AffinityScore


def read_screening_csv(
    screening_csv: str,
    compound_col: str = "Compound_ID",
    protein_col: str = "Protein_ID",
    score_col: Optional[str] = None,
    score_scale: float = 10.0,
    use_binding_prob: bool = False,
    use_agonist: bool = False,
) -> Dict[str, List[AffinityScore]]:
    """Read a PSICHIC screening output CSV and return an affinity map.

    Args:
        screening_csv: Path to screening_master.csv or screening.csv.
        compound_col: Column for compound IDs.
        protein_col: Column for protein IDs.
        score_col: Column containing the raw score. If None, auto-detects
                   from common PSICHIC output column names.
        score_scale: Max value for normalization (default 10.0 for PSICHIC).
        use_binding_prob: If True, use 1 - predicted_nonbinder as score_norm
                         (already 0-1, no scaling needed). Overrides score_col.
        use_agonist: If True, use predicted_agonist as score_norm
                     (already 0-1, no scaling needed). Overrides score_col.

    Returns:
        Dict mapping compound_id to list of AffinityScore objects.
    """
    df = pd.read_csv(screening_csv)

    # Auto-detect columns
    compound_col = _resolve_col(df.columns, compound_col, [
        "Compound_ID", "compound_id", "compound", "Compound", "ligand_id",
    ])
    protein_col = _resolve_col(df.columns, protein_col, [
        "Protein_ID", "protein_id", "protein", "Protein",
    ])

    if use_agonist:
        if "predicted_agonist" not in df.columns:
            raise ValueError(
                f"use_agonist=True but 'predicted_agonist' not found. "
                f"Columns: {list(df.columns)}"
            )
    elif use_binding_prob:
        if "predicted_nonbinder" not in df.columns:
            raise ValueError(
                f"use_binding_prob=True but 'predicted_nonbinder' not found. "
                f"Columns: {list(df.columns)}"
            )
    else:
        if score_col is None:
            score_col = _find_score_col(df.columns)
        if score_col is None:
            raise ValueError(
                f"Cannot find score column in screening CSV. Columns: {list(df.columns)}\n"
                "Pass --score-col explicitly."
            )

    affinity_map: Dict[str, List[AffinityScore]] = {}

    for _, row in df.iterrows():
        cid = str(row[compound_col])
        pid = str(row[protein_col])

        if use_agonist:
            raw = float(row["predicted_agonist"])
            norm = max(0.0, min(1.0, raw))
        elif use_binding_prob:
            raw = 1.0 - float(row["predicted_nonbinder"])
            norm = max(0.0, min(1.0, raw))
        else:
            raw = float(row[score_col])
            norm = max(0.0, min(1.0, raw / score_scale))

        score = AffinityScore(
            protein_id=pid,
            score_raw=round(raw, 6),
            score_norm=round(norm, 6),
            model="psichic",
        )
        affinity_map.setdefault(cid, []).append(score)

    return affinity_map


def run_psichic(
    proteins_csv: str,
    ligands_csv: str,
    outdir: str,
    psichic_repo: str,
    trained_model_path: str,
    screen_script: str = "screening.py",
    device: str = "cpu",
    batch_size: int = 16,
    python_exe: Optional[str] = None,
    score_col: Optional[str] = None,
) -> Dict[str, List[AffinityScore]]:
    """Run PSICHIC inference via psichic_workflow_infer.py and return affinity map.

    Args:
        proteins_csv: CSV with protein IDs and sequences.
        ligands_csv: CSV with compound IDs and SMILES (should be CNS-MPO filtered).
        outdir: Output directory for PSICHIC results.
        psichic_repo: Path to PSICHIC repo (where screening.py lives).
        trained_model_path: Path to pretrained weights folder.
        screen_script: Screening script filename inside repo.
        device: "cpu" or "cuda:0".
        batch_size: Inference batch size.
        python_exe: Python executable. Defaults to current interpreter.
        score_col: Score column name in output. Auto-detected if None.

    Returns:
        Dict mapping compound_id to list of AffinityScore objects.

    Raises:
        RuntimeError: If PSICHIC subprocess fails.
        FileNotFoundError: If expected output files are missing.
    """
    python_exe = python_exe or sys.executable
    repo = Path(psichic_repo).expanduser().resolve()
    workflow_script = repo / "psichic_workflow_infer.py"

    if not workflow_script.exists():
        raise FileNotFoundError(f"PSICHIC workflow script not found: {workflow_script}")

    out = Path(outdir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    cmd = [
        python_exe, str(workflow_script),
        "--proteins_csv", str(proteins_csv),
        "--ligands_csv", str(ligands_csv),
        "--outdir", str(out),
        "--psichic_repo", str(repo),
        "--screen_script", screen_script,
        "--trained_model_path", str(trained_model_path),
        "--device", device,
        "--batch_size", str(batch_size),
    ]

    print(f"[PSICHIC] Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.stdout:
        print(result.stdout)
    if result.returncode != 0:
        raise RuntimeError(
            f"PSICHIC failed (exit {result.returncode}):\n{result.stderr}"
        )

    # Find the master CSV
    master_csv = out / "screening_master.csv"
    if not master_csv.exists():
        # Fallback to raw screening output
        alt = out / "psichic_screen_run" / "screening.csv"
        if alt.exists():
            master_csv = alt
        else:
            raise FileNotFoundError(
                f"PSICHIC output not found. Checked:\n  {master_csv}\n  {alt}"
            )

    return read_screening_csv(str(master_csv), score_col=score_col)


def prepare_filtered_ligands_csv(
    pipeline_results: list,
    output_path: str,
    smiles_col: str = "smiles",
    id_col: str = "compound_name",
) -> str:
    """Write a filtered ligands CSV (MPO >= 3) for PSICHIC input.

    Takes pipeline results (after MPO scoring) and writes only passing
    compounds to a CSV suitable for PSICHIC consumption.

    Args:
        pipeline_results: List of PipelineResult objects from run_batch.
        output_path: Where to write the filtered CSV.
        smiles_col: Column name for SMILES in output.
        id_col: Column name for compound ID in output.

    Returns:
        Path to the written CSV.
    """
    rows = []
    for r in pipeline_results:
        if r.passed_mpo_filter:
            rows.append({
                id_col: r.compound_id,
                smiles_col: r.smiles_standardized,
            })

    df = pd.DataFrame(rows)
    df.to_csv(output_path, index=False)
    print(f"[PSICHIC] Wrote {len(df)} filtered compounds to {output_path}")
    return str(output_path)


def _resolve_col(columns, preferred: str, candidates: List[str]) -> str:
    """Return preferred if it exists, otherwise find first matching candidate."""
    if preferred in columns:
        return preferred
    for c in candidates:
        if c in columns:
            return c
    raise ValueError(f"Cannot find column. Tried: {[preferred] + candidates}. Available: {list(columns)}")


def _find_score_col(columns) -> Optional[str]:
    """Auto-detect the PSICHIC score column."""
    # PSICHIC outputs vary; common patterns:
    score_candidates = [
        "Prediction", "prediction",
        "Score", "score",
        "Binding_Score", "binding_score",
        "pchembl_value", "pChEMBL",
        "affinity", "Affinity",
        "pred", "Pred",
        "y_pred", "Y_pred",
    ]
    for c in score_candidates:
        if c in columns:
            return c

    # Fallback: look for any column with "pred" or "score" in name
    for c in columns:
        cl = str(c).lower()
        if "pred" in cl or "score" in cl or "affinity" in cl:
            return c

    return None
