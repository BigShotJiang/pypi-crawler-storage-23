"""Vendored from PSICHIC: Virtual screening inference (stripped of training code)."""

from __future__ import annotations

import os
import sys

import numpy as np
import pandas as pd
import torch
from torch_geometric.loader import DataLoader
from torch_geometric.utils import degree


def virtual_screening(screen_df, model, data_loader, device='cpu'):
    """Run PSICHIC virtual screening inference (no interpretation saving).

    Args:
        screen_df: DataFrame with 'Protein' and 'Ligand' columns.
        model: Loaded PSICHIC net model.
        data_loader: DataLoader over ProteinMoleculeDataset.
        device: Torch device string.

    Returns:
        DataFrame with predicted_binding_affinity, predicted_binary_interaction,
        and multiclass prediction columns added.
    """
    if "ID" in screen_df.columns:
        for i, row in screen_df.iterrows():
            if pd.isna(row['ID']):
                screen_df.at[i, 'ID'] = f"PAIR_{i}"
    else:
        screen_df['ID'] = 'PAIR_'
        screen_df['ID'] += screen_df.index.astype(str)

    model.eval()

    with torch.no_grad():
        for data in data_loader:
            data = data.to(device)
            reg_pred, cls_pred, mcls_pred, sp_loss, o_loss, cl_loss, attention_dict = model(
                mol_x=data.mol_x, mol_x_feat=data.mol_x_feat, bond_x=data.mol_edge_attr,
                atom_edge_index=data.mol_edge_index, clique_x=data.clique_x,
                clique_edge_index=data.clique_edge_index, atom2clique_index=data.atom2clique_index,
                residue_x=data.prot_node_aa, residue_evo_x=data.prot_node_evo,
                residue_edge_index=data.prot_edge_index,
                residue_edge_weight=data.prot_edge_weight,
                mol_batch=data.mol_x_batch, prot_batch=data.prot_node_aa_batch,
                clique_batch=data.clique_x_batch,
                save_cluster=False
            )
            interaction_keys = list(zip(data.prot_key, data.mol_key))

            if reg_pred is not None:
                reg_pred_np = reg_pred.squeeze().reshape(-1).cpu().numpy()
            else:
                reg_pred_np = None

            if cls_pred is not None:
                cls_pred_np = torch.sigmoid(cls_pred).squeeze().reshape(-1).cpu().numpy()
            else:
                cls_pred_np = None

            if mcls_pred is not None:
                mcls_pred_np = torch.softmax(mcls_pred, dim=-1).cpu().numpy()
            else:
                mcls_pred_np = None

            for idx, key in enumerate(interaction_keys):
                matching_row = (screen_df['Protein'] == key[0]) & (screen_df['Ligand'] == key[1])
                if reg_pred_np is not None:
                    if 'predicted_binding_affinity' not in screen_df.columns:
                        screen_df['predicted_binding_affinity'] = None
                    screen_df.loc[matching_row, 'predicted_binding_affinity'] = reg_pred_np[idx]
                if cls_pred_np is not None:
                    if 'predicted_binary_interaction' not in screen_df.columns:
                        screen_df['predicted_binary_interaction'] = None
                    screen_df.loc[matching_row, 'predicted_binary_interaction'] = cls_pred_np[idx]
                if mcls_pred_np is not None:
                    if 'predicted_antagonist' not in screen_df.columns:
                        screen_df['predicted_antagonist'] = None
                        screen_df['predicted_nonbinder'] = None
                        screen_df['predicted_agonist'] = None
                    screen_df.loc[matching_row, ['predicted_antagonist', 'predicted_nonbinder', 'predicted_agonist']] = mcls_pred_np[idx].tolist()

    return screen_df


def protein_degree_from_dict(protein_dict):
    """Compute protein node degree histogram from a pre-computed protein dict."""
    protein_max_degree = -1
    for k, v in protein_dict.items():
        node_num = len(v['seq'])
        edge_index = v['edge_index']
        protein_degree = degree(edge_index[1], num_nodes=node_num, dtype=torch.long)
        protein_max_degree = max(protein_max_degree, protein_degree.max())

    protein_deg = torch.zeros(protein_max_degree + 1, dtype=torch.long)
    for k, v in protein_dict.items():
        node_num = len(v['seq'])
        edge_index = v['edge_index']
        protein_degree = degree(edge_index[1], num_nodes=node_num, dtype=torch.long)
        protein_deg += torch.bincount(protein_degree, minlength=protein_deg.numel())

    return protein_deg


def ligand_degree_from_dict(ligand_dict):
    """Compute ligand node degree histograms from a ligand dict."""
    mol_max_degree = -1
    clique_max_degree = -1

    for k, v in ligand_dict.items():
        mol_x = v['atom_feature']
        adj = v['bond_feature']
        mol_edge_index = adj.nonzero(as_tuple=False).t().contiguous()
        mol_d = degree(mol_edge_index[1], num_nodes=mol_x.shape[0], dtype=torch.long)
        mol_max_degree = max(mol_max_degree, int(mol_d.max()))
        clique_x = v['x_clique']
        clique_edge_index = v['tree_edge_index'].long()
        clique_d = degree(clique_edge_index[1], num_nodes=clique_x.shape[0], dtype=torch.long)
        clique_max_degree = max(clique_max_degree, int(clique_d.max()))

    mol_deg = torch.zeros(mol_max_degree + 1, dtype=torch.long)
    clique_deg = torch.zeros(clique_max_degree + 1, dtype=torch.long)

    for k, v in ligand_dict.items():
        mol_x = v['atom_feature']
        adj = v['bond_feature']
        mol_edge_index = adj.nonzero(as_tuple=False).t().contiguous()
        mol_d = degree(mol_edge_index[1], num_nodes=mol_x.shape[0], dtype=torch.long)
        mol_deg += torch.bincount(mol_d, minlength=mol_deg.numel())
        clique_x = v['x_clique']
        clique_edge_index = v['tree_edge_index'].long()
        clique_d = degree(clique_edge_index[1], num_nodes=clique_x.shape[0], dtype=torch.long)
        clique_deg += torch.bincount(clique_d, minlength=clique_deg.numel())

    return mol_deg, clique_deg
