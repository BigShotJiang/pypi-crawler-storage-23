"""Vendored from PSICHIC: Main GNN model for drug-protein interaction prediction."""

import math

import torch
import torch.nn.functional as F
import numpy as np
import scipy.sparse as sp
from torch.nn import Embedding, Linear
from torch_scatter import scatter
from torch_geometric.nn import global_add_pool
from torch_geometric.nn.norm import GraphNorm
from torch_geometric.utils import (
    degree, to_scipy_sparse_matrix, segregate_self_loops,
    dense_to_sparse, to_dense_adj, to_dense_batch, degree, subgraph, softmax,
)

from bbnuke.modules.psichic.layers import (
    MLP, AtomEncoder, Drug_PNAConv, Protein_PNAConv, DrugProteinConv,
    PosLinear, GCNCluster, dropout_edge, unbatch, dropout_node,
)
from bbnuke.modules.psichic.drug_pool import MotifPool
from bbnuke.modules.psichic.protein_pool import dense_mincut_pool

EPS = 1e-15


class net(torch.nn.Module):
    def __init__(self, mol_deg, prot_deg,
                 mol_in_channels=43, prot_in_channels=33, prot_evo_channels=1280,
                 hidden_channels=200,
                 pre_layers=2, post_layers=1,
                 aggregators=['mean', 'min', 'max', 'std'],
                 scalers=['identity', 'amplification', 'linear'],
                 total_layer=3,
                 K=[5, 10, 20],
                 t=1,
                 heads=5,
                 dropout=0,
                 dropout_attn_score=0.2,
                 drop_atom=0,
                 drop_residue=0,
                 dropout_cluster_edge=0,
                 gaussian_noise=0,
                 regression_head=True,
                 classification_head=False,
                 multiclassification_head=0,
                 device='cpu'):
        super(net, self).__init__()
        self.total_layer = total_layer

        if (regression_head or classification_head) == False:
            raise Exception('must have one objective')

        self.regression_head = regression_head
        self.classification_head = classification_head
        self.multiclassification_head = multiclassification_head

        if isinstance(K, int):
            K = [K] * total_layer

        # MOLECULE IN FEAT
        self.atom_type_encoder = Embedding(20, hidden_channels)
        self.atom_feat_encoder = MLP([mol_in_channels, hidden_channels * 2, hidden_channels], out_norm=True)

        # Clique IN feat
        self.clique_encoder = Embedding(4, hidden_channels)

        # PROTEIN IN FEAT
        self.prot_evo = MLP([prot_evo_channels, hidden_channels * 2, hidden_channels], out_norm=True)
        self.prot_aa = MLP([prot_in_channels, hidden_channels * 2, hidden_channels], out_norm=True)

        self.mol_convs = torch.nn.ModuleList()
        self.prot_convs = torch.nn.ModuleList()
        self.mol_gn2 = torch.nn.ModuleList()
        self.prot_gn2 = torch.nn.ModuleList()
        self.inter_convs = torch.nn.ModuleList()

        self.num_cluster = K
        self.t = t
        self.cluster = torch.nn.ModuleList()

        self.mol_pools = torch.nn.ModuleList()
        self.mol_norms = torch.nn.ModuleList()
        self.prot_norms = torch.nn.ModuleList()

        self.atom_lins = torch.nn.ModuleList()
        self.residue_lins = torch.nn.ModuleList()

        self.c2a_mlps = torch.nn.ModuleList()
        self.c2r_mlps = torch.nn.ModuleList()

        self.total_layer = total_layer
        self.prot_edge_dim = hidden_channels

        for idx in range(total_layer):
            self.mol_convs.append(Drug_PNAConv(
                mol_deg, hidden_channels, edge_channels=hidden_channels,
                pre_layers=pre_layers, post_layers=post_layers,
                aggregators=aggregators, scalers=scalers,
                num_towers=heads, dropout=dropout
            ))

            self.prot_convs.append(Protein_PNAConv(
                prot_deg, hidden_channels, edge_channels=hidden_channels,
                pre_layers=pre_layers, post_layers=post_layers,
                aggregators=aggregators, scalers=scalers,
                num_towers=heads, dropout=dropout
            ))

            self.cluster.append(GCNCluster([hidden_channels, hidden_channels * 2, self.num_cluster[idx]], in_norm=True))
            self.inter_convs.append(DrugProteinConv(
                atom_channels=hidden_channels,
                residue_channels=hidden_channels,
                heads=heads, t=t,
                dropout_attn_score=dropout_attn_score
            ))

            self.mol_pools.append(MotifPool(hidden_channels, heads, dropout_attn_score, drop_atom))
            self.mol_norms.append(torch.nn.LayerNorm(hidden_channels))
            self.prot_norms.append(torch.nn.LayerNorm(hidden_channels))

            self.atom_lins.append(Linear(hidden_channels, hidden_channels, bias=False))
            self.residue_lins.append(Linear(hidden_channels, hidden_channels, bias=False))

            self.c2a_mlps.append(MLP([hidden_channels, hidden_channels * 2, hidden_channels], bias=False))
            self.c2r_mlps.append(MLP([hidden_channels, hidden_channels * 2, hidden_channels], bias=False))

            self.mol_gn2.append(GraphNorm(hidden_channels))
            self.prot_gn2.append(GraphNorm(hidden_channels))

        self.atom_attn_lin = PosLinear(heads * total_layer, 1, bias=False, init_value=1 / heads)
        self.residue_attn_lin = PosLinear(heads * total_layer, 1, bias=False, init_value=1 / heads)

        self.mol_out = MLP([hidden_channels, hidden_channels * 2, hidden_channels], out_norm=True)
        self.prot_out = MLP([hidden_channels, hidden_channels * 2, hidden_channels], out_norm=True)

        if self.regression_head:
            self.reg_out = MLP([hidden_channels * 2, hidden_channels, 1])
        if self.classification_head:
            self.cls_out = MLP([hidden_channels * 2, hidden_channels, 1])
        if self.multiclassification_head:
            self.mcls_out = MLP([hidden_channels * 2, hidden_channels, multiclassification_head])

        self.dropout = dropout
        self.drop_atom = drop_atom
        self.drop_residue = drop_residue
        self.gaussian_noise = gaussian_noise
        self.dropout_cluster_edge = dropout_cluster_edge
        self.device = device

    def forward(self,
                mol_x, mol_x_feat, bond_x, atom_edge_index,
                clique_x, clique_edge_index, atom2clique_index,
                residue_x, residue_evo_x, residue_edge_index, residue_edge_weight,
                mol_batch=None, prot_batch=None, clique_batch=None,
                save_cluster=False):
        reg_pred = None
        cls_pred = None
        mcls_pred = None
        residue_edge_attr = _rbf(residue_edge_weight, D_max=1.0, D_count=self.prot_edge_dim, device=self.device)
        mol_pool_feat = []
        prot_pool_feat = []

        # PROTEIN Featurize
        residue_x = self.prot_aa(residue_x) + self.prot_evo(residue_evo_x)

        # MOLECULE Featurize
        atom_x = self.atom_type_encoder(mol_x.squeeze()) + self.atom_feat_encoder(mol_x_feat)

        # Clique Featurize
        clique_x = self.clique_encoder(clique_x.squeeze())
        spectral_loss = torch.tensor(0.).to(self.device)
        ortho_loss = torch.tensor(0.).to(self.device)
        cluster_loss = torch.tensor(0.).to(self.device)

        clique_scores = []
        residue_scores = []
        layer_s = {}

        for idx in range(self.total_layer):
            atom_x = self.mol_convs[idx](atom_x, bond_x, atom_edge_index)
            residue_x = self.prot_convs[idx](residue_x, residue_edge_index, residue_edge_attr)

            drug_x, clique_x, clique_score = self.mol_pools[idx](atom_x, clique_x, atom2clique_index, clique_batch, clique_edge_index)
            drug_x = self.mol_norms[idx](drug_x)
            clique_scores.append(clique_score)

            dropped_residue_edge_index, _ = dropout_edge(residue_edge_index, p=self.dropout_cluster_edge,
                                                         force_undirected=True, training=self.training)
            s = self.cluster[idx](residue_x, dropped_residue_edge_index)
            residue_hx, residue_mask = to_dense_batch(residue_x, prot_batch)

            if save_cluster:
                layer_s[idx] = s

            s, _ = to_dense_batch(s, prot_batch)
            residue_adj = to_dense_adj(residue_edge_index, prot_batch)
            cluster_mask = residue_mask

            cluster_drop_mask = None
            if self.drop_residue != 0 and self.training:
                _, _, residue_drop_mask = dropout_node(residue_edge_index, self.drop_residue, residue_x.size(0), prot_batch,
                                                       self.training)
                residue_drop_mask, _ = to_dense_batch(residue_drop_mask.reshape(-1, 1), prot_batch)
                residue_drop_mask = residue_drop_mask.squeeze()
                cluster_drop_mask = residue_mask * residue_drop_mask.squeeze()

            s, cluster_x, residue_adj, cl_loss, o_loss = dense_mincut_pool(residue_hx, residue_adj, s, cluster_mask, cluster_drop_mask)

            ortho_loss += o_loss
            cluster_loss += cl_loss
            cluster_x = self.prot_norms[idx](cluster_x)

            batch_size = s.size(0)
            cluster_residue_batch = torch.arange(batch_size).repeat_interleave(self.num_cluster[idx]).to(self.device)
            cluster_x = cluster_x.reshape(batch_size * self.num_cluster[idx], -1)
            p2m_edge_index = torch.stack([torch.arange(batch_size * self.num_cluster[idx]),
                                          torch.arange(batch_size).repeat_interleave(self.num_cluster[idx])]
                                         ).to(self.device)

            clique_x, cluster_x, inter_attn = self.inter_convs[idx](drug_x, clique_x, clique_batch, cluster_x, p2m_edge_index)
            inter_attn = inter_attn[1]

            row, col = atom2clique_index
            atom_x = atom_x + F.relu(self.atom_lins[idx](scatter(clique_x[col], row, dim=0, dim_size=atom_x.size(0), reduce='mean')))
            atom_x = atom_x + self.c2a_mlps[idx](atom_x)
            atom_x = F.dropout(atom_x, self.dropout, training=self.training)

            residue_hx, _ = to_dense_batch(cluster_x, cluster_residue_batch)
            inter_attn, _ = to_dense_batch(inter_attn, cluster_residue_batch)
            residue_x = residue_x + F.relu(self.residue_lins[idx]((s @ residue_hx)[residue_mask]))
            residue_x = residue_x + self.c2r_mlps[idx](residue_x)

            residue_x = F.dropout(residue_x, self.dropout, training=self.training)
            inter_attn = (s @ inter_attn)[residue_mask]
            residue_scores.append(inter_attn)

            atom_x = self.mol_gn2[idx](atom_x, mol_batch)
            residue_x = self.prot_gn2[idx](residue_x, prot_batch)

        # Pool based on attn scores
        row, col = atom2clique_index
        clique_scores = torch.cat(clique_scores, dim=-1)
        atom_scores = scatter(clique_scores[col], row, dim=0, dim_size=atom_x.size(0), reduce='mean')
        atom_score = self.atom_attn_lin(atom_scores)
        atom_score = softmax(atom_score, mol_batch)
        mol_pool_feat = global_add_pool(atom_x * atom_score, mol_batch)

        residue_scores = torch.cat(residue_scores, dim=-1)
        residue_score = softmax(self.residue_attn_lin(residue_scores), prot_batch)
        prot_pool_feat = global_add_pool(residue_x * residue_score, prot_batch)

        mol_pool_feat = self.mol_out(mol_pool_feat)
        prot_pool_feat = self.prot_out(prot_pool_feat)

        mol_prot_feat = torch.cat([mol_pool_feat, prot_pool_feat], dim=-1)

        if self.regression_head:
            reg_pred = self.reg_out(mol_prot_feat)
        if self.classification_head:
            cls_pred = self.cls_out(mol_prot_feat)
        if self.multiclassification_head:
            mcls_pred = self.mcls_out(mol_prot_feat)

        attention_dict = {
            'residue_final_score': residue_score,
            'atom_final_score': atom_score,
            'clique_layer_scores': clique_scores,
            'residue_layer_scores': residue_scores,
            'drug_atom_index': mol_batch,
            'drug_clique_index': clique_batch,
            'protein_residue_index': prot_batch,
            'mol_feature': mol_pool_feat,
            'prot_feature': prot_pool_feat,
            'interaction_fingerprint': mol_prot_feat,
            'cluster_s': layer_s
        }

        return reg_pred, cls_pred, mcls_pred, spectral_loss, ortho_loss, cluster_loss, attention_dict


def _rbf(D, D_min=0., D_max=1., D_count=16, device='cpu'):
    D = torch.where(D < D_max, D, torch.tensor(D_max).float().to(device))
    D_mu = torch.linspace(D_min, D_max, D_count, device=device)
    D_mu = D_mu.view([1, -1])
    D_sigma = (D_max - D_min) / D_count
    D_expand = torch.unsqueeze(D, -1)
    RBF = torch.exp(-((D_expand - D_mu) / D_sigma) ** 2)
    return RBF
