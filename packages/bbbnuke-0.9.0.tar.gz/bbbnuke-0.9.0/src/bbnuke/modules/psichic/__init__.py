"""Vendored PSICHIC inference for efflux transporter screening.

Runs the PSICHIC GNN against 9 pre-featurized efflux transporter proteins
to predict whether a compound is an efflux substrate. Pre-computed protein
graphs (from ESM2) are bundled as efflux_protein_graphs.pt, eliminating the
need for ESM2 at runtime.

Public API:
    screen_efflux(smiles_list, compound_ids, device, batch_size)
        -> dict[str, list[AffinityScore]]
"""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
import torch

from bbnuke.core.schemas import AffinityScore

logger = logging.getLogger(__name__)

# HuggingFace repo for model weights + protein graphs
HF_REPO_ID = "temisobodu/psichic-multitask-bbb"
HF_WEIGHT_FILES = ["model.pt", "degree.pt", "config.json"]
HF_PROTEIN_GRAPH_FILE = "efflux_protein_graphs.pt"

# Cache for loaded model and protein graphs
_model_cache: Dict[str, object] = {}


def _data_dir() -> Path:
    """Return path to bundled data directory."""
    return Path(__file__).resolve().parent.parent.parent / "data"


def _efflux_proteins_path() -> Path:
    """Return path to bundled efflux_proteins.csv."""
    return _data_dir() / "efflux_proteins.csv"


def _ensure_weights() -> str:
    """Ensure PSICHIC weights are available, downloading from HF if needed.

    Returns the directory path containing model.pt, degree.pt, config.json.
    """
    from bbnuke.core.config import settings

    local_path = Path(settings.psichic_model_path).expanduser()

    if local_path.exists() and (local_path / "model.pt").exists():
        return str(local_path)

    try:
        from huggingface_hub import hf_hub_download

        logger.info("PSICHIC weights not found locally. Downloading from HuggingFace (%s)...", HF_REPO_ID)
        downloaded_dir = None

        for fname in HF_WEIGHT_FILES:
            fpath = hf_hub_download(repo_id=HF_REPO_ID, filename=fname)
            downloaded_dir = str(Path(fpath).parent)

        logger.info("PSICHIC weights downloaded to: %s", downloaded_dir)
        return downloaded_dir

    except ImportError:
        raise FileNotFoundError(
            f"PSICHIC weights not found at {local_path} and huggingface_hub not installed. "
            "Install with: pip install huggingface_hub"
        )
    except Exception as exc:
        raise FileNotFoundError(
            f"PSICHIC weights not found at {local_path} and HF download failed: {exc}"
        )


def _ensure_protein_graphs() -> str:
    """Ensure pre-computed protein graphs are available.

    Returns path to efflux_protein_graphs.pt file.
    """
    # Check bundled data directory first
    local_path = _data_dir() / "efflux_protein_graphs.pt"
    if local_path.exists():
        return str(local_path)

    # Try downloading from HuggingFace
    try:
        from huggingface_hub import hf_hub_download

        logger.info("Protein graphs not found locally. Downloading from HuggingFace...")
        fpath = hf_hub_download(repo_id=HF_REPO_ID, filename=HF_PROTEIN_GRAPH_FILE)
        logger.info("Protein graphs downloaded to: %s", fpath)
        return fpath

    except ImportError:
        raise FileNotFoundError(
            f"Protein graphs not found at {local_path} and huggingface_hub not installed"
        )
    except Exception as exc:
        raise FileNotFoundError(
            f"Protein graphs not found at {local_path} and HF download failed: {exc}"
        )


def _load_model(weights_dir: str, device: str = "cpu"):
    """Load the PSICHIC model with weights."""
    cache_key = f"{weights_dir}:{device}"
    if cache_key in _model_cache:
        return _model_cache[cache_key]

    from bbnuke.modules.psichic.net import net

    weights_path = Path(weights_dir)

    # Load config
    config_path = weights_path / "config.json"
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
    else:
        config = {}

    # Extract params from nested config (HF format has "params" sub-dict)
    params = config.get("params", config)
    tasks = config.get("tasks", config)

    # Load degree histograms
    degree_path = weights_path / "degree.pt"
    degree_data = torch.load(degree_path, map_location="cpu", weights_only=True)
    mol_deg = degree_data["ligand_deg"]
    prot_deg = degree_data["protein_deg"]

    # Build model
    model = net(
        mol_deg=mol_deg,
        prot_deg=prot_deg,
        mol_in_channels=params.get("mol_in_channels", 43),
        prot_in_channels=params.get("prot_in_channels", 33),
        prot_evo_channels=params.get("prot_evo_channels", 1280),
        hidden_channels=params.get("hidden_channels", 200),
        pre_layers=params.get("pre_layers", 2),
        post_layers=params.get("post_layers", 1),
        aggregators=params.get("aggregators", ['mean', 'min', 'max', 'std']),
        scalers=params.get("scalers", ['identity', 'amplification', 'linear']),
        total_layer=params.get("total_layer", 3),
        K=params.get("K", [5, 10, 20]),
        t=params.get("t", 1),
        heads=params.get("heads", 5),
        dropout=0,
        dropout_attn_score=0,
        drop_atom=0,
        drop_residue=0,
        dropout_cluster_edge=0,
        regression_head=tasks.get("regression_task", True),
        classification_head=tasks.get("classification_task", False),
        multiclassification_head=tasks.get("mclassification_task", 3),
        device=device,
    )

    # Load weights
    model_path = weights_path / "model.pt"
    state_dict = torch.load(model_path, map_location=device, weights_only=True)
    model.load_state_dict(state_dict)
    model = model.to(device)
    model.eval()

    _model_cache[cache_key] = model
    logger.info("PSICHIC model loaded from %s (device=%s)", weights_dir, device)
    return model


def screen_efflux(
    smiles_list: List[str],
    compound_ids: List[str],
    device: str = "cpu",
    batch_size: int = 16,
) -> Dict[str, List[AffinityScore]]:
    """Run PSICHIC GNN inference against 9 efflux transporter proteins.

    Args:
        smiles_list: List of standardized SMILES strings.
        compound_ids: List of compound identifiers (same length as smiles_list).
        device: Torch device string ('cpu' or 'cuda:0').
        batch_size: Batch size for DataLoader.

    Returns:
        Dict mapping compound_id to list of AffinityScore for each efflux protein.
    """
    if not smiles_list:
        return {}

    from torch_geometric.loader import DataLoader

    from bbnuke.modules.psichic.dataset import ProteinMoleculeDataset
    from bbnuke.modules.psichic.inference import virtual_screening
    from bbnuke.modules.psichic.ligand_init import ligand_init

    # 1. Load model weights
    weights_dir = _ensure_weights()
    model = _load_model(weights_dir, device)

    # 2. Load pre-computed protein graphs
    protein_graphs_path = _ensure_protein_graphs()
    protein_dict = torch.load(protein_graphs_path, map_location="cpu", weights_only=False)

    # 3. Load efflux protein sequences to build the mapping
    efflux_csv = _efflux_proteins_path()
    efflux_proteins = {}
    with open(efflux_csv) as f:
        reader = csv.DictReader(f)
        for row in reader:
            efflux_proteins[row["UniProt ID"]] = row["Sequence"]

    # Map protein IDs to their sequence keys in the protein_dict
    # protein_dict is keyed by sequence string
    # Multiple protein IDs may map to the same sequence (e.g. A4D1D2_HUMAN and MDR1_HUMAN)
    seq_to_ids: Dict[str, List[str]] = {}
    for pid, seq in efflux_proteins.items():
        if seq in protein_dict:
            seq_to_ids.setdefault(seq, []).append(pid)
        else:
            logger.warning("Protein %s sequence not found in pre-computed graphs", pid)

    available_sequences = list(seq_to_ids.keys())
    if not available_sequences:
        logger.error("No efflux protein graphs available")
        return {cid: [] for cid in compound_ids}

    # 4. Featurize ligands
    ligand_dict = ligand_init(smiles_list)

    # 5. Build screening DataFrame (all compound × protein pairs)
    # Use one row per unique sequence (not per protein ID)
    pairs = []
    for smiles, cid in zip(smiles_list, compound_ids):
        for seq in available_sequences:
            pairs.append({
                "Ligand": smiles,
                "Protein": seq,
                "compound_id": cid,
            })

    screen_df = pd.DataFrame(pairs)

    # 6. Build dataset and DataLoader
    dataset = ProteinMoleculeDataset(
        sequence_data=screen_df[["Ligand", "Protein"]].copy(),
        mol_obj=ligand_dict,
        prot_obj=protein_dict,
        device="cpu",
        cache_transform=True,
    )

    loader = DataLoader(
        dataset, batch_size=batch_size, shuffle=False,
        follow_batch=["mol_x", "prot_node_aa", "clique_x"],
    )

    # 7. Run inference
    result_df = virtual_screening(screen_df, model, loader, device=device)

    # 8. Parse results into AffinityScore objects
    # Expand sequences back to all protein IDs they map to
    results: Dict[str, List[AffinityScore]] = {cid: [] for cid in compound_ids}

    for _, row in result_df.iterrows():
        cid = row["compound_id"]
        seq = row["Protein"]
        score_raw = float(row.get("predicted_binding_affinity", 0) or 0)
        score_norm = score_raw / 10.0  # Normalize to [0, 1] range

        # Each sequence may map to multiple protein IDs
        for pid in seq_to_ids.get(seq, []):
            results[cid].append(AffinityScore(
                protein_id=pid,
                score_raw=score_raw,
                score_norm=score_norm,
            ))

    return results
