"""SMILES standardization using RDKit."""

from __future__ import annotations

from rdkit import Chem
from rdkit.Chem.MolStandardize import rdMolStandardize


def standardize_smiles(smiles: str) -> str:
    """Canonicalize, neutralize, and strip salts from a SMILES string.

    Returns the standardized SMILES or raises ValueError on failure.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"RDKit cannot parse SMILES: {smiles!r}")

    # Strip salts — keep largest fragment
    mol = rdMolStandardize.FragmentParent(mol)

    # Neutralize charges
    uncharger = rdMolStandardize.Uncharger()
    mol = uncharger.uncharge(mol)

    # Canonical SMILES round-trip
    canon = Chem.MolToSmiles(mol)
    mol = Chem.MolFromSmiles(canon)
    if mol is None:
        raise ValueError(f"Standardization round-trip failed for: {smiles!r}")

    return Chem.MolToSmiles(mol)
