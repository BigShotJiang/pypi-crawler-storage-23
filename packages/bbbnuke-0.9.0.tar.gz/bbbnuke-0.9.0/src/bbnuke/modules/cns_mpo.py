"""CNS Multi-Parameter Optimization (MPO) scoring.

Implements the 6-component desirability scoring from Wager et al. (2016).
Each property maps to a 0-1 desirability via monotonic/hump transforms;
the total CNS-MPO score is the sum (range 0-6).

References:
    Wager et al., ACS Chem. Neurosci. 2016, 7, 767-775
    (doi:10.1021/acschemneuro.6b00029)
"""

from __future__ import annotations

import math
from typing import List, Optional

from bbnuke.core.constants import MPO_FILTER_CUTOFF
from bbnuke.core.schemas import CnsMpoResult, CnsMpoSubscores, PkaSource, PropertyResult


# -- Desirability functions (piecewise linear, matching Wager et al.) --------

def _desirability_mw(mw: float) -> float:
    """MW desirability: 1.0 for <=360, linear decline to 0.0 at 500."""
    if mw <= 360:
        return 1.0
    if mw >= 500:
        return 0.0
    return 1.0 - (mw - 360) / (500 - 360)


def _desirability_logp(logp: float) -> float:
    """LogP desirability: 1.0 for <=3, else 0."""
    if logp <= 3.0:
        return 1.0
    return 0.0


def _desirability_tpsa(tpsa: float) -> float:
    """TPSA desirability: 1.0 for 40-90, linear ramps outside."""
    if 40 <= tpsa <= 90:
        return 1.0
    if tpsa < 20:
        return 0.0
    if tpsa < 40:
        return (tpsa - 20) / (40 - 20)
    if tpsa > 120:
        return 0.0
    # 90 < tpsa <= 120
    return 1.0 - (tpsa - 90) / (120 - 90)


def _desirability_hbd(hbd: int) -> float:
    """HBD desirability: 1.0 for <=1, else 0."""
    if hbd <= 1:
        return 1.0
    return 0.0


def _desirability_pka(pka: float) -> float:
    """pKa desirability: 1.0 for 8 <= pka < 12, else 0."""
    if 8.0 <= pka < 12.0:
        return 1.0
    return 0.0


def _desirability_clogd(clogd: float) -> float:
    """cLogD desirability: 1.0 for <=2, linear decline to 0.0 at 4."""
    if clogd <= 2.0:
        return 1.0
    if clogd >= 4.0:
        return 0.0
    return 1.0 - (clogd - 2.0) / (4.0 - 2.0)


# -- cLogD calculation -------------------------------------------------------

_PKA_MIN = -2.0   # Floor for plausible pKa
_PKA_MAX = 14.0   # Ceiling for plausible pKa (beyond water autoionization)


def compute_clogd(
    logp: float,
    acid_pkas: Optional[List[float]] = None,
    base_pkas: Optional[List[float]] = None,
    ph: float = 7.4,
) -> float:
    """Compute cLogD at a given pH from cLogP and pKa values.

    Uses the Henderson-Hasselbalch relationship:
      - For acids: LogD = LogP - log10(1 + 10^(pH - pKa))
      - For bases: LogD = LogP - log10(1 + 10^(pKa - pH))

    When a molecule has multiple ionizable groups, each independently
    reduces the effective lipophilicity:
      LogD = LogP - Σ log10(1 + 10^(pH - pKa_acid_i))
                   - Σ log10(1 + 10^(pKa_base_j - pH))

    pKa values outside [-2, 14] are discarded as prediction artifacts.

    Args:
        logp: Crippen LogP from RDKit.
        acid_pkas: Acidic pKa values (deprotonation equilibria).
        base_pkas: Basic pKa values (protonation equilibria).
        ph: pH for LogD calculation (default 7.4, physiological).

    Returns:
        Estimated cLogD at the given pH.
    """
    correction = 0.0

    if acid_pkas:
        for pka in acid_pkas:
            if _PKA_MIN <= pka <= _PKA_MAX:
                correction += math.log10(1.0 + 10.0 ** (ph - pka))

    if base_pkas:
        for pka in base_pkas:
            if _PKA_MIN <= pka <= _PKA_MAX:
                correction += math.log10(1.0 + 10.0 ** (pka - ph))

    return logp - correction


# -- Main scoring function ---------------------------------------------------

def compute_cns_mpo(
    props: PropertyResult,
    pka: float | None = None,
    clogd: float | None = None,
    acid_pkas: Optional[List[float]] = None,
    base_pkas: Optional[List[float]] = None,
) -> CnsMpoResult:
    """Compute CNS-MPO score from physicochemical properties.

    Args:
        props: RDKit property results (MW, LogP, TPSA, HBD, HBA).
        pka: Representative pKa for the pKa subscore. If None, uses placeholder.
        clogd: Explicit cLogD override. If None, computed from LogP + pKa values
               via Henderson-Hasselbalch. Falls back to cLogP if no pKa available.
        acid_pkas: Acidic pKa values (for cLogD calculation).
        base_pkas: Basic pKa values (for cLogD calculation).

    Returns:
        CnsMpoResult with total score (0-6) and per-property subscores.
    """
    pka_source = PkaSource.placeholder
    if pka is not None:
        pka_source = PkaSource.provided
    else:
        pka = 8.0  # neutral default when no pKa available

    if clogd is None:
        if acid_pkas or base_pkas:
            # Compute cLogD from Henderson-Hasselbalch
            clogd = compute_clogd(props.logp, acid_pkas=acid_pkas, base_pkas=base_pkas)
        else:
            # No ionization data — cLogD ≈ cLogP (neutral molecule assumption)
            clogd = props.logp

    sub = CnsMpoSubscores(
        mw=_desirability_mw(props.mw),
        logp=_desirability_logp(props.logp),
        tpsa=_desirability_tpsa(props.tpsa),
        hbd=_desirability_hbd(props.hbd),
        pka=_desirability_pka(pka),
        clogd=_desirability_clogd(clogd),
    )

    total = sub.mw + sub.logp + sub.tpsa + sub.hbd + sub.pka + sub.clogd

    return CnsMpoResult(
        score=round(total, 4),
        subscores=sub,
        pka_used=pka,
        clogd=round(clogd, 4),
        pka_source=pka_source,
        passed_filter=total >= MPO_FILTER_CUTOFF,
    )
