"""MolGpKa pKa prediction adapter.

Two modes of operation:
  1. **Read pre-computed CSV** — fastest; use when MolGpKa has already been run.
  2. **Run MolGpKa subprocess** — invokes predict_pka2.py against a CSV of compounds.

The representative pKa heuristic (v0.1):
  - If basic pKa(s) exist → select the **maximum basic pKa**
  - Else if acidic pKa(s) exist → select the **minimum acidic pKa**
  - Else → None (pipeline will use placeholder)

This reflects dominant ionization near physiological pH for CNS compounds.
"""

from __future__ import annotations

import logging
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


def select_representative_pka(
    acid_pkas_str: str,
    base_pkas_str: str,
) -> Optional[float]:
    """Select a single representative pKa from semicolon-separated acid/base strings.

    Args:
        acid_pkas_str: Semicolon-separated acidic pKa values (e.g., "4.123;6.789").
        base_pkas_str: Semicolon-separated basic pKa values (e.g., "5.667;6.785").

    Returns:
        Representative pKa float, or None if no predictions available.
    """
    base_vals = _parse_pka_string(base_pkas_str)
    if base_vals:
        return max(base_vals)

    acid_vals = _parse_pka_string(acid_pkas_str)
    if acid_vals:
        return min(acid_vals)

    return None


def _parse_pka_string(s: str) -> List[float]:
    """Parse a semicolon-separated pKa string into a list of floats."""
    if not isinstance(s, str):
        return []
    s = s.strip()
    if not s or s.lower() == "nan":
        return []
    vals = []
    for part in s.split(";"):
        part = part.strip()
        if part:
            try:
                vals.append(float(part))
            except ValueError:
                continue
    return vals


class PkaData:
    """All pKa data for a single compound."""
    __slots__ = ("acid_pkas", "base_pkas", "representative")

    def __init__(
        self,
        acid_pkas: List[float],
        base_pkas: List[float],
        representative: Optional[float],
    ):
        self.acid_pkas = acid_pkas
        self.base_pkas = base_pkas
        self.representative = representative


def read_pka_csv(
    pka_csv: str,
    id_col: str = "compound",
    acid_col: str = "acid_pkas",
    base_col: str = "base_pkas",
) -> Dict[str, float]:
    """Read a MolGpKa output CSV and return {compound_id: representative_pka}.

    Args:
        pka_csv: Path to CSV with pKa predictions (output of predict_pka2.py).
        id_col: Column name for compound IDs.
        acid_col: Column name for acidic pKa values.
        base_col: Column name for basic pKa values.

    Returns:
        Dict mapping compound_id to representative pKa. Compounds with no
        pKa predictions are omitted.
    """
    full = read_pka_csv_full(pka_csv, id_col=id_col, acid_col=acid_col, base_col=base_col)
    return {cid: d.representative for cid, d in full.items() if d.representative is not None}


def read_pka_csv_full(
    pka_csv: str,
    id_col: str = "compound",
    acid_col: str = "acid_pkas",
    base_col: str = "base_pkas",
) -> Dict[str, PkaData]:
    """Read a MolGpKa output CSV and return full pKa data per compound.

    Args:
        pka_csv: Path to CSV with pKa predictions (output of predict_pka2.py).
        id_col: Column name for compound IDs.
        acid_col: Column name for acidic pKa values.
        base_col: Column name for basic pKa values.

    Returns:
        Dict mapping compound_id to PkaData (acid_pkas, base_pkas, representative).
    """
    df = pd.read_csv(pka_csv)

    # Auto-detect columns if defaults don't match
    if id_col not in df.columns:
        for candidate in ["compound", "compound_id", "name", "Name", "compound_name", "ID"]:
            if candidate in df.columns:
                id_col = candidate
                break
        else:
            raise ValueError(f"Cannot find ID column in pKa CSV. Columns: {list(df.columns)}")

    if acid_col not in df.columns:
        acid_col = _find_col(df.columns, ["acid_pkas", "acidic_pka", "acid_pKa"])
    if base_col not in df.columns:
        base_col = _find_col(df.columns, ["base_pkas", "basic_pka", "base_pKa"])

    pka_map: Dict[str, PkaData] = {}
    for _, row in df.iterrows():
        cid = str(row[id_col])
        acid_str = str(row.get(acid_col, "")) if acid_col else ""
        base_str = str(row.get(base_col, "")) if base_col else ""

        acid_vals = _parse_pka_string(acid_str)
        base_vals = _parse_pka_string(base_str)
        rep = select_representative_pka(acid_str, base_str)

        pka_map[cid] = PkaData(acid_pkas=acid_vals, base_pkas=base_vals, representative=rep)

    return pka_map


def run_molgpka(
    input_csv: str,
    output_csv: str,
    molgpka_src_dir: str,
    smiles_col: str = "smiles",
    name_col: str = "compound",
    python_exe: Optional[str] = None,
) -> Dict[str, float]:
    """Run MolGpKa predict_pka2.py as a subprocess and return pKa map.

    Args:
        input_csv: Path to input CSV with compound IDs and SMILES.
        molgpka_src_dir: Path to MolGpKa src/ directory (where predict_pka2.py lives).
        output_csv: Path to write pKa results CSV.
        smiles_col: SMILES column name in input CSV.
        name_col: Compound name column in input CSV.
        python_exe: Python executable to use. Defaults to current interpreter.

    Returns:
        Dict mapping compound_id to representative pKa.

    Raises:
        RuntimeError: If MolGpKa subprocess fails.
    """
    python_exe = python_exe or sys.executable
    src_dir = Path(molgpka_src_dir).expanduser().resolve()
    script = src_dir / "predict_pka2.py"

    if not script.exists():
        raise FileNotFoundError(f"MolGpKa script not found: {script}")

    cmd = [
        python_exe, str(script),
        "--input", str(input_csv),
        "--output", str(output_csv),
        "--smiles-col", smiles_col,
        "--name-col", name_col,
    ]

    print(f"[MolGpKa] Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=str(src_dir), capture_output=True, text=True)

    if result.returncode != 0:
        raise RuntimeError(
            f"MolGpKa failed (exit {result.returncode}):\n{result.stderr}"
        )

    if result.stdout:
        print(result.stdout)

    return read_pka_csv(output_csv, id_col=name_col)


def predict_single_pka(
    smiles: str,
    molgpka_src_dir: Optional[str] = None,
    python_exe: Optional[str] = None,
) -> PkaData:
    """Predict pKa for a single SMILES using MolGpKa subprocess.

    Creates a temporary single-row CSV, runs predict_pka2.py, parses output.
    Falls back to empty PkaData (placeholder) if MolGpKa is unavailable or fails.

    Args:
        smiles: Standardized SMILES string.
        molgpka_src_dir: Path to MolGpKa src/ directory. None = use config default.
        python_exe: Python executable with torch installed. None = use config default.

    Returns:
        PkaData with acid_pkas, base_pkas, and representative pKa.
    """
    from bbnuke.core.config import settings

    molgpka_src_dir = molgpka_src_dir or settings.molgpka_dir
    python_exe = python_exe or settings.molgpka_python

    # Validate MolGpKa is available
    if not molgpka_src_dir:
        logger.warning("MolGpKa directory not configured (BBNUKE_MOLGPKA_DIR)")
        return PkaData(acid_pkas=[], base_pkas=[], representative=None)

    script = Path(molgpka_src_dir).expanduser().resolve() / "predict_pka2.py"
    if not script.exists():
        logger.warning("MolGpKa script not found: %s", script)
        return PkaData(acid_pkas=[], base_pkas=[], representative=None)

    python_path = Path(python_exe).expanduser().resolve()
    if not python_path.exists():
        logger.warning("MolGpKa Python not found: %s", python_path)
        return PkaData(acid_pkas=[], base_pkas=[], representative=None)

    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            input_csv = Path(tmpdir) / "input.csv"
            output_csv = Path(tmpdir) / "output.csv"

            # Write single-row input CSV
            pd.DataFrame([{
                "compound": "query",
                "smiles": smiles,
            }]).to_csv(str(input_csv), index=False)

            cmd = [
                str(python_path),
                str(script),
                "--input", str(input_csv),
                "--output", str(output_csv),
                "--smiles-col", "smiles",
                "--name-col", "compound",
            ]

            logger.info("[MolGpKa] Predicting pKa for: %s", smiles[:80])
            result = subprocess.run(
                cmd,
                cwd=str(script.parent),
                capture_output=True,
                text=True,
                timeout=120,  # 2-minute timeout per molecule
            )

            if result.returncode != 0:
                logger.warning(
                    "MolGpKa failed (exit %d): %s",
                    result.returncode,
                    result.stderr[:500],
                )
                return PkaData(acid_pkas=[], base_pkas=[], representative=None)

            if not output_csv.exists():
                logger.warning("MolGpKa produced no output file")
                return PkaData(acid_pkas=[], base_pkas=[], representative=None)

            # Parse the single-row output
            full = read_pka_csv_full(str(output_csv))
            if "query" in full:
                return full["query"]

            # If compound name didn't match, take the first row
            if full:
                return next(iter(full.values()))

            return PkaData(acid_pkas=[], base_pkas=[], representative=None)

    except subprocess.TimeoutExpired:
        logger.warning("MolGpKa timed out for: %s", smiles[:80])
        return PkaData(acid_pkas=[], base_pkas=[], representative=None)
    except Exception as exc:
        logger.warning("MolGpKa error: %s", exc)
        return PkaData(acid_pkas=[], base_pkas=[], representative=None)


def _find_col(columns, candidates: List[str]) -> Optional[str]:
    """Find the first matching column name from candidates."""
    for c in candidates:
        if c in columns:
            return c
    return None
