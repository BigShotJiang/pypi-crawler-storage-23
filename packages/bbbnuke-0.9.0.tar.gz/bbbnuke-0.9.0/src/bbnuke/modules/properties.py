"""RDKit physicochemical property computation."""

from __future__ import annotations

from rdkit import Chem
from rdkit.Chem import Crippen, Descriptors, rdMolDescriptors

from bbnuke.core.schemas import PropertyResult


def compute_properties(smiles: str) -> PropertyResult:
    """Compute physicochemical descriptors from a (standardized) SMILES.

    Returns a PropertyResult with MW, LogP, TPSA, HBD, HBA.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Cannot compute properties — invalid SMILES: {smiles!r}")

    return PropertyResult(
        mw=Descriptors.MolWt(mol),
        logp=Crippen.MolLogP(mol),
        tpsa=rdMolDescriptors.CalcTPSA(mol),
        hbd=Descriptors.NumHDonors(mol),
        hba=Descriptors.NumHAcceptors(mol),
        rotatable_bonds=rdMolDescriptors.CalcNumRotatableBonds(mol),
        num_rings=rdMolDescriptors.CalcNumRings(mol),
        aromatic_rings=rdMolDescriptors.CalcNumAromaticRings(mol),
        heavy_atoms=mol.GetNumHeavyAtoms(),
        fsp3=rdMolDescriptors.CalcFractionCSP3(mol),
    )
