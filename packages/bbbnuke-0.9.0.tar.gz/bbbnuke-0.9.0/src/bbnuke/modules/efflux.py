"""Efflux transporter screening via vendored PSICHIC inference.

Runs the vendored PSICHIC GNN against 9 BBB efflux transporter proteins to
check whether a compound is an efflux substrate. If binding exceeds the
per-protein threshold, the pipeline vetoes the compound (P_BBB = 0).

Efflux proteins screened:
  ABCB1 (A4D1D2_HUMAN), ABCG2 (BCRP), MDR1 (P-gp), MRP1-5, MATE1, OAT3

Weight resolution order:
  1. Local path from BBNUKE_PSICHIC_MODEL env var / config
  2. Auto-download from HuggingFace Hub (temisobodu/psichic-multitask-bbb)

Graceful degradation: if PSICHIC dependencies (torch, torch_geometric) are
not installed, logs a warning and returns an empty list — the classifier
still scores without the efflux veto.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Tuple

from bbnuke.core.schemas import AffinityScore

logger = logging.getLogger(__name__)


def _psichic_available() -> bool:
    """Check whether vendored PSICHIC dependencies are available."""
    try:
        import torch
        import torch_geometric
        return True
    except ImportError:
        logger.warning(
            "torch/torch_geometric not installed — efflux screening disabled. "
            "Install with: pip install torch torch_geometric torch_scatter torch_sparse"
        )
        return False


def run_efflux_screen(
    smiles: str,
    compound_id: str = "query",
) -> List[AffinityScore]:
    """Run PSICHIC inference against 9 efflux proteins for a single compound.

    Args:
        smiles: Standardized SMILES string.
        compound_id: Compound identifier.

    Returns:
        List of AffinityScore for each efflux protein. Empty if PSICHIC
        dependencies are not available.
    """
    if not _psichic_available():
        return []

    from bbnuke.core.config import settings

    try:
        from bbnuke.modules.psichic import screen_efflux

        result = screen_efflux(
            smiles_list=[smiles],
            compound_ids=[compound_id],
            device=settings.psichic_device,
            batch_size=settings.psichic_batch_size,
        )
        return result.get(compound_id, [])

    except Exception as exc:
        logger.error("PSICHIC efflux screening failed: %s", exc)
        return []


def run_efflux_screen_batch(
    compounds: List[Tuple[str, str]],
) -> Dict[str, List[AffinityScore]]:
    """Run PSICHIC efflux screening for multiple compounds in one batch.

    Args:
        compounds: List of (compound_id, standardized_smiles) tuples.

    Returns:
        Dict mapping compound_id to list of AffinityScore. Missing compounds
        get empty lists. Returns empty dict if PSICHIC is not available.
    """
    if not compounds:
        return {}
    if not _psichic_available():
        return {cid: [] for cid, _ in compounds}

    from bbnuke.core.config import settings

    try:
        from bbnuke.modules.psichic import screen_efflux

        compound_ids = [cid for cid, _ in compounds]
        smiles_list = [smi for _, smi in compounds]

        result = screen_efflux(
            smiles_list=smiles_list,
            compound_ids=compound_ids,
            device=settings.psichic_device,
            batch_size=settings.psichic_batch_size,
        )

        # Ensure all compound IDs are present in result
        for cid in compound_ids:
            if cid not in result:
                result[cid] = []

        return result

    except Exception as exc:
        logger.error("PSICHIC batch efflux screening failed: %s", exc)
        return {cid: [] for cid, _ in compounds}
