"""Heuristic confidence layer for BBB penetration probability.

Two scoring modes:
  1. **Classifier** (default): GradientBoosting model trained on B3DB (7807
     compounds, 10 RDKit descriptors, 5×10 CV F1=0.903). The model outputs
     P_BBB directly via predict_proba. An efflux veto from PSICHIC data
     can still override the score to 0.
  2. **Legacy formula**: Combines PSICHIC binding scores with CNS-MPO via a
     logistic mapping. Kept for backward compatibility.

Protein weights, categories, and per-protein binding thresholds loaded from
BBB_proteins_merged.csv.
"""

from __future__ import annotations

import functools
import logging
import math
from pathlib import Path
from typing import Optional

import joblib
import numpy as np
import pandas as pd

from bbnuke.core.constants import (
    EFFLUX_VETO_THRESHOLD,
    LOGISTIC_K,
    MPO_FILTER_CUTOFF,
    MPO_GAIN_COEFF,
    PROTEIN_ALIASES,
)
from bbnuke.core.schemas import (
    AffinityScore,
    HeuristicDiagnostics,
    HeuristicResult,
    PropertyResult,
    ProteinCategory,
    ProteinContribution,
)

logger = logging.getLogger(__name__)

# Feature order expected by the trained classifier
_CLASSIFIER_FEATURES = [
    "mw", "logp", "tpsa", "hbd", "hba",
    "rot", "rings", "aromatic_rings", "heavy_atoms", "fsp3",
]


def canonicalize_protein(name: str) -> str:
    """Resolve a protein name to its canonical form via the alias table."""
    s = name.upper().strip()
    s = s.replace("\u2014", "-").replace("\u2013", "-")
    s = s.replace("(", " ").replace(")", " ")
    s = " ".join(s.split())
    # Strip UniProt _HUMAN / _MOUSE / etc. suffix
    if "_" in s:
        prefix = s.rsplit("_", 1)[0]
        suffix = s.rsplit("_", 1)[1]
        if suffix in ("HUMAN", "MOUSE", "RAT", "BOVIN"):
            s = prefix
    for canon, variants in PROTEIN_ALIASES.items():
        if s in variants:
            return canon
    return s


@functools.cache
def _load_proteins_table(path: str) -> tuple[
    dict[str, float],       # weights
    dict[str, str],         # categories
    dict[str, float],       # per-protein binding thresholds
    frozenset[str],         # efflux set
]:
    """Load and cache the protein table.

    Returns (weights, categories, thresholds, efflux_set).
    """
    if path.endswith(".csv"):
        df = pd.read_csv(path)
    else:
        df = pd.read_excel(path)
    df.columns = [c.strip() for c in df.columns]

    # Determine protein name column
    if "Common Name" in df.columns:
        protein_col = "Common Name"
    elif "Protein" in df.columns:
        protein_col = "Protein"
    else:
        raise ValueError(f"Cannot find protein column. Available: {list(df.columns)}")

    # Also build alias mapping from UniProt Name if present
    uniprot_col = "UniProt Name" if "UniProt Name" in df.columns else None
    threshold_col = "Binding Threshold" if "Binding Threshold" in df.columns else None
    type_col = "Type" if "Type" in df.columns else "Category"

    df[protein_col] = df[protein_col].astype(str).str.strip()
    df[type_col] = df[type_col].astype(str).str.strip().str.lower()
    df["Weight"] = pd.to_numeric(df["Weight"], errors="coerce")
    df = df.dropna(subset=[protein_col, "Weight", type_col])

    weights: dict[str, float] = {}
    categories: dict[str, str] = {}
    thresholds: dict[str, float] = {}

    for _, row in df.iterrows():
        common = str(row[protein_col]).strip().upper()

        # Register UniProt alias if present
        if uniprot_col and pd.notna(row.get(uniprot_col)):
            uniprot = str(row[uniprot_col]).strip().upper()
            # Strip _HUMAN suffix for alias
            uniprot_bare = uniprot.rsplit("_", 1)[0] if "_" in uniprot else uniprot
            # Add to PROTEIN_ALIASES dynamically if not already there
            if common not in PROTEIN_ALIASES:
                PROTEIN_ALIASES[common] = {common, uniprot_bare}
            else:
                PROTEIN_ALIASES[common].add(uniprot_bare)

        weights[common] = float(row["Weight"])
        categories[common] = row[type_col]

        if threshold_col and pd.notna(row.get(threshold_col)):
            thresholds[common] = float(row[threshold_col])

    efflux = frozenset(p for p, cat in categories.items() if "efflux" in cat)
    return weights, categories, thresholds, efflux


def _default_weights_path() -> str:
    """Return path to the bundled protein table."""
    pkg_data = Path(__file__).resolve().parent.parent / "data"
    # Prefer new merged CSV
    csv_path = pkg_data / "BBB_proteins_merged.csv"
    if csv_path.exists():
        return str(csv_path)
    # Fallback to old Excel
    xlsx_path = pkg_data / "BBB_protein_core_table.xlsx"
    if xlsx_path.exists():
        return str(xlsx_path)
    raise FileNotFoundError(
        "Cannot find protein table. "
        "Pass weights_path explicitly or ensure the data/ directory is present."
    )


@functools.cache
def _load_classifier() -> tuple:
    """Load the trained BBB classifier and scaler from bundled data."""
    pkg_data = Path(__file__).resolve().parent.parent / "data"
    model_path = pkg_data / "bbb_classifier.joblib"
    scaler_path = pkg_data / "bbb_scaler.joblib"

    if not model_path.exists() or not scaler_path.exists():
        return None, None

    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    return model, scaler


def _properties_to_features(props: PropertyResult) -> np.ndarray:
    """Extract the 10 features expected by the classifier from PropertyResult."""
    return np.array([[
        props.mw,
        props.logp,
        props.tpsa,
        float(props.hbd),
        float(props.hba),
        float(props.rotatable_bonds),
        float(props.num_rings),
        float(props.aromatic_rings),
        float(props.heavy_atoms),
        props.fsp3,
    ]])


def compute_classifier_heuristic(
    properties: PropertyResult,
    affinity_scores: Optional[list[AffinityScore]] = None,
    weights_path: Optional[str] = None,
    threshold: float = EFFLUX_VETO_THRESHOLD,
) -> HeuristicResult:
    """Compute P_BBB using the trained GradientBoosting classifier.

    The classifier uses 10 RDKit descriptors to predict BBB+/- probability.
    If PSICHIC affinity data is provided, efflux veto logic still applies.

    Args:
        properties: RDKit physicochemical descriptors.
        affinity_scores: Optional protein-ligand affinity scores for efflux veto.
        weights_path: Path to protein table for efflux veto.
        threshold: Default efflux veto threshold.

    Returns:
        HeuristicResult with probability and diagnostics.
    """
    model, scaler = _load_classifier()
    if model is None:
        logger.warning("Classifier not found, falling back to legacy heuristic")
        # Can't run classifier — return a no-score result
        return HeuristicResult(
            p_bbb=0.5,
            diagnostics=HeuristicDiagnostics(
                reason="Classifier model not found — default 0.5",
                k=0.0, c_mpo=0.0, threshold=threshold,
            ),
        )

    # Check efflux veto if affinity data provided
    if affinity_scores:
        if weights_path is None:
            weights_path = _default_weights_path()
        _, categories, thresholds, efflux = _load_proteins_table(weights_path)

        contributions: list[ProteinContribution] = []
        for aff in affinity_scores:
            canon = canonicalize_protein(aff.protein_id)
            p = aff.score_norm
            protein_threshold = thresholds.get(canon, threshold)

            if p >= protein_threshold and canon in efflux:
                return HeuristicResult(
                    p_bbb=0.0,
                    diagnostics=HeuristicDiagnostics(
                        reason="Efflux veto triggered",
                        veto=True,
                        veto_protein=canon,
                        veto_prob=p,
                        contributions=contributions,
                        k=0.0, c_mpo=0.0, threshold=threshold,
                    ),
                )

            w = 0.0  # weights not used in classifier mode
            cat_str = categories.get(canon, "carrier")
            try:
                cat = ProteinCategory(cat_str)
            except ValueError:
                cat = ProteinCategory.carrier

            contributions.append(ProteinContribution(
                protein_id=aff.protein_id,
                canonical_id=canon,
                binding_prob=p,
                weight=w,
                category=cat,
                weighted_contribution=0.0,
            ))

    # Run classifier
    X = _properties_to_features(properties)
    X_scaled = scaler.transform(X)
    p_bbb = float(model.predict_proba(X_scaled)[0, 1])

    return HeuristicResult(
        p_bbb=round(p_bbb, 6),
        diagnostics=HeuristicDiagnostics(
            reason="classifier",
            score_total=round(p_bbb, 6),
            k=0.0,
            c_mpo=0.0,
            threshold=threshold,
        ),
    )


def compute_heuristic(
    mpo_score: float,
    affinity_scores: list[AffinityScore] | None = None,
    weights_path: str | None = None,
    k: float = LOGISTIC_K,
    threshold: float = EFFLUX_VETO_THRESHOLD,
    c_mpo: float = MPO_GAIN_COEFF,
) -> HeuristicResult:
    """Compute the BBB penetration probability heuristic.

    Args:
        mpo_score: CNS-MPO score (0-6).
        affinity_scores: Protein-ligand affinity scores (normalized 0-1).
        weights_path: Path to protein table (CSV or Excel). Uses bundled default if None.
        k: Logistic slope parameter.
        threshold: Default efflux veto threshold (used when no per-protein override).
        c_mpo: MPO gain coefficient.

    Returns:
        HeuristicResult with probability and full diagnostics.
    """
    if weights_path is None:
        weights_path = _default_weights_path()

    weights, categories, thresholds, efflux = _load_proteins_table(weights_path)

    _hparams = dict(k=k, c_mpo=c_mpo, threshold=threshold)

    # MPO filter gate
    if mpo_score < MPO_FILTER_CUTOFF:
        return HeuristicResult(
            p_bbb=0.0,
            diagnostics=HeuristicDiagnostics(
                reason=f"CNS-MPO {mpo_score:.2f} < {MPO_FILTER_CUTOFF} cutoff",
                **_hparams,
            ),
        )

    if not affinity_scores:
        # No affinity data — score based on MPO alone
        score_mpo = c_mpo * (mpo_score - MPO_FILTER_CUTOFF)
        p = 1.0 / (1.0 + math.exp(-k * score_mpo))
        return HeuristicResult(
            p_bbb=round(p, 6),
            diagnostics=HeuristicDiagnostics(
                reason="MPO-only (no affinity scores)",
                score_mpo=round(score_mpo, 6),
                score_total=round(score_mpo, 6),
                **_hparams,
            ),
        )

    # Check efflux veto and accumulate contributions
    contributions: list[ProteinContribution] = []

    for aff in affinity_scores:
        canon = canonicalize_protein(aff.protein_id)
        p = aff.score_norm

        # Per-protein threshold (from table or default)
        protein_threshold = thresholds.get(canon, threshold)

        # Efflux veto check
        if p >= protein_threshold and canon in efflux:
            return HeuristicResult(
                p_bbb=0.0,
                diagnostics=HeuristicDiagnostics(
                    reason="Efflux veto triggered",
                    veto=True,
                    veto_protein=canon,
                    veto_prob=p,
                    contributions=contributions,
                    **_hparams,
                ),
            )

        w = weights.get(canon, 0.0)
        cat_str = categories.get(canon, "carrier")
        try:
            cat = ProteinCategory(cat_str)
        except ValueError:
            cat = ProteinCategory.carrier

        # Only count contribution if binding >= per-protein threshold
        if p >= protein_threshold:
            wc = w * p
        else:
            wc = 0.0

        contributions.append(ProteinContribution(
            protein_id=aff.protein_id,
            canonical_id=canon,
            binding_prob=p,
            weight=w,
            category=cat,
            weighted_contribution=round(wc, 6),
        ))

    score_bind = sum(c.weighted_contribution for c in contributions)
    score_mpo = c_mpo * (mpo_score - MPO_FILTER_CUTOFF)
    score_total = score_bind + score_mpo

    p_bbb = 1.0 / (1.0 + math.exp(-k * score_total))

    return HeuristicResult(
        p_bbb=round(p_bbb, 6),
        diagnostics=HeuristicDiagnostics(
            reason="OK",
            score_bind=round(score_bind, 6),
            score_mpo=round(score_mpo, 6),
            score_total=round(score_total, 6),
            contributions=contributions,
            **_hparams,
        ),
    )
