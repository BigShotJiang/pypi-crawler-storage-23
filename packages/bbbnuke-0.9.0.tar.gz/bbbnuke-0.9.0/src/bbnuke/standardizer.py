"""
This module standardizes the molecular structures, the intention of this module is to
provide a consistent representation of molecules for downstream tasks and also provide a flexible API
for users to implement their own standardization methods.
"""
from bbnuke.base import StandardizerABC

class Standardizer(StandardizerABC):
    def __init__(self, smiles: str | list[str]) -> None:
        super().__init__(smiles)
        # Additional initialization if needed

    def standardize(self) -> str | list[str]:
        """Implement the standardization logic here."""
        if isinstance(self.smiles, str):
            # Standardize a single molecule
            pass
        elif isinstance(self.smiles, list):
            # Standardize a list of molecules
            pass
        else:
            raise ValueError("Invalid input type. Expected string or list of strings.")
