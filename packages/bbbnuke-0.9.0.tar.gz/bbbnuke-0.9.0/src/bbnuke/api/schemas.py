"""API request/response schemas.

These wrap the existing pipeline Pydantic models from core/schemas.py.
The pipeline models ARE the contract — these add API-layer metadata.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from bbnuke.core.schemas import (
    PipelineConfig,
    PipelineResult,
    ProteinCategory,
)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class JobStatus(str, Enum):
    pending = "pending"
    running = "running"
    partial = "partial"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"


# ---------------------------------------------------------------------------
# Score endpoint
# ---------------------------------------------------------------------------

class ScoreRequest(BaseModel):
    """POST /v1/score — single compound scoring."""

    smiles: str = Field(min_length=1, description="SMILES string")
    compound_id: str = Field(default="query", description="Compound identifier")
    include_affinity: bool = Field(
        default=False,
        description="If True, include pre-computed PSICHIC affinity scores "
                    "(599 BBB+ compounds). If False, CPU-only scoring.",
    )
    config: Optional[PipelineConfig] = Field(
        default=None,
        description="Override default pipeline parameters",
    )


class ScoreResponse(BaseModel):
    """Response for POST /v1/score (synchronous)."""

    result: PipelineResult
    pipeline_version: str
    config: PipelineConfig


# ---------------------------------------------------------------------------
# Batch endpoint (stubs for Sprint 2)
# ---------------------------------------------------------------------------

class CompoundInputAPI(BaseModel):
    """Single compound in a batch request."""

    smiles: str = Field(min_length=1)
    compound_id: str = Field(min_length=1)


class BatchRequest(BaseModel):
    """POST /v1/batch — batch submission."""

    compounds: List[CompoundInputAPI] = Field(max_length=10000)
    run_pka: bool = True
    run_affinity: bool = True
    config: Optional[PipelineConfig] = None
    callback_url: Optional[str] = None


class BatchStatusResponse(BaseModel):
    """GET /v1/batch/{job_id} — job status."""

    job_id: str
    status: JobStatus
    total_compounds: int
    completed_compounds: int
    current_stage: str = ""
    pct: float = 0.0


# ---------------------------------------------------------------------------
# Proteins endpoint
# ---------------------------------------------------------------------------

class ProteinInfo(BaseModel):
    """A BBB protein from the protein table."""

    common_name: str
    uniprot_name: Optional[str] = None
    full_name: Optional[str] = None
    category: ProteinCategory
    weight: float
    binding_threshold: float


class ProteinsResponse(BaseModel):
    """GET /v1/proteins — all 66 BBB proteins."""

    proteins: List[ProteinInfo]
    count: int


# ---------------------------------------------------------------------------
# Health / Version
# ---------------------------------------------------------------------------

class HealthResponse(BaseModel):
    status: str = "ok"


class VersionResponse(BaseModel):
    pipeline_version: str
    api_version: str = "1.0.0"
    hyperparameters: Dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Error
# ---------------------------------------------------------------------------

class ErrorResponse(BaseModel):
    detail: str
    error_code: Optional[str] = None
