"""Audit logging — immutable trail for security-sensitive actions."""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from bbnuke.db.models import AuditLog

logger = logging.getLogger(__name__)


async def log_audit(
    db: AsyncSession,
    action: str,
    resource_type: str,
    resource_id: Optional[str] = None,
    org_id: Optional[str] = None,
    user_id: Optional[str] = None,
    detail: Optional[Dict[str, Any]] = None,
    ip_address: Optional[str] = None,
) -> None:
    """Write an immutable audit log entry.

    Actions: key_created, key_revoked, org_created, workspace_created,
             project_created, job_submitted, workflow_created, etc.
    """
    entry = AuditLog(
        org_id=org_id,
        user_id=user_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        detail_json=detail,
        ip_address=ip_address,
    )
    db.add(entry)
    await db.flush()
    logger.info("Audit: %s %s/%s (org=%s)", action, resource_type, resource_id, org_id)
