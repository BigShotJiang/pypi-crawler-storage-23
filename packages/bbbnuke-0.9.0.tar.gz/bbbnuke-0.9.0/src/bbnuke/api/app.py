"""FastAPI application factory for BBB-Nuke API."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from bbnuke import __version__
from bbnuke.core.config import settings
from bbnuke.api.middleware import ApiKeyMiddleware, RateLimitMiddleware, RequestIdMiddleware
from bbnuke.api.routes import batch, health, keys, projects, proteins, score, screen

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize DB tables on startup, cleanup on shutdown."""
    from bbnuke.db.session import init_db
    await init_db()
    logger.info("Database tables initialized")
    yield
    # Cleanup: close Redis pool if it was opened
    from bbnuke.api.deps import _redis_pool
    if _redis_pool is not None:
        await _redis_pool.close()


def create_app() -> FastAPI:
    """Build and return the FastAPI application."""

    app = FastAPI(
        title="BBB-Nuke",
        description="Blood-brain barrier penetration screening API",
        version=__version__,
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # -- Middleware (order matters: outermost first) -------------------------
    app.add_middleware(RequestIdMiddleware)
    app.add_middleware(RateLimitMiddleware, default_rpm=settings.rate_limit_rpm)
    app.add_middleware(ApiKeyMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # -- Routes --------------------------------------------------------------
    app.include_router(health.router, prefix="/v1", tags=["health"])
    app.include_router(score.router, prefix="/v1", tags=["scoring"])
    app.include_router(batch.router, prefix="/v1", tags=["batch"])
    app.include_router(screen.router, prefix="/v1", tags=["screen"])
    app.include_router(proteins.router, prefix="/v1", tags=["proteins"])
    app.include_router(keys.router, prefix="/v1/admin", tags=["admin"])
    app.include_router(projects.router, prefix="/v1", tags=["projects"])

    return app


# Module-level app for `uvicorn bbnuke.api.app:app`
app = create_app()
