"""FastAPI dependency injection — DB session, Redis, auth."""

from __future__ import annotations

import json
import logging
from typing import AsyncGenerator, Optional

from fastapi import Depends, HTTPException, Request

from bbnuke.core.config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Database session
# ---------------------------------------------------------------------------

async def get_db():
    """Yield an async SQLAlchemy session."""
    from bbnuke.db.session import async_session_factory

    async with async_session_factory() as session:
        yield session


# ---------------------------------------------------------------------------
# Redis
# ---------------------------------------------------------------------------

_redis_pool = None


async def get_redis():
    """Return a shared Redis connection (lazy-initialized)."""
    global _redis_pool
    if _redis_pool is None:
        from redis.asyncio import Redis
        _redis_pool = Redis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


async def get_arq_redis():
    """Return an ARQ Redis connection for enqueuing jobs."""
    from arq import create_pool
    from arq.connections import RedisSettings

    url = settings.redis_url
    parts = url.replace("redis://", "").split("/")
    host_port = parts[0].split(":")
    host = host_port[0] or "localhost"
    port = int(host_port[1]) if len(host_port) > 1 else 6379
    db = int(parts[1]) if len(parts) > 1 and parts[1] else 0

    pool = await create_pool(RedisSettings(host=host, port=port, database=db))
    return pool
