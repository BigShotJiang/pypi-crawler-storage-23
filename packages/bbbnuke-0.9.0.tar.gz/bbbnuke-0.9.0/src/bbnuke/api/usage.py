"""Usage metering — records billable events for compound scoring."""

from __future__ import annotations

import logging
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from bbnuke.db.models import UsageEvent

logger = logging.getLogger(__name__)


async def record_usage(
    db: AsyncSession,
    event_type: str,
    quantity: int = 1,
    org_id: Optional[str] = None,
    job_id: Optional[str] = None,
) -> None:
    """Record a metered usage event.

    Event types:
        compound_scored — one compound through CPU pipeline
        affinity_pair   — one compound × protein affinity call
        gpu_second      — one second of GPU compute
    """
    event = UsageEvent(
        org_id=org_id,
        event_type=event_type,
        quantity=quantity,
        job_id=job_id,
    )
    db.add(event)
    await db.flush()
    logger.debug("Usage: %s ×%d (org=%s, job=%s)", event_type, quantity, org_id, job_id)


async def record_compound_scored(
    db: AsyncSession,
    count: int = 1,
    org_id: Optional[str] = None,
    job_id: Optional[str] = None,
) -> None:
    """Shorthand for recording compound_scored events."""
    await record_usage(db, "compound_scored", count, org_id, job_id)
