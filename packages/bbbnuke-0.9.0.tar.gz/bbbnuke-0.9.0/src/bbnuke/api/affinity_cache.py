"""Pre-computed PSICHIC affinity data cache.

Loads the affinity matrix and pKa CSVs on first access, builds a canonical
SMILES → compound_id lookup so the score endpoint can resolve any SMILES
to its pre-computed affinity scores.
"""

from __future__ import annotations

import csv
import functools
import logging
import os
from typing import Dict, List, Optional, Tuple

from bbnuke.core.schemas import AffinityModel, AffinityScore
from bbnuke.modules.pka import PkaData

logger = logging.getLogger(__name__)

# Default paths (relative to package root)
_PACKAGE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PROJECT_DIR = os.path.dirname(_PACKAGE_DIR)  # src/
_REPO_DIR = os.path.dirname(_PROJECT_DIR)      # bbnuke/

_DEFAULT_AFFINITY_CSV = os.path.join(_REPO_DIR, "psichic_affinity_matrix.csv")
_DEFAULT_PKA_CSV = os.path.join(_REPO_DIR, "bbb_plus_pka.csv")


@functools.lru_cache(maxsize=1)
def _load_affinity_matrix(
    affinity_csv: Optional[str] = None,
) -> Dict[str, List[AffinityScore]]:
    """Load wide-format affinity matrix → {compound_id: [AffinityScore, ...]}."""
    path = affinity_csv or _DEFAULT_AFFINITY_CSV
    if not os.path.exists(path):
        logger.warning("Affinity matrix not found: %s", path)
        return {}

    affinity_map: Dict[str, List[AffinityScore]] = {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        protein_cols = [c for c in (reader.fieldnames or []) if c != "Compound_ID"]
        for row in reader:
            cid = row["Compound_ID"]
            scores: List[AffinityScore] = []
            for protein in protein_cols:
                raw_val = row.get(protein, "")
                if not raw_val:
                    continue
                score_norm = float(raw_val)
                scores.append(AffinityScore(
                    protein_id=protein,
                    score_raw=score_norm * 10.0,  # denormalize to 0-10 scale
                    score_norm=min(max(score_norm, 0.0), 1.0),
                    model=AffinityModel.psichic,
                ))
            affinity_map[cid] = scores

    logger.info("Loaded affinity data for %d compounds", len(affinity_map))
    return affinity_map


@functools.lru_cache(maxsize=1)
def _load_smiles_lookup(
    pka_csv: Optional[str] = None,
) -> Tuple[Dict[str, str], Dict[str, PkaData]]:
    """Load pKa CSV → (canonical_smiles → compound_id, compound_id → PkaData).

    Uses RDKit to canonicalize SMILES for reliable matching.
    """
    path = pka_csv or _DEFAULT_PKA_CSV
    if not os.path.exists(path):
        logger.warning("pKa CSV not found: %s", path)
        return {}, {}

    from bbnuke.modules.standardize import standardize_smiles

    smiles_to_id: Dict[str, str] = {}
    pka_data_map: Dict[str, PkaData] = {}

    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cid = row.get("compound_name", "").strip()
            raw_smiles = row.get("SMILES", "").strip()
            if not cid or not raw_smiles:
                continue

            # Canonicalize for lookup
            try:
                canonical = standardize_smiles(raw_smiles)
                smiles_to_id[canonical] = cid
            except Exception:
                # If standardization fails, store raw
                smiles_to_id[raw_smiles] = cid

            # Parse pKa data
            acid_str = row.get("acid_pkas", "").strip()
            base_str = row.get("base_pkas", "").strip()
            acid_pkas = _parse_pka_list(acid_str)
            base_pkas = _parse_pka_list(base_str)

            rep = None
            if base_pkas:
                rep = max(base_pkas)
            elif acid_pkas:
                rep = min(acid_pkas)

            pka_data_map[cid] = PkaData(
                acid_pkas=acid_pkas,
                base_pkas=base_pkas,
                representative=rep,
            )

    logger.info(
        "Loaded SMILES lookup: %d compounds, %d with pKa data",
        len(smiles_to_id), len(pka_data_map),
    )
    return smiles_to_id, pka_data_map


def _parse_pka_list(s: str) -> List[float]:
    """Parse comma-separated pKa values, filtering out invalid entries."""
    if not s:
        return []
    values = []
    for part in s.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            v = float(part)
            if -2 <= v <= 14:  # sanity filter
                values.append(v)
        except ValueError:
            continue
    return values


def lookup_affinity(
    standardized_smiles: str,
) -> Tuple[Optional[List[AffinityScore]], Optional[PkaData], Optional[str]]:
    """Look up pre-computed affinity scores and pKa by canonical SMILES.

    Returns:
        (affinity_scores, pka_data, compound_name) — any may be None if not found.
    """
    smiles_to_id, pka_data_map = _load_smiles_lookup()
    affinity_map = _load_affinity_matrix()

    cid = smiles_to_id.get(standardized_smiles)
    if cid is None:
        return None, None, None

    affinity_scores = affinity_map.get(cid)
    pka_data = pka_data_map.get(cid)

    return affinity_scores, pka_data, cid


def get_known_compound_count() -> int:
    """Number of compounds in the pre-computed affinity cache."""
    return len(_load_affinity_matrix())
