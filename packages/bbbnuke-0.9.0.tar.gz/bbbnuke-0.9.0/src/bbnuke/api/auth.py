"""API key authentication.

Key format: bnk_live_<32 hex chars>  (e.g. bnk_live_a1b2c3d4...)
Storage: SHA-256 hash in database. Raw key shown only at creation time.

Supports two modes:
  1. Single env var (BBNUKE_API_KEY) — simple Tier A deployments
  2. Database-backed keys — Tier B with per-key rate limits and org scoping
"""

from __future__ import annotations

import hashlib
import secrets
from typing import Optional

from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bbnuke.core.config import settings

API_KEY_PREFIX = "bnk_live_"


def generate_api_key() -> tuple[str, str]:
    """Generate a new API key.

    Returns:
        (raw_key, key_hash) — raw_key shown once to user, key_hash stored in DB.
    """
    raw = API_KEY_PREFIX + secrets.token_hex(32)
    hashed = hash_key(raw)
    return raw, hashed


def hash_key(raw_key: str) -> str:
    """SHA-256 hash of a raw API key."""
    return hashlib.sha256(raw_key.encode()).hexdigest()


async def verify_api_key(request: Request) -> Optional[str]:
    """FastAPI dependency: verify the API key from Authorization header.

    Returns the key hash if valid. Raises 401/403 on failure.
    If no auth is configured (no env key, no DB keys), returns None (open access).
    """
    auth = request.headers.get("Authorization")

    # No auth header provided
    if not auth or not auth.startswith("Bearer "):
        # If no auth is required (no env key set), allow through
        if settings.api_key is None:
            return None
        raise HTTPException(status_code=401, detail="Missing Authorization header")

    token = auth[len("Bearer "):]

    # Check against env var first (fast path)
    if settings.api_key is not None and token == settings.api_key:
        return hash_key(token)

    # Check against database
    token_hash = hash_key(token)
    try:
        from bbnuke.api.deps import get_db
        from bbnuke.db.models import ApiKey

        # Get a session manually (can't use Depends inside Depends easily)
        from bbnuke.db.session import async_session_factory
        async with async_session_factory() as session:
            result = await session.execute(
                select(ApiKey).where(
                    ApiKey.key_hash == token_hash,
                    ApiKey.is_active == True,
                )
            )
            db_key = result.scalar_one_or_none()
            if db_key is not None:
                return token_hash
    except Exception:
        # DB not available — fall through to env-only check
        pass

    # If env key is set and token didn't match, reject
    if settings.api_key is not None:
        raise HTTPException(status_code=403, detail="Invalid API key")

    # No auth configured at all — open access
    return None
