"""API middleware: request ID, timing, auth, rate limiting."""

from __future__ import annotations

import time
import uuid
from collections import defaultdict
from typing import Dict, Optional, Tuple

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

import bbnuke.core.config as _cfg


class RequestIdMiddleware(BaseHTTPMiddleware):
    """Attach a unique request ID and timing header to every response."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id

        start = time.perf_counter()
        response = await call_next(request)
        elapsed_ms = (time.perf_counter() - start) * 1000

        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time-Ms"] = f"{elapsed_ms:.1f}"
        return response


EXEMPT_PATHS = {"/v1/health", "/v1/version", "/docs", "/openapi.json", "/redoc"}


class ApiKeyMiddleware(BaseHTTPMiddleware):
    """Optional API key authentication.

    If BBNUKE_API_KEY is set, all requests must include it as
    Authorization: Bearer <key>. Health and version endpoints are exempt.
    Also checks DB-backed keys when available.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        if request.url.path in EXEMPT_PATHS:
            return await call_next(request)

        if _cfg.settings.api_key is None:
            # No env key set — open access (DB keys checked at route level if needed)
            return await call_next(request)

        auth: Optional[str] = request.headers.get("Authorization")
        if not auth or not auth.startswith("Bearer "):
            return Response(
                content='{"detail":"Missing or invalid Authorization header"}',
                status_code=401,
                media_type="application/json",
            )

        token = auth[len("Bearer "):]

        # Check env var
        if token == _cfg.settings.api_key:
            return await call_next(request)

        # Check DB-backed keys
        from bbnuke.api.auth import hash_key
        token_hash = hash_key(token)
        try:
            from sqlalchemy import select
            from bbnuke.db.models import ApiKey
            from bbnuke.db.session import async_session_factory

            async with async_session_factory() as session:
                result = await session.execute(
                    select(ApiKey).where(
                        ApiKey.key_hash == token_hash,
                        ApiKey.is_active == True,
                    )
                )
                if result.scalar_one_or_none() is not None:
                    return await call_next(request)
        except Exception:
            pass

        return Response(
            content='{"detail":"Invalid API key"}',
            status_code=403,
            media_type="application/json",
        )


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Sliding window rate limiter.

    Uses Redis when available, falls back to in-memory counters.
    Returns 429 with Retry-After header when limit exceeded.
    Adds X-RateLimit-* headers to all responses.
    """

    def __init__(self, app, default_rpm: int = 100):
        super().__init__(app)
        self.default_rpm = default_rpm
        # In-memory fallback: {client_key: [(timestamp, ...)] }
        self._memory_windows: Dict[str, list] = defaultdict(list)

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        if request.url.path in EXEMPT_PATHS:
            return await call_next(request)

        client_key = self._get_client_key(request)
        rpm = self.default_rpm
        now = time.time()

        allowed, remaining, reset_at = await self._check_rate_limit(
            client_key, rpm, now
        )

        if not allowed:
            retry_after = max(1, int(reset_at - now))
            return Response(
                content='{"detail":"Rate limit exceeded"}',
                status_code=429,
                media_type="application/json",
                headers={
                    "Retry-After": str(retry_after),
                    "X-RateLimit-Limit": str(rpm),
                    "X-RateLimit-Remaining": "0",
                    "X-RateLimit-Reset": str(int(reset_at)),
                },
            )

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(rpm)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Reset"] = str(int(reset_at))
        return response

    def _get_client_key(self, request: Request) -> str:
        """Identify client by API key or IP."""
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return f"key:{auth[7:20]}"  # First 13 chars of token
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return f"ip:{forwarded.split(',')[0].strip()}"
        client = request.client
        return f"ip:{client.host}" if client else "ip:unknown"

    async def _check_rate_limit(
        self, client_key: str, rpm: int, now: float
    ) -> Tuple[bool, int, float]:
        """Check and record a request. Returns (allowed, remaining, reset_at)."""
        # Try Redis first
        try:
            return await self._check_redis(client_key, rpm, now)
        except Exception:
            pass

        # Fallback to in-memory
        return self._check_memory(client_key, rpm, now)

    async def _check_redis(
        self, client_key: str, rpm: int, now: float
    ) -> Tuple[bool, int, float]:
        """Redis sliding window counter."""
        from bbnuke.api.deps import get_redis
        redis = await get_redis()

        window_key = f"bbnuke:ratelimit:{client_key}"
        window_start = now - 60

        pipe = redis.pipeline()
        # Remove old entries
        pipe.zremrangebyscore(window_key, 0, window_start)
        # Add current request
        pipe.zadd(window_key, {str(now): now})
        # Count requests in window
        pipe.zcard(window_key)
        # Set expiry
        pipe.expire(window_key, 120)
        results = await pipe.execute()

        count = results[2]
        remaining = max(0, rpm - count)
        reset_at = now + 60

        if count > rpm:
            return False, 0, reset_at

        return True, remaining, reset_at

    def _check_memory(
        self, client_key: str, rpm: int, now: float
    ) -> Tuple[bool, int, float]:
        """In-memory sliding window fallback."""
        window_start = now - 60
        # Prune old entries
        self._memory_windows[client_key] = [
            t for t in self._memory_windows[client_key] if t > window_start
        ]
        count = len(self._memory_windows[client_key])
        reset_at = now + 60

        if count >= rpm:
            return False, 0, reset_at

        self._memory_windows[client_key].append(now)
        remaining = rpm - count - 1
        return True, remaining, reset_at
