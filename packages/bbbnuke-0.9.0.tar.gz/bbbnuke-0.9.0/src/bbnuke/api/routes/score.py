"""Single compound scoring endpoint."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from bbnuke import __version__
from bbnuke.api.affinity_cache import lookup_affinity
from bbnuke.api.schemas import ScoreRequest, ScoreResponse
from bbnuke.core.config import settings
from bbnuke.core.schemas import CompoundInput, PipelineConfig
from bbnuke.pipeline.runner import run_single

router = APIRouter()


@router.post("/score", response_model=ScoreResponse)
async def score_compound(req: ScoreRequest) -> ScoreResponse:
    """Score a single compound through the BBB-Nuke pipeline.

    If include_affinity is True, looks up pre-computed PSICHIC affinity scores
    by canonical SMILES (599 BBB+ compounds available).  If the compound is not
    in the pre-computed set, scoring proceeds without affinity data.
    """
    config = req.config or PipelineConfig()

    compound = CompoundInput(
        compound_id=req.compound_id,
        smiles=req.smiles,
    )

    try:
        # Standardize first to get canonical SMILES for lookup
        from bbnuke.modules.standardize import standardize_smiles

        std_smiles = standardize_smiles(req.smiles)

        affinity_scores = None
        pka_data = None

        if req.include_affinity:
            affinity_scores, pka_data, matched_id = lookup_affinity(std_smiles)

        result = run_single(
            compound,
            pka_data=pka_data,
            affinity_scores=affinity_scores,
            weights_path=config.weights_path or settings.weights_path,
        )
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Pipeline error: {e}")

    return ScoreResponse(
        result=result,
        pipeline_version=__version__,
        config=config,
    )
