"""API key management endpoints."""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bbnuke.api.auth import generate_api_key
from bbnuke.api.deps import get_db
from bbnuke.db.models import ApiKey

router = APIRouter()


class CreateKeyRequest(BaseModel):
    label: str = Field(default="", max_length=255)
    rate_limit_rpm: int = Field(default=100, ge=1, le=10000)


class CreateKeyResponse(BaseModel):
    """Returned only once — raw key is not stored."""
    key: str
    label: str
    rate_limit_rpm: int


class KeyInfo(BaseModel):
    id: int
    label: str
    is_active: bool
    rate_limit_rpm: int
    key_prefix: str = Field(description="First 12 chars of key for identification")
    created_at: str


@router.post("/keys", response_model=CreateKeyResponse, status_code=201)
async def create_key(
    req: CreateKeyRequest,
    db: AsyncSession = Depends(get_db),
) -> CreateKeyResponse:
    """Generate a new API key. The raw key is shown only in this response."""
    raw_key, key_hash = generate_api_key()

    db_key = ApiKey(
        key_hash=key_hash,
        label=req.label,
        rate_limit_rpm=req.rate_limit_rpm,
    )
    db.add(db_key)
    await db.commit()

    return CreateKeyResponse(
        key=raw_key,
        label=req.label,
        rate_limit_rpm=req.rate_limit_rpm,
    )


@router.get("/keys", response_model=List[KeyInfo])
async def list_keys(
    db: AsyncSession = Depends(get_db),
) -> List[KeyInfo]:
    """List all API keys (hashes only, never raw keys)."""
    result = await db.execute(select(ApiKey).order_by(ApiKey.created_at.desc()))
    keys = result.scalars().all()

    return [
        KeyInfo(
            id=k.id,
            label=k.label,
            is_active=k.is_active,
            rate_limit_rpm=k.rate_limit_rpm,
            key_prefix=f"bnk_live_{k.key_hash[:8]}...",
            created_at=k.created_at.isoformat() if k.created_at else "",
        )
        for k in keys
    ]


@router.delete("/keys/{key_id}")
async def revoke_key(
    key_id: int,
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Revoke (deactivate) an API key."""
    result = await db.execute(select(ApiKey).where(ApiKey.id == key_id))
    key = result.scalar_one_or_none()
    if key is None:
        raise HTTPException(status_code=404, detail="Key not found")

    key.is_active = False
    await db.commit()
    return {"id": key_id, "status": "revoked"}
