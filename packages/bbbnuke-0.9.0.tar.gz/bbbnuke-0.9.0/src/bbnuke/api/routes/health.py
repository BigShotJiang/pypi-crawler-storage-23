"""Health and version endpoints."""

from __future__ import annotations

from fastapi import APIRouter

from bbnuke import __version__
from bbnuke.core.constants import (
    EFFLUX_VETO_THRESHOLD,
    LOGISTIC_K,
    MPO_FILTER_CUTOFF,
    MPO_GAIN_COEFF,
)
from bbnuke.api.schemas import HealthResponse, VersionResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    return HealthResponse(status="ok")


@router.get("/version", response_model=VersionResponse)
async def version() -> VersionResponse:
    return VersionResponse(
        pipeline_version=__version__,
        hyperparameters={
            "logistic_k": LOGISTIC_K,
            "efflux_veto_threshold": EFFLUX_VETO_THRESHOLD,
            "mpo_gain_coeff": MPO_GAIN_COEFF,
            "mpo_filter_cutoff": MPO_FILTER_CUTOFF,
        },
    )
