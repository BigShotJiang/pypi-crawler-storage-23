"""Organization, workspace, and project management endpoints (Tier B)."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from bbnuke.api.deps import get_db
from bbnuke.db.models import Organization, OrgMember, Project, Workspace

router = APIRouter()


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

class CreateOrgRequest(BaseModel):
    name: str = Field(min_length=1, max_length=255)


class OrgResponse(BaseModel):
    id: str
    name: str
    plan: str
    created_at: str
    member_count: int = 0
    workspace_count: int = 0


class CreateWorkspaceRequest(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: str = ""


class WorkspaceResponse(BaseModel):
    id: str
    org_id: str
    name: str
    description: str
    created_at: str
    project_count: int = 0


class CreateProjectRequest(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: str = ""
    config: Optional[Dict[str, Any]] = None


class ProjectResponse(BaseModel):
    id: str
    workspace_id: str
    name: str
    description: str
    config: Optional[Dict[str, Any]] = None
    created_at: str


# ---------------------------------------------------------------------------
# Organizations
# ---------------------------------------------------------------------------

@router.post("/orgs", response_model=OrgResponse, status_code=201)
async def create_org(
    req: CreateOrgRequest,
    db: AsyncSession = Depends(get_db),
) -> OrgResponse:
    org = Organization(name=req.name)
    db.add(org)
    await db.commit()
    await db.refresh(org)
    return OrgResponse(
        id=org.id, name=org.name, plan=org.plan,
        created_at=org.created_at.isoformat() if org.created_at else "",
    )


@router.get("/orgs", response_model=List[OrgResponse])
async def list_orgs(
    db: AsyncSession = Depends(get_db),
) -> List[OrgResponse]:
    result = await db.execute(
        select(Organization).options(
            selectinload(Organization.members),
            selectinload(Organization.workspaces),
        )
    )
    orgs = result.scalars().all()
    return [
        OrgResponse(
            id=o.id, name=o.name, plan=o.plan,
            created_at=o.created_at.isoformat() if o.created_at else "",
            member_count=len(o.members),
            workspace_count=len(o.workspaces),
        )
        for o in orgs
    ]


@router.get("/orgs/{org_id}", response_model=OrgResponse)
async def get_org(org_id: str, db: AsyncSession = Depends(get_db)) -> OrgResponse:
    result = await db.execute(
        select(Organization)
        .options(selectinload(Organization.members), selectinload(Organization.workspaces))
        .where(Organization.id == org_id)
    )
    org = result.scalar_one_or_none()
    if org is None:
        raise HTTPException(status_code=404, detail="Organization not found")
    return OrgResponse(
        id=org.id, name=org.name, plan=org.plan,
        created_at=org.created_at.isoformat() if org.created_at else "",
        member_count=len(org.members),
        workspace_count=len(org.workspaces),
    )


# ---------------------------------------------------------------------------
# Workspaces
# ---------------------------------------------------------------------------

@router.post("/orgs/{org_id}/workspaces", response_model=WorkspaceResponse, status_code=201)
async def create_workspace(
    org_id: str,
    req: CreateWorkspaceRequest,
    db: AsyncSession = Depends(get_db),
) -> WorkspaceResponse:
    # Verify org exists
    org = await db.get(Organization, org_id)
    if org is None:
        raise HTTPException(status_code=404, detail="Organization not found")

    ws = Workspace(org_id=org_id, name=req.name, description=req.description)
    db.add(ws)
    await db.commit()
    await db.refresh(ws)
    return WorkspaceResponse(
        id=ws.id, org_id=ws.org_id, name=ws.name, description=ws.description,
        created_at=ws.created_at.isoformat() if ws.created_at else "",
    )


@router.get("/orgs/{org_id}/workspaces", response_model=List[WorkspaceResponse])
async def list_workspaces(
    org_id: str,
    db: AsyncSession = Depends(get_db),
) -> List[WorkspaceResponse]:
    result = await db.execute(
        select(Workspace)
        .options(selectinload(Workspace.projects))
        .where(Workspace.org_id == org_id)
    )
    workspaces = result.scalars().all()
    return [
        WorkspaceResponse(
            id=w.id, org_id=w.org_id, name=w.name, description=w.description,
            created_at=w.created_at.isoformat() if w.created_at else "",
            project_count=len(w.projects),
        )
        for w in workspaces
    ]


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------

@router.post("/workspaces/{ws_id}/projects", response_model=ProjectResponse, status_code=201)
async def create_project(
    ws_id: str,
    req: CreateProjectRequest,
    db: AsyncSession = Depends(get_db),
) -> ProjectResponse:
    ws = await db.get(Workspace, ws_id)
    if ws is None:
        raise HTTPException(status_code=404, detail="Workspace not found")

    proj = Project(
        workspace_id=ws_id, name=req.name,
        description=req.description, config_json=req.config,
    )
    db.add(proj)
    await db.commit()
    await db.refresh(proj)
    return ProjectResponse(
        id=proj.id, workspace_id=proj.workspace_id, name=proj.name,
        description=proj.description, config=proj.config_json,
        created_at=proj.created_at.isoformat() if proj.created_at else "",
    )


@router.get("/workspaces/{ws_id}/projects", response_model=List[ProjectResponse])
async def list_projects(
    ws_id: str,
    db: AsyncSession = Depends(get_db),
) -> List[ProjectResponse]:
    result = await db.execute(
        select(Project).where(Project.workspace_id == ws_id)
    )
    projects = result.scalars().all()
    return [
        ProjectResponse(
            id=p.id, workspace_id=p.workspace_id, name=p.name,
            description=p.description, config=p.config_json,
            created_at=p.created_at.isoformat() if p.created_at else "",
        )
        for p in projects
    ]


@router.get("/projects/{proj_id}", response_model=ProjectResponse)
async def get_project(
    proj_id: str,
    db: AsyncSession = Depends(get_db),
) -> ProjectResponse:
    proj = await db.get(Project, proj_id)
    if proj is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return ProjectResponse(
        id=proj.id, workspace_id=proj.workspace_id, name=proj.name,
        description=proj.description, config=proj.config_json,
        created_at=proj.created_at.isoformat() if proj.created_at else "",
    )
