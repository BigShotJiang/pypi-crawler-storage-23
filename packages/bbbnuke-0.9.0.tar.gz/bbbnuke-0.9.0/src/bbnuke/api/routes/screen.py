"""Full screening endpoint (Sprint 2 stub)."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

router = APIRouter()


@router.post("/screen", status_code=501)
async def screen(req: dict) -> dict:
    raise HTTPException(
        status_code=501,
        detail="Full screening (pKa + affinity + heuristic) requires job queue (Sprint 2).",
    )
