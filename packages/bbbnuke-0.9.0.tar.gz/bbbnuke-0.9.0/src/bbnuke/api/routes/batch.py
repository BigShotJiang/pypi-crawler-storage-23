"""Batch scoring endpoints.

POST /v1/batch       — submit batch job → returns job_id
GET  /v1/batch/{id}  — poll job status + progress
DELETE /v1/batch/{id} — cancel job
GET  /v1/batch/{id}/results — download results
"""

from __future__ import annotations

import json
import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bbnuke.api.deps import get_arq_redis, get_db
from bbnuke.api.schemas import BatchRequest, BatchStatusResponse, JobStatus
from bbnuke.core.config import settings
from bbnuke.db.models import CompoundResult, Job

router = APIRouter()


@router.post("/batch", status_code=202)
async def submit_batch(
    req: BatchRequest,
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    """Submit a batch of compounds for scoring.

    Returns a job_id immediately. Poll GET /v1/batch/{job_id} for progress.
    """
    if len(req.compounds) > settings.max_batch_size:
        raise HTTPException(
            status_code=400,
            detail=f"Batch size {len(req.compounds)} exceeds maximum {settings.max_batch_size}",
        )

    if not req.compounds:
        raise HTTPException(status_code=400, detail="No compounds provided")

    job_id = str(uuid.uuid4())
    config_dict = req.config.model_dump(mode="json") if req.config else None

    # Create DB record
    job = Job(
        id=job_id,
        status="pending",
        total_compounds=len(req.compounds),
        completed_compounds=0,
        current_stage="queued",
        config_json=config_dict,
        callback_url=req.callback_url,
    )
    db.add(job)
    await db.commit()

    # Enqueue orchestrator job
    try:
        arq = await get_arq_redis()
        compounds_data = [c.model_dump() for c in req.compounds]
        await arq.enqueue_job(
            "run_batch_job",
            job_id,
            compounds_data,
            req.run_affinity,
            config_dict,
            req.callback_url,
            _queue_name="bbnuke:orchestrator",
        )
        await arq.close()
    except Exception as e:
        # If Redis is down, still return job_id but mark as failed
        job.status = "failed"
        job.error_message = f"Failed to enqueue: {e}"
        await db.commit()
        raise HTTPException(
            status_code=503,
            detail=f"Job queue unavailable: {e}",
        )

    return {"job_id": job_id, "status": "pending", "total_compounds": len(req.compounds)}


@router.get("/batch/{job_id}", response_model=BatchStatusResponse)
async def get_batch_status(job_id: str) -> BatchStatusResponse:
    """Poll job status and progress.

    Reads from Redis for fast polling (no DB query).
    Falls back to DB if Redis data missing.
    """
    try:
        from bbnuke.api.deps import get_redis
        redis = await get_redis()
        progress_raw = await redis.get(f"bbnuke:job:{job_id}:progress")
        if progress_raw:
            progress = json.loads(progress_raw)
            return BatchStatusResponse(
                job_id=job_id,
                status=JobStatus(progress["status"]),
                total_compounds=progress["total_compounds"],
                completed_compounds=progress["completed_compounds"],
                current_stage=progress.get("current_stage", ""),
                pct=progress.get("pct", 0.0),
            )
    except Exception:
        pass

    # Fallback: not found
    raise HTTPException(status_code=404, detail=f"Job {job_id} not found")


@router.delete("/batch/{job_id}")
async def cancel_batch(job_id: str) -> Dict[str, str]:
    """Cancel a running batch job."""
    try:
        from bbnuke.api.deps import get_redis
        redis = await get_redis()
        progress_raw = await redis.get(f"bbnuke:job:{job_id}:progress")
        if progress_raw:
            progress = json.loads(progress_raw)
            progress["status"] = "cancelled"
            await redis.set(
                f"bbnuke:job:{job_id}:progress",
                json.dumps(progress),
                ex=86400,
            )
            return {"job_id": job_id, "status": "cancelled"}
    except Exception:
        pass

    raise HTTPException(status_code=404, detail=f"Job {job_id} not found")


@router.get("/batch/{job_id}/results")
async def get_batch_results(
    job_id: str,
    format: str = "json",
) -> Any:
    """Download full results for a completed job."""
    try:
        from bbnuke.api.deps import get_redis
        redis = await get_redis()

        # Check status first
        progress_raw = await redis.get(f"bbnuke:job:{job_id}:progress")
        if not progress_raw:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

        progress = json.loads(progress_raw)
        if progress["status"] != "completed":
            raise HTTPException(
                status_code=409,
                detail=f"Job {job_id} is {progress['status']}, not completed",
            )

        results_raw = await redis.get(f"bbnuke:job:{job_id}:results")
        if not results_raw:
            raise HTTPException(status_code=404, detail=f"Results for {job_id} expired or not found")

        results = json.loads(results_raw)

        summary_raw = await redis.get(f"bbnuke:job:{job_id}:summary")
        summary = json.loads(summary_raw) if summary_raw else {}

        if format == "csv":
            import io
            import csv
            from fastapi.responses import StreamingResponse

            output = io.StringIO()
            if results:
                writer = csv.DictWriter(output, fieldnames=["compound_id", "smiles_standardized", "cns_mpo_score", "passed_mpo_filter", "p_bbb"])
                writer.writeheader()
                for r in results:
                    p_bbb = None
                    if r.get("heuristic"):
                        p_bbb = r["heuristic"].get("p_bbb")
                    writer.writerow({
                        "compound_id": r.get("compound_id", ""),
                        "smiles_standardized": r.get("smiles_standardized", ""),
                        "cns_mpo_score": r.get("cns_mpo", {}).get("score"),
                        "passed_mpo_filter": r.get("passed_mpo_filter"),
                        "p_bbb": p_bbb,
                    })
            output.seek(0)
            return StreamingResponse(
                output,
                media_type="text/csv",
                headers={"Content-Disposition": f"attachment; filename={job_id}.csv"},
            )

        return {
            "job_id": job_id,
            "summary": summary,
            "results": results,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Results retrieval failed: {e}")
