"""Protein table endpoint."""

from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd
from fastapi import APIRouter

from bbnuke.api.schemas import ProteinInfo, ProteinsResponse
from bbnuke.core.schemas import ProteinCategory

router = APIRouter()


def _data_dir() -> Path:
    return Path(__file__).resolve().parent.parent.parent / "data"


def _load_proteins() -> List[ProteinInfo]:
    csv_path = _data_dir() / "BBB_proteins_merged.csv"
    df = pd.read_csv(csv_path)
    df.columns = [c.strip() for c in df.columns]

    proteins: List[ProteinInfo] = []
    for _, row in df.iterrows():
        cat_str = str(row["Type"]).strip().lower()
        try:
            cat = ProteinCategory(cat_str)
        except ValueError:
            cat = ProteinCategory.carrier

        proteins.append(ProteinInfo(
            common_name=str(row["Common Name"]).strip(),
            uniprot_name=str(row["UniProt Name"]).strip() if pd.notna(row.get("UniProt Name")) else None,
            full_name=str(row["Full Name"]).strip() if pd.notna(row.get("Full Name")) else None,
            category=cat,
            weight=float(row["Weight"]),
            binding_threshold=float(row["Binding Threshold"]) if pd.notna(row.get("Binding Threshold")) else 0.7,
        ))
    return proteins


@router.get("/proteins", response_model=ProteinsResponse)
async def list_proteins() -> ProteinsResponse:
    proteins = _load_proteins()
    return ProteinsResponse(proteins=proteins, count=len(proteins))
