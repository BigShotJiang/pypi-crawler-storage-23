"""Agent orchestrator — walks the fixed run graph and executes steps.

The ``plan_step()`` method is the LLM integration point.  The default
implementation returns a deterministic plan; subclass and override
``plan_step()`` to wire in an LLM.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from bbnuke.agent.permissions import get_tier_limits
from bbnuke.agent.state import (
    AgentContext,
    RUN_GRAPH,
    RunState,
    RunStateManager,
    RunStepName,
    StepStatus,
    TierName,
)
from bbnuke.agent.tools.registry import ToolExecutionError, invoke
from bbnuke.agent.workspace import WorkspaceSandbox

logger = logging.getLogger(__name__)


class AgentOrchestrator:
    """Execute the fixed run graph, step by step.

    Each step is planned (``plan_step``) into a list of ``(tool_name, input_dict)``
    tuples, then executed sequentially via ``invoke()``.  State is saved after
    each tool call for crash-recovery.
    """

    def __init__(
        self,
        run_id: str,
        tier: TierName,
        org_id: Optional[str] = None,
        runs_dir: Optional[str] = None,
        db_session: Optional[Any] = None,
    ) -> None:
        self.run_id = run_id
        self.tier = tier
        self.org_id = org_id
        self.sandbox = WorkspaceSandbox(run_id=run_id, runs_dir=runs_dir)
        self.state_manager = RunStateManager(sandbox=self.sandbox)
        self.db_session = db_session
        self.limits = get_tier_limits(tier)

        self.ctx = AgentContext(
            run_id=run_id,
            tier=tier,
            org_id=org_id,
            sandbox=self.sandbox,
            state_manager=self.state_manager,
            db_session=db_session,
        )

    async def run(self) -> RunState:
        """Execute the full run graph, resuming from last completed step."""
        # Init workspace
        self.sandbox.init()
        state = self.state_manager.load_or_create(
            self.run_id, self.tier, self.org_id
        )

        total_tool_calls = 0

        for step_rec in state.steps:
            if step_rec.status in (StepStatus.completed, StepStatus.skipped):
                # Count prior tool calls for limit enforcement
                total_tool_calls += len(step_rec.tool_calls)
                continue

            # Check tool call budget
            if total_tool_calls >= self.limits.max_tool_calls:
                step_rec.status = StepStatus.failed
                step_rec.error = "Tool call limit exceeded"
                self.state_manager.save(state)
                break

            success = await self._execute_step(step_rec, state, total_tool_calls)
            total_tool_calls += len(step_rec.tool_calls)

            if not success:
                break  # abort on failure after retries exhausted

        return self.state_manager.load() or state

    async def _execute_step(
        self,
        step_rec: Any,
        state: RunState,
        total_tool_calls: int,
    ) -> bool:
        """Plan and execute a single step.  Returns True on success."""
        step_rec.status = StepStatus.running
        step_rec.started_at = datetime.now(timezone.utc).isoformat()
        self.state_manager.save(state)

        for attempt in range(self.limits.max_retries_per_step + 1):
            try:
                plan = await self.plan_step(step_rec.name, state)

                if not plan:
                    # Empty plan → skip step
                    step_rec.status = StepStatus.skipped
                    step_rec.completed_at = datetime.now(timezone.utc).isoformat()
                    self.state_manager.save(state)
                    return True

                for tool_name, tool_input in plan:
                    if total_tool_calls + len(step_rec.tool_calls) >= self.limits.max_tool_calls:
                        raise ToolExecutionError("Tool call limit exceeded")
                    result = await invoke(tool_name, tool_input, self.ctx)
                    # Record artifact path if the output has one
                    if hasattr(result, "artifact_path") and result.artifact_path:
                        step_rec.output_artifacts[tool_name] = result.artifact_path

                step_rec.status = StepStatus.completed
                step_rec.completed_at = datetime.now(timezone.utc).isoformat()
                self.state_manager.save(state)
                return True

            except Exception as exc:
                step_rec.retry_count = attempt + 1
                step_rec.error = str(exc)
                logger.warning(
                    "Step %s attempt %d failed: %s",
                    step_rec.name, attempt + 1, exc,
                )
                if attempt >= self.limits.max_retries_per_step:
                    step_rec.status = StepStatus.failed
                    self.state_manager.save(state)
                    return False
                # Save state between retries
                self.state_manager.save(state)

        return False  # unreachable, but satisfies type checker

    async def plan_step(
        self,
        step_name: RunStepName,
        state: RunState,
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """Return a deterministic tool-call plan for *step_name*.

        Override this method to integrate an LLM:

        .. code-block:: python

            class LlmAgentOrchestrator(AgentOrchestrator):
                async def plan_step(self, step_name, state):
                    schemas = get_registry().schema_for_llm(self.tier)
                    response = await llm_client.create(
                        messages=..., tools=schemas
                    )
                    return [(tc.name, tc.input) for tc in response.tool_calls]
        """
        # Find previous step artifacts
        def _artifact(step: RunStepName, tool: str) -> str:
            s = state.get_step(step)
            if s and s.output_artifacts.get(tool):
                return s.output_artifacts[tool]
            return ""

        if step_name == RunStepName.ingest:
            return [
                ("workspace_init", {}),
            ]

        elif step_name == RunStepName.standardize:
            return [
                ("run_standardize", {
                    "compounds_artifact": _artifact(RunStepName.ingest, "load_compounds_csv")
                    or "artifacts/compounds_validated.json",
                }),
            ]

        elif step_name == RunStepName.props_pka:
            return [
                ("run_properties_pka", {
                    "standardized_artifact": _artifact(RunStepName.standardize, "run_standardize")
                    or "artifacts/standardized.json",
                }),
            ]

        elif step_name == RunStepName.cns_mpo:
            return [
                ("run_cns_mpo", {
                    "props_pka_artifact": _artifact(RunStepName.props_pka, "run_properties_pka")
                    or "artifacts/props_pka.json",
                }),
            ]

        elif step_name == RunStepName.filter_mpo:
            # Filter is handled inline by run_cns_mpo (passed_mpo_filter field)
            return []

        elif step_name == RunStepName.affinity:
            if self.tier == TierName.tier_a:
                # tier_a: no GPU, skip affinity
                return []
            else:
                return [
                    ("submit_affinity_job", {
                        "ligands_artifact": _artifact(RunStepName.cns_mpo, "run_cns_mpo")
                        or "artifacts/cns_mpo.json",
                    }),
                ]

        elif step_name == RunStepName.heuristic:
            return [
                ("run_heuristic", {
                    "affinity_artifact": "artifacts/affinity.json",
                    "mpo_artifact": _artifact(RunStepName.cns_mpo, "run_cns_mpo")
                    or "artifacts/cns_mpo.json",
                }),
            ]

        elif step_name == RunStepName.export:
            return [
                ("export_results", {
                    "source_artifact": _artifact(RunStepName.heuristic, "run_heuristic")
                    or "artifacts/heuristic.json",
                    "format": "csv",
                }),
            ]

        return []
