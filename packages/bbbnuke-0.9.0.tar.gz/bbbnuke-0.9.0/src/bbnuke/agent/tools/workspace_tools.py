"""Workspace tools — file I/O within the sandbox."""

from __future__ import annotations

import csv
import io
import json
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from bbnuke.agent.state import AgentContext
from bbnuke.agent.tools.registry import PermissionScope, register_tool
from bbnuke.agent.workspace import (
    WorkspaceInitOutput,
    WorkspaceListOutput,
    WorkspaceReadOutput,
    WorkspaceWriteOutput,
)


# ---------------------------------------------------------------------------
# Input / output schemas
# ---------------------------------------------------------------------------

class WorkspaceInitInput(BaseModel):
    """No parameters needed — run_id comes from context."""
    pass


class WorkspaceListInput(BaseModel):
    pass


class WorkspaceReadInput(BaseModel):
    path: str = Field(description="Relative path within the workspace")


class WorkspaceWriteInput(BaseModel):
    path: str = Field(description="Relative path within the workspace")
    content: str = Field(description="Text content to write")


class LoadCompoundsCsvInput(BaseModel):
    csv_path: str = Field(description="Relative path to input CSV in workspace")
    smiles_col: str = Field(default="smiles", description="Column containing SMILES")
    id_col: Optional[str] = Field(default=None, description="Column for compound IDs (auto-generated if absent)")


class LoadCompoundsCsvOutput(BaseModel):
    n_compounds: int
    artifact_path: str
    errors: List[str] = Field(default_factory=list)


class ExportResultsInput(BaseModel):
    source_artifact: str = Field(description="Relative path to results JSON artifact")
    format: str = Field(default="csv", description="'csv' or 'json'")
    filename: Optional[str] = Field(default=None, description="Output filename (auto-generated if absent)")


class ExportResultsOutput(BaseModel):
    artifact_path: str
    n_records: int
    format: str


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------

@register_tool(
    name="workspace_init",
    description="Create the run directory tree for a new pipeline run.",
    input_schema=WorkspaceInitInput,
    output_schema=WorkspaceInitOutput,
    permission_scope=PermissionScope.tier_a,
)
async def workspace_init(inp: WorkspaceInitInput, ctx: AgentContext) -> WorkspaceInitOutput:
    return ctx.sandbox.init()


@register_tool(
    name="workspace_list",
    description="List all files in the workspace with sizes and timestamps.",
    input_schema=WorkspaceListInput,
    output_schema=WorkspaceListOutput,
    permission_scope=PermissionScope.tier_a,
)
async def workspace_list(inp: WorkspaceListInput, ctx: AgentContext) -> WorkspaceListOutput:
    return ctx.sandbox.list_files()


@register_tool(
    name="workspace_read",
    description="Read the contents of a file in the workspace (2 MB max).",
    input_schema=WorkspaceReadInput,
    output_schema=WorkspaceReadOutput,
    permission_scope=PermissionScope.tier_a,
)
async def workspace_read(inp: WorkspaceReadInput, ctx: AgentContext) -> WorkspaceReadOutput:
    return ctx.sandbox.read_file(inp.path)


@register_tool(
    name="workspace_write",
    description="Write text content to a file in the workspace.",
    input_schema=WorkspaceWriteInput,
    output_schema=WorkspaceWriteOutput,
    permission_scope=PermissionScope.tier_a,
)
async def workspace_write(inp: WorkspaceWriteInput, ctx: AgentContext) -> WorkspaceWriteOutput:
    return ctx.sandbox.write_file(inp.path, inp.content)


@register_tool(
    name="load_compounds_csv",
    description="Parse a CSV of compounds, validate SMILES, and save to artifacts/compounds_validated.json.",
    input_schema=LoadCompoundsCsvInput,
    output_schema=LoadCompoundsCsvOutput,
    permission_scope=PermissionScope.tier_a,
)
async def load_compounds_csv(
    inp: LoadCompoundsCsvInput, ctx: AgentContext
) -> LoadCompoundsCsvOutput:
    from bbnuke.core.schemas import CompoundInput

    raw = ctx.sandbox.read_file(inp.csv_path)
    reader = csv.DictReader(io.StringIO(raw.content))

    compounds: List[Dict[str, Any]] = []
    errors: List[str] = []
    for i, row in enumerate(reader):
        smiles = row.get(inp.smiles_col, "").strip()
        if not smiles:
            errors.append(f"Row {i}: missing SMILES in column '{inp.smiles_col}'")
            continue
        if inp.id_col and inp.id_col in row:
            cid = row[inp.id_col].strip()
        else:
            cid = f"compound_{i}"
        try:
            c = CompoundInput(compound_id=cid, smiles=smiles)
            compounds.append(c.model_dump())
        except Exception as exc:
            errors.append(f"Row {i} ({cid}): {exc}")

    artifact_path = "artifacts/compounds_validated.json"
    ctx.sandbox.write_file(artifact_path, json.dumps(compounds, indent=2))

    # Update state
    state = ctx.state_manager.load()
    if state is not None:
        state.n_compounds_input = len(compounds)
        ctx.state_manager.save(state)

    return LoadCompoundsCsvOutput(
        n_compounds=len(compounds),
        artifact_path=artifact_path,
        errors=errors[:20],  # cap error list
    )


@register_tool(
    name="export_results",
    description="Write final pipeline results as CSV or JSON to artifacts/.",
    input_schema=ExportResultsInput,
    output_schema=ExportResultsOutput,
    permission_scope=PermissionScope.tier_a,
)
async def export_results(
    inp: ExportResultsInput, ctx: AgentContext
) -> ExportResultsOutput:
    raw = ctx.sandbox.read_file(inp.source_artifact)
    records = json.loads(raw.content)
    n_records = len(records) if isinstance(records, list) else 1

    if inp.format == "csv":
        filename = inp.filename or "results.csv"
        output_path = f"artifacts/{filename}"
        if isinstance(records, list) and records:
            # Flatten to CSV
            buf = io.StringIO()
            flat = _flatten_records(records)
            writer = csv.DictWriter(buf, fieldnames=list(flat[0].keys()))
            writer.writeheader()
            writer.writerows(flat)
            ctx.sandbox.write_file(output_path, buf.getvalue())
        else:
            ctx.sandbox.write_file(output_path, json.dumps(records))
    else:
        filename = inp.filename or "results.json"
        output_path = f"artifacts/{filename}"
        ctx.sandbox.write_file(output_path, json.dumps(records, indent=2))

    return ExportResultsOutput(
        artifact_path=output_path, n_records=n_records, format=inp.format
    )


def _flatten_records(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Flatten nested dicts to dot-notation keys for CSV export."""
    flat_list = []
    for rec in records:
        flat: Dict[str, Any] = {}
        _flatten(rec, "", flat)
        flat_list.append(flat)
    return flat_list


def _flatten(d: Any, prefix: str, out: Dict[str, Any]) -> None:
    if isinstance(d, dict):
        for k, v in d.items():
            key = f"{prefix}{k}" if not prefix else f"{prefix}.{k}"
            _flatten(v, key, out)
    elif isinstance(d, list):
        out[prefix] = json.dumps(d)
    else:
        out[prefix] = d
