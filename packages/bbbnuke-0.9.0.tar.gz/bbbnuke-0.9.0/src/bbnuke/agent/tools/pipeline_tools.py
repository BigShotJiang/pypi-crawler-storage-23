"""Pipeline tools — wrap existing bbnuke.modules functions for agent use.

Pattern: read artifact from sandbox → compute → write result artifact → return summary.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from bbnuke.agent.state import AgentContext
from bbnuke.agent.tools.registry import PermissionScope, register_tool

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Input / output schemas
# ---------------------------------------------------------------------------

class RunStandardizeInput(BaseModel):
    compounds_artifact: str = Field(
        default="artifacts/compounds_validated.json",
        description="Relative path to validated compounds JSON",
    )


class RunStandardizeOutput(BaseModel):
    artifact_path: str
    n_compounds: int
    n_failed: int


class RunPropertiesPkaInput(BaseModel):
    standardized_artifact: str = Field(
        default="artifacts/standardized.json",
        description="Relative path to standardized compounds JSON",
    )


class RunPropertiesPkaOutput(BaseModel):
    artifact_path: str
    n_compounds: int


class RunCnsMpoInput(BaseModel):
    props_pka_artifact: str = Field(
        default="artifacts/props_pka.json",
        description="Relative path to properties+pKa JSON",
    )
    mpo_cutoff: float = Field(default=3.0, description="Minimum CNS-MPO score to pass")


class RunCnsMpoOutput(BaseModel):
    artifact_path: str
    n_passed: int
    n_failed: int
    mean_score: float


class RunHeuristicInput(BaseModel):
    affinity_artifact: str = Field(
        default="artifacts/affinity.json",
        description="Relative path to affinity results JSON",
    )
    mpo_artifact: str = Field(
        default="artifacts/cns_mpo.json",
        description="Relative path to CNS-MPO results JSON",
    )


class RunHeuristicOutput(BaseModel):
    artifact_path: str
    n_results: int
    p_bbb_mean: float
    p_bbb_median: float


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------

@register_tool(
    name="run_standardize",
    description="Standardize SMILES for all compounds in workspace.",
    input_schema=RunStandardizeInput,
    output_schema=RunStandardizeOutput,
    permission_scope=PermissionScope.tier_a,
)
async def run_standardize(
    inp: RunStandardizeInput, ctx: AgentContext
) -> RunStandardizeOutput:
    from bbnuke.modules.standardize import standardize_smiles

    raw = ctx.sandbox.read_file(inp.compounds_artifact)
    compounds = json.loads(raw.content)

    results = []
    n_failed = 0
    for c in compounds:
        smiles = c["smiles"]
        cid = c["compound_id"]
        try:
            std = standardize_smiles(smiles)
            results.append({
                "compound_id": cid,
                "smiles_input": smiles,
                "smiles_standardized": std,
                "is_valid": True,
                "error": None,
            })
        except Exception as exc:
            n_failed += 1
            results.append({
                "compound_id": cid,
                "smiles_input": smiles,
                "smiles_standardized": "",
                "is_valid": False,
                "error": str(exc),
            })

    artifact_path = "artifacts/standardized.json"
    ctx.sandbox.write_file(artifact_path, json.dumps(results, indent=2))

    return RunStandardizeOutput(
        artifact_path=artifact_path,
        n_compounds=len(results),
        n_failed=n_failed,
    )


@register_tool(
    name="run_properties_pka",
    description="Compute physicochemical properties and placeholder pKa for standardized compounds.",
    input_schema=RunPropertiesPkaInput,
    output_schema=RunPropertiesPkaOutput,
    permission_scope=PermissionScope.tier_a,
)
async def run_properties_pka(
    inp: RunPropertiesPkaInput, ctx: AgentContext
) -> RunPropertiesPkaOutput:
    from bbnuke.modules.properties import compute_properties

    raw = ctx.sandbox.read_file(inp.standardized_artifact)
    compounds = json.loads(raw.content)

    results = []
    for c in compounds:
        if not c.get("is_valid", False):
            continue
        smiles = c["smiles_standardized"]
        try:
            props = compute_properties(smiles)
            results.append({
                "compound_id": c["compound_id"],
                "smiles_input": c["smiles_input"],
                "smiles_standardized": smiles,
                "properties": props.model_dump(),
                "pka": {
                    "acid_pkas": [],
                    "base_pkas": [],
                    "representative_pka": None,
                    "source": "placeholder",
                },
            })
        except Exception as exc:
            logger.warning("Properties failed for %s: %s", c["compound_id"], exc)

    artifact_path = "artifacts/props_pka.json"
    ctx.sandbox.write_file(artifact_path, json.dumps(results, indent=2))

    return RunPropertiesPkaOutput(
        artifact_path=artifact_path,
        n_compounds=len(results),
    )


@register_tool(
    name="run_cns_mpo",
    description="Compute CNS-MPO scores and filter compounds by cutoff.",
    input_schema=RunCnsMpoInput,
    output_schema=RunCnsMpoOutput,
    permission_scope=PermissionScope.tier_a,
)
async def run_cns_mpo(
    inp: RunCnsMpoInput, ctx: AgentContext
) -> RunCnsMpoOutput:
    from bbnuke.core.schemas import PropertyResult
    from bbnuke.modules.cns_mpo import compute_cns_mpo

    raw = ctx.sandbox.read_file(inp.props_pka_artifact)
    compounds = json.loads(raw.content)

    results = []
    scores = []
    for c in compounds:
        props = PropertyResult(**c["properties"])
        pka_data = c.get("pka", {})
        rep_pka = pka_data.get("representative_pka")
        acid_pkas = pka_data.get("acid_pkas", [])
        base_pkas = pka_data.get("base_pkas", [])

        mpo = compute_cns_mpo(
            props=props,
            pka=rep_pka,
            acid_pkas=acid_pkas or None,
            base_pkas=base_pkas or None,
        )
        passed = mpo.score >= inp.mpo_cutoff
        scores.append(mpo.score)
        results.append({
            **c,
            "cns_mpo": mpo.model_dump(),
            "passed_mpo_filter": passed,
        })

    artifact_path = "artifacts/cns_mpo.json"
    ctx.sandbox.write_file(artifact_path, json.dumps(results, indent=2))

    n_passed = sum(1 for r in results if r["passed_mpo_filter"])
    mean_score = sum(scores) / len(scores) if scores else 0.0

    # Update state counts
    state = ctx.state_manager.load()
    if state is not None:
        state.n_compounds_passed_mpo = n_passed
        ctx.state_manager.save(state)

    return RunCnsMpoOutput(
        artifact_path=artifact_path,
        n_passed=n_passed,
        n_failed=len(results) - n_passed,
        mean_score=round(mean_score, 3),
    )


@register_tool(
    name="run_heuristic",
    description="Compute BBB penetration probability (P_BBB) using heuristic confidence layer.",
    input_schema=RunHeuristicInput,
    output_schema=RunHeuristicOutput,
    permission_scope=PermissionScope.tier_a,
)
async def run_heuristic(
    inp: RunHeuristicInput, ctx: AgentContext
) -> RunHeuristicOutput:
    from bbnuke.core.schemas import AffinityScore, PropertyResult
    from bbnuke.modules.heuristic import compute_classifier_heuristic

    mpo_raw = ctx.sandbox.read_file(inp.mpo_artifact)
    mpo_compounds = json.loads(mpo_raw.content)

    # Build affinity map: compound_id → list of AffinityScore
    affinity_map: Dict[str, List[Any]] = {}
    try:
        aff_raw = ctx.sandbox.read_file(inp.affinity_artifact)
        aff_data = json.loads(aff_raw.content)
        if isinstance(aff_data, dict):
            # Format: {compound_id: [{protein_id, score_raw, score_norm, model}, ...]}
            for cid, scores in aff_data.items():
                affinity_map[cid] = [AffinityScore(**s) for s in scores]
        elif isinstance(aff_data, list):
            for entry in aff_data:
                cid = entry.get("compound_id", "")
                scores = entry.get("scores", [])
                affinity_map[cid] = [AffinityScore(**s) for s in scores]
    except FileNotFoundError:
        logger.info("No affinity artifact found; running heuristic without affinity data")

    results = []
    p_bbb_values = []
    for c in mpo_compounds:
        if not c.get("passed_mpo_filter", False):
            continue
        cid = c["compound_id"]
        props = PropertyResult(**c["properties"])
        aff_scores = affinity_map.get(cid)

        hr = compute_classifier_heuristic(properties=props, affinity_scores=aff_scores)
        p_bbb_values.append(hr.p_bbb)
        results.append({
            **c,
            "heuristic": hr.model_dump(),
            "p_bbb": hr.p_bbb,
        })

    artifact_path = "artifacts/heuristic.json"
    ctx.sandbox.write_file(artifact_path, json.dumps(results, indent=2))

    sorted_pbbb = sorted(p_bbb_values)
    n = len(sorted_pbbb)
    median = 0.0
    if n > 0:
        mid = n // 2
        median = sorted_pbbb[mid] if n % 2 else (sorted_pbbb[mid - 1] + sorted_pbbb[mid]) / 2
    mean = sum(p_bbb_values) / n if n > 0 else 0.0

    # Update state
    state = ctx.state_manager.load()
    if state is not None:
        state.n_compounds_final = n
        ctx.state_manager.save(state)

    return RunHeuristicOutput(
        artifact_path=artifact_path,
        n_results=n,
        p_bbb_mean=round(mean, 4),
        p_bbb_median=round(median, 4),
    )
