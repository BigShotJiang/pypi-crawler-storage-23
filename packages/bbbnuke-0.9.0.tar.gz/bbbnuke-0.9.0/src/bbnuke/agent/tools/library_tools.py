"""Library / data-source tools — stubs for future vendor integrations.

All tools have defined schemas but raise ``NotImplementedError`` in the body.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from bbnuke.agent.state import AgentContext
from bbnuke.agent.tools.registry import PermissionScope, register_tool


# ---------------------------------------------------------------------------
# ChEMBL
# ---------------------------------------------------------------------------

class ChemblSearchInput(BaseModel):
    query: str = Field(description="Free-text or target search query")
    max_results: int = Field(default=100, description="Max results to return")
    filters: Dict[str, Any] = Field(default_factory=dict, description="Optional filters")


class ChemblSearchOutput(BaseModel):
    n_results: int
    artifact_path: str


class ChemblFetchMoleculesInput(BaseModel):
    chembl_ids: List[str] = Field(description="ChEMBL molecule IDs to fetch")


class ChemblFetchMoleculesOutput(BaseModel):
    n_molecules: int
    artifact_path: str


# ---------------------------------------------------------------------------
# ZINC
# ---------------------------------------------------------------------------

class ZincFetchSubsetInput(BaseModel):
    subset: str = Field(description="ZINC subset name (e.g. 'lead-like', 'drug-like')")
    max_compounds: int = Field(default=1000)
    filters: Dict[str, Any] = Field(default_factory=dict)


class ZincFetchSubsetOutput(BaseModel):
    n_compounds: int
    artifact_path: str


# ---------------------------------------------------------------------------
# Enamine REAL Space
# ---------------------------------------------------------------------------

class EnamineRealspaceQueryInput(BaseModel):
    smarts: str = Field(description="SMARTS pattern for substructure query")
    max_results: int = Field(default=500)


class EnamineRealspaceQueryOutput(BaseModel):
    query_id: str
    status: str
    estimated_hits: int


class EnamineRealspaceDownloadInput(BaseModel):
    query_id: str = Field(description="Enamine query ID to download")


class EnamineRealspaceDownloadOutput(BaseModel):
    n_compounds: int
    artifact_path: str


# ---------------------------------------------------------------------------
# Tool registrations (all stubs)
# ---------------------------------------------------------------------------

@register_tool(
    name="chembl_search",
    description="Search ChEMBL database by query and filters.",
    input_schema=ChemblSearchInput,
    output_schema=ChemblSearchOutput,
    permission_scope=PermissionScope.tier_a,
)
async def chembl_search(inp: ChemblSearchInput, ctx: AgentContext) -> ChemblSearchOutput:
    raise NotImplementedError("ChEMBL search integration not yet implemented")


@register_tool(
    name="chembl_fetch_molecules",
    description="Fetch molecules from ChEMBL by IDs.",
    input_schema=ChemblFetchMoleculesInput,
    output_schema=ChemblFetchMoleculesOutput,
    permission_scope=PermissionScope.tier_a,
)
async def chembl_fetch_molecules(
    inp: ChemblFetchMoleculesInput, ctx: AgentContext
) -> ChemblFetchMoleculesOutput:
    raise NotImplementedError("ChEMBL molecule fetch not yet implemented")


@register_tool(
    name="zinc_fetch_subset",
    description="Fetch a subset of compounds from the ZINC database.",
    input_schema=ZincFetchSubsetInput,
    output_schema=ZincFetchSubsetOutput,
    permission_scope=PermissionScope.tier_a,
)
async def zinc_fetch_subset(
    inp: ZincFetchSubsetInput, ctx: AgentContext
) -> ZincFetchSubsetOutput:
    raise NotImplementedError("ZINC fetch not yet implemented")


@register_tool(
    name="enamine_realspace_query",
    description="Submit an Enamine REAL Space substructure query.",
    input_schema=EnamineRealspaceQueryInput,
    output_schema=EnamineRealspaceQueryOutput,
    permission_scope=PermissionScope.tier_b,
)
async def enamine_realspace_query(
    inp: EnamineRealspaceQueryInput, ctx: AgentContext
) -> EnamineRealspaceQueryOutput:
    raise NotImplementedError("Enamine REAL Space query not yet implemented")


@register_tool(
    name="enamine_realspace_download",
    description="Download results from a completed Enamine REAL Space query.",
    input_schema=EnamineRealspaceDownloadInput,
    output_schema=EnamineRealspaceDownloadOutput,
    permission_scope=PermissionScope.tier_b,
)
async def enamine_realspace_download(
    inp: EnamineRealspaceDownloadInput, ctx: AgentContext
) -> EnamineRealspaceDownloadOutput:
    raise NotImplementedError("Enamine REAL Space download not yet implemented")
