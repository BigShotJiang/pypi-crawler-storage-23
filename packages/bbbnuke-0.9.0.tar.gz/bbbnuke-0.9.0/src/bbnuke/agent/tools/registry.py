"""Tool registry — global singleton for agentic tool definitions.

Every tool has a name, schemas, permission scope, and handler function.
All tool invocations go through ``invoke()`` which validates, executes, and logs.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Type

from pydantic import BaseModel, ValidationError

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Permission scopes
# ---------------------------------------------------------------------------

class PermissionScope(str, Enum):
    """Access tier required to call a tool."""
    tier_a = "tier_a"       # bounded runs, no vendor APIs
    tier_b = "tier_b"       # large libraries, vendor APIs, GPU
    internal = "internal"   # framework-only, never exposed to agent


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ToolError(Exception):
    """Base for all tool-related errors."""


class ToolNotFoundError(ToolError):
    """Raised when a tool name is not in the registry."""


class PermissionDeniedError(ToolError):
    """Raised when the caller's tier cannot access the tool."""


class ToolValidationError(ToolError):
    """Raised when input fails Pydantic validation."""


class ToolExecutionError(ToolError):
    """Raised when the tool handler raises an unexpected error."""


# ---------------------------------------------------------------------------
# Tool definition
# ---------------------------------------------------------------------------

@dataclass
class ToolDefinition:
    """Metadata + handler for a single registered tool."""

    name: str
    description: str
    input_schema: Type[BaseModel]
    output_schema: Type[BaseModel]
    permission_scope: PermissionScope
    fn: Callable
    logging_enabled: bool = True
    timeout_seconds: Optional[int] = None


# ---------------------------------------------------------------------------
# Registry singleton
# ---------------------------------------------------------------------------

class ToolRegistry:
    """Global tool registry — register, look up, and invoke tools."""

    def __init__(self) -> None:
        self._tools: Dict[str, ToolDefinition] = {}

    def register(self, defn: ToolDefinition) -> None:
        """Register a tool definition. Raises ValueError on duplicate name."""
        if defn.name in self._tools:
            raise ValueError(f"Tool already registered: {defn.name}")
        self._tools[defn.name] = defn
        logger.debug("Registered tool: %s (scope=%s)", defn.name, defn.permission_scope.value)

    def get(self, name: str) -> Optional[ToolDefinition]:
        """Look up a tool by name."""
        return self._tools.get(name)

    def tools_for_scope(self, scope: PermissionScope) -> Dict[str, ToolDefinition]:
        """Return tools visible to the given scope.

        tier_a sees tier_a only; tier_b sees tier_a + tier_b.
        Internal tools are never returned.
        """
        allowed: Dict[str, ToolDefinition] = {}
        for name, defn in self._tools.items():
            if defn.permission_scope == PermissionScope.internal:
                continue
            if scope == PermissionScope.tier_a and defn.permission_scope == PermissionScope.tier_a:
                allowed[name] = defn
            elif scope == PermissionScope.tier_b and defn.permission_scope in (
                PermissionScope.tier_a,
                PermissionScope.tier_b,
            ):
                allowed[name] = defn
        return allowed

    def schema_for_llm(self, scope: PermissionScope) -> List[Dict[str, Any]]:
        """Return JSON-serializable tool schemas suitable for an LLM system prompt."""
        tools = self.tools_for_scope(scope)
        schemas: List[Dict[str, Any]] = []
        for defn in tools.values():
            schemas.append({
                "name": defn.name,
                "description": defn.description,
                "parameters": defn.input_schema.model_json_schema(),
            })
        return schemas

    @property
    def all_tools(self) -> Dict[str, ToolDefinition]:
        """All registered tools (including internal). For testing/introspection."""
        return dict(self._tools)

    def clear(self) -> None:
        """Remove all registrations. For testing only."""
        self._tools.clear()


# Module-level singleton
_registry = ToolRegistry()


def get_registry() -> ToolRegistry:
    """Return the global tool registry."""
    return _registry


# ---------------------------------------------------------------------------
# Registration decorator
# ---------------------------------------------------------------------------

def register_tool(
    name: str,
    description: str,
    input_schema: Type[BaseModel],
    output_schema: Type[BaseModel],
    permission_scope: PermissionScope,
    logging_enabled: bool = True,
    timeout_seconds: Optional[int] = None,
) -> Callable:
    """Decorator to register an async tool handler."""

    def decorator(fn: Callable) -> Callable:
        defn = ToolDefinition(
            name=name,
            description=description,
            input_schema=input_schema,
            output_schema=output_schema,
            permission_scope=permission_scope,
            fn=fn,
            logging_enabled=logging_enabled,
            timeout_seconds=timeout_seconds,
        )
        get_registry().register(defn)
        return fn

    return decorator


# ---------------------------------------------------------------------------
# Unified invocation
# ---------------------------------------------------------------------------

async def invoke(
    tool_name: str,
    raw_input: Dict[str, Any],
    ctx: Any,  # AgentContext — import avoided for circular deps
) -> BaseModel:
    """Invoke a tool by name.

    Steps:
      1. Look up in registry
      2. Check tier permission
      3. Validate input via Pydantic
      4. Execute handler
      5. Log via tool_logger
      6. Return validated output
    """
    from bbnuke.agent.permissions import check_permission
    from bbnuke.agent.tool_logger import log_tool_call

    registry = get_registry()
    defn = registry.get(tool_name)
    if defn is None:
        raise ToolNotFoundError(f"Unknown tool: {tool_name}")

    # Permission check
    check_permission(ctx.tier, defn.permission_scope)

    # Input validation
    try:
        validated_input = defn.input_schema(**raw_input)
    except ValidationError as exc:
        raise ToolValidationError(f"Input validation failed for {tool_name}: {exc}") from exc

    # Execute
    started_at = time.time()
    error_msg: Optional[str] = None
    output: Optional[BaseModel] = None
    try:
        result = defn.fn(validated_input, ctx)
        if asyncio.iscoroutine(result):
            output = await result
        else:
            output = result
    except (ToolError, ToolNotFoundError, PermissionDeniedError, ToolValidationError):
        raise
    except Exception as exc:
        error_msg = f"{type(exc).__name__}: {exc}"
        raise ToolExecutionError(f"Tool {tool_name} failed: {exc}") from exc
    finally:
        duration_ms = int((time.time() - started_at) * 1000)
        if defn.logging_enabled:
            await log_tool_call(
                ctx=ctx,
                tool_name=tool_name,
                input_data=raw_input,
                output_data=output,
                error=error_msg,
                started_at=started_at,
                duration_ms=duration_ms,
            )

    return output
