"""Compute/job tools — non-blocking GPU workloads via ARQ."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from bbnuke.agent.state import AgentContext
from bbnuke.agent.tools.registry import PermissionScope, register_tool


# ---------------------------------------------------------------------------
# Input / output schemas
# ---------------------------------------------------------------------------

class SubmitAffinityJobInput(BaseModel):
    ligands_artifact: str = Field(
        description="Relative path to compounds JSON artifact (MPO-passing)"
    )
    device: str = Field(default="cuda:0", description="GPU device")
    batch_size: int = Field(default=16, description="PSICHIC batch size")


class SubmitAffinityJobOutput(BaseModel):
    job_id: str
    status: str
    n_compounds: int


class PollJobInput(BaseModel):
    job_id: str = Field(description="ARQ job ID to poll")


class PollJobOutput(BaseModel):
    job_id: str
    status: str
    progress_pct: Optional[float] = None
    current_stage: Optional[str] = None
    error: Optional[str] = None


class FetchJobOutputsInput(BaseModel):
    job_id: str = Field(description="ARQ job ID whose results to fetch")
    output_artifact: str = Field(
        default="artifacts/affinity.json",
        description="Where to write results in workspace",
    )


class FetchJobOutputsOutput(BaseModel):
    artifact_path: str
    n_results: int
    status: str


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------

@register_tool(
    name="submit_affinity_job",
    description="Submit PSICHIC affinity screening job to GPU queue. Returns job_id.",
    input_schema=SubmitAffinityJobInput,
    output_schema=SubmitAffinityJobOutput,
    permission_scope=PermissionScope.tier_b,
)
async def submit_affinity_job(
    inp: SubmitAffinityJobInput, ctx: AgentContext
) -> SubmitAffinityJobOutput:
    import uuid

    from bbnuke.api.deps import get_arq_redis

    # Read compounds from artifact
    raw = ctx.sandbox.read_file(inp.ligands_artifact)
    compounds = json.loads(raw.content)

    # Filter to MPO-passing only
    passing = [c for c in compounds if c.get("passed_mpo_filter", True)]
    smiles_list = [c["smiles_standardized"] for c in passing]
    compound_ids = [c["compound_id"] for c in passing]

    job_id = f"agent_{ctx.run_id}_{uuid.uuid4().hex[:8]}"

    # Enqueue to ARQ GPU queue
    redis = await get_arq_redis()
    await redis.enqueue_job(
        "run_affinity",
        smiles_list=smiles_list,
        compound_ids=compound_ids,
        job_id=job_id,
        device=inp.device,
        batch_size=inp.batch_size,
        _queue_name="bbnuke:gpu",
    )

    return SubmitAffinityJobOutput(
        job_id=job_id,
        status="submitted",
        n_compounds=len(smiles_list),
    )


@register_tool(
    name="poll_job",
    description="Poll the progress of an ARQ job by ID.",
    input_schema=PollJobInput,
    output_schema=PollJobOutput,
    permission_scope=PermissionScope.tier_a,
)
async def poll_job(inp: PollJobInput, ctx: AgentContext) -> PollJobOutput:
    from bbnuke.api.deps import get_arq_redis

    try:
        redis = await get_arq_redis()
        pool = redis.pool if hasattr(redis, "pool") else redis
        raw = await pool.get(f"bbnuke:job:{inp.job_id}:progress")
        if raw is None:
            return PollJobOutput(job_id=inp.job_id, status="unknown")
        progress = json.loads(raw)
        return PollJobOutput(
            job_id=inp.job_id,
            status=progress.get("status", "unknown"),
            progress_pct=progress.get("pct"),
            current_stage=progress.get("current_stage"),
            error=progress.get("error"),
        )
    except Exception as exc:
        return PollJobOutput(
            job_id=inp.job_id, status="error", error=str(exc)
        )


@register_tool(
    name="fetch_job_outputs",
    description="Fetch completed job results and write to workspace artifact.",
    input_schema=FetchJobOutputsInput,
    output_schema=FetchJobOutputsOutput,
    permission_scope=PermissionScope.tier_a,
)
async def fetch_job_outputs(
    inp: FetchJobOutputsInput, ctx: AgentContext
) -> FetchJobOutputsOutput:
    from bbnuke.api.deps import get_arq_redis

    redis = await get_arq_redis()
    pool = redis.pool if hasattr(redis, "pool") else redis

    raw = await pool.get(f"bbnuke:job:{inp.job_id}:results")
    if raw is None:
        return FetchJobOutputsOutput(
            artifact_path="", n_results=0, status="not_found"
        )

    results = json.loads(raw)
    ctx.sandbox.write_file(inp.output_artifact, json.dumps(results, indent=2))

    n = len(results) if isinstance(results, list) else 1
    return FetchJobOutputsOutput(
        artifact_path=inp.output_artifact,
        n_results=n,
        status="fetched",
    )
