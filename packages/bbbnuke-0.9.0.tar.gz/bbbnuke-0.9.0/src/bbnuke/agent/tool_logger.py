"""Tool call logging — append records to state.json and (optionally) AuditLog DB."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from pydantic import BaseModel

from bbnuke.agent.state import AgentContext, ToolCallRecord

logger = logging.getLogger(__name__)


def _summarize(data: Any) -> Dict[str, Any]:
    """Build a privacy-safe summary: key names + value types only."""
    if data is None:
        return {}
    if isinstance(data, BaseModel):
        d = data.model_dump()
    elif isinstance(data, dict):
        d = data
    else:
        return {"_type": type(data).__name__}
    return {k: type(v).__name__ for k, v in d.items()}


async def log_tool_call(
    ctx: AgentContext,
    tool_name: str,
    input_data: Any,
    output_data: Any,
    error: Optional[str],
    started_at: float,
    duration_ms: int,
) -> None:
    """Log a tool call to state.json and (optionally) the AuditLog DB.

    Parameters
    ----------
    ctx : AgentContext
        Current run context.
    tool_name : str
        Name of the invoked tool.
    input_data : Any
        Raw input dict or Pydantic model.
    output_data : Any
        Output Pydantic model or None on error.
    error : str or None
        Error message if the tool failed.
    started_at : float
        ``time.time()`` when execution began.
    duration_ms : int
        Elapsed milliseconds.
    """
    record = ToolCallRecord(
        tool_name=tool_name,
        input_summary=_summarize(input_data),
        output_summary=_summarize(output_data),
        started_at=datetime.fromtimestamp(started_at, tz=timezone.utc).isoformat(),
        duration_ms=duration_ms,
        error=error,
    )

    # 1. Append to current step in state.json
    state = ctx.state_manager.load()
    if state is not None:
        current = state.current_step()
        if current is not None:
            current.tool_calls.append(record)
            ctx.state_manager.save(state)

    # 2. AuditLog DB (optional)
    if ctx.db_session is not None:
        try:
            from bbnuke.api.audit import log_audit

            await log_audit(
                db=ctx.db_session,
                action="tool_called",
                resource_type="agent_tool",
                resource_id=tool_name,
                org_id=ctx.org_id,
                detail={
                    "run_id": ctx.run_id,
                    "duration_ms": duration_ms,
                    "error": error,
                },
            )
        except Exception:
            logger.warning("Failed to write audit log for tool %s", tool_name, exc_info=True)
