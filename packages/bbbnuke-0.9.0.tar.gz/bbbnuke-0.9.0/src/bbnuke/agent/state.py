"""Run state models, fixed run graph, and persistence.

The run graph is a fixed sequence of steps that cannot be modified by the
agent.  ``RunState`` captures the progress of each step including tool calls,
artifacts, and errors.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from bbnuke.agent.workspace import WorkspaceSandbox

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class RunStepName(str, Enum):
    """Fixed sequence of pipeline steps."""
    ingest = "ingest"
    standardize = "standardize"
    props_pka = "props_pka"
    cns_mpo = "cns_mpo"
    filter_mpo = "filter_mpo"
    affinity = "affinity"
    heuristic = "heuristic"
    export = "export"


class StepStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    skipped = "skipped"


class TierName(str, Enum):
    tier_a = "tier_a"
    tier_b = "tier_b"


# Canonical step order
RUN_GRAPH: List[RunStepName] = list(RunStepName)


# ---------------------------------------------------------------------------
# State models
# ---------------------------------------------------------------------------

class ToolCallRecord(BaseModel):
    """Record of a single tool invocation within a step."""

    tool_name: str
    input_summary: Dict[str, Any] = Field(default_factory=dict)
    output_summary: Dict[str, Any] = Field(default_factory=dict)
    started_at: str
    duration_ms: int
    error: Optional[str] = None


class StepRecord(BaseModel):
    """State of a single pipeline step."""

    name: RunStepName
    status: StepStatus = StepStatus.pending
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    output_artifacts: Dict[str, str] = Field(default_factory=dict)
    tool_calls: List[ToolCallRecord] = Field(default_factory=list)
    error: Optional[str] = None
    retry_count: int = 0
    config_snapshot: Dict[str, Any] = Field(default_factory=dict)


class RunState(BaseModel):
    """Full state of a pipeline run."""

    run_id: str
    tier: TierName
    created_at: str
    updated_at: str
    org_id: Optional[str] = None
    steps: List[StepRecord] = Field(default_factory=list)
    pipeline_config: Dict[str, Any] = Field(default_factory=dict)
    n_compounds_input: int = 0
    n_compounds_passed_mpo: int = 0
    n_compounds_final: int = 0

    def current_step(self) -> Optional[StepRecord]:
        """Return the first step that is not completed/skipped."""
        for step in self.steps:
            if step.status not in (StepStatus.completed, StepStatus.skipped):
                return step
        return None

    def is_complete(self) -> bool:
        """True when every step is completed or skipped."""
        return all(
            s.status in (StepStatus.completed, StepStatus.skipped) for s in self.steps
        )

    def get_step(self, name: RunStepName) -> Optional[StepRecord]:
        """Look up a step by name."""
        for step in self.steps:
            if step.name == name:
                return step
        return None


# ---------------------------------------------------------------------------
# Persistence — atomic save via tmp + rename
# ---------------------------------------------------------------------------

class RunStateManager:
    """Load/save ``RunState`` as JSON in the workspace."""

    def __init__(self, sandbox: WorkspaceSandbox) -> None:
        self.sandbox = sandbox
        self._path = sandbox.root / "state.json"

    def load(self) -> Optional[RunState]:
        """Load state from disk, or ``None`` if not present."""
        if not self._path.exists():
            return None
        data = self._path.read_text(encoding="utf-8")
        return RunState.model_validate_json(data)

    def save(self, state: RunState) -> None:
        """Atomic save — write to temp file then rename."""
        state.updated_at = datetime.now(timezone.utc).isoformat()
        content = state.model_dump_json(indent=2)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(
            dir=str(self._path.parent), suffix=".tmp"
        )
        try:
            os.write(fd, content.encode("utf-8"))
            os.close(fd)
            os.replace(tmp_path, str(self._path))
        except BaseException:
            os.close(fd) if not os.get_inheritable(fd) else None
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise

    def load_or_create(
        self,
        run_id: str,
        tier: TierName,
        org_id: Optional[str] = None,
    ) -> RunState:
        """Load existing state or create a fresh one with all steps pending."""
        existing = self.load()
        if existing is not None:
            return existing
        now = datetime.now(timezone.utc).isoformat()
        state = RunState(
            run_id=run_id,
            tier=tier,
            created_at=now,
            updated_at=now,
            org_id=org_id,
            steps=[StepRecord(name=step) for step in RUN_GRAPH],
        )
        self.save(state)
        return state


# ---------------------------------------------------------------------------
# Agent context — passed to every tool call
# ---------------------------------------------------------------------------

class AgentContext(BaseModel):
    """Runtime context for tool execution.  Not serialized to disk."""

    run_id: str
    tier: TierName
    org_id: Optional[str] = None
    sandbox: WorkspaceSandbox
    state_manager: RunStateManager
    db_session: Optional[Any] = None

    model_config = {"arbitrary_types_allowed": True}
