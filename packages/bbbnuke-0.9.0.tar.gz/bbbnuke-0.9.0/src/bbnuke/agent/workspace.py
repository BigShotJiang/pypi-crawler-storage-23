"""Filesystem sandbox for agent runs.

Each run gets an isolated directory tree.  All file operations are
validated via ``Path.resolve()`` — any ``../`` escape raises
``WorkspaceSandboxError``.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class WorkspaceSandboxError(Exception):
    """Path escapes the workspace boundary."""


# ---------------------------------------------------------------------------
# Output models (used by workspace tools)
# ---------------------------------------------------------------------------

class WorkspaceInitOutput(BaseModel):
    run_id: str
    root: str
    created_dirs: List[str]


class FileInfo(BaseModel):
    path: str
    size_bytes: int
    modified: str


class WorkspaceListOutput(BaseModel):
    run_id: str
    files: List[FileInfo]


class WorkspaceReadOutput(BaseModel):
    path: str
    content: str
    size_bytes: int


class WorkspaceWriteOutput(BaseModel):
    path: str
    size_bytes: int


# ---------------------------------------------------------------------------
# Sandbox class
# ---------------------------------------------------------------------------

_MAX_READ_BYTES = 2 * 1024 * 1024  # 2 MB


class WorkspaceSandbox:
    """Isolated run directory with path-validated file operations."""

    SUBDIRS = ("input", "artifacts", "logs")

    def __init__(self, run_id: str, runs_dir: Optional[str] = None) -> None:
        self.run_id = run_id
        base = Path(runs_dir) if runs_dir else Path("runs")
        self.root = base / run_id
        self._root_resolved = self.root.resolve()

    # -- path safety ----------------------------------------------------------

    def _validate_path(self, relative: str) -> Path:
        """Resolve *relative* within the sandbox and reject escapes."""
        target = (self.root / relative).resolve()
        if not str(target).startswith(str(self._root_resolved)):
            raise WorkspaceSandboxError(
                f"Path escapes sandbox: {relative!r} resolves to {target}"
            )
        return target

    def resolve_path(self, relative: str) -> Path:
        """Public wrapper for internal pipeline calls that need an absolute path."""
        return self._validate_path(relative)

    # -- directory operations -------------------------------------------------

    def init(self) -> WorkspaceInitOutput:
        """Create the run directory tree.  Idempotent."""
        created: List[str] = []
        for sub in self.SUBDIRS:
            p = self.root / sub
            if not p.exists():
                p.mkdir(parents=True, exist_ok=True)
                created.append(sub)
        # Also ensure root itself is tracked
        if not (self.root / "state.json").exists():
            created.insert(0, str(self.root))
        return WorkspaceInitOutput(
            run_id=self.run_id,
            root=str(self.root),
            created_dirs=created,
        )

    # -- file operations ------------------------------------------------------

    def list_files(self) -> WorkspaceListOutput:
        """Recursive listing of all files in the workspace."""
        files: List[FileInfo] = []
        if not self.root.exists():
            return WorkspaceListOutput(run_id=self.run_id, files=files)
        for p in sorted(self.root.rglob("*")):
            if p.is_file():
                rel = str(p.relative_to(self.root))
                stat = p.stat()
                files.append(FileInfo(
                    path=rel,
                    size_bytes=stat.st_size,
                    modified=datetime.fromtimestamp(
                        stat.st_mtime, tz=timezone.utc
                    ).isoformat(),
                ))
        return WorkspaceListOutput(run_id=self.run_id, files=files)

    def read_file(self, relative: str) -> WorkspaceReadOutput:
        """Read file content (max 2 MB)."""
        target = self._validate_path(relative)
        if not target.exists():
            raise FileNotFoundError(f"File not found in workspace: {relative}")
        size = target.stat().st_size
        if size > _MAX_READ_BYTES:
            raise WorkspaceSandboxError(
                f"File too large ({size} bytes > {_MAX_READ_BYTES} limit): {relative}"
            )
        content = target.read_text(encoding="utf-8")
        return WorkspaceReadOutput(path=relative, content=content, size_bytes=size)

    def write_file(self, relative: str, content: str) -> WorkspaceWriteOutput:
        """Write text content to a file in the workspace."""
        target = self._validate_path(relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return WorkspaceWriteOutput(path=relative, size_bytes=len(content.encode("utf-8")))
