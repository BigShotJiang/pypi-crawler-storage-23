"""BBB-Nuke agentic tool-calling framework.

Public API:
    - ``AgentOrchestrator`` — run-graph executor
    - ``AgentContext`` — per-tool-call context
    - ``WorkspaceSandbox`` — path-validated file I/O
    - ``RunState`` / ``RunStateManager`` — state persistence
    - ``get_registry()`` / ``invoke()`` — tool registry + invocation
    - ``PermissionScope`` / ``TierName`` — access control enums
"""

from bbnuke.agent.orchestrator import AgentOrchestrator  # noqa: F401
from bbnuke.agent.permissions import (                   # noqa: F401
    TierLimits,
    check_permission,
    get_tier_limits,
)
from bbnuke.agent.state import (                         # noqa: F401
    AgentContext,
    RunState,
    RunStateManager,
    RunStepName,
    StepStatus,
    TierName,
)
from bbnuke.agent.tools.registry import (                # noqa: F401
    PermissionScope,
    get_registry,
    invoke,
)
from bbnuke.agent.workspace import WorkspaceSandbox      # noqa: F401
