"""Permission enforcement and tier limits for the agent framework."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel

from bbnuke.agent.state import TierName
from bbnuke.agent.tools.registry import PermissionScope, PermissionDeniedError


# ---------------------------------------------------------------------------
# Tier permission check
# ---------------------------------------------------------------------------

def check_permission(tier: TierName, required_scope: PermissionScope) -> None:
    """Raise ``PermissionDeniedError`` if *tier* cannot access *required_scope*.

    Rules:
      - tier_a → tier_a tools only
      - tier_b → tier_a + tier_b tools
      - internal → NEVER accessible to agent
    """
    if required_scope == PermissionScope.internal:
        raise PermissionDeniedError("Internal tools are not accessible to agents")

    if tier == TierName.tier_a and required_scope != PermissionScope.tier_a:
        raise PermissionDeniedError(
            f"Tier A cannot access {required_scope.value} tools"
        )
    # tier_b can access tier_a + tier_b — always allowed (non-internal)


# ---------------------------------------------------------------------------
# Tier limits
# ---------------------------------------------------------------------------

class TierLimits(BaseModel):
    """Resource limits enforced by the orchestrator for each tier."""

    max_compounds: int
    max_tool_calls: int
    max_retries_per_step: int
    step_timeout_seconds: int
    allow_vendor_tools: bool
    allow_gpu_jobs: bool
    max_concurrent_jobs: int


TIER_LIMITS = {
    TierName.tier_a: TierLimits(
        max_compounds=1000,
        max_tool_calls=50,
        max_retries_per_step=2,
        step_timeout_seconds=300,
        allow_vendor_tools=False,
        allow_gpu_jobs=False,
        max_concurrent_jobs=1,
    ),
    TierName.tier_b: TierLimits(
        max_compounds=100_000,
        max_tool_calls=500,
        max_retries_per_step=5,
        step_timeout_seconds=3600,
        allow_vendor_tools=True,
        allow_gpu_jobs=True,
        max_concurrent_jobs=4,
    ),
}


def get_tier_limits(tier: TierName) -> TierLimits:
    """Return the resource limits for a tier."""
    return TIER_LIMITS[tier]
