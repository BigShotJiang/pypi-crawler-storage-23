"""BBB-Nuke: Blood-brain barrier penetration screening pipeline."""

__version__ = "0.9.0"
