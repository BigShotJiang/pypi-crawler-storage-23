"""BBB-Nuke CLI entry point."""

from __future__ import annotations

import argparse
import json
import sys

import pandas as pd

from bbnuke.core.schemas import CompoundInput


def main() -> None:
    ap = argparse.ArgumentParser(
        prog="bbnuke",
        description="BBB-Nuke: Blood-brain barrier penetration screening pipeline",
    )
    sub = ap.add_subparsers(dest="command")

    # --- run command (pre-computed pKa / affinity) ---
    run_p = sub.add_parser("run", help="Run pipeline with pre-computed pKa and/or affinity CSVs")
    run_p.add_argument("--input", required=True, help="Input CSV with compound_id and smiles columns")
    run_p.add_argument("--output", required=True, help="Output file (.json or .csv)")
    run_p.add_argument("--smiles-col", default="smiles", help="SMILES column (default: smiles)")
    run_p.add_argument("--id-col", default="compound_id", help="Compound ID column (default: compound_id)")
    run_p.add_argument("--pka-csv", default=None, help="MolGpKa output CSV (compound, acid_pkas, base_pkas)")
    run_p.add_argument("--pka-id-col", default=None, help="ID column in pKa CSV (default: same as --id-col)")
    run_p.add_argument("--affinity-csv", default=None, help="PSICHIC screening_master.csv")
    run_p.add_argument("--score-col", default=None, help="Score column in affinity CSV (auto-detect if omitted)")
    run_p.add_argument("--weights-path", default=None, help="Path to protein weights Excel")
    run_p.add_argument("--format", choices=["json", "csv"], default="json", help="Output format (default: json)")

    # --- screen command (end-to-end with external tools) ---
    screen_p = sub.add_parser("screen", help="End-to-end screening: MolGpKa → CNS-MPO → PSICHIC → heuristic")
    screen_p.add_argument("--input", required=True, help="Input CSV with compound_id and smiles columns")
    screen_p.add_argument("--output", required=True, help="Output file (.json or .csv)")
    screen_p.add_argument("--smiles-col", default="smiles")
    screen_p.add_argument("--id-col", default="compound_id")
    screen_p.add_argument("--format", choices=["json", "csv"], default="json")
    screen_p.add_argument("--weights-path", default=None)
    # MolGpKa options
    screen_p.add_argument("--molgpka-src", default=None, help="Path to MolGpKa src/ dir (skip pKa if omitted)")
    screen_p.add_argument("--pka-output", default=None, help="Where to write pKa CSV (default: <outdir>/pka_predictions.csv)")
    # PSICHIC options
    screen_p.add_argument("--proteins-csv", default=None, help="Proteins CSV for PSICHIC (skip affinity if omitted)")
    screen_p.add_argument("--psichic-repo", default=None, help="Path to PSICHIC repo")
    screen_p.add_argument("--trained-model-path", default=None, help="PSICHIC pretrained weights path")
    screen_p.add_argument("--psichic-outdir", default=None, help="PSICHIC output dir (default: <outdir>/psichic_run/)")
    screen_p.add_argument("--device", default="cpu")
    screen_p.add_argument("--batch-size", type=int, default=16)

    # --- score-single command ---
    single_p = sub.add_parser("score-single", help="Score a single SMILES")
    single_p.add_argument("--smiles", required=True, help="SMILES string")
    single_p.add_argument("--name", default="query", help="Compound name/ID")

    args = ap.parse_args()

    if args.command == "run":
        _cmd_run(args)
    elif args.command == "screen":
        _cmd_screen(args)
    elif args.command == "score-single":
        _cmd_score_single(args)
    else:
        ap.print_help()
        sys.exit(1)


def _cmd_score_single(args: argparse.Namespace) -> None:
    from bbnuke.pipeline.runner import run_single

    compound = CompoundInput(compound_id=args.name, smiles=args.smiles)
    result = run_single(compound)
    print(result.model_dump_json(indent=2))


def _cmd_run(args: argparse.Namespace) -> None:
    from bbnuke.modules.affinity import read_screening_csv
    from bbnuke.modules.pka import read_pka_csv
    from bbnuke.pipeline.runner import run_batch

    df = pd.read_csv(args.input)
    _validate_cols(df, args.smiles_col, args.id_col)

    compounds = [
        CompoundInput(compound_id=str(row[args.id_col]), smiles=str(row[args.smiles_col]))
        for _, row in df.iterrows()
    ]

    # Load pKa via adapter
    pka_map = {}
    if args.pka_csv:
        pka_id = args.pka_id_col or args.id_col
        pka_map = read_pka_csv(args.pka_csv, id_col=pka_id)
        print(f"[pKa] Loaded representative pKa for {len(pka_map)} compounds")

    # Load affinity via adapter
    affinity_map = {}
    if args.affinity_csv:
        affinity_map = read_screening_csv(args.affinity_csv, score_col=args.score_col)
        print(f"[Affinity] Loaded scores for {len(affinity_map)} compounds")

    results = run_batch(compounds, pka_map=pka_map, affinity_map=affinity_map, weights_path=args.weights_path)
    _write_output(results, args.output, args.format)


def _cmd_screen(args: argparse.Namespace) -> None:
    """End-to-end screening: optionally run MolGpKa → CNS-MPO filter → optionally run PSICHIC → heuristic."""
    from pathlib import Path

    from bbnuke.modules.affinity import prepare_filtered_ligands_csv, run_psichic
    from bbnuke.modules.pka import read_pka_csv, run_molgpka
    from bbnuke.pipeline.runner import run_batch

    df = pd.read_csv(args.input)
    _validate_cols(df, args.smiles_col, args.id_col)

    compounds = [
        CompoundInput(compound_id=str(row[args.id_col]), smiles=str(row[args.smiles_col]))
        for _, row in df.iterrows()
    ]

    outdir = Path(args.output).parent
    outdir.mkdir(parents=True, exist_ok=True)

    # Step 1: pKa prediction (optional)
    pka_map = {}
    if args.molgpka_src:
        pka_out = args.pka_output or str(outdir / "pka_predictions.csv")
        pka_map = run_molgpka(
            input_csv=args.input,
            output_csv=pka_out,
            molgpka_src_dir=args.molgpka_src,
            smiles_col=args.smiles_col,
            name_col=args.id_col,
        )
        print(f"[pKa] Predicted pKa for {len(pka_map)} compounds")

    # Step 2: First pass — properties + CNS-MPO (no affinity yet)
    first_pass = run_batch(compounds, pka_map=pka_map, weights_path=args.weights_path)
    n_passed = sum(1 for r in first_pass if r.passed_mpo_filter)
    print(f"[MPO] {n_passed}/{len(first_pass)} compounds passed CNS-MPO filter (>= 3.0)")

    # Step 3: PSICHIC affinity (optional, only on filtered compounds)
    affinity_map = {}
    if args.proteins_csv and args.psichic_repo and args.trained_model_path:
        psichic_out = args.psichic_outdir or str(outdir / "psichic_run")
        filtered_csv = str(outdir / "filtered_ligands.csv")
        prepare_filtered_ligands_csv(first_pass, filtered_csv, smiles_col=args.smiles_col, id_col=args.id_col)

        if n_passed > 0:
            affinity_map = run_psichic(
                proteins_csv=args.proteins_csv,
                ligands_csv=filtered_csv,
                outdir=psichic_out,
                psichic_repo=args.psichic_repo,
                trained_model_path=args.trained_model_path,
                device=args.device,
                batch_size=args.batch_size,
            )
            print(f"[Affinity] Scored {len(affinity_map)} compounds against protein panel")
        else:
            print("[Affinity] Skipped — no compounds passed MPO filter")

    # Step 4: Final pass with affinity scores → heuristic
    results = run_batch(compounds, pka_map=pka_map, affinity_map=affinity_map, weights_path=args.weights_path)
    _write_output(results, args.output, args.format)


def _validate_cols(df: pd.DataFrame, smiles_col: str, id_col: str) -> None:
    if smiles_col not in df.columns:
        print(f"[ERROR] Column '{smiles_col}' not found. Available: {list(df.columns)}", file=sys.stderr)
        sys.exit(2)
    if id_col not in df.columns:
        print(f"[ERROR] Column '{id_col}' not found. Available: {list(df.columns)}", file=sys.stderr)
        sys.exit(2)


def _write_output(results: list, output_path: str, fmt: str) -> None:
    if fmt == "json":
        output = [r.model_dump() for r in results]
        with open(output_path, "w") as f:
            json.dump(output, f, indent=2)
    else:
        rows = []
        for r in results:
            row = {
                "compound_id": r.compound_id,
                "smiles_input": r.smiles_input,
                "smiles_standardized": r.smiles_standardized,
                "mw": r.properties.mw,
                "logp": r.properties.logp,
                "tpsa": r.properties.tpsa,
                "hbd": r.properties.hbd,
                "hba": r.properties.hba,
                "cns_mpo": r.cns_mpo.score,
                "pka_used": r.cns_mpo.pka_used,
                "pka_source": r.cns_mpo.pka_source,
                "passed_mpo_filter": r.passed_mpo_filter,
                "p_bbb": r.heuristic.p_bbb if r.heuristic else None,
            }
            # Flatten affinity scores
            for aff in r.affinity_scores:
                row[f"affinity_{aff.protein_id}"] = aff.score_norm
            rows.append(row)
        pd.DataFrame(rows).to_csv(output_path, index=False)

    n_passed = sum(1 for r in results if r.passed_mpo_filter)
    print(f"[OK] Processed {len(results)} compounds, {n_passed} passed MPO filter")
    print(f"[OK] Results written to {output_path}")


if __name__ == "__main__":
    main()
