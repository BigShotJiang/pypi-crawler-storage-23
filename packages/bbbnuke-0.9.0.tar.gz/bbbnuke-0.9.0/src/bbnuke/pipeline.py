from pathlib import Path
from functools import cache
from bbnuke.standardizer import Standardizer
from src.bbnuke.prop_predictor import PropPredictor
from bbnuke.optimizer import Optimizer
from bbnuke.bb_profiler import BBProfiler


class Pipeline:
    def __init__(self, smiles: str | list[str]):
        self.smiles = smiles

    def _optimize_molecule(self) -> str | list[str]:
        """Optimize input molecule(s) using the optimizer."""
        # Currently, optimization is not implemented in the MVP release.
        pass

    def _standardize_molecule(self):
        """Standardize the molecule using the standardizer."""
        self.standardizer = Standardizer(self.smiles)
        self.smiles = self.standardizer.standardize()

    def _get_physicochemical_properties(self):
        """Get physicochemical properties using the predictor."""
        self.predictor = PropPredictor(self.smiles)
        self.properties = self.predictor.predict()

    def _profile_bbb_penetration(self, properties: dict):
        """Profile BBB penetration using the BBB profiler."""
        self.profiler = BBProfiler(self.smiles, self.properties)
        self.profiler.get_profile()
        self.profile = self.profiler.profile
        self.classification = self.profiler.classify()

    def run_pipeline(self):
        """Run the complete pipeline."""
        self._standardize_molecule()
        self._get_physicochemical_properties()
        self._profile_bbb_penetration(self.properties)
        return {
            "standardized_smiles": self.smiles,
            "properties": self.properties,
            "bbb_profile": self.profile,
            "classification": self.classification,
        }
