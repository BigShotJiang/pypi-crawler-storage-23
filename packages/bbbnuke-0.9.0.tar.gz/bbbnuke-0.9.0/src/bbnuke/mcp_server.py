"""BBB-Nuke MCP Server — expose the pipeline as tool calls for Claude.

Supports two transports:
  - stdio:            For local Claude Code / Claude Desktop
  - streamable-http:  For remote access at https://mcp.attentionlab.ai/mcp

Usage:
  # Local (stdio)
  python -m bbnuke.mcp_server

  # Remote (HTTP)
  python -m bbnuke.mcp_server --http --port 8080
"""

from __future__ import annotations

import sys
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Server instance
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "bbnuke",
    instructions=(
        "BBB-Nuke: Blood-brain barrier penetration screening pipeline. "
        "Score small molecules for BBB permeability using physicochemical "
        "properties, CNS-MPO scoring, PSICHIC protein-ligand affinity "
        "(65 BBB target proteins), and a heuristic confidence layer. "
        "Use score_compound for quick scoring or score_with_affinity for "
        "full pipeline with pre-computed PSICHIC binding data (599 compounds)."
    ),
)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def score_compound(
    smiles: str,
    compound_id: str = "query",
) -> dict:
    """Score a molecule for blood-brain barrier penetration (CPU-only, no affinity).

    Runs: Standardize → Properties → pKa → CNS-MPO → Heuristic → P_BBB.
    Returns P_BBB (0-1), CNS-MPO score (0-6), physicochemical properties,
    and full heuristic diagnostics.

    Args:
        smiles: SMILES string of the molecule to score.
        compound_id: Optional identifier for the compound.
    """
    from bbnuke.core.schemas import CompoundInput
    from bbnuke.pipeline.runner import run_single

    compound = CompoundInput(compound_id=compound_id, smiles=smiles)
    result = run_single(compound, run_efflux=False)

    return _format_result(result)


@mcp.tool()
def score_with_affinity(
    smiles: str,
    compound_id: str = "query",
) -> dict:
    """Score a molecule with PSICHIC protein-ligand affinity data.

    Looks up pre-computed PSICHIC screening results (599 BBB+ compounds,
    65 proteins). If the compound is in the dataset, returns full scoring
    with protein binding contributions and efflux veto check. If not found,
    falls back to CPU-only scoring.

    Args:
        smiles: SMILES string of the molecule to score.
        compound_id: Optional identifier for the compound.
    """
    from bbnuke.api.affinity_cache import lookup_affinity
    from bbnuke.core.schemas import CompoundInput
    from bbnuke.modules.standardize import standardize_smiles
    from bbnuke.pipeline.runner import run_single

    compound = CompoundInput(compound_id=compound_id, smiles=smiles)

    # Try to look up pre-computed affinity data
    std_smiles = standardize_smiles(smiles)
    affinity_scores, pka_data, matched_id = lookup_affinity(std_smiles)

    # If pre-computed data found, use it (run_efflux=False since we have full data)
    # If not found, run_efflux=True to do live efflux screening
    result = run_single(
        compound,
        pka_data=pka_data,
        affinity_scores=affinity_scores,
        run_efflux=(affinity_scores is None),
    )

    output = _format_result(result)
    if matched_id:
        output["matched_compound"] = matched_id
        output["affinity_source"] = "pre-computed PSICHIC (BBB+ dataset, 65 proteins)"
    elif result.affinity and result.affinity.scores:
        output["matched_compound"] = None
        output["affinity_source"] = "live PSICHIC inference (9 efflux proteins)"
    else:
        output["matched_compound"] = None
        output["affinity_source"] = "none — PSICHIC not available"

    return output


@mcp.tool()
def get_pipeline_info() -> dict:
    """Get BBB-Nuke pipeline version, hyperparameters, and capabilities.

    Returns the current version, scoring model parameters, and
    information about available features.
    """
    from bbnuke import __version__
    from bbnuke.api.affinity_cache import get_known_compound_count
    from bbnuke.core.constants import (
        EFFLUX_VETO_THRESHOLD,
        LOGISTIC_K,
        MPO_FILTER_CUTOFF,
        MPO_GAIN_COEFF,
    )

    try:
        n_affinity = get_known_compound_count()
    except Exception:
        n_affinity = 0

    from bbnuke.modules.efflux import _psichic_available

    return {
        "pipeline_version": __version__,
        "hyperparameters": {
            "efflux_veto_threshold": EFFLUX_VETO_THRESHOLD,
            "mpo_filter_cutoff": MPO_FILTER_CUTOFF,
        },
        "capabilities": {
            "cpu_scoring": True,
            "classifier": "GradientBoosting (10 RDKit descriptors, F1=0.903 CV)",
            "affinity_lookup": n_affinity > 0,
            "affinity_compounds": n_affinity,
            "affinity_proteins": 65,
            "affinity_model": "PSICHIC",
            "live_efflux_screening": _psichic_available(),
            "efflux_proteins": 9,
        },
        "scoring_formula": (
            "P_BBB = GradientBoosting.predict_proba(10 RDKit descriptors)\n"
            "Efflux veto: P_BBB = 0 if any of 9 efflux proteins exceeds its binding threshold\n"
            "Efflux proteins: ABCB1, ABCG2, MDR1, MRP1-5, MATE1, OAT3"
        ),
    }


@mcp.tool()
def explain_score(
    smiles: str,
) -> dict:
    """Get a detailed human-readable explanation of a molecule's BBB score.

    Breaks down each pipeline stage, explains why the compound passed or
    failed each checkpoint, and highlights the key factors driving the
    final P_BBB score.

    Args:
        smiles: SMILES string of the molecule to explain.
    """
    from bbnuke.api.affinity_cache import lookup_affinity
    from bbnuke.core.schemas import CompoundInput
    from bbnuke.modules.standardize import standardize_smiles
    from bbnuke.pipeline.runner import run_single

    compound = CompoundInput(compound_id="query", smiles=smiles)

    std_smiles = standardize_smiles(smiles)
    affinity_scores, pka_data, matched_id = lookup_affinity(std_smiles)

    result = run_single(
        compound,
        pka_data=pka_data,
        affinity_scores=affinity_scores,
        run_efflux=(affinity_scores is None),
    )

    explanation = []
    explanation.append(f"Molecule: {result.smiles_standardized}")
    explanation.append("")

    # Properties
    p = result.properties
    explanation.append("1. PHYSICOCHEMICAL PROPERTIES")
    explanation.append(f"   MW={p.mw:.1f} Da, LogP={p.logp:.2f}, TPSA={p.tpsa:.1f}, HBD={p.hbd}, HBA={p.hba}")

    # CNS-MPO
    mpo = result.cns_mpo
    explanation.append("")
    explanation.append(f"2. CNS-MPO SCORE: {mpo.score:.2f}/6.0 {'PASS' if mpo.passed_filter else 'FAIL'}")
    s = mpo.subscores
    explanation.append(f"   Subscores: MW={s.mw:.2f} LogP={s.logp:.2f} TPSA={s.tpsa:.2f} HBD={s.hbd:.2f} pKa={s.pka:.2f} cLogD={s.clogd:.2f}")
    if not mpo.passed_filter:
        explanation.append(f"   BLOCKED: CNS-MPO {mpo.score:.2f} < 3.0 cutoff. P_BBB = 0.")

    # Affinity
    explanation.append("")
    if result.affinity and result.affinity.scores:
        n_aff = len(result.affinity.scores)
        source = "pre-computed, 65 proteins" if matched_id else "live efflux screen, 9 proteins"
        explanation.append(f"3. PROTEIN AFFINITY ({n_aff} proteins, source: PSICHIC {source})")
        top = sorted(result.affinity.scores, key=lambda x: -x.score_norm)[:5]
        for s in top:
            explanation.append(f"   {s.protein_id}: {s.score_norm:.3f}")
    else:
        explanation.append("3. PROTEIN AFFINITY: No data available (PSICHIC not installed)")

    # Heuristic
    explanation.append("")
    if result.heuristic:
        h = result.heuristic
        d = h.diagnostics
        explanation.append(f"4. BBB PENETRATION: P_BBB = {h.p_bbb:.4f}")
        if d.veto:
            explanation.append(f"   VETOED by efflux protein {d.veto_protein} (binding prob {d.veto_prob:.3f})")
        else:
            explanation.append(f"   S_bind={d.score_bind:.2f}, S_mpo={d.score_mpo:.2f}, S_total={d.score_total:.2f}")
            active = [c for c in d.contributions if abs(c.weighted_contribution) > 0.01]
            if active:
                explanation.append(f"   Active protein contributions: {len(active)}")
                for c in sorted(active, key=lambda x: -abs(x.weighted_contribution))[:5]:
                    sign = "+" if c.weighted_contribution > 0 else ""
                    explanation.append(
                        f"     {c.canonical_id}: {c.category} w={c.weight:+.0f} "
                        f"p={c.binding_prob:.3f} → {sign}{c.weighted_contribution:.3f}"
                    )
    else:
        explanation.append("4. BBB PENETRATION: Not computed (failed MPO filter)")

    return {
        "explanation": "\n".join(explanation),
        "p_bbb": result.heuristic.p_bbb if result.heuristic else 0.0,
        "passed_mpo": result.passed_mpo_filter,
        "has_affinity": result.affinity is not None and len(result.affinity.scores) > 0,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _format_result(result) -> dict:
    """Format a PipelineResult into a clean dict for MCP output."""
    output: Dict[str, Any] = {
        "compound_id": result.compound_id,
        "smiles_input": result.smiles_input,
        "smiles_standardized": result.smiles_standardized,
        "properties": {
            "mw": result.properties.mw,
            "logp": result.properties.logp,
            "tpsa": result.properties.tpsa,
            "hbd": result.properties.hbd,
            "hba": result.properties.hba,
        },
        "cns_mpo": {
            "score": result.cns_mpo.score,
            "passed_filter": result.cns_mpo.passed_filter,
            "subscores": result.cns_mpo.subscores.model_dump(),
        },
        "passed_mpo_filter": result.passed_mpo_filter,
    }

    if result.affinity and result.affinity.scores:
        output["affinity"] = {
            "model": result.affinity.model.value,
            "n_proteins": len(result.affinity.scores),
            "top_5": [
                {"protein": s.protein_id, "score": round(s.score_norm, 4)}
                for s in sorted(result.affinity.scores, key=lambda x: -x.score_norm)[:5]
            ],
        }
    else:
        output["affinity"] = None

    if result.heuristic:
        d = result.heuristic.diagnostics
        output["heuristic"] = {
            "p_bbb": result.heuristic.p_bbb,
            "reason": d.reason,
            "veto": d.veto,
            "veto_protein": d.veto_protein,
            "score_bind": d.score_bind,
            "score_mpo": d.score_mpo,
            "score_total": d.score_total,
        }
    else:
        output["heuristic"] = None

    return output


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    import argparse

    parser = argparse.ArgumentParser(description="BBB-Nuke MCP Server")
    parser.add_argument("--http", action="store_true", help="Run as HTTP server")
    parser.add_argument("--host", default="0.0.0.0", help="HTTP host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8080, help="HTTP port (default: 8080)")
    parser.add_argument("--path", default="/mcp", help="HTTP path (default: /mcp)")
    args = parser.parse_args()

    if args.http:
        # Host/port are set on the FastMCP instance
        mcp.settings.host = args.host
        mcp.settings.port = args.port
        mcp.settings.streamable_http_path = args.path
        mcp.run(transport="streamable-http")
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
