"""CPU worker — handles standardize, properties, pKa, CNS-MPO, heuristic.

Runs as an ARQ worker process. Tasks are enqueued by the orchestrator
or directly by the API for small jobs.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from arq import ArqRedis

from bbnuke.core.schemas import CompoundInput, PipelineConfig
from bbnuke.pipeline.runner import run_batch, run_single

logger = logging.getLogger(__name__)


async def score_single(
    ctx: Dict[str, Any],
    smiles: str,
    compound_id: str = "query",
    config_dict: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Score a single compound (CPU pipeline only).

    Returns the PipelineResult as a dict.
    """
    compound = CompoundInput(compound_id=compound_id, smiles=smiles)
    config = PipelineConfig(**(config_dict or {}))

    result = run_single(compound, weights_path=config.weights_path)
    return result.model_dump(mode="json")


async def score_batch_chunk(
    ctx: Dict[str, Any],
    compounds_data: List[Dict[str, str]],
    job_id: str,
    chunk_index: int,
    config_dict: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Score a chunk of compounds through the CPU pipeline.

    Called by the orchestrator for each chunk of a batch job.

    Args:
        compounds_data: List of {"compound_id": ..., "smiles": ...}
        job_id: Parent job ID for progress tracking
        chunk_index: Which chunk this is (for ordering)
        config_dict: PipelineConfig overrides

    Returns:
        Dict with chunk_index and list of PipelineResult dicts.
    """
    config = PipelineConfig(**(config_dict or {}))
    compounds = [CompoundInput(**c) for c in compounds_data]

    logger.info("Job %s chunk %d: scoring %d compounds", job_id, chunk_index, len(compounds))

    results = run_batch(compounds, weights_path=config.weights_path)

    return {
        "chunk_index": chunk_index,
        "job_id": job_id,
        "results": [r.model_dump(mode="json") for r in results],
    }


# ---------------------------------------------------------------------------
# ARQ worker class config
# ---------------------------------------------------------------------------

class CpuWorkerSettings:
    """ARQ worker settings for CPU tasks."""

    functions = [score_single, score_batch_chunk]
    queue_name = "bbnuke:cpu"
    max_jobs = 4

    # Connection set at startup from env
    redis_settings = None  # Overridden by create_worker_settings()


def create_worker_settings(redis_url: str = "redis://localhost:6379") -> type:
    """Create ARQ WorkerSettings with the given Redis URL."""
    from arq.connections import RedisSettings

    # Parse redis://host:port/db
    parts = redis_url.replace("redis://", "").split("/")
    host_port = parts[0].split(":")
    host = host_port[0] or "localhost"
    port = int(host_port[1]) if len(host_port) > 1 else 6379
    db = int(parts[1]) if len(parts) > 1 and parts[1] else 0

    class Settings(CpuWorkerSettings):
        redis_settings = RedisSettings(host=host, port=port, database=db)

    return Settings
