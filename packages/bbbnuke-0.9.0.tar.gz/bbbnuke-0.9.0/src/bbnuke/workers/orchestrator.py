"""Batch job orchestrator.

Coordinates the multi-phase batch pipeline:
  Phase 1 [cpu]: standardize + properties + pKa + CNS-MPO (chunked)
  Phase 2 [orchestrator]: collect, identify compounds passing MPO
  Phase 3 [gpu]: PSICHIC affinity for passing compounds (if requested)
  Phase 4 [cpu]: heuristic scoring with affinity data
  Phase 5 [orchestrator]: merge results → DB

For Sprint 2 MVP, phases 3-4 are optional (run_affinity=False skips GPU).
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from arq import ArqRedis

logger = logging.getLogger(__name__)

CHUNK_SIZE = 50


async def run_batch_job(
    ctx: Dict[str, Any],
    job_id: str,
    compounds_data: List[Dict[str, str]],
    run_affinity: bool = False,
    config_dict: Optional[Dict[str, Any]] = None,
    callback_url: Optional[str] = None,
) -> Dict[str, Any]:
    """Orchestrate a full batch scoring job.

    This is the top-level ARQ task that coordinates CPU and GPU workers.

    Args:
        job_id: Unique job ID (matches DB record)
        compounds_data: List of {"compound_id": ..., "smiles": ...}
        run_affinity: Whether to run PSICHIC (requires GPU worker)
        config_dict: PipelineConfig overrides
        callback_url: Webhook URL to POST results to on completion

    Returns:
        Dict with job_id, status, and summary.
    """
    redis: ArqRedis = ctx["redis"]
    total = len(compounds_data)

    # -- Update job status ---------------------------------------------------
    await _update_job_progress(redis, job_id, "running", "cpu_scoring", 0, total)

    # -- Phase 1: CPU scoring in chunks --------------------------------------
    chunks = [
        compounds_data[i : i + CHUNK_SIZE]
        for i in range(0, total, CHUNK_SIZE)
    ]

    all_results: List[Dict[str, Any]] = []
    completed = 0

    for idx, chunk in enumerate(chunks):
        # Enqueue to CPU worker and wait for result
        cpu_job = await redis.enqueue_job(
            "score_batch_chunk",
            chunk,
            job_id,
            idx,
            config_dict,
            _queue_name="bbnuke:cpu",
        )

        if cpu_job is None:
            logger.error("Failed to enqueue CPU chunk %d for job %s", idx, job_id)
            continue

        # Wait for chunk to complete
        chunk_result = await cpu_job.result(timeout=300)

        if chunk_result and "results" in chunk_result:
            all_results.extend(chunk_result["results"])
            completed += len(chunk_result["results"])
            await _update_job_progress(
                redis, job_id, "running", "cpu_scoring", completed, total
            )

    # -- Phase 2: Filter passing compounds -----------------------------------
    passing = [r for r in all_results if r.get("passed_mpo_filter", False)]
    logger.info("Job %s: %d/%d passed MPO filter", job_id, len(passing), total)

    # -- Phase 3: GPU affinity (if requested) --------------------------------
    if run_affinity and passing:
        await _update_job_progress(redis, job_id, "running", "affinity", completed, total)
        # GPU affinity would be enqueued here
        # For Sprint 2 MVP, this is a placeholder
        logger.info("Job %s: affinity scoring not yet wired (Sprint 2 MVP)", job_id)

    # -- Phase 5: Finalize ---------------------------------------------------
    await _update_job_progress(redis, job_id, "completed", "done", total, total)

    summary = {
        "job_id": job_id,
        "status": "completed",
        "total_compounds": total,
        "completed_compounds": len(all_results),
        "passed_mpo": len(passing),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    # Store results in Redis for retrieval (TTL 24h)
    import json
    await redis.set(
        f"bbnuke:job:{job_id}:results",
        json.dumps(all_results),
        ex=86400,
    )
    await redis.set(
        f"bbnuke:job:{job_id}:summary",
        json.dumps(summary),
        ex=86400,
    )

    # Webhook callback (fire and forget)
    if callback_url:
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                await client.post(callback_url, json=summary, timeout=10)
        except Exception as e:
            logger.warning("Callback to %s failed: %s", callback_url, e)

    return summary


async def _update_job_progress(
    redis: ArqRedis,
    job_id: str,
    status: str,
    stage: str,
    completed: int,
    total: int,
) -> None:
    """Update job progress in Redis (polled by GET /v1/batch/{job_id})."""
    import json

    progress = {
        "status": status,
        "current_stage": stage,
        "completed_compounds": completed,
        "total_compounds": total,
        "pct": round(completed / total * 100, 1) if total > 0 else 0.0,
    }
    await redis.set(f"bbnuke:job:{job_id}:progress", json.dumps(progress), ex=86400)


# ---------------------------------------------------------------------------
# ARQ worker class config
# ---------------------------------------------------------------------------

class OrchestratorSettings:
    """ARQ worker settings for orchestrator tasks."""

    functions = [run_batch_job]
    queue_name = "bbnuke:orchestrator"
    max_jobs = 2
