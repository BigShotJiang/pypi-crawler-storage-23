"""GPU worker — handles PSICHIC affinity inference.

Runs as an ARQ worker on a GPU-equipped node. One worker per GPU.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


async def run_affinity(
    ctx: Dict[str, Any],
    smiles_list: List[str],
    compound_ids: List[str],
    job_id: str,
    psichic_repo: Optional[str] = None,
    trained_model_path: Optional[str] = None,
    device: str = "cuda:0",
    batch_size: int = 16,
) -> Dict[str, Any]:
    """Run PSICHIC affinity inference for a list of compounds.

    This invokes the PSICHIC subprocess adapter from bbnuke.modules.affinity.

    Args:
        smiles_list: SMILES strings to score
        compound_ids: Corresponding compound IDs
        job_id: Parent job ID
        psichic_repo: Path to PSICHIC repo
        trained_model_path: Path to trained model weights
        device: CUDA device
        batch_size: Inference batch size

    Returns:
        Dict with job_id and affinity_map {compound_id: [AffinityScore dicts]}
    """
    # Import here to avoid loading torch on CPU workers
    from bbnuke.modules.affinity import run_psichic

    logger.info("Job %s: running PSICHIC on %d compounds (device=%s)", job_id, len(smiles_list), device)

    if not psichic_repo or not trained_model_path:
        logger.warning("PSICHIC paths not configured; returning empty affinity map")
        return {"job_id": job_id, "affinity_map": {}}

    # run_psichic returns Dict[str, List[AffinityScore]]
    affinity_map = run_psichic(
        smiles_list=smiles_list,
        compound_ids=compound_ids,
        psichic_repo=psichic_repo,
        trained_model_path=trained_model_path,
        device=device,
        batch_size=batch_size,
    )

    # Serialize AffinityScore objects to dicts
    serialized = {}
    for cid, scores in affinity_map.items():
        serialized[cid] = [s.model_dump(mode="json") for s in scores]

    return {"job_id": job_id, "affinity_map": serialized}


# ---------------------------------------------------------------------------
# ARQ worker class config
# ---------------------------------------------------------------------------

class GpuWorkerSettings:
    """ARQ worker settings for GPU tasks."""

    functions = [run_affinity]
    queue_name = "bbnuke:gpu"
    max_jobs = 1  # One job per GPU at a time
