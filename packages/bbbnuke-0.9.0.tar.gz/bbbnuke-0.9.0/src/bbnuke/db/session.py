"""Async database session factory.

Supports PostgreSQL (production) and SQLite (development/testing).
Connection string configured via BBNUKE_DATABASE_URL env var.
"""

from __future__ import annotations

import os
from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from bbnuke.db.models import Base

# Default to async SQLite for local dev (no Postgres needed)
DATABASE_URL = os.getenv(
    "BBNUKE_DATABASE_URL",
    "sqlite+aiosqlite:///bbnuke.db",
)

engine = create_async_engine(DATABASE_URL, echo=False)
async_session_factory = async_sessionmaker(engine, expire_on_commit=False)


async def init_db() -> None:
    """Create all tables. For dev/testing; use Alembic in production."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency: yield an async DB session."""
    async with async_session_factory() as session:
        yield session
