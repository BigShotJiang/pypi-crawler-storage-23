"""Tests for the MolGpKa pKa adapter."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from bbnuke.modules.pka import read_pka_csv, select_representative_pka


# --- Representative pKa selection ---

def test_select_basic_pka_max():
    """Max basic pKa should be selected when base_pkas present."""
    result = select_representative_pka("", "5.667;6.785;4.657")
    assert result == pytest.approx(6.785)


def test_select_acidic_pka_min():
    """Min acidic pKa when no basic pKa available."""
    result = select_representative_pka("3.456;7.890", "")
    assert result == pytest.approx(3.456)


def test_select_basic_over_acidic():
    """Basic pKa takes priority over acidic."""
    result = select_representative_pka("3.0;4.0", "8.0;9.0")
    assert result == pytest.approx(9.0)  # max basic


def test_select_empty():
    """None when no pKa data."""
    assert select_representative_pka("", "") is None


def test_select_nan():
    """None for nan strings."""
    assert select_representative_pka("nan", "nan") is None


def test_select_single_base():
    result = select_representative_pka("", "7.123")
    assert result == pytest.approx(7.123)


# --- CSV reading ---

def test_read_pka_csv():
    """Read a mock MolGpKa output CSV."""
    csv_content = (
        "compound,smiles,acid_pkas,base_pkas\n"
        "aspirin,CC(=O)Oc1ccccc1C(=O)O,3.456,\n"
        "risperidone,c1ccc2c(c1)Cc1ccccc1C2=O,,5.667;6.785;4.657\n"
        "caffeine,Cn1cnc2c1c(=O)n(c(=O)n2C)C,,\n"
    )
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(csv_content)
        f.flush()
        pka_map = read_pka_csv(f.name, id_col="compound")

    # aspirin: only acidic → min = 3.456
    assert "aspirin" in pka_map
    assert pka_map["aspirin"] == pytest.approx(3.456)

    # risperidone: basic → max = 6.785
    assert "risperidone" in pka_map
    assert pka_map["risperidone"] == pytest.approx(6.785)

    # caffeine: no pKa data → not in map
    assert "caffeine" not in pka_map


def test_read_pka_csv_auto_detect_id():
    """Auto-detect compound name column."""
    csv_content = "name,smiles,acid_pkas,base_pkas\ntest,C,4.0,\n"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(csv_content)
        f.flush()
        # Default id_col="compound" won't match, should auto-detect "name"
        pka_map = read_pka_csv(f.name)

    assert "test" in pka_map
