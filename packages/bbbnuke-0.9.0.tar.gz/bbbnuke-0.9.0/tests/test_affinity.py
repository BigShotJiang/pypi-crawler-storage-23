"""Tests for the PSICHIC affinity adapter."""

from __future__ import annotations

import tempfile

import pytest

from bbnuke.modules.affinity import read_screening_csv


def _make_screening_csv(score_col: str = "Prediction") -> str:
    """Create a mock PSICHIC screening CSV and return its path."""
    rows = [
        f"Compound_ID,Protein_ID,Ligand,Protein,{score_col}",
        "aspirin,LAT1,CC(=O)Oc1ccccc1C(=O)O,MSEQ...,7.5",
        "aspirin,GTR1,CC(=O)Oc1ccccc1C(=O)O,MSEQ...,4.2",
        "caffeine,LAT1,Cn1cnc2c1c,MSEQ...,3.1",
        "caffeine,GTR1,Cn1cnc2c1c,MSEQ...,6.8",
        "caffeine,ABCB1,Cn1cnc2c1c,MSEQ...,8.5",
    ]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write("\n".join(rows))
        return f.name


def test_read_screening_csv_basic():
    """Read a standard PSICHIC screening CSV."""
    csv_path = _make_screening_csv()
    aff_map = read_screening_csv(csv_path)

    assert "aspirin" in aff_map
    assert "caffeine" in aff_map

    # aspirin: 2 proteins
    assert len(aff_map["aspirin"]) == 2
    lat1 = next(s for s in aff_map["aspirin"] if s.protein_id == "LAT1")
    assert lat1.score_raw == pytest.approx(7.5)
    assert lat1.score_norm == pytest.approx(0.75)

    # caffeine: 3 proteins
    assert len(aff_map["caffeine"]) == 3


def test_read_screening_csv_normalization():
    """Scores are normalized to [0, 1] by dividing by 10."""
    csv_path = _make_screening_csv()
    aff_map = read_screening_csv(csv_path)

    gtr1 = next(s for s in aff_map["aspirin"] if s.protein_id == "GTR1")
    assert gtr1.score_raw == pytest.approx(4.2)
    assert gtr1.score_norm == pytest.approx(0.42)


def test_read_screening_csv_clamped():
    """Scores > 10 are clamped to 1.0."""
    rows = [
        "Compound_ID,Protein_ID,Ligand,Protein,Prediction",
        "test,P1,C,SEQ,12.5",
    ]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write("\n".join(rows))
        f.flush()
        aff_map = read_screening_csv(f.name)

    assert aff_map["test"][0].score_norm == 1.0


def test_read_screening_csv_custom_score_col():
    """Read with a non-default score column name."""
    csv_path = _make_screening_csv(score_col="binding_score")
    aff_map = read_screening_csv(csv_path, score_col="binding_score")
    assert len(aff_map["aspirin"]) == 2


def test_read_screening_csv_auto_detect_score():
    """Auto-detect score column when it contains 'pred' or 'score'."""
    csv_path = _make_screening_csv(score_col="Prediction")
    # No explicit score_col → should auto-detect "Prediction"
    aff_map = read_screening_csv(csv_path)
    assert len(aff_map) == 2
