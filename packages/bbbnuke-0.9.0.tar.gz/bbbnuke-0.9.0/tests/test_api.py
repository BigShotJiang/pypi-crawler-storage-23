"""Tests for BBB-Nuke API endpoints."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from bbnuke.api.app import create_app


@pytest.fixture(scope="module")
def client():
    app = create_app()
    with TestClient(app) as c:
        yield c


# ---------------------------------------------------------------------------
# Health & Version
# ---------------------------------------------------------------------------

class TestHealth:
    def test_health(self, client: TestClient):
        r = client.get("/v1/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"

    def test_version(self, client: TestClient):
        r = client.get("/v1/version")
        assert r.status_code == 200
        data = r.json()
        assert "pipeline_version" in data
        assert "hyperparameters" in data
        assert data["hyperparameters"]["logistic_k"] == 0.1352

    def test_request_id_header(self, client: TestClient):
        r = client.get("/v1/health")
        assert "x-request-id" in r.headers
        assert "x-response-time-ms" in r.headers


# ---------------------------------------------------------------------------
# Proteins
# ---------------------------------------------------------------------------

class TestProteins:
    def test_list_proteins(self, client: TestClient):
        r = client.get("/v1/proteins")
        assert r.status_code == 200
        data = r.json()
        assert data["count"] == 65
        assert len(data["proteins"]) == 65

    def test_protein_fields(self, client: TestClient):
        r = client.get("/v1/proteins")
        p = r.json()["proteins"][0]
        assert "common_name" in p
        assert "category" in p
        assert "weight" in p
        assert "binding_threshold" in p
        assert p["category"] in ("carrier", "efflux", "enzyme")

    def test_protein_categories(self, client: TestClient):
        r = client.get("/v1/proteins")
        cats = {p["category"] for p in r.json()["proteins"]}
        assert "carrier" in cats
        assert "efflux" in cats
        assert "enzyme" in cats


# ---------------------------------------------------------------------------
# Score
# ---------------------------------------------------------------------------

class TestScore:
    def test_score_simple_smiles(self, client: TestClient):
        """Score carbazole (simple aromatic) — no pKa, no affinity."""
        r = client.post("/v1/score", json={
            "smiles": "c1ccc2c(c1)c1ccccc1[nH]2",
            "compound_id": "carbazole",
        })
        assert r.status_code == 200
        data = r.json()
        result = data["result"]
        assert result["compound_id"] == "carbazole"
        assert result["smiles_standardized"]
        assert result["properties"]["mw"] > 0
        assert 0 <= result["cns_mpo"]["score"] <= 6
        assert "pipeline_version" in data

    def test_score_default_compound_id(self, client: TestClient):
        r = client.post("/v1/score", json={"smiles": "CCO"})
        assert r.status_code == 200
        assert r.json()["result"]["compound_id"] == "query"

    def test_score_invalid_smiles(self, client: TestClient):
        r = client.post("/v1/score", json={"smiles": "NOT_A_SMILES"})
        assert r.status_code == 422

    def test_score_empty_smiles(self, client: TestClient):
        r = client.post("/v1/score", json={"smiles": ""})
        assert r.status_code == 422

    def test_score_with_affinity_flag(self, client: TestClient):
        """include_affinity=True now works (pre-computed lookup).
        Unknown compounds gracefully fall back to MPO-only scoring.
        """
        r = client.post("/v1/score", json={
            "smiles": "CCO",
            "include_affinity": True,
        })
        assert r.status_code == 200
        # CCO (ethanol) is not in the BBB+ set, so affinity should be None
        assert r.json()["result"]["affinity"] is None

    def test_score_with_config_override(self, client: TestClient):
        r = client.post("/v1/score", json={
            "smiles": "c1ccc2c(c1)c1ccccc1[nH]2",
            "config": {"mpo_cutoff": 5.0},
        })
        assert r.status_code == 200
        assert r.json()["config"]["mpo_cutoff"] == 5.0

    def test_score_mpo_pass(self, client: TestClient):
        """Risperidone-like compound should pass MPO filter."""
        r = client.post("/v1/score", json={
            "smiles": "c1ccc2c(c1)c1ccccc1[nH]2",
        })
        assert r.status_code == 200
        result = r.json()["result"]
        # Carbazole has decent drug-like properties
        assert result["cns_mpo"]["score"] > 0

    def test_score_heuristic_present_when_mpo_passes(self, client: TestClient):
        """When MPO >= 3, heuristic should be computed (MPO-only mode)."""
        r = client.post("/v1/score", json={
            "smiles": "c1ccc2c(c1)c1ccccc1[nH]2",
        })
        assert r.status_code == 200
        result = r.json()["result"]
        if result["passed_mpo_filter"]:
            assert result["heuristic"] is not None
            assert 0 <= result["heuristic"]["p_bbb"] <= 1


# ---------------------------------------------------------------------------
# Batch / Screen stubs
# ---------------------------------------------------------------------------

class TestStubs:
    def test_batch_needs_redis(self, client: TestClient):
        """Batch submission without Redis returns error (503 or 500)."""
        r = client.post("/v1/batch", json={
            "compounds": [{"smiles": "CCO", "compound_id": "ethanol"}],
        })
        # Without Redis running, batch submission should fail
        assert r.status_code >= 500

    def test_screen_not_implemented(self, client: TestClient):
        r = client.post("/v1/screen", json={})
        assert r.status_code == 501
