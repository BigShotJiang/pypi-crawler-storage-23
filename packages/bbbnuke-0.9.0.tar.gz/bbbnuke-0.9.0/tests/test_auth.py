"""Tests for API key auth, key management, and rate limiting."""

from __future__ import annotations

import os

import pytest
from fastapi.testclient import TestClient

from bbnuke.api.auth import API_KEY_PREFIX, generate_api_key, hash_key


# ---------------------------------------------------------------------------
# Auth unit tests
# ---------------------------------------------------------------------------

class TestKeyGeneration:
    def test_generate_key_format(self):
        raw, hashed = generate_api_key()
        assert raw.startswith(API_KEY_PREFIX)
        assert len(raw) == len(API_KEY_PREFIX) + 64  # 32 bytes hex = 64 chars
        assert len(hashed) == 64  # SHA-256 hex

    def test_generate_unique(self):
        keys = [generate_api_key()[0] for _ in range(10)]
        assert len(set(keys)) == 10

    def test_hash_deterministic(self):
        raw = "bnk_live_abc123"
        assert hash_key(raw) == hash_key(raw)

    def test_hash_different_keys(self):
        _, h1 = generate_api_key()
        _, h2 = generate_api_key()
        assert h1 != h2


# ---------------------------------------------------------------------------
# Key management endpoint tests (use fresh in-memory DB)
# ---------------------------------------------------------------------------

@pytest.fixture
def auth_client():
    """Client with a fresh in-memory SQLite DB."""
    # Force SQLite in-memory for tests
    os.environ["BBNUKE_DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
    old_key = os.environ.pop("BBNUKE_API_KEY", None)

    import bbnuke.core.config as cfg
    cfg.settings = cfg.Settings()

    # Re-create engine with new URL
    import bbnuke.db.session as sess
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
    sess.engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    sess.async_session_factory = async_sessionmaker(sess.engine, expire_on_commit=False)

    from bbnuke.api.app import create_app
    app = create_app()
    with TestClient(app) as c:
        yield c

    # Cleanup
    if old_key is not None:
        os.environ["BBNUKE_API_KEY"] = old_key
    else:
        os.environ.pop("BBNUKE_API_KEY", None)
    os.environ.pop("BBNUKE_DATABASE_URL", None)
    cfg.settings = cfg.Settings()


class TestKeyManagement:
    def test_create_key(self, auth_client: TestClient):
        r = auth_client.post("/v1/admin/keys", json={"label": "test-key"})
        assert r.status_code == 201
        data = r.json()
        assert data["key"].startswith(API_KEY_PREFIX)
        assert data["label"] == "test-key"
        assert data["rate_limit_rpm"] == 100

    def test_create_key_custom_rpm(self, auth_client: TestClient):
        r = auth_client.post("/v1/admin/keys", json={
            "label": "fast-key",
            "rate_limit_rpm": 500,
        })
        assert r.status_code == 201
        assert r.json()["rate_limit_rpm"] == 500

    def test_list_keys(self, auth_client: TestClient):
        auth_client.post("/v1/admin/keys", json={"label": "list-test"})
        r = auth_client.get("/v1/admin/keys")
        assert r.status_code == 200
        keys = r.json()
        assert isinstance(keys, list)
        assert any(k["label"] == "list-test" for k in keys)

    def test_revoke_key(self, auth_client: TestClient):
        auth_client.post("/v1/admin/keys", json={"label": "revoke-test"})
        list_r = auth_client.get("/v1/admin/keys")
        key_entry = next(k for k in list_r.json() if k["label"] == "revoke-test")

        revoke_r = auth_client.delete(f"/v1/admin/keys/{key_entry['id']}")
        assert revoke_r.status_code == 200
        assert revoke_r.json()["status"] == "revoked"

    def test_revoke_nonexistent(self, auth_client: TestClient):
        r = auth_client.delete("/v1/admin/keys/99999")
        assert r.status_code == 404


# ---------------------------------------------------------------------------
# Rate limit header tests
# ---------------------------------------------------------------------------

class TestRateLimitHeaders:
    def test_rate_limit_headers_present(self, auth_client: TestClient):
        r = auth_client.get("/v1/proteins")
        assert "x-ratelimit-limit" in r.headers
        assert "x-ratelimit-remaining" in r.headers
        assert "x-ratelimit-reset" in r.headers

    def test_health_exempt_from_rate_limit(self, auth_client: TestClient):
        r = auth_client.get("/v1/health")
        assert "x-ratelimit-limit" not in r.headers


# ---------------------------------------------------------------------------
# API key middleware tests
# ---------------------------------------------------------------------------

class TestApiKeyMiddleware:
    def test_open_access_when_no_key_configured(self):
        """Without BBNUKE_API_KEY, all requests pass through."""
        old = os.environ.pop("BBNUKE_API_KEY", None)
        try:
            import bbnuke.core.config as cfg
            cfg.settings = cfg.Settings()

            from bbnuke.api.app import create_app
            app = create_app()
            with TestClient(app) as client:
                r = client.post("/v1/score", json={"smiles": "CCO"})
                assert r.status_code == 200
        finally:
            if old is not None:
                os.environ["BBNUKE_API_KEY"] = old
            cfg.settings = cfg.Settings()

    def test_reject_without_key_when_configured(self):
        """With BBNUKE_API_KEY set, unauthenticated requests are rejected."""
        old = os.environ.get("BBNUKE_API_KEY")
        try:
            os.environ["BBNUKE_API_KEY"] = "test_secret_key"
            import bbnuke.core.config as cfg
            cfg.settings = cfg.Settings()

            from bbnuke.api.app import create_app
            app = create_app()
            with TestClient(app) as client:
                r = client.post("/v1/score", json={"smiles": "CCO"})
                assert r.status_code == 401
        finally:
            if old is None:
                os.environ.pop("BBNUKE_API_KEY", None)
            else:
                os.environ["BBNUKE_API_KEY"] = old
            cfg.settings = cfg.Settings()

    def test_accept_with_correct_key(self):
        """Correct Bearer token passes through."""
        old = os.environ.get("BBNUKE_API_KEY")
        try:
            os.environ["BBNUKE_API_KEY"] = "test_secret_key"
            import bbnuke.core.config as cfg
            cfg.settings = cfg.Settings()

            from bbnuke.api.app import create_app
            app = create_app()
            with TestClient(app) as client:
                r = client.post(
                    "/v1/score",
                    json={"smiles": "CCO"},
                    headers={"Authorization": "Bearer test_secret_key"},
                )
                assert r.status_code == 200
        finally:
            if old is None:
                os.environ.pop("BBNUKE_API_KEY", None)
            else:
                os.environ["BBNUKE_API_KEY"] = old
            cfg.settings = cfg.Settings()

    def test_reject_with_wrong_key(self):
        """Wrong Bearer token is rejected."""
        old = os.environ.get("BBNUKE_API_KEY")
        try:
            os.environ["BBNUKE_API_KEY"] = "test_secret_key"
            import bbnuke.core.config as cfg
            cfg.settings = cfg.Settings()

            from bbnuke.api.app import create_app
            app = create_app()
            with TestClient(app) as client:
                r = client.post(
                    "/v1/score",
                    json={"smiles": "CCO"},
                    headers={"Authorization": "Bearer wrong_key"},
                )
                assert r.status_code == 403
        finally:
            if old is None:
                os.environ.pop("BBNUKE_API_KEY", None)
            else:
                os.environ["BBNUKE_API_KEY"] = old
            cfg.settings = cfg.Settings()
