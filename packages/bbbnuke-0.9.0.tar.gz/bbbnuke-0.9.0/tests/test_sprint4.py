"""Tests for Sprint 4: Tier B foundation — orgs, projects, workflows, usage, audit."""

from __future__ import annotations

import asyncio
import os

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def s4_client():
    """Client with fresh in-memory DB (no API key required)."""
    os.environ["BBNUKE_DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
    os.environ.pop("BBNUKE_API_KEY", None)

    import bbnuke.core.config as cfg
    cfg.settings = cfg.Settings()

    # Re-init DB engine with in-memory SQLite
    import bbnuke.db.session as sess
    asyncio.get_event_loop().run_until_complete(sess.engine.dispose())

    sess.engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    sess.async_session_factory = async_sessionmaker(sess.engine, expire_on_commit=False)

    from bbnuke.api.app import create_app
    app = create_app()

    with TestClient(app) as client:
        yield client


# ---------------------------------------------------------------------------
# Organization CRUD
# ---------------------------------------------------------------------------

class TestOrganizations:
    def test_create_org(self, s4_client):
        resp = s4_client.post("/v1/orgs", json={"name": "ATTN Lab"})
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "ATTN Lab"
        assert data["plan"] == "free"
        assert "id" in data

    def test_list_orgs(self, s4_client):
        s4_client.post("/v1/orgs", json={"name": "Org A"})
        s4_client.post("/v1/orgs", json={"name": "Org B"})
        resp = s4_client.get("/v1/orgs")
        assert resp.status_code == 200
        assert len(resp.json()) == 2

    def test_get_org(self, s4_client):
        create = s4_client.post("/v1/orgs", json={"name": "Test Org"})
        org_id = create.json()["id"]
        resp = s4_client.get(f"/v1/orgs/{org_id}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "Test Org"

    def test_get_org_not_found(self, s4_client):
        resp = s4_client.get("/v1/orgs/nonexistent")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Workspace CRUD
# ---------------------------------------------------------------------------

class TestWorkspaces:
    def test_create_workspace(self, s4_client):
        org = s4_client.post("/v1/orgs", json={"name": "WS Org"}).json()
        resp = s4_client.post(
            f"/v1/orgs/{org['id']}/workspaces",
            json={"name": "Default", "description": "Main workspace"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "Default"
        assert data["org_id"] == org["id"]

    def test_create_workspace_org_not_found(self, s4_client):
        resp = s4_client.post(
            "/v1/orgs/bad-id/workspaces",
            json={"name": "Orphan"},
        )
        assert resp.status_code == 404

    def test_list_workspaces(self, s4_client):
        org = s4_client.post("/v1/orgs", json={"name": "Multi WS"}).json()
        s4_client.post(f"/v1/orgs/{org['id']}/workspaces", json={"name": "WS 1"})
        s4_client.post(f"/v1/orgs/{org['id']}/workspaces", json={"name": "WS 2"})
        resp = s4_client.get(f"/v1/orgs/{org['id']}/workspaces")
        assert resp.status_code == 200
        assert len(resp.json()) == 2


# ---------------------------------------------------------------------------
# Project CRUD
# ---------------------------------------------------------------------------

class TestProjects:
    def test_create_project(self, s4_client):
        org = s4_client.post("/v1/orgs", json={"name": "Proj Org"}).json()
        ws = s4_client.post(
            f"/v1/orgs/{org['id']}/workspaces", json={"name": "WS"}
        ).json()
        resp = s4_client.post(
            f"/v1/workspaces/{ws['id']}/projects",
            json={"name": "BBB Screen", "description": "Main screen project"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "BBB Screen"
        assert data["workspace_id"] == ws["id"]

    def test_list_projects(self, s4_client):
        org = s4_client.post("/v1/orgs", json={"name": "LP Org"}).json()
        ws = s4_client.post(
            f"/v1/orgs/{org['id']}/workspaces", json={"name": "WS"}
        ).json()
        s4_client.post(f"/v1/workspaces/{ws['id']}/projects", json={"name": "P1"})
        s4_client.post(f"/v1/workspaces/{ws['id']}/projects", json={"name": "P2"})
        resp = s4_client.get(f"/v1/workspaces/{ws['id']}/projects")
        assert resp.status_code == 200
        assert len(resp.json()) == 2

    def test_get_project(self, s4_client):
        org = s4_client.post("/v1/orgs", json={"name": "GP Org"}).json()
        ws = s4_client.post(
            f"/v1/orgs/{org['id']}/workspaces", json={"name": "WS"}
        ).json()
        proj = s4_client.post(
            f"/v1/workspaces/{ws['id']}/projects",
            json={"name": "P", "config": {"run_pka": True}},
        ).json()
        resp = s4_client.get(f"/v1/projects/{proj['id']}")
        assert resp.status_code == 200
        assert resp.json()["config"] == {"run_pka": True}

    def test_get_project_not_found(self, s4_client):
        resp = s4_client.get("/v1/projects/nonexistent")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Workflow models (unit tests — no API endpoint yet)
# ---------------------------------------------------------------------------

class TestWorkflowModels:
    def test_workflow_definition_ready_steps(self):
        from bbnuke.workflows.models import (
            StepStatus, StepType, WorkflowDefinition, WorkflowStep,
        )
        wf = WorkflowDefinition(
            name="test",
            steps=[
                WorkflowStep(id="a", type=StepType.batch_score),
                WorkflowStep(id="b", type=StepType.filter, depends_on=["a"]),
            ],
        )
        ready = wf.ready_steps()
        assert len(ready) == 1
        assert ready[0].id == "a"

    def test_workflow_definition_is_complete(self):
        from bbnuke.workflows.models import (
            StepStatus, StepType, WorkflowDefinition, WorkflowStep,
        )
        wf = WorkflowDefinition(
            name="test",
            steps=[
                WorkflowStep(id="a", type=StepType.batch_score, status=StepStatus.completed),
                WorkflowStep(id="b", type=StepType.filter, status=StepStatus.completed),
            ],
        )
        assert wf.is_complete is True

    def test_workflow_not_complete(self):
        from bbnuke.workflows.models import (
            StepStatus, StepType, WorkflowDefinition, WorkflowStep,
        )
        wf = WorkflowDefinition(
            name="test",
            steps=[
                WorkflowStep(id="a", type=StepType.batch_score, status=StepStatus.completed),
                WorkflowStep(id="b", type=StepType.filter, status=StepStatus.pending),
            ],
        )
        assert wf.is_complete is False

    def test_ready_steps_respects_dependencies(self):
        from bbnuke.workflows.models import (
            StepStatus, StepType, WorkflowDefinition, WorkflowStep,
        )
        wf = WorkflowDefinition(
            name="test",
            steps=[
                WorkflowStep(id="a", type=StepType.batch_score, status=StepStatus.pending),
                WorkflowStep(id="b", type=StepType.filter, depends_on=["a"], status=StepStatus.pending),
                WorkflowStep(id="c", type=StepType.batch_score, status=StepStatus.pending),
            ],
        )
        ready = wf.ready_steps()
        ids = {s.id for s in ready}
        assert ids == {"a", "c"}


# ---------------------------------------------------------------------------
# Workflow engine (unit test with mock step)
# ---------------------------------------------------------------------------

class TestWorkflowEngine:
    def test_run_workflow_simple(self):
        """Run a two-step workflow: score → filter, with mock handlers."""
        from bbnuke.workflows.models import (
            StepType, WorkflowDefinition, WorkflowStep,
        )
        from bbnuke.workflows.engine import _STEP_HANDLERS, run_workflow

        # Save and replace handlers with mocks
        saved = dict(_STEP_HANDLERS)
        try:
            async def mock_score(step, ctx):
                return {"results": [{"compound_id": "A", "smiles": "C", "p_bbb": 0.7}], "compounds": []}

            async def mock_filter(step, ctx):
                return {"results": [], "count": 0}

            _STEP_HANDLERS[StepType.batch_score] = mock_score
            _STEP_HANDLERS[StepType.filter] = mock_filter

            wf = WorkflowDefinition(
                name="mock-wf",
                steps=[
                    WorkflowStep(id="score", type=StepType.batch_score),
                    WorkflowStep(id="filt", type=StepType.filter, depends_on=["score"]),
                ],
            )

            result = asyncio.get_event_loop().run_until_complete(run_workflow(wf))
            assert result.is_complete
            assert result.get_step("score").status.value == "completed"
            assert result.get_step("filt").status.value == "completed"
        finally:
            _STEP_HANDLERS.clear()
            _STEP_HANDLERS.update(saved)

    def test_run_workflow_handles_failure(self):
        """A failing step should be marked failed, not stall the workflow."""
        from bbnuke.workflows.models import (
            StepType, WorkflowDefinition, WorkflowStep,
        )
        from bbnuke.workflows.engine import _STEP_HANDLERS, run_workflow

        saved = dict(_STEP_HANDLERS)
        try:
            async def mock_fail(step, ctx):
                raise RuntimeError("boom")

            _STEP_HANDLERS[StepType.batch_score] = mock_fail

            wf = WorkflowDefinition(
                name="fail-wf",
                steps=[
                    WorkflowStep(id="bad", type=StepType.batch_score),
                ],
            )

            result = asyncio.get_event_loop().run_until_complete(run_workflow(wf))
            assert result.is_complete
            assert result.get_step("bad").status.value == "failed"
            assert result.get_step("bad").error == "boom"
        finally:
            _STEP_HANDLERS.clear()
            _STEP_HANDLERS.update(saved)


# ---------------------------------------------------------------------------
# Filter step logic (unit test)
# ---------------------------------------------------------------------------

class TestFilterStep:
    def test_filter_by_min_value(self):
        from bbnuke.workflows.steps.filter_step import handle_filter
        from bbnuke.workflows.models import StepType, WorkflowStep

        step = WorkflowStep(
            id="filt",
            type=StepType.filter,
            config={
                "input_from": "score",
                "metric": "p_bbb",
                "min_value": 0.5,
            },
        )
        context = {
            "score": {
                "results": [
                    {"compound_id": "A", "smiles": "C", "p_bbb": 0.7},
                    {"compound_id": "B", "smiles": "CC", "p_bbb": 0.3},
                    {"compound_id": "C", "smiles": "CCC", "p_bbb": 0.6},
                ],
            },
        }
        result = asyncio.get_event_loop().run_until_complete(handle_filter(step, context))
        assert result["count"] == 2
        assert result["filtered_from"] == 3

    def test_filter_top_k(self):
        from bbnuke.workflows.steps.filter_step import handle_filter
        from bbnuke.workflows.models import StepType, WorkflowStep

        step = WorkflowStep(
            id="filt",
            type=StepType.filter,
            config={
                "input_from": "score",
                "metric": "p_bbb",
                "top_k": 2,
            },
        )
        context = {
            "score": {
                "results": [
                    {"compound_id": "A", "smiles": "C", "p_bbb": 0.3},
                    {"compound_id": "B", "smiles": "CC", "p_bbb": 0.8},
                    {"compound_id": "C", "smiles": "CCC", "p_bbb": 0.5},
                ],
            },
        }
        result = asyncio.get_event_loop().run_until_complete(handle_filter(step, context))
        assert result["count"] == 2
        ids = [r["compound_id"] for r in result["results"]]
        assert ids == ["B", "C"]  # sorted descending by p_bbb

    def test_filter_nested_metric(self):
        from bbnuke.workflows.steps.filter_step import handle_filter
        from bbnuke.workflows.models import StepType, WorkflowStep

        step = WorkflowStep(
            id="filt",
            type=StepType.filter,
            config={
                "input_from": "score",
                "metric": "cns_mpo.score",
                "min_value": 4.0,
            },
        )
        context = {
            "score": {
                "results": [
                    {"compound_id": "A", "smiles": "C", "cns_mpo": {"score": 5.2}},
                    {"compound_id": "B", "smiles": "CC", "cns_mpo": {"score": 3.1}},
                ],
            },
        }
        result = asyncio.get_event_loop().run_until_complete(handle_filter(step, context))
        assert result["count"] == 1
        assert result["results"][0]["compound_id"] == "A"


# ---------------------------------------------------------------------------
# Usage & Audit (unit tests with async DB)
# ---------------------------------------------------------------------------

class TestUsageMetering:
    def test_record_usage(self):
        """Record a usage event and verify it persists."""
        from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
        from sqlalchemy.orm import sessionmaker
        from sqlalchemy import select
        from bbnuke.db.models import Base, UsageEvent
        from bbnuke.api.usage import record_usage

        async def _run():
            engine = create_async_engine("sqlite+aiosqlite:///:memory:")
            async with engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)

            async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
            async with async_session() as session:
                await record_usage(session, "compound_scored", 10, org_id="org-1", job_id="job-1")
                await session.commit()

                result = await session.execute(select(UsageEvent))
                events = result.scalars().all()
                assert len(events) == 1
                assert events[0].event_type == "compound_scored"
                assert events[0].quantity == 10

            await engine.dispose()

        asyncio.get_event_loop().run_until_complete(_run())


class TestAuditLog:
    def test_log_audit(self):
        """Record an audit entry and verify it persists."""
        from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
        from sqlalchemy.orm import sessionmaker
        from sqlalchemy import select
        from bbnuke.db.models import Base, AuditLog
        from bbnuke.api.audit import log_audit

        async def _run():
            engine = create_async_engine("sqlite+aiosqlite:///:memory:")
            async with engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)

            async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
            async with async_session() as session:
                await log_audit(
                    session,
                    action="key_created",
                    resource_type="api_key",
                    resource_id="key-1",
                    org_id="org-1",
                    detail={"label": "test key"},
                )
                await session.commit()

                result = await session.execute(select(AuditLog))
                entries = result.scalars().all()
                assert len(entries) == 1
                assert entries[0].action == "key_created"
                assert entries[0].detail_json == {"label": "test key"}

            await engine.dispose()

        asyncio.get_event_loop().run_until_complete(_run())
