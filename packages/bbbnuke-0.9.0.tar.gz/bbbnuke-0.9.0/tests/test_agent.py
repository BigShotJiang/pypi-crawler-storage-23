"""Tests for the BBB-Nuke agentic tool-calling framework (v0.7.0).

Coverage:
  1. Tool registry — register, invoke, logging, permission enforcement
  2. Workspace sandbox — create, write, read, list, path escape blocked
  3. Run state — create, save, load, resumability
  4. Permissions — tier_a blocked from tier_b, internal always blocked
  5. Integration — full orchestrator run with deterministic plan
"""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
from typing import Any, Dict

import pytest

from bbnuke.agent.permissions import check_permission, get_tier_limits
from bbnuke.agent.state import (
    AgentContext,
    RunState,
    RunStateManager,
    RunStepName,
    StepStatus,
    TierName,
)
from bbnuke.agent.tools.registry import (
    PermissionDeniedError,
    PermissionScope,
    ToolDefinition,
    ToolExecutionError,
    ToolNotFoundError,
    ToolRegistry,
    ToolValidationError,
    get_registry,
    invoke,
)
from bbnuke.agent.workspace import WorkspaceSandbox, WorkspaceSandboxError

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run(coro):
    """Run an async function synchronously."""
    return asyncio.get_event_loop().run_until_complete(coro)


class _MockInput(BaseModel):
    value: str = "hello"


class _MockOutput(BaseModel):
    result: str


def _make_ctx(tmp_dir: str, tier: TierName = TierName.tier_a) -> AgentContext:
    """Create an AgentContext with a temp workspace."""
    sandbox = WorkspaceSandbox(run_id="test_run", runs_dir=tmp_dir)
    sandbox.init()
    sm = RunStateManager(sandbox=sandbox)
    sm.load_or_create("test_run", tier)
    return AgentContext(
        run_id="test_run",
        tier=tier,
        sandbox=sandbox,
        state_manager=sm,
    )


# ===================================================================
# 1. Tool Registry
# ===================================================================

class TestToolRegistry:
    """Unit tests for ToolRegistry, @register_tool, and invoke()."""

    def test_register_and_get(self):
        reg = ToolRegistry()
        defn = ToolDefinition(
            name="test_tool",
            description="A test tool",
            input_schema=_MockInput,
            output_schema=_MockOutput,
            permission_scope=PermissionScope.tier_a,
            fn=lambda inp, ctx: _MockOutput(result=inp.value),
        )
        reg.register(defn)
        assert reg.get("test_tool") is defn
        assert reg.get("nonexistent") is None

    def test_duplicate_registration_raises(self):
        reg = ToolRegistry()
        defn = ToolDefinition(
            name="dup_tool",
            description="dup",
            input_schema=_MockInput,
            output_schema=_MockOutput,
            permission_scope=PermissionScope.tier_a,
            fn=lambda inp, ctx: _MockOutput(result="x"),
        )
        reg.register(defn)
        with pytest.raises(ValueError, match="already registered"):
            reg.register(defn)

    def test_tools_for_scope_tier_a(self):
        reg = ToolRegistry()
        for name, scope in [("a1", PermissionScope.tier_a), ("b1", PermissionScope.tier_b), ("i1", PermissionScope.internal)]:
            reg.register(ToolDefinition(
                name=name, description=name, input_schema=_MockInput,
                output_schema=_MockOutput, permission_scope=scope,
                fn=lambda inp, ctx: _MockOutput(result="x"),
            ))
        visible = reg.tools_for_scope(PermissionScope.tier_a)
        assert "a1" in visible
        assert "b1" not in visible
        assert "i1" not in visible

    def test_tools_for_scope_tier_b(self):
        reg = ToolRegistry()
        for name, scope in [("a2", PermissionScope.tier_a), ("b2", PermissionScope.tier_b), ("i2", PermissionScope.internal)]:
            reg.register(ToolDefinition(
                name=name, description=name, input_schema=_MockInput,
                output_schema=_MockOutput, permission_scope=scope,
                fn=lambda inp, ctx: _MockOutput(result="x"),
            ))
        visible = reg.tools_for_scope(PermissionScope.tier_b)
        assert "a2" in visible
        assert "b2" in visible
        assert "i2" not in visible

    def test_schema_for_llm(self):
        reg = ToolRegistry()
        reg.register(ToolDefinition(
            name="llm_tool", description="For LLM", input_schema=_MockInput,
            output_schema=_MockOutput, permission_scope=PermissionScope.tier_a,
            fn=lambda inp, ctx: _MockOutput(result="x"),
        ))
        schemas = reg.schema_for_llm(PermissionScope.tier_a)
        assert len(schemas) == 1
        assert schemas[0]["name"] == "llm_tool"
        assert "parameters" in schemas[0]

    def test_invoke_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = _make_ctx(tmp)

            # Register tool directly in global registry, then clean up
            orig_registry = get_registry()
            saved_tools = dict(orig_registry._tools)

            async def _handler(inp: _MockInput, ctx: AgentContext) -> _MockOutput:
                return _MockOutput(result=f"processed_{inp.value}")

            defn = ToolDefinition(
                name="_test_invoke_ok",
                description="test",
                input_schema=_MockInput,
                output_schema=_MockOutput,
                permission_scope=PermissionScope.tier_a,
                fn=_handler,
            )
            orig_registry.register(defn)
            try:
                result = _run(invoke("_test_invoke_ok", {"value": "abc"}, ctx))
                assert result.result == "processed_abc"
            finally:
                orig_registry._tools = saved_tools

    def test_invoke_not_found(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = _make_ctx(tmp)
            with pytest.raises(ToolNotFoundError):
                _run(invoke("no_such_tool_xyz", {}, ctx))

    def test_invoke_permission_denied(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = _make_ctx(tmp, tier=TierName.tier_a)
            orig_registry = get_registry()
            saved_tools = dict(orig_registry._tools)

            defn = ToolDefinition(
                name="_test_perm_denied",
                description="test",
                input_schema=_MockInput,
                output_schema=_MockOutput,
                permission_scope=PermissionScope.tier_b,
                fn=lambda inp, ctx: _MockOutput(result="x"),
            )
            orig_registry.register(defn)
            try:
                with pytest.raises(PermissionDeniedError):
                    _run(invoke("_test_perm_denied", {}, ctx))
            finally:
                orig_registry._tools = saved_tools

    def test_invoke_validation_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = _make_ctx(tmp)
            orig_registry = get_registry()
            saved_tools = dict(orig_registry._tools)

            class StrictInput(BaseModel):
                required_field: int

            defn = ToolDefinition(
                name="_test_validation",
                description="test",
                input_schema=StrictInput,
                output_schema=_MockOutput,
                permission_scope=PermissionScope.tier_a,
                fn=lambda inp, ctx: _MockOutput(result="x"),
            )
            orig_registry.register(defn)
            try:
                with pytest.raises(ToolValidationError):
                    _run(invoke("_test_validation", {"wrong_field": "abc"}, ctx))
            finally:
                orig_registry._tools = saved_tools


# ===================================================================
# 2. Workspace Sandbox
# ===================================================================

class TestWorkspaceSandbox:
    """Unit tests for WorkspaceSandbox."""

    def test_init_creates_dirs(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="r1", runs_dir=tmp)
            result = ws.init()
            assert result.run_id == "r1"
            for sub in ("input", "artifacts", "logs"):
                assert (ws.root / sub).is_dir()

    def test_init_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="r2", runs_dir=tmp)
            ws.init()
            result2 = ws.init()
            # Second call should not error
            assert result2.run_id == "r2"

    def test_write_and_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="r3", runs_dir=tmp)
            ws.init()
            ws.write_file("artifacts/test.txt", "hello world")
            read = ws.read_file("artifacts/test.txt")
            assert read.content == "hello world"
            assert read.size_bytes == len("hello world".encode())

    def test_list_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="r4", runs_dir=tmp)
            ws.init()
            ws.write_file("artifacts/a.txt", "aaa")
            ws.write_file("input/b.csv", "x,y\n1,2")
            listing = ws.list_files()
            paths = [f.path for f in listing.files]
            assert "artifacts/a.txt" in paths
            assert "input/b.csv" in paths

    def test_path_escape_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="r5", runs_dir=tmp)
            ws.init()
            with pytest.raises(WorkspaceSandboxError):
                ws.read_file("../../etc/passwd")

    def test_path_escape_write_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="r6", runs_dir=tmp)
            ws.init()
            with pytest.raises(WorkspaceSandboxError):
                ws.write_file("../outside.txt", "escape attempt")

    def test_read_nonexistent_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="r7", runs_dir=tmp)
            ws.init()
            with pytest.raises(FileNotFoundError):
                ws.read_file("artifacts/nope.txt")


# ===================================================================
# 3. Run State
# ===================================================================

class TestRunState:
    """Unit tests for RunState, RunStateManager."""

    def test_create_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="s1", runs_dir=tmp)
            ws.init()
            sm = RunStateManager(sandbox=ws)
            state = sm.load_or_create("s1", TierName.tier_a)
            assert state.run_id == "s1"
            assert len(state.steps) == 8  # all RunStepName values
            assert state.steps[0].name == RunStepName.ingest
            assert all(s.status == StepStatus.pending for s in state.steps)

    def test_save_and_load(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="s2", runs_dir=tmp)
            ws.init()
            sm = RunStateManager(sandbox=ws)
            state = sm.load_or_create("s2", TierName.tier_a)

            # Modify and save
            state.steps[0].status = StepStatus.completed
            sm.save(state)

            # Reload
            loaded = sm.load()
            assert loaded is not None
            assert loaded.steps[0].status == StepStatus.completed

    def test_current_step_advances(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="s3", runs_dir=tmp)
            ws.init()
            sm = RunStateManager(sandbox=ws)
            state = sm.load_or_create("s3", TierName.tier_a)

            assert state.current_step().name == RunStepName.ingest

            state.steps[0].status = StepStatus.completed
            assert state.current_step().name == RunStepName.standardize

            state.steps[1].status = StepStatus.skipped
            assert state.current_step().name == RunStepName.props_pka

    def test_is_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="s4", runs_dir=tmp)
            ws.init()
            sm = RunStateManager(sandbox=ws)
            state = sm.load_or_create("s4", TierName.tier_a)

            assert not state.is_complete()
            for s in state.steps:
                s.status = StepStatus.completed
            assert state.is_complete()

    def test_resumability(self):
        """Mark steps completed, reload, verify current_step advances."""
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="s5", runs_dir=tmp)
            ws.init()
            sm = RunStateManager(sandbox=ws)
            state = sm.load_or_create("s5", TierName.tier_a)

            # Complete first 3 steps
            for i in range(3):
                state.steps[i].status = StepStatus.completed
            sm.save(state)

            # Simulate restart — new manager, same path
            sm2 = RunStateManager(sandbox=ws)
            reloaded = sm2.load()
            assert reloaded is not None
            assert reloaded.current_step().name == RunStepName.cns_mpo

    def test_load_or_create_reuses_existing(self):
        with tempfile.TemporaryDirectory() as tmp:
            ws = WorkspaceSandbox(run_id="s6", runs_dir=tmp)
            ws.init()
            sm = RunStateManager(sandbox=ws)
            state = sm.load_or_create("s6", TierName.tier_a)
            state.n_compounds_input = 42
            sm.save(state)

            # load_or_create should return existing
            reloaded = sm.load_or_create("s6", TierName.tier_a)
            assert reloaded.n_compounds_input == 42


# ===================================================================
# 4. Permissions
# ===================================================================

class TestPermissions:
    """Unit tests for permission enforcement."""

    def test_tier_a_can_access_tier_a(self):
        # Should not raise
        check_permission(TierName.tier_a, PermissionScope.tier_a)

    def test_tier_a_blocked_from_tier_b(self):
        with pytest.raises(PermissionDeniedError):
            check_permission(TierName.tier_a, PermissionScope.tier_b)

    def test_tier_b_can_access_tier_a(self):
        check_permission(TierName.tier_b, PermissionScope.tier_a)

    def test_tier_b_can_access_tier_b(self):
        check_permission(TierName.tier_b, PermissionScope.tier_b)

    def test_internal_always_blocked(self):
        with pytest.raises(PermissionDeniedError):
            check_permission(TierName.tier_a, PermissionScope.internal)
        with pytest.raises(PermissionDeniedError):
            check_permission(TierName.tier_b, PermissionScope.internal)

    def test_tier_limits(self):
        limits_a = get_tier_limits(TierName.tier_a)
        assert limits_a.max_compounds == 1000
        assert not limits_a.allow_gpu_jobs

        limits_b = get_tier_limits(TierName.tier_b)
        assert limits_b.max_compounds == 100_000
        assert limits_b.allow_gpu_jobs


# ===================================================================
# 5. Tool Registration Check
# ===================================================================

class TestToolRegistration:
    """Verify all expected tools are registered."""

    def test_workspace_tools_registered(self):
        reg = get_registry()
        for name in ["workspace_init", "workspace_list", "workspace_read",
                      "workspace_write", "load_compounds_csv", "export_results"]:
            assert reg.get(name) is not None, f"Missing tool: {name}"

    def test_pipeline_tools_registered(self):
        reg = get_registry()
        for name in ["run_standardize", "run_properties_pka", "run_cns_mpo", "run_heuristic"]:
            assert reg.get(name) is not None, f"Missing tool: {name}"

    def test_compute_tools_registered(self):
        reg = get_registry()
        for name in ["submit_affinity_job", "poll_job", "fetch_job_outputs"]:
            assert reg.get(name) is not None, f"Missing tool: {name}"

    def test_library_stubs_registered(self):
        reg = get_registry()
        for name in ["chembl_search", "chembl_fetch_molecules", "zinc_fetch_subset",
                      "enamine_realspace_query", "enamine_realspace_download"]:
            assert reg.get(name) is not None, f"Missing tool: {name}"

    def test_total_tool_count(self):
        reg = get_registry()
        # 6 workspace + 4 pipeline + 3 compute + 5 library = 18
        # Plus any test tools that leaked — check >= 18
        assert len(reg.all_tools) >= 18


# ===================================================================
# 6. Integration — Full Orchestrator Run (tier_a)
# ===================================================================

class TestOrchestratorIntegration:
    """Integration test: run full graph with a test CSV."""

    def test_full_tier_a_run(self):
        """Place a CSV in input/, run orchestrator, verify completion and artifacts."""
        with tempfile.TemporaryDirectory() as tmp:
            from bbnuke.agent.orchestrator import AgentOrchestrator

            orch = AgentOrchestrator(
                run_id="integration_test",
                tier=TierName.tier_a,
                runs_dir=tmp,
            )
            # Init workspace and place test CSV
            orch.sandbox.init()
            csv_content = "compound_id,smiles\ncaffeine,Cn1c(=O)c2c(ncn2C)n(C)c1=O\nascorbic_acid,OC(=O)C1OC(=O)C(O)=C1O\n"
            orch.sandbox.write_file("input/test.csv", csv_content)

            # We need to manually load compounds first since ingest step
            # only does workspace_init by default
            ctx = orch.ctx
            state = orch.state_manager.load_or_create("integration_test", TierName.tier_a)

            # Load compounds before running
            from bbnuke.agent.tools.workspace_tools import LoadCompoundsCsvInput, load_compounds_csv
            _run(load_compounds_csv(
                LoadCompoundsCsvInput(csv_path="input/test.csv", smiles_col="smiles", id_col="compound_id"),
                ctx,
            ))

            # Now run the full graph
            final_state = _run(orch.run())

            # Verify: ingest, standardize, props_pka, cns_mpo should complete
            # filter_mpo should be skipped (handled inline)
            # affinity should be skipped (tier_a)
            # heuristic and export should complete
            completed_steps = [
                s.name for s in final_state.steps
                if s.status == StepStatus.completed
            ]
            skipped_steps = [
                s.name for s in final_state.steps
                if s.status == StepStatus.skipped
            ]

            assert RunStepName.ingest in completed_steps
            assert RunStepName.standardize in completed_steps
            assert RunStepName.props_pka in completed_steps
            assert RunStepName.cns_mpo in completed_steps
            assert RunStepName.filter_mpo in skipped_steps
            assert RunStepName.affinity in skipped_steps  # tier_a
            assert RunStepName.heuristic in completed_steps
            assert RunStepName.export in completed_steps

            # Verify artifacts exist
            listing = orch.sandbox.list_files()
            paths = [f.path for f in listing.files]
            assert "artifacts/compounds_validated.json" in paths
            assert "artifacts/standardized.json" in paths
            assert "artifacts/props_pka.json" in paths
            assert "artifacts/cns_mpo.json" in paths
            assert "artifacts/heuristic.json" in paths

            # Verify state counts
            assert final_state.n_compounds_input == 2

    def test_orchestrator_resumes_from_checkpoint(self):
        """Mark first 2 steps completed, run, verify only remaining steps execute."""
        with tempfile.TemporaryDirectory() as tmp:
            from bbnuke.agent.orchestrator import AgentOrchestrator

            # First run — create state with some steps completed
            sandbox = WorkspaceSandbox(run_id="resume_test", runs_dir=tmp)
            sandbox.init()
            sm = RunStateManager(sandbox=sandbox)
            state = sm.load_or_create("resume_test", TierName.tier_a)

            # Pre-place artifacts as if ingest + standardize already ran
            csv_data = json.dumps([
                {"compound_id": "test1", "smiles": "c1ccccc1", "smiles_input": "c1ccccc1",
                 "smiles_standardized": "c1ccccc1", "is_valid": True, "error": None},
            ])
            sandbox.write_file("artifacts/compounds_validated.json",
                json.dumps([{"compound_id": "test1", "smiles": "c1ccccc1"}]))
            sandbox.write_file("artifacts/standardized.json", csv_data)

            state.steps[0].status = StepStatus.completed  # ingest
            state.steps[1].status = StepStatus.completed  # standardize
            state.n_compounds_input = 1
            sm.save(state)

            # Now run — should skip ingest and standardize
            orch = AgentOrchestrator(
                run_id="resume_test",
                tier=TierName.tier_a,
                runs_dir=tmp,
            )
            final_state = _run(orch.run())

            # Ingest and standardize should still be completed (not re-run)
            assert final_state.steps[0].status == StepStatus.completed
            assert final_state.steps[1].status == StepStatus.completed
            # props_pka should have been executed
            assert final_state.steps[2].status == StepStatus.completed
            assert final_state.steps[2].name == RunStepName.props_pka
