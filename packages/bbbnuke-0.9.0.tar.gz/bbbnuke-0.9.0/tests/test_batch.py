"""Tests for batch endpoints and database layer.

Tests the DB models, job creation, and batch submission.
Redis-dependent tests (polling, results) are integration tests
that require a running Redis instance.
"""

from __future__ import annotations

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from bbnuke.db.models import Base, CompoundResult, Job


# ---------------------------------------------------------------------------
# DB fixtures (in-memory SQLite)
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture
async def db_engine():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(db_engine):
    factory = async_sessionmaker(db_engine, expire_on_commit=False)
    async with factory() as session:
        yield session


# ---------------------------------------------------------------------------
# DB Model Tests
# ---------------------------------------------------------------------------

class TestJobModel:
    @pytest.mark.asyncio
    async def test_create_job(self, db_session: AsyncSession):
        job = Job(
            id="test-job-1",
            status="pending",
            total_compounds=10,
            completed_compounds=0,
            current_stage="queued",
        )
        db_session.add(job)
        await db_session.commit()

        from sqlalchemy import select
        result = await db_session.execute(select(Job).where(Job.id == "test-job-1"))
        fetched = result.scalar_one()
        assert fetched.status == "pending"
        assert fetched.total_compounds == 10
        assert fetched.pct == 0.0

    @pytest.mark.asyncio
    async def test_job_progress(self, db_session: AsyncSession):
        job = Job(
            id="test-job-2",
            status="running",
            total_compounds=100,
            completed_compounds=50,
        )
        db_session.add(job)
        await db_session.commit()
        assert job.pct == 50.0

    @pytest.mark.asyncio
    async def test_job_with_config(self, db_session: AsyncSession):
        job = Job(
            id="test-job-3",
            config_json={"mpo_cutoff": 4.0, "logistic_k": 0.15},
        )
        db_session.add(job)
        await db_session.commit()

        from sqlalchemy import select
        result = await db_session.execute(select(Job).where(Job.id == "test-job-3"))
        fetched = result.scalar_one()
        assert fetched.config_json["mpo_cutoff"] == 4.0


class TestCompoundResultModel:
    @pytest.mark.asyncio
    async def test_create_result(self, db_session: AsyncSession):
        job = Job(id="test-job-cr", total_compounds=1)
        db_session.add(job)
        await db_session.flush()

        result = CompoundResult(
            job_id="test-job-cr",
            compound_id="ethanol",
            smiles="CCO",
            p_bbb=0.55,
            cns_mpo_score=4.2,
            passed_mpo=True,
            result_json={"compound_id": "ethanol", "p_bbb": 0.55},
        )
        db_session.add(result)
        await db_session.commit()

        from sqlalchemy import select
        rows = await db_session.execute(
            select(CompoundResult).where(CompoundResult.job_id == "test-job-cr")
        )
        fetched = rows.scalar_one()
        assert fetched.compound_id == "ethanol"
        assert fetched.p_bbb == 0.55
        assert fetched.result_json["p_bbb"] == 0.55

    @pytest.mark.asyncio
    async def test_cascade_delete(self, db_session: AsyncSession):
        job = Job(id="test-job-cascade", total_compounds=1)
        db_session.add(job)
        await db_session.flush()

        result = CompoundResult(
            job_id="test-job-cascade",
            compound_id="test",
            smiles="C",
        )
        db_session.add(result)
        await db_session.commit()

        await db_session.delete(job)
        await db_session.commit()

        from sqlalchemy import select
        rows = await db_session.execute(
            select(CompoundResult).where(CompoundResult.job_id == "test-job-cascade")
        )
        assert rows.first() is None


# ---------------------------------------------------------------------------
# Worker unit tests (no Redis needed)
# ---------------------------------------------------------------------------

class TestCpuWorker:
    @pytest.mark.asyncio
    async def test_score_single_task(self):
        from bbnuke.workers.cpu_worker import score_single
        result = await score_single(
            ctx={},
            smiles="c1ccc2c(c1)c1ccccc1[nH]2",
            compound_id="carbazole",
        )
        assert result["compound_id"] == "carbazole"
        assert result["smiles_standardized"]
        assert 0 <= result["cns_mpo"]["score"] <= 6

    @pytest.mark.asyncio
    async def test_score_batch_chunk_task(self):
        from bbnuke.workers.cpu_worker import score_batch_chunk
        compounds = [
            {"compound_id": "ethanol", "smiles": "CCO"},
            {"compound_id": "carbazole", "smiles": "c1ccc2c(c1)c1ccccc1[nH]2"},
        ]
        result = await score_batch_chunk(
            ctx={},
            compounds_data=compounds,
            job_id="test-chunk",
            chunk_index=0,
        )
        assert result["chunk_index"] == 0
        assert result["job_id"] == "test-chunk"
        assert len(result["results"]) == 2
        assert result["results"][0]["compound_id"] == "ethanol"


# ---------------------------------------------------------------------------
# API endpoint tests (batch submission — mocked Redis)
# ---------------------------------------------------------------------------

class TestBatchAPI:
    def test_batch_empty_compounds(self):
        """Empty compounds list should return 400."""
        from fastapi.testclient import TestClient
        from bbnuke.api.app import create_app

        app = create_app()
        with TestClient(app) as client:
            r = client.post("/v1/batch", json={"compounds": []})
            assert r.status_code == 400

    def test_batch_validation(self):
        """Compounds without required fields should return 422."""
        from fastapi.testclient import TestClient
        from bbnuke.api.app import create_app

        app = create_app()
        with TestClient(app) as client:
            r = client.post("/v1/batch", json={
                "compounds": [{"smiles": "CCO"}]  # missing compound_id
            })
            assert r.status_code == 422
