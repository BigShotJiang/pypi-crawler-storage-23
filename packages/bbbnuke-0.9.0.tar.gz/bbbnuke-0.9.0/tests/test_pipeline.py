"""Tests for the BBB-Nuke pipeline."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from bbnuke.core.schemas import AffinityScore, CompoundInput, PkaSource
from bbnuke.modules.standardize import standardize_smiles
from bbnuke.modules.properties import compute_properties
from bbnuke.modules.cns_mpo import compute_cns_mpo
from bbnuke.modules.heuristic import compute_heuristic
from bbnuke.pipeline.runner import run_single


# --- Standardizer ---

def test_standardize_canonical():
    assert standardize_smiles("c1ccccc1") == "c1ccccc1"  # benzene


def test_standardize_salt_strip():
    result = standardize_smiles("CC(=O)[O-].[Na+]")
    assert "Na" not in result  # salt stripped


def test_standardize_invalid():
    with pytest.raises(ValueError):
        standardize_smiles("NOT_A_SMILES")


# --- Properties ---

def test_properties_aspirin():
    props = compute_properties("CC(=O)Oc1ccccc1C(=O)O")  # aspirin
    assert 170 < props.mw < 190
    assert props.hbd >= 1
    assert props.tpsa > 0


# --- CNS-MPO ---

def test_cns_mpo_basic():
    props = compute_properties("CC(=O)Oc1ccccc1C(=O)O")
    mpo = compute_cns_mpo(props, pka=7.5)
    assert 0 <= mpo.score <= 6
    assert mpo.pka_source == PkaSource.provided
    assert mpo.pka_used == 7.5
    assert mpo.passed_filter is True


def test_cns_mpo_placeholder_pka():
    props = compute_properties("c1ccccc1")
    mpo = compute_cns_mpo(props)
    assert mpo.pka_source == PkaSource.placeholder


# --- Heuristic ---

def test_heuristic_mpo_below_cutoff():
    result = compute_heuristic(mpo_score=2.5)
    assert result.p_bbb == 0.0
    assert "cutoff" in result.diagnostics.reason
    assert result.diagnostics.k == pytest.approx(0.1352)


def test_heuristic_mpo_only():
    result = compute_heuristic(mpo_score=5.0)
    assert result.p_bbb > 0.5  # should be above 0.5 for good MPO
    assert result.diagnostics.c_mpo == pytest.approx(3.5)


def test_heuristic_with_affinity():
    scores = [
        AffinityScore(protein_id="LAT1", score_raw=7.0, score_norm=0.7),
        AffinityScore(protein_id="GTR1", score_raw=5.0, score_norm=0.5),
    ]
    result = compute_heuristic(mpo_score=5.0, affinity_scores=scores)
    assert result.p_bbb > 0.0
    assert len(result.diagnostics.contributions) == 2
    # Check weighted_contribution is populated (w * p for scores above threshold)
    for c in result.diagnostics.contributions:
        if c.binding_prob >= 0.7:  # default per-protein threshold
            assert c.weighted_contribution == pytest.approx(c.weight * c.binding_prob)
        else:
            assert c.weighted_contribution == 0.0


def test_heuristic_efflux_veto():
    scores = [
        AffinityScore(protein_id="ABCB1", score_raw=8.0, score_norm=0.85),
    ]
    result = compute_heuristic(mpo_score=5.0, affinity_scores=scores)
    assert result.p_bbb == 0.0
    assert result.diagnostics.veto is True
    assert result.diagnostics.threshold == pytest.approx(0.7)


# --- Full pipeline ---

def test_pipeline_single():
    compound = CompoundInput(compound_id="aspirin", smiles="CC(=O)Oc1ccccc1C(=O)O")
    result = run_single(compound)
    assert result.compound_id == "aspirin"
    assert result.smiles_standardized
    assert result.properties.mw > 0
    assert 0 <= result.cns_mpo.score <= 6
    assert result.cns_mpo.passed_filter is True


def test_pipeline_with_pka():
    compound = CompoundInput(compound_id="test", smiles="c1ccc2[nH]ccc2c1")  # indole
    result = run_single(compound, pka=6.5)
    assert result.cns_mpo.pka_used == 6.5
    assert result.pka is not None
    assert result.pka.representative_pka == 6.5
    assert result.pka.source == PkaSource.provided


def test_pipeline_with_affinity():
    compound = CompoundInput(compound_id="test", smiles="c1ccccc1")
    scores = [AffinityScore(protein_id="LAT1", score_raw=7.0, score_norm=0.7)]
    result = run_single(compound, affinity_scores=scores)
    assert result.affinity is not None
    assert len(result.affinity.scores) == 1
    assert result.affinity_scores == result.affinity.scores


# --- Efflux screening ---

def test_pipeline_skips_efflux_when_affinity_provided():
    """When affinity_scores are already provided, efflux screen should NOT run."""
    compound = CompoundInput(compound_id="test", smiles="c1ccccc1")
    scores = [AffinityScore(protein_id="LAT1", score_raw=7.0, score_norm=0.7)]
    with patch("bbnuke.modules.efflux.run_efflux_screen") as mock_efflux:
        result = run_single(compound, affinity_scores=scores, run_efflux=True)
        mock_efflux.assert_not_called()
    assert result.affinity is not None


def test_pipeline_no_efflux_when_disabled():
    """When run_efflux=False, efflux screen should NOT run even without affinity."""
    compound = CompoundInput(compound_id="test", smiles="c1ccccc1")
    with patch("bbnuke.modules.efflux.run_efflux_screen") as mock_efflux:
        result = run_single(compound, run_efflux=False)
        mock_efflux.assert_not_called()
    assert result.heuristic is not None


def test_pipeline_calls_efflux_when_no_affinity():
    """When no affinity provided and run_efflux=True, should invoke efflux screen."""
    compound = CompoundInput(compound_id="test", smiles="c1ccccc1")
    mock_scores = [
        AffinityScore(protein_id="MDR1_HUMAN", score_raw=3.0, score_norm=0.3),
    ]
    with patch("bbnuke.modules.efflux.run_efflux_screen", return_value=mock_scores) as mock_efflux:
        result = run_single(compound, run_efflux=True)
        mock_efflux.assert_called_once()
    assert result.affinity is not None
    assert len(result.affinity.scores) == 1


def test_efflux_module_graceful_fallback():
    """If PSICHIC not available, run_efflux_screen returns empty list."""
    with patch("bbnuke.modules.efflux._psichic_available", return_value=False):
        from bbnuke.modules.efflux import run_efflux_screen
        scores = run_efflux_screen("c1ccccc1", "benzene")
        assert scores == []
