"""End-to-end integration test: CSV input → pKa + affinity → pipeline → results."""

from __future__ import annotations

import tempfile

import pytest

from bbnuke.core.schemas import CompoundInput, PkaSource
from bbnuke.modules.affinity import read_screening_csv
from bbnuke.modules.pka import read_pka_csv
from bbnuke.pipeline.runner import run_batch


@pytest.fixture
def pka_csv():
    content = (
        "compound,smiles,acid_pkas,base_pkas\n"
        "venlafaxine,OC1(c2ccc(OC)cc2)CC(CN(C)C)CC1,,5.667;6.785;4.657\n"
        "risperidone,c1ccc2c(c1)Cc1ccccc1C2=O,,8.123;6.5\n"
        "bad_compound,XXXX,,\n"
    )
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(content)
        return f.name


@pytest.fixture
def affinity_csv():
    rows = [
        "Compound_ID,Protein_ID,Ligand,Protein,Prediction",
        "venlafaxine,LAT1,SMILES,SEQ,7.2",
        "venlafaxine,GTR1,SMILES,SEQ,5.5",
        "venlafaxine,ABCB1,SMILES,SEQ,3.0",
        "risperidone,LAT1,SMILES,SEQ,6.8",
        "risperidone,GTR1,SMILES,SEQ,4.1",
    ]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write("\n".join(rows))
        return f.name


def test_end_to_end_with_pka_and_affinity(pka_csv, affinity_csv):
    """Full pipeline: pKa CSV + affinity CSV → heuristic results."""
    pka_map = read_pka_csv(pka_csv, id_col="compound")
    affinity_map = read_screening_csv(affinity_csv)

    compounds = [
        CompoundInput(compound_id="venlafaxine", smiles="OC1(c2ccc(OC)cc2)CC(CN(C)C)CC1"),
        CompoundInput(compound_id="risperidone", smiles="c1ccc2c(c1)Cc1ccccc1C2=O"),
    ]

    results = run_batch(compounds, pka_map=pka_map, affinity_map=affinity_map)

    assert len(results) == 2

    # Venlafaxine
    v = results[0]
    assert v.compound_id == "venlafaxine"
    assert v.cns_mpo.pka_used == pytest.approx(6.785)  # max basic
    assert v.cns_mpo.pka_source == PkaSource.provided
    assert v.passed_mpo_filter  # venlafaxine is a CNS drug, should pass
    assert v.heuristic is not None
    assert v.heuristic.p_bbb > 0.0
    assert len(v.affinity_scores) == 3
    assert v.heuristic.diagnostics.veto is False  # ABCB1 at 0.3 < 0.7

    # Risperidone
    r = results[1]
    assert r.compound_id == "risperidone"
    assert r.cns_mpo.pka_used == pytest.approx(8.123)  # max basic
    assert r.heuristic is not None
    assert len(r.affinity_scores) == 2


def test_end_to_end_efflux_veto(affinity_csv):
    """Efflux veto should trigger when ABCB1 binding >= 0.7."""
    # Modify: high ABCB1 binding
    rows = [
        "Compound_ID,Protein_ID,Ligand,Protein,Prediction",
        "test_drug,LAT1,C,SEQ,6.0",
        "test_drug,ABCB1,C,SEQ,8.5",  # 0.85 > 0.7 → veto
    ]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write("\n".join(rows))
        f.flush()
        affinity_map = read_screening_csv(f.name)

    compounds = [CompoundInput(compound_id="test_drug", smiles="c1ccccc1")]
    results = run_batch(compounds, affinity_map=affinity_map)

    r = results[0]
    assert r.passed_mpo_filter
    assert r.heuristic is not None
    assert r.heuristic.p_bbb == 0.0
    assert r.heuristic.diagnostics.veto is True
    assert r.heuristic.diagnostics.veto_protein == "ABCB1"
