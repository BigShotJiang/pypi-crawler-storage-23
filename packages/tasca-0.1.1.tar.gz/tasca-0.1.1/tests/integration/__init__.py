"""
Integration tests for shell module.

These tests verify I/O operations with actual storage/API.
"""
