"""
Unit tests for core module.

These tests verify pure business logic without I/O.
"""
