"""Tests for shell services."""
