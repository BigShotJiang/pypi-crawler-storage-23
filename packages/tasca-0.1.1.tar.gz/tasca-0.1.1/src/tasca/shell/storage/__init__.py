"""
Storage package - SQLite repositories.

This package contains repository implementations that persist
domain objects to SQLite storage.
"""

# Storage implementations will be here
