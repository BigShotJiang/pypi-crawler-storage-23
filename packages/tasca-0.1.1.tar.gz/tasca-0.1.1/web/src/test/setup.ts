/**
 * Test setup for vitest.
 * Configures @testing-library/jest-dom matchers.
 */
import '@testing-library/jest-dom'