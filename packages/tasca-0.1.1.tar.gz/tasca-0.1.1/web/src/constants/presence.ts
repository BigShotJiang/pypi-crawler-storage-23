/**
 * Shared presence-related constants.
 *
 * Source: docs/tasca-design-notes.md — presence threshold definitions.
 * Extracted from SeatDeck.tsx (web_fix4.s2) to remove lateral component coupling.
 */

/** Seconds of inactivity before a seat is considered idle. */
export const IDLE_THRESHOLD_SECONDS = 60
