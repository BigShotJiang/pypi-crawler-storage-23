"""
Frankenreview - Configuration Loader

Canonical configuration loading logic.
Implements a 3-level Config Cascade:
  Level 1 (Global)  — dev-root config.yaml OR installed package config.yaml
  Level 2 (Local)   — project_root/.frankenreview/config.yaml (repo-specific overrides)
  Level 3 (CLI)     — direct flags (handled by callers, always win)

Local values win over global on a per-key basis (deep merge).
This enables Zero-Global-Config portability: commit .frankenreview/config.yaml
and any dev or agent that clones the repo gets the same prune settings.
"""

import os
import yaml
import importlib.resources
from pathlib import Path


def _deep_merge(base: dict, override: dict) -> dict:
    """
    Recursively merge *override* into *base*.

    Rules:
    - Dicts are merged recursively.
    - Lists (e.g. prune_dirs) are replaced in full by the override value.
    - All other scalar values are replaced by the override value.
    """
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _load_global_config(explicit_path=None) -> dict:
    """
    Load the global (Level 1) configuration.

    Resolution order:
    1. Explicit path argument (if file exists)
    2. FR_CONFIG_PATH environment variable
    3. Dev-root config.yaml (editable / development install)
    4. Installed package data config.yaml (pip install)
    5. Minimal fallback dict
    """
    config_path = explicit_path
    if config_path and not os.path.exists(str(config_path)):
        config_path = None

    if config_path is None:
        env_path = os.environ.get('FR_CONFIG_PATH')
        if env_path and os.path.exists(env_path):
            config_path = env_path
        else:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # utils/ -> frankenreview/ -> src/ -> ROOT
            dev_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
            dev_config = os.path.join(dev_root, "config.yaml")

            if os.path.exists(dev_config):
                config_path = dev_config
            else:
                try:
                    with importlib.resources.path('frankenreview', 'config.yaml') as pkg_cfg:
                        config_path = str(pkg_cfg)
                except (ImportError, FileNotFoundError, TypeError):
                    config_path = "config.yaml"

    if not config_path or not os.path.exists(config_path):
        return {"project_root": "."}

    with open(config_path, encoding='utf-8') as f:
        return yaml.safe_load(f) or {}


def load_config(config_path=None, project_root=None):
    """
    Load configuration with 3-level cascade.

    Args:
        config_path:  Optional explicit path to global config (Level 1).
        project_root: Optional path to the project being reviewed. When
                      provided, .frankenreview/config.yaml inside that folder
                      is loaded as the Level 2 local override.

    Returns:
        dict: Merged configuration. Local values win over global.
    """
    global_cfg = _load_global_config(config_path)

    # Determine where to look for the local override
    root = Path(project_root) if project_root else Path(os.getcwd())
    local_path = root / ".frankenreview" / "config.yaml"

    if local_path.exists():
        with open(local_path, encoding='utf-8') as f:
            local_cfg = yaml.safe_load(f) or {}
        return _deep_merge(global_cfg, local_cfg)

    return global_cfg


def get_effective_config_path():
    """
    Returns the path to the config file that will be used.
    Used for tools that need to write back to the config.
    """
    from .workspace import get_config_path
    
    # Check environment variable first
    env_path = os.environ.get('FR_CONFIG_PATH')
    if env_path and os.path.exists(env_path):
        return env_path
        
    # Check .frankenreview/config.yaml (preferred repo-specific path)
    dot_fr_config = get_config_path(os.getcwd())
    if dot_fr_config.exists():
        return str(dot_fr_config)
        
    # Fallback to current directory config.yaml if it exists
    if os.path.exists("config.yaml"):
        return os.path.abspath("config.yaml")
        
    # Default to .frankenreview/config.yaml (creation target)
    return str(dot_fr_config)
