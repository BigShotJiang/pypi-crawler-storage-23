"""
Frankenreview v11 - Prune Configuration Management (prune_config.py)

Provides CLI-accessible functions for managing prune lists (dirs, files, extensions)
that control what gets excluded from code review dumps.

Write target: .frankenreview/config.yaml (local, repo-specific overrides).
Read source:  global config.yaml merged with local .frankenreview/config.yaml.

This achieves Zero-Global-Config portability:
- Mutations never pollute the global selector/URL config.
- The local override can be committed to the repo so every agent or developer
  that clones it automatically inherits the project's prune settings.
"""

import os
import yaml
from pathlib import Path
from typing import List, Literal

# Categories for prune lists
PruneCategory = Literal["dirs", "files", "exts"]


def _get_global_config_path() -> Path:
    """
    Locate the global config.yaml (dev-root or installed package).

    Returns:
        Path to global config.yaml, or None if not found.
    """
    current_dir = Path(__file__).parent
    # src/frankenreview/utils -> src/frankenreview -> src -> ROOT
    project_root = current_dir.parent.parent.parent
    dev_config = project_root / "config.yaml"
    if dev_config.exists():
        return dev_config

    # Installed package fallback
    try:
        import importlib.resources
        with importlib.resources.path('frankenreview', 'config.yaml') as pkg_cfg:
            return Path(str(pkg_cfg))
    except (ImportError, FileNotFoundError, TypeError):
        return None


def _get_local_config_path() -> Path:
    """
    Return the local repo-specific override path: .frankenreview/config.yaml
    resolved from the current working directory.

    Returns:
        Path object (may not exist yet).
    """
    return Path(os.getcwd()) / ".frankenreview" / "config.yaml"


def _load_config() -> dict:
    """
    Load the effective prune configuration using the cascade:
    global config.yaml merged with .frankenreview/config.yaml (local wins).

    Returns:
        Merged configuration dictionary.
    """
    from .config_loader import _load_global_config, _deep_merge

    global_cfg = _load_global_config()
    local_path = _get_local_config_path()
    if local_path.exists():
        with open(local_path, 'r', encoding='utf-8') as f:
            local_cfg = yaml.safe_load(f) or {}
        return _deep_merge(global_cfg, local_cfg)
    return global_cfg


def _save_config(config: dict) -> None:
    """
    Persist the updated configuration to the local .frankenreview/config.yaml.

    Only prune-related keys are stored in the local file to avoid bloating it
    with global selector and URL settings that belong in the global config.
    On first creation, prints a notice so the agent / user knows a local
    config file was bootstrapped.

    Args:
        config: Full merged configuration dict (only prune keys are extracted).
    """
    local_path = _get_local_config_path()
    is_new = not local_path.exists()

    # Ensure .frankenreview/ directory exists
    local_path.parent.mkdir(parents=True, exist_ok=True)

    # Load existing local config to merge into (preserves any existing keys)
    existing_local: dict = {}
    if not is_new:
        with open(local_path, 'r', encoding='utf-8') as f:
            existing_local = yaml.safe_load(f) or {}

    # Extract only the prune keys we manage
    prune_keys = ('prune_dirs', 'prune_files', 'prune_exts')
    for key in prune_keys:
        if key in config:
            existing_local[key] = config[key]

    with open(local_path, 'w', encoding='utf-8') as f:
        yaml.dump(existing_local, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    if is_new:
        print(f"[+] Local config created at {local_path}")


def _get_list_key(category: PruneCategory) -> str:
    """
    Get the config key for a prune category.
    
    Args:
        category: "dirs", "files", or "exts"
        
    Returns:
        Config key name
    """
    return {
        "dirs": "prune_dirs",
        "files": "prune_files",
        "exts": "prune_exts"
    }[category]


def get_prune_list(category: PruneCategory) -> List[str]:
    """
    Get the current prune list for a category.
    
    Args:
        category: "dirs", "files", or "exts"
        
    Returns:
        List of items in that prune category
    """
    config = _load_config()
    key = _get_list_key(category)
    return config.get(key, [])


def add_to_prune_list(category: PruneCategory, item: str) -> bool:
    """
    Add an item to a prune list (persistent).
    
    Args:
        category: "dirs", "files", or "exts"
        item: Item to add
        
    Returns:
        True if added, False if already exists
    """
    config = _load_config()
    key = _get_list_key(category)
    
    current_list = config.get(key, [])
    if current_list is None:
        current_list = []
    
    # Normalize item
    item = item.strip()
    if category == "exts" and not item.startswith("."):
        item = "." + item
    
    if item in current_list:
        return False  # Already exists
    
    current_list.append(item)
    config[key] = current_list
    _save_config(config)
    return True


def remove_from_prune_list(category: PruneCategory, item: str) -> bool:
    """
    Remove an item from a prune list (persistent).
    
    Args:
        category: "dirs", "files", or "exts"
        item: Item to remove
        
    Returns:
        True if removed, False if not found
    """
    config = _load_config()
    key = _get_list_key(category)
    
    current_list = config.get(key, [])
    if current_list is None:
        current_list = []
    
    # Normalize item
    item = item.strip()
    if category == "exts" and not item.startswith("."):
        item = "." + item
    
    if item not in current_list:
        return False  # Not found
    
    current_list.remove(item)
    config[key] = current_list
    _save_config(config)
    return True


def list_prune_config() -> str:
    """
    Generate a formatted string of the current prune configuration.
    
    Returns:
        Formatted prune configuration string
    """
    config = _load_config()
    
    prune_dirs = config.get("prune_dirs", [])
    prune_files = config.get("prune_files", [])
    prune_exts = config.get("prune_exts", [])
    
    lines = []
    lines.append("=" * 60)
    lines.append("FRANKENREVIEW PRUNE CONFIGURATION")
    lines.append("=" * 60)
    lines.append("")
    
    # Directories
    lines.append(f"PRUNE_DIRS ({len(prune_dirs)} items):")
    lines.append("-" * 40)
    if prune_dirs:
        for d in sorted(prune_dirs):
            lines.append(f"  {d}/")
    else:
        lines.append("  (none)")
    lines.append("")
    
    # Files
    lines.append(f"PRUNE_FILES ({len(prune_files)} items):")
    lines.append("-" * 40)
    if prune_files:
        for f in sorted(prune_files):
            lines.append(f"  {f}")
    else:
        lines.append("  (none)")
    lines.append("")
    
    # Extensions
    lines.append(f"PRUNE_EXTS ({len(prune_exts)} items):")
    lines.append("-" * 40)
    if prune_exts:
        for e in sorted(prune_exts):
            lines.append(f"  {e}")
    else:
        lines.append("  (none)")
    lines.append("")
    
    lines.append("=" * 60)
    lines.append("Use --prune-add-* and --prune-remove-* to modify these lists.")
    lines.append("=" * 60)
    
    return "\n".join(lines)
