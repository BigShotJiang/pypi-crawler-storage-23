"""
Frankenreview v11 - Workspace Management (workspace.py)

Manages the per-repo .frankenreview/ folder for all artifacts:
- dumps/     - XML code snapshots
- review.md  - Latest review output
- SKILL.md   - AI agent skill descriptor (auto-generated)

This module handles folder creation and automatic .gitignore updates.
"""

import os
from pathlib import Path

# The canonical folder name for Frankenreview artifacts
FR_FOLDER_NAME = ".frankenreview"


def get_fr_folder(project_root: str) -> Path:
    """
    Get the .frankenreview folder path for a project.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        Path to the .frankenreview folder
    """
    return Path(project_root) / FR_FOLDER_NAME


def ensure_fr_folder(project_root: str) -> Path:
    """
    Ensure the .frankenreview folder exists and is gitignored.
    
    Creates the folder structure:
    .frankenreview/
    ├── dumps/          # XML code snapshots
    ├── state.json      # VS Code extension state
    └── latest_prompt.txt
    
    Args:
        project_root: Root path of the project
        
    Returns:
        Path to the .frankenreview folder
    """
    fr_folder = get_fr_folder(project_root)
    
    # Create folder structure
    fr_folder.mkdir(parents=True, exist_ok=True)
    (fr_folder / "dumps").mkdir(exist_ok=True)
    
    # Auto-add to .gitignore if it exists
    _ensure_gitignored(project_root)
    
    # Auto-generate SKILL.md for Agents
    _ensure_skill_md(fr_folder)
    
    return fr_folder


def _ensure_skill_md(fr_folder: Path) -> None:
    """
    Write SKILL.md for AI Agents into the .frankenreview folder.

    Always overwrites so that the auto-generated reference stays current with
    the installed package version. Called before argparse so --help also
    triggers it.
    """
    skill_path = fr_folder / "SKILL.md"
    fr_folder.mkdir(parents=True, exist_ok=True)

    content = """\

# Frankenreview

Agentic code review and research tool powered by Gemini via Chrome automation.
Outputs structured, severity-tagged Markdown findings — no API key, no cost.

---

## Prerequisites

Chrome must be running with remote debugging before any browser-dependent command:

    frankenreview --start-chrome

User must be logged into Google AI Studio (https://aistudio.google.com) in that
Chrome window. This is required only for commands that actually send to the AI
(review, research, open-chat). Commands like --dump, --self-check, --prune-* do
NOT require Chrome.

---

## Core Workflows

### 1. One-Shot Code Review (default)

    frankenreview -r
    frankenreview            # -r is the default

Output: `.frankenreview/review.md`
Exit codes: 0 = success, 1 = error.

Key flags:

    --path <dir>           Target project (default: git root or cwd)
    --output <file>        Output path (default: .frankenreview/review.md)
    --model <id>           Model override (e.g. gemini-2.5-pro, gemini-2.5-flash)
    --prompt <name|path>   Built-in prompt (audit, fullstack, consolidation) or
                           path to custom .md file
    --prune-changelogs     Exclude CHANGELOG files to reduce hallucination
    --json                 Append JSON schema to force structured output
    --attach <file>        Attach an extra file alongside the repo dump
                           (repeatable: --attach a.txt --attach b.py)
    --verbose              Show detailed browser automation steps

### 2. Session Management (Multi-Turn Context)

Frankenreview saves the chat URL after each review so you can continue the
same conversation thread for iterative refinement.

    # Continue the last saved chat session for the next review
    frankenreview -r --continue

    # Start a fresh session and save it for future --continue calls
    frankenreview -r --continue-new

    # Delete the saved session from AI Studio and clear the URL file
    frankenreview --delete-chat

NOTE: --continue and --open-chat are NOT the same thing:
  --continue   : modifier flag used WITH -r. Resumes the saved session URL so
                 the next review goes into the same chat thread (multi-turn).
  --open-chat  : standalone command. Bypasses the review pipeline entirely and
                 opens a raw chat window for freeform prompting and file uploads.

### 3. Open Chat (Direct AI Interaction)

Opens an AI Studio chat without running a code review. Useful for sending
arbitrary files or freeform prompts directly.

    # Open chat and send a freeform prompt
    frankenreview --open-chat --prompt "Explain the scaling strategy"

    # Attach a file and send a prompt
    frankenreview --open-chat --attach report.txt --prompt "Summarize this"

    # Attach multiple files
    frankenreview --open-chat --attach a.py --attach b.py --prompt "Compare these"

    # Open chat and resume last session (if no --attach provided)
    frankenreview --open-chat --prompt "Follow-up question"

    # Save response to a file
    frankenreview --open-chat --prompt "..." --output .frankenreview/notes.md

### 4. Deep Scan (Multi-Cycle Review)

    frankenreview --deep-scan --cycles 3    # 3 recursive review cycles
    frankenreview --deep-scan --resume      # Resume interrupted scan

### 5. Research Mode

    frankenreview --research --prompt research_topic.md --output findings.md

Output: `.frankenreview/research_<timestamp>.md` (with Executive Summary +
Key Findings sections).

### 6. Consolidation Mode

Focused structural + standardisation review using the consolidation prompt:

    frankenreview --consolidation

Equivalent to: `frankenreview -r --prompt consolidation`

### 7. Planner Mode

Critique a plan.md file against the current codebase:

    frankenreview --planner --prompt plan.md

---

## Repository Commands (no Chrome required)

### Dump

    frankenreview --dump
    frankenreview --dump --path /other/repo

Output line: `[+] Dump generated: .frankenreview/dumps/Repo.xml (1.4 MB) in 87ms`

### Token Analysis

Identify which files consume the most tokens:

    frankenreview --token-eaters

### Self-Check

    frankenreview --self-check            # Human-readable
    frankenreview --self-check --json     # JSON: {"overall":"passed", ...}

---

## Prune Configuration (no Chrome required)

Prune rules control which files/dirs are excluded from the context dump.
Mutations write ONLY to the project-local `.frankenreview/config.yaml` — the
global package config is never touched.

    frankenreview --prune-list                        # Show current rules
    frankenreview --prune-add-dir    node_modules     # Add dir to exclude
    frankenreview --prune-remove-dir node_modules     # Remove dir
    frankenreview --prune-add-file   package-lock.json
    frankenreview --prune-remove-file package-lock.json
    frankenreview --prune-add-ext    .csv
    frankenreview --prune-remove-ext .csv

On first use in a project, the local config is auto-created:

    [+] Local config created at /path/to/project/.frankenreview/config.yaml

Config cascade (highest wins): CLI flags > .frankenreview/config.yaml > global config

---

## Model Management (no Chrome required)

    frankenreview --available-models    # Show cached model list
    frankenreview --fetch-models        # Re-fetch from Google AI docs and update cache

---

## Chrome Management

    frankenreview --start-chrome                     # Start on default port 9222
    frankenreview --start-chrome --port 9223         # Custom port (parallel instance)
    frankenreview --start-chrome --profile work      # Named profile
    frankenreview --stop-chrome
    frankenreview --chrome-stats                     # Memory / performance stats

---

## Prompt Management

    frankenreview --create-prompt my-custom          # Create & open new prompt file
    frankenreview --prompt-edit                      # Edit current prompt in $EDITOR
    frankenreview --workflow                         # Print release workflow guide
    frankenreview --rigour                           # Print RIGOUR doctrine

---

## Agentic Integration Pattern

    # 1. Verify install
    frankenreview --self-check --json

    # 2. Identify token-heavy garbage
    frankenreview --token-eaters

    # 3. Prune large dirs from context
    frankenreview --prune-add-dir data

    # 4. Run review
    frankenreview -r --prune-changelogs

    # 5. Read findings
    cat .frankenreview/review.md

    # 6. Implement fixes, then iterate in the same chat thread
    frankenreview -r --continue

    # 7. Cleanup when done
    frankenreview --delete-chat

---

## Output Structure

`.frankenreview/review.md` uses severity tags:
  [CRITICAL], [HIGH], [MEDIUM], [LOW]

Each finding: file reference, line number, explanation, suggested fix.

---

## File Locations

- `.frankenreview/review.md`          — Latest review output
- `.frankenreview/dumps/`             — XML context dumps
- `.frankenreview/last_chat_url.txt`  — Saved session URL for --continue
- `.frankenreview/config.yaml`        — Project-local config overrides
- `.frankenreview/SKILL.md`           — This file (auto-generated, always current)

---

## Error Reference

| Error                         | Fix                                                          |
|-------------------------------|--------------------------------------------------------------|
| Chrome not found              | Run `--start-chrome`                                         |
| Not logged into AI Studio     | Open Chrome, login to aistudio.google.com                    |
| Session expired               | Run without `--continue` to start fresh                      |
| Selector not found            | Run `--discover-selectors`                                   |
| Model not found               | Run `--fetch-models` then `--available-models`               |
| Rate limit                    | Model failover is automatic; wait and retry if it persists   |
| Unsupported file format       | Use .txt; XML files are auto-converted                       |
| Timeout during generation     | Try `--visible` to watch the browser automation live         |
"""
    try:
        with open(skill_path, 'w', encoding='utf-8') as f:
            f.write(content)
    except Exception:
        pass


def get_dump_dir(project_root: str) -> Path:
    """
    Get the dumps directory for a project.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        Path to the dumps directory
    """
    fr_folder = ensure_fr_folder(project_root)
    return fr_folder / "dumps"


def _ensure_gitignored(project_root: str) -> bool:
    """
    Ensure .frankenreview/ is in .gitignore if the file exists.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        True if .gitignore was updated, False otherwise
    """
    gitignore_path = Path(project_root) / ".gitignore"
    
    if not gitignore_path.exists():
        return False
    
    # Read existing .gitignore
    try:
        with open(gitignore_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            lines = content.splitlines()
    except Exception:
        return False
    
    # Check if already ignored (various formats)
    ignore_patterns = [
        FR_FOLDER_NAME,
        f"{FR_FOLDER_NAME}/",
        f"/{FR_FOLDER_NAME}",
        f"/{FR_FOLDER_NAME}/",
    ]
    
    for pattern in ignore_patterns:
        if pattern in lines or pattern.strip() in [l.strip() for l in lines]:
            return False  # Already ignored
    
    # Add to .gitignore
    try:
        with open(gitignore_path, 'a', encoding='utf-8') as f:
            # Add newline if file doesn't end with one
            if content and not content.endswith('\n'):
                f.write('\n')
            f.write(f"\n# Frankenreview artifacts\n{FR_FOLDER_NAME}/\n")
        return True
    except Exception:
        return False



def get_config_path(project_root: str) -> Path:
    """
    Get the canonical config.yaml path for a project.

    Args:
        project_root: Root path of the project

    Returns:
        Path to config.yaml in the .frankenreview folder
    """
    return ensure_fr_folder(project_root) / "config.yaml"


# Session URL Management (v11.5)
SESSION_URL_FILE = "last_chat_url.txt"


def get_session_url_path(project_root: str) -> Path:
    """
    Get the path to the session URL file.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        Path to the last_chat_url.txt file
    """
    return get_fr_folder(project_root) / SESSION_URL_FILE


def save_session_url(project_root: str, url: str) -> None:
    """
    Save the current chat URL for session continuation.
    
    Args:
        project_root: Root path of the project
        url: The AI Studio chat URL to save
    """
    session_path = get_session_url_path(project_root)
    session_path.parent.mkdir(parents=True, exist_ok=True)
    session_path.write_text(url, encoding='utf-8')


def load_session_url(project_root: str) -> str | None:
    """
    Load a saved chat URL for session continuation.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        The saved URL or None if no session exists
    """
    session_path = get_session_url_path(project_root)
    if session_path.exists():
        url = session_path.read_text(encoding='utf-8').strip()
        return url if url else None
    return None


def delete_session_url(project_root: str) -> bool:
    """
    Delete the saved session URL file.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        True if file was deleted, False if it didn't exist
    """
    session_path = get_session_url_path(project_root)
    if session_path.exists():
        session_path.unlink()
        return True
    return False