"""
Shared UI helpers for Frankenreview.
"""

import sys
import time
import select
import platform

def prompt_with_timeout(message: str, timeout: int = 5, default: str = 'y') -> str:
    """
    Prompt user for input with a timeout.
    Returns default if timeout reached.
    """
    print(f"{message} (timeout {timeout}s, default '{default}'): ", end='', flush=True)
    
    if platform.system() == "Windows":
        try:
            import msvcrt
            start_time = time.time()
            inp = ""
            while time.time() - start_time < timeout:
                if msvcrt.kbhit():
                    char = msvcrt.getche().decode()
                    if char in ('\r', '\n'):
                        print()
                        return inp
                    inp += char
                time.sleep(0.1)
            print(f"\n[i] Timeout reached, using default '{default}'")
            return default
        except ImportError:
            try:
                # Basic input if msvcrt fails
                return input()
            except EOFError:
                return default
    
    # Unix-like (Mac/Linux)
    try:
        rlist, _, _ = select.select([sys.stdin], [], [], timeout)
        if rlist:
            res = sys.stdin.readline().strip().lower()
            return res if res else default
        else:
            print(f"\n[i] Timeout reached, using default '{default}'")
            return default
    except Exception:
        # Fallback for environments where select/stdin might be tricky
        import os
        if not os.isatty(sys.stdin.fileno()):
             return default
        return default
