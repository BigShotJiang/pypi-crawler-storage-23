# DEEP SCAN: RECURSIVE BUG HUNT

**MODE**: Recursive Depth.
**TASK**: Review the codebase for **NEW, HIDDEN flaws** that were missed in the previous cycle.

## INSTRUCTIONS

1.  **IGNORE** issues already documented in the attached `review.md` (or `deep-review.md`). Do NOT repeat them.
2.  **DIG DEEPER**: Look for:
    *   Race conditions in specific functions.
    *   Edge cases in data handling.
    *   Security vulnerabilities in dependencies.
    *   Performance bottlenecks in loops/queries.
3.  **NO ARCHITECTURE**: Do not comment on high-level architecture unless it is a localized implementation flaw.
4.  **EVIDENCE**: You must pinpoint the exact line numbers and logic.

## OUTPUT FORMAT

Provide a markdown report of **NEW FINDINGS ONLY**:

### [P0/P1] New Critical Findings
*List bugs missed in previous cycle.*

### [P2] Edge Cases
*List subtle logic errors.*

---
**Constraint**: If you find nothing new, output "NO NEW FINDINGS."
