"""
Frankenreview - Command Line Interface (v11 - Lean Pivot)

Provides a global CLI for AI agents and developers to run code reviews and research.
Streamlined for stateless, fast, deterministic execution.

Usage:
    frankenreview                       # One-shot review of current directory (default)
    frankenreview -r --path /some/dir   # Review specific directory
    frankenreview --research --prompt topic.md  # Research mode
    frankenreview --deep-scan           # Multi-cycle deep scan
    frankenreview --start-chrome        # Start Chrome with debugging
    frankenreview --help                # Show help
"""

from . import __version__

import argparse
import os

# Suppress Node.js deprecation warnings from Playwright/upstream
os.environ["NODE_OPTIONS"] = "--no-deprecation"

import sys
import time
import subprocess
import socket
import platform
from pathlib import Path
from typing import Optional

from .utils.log_config import setup_logging, get_logger


def edit_file(filepath: Path) -> None:
    """Open a file in the system default editor."""
    if not filepath.exists():
        print(f"[!] File not found: {filepath}")
        return

    editor = os.environ.get('EDITOR', 'nano')
    try:
        import shlex
        subprocess.call(shlex.split(editor) + [str(filepath)])
    except FileNotFoundError:
        # Fallback
        print(f"[!] Editor '{editor}' not found. Trying 'vi'...")
        subprocess.call(['vi', str(filepath)])



def is_port_in_use(port: int) -> bool:
    """Check if a port is already in use."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0


def check_internet_connection(timeout=3):
    """
    Check if internet is available by connecting to major endpoints.
    Uses port 443 (HTTPS) which is more reliable than DNS port 53.
    """
    targets = [
        ("aistudio.google.com", 443),
        ("google.com", 443),
        ("8.8.8.8", 53) # Fallback
    ]
    
    for host, port in targets:
        try:
            socket.setdefaulttimeout(timeout)
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((host, port))
            return True
        except (OSError, socket.timeout):
            continue
    return False



def get_chrome_path() -> Optional[str]:
    """
    Detect Chrome path based on OS.
    
    Returns:
        Path to Chrome executable or None if not found
    """
    system = platform.system()
    
    if system == "Darwin":
        path = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if os.path.exists(path):
            return path
        chromium = "/Applications/Chromium.app/Contents/MacOS/Chromium"
        if os.path.exists(chromium):
            return chromium
            
    elif system == "Linux":
        candidates = ["google-chrome", "google-chrome-stable", "chromium-browser", "chromium"]
        for cmd in candidates:
            try:
                path = subprocess.check_output(["which", cmd], stderr=subprocess.DEVNULL).decode().strip()
                if path:
                    return path
            except subprocess.CalledProcessError:
                continue
                
    elif system == "Windows":
        paths = [
            os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        ]
        for path in paths:
            if os.path.exists(path):
                return path
    
    return None


def start_chrome(port: int = 9222, profile: str = "default") -> None:
    """
    Start Chrome with remote debugging enabled.
    
    Launches Chrome on the specified port with anti-throttle flags.
    """
    print("[>] Frankenreview Chrome Launcher")
    print()
    
    chrome_path = get_chrome_path()
    if not chrome_path:
        print("[x] Chrome not found. Please install Google Chrome.")
        sys.exit(1)
    print(f"[i] Chrome found: {chrome_path}")
    
    if is_port_in_use(port):
        print(f"[+] Chrome already running on port {port} - ready to use!")
        print(f"[i] If you need to restart, run: frankenreview --stop-chrome")
        return
    
    # Profile and log paths
    home = os.path.expanduser("~")
    profile_dir = os.path.join(home, f"frankenreview_chrome_profile_{profile}")
    log_file = os.path.join(home, f"frankenreview_chrome_{port}.log")
    print(f"[i] Debug port: {port}")
    print(f"[i] Profile: {profile_dir}")
    
    args = [
        chrome_path,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={profile_dir}",
        "--disable-background-timer-throttling",
        "--disable-backgrounding-occluded-windows",
        "--disable-renderer-backgrounding",
        "--no-first-run",
        "--no-default-browser-check",
    ]
    
    print("[>] Launching Chrome with debugging enabled...")
    
    with open(log_file, "w") as log:
        if platform.system() == "Windows":
            subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT,
                           creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        else:
            subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT,
                           start_new_session=True)
    
    time.sleep(2)
    
    if is_port_in_use(port):
        print(f"[+] Chrome launched on port {port}")
        print()
        print("[i] NEXT STEPS:")
        print("   1. Go to https://aistudio.google.com in the Chrome window")
        print("   2. Log in with your Google account")
        print("   3. Minimize the window (DO NOT CLOSE IT)")
        print(f"   4. Run: frankenreview -r --port {port}")
        print()
        print("[!] DISCLAIMER: AI Studio may use your code for model training.")
    else:
        print(f"[x] Chrome failed to start. Check log: {log_file}")
        sys.exit(1)


def stop_chrome_cli(port: int = 9222) -> None:
    """
    Stop Chrome instances using the internal chrome_control module.
    
    This avoids killing unrelated Chrome instances (P1 Safety Fix).
    Uses PID file for reliable process targeting with fallback detection.
    
    Args:
        port: The debugging port to target.
    """
    from .utils.chrome_control import stop_chrome
    stop_chrome(port=port)


def get_project_root() -> Path:
    """
    Get the project root directory.
    
    Tries to find git root, otherwise uses current directory.
    
    Returns:
        Path to project root
    """
    cwd = Path.cwd()
    
    # Walk up to find .git directory
    current = cwd
    while current != current.parent:
        if (current / ".git").exists():
            return current
        current = current.parent
    
    # No git root found, use cwd
    return cwd


def resolve_prompt_path(prompt_arg: str, project_path: Path) -> Path:
    """
    Resolve prompt argument to a file path.
    
    Order:
    1. Direct file path
    2. .frankenreview/prompts/<name>.md
    3. src/frankenreview/prompts/<name>.md
    4. propject_root/prompt.md (legacy fallback for 'audit')
    """
    project_prompts_dir = project_path / ".frankenreview" / "prompts"
    built_in_dir = Path(__file__).parent / "prompts"
    
    # 1. Direct path
    p = Path(prompt_arg)
    if p.exists(): return p
    
    # 2. Project specific
    p = project_prompts_dir / f"{prompt_arg}.md"
    if p.exists(): return p
    
    # 3. Built-in
    p = built_in_dir / f"{prompt_arg}.md"
    if p.exists(): return p
    
    # 4. Fallback (local prompt.md)
    # Only check this if prompt_arg is 'audit' (default) to preserve legacy behavior without confusing explicit args
    if prompt_arg == 'audit' and (project_path / "prompt.md").exists():
        return project_path / "prompt.md"
        
    # Return best guess (built-in path) so caller can handle "not found"
    return built_in_dir / f"{prompt_arg}.md"


def run_one_shot_review(
    project_path: Optional[Path] = None,
    output_file: str = ".frankenreview/review.md",
    prompt_arg: str = "standard",
    model_arg: str = None,
    verbose: bool = False,
    port: int = 9222,
    attachments: list = None,
    prune_changelogs: bool = False,
    json_mode: bool = False,
    continue_session: bool = False,
    continue_new: bool = False
) -> int:
    """
    Run a single review pass.
    
    Args:
        project_path: Path to the project to review.
        output_file: Where to write the review output.
        prompt_arg: Prompt type or path to custom prompt file.
        model_arg: Model ID to use for the review.
        verbose: Enable verbose output.
        port: Chrome debugging port.
        attachments: Additional files to attach to the prompt.
        prune_changelogs: Temporarily truncate CHANGELOGs from dump.
        json_mode: Output results as JSON.
        continue_session: If True, continue from saved chat session.
        continue_new: If True, delete old session and start fresh but preserve for continuation.
        
    Returns:
        Exit code: 0 for success, 1 for failure.
    """
    # Import dependencies
    from .utils.workspace import (
        ensure_fr_folder, get_dump_dir, 
        load_session_url, save_session_url, delete_session_url
    )
    from .utils.config_loader import load_config
    from .engine.repo_dumper import dump_repo
    from .engine.browser import StudioClient

    if not check_internet_connection():
        print("[x] No internet connection. Frankenreview requires an active internet connection to communicate with Google AI Studio.")
        print("    Please check your network settings and try again.")
        return 1

    if project_path is None:
        project_path = get_project_root()
    else:
        project_path = Path(project_path)
        
    project_path = project_path.resolve()
    ensure_fr_folder(str(project_path))
    
    # 1. Load Config (cascade: global + .frankenreview/config.yaml local override)
    config = load_config(project_root=str(project_path))

    # Pre-resolve session continuation URL before the dump step so the dump
    # can be skipped when --continue resumes an existing chat.
    continue_url = None
    if continue_session:
        continue_url = load_session_url(str(project_path))
        if continue_url:
            print(f"[i] Continuing session: {continue_url[:50]}...")
        else:
            print("[i] No saved session found. Starting new chat.")

    # 2. Dump Repo
    # Skip when --continue resumes a saved session: the repo context is already
    # present in that chat from the previous run. Re-dumping would bloat the
    # context window and waste upload time.
    xml_content = None
    if continue_session and continue_url:
        print("[i] Continuing session — skipping repo dump (context already in chat).")
    else:
        dump_dir = get_dump_dir(str(project_path))
        print(f"[i] Dumping repo to {dump_dir}...")

        dump_path = dump_repo(
            str(project_path),
            str(dump_dir),
            prune_dirs=config.get('prune_dirs'),
            prune_files=config.get('prune_files'),
            prune_exts=config.get('prune_exts'),
            prune_changelogs=prune_changelogs
        )

        if not dump_path:
            print("[x] Dump failed.")
            return 1

        xml_content = Path(dump_path).read_text(encoding='utf-8')
        tokens = len(xml_content) // 2
        print(f"[i] Context Size: ~{tokens:,} tokens")

    # 3. Load Prompt
    prompt_path = resolve_prompt_path(prompt_arg, project_path)
    if not prompt_path.exists():
        print(f"[x] Prompt file not found: {prompt_path}")
        return 1
    
    prompt_text = prompt_path.read_text(encoding="utf-8")
    
    if json_mode:
        json_extension = """

### STRUCTURED OUTPUT REQUIREMENT (MANDATORY)
You MUST output your review in valid JSON format. 
Do NOT include any markdown formatting (no ```json code blocks), just the raw JSON object.
Follow this schema EXACTLY:
{
  "summary": "Brief high-level assessment of the code changes",
  "issues": [
    {
      "severity": "CRITICAL|HIGH|MEDIUM|LOW",
      "file": "path/to/file",
      "line": 123,
      "description": "Clear explanation of the problem",
      "fix": "Suggested fix or direction"
    }
  ],
  "score": 8.5
}
Ensure all paths are absolute within the repository context.
"""
        prompt_text += json_extension
    
    # 4. Connect to Chrome
    print(f"[i] Connecting to Chrome ({port})...")
    
    # FIX: Propagate CLI model argument to config
    if model_arg:
        base = "https://aistudio.google.com/prompts/new_chat"
        config['chat_url'] = f"{base}?model={model_arg}"
        if 'thinking' in model_arg.lower():
            config['thinking_mode'] = True

    # Handle --continue-new: clear old session before starting fresh
    if continue_new:
        old_url = load_session_url(str(project_path))
        if old_url:
            delete_session_url(str(project_path))
            print("[i] Cleared previous session. Starting fresh (preserving for continuation).")
    # continue_url already resolved before the dump step

    from .engine.browser import StudioClient
    try:
        client = StudioClient(
            debugger_port=port, 
            config=config, 
            model=model_arg,
            continue_url=continue_url
        )
    except Exception as e:
        print(f"[x] Connection failed: {e}")
        return 1
    
    # Disable chat deletion in continue mode or continue-new mode
    if continue_session or continue_new:
        client.delete_after_review = False
        
    # 5. Send Review
    actual_model = model_arg
    if not actual_model:
        chat_url = config.get('chat_url', '')
        if 'model=' in chat_url:
            actual_model = chat_url.split('model=')[-1].split('&')[0]
            
    print(f"[i] Sending to AI Studio (Model: {actual_model or 'Config Default'})...")
    if attachments:
        print(f"    [+] Attaching {len(attachments)} extra files.")
    
    start_time = time.time()
    try:
        response = client.send_review(prompt_text, xml_content=xml_content, attachments=attachments)
    except KeyboardInterrupt:
        print("\n[!] Review interrupted by user (^C). Stopping.")
        return 130  # Standard SIGINT exit code
    elapsed = time.time() - start_time
    
    if response.startswith("Error"):
        print(f"[x] Review failed: {response}")
        return 1
        
    # 6. Process and Save Output
    if json_mode:
        # Attempt to extract JSON if wrapped in markdown or filler
        import re
        json_match = re.search(r'(\{.*\})', response, re.DOTALL)
        if json_match:
            response = json_match.group(1)
        # Remove any leading/trailing whitespace
        response = response.strip()

    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    header = "" if json_mode else f"# Frankenreview Output\nGenerated: {timestamp}\nModel: {actual_model or 'Unknown'}\n\n---\n\n"

    out_path = project_path / output_file
    out_path.write_text(header + response, encoding="utf-8")
    
    print(f"[+] Review saved to {output_file} ({elapsed:.1f}s)")
    
    # Save session URL if in continue or continue-new mode (for future continuations)
    if (continue_session or continue_new) and hasattr(client, 'current_chat_url') and client.current_chat_url:
        save_session_url(str(project_path), client.current_chat_url)
        print("[i] Session saved for continuation.")
    
    return 0
def main():
    """
    Main CLI entry point.

    Parses arguments and dispatches to appropriate mode. SKILL.md is written
    before argument parsing so that ``--help`` (which exits inside
    ``parse_args``) still triggers workspace initialisation.
    """
    # Create .frankenreview/SKILL.md before argparse so --help also triggers it.
    try:
        from .utils.workspace import _ensure_skill_md
        _ensure_skill_md(Path.cwd() / ".frankenreview")
    except Exception:
        pass

    parser = argparse.ArgumentParser(
        prog="frankenreview",

        description=f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  FRANKENREVIEW v{__version__} - Agentic Code Reviewer & Research Agent                ║
║  Powered by Google AI Studio (Gemini)                                       ║
╚══════════════════════════════════════════════════════════════════════════════╝

WHAT IT DOES:
  Frankenreview analyzes your codebase using Gemini AI and produces a detailed
  code review in Markdown format. It can also perform deep research on any topic.
  More info in the SKILL.md generated in .frankenreview/ (auto-gitignored) on --help.

PREREQUISITES:
  1. Chrome must be running with remote debugging enabled:
     $ frankenreview --start-chrome
  2. You must be logged into Google AI Studio in that Chrome window.

OUTPUT:
  - All outputs are written to: .frankenreview/ (auto-gitignored)
  - Code Review Mode: Writes to '.frankenreview/review.md' (or --output)
  - Research Mode: Writes to specified --output file
  - Folder structure: .frankenreview/dumps/, .frankenreview/review.md

FOR AI AGENTS:
  - Default mode (-r) is designed for CI/CD and agent integration
  - Exit code 0 = success, 1 = error
  - Review output is in Markdown with [CRITICAL], [HIGH], [MEDIUM] severity tags
  - Read '.frankenreview/review.md' after execution to get the AI's feedback
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
BEST TIPS: 
  1. READ THE SKILL.md (generated in .frankenreview/) for advanced techniques to get the most out of Frankenreview.
  2. Mini-Changelog: Use 'frankenreview --workflow' to see the optimal iterative hardening loop.
  3. Token Eaters: Run 'frankenreview --token-eaters' to find garbage files to prune before sending code to AI.
  4. Self-Check: Run 'frankenreview --self-check' for project health diagnostics.



═══════════════════════════════════════════════════════════════════════════════
EXAMPLES FOR AI AGENTS:
═══════════════════════════════════════════════════════════════════════════════

  RECOMMENDED WORKFLOW (For Maximum Quality):
    1. READ DOCTRINE:   frankenreview --rigour
       (Internalize the "High-Precision Continuous Execution" mindset)
    2. READ PROCESS:    frankenreview --workflow
       (Understand the iterative hardening loop)
    3. PRUNE GARBAGE:   frankenreview --token-eaters
       (Remove noise to improve AI attention)
    4. EXECUTE REVIEW:  frankenreview -r
    
    MAINTENANCE:
    - Update CHANGELOG-MINI.md for EVERY task (concise single lines).
    - Prune main CHANGELOG.md as it could cause the review to be hallucinated based on false positives of the work done.


  CODE REVIEW (One-Shot):
    frankenreview -r
    frankenreview -r --path /path/to/project --output review.md
    frankenreview -r --prompt audit      # PhD-level brutal audit (default)
    frankenreview -r --prompt fullstack  # Full-stack production audit
    frankenreview -r --prompt research   # Scientific/algorithmic review

  RESEARCH MODE:
    echo "How to implement rate limiting in Python?" > topic.md
    frankenreview --research --prompt topic.md --output research_output.md
    frankenreview --research --prompt topic.md --research-model gemini-2.5-pro

  MODEL SELECTION:
    frankenreview -r --model MODEL_NAME (You can get the availaible models list from --available-models)

  DEEP SCAN & PLANNER:
    frankenreview --planner              # Critique plan.md before implementing
    frankenreview --deep-scan --cycles 3 # Recursive, self-correcting review

  DIAGNOSTICS:
    frankenreview --self-check           # Project health & manageability report

  CHROME MANAGEMENT:
    frankenreview --start-chrome         # Start Chrome with remote debugging
    frankenreview --stop-chrome          # Stop the Chrome debug instance

═══════════════════════════════════════════════════════════════════════════════
BUILT-IN PROMPTS:
═══════════════════════════════════════════════════════════════════════════════

  'audit'     - PhD-level brutal code audit. Default. Covers logic, security,
                performance, architecture. Output: prioritized action items.

  'fullstack' - Full-stack production audit. Focuses on OWASP, DevOps, Docker,
                frontend/backend performance. For web applications.

  'research'  - Scientific/algorithmic review. For ML/data science projects.
                Checks theoretical validity, reproducibility, data leakage.

  You can also pass a path to your own custom .md prompt file:
    frankenreview -r --prompt /path/to/custom_prompt.md

═══════════════════════════════════════════════════════════════════════════════
AGENT INTEGRATION TIPS:
═══════════════════════════════════════════════════════════════════════════════

  1. After running 'frankenreview -r', read 'review.md' to see feedback.
  2. The review contains actionable items tagged by severity.
  3. Fix issues in order: CRITICAL > HIGH > MEDIUM.
  4. Re-run frankenreview after fixes to verify resolution.
  5. Research mode is useful for investigating unfamiliar topics.

═══════════════════════════════════════════════════════════════════════════════
PERFORMANCE:
═══════════════════════════════════════════════════════════════════════════════

  Typical execution times (approximate):
  - One-Shot Review: 100-150 seconds (includes dump, upload, generation)
  - Research Mode:    60-90 seconds per query
  - Deep Scan:       3-5 minutes (multi-cycle)

═══════════════════════════════════════════════════════════════════════════════
CACHING & SNAPSHOTS:
═══════════════════════════════════════════════════════════════════════════════

  Frankenreview auto-clears code snapshots (.xml) after each successful review.
  Old snapshots are pruned if they are older than 1 hour. This prevents cached
  hallucinations and ensures the AI always sees your latest code. 
  Prune Changelogs option (--prune-changelogs) temporarily truncates changelogs 
  from the dump to reduce hallucination based on noisy changelog entries.

═══════════════════════════════════════════════════════════════════════════════
        """
    )
    
    # Mode flags
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        "-r", "--review",
        action="store_true",
        help="[DEFAULT] One-shot code review. Analyzes codebase and writes findings to review.md. "
             "Best for AI agents and CI/CD. Exit code 0=success, 1=error."
    )
    mode_group.add_argument(
        "--research",
        action="store_true",
        help="Research mode. Runs deep research on a topic using Gemini. "
             "Requires --prompt pointing to a .md file with your research question. "
             "Outputs structured findings with Executive Summary, Key Findings, etc."
    )
    # Options
    parser.add_argument(
        "--path", "-p",
        type=str,
        default=None,
        metavar="PATH",
        help="Project path to review. Default: auto-detects git root or uses current directory."
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default=None,
        metavar="FILE",
        help="Output filename for review/research results. Default: .frankenreview/review.md"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging. Shows detailed browser automation steps."
    )
    parser.add_argument(
        "--edit-config",
        action="store_true",
        help="Open config.yaml in editor ($EDITOR or nano). Configure selectors, models, paths. "
             "(Located in the project root directory)"
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"frankenreview {__version__}"
    )

    parser.add_argument(
        "--update",
        action="store_true",
        help="Update Frankenreview from the current directory (pip install .)"
    )
    
    parser.add_argument(
        "--prompt",
        type=str,
        default=None,
        metavar="TYPE|PATH",
        help="Prompt selection. Built-in: 'audit' (default), 'fullstack', 'research'. "
             "Or path to custom .md file. For --research mode, this is your topic file."
    )
    
    parser.add_argument(
        "--research-model",
        type=str,
        default="gemini-3-pro-preview",
        choices=["gemini-3-pro-preview", "gemini-2.5-pro"],
        metavar="MODEL",
        help="Model for research mode. Options: gemini-3-pro-preview (default, thinking), gemini-2.5-pro (reliable)."
    )

    parser.add_argument(
        "--model",
        type=str,
        default=None,
        metavar="MODEL_ID",
        help="Model for code review. Use 'thinking' for Gemini Thinking mode, or full model ID "
             "(e.g., gemini-2.0-flash-thinking-exp-01-21). Default: from config.yaml."
    )

    parser.add_argument(
        "--visible",
        action="store_true",
        help="Force browser window to be visible. Useful for debugging automation issues."
    )
    parser.add_argument(
        "--start-chrome",
        action="store_true",
        help="Start Chrome with remote debugging enabled. Required before first use."
    )
    parser.add_argument(
        "--stop-chrome",
        action="store_true",
        help="Stop the Chrome debug instance."
    )
    
    # Session Continuation (v11.5)
    parser.add_argument(
        "--continue",
        dest="continue_session",
        action="store_true",
        help="Continue from the last chat session instead of starting new. "
             "Preserves context across multiple review runs."
    )
    parser.add_argument(
        "--continue-new",
        dest="continue_new",
        action="store_true",
        help="Start fresh session but preserve for future --continue. "
             "Deletes any existing saved session first."
    )
    parser.add_argument(
        "--delete-chat",
        action="store_true",
        help="Delete the saved chat session on AI Studio. "
             "Use after completing a multi-step task."
    )
    parser.add_argument(
        "--open-chat",
        action="store_true",
        help="Open a new chat session without running a review. "
             "Use with --attach to upload files for manual interaction."
    )
    
    # Phase 8: Scale & Context
    parser.add_argument(
        "--port",
        type=int,
        default=9222,
        help="Chrome remote debugging port (default: 9222). Allows running multiple instances."
    )
    parser.add_argument(
        "--profile",
        type=str,
        default="default",
        help="Chrome profile name suffix (default: default). Use different names for parallel instances."
    )
    parser.add_argument(
        "--attach",
        action="append",
        metavar="FILE",
        help="Attach a file to the prompt (can be used multiple times)."
    )
    
    # Phase 9: Hygiene
    parser.add_argument(
        "--prune-changelogs",
        action="store_true",
        help="Temporarily truncate CHANGELOG.md and CHANGELOG-MINI.md from the dump to reduce hallucination."
    )

    # Phase 7: Rigour & Workflow
    parser.add_argument(
        "--rigour",
        action="store_true",
        help="Run audit using the RIGOUR doctrine (High-Precision Mode)."
    )
    
    # Phase 10: Deep Scan & Planner
    parser.add_argument(
        "--planner",
        action="store_true",
        help="Planner Mode: Critique plan.md against codebase context."
    )
    parser.add_argument(
        "--deep-scan",
        action="store_true",
        help="Deep Scan Mode: Recursive, multi-cycle review loop."
    )
    parser.add_argument(
        "--cycles",
        type=int,
        default=3,
        help="Number of cycles for Deep Scan (default: 3)."
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume Deep Scan from the last completed cycle."
    )

    # Phase 19: Agent Manageability
    parser.add_argument(
        "--self-check",
        action="store_true",
        help="Run self-diagnostic check (Syntax, Imports, Config). Returns JSON status."
    )
    
    parser.add_argument(
        "--discover-selectors",
        action="store_true",
        help="Run interactive selector discovery to verify and update config.yaml against live AI Studio."
    )
        
    # Prune Configuration Management
    parser.add_argument(
        "--prune-list",
        action="store_true",
        help="Display current prune configuration (dirs, files, extensions to skip)."
    )
    parser.add_argument(
        "--prune-add-dir",
        type=str,
        metavar="DIR",
        help="Add a directory to prune_dirs (persists to config.yaml)."
    )
    parser.add_argument(
        "--prune-remove-dir",
        type=str,
        metavar="DIR",
        help="Remove a directory from prune_dirs."
    )
    parser.add_argument(
        "--prune-add-file",
        type=str,
        metavar="FILE",
        help="Add a filename to prune_files (persists to config.yaml)."
    )
    parser.add_argument(
        "--prune-remove-file",
        type=str,
        metavar="FILE",
        help="Remove a filename from prune_files."
    )
    parser.add_argument(
        "--prune-add-ext",
        type=str,
        metavar="EXT",
        help="Add extension to prune_exts (e.g., '.csv'). Persists to config.yaml."
    )
    parser.add_argument(
        "--prune-remove-ext",
        type=str,
        metavar="EXT",
        help="Remove extension from prune_exts."
    )
    
    # Token Analysis
    parser.add_argument(
        "--token-eaters",
        action="store_true",
        help="Analyze repo to show top 10 files and folders consuming most tokens. "
             "Helps identify garbage before running review."
    )
    
    # Chrome Performance
    parser.add_argument(
        "--chrome-stats",
        action="store_true",
        help="Display Chrome memory usage and performance stats."
    )

    # Prompt Management
    parser.add_argument(
        "--create-prompt",
        type=str,
        metavar="NAME",
        help="Create a new project-specific prompt in .frankenreview/prompts/ and open it for editing."
    )
    
    

    
    
    # V7.0 Documentation & Workflow
    # Rigour arg moved to main parser block above
    parser.add_argument("--workflow", action="store_true", help="Display the Mini-Changelog Workflow.")
    parser.add_argument("--rigour-edit", action="store_true", help="Open rigour.md in editor.")
    parser.add_argument("--workflow-edit", action="store_true", help="Open workflow.md in editor.")
    parser.add_argument("--prompt-edit", action="store_true", help="Open current prompt file in editor.")
    
    parser.add_argument("--feature-research", type=str, metavar="QUERY", help="Run feature research (Repo Dump + Query).")
    parser.add_argument("--dump", action="store_true", help="Generate repo dump only (print stats).")
    parser.add_argument("--available-models", action="store_true", help="Display cached model compatibility list.")
    parser.add_argument("--fetch-models", action="store_true", help="Actively fetch available Gemini models from Google AI docs and update cache.")
    parser.add_argument("--consolidation", action="store_true", help="Run Repository Consolidation analysis (Structure & Standardization).")

    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON (for --self-check)."
    )
    
    args = parser.parse_args()
    
    # 0. Initialize Workspace used by Agent SKILL.md
    try:
        from .utils.workspace import ensure_fr_folder
        project_root = Path(args.path).resolve() if hasattr(args, 'path') and args.path else Path.cwd()
        ensure_fr_folder(str(project_root))
    except Exception:
        pass # Non-critical if fails (e.g. permission error)

    # Agent Manageability    # 0. Selector Discovery
    if args.discover_selectors:
        from .utils.selector_discovery import discover_selectors_cli
        discover_selectors_cli()
        return 0

    # 1. Self Check
    if args.self_check:
        try:
            from .utils.self_check import run_self_check
            sys.exit(run_self_check(json_output=args.json))
        except ImportError as e:
            print(f'{{"status": "failed", "error": "Could not import self_check: {e}"}}')
            sys.exit(1)

    # Prioritize Consolidation Mode
    if args.consolidation:
        args.review = True
        # Set prompt if not explicitly overridden (allow user to point to custom consolidation logic if they want)
        if not args.prompt:
            args.prompt = "consolidation"
    
    # Handle Chrome management first (before other modes)
    if args.start_chrome:
        start_chrome(port=args.port, profile=args.profile)
        sys.exit(0)
    
    if args.stop_chrome:
        stop_chrome_cli(port=args.port)
        sys.exit(0)
    
    # Handle --delete-chat (Session cleanup utility)
    if args.delete_chat:
        from .utils.workspace import load_session_url, delete_session_url
        project_path = Path(args.path).resolve() if args.path else get_project_root()
        
        saved_url = load_session_url(str(project_path))
        if not saved_url:
            print("[i] No saved chat session found. Nothing to delete.")
            sys.exit(0)
        
        print(f"[i] Saved session URL: {saved_url[:60]}...")
        print("[>] Deleting chat from AI Studio...")
        
        from .utils.config_loader import load_config
        from .engine.browser import StudioClient
        config = load_config()
        
        try:
            client = StudioClient(debugger_port=args.port, config=config)
            client.delete_chat_from_url(saved_url)
            delete_session_url(str(project_path))
            print("[+] Chat deleted and session cleared.")
        except Exception as e:
            print(f"[x] Failed to delete chat: {e}")
            sys.exit(1)
        sys.exit(0)

    # Handle --open-chat (Interactive session mode)
    if args.open_chat:
        from .utils.workspace import save_session_url, delete_session_url, load_session_url
        from .utils.config_loader import load_config
        from .engine.browser import StudioClient
        
        project_path = Path(args.path).resolve() if args.path else get_project_root()
        config = load_config()
        
        # Check for existing session to continue
        existing_url = load_session_url(str(project_path))
        continue_url = existing_url if existing_url and not args.attach else None
        
        # If new attachments provided, start fresh session
        if args.attach:
            delete_session_url(str(project_path))
        
        print("[>] Opening AI Studio chat session...")
        if continue_url:
            print(f"   [i] Resuming existing session...")
        
        try:
            client = StudioClient(debugger_port=args.port, config=config, model=args.model, continue_url=continue_url)
            page = client.connect_to_aistudio()
            
            if not page:
                print("[x] Failed to open chat session.")
                sys.exit(1)
            
            # Upload attachments if provided (without prompt, just for staging)
            if args.attach and not args.prompt:
                print(f"[>] Uploading {len(args.attach)} files...")
                upload_success = client._try_file_upload(page, args.attach)
                if not upload_success:
                    print("[x] File upload failed. All files may be unsupported format.")
                    print("[i] Tip: Use .txt extension for XML content.")
                    sys.exit(1)
            
            # Send prompt if provided (handle attachments here too)
            if args.prompt:
                prompt_path = Path(args.prompt)
                if prompt_path.exists():
                    prompt_text = prompt_path.read_text(encoding='utf-8').strip()
                else:
                    prompt_text = args.prompt  # Use as raw text
                
                print(f"[>] Sending prompt ({len(prompt_text)} chars)...")
                
                response = client.send_prompt_in_chat(page, prompt_text, attachments=args.attach)
                
                if response and not response.startswith("Error:"):
                    print("\n" + "="*60)
                    print("RESPONSE:")
                    print("="*60)
                    print(response[:2000] + ("..." if len(response) > 2000 else ""))
                    print("="*60)
                    
                    # Save output if specified
                    if args.output and args.output != "review.md":
                        output_path = Path(args.output)
                        output_path.parent.mkdir(parents=True, exist_ok=True)
                        output_path.write_text(response, encoding='utf-8')
                        print(f"[+] Response saved to: {output_path}")
                else:
                    print(f"[x] {response}")
            
            # Save session URL for continuation
            client.current_chat_url = page.url
            save_session_url(str(project_path), page.url)
            
            print(f"[+] Chat session opened at: {page.url[:60]}...")
            print("[i] Session saved. Use --open-chat to continue this chat.")
            print("[i] Chrome window is ready for manual interaction.")
            
        except KeyboardInterrupt:
            print("\n[!] Session opening aborted by user (^C).")
            sys.exit(130)
        except Exception as e:
            print(f"[x] Failed to open chat: {e}")
            sys.exit(1)
        sys.exit(0)

    if args.available_models:
        doc_path = get_project_root() / "docs" / "MODEL_COMPATIBILITY_2026.md"
        if doc_path.exists():
            print(doc_path.read_text(encoding='utf-8'))
        else:
            print("[!] No cached model data. Run 'frankenreview --fetch-models' to fetch.")
        sys.exit(0)

    if args.fetch_models:
        from .engine.model_discovery import fetch_models_live, format_model_table, update_cached_doc
        models = fetch_models_live()
        if models:
            print(format_model_table(models))
            update_cached_doc(models, project_root=get_project_root())
        else:
            doc_path = get_project_root() / "docs" / "MODEL_COMPATIBILITY_2026.md"
            if doc_path.exists():
                print("[!] Live fetch failed. Showing cached data:")
                print(doc_path.read_text(encoding='utf-8'))
            else:
                print("[!] Fetch failed and no cached data available.")
        sys.exit(0)
    
    # Handle prune configuration commands
    from .utils.prune_config import add_to_prune_list, remove_from_prune_list, list_prune_config
    
    if args.prune_list:
        print(list_prune_config())
        sys.exit(0)
    
    if args.prune_add_dir:
        if add_to_prune_list("dirs", args.prune_add_dir):
            print(f"[+] Added directory to prune_dirs: {args.prune_add_dir}")
        else:
            print(f"[i] Directory already in prune_dirs: {args.prune_add_dir}")
        sys.exit(0)
    
    if args.prune_remove_dir:
        if remove_from_prune_list("dirs", args.prune_remove_dir):
            print(f"[+] Removed directory from prune_dirs: {args.prune_remove_dir}")
        else:
            print(f"[i] Directory not found in prune_dirs: {args.prune_remove_dir}")
        sys.exit(0)
    
    if args.prune_add_file:
        if add_to_prune_list("files", args.prune_add_file):
            print(f"[+] Added file to prune_files: {args.prune_add_file}")
        else:
            print(f"[i] File already in prune_files: {args.prune_add_file}")
        sys.exit(0)
    
    if args.prune_remove_file:
        if remove_from_prune_list("files", args.prune_remove_file):
            print(f"[+] Removed file from prune_files: {args.prune_remove_file}")
        else:
            print(f"[i] File not found in prune_files: {args.prune_remove_file}")
        sys.exit(0)
    
    if args.prune_add_ext:
        ext = args.prune_add_ext
        if not ext.startswith("."):
            ext = "." + ext
        if add_to_prune_list("exts", ext):
            print(f"[+] Added extension to prune_exts: {ext}")
        else:
            print(f"[i] Extension already in prune_exts: {ext}")
        sys.exit(0)
    
    if args.prune_remove_ext:
        ext = args.prune_remove_ext
        if not ext.startswith("."):
            ext = "." + ext
        if remove_from_prune_list("exts", ext):
            print(f"[+] Removed extension from prune_exts: {ext}")
        else:
            print(f"[i] Extension not found in prune_exts: {ext}")
        sys.exit(0)
    
    # Token Eaters Analysis
    if args.token_eaters:
        from .engine.repo_dumper import analyze_token_eaters
        from .utils.config_loader import load_config
        
        config = load_config()
        project_path = Path(args.path).resolve() if args.path else Path.cwd()
        
        prune_dirs = config.get('prune_dirs')
        prune_files = config.get('prune_files')
        prune_exts = config.get('prune_exts')
        
        result = analyze_token_eaters(str(project_path), prune_dirs, prune_files, prune_exts)
        print(result)
        sys.exit(0)
    
    # Chrome Performance Stats
    if args.chrome_stats:
        from .engine.chrome_stats import format_chrome_stats
        print(format_chrome_stats())
        sys.exit(0)
    
    # V7.0 Handlers
    
    if args.rigour:
        rigour_path = Path(__file__).parent / "prompts" / "rigour.md"
        if rigour_path.exists():
            print(rigour_path.read_text())
        else:
            print("[!] Rigour doctrine not found.")
        sys.exit(0)

    if args.workflow:
        workflow_path = Path(__file__).parent / "prompts" / "workflow.md"
        if workflow_path.exists():
            print(workflow_path.read_text())
        else:
            print("[!] Workflow guide not found.")
        sys.exit(0)
        
    if args.rigour_edit:
        rigour_path = Path(__file__).parent / "prompts" / "rigour.md"
        edit_file(rigour_path)
        sys.exit(0)

    if args.workflow_edit:
        workflow_path = Path(__file__).parent / "prompts" / "workflow.md"
        edit_file(workflow_path)
        sys.exit(0)
    
    if args.create_prompt:
        project_path = Path(args.path).resolve() if args.path else get_project_root()
        prompts_dir = project_path / ".frankenreview" / "prompts"
        prompts_dir.mkdir(parents=True, exist_ok=True)
        
        target_name = args.create_prompt
        if not target_name.endswith(".md"):
            target_name += ".md"
            
        target_file = prompts_dir / target_name
        
        if not target_file.exists():
            print(f"[+] Creating new prompt: {target_file}")
            template = """# Custom Review Prompt

Review this code with focus on:
1. ...
2. ...

Output a prioritized action plan in Markdown format.
"""
            target_file.write_text(template, encoding="utf-8")
        else:
            print(f"[i] Prompt already exists: {target_file}")
            
        edit_file(target_file)
        sys.exit(0)
    
    if args.prompt_edit:
        # Determine current prompt path
        from .utils.config_loader import load_config
        project_path = Path(args.path).resolve() if args.path else get_project_root()
        
        config = {}
        config_path = project_path / "config.yaml"
        if config_path.exists():
             config = load_config(str(config_path))
             
        # Check command line arg precedence, then config, then default
        prompt_name = args.prompt or config.get('prompt_arg', 'standard')
        prompt_path = resolve_prompt_path(prompt_name, project_path)
        
        if not prompt_path.exists():
             # Try local file directly if resolve failed (shouldn't happen with updated resolve)
             pass
        
        edit_file(prompt_path)
        sys.exit(0)

    if args.dump:
        from .engine.repo_dumper import dump_repo
        from .engine.token_governor import optimize_dump
        from .utils.config_loader import load_config
        from .utils.workspace import ensure_fr_folder, get_dump_dir
        
        project_path = Path(args.path).resolve() if args.path else get_project_root()
        config = load_config(project_root=str(project_path))
        ensure_fr_folder(str(project_path))
        dump_dir = get_dump_dir(str(project_path))
        
        print(f"[i] Dumping repository: {project_path}")
        dump_path = dump_repo(
            str(project_path), 
            str(dump_dir), 
            prune_dirs=config.get('prune_dirs'), 
            prune_files=config.get('prune_files'),
            prune_exts=config.get('prune_exts')
        )
        
        if dump_path and Path(dump_path).exists():
            # Token estimate
            with open(dump_path, 'r', encoding='utf-8') as f:
                content = f.read()
            # Calibrated heuristic (3.7 chars/token) to match Gemini AI Studio
            tokens = int(len(content) / 3.7)
            print(f"[i] Est. Tokens: {tokens:,}")
        else:
            print("[!] Dump generation failed.")
            sys.exit(1)
        sys.exit(0)
        
    if args.feature_research:
        if not check_internet_connection():
            print("[x] No internet connection.")
            sys.exit(1)

        from .agents.research import run_feature_research
        
        project_path = Path(args.path).resolve() if args.path else get_project_root()
        if not args.output or args.output == "review.md":
            # Default: use timestamped file in .frankenreview
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            output_file = f".frankenreview/feature_research_{timestamp}.md"
        else:
            output_file = args.output
            
        output_path = Path(output_file).resolve()
        
        print(f"[i] Starting Feature Research: {args.feature_research}")
        research_model = args.model if args.model else args.research_model
        exit_code = run_feature_research(
            query=args.feature_research,
            project_root=project_path,
            output_path=output_path,
            model=research_model,
            verbose=args.verbose,
            port=args.port
        )
        sys.exit(exit_code)

    if args.planner:
        if not check_internet_connection():
            print("[x] No internet connection.")
            sys.exit(1)

        from .agents.planner import run_planner
        print(f"[i] Starting Planner Critique...")
        exit_code = run_planner(
            project_path=args.path if args.path else Path.cwd(),
            port=args.port,
            verbose=args.verbose
        )
        sys.exit(exit_code)

    if args.deep_scan:
        if not check_internet_connection():
            print("[x] No internet connection.")
            sys.exit(1)

        from .agents.deep_scan import run_deep_scan
        print(f"[i] Starting Deep Scan ({args.cycles} cycles)...")
        exit_code = run_deep_scan(
            project_path=args.path if args.path else Path.cwd(),
            cycles=args.cycles,
            port=args.port,
            verbose=args.verbose,
            prune_changelogs=args.prune_changelogs,
            model=args.model,
            prompt_arg=args.prompt,
            resume=args.resume
        )
        sys.exit(exit_code)

    # Default to one-shot review if no mode specified
    if not any([
        args.review, args.edit_config, args.research,
        args.dump, args.feature_research, args.planner, args.deep_scan,
        args.rigour, args.workflow,
        args.rigour_edit, args.workflow_edit, args.prompt_edit,
        args.create_prompt,
        args.prune_list, args.prune_add_dir, args.prune_add_file, args.prune_add_ext,
        args.token_eaters, args.chrome_stats
    ]):
        args.review = True
    
    if args.edit_config:
        # Resolve config path via the config loader
        from .utils.config_loader import get_effective_config_path
        config_path = Path(get_effective_config_path())
        print(f"[i] Opening configuration: {config_path}")
        if not config_path.exists():
            print(f"[!] Config file not found at {config_path}")
            sys.exit(1)
            
        editor = os.environ.get('EDITOR', 'nano')
        try:
            import shlex
            subprocess.call(shlex.split(editor) + [str(config_path)])
        except FileNotFoundError:
             # Fallback if nano is missing?
             print(f"[!] Editor '{editor}' not found. Trying 'vi'...")
             subprocess.call(['vi', str(config_path)])
             
        print("[+] Configuration closed.")
        sys.exit(0)
    
    if args.update:
        # Self-update from current directory
        # Check for setup.py or pyproject.toml
        cwd = Path.cwd()
        if not (cwd / "setup.py").exists() and not (cwd / "pyproject.toml").exists():
            print(f"[x] No setup.py or pyproject.toml found in {cwd}")
            print("    Please run this command from the root of the Frankenreview repository.")
            sys.exit(1)
            
        print(f"[i] Updating Frankenreview from {cwd}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "."])
            print(f"[+] Update complete! Run 'frankenreview --version' to verify.")
        except subprocess.CalledProcessError as e:
            print(f"[x] Update failed: {e}")
            sys.exit(1)
        sys.exit(0)
    


    if args.review:
        # One-shot review mode
        attachments = args.attach or []

        try:
            exit_code = run_one_shot_review(
                project_path=args.path,
                output_file=args.output or ".frankenreview/review.md",
                prompt_arg=args.prompt or "audit",
                model_arg=args.model,
                verbose=args.verbose,
                port=args.port,
                attachments=args.attach,
                prune_changelogs=args.prune_changelogs,
                json_mode=args.json,
                continue_session=args.continue_session,
                continue_new=args.continue_new
            )
        except KeyboardInterrupt:
            print("\n[!] Review aborted by user (^C). Exiting gracefully.")
            sys.exit(130)
        sys.exit(exit_code)
    
    elif args.research:
        # Research mode
        from .agents.research import run_research
        
        if not check_internet_connection():
            print("[x] No internet connection.")
            sys.exit(1)
        
        if not args.prompt:
            print("[x] Research mode requires --prompt <file|topic>")
            sys.exit(1)
        prompt_path = Path(args.prompt)
        
        # Note: run_research handles if prompt_path is a raw string/doesn't exist
        
        if not args.output or args.output == "review.md":
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            output_path = Path(f".frankenreview/research_{timestamp}.md")
        else:
            output_path = Path(args.output)
        
        # Prioritize --model if explicitly provided, otherwise use research default
        target_model = args.model if args.model else args.research_model
        
        print(f"[i] Research Mode: {target_model}")
        print(f"[i] Prompt: {args.prompt}")
        print(f"[i] Output: {output_path}")
        
        try:
            exit_code = run_research(
                prompt_path=prompt_path,
                output_path=output_path,
                model=target_model,
                verbose=args.verbose,
                port=args.port
            )
        except KeyboardInterrupt:
            print("\n[!] Research aborted by user (^C). Exiting gracefully.")
            sys.exit(130)
        sys.exit(exit_code)
    

if __name__ == "__main__":
    main()
