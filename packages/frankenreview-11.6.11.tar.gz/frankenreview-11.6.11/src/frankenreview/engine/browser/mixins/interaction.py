"""
DOM interaction utilities for browser automation.
Handles clicking, scrolling, and generation state verification.
"""
import time


class InteractMixin:
    """Mixin providing DOM interaction and state verification."""
    def _get_model_turn_count(self, page):
        """Count how many model responses exist currently."""
        try:
            return page.evaluate("""() => {
                return document.querySelectorAll('[data-message-author-role="model"]').length;
            }""")
        except Exception:
            return 0


    def _scroll_to_bottom(self, page):
        """Scroll to the bottom of the page to trigger lazy loading."""
        # print("   [i] Scrolling...") # Removed to reduce spam
        try:
            page.evaluate("""() => {
                const viewport = document.querySelector('cdk-virtual-scroll-viewport') || 
                                 document.querySelector('.virtual-scroll-viewport') || 
                                 document.querySelector('main');
                if (viewport) {
                    viewport.scrollTop = viewport.scrollHeight;
                }
                window.scrollTo(0, document.body.scrollHeight);
                const lastTurn = document.querySelector('ms-chat-turn:last-of-type');
                if (lastTurn) lastTurn.scrollIntoView({ behavior: 'instant', block: 'end' });
            }""")
        except Exception:
            pass


    def _click_run_button(self, page, selectors):
        """
        Locate and click the Run/Send button with robust verification.
        
        Handles selector shadowing by:
        1. Checking viewport intersection before clicking
        2. Scrolling button into view
        3. Verifying the click triggered generation (Stop button or Run disabled)
        
        Args:
            page: Playwright page object
            selectors: List of CSS selectors to try
            
        Returns:
            True if generation was triggered, False otherwise
        """
        # Count existing responses before running
        initial_count = self._get_model_turn_count(page)
        
        start_time = time.monotonic()
        keyboard_fallback_used = False
        click_attempted = False
        
        # Extended selectors including role-based fallbacks
        extended_selectors = list(selectors) + [
            "button[role='button'][aria-label*='Run']",
            "button[role='button'][aria-label*='Send']",
            "[role='button']:has-text('Run')",
            "[role='button']:has-text('Send')"
        ]
        
        while time.monotonic() - start_time < 30.0:
            # 1. Try Selectors with viewport intersection check
            for selector in extended_selectors:
                sel = selector.strip()
                if not sel:
                    continue
                try:
                    loc = page.locator(sel)
                    count = loc.count()
                    for i in range(count):
                        btn = loc.nth(i)
                        if not btn.is_visible():
                            continue
                            
                        # Check disabled state
                        is_disabled = btn.get_attribute("disabled") is not None
                        aria_disabled = btn.get_attribute("aria-disabled")
                        if aria_disabled == "true":
                            is_disabled = True
                        if is_disabled:
                            continue
                        
                        # Viewport Intersection Check via JavaScript
                        try:
                            in_viewport = page.evaluate("""(selector, index) => {
                                const elements = document.querySelectorAll(selector);
                                if (index >= elements.length) return false;
                                const el = elements[index];
                                const rect = el.getBoundingClientRect();
                                const viewHeight = window.innerHeight || document.documentElement.clientHeight;
                                const viewWidth = window.innerWidth || document.documentElement.clientWidth;
                                // Element must be at least partially visible in viewport
                                return rect.top < viewHeight && rect.bottom > 0 && 
                                       rect.left < viewWidth && rect.right > 0 &&
                                       rect.width > 0 && rect.height > 0;
                            }""", [sel, i])
                            
                            if not in_viewport:
                                # Scroll into view and recheck
                                btn.scroll_into_view_if_needed()
                                time.sleep(0.3)
                        except Exception:
                            pass
                        
                        # Attempt click
                        try:
                            btn.click(timeout=2000)
                            click_attempted = True
                            print(f"   [+] Clicked Run button ({sel} #{i})")
                            
                            # Verify generation started (critical for shadowed buttons)
                            if self._verify_generation_triggered(page, initial_count=initial_count):
                                return True
                            else:
                                print(f"   [!] Click did not trigger generation, trying next...")
                                continue
                        except Exception as click_err:
                            if self.verbose_selectors:
                                print(f"   [d] Click failed on {sel}#{i}: {click_err}")
                            continue
                            
                except Exception:
                    continue
            
            # 2. Keyboard Fallback (after 5s or if click attempts failed)
            if not keyboard_fallback_used and (time.monotonic() - start_time > 5.0 or click_attempted):
                try:
                    print("   [i] Trying Keyboard Shortcut fallback...")
                    # Ensure textarea has focus with explicit click + focus
                    textarea_sels = ["textarea[aria-label*='prompt']", "textarea"]
                    for t_sel in textarea_sels:
                        try:
                            textarea = page.locator(t_sel).first
                            if textarea.is_visible():
                                textarea.click()
                                time.sleep(0.2)
                                textarea.focus()
                                break
                        except Exception:
                            continue
                    
                    time.sleep(0.3)
                    # Try Mac shortcut
                    page.keyboard.press("Meta+Enter")
                    time.sleep(0.5)
                    
                    if self._verify_generation_triggered(page):
                        print("   [+] Triggered Run via Meta+Enter")
                        return True
                    
                    # Try Windows/Linux shortcut  
                    page.keyboard.press("Control+Enter")
                    time.sleep(0.5)
                    
                    if self._verify_generation_triggered(page):
                        print("   [+] Triggered Run via Control+Enter")
                        return True
                        
                    keyboard_fallback_used = True
                except Exception as e:
                    print(f"   [!] Keyboard fallback failed: {e}")
                    keyboard_fallback_used = True
            
            time.sleep(0.5)
            
        print("   [!] Could not trigger generation (timed out)")
        return False
    

    def _verify_generation_triggered(self, page, initial_count=0, timeout=5.0):
        """
        Quick check to verify that generation actually started after a click.
        Strict verification to avoid false positives from pre-disabled buttons.
        """
        stop_sel = self.selectors.get('stop_button', "button:has-text('Stop')")
        run_sel = self.selectors.get('run_button', "button[aria-label*='Run']")
        thinking_sel = self.selectors.get('thinking_indicator', "span:has-text('Thinking')")
        
        # Parse potential multi-selectors
        stop_selectors = [s.strip() for s in stop_sel.split(',') if s.strip()]
        thinking_selectors = []
        if thinking_sel:
            thinking_selectors = [s.strip() for s in thinking_sel.split(',') if s.strip()]
        run_selectors = [s.strip() for s in run_sel.split(',') if s.strip()]
        
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            try:
                # 1. Stop button visibility is the strongest signal
                for sel in stop_selectors:
                    stop_loc = page.locator(sel)
                    if stop_loc.count() > 0 and stop_loc.first.is_visible():
                        return True
                
                # 2. Thinking indicator
                for sel in thinking_selectors:
                    think_loc = page.locator(sel)
                    if think_loc.count() > 0 and think_loc.first.is_visible():
                        return True
                
                # 3. Message turn count increased
                if initial_count > 0:
                    current_count = self._get_model_turn_count(page)
                    if current_count > initial_count:
                        return True
                    
                # 4. Check for disabled Run button (wait at least 1s for consistency)
                if (time.monotonic() - (end - timeout)) > 1.0:
                    for sel in run_selectors:
                        run_loc = page.locator(sel)
                        if run_loc.count() > 0:
                            btn = run_loc.first
                            is_disabled = btn.get_attribute("disabled") is not None or btn.get_attribute("aria-disabled") == "true"
                            if is_disabled:
                                return True
            except Exception:
                pass
            time.sleep(0.25)
        return False


    def _confirm_generation_started(self, page, run_selectors, stop_selector, timeout=30):
        """
        Confirm that generation actually started by observing Stop button visibility,
        Run button disabling, or the Thinking indicator appearing.
        """
        # We reuse the robust logic from _verify_generation_triggered
        return self._verify_generation_triggered(page, timeout=timeout)
    

