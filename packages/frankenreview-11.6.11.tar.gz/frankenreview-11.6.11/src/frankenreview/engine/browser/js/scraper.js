/**
 * scraper.js - DOM-based Markdown reconstruction for AI Studio responses.
 *
 * Loaded at runtime by generation.py and executed via Playwright's page.evaluate().
 * Reconstructs structured Markdown from the live DOM of the last model response,
 * preserving code fences, headings, lists, and inline formatting.
 *
 * Target element: ms-chat-turn:last-of-type > .turn-content
 */
(() => {
    const lastTurn = document.querySelector('ms-chat-turn:last-of-type');
    if (!lastTurn) return "";

    const contentDiv = lastTurn.querySelector('.turn-content');
    if (!contentDiv) return "";

    /**
     * Recursively walks the DOM tree and reconstructs Markdown text.
     * @param {Element} element - The root element to traverse.
     * @returns {string} Reconstructed Markdown string.
     */
    function extractMarkdown(element) {
        let result = '';

        for (const node of element.childNodes) {
            if (node.nodeType === 1) { // Element node
                const tag = node.tagName?.toLowerCase() || '';
                const classList = node.className || '';

                // Skip thinking blocks, footers, and UI chrome
                if (
                    tag === 'mat-expansion-panel' ||
                    classList.includes('model-thoughts') ||
                    classList.includes('turn-footer') ||
                    classList.includes('actions-container') ||
                    classList.includes('author-label') ||
                    tag === 'button'
                ) {
                    continue;
                }

                // Block-level elements with structural Markdown output
                if (tag === 'p') {
                    result += extractMarkdown(node) + '\n\n';
                } else if (tag === 'h1') {
                    result += '# ' + extractMarkdown(node) + '\n\n';
                } else if (tag === 'h2') {
                    result += '## ' + extractMarkdown(node) + '\n\n';
                } else if (tag === 'h3') {
                    result += '### ' + extractMarkdown(node) + '\n\n';
                } else if (tag === 'h4') {
                    result += '#### ' + extractMarkdown(node) + '\n\n';
                } else if (tag === 'li') {
                    result += '- ' + extractMarkdown(node) + '\n';
                } else if (tag === 'ul' || tag === 'ol') {
                    result += extractMarkdown(node) + '\n';
                } else if (tag === 'br') {
                    result += '\n';
                } else if (tag === 'ms-code-block' || classList.includes('code-block')) {
                    const lang = node.getAttribute('language') || '';
                    const code = node.innerText || '';
                    result += '\n```' + lang + '\n' + code + '\n```\n\n';
                } else if (
                    tag === 'ms-cmark-node' ||
                    tag === 'ms-text-chunk' ||
                    tag === 'ms-prompt-chunk'
                ) {
                    result += extractMarkdown(node);
                } else if (tag === 'strong' || tag === 'b') {
                    result += '**' + extractMarkdown(node) + '**';
                } else if (tag === 'em' || tag === 'i') {
                    result += '*' + extractMarkdown(node) + '*';
                } else if (tag === 'code' || classList.includes('inline-code')) {
                    result += '`' + (node.innerText || '') + '`';
                } else if (tag === 'a') {
                    const href = node.getAttribute('href') || '';
                    result += '[' + extractMarkdown(node) + '](' + href + ')';
                } else if (tag === 'div' || tag === 'span') {
                    result += extractMarkdown(node);
                } else {
                    result += node.innerText || '';
                }
            } else if (node.nodeType === 3) { // Text node
                result += node.textContent || '';
            }
        }
        return result;
    }

    return extractMarkdown(contentDiv).trim();
})()
