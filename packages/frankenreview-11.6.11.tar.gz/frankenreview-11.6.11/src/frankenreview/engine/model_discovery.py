"""
Frankenreview v11 - Model Discovery

Actively fetches available Gemini model IDs from Google AI documentation.
Uses Playwright headless browser for JavaScript-rendered content.
Falls back to cached docs/MODEL_COMPATIBILITY_2026.md if fetching fails.
"""

import os
import re
from datetime import datetime
from pathlib import Path

DOCS_URL = "https://ai.google.dev/models/gemini"


def fetch_models_live():
    """
    Fetch current Gemini model IDs from Google AI documentation.

    Uses Playwright headless Chromium to render the page and extract
    model identifiers via regex pattern matching.

    Returns:
        list[str]: Sorted list of discovered model IDs, or empty list on failure.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("[!] Playwright not installed. Cannot fetch models actively.")
        return []

    print(f"[i] Fetching models from {DOCS_URL}...")

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()

            try:
                page.goto(DOCS_URL, timeout=30000)
                page.wait_for_load_state("networkidle", timeout=15000)
                content = page.content()

                matches = re.findall(r'gemini-[a-z0-9\-\.]+', content, re.IGNORECASE)

                valid_models = set()
                for m in matches:
                    m = m.lower().rstrip('.')
                    if (len(m) < 50
                            and 'api' not in m
                            and 'logo' not in m
                            and 'width' not in m
                            and 'icon' not in m
                            and 'card' not in m
                            and 'grid' not in m
                            and 'model-name' not in m
                            and 'model-desc' not in m
                            and 'model-row' not in m
                            and 'model-details' not in m
                            and 'centered' not in m):
                        valid_models.add(m)

                print(f"[+] Discovered {len(valid_models)} models.")
                return sorted(valid_models)

            except Exception as e:
                print(f"[!] Fetch error: {e}")
                return []
            finally:
                browser.close()

    except Exception as e:
        print(f"[!] Browser launch error: {e}")
        return []


def format_model_table(models):
    """
    Format discovered models into a human-readable table string.

    Args:
        models: List of model ID strings.

    Returns:
        str: Formatted table with model IDs and inferred status.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        f"Gemini Models (fetched {timestamp})",
        f"Source: {DOCS_URL}",
        "",
        f"{'Model ID':<45} {'Status':<15}",
        "-" * 60,
    ]

    for m in models:
        status = "Active"
        if "exp" in m:
            status = "Experimental"
        if "preview" in m:
            status = "Preview"
        if "latest" in m:
            status = "Latest Alias"
        if "deprecated" in m:
            status = "Deprecated"
        if "tts" in m:
            status = "TTS Preview"
        if "embedding" in m:
            status = "Embedding"
        if "live" in m:
            status = "Live Preview"
        if "robotics" in m:
            status = "Robotics"
        if "image" in m and "preview" in m:
            status = "Image Preview"

        lines.append(f"  {m:<43} {status:<15}")

    lines.append("")
    lines.append(f"Total: {len(models)} models discovered")

    return "\n".join(lines)


def update_cached_doc(models, project_root=None):
    """
    Update the cached MODEL_COMPATIBILITY_2026.md with fresh data.

    Args:
        models: List of model ID strings.
        project_root: Optional project root path. Defaults to cwd.
    """
    if not models:
        return

    root = Path(project_root) if project_root else Path.cwd()
    doc_path = root / "docs" / "MODEL_COMPATIBILITY_2026.md"

    if not doc_path.parent.exists():
        return

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(doc_path, 'w', encoding='utf-8') as f:
        f.write("# Gemini Model Compatibility Matrix (2026) [AUTO-GENERATED]\n\n")
        f.write(f"> **Generated**: {timestamp}\n")
        f.write(f"> **Source**: `frankenreview --available-models` from {DOCS_URL}\n\n")
        f.write("## Discovered Models\n\n")
        f.write("| Model ID | Status |\n")
        f.write("| :--- | :--- |\n")

        for m in models:
            status = "Active"
            if "exp" in m:
                status = "Experimental"
            if "preview" in m:
                status = "Preview"
            if "latest" in m:
                status = "Latest Alias"
            if "deprecated" in m:
                status = "Deprecated"

            f.write(f"| `{m}` | {status} |\n")

        f.write("\n## Recommended Configuration\n")
        f.write("- **Stable**: `gemini-flash-latest` (or newest flash variant)\n")
        f.write("- **Pro**: `gemini-3-pro` or `gemini-3.1-pro`\n")

    print(f"[+] Cached results to {doc_path}")
