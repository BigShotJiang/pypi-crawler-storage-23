"""
Frankenreview v11 - "Lean" Stateless Utility

A zero-cost, agentic code reviewer and research agent.
Implements a Pull model: invoke explicitly, get results deterministically.

Architecture (v11 Lean):
1. Dumper        - Pack the repo into a compact XML context (repo_dumper.py, token_governor.py)
2. Browser       - Bridge to free cloud compute via Google AI Studio (engine/browser/client.py)
3. CLI           - Stateless entrypoint: Input -> Review -> Output (cli.py)
4. Research      - Agentic deep research via Gemini Pro (research.py)

Usage:
    frankenreview                       # One-shot code review of current directory
    frankenreview -r --path /some/dir   # Review specific path
    frankenreview --research --prompt topic.md  # Research mode
    frankenreview --start-chrome        # Setup Chrome for AI Studio
    frankenreview --stop-chrome         # Stop Chrome debug instance
    frankenreview --help                # Show all options
"""

__version__ = "11.6.11"
__author__ = "SNiPERxDD"

# Identity and versioning only.
# Submodules must be imported directly (e.g. from frankenreview.engine.browser import StudioClient)
# to avoid eager loading of optional dependencies during startup.

__all__ = []
