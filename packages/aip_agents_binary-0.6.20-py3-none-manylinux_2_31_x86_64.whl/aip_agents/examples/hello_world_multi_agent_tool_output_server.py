"""Example A2A server demonstrating multi-agent tool output management.

This server provides a multi-agent system for data generation and visualization,
demonstrating how tool outputs can be shared across agent boundaries using
a shared ToolOutputManager.

Workflow:
1. CoordinatorAgent: Receives user request and delegates tasks.
2. GeneratorAgent: Generates sample data and stores it.
3. VisualizerAgent: Retrieves stored data via reference and creates visualizations.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

import click
import uvicorn
from a2a.types import AgentCapabilities, AgentCard, AgentSkill
from dotenv import load_dotenv

from aip_agents.agent import LangGraphReactAgent
from aip_agents.examples.tools.data_generator_tool import DataGeneratorTool
from aip_agents.examples.tools.data_visualization_tool import DataVisualizerTool
from aip_agents.storage.clients.minio_client import MinioConfig, MinioObjectStorage
from aip_agents.storage.providers.object_storage import ObjectStorageProvider
from aip_agents.utils.langgraph.tool_output_management import ToolOutputConfig, ToolOutputManager
from aip_agents.utils.logger import get_logger

load_dotenv()
logger = get_logger(__name__)

SERVER_AGENT_NAME = "MultiAgentDataVisualizationAgent"


@click.command()
@click.option("--host", default="localhost", help="Host to bind the server to")
@click.option("--port", default=8886, help="Port to bind the server to")
def main(host: str, port: int):
    """Run the Multi-Agent Data Visualization A2A server.

    Args:
        host (str): Host to bind the server to.
        port (int): Port to bind the server to.
    """
    logger.info(f"Starting {SERVER_AGENT_NAME} on http://{host}:{port}")

    # 1. Setup Shared Tool Output Management
    minio_config = MinioConfig.from_env()
    minio_client = MinioObjectStorage(minio_config)
    object_storage_provider = ObjectStorageProvider(
        client=minio_client,
        prefix="multi_agent_test",  # Unique prefix for this example
    )
    tool_output_config = ToolOutputConfig(
        storage_provider=object_storage_provider,
    )
    tool_output_manager = ToolOutputManager(tool_output_config)

    # 2. Create Specialized Agents
    model_name = "openai/gpt-4.1"

    # Generator Agent: Specializes in data generation
    generator_agent = LangGraphReactAgent(
        name="GeneratorAgent",
        instruction="""You are a data generation specialist.
Generate sample datasets (sales, scores, growth data) when requested.
Always ensure your tool outputs are stored for other agents to use.""",
        model=model_name,
        tools=[DataGeneratorTool()],
        tool_output_manager=tool_output_manager,
    )

    # Visualizer Agent: Specializes in data visualization
    visualizer_agent = LangGraphReactAgent(
        name="VisualizerAgent",
        instruction="""You are a data visualization specialist.
Create charts and visualizations from data references ($tool_output.call_id).
Do not try to generate data yourself; use the data provided by the GeneratorAgent.""",
        model=model_name,
        tools=[DataVisualizerTool()],
        tool_output_manager=tool_output_manager,
    )

    # 3. Create Coordinator Agent (The Main Entry Point)
    coordinator_agent = LangGraphReactAgent(
        name=SERVER_AGENT_NAME,
        instruction="""You are a coordinator that manages data workflows.
Delegate data generation tasks to the GeneratorAgent and visualization tasks to the VisualizerAgent.

When you receive a request:
1. Ask GeneratorAgent to generate the data.
2. Pass the resulting tool output reference ($tool_output.call_id) to the VisualizerAgent to create the chart.

Always use tool output references to avoid passing large amounts of data between agents.""",
        model=model_name,
        agents=[generator_agent, visualizer_agent],
        tool_output_manager=tool_output_manager,
    )

    # 4. Define Agent Card for A2A
    agent_card = AgentCard(
        name=SERVER_AGENT_NAME,
        description="Multi-agent system that generates and visualizes data using shared tool outputs",
        url=f"http://{host}:{port}",
        version="1.0.0",
        defaultInputModes=["text"],
        defaultOutputModes=["text"],
        capabilities=AgentCapabilities(streaming=True),
        skills=[
            AgentSkill(
                id="coordinated_analysis",
                name="Coordinated Data Analysis",
                description="End-to-end data generation and visualization via multiple specialized agents",
                examples=[
                    "Generate sales data and create a bar chart",
                    "Analyze student scores with a line chart",
                ],
                tags=["multi-agent", "data", "visualization"],
            ),
        ],
        tags=["multi-agent", "data", "visualization"],
    )

    # 5. Create and Run A2A App
    app = coordinator_agent.to_a2a(agent_card=agent_card)

    logger.info("A2A application configured. Starting Uvicorn server...")
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
