"""Simple A2A client demonstrating multi-agent tool output management.

This client connects to the multi-agent data visualization server and demonstrates
how tool outputs are shared across specialized agents (Generator -> Visualizer)
via the coordinator agent.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

import asyncio
import uuid

from dotenv import load_dotenv

from aip_agents.agent import LangGraphReactAgent
from aip_agents.schema.agent import A2AClientConfig

load_dotenv()


async def main() -> None:
    """Demonstrate multi-agent tool output management."""
    # Create client agent
    client = LangGraphReactAgent(
        name="Client",
        instruction="You request complex data analysis services.",
        model="openai/gpt-4o-mini",
    )

    # Discover the multi-agent server
    agents = client.discover_agents(A2AClientConfig(discovery_urls=["http://localhost:8886"]))
    if not agents:
        print("Error: Multi-agent server not found. Please run the server first.")
        return

    server_agent = agents[0]
    print(f"Connected to: {server_agent.name}")

    # Generate a unique thread ID for this session
    thread_id = str(uuid.uuid4())
    print(f"Session Thread ID: {thread_id}\n")

    query = "Generate sales data for 10 points and create a bar chart from it"
    print(f"Query: {query}\n")

    async for chunk in client.astream_to_agent(server_agent, query, config={"configurable": {"thread_id": thread_id}}):
        if chunk.get("content"):
            print(chunk["content"], end="", flush=True)
        if chunk.get("metadata"):
            print(f"\nMetadata: {chunk['metadata']}", end="\n\n", flush=True)

    print("\n\nDone.")


if __name__ == "__main__":
    asyncio.run(main())
