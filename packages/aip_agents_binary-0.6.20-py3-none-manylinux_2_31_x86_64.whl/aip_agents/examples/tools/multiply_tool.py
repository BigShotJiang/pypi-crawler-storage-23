"""Tool to multiply two integers.

Author: Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class MultiplyToolInput(BaseModel):
    """Input schema for the MultiplyTool."""

    a: int = Field(..., description="First factor.")
    b: int = Field(..., description="Second factor.")


class MultiplyToolConfig(BaseModel):
    """Configuration for MultiplyTool."""

    offset: int = Field(default=0, description="Offset to add to the result.")


class MultiplyTool(BaseTool):
    """Tool to multiply two integers."""

    name: str = "multiply"
    description: str = "Multiply two integers."
    args_schema: type[BaseModel] = MultiplyToolInput
    tool_config_schema: type[BaseModel] = MultiplyToolConfig

    def _run(self, a: int, b: int) -> int:
        """Return the product of two integers."""
        offset = 0
        if hasattr(self, "get_tool_config"):
            config = self.get_tool_config()
            if config:
                offset = getattr(config, "offset", 0)

        return a * b + offset

    async def _arun(self, a: int, b: int) -> int:
        """Return the product of two integers asynchronously."""
        return self._run(a=a, b=b)
