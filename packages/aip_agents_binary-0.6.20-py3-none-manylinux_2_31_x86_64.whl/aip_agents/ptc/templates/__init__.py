"""Shared templates for PTC sandbox code generation."""
