"""Top-level PTC Sandbox Bridge.

This module provides the unified entry point for building sandbox payloads
across different tool sources (MCP, custom tools, etc.).

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from __future__ import annotations

import json
from typing import Any

from aip_agents.mcp.client.base_mcp_client import BaseMCPClient
from aip_agents.ptc.custom_tools import (
    PTCCustomToolConfig,
    validate_custom_tool_config,
)
from aip_agents.ptc.custom_tools_payload import build_custom_tools_payload
from aip_agents.ptc.doc_gen import (
    render_tool_doc,
)
from aip_agents.ptc.exceptions import PTCPayloadConflictError
from aip_agents.ptc.mcp.sandbox_bridge import build_mcp_payload
from aip_agents.ptc.naming import sanitize_function_name, schema_to_params
from aip_agents.ptc.payload import SandboxPayload
from aip_agents.ptc.ptc_helper import _generate_ptc_helper_module


async def build_sandbox_payload(
    mcp_client: BaseMCPClient | None = None,
    default_tool_timeout: float = 60.0,
    custom_tools_config: PTCCustomToolConfig | None = None,
    tool_configs: dict[str, dict] | None = None,
) -> SandboxPayload:
    """Build sandbox payload from all configured tool sources.

    Composes MCP and custom LangChain tool payloads into a single payload.

    Args:
        mcp_client: The MCP client with configured servers. Can be None if only custom tools.
        default_tool_timeout: Default timeout for tool calls in seconds.
        custom_tools_config: Optional custom LangChain tools configuration.
        tool_configs: Optional per-tool config values for custom tools.

    Returns:
        SandboxPayload containing files and env vars for the sandbox.
    """
    # Build MCP payload
    mcp_payload = SandboxPayload()
    if mcp_client:
        mcp_payload = await build_mcp_payload(mcp_client, default_tool_timeout)

    # Build custom tools payload if enabled
    custom_payload = SandboxPayload()
    if custom_tools_config and custom_tools_config.enabled:
        # Validate config before building payload (fail fast)
        validate_custom_tool_config(custom_tools_config)
        result = build_custom_tools_payload(custom_tools_config, tool_configs)
        custom_payload = result.payload

    # Check for conflicts before merging payloads
    _check_payload_conflicts(mcp_payload, custom_payload)

    # Merge payloads (custom tools files should not conflict with MCP files)
    merged = SandboxPayload()
    merged.files.update(mcp_payload.files)
    merged.files.update(custom_payload.files)
    merged.per_run_files.update(mcp_payload.per_run_files)
    merged.per_run_files.update(custom_payload.per_run_files)
    merged.env.update(mcp_payload.env)
    merged.env.update(custom_payload.env)

    # Merge custom tools into ptc_index.json
    if custom_tools_config and custom_tools_config.enabled and custom_tools_config.tools:
        merged.files["tools/ptc_index.json"] = _merge_custom_tools_into_index(
            merged.files.get("tools/ptc_index.json"),
            custom_tools_config,
        )
        if "tools/ptc_helper.py" not in merged.files:
            merged.files["tools/ptc_helper.py"] = _generate_ptc_helper_module()
        # Generate documentation for custom tools
        custom_docs = _generate_custom_tool_docs(custom_tools_config)
        merged.files.update(custom_docs)

    return merged


def _check_payload_conflicts(
    mcp_payload: SandboxPayload,
    custom_payload: SandboxPayload,
) -> None:
    """Check for conflicts between MCP and custom tool payloads.

    Args:
        mcp_payload: Payload from MCP tool configuration.
        custom_payload: Payload from custom tool configuration.

    Raises:
        PTCPayloadConflictError: If any conflicts are detected in files,
            per-run files, or environment variables.
    """
    mcp_files = set(mcp_payload.files.keys())
    custom_files = set(custom_payload.files.keys())
    file_conflicts = mcp_files & custom_files

    mcp_per_run = set(mcp_payload.per_run_files.keys())
    custom_per_run = set(custom_payload.per_run_files.keys())
    per_run_conflicts = mcp_per_run & custom_per_run

    mcp_env_keys = set(mcp_payload.env.keys())
    custom_env_keys = set(custom_payload.env.keys())
    env_conflicts = mcp_env_keys & custom_env_keys

    all_conflicts = file_conflicts | per_run_conflicts | env_conflicts
    if all_conflicts:
        raise PTCPayloadConflictError(
            f"Conflicts detected when merging MCP and custom tool payloads. "
            f"Files: {sorted(file_conflicts)}, "
            f"Per-run files: {sorted(per_run_conflicts)}, "
            f"Environment variables: {sorted(env_conflicts)}",
            conflicts=all_conflicts,
        )


def _merge_custom_tools_into_index(
    existing_index_json: str | None,
    custom_tools_config: PTCCustomToolConfig,
) -> str:
    """Merge custom tools into the ptc_index.json.

    Args:
        existing_index_json: Existing ptc_index.json content (may be None).
        custom_tools_config: Custom tools configuration.

    Returns:
        Updated JSON string with custom tools included.
    """
    # Parse existing index or create new one
    if existing_index_json:
        index = json.loads(existing_index_json)
    else:
        index = {"packages": {}}

    # Add custom tools package
    tool_entries = []
    for tool_def in sorted(custom_tools_config.tools, key=lambda t: sanitize_function_name(t.get("name", ""))):
        name = tool_def.get("name", "")
        func_name = sanitize_function_name(name)
        schema = tool_def.get("input_schema", {"type": "object", "properties": {}})
        signature = f"{func_name}({schema_to_params(schema)})"

        tool_entries.append(
            {
                "name": func_name,
                "signature": signature,
                "doc_path": f"tools/docs/custom/{func_name}.md",
            }
        )

    index["packages"]["custom"] = {"tools": tool_entries}

    return json.dumps(index, indent=2, sort_keys=True)


def _generate_custom_tool_docs(custom_tools_config: PTCCustomToolConfig) -> dict[str, str]:
    """Generate documentation files for custom tools.

    Args:
        custom_tools_config: Custom tools configuration.

    Returns:
        Dict mapping file path to content.
    """
    docs: dict[str, str] = {}

    for tool_def in sorted(custom_tools_config.tools, key=lambda t: sanitize_function_name(t.get("name", ""))):
        name = tool_def.get("name", "")
        func_name = sanitize_function_name(name)
        description = tool_def.get("description", "")
        schema = tool_def.get("input_schema", {"type": "object", "properties": {}})

        doc_content = _generate_tool_doc_content(func_name, description, schema)
        docs[f"tools/docs/custom/{func_name}.md"] = doc_content

    return docs


def _generate_tool_doc_content(
    func_name: str,
    description: str,
    schema: dict[str, Any],
) -> str:
    """Generate markdown documentation for a single tool.

    Args:
        func_name: Sanitized function name.
        description: Tool description.
        schema: JSON schema for tool input.

    Returns:
        Markdown documentation string.
    """
    # Use schema_to_params for consistent signatures
    params = schema_to_params(schema)
    signature = f"{func_name}({params})"

    example_code = f"from tools.custom import {func_name}\nresult = {func_name}(...)\nprint(result)"

    return render_tool_doc(
        func_name=func_name,
        signature=signature,
        description=description,
        schema=schema,
        example_code=example_code,
    )


def wrap_ptc_code(code: str, include_packages_path: bool = False) -> str:
    """Wrap user PTC code with necessary imports and setup.

    This prepends sys.path setup to ensure the tools package is importable.
    When custom tools with bundled package sources are enabled, also adds
    the packages/ directory to sys.path.

    Args:
        code: User-provided Python code.
        include_packages_path: If True, also add packages/ dir to sys.path
            for bundled package sources from custom LangChain tools.

    Returns:
        Wrapped code ready for sandbox execution.
    """
    preamble = """# PTC Code Wrapper - Auto-generated
import sys
import os

# Add tools package to path
_tools_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in dir() else os.getcwd()
if _tools_dir not in sys.path:
    sys.path.insert(0, _tools_dir)
"""

    if include_packages_path:
        preamble += """
# Add packages directory to path for bundled custom tool sources
_packages_dir = os.path.join(_tools_dir, "packages")
if os.path.isdir(_packages_dir) and _packages_dir not in sys.path:
    sys.path.insert(0, _packages_dir)
"""

    preamble += """
# User code below
"""
    return preamble + code
