"""Helper functions for constructing PTC tool definitions.

Author: Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)

These helpers provide a cleaner API for defining custom tools in PTCCustomToolConfig.
They return properly-typed dictionaries that can be used in PTCCustomToolConfig.tools.

Example:
    >>> from aip_agents.ptc import package_tool, file_tool, PTCCustomToolConfig
    >>> config = PTCCustomToolConfig(
    ...     enabled=True,
    ...     tools=[
    ...         package_tool("time_tool", import_path="aip_agents.tools.time_tool", class_name="TimeTool"),
    ...         file_tool("multiply", file_path="/path/to/multiply.py", class_name="MultiplyTool"),
    ...     ]
    ... )
"""

from __future__ import annotations

from typing import Any

from aip_agents.ptc.custom_tools import PTCFileToolDef, PTCPackageToolDef


def package_tool(
    name: str,
    *,
    import_path: str,
    class_name: str,
    package_path: str | None = None,
    description: str | None = None,
    input_schema: dict[str, Any] | None = None,
) -> PTCPackageToolDef:
    """Create a package-based tool definition.

    Args:
        name: Tool name (will be sanitized for Python compatibility).
        import_path: Python import path (e.g., "aip_agents.tools.time_tool").
        class_name: Tool class name to instantiate.
        package_path: Optional local package path for bundling.
        description: Optional tool description (auto-derived from tool if not provided).
        input_schema: Optional JSON schema (auto-derived from tool if not provided).

    Returns:
        PTCPackageToolDef dict ready for use in PTCCustomToolConfig.tools.

    Example:
        >>> package_tool("time_tool", import_path="aip_agents.tools.time_tool", class_name="TimeTool")
        {'name': 'time_tool', 'kind': 'package', 'import_path': 'aip_agents.tools.time_tool', 'class_name': 'TimeTool'}
    """
    result: PTCPackageToolDef = {
        "name": name,
        "kind": "package",
        "import_path": import_path,
        "class_name": class_name,
    }
    if package_path is not None:
        result["package_path"] = package_path
    if description is not None:
        result["description"] = description
    if input_schema is not None:
        result["input_schema"] = input_schema
    return result


def file_tool(
    name: str,
    *,
    file_path: str,
    class_name: str,
    description: str | None = None,
    input_schema: dict[str, Any] | None = None,
) -> PTCFileToolDef:
    """Create a file-based tool definition.

    Args:
        name: Tool name (will be sanitized for Python compatibility).
        file_path: Absolute path to the Python file containing the tool.
        class_name: Tool class name to instantiate.
        description: Optional tool description (auto-derived from tool if not provided).
        input_schema: Optional JSON schema (auto-derived from tool if not provided).

    Returns:
        PTCFileToolDef dict ready for use in PTCCustomToolConfig.tools.

    Example:
        >>> file_tool("multiply", file_path="/path/to/multiply_tool.py", class_name="MultiplyTool")
        {'name': 'multiply', 'kind': 'file', 'file_path': '/path/to/multiply_tool.py', 'class_name': 'MultiplyTool'}
    """
    result: PTCFileToolDef = {
        "name": name,
        "kind": "file",
        "file_path": file_path,
        "class_name": class_name,
    }
    if description is not None:
        result["description"] = description
    if input_schema is not None:
        result["input_schema"] = input_schema
    return result
