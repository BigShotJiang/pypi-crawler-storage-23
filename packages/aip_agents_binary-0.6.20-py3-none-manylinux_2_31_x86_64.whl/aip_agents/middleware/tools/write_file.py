"""Write file tool for agents.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)

TODO: When migrating to deepagents, replace this entire file with:
    from deepagents.middleware.tools.write_file import WriteFileTool, WriteFileInput

    Note: deepagents WriteFileTool uses ToolRuntime pattern instead of BaseTool.
    We'll need to adapt our middleware to use deepagents' tool registration.
"""

from typing import Annotated, Any

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, SkipValidation

WRITE_FILE_TOOL_DESCRIPTION = """Writes to a new file in the filesystem.

Usage:
- The write_file tool will create the a new file.
"""


class WriteFileInput(BaseModel):
    """Input schema for ``write_file``.

    Attributes:
        path (str): Absolute destination path for the new file.
        content (str): UTF-8 text content to write.
    """

    path: str = Field(description="Absolute path to the file to write. Must be absolute, not relative.")
    content: str = Field(description="Content to write to the file.")


class WriteFileTool(BaseTool):
    """Create a new file in the configured filesystem backend.

    This tool enforces create-only semantics: if the target path already exists,
    it returns an error instead of overwriting the file.

    Attributes:
        name (str): Tool identifier exposed to the model.
        description (str): Human-readable usage guidance for the model.
        args_schema (type[BaseModel]): Pydantic schema for tool arguments.
        backend (Any): Filesystem backend implementing ``read`` and ``write``.
    """

    name: str = "write_file"
    description: str = WRITE_FILE_TOOL_DESCRIPTION
    args_schema: type[BaseModel] = WriteFileInput
    backend: Annotated[Any, SkipValidation()]  # BackendProtocol - skip validation for Protocol type

    def _file_exists(self, path: str) -> bool:
        """Check whether a filesystem entry already exists at ``path``.

        Args:
            path (str): Absolute path to inspect.

        Returns:
            bool: ``True`` when a file or directory exists at ``path``;
            ``False`` when the path does not exist.
        """
        try:
            self.backend.read(path, offset=0, limit=1)
            return True
        except FileNotFoundError:
            return False
        except IsADirectoryError:
            return True

    def _run(self, path: str, content: str) -> str:
        """Create a new file with the provided content.

        Args:
            path (str): Absolute destination path for the new file.
            content (str): Full file content to persist.

        Returns:
            str: Success or error status message. Returns
            ``"Successfully wrote {n} characters to {path}"`` on success,
            or ``"Error: ..."`` when creation fails.

        Notes:
            This method catches runtime exceptions and converts them to
            user-facing error messages; it does not raise exceptions.

        Examples:
            >>> tool._run(path="/reports/summary.md", content="# Summary")
            'Successfully wrote 9 characters to /reports/summary.md'
            >>> tool._run(path="/reports/summary.md", content="# New")
            'Error: File already exists: /reports/summary.md'
        """
        try:
            if self._file_exists(path):
                return f"Error: File already exists: {path}"

            result = self.backend.write(path, content)
            if result.success:
                return f"Successfully wrote {len(content)} characters to {path}"
            else:
                return f"Error: {result.error or 'Unknown error'}"
        except PermissionError:
            return f"Error: Permission denied: {path}"
        except Exception as e:
            return f"Error: {str(e)}"
