"""Backend protocol and types for filesystem middleware.

This module defines the BackendProtocol interface and data types
for filesystem backend implementations. These are self-contained
definitions that do not depend on external packages like deepagents.

TODO: When migrating to deepagents, replace this entire file with:
    from deepagents.backends.protocol import (
        BackendProtocol,
        FileInfo,
        WriteResult,
        EditResult,
        GrepMatch,
    )

Note: deepagents set_files/get_files are NOT in their protocol - they are
our extensions for state synchronization. Keep those as extensions.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

from typing import Any, Protocol, TypedDict


# TODO: Replace with deepagents.backends.protocol.FileInfo
class FileInfo(TypedDict):
    """Information about a file in the filesystem.

    Attributes:
        path: Absolute path to the file.
        type: File type, either "file" or "directory".
        size: Size of the file in bytes (optional).
    """

    path: str
    type: str  # "file" or "directory"
    size: int | None


# TODO: Replace with deepagents.backends.protocol.WriteResult
class WriteResult:
    """Result of a write operation.

    Attributes:
        path: Path that was written.
        success: Whether the write succeeded.
        error: Error message if write failed (None if success).
    """

    def __init__(
        self,
        path: str,
        success: bool = True,
        error: str | None = None,
    ) -> None:
        """Initialize write result.

        Args:
            path: Path that was written.
            success: Whether write succeeded. Defaults to True.
            error: Error message if failed. Defaults to None.
        """
        self.path = path
        self.success = success
        self.error = error


# TODO: Replace with deepagents.backends.protocol.EditResult
class EditResult:
    """Result of an edit operation.

    Attributes:
        path: Path that was edited.
        occurrences: Number of replacements made.
        success: Whether the edit succeeded.
        error: Error message if edit failed (None if success).
    """

    def __init__(
        self,
        path: str,
        occurrences: int = 0,
        success: bool = True,
        error: str | None = None,
    ) -> None:
        """Initialize edit result.

        Args:
            path: Path that was edited.
            occurrences: Number of replacements. Defaults to 0.
            success: Whether edit succeeded. Defaults to True.
            error: Error message if failed. Defaults to None.
        """
        self.path = path
        self.occurrences = occurrences
        self.success = success
        self.error = error


# TODO: Replace with deepagents.backends.protocol.GrepMatch
class GrepMatch:
    """A match from a grep search.

    Attributes:
        path: File path where match was found.
        line_number: Line number of the match (1-indexed).
        content: The matching line content.
    """

    def __init__(
        self,
        path: str,
        line_number: int,
        content: str,
    ) -> None:
        """Initialize grep match.

        Args:
            path: File path where match was found.
            line_number: Line number (1-indexed).
            content: The matching line content.
        """
        self.path = path
        self.line_number = line_number
        self.content = content


# TODO: Replace with deepagents.backends.protocol.BackendProtocol
class BackendProtocol(Protocol):
    """Protocol for filesystem backend implementations.

    This protocol defines the interface that all filesystem backends
    must implement. It provides methods for file operations like
    reading, writing, editing, and searching.

    Implementations:
        - InMemoryBackend: Stores files in memory (for testing/single-session)
        - Future: SandboxBackend for isolated execution
        - Future: PersistentBackend for cross-session storage

    Example:
        >>> class MyBackend:
        ...     def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        ...         return "file content"
        ...     # ... implement other methods
    """

    def ls_info(self, path: str) -> list[FileInfo]:
        """List files in a directory.

        Args:
            path: Directory path to list (absolute).

        Returns:
            List of FileInfo objects for files in the directory.

        Raises:
            FileNotFoundError: If path does not exist.
            NotADirectoryError: If path is not a directory.
        """
        ...

    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        """Read a file's contents.

        Args:
            file_path: Path to the file (absolute).
            offset: Line number to start from (0-indexed). Defaults to 0.
            limit: Maximum number of lines to read. Defaults to 2000.

        Returns:
            File content as string.

        Raises:
            FileNotFoundError: If file does not exist.
        """
        ...

    def write(self, file_path: str, content: str) -> WriteResult:
        """Write content to a file.

        Args:
            file_path: Path where to write (absolute).
            content: Content to write.

        Returns:
            WriteResult indicating success/failure.
        """
        ...

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
    ) -> EditResult:
        """Edit a file by replacing old_string with new_string.

        Args:
            file_path: Path to the file (absolute).
            old_string: String to find and replace.
            new_string: String to replace with.

        Returns:
            EditResult with number of replacements.

        Raises:
            FileNotFoundError: If file does not exist.
            ValueError: If old_string not found in file.
        """
        ...

    def glob_info(self, pattern: str, path: str = "/") -> list[FileInfo]:
        """Find files matching a glob pattern.

        Args:
            pattern: Glob pattern (e.g., "**/*.py", "*.txt").
            path: Base directory to search from. Defaults to "/".

        Returns:
            List of FileInfo objects for matching files.
        """
        ...

    def grep_raw(
        self,
        pattern: str,
        path: str | None = None,
    ) -> list[GrepMatch] | str:
        """Search for text pattern across files.

        Args:
            pattern: Text pattern to search (literal string, not regex).
            path: Directory to search in. Defaults to None (search all).

        Returns:
            List of GrepMatch objects, or error string.
        """
        ...

    # State synchronization methods (for middleware integration)
    def set_files(self, files: dict[str, Any], thread_id: str = "default") -> None:
        """Load files from state for a specific thread.

        Called by FilesystemMiddleware.before_model to restore files
        from checkpointed state into the backend.

        Args:
            files: Dictionary mapping file paths to file data.
            thread_id: Thread identifier for isolation. Defaults to "default".
        """
        ...

    def get_files(self, thread_id: str = "default") -> dict[str, Any]:
        """Get files for a specific thread.

        Called by FilesystemMiddleware.after_model to save files
        from backend into state for checkpointing.

        Args:
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            Dictionary mapping file paths to file data.
        """
        ...


__all__ = [
    "BackendProtocol",
    "FileInfo",
    "WriteResult",
    "EditResult",
    "GrepMatch",
]
