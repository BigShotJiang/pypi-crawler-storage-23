"""Backend implementations for filesystem middleware.

This package provides backend implementations for filesystem storage,
including in-memory storage and protocol definitions.

TODO: When migrating to deepagents:
  1. Replace protocol imports with deepagents.backends.protocol
  2. Replace utils imports with deepagents.backends.utils
  3. InMemoryBackend can stay or be replaced with StateBackend

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from aip_agents.middleware.backends.in_memory import InMemoryBackend
from aip_agents.middleware.backends.local_disk import LocalDiskBackend

# TODO: Replace with deepagents.backends.protocol imports
from aip_agents.middleware.backends.protocol import (
    BackendProtocol,
    EditResult,
    FileInfo,
    GrepMatch,
    WriteResult,
)

# TODO: Replace with deepagents.backends.utils imports
from aip_agents.middleware.backends.utils import (
    ensure_absolute_path,
    format_content_with_line_numbers,
    format_grep_matches,
    perform_string_replacement,
    sanitize_tool_call_id,
    truncate_if_too_long,
)

__all__ = [
    "InMemoryBackend",
    "LocalDiskBackend",
    "BackendProtocol",
    "FileInfo",
    "WriteResult",
    "EditResult",
    "GrepMatch",
    "ensure_absolute_path",
    "format_content_with_line_numbers",
    "perform_string_replacement",
    "format_grep_matches",
    "truncate_if_too_long",
    "sanitize_tool_call_id",
]
