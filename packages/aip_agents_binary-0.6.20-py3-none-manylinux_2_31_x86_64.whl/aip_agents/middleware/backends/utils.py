"""Utility functions for filesystem backend operations.

These utilities are copied from deepagents.backends.utils to ensure
compatibility and identical behavior when we migrate to deepagents.

TODO: When migrating to deepagents, replace this file with:
    from deepagents.backends.utils import (
        format_content_with_line_numbers,
        perform_string_replacement,
        format_grep_matches,
        truncate_if_too_long,
        sanitize_tool_call_id,
    )

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from aip_agents.middleware.backends.protocol import GrepMatch


# Constants from deepagents
EMPTY_CONTENT_WARNING = "System reminder: File exists but has empty contents"
MAX_LINE_LENGTH = 5000
LINE_NUMBER_WIDTH = 6
TOOL_RESULT_TOKEN_LIMIT = 8000
NUM_CHARS_PER_TOKEN = 4

TRUNCATION_GUIDANCE = "... [results truncated, try being more specific with your parameters]"


def ensure_absolute_path(path: str) -> str:
    """Normalize path to absolute form (leading /) for tool output consistency.

    Backends may return relative paths (e.g. LocalDiskBackend). Tools that return
    paths to the agent must use absolute paths so read_file and other tools
    receive consistent input per the filesystem contract.

    Args:
        path: Path from backend (may be relative or absolute).

    Returns:
        Path with leading / (absolute form). Idempotent if already absolute.

    Example:
        >>> ensure_absolute_path("workspace/file.txt")
        '/workspace/file.txt'
        >>> ensure_absolute_path("/workspace/file.txt")
        '/workspace/file.txt'
    """
    if path.startswith("/"):
        return path
    return f"/{path}"


def format_content_with_line_numbers(
    content: str,
    offset: int = 0,
    line_number_width: int = LINE_NUMBER_WIDTH,
) -> str:
    r"""Format content with cat -n style line numbers.

    Args:
        content: The file content to format.
        offset: Starting line number (0-indexed). Defaults to 0.
        line_number_width: Width of line number column. Defaults to 6.

    Returns:
        Formatted string with line numbers.

    Example:
        >>> format_content_with_line_numbers("line1\nline2", offset=0)
        '     1\tline1\n     2\tline2'
    """
    if not content:
        return EMPTY_CONTENT_WARNING

    lines = content.splitlines(keepends=True)
    formatted_lines = []

    for i, line in enumerate(lines, start=offset + 1):
        # Handle very long lines by splitting them
        if len(line) > MAX_LINE_LENGTH:
            # Split long line into chunks
            chunks = []
            for j in range(0, len(line), MAX_LINE_LENGTH):
                chunk = line[j : j + MAX_LINE_LENGTH]
                if j == 0:
                    # First chunk gets the line number
                    line_num = str(i).rjust(line_number_width)
                    chunks.append(f"{line_num}\t{chunk}")
                else:
                    # Continuation chunks get decimal notation (e.g., 5.1, 5.2)
                    continuation_num = f"{i}.{j // MAX_LINE_LENGTH}"
                    line_num = continuation_num.rjust(line_number_width)
                    chunks.append(f"{line_num}\t{chunk}")
            formatted_lines.extend(chunks)
        else:
            line_num = str(i).rjust(line_number_width)
            formatted_lines.append(f"{line_num}\t{line}")

    return "".join(formatted_lines)


def perform_string_replacement(
    content: str,
    old_string: str,
    new_string: str,
    replace_all: bool = False,
) -> tuple[str, int]:
    """Perform string replacement in content.

    Args:
        content: Original content.
        old_string: String to find and replace.
        new_string: String to replace with.
        replace_all: If True, replace all occurrences. Defaults to False.

    Returns:
        Tuple of (new_content, occurrences).

    Raises:
        ValueError: If old_string not found or appears multiple times
            without replace_all=True.
    """
    if old_string not in content:
        raise ValueError(f"String not found: {old_string!r}")

    occurrences = content.count(old_string)

    if occurrences > 1 and not replace_all:
        raise ValueError(f"String appears {occurrences} times. Use replace_all=True to replace all occurrences.")

    if replace_all:
        new_content = content.replace(old_string, new_string)
    else:
        new_content = content.replace(old_string, new_string, 1)

    return new_content, occurrences if replace_all else 1


def format_grep_matches(
    matches: list[GrepMatch],
    output_mode: str = "files_with_matches",
) -> str:
    """Format grep matches for display.

    Args:
        matches: List of GrepMatch objects.
        output_mode: One of "files_with_matches", "content", or "count".
            Defaults to "files_with_matches".

    Returns:
        Formatted string based on output_mode.

    Raises:
        ValueError: If output_mode is invalid.
    """
    if not matches:
        return "No matches found."

    if output_mode == "files_with_matches":
        # Just list unique file paths
        file_paths = sorted(set(match.path for match in matches))
        return "\n".join(file_paths)

    elif output_mode == "content":
        # Show file:line_number: content
        formatted = []
        for match in matches:
            formatted.append(f"{match.path}:{match.line_number}: {match.content}")
        return "\n".join(formatted)

    elif output_mode == "count":
        # Count matches per file
        from collections import Counter

        counts = Counter(match.path for match in matches)
        formatted = []
        for path in sorted(counts.keys()):
            formatted.append(f"{path}: {counts[path]} matches")
        return "\n".join(formatted)

    else:
        raise ValueError(f"Invalid output_mode: {output_mode}")


def truncate_if_too_long(
    content: list[str] | str,
    token_limit: int = TOOL_RESULT_TOKEN_LIMIT,
) -> list[str] | str:
    """Truncate content if it exceeds token limit.

    Uses 4 characters per token as a rough estimate.
    For lists, keeps whole items (drops from end) to avoid broken paths/lines.

    Args:
        content: String or list of strings to truncate.
        token_limit: Maximum tokens allowed. Defaults to 8000.

    Returns:
        Truncated content if too long, otherwise original content.
    """
    char_limit = token_limit * NUM_CHARS_PER_TOKEN

    if isinstance(content, list):
        total_chars = sum(len(item) for item in content)
        if total_chars <= char_limit:
            return content
        n_keep = max(1, len(content) * char_limit // total_chars)
        return content[:n_keep] + [TRUNCATION_GUIDANCE]
    else:
        if len(content) <= char_limit:
            return content
        return content[:char_limit] + TRUNCATION_GUIDANCE


def sanitize_tool_call_id(tool_call_id: str) -> str:
    """Sanitize tool call ID for use in filenames.

    Replaces dangerous characters that could cause path traversal.

    Args:
        tool_call_id: The tool call ID to sanitize.

    Returns:
        Sanitized string safe for use in filenames.
    """
    # Replace path separators and dots with underscores
    sanitized = re.sub(r"[\/\\\.]", "_", tool_call_id)
    return sanitized


__all__ = [
    "ensure_absolute_path",
    "format_content_with_line_numbers",
    "format_grep_matches",
    "perform_string_replacement",
    "sanitize_tool_call_id",
    "truncate_if_too_long",
    "EMPTY_CONTENT_WARNING",
    "MAX_LINE_LENGTH",
    "LINE_NUMBER_WIDTH",
    "TRUNCATION_GUIDANCE",
]
