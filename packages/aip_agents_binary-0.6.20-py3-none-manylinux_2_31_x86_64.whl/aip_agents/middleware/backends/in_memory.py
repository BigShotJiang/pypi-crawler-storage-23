"""In-memory filesystem backend implementation.

This module provides InMemoryBackend, a BackendProtocol implementation
that stores files in memory with thread-isolated storage.

TODO: When migrating to deepagents:
  1. Import BackendProtocol and types from deepagents.backends.protocol
  2. Import utility functions from deepagents.backends.utils (same API)

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

import re
import threading
import time
from typing import Any

# TODO: Replace with deepagents.backends.protocol imports
from aip_agents.middleware.backends.protocol import (
    BackendProtocol,
    EditResult,
    FileInfo,
    GrepMatch,
    WriteResult,
)
from aip_agents.middleware.backends.utils import format_content_with_line_numbers

__all__ = ["InMemoryBackend"]


class InMemoryBackend(BackendProtocol):
    """In-memory filesystem backend.

    Explicitly implements BackendProtocol with thread-isolated storage.
    Stores files in memory per thread_id, making it suitable for
    agent conversations where each thread needs isolated file storage.

    Thread Safety:
        All operations are protected by threading.RLock to ensure
        thread-safe access to the shared storage.

    Attributes:
        _storage: Dictionary mapping thread_id to {path: FileData}.
        _storage_lock: RLock protecting concurrent access to _storage.

    Example:
        >>> backend = InMemoryBackend()
        >>> files = {"/test.txt": {"content": ["Hello"], "created_at": "2024-01-01", "modified_at": "2024-01-01"}}
        >>> backend.set_files(files, thread_id="thread-1")
        >>> retrieved = backend.get_files(thread_id="thread-1")
        >>> "/test.txt" in retrieved
        True
    """

    def __init__(self) -> None:
        """Initialize with empty storage."""
        self._storage: dict[str, dict[str, Any]] = {}
        self._storage_lock = threading.RLock()

    def set_files(self, files: dict[str, Any], thread_id: str = "default") -> None:
        """Load files from state for a specific thread.

        Called by FilesystemMiddleware.before_model to restore files
        from checkpointed state into the backend.

        Args:
            files: Dictionary mapping file paths to FileData.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Note:
            Makes a copy of the files dict to prevent external modifications
            affecting internal storage.
        """
        with self._storage_lock:
            self._storage[thread_id] = files.copy()

    def get_files(self, thread_id: str = "default") -> dict[str, Any]:
        """Get files for a specific thread.

        Called by FilesystemMiddleware.after_model to save files
        from backend into state for checkpointing.

        Args:
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            Dictionary mapping file paths to FileData, or empty dict
            if no files for this thread.

        Note:
            Returns a copy to prevent external modifications affecting
            internal storage.
        """
        with self._storage_lock:
            return self._storage.get(thread_id, {}).copy()

    def _get_thread_storage(self, thread_id: str = "default") -> dict[str, Any]:
        """Get or create storage for a thread.

        Args:
            thread_id: Thread identifier.

        Returns:
            Storage dictionary for the thread.
        """
        with self._storage_lock:
            if thread_id not in self._storage:
                self._storage[thread_id] = {}
            return self._storage[thread_id]

    def _normalize_path(self, path: str) -> str:
        """Normalize a path to absolute form.

        Args:
            path: Path to normalize.

        Returns:
            Normalized absolute path.
        """
        if not path.startswith("/"):
            path = "/" + path
        # Remove trailing slashes except for root
        path = path.rstrip("/") or "/"
        return path

    def write(
        self,
        file_path: str,
        content: str | list[str],
        thread_id: str = "default",
    ) -> WriteResult:
        """Write content to a file.

        Args:
            file_path: Path where to write the file.
            content: Content to write (string or list of strings).
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            WriteResult indicating success.
        """
        path = self._normalize_path(file_path)
        storage = self._get_thread_storage(thread_id)

        # Normalize content to list of strings
        if isinstance(content, str):
            lines = content.split("\n")
        else:
            lines = list(content)

        now = time.strftime("%Y-%m-%dT%H:%M:%S")

        with self._storage_lock:
            is_new = path not in storage
            storage[path] = {
                "content": lines,
                "created_at": storage.get(path, {}).get("created_at", now) if not is_new else now,
                "modified_at": now,
            }

        return WriteResult(path=path, success=True)

    def read(
        self,
        file_path: str,
        offset: int = 0,
        limit: int = 2000,
        thread_id: str = "default",
    ) -> str:
        """Read a file's contents with line numbers.

        Args:
            file_path: Path to the file.
            offset: Line number to start reading from (0-indexed).
            limit: Maximum number of lines to read.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            File content formatted with line numbers.

        Raises:
            FileNotFoundError: If file does not exist.
        """
        path = self._normalize_path(file_path)
        storage = self._get_thread_storage(thread_id)

        with self._storage_lock:
            if path not in storage:
                raise FileNotFoundError(f"File not found: {file_path}")

            file_data = storage[path]
            lines = file_data.get("content", [])

            # Apply offset and limit
            start = max(0, offset)
            end = min(len(lines), start + limit)
            selected_lines = lines[start:end]

            content = "\n".join(selected_lines)
            if not content:
                return ""
            return format_content_with_line_numbers(content, offset=start)

    def ls_info(self, path: str, thread_id: str = "default") -> list[FileInfo]:
        """List files in a directory.

        Args:
            path: Directory path to list.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            List of FileInfo objects.

        Raises:
            FileNotFoundError: If directory does not exist (treats root as always existing).
        """
        path = self._normalize_path(path)
        storage = self._get_thread_storage(thread_id)

        with self._storage_lock:
            if path == "/":
                # List all files (we don't have directories, just files)
                result = []
                for file_path, file_data in storage.items():
                    content = file_data.get("content", [])
                    size = sum(len(line.encode("utf-8")) for line in content)
                    result.append(FileInfo(path=file_path, type="file", size=size))
                return result
            else:
                # For non-root, check if any files exist with this prefix
                prefix = path if path.endswith("/") else path + "/"
                matching_files = [fp for fp in storage.keys() if fp.startswith(prefix) or fp == path]

                if not matching_files:
                    raise FileNotFoundError(f"Directory not found: {path}")

                result = []
                for file_path in matching_files:
                    file_data = storage[file_path]
                    content = file_data.get("content", [])
                    size = sum(len(line.encode("utf-8")) for line in content)
                    result.append(FileInfo(path=file_path, type="file", size=size))
                return result

    def _get_files_to_search(self, storage: dict[str, Any], path: str | None) -> list[str]:
        """Get list of files to search based on path filter.

        Args:
            storage: Storage dictionary for the thread.
            path: Directory to search in, or None for all files.

        Returns:
            List of file paths to search.

        Raises:
            FileNotFoundError: If path is specified but directory does not exist.
        """
        if path is None or path == "/":
            return list(storage.keys())

        normalized_path = self._normalize_path(path)
        prefix = normalized_path if normalized_path.endswith("/") else normalized_path + "/"
        files_to_search = [fp for fp in storage.keys() if fp.startswith(prefix) or fp == normalized_path]

        if normalized_path != "/" and not files_to_search:
            raise FileNotFoundError(f"Path not found: {path}")

        return files_to_search

    def _compile_pattern(self, pattern: str) -> re.Pattern[str]:
        """Compile pattern as regex, falling back to literal if invalid.

        Args:
            pattern: Pattern to compile.

        Returns:
            Compiled regex pattern.
        """
        try:
            return re.compile(pattern, re.IGNORECASE)
        except re.error:
            return re.compile(re.escape(pattern), re.IGNORECASE)

    def grep(
        self,
        pattern: str,
        path: str | None = None,
        thread_id: str = "default",
    ) -> list[GrepMatch]:
        """Search for text pattern across files.

        Args:
            pattern: Text pattern to search for (literal string, not regex).
            path: Directory to search in. Defaults to None (search all).
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            List of GrepMatch objects.

        Raises:
            FileNotFoundError: If path is specified but directory does not exist.
        """
        storage = self._get_thread_storage(thread_id)
        matches = []

        with self._storage_lock:
            files_to_search = self._get_files_to_search(storage, path)
            regex = self._compile_pattern(pattern)

            for file_path in files_to_search:
                file_data = storage.get(file_path, {})
                lines = file_data.get("content", [])

                for line_num, line in enumerate(lines, start=1):
                    if regex.search(line):
                        matches.append(
                            GrepMatch(
                                path=file_path,
                                line_number=line_num,
                                content=line,
                            )
                        )

        return matches

    # Alias grep_raw to grep for protocol compatibility
    grep_raw = grep

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        thread_id: str = "default",
    ) -> EditResult:
        """Edit a file by replacing old_string with new_string.

        Args:
            file_path: Path to the file to edit.
            old_string: String to find and replace.
            new_string: String to replace with.
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            EditResult with number of replacements.

        Raises:
            FileNotFoundError: If file does not exist.
            ValueError: If old_string not found in file.
        """
        path = self._normalize_path(file_path)
        storage = self._get_thread_storage(thread_id)

        with self._storage_lock:
            if path not in storage:
                raise FileNotFoundError(f"File not found: {file_path}")

            file_data = storage[path]
            lines = file_data.get("content", [])
            content = "\n".join(lines)

            if old_string not in content:
                raise ValueError(f"String not found in file: {old_string}")

            # Count occurrences
            occurrences = content.count(old_string)

            # Replace all occurrences
            new_content = content.replace(old_string, new_string)
            new_lines = new_content.split("\n")

            # Update file
            file_data["content"] = new_lines
            file_data["modified_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")

            return EditResult(
                path=path,
                occurrences=occurrences,
                success=True,
            )

    def glob_info(self, pattern: str, path: str = "/", thread_id: str = "default") -> list[FileInfo]:
        """Find files matching a glob pattern.

        Args:
            pattern: Glob pattern to match (e.g., "**/*.py").
            path: Base directory to search from. Defaults to "/".
            thread_id: Thread identifier for isolation. Defaults to "default".

        Returns:
            List of FileInfo objects for matching files.
        """
        import fnmatch

        storage = self._get_thread_storage(thread_id)
        matches = []

        # Convert glob pattern to something we can match
        # Simple implementation: just check if filename matches
        with self._storage_lock:
            for file_path, file_data in storage.items():
                # Check if file matches pattern
                filename = file_path.split("/")[-1] if "/" in file_path else file_path
                if fnmatch.fnmatch(filename, pattern) or fnmatch.fnmatch(file_path, pattern):
                    content = file_data.get("content", [])
                    size = sum(len(line.encode("utf-8")) for line in content)
                    matches.append(FileInfo(path=file_path, type="file", size=size))

        return matches
