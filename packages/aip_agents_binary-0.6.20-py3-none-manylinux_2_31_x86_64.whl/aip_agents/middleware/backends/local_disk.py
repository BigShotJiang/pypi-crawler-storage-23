"""Local disk filesystem backend implementation.

This module provides LocalDiskBackend, a BackendProtocol implementation
that stores files on the actual filesystem using pathlib.

TODO: When migrating to deepagents:
  1. Import BackendProtocol and types from deepagents.backends.protocol
  2. Keep LocalDiskBackend as wrapper around FilesystemBackend (adapter pattern)

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from aip_agents.middleware.backends.protocol import (
    BackendProtocol,
    EditResult,
    FileInfo,
    GrepMatch,
    WriteResult,
)
from aip_agents.middleware.backends.utils import format_content_with_line_numbers

__all__ = ["LocalDiskBackend"]

# macOS path aliases for /var directory
_MACOS_PRIVATE_VAR = "/private/var/"
_MACOS_VAR = "/var/"


class LocalDiskBackend(BackendProtocol):
    """Local disk filesystem backend.

    Implements BackendProtocol using actual filesystem storage via pathlib.
    Files persist across sessions and are stored on disk.

    Security:
        All paths are validated to prevent directory traversal attacks.
        Operations are restricted to the base_directory.

    Attributes:
        base_path: Root directory for all file operations.

    Example:
        >>> backend = LocalDiskBackend(base_directory="/tmp/agent_files")
        >>> backend.write("/test.txt", "Hello World")
        >>> content = backend.read("/test.txt")
    """

    def __init__(self, base_directory: str | Path | None = None) -> None:
        """Initialize local disk backend.

        Args:
            base_directory: Root directory for file storage. Created if
                it doesn't exist. If None, use system temp directory.
        """
        if base_directory is None:
            temp_dir = tempfile.mkdtemp(prefix="agent_files_")
            base_path = Path(temp_dir)
        else:
            base_path = Path(base_directory)

        base_path = base_path.resolve()
        self._ensure_safe_directory(base_path)
        self.base_path = base_path

    def _ensure_safe_directory(self, path: Path) -> None:
        """Ensure the directory exists with safe permissions and ownership.

        Args:
            path: The directory path to verify/create.

        Raises:
            PermissionError: If the directory is owned by another user.
        """
        path.mkdir(parents=True, exist_ok=True, mode=0o700)

        if os.name != "nt":
            stat_info = path.stat()
            if stat_info.st_uid != os.getuid():
                raise PermissionError(
                    f"Security risk: Directory '{path}' is owned by another user (uid {stat_info.st_uid}). "
                    "In a shared publicly writable directory like /tmp, this could lead to symlink attacks. "
                    "Please use a private directory or delete the existing one."
                )

            if stat_info.st_mode & 0o077:
                path.chmod(0o700)

    def _rel_posix(self, p: Path) -> str:
        """Convert path to relative POSIX-style path string.

        Args:
            p: Path to convert.

        Returns:
            Relative path with forward slashes.
        """
        base_candidates = self._canonical_path_candidates(self.base_path)
        target_candidates = self._canonical_path_candidates(p)

        for candidate_target in target_candidates:
            for candidate_base in base_candidates:
                try:
                    return candidate_target.relative_to(candidate_base).as_posix()
                except ValueError:
                    continue

        target_real = target_candidates[-1]
        base_real = base_candidates[-1]
        try:
            rel = os.path.relpath(str(target_real), str(base_real))
        except ValueError as e:
            raise ValueError(f"Path '{target_real}' is not within base directory '{base_real}'") from e

        rel_posix = rel.replace("\\", "/")
        if rel_posix == ".." or rel_posix.startswith("../") or os.path.isabs(rel):
            raise ValueError(f"Path '{target_real}' is not within base directory '{base_real}'")

        return rel_posix

    @staticmethod
    def _macos_var_alias(path: Path) -> Path | None:
        """Return alternate /var <-> /private/var alias when applicable."""
        posix_path = path.as_posix()
        if posix_path.startswith(_MACOS_PRIVATE_VAR):
            return Path(posix_path.replace(_MACOS_PRIVATE_VAR, _MACOS_VAR, 1))
        if posix_path.startswith(_MACOS_VAR):
            return Path(posix_path.replace(_MACOS_VAR, _MACOS_PRIVATE_VAR, 1))
        return None

    def _canonical_path_candidates(self, path: Path) -> list[Path]:
        """Build canonical path variants for robust cross-platform comparisons."""
        resolved = path.resolve(strict=False)
        candidates = [resolved]

        realpath_candidate = Path(os.path.realpath(resolved.as_posix()))
        if realpath_candidate not in candidates:
            candidates.append(realpath_candidate)

        index = 0
        while index < len(candidates):
            alias_candidate = self._macos_var_alias(candidates[index])
            if alias_candidate is not None and alias_candidate not in candidates:
                candidates.append(alias_candidate)
            index += 1

        return candidates

    def _resolve_path(self, path: str) -> Path:
        """Resolve a path relative to base_path securely.

        Args:
            path: Path to resolve (absolute or relative).

        Returns:
            Resolved Path object.

        Raises:
            ValueError: If path attempts directory traversal outside base_path.
        """
        # Remove leading slash if present for relative resolution
        rel_path = path.lstrip("/")
        target = (self.base_path / rel_path).resolve()

        # Security check: ensure resolved path is within base_path, accounting for
        # platform aliases (Windows short/long names, macOS /var vs /private/var).
        target_resolved = target.resolve(strict=False)
        base_candidates = self._canonical_path_candidates(self.base_path)
        target_candidates = self._canonical_path_candidates(target_resolved)

        for candidate_target in target_candidates:
            for candidate_base in base_candidates:
                try:
                    candidate_target.relative_to(candidate_base)
                    return target_resolved
                except ValueError:
                    continue

        raise ValueError(f"Path '{path}' attempts to escape base directory")

    def ls_info(self, path: str) -> list[FileInfo]:
        """List files in a directory.

        Args:
            path: Directory path to list (absolute, relative to base).

        Returns:
            List of FileInfo objects.

        Raises:
            FileNotFoundError: If path does not exist.
            NotADirectoryError: If path is not a directory.
        """
        target = self._resolve_path(path)

        if not target.exists():
            raise FileNotFoundError(f"Directory not found: {path}")

        if not target.is_dir():
            raise NotADirectoryError(f"Path is not a directory: {path}")

        result = []
        for item in target.iterdir():
            if item.is_file():
                stat = item.stat()
                result.append(
                    FileInfo(
                        path=self._rel_posix(item),
                        type="file",
                        size=stat.st_size,
                    )
                )
            elif item.is_dir():
                result.append(
                    FileInfo(
                        path=self._rel_posix(item),
                        type="directory",
                        size=None,
                    )
                )

        return result

    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        """Read a file's contents with line numbers.

        Args:
            file_path: Path to the file (absolute, relative to base).
            offset: Line number to start from (0-indexed). Defaults to 0.
            limit: Maximum number of lines to read. Defaults to 2000.

        Returns:
            File content formatted with line numbers.

        Raises:
            FileNotFoundError: If file does not exist.
            IsADirectoryError: If path is a directory.
        """
        target = self._resolve_path(file_path)

        if not target.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if target.is_dir():
            raise IsADirectoryError(f"Cannot read directory: {file_path}")

        content = target.read_text(encoding="utf-8")
        lines = content.split("\n")

        start = max(0, offset)
        end = min(len(lines), start + limit)
        selected_lines = lines[start:end]

        selected_content = "\n".join(selected_lines)
        if not selected_content:
            return ""
        return format_content_with_line_numbers(selected_content, offset=start)

    def write(self, file_path: str, content: str) -> WriteResult:
        """Write content to a file.

        Args:
            file_path: Path where to write (absolute, relative to base).
            content: Content to write.

        Returns:
            WriteResult indicating success.
        """
        target = self._resolve_path(file_path)

        # Ensure parent directory exists
        target.parent.mkdir(parents=True, exist_ok=True)

        # Write content
        target.write_text(content, encoding="utf-8")

        return WriteResult(path=file_path, success=True)

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
    ) -> EditResult:
        """Edit a file by replacing old_string with new_string.

        Args:
            file_path: Path to the file (absolute, relative to base).
            old_string: String to find and replace.
            new_string: String to replace with.

        Returns:
            EditResult with number of replacements.

        Raises:
            FileNotFoundError: If file does not exist.
            ValueError: If old_string not found in file.
        """
        target = self._resolve_path(file_path)

        if not target.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        content = target.read_text(encoding="utf-8")

        if old_string not in content:
            raise ValueError(f"String not found in file: {old_string}")

        # Count and replace
        occurrences = content.count(old_string)
        new_content = content.replace(old_string, new_string)

        # Write back
        target.write_text(new_content, encoding="utf-8")

        return EditResult(
            path=file_path,
            occurrences=occurrences,
            success=True,
        )

    def glob_info(self, pattern: str, path: str = "/") -> list[FileInfo]:
        """Find files matching a glob pattern.

        Args:
            pattern: Glob pattern (e.g., "**/*.py", "*.txt").
            path: Base directory to search from. Defaults to "/".

        Returns:
            List of FileInfo objects for matching files.
        """
        base = self._resolve_path(path)
        result = []

        # Use rglob for recursive patterns
        if "**" in pattern:
            files = base.rglob(pattern.replace("**/", "").replace("**", ""))
        else:
            files = base.glob(pattern)

        for item in files:
            if item.is_file():
                stat = item.stat()
                result.append(
                    FileInfo(
                        path=self._rel_posix(item),
                        type="file",
                        size=stat.st_size,
                    )
                )

        return result

    def grep(
        self,
        pattern: str,
        path: str | None = None,
    ) -> list[GrepMatch]:
        """Search for text pattern across files.

        Uses ripgrep (rg) if available for fast searching, falling back to
        Python regex search. Requires ripgrep to be installed in the
        environment (e.g., via Docker).

        Args:
            pattern: Text pattern to search (literal string, not regex).
            path: Directory to search in. Defaults to None (search all).

        Returns:
            List of GrepMatch objects.

        Raises:
            FileNotFoundError: If path is specified but does not exist.
        """
        base = self._resolve_path(path) if path else self.base_path

        if not base.exists():
            raise FileNotFoundError(f"Path not found: {path}")

        # Try ripgrep first for performance
        results = self._ripgrep_search(pattern, base)
        if results is not None:
            return results

        # Fallback to Python implementation
        return self._python_search(pattern, base)

    def _ripgrep_search(self, pattern: str, base: Path) -> list[GrepMatch] | None:
        """Search using ripgrep with fixed-string (literal) mode.

        Args:
            pattern: Literal string to search for.
            base: Resolved base path to search in.

        Returns:
            List of GrepMatch objects, or None if ripgrep is unavailable.
        """
        cmd = ["rg", "--json", "-F", "--", pattern, str(base)]

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return None

        matches: list[GrepMatch] = []
        for line in proc.stdout.splitlines():
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            if data.get("type") != "match":
                continue
            pdata = data.get("data", {})
            ftext = pdata.get("path", {}).get("text")
            if not ftext:
                continue
            p = Path(ftext)
            rel_path = self._rel_posix(p)
            ln = pdata.get("line_number")
            lt = pdata.get("lines", {}).get("text", "").rstrip("\n")
            if ln is None:
                continue
            matches.append(
                GrepMatch(
                    path=rel_path,
                    line_number=int(ln),
                    content=lt,
                )
            )

        return matches

    def _python_search(self, pattern: str, base: Path) -> list[GrepMatch]:
        """Fallback search using Python when ripgrep is unavailable.

        Args:
            pattern: Text pattern to search for.
            base: Resolved base path to search in.

        Returns:
            List of GrepMatch objects.
        """
        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error:
            regex = re.compile(re.escape(pattern), re.IGNORECASE)

        matches: list[GrepMatch] = []

        if base.is_file():
            files = [base]
        else:
            files = [f for f in base.rglob("*") if f.is_file()]

        for file_path in files:
            try:
                content = file_path.read_text(encoding="utf-8")
                lines = content.split("\n")

                for line_num, line in enumerate(lines, start=1):
                    if regex.search(line):
                        rel_path = self._rel_posix(file_path)
                        matches.append(
                            GrepMatch(
                                path=rel_path,
                                line_number=line_num,
                                content=line,
                            )
                        )
            except (UnicodeDecodeError, PermissionError):
                continue

        return matches

    # Alias grep_raw to grep for protocol compatibility
    grep_raw = grep

    # State sync helpers (required by BackendProtocol)
    def set_files(self, files: dict[str, Any], thread_id: str = "default") -> None:
        """Load files from state (no-op for disk backend).

        Files are already persisted on disk, so this is a no-op.
        The thread_id parameter is accepted for protocol compatibility
        but ignored since disk storage is not thread-isolated.

        Args:
            files: Dictionary mapping file paths to file data (ignored).
            thread_id: Thread identifier (ignored for disk backend).
        """
        # Disk backend persists files automatically, no state sync needed
        pass

    def get_files(self, thread_id: str = "default") -> dict[str, Any]:
        """Get files for a specific thread (no-op for disk backend).

        Returns empty dict since disk backend doesn't track files in memory.
        The thread_id parameter is accepted for protocol compatibility
        but ignored.

        Args:
            thread_id: Thread identifier (ignored for disk backend).

        Returns:
            Empty dictionary.
        """
        # Disk backend doesn't track files in memory
        return {}
