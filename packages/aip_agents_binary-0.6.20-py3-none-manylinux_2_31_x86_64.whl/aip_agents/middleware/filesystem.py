"""Filesystem middleware for agent file operations.

Provides file storage and management capabilities for agents, enabling them
to read, write, edit, and search files within isolated thread-specific storage.

TODO: When migrating to deepagents:
  1. Import BackendProtocol from deepagents.backends.protocol
  2. Keep InMemoryBackend or use deepagents.backends.StateBackend
  3. Tools will import from deepagents middleware tools

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from abc import abstractmethod
from pathlib import Path
from typing import Any

from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool
from pydantic import BaseModel, ConfigDict, Field

from aip_agents.middleware.backends.in_memory import InMemoryBackend
from aip_agents.middleware.backends.local_disk import LocalDiskBackend
from aip_agents.middleware.backends.protocol import BackendProtocol
from aip_agents.middleware.backends.utils import sanitize_tool_call_id
from aip_agents.middleware.base import ModelRequest
from aip_agents.middleware.tools.grep_file import GrepTool
from aip_agents.middleware.tools.ls import LsTool
from aip_agents.middleware.tools.read_file import ReadFileTool
from aip_agents.middleware.tools.write_file import WriteFileTool

__all__ = [
    "FilesystemConfig",
    "InMemoryConfig",
    "LocalDiskConfig",
    "FilesystemMiddleware",
    "FILESYSTEM_SYSTEM_PROMPT",
]


class FilesystemConfig(BaseModel):
    """Abstract base class for filesystem backend configurations.

    Subclasses implement create_backend() to instantiate specific backends.
    This allows users to configure filesystem storage with custom settings.

    Example:
        >>> config = InMemoryConfig()
        >>> backend = config.create_backend()
        >>> middleware = FilesystemMiddleware(backend=backend)

        >>> config = LocalDiskConfig(base_directory="/tmp/agent_files")
        >>> backend = config.create_backend()
        >>> middleware = FilesystemMiddleware(backend=backend)
    """

    @abstractmethod
    def create_backend(self) -> BackendProtocol:
        """Create and return a backend instance based on this configuration.

        Returns:
            BackendProtocol: Configured backend instance ready for use.
        """
        ...


class InMemoryConfig(FilesystemConfig):
    """Configuration for in-memory filesystem backend.

    Stores all files in memory. Files are lost when the process exits.
    Best for temporary storage and testing scenarios.

    Example:
        >>> config = InMemoryConfig()
        >>> agent = LangGraphReactAgent(
        ...     name="test_agent",
        ...     instruction="Test",
        ...     filesystem=config
        ... )
    """

    def create_backend(self) -> BackendProtocol:
        """Create an in-memory backend.

        Returns:
            BackendProtocol: InMemoryBackend instance.
        """
        return InMemoryBackend()

    model_config = ConfigDict(frozen=True)


class LocalDiskConfig(FilesystemConfig):
    """Configuration for local disk filesystem backend.

    Stores files on the local filesystem at the specified base path.
    Files persist between process restarts.
    Best for production use cases requiring file persistence.


    Args:
        base_directory: Root directory for file storage.

    Example:
        >>> import tempfile
        >>> with tempfile.TemporaryDirectory() as tmpdir:
        ...     config = LocalDiskConfig(base_directory=tmpdir)
        ...     agent = LangGraphReactAgent(
        ...         name="file_agent",
        ...         instruction="Process files",
        ...         filesystem=config
        ...     )
    """

    base_directory: str | Path = Field(
        ...,
        description="Root directory for file storage.",
    )

    def create_backend(self) -> BackendProtocol:
        """Create a local disk backend.

        Returns:
            BackendProtocol: LocalDiskBackend instance configured with base_path.
        """
        return LocalDiskBackend(base_directory=Path(self.base_directory))

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)


NUM_CHARS_PER_TOKEN = 4
TOOL_TOKEN_LIMIT_BEFORE_EVICT = 20000
PREVIEW_HEAD_SIZE = 500
PREVIEW_TAIL_SIZE = 500
AUTO_SAVE_DIR = "/tool_outputs"

TOOLS_EXCLUDED_FROM_EVICTION = (
    "ls",
    "grep",
    "read_file",
    "edit_file",
    "write_file",
)


FILESYSTEM_SYSTEM_PROMPT = """## Filesystem Tools `read_file`, `grep`, `ls`, `write_file`

You have access to a filesystem which you can interact with using these tools.
All file paths must start with a /.

- read_file: read a file from the filesystem
- grep: search for text within files
- ls: list files in a directory (requires absolute path)
- write_file: write to a file in the filesystem

## Auto-Save

Large tool outputs may be automatically saved to files. You will receive:
- The file path where content was saved
- A preview (head + tail) of the content
- Instructions to use read_file with offset/limit for full access"""


class FilesystemMiddleware:
    """Middleware providing filesystem capabilities for agents.

    Manages file storage and retrieval for agents using a pluggable backend.
    Provides hooks for lifecycle management and system prompt enhancement
    with file context information.

    Thread Safety:
        Uses the underlying backend's thread safety mechanisms.
        Each thread_id has isolated storage.

    Attributes:
        tools: List of file operation tools (empty in PR 001, populated in 002-004).
        system_prompt_additions: System prompt text explaining file access.
        backend: Storage backend for file operations.
    """

    def __init__(
        self,
        backend: BackendProtocol | None = None,
        tool_token_limit_before_evict: int | None = TOOL_TOKEN_LIMIT_BEFORE_EVICT,
    ) -> None:
        """Initialize filesystem tools and tool-output eviction policy.

        Args:
            backend (BackendProtocol | None): Filesystem backend implementation.
                If ``None``, ``InMemoryBackend`` is used.
            tool_token_limit_before_evict (int | None): Token threshold used to
                decide when tool output should be evicted to
                ``/tool_outputs/<tool_call_id>.txt``. The middleware uses
                ``NUM_CHARS_PER_TOKEN`` as an approximation.
                Set to ``None`` to disable eviction.

        Notes:
            Eviction is skipped for tools listed in
            ``TOOLS_EXCLUDED_FROM_EVICTION``.
        """
        self.backend = backend if backend is not None else InMemoryBackend()
        self.tools: list[BaseTool] = [
            ReadFileTool(backend=self.backend),
            GrepTool(backend=self.backend),
            LsTool(backend=self.backend),
            WriteFileTool(backend=self.backend),
        ]
        self.tool_token_limit_before_evict = tool_token_limit_before_evict
        self.system_prompt_additions: str | None = FILESYSTEM_SYSTEM_PROMPT

    def _is_tool_excluded_from_eviction(self, message: ToolMessage) -> bool:
        tool_name = None
        tool_calls = getattr(message, "tool_calls", None)
        if isinstance(tool_calls, dict):
            tool_name = tool_calls.get("name")

        if not tool_name:
            tool_name = getattr(message, "name", None)

        return isinstance(tool_name, str) and tool_name in TOOLS_EXCLUDED_FROM_EVICTION

    def _exceeds_eviction_limit(self, content: str) -> bool:
        if self.tool_token_limit_before_evict is None:
            return False
        return len(content) > NUM_CHARS_PER_TOKEN * self.tool_token_limit_before_evict

    def _save_output(self, path: str, content: str, thread_id: str) -> None:
        if isinstance(self.backend, InMemoryBackend):
            self.backend.write(path, content, thread_id=thread_id)
            return
        self.backend.write(path, content)

    def _format_auto_saved_preview(self, file_path: str, content: str) -> str:
        head = content[:PREVIEW_HEAD_SIZE]
        tail = content[-PREVIEW_TAIL_SIZE:] if len(content) > PREVIEW_TAIL_SIZE else content
        return (
            f"Output saved to: {file_path}\n"
            f"Preview (first {PREVIEW_HEAD_SIZE} chars): {head}...\n"
            f"Preview (last {PREVIEW_TAIL_SIZE} chars): ...{tail}\n"
            "Use read_file(path, offset, limit) to access specific sections."
        )

    def _replace_tool_message_content(self, message: ToolMessage, content: str) -> ToolMessage:
        return message.model_copy(update={"content": content})

    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed before model invocation.

        Loads files from state into the backend storage for the current thread.
        This restores the filesystem state from checkpointed data.

        Args:
            state: Current agent state containing messages and other context.
                Expected keys:
                - "files": Dictionary mapping file paths to file data (optional).
                - "configurable": Dict containing "thread_id" for isolation.

        Returns:
            Empty dict (no state updates needed from this hook).
        """
        thread_id = state.get("configurable", {}).get("thread_id", "default")

        if "files" in state and state["files"] is not None:
            self.backend.set_files(state["files"], thread_id=thread_id)

        return {}

    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed after model invocation.

        Saves files from backend storage back to state for checkpointing.
        This ensures file modifications persist across conversation turns.

        Args:
            state: Current agent state after model invocation.

        Returns:
            Dict with "files" key containing updated file data, or empty dict
            if no files exist for this thread.
        """
        thread_id = state.get("configurable", {}).get("thread_id", "default")

        messages = state.get("messages", [])
        updated_messages = []
        messages_changed = False

        for message in messages:
            if not isinstance(message, ToolMessage):
                updated_messages.append(message)
                continue

            content = message.content if isinstance(message.content, str) else str(message.content)
            if self._is_tool_excluded_from_eviction(message):
                updated_messages.append(message)
                continue

            if not self._exceeds_eviction_limit(content):
                updated_messages.append(message)
                continue

            raw_call_id = getattr(message, "tool_call_id", "") or "unknown"
            safe_call_id = sanitize_tool_call_id(str(raw_call_id))
            file_path = f"{AUTO_SAVE_DIR}/{safe_call_id}.txt"

            self._save_output(file_path, content, thread_id)
            preview_text = self._format_auto_saved_preview(file_path=file_path, content=content)
            updated_messages.append(self._replace_tool_message_content(message=message, content=preview_text))
            messages_changed = True

        updates: dict[str, Any] = {}
        if messages_changed:
            updates["messages"] = updated_messages

        files = self.backend.get_files(thread_id=thread_id)
        if files:
            updates["files"] = files

        return updates

    def modify_model_request(self, request: ModelRequest, _state: dict[str, Any]) -> ModelRequest:
        """Modify the model request before invocation."""
        return request

    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async version of before_model.

        Args:
            state: Current agent state containing messages and other context.

        Returns:
            Dict of state updates to merge into the agent state. Return empty dict
            if no updates are needed.
        """
        return self.before_model(state)

    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async version of after_model.

        Args:
            state: Current agent state after model invocation.

        Returns:
            Dict of state updates to merge into the agent state. Return empty dict
            if no updates are needed.
        """
        return self.after_model(state)
