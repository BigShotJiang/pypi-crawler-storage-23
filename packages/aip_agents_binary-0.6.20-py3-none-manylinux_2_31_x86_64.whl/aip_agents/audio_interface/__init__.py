"""Audio interface (beta, local-only).

This package separates:
- transport sessions (e.g. LiveKit provider implementations)
- text-turn adapter (`AIPAudioAgentAdapter`) shared by all transports
"""

from __future__ import annotations

from aip_agents.audio_interface.audio_agent_adapter import AIPAudioAgentAdapter
from aip_agents.audio_interface.config import AudioIOConfig, AudioModelConfig, AudioSessionConfig, LiveKitConfig
from aip_agents.audio_interface.errors import AudioConfigError, AudioInterfaceError, AudioSessionUnavailableError
from aip_agents.audio_interface.livekit_audio_session import LiveKitAudioSession
from aip_agents.audio_interface.livekit_realtime_audio_session import LiveKitRealtimeAudioSession
from aip_agents.audio_interface.session_factory import AudioSession, create_audio_session

__all__ = [
    "AIPAudioAgentAdapter",
    "AudioSession",
    "AudioConfigError",
    "AudioInterfaceError",
    "AudioIOConfig",
    "AudioModelConfig",
    "AudioSessionConfig",
    "AudioSessionUnavailableError",
    "LiveKitAudioSession",
    "LiveKitRealtimeAudioSession",
    "LiveKitConfig",
    "create_audio_session",
]
