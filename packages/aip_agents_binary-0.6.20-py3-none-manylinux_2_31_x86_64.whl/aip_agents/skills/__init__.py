"""Skills support for AIP Agents (PR-001 foundation).

Authors:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations

from aip_agents.skills.errors import SkillError, SkillInstallError, SkillMetadataError, SkillValidationError
from aip_agents.skills.installer import SkillInstaller
from aip_agents.skills.models import Skill

__all__ = [
    "SkillError",
    "SkillInstallError",
    "SkillMetadataError",
    "SkillValidationError",
    "Skill",
    "SkillInstaller",
]
