"""Skill-related error types.

These errors are intentionally small and human-readable since they are expected to
surface to SDK users (e.g., during skill installation).

Authors:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations


class SkillError(Exception):
    """Base error for skill operations."""


class SkillInstallError(SkillError):
    """Raised when a skill cannot be installed (network/auth/archive errors)."""


class SkillValidationError(SkillError):
    """Raised when a local skill path is invalid (naming, missing files, etc.)."""


class SkillMetadataError(SkillError):
    """Raised when SKILL.md metadata is invalid.

    PR-001 does not parse SKILL.md frontmatter, but later milestones will.
    """
