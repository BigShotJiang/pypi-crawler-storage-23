"""Skill staging utilities.

This module stages local skill directories into a filesystem backend so skills can be
discovered and read from backend storage (DeepAgents-compatible flow).

Author:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations

import posixpath
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path

from aip_agents.middleware.backends.protocol import BackendProtocol
from aip_agents.skills.errors import SkillValidationError
from aip_agents.skills.models import Skill

_DEFAULT_SKILLS_BACKEND_ROOT = "/skills"
_DEFAULT_SKILL_SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "__pycache__",
    ".venv",
    "node_modules",
}


def _iter_skill_files(skill_root: Path) -> Iterable[Path]:
    """Iterate all files under a local skill root, skipping common noise directories.

    Args:
        skill_root (Path): Local root directory of the skill.

    Yields:
        Path: File paths under the skill root.
    """
    for path in skill_root.rglob("*"):
        if path.is_dir():
            continue

        relative = path.relative_to(skill_root)

        if any(part in _DEFAULT_SKILL_SKIP_DIRS for part in relative.parts):
            continue

        yield path


def _is_utf8_text(data: bytes) -> bool:
    """Return True if data is valid UTF-8.

    Args:
        data (bytes): File content bytes.

    Returns:
        bool: True if UTF-8 decodable, False otherwise.
    """
    try:
        data.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def _ensure_posix_root(path: str) -> str:
    """Normalize a backend root path to a POSIX absolute root.

    Args:
        path (str): Input root path (e.g., "/skills", "skills/").

    Returns:
        str: Normalized root path (e.g., "/skills").
    """
    normalized = path.strip()
    if not normalized:
        return "/"
    if not normalized.startswith("/"):
        normalized = "/" + normalized
    return normalized.rstrip("/") or "/"


@dataclass(frozen=True, slots=True)
class StagedSkill:
    """Represents the result of staging a single skill.

    Attributes:
        name (str): Skill name.
        backend_root (str): Backend root directory for the staged skill.
        staged_files (tuple[str, ...]): Backend file paths written.
    """

    name: str
    backend_root: str
    staged_files: tuple[str, ...]


class SkillStager:
    """Stage local skills into a backend storage namespace."""

    def __init__(self, *, backend: BackendProtocol, destination_root: str = _DEFAULT_SKILLS_BACKEND_ROOT) -> None:
        """Initialize SkillStager.

        Args:
            backend (BackendProtocol): Backend used for writes.
            destination_root (str, optional): Backend root under which skills are staged. Defaults to "/skills".

        Returns:
            None: This initializer returns None.
        """
        self._backend = backend
        self._destination_root = _ensure_posix_root(destination_root)

    def stage(self, skills: Sequence[Skill]) -> list[StagedSkill]:
        """Stage a collection of skills into the backend.

        Args:
            skills (Sequence[Skill]): Skills to stage.

        Returns:
            list[StagedSkill]: Staging results for each skill.

        Raises:
            SkillValidationError: If a provided skill is missing required files.
        """
        results: list[StagedSkill] = []
        for skill in skills:
            results.append(self.stage_one(skill))
        return results

    def stage_one(self, skill: Skill) -> StagedSkill:
        """Stage a single skill into the backend.

        Files are written under:
            /skills/<skill-name>/<relative-path>

        Binary files are skipped in prompt-only milestones.

        Args:
            skill (Skill): Skill to stage.

        Returns:
            StagedSkill: Staging result.

        Raises:
            SkillValidationError: If SKILL.md is missing.
        """
        if not skill.skill_md_path.is_file():
            raise SkillValidationError(f"Missing required SKILL.md at: {skill.skill_md_path}.")

        staged_files: list[str] = []
        backend_root = posixpath.join(self._destination_root, skill.name)

        for local_path in _iter_skill_files(skill.local_root_path):
            rel = local_path.relative_to(skill.local_root_path).as_posix()
            backend_path = posixpath.join(backend_root, rel)

            data = local_path.read_bytes()
            if not _is_utf8_text(data):
                # Prompt-only milestone: skip non-text artifacts.
                continue

            content = data.decode("utf-8")
            self._backend.write(backend_path, content)
            staged_files.append(backend_path)

        return StagedSkill(name=skill.name, backend_root=backend_root, staged_files=tuple(staged_files))
