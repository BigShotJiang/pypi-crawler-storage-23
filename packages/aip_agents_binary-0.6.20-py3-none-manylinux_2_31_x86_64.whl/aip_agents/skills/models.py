"""Skill object model (PR-001).

In PR-001 we do *not* parse SKILL.md frontmatter or load SKILL.md bodies. We only:
- enforce basic naming rules (DeepAgents-compatible),
- ensure `SKILL.md` exists,
- provide stable local/backend roots that later PRs can stage/discover.

Authors:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations

import os
from pathlib import Path

from pydantic import BaseModel

try:
    # Pydantic v2 preferred config
    from pydantic import ConfigDict  # type: ignore
except ImportError:  # pragma: no cover
    ConfigDict = None  # type: ignore

from aip_agents.skills.installer import SkillInstaller
from aip_agents.skills.validation import validate_skill_root


class Skill(BaseModel):
    """Represents an installed skill.

    Attributes:
        name (str): Skill name (derived from folder name).
        description (str | None): Optional metadata. Defaults to None.
        version (str | None): Optional metadata. Defaults to None.
        tags (tuple[str, ...]): Optional metadata. Defaults to ().
        triggers (tuple[str, ...]): Optional metadata. Defaults to ().
        source (str | None): The install source, when applicable. Defaults to None.
        local_root_path (Path): Local filesystem path to the skill root.
        backend_root (str): Deterministic backend root path (`/skills/<name>`).
    """

    name: str
    local_root_path: Path
    source: str | None = None
    description: str | None = None
    version: str | None = None
    tags: tuple[str, ...] = ()
    triggers: tuple[str, ...] = ()

    if ConfigDict is not None:
        # Pydantic v2 style config
        model_config = ConfigDict(frozen=True)  # type: ignore[assignment]
    else:  # pragma: no cover

        class Config:  # type: ignore[no-redef]
            """Pydantic v1 fallback config for Skill."""

            allow_mutation = False

    @property
    def local_root(self) -> str:
        """Local filesystem root as a string path.

        Returns:
            str: Local skill root path.
        """
        return str(self.local_root_path)

    @property
    def backend_root(self) -> str:
        """Backend root path used for staging (`/skills/<skill-name>`).

        Returns:
            str: Backend root path.
        """
        return f"/skills/{self.name}"

    @property
    def skill_md_path(self) -> Path:
        """Return the path to the required SKILL.md file.

        Returns:
            Path: SKILL.md file path.
        """
        return self.local_root_path / "SKILL.md"

    @classmethod
    def from_path(cls, path: str | os.PathLike[str]) -> Skill:
        """Create a Skill object from an already-installed local directory.

        Args:
            path (str | os.PathLike[str]): Path to a skill directory.

        Returns:
            Skill: The validated skill object.

        Raises:
            SkillValidationError: If the path is not a valid skill.
        """
        skill_root = Path(path).expanduser()
        validate_skill_root(skill_root)
        return cls(name=skill_root.name, local_root_path=skill_root)

    @classmethod
    async def from_github(
        cls,
        *,
        source: str,
        destination_root: str | os.PathLike[str],
        token: str | None = None,
    ) -> Skill:
        """Install a skill from GitHub and return a Skill object.

        Args:
            source (str): GitHub tree URL pointing at a skill directory.
            destination_root (str | os.PathLike[str]): Installation destination root
                (e.g. `.agents/skills`).
            token (str | None, optional): GitHub token used for private repos. Defaults to None.

        Returns:
            Skill: The installed and validated skill.

        Raises:
            SkillInstallError: If installation fails.
            SkillValidationError: If the installed result is invalid.
        """
        installer = SkillInstaller(token=token)
        installed_root = await installer.install_github_tree(source=source, destination_root=destination_root)

        installed_skill = cls.from_path(installed_root)
        return cls(
            name=installed_skill.name,
            local_root_path=installed_skill.local_root_path,
            source=source,
        )
