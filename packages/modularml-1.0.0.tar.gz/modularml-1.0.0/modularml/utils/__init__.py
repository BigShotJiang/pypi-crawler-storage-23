from modularml.utils.io.inspection import inspect_packaged_code


__all__ = [
    "inspect_packaged_code",
]
