from __future__ import annotations

import importlib
import sys
import pytest


if sys.version_info < (3, 10):
    pytest.skip(
        "pollyweb-utils uses Python 3.10+ typing syntax (e.g., X | Y).",
        allow_module_level=True,
    )


def test_pw_aws_module_imports() -> None:
    import PW_AWS  # noqa: F401

    aws_module = importlib.import_module("AWS")
    assert hasattr(aws_module, "AWS")
