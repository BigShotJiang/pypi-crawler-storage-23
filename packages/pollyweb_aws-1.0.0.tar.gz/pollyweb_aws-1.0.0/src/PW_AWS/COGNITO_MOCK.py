from __future__ import annotations

from PW_UTILS.LOG import LOG


class COGNITO_MOCK:
    
    @classmethod
    def CreateUser(cls, username, password, clientAlias='COGNITO'): 
        pass