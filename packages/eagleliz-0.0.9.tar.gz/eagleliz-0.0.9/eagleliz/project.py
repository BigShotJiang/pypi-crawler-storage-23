name = 'eagleliz'
version = '0.0.9'
description = 'Add your description here'
requires_python = '>=3.12'
authors = [('Gabliz', 'gabliz.dev@gmail.com')]
