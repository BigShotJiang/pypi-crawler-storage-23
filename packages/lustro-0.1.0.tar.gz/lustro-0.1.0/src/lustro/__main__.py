from lustro.cli import main

raise SystemExit(main())
