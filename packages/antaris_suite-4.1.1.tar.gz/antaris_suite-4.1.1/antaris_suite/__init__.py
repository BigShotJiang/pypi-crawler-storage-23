"""
antaris-suite — Complete AI memory, routing, safety, and context management suite.

Quick start:
    pip install antaris-suite          # core
    pip install antaris-suite[mcp]     # + MCP server tools
    pip install antaris-suite[pro]     # + MCP + semantic search

Usage:
    from antaris_memory import MemoryCore
    from antaris_guard import PromptGuard
    from antaris_context import ContextManager
"""

__version__ = "4.1.1"
