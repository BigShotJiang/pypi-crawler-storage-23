# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Compute similarity metrics between embeddings."""

import numpy as np


def cosine_similarity(embedding1: np.ndarray, embedding2: np.ndarray) -> float:
  return float(
      np.dot(embedding1, embedding2)
      / (np.linalg.norm(embedding1) * np.linalg.norm(embedding2))
  )


def euclidian_distance(embedding1: np.ndarray, embedding2: np.ndarray) -> float:
  return float(
      np.sqrt(np.sum(np.power(np.subtract(embedding1, embedding2), 2)))
  )
