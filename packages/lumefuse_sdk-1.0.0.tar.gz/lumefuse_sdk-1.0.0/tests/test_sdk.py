"""
LumeFuse SDK Tests
"""

import pytest
import hashlib
import json
from lumefuse import LumeFuse, DataStream
from lumefuse.models import BitPacket, PacketStatus
from lumefuse.exceptions import LumeFuseError, AuthenticationError


class TestDataStream:
    """Test the DataStream class"""
    
    def test_stream_creation(self):
        """Test creating a new stream"""
        stream = DataStream("test_source", client=None)
        assert stream.source_id == "test_source"
        assert stream.packet_count == 0
        assert not stream.is_closed
    
    def test_write_dict(self):
        """Test writing dict data"""
        stream = DataStream("test_source", client=None)
        data = {"temperature": 72.5, "humidity": 45}
        
        packet = stream.write(data)
        
        assert packet.source_id == "test_source"
        assert packet.sequence_no == 0
        assert len(packet.payload_hash) == 64  # SHA-256 hex
        assert len(packet.recursive_dna) == 64
        assert packet.prev_packet_hash is None  # First packet
        assert packet.chain_valid is True
    
    def test_write_string(self):
        """Test writing string data"""
        stream = DataStream("test_source", client=None)
        data = "Hello, LumeFuse!"
        
        packet = stream.write(data)
        
        expected_hash = hashlib.sha256(data.encode()).hexdigest()
        assert packet.payload_hash == expected_hash
    
    def test_recursive_dna_linking(self):
        """Test that packets are linked via Recursive DNA"""
        stream = DataStream("test_source", client=None)
        
        packet1 = stream.write({"event": 1})
        packet2 = stream.write({"event": 2})
        packet3 = stream.write({"event": 3})
        
        # First packet: recursive_dna == payload_hash
        assert packet1.recursive_dna == packet1.payload_hash
        
        # Second packet links to first
        assert packet2.prev_packet_hash == packet1.recursive_dna
        expected_dna2 = hashlib.sha256(
            (packet2.payload_hash + packet1.recursive_dna).encode()
        ).hexdigest()
        assert packet2.recursive_dna == expected_dna2
        
        # Third packet links to second
        assert packet3.prev_packet_hash == packet2.recursive_dna
    
    def test_close_returns_result(self):
        """Test closing stream returns StreamResult"""
        stream = DataStream("test_source", client=None)
        
        stream.write({"event": 1})
        stream.write({"event": 2})
        
        result = stream.close()
        
        assert result.source_id == "test_source"
        assert result.total_packets == 2
        assert len(result.merkle_root) == 64
        assert len(result.packets) == 2
        assert result.quantum_resistant is True
    
    def test_cannot_write_after_close(self):
        """Test that writing to closed stream raises error"""
        stream = DataStream("test_source", client=None)
        stream.write({"event": 1})
        stream.close()
        
        with pytest.raises(LumeFuseError):
            stream.write({"event": 2})
    
    def test_context_manager(self):
        """Test stream as context manager"""
        with DataStream("test_source", client=None) as stream:
            stream.write({"event": 1})
            assert not stream.is_closed
        
        assert stream.is_closed
    
    def test_merkle_root_single_packet(self):
        """Test Merkle root with single packet"""
        stream = DataStream("test_source", client=None)
        packet = stream.write({"event": 1})
        result = stream.close()
        
        # With single packet, merkle root == recursive_dna
        assert result.merkle_root == packet.recursive_dna
    
    def test_merkle_root_multiple_packets(self):
        """Test Merkle root with multiple packets"""
        stream = DataStream("test_source", client=None)
        stream.write({"event": 1})
        stream.write({"event": 2})
        stream.write({"event": 3})
        stream.write({"event": 4})
        
        result = stream.close()
        
        # Merkle root should be computed from all packet hashes
        assert len(result.merkle_root) == 64
        assert result.merkle_root != result.packets[-1].recursive_dna


class TestBitPacketModel:
    """Test BitPacket model"""
    
    def test_to_dict(self):
        """Test converting packet to dict"""
        packet = BitPacket(
            source_id="test",
            sequence_no=0,
            payload_hash="abc123",
            recursive_dna="def456",
            prev_packet_hash=None,
            timestamp="2026-02-20T00:00:00Z",
            status=PacketStatus.ANCHORED
        )
        
        d = packet.to_dict()
        
        assert d["source_id"] == "test"
        assert d["sequence_no"] == 0
        assert d["status"] == "anchored"
    
    def test_from_dict(self):
        """Test creating packet from dict"""
        data = {
            "source_id": "test",
            "sequence_no": 5,
            "payload_hash": "abc",
            "recursive_dna": "def",
            "prev_packet_hash": "xyz",
            "timestamp": "2026-02-20",
            "status": "verified"
        }
        
        packet = BitPacket.from_dict(data)
        
        assert packet.source_id == "test"
        assert packet.sequence_no == 5
        assert packet.status == PacketStatus.VERIFIED


class TestAuthenticationError:
    """Test authentication error handling"""
    
    def test_missing_api_key(self):
        """Test error when API key is missing"""
        with pytest.raises(AuthenticationError):
            LumeFuse(api_key=None)
    
    def test_invalid_api_key_format(self):
        """Test error when API key has wrong format"""
        with pytest.raises(AuthenticationError):
            LumeFuse(api_key="invalid_key_format")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
