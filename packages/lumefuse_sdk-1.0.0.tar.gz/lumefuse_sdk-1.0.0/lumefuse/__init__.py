"""
LumeFuse SDK - Atomic Veracity Protocol
The "Born-Signed" SDK for embedding structural DNA into your data.

Usage:
    from lumefuse import LumeFuse
    
    lf = LumeFuse(api_key="lf_your_api_key")
    
    # Open a data stream (The "Latch")
    stream = lf.open_stream("medical_lab_results")
    
    # Every data point is automatically:
    # 1. Hashed (SHA-256)
    # 2. Linked to previous packet (Recursive DNA)
    # 3. Anchored to BSV ledger
    
    stream.write({"patient_id": "P-001", "glucose": 95})
    stream.write({"patient_id": "P-001", "glucose": 102})
    
    # Close stream and get the Merkle root
    result = stream.close()
    print(f"Chain Root: {result.merkle_root}")
"""

from .client import LumeFuse
from .stream import DataStream, StreamResult
from .models import BitPacket, VerificationResult, ChainStatus
from .exceptions import (
    LumeFuseError,
    AuthenticationError,
    RateLimitError,
    ChainIntegrityError,
    InsufficientCreditsError
)

__version__ = "1.0.0"
__all__ = [
    "LumeFuse",
    "DataStream",
    "StreamResult",
    "BitPacket",
    "VerificationResult",
    "ChainStatus",
    "LumeFuseError",
    "AuthenticationError",
    "RateLimitError",
    "ChainIntegrityError",
    "InsufficientCreditsError",
]
