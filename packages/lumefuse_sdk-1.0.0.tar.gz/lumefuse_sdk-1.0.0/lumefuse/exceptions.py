"""
LumeFuse SDK Exceptions
"""


class LumeFuseError(Exception):
    """Base exception for all LumeFuse errors"""
    
    def __init__(self, message: str, code: str = None, details: dict = None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)


class AuthenticationError(LumeFuseError):
    """Raised when API key is invalid or missing"""
    
    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, code="AUTH_ERROR")


class RateLimitError(LumeFuseError):
    """Raised when rate limit is exceeded"""
    
    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None):
        super().__init__(message, code="RATE_LIMIT")
        self.retry_after = retry_after


class ChainIntegrityError(LumeFuseError):
    """Raised when DNA chain integrity is compromised"""
    
    def __init__(
        self, 
        message: str = "Chain integrity compromised",
        break_sequence: int = None,
        break_timestamp: str = None
    ):
        super().__init__(message, code="CHAIN_BREAK")
        self.break_sequence = break_sequence
        self.break_timestamp = break_timestamp


class InsufficientCreditsError(LumeFuseError):
    """Raised when user doesn't have enough BSV credits"""
    
    def __init__(self, message: str = "Insufficient BSV credits", required: int = None, available: int = None):
        super().__init__(message, code="INSUFFICIENT_CREDITS")
        self.required = required
        self.available = available


class NetworkError(LumeFuseError):
    """Raised when network request fails"""
    
    def __init__(self, message: str = "Network request failed", status_code: int = None):
        super().__init__(message, code="NETWORK_ERROR")
        self.status_code = status_code


class ValidationError(LumeFuseError):
    """Raised when input validation fails"""
    
    def __init__(self, message: str = "Validation failed", field: str = None):
        super().__init__(message, code="VALIDATION_ERROR")
        self.field = field
