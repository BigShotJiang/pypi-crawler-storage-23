"""
LumeFuse SDK Data Models
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


class PacketStatus(str, Enum):
    """Status of a Bit-Packet"""
    PENDING = "pending"
    ANCHORED = "anchored"
    VERIFIED = "verified"
    CORRUPTED = "corrupted"
    HEALED = "healed"


class ChainHealth(str, Enum):
    """Health status of a data chain"""
    HEALTHY = "healthy"
    INFECTED = "infected"
    QUARANTINED = "quarantined"
    HEALING = "healing"
    HEALED = "healed"
    TERMINAL = "terminal"


@dataclass
class BitPacket:
    """
    A single Bit-Packet - the atomic unit of verified data.
    
    Each packet contains:
    - payload_hash: SHA-256 hash of the data
    - recursive_dna: Hash linking this packet to the previous one
    - tx_id: BSV transaction ID anchoring this packet
    """
    source_id: str
    sequence_no: int
    payload_hash: str
    recursive_dna: str
    prev_packet_hash: Optional[str]
    timestamp: str
    tx_id: Optional[str] = None
    status: PacketStatus = PacketStatus.PENDING
    chain_valid: bool = True
    original_data_preview: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_id": self.source_id,
            "sequence_no": self.sequence_no,
            "payload_hash": self.payload_hash,
            "recursive_dna": self.recursive_dna,
            "prev_packet_hash": self.prev_packet_hash,
            "timestamp": self.timestamp,
            "tx_id": self.tx_id,
            "status": self.status.value if isinstance(self.status, PacketStatus) else self.status,
            "chain_valid": self.chain_valid,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BitPacket":
        return cls(
            source_id=data.get("source_id", ""),
            sequence_no=data.get("sequence_no", 0),
            payload_hash=data.get("payload_hash", ""),
            recursive_dna=data.get("recursive_dna", ""),
            prev_packet_hash=data.get("prev_packet_hash"),
            timestamp=data.get("timestamp", ""),
            tx_id=data.get("tx_id"),
            status=PacketStatus(data.get("status", "pending")),
            chain_valid=data.get("chain_valid", True),
            original_data_preview=data.get("original_data_preview"),
        )


@dataclass
class VerificationResult:
    """
    Result of verifying data against the BSV ledger.
    """
    verified: bool
    source_id: str
    data_hash: str
    expected_hash: Optional[str] = None
    tx_id: Optional[str] = None
    timestamp: Optional[str] = None
    message: str = ""
    quantum_resistant: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "verified": self.verified,
            "source_id": self.source_id,
            "data_hash": self.data_hash,
            "expected_hash": self.expected_hash,
            "tx_id": self.tx_id,
            "timestamp": self.timestamp,
            "message": self.message,
            "quantum_resistant": self.quantum_resistant,
        }


@dataclass
class ChainStatus:
    """
    Status of an entire data chain (all packets for a source).
    """
    source_id: str
    chain_intact: bool
    total_packets: int
    verified_packets: int = 0
    break_sequence: Optional[int] = None
    break_timestamp: Optional[str] = None
    health: ChainHealth = ChainHealth.HEALTHY
    quantum_resistant: bool = True
    healed: bool = False
    forensic_message: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_id": self.source_id,
            "chain_intact": self.chain_intact,
            "total_packets": self.total_packets,
            "verified_packets": self.verified_packets,
            "break_sequence": self.break_sequence,
            "break_timestamp": self.break_timestamp,
            "health": self.health.value if isinstance(self.health, ChainHealth) else self.health,
            "quantum_resistant": self.quantum_resistant,
            "healed": self.healed,
            "forensic_message": self.forensic_message,
        }


@dataclass
class CreditBalance:
    """User's BSV credit balance"""
    satoshi_balance: int
    packets_available: int
    total_deposited: int = 0
    total_spent: int = 0
    
    @property
    def usd_value(self) -> float:
        """Approximate USD value (assuming $50/BSV)"""
        return (self.satoshi_balance / 100_000_000) * 50


@dataclass
class HealingEvent:
    """Record of a data healing operation"""
    id: str
    source_id: str
    break_sequence: int
    original_hash: str
    corrupted_hash: str
    recovery_source: str
    healed_at: str
    success: bool
    receipt_hash: Optional[str] = None
    message: str = ""
