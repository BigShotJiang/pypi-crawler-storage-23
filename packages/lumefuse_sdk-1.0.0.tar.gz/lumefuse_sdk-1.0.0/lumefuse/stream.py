"""
LumeFuse DataStream - The "Latch" for Born-Signed Data
"""

import hashlib
import json
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .models import BitPacket, PacketStatus
from .exceptions import LumeFuseError, ValidationError


@dataclass
class StreamResult:
    """
    Result returned when closing a data stream.
    
    Contains the Merkle root and summary of all packets created.
    """
    source_id: str
    total_packets: int
    merkle_root: str
    anchor_txid: Optional[str]
    packets: List[BitPacket]
    created_at: str
    quantum_resistant: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_id": self.source_id,
            "total_packets": self.total_packets,
            "merkle_root": self.merkle_root,
            "anchor_txid": self.anchor_txid,
            "packets": [p.to_dict() for p in self.packets],
            "created_at": self.created_at,
            "quantum_resistant": self.quantum_resistant,
        }


class DataStream:
    """
    A data stream for creating Bit-Packets with Recursive DNA Binding.
    
    This is the core "Latch" - data written to this stream is automatically:
    1. Hashed (SHA-256)
    2. Linked to previous packet (Recursive DNA)
    3. Queued for BSV anchoring
    
    Usage:
        stream = lf.open_stream("sensor_data")
        stream.write({"temperature": 72.5, "humidity": 45})
        stream.write({"temperature": 73.1, "humidity": 44})
        result = stream.close()
    """
    
    def __init__(
        self, 
        source_id: str, 
        client: Any,  # LumeFuse client instance
        auto_anchor: bool = True,
        batch_size: int = 100
    ):
        """
        Initialize a new data stream.
        
        Args:
            source_id: Unique identifier for this data source
            client: LumeFuse client instance for API calls
            auto_anchor: Whether to automatically anchor packets to BSV
            batch_size: Number of packets to batch before anchoring
        """
        self.source_id = source_id
        self._client = client
        self._auto_anchor = auto_anchor
        self._batch_size = batch_size
        self._packets: List[BitPacket] = []
        self._prev_recursive_dna: Optional[str] = None
        self._sequence_no: int = 0
        self._closed: bool = False
        self._created_at = datetime.now(timezone.utc).isoformat()
    
    def _compute_hash(self, data: Union[str, bytes, Dict]) -> str:
        """Compute SHA-256 hash of data"""
        if isinstance(data, dict):
            data = json.dumps(data, sort_keys=True, default=str)
        if isinstance(data, str):
            data = data.encode('utf-8')
        return hashlib.sha256(data).hexdigest()
    
    def _compute_recursive_dna(self, payload_hash: str) -> str:
        """
        Compute Recursive DNA - the Cryptographic Heartbeat.
        
        Formula: recursive_dna[N] = SHA256(payload_hash[N] + recursive_dna[N-1])
        """
        if self._prev_recursive_dna is None:
            # First packet - DNA is just the payload hash
            return payload_hash
        
        combined = payload_hash + self._prev_recursive_dna
        return hashlib.sha256(combined.encode()).hexdigest()
    
    def write(self, data: Union[str, bytes, Dict, Any]) -> BitPacket:
        """
        Write data to the stream, creating a Bit-Packet with Recursive DNA.
        
        Args:
            data: The data to wrap (string, bytes, dict, or any JSON-serializable object)
        
        Returns:
            BitPacket: The created Bit-Packet with DNA binding
        
        Raises:
            LumeFuseError: If stream is closed
            ValidationError: If data is invalid
        """
        if self._closed:
            raise LumeFuseError("Cannot write to closed stream")
        
        # Handle different data types
        if hasattr(data, 'to_dict'):
            data = data.to_dict()
        elif hasattr(data, '__dict__'):
            data = data.__dict__
        
        # Compute payload hash
        payload_hash = self._compute_hash(data)
        
        # Compute Recursive DNA (the Cryptographic Heartbeat)
        recursive_dna = self._compute_recursive_dna(payload_hash)
        
        # Create packet
        timestamp = datetime.now(timezone.utc).isoformat()
        
        # Generate preview
        if isinstance(data, dict):
            preview = json.dumps(data, default=str)[:100]
        elif isinstance(data, bytes):
            preview = f"<binary data: {len(data)} bytes>"
        else:
            preview = str(data)[:100]
        
        packet = BitPacket(
            source_id=self.source_id,
            sequence_no=self._sequence_no,
            payload_hash=payload_hash,
            recursive_dna=recursive_dna,
            prev_packet_hash=self._prev_recursive_dna,
            timestamp=timestamp,
            status=PacketStatus.PENDING,
            chain_valid=True,
            original_data_preview=preview
        )
        
        self._packets.append(packet)
        self._prev_recursive_dna = recursive_dna
        self._sequence_no += 1
        
        # Auto-anchor if batch size reached
        if self._auto_anchor and len(self._packets) >= self._batch_size:
            self._anchor_batch()
        
        return packet
    
    def write_many(self, data_list: List[Any]) -> List[BitPacket]:
        """
        Write multiple data items to the stream.
        
        Args:
            data_list: List of data items to wrap
        
        Returns:
            List of created BitPackets
        """
        return [self.write(data) for data in data_list]
    
    def _anchor_batch(self) -> None:
        """Anchor pending packets to BSV (internal method)"""
        if not self._client:
            return
        
        pending = [p for p in self._packets if p.status == PacketStatus.PENDING]
        if not pending:
            return
        
        # In production, this would call the API to anchor packets
        # For now, we mark them as anchored locally
        for packet in pending:
            packet.status = PacketStatus.ANCHORED
    
    def _compute_merkle_root(self) -> str:
        """Compute Merkle root of all packet hashes"""
        if not self._packets:
            return hashlib.sha256(b"").hexdigest()
        
        hashes = [p.recursive_dna for p in self._packets]
        
        while len(hashes) > 1:
            if len(hashes) % 2 == 1:
                hashes.append(hashes[-1])  # Duplicate last hash if odd
            
            new_hashes = []
            for i in range(0, len(hashes), 2):
                combined = hashes[i] + hashes[i + 1]
                new_hash = hashlib.sha256(combined.encode()).hexdigest()
                new_hashes.append(new_hash)
            hashes = new_hashes
        
        return hashes[0]
    
    def close(self) -> StreamResult:
        """
        Close the stream and finalize all packets.
        
        Returns:
            StreamResult containing summary and Merkle root
        
        Raises:
            LumeFuseError: If stream is already closed
        """
        if self._closed:
            raise LumeFuseError("Stream already closed")
        
        self._closed = True
        
        # Anchor any remaining pending packets
        self._anchor_batch()
        
        # Compute Merkle root
        merkle_root = self._compute_merkle_root()
        
        # Get the last transaction ID if available
        anchor_txid = None
        for packet in reversed(self._packets):
            if packet.tx_id:
                anchor_txid = packet.tx_id
                break
        
        return StreamResult(
            source_id=self.source_id,
            total_packets=len(self._packets),
            merkle_root=merkle_root,
            anchor_txid=anchor_txid,
            packets=self._packets.copy(),
            created_at=self._created_at,
            quantum_resistant=True
        )
    
    @property
    def packet_count(self) -> int:
        """Number of packets written to this stream"""
        return len(self._packets)
    
    @property
    def is_closed(self) -> bool:
        """Whether the stream is closed"""
        return self._closed
    
    def __enter__(self) -> "DataStream":
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - auto-close the stream"""
        if not self._closed:
            self.close()
