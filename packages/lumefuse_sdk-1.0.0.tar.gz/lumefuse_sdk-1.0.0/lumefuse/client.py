"""
LumeFuse Client - Main API Client
"""

import hashlib
import json
import os
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urljoin
import httpx

from .stream import DataStream, StreamResult
from .models import BitPacket, VerificationResult, ChainStatus, CreditBalance, HealingEvent
from .exceptions import (
    LumeFuseError,
    AuthenticationError,
    RateLimitError,
    ChainIntegrityError,
    InsufficientCreditsError,
    NetworkError,
)


class LumeFuse:
    """
    LumeFuse SDK Client - The "Born-Signed" Data Integrity Platform
    
    This client provides methods to:
    - Open data streams for Bit-Packet creation
    - Verify data against the BSV ledger
    - Check chain integrity
    - Monitor healing events
    
    Usage:
        from lumefuse import LumeFuse
        
        lf = LumeFuse(api_key="lf_your_api_key")
        
        # Create a data stream
        stream = lf.open_stream("sensor_data")
        stream.write({"temperature": 72.5})
        result = stream.close()
        
        # Verify chain integrity
        status = lf.verify_chain("sensor_data")
        print(f"Chain intact: {status.chain_intact}")
    """
    
    DEFAULT_BASE_URL = "https://api.lumefuse.io/v1"
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
        auto_heal: bool = True
    ):
        """
        Initialize the LumeFuse client.
        
        Args:
            api_key: Your LumeFuse API key (starts with 'lf_')
            base_url: API base URL (default: https://api.lumefuse.io/v1)
            timeout: Request timeout in seconds
            auto_heal: Whether to automatically trigger healing on chain breaks
        """
        self.api_key = api_key or os.environ.get("LUMEFUSE_API_KEY")
        self.base_url = base_url or os.environ.get("LUMEFUSE_BASE_URL", self.DEFAULT_BASE_URL)
        self.timeout = timeout
        self.auto_heal = auto_heal
        
        if not self.api_key:
            raise AuthenticationError(
                "API key is required. Set LUMEFUSE_API_KEY environment variable or pass api_key parameter."
            )
        
        if not self.api_key.startswith("lf_"):
            raise AuthenticationError(
                "Invalid API key format. API keys should start with 'lf_'"
            )
        
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "X-SDK-Version": "lumefuse-python/1.0.0"
            }
        )
    
    def _request(
        self, 
        method: str, 
        endpoint: str, 
        data: Optional[Dict] = None,
        params: Optional[Dict] = None
    ) -> Dict:
        """Make an API request"""
        try:
            response = self._client.request(
                method=method,
                url=endpoint,
                json=data,
                params=params
            )
            
            if response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            
            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                raise RateLimitError(
                    "Rate limit exceeded",
                    retry_after=int(retry_after) if retry_after else None
                )
            
            if response.status_code == 402:
                raise InsufficientCreditsError("Insufficient BSV credits")
            
            if response.status_code >= 400:
                error_data = response.json() if response.text else {}
                raise LumeFuseError(
                    error_data.get("detail", f"Request failed with status {response.status_code}"),
                    code=str(response.status_code)
                )
            
            return response.json()
            
        except httpx.RequestError as e:
            raise NetworkError(f"Network request failed: {str(e)}")
    
    # ==================== STREAM API ====================
    
    def open_stream(
        self, 
        source_id: str,
        auto_anchor: bool = True,
        batch_size: int = 100
    ) -> DataStream:
        """
        Open a new data stream for Bit-Packet creation.
        
        This is the core "Latch" - data written to the returned stream is
        automatically hashed, linked with Recursive DNA, and anchored to BSV.
        
        Args:
            source_id: Unique identifier for this data source
            auto_anchor: Whether to automatically anchor packets (default: True)
            batch_size: Number of packets to batch before anchoring (default: 100)
        
        Returns:
            DataStream: A stream object for writing data
        
        Example:
            stream = lf.open_stream("medical_lab_results")
            stream.write({"patient_id": "P-001", "glucose": 95})
            stream.write({"patient_id": "P-001", "glucose": 102})
            result = stream.close()
            print(f"Merkle Root: {result.merkle_root}")
        """
        return DataStream(
            source_id=source_id,
            client=self,
            auto_anchor=auto_anchor,
            batch_size=batch_size
        )
    
    # ==================== WRAP API ====================
    
    def wrap(self, source_id: str, data: Union[str, bytes, Dict]) -> BitPacket:
        """
        Wrap data into a single Bit-Packet with Recursive DNA.
        
        This is a convenience method for wrapping individual data items.
        For streaming data, use open_stream() instead.
        
        Args:
            source_id: Unique identifier for this data source
            data: The data to wrap
        
        Returns:
            BitPacket: The created Bit-Packet
        """
        if isinstance(data, bytes):
            data = data.decode('utf-8')
        elif isinstance(data, dict):
            data = json.dumps(data, sort_keys=True, default=str)
        
        response = self._request("POST", "/packets/wrap", {
            "source_id": source_id,
            "data": data
        })
        
        return BitPacket.from_dict(response)
    
    def wrap_file(self, source_id: str, file_path: str) -> BitPacket:
        """
        Wrap a file into a Bit-Packet.
        
        Args:
            source_id: Unique identifier for this data source
            file_path: Path to the file to wrap
        
        Returns:
            BitPacket: The created Bit-Packet
        """
        with open(file_path, 'rb') as f:
            file_content = f.read()
        
        # Compute local hash for verification
        local_hash = hashlib.sha256(file_content).hexdigest()
        
        # In production, this would upload the file
        # For now, we compute the hash locally
        response = self._request("POST", "/packets/wrap", {
            "source_id": source_id,
            "data": f"FILE:{file_path}:{local_hash}"
        })
        
        return BitPacket.from_dict(response)
    
    # ==================== VERIFY API ====================
    
    def verify(self, data: Union[str, bytes, Dict]) -> VerificationResult:
        """
        Verify data against the BSV ledger.
        
        Args:
            data: The data to verify
        
        Returns:
            VerificationResult: Verification status and details
        """
        if isinstance(data, bytes):
            data_hash = hashlib.sha256(data).hexdigest()
        elif isinstance(data, dict):
            data_str = json.dumps(data, sort_keys=True, default=str)
            data_hash = hashlib.sha256(data_str.encode()).hexdigest()
        else:
            data_hash = hashlib.sha256(str(data).encode()).hexdigest()
        
        response = self._request("POST", "/verify", {
            "data_hash": data_hash
        })
        
        return VerificationResult(
            verified=response.get("verified", False),
            source_id=response.get("source_id", ""),
            data_hash=data_hash,
            expected_hash=response.get("expected_hash"),
            tx_id=response.get("tx_id"),
            timestamp=response.get("timestamp"),
            message=response.get("message", ""),
            quantum_resistant=response.get("quantum_resistant", True)
        )
    
    def verify_chain(self, source_id: str, auto_heal: Optional[bool] = None) -> ChainStatus:
        """
        Verify the entire Recursive DNA chain for a source.
        
        This checks that every packet's DNA correctly links to the previous,
        creating the "Cryptographic Heartbeat" that detects any tampering.
        
        Args:
            source_id: The source ID to verify
            auto_heal: Whether to auto-heal if broken (default: instance setting)
        
        Returns:
            ChainStatus: Chain integrity status
        
        Raises:
            ChainIntegrityError: If chain is broken and auto_heal is False
        """
        if auto_heal is None:
            auto_heal = self.auto_heal
        
        response = self._request("POST", "/sentinel/verify", {
            "source_id": source_id,
            "auto_heal": auto_heal
        })
        
        status = ChainStatus(
            source_id=source_id,
            chain_intact=response.get("chain_intact", False),
            total_packets=response.get("total_packets", 0),
            break_sequence=response.get("break_event", {}).get("break_sequence") if response.get("break_event") else None,
            break_timestamp=response.get("break_event", {}).get("break_timestamp") if response.get("break_event") else None,
            healed=response.get("healed", False),
            quantum_resistant=response.get("quantum_resistant", True),
            forensic_message=response.get("message")
        )
        
        if not status.chain_intact and not auto_heal:
            raise ChainIntegrityError(
                f"DNA chain broken at sequence {status.break_sequence}",
                break_sequence=status.break_sequence,
                break_timestamp=status.break_timestamp
            )
        
        return status
    
    # ==================== SENTINEL API ====================
    
    def get_sentinel_status(self) -> Dict:
        """
        Get the current status of the Sentinel (self-healing system).
        
        Returns:
            Dict with sentinel status and features
        """
        return self._request("GET", "/sentinel/status")
    
    def trigger_audit(self) -> Dict:
        """
        Manually trigger a full audit of all data sources.
        
        Returns:
            Dict with audit results
        """
        return self._request("POST", "/sentinel/audit/run")
    
    def heal(self, source_id: str, break_sequence: int) -> Dict:
        """
        Manually trigger healing for a specific data break.
        
        Args:
            source_id: The source ID to heal
            break_sequence: The sequence number where the break occurred
        
        Returns:
            Dict with healing result
        """
        return self._request("POST", "/sentinel/heal", {
            "source_id": source_id,
            "break_sequence": break_sequence
        })
    
    def get_healing_history(self, source_id: Optional[str] = None) -> List[HealingEvent]:
        """
        Get history of healing events.
        
        Args:
            source_id: Optional filter by source ID
        
        Returns:
            List of HealingEvent objects
        """
        params = {"source_id": source_id} if source_id else None
        response = self._request("GET", "/sentinel/healing-history", params=params)
        
        return [
            HealingEvent(
                id=e.get("id", ""),
                source_id=e.get("source_id", ""),
                break_sequence=e.get("break_sequence", 0),
                original_hash=e.get("original_payload_hash", ""),
                corrupted_hash=e.get("corrupted_payload_hash", ""),
                recovery_source=e.get("recovery_source", ""),
                healed_at=e.get("healed_at", ""),
                success=e.get("success", False),
                message=e.get("message", "")
            )
            for e in response.get("events", [])
        ]
    
    # ==================== CREDITS API ====================
    
    def get_credits(self) -> CreditBalance:
        """
        Get current BSV credit balance.
        
        Returns:
            CreditBalance: Current balance and usage
        """
        response = self._request("GET", "/credits/balance")
        
        return CreditBalance(
            satoshi_balance=response.get("satoshi_balance", 0),
            packets_available=response.get("packets_available", 0),
            total_deposited=response.get("total_deposited", 0),
            total_spent=response.get("total_spent", 0)
        )
    
    # ==================== PACKETS API ====================
    
    def get_packets(self, source_id: str, limit: int = 100) -> List[BitPacket]:
        """
        Get all packets for a source.
        
        Args:
            source_id: The source ID to query
            limit: Maximum number of packets to return
        
        Returns:
            List of BitPacket objects
        """
        response = self._request("GET", "/packets", params={
            "source_id": source_id,
            "limit": limit
        })
        
        return [BitPacket.from_dict(p) for p in response]
    
    # ==================== CONTEXT MANAGER ====================
    
    def __enter__(self) -> "LumeFuse":
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
    
    def close(self) -> None:
        """Close the HTTP client"""
        self._client.close()
