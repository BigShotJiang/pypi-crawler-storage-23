"""Command-line interface module.

This module provides CLI commands using Typer and Rich.
"""

from kstlib.cli.app import app

__all__ = ["app"]
