
import os



import shutil








# Mkdir if not exist
def Supporting_MkdirList(folderlist):
 for i in folderlist:
  if not os.path.exists('%s' %(i)):
   os.mkdir('%s' %(i))


def Supporting_ChunkList(l, n):
  x = [l[i:i + n] for i in range(0, len(l), n)]
  return x


def Supporting_CopyAnything(src, dst):
    try:
        shutil.copytree(src, dst)
    except OSError as exc:
        print("%s had been copied before. Check" %(dst))
        #shutil.copy(src, dst)
