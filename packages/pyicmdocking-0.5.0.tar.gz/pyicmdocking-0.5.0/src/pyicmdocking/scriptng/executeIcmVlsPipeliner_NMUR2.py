import subprocess
import os
from argparse import ArgumentParser
import sys
import tqdm
import re
import pandas as pd
from io import StringIO
import urllib.request
import glob
import gzip
import numpy as np
import time
import pickle

import pandas as pd

from collections import Counter, defaultdict

import networkx as nx



import bisect
#from numba import jit, float32, int64
import multiprocessing
from functools import partial


from commandIcmSupporting import *
from commandIcmVlsPipeliner import *


# =====================
# Instruction
# =====================
# Restrict the file name to alphanumeric only as filenames can be come pretty complicated ni later stages


# =====================
# I/O
# =====================

DIR_ICM64 = "/home/homingla/Software/icm-3.9-2e/icm64"

DIR_OverallFolder = os.path.abspath("../") + '/'

User_Outputlabel = "NMUR2"
User_ContainerName = "ResultNmur2"
User_Effort = 30.0
User_nprocs = 20







# ===========================
# Auto Folder structure
#=============================

DIR_Container = DIR_OverallFolder + "%s/" %(User_ContainerName)

# This is the sdf folder. All Sdf will be read here.
DIR_RawSdfFolder = DIR_OverallFolder + "Raw_SDF/"
DIR_RawPdbFolder = DIR_OverallFolder + "Raw_PDB/"



# Autoproduce folders
DIR_ProcessedSdfFolder = DIR_OverallFolder + "Icm_SDF/" # NOTE Hold sdf TODO incorporate charge enumeration
DIR_ProcessedPdbFolder = DIR_OverallFolder + "Icm_PDB/" # NOTE Hold Pdb ob
DIR_ProcessedMapFolder = DIR_OverallFolder + "Icm_MAP/" # NOTE Hold maps


Supporting_MkdirList([DIR_Container, 
                      DIR_ProcessedSdfFolder, DIR_ProcessedPdbFolder])





# ===================
# Execute
# ===============
# 1. Prepare all ligands
dockcontainer001 = IcmPipeliner(DIR_Container = DIR_Container, 
                                ICM_Rigid = True,
                                n_replica = 1)
# TODO Give option to enumerate stereochem /tautomer etc rather than hardcoded.
dockcontainer001.Prep_Ligand(
        DIR_RawSdfFolder = DIR_RawSdfFolder, 
        DIR_ProcessedSdfFolder = DIR_ProcessedSdfFolder, Outputlabel = User_Outputlabel)


# 2. Prepare receptor TODO Does not work when the ligand is peptide!
dockcontainer001.Prep_Receptor(
        DIR_RawPdbFolder = DIR_RawPdbFolder,
        DIR_ProcessedPdbFolder = DIR_ProcessedPdbFolder, Outputlabel = User_Outputlabel)


# 3. Prepare map
dockcontainer001.Prep_Map(
        DIR_ProcessedPdbFolder = DIR_ProcessedPdbFolder, 
        Outputlabel = User_Outputlabel, ChosenPocketDict = {"Nmr2aW0":0})


# Set up docking and inspection per sdf
dockcontainer001.Dock_PerSdf(
        DIR_ProcessedPdbFolder = DIR_ProcessedPdbFolder, 
        DIR_ProcessedSdfFolder = DIR_ProcessedSdfFolder, 
        Outputlabel = User_Outputlabel, n_processor = User_nprocs, n_effort = User_Effort)































































