# IcmDocking

Author: Jordy Homing Lam 
Copyright (C) 2024  Jordy Homing Lam, jhmlam, JHML. Ho Ming LAM. All rights reserved.

## Acknowledgement 
* We would like to thank Ruben Abagyan, Eugene Raush and Maxim Totrov for writing the very powerful ICM program in Molsoft LLC.
* We would like to thank Vsevolod Katritch for purchasing a license from Molsoft and teaching us how to use the program correctly.
* JHML would like to thank Tessa Ferrari for testing this out together with me when we started on one of the docking projects that went to black hole.