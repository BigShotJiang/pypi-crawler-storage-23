"""Test package for gs_prompt_manager."""
