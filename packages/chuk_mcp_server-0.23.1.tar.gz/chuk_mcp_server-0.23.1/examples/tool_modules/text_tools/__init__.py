"""Text Tools - Example tool module for ChukMCPServer."""
