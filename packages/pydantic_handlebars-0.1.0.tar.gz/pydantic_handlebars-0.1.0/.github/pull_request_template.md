- Closes #<issue>

### Checklist

- [ ] **Linting and type checking** pass (`make lint` and `make typecheck`)
- [ ] **Tests** maintain 100% coverage
- [ ] **PR title** is a clear summary of the change
