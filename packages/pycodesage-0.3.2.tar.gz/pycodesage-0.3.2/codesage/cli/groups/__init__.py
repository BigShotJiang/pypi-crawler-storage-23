"""Command groups for CodeSage CLI."""

from codesage.cli.groups import hook, mcp

__all__ = [
    "hook",
    "mcp",
]
