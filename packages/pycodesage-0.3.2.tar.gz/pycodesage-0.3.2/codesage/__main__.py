"""Allow running as python -m codesage."""

from codesage.cli.main import app

if __name__ == "__main__":
    app()
