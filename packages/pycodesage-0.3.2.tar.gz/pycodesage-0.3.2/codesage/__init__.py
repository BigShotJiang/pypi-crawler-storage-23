"""CodeSage: Local-first CLI code intelligence tool."""

__version__ = "0.3.2"
__author__ = "Keshav Ashiya"
