"""token 存储模块（keyring 优先，本地文件兜底）。"""

