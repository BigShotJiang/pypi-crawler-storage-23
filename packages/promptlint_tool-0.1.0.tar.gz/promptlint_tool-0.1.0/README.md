# promptlint-tool

Rules-based prompt quality checks (format, constraints, examples, role/tone).

## Install
```bash
pip install promptlint-tool
```

## CLI
```bash
promptlint prompt.txt
promptlint prompt.txt --json
```

You can also pipe from stdin:
```bash
cat prompt.txt | promptlint
```

## Python
```python
from promptlint import lint_text

res = lint_text("Return JSON with keys: a, b. Example: Input: ... Output: ...")
print(res.score)
for issue in res.issues:
    print(issue.code, issue.message)
```
