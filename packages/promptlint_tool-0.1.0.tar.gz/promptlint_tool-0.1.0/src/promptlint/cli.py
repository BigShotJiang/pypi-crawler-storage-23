import argparse
import json
import sys

from .core import lint_prompt, lint_text
from .formatters import format_human, format_json


def main():
    parser = argparse.ArgumentParser(
        prog="promptlint",
        description="Rules-based prompt quality checker (format, constraints, examples, role/tone).",
    )
    parser.add_argument("path", nargs="?", help="Path to a prompt text file. If omitted, reads from stdin.")
    parser.add_argument("--json", action="store_true", help="Output JSON instead of human-readable text.")
    args = parser.parse_args()

    if args.path:
        result = lint_prompt(args.path)
    else:
        text = sys.stdin.read()
        result = lint_text(text)

    if args.json:
        print(json.dumps(format_json(result), indent=2))
    else:
        print(format_human(result))
