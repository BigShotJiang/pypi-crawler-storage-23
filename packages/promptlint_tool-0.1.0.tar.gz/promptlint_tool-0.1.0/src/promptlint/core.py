from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

from .rules import LintIssue, RuleFn, default_rules


@dataclass(frozen=True)
class LintResult:
    score: int  # 0..100
    issues: List[LintIssue]
    summary: str


def _severity_penalty(severity: str) -> int:
    sev = severity.upper().strip()
    if sev == "HIGH":
        return 30
    if sev == "MEDIUM":
        return 15
    return 8  # LOW


def lint_text(text: str, rules: Optional[Sequence[RuleFn]] = None) -> LintResult:
    if rules is None:
        rules = default_rules()

    issues: List[LintIssue] = []
    clean_text = text or ""

    for rule in rules:
        try:
            issues.extend(rule(clean_text))
        except Exception as e:
            issues.append(LintIssue(
                code="PL000",
                severity="LOW",
                message=f"Rule raised an exception: {type(e).__name__}",
                suggestion="Update promptlint or disable the problematic rule."
            ))

    score = 100
    for iss in issues:
        score -= _severity_penalty(iss.severity)
    score = max(0, score)

    if not issues:
        summary = "Looks good: no issues detected."
    else:
        high = sum(1 for i in issues if i.severity.upper() == "HIGH")
        med = sum(1 for i in issues if i.severity.upper() == "MEDIUM")
        low = sum(1 for i in issues if i.severity.upper() == "LOW")
        summary = f"{len(issues)} issue(s): {high} high, {med} medium, {low} low."

    return LintResult(score=score, issues=issues, summary=summary)


def lint_prompt(path: str) -> LintResult:
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    return lint_text(text)
