from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable, List, Sequence

RuleFn = Callable[[str], List["LintIssue"]]


@dataclass(frozen=True)
class LintIssue:
    code: str
    severity: str  # "HIGH" | "MEDIUM" | "LOW"
    message: str
    suggestion: str


def _has_any(text: str, patterns: Sequence[str], *, flags: int = re.IGNORECASE) -> bool:
    for p in patterns:
        if re.search(p, text, flags=flags):
            return True
    return False


def rule_missing_output_format(text: str) -> List[LintIssue]:
    format_signals = [
        r"\bjson\b", r"\byaml\b", r"\bmarkdown\b", r"\bxml\b",
        r"\btable\b", r"\bbullets?\b", r"\bnumbered\b", r"\blist\b",
        r"\bschema\b", r"\bkeys?\b", r"\bfields?\b", r"\boutput\b.*\bformat\b",
        r"```",
    ]
    if not _has_any(text, format_signals):
        return [LintIssue(
            code="PL001",
            severity="HIGH",
            message="No explicit output format found.",
            suggestion="Specify the required output format (e.g., JSON with keys, Markdown sections, or a table)."
        )]
    return []


def rule_ambiguous_constraints(text: str) -> List[LintIssue]:
    vague_terms = [
        r"\bbrief\b", r"\bdetailed\b", r"\bquick\b", r"\bfast\b", r"\bbest\b",
        r"\bgood\b", r"\bproper\b", r"\bappropriate\b", r"\basap\b",
        r"\bconcise\b", r"\bexplain\b", r"\bcover everything\b",
    ]
    specificity_signals = [
        r"\bexactly\b\s+\d+\b", r"\b\d+\s*(words?|sentences?|bullets?)\b",
        r"\bmust include\b", r"\bshould include\b", r"\bdo not\b", r"\bonly\b",
        r"\breturn\b\s+\bjson\b", r"\bfields?\b", r"\bkeys?\b"
    ]
    has_vague = _has_any(text, vague_terms)
    has_specific = _has_any(text, specificity_signals)
    if has_vague and not has_specific:
        return [LintIssue(
            code="PL002",
            severity="MEDIUM",
            message="Ambiguous constraints detected (vague adjectives without measurable requirements).",
            suggestion="Replace vague words with measurable constraints (e.g., 'under 120 words', 'exactly 5 bullets', 'include 3 examples')."
        )]
    if has_vague and has_specific:
        return [LintIssue(
            code="PL002",
            severity="LOW",
            message="Some vague terms detected, but prompt also contains measurable constraints.",
            suggestion="Consider tightening any remaining vague wording to reduce interpretation differences."
        )]
    return []


def rule_missing_examples(text: str) -> List[LintIssue]:
    example_signals = [
        r"\bexample\b", r"\bexamples\b", r"\be\.g\.\b", r"\bfor instance\b",
        r"\bsample output\b", r"\bsample\b", r"\bfew[-\s]?shot\b",
        r"\binput:\b", r"\boutput:\b",
    ]
    if not _has_any(text, example_signals):
        return [LintIssue(
            code="PL003",
            severity="MEDIUM",
            message="No examples found (few-shot guidance missing).",
            suggestion="Add 1–2 short examples (input → output) to anchor the expected style/format."
        )]
    return []


def rule_missing_audience_or_role(text: str) -> List[LintIssue]:
    role_signals = [
        r"\byou are\b", r"\bact as\b", r"\bas a\b.*\bexpert\b",
        r"\baudience\b", r"\bfor beginners\b", r"\bfor executives\b",
        r"\btone\b", r"\bstyle\b"
    ]
    if not _has_any(text, role_signals):
        return [LintIssue(
            code="PL004",
            severity="LOW",
            message="No role/audience/tone guidance detected.",
            suggestion="Specify audience and tone (e.g., 'for beginners', 'executive summary', 'friendly tone')."
        )]
    return []


def default_rules() -> List[RuleFn]:
    return [
        rule_missing_output_format,
        rule_ambiguous_constraints,
        rule_missing_examples,
        rule_missing_audience_or_role,
    ]
