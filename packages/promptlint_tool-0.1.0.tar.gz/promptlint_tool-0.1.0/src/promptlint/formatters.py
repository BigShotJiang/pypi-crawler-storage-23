from __future__ import annotations

from typing import List

from .core import LintResult


def format_human(result: LintResult) -> str:
    lines: List[str] = []
    lines.append(f"PromptLint Score: {result.score}/100")
    lines.append(result.summary)

    if result.issues:
        lines.append("")
        lines.append("Issues:")
        for i, iss in enumerate(result.issues, start=1):
            lines.append(f"{i}. [{iss.severity}] {iss.code} - {iss.message}")
            lines.append(f"   Suggestion: {iss.suggestion}")
    return "\n".join(lines)


def format_json(result: LintResult) -> dict:
    return {
        "score": result.score,
        "summary": result.summary,
        "issues": [
            {
                "code": iss.code,
                "severity": iss.severity,
                "message": iss.message,
                "suggestion": iss.suggestion,
            }
            for iss in result.issues
        ],
    }
