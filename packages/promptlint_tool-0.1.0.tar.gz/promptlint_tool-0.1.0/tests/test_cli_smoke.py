import subprocess
import sys
from pathlib import Path

def test_cli_runs(tmp_path: Path):
    prompt_file = tmp_path / "p.txt"
    prompt_file.write_text("Summarize it.", encoding="utf-8")
    cmd = [sys.executable, "-m", "promptlint.cli", str(prompt_file)]
    cp = subprocess.run(cmd, capture_output=True, text=True)
    assert cp.returncode == 0
    assert "PromptLint Score" in cp.stdout
