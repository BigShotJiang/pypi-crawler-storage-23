from promptlint import lint_text

def test_missing_output_format_triggers():
    text = "Summarize this article."
    res = lint_text(text)
    codes = [i.code for i in res.issues]
    assert "PL001" in codes

def test_json_format_reduces_pl001():
    text = "Return JSON with keys: summary, risks. Summarize the text."
    res = lint_text(text)
    codes = [i.code for i in res.issues]
    assert "PL001" not in codes

def test_examples_rule():
    text = "Return JSON with keys: a, b. Do it."
    res = lint_text(text)
    codes = [i.code for i in res.issues]
    assert "PL003" in codes

def test_score_bounds():
    res = lint_text("")
    assert 0 <= res.score <= 100
