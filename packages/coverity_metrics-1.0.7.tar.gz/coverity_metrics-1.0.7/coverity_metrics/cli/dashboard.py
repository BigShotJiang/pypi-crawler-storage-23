"""
Coverity Metrics HTML Dashboard Generator
Creates a beautiful HTML dashboard using Jinja2 templates
Supports single-instance and multi-instance deployments
Supports reading from database or exported ZIP files
"""
import os
import sys
import argparse
import logging
import json
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
from coverity_metrics.metrics import CoverityMetrics
from coverity_metrics.zip_data_loader import ZipDataLoader
import webbrowser
from tqdm import tqdm
from coverity_metrics.metrics_cache import MetricsCache, ProgressTracker, collect_metrics_with_cache

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Color palette for automatic instance color assignment
INSTANCE_COLOR_PALETTE = [
    "#e74c3c",  # Red
    "#3498db",  # Blue
    "#2ecc71",  # Green
    "#f39c12",  # Orange
    "#9b59b6",  # Purple
    "#1abc9c",  # Turquoise
    "#e67e22",  # Carrot
    "#34495e",  # Dark gray
    "#16a085",  # Green Sea
    "#c0392b",  # Dark red
    "#2980b9",  # Belize blue
    "#8e44ad",  # Wisteria
    "#27ae60",  # Nephritis
    "#d35400",  # Pumpkin
    "#7f8c8d",  # Asbestos
]

def assign_instance_colors(instance_names):
    """Automatically assign distinct colors to instances
    
    Args:
        instance_names: List of instance names
        
    Returns:
        dict: Mapping of instance name to color hex code
    """
    color_map = {}
    for i, name in enumerate(instance_names):
        # Cycle through colors if we have more instances than colors
        color_map[name] = INSTANCE_COLOR_PALETTE[i % len(INSTANCE_COLOR_PALETTE)]
    return color_map

def load_inline_css():
    """
    Load CSS content from static directory to embed inline in HTML
    
    Returns:
        str: CSS content to embed in HTML style tags
    """
    # Get the package directory (where this file is located)
    package_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    css_path = os.path.join(package_dir, 'static', 'css', 'dashboard.css')
    
    # Load CSS file content
    if os.path.exists(css_path):
        with open(css_path, 'r', encoding='utf-8') as f:
            return f.read()
    else:
        tqdm.write(f"  [WARNING] CSS file not found at {css_path}")
        return "/* CSS file not found */"


def detect_multi_instance_config(config_file='config.json'):
    """
    Detect if multi-instance configuration exists and has multiple instances
    
    Returns:
        tuple: (is_multi_instance, instance_count, config_data)
    """
    if not os.path.exists(config_file):
        return False, 0, None
    
    try:
        with open(config_file, 'r') as f:
            config_data = json.load(f)
        
        instances = config_data.get('instances', [])
        enabled_instances = [inst for inst in instances if inst.get('enabled', True)]
        instance_count = len(enabled_instances)
        
        return instance_count > 1, instance_count, config_data
    except Exception as e:
        tqdm.write(f"[WARNING] Failed to read config file {config_file}: {e}")
        return False, 0, None

def generate_html_dashboard(output_file="output/dashboard.html", project_name=None, 
                           instance_name=None, metrics_instance=None, cache=None, use_cache=True, days=90):
    """Generate HTML dashboard with all metrics
    
    Args:
        output_file: Path to output HTML file
        project_name: Optional project name to filter metrics
        instance_name: Optional instance name for multi-instance mode
        metrics_instance: Optional CoverityMetrics instance (for multi-instance)
        cache: Optional MetricsCache instance for caching support
        use_cache: Whether to use cached data if available
        days: Number of days for trend analysis (default: 90)
    """
    tqdm.write("\nGenerating Coverity Metrics HTML Dashboard...")
    if instance_name:
        tqdm.write(f"Instance: {instance_name}")
    if project_name:
        tqdm.write(f"Filtering by project: {project_name}")
    tqdm.write("=" * 80)
    
    # Initialize metrics with project filter
    if metrics_instance:
        metrics = metrics_instance
        if project_name:
            metrics.project_name = project_name
    else:
        # This shouldn't happen anymore, but handle gracefully
        raise ValueError("metrics_instance is required. Please pass CoverityMetrics instance to generate_html_dashboard()")
    
    # Try to use cached data if cache is provided
    if cache and use_cache:
        cache_key = f"{instance_name}_{project_name}_days{days}" if instance_name else f"default_{project_name if project_name else 'all'}_days{days}"
        cached_metrics = cache.get_cached_metrics(instance_name or 'default', project_name, days)
        
        if cached_metrics:
            tqdm.write("  [CACHE] Using cached metrics data")
            metrics_data = cached_metrics['data']
            
            # Extract from cache
            summary = metrics_data.get('summary', {})
            defects_by_severity = metrics_data.get('defects_by_severity', [])
            defects_by_project = metrics_data.get('defects_by_project', [])
            defects_by_category = metrics_data.get('defects_by_category', [])
            top_checkers = metrics_data.get('top_checkers', [])
            defect_density = metrics_data.get('defect_density', [])
            file_hotspots = metrics_data.get('file_hotspots', [])
            code_metrics = metrics_data.get('code_metrics', [])
            complexity_distribution = metrics_data.get('complexity_distribution', [])
            db_stats = metrics_data.get('db_stats', {})
            instance_info = metrics_data.get('instance_info', {})
            analysis_versions = metrics_data.get('analysis_versions', [])
            largest_tables = metrics_data.get('largest_tables', [])
            snapshot_performance = metrics_data.get('snapshot_performance', [])
            commit_stats = metrics_data.get('commit_stats', {})
            commit_activity = metrics_data.get('commit_activity', {})
            defect_discovery = metrics_data.get('defect_discovery', [])
            projects_list = metrics_data.get('all_projects', [])
            defect_trends = metrics_data.get('defect_trends', [])
            triage_trends = metrics_data.get('triage_trends', [])
            fix_rate_metrics = metrics_data.get('fix_rate_metrics', {})
            defect_aging = metrics_data.get('defect_aging', [])
            triage_summary = metrics_data.get('triage_summary', {})
            defect_velocity = metrics_data.get('defect_velocity', [])
            cumulative_trends = metrics_data.get('cumulative_trends', [])
            trend_summary = metrics_data.get('trend_summary', {})
            trend_period_text = metrics_data.get('trend_period_text', f'Last {days} Days')
            user_activity_stats = metrics_data.get('user_activity_stats', {})
            top_projects_by_fix_rate = metrics_data.get('top_projects_by_fix_rate', [])
            most_improved_projects = metrics_data.get('most_improved_projects', [])
            top_projects_by_triage = metrics_data.get('top_projects_by_triage', [])
            top_users_by_fixes = metrics_data.get('top_users_by_fixes', [])
            top_triagers = metrics_data.get('top_triagers', [])
            most_collaborative_users = metrics_data.get('most_collaborative_users', [])
            owasp_metrics = metrics_data.get('owasp_metrics', [])
            owasp_details = metrics_data.get('owasp_details', {})
            cwe_top25_metrics = metrics_data.get('cwe_top25_metrics', [])
            tech_debt_summary = metrics_data.get('tech_debt_summary', {})
        else:
            # Collect from database and cache
            metrics_data = _collect_and_cache_metrics(metrics, instance_name, project_name, cache, days)
            summary = metrics_data['summary']
            defects_by_severity = metrics_data['defects_by_severity']
            defects_by_project = metrics_data['defects_by_project']
            defects_by_category = metrics_data['defects_by_category']
            top_checkers = metrics_data['top_checkers']
            defect_density = metrics_data['defect_density']
            file_hotspots = metrics_data['file_hotspots']
            code_metrics = metrics_data['code_metrics']
            complexity_distribution = metrics_data['complexity_distribution']
            db_stats = metrics_data['db_stats']
            instance_info = metrics_data.get('instance_info', {})
            analysis_versions = metrics_data.get('analysis_versions', [])
            largest_tables = metrics_data['largest_tables']
            snapshot_performance = metrics_data['snapshot_performance']
            commit_stats = metrics_data['commit_stats']
            commit_activity = metrics_data.get('commit_activity', {})
            defect_discovery = metrics_data['defect_discovery']
            projects_list = metrics_data['all_projects']
            defect_trends = metrics_data.get('defect_trends', [])
            triage_trends = metrics_data.get('triage_trends', [])
            fix_rate_metrics = metrics_data.get('fix_rate_metrics', {})
            defect_aging = metrics_data.get('defect_aging', [])
            triage_summary = metrics_data.get('triage_summary', {})
            defect_velocity = metrics_data.get('defect_velocity', [])
            cumulative_trends = metrics_data.get('cumulative_trends', [])
            trend_summary = metrics_data.get('trend_summary', {})
            trend_period_text = metrics_data.get('trend_period_text', f'Last {days} Days')
            user_activity_stats = metrics_data.get('user_activity_stats', {})
            top_projects_by_fix_rate = metrics_data.get('top_projects_by_fix_rate', [])
            most_improved_projects = metrics_data.get('most_improved_projects', [])
            top_projects_by_triage = metrics_data.get('top_projects_by_triage', [])
            top_users_by_fixes = metrics_data.get('top_users_by_fixes', [])
            top_triagers = metrics_data.get('top_triagers', [])
            most_collaborative_users = metrics_data.get('most_collaborative_users', [])
            owasp_metrics = metrics_data.get('owasp_metrics', [])
            owasp_details = metrics_data.get('owasp_details', {})
            cwe_top25_metrics = metrics_data.get('cwe_top25_metrics', [])
            tech_debt_summary = metrics_data.get('tech_debt_summary', {})
    else:
        # Collect without caching
        all_projects = metrics.get_available_projects()
        projects_list = all_projects['project_name'].tolist() if not all_projects.empty else []
        
        # Collect all metrics data
        tqdm.write("Collecting metrics data...")
        
        summary = metrics.get_overall_summary()
        defects_by_severity = metrics.get_defects_by_severity().to_dict('records')
        defects_by_project = metrics.get_total_defects_by_project().to_dict('records')
        defects_by_category = metrics.get_defects_by_checker_category(limit=20).to_dict('records')
        top_checkers = metrics.get_defects_by_checker_name(limit=20).to_dict('records')
        defect_density = metrics.get_defect_density_by_project().to_dict('records')
        file_hotspots = metrics.get_file_hotspots(limit=20).to_dict('records')
        code_metrics = metrics.get_code_metrics_by_stream().to_dict('records')
        complexity_distribution = metrics.get_function_complexity_distribution().to_dict('records')
        
        # Collect performance metrics
        db_stats = metrics.get_database_statistics()
        instance_info = metrics.get_instance_info()
        analysis_versions = metrics.get_analysis_versions(limit=10, days=days)
        largest_tables = metrics.get_largest_tables(limit=10).to_dict('records')
        snapshot_performance = metrics.get_snapshot_performance(limit=15).to_dict('records')
        commit_stats = metrics.get_commit_time_statistics()
        commit_activity = metrics.get_commit_activity_patterns()
        defect_discovery = metrics.get_defect_discovery_rate(days=days).to_dict('records')
        
        # Collect user activity statistics
        user_activity_stats = metrics.get_user_license_statistics(days=days)
        
        # Collect trend analysis data
        # Use daily granularity for project-level reports, weekly for instance-level
        granularity = 'day' if project_name else 'week'
        defect_trends = metrics.get_defect_trends(days=days, granularity=granularity).to_dict('records')
        triage_trends = metrics.get_triage_trends(days=days, granularity=granularity).to_dict('records')
        fix_rate_metrics = metrics.get_fix_rate_metrics(days=days)
        defect_aging = metrics.get_defect_aging_distribution().to_dict('records')
        triage_summary = metrics.get_triage_progress_summary()
        
        # Collect enhanced velocity and cumulative trends
        defect_velocity = metrics.get_defect_velocity_trend(days=days).to_dict('records')
        cumulative_trends = metrics.get_cumulative_defect_trend(days=days).to_dict('records')
        trend_summary = metrics.get_defect_trend_summary(days=days)
        
        # Collect technical debt summary
        tech_debt_summary = metrics.get_technical_debt_summary()
        
        # Collect leaderboard data (now using triage_state table for user metrics)
        top_projects_by_fix_rate = metrics.get_top_projects_by_fix_rate(days=30, limit=10).to_dict('records')
        most_improved_projects = metrics.get_most_improved_projects(days=90, limit=10).to_dict('records')
        top_projects_by_triage = metrics.get_top_projects_by_triage_activity(days=30, limit=10).to_dict('records')
        top_users_by_fixes = metrics.get_top_users_by_fixes(days=30, limit=10).to_dict('records')
        top_triagers = metrics.get_top_triagers(days=30, limit=10).to_dict('records')
        most_collaborative_users = metrics.get_most_collaborative_users(days=30, limit=10).to_dict('records')
        
        # Collect OWASP Top 10 2025 metrics (project-level only)
        owasp_metrics = metrics.get_owasp_top10_metrics().to_dict('records') if project_name else []
        
        # Collect detailed breakdown for FAILED OWASP categories
        owasp_details = {}
        if project_name and owasp_metrics:
            for item in owasp_metrics:
                if item.get('status') == 'FAILED':
                    category_id = item['category']
                    owasp_details[category_id] = metrics.get_owasp_category_details(category_id)
        
        # Collect CWE Top 25 2024 metrics (project-level only)
        cwe_top25_metrics = metrics.get_cwe_top25_metrics().to_dict('records') if project_name else []
        
        # Collect detailed breakdown for FAILED CWE Top 25 entries only
        cwe_top25_details = {}
        if project_name and cwe_top25_metrics:
            for item in cwe_top25_metrics:
                if item.get('status') == 'FAILED':
                    cwe_id = item['cwe_id']
                    cwe_top25_details[cwe_id] = metrics.get_cwe_top25_details(cwe_id)
        
        # Calculate actual date range from trend data
        trend_period_text = f"Last {days} Days"
        
        tqdm.write(f"  [OK] Summary statistics")
        tqdm.write(f"  [OK] Defects by severity: {len(defects_by_severity)} records")
        tqdm.write(f"  [OK] Defects by project: {len(defects_by_project)} records")
        tqdm.write(f"  [OK] Defects by category: {len(defects_by_category)} records")
        tqdm.write(f"  [OK] File hotspots: {len(file_hotspots)} records")
        tqdm.write(f"  [OK] Code quality metrics: {len(code_metrics)} records")
        tqdm.write(f"  [OK] Performance metrics: {len(snapshot_performance)} snapshots")
        tqdm.write(f"  [OK] Trend analysis: {len(defect_trends)} periods")
        active_users = user_activity_stats.get('active_users', 0) if user_activity_stats else 0
        tqdm.write(f"  [OK] User activity: {active_users} active users")
    
    # Check for high severity alert
    high_severity_alert = summary.get('high_severity_defects', 0) > 0
    
    # Load CSS content for inline embedding
    inline_css = load_inline_css()
    
    # Set up Jinja2 environment (templates are in parent package directory)
    template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'templates')
    env = Environment(loader=FileSystemLoader(template_dir))
    
    # Load template
    template = env.get_template('dashboard.html')
    
    # Render template with data
    html_content = template.render(
        inline_css=inline_css,
        timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        summary=summary,
        defects_by_severity=defects_by_severity,
        defects_by_project=defects_by_project,
        defects_by_category=defects_by_category,
        top_checkers=top_checkers,
        defect_density=defect_density,
        file_hotspots=file_hotspots,
        code_metrics=code_metrics,
        complexity_distribution=complexity_distribution,
        high_severity_alert=high_severity_alert,
        current_project=project_name,
        current_instance=instance_name,
        all_projects=projects_list,
        # Performance metrics
        db_stats=db_stats,
        instance_info=instance_info,
        analysis_versions=analysis_versions,
        largest_tables=largest_tables,
        snapshot_performance=snapshot_performance,
        commit_stats=commit_stats,
        commit_activity=commit_activity,
        defect_discovery=defect_discovery,
        # Trend analysis
        defect_trends=defect_trends,
        triage_trends=triage_trends,
        fix_rate_metrics=fix_rate_metrics,
        defect_aging=defect_aging,
        triage_summary=triage_summary,
        defect_velocity=defect_velocity,
        cumulative_trends=cumulative_trends,
        trend_summary=trend_summary,
        tech_debt_summary=tech_debt_summary,
        trend_period_text=trend_period_text,
        user_activity_stats=user_activity_stats,
        # Leaderboards
        top_projects_by_fix_rate=top_projects_by_fix_rate,
        most_improved_projects=most_improved_projects,
        top_projects_by_triage=top_projects_by_triage,
        top_users_by_fixes=top_users_by_fixes,
        top_triagers=top_triagers,
        most_collaborative_users=most_collaborative_users,
        # OWASP Top 10 2025 (project-level only)
        owasp_metrics=owasp_metrics,
        owasp_details=owasp_details,
        # CWE Top 25 2024 (project-level only)
        cwe_top25_metrics=cwe_top25_metrics,
        cwe_top25_details=cwe_top25_details
    )
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    # Write HTML file
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # Get absolute path for display
    abs_path = os.path.abspath(output_file)
    
    tqdm.write("\n" + "=" * 80)
    tqdm.write(f"[SUCCESS] Dashboard generated successfully!")
    tqdm.write(f"Location: {abs_path}")
    tqdm.write(f"File size: {os.path.getsize(output_file):,} bytes")
    tqdm.write("=" * 80)
    
    return abs_path


def _collect_and_cache_metrics(metrics, instance_name, project_name, cache, days=90):
    """Helper function to collect metrics and cache them"""
    tqdm.write(f"Collecting metrics data from database (trend period: {days} days)...")
    
    all_projects = metrics.get_available_projects()
    projects_list = all_projects['project_name'].tolist() if not all_projects.empty else []
    
    summary = metrics.get_overall_summary()
    defects_by_severity = metrics.get_defects_by_severity().to_dict('records')
    defects_by_project = metrics.get_total_defects_by_project().to_dict('records')
    defects_by_category = metrics.get_defects_by_checker_category(limit=20).to_dict('records')
    top_checkers = metrics.get_defects_by_checker_name(limit=20).to_dict('records')
    defect_density = metrics.get_defect_density_by_project().to_dict('records')
    file_hotspots = metrics.get_file_hotspots(limit=20).to_dict('records')
    code_metrics = metrics.get_code_metrics_by_stream().to_dict('records')
    complexity_distribution = metrics.get_function_complexity_distribution().to_dict('records')
    db_stats = metrics.get_database_statistics()
    instance_info = metrics.get_instance_info()
    analysis_versions = metrics.get_analysis_versions(limit=10, days=days)
    largest_tables = metrics.get_largest_tables(limit=10).to_dict('records')
    snapshot_performance = metrics.get_snapshot_performance(limit=15).to_dict('records')
    commit_stats = metrics.get_commit_time_statistics()
    commit_activity = metrics.get_commit_activity_patterns()
    defect_discovery = metrics.get_defect_discovery_rate(days=days).to_dict('records')
    
    # Collect user activity statistics
    user_activity_stats = metrics.get_user_license_statistics(days=days)
    
    # Collect trend analysis data
    # Use daily granularity for project-level reports, weekly for instance-level
    granularity = 'day' if project_name else 'week'
    defect_trends = metrics.get_defect_trends(days=days, granularity=granularity).to_dict('records')
    triage_trends = metrics.get_triage_trends(days=days, granularity=granularity).to_dict('records')
    fix_rate_metrics = metrics.get_fix_rate_metrics(days=days)
    defect_aging = metrics.get_defect_aging_distribution().to_dict('records')
    triage_summary = metrics.get_triage_progress_summary()
    
    # Collect enhanced velocity and cumulative trends
    defect_velocity = metrics.get_defect_velocity_trend(days=days).to_dict('records')
    cumulative_trends = metrics.get_cumulative_defect_trend(days=days).to_dict('records')
    trend_summary = metrics.get_defect_trend_summary(days=days)
    
    # Collect leaderboard data (project-level only - database doesn't have history tables for user tracking)
    top_projects_by_fix_rate = metrics.get_top_projects_by_fix_rate(days=30, limit=10).to_dict('records')
    most_improved_projects = metrics.get_most_improved_projects(days=90, limit=10).to_dict('records')
    top_projects_by_triage = metrics.get_top_projects_by_triage_activity(days=30, limit=10).to_dict('records')
    top_users_by_fixes = []  # Not available without defect_triage_history table
    top_triagers = []  # Not available without defect_triage_history table
    most_collaborative_users = []  # Not available without defect_history table
    
    # Collect OWASP Top 10 2025 metrics (project-level only)
    owasp_metrics = metrics.get_owasp_top10_metrics().to_dict('records') if project_name else []
    
    # Collect detailed breakdown for FAILED OWASP categories
    owasp_details = {}
    if project_name and owasp_metrics:
        for item in owasp_metrics:
            if item.get('status') == 'FAILED':
                category_id = item['category']
                owasp_details[category_id] = metrics.get_owasp_category_details(category_id)
    
    # Collect CWE Top 25 2024 metrics (project-level only)
    cwe_top25_metrics = metrics.get_cwe_top25_metrics().to_dict('records') if project_name else []
    
    # Collect technical debt summary
    tech_debt_summary = metrics.get_technical_debt_summary()
    
    # Calculate actual date range from trend data
    trend_period_text = f"Last {days} Days"
    
    tqdm.write(f"  [OK] Summary statistics")
    tqdm.write(f"  [OK] Defects by severity: {len(defects_by_severity)} records")
    tqdm.write(f"  [OK] Defects by project: {len(defects_by_project)} records")
    tqdm.write(f"  [OK] Defects by category: {len(defects_by_category)} records")
    tqdm.write(f"  [OK] File hotspots: {len(file_hotspots)} records")
    tqdm.write(f"  [OK] Code quality metrics: {len(code_metrics)} records")
    tqdm.write(f"  [OK] Performance metrics: {len(snapshot_performance)} snapshots")
    tqdm.write(f"  [OK] Trend analysis: {len(defect_trends)} periods")
    active_users = user_activity_stats.get('active_users', 0) if user_activity_stats else 0
    tqdm.write(f"  [OK] User activity: {active_users} active users")
    
    metrics_data = {
        'summary': summary,
        'defects_by_severity': defects_by_severity,
        'defects_by_project': defects_by_project,
        'defects_by_category': defects_by_category,
        'top_checkers': top_checkers,
        'defect_density': defect_density,
        'file_hotspots': file_hotspots,
        'code_metrics': code_metrics,
        'complexity_distribution': complexity_distribution,
        'db_stats': db_stats,
        'instance_info': instance_info,
        'analysis_versions': analysis_versions,
        'largest_tables': largest_tables,
        'snapshot_performance': snapshot_performance,
        'commit_stats': commit_stats,
        'commit_activity': commit_activity,
        'defect_discovery': defect_discovery,
        'all_projects': projects_list,
        'defect_trends': defect_trends,
        'triage_trends': triage_trends,
        'fix_rate_metrics': fix_rate_metrics,
        'defect_aging': defect_aging,
        'triage_summary': triage_summary,
        'defect_velocity': defect_velocity,
        'cumulative_trends': cumulative_trends,
        'trend_summary': trend_summary,
        'trend_period_text': trend_period_text,
        'user_activity_stats': user_activity_stats,
        'top_projects_by_fix_rate': top_projects_by_fix_rate,
        'most_improved_projects': most_improved_projects,
        'top_projects_by_triage': top_projects_by_triage,
        'top_users_by_fixes': top_users_by_fixes,
        'top_triagers': top_triagers,
        'most_collaborative_users': most_collaborative_users,
        'owasp_metrics': owasp_metrics,
        'owasp_details': owasp_details,
        'cwe_top25_metrics': cwe_top25_metrics,
        'tech_debt_summary': tech_debt_summary
    }
    
    # Cache the data
    if cache:
        cache.save_metrics_to_cache(instance_name or 'default', metrics_data, project_name)
    
    return metrics_data


def generate_aggregated_dashboard(multi_metrics, output_file="output/dashboard_aggregated.html", days=365):
    """Generate aggregated dashboard across all Coverity instances
    
    Args:
        multi_metrics: MultiInstanceMetrics instance
        output_file: Path to output HTML file
        days: Number of days for trend analysis (default: 365)
    """
    tqdm.write("\nGenerating Aggregated Multi-Instance Dashboard...")
    tqdm.write("=" * 80)
    
    # Get aggregated data
    tqdm.write("Collecting aggregated metrics data...")
    summary = multi_metrics.get_aggregated_summary()
    defects_by_instance = multi_metrics.get_defects_by_instance().to_dict('records')
    defects_by_severity = multi_metrics.get_aggregated_defects_by_severity().to_dict('records')
    analysis_versions = multi_metrics.get_aggregated_analysis_versions(limit=10)
    user_statistics = multi_metrics.get_aggregated_user_statistics(days=days)
    database_statistics = multi_metrics.get_aggregated_database_statistics()
    commit_activity = multi_metrics.get_aggregated_commit_activity()
    aggregated_trends = multi_metrics.get_aggregated_trends(days=days)
    
    # Get instance names with colors
    instance_configs = []
    for instance in multi_metrics.instances:
        instance_configs.append({
            'name': instance.name,
            'description': instance.description,
            'color': instance.color
        })
    
    tqdm.write(f"  [OK] Aggregated summary across {summary['total_instances']} instances")
    tqdm.write(f"  [OK] Defects by instance: {len(defects_by_instance)} instances")
    tqdm.write(f"  [OK] User activity: {user_statistics['active_users']} active users across all instances")
    tqdm.write(f"  [OK] Database statistics: {database_statistics['total_db_size']} total size, {database_statistics['total_snapshots']} snapshots")
    tqdm.write(f"  [OK] Trends & Progress: {aggregated_trends['trend_summary']['total_new']} new, {aggregated_trends['trend_summary']['total_fixed']} fixed")
    
    # Load CSS content for inline embedding
    inline_css = load_inline_css()
    
    # Set up Jinja2 environment (templates are in parent package directory)
    template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'templates')
    env = Environment(loader=FileSystemLoader(template_dir))
    
    # Load aggregated template
    template = env.get_template('dashboard_aggregated.html')
    
    # Render template with data
    html_content = template.render(
        inline_css=inline_css,
        timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        summary=summary,
        defects_by_instance=defects_by_instance,
        defects_by_severity=defects_by_severity,
        analysis_versions=analysis_versions,
        instance_configs=instance_configs,
        user_statistics=user_statistics,
        database_statistics=database_statistics,
        commit_activity=commit_activity,
        triage_summary=aggregated_trends['triage_summary'],
        trend_summary=aggregated_trends['trend_summary'],
        fix_rate_metrics=aggregated_trends['fix_rate_metrics'],
        trends_by_instance=aggregated_trends['by_instance'],
        trend_period_text=f"Last {days} Days",
        multi_instance_mode=True
    )
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    # Write HTML file
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # Get absolute path for display
    abs_path = os.path.abspath(output_file)
    
    tqdm.write("\n" + "=" * 80)
    tqdm.write(f"[SUCCESS] Aggregated dashboard generated successfully!")
    tqdm.write(f"Location: {abs_path}")
    tqdm.write(f"File size: {os.path.getsize(output_file):,} bytes")
    tqdm.write("=" * 80)
    
    return abs_path


def generate_aggregated_dashboard_from_zips(zip_loaders, instance_configs, output_file="output/dashboard_aggregated.html", days=365):
    """Generate aggregated dashboard from ZIP file data loaders
    
    Args:
        zip_loaders: Dict mapping instance names to ZipDataLoader objects
        instance_configs: List of dicts with instance config (name, description, color)
        output_file: Path to output HTML file
        days: Number of days for trend analysis
    """
    tqdm.write("\nGenerating Aggregated Dashboard from ZIP files...")
    tqdm.write("=" * 80)
    
    # Collect aggregated data from all ZIP loaders
    tqdm.write("Collecting aggregated metrics from ZIP files...")
    
    # Initialize aggregated statistics
    total_defects = 0
    total_outstanding = 0
    total_fixed = 0
    total_dismissed = 0
    total_triaged = 0
    total_new = 0
    total_projects = 0
    total_high_severity = 0
    total_licensed_users = 0
    total_users_with_login = 0
    total_active_users = 0
    total_snapshots = 0
    total_db_size_bytes = 0
    total_commits = 0
    min_duration_seconds = None
    max_duration_seconds = None
    weighted_duration_sum = 0  # For calculating weighted average
    
    defects_by_instance_list = []
    defects_by_severity_agg = {}
    analysis_versions_agg = {}
    user_statistics_by_instance = []
    database_statistics_by_instance = []
    trends_by_instance = []
    triage_by_state_agg = {}
    commit_activity_by_hour = {}
    commit_activity_by_day = {}
    
    # Aggregate data from each instance
    for instance_name, loader in zip_loaders.items():
        try:
            summary = loader.get_overall_summary()
            
            # Get trend summary for this instance
            trend_data = loader.get_defect_trend_summary(days=days)
            
            # Get triage summary for this instance
            triage_data = loader.get_triage_progress_summary()
            
            # Aggregate totals from summary
            total_defects += summary.get('total_defects', 0)
            total_projects += summary.get('total_projects', 0)
            
            # Aggregate totals from trend data
            if trend_data:
                total_new += trend_data.get('total_new', 0)
                total_fixed += trend_data.get('total_fixed', 0)
                total_outstanding += trend_data.get('current_outstanding', summary.get('total_defects', 0))
            else:
                total_outstanding += summary.get('total_defects', 0)
            
            # Aggregate triage data
            if triage_data:
                total_triaged += triage_data.get('classified_count', 0)
            
            # Note: dismissed_defects is typically tracked in trend data or separate metrics
            # For now, using total_dismissed from available data
            total_dismissed += 0  # Not typically in summary; would need separate metric
            
            # Get severity breakdown for this instance
            severity_df = loader.get_defects_by_severity()
            high_severity = 0
            medium_severity = 0
            low_severity = 0
            
            if not severity_df.empty:
                for _, row in severity_df.iterrows():
                    severity = row.get('impact', row.get('severity', 'Unknown'))
                    count = row.get('defect_count', row.get('count', 0))
                    
                    # Count for instance-level metrics
                    if severity == 'High':
                        high_severity += count
                        total_high_severity += count
                    elif severity == 'Medium':
                        medium_severity += count
                    elif severity == 'Low':
                        low_severity += count
                    
                    # Aggregate for overall severity
                    if severity in defects_by_severity_agg:
                        defects_by_severity_agg[severity] += count
                    else:
                        defects_by_severity_agg[severity] = count
            
            # Get instance description and color from config
            instance_config = next((cfg for cfg in instance_configs if cfg['name'] == instance_name), None)
            description = instance_config.get('description', '') if instance_config else ''
            color = instance_config.get('color', '#3498db') if instance_config else '#3498db'
            
            # Per-instance defect count with all fields needed by template
            defects_by_instance_list.append({
                'instance_name': instance_name,
                'description': description,
                'color': color,
                'total_defects': summary.get('total_defects', 0),
                'high_severity': high_severity,
                'medium_severity': medium_severity,
                'low_severity': low_severity,
                'total_projects': summary.get('total_projects', 0),
                'total_streams': summary.get('total_streams', 0)
            })
            
            # Collect user statistics from each instance
            try:
                user_stats = loader.get_user_license_statistics(days=90)
                if user_stats:
                    licensed_users = user_stats.get('total_licensed_users', 0)
                    users_with_login = user_stats.get('users_with_login', 0)
                    active_users = user_stats.get('active_users', 0)
                    
                    total_licensed_users += licensed_users
                    total_users_with_login += users_with_login
                    total_active_users += active_users
                    
                    active_percentage = round((active_users / licensed_users * 100) if licensed_users > 0 else 0, 1)
                    
                    user_statistics_by_instance.append({
                        'instance_name': instance_name,
                        'color': color,
                        'licensed_users': licensed_users,
                        'users_with_login': users_with_login,
                        'active_users': active_users,
                        'active_percentage': active_percentage
                    })
            except Exception as e:
                tqdm.write(f"  [WARNING] Failed to load user statistics from {instance_name}: {e}")
            
            # Collect database statistics from each instance
            try:
                db_stats = loader.get_database_statistics()
                if db_stats:
                    # Use db_size_bytes if available, otherwise try to parse db_size
                    db_size = db_stats.get('db_size_bytes', 0)
                    if db_size == 0:
                        db_size_str = db_stats.get('total_db_size', db_stats.get('db_size', '0'))
                        if isinstance(db_size_str, str):
                            # Try to extract bytes from formatted string (e.g., "123.45 MB")
                            import re
                            match = re.search(r'([\d.]+)\s*(GB|MB|KB|B)', db_size_str, re.IGNORECASE)
                            if match:
                                value = float(match.group(1))
                                unit = match.group(2).upper()
                                if unit == 'GB':
                                    db_size = int(value * 1024 * 1024 * 1024)
                                elif unit == 'MB':
                                    db_size = int(value * 1024 * 1024)
                                elif unit == 'KB':
                                    db_size = int(value * 1024)
                                else:
                                    db_size = int(value)
                    
                    snapshots = db_stats.get('total_snapshots', 0)
                    
                    total_db_size_bytes += db_size
                    total_snapshots += snapshots
                    
                    # Store for per-instance table (will add commit stats later)
                    db_instance_entry = {
                        'instance_name': instance_name,
                        'color': color,
                        'db_size': db_size,
                        'total_snapshots': snapshots
                    }
                    database_statistics_by_instance.append(db_instance_entry)
            except Exception as e:
                tqdm.write(f"  [WARNING] Failed to load database statistics from {instance_name}: {e}")
            
            # Collect commit time statistics from each instance
            try:
                commit_stats = loader.get_commit_time_statistics()
                if commit_stats:
                    commits = commit_stats.get('total_commits', 0)
                    avg_duration = commit_stats.get('avg_duration_seconds', 0)
                    min_duration = commit_stats.get('min_duration_seconds', 0)
                    max_duration = commit_stats.get('max_duration_seconds', 0)
                    
                    total_commits += commits
                    weighted_duration_sum += avg_duration * commits
                    
                    # Track global min/max
                    if min_duration_seconds is None or (min_duration > 0 and min_duration < min_duration_seconds):
                        min_duration_seconds = min_duration
                    if max_duration_seconds is None or max_duration > max_duration_seconds:
                        max_duration_seconds = max_duration
                    
                    # Update database_statistics_by_instance entry with commit stats
                    if database_statistics_by_instance:
                        database_statistics_by_instance[-1]['total_commits'] = commits
                        database_statistics_by_instance[-1]['avg_duration_seconds'] = round(avg_duration, 2)
            except Exception as e:
                tqdm.write(f"  [WARNING] Failed to load commit statistics from {instance_name}: {e}")
            
            # Collect commit activity patterns from each instance
            try:
                activity_patterns = loader.get_commit_activity_patterns()
                if activity_patterns:
                    # Aggregate by hour
                    by_hour = activity_patterns.get('by_hour', [])
                    for hour_data in by_hour:
                        hour = int(hour_data.get('hour', 0))
                        commit_count = hour_data.get('commit_count', 0)
                        avg_duration = hour_data.get('avg_duration_seconds', 0)
                        
                        if hour in commit_activity_by_hour:
                            commit_activity_by_hour[hour]['commit_count'] += commit_count
                            commit_activity_by_hour[hour]['total_duration'] += avg_duration * commit_count
                        else:
                            commit_activity_by_hour[hour] = {
                                'hour': hour,
                                'commit_count': commit_count,
                                'total_duration': avg_duration * commit_count
                            }
                    
                    # Aggregate by day
                    by_day = activity_patterns.get('by_day_of_week', [])
                    for day_data in by_day:
                        day_name = day_data.get('day_name', 'Unknown')
                        day_num = int(day_data.get('day_num', 0))
                        commit_count = day_data.get('commit_count', 0)
                        avg_duration = day_data.get('avg_duration_seconds', 0)
                        
                        if day_name in commit_activity_by_day:
                            commit_activity_by_day[day_name]['commit_count'] += commit_count
                            commit_activity_by_day[day_name]['total_duration'] += avg_duration * commit_count
                        else:
                            commit_activity_by_day[day_name] = {
                                'day_num': day_num,
                                'day_name': day_name,
                                'commit_count': commit_count,
                                'total_duration': avg_duration * commit_count
                            }
            except Exception as e:
                tqdm.write(f"  [WARNING] Failed to load commit activity patterns from {instance_name}: {e}")
            
            # Collect analysis versions from each instance
            try:
                versions = loader.get_analysis_versions(limit=10, days=days)
                if versions and len(versions) > 0:
                    for ver in versions:
                        version = ver.get('version', ver.get('analysis_version', 'Unknown'))
                        snapshot_count = ver.get('snapshot_count', 1)
                        first_used = ver.get('first_used')
                        last_used = ver.get('last_used')
                        
                        if version in analysis_versions_agg:
                            # Merge data
                            analysis_versions_agg[version]['snapshot_count'] += snapshot_count
                            analysis_versions_agg[version]['instances'].add(instance_name)
                            
                            # Update first/last used dates
                            if first_used:
                                if analysis_versions_agg[version]['first_used'] is None or first_used < analysis_versions_agg[version]['first_used']:
                                    analysis_versions_agg[version]['first_used'] = first_used
                            if last_used:
                                if analysis_versions_agg[version]['last_used'] is None or last_used > analysis_versions_agg[version]['last_used']:
                                    analysis_versions_agg[version]['last_used'] = last_used
                        else:
                            analysis_versions_agg[version] = {
                                'version': version,
                                'snapshot_count': snapshot_count,
                                'instances': {instance_name},
                                'first_used': first_used,
                                'last_used': last_used
                            }
            except Exception as e:
                tqdm.write(f"  [WARNING] Failed to load analysis versions from {instance_name}: {e}")
            
            # Collect triage trends from each instance
            if triage_data:
                # Use triage_progress_summary data
                for key in ['bug_count', 'false_positive_count', 'intentional_count', 'action_assigned_count']:
                    state_name = key.replace('_count', '').replace('_', ' ').title()
                    count = triage_data.get(key, 0)
                    if count > 0:
                        if state_name in triage_by_state_agg:
                            triage_by_state_agg[state_name] += count
                        else:
                            triage_by_state_agg[state_name] = count
            
            # Collect defect trends for per-instance breakdown
            if trend_data:
                trends_by_instance.append({
                    'instance_name': instance_name,
                    'color': color,
                    'triage_completion': round((triage_data.get('classified_count', 0) / summary.get('total_defects', 1) * 100) if summary.get('total_defects', 0) > 0 else 0, 1),
                    'classified': triage_data.get('classified_count', 0) if triage_data else 0,
                    'total_new': trend_data.get('total_new', 0),
                    'total_fixed': trend_data.get('total_fixed', 0),
                    'net_change': trend_data.get('net_change', 0),
                    'trend_direction': trend_data.get('trend_direction', 'unknown').lower()
                })
        
        except Exception as e:
            tqdm.write(f"  [WARNING] Failed to load metrics from {instance_name}: {e}")
    
    # Calculate aggregated triage summary
    # Use total_triaged which correctly sums classified_count from each instance
    # Don't use sum(triage_by_state_agg.values()) as it includes action_assigned_count which may include unclassified defects
    total_classified = total_triaged
    total_unclassified = total_defects - total_classified if total_defects > total_classified else 0
    triage_completion_pct = round((total_classified / total_defects * 100) if total_defects > 0 else 0, 1)
    
    # Count by specific triage states
    bug_count = triage_by_state_agg.get('Bug', 0) + triage_by_state_agg.get('Action Required', 0)
    false_positive_count = triage_by_state_agg.get('False Positive', 0)
    intentional_count = triage_by_state_agg.get('Intentional', 0)
    action_assigned_count = triage_by_state_agg.get('Action Assigned', 0)
    
    # Calculate trend metrics
    avg_new_per_day = round(total_new / days, 1) if days > 0 else 0
    avg_fixed_per_day = round(total_fixed / days, 1) if days > 0 else 0
    net_change = total_new - total_fixed
    fix_rate_pct = round((total_fixed / (total_fixed + total_new) * 100) if (total_fixed + total_new) > 0 else 0, 1)
    
    if total_fixed > total_new:
        trend_direction = 'improving'
    elif total_new > total_fixed:
        trend_direction = 'declining'
    else:
        trend_direction = 'stable'
    
    # Format aggregated summary
    summary = {
        'total_instances': len(zip_loaders),
        'total_defects': total_defects,
        'outstanding_defects': total_outstanding,
        'fixed_defects': total_fixed,
        'dismissed_defects': total_dismissed,
        'triaged_defects': total_triaged,
        'new_defects': total_new,
        'total_projects': total_projects,
        'high_severity_defects': total_high_severity,
        'fix_rate': round((total_fixed / total_defects * 100) if total_defects > 0 else 0, 1),
        'triage_rate': round((total_triaged / total_defects * 100) if total_defects > 0 else 0, 1)
    }
    
    # Format defects by severity for template
    defects_by_severity = [
        {'severity': severity, 'count': count}
        for severity, count in defects_by_severity_agg.items()
    ]
    
    # Format analysis versions for template (sorted by snapshot count)
    analysis_versions = sorted([
        {
            'version': data['version'],
            'snapshot_count': data['snapshot_count'],
            'instances': list(data['instances']),
            'first_used': data['first_used'],
            'last_used': data['last_used']
        }
        for data in analysis_versions_agg.values()
    ], key=lambda x: x['snapshot_count'], reverse=True)
    
    # Format user statistics
    user_statistics = {
        'total_licensed_users': total_licensed_users,
        'users_with_login': total_users_with_login,
        'login_user_percentage': round((total_users_with_login / total_licensed_users * 100) if total_licensed_users > 0 else 0, 1),
        'active_users': total_active_users,
        'active_user_percentage': round((total_active_users / total_licensed_users * 100) if total_licensed_users > 0 else 0, 1),
        'top_fixers': [],
        'top_triagers': [],
        'by_instance': user_statistics_by_instance
    }
    
    # Format database statistics
    def format_db_size(bytes_size):
        if bytes_size >= 1024 * 1024 * 1024:
            return f"{bytes_size / (1024 * 1024 * 1024):.2f} GB"
        elif bytes_size >= 1024 * 1024:
            return f"{bytes_size / (1024 * 1024):.2f} MB"
        elif bytes_size >= 1024:
            return f"{bytes_size / 1024:.2f} KB"
        else:
            return f"{bytes_size} B"
    
    # Calculate weighted average commit duration
    avg_duration_seconds = round(weighted_duration_sum / total_commits, 2) if total_commits > 0 else 0
    
    # Format per-instance database statistics (add formatted db_size)
    for inst in database_statistics_by_instance:
        inst['db_size'] = format_db_size(inst['db_size'])
    
    database_statistics = {
        'total_db_size': format_db_size(total_db_size_bytes),
        'total_snapshots': total_snapshots,
        'total_commits': total_commits,
        'avg_duration_seconds': avg_duration_seconds,
        'min_duration_seconds': round(min_duration_seconds, 2) if min_duration_seconds is not None else 0,
        'max_duration_seconds': round(max_duration_seconds, 2) if max_duration_seconds is not None else 0,
        'by_instance': database_statistics_by_instance
    }
    
    # Calculate commit activity patterns
    # Find busiest and quietest hours (3-hour blocks)
    busiest_hours = None
    quietest_hours = None
    if commit_activity_by_hour:
        # Calculate 3-hour rolling windows
        hours_sorted = sorted(commit_activity_by_hour.keys())
        best_window = {'commit_count': 0}
        worst_window = {'commit_count': float('inf')}
        
        for start_hour in hours_sorted:
            window_commits = 0
            window_duration = 0
            hours_in_window = []
            
            for h in range(start_hour, min(start_hour + 3, 24)):
                if h in commit_activity_by_hour:
                    window_commits += commit_activity_by_hour[h]['commit_count']
                    window_duration += commit_activity_by_hour[h]['total_duration']
                    hours_in_window.append(h)
            
            if len(hours_in_window) >= 2:  # At least 2 hours of data
                if window_commits > best_window['commit_count']:
                    best_window = {
                        'block_start': start_hour,
                        'block_end': min(start_hour + 2, 23),
                        'hours_display': f"{start_hour:02d}:00-{min(start_hour + 2, 23):02d}:00 ({start_hour % 12 or 12} {'AM' if start_hour < 12 else 'PM'} - {(min(start_hour + 2, 23)) % 12 or 12} {'AM' if min(start_hour + 2, 23) < 12 else 'PM'})",
                        'commit_count': window_commits,
                        'avg_duration_seconds': round(window_duration / window_commits, 2) if window_commits > 0 else 0
                    }
                
                if window_commits < worst_window['commit_count'] and window_commits > 0:
                    worst_window = {
                        'block_start': start_hour,
                        'block_end': min(start_hour + 2, 23),
                        'hours_display': f"{start_hour:02d}:00-{min(start_hour + 2, 23):02d}:00 ({start_hour % 12 or 12} {'AM' if start_hour < 12 else 'PM'} - {(min(start_hour + 2, 23)) % 12 or 12} {'AM' if min(start_hour + 2, 23) < 12 else 'PM'})",
                        'commit_count': window_commits,
                        'avg_duration_seconds': round(window_duration / window_commits, 2) if window_commits > 0 else 0
                    }
        
        if best_window['commit_count'] > 0:
            busiest_hours = best_window
        if worst_window['commit_count'] < float('inf'):
            quietest_hours = worst_window
    
    # Find busiest and quietest days
    busiest_day = None
    quietest_day = None
    if commit_activity_by_day:
        for day_name, day_data in commit_activity_by_day.items():
            commit_count = day_data['commit_count']
            avg_duration = round(day_data['total_duration'] / commit_count, 2) if commit_count > 0 else 0
            
            day_entry = {
                'day_num': day_data['day_num'],
                'day_name': day_name,
                'commit_count': commit_count,
                'avg_duration_seconds': avg_duration
            }
            
            if busiest_day is None or commit_count > busiest_day['commit_count']:
                busiest_day = day_entry
            
            if (quietest_day is None or commit_count < quietest_day['commit_count']) and commit_count > 0:
                quietest_day = day_entry
    
    commit_activity = {
        'total_commits': total_commits,
        'commits_by_hour': [],
        'by_instance': [],
        'busiest_hours': busiest_hours,
        'quietest_hours': quietest_hours,
        'busiest_day': busiest_day,
        'quietest_day': quietest_day
    }
    
    # Triage summary
    triage_summary = {
        'total': total_classified,
        'total_defects': total_defects,
        'classified_count': total_classified,
        'unclassified_count': total_unclassified,
        'triage_completion_percentage': triage_completion_pct,
        'bug_count': bug_count,
        'false_positive_count': false_positive_count,
        'intentional_count': intentional_count,
        'action_assigned_count': action_assigned_count,
        'by_state': [
            {'state': state, 'count': count}
            for state, count in triage_by_state_agg.items()
        ]
    }
    
    # Trend summary
    trend_summary = {
        'total_new': total_new,
        'total_fixed': total_fixed,
        'total_dismissed': total_dismissed,
        'avg_new_per_day': avg_new_per_day,
        'avg_fixed_per_day': avg_fixed_per_day,
        'net_change': net_change,
        'fix_rate_pct': fix_rate_pct,
        'trend_direction': trend_direction,
        'current_outstanding': total_outstanding
    }
    
    # Fix rate metrics
    fix_rate_metrics = {
        'total_defects': total_defects,
        'fixed_defects': total_fixed,
        'fix_rate_percentage': round((total_fixed / total_defects * 100) if total_defects > 0 else 0, 1)
    }
    
    tqdm.write(f"  [OK] Aggregated summary across {summary['total_instances']} instances")
    tqdm.write(f"  [OK] Total defects: {total_defects:,}")
    tqdm.write(f"  [OK] Outstanding: {total_outstanding:,}, Fixed: {total_fixed:,}")
    
    # Load CSS content for inline embedding
    inline_css = load_inline_css()
    
    # Set up Jinja2 environment
    template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'templates')
    env = Environment(loader=FileSystemLoader(template_dir))
    
    # Load aggregated template
    template = env.get_template('dashboard_aggregated.html')
    
    # Render template with data
    html_content = template.render(
        inline_css=inline_css,
        timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        summary=summary,
        defects_by_instance=defects_by_instance_list,
        defects_by_severity=defects_by_severity,
        analysis_versions=analysis_versions,
        instance_configs=instance_configs,
        user_statistics=user_statistics,
        database_statistics=database_statistics,
        commit_activity=commit_activity,
        triage_summary=triage_summary,
        trend_summary=trend_summary,
        fix_rate_metrics=fix_rate_metrics,
        trends_by_instance=trends_by_instance,
        trend_period_text=f"Last {days} Days",
        multi_instance_mode=True,
        zip_mode=True  # Flag to indicate ZIP mode (some features unavailable)
    )
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_file) if os.path.dirname(output_file) else '.', exist_ok=True)
    
    # Write HTML file
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # Get absolute path for display
    abs_path = os.path.abspath(output_file)
    
    tqdm.write("\n" + "=" * 80)
    tqdm.write(f"[SUCCESS] Aggregated dashboard generated successfully!")
    tqdm.write(f"Location: {abs_path}")
    tqdm.write(f"File size: {os.path.getsize(output_file):,} bytes")
    tqdm.write("=" * 80)
    
    return abs_path


def main():
    """Main entry point with automatic multi-instance detection"""
    parser = argparse.ArgumentParser(
        description='Generate Coverity Metrics HTML Dashboard (auto-detects multi-instance from config.json)\n'
                    'Supports reading from database or exported ZIP files.',
        epilog='Examples:\n'
               '  coverity-dashboard                          # Auto-detect and generate all (database)\n'
               '  coverity-dashboard --project MyApp          # Filter by project (database)\n'
               '  coverity-dashboard --instance Prod          # Specific instance only (database)\n'
               '  coverity-dashboard --zip-file export.zip    # Generate from ZIP export\n'
               '  coverity-dashboard --zip-file export1.zip export2.zip export3.zip  # Multi-ZIP aggregation\n'
               '  coverity-dashboard --zip-file export.zip --instance Prod --project MyApp\n'
               '  coverity-dashboard --days 365               # Change trend period\n',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument('--project', '-p', type=str, 
                       help='Filter metrics by specific project name')
    parser.add_argument('--output', '-o', type=str, default='output', 
                       help='Output folder path (default: output)')
    parser.add_argument('--no-browser', action='store_true',
                       help='Do not open dashboard in browser')
    
    # Data source arguments
    parser.add_argument('--zip-file', '-z', type=str, nargs='+',
                       help='Use exported ZIP file(s) as data source instead of database (supports multiple files for aggregation)')
    
    # Multi-instance arguments (mostly for backward compatibility and override)
    parser.add_argument('--config', '-c', type=str, default='config.json',
                       help='Path to configuration file (default: config.json)')
    parser.add_argument('--instance', '-i', type=str,
                       help='Generate dashboard for specific instance only')
    parser.add_argument('--single-instance-mode', action='store_true',
                       help='Force single-instance mode even if config.json has multiple instances')
    
    # Caching arguments
    parser.add_argument('--cache', action='store_true',
                       help='Enable caching to speed up subsequent generations')
    parser.add_argument('--cache-dir', type=str, default='cache',
                       help='Directory for cache files (default: cache)')
    parser.add_argument('--cache-ttl', type=int, default=24,
                       help='Cache time-to-live in hours (default: 24)')
    parser.add_argument('--clear-cache', action='store_true',
                       help='Clear all cached data before generating')
    parser.add_argument('--cache-stats', action='store_true',
                       help='Display cache statistics and exit')
    parser.add_argument('--no-cache', action='store_true',
                       help='Force refresh data from database, bypass cache')
    
    # Trend analysis arguments
    parser.add_argument('--days', '-d', type=int, default=365,
                       help='Number of days for trend analysis (default: 365)')
    
    # Progress tracking arguments
    parser.add_argument('--track-progress', action='store_true',
                       help='Enable progress tracking for large operations')
    parser.add_argument('--resume', type=str,
                       help='Resume from interrupted session (provide session ID)')
    
    args = parser.parse_args()
    
    tqdm.write("\nCoverity Metrics HTML Dashboard Generator")
    tqdm.write("=" * 80)
    
    # ========================================================================
    # ZIP FILE MODE - Read from exported ZIP instead of database
    # ========================================================================
    if args.zip_file:
        zip_files = args.zip_file if isinstance(args.zip_file, list) else [args.zip_file]
        
        # Validate all ZIP files exist
        for zip_file in zip_files:
            if not os.path.exists(zip_file):
                tqdm.write(f"[ERROR] ZIP file not found: {zip_file}")
                sys.exit(1)
        
        # ==============================================================
        # MULTI-ZIP AGGREGATION MODE - Multiple ZIP files provided
        # ==============================================================
        if len(zip_files) > 1:
            tqdm.write(f"\n[Multi-ZIP Aggregation Mode] Combining {len(zip_files)} ZIP files:")
            for zip_file in zip_files:
                tqdm.write(f"  - {zip_file}")
            
            try:
                # Load all ZIP files and extract instance information
                zip_loaders = {}
                all_instances = []
                days = 365  # Default, will use from first ZIP
                
                for zip_file in zip_files:
                    loader = ZipDataLoader(zip_file)
                    metadata = loader.get_metadata()
                    available_instances = loader.list_available_instances()
                    
                    if not available_instances:
                        tqdm.write(f"[WARNING] No instances found in {zip_file}, skipping")
                        continue
                    
                    # Use first instance from each ZIP file
                    instance_name = available_instances[0]
                    loader.instance_name = instance_name
                   
                    zip_loaders[instance_name] = loader
                    all_instances.append(instance_name)
                    days = metadata.get('days', days)
                    
                    tqdm.write(f"  [OK] Loaded instance '{instance_name}' from {os.path.basename(zip_file)}")
                
                if not zip_loaders:
                    tqdm.write("[ERROR] No valid instances found in any ZIP file")
                    sys.exit(1)
                
                tqdm.write(f"\nTotal instances loaded: {len(all_instances)}")
                tqdm.write(f"Instances: {', '.join(all_instances)}")
                
                generated_files = []
                
                # Generate aggregated dashboard (if no project filter)
                if not args.project:
                    tqdm.write("\n[1/3] Generating aggregated dashboard...")
                    aggregated_output = f"{args.output}/dashboard_aggregated.html"
                    
                    # Get instance configs from metadata with auto-assigned colors
                    color_map = assign_instance_colors(all_instances)
                    instance_configs = []
                    for instance_name in all_instances:
                        instance_configs.append({
                            'name': instance_name,
                            'description': f'{instance_name} Instance',
                            'color': color_map[instance_name]
                        })
                    
                    # Generate aggregated dashboard
                    dashboard_path = generate_aggregated_dashboard_from_zips(
                        zip_loaders,
                        instance_configs,
                        aggregated_output,
                        days
                    )
                    generated_files.append(("Aggregated View", dashboard_path))
                
                # Generate per-instance dashboards
                instance_num = 0 if args.project else 2
                total_steps = len(all_instances) + instance_num
                current_step = instance_num
                
                tqdm.write(f"\n[{current_step+1}/{total_steps}] Generating per-instance dashboards...")
                for instance_name in all_instances:
                    loader = zip_loaders[instance_name]
                    
                    output_folder = f"{args.output}/{instance_name.replace(' ', '_')}"
                    os.makedirs(output_folder, exist_ok=True)
                    
                    # Get projects for this instance
                    loader.project_name = None
                    available_projects = loader.list_available_projects()
                    
                    # Filter by project if specified
                    if args.project:
                        if args.project not in available_projects:
                            tqdm.write(f"  [SKIP] Instance '{instance_name}': Project '{args.project}' not found")
                            continue
                        
                        tqdm.write(f"  Generating dashboard for {instance_name} - {args.project}")
                        loader.project_name = args.project
                        output_file = f"{output_folder}/dashboard_{args.project.replace(' ', '_')}.html"
                        dashboard_path = generate_html_dashboard(
                            output_file, 
                            args.project, 
                            instance_name, 
                            loader, 
                            cache=None, 
                            use_cache=False, 
                            days=days
                        )
                        generated_files.append((f"{instance_name} - {args.project}", dashboard_path))
                    else:
                        # Instance-level dashboard
                        tqdm.write(f"  Generating instance dashboard: {instance_name}")
                        output_file = f"{output_folder}/dashboard.html"
                        dashboard_path = generate_html_dashboard(
                            output_file, 
                            None, 
                            instance_name, 
                            loader, 
                            cache=None, 
                            use_cache=False, 
                            days=days
                        )
                        generated_files.append((f"{instance_name} - All Projects", dashboard_path))
                        
                        # Project-level dashboards
                        for project_name in available_projects:
                            tqdm.write(f"    • Project: {project_name}")
                            loader.project_name = project_name
                            output_file = f"{output_folder}/dashboard_{project_name.replace(' ', '_')}.html"
                            dashboard_path = generate_html_dashboard(
                                output_file, 
                                project_name, 
                                instance_name, 
                                loader, 
                                cache=None, 
                                use_cache=False, 
                                days=days
                            )
                            generated_files.append((f"{instance_name} - {project_name}", dashboard_path))
                
                # Summary
                tqdm.write("\n" + "=" * 80)
                tqdm.write(f"[SUCCESS] Multi-instance dashboards generated successfully!")
                tqdm.write(f"  Total ZIP files: {len(zip_files)}")
                tqdm.write(f"  Total instances: {len(all_instances)}")
                tqdm.write(f"  Total dashboards: {len(generated_files)}")
                tqdm.write("\nGenerated dashboards:")
                for name, path in generated_files:
                    tqdm.write(f"  • {name}: {path}")
                
                # Open in browser
                if not args.no_browser and generated_files:
                    main_dashboard = generated_files[0][1]
                    tqdm.write(f"\nOpening dashboard in browser: {main_dashboard}")
                    webbrowser.open('file://' + os.path.abspath(main_dashboard))
                
                return
            
            except Exception as e:
                tqdm.write(f"[ERROR] Failed to process ZIP files: {str(e)}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
        
        # ==============================================================
        # SINGLE-ZIP MODE - One ZIP file provided
        # ==============================================================
        else:
            zip_file = zip_files[0]
            tqdm.write(f"\n[ZIP File Mode] Using exported data: {zip_file}")
            
            # Load ZIP data
            try:
                zip_loader = ZipDataLoader(zip_file, instance_name=args.instance)
                metadata = zip_loader.get_metadata()
                
                tqdm.write(f"  Export date: {metadata.get('export_date', 'Unknown')}")
                tqdm.write(f"  Trend period: {metadata.get('days', 'Unknown')} days")
                
                available_instances = zip_loader.list_available_instances()
                tqdm.write(f"  Available instances: {', '.join(available_instances)}")
                
                # Auto-select instance if not specified
                if not args.instance and available_instances:
                    args.instance = available_instances[0]
                    tqdm.write(f"  Auto-selected instance: {args.instance}")
                    zip_loader.instance_name = args.instance
                
                # Get available projects
                available_projects = zip_loader.list_available_projects()
                tqdm.write(f"  Available projects: {', '.join(available_projects) if available_projects else 'None'}")
                
                generated_files = []
                
                if args.project:
                    # Generate dashboard for specific project
                    if args.project not in available_projects:
                        tqdm.write(f"\n[ERROR] Project '{args.project}' not found in ZIP file")
                        tqdm.write(f"Available projects: {', '.join(available_projects)}")
                        sys.exit(1)
                    
                    tqdm.write(f"\nGenerating dashboard for project: {args.project}")
                    zip_loader.project_name = args.project
                    
                    output_folder = f"{args.output}/{args.instance.replace(' ', '_')}" if args.instance else args.output
                    os.makedirs(output_folder, exist_ok=True)
                    output_file = f"{output_folder}/dashboard_{args.project.replace(' ', '_')}.html"
                    
                    dashboard_path = generate_html_dashboard(
                        output_file, 
                        args.project, 
                        args.instance, 
                        zip_loader, 
                        cache=None, 
                        use_cache=False, 
                        days=metadata.get('days', 365)
                    )
                    generated_files.append((f"{args.instance} - {args.project}", dashboard_path))
                else:
                    # Generate dashboards for all projects
                    tqdm.write(f"\nGenerating dashboards for all projects in {args.instance}...")
                    
                    output_folder = f"{args.output}/{args.instance.replace(' ', '_')}" if args.instance else args.output
                    os.makedirs(output_folder, exist_ok=True)
                    
                    # Generate aggregated dashboard first (even for single instance)
                    tqdm.write(f"  Generating aggregated dashboard...")
                    zip_loaders_dict = {args.instance: zip_loader}
                    # Auto-assign color for single instance
                    color_map = assign_instance_colors([args.instance])
                    instance_configs = [{
                        'name': args.instance,
                        'description': f'{args.instance} Instance',
                        'color': color_map[args.instance]
                    }]
                    aggregated_output = f"{args.output}/dashboard_aggregated.html"
                    dashboard_path = generate_aggregated_dashboard_from_zips(
                        zip_loaders_dict,
                        instance_configs,
                        aggregated_output,
                        metadata.get('days', 365)
                    )
                    generated_files.append(("Aggregated View", dashboard_path))
                    
                    # Instance-level dashboard (all projects)
                    tqdm.write(f"  Generating instance dashboard: {args.instance}")
                    output_file = f"{output_folder}/dashboard.html"
                    zip_loader.project_name = None
                    dashboard_path = generate_html_dashboard(
                        output_file, 
                        None, 
                        args.instance, 
                        zip_loader, 
                        cache=None, 
                        use_cache=False, 
                        days=metadata.get('days', 365)
                    )
                    generated_files.append((f"{args.instance} - All Projects", dashboard_path))
                    
                    # Project-level dashboards
                    for project_name in available_projects:
                        tqdm.write(f"  Generating project dashboard: {project_name}")
                        zip_loader.project_name = project_name
                        output_file = f"{output_folder}/dashboard_{project_name.replace(' ', '_')}.html"
                        dashboard_path = generate_html_dashboard(
                            output_file, 
                            project_name, 
                            args.instance, 
                            zip_loader, 
                            cache=None, 
                            use_cache=False, 
                            days=metadata.get('days', 365)
                        )
                        generated_files.append((f"{args.instance} - {project_name}", dashboard_path))
                
                # Summary
                tqdm.write("\n" + "=" * 80)
                tqdm.write(f"[SUCCESS] Dashboard(s) generated successfully!")
                tqdm.write(f"  Total dashboards: {len(generated_files)}")
                for name, path in generated_files:
                    tqdm.write(f"    {name}: {path}")
                
                # Open in browser
                if not args.no_browser and generated_files:
                    main_dashboard = generated_files[0][1]
                    tqdm.write(f"\nOpening dashboard in browser: {main_dashboard}")
                    webbrowser.open('file://' + os.path.abspath(main_dashboard))
                
                return
            
            except Exception as e:
                tqdm.write(f"[ERROR] Failed to process ZIP file: {str(e)}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
    
    # ========================================================================
    # DATABASE MODE - Continue with normal database logic
    # ========================================================================
    
    # Auto-detect multi-instance configuration
    is_multi_instance, instance_count, config_data = detect_multi_instance_config(args.config)
    
    # Override detection if single-instance mode forced
    if args.single_instance_mode:
        is_multi_instance = False
        tqdm.write("\n[Single-Instance Mode] Forced by --single-instance-mode flag")
    elif is_multi_instance:
        tqdm.write(f"\n[Multi-Instance Mode] Auto-detected {instance_count} instances in {args.config}")
    else:
        tqdm.write("\n[Single-Instance Mode] Using first instance from {args.config}")
    
    # Handle cache stats request
    if args.cache_stats:
        cache = MetricsCache(cache_dir=args.cache_dir, cache_ttl_hours=args.cache_ttl)
        stats = cache.get_cache_stats()
        tqdm.write("\nCache Statistics:")
        tqdm.write(f"  Location: {stats['cache_dir']}")
        tqdm.write(f"  Total entries: {stats['total_entries']}")
        tqdm.write(f"  Valid entries: {stats['valid_entries']}")
        tqdm.write(f"  Expired entries: {stats['expired_entries']}")
        tqdm.write(f"  Total size: {stats['total_size_mb']} MB")
        
        if stats['expired_entries'] > 0:
            tqdm.write(f"\nRun with --clear-cache to remove expired entries")
        return
    
    # Initialize cache if enabled
    cache = None
    use_cache = not args.no_cache
    if args.cache or args.clear_cache:
        cache = MetricsCache(cache_dir=args.cache_dir, cache_ttl_hours=args.cache_ttl)
        tqdm.write(f"\n[Cache Enabled] Location: {cache.cache_dir}, TTL: {args.cache_ttl} hours")
        
        if args.clear_cache:
            cache.clear_cache()
            tqdm.write("[Cache Cleared] All cached data removed")
    
    # Initialize progress tracker if enabled
    progress_tracker = None
    session_id = None
    if args.track_progress or args.resume:
        progress_tracker = ProgressTracker(cache_dir=args.cache_dir)
        
        if args.resume:
            # Load existing session
            tqdm.write(f"\n[Resume Mode] Loading session: {args.resume}")
            progress_data = progress_tracker.get_progress(args.resume)
            if not progress_data:
                tqdm.write(f"[ERROR] Session not found: {args.resume}")
                sys.exit(1)
            session_id = args.resume
            tqdm.write(f"  Completed: {progress_data['completed_tasks']}/{progress_data['total_tasks']}")
            tqdm.write(f"  Failed: {progress_data['failed_tasks']}")
    
    try:
        # ========================================================================
        # MULTI-INSTANCE MODE (automatic)
        # ========================================================================
        if is_multi_instance and not args.single_instance_mode:
            from coverity_metrics.multi_instance_metrics import MultiInstanceMetrics
            
            multi_metrics = MultiInstanceMetrics(args.config)
            instance_names = multi_metrics.get_instance_names()
            tqdm.write(f"  Instances: {', '.join(instance_names)}")
            
            generated_files = []
            
            # Check if filtering by specific instance
            if args.instance:
                # SPECIFIC INSTANCE MODE
                if args.instance not in instance_names:
                    tqdm.write(f"\n[ERROR] Unknown instance: {args.instance}")
                    tqdm.write(f"Available instances: {', '.join(instance_names)}")
                    sys.exit(1)
                
                tqdm.write(f"\nGenerating dashboards for instance: {args.instance}")
                
                if args.project:
                    # Specific instance + specific project
                    tqdm.write(f"  Project filter: {args.project}")
                    metrics = multi_metrics.get_metrics_for_instance(args.instance, args.project)
                    instance_folder = f"{args.output}/{args.instance.replace(' ', '_')}"
                    os.makedirs(instance_folder, exist_ok=True)
                    output_file = f"{instance_folder}/dashboard_{args.project.replace(' ', '_')}.html"
                    dashboard_path = generate_html_dashboard(output_file, args.project, args.instance, metrics, cache, use_cache, args.days)
                    generated_files.append((f"{args.instance} - {args.project}", dashboard_path))
                else:
                    # Specific instance + all projects (AUTO)
                    tqdm.write(f"  Generating all projects (auto-mode)")
                    metrics = multi_metrics.get_metrics_for_instance(args.instance)
                    projects = metrics.get_available_projects()
                    
                    # Calculate total work
                    total_dashboards = 1 + (len(projects) if not projects.empty else 0)  # 1 instance + N projects
                    tqdm.write(f"  Total dashboards to generate: {total_dashboards} (1 instance + {len(projects) if not projects.empty else 0} projects)")
                    
                    with tqdm(total=total_dashboards, desc=f"{args.instance}", unit="dashboard") as pbar:
                        # Generate instance-level dashboard (all projects)
                        instance_folder = f"{args.output}/{args.instance.replace(' ', '_')}"
                        os.makedirs(instance_folder, exist_ok=True)
                        pbar.set_description(f"{args.instance} - Overview")
                        output_file = f"{instance_folder}/dashboard.html"
                        dashboard_path = generate_html_dashboard(output_file, None, args.instance, metrics, cache, use_cache, args.days)
                        generated_files.append((f"{args.instance} - All Projects", dashboard_path))
                        pbar.update(1)
                        
                        # Generate project-level dashboards
                        if not projects.empty:
                            for idx, project in enumerate(projects['project_name'], 1):
                                pbar.set_description(f"{args.instance} - {project}")
                                pbar.set_postfix_str(f"{idx}/{len(projects)}")
                                metrics_proj = multi_metrics.get_metrics_for_instance(args.instance, project)
                                output_file = f"{instance_folder}/dashboard_{project.replace(' ', '_')}.html"
                                dashboard_path = generate_html_dashboard(output_file, project, args.instance, metrics_proj, cache, use_cache, args.days)
                                generated_files.append((f"{args.instance} - {project}", dashboard_path))
                                pbar.update(1)
                    
            else:
                # ALL INSTANCES MODE (AUTO-AGGREGATED)
                if args.project:
                    # All instances filtered by specific project
                    tqdm.write(f"\nGenerating dashboards for all instances, project: {args.project}")
                    tqdm.write(f"  Total instances: {len(instance_names)}")
                    
                    with tqdm(total=len(instance_names), desc="Instances", unit="instance") as pbar:
                        for idx, instance_name in enumerate(instance_names, 1):
                            pbar.set_description(f"Instance {idx}/{len(instance_names)}: {instance_name}")
                            metrics = multi_metrics.get_metrics_for_instance(instance_name, args.project)
                            instance_folder = f"{args.output}/{instance_name.replace(' ', '_')}"
                            os.makedirs(instance_folder, exist_ok=True)
                            output_file = f"{instance_folder}/dashboard_{args.project.replace(' ', '_')}.html"
                            dashboard_path = generate_html_dashboard(output_file, args.project, instance_name, metrics, cache, use_cache, args.days)
                            generated_files.append((f"{instance_name} - {args.project}", dashboard_path))
                            pbar.update(1)
                else:
                    # All instances + all projects (FULL AUTO MODE)
                    # Calculate total work for progress tracking
                    tqdm.write("\nCalculating total work for progress tracking...")
                    total_work_items = 1  # Aggregated dashboard
                    total_work_items += len(instance_names)  # Instance-level dashboards
                    
                    # Count projects per instance for accurate progress
                    instance_project_counts = {}
                    for instance_name in instance_names:
                        metrics_temp = multi_metrics.get_metrics_for_instance(instance_name)
                        projects_temp = metrics_temp.get_available_projects()
                        project_count = len(projects_temp) if not projects_temp.empty else 0
                        instance_project_counts[instance_name] = project_count
                        total_work_items += project_count
                    
                    tqdm.write(f"  Total dashboards to generate: {total_work_items}")
                    tqdm.write(f"  - 1 aggregated dashboard")
                    tqdm.write(f"  - {len(instance_names)} instance dashboards")
                    tqdm.write(f"  - {sum(instance_project_counts.values())} project dashboards")
                    
                    # Create overall progress bar
                    with tqdm(total=total_work_items, desc="Overall Progress", unit="dashboard", position=0) as pbar_overall:
                        # Generate aggregated dashboard
                        tqdm.write("\nGenerating aggregated dashboard across all instances...")
                        os.makedirs(args.output, exist_ok=True)
                        output_file = f"{args.output}/dashboard_aggregated.html"
                        dashboard_path = generate_aggregated_dashboard(multi_metrics, output_file, args.days)
                        generated_files.append(("Aggregated View", dashboard_path))
                        pbar_overall.update(1)
                        
                        # Also generate instance-level dashboards for navigation
                        tqdm.write("\nGenerating instance-level dashboards for navigation...")
                        for idx, instance_name in enumerate(instance_names, 1):
                            pbar_overall.set_description(f"Instance {idx}/{len(instance_names)}: {instance_name}")
                            metrics = multi_metrics.get_metrics_for_instance(instance_name)
                            instance_folder = f"{args.output}/{instance_name.replace(' ', '_')}"
                            os.makedirs(instance_folder, exist_ok=True)
                            output_file = f"{instance_folder}/dashboard.html"
                            dashboard_path = generate_html_dashboard(output_file, None, instance_name, metrics, cache, use_cache, args.days)
                            generated_files.append((instance_name, dashboard_path))
                            pbar_overall.update(1)
                        
                        tqdm.write(f"\n[OK] Generated aggregated view + {len(instance_names)} instance dashboards")
                        
                        # Auto-generate project-level dashboards for each instance
                        tqdm.write("\nGenerating project-level dashboards for all instances...")
                        total_projects = 0
                        for idx, instance_name in enumerate(instance_names, 1):
                            metrics = multi_metrics.get_metrics_for_instance(instance_name)
                            projects = metrics.get_available_projects()
                            
                            if not projects.empty:
                                pbar_overall.set_description(f"Instance {idx}/{len(instance_names)}: {instance_name} projects")
                                for proj_idx, project in enumerate(projects['project_name'], 1):
                                    pbar_overall.set_postfix_str(f"{project} ({proj_idx}/{len(projects)})")
                                    metrics_proj = multi_metrics.get_metrics_for_instance(instance_name, project)
                                    instance_folder = f"{args.output}/{instance_name.replace(' ', '_')}"
                                    os.makedirs(instance_folder, exist_ok=True)
                                    output_file = f"{instance_folder}/dashboard_{project.replace(' ', '_')}.html"
                                    dashboard_path = generate_html_dashboard(output_file, project, instance_name, metrics_proj, cache, use_cache, args.days)
                                    generated_files.append((f"{instance_name} - {project}", dashboard_path))
                                    total_projects += 1
                                    pbar_overall.update(1)
                        
                        pbar_overall.set_description("Complete")
                        pbar_overall.set_postfix_str("")
                    
                    tqdm.write(f"\n[OK] Generated {total_projects} project-level dashboards across {len(instance_names)} instances")
                
            # Summary and completion
            tqdm.write("\n" + "=" * 80)
            tqdm.write(f"[SUCCESS] Generated {len(generated_files)} dashboards!")
            tqdm.write("=" * 80)
            
            if generated_files and not args.no_browser:
                tqdm.write("\nOpening aggregated dashboard in browser...")
                webbrowser.open('file://' + os.path.abspath(generated_files[0][1]))
            
            tqdm.write("\n" + "=" * 80)
            tqdm.write("Dashboard generation completed successfully!")
            tqdm.write("=" * 80 + "\n")
            return

        
        # ========================================================================
        # SINGLE-INSTANCE MODE
        # ========================================================================
        # For single-instance mode, we still generate aggregated dashboard for consistency
        from coverity_metrics.multi_instance_metrics import MultiInstanceMetrics
        
        # Read first enabled instance from config.json
        connection_params = None
        instance_name = None
        if config_data and config_data.get('instances'):
            enabled_instances = [inst for inst in config_data['instances'] if inst.get('enabled', True)]
            if enabled_instances:
                first_instance = enabled_instances[0]
                connection_params = {
                    'host': first_instance['database']['host'],
                    'port': first_instance['database']['port'],
                    'database': first_instance['database']['database'],
                    'user': first_instance['database']['user'],
                    'password': first_instance['database']['password']
                }
                instance_name = first_instance['name']
                tqdm.write(f"  Using instance: {instance_name}")
        
        if not connection_params:
            tqdm.write("\n[ERROR] No database configuration found in config.json")
            tqdm.write("Please configure at least one instance in config.json")
            sys.exit(1)
        
        # Create metrics instance with connection params from config.json
        metrics = CoverityMetrics(connection_params=connection_params)
        
        # Use same folder structure as multi-instance mode
        generated_files = []
        
        if args.project:
            # Specific project only
            tqdm.write(f"\nGenerating dashboard for project: {args.project}")
            instance_folder = f"{args.output}/{instance_name.replace(' ', '_')}"
            os.makedirs(instance_folder, exist_ok=True)
            output_file = f"{instance_folder}/dashboard_{args.project.replace(' ', '_')}.html"
            dashboard_path = generate_html_dashboard(output_file, args.project, instance_name, metrics, cache, use_cache, args.days)
            generated_files.append((f"{instance_name} - {args.project}", dashboard_path))
        else:
            # All projects (AUTO MODE) - same as multi-instance
            tqdm.write(f"\nGenerating all dashboards for instance: {instance_name}")
            projects = metrics.get_available_projects()
            
            # Calculate total work: aggregated + instance + projects
            total_dashboards = 1 + 1 + (len(projects) if not projects.empty else 0)  # 1 aggregated + 1 instance + N projects
            tqdm.write(f"  Total dashboards to generate: {total_dashboards} (1 aggregated + 1 instance + {len(projects) if not projects.empty else 0} projects)")
            
            with tqdm(total=total_dashboards, desc=f"{instance_name}", unit="dashboard") as pbar:
                # Generate aggregated dashboard (even for single instance, for consistency)
                pbar.set_description("Aggregated View")
                multi_metrics = MultiInstanceMetrics(args.config)
                os.makedirs(args.output, exist_ok=True)
                output_file = f"{args.output}/dashboard_aggregated.html"
                dashboard_path = generate_aggregated_dashboard(multi_metrics, output_file, args.days)
                generated_files.append(("Aggregated View", dashboard_path))
                pbar.update(1)
                
                # Generate instance-level dashboard (all projects)
                instance_folder = f"{args.output}/{instance_name.replace(' ', '_')}"
                os.makedirs(instance_folder, exist_ok=True)
                pbar.set_description(f"{instance_name} - Overview")
                output_file = f"{instance_folder}/dashboard.html"
                dashboard_path = generate_html_dashboard(output_file, None, instance_name, metrics, cache, use_cache, args.days)
                generated_files.append((f"{instance_name} - All Projects", dashboard_path))
                pbar.update(1)
                
                # Generate project-level dashboards
                if not projects.empty:
                    for idx, project in enumerate(projects['project_name'], 1):
                        pbar.set_description(f"{instance_name} - {project}")
                        pbar.set_postfix_str(f"{idx}/{len(projects)}")
                        # Create a new metrics instance with project filter
                        metrics_proj = CoverityMetrics(connection_params=connection_params, project_name=project)
                        output_file = f"{instance_folder}/dashboard_{project.replace(' ', '_')}.html"
                        dashboard_path = generate_html_dashboard(output_file, project, instance_name, metrics_proj, cache, use_cache, args.days)
                        generated_files.append((f"{instance_name} - {project}", dashboard_path))
                        pbar.update(1)
        
        # Summary and completion
        tqdm.write("\n" + "=" * 80)
        tqdm.write(f"[SUCCESS] Generated {len(generated_files)} dashboard(s)!")
        tqdm.write("=" * 80)
        
        if generated_files and not args.no_browser:
            tqdm.write("\nOpening dashboard in default browser...")
            webbrowser.open('file://' + os.path.abspath(generated_files[0][1]))
            tqdm.write("[OK] Dashboard opened")
        
        tqdm.write("\n" + "=" * 80)
        tqdm.write("Dashboard generation completed successfully!")
        tqdm.write("=" * 80 + "\n")
        
    except Exception as e:
        tqdm.write(f"\n[ERROR] Failed to generate dashboard")
        tqdm.write(f"  {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    import time
    start_time = time.time()
    main()
    end_time = time.time()
    elapsed = end_time - start_time
    mins, secs = divmod(int(elapsed), 60)
    print(f"\nTotal execution time: {mins} min {secs} sec ({elapsed:.2f} seconds)")
