"""Tests for location tools."""

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from platform_2step_mcp.tools.locations import (
    LOCATION_TOOLS,
    handle_location_tool,
)


class TestLocationTools:
    """Tests for location tool definitions."""

    def test_location_tools_count(self):
        """Test that all location tools are defined."""
        assert len(LOCATION_TOOLS) == 2

    def test_list_locations_tool_defined(self):
        """Test list_locations tool is properly defined."""
        tool = next((t for t in LOCATION_TOOLS if t.name == "list_locations"), None)
        assert tool is not None
        assert "company_id" in tool.inputSchema["required"]

    def test_get_location_tool_defined(self):
        """Test get_location tool is properly defined."""
        tool = next((t for t in LOCATION_TOOLS if t.name == "get_location"), None)
        assert tool is not None
        assert "location_id" in tool.inputSchema["required"]
        # company_id is no longer required for get_location (inferred from resource)
        assert "company_id" not in tool.inputSchema["required"]


class TestHandleLocationTool:
    """Tests for handle_location_tool."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock Platform2StepClient."""
        client = MagicMock()
        client.list_locations = AsyncMock()
        client.get_location = AsyncMock()
        return client

    async def test_list_locations(self, mock_client):
        """Test list_locations tool handler."""
        mock_client.list_locations.return_value = {
            "data": [
                {"id": 1, "name": "Main Office"},
                {"id": 2, "name": "Branch Office"},
            ]
        }

        result = await handle_location_tool(
            "list_locations",
            {"company_id": 1238},
            mock_client,
        )

        assert len(result) == 1
        assert result[0].type == "text"
        data = json.loads(result[0].text)
        assert len(data["data"]) == 2
        mock_client.list_locations.assert_called_once_with(
            company_id=1238,
            page=1,
            per_page=25,
        )

    async def test_list_locations_with_pagination(self, mock_client):
        """Test list_locations tool handler with pagination."""
        mock_client.list_locations.return_value = {"data": []}

        await handle_location_tool(
            "list_locations",
            {"company_id": 1238, "page": 2, "per_page": 10},
            mock_client,
        )

        mock_client.list_locations.assert_called_once_with(
            company_id=1238,
            page=2,
            per_page=10,
        )

    async def test_get_location(self, mock_client):
        """Test get_location tool handler."""
        mock_client.get_location.return_value = {
            "id": 123,
            "name": "Main Office",
            "address": "123 Main St",
        }

        result = await handle_location_tool(
            "get_location",
            {"location_id": 123},
            mock_client,
        )

        assert len(result) == 1
        data = json.loads(result[0].text)
        assert data["id"] == 123
        assert data["name"] == "Main Office"
        mock_client.get_location.assert_called_once_with(
            location_id=123,
        )

    async def test_unknown_tool_raises_error(self, mock_client):
        """Test that unknown tool raises ValueError."""
        with pytest.raises(ValueError, match="Unknown location tool"):
            await handle_location_tool(
                "unknown_tool",
                {},
                mock_client,
            )
