"""Authentication exceptions for Platform-MCP."""


class AuthError(Exception):
    """Base authentication error."""

    def __init__(self, message: str, error_code: str | None = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code


class TokenExpiredError(AuthError):
    """Token has expired."""

    def __init__(self, message: str = "Access token has expired"):
        super().__init__(message, error_code="token_expired")


class RefreshError(AuthError):
    """Token refresh failed."""

    def __init__(self, message: str = "Failed to refresh token"):
        super().__init__(message, error_code="refresh_failed")


class DeviceFlowExpiredError(AuthError):
    """Device authorization code has expired."""

    def __init__(self, message: str = "Device code has expired. Please try again."):
        super().__init__(message, error_code="expired_token")


class DeviceFlowDeniedError(AuthError):
    """User denied the device authorization request."""

    def __init__(self, message: str = "Authorization denied by user."):
        super().__init__(message, error_code="access_denied")


class DeviceFlowTimeoutError(AuthError):
    """Device flow polling timed out."""

    def __init__(self, message: str = "Authentication timed out."):
        super().__init__(message, error_code="timeout")


class InvalidTokenError(AuthError):
    """Token is invalid or malformed."""

    def __init__(self, message: str = "Token is invalid"):
        super().__init__(message, error_code="invalid_token")


class InsufficientScopeError(AuthError):
    """Token lacks required scope."""

    def __init__(self, message: str = "Insufficient permissions"):
        super().__init__(message, error_code="insufficient_scope")


class InvalidCompletionCodeError(AuthError):
    """Completion code is invalid or malformed."""

    def __init__(self, message: str = "Invalid completion code"):
        super().__init__(message, error_code="invalid_grant")


class SessionNotFoundError(AuthError):
    """Session not found."""

    def __init__(self, session_id: str):
        super().__init__(f"Session {session_id} not found", error_code="not_found")
        self.session_id = session_id


class SessionRevocationForbiddenError(AuthError):
    """Cannot revoke another user's session."""

    def __init__(self, message: str = "Cannot revoke another user's session"):
        super().__init__(message, error_code="forbidden")
