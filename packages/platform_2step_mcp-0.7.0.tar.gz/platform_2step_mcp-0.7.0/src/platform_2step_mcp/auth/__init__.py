"""Authentication module for Platform-MCP.

This module implements OAuth 2.0 Device Authorization Grant (RFC 8628)
for authenticating MCP clients through the Platform-2Steps BFF.

Example usage:
    from platform_2step_mcp.auth import AuthClient

    # Initialize auth client
    auth = AuthClient(bff_url="https://ap-api.agendaprodev.com/platform-2steps-bff")

    # Authenticate (will prompt user if needed)
    auth.authenticate()

    # Get valid access token
    token = auth.get_valid_token()
"""

from .client import AuthClient
from .exceptions import (
    AuthError,
    DeviceFlowDeniedError,
    DeviceFlowExpiredError,
    DeviceFlowTimeoutError,
    InsufficientScopeError,
    InvalidCompletionCodeError,
    InvalidTokenError,
    RefreshError,
    SessionNotFoundError,
    SessionRevocationForbiddenError,
    TokenExpiredError,
)
from .models import DeviceAuthResponse, TokenData, TokenResponse
from .storage import TokenStorage

__all__ = [
    # Client
    "AuthClient",
    # Storage
    "TokenStorage",
    # Models
    "TokenData",
    "TokenResponse",
    "DeviceAuthResponse",
    # Exceptions
    "AuthError",
    "TokenExpiredError",
    "RefreshError",
    "DeviceFlowExpiredError",
    "DeviceFlowDeniedError",
    "DeviceFlowTimeoutError",
    "InvalidTokenError",
    "InsufficientScopeError",
    "InvalidCompletionCodeError",
    "SessionNotFoundError",
    "SessionRevocationForbiddenError",
]
