"""Configuration module using Pydantic Settings."""

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables.

    Uses device flow authentication via PLATFORM_2STEPS_BFF_URL.
    The BFF handles both authentication and API requests.
    """

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=True,
    )

    PLATFORM_2STEPS_BFF_URL: str | None = None
    """Base URL for Platform-2Steps BFF (e.g., https://ap-api.agendaprodev.com/platform-2steps-bff).

    This URL is used for BOTH authentication AND API requests,
    as the BFF proxies all /api/v1/* requests to the backend.
    """

    PLATFORM_MCP_TOKEN_PATH: str = "~/.platform-mcp/tokens.json"
    """Path to store auth tokens. Use different paths for staging vs production."""

    LOG_LEVEL: str = "INFO"
    """Logging level (DEBUG, INFO, WARNING, ERROR)."""

    DEBUG_HTTP: bool = False
    """Enable detailed HTTP logging with cURL-style request/response output.

    When enabled, all HTTP requests and responses are logged in a format similar to:
    curl -X GET 'https://api.example.com/path' -H 'Header: value' --data '{...}'

    Set to true via environment variable: DEBUG_HTTP=true
    """

    @property
    def api_url(self) -> str:
        """Get the API base URL.

        Returns:
            The configured BFF URL

        Raises:
            ValueError: If PLATFORM_2STEPS_BFF_URL is not configured
        """
        if not self.PLATFORM_2STEPS_BFF_URL:
            raise ValueError(
                "PLATFORM_2STEPS_BFF_URL is required. "
                "Set this environment variable to use device flow authentication."
            )
        return self.PLATFORM_2STEPS_BFF_URL

    @property
    def bff_url(self) -> str:
        """Get the BFF URL for device flow authentication.

        Returns:
            The BFF URL

        Raises:
            ValueError: If PLATFORM_2STEPS_BFF_URL is not configured
        """
        if not self.PLATFORM_2STEPS_BFF_URL:
            raise ValueError(
                "PLATFORM_2STEPS_BFF_URL is required. "
                "Set this environment variable to use device flow authentication."
            )
        return self.PLATFORM_2STEPS_BFF_URL

    @model_validator(mode="after")
    def validate_config(self) -> "Settings":
        """Validate that required configuration is present."""
        if not self.PLATFORM_2STEPS_BFF_URL:
            raise ValueError(
                "PLATFORM_2STEPS_BFF_URL is required. "
                "Set this environment variable to configure the Platform-2Steps BFF URL."
            )
        return self


def get_settings() -> Settings:
    """Load and return application settings from environment."""
    return Settings()
