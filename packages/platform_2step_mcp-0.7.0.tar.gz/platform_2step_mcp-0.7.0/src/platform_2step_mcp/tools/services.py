"""Service tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

SERVICE_TOOLS: list[Tool] = [
    Tool(
        name="list_services",
        description="List services for a company, optionally filtered by category.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID",
                },
                "service_category_id": {
                    "type": "integer",
                    "description": "Filter by service category ID (optional)",
                },
                "active": {
                    "type": "boolean",
                    "description": "Filter by active/inactive status (optional)",
                },
                "page": {
                    "type": "integer",
                    "description": "Page number (default 1)",
                },
                "per_page": {
                    "type": "integer",
                    "description": "Results per page (default 25, max 100)",
                },
            },
            "required": ["company_id"],
        },
    ),
    Tool(
        name="get_service",
        description="Get details of a specific service.",
        inputSchema={
            "type": "object",
            "properties": {
                "service_id": {
                    "type": "integer",
                    "description": "Service ID",
                },
            },
            "required": ["service_id"],
        },
    ),
]


async def handle_service_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle service tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "list_services":
        result = await client.list_services(
            company_id=arguments["company_id"],
            service_category_id=arguments.get("service_category_id"),
            active=arguments.get("active"),
            page=arguments.get("page", 1),
            per_page=arguments.get("per_page", 25),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "get_service":
        result = await client.get_service(
            service_id=arguments["service_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown service tool: {name}")
