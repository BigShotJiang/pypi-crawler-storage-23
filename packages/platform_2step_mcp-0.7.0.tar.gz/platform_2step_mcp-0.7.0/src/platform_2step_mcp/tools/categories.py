"""Category tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

CATEGORY_TOOLS: list[Tool] = [
    Tool(
        name="list_categories",
        description="List service categories for a company. Returns all active categories with their IDs, names, order, and service counts.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID to list categories for",
                },
                "page": {
                    "type": "integer",
                    "description": "Page number (default 1)",
                },
                "per_page": {
                    "type": "integer",
                    "description": "Results per page (default 25, max 100)",
                },
            },
            "required": ["company_id"],
        },
    ),
    Tool(
        name="list_services_by_category",
        description="List all services grouped by category. Useful for building service menus or catalogs.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID",
                },
                "active": {
                    "type": "boolean",
                    "description": "Filter services by active/inactive status (optional)",
                },
            },
            "required": ["company_id"],
        },
    ),
    Tool(
        name="get_category",
        description="Get details of a specific category.",
        inputSchema={
            "type": "object",
            "properties": {
                "category_id": {
                    "type": "integer",
                    "description": "Category ID",
                },
            },
            "required": ["category_id"],
        },
    ),
]


async def handle_category_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle category tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "list_categories":
        result = await client.list_categories(
            company_id=arguments["company_id"],
            page=arguments.get("page", 1),
            per_page=arguments.get("per_page", 25),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "list_services_by_category":
        result = await client.list_services_by_category(
            company_id=arguments["company_id"],
            active=arguments.get("active"),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "get_category":
        result = await client.get_category(
            category_id=arguments["category_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown category tool: {name}")
