"""Location tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

LOCATION_TOOLS: list[Tool] = [
    Tool(
        name="list_locations",
        description="List locations for a company. Returns all locations with their IDs, names, and details.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID to list locations for",
                },
                "page": {
                    "type": "integer",
                    "description": "Page number (default 1)",
                },
                "per_page": {
                    "type": "integer",
                    "description": "Results per page (default 25, max 100)",
                },
            },
            "required": ["company_id"],
        },
    ),
    Tool(
        name="get_location",
        description="Get details of a specific location.",
        inputSchema={
            "type": "object",
            "properties": {
                "location_id": {
                    "type": "integer",
                    "description": "Location ID",
                },
            },
            "required": ["location_id"],
        },
    ),
]


async def handle_location_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle location tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "list_locations":
        result = await client.list_locations(
            company_id=arguments["company_id"],
            page=arguments.get("page", 1),
            per_page=arguments.get("per_page", 25),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "get_location":
        result = await client.get_location(
            location_id=arguments["location_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown location tool: {name}")
