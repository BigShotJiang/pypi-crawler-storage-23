"""User tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

USER_TOOLS: list[Tool] = [
    Tool(
        name="get_user",
        description="""Get details of a specific user by ID.

Note: Users are cross-company entities, so no company ownership validation is performed.
The company_id is still required for request tracking.""",
        inputSchema={
            "type": "object",
            "properties": {
                "user_id": {
                    "type": "integer",
                    "description": "User ID",
                },
                "company_id": {
                    "type": "integer",
                    "description": "Company ID (required for request tracking)",
                },
            },
            "required": ["user_id", "company_id"],
        },
    ),
]


async def handle_user_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle user tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "get_user":
        result = await client.get_user(
            user_id=arguments["user_id"],
            company_id=arguments["company_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown user tool: {name}")
