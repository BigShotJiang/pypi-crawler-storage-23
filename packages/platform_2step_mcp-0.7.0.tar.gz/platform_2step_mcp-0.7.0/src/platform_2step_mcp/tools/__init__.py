"""MCP Tools for Platform-2Step."""

from .analytics import ANALYTICS_TOOLS, handle_analytics_tool
from .batches import BATCH_TOOLS, handle_batch_tool
from .bookings import BOOKING_TOOLS, handle_booking_tool
from .categories import CATEGORY_TOOLS, handle_category_tool
from .locations import LOCATION_TOOLS, handle_location_tool
from .memberships import MEMBERSHIP_TOOLS, handle_membership_tool
from .providers import PROVIDER_TOOLS, handle_provider_tool
from .services import SERVICE_TOOLS, handle_service_tool
from .users import USER_TOOLS, handle_user_tool

__all__ = [
    "ANALYTICS_TOOLS",
    "handle_analytics_tool",
    "CATEGORY_TOOLS",
    "handle_category_tool",
    "SERVICE_TOOLS",
    "handle_service_tool",
    "BOOKING_TOOLS",
    "handle_booking_tool",
    "LOCATION_TOOLS",
    "handle_location_tool",
    "MEMBERSHIP_TOOLS",
    "handle_membership_tool",
    "PROVIDER_TOOLS",
    "handle_provider_tool",
    "USER_TOOLS",
    "handle_user_tool",
    "BATCH_TOOLS",
    "handle_batch_tool",
]
