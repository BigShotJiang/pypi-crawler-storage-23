---
type: decision
status: draft # draft | final | superseded | reversed
confidence: high # low | medium | high
source: "" # who/what triggered the decision
source_date:
project: [] # [[project links]]
decided_by: [] # [[person links]]
approved_by: [] # [[person links — authority chain]]
based_on: [] # [[assumptions/evidence this rests on]]
supports: [] # [[what this decision enables]]
challenged_by: [] # [[evidence that questions this]]
session: # [[session where decided]]
related: []
created: "{{date}}"
tags: []
---

# {{title}}

## Context

<!-- Why this decision needed to be made -->

## Options Considered

1. **Option A** — description
2. **Option B** — description

## Decision

<!-- What was decided and why -->

## Rationale

<!-- The reasoning chain — what assumptions and evidence led here -->

## Consequences

<!-- What follows from this decision -->

![[learn-decision.base#Based On]]
![[learn-decision.base#Related]]
