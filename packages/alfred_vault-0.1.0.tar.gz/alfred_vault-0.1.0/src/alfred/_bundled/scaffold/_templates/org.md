---
type: org
status: active # active | inactive
name:
description:
org_type: # e.g. client | vendor | partner | legal | government | internal
website:
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

## People
![[org.base#People]]

## Projects
![[org.base#Projects]]

## Tasks
![[org.base#Tasks]]

## Accounts
![[org.base#Accounts]]

## Assets
![[org.base#Assets]]

## Notes
![[org.base#Notes]]
