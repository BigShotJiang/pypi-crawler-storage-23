---
type: synthesis
status: draft # draft | active | superseded
confidence: medium # low | medium | high
cluster_sources: [] # [[entities that contributed to this insight]]
project: [] # [[project links]]
supports: [] # [[decisions/assumptions this strengthens]]
related: []
created: "{{date}}"
tags: []
---

# {{title}}

## Insight

<!-- The synthesised finding — what pattern or conclusion emerged -->

## Evidence

<!-- What records/observations led to this synthesis -->

## Implications

<!-- What should change based on this insight? -->

## Applicability

<!-- Which projects, people, or contexts does this apply to? -->

![[learn-synthesis.base#Sources]]
![[learn-synthesis.base#Related]]
