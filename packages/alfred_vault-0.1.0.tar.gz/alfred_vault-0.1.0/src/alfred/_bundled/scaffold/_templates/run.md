---
type: run
status: active # active | completed | blocked | cancelled
name:
description:
process: # Link to Process (required)
project: # Link to Project
trigger: # What started this run (link or description)
current_step:
started:
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

Execution of [[Process]].

## Tasks
![[run.base#Tasks]]

## Related
![[related.base#All]]
