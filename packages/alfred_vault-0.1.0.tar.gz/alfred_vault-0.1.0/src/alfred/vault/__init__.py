"""Vault operations layer — mediated file access for AI agents."""
