"""Vault quality sweeper — structural scanning + agent-backed semantic fixes."""
