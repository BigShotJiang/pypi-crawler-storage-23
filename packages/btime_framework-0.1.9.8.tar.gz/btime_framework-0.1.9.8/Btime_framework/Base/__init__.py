"""Btime_framework package.

Resumo
-------
Pacote principal do Btime Framework.
Contém o subpacote `Base` com utilitários de RPA, file management, decorators e automação.

Versão
------
0.1.9.2

Instalação
---------
pip install --upgrade Btime_framework

Uso
---
Exemplo mínimo (Google/doctest style):

>>> import Btime_framework as bt
>>> bt.Base.decorators.rpa_retry(max_attempts=3, delay=5)
>>> bt.Base.file_manager.clean_directory(path=r"C:\Program Files\PATH", older_than_days=5)
>>> bt.Base.automation_with_image_recognition.click(coord_x=750, coord_y=400, double_click=True)

Atenção
-------
- O CLI ainda não detecta dependências dos módulos da `Base` automaticamente.
  Instale manualmente as dependências necessárias até a integração completa.

Autor
-----
bt (Btime)

"""