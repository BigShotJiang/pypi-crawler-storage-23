---
description: "Persistent self-referential loop until verification passes"
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/ralph/SKILL.md` using the Read tool and follow its instructions exactly.
