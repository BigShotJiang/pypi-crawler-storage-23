---
description: "Execute a Seed specification through the workflow engine"
aliases: [execute]
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/run/SKILL.md` using the Read tool and follow its instructions exactly.
