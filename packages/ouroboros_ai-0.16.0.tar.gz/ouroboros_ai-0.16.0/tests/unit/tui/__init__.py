"""Unit tests for the TUI module."""
