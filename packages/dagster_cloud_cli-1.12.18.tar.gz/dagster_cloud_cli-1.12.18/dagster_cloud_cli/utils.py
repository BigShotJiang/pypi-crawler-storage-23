import collections
import functools
import inspect
import math
import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from typer import Typer
    from typer.models import OptionInfo


DEFAULT_PYTHON_VERSION = "3.11"

SUPPORTED_PYTHON_VERSIONS = ["3.9", "3.10", "3.11", "3.12", "3.13", "3.14"]


def create_stub_app(package_name: str) -> "Typer":
    import typer

    return typer.Typer(
        help=f"This command is not available unless you install the {package_name} package.",
        hidden=True,
    )


def create_stub_command(package_name: str):
    from dagster_cloud_cli import ui

    def fn():
        ui.print(f"This command is not available unless you install the {package_name} package.")

    return fn


def with_added_params(
    signature: inspect.Signature, to_add: dict[str, inspect.Parameter]
) -> inspect.Signature:
    """Returns a new signature based on the provided one, with the provided parameters added."""
    params = collections.OrderedDict(signature.parameters)
    for k, v in to_add.items():
        params[k] = v
    return signature.replace(parameters=list(params.values()))


def without_params(signature: inspect.Signature, to_remove: list[str]) -> inspect.Signature:
    """Returns a new signature based on the provided one with the given parameters removed by name.
    Does nothing if the parameter is not found.
    """
    params = collections.OrderedDict(signature.parameters)
    for r in to_remove:
        if r in params:
            del params[r]
    return signature.replace(parameters=list(params.values()))


def add_options(options: dict[str, tuple[Any, "OptionInfo"]]):
    """Decorator to add Options to a particular command."""

    def decorator(to_wrap):
        # Ensure that the function signature has the correct typer.Option defaults,
        # so that every command need not specify them

        # Remove kwargs, since Typer doesn't know how to handle it
        to_wrap_sig = inspect.signature(to_wrap)
        has_kwargs = "kwargs" in to_wrap_sig.parameters
        sig = without_params(to_wrap_sig, ["kwargs"])
        sig = with_added_params(
            sig,
            {
                name: inspect.Parameter(
                    name,
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    annotation=_type,
                    default=default,
                )
                for name, (_type, default) in options.items()
            },
        )

        @functools.wraps(to_wrap)
        def wrap_function(*args, **kwargs):
            modified_kwargs = kwargs
            if not has_kwargs and not hasattr(to_wrap, "modified_options"):
                modified_kwargs: dict[Any, Any] = {
                    k: v for k, v in kwargs.items() if k in to_wrap_sig.parameters
                }
            return to_wrap(*args, **modified_kwargs)

        wrap_function.__signature__ = sig  # pyright: ignore[reportAttributeAccessIssue]
        wrap_function.modified_options = True  # pyright: ignore[reportAttributeAccessIssue]
        return wrap_function

    return decorator


def get_file_size(path) -> str:
    size = os.path.getsize(path)
    if size == 0:
        return "0 bytes"
    units = ["bytes", "KB", "MB", "GB"]
    magnitude = math.floor(math.log(size, 1024))
    magnitude = min([len(units) - 1, magnitude])

    unit = units[magnitude]
    value = size // (1024**magnitude)
    return f"{value} {unit}"
