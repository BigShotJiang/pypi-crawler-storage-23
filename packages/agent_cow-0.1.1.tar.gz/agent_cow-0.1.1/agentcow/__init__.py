"""agent-cow: Database Copy-On-Write for AI agent workspace isolation."""

__version__ = "0.1.1"
