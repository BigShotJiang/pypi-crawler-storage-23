from dataclasses import dataclass


@dataclass
class ActivityIDInstance:
    activity_id: str
    milestone_field_name: str
    milestone_object_type: str
    sitetracker_instance_id: str