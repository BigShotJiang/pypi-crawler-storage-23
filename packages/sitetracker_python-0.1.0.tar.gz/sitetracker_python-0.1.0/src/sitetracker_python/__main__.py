import os
from functools import lru_cache
from html import escape
from typing import Any, Dict, List, Optional, Tuple, Union
from xml.parsers.expat import ExpatError

import pandas as pd
import requests
from dotenv import load_dotenv

from .exceptions import (
    ExpiredSitetrackerPassword,
    FieldDoesNotExist,
    MissingEnvironmentVariable,
    ObjectDoesNotExist,
    SalesForceVersionError,
)
from .models import ActivityIDInstance
from .utils import getUniqueElementValueFromXmlString


class SiteTracker:
    def __init__(self, sandbox: bool = True, sf_version: str = "60.0") -> None:
        """
        Initialise le wrapper et se connecte à Salesforce.
        Après avoir créé une instance, la session est prête à effectuer des requêtes.

        Arguments :
            sandbox -- Un booléen pour déterminer si l'on se connecte à un environnement de test ou de production. Par défaut, c'est True, environnement de test.
            sf_version -- La version de l'API Salesforce à utiliser. Par défaut, c'est '60.0', qui est la version Spring '24.
                          Pour vérifier la version, GET /services/data/ dans Salesforce.
                          Par exemple, nous pouvons obtenir la notre à https://YOUR_SITETRACKER_INSTANCE.sandbox.my.salesforce.com/services/data/


        ⚠️ Important

        Salesforce détermine automatiquement l'environnement de test ou de production.
        Cela est fait en fonction des informations d'identification utilisées pour se connecter.

        Si je fournis des identifiants relatifs à un environnement de staging, il suffit
        simplement de définir `sandbox=True` lors de l'initialisation du wrapper et
        de fournir dans le .env les variables d'environnement correspondant à cet environnement.

        Si je veux me connecter à l'environnement de production, les noms des variables
        d'environnement ne changent pas, mais les valeurs doivent être celles relatives à la production.

        Documentation et référence API :
        https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/quickstart.htm
        https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/resources_list.htm
        """

        if not isinstance(sandbox, bool):
            raise ValueError("La valeur de sandbox doit être un booléen.")

        if not isinstance(sf_version, str) or "v" in sf_version.lower():
            raise SalesForceVersionError(
                "La version de Salesforce doit être une chaîne de caractères et ne doit pas contenir 'v'."
            )

        self.sf_version = sf_version
        self.session = requests.Session()
        self.domain = "test" if sandbox is True else "login"

        # Charger les variables d'environnement du fichier .env
        load_dotenv()

        # Obtenir toutes les variables d'environnement nécessaires en utilisant l'unpacking
        (
            __USER_EMAIL,
            __USER_PASSWORD,
            __SECURITY_TOKEN,
        ) = self.__check_and_get_env_variables(sandbox=sandbox)

        # Connexion à Salesforce pour initialiser la session
        self.session_id, self.sf_instance = self.__salesforceLogin(
            username=__USER_EMAIL,
            password=__USER_PASSWORD,
            security_token=__SECURITY_TOKEN,
            domain=self.domain,
        )

        # Après la connexion je peux définir mon BASE_URL
        self.BASE_URL = f"https://{self.sf_instance}/services/data/v{self.sf_version}"

        # Et mes headers
        self.headers = {
            "Authorization": f"Bearer {self.session_id}",
            "Content-Type": "application/json",
        }

        self.session.headers.update(self.headers)

        # J'utilise un cache pour limiter les appels à l'API
        # lors de la création de plusieurs enregistrements du même objet
        self.last_object_name = None
        self.last_object_fields = {}
        self.last_objects_list = None

        # On appelle la méthode get_objects() lors de l'__init__()
        # pour vérifier si le mot de passe Sitetracker n'a pas expiré
        # et si les requêtes fonctionnent correctement
        self.get_objects(limit=1)

    ################### AUTHENTICATION ###################

    def __check_and_get_env_variables(
        self, sandbox: bool
    ) -> Union[Tuple[str, str, str], ValueError]:
        """
        Cette fonction vérifie et retourne les variables d'environnement nécessaires.

        Raises:
            ValueError: Si les variables d'environnement ne sont pas définies.

        Returns:
            Tuple[str, str, str] -- Un tuple contenant les variables d'environnement nécessaires.
        """
        __USER_EMAIL = (
            os.getenv("SANDBOX_USER_EMAIL")
            if sandbox is True
            else os.getenv("PRODUCTION_USER_EMAIL")
        )
        __USER_PASSWORD = (
            os.getenv("SANDBOX_USER_PASSWORD")
            if sandbox is True
            else os.getenv("PRODUCTION_USER_PASSWORD")
        )
        __SECURITY_TOKEN = (
            os.getenv("SANDBOX_SECURITY_TOKEN")
            if sandbox is True
            else os.getenv("PRODUCTION_SECURITY_TOKEN")
        )

        mapping = {
            "USER_EMAIL": __USER_EMAIL,
            "USER_PASSWORD": __USER_PASSWORD,
            "SECURITY_TOKEN": __SECURITY_TOKEN,
        }

        for key, value in mapping.items():
            if value is None:
                raise MissingEnvironmentVariable(
                    f"La variable d'environnement \"{key}\" n'est pas définie.\n"
                    "Merci de définir toutes les variables d'environnement nécessaires. Pour l'adresse email, une seule doit être définie, en fonction de l'environnement."
                )

        return (
            __USER_EMAIL,
            __USER_PASSWORD,
            __SECURITY_TOKEN,
        )

    def __salesforceLogin(
        self,
        username: str,
        password: str,
        security_token: str,
        domain: Optional[str] = None,
    ) -> Tuple[str, str]:
        """
        Retourne un tuple `(session_id, sf_instance)` où `session_id` est l'identifiant
        de session à utiliser pour l'authentification à Salesforce et `sf_instance` est
        le domaine de l'instance de Salesforce à utiliser pour la session.

        Arguments :

        * username -- le nom d'utilisateur Salesforce à utiliser pour l'authentification
        * password -- le mot de passe pour le nom d'utilisateur
        * security_token -- le jeton de sécurité pour le nom d'utilisateur
        """

        username = escape(username)
        password = escape(password)

        login_soap_request_body = f"""<?xml version="1.0" encoding="utf-8" ?>
    <env:Envelope
            xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"
            xmlns:urn="urn:partner.soap.sforce.com">
        <env:Body>
            <n1:login xmlns:n1="urn:partner.soap.sforce.com">
                <n1:username>{username}</n1:username>
                <n1:password>{password}{security_token}</n1:password>
            </n1:login>
        </env:Body>
    </env:Envelope>"""

        soap_url = f"https://{domain}.salesforce.com/services/Soap/u/{self.sf_version}"

        login_soap_request_headers = {
            "content-type": "text/xml",
            "charset": "UTF-8",
            "SOAPAction": "login",
        }

        return self.__soap_login(
            soap_url, login_soap_request_body, login_soap_request_headers
        )

    def __soap_login(
        self,
        soap_url: str,
        request_body: str,
        headers: Optional[dict],
    ) -> Tuple[str, str]:
        """
        Etablit une connexion à Salesforce en utilisant le protocole SOAP.
        """
        response = self.session.post(soap_url, request_body, headers=headers)

        if response.status_code != 200:
            except_code: Union[str, int, None]
            except_msg: str
            try:
                except_code = getUniqueElementValueFromXmlString(
                    response.content, "sf:exceptionCode"
                )
                except_msg = (
                    getUniqueElementValueFromXmlString(
                        response.content, "sf:exceptionMessage"
                    )
                    or response.content.decode()
                )
            except ExpatError:
                except_code = response.status_code
                except_msg = response.content.decode()
            raise ValueError(except_code, except_msg)

        session_id = getUniqueElementValueFromXmlString(response.content, "sessionId")
        server_url = getUniqueElementValueFromXmlString(response.content, "serverUrl")

        if session_id is None or server_url is None:
            except_code = (
                getUniqueElementValueFromXmlString(response.content, "sf:exceptionCode")
                or "UNKNOWN_EXCEPTION_CODE"
            )
            except_msg = (
                getUniqueElementValueFromXmlString(
                    response.content, "sf:exceptionMessage"
                )
                or "UNKNOWN_EXCEPTION_MESSAGE"
            )
            raise ValueError(except_code, except_msg)

        sf_instance = (
            server_url.replace("http://", "")
            .replace("https://", "")
            .split("/")[0]
            .replace("-api", "")
        )

        return session_id, sf_instance

    ################### ENDPOINTS ###################

    ### DELETE ###

    def delete_record(self, object_name: str, record_id: str) -> Tuple[bool, str]:
        """
        Supprime un enregistrement d'un objet Salesforce spécifique.
        Cette méthode utilise du caching pour vérifier si l'objet existe
        appeler l'API plus que nécessaire.

        endpoint: DELETE /sobjects/{object_name}/{record_id}

        Args:
            object_name (str): Le nom de l'objet Salesforce à supprimer.
            record_id (str): L'ID de l'enregistrement à supprimer.

        Returns:
            bool: True si la suppression a réussi, False sinon.
            str: Le message de succès ou d'erreur.

        Raises:
            ObjectDoesNotExist: Si l'objet spécifié n'existe pas dans Salesforce.
        """

        # Si l'objet n'existe pas, une exception sera levée
        self.__check_object_exists(object_name)

        delete_url = f"{self.BASE_URL}/sobjects/{object_name}/{record_id}"

        response = self.session.delete(delete_url)

        if response.status_code == 204:
            return True, "Enregistrement supprimé avec succès."
        else:
            return False, response.json()

    ### POST ###

    def create_record(self, object_name: str, data: dict) -> Tuple[bool, str]:
        """
        Crée un nouvel enregistrement d'un objet Salesforce spécifique. Pour créer un enregistrement,
        il est nécessaire de fournir le nom de l'objet ainsi que l'ensemble des champs et valeurs à insérer.

        endpoint: POST /sobjects/{object_name}/

        Args:
            object_name (str): Le nom de l'objet Salesforce dans lequel vous souhaitez créer un enregistrement.
            data (dict): Un dictionnaire contenant les données à insérer dans Salesforce.

        Returns:
            bool: True si l'enregistrement est créé avec succès, False sinon.
            str: L'ID de l'enregistrement créé ou la réponse brute de Salesforce.

        Raises:
            FieldDoesNotExist: Si un champ spécifié dans `data` n'existe pas dans l'objet Salesforce.
            ObjectDoesNotExist: Si l'objet spécifié n'existe pas dans Salesforce.
        """

        # Si l'objet n'existe pas, une exception sera levée
        self.__check_object_exists(object_name)

        allowed_fields_names = [f["name"].lower() for f in self.get_fields(object_name)]

        for key in data.keys():
            if key.lower() not in allowed_fields_names:
                raise FieldDoesNotExist(
                    f'Le champ "{key}" n\'existe pas dans l\'objet "{object_name}".\n'
                    f"Vous pouvez obtenir les champs autorisés en utilisant la méthode `get_fields`."
                )

        create_url = f"{self.BASE_URL}/sobjects/{object_name}/"

        r = self.session.post(create_url, json=data)

        match r.status_code:
            # Si l'enregistrement est créé avec succès, retourne True et l'ID de l'enregistrement
            case 201:
                return True, r.json().get("id")
            case _:
                # Dans les autres cas, retourne False et la réponse brute de Salesforce
                return False, r.json()

    ### GET ###

    def fetch_endpoint(self, endpoint: str) -> dict:
        """
        Récupère les données d'un endpoint Salesforce spécifique.
        exemple: st.fetch_endpoint('sobjects/Account/describe')
        Args:
            endpoint (str): L'URL de l'endpoint Salesforce à récupérer.

        Returns:
            dict: Les données de l'endpoint Salesforce.
        """
        return self.session.get(f"{self.BASE_URL}/{endpoint}").json()

    def query(self, soql: str, include_deleted: bool = False) -> Union[dict, list]:
        """
        Exécute une requête SOQL et retourne le résultat.
        endpoint: GET /query/?q=your_query_here
        ou GET /queryAll/?q=your_query_here si include_deleted=True.

        Args:
            soql (str): La requête SOQL à exécuter. ex: "SELECT Id, Name FROM Account LIMIT 5"
            include_deleted (bool): Si True, utilise l'endpoint queryAll.

        Returns:
            dict | list: Le résultat de la requête SOQL. En cas d'erreur API, Salesforce
            peut retourner une liste d'erreurs.
        """

        if not isinstance(soql, str):
            raise ValueError("La requête doit être une chaîne de caractères:", soql)

        records = []
        endpoint = "queryAll" if include_deleted else "query"
        response = self.session.get(
            f"{self.BASE_URL}/{endpoint}/",
            params={"q": soql},
            timeout=30,
        ).json()

        if isinstance(response, list):
            return response

        if not isinstance(response, dict):
            raise ValueError(
                "Réponse inattendue pendant l'exécution de la requête SOQL.",
                response,
            )

        while True:
            records.extend(response.get("records", []))
            if response.get("done", True):
                break
            next_records_url = response.get("nextRecordsUrl")
            if not next_records_url:
                break

            response = self.session.get(
                f"https://{self.sf_instance}{next_records_url}"
            ).json()

            if isinstance(response, list):
                return response

            if not isinstance(response, dict):
                raise ValueError(
                    "Réponse inattendue pendant la pagination de la requête SOQL.",
                    response,
                )

        return {"totalSize": len(records), "records": records}

    def get_fields(self, object_name: str) -> list:
        """
        Retourne les champs d'un objet Salesforce spécifique.

        endpoint: /sobjects/{object_name}/describe

        Args:
            object_name (str): Le nom de l'objet Salesforce pour lequel vous souhaitez obtenir les champs.

        Returns:
            list: Les champs de l'objet Salesforce.

        Exemple de réponse:

        [{
        'label': 'ID du compte',
        'name': 'AccountId',
        'referenceTo': ['Account'],
        'type': 'reference'
        }]

        Raises:
            ObjectDoesNotExist: Si l'objet n'existe pas dans Salesforce, via get_object_by_name().
        """

        # Si l'objet est dans le cache, on le retourne
        if self.last_object_name == object_name:
            return self.last_object_fields

        self.last_object_fields = self.get_object_by_name(object_name).get("fields", [])
        self.last_object_name = object_name

        fields = [
            {
                "name": field["name"],
                "label": field["label"],
                "type": field["type"],
                "referenceTo": field.get("referenceTo"),
            }
            for field in self.last_object_fields
        ]
        # On retourne la liste triée des champs relatifs à l'objet et leurs types
        return fields

    def get_objects(self, fields: list[str] = None, limit: int = None) -> list:
        """
        Récupère les objets Salesforce disponibles pour l'utilisateur connecté.
        La structure d'un objet peut être consultée dans `data/all_objects.json`

        endpoint: /sobjects/

        Args:
            fields list[str]: Les champs à récupérer pour chaque objet.
            object_name str: Le nom de l'objet Salesforce à récupérer.
            limit int: Le nombre d'objets à récupérer, retourne le nombre maximum si non spécifié.

        Returns:
            list: la liste des objets avec les champs souhaités.

        Exemple d'utilisation:

        sf.get_objects() pour obtenir tous les objets avec tous les champs.
        sf.get_objects(["name", "label"]) pour obtenir une liste d'objets avec uniquement les champs "name" et "label".
        """

        if limit is not None and not isinstance(limit, int):
            raise ValueError("La limite doit être un entier.")

        if fields is not None and not isinstance(fields, list):
            raise ValueError(
                "Les champs doivent être une liste de chaînes de caractères."
            )

        if self.last_objects_list is not None:
            if fields is None:
                return (
                    self.last_objects_list[:limit]
                    if limit is not None
                    else self.last_objects_list
                )
            else:
                final_data = []

                for obj in self.last_objects_list:
                    for field in fields:
                        try:
                            final_data.append({field: obj[field]})
                        except KeyError:
                            raise FieldDoesNotExist(
                                f'Le champ "{field}" n\'existe pas dans l\'objet "{obj["name"]}".\n'
                                f"Vous pouvez obtenir les champs disponibles en utilisant la méthode `get_fields`."
                            ) from None

                return final_data[:limit] if limit is not None else final_data

        r = self.session.get(f"{self.BASE_URL}/sobjects/")

        json_data = r.json()

        if (
            isinstance(json_data, list)
            and json_data[0].get("errorCode")
            == "INVALID_OPERATION_WITH_EXPIRED_PASSWORD"
        ):
            raise ExpiredSitetrackerPassword(
                "Votre mot de passe Sitetracker a expiré, merci de le renouveler."
            )

        data = json_data.get("sobjects") or []

        if fields is None:
            # On retourne tous les champs de tous les objets
            return data

        fields = [f.lower() for f in fields]

        final_data = []

        # Pour chaque objet, on remplit le dictionnaire avec les champs demandés
        for obj in data:
            for field in fields:
                try:
                    final_data.append({field: obj[field]})
                except KeyError:
                    raise FieldDoesNotExist(
                        f'Le champ "{field}" n\'existe pas dans l\'objet "{obj["name"]}".\n'
                        f"Vous pouvez obtenir les champs disponibles en utilisant la méthode `get_fields`."
                    ) from None

        self.last_objects_list = final_data

        return final_data[:limit] if limit is not None else final_data

    def get_object_by_name(self, object_name: str) -> dict:
        """
        Récupère les informations sur un objet Salesforce spécifique.
        Endpoint: /sobjects/{object_name}/describe

        Args:
            object_name (str): Le nom de l'objet Salesforce à récupérer.

        Returns:
            dict: Les informations sur l'objet Salesforce.
        """

        # Si l'objet n'existe pas, une exception sera levée
        self.__check_object_exists(object_name)

        return self.session.get(
            f"{self.BASE_URL}/sobjects/{object_name}/describe"
        ).json()

    def get_object_records(
        self, object_name: str, fields: list[str] = None, limit: int = None
    ) -> dict:
        """
        Récupère les enregistrements d'un objet Salesforce spécifique.

        Args:
            object_name (str): Le nom de l'objet Salesforce à récupérer.
            fields (list[str], optional): Les champs à récupérer pour chaque enregistrement. Par défaut, c'est None.

        Raises:
            TypeError: Si les champs ne sont pas une liste de chaînes de caractères.

        Returns:
            dict: Les enregistrements de l'objet Salesforce.
        """

        self.__check_object_exists(object_name)

        if limit is not None and not isinstance(limit, int):
            raise TypeError("La limite doit être un entier.")

        if fields is not None:
            if not isinstance(fields, list):
                raise TypeError(
                    "Les champs doivent être une liste de chaînes de caractères."
                )

            allowed_fields_names = [
                f["name"].lower() for f in self.get_fields(object_name)
            ]

            for entry in fields:
                if entry.lower() not in allowed_fields_names:
                    raise FieldDoesNotExist(
                        f'Le champ "{entry}" n\'existe pas dans l\'objet "{object_name}".\n'
                        f"Vous pouvez obtenir les champs autorisés en utilisant la méthode `get_fields`."
                    )

            fields = ",".join(fields)

        else:
            fields = "Id"

        q = f"SELECT {fields} FROM {object_name}"

        if limit is not None:
            q += f" LIMIT {limit}"

        return self.query(q)

    def get_picklist_values(self, object_api_name: str, field_api_name: str) -> dict:
        """
        Retourne les valeurs possibles d'un champ de type picklist pour un objet Salesforce.

        Args:
            object_api_name (str): Le nom API de l'objet Salesforce (ex: "Account").
            field_api_name (str): Le nom API du champ picklist (ex: "Type").

        Returns:
            dict: Un dictionnaire dont les clés sont les valeurs techniques de la picklist
            et les valeurs sont des objets contenant:
                - label (str): le libellé affiché
                - is_active (bool): indique si la valeur est active

            Retourne un dictionnaire vide `{}` si le champ n'existe pas
            sur l'objet ou si aucune valeur de picklist n'est disponible.

        Exemple de retour:
            {
                "Customer": {"label": "Customer", "is_active": True},
                "Prospect": {"label": "Prospect", "is_active": True}
            }
        """
        desc = self.get_object_by_name(object_api_name)
        for field in desc.get("fields", []):
            if field.get("name") == field_api_name:
                values = {}
                for v in field.get("picklistValues", []):
                    value = v.get("value")
                    if value is None:
                        continue
                    values[value] = {
                        "label": v.get("label"),
                        "is_active": v.get("active"),
                    }
                return values
        return {}

    def get_all_fields_values(
        self,
        object_name: str,
        fields: list[str],
        where: Optional[str] = None,
        include_deleted: bool = False,
        as_dataframe: bool = False,
    ) -> Union[list[dict], pd.DataFrame]:
        """
        Récupère tous les enregistrements d'un objet Salesforce pour plusieurs champs
        (avec pagination automatique).
        - Inclut toujours le champ `Id`.
        - Clause `WHERE` optionnelle.
        - `include_deleted=True` utilise `/queryAll`.
        - `as_dataframe=True` retourne automatiquement un `pandas.DataFrame`.

        Args:
            object_name (str): Le nom de l'objet Salesforce (ex: "Account").
            fields (list[str]): La liste des champs à récupérer, ex:
                ["Name", "External_Id__c"].
            where (str, optional): Condition SOQL (sans le mot-clé `WHERE`), ex:
                "IsActive__c = true".
            include_deleted (bool): Si `True`, utilise `/queryAll` pour inclure
                les enregistrements supprimés/archivés.
            as_dataframe (bool): Si `True`, retourne un `pandas.DataFrame`.

        Returns:
            list[dict] | pd.DataFrame: Les enregistrements récupérés.
        """
        self.__check_object_exists(object_name)

        if not isinstance(fields, list) or not fields:
            raise ValueError("`fields` doit être une liste non vide de chaînes.")

        allowed = {f["name"].lower(): f["name"] for f in self.get_fields(object_name)}
        normed = []
        for f in fields:
            if not isinstance(f, str):
                raise ValueError("Chaque nom de champ doit être une chaîne.")
            key = f.lower()
            if key not in allowed:
                raise FieldDoesNotExist(
                    f'Le champ "{f}" n\'existe pas dans l\'objet "{object_name}".'
                )
            if allowed[key] not in normed:
                normed.append(allowed[key])

        if "Id" not in normed:
            normed.insert(0, "Id")

        # Construire la requête SOQL
        select_fields = ", ".join(normed)
        soql = f"SELECT {select_fields} FROM {object_name}"
        if where:
            soql += f" WHERE {where}"

        resp = self.query(soql, include_deleted=include_deleted)
        if not isinstance(resp, dict):
            raise ValueError(resp)

        out = [{k: r.get(k) for k in normed} for r in resp.get("records", [])]

        return pd.DataFrame(out) if as_dataframe else out

    @lru_cache(maxsize=128)
    def get_record_by_id(self, object_name: str, record_id: str) -> Tuple[bool, dict]:
        """
        Récupère un enregistrement d'un objet Salesforce spécifique en utilisant son ID.

        Args:
            object_name (str): Le nom de l'objet Salesforce à récupérer.
            record_id (str): L'ID de l'enregistrement à récupérer.

        Returns:
            bool: True si l'enregistrement est récupéré avec succès, False sinon.
            dict: L'enregistrement de l'objet Salesforce.
        """

        self.__check_object_exists(object_name)

        records_url = f"{self.BASE_URL}/sobjects/{object_name}/{record_id}"

        response = self.session.get(records_url).json()

        if isinstance(response, list):
            try:
                result = response[0]
                if result.get("errorCode") == "NOT_FOUND":
                    return (
                        False,
                        {
                            "message": f'"{object_name}" avec l\'id "{record_id}" n\'existe pas.'
                        },
                    )
            except IndexError:
                return (
                    False,
                    {
                        "message": f'Une erreur non prévue s\'est produite lors de la récupération de "{object_name}" avec l\'id "{record_id}".'
                    },
                )

        return True, response

    def get_specific_object_relation(
        self, object_name: str, record_id: str, related_field: str
    ) -> dict | Tuple[bool, dict]:
        """
        Récupère la relation d'un objet spécifique.
        Cette fonction est utile pour obtenir les relations d'un objet avec un autre objet.

        Par exemple, je peux obtenir le site d'un projet spécifique.
        Args:
            object_name (str): Le nom de l'objet Salesforce à récupérer.
            record_id (str): L'ID de l'enregistrement à récupérer.
            related_field (str): Le champ de relation de l'objet à récupérer. (nom du champ)

        """
        self.__check_object_exists(object_name)

        success, record = self.get_record_by_id(object_name, record_id)

        if success is False:
            return False, record

        try:
            related_record_id = record[related_field]
        except KeyError:
            return False, {
                "message": f'Le champ "{related_field}" de l\'objet "{object_name}" n existe pas.'
            }

        if related_record_id is None:
            return False, {
                "message": f'Le champ "{related_field}" de l\'objet "{object_name}" est vide.'
            }

        return self.get_record_by_id(related_field, related_record_id)

    def check_instance_exists(
        self, object_name: str, field_name: str, field_value: str
    ) -> Optional[str]:
        """
        Vérifie si un enregistrement existe dans un objet Salesforce
        avec un champ donné égal à une valeur spécifique.

        Args:
            object_name (str): Nom de l'objet Salesforce (ex: "Account")
            field_name (str): Nom du champ à vérifier (ex: "Name")
            field_value (str): Valeur du champ (ex: "XXXX")

        Returns:
            Optional[str]: Id de l'enregistrement s'il existe, sinon None.
        """
        field_value_escaped = self.__soql_escape(field_value)

        query = f"SELECT Id FROM {object_name} WHERE {field_name} = '{field_value_escaped}' LIMIT 1"
        response = self.query(query)

        records = response.get("records", [])

        if records:
            return records[0].get("Id")  # retourne l'Id trouvé ou None

        return None

    def find_duplicates_records(self, object_name: str, field_value: str):
        """
        Recherche les valeurs dupliquées d'un champ donné dans un objet Salesforce.

        Args:
            object_name (str): Le nom de l'objet Salesforce (ex: "Account").
            field_value (str): Le nom du champ sur lequel rechercher les doublons
                (ex: "External_Id__c").

        Returns:
            dict: Un dictionnaire de la forme `{valeur_du_champ: nombre_occurrences}`,
            contenant uniquement les entrées dont le nombre d'occurrences est > 1.
        """
        query = (
            f"SELECT {field_value}, COUNT(Id) cnt "
            f"FROM {object_name} "
            f"WHERE {field_value} != NULL "
            f"GROUP BY {field_value} "
            f"HAVING COUNT(Id) > 1"
        )
        resp = self.query(query) or {}
        recs = resp.get("records", [])

        duplicates: dict[Any, int] = {}
        for r in recs:
            key_val = r.get(field_value)
            cnt = r.get("cnt") or r.get("expr0")  # Certaines orgs renvoient expr0 à la place de l'alias.
            if key_val is not None:
                duplicates[key_val] = int(cnt)

        return duplicates

    def delete_records_with_specific_value(
        self,
        object_name: str,
        field_value: str,
        value_list_to_delete: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> int:
        """
        Supprime tous les enregistrements d'un objet dont la valeur d'un champ
        appartient à `value_list_to_delete`.

        Args:
            object_name (str): Le nom de l'objet (ex: "Account").
            field_value (str): Le nom du champ à filtrer (ex: "External_Id__c").
            value_list_to_delete (List[str]): La liste des valeurs à supprimer.

        Returns:
            int: Le nombre d'enregistrements supprimés.
        """
        if value_list_to_delete is None and "list_valeurs" in kwargs:
            value_list_to_delete = kwargs.pop("list_valeurs")

        if kwargs:
            unexpected_keys = ", ".join(kwargs.keys())
            raise TypeError(f"Arguments inattendus: {unexpected_keys}")

        if value_list_to_delete is None:
            raise TypeError(
                'Le paramètre "value_list_to_delete" est requis (ou "list_valeurs" pour compatibilité).'
            )

        if not value_list_to_delete:
            return 0
        # Construire la clause IN
        in_clause = ",".join([f"'{v}'" for v in value_list_to_delete])

        # 1) Récupérer les Id correspondant aux critères
        query = f"SELECT Id FROM {object_name} WHERE {field_value} IN ({in_clause})"
        resp = self.query(query) or {}
        recs = resp.get("records", [])
        ids = [r.get("Id") for r in recs if r.get("Id")]

        # 2) Exécuter la suppression
        deleted_count = 0
        for rid in ids:
            try:
                self.delete_record(object_name, rid)  # Suppression unitaire par enregistrement
                deleted_count += 1
            except Exception as e:
                print(f"❌ Suppression échouée pour l'Id={rid}: {e}")

        return deleted_count

    ################### UPDATE ###################

    def update_record(
        self, object_name: str, record_id: str, data: dict
    ) -> Tuple[bool, str]:
        """
        Met à jour un enregistrement d'un objet Salesforce spécifique.

        Args:
            object_name (str): Le nom de l'objet Salesforce à mettre à jour.
            record_id (str): L'ID de l'enregistrement à mettre à jour.
            data (dict): Un dictionnaire contenant les données à mettre à jour.

        Returns:
            bool: True si la mise à jour a réussi, False sinon.
            str | dict: si l'opération  a réussi, ou le message d'erreur
        """

        self.__check_object_exists(object_name)

        update_url = f"{self.BASE_URL}/sobjects/{object_name}/{record_id}"

        # Si la réponse est 204, la mise à jour a réussi
        r = self.session.patch(update_url, json=data)

        if r.status_code == 204:
            return True, "Mise à jour effectuée avec succès."
        else:
            return False, r.json()


    #### ATTACHMENTS ####

    def upload_file_no_lease(
        self,
        activity_sf_id: str,
        b64_data: str,
        filename: str,
        file_extension: str | None = None,
    ):
        """
        Envoie un fichier vers Sitetracker en créant :
        - ContentVersion
        - ContentDocument
        - Sitetracker__Attachment__c

        Cette méthode ne fonctionne pas pour les objets de type Sitetracker__Lease__c

        Args:
            activity_sf_id (str): L'identifiant Salesforce de l'activité à laquelle
                rattacher le fichier.
            b64_data (str): Le contenu du fichier encodé en base64 (chaîne brute, sans
                préfixe de type data URI).
            filename (str): Le nom logique du fichier (sans extension).
            file_extension (str | None): L'extension du fichier (ex: "pdf", "jpg").
                Si `None` ou vide, la méthode retourne une erreur
                `"FILE_EXTENSION_MISSING"`.

        Returns:
            dict: Un dictionnaire décrivant le résultat de l'opération, contenant
            notamment:
                - success (bool)
                - sitetracker_attachment_id (str | None)
                - content_version_id (str | None)
                - content_document_id (str | None)
                - filename (str)
                - error (str | dict | None) en cas d'échec
        """

        # ------------------------------------------------------------
        # Vérifier la taille (limite requête ~50MB)
        # ------------------------------------------------------------
        if not self.__file_is_small_enough(b64_data):
            return {
                "success": False,
                "sitetracker_attachment_id": None,
                "content_version_id": None,
                "content_document_id": None,
                "filename": filename,
                "error": "FILE_TOO_LARGE",
                "b64_size": len(b64_data),
            }

        # ------------------------------------------------------------
        # Créer ContentVersion (upload réel du fichier)
        # ------------------------------------------------------------
        normalized_extension = (file_extension or "").strip().lstrip(".").lower()

        if not normalized_extension:
            return {
                "success": False,
                "sitetracker_attachment_id": None,
                "content_version_id": None,
                "content_document_id": None,
                "filename": filename,
                "error": "FILE_EXTENSION_MISSING",
            }

        filename_with_extension = f"{filename}.{normalized_extension}"
        cv_payload = {
            "Title": filename,
            "PathOnClient": filename_with_extension,
            # "FileExtension": normalized_extension,
            "VersionData": b64_data,
            "FirstPublishLocationId": activity_sf_id,
        }

        sucess, cv_id = self.create_record("ContentVersion", cv_payload)
        if not sucess or not isinstance(cv_id, str):
            print("ContentVersion creation failed:", cv_id)

            return {
                "success": False,
                "sitetracker_attachment_id": None,
                "content_version_id": None,
                "content_document_id": None,
                "filename": filename,
                "error": cv_id,
            }

        # ------------------------------------------------------------
        # Récupérer ContentDocumentId
        # ------------------------------------------------------------
        soql = f"""
            SELECT ContentDocumentId
            FROM ContentVersion
            WHERE Id = '{cv_id}'
            LIMIT 1
        """
        doc = self.query(soql)
        records = doc.get("records") if isinstance(doc, dict) else None
        if not records:
            print("ContentDocumentId query failed:", doc)

            return {
                "success": False,
                "sitetracker_attachment_id": None,
                "content_version_id": cv_id,
                "content_document_id": None,
                "filename": filename,
                "error": doc,
            }
        content_doc_id = records[0].get("ContentDocumentId")
        if not content_doc_id:
            print("ContentDocumentId missing in response:", records[0])

            return {
                "success": False,
                "sitetracker_attachment_id": None,
                "content_version_id": cv_id,
                "content_document_id": None,
                "filename": filename,
                "error": "MISSING_CONTENT_DOCUMENT_ID",
            }

        # ------------------------------------------------------------
        # Créer Sitetracker__Attachment__c
        # ------------------------------------------------------------
        st_payload = {
            "Name": filename,
            "sitetracker__Activity__c": activity_sf_id,
            "sitetracker__Parent_ID__c": activity_sf_id,
            "sitetracker__ContentDocumentRecord__c": content_doc_id,
        }

        sucess, st_attach_id = self.create_record(
            "sitetracker__Attachment__c", st_payload
        )

        if not sucess or not isinstance(st_attach_id, str):
            print("Sitetracker attachment creation failed:", st_attach_id)

            return {
                "success": False,
                "sitetracker_attachment_id": None,
                "content_version_id": cv_id,
                "content_document_id": content_doc_id,
                "filename": filename,
                "error": st_attach_id,
            }

        return {
            "success": True,
            "sitetracker_attachment_id": st_attach_id,
            "content_version_id": cv_id,
            "content_document_id": content_doc_id,
            "filename": filename,
        }

    def get_attachments_of_activities(
        self, activity_ids: List[ActivityIDInstance], chunk_size: int = 150
    ) -> Dict[str, List[Dict]]:
        """
        Récupère les pièces jointes pour une liste d'activités en limitant le nombre
        de requêtes réseau via des requêtes SOQL en lot (`IN (...)`).

        Logique:
        - dédupliquer/nettoyer les IDs,
        - découper en paquets (`chunk_size`),
        - exécuter une requête par paquet,
        - regrouper les résultats par activité.
        """
        if not isinstance(activity_ids, list):
            raise TypeError(
                'Le paramètre "activity_ids" de la méthode get_attachments_of_activities() doit être une liste de la classe ActivityIDInstance.'
            )

        if chunk_size <= 0:
            raise ValueError('Le paramètre "chunk_size" doit être supérieur à 0.')

        cleaned_activity_rows = [
            aid
            for aid in activity_ids
            if isinstance(aid, ActivityIDInstance)
            and isinstance(aid.activity_id, str)
            and aid.activity_id.strip()
        ]
        if not cleaned_activity_rows:
            return {}

        unique_activity_ids = list(
            dict.fromkeys([aid.activity_id for aid in cleaned_activity_rows])
        )
        activity_id_to_instance_id = {
            aid.activity_id: aid.sitetracker_instance_id
            for aid in cleaned_activity_rows
        }
        attachments_by_activity: Dict[str, List[Dict]] = {
            aid: [] for aid in unique_activity_ids
        }

        fields = [
            "Id",
            "Name",
            "sitetracker__Activity__c",
            "sitetracker__Activity__r.Name",
            "sitetracker__Activity__r.sitetracker__Project__r.Name",
            "sitetracker__Attachment__c",
            "sitetracker__ContentDocumentRecord__c",
            "CreatedBy.Name",
            "CreatedDate",
            "LastModifiedBy.Name",
            "LastModifiedDate",
        ]

        for i in range(0, len(unique_activity_ids), chunk_size):
            batch = unique_activity_ids[i : i + chunk_size]
            ids_sql = ", ".join(f"'{aid}'" for aid in batch)
            soql = (
                f"SELECT {', '.join(fields)} "
                f"FROM sitetracker__Attachment__c "
                f"WHERE sitetracker__Activity__c IN ({ids_sql}) "
                f"AND sitetracker__ContentDocumentRecord__c != null"
            )

            records = self.query(soql).get("records", [])
            for r in records:
                activity_id = r.get("sitetracker__Activity__c")
                if not activity_id:
                    continue
                activity_rel = (
                    r.get("sitetracker__Activity__r")
                    if isinstance(r.get("sitetracker__Activity__r"), dict)
                    else {}
                )
                project_rel = (
                    activity_rel.get("sitetracker__Project__r")
                    if isinstance(activity_rel.get("sitetracker__Project__r"), dict)
                    else {}
                )
                instance_name = (
                    project_rel.get("Name")
                    or activity_rel.get("Name")
                    or activity_id_to_instance_id.get(activity_id)
                    or ""
                )
                attachments_by_activity.setdefault(activity_id, []).append(
                    {
                        "id": r.get("Id"),
                        "activity_id": activity_id,
                        "instance_id": activity_id_to_instance_id.get(activity_id),
                        "instance_name": instance_name,
                        "filename": r.get("Name"),
                        "author_name": (r.get("CreatedBy") or {}).get("Name"),
                        "created_date": r.get("CreatedDate"),
                        "last_modified_date": r.get("LastModifiedDate"),
                    }
                )

        return attachments_by_activity

    def delete_attachment_by_id(self, attachment_id: str):
        """
        Supprime complètement un fichier depuis Sitetracker :
        - récupère ContentDocumentId directement depuis sitetracker__Attachment__c
          (fallback via ContentDocumentLink si nécessaire)
        - supprime sitetracker__Attachment__c
        - supprime ContentDocument
        """

        print("🗑 Suppression de l'attachement ST :", attachment_id)

        # 1. Récupérer Parent ID + ContentDocument directement depuis l'attachment
        soql = f"""
            SELECT sitetracker__Parent_ID__c, sitetracker__ContentDocumentRecord__c
            FROM sitetracker__Attachment__c
            WHERE Id = '{attachment_id}'
            LIMIT 1
        """

        res = self.query(soql)

        # ---- 🔥 PATCH : éviter IndexError ----
        if not res["records"]:
            print(f"⚠️ Attachment {attachment_id} déjà supprimé ou introuvable → skip")
            return False

        att = res["records"][0]
        parent_id = att.get("sitetracker__Parent_ID__c")
        content_doc_id = att.get("sitetracker__ContentDocumentRecord__c")

        if not parent_id:
            print("❌ Aucun Parent_ID trouvé → impossible de continuer")
            return False

        print("🔗 Parent ID =", parent_id)

        # Fallback historique: si le champ direct n'est pas rempli
        if not content_doc_id:
            soql = f"""
                SELECT ContentDocumentId
                FROM ContentDocumentLink
                WHERE LinkedEntityId = '{parent_id}'
                LIMIT 1
            """
            links = self.query(soql).get("records", [])
            if not links:
                print("❌ Aucun ContentDocumentId trouvé (champ direct + link)")
                return False
            content_doc_id = links[0].get("ContentDocumentId")

        if not content_doc_id:
            print("❌ ContentDocumentId introuvable")
            return False

        print("📄 ContentDocumentId =", content_doc_id)

        def _payload_has_entity_is_deleted(payload: Any) -> bool:
            if isinstance(payload, list):
                for item in payload:
                    if (
                        isinstance(item, dict)
                        and item.get("errorCode") == "ENTITY_IS_DELETED"
                    ):
                        return True
            return False

        # 3. Supprimer sitetracker__Attachment__c
        success1, deleted_attachment_payload = self.delete_record(
            "sitetracker__Attachment__c", attachment_id
        )
        if not success1 and _payload_has_entity_is_deleted(deleted_attachment_payload):
            success1 = True
        print(
            "🗑 ST Attachment supprimé :",
            success1,
            "| payload=",
            deleted_attachment_payload,
        )

        # 4. Supprimer ContentDocument
        success2, deleted_content_document_payload = self.delete_record(
            "ContentDocument", content_doc_id
        )
        if not success2 and _payload_has_entity_is_deleted(
            deleted_content_document_payload
        ):
            success2 = True
        print(
            "🗑 ContentDocument supprimé :",
            success2,
            "| payload=",
            deleted_content_document_payload,
        )

        return success1 and success2


    ################### UTILS ###################

    @lru_cache(maxsize=128)
    def __check_object_exists(self, object_name: str) -> bool:
        """
        Vérifie si un objet Salesforce spécifique existe.
        Lève une exception ObjectDoesNotExist si l'objet n'existe pas.

        Args:
            object_name (str): Le nom de l'objet Salesforce à vérifier.

        Returns:
            bool: True si l'objet existe, lève une exception sinon.
        """
        if self.last_objects_list is None:
            self.last_objects_list = [
                obj.get("name").casefold() for obj in self.get_objects(["name"])
            ]

        if object_name.casefold() not in self.last_objects_list:
            raise ObjectDoesNotExist(
                f"L'objet \"{object_name}\" n'existe pas dans Salesforce."
            )

        return True

    def __soql_escape(self, value: str) -> str:
        return (
            value.replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
        )

    def __file_is_small_enough(self, file: str) -> bool:
        max_b64_bytes = 48 * 1024 * 1024  # safety margin below 50MB request limit
        b64_size = len(file)

        return b64_size < max_b64_bytes
