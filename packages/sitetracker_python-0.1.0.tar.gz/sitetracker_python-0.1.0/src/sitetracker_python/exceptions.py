"""Exceptions for the salesforce_wrapper module."""


class SiteTrackerError(Exception):
    """Base exception for the salesforce_wrapper module."""
    pass


class FieldDoesNotExist(SiteTrackerError):
    """Exception raised when a non-existing field is requested."""
    pass


class ObjectDoesNotExist(SiteTrackerError):
    """Exception raised when a non-existing object is requested."""
    pass


class SalesForceVersionError(SiteTrackerError):
    """Exception raised when the version of Salesforce is not supported."""
    pass


class MissingEnvironmentVariable(SiteTrackerError):
    """Exception raised when an environment variable is missing."""
    pass


class ExpiredSitetrackerPassword(SiteTrackerError):
    """Exception raised when the password of the user has expired."""
    pass