Please download pretrained weights MantraNetv4.pt from [ManTraNet-pytorch](https://github.com/RonyAbecidan/ManTraNet-pytorch) and put it under this directory. 

Then run modify_weights.py to modify the weight into appropriate form.