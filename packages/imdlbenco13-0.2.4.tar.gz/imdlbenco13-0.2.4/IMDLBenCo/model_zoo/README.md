# MODEL_ZOO
Here is the implementation of all models in `model_zoo` of IMDLBenCo.

You can find the guide to download the pretrained weights of each model under their **sub-folders** here, which is must when you want train each model by yourself.