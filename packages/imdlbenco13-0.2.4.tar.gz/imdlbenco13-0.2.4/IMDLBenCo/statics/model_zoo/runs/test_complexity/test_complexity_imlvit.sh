python ./test_complexity.py \
    --model IML_ViT \
    --test_batch_size 1 \
    --image_size 1024 \
    --if_padding