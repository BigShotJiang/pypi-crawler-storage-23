python ./test_complexity.py \
    --model MVSSNet \
    --test_batch_size 1 \
    --edge_mask_width 7 \
    --image_size 512 \
    --if_resizing