"""Supervisor-Worker multi-agent pattern example."""
