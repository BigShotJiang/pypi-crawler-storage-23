"""Klartex — PDF generation via LaTeX."""

from klartex.renderer import render

__all__ = ["render"]
