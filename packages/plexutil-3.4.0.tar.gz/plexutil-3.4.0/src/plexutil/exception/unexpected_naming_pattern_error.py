class UnexpectedNamingPatternError(Exception):
    pass
