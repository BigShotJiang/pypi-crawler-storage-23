class DatabaseConnectionError(Exception):
    pass
