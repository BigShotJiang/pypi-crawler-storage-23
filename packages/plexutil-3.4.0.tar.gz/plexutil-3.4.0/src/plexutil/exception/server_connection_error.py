class ServerConnectionError(Exception):
    pass
