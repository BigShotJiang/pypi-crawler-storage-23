class LibraryPollTimeoutError(Exception):
    pass
