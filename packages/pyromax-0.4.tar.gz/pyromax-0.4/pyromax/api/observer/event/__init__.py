from pyromax.api.observer.event.MaxEventObserver import MaxEventObserver

__all__ = ['MaxEventObserver']