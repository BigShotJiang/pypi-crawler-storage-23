from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from LOGS.Auxiliary.Decorators import deprecated
from LOGS.Auxiliary.Tools import Tools
from LOGS.Entities.Origin import Origin
from LOGS.Entities.OriginMinimal import OriginMinimal
from LOGS.Interfaces.IEntityInterface import IEntityInterface


@dataclass
class IUniqueEntityRequest:
    originIds: Optional[List[int]] = None


class IUniqueEntity(IEntityInterface):
    _uid: Optional[str] = None

    _foreignStorage: Optional[OriginMinimal] = None
    _foreignIdentifier: Optional[str] = None
    _foreignUid: Optional[UUID] = None
    _foreignUrl: Optional[str] = None

    def toDict(self) -> Dict[str, Any]:
        result = getattr(super(), "toDict")() if hasattr(super(), "toDict") else {}
        if self._foreignUid is not None:
            result["foreignUid"] = self._foreignUid
        if self._foreignStorage is not None:
            result["foreignStorage"] = self._foreignStorage.toDict()
        if self._foreignIdentifier is not None:
            result["foreignIdentifier"] = self._foreignIdentifier
        if self._foreignUid is not None:
            result["foreignUid"] = str(self._foreignUid)
        if self._foreignUrl is not None:
            result["foreignUrl"] = self._foreignUrl
        return result

    def setForeignStorage(
        self,
        origin: Optional[Union[Origin, OriginMinimal]],
        uid: Optional[Union[str, UUID]] = None,
        identifier: Optional[str] = None,
        url: Optional[str] = None,
    ):
        self._foreignUid = Tools.checkAndConvert(
            uid, UUID, f"{self.setForeignStorage.__name__}(uid)", allowNone=True
        )
        self._foreignStorage = Tools.checkAndConvert(
            origin,
            OriginMinimal,
            f"{self.setForeignStorage.__name__}(origin)",
        )
        self._foreignIdentifier = Tools.checkAndConvert(
            identifier,
            str,
            f"{self.setForeignStorage.__name__}(identifier)",
            allowNone=True,
        )
        self._foreignUrl = Tools.checkAndConvert(
            url, str, f"{self.setForeignStorage.__name__}(url)", allowNone=True
        )

    @deprecated
    def setOrigin(
        self,
        uid: Optional[Union[str, UUID]] = None,
        origin: Optional[Union[Origin, OriginMinimal]] = None,
    ):
        self._foreignUid = Tools.checkAndConvert(
            uid, UUID, f"{self.setOrigin.__name__}(uid)", allowNone=True
        )
        self._foreignStorage = Tools.checkAndConvert(
            origin, OriginMinimal, f"{self.setOrigin.__name__}(origin)", allowNone=True
        )

    def _originConverter(self, origin: Union[Origin, OriginMinimal]) -> OriginMinimal:
        if isinstance(origin, OriginMinimal):
            return origin
        if isinstance(origin, Origin):
            return OriginMinimal(name=origin.name, id=origin.id)
        return Tools.checkAndConvert(origin, OriginMinimal, allowNone=True)

    @property
    def uid(self) -> Optional[str]:
        return self._uid

    @uid.setter
    def uid(self, value):
        self._uid = Tools.checkAndConvert(
            value=value, fieldType=str, fieldName="uid", allowNone=True
        )
