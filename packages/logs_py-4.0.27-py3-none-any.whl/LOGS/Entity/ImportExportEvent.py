from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import UUID

from LOGS.Auxiliary.MinimalModelGenerator import MinimalModelGenerator
from LOGS.Entities.OriginMinimal import OriginMinimal
from LOGS.Entity.EntityWithIntId import IEntityWithIntId


class ImportExportEventType(Enum):
    Import = "Import"
    Export = "Export"


class ImportExportEvent(IEntityWithIntId):
    _foreignStorage: Optional[OriginMinimal] = None
    _timestamp: Optional[datetime] = None
    _eventType: Optional[ImportExportEventType] = None
    _foreignIdentifier: Optional[str] = None
    _foreignUid: Optional[Optional[UUID]] = None
    _foreignUrl: Optional[str] = None

    @property
    def foreignStorage(self) -> Optional[OriginMinimal]:
        return self._foreignStorage

    @foreignStorage.setter
    def foreignStorage(self, value):
        self._foreignStorage = MinimalModelGenerator.MinimalFromSingle(
            value, "OriginMinimal", "origins", connection=self._getConnection()
        )

    @property
    def timestamp(self) -> Optional[datetime]:
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value):
        self._timestamp = self.checkAndConvertNullable(value, datetime, "timestamp")

    @property
    def eventType(self) -> Optional[ImportExportEventType]:
        return self._eventType

    @eventType.setter
    def eventType(self, value):
        self._eventType = self.checkAndConvertNullable(
            value, ImportExportEventType, "eventType"
        )

    @property
    def foreignIdentifier(self) -> Optional[str]:
        return self._foreignIdentifier

    @foreignIdentifier.setter
    def foreignIdentifier(self, value):
        self._foreignIdentifier = self.checkAndConvertNullable(
            value, str, "foreignIdentifier"
        )

    @property
    def foreignUid(self) -> Optional[UUID]:
        return self._foreignUid

    @foreignUid.setter
    def foreignUid(self, value):
        self._foreignUid = self.checkAndConvertNullable(value, UUID, "foreignUid")

    @property
    def foreignUrl(self) -> Optional[str]:
        return self._foreignUrl

    @foreignUrl.setter
    def foreignUrl(self, value):
        self._foreignUrl = self.checkAndConvertNullable(value, str, "foreignUrl")
