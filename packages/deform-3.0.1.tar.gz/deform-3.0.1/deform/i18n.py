"""I18n."""

from translationstring import TranslationStringFactory

_ = TranslationStringFactory("deform")
