.. _changelog:

=====================
Deform Change History
=====================

.. include:: ../CHANGES.txt


