"""Visual graph editor for fsm-agent-flow workflows."""
