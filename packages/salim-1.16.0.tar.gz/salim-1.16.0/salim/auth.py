"""
Authorization middleware for Salim.
Handles per-user auth, session management, and audit logging.
"""

from __future__ import annotations

import json
import logging
import functools
from datetime import datetime
from pathlib import Path
from typing import Callable

from telegram import Update
from telegram.ext import ContextTypes

from salim.config import Config, LOG_FILE

logger = logging.getLogger("salim.auth")


def setup_logging(verbose: bool = False):
    """Configure logging to file + console."""
    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

    handlers: list[logging.Handler] = [logging.StreamHandler()]
    try:
        handlers.append(logging.FileHandler(LOG_FILE))
    except Exception:
        pass

    logging.basicConfig(level=level, format=fmt, handlers=handlers)


class AuthMiddleware:
    """
    Centralized auth + audit logging.
    """

    def __init__(self, config: Config):
        self.config = config
        self._blocked_attempts: dict[int, list[float]] = {}

    def is_allowed(self, user_id: int) -> bool:
        return user_id in self.config.allowed_ids

    def log_command(self, user_id: int, username: str, command: str, args: str = ""):
        if not self.config.log_commands:
            return
        entry = {
            "ts": datetime.now().isoformat(),
            "uid": user_id,
            "user": username,
            "cmd": command,
            "args": args[:200],
        }
        try:
            with open(LOG_FILE, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass

    def log_blocked(self, user_id: int, username: str):
        import time
        attempts = self._blocked_attempts.setdefault(user_id, [])
        attempts.append(time.time())
        logger.warning(f"Blocked unauthorized access: uid={user_id} user={username!r}")

    def get_audit_log(self, lines: int = 50) -> list[dict]:
        try:
            raw = LOG_FILE.read_text().strip().splitlines()
            entries = []
            for line in raw[-lines:]:
                try:
                    entries.append(json.loads(line))
                except Exception:
                    pass
            return entries
        except Exception:
            return []


# ── Decorator ────────────────────────────────────────────────────────────────

def require_auth(func: Callable) -> Callable:
    """
    Decorator for handler methods in SalimBot.
    Requires self.auth (AuthMiddleware) on the class.
    """
    @functools.wraps(func)
    async def wrapper(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        if not user or not self.auth.is_allowed(user.id):
            if user:
                self.auth.log_blocked(user.id, user.username or "")
            if update.message:
                await update.message.reply_text("⛔ Unauthorized.")
            elif update.callback_query:
                await update.callback_query.answer("⛔ Unauthorized.", show_alert=True)
            return
        # Log command
        cmd = func.__name__.replace("cmd_", "/")
        arg_str = " ".join(ctx.args or [])
        self.auth.log_command(user.id, user.username or str(user.id), cmd, arg_str)
        return await func(self, update, ctx, *args, **kwargs)
    return wrapper
