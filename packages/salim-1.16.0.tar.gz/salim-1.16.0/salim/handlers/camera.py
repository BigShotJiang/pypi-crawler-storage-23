"""
Salim Camera & Recording Handler

/cam [delay]       — Capture a webcam photo and send to Telegram
/cam list          — List available webcam devices
/record <seconds>  — Record screen for N seconds, compress, send as video

Screen recording uses ffmpeg (already required for voice).
Webcam uses OpenCV (cv2) — already a transitive dep of many packages.

Auto-installs: opencv-python (if missing)
"""
from __future__ import annotations

import asyncio
import io
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import is_mac, is_linux, is_windows, run_shell_async

logger = logging.getLogger("salim.camera")

MAX_RECORD_SECONDS = 300   # 5 minutes hard cap
MAX_VIDEO_MB = 49          # Telegram bot limit is 50MB


def _ensure_cv2() -> bool:
    try:
        import cv2  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "opencv-python-headless", "--quiet"],
            check=True, timeout=120
        )
        return True
    except Exception as e:
        logger.error(f"Failed to install opencv: {e}")
        return False


def _ensure_ffmpeg() -> bool:
    return bool(shutil.which("ffmpeg"))


def _get_camera_name(index: int) -> str:
    """Read the real device name for a camera index from the OS."""
    # Linux: read from /sys/class/video4linux/videoN/name
    if is_linux():
        try:
            name_path = Path(f"/sys/class/video4linux/video{index}/name")
            if name_path.exists():
                return name_path.read_text().strip()
        except Exception:
            pass
        # Fallback: try v4l2-ctl if available
        try:
            import shutil
            if shutil.which("v4l2-ctl"):
                result = subprocess.run(
                    ["v4l2-ctl", f"--device=/dev/video{index}", "--info"],
                    capture_output=True, text=True, timeout=3
                )
                for line in result.stdout.splitlines():
                    if "Card type" in line or "Driver name" in line:
                        return line.split(":", 1)[-1].strip()
        except Exception:
            pass
        return f"/dev/video{index}"

    # macOS: use avfoundation via ffmpeg to list devices
    elif is_mac():
        try:
            result = subprocess.run(
                ["ffmpeg", "-f", "avfoundation", "-list_devices", "true", "-i", ""],
                capture_output=True, text=True, timeout=5
            )
            # Parse lines like: [AVFoundation indev @ ...] [0] FaceTime HD Camera
            import re
            matches = re.findall(r"\[(\d+)\] (.+)", result.stderr)
            for idx_str, name in matches:
                if int(idx_str) == index:
                    return name.strip()
        except Exception:
            pass
        return f"Camera {index}"

    # Windows: use DirectShow via ffmpeg
    elif is_windows():
        try:
            result = subprocess.run(
                ["ffmpeg", "-f", "dshow", "-list_devices", "true", "-i", "video=dummy"],
                capture_output=True, text=True, timeout=5
            )
            import re
            # Match lines like:  "Integrated Webcam" (video)
            names = re.findall(r'"(.+?)"\s+\(video\)', result.stderr)
            if index < len(names):
                return names[index]
        except Exception:
            pass
        return f"Camera {index}"

    return f"Camera {index}"


def _list_webcams() -> list[tuple[int, str]]:
    """Return [(index, real_device_name), ...] of available cameras."""
    import cv2
    cams = []
    for i in range(8):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            name = _get_camera_name(i)
            cams.append((i, name))
            cap.release()
    return cams


def _capture_frame(cam_index: int = 0) -> bytes:
    """Capture a single JPEG frame from the webcam. Returns JPEG bytes."""
    import cv2
    cap = cv2.VideoCapture(cam_index)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open camera {cam_index}")

    # Let camera warm up (auto-exposure stabilize)
    for _ in range(5):
        cap.read()

    ret, frame = cap.read()
    cap.release()

    if not ret or frame is None:
        raise RuntimeError("Failed to capture frame from camera")

    # Flip horizontally (natural selfie view)
    frame = cv2.flip(frame, 1)

    # Add timestamp watermark
    h, w = frame.shape[:2]
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    cv2.putText(frame, ts, (10, h - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.putText(frame, ts, (10, h - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)

    ret, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 90])
    if not ret:
        raise RuntimeError("JPEG encoding failed")
    return buf.tobytes()


def _find_linux_audio_source() -> tuple[str, str]:
    """
    Detect the best audio source on Linux.
    Returns (ffmpeg_audio_driver, ffmpeg_audio_input).
    Prefers PulseAudio monitor (captures system/desktop audio).
    Falls back to ALSA default if PulseAudio unavailable.
    """
    import re

    # ── PulseAudio: find a monitor source (captures ALL desktop audio) ────────
    try:
        r = subprocess.run(
            ["pactl", "list", "short", "sources"],
            capture_output=True, text=True, timeout=5
        )
        if r.returncode == 0:
            for line in r.stdout.splitlines():
                # Monitor sources end with .monitor
                parts = line.split()
                if len(parts) >= 2 and parts[1].endswith(".monitor"):
                    return "pulse", parts[1]
            # No monitor found — try generic pulse
            return "pulse", "default"
    except FileNotFoundError:
        pass

    # ── PipeWire (uses same pactl interface, so already caught above) ──────────

    # ── ALSA fallback ─────────────────────────────────────────────────────────
    return "alsa", "hw:0,0"


def _find_mac_audio_index() -> str:
    """
    Find the audio input index for avfoundation that captures system audio.
    On macOS you need a loopback device such as BlackHole (free, open source)
    or Soundflower.  Without one we fall back to the built-in microphone (index 0).
    Returns the string to put after the colon in  "-i N:M".
    """
    try:
        r = subprocess.run(
            ["ffmpeg", "-f", "avfoundation", "-list_devices", "true", "-i", ""],
            capture_output=True, text=True, timeout=5
        )
        output = r.stderr
        # Look for BlackHole or Soundflower (popular free loopback drivers)
        import re
        audio_devices = []
        in_audio = False
        for line in output.splitlines():
            if "AVFoundation audio devices" in line:
                in_audio = True
                continue
            if in_audio and re.search(r"\[\d+\]", line):
                m = re.search(r"\[(\d+)\]\s+(.+)", line)
                if m:
                    audio_devices.append((int(m.group(1)), m.group(2).strip()))

        for idx, name in audio_devices:
            if any(kw in name.lower() for kw in ["blackhole", "soundflower", "loopback", "virtual"]):
                return str(idx)
        # Fallback: built-in microphone (index 0) — records mic, not desktop audio
        return "0"
    except Exception:
        return "0"


def _find_windows_audio_device() -> str | None:
    """
    Find a DirectShow audio device name for desktop audio capture.
    Checks for virtual audio cables / loopback devices first,
    then falls back to the default stereo mix / wave out.
    Returns the device name string or None if none found.
    """
    try:
        r = subprocess.run(
            ["ffmpeg", "-f", "dshow", "-list_devices", "true", "-i", "dummy"],
            capture_output=True, text=True, timeout=5
        )
        import re
        audio_names = re.findall(r'"(.+?)"\s+\(audio\)', r.stderr)
        # Prefer loopback / stereo mix devices
        priority_kws = ["stereo mix", "wave out", "loopback", "virtual", "cable", "voicemeeter"]
        for kw in priority_kws:
            for name in audio_names:
                if kw.lower() in name.lower():
                    return name
        # Return first available audio device
        if audio_names:
            return audio_names[0]
    except Exception:
        pass
    return None


async def _record_screen_ffmpeg(seconds: int, output_path: str) -> tuple[bool, str]:
    """
    Record screen + desktop audio using ffmpeg. Cross-platform.
    Audio capture:
    - Linux  : PulseAudio monitor source (grabs all desktop audio)
    - macOS  : avfoundation audio (BlackHole/Soundflower if installed, else mic)
    - Windows: DirectShow Stereo Mix / virtual cable (if available, else video-only)
    """
    import re

    if is_linux():
        display = os.environ.get("DISPLAY", ":0")
        try:
            xr = subprocess.check_output(
                ["xrandr"], stderr=subprocess.DEVNULL, text=True, timeout=5
            )
            m = re.search(r"(\d{3,4}x\d{3,4})\+0\+0", xr)
            size = m.group(1) if m else "1920x1080"
        except Exception:
            size = "1920x1080"

        audio_driver, audio_src = _find_linux_audio_source()

        cmd = [
            "ffmpeg", "-y",
            # Video input
            "-video_size", size,
            "-framerate", "15",
            "-f", "x11grab",
            "-i", display,
            # Audio input
            "-f", audio_driver,
            "-i", audio_src,
            # Duration
            "-t", str(seconds),
            # Video codec
            "-vcodec", "libx264",
            "-preset", "ultrafast",
            "-crf", "28",
            "-pix_fmt", "yuv420p",
            # Audio codec
            "-acodec", "aac",
            "-b:a", "128k",
            output_path
        ]

    elif is_mac():
        audio_idx = _find_mac_audio_index()
        # Screen is always index 1 for avfoundation on macOS
        cmd = [
            "ffmpeg", "-y",
            "-f", "avfoundation",
            "-framerate", "15",
            "-capture_cursor", "1",
            "-i", f"1:{audio_idx}",     # screen:audio
            "-t", str(seconds),
            "-vcodec", "libx264",
            "-preset", "ultrafast",
            "-crf", "28",
            "-pix_fmt", "yuv420p",
            "-acodec", "aac",
            "-b:a", "128k",
            output_path
        ]

    else:  # Windows
        audio_dev = _find_windows_audio_device()
        if audio_dev:
            cmd = [
                "ffmpeg", "-y",
                # Video
                "-f", "gdigrab",
                "-framerate", "15",
                "-i", "desktop",
                # Audio via DirectShow
                "-f", "dshow",
                "-i", f"audio={audio_dev}",
                # Duration
                "-t", str(seconds),
                "-vcodec", "libx264",
                "-preset", "ultrafast",
                "-crf", "28",
                "-pix_fmt", "yuv420p",
                "-acodec", "aac",
                "-b:a", "128k",
                output_path
            ]
        else:
            # No audio device found — record video only
            cmd = [
                "ffmpeg", "-y",
                "-f", "gdigrab",
                "-framerate", "15",
                "-i", "desktop",
                "-t", str(seconds),
                "-vcodec", "libx264",
                "-preset", "ultrafast",
                "-crf", "28",
                "-pix_fmt", "yuv420p",
                output_path
            ]

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=seconds + 30
        )
        if proc.returncode == 0 and Path(output_path).exists():
            return True, ""
        err_text = stderr.decode(errors="replace")
        # If audio capture failed, retry without audio
        if ("Invalid data found" in err_text or "No such file" in err_text
                or "Cannot find" in err_text or "dshow" in err_text.lower()
                and "error" in err_text.lower()):
            # Strip audio args and retry video-only
            video_only_cmd = [
                a for a in cmd
                if a not in ("-f", "dshow", "pulse", "alsa")
                and not a.startswith("audio=")
                and not a.startswith("hw:")
                and a not in ("-acodec", "aac", "-b:a", "128k")
            ]
            # Rebuild cleanly
            if is_linux():
                video_only_cmd = [
                    "ffmpeg", "-y",
                    "-video_size", size, "-framerate", "15",
                    "-f", "x11grab", "-i", display,
                    "-t", str(seconds),
                    "-vcodec", "libx264", "-preset", "ultrafast",
                    "-crf", "28", "-pix_fmt", "yuv420p",
                    output_path
                ]
            elif is_mac():
                video_only_cmd = [
                    "ffmpeg", "-y",
                    "-f", "avfoundation", "-framerate", "15",
                    "-i", "1:none",
                    "-t", str(seconds),
                    "-vcodec", "libx264", "-preset", "ultrafast",
                    "-crf", "28", "-pix_fmt", "yuv420p",
                    output_path
                ]
            else:
                video_only_cmd = [
                    "ffmpeg", "-y",
                    "-f", "gdigrab", "-framerate", "15", "-i", "desktop",
                    "-t", str(seconds),
                    "-vcodec", "libx264", "-preset", "ultrafast",
                    "-crf", "28", "-pix_fmt", "yuv420p",
                    output_path
                ]
            proc2 = await asyncio.create_subprocess_exec(
                *video_only_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr2 = await asyncio.wait_for(
                proc2.communicate(), timeout=seconds + 30
            )
            if proc2.returncode == 0 and Path(output_path).exists():
                return True, "⚠️ Audio capture failed — recorded video only (no audio device found)"
            return False, stderr2.decode(errors="replace")[-500:]
        return False, err_text[-500:]
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        return False, "Recording timed out"
    except Exception as e:
        return False, str(e)


class CameraHandlers:

    @require_auth
    async def cmd_cam(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /cam            — Snapshot from default webcam
        /cam <N>        — Snapshot from camera index N
        /cam list       — List available cameras
        /cam <delay> <index>  — with delay
        """
        if not _ensure_cv2():
            await update.effective_message.reply_text(
                "❌ opencv-python not installed.\n"
                "Run: <code>pip install opencv-python-headless</code>",
                parse_mode="HTML"
            )
            return

        args = ctx.args or []

        # List cameras
        if args and args[0].lower() == "list":
            cams = await asyncio.get_event_loop().run_in_executor(None, _list_webcams)
            if not cams:
                await update.effective_message.reply_text("📷 No cameras detected.")
                return
            lines = [f"• Camera <code>{i}</code>: {name}" for i, name in cams]
            await update.effective_message.reply_text(
                "📷 <b>Available Cameras:</b>\n\n" + "\n".join(lines) +
                "\n\nUse <code>/cam &lt;index&gt;</code> to select.",
                parse_mode="HTML"
            )
            return

        # Parse delay and cam index
        delay = 0
        cam_index = 0
        for arg in args:
            try:
                val = int(arg)
                if val > 10:
                    delay = val
                else:
                    cam_index = val
            except ValueError:
                pass

        if delay:
            await update.effective_message.reply_text(f"📷 Taking webcam photo in {delay}s...")
            await asyncio.sleep(delay)

        status = await update.effective_message.reply_text(
            f"📷 <i>Capturing from camera {cam_index}...</i>", parse_mode="HTML"
        )

        try:
            jpeg_bytes = await asyncio.get_event_loop().run_in_executor(
                None, _capture_frame, cam_index
            )
        except Exception as e:
            await status.edit_text(f"❌ Camera error: {e}", parse_mode="HTML")
            return

        buf = io.BytesIO(jpeg_bytes)
        buf.name = f"cam_{cam_index}_{int(time.time())}.jpg"

        try:
            await status.delete()
        except Exception:
            pass

        await update.effective_message.reply_photo(
            photo=buf,
            caption=f"📷 Camera {cam_index} · {time.strftime('%Y-%m-%d %H:%M:%S')} · {len(jpeg_bytes)//1024}KB"
        )

    @require_auth
    async def cmd_record(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /record <seconds>   — Record screen, compress, send to Telegram
        /record 30          — 30-second recording
        """
        if not ctx.args:
            await update.effective_message.reply_text(
                "🎬 <b>Screen Recording</b>\n\n"
                "Usage: <code>/record &lt;seconds&gt;</code>\n"
                "Example: <code>/record 30</code>\n\n"
                f"Max: {MAX_RECORD_SECONDS}s · Output: compressed MP4",
                parse_mode="HTML"
            )
            return

        if not _ensure_ffmpeg():
            await update.effective_message.reply_text(
                "❌ ffmpeg not found.\n"
                "Install: <code>sudo apt install ffmpeg</code>",
                parse_mode="HTML"
            )
            return

        try:
            seconds = int(ctx.args[0])
        except ValueError:
            await update.effective_message.reply_text("❌ Duration must be a number (seconds).")
            return

        if seconds < 1:
            await update.effective_message.reply_text("❌ Minimum duration is 1 second.")
            return
        if seconds > MAX_RECORD_SECONDS:
            await update.effective_message.reply_text(
                f"❌ Maximum duration is {MAX_RECORD_SECONDS}s ({MAX_RECORD_SECONDS//60} minutes)."
            )
            return

        status = await update.effective_message.reply_text(
            f"🎬 <b>Recording screen for {seconds}s...</b>\n"
            f"<i>Will send video when complete.</i>",
            parse_mode="HTML"
        )

        with tempfile.TemporaryDirectory() as tmp:
            raw_path = os.path.join(tmp, "recording_raw.mp4")
            final_path = os.path.join(tmp, "recording.mp4")

            success, err = await _record_screen_ffmpeg(seconds, raw_path)

            audio_warning = ""
            if not success:
                await status.edit_text(
                    f"❌ Recording failed.\n<pre>{err[:400]}</pre>",
                    parse_mode="HTML"
                )
                return
            elif err:  # non-empty err on success = audio fallback warning
                audio_warning = f"\n{err}"

            # Re-encode to ensure compatibility and smaller size
            # Preserve audio track if present (-c:a copy keeps it lossless)
            compress_cmd = [
                "ffmpeg", "-y", "-i", raw_path,
                "-vcodec", "libx264",
                "-crf", "32",
                "-preset", "fast",
                "-movflags", "+faststart",
                "-pix_fmt", "yuv420p",
                "-c:a", "aac",        # re-encode audio to aac for compatibility
                "-b:a", "128k",
                final_path
            ]
            proc = await asyncio.create_subprocess_exec(
                *compress_cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()

            use_path = final_path if Path(final_path).exists() else raw_path
            size_bytes = Path(use_path).stat().st_size
            size_mb = size_bytes / (1024 * 1024)

            if size_mb > MAX_VIDEO_MB:
                await status.edit_text(
                    f"⚠️ Video is {size_mb:.1f}MB (Telegram limit: {MAX_VIDEO_MB}MB).\n"
                    "Try a shorter duration.",
                    parse_mode="HTML"
                )
                return

            await status.edit_text("📤 <i>Uploading video...</i>", parse_mode="HTML")

            with open(use_path, "rb") as f:
                video_bytes = f.read()

            buf = io.BytesIO(video_bytes)
            buf.name = f"screen_{int(time.time())}.mp4"

            try:
                await status.delete()
            except Exception:
                pass

            await update.effective_message.reply_video(
                video=buf,
                caption=(
                    f"🎬 Screen recording · {seconds}s\n"
                    f"📦 {size_mb:.1f}MB · {time.strftime('%H:%M:%S')}"
                    f"{audio_warning}"
                ),
                supports_streaming=True,
            )
