"""
salim.handlers.speedtest_handler — Internet Speed Test via Telegram
Feature: /speedtest — runs a speed test and reports download/upload/ping
"""
from __future__ import annotations
import asyncio
import logging
from telegram import Update
from telegram.ext import ContextTypes

logger = logging.getLogger(__name__)


def _ensure_speedtest():
    from salim.auto_install import ensure_one
    return ensure_one("speedtest", "speedtest-cli>=2.1")


class SpeedTestHandlers:

    async def cmd_speedtest(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Run an internet speed test and report results."""
        msg = await update.message.reply_text("🌐 Running speed test… this takes ~15 seconds.")

        if not _ensure_speedtest():
            await msg.edit_text("❌ speedtest-cli could not be installed. Run: pip install speedtest-cli")
            return

        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, _run_speedtest)
            await msg.edit_text(result, parse_mode="HTML")
        except Exception as e:
            await msg.edit_text(f"❌ Speed test failed: {e}")


def _run_speedtest() -> str:
    import speedtest as st
    s = st.Speedtest(secure=True)
    s.get_best_server()
    s.download(threads=4)
    s.upload(threads=4)
    r = s.results.dict()

    down_mbps  = r["download"] / 1_000_000
    up_mbps    = r["upload"]   / 1_000_000
    ping_ms    = r["ping"]
    isp        = r.get("client", {}).get("isp", "Unknown")
    server     = r.get("server", {}).get("name", "?")
    country    = r.get("server", {}).get("country", "")

    emoji_down = "🚀" if down_mbps > 100 else "✅" if down_mbps > 25 else "🐢"
    emoji_up   = "🚀" if up_mbps   > 50  else "✅" if up_mbps   > 10  else "🐢"
    emoji_ping = "⚡" if ping_ms   < 20  else "✅" if ping_ms   < 80  else "🐌"

    return (
        f"<b>🌐 Speed Test Results</b>\n\n"
        f"{emoji_down} <b>Download:</b> {down_mbps:.1f} Mbps\n"
        f"{emoji_up}   <b>Upload:</b>   {up_mbps:.1f} Mbps\n"
        f"{emoji_ping} <b>Ping:</b>     {ping_ms:.0f} ms\n\n"
        f"📡 <b>Server:</b> {server} {country}\n"
        f"🏢 <b>ISP:</b>    {isp}"
    )
