#!/usr/bin/env python3
"""OpenClaw Stock Kit — 진입점

uvx openclaw-stock-kit                → SSE + 브라우저 설정 페이지 (기본)
uvx openclaw-stock-kit -p 9000        → 포트 지정
uvx openclaw-stock-kit --stdio        → stdio 모드 (Claude Code MCP 등록용)
uvx openclaw-stock-kit setup          → Claude Code + OpenClaw 통합 설치
uvx openclaw-stock-kit setup claude-code  → Claude Code 플러그인만
uvx openclaw-stock-kit setup openclaw     → OpenClaw 스킬만
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(name)s | %(message)s")
logger = logging.getLogger("stock-kit")

# ─── 키 저장 디렉토리 (홈 디렉토리 하위, 프로젝트 폴더 아님) ───
CONFIG_DIR = Path(os.getenv(
    "OPENCLAW_STOCK_KIT_HOME",
    Path.home() / ".openclaw-stock-kit"
))
ENV_FILE = CONFIG_DIR / ".env"
_LEGACY_JSON = CONFIG_DIR / "api_keys.json"


def _ensure_config_dir():
    """설정 디렉토리 생성 + 권한 700"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        CONFIG_DIR.chmod(0o700)
    except OSError:
        pass  # Windows에서는 chmod 무시


def _migrate_json_to_env():
    """기존 api_keys.json → .env 마이그레이션 (1회성)"""
    if not _LEGACY_JSON.exists():
        return
    try:
        with open(_LEGACY_JSON, encoding="utf-8") as f:
            keys = json.load(f)
        if keys:
            save_keys(keys)
            logger.info(f"[Keys] api_keys.json → .env 마이그레이션 완료 ({len(keys)}개)")
        _LEGACY_JSON.unlink()
    except Exception as e:
        logger.warning(f"[Keys] JSON 마이그레이션 실패: {e}")


def load_saved_keys():
    """.env 파일에서 저장된 키를 환경변수로 로딩 (기존 환경변수 우선)"""
    _migrate_json_to_env()
    if not ENV_FILE.exists():
        return {}
    try:
        from dotenv import dotenv_values
        keys = dotenv_values(ENV_FILE)
        applied = 0
        for k, v in keys.items():
            if v and k not in os.environ:
                os.environ[k] = str(v)
                applied += 1
        if applied:
            logger.info(f"[Keys] {applied}개 키 로딩 ({ENV_FILE})")
        return dict(keys)
    except Exception as e:
        logger.warning(f"[Keys] 로딩 실패: {e}")
        return {}


def save_keys(keys: dict):
    """키를 .env 파일에 저장 (권한 600)"""
    _ensure_config_dir()
    lines = [f"{k}={v}" for k, v in keys.items() if v]
    ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        ENV_FILE.chmod(0o600)
    except OSError:
        pass  # Windows
    # 환경변수에 즉시 반영
    for k, v in keys.items():
        if v:
            os.environ[k] = str(v)


def _build_mcp():
    """MCP 인스턴스 생성 + 모듈 로딩"""
    from fastmcp import FastMCP

    mcp = FastMCP("OpenClaw Stock Kit")
    modules_status = {}

    # ── DB 연결 (optional) ──
    _pg_conn = None
    try:
        import psycopg2
        _has_pg = True
    except ImportError:
        _has_pg = False

    def _get_pg():
        nonlocal _pg_conn
        if not _has_pg:
            return None
        try:
            if _pg_conn is None or _pg_conn.closed:
                _pg_conn = psycopg2.connect(
                    host=os.getenv("PG_HOST", "localhost"),
                    port=int(os.getenv("PG_PORT", "5432")),
                    dbname=os.getenv("PG_DB", "shared_data_lake"),
                    user=os.getenv("PG_USER", "hub"),
                    password=os.getenv("PG_PASSWORD", ""),
                    connect_timeout=5,
                )
                _pg_conn.autocommit = True
            return _pg_conn
        except Exception:
            return None

    # ── 모듈 로딩 (실패 격리) ──
    def _load(name, fn, desc, extra=None):
        try:
            fn()
            info = {"ok": True, "description": desc}
            if extra:
                info.update(extra)
            modules_status[name] = info
            logger.info(f"[OK] {name}: {desc}")
        except Exception as e:
            modules_status[name] = {"ok": False, "description": desc, "error": str(e)}
            logger.warning(f"[SKIP] {name}: {e}")

    # 모듈 import 경로 설정 (패키지 내부)
    _pkg_dir = Path(__file__).parent
    sys.path.insert(0, str(_pkg_dir))

    # 1) Stock Data Kit (PyKRX, DART, ECOS, 환율, 지배구조)
    def _load_datakit():
        from pykrx_mcp_server import register_tools as reg
        reg(mcp, get_pg=_get_pg)

    _load("datakit", _load_datakit, "Stock Data Kit (PyKRX, DART, ECOS)", {
        "tools": ["datakit_call", "datakit_list_functions", "datakit_get_env_info"],
    })

    # 2) Kiwoom REST API
    def _load_kiwoom():
        from kiwoom_mcp_server import register_tools as reg
        reg(mcp, get_pg=_get_pg)

    _load("kiwoom", _load_kiwoom, "Kiwoom REST API (159 APIs)", {
        "tools": ["kiwoom_call_api", "kiwoom_list_apis", "kiwoom_get_env_info", "kiwoom_api_spec"],
    })

    # 3) KIS 한국투자증권 (네이티브, Docker 불필요)
    def _load_kis():
        from kis_mcp_server import register_tools as reg
        reg(mcp, get_pg=_get_pg)

    _load("kis", _load_kis, "KIS Trading (166 APIs, Docker-free)", {
        "tools": ["kis_domestic_stock", "kis_overseas_stock", "kis_auth", "kis_get_env_info"],
    })

    # 4) News & Telegram (Naver API + Telethon)
    def _load_news():
        from news_mcp_server import register_tools as reg
        reg(mcp, get_pg=_get_pg)

    _load("news", _load_news, "News & Telegram (Naver API, Telegram)", {
        "tools": ["news_search", "news_search_stock", "telegram_auth",
                  "telegram_get_channels", "telegram_get_messages",
                  "news_get_env_info"],
    })

    # 5) Premium (라이선스 키 있을 때만 활성)
    def _load_premium():
        from openclaw_stock_kit.premium import register_premium_tools
        tools = register_premium_tools(mcp)
        return tools

    _load("premium", _load_premium, "Premium Features (briefing, excel, backtest, course)", {
        "tools": ["premium_call", "premium_list_functions"],
    })

    # ── Gateway 메타 도구 ──
    @mcp.tool()
    def gateway_status() -> dict:
        """OpenClaw Stock Kit 전체 상태 + 도구 선택 가이드

        첫 호출 시 이 도구를 사용하면 활성 모듈 확인 + 최적 도구 선택법을 안내받습니다.
        """
        active = sum(1 for m in modules_status.values() if m.get("ok"))
        total_tools = sum(
            len(m.get("tools", []))
            for m in modules_status.values()
            if m.get("ok")
        ) + 1

        # 활성 모듈 기반 라우팅 가이드 생성
        guide = {
            "how_to_choose": "아래 시나리오별 권장 도구를 참고하세요",
            "scenarios": [],
        }

        if modules_status.get("datakit", {}).get("ok"):
            guide["scenarios"].append({
                "when": "과거 주가/시세/거래량/시총/지수 조회 (무료, 키 불필요)",
                "tool": "datakit_call",
                "examples": ["get_price", "get_ohlcv", "get_market_cap", "get_index", "search_stock"],
                "note": "PyKRX 기반. 15분 지연. 과거 데이터/분석에 최적",
            })
            guide["scenarios"].append({
                "when": "DART 공시, ECOS 거시지표, 환율, 지배구조 조회",
                "tool": "datakit_call",
                "examples": ["dart_disclosures", "ecos_indicator", "exchange_rate", "governance_majority"],
                "note": "DART/ECOS/EXIM API 키 필요",
            })

        if modules_status.get("kiwoom", {}).get("ok"):
            guide["scenarios"].append({
                "when": "실시간 현재가/호가/체결/순위 + 매매 주문 (키움 계좌 필요)",
                "tool": "kiwoom_call_api",
                "examples": ["ka10001 (현재가)", "ka10004 (호가)", "kt10000 (매수주문)"],
                "note": "키움 REST API. 실시간 데이터 + 주문. 인증 필요",
            })

        if modules_status.get("kis", {}).get("ok"):
            guide["scenarios"].append({
                "when": "한국투자증권 시세/매매/분석 (KIS 계좌 필요)",
                "tool": "kis_domestic_stock / kis_overseas_stock",
                "examples": ["inquire_price (현재가)", "inquire_balance (잔고)", "order (주문)"],
                "note": "166 APIs. find_api_detail로 파라미터 확인 후 호출",
            })

        if modules_status.get("news", {}).get("ok"):
            guide["scenarios"].append({
                "when": "주식 뉴스 검색, 종목별 뉴스, 텔레그램 채널 메시지",
                "tool": "news_search / news_search_stock / telegram_get_messages",
                "examples": ["삼성전자 뉴스 7일", "텔레그램 @channel 최신 20개"],
                "note": "Naver API 키 필요. 텔레그램 공개채널은 키 없이 가능",
            })

        guide["decision_tree"] = [
            "1. 뉴스/소식 → news_search_stock 또는 telegram_get_messages",
            "2. 과거 주가/차트/시총 → datakit_call (무료, 즉시 사용)",
            "3. 실시간 현재가/호가 → kiwoom_call_api 또는 kis_domestic_stock",
            "4. 매매 주문 → kiwoom_call_api 또는 kis_domestic_stock",
            "5. 공시/거시지표 → datakit_call (DART/ECOS)",
            "6. 종목코드 모를 때 → datakit_call(function='search_stock')",
            "7. 모듈 상태 확인 → gateway_status (이 도구)",
        ]

        return {
            "success": True,
            "data": {
                "gateway": "OpenClaw Stock Kit",
                "active_modules": f"{active}/{len(modules_status)}",
                "total_tools": total_tools,
                "config_dir": str(CONFIG_DIR),
                "db_enabled": _has_pg,
            },
            "modules": modules_status,
            "tool_guide": guide,
        }

    return mcp, modules_status


def _run_serve(args):
    """MCP 서버 실행 (SSE 또는 stdio)"""
    # 저장된 키 로딩
    _ensure_config_dir()
    load_saved_keys()

    # MCP 빌드
    mcp, modules_status = _build_mcp()

    active = sum(1 for m in modules_status.values() if m.get("ok"))
    total_tools = sum(
        len(m.get("tools", []))
        for m in modules_status.values()
        if m.get("ok")
    ) + 1

    if not args.stdio:
        # SSE 모드 (기본): 브라우저 설정 페이지 + MCP SSE
        logger.info("=" * 50)
        logger.info("OpenClaw Stock Kit (SSE mode)")
        logger.info(f"  Modules: {active}/{len(modules_status)}")
        logger.info(f"  Tools:   {total_tools}")
        logger.info(f"  Config:  {CONFIG_DIR}")
        logger.info(f"  Settings: http://localhost:{args.port}")
        logger.info(f"  MCP SSE:  http://localhost:{args.port}/mcp/sse")
        logger.info("=" * 50)

        import uvicorn
        from starlette.applications import Starlette
        from starlette.routing import Route, Mount
        from starlette.responses import HTMLResponse, JSONResponse

        # Settings HTML (패키지 내부)
        _settings_path = Path(__file__).parent / "settings.html"
        _settings_html = _settings_path.read_text(encoding="utf-8") if _settings_path.exists() else "<h1>Settings page not found</h1>"

        async def _page_settings(request):
            return HTMLResponse(_settings_html)

        async def _api_keys(request):
            if request.method == "GET":
                saved = {}
                if ENV_FILE.exists():
                    try:
                        from dotenv import dotenv_values
                        saved = dict(dotenv_values(ENV_FILE))
                    except Exception:
                        pass
                return JSONResponse({"keys": saved})
            elif request.method == "POST":
                try:
                    body = await request.json()
                    new_keys = body.get("keys", {})
                    saved = {}
                    if ENV_FILE.exists():
                        try:
                            from dotenv import dotenv_values
                            saved = dict(dotenv_values(ENV_FILE))
                        except Exception:
                            pass
                    saved.update(new_keys)
                    saved = {k: v for k, v in saved.items() if v}
                    save_keys(saved)
                    return JSONResponse({"success": True})
                except Exception as e:
                    return JSONResponse({"success": False, "error": str(e)}, status_code=400)

        async def _api_status(request):
            return JSONResponse({
                "active_modules": f"{active}/{len(modules_status)}",
                "total_tools": total_tools,
                "config_dir": str(CONFIG_DIR),
                "modules": modules_status,
            })

        sse_app = mcp.http_app(transport="sse")
        app = Starlette(routes=[
            Route("/", _page_settings),
            Route("/settings", _page_settings),
            Route("/api/keys", _api_keys, methods=["GET", "POST"]),
            Route("/api/status", _api_status),
            Mount("/mcp", sse_app),
        ])
        uvicorn.run(app, host="0.0.0.0", port=args.port)
    else:
        # stdio 모드: Claude Code MCP 등록용 (--stdio 플래그)
        logger.info(f"OpenClaw Stock Kit (stdio) — {active} modules, {total_tools} tools")
        mcp.run(transport="stdio")


def _run_setup(args):
    """통합 설치 실행"""
    from openclaw_stock_kit.setup import run_setup
    target = getattr(args, "target", None)
    sys.exit(run_setup(target))


def main():
    parser = argparse.ArgumentParser(
        prog="openclaw-stock-kit",
        description="Korean stock data MCP server (PyKRX + Kiwoom + KIS)",
    )

    # 하위호환: --stdio, -p 플래그는 서브커맨드 없이도 동작
    # argparse에서 subparsers를 optional로 만들기 위해 dest 사용
    subparsers = parser.add_subparsers(dest="command")

    # serve (기본 — 서브커맨드 생략 시)
    serve_parser = subparsers.add_parser(
        "serve", help="Run MCP server (default)",
    )
    serve_parser.add_argument(
        "--stdio", action="store_true",
        help="stdio mode for Claude Code MCP registration",
    )
    serve_parser.add_argument(
        "-p", "--port", type=int, default=8200,
        help="Port for SSE/settings page (default: 8200)",
    )

    # setup
    setup_parser = subparsers.add_parser(
        "setup", help="Install Claude Code plugin and/or OpenClaw skill",
    )
    setup_parser.add_argument(
        "target", nargs="?", default=None,
        choices=["claude-code", "openclaw"],
        help="Install target (default: both)",
    )

    # 하위호환: 서브커맨드 없이 --stdio / -p 사용 가능
    parser.add_argument(
        "--stdio", action="store_true", default=False,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "-p", "--port", type=int, default=8200,
        help=argparse.SUPPRESS,
    )

    args = parser.parse_args()

    if args.command == "setup":
        _run_setup(args)
    else:
        # serve (명시적) 또는 서브커맨드 없음 (하위호환)
        _run_serve(args)


if __name__ == "__main__":
    main()
