#!/usr/bin/env python3
"""한국투자증권(KIS) MCP 도구 — 직접 API 실행 (Docker 불필요)

공식 KIS Trading MCP 아키텍처를 Stock Kit Free에 내장.
GitHub에서 API 코드를 다운로드 → 파라미터 주입 → subprocess 실행.

도구 구성 (8개 카테고리):
  - domestic_stock     : 국내주식 (74 APIs)
  - overseas_stock     : 해외주식 (34 APIs)
  - domestic_bond      : 국내채권 (14 APIs)
  - domestic_futureoption : 국내선물옵션 (20 APIs)
  - overseas_futureoption : 해외선물옵션 (19 APIs)
  - elw               : ELW (1 API)
  - etfetn            : ETF/ETN (2 APIs)
  - auth              : 인증 (2 APIs)

사용 예시:
  kis_domestic_stock({"api_type": "inquire_price", "params": {"stock_name": "삼성전자"}})
  kis_domestic_stock({"api_type": "find_api_detail", "params": {"api_type": "inquire_price"}})
  kis_domestic_stock({"api_type": "find_stock_code", "params": {"stock_name": "삼성전자"}})
"""

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import logging
from pathlib import Path
from typing import Any, Dict

logger = logging.getLogger("kis-native")

# ─── configs 경로 (패키지 내부) ───────────────────────────
_PKG_DIR = Path(__file__).parent
_CONFIGS_DIR = _PKG_DIR / "kis_configs"

# GitHub raw URL for kis_auth.py
_KIS_AUTH_URL = (
    "https://raw.githubusercontent.com/koreainvestment/open-trading-api"
    "/main/examples_llm/kis_auth.py"
)


# ─── ApiExecutor: GitHub 코드 다운로드 → subprocess 실행 ──
class ApiExecutor:
    """공식 KIS Trading MCP의 ApiExecutor를 Python 3.12 호환으로 재구현"""

    def __init__(self, tool_name: str, venv_python: str = None):
        self.tool_name = tool_name
        self.temp_base = tempfile.gettempdir()
        # venv python 경로 자동 탐색
        self.venv_python = venv_python or self._find_python()

    @staticmethod
    def _find_python() -> str:
        """현재 venv의 python 경로 반환"""
        return sys.executable

    def _create_temp_dir(self) -> str:
        ts = int(time.time() * 1_000_000)
        d = os.path.join(self.temp_base, f"kis_{ts}")
        os.makedirs(d, exist_ok=True)
        return d

    @staticmethod
    def _download_file(url: str, dest: str) -> bool:
        try:
            import requests
            r = requests.get(url, timeout=30)
            r.raise_for_status()
            with open(dest, "w", encoding="utf-8") as f:
                f.write(r.text)
            return True
        except Exception as e:
            logger.warning(f"다운로드 실패: {url} → {e}")
            return False

    def _download_kis_auth(self, tmp: str) -> bool:
        return self._download_file(_KIS_AUTH_URL, os.path.join(tmp, "kis_auth.py"))

    def _download_api_code(self, github_url: str, tmp: str, api_type: str) -> str:
        raw = github_url.replace("/tree/", "/").replace(
            "github.com", "raw.githubusercontent.com"
        )
        full_url = f"{raw}/{api_type}.py"
        dest = os.path.join(tmp, "api_code.py")
        if self._download_file(full_url, dest):
            return dest
        raise Exception(f"API 코드 다운로드 실패: {full_url}")

    @staticmethod
    def _extract_trenv_params(code: str) -> Dict[str, str]:
        """kis_auth TRENV 파라미터 자동 매핑"""
        matches = re.findall(r"(\w+)=\w*\.(my_\w+)", code)
        mappings = {}
        for param, attr in matches:
            val = f"ka._TRENV.{attr}"
            mappings[param] = val
            mappings[param.upper()] = val
        return mappings

    @staticmethod
    def _modify_api_code(code_path: str, params: Dict[str, Any], api_type: str) -> str:
        """API 코드에 파라미터 주입 + 실행 코드 추가"""
        with open(code_path, "r", encoding="utf-8") as f:
            code = f.read()

        # sys.path 제거
        code = re.sub(r"sys\.path\.extend\(\[.*?\]\)", "", code, flags=re.DOTALL)
        code = re.sub(r"import sys\n", "", code)

        # 함수 시그니처 추출
        fn_match = re.search(r"def\s+(\w+)\s*\((.*?)\):", code, re.DOTALL)
        if not fn_match:
            raise Exception("코드에서 함수를 찾을 수 없습니다.")

        fn_name = fn_match.group(1)
        fn_params = fn_match.group(2)
        adj = params.copy()

        # max_depth 처리
        if "max_depth" in fn_params:
            adj.setdefault("max_depth", 1)
        else:
            adj.pop("max_depth", None)

        # 보안: 계좌정보 강제 시스템값
        trenv_map = ApiExecutor._extract_trenv_params(code)
        account_map = {
            "cano": "ka._TRENV.my_acct",
            "acnt_prdt_cd": "ka._TRENV.my_prod",
            "my_htsid": "ka._TRENV.my_htsid",
            "user_id": "ka._TRENV.my_htsid",
            **trenv_map,
        }
        for pn, cv in account_map.items():
            if pn in fn_params:
                adj[pn] = cv

        # 거래소 코드 자동 설정
        if "excg_id_dvsn_cd" in fn_params and "excg_id_dvsn_cd" not in adj:
            if api_type.startswith("domestic"):
                adj["excg_id_dvsn_cd"] = '"KRX"'

        # 실전/모의 분기
        env_dv = params.get("env_dv", "real")
        auth_code = 'ka.auth("vps")' if env_dv == "demo" else "ka.auth()"

        # 실행 코드 생성
        param_strs = []
        for k, v in adj.items():
            if isinstance(v, str) and v.startswith("ka._TRENV."):
                param_strs.append(f"{k}={v}")
            else:
                param_strs.append(f"{k}={repr(v)}")

        call_code = f"""
# API 함수 호출
if __name__ == "__main__":
    try:
        {auth_code}
        result = {fn_name}({", ".join(param_strs)})
    except TypeError as e:
        print(f"TypeError: {{str(e)}}")
        import sys; sys.exit(1)
    try:
        if isinstance(result, tuple):
            output = {{}}
            for i, item in enumerate(result):
                if hasattr(item, 'to_dict'):
                    output[f"output{{i+1}}"] = item.to_dict('records') if not item.empty else []
                else:
                    output[f"output{{i+1}}"] = str(item)
            import json; print(json.dumps(output, ensure_ascii=False, indent=2))
        elif hasattr(result, 'empty') and not result.empty:
            print(result.to_json(orient='records', force_ascii=False))
        elif isinstance(result, dict):
            import json; print(json.dumps(result, ensure_ascii=False))
        elif isinstance(result, (list, tuple)):
            import json; print(json.dumps(result, ensure_ascii=False))
        else:
            print(str(result))
    except Exception as e:
        print(f"오류: {{str(e)}}")
"""
        modified = code + call_code
        with open(code_path, "w", encoding="utf-8") as f:
            f.write(modified)
        return code_path

    def execute_api(self, api_type: str, params: Dict[str, Any], github_url: str) -> Dict[str, Any]:
        """API 실행: 다운로드 → 수정 → subprocess"""
        tmp = None
        t0 = time.time()
        try:
            tmp = self._create_temp_dir()

            if not self._download_kis_auth(tmp):
                raise Exception("kis_auth.py 다운로드 실패")

            code_path = self._download_api_code(github_url, tmp, api_type)
            self._modify_api_code(code_path, params, api_type)

            result = subprocess.run(
                [self.venv_python, "api_code.py"],
                cwd=tmp,
                capture_output=True,
                text=True,
                timeout=30,
            )

            elapsed = f"{time.time() - t0:.2f}s"
            if result.returncode == 0:
                return {
                    "success": True,
                    "data": result.stdout,
                    "api_type": api_type,
                    "execution_time": elapsed,
                }
            else:
                return {
                    "success": False,
                    "error": result.stderr or result.stdout,
                    "api_type": api_type,
                    "execution_time": elapsed,
                }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "실행 시간 초과 (30초)", "api_type": api_type}
        except Exception as e:
            return {"success": False, "error": str(e), "api_type": api_type}
        finally:
            if tmp and os.path.exists(tmp):
                shutil.rmtree(tmp, ignore_errors=True)


# ─── KIS 도구 팩토리 ─────────────────────────────────────

def _load_config(name: str) -> dict:
    """configs JSON 로딩"""
    path = _CONFIGS_DIR / f"{name}.json"
    if not path.exists():
        return {"apis": {}}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _build_description(tool_name: str, config: dict) -> str:
    """configs JSON에서 MCP 도구 설명 생성"""
    info = config.get("tool_info", {})
    apis = config.get("apis", {})
    lines = [info.get("introduce", f"KIS {tool_name} API")]
    append = info.get("introduce_append", "").strip()
    if append:
        lines.append(append)
    lines.append("")
    lines.append(f"[지원 기능 — {len(apis)}개 API]")
    for atype, ainfo in apis.items():
        lines.append(f"- {ainfo.get('name', atype)} (api_type: \"{atype}\")")
    lines.append("")
    lines.append("사용 방법:")
    lines.append("1. find_api_detail로 API 상세 파라미터 확인")
    lines.append("2. api_type + params로 호출")
    lines.append("3. 종목명 검색: stock_name='삼성전자' 사용 가능")
    lines.append("4. 모의투자: env_dv='demo' 추가")
    lines.append("")
    lines.append("자동 처리: cano, acnt_prdt_cd (계좌정보는 시스템 자동 설정)")
    examples = info.get("examples", [])
    if examples:
        lines.append("")
        lines.append("예시:")
        for ex in examples[:3]:
            ps = json.dumps(ex.get("params", {}), ensure_ascii=False)
            lines.append(f'  kis_{tool_name}({{"api_type": "{ex["api_type"]}", "params": {ps}}})')
    return "\n".join(lines)


def _make_tool_fn(tool_name: str, config: dict, executor: ApiExecutor):
    """클로저로 MCP 도구 함수 생성"""
    apis = config.get("apis", {})

    def tool_fn(api_type: str, params: str = "{}") -> dict:
        try:
            p = json.loads(params) if isinstance(params, str) else params
        except json.JSONDecodeError:
            return {"success": False, "error": "params JSON 파싱 실패"}

        # 특수 api_type: find_api_detail
        if api_type == "find_api_detail":
            target = p.get("api_type", "")
            if target not in apis:
                return {
                    "success": False,
                    "error": f"지원하지 않는 API: {target}",
                    "available": list(apis.keys()),
                }
            info = apis[target]
            param_details = {}
            for pn, pi in info.get("params", {}).items():
                param_details[pn] = {
                    "name": pi.get("name", pn),
                    "type": pi.get("type", "str"),
                    "required": pi.get("required", False),
                    "default_value": pi.get("default_value"),
                    "description": pi.get("description", ""),
                }
            return {
                "success": True,
                "data": {
                    "api_type": target,
                    "name": info.get("name", ""),
                    "method": info.get("method", ""),
                    "api_path": info.get("api_path", ""),
                    "params": param_details,
                },
            }

        # 특수 api_type: find_stock_code
        if api_type == "find_stock_code":
            stock = p.get("stock_name", "")
            if not stock:
                return {"success": False, "error": "stock_name 필요"}
            # PyKRX로 종목코드 검색 (의존성 최소화)
            try:
                from pykrx import stock as pykrx_stock
                tickers = pykrx_stock.get_market_ticker_list()
                for t in tickers:
                    name = pykrx_stock.get_market_ticker_name(t)
                    if stock in name or name in stock:
                        return {
                            "success": True,
                            "data": {
                                "stock_code": t,
                                "stock_name": name,
                                "message": f"'{stock}' → {t} ({name})",
                            },
                        }
                return {"success": False, "error": f"종목 '{stock}' 찾을 수 없음"}
            except Exception as e:
                return {"success": False, "error": f"종목 검색 실패: {e}"}

        # 일반 API 호출
        if api_type not in apis:
            return {
                "success": False,
                "error": f"지원하지 않는 API: {api_type}",
                "available": list(apis.keys())[:20],
            }

        # stock_name → 종목코드 자동 변환
        if "stock_name" in p:
            try:
                from pykrx import stock as pykrx_stock
                stock = p.pop("stock_name")
                tickers = pykrx_stock.get_market_ticker_list()
                for t in tickers:
                    name = pykrx_stock.get_market_ticker_name(t)
                    if stock in name or name in stock:
                        p["pdno"] = t
                        logger.info(f"종목 변환: {stock} → {t}")
                        break
            except Exception:
                pass

        github_url = apis[api_type].get("github_url", "")
        if not github_url:
            return {"success": False, "error": f"GitHub URL 없음: {api_type}"}

        return executor.execute_api(api_type, p, github_url)

    return tool_fn


# ─── 도구 카테고리 정의 ──────────────────────────────────

_KIS_TOOLS = [
    ("domestic_stock", "국내주식 시세/매매/분석 (KIS 계좌 필요)"),
    ("overseas_stock", "해외주식 시세/매매 (KIS 계좌 필요)"),
    ("domestic_bond", "국내채권 (KIS 계좌 필요)"),
    ("domestic_futureoption", "국내선물옵션 (KIS 계좌 필요)"),
    ("overseas_futureoption", "해외선물옵션 (KIS 계좌 필요)"),
    ("elw", "ELW (KIS 계좌 필요)"),
    ("etfetn", "ETF/ETN (KIS 계좌 필요)"),
    ("auth", "KIS 인증 관리"),
]


# ─── 공개 등록 함수 ──────────────────────────────────────

def register_tools(mcp, get_pg=None):
    """FastMCP 인스턴스에 KIS 도구 등록

    각 카테고리별로 하나의 MCP 도구가 등록됩니다:
    - kis_domestic_stock, kis_overseas_stock, kis_auth, ...

    Args:
        mcp: FastMCP 인스턴스
        get_pg: PostgreSQL getter (분양 환경용, 없으면 무시)
    """
    # KIS 키 확인
    app_key = os.getenv("KIS_APP_KEY", "")
    if not app_key:
        raise ValueError("KIS_APP_KEY 미설정 — Settings 페이지에서 KIS 키를 입력하세요")

    registered = []
    for tool_name, short_desc in _KIS_TOOLS:
        config = _load_config(tool_name)
        if not config.get("apis"):
            continue

        executor = ApiExecutor(tool_name)
        fn = _make_tool_fn(tool_name, config, executor)
        desc = _build_description(tool_name, config)

        # FastMCP 도구 등록
        mcp_name = f"kis_{tool_name}"
        fn.__name__ = mcp_name
        fn.__doc__ = desc
        mcp.tool()(fn)
        registered.append(mcp_name)
        logger.info(f"  KIS 도구 등록: {mcp_name} ({len(config.get('apis', {}))} APIs)")

    # 환경 정보 도구
    @mcp.tool()
    def kis_get_env_info() -> dict:
        """KIS 환경 정보 조회 (실전/모의, 키 설정 상태)"""
        return {
            "success": True,
            "data": {
                "mode": "native (Docker-free)",
                "app_key_set": bool(os.getenv("KIS_APP_KEY")),
                "app_secret_set": bool(os.getenv("KIS_APP_SECRET")),
                "hts_id": os.getenv("KIS_HTS_ID", ""),
                "tools_registered": registered,
                "total_tools": len(registered),
            },
        }

    logger.info(f"  KIS 총 {len(registered)}개 카테고리 등록 완료 (Docker-free)")


if __name__ == "__main__":
    from fastmcp import FastMCP
    mcp = FastMCP("KIS Trading MCP (Native)")
    os.environ.setdefault("KIS_APP_KEY", "test")  # 테스트용
    register_tools(mcp)
    print(f"KIS Native MCP — {len(_KIS_TOOLS)} categories")
    mcp.run(transport="sse", host="0.0.0.0", port=8202)
