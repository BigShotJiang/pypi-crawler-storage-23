---
name: stock-kit
description: |
  Korean stock market expert skill. Provides real-time quotes, trading, news, and disclosures via MCP tools.
  Delegates all work to the stock-kit agent which handles MCP tool routing.

  Triggers: 주식, 현재가, 시세, 매매, 주문, 잔고, 뉴스, 공시, 차트,
  종목, 코스피, 코스닥, 환율, 금리, 시가총액, 급등주, 호가, 배당,
  stock, price, trade, order, balance, news, disclosure, chart, KOSPI

  Do NOT use for: general knowledge, coding, non-stock questions, cryptocurrency
argument-hint: "[종목명|질문]"
user-invocable: true
agent: stock-kit:stock-kit
allowed-tools:
  - Bash
  - Read
---

# Stock Analysis Skill

## Overview

Korean stock market analysis skill powered by MCP tools.
All queries are routed to the `stock-kit` agent which interprets intent and calls the optimal MCP tool.

## Actions

| Action | Description | Example |
|--------|-------------|---------|
| Price query | Real-time stock price | `/stock 삼성전자 현재가` |
| Market ranking | Top gainers, volume, market cap | `/stock 급등주 순위` |
| Chart data | Daily/weekly/monthly OHLCV | `/stock 삼성전자 일봉` |
| Historical data | Past price trends | `/stock 삼성전자 최근 3개월` |
| News | Stock-related news | `/stock 삼성전자 뉴스` |
| Disclosure | DART corporate filings | `/stock 삼성전자 공시` |
| Fundamentals | PER, PBR, dividend yield | `/stock 삼성전자 PER` |
| Economic data | Interest rates, GDP, exchange rates | `/stock 원달러 환율` |
| Index | KOSPI/KOSDAQ index data | `/stock 코스피 지수` |
| Trading | Buy/sell orders (with confirmation) | `/stock 삼성전자 10주 매수` |
| Portfolio | Account balance and P&L | `/stock 내 잔고` |

## Data Sources

| Source | Coverage | Key Feature |
|--------|----------|-------------|
| Kiwoom (키움) | 159 APIs | Real-time quotes, trading |
| DataKit (PyKRX) | Free historical data | No API key required |
| DataKit (DART) | Corporate disclosures | Financial statements |
| DataKit (ECOS) | Economic indicators | Interest rates, GDP |
| News (Naver) | Stock/keyword news | Latest articles |
| Telegram | Channel messages | Community sentiment |
| KIS | 166 APIs | Alternative broker |

## Usage Examples

```
/stock 삼성전자                    → 현재가 조회
/stock 오늘 급등주                 → 상승률 순위
/stock 삼성전자 최근 6개월 추이    → 과거 주가 데이터
/stock 반도체 관련 뉴스            → 키워드 뉴스 검색
/stock 코스피 지수                 → KOSPI 지수 조회
/stock 원달러 환율                 → 환율 조회
/stock 내 잔고                     → 계좌 잔고 조회
```
