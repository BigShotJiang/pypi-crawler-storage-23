---
name: stock-kit
description: |
  Korean stock market expert skill for OpenClaw.
  Provides real-time quotes, trading, news, and disclosures via MCP tools.

  Triggers: 주식, 현재가, 시세, 매매, 주문, 잔고, 뉴스, 공시, 차트,
  종목, 코스피, 코스닥, 환율, 금리, 시가총액, 급등주, 호가, 배당,
  stock, price, trade, order, balance, news, disclosure, chart, KOSPI

  Do NOT use for: general knowledge, coding, non-stock questions, cryptocurrency
argument-hint: "[종목명|질문]"
user-invocable: true
mcp-server: stock-kit
---

# Stock Kit Skill (OpenClaw)

## Overview

Korean stock market expert skill powered by MCP tools.
Interprets natural language queries about stocks and routes them to the optimal MCP tool.

## MCP Server

This skill requires the `stock-kit` MCP server:

```bash
# Start the MCP server
uvx openclaw-stock-kit
```

## Available Tools

| Module | Tool | Description |
|--------|------|-------------|
| DataKit | `datakit_call` | Historical prices, DART, ECOS, exchange rates (13 functions) |
| Kiwoom | `kiwoom_call_api` | Real-time quotes, trading (159 APIs) |
| KIS | `kis_call_tool` | Korea Investment Securities (68 APIs) |
| News | `news_search`, `news_search_stock` | Naver news search |
| Telegram | `telegram_get_messages` | Telegram channel messages |
| Gateway | `gateway_status` | Module status check |

## Actions

| Action | Description | Example |
|--------|-------------|---------|
| Price query | Real-time stock price | "삼성전자 현재가" |
| Market ranking | Top gainers, volume | "급등주 순위" |
| Chart data | Daily/weekly/monthly OHLCV | "삼성전자 일봉" |
| Historical data | Past price trends | "삼성전자 최근 3개월" |
| News | Stock-related news | "삼성전자 뉴스" |
| Disclosure | DART corporate filings | "삼성전자 공시" |
| Fundamentals | PER, PBR, dividend yield | "삼성전자 PER" |
| Economic data | Interest rates, GDP, exchange rates | "원달러 환율" |
| Index | KOSPI/KOSDAQ index data | "코스피 지수" |
| Trading | Buy/sell orders (with confirmation) | "삼성전자 10주 매수" |
| Portfolio | Account balance and P&L | "내 잔고" |

## Data Sources

| Source | Coverage | Key Feature |
|--------|----------|-------------|
| Kiwoom (키움) | 159 APIs | Real-time quotes, trading |
| DataKit (PyKRX) | Free historical data | No API key required |
| DataKit (DART) | Corporate disclosures | Financial statements |
| DataKit (ECOS) | Economic indicators | Interest rates, GDP |
| News (Naver) | Stock/keyword news | Latest articles |
| Telegram | Channel messages | Community sentiment |
| KIS | 166 APIs | Alternative broker |
