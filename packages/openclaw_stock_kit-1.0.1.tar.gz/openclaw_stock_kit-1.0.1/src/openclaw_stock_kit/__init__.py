"""OpenClaw Stock Kit — Korean stock data MCP server.

Usage:
    uvx openclaw-stock-kit                     # SSE + browser settings (default)
    uvx openclaw-stock-kit -p 9000             # custom port
    uvx openclaw-stock-kit --stdio             # stdio mode (Claude Code MCP)
"""

__version__ = "0.2.2"
