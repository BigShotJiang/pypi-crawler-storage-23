"""OpenClaw Stock Kit -통합 설치 모듈

uvx openclaw-stock-kit setup              → Claude Code + OpenClaw 모두 설치
uvx openclaw-stock-kit setup claude-code   → Claude Code 플러그인만
uvx openclaw-stock-kit setup openclaw      → OpenClaw 스킬만
"""

import io
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

# Windows cp949 대응: stdout을 UTF-8로 강제
if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
if sys.stderr.encoding and sys.stderr.encoding.lower() not in ("utf-8", "utf8"):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# 번들 데이터 경로 (패키지 내부)
_EXTENSIONS_DIR = Path(__file__).parent / "extensions"


def _print(msg: str):
    print(f"  {msg}")


def _print_ok(msg: str):
    print(f"  [OK] {msg}")


def _print_skip(msg: str):
    print(f"  [SKIP] {msg}")


def _print_err(msg: str):
    print(f"  [ERROR] {msg}", file=sys.stderr)


def _copytree(src: Path, dst: Path):
    """src 디렉토리를 dst로 병합 복사 (기존 파일 덮어쓰기, 삭제 안 함)"""
    shutil.copytree(src, dst, dirs_exist_ok=True)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


# ─── Claude Code 플러그인 설치 ───


def setup_claude_code() -> bool:
    """Claude Code 플러그인 설치

    1. ~/.claude/plugins/marketplaces/stock-kit/ 에 플러그인 파일 복사
    2. installed_plugins.json 에 항목 추가
    3. known_marketplaces.json 에 항목 추가
    """
    print("\n--- Claude Code Plugin ---")

    src = _EXTENSIONS_DIR / "claude-code"
    if not src.exists():
        _print_err(f"번들 데이터 없음: {src}")
        return False

    # 플러그인 설치 경로
    claude_dir = Path.home() / ".claude"
    plugins_dir = claude_dir / "plugins"
    install_dir = plugins_dir / "marketplaces" / "stock-kit"

    # 1) 디렉토리 생성
    install_dir.mkdir(parents=True, exist_ok=True)

    # 2) 플러그인 파일 복사
    for item in src.iterdir():
        dst_item = install_dir / item.name
        if item.is_dir():
            _copytree(item, dst_item)
        else:
            shutil.copy2(item, dst_item)
    _print_ok(f"플러그인 파일 복사 → {install_dir}")

    # 3) plugin.json에서 버전 읽기
    plugin_json_path = install_dir / ".claude-plugin" / "plugin.json"
    version = "0.1.0"
    if plugin_json_path.exists():
        try:
            with open(plugin_json_path, encoding="utf-8") as f:
                pdata = json.load(f)
            version = pdata.get("version", version)
        except Exception:
            pass

    # 4) installed_plugins.json 업데이트
    installed_path = plugins_dir / "installed_plugins.json"
    installed = {"version": 2, "plugins": {}}
    if installed_path.exists():
        try:
            with open(installed_path, encoding="utf-8") as f:
                installed = json.load(f)
        except Exception:
            pass

    now = _now_iso()
    plugin_key = "stock-kit@stock-kit"
    # 기존 항목이 있으면 업데이트, 없으면 추가
    installed.setdefault("plugins", {})[plugin_key] = [
        {
            "scope": "user",
            "installPath": str(install_dir),
            "version": version,
            "installedAt": now,
            "lastUpdated": now,
        }
    ]

    with open(installed_path, "w", encoding="utf-8") as f:
        json.dump(installed, f, indent=2, ensure_ascii=False)
    _print_ok(f"installed_plugins.json 업데이트 (key={plugin_key})")

    # 5) known_marketplaces.json 업데이트
    known_path = plugins_dir / "known_marketplaces.json"
    known = {}
    if known_path.exists():
        try:
            with open(known_path, encoding="utf-8") as f:
                known = json.load(f)
        except Exception:
            pass

    known["stock-kit"] = {
        "source": {
            "source": "local",
            "repo": "readinginvestor/stock-kit",
        },
        "installLocation": str(install_dir),
        "lastUpdated": now,
    }

    with open(known_path, "w", encoding="utf-8") as f:
        json.dump(known, f, indent=2, ensure_ascii=False)
    _print_ok("known_marketplaces.json 업데이트")

    _print("")
    _print("Claude Code 플러그인 설치 완료!")
    _print(f"  경로: {install_dir}")
    _print("  Claude Code를 재시작하면 자동 로딩됩니다.")
    _print("  /stock 명령으로 주식 데이터를 조회하세요.")
    return True


# ─── OpenClaw 스킬 설치 ───


def setup_openclaw() -> bool:
    """OpenClaw 스킬 + 에이전트 설치

    1. OPENCLAW_WORKSPACE 또는 ~/.openclaw/workspace/ 확인
    2. extensions/openclaw/skills/ → {workspace}/skills/ 복사
    3. extensions/openclaw/agents/ → {workspace}/agents/ 복사
    """
    print("\n--- OpenClaw Skill + Agent ---")

    src = _EXTENSIONS_DIR / "openclaw"
    if not src.exists():
        _print_err(f"번들 데이터 없음: {src}")
        return False

    # 워크스페이스 경로 결정
    workspace = os.getenv("OPENCLAW_WORKSPACE")
    if workspace:
        workspace = Path(workspace)
    else:
        workspace = Path.home() / ".openclaw" / "workspace"

    # 스킬 복사
    src_skills = src / "skills"
    if src_skills.exists():
        skills_dir = workspace / "skills"
        skills_dir.mkdir(parents=True, exist_ok=True)
        for item in src_skills.iterdir():
            dst_item = skills_dir / item.name
            if item.is_dir():
                _copytree(item, dst_item)
            else:
                shutil.copy2(item, dst_item)
        _print_ok(f"스킬 복사 → {skills_dir / 'stock-kit'}")

    # 에이전트 복사
    src_agents = src / "agents"
    if src_agents.exists():
        agents_dir = workspace / "agents"
        agents_dir.mkdir(parents=True, exist_ok=True)
        for item in src_agents.iterdir():
            dst_item = agents_dir / item.name
            if item.is_dir():
                _copytree(item, dst_item)
            else:
                shutil.copy2(item, dst_item)
        _print_ok(f"에이전트 복사 → {agents_dir / 'stock-kit.md'}")

    _print("")
    _print("OpenClaw 설치 완료! (스킬 + 에이전트)")
    _print(f"  스킬: {workspace / 'skills' / 'stock-kit'}")
    _print(f"  에이전트: {workspace / 'agents' / 'stock-kit.md'}")
    _print("  MCP 서버 실행: uvx openclaw-stock-kit")
    return True


# ─── 통합 설치 ───


def setup_all() -> bool:
    """Claude Code + OpenClaw 모두 설치"""
    print("=" * 50)
    print("OpenClaw Stock Kit -통합 설치")
    print("=" * 50)

    ok_cc = setup_claude_code()
    ok_oc = setup_openclaw()

    print("\n" + "=" * 50)
    if ok_cc and ok_oc:
        print("모든 설치 완료!")
    elif ok_cc:
        print("Claude Code 설치 완료 (OpenClaw 실패)")
    elif ok_oc:
        print("OpenClaw 설치 완료 (Claude Code 실패)")
    else:
        print("설치 실패")
    print("=" * 50)

    return ok_cc or ok_oc


def run_setup(target: str | None = None) -> int:
    """CLI에서 호출되는 진입점

    Args:
        target: "claude-code", "openclaw", 또는 None (둘 다)

    Returns:
        종료 코드 (0=성공, 1=실패)
    """
    if target == "claude-code":
        print("=" * 50)
        print("OpenClaw Stock Kit -Claude Code 플러그인 설치")
        print("=" * 50)
        ok = setup_claude_code()
    elif target == "openclaw":
        print("=" * 50)
        print("OpenClaw Stock Kit -OpenClaw 스킬 설치")
        print("=" * 50)
        ok = setup_openclaw()
    else:
        ok = setup_all()

    return 0 if ok else 1
