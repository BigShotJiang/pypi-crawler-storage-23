# OpenClaw Stock Kit

Korean stock data MCP server — one command install for Claude Code, Cursor, and OpenClaw.

```bash
uvx openclaw-stock-kit
```

## Install

### One-command setup (Claude Code + OpenClaw)

```bash
# Install Claude Code plugin + OpenClaw skill at once
uvx openclaw-stock-kit setup

# Or install individually
uvx openclaw-stock-kit setup claude-code   # Claude Code plugin only
uvx openclaw-stock-kit setup openclaw      # OpenClaw skill only
```

This installs:
- **Claude Code**: Plugin files to `~/.claude/plugins/marketplaces/stock-kit/` (agent, /stock command, MCP config)
- **OpenClaw**: Skill to `~/.openclaw/workspace/skills/stock-expert/`

### Manual setup

```bash
# 1. Run (browser settings page opens at http://localhost:8200)
uvx openclaw-stock-kit

# 2. Enter API keys in browser → Save

# 3. Register as MCP (Claude Code)
claude mcp add stock-kit -- uvx openclaw-stock-kit --stdio
```

### Cursor / Claude Desktop

```json
{
  "mcpServers": {
    "stock-kit": {
      "command": "uvx",
      "args": ["openclaw-stock-kit", "--stdio"]
    }
  }
}
```

## Free Tools (10 MCP tools)

| Module | Tools | Source |
|--------|-------|--------|
| **Stock Data Kit** | `datakit_call` (13 functions) | PyKRX, DART, ECOS, Exchange Rate |
| **Kiwoom** | `kiwoom_call_api` (159 APIs) | Kiwoom REST API |
| **KIS** | `kis_call_tool` (68 APIs) | Korea Investment & Securities |
| **Gateway** | `gateway_status` | Status check |

> **ABI Contract**: Tool names (`datakit_call`, `kiwoom_call_api`, etc.) are stable and will never be renamed — only deprecated with 3-version notice. See [STANDARD.md](STANDARD.md).

### API Keys (free to get)

| Key | Source | Required |
|-----|--------|----------|
| `DART_API_KEY` | [DART](https://opendart.fss.or.kr/) | For disclosures |
| `ECOS_API_KEY` | [ECOS](https://ecos.bok.or.kr/) | For macro indicators |
| `EXIM_API_KEY` | [EXIM Bank](https://www.koreaexim.go.kr/) | For exchange rates |
| Kiwoom credentials | [Kiwoom](https://www.kiwoom.com/) | For Kiwoom APIs |
| KIS credentials | [KIS](https://www.truefriend.com/) | For KIS APIs |

PyKRX (stock prices, supply/demand) works without any API key.

### Response Format

All tools return a standardized response:

```json
{"ok": true, "source": "datakit", "asof": "2026-02-17T09:30:00+09:00", "data": {...}, "error": null}
```

See [STANDARD.md](STANDARD.md) for full schema and error codes.

## Premium (license key)

| Feature | Description |
|---------|-------------|
| Morning/Afternoon Briefing | AI-generated market analysis |
| TOP30/Memo Excel | Daily stock rankings & analysis Excel |
| Backtesting | Trading strategy simulation (종가매매 etc.) |
| Trading Courses | Step-by-step trading methodology |

```bash
# Set license key via settings page or environment variable
export OPENCLAW_LICENSE_KEY=OCKP-XXXXXX-XXXXXX-XXXXXX
```

**Premium requires server verification.** License keys are validated against the OpenClaw license server on each session. If the server is unreachable, a 24-hour grace period applies for previously verified keys. Without prior server verification, premium features remain locked — free tools continue to work normally.

Purchase: [openclaw.ai/premium](https://openclaw.ai/premium)

## Modes

```bash
uvx openclaw-stock-kit                # SSE + settings page (default)
uvx openclaw-stock-kit serve          # same as above (explicit)
uvx openclaw-stock-kit -p 9000        # custom port
uvx openclaw-stock-kit --stdio        # stdio for MCP registration
uvx openclaw-stock-kit setup          # install Claude Code plugin + OpenClaw skill
```

## Version Pinning

For CI/production environments, pin to a specific version:

```bash
uvx openclaw-stock-kit==1.0.3         # exact version
uvx openclaw-stock-kit>=1.0,<2.0      # compatible range
```

## Security

- **API key storage**: `~/.openclaw-stock-kit/api_keys.json` (directory 700, file 600 permissions)
- **License verification**: Server-side verification required (fail-closed). 24h grace for previously verified keys when server is unreachable. Local HMAC is format-check only — it does not grant premium access.
- **Network**: All external API calls use HTTPS (localhost dev excluded)
- **No telemetry**: No usage data collected

## Data Sources

- [PyKRX](https://github.com/sharebook-kr/pykrx) — KRX public data
- [OpenDART](https://opendart.fss.or.kr/) — Electronic disclosure
- [ECOS](https://ecos.bok.or.kr/) — Bank of Korea statistics
- [EXIM Bank](https://www.koreaexim.go.kr/) — Exchange rates
- [Kiwoom](https://www.kiwoom.com/) — Kiwoom REST API (159 endpoints)
- [KIS](https://www.truefriend.com/) — Korea Investment Open API (68 endpoints)

## Requirements

- Python 3.11+
- [uv](https://docs.astral.sh/uv/getting-started/installation/) package manager

## License

MIT
