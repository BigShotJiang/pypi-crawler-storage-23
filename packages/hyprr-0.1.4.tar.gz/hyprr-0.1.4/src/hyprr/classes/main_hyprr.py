from pathlib import Path
import subprocess
import time

class Hyprr:
    def __init__(self):
        self.home = Path.home()
        self.config_dir = Path.home() / ".config/"

    @staticmethod
    def reload_environment():
        programs = [
            "hyprpaper",
            "waybar",
            "wofi",
        ]

        for program in programs:
            subprocess.run(
                ["pkill", "-x", program],
                stderr=subprocess.DEVNULL,
            )

            if program == "wofi":
                continue

            time.sleep(0.01)

            subprocess.Popen(
                [program],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )

        print("donrr.")
