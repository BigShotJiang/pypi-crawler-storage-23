from .classes.hyprpaper import Hyprpaper
import sys

def main():
    args = sys.argv[1:]

    hyprpaper = False
    character = None

    while args:
        arg = args.pop(0)

        match arg:
            case "hyprpaper":
                hyprpaper = True
                try:
                    argument = args.pop(0)
                except IndexError:
                    pass
                else:
                    character = argument
                    break

            case _:
                print("Unknown option...")
                sys.exit(1)

    if hyprpaper:
        hypr = Hyprpaper()
        if character:
            hypr.change_wallpaper_manually(character)

        else:
            hypr.change_wallpaper_randomly()

        hypr.reload_environment()

if __name__ == "__main__": 
    main()
    
