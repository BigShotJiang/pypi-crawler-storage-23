"""Statistical learning models for commerce analytics.

Provides standard business engines with pluggable backends:
    - inventory: EOQ, safety stock, reorder point, ABC classification (builtin + stockpyl)
    - forecasting: MA, ETS, Croston, seasonal decompose (builtin + statsforecast)
    - analytics: RFM segmentation, LTV, cohort retention (sklearn + polars)

Usage:
    from platoon.learning.providers import get_provider, list_providers

    # Auto-select best available backend
    fc = get_provider("forecasting")
    result = fc.forecast(series, horizon=14)

    inv = get_provider("inventory")
    eoq = inv.eoq(demand=10000, ordering_cost=50, holding_cost=2)

    analytics = get_provider("analytics")
    rfm = analytics.rfm_segment(orders)

    # See what's available
    list_providers()
"""

# Import modules to trigger provider registration
from platoon.learning import inventory  # noqa: F401
from platoon.learning import forecasting  # noqa: F401
from platoon.learning import analytics  # noqa: F401
from platoon.learning import optimization  # noqa: F401
from platoon.learning import recommendations  # noqa: F401
from platoon.learning.providers import get_provider, list_providers  # noqa: F401
