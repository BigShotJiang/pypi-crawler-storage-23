"""Platoon MCP server — exposes learning tools via FastMCP."""


def create_mcp_server():
    """Lazy import to avoid circular issues with ``python -m``."""
    from platoon.mcp.server import create_mcp_server as _create

    return _create()


from platoon.mcp.agent import COMMERCE_ANALYST

__all__ = ["create_mcp_server", "COMMERCE_ANALYST"]
