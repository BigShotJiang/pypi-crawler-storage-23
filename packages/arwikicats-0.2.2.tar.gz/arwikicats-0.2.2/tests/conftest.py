"""Test configuration for the test-suite."""

import json
import os
import random
from pathlib import Path

import pytest


@pytest.fixture
def load_json_data(request: pytest.FixtureRequest):
    file_path = request.param
    file_path = Path(file_path)

    if not file_path.exists():
        pytest.skip(f"File {file_path} not found")

    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f), file_path.stem


def pytest_configure(config: pytest.Config) -> None:
    """
    Global test-suite normalization.
    - Force UTF-8 I/O (important on Windows for Arabic output)
    - Make random deterministic (avoid flaky order / generation)
    """
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")

    # Make randomness deterministic across workers/processes
    random.seed(0)


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add custom command line options."""
    parser.addoption(
        "--rune2e",
        action="store_true",
        default=False,
        help="Run end-to-end tests (disabled by default in quick mode)",
    )


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """
    Automatically apply markers based on test location.

    Marker rules:
    - tests/unit/* → @pytest.mark.unit
    - tests/integration/* → @pytest.mark.integration
    - tests/e2e/* → @pytest.mark.e2e
    - tests/big/* → @pytest.mark.big
    """
    run_e2e = config.getoption("--rune2e")

    for item in items:
        path_str = str(item.fspath)

        # Auto-mark based on file path
        if "tests" + os.sep + "unit" in path_str:
            item.add_marker(pytest.mark.unit)
            item.add_marker(pytest.mark.fast)
        elif "tests" + os.sep + "integration" in path_str:
            item.add_marker(pytest.mark.integration)
        elif "tests" + os.sep + "big" in path_str:
            item.add_marker(pytest.mark.big)
        elif "tests" + os.sep + "e2e" in path_str:
            item.add_marker(pytest.mark.e2e)
            if not run_e2e:
                item.add_marker(pytest.mark.skip(reason="E2E tests disabled, use --rune2e"))
