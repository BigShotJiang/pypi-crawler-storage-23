from .bases import AuthModel as AuthModel
