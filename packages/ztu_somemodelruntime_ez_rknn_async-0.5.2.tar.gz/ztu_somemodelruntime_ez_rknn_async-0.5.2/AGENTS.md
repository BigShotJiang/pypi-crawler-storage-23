## 项目编译方法

python3 -m pip wheel . -w dist --no-deps --config-settings=cmake.build-type=Debug