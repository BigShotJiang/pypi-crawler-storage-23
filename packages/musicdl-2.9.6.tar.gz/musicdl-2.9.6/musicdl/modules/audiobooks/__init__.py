'''initialize'''
from .lizhi import LizhiMusicClient
from .ximalaya import XimalayaMusicClient
from .qingting import QingtingMusicClient