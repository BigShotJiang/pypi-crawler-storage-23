'''initialize'''
from .jsinterp import JSInterpreter, extractplayerjsglobalvar