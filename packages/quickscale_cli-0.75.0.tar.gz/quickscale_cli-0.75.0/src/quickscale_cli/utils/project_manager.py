"""Project state detection and management utilities."""

from pathlib import Path
from typing import Any

from quickscale_cli.schema.config_schema import QuickScaleConfig, validate_config
from .docker_utils import find_docker_compose, get_running_containers


def get_project_config() -> QuickScaleConfig | None:
    """Load and validate quickscale.yml from current directory if it exists."""
    config_path = Path.cwd() / "quickscale.yml"
    if not config_path.exists():
        return None
    try:
        return validate_config(config_path.read_text())
    except Exception:
        return None


def get_project_state() -> dict[str, Any]:
    """Get comprehensive project state including directory and containers."""
    try:
        current_dir = Path.cwd()
    except OSError:
        return {
            "has_project": False,
            "project_dir": None,
            "project_name": None,
            "containers": [],
        }

    compose_file = find_docker_compose()
    has_project = compose_file is not None
    containers = get_running_containers() if has_project else []

    return {
        "has_project": has_project,
        "project_dir": current_dir if has_project else None,
        "project_name": current_dir.name if has_project else None,
        "containers": containers,
        "compose_file": compose_file,
    }


def is_in_quickscale_project() -> bool:
    """Check if current directory is a QuickScale project."""
    return find_docker_compose() is not None


def get_backend_container_name() -> str:
    """Get the name of the backend container (dynamically detected)."""
    project_name = Path.cwd().name
    containers = get_running_containers()

    # Try different naming patterns used by Docker Compose
    # Examples: test59_backend, test59-backend-1, test59_backend_1
    for container in containers:
        if project_name in container and "backend" in container:
            return container

    # Fallback to common patterns if no running container found
    return f"{project_name}-backend-1"


def get_db_container_name() -> str:
    """Get the name of the database container (dynamically detected)."""
    project_name = Path.cwd().name
    containers = get_running_containers()

    # Try different naming patterns used by Docker Compose
    # Examples: test59_db, test59-db-1, test59_db_1
    for container in containers:
        if project_name in container and "db" in container:
            return container

    # Fallback to common patterns if no running container found
    return f"{project_name}-db-1"
