"""Module configuration functions for QuickScale modules.

This module contains configuration functions for individual QuickScale modules,
including interactive configuration prompts and settings application.
"""

import json
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import click

from quickscale_cli.utils.module_wiring_manager import regenerate_managed_wiring
from quickscale_cli.utils.project_identity import (
    derive_package_from_slug,
    resolve_project_identity,
)


def _is_app_in_installed_apps(settings_content: str, app_name: str) -> bool:
    """Check if an app is already in INSTALLED_APPS.

    Args:
        settings_content: The content of settings.py
        app_name: The app name to check for (e.g., 'django_filters')

    Returns:
        True if the app is already in INSTALLED_APPS, False otherwise
    """
    # Check for app in INSTALLED_APPS list or INSTALLED_APPS +=
    # Match patterns like: "app_name", 'app_name' in lists
    pattern = rf'["\']({re.escape(app_name)})["\']'
    return bool(re.search(pattern, settings_content))


def _filter_new_apps(settings_content: str, apps: list[str]) -> list[str]:
    """Filter out apps that are already in INSTALLED_APPS.

    Args:
        settings_content: The content of settings.py
        apps: List of app names to filter

    Returns:
        List of apps that are NOT already in settings.py
    """
    return [app for app in apps if not _is_app_in_installed_apps(settings_content, app)]


@dataclass(frozen=True)
class AuthMigrationAssessment:
    """Auth migration safety assessment."""

    status: str  # compatible | incompatible | unverifiable
    reason: str

    @property
    def compatible(self) -> bool:
        return self.status == "compatible"

    @property
    def incompatible(self) -> bool:
        return self.status == "incompatible"

    @property
    def unverifiable(self) -> bool:
        return self.status == "unverifiable"


_CORE_AUTH_APPS = {"auth", "admin", "contenttypes", "sessions"}


def _migration_probe_script() -> str:
    """Return Python snippet for migration recorder probing via manage.py shell."""
    return (
        "import json;"
        "from django.db import connection;"
        "from django.db.migrations.recorder import MigrationRecorder;"
        f"core_apps={sorted(_CORE_AUTH_APPS)!r};"
        "recorder=MigrationRecorder(connection);"
        "applied=[(m.app,m.name) for m in recorder.migration_qs];"
        "incompatible=any(app in core_apps for app,_ in applied);"
        "print(json.dumps({'ok': True, 'incompatible': incompatible, 'count': len(applied)}))"
    )


def assess_auth_migration_state(
    project_path: Path | None = None,
) -> AuthMigrationAssessment:
    """Assess whether auth module can be embedded safely.

    Uses Django's MigrationRecorder through project runtime instead of filesystem
    heuristics.
    """
    if project_path is None:
        project_path = Path.cwd()

    manage_py = project_path / "manage.py"
    if not manage_py.exists():
        return AuthMigrationAssessment(
            status="unverifiable",
            reason=f"manage.py not found at {manage_py}",
        )

    try:
        result = subprocess.run(
            ["python", "manage.py", "shell", "-c", _migration_probe_script()],
            cwd=project_path,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        return AuthMigrationAssessment(
            status="unverifiable",
            reason=f"failed to execute Django runtime check: {e}",
        )

    if result.returncode != 0:
        error = (result.stderr or result.stdout or "").strip() or "unknown error"
        return AuthMigrationAssessment(
            status="unverifiable",
            reason=f"migration recorder check failed: {error}",
        )

    output_lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    if not output_lines:
        return AuthMigrationAssessment(
            status="unverifiable",
            reason="migration recorder check produced no output",
        )

    try:
        payload = json.loads(output_lines[-1])
    except json.JSONDecodeError:
        return AuthMigrationAssessment(
            status="unverifiable",
            reason=f"unexpected migration recorder output: {output_lines[-1]}",
        )

    if not payload.get("ok"):
        return AuthMigrationAssessment(
            status="unverifiable",
            reason=payload.get("error", "unknown migration recorder error"),
        )

    if payload.get("incompatible"):
        return AuthMigrationAssessment(
            status="incompatible",
            reason=(
                "Default Django auth/admin/session/contenttypes migrations are already "
                "applied in this database."
            ),
        )

    return AuthMigrationAssessment(
        status="compatible",
        reason="No incompatible core auth migrations were detected.",
    )


def has_migrations_been_run(project_path: Path | None = None) -> bool:
    """Backward-compatible helper for tests and existing callers."""
    assessment = assess_auth_migration_state(project_path)
    return assessment.incompatible


def format_auth_migration_remediation(project_path: Path) -> str:
    """Return actionable remediation commands for incompatible auth state."""
    try:
        identity = resolve_project_identity(project_path)
        package_hint = identity.package
    except Exception:
        package_hint = derive_package_from_slug(project_path.name)

    project_abs = project_path.resolve()
    fresh_db_name = f"{package_hint}_fresh"

    return (
        "Remediation options (all may involve data loss):\n\n"
        "1) Fresh disposable local database\n"
        f"   cd {project_abs}\n"
        f"   export DATABASE_URL=postgresql://postgres:postgres@localhost:5432/{fresh_db_name}\n"
        "   poetry run python manage.py migrate\n"
        "   quickscale apply\n\n"
        "2) Docker volume reset (destructive)\n"
        f"   cd {project_abs}\n"
        "   docker compose down -v\n"
        "   quickscale up --build\n"
        "   poetry run python manage.py migrate\n"
        "   quickscale apply\n\n"
        "3) Explicitly destructive reset path\n"
        f"   cd {project_abs}\n"
        "   poetry run python manage.py flush --no-input\n"
        "   poetry run python manage.py migrate\n\n"
        "WARNING: These commands can permanently delete data."
    )


# ============================================================================
# AUTH MODULE CONFIGURATION
# ============================================================================


def get_default_auth_config() -> dict[str, Any]:
    """Get default configuration for auth module (non-interactive mode)"""
    return {
        "registration_enabled": True,
        "email_verification": "none",
        "authentication_method": "email",
        "social_providers": [],
        "session_cookie_age": 1209600,
    }


def configure_auth_module(non_interactive: bool = False) -> dict[str, Any]:
    """Interactive configuration for auth module"""
    if non_interactive:
        click.echo("\n⚙️  Using default auth module configuration...")
        config = get_default_auth_config()
        click.echo("  • Registration: Enabled")
        click.echo(f"  • Email verification: {config['email_verification']}")
        click.echo(f"  • Authentication: {config['authentication_method']}")
        return config

    click.echo("\n⚙️  Configuring auth module...")
    click.echo("Answer these questions to customize the authentication setup:\n")

    config = {
        "registration_enabled": click.confirm(
            "Enable user registration?",
            default=True,
        ),
        "email_verification": click.prompt(
            "Email verification",
            type=click.Choice(["none", "optional", "mandatory"], case_sensitive=False),
            default="none",
            show_choices=True,
        ),
        "authentication_method": click.prompt(
            "Authentication method",
            type=click.Choice(["email", "username", "both"], case_sensitive=False),
            default="email",
            show_choices=True,
        ),
        "social_providers": [],
        "session_cookie_age": 1209600,
    }

    return config


def _add_django_allauth_dependency(project_path: Path, pyproject_path: Path) -> None:
    """Add django-allauth dependency to project's pyproject.toml."""
    with open(pyproject_path) as f:
        pyproject_content = f.read()

    if "django-allauth" in pyproject_content:
        return

    # Read django-allauth version from the embedded auth module
    auth_pyproject_path = project_path / "modules" / "auth" / "pyproject.toml"

    if not auth_pyproject_path.exists():
        click.secho(
            "❌ Error: Auth module pyproject.toml not found. "
            "Cannot determine django-allauth version requirement.",
            fg="red",
            err=True,
        )
        click.echo(f"Expected file: {auth_pyproject_path}", err=True)
        click.echo(
            "This indicates the auth module was not embedded correctly.",
            err=True,
        )
        raise click.Abort()

    # Extract django-allauth version using regex
    try:
        with open(auth_pyproject_path) as f:
            auth_pyproject_content = f.read()

        version_match = re.search(
            r'django-allauth\s*=\s*["\']([^"\']+)["\']', auth_pyproject_content
        )
        if not version_match:
            click.secho(
                "❌ Error: Cannot find django-allauth version in auth module's "
                "pyproject.toml",
                fg="red",
                err=True,
            )
            click.echo(f"File: {auth_pyproject_path}", err=True)
            click.echo('Expected format: django-allauth = "^x.x.x"', err=True)
            click.echo("Please check the auth module's dependencies.", err=True)
            raise click.Abort()
        django_allauth_version = version_match.group(1)
    except (FileNotFoundError, AttributeError) as e:
        click.secho(
            f"❌ Error: Failed to parse django-allauth version from auth module: {e}",
            fg="red",
            err=True,
        )
        click.echo(f"File: {auth_pyproject_path}", err=True)
        click.echo(
            "Please ensure the auth module is properly embedded and its "
            "pyproject.toml is valid.",
            err=True,
        )
        raise click.Abort()

    # Try to add to [tool.poetry.dependencies] section
    dependencies_pattern = r"(\[tool\.poetry\.dependencies\][^\[]*)"
    match = re.search(dependencies_pattern, pyproject_content, re.DOTALL)
    if match:
        dependencies_section = match.group(1)
        # Add django-allauth after the python version line
        updated_dependencies = re.sub(
            r'(python = "[^"]*")',
            rf'\1\ndjango-allauth = "{django_allauth_version}"',
            dependencies_section,
        )
        pyproject_content = pyproject_content.replace(
            dependencies_section, updated_dependencies
        )

        with open(pyproject_path, "w") as f:
            f.write(pyproject_content)

        click.secho("  ✅ Added django-allauth to pyproject.toml", fg="green")
    else:
        click.secho(
            "⚠️  Warning: Could not find [tool.poetry.dependencies] section in "
            "pyproject.toml",
            fg="yellow",
        )


def _generate_auth_settings_addition(config: dict[str, Any]) -> str:
    """Generate the settings addition string for auth module."""
    registration_enabled = config.get("registration_enabled")
    if registration_enabled is None:
        registration_enabled = config.get("allow_registration", True)

    session_cookie_age = int(config.get("session_cookie_age", 1209600))

    settings_addition = """
# QuickScale Auth Module - Added by quickscale embed
INSTALLED_APPS += [
    "django.contrib.sites",  # Required by allauth
    "quickscale_modules_auth",  # Must be before allauth.account for template overrides
    "allauth",
    "allauth.account",
]

# Allauth Middleware (must be added to MIDDLEWARE)
MIDDLEWARE += [
    "allauth.account.middleware.AccountMiddleware",
]

# Authentication Configuration
AUTHENTICATION_BACKENDS = [
    "django.contrib.auth.backends.ModelBackend",
    "allauth.account.auth_backends.AuthenticationBackend",
]

# Custom User Model
AUTH_USER_MODEL = "quickscale_modules_auth.User"

# Site ID (required by django.contrib.sites)
SITE_ID = 1

# Allauth Settings
"""

    # Add configuration based on user choices (using new django-allauth 0.62+ format)
    if config["authentication_method"] == "email":
        settings_addition += 'ACCOUNT_LOGIN_METHODS = {"email"}\n'
        settings_addition += (
            'ACCOUNT_SIGNUP_FIELDS = ["email*", "password1*", "password2*"]\n'
        )
    elif config["authentication_method"] == "username":
        settings_addition += 'ACCOUNT_LOGIN_METHODS = {"username"}\n'
        settings_addition += (
            'ACCOUNT_SIGNUP_FIELDS = ["username*", "password1*", "password2*"]\n'
        )
    else:  # both
        settings_addition += 'ACCOUNT_LOGIN_METHODS = {"email", "username"}\n'
        settings_addition += 'ACCOUNT_SIGNUP_FIELDS = ["email*", "username*", "password1*", "password2*"]\n'

    settings_addition += (
        f'ACCOUNT_EMAIL_VERIFICATION = "{config["email_verification"]}"\n'
    )
    settings_addition += f"ACCOUNT_ALLOW_REGISTRATION = {registration_enabled}\n"
    settings_addition += 'ACCOUNT_ADAPTER = "quickscale_modules_auth.adapters.QuickscaleAccountAdapter"\n'
    settings_addition += (
        'ACCOUNT_SIGNUP_FORM_CLASS = "quickscale_modules_auth.forms.SignupForm"\n'
    )
    settings_addition += 'LOGIN_REDIRECT_URL = "/accounts/profile/"\n'
    settings_addition += 'LOGOUT_REDIRECT_URL = "/"\n'
    settings_addition += f"SESSION_COOKIE_AGE = {session_cookie_age}  # 2 weeks\n"

    return settings_addition


def _normalize_auth_config(config: dict[str, Any]) -> dict[str, Any]:
    """Normalize legacy auth config keys to manifest-aligned keys."""
    normalized = dict(config)
    if "registration_enabled" not in normalized and "allow_registration" in normalized:
        normalized["registration_enabled"] = normalized["allow_registration"]
    normalized.setdefault("registration_enabled", True)
    normalized.setdefault("email_verification", "none")
    normalized.setdefault("authentication_method", "email")
    normalized.setdefault("social_providers", [])
    normalized.setdefault("session_cookie_age", 1209600)
    return normalized


def _regenerate_wiring_for_module(
    project_path: Path,
    module_name: str,
    module_config: dict[str, Any],
) -> None:
    """Regenerate deterministic managed wiring for module integrations."""
    modules_dir = project_path / "modules"
    discovered_modules = (
        [p.name for p in modules_dir.iterdir() if p.is_dir()]
        if modules_dir.exists()
        else []
    )
    selected_modules = sorted(set(discovered_modules + [module_name]))

    success, message = regenerate_managed_wiring(
        project_path,
        module_names=selected_modules,
        option_overrides={module_name: module_config},
    )
    if not success:
        click.secho(
            f"⚠️  Warning: managed wiring regeneration failed: {message}",
            fg="yellow",
        )
    else:
        click.secho("  ✅ Regenerated managed module wiring", fg="green")


def apply_auth_configuration(project_path: Path, config: dict[str, Any]) -> None:
    """Apply auth module configuration via managed wiring files."""
    normalized_config = _normalize_auth_config(config)
    pyproject_path = project_path / "pyproject.toml"

    # Add django-allauth dependency to pyproject.toml
    if pyproject_path.exists():
        _add_django_allauth_dependency(project_path, pyproject_path)

    # Managed wiring includes django-allauth + auth module URL routes.
    _regenerate_wiring_for_module(project_path, "auth", normalized_config)

    # Show configuration summary
    click.echo("\n📋 Configuration applied:")
    registration_enabled = normalized_config["registration_enabled"]
    click.echo(f"  • Registration: {'Enabled' if registration_enabled else 'Disabled'}")
    click.echo(f"  • Email verification: {normalized_config['email_verification']}")
    click.echo(f"  • Authentication: {normalized_config['authentication_method']}")


# ============================================================================
# BLOG MODULE CONFIGURATION
# ============================================================================


def get_default_blog_config() -> dict[str, Any]:
    """Get default configuration for blog module (non-interactive mode)"""
    return {
        "posts_per_page": 10,
        "enable_rss": True,
    }


def configure_blog_module(non_interactive: bool = False) -> dict[str, Any]:
    """Interactive configuration for blog module"""
    if non_interactive:
        click.echo("\n⚙️  Using default blog module configuration...")
        config = get_default_blog_config()
        click.echo(f"  • Posts per page: {config['posts_per_page']}")
        click.echo("  • RSS feed: Enabled")
        return config

    click.echo("\n⚙️  Configuring blog module...")
    click.echo("The blog module will be configured with default settings.\n")

    config = {
        "posts_per_page": click.prompt(
            "Posts per page",
            type=int,
            default=10,
        ),
        "enable_rss": click.confirm("Enable RSS feed?", default=True),
    }

    return config


def apply_blog_configuration(project_path: Path, config: dict[str, Any]) -> None:
    """Apply blog module configuration via managed wiring files."""
    _regenerate_wiring_for_module(project_path, "blog", config)

    # Show configuration summary
    click.echo("\n📋 Configuration applied:")
    click.echo(f"  • Posts per page: {config['posts_per_page']}")
    click.echo(f"  • RSS feed: {'Enabled' if config['enable_rss'] else 'Disabled'}")


# ============================================================================
# LISTINGS MODULE CONFIGURATION
# ============================================================================


def get_default_listings_config() -> dict[str, Any]:
    """Get default configuration for listings module (non-interactive mode)"""
    return {
        "listings_per_page": 12,
    }


def configure_listings_module(non_interactive: bool = False) -> dict[str, Any]:
    """Interactive configuration for listings module"""
    if non_interactive:
        click.echo("\n⚙️  Using default listings module configuration...")
        config = get_default_listings_config()
        click.echo(f"  • Listings per page: {config['listings_per_page']}")
        return config

    click.echo("\n⚙️  Configuring listings module...")
    click.echo(
        "The listings module provides an abstract base model for marketplace listings.\n"
    )

    config = {
        "listings_per_page": click.prompt(
            "Listings per page",
            type=int,
            default=12,
        ),
    }

    return config


def _add_django_filter_dependency(project_path: Path, pyproject_path: Path) -> None:
    """Add django-filter dependency to project's pyproject.toml."""
    with open(pyproject_path) as f:
        pyproject_content = f.read()

    if "django-filter" in pyproject_content:
        return

    # Read django-filter version from the embedded listings module
    listings_pyproject_path = project_path / "modules" / "listings" / "pyproject.toml"

    if not listings_pyproject_path.exists():
        click.secho(
            "❌ Error: Listings module pyproject.toml not found. "
            "Cannot determine django-filter version requirement.",
            fg="red",
            err=True,
        )
        click.echo(f"Expected file: {listings_pyproject_path}", err=True)
        click.echo(
            "This indicates the listings module was not embedded correctly.",
            err=True,
        )
        raise click.Abort()

    # Extract django-filter version using regex
    try:
        with open(listings_pyproject_path) as f:
            listings_pyproject_content = f.read()

        version_match = re.search(
            r'django-filter\s*=\s*["\']([^"\']+)["\']',
            listings_pyproject_content,
        )
        if not version_match:
            click.secho(
                "❌ Error: Cannot find django-filter version in listings "
                "module's pyproject.toml",
                fg="red",
                err=True,
            )
            click.echo(f"File: {listings_pyproject_path}", err=True)
            click.echo('Expected format: django-filter = "^x.x.x"', err=True)
            click.echo("Please check the listings module's dependencies.", err=True)
            raise click.Abort()
        django_filter_version = version_match.group(1)
    except (FileNotFoundError, AttributeError) as e:
        click.secho(
            f"❌ Error: Failed to parse django-filter version from listings "
            f"module: {e}",
            fg="red",
            err=True,
        )
        click.echo(f"File: {listings_pyproject_path}", err=True)
        click.echo(
            "Please ensure the listings module is properly embedded and its "
            "pyproject.toml is valid.",
            err=True,
        )
        raise click.Abort()

    # Try to add to [tool.poetry.dependencies] section
    dependencies_pattern = r"(\[tool\.poetry\.dependencies\][^\[]*)"
    match = re.search(dependencies_pattern, pyproject_content, re.DOTALL)
    if match:
        dependencies_section = match.group(1)
        # Add django-filter after the python version line
        updated_dependencies = re.sub(
            r'(python = "[^"]*")',
            rf'\1\ndjango-filter = "{django_filter_version}"',
            dependencies_section,
        )
        pyproject_content = pyproject_content.replace(
            dependencies_section, updated_dependencies
        )

        with open(pyproject_path, "w") as f:
            f.write(pyproject_content)

        click.secho("  ✅ Added django-filter to pyproject.toml", fg="green")
    else:
        click.secho(
            "⚠️  Warning: Could not find [tool.poetry.dependencies] section in "
            "pyproject.toml",
            fg="yellow",
        )


def apply_listings_configuration(project_path: Path, config: dict[str, Any]) -> None:
    """Apply listings module configuration via managed wiring files."""
    pyproject_path = project_path / "pyproject.toml"

    # Add django-filter dependency to pyproject.toml
    if pyproject_path.exists():
        _add_django_filter_dependency(project_path, pyproject_path)

    _regenerate_wiring_for_module(project_path, "listings", config)

    # Show configuration summary
    click.echo("\n📋 Configuration applied:")
    click.echo(f"  • Listings per page: {config['listings_per_page']}")


# ============================================================================
# CRM MODULE CONFIGURATION
# ============================================================================


def get_default_crm_config() -> dict[str, Any]:
    """Get default configuration for CRM module (non-interactive mode)"""
    return {
        "enable_api": True,
        "deals_per_page": 25,
        "contacts_per_page": 50,
        "default_pipeline_stages": [
            "Prospecting",
            "Negotiation",
            "Closed-Won",
            "Closed-Lost",
        ],
    }


def configure_crm_module(non_interactive: bool = False) -> dict[str, Any]:
    """Interactive configuration for CRM module"""
    if non_interactive:
        click.echo("\n⚙️  Using default CRM module configuration...")
        config = get_default_crm_config()
        click.echo("  • API: Enabled")
        click.echo(f"  • Deals per page: {config['deals_per_page']}")
        click.echo(f"  • Contacts per page: {config['contacts_per_page']}")
        return config

    click.echo("\n⚙️  Configuring CRM module...")
    click.echo(
        "The CRM module provides contact management, companies, and deal pipeline.\n"
    )

    config = {
        "enable_api": click.confirm("Enable REST API endpoints?", default=True),
        "deals_per_page": click.prompt(
            "Deals per page",
            type=int,
            default=25,
        ),
        "contacts_per_page": click.prompt(
            "Contacts per page",
            type=int,
            default=50,
        ),
        "default_pipeline_stages": [
            "Prospecting",
            "Negotiation",
            "Closed-Won",
            "Closed-Lost",
        ],
    }

    return config


def _get_dependency_version(content: str, package: str) -> Optional[str]:
    """Extract dependency version from pyproject.toml content."""
    match = re.search(
        rf'{package}\s*=\s*["\']([^"\']+)["\']',
        content,
    )
    return match.group(1) if match else None


def _update_pyproject_toml(
    pyproject_path: Path,
    content: str,
    drf_ver: Optional[str],
    filter_ver: Optional[str],
) -> None:
    """Update pyproject.toml with new dependencies."""
    dependencies_pattern = r"(\[tool\.poetry\.dependencies\][^\[]*)"
    match = re.search(dependencies_pattern, content, re.DOTALL)
    if not match:
        return

    dependencies_section = match.group(1)
    additions = ""
    if drf_ver:
        additions += f'\ndjangorestframework = "{drf_ver}"'
    if filter_ver:
        additions += f'\ndjango-filter = "{filter_ver}"'

    updated_dependencies = re.sub(
        r'(python = "[^"]*")',
        rf"\1{additions}",
        dependencies_section,
    )
    content = content.replace(dependencies_section, updated_dependencies)

    with open(pyproject_path, "w") as f:
        f.write(content)

    if drf_ver:
        click.secho("  ✅ Added djangorestframework to pyproject.toml", fg="green")
    if filter_ver:
        click.secho("  ✅ Added django-filter to pyproject.toml", fg="green")


def _add_drf_and_filter_dependencies(
    project_path: Path,
    pyproject_path: Path,
    source_module: str = "crm",
) -> None:
    """Add djangorestframework and django-filter dependencies to project's pyproject.toml.

    Reads the required versions from the already-embedded source_module's pyproject.toml.
    """
    with open(pyproject_path) as f:
        pyproject_content = f.read()

    module_pyproject_path = project_path / "modules" / source_module / "pyproject.toml"

    if not module_pyproject_path.exists():
        click.secho(
            f"❌ Error: {source_module} module pyproject.toml not found. "
            "Cannot determine dependency version requirements.",
            fg="red",
            err=True,
        )
        click.echo(f"Expected file: {module_pyproject_path}", err=True)
        raise click.Abort()

    try:
        with open(module_pyproject_path) as f:
            module_pyproject_content = f.read()

        drf_version = None
        if "djangorestframework" not in pyproject_content:
            drf_version = _get_dependency_version(
                module_pyproject_content, "djangorestframework"
            )

        filter_version = None
        if "django-filter" not in pyproject_content:
            filter_version = _get_dependency_version(
                module_pyproject_content, "django-filter"
            )

        if drf_version or filter_version:
            _update_pyproject_toml(
                pyproject_path, pyproject_content, drf_version, filter_version
            )

    except (FileNotFoundError, AttributeError) as e:
        click.secho(
            f"❌ Error: Failed to parse dependencies from {source_module} module: {e}",
            fg="red",
            err=True,
        )
        raise click.Abort()


def _get_crm_settings_addition(config: dict[str, Any]) -> str:
    """Generate settings addition for CRM module."""
    addition = f"""
# CRM Module Settings
CRM_DEALS_PER_PAGE = {config["deals_per_page"]}
CRM_CONTACTS_PER_PAGE = {config["contacts_per_page"]}
CRM_ENABLE_API = {config["enable_api"]}
"""
    if config["enable_api"]:
        addition += """
# REST Framework Settings
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.IsAuthenticated",
    ],
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 25,
    "DEFAULT_FILTER_BACKENDS": [
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ],
}
"""
    return addition


def _update_crm_urls(urls_path: Path) -> None:
    """Add CRM URLs to project's urls.py."""
    if not urls_path.exists():
        return

    with open(urls_path) as f:
        urls_content = f.read()

    if "quickscale_modules_crm" in urls_content:
        return

    if "urlpatterns = [" in urls_content:
        urls_addition = '    path("crm/", include("quickscale_modules_crm.urls")),\n'
        urls_content = urls_content.replace(
            "urlpatterns = [", "urlpatterns = [\n" + urls_addition
        )

        with open(urls_path, "w") as f:
            f.write(urls_content)

        click.secho("  ✅ Updated urls.py with CRM URLs", fg="green")


def apply_crm_configuration(project_path: Path, config: dict[str, Any]) -> None:
    """Apply CRM module configuration via managed wiring files."""
    pyproject_path = project_path / "pyproject.toml"

    # Add DRF and django-filter dependencies to pyproject.toml
    if pyproject_path.exists():
        _add_drf_and_filter_dependencies(
            project_path, pyproject_path, source_module="crm"
        )

    _regenerate_wiring_for_module(project_path, "crm", config)

    # Show configuration summary
    click.echo("\n📋 Configuration applied:")
    click.echo(f"  • API: {'Enabled' if config['enable_api'] else 'Disabled'}")
    click.echo(f"  • Deals per page: {config['deals_per_page']}")
    click.echo(f"  • Contacts per page: {config['contacts_per_page']}")


# ============================================================================
# FORMS MODULE CONFIGURATION
# ============================================================================


def get_default_forms_config() -> dict[str, Any]:
    """Return default configuration for the forms module."""
    return {
        "forms_per_page": 25,
        "spam_protection_enabled": True,
        "rate_limit": "5/hour",
        "data_retention_days": 365,
        "submissions_api_enabled": True,
        "storage_backend": "django",
    }


def configure_forms_module(non_interactive: bool = False) -> dict[str, Any]:
    """Configure the forms module interactively or using defaults."""
    if non_interactive:
        click.echo("\n⚙️  Using default forms module configuration...")
        config = get_default_forms_config()
        click.echo(f"  \u2022 Forms per page: {config['forms_per_page']}")
        click.echo("  \u2022 Spam protection: Enabled")
        click.echo(f"  \u2022 Rate limit: {config['rate_limit']}")
        click.echo(f"  \u2022 Data retention: {config['data_retention_days']} days")
        click.echo("  \u2022 Submissions API: Enabled")
        return config

    click.echo("\n⚙️  Configuring forms module...")
    config = {
        "forms_per_page": click.prompt(
            "Submissions per page (admin)", type=int, default=25
        ),
        "spam_protection_enabled": click.confirm(
            "Enable honeypot spam protection?", default=True
        ),
        "rate_limit": click.prompt(
            "Rate limit for submissions (e.g. 5/hour, 10/minute)",
            default="5/hour",
        ),
        "data_retention_days": click.prompt(
            "Data retention days (0 = keep forever)", type=int, default=365
        ),
        "submissions_api_enabled": click.confirm(
            "Enable REST API for admin submissions?", default=True
        ),
        "storage_backend": "django",
    }
    return config


def apply_forms_configuration(project_path: Path, config: dict[str, Any]) -> None:
    """Apply forms module configuration to the project."""
    pyproject_path = project_path / "pyproject.toml"

    # Add DRF and django-filter dependencies to pyproject.toml
    if pyproject_path.exists():
        _add_drf_and_filter_dependencies(
            project_path, pyproject_path, source_module="forms"
        )

    _regenerate_wiring_for_module(project_path, "forms", config)
    click.echo("\n\U0001f4cb Configuration applied:")
    click.echo(f"  \u2022 Forms per page: {config['forms_per_page']}")
    click.echo(
        f"  \u2022 Spam protection: {'Enabled' if config['spam_protection_enabled'] else 'Disabled'}"
    )
    click.echo(f"  \u2022 Rate limit: {config['rate_limit']}")
    click.echo(f"  \u2022 Data retention: {config['data_retention_days']} days")
    click.echo(
        f"  \u2022 Submissions API: {'Enabled' if config['submissions_api_enabled'] else 'Disabled'}"
    )


# ============================================================================
# MODULE CONFIGURATORS REGISTRY
# ============================================================================

MODULE_CONFIGURATORS = {
    "auth": (configure_auth_module, apply_auth_configuration),
    "blog": (configure_blog_module, apply_blog_configuration),
    "listings": (configure_listings_module, apply_listings_configuration),
    "crm": (configure_crm_module, apply_crm_configuration),
    "forms": (configure_forms_module, apply_forms_configuration),
}
