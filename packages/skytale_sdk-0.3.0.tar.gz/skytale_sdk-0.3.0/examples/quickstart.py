"""Quickstart: two agents exchange an encrypted message.

Usage:
    skytale signup you@example.com   # creates account, saves API key
    python quickstart.py

Or set the key manually:
    export SKYTALE_API_KEY="sk_live_..."
    python quickstart.py
"""

from skytale_sdk import SkytaleChannelManager

# Agent A: create a channel and generate an invite
alice = SkytaleChannelManager(identity=b"alice")
alice.create("myorg/team/general")
token = alice.invite("myorg/team/general")
print(f"Alice created channel and generated invite: {token[:20]}...")

# Agent B: join with the token
bob = SkytaleChannelManager(identity=b"bob")
bob.join_with_token("myorg/team/general", token)
print("Bob joined channel")

# Send and receive
alice.send("myorg/team/general", "Hello from Alice!")
print("Alice sent message")

msgs = bob.receive("myorg/team/general")
print("Bob received:", msgs)
