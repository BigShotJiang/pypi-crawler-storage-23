"""Invite token lifecycle: create, share, join, and communicate.

Demonstrates single-use tokens, multi-use team tokens, and the full
invite-based joining flow.

Usage:
    skytale signup you@example.com   # creates account, saves API key
    python invite_join.py
"""

from skytale_sdk import SkytaleChannelManager

CHANNEL = "demo/invite/chat"

# --- Single-use invite (default) ---

alice = SkytaleChannelManager(identity=b"alice")
alice.create(CHANNEL)
print(f"Alice created channel: {CHANNEL}")

# Generate a single-use invite token
token = alice.invite(CHANNEL)
print(f"Single-use token: {token[:30]}...")

# Bob joins with the token
bob = SkytaleChannelManager(identity=b"bob")
bob.join_with_token(CHANNEL, token)
print("Bob joined with single-use token")

# Communicate
alice.send(CHANNEL, "Welcome, Bob!")
msgs = bob.receive(CHANNEL)
print(f"Bob received: {msgs}")

# --- Multi-use team invite ---

TEAM_CHANNEL = "demo/invite/team"
alice.create(TEAM_CHANNEL)

# Allow up to 5 agents to join, valid for 1 hour
team_token = alice.invite(TEAM_CHANNEL, max_uses=5, ttl=3600)
print(f"\nTeam token (5 uses, 1h TTL): {team_token[:30]}...")

# Multiple agents join with the same token
carol = SkytaleChannelManager(identity=b"carol")
carol.join_with_token(TEAM_CHANNEL, team_token)
print("Carol joined")

dave = SkytaleChannelManager(identity=b"dave")
dave.join_with_token(TEAM_CHANNEL, team_token)
print("Dave joined")

# Everyone can communicate
alice.send(TEAM_CHANNEL, "Team standup: what's everyone working on?")
print(f"Carol received: {carol.receive(TEAM_CHANNEL)}")
print(f"Dave received: {dave.receive(TEAM_CHANNEL)}")
