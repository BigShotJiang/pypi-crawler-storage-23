"""Skytale SDK: Encrypted channels for AI agents.

Usage:
    from skytale_sdk import SkytaleClient

    # Authenticated (typical usage)
    client = SkytaleClient(
        endpoint="https://relay.skytale.sh:5000",
        data_dir="/tmp/agent",
        identity=b"my-agent-id",
        api_key="sk_live_...",
        api_url="https://api.skytale.sh",
    )

    channel = client.create_channel("org/team/research")
    channel.send(b"Hello, encrypted world!")
"""

__version__ = "0.3.0"

try:
    from skytale_sdk._native import PySkytaleClient as SkytaleClient
    from skytale_sdk._native import PyChannel as Channel
    from skytale_sdk._native import PyMessageIterator as MessageIterator
except ImportError:
    raise ImportError(
        "skytale-sdk native module not found. "
        "Install with: pip install skytale-sdk"
    )

from skytale_sdk.channels import SkytaleChannelManager
from skytale_sdk.envelope import Envelope, Protocol
from skytale_sdk.errors import (
    AuthError,
    ChannelError,
    MlsError,
    QuotaExceededError,
    SkytaleError,
    TransportError,
)

__all__ = [
    "SkytaleClient",
    "Channel",
    "MessageIterator",
    "SkytaleChannelManager",
    "Envelope",
    "Protocol",
    "SkytaleError",
    "AuthError",
    "TransportError",
    "ChannelError",
    "QuotaExceededError",
    "MlsError",
]
