from ocralign import ocr
from ocralign import tess_align
from ocralign.ocr import process_pdf, process_image

__version__="0.1.1"