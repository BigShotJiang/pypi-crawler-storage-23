# (c) Copyright IBM Corp. 2021
# (c) Copyright Instana Inc. 2017


from instana.instrumentation.asgi import InstanaASGIMiddleware  # noqa: F401
from instana.instrumentation.wsgi import InstanaWSGIMiddleware  # noqa: F401
