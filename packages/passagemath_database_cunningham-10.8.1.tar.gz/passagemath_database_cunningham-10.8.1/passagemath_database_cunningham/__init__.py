# sage_setup: distribution = sagemath-database-cunningham

from sage.all__sagemath_database_cunningham import *
