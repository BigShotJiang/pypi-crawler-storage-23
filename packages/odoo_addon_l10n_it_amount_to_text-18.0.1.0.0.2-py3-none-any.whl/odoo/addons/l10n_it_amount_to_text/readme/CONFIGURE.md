**Italiano**

Versione libreria `num2words` \>= 0.5.12

**English**

`num2words` library version \>= 0.5.12
