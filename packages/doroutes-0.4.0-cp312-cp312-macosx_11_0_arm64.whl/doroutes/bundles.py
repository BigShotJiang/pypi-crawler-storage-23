"""Bundle routing."""

from collections.abc import Iterable
from functools import partial

import numpy as np
from kfactory.kcell import ProtoTKCell
from kfactory.typings import KCellSpec

from doroutes import pcells, util
from doroutes.fanin import add_fan_in
from doroutes.routing import add_route_astar, add_route_from_corners
from doroutes.types import (
    Dbu,
    Int,
    LayerLike,
    OrientationChar,
    PointsDbu,
    PortLike,
    StepDbu,
    Um,
    validate_orientation,
    validate_position,
    validate_position_with_orientation,
)


def add_bundle_astar(
    component: ProtoTKCell,
    ports1: list[PortLike],
    ports2: list[PortLike],
    spacing: Um,
    bend: KCellSpec,
    straight: KCellSpec,
    layers: Iterable[LayerLike],
    grid_unit: Int = 500,
) -> list[None]:  # FIXME: GDSFactory expects a list of something...
    """Add a bundle route using the a-star algorithm.

    Args:
        component: The component to add the route into.
        ports1: the start ports
        ports2: the end ports
        spacing: the spacing between the waveguides in the bundle
        bend: the bend-spec to create bends with
        straight: the straight-spec to create straights with
        layers: the layers to avoid.
        grid_unit: the discretization unit for the a-star algorithm.

    """
    if len(ports1) != len(ports2):
        msg = "Number of start ports is different than number of end ports"
        raise ValueError(msg)
    num_ports = len(ports1)
    if num_ports == 0:
        msg = "No input/output ports given"
        raise ValueError(msg)
    xyo1 = [validate_position_with_orientation(p) for p in ports1]
    xyo2 = [validate_position_with_orientation(p) for p in ports2]
    os1 = [o for _, _, o in xyo1]
    os2 = [o for _, _, o in xyo2]
    if not all(o == os1[0] for o in os1):
        msg = f"Input port orientations are not all equal. Got: {os1}."
        raise ValueError(msg)
    if not all(o == os2[0] for o in os2):
        msg = f"Output port orientations are not all equal. Got: {os1}."
        raise ValueError(msg)

    o1 = validate_orientation(os1[0])
    o2 = validate_orientation(os2[0])
    if o1 == o2:
        # FIXME: this check seems necessary because the router doesn't
        # seem to find a solution anyway in this case :(
        msg = (
            f"The port orientation at the input needs to be different "
            f"from the port orientation at the output. Got: {o1!r}=={o2!r}."
        )
        raise ValueError(msg)

    if num_ports == 1:
        start = validate_position_with_orientation(ports1[0], invert_orientation=False)
        stop = validate_position_with_orientation(ports2[0], invert_orientation=True)
    else:
        inv_dbu = util.get_inv_dbu(component.kcl)
        spacing_dbu = round(spacing * inv_dbu)
        starts = add_fan_in(
            c=component,
            inputs=ports1,
            straight=straight,
            bend=bend,
            spacing_dbu=spacing_dbu,
        )
        stops = add_fan_in(
            c=component,
            inputs=ports2,
            straight=straight,
            bend=bend,
            spacing_dbu=spacing_dbu,
        )
        start = (*np.mean(starts, 0), o1)
        stop = (*np.mean(stops, 0), util.invert_orientation(o2))
        bend = partial(pcells.bends, bend, straight, num_ports, spacing)
        straight = partial(pcells.straights, straight, num_ports, spacing)

    add_route_astar(
        c=component,
        start=start,
        stop=stop,
        layers=layers,
        straight=straight,
        bend=bend,
        grid_unit=grid_unit,
    )
    return [None for _ in range(num_ports)]


def _resolve_corners(
    component: ProtoTKCell,
    ports1: list[PortLike],
    corners: PointsDbu | None,
    steps: list[StepDbu] | None,
) -> PointsDbu:
    """Convert steps to corners or default to empty list."""
    if corners is not None and steps is not None:
        msg = "Cannot specify both 'corners' and 'steps'."
        raise ValueError(msg)
    if steps is not None:
        positions = [validate_position(p) for p in ports1]
        n = len(positions)
        centroid = (
            sum(p[0] for p in positions) // n,
            sum(p[1] for p in positions) // n,
        )
        return util.steps_to_corners(util.as_kcell(component), steps, centroid)
    if corners is None:
        return []
    return corners


def add_bundle_from_corners(
    component: ProtoTKCell,
    ports1: list[PortLike],
    ports2: list[PortLike],
    corners: PointsDbu | None = None,
    *,
    steps: list[StepDbu] | None = None,
    spacing: Um,
    bend: KCellSpec,
    straight: KCellSpec,
) -> list[None]:  # FIXME: GDSFactory expects a list of something...
    """Add a bundle route through explicit corner points.

    Args:
        component: The component to add the route into.
        ports1: the start ports
        ports2: the end ports
        corners: the corner points the route passes through
        steps: steps to define corners (alternative to corners).
        spacing: the spacing between the waveguides in the bundle
        bend: the bend-spec to create bends with
        straight: the straight-spec to create straights with

    """
    corners = _resolve_corners(component, ports1, corners, steps)
    if len(ports1) != len(ports2):
        msg = "Number of start ports is different than number of end ports"
        raise ValueError(msg)
    num_ports = len(ports1)
    if num_ports == 0:
        msg = "No input/output ports given"
        raise ValueError(msg)
    xyo1 = [validate_position_with_orientation(p) for p in ports1]
    xyo2 = [validate_position_with_orientation(p) for p in ports2]
    os1 = [o for _, _, o in xyo1]
    os2 = [o for _, _, o in xyo2]
    if not all(o == os1[0] for o in os1):
        msg = f"Input port orientations are not all equal. Got: {os1}."
        raise ValueError(msg)
    if not all(o == os2[0] for o in os2):
        msg = f"Output port orientations are not all equal. Got: {os2}."
        raise ValueError(msg)

    o1 = validate_orientation(os1[0])
    o2 = validate_orientation(os2[0])
    if o1 == o2:
        msg = (
            f"The port orientation at the input needs to be different "
            f"from the port orientation at the output. "
            f"Got: {o1!r}=={o2!r}."
        )
        raise ValueError(msg)

    if num_ports == 1:
        start = validate_position_with_orientation(ports1[0], invert_orientation=False)
        stop = validate_position_with_orientation(ports2[0], invert_orientation=True)
    else:
        inv_dbu = util.get_inv_dbu(component.kcl)
        spacing_dbu = round(spacing * inv_dbu)
        fan_in_kwargs: dict = {}
        if corners:
            single_radius = util.extract_bend_radius(component.kcl, bend)
            bundle_radius = single_radius + (num_ports - 1) * spacing_dbu // 2
            fan_in_kwargs = _fan_in_corner_kwargs(
                o1,
                o2,
                corners,
                xyo1,
                xyo2,
                bundle_radius,
                spacing_dbu,
                num_ports,
            )
        starts = add_fan_in(
            c=component,
            inputs=ports1,
            straight=straight,
            bend=bend,
            spacing_dbu=spacing_dbu,
            **fan_in_kwargs.get("start", {}),
        )
        stops = add_fan_in(
            c=component,
            inputs=ports2,
            straight=straight,
            bend=bend,
            spacing_dbu=spacing_dbu,
            **fan_in_kwargs.get("stop", {}),
        )
        start = (*np.mean(starts, 0), o1)
        stop = (*np.mean(stops, 0), util.invert_orientation(o2))
        bend = partial(pcells.bends, bend, straight, num_ports, spacing)
        straight = partial(pcells.straights, straight, num_ports, spacing)

    add_route_from_corners(
        c=component,
        start=start,
        stop=stop,
        corners=corners,
        straight=straight,
        bend=bend,
    )
    return [None for _ in range(num_ports)]


_UNIT_VECTORS: dict[str, tuple[int, int]] = {
    "n": (0, 1),
    "e": (1, 0),
    "s": (0, -1),
    "w": (-1, 0),
}


def _fan_in_corner_kwargs(
    o1: OrientationChar,
    o2: OrientationChar,
    corners: PointsDbu,
    xyo1: list[tuple[Dbu, Dbu, OrientationChar]],
    xyo2: list[tuple[Dbu, Dbu, OrientationChar]],
    bundle_radius: Dbu,
    spacing_dbu: Dbu,
    num_ports: int,
) -> dict[str, dict[str, Dbu]]:
    """Compute fan-in kwargs to align convergence with corners."""
    dx1, dy1 = _UNIT_VECTORS[o1]
    start_target = (
        int(corners[0][0] - bundle_radius * dx1),
        int(corners[0][1] - bundle_radius * dy1),
    )

    inv_o2 = util.invert_orientation(o2)
    dx2, dy2 = _UNIT_VECTORS[inv_o2]
    stop_target = (
        int(corners[-1][0] + bundle_radius * dx2),
        int(corners[-1][1] + bundle_radius * dy2),
    )

    even_offset = spacing_dbu // 2 if num_ports % 2 == 0 else 0

    return {
        "start": _fan_in_kwargs_for_direction(
            o1,
            start_target,
            xyo1,
            even_offset,
        ),
        "stop": _fan_in_kwargs_for_direction(
            o2,
            stop_target,
            xyo2,
            even_offset,
        ),
    }


def _fan_in_kwargs_for_direction(
    orientation: OrientationChar,
    target: tuple[int, int],
    xyo: list[tuple[Dbu, Dbu, OrientationChar]],
    even_offset: Dbu,
) -> dict[str, Dbu]:
    """Map a target convergence center to add_fan_in x/y_bundle_dbu."""
    target_x, target_y = target
    if orientation in ("n", "s"):
        x_bundle = target_x + even_offset
        port_y = xyo[0][1]
        y_bundle = target_y if orientation == "n" else 2 * port_y - target_y
        return {"x_bundle_dbu": x_bundle, "y_bundle_dbu": y_bundle}
    # east/west
    y_bundle = target_y + even_offset
    port_x = xyo[0][0]
    x_bundle = target_x if orientation == "e" else 2 * port_x - target_x
    return {"x_bundle_dbu": x_bundle, "y_bundle_dbu": y_bundle}
