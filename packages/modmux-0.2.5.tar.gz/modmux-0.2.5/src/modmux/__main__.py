"""Module entry point for `python -m modmux`."""

from .cli import main


if __name__ == "__main__":
    main()
