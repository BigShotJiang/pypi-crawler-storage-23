__version__ = (1, 25, 5)
__version_string__ = '.'.join(map(str, __version__))
