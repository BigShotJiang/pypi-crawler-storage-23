import string
from typing import Final

RANDOM_STRING_CHARS: Final[str] = string.ascii_letters + string.digits
