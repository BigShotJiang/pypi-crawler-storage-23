@echo off
:: =============================================================
:: Validation Report Collector - Windows XP Batch Launcher
:: =============================================================
:: This batch file launches the validation report collector utility
:: Compatible with Windows XP and Python 3.4.4
:: =============================================================

title MediLink Validation Report Collector

echo.
echo ================================================================
echo                 MEDILINK VALIDATION REPORT COLLECTOR
echo ================================================================
echo                     Windows XP Compatible
echo ================================================================
echo.

:: Check if Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please ensure Python 3.4.4 is installed and accessible
    echo.
    pause
    exit /b 1
)

:: Display Python version
echo Python version check:
python --version
echo.

:: Check if the Python script exists
if not exist "validation_report_collector.py" (
    echo ERROR: validation_report_collector.py not found in current directory
    echo Please ensure the script is in the same folder as this batch file
    echo.
    pause
    exit /b 1
)

:: Run the validation report collector
echo Starting validation report collection...
echo.
python validation_report_collector.py

:: Check if the script ran successfully
if errorlevel 1 (
    echo.
    echo ERROR: The validation report collector encountered an error
) else (
    echo.
    echo Validation report collection completed successfully
)

echo.
echo ================================================================
echo                         FINISHED
echo ================================================================
pause