Credits
=======

This extension is roughly based on the idea of the `contrib/ansi <https://github.com/sphinx-contrib/ansi>`_ package by
Sebastian Wiesner.
