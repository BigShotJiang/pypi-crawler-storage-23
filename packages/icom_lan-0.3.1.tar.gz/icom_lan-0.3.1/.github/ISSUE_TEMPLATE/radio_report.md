---
name: Radio Compatibility Report
about: Report test results with a new radio model
title: "[Radio] IC-XXXX compatibility report"
labels: radio-compat
assignees: ''
---

**Radio Model:**
<!-- e.g., IC-705 -->

**CI-V Address:**
<!-- e.g., 0xA4 -->

**Connection Type:**
<!-- Ethernet / WiFi -->

**Firmware Version:**
<!-- if known -->

**Working Commands:**
- [ ] `get_frequency()`
- [ ] `set_frequency()`
- [ ] `get_mode()`
- [ ] `set_mode()`
- [ ] `get_power()`
- [ ] `set_power()`
- [ ] `get_s_meter()`
- [ ] `set_ptt()`
- [ ] `select_vfo()`
- [ ] `send_cw_text()`
- [ ] `power_control()`
- [ ] `discover`

**Issues Found:**
<!-- Any commands that didn't work? -->

**Notes:**
<!-- Any special configuration needed? -->
