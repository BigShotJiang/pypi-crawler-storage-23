See AGENTS.md for project instructions.
