import logging
from typing import Any, Optional, List
from pydantic import BaseModel

from .agent import Agent
from ..media.media import Media


logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

"""
image generator agent
"""

class ImageGeneratorAgent(Agent):
	"""Generate images based on textual prompts or modify existing images using prompting.

	This class extends the base Agent to specialize in image generation tasks.
	It supports two primary workflows: generating an image from a text prompt
	alone, or transforming one or more input images based on a combined text
	prompt and media input. The actual image generation is delegated to the
	underlying platform implementation through dispatch to either text2image
	or image2image methods.

	When no media is provided, the agent generates a new image from scratch
	using only the prompt. When one or more media objects are provided, the
	agent uses them as input to guide the image transformation process,
	delegating to an image-to-image pipeline instead.
	"""

	def __init__(self, **kwargs):
		super().__init__(**kwargs)


	def run(self, prompt: str, media: Optional[List[Media]] = None, response_model: Optional[BaseModel] = None, **kwargs: Any) -> Any:
		"""
		Execute the image captioning process.

		Args:
			prompt (str): The prompt or instruction for image description generation.
			media (Optional[List[Media]]): List of media objects to process.
										  Defaults to None.
			**kwargs: Additional keyword arguments passed to the platform's
					 image2text method.

		Returns:
			Any: The result from the platform's image-to-text conversion, typically
				 a string or structured data containing the generated caption or
				 description.
		"""
		platform=self.platform
		model=self.model
		system_prompt=self.system_prompt

		if media is None:
			return platform.text2image(model=model, prompt=prompt, **kwargs)
		else:
			return platform.image2image(model=model, prompt=prompt, media=media, **kwargs)
