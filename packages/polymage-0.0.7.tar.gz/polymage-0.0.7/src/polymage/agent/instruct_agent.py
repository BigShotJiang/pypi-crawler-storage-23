import logging
from typing import Any, Optional, List
from pydantic import BaseModel

from .agent import Agent
from ..media.media import Media

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

class InstructAgent(Agent):
	"""
	A specialized agent that executes text-to-text transformations using a configured platform.

	This class extends the base Agent to provide structured execution of text processing tasks
	through an underlying platform's text-to-text functionality. It supports optional system
	prompt configuration and integration of media content during processing.
	class InstructAgent

	The class provides a simplified interface for invoking text generation or transformation
	capabilities by abstracting the underlying platform interaction. It ensures proper merging
	of system prompts and additional arguments, prioritizing explicitly provided system prompts
	over those passed through kwargs.

	The run method handles the core execution, delegating to the platform's text2text capability
	while managing required parameters like model selection, input prompt, optional media,
	and structured response formatting through response_model.
	"""

	def __init__(self, **kwargs: Any) -> None:
		super().__init__(**kwargs)

	def run(self, prompt: str, media: Optional[List[Media]] = None, **kwargs: Any) -> Any:
		"""
		Execute a text-to-text transformation using the configured platform.

		This method processes a prompt through the platform's text2text capability,
		optionally incorporating a system prompt if one was provided during initialization.

		Args:
			prompt (str): The input text prompt to process
			media (Optional[List[Media]]): Optional list of media objects to include
										  in the processing (e.g., images, files)
			**kwargs: Additional keyword arguments to pass to the platform's text2text method

		Returns:
			Any: The result from the platform's text2text processing, typically
				 a string or structured data based on response_model parameter

		Note:
			If system_prompt was provided during initialization, it will be merged
			with any additional kwargs, where the system prompt takes precedence
			in case of key conflicts.
		"""

		if self.system_prompt is not None:
			kwargs['system_prompt'] = self.system_prompt

		return self.platform.text2text(
			model=self.model,
			prompt=prompt,
			media=media,
			response_model=self.response_model,
			**kwargs
		)
