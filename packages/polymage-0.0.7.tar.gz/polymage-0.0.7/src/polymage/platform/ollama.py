import json
import logging
import ollama

from typing import Optional, List, Any
from pydantic import BaseModel
from PIL import Image
from tenacity import retry, stop_after_attempt, retry_if_exception_type

from polymage.model.model import Model
from polymage.media.media import Media
from polymage.media.image_media import ImageMedia
from polymage.platform.platform import Platform

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class OllamaPlatform(Platform):
	"""Platform implementation for interacting with Ollama models.

	This class provides concrete implementations of platform methods for text-to-text,
	text-to-data (structured output), and image-to-text operations using the Ollama
	LLM service. It handles client initialization, optional system prompts,
	structured output formatting with retries on JSON parsing failures, and image
	encoding for multimodal inputs. Audio and image generation capabilities are not
	supported and implemented as no-op stubs.

	:var host: The Ollama server endpoint (default: "127.0.0.1:11434").
	:type host: str

	__init__(self, host: str = "127.0.0.1:11434", **kwargs: Any) -> None

	    Initialize the Ollama platform client.

	    :param host: The endpoint URL of the Ollama server, defaults to "127.0.0.1:11434"
	    :type host: str
	    :param kwargs: Additional keyword arguments passed to the parent Platform class

	_text2text(self, model: Model, prompt: str, media: Optional[List[Media]] = None, response_model: Optional[BaseModel] = None, **kwargs: Any) -> str

	    Generate text response from a given prompt using Ollama.

	    :param model: The model configuration to use for inference
	    :type model: Model
	    :param prompt: User prompt text
	    :type prompt: str
	    :param media: Unused in this implementation; allowed for interface compliance
	    :type media: Optional[List[Media]]
	    :param response_model: Unused in this implementation; allowed for interface compliance
	    :type response_model: Optional[BaseModel]
	    :param kwargs: Additional parameters such as 'system_prompt', 'temperature'
	    :type kwargs: Any
	    :return: The generated text response from the model
	    :rtype: str

	_text2data(self, model: Model, prompt: str, response_model: BaseModel, media: Optional[List[Media]] = None, **kwargs: Any) -> str

	    Generate structured data (as JSON-compatible dict) from a prompt using Ollama.

	    Uses model's JSON schema to enforce structured output via the 'format' argument.
	    Retries up to three times in case of JSON parsing errors.

	    :param model: The model configuration to use for inference
	    :type model: Model
	    :param prompt: User prompt text
	    :type prompt: str
	    :param response_model: Pydantic model defining expected JSON structure
	    :type response_model: BaseModel
	    :param media: Unused in this implementation; allowed for interface compliance
	    :type media: Optional[List[Media]]
	    :param kwargs: Additional parameters such as 'system_prompt', 'temperature'
	    :type kwargs: Any
	    :return: A dictionary representation of the structured output
	    :rtype: str

	_image2text(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> str

	    Generate text description of an input image using Ollama.

	    Accepts the first image in the media list, encodes it to Base64, and passes
	    it alongside the prompt for multimodal inference.

	    :param model: The multimodal-capable model configuration to use
	    :type model: Model
	    :param prompt: User instruction about the image
	    :type prompt: str
	    :param media: List containing exactly one image to analyze
	    :type media: List[ImageMedia]
	    :param kwargs: Additional parameters such as 'temperature'
	    :type kwargs: Any
	    :return: Textual response about the image
	    :rtype: str

	_text2image(self, model: str, prompt: str, **kwargs: Any) -> Image.Image

	    Placeholder for image generation; currently unsupported.

	    :param model: Model name (unused)
	    :type model: str
	    :param prompt: Prompt for image generation (unused)
	    :type prompt: str
	    :param kwargs: Additional arguments (unused)
	    :type kwargs: Any
	    :return: None; function is not implemented
	    :rtype: Optional[Image.Image]

	_image2image(self, model: str, prompt: str, image: Image.Image, **kwargs: Any) -> Image.Image

	    Placeholder for image-to-image translation; currently unsupported.

	    :param model: Model name (unused)
	    :type model: str
	    :param prompt: Prompt instruction (unused)
	    :type prompt: str
	    :param image: Input image (unused)
	    :type image: Image.Image
	    :param kwargs: Additional arguments (unused)
	    :type kwargs: Any
	    :return: None; function is not implemented
	    :rtype: Optional[Image.Image]
	"""

	def __init__(self, host: str = "127.0.0.1:11434", **kwargs: Any) -> None:
		super().__init__('ollama', **kwargs)
		self._host = host
		self._api_key = "ollama"  # Dummy key (Ollama doesn't require real keys)

	def _text2text(self, model: Model, prompt: str, media: Optional[List[Media]] = None,
				   response_model: Optional[BaseModel] = None, **kwargs: Any) -> str:
		system_prompt: Optional[str] = kwargs.get("system_prompt", "")
		client = ollama.Client(host=self._host)
		response = client.chat(
			model=model.internal_name(),
			messages=[
				{"role": "system", "content": system_prompt},
				{"role": "user", "content": prompt}
			],
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		return response['message']['content'].strip()

	#
	# using structured data may sometime fail, because the result is not a valid JSON
	# if the JSON is not valid, retry 3 times
	#
	@retry(retry=retry_if_exception_type(json.JSONDecodeError), stop=stop_after_attempt(3))
	def _text2data(self, model: Model, prompt: str, response_model: BaseModel, media: Optional[List[Media]] = None,
				   **kwargs: Any) -> str:
		system_prompt: Optional[str] = kwargs.get("system_prompt", "")
		client = ollama.Client(host=self._host)

		json_schema = response_model.model_json_schema()

		response = client.chat(
			model=model.internal_name(),
			messages=[
				{"role": "system", "content": system_prompt},
				{"role": "user", "content": prompt}
			],
			format=json_schema,
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		json_string = response.message.content.strip()
		# return a python Dict
		return json.loads(json_string)

	def _image2text(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> str:
		client = ollama.Client(host=self._host)
		if len(media) == 0:
			return ""
		else:
			image = media[0]
			base64_image = image.to_base64()

		response = client.chat(
			model=model.internal_name(),
			messages=[
				{
					'role': 'user',
					'content': prompt,
					'images': [base64_image],
				}
			],
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		return response.message.content

	def _text2image(self, model: str, prompt: str, **kwargs: Any) -> Image.Image:
		"""Not supported"""
		pass

	def _image2image(self, model: str, prompt: str, image: Image.Image, **kwargs: Any) -> Image.Image:
		"""Not supported"""
		pass
