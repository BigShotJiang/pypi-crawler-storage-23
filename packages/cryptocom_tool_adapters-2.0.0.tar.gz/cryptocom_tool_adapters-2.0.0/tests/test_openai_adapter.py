"""Tests for OpenAI adapter."""

from cryptocom_tool_adapters.openai import create_openai_executor, to_openai_function

from .test_utils import MockTool


def test_to_openai_function_basic():
    """Test basic conversion to OpenAI function format."""
    tool = MockTool()
    result = to_openai_function(tool)

    assert result["type"] == "function"
    assert result["function"]["name"] == "mock_tool"
    description = result["function"].get("description", "")
    assert description == "A mock tool for testing"
    parameters = result["function"].get("parameters")
    assert parameters == tool.parameters_schema


def test_to_openai_function_with_context():
    """Test conversion with context."""
    tool = MockTool()
    context = {"wallet_address": "0x1234"}
    result = to_openai_function(tool, context)

    assert result["type"] == "function"
    description = result["function"].get("description", "")
    assert "wallet_address=0x1234" in description


def test_create_openai_executor_basic():
    """Test executor creation and execution."""
    tool = MockTool()
    executor = create_openai_executor(tool)

    # Execute with OpenAI-style arguments
    result = executor({"input": "test", "count": 3})

    assert result.success is True
    assert result.value == "test_3"


def test_create_openai_executor_with_context():
    """Test executor with pre-bound context."""
    tool = MockTool()
    context = {"wallet_address": "0x1234", "network": "cronos"}
    executor = create_openai_executor(tool, context)

    # Execute with OpenAI-style arguments
    # Context should be merged with arguments
    result = executor({"input": "test"})

    assert result.success is True
    # The mock tool includes extra kwargs in the result
    assert "wallet_address=0x1234" in result.value
    assert "network=cronos" in result.value


def test_create_openai_executor_override_context():
    """Test that arguments can override context."""
    tool = MockTool()
    context = {"count": 5}
    executor = create_openai_executor(tool, context)

    # Arguments should override context
    result = executor({"input": "test", "count": 10})

    assert result.success is True
    assert result.value == "test_10"  # Uses 10 from args, not 5 from context
