"""Tests for LangGraph adapter."""

from typing import Any, Dict, cast

import pytest

from cryptocom_tool_adapters.langgraph import (
    create_langgraph_executor,
    to_langgraph_tool,
    with_injected_state,
)

from .test_utils import MockTool


def test_to_langgraph_tool_basic():
    """Test basic conversion to LangGraph tool."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    tool = MockTool()

    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract nothing from state."""
        return {}

    lg_tool = to_langgraph_tool(tool, state_extractor, injected_param_names=["wallet_address"])

    # Check basic properties
    assert lg_tool.name == "mock_tool"
    assert lg_tool.description == "A mock tool for testing"

    # Simulate state injection (normally done by LangGraph)
    state = {"some_state": "value"}
    result = lg_tool.invoke({"input": "test", "count": 3, "state": state})

    # The result should be the string representation of MockResult
    assert "test_3" in result


def test_to_langgraph_tool_with_state_extraction():
    """Test LangGraph tool with state extraction."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    tool = MockTool()

    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract wallet from state."""
        wallets = state.get("wallets", {})
        active = wallets.get("active", "default_wallet")
        return {"wallet_address": active}

    lg_tool = to_langgraph_tool(
        tool,
        state_extractor,
        injected_param_names=["wallet_address", "gas_limit"],
    )

    # Check that args_schema is properly filtered
    # The schema should not include wallet_address since it's injected
    args_schema = lg_tool.args_schema
    # args_schema is a Pydantic model class, check its fields
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))
    assert "wallet_address" not in schema_fields
    assert "input" in schema_fields
    assert "count" in schema_fields
    assert "state" in schema_fields  # InjectedState is always present


def test_with_injected_state_simple():
    """Test simple state injection without mapping."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    tool = MockTool()

    # Inject wallet_address from state
    lg_tool = with_injected_state(tool, ["wallet_address"])

    assert lg_tool.name == "mock_tool"
    assert lg_tool.description == "A mock tool for testing"

    # Check args_schema - it's a Pydantic model class
    args_schema = lg_tool.args_schema
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))
    assert "wallet_address" not in schema_fields
    assert "input" in schema_fields
    assert "state" in schema_fields  # InjectedState is always present


def test_with_injected_state_with_mapping():
    """Test state injection with key mapping."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    tool = MockTool()

    # Map active_wallet -> wallet_address
    lg_tool = with_injected_state(
        tool, ["active_wallet", "network"], {"active_wallet": "wallet_address"}
    )

    assert lg_tool.name == "mock_tool"

    # Check args_schema - it's a Pydantic model class
    args_schema = lg_tool.args_schema
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))
    assert "wallet_address" not in schema_fields
    assert "network" not in schema_fields
    assert "input" in schema_fields
    assert "state" in schema_fields  # InjectedState is always present


def test_create_langgraph_executor():
    """Test executor creation for LangGraph tools."""
    tool = MockTool()

    state = {"wallets": {"active": "0x123"}, "network": "cronos"}

    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract wallet and network from state."""
        wallets = state.get("wallets", {})
        return {"wallet_address": wallets.get("active"), "network": state.get("network")}

    executor = create_langgraph_executor(tool, state, state_extractor)

    # Execute with just the LLM-provided args
    result = executor({"input": "test", "count": 5})

    assert result.success is True
    # Check that state values were injected
    assert "wallet_address=0x123" in result.value
    assert "network=cronos" in result.value
    assert "test_5" in result.value


def test_args_override_state():
    """Test that LLM-provided args can override state values."""
    tool = MockTool()

    state = {
        "count": 10,  # Default count from state
        "network": "mainnet",
    }

    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract count and network from state."""
        return {"count": state.get("count"), "network": state.get("network")}

    executor = create_langgraph_executor(tool, state, state_extractor)

    # Override count with LLM arg
    result = executor({"input": "test", "count": 3})

    assert result.success is True
    # Should use 3 from args, not 10 from state
    assert "test_3" in result.value
    assert "network=mainnet" in result.value


def test_complex_state_extraction():
    """Test complex state extraction logic."""
    tool = MockTool()

    state = {
        "user": {
            "wallets": [{"address": "0xabc", "active": False}, {"address": "0xdef", "active": True}]
        },
        "config": {"network": "testnet", "gas_limit": 21000},
    }

    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract active wallet and config from nested state."""
        user = state.get("user", {})
        wallets = user.get("wallets", [])

        # Find active wallet
        active_wallet = None
        for wallet in wallets:
            if wallet.get("active"):
                active_wallet = wallet.get("address")
                break

        # Extract config
        config = state.get("config", {})

        return {
            "wallet_address": active_wallet,
            "network": config.get("network"),
            "gas_limit": config.get("gas_limit"),
        }

    executor = create_langgraph_executor(tool, state, state_extractor)

    result = executor({"input": "complex"})

    assert result.success is True
    assert "wallet_address=0xdef" in result.value
    assert "network=testnet" in result.value
    assert "gas_limit=21000" in result.value


def test_empty_state_handling():
    """Test handling of empty or missing state."""
    tool = MockTool()

    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract with defaults for missing keys."""
        return {
            "wallet_address": state.get("wallet", "no_wallet"),
            "network": state.get("network", "mainnet"),
        }

    # Empty state
    executor = create_langgraph_executor(tool, {}, state_extractor)
    result = executor({"input": "empty"})

    assert result.success is True
    assert "wallet_address=no_wallet" in result.value
    assert "network=mainnet" in result.value


def test_schema_filtering_in_to_langgraph_tool():
    """Test that args_schema properly filters out injected params."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    # Create a more complex tool with multiple parameters
    class ComplexTool:
        name = "complex_tool"
        description = "A complex tool"
        parameters_schema: Dict[str, Any] = {
            "type": "object",
            "properties": {
                "wallet_address": {"type": "string"},
                "to_address": {"type": "string"},
                "amount": {"type": "number"},
                "gas_limit": {"type": "integer"},
                "memo": {"type": "string"},
            },
            "required": ["wallet_address", "to_address", "amount"],
        }

        def execute(self, **kwargs: Any) -> str:
            return f"Executed with {kwargs}"

    tool = ComplexTool()

    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract wallet and gas from state."""
        return {
            "wallet_address": state.get("wallet", "0x000"),
            "gas_limit": state.get("gas", 21000),
        }

    lg_tool = to_langgraph_tool(
        tool,
        state_extractor,
        injected_param_names=["wallet_address", "gas_limit"],
    )

    # Check filtered schema - args_schema is a Pydantic model class
    args_schema = lg_tool.args_schema
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))

    # wallet_address and gas_limit should be filtered out
    assert "wallet_address" not in schema_fields
    assert "gas_limit" not in schema_fields

    # Other params should remain
    assert "to_address" in schema_fields
    assert "amount" in schema_fields
    assert "memo" in schema_fields
    assert "state" in schema_fields  # InjectedState is always present

    # Check which fields are required (in Pydantic v2, check if field is not optional)
    assert schema_fields["to_address"].is_required() is True
    assert schema_fields["amount"].is_required() is True
    assert schema_fields["memo"].is_required() is False  # Not in required list


def test_schema_filtering_in_with_injected_state():
    """Test schema filtering in with_injected_state."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    class ComplexTool:
        name = "complex_tool"
        description = "A complex tool"
        parameters_schema: Dict[str, Any] = {
            "type": "object",
            "properties": {
                "wallet": {"type": "string"},
                "recipient": {"type": "string"},
                "amount": {"type": "number"},
                "network": {"type": "string"},
            },
            "required": ["wallet", "recipient", "amount"],
        }

        def execute(self, **kwargs: Any) -> str:
            return f"Executed with {kwargs}"

    tool = ComplexTool()

    # Inject with mapping
    lg_tool = with_injected_state(
        tool,
        ["active_wallet", "current_network"],
        {"active_wallet": "wallet", "current_network": "network"},
    )

    args_schema = lg_tool.args_schema
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))

    # Mapped params should be filtered
    assert "wallet" not in schema_fields
    assert "network" not in schema_fields

    # Other params should remain
    assert "recipient" in schema_fields
    assert "amount" in schema_fields
    assert "state" in schema_fields  # InjectedState is always present

    # Check which fields are required (in Pydantic v2, check if field is not optional)
    assert schema_fields["recipient"].is_required() is True
    assert schema_fields["amount"].is_required() is True


def test_to_langgraph_tool_does_not_call_state_extractor_during_setup():
    """Tool conversion should not probe state_extractor with dummy state."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    tool = MockTool()
    called = False

    def strict_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        nonlocal called
        called = True
        return {"wallet_address": state["wallets"]["active"]}

    lg_tool = to_langgraph_tool(tool, strict_extractor, injected_param_names=["wallet_address"])

    # Constructing the tool should not run state extraction.
    assert called is False

    result = lg_tool.invoke({"input": "ok", "count": 1, "state": {"wallets": {"active": "0x1"}}})
    assert "ok_1" in result
    assert called is True
