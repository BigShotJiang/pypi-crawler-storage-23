"""
Integration tests for OpenAI SDK adapter with full type checking.

Tests that the adapter properly generates OpenAI-compatible function schemas
and can be used with the actual OpenAI SDK.
"""

import json
from typing import Any, Dict
from unittest.mock import Mock, patch

import pytest

from cryptocom_tool_adapters.openai import create_openai_executor, to_openai_function

from .test_utils import MockTool


class TestOpenAISDKIntegration:
    """Test OpenAI SDK integration with proper type checking."""

    def test_schema_matches_openai_spec(self):
        """Test that generated schema matches OpenAI ChatCompletionToolParam spec."""
        tool = MockTool()
        schema = to_openai_function(tool)

        # Verify top-level structure
        assert schema["type"] == "function"
        assert "function" in schema

        # Verify function definition
        func_def = schema["function"]
        assert isinstance(func_def["name"], str)
        assert func_def["name"] == "mock_tool"
        description = func_def.get("description")
        assert isinstance(description, str)
        assert "parameters" in func_def

        # Verify parameters follow JSON Schema spec
        params = func_def["parameters"]
        assert params["type"] == "object"
        assert "properties" in params
        assert "required" in params
        assert isinstance(params["required"], list)

    def test_tool_call_execution_flow(self):
        """Test the full flow of tool call execution."""
        tool = MockTool()
        executor = create_openai_executor(tool)

        # Simulate OpenAI tool call arguments
        tool_args = {"input": "test_value", "count": 5}

        # Execute tool
        result = executor(tool_args)

        # Verify result
        assert result.success is True
        assert result.value == "test_value_5"

    def test_context_injection_in_execution(self):
        """Test that context is properly injected during execution."""
        tool = MockTool()
        context = {"user_id": "123", "session": "abc"}
        executor = create_openai_executor(tool, context)

        # Execute with partial arguments
        result = executor({"input": "data"})

        # MockTool includes extra kwargs in result
        assert "user_id=123" in result.value
        assert "session=abc" in result.value

    @patch("openai.OpenAI")
    def test_mock_openai_client_interaction(self, mock_openai_class: Mock):
        """Test interaction with mocked OpenAI client."""
        # Setup mock OpenAI client
        mock_client = Mock()
        mock_openai_class.return_value = mock_client

        # Setup mock response
        mock_message = Mock()
        mock_message.tool_calls = [
            Mock(
                id="call_123",
                type="function",
                function=Mock(name="mock_tool", arguments='{"input": "hello", "count": 2}'),
            )
        ]
        mock_response = Mock()
        mock_response.choices = [Mock(message=mock_message)]
        mock_client.chat.completions.create.return_value = mock_response

        # Create tool and schema
        tool = MockTool()
        tool_schema = to_openai_function(tool)
        executor = create_openai_executor(tool)

        # Simulate OpenAI API call
        from openai import OpenAI

        client = OpenAI(api_key="test-key")

        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "test"}],
            tools=[tool_schema],
            tool_choice="auto",
        )

        # Process tool calls
        message = response.choices[0].message
        assert message.tool_calls is not None
        for tool_call in message.tool_calls:
            # Type narrow to ChatCompletionMessageToolCall which has function attribute
            if tool_call.type == "function":
                func = tool_call.function
                if func.name == "mock_tool":
                    args = json.loads(func.arguments)
                    result = executor(args)
                    assert result.success is True
                    assert result.value == "hello_2"

    def test_multiple_tools_registration(self):
        """Test registering multiple tools with OpenAI."""
        # Create multiple tools
        tool1 = MockTool()
        tool1.name = "tool_1"
        tool1.description = "First tool"

        tool2 = MockTool()
        tool2.name = "tool_2"
        tool2.description = "Second tool"

        # Convert to OpenAI format
        tools = [
            to_openai_function(tool1),
            to_openai_function(tool2),
        ]

        # Verify both tools are properly formatted
        assert len(tools) == 2
        assert tools[0]["function"]["name"] == "tool_1"
        assert tools[1]["function"]["name"] == "tool_2"

        # Create executors
        executors = {
            "tool_1": create_openai_executor(tool1),
            "tool_2": create_openai_executor(tool2),
        }

        # Test execution of both
        result1 = executors["tool_1"]({"input": "test1"})
        result2 = executors["tool_2"]({"input": "test2", "count": 3})

        assert result1.value == "test1_1"
        assert result2.value == "test2_3"

    def test_error_handling_in_executor(self):
        """Test error handling in the executor."""

        class ErrorTool:
            name = "error_tool"
            description = "Tool that raises errors"
            parameters_schema: Dict[str, Any] = {
                "type": "object",
                "properties": {"should_fail": {"type": "boolean"}},
                "required": [],
            }

            def execute(self, should_fail: bool = False, **kwargs: Any) -> Dict[str, bool]:
                if should_fail:
                    raise ValueError("Intentional error")
                return {"success": True}

        tool = ErrorTool()
        executor = create_openai_executor(tool)

        # Test successful execution
        result = executor({"should_fail": False})
        assert result["success"] is True

        # Test error case
        with pytest.raises(ValueError, match="Intentional error"):
            executor({"should_fail": True})

    def test_optional_parameters_handling(self):
        """Test handling of optional parameters."""

        class OptionalParamTool:
            name = "optional_tool"
            description = "Tool with optional parameters"
            parameters_schema: Dict[str, Any] = {
                "type": "object",
                "properties": {
                    "required_param": {"type": "string", "description": "Required parameter"},
                    "optional_param": {
                        "type": "string",
                        "description": "Optional parameter",
                        "default": "default_value",
                    },
                },
                "required": ["required_param"],
            }

            def execute(
                self,
                required_param: str,
                optional_param: str = "default_value",
                **kwargs: Any,
            ) -> str:
                return f"{required_param}:{optional_param}"

        tool = OptionalParamTool()
        executor = create_openai_executor(tool)

        # Test with only required parameter
        result = executor({"required_param": "test"})
        assert result == "test:default_value"

        # Test with both parameters
        result = executor({"required_param": "test", "optional_param": "custom"})
        assert result == "test:custom"

    def test_context_description_update(self):
        """Test that context is properly noted in the description."""
        tool = MockTool()
        context = {"wallet_address": "0xABC", "network": "cronos-testnet"}

        schema = to_openai_function(tool, context)

        # Verify context is mentioned in description
        description = schema["function"].get("description", "")
        assert "wallet_address=0xABC" in description
        assert "network=cronos-testnet" in description
        assert "Context:" in description
