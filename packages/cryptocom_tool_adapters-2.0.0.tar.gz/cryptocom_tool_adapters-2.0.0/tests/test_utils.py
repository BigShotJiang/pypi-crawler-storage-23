"""Test utilities and mock tools for adapter testing."""

from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class MockResult:
    """Mock result for testing."""

    success: bool
    value: str


class MockTool:
    """Mock tool for testing adapters."""

    name = "mock_tool"
    description = "A mock tool for testing"

    # Use class-level attribute instead of property for protocol compatibility
    parameters_schema: Dict[str, Any] = {
        "type": "object",
        "properties": {
            "input": {
                "type": "string",
                "description": "Input value",
            },
            "count": {
                "type": "integer",
                "description": "Number of iterations",
            },
        },
        "required": ["input"],
    }

    def execute(self, input: str, count: int = 1, **kwargs: Any) -> MockResult:
        """Execute the mock tool."""
        # Include any extra kwargs in the result for testing context injection
        extra = "_".join(f"{k}={v}" for k, v in kwargs.items())
        value = f"{input}_{count}"
        if extra:
            value = f"{value}_{extra}"
        return MockResult(success=True, value=value)
