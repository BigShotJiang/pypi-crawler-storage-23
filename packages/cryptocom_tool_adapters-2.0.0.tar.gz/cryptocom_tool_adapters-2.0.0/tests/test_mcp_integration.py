"""Integration tests for MCP adapter with actual crypto tools."""

import json
from typing import Any, Dict

from cryptocom_tool_adapters.mcp import create_mcp_handler, to_mcp_tool


class MockBalanceTool:
    """Mock balance tool simulating a real crypto tool."""

    name = "get_native_balance"
    description = "Get native token balance for an address"

    @property
    def parameters_schema(self) -> Dict[str, Any]:
        """Return JSON schema for parameters."""
        return {
            "type": "object",
            "properties": {
                "address": {
                    "type": "string",
                    "description": "Blockchain address",
                },
                "use_wei": {
                    "type": "boolean",
                    "description": "Return balance in wei units",
                    "default": False,
                },
            },
            "required": ["address"],
        }

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """Execute the tool."""
        address = kwargs["address"]
        use_wei = kwargs.get("use_wei", False)
        # Simulate balance lookup
        balance = 1000000000000000000 if use_wei else 1.0
        unit = "wei" if use_wei else "ETH"
        return {
            "address": address,
            "balance": str(balance),
            "unit": unit,
        }


class MockTransferTool:
    """Mock transfer tool simulating injected context."""

    name = "transfer_native_token"
    description = "Transfer native tokens to an address"

    @property
    def parameters_schema(self) -> Dict[str, Any]:
        """Return JSON schema for parameters."""
        return {
            "type": "object",
            "properties": {
                "to": {
                    "type": "string",
                    "description": "Recipient blockchain address",
                },
                "amount": {
                    "type": "number",
                    "description": "Amount of native tokens to transfer",
                },
            },
            "required": ["to", "amount"],
        }

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """Execute the transfer."""
        wallet_address = kwargs["wallet_address"]
        to = kwargs["to"]
        amount = kwargs["amount"]
        # Simulate transfer
        return {
            "tx_hash": f"0x{'a' * 64}",
            "tx_link": f"https://cronoscan.com/tx/0x{'a' * 64}",
            "from": wallet_address,
            "to": to,
            "amount": amount,
        }


def test_mcp_balance_tool_integration():
    """Test MCP adapter with balance tool."""
    tool = MockBalanceTool()

    # Convert to MCP format
    mcp_tool = to_mcp_tool(tool)

    # Verify MCP tool structure
    assert mcp_tool["name"] == "get_native_balance"
    assert "inputSchema" in mcp_tool
    assert mcp_tool["inputSchema"]["properties"]["address"]["type"] == "string"

    # Create handler and execute
    handler = create_mcp_handler(tool)
    result = handler({"address": "0x1234567890abcdef"})

    assert result["success"] is True
    assert result["result"]["balance"] == "1.0"
    assert result["result"]["unit"] == "ETH"


def test_mcp_transfer_tool_with_context():
    """Test MCP adapter with transfer tool and context injection."""
    tool = MockTransferTool()

    # Context provides the wallet address (not visible to LLM)
    context = {"wallet_address": "0xAAA"}

    # Convert to MCP format with context
    mcp_tool = to_mcp_tool(tool, context)

    # Verify context is noted in description
    assert "wallet_address=0xAAA" in mcp_tool["description"]

    # Verify inputSchema doesn't include wallet_address (it's injected)
    assert "wallet_address" not in mcp_tool["inputSchema"]["properties"]

    # Create handler with context
    handler = create_mcp_handler(tool, context)

    # Execute with only LLM-visible parameters
    result = handler({"to": "0xBBB", "amount": 10.5})

    assert result["success"] is True
    assert result["result"]["from"] == "0xAAA"  # Injected from context
    assert result["result"]["to"] == "0xBBB"
    assert result["result"]["amount"] == 10.5


def test_mcp_tool_registry_simulation():
    """Simulate registering multiple tools with an MCP server."""
    # Create multiple tools
    balance_tool = MockBalanceTool()
    transfer_tool = MockTransferTool()

    # Context for tools that need it
    context = {"wallet_address": "0x123"}

    # Convert all tools to MCP format
    tools_registry = [
        to_mcp_tool(balance_tool),
        to_mcp_tool(transfer_tool, context),
    ]

    # Verify all tools are properly formatted for MCP
    for tool_def in tools_registry:
        assert "name" in tool_def
        assert "description" in tool_def
        assert "inputSchema" in tool_def

        # Verify JSON serializable (important for MCP protocol)
        json_str = json.dumps(tool_def)
        parsed = json.loads(json_str)
        assert parsed == tool_def

    # Create handlers map (simulating MCP server registry)
    handlers = {
        "get_native_balance": create_mcp_handler(balance_tool),
        "transfer_native_token": create_mcp_handler(transfer_tool, context),
    }

    # Simulate MCP tool calls
    balance_result = handlers["get_native_balance"]({"address": "0x999", "use_wei": True})
    assert balance_result["success"] is True
    assert balance_result["result"]["unit"] == "wei"

    transfer_result = handlers["transfer_native_token"]({"to": "0x888", "amount": 5.0})
    assert transfer_result["success"] is True
    assert transfer_result["result"]["from"] == "0x123"  # From context


def test_mcp_error_handling_integration():
    """Test MCP adapter error handling with realistic scenarios."""

    class FailingTool:
        """Tool that can fail in various ways."""

        name = "failing_tool"
        description = "Tool for testing error scenarios"

        @property
        def parameters_schema(self) -> Dict[str, Any]:
            return {
                "type": "object",
                "properties": {
                    "action": {"type": "string"},
                },
                "required": ["action"],
            }

        def execute(self, **kwargs: Any) -> Any:
            action = kwargs["action"]
            if action == "network_error":
                raise ConnectionError("Network request failed")
            elif action == "invalid_input":
                raise ValueError("Invalid blockchain address")
            elif action == "timeout":
                raise TimeoutError("Transaction timed out")
            else:
                return {"status": "success"}

    tool = FailingTool()
    handler = create_mcp_handler(tool)

    # Test network error
    result = handler({"action": "network_error"})
    assert result["success"] is False
    assert "Network request failed" in result["error"]

    # Test validation error
    result = handler({"action": "invalid_input"})
    assert result["success"] is False
    assert "Invalid blockchain address" in result["error"]

    # Test timeout
    result = handler({"action": "timeout"})
    assert result["success"] is False
    assert "Transaction timed out" in result["error"]

    # Test success
    result = handler({"action": "success"})
    assert result["success"] is True
    assert result["result"]["status"] == "success"
