"""
Integration tests for Anthropic SDK adapter with full type checking.

Tests that the adapter properly generates Anthropic-compatible tool schemas
and can be used with the actual Anthropic SDK.
"""

from typing import TYPE_CHECKING, Any, Dict
from unittest.mock import Mock, patch

import pytest

from cryptocom_tool_adapters.anthropic import create_anthropic_executor, to_anthropic_tool

from .test_utils import MockTool

if TYPE_CHECKING:
    pass


class TestAnthropicSDKIntegration:
    """Test Anthropic SDK integration with proper type checking."""

    def test_schema_matches_anthropic_spec(self):
        """Test that generated schema matches Anthropic ToolParam spec."""
        tool = MockTool()
        schema = to_anthropic_tool(tool)

        # Verify required fields for Anthropic tool
        assert "name" in schema
        assert schema["name"] == "mock_tool"
        assert "description" in schema
        assert "input_schema" in schema

        # Verify input_schema follows JSON Schema spec
        input_schema = schema["input_schema"]
        assert input_schema["type"] == "object"
        assert "properties" in input_schema
        assert "required" in input_schema
        assert isinstance(input_schema["required"], list)

    def test_tool_call_execution_flow(self):
        """Test the full flow of tool call execution."""
        tool = MockTool()
        executor = create_anthropic_executor(tool)

        # Simulate Anthropic tool use inputs
        tool_inputs = {"input": "test_value", "count": 5}

        # Execute tool
        result = executor(tool_inputs)

        # Verify result
        assert result.success is True
        assert result.value == "test_value_5"

    def test_context_injection_in_execution(self):
        """Test that context is properly injected during execution."""
        tool = MockTool()
        context = {"user_id": "123", "session": "abc"}
        executor = create_anthropic_executor(tool, context)

        # Execute with partial arguments
        result = executor({"input": "data"})

        # MockTool includes extra kwargs in result
        assert "user_id=123" in result.value
        assert "session=abc" in result.value

    @patch("anthropic.Anthropic")
    def test_mock_anthropic_client_interaction(self, mock_anthropic_class: Mock):
        """Test interaction with mocked Anthropic client."""
        # Setup mock Anthropic client
        mock_client = Mock()
        mock_anthropic_class.return_value = mock_client

        # Setup mock response with tool use
        mock_tool_use = Mock(
            type="tool_use",
            id="tool_use_123",
            name="mock_tool",
            input={"input": "hello", "count": 2},
        )
        mock_message = Mock(content=[mock_tool_use])
        mock_client.messages.create.return_value = mock_message

        # Create tool and schema
        tool = MockTool()
        tool_schema = to_anthropic_tool(tool)
        executor = create_anthropic_executor(tool)

        # Simulate Anthropic API call
        from anthropic import Anthropic

        client = Anthropic(api_key="test-key")

        response = client.messages.create(
            model="claude-3-opus-20240229",
            messages=[{"role": "user", "content": "test"}],
            tools=[tool_schema],
            max_tokens=1024,
        )

        # Process tool uses
        for content in response.content:
            if content.type == "tool_use" and content.name == "mock_tool":
                result = executor(content.input)
                assert result.success is True
                assert result.value == "hello_2"

    def test_multiple_tools_registration(self):
        """Test registering multiple tools with Anthropic."""
        # Create multiple tools
        tool1 = MockTool()
        tool1.name = "tool_1"
        tool1.description = "First tool"

        tool2 = MockTool()
        tool2.name = "tool_2"
        tool2.description = "Second tool"

        # Convert to Anthropic format
        tools = [
            to_anthropic_tool(tool1),
            to_anthropic_tool(tool2),
        ]

        # Verify both tools are properly formatted
        assert len(tools) == 2
        assert tools[0]["name"] == "tool_1"
        assert tools[1]["name"] == "tool_2"

        # Create executors
        executors = {
            "tool_1": create_anthropic_executor(tool1),
            "tool_2": create_anthropic_executor(tool2),
        }

        # Test execution of both
        result1 = executors["tool_1"]({"input": "test1"})
        result2 = executors["tool_2"]({"input": "test2", "count": 3})

        assert result1.value == "test1_1"
        assert result2.value == "test2_3"

    def test_error_handling_in_executor(self):
        """Test error handling in the executor."""

        class ErrorTool:
            name = "error_tool"
            description = "Tool that raises errors"

            @property
            def parameters_schema(self) -> Dict[str, Any]:
                return {
                    "type": "object",
                    "properties": {"should_fail": {"type": "boolean"}},
                    "required": [],
                }

            def execute(self, should_fail: bool = False, **kwargs: Any):
                if should_fail:
                    raise ValueError("Intentional error")
                return {"success": True}

        tool = ErrorTool()
        executor = create_anthropic_executor(tool)

        # Test successful execution
        result = executor({"should_fail": False})
        assert result["success"] is True

        # Test error case
        with pytest.raises(ValueError, match="Intentional error"):
            executor({"should_fail": True})

    def test_optional_parameters_handling(self):
        """Test handling of optional parameters."""

        class OptionalParamTool:
            name = "optional_tool"
            description = "Tool with optional parameters"

            @property
            def parameters_schema(self) -> Dict[str, Any]:
                return {
                    "type": "object",
                    "properties": {
                        "required_param": {"type": "string", "description": "Required parameter"},
                        "optional_param": {
                            "type": "string",
                            "description": "Optional parameter",
                            "default": "default_value",
                        },
                    },
                    "required": ["required_param"],
                }

            def execute(
                self, required_param: str, optional_param: str = "default_value", **kwargs: Any
            ):
                return f"{required_param}:{optional_param}"

        tool = OptionalParamTool()
        executor = create_anthropic_executor(tool)

        # Test with only required parameter
        result = executor({"required_param": "test"})
        assert result == "test:default_value"

        # Test with both parameters
        result = executor({"required_param": "test", "optional_param": "custom"})
        assert result == "test:custom"

    def test_context_description_update(self):
        """Test that context is properly noted in the description."""
        tool = MockTool()
        context = {"wallet_address": "0xABC", "network": "cronos-testnet"}

        schema = to_anthropic_tool(tool, context)

        # Verify context is mentioned in description
        description = schema.get("description", "")
        assert "wallet_address=0xABC" in description
        assert "network=cronos-testnet" in description
        assert "Context:" in description

    def test_anthropic_specific_fields(self):
        """Test that Anthropic-specific fields are handled correctly."""
        tool = MockTool()
        schema = to_anthropic_tool(tool)

        # Anthropic uses 'input_schema' instead of 'parameters'
        assert "input_schema" in schema
        assert "parameters" not in schema

        # Verify the structure matches what Anthropic expects
        assert isinstance(schema["name"], str)
        assert isinstance(schema.get("description", ""), str)
        assert isinstance(schema["input_schema"], dict)

    def test_tool_result_format(self):
        """Test that tool results can be properly formatted for Anthropic responses."""
        tool = MockTool()
        executor = create_anthropic_executor(tool)

        result = executor({"input": "test", "count": 3})

        # Anthropic expects tool results as strings or structured data
        # Our MockTool returns a MockResult object
        result_str = str(result)
        assert "success=True" in result_str
        assert "value='test_3'" in result_str

        # Alternatively, can access attributes
        assert hasattr(result, "success")
        assert hasattr(result, "value")
