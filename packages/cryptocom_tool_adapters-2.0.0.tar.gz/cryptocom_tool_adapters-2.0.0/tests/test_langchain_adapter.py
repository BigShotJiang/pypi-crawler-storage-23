"""Tests for LangChain adapter."""

from typing import Any, Dict
from unittest.mock import Mock, patch

from cryptocom_tool_adapters.langchain import (
    create_langchain_executor,
    to_langchain_tool,
)

from .test_utils import MockTool


class TestToLangchainTool:
    """Tests for to_langchain_tool function."""

    def test_basic_conversion(self):
        """Test basic conversion to LangChain StructuredTool."""
        tool = MockTool()

        # Mock the StructuredTool import inside the function
        with patch("langchain_core.tools.StructuredTool") as mock_structured_tool:
            mock_tool_instance = Mock()
            mock_structured_tool.from_function.return_value = mock_tool_instance

            to_langchain_tool(tool)

            # Verify StructuredTool.from_function was called
            mock_structured_tool.from_function.assert_called_once()
            call_kwargs = mock_structured_tool.from_function.call_args.kwargs

            assert call_kwargs["name"] == "mock_tool"
            assert call_kwargs["description"] == "A mock tool for testing"
            assert callable(call_kwargs["func"])

            # Test the wrapped function
            func = call_kwargs["func"]
            result_str = func(input="test", count=3)
            assert result_str == "MockResult(success=True, value='test_3')"

    def test_with_context(self):
        """Test conversion with pre-bound context."""
        tool = MockTool()
        context = {"wallet_address": "0x1234", "network": "cronos"}

        with patch("langchain_core.tools.StructuredTool") as mock_structured_tool:
            mock_tool_instance = Mock()
            mock_structured_tool.from_function.return_value = mock_tool_instance

            to_langchain_tool(tool, context)

            # Verify the function was called
            mock_structured_tool.from_function.assert_called_once()
            call_kwargs = mock_structured_tool.from_function.call_args.kwargs

            # Check description includes context
            expected_desc = (
                "A mock tool for testing (Context: wallet_address=0x1234, network=cronos)"
            )
            assert call_kwargs["description"] == expected_desc

            # Test the wrapped function merges context
            func = call_kwargs["func"]
            result_str = func(input="test")
            assert "wallet_address=0x1234" in result_str
            assert "network=cronos" in result_str

    def test_args_schema_generation(self):
        """Test that args_schema is properly generated from parameters_schema."""
        tool = MockTool()

        with patch("langchain_core.tools.StructuredTool") as mock_structured_tool:
            with patch("pydantic.create_model") as mock_create_model:
                mock_model = Mock()
                mock_create_model.return_value = mock_model
                mock_structured_tool.from_function.return_value = Mock()

                to_langchain_tool(tool)

                # Verify create_model was called to create Pydantic schema
                mock_create_model.assert_called_once()
                call_args = mock_create_model.call_args
                model_name = call_args[0][0]  # First positional arg
                fields = call_args[1]  # Keyword args

                assert model_name == "mock_tool_Args"
                # Check that fields were created for the schema
                assert "input" in fields
                assert "count" in fields

    def test_with_context_excludes_fields_from_schema(self):
        """Test that context fields are excluded from args_schema."""
        tool = MockTool()
        context = {"input": "fixed_input"}  # Pre-bind the 'input' field

        with patch("langchain_core.tools.StructuredTool") as mock_structured_tool:
            with patch("pydantic.create_model") as mock_create_model:
                mock_model = Mock()
                mock_create_model.return_value = mock_model
                mock_structured_tool.from_function.return_value = Mock()

                to_langchain_tool(tool, context)

                # Verify create_model was called
                mock_create_model.assert_called_once()
                call_args = mock_create_model.call_args
                call_args[0][0]  # First positional arg
                fields = call_args[1]  # Keyword args

                # 'input' should be excluded since it's in context
                assert "input" not in fields
                # 'count' should still be included
                assert "count" in fields

    def test_empty_parameters_schema(self):
        """Test tool with no parameters."""

        class NoParamTool:
            name = "no_param_tool"
            description = "Tool with no parameters"
            parameters_schema: Dict[str, Any] = {"type": "object", "properties": {}, "required": []}

            def execute(self, **kwargs: Any) -> str:
                return "success"

        tool = NoParamTool()

        with patch("langchain_core.tools.StructuredTool") as mock_structured_tool:
            mock_structured_tool.from_function.return_value = Mock()

            to_langchain_tool(tool)

            mock_structured_tool.from_function.assert_called_once()
            call_kwargs = mock_structured_tool.from_function.call_args.kwargs

            # args_schema should be None for tool with no parameters
            assert call_kwargs["args_schema"] is None

    def test_required_vs_optional_fields(self):
        """Test handling of required and optional fields in schema."""

        class DetailedTool:
            name = "detailed_tool"
            description = "Tool with required and optional fields"
            parameters_schema: Dict[str, Any] = {
                "type": "object",
                "properties": {
                    "required_field": {"type": "string", "description": "This is required"},
                    "optional_field": {"type": "integer", "description": "This is optional"},
                },
                "required": ["required_field"],
            }

            def execute(self, **kwargs: Any) -> Dict[str, Any]:
                return kwargs

        tool = DetailedTool()

        with patch("langchain_core.tools.StructuredTool") as mock_structured_tool:
            with patch("pydantic.create_model") as mock_create_model:
                mock_model = Mock()
                mock_create_model.return_value = mock_model
                mock_structured_tool.from_function.return_value = Mock()

                to_langchain_tool(tool)

                mock_create_model.assert_called_once()
                call_args = mock_create_model.call_args
                call_args[0][0]  # First positional arg
                fields = call_args[1]  # Keyword args

                # Check field definitions
                assert "required_field" in fields
                assert "optional_field" in fields

                # Required field should not have Optional type
                required_field_def = fields["required_field"]
                assert required_field_def[0] is str  # Type should be str, not Optional[str]

                # Optional field should have Optional type
                from typing import Optional

                optional_field_def = fields["optional_field"]
                # Check if it's Optional[int] type annotation
                assert optional_field_def[0] == Optional[int]  # noqa: E721


class TestCreateLangchainExecutor:
    """Tests for create_langchain_executor function."""

    def test_basic_executor(self):
        """Test basic executor creation and execution."""
        tool = MockTool()
        executor = create_langchain_executor(tool)

        # Execute with arguments
        result = executor({"input": "test", "count": 5})

        # Should return string representation
        assert result == "MockResult(success=True, value='test_5')"
        assert isinstance(result, str)

    def test_executor_with_context(self):
        """Test executor with pre-bound context."""
        tool = MockTool()
        context = {"wallet_address": "0x1234", "network": "cronos"}
        executor = create_langchain_executor(tool, context)

        # Execute with only LLM-provided arguments
        result = executor({"input": "test"})

        # Context should be merged into the result
        assert "wallet_address=0x1234" in result
        assert "network=cronos" in result
        assert isinstance(result, str)

    def test_executor_context_override(self):
        """Test that executor arguments can override context."""
        tool = MockTool()
        context = {"count": 10}
        executor = create_langchain_executor(tool, context)

        # Override the context value
        result = executor({"input": "test", "count": 20})

        # Should use the argument value, not context value
        assert result == "MockResult(success=True, value='test_20')"

    def test_executor_empty_args(self):
        """Test executor with no arguments."""

        class NoArgTool:
            name = "no_arg_tool"
            description = "Tool that needs no args"
            parameters_schema = {}

            def execute(self, **kwargs: Any) -> Dict[str, Any]:
                return {"status": "executed", "kwargs": kwargs}

        tool = NoArgTool()
        context = {"session_id": "abc123"}
        executor = create_langchain_executor(tool, context)

        # Execute with no arguments
        result = executor({})

        # Should still include context
        assert "session_id" in result
        assert isinstance(result, str)

    def test_executor_returns_string(self):
        """Test that executor always returns string."""

        class VariousReturnTool:
            name = "various_return"
            description = "Returns different types"
            parameters_schema = {}

            def execute(self, return_type: str = "dict", **kwargs: Any) -> Any:
                if return_type == "dict":
                    return {"key": "value"}
                elif return_type == "list":
                    return [1, 2, 3]
                elif return_type == "number":
                    return 42
                elif return_type == "bool":
                    return True
                elif return_type == "none":
                    return None
                else:
                    return "string"

        tool = VariousReturnTool()
        executor = create_langchain_executor(tool)

        # Test various return types
        assert executor({"return_type": "dict"}) == "{'key': 'value'}"
        assert executor({"return_type": "list"}) == "[1, 2, 3]"
        assert executor({"return_type": "number"}) == "42"
        assert executor({"return_type": "bool"}) == "True"
        assert executor({"return_type": "none"}) == "None"
        assert executor({"return_type": "string"}) == "string"

        # All results should be strings
        for return_type in ["dict", "list", "number", "bool", "none", "string"]:
            result = executor({"return_type": return_type})
            assert isinstance(result, str)
