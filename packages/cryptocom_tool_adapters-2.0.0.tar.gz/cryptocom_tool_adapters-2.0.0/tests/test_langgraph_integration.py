"""Integration tests for LangGraph adapter with actual tools."""

import json
from typing import Any, Dict, Optional, cast
from unittest.mock import Mock

import pytest

from cryptocom_tool_adapters.langgraph import (
    create_langgraph_executor,
    to_langgraph_tool,
    with_injected_state,
)


def test_langgraph_adapter_with_balance_tool():
    """Test LangGraph adapter with a balance tool example."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    # Create a mock balance tool following the actual BalanceTool interface
    class MockBalanceTool:
        name = "get_native_balance"
        description = "Get native token balance for an address"
        parameters_schema: Dict[str, Any] = {
            "type": "object",
            "properties": {
                "address": {"type": "string", "description": "The blockchain address to query"},
                "use_wei": {
                    "type": "boolean",
                    "description": "Return balance in wei units",
                    "default": False,
                },
                "decimal_places": {
                    "type": "integer",
                    "description": "Number of decimal places for formatting",
                    "default": 6,
                },
            },
            "required": ["address"],
        }

        def __init__(self, cdp_client: Any):
            self.cdp_client = cdp_client

        def execute(
            self,
            address: str,
            use_wei: bool = False,
            decimal_places: Optional[int] = 6,
            **kwargs: Any,
        ) -> str:
            """Execute the balance query."""
            # Mock implementation
            balance = 1234.567890
            # Handle None values for optional params
            if decimal_places is None:
                decimal_places = 6
            if use_wei:
                return f"{int(balance * 10**18)} wei"
            return f"{balance:.{decimal_places}f} CRO"

    # Create mock CDP client
    mock_cdp_client = Mock()

    # Create tool instance
    balance_tool = MockBalanceTool(cdp_client=mock_cdp_client)

    # No state extraction needed for this tool
    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """No state extraction for balance tool."""
        return {}

    # Convert to LangGraph tool
    lg_tool = to_langgraph_tool(balance_tool, state_extractor)

    # Verify properties
    assert lg_tool.name == "get_native_balance"
    assert lg_tool.description == "Get native token balance for an address"

    # Check args_schema
    args_schema = lg_tool.args_schema
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))

    assert "address" in schema_fields
    assert "use_wei" in schema_fields
    assert "decimal_places" in schema_fields
    assert "state" in schema_fields  # InjectedState is always present

    # Test invocation
    state = {}
    result = lg_tool.invoke({"address": "0x123", "use_wei": False, "state": state})
    assert "1234.567890 CRO" in result


def test_langgraph_adapter_with_stateful_tool():
    """Test LangGraph adapter with a tool that needs state injection."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    # Create a mock transfer tool following the state injection pattern
    class MockTransferTool:
        name = "transfer_native_token"
        description = "Transfer native tokens using injected state"
        parameters_schema: Dict[str, Any] = {
            "type": "object",
            "properties": {
                "wallet_address": {"type": "string", "description": "Source wallet address"},
                "to": {"type": "string", "description": "Recipient address"},
                "amount": {"type": "number", "description": "Amount to transfer"},
            },
            "required": ["wallet_address", "to", "amount"],
        }

        def __init__(self, sso_client: Any):
            self.sso_client = sso_client

        def execute(
            self, wallet_address: str, to: str, amount: float, **kwargs: Any
        ) -> Dict[str, str]:
            """Execute the transfer."""
            # Mock implementation
            return {
                "tx_hash": "0xabc123",
                "tx_link": "https://cronos.org/tx/0xabc123",
                "from": wallet_address,
                "to": to,
                "amount": str(amount),
            }

    # Create mock SSO client
    mock_sso_client = Mock()

    # Create tool instance
    transfer_tool = MockTransferTool(sso_client=mock_sso_client)

    # State extractor that pulls wallet from state
    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract active wallet from state."""
        wallets = state.get("wallets", {})
        active = wallets.get("active", "")
        return {"wallet_address": active}

    # Convert to LangGraph tool with state injection
    lg_tool = to_langgraph_tool(
        transfer_tool,
        state_extractor,
        injected_param_names=["wallet_address"],
    )

    # Check that wallet_address is NOT in the LLM-visible schema
    args_schema = lg_tool.args_schema
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))

    assert "wallet_address" not in schema_fields  # Injected from state
    assert "to" in schema_fields
    assert "amount" in schema_fields
    assert "state" in schema_fields

    # Test invocation with state
    state = {"wallets": {"active": "0xUserWallet", "all": ["0xUserWallet", "0xOtherWallet"]}}

    result = lg_tool.invoke({"to": "0xRecipient", "amount": 10.5, "state": state})

    # Verify the result includes the injected wallet
    result_dict = json.loads(result.replace("'", '"'))
    assert result_dict["from"] == "0xUserWallet"
    assert result_dict["to"] == "0xRecipient"
    assert result_dict["amount"] == "10.5"


def test_with_injected_state_convenience_function():
    """Test the convenience function for simple state injection."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    # Create a mock DeFi tool
    class MockDeFiTool:
        name = "swap_tokens"
        description = "Swap tokens on a DEX"
        parameters_schema: Dict[str, Any] = {
            "type": "object",
            "properties": {
                "wallet_address": {"type": "string"},
                "network": {"type": "string"},
                "from_token": {"type": "string"},
                "to_token": {"type": "string"},
                "amount": {"type": "number"},
            },
            "required": ["wallet_address", "network", "from_token", "to_token", "amount"],
        }

        def execute(self, **kwargs: Any) -> str:
            return f"Swapped {kwargs['amount']} {kwargs['from_token']} to {kwargs['to_token']} on {kwargs['network']}"

    tool = MockDeFiTool()

    # Use convenience function to inject wallet and network from state
    lg_tool = with_injected_state(tool, ["wallet_address", "network"])

    # Check filtered schema
    args_schema = lg_tool.args_schema
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))

    # These should be filtered out (injected from state)
    assert "wallet_address" not in schema_fields
    assert "network" not in schema_fields

    # These should remain (provided by LLM)
    assert "from_token" in schema_fields
    assert "to_token" in schema_fields
    assert "amount" in schema_fields


def test_state_mapping_with_different_key_names():
    """Test state injection when state keys differ from parameter names."""
    pytest.importorskip("langchain_core")
    pytest.importorskip("langgraph")

    class MockToolLocal:
        name = "test_tool"
        description = "Test tool with mapping"
        parameters_schema: Dict[str, Any] = {
            "type": "object",
            "properties": {
                "wallet_address": {"type": "string"},
                "chain_id": {"type": "integer"},
                "action": {"type": "string"},
            },
            "required": ["wallet_address", "chain_id", "action"],
        }

        def execute(self, **kwargs: Any) -> str:
            return f"Executed on chain {kwargs['chain_id']} with wallet {kwargs['wallet_address']}"

    tool = MockToolLocal()

    # Map state keys to different parameter names
    lg_tool = with_injected_state(
        tool,
        ["active_wallet", "current_chain"],
        {"active_wallet": "wallet_address", "current_chain": "chain_id"},
    )

    # Check schema
    args_schema = lg_tool.args_schema
    assert args_schema is not None
    schema_fields = cast(Dict[str, Any], getattr(args_schema, "model_fields", {}))

    # Mapped params should be filtered
    assert "wallet_address" not in schema_fields
    assert "chain_id" not in schema_fields

    # Only action should remain
    assert "action" in schema_fields
    assert "state" in schema_fields


def test_executor_pattern_for_direct_invocation():
    """Test the executor pattern for tools that need direct invocation."""

    class MockToolLocal:
        name = "test_tool"
        description = "Test tool"
        parameters_schema: Dict[str, Any] = {
            "type": "object",
            "properties": {"wallet": {"type": "string"}, "action": {"type": "string"}},
            "required": ["wallet", "action"],
        }

        def execute(self, wallet: str, action: str, **kwargs: Any) -> str:
            network = kwargs.get("network", "unknown")
            return f"{action} on {wallet} (network: {network})"

    tool = MockToolLocal()

    state = {"wallet": "0x123", "network": "cronos-testnet"}

    def state_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        return {"wallet": state.get("wallet"), "network": state.get("network")}

    # Create executor
    executor = create_langgraph_executor(tool, state, state_extractor)

    # Execute with only LLM args (wallet from state)
    result = executor({"action": "stake"})

    assert result == "stake on 0x123 (network: cronos-testnet)"

    # Override wallet from args
    result = executor({"wallet": "0x456", "action": "unstake"})

    assert result == "unstake on 0x456 (network: cronos-testnet)"


def test_complex_nested_state_extraction():
    """Test extraction from deeply nested state structures."""

    class MockToolLocal:
        name = "complex_tool"
        description = "Tool with complex state"
        parameters_schema: Dict[str, Any] = {
            "type": "object",
            "properties": {
                "wallet": {"type": "string"},
                "gas_price": {"type": "number"},
                "slippage": {"type": "number"},
                "action": {"type": "string"},
            },
            "required": ["wallet", "gas_price", "slippage", "action"],
        }

        def execute(self, **kwargs: Any) -> Dict[str, Any]:
            return kwargs

    tool = MockToolLocal()

    # Complex nested state
    state = {
        "user": {
            "preferences": {
                "trading": {
                    "slippage_tolerance": 0.5,
                    "gas_settings": {"mode": "fast", "price_gwei": 25.5},
                }
            },
            "wallets": {"primary": "0xPrimary", "secondary": "0xSecondary"},
        },
        "network": {"chain_id": 25, "name": "cronos"},
    }

    def complex_extractor(state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract from nested state."""
        user = state.get("user", {})
        prefs = user.get("preferences", {})
        trading = prefs.get("trading", {})
        gas = trading.get("gas_settings", {})
        wallets = user.get("wallets", {})

        return {
            "wallet": wallets.get("primary"),
            "gas_price": gas.get("price_gwei", 20),
            "slippage": trading.get("slippage_tolerance", 1.0),
        }

    executor = create_langgraph_executor(tool, state, complex_extractor)

    result = executor({"action": "swap"})

    assert result["wallet"] == "0xPrimary"
    assert result["gas_price"] == 25.5
    assert result["slippage"] == 0.5
    assert result["action"] == "swap"
