"""Tests for Anthropic adapter."""

from cryptocom_tool_adapters.anthropic import create_anthropic_executor, to_anthropic_tool

from .test_utils import MockTool


def test_to_anthropic_tool_basic():
    """Test basic conversion to Anthropic tool format."""
    tool = MockTool()
    result = to_anthropic_tool(tool)

    assert result["name"] == "mock_tool"
    assert result.get("description") == "A mock tool for testing"
    assert result["input_schema"] == tool.parameters_schema


def test_to_anthropic_tool_with_context():
    """Test conversion with context."""
    tool = MockTool()
    context = {"wallet_address": "0x1234"}
    result = to_anthropic_tool(tool, context)

    assert result["name"] == "mock_tool"
    assert "wallet_address=0x1234" in result.get("description", "")


def test_create_anthropic_executor_basic():
    """Test executor creation and execution."""
    tool = MockTool()
    executor = create_anthropic_executor(tool)

    # Execute with Anthropic-style inputs
    result = executor({"input": "test", "count": 3})

    assert result.success is True
    assert result.value == "test_3"


def test_create_anthropic_executor_with_context():
    """Test executor with pre-bound context."""
    tool = MockTool()
    context = {"wallet_address": "0x1234", "network": "cronos"}
    executor = create_anthropic_executor(tool, context)

    # Execute with Anthropic-style inputs
    # Context should be merged with inputs
    result = executor({"input": "test"})

    assert result.success is True
    # The mock tool includes extra kwargs in the result
    assert "wallet_address=0x1234" in result.value
    assert "network=cronos" in result.value


def test_create_anthropic_executor_override_context():
    """Test that inputs can override context."""
    tool = MockTool()
    context = {"count": 5}
    executor = create_anthropic_executor(tool, context)

    # Inputs should override context
    result = executor({"input": "test", "count": 10})

    assert result.success is True
    assert result.value == "test_10"  # Uses 10 from inputs, not 5 from context
