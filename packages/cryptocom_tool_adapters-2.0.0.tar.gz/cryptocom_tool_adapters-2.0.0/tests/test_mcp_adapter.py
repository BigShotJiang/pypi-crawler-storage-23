"""Tests for MCP adapter."""

import json
from typing import Any

from cryptocom_tool_adapters.mcp import create_mcp_handler, to_mcp_tool

from .test_utils import MockResult, MockTool


def test_to_mcp_tool_basic():
    """Test basic conversion to MCP tool format."""
    tool = MockTool()
    result = to_mcp_tool(tool)

    assert result["name"] == "mock_tool"
    assert result["description"] == "A mock tool for testing"
    assert result["inputSchema"] == tool.parameters_schema

    # Verify inputSchema structure follows MCP spec
    assert result["inputSchema"]["type"] == "object"
    assert "properties" in result["inputSchema"]
    assert "required" in result["inputSchema"]


def test_to_mcp_tool_with_context():
    """Test conversion with context."""
    tool = MockTool()
    context = {"wallet_address": "0x1234"}
    result = to_mcp_tool(tool, context)

    assert result["name"] == "mock_tool"
    assert "wallet_address=0x1234" in result["description"]
    assert result["description"].startswith("A mock tool for testing")


def test_to_mcp_tool_with_multiple_context():
    """Test conversion with multiple context values."""
    tool = MockTool()
    context = {"wallet_address": "0x1234", "network": "cronos", "chain_id": 25}
    result = to_mcp_tool(tool, context)

    assert result["name"] == "mock_tool"
    # All context should be in description
    assert "wallet_address=0x1234" in result["description"]
    assert "network=cronos" in result["description"]
    assert "chain_id=25" in result["description"]


def test_to_mcp_tool_empty_context():
    """Test conversion with empty context."""
    tool = MockTool()
    result = to_mcp_tool(tool, {})

    assert result["name"] == "mock_tool"
    assert result["description"] == "A mock tool for testing"
    # Empty context should not modify description


def test_to_mcp_tool_none_context():
    """Test conversion with None context."""
    tool = MockTool()
    result = to_mcp_tool(tool, None)

    assert result["name"] == "mock_tool"
    assert result["description"] == "A mock tool for testing"


def test_create_mcp_handler_success():
    """Test handler creation and successful execution."""
    tool = MockTool()
    handler = create_mcp_handler(tool)

    # Execute with MCP-style arguments
    result = handler({"input": "test", "count": 3})

    assert result["success"] is True
    assert result["result"] == {"success": True, "value": "test_3"}


def test_create_mcp_handler_with_default_params():
    """Test handler with optional parameters using defaults."""
    tool = MockTool()
    handler = create_mcp_handler(tool)

    # Execute with only required argument (count has default)
    result = handler({"input": "test"})

    assert result["success"] is True
    assert result["result"] == {"success": True, "value": "test_1"}


def test_create_mcp_handler_with_context():
    """Test handler with pre-bound context."""
    tool = MockTool()
    context = {"wallet_address": "0x1234", "network": "cronos"}
    handler = create_mcp_handler(tool, context)

    # Execute with MCP-style arguments
    result = handler({"input": "test"})

    assert result["success"] is True
    # The result should contain the context values
    assert "wallet_address=0x1234" in result["result"]["value"]
    assert "network=cronos" in result["result"]["value"]


def test_create_mcp_handler_context_override():
    """Test that arguments can override context values."""
    tool = MockTool()
    context = {"input": "context_value", "network": "cronos"}
    handler = create_mcp_handler(tool, context)

    # Arguments should override context
    result = handler({"input": "argument_value"})

    assert result["success"] is True
    # Should use argument value, not context value
    assert "argument_value" in result["result"]["value"]
    assert "network=cronos" in result["result"]["value"]


def test_create_mcp_handler_error():
    """Test handler error handling."""
    tool = MockTool()
    handler = create_mcp_handler(tool)

    # Mock an error by not providing required argument
    # Since our mock tool has "input" as required, we'll patch it temporarily
    original_execute = tool.execute

    def failing_execute(**kwargs: Any) -> Any:
        raise ValueError("Test error")

    tool.execute = failing_execute  # type: ignore[assignment]

    result = handler({"input": "test"})

    assert result["success"] is False
    assert "Test error" in result["error"]

    # Restore original method
    tool.execute = original_execute


def test_create_mcp_handler_type_error():
    """Test handler handles TypeError from missing required arguments."""
    tool = MockTool()
    handler = create_mcp_handler(tool)

    # Don't provide required "input" argument
    # This will cause a TypeError in the execute method
    original_execute = tool.execute

    def strict_execute(input: str, count: int = 1, **kwargs: Any) -> MockResult:
        """Strict execute that requires input parameter."""
        if "input" not in locals():
            raise TypeError("missing required argument: 'input'")
        return original_execute(input, count, **kwargs)

    tool.execute = strict_execute  # type: ignore[assignment]

    result = handler({})  # Missing required "input"

    assert result["success"] is False
    assert "missing" in result["error"] and "input" in result["error"]

    # Restore original method
    tool.execute = original_execute


def test_create_mcp_handler_result_formatting():
    """Test that different result types are formatted correctly."""

    class CustomResult:
        """Custom result class with __dict__."""

        def __init__(self, value: str):
            self.value = value
            self.status = "complete"

    class StringResult:
        """Result that doesn't have __dict__ but has __str__."""

        def __str__(self) -> str:
            return "custom_string_result"

    tool = MockTool()

    # Test with object that has __dict__
    original_execute = tool.execute

    def return_custom_result(**kwargs: Any) -> Any:
        return CustomResult("test_value")

    tool.execute = return_custom_result  # type: ignore[assignment]
    handler = create_mcp_handler(tool)
    result = handler({"input": "test"})

    assert result["success"] is True
    assert result["result"] == {"value": "test_value", "status": "complete"}

    # Test with object that needs str() conversion
    def return_string_result(**kwargs: Any) -> Any:
        return StringResult()

    tool.execute = return_string_result  # type: ignore[assignment]
    handler = create_mcp_handler(tool)
    result = handler({"input": "test"})

    assert result["success"] is True
    assert result["result"] == "custom_string_result"

    # Test with primitive type
    def return_primitive(**kwargs: Any) -> Any:
        return 42

    tool.execute = return_primitive  # type: ignore[assignment]
    handler = create_mcp_handler(tool)
    result = handler({"input": "test"})

    assert result["success"] is True
    assert result["result"] == "42"

    # Restore original method
    tool.execute = original_execute


def test_mcp_tool_schema_validation():
    """Test that the MCP tool schema follows the MCP specification."""
    tool = MockTool()
    result = to_mcp_tool(tool)

    # MCP tools must have these fields
    assert "name" in result
    assert "description" in result
    assert "inputSchema" in result

    # inputSchema must be a valid JSON Schema
    schema = result["inputSchema"]
    assert isinstance(schema, dict)
    assert schema.get("type") == "object"

    # Validate it's serializable as JSON
    json_str = json.dumps(result)
    parsed = json.loads(json_str)
    assert parsed == result
