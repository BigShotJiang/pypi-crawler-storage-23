"""
Integration tests for balance tools with framework adapters.

Tests that GetNativeBalanceTool works correctly with OpenAI, Anthropic, and MCP adapters.
"""

from typing import Any, Dict, Iterator, List, cast
from unittest.mock import Mock, patch

import pytest
from cryptocom_tools_token import GetNativeBalanceTool

from cryptocom_tool_adapters.anthropic import create_anthropic_executor, to_anthropic_tool
from cryptocom_tool_adapters.mcp import create_mcp_handler, to_mcp_tool
from cryptocom_tool_adapters.openai import create_openai_executor, to_openai_function


@pytest.fixture
def mock_token() -> Iterator[Mock]:
    """Mock the Token class from CDP client."""
    with patch("crypto_com_developer_platform_client.Token") as mock:
        mock.get_native_balance.return_value = {
            "status": "Success",
            "data": {"balance": 1000000000000000000},  # 1 CRO
        }
        yield mock


@pytest.fixture
def native_balance_tool() -> GetNativeBalanceTool:
    """Create a GetNativeBalanceTool."""
    return GetNativeBalanceTool()


class TestOpenAIIntegration:
    """Test GetNativeBalanceTool with OpenAI SDK adapter."""

    def test_to_openai_function(self, native_balance_tool: GetNativeBalanceTool):
        """Test conversion to OpenAI function format."""
        function_def = to_openai_function(native_balance_tool)

        assert function_def["type"] == "function"
        assert function_def["function"]["name"] == "get_native_balance"
        description = function_def["function"].get("description", "")
        assert "native token balance" in description.lower()
        assert "parameters" in function_def["function"]

        # Check parameter schema
        params = cast(Dict[str, Any], function_def["function"]["parameters"])
        assert params["type"] == "object"
        assert "address" in params["properties"]
        assert "use_wei" in params["properties"]
        assert "decimal_places" in params["properties"]
        assert "address" in params["required"]

    def test_create_openai_executor(
        self, native_balance_tool: GetNativeBalanceTool, mock_token: Mock
    ):
        """Test executing tool via OpenAI executor."""
        # Create executor
        executor = create_openai_executor(native_balance_tool)

        # Execute with OpenAI-style arguments
        result = executor(
            {
                "address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7",
                "use_wei": False,
                "decimal_places": 2,
            }
        )

        # Verify execution
        assert "1" in str(result)
        assert "CRO" in str(result)
        mock_token.get_native_balance.assert_called_once()


class TestAnthropicIntegration:
    """Test GetNativeBalanceTool with Anthropic SDK adapter."""

    def test_to_anthropic_tool(self, native_balance_tool: GetNativeBalanceTool):
        """Test conversion to Anthropic tool format."""
        tool_def = to_anthropic_tool(native_balance_tool)

        assert tool_def["name"] == "get_native_balance"
        description = tool_def.get("description", "")
        assert description is not None
        assert "native token balance" in description.lower()
        assert "input_schema" in tool_def

        # Check input schema
        schema = cast(Dict[str, Any], tool_def["input_schema"])
        properties = cast(Dict[str, Any], schema.get("properties", {}))
        required = cast(List[str], schema.get("required", []))
        assert schema["type"] == "object"
        assert "address" in properties
        assert "use_wei" in properties
        assert "decimal_places" in properties
        assert "address" in required

    def test_create_anthropic_executor(
        self, native_balance_tool: GetNativeBalanceTool, mock_token: Mock
    ):
        """Test executing tool via Anthropic executor."""
        # Create executor
        executor = create_anthropic_executor(native_balance_tool)

        # Execute with Anthropic-style arguments
        result = executor(
            {
                "address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7",
                "use_wei": True,
            }
        )

        # Verify execution
        assert "1000000000000000000" in str(result)
        assert "WEI" in str(result)
        mock_token.get_native_balance.assert_called_once()

    def test_anthropic_executor_with_defaults(
        self, native_balance_tool: GetNativeBalanceTool, mock_token: Mock
    ):
        """Test Anthropic executor handles optional parameters."""
        executor = create_anthropic_executor(native_balance_tool)

        # Execute with minimal parameters (should use defaults)
        result = executor({"address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7"})

        # Default is use_wei=True
        assert "1000000000000000000" in str(result)
        assert "WEI" in str(result)


class TestMCPIntegration:
    """Test GetNativeBalanceTool with MCP adapter."""

    def test_to_mcp_tool(self, native_balance_tool: GetNativeBalanceTool):
        """Test conversion to MCP tool format."""
        tool_def = to_mcp_tool(native_balance_tool)

        assert tool_def["name"] == "get_native_balance"
        assert "native token balance" in tool_def["description"].lower()
        assert "inputSchema" in tool_def

        # Check input schema (note: MCP uses 'inputSchema' not 'input_schema')
        schema = tool_def["inputSchema"]
        assert schema["type"] == "object"
        assert "address" in schema["properties"]
        assert "use_wei" in schema["properties"]
        assert "decimal_places" in schema["properties"]
        assert "address" in schema["required"]

    def test_create_mcp_handler(self, native_balance_tool: GetNativeBalanceTool, mock_token: Mock):
        """Test executing tool via MCP handler."""
        # Create handler
        handler = create_mcp_handler(native_balance_tool)

        # Execute with MCP-style arguments
        result = handler(
            {
                "address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7",
                "use_wei": False,
                "decimal_places": 6,
            }
        )

        # Verify execution
        assert "1" in str(result)
        assert "CRO" in str(result)
        mock_token.get_native_balance.assert_called_once()

    def test_mcp_handler_error_handling(self, native_balance_tool: GetNativeBalanceTool):
        """Test MCP handler handles errors gracefully."""
        with patch("crypto_com_developer_platform_client.Token") as mock_token:
            mock_token.get_native_balance.return_value = {
                "status": "Error",
                "message": "Invalid address",
            }

            handler = create_mcp_handler(native_balance_tool)
            result = handler({"address": "invalid_address"})

            # Should handle error gracefully
            assert "Error" in str(result)


class TestMultiFrameworkCompatibility:
    """Test that the same tool works across all frameworks."""

    def test_tool_works_with_all_adapters(
        self, native_balance_tool: GetNativeBalanceTool, mock_token: Mock
    ):
        """Test that tool can be adapted to all frameworks."""
        address = "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7"

        # OpenAI
        openai_func = to_openai_function(native_balance_tool)
        openai_exec = create_openai_executor(native_balance_tool)
        openai_result = openai_exec({"address": address, "use_wei": False})

        # Anthropic
        anthropic_tool = to_anthropic_tool(native_balance_tool)
        anthropic_exec = create_anthropic_executor(native_balance_tool)
        anthropic_result = anthropic_exec({"address": address, "use_wei": False})

        # MCP
        mcp_tool = to_mcp_tool(native_balance_tool)
        mcp_handler = create_mcp_handler(native_balance_tool)
        mcp_result = mcp_handler({"address": address, "use_wei": False})

        # All should produce similar results
        assert "1" in str(openai_result)
        assert "1" in str(anthropic_result)
        assert "1" in str(mcp_result)

        assert "CRO" in str(openai_result)
        assert "CRO" in str(anthropic_result)
        assert "CRO" in str(mcp_result)

        # All should have valid schema definitions
        assert openai_func["function"]["name"] == "get_native_balance"
        assert anthropic_tool["name"] == "get_native_balance"
        assert mcp_tool["name"] == "get_native_balance"
