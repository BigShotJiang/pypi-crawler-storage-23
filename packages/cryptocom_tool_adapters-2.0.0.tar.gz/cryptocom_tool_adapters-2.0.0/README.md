# Cryptocom Tool Adapters

[![PyPI version](https://badge.fury.io/py/cryptocom-tool-adapters.svg)](https://pypi.org/project/cryptocom-tool-adapters/)
[![Python versions](https://img.shields.io/pypi/pyversions/cryptocom-tool-adapters.svg)](https://pypi.org/project/cryptocom-tool-adapters/)

Framework adapters for Crypto.com blockchain tools - convert framework-agnostic tools to LangGraph, OpenAI, Anthropic, and MCP formats.

## Installation

```bash
# Install with specific framework support
pip install cryptocom-tool-adapters[langgraph]    # For LangGraph
pip install cryptocom-tool-adapters[openai]       # For OpenAI SDK
pip install cryptocom-tool-adapters[anthropic]    # For Anthropic SDK
pip install cryptocom-tool-adapters[langchain]    # For LangChain (without LangGraph)

# Install with all framework support
pip install cryptocom-tool-adapters[all]
```

## Quick Start

### LangGraph Adapter

Convert tools to LangGraph format with state injection:

```python
from cryptocom_tool_adapters import to_langgraph_tool

# Example tool using the framework-agnostic protocol
class TransferTool:
    name = "transfer_native_token"
    description = "Transfer native tokens to an address"
    parameters_schema = {
        "type": "object",
        "properties": {
            "wallet_address": {"type": "string"},
            "to": {"type": "string"},
            "amount": {"type": "number"},
        },
        "required": ["wallet_address", "to", "amount"],
    }

    def execute(self, **kwargs):
        return kwargs

transfer_tool = TransferTool()

# Define how to extract context from LangGraph state
def extract_wallet_from_state(state: dict) -> dict:
    wallets = state.get("wallets", {})
    active = wallets.get("active", "")
    return {"wallet_address": active}

# Convert to LangGraph tool (wallet_address injected from state)
transfer_lg = to_langgraph_tool(
    transfer_tool,
    extract_wallet_from_state,
    injected_param_names=["wallet_address"],
)

# Use in LangGraph agent
from langgraph.prebuilt import create_react_agent
agent = create_react_agent(llm, tools=[transfer_lg])
```

### OpenAI SDK Adapter

Convert tools to OpenAI function calling format:

```python
import json
import os

from cryptocom_tools_token import GetNativeBalanceTool
from cryptocom_tool_adapters import to_openai_function, create_openai_executor
from openai import OpenAI

# Initialize tool and client
balance_tool = GetNativeBalanceTool(api_key=os.getenv("CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY"))
client = OpenAI()

# Convert to OpenAI function format
tool_schema = to_openai_function(balance_tool)

# Use in OpenAI API call
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Check balance of 0x123..."}],
    tools=[tool_schema],
    tool_choice="auto"
)

# Execute tool calls
executor = create_openai_executor(balance_tool)
for tool_call in response.choices[0].message.tool_calls:
    if tool_call.function.name == balance_tool.name:
        args = json.loads(tool_call.function.arguments)
        result = executor(args)
```

### Anthropic SDK Adapter

Convert tools to Anthropic tool format:

```python
from cryptocom_tools_wallet import CreateWalletTool
from cryptocom_tool_adapters import to_anthropic_tool, create_anthropic_executor
from anthropic import Anthropic

# Initialize tool and client
wallet_tool = CreateWalletTool(wallet_state)
client = Anthropic()

# Convert to Anthropic tool format
tool_schema = to_anthropic_tool(wallet_tool)

# Use in Anthropic API call
response = client.messages.create(
    model="claude-3-opus-20240229",
    messages=[{"role": "user", "content": "Create a new wallet"}],
    tools=[tool_schema],
    max_tokens=1024
)

# Execute tool calls
executor = create_anthropic_executor(wallet_tool)
for content in response.content:
    if content.type == "tool_use":
        result = executor(content.input)
```

### LangChain Adapter (without LangGraph)

Pre-bind context for simple LangChain usage:

```python
from cryptocom_tool_adapters import to_langchain_tool

transfer_tool = TransferTool()

# Pre-bind context (wallet address)
context = {"wallet_address": "0x1234..."}
transfer_lc = to_langchain_tool(transfer_tool, context)

# Use in LangChain agent
from langchain.agents import create_tool_calling_agent
agent = create_tool_calling_agent(llm, [swap_lc], prompt)
```

### MCP Adapter

Convert tools to Model Context Protocol format:

```python
import os

from cryptocom_tools_explorer import GetTransactionByHashTool
from cryptocom_tool_adapters import to_mcp_tool, create_mcp_handler

# Initialize tool
tx_tool = GetTransactionByHashTool(api_key=os.getenv("CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY"))

# Convert to MCP format
tool_def = to_mcp_tool(tx_tool)

# Create handler for execution
handler = create_mcp_handler(tx_tool)

# Process MCP requests
request = {"arguments": {"hash": "0xabc..."}}
response = handler(request["arguments"])
# Returns: {"success": true, "result": {...}}
```

## Features

- **Framework-agnostic core**: Tools have no framework dependencies
- **Multiple adapters**: Support for LangGraph, LangChain, OpenAI, Anthropic, and MCP
- **Type-safe**: Full type hints with Protocol definitions
- **Context injection**: Flexible state/context management for each framework
- **Minimal dependencies**: Only import what you need with optional dependencies

## Adapter Reference

### LangGraph Functions

- `to_langgraph_tool(tool, state_extractor)`: Convert with custom state extraction
- `with_injected_state(tool, state_keys, mapping)`: Simple state key injection

### OpenAI Functions

- `to_openai_function(tool, context)`: Convert to OpenAI function schema
- `create_openai_executor(tool, context)`: Create executor for tool calls

### Anthropic Functions

- `to_anthropic_tool(tool, context)`: Convert to Anthropic tool schema
- `create_anthropic_executor(tool, context)`: Create executor for tool use

### LangChain Functions

- `to_langchain_tool(tool, context)`: Convert to StructuredTool with pre-bound context

### MCP Functions

- `to_mcp_tool(tool, context)`: Convert to MCP tool definition
- `create_mcp_handler(tool, context)`: Create MCP request handler

## Development

```bash
# Clone the repository
git clone https://github.com/crypto-com/agent-client-py.git
cd agent-client-py/cryptocom-tool-adapters

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Run type checking
basedpyright

# Run linting
ruff check src/
```

## License

MIT
