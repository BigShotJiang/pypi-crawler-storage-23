"""
Cryptocom Tool Adapters - Framework adapters for blockchain tools.

This package provides adapters to convert framework-agnostic cryptocurrency tools
into framework-specific formats for LangGraph, LangChain, OpenAI, Anthropic, and MCP.
"""

__version__ = "0.1.0"

# Import adapters conditionally based on installed packages
__all__ = ["__version__"]

# Try importing LangGraph adapter
try:
    from .langgraph import (  # noqa: F401
        create_langgraph_executor,
        to_langgraph_tool,
        with_injected_state,
    )

    __all__.extend(["to_langgraph_tool", "with_injected_state", "create_langgraph_executor"])
except ImportError:
    pass

# Try importing LangChain adapter
try:
    from .langchain import to_langchain_tool  # noqa: F401

    __all__.append("to_langchain_tool")
except ImportError:
    pass

# Try importing OpenAI adapter
try:
    from .openai import create_openai_executor, to_openai_function  # noqa: F401

    __all__.extend(["to_openai_function", "create_openai_executor"])
except ImportError:
    pass

# Try importing Anthropic adapter
try:
    from .anthropic import create_anthropic_executor, to_anthropic_tool  # noqa: F401

    __all__.extend(["to_anthropic_tool", "create_anthropic_executor"])
except ImportError:
    pass

# Try importing MCP adapter
try:
    from .mcp import create_mcp_handler, to_mcp_tool  # noqa: F401

    __all__.extend(["to_mcp_tool", "create_mcp_handler"])
except ImportError:
    pass
