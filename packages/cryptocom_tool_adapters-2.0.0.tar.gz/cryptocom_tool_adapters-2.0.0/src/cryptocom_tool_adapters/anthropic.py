"""Anthropic SDK adapter for cryptocurrency tools.

Supports both:
- LangChain BaseTool (recommended for SDK tools)
- Custom tools with name/description/parameters_schema/execute() protocol
"""

from typing import TYPE_CHECKING, Any, Callable, Dict, Optional, Protocol, Union, cast

if TYPE_CHECKING:
    from anthropic.types import ToolParam
    from langchain_core.tools import BaseTool as LangChainBaseTool


# Protocol for custom tool instances (backwards compatibility)
class BaseCryptoTool(Protocol):
    """Protocol for cryptocurrency tools."""

    name: str
    description: str

    @property
    def parameters_schema(self) -> Dict[str, Any]:
        """Return JSON schema for parameters."""
        ...

    def execute(self, **kwargs: Any) -> Any:
        """Execute the tool."""
        ...


def _is_langchain_basetool(tool: Any) -> bool:
    """Check if tool is a LangChain BaseTool instance."""
    try:
        from langchain_core.tools import BaseTool

        return isinstance(tool, BaseTool)
    except ImportError:
        return False


def _get_tool_schema(tool: Any) -> Dict[str, Any]:
    """Extract JSON schema from tool (LangChain or custom protocol)."""
    if _is_langchain_basetool(tool):
        # LangChain BaseTool: use args_schema.model_json_schema()
        if hasattr(tool, "args_schema") and tool.args_schema is not None:
            return tool.args_schema.model_json_schema()
        return {"type": "object", "properties": {}}
    else:
        # Custom protocol: use parameters_schema property
        return tool.parameters_schema


def to_anthropic_tool(
    tool_instance: Union["LangChainBaseTool", BaseCryptoTool],
    context: Optional[Dict[str, Any]] = None,
) -> "ToolParam":
    """
    Convert tool to Anthropic tool format.

    Supports both LangChain BaseTool and custom protocol tools.

    Args:
        tool_instance: LangChain BaseTool or custom tool with protocol
        context: Pre-bound context (e.g., {"wallet_address": "0x..."})

    Returns:
        Anthropic tool schema (ToolParam)

    Example with LangChain BaseTool:
        >>> from langchain_core.tools import BaseTool
        >>> from pydantic import BaseModel, Field
        >>>
        >>> class GetBalanceInput(BaseModel):
        ...     address: str = Field(description="Wallet address")
        >>>
        >>> class GetBalanceTool(BaseTool):
        ...     name: str = "get_balance"
        ...     description: str = "Get wallet balance"
        ...     args_schema: type[BaseModel] = GetBalanceInput
        ...
        ...     def _run(self, address: str) -> str:
        ...         return f"Balance: 100 CRO"
        >>>
        >>> tool = GetBalanceTool()
        >>> anthropic_tool = to_anthropic_tool(tool)
        >>> # Use with Anthropic SDK
        >>> response = client.messages.create(
        ...     model="claude-3-5-sonnet-20241022",
        ...     tools=[anthropic_tool],
        ... )
    """
    tool_def: Dict[str, Any] = {
        "name": tool_instance.name,
        "description": tool_instance.description,
        "input_schema": _get_tool_schema(tool_instance),
    }

    # If context is provided, note it in the description
    if context:
        context_str = ", ".join(f"{k}={v}" for k, v in context.items())
        tool_def["description"] += f" (Context: {context_str})"

    return cast("ToolParam", tool_def)


def create_anthropic_executor(
    tool_instance: Union["LangChainBaseTool", BaseCryptoTool],
    context: Optional[Dict[str, Any]] = None,
) -> Callable[[Dict[str, Any]], Any]:
    """
    Create executor function for Anthropic tool calls.

    Supports both LangChain BaseTool and custom protocol tools.

    Args:
        tool_instance: LangChain BaseTool or custom tool with protocol
        context: Pre-bound context values

    Returns:
        Executor function that can be called with Anthropic tool use inputs

    Example with LangChain BaseTool:
        >>> from langchain_core.tools import BaseTool
        >>>
        >>> class GetBalanceTool(BaseTool):
        ...     name: str = "get_balance"
        ...     description: str = "Get balance"
        ...     def _run(self, address: str) -> str:
        ...         return "100 CRO"
        >>>
        >>> tool = GetBalanceTool()
        >>> executor = create_anthropic_executor(tool)
        >>>
        >>> # Process Anthropic response
        >>> for content in response.content:
        ...     if content.type == "tool_use":
        ...         result = executor(content.input)
    """
    context = context or {}
    is_langchain = _is_langchain_basetool(tool_instance)
    # Cast to Any to avoid type narrowing issues in closure
    tool: Any = tool_instance

    def executor(inputs: Dict[str, Any]) -> Any:
        """Execute tool with merged context and inputs."""
        all_args = {**context, **inputs}
        if is_langchain:
            # LangChain BaseTool: use invoke() method
            return tool.invoke(all_args)
        else:
            # Custom protocol: use execute() method
            return tool.execute(**all_args)

    return executor
