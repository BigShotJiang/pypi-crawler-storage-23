"""LangGraph adapter for cryptocurrency tools."""

from typing import TYPE_CHECKING, Annotated, Any, Callable, Dict, List, Optional, Protocol, Type

if TYPE_CHECKING:
    from langchain_core.tools import BaseTool as LangChainTool


class BaseTool(Protocol):
    """Protocol for framework-agnostic tools."""

    name: str
    description: str

    @property
    def parameters_schema(self) -> Dict[str, Any]:
        """JSON Schema for tool parameters."""
        ...

    def execute(self, **kwargs: Any) -> Any:
        """Execute the tool."""
        ...


def to_langgraph_tool(
    tool_instance: BaseTool,
    state_extractor: Callable[[Dict[str, Any]], Dict[str, Any]],
    injected_param_names: Optional[List[str]] = None,
) -> "LangChainTool":
    """
    Convert framework-agnostic tool to LangGraph tool with InjectedState.

    Args:
        tool_instance: The core tool (e.g., TransferTool)
        state_extractor: Function to extract params from LangGraph state
        injected_param_names: Optional list of parameter names supplied by state. These
            fields are excluded from the LLM-visible args schema.

    Returns:
        LangChain-compatible tool with InjectedState

    Example:
        >>> class TransferTool:
        ...     name = "transfer_native_token"
        ...     description = "Transfer native tokens to an address"
        ...     @property
        ...     def parameters_schema(self) -> dict:
        ...         return {
        ...             "type": "object",
        ...             "properties": {
        ...                 "wallet_address": {"type": "string"},
        ...                 "to": {"type": "string"},
        ...                 "amount": {"type": "number"},
        ...             },
        ...             "required": ["wallet_address", "to", "amount"],
        ...         }
        ...     def execute(self, **kwargs):
        ...         return kwargs
        >>>
        >>> from cryptocom_tool_adapters import to_langgraph_tool
        >>> def extract_wallet_from_state(state: dict) -> dict:
        ...     wallets = state.get("wallets", {})
        ...     active = wallets.get("active", "")
        ...     return {"wallet_address": active}
        >>>
        >>> transfer_tool = TransferTool()
        >>> transfer_lg = to_langgraph_tool(
        ...     transfer_tool,
        ...     extract_wallet_from_state,
        ...     injected_param_names=["wallet_address"],
        ... )
    """
    try:
        from langchain_core.tools import StructuredTool
        from langgraph.prebuilt import InjectedState
        from pydantic import BaseModel, Field, create_model
    except ImportError as e:
        raise ImportError(
            "LangGraph dependencies not installed. Install with: "
            "pip install langchain-core langgraph pydantic"
        ) from e

    # Extract parameter names from schema to build the signature
    # This ensures the wrapped function accepts the right parameters
    param_props = tool_instance.parameters_schema.get("properties", {})
    required_params = tool_instance.parameters_schema.get("required", [])

    # Build args_schema to match the tool's parameter schema.
    # Injected params can be excluded when names are explicitly provided.
    def build_pydantic_model() -> Type[BaseModel]:
        """Build Pydantic model for the tool."""
        injected_keys = set(injected_param_names or [])

        # Build model fields without injected keys
        model_fields = {}
        for prop_name, prop_schema in param_props.items():
            if prop_name not in injected_keys:
                # Convert JSON schema to Pydantic field
                field_type = str  # Default to str
                if prop_schema.get("type") == "integer":
                    field_type = int
                elif prop_schema.get("type") == "number":
                    field_type = float
                elif prop_schema.get("type") == "boolean":
                    field_type = bool

                # Check if required
                if prop_name in required_params:
                    model_fields[prop_name] = (
                        field_type,
                        Field(description=prop_schema.get("description", "")),
                    )
                else:
                    model_fields[prop_name] = (
                        Optional[field_type],
                        Field(default=None, description=prop_schema.get("description", "")),
                    )

        # Add the InjectedState field
        model_fields["state"] = (
            Annotated[Dict[str, Any], InjectedState],
            Field(default_factory=dict),
        )

        # Create dynamic Pydantic model
        return create_model(
            f"{tool_instance.name}_Schema", __doc__=tool_instance.description, **model_fields
        )

    # Create dynamic function signature based on tool schema
    def wrapped(state: Dict[str, Any], **kwargs: Any) -> str:
        """Execute tool with injected state."""
        # Extract required params from LangGraph state
        extracted = state_extractor(state)

        # Merge with LLM-provided args (args override state)
        all_args = {**extracted, **kwargs}

        # Execute core tool
        result = tool_instance.execute(**all_args)
        return str(result)

    # Create StructuredTool with Pydantic model
    return StructuredTool.from_function(
        func=wrapped,
        name=tool_instance.name,
        description=tool_instance.description,
        args_schema=build_pydantic_model(),
    )


def with_injected_state(
    tool_instance: BaseTool,
    state_keys: List[str],
    state_mapping: Optional[Dict[str, str]] = None,
) -> "LangChainTool":
    """
    Convenience function to inject specific state keys into tool parameters.

    Args:
        tool_instance: The core tool
        state_keys: Keys to extract from state
        state_mapping: Optional mapping from state key to param name

    Returns:
        LangChain-compatible tool with InjectedState

    Example:
        >>> transfer_tool = TransferNativeTool(sso_client=my_client)
        >>> # Simple extraction - state["wallet_address"] -> wallet_address param
        >>> transfer_lg = with_injected_state(transfer_tool, ["wallet_address"])
        >>>
        >>> # With mapping - state["active_wallet"] -> wallet_address param
        >>> transfer_lg = with_injected_state(
        ...     transfer_tool,
        ...     ["active_wallet"],
        ...     {"active_wallet": "wallet_address"}
        ... )
    """
    try:
        from langchain_core.tools import StructuredTool
        from langgraph.prebuilt import InjectedState
        from pydantic import BaseModel, Field, create_model
    except ImportError as e:
        raise ImportError(
            "LangGraph dependencies not installed. Install with: "
            "pip install langchain-core langgraph pydantic"
        ) from e

    mapping = state_mapping or {}

    # Extract parameter names from schema
    param_props = tool_instance.parameters_schema.get("properties", {})
    required_params = tool_instance.parameters_schema.get("required", [])

    # Build Pydantic model excluding injected params
    def build_pydantic_model() -> Type[BaseModel]:
        """Build Pydantic model for the tool, excluding injected state params."""
        # Get the parameter names that will be injected
        injected_param_names = set()
        for key in state_keys:
            param_name = mapping.get(key, key)
            injected_param_names.add(param_name)

        # Build model fields without injected keys
        model_fields = {}
        for prop_name, prop_schema in param_props.items():
            if prop_name not in injected_param_names:
                # Convert JSON schema to Pydantic field
                field_type = str  # Default to str
                if prop_schema.get("type") == "integer":
                    field_type = int
                elif prop_schema.get("type") == "number":
                    field_type = float
                elif prop_schema.get("type") == "boolean":
                    field_type = bool

                # Check if required
                if prop_name in required_params:
                    model_fields[prop_name] = (
                        field_type,
                        Field(description=prop_schema.get("description", "")),
                    )
                else:
                    model_fields[prop_name] = (
                        Optional[field_type],
                        Field(default=None, description=prop_schema.get("description", "")),
                    )

        # Add the InjectedState field
        model_fields["state"] = (
            Annotated[Dict[str, Any], InjectedState],
            Field(default_factory=dict),
        )

        # Create dynamic Pydantic model
        return create_model(
            f"{tool_instance.name}_Schema", __doc__=tool_instance.description, **model_fields
        )

    def wrapped(state: Dict[str, Any], **kwargs: Any) -> str:
        """Execute tool with injected state."""
        # Extract specified keys from state
        extracted = {}
        for key in state_keys:
            if key in state:
                param_name = mapping.get(key, key)
                extracted[param_name] = state[key]

        # Merge with LLM-provided args (args override state)
        all_args = {**extracted, **kwargs}

        # Execute core tool
        result = tool_instance.execute(**all_args)
        return str(result)

    # Create StructuredTool with Pydantic model
    return StructuredTool.from_function(
        func=wrapped,
        name=tool_instance.name,
        description=tool_instance.description,
        args_schema=build_pydantic_model(),
    )


def create_langgraph_executor(
    tool_instance: BaseTool,
    state: Dict[str, Any],
    state_extractor: Callable[[Dict[str, Any]], Dict[str, Any]],
) -> Callable[[Dict[str, Any]], Any]:
    """
    Create an executor function for a LangGraph tool with state.

    Args:
        tool_instance: The core tool
        state: The LangGraph state
        state_extractor: Function to extract params from state

    Returns:
        Executor function that can be called with tool arguments

    Example:
        >>> tool = TransferTool(sso_client=client)
        >>> state = {"wallets": {"active": "0x123"}}
        >>> executor = create_langgraph_executor(tool, state, extract_wallet)
        >>> result = executor({"to": "0xabc", "amount": 1.0})
    """

    def executor(args: Dict[str, Any]) -> Any:
        """Execute the tool with merged state and arguments."""
        # Extract required params from state
        extracted = state_extractor(state)

        # Merge with provided args (args override state)
        all_args = {**extracted, **args}

        # Execute tool
        return tool_instance.execute(**all_args)

    return executor
