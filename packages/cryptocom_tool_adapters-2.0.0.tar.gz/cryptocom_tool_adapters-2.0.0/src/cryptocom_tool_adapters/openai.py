"""OpenAI SDK adapter for cryptocurrency tools.

Supports both:
- LangChain BaseTool (recommended for SDK tools)
- Custom tools with name/description/parameters_schema/execute() protocol
"""

from typing import TYPE_CHECKING, Any, Callable, Dict, Optional, Protocol, Union, cast

if TYPE_CHECKING:
    from langchain_core.tools import BaseTool as LangChainBaseTool
    from openai.types.chat import ChatCompletionToolParam


# Protocol for custom tool instances (backwards compatibility)
class BaseCryptoTool(Protocol):
    """Protocol for cryptocurrency tools."""

    name: str
    description: str
    parameters_schema: Dict[str, Any]

    def execute(self, **kwargs: Any) -> Any:
        """Execute the tool."""
        ...


def _is_langchain_basetool(tool: Any) -> bool:
    """Check if tool is a LangChain BaseTool instance."""
    try:
        from langchain_core.tools import BaseTool

        return isinstance(tool, BaseTool)
    except ImportError:
        return False


def _get_tool_schema(tool: Any) -> Dict[str, Any]:
    """Extract JSON schema from tool (LangChain or custom protocol)."""
    if _is_langchain_basetool(tool):
        # LangChain BaseTool: use args_schema.model_json_schema()
        if hasattr(tool, "args_schema") and tool.args_schema is not None:
            return tool.args_schema.model_json_schema()
        return {"type": "object", "properties": {}}
    else:
        # Custom protocol: use parameters_schema property
        return tool.parameters_schema


def to_openai_function(
    tool_instance: Union["LangChainBaseTool", BaseCryptoTool],
    context: Optional[Dict[str, Any]] = None,
) -> "ChatCompletionToolParam":
    """
    Convert tool to OpenAI function calling format.

    Supports both LangChain BaseTool and custom protocol tools.

    Args:
        tool_instance: LangChain BaseTool or custom tool with protocol
        context: Pre-bound context (e.g., {"wallet_address": "0x..."})

    Returns:
        OpenAI function schema

    Example with LangChain BaseTool:
        >>> from langchain_core.tools import BaseTool
        >>> from pydantic import BaseModel, Field
        >>>
        >>> class GetBalanceInput(BaseModel):
        ...     address: str = Field(description="Wallet address")
        >>>
        >>> class GetBalanceTool(BaseTool):
        ...     name: str = "get_balance"
        ...     description: str = "Get wallet balance"
        ...     args_schema: type[BaseModel] = GetBalanceInput
        ...
        ...     def _run(self, address: str) -> str:
        ...         return f"Balance: 100 CRO"
        >>>
        >>> tool = GetBalanceTool()
        >>> openai_tool = to_openai_function(tool)
        >>> # Use with OpenAI SDK
        >>> response = client.chat.completions.create(
        ...     model="gpt-4",
        ...     tools=[openai_tool],
        ... )
    """
    function_def: Dict[str, Any] = {
        "name": tool_instance.name,
        "description": tool_instance.description,
        "parameters": _get_tool_schema(tool_instance),
    }

    # If context is provided, note it in the description
    if context:
        context_str = ", ".join(f"{k}={v}" for k, v in context.items())
        function_def["description"] += f" (Context: {context_str})"

    return cast(
        "ChatCompletionToolParam",
        {
            "type": "function",
            "function": function_def,
        },
    )


def create_openai_executor(
    tool_instance: Union["LangChainBaseTool", BaseCryptoTool],
    context: Optional[Dict[str, Any]] = None,
) -> Callable[[Dict[str, Any]], Any]:
    """
    Create executor function for OpenAI tool calls.

    Supports both LangChain BaseTool and custom protocol tools.

    Args:
        tool_instance: LangChain BaseTool or custom tool with protocol
        context: Pre-bound context values

    Returns:
        Executor function that can be called with OpenAI tool call arguments

    Example with LangChain BaseTool:
        >>> from langchain_core.tools import BaseTool
        >>> import json
        >>>
        >>> class GetBalanceTool(BaseTool):
        ...     name: str = "get_balance"
        ...     description: str = "Get balance"
        ...     def _run(self, address: str) -> str:
        ...         return "100 CRO"
        >>>
        >>> tool = GetBalanceTool()
        >>> executor = create_openai_executor(tool)
        >>>
        >>> # Process OpenAI response
        >>> tool_call = response.choices[0].message.tool_calls[0]
        >>> args = json.loads(tool_call.function.arguments)
        >>> result = executor(args)
    """
    context = context or {}
    is_langchain = _is_langchain_basetool(tool_instance)
    # Cast to Any to avoid type narrowing issues in closure
    tool: Any = tool_instance

    def executor(args: Dict[str, Any]) -> Any:
        """Execute tool with merged context and arguments."""
        all_args = {**context, **args}
        if is_langchain:
            # LangChain BaseTool: use invoke() method
            return tool.invoke(all_args)
        else:
            # Custom protocol: use execute() method
            return tool.execute(**all_args)

    return executor
