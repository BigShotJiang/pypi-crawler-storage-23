"""LangChain adapter for cryptocurrency tools."""

from typing import TYPE_CHECKING, Any, Callable, Dict, Optional, Protocol

if TYPE_CHECKING:
    from langchain_core.tools import StructuredTool


# Protocol for tool instances
class BaseCryptoTool(Protocol):
    """Protocol for cryptocurrency tools."""

    name: str
    description: str
    parameters_schema: Dict[str, Any]

    def execute(self, **kwargs: Any) -> Any:
        """Execute the tool."""
        ...


def to_langchain_tool(
    tool_instance: BaseCryptoTool,
    context: Optional[Dict[str, Any]] = None,
) -> "StructuredTool":
    """
    Convert to LangChain StructuredTool (no state injection).

    Context is pre-bound - useful for simple LangChain usage without LangGraph.

    Args:
        tool_instance: The core tool (e.g., TransferTool)
        context: Pre-bound context values (e.g., {"wallet_address": "0x..."})

    Returns:
        LangChain StructuredTool

    Example:
        >>> class TransferTool:
        ...     name = "transfer_native_token"
        ...     description = "Transfer native tokens to an address"
        ...     parameters_schema = {
        ...         "type": "object",
        ...         "properties": {
        ...             "wallet_address": {"type": "string"},
        ...             "to": {"type": "string"},
        ...             "amount": {"type": "number"},
        ...         },
        ...         "required": ["wallet_address", "to", "amount"],
        ...     }
        ...     def execute(self, **kwargs):
        ...         return kwargs
        >>>
        >>> from cryptocom_tool_adapters import to_langchain_tool
        >>> transfer_tool = TransferTool()
        >>> context = {"wallet_address": "0x1234..."}
        >>> transfer_lc = to_langchain_tool(transfer_tool, context)
        >>>
        >>> from langchain.agents import create_tool_calling_agent
        >>> agent = create_tool_calling_agent(llm, [transfer_lc], prompt)
    """
    from langchain_core.tools import StructuredTool
    from pydantic import Field, create_model

    context = context or {}

    # Create a Pydantic model from the parameters schema
    # This ensures proper validation and schema generation
    fields: Dict[str, Any] = {}
    params_schema = tool_instance.parameters_schema

    if params_schema and "properties" in params_schema:
        properties = params_schema["properties"]
        required_fields = params_schema.get("required", [])

        for field_name, field_info in properties.items():
            # Skip fields that are in context (they're pre-bound)
            if field_name in context:
                continue

            field_type = Any  # Default type
            field_desc = field_info.get("description", "")

            # Map JSON Schema types to Python types
            json_type = field_info.get("type", "string")
            if json_type == "string":
                field_type = str
            elif json_type == "integer":
                field_type = int
            elif json_type == "number":
                field_type = float
            elif json_type == "boolean":
                field_type = bool
            elif json_type == "array":
                field_type = list
            elif json_type == "object":
                field_type = dict

            # Determine if field is optional
            if field_name in required_fields:
                fields[field_name] = (field_type, Field(description=field_desc))
            else:
                # Optional field with default None
                fields[field_name] = (
                    Optional[field_type],
                    Field(default=None, description=field_desc),
                )

    # Create dynamic Pydantic model for args_schema
    args_schema_model = create_model(f"{tool_instance.name}_Args", **fields) if fields else None

    def func(**kwargs: Any) -> str:
        """Execute with pre-bound context."""
        all_args = {**context, **kwargs}
        result = tool_instance.execute(**all_args)
        return str(result)

    # Update description if context is provided
    description = tool_instance.description
    if context:
        context_str = ", ".join(f"{k}={v}" for k, v in context.items())
        description = f"{description} (Context: {context_str})"

    return StructuredTool.from_function(
        func=func,
        name=tool_instance.name,
        description=description,
        args_schema=args_schema_model,
    )


def create_langchain_executor(
    tool_instance: BaseCryptoTool,
    context: Optional[Dict[str, Any]] = None,
) -> Callable[[Dict[str, Any]], str]:
    """
    Create executor function for LangChain tool calls.

    This executor returns string results (as expected by LangChain tools).

    Args:
        tool_instance: The core tool
        context: Pre-bound context values

    Returns:
        Executor function that returns string results

    Example:
        >>> from cryptocom_tool_adapters import create_langchain_executor
        >>>
        >>> transfer_tool = TransferTool()
        >>> executor = create_langchain_executor(
        ...     transfer_tool,
        ...     {"wallet_address": "0x1234..."}
        ... )
        >>>
        >>> result = executor({"to": "0xabc...", "amount": 1.0})
        >>> print(result)
    """
    context = context or {}

    def executor(args: Dict[str, Any]) -> str:
        """Execute tool with merged context and arguments, returning string."""
        all_args = {**context, **args}
        result = tool_instance.execute(**all_args)
        return str(result)

    return executor
