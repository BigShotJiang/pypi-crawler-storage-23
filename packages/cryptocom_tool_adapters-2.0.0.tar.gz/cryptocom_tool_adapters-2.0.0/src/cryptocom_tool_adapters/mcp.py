"""MCP (Model Context Protocol) adapter for cryptocurrency tools.

Supports both:
- LangChain BaseTool (recommended for SDK tools)
- Custom tools with name/description/parameters_schema/execute() protocol
"""

from typing import TYPE_CHECKING, Any, Callable, Dict, Optional, Protocol, Union

if TYPE_CHECKING:
    # MCP types would go here if there was an MCP Python SDK
    # For now, we use Dict[str, Any] for MCP tool definitions
    from langchain_core.tools import BaseTool as LangChainBaseTool


# Protocol for tool instances
class BaseCryptoTool(Protocol):
    """Protocol for cryptocurrency tools."""

    name: str
    description: str

    @property
    def parameters_schema(self) -> Dict[str, Any]:
        """Return JSON schema for parameters."""
        ...

    def execute(self, **kwargs: Any) -> Any:
        """Execute the tool."""
        ...


def _is_langchain_basetool(tool: Any) -> bool:
    """Check if tool is a LangChain BaseTool instance."""
    try:
        from langchain_core.tools import BaseTool

        return isinstance(tool, BaseTool)
    except ImportError:
        return False


def _get_tool_schema(tool: Any) -> Dict[str, Any]:
    """Extract JSON schema from tool (LangChain or custom protocol)."""
    if _is_langchain_basetool(tool):
        if hasattr(tool, "args_schema") and tool.args_schema is not None:
            return tool.args_schema.model_json_schema()
        return {"type": "object", "properties": {}}
    return tool.parameters_schema


def to_mcp_tool(
    tool_instance: Union["LangChainBaseTool", BaseCryptoTool],
    context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Convert tool to MCP (Model Context Protocol) format.

    Args:
        tool_instance: The core tool
        context: Pre-bound context (e.g., {"wallet_address": "0x..."})

    Returns:
        MCP tool definition with name, description, and inputSchema

    Example:
        >>> class TransferTool:
        ...     name = "transfer_native_token"
        ...     description = "Transfer native tokens to an address"
        ...     @property
        ...     def parameters_schema(self) -> dict:
        ...         return {
        ...             "type": "object",
        ...             "properties": {
        ...                 "to": {"type": "string"},
        ...                 "amount": {"type": "number"},
        ...             },
        ...             "required": ["to", "amount"],
        ...         }
        ...     def execute(self, **kwargs):
        ...         return kwargs
        >>>
        >>> from cryptocom_tool_adapters import to_mcp_tool
        >>> transfer_tool = TransferTool()
        >>> tool_def = to_mcp_tool(transfer_tool)
    """
    tool_def: Dict[str, Any] = {
        "name": tool_instance.name,
        "description": tool_instance.description,
        "inputSchema": _get_tool_schema(tool_instance),
    }

    # If context is provided, note it in the description
    if context:
        context_str = ", ".join(f"{k}={v}" for k, v in context.items())
        tool_def["description"] = f"{tool_def['description']} (Context: {context_str})"

    return tool_def


def create_mcp_handler(
    tool_instance: Union["LangChainBaseTool", BaseCryptoTool],
    context: Optional[Dict[str, Any]] = None,
) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """
    Create handler function for MCP tool execution.

    Args:
        tool_instance: The core tool
        context: Pre-bound context values

    Returns:
        Handler function that returns MCP-formatted response

    Example:
        >>> from cryptocom_tool_adapters import create_mcp_handler
        >>>
        >>> transfer_tool = TransferTool()
        >>> handler = create_mcp_handler(
        ...     transfer_tool,
        ...     {"wallet_address": "0x1234..."}
        ... )
        >>>
        >>> request = {
        ...     "name": "transfer_native_token",
        ...     "arguments": {"to": "0xabc...", "amount": 1.0}
        ... }
        >>> response = handler(request["arguments"])
        >>> print(response)
    """
    context = context or {}
    is_langchain = _is_langchain_basetool(tool_instance)
    tool: Any = tool_instance

    def handler(arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle MCP tool call and return formatted response.

        Args:
            arguments: Tool arguments from MCP request

        Returns:
            Response dict with success status and result/error
        """
        try:
            # Merge context with provided arguments
            all_args = {**context, **arguments}
            if is_langchain:
                result = tool.invoke(all_args)
            else:
                result = tool.execute(**all_args)

            # Format result for MCP response
            if isinstance(result, dict):
                # Already a dict, use as-is
                result_data = result
            elif hasattr(result, "__dict__") and result.__dict__:
                # Object with attributes, use its __dict__
                result_data = result.__dict__
            else:
                # Convert to string for other types
                result_data = str(result)

            return {
                "success": True,
                "result": result_data,
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    return handler
