from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class APIError(Exception):
    status: int
    message: str
    code: str | None = None
    request_id: str | None = None
    meta: dict[str, Any] | None = None
    raw_body: str = ""
    payload: dict[str, Any] | None = None

    def __str__(self) -> str:
        code = f" code={self.code}" if self.code else ""
        request_id = f" request_id={self.request_id}" if self.request_id else ""
        return f"status={self.status}{code}{request_id} message={self.message}"
