"""TUI widgets for Nethergaze."""
