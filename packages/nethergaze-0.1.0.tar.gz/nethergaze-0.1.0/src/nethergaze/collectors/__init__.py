"""Data collectors for Nethergaze."""
