"""Support running as: python -m nethergaze"""

from nethergaze.cli import main

main()
