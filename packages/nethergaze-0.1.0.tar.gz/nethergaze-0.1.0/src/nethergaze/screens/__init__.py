"""TUI screens for Nethergaze."""
