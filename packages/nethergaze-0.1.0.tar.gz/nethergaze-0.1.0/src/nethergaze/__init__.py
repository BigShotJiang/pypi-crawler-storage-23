"""Nethergaze - Real-time VPS network traffic dashboard."""

__version__ = "0.1.0"
