"""Tests for DREAM library."""
