"""Unit test package for sar_coloc."""
