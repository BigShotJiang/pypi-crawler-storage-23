"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'build_server.proto')
_sym_db = _symbol_database.Default()
from . import os_environment_pb2 as os__environment__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x12build_server.proto\x12\x16codespeak.build_server\x1a\x14os_environment.proto"\xe8\x01\n\rClientMessage\x12@\n\x0bstart_build\x18\x01 \x01(\x0b2).codespeak.build_server.StartBuildRequestH\x00\x12B\n\x0ccancel_build\x18\x02 \x01(\x0b2*.codespeak.build_server.CancelBuildRequestH\x00\x12F\n\x0fos_env_response\x18\x03 \x01(\x0b2+.codespeak.os_environment.OperationResponseH\x00B\t\n\x07message"\x9e\x03\n\x11StartBuildRequest\x12\x14\n\x0cproject_root\x18\x01 \x01(\t\x12\x15\n\rsettings_json\x18\x02 \x01(\t\x12\x11\n\targs_json\x18\x03 \x01(\t\x12_\n\x14client_feature_flags\x18\x04 \x03(\x0b2A.codespeak.build_server.StartBuildRequest.ClientFeatureFlagsEntry\x12H\n\x08env_vars\x18\x05 \x03(\x0b26.codespeak.build_server.StartBuildRequest.EnvVarsEntry\x12\x12\n\nuser_token\x18\x06 \x01(\t\x12\x1f\n\x17client_protocol_version\x18\x07 \x01(\r\x1a9\n\x17ClientFeatureFlagsEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x01\x1a.\n\x0cEnvVarsEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x01"\x14\n\x12CancelBuildRequest"\xfa\x02\n\rServerMessage\x12E\n\rbuild_started\x18\x01 \x01(\x0b2,.codespeak.build_server.BuildStartedResponseH\x00\x12F\n\x0fprogress_update\x18\x02 \x01(\x0b2+.codespeak.build_server.BuildProgressUpdateH\x00\x12?\n\x0ebuild_finished\x18\x03 \x01(\x0b2%.codespeak.build_server.BuildFinishedH\x00\x12D\n\x0eos_env_request\x18\x04 \x01(\x0b2*.codespeak.os_environment.OperationRequestH\x00\x12H\n\x13build_insight_event\x18\x05 \x01(\x0b2).codespeak.build_server.BuildInsightEventH\x00B\t\n\x07message"_\n\x11BuildStartFailure\x129\n\x04type\x18\x01 \x01(\x0e2+.codespeak.build_server.BuildStartErrorType\x12\x0f\n\x07message\x18\x02 \x01(\t"F\n\x11BuildStartSuccess\x12\x10\n\x08build_id\x18\x01 \x01(\t\x12\x1f\n\x17server_protocol_version\x18\x02 \x01(\r"\x9c\x01\n\x14BuildStartedResponse\x12<\n\x07success\x18\x01 \x01(\x0b2).codespeak.build_server.BuildStartSuccessH\x00\x12<\n\x07failure\x18\x02 \x01(\x0b2).codespeak.build_server.BuildStartFailureH\x00B\x08\n\x06result"5\n\x13BuildProgressUpdate\x12\x0f\n\x07message\x18\x01 \x01(\t\x12\r\n\x05color\x18\x02 \x01(\t"K\n\x12CodespeakUserError\x12\x17\n\x0fexception_class\x18\x01 \x01(\t\x12\x1c\n\x14user_visible_message\x18\x02 \x01(\t"u\n\x16CodespeakInternalError\x12\x17\n\x0fexception_class\x18\x01 \x01(\t\x12\x18\n\x10internal_message\x18\x02 \x01(\t\x12\x18\n\x0bstack_trace\x18\x03 \x01(\tH\x00\x88\x01\x01B\x0e\n\x0c_stack_trace"\xa1\x01\n\nBuildError\x12@\n\nuser_error\x18\x01 \x01(\x0b2*.codespeak.build_server.CodespeakUserErrorH\x00\x12H\n\x0einternal_error\x18\x02 \x01(\x0b2..codespeak.build_server.CodespeakInternalErrorH\x00B\x07\n\x05error"\xea\x01\n\rBuildFinished\x12\x0f\n\x07command\x18\x01 \x01(\t\x12<\n\x0bresult_type\x18\x02 \x01(\x0e2\'.codespeak.build_server.BuildResultType\x12<\n\x0bbuild_error\x18\x03 \x01(\x0b2".codespeak.build_server.BuildErrorH\x00\x88\x01\x01\x12<\n\x0bbuild_stats\x18\x04 \x01(\x0b2\'.codespeak.build_server.BuildStatisticsB\x0e\n\x0c_build_error"R\n\x0fBuildStatistics\x12\x15\n\rcache_enabled\x18\x01 \x01(\x08\x12\x12\n\ncache_hits\x18\x02 \x01(\x05\x12\x14\n\x0ccache_misses\x18\x03 \x01(\x05"\xd1\x05\n\x11BuildInsightEvent\x12\x11\n\ttimestamp\x18\x01 \x01(\x01\x12\x17\n\x0fsequence_number\x18\x07 \x01(\x03\x12O\n\x14progress_item_create\x18\x02 \x01(\x0b2/.codespeak.build_server.ProgressItemCreateEventH\x00\x12O\n\x14progress_item_update\x18\x03 \x01(\x0b2/.codespeak.build_server.ProgressItemUpdateEventH\x00\x12>\n\x0btext_output\x18\x04 \x01(\x0b2\'.codespeak.build_server.TextOutputEventH\x00\x12:\n\ttool_call\x18\x05 \x01(\x0b2%.codespeak.build_server.ToolCallEventH\x00\x12X\n\x19user_visible_model_output\x18\x06 \x01(\x0b23.codespeak.build_server.UserVisibleModelOutputEventH\x00\x12:\n\tspan_open\x18\x08 \x01(\x0b2%.codespeak.build_server.SpanOpenEventH\x00\x12<\n\nspan_close\x18\t \x01(\x0b2&.codespeak.build_server.SpanCloseEventH\x00\x12:\n\ttests_run\x18\n \x01(\x0b2%.codespeak.build_server.TestsRunEventH\x00\x12Y\n\x19stop_interactive_progress\x18\x0b \x01(\x0b24.codespeak.build_server.StopInteractiveProgressEventH\x00B\x07\n\x05event"\xc0\x02\n\x17ProgressItemCreateEvent\x12\x18\n\x10progress_item_id\x18\x01 \x01(\t\x12:\n\x06status\x18\x02 \x01(\x0e2*.codespeak.build_server.ProgressItemStatus\x12\r\n\x05title\x18\x03 \x01(\t\x12\x18\n\x0bdescription\x18\x04 \x01(\tH\x00\x88\x01\x01\x12\x1b\n\x0eparent_item_id\x18\x05 \x01(\tH\x01\x88\x01\x01\x12\x18\n\x0bstatus_text\x18\x06 \x01(\tH\x02\x88\x01\x01\x12"\n\x15truncate_child_output\x18\x07 \x01(\x08H\x03\x88\x01\x01B\x0e\n\x0c_descriptionB\x11\n\x0f_parent_item_idB\x0e\n\x0c_status_textB\x18\n\x16_truncate_child_output"\x99\x01\n\x17ProgressItemUpdateEvent\x12\x18\n\x10progress_item_id\x18\x01 \x01(\t\x12:\n\x06status\x18\x02 \x01(\x0e2*.codespeak.build_server.ProgressItemStatus\x12\x18\n\x0bstatus_text\x18\x03 \x01(\tH\x00\x88\x01\x01B\x0e\n\x0c_status_text"a\n\x0fTextOutputEvent\x12\x0c\n\x04text\x18\x01 \x01(\t\x12$\n\x17parent_progress_item_id\x18\x02 \x01(\tH\x00\x88\x01\x01B\x1a\n\x18_parent_progress_item_id"\x82\x01\n\rToolCallEvent\x12\r\n\x05title\x18\x01 \x01(\t\x12\x14\n\x07details\x18\x02 \x01(\tH\x00\x88\x01\x01\x12$\n\x17parent_progress_item_id\x18\x03 \x01(\tH\x01\x88\x01\x01B\n\n\x08_detailsB\x1a\n\x18_parent_progress_item_id"m\n\x1bUserVisibleModelOutputEvent\x12\x0c\n\x04text\x18\x01 \x01(\t\x12$\n\x17parent_progress_item_id\x18\x02 \x01(\tH\x00\x88\x01\x01B\x1a\n\x18_parent_progress_item_id"Y\n\rSpanOpenEvent\x12\x0f\n\x07span_id\x18\x01 \x01(\t\x12\r\n\x05title\x18\x02 \x01(\t\x12\x18\n\x0bdescription\x18\x03 \x01(\tH\x00\x88\x01\x01B\x0e\n\x0c_description"!\n\x0eSpanCloseEvent\x12\x0f\n\x07span_id\x18\x01 \x01(\t"E\n\rTestsRunEvent\x12\x1e\n\x11test_results_json\x18\x01 \x01(\tH\x00\x88\x01\x01B\x14\n\x12_test_results_json"\x1e\n\x1cStopInteractiveProgressEvent*\xad\x02\n\x13BuildStartErrorType\x12&\n"BUILD_START_ERROR_TYPE_UNSPECIFIED\x10\x00\x12-\n)BUILD_START_ERROR_TYPE_USER_TOKEN_MISSING\x10\x01\x12/\n+BUILD_START_ERROR_TYPE_USER_NOT_ALLOWLISTED\x10\x02\x12\'\n#BUILD_START_ERROR_TYPE_USER_BLOCKED\x10\x03\x127\n3BUILD_START_ERROR_TYPE_UNSUPPORTED_PROTOCOL_VERSION\x10\x04\x12,\n(BUILD_START_ERROR_TYPE_SERVER_OVERLOADED\x10\x05*\x9a\x01\n\x0fBuildResultType\x12\x1c\n\x18BUILD_RESULT_UNSPECIFIED\x10\x00\x12\x1a\n\x16BUILD_RESULT_SUCCEEDED\x10\x01\x12\x17\n\x13BUILD_RESULT_FAILED\x10\x02\x12\x1a\n\x16BUILD_RESULT_CANCELLED\x10\x03\x12\x18\n\x14BUILD_RESULT_SKIPPED\x10\x04*\xe4\x01\n\x12ProgressItemStatus\x12$\n PROGRESS_ITEM_STATUS_UNSPECIFIED\x10\x00\x12 \n\x1cPROGRESS_ITEM_STATUS_PENDING\x10\x01\x12$\n PROGRESS_ITEM_STATUS_IN_PROGRESS\x10\x02\x12 \n\x1cPROGRESS_ITEM_STATUS_SKIPPED\x10\x03\x12\x1d\n\x19PROGRESS_ITEM_STATUS_DONE\x10\x04\x12\x1f\n\x1bPROGRESS_ITEM_STATUS_FAILED\x10\x052i\n\x0cBuildService\x12Y\n\x05Build\x12%.codespeak.build_server.ClientMessage\x1a%.codespeak.build_server.ServerMessage(\x010\x01b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'build_server_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_STARTBUILDREQUEST_CLIENTFEATUREFLAGSENTRY']._loaded_options = None
    _globals['_STARTBUILDREQUEST_CLIENTFEATUREFLAGSENTRY']._serialized_options = b'8\x01'
    _globals['_STARTBUILDREQUEST_ENVVARSENTRY']._loaded_options = None
    _globals['_STARTBUILDREQUEST_ENVVARSENTRY']._serialized_options = b'8\x01'
    _globals['_BUILDSTARTERRORTYPE']._serialized_start = 3963
    _globals['_BUILDSTARTERRORTYPE']._serialized_end = 4264
    _globals['_BUILDRESULTTYPE']._serialized_start = 4267
    _globals['_BUILDRESULTTYPE']._serialized_end = 4421
    _globals['_PROGRESSITEMSTATUS']._serialized_start = 4424
    _globals['_PROGRESSITEMSTATUS']._serialized_end = 4652
    _globals['_CLIENTMESSAGE']._serialized_start = 69
    _globals['_CLIENTMESSAGE']._serialized_end = 301
    _globals['_STARTBUILDREQUEST']._serialized_start = 304
    _globals['_STARTBUILDREQUEST']._serialized_end = 718
    _globals['_STARTBUILDREQUEST_CLIENTFEATUREFLAGSENTRY']._serialized_start = 613
    _globals['_STARTBUILDREQUEST_CLIENTFEATUREFLAGSENTRY']._serialized_end = 670
    _globals['_STARTBUILDREQUEST_ENVVARSENTRY']._serialized_start = 672
    _globals['_STARTBUILDREQUEST_ENVVARSENTRY']._serialized_end = 718
    _globals['_CANCELBUILDREQUEST']._serialized_start = 720
    _globals['_CANCELBUILDREQUEST']._serialized_end = 740
    _globals['_SERVERMESSAGE']._serialized_start = 743
    _globals['_SERVERMESSAGE']._serialized_end = 1121
    _globals['_BUILDSTARTFAILURE']._serialized_start = 1123
    _globals['_BUILDSTARTFAILURE']._serialized_end = 1218
    _globals['_BUILDSTARTSUCCESS']._serialized_start = 1220
    _globals['_BUILDSTARTSUCCESS']._serialized_end = 1290
    _globals['_BUILDSTARTEDRESPONSE']._serialized_start = 1293
    _globals['_BUILDSTARTEDRESPONSE']._serialized_end = 1449
    _globals['_BUILDPROGRESSUPDATE']._serialized_start = 1451
    _globals['_BUILDPROGRESSUPDATE']._serialized_end = 1504
    _globals['_CODESPEAKUSERERROR']._serialized_start = 1506
    _globals['_CODESPEAKUSERERROR']._serialized_end = 1581
    _globals['_CODESPEAKINTERNALERROR']._serialized_start = 1583
    _globals['_CODESPEAKINTERNALERROR']._serialized_end = 1700
    _globals['_BUILDERROR']._serialized_start = 1703
    _globals['_BUILDERROR']._serialized_end = 1864
    _globals['_BUILDFINISHED']._serialized_start = 1867
    _globals['_BUILDFINISHED']._serialized_end = 2101
    _globals['_BUILDSTATISTICS']._serialized_start = 2103
    _globals['_BUILDSTATISTICS']._serialized_end = 2185
    _globals['_BUILDINSIGHTEVENT']._serialized_start = 2188
    _globals['_BUILDINSIGHTEVENT']._serialized_end = 2909
    _globals['_PROGRESSITEMCREATEEVENT']._serialized_start = 2912
    _globals['_PROGRESSITEMCREATEEVENT']._serialized_end = 3232
    _globals['_PROGRESSITEMUPDATEEVENT']._serialized_start = 3235
    _globals['_PROGRESSITEMUPDATEEVENT']._serialized_end = 3388
    _globals['_TEXTOUTPUTEVENT']._serialized_start = 3390
    _globals['_TEXTOUTPUTEVENT']._serialized_end = 3487
    _globals['_TOOLCALLEVENT']._serialized_start = 3490
    _globals['_TOOLCALLEVENT']._serialized_end = 3620
    _globals['_USERVISIBLEMODELOUTPUTEVENT']._serialized_start = 3622
    _globals['_USERVISIBLEMODELOUTPUTEVENT']._serialized_end = 3731
    _globals['_SPANOPENEVENT']._serialized_start = 3733
    _globals['_SPANOPENEVENT']._serialized_end = 3822
    _globals['_SPANCLOSEEVENT']._serialized_start = 3824
    _globals['_SPANCLOSEEVENT']._serialized_end = 3857
    _globals['_TESTSRUNEVENT']._serialized_start = 3859
    _globals['_TESTSRUNEVENT']._serialized_end = 3928
    _globals['_STOPINTERACTIVEPROGRESSEVENT']._serialized_start = 3930
    _globals['_STOPINTERACTIVEPROGRESSEVENT']._serialized_end = 3960
    _globals['_BUILDSERVICE']._serialized_start = 4654
    _globals['_BUILDSERVICE']._serialized_end = 4759