"""
Utilities for formatting OsEnvironment operation requests for logging.
"""

from api_stubs.os_environment_pb2 import (
    AppendToFileRequest,
    CopyRequest,
    DeleteFileRequest,
    DeleteRecursivelyRequest,
    ExistsRequest,
    GetAttributesRequest,
    GlobRequest,
    GrepRequest,
    IsDirectoryRequest,
    IsFileRequest,
    ListDirectoryRequest,
    ListTreeRequest,
    MkdirsRequest,
    OperationRequest,
    ReadFileRequest,
    ResolvePathRequest,
    ResolveUserNameRequest,
    RunChildProcessRequest,
    RunDjangoDevServerRequest,
    TraverseRequest,
    WriteFileRequest,
)


class OsEnvRequestLogging:
    @staticmethod
    def _pretty_print_file_size(size: int) -> str:
        if size >= 1024 * 1024 * 1024:
            return f"{size // (1024 * 1024 * 1024)} GB"
        if size >= 1024 * 1024:
            return f"{size // (1024 * 1024)} MB"
        elif size >= 1024:
            return f"{size // 1024} KB"
        else:
            return f"{size} bytes"

    @staticmethod
    def _format_get_attributes_request(request: GetAttributesRequest) -> str:
        return f"GetAttributes: path={request.path}"

    @staticmethod
    def _format_read_file_request(request: ReadFileRequest) -> str:
        return f"ReadFile: path={request.path}"

    @staticmethod
    def _format_write_file_request(request: WriteFileRequest) -> str:
        return (
            f"WriteFile: path={request.path}, size={OsEnvRequestLogging._pretty_print_file_size(len(request.content))}"
        )

    @staticmethod
    def _format_append_to_file_request(request: AppendToFileRequest) -> str:
        return f"AppendToFile: path={request.path}, size={OsEnvRequestLogging._pretty_print_file_size(len(request.content))}"

    @staticmethod
    def _format_mkdirs_request(request: MkdirsRequest) -> str:
        return f"Mkdirs: path={request.path}"

    @staticmethod
    def _format_is_file_request(request: IsFileRequest) -> str:
        return f"IsFile: path={request.path}"

    @staticmethod
    def _format_is_directory_request(request: IsDirectoryRequest) -> str:
        return f"IsDirectory: path={request.path}"

    @staticmethod
    def _format_exists_request(request: ExistsRequest) -> str:
        return f"Exists: path={request.path}"

    @staticmethod
    def _format_copy_request(request: CopyRequest) -> str:
        return f"Copy: from={request.source_path} to={request.dest_path}"

    @staticmethod
    def _format_delete_recursively_request(request: DeleteRecursivelyRequest) -> str:
        return f"DeleteRecursively: path={request.path}"

    @staticmethod
    def _format_delete_file_request(request: DeleteFileRequest) -> str:
        return f"DeleteFile: path={request.path}"

    @staticmethod
    def _format_list_directory_request(request: ListDirectoryRequest) -> str:
        return f"ListDirectory: path={request.path}"

    @staticmethod
    def _format_glob_request(request: GlobRequest) -> str:
        if request.path:
            return f"Glob: pattern={request.pattern}, path={request.path}"
        return f"Glob: pattern={request.pattern}"

    @staticmethod
    def _format_grep_request(request: GrepRequest) -> str:
        parts = [f"Grep: pattern={request.pattern}"]
        if request.path:
            parts.append(f"path={request.path}")
        if request.glob:
            parts.append(f"glob={request.glob}")
        return ", ".join(parts)

    @staticmethod
    def _format_resolve_user_name_request(_request: ResolveUserNameRequest) -> str:
        return "ResolveUserName"

    @staticmethod
    def _format_run_child_process_request(request: RunChildProcessRequest) -> str:
        return f"RunChildProcess: args={list(request.args)}, cwd={request.cwd_relative}"

    @staticmethod
    def _format_resolve_path_request(request: ResolvePathRequest) -> str:
        return f"ResolvePath: path={request.path}"

    @staticmethod
    def _format_traverse_request(request: TraverseRequest) -> str:
        return f"Traverse: extension={request.required_extension}"

    @staticmethod
    def _format_list_tree_request(request: ListTreeRequest) -> str:
        parts = ["ListTree"]
        if request.path:
            parts.append(f"path={request.path}")
        if request.HasField("max_depth"):
            parts.append(f"max_depth={request.max_depth}")
        return ": ".join(parts[:1]) + (", ".join(parts[1:]) if len(parts) > 1 else "")

    @staticmethod
    def _format_run_django_dev_server_request(request: RunDjangoDevServerRequest) -> str:
        return f"RunDjangoDevServer: server_readiness_timeout={request.server_readiness_timeout_sec}s, run_mode={request.run_mode}"

    @staticmethod
    def format(request: OperationRequest) -> str:
        which = request.WhichOneof("operation")

        if which == "get_attributes":
            result = OsEnvRequestLogging._format_get_attributes_request(request.get_attributes)
        elif which == "read_file":
            result = OsEnvRequestLogging._format_read_file_request(request.read_file)
        elif which == "write_file":
            result = OsEnvRequestLogging._format_write_file_request(request.write_file)
        elif which == "append_to_file":
            result = OsEnvRequestLogging._format_append_to_file_request(request.append_to_file)
        elif which == "mkdirs":
            result = OsEnvRequestLogging._format_mkdirs_request(request.mkdirs)
        elif which == "is_file":
            result = OsEnvRequestLogging._format_is_file_request(request.is_file)
        elif which == "is_directory":
            result = OsEnvRequestLogging._format_is_directory_request(request.is_directory)
        elif which == "exists":
            result = OsEnvRequestLogging._format_exists_request(request.exists)
        elif which == "copy":
            result = OsEnvRequestLogging._format_copy_request(request.copy)
        elif which == "delete_recursively":
            result = OsEnvRequestLogging._format_delete_recursively_request(request.delete_recursively)
        elif which == "delete_file":
            result = OsEnvRequestLogging._format_delete_file_request(request.delete_file)
        elif which == "list_directory":
            result = OsEnvRequestLogging._format_list_directory_request(request.list_directory)
        elif which == "glob":
            result = OsEnvRequestLogging._format_glob_request(request.glob)
        elif which == "resolve_user_name":
            result = OsEnvRequestLogging._format_resolve_user_name_request(request.resolve_user_name)
        elif which == "run_child_process":
            result = OsEnvRequestLogging._format_run_child_process_request(request.run_child_process)
        elif which == "resolve_path":
            result = OsEnvRequestLogging._format_resolve_path_request(request.resolve_path)
        elif which == "traverse":
            result = OsEnvRequestLogging._format_traverse_request(request.traverse)
        elif which == "run_django_dev_server":
            result = OsEnvRequestLogging._format_run_django_dev_server_request(request.run_django_dev_server)
        elif which == "grep":
            result = OsEnvRequestLogging._format_grep_request(request.grep)
        elif which == "list_tree":
            result = OsEnvRequestLogging._format_list_tree_request(request.list_tree)
        else:
            raise ValueError(f"Unknown operation: {which}")

        return f"{result} (ID: {request.request_id[:8]})"
