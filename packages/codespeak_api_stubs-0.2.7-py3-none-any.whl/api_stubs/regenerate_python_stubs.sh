#!/usr/bin/env bash

# Script to regenerate protobuf stubs from .proto files
# This script should be run from any directory in the project

set -euo pipefail

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Define the proto source directory
PROTO_DIR="$(cd "$SCRIPT_DIR/../../../protos/build-server" && pwd)"

# Change to the api_stubs directory (where stubs will be generated)
cd "$SCRIPT_DIR"

echo "Regenerating protobuf stubs in: $SCRIPT_DIR"
echo "Using proto files from: $PROTO_DIR"
echo ""

# Find all .proto files in the proto directory
PROTO_FILES=("$PROTO_DIR"/*.proto)

if [ ${#PROTO_FILES[@]} -eq 0 ]; then
    echo "Error: No .proto files found in $PROTO_DIR"
    exit 1
fi

echo "Found ${#PROTO_FILES[@]} .proto file(s):"
printf '  - %s\n' "${PROTO_FILES[@]}"
echo ""

# Generate stubs for each .proto file
for proto_file in "${PROTO_FILES[@]}"; do
    echo "Generating stubs for: $proto_file"

    # Use uv to run the protoc compiler
    # -I"$PROTO_DIR" : Include proto directory for imports (allows build_server.proto to import os_environment.proto)
    # --python_out=. : Generate *_pb2.py files in current directory
    # --grpc_python_out=. : Generate *_pb2_grpc.py files in current directory
    # --pyi_out=. : Generate *_pb2.pyi type stub files in current directory
    uv run python -m grpc_tools.protoc \
        -I"$PROTO_DIR" \
        --python_out=. \
        --grpc_python_out=. \
        --pyi_out=. \
        "$proto_file"

    echo "  ✓ Generated stubs for $proto_file"
done

echo ""
echo "Fixing imports in generated files using protoletariat..."

# Create a temporary directory for the protoc wrapper
TEMP_BIN_DIR=$(mktemp -d)
trap 'rm -rf "$TEMP_BIN_DIR"' EXIT

# Create a protoc wrapper script that calls grpc_tools.protoc
# This is needed because protoletariat expects 'protoc' to be in PATH
cat > "$TEMP_BIN_DIR/protoc" << 'EOF'
#!/usr/bin/env bash
exec python -m grpc_tools.protoc "$@"
EOF
chmod +x "$TEMP_BIN_DIR/protoc"

# Add the wrapper to PATH temporarily
export PATH="$TEMP_BIN_DIR:$PATH"

# Use protoletariat to fix imports in generated files
# This converts absolute imports (import foo_pb2) to relative imports (from . import foo_pb2)
uv run protol \
    --in-place \
    --python-out="$SCRIPT_DIR" \
    protoc \
    --proto-path="$PROTO_DIR" \
    "${PROTO_FILES[@]}"

echo "  ✓ Fixed imports in all generated files"

echo ""
echo "All protobuf stubs have been regenerated successfully!"
echo ""
echo "Generated files:"
ls -1 *_pb2.py *_pb2.pyi *_pb2_grpc.py 2>/dev/null || echo "  (no generated files found)"
