import os
import sys
from pathlib import Path


def setup_grpc(enable_tracing: bool) -> None:
    """Configure gRPC tracing.

    NOTE: this MUST be called before importing grpc module

    When tracing enabled, gRPC traces are redirected to 'codespeak_client_stderr.log' in the
    current directory to avoid cluttering terminal output.
    """

    if "grpc" in sys.modules:
        raise RuntimeError("Must be called before importing grpc module")

    # details: https://github.com/grpc/grpc/issues/28557
    os.environ["GRPC_ENABLE_FORK_SUPPORT"] = "False"

    if enable_tracing:
        # Redirect stderr to file before gRPC starts logging
        # gRPC's C library writes directly to fd 2, so we need to redirect at fd level
        stderr_file = Path.cwd() / ".codespeak/ignored/codespeak_client_stderr.log"
        stderr_file.parent.mkdir(parents=True, exist_ok=True)
        grpc_log_fd = os.open(stderr_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o666)

        # Save original stderr fd
        original_stderr_fd = os.dup(2)

        # Redirect fd 2 to the file
        os.dup2(grpc_log_fd, 2)
        os.close(grpc_log_fd)

        # Create new stderr that writes to original terminal
        sys.stderr = os.fdopen(original_stderr_fd, "w", encoding="utf-8")

        # all trace flags: https://github.com/grpc/grpc/blob/master/doc/trace_flags.md
        os.environ["GRPC_TRACE"] = "http,http2_stream_state,connectivity_state"
        os.environ["GRPC_VERBOSITY"] = "DEBUG"
    else:
        os.environ["GRPC_VERBOSITY"] = "NONE"
