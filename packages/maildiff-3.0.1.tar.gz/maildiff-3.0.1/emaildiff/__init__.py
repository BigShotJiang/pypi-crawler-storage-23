"""
Main package for git-maildiff.

This package provides tools to email color git diffs directly from the command line.
"""

from . import maildiff_cmd
