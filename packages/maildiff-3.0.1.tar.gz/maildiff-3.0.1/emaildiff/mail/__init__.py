"""
Email sending module for git-maildiff.

This module contains the email sending functionality used by the git-maildiff tool.
"""
