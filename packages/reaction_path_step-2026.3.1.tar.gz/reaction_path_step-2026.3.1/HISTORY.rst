=======
History
=======
2026.3.1 -- Internal: switching from deprecated library pkg_resources to importlib

2024.12.14 -- Enhancements to control and to output
    * Cleaned up the control parameters to make them more consistent, and updated
      defaults to better values based on experience.
    * Cleaned up the output.
      
2024.8.4 (2024-08-04)
---------------------

* Plug-in created using the SEAMM plug-in cookiecutter.
