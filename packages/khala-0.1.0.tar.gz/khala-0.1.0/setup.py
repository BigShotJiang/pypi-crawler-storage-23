from setuptools import setup, find_packages

with open("readme.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="khala",
    version="0.1.0",
    description="串口带外管理：MAC/网络注入与 Telnet 调试",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "click",
        "sdev",
    ],
    entry_points={
        "console_scripts": ["khala=khala.cli:main"],
    },
)
