# Project Khala: Architecture & implementation Spec

## 1. 核心目标 (Mission)

通过 `sdev` 库独占串口，自动识别硬件 ID，并利用串口作为“带外管理”通道，自动为 Linux 开发板注入 MAC 地址、启动 DHCP 并开启 Telnet 调试服务。

## 2. 核心模块分解

### A. Serial Engine (基于 `sdev`)

* **作用**：负责所有物理层交互。
* **逻辑**：
* **Watchdog**：持续监听串口流。
* **Pattern Matcher**：识别 `U-Boot`、`Kernel Panic`、`Starting kernel`、`login:` 等关键字。
* **Injector**：在匹配到 Prompt 后，自动逐行注入配置脚本。



### B. Identity & Network (Identity Module)

* **MAC 算法**：
* 通过 `sdev` 执行 `cat /proc/cpuinfo` 提取 `Serial` 字段。
* 生成唯一 MAC：`02:50:4B` + `md5(Serial).hex()[0:6]`。


* **Provisioning 脚本**（由 `sdev` 注入执行）：
```bash
ifconfig eth0 down
ifconfig eth0 hw ether <GENERATED_MAC>
ifconfig eth0 up
udhcpc -i eth0 -n &
/usr/sbin/telnetd -p 23 -l /bin/sh

```



### C. Daemon & Registry (Host Side)

* **khalad**：作为后台进程，管理多个串口实例。
* **Registry**：记录 `Host:DeviceName` 到 `MAC/IP/Status` 的映射（SQLite 或 JSON）。
* **Distributed View**：支持通过网络查询其他 Host 上的 Khala 实例状态。

---

## 3. CLI 交互逻辑 (The Workflow)

| 命令 | 行为描述 |
| --- | --- |
| **`khala add -D /dev/ttyUSB0 -n xc01`** | 手动绑定串口并命名为 `xc01`。 |
| **`khala add all`** | **自动发现模式**：扫描所有 `/dev/ttyUSB*`，由 `sdev` 尝试握手。握手成功后，通过重启日志识别型号并命名。 |
| **`khala list`** | 显示本地及远程 Host 的所有设备（Name, Active状态, 设备路径, 获取到的 IP）。 |
| **`khala activate <target>`** | 1. 检查目标是否已被占用；2. `sdev` 介入并注入网络配置；3. 获取 DHCP IP 后存入 Registry 并显示。 |
| **`khala deactivate`** | **本地退栈**：对最后激活的设备发送 `reboot` 命令，清理其内存状态并释放服务。 |

---

## 4. 给 Cursor 的具体开发指令 (Task Prompt)

> **"请基于以下设计实现 Khala 系统："**
> 1. **集成 sdev**：使用 `sdev` 库作为串口后端。创建一个 `KhalaDevice` 类，能够异步监听串口并在匹配到 `login:` 后执行回调。
> 2. **实现 Identity 模块**：编写函数，根据输入的 Serial ID 字符串，按照 `02:50:4B` 前缀生成确定性的 MAC 地址。
> 3. **状态机管理**：实现设备的生命周期管理（Added -> Booting -> Identified -> Active -> Panic）。
> 4. **IP 追踪器**：在 `activate` 过程中，注入 `udhcpc` 后，需通过 `sdev` 执行 `ip addr show eth0` 并正则解析出分配到的 IPv4 地址。
> 5. **CLI 框架**：使用 `click` 或 `argparse` 构建满足上述定义的 CLI 接口。
> 
> 

---

### 给你的最后提醒：

* **sdev 的独占性**：Cursor 在写代码时，要确保 `khala` 进程持有 `sdev` 对象期间，不会有其他进程干扰串口。
* **并发处理**：如果有多个串口（ttyUSB0, ttyUSB1...），`khalad` 必须为每个串口分配独立的线程或协程，互不阻塞。

**这份文档已经准备好，你可以开启 Cursor 的工作了！祝你的 Khala 开发顺利！**