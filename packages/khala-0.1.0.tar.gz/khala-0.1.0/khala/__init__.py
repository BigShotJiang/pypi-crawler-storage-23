"""
Khala - 串口带外管理：MAC/网络注入与 Telnet 调试

- KhalaDevice / KhalaServer：设备与多设备管理；
- identity：Serial -> MAC、provisioning 脚本；
- state_machine：设备状态机；
- serial_engine：串口 Watchdog 与注入。
"""

from .core import KhalaDevice, KhalaServer
from .identity import (
    serial_to_mac,
    parse_serial_from_cpuinfo,
    provisioning_script,
)
from .state_machine import DeviceState, transition, can_transition

__version__ = "0.1.0"

__all__ = [
    "KhalaDevice",
    "KhalaServer",
    "DeviceState",
    "transition",
    "can_transition",
    "serial_to_mac",
    "parse_serial_from_cpuinfo",
    "provisioning_script",
]
