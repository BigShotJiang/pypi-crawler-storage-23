from __future__ import annotations
import decimal
from functools import cache
from types import TracebackType
from typing import Optional, Type, Union, TypeAlias
import numbers
from strict_decimal.exceptions import (
    InfinityNotSupported,
    NanNotSupported,
)

# represents type that is convertable to `StrictDecimal`
StrictDecimalLike: TypeAlias = Union[str, int, decimal.Decimal, tuple, "StrictDecimal"]

# represents type that can be used in arithmetic operations
Number: TypeAlias = Union["StrictDecimal", decimal.Decimal, int]

# represents type that can be used in comparison operations
ComparableNumber: TypeAlias = Union[
    "StrictDecimal", decimal.Decimal, float, numbers.Rational
]


class StrictDecimalContext(decimal.Context):
    """Decimal context, with all signals trapped."""

    def __init__(self, precision=128) -> None:
        self.precision = precision
        traps = [
            decimal.Clamped,
            decimal.DivisionByZero,
            decimal.FloatOperation,
            decimal.Inexact,
            decimal.InvalidOperation,
            decimal.Rounded,
            decimal.Subnormal,
        ]

        super().__init__(traps=traps, prec=self.precision)
        self.saved_context: Optional[decimal.Context] = None

    def __enter__(self) -> decimal.Context:
        """Set the decimal context to `StrictDecimalContext` and return it."""
        self.saved_context = decimal.getcontext()
        context = self.copy()
        decimal.setcontext(context)
        return context

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        """Reset the decimal context to what it was."""
        if self.saved_context:
            decimal.setcontext(self.saved_context)

    def create_decimal(self, num: StrictDecimalLike = "0", /) -> decimal.Decimal:
        if isinstance(num, StrictDecimal):
            num = num.decimal
        dec = super().create_decimal(num)
        return dec

    @staticmethod
    def create_strict_decimal(num: StrictDecimalLike = "0", /) -> StrictDecimal:
        return StrictDecimal(num)


@cache
def default_strict_decimal_context() -> StrictDecimalContext:
    """Return always same instance (singleton) of `StrictDecimalContext`."""
    return StrictDecimalContext(precision=128)


class StrictDecimal:
    """A decimal class that operates within most strict decimal context possible.

    `StrictDecimal` is intended to be used in financial applications, where no hidden
    rounding or inexactness is allowed. Additionally, trailing redundant zeroes are
    dropped, scientific notation is removed, NaN and infinity are not allowed.

    `StrictDecimal` uses `StrictDecimalContext` instead of default context that
    comes with `decimal` module.

    `StrictDecimal` does not inherit from `Decimal` on purpose: inheriting makes
    managing context in which operations are done more tedious.

    `StrictDecimal` is only a partial substitute for `Decimal`. Some `Decimal` methods
    are not implemented.
    """

    def __init__(self, value: StrictDecimalLike, /) -> None:
        """Initialize a `StrictDecimal` instance from provided `value`."""
        dec = self.context.create_decimal(value)

        if dec.is_infinite():
            raise InfinityNotSupported("Infinity not supported.")

        if dec.is_nan():
            raise NanNotSupported("NaN not supported.")

        dec = self._adjust_exponent_and_trim_redundant_zeros(dec)
        self.decimal = dec

    def _adjust_exponent_and_trim_redundant_zeros(
        self, value: decimal.Decimal
    ) -> decimal.Decimal:
        """Adjust exponent to avoid scientific notation and trim redundant zeros.

        Adapted from https://docs.python.org/3/library/decimal.html#decimal-faq.
        """
        if value == int(value):
            # we have a whole number here

            # normalize first to avoid Rounded signal when quantizing decimal
            #  values that have explicit fractional part of zero, e.g.
            #  Decimal("10.0") and Decimal("1.1e4")
            normalized = value.normalize(context=self.context)

            value = normalized.quantize(decimal.Decimal(1), context=self.context)
        else:
            value = value.normalize(context=self.context)

        return value

    def __setattr__(self, name, value):
        # make `decimal` attribute immutable once it has been set by `__init__`.
        if name == "decimal" and hasattr(self, "decimal"):
            raise AttributeError("Attribute `decimal` is immutable")
        super().__setattr__(name, value)

    @property
    def context(self) -> StrictDecimalContext:
        return default_strict_decimal_context()

    def __bool__(self) -> bool:
        return self.decimal.__bool__()

    def __hash__(self) -> int:
        return self.decimal.__hash__()

    def __abs__(self) -> StrictDecimal:
        dec = self.context.abs(self.decimal)
        return self.context.create_strict_decimal(dec)

    def __add__(self, value: Number) -> StrictDecimal:
        value = self._normalize_for_decimal(value=value)
        result = self.context.add(self.decimal, value)
        return self.context.create_strict_decimal(result)

    def __radd__(self, value: Number) -> StrictDecimal:
        return self.__add__(value)

    def __sub__(self, value: Number) -> StrictDecimal:
        value = self._normalize_for_decimal(value=value)
        result = self.context.subtract(self.decimal, value)
        return self.context.create_strict_decimal(result)

    def __rsub__(self, value: Number) -> StrictDecimal:
        return self.context.create_strict_decimal(value).__sub__(self)

    def __mul__(self, value: Number) -> StrictDecimal:
        value = self._normalize_for_decimal(value=value)
        result = self.context.multiply(self.decimal, value)
        return self.context.create_strict_decimal(result)

    def __rmul__(self, value: Number) -> StrictDecimal:
        return self.__mul__(value)

    def __truediv__(self, value: Number) -> StrictDecimal:
        value = self._normalize_for_decimal(value=value)
        result = self.context.divide(self.decimal, value)
        return self.context.create_strict_decimal(result)

    def __rtruediv__(self, value: Number) -> StrictDecimal:
        return self.__truediv__(value)

    def __eq__(self, value: object) -> bool:
        if isinstance(value, StrictDecimal):
            value = value.decimal
        return self.decimal.__eq__(value)

    def __repr__(self):
        return self.decimal.__repr__().replace("Decimal", "StrictDecimal")

    @staticmethod
    def _normalize_for_decimal(
        value: Union["StrictDecimal", decimal.Decimal, float, numbers.Rational],
    ) -> Union[decimal.Decimal, float, numbers.Rational]:
        if isinstance(value, StrictDecimal):
            value = value.decimal
        return value

    def __ge__(self, value: ComparableNumber) -> bool:
        value = self._normalize_for_decimal(value=value)
        return self.decimal.__ge__(value)

    def __gt__(self, value: ComparableNumber) -> bool:
        value = self._normalize_for_decimal(value=value)
        return self.decimal.__gt__(value)

    def __le__(self, value: ComparableNumber) -> bool:
        value = self._normalize_for_decimal(value=value)
        return self.decimal.__le__(value)

    def __lt__(self, value: ComparableNumber) -> bool:
        value = self._normalize_for_decimal(value=value)
        return self.decimal.__lt__(value)
