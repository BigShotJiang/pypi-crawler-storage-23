class InfinityNotSupported(Exception):
    """Raised when StrictDecimal is being initialized with infinity."""


class NanNotSupported(Exception):
    """Raised when StrictDecimal is being initialized with Nan."""


class DifferentContexts(Exception):
    """Raises when an operation involves multiple contexts."""
