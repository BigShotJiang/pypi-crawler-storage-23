# strict-decimal

## Publishing to PyPI

```
git checkout <tag>
uv build
twine check dist/*
twine upload dist/*
git checkout master
```
