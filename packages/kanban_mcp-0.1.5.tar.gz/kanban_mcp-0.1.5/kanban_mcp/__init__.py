"""Kanban MCP Server — issue/todo/feature tracking for Claude Code."""

__version__ = "0.1.5"
