# -*- coding: utf-8 -*-
"""
ui_help_de.py

Deutschsprachige Hilfetexte für die MigMan/DataMate-Konfigurations-UI (NiceGUI).

Design-Ziel:
- ui.py bleibt UI-/Controller-Logik
- ui_help_de.py enthält ausschließlich Help-Content + kleine Lookup-API

Hinweis:
- Keys sind so gewählt, dass sie direkt mit `active["value"]` (Global/Setup/Extract/Transform/Load/Overview)
  und `transform_tab_state["value"]` (Join/Mapping/Non-Empty/Duplicate) funktionieren.
"""

from __future__ import annotations

from typing import Dict, Optional


# ----------------------------
# Öffentliche API
# ----------------------------
def get_help_markdown_de(active_section: str, transform_tab: Optional[str] = None) -> str:
    """
    Liefert den passenden Markdown-Hilfetext für den aktuellen UI-Kontext.

    Args:
        active_section: z. B. "Global", "Setup", "Extract", "Transform", "Load", "Overview"
        transform_tab:  z. B. "Join", "Mapping", "Non-Empty", "Duplicate" (nur relevant bei active_section="Transform")
    """
    section = (active_section or "Global").strip()

    if section == "Transform":
        tab = (transform_tab or "Join").strip()
        key = f"Transform/{tab}"
        return HELP_TEXT_MD_DE.get(key) or HELP_TEXT_MD_DE.get("Transform") or DEFAULT_HELP_MD_DE

    return HELP_TEXT_MD_DE.get(section) or DEFAULT_HELP_MD_DE


def get_help_title_de(active_section: str, transform_tab: Optional[str] = None) -> str:
    """Kurzer Titel (z. B. für Dialog-Header)."""
    section = (active_section or "Global").strip()
    if section == "Transform":
        tab = (transform_tab or "Join").strip()
        return f"Hilfe – Transform → {tab}"
    return f"Hilfe – {section}"


# ----------------------------
# Inhalte (DE)
# ----------------------------
DEFAULT_HELP_MD_DE = """## Hilfe

Für diesen Bereich ist noch kein Hilfetext hinterlegt.

**Tipp:** Falls du mir kurz sagst, *was* genau du hier erklären willst (Zielgruppe, Workflow, typische Fehler),
kann ich den Text präzise ergänzen.
"""


HELP_TEXT_MD_DE: Dict[str, str] = {
    "Global": """## Global

Hier steuerst du die UI selbst und das Speichern/Zurücksetzen.

- **Save**: schreibt deine Änderungen in die lokale Konfiguration (Delta zur Default-Konfiguration).
- **Reset**: setzt die lokale Konfiguration auf Default zurück (mit Bestätigung).
- **Dark mode**: UI-Darstellung umschalten.

**Typische Stolpersteine**

- Änderungen sind erst nach einer Eingabe „aktiv“ (Save wird dann erst relevant).
- Bei „komischem“ UI-Verhalten: einmal speichern, Seite neu laden, erneut prüfen.

**Konvention**

- Pfade (z. B. `etl_directory`) sind relativ zum Arbeitsverzeichnis gedacht.
""",

    "Setup": """## Setup

Grundkonfiguration: *Welche Projekte? Welche Adapter? Welche Zusatzlisten?*

##### Data Source Adapter
Wähle den Quell-Adapter (z. B. SAP/ODBC/Proalpha). Das bestimmt u. a.:

- welche Tabellen/Objekte als Default vorgeschlagen werden,
- welche Adapter-spezifischen Parameter im Bereich **Extract** sichtbar sind.

##### Target Adapter
Wähle den Ziel-Adapter für den Load-Schritt.

##### Project Status File (optional)
- Importiert Projekte aus einer Excel-Statusdatei (wenn vorhanden).
- Praktisch zum initialen Befüllen – danach wird oft direkt in der UI gepflegt.

##### Projects
- Projekte/Objekte sind die „Arbeitsmenge“ für Extract/Transform/Load.
- **Select All / Select None** hilft beim schnellen Start.

##### Multi-Project Lists
- **Feature assignment keys**: komma-separiert (z. B. `key1, key2`).
- **Text keys**: komma-separiert (z. B. `de, en`).

**Typische Stolpersteine**

- Leere Key-Listen sollten entfernt werden (nicht als `[]` stehen lassen), um Folgefehler zu vermeiden.
""",

    "Extract": """## Extract

Steuert die Datenbeschaffung (DB oder Dateien) und die Eingangsparameter.

##### General Extract Settings
- **Extract active**: Extraktion komplett an/aus.
- **Load to Nemo**: lädt Extrakte zusätzlich nach Nemo hoch (für Analyse/Transparenz).
- **Delete temp files**: räumt temporäre Dateien nach Nutzung auf.
- **Nemo project prefix**: Prefix für Extrakt-Tabellen (z. B. `MME...`).

**Prefix-Konzept (empfohlen, konsistent halten)**

- `MME...` = *MigMan Extract* (Roh-Extrakte)
- `MMT...` = *MigMan Transform* (Zwischenergebnisse aus Transform-Schritten)
- `MML...` = *MigMan Load* (finale Load-/Exporttabellen, relevant für Proalpha-Import)

##### Extract method
- `database`: direkte Extraktion aus der Quelle (z. B. SAP/ODBC).
- `file`: Import aus CSV Dateien – sinnvoll, wenn nur Exporte bereitgestellt werden.

##### Tables
- Tabellen/Objekte auswählen, die extrahiert werden sollen.
- **Add custom table**: fügt eine Tabelle hinzu, die nicht in der Default-Liste steht.

##### Extract from folder
- Pfad zur Datei-Quelle (insbesondere bei `file`).
- Die UI zeigt eine kurze Plausibilitätsprüfung (existiert? CSV-Anzahl?).

##### Quick Setup (bei Extract method = file)
- kann automatisch File-Configs für die im Adapter hinterlegten Tabellen erzeugen.

##### File Configuration
- Importparameter pro Datei (Separator, Encoding, Header, Spalten, …).
- Ziel ist: robuste, reproduzierbare Dateieinlese ohne manuelle Nacharbeit.

**Typische Stolpersteine**

- Wenn du Tabellen/Configs ergänzt, aber die UI nicht sofort aktualisiert: einmal in einen anderen Tab wechseln und zurück.
- Trennzeichen/Encoding müssen zu den gelieferten Dateien passen (sonst „schiefe“ Spalten).
""",

    "Transform": """## Transform

Bearbeitet/normalisiert die extrahierten Daten.

Untertabs:
- **Join**: Datenmodell herstellen (SQL-Join-Statements).
- **Mapping**: Zuordnungen (z. B. Umcodierungen, Normalisierung).
- **Non-Empty**: Pflichtfelder/Validierungsregeln.
- **Duplicate**: Dublettenprüfung (Fuzzy-Logik / Matching).

Die Hilfe im „?“ passt sich automatisch an den aktiven Transform-Tab an.
""",

    "Transform/Join": """## Transform → Join

Hier wird das Datenmodell erzeugt (typischerweise via SQL).

**Wofür?**
- Aus mehreren Quelltabellen wird eine Zielstruktur gebaut, die später für Analyse/Load genutzt wird.

**Workflow**

1. Projekt/Objekt auswählen (z. B. Suppliers).
2. **Customize** erzeugt/öffnet das Join-SQL für das Objekt.
3. SQL im Editor anpassen (Feldnamen, Joins, Filter).
4. Transfer ausführen und Ergebnisse prüfen.

**Typische Stolpersteine**

- Join-Schlüssel fehlen / sind nicht eindeutig → führt zu Duplikaten oder fehlenden Datensätzen.
- Ein Feld wird in Duplicate/Non-Empty referenziert, ist aber im Join nicht vorhanden → späterer Lauf bricht.
- Groß-/Kleinschreibung kann relevant sein (insb. bei Feld-/Attributnamen in nachfolgenden Schritten).

**Tipp**

- Erst Join stabilisieren, danach Mapping/Non-Empty/Duplicate aktivieren.
""",

    "Transform/Mapping": """## Transform → Mapping

Mapping dient zur Normalisierung/Umcodierung von Werten und zur Feldzuordnung.

**Typische Anwendungsfälle**

- Nummernkreise anpassen (z. B. führende Stellen entfernen/setzen).
- Codes/Schlüssel umsetzen (z. B. CASE-Logik nicht im Join, sondern als Mapping).
- Synonyme/Alternative Feldnamen zulassen (je nach UI-Ausprägung).

**Wichtig**
- Feld-/Attributnamen sind häufig **case-sensitiv**: exakt so schreiben, wie sie im Datenmodell heißen.

**Typische Stolpersteine**

- Nach „Add“ aktualisiert sich die Ansicht nicht sofort → kurz in einen anderen Tab wechseln und zurück.
- CSV-/Mapping-Dateien nicht sauber formatiert (Delimiter/Quotes) → führt zu falschen Zuordnungen.

**Tipp**

- Mapping möglichst *zentral* halten (nicht in Join-SQL „verstecken“), damit es wiederverwendbar bleibt.
""",

    "Transform/Non-Empty": """## Transform → Non-Empty

Regeln für Pflichtfelder / Nicht-Leer-Werte.

**Wofür?**

- Datenqualität: Felder, die für den Load zwingend gefüllt sein müssen, werden geprüft.
- Hilft, Fehler früh sichtbar zu machen (bevor du in Proalpha/MigMan importierst).

**Typische Stolpersteine**

- Zu viele Pflichtfelder auf einmal → viele Fehler, wenig Fokus.
- Pflichtfelder referenzieren Felder, die im Join nicht erzeugt wurden.

**Tipp**

- Starte mit wenigen Kern-Pflichtfeldern und erweitere iterativ.
""",

    "Transform/Duplicate": """## Transform → Duplicate

Dublettenprüfung pro Objekt (z. B. Customers/Suppliers/Prospects).

**Kernkonzept**

- Pro Objekt definierst du, welche Felder in den Vergleich einfließen.
- Ein **Similarity Threshold** steuert, ab wann Datensätze als „ähnlich“ gelten.

**Add custom field**

- Fügt ein zusätzliches Feld in die Vergleichsliste ein (für Matching/Tokenisierung).
- Feldnamen exakt (inkl. Groß-/Kleinschreibung) wie im Modell angeben.

**Typische Stolpersteine**

- Feld in Duplicate konfiguriert, aber im Join nicht vorhanden → Lauf bricht.
- UI-Refresh nach Hinzufügen/Löschen: falls nicht sichtbar, kurz Tab wechseln und zurück.
- Performance: zu viele Felder/zu niedriger Threshold kann Laufzeit stark erhöhen.

**Tipp**

- Schlank starten (wenige, stabile Felder) und schrittweise erweitern.
""",

    "Load": """## Load

Steuert die Ausgabe/Beladung ins Zielsystem.

**Wofür?**

- Erzeugt die finalen Load-Projekte/Exportdaten (für Proalpha/MigMan).
- Typisch ist hier der Prefix `MML...` (*MigMan Load*), also „die“ Tabelle, die du am Ende für den Import brauchst.
- Optionale Features wie „Delete projects before load“ helfen beim sauberen Neu-Lauf.

**Typische Stolpersteine**

- Reihenfolge/Abhängigkeiten: Stammdaten vor Bewegungsdaten.
- Felder/Datentypen passen nicht zu Import-Templates → vorher mit Testlauf prüfen.

**Tipp**

- Für erste Iterationen möglichst wenige Objekte aktivieren und sauber durchtesten.
""",

    "Overview": """## Overview

Übersicht über die aktuellen Konfigurations-Deltas.

**Wofür?**

- Schneller „Sanity Check“, was du gegenüber der Default-Konfiguration geändert hast.
- Hilft beim Debugging: „Warum läuft es anders als vorher?“

**Tipp**

- Wenn etwas unerwartet ist: Overview öffnen, Änderungen prüfen, dann gezielt zurückdrehen.
""",
}

# -------------------- Tooltips --------------------
TOOLTIP_TEXT_DE = {
    "setup.source_adapter": "Wähle den Quell-Adapter für die Extraktion (z. B. PROALPHA, INFOR, ODBC).",
    "setup.project_status_file": "Pfad zu einer Excel-Datei, aus der Projekte importiert/verwaltet werden können.",
    "setup.mult_project_list_feature_assignments": "Komma-separierte Schlüssel für Feature-Zuordnungen (z. B. key1, key2).",
    "setup.mult_project_list_text": "Komma-separierte Schlüssel für Text-Projekte (z. B. text1, text2).",
    "extract.quick_setup.create_file_configs": "Erzeugt automatisch File-Configs für alle Tabellen des ausgewählten Adapters (CSV-Pfade basieren auf 'Extract from folder').",
    "extract.chunk_size": "Anzahl Datensätze pro Batch beim Extrahieren (Performance/Memory-Tuning).",
    "extract.timeout": "Timeout in Sekunden für DB-Abfragen/Verbindungen im Extract.",
    "extract.table_prefix": "Optionaler Präfix für Tabellennamen (z. B. schema oder Mandant).",
    "extract.table_selector": "Filter/Selektor für Tabellen (z. B. Pattern oder Auswahl je nach Adapter).",
    "extract.add_custom_table": "Eigene Tabellen ergänzen, die nicht in der Standardliste enthalten sind.",
    "extract.add_custom_table_apply": "Fügt die eingegebene Tabelle zur Auswahl hinzu.",
    "transform.general.active": "Aktiviert/Deaktiviert die gesamte Transform-Phase.",
    "transform.general.load_to_nemo": "Wenn aktiv, werden Transform-Ergebnisse für den Nemo-Import vorbereitet.",
    "transform.general.delete_temp_files": "Löscht temporäre Dateien nach erfolgreichem Lauf.",
    "transform.general.dump_files": "Schreibt Debug-/Dump-Dateien zur Analyse (kann Speicher/Platz benötigen).",
    "transform.general.nemo_project_prefix": "Projektpräfix für Nemo-Projekte in der Transform-Phase.",
    "transform.join.active": "Aktiviert/Deaktiviert die Join-Transformationen.",
    "transform.join.customize_project": "Öffnet die projektspezifische Join-Konfiguration (überschreibt Defaults für dieses Projekt).",
    "transform.mapping.new_field_name": "Ziel-Feldname für ein neues Field-Mapping (wird in die Mapping-Konfiguration geschrieben).",
    "transform.nonempty.active": "Entfernt leere/NULL-Spalten während der Transformation.",
    "transform.duplicate.active": "Aktiviert/Deaktiviert die Dubletten-Erkennung im Transform-Schritt.",
    "transform.duplicate.object_active": "Aktiviert/Deaktiviert Dubletten-Erkennung für dieses Objekt (z. B. Customers).",
    "transform.duplicate.primary_key": "Primärschlüssel-Feld für dieses Objekt (eindeutige Identifikation).",
    "transform.duplicate.add_custom_field": "Fügt zusätzliche Felder zur Dublettenprüfung hinzu (mehrere Werte per Komma möglich).",
    "transform.duplicate.add_custom_field_apply": "Übernimmt die Eingabe und ergänzt die Felderliste.",
    "load.active": "Aktiviert/Deaktiviert die Load-Phase (Import nach Nemo).",
    "load.delete_temp_files": "Löscht temporäre Dateien nach dem Load.",
    "load.delete_projects_before_load": "Löscht bestehende Projekte vor dem Import (vorsichtig verwenden).",
    "load.nemo_project_prefix": "Projektpräfix für Nemo-Projekte im Load (Standard: mme).",
}

def get_tooltip_de(key: str, default: str = "") -> str:
    return TOOLTIP_TEXT_DE.get(key, default)


# --- Tooltip additions (auto) ---
TOOLTIP_TEXT_DE.update({
    "global.etl_directory": "Pfad zum ETL-Arbeitsverzeichnis (Basisordner für lokale ETL-Dateien/Configs).",
    "setup.target_adapter": "Wähle den Ziel-Adapter für den Load (z. B. PROALPHA_MIGMAN oder NEMO_BUSINESS_PROCESSES).",
    "extract.general.active": "Aktiviert/Deaktiviert die gesamte Extract-Phase.",
    "extract.general.load_to_nemo": "Wenn aktiv, werden Extract-Ergebnisse für den Nemo-Import vorbereitet/weitergereicht.",
    "extract.general.delete_temp_files": "Löscht temporäre Dateien nach dem Extract (sofern erzeugt).",
    "extract.general.method": "Extraktionsmethode: database = direkte DB-Extraktion, file = nur File-Import (z. B. aus CSVs).",
    "transform.mapping.active": "Aktiviert/Deaktiviert das Mapping (Field Mappings + Transformationsregeln).",
})
