"""Recipes module for managing recipes."""
