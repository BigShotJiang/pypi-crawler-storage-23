"""Entry point for PyInstaller binary build."""

from vibe_clock.cli import cli

if __name__ == "__main__":
    cli()
