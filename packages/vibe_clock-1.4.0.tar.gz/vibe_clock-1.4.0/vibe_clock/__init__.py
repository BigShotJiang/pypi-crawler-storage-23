"""vibe-clock: Track AI coding agent usage."""

from importlib.metadata import version as _v

__version__ = _v("vibe-clock")
