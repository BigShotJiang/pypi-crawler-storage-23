"""Module entrypoint for ``python -m planpilot.cli``."""

from planpilot.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
