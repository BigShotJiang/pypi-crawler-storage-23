---
description: Create a Technical Specification from a PRD
allowed-tools: [Read, Glob, Grep, Write, Bash]
---

Use the Skill tool to invoke the `planpilot:create-tech-spec` skill, then follow its workflow exactly.
