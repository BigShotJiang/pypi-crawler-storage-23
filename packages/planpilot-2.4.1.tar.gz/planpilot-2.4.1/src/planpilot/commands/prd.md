---
description: Create a Product Requirements Document from a feature idea
allowed-tools: [Read, Glob, Grep, Write]
---

Use the Skill tool to invoke the `planpilot:create-prd` skill, then follow its workflow exactly.
