---
description: Convert PRD/spec/roadmap to .plans JSON and sync to GitHub Issues + Projects v2
allowed-tools: [Read, Glob, Grep, Write, Bash]
---

Use the Skill tool to invoke the `planpilot:plan-sync` skill, then follow its workflow exactly.
