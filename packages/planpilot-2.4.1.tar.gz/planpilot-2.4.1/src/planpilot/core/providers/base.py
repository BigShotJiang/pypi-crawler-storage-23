"""Provider module base types."""

from __future__ import annotations


class ProviderContext:
    """Base class for provider-specific resolved state."""

    pass
