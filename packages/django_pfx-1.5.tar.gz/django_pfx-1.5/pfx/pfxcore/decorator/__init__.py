from .rest import rest_api, rest_doc, rest_property, rest_view
