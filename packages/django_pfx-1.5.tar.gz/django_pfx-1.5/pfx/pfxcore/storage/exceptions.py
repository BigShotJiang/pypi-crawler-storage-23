
class StorageException(Exception):
    pass
