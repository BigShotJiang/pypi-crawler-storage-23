import importlib.metadata
from typing import Awaitable
from .quent import Chain, Cascade, ChainAttr, CascadeAttr, run, QuentException
from .quent import PyNull as Null
from .quent import _FrozenChain as FrozenChain

__version__ = importlib.metadata.version("quent")

type ResultOrAwaitable[T] = T | Awaitable[T]


__all__ = [
  'Chain', 'Cascade', 'ChainAttr', 'CascadeAttr', 'QuentException', 'run', 'ResultOrAwaitable', 'Null',
  'FrozenChain', '__version__'
]
