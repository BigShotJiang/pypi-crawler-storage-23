from django.apps import AppConfig


class ArchesSearchConfig(AppConfig):
    name = "arches_search"
    is_arches_application = True
