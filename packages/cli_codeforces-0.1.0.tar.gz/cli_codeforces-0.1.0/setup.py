from pathlib import Path

from setuptools import find_packages, setup


README_PATH = Path(__file__).parent / "README.md"


setup(
    name="cli-codeforces",
    version="0.1.0",
    description="Codeforces CLI automation tool built with Typer, Rich, and Playwright.",
    long_description=README_PATH.read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    author="Nigam Vaghani",
    url="https://github.com/Nigam-Vaghani/codeforces_cli",
    project_urls={
        "Source": "https://github.com/Nigam-Vaghani/codeforces_cli",
        "Issues": "https://github.com/Nigam-Vaghani/codeforces_cli/issues",
    },
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.10",
    install_requires=[
        "typer>=0.9.0",
        "rich>=13.0.0",
        "requests>=2.31.0",
        "beautifulsoup4>=4.12.0",
        "cloudscraper>=1.2.71",
        "playwright>=1.40.0",
    ],
    entry_points={
        "console_scripts": [
            "cf_cli=codeforces_cli.main:app",
            "cf=codeforces_cli.main:app",
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
        "Environment :: Console",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)