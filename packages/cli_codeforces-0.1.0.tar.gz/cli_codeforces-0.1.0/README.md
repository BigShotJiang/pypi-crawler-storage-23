# cf_cli

Codeforces CLI automation tool built with Typer, Rich, and Playwright.

## Install (Public)

After this package is published to PyPI:

```powershell
pip install cli-codeforces
playwright install chromium
```

Then use:

```powershell
cf --help
```

## Browser-Based Login Workflow

This project uses a real Playwright Chromium browser with a persistent profile at `.cf_browser_profile`.
No manual cookie storage and no requests-based login are used for auth.

### One-time setup

```powershell
.\cli_env\Scripts\python -m pip install -r requirement.txt
.\cli_env\Scripts\python -m playwright install chromium
```

### Login

```powershell
cf_cli login
```

- CLI opens a real Chromium window.
- Log in manually (solve CAPTCHA if shown).
- On success, CLI prints: `Login successful. Session stored.`
- Session is preserved via `.cf_browser_profile`.
