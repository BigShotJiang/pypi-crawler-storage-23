import typer
from rich.console import Console

from codeforces_cli.services.contest_registration_service import register_for_contest


def register(
    contest_id: int = typer.Argument(..., help="Codeforces contest ID. Example: 2197"),
):
    """
    Register for an upcoming contest if registration is currently open.

    Example:
      cf_cli register 2197
    """
    console = Console()

    try:
        result = register_for_contest(contest_id)
    except Exception as error:
        console.print(f"[bold red]Error:[/bold red] {error}")
        raise typer.Exit(code=1)

    if result["already_registered"]:
        console.print(f"[bold yellow]Already registered[/bold yellow] for contest {contest_id}.")
        return

    console.print(f"[bold green]Registration successful[/bold green] for contest {contest_id}.")
