import typer
from rich.console import Console
from rich.table import Table

from codeforces_cli.services.user_service import get_user_rating


def rating(
    handle: str = typer.Argument(..., help="Codeforces handle. Example: tourist"),
):
    """
    Show a user's current and max rating.

    Example:
      cf_cli rating tourist
    """
    console = Console()

    try:
        user = get_user_rating(handle)
    except Exception as error:
        console.print(f"[bold red]Error:[/bold red] {error}")
        raise typer.Exit(code=1)

    table = Table(title=f"Rating for {user['handle']}")
    table.add_column("Handle", style="green")
    table.add_column("Current Rating", justify="right", style="cyan")
    table.add_column("Current Rank", style="magenta")
    table.add_column("Max Rating", justify="right", style="yellow")
    table.add_column("Max Rank", style="magenta")

    table.add_row(
        str(user["handle"]),
        str(user["rating"]),
        str(user["rank"]),
        str(user["max_rating"]),
        str(user["max_rank"]),
    )

    console.print(table)
