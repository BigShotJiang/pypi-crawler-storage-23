import typer

def hello():
    """Show a welcome message."""
    typer.echo("Welcome to Codeforces CLI 🚀")
