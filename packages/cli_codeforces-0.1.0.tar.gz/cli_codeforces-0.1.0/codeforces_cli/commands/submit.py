import typer
from rich.console import Console

from codeforces_cli.services.submit_service import NotLoggedInError, run_submission_workflow

console = Console()


def submit(
    contest_id: int = typer.Argument(..., help="Contest ID"),
    problem_index: str = typer.Argument(..., help="Problem index (A, B, C1...)"),
):
    """
    Submit local solution file and stream verdict updates.
    """

    last_status = None
    final_verdict = None

    try:
        for event in run_submission_workflow(contest_id, problem_index):
            event_type = event["event"]

            if event_type == "submitted":
                console.print(f"[bold cyan]Submitted[/bold cyan] {event['file_path']}")
                console.print(f"Submission ID: {event['submission_id']}")
                continue

            if event_type == "status":
                status_text = f"{event['verdict']}|{event['passed_test_count']}"
                if status_text == last_status:
                    continue
                last_status = status_text
                console.print(
                    f"Status: {event['verdict']} | "
                    f"Passed: {event['passed_test_count']}"
                )
                continue

            if event_type == "final":
                final_verdict = event["verdict"]

        if final_verdict:
            style = "green" if final_verdict == "OK" else "red"
            console.print(f"[bold {style}]Final Verdict: {final_verdict}[/bold {style}]")

    except NotLoggedInError as error:
        console.print(f"[bold red]{error}[/bold red]")
        raise typer.Exit(code=1)
    except Exception as error:
        console.print(f"[bold red]Submission failed:[/bold red] {error}")
        raise typer.Exit(code=1)
