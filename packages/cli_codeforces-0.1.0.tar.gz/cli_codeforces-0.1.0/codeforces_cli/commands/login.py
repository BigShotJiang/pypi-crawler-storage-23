import typer
from rich.console import Console

from codeforces_cli.services.auth_service import login_and_persist


def login():
    """
    Login to Codeforces in a real browser and persist session profile.
    """

    console = Console()

    console.print("[bold cyan]Opening browser for Codeforces login...[/bold cyan]")
    console.print("Complete login (and CAPTCHA if shown) in the opened browser window.")

    try:
        login_and_persist()
    except Exception as error:
        console.print(f"[bold red]Login failed:[/bold red] {error}")
        raise typer.Exit(code=1)

    console.print("[bold green]Login successful. Session stored.[/bold green]")
