import typer
from rich.console import Console
from rich.table import Table

from codeforces_cli.config.store import get_session
from codeforces_cli.services.auth_service import get_logged_in_handle
from codeforces_cli.services.contest_status_service import get_contest_status


def status(
    contest_id: int = typer.Argument(..., help="Codeforces contest ID. Example: 2197"),
    handle: str | None = typer.Option(
        None,
        "--handle",
        "-u",
        help="Codeforces handle override. If omitted, currently logged-in handle is used.",
    ),
):
    """
    Show your registration and performance status for a contest.

    Example:
      cf_cli status 2197
            cf_cli status 2197 --handle nigamvaghani007
    """
    console = Console()

    try:
        if handle:
            resolved_handle = handle.strip()
        else:
            try:
                resolved_handle = get_logged_in_handle()
            except Exception:
                saved_handle, _ = get_session()
                if not saved_handle:
                    raise Exception("Could not detect account. Run cf_cli login again or pass --handle.")
                resolved_handle = saved_handle

        contest_status = get_contest_status(contest_id, resolved_handle)
    except Exception as error:
        console.print(f"[bold red]Error:[/bold red] {error}")
        raise typer.Exit(code=1)

    table = Table(title=f"Contest Status - {contest_status['contest_name']} ({contest_status['contest_id']})")
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="green")

    rating_delta = contest_status["rating_delta"]
    rating_delta_text = "N/A"
    if isinstance(rating_delta, int):
        rating_delta_text = f"+{rating_delta}" if rating_delta > 0 else str(rating_delta)

    table.add_row("Handle", resolved_handle)
    table.add_row("Phase", str(contest_status["phase"]))
    table.add_row("Started At", str(contest_status["started_at"]))
    table.add_row("Registered", "Yes" if contest_status["registered"] else "No")
    table.add_row("Registration Open", "Yes" if contest_status["registration_open"] else "No")
    table.add_row("Solved", str(contest_status["solved"]))
    table.add_row("Rank", str(contest_status["rank"]))
    table.add_row("Points", str(contest_status["points"]))
    table.add_row("Penalty", str(contest_status["penalty"]))
    table.add_row("Rating Delta", rating_delta_text)

    console.print(table)
