from datetime import datetime

import typer
from rich.console import Console
from rich.table import Table

from codeforces_cli.services.user_service import get_user_rating_history


def rating_history(
    handle: str = typer.Argument(..., help="Codeforces handle. Example: nigamvaghani007"),
):
    """
    Show contest-by-contest rating progression for a user.

    Example:
      cf_cli rating-history nigamvaghani007
    """
    console = Console()

    try:
        history = get_user_rating_history(handle)
    except Exception as error:
        console.print(f"[bold red]Error:[/bold red] {error}")
        raise typer.Exit(code=1)

    if not history:
        console.print("[bold yellow]No rating history found for this handle.[/bold yellow]")
        raise typer.Exit(code=0)

    table = Table(title=f"Rating Progression - {handle}")
    table.add_column("#", justify="right", style="cyan")
    table.add_column("Contest", style="green")
    table.add_column("Rank", justify="right")
    table.add_column("Change", justify="right")
    table.add_column("Rating", justify="right", style="magenta")
    table.add_column("Date", justify="center")

    for index, item in enumerate(history, start=1):
        timestamp = item["timestamp"]
        date_text = "N/A"
        if isinstance(timestamp, int):
            date_text = datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d")

        table.add_row(
            str(index),
            str(item["contest_name"]),
            str(item["rank"]),
            str(item["delta"]),
            f"{item['old_rating']} → {item['new_rating']}",
            date_text,
        )

    console.print(table)
