from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
BROWSER_PROFILE_DIR = PROJECT_ROOT / ".cf_browser_profile"
CODEFORCES_BASE_URL = "https://codeforces.com"
LOGIN_URL = f"{CODEFORCES_BASE_URL}/enter"


def ensure_browser_profile_dir() -> Path:
    BROWSER_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    return BROWSER_PROFILE_DIR
