"""Configuration utilities for Codeforces CLI."""
