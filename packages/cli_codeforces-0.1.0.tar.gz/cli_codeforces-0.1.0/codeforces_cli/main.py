import typer
from codeforces_cli.commands.hello import hello
from codeforces_cli.commands.contest import contest
from codeforces_cli.commands.problems import problems
from codeforces_cli.commands.open_problem import open as open_problem
from codeforces_cli.commands.create_file import create
from codeforces_cli.commands.open_file import open_file
from codeforces_cli.commands.login import login
from codeforces_cli.commands.standing import standing
from codeforces_cli.commands.rating import rating
from codeforces_cli.commands.rating_history import rating_history
from codeforces_cli.commands.register import register
from codeforces_cli.commands.status import status

app = typer.Typer(
    help="Codeforces CLI - Manage contests from terminal 🚀",
    no_args_is_help=True,
)

app.command()(hello)
app.command()(contest)
app.command()(problems)
app.command()(open_problem)
app.command(name="create")(create)
app.command(name="open-file")(open_file)
app.command(name="login")(login)
app.command(name="standing")(standing)
app.command(name="rating")(rating)
app.command(name="rating-history")(rating_history)
app.command(name="register")(register)
app.command(name="status")(status)

@app.callback()
def main():
    """Codeforces CLI entrypoint."""


if __name__ == "__main__":
    app()