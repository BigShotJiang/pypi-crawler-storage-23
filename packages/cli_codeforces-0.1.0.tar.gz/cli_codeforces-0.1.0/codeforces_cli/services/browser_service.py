from contextlib import contextmanager
from typing import Iterator

from playwright.sync_api import BrowserContext, sync_playwright

from codeforces_cli.config.settings import ensure_browser_profile_dir


@contextmanager
def persistent_browser_context(headless: bool = False) -> Iterator[BrowserContext]:
    user_data_dir = ensure_browser_profile_dir()

    with sync_playwright() as playwright:
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=str(user_data_dir),
            headless=headless,
        )
        try:
            yield context
        finally:
            context.close()
