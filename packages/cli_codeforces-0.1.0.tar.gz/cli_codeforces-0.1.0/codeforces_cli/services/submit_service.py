from pathlib import Path

from codeforces_cli.services.browser_service import persistent_browser_context


CODEFORCES_BASE_URL = "https://codeforces.com"
SUPPORTED_EXTENSIONS = (".cpp", ".py", ".java", ".c")
PENDING_VERDICTS = {"in queue", "running", "testing"}
LANGUAGE_PREFERENCES = {
    ".cpp": ["GNU G++20", "GNU G++17", "GNU C++20", "GNU C++17", "GNU C++"],
    ".py": ["PyPy 3", "Python 3", "PyPy3"],
    ".java": ["Java 21", "Java 17", "Java 11", "Java"],
    ".c": ["GNU C11", "GNU C"],
}


class NotLoggedInError(Exception):
    pass


def _unique(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def detect_solution_file(contest_id: int, problem_index: str) -> tuple[Path, str]:
    cwd = Path.cwd()
    index_candidates = _unique([problem_index, problem_index.upper()])

    for extension in SUPPORTED_EXTENSIONS:
        for index in index_candidates:
            root_path = cwd / str(contest_id) / f"{index}{extension}"
            if root_path.exists() and root_path.is_file():
                return root_path, extension

            contest_path = cwd / f"{index}{extension}"
            if contest_path.exists() and contest_path.is_file():
                return contest_path, extension

    raise Exception("Solution file not found.")


def _select_problem_index(page, problem_index: str) -> None:
    options = page.locator('select[name="submittedProblemIndex"] option').evaluate_all(
        "els => els.map(e => ({ value: e.value, label: (e.textContent || '').trim() }))"
    )

    target = problem_index.upper()
    selected = None
    for option in options:
        value = option["value"].strip()
        label = option["label"].strip()
        if value.upper() == target or label.upper() == target:
            selected = option
            break

    if not selected:
        raise Exception(f"Problem index '{problem_index}' is not available in submit form.")

    page.select_option('select[name="submittedProblemIndex"]', value=selected["value"])


def _select_language(page, extension: str) -> str:
    options = page.locator('select[name="programTypeId"] option').evaluate_all(
        "els => els.map(e => ({ value: e.value, label: (e.textContent || '').trim() }))"
    )
    preferences = LANGUAGE_PREFERENCES.get(extension)

    if not preferences:
        raise Exception(f"Unsupported language extension '{extension}'.")

    selected = None
    for preference in preferences:
        normalized_preference = preference.lower()
        for option in options:
            label = option["label"].strip()
            if normalized_preference in label.lower():
                selected = option
                break
        if selected:
            break

    if not selected:
        raise Exception(f"Could not match a language in submit form for '{extension}'.")

    page.select_option('select[name="programTypeId"]', value=selected["value"])
    return selected["label"]


def _extract_submission_snapshot(page, submission_id: str | None) -> dict[str, str] | None:
    if submission_id:
        row = page.locator(f'tr[data-submission-id="{submission_id}"]')
    else:
        row = page.locator("tr[data-submission-id]").first

    if row.count() == 0:
        return None

    resolved_submission_id = row.get_attribute("data-submission-id")
    if not resolved_submission_id:
        return None

    verdict_cell = row.locator("span.submissionVerdictWrapper").first
    passed_cell = row.locator("td.passedTestCount").first

    verdict = verdict_cell.inner_text().strip() if verdict_cell.count() else "UNKNOWN"
    passed = passed_cell.inner_text().strip() if passed_cell.count() else "0"

    return {
        "submission_id": resolved_submission_id,
        "verdict": verdict,
        "passed_test_count": passed,
    }


def run_submission_workflow(contest_id: int, problem_index: str):
    file_path, extension = detect_solution_file(contest_id, problem_index)
    source_code = file_path.read_text(encoding="utf-8")
    submit_url = f"{CODEFORCES_BASE_URL}/contest/{contest_id}/submit"

    with persistent_browser_context(headless=False) as context:
        page = context.new_page()
        page.goto(submit_url, wait_until="domcontentloaded")

        if "/enter" in page.url:
            raise NotLoggedInError("Not logged in. Run cf_cli login first.")

        page.wait_for_selector('select[name="submittedProblemIndex"]', timeout=20000)
        _select_problem_index(page, problem_index)
        selected_language = _select_language(page, extension)
        page.fill('textarea[name="source"]', source_code)

        page.click('input[type="submit"]')
        page.wait_for_url(f"**/contest/{contest_id}/my**", timeout=20000)

        snapshot = _extract_submission_snapshot(page, submission_id=None)
        if not snapshot:
            raise Exception("Unable to retrieve submission status after submit.")

        submission_id = snapshot["submission_id"]
        yield {
            "event": "submitted",
            "file_path": str(file_path),
            "submission_id": submission_id,
            "language": selected_language,
        }
        yield {
            "event": "status",
            "verdict": snapshot["verdict"],
            "passed_test_count": snapshot["passed_test_count"],
        }

        while snapshot["verdict"].strip().lower() in PENDING_VERDICTS:
            page.wait_for_timeout(2000)
            page.reload(wait_until="domcontentloaded")

            if "/enter" in page.url:
                raise NotLoggedInError("Not logged in. Run cf_cli login first.")

            latest_snapshot = _extract_submission_snapshot(page, submission_id=submission_id)
            if not latest_snapshot:
                continue

            snapshot = latest_snapshot
            yield {
                "event": "status",
                "verdict": snapshot["verdict"],
                "passed_test_count": snapshot["passed_test_count"],
            }

        yield {
            "event": "final",
            "verdict": snapshot["verdict"],
            "passed_test_count": snapshot["passed_test_count"],
            "submission_id": submission_id,
        }
