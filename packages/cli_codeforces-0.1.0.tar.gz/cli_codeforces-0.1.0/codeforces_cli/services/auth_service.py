from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from urllib.parse import urlparse

from codeforces_cli.config.settings import CODEFORCES_BASE_URL, LOGIN_URL
from codeforces_cli.config.store import save_session
from codeforces_cli.services.browser_service import persistent_browser_context


def login_and_persist(timeout_seconds: int = 300) -> None:
    with persistent_browser_context(headless=False) as context:
        page = context.new_page()
        page.goto(LOGIN_URL, wait_until="domcontentloaded")

        page.goto(CODEFORCES_BASE_URL, wait_until="domcontentloaded")

        try:
            page.wait_for_selector("a.rated-user", timeout=timeout_seconds * 1000)
        except PlaywrightTimeoutError as error:
            raise Exception(
                "Login was not detected in time. Complete login in the browser and try again."
            ) from error

        handle = page.evaluate(
            """
            () => {
                if (typeof window.Codeforces !== 'undefined' && window.Codeforces?.options?.userHandle) {
                    return window.Codeforces.options.userHandle;
                }
                const candidate = document.querySelector('a[href^="/profile/"]');
                return candidate ? (candidate.textContent || '').trim() : null;
            }
            """
        )
        if handle:
            save_session(str(handle), {})


def get_logged_in_handle() -> str:
    with persistent_browser_context(headless=False) as context:
        page = context.new_page()
        page.goto(f"{CODEFORCES_BASE_URL}/profile", wait_until="domcontentloaded")

        if "/enter" in page.url:
            raise Exception("Not logged in. Run cf_cli login first.")

        parsed = urlparse(page.url)
        if "/profile/" in parsed.path:
            handle = parsed.path.split("/profile/")[-1].strip("/")
            if handle:
                return handle

        page.goto(CODEFORCES_BASE_URL, wait_until="domcontentloaded")

        handle = page.evaluate(
            """
            () => {
                if (typeof window.Codeforces !== 'undefined' && window.Codeforces?.options?.userHandle) {
                    return window.Codeforces.options.userHandle;
                }
                const candidate = document.querySelector('a[href^="/profile/"]');
                return candidate ? (candidate.textContent || '').trim() : null;
            }
            """
        )

        if not handle:
            raise Exception("Could not detect logged-in handle. Run cf_cli login again.")

        return str(handle)
