from codeforces_cli.api.client import fetch


def get_user_rating(handle: str) -> dict:
    result = fetch("user.info", {"handles": handle})
    if not result:
        raise Exception("User not found")

    user = result[0]
    return {
        "handle": user.get("handle", handle),
        "rating": user.get("rating", "N/A"),
        "max_rating": user.get("maxRating", "N/A"),
        "rank": user.get("rank", "N/A"),
        "max_rank": user.get("maxRank", "N/A"),
    }


def get_user_rating_history(handle: str) -> list[dict]:
    changes = fetch("user.rating", {"handle": handle})

    history: list[dict] = []
    for change in changes:
        old_rating = change.get("oldRating")
        new_rating = change.get("newRating")

        delta = "N/A"
        if isinstance(old_rating, int) and isinstance(new_rating, int):
            diff = new_rating - old_rating
            delta = f"+{diff}" if diff > 0 else str(diff)

        history.append(
            {
                "contest_name": change.get("contestName", "N/A"),
                "rank": change.get("rank", "N/A"),
                "delta": delta,
                "old_rating": old_rating if old_rating is not None else "N/A",
                "new_rating": new_rating if new_rating is not None else "N/A",
                "timestamp": change.get("ratingUpdateTimeSeconds"),
            }
        )

    history.sort(key=lambda item: item["timestamp"] or 0)
    return history
