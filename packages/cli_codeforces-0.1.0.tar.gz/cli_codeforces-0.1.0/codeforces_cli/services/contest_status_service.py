from datetime import datetime

from codeforces_cli.api.client import fetch
from codeforces_cli.config.settings import CODEFORCES_BASE_URL
from codeforces_cli.services.browser_service import persistent_browser_context


def _get_contest(contest_id: int) -> dict:
    contests = fetch("contest.list")
    for contest in contests:
        if contest.get("id") == contest_id:
            return contest
    raise Exception(f"Contest {contest_id} not found.")


def _get_registration_flags(contest_id: int) -> tuple[bool, bool]:
    register_url = f"{CODEFORCES_BASE_URL}/contest/{contest_id}/register"

    with persistent_browser_context(headless=False) as context:
        page = context.new_page()
        page.goto(register_url, wait_until="domcontentloaded")

        if "/enter" in page.url:
            return False, False

        body_text = page.locator("body").inner_text().lower()
        registered = "you are already registered" in body_text or "you have registered" in body_text
        registration_open = page.locator("form[action*='/register']").count() > 0

        return registered, registration_open


def _get_standing_row(contest_id: int, handle: str) -> dict | None:
    data = fetch(
        "contest.standings",
        {
            "contestId": contest_id,
            "handles": handle,
            "from": 1,
            "count": 1,
            "showUnofficial": "true",
        },
    )

    rows = data.get("rows", [])
    if not rows:
        return None

    row = rows[0]
    members = row.get("party", {}).get("members", [])
    member_handles = [member.get("handle", "").lower() for member in members]
    if handle.lower() not in member_handles:
        return None

    return row


def _get_rating_delta(handle: str, contest_id: int) -> int | None:
    changes = fetch("user.rating", {"handle": handle})
    for change in changes:
        if change.get("contestId") == contest_id:
            old_rating = change.get("oldRating")
            new_rating = change.get("newRating")
            if isinstance(old_rating, int) and isinstance(new_rating, int):
                return new_rating - old_rating
    return None


def get_contest_status(contest_id: int, handle: str) -> dict:
    contest = _get_contest(contest_id)
    phase = contest.get("phase", "N/A")

    if phase == "FINISHED":
        registered, registration_open = False, False
    else:
        try:
            registered, registration_open = _get_registration_flags(contest_id)
        except Exception:
            registered, registration_open = False, False

    status = {
        "contest_id": contest_id,
        "contest_name": contest.get("name", "N/A"),
        "phase": phase,
        "registered": registered,
        "registration_open": registration_open,
        "rank": "N/A",
        "points": "N/A",
        "penalty": "N/A",
        "solved": 0,
        "rating_delta": None,
        "started_at": "N/A",
    }

    start_ts = contest.get("startTimeSeconds")
    if isinstance(start_ts, int):
        status["started_at"] = datetime.fromtimestamp(start_ts).strftime("%Y-%m-%d %H:%M")

    try:
        row = _get_standing_row(contest_id, handle)
    except Exception:
        row = None

    if row:
        problem_results = row.get("problemResults", [])
        solved = 0
        for result in problem_results:
            points = result.get("points", 0)
            if isinstance(points, (int, float)) and points > 0:
                solved += 1

        status["rank"] = row.get("rank", "N/A")
        status["points"] = row.get("points", "N/A")
        status["penalty"] = row.get("penalty", "N/A")
        status["solved"] = solved

    if status["phase"] == "FINISHED":
        status["registered"] = row is not None
        try:
            status["rating_delta"] = _get_rating_delta(handle, contest_id)
        except Exception:
            status["rating_delta"] = None

    return status
