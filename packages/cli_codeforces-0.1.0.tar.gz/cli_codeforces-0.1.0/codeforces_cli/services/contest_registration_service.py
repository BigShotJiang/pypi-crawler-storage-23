from codeforces_cli.config.settings import CODEFORCES_BASE_URL
from codeforces_cli.services.browser_service import persistent_browser_context


def register_for_contest(contest_id: int) -> dict:
    register_url = f"{CODEFORCES_BASE_URL}/contest/{contest_id}/register"

    with persistent_browser_context(headless=False) as context:
        page = context.new_page()
        page.goto(register_url, wait_until="domcontentloaded")

        if "/enter" in page.url:
            raise Exception("Not logged in. Run cf_cli login first.")

        body_text = page.locator("body").inner_text().lower()
        if "you are already registered" in body_text or "you have registered" in body_text:
            return {
                "contest_id": contest_id,
                "registered": True,
                "already_registered": True,
                "registration_open": True,
            }

        register_form = page.locator("form[action*='/register']").first
        if register_form.count() == 0:
            raise Exception("Registration is not open right now for this contest.")

        submit_button = register_form.locator(
            "input[type='submit'], button[type='submit'], button, input[value*='Register']"
        ).first
        if submit_button.count() == 0:
            raise Exception("Registration form found, but submit button is unavailable.")

        submit_button.click()
        page.wait_for_load_state("networkidle")

        updated_text = page.locator("body").inner_text().lower()
        is_registered = (
            "you are already registered" in updated_text
            or "you have registered" in updated_text
            or "registered successfully" in updated_text
        )

        if not is_registered:
            raise Exception("Registration did not complete. Please open Codeforces and verify manually.")

        return {
            "contest_id": contest_id,
            "registered": True,
            "already_registered": False,
            "registration_open": True,
        }
