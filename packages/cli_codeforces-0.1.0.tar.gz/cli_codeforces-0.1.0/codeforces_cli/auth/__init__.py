"""Authentication and session management helpers."""
