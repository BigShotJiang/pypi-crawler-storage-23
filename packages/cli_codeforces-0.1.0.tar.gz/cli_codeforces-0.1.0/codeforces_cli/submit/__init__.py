"""Submission language and template metadata."""
