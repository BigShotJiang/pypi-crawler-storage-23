"""Utility functions for the everyrow MCP server."""

import json
from io import StringIO
from pathlib import Path
from typing import Any

import pandas as pd


def validate_csv_path(path: str) -> None:
    """Validate that a CSV file exists and is readable.

    Args:
        path: Path to the CSV file

    Raises:
        ValueError: If path is not absolute, doesn't exist, or isn't a CSV file
    """
    p = Path(path)

    if not p.is_absolute():
        raise ValueError(f"Path must be absolute: {path}")

    if not p.exists():
        raise ValueError(f"File does not exist: {path}")

    if not p.is_file():
        raise ValueError(f"Path is not a file: {path}")

    if p.suffix.lower() != ".csv":
        raise ValueError(f"File must be a CSV file: {path}")


def validate_output_path(path: str) -> None:
    """Validate that an output path is valid before processing.

    The path can be either:
    - A directory (must exist)
    - A file path ending in .csv (parent directory must exist)

    Args:
        path: Output path to validate

    Raises:
        ValueError: If path is not absolute or parent directory doesn't exist
    """
    p = Path(path)

    if not p.is_absolute():
        raise ValueError(f"Output path must be absolute: {path}")

    is_csv_file = p.suffix.lower() == ".csv"
    dir_to_check = p.parent if is_csv_file else p

    if not dir_to_check.exists():
        label = "Parent directory" if is_csv_file else "Output directory"
        raise ValueError(f"{label} does not exist: {dir_to_check}")

    if not dir_to_check.is_dir():
        label = "Parent path" if is_csv_file else "Output path"
        raise ValueError(f"{label} is not a directory: {dir_to_check}")


def validate_csv_output_path(path: str) -> None:
    """Validate that an output path is a full CSV file path.

    Unlike validate_output_path, this requires a full file path ending in .csv,
    not a directory.

    Args:
        path: Output path to validate (must be absolute and end in .csv)

    Raises:
        ValueError: If path is not absolute, doesn't end in .csv, or parent doesn't exist
    """
    p = Path(path)

    if not p.is_absolute():
        raise ValueError(f"Output path must be absolute: {path}")

    if p.suffix.lower() != ".csv":
        raise ValueError(f"Output path must end in .csv: {path}")

    if not p.parent.exists():
        raise ValueError(f"Parent directory does not exist: {p.parent}")

    if not p.parent.is_dir():
        raise ValueError(f"Parent path is not a directory: {p.parent}")


def resolve_output_path(output_path: str, input_path: str, prefix: str) -> Path:
    """Resolve the output path, generating a filename if needed.

    Args:
        output_path: The output path (directory or full file path)
        input_path: The input file path (used to generate output filename)
        prefix: Prefix to add to the generated filename (e.g., 'screened', 'ranked')

    Returns:
        Full path to the output file
    """
    out = Path(output_path)

    if out.suffix.lower() == ".csv":
        return out

    input_name = Path(input_path).stem
    return out / f"{prefix}_{input_name}.csv"


def load_data(
    *,
    data: str | list[dict[str, Any]] | None = None,
    input_csv: str | None = None,
) -> pd.DataFrame:
    """Load tabular data from inline data or a local CSV file path.

    Exactly one of ``data`` or ``input_csv`` must be provided.

    Args:
        data: Inline data — either a CSV string or a JSON array of objects
              (``list[dict]``).  When a string starting with ``[`` is passed it
              is parsed as JSON first; otherwise it is treated as CSV.
        input_csv: Absolute path to a CSV file on disk (stdio mode only).

    Returns:
        DataFrame with the loaded data.

    Raises:
        ValueError: If no source or multiple sources are provided, or if data is empty.
    """
    sources = sum(1 for s in (data, input_csv) if s is not None)
    if sources != 1:
        raise ValueError("Provide exactly one of data, input_csv.")

    if input_csv:
        return pd.read_csv(input_csv)

    # data is not None at this point
    if isinstance(data, list):
        df = pd.DataFrame(data)
        if df.empty:
            raise ValueError("data produced an empty DataFrame.")
        return df

    # str — auto-detect JSON array vs CSV
    assert isinstance(data, str)
    stripped = data.strip()
    if stripped.startswith("["):
        try:
            parsed = json.loads(stripped)
            if isinstance(parsed, list):
                df = pd.DataFrame(parsed)
                if df.empty:
                    raise ValueError("data produced an empty DataFrame.")
                return df
        except json.JSONDecodeError:
            pass  # fall through to CSV

    df = pd.read_csv(StringIO(data))
    if df.empty:
        raise ValueError("data produced an empty DataFrame.")
    return df


def save_result_to_csv(df: pd.DataFrame, path: Path) -> None:
    """Save a DataFrame to CSV.

    Args:
        df: DataFrame to save
        path: Path to save to
    """
    df.to_csv(path, index=False)
