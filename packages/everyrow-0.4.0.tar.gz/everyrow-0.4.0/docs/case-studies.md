---
title: Case Studies
description: Runnable case studies demonstrating everyrow operations on real datasets — screen, rank, dedupe, merge, and research with LLM-powered agents.
---

# Case Studies

Runnable case studies with real datasets. Each case study demonstrates an everyrow operation end-to-end with output you can inspect.

## Screen

- [Screen 10,000 Rows](/docs/case-studies/llm-powered-screening-at-scale)
- [Screen Stocks by Investment Thesis](/docs/case-studies/screen-stocks-by-investment-thesis)
- [Screen Stocks by Economic Sensitivity](/docs/case-studies/screen-stocks-by-margin-sensitivity)
- [Screen Job Listings](/docs/case-studies/screen-job-postings-by-criteria)

## Rank

- [Score Leads from Fragmented Data](/docs/case-studies/score-leads-from-fragmented-data)
- [Score Cold Leads via Web Research](/docs/case-studies/score-leads-without-crm-history)
- [Research and Rank Web Data](/docs/case-studies/research-and-rank-permit-times)

## Dedupe

- [Deduplicate CRM Records](/docs/case-studies/dedupe-crm-company-records)

## Merge

- [Merge Thousands of Records](/docs/case-studies/llm-powered-merging-at-scale)
- [Fuzzy Match Across Tables](/docs/case-studies/match-software-vendors-to-requirements)
- [Enrich Contacts with Company Data](/docs/case-studies/merge-contacts-with-company-data)
- [Deduplicate Contact Lists](/docs/case-studies/merge-overlapping-contact-lists)
- [Link Records Across Medical Datasets](/docs/case-studies/match-clinical-trials-to-papers)
- [Merge Costs and Speed](/docs/case-studies/understanding-costs-and-speed-for-merge)

## Multi-Method

- [Multi-Stage Lead Qualification](/docs/case-studies/multi-stage-lead-qualification)
- [LLM Cost vs. Accuracy](/docs/case-studies/deep-research-bench-pareto-analysis)
