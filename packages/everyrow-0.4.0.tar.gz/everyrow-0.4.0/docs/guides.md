---
title: Guides
description: Step-by-step tutorials for using everyrow to screen, rank, dedupe, merge, and research data with LLM-powered agents.
---

# Guides

Practical walkthroughs that show you how to use everyrow for common data processing tasks. Each guide covers a single operation end-to-end with working code.

## Screen

- [Filter a Dataset Intelligently](/docs/filter-dataframe-with-llm)

## Rank

- [Rank Data by External Metrics](/docs/rank-by-external-metric)

## Dedupe

- [Deduplicate Training Data](/docs/deduplicate-training-data-ml)
- [Resolve Duplicate Entities](/docs/resolve-entities-python)
- [Scale Deduplication to 20K Rows](/docs/scale-deduplication-20k-rows)

## Merge

- [Join Tables Without Shared Keys](/docs/fuzzy-join-without-keys)

## Research

- [Add a Column via Web Research](/docs/add-column-web-lookup)
- [Classify and Label Rows](/docs/classify-dataframe-rows-llm)
- [LLM-Powered Data Labeling](/docs/active-learning-llm-oracle)
