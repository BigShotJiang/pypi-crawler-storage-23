# API Reference

## show()

```{eval-rst}
.. autofunction:: visu_hlo.show
```

## write_svg()

```{eval-rst}
.. autofunction:: visu_hlo.write_svg
```

## write_dot()

```{eval-rst}
.. autofunction:: visu_hlo.write_dot
```
