from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class SecurityStatus(StrEnum):
    """
    The outcome of a security evaluation.
    """

    SAFE = "safe"  # No threats found.
    WARNING = "warning"  # Policy violation detected but execution allowed (audit mode).
    UNSAFE = "unsafe"  # Threat detected or Policy violation.


IntegrityLevel = Literal["snapshot", "strict"]


class SecurityComponent(StrEnum):
    """
    The system component that produced the result.
    """

    LANGUAGE_SCANNER = "LanguageScanner"
    CANARY_SCANNER = "CanaryScanner"
    SIGNATURE_SCANNER = "SignatureScanner"
    FIREWALL = "Firewall"
    SCANNER = "Scanner"  # Generic scanner for defaults


class SecurityResult(BaseModel):
    """
    Unified result model for all security components (Scanners & Firewall).

    Centralizes telemetry structure for both passive scanning (safe/unsafe)
    and active policy enforcement (safe/warn/unsafe).

    Attributes:
        status: The enforcement decision (SAFE, WARNING, UNSAFE).
        component: Who made the decision (e.g. 'LanguageScanner', 'Firewall').
        timestamp: UTC timestamp of the check.
        metadata: Contextual data (rule_id, latency, model_name, etc.).
    """

    status: SecurityStatus = Field(
        ..., description="The outcome of the security check."
    )
    component: SecurityComponent = Field(
        ...,
        description="The module that produced this result (e.g. 'Firewall').",
    )
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="UTC timestamp of the check.",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Contextual telemetry data.",
    )

    # Immutable instances ensure telemetry cannot be tampered with after creation
    model_config = ConfigDict(frozen=True)

    @property
    def safe(self) -> bool:
        """
        Helper for control flow.
        Returns True if execution is allowed to proceed (SAFE or WARNING).
        Returns False if execution must be stopped (UNSAFE).
        """
        return self.status != SecurityStatus.UNSAFE


class StdioOrigin(BaseModel):
    """
    The actual physical parameters of a local stdio connection.
    """

    type: Literal["stdio"]
    command: str
    args: list[str]
    model_config = ConfigDict(frozen=True)


class SSEOrigin(BaseModel):
    """
    The actual physical parameters of a remote SSE connection.
    """

    type: Literal["sse"]
    url: str
    model_config = ConfigDict(frozen=True)


TransportOrigin = Annotated[StdioOrigin | SSEOrigin, Field(discriminator="type")]
