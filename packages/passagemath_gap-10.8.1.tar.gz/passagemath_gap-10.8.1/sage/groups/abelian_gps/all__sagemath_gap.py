# sage_setup: distribution = sagemath-gap

# TODO:
# Implement group homset, conversion of generator images to morphism

from sage.groups.abelian_gps.abelian_group_morphism import AbelianGroupMorphism
