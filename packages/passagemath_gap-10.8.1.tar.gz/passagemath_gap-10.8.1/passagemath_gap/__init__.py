# sage_setup: distribution = sagemath-gap

from sage.all__sagemath_gap import *
