from typing import Any, ClassVar, Protocol

from .headers import S7AckDataHeader, S7Header


class S7Data(Protocol):
    def serialize(self) -> bytes: ...


class S7Parameter(Protocol):
    def serialize(self) -> bytes: ...


class S7Packet(Protocol):
    MESSAGE_TYPE: ClassVar
    header: S7Header | None
    parameter: Any  # S7Parameter | None
    data: Any  # S7Data | list[S7Data] | None

    def serialize_parameter(self) -> bytes: ...

    def serialize_data(self) -> bytes: ...

    @classmethod
    def parse(cls, packet: bytes) -> "S7Packet": ...


class S7Response(S7Packet):
    def create_packet(self, pdu_reference: int) -> bytes:
        parameter = self.serialize_parameter()
        data = self.serialize_data()
        header = S7AckDataHeader(
            pdu_reference=pdu_reference,
            message_type=self.MESSAGE_TYPE,
            parameter_length=len(parameter),
            data_length=len(data),
        )
        self.header = header
        return bytes(header.serialize() + parameter + data)
