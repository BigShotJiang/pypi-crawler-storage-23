import struct

from ..enums import FunctionCode, MessageType
from .packet import S7Packet


class RequestPLCStop(S7Packet):
    """
    message_type: enums.MessageType = enums.MessageType.JobRequest
    FUNCTION_CODE: bytes = struct.pack("!B", enums.FunctionCode.PLCStop)
    UNKNOWN_5B: bytes = b"\x00\x00\x00\x00\x00"
    LENGTH = b"\x09"
    SERVICE_NAME = b"P_PROGRAM"
    """

    MESSAGE_TYPE = MessageType.JobRequest

    def __init__(self) -> None:
        self.header = None
        self.parameter: bytes = b"\x29\x00\x00\x00\x00\x00\x09\x50\x5f\x50\x52\x4f\x47\x52\x41\x4d"
        self.data = None

    def serialize_parameter(self) -> bytes:
        return self.parameter

    def serialize_data(self) -> bytes:
        return b""

    @classmethod
    def parse(cls, packet: bytes) -> "RequestPLCStop":
        raise NotImplementedError("RequestPLCStop is created from constructor, not parsed from bytes")


class PIServiceRequest:
    UNKNOWN_BYTES = b"\x00\x00\x00\x00\x00\x00\xfd"

    def __init__(self, function_code: FunctionCode, parameter_block: bytes, pi_service: str) -> None:
        self.function_code = function_code
        self.parameter_block = parameter_block
        self.pi_service = pi_service

    def serialize(self) -> bytes:
        string_length = len(self.pi_service)
        parameter_block_length = len(self.parameter_block)
        function_code = struct.pack("!B", self.function_code)
        params = struct.pack(
            f"!HB{parameter_block_length}BB{string_length}s",
            parameter_block_length,
            self.parameter_block,
            string_length,
            self.pi_service.encode(),
        )
        return function_code + self.UNKNOWN_BYTES + params
