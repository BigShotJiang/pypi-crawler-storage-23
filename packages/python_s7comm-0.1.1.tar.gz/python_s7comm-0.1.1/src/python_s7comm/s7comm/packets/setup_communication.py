import struct

from ..enums import MessageType
from .packet import S7Packet


class SetupCommunicationParameter:
    PACKET_STRUCT = struct.Struct("!BBHHH")
    FUNCTION_CODE = 0xF0

    def __init__(self, max_amq_caller_ack: int = 0x0001, max_amq_callee_ack: int = 0x0001, pdu_length: int = 0x01E0):
        self.function_code: int = self.FUNCTION_CODE
        self.reserved: int = 0x00
        self.max_amq_caller_ack: int = max_amq_caller_ack
        self.max_amq_callee_ack: int = max_amq_callee_ack
        self.pdu_length: int = pdu_length

    @classmethod
    def parse(cls, packet: bytes) -> "SetupCommunicationParameter":
        function_code, _, max_amq_caller_ack, max_amq_callee_ack, pdu_length = cls.PACKET_STRUCT.unpack_from(packet, 0)
        if function_code != cls.FUNCTION_CODE:
            raise ValueError(f"Invalid function code. receive: {function_code}, expected: {cls.FUNCTION_CODE}")
        return cls(max_amq_caller_ack=max_amq_caller_ack, max_amq_callee_ack=max_amq_callee_ack, pdu_length=pdu_length)

    def serialize(self) -> bytes:
        return self.PACKET_STRUCT.pack(
            self.FUNCTION_CODE,
            self.reserved,
            self.max_amq_caller_ack,
            self.max_amq_callee_ack,
            self.pdu_length,
        )


class SetupCommunicationRequest(S7Packet):
    MESSAGE_TYPE = MessageType.JobRequest

    def __init__(self, parameter: SetupCommunicationParameter):
        self.header = None
        self.parameter = parameter
        self.data = None

    def serialize_parameter(self) -> bytes:
        return self.parameter.serialize()

    def serialize_data(self) -> bytes:
        return b""

    @classmethod
    def parse(cls, packet: bytes) -> "SetupCommunicationRequest":
        return cls(parameter=SetupCommunicationParameter.parse(packet=packet))


class SetupCommunicationResponse(S7Packet):
    MESSAGE_TYPE = MessageType.Response

    def __init__(self, parameter: SetupCommunicationParameter) -> None:
        self.parameter = parameter

    @classmethod
    def create(
        cls,
        max_amq_caller_ack: int = 0x0001,
        max_amq_callee_ack: int = 0x0001,
        pdu_length: int = 0x00F0,
    ) -> "SetupCommunicationResponse":
        parameter = SetupCommunicationParameter(
            max_amq_caller_ack=max_amq_caller_ack,
            max_amq_callee_ack=max_amq_callee_ack,
            pdu_length=pdu_length,
        )
        return cls(parameter=parameter)

    def serialize(self) -> bytes:
        return self.parameter.serialize()
