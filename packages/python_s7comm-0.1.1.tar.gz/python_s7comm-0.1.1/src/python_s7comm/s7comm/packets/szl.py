import struct
from enum import IntEnum

from ..enums import CPUStatus


class CPUStateDataTree:
    def __init__(
        self,
        ereig: int,
        ae: int,
        requested_mode: CPUStatus,
        previous_mode: CPUStatus,
        allinfo1: bytes,
        allinfo2: bytes,
        allinfo3: bytes,
        allinfo4: bytes,
        time: bytes,
    ):
        self.ereig = ereig
        self.ae = ae
        self.requested_mode = requested_mode
        self.previous_mode = previous_mode
        self.allinfo1 = allinfo1
        self.allinfo2 = allinfo2
        self.allinfo3 = allinfo3
        self.allinfo4 = allinfo4
        self.time = time

    @classmethod
    def parse(cls, packet: bytes) -> "CPUStateDataTree":
        ereig, ae, bzu_id, _, allinfo1, allinfo2, allinfo3, allinfo4, time = struct.unpack_from("Hbbi4b8s", packet)
        requested_mode = CPUStatus(bzu_id & 0xF)
        previous_mode = CPUStatus(bzu_id >> 4)
        return cls(ereig, ae, requested_mode, previous_mode, allinfo1, allinfo2, allinfo3, allinfo4, time)


class ModuleIdentificationIndex(IntEnum):
    MODULE_IDENTIFICATION = 0x0001
    HARDWARE_IDENTIFICATION = 0x0006
    FIRMWARE_IDENTIFICATION = 0x0007
    BOOT_LOADER = 0x0081
    """bootloader
    b'\x00\x81\x42\x6f\x6f\x74\x20\x4c\x6f\x61\x64\x65\x72\x20\x20\x20\x20\x20\x20\x20\x20\x20\x00\x00\x41\x20\x09\x09'
    """


class ModuleIdentificationDataTree:
    """A data record in the SZL with the SZL-ID W#16#xy11"""

    def __init__(self, index: int, order_number: str, module_type_id: int, version: int, release: int) -> None:
        """A data record in the SZL with the SZL-ID W#16#xy11

        Args:
            index (int): Number of an identification data record
            order_number (str): The module’s Order No.; a string of 19 characters and one blank (20H), for example.:
                “6ES7 314-0AE01-0AB0 ” for CPU 314
            module_type_id (int): Module type identifier (the module type identifier is for internal use only)
            version (int): Release of the module or operating system version
            release (int): Release of the PG description file for offline configuration
        """
        self.index = index
        self.order_number = order_number
        self.module_type_id = module_type_id
        self.version = version
        self.release = release

    @classmethod
    def parse(cls, packet: bytes) -> "ModuleIdentificationDataTree":
        index, order_number, module_type_id, version, release = struct.unpack_from("!H20s3H", packet)
        return cls(
            index=index,
            order_number=order_number.decode(),
            module_type_id=module_type_id,
            version=version,
            release=release,
        )


class SZLResponseData:
    DATA_TREE_OFFSET = 8

    def __init__(self, szl_id: int, szl_index: int, szl_data_tree_list: list[bytes]) -> None:
        self.szl_id = szl_id
        self.szl_index = szl_index
        self.szl_data_tree_list = szl_data_tree_list

    @classmethod
    def parse(cls, packet: bytes) -> "SZLResponseData":
        szl_id, szl_index, szl_partial_list_length, szl_partial_list_count = struct.unpack_from("!HHHH", packet)
        szl_data_tree_list = []
        offset = cls.DATA_TREE_OFFSET
        for _ in range(szl_partial_list_count):
            szl_data_tree = packet[offset : offset + szl_partial_list_length]
            szl_data_tree_list.append(szl_data_tree)
            offset += szl_partial_list_length
        return cls(szl_id=szl_id, szl_index=szl_index, szl_data_tree_list=szl_data_tree_list)
