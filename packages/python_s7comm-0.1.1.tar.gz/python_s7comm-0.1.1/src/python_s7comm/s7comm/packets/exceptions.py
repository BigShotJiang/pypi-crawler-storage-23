from .packet import S7Packet


class S7CommException(Exception):
    def __init__(self, message: str, response: S7Packet | None) -> None:
        super().__init__(message)
        self.response = response
        self.message = message


class ReadVariableException(S7CommException): ...


class WriteVariableException(S7CommException): ...
