import re
from dataclasses import dataclass

from ..enums import Area, DataType


db_pattern = re.compile(
    r"""^
       (?P<area>DB)
       (?P<db_number>\d{1,5})
       \.
       (?P<start>\d{1,5})
       \.?
       (?P<start_bit>[0-7])?
       \ (?P<data_type>BOOL|BYTE|CHAR|WORD|DWORD|INT|DINT|REAL|COUNTER|TIMER)
       \ (?P<amount>\d{1,5})
       $""",
    re.X | re.IGNORECASE,
)
peripheral_pattern = re.compile(
    r"""^(?P<area>M|I|Q|C|T)
       (?P<start>\d{1,5})
       \.?(?P<start_bit>[0-7])?
       \ (?P<data_type>BOOL|BYTE|CHAR|WORD|DWORD|INT|DINT|REAL|COUNTER|TIMER)
       \ (?P<amount>\d{1,5})
       $""",
    re.X | re.IGNORECASE,
)


@dataclass
class VariableAddress:
    # TODO: data_type=None is for parsing from response, consider moving to a separate VariableAddressResponse class
    # because the response doesn't contain data_type, or maybe remove datatype entirely

    area: Area
    db_number: int
    start: int
    data_type: DataType
    start_bit: int = 0
    amount: int = 1

    def __post_init__(self) -> None:
        """Performs post-initialization validation of the VariableAddress object.
        TODO: add more validation
        """
        if self.area != Area.DB:
            self.db_number = 0
        if self.db_number < 0 or self.db_number > 65535:
            raise ValueError("Invalid DB number")
        if self.start < 0 or self.start > 65535:
            raise ValueError("Invalid start byte")
        if self.start_bit < 0 or self.start_bit > 7:
            raise ValueError("Invalid start_bit")

    @classmethod
    def from_string(cls, address: str) -> "VariableAddress":
        """Creates a VariableAddress object from a string representation of an address.
        Args:
            address (str): The string representation of the address.

        Returns:
            VariableAddress: The created VariableAddress object.

        Raises:
            ValueError: If the address format is invalid.

        Notes:
            - The maximum DB number is 65535.
            - The start address range is 0 to 65535.
            - The bit number range is 0 to 7.

        DB area format:
            "DB<db_number>.<start_address>[.<bit_number>] <data_type> <amount>"
        Other areas format:
            "<area><start_address>[.<bit_number>] <data_type> <amount>"
        db_number: 65535
        area_type:
            I - inputs
            Q - outputs
            M - markers
            C - counters
            T - timers
        start_address range: 0-65535
        bit_number range: 0-7
        data_type: [BOOL|BYTE|CHAR|WORD|DWORD|INT|DINT|REAL|COUNTER|TIMER]
        amount: int

            Input bit	        BOOL	                        0 to 65535.7
            Input byte	        BYTE, CHAR	                    0 to 65535
            Input word	        WORD, INT, S5TIME, DATE	        0 to 65534
            Input double word	DWORD, DINT, REAL, TOD, TIME	0 to 65532
        """
        if addr := db_pattern.match(address) or peripheral_pattern.match(address):
            addr_dict = addr.groupdict()
            area = Area[addr_dict["area"].upper()]
            db_number = 0
            if area == Area.DB:
                db_number = int(addr_dict["db_number"])
            start = int(addr_dict["start"])
            data_type = DataType(addr_dict["data_type"].upper())
            start_bit = int(addr_dict["start_bit"] or 0)
            amount = int(addr_dict["amount"])
        else:
            raise ValueError("Invalid address format")
        return cls(
            area=area,
            db_number=db_number,
            start=start,
            data_type=data_type,
            start_bit=start_bit,
            amount=amount,
        )
