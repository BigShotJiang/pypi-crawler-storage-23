from ..enums import MessageType
from .headers import S7AckDataHeader
from .packet import S7Packet


class S7Error(S7Packet):
    MESSAGE_TYPE = MessageType.Response

    def __init__(self, header: S7AckDataHeader) -> None:
        self.header = header
        self.parameter = None
        self.data = None

    def serialize_parameter(self) -> bytes:
        return b""

    def serialize_data(self) -> bytes:
        return b""

    @classmethod
    def parse(cls, packet: bytes) -> "S7Error":
        raise NotImplementedError("S7Error is created from header, not parsed from bytes")
