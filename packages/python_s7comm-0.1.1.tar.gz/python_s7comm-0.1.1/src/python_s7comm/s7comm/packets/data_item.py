import struct

from ..enums import DataTransportSize


class DataItem:
    HEADER_LENGTH = 4  # return_code + transport_size + data_length

    def __init__(
        self,
        transport_size: DataTransportSize,
        data_length: int,
        data: bytes = b"",
        return_code: int = 0x00,
    ):
        self.return_code = return_code
        self.transport_size = transport_size
        self.data_length = data_length
        self.data = data

    def serialize(self) -> bytes:
        return struct.pack("!BBH", self.return_code, self.transport_size, self.data_length) + self.data

    @classmethod
    def parse(cls, packet: bytes) -> "DataItem":
        return_code, transport_size, data_length = struct.unpack_from("!BBH", packet)
        data = packet[cls.HEADER_LENGTH : cls.HEADER_LENGTH + data_length]
        return cls(transport_size=transport_size, data_length=data_length, return_code=return_code, data=data)
