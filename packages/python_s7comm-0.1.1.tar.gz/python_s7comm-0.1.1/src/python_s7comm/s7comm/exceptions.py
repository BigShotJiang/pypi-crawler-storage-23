class S7CommException(Exception):
    pass


class ReadVariableException(S7CommException):
    pass


class PacketLostError(Exception):
    pass


class StalePacketError(Exception):
    pass
