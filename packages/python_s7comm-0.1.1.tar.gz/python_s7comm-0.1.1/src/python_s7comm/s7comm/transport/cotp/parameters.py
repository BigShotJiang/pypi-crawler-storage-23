import struct
from dataclasses import dataclass
from typing import ClassVar


@dataclass
class Parameter:
    """RFC 905 13.2.3"""

    STRUCT: ClassVar[struct.Struct]
    value: int
    code: int
    length: int

    def serialize(self) -> bytes:
        return self.STRUCT.pack(self.code, self.length, self.value)


@dataclass
class TPDUSize(Parameter):
    STRUCT: ClassVar[struct.Struct] = struct.Struct("!BBB")
    TPDU_SIZE_DICT: ClassVar[dict[int, int]] = {
        128: 0x07,
        256: 0x08,
        512: 0x09,
        1024: 0x0A,
        2048: 0x0B,
        4096: 0x0C,
        8192: 0x0D,
    }
    length: int = 1
    code: int = 0xC0

    def serialize(self) -> bytes:
        return self.STRUCT.pack(self.code, self.length, self._get_tpdu_size_code())

    def _get_tpdu_size_code(self) -> int:
        tpdu_size_code = self.TPDU_SIZE_DICT.get(self.value)
        if tpdu_size_code is None:
            raise ValueError(f"Invalid TPDU size value. Valid values: {self.TPDU_SIZE_DICT.keys()}")
        return tpdu_size_code


@dataclass
class TSAP(Parameter):
    STRUCT: ClassVar[struct.Struct] = struct.Struct("!BBH")


@dataclass
class SourceTSAP(TSAP):
    code: int = 0xC1
    length: int = 2


@dataclass
class DestinationTSAP(TSAP):
    code: int = 0xC2
    length: int = 2
