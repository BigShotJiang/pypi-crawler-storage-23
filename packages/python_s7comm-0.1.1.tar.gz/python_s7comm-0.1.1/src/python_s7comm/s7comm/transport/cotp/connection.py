import struct

from .enums import TPDUType
from .parameters import DestinationTSAP, Parameter, SourceTSAP, TPDUSize


class ConnectionTPDU:
    """
    ConnectionRequest - RFC 905 13.3.1
    ConnectionConfirm - RFC 905 13.4

    The structure of the TPDU shall be as follows:

    1    2        3        4       5   6    7    8    p  p+1...end
    +--+------+---------+---------+---+---+------+-------+---------+
    |LI|CR CDT|     DST - REF     |SRC-REF|CLASS |VARIAB.|USER     |
    |  |      |0000 0000|0000 0000|   |   |OPTION|PART   |DATA     |
    +--+------+---------+---------+---+---+------+-------+---------+
    """

    FIXED_PART_STRUCT = struct.Struct("!BHHB")
    _MAX_LENGTH = 128

    def __init__(
        self,
        dst_ref: int,
        src_ref: int,
        tpdu_type: TPDUType,
        class_option: int = 0,
        parameters: dict[int, Parameter] | None = None,
    ):
        self.dst_ref = dst_ref
        self.src_ref = src_ref
        self.tpdu_type = tpdu_type
        self.class_option = class_option
        self.parameters = parameters or {}

    def _serialize_fixed_part(self) -> bytes:
        return self.FIXED_PART_STRUCT.pack(self.tpdu_type, self.dst_ref, self.src_ref, self.class_option)

    def _serialize_variable_part(self) -> bytes:
        if self.parameters is None:
            return b""
        variable_part = b""
        for parameter in self.parameters.values():
            variable_part += parameter.serialize()
        return variable_part

    def serialize(self) -> bytes:
        tpdu = self._serialize_fixed_part() + self._serialize_variable_part()
        return len(tpdu).to_bytes(length=1, byteorder="big") + tpdu

    @classmethod
    def parse(cls, packet: bytes) -> "ConnectionTPDU":
        length = packet[0]
        code_cdt, dst_ref, src_ref, class_option = cls.FIXED_PART_STRUCT.unpack_from(packet, 1)

        if code_cdt not in TPDUType:
            raise ValueError(f"Invalid data unit code: {code_cdt}")

        # variable part
        parameters: dict[int, Parameter] = {}
        if length > 6:
            variable_part = packet[7:]
            while variable_part:
                code = variable_part[0]
                length = variable_part[1]
                value = int.from_bytes(variable_part[2 : 2 + length], byteorder="big")
                if code == 0xC0:
                    tpdu_size = [k for k, v in TPDUSize.TPDU_SIZE_DICT.items() if v == value]
                    if tpdu_size:
                        parameters[code] = TPDUSize(value=tpdu_size[0])
                    else:
                        raise ValueError(
                            f"Invalid value for TPDUSize parameter: {value}. "
                            f"One of the following values is expected: {list(TPDUSize.TPDU_SIZE_DICT.values())}"
                        )
                elif code == 0xC1:
                    parameters[code] = SourceTSAP(value)
                elif code == 0xC2:
                    parameters[code] = DestinationTSAP(value)
                else:
                    parameters[code] = Parameter(code=code, length=length, value=value)
                variable_part = variable_part[2 + length :]
        return cls(
            dst_ref=dst_ref,
            src_ref=src_ref,
            tpdu_type=TPDUType(code_cdt),
            class_option=class_option,
            parameters=parameters,
        )
