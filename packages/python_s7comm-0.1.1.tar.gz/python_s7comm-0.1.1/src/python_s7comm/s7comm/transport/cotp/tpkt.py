import struct


class TPKT:
    """RFC 1006 Packet Format

    vrsn                         8 bits

    This field is always 3 for the version of the protocol described in
    this memo.

    packet length                16 bits (min=7, max=65535)

    This field contains the length of entire packet in octets,
    including packet-header.  This permits a maximum TPDU size of
    65531 octets.  Based on the size of the data transfer (DT) TPDU,
    this permits a maximum TSDU size of 65524 octets.

    The format of the TPDU is defined in [ISO8073].  Note that only
    TPDUs formatted for transport class 0 are exchanged (different
    transport classes may use slightly different formats).
    """

    MAX_PACKET_LENGTH = 65531
    PACKET_STRUCT = struct.Struct("!BBH")
    VERSION = 3
    RESERVED = 0

    @classmethod
    def serialize(cls, payload: bytes) -> bytes:
        length = 4 + len(payload)
        return cls.PACKET_STRUCT.pack(cls.VERSION, cls.RESERVED, length) + payload

    @classmethod
    def parse(cls, packet: bytes) -> bytes:
        version, reserved, length = cls.PACKET_STRUCT.unpack_from(packet)
        if version != 3:
            raise ValueError(f"Invalid version: {version}. Expected: {cls.VERSION}")
        if reserved != 0:
            raise ValueError(f"Invalid reserved field: {reserved}. Expected: {cls.RESERVED}")
        if length != len(packet) or len(packet) > TPKT.MAX_PACKET_LENGTH:
            raise ValueError(f"Packet length exceeds maximum allowed length: {len(packet)}")
        payload = packet[4:]
        return payload
