import struct

from .enums import TPDUType


class Data:
    PDU_TYPE = TPDUType.DT
    FIXED_PART_STRUCT = struct.Struct("!BBB")
    """RFC 905 13.7

    Depending on the class and the option the DT TPDU shall have  one
    of the following structures.

    a)  Normal format for Classes 0 and 1

    1       2         3          4       5             ... end
    +----+-----------+-----------+------------ - - - - - -------+
    | LI |    DT     |  TPDU-NR  | User Data                    |
    |    | 1111 0000 |  and EOT  |                              |
    +----+-----------+-----------+------------ - - - - - -------+


    b)  Normal format for Classes 2, 3 and 4

    1      2       3   4     5     6       p    p+1       ... end
    +----+---------+---+---+-------+-----+-------+----------- - - -+
    | LI |   DT    |DST-REF|TPDU-NR|Variable Part|User Data        |
    |    |1111 0000|   |   |and EOT|     |       |                 |
    +----+---------+---+---+-------+-----+-------+----------- - - -+

    c)  Extended Format for  use  in  Classes  2,  3  and  4  when
        selected during connection establishment.

    1      2       3   4   5,6 7,8  9     p  p+1      ... end
    +----+---------+---+---+---------+--------+---------- - - -+
    | LI |   DT    |DST-REF| TPDU-NR |Variable|User Data       |
    |    |1111 0000|   |   | and EOT |  Part  |                |
    +----+---------+---+---+---------+--------+---------- - - -+

    The fixed part shall contain:

    a)  DT:       Data Transfer Code:  1111 0000;

    b)  DST-REF:  See 13.4.3;

    c)  EOT:      When set to ONE, indicates that the  current  DT
                    TPDU is the last data unit of a complete DT TPDU
                    sequence (End of TSDU).  EOT is bit 8 of octet 3
                    in  class  0  and 1, bit 8 of octet 5 for normal
                    formats for classes 2, 3 and  4  and  bit  8  of
                    octet 8 for extended formats;

    d)  TPDU-NR:  TPDU send Sequence Number  (zero  in  Class  0).
                    May  take  any value in Class 2 without explicit
                    flow control.  TPDU-NR is bits 7-1  of  octet  3
                    for  classes  0  and  1, bits 7-1 of octet 5 for
                    normal formats in classes 2, 3 and 4, octets  5,
                    6  and  7  together with bits 7-1 of octet 8 for
                    extended formats.
    """

    def __init__(self, eot: bool, tpdu_nr: int, user_data: bytes):
        self.eot = eot
        self.tpdu_nr = tpdu_nr
        self.user_data = user_data

    @classmethod
    def parse(cls, packet: bytes) -> "Data":
        packet = bytearray(packet)
        # The length indicated shall be the header length
        # in   octets   including  parameters,  but  excluding  the  length
        # indicator field and user data, if any.
        length = packet.pop(0)
        if length != 2:
            raise ValueError("invalid header length")
        tpdu_type = packet.pop(0)
        # check if tpdu_type is valid
        TPDUType(tpdu_type)
        eot_nr = packet.pop(0)
        eot = bool(eot_nr >> 7)
        tpdu_nr = eot_nr & ~(1 << 7)
        user_data = packet
        return cls(eot=eot, tpdu_nr=tpdu_nr, user_data=user_data)

    def serialize(self) -> bytes:
        length = 2
        eot_nr = (self.eot << 7) | self.tpdu_nr
        fixed_part = self.FIXED_PART_STRUCT.pack(length, self.PDU_TYPE.value, eot_nr)
        return fixed_part + self.user_data
