import asyncio
import socket
import struct

from .connection import ConnectionTPDU
from .data import Data
from .enums import TPDUType
from .parameters import DestinationTSAP, Parameter, SourceTSAP, TPDUSize
from .tpkt import TPKT


class BaseCOTP:
    MAX_PACKET_LENGTH = 65531  # octets

    def __init__(
        self,
        tpdu_size: int = 1024,
        source_tsap: int = 0x0100,
        dest_tsap: int = 0x0101,
        socket_buffer_size: int = 1024,
        dst_ref: int = 0,
        src_ref: int = 1,
        class_option: int = 0,
    ):
        self.tpdu_size = tpdu_size
        self.source_tsap = source_tsap
        self.dest_tsap = dest_tsap
        self.socket_buffer_size = socket_buffer_size
        self.tpkt = TPKT
        self.dst_ref = dst_ref
        self.src_ref = src_ref
        self.class_option = class_option

    def create_data_packet(self, payload: bytes, tpdu_nr: int = 0) -> Data:
        if len(payload) < self.MAX_PACKET_LENGTH:
            eot = True
        else:
            raise Exception("Invalid packet length")
        packet = Data(eot=eot, tpdu_nr=tpdu_nr, user_data=payload)
        return packet

    def create_connection_packet(self, tpdu_type: TPDUType) -> ConnectionTPDU:
        if tpdu_type not in (TPDUType.CC, TPDUType.CR):
            raise ValueError("tpdu_type must be TPDUType.CC or TPDUType.CR")
        parameters: dict[int, Parameter] = {
            0xC0: TPDUSize(value=self.tpdu_size),
            0xC1: SourceTSAP(value=self.source_tsap),
            0xC2: DestinationTSAP(value=self.dest_tsap),
        }
        return ConnectionTPDU(
            dst_ref=self.dst_ref,
            src_ref=self.src_ref,
            tpdu_type=tpdu_type,
            class_option=self.class_option,
            parameters=parameters,
        )

    @classmethod
    def parse(cls, packet: bytes) -> Data | ConnectionTPDU:
        length, tpdu_type_code = struct.unpack_from("!BB", packet)
        tpdu_type = TPDUType(tpdu_type_code)
        if tpdu_type == TPDUType.DT:
            return Data.parse(packet)
        if tpdu_type in (TPDUType.CC, TPDUType.CR):
            return ConnectionTPDU.parse(packet)
        raise ValueError(f"Invalid TPDU type: {tpdu_type}")


class COTP(BaseCOTP):
    MAX_PACKET_LENGTH = 65531  # octets

    def __init__(
        self,
        tpdu_size: int = 1024,
        source_tsap: int = 0x0100,
        dest_tsap: int = 0x0101,
        socket_buffer_size: int = 1024,
        dst_ref: int = 0,
        src_ref: int = 1,
        class_option: int = 0,
    ):
        super().__init__(
            tpdu_size=tpdu_size,
            source_tsap=source_tsap,
            dest_tsap=dest_tsap,
            socket_buffer_size=socket_buffer_size,
            dst_ref=dst_ref,
            src_ref=src_ref,
            class_option=class_option,
        )
        self.socket = socket.socket()

    def connect(self, address: str, rack: int, slot: int, port: int = 102) -> None:
        dest_tsap = (0x01 << 8) + (rack * 0x20) + slot
        self.dest_tsap = dest_tsap
        connection_request_packet = self.create_connection_packet(tpdu_type=TPDUType.CR)
        self.socket.connect((address, port))
        data = self.tpkt.serialize(payload=connection_request_packet.serialize())
        self.socket.send(data)
        response = self.socket.recv(self.socket_buffer_size)
        response_packet = self.parse(self.tpkt.parse(response))
        if not isinstance(response_packet, ConnectionTPDU):
            raise ValueError(f"Invalid COTP packet type: {response_packet}. Expected ConnectionTPDU type")
        if response_packet.tpdu_type != TPDUType.CC:
            raise ValueError(f"Invalid COTP packet type: {response_packet.tpdu_type}. Expected {TPDUType.CC}")
        if not response_packet.parameters:
            return
        if tpdu_size := response_packet.parameters.get(TPDUSize.code):
            self.tpdu_size = tpdu_size.value

    def send(self, payload: bytes) -> None:
        data_packet = self.create_data_packet(payload=payload)
        data = self.tpkt.serialize(payload=data_packet.serialize())
        self.socket.send(data)

    def receive(self) -> bytes:
        """Receive complete COTP message (until EOT)."""
        buffer = bytes(0)
        while True:
            response = self.socket.recv(self.socket_buffer_size)
            response_packet = self.parse(self.tpkt.parse(response))
            if not isinstance(response_packet, Data):
                raise ValueError(f"Invalid COTP packet type: {response_packet}. Expected Data")
            buffer += response_packet.user_data
            if response_packet.eot:
                break
        return buffer

    def close(self) -> None:
        self.socket.close()


class AsyncSocket:
    def __init__(self) -> None:
        self.reader: asyncio.StreamReader
        self.writer: asyncio.StreamWriter

    async def connect(self, address: str, port: int) -> None:
        self.reader, self.writer = await asyncio.open_connection(address, port)

    async def send(self, data: bytes) -> None:
        self.writer.write(data)
        await self.writer.drain()

    async def recv(self, n: int = -1) -> bytes:
        return await self.reader.read(n)

    async def close(self) -> None:
        self.writer.close()
        await self.writer.wait_closed()


class AsyncCOTP(BaseCOTP):
    # TODO: Refactor send/receive like COTP - separate send() and receive() methods

    def __init__(
        self,
        tpdu_size: int = 1024,
        source_tsap: int = 0x0100,
        dest_tsap: int = 0x0101,
        socket_buffer_size: int = 1024,
        dst_ref: int = 0,
        src_ref: int = 1,
        class_option: int = 0,
    ):
        super().__init__(
            tpdu_size=tpdu_size,
            source_tsap=source_tsap,
            dest_tsap=dest_tsap,
            socket_buffer_size=socket_buffer_size,
            dst_ref=dst_ref,
            src_ref=src_ref,
            class_option=class_option,
        )
        self.socket = AsyncSocket()
        self.lock = asyncio.Lock()

    async def connect(self, address: str, rack: int, slot: int, port: int = 102) -> None:
        dest_tsap = (0x01 << 8) + (rack * 0x20) + slot
        self.dest_tsap = dest_tsap
        connection_request_packet = self.create_connection_packet(tpdu_type=TPDUType.CR)
        await self.socket.connect(address, port)
        data = self.tpkt.serialize(payload=connection_request_packet.serialize())
        await self.socket.send(data)
        response = await self.socket.recv(self.socket_buffer_size)
        response_packet = self.parse(self.tpkt.parse(response))
        if not isinstance(response_packet, ConnectionTPDU):
            raise ValueError(f"Invalid COTP packet type: {response_packet}. Expected ConnectionTPDU type")
        if response_packet.tpdu_type != TPDUType.CC:
            raise ValueError(f"Invalid COTP packet type: {response_packet.tpdu_type}. Expected {TPDUType.CC}")
        if not response_packet.parameters:
            return
        if tpdu_size := response_packet.parameters.get(TPDUSize.code):
            self.tpdu_size = tpdu_size.value

    async def send(self, payload: bytes) -> None:
        data_packet = self.create_data_packet(payload=payload)
        data = self.tpkt.serialize(payload=data_packet.serialize())
        await self.socket.send(data)

    async def receive(self) -> bytes:
        """Receive complete COTP message (until EOT)."""
        buffer = bytes(0)
        while True:
            response = await self.socket.recv(self.socket_buffer_size)
            response_packet = self.parse(self.tpkt.parse(response))
            if not isinstance(response_packet, Data):
                raise ValueError(f"Invalid COTP packet type: {response_packet}. Expected Data")
            buffer += response_packet.user_data
            if response_packet.eot:
                break
        return buffer

    async def close(self) -> None:
        await self.socket.close()
