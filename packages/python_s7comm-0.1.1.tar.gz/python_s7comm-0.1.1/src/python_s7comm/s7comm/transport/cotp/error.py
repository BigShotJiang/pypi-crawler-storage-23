class Error:
    """RFC 905 13.12

     1        2       3     4     5         6   P
    +----+-----------+----+----+--------+----------+
    | LI |    ER     | DST-REF | Reject | Variable |
    |    | 0111 0000 |    |    | Cause  |   Part   |
    +----+-----------+----+----+--------+----------+

    The fixed part shall contain:

       a)  ER:            TPDU Error Code:  0111 0000;

       b)  DST-REF:       See 13.4.3;

       c)  REJECT CAUSE:  0000 0000  Reason not specified
                          0000 0001  Invalid parameter code
                          0000 0010  Invalid TPDU type
                          0000 0011  Invalid parameter value.
    13.12.4  Variable Part

    The variable part may contain the following parameters:

       a)  Invalid TPDU

           Parameter code:    1100 0001

           Parameter length:  number of octets of the value field

           Parameter Value:  Contains the bit pattern of the rejected
                              TPDU  up  to  and  including  the octet
                              which  caused  the   rejection.    This
                              parameter is mandatory in Class 0.
    """

    ...
