from enum import IntEnum


class TPDUType(IntEnum):
    """RFC 905 4.2"""

    CR = 0xE0  # Connection request
    CC = 0xD0  # Connection confirm
    DT = 0xF0  # Data
    ER = 0x70  # Error
    # DR = ...  # Disconnect request
    # DC = ...  # Disconnect confirm
    # ED = ...  # Expedited data
    # AK = ...  # Data acknowledge
    # EA = ...  # Expedited acknowledge
    # RJ = ...  # Reject


class RejectCause(IntEnum):
    """RFC 905 13.12.3"""

    NOT_SPECIFIED = 0x00
    INVALID_PARAMETER_CODE = 0x01
    INVALID_TPDU_TYPE = 0x02
    INVALID_PARAMETER_VALUE = 0x03


class TPDUSize(IntEnum):
    """RFC 905 13.3.4
    This parameter defines the proposed maximum TPDU size  (in
    octets including the header) to be used over the requested
    transport connection.
    """

    octets_128 = 0x07
    octets_256 = 0x08
    octets_512 = 0x09
    octets_1024 = 0x0A
    octets_2048 = 0x0B
    octets_4096 = 0x0C
    octets_8192 = 0x0D
