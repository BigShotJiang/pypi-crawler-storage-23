from enum import Enum, IntEnum


class DataTransportSize(IntEnum):
    NULL = 0x00
    BIT = 0x03
    BYTE = 0x04  # BYTE, WORD, DWORD, COUNTER, TIMER
    INT = 0x05  # INT, DINT
    REAL = 0x07
    OCTET = 0x09  # CHAR


class MessageType(IntEnum):
    """S7comm Message Types"""

    JobRequest = 0x01  # request sent by the master
    Ack = 0x02  # simple acknowledgement sent by the slave with no data field
    Response = 0x03  # AckData
    Userdata = 0x07  # an extension of the original protocol, the parameter field contains the request/response id
    ServerControl = 0x08  # request server control


class FunctionCode(IntEnum):
    """Job Request/Ack-Data function codes"""

    CpuService = 0x00
    SetupCommunication = 0xF0
    ReadVariable = 0x04
    WriteVariable = 0x05
    RequestDownload = 0x1A
    DownloadBlock = 0x1B
    DownloadEnded = 0x1C
    StartUpload = 0x1D
    Upload = 0x1E
    EndUpload = 0x1F
    PLCControl = 0x28
    PLCStop = 0x29


class ParameterTransportSize(IntEnum):
    BOOL = 0x01
    BIT = 0x01
    BYTE = 0x02
    CHAR = 0x03
    WORD = 0x04
    INT = 0x05
    DWORD = 0x06
    DINT = 0x07
    REAL = 0x08
    COUNTER = 0x1C
    TIMER = 0x1D
    # unconfirmed
    # LWORD = 0x0D


class DataSizeByte(IntEnum):
    BOOL = 1
    BIT = 1  # S7 sends 1 byte per bit
    BYTE = 1
    CHAR = 1
    WORD = 2
    DWORD = 4
    INT = 2
    DINT = 4
    REAL = 4
    COUNTER = 2
    TIMER = 2
    # unconfirmed
    # LWORD = 8


class Area(IntEnum):
    P = 0x80  # peripheral
    I = 0x81  # inputs # noqa: E741
    Q = 0x82  # outputs
    M = 0x83  # markers
    DB = 0x84  # data block
    C = 0x1C  # counters
    T = 0x1D  # timers


class DataTypeTransportSize(Enum):
    BOOL = DataTransportSize.BIT
    BIT = DataTransportSize.BIT
    BYTE = DataTransportSize.BYTE
    CHAR = DataTransportSize.OCTET
    WORD = DataTransportSize.BYTE
    INT = DataTransportSize.INT
    DWORD = DataTransportSize.BYTE
    DINT = DataTransportSize.INT
    REAL = DataTransportSize.REAL
    COUNTER = DataTransportSize.BYTE
    TIMER = DataTransportSize.BYTE


class DataType(str, Enum):
    BIT = "BOOL"  # Workaround for getting data_type from transport_size
    BOOL = "BOOL"
    BYTE = "BYTE"
    CHAR = "CHAR"
    WORD = "WORD"
    INT = "INT"
    DWORD = "DWORD"
    DINT = "DINT"
    REAL = "REAL"
    COUNTER = "COUNTER"
    TIMER = "TIMER"


class ItemReturnCode(IntEnum):
    RESERVED = 0x00
    DATA_HW_FAULT = 0x01  # Hardware error
    DATA_ACCESS_FAULT = 0x03  # Accessing the object not allowed
    DATA_OUT_OF_RANGE = 0x05  # Address out of range
    DATA_NOT_SUP = 0x06  # Data type not supported
    DATA_SIZEMISMATCH = 0x07  # Data type inconsistent
    DATA_ERR = 0x0A  # Object does not exist
    SUCCESS = 0xFF


class HeaderError(IntEnum):
    NO_ERROR = 0x00
    APLICATION_RELATION_ERROR = 0x81
    OBJECT_DEFINITION_ERROR = 0x82
    NO_RESOURCES_AVAILABLE = 0x83
    ERROR_ON_SERVICE_PROCESSING = 0x84
    ERROR_ON_SUPPLIES = 0x85
    ACCESS_ERROR = 0x87


class UserdataMethod(IntEnum):
    REQUEST = 0x11
    RESPONSE = 0x12


class TransmissionType(IntEnum):
    """Userdata transmission type"""

    CYCLIC = 0x0  # Push cyclic data push by the PLC
    REQUEST = 0x4  # Request by the master
    RESPONSE = 0x8  # Response by the slave


class UserdataFunction(IntEnum):
    """Userdata Functions"""

    PROGRAMMER_COMMAND = 0x1  # Programmer commands
    CYCLIC_DATA = 0x2  # Cyclic data
    BLOCK_FUCTION = 0x3  # Block functions
    CPU_FUNCTION = 0x4  # CPU functions
    SECURITY = 0x5  # Security
    TIME = 0x7  # Time functions


class SubfunctionCode(IntEnum):
    """Userdata CPU subfunctions"""

    READ_SZL = 0x01  # Read SZL
    MESSAGE_SERVICE = 0x02  # Message service
    TRANSITION_TO_STOP = 0x03  # Transition to stop
    ALARM_ACK_1 = 0x0B  # Alarm was acknowledged in HMI/SCADA 1
    ALARM_ACK_2 = 0x0C  # Alarm was acknowledged in HMI/SCADA 2
    ALARM_MESSAGE = 0x11  # PLC is indicating a ALARM message
    ALARM_SUBSCRIPTION = 0x13  # HMI/SCADA initiating ALARM subscription


class CPUStatus(IntEnum):
    UNKNOWN = 0
    STOP = 4
    RUN = 8


class SZLMethod(IntEnum):
    REQUEST = 0x11
    RESPONSE = 0x12


class UserdataLastPDU(IntEnum):
    YES = 0x00
    NO = 0x01
