from .s7comm import S7Comm, enums
from .s7comm.packets import S7Packet
from .s7comm.packets.variable_address import VariableAddress
from .s7comm.szl import (
    CPUStateDataTree,
    ModuleIdentificationDataTree,
    ModuleIdentificationIndex,
    SZLResponseData,
)


class Client:
    def __init__(
        self,
        tpdu_size: int = 1024,  # cotp packet length
        pdu_length: int = 480,  # s7comm packet length
        source_tsap: int = 0x0100,
        dest_tsap: int = 0x0101,
    ) -> None:
        self.s7comm = S7Comm(tpdu_size=tpdu_size, pdu_length=pdu_length, source_tsap=source_tsap, dest_tsap=dest_tsap)
        self.is_connected = False

    def __enter__(self) -> "Client":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        self.close()

    def connect(self, address: str, rack: int, slot: int, port: int = 102) -> None:
        self.s7comm.connect(address=address, rack=rack, slot=slot, port=port)
        self.is_connected = True

    def disconnect(self) -> None:
        self.close()
        self.is_connected = False

    def get_pdu_length(self) -> int:
        return self.s7comm.pdu_length

    def close(self) -> None:
        self.s7comm.close()

    def get_cpu_state(self) -> enums.CPUStatus:
        response = self.s7comm.read_szl(szl_id=0x0424, szl_index=0x0000)
        szl_data = SZLResponseData.parse(response.data.data)
        cpu_state = CPUStateDataTree.parse(szl_data.szl_data_tree_list[0])
        return cpu_state.requested_mode

    def read_area(self, address: str) -> bytes:
        return self.s7comm.read_area(address=VariableAddress.from_string(address))

    def write_area(self, address: str, data: bytes) -> None:
        self.s7comm.write_area(address=VariableAddress.from_string(address), data=data)

    def get_order_code(self) -> str | None:
        response = self.s7comm.read_szl(szl_id=0x0011, szl_index=0x0000)
        szl_data = SZLResponseData.parse(response.data.data)
        for date_tree in szl_data.szl_data_tree_list:
            module_identification = ModuleIdentificationDataTree.parse(date_tree)
            if module_identification.index == ModuleIdentificationIndex.MODULE_IDENTIFICATION:
                return module_identification.order_number
        return None

    def read_szl(self, szl_id: int, szl_index: int = 0x0000) -> S7Packet:
        return self.s7comm.read_szl(szl_id=szl_id, szl_index=szl_index)

    def read_szl_list(self) -> SZLResponseData:
        response_data = self.s7comm.read_szl(szl_id=0x0000, szl_index=0x0000)
        return SZLResponseData.parse(response_data.data.data)

    def read_multi_vars(self, items: list[str]) -> list[bytes]:
        items_ = [VariableAddress.from_string(item) for item in items]
        response = self.s7comm.read_multi_vars(items=items_)
        return response.values()

    def write_multi_vars(self, items: list[tuple[str, bytes]]) -> None:
        vars_ = [(VariableAddress.from_string(address), data) for address, data in items]
        response = self.s7comm.write_multi_vars(items=vars_)
        response.check_result()

    def plc_stop(self) -> None:
        self.s7comm.plc_stop()
