import struct
from unittest.mock import Mock

import pytest

from python_s7comm.s7comm import PacketLostError, S7Comm, StalePacketError
from python_s7comm.s7comm.enums import SubfunctionCode, UserdataFunction
from python_s7comm.s7comm.packets import (
    SetupCommunicationParameter,
    SetupCommunicationRequest,
    UserDataRequest,
)
from python_s7comm.s7comm.packets.rw_variable import ReadVariableResponse


class TestS7CommSend:
    """Tests for S7Comm.send() method."""

    # Sample packets from real PLC communication
    SETUP_COMM_RESPONSE = b"\x32\x03\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\xf0\x00\x00\x01\x00\x01\x00\xf0"

    READ_VARIABLE_RESPONSE = (
        b"\x32\x03\x00\x00\x01\x00\x00\x02\x00\x0c"  # S7 ACK_DATA header
        b"\x00\x00\x04\x01"  # parameter
        b"\xff\x07\x00\x08\x42\xf6\xe6\x66\x44\x07\xcd\x71"  # data
    )

    ERROR_RESPONSE = (
        b"\x32\x03\x00\x00\x00\x00"  # header start
        b"\x81\x04"  # error_class=0x81, error_code=0x04
        b"\x00\x00\x00\x00"  # rest of header
    )

    def create_mock_transport(self, responses: list[bytes]) -> Mock:
        """Create a mock transport that returns given responses."""
        transport = Mock()
        transport.receive = Mock(side_effect=responses)
        transport.send = Mock()
        return transport

    def test_send_setup_communication(self) -> None:
        """Test sending SetupCommunication request."""
        transport = self.create_mock_transport([self.SETUP_COMM_RESPONSE])
        client = S7Comm(transport=transport)

        request = SetupCommunicationRequest(
            parameter=SetupCommunicationParameter(
                max_amq_caller_ack=1,
                max_amq_callee_ack=1,
                pdu_length=240,
            )
        )

        response = client.send(request)

        assert isinstance(response, SetupCommunicationRequest)
        assert response.parameter.pdu_length == 240
        transport.send.assert_called_once()

    def test_send_read_variable(self) -> None:
        """Test sending ReadVariable request and receiving response."""
        transport = self.create_mock_transport([self.READ_VARIABLE_RESPONSE])
        client = S7Comm(transport=transport)
        # Set PDU reference to match response (0x0100 = 256, but response has 0x01)
        client._pdu_reference = 0  # Will become 1 after send

        from python_s7comm.s7comm.packets import VariableAddress, VariableReadRequest

        address = VariableAddress.from_string("DB1.4 REAL 2")
        request = VariableReadRequest.create(items=[address])
        response = client.send(request)

        assert isinstance(response, ReadVariableResponse)
        assert len(response.data) == 1
        transport.send.assert_called_once()

    def test_send_stale_packet_retry(self) -> None:
        """Test that stale packets are dropped and receive is retried."""
        # First response has old PDU reference, second has correct one
        stale_response = b"\x32\x03\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\xf0\x00\x00\x01\x00\x01\x00\xf0"
        correct_response = b"\x32\x03\x00\x00\x01\x00\x00\x08\x00\x00\x00\x00\xf0\x00\x00\x01\x00\x01\x00\xf0"

        transport = self.create_mock_transport([stale_response, correct_response])
        client = S7Comm(transport=transport)
        client._pdu_reference = 0  # Will become 1 after send

        request = SetupCommunicationRequest(
            parameter=SetupCommunicationParameter(
                max_amq_caller_ack=1,
                max_amq_callee_ack=1,
            )
        )
        response = client.send(request)

        assert isinstance(response, SetupCommunicationRequest)
        # Should have received twice (stale dropped, then correct)
        assert transport.receive.call_count == 2

    def test_send_packet_lost_error(self) -> None:
        """Test that PacketLostError is raised when PDU reference is higher than expected."""
        # Response has PDU reference higher than expected
        future_response = b"\x32\x03\x00\x00\x01\x05\x00\x08\x00\x00\x00\x00\xf0\x00\x00\x01\x00\x01\x00\xf0"

        transport = self.create_mock_transport([future_response])
        client = S7Comm(transport=transport)
        client._pdu_reference = 0  # Will become 1, but response has 5

        request = SetupCommunicationRequest(
            parameter=SetupCommunicationParameter(
                max_amq_caller_ack=1,
                max_amq_callee_ack=1,
            )
        )

        with pytest.raises(PacketLostError):
            client.send(request)

    def test_send_calls_transport_send(self) -> None:
        """Test that transport.send is called with serialized packet."""
        transport = self.create_mock_transport([self.SETUP_COMM_RESPONSE])
        client = S7Comm(transport=transport)

        request = SetupCommunicationRequest(
            parameter=SetupCommunicationParameter(
                max_amq_caller_ack=1,
                max_amq_callee_ack=1,
                pdu_length=480,
            )
        )
        client.send(request)

        transport.send.assert_called_once()
        # Verify payload is bytes
        call_args = transport.send.call_args
        assert call_args.kwargs.get("payload") is not None
        assert isinstance(call_args.kwargs["payload"], bytes)

    def test_send_szl_multiple_packets(self) -> None:
        expected_szl_request = (
            b"\x32\x07\x00\x00\x01\x00\x00\x08\x00\x08\x00\x01\x12\x04\x11\x44"
            b"\x01\x00\xff\x09\x00\x04\x00\x1c\x00\x00"
        )
        response1 = (
            b"\x32\x07\x00\x00\x02\x00\x00\x0c\x00\xda\x00\x01\x12\x08\x12\x84"
            b"\x01\x02\xd5\x01\x00\x00\xff\x09\x00\xd6\x00\x1c\x00\x00\x00\x22"
            b"\x00\x0a\x00\x01\x53\x37\x33\x30\x30\x2f\x45\x54\x32\x30\x30\x4d"
            b"\x20\x73\x74\x61\x74\x69\x6f\x6e\x5f\x31\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x02\x50\x4c\x43\x5f\x31\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x4f\x72\x69\x67\x69\x6e"
            b"\x61\x6c\x20\x53\x69\x65\x6d\x65\x6e\x73\x20\x45\x71\x75\x69\x70"
            b"\x6d\x65\x6e\x74\x00\x00\x00\x00\x00\x00\x00\x05\x53\x20\x43\x2d"
            b"\x42\x31\x55\x33\x39\x33\x31\x34\x32\x30\x31\x31\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x07\x43\x50"
            b"\x55\x20\x33\x31\x35\x2d\x32\x20\x50\x4e\x2f\x44\x50\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08"
        )
        response2 = (
            b"\x32\x07\x00\x00\x03\x00\x00\x0c\x00\x8a\x00\x01\x12\x08\x12\x84"
            b"\x01\x02\xd5\x00\x00\x00\xff\x09\x00\x86\x4d\x4d\x43\x20\x34\x41"
            b"\x31\x41\x43\x30\x31\x39\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x09\x00\x2a\xf6\x00"
            b"\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0a\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0b"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        )

        expected_data = (
            b"\x00\x1c\x00\x00\x00\x22\x00\x0a\x00\x01\x53\x37\x33\x30\x30\x2f"
            b"\x45\x54\x32\x30\x30\x4d\x20\x73\x74\x61\x74\x69\x6f\x6e\x5f\x31"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x50\x4c\x43\x5f"
            b"\x31\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04"
            b"\x4f\x72\x69\x67\x69\x6e\x61\x6c\x20\x53\x69\x65\x6d\x65\x6e\x73"
            b"\x20\x45\x71\x75\x69\x70\x6d\x65\x6e\x74\x00\x00\x00\x00\x00\x00"
            b"\x00\x05\x53\x20\x43\x2d\x42\x31\x55\x33\x39\x33\x31\x34\x32\x30"
            b"\x31\x31\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x07\x43\x50\x55\x20\x33\x31\x35\x2d\x32\x20\x50\x4e"
            b"\x2f\x44\x50\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x08"
            b"\x4d\x4d\x43\x20\x34\x41\x31\x41\x43\x30\x31\x39"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x09\x00\x2a\xf6\x00\x00\x01\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x0a\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0b\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        )

        transport = self.create_mock_transport([response1, response2])
        client = S7Comm(transport=transport)
        data = struct.pack("!HH", 0x001C, 0x0000)  # szl_id, szl_index
        request = UserDataRequest.create(
            function_group=UserdataFunction.CPU_FUNCTION,
            subfunction=SubfunctionCode.READ_SZL,
            data=data,
        )
        client._pdu_reference = 1
        packet = client._create_packet(request=request, pdu_reference=client._pdu_reference)
        assert packet == expected_szl_request
        response = client.send(request)
        assert response.data.data == expected_data


class TestS7CommValidatePduReference:
    """Tests for S7Comm._validate_pdu_reference() method."""

    def test_validate_matching_pdu_reference(self) -> None:
        """Test that matching PDU reference passes validation."""
        transport = Mock()
        client = S7Comm(transport=transport)
        client._pdu_reference = 0  # Current is 0

        # Create a mock response with matching PDU reference
        response = Mock()
        response.header = Mock()
        response.header.pdu_reference = 1  # After send, it will be 1

        # Should not raise
        client._pdu_reference = 1
        client._validate_pdu_reference(response)

    def test_validate_stale_pdu_reference(self) -> None:
        """Test that stale PDU reference raises StalePacketError."""
        transport = Mock()
        client = S7Comm(transport=transport)
        client._pdu_reference = 5  # Current is 5

        response = Mock()
        response.header = Mock()
        response.header.pdu_reference = 3  # Old reference

        with pytest.raises(StalePacketError):
            client._validate_pdu_reference(response)

    def test_validate_future_pdu_reference(self) -> None:
        """Test that future PDU reference raises PacketLostError."""
        transport = Mock()
        client = S7Comm(transport=transport)
        client._pdu_reference = 1  # Current is 1

        response = Mock()
        response.header = Mock()
        response.header.pdu_reference = 5  # Future reference

        with pytest.raises(PacketLostError):
            client._validate_pdu_reference(response)
