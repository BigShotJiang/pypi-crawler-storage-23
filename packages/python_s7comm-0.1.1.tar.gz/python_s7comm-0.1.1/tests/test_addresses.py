from typing import Any

import pytest

from python_s7comm.s7comm.enums import Area, DataType
from python_s7comm.s7comm.packets.variable_address import VariableAddress


valid_address_cases: list[tuple[str, dict[Any, Any]]] = [
    ("DB1.23.4 BYTE 999", dict(area=Area.DB, db_number=1, start=23, data_type=DataType.BYTE, start_bit=4, amount=999)),
    ("DB100.2000 BYTE 10", dict(area=Area.DB, db_number=100, start=2000, data_type=DataType.BYTE, amount=10)),
    ("M123.5 BOOL 1", dict(area=Area.M, db_number=0, start=123, data_type=DataType.BOOL, start_bit=5, amount=1)),
    ("DB1000.20000 INT 10", dict(area=Area.DB, db_number=1000, start=20000, data_type=DataType.INT, amount=10)),
    ("M123.5 BOOL 1", dict(area=Area.M, db_number=0, start=123, data_type=DataType.BOOL, start_bit=5, amount=1)),
    ("I0.0 DINT 1", dict(area=Area.I, db_number=0, start=0, data_type=DataType.DINT, amount=1)),
    ("Q65535 DWORD 5", dict(area=Area.Q, db_number=0, start=65535, data_type=DataType.DWORD, amount=5)),
    ("C1000 REAL 2", dict(area=Area.C, db_number=0, start=1000, data_type=DataType.REAL, amount=2)),
]

invalid_address_format_cases: list[str] = [
    "INVALID_FORMAT",
    "DB100.2000.3000 BYTE 10",  # Extra dot between start address and bit number
    "Q100.65535 DWORD 5 EXTRA",  # Extra token at the end
    "C500.1000 REAL",  # Missing amount
]

invalid_db_number_cases: list[str] = [
    "DB99999.100 BYTE 1",  # DB number exceeds the maximum limit
    "DB-100.200 BYTE 1",  # Negative DB number
    "DBA.200 BYTE 1",  # Non-numeric DB number
    "DB.200 BYTE 1",  # Missing DB number
]

invalid_start_address_cases: list[str] = [
    "DB100.99999 BYTE 1",  # Start address exceeds the maximum limit
    "M-10.5 BYTE 1",  # Negative start address
    "MABC.5 BYTE 1",  # Non-numeric start address
    "M.5 BYTE 1",  # Missing start address
]

invalid_start_bit_cases: list[str] = [
    "M123.8 BOOL 1",  # Start bit exceeds the maximum limit
    "M123.-1 BOOL 1",  # Negative start bit
    "M123.A BOOL 1",  # Non-numeric start bit
]

invalid_amount_cases: list[str] = [
    "DB100.2000 BYTE ABC",  # Non-numeric amount
    "I0.0 BYTE -1",  # Negative amount
    "Q100.65535 DWORD",  # Missing amount
    "C500.1000 REAL 2.5",  # Float value for amount
    "M123.5 BOOL 0x10",  # Hexadecimal value for amount
]


@pytest.mark.parametrize("address_str, parameters_dict", valid_address_cases)
def test_from_string_valid_address(address_str: str, parameters_dict: dict[Any, Any]) -> None:
    result = VariableAddress.from_string(address_str)
    expected = VariableAddress(**parameters_dict)
    assert result == expected


@pytest.mark.parametrize("address_str", invalid_address_format_cases)
def test_from_string_invalid_address_format(address_str: str) -> None:
    with pytest.raises(ValueError):
        VariableAddress.from_string(address_str)


@pytest.mark.parametrize("address_str", invalid_db_number_cases)
def test_from_string_invalid_db_number(address_str: str) -> None:
    with pytest.raises(ValueError):
        VariableAddress.from_string(address_str)


@pytest.mark.parametrize("address_str", invalid_start_address_cases)
def test_from_string_invalid_start_address(address_str: str) -> None:
    with pytest.raises(ValueError):
        VariableAddress.from_string(address_str)


@pytest.mark.parametrize("address_str", invalid_start_bit_cases)
def test_from_string_invalid_start_bit(address_str: str) -> None:
    with pytest.raises(ValueError):
        VariableAddress.from_string(address_str)


@pytest.mark.parametrize("address_str", invalid_amount_cases)
def test_from_string_invalid_amount(address_str: str) -> None:
    with pytest.raises(ValueError):
        VariableAddress.from_string(address_str)
