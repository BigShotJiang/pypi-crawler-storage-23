from python_s7comm.s7comm import enums
from python_s7comm.s7comm.packets.user_data import UserDataResponseParameter
from python_s7comm.s7comm.szl import (
    CPUStateDataTree,
    ModuleIdentificationDataTree,
    SZLResponseData,
)


# @pytest.mark.skip("Need to fix")  # type: ignore[misc]
# def test_read_szl_list_request() -> None:
#     expected = (
#         b"\x32\x07\x00\x00\x00\x00\x00\x08\x00\x08\x00\x01\x12\x04\x11\x44\x01\x00\xff\x09\x00\x04\x00\x00\x00\x00"
#     )
#     szl_pdu = BaseS7Comm().create_szl_pdu(szl_id=0x0000, szl_index=0x000)
#     assert szl_pdu == expected


def test_parse_response_parameter() -> None:
    packet = b"\x00\x01\x12\x08\x12\x84\x01\x01\x00\x00\x00\x00"
    parameter = UserDataResponseParameter.parse(packet)
    # assert parameter.head == b"\x00\x01\x12"
    assert parameter.length == 8
    assert parameter.method == enums.UserdataMethod.RESPONSE
    assert parameter.type == enums.TransmissionType.RESPONSE
    assert parameter.function_group == enums.UserdataFunction.CPU_FUNCTION
    assert parameter.subfunction == enums.SubfunctionCode.READ_SZL
    assert parameter.sequence_number == 1
    assert parameter.data_unit_reference == 0
    assert parameter.last_data_unit == enums.UserdataLastPDU.YES
    assert parameter.error_code == 0


def test_parse_cpu_state_response_data() -> None:
    # datahead b'\xff\x09\x00\x14'
    packet = b"\x00\x00\x00\x00\x00\x02\x00\x06\x00\x00\x00\x11\x01\x11\x0f\x11\x04\x24\x01\x31"
    parameter = SZLResponseData.parse(packet)
    assert parameter.szl_id == 0
    assert parameter.szl_index == 0
    assert parameter.szl_data_tree_list == [b"\x00\x00", b"\x00\x11", b"\x01\x11", b"\x0f\x11", b"\x04$", b"\x011"]


def test_parse_cpu_state_data_tree() -> None:
    input = b"\x02\x51\xff\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    expected = enums.CPUStatus.RUN
    result = CPUStateDataTree.parse(input)
    assert result.requested_mode == expected


def test_parse_cpu_order_code_data() -> None:
    input = (
        # b"\xFF"  # return code
        # b"\x09"  # transport size
        # b"\x00\x78"  # length
        b"\x00\x11"  # szl-id
        b"\x00\x00"  # szl-index
        b"\x00\x1c"  # szl partial list length
        b"\x00\x04"  # szl partial list count
        b"\x00\x01\x36\x45\x53\x37\x20\x32\x31\x34\x2d"
        b"\x31\x48\x47\x34\x30\x2d\x30\x58\x42\x30\x20\x00\x00\x00\x02\x20\x20"
        b"\x00\x06\x36\x45\x53\x37\x20\x32\x31\x34\x2d"
        b"\x31\x48\x47\x34\x30\x2d\x30\x58\x42\x30\x20\x00\x00\x00\x02\x20\x20"
        b"\x00\x07\x36\x45\x53\x37\x20\x32\x31\x34\x2d"
        b"\x31\x48\x47\x34\x30\x2d\x30\x58\x42\x30\x20\x00\x00\x56\x04\x01\x00"
        b"\x00\x81\x42\x6f\x6f\x74\x20\x4c\x6f\x61\x64"
        b"\x65\x72\x20\x20\x20\x20\x20\x20\x20\x20\x20\x00\x00\x41\x20\x09\x09"
    )
    response = SZLResponseData.parse(input)
    assert len(response.szl_data_tree_list) == 4
    assert ModuleIdentificationDataTree.parse(response.szl_data_tree_list[3]).order_number.strip() == "Boot Loader"


def test_parse_cpu_order_code_data_tree() -> None:
    module_identification = (
        b"\x00\x01"  # Index: Identification of the module (0x0001)
        b"\x36\x45\x53\x37\x20\x32\x31\x34\x2d\x31\x48\x47\x34\x30\x2d\x30\x58\x42\x30\x20"  # MlfB (Order number)
        b"\x00\x00"  # BGTyp (Module type ID): 0x0000
        b"\x00\x02"  # Ausbg (Version of the module or release of the operating system): 2
        b"\x20\x20"  # Ausbe (Release of the PG description file): 8224
    )
    result = ModuleIdentificationDataTree.parse(module_identification)
    assert "6ES7 214-1HG40-0XB0 " == result.order_number
    assert 0x0001 == result.index

    hardware_identification = (
        b"\x00\x06"  # Index: Identification of the basic hardware (0x0006)
        b"\x36\x45\x53\x37\x20\x32\x31\x34\x2d\x31\x48\x47\x34\x30\x2d\x30\x58\x42\x30\x20"  # MlfB (Order number)
        b"\x00\x00"  # BGTyp (Module type ID): 0x0000
        b"\x00\x02"  # Ausbg (Version of the module or release of the operating system): 2
        b"\x20\x20"  # Ausbe (Release of the PG description file): 8224
    )
    result = ModuleIdentificationDataTree.parse(hardware_identification)
    assert "6ES7 214-1HG40-0XB0 " == result.order_number
    assert 0x0006 == result.index

    software_identification = (
        b"\x00\x07"  # Index: Identification of the basic firmware (0x0007)
        b"\x36\x45\x53\x37\x20\x32\x31\x34\x2d\x31\x48\x47\x34\x30\x2d\x30\x58\x42\x30\x20"  # MlfB (Order number)
        b"\x00\x00"  # BGTyp (Module type ID): 0x0000
        b"\x56\x04"  # Ausbg (Version of the module or release of the operating system): 22020
        b"\x01\x00"  # Ausbe (Release of the PG description file): 256
    )
    result = ModuleIdentificationDataTree.parse(software_identification)
    assert "6ES7 214-1HG40-0XB0 " == result.order_number
    assert 0x0007 == result.index
