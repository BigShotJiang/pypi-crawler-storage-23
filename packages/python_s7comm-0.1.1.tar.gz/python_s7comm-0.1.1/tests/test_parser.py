import pytest

from python_s7comm.s7comm.enums import MessageType
from python_s7comm.s7comm.packets.error import S7Error
from python_s7comm.s7comm.packets.parser import S7PacketParser
from python_s7comm.s7comm.packets.rw_variable import ReadVariableResponse
from python_s7comm.s7comm.packets.setup_communication import SetupCommunicationRequest


class TestS7PacketParserSetupCommunication:
    def test_parse_setup_communication_response(self) -> None:
        # SetupCommunication response from S1200
        packet = b"\x32\x03\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\xf0\x00\x00\x01\x00\x01\x00\xf0"
        response = S7PacketParser.parse(packet)

        assert isinstance(response, SetupCommunicationRequest)
        assert response.header is not None
        assert response.header.message_type == MessageType.Response
        assert response.parameter.max_amq_caller_ack == 1
        assert response.parameter.max_amq_callee_ack == 1
        assert response.parameter.pdu_length == 240  # 0x00F0

    def test_parse_setup_communication_request(self) -> None:
        # SetupCommunication request (JobRequest)
        packet = b"\x32\x01\x00\x00\x00\x00\x00\x08\x00\x00\xf0\x00\x00\x01\x00\x01\x01\xe0"
        response = S7PacketParser.parse(packet)

        assert isinstance(response, SetupCommunicationRequest)
        assert response.header is not None
        assert response.header.message_type == MessageType.JobRequest
        assert response.parameter.pdu_length == 480  # 0x01E0


class TestS7PacketParserReadVariable:
    def test_parse_read_variable_response(self) -> None:
        # ReadVariable response with REAL data
        packet = (
            b"\x32\x03\x00\x00\x01\x00\x00\x02\x00\x0c\x00\x00\x04\x01\xff\x07\x00\x08\x42\xf6\xe6\x66\x44\x07\xcd\x71"
        )
        response = S7PacketParser.parse(packet)

        assert isinstance(response, ReadVariableResponse)
        assert response.header is not None
        assert response.header.message_type == MessageType.Response
        assert len(response.data) == 1
        assert response.data[0].return_code == 0xFF
        assert response.data[0].transport_size == 7
        assert response.data[0].data == b"\x42\xf6\xe6\x66\x44\x07\xcd\x71"


class TestS7PacketParserErrors:
    def test_parse_invalid_protocol_id(self) -> None:
        # Invalid protocol ID (not 0x32)
        packet = b"\x33\x03\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\xf0\x00\x00\x01\x00\x01\x00\xf0"
        with pytest.raises(ValueError, match="Invalid protocol id"):
            S7PacketParser.parse(packet)

    def test_parse_error_response(self) -> None:
        # Response with error class != 0 (error_class=0x81, error_code=0x04)
        packet = b"\x32\x03\x00\x00\x00\x00\x00\x02\x00\x00\x81\x04\xf0\x00"
        response = S7PacketParser.parse(packet)

        assert isinstance(response, S7Error)
        assert response.header is not None
        assert response.header.error_class == 0x81


class TestS7PacketParserMessageTypes:
    @pytest.mark.parametrize(
        "message_type_byte,expected_type",
        [
            (0x01, MessageType.JobRequest),
            (0x03, MessageType.Response),
        ],
    )
    def test_parse_message_type(self, message_type_byte: int, expected_type: MessageType) -> None:
        # Build minimal valid packet with different message types
        if message_type_byte == 0x01:  # JobRequest
            packet = b"\x32\x01\x00\x00\x00\x00\x00\x08\x00\x00\xf0\x00\x00\x01\x00\x01\x01\xe0"
        else:  # Response
            packet = b"\x32\x03\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\xf0\x00\x00\x01\x00\x01\x00\xf0"

        response = S7PacketParser.parse(packet)
        assert response.header is not None
        assert response.header.message_type == expected_type
