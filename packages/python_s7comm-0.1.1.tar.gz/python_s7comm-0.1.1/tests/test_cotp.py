from python_s7comm.s7comm.transport.cotp import COTP, ConnectionTPDU, Data, TPDUType
from python_s7comm.s7comm.transport.cotp.parameters import DestinationTSAP, SourceTSAP, TPDUSize


def test_serialize_connection_request() -> None:
    expected = b"\x11\xe0\x00\x00\x00\x01\x00\xc0\x01\x0a\xc1\x02\x00\x01\xc2\x02\x01\x01"
    cr = COTP(tpdu_size=1024, source_tsap=1, dest_tsap=257).create_connection_packet(tpdu_type=TPDUType.CR)
    assert cr.serialize() == expected


def test_parse_connection_request() -> None:
    input = b"\x11\xe0\x00\x00\x00\x01\x00\xc0\x01\x0a\xc1\x02\x00\x01\xc2\x02\x01\x01"
    expected_parameters = {
        0xC0: TPDUSize(value=1024),
        0xC1: SourceTSAP(value=1),
        0xC2: DestinationTSAP(value=257),
    }
    cr = COTP.parse(input)
    assert isinstance(cr, ConnectionTPDU)
    assert cr.class_option == 0
    assert cr.src_ref == 1
    assert cr.dst_ref == 0
    assert cr.parameters == expected_parameters


def test_serialize_connection_confirm() -> None:
    expected = b"\x11\xd0\x00\x01\x00\x11\x00\xc0\x01\x0a\xc1\x02\x01\x00\xc2\x02\x01\x01"
    cc = COTP(tpdu_size=1024, source_tsap=256, dest_tsap=257, dst_ref=1, src_ref=17).create_connection_packet(
        tpdu_type=TPDUType.CC
    )
    assert cc.serialize() == expected


def test_parse_connection_confirm() -> None:
    cc_bytes = b"\x11\xd0\x00\x01\x00\x11\x00\xc0\x01\x0a\xc1\x02\x01\x00\xc2\x02\x01\x01"
    expected_parameters = {
        0xC0: TPDUSize(value=1024),
        0xC1: SourceTSAP(value=256),
        0xC2: DestinationTSAP(value=257),
    }
    cc = ConnectionTPDU.parse(cc_bytes)
    assert cc.dst_ref == 1
    assert cc.src_ref == 17
    assert cc.class_option == 0
    assert cc.tpdu_type == TPDUType.CC
    assert cc.parameters == expected_parameters


def test_serializer_cotp_data() -> None:
    expected = b"\x02\xf0\x80\x32\x01\x00\x00\x00\x00\x00\x08\x00\x00\xf0\x00\x00\x01\x00\x01\x01\xe0"
    dt = Data(eot=True, tpdu_nr=0, user_data=expected[3:])
    assert dt.serialize() == expected


def test_parse_cotp_data() -> None:
    dt_bytes = b"\x02\xf0\x80\x32\x01\x00\x00\x00\x00\x00\x08\x00\x00\xf0\x00\x00\x01\x00\x01\x01\xe0"
    dt = Data.parse(dt_bytes)
    assert dt.eot
    assert dt.tpdu_nr == 0
    assert dt.user_data == bytearray(dt_bytes[3:])
