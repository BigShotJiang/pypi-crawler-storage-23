from django.contrib import admin

# Utilities admin configurations will be added here as needed