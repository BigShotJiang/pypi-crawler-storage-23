"""Charter — AI governance layer."""

__version__ = "1.5.0"
