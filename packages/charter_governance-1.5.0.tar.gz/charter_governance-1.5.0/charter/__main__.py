"""Allow running as python -m charter."""

from charter.cli import main

main()
