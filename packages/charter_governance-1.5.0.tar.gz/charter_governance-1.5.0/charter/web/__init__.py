"""Charter web dashboard."""
