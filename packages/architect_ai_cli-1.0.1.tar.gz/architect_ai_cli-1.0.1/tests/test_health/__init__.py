"""Tests para Code Health Delta (v4-D2)."""
