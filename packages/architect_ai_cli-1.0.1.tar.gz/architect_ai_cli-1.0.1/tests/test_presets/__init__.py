"""Tests para Preset Configs (v4-D5)."""
