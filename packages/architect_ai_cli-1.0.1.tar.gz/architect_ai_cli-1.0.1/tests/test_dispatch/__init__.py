"""Tests para el sistema de sub-agentes / dispatch (v4-D1)."""
