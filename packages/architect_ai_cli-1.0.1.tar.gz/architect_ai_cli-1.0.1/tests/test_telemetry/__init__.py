"""Tests para OpenTelemetry integration (v4-D4)."""
