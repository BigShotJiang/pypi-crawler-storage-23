"""
architect - Herramienta CLI headless y agentica para orquestar agentes de IA.
"""

__version__ = "1.0.1"
