"""
Execution Engine - Orquestador central de ejecución de tools.

El ExecutionEngine es el punto de paso obligatorio para toda ejecución
de tools. Aplica validación, políticas de confirmación, dry-run y logging.

v3-M4: Añadido soporte para PostEditHooks (auto-verificación post-edición).
v4-A1: Integración con el sistema de hooks completo (pre/post tool hooks).
"""

from typing import TYPE_CHECKING, Any

import structlog

from ..config.schema import AppConfig
from ..tools.base import BaseTool, ToolResult
from ..tools.registry import ToolNotFoundError, ToolRegistry
from .policies import ConfirmationPolicy, NoTTYError

if TYPE_CHECKING:
    from ..core.guardrails import GuardrailsEngine
    from ..core.hooks import HookExecutor

logger = structlog.get_logger()


class ExecutionEngine:
    """Motor de ejecución de tools con validación y políticas.

    El ExecutionEngine aplica un pipeline completo a cada tool call:
    1. Buscar tool en registry
    2. Validar argumentos (Pydantic)
    3. Validar paths si aplica (ya dentro de cada tool)
    4. Aplicar política de confirmación
    5. Ejecutar (o simular en dry-run)
    6. Loggear resultado
    7. Retornar resultado (nunca excepción)

    Características clave:
    - NUNCA lanza excepciones al caller (siempre retorna ToolResult)
    - Soporta dry-run (simulación sin efectos secundarios)
    - Aplica políticas de confirmación configurables
    - Logging estructurado de todas las operaciones
    - Hooks pre/post tool integrados (v4-A1)
    """

    def __init__(
        self,
        registry: ToolRegistry,
        config: AppConfig,
        confirm_mode: str | None = None,
        hook_executor: "HookExecutor | None" = None,
        guardrails: "GuardrailsEngine | None" = None,
    ):
        """Inicializa el execution engine.

        Args:
            registry: ToolRegistry con las tools disponibles
            config: Configuración completa de la aplicación
            confirm_mode: Override del modo de confirmación (opcional)
            hook_executor: HookExecutor para pre/post hooks (v4-A1)
            guardrails: GuardrailsEngine para seguridad determinista (v4-A2)
        """
        self.registry = registry
        self.config = config
        self.dry_run = False
        self.hook_executor = hook_executor
        self.guardrails = guardrails

        # Determinar modo de confirmación
        # Prioridad: argumento confirm_mode > config de agente > default
        mode = confirm_mode or "confirm-sensitive"
        self.policy = ConfirmationPolicy(mode)

        self.log = logger.bind(component="execution_engine")

    def execute_tool_call(self, tool_name: str, args: dict[str, Any]) -> ToolResult:
        """Ejecuta una tool call con el pipeline completo.

        Este es el método principal del ExecutionEngine. Aplica todas
        las validaciones y políticas antes de ejecutar la tool.

        Args:
            tool_name: Nombre de la tool a ejecutar
            args: Diccionario con argumentos sin validar

        Returns:
            ToolResult con el resultado de la ejecución o error

        Note:
            Este método NUNCA lanza excepciones. Todos los errores se
            capturan y retornan como ToolResult con success=False.
        """
        self.log.info(
            "tool.call.start",
            tool=tool_name,
            args=self._sanitize_args_for_log(args),
            dry_run=self.dry_run,
        )

        try:
            # 1. Buscar tool en registry
            try:
                tool = self.registry.get(tool_name)
            except ToolNotFoundError as e:
                self.log.error("tool.not_found", tool=tool_name)
                return ToolResult(
                    success=False,
                    output="",
                    error=str(e),
                )

            # 2. Validar argumentos con Pydantic
            try:
                validated_args = tool.validate_args(args)
            except Exception as e:
                self.log.error("tool.validation_error", tool=tool_name, error=str(e))
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Argumentos inválidos: {e}",
                )

            # 3. Aplicar política de confirmación
            # run_command usa clasificación dinámica por comando (no solo tool.sensitive)
            if tool.name == "run_command":
                command_str = validated_args.model_dump().get("command", "")
                needs_confirm = self._should_confirm_command(command_str, tool)
            else:
                needs_confirm = self.policy.should_confirm(tool)

            if needs_confirm:
                try:
                    confirmed = self.policy.request_confirmation(
                        tool_name,
                        args,
                        dry_run=self.dry_run,
                    )

                    if not confirmed:
                        self.log.info("tool.cancelled", tool=tool_name)
                        return ToolResult(
                            success=False,
                            output="",
                            error="Operación cancelada por el usuario",
                        )

                except NoTTYError as e:
                    self.log.error("tool.no_tty", tool=tool_name)
                    return ToolResult(
                        success=False,
                        output="",
                        error=str(e),
                    )

            # 4. Ejecutar (o simular en dry-run)
            if self.dry_run:
                self.log.info(
                    "tool.dry_run",
                    tool=tool_name,
                    args=validated_args.model_dump(),
                )
                return ToolResult(
                    success=True,
                    output=f"[DRY-RUN] Se ejecutaría {tool_name} con args: {validated_args.model_dump()}",
                )

            # 5. Ejecución real
            try:
                result = tool.execute(**validated_args.model_dump())
            except Exception as e:
                # Las tools NO deberían lanzar excepciones, pero
                # capturamos por si acaso (defensive programming)
                self.log.error(
                    "tool.execution_error",
                    tool=tool_name,
                    error=str(e),
                    error_type=type(e).__name__,
                )
                result = ToolResult(
                    success=False,
                    output="",
                    error=f"Error interno de la tool: {e}",
                )

            # 6. Record edit for guardrails tracking
            if result.success and self.guardrails and tool_name in ("write_file", "edit_file"):
                self.guardrails.record_edit()

            # 7. Loggear resultado
            self.log.info(
                "tool.call.complete",
                tool=tool_name,
                success=result.success,
                output_length=len(result.output) if result.output else 0,
                has_error=result.error is not None,
            )

            return result

        except Exception as e:
            # Captura de último recurso para errores inesperados
            # en el propio ExecutionEngine
            self.log.error(
                "engine.unexpected_error",
                tool=tool_name,
                error=str(e),
                error_type=type(e).__name__,
            )
            return ToolResult(
                success=False,
                output="",
                error=f"Error inesperado en el execution engine: {e}",
            )

    def check_guardrails(
        self, tool_name: str, tool_input: dict[str, Any]
    ) -> ToolResult | None:
        """Verifica guardrails ANTES de ejecutar un tool (v4-A2).

        Los guardrails se evalúan antes que los hooks de usuario.
        Son la capa de seguridad determinista que el LLM no puede saltarse.

        Args:
            tool_name: Nombre del tool a ejecutar.
            tool_input: Argumentos del tool.

        Returns:
            ToolResult con error si un guardrail bloqueó, None si todo OK.
        """
        if not self.guardrails:
            return None

        # Verificar archivos protegidos
        if tool_name in ("write_file", "edit_file", "delete_file", "apply_patch"):
            file_path = tool_input.get("path", "")
            allowed, reason = self.guardrails.check_file_access(file_path, tool_name)
            if not allowed:
                return ToolResult(success=False, output=f"Guardrail: {reason}")

        # Verificar comandos bloqueados
        if tool_name == "run_command":
            command = tool_input.get("command", "")
            allowed, reason = self.guardrails.check_command(command)
            if not allowed:
                return ToolResult(success=False, output=f"Guardrail: {reason}")
            self.guardrails.record_command()

        # Verificar límites de edición
        if tool_name in ("write_file", "edit_file", "apply_patch"):
            file_path = tool_input.get("path", "")
            content = tool_input.get("content", "")
            lines = content.count("\n") + 1 if content else 0
            allowed, reason = self.guardrails.check_edit_limits(file_path, lines_added=lines)
            if not allowed:
                return ToolResult(success=False, output=f"Guardrail: {reason}")

        return None

    def check_code_rules(
        self, tool_name: str, tool_input: dict[str, Any]
    ) -> list[str]:
        """Escanea contenido contra code_rules ANTES de ejecutar (v4-A2).

        Args:
            tool_name: Nombre del tool ejecutado.
            tool_input: Argumentos del tool.

        Returns:
            Lista de mensajes de warning/block.
        """
        if not self.guardrails:
            return []

        if tool_name not in ("write_file", "edit_file"):
            return []

        content = tool_input.get("content", "") or tool_input.get("new_str", "")
        if not content:
            return []

        file_path = tool_input.get("path", "")
        violations = self.guardrails.check_code_rules(content, file_path)

        messages: list[str] = []
        for severity, msg in violations:
            if severity == "block":
                messages.append(f"BLOQUEADO por code rule: {msg}")
            else:
                messages.append(f"Aviso code rule: {msg}")

        return messages

    def run_pre_tool_hooks(
        self, tool_name: str, tool_input: dict[str, Any]
    ) -> ToolResult | dict[str, Any] | None:
        """Ejecuta pre-tool hooks (v4-A1).

        Args:
            tool_name: Nombre del tool a ejecutar.
            tool_input: Argumentos originales del tool.

        Returns:
            - ToolResult si un hook bloqueó la acción (con blocked_by_hook info)
            - dict con input actualizado si un hook lo modificó
            - None si todos permiten la acción sin modificación
        """
        if not self.hook_executor or self.dry_run:
            return None

        from ..core.hooks import HookDecision, HookEvent

        context: dict[str, Any] = {"tool_name": tool_name}
        file_path = tool_input.get("path") or tool_input.get("file_path")
        if file_path:
            context["file_path"] = str(file_path)
        if "command" in tool_input:
            context["command"] = tool_input["command"]

        results = self.hook_executor.run_event(
            HookEvent.PRE_TOOL_USE,
            context,
            stdin_data={"tool_name": tool_name, "tool_input": tool_input},
        )

        updated_input: dict[str, Any] | None = None
        additional_contexts: list[str] = []

        for result in results:
            if result.decision == HookDecision.BLOCK:
                return ToolResult(
                    success=False,
                    output=f"Bloqueado por hook: {result.reason}",
                    error=f"Hook bloqueó la acción: {result.reason}",
                )
            if result.decision == HookDecision.MODIFY and result.updated_input:
                updated_input = result.updated_input
            if result.additional_context:
                additional_contexts.append(result.additional_context)

        if updated_input:
            return updated_input

        return None

    def run_post_tool_hooks(
        self, tool_name: str, tool_input: dict[str, Any], tool_output: str, success: bool
    ) -> str | None:
        """Ejecuta post-tool hooks (v4-A1).

        Args:
            tool_name: Nombre del tool ejecutado.
            tool_input: Argumentos del tool.
            tool_output: Output del tool (truncado).
            success: Si el tool se ejecutó exitosamente.

        Returns:
            Texto con contexto adicional de los hooks, o None.
        """
        if not self.hook_executor or self.dry_run:
            return None

        from ..core.hooks import HookEvent

        context: dict[str, Any] = {
            "tool_name": tool_name,
            "tool_result_success": str(success),
        }
        file_path = tool_input.get("path") or tool_input.get("file_path")
        if file_path:
            context["file_path"] = str(file_path)

        results = self.hook_executor.run_event(
            HookEvent.POST_TOOL_USE,
            context,
            stdin_data={
                "tool_name": tool_name,
                "tool_input": tool_input,
                "tool_output": tool_output[:2000],
            },
        )

        outputs: list[str] = []
        for result in results:
            if result.additional_context:
                outputs.append(result.additional_context)

        return "\n".join(outputs) if outputs else None

    def _sanitize_args_for_log(self, args: dict[str, Any]) -> dict[str, Any]:
        """Sanitiza argumentos para logging seguro.

        Trunca valores muy largos (como content) para evitar
        logs masivos.

        Args:
            args: Argumentos originales

        Returns:
            Diccionario sanitizado para logging
        """
        sanitized = {}
        for key, value in args.items():
            if isinstance(value, str) and len(value) > 200:
                sanitized[key] = value[:200] + f"... ({len(value)} chars total)"
            else:
                sanitized[key] = value

        return sanitized

    def _should_confirm_command(self, command: str, tool: Any) -> bool:
        """Determina si un comando run_command requiere confirmación.

        Implementa una tabla de sensibilidad dinámica para run_command (F13),
        overridando la política estática basada en tool.sensitive:

        | Clasificación | yolo | confirm-sensitive | confirm-all |
        |---------------|------|-------------------|-------------|
        | safe          | No   | No                | Sí          |
        | dev           | No   | Sí                | Sí          |
        | dangerous     | No   | Sí                | Sí          |

        En modo yolo NUNCA se pide confirmación. La seguridad está garantizada
        por la blocklist (Capa 1) que impide comandos realmente peligrosos.
        Los comandos "dangerous" son simplemente comandos no reconocidos en
        las listas safe/dev, no necesariamente peligrosos.

        Args:
            command: El comando que se va a ejecutar
            tool: La instancia de RunCommandTool (con classify_sensitivity())

        Returns:
            True si se debe solicitar confirmación al usuario
        """
        classification = tool.classify_sensitivity(command)
        match self.policy.mode:
            case "yolo":
                return False
            case "confirm-sensitive":
                return classification in ("dev", "dangerous")
            case "confirm-all":
                return True
            case _:
                return True

    def set_dry_run(self, enabled: bool) -> None:
        """Habilita o deshabilita el modo dry-run.

        Args:
            enabled: True para habilitar dry-run, False para deshabilitar
        """
        self.dry_run = enabled
        self.log.info("engine.dry_run_mode", enabled=enabled)

    def __repr__(self) -> str:
        return (
            f"<ExecutionEngine("
            f"tools={self.registry.count()}, "
            f"mode={self.policy.mode}, "
            f"dry_run={self.dry_run})>"
        )
