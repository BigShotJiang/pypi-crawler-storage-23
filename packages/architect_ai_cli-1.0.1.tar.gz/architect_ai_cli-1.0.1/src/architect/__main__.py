"""
Entry point para ejecutar architect como módulo: python -m architect
"""

from .cli import main

if __name__ == "__main__":
    main()
