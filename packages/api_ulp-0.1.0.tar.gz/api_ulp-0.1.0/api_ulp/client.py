import requests

API_URL = "https://api-1-wi9u.onrender.com/api/search"


class ApiUlp:
    """
    Client for the ULP API.

    Usage:
        client = ApiUlp(api_key="YOUR_API_KEY")
        results = client.search(query="hello", limit=10)
        print(results)
    """

    def __init__(self, api_key: str):
        """
        Initialize the ApiUlp client.

        Args:
            api_key (str): Your ULP API key.
        """
        if not api_key or not isinstance(api_key, str):
            raise ValueError("A valid API key string is required.")
        self.api_key = api_key
        self._headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

    def search(self, query: str, limit: int = 100) -> dict:
        """
        Perform a search against the ULP API.

        Args:
            query (str): The search term / target.
            limit (int): Maximum number of results to return (default: 100).

        Returns:
            dict: Parsed JSON response from the API.

        Raises:
            ValueError: If query is empty or limit is not a positive integer.
            requests.HTTPError: If the API returns an error status code.
            requests.ConnectionError: If the API cannot be reached.
            requests.Timeout: If the request times out.
        """
        if not query or not isinstance(query, str):
            raise ValueError("'query' must be a non-empty string.")
        if not isinstance(limit, int) or limit <= 0:
            raise ValueError("'limit' must be a positive integer.")

        payload = {
            "query": query,
            "limit": limit,
        }

        try:
            response = requests.post(
                API_URL,
                headers=self._headers,
                json=payload,
                timeout=30,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as http_err:
            status = response.status_code
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise requests.exceptions.HTTPError(
                f"HTTP {status} error from ULP API: {detail}"
            ) from http_err
        except requests.exceptions.ConnectionError as conn_err:
            raise requests.exceptions.ConnectionError(
                "Could not connect to the ULP API. Check your internet connection."
            ) from conn_err
        except requests.exceptions.Timeout as timeout_err:
            raise requests.exceptions.Timeout(
                "The request to the ULP API timed out after 30 seconds."
            ) from timeout_err
