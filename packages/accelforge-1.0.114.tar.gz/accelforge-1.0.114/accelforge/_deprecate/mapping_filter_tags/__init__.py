from .ffmt import get_ffmt_tag
from .onesplit import get_one_split_tag
