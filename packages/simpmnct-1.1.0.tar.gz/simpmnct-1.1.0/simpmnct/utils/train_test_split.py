import numpy as np

def train_test_split(X,y,test_size=0.2,out_split=False,out_shape=False,out_index=False):
    X = np.array(X)
    y = np.array(y)
    n_sample = X.shape[0]
    indices = np.arange(n_sample)
    np.random.shuffle(indices)
    n_test = int(n_sample*test_size)
    test_index = indices[:n_test]
    train_index = indices[n_test:]
    X_train = X[train_index]
    X_test = X[test_index]
    y_train = y[train_index]
    y_test = y[test_index]
    if out_split:
        print("Train-Test Split Explain")
        print()
        print("Total samples =", n_sample)
        print("Test size =", test_size)
        print("Train size =", 1-test_size)
        print()
    if out_shape:
        print("Shape:")
        print("X_train =", X_train.shape)
        print("X_test =", X_test.shape)
        print("y_train =", y_train.shape)
        print("y_test =", y_test.shape)
        print()
    if out_index:
        print("Train index =", train_index)
        print("Test index =", test_index)
        print()
    return X_train, X_test, y_train, y_test