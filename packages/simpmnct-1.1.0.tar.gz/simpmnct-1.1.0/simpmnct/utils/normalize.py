import numpy as np

def normalize(X,out_stat=False,out_formula=False,out_data=False):
    X = np.array(X)
    mean = np.mean(X, axis=0)
    std = np.std(X, axis=0)
    std[std ==0] = 1
    X_norm = (X - mean) / std
    if out_formula:
        print("Normalize Explain")
        print()
        print("Formula:")
        print("X_norm = (X - mean) / std")
        print()
    if out_stat:
        print("Statistics")
        print("Mean =",mean)
        print("Std =",std)
        print()
    if out_data:
        print("Original X:")
        print(X)
        print()
        print("Normalized X:")
        print(X_norm)
        print()
    return X_norm