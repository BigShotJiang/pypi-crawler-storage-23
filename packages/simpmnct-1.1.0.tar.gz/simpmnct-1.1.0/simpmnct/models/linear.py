import numpy as np
from .base_model import BaseModel
class linear(BaseModel):

    def __init__(self,lr=0.01,epochs=1000,out_loss=False,out_gradient=False,out_update=False,out_epoch=False ):
        self.lr = lr
        self.epochs = epochs
        self.out_loss = out_loss
        self.out_gradient = out_gradient
        self.out_update = out_update
        self.out_epoch = out_epoch
        self.weight = None
        self.bias = None
        self.loss_history = []

    def fit(self,X,y):
        n_sample,n_feature=X.shape

        self.weight = np.zeros(n_feature)
        self.bias = 0
        print("Model:")
        print("y_pred = X·w + b")
        print("Initial weight =",self.weight)
        print("Initial bias =",self.bias)
        for i in range(self.epochs):
            y_pred = X.dot(self.weight) + self.bias
            loss = (1/n_sample) * np.sum((y-y_pred)**2)
            self.loss_history.append(loss)
            dw = (2/n_sample) * X.T @ (y_pred-y)
            gd = (2/n_sample) * np.sum(y_pred - y)
            if self.out_gradient:
                print("dw =",dw)
                print("db =",gd)
            old_w = self.weight.copy()
            old_b = self.bias
            self.weight = self.weight - self.lr * dw
            self.bias = self.bias - self.lr * gd
            if self.out_update:
                print("Weight update:")
                print(old_w,"->",self.weight)
                print("Bias update:")
                print(old_b,"->",self.bias)
            if self.out_epoch:
                print("Epoch",i+1,"Loss =",loss)
        
        if self.out_loss:
            print("Loss history")
            for i in range(0,len(self.loss_history),self.loss_step):
                print(f"Epoch {i+1:3d} | Loss = {self.loss_history[i]:.6f}")
        if self.out_loss:
            print("Initial Loss =",self.loss_history[0])
            print("Final Loss =",self.loss_history[-1])

    def predict(self,X,explain=False):
        X = np.array(X)
        if explain:
            print("Predict explain")
            print("X =",X)
            print("w =",self.weight)
            print("b =",self.bias)
            print("X·w+b =",X.dot(self.weight)+self.bias)
        return X.dot(self.weight)+self.bias
    def score(self, X, y,explain=False):
        y_pred = self.predict(X)
        ss_res = np.sum((y - y_pred)**2)
        ss_tot = np.sum((y - np.mean(y))**2)
        r2 = 1 - (ss_res / (ss_tot + 1e-8))
        if explain:
            print("R2 Score Explain")
            print()
            print("y =",y)
            print("y_pred =",y_pred)
            print()
            print("SS_res = Σ(y - y_pred)^2")
            print("=",ss_res)
            print()
            print("SS_tot = Σ(y - y_mean)^2")
            print("=",ss_tot)
            print()
            print("R2 = 1 - SS_res/SS_tot")
            print("=",r2)
        return r2

