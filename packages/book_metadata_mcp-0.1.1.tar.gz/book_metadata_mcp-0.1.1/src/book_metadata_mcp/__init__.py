"""Book Metadata MCP Server — Multi-source book lookup for AI assistants."""

__version__ = "0.1.1"
