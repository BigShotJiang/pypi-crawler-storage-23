"""OpenAIVision converter"""

__version__ = "0.6.5"
