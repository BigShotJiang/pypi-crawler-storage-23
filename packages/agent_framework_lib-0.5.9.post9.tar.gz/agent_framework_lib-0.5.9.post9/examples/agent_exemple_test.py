import logging
import os
from pathlib import Path
from typing import Any
import asyncio

from dotenv import load_dotenv

# Load environment variables
env_path = Path(__file__).resolve().parents[1] / ".env"
if env_path.exists():
    load_dotenv(dotenv_path=env_path)
else:
    load_dotenv()

from agent_framework.core.models import Tag
from agent_framework.implementations import LlamaIndexAgent
from agent_framework.storage.file_system_management import FileStorageFactory
from agent_framework.memory import MemoryConfig


logger = logging.getLogger(__name__)

# Shared file storage cache (module-level for sharing across all agent instances)
# Modification pour la concurrence: gain de temps après le premier appel
_SHARED_FILE_STORAGE = None
_STORAGE_LOCK = asyncio.Lock()


class MultiSkillsAgent(LlamaIndexAgent):
    def __init__(self) -> None:
        super().__init__(
            agent_id="multi-skills-agent-test",
            name="Multi-Skills Agent Test",
            description=(
                "A versatile assistant that can dynamically load specialized skills "
                "for PDFs, file operations, web search, and more."
            ),
            tags=[
                Tag(name="files", color="#D4EB0B"),
                {"name": "storage"},
                "pdf",
            ],
            image_url="https://api.dicebear.com/7.x/bottts/svg?seed=filestorage",
            hoover= "1",
            short_description="2",
        )
        self.current_user_id = "default_user"
        self.current_session_id: str | None = None
        self.file_storage = None
    
    def get_memory_config(self) -> MemoryConfig:
        """Configure Graphiti memory with FalkorDB backend."""
        return MemoryConfig.graphiti_simple(
            use_falkordb=True,
            falkordb_host=os.getenv("FALKORDB_HOST", "localhost"),
            falkordb_port=int(os.getenv("FALKORDB_PORT", "6379")),
            environment=os.getenv("ENVIRONMENT", "dev"),
            passive_injection=True,
            skip_index_creation=True,
        )
    
    async def _ensure_file_storage(self) -> None:
        """Ensure file storage is initialized (with caching)."""
        global _SHARED_FILE_STORAGE
        
        if _SHARED_FILE_STORAGE is not None:
            self.file_storage = _SHARED_FILE_STORAGE
            return
        
        # Double-check locking pattern
        async with _STORAGE_LOCK:
            if _SHARED_FILE_STORAGE is None:
                _SHARED_FILE_STORAGE = await FileStorageFactory.create_storage_manager()
            self.file_storage = _SHARED_FILE_STORAGE

    async def configure_session(self, session_configuration: dict[str, Any]) -> None:
        """Configure session and initialize file storage for skills."""
        self.current_user_id = session_configuration.get("user_id", "default_user")
        self.current_session_id = session_configuration.get("session_id")

        # Initialize file storage for file-related skills
        await self._ensure_file_storage()

        # Call parent to build the agent (this collects skill tool instances)
        await super().configure_session(session_configuration)

        # Configure context for ALL registered skill tools
        # This must be called AFTER super().configure_session()
        self.configure_skill_tools_context(
            file_storage=self.file_storage,
            user_id=self.current_user_id,
            session_id=self.current_session_id,
        )

    def get_agent_prompt(self) -> str:
        """
        Define the agent's system prompt with skills discovery.

        The skills discovery prompt is automatically appended by BaseAgent.get_system_prompt()
        when skills are enabled. This teaches the agent to:
        - Use list_skills() to see available skills
        - Use load_skill("name") to get detailed instructions
        - Use skill tools directly (they're already available)
        """
        return """You are a versatile assistant with access to a Skills System.

Your capabilities are organized into skills. Skill tools are always available to you.
Use list_skills() to see all available skills and their descriptions.
Use load_skill("skill_name") to get detailed instructions for using a skill.

When a user asks for something:
1. Use the appropriate skill tools directly (they're already available)
2. If you need guidance, load the skill to get detailed instructions
3. Follow the skill's instructions to complete the task

Be proactive about using your capabilities to help users."""

    def get_agent_tools(self) -> list[callable]:
        """
        Return agent-specific tools.

        Note: Skill tools are automatically added by BaseAgent._get_all_tools().
        No need to manually add them here. This method only needs to return
        any custom tools specific to this agent (none in this case).
        """
        return []

    async def get_welcome_message(self) -> str:
        """Return a welcome message showing available skills."""
        skills = self.skill_registry.list_all()
        skill_categories: dict[str, list[str]] = {}

        for skill in skills:
            category = skill.category
            if category not in skill_categories:
                skill_categories[category] = []
            skill_categories[category].append(skill.name)

        categories_text = "\n".join(
            f"  - {cat.title()}: {', '.join(names)}" for cat, names in skill_categories.items()
        )

        return f"""Hello! I'm the {self.name}.

I have access to {len(skills)} skills organized by category:
{categories_text}

Skill tools are already available - just ask me to:
- Create charts, diagrams, or tables
- Generate PDF documents
- Search the web
- Analyze images
- And more!

What would you like me to help you with?"""


def main() -> None:
    """Start the multi-skills agent server."""
    if not os.getenv("OPENAI_API_KEY") and not os.getenv("ANTHROPIC_API_KEY"):
        print("Error: No API key found")
        print("Please set OPENAI_API_KEY or ANTHROPIC_API_KEY")
        return

    from agent_framework import create_basic_agent_server

    port = int(os.getenv("AGENT_PORT", "8205"))

    print("=" * 60)
    print("🚀 Starting Multi-Skills Agent Server")
    print("=" * 60)
    print(f"📊 Model: {os.getenv('DEFAULT_MODEL', 'gpt-4o-mini')}")
    print("🎯 Skills: 12 built-in skills (tools auto-loaded)")
    print(f"🌐 Server: http://localhost:{port}")
    print(f"🎨 UI: http://localhost:{port}/ui")
    print("=" * 60)
    print("\nTry asking:")
    print("  - 'List available skills'")
    print("  - 'Create a bar chart of monthly sales'")
    print("  - 'Generate a flowchart diagram'")
    print("  - 'Create a PDF report'")
    print("=" * 60)

    create_basic_agent_server(
        agent_class=MultiSkillsAgent,
        host="0.0.0.0",
        port=port,
        reload=False,
    )


if __name__ == "__main__":
    main()
