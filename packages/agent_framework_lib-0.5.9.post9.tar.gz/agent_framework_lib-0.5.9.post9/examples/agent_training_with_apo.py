"""
Exemple d'entraînement d'agent avec AgentLightning et APO.

Ce script montre comment:
1. Adapter votre agent existant pour AgentLightning
2. Créer un dataset de tâches d'entraînement
3. Configurer et lancer l'optimisation APO
4. Évaluer les résultats

Installation requise:
    pip install agentlightning openai
"""

import asyncio
import logging
import os
from pathlib import Path
from typing import Any
from dotenv import load_dotenv

# Charger les variables d'environnement
env_path = Path(__file__).resolve().parents[1] / ".env"
if env_path.exists():
    load_dotenv(dotenv_path=env_path)
else:
    load_dotenv()

import agentlightning as agl
from openai import AsyncOpenAI, OpenAI

from agent_framework.core.models import Tag
from agent_framework.implementations import LlamaIndexAgent
from agent_framework.storage.file_system_management import FileStorageFactory

logger = logging.getLogger(__name__)


# ============================================================================
# 1. DATASET DE TÂCHES
# ============================================================================

def create_training_dataset() -> list[dict[str, Any]]:
    """Crée un dataset de tâches d'entraînement."""
    return [
        {
            "query": "Liste les compétences disponibles",
            "expected_action": "list_skills",
            "expected_output_contains": ["skills", "available"],
            "difficulty": "easy"
        },
        {
            "query": "Crée un graphique en barres des ventes mensuelles: Jan=100, Feb=150, Mar=200",
            "expected_action": "create_chart",
            "expected_output_contains": ["chart", "created"],
            "difficulty": "medium"
        },
        {
            "query": "Génère un diagramme de flux pour un processus de connexion utilisateur",
            "expected_action": "create_mermaid",
            "expected_output_contains": ["diagram", "flowchart"],
            "difficulty": "medium"
        },
        {
            "query": "Crée un tableau comparant 3 produits avec leurs prix et caractéristiques",
            "expected_action": "create_table",
            "expected_output_contains": ["table", "products"],
            "difficulty": "medium"
        },
        {
            "query": "Recherche sur le web les dernières nouvelles sur l'IA",
            "expected_action": "web_search",
            "expected_output_contains": ["search", "results"],
            "difficulty": "easy"
        },
        {
            "query": "Génère un PDF avec un rapport de ventes incluant un graphique",
            "expected_action": "create_pdf",
            "expected_output_contains": ["pdf", "generated"],
            "difficulty": "hard"
        },
        {
            "query": "Charge la compétence de gestion de fichiers et liste ses capacités",
            "expected_action": "load_skill",
            "expected_output_contains": ["skill", "loaded", "file"],
            "difficulty": "easy"
        },
        {
            "query": "Crée un graphique circulaire montrant la répartition des dépenses: Loyer=40%, Nourriture=30%, Transport=20%, Autres=10%",
            "expected_action": "create_chart",
            "expected_output_contains": ["pie", "chart"],
            "difficulty": "medium"
        },
    ]


def create_validation_dataset() -> list[dict[str, Any]]:
    """Crée un dataset de validation."""
    return [
        {
            "query": "Montre-moi toutes les compétences que tu as",
            "expected_action": "list_skills",
            "expected_output_contains": ["skills"],
            "difficulty": "easy"
        },
        {
            "query": "Fais un graphique linéaire de l'évolution des températures",
            "expected_action": "create_chart",
            "expected_output_contains": ["chart", "line"],
            "difficulty": "medium"
        },
        {
            "query": "Crée un diagramme de séquence pour une API REST",
            "expected_action": "create_mermaid",
            "expected_output_contains": ["diagram", "sequence"],
            "difficulty": "hard"
        },
    ]


# ============================================================================
# 2. FONCTION DE GRADING
# ============================================================================

def grade_agent_response(
    response: str,
    task: dict[str, Any],
    use_llm_judge: bool = True
) -> float:
    """
    Évalue la qualité de la réponse de l'agent.
    
    Args:
        response: Réponse générée par l'agent
        task: Tâche originale avec critères d'évaluation
        use_llm_judge: Utiliser un LLM comme juge (recommandé)
    
    Returns:
        Score entre 0.0 et 1.0
    """
    if not response:
        return 0.0
    
    # Méthode 1: Vérification simple des mots-clés
    score = 0.0
    expected_keywords = task.get("expected_output_contains", [])
    
    if expected_keywords:
        matches = sum(1 for keyword in expected_keywords if keyword.lower() in response.lower())
        keyword_score = matches / len(expected_keywords)
        score += keyword_score * 0.5  # 50% du score
    
    # Méthode 2: Utiliser un LLM comme juge (plus précis)
    if use_llm_judge:
        try:
            client = OpenAI()
            judge_response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {
                        "role": "system",
                        "content": """Tu es un évaluateur d'agents IA. Évalue si la réponse de l'agent 
                        répond correctement à la tâche demandée. 
                        
                        Critères:
                        - L'agent a-t-il compris la demande?
                        - A-t-il utilisé les bons outils?
                        - La réponse est-elle complète et pertinente?
                        
                        Réponds UNIQUEMENT avec un nombre entre 0.0 et 1.0."""
                    },
                    {
                        "role": "user",
                        "content": f"""Tâche: {task['query']}
Action attendue: {task.get('expected_action', 'N/A')}
Réponse de l'agent: {response[:500]}

Score (0.0 à 1.0):"""
                    }
                ],
                temperature=0.0,
                max_tokens=10
            )
            
            llm_score_text = judge_response.choices[0].message.content.strip()
            llm_score = float(llm_score_text)
            score += llm_score * 0.5  # 50% du score
            
        except Exception as e:
            logger.warning(f"LLM judge failed: {e}")
            # Fallback sur le score des mots-clés uniquement
            score = keyword_score if expected_keywords else 0.0
    
    return min(1.0, max(0.0, score))


# ============================================================================
# 3. AGENT WRAPPER POUR AGENTLIGHTNING
# ============================================================================

class TrainableMultiSkillsAgent(LlamaIndexAgent):
    """Agent adapté pour l'entraînement avec AgentLightning."""
    
    def __init__(self, custom_prompt: str | None = None) -> None:
        super().__init__(
            agent_id="trainable-multi-skills-agent",
            name="Trainable Multi-Skills Agent",
            description="Agent polyvalent optimisable avec APO",
            tags=[Tag(name="training", color="#FF6B6B")],
        )
        self.custom_prompt = custom_prompt
        self.current_user_id = "training_user"
        self.current_session_id = "training_session"
        self.file_storage = None
    
    def get_agent_prompt(self) -> str:
        """Retourne le prompt (personnalisé ou par défaut)."""
        if self.custom_prompt:
            return self.custom_prompt
        
        return """Tu es un assistant polyvalent avec accès à plusieurs compétences.

Quand un utilisateur demande quelque chose:
1. Analyse la demande pour identifier la compétence appropriée
2. Utilise les outils disponibles de manière efficace
3. Fournis une réponse claire et complète

Compétences disponibles:
- Gestion de fichiers
- Création de graphiques
- Génération de diagrammes
- Création de tableaux
- Recherche web
- Génération de PDF

Sois précis, efficace et professionnel."""
    
    async def initialize_for_training(self):
        """Initialise l'agent pour l'entraînement."""
        self.file_storage = await FileStorageFactory.create_storage_manager()
        
        await self.configure_session({
            "user_id": self.current_user_id,
            "session_id": self.current_session_id
        })
        
        self.configure_skill_tools_context(
            file_storage=self.file_storage,
            user_id=self.current_user_id,
            session_id=self.current_session_id,
        )


# ============================================================================
# 4. FONCTION ROLLOUT POUR AGENTLIGHTNING
# ============================================================================

@agl.rollout
async def multi_skills_agent_rollout(
    task: dict[str, Any],
    prompt_template: agl.PromptTemplate
) -> float:
    """
    Fonction de rollout pour AgentLightning.
    
    Args:
        task: Tâche à exécuter
        prompt_template: Template de prompt fourni par APO
    
    Returns:
        Récompense entre 0.0 et 1.0
    """
    try:
        # 1. Créer l'agent avec le prompt optimisé
        agent = TrainableMultiSkillsAgent(custom_prompt=str(prompt_template))
        await agent.initialize_for_training()
        
        # 2. Créer un contexte frais
        ctx = agent.create_fresh_context()
        
        # 3. Exécuter l'agent sur la tâche
        query = task["query"]
        response = await agent.run_agent(query, ctx, stream=False)
        
        # 4. Évaluer la réponse
        reward = grade_agent_response(response, task, use_llm_judge=True)
        
        logger.info(f"Task: {query[:50]}... | Reward: {reward:.3f}")
        
        return reward
        
    except Exception as e:
        logger.error(f"Rollout failed: {e}")
        return 0.0


# ============================================================================
# 5. CONFIGURATION ET LANCEMENT DU TRAINING
# ============================================================================

async def train_agent():
    """Lance l'entraînement de l'agent avec APO."""
    
    print("=" * 70)
    print("🚀 Entraînement d'agent avec AgentLightning + APO")
    print("=" * 70)
    
    # Vérifier les clés API
    if not os.getenv("OPENAI_API_KEY"):
        print("❌ Erreur: OPENAI_API_KEY non définie")
        return
    
    # 1. Charger les datasets
    print("\n📊 Chargement des datasets...")
    train_dataset = create_training_dataset()
    val_dataset = create_validation_dataset()
    print(f"   - Training: {len(train_dataset)} tâches")
    print(f"   - Validation: {len(val_dataset)} tâches")
    
    # 2. Configurer l'algorithme APO
    print("\n🧠 Configuration de l'algorithme APO...")
    openai_client = AsyncOpenAI()
    algo = agl.APO(
        openai_client,
        val_batch_size=len(val_dataset),  # Toutes les tâches de validation
        gradient_batch_size=4,             # 4 tâches pour la critique
        beam_width=2,                      # Explorer 2 prompts
        branch_factor=2,                   # 2 variations par prompt
        beam_rounds=2                      # 2 rounds d'optimisation
    )
    
    # 3. Prompt initial (baseline)
    initial_prompt = """Tu es un assistant polyvalent avec accès à plusieurs compétences.

Quand un utilisateur demande quelque chose:
1. Analyse la demande
2. Utilise les outils appropriés
3. Fournis une réponse claire

Sois efficace."""
    
    print(f"\n📝 Prompt initial ({len(initial_prompt)} caractères):")
    print(f"   {initial_prompt[:100]}...")
    
    # 4. Configurer le Trainer
    print("\n⚙️  Configuration du Trainer...")
    trainer = agl.Trainer(
        algorithm=algo,
        n_runners=4,  # 4 agents parallèles (ajuster selon votre machine)
        initial_resources={
            "prompt_template": initial_prompt
        },
        adapter=agl.TraceToMessages()
    )
    
    # 5. Lancer l'entraînement
    print("\n🎯 Démarrage de l'entraînement...")
    print("   (Cela peut prendre 10-15 minutes)")
    print("-" * 70)
    
    results = await trainer.fit(
        agent=multi_skills_agent_rollout,
        train_dataset=train_dataset,
        val_dataset=val_dataset
    )
    
    # 6. Afficher les résultats
    print("\n" + "=" * 70)
    print("✅ Entraînement terminé!")
    print("=" * 70)
    
    if results:
        print("\n📈 Résultats:")
        for round_num, metrics in enumerate(results.get("rounds", [])):
            accuracy = metrics.get("val_accuracy", 0)
            print(f"   Round {round_num}: {accuracy:.3f} accuracy")
        
        # Meilleur prompt
        best_prompt = results.get("best_prompt_template")
        if best_prompt:
            print(f"\n🏆 Meilleur prompt ({len(best_prompt)} caractères):")
            print(f"   {best_prompt[:200]}...")
            
            # Sauvegarder le meilleur prompt
            output_path = Path("outputs/optimized_prompt.txt")
            output_path.parent.mkdir(exist_ok=True)
            output_path.write_text(best_prompt)
            print(f"\n💾 Prompt sauvegardé: {output_path}")


def main():
    """Point d'entrée principal."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    asyncio.run(train_agent())


if __name__ == "__main__":
    main()
