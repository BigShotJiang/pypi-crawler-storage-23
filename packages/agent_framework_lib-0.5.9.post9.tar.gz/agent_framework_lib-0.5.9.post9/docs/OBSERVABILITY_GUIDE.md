# Guide d'Observabilité - Agent Framework

Ce guide couvre l'architecture d'observabilité de l'Agent Framework.

## Table des Matières

1. [Vue d'Ensemble](#vue-densemble)
2. [Index Unifié de Métriques](#index-unifié-de-métriques)
3. [Accurate Token Tracking](#accurate-token-tracking)
4. [Configuration](#configuration)
5. [Dashboards Kibana](#dashboards-kibana)
6. [OpenTelemetry (Optionnel)](#opentelemetry-optionnel)
7. [Troubleshooting](#troubleshooting)

---

## Vue d'Ensemble

L'Agent Framework utilise un **index Elasticsearch unifié** (`agent-metrics-*`) pour toutes les métriques d'observabilité. Cet index consolide :

- Timing API (preprocessing, LLM, postprocessing)
- Métriques LLM (tokens, TTFT, durée)
- Spans détaillés (chaque étape du pipeline)

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              AGENT FRAMEWORK                                    │
│                                                                                 │
│                         MetricsAggregator                                       │
│                               │                                                 │
│              ┌────────────────┼────────────────┐                               │
│              │                │                │                                │
│              ▼                ▼                ▼                                │
│   ┌──────────────────┐ ┌──────────────┐ ┌──────────────┐                       │
│   │   API Timing     │ │ LLM Metrics  │ │ Span Timings │                       │
│   │                  │ │              │ │              │                       │
│   │ preprocessing_ms │ │ input_tokens │ │ span_*_ms    │                       │
│   │ llm_duration_ms  │ │ output_tokens│ │              │                       │
│   │ postprocessing_ms│ │ ttft_ms      │ │              │                       │
│   └──────────────────┘ └──────────────┘ └──────────────┘                       │
│              │                │                │                                │
│              └────────────────┼────────────────┘                               │
│                               │                                                 │
│                               ▼                                                 │
│                    ┌──────────────────────┐                                    │
│                    │  Document Unifié     │                                    │
│                    │  (1 doc par requête) │                                    │
│                    └──────────┬───────────┘                                    │
│                               │                                                 │
└───────────────────────────────┼─────────────────────────────────────────────────┘
                                │
                                │ HTTP (bulk API)
                                │
                                ▼
              ┌────────────────────────────────────────────────┐
              │              Elasticsearch                     │
              │              (Port 9200)                       │
              │                                                │
              │  Index: agent-metrics-{date}                   │
              │                                                │
              └─────────────────────┬──────────────────────────┘
                                    │
                                    ▼
                             ┌───────────┐
                             │  Kibana   │
                             │  (5601)   │
                             │           │
                             │  TSVB     │
                             │  Dashboard│
                             └───────────┘
```

### Avantages de l'Index Unifié

| Aspect | Avant (3 index) | Après (1 index) |
|--------|-----------------|-----------------|
| **Corrélation** | Jointure par request_id | Tout dans un document |
| **Maintenance** | 3 templates, 3 rotations | 1 template, 1 rotation |
| **Dashboards** | Panels pointant vers différents index | Source unique |
| **Requêtes** | Complexes avec jointures | Simples et rapides |

---

## Index Unifié de Métriques

### Structure du Document

Chaque requête API génère **un seul document** dans `agent-metrics-{date}` :

```json
{
  "@timestamp": "2024-01-15T10:30:00.000Z",
  "request_id": "req-uuid-123",
  "session_id": "sess-456",
  "user_id": "user-789",
  "agent_id": "support-agent",
  "endpoint": "/stream",
  "method": "POST",
  "model_name": "gpt-4-turbo",
  
  "total_api_duration_ms": 2500.0,
  "preprocessing_duration_ms": 150.0,
  "llm_duration_ms": 2200.0,
  "postprocessing_duration_ms": 150.0,
  
  "time_to_first_token_ms": 450.0,
  "input_tokens": 1500,
  "output_tokens": 800,
  "thinking_tokens": 200,
  "total_tokens": 2500,
  "tokens_per_second": 36.4,
  
  "tool_call_count": 2,
  "tool_call_total_ms": 350.0,
  
  "span_preprocessing_load_session_ms": 25.0,
  "span_preprocessing_get_history_ms": 45.0,
  "span_preprocessing_model_routing_ms": 10.0,
  "span_agent_load_state_ms": 30.0,
  "span_llamaindex_llm_call_ms": 2200.0,
  
  "is_streaming": true,
  "status_code": 200
}
```

### Champs Disponibles

| Catégorie | Champs | Description |
|-----------|--------|-------------|
| **Contexte** | `request_id`, `session_id`, `user_id`, `agent_id`, `endpoint`, `method`, `model_name` | Identifiants pour filtrage |
| **API Timing** | `total_api_duration_ms`, `preprocessing_duration_ms`, `llm_duration_ms`, `postprocessing_duration_ms` | Durées des phases principales |
| **LLM Metrics** | `input_tokens`, `output_tokens`, `thinking_tokens`, `total_tokens`, `tokens_per_second`, `time_to_first_token_ms` | Métriques LLM |
| **Tool Calls** | `tool_call_count`, `tool_call_total_ms` | Appels d'outils |
| **Spans** | `span_preprocessing_*_ms`, `span_agent_*_ms`, `span_llamaindex_*_ms` | Timing détaillé par étape |
| **Status** | `is_streaming`, `status_code`, `error_message` | État de la requête |

### Spans Disponibles

Les spans permettent une analyse fine du pipeline :

**Preprocessing:**
- `span_preprocessing_load_session_ms`
- `span_preprocessing_process_files_ms`
- `span_preprocessing_get_agent_ms`
- `span_preprocessing_get_history_ms`
- `span_preprocessing_model_routing_ms`
- `span_preprocessing_configure_model_ms`
- `span_preprocessing_persist_user_message_ms`
- `span_preprocessing_build_query_ms`

**Agent:**
- `span_agent_instantiate_ms`
- `span_agent_inject_storage_ms`
- `span_agent_load_config_ms`
- `span_agent_load_state_ms`
- `span_agent_configure_session_ms`
- `span_agent_ensure_built_ms`
- `span_agent_create_context_ms`
- `span_agent_build_query_ms`
- `span_agent_memory_injection_ms`

**LlamaIndex:**
- `span_llamaindex_load_memory_ms`
- `span_llamaindex_sanitize_memory_ms`
- `span_llamaindex_llm_call_ms`

---

## Accurate Token Tracking

Le framework capture les **vrais comptages de tokens** directement depuis les réponses API des providers LLM via OpenLLMetry.

### Classification des Tokens

| Type | Description |
|------|-------------|
| `input_tokens` | Contexte initial (query + system prompt + tools + memory) |
| `thinking_tokens` | Raisonnement intermédiaire (décisions d'outils, traitement des résultats) |
| `output_tokens` | Réponse finale à l'utilisateur |

### Exemple avec Agent Loop

```
Call 1 (initial):
  input: 5000 tokens → input_tokens
  output: 200 tokens → thinking_tokens

Call 2 (intermediate):  
  input: 1500 tokens  → thinking_tokens
  output: 300 tokens  → thinking_tokens

Call 3 (final):
  input: 2000 tokens  → thinking_tokens
  output: 800 tokens  → output_tokens

Résultat:
  input_tokens = 5000
  thinking_tokens = 4000
  output_tokens = 800
```

---

## Configuration

### Variables d'Environnement

```bash
# Elasticsearch (requis)
ELASTICSEARCH_ENABLED=true
ELASTICSEARCH_URL=http://localhost:9200

# Métriques unifiées (activé par défaut)
UNIFIED_METRICS_ENABLED=true
METRICS_INDEX_PREFIX=agent-metrics

# Configuration du batching
METRICS_BATCH_SIZE=50
METRICS_FLUSH_INTERVAL=5.0

# Auto-instrumentation LLM (optionnel)
LLM_AUTO_INSTRUMENTATION_ENABLED=true
```

### Utilisation dans le Code

```python
from agent_framework.monitoring import MetricsAggregator

# Créer l'aggregator au début de la requête
aggregator = MetricsAggregator(
    request_id="req-123",
    endpoint="/stream",
    method="POST",
)

# Enregistrer les phases
aggregator.start_request()
aggregator.start_preprocessing()
# ... preprocessing ...
aggregator.end_preprocessing()

aggregator.start_llm()
# ... LLM call ...
aggregator.record_ttft(450.0)
aggregator.end_llm()

aggregator.start_postprocessing()
# ... postprocessing ...
aggregator.end_postprocessing()

# Enregistrer les tokens et finaliser
aggregator.record_tokens(input_tokens=1500, output_tokens=800, thinking_tokens=200)
await aggregator.finalize()
```

---

## Dashboards Kibana

Le fichier `observability/kibana-llm-dashboard-setup.json` contient la configuration complète du dashboard.

### Visualisations Disponibles

| Panel | Type | Description |
|-------|------|-------------|
| LLM Tokens Over Time | Timeseries | Input/Output/Thinking tokens |
| LLM Duration Over Time | Timeseries | Durée LLM + TTFT (P50) |
| Total Input/Output/Thinking Tokens | Metric | Compteurs totaux |
| Avg LLM Duration | Metric | Durée moyenne |
| Avg TTFT | Metric | Time to First Token moyen |
| Tokens by Model | Top N | Répartition par modèle |
| Tool Calls Count | Metric | Nombre d'appels d'outils |
| API Duration Over Time | Timeseries | Durée API (P50) |
| Duration by Endpoint | Top N | Durée par endpoint |
| Latency Breakdown | Timeseries | Preprocessing/LLM/Postprocessing |
| Tokens Per Second | Metric | Débit de génération |

### Création du Dashboard

Le dashboard est créé automatiquement via l'Admin Panel ou peut être importé manuellement :

```bash
# Vérifier que l'index existe
curl -s "http://localhost:9200/_cat/indices/agent-metrics-*?v"

# Créer l'index pattern dans Kibana
# Management > Index Patterns > Create: agent-metrics-*
```

---

## OpenTelemetry (Optionnel)

Pour le tracing distribué et l'export vers d'autres backends :

```bash
# Activer OTel
OTEL_ENABLED=true
OTEL_SERVICE_NAME=agent_framework
OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
```

OTel est complémentaire à l'index unifié ES - il permet :
- Traces distribuées (Jaeger)
- Export vers Prometheus/Grafana
- Corrélation avec d'autres services

---

## Troubleshooting

| Problème | Solution |
|----------|----------|
| Pas de données dans Kibana | Vérifier `ELASTICSEARCH_ENABLED=true` et `UNIFIED_METRICS_ENABLED=true` |
| Index non créé | Le template est créé au démarrage du serveur |
| Token counts semblent bas | Vérifier que `traceloop-sdk` est installé |
| Pas de thinking_tokens | Normal pour les appels LLM simples (sans tool calls) |

### Vérifications

```bash
# Vérifier les indices
curl -s "http://localhost:9200/_cat/indices/agent-metrics-*?v"

# Vérifier le template
curl -s "http://localhost:9200/_index_template/agent-metrics-unified-template?pretty"

# Voir un document exemple
curl -s "http://localhost:9200/agent-metrics-*/_search?size=1&pretty"

# Vérifier les champs de timing
curl -s "http://localhost:9200/agent-metrics-*/_search?size=1" | \
  jq '.hits.hits[0]._source | {preprocessing: .preprocessing_duration_ms, llm: .llm_duration_ms, postprocessing: .postprocessing_duration_ms}'
```
