# QA - Streaming Latency Instrumentation

## Problèmes Identifiés

### 1. ❌ `llamaindex.llm_call` duration > total API call duration
**Symptôme**: La durée du span LLM est plus élevée que la durée totale de l'API call
**Cause probable**: Problème async - le span LLM n'est pas correctement fermé ou mesure au-delà de la fin de la requête
**Investigation**:
- [ ] Vérifier que le span `llm_call` est fermé AVANT la fin du streaming
- [ ] Vérifier qu'il n'y a pas de race condition entre `_flush_buffer()` et la fin de la requête
- [ ] Vérifier que `time.perf_counter()` est utilisé de manière cohérente (pas de mélange avec `datetime`)
- [ ] Vérifier que le span ne reste pas ouvert pendant le post-processing

**Fichiers à vérifier**:
- `agent_framework/implementations/llamaindex_agent.py` - span `llm_call`
- `agent_framework/web/server.py` - timing API total

**🔍 ANALYSE DU CODE:**

Le problème est dans `llamaindex_agent.py` lignes 1150-1700. Voici le flow:

```python
# Ligne ~1150: Le span LLM est ouvert AVANT le streaming
llm_span_context = tracer.llm_span("llm_call", model_name=self._current_model)
llm_span = await llm_span_context.__aenter__()

handler = self._run_agent_stream_internal(full_query, ctx, **run_kwargs)

# Ligne ~1200-1600: Boucle async for qui yield les events
async for event in handler.stream_events():
    # ... traitement des events ...

# Ligne ~1620: APRÈS la boucle, on attend le handler final
final_response = await handler  # <-- PROBLÈME: Ceci peut prendre du temps!

# Ligne ~1700: Le span est fermé APRÈS tout le post-processing
await llm_span_context.__aexit__(None, None, None)
```

**🐛 BUG IDENTIFIÉ:**
Le span `llm_call` inclut:
1. Le streaming complet (OK)
2. `await handler` - attente du résultat final (OK)
3. Tout le post-processing: metrics, session stats, parsing special blocks (PROBLÈME!)

Le span devrait être fermé IMMÉDIATEMENT après `await handler`, pas après le post-processing.

**✅ SOLUTION PROPOSÉE:**
Déplacer `await llm_span_context.__aexit__()` juste après `final_response = await handler`:

```python
# Après le streaming
final_response = await handler
self._state_ctx = ctx

# FERMER LE SPAN ICI - avant le post-processing
if llm_span_context:
    await llm_span_context.__aexit__(None, None, None)
    llm_span_context = None  # Éviter double fermeture

# Puis le post-processing (metrics, session stats, etc.)
```

---

### 2. ❌ Thinking tokens toujours à 0
**Symptôme**: `thinking_tokens` est toujours 0 même quand le modèle utilise le thinking
**Cause probable**: Le champ n'est pas extrait de la réponse LLM
**Investigation**:
- [ ] Vérifier comment `thinking_tokens` est extrait dans `LLMMetrics`
- [ ] Vérifier si Anthropic/OpenAI retournent ce champ dans leur réponse
- [ ] Vérifier le mapping dans `llm_metrics.py`

**Fichiers à vérifier**:
- `agent_framework/monitoring/llm_metrics.py`
- `agent_framework/monitoring/llm_metrics_extractor.py`

**🔍 ANALYSE DU CODE:**

Dans `llm_metrics_collector.py`:
- `count_thinking()` existe et incrémente `_thinking_tokens`
- `count_tool_call_tokens()` compte les tool calls comme thinking tokens

Dans `llamaindex_agent.py`:
- `count_thinking()` n'est JAMAIS appelé!
- `count_tool_call_tokens()` n'est JAMAIS appelé!

Le code ne compte que:
- `count_input()` - appelé au début avec la query
- `count_output()` - appelé à la fin avec la réponse complète

**🐛 BUG IDENTIFIÉ:**
Les thinking tokens ne sont jamais comptés car:
1. Pour Claude avec thinking: Le thinking content n'est pas extrait du stream
2. Pour les tool calls: `count_tool_call_tokens()` n'est pas appelé

**✅ SOLUTION PROPOSÉE:**
1. Dans la boucle de streaming, quand on détecte un `ToolCall` event:
```python
if event_type == "ToolCall":
    if self._metrics_collector:
        tool_call_id = getattr(event, "call_id", None) or getattr(event, "id", "unknown")
        self._metrics_collector.start_tool_call(tool_call_id)
        # AJOUTER: Compter les tokens du tool call
        tool_kwargs = getattr(event, "tool_kwargs", {})
        tool_name = getattr(event, "tool_name", "")
        self._metrics_collector.count_tool_call_tokens([{
            "function": {"name": tool_name, "arguments": json.dumps(tool_kwargs)}
        }])
```

2. Pour Claude thinking: Détecter les events de type "thinking" et appeler `count_thinking()`

---

### 3. ❌ Tool calls count toujours à 0
**Symptôme**: `tool_call_count` est toujours 0 même quand il y a des tool calls
**Cause probable**: Le compteur n'est pas incrémenté lors des tool calls
**Investigation**:
- [ ] Vérifier où `tool_call_count` est incrémenté
- [ ] Vérifier si les tool calls sont détectés dans le streaming
- [ ] Vérifier le flow de données entre LlamaIndex et les métriques

**Fichiers à vérifier**:
- `agent_framework/implementations/llamaindex_agent.py`
- `agent_framework/monitoring/llm_metrics_collector.py`

**🔍 ANALYSE DU CODE:**

Dans `llm_metrics.py`:
```python
def to_elasticsearch_doc(self) -> dict[str, Any]:
    return {
        # ...
        "tool_call_count": len(self.tool_call_durations_ms),  # <-- Compte les durées!
        "tool_call_total_ms": sum(self.tool_call_durations_ms) if self.tool_call_durations_ms else 0.0,
    }
```

Le `tool_call_count` est calculé à partir de `tool_call_durations_ms`, qui est rempli par `TimingTracker.end_tool_call()`.

Dans `llamaindex_agent.py`:
```python
# Ligne ~1520: ToolCall event - start_tool_call est appelé
if event_type == "ToolCall":
    if self._metrics_collector:
        tool_call_id = getattr(event, "call_id", None) or getattr(event, "id", "unknown")
        self._metrics_collector.start_tool_call(tool_call_id)

# Ligne ~1280: ToolCallResult event - end_tool_call est appelé
if getattr(event, "__class__", type("", (), {})).__name__ == "ToolCallResult":
    # ...
    if self._metrics_collector:
        self._metrics_collector.end_tool_call(call_id)
```

**🐛 BUG IDENTIFIÉ:**
Le flow semble correct MAIS il y a un problème d'ordre des events:
1. `ToolCallResult` est traité AVANT `ToolCall` dans le code (ligne 1280 vs 1520)
2. Si LlamaIndex émet `ToolCallResult` AVANT `ToolCall`, alors `end_tool_call()` est appelé avant `start_tool_call()`
3. Dans `TimingTracker.end_tool_call()`:
```python
def end_tool_call(self, tool_id: str) -> None:
    if tool_id in self._tool_call_starts:  # <-- Si pas dans le dict, rien ne se passe!
        duration = (time.perf_counter() - self._tool_call_starts[tool_id]) * 1000
        self._tool_call_durations.append(duration)
```

**VÉRIFICATION NÉCESSAIRE:**
- Vérifier l'ordre d'émission des events LlamaIndex: `ToolCall` puis `ToolCallResult` ou l'inverse?
- Si `ToolCallResult` arrive en premier, le `call_id` n'est pas dans `_tool_call_starts`

**✅ SOLUTION PROPOSÉE:**
Option 1: Vérifier et corriger l'ordre de traitement dans la boucle
Option 2: Dans `end_tool_call()`, si le tool_id n'existe pas, créer une entrée avec durée 0:
```python
def end_tool_call(self, tool_id: str) -> None:
    if tool_id in self._tool_call_starts:
        duration = (time.perf_counter() - self._tool_call_starts[tool_id]) * 1000
        self._tool_call_durations.append(duration)
        del self._tool_call_starts[tool_id]
    else:
        # Tool call ended without start - log warning and count it anyway
        logger.warning(f"end_tool_call called for unknown tool_id: {tool_id}")
        self._tool_call_durations.append(0.0)  # Durée inconnue
```

---

### 4. ❌ TTFT incohérent entre panels Kibana
**Symptôme**: TTFT affiché en haut du dashboard (LLM metrics) ≠ TTFT en bas (spans)
**Cause probable**: Deux sources de données différentes avec des mesures différentes
**Investigation**:
- [ ] Vérifier que `time_to_first_token_ms` est mesuré au même moment dans les deux cas
- [ ] Vérifier que le TTFT dans les spans utilise `record_ttft()` correctement
- [ ] Vérifier qu'il n'y a pas de double comptage ou de décalage async

**Fichiers à vérifier**:
- `agent_framework/implementations/llamaindex_agent.py` - `record_ttft()`
- `agent_framework/monitoring/llm_metrics.py` - `time_to_first_token_ms`

**🔍 ANALYSE DU CODE:**

**Source 1: LLM Metrics (panels du haut)**
Dans `llamaindex_agent.py` ligne ~1200:
```python
if not first_token_recorded and self._metrics_collector:
    self._metrics_collector.record_first_token()
    first_token_recorded = True
```
Ceci appelle `TimingTracker.record_first_token()` qui calcule:
```python
ttft_ms = (self._first_token_time - self._start_time) * 1000
```
Où `_start_time` est défini dans `LLMMetricsCollector.start()` (ligne ~1140).

**Source 2: Spans (panels du bas)**
Dans `llamaindex_agent.py` ligne ~1690:
```python
if llm_span and self._metrics_collector:
    ttft_ms = self._metrics_collector.get_time_to_first_token_ms()
    if ttft_ms is not None:
        llm_span.set_attribute("gen_ai.response.time_to_first_token_ms", ttft_ms)
```
Le TTFT est copié depuis le metrics collector vers le span.

**🐛 BUG POTENTIEL:**
Le TTFT devrait être identique car il vient de la même source (`_metrics_collector`).
MAIS le span `llm_call` a son propre timing qui commence à un moment différent!

Dans `streaming_latency_tracer.py`:
```python
async with self._create_span(...) as ctx:
    span_data = SpanData(
        start_time=datetime.now(timezone.utc),  # <-- Début du span
        # ...
    )
    start_time = time.perf_counter()  # <-- Pour duration_ms
```

Le span `llm_call` commence APRÈS `_metrics_collector.start()` car:
1. `_metrics_collector.start()` est appelé ligne ~1140
2. Le span `llm_call` est ouvert ligne ~1150

**✅ SOLUTION:**
Le TTFT dans les spans devrait utiliser `record_ttft()` du tracer, pas copier depuis metrics:
```python
# Dans la boucle de streaming, quand premier token reçu:
if not first_token_recorded:
    if self._metrics_collector:
        self._metrics_collector.record_first_token()
    if tracer and llm_span:
        ttft_ms = self._metrics_collector.get_time_to_first_token_ms()
        tracer.record_ttft(llm_span, ttft_ms)
    first_token_recorded = True
```

---

## Timings Actuels Mesurés

### Preprocessing (server.py)
| Span | Description |
|------|-------------|
| `preprocessing.load_session` | Chargement session depuis storage |
| `preprocessing.process_files` | Conversion fichiers en markdown |
| `preprocessing.get_agent` | Récupération/création agent |
| `preprocessing.get_history` | Chargement historique conversation |
| `preprocessing.model_routing` | Sélection du modèle |
| `preprocessing.configure_model` | Configuration session avec modèle |
| `preprocessing.persist_user_message` | Sauvegarde message utilisateur |
| `preprocessing.build_query` | Construction de la requête |

### Agent (agent_provider.py, base_agent.py)
| Span | Description |
|------|-------------|
| `agent.instantiate` | Création instance agent |
| `agent.inject_storage` | Injection du storage |
| `agent.load_config` | Chargement config dynamique |
| `agent.load_state` | Chargement état agent |
| `agent.configure_session` | Configuration session |
| `agent.ensure_built` | Construction agent (tools, etc.) |
| `agent.create_context` | Création contexte frais |
| `agent.build_query` | Construction requête complète |
| `agent.memory_injection` | Injection mémoire |

### LlamaIndex (llamaindex_agent.py)
| Span | Description |
|------|-------------|
| `llamaindex.load_memory` | Chargement mémoire session |
| `llamaindex.sanitize_memory` | Sanitization cross-provider |
| `llamaindex.llm_call` | Appel LLM complet (avec TTFT) |

---

## Timings Supplémentaires Proposés

### Phase Preprocessing (avant LLM)
| Span Proposé | Description | Fichier |
|--------------|-------------|---------|
| `preprocessing.auth_check` | Vérification authentification | server.py |
| `preprocessing.rate_limit_check` | Vérification rate limiting | server.py |
| `preprocessing.validate_request` | Validation payload requête | server.py |
| `preprocessing.resolve_user` | Résolution user_id depuis token | server.py |
| `preprocessing.load_agent_config` | Chargement config agent depuis ES | server.py |

### Phase Agent Init
| Span Proposé | Description | Fichier |
|--------------|-------------|---------|
| `agent.load_tools` | Chargement des tools | base_agent.py |
| `agent.load_skills` | Chargement des skills | base_agent.py |
| `agent.build_system_prompt` | Construction system prompt | base_agent.py |
| `agent.init_mcp_servers` | Initialisation serveurs MCP | base_agent.py |

### Phase LLM
| Span Proposé | Description | Fichier |
|--------------|-------------|---------|
| `llamaindex.prepare_messages` | Préparation messages pour LLM | llamaindex_agent.py |
| `llamaindex.api_call_start` | Début appel API (avant réseau) | llamaindex_agent.py |
| `llamaindex.first_byte_received` | Premier byte reçu du réseau | llamaindex_agent.py |
| `llamaindex.token_parsing` | Parsing des tokens reçus | llamaindex_agent.py |
| `llamaindex.tool_call_detection` | Détection d'un tool call | llamaindex_agent.py |
| `llamaindex.tool_execution` | Exécution d'un tool (par tool) | llamaindex_agent.py |
| `llamaindex.tool_result_injection` | Injection résultat tool | llamaindex_agent.py |

### Phase Post-Processing (après LLM)
| Span Proposé | Description | Fichier |
|--------------|-------------|---------|
| `postprocessing.parse_response` | Parsing réponse LLM | server.py |
| `postprocessing.extract_activities` | Extraction activities du stream | server.py |
| `postprocessing.persist_assistant_message` | Sauvegarde réponse assistant | server.py |
| `postprocessing.update_session_state` | Mise à jour état session | server.py |
| `postprocessing.generate_insights` | Génération insights (si activé) | server.py |
| `postprocessing.log_metrics` | Logging métriques ES | server.py |
| `postprocessing.flush_buffers` | Flush des buffers | server.py |

### Phase Streaming
| Span Proposé | Description | Fichier |
|--------------|-------------|---------|
| `streaming.chunk_encode` | Encodage chunk SSE | server.py |
| `streaming.chunk_send` | Envoi chunk au client | server.py |
| `streaming.backpressure_wait` | Attente si backpressure | server.py |

### Métriques Additionnelles (pas des spans, mais des attributs)
| Métrique | Description |
|----------|-------------|
| `network_latency_ms` | Latence réseau vers LLM provider |
| `queue_wait_ms` | Temps d'attente dans la queue (si rate limited) |
| `memory_context_tokens` | Nombre de tokens dans le contexte mémoire |
| `system_prompt_tokens` | Nombre de tokens dans le system prompt |
| `user_message_tokens` | Nombre de tokens dans le message user |
| `tool_calls_total_duration_ms` | Durée totale de tous les tool calls |
| `chunks_sent_count` | Nombre de chunks SSE envoyés |
| `response_size_bytes` | Taille totale de la réponse |

---

## Résumé des Bugs et Corrections

### 🔴 Priorité Critique

| Bug | Cause Racine | Fichier | Correction |
|-----|--------------|---------|------------|
| LLM span > API duration | Span fermé après post-processing | `llamaindex_agent.py:1700` | Fermer span juste après `await handler` |
| tool_call_count = 0 | `end_tool_call()` appelé avant `start_tool_call()` | `llamaindex_agent.py:1280,1520` | Vérifier ordre events OU modifier `end_tool_call()` |

### 🟡 Priorité Moyenne

| Bug | Cause Racine | Fichier | Correction |
|-----|--------------|---------|------------|
| thinking_tokens = 0 | `count_thinking()` jamais appelé | `llamaindex_agent.py` | Appeler `count_tool_call_tokens()` sur ToolCall |
| TTFT incohérent | Timing différent entre metrics et spans | `llamaindex_agent.py:1690` | Utiliser `record_ttft()` au moment du premier token |

---

## Plan de Correction

### Priorité 1 - Bugs Critiques
1. [x] Analysé: `llamaindex.llm_call` duration > API duration
2. [x] Analysé: `tool_call_count` toujours à 0
3. [x] Analysé: `thinking_tokens` toujours à 0

### Priorité 2 - Cohérence Données
4. [x] Analysé: TTFT entre LLM metrics et spans
5. [ ] Implémenter les corrections

### Priorité 3 - Nouveaux Timings
6. [ ] Ajouter spans post-processing
7. [ ] Ajouter spans tool execution
8. [ ] Ajouter métriques additionnelles

---

## Tests de Validation

### Test 1: Cohérence des durées
```
total_api_duration >= preprocessing_duration + llm_duration + postprocessing_duration
```

### Test 2: TTFT cohérent
```
TTFT (LLM metrics) == TTFT (spans) ± 10ms
```

### Test 3: Tool calls comptés
```
Si response contient tool_call -> tool_call_count > 0
```

### Test 4: Thinking tokens
```
Si modèle Claude avec thinking -> thinking_tokens > 0
```

---

## Code Fixes Détaillés

### Fix 1: LLM Span Duration (llamaindex_agent.py)

**Localisation**: `handle_message_stream()` lignes ~1620-1700

**Avant** (problématique):
```python
# Ligne ~1620
final_response = await handler
self._state_ctx = ctx
final_text = "".join(validated_output_parts) if validated_output_parts else str(final_response)

# ... beaucoup de post-processing ...

# Ligne ~1700 - Span fermé TROP TARD
if llm_span_context:
    await llm_span_context.__aexit__(None, None, None)
```

**Après** (corrigé):
```python
# Ligne ~1620
final_response = await handler
self._state_ctx = ctx

# FERMER LE SPAN IMMÉDIATEMENT après le LLM
if llm_span_context:
    # Record TTFT avant de fermer
    if self._metrics_collector:
        ttft_ms = self._metrics_collector.get_time_to_first_token_ms()
        if ttft_ms is not None and llm_span:
            llm_span.set_attribute("time_to_first_token_ms", ttft_ms)
    await llm_span_context.__aexit__(None, None, None)
    llm_span_context = None  # Éviter double fermeture

# Puis le post-processing (hors du span LLM)
final_text = "".join(validated_output_parts) if validated_output_parts else str(final_response)
# ... reste du post-processing ...
```

---

### Fix 2: Tool Call Count (llamaindex_agent.py)

**Problème**: L'ordre de traitement dans la boucle fait que `ToolCallResult` est traité avant `ToolCall`.

**Option A - Réorganiser la boucle** (recommandé):
Déplacer le traitement de `ToolCall` AVANT `ToolCallResult` dans la boucle.

**Option B - Modifier TimingTracker** (fallback):
```python
# timing_tracker.py
def end_tool_call(self, tool_id: str) -> None:
    if tool_id in self._tool_call_starts:
        duration = (time.perf_counter() - self._tool_call_starts[tool_id]) * 1000
        self._tool_call_durations.append(duration)
        del self._tool_call_starts[tool_id]
    else:
        # Tool call ended without matching start - count it anyway
        import logging
        logging.getLogger(__name__).warning(
            f"end_tool_call for unknown tool_id: {tool_id}, counting with 0ms duration"
        )
        self._tool_call_durations.append(0.0)
```

---

### Fix 3: Thinking Tokens (llamaindex_agent.py)

**Localisation**: Dans la boucle de streaming, après détection de `ToolCall`

**Ajouter**:
```python
if event_type == "ToolCall":
    if self._metrics_collector:
        tool_call_id = getattr(event, "call_id", None) or getattr(event, "id", "unknown")
        self._metrics_collector.start_tool_call(tool_call_id)
        
        # NOUVEAU: Compter les tokens du tool call comme thinking tokens
        tool_name = getattr(event, "tool_name", "")
        tool_kwargs = getattr(event, "tool_kwargs", {})
        if tool_name or tool_kwargs:
            self._metrics_collector.count_tool_call_tokens([{
                "function": {
                    "name": tool_name,
                    "arguments": json.dumps(tool_kwargs) if tool_kwargs else ""
                }
            }])
    continue
```

---

### Fix 4: TTFT Cohérent (llamaindex_agent.py)

**Localisation**: Dans la boucle de streaming, quand premier token reçu

**Avant**:
```python
if not first_token_recorded and self._metrics_collector:
    self._metrics_collector.record_first_token()
    first_token_recorded = True
```

**Après**:
```python
if not first_token_recorded:
    # Enregistrer TTFT dans metrics collector
    if self._metrics_collector:
        self._metrics_collector.record_first_token()
    
    # NOUVEAU: Enregistrer TTFT dans le span aussi (même valeur)
    if tracer and llm_span and self._metrics_collector:
        ttft_ms = self._metrics_collector.get_time_to_first_token_ms()
        if ttft_ms is not None:
            tracer.record_ttft(llm_span, ttft_ms)
    
    first_token_recorded = True
```

---

## Ordre d'Implémentation Recommandé

1. **Fix 1** (LLM Span Duration) - Impact immédiat sur les métriques Kibana
2. **Fix 2** (Tool Call Count) - Nécessite investigation de l'ordre des events LlamaIndex
3. **Fix 4** (TTFT Cohérent) - Simple à implémenter
4. **Fix 3** (Thinking Tokens) - Dépend de Fix 2 pour le timing correct

---

## 🔴 AUDIT DOUBLONS DASHBOARD KIBANA

### Problème Observé
Le dashboard affiche des métriques qui semblent dupliquées ou incohérentes entre différentes sources de données.

### Sources de Données (3 Index Patterns)

| Index Pattern | Source Code | Données |
|---------------|-------------|---------|
| `agent-metrics-llm-*` | `LLMMetricsLogger` | Tokens, duration LLM, TTFT |
| `agent-metrics-api-*` | `APITimingMiddleware` | Duration API totale, preprocessing, postprocessing |
| `agent-metrics-spans-*` | `StreamingLatencyTracer` | Spans granulaires (preprocessing, agent, llamaindex) |

### Analyse des Doublons par Panel

#### 🟡 DOUBLONS POTENTIELS - Durée LLM

| Panel | Index | Champ | Valeur Observée |
|-------|-------|-------|-----------------|
| "Avg LLM Call Duration (ms)" | `llm-*` | `duration_ms` | 18,773 ms |
| "llamaindex.llm_call" (Waterfall) | `spans-*` | `duration_ms` | 26,773 ms |

**Analyse:**
- `llm-*` → Vient de `LLMMetricsLogger` qui log via `LLMMetricsCollector.finish()`
- `spans-*` → Vient de `StreamingLatencyTracer.llm_span()` 

**Problème:** Les deux mesurent la même chose mais à des moments différents!
- `LLMMetricsCollector` mesure depuis `start()` jusqu'à `finish()` (après post-processing)
- `StreamingLatencyTracer` mesure depuis l'entrée du span jusqu'à sa sortie (inclut post-processing aussi)

**Recommandation:** Garder UN SEUL - soit `llm-*` soit `spans-*` pour la durée LLM

---

#### 🟡 DOUBLONS POTENTIELS - TTFT

| Panel | Index | Champ | Valeur Observée |
|-------|-------|-------|-----------------|
| "Avg Time to First Token (ms)" | `llm-*` | `time_to_first_token_ms` | 4,952 ms |
| "LLM Time to First Token (Spans)" | `spans-*` | `time_to_first_token_ms` | - (vide) |

**Analyse:**
- `llm-*` → TTFT enregistré via `LLMMetricsCollector.record_first_token()`
- `spans-*` → TTFT copié depuis metrics collector vers le span (mais pas toujours)

**Problème:** Le TTFT dans spans est vide car il n'est pas correctement enregistré (voir Bug #4)

**Recommandation:** 
- Option A: Supprimer le panel TTFT des spans, garder uniquement celui de `llm-*`
- Option B: Corriger l'enregistrement TTFT dans spans et supprimer celui de `llm-*`

---

#### 🟡 DOUBLONS POTENTIELS - Tokens Over Time vs Total Tokens

| Panel | Index | Valeur Observée |
|-------|-------|-----------------|
| "LLM Tokens Over Time" (timeseries) | `llm-*` | Input=0, Output=0, Thinking=0 |
| "Total Input Tokens" (metric) | `llm-*` | 308 |
| "Total Output Tokens" (metric) | `llm-*` | 10,044 |

**Analyse:**
Les deux utilisent le même index `llm-*` mais:
- Timeseries montre 0 car il agrège par bucket de temps (peut-être pas de données dans le bucket actuel)
- Metric montre les totaux sur toute la période

**Pas un doublon** - c'est normal, mais le timeseries peut être confus si vide.

---

#### 🟢 PAS DE DOUBLON - API Duration

| Panel | Index | Champ | Valeur |
|-------|-------|-------|--------|
| "Avg API Duration (ms)" | `api-*` | `total_api_duration_ms` | 19,310 ms |
| "API Duration by Endpoint" | `api-*` | `total_api_duration_ms` | /stream: 19,310 ms |

**OK** - Même source, même champ, juste des vues différentes.

---

#### 🔴 INCOHÉRENCE - LLM Duration vs API Duration

| Métrique | Valeur | Source |
|----------|--------|--------|
| Avg LLM Call Duration | 18,773 ms | `llm-*` |
| Avg API Duration | 19,310 ms | `api-*` |
| llamaindex.llm_call (span) | 26,773 ms | `spans-*` |

**Problème:** 
- LLM duration (18,773) < API duration (19,310) ✅ Normal
- Mais span llm_call (26,773) > API duration (19,310) ❌ Impossible!

**Cause:** Le span `llm_call` inclut le post-processing (Bug #1)

---

### Recommandations de Nettoyage Dashboard

#### Option A: Garder LLM Metrics comme source principale

Supprimer des panels `spans-*`:
- ❌ "LLM Time to First Token (Spans)" → Doublon avec "Avg Time to First Token (ms)"
- ❌ "llamaindex.llm_call" dans Waterfall → Doublon avec "Avg LLM Call Duration"

Garder des panels `spans-*`:
- ✅ Preprocessing spans (preprocessing.*)
- ✅ Agent spans (agent.*)
- ✅ "llamaindex.sanitize_memory", "llamaindex.load_memory" (pas de doublon)

#### Option B: Migrer vers Spans comme source unique

Avantages:
- Plus granulaire
- Permet le waterfall view complet
- Une seule source de vérité

Inconvénients:
- Nécessite de corriger tous les bugs d'abord
- Perte des métriques tokens (pas dans spans actuellement)

#### Option C: Hybride (Recommandé)

| Métrique | Source Recommandée | Raison |
|----------|-------------------|--------|
| Tokens (input/output/thinking) | `llm-*` | Seule source avec tokens |
| TTFT | `llm-*` | Plus fiable actuellement |
| LLM Duration | `llm-*` | Après fix Bug #1, sera correct |
| Preprocessing breakdown | `spans-*` | Granularité unique |
| Agent init breakdown | `spans-*` | Granularité unique |
| API Duration totale | `api-*` | Seule source |

---

### Panels à Supprimer (Doublons)

1. **"LLM Time to First Token (Spans)"** - Doublon avec "Avg Time to First Token (ms)"
2. **"llamaindex.llm_call" dans Waterfall** - Après fix, sera redondant avec "Avg LLM Call Duration"

### Panels à Garder

| Section | Panels |
|---------|--------|
| **LLM Metrics (llm-*)** | Tokens Over Time, Total Tokens (x3), Avg Duration, Avg TTFT, Tokens by Model, Tool Calls, LLM Calls |
| **API Metrics (api-*)** | API Duration Over Time, Avg API Duration, Duration by Endpoint, Requests by Endpoint |
| **Spans (spans-*)** | Preprocessing Waterfall (SANS llm_call), Preprocessing Time, Agent Init Time, Latency Trends, Slowest Steps |

---

### Actions Requises

1. [ ] **Fix Bug #1** - Fermer span llm_call avant post-processing
2. [ ] **Supprimer panel** "LLM Time to First Token (Spans)" du dashboard
3. [ ] **Filtrer Waterfall** pour exclure `llamaindex.llm_call` (ou le garder mais comprendre qu'il mesure autre chose)
4. [ ] **Documenter** clairement ce que chaque source mesure
