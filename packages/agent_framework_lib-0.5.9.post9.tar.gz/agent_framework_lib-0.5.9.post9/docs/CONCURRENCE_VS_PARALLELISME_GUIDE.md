# Guide complet : Concurrence vs Parallélisme en Python

## 📚 Table des matières
1. [Concepts fondamentaux](#concepts-fondamentaux)
2. [Concurrence avec Async/Await](#concurrence-avec-asyncawait)
3. [Parallélisme avec Multiprocessing](#parallélisme-avec-multiprocessing)
4. [Threading (cas particulier)](#threading-cas-particulier)
5. [Comparaison pratique](#comparaison-pratique)
6. [Quand utiliser quoi ?](#quand-utiliser-quoi)

---

## 🎯 Concepts fondamentaux

### Définitions

**CONCURRENCE** = Gérer plusieurs tâches **en alternance** (illusion de simultanéité)
```
Un seul chef cuisinier qui prépare 3 plats :
- Met les pâtes à bouillir → Pendant qu'elles cuisent...
- Coupe les légumes → Pendant qu'ils cuisent...
- Prépare la sauce → Revient aux pâtes
= 1 personne, 3 tâches en alternance
```

**PARALLÉLISME** = Exécuter plusieurs tâches **vraiment en même temps**
```
Trois chefs cuisiniers qui préparent 3 plats :
- Chef 1 : Prépare les pâtes
- Chef 2 : Prépare les légumes  } En même temps
- Chef 3 : Prépare la sauce
= 3 personnes, 3 tâches simultanées
```

### Visualisation

```
CONCURRENCE (1 cœur CPU)
Temps →
Core 1: [A][B][C][A][B][C][A][B][C]
        ↑ Alternance rapide entre tâches

PARALLÉLISME (3 cœurs CPU)
Temps →
Core 1: [A][A][A][A][A][A][A][A][A]
Core 2: [B][B][B][B][B][B][B][B][B]  } Vraiment simultané
Core 3: [C][C][C][C][C][C][C][C][C]
```

---

## 🔄 Concurrence avec Async/Await

### Principe de base

**Async/Await** = Concurrence coopérative pour opérations I/O

```python
# Pendant qu'une tâche ATTEND (I/O), une autre s'exécute
async def task_a():
    print("A: Début")
    await asyncio.sleep(1)  # ← Attend (libère le CPU)
    print("A: Fin")

async def task_b():
    print("B: Début")
    await asyncio.sleep(1)  # ← Attend (libère le CPU)
    print("B: Fin")

# Exécution concurrente
await asyncio.gather(task_a(), task_b())

# Output:
# A: Début
# B: Début
# (1 seconde d'attente)
# A: Fin
# B: Fin
# Total: 1 seconde (pas 2!)
```

### Comment ça fonctionne ?

```
Timeline détaillée (1 seul cœur CPU):

0ms:   Task A démarre → print("A: Début")
1ms:   Task A attend (await sleep) → CPU LIBRE
2ms:   Task B démarre → print("B: Début")
3ms:   Task B attend (await sleep) → CPU LIBRE
...
1000ms: Task A se réveille → print("A: Fin")
1001ms: Task B se réveille → print("B: Fin")

Clé: Pendant l'attente I/O, le CPU fait autre chose!
```

### Event Loop (boucle d'événements)

```python
# L'event loop gère l'alternance automatiquement
import asyncio

async def main():
    # L'event loop surveille toutes les tâches
    tasks = [
        asyncio.create_task(fetch_api_1()),  # Attend réseau
        asyncio.create_task(fetch_api_2()),  # Attend réseau
        asyncio.create_task(fetch_api_3()),  # Attend réseau
    ]
    
    # Pendant que fetch_api_1 attend la réponse HTTP,
    # l'event loop lance fetch_api_2, puis fetch_api_3
    results = await asyncio.gather(*tasks)

asyncio.run(main())
```

### Exemple concret : Requêtes API

```python
import asyncio
import aiohttp
import time

# ❌ SÉQUENTIEL : 3 secondes
def sequential_requests():
    start = time.time()
    
    response1 = requests.get("https://api1.com")  # 1 sec
    response2 = requests.get("https://api2.com")  # 1 sec
    response3 = requests.get("https://api3.com")  # 1 sec
    
    print(f"Temps: {time.time() - start:.2f}s")  # 3.00s

# ✅ CONCURRENT : 1 seconde
async def concurrent_requests():
    start = time.time()
    
    async with aiohttp.ClientSession() as session:
        # Les 3 requêtes partent en même temps
        tasks = [
            session.get("https://api1.com"),  # 1 sec
            session.get("https://api2.com"),  # 1 sec
            session.get("https://api3.com"),  # 1 sec
        ]
        responses = await asyncio.gather(*tasks)
    
    print(f"Temps: {time.time() - start:.2f}s")  # 1.00s

# Gain: 3x plus rapide!
```

### Anatomie d'une fonction async

```python
async def ma_fonction():
    # 1. Code synchrone (s'exécute normalement)
    print("Début")
    x = 1 + 1
    
    # 2. Point d'attente (await) - libère le CPU
    result = await autre_fonction_async()
    #        ↑ Ici, le CPU peut exécuter d'autres tâches
    
    # 3. Reprise après l'attente
    print(f"Résultat: {result}")
    
    return result

# Règles:
# - async def = fonction qui peut attendre
# - await = point où on peut libérer le CPU
# - Toujours appeler avec await ou asyncio.run()
```

### asyncio.gather vs asyncio.create_task

```python
# asyncio.gather : Attend TOUS les résultats
results = await asyncio.gather(
    task1(),  # Si task1 échoue, tout échoue
    task2(),
    task3(),
)

# asyncio.create_task : Fire-and-forget
task = asyncio.create_task(log_event())
# Continue sans attendre
# Utile pour logging, metrics, etc.

# asyncio.wait : Plus de contrôle
done, pending = await asyncio.wait(
    [task1(), task2(), task3()],
    return_when=asyncio.FIRST_COMPLETED  # Ou ALL_COMPLETED
)
```

### Exemple complet : Votre cas d'usage

```python
# Dans votre get_agent, vous avez des opérations I/O indépendantes

# ❌ AVANT (séquentiel) : 120ms
async def get_agent_sequential(session_id):
    # Attend DB (20ms)
    await record_lifecycle_event("created")
    
    # Attend Elasticsearch (50ms)
    config = await load_config_from_es()
    
    # Attend DB (50ms)
    session = await load_session_from_db()
    
    # Total: 120ms

# ✅ APRÈS (concurrent) : 50ms
async def get_agent_concurrent(session_id):
    # Les 3 opérations partent en même temps
    lifecycle_task, config, session = await asyncio.gather(
        record_lifecycle_event("created"),  # 20ms
        load_config_from_es(),              # 50ms
        load_session_from_db(),             # 50ms
    )
    # Total: max(20, 50, 50) = 50ms
    # Gain: 70ms (58% plus rapide)

# Pourquoi ça marche ?
# - Pendant que load_config attend Elasticsearch...
# - ...load_session peut interroger la DB
# - ...et record_lifecycle peut écrire dans la DB
# Tout ça sur 1 seul cœur CPU!
```

---

## ⚡ Parallélisme avec Multiprocessing

### Principe de base

**Multiprocessing** = Vrai parallélisme avec plusieurs processus OS

```python
from multiprocessing import Process, Pool
import os

def heavy_computation(n):
    """Calcul CPU intensif"""
    result = sum(i * i for i in range(n))
    print(f"Process {os.getpid()}: {result}")
    return result

# Créer plusieurs processus
if __name__ == "__main__":
    # Méthode 1: Process manuel
    p1 = Process(target=heavy_computation, args=(10_000_000,))
    p2 = Process(target=heavy_computation, args=(10_000_000,))
    
    p1.start()  # Démarre sur Core 1
    p2.start()  # Démarre sur Core 2
    
    p1.join()   # Attend la fin
    p2.join()
    
    # Méthode 2: Pool (plus simple)
    with Pool(4) as pool:
        results = pool.map(heavy_computation, [10_000_000] * 4)
    # 4 processus en parallèle sur 4 cœurs
```

### Comment ça fonctionne ?

```
Multiprocessing crée des processus OS séparés:

┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│   Process 1     │  │   Process 2     │  │   Process 3     │
│   PID: 1234     │  │   PID: 1235     │  │   PID: 1236     │
├─────────────────┤  ├─────────────────┤  ├─────────────────┤
│ Mémoire isolée  │  │ Mémoire isolée  │  │ Mémoire isolée  │
│ Variables: x=1  │  │ Variables: x=2  │  │ Variables: x=3  │
│ CPU Core 1      │  │ CPU Core 2      │  │ CPU Core 3      │
└─────────────────┘  └─────────────────┘  └─────────────────┘
        ↓                    ↓                    ↓
    Vraiment simultané (pas d'alternance)
```

### Exemple : Traitement d'images

```python
from multiprocessing import Pool
from PIL import Image
import time

def process_image(image_path):
    """Traitement CPU intensif"""
    img = Image.open(image_path)
    # Redimensionnement, filtres, etc.
    img = img.resize((800, 600))
    img = img.filter(ImageFilter.SHARPEN)
    img.save(f"processed_{image_path}")
    return image_path

# ❌ SÉQUENTIEL : 40 secondes (100 images × 0.4s)
def sequential_processing():
    start = time.time()
    
    for img in image_list:
        process_image(img)  # 0.4s par image
    
    print(f"Temps: {time.time() - start:.2f}s")  # 40.00s

# ✅ PARALLÈLE : 10 secondes (4 cœurs)
def parallel_processing():
    start = time.time()
    
    with Pool(4) as pool:
        pool.map(process_image, image_list)
    
    print(f"Temps: {time.time() - start:.2f}s")  # 10.00s

# Gain: 4x plus rapide (4 cœurs)
```

### Communication inter-processus

```python
from multiprocessing import Process, Queue, Pipe

# Méthode 1: Queue (file d'attente)
def worker(queue):
    while True:
        item = queue.get()
        if item is None:
            break
        result = process(item)
        queue.put(result)

queue = Queue()
p = Process(target=worker, args=(queue,))
p.start()
queue.put("data")
result = queue.get()

# Méthode 2: Pipe (canal bidirectionnel)
def worker(conn):
    data = conn.recv()
    result = process(data)
    conn.send(result)

parent_conn, child_conn = Pipe()
p = Process(target=worker, args=(child_conn,))
p.start()
parent_conn.send("data")
result = parent_conn.recv()

# Méthode 3: Manager (objets partagés)
from multiprocessing import Manager

manager = Manager()
shared_dict = manager.dict()
shared_list = manager.list()

def worker(shared_dict):
    shared_dict["result"] = 42

p = Process(target=worker, args=(shared_dict,))
p.start()
p.join()
print(shared_dict["result"])  # 42
```

### Overhead du multiprocessing

```python
import time
from multiprocessing import Process

def simple_task():
    return 1 + 1

# Mesurer l'overhead
start = time.time()

# Créer un processus
p = Process(target=simple_task)
p.start()
p.join()

overhead = time.time() - start
print(f"Overhead: {overhead * 1000:.2f}ms")  # ~100-500ms

# Comparaison:
# - Fonction normale: 0.001ms
# - Async task: 0.1ms
# - Thread: 1-5ms
# - Process: 100-500ms

# Conclusion: N'utilisez multiprocessing que si le gain
# de parallélisme compense l'overhead!
```

### Quand utiliser multiprocessing ?

```python
# ✅ BON : Calculs CPU intensifs
def good_use_case():
    with Pool(4) as pool:
        # Chaque tâche prend 10 secondes de CPU
        results = pool.map(train_ml_model, datasets)
    # Overhead: 200ms
    # Gain: 40s → 10s (4x plus rapide)
    # Ratio: 200ms / 30s = 0.6% overhead

# ❌ MAUVAIS : Opérations I/O
def bad_use_case():
    with Pool(4) as pool:
        # Chaque tâche attend 50ms (réseau)
        results = pool.map(fetch_api, urls)
    # Overhead: 200ms
    # Gain: 200ms → 50ms (4x plus rapide)
    # Ratio: 200ms / 150ms = 133% overhead
    # Pire qu'avant!
```

---

## 🧵 Threading (cas particulier en Python)

### Le problème du GIL (Global Interpreter Lock)

```python
import threading
import time

def cpu_task():
    """Calcul CPU intensif"""
    total = 0
    for i in range(10_000_000):
        total += i
    return total

# ❌ Threading ne donne PAS de parallélisme CPU
def test_threading():
    start = time.time()
    
    t1 = threading.Thread(target=cpu_task)
    t2 = threading.Thread(target=cpu_task)
    
    t1.start()
    t2.start()
    
    t1.join()
    t2.join()
    
    print(f"Temps: {time.time() - start:.2f}s")  # 2.00s
    # Pas plus rapide que séquentiel!

# ✅ Multiprocessing donne du vrai parallélisme
def test_multiprocessing():
    start = time.time()
    
    from multiprocessing import Process
    
    p1 = Process(target=cpu_task)
    p2 = Process(target=cpu_task)
    
    p1.start()
    p2.start()
    
    p1.join()
    p2.join()
    
    print(f"Temps: {time.time() - start:.2f}s")  # 1.00s
    # 2x plus rapide!
```

### Pourquoi le GIL existe ?

```python
# Le GIL protège les structures internes de Python

# Sans GIL (problème):
# Thread 1: x = x + 1  (lit x=5, calcule 6)
# Thread 2: x = x + 1  (lit x=5, calcule 6)
# Résultat: x=6 (devrait être 7!)

# Avec GIL (solution):
# Thread 1: [LOCK] x = x + 1 [UNLOCK]
# Thread 2: [ATTEND...] [LOCK] x = x + 1 [UNLOCK]
# Résultat: x=7 (correct)

# Conséquence: 1 seul thread Python à la fois
```

### Quand utiliser threading ?

```python
# ✅ BON : I/O-bound (mais async est mieux)
import threading
import requests

def fetch_url(url):
    response = requests.get(url)  # Attend réseau
    return response.text

# Threading fonctionne pour I/O
threads = []
for url in urls:
    t = threading.Thread(target=fetch_url, args=(url,))
    t.start()
    threads.append(t)

for t in threads:
    t.join()

# Mais async est plus efficace:
async def fetch_url_async(url):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

await asyncio.gather(*[fetch_url_async(url) for url in urls])
```

---

## 📊 Comparaison pratique

### Tableau récapitulatif

| Critère | Async/Await | Threading | Multiprocessing |
|---------|-------------|-----------|-----------------|
| **Type** | Concurrence | Concurrence | Parallélisme |
| **Cœurs CPU** | 1 | 1 (GIL) | Plusieurs |
| **Bon pour** | I/O-bound | I/O-bound | CPU-bound |
| **Overhead** | <1ms | 1-5ms | 100-500ms |
| **Mémoire** | Partagée | Partagée | Isolée |
| **Communication** | Facile | Facile | Complexe |
| **Création** | Instantané | Rapide | Lent |
| **Scalabilité** | Excellente | Bonne | Limitée |
| **Complexité** | Moyenne | Moyenne | Élevée |

### Benchmark comparatif

```python
import asyncio
import threading
from multiprocessing import Pool
import time
import requests

# Tâche I/O-bound : 10 requêtes API
urls = ["https://httpbin.org/delay/1"] * 10

# 1. SÉQUENTIEL : 10 secondes
def sequential():
    start = time.time()
    for url in urls:
        requests.get(url)
    return time.time() - start

# 2. ASYNC : 1 seconde
async def async_version():
    start = time.time()
    async with aiohttp.ClientSession() as session:
        tasks = [session.get(url) for url in urls]
        await asyncio.gather(*tasks)
    return time.time() - start

# 3. THREADING : 1 seconde
def threading_version():
    start = time.time()
    threads = []
    for url in urls:
        t = threading.Thread(target=requests.get, args=(url,))
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    return time.time() - start

# 4. MULTIPROCESSING : 1.2 secondes (overhead!)
def multiprocessing_version():
    start = time.time()
    with Pool(10) as pool:
        pool.map(requests.get, urls)
    return time.time() - start

# Résultats:
# Sequential:       10.0s
# Async:            1.0s  ← Meilleur pour I/O
# Threading:        1.0s
# Multiprocessing:  1.2s  (overhead de 200ms)
```

### Tâche CPU-bound : Calculs mathématiques

```python
def heavy_computation(n):
    return sum(i * i for i in range(n))

numbers = [10_000_000] * 4

# 1. SÉQUENTIEL : 4 secondes
def sequential():
    start = time.time()
    for n in numbers:
        heavy_computation(n)
    return time.time() - start

# 2. ASYNC : 4 secondes (pas d'amélioration!)
async def async_version():
    start = time.time()
    # Async n'aide pas pour CPU-bound
    for n in numbers:
        heavy_computation(n)
    return time.time() - start

# 3. THREADING : 4 secondes (GIL!)
def threading_version():
    start = time.time()
    threads = []
    for n in numbers:
        t = threading.Thread(target=heavy_computation, args=(n,))
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    return time.time() - start

# 4. MULTIPROCESSING : 1 seconde
def multiprocessing_version():
    start = time.time()
    with Pool(4) as pool:
        pool.map(heavy_computation, numbers)
    return time.time() - start

# Résultats:
# Sequential:       4.0s
# Async:            4.0s  (pas d'amélioration)
# Threading:        4.0s  (GIL bloque)
# Multiprocessing:  1.0s  ← Meilleur pour CPU
```

---

## 🎯 Quand utiliser quoi ?

### Arbre de décision

```
Votre tâche est-elle I/O-bound ou CPU-bound ?
│
├─ I/O-bound (réseau, DB, fichiers)
│  │
│  ├─ Beaucoup de tâches (>100) ?
│  │  └─ ✅ ASYNC/AWAIT (meilleure scalabilité)
│  │
│  └─ Peu de tâches (<100) ?
│     ├─ Code moderne ? → ✅ ASYNC/AWAIT
│     └─ Code legacy ? → ⚠️ THREADING (acceptable)
│
└─ CPU-bound (calculs, ML, traitement d'images)
   │
   ├─ Tâches longues (>1s) ?
   │  └─ ✅ MULTIPROCESSING (gain > overhead)
   │
   └─ Tâches courtes (<100ms) ?
      └─ ❌ Rester SÉQUENTIEL (overhead trop élevé)
```

### Exemples concrets

```python
# ✅ ASYNC : API calls, DB queries, file I/O
async def fetch_user_data(user_id):
    user = await db.get_user(user_id)        # I/O
    posts = await api.get_posts(user_id)     # I/O
    comments = await api.get_comments(user_id)  # I/O
    return user, posts, comments

# ✅ MULTIPROCESSING : ML training, image processing
def train_models(datasets):
    with Pool(4) as pool:
        models = pool.map(train_single_model, datasets)
    return models

# ⚠️ THREADING : Legacy code avec I/O
def legacy_fetch(urls):
    threads = []
    for url in urls:
        t = threading.Thread(target=requests.get, args=(url,))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()

# ❌ MAUVAIS : Multiprocessing pour I/O court
def bad_example(urls):
    # Overhead: 200ms, Gain: 50ms → Perte nette!
    with Pool(4) as pool:
        pool.map(requests.get, urls)
```

### Votre cas : get_agent

```python
# Analyse de votre code:

async def get_agent(session_id, agent_class, user_id):
    # Opérations I/O:
    await record_lifecycle_event(...)      # DB write (20ms)
    config = await load_config(...)        # ES read (50ms)
    session = await load_session(...)      # DB read (50ms)
    await save_session(...)                # DB write (30ms)
    await update_identity(...)             # DB write (20ms)
    state = await load_state(...)          # DB read (50ms)
    
    # Type: I/O-bound (DB + Elasticsearch)
    # Durée: Courte (20-50ms par opération)
    # Quantité: Plusieurs opérations indépendantes

# Recommandation: ✅ ASYNC avec asyncio.gather
# Raison:
# - I/O-bound → async optimal
# - Opérations indépendantes → gather possible
# - Overhead minimal (<1ms)
# - Gain significatif (40-60%)

# ❌ PAS multiprocessing car:
# - Overhead trop élevé (200ms > gain)
# - Complexité inutile
# - Pas de gain pour I/O
```

---

## 💡 Patterns avancés

### Pattern 1 : Combiner async + multiprocessing

```python
import asyncio
from concurrent.futures import ProcessPoolExecutor

# Pour tâches mixtes (I/O + CPU)
async def hybrid_processing():
    # Partie I/O (async)
    data = await fetch_data_from_api()
    
    # Partie CPU (multiprocessing)
    with ProcessPoolExecutor() as executor:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            executor,
            heavy_computation,
            data
        )
    
    # Partie I/O (async)
    await save_result_to_db(result)
    
    return result

# Exemple: Traitement d'images avec API
async def process_images_from_api():
    # 1. Télécharger images (I/O - async)
    images = await asyncio.gather(*[
        download_image(url) for url in image_urls
    ])
    
    # 2. Traiter images (CPU - multiprocessing)
    with ProcessPoolExecutor(max_workers=4) as executor:
        loop = asyncio.get_event_loop()
        processed = await asyncio.gather(*[
            loop.run_in_executor(executor, process_image, img)
            for img in images
        ])
    
    # 3. Uploader résultats (I/O - async)
    await asyncio.gather(*[
        upload_image(img) for img in processed
    ])
```

### Pattern 2 : Semaphore pour limiter la concurrence

```python
# Limiter le nombre de requêtes simultanées
async def fetch_with_limit(urls, max_concurrent=10):
    semaphore = asyncio.Semaphore(max_concurrent)
    
    async def fetch_one(url):
        async with semaphore:  # Max 10 en même temps
            return await fetch_url(url)
    
    return await asyncio.gather(*[fetch_one(url) for url in urls])

# Utile pour:
# - Respecter les rate limits d'API
# - Éviter de surcharger la DB
# - Contrôler l'utilisation mémoire
```

### Pattern 3 : Timeout et retry

```python
async def fetch_with_retry(url, max_retries=3, timeout=5):
    for attempt in range(max_retries):
        try:
            async with asyncio.timeout(timeout):
                return await fetch_url(url)
        except asyncio.TimeoutError:
            if attempt == max_retries - 1:
                raise
            await asyncio.sleep(2 ** attempt)  # Backoff exponentiel
```

---

## 🎓 Résumé final

### Règles d'or

1. **I/O-bound** → `async/await` (concurrence)
2. **CPU-bound** → `multiprocessing` (parallélisme)
3. **Legacy I/O** → `threading` (acceptable)
4. **Tâches courtes** → Rester séquentiel

### Votre situation

```python
# Votre get_agent:
# - Type: I/O-bound (DB, Elasticsearch)
# - Durée: 20-50ms par opération
# - Opérations: Indépendantes

# Solution optimale: ✅ ASYNC avec asyncio.gather
# Gain attendu: 40-60% plus rapide
# Complexité: Faible
# Risque: Minimal
```

### Prochaines étapes

1. ✅ Comprendre les concepts (fait)
2. ⏳ Implémenter asyncio.gather dans get_agent
3. ⏳ Tester les performances
4. ⏳ Monitorer en production
