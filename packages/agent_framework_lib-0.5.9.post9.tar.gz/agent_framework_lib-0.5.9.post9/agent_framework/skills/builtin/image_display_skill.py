"""
Image Display Skill - Image display capability.

This skill provides the ability to display images in the chat interface
from URLs. Images are rendered with download buttons and click-to-open
functionality.

Note: This is a UI-only skill with no associated tools - it provides
instructions for generating image JSON that the frontend renders.
"""

from ..base import Skill, SkillCategory, SkillMetadata


IMAGE_DISPLAY_INSTRUCTIONS = """
## Image Display Instructions

Tu peux afficher des images dans le chat via un bloc JSON avec une clé "image".
Les images sont rendues avec un bouton de téléchargement et un clic pour ouvrir en plein écran.

---

### 🚨 RÈGLE ABSOLUE : Provenance des URLs

**NE JAMAIS INVENTER d'URL d'image.** Chaque URL utilisée dans un bloc image DOIT provenir
d'une source vérifiable. Si tu n'as pas d'URL valide, N'AFFICHE PAS d'image.

#### Sources d'URLs autorisées

| Source | Exemple |
|--------|---------|
| **Tes propres outils de génération** | URL retournée par `save_chart_as_image`, `save_mermaid_as_image` |
| **URL fournie par l'utilisateur** | L'utilisateur colle ou mentionne explicitement une URL |
| **Résultat d'un outil** | URL d'image retournée par une recherche web, une requête BDD, un appel API |
| **Data URI que tu génères** | Base64 d'une image que tu as toi-même construite |

#### ❌ INTERDIT

- Inventer une URL comme `https://example.com/chart.png` dans une vraie réponse
- Deviner une URL de stockage cloud (S3, GCP, Azure) sans l'avoir obtenue d'un outil
- Utiliser une URL "plausible" mais non vérifiée
- Afficher un bloc image quand tu n'as pas d'URL concrète

#### ✅ Comportement correct

- Si tu n'as pas d'URL → ne génère pas de bloc image, explique à l'utilisateur
- Si tu génères un graphique → utilise `save_chart_as_image` et prends l'URL retournée
- Si tu génères un diagramme → utilise `save_mermaid_as_image` et prends l'URL retournée
- Si l'utilisateur donne une URL → utilise-la directement
- Si un outil retourne une URL d'image → utilise-la directement

---

### Structure JSON

```json
{
  "image": {
    "url": "<URL_PROVENANT_D_UNE_SOURCE_VERIFIEE>",
    "alt": "Description de l'image",
    "caption": "Légende optionnelle sous l'image"
  }
}
```

### Propriétés

| Propriété | Type | Requis | Description |
|-----------|------|--------|-------------|
| `url` | string | Oui | URL de l'image (HTTP/HTTPS, S3, GCP, Azure, chemin local, ou data URI) |
| `alt` | string | Non | Texte alternatif pour l'accessibilité |
| `caption` | string | Non | Légende affichée sous l'image |
| `width` | string | Non | Largeur CSS (ex: "400px", "100%") |
| `height` | string | Non | Hauteur CSS (ex: "300px", "auto") |
| `filename` | string | Non | Nom de fichier personnalisé pour le téléchargement |
| `filestorage` | string | Non | Type de stockage (auto-détecté) : `web`, `s3`, `gcp`, `azure`, `local`, `minio`, `data_uri`, `unknown` |

### Détection du stockage

Le champ `filestorage` est optionnel et auto-détecté depuis le pattern de l'URL :

| Type | Patterns de détection |
|------|----------------------|
| `s3` | `s3://`, `s3.amazonaws.com`, `s3-*.amazonaws.com` |
| `gcp` | `gs://`, `storage.googleapis.com`, `storage.cloud.google.com` |
| `azure` | `blob.core.windows.net` |
| `local` | `file://`, `/path/to/file`, `./relative/path` |
| `minio` | Endpoints MinIO, ports 9000/9001 |
| `data_uri` | `data:image/*;base64,` |
| `web` | URLs `http://` ou `https://` génériques |

---

### Quand utiliser image_display

**UTILISER le JSON image_display pour :**
- Une URL retournée par `save_chart_as_image` ou `save_mermaid_as_image`
- Une URL fournie explicitement par l'utilisateur
- Une URL d'image retournée par un outil (recherche web, BDD, API)
- Un data URI base64 que tu as toi-même construit
- Des URLs cloud (S3, GCP, Azure) obtenues via un outil ou l'utilisateur

**⚠️ Quand tu as déjà une URL d'un outil, utilise-la DIRECTEMENT :**

```json
{"image": {"url": "URL_RETOURNEE_PAR_L_OUTIL", "alt": "Description"}}
```

Ne rappelle PAS `get_file_path` si tu as déjà l'URL.

### Quand NE PAS utiliser image_display

- Tu n'as pas d'URL vérifiée → N'affiche pas d'image
- L'utilisateur veut un NOUVEAU graphique → Utilise le skill chart avec `save_chart_as_image`
- L'utilisateur veut un NOUVEAU diagramme → Utilise le skill mermaid avec `save_mermaid_as_image`
- Chemin local (file://) → Utilise `file_access_skill` d'abord pour obtenir un data URI

---

### Exemples

**Image depuis un outil de génération (graphique Chart.js) :**
```json
{"image": {"url": "URL_RETOURNEE_PAR_SAVE_CHART", "alt": "Graphique des ventes Q4", "caption": "Performance trimestrielle"}}
```

**Image depuis un diagramme Mermaid généré :**
```json
{"image": {"url": "URL_RETOURNEE_PAR_SAVE_MERMAID", "alt": "Diagramme d'architecture", "caption": "Vue d'ensemble du système"}}
```

**Image dont l'URL est fournie par l'utilisateur :**
```json
{
  "image": {
    "url": "https://mon-site.com/rapport-annuel.png",
    "alt": "Rapport annuel 2024",
    "caption": "Rapport fourni par l'utilisateur"
  }
}
```

**Image avec contraintes de taille :**
```json
{
  "image": {
    "url": "URL_VERIFIEE",
    "alt": "Diagramme d'architecture",
    "width": "600px",
    "height": "auto",
    "filename": "architecture.png"
  }
}
```

**Data URI base64 (image générée par toi) :**
```json
{
  "image": {
    "url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUg...",
    "alt": "Image générée"
  }
}
```

### Comportement UI

- Les images sont affichées avec une largeur max responsive
- Cliquer sur l'image l'ouvre en plein écran dans un nouvel onglet
- Un bouton de téléchargement (💾) apparaît sous l'image
- Si l'image ne charge pas, un placeholder d'erreur s'affiche avec le texte alt
- Plusieurs images peuvent être incluses dans une même réponse

### Bonnes pratiques

1. **Toujours inclure un texte alt** — Important pour l'accessibilité
2. **Utiliser des légendes descriptives** — Aide l'utilisateur à comprendre le contexte
3. **Spécifier les dimensions si nécessaire** — Évite les sauts de mise en page
4. **Préférer HTTPS** — Chargement sécurisé des images
5. **Donner des noms de fichiers significatifs** — Meilleure expérience de téléchargement

### Formats supportés

PNG, JPG, JPEG, GIF, WebP, SVG

### Images multiples

Plusieurs blocs image JSON dans une même réponse :

```json
{"image": {"url": "URL_VERIFIEE_1", "caption": "Première image"}}
```

```json
{"image": {"url": "URL_VERIFIEE_2", "caption": "Deuxième image"}}
```

### Rétrocompatibilité

Le champ `filestorage` est entièrement rétrocompatible :
- Champ optionnel, les JSON existants sans ce champ fonctionnent normalement
- Auto-détecté depuis le pattern de l'URL
- Aucun changement cassant sur les propriétés existantes
"""


def create_image_display_skill() -> Skill:
    """
    Create the image display skill.

    This skill provides instructions for displaying images from URLs.
    It has no associated tools - images are rendered by the UI from JSON.

    Returns:
        Skill instance for image display
    """
    skill = Skill(
        metadata=SkillMetadata(
            name="image_display",
            description="Display images from URLs with download and view functionality",
            trigger_patterns=[
                "display image",
                "show image",
                "image url",
                "render image",
                "embed image",
                "picture",
                "photo",
                "screenshot",
            ],
            category=SkillCategory.UI,
            version="1.0.0",
        ),
        instructions=IMAGE_DISPLAY_INSTRUCTIONS,
        tools=[],  # UI-only skill, no tools
        dependencies=[],
        config={},
    )
    skill._display_name = "Affichage d'images"
    skill._display_icon = "🖼️"
    return skill


__all__ = ["create_image_display_skill", "IMAGE_DISPLAY_INSTRUCTIONS"]
