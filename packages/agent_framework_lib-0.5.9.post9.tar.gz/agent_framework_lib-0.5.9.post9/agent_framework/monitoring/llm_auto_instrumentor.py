"""LLM Auto-Instrumentor for OpenLLMetry Integration.

This module provides automatic instrumentation for LLM providers using
OpenLLMetry (Traceloop SDK). It captures real token counts from provider
API responses and integrates with the existing OpenTelemetry infrastructure.

Key Features:
- Auto-instruments OpenAI, Anthropic, and other LLM providers
- Captures real token counts from response.usage
- Integrates with existing OTel pipeline via OTelSetup
- Graceful fallback when traceloop-sdk is not installed

Environment Variables:
    LLM_AUTO_INSTRUMENTATION_ENABLED: Enable/disable auto-instrumentation
        (default: "true" if traceloop-sdk is installed)
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agent_framework.monitoring.llm_metrics import LLMMetrics
    from agent_framework.monitoring.otel_setup import OTelSetup

logger = logging.getLogger(__name__)


def _is_traceloop_available() -> bool:
    """Check if traceloop-sdk is installed.

    Returns:
        True if traceloop-sdk is available, False otherwise
    """
    try:
        from traceloop.sdk import Traceloop  # noqa: F401

        return True
    except ImportError:
        return False


def _is_auto_instrumentation_enabled() -> bool:
    """Check if LLM auto-instrumentation is enabled via environment variable.

    The environment variable LLM_AUTO_INSTRUMENTATION_ENABLED controls this.
    Default is "true" if traceloop-sdk is installed.

    Returns:
        True if auto-instrumentation should be enabled, False otherwise
    """
    env_value = os.getenv("LLM_AUTO_INSTRUMENTATION_ENABLED")

    if env_value is not None:
        return env_value.lower() in ("true", "1", "yes", "on")

    # Default to True if traceloop-sdk is available
    return _is_traceloop_available()


class LLMAutoInstrumentor:
    """Auto-instrumentation for LLM providers using OpenLLMetry.

    Captures real token counts from provider API responses and
    integrates with existing OTel infrastructure.

    This class wraps the Traceloop SDK initialization and configures it
    to use the existing OTLP exporter from OTelSetup. It also registers
    a custom span processor (LLMMetricsExtractor) to extract token metrics
    from the generated spans.

    Attributes:
        _otel_setup: Reference to the OTelSetup instance for OTel integration
        _initialized: Whether initialization was successful
        _metrics_extractor: The LLMMetricsExtractor instance for extracting metrics

    Example:
        ```python
        from agent_framework.monitoring import OTelSetup, LLMAutoInstrumentor

        otel_setup = OTelSetup()
        otel_setup.initialize()

        instrumentor = LLMAutoInstrumentor(otel_setup)
        if instrumentor.initialize():
            print("LLM auto-instrumentation enabled")

            # After LLM calls, get metrics
            metrics = instrumentor.get_metrics_for_span(trace_id)
        ```
    """

    def __init__(self, otel_setup: OTelSetup) -> None:
        """Initialize the LLMAutoInstrumentor.

        Args:
            otel_setup: The OTelSetup instance to integrate with
        """
        self._otel_setup = otel_setup
        self._initialized = False
        self._metrics_extractor: "LLMMetricsExtractor | None" = None

    def initialize(self) -> bool:
        """Initialize OpenLLMetry auto-instrumentation.

        This method:
        1. Checks if auto-instrumentation is enabled via environment variable
        2. Imports and initializes the Traceloop SDK
        3. Configures it to use the existing OTLP exporter
        4. Registers the LLMMetricsExtractor as a span processor

        Returns:
            True if initialization succeeded, False otherwise.
            Returns False if:
            - Auto-instrumentation is disabled via environment variable
            - traceloop-sdk is not installed
            - Initialization fails for any reason

        Example:
            ```python
            instrumentor = LLMAutoInstrumentor(otel_setup)
            if instrumentor.initialize():
                print("Ready to capture LLM metrics")
            else:
                print("Using fallback manual token counting")
            ```
        """
        # Check if auto-instrumentation is enabled
        if not _is_auto_instrumentation_enabled():
            logger.info(
                "LLM auto-instrumentation disabled via LLM_AUTO_INSTRUMENTATION_ENABLED"
            )
            return False

        try:
            from traceloop.sdk import Traceloop

            from agent_framework.monitoring.llm_metrics_extractor import LLMMetricsExtractor

            # Get the span exporter from OTelSetup if available
            span_exporter = self._get_span_exporter()

            # Initialize Traceloop with existing exporter
            # Note: Traceloop.init() configures auto-instrumentation for LLM providers
            init_kwargs: dict = {
                "disable_batch": False,
                "propagate_context": True,
            }

            # Only pass exporter if we have one configured
            if span_exporter is not None:
                init_kwargs["exporter"] = span_exporter

            Traceloop.init(**init_kwargs)

            # Create and register the metrics extractor as a span processor
            self._metrics_extractor = LLMMetricsExtractor()
            self._add_span_processor(self._metrics_extractor)

            self._initialized = True
            logger.info("✅ LLM auto-instrumentation initialized (OpenLLMetry)")
            return True

        except ImportError:
            logger.warning(
                "OpenLLMetry (traceloop-sdk) not installed. "
                "Using manual token counting. "
                "Install with: pip install traceloop-sdk"
            )
            return False
        except Exception as e:
            logger.error(f"Failed to initialize LLM auto-instrumentation: {e}")
            return False

    def _get_span_exporter(self):
        """Get the span exporter from OTelSetup.

        This method attempts to get the configured OTLP span exporter
        from the OTelSetup instance.

        Returns:
            The span exporter if available, None otherwise
        """
        try:
            # Try to get the exporter from OTelSetup
            # OTelSetup creates exporters internally, we need to create a new one
            # with the same configuration
            if not self._otel_setup.config.otlp_endpoint:
                return None

            return self._otel_setup._create_otlp_span_exporter()
        except Exception as e:
            logger.debug(f"Could not get span exporter from OTelSetup: {e}")
            return None

    def _add_span_processor(self, processor) -> None:
        """Add a span processor to the tracer provider.

        This method adds the given span processor to the OTel tracer provider
        so it can intercept and process LLM spans.

        Args:
            processor: The span processor to add (must implement SpanProcessor interface)
        """
        try:
            # Get the tracer provider from OTelSetup
            if self._otel_setup._tracer_provider is not None:
                self._otel_setup._tracer_provider.add_span_processor(processor)
                logger.debug("Added LLMMetricsExtractor as span processor")
            else:
                # Fallback: try to get the global tracer provider
                from opentelemetry import trace

                provider = trace.get_tracer_provider()
                if hasattr(provider, "add_span_processor"):
                    provider.add_span_processor(processor)
                    logger.debug(
                        "Added LLMMetricsExtractor to global tracer provider"
                    )
        except Exception as e:
            logger.warning(f"Could not add span processor: {e}")

    @property
    def is_initialized(self) -> bool:
        """Check if auto-instrumentation has been successfully initialized.

        Returns:
            True if initialize() completed successfully, False otherwise
        """
        return self._initialized

    def get_metrics_for_span(self, trace_id: str) -> "LLMMetrics | None":
        """Get extracted metrics for a specific trace.

        This method retrieves the accumulated LLM metrics for the given trace ID.
        The metrics are extracted from OpenLLMetry spans by the LLMMetricsExtractor.

        Note: This method consumes the metrics - calling it again with the same
        trace_id will return None. Use peek_metrics_for_span() to check without
        consuming.

        Args:
            trace_id: The trace ID to get metrics for (32-character hex string)

        Returns:
            LLMMetrics with token counts and timing, or None if:
            - Auto-instrumentation is not initialized
            - No metrics exist for the given trace_id

        Example:
            ```python
            # After an LLM call completes
            metrics = instrumentor.get_metrics_for_span(trace_id)
            if metrics:
                print(f"Input tokens: {metrics.input_tokens}")
                print(f"Output tokens: {metrics.output_tokens}")
            ```
        """
        if self._metrics_extractor is not None:
            return self._metrics_extractor.get_metrics(trace_id)
        return None

    def peek_metrics_for_span(self, trace_id: str) -> "LLMMetrics | None":
        """Peek at metrics for a trace without consuming them.

        Unlike get_metrics_for_span(), this method does not remove the metrics
        from the accumulator, allowing multiple peeks.

        Args:
            trace_id: The trace ID to peek metrics for

        Returns:
            LLMMetrics with token counts and timing, or None if not available
        """
        if self._metrics_extractor is not None:
            return self._metrics_extractor.peek_metrics(trace_id)
        return None

    def has_metrics_for_span(self, trace_id: str) -> bool:
        """Check if metrics exist for a trace.

        Args:
            trace_id: The trace ID to check

        Returns:
            True if metrics exist for the trace, False otherwise
        """
        if self._metrics_extractor is not None:
            return self._metrics_extractor.has_metrics(trace_id)
        return False

    def shutdown(self) -> None:
        """Shutdown the auto-instrumentor and clean up resources.

        This method should be called during application shutdown to
        properly clean up the metrics extractor.
        """
        if self._metrics_extractor is not None:
            self._metrics_extractor.shutdown()
            self._metrics_extractor = None
        self._initialized = False
        logger.debug("LLM auto-instrumentor shutdown complete")


# Module-level singleton for convenience
_default_auto_instrumentor: LLMAutoInstrumentor | None = None


def get_llm_auto_instrumentor(otel_setup: "OTelSetup | None" = None) -> LLMAutoInstrumentor | None:
    """Get or create the default LLMAutoInstrumentor instance.

    This function provides a convenient way to access a singleton
    LLMAutoInstrumentor instance. If no instance exists and an OTelSetup
    is provided, a new instance is created.

    Args:
        otel_setup: Optional OTelSetup instance. Required for first call
                   to create the instrumentor.

    Returns:
        LLMAutoInstrumentor instance, or None if no instance exists
        and no OTelSetup was provided.

    Example:
        ```python
        # First call - create the instrumentor
        instrumentor = get_llm_auto_instrumentor(otel_setup)
        instrumentor.initialize()

        # Subsequent calls - get existing instance
        instrumentor = get_llm_auto_instrumentor()
        ```
    """
    global _default_auto_instrumentor

    if _default_auto_instrumentor is None and otel_setup is not None:
        _default_auto_instrumentor = LLMAutoInstrumentor(otel_setup)

    return _default_auto_instrumentor


def reset_llm_auto_instrumentor() -> None:
    """Reset the default LLMAutoInstrumentor instance.

    Useful for testing or reconfiguration. Shuts down the existing
    instrumentor if initialized.
    """
    global _default_auto_instrumentor

    if _default_auto_instrumentor is not None:
        _default_auto_instrumentor.shutdown()
        _default_auto_instrumentor = None
