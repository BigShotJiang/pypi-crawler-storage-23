"""Streaming Latency Tracer for span instrumentation.

This module provides granular instrumentation for the streaming endpoint
preprocessing pipeline. It creates hierarchical spans for each preprocessing
step, enabling visibility into latency bottlenecks.

DEPRECATION NOTE:
    Direct ES writing is deprecated. Use MetricsAggregator for unified metrics.
    This tracer now only provides span context managers for timing measurement.
    The MetricsAggregator collects span timings and writes them to the unified
    index (agent-metrics-*) as flat fields.

Environment Variables:
    METRICS_ENABLED: Enable metrics collection (default: true)
    METRICS_INDEX_PREFIX: Base prefix for indices (default: agent-metrics)
"""

from __future__ import annotations

import logging
import time
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from collections.abc import AsyncGenerator


logger = logging.getLogger(__name__)


@dataclass
class SpanAttributes:
    """Standard attributes for streaming latency spans."""

    session_id: str | None = None
    user_id: str | None = None
    agent_id: str | None = None
    request_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {
            k: v
            for k, v in {
                "session_id": self.session_id,
                "user_id": self.user_id,
                "agent_id": self.agent_id,
                "request_id": self.request_id,
            }.items()
            if v is not None
        }


@dataclass
class SpanData:
    """Data structure for a single span to be logged to ES."""

    span_id: str
    span_name: str
    span_type: str
    start_time: datetime
    end_time: datetime | None = None
    duration_ms: float | None = None
    status: str = "OK"
    error_message: str | None = None
    attributes: dict[str, Any] = field(default_factory=dict)

    def to_elasticsearch_doc(self) -> dict[str, Any]:
        """Convert to Elasticsearch document format."""
        doc = {
            "@timestamp": (self.end_time or self.start_time).isoformat(),
            "span_id": self.span_id,
            "span_name": self.span_name,
            "span_type": self.span_type,
            "start_time": self.start_time.isoformat(),
            "duration_ms": self.duration_ms,
            "status": self.status,
        }
        if self.end_time:
            doc["end_time"] = self.end_time.isoformat()
        if self.error_message:
            doc["error_message"] = self.error_message
        doc.update(self.attributes)
        return doc


class SpanContext:
    """Context object returned by span context managers."""

    def __init__(self, span_data: SpanData | None):
        self._span_data = span_data

    def set_attribute(self, key: str, value: Any) -> None:
        """Set an attribute on the span."""
        if self._span_data:
            self._span_data.attributes[key] = value



class StreamingLatencyTracer:
    """Logs streaming latency spans directly to Elasticsearch.

    This class writes span data to ES using the same pattern as LLMMetricsLogger,
    with batching, circuit breaker integration, and fallback logging.
    """

    TRACER_NAME = "agent_framework.streaming"

    def __init__(self, es_client: Any | None = None) -> None:
        """Initialize the tracer."""
        from agent_framework.monitoring.metrics_config import get_metrics_config

        self._es_client = es_client
        self._config = get_metrics_config()
        self._base_attributes: SpanAttributes = SpanAttributes()

        self._closed = False
        self._initialized = es_client is not None

        logger.debug(
            f"Initialized StreamingLatencyTracer: "
            f"unified_index={self._config.unified_index_pattern}, "
            f"enabled={self._config.enabled}"
        )

    @property
    def is_initialized(self) -> bool:
        """Check if the tracer has an ES client."""
        return self._initialized

    def set_es_client(self, es_client: Any) -> None:
        """Set the ES client after initialization."""
        self._es_client = es_client
        self._initialized = es_client is not None

    def set_base_attributes(self, attributes: SpanAttributes) -> None:
        """Set base attributes that will be added to all spans."""
        self._base_attributes = attributes

    def _get_index_name(self) -> str:
        """Get the current unified index name with date substitution.
        
        DEPRECATED: Direct ES writing is deprecated. Use MetricsAggregator instead.
        This method is kept for backward compatibility with fallback logging.
        """
        return self._config.get_unified_index_name()

    @asynccontextmanager
    async def preprocessing_span(
        self,
        name: str,
        attributes: dict[str, Any] | None = None,
    ) -> AsyncGenerator[SpanContext, None]:
        """Create a span for a preprocessing step."""
        full_name = f"preprocessing.{name}"
        async with self._create_span(full_name, "preprocessing", attributes) as ctx:
            yield ctx

    @asynccontextmanager
    async def agent_span(
        self,
        name: str,
        attributes: dict[str, Any] | None = None,
    ) -> AsyncGenerator[SpanContext, None]:
        """Create a span for an agent operation."""
        full_name = f"agent.{name}"
        async with self._create_span(full_name, "agent", attributes) as ctx:
            yield ctx

    @asynccontextmanager
    async def llm_span(
        self,
        name: str,
        model_name: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> AsyncGenerator[SpanContext, None]:
        """Create a span for an LLM operation."""
        full_name = f"llamaindex.{name}"
        all_attributes = {**(attributes or {})}
        if model_name:
            all_attributes["model_name"] = model_name
        async with self._create_span(full_name, "llamaindex", all_attributes) as ctx:
            yield ctx

    @asynccontextmanager
    async def _create_span(
        self,
        name: str,
        span_type: str,
        attributes: dict[str, Any] | None = None,
    ) -> AsyncGenerator[SpanContext, None]:
        """Internal method to create and log a span."""
        if not self._config.enabled:
            yield SpanContext(None)
            return

        span_data = SpanData(
            span_id=str(uuid.uuid4()),
            span_name=name,
            span_type=span_type,
            start_time=datetime.now(timezone.utc),
            attributes={**self._base_attributes.to_dict(), **(attributes or {})},
        )

        start_time = time.perf_counter()
        ctx = SpanContext(span_data)

        try:
            yield ctx
            span_data.status = "OK"
        except Exception as e:
            span_data.status = "ERROR"
            span_data.error_message = str(e)
            raise
        finally:
            span_data.end_time = datetime.now(timezone.utc)
            span_data.duration_ms = (time.perf_counter() - start_time) * 1000
            self._log_span(span_data)

    def record_ttft(self, ctx: SpanContext, ttft_ms: float) -> None:
        """Record time-to-first-token on a span context."""
        ctx.set_attribute("time_to_first_token_ms", ttft_ms)

    def _log_span(self, span_data: SpanData) -> None:
        """Log span data (for debugging/fallback only).
        
        DEPRECATED: Direct ES writing is deprecated. Use MetricsAggregator instead.
        This method now only logs to standard logging for debugging purposes.
        """
        if self._closed:
            return

        log_data = {
            "type": "streaming_span",
            "span_name": span_data.span_name,
            "span_type": span_data.span_type,
            "duration_ms": span_data.duration_ms,
            "status": span_data.status,
            "session_id": span_data.attributes.get("session_id"),
        }
        logger.debug(f"STREAMING_SPAN: {log_data}")

    async def flush(self) -> None:
        """Flush operation (no-op, kept for backward compatibility).
        
        DEPRECATED: Direct ES writing is deprecated. Use MetricsAggregator instead.
        """
        pass

    def close(self) -> None:
        """Close the tracer."""
        self._closed = True
        logger.debug("StreamingLatencyTracer closed")



# Singleton instance
_default_tracer: StreamingLatencyTracer | None = None


def get_streaming_latency_tracer() -> StreamingLatencyTracer:
    """Get or create the default StreamingLatencyTracer instance."""
    global _default_tracer
    if _default_tracer is None:
        _default_tracer = StreamingLatencyTracer()
    return _default_tracer


async def initialize_streaming_latency_tracer(
    es_client: Any | None = None,
) -> StreamingLatencyTracer:
    """Initialize the tracer with an ES client."""
    global _default_tracer

    if es_client is None:
        from agent_framework.session.session_storage import get_shared_elasticsearch_client
        es_client = await get_shared_elasticsearch_client()

    if _default_tracer is None:
        _default_tracer = StreamingLatencyTracer(es_client)
    else:
        _default_tracer.set_es_client(es_client)

    logger.info("StreamingLatencyTracer initialized with ES client")
    return _default_tracer


def reset_streaming_latency_tracer() -> None:
    """Reset the default tracer instance."""
    global _default_tracer
    _default_tracer = None


# DEPRECATED: ensure_spans_index_template is no longer needed.
# Use ensure_unified_index_template from metrics_aggregator instead.
# This function is kept as a no-op for backward compatibility.
async def ensure_spans_index_template(es_client: Any | None = None) -> bool:
    """DEPRECATED: Use ensure_unified_index_template from metrics_aggregator instead.
    
    This function is a no-op kept for backward compatibility.
    The unified index template (agent-metrics-*) now contains all span fields.
    """
    logger.warning(
        "ensure_spans_index_template is deprecated. "
        "Use ensure_unified_index_template from metrics_aggregator instead."
    )
    return True
