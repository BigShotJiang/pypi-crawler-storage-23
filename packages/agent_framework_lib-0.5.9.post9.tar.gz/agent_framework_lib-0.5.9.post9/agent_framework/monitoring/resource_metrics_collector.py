"""Resource Metrics Collector Module.

Collects system resource metrics (CPU and RAM) using psutil.
Provides non-blocking measurements for integration with OpenTelemetry
spans and Elasticsearch metrics aggregation.

This module provides:
- ResourceMetrics Pydantic model for structured metrics data
- ResourceMetricsCollector for collecting CPU and memory metrics
- Environment-based enable/disable configuration
- Graceful fallback when psutil is unavailable
"""

import logging
import os

from pydantic import BaseModel


logger = logging.getLogger(__name__)


class ResourceMetrics(BaseModel):
    """System resource metrics.

    Attributes:
        cpu_percent: CPU usage percentage (0-100)
        memory_used_mb: Memory used in megabytes
        memory_available_mb: Memory available in megabytes
        memory_percent: Memory usage percentage (0-100)
    """

    cpu_percent: float
    memory_used_mb: int
    memory_available_mb: int
    memory_percent: float


class ResourceMetricsCollector:
    """Collector for system resource metrics.

    Collects CPU and memory metrics using psutil. Can be enabled or disabled
    via the RESOURCE_METRICS_ENABLED environment variable (default: true).

    Uses psutil.cpu_percent(interval=None) for non-blocking CPU measurement,
    which returns the CPU usage since the last call or since module import.

    Attributes:
        enabled: Whether metrics collection is active

    Example:
        ```python
        collector = ResourceMetricsCollector()

        # Collect metrics
        metrics = collector.collect()
        if metrics:
            print(f"CPU: {metrics.cpu_percent}%")
            print(f"Memory: {metrics.memory_used_mb}MB used")
        ```
    """

    _psutil_available: bool | None = None
    _psutil_warning_logged: bool = False

    def __init__(self, enabled: bool | None = None) -> None:
        """Initialize the resource metrics collector.

        Args:
            enabled: Whether to collect metrics. If None, reads from
                RESOURCE_METRICS_ENABLED environment variable (default: true).
        """
        if enabled is None:
            env_value = os.environ.get("RESOURCE_METRICS_ENABLED", "true").lower()
            self.enabled = env_value in ("true", "1", "yes", "on")
        else:
            self.enabled = enabled

        self._check_psutil_availability()

    def _check_psutil_availability(self) -> None:
        """Check if psutil is available and log warning if not."""
        if ResourceMetricsCollector._psutil_available is None:
            try:
                import psutil  # noqa: F401

                ResourceMetricsCollector._psutil_available = True
            except ImportError:
                ResourceMetricsCollector._psutil_available = False
                if not ResourceMetricsCollector._psutil_warning_logged:
                    logger.warning(
                        "psutil is not available. Resource metrics collection will be disabled. "
                        "Install psutil with: pip install psutil"
                    )
                    ResourceMetricsCollector._psutil_warning_logged = True

    @property
    def is_available(self) -> bool:
        """Check if psutil is available for metrics collection.

        Returns:
            True if psutil is installed and importable, False otherwise.
        """
        return ResourceMetricsCollector._psutil_available is True

    def collect(self) -> ResourceMetrics | None:
        """Collect current CPU and RAM metrics.

        Uses psutil.cpu_percent(interval=None) for non-blocking CPU measurement
        and psutil.virtual_memory() for memory information.

        Returns:
            ResourceMetrics object with current metrics, or None if:
            - Collection is disabled via RESOURCE_METRICS_ENABLED
            - psutil is not available
            - An error occurs during collection

        Note:
            The first call to cpu_percent(interval=None) may return 0.0 or
            a meaningless value. Subsequent calls return the CPU usage since
            the previous call.
        """
        if not self.enabled:
            return None

        if not self.is_available:
            return None

        try:
            import psutil

            cpu_percent = psutil.cpu_percent(interval=None)

            memory = psutil.virtual_memory()
            memory_used_mb = int(memory.used / (1024 * 1024))
            memory_available_mb = int(memory.available / (1024 * 1024))
            memory_percent = memory.percent

            return ResourceMetrics(
                cpu_percent=cpu_percent,
                memory_used_mb=memory_used_mb,
                memory_available_mb=memory_available_mb,
                memory_percent=memory_percent,
            )

        except Exception as e:
            logger.warning(f"Failed to collect resource metrics: {e}")
            return None
