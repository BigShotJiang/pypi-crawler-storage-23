"""Unified Metrics Aggregator for consolidated observability.

This module provides a MetricsAggregator component that collects all metrics
during a request lifecycle and writes a single consolidated document to
Elasticsearch at the end of the request.

The consolidation eliminates duplicate metrics, simplifies correlation
(no more joining 3 indices by request_id), reduces dashboard confusion,
and decreases maintenance overhead (single template, single rotation policy).

Key Features:
- Single unified document per request
- API timing phases (preprocessing, LLM, postprocessing)
- LLM metrics (tokens, TTFT, duration)
- Tool call tracking with graceful handling of missing starts
- Span timings as flat fields
- Resource metrics (CPU and memory)
- Circuit breaker integration for ES resilience
- Fallback to standard logging when ES unavailable

Example:
    ```python
    from agent_framework.monitoring.metrics_aggregator import MetricsAggregator
    from agent_framework.monitoring.resource_metrics_collector import ResourceMetrics

    # Create aggregator at start of request
    aggregator = MetricsAggregator(
        request_id="req-123",
        endpoint="/api/stream",
        method="POST",
        es_client=es_client,
    )

    # Record timing phases
    aggregator.start_request()
    aggregator.start_preprocessing()
    # ... preprocessing work ...
    aggregator.end_preprocessing()

    aggregator.start_llm()
    # ... LLM call ...
    aggregator.record_ttft(150.0)
    aggregator.end_llm()

    aggregator.start_postprocessing()
    # ... postprocessing work ...
    aggregator.end_postprocessing()

    # Record resource metrics
    resource_metrics = ResourceMetrics(
        cpu_percent=45.5,
        memory_used_mb=8192,
        memory_available_mb=8192,
        memory_percent=50.0,
    )
    aggregator.record_resource_metrics(resource_metrics)

    # Record tokens and finalize
    aggregator.record_tokens(input_tokens=100, output_tokens=200)
    doc = await aggregator.finalize()
    ```

Version: 0.1.0
"""

import logging
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field


if TYPE_CHECKING:
    from agent_framework.monitoring.resource_metrics_collector import ResourceMetrics

logger = logging.getLogger(__name__)


class UnifiedMetricsDocument(BaseModel):
    """Single document containing all metrics for a request.

    This Pydantic model represents the unified metrics document that is written
    to Elasticsearch. It contains API timing, LLM metrics, span timings, resource
    metrics, and context fields in a single flat structure.

    Attributes:
        timestamp: Document timestamp (aliased to @timestamp for ES)
        request_id: Unique identifier for the request
        session_id: Session identifier
        user_id: User identifier
        agent_id: Agent identifier
        endpoint: API endpoint path
        method: HTTP method
        model_name: LLM model name
        total_api_duration_ms: Total API request duration
        preprocessing_duration_ms: Preprocessing phase duration
        postprocessing_duration_ms: Postprocessing phase duration
        llm_duration_ms: LLM call duration
        time_to_first_token_ms: Time to first token
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
        thinking_tokens: Number of thinking/reasoning tokens
        total_tokens: Total token count
        tokens_per_second: Output tokens per second
        tool_call_count: Number of tool calls
        tool_call_total_ms: Total tool call duration
        span_*: Various span timing fields
        cpu_percent: CPU usage percentage (0-100)
        memory_used_mb: Memory used in megabytes
        memory_available_mb: Memory available in megabytes
        memory_percent: Memory usage percentage (0-100)
        is_streaming: Whether this was a streaming request
        status_code: HTTP response status code
        error_message: Error message if request failed
    """

    # Timestamp - use serialization_alias for ES output, but accept 'timestamp' as input
    timestamp: datetime = Field(serialization_alias="@timestamp")

    # Request context
    request_id: str
    session_id: str | None = None
    user_id: str | None = None
    agent_id: str | None = None
    endpoint: str | None = None
    method: str | None = None
    model_name: str | None = None

    # API timing
    total_api_duration_ms: float | None = None
    preprocessing_duration_ms: float | None = None
    postprocessing_duration_ms: float | None = None

    # LLM metrics
    llm_duration_ms: float | None = None
    time_to_first_token_ms: float | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    thinking_tokens: int = 0
    total_tokens: int = 0
    tokens_per_second: float | None = None

    # Tool calls
    tool_call_count: int = 0
    tool_call_total_ms: float = 0.0

    # Span timings (flat fields)
    span_preprocessing_load_session_ms: float | None = None
    span_preprocessing_process_files_ms: float | None = None
    span_preprocessing_get_agent_ms: float | None = None
    span_preprocessing_get_history_ms: float | None = None
    span_preprocessing_model_routing_ms: float | None = None
    span_preprocessing_configure_model_ms: float | None = None
    span_preprocessing_persist_user_message_ms: float | None = None
    span_preprocessing_build_query_ms: float | None = None
    span_agent_instantiate_ms: float | None = None
    span_agent_inject_storage_ms: float | None = None
    span_agent_load_config_ms: float | None = None
    span_agent_load_state_ms: float | None = None
    span_agent_configure_session_ms: float | None = None
    span_agent_ensure_built_ms: float | None = None
    span_agent_create_context_ms: float | None = None
    span_agent_build_query_ms: float | None = None
    span_agent_memory_injection_ms: float | None = None
    span_llamaindex_load_memory_ms: float | None = None
    span_llamaindex_sanitize_memory_ms: float | None = None
    span_llamaindex_llm_call_ms: float | None = None
    # Span timings - postprocessing
    span_postprocessing_consolidate_parts_ms: float | None = None
    span_postprocessing_persist_response_ms: float | None = None
    span_postprocessing_build_final_response_ms: float | None = None

    # Resource metrics
    cpu_percent: float | None = None
    memory_used_mb: int | None = None
    memory_available_mb: int | None = None
    memory_percent: float | None = None

    # Status
    is_streaming: bool = False
    status_code: int | None = None
    error_message: str | None = None

    model_config = {"populate_by_name": True}

    def to_elasticsearch_doc(self) -> dict[str, Any]:
        """Convert to Elasticsearch document format.

        Returns:
            Dictionary suitable for indexing in Elasticsearch with @timestamp
            in ISO format.
        """
        doc = self.model_dump(by_alias=True, exclude_none=False)
        # Ensure @timestamp is ISO format
        if isinstance(doc.get("@timestamp"), datetime):
            doc["@timestamp"] = doc["@timestamp"].isoformat()
        return doc


class MetricsAggregator:
    """Collects all metrics during request lifecycle and writes unified document.

    This class is the central component for metrics consolidation. It collects
    API timing, LLM metrics, tool call tracking, and span timings during a
    request lifecycle, then writes a single consolidated document to
    Elasticsearch at the end of the request.

    The aggregator uses the circuit breaker pattern for ES resilience and
    falls back to standard logging when ES is unavailable.

    Attributes:
        request_id: Unique identifier for the request

    Example:
        ```python
        aggregator = MetricsAggregator(
            request_id="req-123",
            endpoint="/api/stream",
            es_client=es_client,
        )

        aggregator.start_request()
        aggregator.start_preprocessing()
        aggregator.end_preprocessing()
        aggregator.start_llm()
        aggregator.record_ttft(150.0)
        aggregator.end_llm()
        aggregator.record_tokens(input_tokens=100, output_tokens=200)
        doc = await aggregator.finalize()
        ```
    """

    def __init__(
        self,
        request_id: str,
        endpoint: str | None = None,
        method: str | None = None,
        es_client: Any | None = None,
    ) -> None:
        """Initialize the MetricsAggregator.

        Args:
            request_id: Unique identifier for the request
            endpoint: API endpoint path (e.g., "/api/stream")
            method: HTTP method (e.g., "POST")
            es_client: Elasticsearch client for writing metrics
        """
        self._request_id = request_id
        self._endpoint = endpoint
        self._method = method
        self._es_client = es_client

        # Timing state
        self._request_start: float | None = None
        self._request_start_dt: datetime | None = None
        self._preprocessing_start: float | None = None
        self._preprocessing_end: float | None = None
        self._llm_start: float | None = None
        self._llm_end: float | None = None
        self._postprocessing_start: float | None = None
        self._postprocessing_end: float | None = None

        # TTFT (recorded once, used consistently)
        self._ttft_ms: float | None = None
        self._ttft_recorded: bool = False

        # Token counts
        self._input_tokens: int = 0
        self._output_tokens: int = 0
        self._thinking_tokens: int = 0

        # Tool calls
        self._tool_call_starts: dict[str, float] = {}
        self._tool_call_durations: list[float] = []

        # Span timings
        self._span_timings: dict[str, float] = {}

        # Context
        self._session_id: str | None = None
        self._user_id: str | None = None
        self._agent_id: str | None = None
        self._model_name: str | None = None
        self._is_streaming: bool = False
        self._status_code: int | None = None
        self._error_message: str | None = None

        # Resource metrics
        self._cpu_percent: float | None = None
        self._memory_used_mb: int | None = None
        self._memory_available_mb: int | None = None
        self._memory_percent: float | None = None

        self._finalized: bool = False

    @property
    def request_id(self) -> str:
        """Get the request ID."""
        return self._request_id

    def set_context(
        self,
        session_id: str | None = None,
        user_id: str | None = None,
        agent_id: str | None = None,
        model_name: str | None = None,
        is_streaming: bool | None = None,
    ) -> None:
        """Set request context information.

        Args:
            session_id: Session identifier
            user_id: User identifier
            agent_id: Agent identifier
            model_name: LLM model name
            is_streaming: Whether this is a streaming request
        """
        if session_id is not None:
            self._session_id = session_id
        if user_id is not None:
            self._user_id = user_id
        if agent_id is not None:
            self._agent_id = agent_id
        if model_name is not None:
            self._model_name = model_name
        if is_streaming is not None:
            self._is_streaming = is_streaming

    # === API Timing Methods ===

    def start_request(self) -> None:
        """Record start of API request."""
        self._request_start = time.perf_counter()
        self._request_start_dt = datetime.now(timezone.utc)

    def start_preprocessing(self) -> None:
        """Record start of preprocessing phase."""
        self._preprocessing_start = time.perf_counter()

    def end_preprocessing(self) -> None:
        """Record end of preprocessing phase."""
        self._preprocessing_end = time.perf_counter()

    def start_llm(self) -> None:
        """Record start of LLM call."""
        self._llm_start = time.perf_counter()

    def end_llm(self) -> None:
        """Record end of LLM call (immediately after await handler)."""
        self._llm_end = time.perf_counter()

    def start_postprocessing(self) -> None:
        """Record start of postprocessing phase."""
        self._postprocessing_start = time.perf_counter()

    def end_postprocessing(self) -> None:
        """Record end of postprocessing phase."""
        self._postprocessing_end = time.perf_counter()

    # === LLM Metrics Methods ===

    def record_ttft(self, ttft_ms: float) -> None:
        """Record time to first token (only once, for consistency).

        This method ensures TTFT is recorded exactly once. Subsequent calls
        are ignored to maintain consistency across all metrics.

        Args:
            ttft_ms: Time to first token in milliseconds
        """
        if not self._ttft_recorded:
            self._ttft_ms = ttft_ms
            self._ttft_recorded = True

    def record_tokens(
        self,
        input_tokens: int = 0,
        output_tokens: int = 0,
        thinking_tokens: int = 0,
    ) -> None:
        """Record token counts.

        Args:
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            thinking_tokens: Number of thinking/reasoning tokens
        """
        self._input_tokens = input_tokens
        self._output_tokens = output_tokens
        self._thinking_tokens = thinking_tokens

    # === Tool Call Methods ===

    def start_tool_call(self, tool_id: str) -> None:
        """Record start of a tool call.

        Args:
            tool_id: Unique identifier for the tool call
        """
        self._tool_call_starts[tool_id] = time.perf_counter()

    def end_tool_call(self, tool_id: str) -> None:
        """Record end of a tool call (handles missing starts gracefully).

        This method handles the case where end_tool_call is called without
        a corresponding start_tool_call. In this case, it logs a warning
        and counts the tool call with 0ms duration.

        Args:
            tool_id: Unique identifier for the tool call
        """
        if tool_id in self._tool_call_starts:
            duration = (time.perf_counter() - self._tool_call_starts[tool_id]) * 1000
            self._tool_call_durations.append(duration)
            del self._tool_call_starts[tool_id]
        else:
            # Bug fix: Handle end_tool_call called before start_tool_call
            logger.warning(
                f"end_tool_call for unknown tool_id: {tool_id}, counting with 0ms duration"
            )
            self._tool_call_durations.append(0.0)

    def add_tool_call_durations(self, durations: list[float]) -> None:
        """Add pre-recorded tool call durations.

        This method allows transferring tool call durations from another
        metrics collector (e.g., LLMMetricsCollector) to the aggregator.

        Args:
            durations: List of tool call durations in milliseconds
        """
        self._tool_call_durations.extend(durations)

    # === Span Timing Methods ===

    def record_span(self, span_type: str, span_name: str, duration_ms: float) -> None:
        """Record a span timing as a flat field.

        The span is stored with a field name following the convention:
        span_{span_type}_{span_name}_ms

        Dots and hyphens in span_type and span_name are replaced with underscores.

        Args:
            span_type: Type of span (e.g., "preprocessing", "agent")
            span_name: Name of span (e.g., "load_session", "build_query")
            duration_ms: Duration in milliseconds
        """
        # Normalize span name to valid field name
        field_name = f"span_{span_type}_{span_name}_ms".replace(".", "_").replace("-", "_")
        self._span_timings[field_name] = duration_ms

    # === Resource Metrics Methods ===

    def record_resource_metrics(
        self,
        metrics: "ResourceMetrics | None",
    ) -> None:
        """Record resource metrics (CPU and memory).

        Args:
            metrics: ResourceMetrics object containing cpu_percent, memory_used_mb,
                memory_available_mb, and memory_percent. If None, no metrics are recorded.
        """
        if metrics is None:
            return

        self._cpu_percent = metrics.cpu_percent
        self._memory_used_mb = metrics.memory_used_mb
        self._memory_available_mb = metrics.memory_available_mb
        self._memory_percent = metrics.memory_percent

    # === Finalization ===

    def set_status(self, status_code: int, error_message: str | None = None) -> None:
        """Set response status.

        Args:
            status_code: HTTP response status code
            error_message: Error message if request failed
        """
        self._status_code = status_code
        self._error_message = error_message

    def _build_document(self) -> UnifiedMetricsDocument:
        """Build the unified metrics document.

        Returns:
            UnifiedMetricsDocument containing all collected metrics
        """
        request_end = time.perf_counter()

        # Calculate durations
        total_api_duration_ms = None
        preprocessing_duration_ms = None
        llm_duration_ms = None
        postprocessing_duration_ms = None

        if self._request_start is not None:
            total_api_duration_ms = (request_end - self._request_start) * 1000

        if self._preprocessing_start is not None and self._preprocessing_end is not None:
            preprocessing_duration_ms = (self._preprocessing_end - self._preprocessing_start) * 1000

        if self._llm_start is not None and self._llm_end is not None:
            llm_duration_ms = (self._llm_end - self._llm_start) * 1000

        if self._postprocessing_start is not None and self._postprocessing_end is not None:
            postprocessing_duration_ms = (
                self._postprocessing_end - self._postprocessing_start
            ) * 1000

        # Calculate tokens per second
        total_tokens = self._input_tokens + self._output_tokens + self._thinking_tokens
        tokens_per_second = None
        if llm_duration_ms and llm_duration_ms > 0 and self._output_tokens > 0:
            tokens_per_second = self._output_tokens / (llm_duration_ms / 1000)

        # Build document
        doc = UnifiedMetricsDocument(
            timestamp=self._request_start_dt or datetime.now(timezone.utc),
            request_id=self._request_id,
            session_id=self._session_id,
            user_id=self._user_id,
            agent_id=self._agent_id,
            endpoint=self._endpoint,
            method=self._method,
            model_name=self._model_name,
            total_api_duration_ms=total_api_duration_ms,
            preprocessing_duration_ms=preprocessing_duration_ms,
            postprocessing_duration_ms=postprocessing_duration_ms,
            llm_duration_ms=llm_duration_ms,
            time_to_first_token_ms=self._ttft_ms,
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            thinking_tokens=self._thinking_tokens,
            total_tokens=total_tokens,
            tokens_per_second=tokens_per_second,
            tool_call_count=len(self._tool_call_durations),
            tool_call_total_ms=sum(self._tool_call_durations) if self._tool_call_durations else 0.0,
            cpu_percent=self._cpu_percent,
            memory_used_mb=self._memory_used_mb,
            memory_available_mb=self._memory_available_mb,
            memory_percent=self._memory_percent,
            is_streaming=self._is_streaming,
            status_code=self._status_code,
            error_message=self._error_message,
        )

        # Add span timings as dynamic fields
        for field_name, duration in self._span_timings.items():
            if hasattr(doc, field_name):
                setattr(doc, field_name, duration)

        return doc

    async def finalize(self) -> UnifiedMetricsDocument:
        """Finalize metrics collection and write to Elasticsearch.

        This method builds the unified metrics document and writes it to
        Elasticsearch. If ES is unavailable (circuit breaker open or write
        failure), it falls back to standard logging.

        Returns:
            The finalized UnifiedMetricsDocument

        Raises:
            RuntimeError: If finalize() is called more than once
        """
        if self._finalized:
            raise RuntimeError("MetricsAggregator already finalized")

        self._finalized = True
        doc = self._build_document()

        # Write to Elasticsearch
        if self._es_client:
            await self._write_to_elasticsearch(doc)
        else:
            self._log_to_fallback(doc)

        return doc

    async def _write_to_elasticsearch(self, doc: UnifiedMetricsDocument) -> None:
        """Write document to Elasticsearch with circuit breaker.

        Args:
            doc: The unified metrics document to write
        """
        from agent_framework.monitoring.elasticsearch_circuit_breaker import (
            get_elasticsearch_circuit_breaker,
        )
        from agent_framework.monitoring.metrics_config import get_metrics_config

        circuit_breaker = get_elasticsearch_circuit_breaker()
        config = get_metrics_config()

        if not circuit_breaker.is_available():
            logger.warning("Circuit breaker open, using fallback logging for unified metrics")
            self._log_to_fallback(doc)
            return

        # ES client is guaranteed to be non-None when this method is called
        assert self._es_client is not None

        try:
            index_name = config.get_unified_index_name()
            await self._es_client.index(
                index=index_name,
                body=doc.to_elasticsearch_doc(),
            )
            circuit_breaker.record_success()
        except Exception as e:
            logger.error(f"Failed to write unified metrics to ES: {e}")
            circuit_breaker.record_failure()
            self._log_to_fallback(doc)

    def _log_to_fallback(self, doc: UnifiedMetricsDocument) -> None:
        """Log metrics to standard logging as fallback.

        Args:
            doc: The unified metrics document to log
        """
        log_data = {
            "type": "unified_metrics",
            "request_id": doc.request_id,
            "session_id": doc.session_id,
            "total_api_duration_ms": doc.total_api_duration_ms,
            "llm_duration_ms": doc.llm_duration_ms,
            "total_tokens": doc.total_tokens,
            "tool_call_count": doc.tool_call_count,
            "cpu_percent": doc.cpu_percent,
            "memory_used_mb": doc.memory_used_mb,
            "memory_percent": doc.memory_percent,
        }
        logger.info(f"UNIFIED_METRICS: {log_data}")


async def ensure_unified_index_template(es_client: Any | None = None) -> bool:
    """Ensure the unified metrics index template exists in Elasticsearch.

    Creates an index template that defines proper mappings for all unified metrics
    fields. This ensures that string fields like model_name and endpoint are indexed
    as 'keyword' type for aggregations, and numeric fields use appropriate types.

    Should be called once at application startup before logging metrics.

    Args:
        es_client: Elasticsearch client (if None, will use shared client)

    Returns:
        True if template was created/verified successfully, False otherwise
    """
    try:
        if es_client is None:
            from agent_framework.session.session_storage import get_shared_elasticsearch_client

            es_client = await get_shared_elasticsearch_client()

        if es_client is None:
            logger.warning("Cannot create unified index template: ES client not available")
            return False

        from agent_framework.monitoring.metrics_config import get_metrics_config

        config = get_metrics_config()

        # Unified metrics index template with all fields from design document
        template = {
            "index_patterns": [f"{config.index_prefix}-*"],
            "priority": 100,  # Higher priority to override other templates
            "template": {
                "settings": {
                    "number_of_shards": 1,
                    "number_of_replicas": 0,
                },
                "mappings": {
                    "properties": {
                        # Timestamp
                        "@timestamp": {"type": "date"},
                        # Request context
                        "request_id": {"type": "keyword"},
                        "session_id": {"type": "keyword"},
                        "user_id": {"type": "keyword"},
                        "agent_id": {"type": "keyword"},
                        "endpoint": {"type": "keyword"},
                        "method": {"type": "keyword"},
                        "model_name": {"type": "keyword"},
                        # API timing
                        "total_api_duration_ms": {"type": "float"},
                        "preprocessing_duration_ms": {"type": "float"},
                        "postprocessing_duration_ms": {"type": "float"},
                        # LLM metrics
                        "llm_duration_ms": {"type": "float"},
                        "time_to_first_token_ms": {"type": "float"},
                        "input_tokens": {"type": "integer"},
                        "output_tokens": {"type": "integer"},
                        "thinking_tokens": {"type": "integer"},
                        "total_tokens": {"type": "integer"},
                        "tokens_per_second": {"type": "float"},
                        # Tool calls
                        "tool_call_count": {"type": "integer"},
                        "tool_call_total_ms": {"type": "float"},
                        # Span timings - preprocessing
                        "span_preprocessing_load_session_ms": {"type": "float"},
                        "span_preprocessing_process_files_ms": {"type": "float"},
                        "span_preprocessing_get_agent_ms": {"type": "float"},
                        "span_preprocessing_get_history_ms": {"type": "float"},
                        "span_preprocessing_model_routing_ms": {"type": "float"},
                        "span_preprocessing_configure_model_ms": {"type": "float"},
                        "span_preprocessing_persist_user_message_ms": {"type": "float"},
                        "span_preprocessing_build_query_ms": {"type": "float"},
                        # Span timings - agent
                        "span_agent_instantiate_ms": {"type": "float"},
                        "span_agent_inject_storage_ms": {"type": "float"},
                        "span_agent_load_config_ms": {"type": "float"},
                        "span_agent_load_state_ms": {"type": "float"},
                        "span_agent_configure_session_ms": {"type": "float"},
                        "span_agent_ensure_built_ms": {"type": "float"},
                        "span_agent_create_context_ms": {"type": "float"},
                        "span_agent_build_query_ms": {"type": "float"},
                        "span_agent_memory_injection_ms": {"type": "float"},
                        # Span timings - llamaindex
                        "span_llamaindex_load_memory_ms": {"type": "float"},
                        "span_llamaindex_sanitize_memory_ms": {"type": "float"},
                        "span_llamaindex_llm_call_ms": {"type": "float"},
                        # Span timings - postprocessing
                        "span_postprocessing_consolidate_parts_ms": {"type": "float"},
                        "span_postprocessing_persist_response_ms": {"type": "float"},
                        "span_postprocessing_build_final_response_ms": {"type": "float"},
                        # Resource metrics
                        "cpu_percent": {"type": "float"},
                        "memory_used_mb": {"type": "integer"},
                        "memory_available_mb": {"type": "integer"},
                        "memory_percent": {"type": "float"},
                        # Status
                        "is_streaming": {"type": "boolean"},
                        "status_code": {"type": "integer"},
                        "error_message": {"type": "text"},
                    }
                },
            },
        }

        # Create the unified metrics template
        await es_client.indices.put_index_template(
            name=f"{config.index_prefix}-unified-template",
            body=template,
        )
        logger.info(
            f"Created/updated unified index template: {config.index_prefix}-unified-template"
        )

        return True

    except Exception as e:
        logger.error(f"Failed to create unified metrics index template: {e}")
        return False
