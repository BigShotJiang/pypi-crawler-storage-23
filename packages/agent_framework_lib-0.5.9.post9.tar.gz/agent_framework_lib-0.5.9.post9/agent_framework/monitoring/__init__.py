"""Monitoring module for performance, progress tracking, and error handling.

This module provides observability components for the Agent Framework:

Core Components:
    - ObservabilityManager: Unified facade for tracing, metrics, and logging
    - MetricsAggregator: Collects all metrics and writes unified document to ES
    - OTelSetup: OpenTelemetry initialization and configuration
    - TracingContextManager: API-first trace hierarchy management
    - OTelMetricsRecorder: OpenTelemetry metrics recording
    - OTelLoggingHandler: OpenTelemetry log handler with trace correlation

Usage:
    ```python
    from agent_framework.monitoring import get_observability_manager, MetricsAggregator

    # For general observability
    manager = get_observability_manager()
    manager.record_llm_call(llm_metrics)

    # For unified metrics per request
    aggregator = MetricsAggregator(request_id="req-123", endpoint="/stream")
    aggregator.start_request()
    # ... request processing ...
    await aggregator.finalize()
    ```
"""

from agent_framework.monitoring.api_timing_tracker import APITimingData, APITimingTracker
from agent_framework.monitoring.llm_auto_instrumentor import (
    LLMAutoInstrumentor,
    get_llm_auto_instrumentor,
    reset_llm_auto_instrumentor,
)
from agent_framework.monitoring.llm_metrics import LLMMetrics, SessionLLMStats
from agent_framework.monitoring.llm_metrics_collector import LLMMetricsCollector
from agent_framework.monitoring.llm_metrics_extractor import (
    LLMMetricsExtractor,
    TraceMetricsAccumulator,
)
from agent_framework.monitoring.metrics_aggregator import (
    MetricsAggregator,
    UnifiedMetricsDocument,
    ensure_unified_index_template,
)
from agent_framework.monitoring.metrics_config import (
    MetricsConfig,
    get_metrics_config,
    reset_metrics_config,
)
from agent_framework.monitoring.observability_manager import (
    ObservabilityManager,
    get_observability_manager,
    reset_observability_manager,
)
from agent_framework.monitoring.otel_instrumentor import (
    OTELInstrumentor,
    get_meter,
    get_otel_instrumentor,
    get_tracer,
)
from agent_framework.monitoring.otel_logging_handler import (
    OTelLoggingHandler,
    get_otel_logging_handler,
    setup_otel_logging,
)
from agent_framework.monitoring.otel_metrics_recorder import (
    OTelMetricsRecorder,
    get_otel_metrics_recorder,
    reset_otel_metrics_recorder,
)
from agent_framework.monitoring.otel_setup import (
    OTelConfig,
    OTelSetup,
    get_otel_setup,
    reset_otel_setup,
)
from agent_framework.monitoring.resource_metrics_collector import (
    ResourceMetrics,
    ResourceMetricsCollector,
)
from agent_framework.monitoring.streaming_latency_tracer import (
    SpanAttributes,
    SpanContext,
    SpanData,
    StreamingLatencyTracer,
    ensure_spans_index_template,  # Deprecated, kept for backward compatibility
    get_streaming_latency_tracer,
    initialize_streaming_latency_tracer,
    reset_streaming_latency_tracer,
)
from agent_framework.monitoring.timing_tracker import TimingData, TimingTracker
from agent_framework.monitoring.token_counter import TokenCount, TokenCounter
from agent_framework.monitoring.tracing_context import (
    APISpanContext,
    LLMCallMetrics,
    LLMSpanContext,
    TracingContextManager,
    get_tracing_context_manager,
    reset_tracing_context_manager,
)


__all__ = [
    # Module references (for submodule access)
    "performance_monitor",
    "progress_tracker",
    "resource_manager",
    "error_handling",
    "error_logging",
    "elasticsearch_logging",
    "elasticsearch_circuit_breaker",
    # ===========================================
    # OpenTelemetry Observability
    # ===========================================
    # ObservabilityManager Facade (primary entry point)
    "ObservabilityManager",
    "get_observability_manager",
    "reset_observability_manager",
    # OTel Setup (unified initialization)
    "OTelConfig",
    "OTelSetup",
    "get_otel_setup",
    "reset_otel_setup",
    # Tracing Context (API-first hierarchy)
    "TracingContextManager",
    "APISpanContext",
    "LLMSpanContext",
    "LLMCallMetrics",
    "get_tracing_context_manager",
    "reset_tracing_context_manager",
    # OTel Metrics Recorder
    "OTelMetricsRecorder",
    "get_otel_metrics_recorder",
    "reset_otel_metrics_recorder",
    # OTel Logging Handler
    "OTelLoggingHandler",
    "get_otel_logging_handler",
    "setup_otel_logging",
    # OpenTelemetry Instrumentor
    "OTELInstrumentor",
    "get_tracer",
    "get_meter",
    "get_otel_instrumentor",
    # LLM Auto-Instrumentation (OpenLLMetry)
    "LLMAutoInstrumentor",
    "get_llm_auto_instrumentor",
    "reset_llm_auto_instrumentor",
    # Streaming Latency Tracer
    "StreamingLatencyTracer",
    "SpanAttributes",
    "SpanContext",
    "SpanData",
    "get_streaming_latency_tracer",
    "initialize_streaming_latency_tracer",
    "reset_streaming_latency_tracer",
    "ensure_spans_index_template",  # Deprecated, kept for backward compatibility
    # ===========================================
    # Unified Metrics (Elasticsearch)
    # ===========================================
    "MetricsAggregator",
    "UnifiedMetricsDocument",
    "ensure_unified_index_template",
    # LLM Metrics Extraction
    "LLMMetricsExtractor",
    "TraceMetricsAccumulator",
    # ===========================================
    # Metrics Configuration
    # ===========================================
    "MetricsConfig",
    "get_metrics_config",
    "reset_metrics_config",
    # ===========================================
    # Data Models
    # ===========================================
    "LLMMetrics",
    "SessionLLMStats",
    "LLMMetricsCollector",
    "TokenCounter",
    "TokenCount",
    "TimingTracker",
    "TimingData",
    "APITimingTracker",
    "APITimingData",
    # Resource Metrics
    "ResourceMetrics",
    "ResourceMetricsCollector",
]
