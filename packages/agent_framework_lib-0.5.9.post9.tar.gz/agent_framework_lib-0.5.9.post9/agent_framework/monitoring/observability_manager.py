"""ObservabilityManager Facade.

Provides a unified interface for all observability concerns:
- Tracing (via TracingContextManager)
- Metrics (via OTelMetricsRecorder)
- Logging (via OTelLoggingHandler or ElasticsearchLoggingHandler fallback)
- Unified metrics via MetricsAggregator (for Kibana dashboards)

The ObservabilityManager simplifies observability integration by providing
a single entry point that handles OTel initialization, fallback to Elasticsearch
when OTel is unavailable, and consistent API for recording telemetry.

Example:
    ```python
    from agent_framework.monitoring.observability_manager import (
        ObservabilityManager,
        get_observability_manager,
    )

    # Get the singleton manager
    manager = get_observability_manager()

    # Use unified API request context
    async with manager.api_request(
        endpoint="/chat",
        method="POST",
        session_id="sess-123"
    ) as ctx:
        # Record LLM calls within the request
        manager.record_llm_call(llm_metrics)

        # Access tracing context
        print(f"Request ID: {ctx.request_id}")
        print(f"LLM calls: {ctx.llm_call_count}")
    ```
"""

from __future__ import annotations

import logging
import uuid
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from agent_framework.monitoring.api_timing_tracker import APITimingData
    from agent_framework.monitoring.llm_metrics import LLMMetrics
    from agent_framework.monitoring.otel_setup import OTelSetup
    from agent_framework.monitoring.tracing_context import APISpanContext

logger = logging.getLogger(__name__)


class ObservabilityManager:
    """Unified facade for observability: tracing, metrics, and logging.

    Combines TracingContextManager and OTelMetricsRecorder into a single
    interface, with automatic fallback to Elasticsearch when OTel is
    unavailable.

    For Kibana dashboards, use MetricsAggregator directly in your request
    handlers to write unified metrics to the agent-metrics-* index.

    Attributes:
        otel_setup: OTelSetup instance for OTel configuration
        tracing: TracingContextManager for distributed tracing
        metrics: OTelMetricsRecorder for metrics recording
        es_fallback_enabled: Whether ES fallback is active
    """

    def __init__(
        self,
        otel_setup: OTelSetup | None = None,
        enable_es_fallback: bool = True,
    ) -> None:
        """Initialize the ObservabilityManager.

        Args:
            otel_setup: Optional OTelSetup instance. If not provided,
                       uses the default from get_otel_setup().
            enable_es_fallback: Whether to enable Elasticsearch fallback
                               when OTel is unavailable (default: True)
        """
        from agent_framework.monitoring.otel_setup import get_otel_setup

        self._otel_setup = otel_setup or get_otel_setup()
        self._enable_es_fallback = enable_es_fallback

        self._tracing: Any = None
        self._metrics: Any = None
        self._es_logging_handler: Any = None
        self._es_fallback_active = False

        self._initialize_components()

    def _initialize_components(self) -> None:
        """Initialize tracing and metrics components."""
        from agent_framework.monitoring.otel_metrics_recorder import OTelMetricsRecorder
        from agent_framework.monitoring.tracing_context import TracingContextManager

        self._tracing = TracingContextManager(self._otel_setup)
        self._metrics = OTelMetricsRecorder(self._otel_setup)

        if not self._otel_setup.is_initialized and self._enable_es_fallback:
            self._activate_es_fallback()

    def _activate_es_fallback(self) -> None:
        """Activate Elasticsearch fallback when OTel is unavailable."""
        if self._es_fallback_active:
            return

        logger.warning(
            "OpenTelemetry is not initialized. "
            "Activating Elasticsearch fallback for logging. "
            "Metrics and tracing will be disabled."
        )

        try:
            from agent_framework.monitoring.elasticsearch_logging import (
                ElasticsearchLoggingHandler,
            )

            self._es_logging_handler = ElasticsearchLoggingHandler
            self._es_fallback_active = True
            logger.info("Elasticsearch fallback activated for logging")
        except ImportError:
            logger.warning(
                "ElasticsearchLoggingHandler not available. "
                "Logging fallback disabled."
            )
            self._es_fallback_active = False

    @property
    def is_otel_initialized(self) -> bool:
        """Check if OTel is initialized and available.

        Returns:
            True if OTel is initialized, False otherwise
        """
        return self._otel_setup.is_initialized

    @property
    def is_es_fallback_active(self) -> bool:
        """Check if Elasticsearch fallback is active.

        Returns:
            True if ES fallback is being used, False otherwise
        """
        return self._es_fallback_active

    @property
    def tracing(self) -> Any:
        """Get the TracingContextManager instance.

        Returns:
            TracingContextManager for creating spans
        """
        return self._tracing

    @property
    def metrics(self) -> Any:
        """Get the OTelMetricsRecorder instance.

        Returns:
            OTelMetricsRecorder for recording metrics
        """
        return self._metrics

    @asynccontextmanager
    async def api_request(
        self,
        endpoint: str,
        method: str,
        session_id: str | None = None,
        request_id: str | None = None,
    ) -> AsyncGenerator[APISpanContext, None]:
        """Track an API request with automatic LLM call aggregation.

        Creates a parent span for the API request and provides context
        for tracking LLM calls made during the request. Automatically
        records API timing metrics when the context exits.

        Args:
            endpoint: HTTP endpoint path (e.g., "/chat")
            method: HTTP method (e.g., "POST")
            session_id: Optional session identifier for correlation
            request_id: Optional request ID (auto-generated if not provided)

        Yields:
            APISpanContext for tracking LLM calls and accessing request info

        Example:
            ```python
            async with manager.api_request(
                endpoint="/chat",
                method="POST",
                session_id="sess-123"
            ) as ctx:
                # Make LLM calls
                response = await llm.chat(messages)
                manager.record_llm_call(metrics)

                # Access aggregated data
                print(f"Total LLM calls: {ctx.llm_call_count}")
            ```
        """
        if request_id is None:
            request_id = str(uuid.uuid4())

        with self._tracing.api_request_span(
            endpoint=endpoint,
            method=method,
            request_id=request_id,
            session_id=session_id,
        ) as ctx:
            try:
                yield ctx
            finally:
                self._record_api_timing_from_context(ctx)

    def _record_api_timing_from_context(self, ctx: APISpanContext) -> None:
        """Record API timing metrics from the span context.

        Args:
            ctx: APISpanContext with timing and LLM call data
        """
        from datetime import datetime, timezone

        from agent_framework.monitoring.api_timing_tracker import APITimingData

        timing = APITimingData(
            request_id=ctx.request_id,
            request_start=datetime.now(timezone.utc),
            total_api_duration_ms=ctx.api_duration_ms,
            llm_call_count=ctx.llm_call_count,
            total_llm_duration_ms=ctx.total_llm_duration_ms,
            endpoint=ctx.endpoint,
            method=ctx.method,
            session_id=ctx.session_id,
        )

        self.record_api_timing(timing)

    def record_llm_call(
        self,
        metrics: LLMMetrics,
        api_context: APISpanContext | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        """Record LLM call metrics via OTel.

        Records token counts and timing to OTel metrics instruments.
        If an API context is provided, also adds the metrics to the
        context for aggregation.

        Args:
            metrics: LLMMetrics from a completed LLM call
            api_context: Optional APISpanContext to add metrics to
            attributes: Optional additional attributes for metrics

        Example:
            ```python
            async with manager.api_request(...) as ctx:
                # After LLM call completes
                manager.record_llm_call(metrics, api_context=ctx)
            ```
        """
        # Record to OTel
        self._metrics.record_llm_metrics(metrics, attributes)

        if api_context is not None:
            from agent_framework.monitoring.tracing_context import LLMCallMetrics

            llm_call_metrics = LLMCallMetrics(
                model_name=metrics.model_name or "unknown",
                input_tokens=metrics.input_tokens,
                output_tokens=metrics.output_tokens,
                thinking_tokens=metrics.thinking_tokens,
                duration_ms=metrics.duration_ms or 0.0,
                time_to_first_token_ms=metrics.time_to_first_token_ms,
            )
            api_context.add_llm_call(llm_call_metrics)

    def record_api_timing(
        self,
        timing: APITimingData,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        """Record API request timing metrics via OTel.

        Records total duration, preprocessing, and postprocessing times
        to OTel metrics instruments.

        Args:
            timing: APITimingData from a completed API request
            attributes: Optional additional attributes for metrics

        Example:
            ```python
            timing_data = tracker.finish_request()
            manager.record_api_timing(timing_data)
            ```
        """
        self._metrics.record_api_timing(timing, attributes)

    def get_trace_context(self) -> tuple[str | None, str | None]:
        """Get current trace_id and span_id for correlation.

        Returns:
            Tuple of (trace_id, span_id) as hex strings, or (None, None)
            if no active span or OTel unavailable
        """
        result: tuple[str | None, str | None] = self._tracing.get_current_trace_context()
        return result

    async def setup_es_logging_handler(
        self,
        logger_instance: logging.Logger | None = None,
        log_level: str = "INFO",
    ) -> Any | None:
        """Set up Elasticsearch logging handler as fallback.

        Creates and attaches an ElasticsearchLoggingHandler to the
        specified logger when OTel is not available.

        Args:
            logger_instance: Logger to add handler to (default: agent_framework)
            log_level: Logging level as string (default: INFO)

        Returns:
            ElasticsearchLoggingHandler if successful, None otherwise
        """
        if self.is_otel_initialized:
            logger.debug("OTel is initialized, ES logging fallback not needed")
            return None

        if not self._es_fallback_active:
            logger.debug("ES fallback not active, cannot setup handler")
            return None

        try:
            from agent_framework.monitoring.elasticsearch_logging import (
                setup_elasticsearch_logging,
            )

            handler = await setup_elasticsearch_logging(
                logger_instance=logger_instance,
                log_level=log_level,
            )
            return handler
        except Exception as e:
            logger.warning(f"Failed to setup ES logging handler: {e}")
            return None

    def shutdown(self) -> None:
        """Shutdown the observability manager.

        Cleans up resources and flushes any pending telemetry.
        """
        if self._otel_setup.is_initialized:
            self._otel_setup.shutdown()

        logger.debug("ObservabilityManager shutdown complete")


_default_observability_manager: ObservabilityManager | None = None


def get_observability_manager(
    otel_setup: OTelSetup | None = None,
    enable_es_fallback: bool = True,
) -> ObservabilityManager:
    """Get or create the default ObservabilityManager instance.

    Returns a singleton instance of ObservabilityManager for convenience.
    The manager automatically initializes OTel if not already done.

    Args:
        otel_setup: Optional OTelSetup instance
        enable_es_fallback: Whether to enable ES fallback (default: True)

    Returns:
        ObservabilityManager instance

    Example:
        ```python
        manager = get_observability_manager()

        async with manager.api_request(endpoint="/chat", method="POST") as ctx:
            # Process request
            pass
        ```
    """
    global _default_observability_manager
    if _default_observability_manager is None:
        _default_observability_manager = ObservabilityManager(
            otel_setup=otel_setup,
            enable_es_fallback=enable_es_fallback,
        )
    return _default_observability_manager


def reset_observability_manager() -> None:
    """Reset the default ObservabilityManager instance.

    Useful for testing or reconfiguration. Shuts down the existing
    manager if initialized.
    """
    global _default_observability_manager
    if _default_observability_manager is not None:
        _default_observability_manager.shutdown()
        _default_observability_manager = None
