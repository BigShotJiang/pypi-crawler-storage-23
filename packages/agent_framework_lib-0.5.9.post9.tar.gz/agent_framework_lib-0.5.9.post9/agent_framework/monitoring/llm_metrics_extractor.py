"""LLM Metrics Extractor for OpenTelemetry Spans.

This module provides a SpanProcessor implementation that extracts LLM token
metrics from OpenLLMetry spans. It captures real token counts from provider
API responses and classifies them into input, thinking, and output tokens.

Key insight: In an agent loop with tool calls, we have multiple LLM calls:
- First call: User query → LLM decides to use tools
- Intermediate calls: Tool results → LLM reasons (THINKING TOKENS!)
- Final call: LLM produces final response

Token classification:
- input_tokens: First LLM call's input (query + system + tools + memory)
- thinking_tokens: All intermediate calls (input + output)
- output_tokens: Final LLM call's output (the actual response)
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from opentelemetry.context import Context
    from opentelemetry.sdk.trace import ReadableSpan, Span

from agent_framework.monitoring.llm_metrics import LLMMetrics


@dataclass
class TraceMetricsAccumulator:
    """Accumulates metrics across multiple LLM calls in an agent loop.

    This dataclass tracks all LLM calls within a single trace, allowing
    proper classification of tokens into input, thinking, and output categories.

    Attributes:
        llm_calls: List of dictionaries containing per-call token data
        first_call_start: Timestamp of the first LLM call
        last_call_end: Timestamp of the last LLM call completion
        model_name: Name of the LLM model used
    """

    llm_calls: list[dict[str, Any]] = field(default_factory=list)
    first_call_start: datetime | None = None
    last_call_end: datetime | None = None
    model_name: str | None = None


class LLMMetricsExtractor:
    """Extracts LLM metrics from OpenLLMetry spans.

    Implements the OpenTelemetry SpanProcessor interface to intercept completed
    spans and extract token usage from gen_ai.* attributes.

    This class is thread-safe and can handle concurrent span processing from
    multiple traces.

    Attributes:
        ATTR_INPUT_TOKENS: OpenLLMetry attribute for input token count
        ATTR_OUTPUT_TOKENS: OpenLLMetry attribute for output token count
        ATTR_MODEL: OpenLLMetry attribute for model name
        ATTR_SYSTEM: OpenLLMetry attribute for provider system (openai, anthropic, etc.)

    Example:
        ```python
        from opentelemetry.sdk.trace import TracerProvider

        extractor = LLMMetricsExtractor()
        provider = TracerProvider()
        provider.add_span_processor(extractor)

        # After LLM calls complete, get metrics
        metrics = extractor.get_metrics(trace_id)
        if metrics:
            print(f"Input: {metrics.input_tokens}, Output: {metrics.output_tokens}")
        ```
    """

    # OpenLLMetry semantic conventions
    ATTR_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    ATTR_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
    ATTR_MODEL = "gen_ai.request.model"
    ATTR_SYSTEM = "gen_ai.system"

    def __init__(self) -> None:
        """Initialize the LLMMetricsExtractor with thread-safe storage."""
        self._trace_accumulators: dict[str, TraceMetricsAccumulator] = {}
        self._lock = threading.Lock()

    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        """Called when a span starts. Not used for metrics extraction.

        Args:
            span: The span that is starting
            parent_context: The parent context, if any
        """
        pass

    def on_end(self, span: ReadableSpan) -> None:
        """Called when a span ends. Extract metrics if it's an LLM span.

        This method checks if the span contains gen_ai.usage attributes
        and if so, extracts the token counts and stores them for later
        retrieval via get_metrics().

        Args:
            span: The completed span to process
        """
        attrs = span.attributes or {}

        # Check if this is an LLM span (has gen_ai attributes)
        if self.ATTR_INPUT_TOKENS not in attrs:
            return

        # Get trace_id from span context
        trace_id = format(span.context.trace_id, "032x")

        # Extract call data from span
        start_time = self._timestamp_to_datetime(span.start_time)
        end_time = self._timestamp_to_datetime(span.end_time) if span.end_time else None

        call_data = {
            "input_tokens": attrs.get(self.ATTR_INPUT_TOKENS, 0),
            "output_tokens": attrs.get(self.ATTR_OUTPUT_TOKENS, 0),
            "start_time": start_time,
            "end_time": end_time,
        }

        with self._lock:
            if trace_id not in self._trace_accumulators:
                self._trace_accumulators[trace_id] = TraceMetricsAccumulator(
                    model_name=attrs.get(self.ATTR_MODEL)
                )

            acc = self._trace_accumulators[trace_id]
            acc.llm_calls.append(call_data)

            # Track timing - update first_call_start only if not set
            if acc.first_call_start is None or (start_time and start_time < acc.first_call_start):
                acc.first_call_start = start_time

            # Always update last_call_end to the latest end time
            if end_time and (acc.last_call_end is None or end_time > acc.last_call_end):
                acc.last_call_end = end_time

    def get_metrics(self, trace_id: str) -> LLMMetrics | None:
        """Get accumulated metrics for a trace, classifying thinking tokens.

        Token classification logic:
        - If 1 LLM call: input_tokens = call.input, output_tokens = call.output
        - If N LLM calls (agent loop):
          - input_tokens = first_call.input (initial query context)
          - thinking_tokens = sum of all intermediate calls (input + output)
          - output_tokens = last_call.output (final response)

        This method removes the trace from the accumulator after retrieval,
        so it can only be called once per trace.

        Args:
            trace_id: The trace ID to get metrics for (32-character hex string)

        Returns:
            LLMMetrics with classified token counts, or None if no data exists
        """
        with self._lock:
            acc = self._trace_accumulators.pop(trace_id, None)
            if not acc or not acc.llm_calls:
                return None

        calls = acc.llm_calls
        n_calls = len(calls)

        if n_calls == 1:
            # Simple case: single LLM call, no agent loop
            return LLMMetrics(
                input_tokens=calls[0]["input_tokens"],
                thinking_tokens=0,
                output_tokens=calls[0]["output_tokens"],
                model_name=acc.model_name,
                start_time=acc.first_call_start or datetime.now(timezone.utc),
                end_time=acc.last_call_end,
                duration_ms=self._calc_duration(acc.first_call_start, acc.last_call_end),
                trace_id=trace_id,
            )

        # Agent loop case: multiple LLM calls
        # First call input = real input tokens
        input_tokens = calls[0]["input_tokens"]

        # Last call output = real output tokens (final response)
        output_tokens = calls[-1]["output_tokens"]

        # Everything in between = thinking tokens
        # This includes:
        # - First call's output (tool call decisions)
        # - All intermediate calls (input = tool results, output = reasoning)
        # - Last call's input (accumulated context before final response)
        thinking_tokens = calls[0]["output_tokens"]  # First call's tool decisions

        for call in calls[1:-1]:  # All intermediate calls
            thinking_tokens += call["input_tokens"] + call["output_tokens"]

        if n_calls > 1:
            thinking_tokens += calls[-1]["input_tokens"]  # Last call's input context

        return LLMMetrics(
            input_tokens=input_tokens,
            thinking_tokens=thinking_tokens,
            output_tokens=output_tokens,
            model_name=acc.model_name,
            start_time=acc.first_call_start or datetime.now(timezone.utc),
            end_time=acc.last_call_end,
            duration_ms=self._calc_duration(acc.first_call_start, acc.last_call_end),
            trace_id=trace_id,
        )

    def peek_metrics(self, trace_id: str) -> LLMMetrics | None:
        """Get metrics without removing from accumulator.

        This is useful for checking metrics without consuming them.

        Args:
            trace_id: The trace ID to peek metrics for

        Returns:
            LLMMetrics with classified token counts, or None if no data exists
        """
        with self._lock:
            acc = self._trace_accumulators.get(trace_id)
            if not acc or not acc.llm_calls:
                return None

            # Create a copy of the accumulator data for processing
            calls = list(acc.llm_calls)
            model_name = acc.model_name
            first_call_start = acc.first_call_start
            last_call_end = acc.last_call_end

        # Process outside the lock
        n_calls = len(calls)

        if n_calls == 1:
            return LLMMetrics(
                input_tokens=calls[0]["input_tokens"],
                thinking_tokens=0,
                output_tokens=calls[0]["output_tokens"],
                model_name=model_name,
                start_time=first_call_start or datetime.now(timezone.utc),
                end_time=last_call_end,
                duration_ms=self._calc_duration(first_call_start, last_call_end),
                trace_id=trace_id,
            )

        input_tokens = calls[0]["input_tokens"]
        output_tokens = calls[-1]["output_tokens"]
        thinking_tokens = calls[0]["output_tokens"]

        for call in calls[1:-1]:
            thinking_tokens += call["input_tokens"] + call["output_tokens"]

        if n_calls > 1:
            thinking_tokens += calls[-1]["input_tokens"]

        return LLMMetrics(
            input_tokens=input_tokens,
            thinking_tokens=thinking_tokens,
            output_tokens=output_tokens,
            model_name=model_name,
            start_time=first_call_start or datetime.now(timezone.utc),
            end_time=last_call_end,
            duration_ms=self._calc_duration(first_call_start, last_call_end),
            trace_id=trace_id,
        )

    def has_metrics(self, trace_id: str) -> bool:
        """Check if metrics exist for a trace without consuming them.

        Args:
            trace_id: The trace ID to check

        Returns:
            True if metrics exist for the trace, False otherwise
        """
        with self._lock:
            acc = self._trace_accumulators.get(trace_id)
            return acc is not None and len(acc.llm_calls) > 0

    def clear_metrics(self, trace_id: str) -> None:
        """Clear metrics for a specific trace.

        Args:
            trace_id: The trace ID to clear metrics for
        """
        with self._lock:
            self._trace_accumulators.pop(trace_id, None)

    def shutdown(self) -> None:
        """Shutdown the processor and clear all accumulated data."""
        with self._lock:
            self._trace_accumulators.clear()

    def force_flush(self, timeout_millis: int = 30000) -> bool:  # noqa: ARG002
        """Force flush any pending data.

        This implementation has no pending data to flush.

        Args:
            timeout_millis: Timeout in milliseconds (unused, required by SpanProcessor interface)

        Returns:
            Always returns True
        """
        return True

    def _timestamp_to_datetime(self, timestamp_ns: int | None) -> datetime | None:
        """Convert nanosecond timestamp to datetime.

        Args:
            timestamp_ns: Timestamp in nanoseconds since epoch

        Returns:
            datetime object in UTC, or None if timestamp is None
        """
        if timestamp_ns is None:
            return None
        return datetime.fromtimestamp(timestamp_ns / 1e9, tz=timezone.utc)

    def _calc_duration(self, start: datetime | None, end: datetime | None) -> float | None:
        """Calculate duration in milliseconds between two datetimes.

        Args:
            start: Start datetime
            end: End datetime

        Returns:
            Duration in milliseconds, or None if either datetime is None
        """
        if start and end:
            return (end - start).total_seconds() * 1000
        return None
