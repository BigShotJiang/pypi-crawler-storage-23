"""Budget-aware function agent for tool loop budget enforcement.

Subclasses LlamaIndex's FunctionAgent to intercept take_step() and
verify context budget before each LLM call, compressing the scratchpad
when usage approaches the context window limit.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, List, Optional, Sequence

from llama_index.core.agent.workflow import FunctionAgent
from llama_index.core.agent.workflow.workflow_events import AgentOutput
from llama_index.core.bridge.pydantic import Field, PrivateAttr
from llama_index.core.llms import ChatMessage
from llama_index.core.memory import BaseMemory
from llama_index.core.tools import AsyncBaseTool
from llama_index.core.workflow import Context

if TYPE_CHECKING:
    from agent_framework.core.context_budget import ContextBudgetManager
    from agent_framework.core.scratchpad_compressor import ScratchpadCompressor
    from agent_framework.monitoring.token_counter import TokenCounter

logger = logging.getLogger(__name__)


class BudgetAwareFunctionAgent(FunctionAgent):
    """FunctionAgent avec vérification du budget avant chaque appel LLM."""

    _budget_manager: Any = PrivateAttr(default=None)
    _token_counter: Any = PrivateAttr(default=None)
    _scratchpad_compressor: Any = PrivateAttr(default=None)

    def __init__(
        self,
        *args: Any,
        budget_manager: ContextBudgetManager | None = None,
        token_counter: TokenCounter | None = None,
        scratchpad_compressor: ScratchpadCompressor | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._budget_manager = budget_manager
        self._token_counter = token_counter
        self._scratchpad_compressor = scratchpad_compressor

    async def take_step(
        self,
        ctx: Context,
        llm_input: List[ChatMessage],
        tools: Sequence[AsyncBaseTool],
        memory: BaseMemory,
    ) -> AgentOutput:
        """Vérifie le budget et compresse le scratchpad avant l'appel LLM."""
        if self._budget_manager and self._token_counter and self._scratchpad_compressor:
            scratchpad: List[ChatMessage] = await ctx.store.get(
                self.scratchpad_key, default=[]
            )
            total_tokens = self._count_total_tokens(llm_input, scratchpad)
            context_window = self._budget_manager.context_window

            llm_input_tokens = self._count_total_tokens(llm_input, [])
            scratchpad_tokens = self._count_total_tokens([], scratchpad)

            if context_window > 0:
                usage_percent = total_tokens / context_window * 100
            else:
                usage_percent = 0.0

            logger.info(
                "Tool loop budget: %d/%d tokens (%.1f%%), "
                "llm_input=%d, scratchpad=%d (%d entries)",
                total_tokens,
                context_window,
                usage_percent,
                llm_input_tokens,
                scratchpad_tokens,
                len(scratchpad),
            )

            if usage_percent >= 80:
                logger.warning(
                    "Tool loop context usage at %.1f%%", usage_percent
                )

            if usage_percent >= 95:
                compressed_scratchpad = await self._scratchpad_compressor.compress(
                    scratchpad=scratchpad,
                    llm_input=llm_input,
                    context_window=context_window,
                    sacred_zone_tokens=self._budget_manager._sacred_zone_tokens,
                )
                await ctx.store.set(self.scratchpad_key, compressed_scratchpad)

        return await super().take_step(ctx, llm_input, tools, memory)

    def _count_total_tokens(
        self,
        llm_input: List[ChatMessage],
        scratchpad: List[ChatMessage],
    ) -> int:
        """Compte le total de tokens de llm_input + scratchpad.

        Args:
            llm_input: Messages d'historique envoyés au LLM.
            scratchpad: Messages du scratchpad de la boucle d'outils.

        Returns:
            Nombre total de tokens.
        """
        total = 0
        for msg in [*llm_input, *scratchpad]:
            total += self._token_counter.count_tokens(msg.content or "").count
        return total
