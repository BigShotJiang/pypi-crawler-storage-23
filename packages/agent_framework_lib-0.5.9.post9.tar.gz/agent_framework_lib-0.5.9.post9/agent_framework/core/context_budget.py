"""Context window budget management.

Provides model context window resolution and budget tracking
for managing LLM context window usage across agent sessions.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from llama_index.core.llms import ChatMessage

    from agent_framework.core.context_summarizer import ContextSummarizer
    from agent_framework.monitoring.token_counter import TokenCounter

logger = logging.getLogger(__name__)


class ModelContextRegistry:
    """Registre des tailles de fenêtre de contexte par modèle.

    Résout la taille de la fenêtre de contexte (input tokens) pour un modèle donné
    via un lookup exact, puis un fallback par préfixe de provider, puis une valeur
    par défaut de 128 000 tokens.
    """

    CONTEXT_WINDOWS: dict[str, int] = {
        # Light tier
        "gpt-5-nano": 272_000,
        "gpt-5-nano-2025-08-07": 272_000,
        "gemini-2.5-flash-lite": 1_048_576,
        # Standard tier
        "gpt-5-mini": 272_000,
        "gpt-5-mini-2025-08-07": 272_000,
        "claude-haiku-4-5-20251001": 200_000,
        "gemini-2.5-flash": 1_048_576,
        # Advanced tier
        "gpt-5.2": 272_000,
        "gpt-5.2-2025-12-11": 272_000,
        "claude-opus-4-6": 1_000_000,
        "claude-sonnet-4-5-20250929": 200_000,
        "claude-opus-4-5-20251101": 200_000,
        "gemini-2.5-pro": 1_048_576,
        "gemini-3-pro-preview": 1_048_576,
    }

    PROVIDER_DEFAULTS: dict[str, int] = {
        "gpt-5": 272_000,
        "gpt-4": 128_000,
        "claude": 200_000,
        "gemini": 1_048_576,
        "o1": 128_000,
        "o3": 200_000,
        "o4": 200_000,
    }

    DEFAULT_CONTEXT_WINDOW: int = 128_000

    @classmethod
    def get_context_window(cls, model_name: str) -> int:
        """Résout la taille de la fenêtre de contexte pour un modèle.

        Stratégie de résolution :
        1. Lookup exact dans CONTEXT_WINDOWS
        2. Fallback par préfixe (le plus long d'abord) dans PROVIDER_DEFAULTS
        3. Valeur par défaut de 128 000 tokens

        Args:
            model_name: Nom du modèle LLM.

        Returns:
            Taille de la fenêtre de contexte en tokens.
        """
        if model_name in cls.CONTEXT_WINDOWS:
            return cls.CONTEXT_WINDOWS[model_name]

        # Préfixe le plus long d'abord pour éviter les faux positifs
        for prefix in sorted(cls.PROVIDER_DEFAULTS, key=len, reverse=True):
            if model_name.startswith(prefix):
                return cls.PROVIDER_DEFAULTS[prefix]

        logger.warning(
            "Modèle inconnu '%s', utilisation de la fenêtre par défaut de %d tokens",
            model_name,
            cls.DEFAULT_CONTEXT_WINDOW,
        )
        return cls.DEFAULT_CONTEXT_WINDOW


@dataclass(frozen=True)
class BudgetSnapshot:
    """Snapshot de l'état du budget de la fenêtre de contexte à un instant donné."""

    context_window: int
    sacred_zone_tokens: int
    conversation_zone_tokens: int
    recent_zone_tokens: int
    total_tokens: int
    usage_percent: float
    compression_triggered: bool
    model_name: str


class ContextBudgetManager:
    """Gère le budget de la fenêtre de contexte pour un agent LLM.

    Découpe la fenêtre de contexte en zones (sacrée, conversation, récente),
    surveille l'utilisation, et fournit des snapshots de l'état du budget.
    """

    TRIGGER_THRESHOLD: float = 0.95
    TARGET_CONVERSATION_RATIO: float = 0.30
    RECENT_ZONE_RATIO: float = 0.05

    def __init__(
        self,
        model_name: str,
        token_counter: TokenCounter,
        summarizer: ContextSummarizer | None = None,
    ) -> None:
        self._model_name = model_name
        self._token_counter = token_counter
        self._summarizer = summarizer
        self._context_window = ModelContextRegistry.get_context_window(model_name)
        self._sacred_zone_tokens = 0

    @property
    def context_window(self) -> int:
        """Taille de la fenêtre de contexte résolue pour le modèle courant."""
        return self._context_window

    def set_sacred_zone(self, system_prompt: str, tool_definitions: str) -> int:
        """Compte et enregistre les tokens de la Zone Sacrée.

        Args:
            system_prompt: Prompt système complet (agent + skills + mémoire passive).
            tool_definitions: Définitions d'outils sérialisées.

        Returns:
            Nombre total de tokens de la Zone Sacrée.
        """
        prompt_tokens = self._token_counter.count_tokens(system_prompt).count
        tool_tokens = self._token_counter.count_tokens(tool_definitions).count
        self._sacred_zone_tokens = prompt_tokens + tool_tokens
        if self._sacred_zone_tokens > 0.65 * self._context_window:
            logger.warning(
                "Sacred zone uses >65%% of context window: %d tokens",
                self._sacred_zone_tokens,
            )
        return self._sacred_zone_tokens

    def _identify_recent_zone(self, messages: list[ChatMessage]) -> int:
        """Retourne l'index du premier message de la Zone Récente.

        Parcourt les messages depuis la fin en accumulant les tokens
        jusqu'à dépasser le budget de la zone récente (5% de context_window).
        Si un seul dernier message dépasse le budget, il est conservé.

        Args:
            messages: Liste de messages de conversation.

        Returns:
            Index du premier message de la zone récente.
        """
        if not messages:
            return 0

        budget = int(self._context_window * self.RECENT_ZONE_RATIO)
        total = 0
        idx = len(messages)

        for i in range(len(messages) - 1, -1, -1):
            msg_tokens = self._token_counter.count_tokens(messages[i].content or "").count
            if total + msg_tokens > budget and idx < len(messages):
                break
            total += msg_tokens
            idx = i

        return idx

    def compute_snapshot(self, messages: list[ChatMessage]) -> BudgetSnapshot:
        """Calcule le snapshot complet du budget.

        Args:
            messages: Liste de messages de conversation.

        Returns:
            Snapshot de l'état du budget.
        """
        conversation_tokens = sum(
            self._token_counter.count_tokens(m.content or "").count for m in messages
        )
        recent_idx = self._identify_recent_zone(messages)
        recent_tokens = sum(
            self._token_counter.count_tokens(m.content or "").count
            for m in messages[recent_idx:]
        )
        total = self._sacred_zone_tokens + conversation_tokens
        usage = (total / self._context_window * 100) if self._context_window > 0 else 0.0

        if usage > 80:
            logger.warning("Context usage at %.1f%%", usage)

        return BudgetSnapshot(
            context_window=self._context_window,
            sacred_zone_tokens=self._sacred_zone_tokens,
            conversation_zone_tokens=conversation_tokens,
            recent_zone_tokens=recent_tokens,
            total_tokens=total,
            usage_percent=usage,
            compression_triggered=False,
            model_name=self._model_name,
        )

    async def enforce_budget(
        self, messages: list[ChatMessage],
    ) -> tuple[list[ChatMessage], BudgetSnapshot]:
        """Vérifie le budget et compresse si nécessaire.

        Args:
            messages: Liste de messages de conversation.

        Returns:
            Tuple (messages potentiellement compressés, snapshot du budget).
        """
        snapshot = self.compute_snapshot(messages)

        if snapshot.usage_percent < self.TRIGGER_THRESHOLD * 100:
            return messages, snapshot

        recent_idx = self._identify_recent_zone(messages)
        recent_messages = messages[recent_idx:]
        old_messages = messages[:recent_idx]

        target_conversation_tokens = int(
            self._context_window * self.TARGET_CONVERSATION_RATIO
        )
        recent_tokens = sum(
            self._token_counter.count_tokens(m.content or "").count
            for m in recent_messages
        )
        target_old_tokens = max(0, target_conversation_tokens - recent_tokens)

        compressed_messages: list[ChatMessage] = []
        try:
            if self._summarizer is not None and old_messages:
                summary_msg = await self._summarizer.summarize(
                    old_messages, target_old_tokens, self._model_name
                )
                compressed_messages = [summary_msg] + recent_messages
            else:
                raise RuntimeError("No summarizer available")
        except Exception:
            logger.warning("Summarizer failed, falling back to truncation")
            from agent_framework.core.context_summarizer import ContextSummarizer

            truncated = ContextSummarizer.truncate(
                old_messages, target_old_tokens, self._token_counter
            )
            compressed_messages = truncated + recent_messages

        final_snapshot = self._compute_snapshot_compressed(compressed_messages)
        return compressed_messages, final_snapshot

    def update_model(self, new_model_name: str) -> None:
        """Met à jour le modèle et recalcule la fenêtre de contexte.

        Args:
            new_model_name: Nom du nouveau modèle LLM.
        """
        self._model_name = new_model_name
        self._context_window = ModelContextRegistry.get_context_window(new_model_name)

    def _compute_snapshot_compressed(
        self, messages: list[ChatMessage],
    ) -> BudgetSnapshot:
        """Calcule un snapshot avec le flag compression_triggered activé.

        Args:
            messages: Liste de messages après compression.

        Returns:
            Snapshot avec compression_triggered=True.
        """
        conversation_tokens = sum(
            self._token_counter.count_tokens(m.content or "").count for m in messages
        )
        recent_idx = self._identify_recent_zone(messages)
        recent_tokens = sum(
            self._token_counter.count_tokens(m.content or "").count
            for m in messages[recent_idx:]
        )
        total = self._sacred_zone_tokens + conversation_tokens
        usage = (total / self._context_window * 100) if self._context_window > 0 else 0.0

        if usage > 80:
            logger.warning("Context usage at %.1f%%", usage)

        return BudgetSnapshot(
            context_window=self._context_window,
            sacred_zone_tokens=self._sacred_zone_tokens,
            conversation_zone_tokens=conversation_tokens,
            recent_zone_tokens=recent_tokens,
            total_tokens=total,
            usage_percent=usage,
            compression_triggered=True,
            model_name=self._model_name,
        )

