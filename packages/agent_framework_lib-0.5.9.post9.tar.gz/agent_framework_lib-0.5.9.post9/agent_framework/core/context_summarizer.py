"""Context summarizer for compressing conversation history.

Provides LLM-based summarization and simple truncation as fallback
for managing conversation context within budget constraints.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

from llama_index.core.llms import ChatMessage, MessageRole

if TYPE_CHECKING:
    from agent_framework.monitoring.token_counter import TokenCounter


class ContextSummarizer:
    """Compresse les messages de conversation via résumé LLM ou troncature."""

    def __init__(self, llm_factory: Callable[[str], Any]) -> None:
        self._llm_factory = llm_factory

    async def summarize(
        self,
        messages_to_compress: list[ChatMessage],
        target_token_count: int,
        model_name: str,
    ) -> ChatMessage:
        """Résume les messages en un seul message via appel LLM.

        Args:
            messages_to_compress: Messages à résumer.
            target_token_count: Nombre cible de tokens pour le résumé.
            model_name: Modèle LLM à utiliser pour le résumé.

        Returns:
            Un ChatMessage de rôle SYSTEM contenant le résumé.
        """
        llm = self._llm_factory(model_name)
        conversation_text = "\n".join(
            f"[{m.role.value}]: {m.content or ''}" for m in messages_to_compress
        )
        summary_prompt = ChatMessage(
            role=MessageRole.USER,
            content=(
                "Résume de manière concise la conversation suivante en conservant "
                "les informations clés, les décisions prises, et les résultats "
                f"d'outils importants. Le résumé doit faire moins de {target_token_count} "
                f"tokens.\n\nConversation :\n{conversation_text}"
            ),
        )
        response = await llm.achat([summary_prompt])
        return ChatMessage(
            role=MessageRole.SYSTEM,
            content=f"[Résumé de la conversation précédente]\n{response.message.content}",
        )

    @staticmethod
    def truncate(
        messages: list[ChatMessage],
        target_token_count: int,
        token_counter: TokenCounter,
    ) -> list[ChatMessage]:
        """Troncature simple : supprime les messages les plus anciens.

        Args:
            messages: Messages à tronquer.
            target_token_count: Budget cible en tokens.
            token_counter: Compteur de tokens.

        Returns:
            Liste de messages dont le total est <= target_token_count.
        """
        total = sum(token_counter.count_tokens(m.content or "").count for m in messages)
        result = list(messages)
        while result and total > target_token_count:
            removed = result.pop(0)
            total -= token_counter.count_tokens(removed.content or "").count
        return result
