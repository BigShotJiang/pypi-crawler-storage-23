"""Scratchpad compression for tool loop budget enforcement.

Compresses old tool call/result entries in the scratchpad when the
context budget is exceeded, preserving the most recent tool pair
and summarizing or truncating older entries.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from llama_index.core.llms import ChatMessage, MessageRole

if TYPE_CHECKING:
    from agent_framework.core.context_summarizer import ContextSummarizer
    from agent_framework.monitoring.token_counter import TokenCounter

logger = logging.getLogger(__name__)

TRUNCATION_MARKER = "\n\n[... contenu tronqué ...]\n\n"


class ScratchpadCompressor:
    """Compresse le scratchpad de la boucle d'outils pour respecter le budget."""

    def __init__(
        self,
        token_counter: TokenCounter,
        summarizer: ContextSummarizer | None = None,
    ) -> None:
        self._token_counter = token_counter
        self._summarizer = summarizer

    def _count_tokens(self, messages: list[ChatMessage]) -> int:
        """Compte le total de tokens d'une liste de messages.

        Args:
            messages: Liste de ChatMessage.

        Returns:
            Nombre total de tokens.
        """
        total = 0
        for msg in messages:
            total += self._token_counter.count_tokens(msg.content or "").count
        return total

    def _identify_last_tool_pair(
        self, scratchpad: list[ChatMessage]
    ) -> tuple[list[ChatMessage], list[ChatMessage]]:
        """Sépare le scratchpad en (anciennes entrées, dernière paire tool_call/tool_result).

        Parcourt le scratchpad depuis la fin pour trouver la dernière paire
        composée d'un message ASSISTANT (tool_call) suivi d'un message TOOL (tool_result).

        Args:
            scratchpad: Liste de messages du scratchpad.

        Returns:
            Tuple (anciennes entrées, dernière paire). Si le scratchpad est vide
            ou ne contient pas de paire complète, retourne ([], scratchpad).
        """
        if len(scratchpad) < 2:
            return [], list(scratchpad)

        # Chercher la dernière paire tool_call/tool_result depuis la fin
        # Les paires sont : ASSISTANT (avec tool_calls) + TOOL (résultat)
        for i in range(len(scratchpad) - 1, 0, -1):
            current = scratchpad[i]
            previous = scratchpad[i - 1]
            if (
                current.role == MessageRole.TOOL
                and previous.role == MessageRole.ASSISTANT
            ):
                old_entries = scratchpad[: i - 1]
                last_pair = scratchpad[i - 1 :]
                return old_entries, last_pair

        # Pas de paire trouvée, tout est considéré comme dernière paire
        return [], list(scratchpad)

    def _truncate_single_result(
        self, message: ChatMessage, target_tokens: int
    ) -> ChatMessage:
        """Tronque le contenu d'un tool_result en gardant début + marqueur + fin.

        Args:
            message: Message tool_result à tronquer.
            target_tokens: Nombre cible de tokens pour le message tronqué.

        Returns:
            Nouveau ChatMessage avec le contenu tronqué.
        """
        content = message.content or ""
        current_tokens = self._token_counter.count_tokens(content).count

        if current_tokens <= target_tokens or target_tokens <= 0:
            return message

        # Réserver des tokens pour le marqueur de troncature
        marker_tokens = self._token_counter.count_tokens(TRUNCATION_MARKER).count
        available_tokens = max(0, target_tokens - marker_tokens)

        # Répartir entre début et fin (60% début, 40% fin)
        begin_tokens = int(available_tokens * 0.6)
        end_tokens = available_tokens - begin_tokens

        # Approximation : ratio tokens/caractères pour découper le texte
        if current_tokens > 0:
            chars_per_token = len(content) / current_tokens
        else:
            chars_per_token = 4.0

        begin_chars = max(0, int(begin_tokens * chars_per_token))
        end_chars = max(0, int(end_tokens * chars_per_token))

        if begin_chars + end_chars >= len(content):
            return message

        begin_part = content[:begin_chars]
        end_part = content[-end_chars:] if end_chars > 0 else ""
        truncated_content = begin_part + TRUNCATION_MARKER + end_part

        return ChatMessage(
            role=message.role,
            content=truncated_content,
            additional_kwargs=message.additional_kwargs,
        )

    async def compress(
        self,
        scratchpad: list[ChatMessage],
        llm_input: list[ChatMessage],
        context_window: int,
        sacred_zone_tokens: int,
    ) -> list[ChatMessage]:
        """Compresse le scratchpad pour respecter le budget.

        Stratégie :
        1. Préserver la dernière paire tool_call/tool_result
        2. Résumer les entrées anciennes via LLM (ou tronquer en fallback)
        3. Si une seule paire existe, tronquer le contenu du tool_result

        Args:
            scratchpad: Entrées actuelles du scratchpad.
            llm_input: Messages d'historique (pour calculer le budget restant).
            context_window: Taille de la fenêtre de contexte.
            sacred_zone_tokens: Tokens de la zone sacrée.

        Returns:
            Scratchpad compressé.
        """
        if not scratchpad:
            return scratchpad

        budget_limit = int(context_window * 0.95)
        llm_input_tokens = self._count_tokens(llm_input)

        # Tokens disponibles pour le scratchpad
        available_for_scratchpad = max(0, budget_limit - sacred_zone_tokens - llm_input_tokens)

        old_entries, last_pair = self._identify_last_tool_pair(scratchpad)

        entries_before = len(scratchpad)
        tokens_before = self._count_tokens(scratchpad)

        # Cas 1 : pas d'anciennes entrées (une seule paire ou moins)
        if not old_entries:
            last_pair_tokens = self._count_tokens(last_pair)
            if last_pair_tokens > available_for_scratchpad:
                # Tronquer le tool_result de la dernière paire
                compressed_pair = self._truncate_last_pair(
                    last_pair, available_for_scratchpad
                )
                tokens_after = self._count_tokens(compressed_pair)
                self._log_compression(
                    entries_before, len(compressed_pair),
                    tokens_before, tokens_after,
                    "single_result_truncation",
                )
                return compressed_pair
            return last_pair

        # Cas 2 : il y a des anciennes entrées à compresser
        last_pair_tokens = self._count_tokens(last_pair)
        target_old_tokens = max(0, available_for_scratchpad - last_pair_tokens)

        # Tenter le résumé LLM
        compressed_old = await self._try_summarize_old_entries(
            old_entries, target_old_tokens
        )

        if compressed_old is not None:
            result = compressed_old + last_pair
            tokens_after = self._count_tokens(result)
            self._log_compression(
                entries_before, len(result),
                tokens_before, tokens_after,
                "llm_summary",
            )
            return result

        # Fallback : troncature simple (supprimer les plus anciennes)
        truncated_old = self._truncate_old_entries(old_entries, target_old_tokens)
        result = truncated_old + last_pair
        tokens_after = self._count_tokens(result)
        self._log_compression(
            entries_before, len(result),
            tokens_before, tokens_after,
            "truncation",
        )
        return result

    async def _try_summarize_old_entries(
        self,
        old_entries: list[ChatMessage],
        target_tokens: int,
    ) -> list[ChatMessage] | None:
        """Tente de résumer les anciennes entrées via LLM.

        Args:
            old_entries: Messages anciens à résumer.
            target_tokens: Budget cible en tokens pour le résumé.

        Returns:
            Liste contenant un unique message de résumé, ou None si échec.
        """
        if self._summarizer is None:
            return None

        try:
            # Construire le texte des anciennes entrées pour le résumé
            tool_names = []
            for msg in old_entries:
                kwargs = msg.additional_kwargs or {}
                tool_calls = kwargs.get("tool_calls", [])
                for tc in tool_calls:
                    if isinstance(tc, dict):
                        name = tc.get("name") or ""
                        if not name:
                            func = tc.get("function", {})
                            name = func.get("name", "") if isinstance(func, dict) else ""
                        if name:
                            tool_names.append(name)

            summary_msg = await self._summarizer.summarize(
                old_entries, target_tokens, "gpt-5-mini"
            )

            # Enrichir le résumé avec les noms d'outils
            tool_info = ""
            if tool_names:
                tool_info = f"Outils appelés : {', '.join(tool_names)}\n"

            summary_content = (
                f"[Résumé du scratchpad précédent]\n"
                f"{tool_info}"
                f"{summary_msg.content or ''}"
            )

            return [
                ChatMessage(
                    role=MessageRole.SYSTEM,
                    content=summary_content,
                )
            ]
        except Exception:
            logger.warning("Résumé LLM du scratchpad échoué, fallback troncature")
            return None

    def _truncate_old_entries(
        self,
        old_entries: list[ChatMessage],
        target_tokens: int,
    ) -> list[ChatMessage]:
        """Supprime les entrées les plus anciennes jusqu'à respecter le budget.

        Args:
            old_entries: Messages anciens.
            target_tokens: Budget cible en tokens.

        Returns:
            Liste de messages dont le total est <= target_tokens.
        """
        total = self._count_tokens(old_entries)
        result = list(old_entries)
        while result and total > target_tokens:
            removed = result.pop(0)
            total -= self._token_counter.count_tokens(removed.content or "").count
        return result

    def _truncate_last_pair(
        self,
        last_pair: list[ChatMessage],
        available_tokens: int,
    ) -> list[ChatMessage]:
        """Tronque le tool_result dans la dernière paire pour respecter le budget.

        Args:
            last_pair: Dernière paire de messages (tool_call + tool_result).
            available_tokens: Tokens disponibles pour toute la paire.

        Returns:
            Paire avec le tool_result tronqué si nécessaire.
        """
        result = []
        tokens_used = 0

        for msg in last_pair:
            if msg.role == MessageRole.TOOL:
                remaining = max(0, available_tokens - tokens_used)
                result.append(self._truncate_single_result(msg, remaining))
            else:
                tokens_used += self._token_counter.count_tokens(msg.content or "").count
                result.append(msg)

        return result

    def _log_compression(
        self,
        entries_before: int,
        entries_after: int,
        tokens_before: int,
        tokens_after: int,
        method: str,
    ) -> None:
        """Émet les logs de compression.

        Args:
            entries_before: Nombre d'entrées avant compression.
            entries_after: Nombre d'entrées après compression.
            tokens_before: Tokens avant compression.
            tokens_after: Tokens après compression.
            method: Méthode utilisée (llm_summary, truncation, single_result_truncation).
        """
        logger.info(
            "Scratchpad compressé : %d→%d entrées, %d→%d tokens, méthode=%s",
            entries_before,
            entries_after,
            tokens_before,
            tokens_after,
            method,
        )
        if entries_before > 10:
            logger.warning(
                "Boucle d'outils potentiellement excessive : %d entrées dans le scratchpad",
                entries_before,
            )
