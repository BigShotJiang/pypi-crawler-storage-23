"""Nexus CLI module for command-line workflow interaction."""

from .main import main

__all__ = ["main"]
