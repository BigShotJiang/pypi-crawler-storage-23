# CellCog Python SDK — File Safety Improvements

**Version:** 1.0  
**Date:** 2026-02-26  
**Status:** Design Review

---

## Executive Summary

Two file handling vulnerabilities in the CellCog Python SDK need to be addressed:

1. **Silent pass-through of missing files**: When a user references a local file via SHOW_FILE that doesn't exist in the SDK's execution environment, the SDK silently passes the raw path to CellCog, creating a broken chat that wastes credits.

2. **Unsafe download destinations**: When CellCog returns files with `external_local_path` attributes (from the GENERATE_FILE flow), the SDK downloads files to arbitrary user-specified paths, which is dangerous.

---

## Issue 1: Silent Pass-Through of Missing SHOW_FILE Files

### Problem

**File:** `cellcog/files.py` → `transform_outgoing()` (lines 36-90)

When the SDK processes outgoing messages, it finds SHOW_FILE tags and attempts to upload the referenced files. The current logic:

```python
if os.path.exists(file_path):
    # Upload file → transform to blob name
    ...
# If file doesn't exist → SILENTLY return original tag unchanged
return match.group(0)
```

**What goes wrong:**

1. User's OpenClaw agent sends: `<SHOW_FILE>/mnt/c/Users/.../video3.mp4</SHOW_FILE>`
2. SDK runs `os.path.exists()` → `False` (file exists on user's host but not accessible from SDK context, e.g., Docker container without proper mount, different WSL distro, etc.)
3. SDK silently passes raw local path through to CellCog backend
4. Backend's `process_human_files()` only processes `human_files/` prefixed blobs → skips it
5. Anthropic processor tries to read the path from CellCog's container → `FileNotFoundError` → silently skipped
6. Agent sees empty SHOW_FILE tag → asks user to re-upload
7. Credits wasted, user confused, zero actionable error

**Real-world evidence (chat `699fa731`):**

```
# DB stored this — raw path, no upload happened
<SHOW_FILE>699fa73106231913f5a31fb3//mnt/c/Users/Administrator/Desktop/first/input/raw/video3.mp4</SHOW_FILE>
```

- `blob_name_to_url`: `{}` (empty — no files in GCS)
- File DB: 0 files for this chat
- User paid $50 for credits

**vs. working chat (`699856a8`) from same user:**

```
# DB stored this — proper blob name with external_local_path preserved
<SHOW_FILE external_local_path="/mnt/c/.../diyige.mp4">699856a8a69767c86f7a0447/human_files/diyige.mp4</SHOW_FILE>
```

- `blob_name_to_url`: 4 files with signed URLs
- File DB: 4 files uploaded correctly

### Solution

In `transform_outgoing()`, when a SHOW_FILE path:
- Is NOT a URL (not `http://` or `https://`)
- Does NOT exist locally (`os.path.exists()` returns `False`)

→ **Raise `FileUploadError`** with a clear message instead of silently passing through.

**Updated logic in `cellcog/files.py`:**

```python
def transform_outgoing(self, message: str) -> tuple[str, list]:
    uploaded = []
    missing_files = []  # NEW: Track missing files

    def replace_show_file(match):
        attrs = match.group(1)
        file_path = match.group(2).strip()

        # Skip empty paths and URLs
        if not file_path or file_path.startswith(("http://", "https://")):
            return match.group(0)

        try:
            if os.path.exists(file_path):
                try:
                    blob_name = self._upload_file(file_path)
                    uploaded.append({"local": file_path, "blob": blob_name})
                    return f'<SHOW_FILE external_local_path="{file_path}">{blob_name}</SHOW_FILE>'
                except FileUploadError:
                    return match.group(0)
        except (OSError, ValueError):
            pass

        # NEW: File path looks local but doesn't exist — track for error
        missing_files.append(file_path)
        return match.group(0)

    transformed = re.sub(
        r"<SHOW_FILE([^>]*)>(.*?)</SHOW_FILE>",
        replace_show_file,
        message,
        flags=re.DOTALL,
    )

    # NEW: Fail early if any referenced files are missing
    if missing_files:
        files_list = "\n".join(f"  - {path}" for path in missing_files)
        raise FileUploadError(
            f"Cannot upload {len(missing_files)} file(s) to CellCog — not found:\n"
            f"{files_list}\n\n"
            f"These files may exist on the user's machine but are not accessible "
            f"from the current environment. If running inside Docker, ensure the "
            f"file paths are mounted as volumes. If on WSL, ensure cross-filesystem "
            f"access is available."
        )

    return transformed, uploaded
```

**Error propagation:**
- `create_chat()` and `send_message()` in `client.py` both call `transform_outgoing()` BEFORE making the API call
- `FileUploadError` will propagate to the OpenClaw agent immediately
- No chat created, no credits spent
- OpenClaw agent can tell the user exactly what went wrong

### Files Changed

| File | Change |
|------|--------|
| `cellcog/files.py` | `transform_outgoing()` — add missing file tracking + raise `FileUploadError` |

---

## Issue 2: Unsafe Download Destinations via external_local_path

### Problem

**File:** `cellcog/files.py` → `transform_incoming_history()` (lines 92-171)

When processing incoming CellCog responses, the SDK checks for an `external_local_path` attribute on SHOW_FILE tags. If present, it downloads the file to that exact path on the user's machine:

```python
# Line 134-138: Current behavior
external_local_path_match = re.search(r'external_local_path="([^"]*)"', attrs)
if external_local_path_match:
    local_path = external_local_path_match.group(1)  # Use user-specified path!
else:
    local_path = self._generate_auto_download_path(blob_name, chat_id)  # Safe path

# Line 144-151: Downloads to local_path
if is_cellcog_message and should_download:
    self._download_file(url_data["url"], local_path)
```

**How external_local_path gets onto CellCog response messages:**

The GENERATE_FILE flow in the system design:
```
Agent sends:     <GENERATE_FILE>/outputs/report.pdf</GENERATE_FILE>
SDK transforms:  <GENERATE_FILE external_local_path="/outputs/report.pdf"></GENERATE_FILE>
CellCog returns: <SHOW_FILE external_local_path="/outputs/report.pdf">/home/app/output/report.pdf</SHOW_FILE>
SDK downloads:   blob → /outputs/report.pdf  ← DANGEROUS
```

**Why this is dangerous:**
- CellCog (a remote service) controls the `external_local_path` value in its response
- SDK blindly downloads files to any path on the user's machine
- Could overwrite existing files, write to system directories, etc.
- Even in the normal GENERATE_FILE case, the OpenClaw agent specifies the path — this still shouldn't be trusted for direct filesystem writes

### Solution

**Always download all incoming files to the safe `~/.cellcog/chats/{chat_id}/` directory**, regardless of whether `external_local_path` is present.

The `external_local_path` attribute is still preserved in the SHOW_FILE tag text for display/reference purposes, but it is **never used as a download destination**.

**Updated logic in `cellcog/files.py`:**

```python
def transform_incoming_history(
    self,
    messages: list,
    blob_name_to_url: dict,
    chat_id: str,
    skip_download_until_index: int = -1,
) -> list:
    transformed_messages = []

    for msg_index, msg in enumerate(messages):
        content = msg.get("content", "")
        message_from = msg.get("messageFrom", "")
        is_cellcog_message = message_from == "CellCog"
        should_download = msg_index > skip_download_until_index

        def replace_show_file(match):
            attrs = match.group(1)
            blob_name = match.group(2).strip()

            # CHANGED: Always generate safe download path
            # Never use external_local_path for download destination
            local_path = self._generate_auto_download_path(blob_name, chat_id)

            # Only download for CellCog messages we haven't seen yet
            if is_cellcog_message and should_download and blob_name in blob_name_to_url:
                url_data = blob_name_to_url[blob_name]
                try:
                    self._download_file(url_data["url"], local_path)
                except FileDownloadError:
                    pass

            # Return with safe local path
            return f"<SHOW_FILE>{local_path}</SHOW_FILE>"

        transformed_content = re.sub(
            r"<SHOW_FILE([^>]*)>(.*?)</SHOW_FILE>",
            replace_show_file,
            content,
            flags=re.DOTALL,
        )

        transformed_messages.append(
            {
                "role": "cellcog" if is_cellcog_message else "openclaw",
                "content": transformed_content,
                "created_at": msg.get("createdAt"),
            }
        )

    return transformed_messages
```

**Key change:** Removed the `external_local_path` branch entirely from the download path logic. The `_generate_auto_download_path()` method already handles all blob name formats correctly:

```
blob_name: "699fa731//home/app/output/report.pdf"
→ safe path: "~/.cellcog/chats/699fa731/output/report.pdf"

blob_name: "699fa731/human_files/video.mp4"
→ safe path: "~/.cellcog/chats/699fa731/human_files/video.mp4"
```

### Impact on OpenClaw Agent Experience

Before: Agent specifies `<GENERATE_FILE>/outputs/report.pdf</GENERATE_FILE>` → file appears at `/outputs/report.pdf`

After: File appears at `~/.cellcog/chats/{chat_id}/output/report.pdf` — the agent sees the safe path in the delivered SHOW_FILE tag and can reference it. The completion notification already lists downloaded file paths.

### Files Changed

| File | Change |
|------|--------|
| `cellcog/files.py` | `transform_incoming_history()` — remove `external_local_path` download branch, always use safe auto-generated path |

---

## Combined Change Summary

| File | Issue | Change Description |
|------|-------|--------------------|
| `cellcog/files.py` | Issue 1 | `transform_outgoing()` — raise `FileUploadError` when SHOW_FILE references missing local files |
| `cellcog/files.py` | Issue 2 | `transform_incoming_history()` — always download to `~/.cellcog/chats/{chat_id}/`, never use `external_local_path` as download destination |

### Testing Plan

**Issue 1 — Missing file detection:**
- Test with a SHOW_FILE referencing a non-existent path → should raise `FileUploadError`
- Test with a SHOW_FILE referencing an existing file → should upload normally (no regression)
- Test with a SHOW_FILE referencing a URL → should pass through unchanged
- Test with multiple SHOW_FILE tags, some missing some present → should raise with list of all missing files

**Issue 2 — Safe download paths:**
- Test with CellCog response containing `external_local_path` attribute → should download to `~/.cellcog/chats/` not the external path
- Test with CellCog response without `external_local_path` → should download to `~/.cellcog/chats/` (same behavior as before)
- Test that completion notification shows correct safe download paths
- Test that GENERATE_FILE flow still works end-to-end (files downloaded to safe location)

### Version Bump

These are non-breaking changes (Issue 1 adds error where there was silent failure, Issue 2 changes download location). Recommend bumping SDK patch version.
