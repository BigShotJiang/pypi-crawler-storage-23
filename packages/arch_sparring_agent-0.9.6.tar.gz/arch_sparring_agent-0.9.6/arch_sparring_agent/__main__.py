"""Allow running the package with ``python -m arch_sparring_agent``."""

from __future__ import annotations

from .cli import cli

cli()
