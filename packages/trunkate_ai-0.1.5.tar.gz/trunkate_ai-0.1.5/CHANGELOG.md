# Changelog

## [0.1.5](https://github.com/Trunkate-AI/trunkate-ai-sdk/compare/python-v0.1.4...python-v0.1.5) (2026-02-28)


### Documentation

* populate SDK readmes with official website documentation and fix release pipeline ([0029ca2](https://github.com/Trunkate-AI/trunkate-ai-sdk/commit/0029ca26022429f18ead88577c18f085bb689026))

## [0.1.4](https://github.com/Trunkate-AI/trunkate-ai-sdk/compare/python-v0.1.3...python-v0.1.4) (2026-02-28)


### Bug Fixes

* upgrade npm proxy to v11 and enforce full sdk release ([e764825](https://github.com/Trunkate-AI/trunkate-ai-sdk/commit/e7648257e9050e86cff15d38223c2458e7bbb69c))

## [0.1.3](https://github.com/Trunkate-AI/trunkate-ai-sdk/compare/python-v0.1.2...python-v0.1.3) (2026-02-28)


### Bug Fixes

* remove npm registry-url config to fix OIDC provenance and bump all SDKs ([5f93206](https://github.com/Trunkate-AI/trunkate-ai-sdk/commit/5f932067c98113dca6941d8ffbe2371834007335))
* resolve publish pipeline configuration bugs across sdks ([13d521f](https://github.com/Trunkate-AI/trunkate-ai-sdk/commit/13d521faf52138f4c00c8bc86c123fa269a65d1c))

## [0.1.2](https://github.com/Trunkate-AI/trunkate-ai-sdk/compare/v0.1.1...v0.1.2) (2026-02-28)


### Bug Fixes

* resolve publish pipeline configuration bugs across sdks ([13d521f](https://github.com/Trunkate-AI/trunkate-ai-sdk/commit/13d521faf52138f4c00c8bc86c123fa269a65d1c))

## [0.1.1](https://github.com/Trunkate-AI/trunkate-ai-sdk/compare/v0.1.0...v0.1.1) (2026-02-28)


### Bug Fixes

* remove npm registry-url config to fix OIDC provenance and bump all SDKs ([5f93206](https://github.com/Trunkate-AI/trunkate-ai-sdk/commit/5f932067c98113dca6941d8ffbe2371834007335))
