"""Git analysis module for EmDash."""

from .commit_analyzer import CommitAnalyzer

__all__ = ["CommitAnalyzer"]
