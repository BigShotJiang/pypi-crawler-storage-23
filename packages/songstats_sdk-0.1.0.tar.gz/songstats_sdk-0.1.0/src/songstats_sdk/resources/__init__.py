from .entities import ArtistsAPI, CollaboratorsAPI, LabelsAPI
from .info import InfoAPI
from .tracks import TracksAPI

__all__ = [
    "ArtistsAPI",
    "CollaboratorsAPI",
    "InfoAPI",
    "LabelsAPI",
    "TracksAPI",
]
