import logging

from .. import MokuException

log = logging.getLogger(__name__)


class NetworkError(MokuException):
    """
    Network connection to Moku failed
    """
    pass


class FileServerException(MokuException):
    """
    A request for an invalid instrument configuration has been made.
    """
    pass


class FrameTimeout(MokuException):
    """
    No new :any:`InstrumentData` arrived within the given timeout
    """
    pass


class Socket(object):
    def connect(self, ip_addr):
        raise NotImplementedError()

    def transfer(self, data):
        raise NotImplementedError()

    def close(self):
        pass


class FrameSocket(object):
    def get_data(self, parser=None, timeout=2.0):
        raise NotImplementedError()

    def close(self):
        pass


class SocketFactory(object):
    def get_control_socket(self):
        raise NotImplementedError()

    def get_render_socket(self):
        raise NotImplementedError()

    def get_frame_socket(self):
        raise NotImplementedError()


from .zmq import *  # noqa
from .tcp import *  # noqa
try:
    from .http import *  # noqa
except Exception:
    pass  # requires 'requests' to be installed
from .control import *  # noqa
from .file_transfer import *  # noqa
from .render import *  # noqa
from .notification import *  # noqa
