from importlib import metadata

version = metadata.version('pymoku')

current_fw_ver = 630

# Compatible network protocol version
protocol_version = '9'
