
def test_import():
    """ Absolute bare minimum: can we import without error """
    import pymoku  # noqa
