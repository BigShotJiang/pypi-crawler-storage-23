# PyMoku

# Getting started

Install the core library with

    pip install pymoku

To include support for the GUI application install with

    pip install pymoku[extras]

Launch the GUI with

    moku gui

And if you have local barfiles you are developing, you can specify a folder to
load with

    moku gui --dev /path/to/dev_folder
