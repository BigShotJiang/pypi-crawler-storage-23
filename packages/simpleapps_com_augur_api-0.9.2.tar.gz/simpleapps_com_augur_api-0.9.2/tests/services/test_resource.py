"""Tests for the BaseResource class."""

import pytest
from pydantic import BaseModel
from pytest_httpx import HTTPXMock

from augur_api.core.config import AugurAPIConfig
from augur_api.core.http_client import HTTPClient
from augur_api.services.resource import BaseResource


class TestParams(BaseModel):
    """Test params model."""

    limit: int | None = None
    offset: int | None = None


class TestData(BaseModel):
    """Test data model."""

    name: str
    value: int | None = None


class TestBaseResourceInit:
    """Tests for BaseResource initialization."""

    def test_init_stores_http_and_path(self) -> None:
        """Should store HTTP client and path."""
        config = AugurAPIConfig(token="test", site_id="test")
        http = HTTPClient("items", config)
        resource = BaseResource(http, "/test")
        assert resource._http is http
        assert resource._path == "/test"


class TestBaseResourceToParams:
    """Tests for _to_params method."""

    @pytest.fixture
    def resource(self) -> BaseResource:
        """Create a test resource."""
        config = AugurAPIConfig(token="test", site_id="test")
        http = HTTPClient("items", config)
        return BaseResource(http, "/test")

    def test_to_params_with_none(self, resource: BaseResource) -> None:
        """Should return None when params is None."""
        assert resource._to_params(None) is None

    def test_to_params_with_values(self, resource: BaseResource) -> None:
        """Should return dict with non-None values."""
        params = TestParams(limit=10, offset=20)
        result = resource._to_params(params)
        assert result == {"limit": 10, "offset": 20}

    def test_to_params_excludes_none(self, resource: BaseResource) -> None:
        """Should exclude None values from result."""
        params = TestParams(limit=10)
        result = resource._to_params(params)
        assert result == {"limit": 10}
        assert "offset" not in result

    def test_to_params_empty_returns_none(self, resource: BaseResource) -> None:
        """Should return None when all params are None."""
        params = TestParams()
        result = resource._to_params(params)
        assert result is None


class TestBaseResourceGet:
    """Tests for _get method."""

    @pytest.fixture
    def resource(self) -> BaseResource:
        """Create a test resource."""
        config = AugurAPIConfig(token="test", site_id="test", retries=0)
        http = HTTPClient("items", config)
        return BaseResource(http, "/test")

    def test_get_base_path(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should GET the base path when no path suffix."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            json={"data": "success"},
        )
        result = resource._get()
        assert result == {"data": "success"}

    def test_get_with_path_suffix(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should append path suffix to base path."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test/123",
            json={"data": "success"},
        )
        result = resource._get("/123")
        assert result == {"data": "success"}

    def test_get_with_params(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should include query params in request."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?limit=10",
            json={"data": "success"},
        )
        result = resource._get(params=TestParams(limit=10))
        assert result == {"data": "success"}


class TestBaseResourcePost:
    """Tests for _post method."""

    @pytest.fixture
    def resource(self) -> BaseResource:
        """Create a test resource."""
        config = AugurAPIConfig(token="test", site_id="test", retries=0)
        http = HTTPClient("items", config)
        return BaseResource(http, "/test")

    def test_post_base_path(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should POST to the base path."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            method="POST",
            json={"data": "created"},
        )
        result = resource._post(data=TestData(name="test"))
        assert result == {"data": "created"}

    def test_post_with_path_suffix(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should append path suffix to base path."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test/sub",
            method="POST",
            json={"data": "created"},
        )
        result = resource._post("/sub", data=TestData(name="test"))
        assert result == {"data": "created"}

    def test_post_with_dict_data(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should accept dict data as well as Pydantic model."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            method="POST",
            json={"data": "created"},
        )
        result = resource._post(data={"name": "test"})
        assert result == {"data": "created"}


class TestBaseResourcePut:
    """Tests for _put method."""

    @pytest.fixture
    def resource(self) -> BaseResource:
        """Create a test resource."""
        config = AugurAPIConfig(token="test", site_id="test", retries=0)
        http = HTTPClient("items", config)
        return BaseResource(http, "/test")

    def test_put_with_path(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should PUT to path suffix."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test/123",
            method="PUT",
            json={"data": "updated"},
        )
        result = resource._put("/123", data=TestData(name="updated"))
        assert result == {"data": "updated"}

    def test_put_with_dict_data(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should accept dict data."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test/123",
            method="PUT",
            json={"data": "updated"},
        )
        result = resource._put("/123", data={"name": "updated"})
        assert result == {"data": "updated"}


class TestBaseResourceDelete:
    """Tests for _delete method."""

    @pytest.fixture
    def resource(self) -> BaseResource:
        """Create a test resource."""
        config = AugurAPIConfig(token="test", site_id="test", retries=0)
        http = HTTPClient("items", config)
        return BaseResource(http, "/test")

    def test_delete_with_path(self, httpx_mock: HTTPXMock, resource: BaseResource) -> None:
        """Should DELETE at path suffix."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test/123",
            method="DELETE",
            json={"data": "deleted"},
        )
        result = resource._delete("/123")
        assert result == {"data": "deleted"}


class TestBaseResourceToParamsDict:
    """Tests for _to_params with dict input."""

    @pytest.fixture
    def resource(self) -> BaseResource:
        """Create a test resource."""
        config = AugurAPIConfig(token="test", site_id="test")
        http = HTTPClient("items", config)
        return BaseResource(http, "/test")

    def test_to_params_dict_with_all_none_values(self, resource: BaseResource) -> None:
        """Should return None when dict has all None values."""
        result = resource._to_params({"a": None, "b": None})
        assert result is None

    def test_to_params_dict_with_some_values(self, resource: BaseResource) -> None:
        """Should filter out None values from dict."""
        result = resource._to_params({"a": 1, "b": None, "c": "test"})
        assert result == {"a": 1, "c": "test"}
