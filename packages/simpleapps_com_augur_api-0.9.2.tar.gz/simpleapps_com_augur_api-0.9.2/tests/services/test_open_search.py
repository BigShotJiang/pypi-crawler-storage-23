"""Tests for the Open Search service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.open_search.schemas import (
    HealthCheckData,
    ItemDocument,
    ItemRefreshResponse,
    ItemSearchAttribute,
    ItemSearchAttributesParams,
    ItemSearchParams,
    ItemSearchResult,
    ItemsListParams,
    ItemUpdateParams,
    QueryString,
    QueryStringListParams,
    Suggestion,
    SuggestionListParams,
    SuggestionParams,
)


class TestOpenSearchSchemas:
    """Tests for Open Search schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_item_search_params(self) -> None:
        """Should create item search params."""
        params = ItemSearchParams(q="widget", limit=10, category_id=5)
        assert params.q == "widget"
        assert params.limit == 10
        assert params.category_id == 5

    def test_item_search_result_model(self) -> None:
        """Should parse item search result data."""
        data = {
            "invMastUid": 1,
            "itemId": "ABC123",
            "itemDesc": "Test Item",
            "price": 29.99,
            "inStock": True,
            "score": 0.95,
        }
        result = ItemSearchResult.model_validate(data)
        assert result.inv_mast_uid == 1
        assert result.item_id == "ABC123"
        assert result.price == 29.99

    def test_item_search_result_passthrough(self) -> None:
        """Should allow extra fields in item search result."""
        data = {"invMastUid": 1, "extraField": "extra"}
        result = ItemSearchResult.model_validate(data)
        assert result.inv_mast_uid == 1
        assert result.model_extra.get("extraField") == "extra"

    def test_item_search_attributes_params(self) -> None:
        """Should create item search attributes params."""
        params = ItemSearchAttributesParams(q="widget", category_id=5)
        assert params.q == "widget"
        assert params.category_id == 5

    def test_item_search_attribute_model(self) -> None:
        """Should parse item search attribute data."""
        data = {
            "attributeUid": 1,
            "attributeName": "Color",
            "values": [{"value": "Red", "count": 5}],
        }
        result = ItemSearchAttribute.model_validate(data)
        assert result.attribute_uid == 1
        assert result.attribute_name == "Color"

    def test_items_list_params(self) -> None:
        """Should create items list params."""
        params = ItemsListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_item_document_model(self) -> None:
        """Should parse item document data."""
        data = {"invMastUid": 1, "itemId": "ABC123", "itemDesc": "Test Item"}
        result = ItemDocument.model_validate(data)
        assert result.inv_mast_uid == 1
        assert result.item_id == "ABC123"

    def test_item_update_params(self) -> None:
        """Should create item update params."""
        params = ItemUpdateParams()
        assert params is not None

    def test_item_refresh_response_model(self) -> None:
        """Should parse item refresh response data."""
        data = {"status": "success"}
        result = ItemRefreshResponse.model_validate(data)
        assert result is not None

    def test_suggestion_params(self) -> None:
        """Should create suggestion params."""
        params = SuggestionParams(q="wid", limit=5)
        assert params.q == "wid"
        assert params.limit == 5

    def test_suggestion_list_params(self) -> None:
        """Should create suggestion list params."""
        params = SuggestionListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_suggestion_model(self) -> None:
        """Should parse suggestion data."""
        data = {
            "suggestionsUid": 1,
            "text": "widget",
            "type": "product",
            "score": 0.8,
            "count": 10,
        }
        result = Suggestion.model_validate(data)
        assert result.suggestions_uid == 1
        assert result.text == "widget"
        assert result.count == 10

    def test_query_string_list_params(self) -> None:
        """Should create query string list params."""
        params = QueryStringListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_query_string_model(self) -> None:
        """Should parse query string data."""
        data = {
            "queryStringUid": 1,
            "query": "widget",
            "searchCount": 100,
            "resultCount": 50,
            "clickCount": 25,
        }
        result = QueryString.model_validate(data)
        assert result.query_string_uid == 1
        assert result.query == "widget"
        assert result.search_count == 100


class TestOpenSearchClient:
    """Tests for OpenSearchClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.open_search.health_check()
        assert response.data.site_id == "test-site"

    def test_item_search_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list item search results."""
        mock_response = {
            "count": 1,
            "data": {
                "items": [{"invMastUid": 1, "itemId": "ABC123", "itemDesc": "Widget"}],
                "totalResults": 1,
                "maxScore": 10.5,
                "took": 5,
                "queryStringUid": 123,
                "queryStringRedirectLink": False,
            },
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/item-search?q=widget",
            json=mock_response,
        )
        response = api.open_search.item_search.list(ItemSearchParams(q="widget"))
        assert len(response.data.items) == 1
        assert response.data.total_results == 1

    def test_item_search_attributes_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list item search attributes."""
        mock_response = {
            "count": 1,
            "data": {"attributes": [{"attributeUid": 1, "attributeName": "Color"}]},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/item-search/attributes",
            json=mock_response,
        )
        response = api.open_search.item_search.attributes.list()
        assert len(response.data.attributes) == 1
        assert response.data.attributes[0].attribute_name == "Color"

    def test_item_search_attributes_list_with_params(
        self, httpx_mock: HTTPXMock, api: AugurAPI
    ) -> None:
        """Should list item search attributes with params."""
        mock_response = {
            "count": 1,
            "data": {"attributes": [{"attributeUid": 1, "attributeName": "Color"}]},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/item-search/attributes?q=test",
            json=mock_response,
        )
        response = api.open_search.item_search.attributes.list(ItemSearchAttributesParams(q="test"))
        assert len(response.data.attributes) == 1

    def test_items_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list items."""
        mock_response = {
            "count": 1,
            "data": [{"invMastUid": 1, "itemId": "ABC123"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/items",
            json=mock_response,
        )
        response = api.open_search.items.list()
        assert len(response.data) == 1

    def test_items_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get item document by UID."""
        mock_response = {
            "count": 1,
            "data": {"invMastUid": 1, "itemId": "ABC123"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/items/1",
            json=mock_response,
        )
        response = api.open_search.items.get(1)
        assert response.data.inv_mast_uid == 1

    def test_items_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update item document."""
        mock_response = {
            "count": 1,
            "data": {"invMastUid": 1, "itemId": "ABC123"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/items/1",
            json=mock_response,
        )
        response = api.open_search.items.update(1, ItemUpdateParams())
        assert response.data.inv_mast_uid == 1

    def test_items_refresh_all(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should refresh all items."""
        mock_response = {
            "count": 1,
            "data": {"status": "success"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/items/refresh",
            json=mock_response,
        )
        response = api.open_search.items.refresh_all()
        assert response is not None

    def test_items_refresh(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should refresh specific item."""
        mock_response = {
            "count": 1,
            "data": {"status": "success"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/items/1/refresh",
            json=mock_response,
        )
        response = api.open_search.items.refresh(1)
        assert response is not None

    def test_suggestions_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list suggestions."""
        mock_response = {
            "count": 2,
            "data": [{"suggestionsUid": 1, "text": "widget"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 2,
            "totalResults": 2,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/suggestions",
            json=mock_response,
        )
        response = api.open_search.suggestions.list()
        assert len(response.data) == 1

    def test_suggestions_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get suggestion by UID."""
        mock_response = {
            "count": 1,
            "data": {"suggestionsUid": 1, "text": "widget"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/suggestions/1",
            json=mock_response,
        )
        response = api.open_search.suggestions.get(1)
        assert response.data.suggestions_uid == 1

    def test_suggestions_suggest(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get search suggestions for autocomplete."""
        mock_response = {
            "count": 2,
            "data": [{"text": "widget"}, {"text": "widgets"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 2,
            "totalResults": 2,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/suggestions/suggest?q=wid",
            json=mock_response,
        )
        response = api.open_search.suggestions.suggest(SuggestionParams(q="wid"))
        assert len(response.data) == 2

    def test_query_string_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list query strings."""
        mock_response = {
            "count": 1,
            "data": [{"queryStringUid": 1, "query": "widget"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/query-string",
            json=mock_response,
        )
        response = api.open_search.query_string.list()
        assert len(response.data) == 1

    def test_query_string_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get query string by UID."""
        mock_response = {
            "count": 1,
            "data": {"queryStringUid": 1, "query": "widget"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://open-search.augur-api.com/query-string/1",
            json=mock_response,
        )
        response = api.open_search.query_string.get(1)
        assert response.data.query_string_uid == 1

    def test_item_search_attributes_property_cached(self, api: AugurAPI) -> None:
        """Should return same attributes resource instance on multiple accesses."""
        item_search = api.open_search.item_search
        assert item_search.attributes is item_search.attributes

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.open_search
        assert client.item_search is client.item_search
        assert client.items is client.items
        assert client.suggestions is client.suggestions
        assert client.query_string is client.query_string
