"""Tests for the Gregorovich service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.gregorovich.schemas import (
    ChatGptAskParams,
    ChatGptAskResult,
    DocumentsResult,
    HealthCheckData,
    OllamaGenerateParams,
    OllamaGenerateResult,
)


class TestGregorovichSchemas:
    """Tests for Gregorovich schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_chat_gpt_ask_params(self) -> None:
        """Should create ChatGPT ask params."""
        params = ChatGptAskParams(question="What is AI?")
        assert params.question == "What is AI?"

    def test_chat_gpt_ask_result(self) -> None:
        """Should parse ChatGPT ask result."""
        data = {"answer": "AI is...", "model": "gpt-4"}
        result = ChatGptAskResult.model_validate(data)
        # Passthrough allows any fields
        assert hasattr(result, "model_extra") or "answer" in result.model_dump()

    def test_documents_result(self) -> None:
        """Should parse documents result."""
        data = {"id": "doc123", "title": "Test Document"}
        result = DocumentsResult.model_validate(data)
        assert result.id == "doc123"

    def test_ollama_generate_params(self) -> None:
        """Should create Ollama generate params."""
        params = OllamaGenerateParams(model="llama2", prompt="Write a story")
        # Passthrough allows any fields
        assert hasattr(params, "model_extra") or "model" in params.model_dump()

    def test_ollama_generate_result(self) -> None:
        """Should parse Ollama generate result."""
        data = {"response": "Once upon a time...", "done": True}
        result = OllamaGenerateResult.model_validate(data)
        # Passthrough allows any fields
        assert hasattr(result, "model_extra") or "response" in result.model_dump()


class TestGregorovichClient:
    """Tests for GregorovichClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://gregorovich.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.gregorovich.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://gregorovich.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.gregorovich.ping()
        assert response.data == "pong"

    def test_chat_gpt_ask_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should ask ChatGPT a question."""
        mock_response = {
            "count": 1,
            "data": {"answer": "AI is artificial intelligence", "model": "gpt-4"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://gregorovich.augur-api.com/chat-gpt/ask?question=What+is+AI%3F",
            json=mock_response,
        )
        response = api.gregorovich.chat_gpt.ask.get(ChatGptAskParams(question="What is AI?"))
        assert response.data is not None

    def test_documents_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list documents."""
        mock_response = {
            "count": 2,
            "data": [{"id": "doc1", "title": "Doc 1"}, {"id": "doc2", "title": "Doc 2"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 2,
            "totalResults": 2,
        }
        httpx_mock.add_response(
            url="https://gregorovich.augur-api.com/documents",
            json=mock_response,
        )
        response = api.gregorovich.documents.list()
        assert len(response.data) == 2
        assert response.data[0].id == "doc1"

    def test_ollama_generate_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should generate with Ollama."""
        mock_response = {
            "count": 1,
            "data": {"response": "Once upon a time...", "done": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://gregorovich.augur-api.com/ollama/generate",
            json=mock_response,
            method="POST",
        )
        response = api.gregorovich.ollama.generate.create(OllamaGenerateParams())
        assert response.data is not None

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.gregorovich
        assert client.chat_gpt is client.chat_gpt
        assert client.chat_gpt.ask is client.chat_gpt.ask
        assert client.documents is client.documents
        assert client.ollama is client.ollama
        assert client.ollama.generate is client.ollama.generate
