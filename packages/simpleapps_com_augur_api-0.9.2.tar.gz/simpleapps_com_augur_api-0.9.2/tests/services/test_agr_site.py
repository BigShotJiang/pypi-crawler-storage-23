"""Tests for the AGR Site service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.agr_site import (
    FyxerTranscript,
    FyxerTranscriptCreateParams,
    FyxerTranscriptListParams,
    FyxerTranscriptUpdateParams,
    GeoCodesPostalCodes,
    MetaFilesRobotsResponse,
    NotificationCreateParams,
    NotificationResponse,
    OpenSearchEmbeddingParams,
    OpenSearchEmbeddingResponse,
    Setting,
    SettingCreateParams,
    SettingListParams,
    SettingUpdateParams,
    TrainingConv,
    TrainingConvCreateParams,
    TrainingConvUpdateParams,
    TrainingMsg,
    TrainingMsgCreateParams,
    TrainingMsgUpdateParams,
    TrainingSet,
    TrainingSetCreateParams,
    TrainingSetListParams,
    TrainingSetUpdateParams,
)
from augur_api.services.agr_site.schemas import ContextGetParams, ContextResponse, HealthCheckData


class TestAgrSiteSchemas:
    """Tests for AGR Site schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"
        assert result.site_hash == "abc123"

    def test_context_get_params(self) -> None:
        """Should create context get params."""
        params = ContextGetParams(edge_cache="5m")
        assert params.edge_cache == "5m"

    def test_context_get_params_defaults(self) -> None:
        """Should have None defaults."""
        params = ContextGetParams()
        assert params.edge_cache is None

    def test_context_response(self) -> None:
        """Should parse context response data."""
        data = {}
        result = ContextResponse.model_validate(data)
        assert result is not None

    def test_setting_list_params(self) -> None:
        """Should create setting list params."""
        params = SettingListParams(limit=10, offset=5, service_name="test")
        assert params.limit == 10
        assert params.offset == 5
        assert params.service_name == "test"

    def test_setting_list_params_defaults(self) -> None:
        """Should have None defaults."""
        params = SettingListParams()
        assert params.limit is None
        assert params.offset is None

    def test_setting_model(self) -> None:
        """Should parse setting data."""
        data = {
            "settingsUid": 1,
            "serviceName": "test-service",
            "settingKey": "key1",
            "settingValue": "value1",
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": "2024-01-02T00:00:00Z",
        }
        result = Setting.model_validate(data)
        assert result.settings_uid == 1
        assert result.service_name == "test-service"
        assert result.setting_key == "key1"
        assert result.setting_value == "value1"

    def test_setting_create_params(self) -> None:
        """Should create setting create params."""
        params = SettingCreateParams(service_name="test", setting_key="key", setting_value="value")
        assert params.service_name == "test"
        assert params.setting_key == "key"

    def test_setting_update_params(self) -> None:
        """Should create setting update params."""
        params = SettingUpdateParams(setting_value="new-value")
        assert params.setting_value == "new-value"

    def test_fyxer_transcript_list_params(self) -> None:
        """Should create Fyxer transcript list params."""
        params = FyxerTranscriptListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_fyxer_transcript_list_params_all_fields(self) -> None:
        """Should create Fyxer transcript list params with all fields."""
        params = FyxerTranscriptListParams(
            limit=10, offset=5, order_by="created_at", q="search", status_cd=1
        )
        assert params.order_by == "created_at"
        assert params.q == "search"
        assert params.status_cd == 1

    def test_fyxer_transcript_model(self) -> None:
        """Should parse Fyxer transcript data."""
        data = {
            "fyxerTranscriptHdrUid": 1,
            "link": "https://example.com",
            "title": "Test Transcript",
            "statusCd": 1,
        }
        result = FyxerTranscript.model_validate(data)
        assert result.fyxer_transcript_hdr_uid == 1
        assert result.title == "Test Transcript"

    def test_fyxer_transcript_create_params(self) -> None:
        """Should create Fyxer transcript create params."""
        params = FyxerTranscriptCreateParams(link="https://example.com")
        assert params.link == "https://example.com"

    def test_training_set_list_params(self) -> None:
        """Should create training set list params."""
        params = TrainingSetListParams(limit=10)
        assert params.limit == 10

    def test_training_set_model(self) -> None:
        """Should parse training set data."""
        data = {
            "trainingSetUid": 1,
            "name": "Test Set",
            "description": "Test description",
        }
        result = TrainingSet.model_validate(data)
        assert result.training_set_uid == 1
        assert result.name == "Test Set"

    def test_training_conv_model(self) -> None:
        """Should parse training conversation data."""
        data = {"trainingConvUid": 1, "trainingSetUid": 1, "title": "Test Conv"}
        result = TrainingConv.model_validate(data)
        assert result.training_conv_uid == 1
        assert result.title == "Test Conv"

    def test_training_msg_model(self) -> None:
        """Should parse training message data."""
        data = {
            "trainingMsgUid": 1,
            "trainingConvUid": 1,
            "role": "user",
            "content": "Hello",
        }
        result = TrainingMsg.model_validate(data)
        assert result.training_msg_uid == 1
        assert result.role == "user"
        assert result.content == "Hello"

    def test_geo_codes_postal_codes_model(self) -> None:
        """Should parse geo codes data."""
        data = {
            "geoCodesPostalCodesUid": 1,
            "postalCode": "12345",
            "city": "Test City",
            "state": "CA",
        }
        result = GeoCodesPostalCodes.model_validate(data)
        assert result.postal_code == "12345"
        assert result.city == "Test City"

    def test_notification_create_params(self) -> None:
        """Should create notification create params."""
        params = NotificationCreateParams(
            message="Test", recipient="user@test.com", notification_type="email"
        )
        assert params.message == "Test"
        assert params.recipient == "user@test.com"

    def test_notification_response(self) -> None:
        """Should parse notification response."""
        data = {"success": True, "message": "Sent"}
        result = NotificationResponse.model_validate(data)
        assert result.success is True
        assert result.message == "Sent"

    def test_open_search_embedding_params(self) -> None:
        """Should create OpenSearch embedding params."""
        params = OpenSearchEmbeddingParams(q="Hello", model="test", dimensions=768)
        assert params.q == "Hello"
        assert params.model == "test"

    def test_open_search_embedding_response(self) -> None:
        """Should parse OpenSearch embedding response."""
        data = {"embedding": [0.1, 0.2], "model": "test", "dimensions": 2}
        result = OpenSearchEmbeddingResponse.model_validate(data)
        assert result.embedding == [0.1, 0.2]
        assert result.dimensions == 2

    def test_meta_files_robots_response(self) -> None:
        """Should parse meta files robots response."""
        data = {"content": "User-agent: *"}
        result = MetaFilesRobotsResponse.model_validate(data)
        assert result.content == "User-agent: *"


class TestAgrSiteClient:
    """Tests for AgrSiteClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.agr_site.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.agr_site.ping()
        assert response.data == "pong"

    def test_context_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get context for a site."""
        mock_response = {
            "count": 1,
            "data": {"siteId": "target-site", "config": {"theme": "dark"}},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/context/target-site",
            json=mock_response,
        )
        response = api.agr_site.context.get("target-site")
        assert response.data is not None

    def test_context_get_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get context with params (edge_cache transforms to cacheSiteId)."""
        mock_response = {
            "count": 1,
            "data": {"siteId": "target-site"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        # edge_cache="5m" transforms to cacheSiteId5m=<site_id>
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/context/target-site?cacheSiteId5m=test-site",
            json=mock_response,
        )
        response = api.agr_site.context.get("target-site", ContextGetParams(edge_cache="5m"))
        assert response.data is not None

    def test_whoami(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should call whoami endpoint."""
        mock_response = {
            "count": 1,
            "data": {"user_id": "test-user", "email": "test@example.com"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/whoami",
            json=mock_response,
        )
        response = api.agr_site.whoami()
        assert response.data["user_id"] == "test-user"

    def test_settings_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list settings."""
        mock_response = {
            "count": 1,
            "data": [{"settingsUid": 1, "settingKey": "key1"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/settings",
            json=mock_response,
        )
        response = api.agr_site.settings.list()
        assert len(response.data) == 1
        assert response.data[0].setting_key == "key1"

    def test_settings_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get setting by UID."""
        mock_response = {
            "count": 1,
            "data": {"settingsUid": 1, "settingKey": "key1"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/settings/1",
            json=mock_response,
        )
        response = api.agr_site.settings.get(1)
        assert response.data.settings_uid == 1

    def test_settings_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create setting."""
        mock_response = {
            "count": 1,
            "data": {"settingsUid": 1, "settingKey": "key1"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/settings",
            json=mock_response,
            method="POST",
        )
        data = SettingCreateParams(service_name="test", setting_key="key1", setting_value="value1")
        response = api.agr_site.settings.create(data)
        assert response.data.setting_key == "key1"

    def test_settings_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update setting."""
        mock_response = {
            "count": 1,
            "data": {"settingsUid": 1, "settingValue": "updated"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/settings/1",
            json=mock_response,
            method="PUT",
        )
        data = SettingUpdateParams(setting_value="updated")
        response = api.agr_site.settings.update(1, data)
        assert response.data.setting_value == "updated"

    def test_settings_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete setting."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/settings/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.agr_site.settings.delete(1)
        assert response.data is True

    def test_fyxer_transcript_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list Fyxer transcripts."""
        mock_response = {
            "count": 1,
            "data": [{"fyxerTranscriptHdrUid": 1, "title": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/fyxer-transcript",
            json=mock_response,
        )
        response = api.agr_site.fyxer_transcript.list()
        assert len(response.data) == 1
        assert response.data[0].title == "Test"

    def test_fyxer_transcript_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get Fyxer transcript by UID."""
        mock_response = {
            "count": 1,
            "data": {"fyxerTranscriptHdrUid": 1, "title": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/fyxer-transcript/1",
            json=mock_response,
        )
        response = api.agr_site.fyxer_transcript.get(1)
        assert response.data.fyxer_transcript_hdr_uid == 1

    def test_fyxer_transcript_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create Fyxer transcript."""
        mock_response = {
            "count": 1,
            "data": {"fyxerTranscriptHdrUid": 1, "link": "https://example.com"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/fyxer-transcript",
            json=mock_response,
            method="POST",
        )
        data = FyxerTranscriptCreateParams(link="https://example.com")
        response = api.agr_site.fyxer_transcript.create(data)
        assert response.data.link == "https://example.com"

    def test_fyxer_transcript_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update Fyxer transcript."""
        mock_response = {
            "count": 1,
            "data": {"fyxerTranscriptHdrUid": 1, "title": "Updated"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/fyxer-transcript/1",
            json=mock_response,
            method="PUT",
        )
        data = FyxerTranscriptUpdateParams(title="Updated")
        response = api.agr_site.fyxer_transcript.update(1, data)
        assert response.data.title == "Updated"

    def test_fyxer_transcript_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete Fyxer transcript."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/fyxer-transcript/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.agr_site.fyxer_transcript.delete(1)
        assert response.data is True

    def test_training_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list training sets."""
        mock_response = {
            "count": 1,
            "data": [{"trainingSetUid": 1, "name": "Test Set"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training",
            json=mock_response,
        )
        response = api.agr_site.training.list()
        assert len(response.data) == 1
        assert response.data[0].name == "Test Set"

    def test_training_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get training set by UID."""
        mock_response = {
            "count": 1,
            "data": {"trainingSetUid": 1, "name": "Test Set"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1",
            json=mock_response,
        )
        response = api.agr_site.training.get(1)
        assert response.data.training_set_uid == 1

    def test_training_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create training set."""
        mock_response = {
            "count": 1,
            "data": {"trainingSetUid": 1, "name": "New Set"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training",
            json=mock_response,
            method="POST",
        )
        data = TrainingSetCreateParams(name="New Set", description="Description")
        response = api.agr_site.training.create(data)
        assert response.data.name == "New Set"

    def test_training_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update training set."""
        mock_response = {
            "count": 1,
            "data": {"trainingSetUid": 1, "name": "Updated Set"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1",
            json=mock_response,
            method="PUT",
        )
        data = TrainingSetUpdateParams(name="Updated Set")
        response = api.agr_site.training.update(1, data)
        assert response.data.name == "Updated Set"

    def test_training_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete training set."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.agr_site.training.delete(1)
        assert response.data is True

    def test_training_conversations_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list training conversations."""
        mock_response = {
            "count": 1,
            "data": [{"trainingConvUid": 1, "title": "Conv 1"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations",
            json=mock_response,
        )
        response = api.agr_site.training.list_conversations(1)
        assert len(response.data) == 1
        assert response.data[0].title == "Conv 1"

    def test_training_conversations_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create training conversation."""
        mock_response = {
            "count": 1,
            "data": {"trainingConvUid": 1, "title": "New Conv"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations",
            json=mock_response,
            method="POST",
        )
        data = TrainingConvCreateParams(title="New Conv")
        response = api.agr_site.training.create_conversation(1, data)
        assert response.data.title == "New Conv"

    def test_training_conversations_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update training conversation."""
        mock_response = {
            "count": 1,
            "data": {"trainingConvUid": 1, "title": "Updated Conv"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations/1",
            json=mock_response,
            method="PUT",
        )
        data = TrainingConvUpdateParams(title="Updated Conv")
        response = api.agr_site.training.update_conversation(1, 1, data)
        assert response.data.title == "Updated Conv"

    def test_training_conversations_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete training conversation."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.agr_site.training.delete_conversation(1, 1)
        assert response.data is True

    def test_training_messages_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list training messages."""
        mock_response = {
            "count": 1,
            "data": [{"trainingMsgUid": 1, "content": "Hello"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations/1/messages",
            json=mock_response,
        )
        response = api.agr_site.training.list_messages(1, 1)
        assert len(response.data) == 1
        assert response.data[0].content == "Hello"

    def test_training_conversations_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get training conversation by UID."""
        mock_response = {
            "count": 1,
            "data": {"trainingConvUid": 1, "title": "Test Conv"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations/1",
            json=mock_response,
        )
        response = api.agr_site.training.get_conversation(1, 1)
        assert response.data.training_conv_uid == 1
        assert response.data.title == "Test Conv"

    def test_training_messages_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get training message by UID."""
        mock_response = {
            "count": 1,
            "data": {"trainingMsgUid": 1, "content": "Hello", "role": "user"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations/1/messages/1",
            json=mock_response,
        )
        response = api.agr_site.training.get_message(1, 1, 1)
        assert response.data.training_msg_uid == 1
        assert response.data.content == "Hello"

    def test_training_messages_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create training message."""
        mock_response = {
            "count": 1,
            "data": {"trainingMsgUid": 1, "content": "New Msg", "role": "user"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations/1/messages",
            json=mock_response,
            method="POST",
        )
        data = TrainingMsgCreateParams(content="New Msg", role="user")
        response = api.agr_site.training.create_message(1, 1, data)
        assert response.data.content == "New Msg"

    def test_training_messages_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update training message."""
        mock_response = {
            "count": 1,
            "data": {"trainingMsgUid": 1, "content": "Updated Msg", "role": "user"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations/1/messages/1",
            json=mock_response,
            method="PUT",
        )
        data = TrainingMsgUpdateParams(content="Updated Msg")
        response = api.agr_site.training.update_message(1, 1, 1, data)
        assert response.data.content == "Updated Msg"

    def test_training_messages_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete training message."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/training/1/conversations/1/messages/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.agr_site.training.delete_message(1, 1, 1)
        assert response.data is True

    def test_geo_codes_postal_codes_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list geo codes."""
        mock_response = {
            "count": 1,
            "data": [{"geoCodesPostalCodesUid": 1, "postalCode": "12345"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/geo-codes-postal-codes",
            json=mock_response,
        )
        response = api.agr_site.geo_codes_postal_codes.list()
        assert len(response.data) == 1
        assert response.data[0].postal_code == "12345"

    def test_geo_codes_postal_codes_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get geo code by UID."""
        mock_response = {
            "count": 1,
            "data": {"geoCodesPostalCodesUid": 1, "postalCode": "12345", "city": "Test City"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/geo-codes-postal-codes/1",
            json=mock_response,
        )
        response = api.agr_site.geo_codes_postal_codes.get(1)
        assert response.data.geo_codes_postal_codes_uid == 1
        assert response.data.postal_code == "12345"

    def test_notifications_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create notification."""
        mock_response = {
            "count": 1,
            "data": {"success": True, "message": "Sent"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/notifications",
            json=mock_response,
            method="POST",
        )
        data = NotificationCreateParams(message="Test", recipient="test@example.com")
        response = api.agr_site.notifications.create(data)
        assert response.data.success is True

    def test_open_search_get_embedding(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get embedding."""
        mock_response = {
            "count": 1,
            "data": {"embedding": [0.1, 0.2], "model": "test", "dimensions": 2},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/open-search/embedding?q=hello",
            json=mock_response,
        )
        params = OpenSearchEmbeddingParams(q="hello")
        response = api.agr_site.open_search.get_embedding(params)
        assert response.data.embedding == [0.1, 0.2]

    def test_meta_files_get_robots(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get robots.txt."""
        mock_response = {
            "count": 1,
            "data": {"content": "User-agent: *"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://agr-site.augur-api.com/meta-files/robots",
            json=mock_response,
        )
        response = api.agr_site.meta_files.get_robots()
        assert response.data.content == "User-agent: *"

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.agr_site
        assert client.context is client.context
        assert client.settings is client.settings
        assert client.fyxer_transcript is client.fyxer_transcript
        assert client.training is client.training
        assert client.geo_codes_postal_codes is client.geo_codes_postal_codes
        assert client.notifications is client.notifications
        assert client.open_search is client.open_search
        assert client.meta_files is client.meta_files
