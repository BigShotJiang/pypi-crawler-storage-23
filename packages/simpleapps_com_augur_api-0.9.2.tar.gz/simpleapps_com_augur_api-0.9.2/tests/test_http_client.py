"""Tests for the HTTP client."""

import httpx
import pytest
from pytest_httpx import HTTPXMock

from augur_api.core.config import AugurAPIConfig
from augur_api.core.errors import (
    AugurError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
)
from augur_api.core.http_client import (
    SERVICE_BASE_URLS,
    HTTPClient,
    _calculate_backoff_delay,
    _generate_request_key,
    _is_retryable_error,
)


class TestServiceBaseUrls:
    """Tests for service base URLs."""

    def test_items_url(self) -> None:
        """Items service URL should be correct."""
        assert SERVICE_BASE_URLS["items"] == "https://items.augur-api.com"

    def test_p21_core_url(self) -> None:
        """P21 Core service URL should be correct."""
        assert SERVICE_BASE_URLS["p21-core"] == "https://p21-core.augur-api.com"


class TestGenerateRequestKey:
    """Tests for request key generation."""

    def test_generates_different_keys_for_different_methods(self) -> None:
        """Should generate different keys for different methods."""
        key1 = _generate_request_key("GET", "/test")
        key2 = _generate_request_key("POST", "/test")
        assert key1 != key2

    def test_generates_different_keys_for_different_urls(self) -> None:
        """Should generate different keys for different URLs."""
        key1 = _generate_request_key("GET", "/test1")
        key2 = _generate_request_key("GET", "/test2")
        assert key1 != key2

    def test_generates_different_keys_for_different_params(self) -> None:
        """Should generate different keys for different params."""
        key1 = _generate_request_key("GET", "/test", {"a": 1})
        key2 = _generate_request_key("GET", "/test", {"a": 2})
        assert key1 != key2

    def test_generates_same_key_for_same_request(self) -> None:
        """Should generate same key for identical requests."""
        key1 = _generate_request_key("GET", "/test", {"a": 1})
        key2 = _generate_request_key("GET", "/test", {"a": 1})
        assert key1 == key2


class TestCalculateBackoffDelay:
    """Tests for backoff delay calculation."""

    def test_first_attempt_uses_base_delay(self) -> None:
        """First attempt should use approximately base delay."""
        delay = _calculate_backoff_delay(0, 1.0)
        # With jitter, should be between 1.0 and 1.3
        assert 1.0 <= delay <= 1.3

    def test_delay_increases_exponentially(self) -> None:
        """Delay should increase exponentially."""
        delay0 = _calculate_backoff_delay(0, 1.0)
        delay1 = _calculate_backoff_delay(1, 1.0)
        delay2 = _calculate_backoff_delay(2, 1.0)
        # Without jitter, would be 1, 2, 4 - allow for jitter range
        assert delay0 < delay1 < delay2

    def test_delay_caps_at_30_seconds(self) -> None:
        """Delay should cap at 30 seconds."""
        delay = _calculate_backoff_delay(10, 1.0)  # Would be 1024 without cap
        assert delay <= 30.0


class TestIsRetryableError:
    """Tests for retryable error detection."""

    def test_network_error_is_retryable(self) -> None:
        """Network errors (None status) should be retryable."""
        assert _is_retryable_error(None) is True

    def test_rate_limit_is_retryable(self) -> None:
        """429 errors should be retryable."""
        assert _is_retryable_error(429) is True

    def test_server_errors_are_retryable(self) -> None:
        """5xx errors should be retryable."""
        assert _is_retryable_error(500) is True
        assert _is_retryable_error(502) is True
        assert _is_retryable_error(503) is True

    def test_client_errors_are_not_retryable(self) -> None:
        """4xx errors (except 429) should not be retryable."""
        assert _is_retryable_error(400) is False
        assert _is_retryable_error(401) is False
        assert _is_retryable_error(404) is False


class TestHTTPClientInit:
    """Tests for HTTPClient initialization."""

    def test_init_with_known_service(self) -> None:
        """Should use known service URL."""
        config = AugurAPIConfig(token="test", site_id="test-site")
        client = HTTPClient("items", config)
        assert client.base_url == "https://items.augur-api.com"

    def test_init_with_unknown_service(self) -> None:
        """Should construct URL for unknown service."""
        config = AugurAPIConfig(token="test", site_id="test-site")
        client = HTTPClient("unknown-service", config)
        assert client.base_url == "https://unknown-service.augur-api.com"


class TestHTTPClientRequests:
    """Tests for HTTPClient request methods."""

    @pytest.fixture
    def http_client(self) -> HTTPClient:
        """Create an HTTP client for testing."""
        config = AugurAPIConfig(
            token="test-token",
            site_id="test-site",
            retries=0,  # Disable retries for most tests
        )
        return HTTPClient("items", config)

    def test_get_success(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """GET request should return response data."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/health-check",
            json={"data": "test"},
        )
        result = http_client.get("/health-check")
        assert result == {"data": "test"}

    def test_get_with_params(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """GET request should include query params."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?limit=10",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"limit": 10})
        assert result == {"data": "test"}

    def test_post_success(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """POST request should return response data."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            method="POST",
            json={"data": "created"},
        )
        result = http_client.post("/test", data={"name": "test"})
        assert result == {"data": "created"}

    def test_put_success(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """PUT request should return response data."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test/1",
            method="PUT",
            json={"data": "updated"},
        )
        result = http_client.put("/test/1", data={"name": "updated"})
        assert result == {"data": "updated"}

    def test_delete_success(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """DELETE request should return response data."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test/1",
            method="DELETE",
            json={"data": "deleted"},
        )
        result = http_client.delete("/test/1")
        assert result == {"data": "deleted"}

    def test_auth_header_on_protected_endpoint(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """Protected endpoints should include auth header."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/protected",
            json={"data": "test"},
        )
        http_client.get("/protected")
        request = httpx_mock.get_requests()[0]
        assert request.headers["Authorization"] == "Bearer test-token"

    def test_no_auth_header_on_health_check(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """Health check endpoint should not include auth header."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/health-check",
            json={"data": "test"},
        )
        http_client.get("/health-check")
        request = httpx_mock.get_requests()[0]
        assert "Authorization" not in request.headers

    def test_no_auth_header_on_ping(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """Ping endpoint should not include auth header."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/ping",
            json={"data": "pong"},
        )
        http_client.get("/ping")
        request = httpx_mock.get_requests()[0]
        assert "Authorization" not in request.headers

    def test_site_id_header(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """All requests should include x-site-id header."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            json={"data": "test"},
        )
        http_client.get("/test")
        request = httpx_mock.get_requests()[0]
        assert request.headers["x-site-id"] == "test-site"


class TestHTTPClientErrors:
    """Tests for HTTPClient error handling."""

    @pytest.fixture
    def http_client(self) -> HTTPClient:
        """Create an HTTP client for testing."""
        config = AugurAPIConfig(
            token="test-token",
            site_id="test-site",
            retries=0,
        )
        return HTTPClient("items", config)

    def test_401_raises_authentication_error(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """401 response should raise AuthenticationError."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            status_code=401,
            json={"message": "Invalid token"},
        )
        with pytest.raises(AuthenticationError) as exc_info:
            http_client.get("/test")
        assert exc_info.value.status_code == 401

    def test_404_raises_not_found_error(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """404 response should raise NotFoundError."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test/999",
            status_code=404,
            json={"message": "Resource not found"},
        )
        with pytest.raises(NotFoundError) as exc_info:
            http_client.get("/test/999")
        assert exc_info.value.status_code == 404

    def test_429_raises_rate_limit_error(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """429 response should raise RateLimitError."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            status_code=429,
            json={"message": "Rate limit exceeded"},
        )
        with pytest.raises(RateLimitError) as exc_info:
            http_client.get("/test")
        assert exc_info.value.status_code == 429

    def test_500_raises_augur_error(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """500 response should raise AugurError."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            status_code=500,
            json={"message": "Internal error", "code": "SERVER_ERROR"},
        )
        with pytest.raises(AugurError) as exc_info:
            http_client.get("/test")
        assert exc_info.value.status_code == 500
        assert exc_info.value.code == "SERVER_ERROR"

    def test_error_with_invalid_json(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """Should handle error response with invalid JSON."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            status_code=500,
            text="Internal Server Error",
        )
        with pytest.raises(AugurError) as exc_info:
            http_client.get("/test")
        assert exc_info.value.status_code == 500


class TestHTTPClientRetries:
    """Tests for HTTPClient retry logic."""

    def test_retries_on_server_error(self, httpx_mock: HTTPXMock) -> None:
        """Should retry on 5xx errors."""
        config = AugurAPIConfig(
            token="test-token",
            site_id="test-site",
            retries=2,
            retry_delay=0.01,  # Fast retries for testing
        )
        client = HTTPClient("items", config)

        # First two requests fail, third succeeds
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            status_code=500,
        )
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            status_code=500,
        )
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            json={"data": "success"},
        )

        result = client.get("/test")
        assert result == {"data": "success"}
        assert len(httpx_mock.get_requests()) == 3

    def test_no_retry_on_client_error(self, httpx_mock: HTTPXMock) -> None:
        """Should not retry on 4xx errors (except 429)."""
        config = AugurAPIConfig(
            token="test-token",
            site_id="test-site",
            retries=2,
        )
        client = HTTPClient("items", config)

        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            status_code=400,
            json={"message": "Bad request"},
        )

        with pytest.raises(AugurError):
            client.get("/test")

        # Should not retry
        assert len(httpx_mock.get_requests()) == 1


class TestHTTPClientNetworkErrors:
    """Tests for network error handling."""

    def test_retries_on_network_error(self, httpx_mock: HTTPXMock) -> None:
        """Should retry on network errors and eventually succeed."""
        config = AugurAPIConfig(
            token="test-token",
            site_id="test-site",
            retries=2,
            retry_delay=0.01,
        )
        client = HTTPClient("items", config)

        # First two requests fail with network error, third succeeds
        httpx_mock.add_exception(
            httpx.RequestError("Connection failed"),
            url="https://items.augur-api.com/test",
        )
        httpx_mock.add_exception(
            httpx.RequestError("Connection failed"),
            url="https://items.augur-api.com/test",
        )
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            json={"data": "success"},
        )

        result = client.get("/test")
        assert result == {"data": "success"}
        assert len(httpx_mock.get_requests()) == 3

    def test_raises_augur_error_after_max_retries_on_network_error(
        self, httpx_mock: HTTPXMock
    ) -> None:
        """Should raise AugurError after exhausting retries on network errors."""
        config = AugurAPIConfig(
            token="test-token",
            site_id="test-site",
            retries=1,
            retry_delay=0.01,
        )
        client = HTTPClient("items", config)

        # All requests fail with network error
        httpx_mock.add_exception(
            httpx.RequestError("Connection failed"),
            url="https://items.augur-api.com/test",
        )
        httpx_mock.add_exception(
            httpx.RequestError("Connection failed"),
            url="https://items.augur-api.com/test",
        )

        with pytest.raises(AugurError) as exc_info:
            client.get("/test")
        assert exc_info.value.code == "NETWORK_ERROR"
        assert "Connection failed" in exc_info.value.message


class TestHTTPClientDeduplication:
    """Tests for request deduplication."""

    def test_returns_cached_result_for_inflight_request(self) -> None:
        """Should return cached result when same request is in-flight."""
        config = AugurAPIConfig(
            token="test-token",
            site_id="test-site",
            retries=0,
        )
        client = HTTPClient("items", config)

        # Manually inject a cached result to simulate in-flight request
        cached_result = {"data": "cached"}
        url = f"{client.base_url}/test"
        key = _generate_request_key("GET", url, None)
        client._inflight_requests[key] = cached_result

        # This should return the cached result without making a request
        result = client.get("/test")
        assert result == cached_result


class TestHTTPClientClose:
    """Tests for HTTPClient cleanup."""

    def test_close_releases_resources(self) -> None:
        """close() should release HTTP client resources."""
        config = AugurAPIConfig(token="test", site_id="test")
        client = HTTPClient("items", config)
        client.close()  # Should not raise


class TestEdgeCacheTransformation:
    """Tests for edge cache parameter transformation."""

    @pytest.fixture
    def http_client(self) -> HTTPClient:
        """Create an HTTP client for testing."""
        config = AugurAPIConfig(
            token="test-token",
            site_id="test-site",
            retries=0,
        )
        return HTTPClient("items", config)

    def test_transform_edge_cache_1_to_cache_site_id_1(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """edge_cache: 1 should transform to cacheSiteId1."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?cacheSiteId1=test-site",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"edge_cache": 1})
        assert result == {"data": "test"}

    def test_transform_edge_cache_8_to_cache_site_id_8(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """edge_cache: 8 should transform to cacheSiteId8."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?cacheSiteId8=test-site",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"edge_cache": 8})
        assert result == {"data": "test"}

    def test_transform_edge_cache_30s_to_cache_site_id_30s(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """edge_cache: '30s' should transform to cacheSiteId30s."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?cacheSiteId30s=test-site",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"edge_cache": "30s"})
        assert result == {"data": "test"}

    def test_transform_edge_cache_1m_to_cache_site_id_1m(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """edge_cache: '1m' should transform to cacheSiteId1m."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?cacheSiteId1m=test-site",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"edge_cache": "1m"})
        assert result == {"data": "test"}

    def test_transform_edge_cache_5m_to_cache_site_id_5m(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """edge_cache: '5m' should transform to cacheSiteId5m."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?cacheSiteId5m=test-site",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"edge_cache": "5m"})
        assert result == {"data": "test"}

    def test_transform_string_hourly_value(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """edge_cache: '2' should transform to cacheSiteId2."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?cacheSiteId2=test-site",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"edge_cache": "2"})
        assert result == {"data": "test"}

    def test_preserve_other_params(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """Other params should be preserved when transforming edge_cache."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?limit=10&cacheSiteId1=test-site",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"limit": 10, "edge_cache": 1})
        assert result == {"data": "test"}

    def test_remove_invalid_edge_cache_value(
        self, httpx_mock: HTTPXMock, http_client: HTTPClient
    ) -> None:
        """Invalid edge_cache values should be removed."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test?limit=10",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"limit": 10, "edge_cache": 99})
        assert result == {"data": "test"}

    def test_remove_edge_cache_6(self, httpx_mock: HTTPXMock, http_client: HTTPClient) -> None:
        """edge_cache: 6 should be removed (not in valid hourly values)."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/test",
            json={"data": "test"},
        )
        result = http_client.get("/test", params={"edge_cache": 6})
        assert result == {"data": "test"}

    def test_handle_none_params(self, http_client: HTTPClient) -> None:
        """Should handle None params without transformation."""
        result = http_client._transform_edge_cache_params(None)
        assert result is None

    def test_handle_empty_params(self, http_client: HTTPClient) -> None:
        """Should handle empty params without transformation."""
        result = http_client._transform_edge_cache_params({})
        assert result == {}

    def test_handle_params_without_edge_cache(self, http_client: HTTPClient) -> None:
        """Should return params unchanged when no edge_cache is present."""
        result = http_client._transform_edge_cache_params({"limit": 10})
        assert result == {"limit": 10}

    def test_invalid_string_edge_cache(self, http_client: HTTPClient) -> None:
        """Invalid string values should remove edge_cache."""
        result = http_client._transform_edge_cache_params({"edge_cache": "invalid"})
        assert result == {}
