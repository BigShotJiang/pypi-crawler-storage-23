"""Tests for the main AugurAPI client."""

import pytest

from augur_api import AugurAPI, AugurAPIConfig, AugurContext, ContextCreationError, __version__


class TestVersion:
    """Tests for package version."""

    def test_version_is_string(self) -> None:
        """Version should be a string."""
        assert isinstance(__version__, str)

    def test_version_format(self) -> None:
        """Version should follow semver format."""
        parts = __version__.split(".")
        assert len(parts) == 3
        assert all(part.isdigit() for part in parts)


class TestAugurAPIInit:
    """Tests for AugurAPI initialization."""

    def test_init_with_required_args(self) -> None:
        """Should initialize with token and site_id."""
        api = AugurAPI(token="test-token", site_id="test-site")
        assert api.config.token == "test-token"
        assert api.config.site_id == "test-site"

    def test_init_with_defaults(self) -> None:
        """Should use default values for optional arguments."""
        api = AugurAPI(token="test-token", site_id="test-site")
        assert api.config.timeout == 30.0
        assert api.config.retries == 3
        assert api.config.retry_delay == 1.0

    def test_init_with_custom_values(self) -> None:
        """Should accept custom values for optional arguments."""
        api = AugurAPI(
            token="test-token",
            site_id="test-site",
            timeout=60.0,
            retries=5,
            retry_delay=2.0,
        )
        assert api.config.timeout == 60.0
        assert api.config.retries == 5
        assert api.config.retry_delay == 2.0


class TestAugurAPIFromConfig:
    """Tests for AugurAPI.from_config factory method."""

    def test_from_config(self, api_config: AugurAPIConfig) -> None:
        """Should create instance from config object."""
        api = AugurAPI.from_config(api_config)
        assert api.config.token == api_config.token
        assert api.config.site_id == api_config.site_id
        assert api.config.timeout == api_config.timeout


class TestAugurAPIFromContext:
    """Tests for AugurAPI.from_context factory method."""

    def test_from_context_with_jwt(self) -> None:
        """Should create instance from context with jwt."""
        context = AugurContext(site_id="test-site", jwt="test-jwt")
        api = AugurAPI.from_context(context)
        assert api.config.token == "test-jwt"
        assert api.config.site_id == "test-site"

    def test_from_context_with_bearer_token(self) -> None:
        """Should create instance from context with bearer_token."""
        context = AugurContext(site_id="test-site", bearer_token="test-bearer")
        api = AugurAPI.from_context(context)
        assert api.config.token == "test-bearer"

    def test_from_context_with_options(self) -> None:
        """Should accept optional configuration overrides."""
        context = AugurContext(site_id="test-site", jwt="test-jwt")
        api = AugurAPI.from_context(context, timeout=60.0, retries=5)
        assert api.config.timeout == 60.0
        assert api.config.retries == 5

    def test_from_context_none_raises_error(self) -> None:
        """Should raise error when context is None."""
        with pytest.raises(ContextCreationError) as exc_info:
            AugurAPI.from_context(None)  # type: ignore[arg-type]
        assert exc_info.value.field == "context"

    def test_from_context_missing_site_id_raises_error(self) -> None:
        """Should raise error when site_id is missing."""
        context = AugurContext(site_id="", jwt="test-jwt")
        with pytest.raises(ContextCreationError) as exc_info:
            AugurAPI.from_context(context)
        assert exc_info.value.field == "site_id"

    def test_from_context_missing_token_raises_error(self) -> None:
        """Should raise error when both jwt and bearer_token are missing."""
        context = AugurContext(site_id="test-site")
        with pytest.raises(ContextCreationError) as exc_info:
            AugurAPI.from_context(context)
        assert exc_info.value.field == "bearer_token"


class TestAugurAPIServices:
    """Tests for service property accessors."""

    def test_items_property_lazy_init(self, api: AugurAPI) -> None:
        """Items property should be lazily initialized."""
        # Should be None initially (internal state)
        assert api._items is None
        # Accessing property should initialize
        _ = api.items
        assert api._items is not None

    def test_items_property_returns_same_instance(self, api: AugurAPI) -> None:
        """Items property should return same instance on repeated access."""
        items1 = api.items
        items2 = api.items
        assert items1 is items2

    def test_p21_core_property_lazy_init(self, api: AugurAPI) -> None:
        """P21 Core property should be lazily initialized."""
        assert api._p21_core is None
        _ = api.p21_core
        assert api._p21_core is not None

    def test_p21_core_property_returns_same_instance(self, api: AugurAPI) -> None:
        """P21 Core property should return same instance on repeated access."""
        p21_core1 = api.p21_core
        p21_core2 = api.p21_core
        assert p21_core1 is p21_core2

    def test_all_service_properties_lazy_init(self, api: AugurAPI) -> None:
        """All service properties should be lazily initialized."""
        # Access all services to trigger lazy initialization
        _ = api.agr_info
        _ = api.agr_site
        _ = api.agr_work
        _ = api.avalara
        _ = api.basecamp2
        _ = api.brand_folder
        _ = api.commerce
        _ = api.customers
        _ = api.gregorovich
        _ = api.joomla
        _ = api.legacy
        _ = api.logistics
        _ = api.nexus
        _ = api.open_search
        _ = api.orders
        _ = api.p21_apis
        _ = api.p21_pim
        _ = api.p21_sism
        _ = api.payments
        _ = api.pricing
        _ = api.shipping
        _ = api.slack
        _ = api.smarty_streets
        _ = api.ups
        _ = api.vmi

        # Verify all are initialized
        assert api._agr_info is not None
        assert api._agr_site is not None
        assert api._agr_work is not None
        assert api._avalara is not None
        assert api._basecamp2 is not None
        assert api._brand_folder is not None
        assert api._commerce is not None
        assert api._customers is not None
        assert api._gregorovich is not None
        assert api._joomla is not None
        assert api._legacy is not None
        assert api._logistics is not None
        assert api._nexus is not None
        assert api._open_search is not None
        assert api._orders is not None
        assert api._p21_apis is not None
        assert api._p21_pim is not None
        assert api._p21_sism is not None
        assert api._payments is not None
        assert api._pricing is not None
        assert api._shipping is not None
        assert api._slack is not None
        assert api._smarty_streets is not None
        assert api._ups is not None
        assert api._vmi is not None

    def test_all_service_properties_return_same_instance(self, api: AugurAPI) -> None:
        """All service properties should return same instance on repeated access."""
        assert api.agr_info is api.agr_info
        assert api.agr_site is api.agr_site
        assert api.agr_work is api.agr_work
        assert api.avalara is api.avalara
        assert api.basecamp2 is api.basecamp2
        assert api.brand_folder is api.brand_folder
        assert api.commerce is api.commerce
        assert api.customers is api.customers
        assert api.gregorovich is api.gregorovich
        assert api.joomla is api.joomla
        assert api.legacy is api.legacy
        assert api.logistics is api.logistics
        assert api.nexus is api.nexus
        assert api.open_search is api.open_search
        assert api.orders is api.orders
        assert api.p21_apis is api.p21_apis
        assert api.p21_pim is api.p21_pim
        assert api.p21_sism is api.p21_sism
        assert api.payments is api.payments
        assert api.pricing is api.pricing
        assert api.shipping is api.shipping
        assert api.slack is api.slack
        assert api.smarty_streets is api.smarty_streets
        assert api.ups is api.ups
        assert api.vmi is api.vmi


class TestAugurAPITokenManagement:
    """Tests for token and site ID management."""

    def test_set_token_updates_config(self, api: AugurAPI) -> None:
        """set_token should update the config."""
        api.set_token("new-token")
        assert api.config.token == "new-token"

    def test_set_token_resets_clients(self, api: AugurAPI) -> None:
        """set_token should reset service clients."""
        # Initialize clients
        _ = api.items
        _ = api.p21_core
        assert api._items is not None
        assert api._p21_core is not None

        # Set new token
        api.set_token("new-token")

        # Clients should be reset
        assert api._items is None
        assert api._p21_core is None

    def test_set_site_id_updates_config(self, api: AugurAPI) -> None:
        """set_site_id should update the config."""
        api.set_site_id("new-site")
        assert api.config.site_id == "new-site"

    def test_set_site_id_resets_clients(self, api: AugurAPI) -> None:
        """set_site_id should reset service clients."""
        # Initialize clients
        _ = api.items
        _ = api.p21_core

        # Set new site ID
        api.set_site_id("new-site")

        # Clients should be reset
        assert api._items is None
        assert api._p21_core is None
