"""Tests for core module components."""

from augur_api.core.config import AugurAPIConfig, AugurContext, ContextCreationError
from augur_api.core.errors import (
    AugurError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from augur_api.core.schemas import BaseResponse, HealthCheckData, PaginationParams


class TestAugurAPIConfig:
    """Tests for AugurAPIConfig."""

    def test_config_with_required_fields(self) -> None:
        """Should create config with required fields."""
        config = AugurAPIConfig(token="test-token", site_id="test-site")
        assert config.token == "test-token"
        assert config.site_id == "test-site"

    def test_config_defaults(self) -> None:
        """Should have sensible defaults."""
        config = AugurAPIConfig(token="test-token", site_id="test-site")
        assert config.timeout == 30.0
        assert config.retries == 3
        assert config.retry_delay == 1.0


class TestAugurContext:
    """Tests for AugurContext."""

    def test_context_with_jwt(self) -> None:
        """Should create context with JWT."""
        context = AugurContext(site_id="test-site", jwt="test-jwt")
        assert context.site_id == "test-site"
        assert context.jwt == "test-jwt"

    def test_context_with_bearer_token(self) -> None:
        """Should create context with bearer token."""
        context = AugurContext(site_id="test-site", bearer_token="test-bearer")
        assert context.bearer_token == "test-bearer"

    def test_context_defaults(self) -> None:
        """Should have empty defaults for optional fields."""
        context = AugurContext(site_id="test-site")
        assert context.jwt is None
        assert context.bearer_token is None
        assert context.parameters == {}
        assert context.filters == {}
        assert context.user_id is None


class TestContextCreationError:
    """Tests for ContextCreationError."""

    def test_error_with_message(self) -> None:
        """Should store message."""
        error = ContextCreationError("Test error")
        assert error.message == "Test error"
        assert error.field is None

    def test_error_with_field(self) -> None:
        """Should store field."""
        error = ContextCreationError("Test error", "test_field")
        assert error.field == "test_field"

    def test_error_str_without_field(self) -> None:
        """String representation without field."""
        error = ContextCreationError("Test error")
        assert str(error) == "Test error"

    def test_error_str_with_field(self) -> None:
        """String representation with field."""
        error = ContextCreationError("Test error", "test_field")
        assert str(error) == "Test error (field: test_field)"


class TestAugurError:
    """Tests for AugurError."""

    def test_error_attributes(self) -> None:
        """Should store all attributes."""
        error = AugurError(
            message="Test error",
            code="TEST_ERROR",
            status_code=500,
            service="test-service",
            endpoint="/test",
            request_id="req-123",
        )
        assert error.message == "Test error"
        assert error.code == "TEST_ERROR"
        assert error.status_code == 500
        assert error.service == "test-service"
        assert error.endpoint == "/test"
        assert error.request_id == "req-123"

    def test_error_str(self) -> None:
        """Should format error string correctly."""
        error = AugurError(
            message="Test error",
            code="TEST_ERROR",
            status_code=500,
            service="test-service",
            endpoint="/test",
        )
        error_str = str(error)
        assert "TEST_ERROR" in error_str
        assert "Test error" in error_str
        assert "test-service" in error_str
        assert "/test" in error_str

    def test_error_str_with_request_id(self) -> None:
        """Should include request ID in string."""
        error = AugurError(
            message="Test error",
            code="TEST_ERROR",
            status_code=500,
            service="test-service",
            endpoint="/test",
            request_id="req-123",
        )
        assert "req-123" in str(error)


class TestValidationError:
    """Tests for ValidationError."""

    def test_validation_error_attributes(self) -> None:
        """Should store validation errors."""
        errors = [{"loc": ["field1"], "msg": "Error 1"}]
        error = ValidationError(
            message="Validation failed",
            service="test-service",
            endpoint="/test",
            validation_errors=errors,
        )
        assert error.code == "VALIDATION_ERROR"
        assert error.status_code == 400
        assert error.validation_errors == errors

    def test_get_formatted_errors(self) -> None:
        """Should format validation errors."""
        errors = [
            {"loc": ["field1"], "msg": "Error 1"},
            {"loc": ["nested", "field2"], "msg": "Error 2"},
        ]
        error = ValidationError(
            message="Validation failed",
            service="test-service",
            endpoint="/test",
            validation_errors=errors,
        )
        formatted = error.get_formatted_errors()
        assert "field1: Error 1" in formatted
        assert "nested.field2: Error 2" in formatted

    def test_get_formatted_errors_empty(self) -> None:
        """Should handle empty validation errors."""
        error = ValidationError(
            message="Validation failed",
            service="test-service",
            endpoint="/test",
            validation_errors=[],
        )
        assert error.get_formatted_errors() == []

    def test_validation_error_str(self) -> None:
        """Should include validation details in string."""
        errors = [{"loc": ["field1"], "msg": "Error 1"}]
        error = ValidationError(
            message="Validation failed",
            service="test-service",
            endpoint="/test",
            validation_errors=errors,
        )
        error_str = str(error)
        assert "field1: Error 1" in error_str

    def test_validation_error_str_no_errors(self) -> None:
        """Should return base string when no validation errors."""
        error = ValidationError(
            message="Validation failed",
            service="test-service",
            endpoint="/test",
            validation_errors=[],
        )
        error_str = str(error)
        # Should not contain "Validation errors:" section
        assert "Validation errors:" not in error_str
        assert "Validation failed" in error_str


class TestAuthenticationError:
    """Tests for AuthenticationError."""

    def test_authentication_error_attributes(self) -> None:
        """Should have correct code and status."""
        error = AuthenticationError(
            message="Auth failed",
            service="test-service",
            endpoint="/test",
        )
        assert error.code == "AUTHENTICATION_ERROR"
        assert error.status_code == 401


class TestNotFoundError:
    """Tests for NotFoundError."""

    def test_not_found_error_attributes(self) -> None:
        """Should have correct code and status."""
        error = NotFoundError(
            message="Not found",
            service="test-service",
            endpoint="/test",
        )
        assert error.code == "NOT_FOUND"
        assert error.status_code == 404


class TestRateLimitError:
    """Tests for RateLimitError."""

    def test_rate_limit_error_attributes(self) -> None:
        """Should have correct code and status."""
        error = RateLimitError(
            message="Rate limited",
            service="test-service",
            endpoint="/test",
        )
        assert error.code == "RATE_LIMIT_EXCEEDED"
        assert error.status_code == 429


class TestBaseResponse:
    """Tests for BaseResponse schema."""

    def test_base_response_parsing(self, mock_health_check_response: dict) -> None:
        """Should parse valid response."""
        response = BaseResponse[HealthCheckData].model_validate(mock_health_check_response)
        assert response.count == 1
        assert response.status == 200
        assert response.data.site_id == "test-site"

    def test_base_response_extra_fields(self) -> None:
        """Should allow extra fields."""
        data = {
            "count": 1,
            "data": {"site_hash": "abc", "site_id": "test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
            "extra_field": "should be allowed",
        }
        response = BaseResponse[HealthCheckData].model_validate(data)
        assert response.count == 1


class TestHealthCheckData:
    """Tests for HealthCheckData schema."""

    def test_health_check_data_parsing(self) -> None:
        """Should parse valid health check data."""
        data = {"site_hash": "abc123", "site_id": "test-site"}
        health = HealthCheckData.model_validate(data)
        assert health.site_hash == "abc123"
        assert health.site_id == "test-site"


class TestPaginationParams:
    """Tests for PaginationParams schema."""

    def test_pagination_params_defaults(self) -> None:
        """Should have None defaults."""
        params = PaginationParams()
        assert params.limit is None
        assert params.offset is None

    def test_pagination_params_with_values(self) -> None:
        """Should accept limit and offset."""
        params = PaginationParams(limit=10, offset=20)
        assert params.limit == 10
        assert params.offset == 20
