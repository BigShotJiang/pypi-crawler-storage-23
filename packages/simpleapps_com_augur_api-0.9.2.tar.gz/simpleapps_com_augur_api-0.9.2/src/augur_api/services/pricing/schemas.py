"""Schemas for the Pricing service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Ping
class PingResponse(CamelCaseModel):
    """Ping response data."""

    pong: bool | None = None
    timestamp: str | None = None


# Price Engine
class PriceEngineParams(EdgeCacheParams):
    """Parameters for price engine lookup."""

    customer_id: int
    item_id: str
    quantity: float | None = None
    ship_to_id: int | None = None
    unit_of_measure: str | None = None
    company_id: str | None = None
    cache_ttl: int | None = None
    cache_site_id: str | None = None


class PriceEngineResult(CamelCaseModel):
    """Price engine result."""

    customer_id: int | None = None
    item_id: str | None = None
    quantity: float | None = None
    unit_price: float | None = None
    base_price: float | None = None
    extended_price: float | None = None
    discount_percent: float | None = None
    discount_amount: float | None = None
    price_source: str | None = None
    price_method: str | None = None
    unit_of_measure: str | None = None
    conversion_factor: float | None = None


# Tax Engine
class TaxEngineItem(BaseModel):
    """Tax engine line item."""

    item_id: str
    quantity: float
    unit_price: float
    extended_amount: float


class TaxEngineAddress(BaseModel):
    """Tax engine address."""

    street: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str


class TaxEngineRequest(BaseModel):
    """Tax engine calculation request."""

    customer_id: int
    postal_code: str
    items: list[TaxEngineItem]
    ship_to_address: TaxEngineAddress | None = None


class TaxJurisdiction(CamelCaseModel):
    """Tax jurisdiction breakdown."""

    jurisdiction_name: str | None = None
    jurisdiction_type: str | None = None
    tax_rate: float | None = None
    tax_amount: float | None = None


class TaxEngineResult(CamelCaseModel):
    """Tax engine calculation result."""

    total_tax: float | None = None
    total_rate: float | None = None
    taxable_amount: float | None = None
    jurisdictions: list[TaxJurisdiction] | None = None


# Job Price Header
class JobPriceHdrListParams(EdgeCacheParams):
    """Parameters for listing job price headers."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


class JobPriceHdr(CamelCaseModel):
    """Job price header entity."""

    job_price_hdr_uid: int | None = None
    customer_id: int | None = None
    job_name: str | None = None
    description: str | None = None
    start_date: str | None = None
    end_date: str | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


# Job Price Lines
class JobPriceLinesParams(EdgeCacheParams):
    """Parameters for listing job price lines."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    status_cd: int | None = None
    inv_mast_uid: int | None = None


class JobPriceLine(CamelCaseModel):
    """Job price line entity."""

    job_price_line_uid: int | None = None
    job_price_hdr_uid: int | None = None
    inv_mast_uid: int | None = None
    item_id: str | None = None
    unit_price: float | None = None
    quantity: float | None = None
    unit_of_measure: str | None = None
    status_cd: int | None = None
