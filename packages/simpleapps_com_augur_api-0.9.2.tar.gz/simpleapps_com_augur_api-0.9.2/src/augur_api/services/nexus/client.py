"""Nexus service client for warehouse operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.nexus.schemas import (
    BinTransfer,
    BinTransferListParams,
    BinTransferUpdateParams,
    PurchaseOrderReceipt,
    PurchaseOrderReceiptListParams,
    PurchaseOrderReceiptUpdateParams,
    Receiving,
    ReceivingListParams,
    Transfer,
    TransferListParams,
    TransferReceipt,
    TransferReceiptListParams,
    TransferReceiptUpdateParams,
    TransferShipping,
    TransferShippingListParams,
    TransferShippingUpdateParams,
    User,
    UserListParams,
)
from augur_api.services.resource import BaseResource


class BinTransferResource(BaseResource):
    """Resource for /bin-transfer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/bin-transfer")

    def list(self, params: BinTransferListParams | None = None) -> BaseResponse[list[BinTransfer]]:
        """List bin transfers.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of BinTransfer items.
        """
        response = self._get(params=params)
        return BaseResponse[list[BinTransfer]].model_validate(response)

    def get(self, bin_transfer_hdr_uid: int) -> BaseResponse[BinTransfer]:
        """Get bin transfer by UID.

        Args:
            bin_transfer_hdr_uid: The bin transfer header UID.

        Returns:
            BaseResponse containing the BinTransfer.
        """
        response = self._get(f"/{bin_transfer_hdr_uid}")
        return BaseResponse[BinTransfer].model_validate(response)

    def create(self, data: Any) -> BaseResponse[BinTransfer]:
        """Create a new bin transfer.

        Args:
            data: The bin transfer data to create.

        Returns:
            BaseResponse containing the created BinTransfer.
        """
        response = self._post(data=data)
        return BaseResponse[BinTransfer].model_validate(response)

    def update(
        self, bin_transfer_hdr_uid: int, data: BinTransferUpdateParams
    ) -> BaseResponse[BinTransfer]:
        """Update an existing bin transfer.

        Args:
            bin_transfer_hdr_uid: The bin transfer header UID.
            data: The bin transfer data to update.

        Returns:
            BaseResponse containing the updated BinTransfer.
        """
        response = self._put(f"/{bin_transfer_hdr_uid}", data=data)
        return BaseResponse[BinTransfer].model_validate(response)

    def delete(self, bin_transfer_hdr_uid: int) -> BaseResponse[BinTransfer]:
        """Delete a bin transfer.

        Args:
            bin_transfer_hdr_uid: The bin transfer header UID.

        Returns:
            BaseResponse containing the deleted BinTransfer.
        """
        response = self._delete(f"/{bin_transfer_hdr_uid}")
        return BaseResponse[BinTransfer].model_validate(response)

    def status(self, bin_transfer_hdr_uid: int) -> BaseResponse[BinTransfer]:
        """Get bin transfer status.

        Args:
            bin_transfer_hdr_uid: The bin transfer header UID.

        Returns:
            BaseResponse containing the bin transfer status.
        """
        response = self._get(f"/{bin_transfer_hdr_uid}/status")
        return BaseResponse[BinTransfer].model_validate(response)


class UsersResource(BaseResource):
    """Resource for /users endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/users")

    def list(self, params: UserListParams | None = None) -> BaseResponse[list[User]]:
        """List users.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of User items.
        """
        response = self._get(params=params)
        return BaseResponse[list[User]].model_validate(response)

    def get(self, users_uid: int) -> BaseResponse[User]:
        """Get user by UID.

        Args:
            users_uid: The user UID.

        Returns:
            BaseResponse containing the User.
        """
        response = self._get(f"/{users_uid}")
        return BaseResponse[User].model_validate(response)


class ReceivingResource(BaseResource):
    """Resource for /receiving endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/receiving")

    def list(self, params: ReceivingListParams | None = None) -> BaseResponse[list[Receiving]]:
        """List receiving records.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Receiving items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Receiving]].model_validate(response)

    def get(self, receiving_uid: int) -> BaseResponse[Receiving]:
        """Get receiving record by UID.

        Args:
            receiving_uid: The receiving UID.

        Returns:
            BaseResponse containing the Receiving record.
        """
        response = self._get(f"/{receiving_uid}")
        return BaseResponse[Receiving].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Receiving]:
        """Create a new receiving record.

        Args:
            data: The receiving data to create.

        Returns:
            BaseResponse containing the created Receiving record.
        """
        response = self._post(data=data)
        return BaseResponse[Receiving].model_validate(response)

    def update(self, receiving_uid: int, data: Any) -> BaseResponse[Receiving]:
        """Update an existing receiving record.

        Args:
            receiving_uid: The receiving UID.
            data: The receiving data to update.

        Returns:
            BaseResponse containing the updated Receiving record.
        """
        response = self._put(f"/{receiving_uid}", data=data)
        return BaseResponse[Receiving].model_validate(response)

    def delete(self, receiving_uid: int) -> BaseResponse[Receiving]:
        """Delete a receiving record.

        Args:
            receiving_uid: The receiving UID.

        Returns:
            BaseResponse containing the deleted Receiving record.
        """
        response = self._delete(f"/{receiving_uid}")
        return BaseResponse[Receiving].model_validate(response)


class TransferResource(BaseResource):
    """Resource for /transfer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/transfer")

    def list(self, params: TransferListParams | None = None) -> BaseResponse[list[Transfer]]:
        """List transfers.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Transfer items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Transfer]].model_validate(response)

    def get(self, transfer_uid: int) -> BaseResponse[Transfer]:
        """Get transfer by UID.

        Args:
            transfer_uid: The transfer UID.

        Returns:
            BaseResponse containing the Transfer.
        """
        response = self._get(f"/{transfer_uid}")
        return BaseResponse[Transfer].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Transfer]:
        """Create a new transfer.

        Args:
            data: The transfer data to create.

        Returns:
            BaseResponse containing the created Transfer.
        """
        response = self._post(data=data)
        return BaseResponse[Transfer].model_validate(response)

    def update(self, transfer_uid: int, data: Any) -> BaseResponse[Transfer]:
        """Update an existing transfer.

        Args:
            transfer_uid: The transfer UID.
            data: The transfer data to update.

        Returns:
            BaseResponse containing the updated Transfer.
        """
        response = self._put(f"/{transfer_uid}", data=data)
        return BaseResponse[Transfer].model_validate(response)

    def delete(self, transfer_uid: int) -> BaseResponse[Transfer]:
        """Delete a transfer.

        Args:
            transfer_uid: The transfer UID.

        Returns:
            BaseResponse containing the deleted Transfer.
        """
        response = self._delete(f"/{transfer_uid}")
        return BaseResponse[Transfer].model_validate(response)


class PurchaseOrderReceiptResource(BaseResource):
    """Resource for /purchase-order-receipt endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/purchase-order-receipt")

    def list(
        self, params: PurchaseOrderReceiptListParams | None = None
    ) -> BaseResponse[list[PurchaseOrderReceipt]]:
        """List purchase order receipts.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of PurchaseOrderReceipt items.
        """
        response = self._get(params=params)
        return BaseResponse[list[PurchaseOrderReceipt]].model_validate(response)

    def get(self, purchase_order_receipt_uid: int) -> BaseResponse[PurchaseOrderReceipt]:
        """Get purchase order receipt by UID.

        Args:
            purchase_order_receipt_uid: The purchase order receipt UID.

        Returns:
            BaseResponse containing the PurchaseOrderReceipt.
        """
        response = self._get(f"/{purchase_order_receipt_uid}")
        return BaseResponse[PurchaseOrderReceipt].model_validate(response)

    def create(self, data: Any) -> BaseResponse[PurchaseOrderReceipt]:
        """Create a new purchase order receipt.

        Args:
            data: The purchase order receipt data to create.

        Returns:
            BaseResponse containing the created PurchaseOrderReceipt.
        """
        response = self._post(data=data)
        return BaseResponse[PurchaseOrderReceipt].model_validate(response)

    def update(
        self, purchase_order_receipt_uid: int, data: PurchaseOrderReceiptUpdateParams
    ) -> BaseResponse[PurchaseOrderReceipt]:
        """Update an existing purchase order receipt.

        Args:
            purchase_order_receipt_uid: The purchase order receipt UID.
            data: The purchase order receipt data to update.

        Returns:
            BaseResponse containing the updated PurchaseOrderReceipt.
        """
        response = self._put(f"/{purchase_order_receipt_uid}", data=data)
        return BaseResponse[PurchaseOrderReceipt].model_validate(response)

    def delete(self, purchase_order_receipt_uid: int) -> BaseResponse[PurchaseOrderReceipt]:
        """Delete a purchase order receipt.

        Args:
            purchase_order_receipt_uid: The purchase order receipt UID.

        Returns:
            BaseResponse containing the deleted PurchaseOrderReceipt.
        """
        response = self._delete(f"/{purchase_order_receipt_uid}")
        return BaseResponse[PurchaseOrderReceipt].model_validate(response)


class TransferReceiptResource(BaseResource):
    """Resource for /transfer-receipt endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/transfer-receipt")

    def list(
        self, params: TransferReceiptListParams | None = None
    ) -> BaseResponse[list[TransferReceipt]]:
        """List transfer receipts.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of TransferReceipt items.
        """
        response = self._get(params=params)
        return BaseResponse[list[TransferReceipt]].model_validate(response)

    def get(self, transfer_receipt_uid: int) -> BaseResponse[TransferReceipt]:
        """Get transfer receipt by UID.

        Args:
            transfer_receipt_uid: The transfer receipt UID.

        Returns:
            BaseResponse containing the TransferReceipt.
        """
        response = self._get(f"/{transfer_receipt_uid}")
        return BaseResponse[TransferReceipt].model_validate(response)

    def create(self, data: Any) -> BaseResponse[TransferReceipt]:
        """Create a new transfer receipt.

        Args:
            data: The transfer receipt data to create.

        Returns:
            BaseResponse containing the created TransferReceipt.
        """
        response = self._post(data=data)
        return BaseResponse[TransferReceipt].model_validate(response)

    def update(
        self, transfer_receipt_uid: int, data: TransferReceiptUpdateParams
    ) -> BaseResponse[TransferReceipt]:
        """Update an existing transfer receipt.

        Args:
            transfer_receipt_uid: The transfer receipt UID.
            data: The transfer receipt data to update.

        Returns:
            BaseResponse containing the updated TransferReceipt.
        """
        response = self._put(f"/{transfer_receipt_uid}", data=data)
        return BaseResponse[TransferReceipt].model_validate(response)

    def delete(self, transfer_receipt_uid: int) -> BaseResponse[TransferReceipt]:
        """Delete a transfer receipt.

        Args:
            transfer_receipt_uid: The transfer receipt UID.

        Returns:
            BaseResponse containing the deleted TransferReceipt.
        """
        response = self._delete(f"/{transfer_receipt_uid}")
        return BaseResponse[TransferReceipt].model_validate(response)


class TransferShippingResource(BaseResource):
    """Resource for /transfer-shipping endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/transfer-shipping")

    def list(
        self, params: TransferShippingListParams | None = None
    ) -> BaseResponse[list[TransferShipping]]:
        """List transfer shipping documents.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of TransferShipping items.
        """
        response = self._get(params=params)
        return BaseResponse[list[TransferShipping]].model_validate(response)

    def get(self, transfer_receipt_uid: int) -> BaseResponse[TransferShipping]:
        """Get transfer shipping document by UID.

        Args:
            transfer_receipt_uid: The transfer receipt UID.

        Returns:
            BaseResponse containing the TransferShipping.
        """
        response = self._get(f"/{transfer_receipt_uid}")
        return BaseResponse[TransferShipping].model_validate(response)

    def create(self, data: Any) -> BaseResponse[TransferShipping]:
        """Create a new transfer shipping document.

        Args:
            data: The transfer shipping data to create.

        Returns:
            BaseResponse containing the created TransferShipping.
        """
        response = self._post(data=data)
        return BaseResponse[TransferShipping].model_validate(response)

    def update(
        self, transfer_receipt_uid: int, data: TransferShippingUpdateParams
    ) -> BaseResponse[TransferShipping]:
        """Update an existing transfer shipping document.

        Args:
            transfer_receipt_uid: The transfer receipt UID.
            data: The transfer shipping data to update.

        Returns:
            BaseResponse containing the updated TransferShipping.
        """
        response = self._put(f"/{transfer_receipt_uid}", data=data)
        return BaseResponse[TransferShipping].model_validate(response)

    def delete(self, transfer_receipt_uid: int) -> BaseResponse[TransferShipping]:
        """Delete a transfer shipping document.

        Args:
            transfer_receipt_uid: The transfer receipt UID.

        Returns:
            BaseResponse containing the deleted TransferShipping.
        """
        response = self._delete(f"/{transfer_receipt_uid}")
        return BaseResponse[TransferShipping].model_validate(response)


class NexusClient(BaseServiceClient):
    """Client for the Nexus warehouse service.

    Provides access to warehouse operation endpoints including:
    - Health check (health_check)
    - Bin transfers (bin_transfer)
    - Users (users)
    - Receiving (receiving)
    - Transfer (transfer)
    - Purchase order receipt (purchase_order_receipt)
    - Transfer receipt (transfer_receipt)
    - Transfer shipping (transfer_shipping)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> transfers = api.nexus.bin_transfer.list()
        >>> for transfer in transfers.data:
        ...     print(transfer.bin_transfer_hdr_uid)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Nexus client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._bin_transfer: BinTransferResource | None = None
        self._users: UsersResource | None = None
        self._receiving: ReceivingResource | None = None
        self._transfer: TransferResource | None = None
        self._purchase_order_receipt: PurchaseOrderReceiptResource | None = None
        self._transfer_receipt: TransferReceiptResource | None = None
        self._transfer_shipping: TransferShippingResource | None = None

    @property
    def bin_transfer(self) -> BinTransferResource:
        """Access bin transfer endpoints."""
        if self._bin_transfer is None:
            self._bin_transfer = BinTransferResource(self._http)
        return self._bin_transfer

    @property
    def users(self) -> UsersResource:
        """Access users endpoints."""
        if self._users is None:
            self._users = UsersResource(self._http)
        return self._users

    @property
    def receiving(self) -> ReceivingResource:
        """Access receiving endpoints."""
        if self._receiving is None:
            self._receiving = ReceivingResource(self._http)
        return self._receiving

    @property
    def transfer(self) -> TransferResource:
        """Access transfer endpoints."""
        if self._transfer is None:
            self._transfer = TransferResource(self._http)
        return self._transfer

    @property
    def purchase_order_receipt(self) -> PurchaseOrderReceiptResource:
        """Access purchase order receipt endpoints."""
        if self._purchase_order_receipt is None:
            self._purchase_order_receipt = PurchaseOrderReceiptResource(self._http)
        return self._purchase_order_receipt

    @property
    def transfer_receipt(self) -> TransferReceiptResource:
        """Access transfer receipt endpoints."""
        if self._transfer_receipt is None:
            self._transfer_receipt = TransferReceiptResource(self._http)
        return self._transfer_receipt

    @property
    def transfer_shipping(self) -> TransferShippingResource:
        """Access transfer shipping endpoints."""
        if self._transfer_shipping is None:
            self._transfer_shipping = TransferShippingResource(self._http)
        return self._transfer_shipping
