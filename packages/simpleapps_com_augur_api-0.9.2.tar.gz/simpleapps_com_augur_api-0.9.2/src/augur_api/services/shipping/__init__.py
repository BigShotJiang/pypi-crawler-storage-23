"""Shipping service exports."""

from augur_api.services.shipping.client import (
    RatesResource,
    ShippingClient,
)
from augur_api.services.shipping.schemas import (
    RateQuote,
    RatesParams,
)

__all__ = [
    "RateQuote",
    "RatesParams",
    "RatesResource",
    "ShippingClient",
]
