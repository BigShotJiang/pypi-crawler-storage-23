"""Payments service client for payment processing."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.payments.schemas import (
    AccountQueryData,
    AccountQueryParams,
    BillingUpdateParams,
    CardInfoData,
    CardInfoParams,
    ElementPaymentResponse,
    MonerisData,
    PaytraceResponse,
    PreAuthCompleteParams,
    PreAuthParams,
    SurchargeData,
    SurchargeParams,
    TransactionSetupData,
    TransactionSetupParams,
    ValidateParams,
)
from augur_api.services.resource import BaseResource


class ElementPaymentResource(BaseResource):
    """Resource for /element/payment endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/element/payment")

    def create(self, data: Any = None) -> BaseResponse[ElementPaymentResponse]:
        """Process an Element payment.

        Args:
            data: Payment data (passthrough).

        Returns:
            BaseResponse containing payment result.
        """
        response = self._post(data=data)
        return BaseResponse[ElementPaymentResponse].model_validate(response)


class ElementResource(BaseResource):
    """Resource for /element endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/element")
        self._payment: ElementPaymentResource | None = None

    @property
    def payment(self) -> ElementPaymentResource:
        """Access payment endpoint."""
        if self._payment is None:
            self._payment = ElementPaymentResource(self._http)
        return self._payment


class PreAuthResource(BaseResource):
    """Resource for /moneris/pre-auth endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/moneris/pre-auth")

    def get(self, params: PreAuthParams) -> BaseResponse[MonerisData]:
        """Execute Moneris pre-authorization.

        Args:
            params: Pre-auth parameters including amount, card number, etc.

        Returns:
            BaseResponse containing pre-auth result.
        """
        response = self._get(params=params)
        return BaseResponse[MonerisData].model_validate(response)


class PreAuthCompleteResource(BaseResource):
    """Resource for /moneris/pre-auth-complete endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/moneris/pre-auth-complete")

    def get(self, params: PreAuthCompleteParams) -> BaseResponse[MonerisData]:
        """Complete a Moneris pre-authorization.

        Args:
            params: Pre-auth completion parameters.

        Returns:
            BaseResponse containing completion result.
        """
        response = self._get(params=params)
        return BaseResponse[MonerisData].model_validate(response)


class MonerisResource(BaseResource):
    """Resource for /moneris endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/moneris")
        self._pre_auth: PreAuthResource | None = None
        self._pre_auth_complete: PreAuthCompleteResource | None = None

    @property
    def pre_auth(self) -> PreAuthResource:
        """Access pre-auth endpoint."""
        if self._pre_auth is None:
            self._pre_auth = PreAuthResource(self._http)
        return self._pre_auth

    @property
    def pre_auth_complete(self) -> PreAuthCompleteResource:
        """Access pre-auth-complete endpoint."""
        if self._pre_auth_complete is None:
            self._pre_auth_complete = PreAuthCompleteResource(self._http)
        return self._pre_auth_complete


class PaytraceAuthorizationResource(BaseResource):
    """Resource for /paytrace/authorization endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/paytrace/authorization")

    def create(self, data: Any = None) -> BaseResponse[PaytraceResponse]:
        """Create a Paytrace authorization.

        Args:
            data: Authorization data (passthrough).

        Returns:
            BaseResponse containing authorization result.
        """
        response = self._post(data=data)
        return BaseResponse[PaytraceResponse].model_validate(response)


class PaytraceCaptureResource(BaseResource):
    """Resource for /paytrace/capture endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/paytrace/capture")

    def create(self, data: Any = None) -> BaseResponse[PaytraceResponse]:
        """Capture a Paytrace transaction.

        Args:
            data: Capture data (passthrough).

        Returns:
            BaseResponse containing capture result.
        """
        response = self._post(data=data)
        return BaseResponse[PaytraceResponse].model_validate(response)


class PaytraceRefundResource(BaseResource):
    """Resource for /paytrace/refund endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/paytrace/refund")

    def create(self, data: Any = None) -> BaseResponse[PaytraceResponse]:
        """Process a Paytrace refund.

        Args:
            data: Refund data (passthrough).

        Returns:
            BaseResponse containing refund result.
        """
        response = self._post(data=data)
        return BaseResponse[PaytraceResponse].model_validate(response)


class PaytraceSaleResource(BaseResource):
    """Resource for /paytrace/sale endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/paytrace/sale")

    def create(self, data: Any = None) -> BaseResponse[PaytraceResponse]:
        """Process a Paytrace sale.

        Args:
            data: Sale data (passthrough).

        Returns:
            BaseResponse containing sale result.
        """
        response = self._post(data=data)
        return BaseResponse[PaytraceResponse].model_validate(response)


class PaytraceVoidResource(BaseResource):
    """Resource for /paytrace/void endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/paytrace/void")

    def create(self, data: Any = None) -> BaseResponse[PaytraceResponse]:
        """Void a Paytrace transaction.

        Args:
            data: Void data (passthrough).

        Returns:
            BaseResponse containing void result.
        """
        response = self._post(data=data)
        return BaseResponse[PaytraceResponse].model_validate(response)


class PaytraceResource(BaseResource):
    """Resource for /paytrace endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/paytrace")
        self._authorization: PaytraceAuthorizationResource | None = None
        self._capture: PaytraceCaptureResource | None = None
        self._refund: PaytraceRefundResource | None = None
        self._sale: PaytraceSaleResource | None = None
        self._void: PaytraceVoidResource | None = None

    @property
    def authorization(self) -> PaytraceAuthorizationResource:
        """Access authorization endpoint."""
        if self._authorization is None:
            self._authorization = PaytraceAuthorizationResource(self._http)
        return self._authorization

    @property
    def capture(self) -> PaytraceCaptureResource:
        """Access capture endpoint."""
        if self._capture is None:
            self._capture = PaytraceCaptureResource(self._http)
        return self._capture

    @property
    def refund(self) -> PaytraceRefundResource:
        """Access refund endpoint."""
        if self._refund is None:
            self._refund = PaytraceRefundResource(self._http)
        return self._refund

    @property
    def sale(self) -> PaytraceSaleResource:
        """Access sale endpoint."""
        if self._sale is None:
            self._sale = PaytraceSaleResource(self._http)
        return self._sale

    @property
    def void(self) -> PaytraceVoidResource:
        """Access void endpoint."""
        if self._void is None:
            self._void = PaytraceVoidResource(self._http)
        return self._void


class TransactionSetupResource(BaseResource):
    """Resource for /unified/transaction-setup endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/unified/transaction-setup")

    def get(self, params: TransactionSetupParams) -> BaseResponse[TransactionSetupData]:
        """Initialize a transaction setup for payment processing.

        Args:
            params: Transaction setup parameters.

        Returns:
            BaseResponse containing transaction setup ID.
        """
        response = self._get(params=params)
        return BaseResponse[TransactionSetupData].model_validate(response)


class AccountQueryResource(BaseResource):
    """Resource for /unified/account-query endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/unified/account-query")

    def get(self, params: AccountQueryParams) -> BaseResponse[AccountQueryData | bool]:
        """Query available payment accounts for a customer.

        Args:
            params: Account query parameters.

        Returns:
            BaseResponse containing payment account data or False.
        """
        response = self._get(params=params)
        return BaseResponse[AccountQueryData | bool].model_validate(response)


class BillingUpdateResource(BaseResource):
    """Resource for /unified/billing-update endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/unified/billing-update")

    def get(self, params: BillingUpdateParams) -> BaseResponse[bool]:
        """Update billing information.

        Args:
            params: Billing update parameters.

        Returns:
            BaseResponse containing success status.
        """
        response = self._get(params=params)
        return BaseResponse[bool].model_validate(response)


class CardInfoResource(BaseResource):
    """Resource for /unified/card-info endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/unified/card-info")

    def get(self, params: CardInfoParams) -> BaseResponse[CardInfoData | dict[str, Any]]:
        """Get card information.

        Args:
            params: Card info parameters.

        Returns:
            BaseResponse containing card info or empty dict.
        """
        response = self._get(params=params)
        return BaseResponse[CardInfoData | dict[str, Any]].model_validate(response)


class SurchargeResource(BaseResource):
    """Resource for /unified/surcharge endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/unified/surcharge")

    def get(self, params: SurchargeParams) -> BaseResponse[SurchargeData | dict[str, Any]]:
        """Calculate surcharge for a payment.

        Args:
            params: Surcharge calculation parameters.

        Returns:
            BaseResponse containing surcharge information or empty dict.
        """
        response = self._get(params=params)
        return BaseResponse[SurchargeData | dict[str, Any]].model_validate(response)


class ValidateResource(BaseResource):
    """Resource for /unified/validate endpoint."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/unified/validate")

    def get(self, params: ValidateParams) -> BaseResponse[bool]:
        """Validate a transaction.

        Args:
            params: Validation parameters.

        Returns:
            BaseResponse containing validation result.
        """
        response = self._get(params=params)
        return BaseResponse[bool].model_validate(response)


class UnifiedResource(BaseResource):
    """Resource for /unified endpoints (unified payment processing)."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/unified")
        self._transaction_setup: TransactionSetupResource | None = None
        self._account_query: AccountQueryResource | None = None
        self._billing_update: BillingUpdateResource | None = None
        self._card_info: CardInfoResource | None = None
        self._surcharge: SurchargeResource | None = None
        self._validate: ValidateResource | None = None

    @property
    def transaction_setup(self) -> TransactionSetupResource:
        """Access transaction setup endpoint."""
        if self._transaction_setup is None:
            self._transaction_setup = TransactionSetupResource(self._http)
        return self._transaction_setup

    @property
    def account_query(self) -> AccountQueryResource:
        """Access account query endpoint."""
        if self._account_query is None:
            self._account_query = AccountQueryResource(self._http)
        return self._account_query

    @property
    def billing_update(self) -> BillingUpdateResource:
        """Access billing update endpoint."""
        if self._billing_update is None:
            self._billing_update = BillingUpdateResource(self._http)
        return self._billing_update

    @property
    def card_info(self) -> CardInfoResource:
        """Access card info endpoint."""
        if self._card_info is None:
            self._card_info = CardInfoResource(self._http)
        return self._card_info

    @property
    def surcharge(self) -> SurchargeResource:
        """Access surcharge endpoint."""
        if self._surcharge is None:
            self._surcharge = SurchargeResource(self._http)
        return self._surcharge

    @property
    def validate(self) -> ValidateResource:
        """Access validate endpoint."""
        if self._validate is None:
            self._validate = ValidateResource(self._http)
        return self._validate


class PaymentsClient(BaseServiceClient):
    """Client for the Payments service.

    Provides access to payment processing endpoints including:
    - Health check (health_check)
    - Element payments (element)
    - Moneris payments (moneris)
    - Paytrace payments (paytrace)
    - Unified payment processing (unified)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> setup = api.payments.unified.transaction_setup.get(
        ...     TransactionSetupParams(customer_id="123")
        ... )
        >>> print(setup.data.transaction_setup_id)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Payments client."""
        super().__init__(http_client)
        self._element: ElementResource | None = None
        self._moneris: MonerisResource | None = None
        self._paytrace: PaytraceResource | None = None
        self._unified: UnifiedResource | None = None

    @property
    def element(self) -> ElementResource:
        """Access Element payment endpoints."""
        if self._element is None:
            self._element = ElementResource(self._http)
        return self._element

    @property
    def moneris(self) -> MonerisResource:
        """Access Moneris payment endpoints."""
        if self._moneris is None:
            self._moneris = MonerisResource(self._http)
        return self._moneris

    @property
    def paytrace(self) -> PaytraceResource:
        """Access Paytrace payment endpoints."""
        if self._paytrace is None:
            self._paytrace = PaytraceResource(self._http)
        return self._paytrace

    @property
    def unified(self) -> UnifiedResource:
        """Access unified payment processing endpoints."""
        if self._unified is None:
            self._unified = UnifiedResource(self._http)
        return self._unified
