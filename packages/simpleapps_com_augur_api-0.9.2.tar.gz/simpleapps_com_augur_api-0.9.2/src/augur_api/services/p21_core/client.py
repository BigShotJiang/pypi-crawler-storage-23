"""P21 Core service client for Prophet 21 core data."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.p21_core.schemas import (
    Address,
    AddressListParams,
    Branch,
    BranchListParams,
    CashDrawer,
    CashDrawerListParams,
    CodeP21,
    CodeP21ListParams,
    Company,
    CompanyListParams,
    Location,
    LocationListParams,
    PaymentType,
    PaymentTypesListParams,
)
from augur_api.services.resource import BaseResource


class AddressResource(BaseResource):
    """Resource for /address endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/address")

    def list(self, params: AddressListParams | None = None) -> BaseResponse[list[Address]]:
        """List addresses.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Address items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Address]].model_validate(response)

    def get(self, address_id: int) -> BaseResponse[Address]:
        """Get address by ID.

        Args:
            address_id: The address ID.

        Returns:
            BaseResponse containing the Address.
        """
        response = self._get(f"/{address_id}")
        return BaseResponse[Address].model_validate(response)

    def refresh(self) -> BaseResponse[bool]:
        """Trigger an address data refresh.

        Returns:
            BaseResponse containing the refresh result.
        """
        response = self._get("/refresh")
        return BaseResponse[bool].model_validate(response)

    def corp_address(self, address_id: int) -> BaseResponse[Address]:
        """Get corporate address for an address ID.

        Args:
            address_id: The address ID.

        Returns:
            BaseResponse containing the corporate Address.
        """
        response = self._get(f"/{address_id}/corp-address")
        return BaseResponse[Address].model_validate(response)

    def default(self, address_id: int) -> BaseResponse[Address]:
        """Get default address for an address ID.

        Args:
            address_id: The address ID.

        Returns:
            BaseResponse containing the default Address.
        """
        response = self._get(f"/{address_id}/default")
        return BaseResponse[Address].model_validate(response)

    def enable(self, address_id: int) -> BaseResponse[Address]:
        """Get enabled status for an address.

        Args:
            address_id: The address ID.

        Returns:
            BaseResponse containing the Address with enable status.
        """
        response = self._get(f"/{address_id}/enable")
        return BaseResponse[Address].model_validate(response)


class BranchResource(BaseResource):
    """Resource for /branch endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/branch")

    def list(self, params: BranchListParams | None = None) -> BaseResponse[list[Branch]]:
        """List branches.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Branch items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Branch]].model_validate(response)

    def get(self, branch_id: str) -> BaseResponse[Branch]:
        """Get branch by ID.

        Args:
            branch_id: The branch ID.

        Returns:
            BaseResponse containing the Branch.
        """
        response = self._get(f"/{branch_id}")
        return BaseResponse[Branch].model_validate(response)


class CashDrawerResource(BaseResource):
    """Resource for /cash-drawer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/cash-drawer")

    def list(self, params: CashDrawerListParams | None = None) -> BaseResponse[list[CashDrawer]]:
        """List cash drawers.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of CashDrawer items.
        """
        response = self._get(params=params)
        return BaseResponse[list[CashDrawer]].model_validate(response)

    def get(self, cash_drawer_id: int) -> BaseResponse[CashDrawer]:
        """Get cash drawer by ID.

        Args:
            cash_drawer_id: The cash drawer ID.

        Returns:
            BaseResponse containing the CashDrawer.
        """
        response = self._get(f"/{cash_drawer_id}")
        return BaseResponse[CashDrawer].model_validate(response)


class CompanyResource(BaseResource):
    """Resource for /company endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/company")

    def list(self, params: CompanyListParams | None = None) -> BaseResponse[list[Company]]:
        """List companies.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Company items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Company]].model_validate(response)

    def get(self, company_id: str) -> BaseResponse[Company]:
        """Get company by ID.

        Args:
            company_id: The company ID.

        Returns:
            BaseResponse containing the Company.
        """
        response = self._get(f"/{company_id}")
        return BaseResponse[Company].model_validate(response)


class LocationResource(BaseResource):
    """Resource for /location endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/location")

    def list(self, params: LocationListParams | None = None) -> BaseResponse[list[Location]]:
        """List locations.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Location items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Location]].model_validate(response)

    def get(self, location_id: int) -> BaseResponse[Location]:
        """Get location by ID.

        Args:
            location_id: The location ID.

        Returns:
            BaseResponse containing the Location.
        """
        response = self._get(f"/{location_id}")
        return BaseResponse[Location].model_validate(response)


class CashDrawerUnderscoreResource(BaseResource):
    """Resource for /cash_drawer endpoints (underscore variant)."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/cash_drawer")

    def list(self, params: CashDrawerListParams | None = None) -> BaseResponse[list[CashDrawer]]:
        """List cash drawers.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of CashDrawer items.
        """
        response = self._get(params=params)
        return BaseResponse[list[CashDrawer]].model_validate(response)

    def get(self, cash_drawer_uid: int) -> BaseResponse[CashDrawer]:
        """Get cash drawer by UID.

        Args:
            cash_drawer_uid: The cash drawer UID.

        Returns:
            BaseResponse containing the CashDrawer.
        """
        response = self._get(f"/{cash_drawer_uid}")
        return BaseResponse[CashDrawer].model_validate(response)


class CodeP21Resource(BaseResource):
    """Resource for /code-p21 endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/code-p21")

    def list(self, params: CodeP21ListParams | None = None) -> BaseResponse[list[CodeP21]]:
        """List code P21 records.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of CodeP21 items.
        """
        response = self._get(params=params)
        return BaseResponse[list[CodeP21]].model_validate(response)


class PaymentTypesResource(BaseResource):
    """Resource for /payment-types endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/payment-types")

    def list(self, params: PaymentTypesListParams | None = None) -> BaseResponse[list[PaymentType]]:
        """List payment types.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of PaymentType items.
        """
        response = self._get(params=params)
        return BaseResponse[list[PaymentType]].model_validate(response)


class P21CoreClient(BaseServiceClient):
    """Client for the P21 Core service.

    Provides access to Prophet 21 core data endpoints including:
    - Addresses (address)
    - Branches (branch)
    - Cash Drawers (cash_drawer)
    - Companies (company)
    - Locations (location)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> drawers = api.p21_core.cash_drawer.list(CashDrawerListParams(drawer_open="Y"))
        >>> for drawer in drawers.data:
        ...     print(drawer.cash_drawer_id, drawer.drawer_open)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the P21 Core client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._address: AddressResource | None = None
        self._branch: BranchResource | None = None
        self._cash_drawer: CashDrawerResource | None = None
        self._cash_drawer_underscore: CashDrawerUnderscoreResource | None = None
        self._code_p21: CodeP21Resource | None = None
        self._company: CompanyResource | None = None
        self._location: LocationResource | None = None
        self._payment_types: PaymentTypesResource | None = None

    @property
    def address(self) -> AddressResource:
        """Access address endpoints."""
        if self._address is None:
            self._address = AddressResource(self._http)
        return self._address

    @property
    def branch(self) -> BranchResource:
        """Access branch endpoints."""
        if self._branch is None:
            self._branch = BranchResource(self._http)
        return self._branch

    @property
    def cash_drawer(self) -> CashDrawerResource:
        """Access cash drawer endpoints."""
        if self._cash_drawer is None:
            self._cash_drawer = CashDrawerResource(self._http)
        return self._cash_drawer

    @property
    def company(self) -> CompanyResource:
        """Access company endpoints."""
        if self._company is None:
            self._company = CompanyResource(self._http)
        return self._company

    @property
    def location(self) -> LocationResource:
        """Access location endpoints."""
        if self._location is None:
            self._location = LocationResource(self._http)
        return self._location

    @property
    def cash_drawer_underscore(self) -> CashDrawerUnderscoreResource:
        """Access cash_drawer endpoints (underscore variant)."""
        if self._cash_drawer_underscore is None:
            self._cash_drawer_underscore = CashDrawerUnderscoreResource(self._http)
        return self._cash_drawer_underscore

    @property
    def code_p21(self) -> CodeP21Resource:
        """Access code-p21 endpoints."""
        if self._code_p21 is None:
            self._code_p21 = CodeP21Resource(self._http)
        return self._code_p21

    @property
    def payment_types(self) -> PaymentTypesResource:
        """Access payment-types endpoints."""
        if self._payment_types is None:
            self._payment_types = PaymentTypesResource(self._http)
        return self._payment_types
