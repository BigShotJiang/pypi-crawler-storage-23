"""Schemas for the Gregorovich service."""

from __future__ import annotations

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# ChatGPT Ask
class ChatGptAskParams(EdgeCacheParams):
    """Parameters for ChatGPT ask endpoint."""

    question: str


class ChatGptAskResult(CamelCaseModel, extra="allow"):
    """ChatGPT ask result (passthrough for API flexibility)."""


# Documents
class DocumentsResult(CamelCaseModel, extra="allow"):
    """Document result (passthrough for API flexibility)."""

    id: str | None = None


# Ollama Generate
class OllamaGenerateParams(BaseModel, extra="allow"):
    """Parameters for Ollama generate endpoint (passthrough for flexibility)."""


class OllamaGenerateResult(CamelCaseModel, extra="allow"):
    """Ollama generate result (passthrough for API flexibility)."""
