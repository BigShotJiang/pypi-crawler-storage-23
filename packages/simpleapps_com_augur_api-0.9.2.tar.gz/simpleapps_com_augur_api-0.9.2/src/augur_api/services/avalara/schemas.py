"""Schemas for the Avalara service."""

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Rates
class RatesParams(EdgeCacheParams):
    """Parameters for tax rate lookup."""

    line1: str | None = None
    line2: str | None = None
    line3: str | None = None
    city: str | None = None
    region: str | None = None
    postal_code: str | None = None
    country: str | None = None


class TaxRate(CamelCaseModel):
    """Tax rate response."""

    total_rate: float | None = None
    state_rate: float | None = None
    county_rate: float | None = None
    city_rate: float | None = None
    special_rate: float | None = None
