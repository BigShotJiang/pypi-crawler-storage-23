"""Schemas for the Orders service."""

from __future__ import annotations

from typing import Any

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Order Header (OE HDR)
class OeHdrLookupParams(EdgeCacheParams):
    """Parameters for order header lookup."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    class1id: str | None = None
    completed: str | None = None
    date_order_completed: str | None = None
    salesrep_id: str | None = None
    taker: str | None = None


class OeHdrDocParams(EdgeCacheParams):
    """Parameters for order document."""

    postal_code: str | None = None


class OeHdr(CamelCaseModel):
    """Order header entity."""

    order_no: int | None = None
    customer_id: int | None = None
    contact_id: int | None = None
    ship_to_id: int | None = None
    order_date: str | None = None
    po_no: str | None = None
    total_amount: float | None = None
    tax_amount: float | None = None
    freight_amount: float | None = None
    status_cd: int | None = None
    ship_via: str | None = None
    terms_id: str | None = None
    salesrep_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class OeHdrDoc(CamelCaseModel):
    """Order header document with lines."""

    order_no: int | None = None
    customer_id: int | None = None
    customer_name: str | None = None
    order_date: str | None = None
    lines: list[Any] | None = None
    totals: dict[str, Any] | None = None


# Invoice Header
class InvoiceHdr(CamelCaseModel):
    """Invoice header entity."""

    invoice_no: int | None = None
    order_no: int | None = None
    customer_id: int | None = None
    invoice_date: str | None = None
    due_date: str | None = None
    total_amount: float | None = None
    balance_due: float | None = None
    status_cd: int | None = None


class InvoiceReprintResponse(CamelCaseModel):
    """Invoice reprint response."""

    success: bool | None = None
    message: str | None = None
    invoice_no: int | None = None


# Sales Rep Order Header
class SalesRepOeHdr(CamelCaseModel):
    """Sales rep order header entity."""

    order_no: int | None = None
    customer_id: int | None = None
    customer_name: str | None = None
    order_date: str | None = None
    total_amount: float | None = None
    status_cd: int | None = None


# Pick Tickets
class PickTicketsListParams(EdgeCacheParams):
    """Parameters for listing pick tickets."""

    limit: int | None = None
    offset: int | None = None
    company_id: str | None = None
    location_id: int | None = None
    delete_flag: str | None = None
    order_no: int | None = None
    printed_flag: str | None = None


class PickTicket(CamelCaseModel):
    """Pick ticket entity."""

    pick_ticket_no: int | None = None
    order_no: int | None = None
    customer_id: int | None = None
    location_id: int | None = None
    status_cd: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class PickTicketLinesParams(EdgeCacheParams):
    """Parameters for listing pick ticket lines."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None


class PickTicketLine(CamelCaseModel):
    """Pick ticket line entity."""

    line_number: int | None = None
    pick_ticket_no: int | None = None
    inv_mast_uid: int | None = None
    item_id: str | None = None
    quantity_ordered: float | None = None
    quantity_picked: float | None = None
    unit_of_measure: str | None = None
    bin_location: str | None = None


# Purchase Order Header
class PoHdrListParams(EdgeCacheParams):
    """Parameters for listing purchase orders."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    complete: str | None = None
    vendor_id: str | None = None
    status_cd: int | None = None


class PoHdrScanParams(EdgeCacheParams):
    """Parameters for scanning purchase orders."""

    vendor_id: str | None = None
    item_id: str | None = None
    date_from: str | None = None
    date_to: str | None = None
    status_cd: int | None = None


class PoHdr(CamelCaseModel):
    """Purchase order header entity."""

    po_no: int | None = None
    vendor_id: str | None = None
    vendor_name: str | None = None
    order_date: str | None = None
    expected_date: str | None = None
    total_amount: float | None = None
    status_cd: int | None = None
    complete: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class PoHdrDoc(CamelCaseModel):
    """Purchase order document with lines."""

    po_no: int | None = None
    vendor_id: str | None = None
    vendor_name: str | None = None
    order_date: str | None = None
    lines: list[Any] | None = None
    totals: dict[str, Any] | None = None
