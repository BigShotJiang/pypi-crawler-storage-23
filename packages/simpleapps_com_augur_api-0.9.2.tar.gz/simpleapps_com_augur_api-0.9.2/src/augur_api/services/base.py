"""Base service client class for all Augur services."""

from typing import Any

from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse, HealthCheckData


class BaseServiceClient:
    """Base client for Augur API services.

    All service-specific clients inherit from this class to gain
    common functionality like health checks and ping endpoints.

    Attributes:
        _http: The HTTP client for making requests.
        service_name: Name of the service.
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the service client.

        Args:
            http_client: The HTTP client for making requests.
        """
        self._http = http_client
        self.service_name = http_client.service_name

    def health_check(self) -> BaseResponse[HealthCheckData]:
        """Check service health.

        Returns:
            BaseResponse containing HealthCheckData with site_hash and site_id.
        """
        response = self._http.get("/health-check")
        return BaseResponse[HealthCheckData].model_validate(response)

    def ping(self) -> BaseResponse[str]:
        """Ping the service.

        Returns:
            BaseResponse containing 'pong' string.
        """
        response = self._http.get("/ping")
        return BaseResponse[str].model_validate(response)

    def whoami(self) -> BaseResponse[dict[str, Any]]:
        """Get information about the authenticated user.

        Returns:
            BaseResponse containing user information.
        """
        response = self._http.get("/whoami")
        return BaseResponse[dict[str, Any]].model_validate(response)
