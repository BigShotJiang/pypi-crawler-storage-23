from pathlib import Path

from pydantic import BaseModel

from ai_parade._toolkit.data.ImageInput import ImageInput
from ai_parade._toolkit.data.output import Output
from ai_parade._toolkit.enums import ExactModelFormat


class ConversionResult(BaseModel):
	format: ExactModelFormat
	"""
	Format of the converted model
	"""

	image_input: ImageInput
	"""
	Image input of the converted model
	"""

	path: Path
	"""
	Path to the converted model.
	"""
	output: Output
	"""
	Output of the converted model.
	"""

	@staticmethod
	def load(path: Path) -> "ConversionResult":
		if not path.exists():
			raise FileNotFoundError(f"Conversion result file {path} does not exist")
		if path.suffix != ".json":
			raise ValueError(f"Conversion result file {path} is not a JSON file")
		with open(path, "r", encoding="utf-8") as f:
			conversion_result = ConversionResult.model_validate_json(f.read())

		conversion_result.path = (path.parent / conversion_result.path).resolve()
		return conversion_result
