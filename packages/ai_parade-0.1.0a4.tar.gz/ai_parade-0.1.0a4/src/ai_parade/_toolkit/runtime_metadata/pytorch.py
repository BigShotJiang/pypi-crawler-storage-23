from ..enums import (
	AIRuntime,
	HardwareAcceleration,
	ModelFormat,
	Platform,
	Quantization,
)
from ._common import ModelAttributes

runtime = AIRuntime.PyTorch
capabilities = {
	Platform.Windows: {
		Quantization.none: {
			HardwareAcceleration.CPU,
		},
	}
}

format = ModelFormat.PyTorch
format_distinguishes = [ModelAttributes.Quantization]
