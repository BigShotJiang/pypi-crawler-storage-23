from ..enums import (
	AIRuntime,
	HardwareAcceleration,
	ModelFormat,
	Platform,
	Quantization,
)
from ._common import ModelAttributes

runtime = AIRuntime.ncnn
capabilities = {
	Platform.Android: {
		Quantization.none: {
			HardwareAcceleration.CPU,
			HardwareAcceleration.Vulkan,
		},
		Quantization.int8: {
			HardwareAcceleration.CPU,
			HardwareAcceleration.Vulkan,
		},
		Quantization.float16: {
			HardwareAcceleration.CPU,
			HardwareAcceleration.Vulkan,
		},
	},
	Platform.IOS: {
		Quantization.none: {
			HardwareAcceleration.CPU,
			HardwareAcceleration.Vulkan,
		},
		Quantization.int8: {
			HardwareAcceleration.CPU,
			HardwareAcceleration.Vulkan,
		},
		Quantization.float16: {
			HardwareAcceleration.CPU,
			HardwareAcceleration.Vulkan,
		},
	},
}

format = ModelFormat.NCNN
format_distinguishes = [ModelAttributes.Quantization]
