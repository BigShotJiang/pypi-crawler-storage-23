from ..enums import (
	AIRuntime,
	HardwareAcceleration,
	ModelFormat,
	Platform,
	Quantization,
)
from ._common import ModelAttributes

runtime = AIRuntime.TensorFlow
capabilities = {
	Platform.Windows: {
		Quantization.none: {
			HardwareAcceleration.CPU,
		},
	}
}

format = ModelFormat.SavedModel
format_distinguishes = [ModelAttributes.Quantization]
