import os
import json
import tempfile
import pytest
from agent_memory.core import load_config, save_config, store, recall, search, delete, list_all

@pytest.fixture(autouse=True)
def clean_env(tmp_path, monkeypatch):
    cfg = {"memory_path": str(tmp_path / "memory.json"), "max_entries": 100}
    cfg_file = tmp_path / "config.json"
    cfg_file.write_text(json.dumps(cfg))
    monkeypatch.setattr("agent_memory.core.DEFAULT_CONFIG_PATH", cfg_file)
    monkeypatch.setattr("agent_memory.core.DEFAULT_MEMORY_PATH", tmp_path / "memory.json")
    yield

class TestLoadConfig:
    def test_returns_dict(self):
        result = load_config()
        assert isinstance(result, dict)

    def test_has_memory_path(self):
        result = load_config()
        assert "memory_path" in result

class TestSaveConfig:
    def test_saves_and_loads(self, tmp_path):
        path = str(tmp_path / "test_cfg.json")
        save_config({"memory_path": "/tmp/mem.json"}, path)
        result = load_config(path)
        assert result["memory_path"] == "/tmp/mem.json"

class TestStore:
    def test_store_returns_dict(self):
        result = store("key1", "value1")
        assert isinstance(result, dict)
        assert result["key"] == "key1"

    def test_store_with_tags(self):
        result = store("key2", "value2", tags=["test"])
        assert "test" in result["tags"]

    def test_store_empty_key_raises(self):
        with pytest.raises(ValueError):
            store("", "value")

class TestRecall:
    def test_recall_existing(self):
        store("mykey", "myval")
        result = recall("mykey")
        assert result is not None
        assert result["value"] == "myval"

    def test_recall_missing_returns_none(self):
        result = recall("nonexistent")
        assert result is None

class TestSearch:
    def test_search_by_tag(self):
        store("s1", "v1", tags=["alpha"])
        store("s2", "v2", tags=["beta"])
        results = search("", tag="alpha")
        assert len(results) >= 1

class TestDelete:
    def test_delete_existing(self):
        store("delme", "val")
        result = delete("delme")
        assert result is True or result is None
        assert recall("delme") is None

class TestListAll:
    def test_list_all_returns_list(self):
        result = list_all()
        assert isinstance(result, list)

    def test_list_after_store(self):
        store("la1", "v1")
        result = list_all()
        assert len(result) >= 1
