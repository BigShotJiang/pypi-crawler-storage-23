# agent-memory

Auto-generated tool for ai_agent_tools

## Installation

```bash
pip install agent-memory
```

## Usage

```bash
agent_memory --help
agent_memory --json
```

## Python API

```python
from agent_memory.core import run
result = run()
```

## License

MIT
