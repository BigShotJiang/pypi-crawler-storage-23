import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Optional


DEFAULT_CONFIG_PATH = Path.home() / ".agent-memory" / "config.json"
DEFAULT_MEMORY_PATH = Path.home() / ".agent-memory" / "memory.json"


def load_config(config_path: Optional[str] = None) -> dict[str, Any]:
    """Load configuration from a JSON file.

    Args:
        config_path: Optional path to config file. Uses default if None.

    Returns:
        Dictionary containing configuration values.
    """
    path = Path(config_path) if config_path else DEFAULT_CONFIG_PATH
    if not path.exists():
        return {"memory_path": str(DEFAULT_MEMORY_PATH), "max_entries": 1000}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        raise RuntimeError(f"Failed to load config from {path}: {e}") from e


def save_config(config: dict[str, Any], config_path: Optional[str] = None) -> None:
    """Save configuration to a JSON file.

    Args:
        config: Configuration dictionary to save.
        config_path: Optional path to config file. Uses default if None.
    """
    path = Path(config_path) if config_path else DEFAULT_CONFIG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
    except OSError as e:
        raise RuntimeError(f"Failed to save config to {path}: {e}") from e


def _load_memory(memory_path: str) -> list[dict[str, Any]]:
    """Load memory entries from storage file."""
    path = Path(memory_path)
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("Memory file must contain a JSON array")
        return data
    except (json.JSONDecodeError, OSError, ValueError) as e:
        raise RuntimeError(f"Failed to load memory from {memory_path}: {e}") from e


def _save_memory(entries: list[dict[str, Any]], memory_path: str) -> None:
    """Save memory entries to storage file."""
    path = Path(memory_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(entries, f, indent=2)
    except OSError as e:
        raise RuntimeError(f"Failed to save memory to {memory_path}: {e}") from e


def store(key: str, value: str, tags: Optional[list[str]] = None, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Store a memory entry with a key, value, and optional tags.

    Args:
        key: Unique identifier for the memory entry.
        value: Content to store.
        tags: Optional list of tags for categorization.
        config: Optional configuration dictionary.

    Returns:
        The stored memory entry as a dictionary.
    """
    if not key or not value:
        raise ValueError("Both key and value must be non-empty strings")
    cfg = config or load_config()
    memory_path = cfg.get("memory_path", str(DEFAULT_MEMORY_PATH))
    max_entries = cfg.get("max_entries", 1000)
    entries = _load_memory(memory_path)
    entry = {"key": key, "value": value, "tags": tags or []}
    entries = [e for e in entries if e.get("key") != key]
    entries.append(entry)
    if len(entries) > max_entries:
        entries = entries[-max_entries:]
    _save_memory(entries, memory_path)
    return entry


def recall(key: str, config: Optional[dict[str, Any]] = None) -> Optional[dict[str, Any]]:
    """Recall a memory entry by its key.

    Args:
        key: The key of the memory entry to retrieve.
        config: Optional configuration dictionary.

    Returns:
        The memory entry if found, None otherwise.
    """
    cfg = config or load_config()
    memory_path = cfg.get("memory_path", str(DEFAULT_MEMORY_PATH))
    entries = _load_memory(memory_path)
    for entry in entries:
        if entry.get("key") == key:
            return entry
    return None


def search(query: str, tag: Optional[str] = None, config: Optional[dict[str, Any]] = None) -> list[dict[str, Any]]:
    """Search memory entries by query string and optional tag filter.

    Args:
        query: Search string to match against keys and values.
        tag: Optional tag to filter results.
        config: Optional configuration dictionary.

    Returns:
        List of matching memory entries.
    """
    cfg = config or load_config()
    memory_path = cfg.get("memory_path", str(DEFAULT_MEMORY_PATH))
    entries = _load_memory(memory_path)
    results = []
    query_lower = query.lower()
    for entry in entries:
        if query_lower in entry.get("key", "").lower() or query_lower in entry.get("value", "").lower():
            if tag is None or tag in entry.get("tags", []):
                results.append(entry)
    return results


def delete(key: str, config: Optional[dict[str, Any]] = None) -> bool:
    """Delete a memory entry by key.

    Args:
        key: The key of the memory entry to delete.
        config: Optional configuration dictionary.

    Returns:
        True if an entry was deleted, False if not found.
    """
    cfg = config or load_config()
    memory_path = cfg.get("memory_path", str(DEFAULT_MEMORY_PATH))
    entries = _load_memory(memory_path)
    filtered = [e for e in entries if e.get("key") != key]
    if len(filtered) == len(entries):
        return False
    _save_memory(filtered, memory_path)
    return True


def list_all(config: Optional[dict[str, Any]] = None) -> list[dict[str, Any]]:
    """List all memory entries.

    Args:
        config: Optional configuration dictionary.

    Returns:
        List of all memory entries.
    """
    cfg = config or load_config()
    memory_path = cfg.get("memory_path", str(DEFAULT_MEMORY_PATH))
    return _load_memory(memory_path)


def _output(data: Any, as_json: bool = True) -> None:
    """Print output, optionally as JSON."""
    if as_json:
        print(json.dumps(data, indent=2))
    else:
        print(data)


def cli(argv: Optional[list[str]] = None) -> int:
    """Run the agent-memory CLI interface.

    Args:
        argv: Optional argument list. Uses sys.argv if None.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    parser = argparse.ArgumentParser(prog="agent-memory", description="AI Agent Memory Tool")
    parser.add_argument("--config", type=str, default=None, help="Path to config file")
    parser.add_argument("--json", action="store_true", default=True, help="Output as JSON")
    sub = parser.add_subparsers(dest="command", help="Available commands")

    sp_store = sub.add_parser("store", help="Store a memory entry")
    sp_store.add_argument("key", help="Memory key")
    sp_store.add_argument("value", help="Memory value")
    sp_store.add_argument("--tags", nargs="*", default=[], help="Tags for the entry")

    sp_recall = sub.add_parser("recall", help="Recall a memory entry")
    sp_recall.add_argument("key", help="Memory key to recall")

    sp_search = sub.add_parser("search", help="Search memory entries")
    sp_search.add_argument("query", help="Search query")
    sp_search.add_argument("--tag", type=str, default=None, help="Filter by tag")

    sp_delete = sub.add_parser("delete", help="Delete a memory entry")
    sp_delete.add_argument("key", help="Memory key to delete")

    sub.add_parser("list", help="List all memory entries")

    sp_config = sub.add_parser("config", help="Manage configuration")
    sp_config.add_argument("--set", nargs=2, metavar=("KEY", "VALUE"), help="Set a config value")
    sp_config.add_argument("--init", action="store_true", help="Initialize default config")

    args = parser.parse_args(argv)
    try:
        cfg = load_config(args.config)
        if args.command == "store":
            result = store(args.key, args.value, args.tags, cfg)
            _output(result, args.json)
        elif args.command == "recall":
            result = recall(args.key, cfg)
            if result is None:
                _output({"error": f"No entry found for key: {args.key}"}, args.json)
                return 1
            _output(result, args.json)
        elif args.command == "search":
            results = search(args.query, args.tag, cfg)
            _output(results, args.json)
        elif args.command == "delete":
            deleted = delete(args.key, cfg)
            _output({"deleted": deleted, "key": args.key}, args.json)
            return 0 if deleted else 1
        elif args.command == "list":
            _output(list_all(cfg), args.json)
        elif args.command == "config":
            if args.init:
                save_config(cfg, args.config)
                _output({"status": "initialized", "config": cfg}, args.json)
            elif args.set:
                cfg[args.set[0]] = args.set[1]
                save_config(cfg, args.config)
                _output(cfg, args.json)
            else:
                _output(cfg, args.json)
        else:
            parser.print_help()
            return 1
    except (RuntimeError, ValueError) as e:
        _output({"error": str(e)}, True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(cli())