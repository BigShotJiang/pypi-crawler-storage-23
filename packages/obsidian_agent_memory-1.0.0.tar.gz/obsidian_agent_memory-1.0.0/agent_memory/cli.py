import argparse
import json as json_module
import sys
import logging

from .core import load_config, save_config, store, recall, search, delete, list_all, cli


def setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(level=level, format="%(levelname)s: %(message)s")


def output_result(result, use_json: bool) -> None:
    if use_json:
        print(json_module.dumps(result, indent=2, default=str))
    else:
        if isinstance(result, (dict, list)):
            for item in (result if isinstance(result, list) else [result]):
                if isinstance(item, dict):
                    for k, v in item.items():
                        print(f"  {k}: {v}")
                    print()
                else:
                    print(item)
        elif result is not None:
            print(result)


def cmd_store(args):
    logging.debug("Storing memory with key=%s", args.key)
    result = store(args.key, args.value, metadata=args.metadata)
    output_result(result if result is not None else {"status": "stored", "key": args.key}, args.json)


def cmd_recall(args):
    logging.debug("Recalling memory with key=%s", args.key)
    result = recall(args.key)
    if result is None:
        if args.json:
            output_result({"status": "not_found", "key": args.key}, args.json)
        else:
            print(f"No memory found for key: {args.key}")
        sys.exit(1)
    else:
        output_result(result, args.json)


def cmd_search(args):
    logging.debug("Searching memories with query=%s", args.query)
    results = search(args.query, limit=args.limit)
    if results is None:
        results = []
    output_result(results, args.json)


def cmd_delete(args):
    logging.debug("Deleting memory with key=%s", args.key)
    result = delete(args.key)
    output_result(result if result is not None else {"status": "deleted", "key": args.key}, args.json)


def cmd_list_all(args):
    logging.debug("Listing all memories")
    results = list_all(limit=args.limit, offset=args.offset)
    if results is None:
        results = []
    output_result(results, args.json)


def cmd_config_load(args):
    logging.debug("Loading configuration")
    config = load_config(path=args.path)
    output_result(config if config is not None else {}, args.json)


def cmd_config_save(args):
    logging.debug("Saving configuration")
    config_data = {}
    if args.data:
        try:
            config_data = json_module.loads(args.data)
        except json_module.JSONDecodeError:
            print("Error: --data must be valid JSON", file=sys.stderr)
            sys.exit(1)
    result = save_config(config_data, path=args.path)
    output_result(result if result is not None else {"status": "saved"}, args.json)


def main():
    parser = argparse.ArgumentParser(
        prog="agent-memory",
        description="Agent Memory - A CLI for managing agent memory storage",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 1.0.0",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Output results in JSON format",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        default=False,
        help="Enable debug output",
    )

    subparsers = parser.add_subparsers(
        title="commands",
        dest="command",
        help="Available commands",
    )

    # store subcommand
    store_parser = subparsers.add_parser("store", help="Store a memory")
    store_parser.add_argument("key", type=str, help="Key for the memory")
    store_parser.add_argument("value", type=str, help="Value to store")
    store_parser.add_argument(
        "--metadata",
        type=str,
        default=None,
        help="Optional metadata as JSON string",
    )
    store_parser.set_defaults(func=cmd_store)

    # recall subcommand
    recall_parser = subparsers.add_parser("recall", help="Recall a memory by key")
    recall_parser.add_argument("key", type=str, help="Key of the memory to recall")
    recall_parser.set_defaults(func=cmd_recall)

    # search subcommand
    search_parser = subparsers.add_parser("search", help="Search memories")
    search_parser.add_argument("query", type=str, help="Search query")
    search_parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Maximum number of results (default: 10)",
    )
    search_parser.set_defaults(func=cmd_search)

    # delete subcommand
    delete_parser = subparsers.add_parser("delete", help="Delete a memory")
    delete_parser.add_argument("key", type=str, help="Key of the memory to delete")
    delete_parser.set_defaults(func=cmd_delete)

    # list subcommand
    list_parser = subparsers.add_parser("list", help="List all memories")
    list_parser.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Maximum number of results (default: 50)",
    )
    list_parser.add_argument(
        "--offset",
        type=int,
        default=0,
        help="Offset for pagination (default: 0)",
    )
    list_parser.set_defaults(func=cmd_list_all)

    # config subcommand with sub-subcommands
    config_parser = subparsers.add_parser("config", help="Manage configuration")
    config_subparsers = config_parser.add_subparsers(
        title="config commands",
        dest="config_command",
        help="Configuration sub-commands",
    )

    # config load
    config_load_parser = config_subparsers.add_parser("load", help="Load configuration")
    config_load_parser.add_argument(
        "--path",
        type=str,
        default=None,
        help="Path to configuration file",
    )
    config_load_parser.set_defaults(func=cmd_config_load)

    # config save
    config_save_parser = config_subparsers.add_parser("save", help="Save configuration")
    config_save_parser.add_argument(
        "--path",
        type=str,
        default=None,
        help="Path to configuration file",
    )
    config_save_parser.add_argument(
        "--data",
        type=str,
        default=None,
        help="Configuration data as JSON string",
    )
    config_save_parser.set_defaults(func=cmd_config_save)

    args = parser.parse_args()

    setup_logging(args.verbose)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "config" and not hasattr(args, "func"):
        config_parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()