# av-cli

CLI wrapper for Alpha Vantage APIs.

## Install

```
pip install av-cli
```

## Usage

```
av-cli --version
```
