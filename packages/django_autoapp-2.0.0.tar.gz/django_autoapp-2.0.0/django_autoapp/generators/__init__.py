"""Generators sub-package for django_autoapp."""
