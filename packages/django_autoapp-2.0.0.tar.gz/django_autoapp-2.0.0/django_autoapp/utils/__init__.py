"""Utility sub-package for django_autoapp."""
