"""Core sub-package for django_autoapp."""
