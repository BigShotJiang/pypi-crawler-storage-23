"""Namespace protection testing package."""

__version__ = "0.1.0"


def hello():
    """Print a hello message."""
    print(f"Hello from namespace-protection-testing v{__version__}")
