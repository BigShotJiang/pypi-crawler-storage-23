# -------------------------------------------------------------------------
# Copyright (c) Switch Automation Pty Ltd. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------
"""
A module for interacting with the insights platform services, etc of the Switch Automation Platform.
"""

# from .platform_insights import get_current_insights_by_equipment

# __all__ = ['get_current_insights_by_equipment']
