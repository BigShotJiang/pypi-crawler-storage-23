# -------------------------------------------------------------------------
# Copyright (c) Switch Automation Pty Ltd. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------
"""
Miscellaneous constants, utility functions & interactions with storage accounts.
"""

# import ._utils
# import ._constants
# import ._platform
