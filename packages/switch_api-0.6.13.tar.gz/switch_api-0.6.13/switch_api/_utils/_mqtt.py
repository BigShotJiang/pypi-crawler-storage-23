# -------------------------------------------------------------------------
# Copyright (c) Switch Automation Pty Ltd.
# Licensed under the MIT License.
# -------------------------------------------------------------------------
"""
A module for mqtt related utils.
"""

from .._utils._constants import (
    WS_DEFAULT_PORT,
    WS_MQTT_DEFAULT_MAX_TIMEOUT,
)

global _control_api_endpoint
global _control_ws_host
global _control_ws_port
global _control_ws_username
global _control_ws_password
global _control_ws_max_timeout

_control_api_endpoint = ''
_control_ws_host = ''
_control_ws_port = WS_DEFAULT_PORT
_control_ws_username = ''
_control_ws_password = ''
_control_ws_max_timeout = WS_MQTT_DEFAULT_MAX_TIMEOUT

def get_control_config():
    """
    Retrieve Control MQTT Configuration

    Returns the currently configured MQTT control variables used by the
    controls module when communicating with the MQTT Broker.

    These values are typically set via `set_control_variables()` during
    local execution. In production environments, they may be populated
    from deployment environment variables.

    Returns
    -------
    dict
        A dictionary containing the current control configuration:

        - api_endpoint : str
            Platform IoT API endpoint.
        - ws_host : str
            WebSocket MQTT host URL (wss://).
        - ws_port : int
            MQTT broker port.
        - username : str
            Username for MQTT authentication.
        - password : str
            Password for MQTT authentication.
        - max_timeout : int
            Maximum timeout (in seconds) for control operations.
    """
    return {
        "api_endpoint": _control_api_endpoint,
        "ws_host": _control_ws_host,
        "ws_port": _control_ws_port,
        "username": _control_ws_username,
        "password": _control_ws_password,
        "max_timeout": _control_ws_max_timeout,
    }


def set_mqtt_broker_config(api_endpoint: str, ws_host: str, user_name: str, password: str,
                          ws_port: int = WS_DEFAULT_PORT, max_timeout: int = WS_MQTT_DEFAULT_MAX_TIMEOUT, bypass_username_password: bool = False):
    """Set Control Variables

    Set Control Variables needed to enable control request to MQTT Broker when running locally.

    In Production, these are pulled from the deployment environment variables.

    Parameters
    ----------
    api_endpoint : str
        Platform IoT API Endpoint.
    host : str
        Host URL for MQTT connection. This needs to be datacenter specfic URL.
    port : int
        MQTT message broker port. Defaults to 443.
    user_name : str
        Username for MQTT connection
    password: str
        Password for MQTT connection
    max_timeout : int
        Max timeout set for the controls module. Defaults to 30 seconds.
    """
    global _control_api_endpoint
    global _control_ws_host
    global _control_ws_port
    global _control_ws_username
    global _control_ws_password
    global _control_ws_max_timeout

    # Check if endpoint is a valid URL
    if not api_endpoint.startswith('https://'):
        raise ValueError(
            "Invalid IoT API Endpoint. The IoT host should start with 'https://'.")

    # # Check if host is a valid URL
    if not ws_host.startswith('wss://'):
        raise ValueError(
            "Invalid IoT Websocket MQTT Host. The IoT host should start with 'wss://'.")

    # Check if user_name and password are not empty
    if not bypass_username_password:
        if not user_name:
            raise ValueError("user_name cannot be empty.")
        if not password:
            raise ValueError("password cannot be empty.")

    # Check if max_timeout is greated than 0
    if max_timeout < 1:
        raise ValueError("max_timeout should be greater than 0.")

    # Set global variables
    _control_api_endpoint = api_endpoint
    _control_ws_host = ws_host
    _control_ws_port = ws_port
    _control_ws_username = user_name
    _control_ws_password = password
    _control_ws_max_timeout = max_timeout