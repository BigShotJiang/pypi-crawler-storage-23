# -------------------------------------------------------------------------
# Copyright (c) Switch Automation Pty Ltd. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------
"""
A module containing the SwitchMQTT class and associated methods referenced by the controls module in the package. This
module is not directly referenced by end users.
"""
import json
import logging
import sys
import threading
from urllib.parse import urlparse
import paho.mqtt.client as mqtt
import pandas
from paho.mqtt.client import MQTTMessage
from ._constants import (CONTROL_REQUEST_ACTION_ACK)
from .._utils._constants import (WS_DEFAULT_PORT, WS_MQTT_CONNECTION_TIMEOUT)

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
consoleHandler = logging.StreamHandler(stream=sys.stdout)
consoleHandler.setLevel(logging.INFO)

logger.addHandler(consoleHandler)
formatter = logging.Formatter('%(asctime)s  %(name)s.%(funcName)s  %(levelname)s: %(message)s',
                              datefmt='%Y-%m-%dT%H:%M:%S')
consoleHandler.setFormatter(formatter)

global message_received


class SwitchMQTT:
    def __init__(self, host_address: str, username: str, password: str,
                 client_id: str, email: str, project_id: str, host_port: int = WS_DEFAULT_PORT):
        """Constructor for MQTT Message Broker client.

        Parameters
        ----------
        host_address : str
            MQTT message broker host address.
        host_port :int
            MQTT message broker port. Defaults to 443.
        username : str
            MQTT credentials - username.
        password :str
            MQTT credentials - password.
        client_id : str
            Unique Client Id for connection.
        email : str
            User email requesting Control.
        project_id : str
            Portfolio to connect for control request.
        """
        self.host_address = host_address
        self.port = host_port
        self.client_id = client_id.lower()
        self.email = email
        self.project_id = project_id

        self._subscriptions = set()
        self._ack_events = threading.Event()
        self._connect_events = threading.Event()

        self.is_connected = False
        self.is_gateway_connected = False
        self.request_status = 0
        self.connection_timeout = WS_MQTT_CONNECTION_TIMEOUT

        self.sensor_request_count = 0
        self.sensor_request: list[dict] = []
        self.sensor_results: list[dict] = []

        self.mqttc = mqtt.Client(client_id=client_id, transport='websockets', clean_session=True)
        self.mqttc.tls_set()
        self.mqttc.username_pw_set(username, password)
        self.mqttc.reconnect_delay_set(min_delay=1, max_delay=60)
        self.mqttc.on_connect = self._on_connect
        self.mqttc.on_message = self._on_message


    def _on_connect(self, client: mqtt.Client, userdata: any, flags: dict, rc: int):
        """Event callback when connecting to the MQTT Message Broker

        Parameters
        ----------
        client: mqtt.Client
            The client instance for this callback
        userdata: any
            The private user data as set in Client() or user_data_set(). None for this workflow. 
        flags: dict
            Response flags sent by the broker
        rc: int
            The connection result
        """
        if rc == 0:
            if self.is_connected:
                logger.info(
                    f"Reconnected to MQTT broker: {self.host_address} port:{self.port}"
                )
            else:
                logger.info(
                    f"Connected to MQTT broker: {self.host_address} port:{self.port}"
                )

            self.is_connected = True
            self._connect_events.set()

            # Re-subscribe after reconnect (because of using cleanSession=True)
            if self._subscriptions:
                logger.info("Restoring subscriptions...")
                for topic in self._subscriptions:
                    client.subscribe(topic, qos=1)
                    logger.info(f"Re-subscribed to = {topic}")

        else:
            self.is_connected = False
            logger.error(f"Connection failed with code {rc}")


    def _on_message(self, client: mqtt.Client, userdata: any, message: MQTTMessage):
        """Event callback when a message received by the client

        Parameters
        ----------
        client: mqtt.Client
            The client instance for this callback
        userdata: any
            The private user data as set in Client() or user_data_set(). None for this workflow. 
        message: MQTTMessage
            An instance of MQTTMessage. This is a class with members topic, payload, qos, retain.
        """
        payload_str = message.payload.decode()
        payload = json.loads(payload_str)

        topic = message.topic
        action = payload.get('action')
        
        # [Logs] received messages from subscribed topics
        logger.info(f'MQTT Message - {topic} : {action}; {payload_str}')

        if topic == self.client_id and action == CONTROL_REQUEST_ACTION_ACK:
            self._process_acknowledgement(payload=payload)
            self._process_write_acknowledgement(payload=payload)
        # elif topic == f'control-result/pid/{self.project_id}/site/{self.installation_id}' and action == CONTROL_REQUEST_ACTION_RESULT:
        #     self._process_notification(payload=payload)
        elif topic.startswith('state/pid') and topic.endswith('svc/janus'):
            self._process_gateway_connected(payload=payload)


    def connect(self, timeout: int = WS_MQTT_CONNECTION_TIMEOUT) -> bool:
        """Initiate connection to MQTT Broker.

        Parameters
        ----------
        timeout : int, Optional
            Timeout in seconds for trying to connect to MQTT Message Broker.
                Defaults to WS_MQTT_CONNECTION_TIMEOUT.
        """
        if self.is_connected:
            return self.is_connected

        self._connect_events.clear()
        self.connection_timeout = timeout
        url = urlparse(self.host_address)

        logger.info(
            f'Attempting connection to MQTT broker with client_id={self.client_id} on host={self.host_address} port={self.port}')
        logger.info(f'hostname={url.hostname}')

        self.mqttc.connect(host=url.hostname, port=self.port)
        self.mqttc.loop_start()

        # Change to Thread Events same as Send Control
        is_connected = self._connect_events.wait(timeout=self.connection_timeout)

        return self.is_connected

    def send_control_request(self, session_id: str, installation_id: str, sensors: list[dict]):
        """Sends control-request action to Switch MQTT Broker to request control

        Parameters
        ----------
        topic : str
            Message broker topic to pulish message to
        sensors : dict
            Sensors to request control and update value
        """
        logger.info(f'Sending Control Request for {sensors}')

        self.session_id = session_id
        self.installation_id = installation_id
        self.sensor_results = []
        self.sensor_request = sensors
        self.sensor_request_count = len(sensors)
        self._ack_events.clear()

        if self.sensor_request_count == 0:
            logger.info("No sensors provided.")
            return pandas.DataFrame(), pandas.DataFrame()

        topic = f'control/pid/{self.project_id}/site/{installation_id}'

        payload = self._build_control_request_payload(sensors=sensors)
        payload_json = json.dumps(payload)


        logger.info(f'Payload = {payload_json}')
        self.mqttc.publish(topic=topic, payload=payload_json)

        received_all = self._ack_events.wait(timeout=self.connection_timeout)

        if received_all:
            logger.info("All Sensor Control Request received.")
        else:
            logger.info("Timeout reached.")

        logger.info('Checking missing items...')
        sensor_ids_received = set(item['sensorId']
                                  for item in self.sensor_results)

        missing_items = [item for item in sensors if item['sensorId']
                         not in sensor_ids_received]

        for item in missing_items:
            item['writeStatus'] = "Timeout reached"

        if len(missing_items) == 0:
            logger.info('There are no missing items.')
        else:
            logger.info(f'There are {len(missing_items)} missing items.')

        return pandas.DataFrame(self.sensor_results), pandas.DataFrame(missing_items)

    def subscribe(self, topic: str, qos: int = 0):
        """Subscribes to topics.

        Parameters
        ----------
        topic : str
            Topic for Websocket subscription.
        qos: int (optional)
            Defaults to 0
            Quality of Service (QoS) in MQTT messaging is an agreement between sender and receiver on the guarantee of delivering a message.
            There are three levels of QoS:
            0 - at most once
            1 - at least once
            2 - exactly once
        """
        self.mqttc.subscribe(topic=topic, qos=qos)

    def subscribe_installation(self, installation_id: str):
        """Subscribe to topics.

        **qos
            Quality of Service (QoS) in MQTT messaging is an agreement between sender and receiver on the guarantee of delivering a message.
            There are three levels of QoS:
            0 - at most once
            1 - at least once
            2 - exactly once

        Parameters
        ----------
        installation_id : str
            Installation Id for Websocket subscription.
        """
        self.connect()

        topics = {
            self.client_topic(),
            self.site_state_topic(self.project_id, installation_id)
        }

        for topic in topics:
            if topic not in self._subscriptions:
                self._subscriptions.add(topic)

            # Always subscribe (broker handles duplicates)
            self.mqttc.subscribe(topic=topic, qos=1)
            logger.info(f"Subscribed to = {topic}")


    def unsubscribe_installation(self, installation_id: str):
        """Unsubscribe to topics.

        Parameters
        ----------
        installation_id : str
            Installation Id for Websocket subscription.
        """
        topic = self.site_state_topic(self.project_id, installation_id)

        if topic in self._subscriptions:
            self.mqttc.unsubscribe(topic)
            self._subscriptions.remove(topic)
            logger.info(f'Unsubscribed from = {topic}')

    def disconnect(self):
        """Disconnect connection to MQTT Message Broker.
        """
        self.mqttc.disconnect()
        self.mqttc.loop_stop()
        self.is_connected = False
        self.is_gateway_connected = False
        logger.info(f'Disconnected to MQTT Broker.')


    def _process_acknowledgement(self, payload: dict):
        """Process mqtt message for control result acknowledgement

        Parameters
        ----------
        payload : dict

            Message payload
        """
        status_messages = {
            0: "Appliance doesn't have any of the sensors requested.",
            1: "Appliance will control some of the sensors in the requested list.",
            2: "Appliance will control all the sensors in the list."
        }

        status = payload.get("status", -1)
        logger.info(
            f'Control Request Acknowledgment. Mac={payload["mac"]} Status={status_messages.get(status, "Unknown status")}')

        self.request_status = status

    def _process_write_acknowledgement(self, payload: dict):
        """Process mqtt message for control result acknowledgement as write command successful
        and return sensor list request sent as a response.

        Parameters
        ----------
        payload : dict

            Message payload
        """

        for item in self.sensor_request:
            sensor_control_result = {
                'sensorId': item["sensorId"],
                'controlValue': item["controlValue"],
                'presentValue': item["controlValue"],
                'defaultControlValue': item.get("defaultControlValue", None),
                'priority': item["priority"],
                'status': 1,
            }

            self.sensor_results.append(sensor_control_result)

        if len(self.sensor_results) >= self.sensor_request_count:
            self._ack_events.set()

    def _process_notification(self, payload: dict):
        """Process mqtt message for control result notification

        Parameters
        ----------
        payload : dict
            Message payload
        """
        write_status = payload.get('status', -1)
        write_status_description = {
            0: 'Write success - session in progress',
            1: 'Write success - session completed',
            2: 'Write failed - session failed',
            3: 'Read verification failed - session failed'
        }.get(write_status, 'Unknown Write Status')

        logger.info(
            f'Sensor {payload["sensorId"]} Value={payload["presentValue"]}, Status={write_status_description}')

        sensor_control_result = {
            'sensorId': payload["sensorId"],
            'controlValue': payload["controlValue"],
            'presentValue': payload["presentValue"],
            'defaultControlValue': payload.get("defaultControlValue", None),
            'status': write_status,
        }

        if not write_status == 0:
            self.sensor_results.append(sensor_control_result)

    def _build_control_request_payload(self, sensors: dict):
        """Util function to build control request payload to Switch MQTT Broker

        Parameters:
        sensors (dict): 
            List of sensors to request control

        Returns:
            _type_: _description_
        """
        return {
            'action': 'control-request',
            'clientId': self.client_id,
            'originator': self.email,
            'sensors': sensors,
            'sessionId': str(self.session_id)
        }

    def _process_gateway_connected(self, payload: dict):
        """Process mqtt message for control result acknowledgement

        Parameters
        ----------
        payload : dict
            Message payload
        """

        self.is_gateway_connected = payload.get('status', False)
        logger.info(f'Gateway Connected Status={self.is_gateway_connected}')

    def client_topic(self):
        """
        Wrapper for ClientId Topic
        """
        return self.client_id

    def site_state_topic(self, project_id, installation_id):
        """
        Wrapper for Site State Topic
        """
        return f"state/pid/{project_id}/site/{installation_id}/#"
