# -------------------------------------------------------------------------
# Copyright (c) Switch Automation Pty Ltd.
# Licensed under the MIT License.
# -------------------------------------------------------------------------
"""
A module for sending control request of sensors.
"""

import logging
import sys
import pandas

from .._utils._constants import (
    WS_MQTT_CONNECTION_TIMEOUT,
)
from .._utils import _mqtt
from ._mqtt import SwitchRealtime
from .._utils._utils import ApiInputs, _with_func_attrs

# -----------------------------------------------------------------------------
# Logging Setup
# -----------------------------------------------------------------------------
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

if not logger.handlers:
    console_handler = logging.StreamHandler(stream=sys.stdout)
    console_handler.setLevel(logging.INFO)

    formatter = logging.Formatter(
        "%(asctime)s  %(name)s.%(funcName)s  %(levelname)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

# -----------------------------------------------------------------------------
# Globals
# -----------------------------------------------------------------------------
global _switch_realtime

_switch_realtime = None


@_with_func_attrs(df_required_columns=["Id"])
def submit_realtime_updates(
    api_inputs: ApiInputs,
    data_set: str,
    df: pandas.DataFrame,
    timeout: int = WS_MQTT_CONNECTION_TIMEOUT,
):
    """
    Submit realtime dataset update live to a single Live Workspace dataset.

    This method connects to the MQTT broker, subscribes to the retained
    message of the specified dataset topic (if any), merges the retained
    dataset with the provided DataFrame, and publishes the updated dataset
    back to the same topic.

    Required DataFrame Fields
    --------------------------
    - Id (Required)

    Topic Format
    ------------
    A single topic is constructed in the format:

        Realtime/{api_project_id}/{data_set}

    Example:
        If api_project_id = "123"
        and data_set = "temperature"

        The resulting topic will be:
            Realtime/123/temperature

    Parameters
    ----------
    api_inputs : ApiInputs
        Object returned by initialize() function.

    data_set : str
        Name of the dataset to subscribe to and publish updates to.
        Represents a dataset under the Live Workspace.
        Must be a non-empty string.

    df : pandas.DataFrame
        Data for realtime dataset update.
        Must contain the required columns listed above.
        If retained data exists on the topic, the DataFrame will:
            - Override existing rows by matching on "Id"
            - Append new rows that do not exist in retained data

    timeout : int, optional
        Connection timeout in seconds.
        Default value is WS_MQTT_CONNECTION_TIMEOUT = 180.

        Rules:
            - Value must be between 1 and max control timeout set in control variables.
            - If set to 0, it defaults to the max timeout value.
            - If greater than max timeout value, it defaults to the max timeout value.

    Returns
    -------
    tuple
        (status_message, pandas.DataFrame)

        status_message : str
            Indicates success or failure reason.

        pandas.DataFrame
            The final merged dataset that was published.
            Returns empty DataFrame if operation failed.
    """

    global _switch_realtime

    mqtt_config = _mqtt.get_control_config()

    # ----------------------------
    # Validation
    # ----------------------------
    if not api_inputs.api_base_url or not api_inputs.bearer_token:
        logger.error("You must call initialize() before using the API.")
        return "Invalid api_inputs.", pandas.DataFrame()

    if not isinstance(data_set, str) or not data_set.strip():
        logger.error("data_set must be a non-empty string.")
        return "Invalid data_set value.", pandas.DataFrame()

    if df.empty:
        logger.error("Dataframe is empty.")
        return "Empty dataframe.", pandas.DataFrame()
    
    if timeout < 0:
        logger.error(
            f"Invalid timeout value. Timeout should be between 0 and {mqtt_config['max_timeout']}. Setting to zero will default to max timeout.")
        return 'Invalid timeout.', pandas.DataFrame()

    if timeout > mqtt_config["max_timeout"]:
        logger.critical(
            f'Timeout is greater than Max Timeout value. Setting timeout to Max Timeout Value instead.')
        timeout = mqtt_config["max_timeout"]

    if timeout == 0:
        timeout = mqtt_config["max_timeout"]


    required_columns = getattr(submit_realtime_updates, "df_required_columns")
    missing_columns = set(required_columns) - set(df.columns)

    if missing_columns:
        logger.error(f"Missing required columns: {missing_columns}")
        return (
            f"DataFrame must contain: {', '.join(required_columns)}",
            pandas.DataFrame(),
        )

    data_frame = df.copy()
    topic = f"Realtime/{api_inputs.api_project_id}/{data_set}"

    # ----------------------------
    # Initialize MQTT client
    # ----------------------------
    if _switch_realtime is None:
        _switch_realtime = SwitchRealtime(
            host=mqtt_config["ws_host"],
            port=mqtt_config["ws_port"],
            username=mqtt_config["username"],
            password=mqtt_config["password"],
            client_id=api_inputs.data_feed_id,
            email=api_inputs.email_address,
            project_id=api_inputs.api_project_id,
        )

    # ----------------------------
    # Connect
    # ----------------------------
    if not _switch_realtime.connect(timeout=timeout):
        logger.error("Could not connect to MQTT Broker.")
        return "Could not connect to MQTT Broker.", pandas.DataFrame()

    # ----------------------------
    # Subscribe (Single Topic)
    # ----------------------------
    retained_dataset = _switch_realtime.subscribe_with_retained_sync(
        topics=[topic],
        timeout=10,
    )

    retained_json = retained_dataset.get(topic)
    logger.info(f"Retained message for {topic}: {retained_json}")

    # ----------------------------
    # Merge Logic
    # ----------------------------
    try:
        if retained_json:
            retained_df = pandas.read_json(retained_json)

            if "Id" in retained_df.columns:
                retained_df = retained_df.set_index("Id")
                new_df = data_frame.set_index("Id")

                retained_df.update(new_df)

                merged_df = pandas.concat(
                    [
                        retained_df,
                        new_df.loc[~new_df.index.isin(retained_df.index)],
                    ]
                ).reset_index()
            else:
                logger.warning("Retained message missing 'Id'. Using new dataframe.")
                merged_df = data_frame
        else:
            logger.info("No retained message. Using new dataframe.")
            merged_df = data_frame

    except Exception as e:
        logger.error(f"Error processing retained message: {e}")
        merged_df = data_frame

    # ----------------------------
    # Publish
    # ----------------------------
    try:
        payload_json = merged_df.to_json(orient="records")
        _switch_realtime.publish(topic=topic, payload=payload_json)
        logger.info(f"Published merged DataFrame to {topic}")
    except Exception as e:
        logger.error(f"Failed to publish DataFrame: {e}")
        return "Publish failed.", pandas.DataFrame()

    return "Success", merged_df
