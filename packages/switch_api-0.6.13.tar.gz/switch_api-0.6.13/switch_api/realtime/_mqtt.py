# -------------------------------------------------------------------------
# Copyright (c) Switch Automation Pty Ltd. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------
"""
A module containing the SwithRealtime class and associated methods referenced by the controls module in the package. This
module is not directly referenced by end users.
"""
import json
import logging
import sys
import threading
from typing import Iterable
from urllib.parse import urlparse
import paho.mqtt.client as mqtt
from paho.mqtt.client import MQTTMessage
from .._utils._constants import (WS_MQTT_CONNECTION_TIMEOUT)

# -----------------------------------------------------------------------------
# Logging Setup
# -----------------------------------------------------------------------------
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

if not logger.handlers:
    console_handler = logging.StreamHandler(stream=sys.stdout)
    console_handler.setLevel(logging.INFO)

    formatter = logging.Formatter(
        "%(asctime)s  %(name)s.%(funcName)s  %(levelname)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)


class SwitchRealtime:
    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        client_id: str,
        email: str, 
        project_id: str
    ):
        self.host = host
        self.port = port

        self.email = email
        self.project_id = project_id

        self.client_id = client_id
        self.client = mqtt.Client(client_id=client_id, transport='websockets', clean_session=True)
        self.client.tls_set()

        if username and password:
            self.client.username_pw_set(username, password)

        self.client.reconnect_delay_set(min_delay=1, max_delay=60)

        # Bind internal callbacks
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message

        self._connected = False
        self._connect_event = threading.Event()

        # Store all topic states here
        self.topic_state = {}

        # Retained Topic message tracking
        self._subscriptions = set()
        self._expected_topics = set()
        self._received_retained = set()
        self._retained_event = threading.Event()

    # -------------------------
    # Public API
    # -------------------------

    def connect(self, timeout: int = WS_MQTT_CONNECTION_TIMEOUT):
        """Connect to the MQTT broker"""

        if self._connected:
            return self._connected

        self._connect_event.clear()
        url = urlparse(self.host)

        logger.info(f'Attempting connection to MQTT broker with client_id={self.client_id} on host={self.host} port={self.port}')
        logger.info(f'hostname={url.hostname}')

        self.client.connect(host=url.hostname, port=self.port)
        self.client.loop_start() # Run network loop in background thread

        self._connected = self._connect_event.wait(timeout=timeout)

        return self._connected

    def subscribe_with_retained_sync(self, topics: Iterable[str], timeout: int = WS_MQTT_CONNECTION_TIMEOUT):
        """
        Subscribe to multiple topics and wait for retained messages.
        """
        # --- Validation ---
        if topics is None:
            raise ValueError("topics cannot be None")

        self.connect()

        topics = list(topics)

        if not topics:
            raise ValueError("topics cannot be empty")

        if not all(isinstance(t, str) and t.strip() for t in topics):
            raise ValueError("All topics must be non-empty strings")

        if not isinstance(timeout, int) or timeout <= 0:
            raise ValueError("timeout must be a positive integer")

        # --- Initialize tracking ---
        self._expected_topics = set(topics)
        self._received_retained = set()
        self._retained_event.clear()

        # --- Subscribe ---
        for topic in topics:
            self.client.subscribe(topic)
            logger.info(f"Subscribed to = {topic}")

        # --- Wait until all retained received OR timeout ---
        self._retained_event.wait(timeout=timeout)

        # --- Return only retained dataset ---
        return {
            topic: self.topic_state[topic]["payload"]
            for topic in self._received_retained
            if topic in self.topic_state
        }


    def publish(self, topic: str, payload: str, qos: int = 1, retain: bool = True):
        """
        Publish message to broker.
        Set retain=True to store as last known state.
        """
        result = self.client.publish(topic, payload, qos=qos, retain=retain)

        if result.rc != mqtt.MQTT_ERR_SUCCESS:
            logger.error(f"Failed to publish to {topic} : {json.loads(payload)}")



    # -------------------------
    # Internal Callbacks
    # -------------------------

    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            logger.info("Connected to MQTT broker.")
            self._connected = True
            self._connect_event.set()
        else:
            logger.error(f"Connection failed with code {rc}")

    def _on_disconnect(self, client, userdata, rc):
        """Event callback when client disconnected to MQTT broker"""
        logger.info(f'Disconnected from MQTT Broker.')
        self._connected = False

    def _on_message(self, client: mqtt.Client, userdata: any, message: MQTTMessage):
        """Event callback when a message received by the client

        Parameters
        ----------
        client: mqtt.Client
            The client instance for this callback
        userdata: any
            The private user data as set in Client() or user_data_set(). None for this workflow. 
        message: MQTTMessage
            An instance of MQTTMessage. This is a class with members topic, payload, qos, retain.
        """
        topic = message.topic
        payload = message.payload.decode()

        # Store everything (retained or live)
        self.topic_state[topic] = {
            "payload": payload,
            "is_retained": message.retain
        }

        # Retained message
        if message.retain and topic in self._expected_topics:
            self._received_retained.add(topic)

            # If all retained messages received
            if self._received_retained == self._expected_topics:
                self._retained_event.set()

        else:
           logger.info(f'MQTT Message - {topic} : {payload}')