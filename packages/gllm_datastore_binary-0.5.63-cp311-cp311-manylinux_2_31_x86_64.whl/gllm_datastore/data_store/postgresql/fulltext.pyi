from gllm_datastore.data_store.postgresql.query_translator import PostgreSQLQueryTranslator as PostgreSQLQueryTranslator
from gllm_datastore.data_store.sql.fulltext import SQLFulltextCapability as SQLFulltextCapability

class PostgreSQLFulltextCapability(SQLFulltextCapability):
    """PostgreSQL implementation of FulltextCapability protocol using async SQLAlchemy.

    This capability extends SQLFulltextCapability and uses PostgreSQLQueryTranslator
    for retrieve, update, and delete so that JSONB metadata filters (e.g. dot paths
    and array indexing) match PostgreSQL semantics. CRUD methods and translator
    caching are inherited from SQLFulltextCapability.

    Attributes:
        engine (AsyncEngine): SQLAlchemy async engine instance.
        session_factory (async_sessionmaker): Async session factory created from engine.
        table_name (str): Name of the table this capability operates on. This is immutable
            and defines the scope of all operations.
    """
    query_translator_class = PostgreSQLQueryTranslator
