from _typeshed import Incomplete
from gllm_core.schema.chunk import Chunk
from gllm_datastore.core.capabilities import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.postgresql.query_translator import PostgreSQLQueryTranslator as PostgreSQLQueryTranslator
from gllm_datastore.data_store.postgresql.utils import validate_sql_identifier as validate_sql_identifier, vector_to_pg_text as vector_to_pg_text
from gllm_datastore.data_store.sql.constants import SQL_COLUMNS as SQL_COLUMNS
from gllm_datastore.data_store.sql.query import execute_update_with_filters as execute_update_with_filters, row_to_chunk as row_to_chunk
from gllm_datastore.utils.converter import cosine_distance_to_similarity_score as cosine_distance_to_similarity_score
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_inference.schema import Vector
from sqlalchemy.ext.asyncio import AsyncEngine
from typing import Any

DEFAULT_VECTOR_TOP_K: int

class PostgreSQLVectorCapability:
    """PostgreSQL implementation of VectorCapability protocol using pgvector.

    This capability uses async SQLAlchemy with the pgvector extension for
    vector storage and cosine-distance similarity search. It operates on the
    same table as the fulltext capability (id, content, metadata) plus an
    embedding column of type vector(embedding_dimension).

    Attributes:
        engine (AsyncEngine): SQLAlchemy async engine instance.
        table_name (str): Name of the table this capability operates on.
        embedding_column (str): Name of the vector column.
        embedding_dimension (int): Dimension of the embedding vectors.
        session_factory (async_sessionmaker): Async session factory.
    """
    engine: Incomplete
    table_name: Incomplete
    embedding_column: Incomplete
    embedding_dimension: Incomplete
    session_factory: Incomplete
    def __init__(self, engine: AsyncEngine, table_name: str, embedding_column: str, embedding_dimension: int, em_invoker: BaseEMInvoker, encryption: EncryptionCapability | None = None) -> None:
        """Initialize the PostgreSQL vector capability.

        Args:
            engine (AsyncEngine): SQLAlchemy async engine instance.
            table_name (str): Name of the table this capability operates on.
            embedding_column (str): Name of the embedding column for vector operations.
            embedding_dimension (int): Dimension of the embedding vectors.
            em_invoker (BaseEMInvoker): Embedding model for vectorization.
            encryption (EncryptionCapability | None, optional): Encryption capability.
                Defaults to None.
        """
    @property
    def em_invoker(self) -> BaseEMInvoker:
        """Return the embedding model invoker.

        Returns:
            BaseEMInvoker: The EM invoker instance.
        """
    async def ensure_index(self) -> None:
        """Ensure pgvector extension and embedding column exist.

        Creates the vector extension if not present and adds the embedding
        column to the table if it does not exist. Idempotent.
        """
    async def create(self, data: Chunk | list[Chunk]) -> None:
        """Add chunks to the vector store with automatic embedding generation.

        Args:
            data (Chunk | list[Chunk]): Single chunk or list of chunks to add.

        Raises:
            ValueError: If chunk content is empty or invalid.
            RuntimeError: If the operation fails.
        """
    async def create_from_vector(self, chunk_vectors: list[tuple[Chunk, Vector]], **kwargs: Any) -> None:
        """Add pre-computed vectors directly.

        Args:
            chunk_vectors (list[tuple[Chunk, Vector]]): Chunks and their vectors.
            **kwargs (Any): Unused; for protocol compatibility.

        Raises:
            ValueError: If chunk content is invalid.
            RuntimeError: If the operation fails.
        """
    async def retrieve(self, query: str, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None, **kwargs: Any) -> list[Chunk]:
        """Read records using text-based similarity search with optional filtering.

        Args:
            query (str): Input text to embed and search with.
            filters (FilterClause | QueryFilter | None, optional): Query filters.
            options (QueryOptions | None, optional): Query options (e.g. limit).
            **kwargs (Any): Unused; for protocol compatibility.

        Returns:
            list[Chunk]: Chunks ordered by similarity score.
        """
    async def retrieve_by_vector(self, vector: Vector, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None) -> list[Chunk]:
        """Direct vector similarity search using cosine distance.

        Args:
            vector (Vector): Query embedding vector.
            filters (FilterClause | QueryFilter | None, optional): Query filters.
            options (QueryOptions | None, optional): Query options (e.g. limit).

        Returns:
            list[Chunk]: Chunks ordered by similarity score.
        """
    async def update(self, update_values: dict[str, Any], filters: FilterClause | QueryFilter | None = None) -> None:
        """Update existing records in the datastore.

        If update_values contains content, embeddings are recomputed for
        updated rows when the table has an embedding column.

        Args:
            update_values (dict[str, Any]): Values to update.
            filters (FilterClause | QueryFilter | None, optional): Filters to select rows.
        """
    async def delete(self, filters: FilterClause | QueryFilter | None = None) -> None:
        """Delete records from the datastore.

        Args:
            filters (FilterClause | QueryFilter | None, optional): Filters to select rows.
        """
    async def clear(self) -> None:
        """Clear all records from the table."""
