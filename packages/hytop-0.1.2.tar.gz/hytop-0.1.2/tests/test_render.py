"""Tests for hytop.gpu.render formatting helpers."""

from __future__ import annotations

from hytop.gpu.render import _format_metric, fmt_elapsed, fmt_window


class TestFmtWindow:
    def test_integer_seconds(self):
        assert fmt_window(5.0) == "5s"

    def test_fractional_seconds(self):
        assert fmt_window(0.5) == "0.5s"

    def test_large_integer(self):
        assert fmt_window(300.0) == "300s"

    def test_non_round_float(self):
        assert fmt_window(1.25) == "1.2s"


class TestFmtElapsed:
    def test_zero(self):
        assert fmt_elapsed(0) == "00:00:00"

    def test_seconds_only(self):
        assert fmt_elapsed(45) == "00:00:45"

    def test_minutes_and_seconds(self):
        assert fmt_elapsed(90) == "00:01:30"

    def test_hours(self):
        assert fmt_elapsed(3661) == "01:01:01"

    def test_negative_clamped_to_zero(self):
        assert fmt_elapsed(-5) == "00:00:00"


class TestFormatMetric:
    def test_none_returns_dash(self):
        assert _format_metric("temp_c", None) == "-"

    def test_temp_format(self):
        result = _format_metric("temp_c", 30.0)
        assert "30.0" in result
        assert "C" in result

    def test_power_format(self):
        result = _format_metric("avg_pwr_w", 157.0)
        assert "157.0" in result
        assert "W" in result

    def test_pct_format_vram(self):
        result = _format_metric("vram_pct", 89.0)
        assert "89.00" in result
        assert "%" in result

    def test_pct_format_hcu(self):
        result = _format_metric("hcu_pct", 0.0)
        assert "0.00" in result and "%" in result

    def test_sclk_format(self):
        result = _format_metric("sclk_mhz", 1500.0)
        assert "1500" in result
        assert "MHz" in result

    def test_unknown_metric_str(self):
        assert _format_metric("unknown", 42) == "42"
