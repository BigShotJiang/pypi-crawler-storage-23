from wbcore.menus import ItemPermission, MenuItem

INVOICE_MENUITEM = MenuItem(
    label="Invoices",
    endpoint="wbaccounting:invoice-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbaccounting.view_invoice"]
    ),
    add=MenuItem(
        label="Create Invoice",
        endpoint="wbaccounting:invoice-list",
        permission=ItemPermission(permissions=["wbaccounting.add_invoice"]),
    ),
)
