"""A terminal user interface for managing hledger journal transactions."""
