import respx
from httpx import Response

from kraken_sdk import KrakenClient


@respx.mock
def test_client_prefixes_pcs_service_path() -> None:
    respx.get("https://pcs.example.com/services/kraken/api/v1/info").mock(
        return_value=Response(
            200,
            json={
                "service": "kraken",
                "version": "1.0.0",
                "description": "Kraken service",
                "timestamp": "2024-01-01T00:00:00Z",
                "capabilities": {},
                "endpoints": {},
            },
        )
    )

    client = KrakenClient(base_url="https://pcs.example.com", api_key="test-api-key")

    info = client.info.info()

    assert info.service == "kraken"


@respx.mock
def test_client_does_not_duplicate_embedded_service_path() -> None:
    respx.get("https://pcs.example.com/services/kraken/api/v1/info").mock(
        return_value=Response(
            200,
            json={
                "service": "kraken",
                "version": "1.0.0",
                "description": "Kraken service",
                "timestamp": "2024-01-01T00:00:00Z",
                "capabilities": {},
                "endpoints": {},
            },
        )
    )

    client = KrakenClient(
        base_url="https://pcs.example.com/services/kraken",
        api_key="test-api-key",
    )

    info = client.info.info()

    assert info.service == "kraken"


@respx.mock
def test_client_supports_direct_internal_urls_when_proxy_disabled() -> None:
    respx.get("https://kraken.internal.example.com/api/v1/info").mock(
        return_value=Response(
            200,
            json={
                "service": "kraken",
                "version": "1.0.0",
                "description": "Kraken service",
                "timestamp": "2024-01-01T00:00:00Z",
                "capabilities": {},
                "endpoints": {},
            },
        )
    )

    client = KrakenClient(
        base_url="https://kraken.internal.example.com",
        api_key="test-api-key",
        use_pcs_proxy=False,
    )

    info = client.info.info()

    assert info.service == "kraken"
