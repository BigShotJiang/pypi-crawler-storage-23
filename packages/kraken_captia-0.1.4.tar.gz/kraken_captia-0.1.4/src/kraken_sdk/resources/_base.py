"""Shared base classes for resources."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..transport import HttpxAsyncTransport, HttpxTransport


class BaseResource:
    def __init__(self, transport: "HttpxTransport"):
        self._transport = transport


class AsyncBaseResource:
    def __init__(self, transport: "HttpxAsyncTransport"):
        self._transport = transport
