"""Benchmarks resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, BinaryIO

from .._generated.models import (
    AggregatedBenchmarkReportResponse,
    BenchmarkReportResponse,
    BenchmarkResponse,
    CreateBenchmarkRequest,
    CreateExpectedResultRequest,
    ExpectedResultResponse,
)
from .._utils.files import get_file_content
from ._base import AsyncBaseResource, BaseResource

if TYPE_CHECKING:
    from collections.abc import Sequence

ReportType = BenchmarkReportResponse | AggregatedBenchmarkReportResponse


class BenchmarksResource(BaseResource):
    def create(self, request: CreateBenchmarkRequest) -> BenchmarkResponse:
        return BenchmarkResponse(
            **self._transport.request(
                "POST", "/api/v1/benchmarks", json=request.model_dump(mode="json")
            )
        )

    def list(self, limit: int = 50) -> list[BenchmarkResponse]:
        return [
            BenchmarkResponse(**i)
            for i in self._transport.request(
                "GET", "/api/v1/benchmarks", params={"limit": limit}
            )
        ]

    def get(self, benchmark_id: str) -> BenchmarkResponse:
        return BenchmarkResponse(
            **self._transport.request("GET", f"/api/v1/benchmarks/{benchmark_id}")
        )

    def report(self, benchmark_id: str) -> ReportType:
        resp = self._transport.request(
            "GET", f"/api/v1/benchmarks/{benchmark_id}/report"
        )
        cls = (
            AggregatedBenchmarkReportResponse
            if resp.get("report_type") == "aggregated"
            else BenchmarkReportResponse
        )
        return cls(**resp)

    def get_report(self, benchmark_id: str) -> ReportType:
        return self.report(benchmark_id)

    def create_expected_result(
        self, request: CreateExpectedResultRequest
    ) -> ExpectedResultResponse:
        return ExpectedResultResponse(
            **self._transport.request(
                "POST",
                "/api/v1/benchmarks/expected-results",
                json=request.model_dump(mode="json"),
            )
        )

    def upload_expected_result(
        self,
        file: str | bytes | BinaryIO,
        source_id: str,
        result_type: str,
        format: str,
        description: str | None = None,
        name: str | None = None,
    ) -> ExpectedResultResponse:
        filename, content, content_type = get_file_content(file, name)
        files = {"file": (filename, content, content_type)}
        data = {
            "source_id": source_id,
            "result_type": result_type,
            "format": format,
        }
        if description:
            data["description"] = description
        return ExpectedResultResponse(
            **self._transport.request(
                "POST",
                "/api/v1/benchmarks/expected-results/upload",
                files=files,
                data=data,
            )
        )

    def get_expected_result(self, expected_result_id: str) -> ExpectedResultResponse:
        return ExpectedResultResponse(
            **self._transport.request(
                "GET",
                f"/api/v1/benchmarks/expected-results/{expected_result_id}",
            )
        )

    def list_expected_results(self, source_id: str) -> Sequence[ExpectedResultResponse]:
        return [
            ExpectedResultResponse(**item)
            for item in self._transport.request(
                "GET",
                "/api/v1/benchmarks/expected-results",
                params={"source_id": source_id},
            )
        ]


class AsyncBenchmarksResource(AsyncBaseResource):
    async def create(self, request: CreateBenchmarkRequest) -> BenchmarkResponse:
        return BenchmarkResponse(
            **await self._transport.request(
                "POST", "/api/v1/benchmarks", json=request.model_dump(mode="json")
            )
        )

    async def list(self, limit: int = 50) -> list[BenchmarkResponse]:
        return [
            BenchmarkResponse(**i)
            for i in await self._transport.request(
                "GET", "/api/v1/benchmarks", params={"limit": limit}
            )
        ]

    async def get(self, benchmark_id: str) -> BenchmarkResponse:
        return BenchmarkResponse(
            **await self._transport.request("GET", f"/api/v1/benchmarks/{benchmark_id}")
        )

    async def report(self, benchmark_id: str) -> ReportType:
        resp = await self._transport.request(
            "GET", f"/api/v1/benchmarks/{benchmark_id}/report"
        )
        cls = (
            AggregatedBenchmarkReportResponse
            if resp.get("report_type") == "aggregated"
            else BenchmarkReportResponse
        )
        return cls(**resp)

    async def get_report(self, benchmark_id: str) -> ReportType:
        return await self.report(benchmark_id)

    async def create_expected_result(
        self, request: CreateExpectedResultRequest
    ) -> ExpectedResultResponse:
        return ExpectedResultResponse(
            **await self._transport.request(
                "POST",
                "/api/v1/benchmarks/expected-results",
                json=request.model_dump(mode="json"),
            )
        )

    async def upload_expected_result(
        self,
        file: str | bytes | BinaryIO,
        source_id: str,
        result_type: str,
        format: str,
        description: str | None = None,
        name: str | None = None,
    ) -> ExpectedResultResponse:
        filename, content, content_type = get_file_content(file, name)
        files = {"file": (filename, content, content_type)}
        data = {
            "source_id": source_id,
            "result_type": result_type,
            "format": format,
        }
        if description:
            data["description"] = description
        return ExpectedResultResponse(
            **await self._transport.request(
                "POST",
                "/api/v1/benchmarks/expected-results/upload",
                files=files,
                data=data,
            )
        )

    async def get_expected_result(
        self, expected_result_id: str
    ) -> ExpectedResultResponse:
        return ExpectedResultResponse(
            **await self._transport.request(
                "GET",
                f"/api/v1/benchmarks/expected-results/{expected_result_id}",
            )
        )

    async def list_expected_results(
        self, source_id: str
    ) -> Sequence[ExpectedResultResponse]:
        return [
            ExpectedResultResponse(**item)
            for item in await self._transport.request(
                "GET",
                "/api/v1/benchmarks/expected-results",
                params={"source_id": source_id},
            )
        ]
