"""Porto data package: Deutsche Post shipping data, schemas, and metadata."""
