import uuid
from datetime import datetime

from tp_helper.base_items.base_schema import BaseSchema

from tp_shared.telegram_hub.types.telegram_hub_types import (
    TelegramHubChatMessageErrorType,
)


class TelegramHubResultsUser(BaseSchema):
    is_bot: bool | None = (
        None  # при событии отправки будет None; телеграм не даёт запросить это при отправке
    )
    user_id: int
    username: str | None
    first_name: str | None = None
    last_name: str | None = None
    language_code: str | None = (
        None  # при событии отправки будет None; телеграм не даёт запросить это при отправке
    )
    birthdate: datetime | None = None


class TelegramHubResultsBot(TelegramHubResultsUser): ...


class TelegramHubResultsMessage(BaseSchema):
    bot: TelegramHubResultsBot
    user: TelegramHubResultsUser
    member_id: uuid.UUID | None = None
    message_id: int
    text: str
    sender_id: int
    recipient_id: int
    sent_at: datetime
    error_type: TelegramHubChatMessageErrorType | None = None
    error_message: str | None = None
