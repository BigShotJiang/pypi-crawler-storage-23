# Quickstart

## One-line run (preset-driven)

```python
from dpo import dpo

result = dpo(preset="nas")
print(result["best_fitness"])
```

## Recommended: explicit universal interface

```python
from dpo.core.universal import DPO_Universal, DPO_Presets

config = DPO_Presets.NAS_Config(population_size=40, max_iterations=80)
optimizer = DPO_Universal(config=config)
result = optimizer.optimize()

print(result["best_fitness"])
print(result.get("best_accuracy"))
```

## Continuous optimization in 10 lines

```python
from dpo import dpo_optimize

def objective(params):
	x, y = params["x"], params["y"]
	fitness = (x - 2.0)**2 + (y + 1.5)**2
	return fitness, {
		"accuracy": 1 / (1 + fitness),
		"latency_ms": abs(x) + abs(y),
		"memory_mb": 1.0,
		"flops_m": 1.0,
	}

result = dpo_optimize(
	objective=objective,
	bounds=[(-5, 5), (-5, 5)],
	names=["x", "y"],
	preset="continuous",
)
print(result["best_solution"])
```
