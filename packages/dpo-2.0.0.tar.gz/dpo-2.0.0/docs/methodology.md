# DPO-NAS: Methodology

## Overview

**DPO-NAS** (Debt-Paying Optimizer for Neural Architecture Search) is a population-based metaheuristic that frames exploration as *financial debt* — moves that sacrifice immediate fitness accumulate debt, which is forcibly repaid later, creating directional momentum through the search space.

---

## Search Space & Encoding

Each candidate architecture is encoded as a continuous gene vector $\mathbf{x} \in \mathbb{R}^D$ comprising:

| Segment | Encoding | Bounds |
|---|---|---|
| Operations ($L$) | Categorical index | $[0, \|\text{OPS}\|)$ |
| Kernels ($L$) | Categorical index | $[0, \|\text{KERN}\|)$ |
| Skip connections ($C$) | Binary probability | $[0, 1]$ |
| Width multipliers (2) | Real-valued | $[0.3, 2.0]$ |

In **continuous mode** all positions are real-valued $\in [0,1]$, enabling the same engine to solve HPO and continuous black-box problems.

---

## Island Population Model

The population of $N$ agents is partitioned into $K$ islands with specialised roles:

- **Island 0 — Accuracy-heavy:** penalises cost more aggressively.
- **Island 1 — Cost-heavy:** penalises low accuracy.
- **Island 2+ — Balanced:** standard weighted fitness.

Periodic **diversity-preserving migration** transfers the most genetically distant agents (not merely the best) between islands, preventing premature convergence while sharing discoveries.

---

## Fitness Function

$$f(\mathbf{x}) = w_a (1 - \text{acc}) + w_c \cdot \bar{c} + w_p \cdot p + 0.01 \cdot r_p$$

| Term | Meaning |
|---|---|
| $w_a(1-\text{acc})$ | Accuracy penalty |
| $w_c \cdot \bar{c}$ | Normalised hardware cost (latency + FLOPs + memory) |
| $w_p \cdot p$ | Adaptive constraint penalty |
| $0.01 \cdot r_p$ | NSGA-II Pareto rank regulariser |

Costs are normalised dynamically against running population statistics. Architecture clones receive a $+0.02$ penalty to enforce diversity.

---

## Core DPO Step

Each agent $i$ generates a candidate $\mathbf{x}'$ via:

$$\mathbf{x}' = \mathbf{x}_i + \underbrace{\alpha \,\boldsymbol{\epsilon}}_{\text{explore}} - \underbrace{b_\text{flow}}_{\text{backflow}} + \underbrace{\mu \mathbf{v}}_{\text{momentum}} + \underbrace{s_e \hat{\mathbf{d}}_\text{best}}_{\text{exploit}} + \underbrace{F(\mathbf{x}_a - \mathbf{x}_b)}_{\text{DE cross}}$$

**Debt Accumulation** ($\beta$): When a worse move is accepted, $\delta\mathbf{x}$ is added to the agent's debt vector $\mathbf{d}$.

**Debt Repayment** ($\beta$): The debt vector pulls future moves *back* toward lost ground — momentum through failure.

**Overshoot** ($\gamma$): Once debt is paid, the agent continues past the repayment point, escaping local optima.

**Global pull** ($\delta$): Attraction toward the island-best position scales with current debt magnitude.

---

## Non-Markovian Memory

Two mechanisms extend memory beyond the current step:

1. **Debt Reservoir** — stores the last 5 failed debt vectors.
2. **Debt Backflow** — inversely exponentially weighted sum of reservoir entries, subtracted from the next perturbation to avoid repeating bad directions.

$$b_\text{flow} = 0.15 \sum_{k} w_k \mathbf{d}_k, \quad w_k \propto 0.5^{(K-k-1)}$$

---

## Adaptive Parameters (3-Phase Schedule)

| Phase | $t$ range | Behaviour |
|---|---|---|
| Exploration | $< 0.4$ | High $\alpha$, low $\beta$, moderate $\gamma$ |
| Transition | $0.4 – 0.6$ | Balanced accumulation/repayment |
| Convergence | $> 0.6$ | Near-zero $\alpha$, max $\beta$, full $\delta$; greedy acceptance locked at $t > 0.65$ |

A **Variable Interest Rate** multiplies repayment force exponentially ($\times 1.1^{\text{stagnation}}$, capped at $3\times$) whenever an agent fails to improve, forcing escapes from local basins.

---

## Acceptance Criterion

$$P(\text{accept}) = \exp\!\left(\frac{-\Delta f}{\tau \cdot d_\text{factor} \cdot \varphi_\text{phase} \cdot \text{div}}\right)$$

- **Debt factor** $d_\text{factor}$: up to $3\times$ more likely to accept worse moves when debt is high.
- **Phase factor** $\varphi$: linearly decays $1.4 \to 0.4$ over run time.
- **Temperature** $\tau$: three-stage decay (fast/medium/slow cooling by phase).
- Hard greedy mode enforced for $t > 0.65$.

---

## Multi-Objective Survival (NSGA-II)

Island populations are pruned via non-dominated sorting + crowding distance, preserving solutions along the accuracy–cost Pareto front rather than discarding all but the scalar-best.

---

## Late-Phase Convergence Mechanisms

| Mechanism | Trigger | Effect |
|---|---|---|
| **Local Elite Search** | $t > 0.5$, stagnation | 15 micro-mutations on top-3 agents |
| **Elite-Only Mode** | $t > 0.8$ | Re-optimise top 25% every iteration |
| **Exploitation Lockdown** | $t > 0.85$ | Migration and diversity injection disabled |
| **Opposition-Based Learning** | Stagnation $> 1.5\times$ threshold | Candidate flipped to $\mathbf{x}_\text{min} + \mathbf{x}_\text{max} - \mathbf{x}$ |

---

## Output

The optimizer returns the **accuracy-best** agent (not fitness-best) after a final noiseless ensemble re-evaluation, along with full convergence history, AUC@{10,25,50}, iterations-to-{95%,99%} accuracy, and Pareto archive.
