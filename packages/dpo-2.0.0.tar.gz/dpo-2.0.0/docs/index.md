# DPO Documentation

This documentation describes the current DPO API for multi-domain optimization.

## What is DPO?

DPO (Debt-Paying Optimizer) is a population-based optimizer that supports:

- Neural Architecture Search (NAS)
- Hyperparameter optimization (HPO)
- Pathfinding / TSP / combinatoric search
- Continuous black-box optimization
- Hybrid mixed-variable optimization

## Documentation Map

- [Installation](installation.md)
- [Quickstart](quickstart.md)
- [API Reference](api_reference.md)
- [Examples](examples.md)
- [Methodology](methodology.md)

## Recommended Entry Point

For most projects, use:

```python
from dpo.core.universal import DPO_Universal, DPO_Presets
```

For one-line convenience helpers:

```python
from dpo import dpo, dpo_optimize, dpo_solve_tsp, dpo_solve_nas
```
