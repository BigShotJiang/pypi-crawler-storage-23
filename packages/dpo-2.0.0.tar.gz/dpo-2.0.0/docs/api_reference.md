# API Reference

## dpo.core.config

- `DPO_Config`: Main configuration dataclass.
- Presets: `fast()`, `balanced()`, `thorough()`, `publication()`, `continuous_analytic()`.
- Resolver: `DPO_Config.from_preset(name)`.

## dpo.core.agent

- `SearchAgent`: Population member representation used by the optimizer.

## dpo.architecture.gene

- `ArchitectureGene`: NAS architecture encoding and mutation/crossover helpers.

## dpo.evaluation.ensemble

- `EnsembleEstimator`
- `ProblemBasedEstimator`

## dpo.constraints.handler

- `AdvancedConstraintHandler`: Constraint validation and adaptive penalty handling.

## dpo.core.optimizer

- `DPO_NAS`: Core optimization engine.
- Primary method: `optimize()`.

## dpo.core.universal

- `DPO_Universal`: Recommended high-level optimizer for all supported problem types.
- `DPO_Presets`: Problem-specific tuned config factories.

## dpo.core.problem

- `Problem` (abstract base class)
- `ContinuousOptimizationProblem`
- `CombinatoricOptimizationProblem`
- `NASProblem`
- `HybridProblem`

## dpo.core.solution

- `Solution`
- `NumericSolution`
- `CombinatoricSolution`
- `HybridSolution`

## Top-level convenience helpers (`dpo` package)

- `dpo(...)`
- `dpo_optimize(...)`
- `dpo_solve_tsp(...)`
- `dpo_solve_nas(...)`
