# Examples

All examples are in `dpo/examples/` and are runnable as regular Python scripts.

## Problem-focused examples

- `example_nas.py` — NAS search using a mock estimator and NAS presets.
- `example_hpo.py` — continuous hyperparameter optimization scenarios.
- `example_tsp.py` — combinatoric optimization for TSP.
- `example_pathfinding.py` — grid pathfinding with obstacles.
- `example_resource_allocation.py` — constrained resource allocation.
- `example_hybrid.py` — mixed continuous + discrete optimization.

## Running an example

```bash
python -m dpo.examples.example_nas
python -m dpo.examples.example_hpo
python -m dpo.examples.example_tsp
```

## Writing your own example

1. Define an objective or implement a custom `Problem`.
2. Choose a preset from `DPO_Presets`.
3. Run `DPO_Universal(problem=..., config=...).optimize()`.
4. Report `best_fitness`, `best_solution`, and `best_metrics`.
