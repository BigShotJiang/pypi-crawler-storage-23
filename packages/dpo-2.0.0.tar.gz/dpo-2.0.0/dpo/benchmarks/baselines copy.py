import numpy as np

class PSO:
    """Kennedy & Eberhart (1995) - Particle Swarm Optimization"""
    def __init__(self, pop_size=30, c1=2.0, c2=2.0, w=0.7):
        self.pop_size = pop_size
        self.c1, self.c2, self.w = c1, c2, w

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        # Handle both scalar and array bounds
        lb = np.array(bounds[0]) if hasattr(bounds[0], '__len__') else np.full(dim, bounds[0])
        ub = np.array(bounds[1]) if hasattr(bounds[1], '__len__') else np.full(dim, bounds[1])
        
        positions = np.random.uniform(lb, ub, (self.pop_size, dim))
        velocities = np.random.uniform(-0.1, 0.1, (self.pop_size, dim))
        pbest_positions = positions.copy()
        pbest_fitness = np.array([objective_fn(p) for p in positions])
        gbest_idx = np.argmin(pbest_fitness)
        convergence = []

        for iteration in range(max_iterations):
            w = self.w * (1 - iteration / max_iterations)

            for i in range(self.pop_size):
                r1, r2 = np.random.rand(2)
                velocities[i] = (
                    w * velocities[i] +
                    self.c1 * r1 * (pbest_positions[i] - positions[i]) +
                    self.c2 * r2 * (positions[gbest_idx] - positions[i])
                )

                positions[i] = np.clip(positions[i] + velocities[i], lb, ub)
                fitness_i = objective_fn(positions[i])

                if fitness_i < pbest_fitness[i]:
                    pbest_fitness[i] = fitness_i
                    pbest_positions[i] = positions[i]

                    if fitness_i < pbest_fitness[gbest_idx]:
                        gbest_idx = i

            convergence.append(pbest_fitness[gbest_idx])

        return positions[gbest_idx], pbest_fitness[gbest_idx], convergence

class GWO:
    """Mirjalili et al. (2014) - Grey Wolf Optimizer"""
    def __init__(self, pop_size=30):
        self.pop_size = pop_size

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        # Handle both scalar and array bounds
        lb = np.array(bounds[0]) if hasattr(bounds[0], '__len__') else np.full(dim, bounds[0])
        ub = np.array(bounds[1]) if hasattr(bounds[1], '__len__') else np.full(dim, bounds[1])
        
        positions = np.random.uniform(lb, ub, (self.pop_size, dim))
        fitness = np.array([objective_fn(p) for p in positions])

        sorted_indices = np.argsort(fitness)
        alpha_pos = positions[sorted_indices[0]].copy()
        beta_pos = positions[sorted_indices[1]].copy() if self.pop_size > 1 else alpha_pos.copy()
        delta_pos = positions[sorted_indices[2]].copy() if self.pop_size > 2 else alpha_pos.copy()
        convergence = []

        for iteration in range(max_iterations):
            a = 2 - 2 * (iteration / max_iterations)

            for i in range(self.pop_size):
                for d in range(dim):
                    r1, r2 = np.random.rand(2)
                    A1 = 2 * a * r1 - a
                    C1 = 2 * r2
                    X1 = alpha_pos[d] - A1 * abs(C1 * alpha_pos[d] - positions[i, d])

                    r1, r2 = np.random.rand(2)
                    A2 = 2 * a * r1 - a
                    C2 = 2 * r2
                    X2 = beta_pos[d] - A2 * abs(C2 * beta_pos[d] - positions[i, d])

                    r1, r2 = np.random.rand(2)
                    A3 = 2 * a * r1 - a
                    C3 = 2 * r2
                    X3 = delta_pos[d] - A3 * abs(C3 * delta_pos[d] - positions[i, d])

                    positions[i, d] = np.clip((X1 + X2 + X3) / 3, lb[d], ub[d])

            fitness = np.array([objective_fn(p) for p in positions])
            sorted_indices = np.argsort(fitness)

            alpha_pos = positions[sorted_indices[0]].copy()
            if self.pop_size > 1:
                beta_pos = positions[sorted_indices[1]].copy()
            if self.pop_size > 2:
                delta_pos = positions[sorted_indices[2]].copy()

            convergence.append(fitness[sorted_indices[0]])

        return alpha_pos, fitness[sorted_indices[0]], convergence

class GA:
    """Holland (1975) - Genetic Algorithm"""
    def __init__(self, pop_size=30, mutation_rate=0.1, crossover_rate=0.8):
        self.pop_size = pop_size
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        population = np.random.uniform(bounds[0], bounds[1], (self.pop_size, dim))
        convergence = []

        for iteration in range(max_iterations):
            fitness = np.array([objective_fn(ind) for ind in population])
            best_idx = np.argmin(fitness)
            convergence.append(fitness[best_idx])

            # Selection via fitness-based probability
            probabilities = 1.0 / (fitness + 1e-10)
            probabilities /= probabilities.sum()

            new_population = []
            for _ in range(self.pop_size):
                parent1_idx, parent2_idx = np.random.choice(
                    self.pop_size, 2, p=probabilities, replace=False
                )

                # Crossover
                child = (population[parent1_idx] + population[parent2_idx]) / 2

                # Mutation
                if np.random.rand() < self.mutation_rate:
                    mutation = np.random.normal(0, 0.1, dim)
                    child = child + mutation

                child = np.clip(child, bounds[0], bounds[1])
                new_population.append(child)

            population = np.array(new_population)

        fitness = np.array([objective_fn(ind) for ind in population])
        best_idx = np.argmin(fitness)
        return population[best_idx], fitness[best_idx], convergence

class DE:
    """Storn & Price (1997) - Differential Evolution"""
    def __init__(self, pop_size=30, F=0.8, CR=0.9):
        self.pop_size = pop_size
        self.F = F  # Differential weight
        self.CR = CR  # Crossover probability

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        # Handle both scalar and array bounds
        lb = np.array(bounds[0]) if hasattr(bounds[0], '__len__') else np.full(dim, bounds[0])
        ub = np.array(bounds[1]) if hasattr(bounds[1], '__len__') else np.full(dim, bounds[1])
        
        population = np.random.uniform(lb, ub, (self.pop_size, dim))
        fitness = np.array([objective_fn(p) for p in population])
        convergence = []

        for iteration in range(max_iterations):
            for i in range(self.pop_size):
                # Select three random distinct individuals
                a, b, c = np.random.choice(self.pop_size, 3, replace=False)

                # Mutation: create mutant vector
                mutant = population[a] + self.F * (population[b] - population[c])
                mutant = np.clip(mutant, lb, ub)

                # Crossover: create trial vector
                trial = population[i].copy()
                for d in range(dim):
                    if np.random.rand() < self.CR:
                        trial[d] = mutant[d]

                # Selection: accept if better
                trial_fitness = objective_fn(trial)
                if trial_fitness < fitness[i]:
                    population[i] = trial
                    fitness[i] = trial_fitness

            convergence.append(np.min(fitness))

        best_idx = np.argmin(fitness)
        return population[best_idx], fitness[best_idx], convergence

class SA:
    """Kirkpatrick et al. (1983) - Simulated Annealing"""
    def __init__(self, temp_start=1.0, temp_min=1e-3, cooling=0.98, step_scale=0.1):
        self.temp_start = temp_start
        self.temp_min = temp_min
        self.cooling = cooling
        self.step_scale = step_scale

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        lb = np.array(bounds[0]) if hasattr(bounds[0], '__len__') else np.full(dim, bounds[0])
        ub = np.array(bounds[1]) if hasattr(bounds[1], '__len__') else np.full(dim, bounds[1])
        current = np.random.uniform(lb, ub, dim)
        current_fit = objective_fn(current)
        best = current.copy()
        best_fit = current_fit
        temp = self.temp_start
        convergence = []

        for _ in range(max_iterations):
            step = np.random.normal(0.0, self.step_scale, dim)
            candidate = np.clip(current + step, lb, ub)
            cand_fit = objective_fn(candidate)
            delta = cand_fit - current_fit
            if delta < 0 or np.random.rand() < np.exp(-delta / max(temp, 1e-12)):
                current = candidate
                current_fit = cand_fit
            if current_fit < best_fit:
                best = current.copy()
                best_fit = current_fit
            convergence.append(best_fit)
            temp = max(self.temp_min, temp * self.cooling)

        return best, best_fit, convergence

class JADE:
    """Zhang & Sanderson (2009) - Adaptive Differential Evolution (JADE)"""
    def __init__(self, pop_size=30, p_best=0.2, c=0.1):
        self.pop_size = pop_size
        self.p_best = p_best
        self.c = c

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        lb = np.array(bounds[0]) if hasattr(bounds[0], '__len__') else np.full(dim, bounds[0])
        ub = np.array(bounds[1]) if hasattr(bounds[1], '__len__') else np.full(dim, bounds[1])

        population = np.random.uniform(lb, ub, (self.pop_size, dim))
        fitness = np.array([objective_fn(p) for p in population])
        convergence = []

        mu_f = 0.5
        mu_cr = 0.5

        for _ in range(max_iterations):
            new_population = []
            new_fitness = []
            s_f = []
            s_cr = []

            p_num = max(2, int(self.p_best * self.pop_size))
            best_indices = np.argsort(fitness)[:p_num]

            for i in range(self.pop_size):
                cr = np.clip(np.random.normal(mu_cr, 0.1), 0.0, 1.0)
                f = np.clip(np.random.standard_cauchy() * 0.1 + mu_f, 0.1, 1.0)

                pbest = population[np.random.choice(best_indices)]
                candidates = [idx for idx in range(self.pop_size) if idx != i]
                r1, r2 = np.random.choice(candidates, 2, replace=False)
                x_i = population[i]
                mutant = x_i + f * (pbest - x_i) + f * (population[r1] - population[r2])
                mutant = np.clip(mutant, lb, ub)

                jrand = np.random.randint(dim)
                trial = np.array([
                    mutant[j] if (np.random.rand() < cr or j == jrand) else x_i[j]
                    for j in range(dim)
                ])

                trial_fit = objective_fn(trial)
                if trial_fit <= fitness[i]:
                    new_population.append(trial)
                    new_fitness.append(trial_fit)
                    s_f.append(f)
                    s_cr.append(cr)
                else:
                    new_population.append(x_i)
                    new_fitness.append(fitness[i])

            population = np.array(new_population)
            fitness = np.array(new_fitness)
            if s_f:
                mu_f = (1 - self.c) * mu_f + self.c * (np.sum(np.square(s_f)) / max(1e-12, np.sum(s_f)))
            if s_cr:
                mu_cr = (1 - self.c) * mu_cr + self.c * np.mean(s_cr)

            convergence.append(float(np.min(fitness)))

        best_idx = int(np.argmin(fitness))
        return population[best_idx], fitness[best_idx], convergence

class WOA:
    """Mirjalili & Lewis (2016) - Whale Optimization Algorithm"""
    def __init__(self, pop_size=30):
        self.pop_size = pop_size

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        lb = np.array(bounds[0]) if hasattr(bounds[0], '__len__') else np.full(dim, bounds[0])
        ub = np.array(bounds[1]) if hasattr(bounds[1], '__len__') else np.full(dim, bounds[1])
        positions = np.random.uniform(lb, ub, (self.pop_size, dim))
        fitness = np.array([objective_fn(p) for p in positions])
        best_idx = int(np.argmin(fitness))
        best_pos = positions[best_idx].copy()
        best_fit = float(fitness[best_idx])
        convergence = []

        for iteration in range(max_iterations):
            a = 2.0 - 2.0 * (iteration / max_iterations)
            for i in range(self.pop_size):
                r1, r2 = np.random.rand(2)
                A = 2.0 * a * r1 - a
                C = 2.0 * r2
                p = np.random.rand()

                if p < 0.5:
                    if abs(A) < 1:
                        D = abs(C * best_pos - positions[i])
                        positions[i] = best_pos - A * D
                    else:
                        rand_idx = np.random.randint(self.pop_size)
                        rand_pos = positions[rand_idx]
                        D = abs(C * rand_pos - positions[i])
                        positions[i] = rand_pos - A * D
                else:
                    b = 1.0
                    l = np.random.uniform(-1.0, 1.0)
                    D = abs(best_pos - positions[i])
                    positions[i] = D * np.exp(b * l) * np.cos(2 * np.pi * l) + best_pos

                positions[i] = np.clip(positions[i], lb, ub)

            fitness = np.array([objective_fn(p) for p in positions])
            best_idx = int(np.argmin(fitness))
            if fitness[best_idx] < best_fit:
                best_fit = float(fitness[best_idx])
                best_pos = positions[best_idx].copy()
            convergence.append(best_fit)

        return best_pos, best_fit, convergence

class ABC:
    """Karaboga (2005) - Artificial Bee Colony"""
    def __init__(self, pop_size=30, limit=50):
        self.pop_size = pop_size
        self.limit = limit

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        lb = np.array(bounds[0]) if hasattr(bounds[0], '__len__') else np.full(dim, bounds[0])
        ub = np.array(bounds[1]) if hasattr(bounds[1], '__len__') else np.full(dim, bounds[1])

        food_sources = np.random.uniform(lb, ub, (self.pop_size, dim))
        fitness = np.array([objective_fn(p) for p in food_sources])
        trial = np.zeros(self.pop_size, dtype=int)
        convergence = []

        def neighbor(i):
            k = np.random.choice([idx for idx in range(self.pop_size) if idx != i])
            phi = np.random.uniform(-1.0, 1.0, dim)
            v = food_sources[i] + phi * (food_sources[i] - food_sources[k])
            return np.clip(v, lb, ub)

        for _ in range(max_iterations):
            for i in range(self.pop_size):
                v = neighbor(i)
                v_fit = objective_fn(v)
                if v_fit < fitness[i]:
                    food_sources[i] = v
                    fitness[i] = v_fit
                    trial[i] = 0
                else:
                    trial[i] += 1

            probs = (1.0 / (fitness + 1e-12))
            probs /= probs.sum()
            for _ in range(self.pop_size):
                i = int(np.random.choice(self.pop_size, p=probs))
                v = neighbor(i)
                v_fit = objective_fn(v)
                if v_fit < fitness[i]:
                    food_sources[i] = v
                    fitness[i] = v_fit
                    trial[i] = 0
                else:
                    trial[i] += 1

            for i in range(self.pop_size):
                if trial[i] >= self.limit:
                    food_sources[i] = np.random.uniform(lb, ub, dim)
                    fitness[i] = objective_fn(food_sources[i])
                    trial[i] = 0

            convergence.append(float(np.min(fitness)))

        best_idx = int(np.argmin(fitness))
        return food_sources[best_idx], fitness[best_idx], convergence

class FA:
    """Yang (2008) - Firefly Algorithm"""
    def __init__(self, pop_size=30, alpha=0.2, beta=1.0, gamma=1.0):
        self.pop_size = pop_size
        self.alpha = alpha  # Randomization parameter
        self.beta = beta  # Light absorption coefficient
        self.gamma = gamma  # Exponential decay rate

    def optimize(self, objective_fn, bounds, dim, max_iterations=200):
        positions = np.random.uniform(bounds[0], bounds[1], (self.pop_size, dim))
        fitness = np.array([objective_fn(p) for p in positions])
        convergence = []

        for iteration in range(max_iterations):
            for i in range(self.pop_size):
                for j in range(self.pop_size):
                    if fitness[j] < fitness[i]:
                        distance = np.linalg.norm(positions[i] - positions[j])
                        beta = self.beta * np.exp(-self.gamma * distance ** 2)

                        positions[i] += (
                            beta * (positions[j] - positions[i]) +
                            self.alpha * (np.random.rand(dim) - 0.5)
                        )
                        positions[i] = np.clip(positions[i], bounds[0], bounds[1])

            fitness = np.array([objective_fn(p) for p in positions])
            convergence.append(np.min(fitness))

        best_idx = np.argmin(fitness)
        return positions[best_idx], fitness[best_idx], convergence