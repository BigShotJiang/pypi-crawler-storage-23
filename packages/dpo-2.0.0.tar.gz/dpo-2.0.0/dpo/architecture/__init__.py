from .gene import ArchitectureGene

__all__ = ['ArchitectureGene']
