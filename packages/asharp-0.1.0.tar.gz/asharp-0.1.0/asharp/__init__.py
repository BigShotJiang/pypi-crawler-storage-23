"""
A# Programming Language

A# is an experimental programming language project designed to explore
new programming language concepts and tooling.

This package provides the A# interpreter, compiler interface, and CLI tools.
"""

__title__ = "asharp"
__version__ = "0.1.0"
__author__ = "Intel"
__license__ = "GPL-3.0" # yes this is the license we use

# public api
from .interpreter import run_file
from .compiler import compile_file

__all__ = [
    "run_file",
    "compile_file"
]