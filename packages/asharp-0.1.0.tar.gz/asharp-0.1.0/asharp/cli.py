# asharp/cli.py

import sys
import argparse
from .interpreter import run_file
from .compiler import compile_file


def main():
    parser = argparse.ArgumentParser(
        prog="ash",
        description="A# Programming Language CLI"
    )

    subparsers = parser.add_subparsers(dest="command")

    # run command
    run_parser = subparsers.add_parser("run", help="Run an A# file")
    run_parser.add_argument("file", help="A# source file")

    # compile command
    compile_parser = subparsers.add_parser("compile", help="Compile an A# file")
    compile_parser.add_argument("file", help="A# source file")

    # default argument (ash file.ash)
    parser.add_argument("file", nargs="?", help="A# source file")

    args = parser.parse_args()

    # ash file.ash
    if args.file and args.command is None:
        run_file(args.file)
        return

    if args.command == "run":
        run_file(args.file)

    elif args.command == "compile":
        compile_file(args.file)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()