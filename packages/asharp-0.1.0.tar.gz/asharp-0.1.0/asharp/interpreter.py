def run_file(path):
    try:
        with open(path, "r") as f:
            code = f.read()

        print("Running A# program:")
        print(code)

    except FileNotFoundError:
        print("File not found:", path)