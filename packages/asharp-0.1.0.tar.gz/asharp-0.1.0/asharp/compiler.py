def compile_file(path):
    print(f"Compiling {path} (feature not implemented yet)")