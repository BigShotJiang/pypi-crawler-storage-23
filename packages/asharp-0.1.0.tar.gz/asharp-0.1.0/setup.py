from setuptools import setup, find_packages
from pathlib import Path

# reads README.md
readme_path = Path("README.md")
long_description = readme_path.read_text(encoding="utf-8")

setup(
    name="asharp",
    version="0.1.0",
    description="A# programming language",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Intel",
    license="GPL-3.0",
    packages=find_packages(),
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "asharp=asharp.cli:main",
        ],
    },
)

# note for people forking this project:

# change description and author if you're forking this project

# also update version names in pyproject.toml and this file when you make changes to your project

# btw add more things like dependencies on pyproject.toml if you want any

# also add a license file with the license text if you want any other license than GPL 3.0

# feel free to asks me any questions about the code or the project btw