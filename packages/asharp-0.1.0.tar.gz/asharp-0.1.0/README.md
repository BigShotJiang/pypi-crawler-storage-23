# A#

A# is a modern programming language experiment designed to explore
new ideas in programming language design.

## Installation

Install from PyPI:

``` bash
pip install asharp
```

## Usage

Run an A# program:

asharp program.ash

## Security

Please read the [Security Notice](SECURITY.md) before installing
third-party versions of A#.

## License

GNU GPL v3