"""Tests for CLI features: remote URL detection, config file detection, report writing."""

from pathlib import Path

# Import helpers from cli module
from argus_nano.cli import _is_remote_url, _write_report
from argus_nano.scanner import ScanResult, _is_config_file

# ======================================================================
# Feature 1: URL detection (no network required)
# ======================================================================


class TestRemoteURLDetection:
    def test_detect_github_https(self):
        assert _is_remote_url("https://github.com/user/repo")

    def test_detect_github_ssh(self):
        assert _is_remote_url("git@github.com:user/repo.git")

    def test_detect_gitlab_url(self):
        assert _is_remote_url("https://gitlab.com/group/project")

    def test_detect_http_url(self):
        assert _is_remote_url("http://github.com/user/repo")

    def test_detect_local_path_relative(self):
        assert not _is_remote_url("./my-repo")

    def test_detect_local_path_windows(self):
        assert not _is_remote_url("c:\\dev\\repo")

    def test_detect_local_path_unix(self):
        assert not _is_remote_url("/home/user/repo")

    def test_detect_bare_directory(self):
        assert not _is_remote_url("my-project")


# ======================================================================
# Feature 2: Config file detection
# ======================================================================


class TestConfigFileDetection:
    def test_env_file(self):
        assert _is_config_file(Path(".env"))

    def test_env_production(self):
        assert _is_config_file(Path(".env.production"))

    def test_yaml_file(self):
        assert _is_config_file(Path("config.yml"))

    def test_yaml_long_ext(self):
        assert _is_config_file(Path("settings.yaml"))

    def test_json_file(self):
        assert _is_config_file(Path("package.json"))

    def test_toml_file(self):
        assert _is_config_file(Path("pyproject.toml"))

    def test_terraform_file(self):
        assert _is_config_file(Path("main.tf"))

    def test_tfvars_file(self):
        assert _is_config_file(Path("prod.tfvars"))

    def test_dockerfile(self):
        assert _is_config_file(Path("Dockerfile"))

    def test_dockerfile_variant(self):
        assert _is_config_file(Path("Dockerfile.prod"))

    def test_docker_compose(self):
        assert _is_config_file(Path("docker-compose.yml"))

    def test_docker_compose_prod(self):
        assert _is_config_file(Path("docker-compose.prod.yml"))

    def test_secrets_json(self):
        assert _is_config_file(Path("secrets.json"))

    def test_credentials_yaml(self):
        assert _is_config_file(Path("credentials.yaml"))

    def test_npmrc(self):
        assert _is_config_file(Path(".npmrc"))

    def test_pgpass(self):
        assert _is_config_file(Path(".pgpass"))

    def test_htpasswd(self):
        assert _is_config_file(Path(".htpasswd"))

    def test_my_cnf(self):
        assert _is_config_file(Path(".my.cnf"))

    def test_ini_file(self):
        assert _is_config_file(Path("setup.cfg"))

    def test_properties_file(self):
        assert _is_config_file(Path("app.properties"))

    def test_xml_file(self):
        assert _is_config_file(Path("web.xml"))

    def test_bashrc(self):
        assert _is_config_file(Path(".bashrc"))

    def test_zshrc(self):
        assert _is_config_file(Path(".zshrc"))

    # Non-config files
    def test_not_config_go(self):
        assert not _is_config_file(Path("main.go"))

    def test_not_config_js(self):
        assert not _is_config_file(Path("app.js"))

    def test_not_config_py(self):
        assert not _is_config_file(Path("scanner.py"))

    def test_not_config_ts(self):
        assert not _is_config_file(Path("index.ts"))

    def test_not_config_readme(self):
        assert not _is_config_file(Path("README.md"))

    def test_not_config_makefile(self):
        assert not _is_config_file(Path("Makefile"))


# ======================================================================
# Feature 3: Report writing
# ======================================================================


class TestReportWriting:
    def _make_results(self):
        return [
            ScanResult(
                severity="high",
                file_path="docker-compose.yml",
                line_number=11,
                provider="semantic",
                pattern_id="semantic_key",
                value_masked="sc****bi",
                confidence=0.9,
                detection_type="semantic",
                key_name="POSTGRES_PASSWORD",
            ),
            ScanResult(
                severity="high",
                file_path="config/prod.env",
                line_number=3,
                provider="aws_access_key_id",
                pattern_id="aws_access_key_id",
                value_masked="AKIA****MPLE",
                confidence=0.95,
                detection_type="format",
            ),
        ]

    def test_write_text_report(self, tmp_path):
        results = self._make_results()
        report_path = str(tmp_path / "findings.txt")
        _write_report(results, report_path, "./repo", 127, 1.7)

        content = Path(report_path).read_text()
        assert "# Argus Nano Scan Report" in content
        assert "# Target: ./repo" in content
        assert "# Files scanned: 127" in content
        assert "# Findings: 2" in content
        assert "# Scan time: 1.7s" in content
        assert "POSTGRES_PASSWORD" in content
        assert "AKIA****MPLE" in content
        assert "sc****bi" in content

    def test_write_csv_report(self, tmp_path):
        results = self._make_results()
        report_path = str(tmp_path / "findings.csv")
        _write_report(results, report_path, "./repo", 127, 1.7)

        content = Path(report_path).read_text()
        lines = content.strip().split("\n")
        assert lines[0] == "severity,file,line,detection_type,provider,masked_value,key_name"
        assert "high,docker-compose.yml,11,semantic,semantic,sc****bi,POSTGRES_PASSWORD" in lines[1]
        assert "high,config/prod.env,3,format,aws_access_key_id,AKIA****MPLE," in lines[2]

    def test_report_no_secrets(self, tmp_path):
        report_path = str(tmp_path / "empty.txt")
        _write_report([], report_path, "./repo", 50, 0.3)

        content = Path(report_path).read_text()
        assert "# Findings: 0" in content
