from setuptools import setup, find_packages

setup(
    name="kissat-sovereign",
    version="2.0.0.post2",
    author="Americo Simoes",
    py_modules=["kissat_apex"],
    # We now look for the library in the current directory (.)
    data_files=[('lib', ['libkissat.so'])],
    include_package_data=True,
    python_requires='>=3.6',
)
