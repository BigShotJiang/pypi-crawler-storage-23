# pymrf4



## To test with `curl`

```bash
# client resolves the domain name, ATYP_IPV4(1)
curl --socks5 socks5://127.0.0.1:9050 http://www.baidu.com
# Or let the proxy resolve the domain name, ATYP_DOMAINNAME(3)
curl --socks5 socks5h://127.0.0.1:9050 http://www.baidu.com
```

## Install as a Windows service

With nssm:

```bat
nssm install pymrf4 D:\Python312\python.exe
nssm set pymrf4 AppParameters "-m pymrf4"
nssm set pymrf4 AppDirectory C:\pymrf4
nssm set pymrf4 AppExit Default Restart
nssm set pymrf4 AppStdout C:\pymrf4\logs\service-err.log
nssm set pymrf4 AppStderr C:\pymrf4\logs\service-err.log
nssm set pymrf4 DisplayName pymrf4
nssm set pymrf4 ObjectName LocalSystem
nssm set pymrf4 Start SERVICE_AUTO_START
nssm set pymrf4 Type SERVICE_WIN32_OWN_PROCESS

```