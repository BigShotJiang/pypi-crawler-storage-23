import requests
from urllib3.exceptions import NewConnectionError

class BTClient:
    def __init__(self, api_config):
        if not api_config.client:
            raise ValueError("BT client not configured")

        _, self.baseurl, self.username, self.password = api_config
        self.jar = requests.cookies.RequestsCookieJar()


    def login(self):
        try:
            data = {"username": self.username, "password": self.password }
            res = requests.post(self.baseurl + "auth/login", data=data)
            self.jar = res.cookies
        except:
            raise
        
    def get_torrents(self):
        try:
            res = requests.get(self.baseurl + "sync/maindata?rid=0", cookies=self.jar)
            if res.status_code == 200:
                return res.json()["torrents"]
            elif res.status_code == 403:
                self.login()
                return self.get_torrents()
        except ConnectionError:
            return []
        except NewConnectionError:
            return []
        except WindowsError:
            return []
        

    # def get_torrent_properties(self, hash):
    #     res = requests.get(self.baseurl + "torrents/properties?hash=" + hash, cookies=self.jar)
    #     if res.status_code == 200:
    #         return res.json()
    #     else:
    #         return None
        

    def get_torrent_info(self, hash):
        all_torrents = self.get_torrents()
        return all_torrents[hash] if hash in all_torrents else None
        

    def delete(self, hashes: str, delete_files=False):
        try:
            res = requests.post(self.baseurl + "torrents/pause", cookies=self.jar, 
                                data={"hashes": hashes, "deleteFiles": delete_files})
            return res.status_code == 200
        except ConnectionError:
            return []
        except NewConnectionError:
            return []
        except WindowsError:
            return []


    def pause(self, hashes: str):
        try:
            res = requests.post(self.baseurl + "torrents/pause", cookies=self.jar, data={"hashes": hashes})
            return res.status_code == 200
        except ConnectionError:
            return []
        except NewConnectionError:
            return []
        except WindowsError:
            return []


# curl 'http://localhost:8080/api/v2/torrents/pause' \
#   -H 'Accept: text/javascript, text/html, application/xml, text/xml, */*' \
#   -H 'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8' \
#   -H 'Cache-Control: no-cache' \
#   -H 'Connection: keep-alive' \
#   -H 'Content-type: application/x-www-form-urlencoded; charset=UTF-8' \
#   -H 'Cookie: SID=Av1eYpG/meN6HcqcB40VYg6BsRfVjG09' \
#   -H 'Origin: http://localhost:8080' \
#   -H 'Pragma: no-cache' \
#   -H 'Referer: http://localhost:8080/' \
#   -H 'Sec-Fetch-Dest: empty' \
#   -H 'Sec-Fetch-Mode: cors' \
#   -H 'Sec-Fetch-Site: same-origin' \
#   -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36' \
#   -H 'X-Requested-With: XMLHttpRequest' \
#   -H 'sec-ch-ua: "Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"' \
#   -H 'sec-ch-ua-mobile: ?0' \
#   -H 'sec-ch-ua-platform: "Windows"' \
#   --data-raw 'hashes=2fb92c6383b14ee42f48199b2ddcb472efb81230'




# curl 'http://localhost:8080/api/v2/torrents/delete' \
#   -H 'Accept: text/javascript, text/html, application/xml, text/xml, */*' \
#   -H 'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8' \
#   -H 'Cache-Control: no-cache' \
#   -H 'Connection: keep-alive' \
#   -H 'Content-type: application/x-www-form-urlencoded; charset=UTF-8' \
#   -H 'Cookie: SID=Av1eYpG/meN6HcqcB40VYg6BsRfVjG09' \
#   -H 'Origin: http://localhost:8080' \
#   -H 'Pragma: no-cache' \
#   -H 'Referer: http://localhost:8080/confirmdeletion.html?hashes=fdfd899f69f341cd9fa5ce450b4606cea536f2c4&deleteFiles=false' \
#   -H 'Sec-Fetch-Dest: empty' \
#   -H 'Sec-Fetch-Mode: cors' \
#   -H 'Sec-Fetch-Site: same-origin' \
#   -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36' \
#   -H 'X-Requested-With: XMLHttpRequest' \
#   -H 'sec-ch-ua: "Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"' \
#   -H 'sec-ch-ua-mobile: ?0' \
#   -H 'sec-ch-ua-platform: "Windows"' \
#   --data-raw 'hashes=fdfd899f69f341cd9fa5ce450b4606cea536f2c4&deleteFiles=false'