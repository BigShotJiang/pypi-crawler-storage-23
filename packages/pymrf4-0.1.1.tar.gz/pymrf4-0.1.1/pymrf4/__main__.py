from pymrf4.cli import cli

cli()

