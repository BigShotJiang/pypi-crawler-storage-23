# -*- coding: utf-8 -*-
from collections import namedtuple

SiteConfig = namedtuple("SiteConfig", ["name", "trackers", \
                                       "uspeed_min", \
                                       "uspeed_max", \
                                       "overspeed_strategy", \
                                       "scale_factor", \
                                       "max_anticipate_leechers", \
                                       "min_leechers_factor", \
                                       "min_leachers_to_mod", \
                                       "force_mod_upload", \
                                       "allow_self_announce", \
                                       "self_announce_interval", \
                                       "upload_reduction"
                                    ])
ApiConfig = namedtuple("ApiConfig", ["client", "baseurl", "username", "password"],
                       defaults=[None, None, None, None])

