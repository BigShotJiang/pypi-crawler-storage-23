from peewee import SqliteDatabase

PRAGMAS = {
    "journal_mode": "wal",        # readers don't block the writer
    "synchronous": "normal",      # fsync less often → faster WAL
    "cache_size": -64 * 1024,     # 64 MiB page cache (negative = KiB)
    "foreign_keys": 1,
    "busy_timeout": 10000,        # wait up to 10 s before “database is locked”
}

db = SqliteDatabase('ctx3.db',
                    check_same_thread=False,
                    pragmas=PRAGMAS)
