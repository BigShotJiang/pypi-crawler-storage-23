#!/bin/sh

apk add git
uv sync --group cli

exec "$@"