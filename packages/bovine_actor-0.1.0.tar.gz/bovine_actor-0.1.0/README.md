# bovine-actor

bovine-actor aims to provide a complete implementation of the functionality

* __pull__: fetch an Object
* __push__: send an Activity

for the Fediverse. 

## Technical details

bovine-actor relies on

* [aiohttp](https://docs.aiohttp.org/en/stable/index.html) through [aiohttp-signer](https://codeberg.org/bovine/aiohttp-signer) for HTTP
* [cryptography](https://cryptography.io/en/latest/) for cryptography

The rest is utility code combining parsing and managing certain requests.

## Development

### docker compose

```bash
docker compose up
docker compose exec bovine uv run python -m bovine_actor --base_url 'http://bovine' repl
```