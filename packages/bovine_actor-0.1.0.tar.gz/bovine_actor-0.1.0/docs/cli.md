::: mkdocs-click
    :module: bovine_actor.__main__
    :command: main
    :prog_name: bovine-actor