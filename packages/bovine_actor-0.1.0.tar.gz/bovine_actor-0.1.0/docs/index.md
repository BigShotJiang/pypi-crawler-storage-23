# bovine-actor

```mermaid
flowchart TB
    BBA[bovine_base_actor] --> OF[object_fetcher]
    BBA --> AS[activity_sender]
    OF --> BA[bovine_actor]
    AS --> BA
```