import aiohttp

from .object_fetcher import SimpleObjectFetcher
from .activity_sender import SimpleActivitySender, ActivitySender

from .crypto import CryptographicSecret
from .base_actor import BaseBovineActor
from .identifier_resolver import IdentityResolver, PublicIdentifier

__all__ = [
    "BaseBovineActor",
    "BovineActor",
    "SimpleObjectFetcher",
    "SimpleActivitySender",
    "ActivitySender",
    "IdentityResolver",
    "PublicIdentifier",
]


class BovineActor(SimpleActivitySender, SimpleObjectFetcher):
    """The base bovine actor"""

    def __init__(self, base_actor: BaseBovineActor):
        super().__init__(
            base_actor=base_actor,
        )

        self.actor_id = base_actor.actor_id

    @staticmethod
    def for_session_id_and_secret(
        session: aiohttp.ClientSession,
        actor_id: str,
        secret: CryptographicSecret,
    ) -> "BovineActor":
        """Creates a bovine actor for some params"""
        base_actor = BaseBovineActor.for_id_and_secret(
            session, actor_id=actor_id, secret=secret
        )
        return BovineActor(base_actor)
