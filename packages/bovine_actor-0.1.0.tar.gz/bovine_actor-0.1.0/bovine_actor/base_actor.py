from dataclasses import dataclass, field

import aiohttp
from aiohttp_signer import (
    DigestMiddleware,
    DigestMode,
    DraftCavageSigner,
    Rfc9421Signer,
    DateMiddleware,
)

from .crypto import CryptographicSecret

BOVINE_CLIENT_NAME = "bovine-actor"


def default_get_headers():
    return {"accept": "application/activity+json", "user-agent": BOVINE_CLIENT_NAME}


def default_post_headers():
    return {
        "content-type": "application/activity+json",
        "user-agent": BOVINE_CLIENT_NAME,
    }


@dataclass
class BaseBovineActor:
    """This is a wrapper around the post and get method of an
    [aiohttp.ClientSession][]. For get the middlewares_get and get_headers
    are automatically added."""

    actor_id: str = field(metadata={"description": "the id of the actor"})
    session: aiohttp.ClientSession

    middlewares_get: list
    middlewares_post: list

    get_headers: dict = field(default_factory=default_get_headers)
    post_headers: dict = field(default_factory=default_post_headers)

    async def get(self, url: str):
        """Makes a get request"""
        return await self.session.get(
            url, headers=self.get_headers, middlewares=self.middlewares_get
        )

    async def post(
        self,
        url: str,
        activity: dict,
    ):
        """Makes a post request"""
        return await self.session.post(
            url,
            json=activity,
            headers=self.post_headers,
            middlewares=self.middlewares_post,
        )

    @staticmethod
    def for_id_and_secret(
        session: aiohttp.ClientSession,
        actor_id: str,
        secret: CryptographicSecret,
        params: list[str] = ["@method", "@target-uri"],
    ):
        """Static constructor for modern usage"""
        signer_get = Rfc9421Signer(
            signer=secret.sign,
            key_id=secret.key_id,
            params=params,
        )
        signer_post = Rfc9421Signer(
            signer=secret.sign, key_id=secret.key_id, params=params + ["content-digest"]
        )

        return BaseBovineActor(
            session=session,
            actor_id=actor_id,
            middlewares_get=[signer_get],
            middlewares_post=[DigestMiddleware(), signer_post],
        )

    @staticmethod
    def for_id_and_secret_legacy(
        session: aiohttp.ClientSession, actor_id: str, secret: CryptographicSecret
    ):
        signer_get = DraftCavageSigner(
            signer=secret.sign,
            key_id=secret.key_id,
            params=["(request-target)", "host", "date"],
        )
        signer_post = DraftCavageSigner(signer=secret.sign, key_id=secret.key_id)

        return BaseBovineActor(
            session=session,
            actor_id=actor_id,
            middlewares_get=[DateMiddleware(), signer_get],
            middlewares_post=[
                DateMiddleware(),
                DigestMiddleware(mode=DigestMode.rfc3230_upper),
                signer_post,
            ],
        )


class BaseActorContainer:
    """Container with a base bovine actor for inheritance"""

    base_actor: BaseBovineActor

    def __init__(self, base_actor: BaseBovineActor) -> None:
        self.base_actor = base_actor
