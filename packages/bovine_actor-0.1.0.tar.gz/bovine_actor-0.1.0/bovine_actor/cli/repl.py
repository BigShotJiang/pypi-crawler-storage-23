from dataclasses import dataclass
from enum import StrEnum, auto
import aiohttp
from ptpython.repl import embed, PythonRepl

from bovine_actor import BovineActor
from bovine_actor.base_actor import BaseBovineActor
from bovine_actor.crypto import RSACryptographicSecret
from bovine_actor.testing import rsa_private_key_pem

from .domain import DomainConfig


def config(repl: PythonRepl):
    repl.use_code_colorscheme("dracula")
    repl.enable_output_formatting = True
    repl.confirm_exit = False


class ActorType(StrEnum):
    rsa = auto()
    base_rsa = auto()


@dataclass
class ReplBuilder:
    domain: DomainConfig
    actor_type: ActorType = ActorType.rsa
    private_key_pem: str = rsa_private_key_pem

    @property
    def secret(self):
        match self.actor_type:
            case ActorType.base_rsa | ActorType.rsa:
                return RSACryptographicSecret.from_pem(
                    self.domain.public_key_id, self.private_key_pem
                )

    def actor_for_session(self, session: aiohttp.ClientSession):
        match self.actor_type:
            case ActorType.base_rsa:
                return BaseBovineActor.for_id_and_secret(
                    session, self.domain.actor_uri, self.secret
                )
            case ActorType.rsa:
                return BovineActor.for_session_id_and_secret(
                    session, self.domain.actor_uri, self.secret
                )

    async def run(self):
        async with aiohttp.ClientSession() as session:
            await embed(
                globals=globals(),
                locals={"actor": self.actor_for_session(session), "session": session},
                return_asyncio_coroutine=True,
                patch_stdout=True,
                configure=config,
            )
