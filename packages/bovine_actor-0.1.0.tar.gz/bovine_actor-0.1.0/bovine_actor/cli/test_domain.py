import pytest
from .domain import DomainConfig


@pytest.mark.parametrize("base_url", ["http://domain.test/", "http://domain.test"])
def test_domain(base_url):
    app = DomainConfig(base_url=base_url)
    assert app.domain == "domain.test"
    assert app.actor_uri == "http://domain.test/actor"
