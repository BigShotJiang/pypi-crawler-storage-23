from urllib.parse import urljoin, urlparse

from dataclasses import dataclass


@dataclass
class DomainConfig:
    base_url: str

    @property
    def domain(self):
        return urlparse(self.base_url).netloc

    @property
    def actor_uri(self):
        return urljoin(self.base_url, "/actor")

    @property
    def public_key_id(self):
        return urljoin(self.base_url, "/actor#key1")
