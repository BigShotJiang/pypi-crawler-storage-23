import logging
from aiohttp import web
from attr import dataclass

from .domain import DomainConfig
from bovine_actor.testing import rsa_public_key_pem

logger = logging.getLogger(__name__)


@dataclass
class Application:
    domain: DomainConfig
    public_key_pem: str = rsa_public_key_pem
    preferred_username: str = "actor"

    @property
    def acct_uri(self):
        return f"acct:{self.preferred_username}@{self.domain.domain}"

    @property
    def actor_profile(self):
        return {
            "@context": [
                "https://www.w3.org/ns/activitystreams",
                "https://w3id.org/security/v1",
            ],
            "id": self.domain.actor_uri,
            "inbox": f"{self.domain.actor_uri}/inbox",
            "name": self.preferred_username,
            "outbox": f"{self.domain.actor_uri}",
            "preferredUsername": self.preferred_username,
            "publicKey": {
                "id": self.domain.public_key_id,
                "owner": self.domain.actor_uri,
                "publicKeyPem": self.public_key_pem,
            },
            "type": "Person",
        }

    async def webfinger_response(self, request: web.Request):
        logger.info("Got webfinger request")
        return web.json_response(
            {
                "subject": self.acct_uri,
                "links": [
                    {
                        "rel": "self",
                        "type": "application/activity+json",
                        "href": self.domain.actor_uri,
                    }
                ],
            },
            content_type="application/jrd+json",
        )

    async def actor_profile_response(self, request: web.Request):
        logger.info("Got actor request")
        return web.json_response(
            self.actor_profile, content_type="application/activity+json"
        )

    async def inbox(self, request: web.Request):
        logger.info("Post to inbox")
        logger.info(await request.json())
        return web.Response(text="", status=202)

    def __call__(self) -> web.Application:
        app = web.Application()
        app.add_routes(
            [
                web.get("/actor", self.actor_profile_response),
                web.post("/actor/inbox", self.inbox),
                web.get("/.well-known/webfinger", self.webfinger_response),
            ]
        )

        return app
