from . import BovineActor
from .base_actor import BaseBovineActor
from .crypto import RSACryptographicSecret
from .testing import rsa_private_key_pem
from .testing.fixtures import *  # noqa


def test_bovine_actor(client_session):
    secret = RSACryptographicSecret.from_pem("key_id", rsa_private_key_pem)

    base_actor = BaseBovineActor.for_id_and_secret(client_session, "actor-id", secret)

    BovineActor(base_actor)


def test_bovine_actor_static(client_session):
    secret = RSACryptographicSecret.from_pem("key_id", rsa_private_key_pem)

    BovineActor.for_session_id_and_secret(client_session, "actor_id", secret)
