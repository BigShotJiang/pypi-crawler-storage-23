import asyncio
from collections.abc import Callable, Awaitable
from bovine_actor.base_actor import BaseActorContainer, BaseBovineActor
from .naive_inbox_resolver import NaiveInboxResolver


__all__ = ["NaiveInboxResolver", "naive_recipient_resolver"]


def as_set(x: str | list[str]) -> set[str]:
    if isinstance(x, str):
        return {x}
    return set(x)


async def naive_recipient_resolver(activity: dict) -> set[str]:
    return as_set(activity.get("to", [])) | as_set(activity.get("cc", []))


class ActivitySender(BaseActorContainer):
    """Implements the logic to send activities"""

    inbox_resolver: Callable[[str], Awaitable[str]]
    recipient_resolver: Callable[[dict], Awaitable[set[str]]]

    def __init__(
        self,
        base_actor: BaseBovineActor,
        inbox_resolver: Callable[[str], Awaitable[str]],
        recipient_resolver: Callable[[dict], Awaitable[set[str]]],
    ) -> None:
        """Creates an Activity Sender"""
        super().__init__(base_actor)
        self.inbox_resolver = inbox_resolver
        self.recipient_resolver = recipient_resolver

    async def send(self, activity: dict):
        """
        Given an activity, sends the activity to the recipients, computed
        using the `recipient_resolver`.
        """
        recipients = await self.recipient_resolver(activity)

        async with asyncio.TaskGroup() as tg:
            for recipient in recipients:
                tg.create_task(self.send_to(recipient, activity))

    async def send_to(self, remote_actor_id: str, activity: dict):
        """Sends the activity to the specified remote_actor"""
        inbox = await self.inbox_resolver(remote_actor_id)
        return await self.base_actor.post(inbox, activity)


class SimpleActivitySender(ActivitySender):
    """Implements a simple activity sender."""

    def __init__(self, base_actor: BaseBovineActor):
        super().__init__(
            base_actor=base_actor,
            inbox_resolver=NaiveInboxResolver(base_actor),
            recipient_resolver=naive_recipient_resolver,
        )
