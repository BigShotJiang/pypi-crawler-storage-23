from dataclasses import dataclass, field
from bovine_actor.base_actor import BaseBovineActor

import logging

logger = logging.getLogger(__name__)


@dataclass
class NaiveInboxResolver:
    base_actor: BaseBovineActor
    caching: bool = True
    _cache: dict[str, str] = field(default_factory=dict)

    async def __call__(self, actor_id: str):
        cached = self._cache.get(actor_id)
        if cached:
            return cached

        actor_profile_response = await self.base_actor.get(actor_id)
        actor_profile_response.raise_for_status()
        actor_profile = await actor_profile_response.json()

        result = actor_profile.get("inbox")
        if not isinstance(result, str):
            raise Exception("Could not fetch inbox")

        self._cache[actor_id] = result

        return result
