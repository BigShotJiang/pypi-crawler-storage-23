import pytest

from . import naive_recipient_resolver


@pytest.mark.parametrize(
    "activity,recipients",
    [
        ({}, set()),
        ({"to": "actor1"}, {"actor1"}),
        ({"to": ["actor1"]}, {"actor1"}),
        ({"cc": "actor1"}, {"actor1"}),
        ({"cc": ["actor1"]}, {"actor1"}),
        ({"to": "actor1", "cc": "actor2"}, {"actor1", "actor2"}),
    ],
)
async def test_recipient_resolver(activity, recipients):
    result = await naive_recipient_resolver(activity)

    assert result == recipients
