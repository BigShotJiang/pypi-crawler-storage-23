from unittest.mock import AsyncMock, MagicMock

from .naive_inbox_resolver import NaiveInboxResolver


async def test_resolve_inbox():
    response_mock = AsyncMock()
    response_mock.json.return_value = {"inbox": "inbox"}
    response_mock.raise_for_status = MagicMock()

    base_actor = AsyncMock()
    base_actor.get.return_value = response_mock

    resolver = NaiveInboxResolver(base_actor=base_actor)

    result = await resolver("actor_id")

    base_actor.get.assert_awaited_once()

    assert result == "inbox"
