import json
import zipfile

import pytest

from .model import PublicIdentifier

from .parsing import legacy_public_key


def actor_objects():
    with zipfile.ZipFile("test_data/samples.zip") as zip:
        for file in zip.filelist:
            if file.filename.startswith("actor_"):
                with zip.open(file) as fp:
                    yield file.filename, json.load(fp)


@pytest.mark.parametrize("name,actor", actor_objects())
def test_actors(name, actor):
    assert isinstance(legacy_public_key(actor), PublicIdentifier)
