from unittest.mock import AsyncMock, MagicMock

import pytest

from bovine_actor.base_actor import BaseBovineActor

from . import IdentityResolver

from .test_parsing import actor_objects


def resolver_for_actor(actor: dict) -> IdentityResolver:
    result_mock = AsyncMock()
    result_mock.raise_for_status = MagicMock()
    result_mock.json.return_value = actor
    mock_actor = AsyncMock(BaseBovineActor)
    mock_actor.get.return_value = result_mock

    return IdentityResolver(mock_actor)


@pytest.mark.parametrize("name,actor", actor_objects())
async def test_identity_resolver(name, actor):
    key_id = actor.get("publicKey", {}).get("id", "")

    resolver = resolver_for_actor(actor)

    result = await resolver(key_id)

    assert result
    assert result.id == key_id


@pytest.mark.parametrize("name,actor", actor_objects())
async def test_identity_resolver_wrong_id(name, actor):
    key_id = actor.get("id", "") + "#does-not-exist-23424"

    resolver = resolver_for_actor(actor)

    result = await resolver(key_id)

    assert result is None
