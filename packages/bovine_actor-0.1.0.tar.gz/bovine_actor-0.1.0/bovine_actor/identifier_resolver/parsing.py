from ..crypto.public_key import RsaPublicKey

from .model import PublicIdentifier


def legacy_public_key(actor_object: dict):
    public_key_info = actor_object.get("publicKey")

    if public_key_info is None:
        return

    controller = public_key_info.get("owner")
    pem = public_key_info.get("publicKeyPem")
    id = public_key_info.get("id")

    return PublicIdentifier(
        id=id, controller=controller, public_key=RsaPublicKey.from_pem(pem)
    )
