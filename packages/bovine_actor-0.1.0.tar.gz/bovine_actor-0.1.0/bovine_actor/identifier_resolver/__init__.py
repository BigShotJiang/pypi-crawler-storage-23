from bovine_actor.base_actor import BaseActorContainer

from .parsing import legacy_public_key
from .model import PublicIdentifier

__all__ = ["PublicIdentifier", "IdentityResolver"]


class IdentityResolver(BaseActorContainer):
    """Allows getting the public key information associated with an identifier"""

    async def __call__(self, identifier: str) -> PublicIdentifier | None:
        """Get the public identifier"""

        response = await self.base_actor.get(identifier)
        response.raise_for_status()

        parsed = await response.json()

        result_key = legacy_public_key(parsed)

        if result_key and result_key.id == identifier:
            return result_key
