from dataclasses import dataclass, field


from bovine_actor.crypto.public_key import PublicKey


@dataclass
class PublicIdentifier:
    """Describes a public identifier"""

    id: str
    controller: str
    public_key: PublicKey
    aliases: list[str] = field(default_factory=list)
