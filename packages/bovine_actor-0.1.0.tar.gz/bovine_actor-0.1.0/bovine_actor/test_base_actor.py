import pytest

from .crypto import RSACryptographicSecret
from .testing import rsa_private_key_pem
from .base_actor import BaseBovineActor
from .testing.fixtures import *  # noqa


def actor_makers():
    secret = RSACryptographicSecret.from_pem("key_id", rsa_private_key_pem)

    yield lambda session: BaseBovineActor.for_id_and_secret(session, "actor-id", secret)
    yield lambda session: BaseBovineActor.for_id_and_secret_legacy(
        session, "actor-id", secret
    )


@pytest.mark.parametrize("actor_maker", actor_makers())
@pytest.mark.timeout(2)
async def test_get(server_url, client_session, headers, actor_maker):
    actor = actor_maker(client_session)
    await actor.get(server_url)

    result = await headers

    assert "signature" in result


@pytest.mark.parametrize("actor_maker", actor_makers())
@pytest.mark.timeout(2)
async def test_post(server_url, client_session, headers, actor_maker):
    actor = actor_maker(client_session)
    await actor.post(server_url, {})

    result = await headers

    assert "signature" in result
