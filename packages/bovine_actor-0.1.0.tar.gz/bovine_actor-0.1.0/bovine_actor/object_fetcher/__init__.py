from bovine_actor.base_actor import BaseActorContainer, BaseBovineActor


class SimpleObjectFetcher(BaseActorContainer):
    """Creates an object fetcher"""

    def __init__(self, base_actor: BaseBovineActor):
        """Creates the object fetcher"""
        super().__init__(
            base_actor=base_actor,
        )

    async def fetch(self, object_id: str):
        """Fetches the object"""
        response = await self.base_actor.get(object_id)
        response.raise_for_status()

        return await response.json()
