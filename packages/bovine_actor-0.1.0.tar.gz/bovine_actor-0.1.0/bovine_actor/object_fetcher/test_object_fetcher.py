from unittest.mock import AsyncMock, MagicMock

from . import SimpleObjectFetcher


def mock_response(data: dict):
    response = AsyncMock()
    response.raise_for_status = MagicMock()
    response.json.return_value = data
    return response


async def test_fetch():
    expected = {"test": "yes"}
    mock_actor = AsyncMock()
    mock_actor.get.return_value = mock_response(expected)

    simple = SimpleObjectFetcher(mock_actor)

    result = await simple.fetch("some_id")

    assert result == expected
