"""Implements basic cryptographic primitives

A CryptographicSecret wraps a private key, providing a method
to sign a message. The `key_id` provides the method to retrieve
the corresponding public key, and knowledge about who signed the
message.

See [Controlled Identifiers](https://www.w3.org/TR/cid-1.0/) for
a message to link a public key to an identifier.
"""

from cryptography.hazmat.primitives.asymmetric import ed25519, rsa, padding
from cryptography.hazmat.primitives import hashes

from .base import CryptographicSecret
from .public_key import Ed25519PublicKey, PublicKey, RsaPublicKey

__all__ = [
    "RSACryptographicSecret",
    "Ed25519CryptographicSecret",
    "CryptographicSecret",
    "Ed25519PublicKey",
    "PublicKey",
    "RsaPublicKey",
]


class RSACryptographicSecret(CryptographicSecret):
    """Cryptographic key based on RSA using PKCS1v15 padding and sha256 hashes"""

    @staticmethod
    def check_key(private_key) -> bool:
        return isinstance(private_key, rsa.RSAPrivateKey)

    def sign(self, message: bytes) -> bytes:
        return self._private_key.sign(message, padding.PKCS1v15(), hashes.SHA256())


class Ed25519CryptographicSecret(CryptographicSecret):
    """Uses Ed25519"""

    @staticmethod
    def check_key(private_key) -> bool:
        return isinstance(private_key, ed25519.Ed25519PrivateKey)

    def sign(self, message: bytes) -> bytes:
        return self._private_key.sign(message)
