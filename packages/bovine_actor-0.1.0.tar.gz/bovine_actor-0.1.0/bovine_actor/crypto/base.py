from abc import abstractmethod
from dataclasses import dataclass, field
from typing import Any

from cryptography.hazmat.primitives.serialization import (
    load_pem_private_key,
)


class InvalidPEMSuppliedException(Exception): ...


@dataclass
class CryptographicSecret:
    """A cryptographic secret"""

    key_id: str = field(
        metadata={
            "description": """unique URI identifying the cryptographic identifier used to verify messages signed using this secret"""
        }
    )

    _private_key: Any

    @staticmethod
    @abstractmethod
    def check_key(private_key) -> bool:
        """Verifies that the key has the correct format"""

    @abstractmethod
    def sign(self, message: bytes) -> bytes:
        """Signs the message"""

    @classmethod
    def from_pem(cls, key_id: str, pem: str):
        """Creates a new Cryptographic Secret from the pem"""

        private_key = load_pem_private_key(pem.encode(), password=None)
        if not cls.check_key(private_key):
            raise InvalidPEMSuppliedException()
        return cls(key_id=key_id, _private_key=private_key)
