from bovine_actor.testing import rsa_private_key_pem, ed25519_private_pem
from cryptography.hazmat.primitives import serialization

from . import Ed25519CryptographicSecret, RSACryptographicSecret
from .public_key import Ed25519PublicKey, RsaPublicKey


def test_rsa_cryptographic_key():
    secret = RSACryptographicSecret.from_pem("key_id", rsa_private_key_pem)

    message = b"moo"
    result = secret.sign(message)

    assert isinstance(result, bytes)

    public_key = secret._private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    public_key = RsaPublicKey.from_pem(public_key.decode())
    assert public_key.verify(message, result)


def test_ed25519():
    secret = Ed25519CryptographicSecret.from_pem("key_id", ed25519_private_pem)

    message = b"moo"
    result = secret.sign(message)

    assert isinstance(result, bytes)

    public_key = secret._private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    public_key = Ed25519PublicKey.from_pem(public_key.decode())
    assert public_key.verify(message, result)
