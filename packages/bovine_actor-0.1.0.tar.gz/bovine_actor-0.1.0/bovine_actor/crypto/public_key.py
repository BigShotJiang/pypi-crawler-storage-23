from abc import abstractmethod
from dataclasses import dataclass
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.serialization import (
    load_pem_public_key,
)
from cryptography.hazmat.primitives.asymmetric import ed25519, rsa, padding
from cryptography.hazmat.primitives import hashes

from .base import InvalidPEMSuppliedException


@dataclass
class PublicKey:
    """Represents a public key"""

    _public_key: Any

    @abstractmethod
    def verify(self, message: bytes, signature: bytes) -> bool:
        """Checks that the message satisfies the signature"""

    @staticmethod
    @abstractmethod
    def check_key(public_key) -> bool:
        """Verifies that the key has the correct format"""

    @classmethod
    def from_pem(cls, pem: str):
        """Creates a new Cryptographic Secret from the pem"""

        public_key = load_pem_public_key(pem.encode())
        if not cls.check_key(public_key):
            raise InvalidPEMSuppliedException()
        return cls(_public_key=public_key)


class Ed25519PublicKey(PublicKey):
    _public_key: ed25519.Ed25519PublicKey

    @staticmethod
    def check_key(public_key) -> bool:
        return isinstance(public_key, ed25519.Ed25519PublicKey)

    def verify(self, message: bytes, signature: bytes) -> bool:
        try:
            self._public_key.verify(signature, message)
            return True
        except InvalidSignature:
            return False


class RsaPublicKey(PublicKey):
    _public_key: rsa.RSAPublicKey

    @staticmethod
    def check_key(public_key) -> bool:
        return isinstance(public_key, rsa.RSAPublicKey)

    def verify(self, message: bytes, signature: bytes) -> bool:
        try:
            self._public_key.verify(
                signature,
                message,
                padding=padding.PKCS1v15(),
                algorithm=hashes.SHA256(),
            )
            return True
        except InvalidSignature:
            return False
