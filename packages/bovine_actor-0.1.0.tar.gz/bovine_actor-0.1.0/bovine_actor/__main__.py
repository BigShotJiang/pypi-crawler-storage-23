import asyncio
import logging
import click

from aiohttp import web

from .cli.repl import ReplBuilder

from .cli.domain import DomainConfig
from .cli.server import Application


logging.basicConfig(level=logging.INFO)


@click.group
@click.option("--base_url", default="http://localhost:8080")
@click.pass_context
def main(ctx: click.Context, base_url: str):
    """Helper command to experiment with bovine-actor"""
    ctx.ensure_object(dict)
    ctx.obj["domain"] = DomainConfig(base_url)


@main.command
@click.pass_context
def repl(ctx: click.Context):
    """Starts a REPL with the actor"""
    repl = ReplBuilder(domain=ctx.obj["domain"])
    asyncio.run(repl.run())


@main.command
@click.option("--port", default=8080)
@click.option("--host", default="0.0.0.0")
@click.pass_context
def server(ctx: click.Context, port, host):
    """Serves a webserver containing the public key information for the actor"""
    app = Application(domain=ctx.obj["domain"])
    web.run_app(app(), port=port, host=host)


if __name__ == "__main__":
    main()
