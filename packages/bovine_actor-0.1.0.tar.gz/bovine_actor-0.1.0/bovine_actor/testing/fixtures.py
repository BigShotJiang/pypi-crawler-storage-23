import asyncio
import aiohttp
import pytest
from aiohttp import web


@pytest.fixture
async def headers():
    return asyncio.Future()


@pytest.fixture
async def server_url(headers):
    port = 14268

    async def store_headers(request: web.Request):
        headers.set_result(request.headers)
        return web.Response(text="")

    app = web.Application()
    app.add_routes([web.get("/", store_headers), web.post("/", store_headers)])

    runner = web.AppRunner(app)

    await runner.setup()

    site = web.TCPSite(runner, "localhost", port)
    await site.start()

    yield f"http://localhost:{port}/"

    await runner.cleanup()


@pytest.fixture
async def client_session():
    async with aiohttp.ClientSession() as session:
        yield session
