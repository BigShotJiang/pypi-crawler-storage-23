"""File storage adapters."""

from .local import LocalFileStorage

__all__ = ["LocalFileStorage"]
