"""Port interfaces for hexdag-storage."""

from .vector_store import VectorStorePort

__all__ = ["VectorStorePort"]
