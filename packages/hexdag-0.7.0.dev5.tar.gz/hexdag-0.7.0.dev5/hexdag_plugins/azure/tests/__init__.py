"""Tests for hexdag-azure plugin."""
