"""SQLite adapter for hexDAG."""

from hexdag.stdlib.adapters.database.sqlite.sqlite_adapter import SQLiteAdapter

__all__ = ["SQLiteAdapter"]
