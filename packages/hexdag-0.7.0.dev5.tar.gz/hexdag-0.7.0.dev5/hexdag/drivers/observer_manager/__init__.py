"""Observer manager drivers."""

from hexdag.drivers.observer_manager.local import LocalObserverManager

__all__ = ["LocalObserverManager"]
