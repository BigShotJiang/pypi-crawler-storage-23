"""Validation utilities for hexDAG framework."""
