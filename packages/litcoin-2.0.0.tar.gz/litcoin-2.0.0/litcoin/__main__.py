"""Allow `python -m litcoin` to run the multi-agent demo."""
from litcoin.demo import main
main()
