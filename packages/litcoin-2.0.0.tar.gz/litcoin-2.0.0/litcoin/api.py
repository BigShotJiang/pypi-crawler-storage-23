"""
Low-level HTTP client for the LITCOIN coordinator API.
"""

import time
import logging
import requests as _requests

log = logging.getLogger("litcoin")

COORDINATOR_URL = "https://api.litcoiin.xyz"
BACKOFF = [2, 4, 8, 16, 30, 60]


class APIError(Exception):
    """Raised when the coordinator returns an error."""
    def __init__(self, status, message, body=None):
        self.status = status
        self.message = message
        self.body = body
        super().__init__(f"HTTP {status}: {message}")


class CoordinatorAPI:
    """HTTP client wrapping all coordinator endpoints."""

    def __init__(self, base_url=None):
        self.base_url = (base_url or COORDINATOR_URL).rstrip("/")
        self.session = _requests.Session()
        self.session.headers["Content-Type"] = "application/json"

    def _request(self, method, path, retries=3, **kwargs):
        url = f"{self.base_url}{path}"
        for attempt in range(retries):
            try:
                r = self.session.request(method, url, timeout=30, **kwargs)
                if r.status_code == 429:
                    wait = BACKOFF[min(attempt, len(BACKOFF) - 1)]
                    log.warning(f"Rate limited on {path}, retry in {wait}s")
                    time.sleep(wait)
                    continue
                return r
            except Exception as e:
                if attempt < retries - 1:
                    wait = BACKOFF[min(attempt, len(BACKOFF) - 1)]
                    log.warning(f"Request failed ({e}), retry in {wait}s")
                    time.sleep(wait)
                else:
                    raise APIError(0, f"All {retries} retries exhausted: {e}")
        raise APIError(429, "Rate limited after all retries")

    def _get(self, path, **kwargs):
        return self._request("GET", path, **kwargs)

    def _post(self, path, **kwargs):
        return self._request("POST", path, **kwargs)

    # ─── Auth ─────────────────────────────────────────────────────────────────

    def get_nonce(self, wallet):
        r = self._post("/v1/auth/nonce", json={"miner": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Nonce failed", r.text)
        return r.json()["message"]

    def verify_auth(self, wallet, message, signature):
        r = self._post("/v1/auth/verify", json={
            "miner": wallet, "message": message, "signature": signature
        })
        if r.status_code != 200:
            raise APIError(r.status_code, "Auth verify failed", r.text)
        return r.json()["token"]

    # ─── Mining ───────────────────────────────────────────────────────────────

    def get_challenge(self, nonce, auth_token):
        r = self._get("/v1/challenge", params={"nonce": nonce},
                       headers={"Authorization": f"Bearer {auth_token}"})
        if r.status_code == 401:
            raise APIError(401, "Auth expired")
        if r.status_code == 403:
            raise APIError(403, r.json().get("error", "Forbidden"), r.text)
        if r.status_code != 200:
            raise APIError(r.status_code, "Challenge failed", r.text)
        return r.json()

    def submit_solution(self, challenge_id, artifact, nonce, auth_token):
        r = self._post("/v1/submit", json={
            "challengeId": challenge_id, "artifact": artifact, "nonce": nonce
        }, headers={"Authorization": f"Bearer {auth_token}"})
        if r.status_code == 401:
            raise APIError(401, "Auth expired")
        if r.status_code not in (200, 201):
            raise APIError(r.status_code, "Submit failed", r.text)
        return r.json()

    # ─── Claims ───────────────────────────────────────────────────────────────

    def claims_status(self, wallet):
        r = self._get("/v1/claims/status", params={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Claims status failed", r.text)
        return r.json()

    def claims_sign(self, wallet):
        r = self._post("/v1/claims/sign", json={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Claims sign failed", r.text)
        return r.json()

    def claims_bankr(self, wallet):
        """Claim via coordinator (for Bankr smart wallets)."""
        r = self._post("/v1/claims/bankr", json={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Bankr claim failed", r.text)
        return r.json()

    # ─── Stats ────────────────────────────────────────────────────────────────

    def network_stats(self):
        r = self._get("/v1/claims/stats")
        return r.json()

    def leaderboard(self, limit=20):
        r = self._get("/v1/claims/leaderboard", params={"limit": limit})
        return r.json()

    def health(self):
        r = self._get("/v1/health")
        return r.json()

    # ─── Staking ──────────────────────────────────────────────────────────────

    def get_boost(self, wallet):
        r = self._get("/v1/boost", params={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Boost check failed", r.text)
        return r.json()

    def register_staker(self, wallet):
        r = self._post("/v1/staking/register", json={"wallet": wallet})
        return r.json()

    def staking_yield(self, wallet):
        r = self._get("/v1/staking/yield", params={"wallet": wallet})
        return r.json()

    def staking_stats(self):
        r = self._get("/v1/staking/stats")
        return r.json()

    # ─── Compute ──────────────────────────────────────────────────────────────

    def compute_request(self, prompt, model=None, max_tokens=4096, wallet=None):
        payload = {"prompt": prompt, "maxTokens": max_tokens}
        if model:
            payload["model"] = model
        if wallet:
            payload["wallet"] = wallet
        r = self._post("/v1/compute/request", json=payload)
        if r.status_code != 200:
            raise APIError(r.status_code, "Compute request failed", r.text)
        return r.json()

    def compute_health(self):
        r = self._get("/v1/compute/health")
        return r.json()

    def compute_providers(self):
        r = self._get("/v1/compute/providers")
        return r.json()

    def compute_stats(self):
        r = self._get("/v1/compute/stats")
        return r.json()
