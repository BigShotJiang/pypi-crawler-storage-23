"""Integration tests for coronagraphoto."""
