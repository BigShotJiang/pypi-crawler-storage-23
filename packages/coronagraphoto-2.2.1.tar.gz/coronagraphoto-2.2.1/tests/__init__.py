"""Test utilities for coronagraphoto."""
