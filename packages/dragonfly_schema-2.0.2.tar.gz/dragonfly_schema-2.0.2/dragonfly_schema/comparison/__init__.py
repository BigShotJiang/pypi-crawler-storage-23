"""Dragonfly objects specific to comparison with other models."""
