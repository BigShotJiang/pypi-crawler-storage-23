"""Dragonfly objects specific to energy simulation."""
