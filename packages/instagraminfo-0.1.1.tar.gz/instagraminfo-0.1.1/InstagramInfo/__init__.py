import os, sys, json

try:
    import httpx
except ImportError:
    os.system(f"{sys.executable} -m pip install httpx[http2]")
    import httpx

def info(username: str):
        url = f"https://i.instagram.com/api/v1/users/web_profile_info/?username={username}"
        headers = {"X-IG-App-ID": "936619743392459"}

        with httpx.Client(http2=True, headers=headers, timeout=10.0) as session:
            response = session.get(url)
            data = response.json()
            user = data.get('data', {}).get('user', {})

            return {
                "name": user.get('full_name', 'N/A'),
                "username": user.get('username', 'N/A'),
                "id": user.get('id', 'N/A'),
                "bio": user.get('biography', 'N/A'),
                "followers": user.get('edge_followed_by', {}).get('count', 0),
                "following": user.get('edge_follow', {}).get('count', 0),
                "posts": user.get('edge_owner_to_timeline_media', {}).get('count', 0),
                "is_private": user.get('is_private', False),
                "is_verified": user.get('is_verified', False),
                "is_professional_account": user.get('is_professional_account', False),
                "category": user.get('category_name', 'N/A'),
                "email": user.get('business_email') or user.get('public_email') or 'N/A',
                "phone": user.get('business_phone_number') or user.get('public_phone_number') or 'N/A',
                "external_url": user.get('external_url', 'N/A'),
                "profile_pic": user.get('profile_pic_url', 'N/A')
            }
