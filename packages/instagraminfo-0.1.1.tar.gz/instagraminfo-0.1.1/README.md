# InstagramInfo

A simple Python library to get Instagram user profile information.

## Installation

```bash
pip install InstagramInfo
```

## Usage

```python
from instagram_info import info

user_data = info("username")
print(user_data)
```
