"""
MechForge: Next-Generation Mechanical Engineering Python Platform.

A comprehensive, open-source Python library for mechanical and industrial
engineers, unifying structural analysis, fluid mechanics, thermodynamics,
machine design, dynamics, controls, manufacturing, materials science,
AI/ML, and Industry 4.0 capabilities.

Examples
--------
>>> import mechforge as mf
>>> shaft = mf.machine.Shaft(
...     length=mf.Q(500, 'mm'),
...     torque=mf.Q(200, 'N*m'),
...     material=mf.materials.get('AISI 4140'),
... )
>>> result = shaft.analyze()
"""

from __future__ import annotations

__version__ = "0.1.0"
__author__ = "MechForge Team"

# Core imports — always available
from mechforge.core.units import ureg, Q, Q_
from mechforge.core.exceptions import (
    MechForgeError,
    UnitError,
    MaterialNotFoundError,
    ConvergenceError,
    InsufficientDataError,
    ValidationError,
)
from mechforge.core.constants import PhysicalConstants
from mechforge.core import constants

# Lazy sub-package imports
from mechforge import core
from mechforge import structural
from mechforge import machine
from mechforge import fluids
from mechforge import thermal
from mechforge import reports

# Convenience alias for materials
from mechforge.core.materials import get_material, list_materials, MaterialDatabase

__all__ = [
    # Version
    "__version__",
    # Core
    "ureg",
    "Q",
    "Q_",
    "constants",
    "PhysicalConstants",
    "core",
    # Materials
    "get_material",
    "list_materials",
    "MaterialDatabase",
    # Modules
    "structural",
    "machine",
    "fluids",
    "thermal",
    "reports",
    # Exceptions
    "MechForgeError",
    "UnitError",
    "MaterialNotFoundError",
    "ConvergenceError",
    "InsufficientDataError",
    "ValidationError",
]
