"""
MechForge API Module (Stub).

REST API interface for exposing MechForge calculations as web services.
Built on FastAPI for high-performance async operation.
Full implementation planned for v0.3.0.

Requires: pip install mechforge[api]
"""

from __future__ import annotations


def create_api_app():
    """Create FastAPI application for MechForge.

    Returns
    -------
    FastAPI
        Configured FastAPI application.

    Raises
    ------
    ImportError
        If FastAPI is not installed.
    """
    try:
        from fastapi import FastAPI
    except ImportError:
        raise ImportError(
            "API module requires FastAPI. "
            "Install with: pip install mechforge[api]"
        )

    app = FastAPI(
        title="MechForge API",
        description="RESTful API for mechanical engineering calculations",
        version="0.1.0",
    )

    @app.get("/health")
    def health():
        return {"status": "healthy", "version": "0.1.0"}

    @app.get("/materials/{name}")
    def get_material(name: str):
        from mechforge.core.materials import get_material
        mat = get_material(name)
        return {
            "name": mat.name,
            "category": mat.category,
            "density": str(mat.density),
            "elastic_modulus": str(mat.elastic_modulus),
            "yield_strength": str(mat.yield_strength),
            "ultimate_strength": str(mat.ultimate_strength),
        }

    return app


__all__ = ["create_api_app"]
