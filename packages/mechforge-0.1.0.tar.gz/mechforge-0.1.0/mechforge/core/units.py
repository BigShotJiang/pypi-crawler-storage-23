"""
MechForge Unit System.

Pint-based unit engine providing automatic unit conversion, validation,
and dimensional analysis for all engineering calculations.

Every value in MechForge carries units — no ambiguity, no guessing.

References
----------
.. [1] NIST SP 811 — Guide for the Use of the International System of Units
.. [2] Pint Documentation: https://pint.readthedocs.io

Examples
--------
>>> from mechforge.core.units import Q, ureg
>>> force = Q(100, 'kN')
>>> area = Q(0.01, 'm**2')
>>> stress = (force / area).to('MPa')
>>> print(stress)
10.0 megapascal
"""

from __future__ import annotations

import pint

# Global unit registry — single instance for the entire library
ureg = pint.UnitRegistry()
ureg.default_format = "~P"  # Short pretty format

# Quantity constructor shorthand
Q_ = ureg.Quantity


def Q(value: float | int, unit: str) -> pint.Quantity:
    """Create a Quantity with value and unit.

    Convenience function for creating unit-aware quantities. This is the
    primary interface for users to create physical quantities in MechForge.

    Parameters
    ----------
    value : float or int
        The numerical value.
    unit : str
        The unit string (e.g., 'mm', 'MPa', 'N*m', 'kg/m**3').

    Returns
    -------
    pint.Quantity
        A Pint Quantity object with value and unit.

    Examples
    --------
    >>> length = Q(500, 'mm')
    >>> print(length.to('m'))
    0.5 m

    >>> stress = Q(250, 'MPa')
    >>> print(stress.to('psi'))
    36259.4... psi

    >>> torque = Q(200, 'N*m')
    >>> print(torque.to('lbf*ft'))
    147.5... ft·lbf
    """
    return ureg.Quantity(value, unit)


def to_base_units(quantity: pint.Quantity) -> pint.Quantity:
    """Convert a quantity to SI base units.

    Parameters
    ----------
    quantity : pint.Quantity
        Input quantity in any compatible unit.

    Returns
    -------
    pint.Quantity
        The quantity expressed in SI base units.

    Examples
    --------
    >>> to_base_units(Q(500, 'mm'))
    <Quantity(0.5, 'meter')>
    """
    return quantity.to_base_units()


def check_dimensionality(
    quantity: pint.Quantity, expected: str, name: str = "value"
) -> None:
    """Verify that a quantity has the expected dimensionality.

    Parameters
    ----------
    quantity : pint.Quantity
        The quantity to check.
    expected : str
        Expected dimensionality string (e.g., '[length]', '[pressure]').
    name : str, optional
        Parameter name for error messages.

    Raises
    ------
    mechforge.core.exceptions.UnitError
        If the dimensionality does not match.
    """
    from mechforge.core.exceptions import UnitError

    if not quantity.check(expected):
        raise UnitError(
            f"Parameter '{name}' has dimensionality {quantity.dimensionality} "
            f"but expected {expected}."
        )


def ensure_quantity(
    value: float | int | pint.Quantity, default_unit: str
) -> pint.Quantity:
    """Ensure a value is a Quantity, applying default unit if necessary.

    Parameters
    ----------
    value : float, int, or pint.Quantity
        If a plain number, it will be wrapped with default_unit.
        If already a Quantity, it is returned as-is.
    default_unit : str
        The unit to apply if value is a plain number.

    Returns
    -------
    pint.Quantity
        The value as a Quantity.

    Examples
    --------
    >>> ensure_quantity(100, 'MPa')
    <Quantity(100, 'megapascal')>

    >>> ensure_quantity(Q(100, 'ksi'), 'MPa')
    <Quantity(100, 'ksi')>
    """
    if isinstance(value, pint.Quantity):
        return value
    return Q(value, default_unit)
