"""
MechForge Physical Constants.

Provides commonly used physical and engineering constants as Pint Quantities
with proper units. All constants sourced from NIST CODATA 2018 or
authoritative engineering references.

References
----------
.. [1] NIST CODATA 2018 — Fundamental Physical Constants
.. [2] CRC Handbook of Chemistry and Physics, 103rd Edition

Examples
--------
>>> from mechforge.core.constants import PhysicalConstants as PC
>>> print(PC.g)
9.80665 m/s²
>>> print(PC.R)
8.314... J/(mol·K)
"""

from __future__ import annotations

from mechforge.core.units import Q


class PhysicalConstants:
    """Collection of physical and engineering constants with units.

    All constants are provided as Pint Quantities with proper SI units.
    Access constants as class attributes.

    Attributes
    ----------
    g : Quantity
        Standard gravitational acceleration (9.80665 m/s²).
    R : Quantity
        Universal gas constant (8.31446 J/(mol·K)).
    sigma_sb : Quantity
        Stefan-Boltzmann constant (5.670374419e-8 W/(m²·K⁴)).
    k_B : Quantity
        Boltzmann constant (1.380649e-23 J/K).
    N_A : Quantity
        Avogadro's number (6.02214076e23 1/mol).
    atm : Quantity
        Standard atmospheric pressure (101325 Pa).
    """

    # Gravitational
    g = Q(9.80665, "m/s**2")

    # Thermodynamic
    R = Q(8.31446261815324, "J/(mol*K)")  # Universal gas constant
    k_B = Q(1.380649e-23, "J/K")  # Boltzmann constant
    N_A = Q(6.02214076e23, "1/mol")  # Avogadro's number

    # Radiation
    sigma_sb = Q(5.670374419e-8, "W/(m**2*K**4)")  # Stefan-Boltzmann

    # Standard conditions
    atm = Q(101325, "Pa")  # Standard atmospheric pressure
    T_std = Q(273.15, "K")  # Standard temperature (0°C)
    T_ref = Q(293.15, "K")  # Reference temperature (20°C)

    # Water properties at 20°C
    rho_water = Q(998.2, "kg/m**3")
    mu_water = Q(1.002e-3, "Pa*s")
    cp_water = Q(4182, "J/(kg*K)")

    # Air properties at 20°C, 1 atm
    rho_air = Q(1.204, "kg/m**3")
    mu_air = Q(1.825e-5, "Pa*s")
    cp_air = Q(1006, "J/(kg*K)")
    k_air = Q(0.0257, "W/(m*K)")
    gamma_air = 1.4  # Specific heat ratio (dimensionless)
    R_air = Q(287.058, "J/(kg*K)")  # Specific gas constant for air

    # Steel typical properties (quick reference)
    E_steel = Q(200, "GPa")  # Young's modulus
    nu_steel = 0.3  # Poisson's ratio
    rho_steel = Q(7850, "kg/m**3")

    # Aluminum typical properties
    E_aluminum = Q(69, "GPa")
    nu_aluminum = 0.33
    rho_aluminum = Q(2700, "kg/m**3")

    # Mathematical / Conversion
    pi = 3.141592653589793

    @classmethod
    def list_all(cls) -> dict[str, str]:
        """List all available constants with their values.

        Returns
        -------
        dict
            Dictionary of constant names and their string representations.
        """
        result = {}
        for name in dir(cls):
            if not name.startswith("_") and name != "list_all":
                val = getattr(cls, name)
                result[name] = str(val)
        return result
