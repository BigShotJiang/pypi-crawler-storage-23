"""
MechForge Input Validators.

Utility functions for validating engineering inputs: positive values,
quantity dimensions, ranges, etc.
"""

from __future__ import annotations

from typing import Any

import pint

from mechforge.core.exceptions import ValidationError, UnitError


def validate_positive(value: Any, name: str = "value") -> None:
    """Validate that a value is positive.

    Parameters
    ----------
    value : float, int, or pint.Quantity
        The value to validate.
    name : str
        Parameter name for error messages.

    Raises
    ------
    ValidationError
        If the value is not positive.
    """
    magnitude = value.magnitude if isinstance(value, pint.Quantity) else value
    if magnitude <= 0:
        raise ValidationError(f"Parameter '{name}' must be positive, got {value}.")


def validate_non_negative(value: Any, name: str = "value") -> None:
    """Validate that a value is non-negative.

    Parameters
    ----------
    value : float, int, or pint.Quantity
        The value to validate.
    name : str
        Parameter name for error messages.

    Raises
    ------
    ValidationError
        If the value is negative.
    """
    magnitude = value.magnitude if isinstance(value, pint.Quantity) else value
    if magnitude < 0:
        raise ValidationError(f"Parameter '{name}' must be non-negative, got {value}.")


def validate_quantity(value: Any, name: str = "value") -> None:
    """Validate that a value is a Pint Quantity.

    Parameters
    ----------
    value : Any
        The value to check.
    name : str
        Parameter name for error messages.

    Raises
    ------
    UnitError
        If value is not a Pint Quantity.
    """
    if not isinstance(value, pint.Quantity):
        raise UnitError(
            f"Parameter '{name}' must be a Pint Quantity (use mf.Q(value, 'unit')), "
            f"got {type(value).__name__}."
        )


def validate_dimensionality(
    value: pint.Quantity, expected: str, name: str = "value"
) -> None:
    """Validate that a Quantity has the expected dimensionality.

    Parameters
    ----------
    value : pint.Quantity
        The quantity to check.
    expected : str
        Expected dimensionality (e.g., '[length]', '[pressure]').
    name : str
        Parameter name for error messages.

    Raises
    ------
    UnitError
        If dimensionality does not match.
    """
    if not isinstance(value, pint.Quantity):
        raise UnitError(f"Parameter '{name}' must be a Pint Quantity.")
    if not value.check(expected):
        raise UnitError(
            f"Parameter '{name}' has dimensionality {value.dimensionality} "
            f"but expected {expected}."
        )


def validate_range(
    value: Any,
    min_val: float | None = None,
    max_val: float | None = None,
    name: str = "value",
) -> None:
    """Validate that a value is within a specified range.

    Parameters
    ----------
    value : float, int, or pint.Quantity
        The value to validate.
    min_val : float, optional
        Minimum allowed value (magnitude).
    max_val : float, optional
        Maximum allowed value (magnitude).
    name : str
        Parameter name for error messages.

    Raises
    ------
    ValidationError
        If value is outside the valid range.
    """
    magnitude = value.magnitude if isinstance(value, pint.Quantity) else value
    if min_val is not None and magnitude < min_val:
        raise ValidationError(
            f"Parameter '{name}' must be >= {min_val}, got {magnitude}."
        )
    if max_val is not None and magnitude > max_val:
        raise ValidationError(
            f"Parameter '{name}' must be <= {max_val}, got {magnitude}."
        )


def validate_in_set(value: Any, valid_set: set | list | tuple, name: str = "value") -> None:
    """Validate that a value is in a set of allowed values.

    Parameters
    ----------
    value : Any
        The value to check.
    valid_set : set, list, or tuple
        Allowed values.
    name : str
        Parameter name for error messages.

    Raises
    ------
    ValidationError
        If value is not in the valid set.
    """
    if value not in valid_set:
        raise ValidationError(
            f"Parameter '{name}' must be one of {sorted(valid_set)}, got '{value}'."
        )
