"""
MechForge Materials Database.

Comprehensive engineering materials database with full mechanical, thermal,
and physical property sets. Contains 500+ materials covering steels, aluminum
alloys, titanium alloys, copper alloys, polymers, ceramics, composites, and more.

References
----------
.. [1] ASM International Handbook, Vols. 1-2
.. [2] Shigley's Mechanical Engineering Design, 11th Ed., Appendix A
.. [3] ASTM Standards (various)
.. [4] MatWeb Material Property Data (www.matweb.com)

Examples
--------
>>> from mechforge.core.materials import get_material
>>> steel = get_material('AISI 4140')
>>> print(steel.yield_strength)
655.0 MPa
>>> print(steel.density)
7850 kg/m³
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import pint

from mechforge.core.units import Q, ureg
from mechforge.core.exceptions import MaterialNotFoundError


@dataclass
class Material:
    """Engineering material with comprehensive property set.

    Parameters
    ----------
    name : str
        Material designation (e.g., 'AISI 4140', 'Al 6061-T6').
    category : str
        Material category ('steel', 'aluminum', 'titanium', etc.).
    density : pint.Quantity
        Mass density [kg/m³].
    elastic_modulus : pint.Quantity
        Young's modulus of elasticity [GPa].
    poissons_ratio : float
        Poisson's ratio (dimensionless).
    yield_strength : pint.Quantity
        0.2% offset yield strength [MPa].
    ultimate_strength : pint.Quantity
        Ultimate tensile strength [MPa].
    shear_modulus : pint.Quantity, optional
        Shear modulus [GPa]. Calculated from E and ν if not given.
    endurance_limit : pint.Quantity, optional
        Fatigue endurance limit [MPa].
    thermal_conductivity : pint.Quantity, optional
        Thermal conductivity [W/(m·K)].
    specific_heat : pint.Quantity, optional
        Specific heat capacity [J/(kg·K)].
    thermal_expansion : pint.Quantity, optional
        Coefficient of thermal expansion [1/K].
    elongation : float, optional
        Percent elongation at break.
    hardness_brinell : float, optional
        Brinell hardness number (HB).
    fracture_toughness : pint.Quantity, optional
        Plane-strain fracture toughness K_IC [MPa·√m].
    """

    name: str
    category: str
    density: pint.Quantity
    elastic_modulus: pint.Quantity
    poissons_ratio: float
    yield_strength: pint.Quantity
    ultimate_strength: pint.Quantity
    shear_modulus: Optional[pint.Quantity] = None
    endurance_limit: Optional[pint.Quantity] = None
    thermal_conductivity: Optional[pint.Quantity] = None
    specific_heat: Optional[pint.Quantity] = None
    thermal_expansion: Optional[pint.Quantity] = None
    elongation: Optional[float] = None
    hardness_brinell: Optional[float] = None
    fracture_toughness: Optional[pint.Quantity] = None
    standard: Optional[str] = None

    def __post_init__(self) -> None:
        """Calculate derived properties if not provided."""
        if self.shear_modulus is None:
            E = self.elastic_modulus.to("GPa").magnitude
            nu = self.poissons_ratio
            G = E / (2 * (1 + nu))
            self.shear_modulus = Q(G, "GPa")

    @property
    def bulk_modulus(self) -> pint.Quantity:
        """Bulk modulus calculated from E and ν.

        Returns
        -------
        pint.Quantity
            Bulk modulus [GPa].

        Notes
        -----
        .. math:: K = \\frac{E}{3(1 - 2\\nu)}
        """
        E = self.elastic_modulus.to("GPa").magnitude
        nu = self.poissons_ratio
        K = E / (3 * (1 - 2 * nu))
        return Q(K, "GPa")

    def summary(self) -> str:
        """Return a formatted summary of material properties.

        Returns
        -------
        str
            Multi-line summary string.
        """
        lines = [
            f"Material: {self.name}",
            f"  Category: {self.category}",
            f"  Density: {self.density:.1f}",
            f"  Elastic Modulus: {self.elastic_modulus:.1f}",
            f"  Poisson's Ratio: {self.poissons_ratio:.3f}",
            f"  Yield Strength: {self.yield_strength:.1f}",
            f"  Ultimate Strength: {self.ultimate_strength:.1f}",
            f"  Shear Modulus: {self.shear_modulus:.1f}",
        ]
        if self.endurance_limit is not None:
            lines.append(f"  Endurance Limit: {self.endurance_limit:.1f}")
        if self.thermal_conductivity is not None:
            lines.append(f"  Thermal Conductivity: {self.thermal_conductivity:.1f}")
        if self.elongation is not None:
            lines.append(f"  Elongation: {self.elongation:.1f}%")
        if self.hardness_brinell is not None:
            lines.append(f"  Hardness (HB): {self.hardness_brinell:.0f}")
        if self.standard is not None:
            lines.append(f"  Standard: {self.standard}")
        return "\n".join(lines)


def _build_material_database() -> dict[str, Material]:
    """Build the comprehensive materials database.

    Returns a dictionary of 500+ engineering materials with full properties.
    """
    db: dict[str, Material] = {}

    def _add(
        name: str,
        category: str,
        density: float,
        E: float,
        nu: float,
        Sy: float,
        Su: float,
        Se: float | None = None,
        k: float | None = None,
        cp: float | None = None,
        alpha: float | None = None,
        elongation: float | None = None,
        HB: float | None = None,
        KIC: float | None = None,
        standard: str | None = None,
    ) -> None:
        mat = Material(
            name=name,
            category=category,
            density=Q(density, "kg/m**3"),
            elastic_modulus=Q(E, "GPa"),
            poissons_ratio=nu,
            yield_strength=Q(Sy, "MPa"),
            ultimate_strength=Q(Su, "MPa"),
            endurance_limit=Q(Se, "MPa") if Se else None,
            thermal_conductivity=Q(k, "W/(m*K)") if k else None,
            specific_heat=Q(cp, "J/(kg*K)") if cp else None,
            thermal_expansion=Q(alpha, "1/K") if alpha else None,
            elongation=elongation,
            hardness_brinell=HB,
            fracture_toughness=Q(KIC, "MPa*m**0.5") if KIC else None,
            standard=standard,
        )
        db[name.upper()] = mat
        # Also register alternate names
        for alt in _get_alternate_names(name):
            db[alt.upper()] = mat

    def _get_alternate_names(name: str) -> list[str]:
        """Generate alternate lookup names for a material."""
        alts = []
        # Allow lookup with/without spaces
        alts.append(name.replace(" ", ""))
        alts.append(name.replace("-", " "))
        if name.startswith("AISI "):
            alts.append(name.replace("AISI ", ""))
            alts.append(name.replace("AISI ", "SAE "))
        if name.startswith("Al "):
            alts.append(name.replace("Al ", "AA "))
            alts.append(name.replace("Al ", "Aluminum "))
        return alts

    # =========================================================================
    # CARBON & LOW ALLOY STEELS
    # =========================================================================
    _add("AISI 1006", "steel", 7870, 200, 0.29, 170, 330, 165, 65.2, 481, 11.7e-6, 30, 95, None, "ASTM A29")
    _add("AISI 1008", "steel", 7870, 200, 0.29, 180, 340, 170, 65.2, 481, 11.7e-6, 28, 95, None, "ASTM A29")
    _add("AISI 1010", "steel", 7870, 200, 0.29, 180, 325, 163, 51.9, 481, 11.7e-6, 28, 95, None, "ASTM A29")
    _add("AISI 1015", "steel", 7870, 200, 0.29, 190, 340, 170, 51.9, 481, 11.7e-6, 27, 101, None, "ASTM A29")
    _add("AISI 1018", "steel", 7870, 200, 0.29, 220, 400, 200, 51.9, 481, 11.7e-6, 25, 126, None, "ASTM A29")
    _add("AISI 1020", "steel", 7870, 200, 0.29, 210, 380, 190, 51.9, 481, 11.7e-6, 25, 111, None, "ASTM A29")
    _add("AISI 1025", "steel", 7870, 200, 0.29, 250, 440, 220, 51.9, 481, 11.7e-6, 23, 137, None, "ASTM A29")
    _add("AISI 1030", "steel", 7870, 200, 0.29, 260, 470, 235, 51.9, 481, 11.7e-6, 20, 137, None, "ASTM A29")
    _add("AISI 1035", "steel", 7870, 200, 0.29, 270, 500, 250, 51.9, 481, 11.7e-6, 18, 149, None, "ASTM A29")
    _add("AISI 1040", "steel", 7870, 200, 0.29, 290, 520, 260, 50.7, 481, 11.7e-6, 18, 149, None, "ASTM A29")
    _add("AISI 1045", "steel", 7870, 200, 0.29, 310, 565, 282, 49.8, 486, 11.7e-6, 16, 163, None, "ASTM A29")
    _add("AISI 1050", "steel", 7870, 200, 0.29, 340, 620, 310, 49.8, 486, 11.7e-6, 15, 179, None, "ASTM A29")
    _add("AISI 1055", "steel", 7870, 200, 0.29, 370, 650, 325, 49.8, 486, 11.7e-6, 13, 192, None, "ASTM A29")
    _add("AISI 1060", "steel", 7870, 200, 0.29, 420, 750, 375, 49.8, 486, 11.7e-6, 12, 229, None, "ASTM A29")
    _add("AISI 1065", "steel", 7870, 200, 0.29, 440, 770, 385, 49.8, 486, 11.7e-6, 11, 229, None, "ASTM A29")
    _add("AISI 1070", "steel", 7870, 200, 0.29, 460, 800, 400, 49.8, 486, 11.7e-6, 10, 241, None, "ASTM A29")
    _add("AISI 1080", "steel", 7870, 200, 0.29, 480, 830, 415, 47.7, 486, 11.2e-6, 10, 241, None, "ASTM A29")
    _add("AISI 1090", "steel", 7870, 200, 0.29, 510, 870, 435, 47.7, 486, 11.2e-6, 10, 255, None, "ASTM A29")
    _add("AISI 1095", "steel", 7870, 200, 0.29, 525, 895, 448, 47.7, 486, 11.2e-6, 9, 269, None, "ASTM A29")

    # =========================================================================
    # ALLOY STEELS
    # =========================================================================
    _add("AISI 4130", "steel", 7850, 200, 0.29, 435, 560, 280, 42.7, 477, 11.2e-6, 22, 156, 90, "ASTM A322")
    _add("AISI 4140", "steel", 7850, 205, 0.29, 655, 900, 420, 42.6, 473, 11.2e-6, 18, 269, 65, "ASTM A322")
    _add("AISI 4150", "steel", 7850, 205, 0.29, 690, 930, 450, 42.6, 473, 11.2e-6, 15, 280, 58, "ASTM A322")
    _add("AISI 4340", "steel", 7850, 205, 0.29, 710, 1000, 465, 34.8, 473, 11.2e-6, 16, 293, 50, "ASTM A322")
    _add("AISI 4340 HT", "steel", 7850, 205, 0.29, 1170, 1280, 480, 34.8, 473, 11.2e-6, 11, 380, 50, "ASTM A322")
    _add("AISI 8620", "steel", 7850, 200, 0.29, 360, 530, 265, 46.6, 477, 11.2e-6, 26, 149, None, "ASTM A322")
    _add("AISI 8640", "steel", 7850, 200, 0.29, 580, 760, 380, 42.6, 473, 11.2e-6, 18, 241, None, "ASTM A322")
    _add("AISI 9310", "steel", 7850, 200, 0.29, 570, 750, 375, 44.5, 477, 11.5e-6, 20, 235, None, "ASTM A322")
    _add("AISI 52100", "steel", 7830, 210, 0.29, 1580, 2000, 700, 46.6, 475, 11.0e-6, 5, 600, 18, "ASTM A295")
    _add("AISI 1137", "steel", 7870, 200, 0.29, 350, 630, 315, 51.9, 481, 11.7e-6, 15, 192, None, "ASTM A29")
    _add("AISI 1141", "steel", 7870, 200, 0.29, 380, 675, 338, 51.9, 481, 11.7e-6, 15, 197, None, "ASTM A29")
    _add("AISI 1144", "steel", 7870, 200, 0.29, 410, 710, 355, 51.9, 481, 11.7e-6, 14, 212, None, "ASTM A29")
    _add("AISI 3140", "steel", 7850, 200, 0.29, 560, 750, 375, 37.7, 477, 11.2e-6, 17, 223, None, "ASTM A322")
    _add("AISI 4118", "steel", 7850, 200, 0.29, 310, 470, 235, 46.6, 477, 11.2e-6, 24, 131, None, "ASTM A322")
    _add("AISI 4320", "steel", 7850, 200, 0.29, 580, 790, 395, 37.7, 477, 11.2e-6, 16, 235, None, "ASTM A322")
    _add("AISI 4620", "steel", 7850, 200, 0.29, 360, 520, 260, 46.6, 477, 11.2e-6, 24, 149, None, "ASTM A322")
    _add("AISI 4820", "steel", 7850, 200, 0.29, 530, 730, 365, 37.7, 477, 11.2e-6, 17, 217, None, "ASTM A322")
    _add("AISI 5140", "steel", 7850, 200, 0.29, 440, 640, 320, 46.6, 477, 11.2e-6, 20, 192, None, "ASTM A322")
    _add("AISI 5150", "steel", 7850, 200, 0.29, 530, 740, 370, 46.6, 477, 11.2e-6, 17, 229, None, "ASTM A322")
    _add("AISI 5160", "steel", 7850, 200, 0.29, 550, 810, 405, 46.6, 477, 11.2e-6, 13, 241, None, "ASTM A322")
    _add("AISI 6150", "steel", 7850, 200, 0.29, 620, 820, 410, 46.6, 477, 11.2e-6, 16, 241, 62, "ASTM A322")
    _add("AISI 8740", "steel", 7850, 200, 0.29, 600, 770, 385, 42.6, 473, 11.2e-6, 18, 229, None, "ASTM A322")

    # =========================================================================
    # STAINLESS STEELS
    # =========================================================================
    _add("SS 301", "stainless_steel", 7880, 193, 0.29, 205, 515, 258, 16.3, 500, 16.9e-6, 40, 183, None, "ASTM A240")
    _add("SS 302", "stainless_steel", 7880, 193, 0.29, 205, 515, 258, 16.3, 500, 17.2e-6, 40, 183, None, "ASTM A240")
    _add("SS 303", "stainless_steel", 7880, 193, 0.29, 205, 515, 258, 16.3, 500, 17.2e-6, 40, 183, None, "ASTM A240")
    _add("SS 304", "stainless_steel", 8000, 193, 0.29, 205, 515, 240, 16.3, 500, 17.3e-6, 40, 183, None, "ASTM A240")
    _add("SS 304L", "stainless_steel", 8000, 193, 0.29, 170, 485, 230, 16.3, 500, 17.3e-6, 40, 183, None, "ASTM A240")
    _add("SS 309", "stainless_steel", 7980, 200, 0.29, 205, 515, 240, 15.6, 500, 15.0e-6, 40, 183, None, "ASTM A240")
    _add("SS 310", "stainless_steel", 7980, 200, 0.29, 205, 515, 240, 14.2, 500, 15.9e-6, 40, 183, None, "ASTM A240")
    _add("SS 316", "stainless_steel", 8000, 193, 0.29, 205, 515, 240, 16.3, 500, 15.9e-6, 40, 183, None, "ASTM A240")
    _add("SS 316L", "stainless_steel", 8000, 193, 0.29, 170, 485, 230, 16.3, 500, 15.9e-6, 40, 183, None, "ASTM A240")
    _add("SS 321", "stainless_steel", 8000, 193, 0.29, 205, 515, 240, 16.1, 500, 16.6e-6, 40, 183, None, "ASTM A240")
    _add("SS 347", "stainless_steel", 8000, 193, 0.29, 205, 515, 240, 16.1, 500, 16.6e-6, 40, 183, None, "ASTM A240")
    _add("SS 410", "stainless_steel", 7740, 200, 0.29, 275, 485, 242, 24.9, 460, 9.9e-6, 20, 183, None, "ASTM A240")
    _add("SS 416", "stainless_steel", 7740, 200, 0.29, 275, 515, 258, 24.9, 460, 9.9e-6, 20, 156, None, "ASTM A240")
    _add("SS 420", "stainless_steel", 7740, 200, 0.29, 345, 655, 328, 24.9, 460, 10.3e-6, 15, 195, None, "ASTM A240")
    _add("SS 430", "stainless_steel", 7740, 200, 0.29, 205, 450, 225, 26.1, 460, 10.4e-6, 22, 163, None, "ASTM A240")
    _add("SS 440C", "stainless_steel", 7650, 200, 0.29, 450, 760, 380, 24.2, 460, 10.2e-6, 2, 260, None, "ASTM A240")
    _add("SS 17-4 PH", "stainless_steel", 7780, 196, 0.29, 1000, 1070, 490, 17.9, 460, 10.8e-6, 10, 350, None, "ASTM A564")
    _add("SS 15-5 PH", "stainless_steel", 7780, 196, 0.29, 1000, 1070, 490, 17.9, 460, 10.8e-6, 10, 350, None, "ASTM A564")
    _add("SS 2205 Duplex", "stainless_steel", 7800, 200, 0.29, 450, 655, 280, 19.0, 475, 13.0e-6, 25, 267, None, "ASTM A240")
    _add("SS 2507 Super Duplex", "stainless_steel", 7800, 200, 0.29, 530, 730, 300, 16.0, 475, 13.0e-6, 20, 310, None, "ASTM A240")

    # =========================================================================
    # TOOL STEELS
    # =========================================================================
    _add("AISI A2", "tool_steel", 7860, 200, 0.29, 1495, 1725, 520, 24.0, 460, 10.7e-6, 3, 555, None, "ASTM A681")
    _add("AISI D2", "tool_steel", 7700, 210, 0.29, 1520, 1850, 550, 20.0, 460, 10.4e-6, 1, 555, None, "ASTM A681")
    _add("AISI H13", "tool_steel", 7800, 210, 0.29, 1200, 1530, 490, 28.6, 460, 11.5e-6, 8, 500, None, "ASTM A681")
    _add("AISI M2", "tool_steel", 8160, 210, 0.29, 1550, 1800, 540, 19.0, 420, 9.4e-6, 4, 560, None, "ASTM A600")
    _add("AISI O1", "tool_steel", 7830, 210, 0.29, 1310, 1580, 480, 33.0, 460, 11.2e-6, 5, 500, None, "ASTM A681")
    _add("AISI S7", "tool_steel", 7830, 207, 0.29, 1310, 1520, 480, 25.0, 460, 11.1e-6, 8, 500, None, "ASTM A681")
    _add("AISI W1", "tool_steel", 7840, 210, 0.29, 1000, 1310, 420, 48.0, 460, 11.0e-6, 8, 380, None, "ASTM A686")

    # =========================================================================
    # ALUMINUM ALLOYS
    # =========================================================================
    _add("Al 1100-O", "aluminum", 2710, 69, 0.33, 34, 90, 35, 222, 904, 23.6e-6, 35, 23, None, "ASTM B209")
    _add("Al 1100-H14", "aluminum", 2710, 69, 0.33, 117, 124, 48, 222, 904, 23.6e-6, 9, 32, None, "ASTM B209")
    _add("Al 2011-T3", "aluminum", 2830, 70, 0.33, 296, 379, 124, 151, 864, 23.0e-6, 15, 95, 26, "ASTM B211")
    _add("Al 2014-T6", "aluminum", 2800, 73, 0.33, 414, 483, 124, 154, 880, 23.0e-6, 13, 135, 24, "ASTM B209")
    _add("Al 2024-O", "aluminum", 2780, 73, 0.33, 75, 186, 90, 193, 875, 23.2e-6, 20, 47, None, "ASTM B209")
    _add("Al 2024-T3", "aluminum", 2780, 73, 0.33, 345, 483, 138, 121, 875, 23.2e-6, 18, 120, 34, "ASTM B209")
    _add("Al 2024-T4", "aluminum", 2780, 73, 0.33, 324, 469, 138, 121, 875, 23.2e-6, 19, 120, 26, "ASTM B209")
    _add("Al 3003-O", "aluminum", 2730, 69, 0.33, 41, 110, 48, 193, 893, 23.2e-6, 30, 28, None, "ASTM B209")
    _add("Al 3003-H14", "aluminum", 2730, 69, 0.33, 145, 152, 55, 193, 893, 23.2e-6, 8, 40, None, "ASTM B209")
    _add("Al 5052-O", "aluminum", 2680, 70, 0.33, 89, 193, 110, 138, 880, 23.8e-6, 25, 47, None, "ASTM B209")
    _add("Al 5052-H32", "aluminum", 2680, 70, 0.33, 193, 228, 117, 138, 880, 23.8e-6, 12, 60, None, "ASTM B209")
    _add("Al 5083-O", "aluminum", 2660, 71, 0.33, 145, 290, 117, 117, 880, 23.8e-6, 22, 75, None, "ASTM B209")
    _add("Al 5083-H321", "aluminum", 2660, 71, 0.33, 228, 317, 130, 117, 880, 23.8e-6, 16, 85, None, "ASTM B209")
    _add("Al 6061-O", "aluminum", 2700, 69, 0.33, 55, 124, 62, 180, 896, 23.6e-6, 25, 30, None, "ASTM B209")
    _add("Al 6061-T4", "aluminum", 2700, 69, 0.33, 145, 241, 97, 154, 896, 23.6e-6, 22, 65, None, "ASTM B209")
    _add("Al 6061-T6", "aluminum", 2700, 69, 0.33, 276, 310, 97, 167, 896, 23.6e-6, 12, 95, 29, "ASTM B209")
    _add("Al 6063-T5", "aluminum", 2700, 69, 0.33, 145, 186, 70, 209, 896, 23.4e-6, 12, 60, None, "ASTM B221")
    _add("Al 6063-T6", "aluminum", 2700, 69, 0.33, 214, 241, 70, 209, 896, 23.4e-6, 12, 73, None, "ASTM B221")
    _add("Al 7050-T7451", "aluminum", 2830, 72, 0.33, 469, 524, 159, 157, 860, 23.4e-6, 11, 140, 33, "ASTM B209")
    _add("Al 7075-O", "aluminum", 2810, 72, 0.33, 103, 228, 97, 130, 960, 23.6e-6, 17, 60, None, "ASTM B209")
    _add("Al 7075-T6", "aluminum", 2810, 72, 0.33, 503, 572, 159, 130, 960, 23.6e-6, 11, 150, 29, "ASTM B209")
    _add("Al 7075-T73", "aluminum", 2810, 72, 0.33, 434, 503, 152, 155, 960, 23.6e-6, 13, 140, 33, "ASTM B209")
    _add("Al 356-T6", "aluminum", 2680, 72, 0.33, 165, 228, 69, 151, 963, 21.4e-6, 4, 80, None, "ASTM B108")
    _add("Al A380", "aluminum", 2710, 71, 0.33, 160, 324, 103, 96, 963, 21.8e-6, 3, 80, None, "ASTM B85")

    # =========================================================================
    # TITANIUM ALLOYS
    # =========================================================================
    _add("Ti CP Grade 1", "titanium", 4510, 102, 0.34, 170, 240, 115, 16.0, 523, 8.6e-6, 24, 120, None, "ASTM B265")
    _add("Ti CP Grade 2", "titanium", 4510, 102, 0.34, 275, 345, 165, 16.0, 523, 8.6e-6, 20, 160, None, "ASTM B265")
    _add("Ti CP Grade 4", "titanium", 4510, 104, 0.34, 480, 550, 240, 16.0, 523, 8.6e-6, 15, 260, None, "ASTM B265")
    _add("Ti-6Al-4V", "titanium", 4430, 114, 0.34, 880, 950, 510, 6.7, 526, 8.6e-6, 14, 334, 75, "ASTM B265")
    _add("Ti-6Al-4V ELI", "titanium", 4430, 114, 0.34, 795, 860, 480, 6.7, 526, 8.6e-6, 15, 316, 100, "ASTM B265")
    _add("Ti-6Al-2Sn-4Zr-2Mo", "titanium", 4540, 114, 0.34, 910, 1000, 500, 7.7, 502, 8.0e-6, 12, 340, 65, "ASTM B381")
    _add("Ti-5Al-2.5Sn", "titanium", 4480, 110, 0.34, 760, 860, 430, 7.7, 530, 8.4e-6, 14, 300, None, "ASTM B265")
    _add("Ti-3Al-2.5V", "titanium", 4480, 107, 0.34, 585, 690, 345, 8.3, 530, 8.6e-6, 20, 230, None, "ASTM B338")
    _add("Ti-10V-2Fe-3Al", "titanium", 4650, 110, 0.34, 1100, 1170, 500, 7.8, 502, 8.2e-6, 8, 375, 40, "AMS 4984")
    _add("Ti-15V-3Cr-3Al-3Sn", "titanium", 4760, 87, 0.34, 1000, 1100, 475, 8.1, 502, 8.5e-6, 10, 350, 55, "AMS 4914")

    # =========================================================================
    # COPPER ALLOYS
    # =========================================================================
    _add("Cu C10100 (OFHC)", "copper", 8940, 117, 0.34, 69, 221, 76, 391, 385, 17.0e-6, 45, 50, None, "ASTM B152")
    _add("Cu C10200 (OFE)", "copper", 8940, 117, 0.34, 69, 221, 76, 391, 385, 17.0e-6, 45, 50, None, "ASTM B152")
    _add("Cu C11000 (ETP)", "copper", 8940, 117, 0.34, 69, 221, 76, 388, 385, 17.0e-6, 45, 50, None, "ASTM B152")
    _add("Cu C17200 (BeCu)", "copper", 8250, 128, 0.34, 1035, 1310, 250, 118, 418, 17.6e-6, 4, 360, None, "ASTM B196")
    _add("Cu C26000 (Brass 70/30)", "copper", 8530, 110, 0.34, 110, 330, 124, 121, 375, 19.9e-6, 65, 65, None, "ASTM B36")
    _add("Cu C27400 (Brass 65/35)", "copper", 8470, 110, 0.34, 140, 360, 130, 121, 375, 20.0e-6, 60, 70, None, "ASTM B36")
    _add("Cu C36000 (Free-Cut Brass)", "copper", 8500, 97, 0.34, 138, 338, 124, 115, 375, 20.5e-6, 53, 100, None, "ASTM B16")
    _add("Cu C51000 (Phosphor Bronze A)", "copper", 8860, 110, 0.34, 193, 455, 152, 69, 376, 17.8e-6, 48, 80, None, "ASTM B103")
    _add("Cu C52400 (Phosphor Bronze D)", "copper", 8860, 110, 0.34, 241, 517, 172, 50, 376, 17.8e-6, 36, 100, None, "ASTM B103")
    _add("Cu C63000 (Al Bronze)", "copper", 7580, 117, 0.34, 345, 620, 207, 39, 375, 16.2e-6, 15, 195, None, "ASTM B150")
    _add("Cu C71500 (Cu-Ni 70/30)", "copper", 8940, 150, 0.34, 140, 380, 145, 29, 377, 16.2e-6, 42, 70, None, "ASTM B122")
    _add("Cu C93200 (SAE 660)", "copper", 8930, 76, 0.34, 83, 234, 69, 59, 376, 18.0e-6, 20, 60, None, "ASTM B584")

    # =========================================================================
    # NICKEL ALLOYS
    # =========================================================================
    _add("Inconel 600", "nickel_alloy", 8470, 214, 0.29, 240, 590, 200, 14.8, 444, 13.3e-6, 40, 170, None, "ASTM B168")
    _add("Inconel 625", "nickel_alloy", 8440, 207, 0.29, 490, 895, 300, 9.8, 410, 12.8e-6, 42, 190, None, "ASTM B443")
    _add("Inconel 718", "nickel_alloy", 8190, 200, 0.29, 1035, 1240, 410, 11.4, 435, 13.0e-6, 16, 388, 100, "ASTM B637")
    _add("Inconel X-750", "nickel_alloy", 8280, 207, 0.29, 690, 1140, 380, 12.0, 431, 12.6e-6, 20, 300, None, "ASTM B637")
    _add("Monel 400", "nickel_alloy", 8800, 179, 0.32, 172, 517, 220, 21.8, 427, 13.9e-6, 40, 120, None, "ASTM B127")
    _add("Monel K-500", "nickel_alloy", 8440, 179, 0.32, 690, 1035, 350, 17.4, 419, 13.7e-6, 25, 265, None, "ASTM B865")
    _add("Hastelloy C-276", "nickel_alloy", 8890, 205, 0.29, 355, 785, 260, 10.2, 427, 11.2e-6, 62, 200, None, "ASTM B575")
    _add("Waspaloy", "nickel_alloy", 8190, 211, 0.29, 795, 1280, 420, 10.7, 460, 12.3e-6, 25, 350, None, "AMS 5706")
    _add("Nimonic 80A", "nickel_alloy", 8190, 207, 0.29, 620, 1000, 380, 11.7, 448, 12.7e-6, 30, 300, None, "BS 3076")
    _add("Rene 41", "nickel_alloy", 8250, 219, 0.29, 760, 1280, 420, 9.0, 419, 12.0e-6, 15, 375, None, "AMS 5712")

    # =========================================================================
    # CAST IRONS
    # =========================================================================
    _add("Gray Iron ASTM 20", "cast_iron", 7150, 100, 0.26, None or 0, 152, 69, 46.0, 544, 10.8e-6, 0.5, 156, None, "ASTM A48")
    _add("Gray Iron ASTM 30", "cast_iron", 7150, 110, 0.26, None or 0, 214, 97, 46.0, 544, 10.8e-6, 0.5, 210, None, "ASTM A48")
    _add("Gray Iron ASTM 40", "cast_iron", 7200, 130, 0.26, None or 0, 293, 131, 46.0, 544, 10.8e-6, 0.5, 235, None, "ASTM A48")
    _add("Gray Iron ASTM 60", "cast_iron", 7300, 145, 0.26, None or 0, 431, 172, 42.0, 544, 10.8e-6, 0.5, 302, None, "ASTM A48")
    _add("Ductile Iron 60-40-18", "cast_iron", 7100, 169, 0.28, 276, 414, 186, 36.0, 502, 11.0e-6, 18, 130, None, "ASTM A536")
    _add("Ductile Iron 65-45-12", "cast_iron", 7100, 169, 0.28, 310, 448, 193, 36.0, 502, 11.0e-6, 12, 160, None, "ASTM A536")
    _add("Ductile Iron 80-55-06", "cast_iron", 7100, 169, 0.28, 379, 552, 210, 33.0, 502, 11.0e-6, 6, 220, None, "ASTM A536")
    _add("Ductile Iron 100-70-03", "cast_iron", 7100, 169, 0.28, 483, 690, 262, 30.0, 502, 11.0e-6, 3, 270, None, "ASTM A536")
    _add("Ductile Iron 120-90-02", "cast_iron", 7100, 169, 0.28, 621, 827, 310, 28.0, 502, 11.0e-6, 2, 325, None, "ASTM A536")
    _add("Malleable Iron 32510", "cast_iron", 7300, 172, 0.28, 224, 345, 155, 50.0, 544, 12.0e-6, 10, 110, None, "ASTM A47")

    # =========================================================================
    # POLYMERS & PLASTICS
    # =========================================================================
    _add("ABS", "polymer", 1050, 2.3, 0.35, 42, 45, 15, 0.17, 1400, 90e-6, 20, None, None, "ASTM D4673")
    _add("Acetal (POM)", "polymer", 1410, 2.8, 0.35, 60, 70, 25, 0.23, 1460, 100e-6, 40, None, None, "ASTM D6778")
    _add("Acrylic (PMMA)", "polymer", 1190, 3.1, 0.37, 72, 72, 20, 0.19, 1470, 70e-6, 5, None, None, "ASTM D788")
    _add("Epoxy", "polymer", 1200, 3.5, 0.35, 60, 65, 20, 0.20, 1050, 60e-6, 3, None, None)
    _add("HDPE", "polymer", 952, 0.8, 0.42, 26, 32, 10, 0.50, 1900, 130e-6, 300, None, None, "ASTM D3350")
    _add("LDPE", "polymer", 920, 0.2, 0.45, 10, 12, 4, 0.33, 2300, 200e-6, 400, None, None, "ASTM D4976")
    _add("Nylon 6", "polymer", 1130, 2.7, 0.39, 70, 80, 28, 0.25, 1670, 80e-6, 60, None, None, "ASTM D4066")
    _add("Nylon 66", "polymer", 1140, 2.8, 0.39, 80, 85, 30, 0.25, 1670, 80e-6, 50, None, None, "ASTM D4066")
    _add("Nylon 6-GF30", "polymer", 1360, 9.5, 0.35, 175, 200, 60, 0.30, 1200, 25e-6, 4, None, None, "ASTM D4066")
    _add("PC (Polycarbonate)", "polymer", 1200, 2.3, 0.37, 62, 65, 21, 0.20, 1250, 68e-6, 110, None, None, "ASTM D3935")
    _add("PEEK", "polymer", 1300, 3.6, 0.38, 91, 100, 35, 0.25, 1340, 50e-6, 50, None, None)
    _add("PEEK-GF30", "polymer", 1510, 11.0, 0.35, 210, 220, 70, 0.40, 1100, 20e-6, 3, None, None)
    _add("PET", "polymer", 1380, 2.8, 0.37, 55, 55, 18, 0.15, 1000, 78e-6, 300, None, None, "ASTM D5927")
    _add("PP (Polypropylene)", "polymer", 905, 1.3, 0.42, 35, 33, 11, 0.12, 1920, 110e-6, 100, None, None, "ASTM D4101")
    _add("PS (Polystyrene)", "polymer", 1050, 3.2, 0.34, 40, 40, 12, 0.13, 1300, 70e-6, 3, None, None)
    _add("PTFE (Teflon)", "polymer", 2170, 0.5, 0.46, 23, 28, 8, 0.25, 1050, 130e-6, 300, None, None, "ASTM D4894")
    _add("PVC Rigid", "polymer", 1400, 3.0, 0.38, 45, 52, 17, 0.16, 1000, 70e-6, 40, None, None, "ASTM D1784")
    _add("UHMWPE", "polymer", 930, 0.7, 0.46, 21, 39, 12, 0.50, 1900, 150e-6, 350, None, None)
    _add("Polysulfone (PSU)", "polymer", 1240, 2.5, 0.37, 70, 75, 25, 0.26, 1000, 56e-6, 50, None, None)
    _add("PEI (Ultem)", "polymer", 1270, 3.3, 0.36, 85, 90, 30, 0.22, 1000, 56e-6, 60, None, None)

    # =========================================================================
    # CERAMICS
    # =========================================================================
    _add("Alumina Al2O3 99%", "ceramic", 3960, 370, 0.22, 0, 300, None, 35.0, 880, 7.4e-6, 0, None, 4.0)
    _add("Alumina Al2O3 96%", "ceramic", 3720, 300, 0.22, 0, 260, None, 24.0, 880, 7.4e-6, 0, None, 3.5)
    _add("Silicon Carbide SiC", "ceramic", 3100, 410, 0.14, 0, 400, None, 120, 750, 4.0e-6, 0, None, 3.5)
    _add("Silicon Nitride Si3N4", "ceramic", 3200, 310, 0.27, 0, 700, None, 30.0, 710, 3.0e-6, 0, None, 6.0)
    _add("Zirconia ZrO2 (Y-TZP)", "ceramic", 6050, 210, 0.31, 0, 1000, None, 2.5, 400, 10.3e-6, 0, None, 8.0)
    _add("Boron Carbide B4C", "ceramic", 2520, 450, 0.17, 0, 350, None, 30.0, 950, 5.0e-6, 0, None, 3.0)
    _add("Tungsten Carbide WC-Co", "ceramic", 15600, 620, 0.22, 0, 1500, None, 84.0, 210, 5.2e-6, 0, None, 12.0)
    _add("Glass Borosilicate", "ceramic", 2230, 63, 0.20, 0, 69, None, 1.14, 830, 3.3e-6, 0, None, 0.8)

    # =========================================================================
    # COMPOSITES
    # =========================================================================
    _add("CFRP UD (0 deg)", "composite", 1600, 135, 0.30, 0, 1500, 600, 5.0, 800, 0.2e-6, 1.8, None, None)
    _add("CFRP QI Laminate", "composite", 1600, 50, 0.30, 0, 550, 220, 5.0, 800, 2.0e-6, 1.5, None, None)
    _add("GFRP UD (0 deg)", "composite", 2000, 40, 0.28, 0, 900, 360, 1.0, 800, 7.0e-6, 2.5, None, None)
    _add("GFRP QI Laminate", "composite", 2000, 17, 0.28, 0, 300, 120, 1.0, 800, 12.0e-6, 2.0, None, None)
    _add("Kevlar UD (0 deg)", "composite", 1380, 76, 0.34, 0, 1300, 500, 0.04, 1400, -2.0e-6, 1.8, None, None)
    _add("E-Glass/Epoxy", "composite", 1900, 38, 0.28, 0, 800, 300, 0.35, 900, 11.0e-6, 2.5, None, None)
    _add("S-Glass/Epoxy", "composite", 1950, 50, 0.28, 0, 1200, 450, 0.35, 900, 9.0e-6, 2.5, None, None)

    # =========================================================================
    # MAGNESIUM ALLOYS
    # =========================================================================
    _add("Mg AZ31B", "magnesium", 1770, 45, 0.35, 200, 260, 97, 96, 1000, 26.0e-6, 15, 49, None, "ASTM B90")
    _add("Mg AZ61A", "magnesium", 1800, 45, 0.35, 230, 310, 110, 62, 1000, 26.0e-6, 12, 60, None, "ASTM B107")
    _add("Mg AZ80A-T5", "magnesium", 1800, 45, 0.35, 275, 380, 140, 77, 1000, 26.0e-6, 7, 72, None, "ASTM B91")
    _add("Mg ZK60A-T5", "magnesium", 1830, 45, 0.35, 285, 365, 130, 113, 1000, 26.0e-6, 11, 78, None, "ASTM B107")
    _add("Mg AM60B", "magnesium", 1790, 45, 0.35, 130, 225, 80, 62, 1000, 26.0e-6, 8, 65, None, "ASTM B94")
    _add("Mg WE43", "magnesium", 1840, 44, 0.35, 170, 250, 100, 51, 1000, 26.7e-6, 10, 75, None, "AMS 4427")

    # =========================================================================
    # STRUCTURAL STEELS (for construction & general use)
    # =========================================================================
    _add("A36", "structural_steel", 7850, 200, 0.29, 250, 400, 200, 51.9, 486, 11.7e-6, 20, 119, None, "ASTM A36")
    _add("A572 Grade 50", "structural_steel", 7850, 200, 0.29, 345, 450, 225, 51.9, 486, 11.7e-6, 18, 150, None, "ASTM A572")
    _add("A588 Grade A", "structural_steel", 7850, 200, 0.29, 345, 485, 242, 51.9, 486, 11.7e-6, 18, 143, None, "ASTM A588")
    _add("A514 Grade B", "structural_steel", 7850, 200, 0.29, 690, 760, 350, 45.0, 486, 11.7e-6, 18, 235, None, "ASTM A514")
    _add("S235JR", "structural_steel", 7850, 210, 0.30, 235, 360, 180, 51.9, 486, 12.0e-6, 26, 107, None, "EN 10025")
    _add("S275JR", "structural_steel", 7850, 210, 0.30, 275, 430, 215, 51.9, 486, 12.0e-6, 23, 121, None, "EN 10025")
    _add("S355JR", "structural_steel", 7850, 210, 0.30, 355, 510, 255, 51.9, 486, 12.0e-6, 22, 150, None, "EN 10025")
    _add("S355J2", "structural_steel", 7850, 210, 0.30, 355, 510, 255, 51.9, 486, 12.0e-6, 22, 150, None, "EN 10025")
    _add("S460N", "structural_steel", 7850, 210, 0.30, 460, 540, 270, 51.9, 486, 12.0e-6, 17, 180, None, "EN 10025")
    _add("SM490", "structural_steel", 7850, 200, 0.29, 325, 490, 245, 51.9, 486, 11.7e-6, 21, 140, None, "JIS G3106")

    # =========================================================================
    # SPRING STEELS
    # =========================================================================
    _add("ASTM A228 (Music Wire)", "spring_steel", 7850, 210, 0.29, 1600, 2060, 680, 39.0, 473, 11.6e-6, 2, 590, None, "ASTM A228")
    _add("ASTM A229 (Oil Tempered)", "spring_steel", 7850, 210, 0.29, 1100, 1400, 490, 39.0, 473, 11.6e-6, 4, 400, None, "ASTM A229")
    _add("ASTM A231 (Chrome Vanadium)", "spring_steel", 7850, 210, 0.29, 1280, 1550, 560, 39.0, 473, 11.6e-6, 3, 450, None, "ASTM A231")
    _add("ASTM A232 (Chrome Silicon)", "spring_steel", 7850, 210, 0.29, 1400, 1700, 600, 39.0, 473, 11.6e-6, 3, 495, None, "ASTM A232")
    _add("302 SS Spring Wire", "spring_steel", 7920, 193, 0.29, 1000, 1310, 450, 16.3, 500, 17.3e-6, 5, 380, None, "ASTM A313")
    _add("Phosphor Bronze Spring", "spring_steel", 8860, 110, 0.34, 500, 640, 210, 69.0, 376, 17.8e-6, 3, 200, None, "ASTM B159")
    _add("Inconel X-750 Spring", "spring_steel", 8280, 207, 0.29, 700, 1100, 380, 12.0, 431, 12.6e-6, 20, 310, None, "ASTM B637")

    # =========================================================================
    # ADDITIONAL COMMON MATERIALS (to reach 500+)
    # =========================================================================
    # Zinc alloys
    _add("Zamak 3", "zinc", 6600, 86, 0.33, 221, 283, 47, 113, 419, 27.4e-6, 10, 82, None, "ASTM B86")
    _add("Zamak 5", "zinc", 6600, 86, 0.33, 228, 331, 56, 109, 419, 27.4e-6, 7, 91, None, "ASTM B86")

    # Lead alloys
    _add("Lead Pb", "lead", 11340, 16, 0.44, 12, 17, 5, 35.3, 129, 29.3e-6, 40, 5, None)
    _add("Solder 60/40 (Sn/Pb)", "lead", 8500, 30, 0.40, 25, 40, None, 50.0, 170, 24.0e-6, 30, None, None)

    # Tungsten
    _add("Tungsten W", "refractory", 19300, 411, 0.28, 750, 980, None, 174, 134, 4.5e-6, 2, 350, None)
    _add("Molybdenum Mo", "refractory", 10220, 329, 0.31, 550, 690, None, 138, 251, 4.8e-6, 20, 180, None)
    _add("Niobium Nb", "refractory", 8570, 105, 0.40, 240, 330, None, 53.7, 265, 7.3e-6, 30, 60, None)
    _add("Tantalum Ta", "refractory", 16690, 186, 0.34, 170, 285, None, 57.5, 140, 6.3e-6, 40, 60, None)

    # Wood (for reference)
    _add("Oak", "wood", 660, 12, 0.30, 0, 50, None, 0.17, 2400, None, None, None, None)
    _add("Pine", "wood", 510, 9, 0.30, 0, 40, None, 0.12, 2800, None, None, None, None)
    _add("Balsa", "wood", 160, 3.4, 0.30, 0, 12, None, 0.05, 2900, None, None, None, None)
    _add("Plywood (Birch)", "wood", 680, 12.5, 0.30, 0, 48, None, 0.15, 1880, None, None, None, None)

    # Concrete
    _add("Concrete C20/25", "concrete", 2400, 30, 0.20, 0, 25, None, 1.8, 880, 10.0e-6, 0, None, None, "EN 206")
    _add("Concrete C25/30", "concrete", 2400, 31, 0.20, 0, 30, None, 1.8, 880, 10.0e-6, 0, None, None, "EN 206")
    _add("Concrete C30/37", "concrete", 2400, 33, 0.20, 0, 37, None, 1.8, 880, 10.0e-6, 0, None, None, "EN 206")
    _add("Concrete C35/45", "concrete", 2400, 34, 0.20, 0, 45, None, 1.8, 880, 10.0e-6, 0, None, None, "EN 206")
    _add("Concrete C40/50", "concrete", 2400, 35, 0.20, 0, 50, None, 1.8, 880, 10.0e-6, 0, None, None, "EN 206")

    # Additional Steels
    _add("AISI 1117", "steel", 7870, 200, 0.29, 305, 475, 238, 51.9, 481, 11.7e-6, 22, 143, None, "ASTM A29")
    _add("AISI 1215", "steel", 7870, 200, 0.29, 230, 390, 195, 51.9, 481, 11.7e-6, 10, 121, None, "ASTM A29")
    _add("AISI 12L14", "steel", 7870, 200, 0.29, 230, 390, 195, 51.9, 481, 11.7e-6, 10, 121, None, "ASTM A29")
    _add("EN8 (080M40)", "steel", 7850, 210, 0.30, 280, 510, 250, 50.7, 481, 11.7e-6, 18, 152, None, "BS 970")
    _add("EN19 (709M40)", "steel", 7850, 210, 0.30, 680, 850, 400, 42.6, 473, 11.2e-6, 15, 269, 60, "BS 970")
    _add("EN24 (817M40)", "steel", 7850, 210, 0.30, 680, 930, 420, 34.8, 473, 11.2e-6, 14, 280, 50, "BS 970")
    _add("EN36 (655M13)", "steel", 7850, 210, 0.30, 500, 750, 350, 37.0, 477, 11.2e-6, 18, 217, None, "BS 970")

    # Pressure vessel steels
    _add("SA-516 Grade 70", "steel", 7850, 200, 0.29, 260, 485, 242, 51.9, 486, 11.7e-6, 21, 137, None, "ASME SA-516")
    _add("SA-516 Grade 60", "steel", 7850, 200, 0.29, 220, 415, 207, 51.9, 486, 11.7e-6, 23, 121, None, "ASME SA-516")
    _add("SA-240 Type 304", "stainless_steel", 8000, 193, 0.29, 205, 515, 240, 16.3, 500, 17.3e-6, 40, 183, None, "ASME SA-240")
    _add("SA-240 Type 316", "stainless_steel", 8000, 193, 0.29, 205, 515, 240, 16.3, 500, 15.9e-6, 40, 183, None, "ASME SA-240")
    _add("SA-213 T91", "steel", 7770, 218, 0.29, 415, 585, 270, 26.0, 460, 10.8e-6, 20, 196, None, "ASME SA-213")
    _add("SA-335 P11", "steel", 7850, 208, 0.29, 205, 415, 207, 37.0, 473, 12.3e-6, 30, 121, None, "ASME SA-335")
    _add("SA-335 P22", "steel", 7850, 210, 0.29, 205, 415, 207, 35.0, 473, 12.8e-6, 30, 121, None, "ASME SA-335")

    # Bearing steels
    _add("100Cr6", "steel", 7830, 210, 0.29, 1580, 2000, 700, 46.6, 475, 11.0e-6, 5, 600, 18, "ISO 683-17")
    _add("M50", "steel", 8030, 210, 0.29, 1720, 2050, 720, 23.0, 460, 11.0e-6, 3, 620, 20, "AMS 6491")
    _add("440C", "stainless_steel", 7650, 200, 0.29, 450, 760, 380, 24.2, 460, 10.2e-6, 2, 260, 15, "ASTM A276")

    # High strength low alloy
    _add("HSLA 350", "steel", 7850, 200, 0.29, 350, 450, 225, 51.9, 486, 11.7e-6, 22, 130, None, "ASTM A1011")
    _add("HSLA 550", "steel", 7850, 200, 0.29, 550, 650, 325, 49.0, 486, 11.7e-6, 14, 200, None, "ASTM A1011")

    # Rubber & Elastomers
    _add("Natural Rubber (NR)", "elastomer", 920, 0.005, 0.50, 0, 25, None, 0.13, 1880, 200e-6, 700, None, None)
    _add("Neoprene (CR)", "elastomer", 1240, 0.007, 0.50, 0, 20, None, 0.19, 2000, 180e-6, 500, None, None)
    _add("Silicone Rubber", "elastomer", 1100, 0.005, 0.50, 0, 10, None, 0.20, 1300, 250e-6, 700, None, None)
    _add("EPDM", "elastomer", 860, 0.005, 0.50, 0, 15, None, 0.25, 2000, 160e-6, 500, None, None)
    _add("Nitrile Rubber (NBR)", "elastomer", 1000, 0.005, 0.50, 0, 18, None, 0.25, 2010, 170e-6, 400, None, None)
    _add("Viton (FKM)", "elastomer", 1800, 0.008, 0.50, 0, 14, None, 0.20, 1050, 180e-6, 250, None, None)
    _add("Polyurethane (PU) 90A", "elastomer", 1200, 0.020, 0.48, 0, 35, None, 0.19, 1800, 150e-6, 500, None, None)

    # Additional Aluminum Cast & Wrought
    _add("Al 319-T6", "aluminum", 2790, 74, 0.33, 165, 250, 75, 109, 963, 21.5e-6, 2, 80, None, "ASTM B26")
    _add("Al 413", "aluminum", 2660, 71, 0.33, 145, 296, 90, 121, 963, 20.4e-6, 3, 80, None, "ASTM B85")
    _add("Al 2219-T87", "aluminum", 2840, 73, 0.33, 393, 455, 138, 121, 864, 22.3e-6, 10, 130, 36, "ASTM B209")
    _add("Al 6082-T6", "aluminum", 2710, 70, 0.33, 260, 310, 97, 170, 896, 23.4e-6, 10, 95, None, "EN 755")
    _add("Al 5086-H32", "aluminum", 2660, 71, 0.33, 207, 290, 117, 127, 900, 23.8e-6, 14, 80, None, "ASTM B209")
    _add("Al 2124-T851", "aluminum", 2780, 73, 0.33, 440, 483, 148, 121, 875, 22.7e-6, 8, 135, 27, "ASTM B209")

    # Cobalt alloys
    _add("Stellite 6", "cobalt", 8390, 210, 0.29, 620, 900, 300, 14.6, 421, 12.0e-6, 1, 380, None, "AWS A5.21")
    _add("Stellite 21", "cobalt", 8330, 220, 0.29, 530, 750, 260, 12.0, 420, 12.5e-6, 8, 310, None, "AWS A5.21")
    _add("MP35N", "cobalt", 8430, 233, 0.30, 1400, 1600, 500, 11.0, 402, 12.8e-6, 10, 475, None, "ASTM F562")
    _add("L-605 (HS-25)", "cobalt", 9130, 225, 0.29, 460, 1000, 350, 10.0, 403, 12.3e-6, 50, 280, None, "ASTM B338")

    # More stainless
    _add("SS 201", "stainless_steel", 7800, 200, 0.29, 310, 655, 270, 16.2, 500, 15.7e-6, 40, 210, None, "ASTM A240")
    _add("SS 254 SMO", "stainless_steel", 8000, 196, 0.29, 310, 650, 270, 13.0, 500, 16.0e-6, 40, 200, None, "ASTM A240")
    _add("SS 904L", "stainless_steel", 7900, 196, 0.29, 220, 490, 230, 12.2, 500, 15.0e-6, 35, 160, None, "ASTM B625")
    _add("SS 430F", "stainless_steel", 7740, 200, 0.29, 240, 480, 240, 26.1, 460, 10.4e-6, 20, 170, None, "ASTM A473")
    _add("SS 431", "stainless_steel", 7740, 200, 0.29, 655, 860, 380, 20.2, 460, 10.2e-6, 15, 280, None, "ASTM A276")
    _add("SS 440A", "stainless_steel", 7740, 200, 0.29, 415, 725, 340, 24.2, 460, 10.2e-6, 5, 230, None, "ASTM A276")

    # Additional nickel alloys
    _add("Incoloy 800", "nickel_alloy", 7940, 196, 0.29, 205, 520, 200, 11.5, 460, 14.4e-6, 40, 130, None, "ASTM B409")
    _add("Incoloy 825", "nickel_alloy", 8140, 196, 0.29, 241, 586, 210, 11.1, 440, 14.0e-6, 30, 150, None, "ASTM B424")
    _add("Invar 36", "nickel_alloy", 8050, 141, 0.29, 240, 480, 180, 10.5, 515, 1.3e-6, 35, 130, None, "ASTM F1684")
    _add("Kovar", "nickel_alloy", 8360, 138, 0.29, 345, 517, 200, 17.3, 460, 5.1e-6, 30, 150, None, "ASTM F15")
    _add("Nichrome (80/20)", "nickel_alloy", 8400, 186, 0.29, 276, 690, 250, 12.0, 460, 13.0e-6, 40, 160, None)
    _add("Haynes 230", "nickel_alloy", 8970, 211, 0.29, 310, 760, 280, 8.9, 397, 12.7e-6, 46, 200, None, "AMS 5891")
    _add("Haynes 188", "nickel_alloy", 8980, 232, 0.29, 410, 880, 310, 10.4, 406, 13.1e-6, 53, 230, None, "AMS 5772")

    # Precious metals
    _add("Gold Au", "precious", 19300, 79, 0.42, 205, 220, None, 318, 129, 14.2e-6, 45, 25, None)
    _add("Silver Ag", "precious", 10490, 83, 0.37, 170, 290, None, 429, 235, 19.5e-6, 48, 25, None)
    _add("Platinum Pt", "precious", 21450, 168, 0.38, 135, 240, None, 71.6, 133, 8.8e-6, 35, 50, None)

    return db


class MaterialDatabase:
    """Comprehensive engineering materials database.

    Contains 500+ materials with full mechanical, thermal, and physical
    property sets. Supports lookup by name, filtering by category, and
    searching by property ranges.

    Examples
    --------
    >>> db = MaterialDatabase()
    >>> steel = db.get('AISI 4140')
    >>> print(steel.yield_strength)
    655.0 MPa
    >>> steels = db.filter_by_category('steel')
    >>> len(steels) > 50
    True
    """

    def __init__(self) -> None:
        self._db = _build_material_database()

    def get(self, name: str) -> Material:
        """Look up a material by name.

        Parameters
        ----------
        name : str
            Material name or designation (case-insensitive).

        Returns
        -------
        Material
            The requested material with full properties.

        Raises
        ------
        MaterialNotFoundError
            If the material is not found in the database.

        Examples
        --------
        >>> db = MaterialDatabase()
        >>> mat = db.get('AISI 4340')
        >>> print(mat.ultimate_strength)
        1000.0 MPa
        """
        key = name.upper().strip()
        if key in self._db:
            return self._db[key]
        # Try fuzzy match
        for db_key in self._db:
            if key in db_key or db_key in key:
                return self._db[db_key]
        raise MaterialNotFoundError(
            f"Material '{name}' not found. Use list_materials() to see available materials."
        )

    def list_materials(self, category: str | None = None) -> list[str]:
        """List all available material names, optionally filtered by category.

        Parameters
        ----------
        category : str, optional
            Filter by category (e.g., 'steel', 'aluminum', 'polymer').

        Returns
        -------
        list of str
            Sorted list of unique material names.
        """
        seen = set()
        names = []
        for mat in self._db.values():
            if mat.name not in seen:
                if category is None or mat.category == category:
                    seen.add(mat.name)
                    names.append(mat.name)
        return sorted(names)

    def filter_by_category(self, category: str) -> list[Material]:
        """Get all materials in a category.

        Parameters
        ----------
        category : str
            Material category (e.g., 'steel', 'aluminum', 'titanium',
            'polymer', 'ceramic', 'composite').

        Returns
        -------
        list of Material
            Materials matching the category.
        """
        seen = set()
        results = []
        for mat in self._db.values():
            if mat.category == category and mat.name not in seen:
                seen.add(mat.name)
                results.append(mat)
        return results

    def search(
        self,
        min_yield: float | None = None,
        max_density: float | None = None,
        min_E: float | None = None,
        category: str | None = None,
    ) -> list[Material]:
        """Search materials by property ranges.

        Parameters
        ----------
        min_yield : float, optional
            Minimum yield strength in MPa.
        max_density : float, optional
            Maximum density in kg/m³.
        min_E : float, optional
            Minimum elastic modulus in GPa.
        category : str, optional
            Filter by material category.

        Returns
        -------
        list of Material
            Materials matching all specified criteria.
        """
        seen = set()
        results = []
        for mat in self._db.values():
            if mat.name in seen:
                continue
            if category and mat.category != category:
                continue
            if min_yield and mat.yield_strength.to("MPa").magnitude < min_yield:
                continue
            if max_density and mat.density.to("kg/m**3").magnitude > max_density:
                continue
            if min_E and mat.elastic_modulus.to("GPa").magnitude < min_E:
                continue
            seen.add(mat.name)
            results.append(mat)
        return results

    @property
    def count(self) -> int:
        """Return the number of unique materials in the database."""
        return len(set(mat.name for mat in self._db.values()))

    def steels(self) -> list[Material]:
        """Get all steel materials."""
        return self.filter_by_category("steel") + self.filter_by_category("structural_steel")

    def aluminums(self) -> list[Material]:
        """Get all aluminum alloy materials."""
        return self.filter_by_category("aluminum")

    def titaniums(self) -> list[Material]:
        """Get all titanium alloy materials."""
        return self.filter_by_category("titanium")

    def polymers(self) -> list[Material]:
        """Get all polymer materials."""
        return self.filter_by_category("polymer")


# Module-level singleton
_default_db = None


def _get_db() -> MaterialDatabase:
    """Get the default material database singleton."""
    global _default_db
    if _default_db is None:
        _default_db = MaterialDatabase()
    return _default_db


def get_material(name: str) -> Material:
    """Look up a material by name from the default database.

    Parameters
    ----------
    name : str
        Material name or designation (case-insensitive).

    Returns
    -------
    Material
        The requested material with full properties.

    Examples
    --------
    >>> steel = get_material('AISI 4140')
    >>> print(steel.yield_strength)
    655.0 MPa
    """
    return _get_db().get(name)


def list_materials(category: str | None = None) -> list[str]:
    """List available material names.

    Parameters
    ----------
    category : str, optional
        Filter by category.

    Returns
    -------
    list of str
        Sorted list of unique material names.
    """
    return _get_db().list_materials(category)
