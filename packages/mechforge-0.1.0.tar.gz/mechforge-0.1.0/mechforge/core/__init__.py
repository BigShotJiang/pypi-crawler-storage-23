"""
MechForge Core Module.

Provides the foundational infrastructure for the entire MechForge platform:
units, constants, materials database, exceptions, and validation utilities.
"""

from __future__ import annotations

from mechforge.core.units import ureg, Q, Q_
from mechforge.core.exceptions import (
    MechForgeError,
    UnitError,
    MaterialNotFoundError,
    ConvergenceError,
    InsufficientDataError,
    ValidationError,
)
from mechforge.core.constants import PhysicalConstants
from mechforge.core.materials import Material, MaterialDatabase, get_material
from mechforge.core.validators import validate_positive, validate_quantity, validate_dimensionality

__all__ = [
    "ureg",
    "Q",
    "Q_",
    "PhysicalConstants",
    "Material",
    "MaterialDatabase",
    "get_material",
    "MechForgeError",
    "UnitError",
    "MaterialNotFoundError",
    "ConvergenceError",
    "InsufficientDataError",
    "ValidationError",
    "validate_positive",
    "validate_quantity",
    "validate_dimensionality",
]
