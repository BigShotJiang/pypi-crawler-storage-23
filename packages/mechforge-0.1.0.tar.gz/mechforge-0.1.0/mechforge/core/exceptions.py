"""
MechForge Exceptions.

All custom exception classes used throughout MechForge. Organized in a
hierarchy for easy catching at different levels of specificity.
"""

from __future__ import annotations


class MechForgeError(Exception):
    """Base exception for all MechForge errors."""

    pass


class UnitError(MechForgeError):
    """Raised when a unit mismatch or invalid unit is encountered."""

    pass


class MaterialNotFoundError(MechForgeError):
    """Raised when a requested material is not found in the database."""

    pass


class ConvergenceError(MechForgeError):
    """Raised when an iterative solver fails to converge."""

    pass


class InsufficientDataError(MechForgeError):
    """Raised when insufficient data is provided for an analysis."""

    pass


class ValidationError(MechForgeError):
    """Raised when input validation fails."""

    pass


class GeometryError(MechForgeError):
    """Raised for invalid geometry specifications."""

    pass


class StandardsError(MechForgeError):
    """Raised when a standards compliance check fails."""

    pass


class SolverError(MechForgeError):
    """Raised when a numerical solver encounters an error."""

    pass


class ConfigurationError(MechForgeError):
    """Raised when configuration is invalid or missing."""

    pass


class ConnectionError(MechForgeError):
    """Raised when an IoT/network connection fails."""

    pass
