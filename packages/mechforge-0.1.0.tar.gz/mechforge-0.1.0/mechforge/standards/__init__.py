"""
MechForge Standards Module (Stub).

Standards compliance verification and lookup tables for ASME, AGMA,
ISO, DIN, Eurocode, AISC, and other engineering standards.
"""

from __future__ import annotations


# Standard material allowable stresses per code
ASME_ALLOWABLE = {
    "ASME_B31.1": {
        "SA-106 Gr. B": {"S_allow_MPa": 120, "temp_max_C": 425},
        "SA-312 TP304": {"S_allow_MPa": 115, "temp_max_C": 540},
        "SA-312 TP316": {"S_allow_MPa": 115, "temp_max_C": 540},
    },
    "ASME_BPVC_VIII_Div1": {
        "SA-516 Gr. 70": {"S_allow_MPa": 138, "temp_max_C": 343},
        "SA-240 304": {"S_allow_MPa": 115, "temp_max_C": 540},
        "SA-240 316": {"S_allow_MPa": 115, "temp_max_C": 540},
    },
}

AGMA_GEAR_GRADES = {
    "Grade_1": {"St_min": 170, "Sc_min": 585},
    "Grade_2": {"St_min": 225, "Sc_min": 720},
    "Grade_3": {"St_min": 275, "Sc_min": 860},
}

ISO_TOLERANCE_GRADES = {
    "IT01": 0.3, "IT0": 0.5, "IT1": 0.8, "IT2": 1.2, "IT3": 2,
    "IT4": 3, "IT5": 4, "IT6": 6, "IT7": 10, "IT8": 14,
    "IT9": 25, "IT10": 40, "IT11": 60, "IT12": 100, "IT13": 140,
    "IT14": 250, "IT15": 400, "IT16": 600,
}

SURFACE_ROUGHNESS_RA = {
    "grinding_fine": 0.2,
    "grinding_normal": 0.8,
    "turning_fine": 1.6,
    "turning_normal": 3.2,
    "milling_fine": 1.6,
    "milling_normal": 6.3,
    "drilling": 6.3,
    "reaming": 1.6,
    "broaching": 1.6,
    "honing": 0.4,
    "lapping": 0.1,
    "polishing": 0.05,
    "casting_investment": 3.2,
    "casting_sand": 12.5,
    "forging": 6.3,
}


def get_iso_tolerance(grade: str, nominal_size_mm: float) -> float:
    """Get ISO tolerance value for given grade and nominal size.

    Parameters
    ----------
    grade : str
        ISO tolerance grade (e.g., 'IT7').
    nominal_size_mm : float
        Nominal dimension [mm].

    Returns
    -------
    float
        Tolerance value [μm].
    """
    base = ISO_TOLERANCE_GRADES.get(grade, 10)
    # Simplified: tolerance increases with size
    factor = (nominal_size_mm / 25.4) ** (1 / 3) if nominal_size_mm > 0 else 1
    return base * factor


__all__ = [
    "ASME_ALLOWABLE",
    "AGMA_GEAR_GRADES",
    "ISO_TOLERANCE_GRADES",
    "SURFACE_ROUGHNESS_RA",
    "get_iso_tolerance",
]
