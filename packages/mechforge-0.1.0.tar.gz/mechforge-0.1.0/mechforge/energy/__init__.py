"""
MechForge Energy Module (Stub).

Renewable energy systems, energy storage, and power generation analysis.
Solar, wind, hydroelectric, and battery storage calculations.
Full implementation planned for v0.3.0.
"""

from __future__ import annotations

import numpy as np


def wind_power(
    wind_speed: float,
    rotor_diameter: float,
    air_density: float = 1.225,
    Cp: float = 0.45,
    efficiency: float = 0.90,
) -> float:
    """Calculate wind turbine power output.

    .. math:: P = \\frac{1}{2} \\rho A V^3 C_p \\eta

    Parameters
    ----------
    wind_speed : float
        Wind speed [m/s].
    rotor_diameter : float
        Rotor diameter [m].
    air_density : float
        Air density [kg/m³].
    Cp : float
        Power coefficient (Betz limit = 0.593).
    efficiency : float
        Drivetrain efficiency.

    Returns
    -------
    float
        Power output [W].
    """
    A = np.pi / 4 * rotor_diameter**2
    return 0.5 * air_density * A * wind_speed**3 * Cp * efficiency


def solar_panel_output(
    irradiance: float = 1000,
    area: float = 1.6,
    efficiency: float = 0.20,
    temperature_coeff: float = -0.004,
    cell_temp: float = 25,
    noct: float = 45,
) -> float:
    """Calculate solar panel power output.

    Parameters
    ----------
    irradiance : float
        Solar irradiance [W/m²].
    area : float
        Panel area [m²].
    efficiency : float
        Panel efficiency at STC.
    temperature_coeff : float
        Power temperature coefficient [1/°C].
    cell_temp : float
        Cell temperature [°C].
    noct : float
        Nominal operating cell temperature [°C].

    Returns
    -------
    float
        Power output [W].
    """
    temp_loss = 1 + temperature_coeff * (cell_temp - 25)
    return irradiance * area * efficiency * temp_loss


__all__ = [
    "wind_power",
    "solar_panel_output",
]
