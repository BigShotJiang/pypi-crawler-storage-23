"""
MechForge Simulation Module (Stub).

Finite Element Method (FEM) basics, mesh generation utilities,
and simple structural/thermal FEA solvers.
Full implementation planned for v0.3.0.

Requires: pip install mechforge[simulation]
"""

from __future__ import annotations

import numpy as np


class TrussElement:
    """Simple 2D truss element for basic FEA.

    Parameters
    ----------
    E : float
        Elastic modulus [Pa].
    A : float
        Cross-section area [m²].
    L : float
        Element length [m].
    theta : float
        Angle from horizontal [degrees].
    """

    def __init__(self, E: float, A: float, L: float, theta: float) -> None:
        self.E = E
        self.A = A
        self.L = L
        self.theta = np.radians(theta)

    def stiffness_matrix(self) -> np.ndarray:
        """Local-to-global stiffness matrix [4x4]."""
        c = np.cos(self.theta)
        s = np.sin(self.theta)
        k = self.E * self.A / self.L

        return k * np.array([
            [c**2, c * s, -c**2, -c * s],
            [c * s, s**2, -c * s, -s**2],
            [-c**2, -c * s, c**2, c * s],
            [-c * s, -s**2, c * s, s**2],
        ])


def solve_truss(
    elements: list[TrussElement],
    connectivity: list[tuple[int, int]],
    n_nodes: int,
    forces: dict[int, tuple[float, float]],
    constraints: dict[int, tuple[bool, bool]],
) -> dict:
    """Solve simple 2D truss problem using direct stiffness method.

    Parameters
    ----------
    elements : list[TrussElement]
        List of truss elements.
    connectivity : list of (node_i, node_j)
        Element connectivity.
    n_nodes : int
        Total number of nodes.
    forces : dict
        Applied forces: {node_id: (Fx, Fy)}.
    constraints : dict
        Boundary conditions: {node_id: (fix_x, fix_y)}.

    Returns
    -------
    dict
        {'displacements': ndarray, 'reactions': ndarray}
    """
    n_dof = 2 * n_nodes
    K_global = np.zeros((n_dof, n_dof))

    # Assemble global stiffness matrix
    for elem, (ni, nj) in zip(elements, connectivity):
        ke = elem.stiffness_matrix()
        dofs = [2 * ni, 2 * ni + 1, 2 * nj, 2 * nj + 1]
        for i, di in enumerate(dofs):
            for j, dj in enumerate(dofs):
                K_global[di, dj] += ke[i, j]

    # Force vector
    F = np.zeros(n_dof)
    for node, (fx, fy) in forces.items():
        F[2 * node] = fx
        F[2 * node + 1] = fy

    # Apply boundary conditions
    free_dofs = list(range(n_dof))
    for node, (fix_x, fix_y) in constraints.items():
        if fix_x and 2 * node in free_dofs:
            free_dofs.remove(2 * node)
        if fix_y and 2 * node + 1 in free_dofs:
            free_dofs.remove(2 * node + 1)

    # Solve reduced system
    K_red = K_global[np.ix_(free_dofs, free_dofs)]
    F_red = F[free_dofs]
    u_red = np.linalg.solve(K_red, F_red)

    # Full displacement vector
    u = np.zeros(n_dof)
    for i, dof in enumerate(free_dofs):
        u[dof] = u_red[i]

    # Reactions
    reactions = K_global @ u - F

    return {"displacements": u, "reactions": reactions}


__all__ = ["TrussElement", "solve_truss"]
