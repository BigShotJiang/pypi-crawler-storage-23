"""
Bearing Selection — Rolling Element Bearings, L10 Life Calculation.

Bearing selection and life prediction per ISO 281 / ABMA standards
including dynamic/static load ratings, speed limits, and reliability factors.

References
----------
.. [1] ISO 281:2007 — Rolling Bearings, Dynamic Load Ratings & Rating Life
.. [2] Shigley's MED, 11th Ed., Chapter 11
.. [3] SKF Rolling Bearings Catalogue
.. [4] Harris & Kotzalas, Rolling Bearing Analysis, 5th Ed.

Examples
--------
>>> from mechforge.machine.bearings import BearingSelection
>>> from mechforge.core.units import Q
>>> bearing = BearingSelection(
...     type='deep_groove', bore=Q(40, 'mm'),
...     radial_load=Q(5, 'kN'), axial_load=Q(1, 'kN'),
...     speed=Q(3000, 'rpm'), desired_life_hours=20000,
... )
>>> result = bearing.analyze()
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional

import numpy as np
import pint

from mechforge.core.units import Q, ureg
from mechforge.core.validators import validate_positive
from mechforge.core.exceptions import ValidationError


# Standard bearing catalog (bore: (C_dynamic_kN, C_static_kN, e, Y))
_BEARING_CATALOG = {
    "deep_groove": {
        10: (5.07, 2.24, 0.22, 2.0),
        15: (5.85, 2.85, 0.24, 1.8),
        17: (7.80, 3.45, 0.26, 1.7),
        20: (9.36, 4.75, 0.27, 1.6),
        25: (14.0, 6.55, 0.28, 1.5),
        30: (19.5, 10.0, 0.30, 1.45),
        35: (25.5, 13.7, 0.31, 1.4),
        40: (30.7, 16.6, 0.31, 1.4),
        45: (33.2, 18.6, 0.31, 1.4),
        50: (35.1, 19.6, 0.31, 1.4),
        55: (43.6, 25.0, 0.32, 1.35),
        60: (47.5, 28.0, 0.32, 1.35),
        65: (55.3, 34.0, 0.33, 1.3),
        70: (61.8, 37.5, 0.33, 1.3),
        75: (66.3, 41.0, 0.33, 1.3),
        80: (70.2, 45.0, 0.34, 1.25),
        85: (83.2, 52.0, 0.34, 1.25),
        90: (95.6, 62.0, 0.34, 1.25),
        100: (108, 73.5, 0.35, 1.2),
        110: (120, 81.5, 0.35, 1.2),
        120: (140, 96.5, 0.36, 1.15),
    },
    "angular_contact": {
        20: (12.7, 6.2, 0.68, 0.95),
        25: (17.8, 9.3, 0.68, 0.95),
        30: (26.0, 14.6, 0.68, 0.95),
        35: (33.5, 19.6, 0.68, 0.95),
        40: (40.2, 24.5, 0.68, 0.95),
        45: (44.0, 27.5, 0.68, 0.95),
        50: (49.4, 31.5, 0.68, 0.95),
        55: (56.1, 37.0, 0.68, 0.95),
        60: (63.7, 43.0, 0.68, 0.95),
        70: (80.9, 57.0, 0.68, 0.95),
        80: (100, 72.0, 0.68, 0.95),
        90: (114, 86.5, 0.68, 0.95),
        100: (133, 104, 0.68, 0.95),
    },
    "cylindrical_roller": {
        25: (26.0, 17.2, None, None),
        30: (36.0, 25.0, None, None),
        35: (47.0, 34.5, None, None),
        40: (56.1, 41.0, None, None),
        45: (62.0, 48.0, None, None),
        50: (72.0, 57.0, None, None),
        55: (80.0, 63.0, None, None),
        60: (92.3, 73.5, None, None),
        70: (116, 95.0, None, None),
        80: (140, 118, None, None),
        90: (160, 140, None, None),
        100: (190, 170, None, None),
    },
}


@dataclass
class BearingResult:
    """Results from bearing analysis.

    Attributes
    ----------
    L10 : float
        Basic rating life in millions of revolutions.
    L10_hours : float
        Basic rating life in hours.
    C_required : pint.Quantity
        Required dynamic load rating [kN].
    C_available : pint.Quantity
        Available dynamic load rating [kN].
    equivalent_load : pint.Quantity
        Equivalent dynamic bearing load [kN].
    static_safety_factor : float
        Static safety factor (C0/P0).
    bearing_bore : pint.Quantity
        Selected bearing bore diameter.
    adequate : bool
        Whether the selected bearing meets life requirements.
    """

    L10: float
    L10_hours: float
    C_required: pint.Quantity
    C_available: pint.Quantity
    equivalent_load: pint.Quantity
    static_safety_factor: float
    bearing_bore: pint.Quantity
    adequate: bool

    def summary(self) -> str:
        """Return formatted summary."""
        status = "✅ ADEQUATE" if self.adequate else "❌ INADEQUATE"
        return (
            f"=== Bearing Analysis Results (ISO 281) ===\n"
            f"  Bearing Bore:         {self.bearing_bore.to('mm'):.0f}\n"
            f"  Equivalent Load:      {self.equivalent_load.to('kN'):.2f}\n"
            f"  C (available):        {self.C_available.to('kN'):.1f}\n"
            f"  C (required):         {self.C_required.to('kN'):.1f}\n"
            f"  L10 Life:             {self.L10:.1f} million rev\n"
            f"  L10 Life (hours):     {self.L10_hours:.0f} hr\n"
            f"  Static SF:            {self.static_safety_factor:.2f}\n"
            f"  Status:               {status}\n"
        )


class BearingSelection:
    """Rolling element bearing selection and life calculation.

    Parameters
    ----------
    type : str
        Bearing type: 'deep_groove', 'angular_contact', 'cylindrical_roller'.
    bore : pint.Quantity
        Bearing bore (shaft) diameter [mm].
    radial_load : pint.Quantity
        Applied radial load [force].
    axial_load : pint.Quantity, optional
        Applied axial (thrust) load [force].
    speed : pint.Quantity
        Rotational speed [RPM].
    desired_life_hours : float
        Desired bearing life in operating hours.
    reliability : float
        Required reliability (0-1). Default 0.90 (L10 life).

    Notes
    -----
    Basic rating life (ISO 281):

    .. math:: L_{10} = \\left(\\frac{C}{P}\\right)^p

    Where:
    - C = dynamic load rating
    - P = equivalent dynamic bearing load
    - p = life exponent (3 for ball, 10/3 for roller)

    References
    ----------
    .. [1] ISO 281:2007, Eq. (1)
    .. [2] Shigley's MED, 11th Ed., Eqs. (11-1) to (11-6)
    """

    def __init__(
        self,
        type: Literal["deep_groove", "angular_contact", "cylindrical_roller"] = "deep_groove",
        bore: pint.Quantity = Q(30, "mm"),
        radial_load: pint.Quantity = Q(5, "kN"),
        axial_load: Optional[pint.Quantity] = None,
        speed: pint.Quantity = Q(1500, "rpm"),
        desired_life_hours: float = 20000,
        reliability: float = 0.90,
    ) -> None:
        self.type = type
        self.bore = int(round(bore.to("mm").magnitude))
        self.Fr = radial_load.to("kN").magnitude
        self.Fa = axial_load.to("kN").magnitude if axial_load is not None else 0
        self.n = speed.to("rpm").magnitude
        self.Lh_desired = desired_life_hours
        self.reliability = reliability

        # Life exponent
        self.p = 3 if type in ["deep_groove", "angular_contact"] else 10 / 3

        # Reliability factor
        self.a1 = self._reliability_factor()

    def _reliability_factor(self) -> float:
        """ISO 281 reliability factor a1."""
        factors = {
            0.90: 1.00,
            0.95: 0.62,
            0.96: 0.53,
            0.97: 0.44,
            0.98: 0.33,
            0.99: 0.21,
        }
        closest = min(factors.keys(), key=lambda x: abs(x - self.reliability))
        return factors[closest]

    def _get_catalog_bearing(self) -> tuple[float, float, float | None, float | None]:
        """Look up bearing from catalog."""
        catalog = _BEARING_CATALOG.get(self.type, {})
        if self.bore in catalog:
            return catalog[self.bore]

        # Find closest available bore size
        available = sorted(catalog.keys())
        closest = min(available, key=lambda x: abs(x - self.bore))
        self.bore = closest
        return catalog[closest]

    def analyze(self) -> BearingResult:
        """Perform bearing selection and life calculation.

        Returns
        -------
        BearingResult
            Complete bearing analysis results.
        """
        C_dyn, C_stat, e, Y = self._get_catalog_bearing()

        # Equivalent dynamic bearing load P
        if self.type == "cylindrical_roller":
            P = self.Fr  # Pure radial for cylindrical roller
        else:
            # For ball bearings: P = X*Fr + Y*Fa
            if e is None:
                e = 0.3
            if Y is None:
                Y = 1.5

            if self.Fa / self.Fr <= e if self.Fr > 0 else True:
                X = 1.0
                Y_use = 0
            else:
                X = 0.56
                Y_use = Y
            P = X * self.Fr + Y_use * self.Fa
            P = max(P, self.Fr)

        # Basic rating life (millions of revolutions)
        L10 = (C_dyn / P) ** self.p if P > 0 else float("inf")

        # Life in hours
        L10_hours = L10 * 1e6 / (60 * self.n) if self.n > 0 else float("inf")

        # Adjusted life with reliability
        L10a_hours = self.a1 * L10_hours

        # Required C for desired life
        L_req = self.Lh_desired * 60 * self.n / 1e6  # Required L10 in Mrev
        C_required = P * L_req ** (1 / self.p) if L_req > 0 else 0

        # Static safety factor
        s0 = C_stat / P if P > 0 else float("inf")

        adequate = L10a_hours >= self.Lh_desired

        return BearingResult(
            L10=L10,
            L10_hours=L10a_hours,
            C_required=Q(C_required, "kN"),
            C_available=Q(C_dyn, "kN"),
            equivalent_load=Q(P, "kN"),
            static_safety_factor=s0,
            bearing_bore=Q(self.bore, "mm"),
            adequate=adequate,
        )
