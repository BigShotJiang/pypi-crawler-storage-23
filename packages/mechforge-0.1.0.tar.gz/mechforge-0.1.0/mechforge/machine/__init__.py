"""
MechForge Machine Design Module.

Covers mechanical power transmission and component design: shafts, gears,
bearings, bolted joints, and springs.
"""

from __future__ import annotations

from mechforge.machine.shaft import Shaft, ShaftResult
from mechforge.machine.gears import SpurGear, GearResult
from mechforge.machine.bearings import BearingSelection, BearingResult
from mechforge.machine.bolts import BoltedJoint, BoltResult
from mechforge.machine.springs import HelicalSpring, SpringResult

__all__ = [
    "Shaft",
    "ShaftResult",
    "SpurGear",
    "GearResult",
    "BearingSelection",
    "BearingResult",
    "BoltedJoint",
    "BoltResult",
    "HelicalSpring",
    "SpringResult",
]
