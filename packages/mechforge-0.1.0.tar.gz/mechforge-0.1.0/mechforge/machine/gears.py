"""
Gear Design — Spur, Helical Gears, AGMA Rating.

Spur and helical gear design per AGMA 2101-D04 including bending stress,
contact (pitting) stress, and gear train synthesis.

References
----------
.. [1] AGMA 2101-D04 — Fundamental Rating Factors for Involute Gear Teeth
.. [2] Shigley's MED, 11th Ed., Chapter 13
.. [3] ISO 6336 — Calculation of Load Capacity of Spur and Helical Gears
.. [4] DIN 3990 — Calculation of Load Capacity of Cylindrical Gears

Examples
--------
>>> from mechforge.machine.gears import SpurGear
>>> from mechforge.core.units import Q
>>> gear = SpurGear(
...     module=Q(3, 'mm'), teeth=24, face_width=Q(30, 'mm'),
...     power=Q(10, 'kW'), speed=Q(1500, 'rpm'),
...     material_hardness=300,
... )
>>> result = gear.analyze()
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pint

from mechforge.core.units import Q, ureg
from mechforge.core.validators import validate_positive, validate_quantity


@dataclass
class GearResult:
    """Results from gear analysis.

    Attributes
    ----------
    bending_stress : pint.Quantity
        Lewis bending stress [MPa].
    contact_stress : pint.Quantity
        Hertzian contact (pitting) stress [MPa].
    pitch_diameter : pint.Quantity
        Pitch circle diameter [mm].
    pitch_line_velocity : pint.Quantity
        Pitch line velocity [m/s].
    tangential_force : pint.Quantity
        Tangential driving force [N].
    bending_safety_factor : float
        Safety factor against bending failure.
    contact_safety_factor : float
        Safety factor against pitting failure.
    """

    bending_stress: pint.Quantity
    contact_stress: pint.Quantity
    pitch_diameter: pint.Quantity
    pitch_line_velocity: pint.Quantity
    tangential_force: pint.Quantity
    bending_safety_factor: float
    contact_safety_factor: float

    def summary(self) -> str:
        """Return formatted summary string."""
        return (
            f"=== Gear Analysis Results (AGMA 2101) ===\n"
            f"  Pitch Diameter:       {self.pitch_diameter.to('mm'):.1f}\n"
            f"  Tangential Force:     {self.tangential_force.to('N'):.1f}\n"
            f"  Pitch Line Velocity:  {self.pitch_line_velocity.to('m/s'):.2f}\n"
            f"  Bending Stress:       {self.bending_stress.to('MPa'):.1f}\n"
            f"  Contact Stress:       {self.contact_stress.to('MPa'):.1f}\n"
            f"  Bending SF:           {self.bending_safety_factor:.2f}\n"
            f"  Contact SF:           {self.contact_safety_factor:.2f}\n"
        )


class SpurGear:
    """Spur gear analysis per AGMA 2101-D04.

    Parameters
    ----------
    module : pint.Quantity
        Gear module [mm] (metric) or use diametral_pitch.
    teeth : int
        Number of teeth.
    face_width : pint.Quantity
        Face width [length].
    power : pint.Quantity
        Transmitted power [W or kW].
    speed : pint.Quantity
        Rotational speed [RPM].
    material_hardness : float
        Brinell hardness of gear material (HB).
    pressure_angle : float
        Pressure angle [degrees]. Default 20.
    quality_number : int
        AGMA quality number (5-12). Default 8.
    Ko : float
        Overload factor. Default 1.0.
    reliability : float
        Required reliability (0-1). Default 0.99.

    Notes
    -----
    AGMA Bending stress equation:

    .. math:: \\sigma_b = W_t \\cdot K_o \\cdot K_v \\cdot K_s \\cdot
              \\frac{1}{b \\cdot m_t} \\cdot \\frac{K_H}{K_B} \\cdot Y_J

    AGMA Contact stress equation:

    .. math:: \\sigma_c = Z_E \\sqrt{W_t \\cdot K_o \\cdot K_v \\cdot K_s \\cdot
              \\frac{K_H}{d_w \\cdot b} \\cdot \\frac{Z_R}{Z_I}}

    References
    ----------
    .. [1] AGMA 2101-D04, Eqs. (1) and (2)
    .. [2] Shigley's MED, 11th Ed., Eqs. (14-15) to (14-16)
    """

    def __init__(
        self,
        module: pint.Quantity,
        teeth: int,
        face_width: pint.Quantity,
        power: pint.Quantity,
        speed: pint.Quantity,
        material_hardness: float = 300,
        pressure_angle: float = 20.0,
        quality_number: int = 8,
        Ko: float = 1.0,
        reliability: float = 0.99,
    ) -> None:
        self.m = module.to("mm").magnitude  # Module in mm
        self.N = teeth
        self.b = face_width.to("mm").magnitude
        self.P = power.to("W").magnitude
        self.n = speed.to("rpm").magnitude
        self.HB = material_hardness
        self.phi = pressure_angle
        self.Qv = quality_number
        self.Ko = Ko
        self.reliability = reliability

        # Derived geometry
        self.d = self.m * self.N  # Pitch diameter [mm]
        self.V = np.pi * self.d * self.n / 60000  # Pitch line velocity [m/s]

        # Tangential force
        if self.V > 0:
            self.Wt = self.P / self.V  # [N]
        else:
            self.Wt = 0

    def analyze(self) -> GearResult:
        """Perform complete AGMA gear analysis.

        Returns
        -------
        GearResult
            Complete gear analysis results.
        """
        # Dynamic factor Kv (AGMA)
        B_factor = 0.25 * (12 - self.Qv) ** (2 / 3)
        A_factor = 50 + 56 * (1 - B_factor)
        Kv = ((A_factor + np.sqrt(200 * self.V)) / A_factor) ** B_factor

        # Size factor Ks
        Ks = 1.0  # For standard module ranges

        # Load distribution factor KH
        # Simplified AGMA equation
        Cmc = 1.0  # Uncrowned
        Cpf = self.b / (10 * self.d) - 0.025 if self.b / self.d <= 0.5 else 0.05
        Cpf = max(Cpf, 0.05)
        Cpm = 1.0  # Straddle mounted
        Cma = 0.127 + 0.0158 * (self.b / 25.4)  # Commercial enclosed
        Ce = 1.0  # Not adjusted
        KH = 1.0 + Cmc * (Cpf * Cpm + Cma * Ce)

        # Lewis form factor Y_J (approximation based on teeth number)
        Y_J = self._lewis_form_factor()

        # Bending stress
        sigma_b = (
            self.Wt * self.Ko * Kv * Ks * KH / (self.b * self.m * Y_J)
        ) if Y_J > 0 else 0

        # Geometry factor for pitting Z_I
        mG = 3.0  # Assumed gear ratio (external)
        Z_I = (np.cos(np.radians(self.phi)) * np.sin(np.radians(self.phi)) / 2) * (
            mG / (mG + 1)
        )

        # Elastic coefficient Z_E (steel on steel)
        Z_E = 191.0  # MPa^0.5 for steel-steel

        # Contact stress
        if self.d > 0 and self.b > 0 and Z_I > 0:
            sigma_c = Z_E * np.sqrt(
                self.Wt * self.Ko * Kv * Ks * KH / (self.d * self.b * Z_I)
            )
        else:
            sigma_c = 0

        # Allowable stresses based on hardness
        St = 0.533 * self.HB + 88.3  # Bending allowable [MPa] (AGMA)
        Sc = 2.22 * self.HB + 200  # Contact allowable [MPa] (AGMA)

        # Safety factors
        n_bending = St / sigma_b if sigma_b > 0 else float("inf")
        n_contact = (Sc / sigma_c) ** 2 if sigma_c > 0 else float("inf")

        return GearResult(
            bending_stress=Q(sigma_b, "MPa"),
            contact_stress=Q(sigma_c, "MPa"),
            pitch_diameter=Q(self.d, "mm"),
            pitch_line_velocity=Q(self.V, "m/s"),
            tangential_force=Q(self.Wt, "N"),
            bending_safety_factor=n_bending,
            contact_safety_factor=n_contact,
        )

    def _lewis_form_factor(self) -> float:
        """Approximate Lewis form factor Y based on number of teeth.

        Uses curve-fit for 20° full-depth involute profile.

        References
        ----------
        .. [1] Shigley's MED, 11th Ed., Table 14-2
        """
        N = self.N
        # Interpolation data (teeth: Y-factor)
        teeth = [12, 14, 16, 18, 20, 24, 28, 32, 40, 50, 60, 75, 100, 150, 200, 300]
        Y = [0.245, 0.277, 0.296, 0.309, 0.322, 0.337, 0.348, 0.357, 0.371,
             0.387, 0.399, 0.409, 0.421, 0.435, 0.447, 0.462]

        if N <= teeth[0]:
            return Y[0]
        if N >= teeth[-1]:
            return Y[-1]

        # Linear interpolation
        for i in range(len(teeth) - 1):
            if teeth[i] <= N <= teeth[i + 1]:
                t = (N - teeth[i]) / (teeth[i + 1] - teeth[i])
                return Y[i] + t * (Y[i + 1] - Y[i])
        return 0.35
