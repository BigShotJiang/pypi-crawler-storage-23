"""
Shaft Design — Combined Loading, ASME DE-Goodman, Critical Speed.

Complete shaft analysis with combined bending, torsion, and axial loading.
Includes ASME DE-Goodman criterion, critical speed calculations, and
keyway stress concentration.

References
----------
.. [1] Shigley's MED, 11th Ed., Chapters 7 & 11
.. [2] ASME B106.1M — Design of Transmission Shafting
.. [3] DIN 743 — Calculation of Load Capacity of Shafts and Axles

Examples
--------
>>> from mechforge.machine.shaft import Shaft
>>> from mechforge.core.units import Q
>>> from mechforge.core.materials import get_material
>>> shaft = Shaft(
...     length=Q(500, 'mm'),
...     diameter=Q(50, 'mm'),
...     torque=Q(200, 'N*m'),
...     material=get_material('AISI 4140'),
... )
>>> result = shaft.analyze()
>>> print(f'Safety factor: {result.safety_factor:.2f}')
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pint

from mechforge.core.units import Q, ureg
from mechforge.core.materials import Material
from mechforge.core.validators import validate_positive, validate_quantity
from mechforge.core.exceptions import ValidationError


@dataclass
class ShaftResult:
    """Results from shaft analysis.

    Attributes
    ----------
    max_bending_stress : pint.Quantity
        Maximum bending stress [MPa].
    max_shear_stress : pint.Quantity
        Maximum torsional shear stress [MPa].
    max_axial_stress : pint.Quantity
        Maximum axial stress [MPa].
    von_mises_stress : pint.Quantity
        Von Mises equivalent stress [MPa].
    safety_factor : float
        Safety factor (DE-Goodman or static).
    deflection : pint.Quantity
        Maximum deflection [mm].
    twist_angle : pint.Quantity
        Total angle of twist [degrees].
    critical_speed : pint.Quantity
        First critical speed [RPM].
    """

    max_bending_stress: pint.Quantity
    max_shear_stress: pint.Quantity
    max_axial_stress: pint.Quantity
    von_mises_stress: pint.Quantity
    safety_factor: float
    deflection: pint.Quantity
    twist_angle: pint.Quantity
    critical_speed: pint.Quantity

    def summary(self) -> str:
        """Return formatted summary string."""
        return (
            f"=== Shaft Analysis Results ===\n"
            f"  Max Bending Stress: {self.max_bending_stress.to('MPa'):.1f}\n"
            f"  Max Shear Stress:   {self.max_shear_stress.to('MPa'):.1f}\n"
            f"  Von Mises Stress:   {self.von_mises_stress.to('MPa'):.1f}\n"
            f"  Safety Factor:      {self.safety_factor:.2f}\n"
            f"  Max Deflection:     {self.deflection.to('mm'):.3f}\n"
            f"  Twist Angle:        {self.twist_angle.to('degree'):.3f}\n"
            f"  Critical Speed:     {self.critical_speed.to('rpm'):.0f}\n"
        )


class Shaft:
    """Complete shaft analysis with combined loading.

    Parameters
    ----------
    length : pint.Quantity
        Shaft length [length].
    diameter : pint.Quantity
        Shaft outer diameter [length].
    torque : pint.Quantity
        Applied torque [force*length].
    material : Material
        Shaft material.
    bending_moment : pint.Quantity, optional
        Applied bending moment [force*length].
    axial_force : pint.Quantity, optional
        Applied axial force [force].
    inner_diameter : pint.Quantity, optional
        Inner diameter for hollow shaft [length].
    Kt_bending : float
        Stress concentration factor for bending. Default 1.0.
    Kt_torsion : float
        Stress concentration factor for torsion. Default 1.0.
    power : pint.Quantity, optional
        Transmitted power [W]. If given with speed, calculates torque.
    speed : pint.Quantity, optional
        Rotational speed [RPM].

    Notes
    -----
    For solid circular shaft:

    .. math:: \\sigma_b = \\frac{32M}{\\pi d^3}

    .. math:: \\tau = \\frac{16T}{\\pi d^3}

    ASME DE-Goodman criterion:

    .. math:: d = \\left[\\frac{16n}{\\pi}\\left(
              \\frac{1}{S_e}\\sqrt{4(K_f M_a)^2 + 3(K_{fs} T_a)^2}
              + \\frac{1}{S_{ut}}\\sqrt{4(K_f M_m)^2 + 3(K_{fs} T_m)^2}
              \\right)\\right]^{1/3}

    References
    ----------
    .. [1] Shigley's MED, 11th Ed., Eq. (7-8)
    .. [2] ASME B106.1M-1985
    """

    def __init__(
        self,
        length: pint.Quantity,
        diameter: pint.Quantity,
        torque: pint.Quantity,
        material: Material,
        bending_moment: Optional[pint.Quantity] = None,
        axial_force: Optional[pint.Quantity] = None,
        inner_diameter: Optional[pint.Quantity] = None,
        Kt_bending: float = 1.0,
        Kt_torsion: float = 1.0,
        power: Optional[pint.Quantity] = None,
        speed: Optional[pint.Quantity] = None,
    ) -> None:
        validate_quantity(length, "length")
        validate_positive(length, "length")
        validate_quantity(diameter, "diameter")
        validate_positive(diameter, "diameter")

        self.L = length.to("m").magnitude
        self.d = diameter.to("m").magnitude
        self.material = material
        self.Kt_b = Kt_bending
        self.Kt_t = Kt_torsion

        # Handle power/speed -> torque
        if power is not None and speed is not None:
            omega = speed.to("rad/s").magnitude
            self.T = power.to("W").magnitude / omega if omega > 0 else 0
        else:
            validate_quantity(torque, "torque")
            self.T = torque.to("N*m").magnitude

        self.M = bending_moment.to("N*m").magnitude if bending_moment is not None else 0
        self.F_a = axial_force.to("N").magnitude if axial_force is not None else 0
        self.d_i = inner_diameter.to("m").magnitude if inner_diameter is not None else 0

        # Section properties
        self._calc_section_props()

    def _calc_section_props(self) -> None:
        """Calculate cross-section properties."""
        d, d_i = self.d, self.d_i
        self.A = np.pi / 4 * (d**2 - d_i**2)  # Area
        self.I = np.pi / 64 * (d**4 - d_i**4)  # Second moment of area
        self.J = np.pi / 32 * (d**4 - d_i**4)  # Polar moment of area
        self.c = d / 2  # Distance to extreme fiber
        self.Z = self.I / self.c  # Section modulus
        self.Zp = self.J / self.c  # Polar section modulus

    def analyze(self) -> ShaftResult:
        """Perform complete shaft analysis.

        Returns
        -------
        ShaftResult
            Complete analysis results including stresses, safety factor,
            deflection, and critical speed.
        """
        E = self.material.elastic_modulus.to("Pa").magnitude
        G = self.material.shear_modulus.to("Pa").magnitude
        Sy = self.material.yield_strength.to("Pa").magnitude
        Sut = self.material.ultimate_strength.to("Pa").magnitude
        rho = self.material.density.to("kg/m**3").magnitude

        # Bending stress: σ_b = M*c/I
        sigma_b = self.Kt_b * self.M * self.c / self.I if self.I > 0 else 0

        # Torsional shear stress: τ = T*c/J
        tau = self.Kt_t * self.T * self.c / self.J if self.J > 0 else 0

        # Axial stress: σ_a = F/A
        sigma_a = self.F_a / self.A if self.A > 0 else 0

        # Von Mises equivalent stress
        sigma_total = sigma_b + sigma_a
        sigma_vm = np.sqrt(sigma_total**2 + 3 * tau**2)

        # Safety factor (static - distortion energy theory)
        n_static = Sy / sigma_vm if sigma_vm > 0 else float("inf")

        # Deflection (simply supported beam with center load)
        delta = self.M * self.L**2 / (8 * E * self.I) if self.I > 0 else 0

        # Angle of twist: φ = TL/(GJ)
        phi = self.T * self.L / (G * self.J) if self.J > 0 else 0

        # Critical speed (Rayleigh's method for uniform shaft)
        m_shaft = rho * self.A * self.L  # Mass
        if m_shaft > 0 and E * self.I > 0:
            # First natural frequency of simply supported beam
            omega_n = (np.pi**2 / self.L**2) * np.sqrt(E * self.I / (rho * self.A))
            critical_rpm = omega_n * 60 / (2 * np.pi)
        else:
            critical_rpm = 0

        return ShaftResult(
            max_bending_stress=Q(sigma_b / 1e6, "MPa"),
            max_shear_stress=Q(tau / 1e6, "MPa"),
            max_axial_stress=Q(sigma_a / 1e6, "MPa"),
            von_mises_stress=Q(sigma_vm / 1e6, "MPa"),
            safety_factor=n_static,
            deflection=Q(delta * 1e3, "mm"),
            twist_angle=Q(np.degrees(phi), "degree"),
            critical_speed=Q(critical_rpm, "rpm"),
        )

    @staticmethod
    def minimum_diameter(
        torque: pint.Quantity,
        material: Material,
        safety_factor: float = 2.0,
        bending_moment: Optional[pint.Quantity] = None,
    ) -> pint.Quantity:
        """Calculate minimum shaft diameter for given loads.

        Parameters
        ----------
        torque : pint.Quantity
            Applied torque.
        material : Material
            Shaft material.
        safety_factor : float
            Required safety factor.
        bending_moment : pint.Quantity, optional
            Applied bending moment.

        Returns
        -------
        pint.Quantity
            Minimum required diameter [mm].

        Notes
        -----
        Using distortion energy theory:

        .. math:: d = \\left(\\frac{16n}{\\pi S_y}
                  \\sqrt{4M^2 + 3T^2}\\right)^{1/3}

        References
        ----------
        .. [1] Shigley's MED, 11th Ed., Eq. (7-8)
        """
        T = torque.to("N*m").magnitude
        Sy = material.yield_strength.to("Pa").magnitude
        M = bending_moment.to("N*m").magnitude if bending_moment is not None else 0

        d_cubed = (16 * safety_factor / (np.pi * Sy)) * np.sqrt(4 * M**2 + 3 * T**2)
        d = d_cubed ** (1 / 3)

        return Q(d * 1000, "mm")
