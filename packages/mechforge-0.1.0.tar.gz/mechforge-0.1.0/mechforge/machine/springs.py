"""
Spring Design — Helical Compression/Extension/Torsion Springs.

Complete spring design including stress analysis, buckling check, natural
frequency, fatigue life, and spring index optimization.

References
----------
.. [1] Shigley's MED, 11th Ed., Chapter 10
.. [2] Spring Manufacturers Institute (SMI) Handbook
.. [3] DIN EN 13906 — Cylindrical Helical Springs

Examples
--------
>>> from mechforge.machine.springs import HelicalSpring
>>> from mechforge.core.units import Q
>>> spring = HelicalSpring(
...     wire_diameter=Q(3, 'mm'), mean_coil_diameter=Q(25, 'mm'),
...     free_length=Q(60, 'mm'), active_coils=8,
...     material_Sut=Q(1700, 'MPa'), material_G=Q(79.3, 'GPa'),
... )
>>> result = spring.analyze(force=Q(100, 'N'))
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pint

from mechforge.core.units import Q, ureg
from mechforge.core.exceptions import ValidationError


@dataclass
class SpringResult:
    """Results from spring analysis.

    Attributes
    ----------
    spring_rate : pint.Quantity
        Spring rate (stiffness) [N/mm].
    shear_stress : pint.Quantity
        Maximum shear stress (Wahl corrected) [MPa].
    deflection : pint.Quantity
        Deflection at applied force [mm].
    spring_index : float
        Spring index C = D/d.
    Wahl_factor : float
        Wahl correction factor Kw.
    solid_length : pint.Quantity
        Solid (fully compressed) length [mm].
    natural_frequency : pint.Quantity
        Fundamental natural frequency [Hz].
    buckling_critical : bool
        Whether buckling is a concern.
    safety_factor : float
        Safety factor (Ssy/τ_max).
    """

    spring_rate: pint.Quantity
    shear_stress: pint.Quantity
    deflection: pint.Quantity
    spring_index: float
    Wahl_factor: float
    solid_length: pint.Quantity
    natural_frequency: pint.Quantity
    buckling_critical: bool
    safety_factor: float

    def summary(self) -> str:
        """Return formatted summary."""
        buck = "⚠️ YES" if self.buckling_critical else "✅ No"
        return (
            f"=== Helical Spring Analysis ===\n"
            f"  Spring Index (C):     {self.spring_index:.2f}\n"
            f"  Wahl Factor:          {self.Wahl_factor:.3f}\n"
            f"  Spring Rate:          {self.spring_rate.to('N/mm'):.2f}\n"
            f"  Shear Stress:         {self.shear_stress.to('MPa'):.1f}\n"
            f"  Deflection:           {self.deflection.to('mm'):.2f}\n"
            f"  Solid Length:         {self.solid_length.to('mm'):.1f}\n"
            f"  Natural Frequency:    {self.natural_frequency.to('Hz'):.1f}\n"
            f"  Buckling Risk:        {buck}\n"
            f"  Safety Factor:        {self.safety_factor:.2f}\n"
        )


class HelicalSpring:
    """Helical compression spring analysis.

    Parameters
    ----------
    wire_diameter : pint.Quantity
        Wire diameter d [mm].
    mean_coil_diameter : pint.Quantity
        Mean coil diameter D [mm].
    free_length : pint.Quantity
        Free (unloaded) length L0 [mm].
    active_coils : float
        Number of active coils Na.
    material_Sut : pint.Quantity
        Wire ultimate tensile strength [MPa].
    material_G : pint.Quantity
        Wire shear modulus [GPa].
    end_type : str
        End type: 'plain', 'plain_ground', 'squared', 'squared_ground'.
    material_density : pint.Quantity, optional
        Wire material density [kg/m³]. Default 7850 (steel).

    Notes
    -----
    Spring rate:

    .. math:: k = \\frac{d^4 G}{8 D^3 N_a}

    Maximum shear stress (Wahl):

    .. math:: \\tau = K_w \\frac{8FD}{\\pi d^3}

    Where the Wahl correction factor is:

    .. math:: K_w = \\frac{4C - 1}{4C - 4} + \\frac{0.615}{C}

    References
    ----------
    .. [1] Shigley's MED, 11th Ed., Eqs. (10-1) to (10-14)
    """

    def __init__(
        self,
        wire_diameter: pint.Quantity,
        mean_coil_diameter: pint.Quantity,
        free_length: pint.Quantity,
        active_coils: float,
        material_Sut: pint.Quantity,
        material_G: pint.Quantity,
        end_type: str = "squared_ground",
        material_density: Optional[pint.Quantity] = None,
    ) -> None:
        self.d = wire_diameter.to("mm").magnitude
        self.D = mean_coil_diameter.to("mm").magnitude
        self.L0 = free_length.to("mm").magnitude
        self.Na = active_coils
        self.Sut = material_Sut.to("MPa").magnitude
        self.G = material_G.to("MPa").magnitude
        self.end_type = end_type
        self.rho = (
            material_density.to("kg/m**3").magnitude
            if material_density is not None
            else 7850
        )

        # Spring index
        self.C = self.D / self.d

        if self.C < 3 or self.C > 16:
            import warnings
            warnings.warn(
                f"Spring index C = {self.C:.1f} is outside recommended range (4-12).",
                stacklevel=2,
            )

        # Total coils based on end type
        end_coils = {"plain": 0, "plain_ground": 1, "squared": 2, "squared_ground": 2}
        self.Nt = self.Na + end_coils.get(end_type, 2)

        # Solid length
        solid_add = {
            "plain": self.d * (self.Nt + 1),
            "plain_ground": self.d * self.Nt,
            "squared": self.d * (self.Nt + 1),
            "squared_ground": self.d * self.Nt,
        }
        self.Ls = solid_add.get(end_type, self.d * self.Nt)

    def analyze(self, force: pint.Quantity) -> SpringResult:
        """Perform complete spring analysis at given force.

        Parameters
        ----------
        force : pint.Quantity
            Applied compressive force [N].

        Returns
        -------
        SpringResult
            Complete spring analysis results.
        """
        F = force.to("N").magnitude

        # Spring rate: k = d⁴G / (8D³Na)
        k = self.d**4 * self.G / (8 * self.D**3 * self.Na)  # N/mm

        # Wahl correction factor
        Kw = (4 * self.C - 1) / (4 * self.C - 4) + 0.615 / self.C

        # Maximum shear stress (corrected)
        tau = Kw * 8 * F * self.D / (np.pi * self.d**3)

        # Deflection
        delta = F / k if k > 0 else 0

        # Natural frequency (fundamental, both ends fixed)
        # f_n = (d/(2π·Na·D²)) · √(G·g / (32·ρ))
        if self.Na > 0 and self.D > 0:
            fn = (self.d / (2 * np.pi * self.Na * self.D**2)) * np.sqrt(
                self.G * 1e6 * 1000 / (32 * self.rho)
            )  # Convert G from MPa to Pa, mm to m
        else:
            fn = 0

        # Buckling check
        # Critical length ratio for squared/ground ends
        alpha = self.L0 / self.D
        buckling_critical = alpha > 5.26  # For fixed-fixed ends

        # Shear yield strength (Ssy ≈ 0.577*Sy ≈ 0.45*Sut for spring wire)
        Ssy = 0.45 * self.Sut

        # Safety factor
        n = Ssy / tau if tau > 0 else float("inf")

        return SpringResult(
            spring_rate=Q(k, "N/mm"),
            shear_stress=Q(tau, "MPa"),
            deflection=Q(delta, "mm"),
            spring_index=self.C,
            Wahl_factor=Kw,
            solid_length=Q(self.Ls, "mm"),
            natural_frequency=Q(fn, "Hz"),
            buckling_critical=buckling_critical,
            safety_factor=n,
        )
