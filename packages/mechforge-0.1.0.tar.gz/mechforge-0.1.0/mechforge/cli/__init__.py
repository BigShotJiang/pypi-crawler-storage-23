"""
MechForge CLI Module (Stub).

Command-line interface for running MechForge calculations,
generating reports, and managing the materials database.
"""

from __future__ import annotations

import argparse
import sys


def main() -> None:
    """MechForge CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="mechforge",
        description="MechForge — Mechanical Engineering Computation Platform",
    )
    subparsers = parser.add_subparsers(dest="command")

    # Version
    parser.add_argument("--version", action="store_true", help="Show version")

    # Materials lookup
    mat_parser = subparsers.add_parser("material", help="Look up material properties")
    mat_parser.add_argument("name", help="Material name")

    # List materials
    subparsers.add_parser("materials", help="List all available materials")

    # Info
    subparsers.add_parser("info", help="Show package information")

    args = parser.parse_args()

    if args.version:
        from mechforge import __version__
        print(f"MechForge v{__version__}")
        return

    if args.command == "material":
        from mechforge.core.materials import get_material
        try:
            mat = get_material(args.name)
            print(f"\n{'='*50}")
            print(f"  Material: {mat.name}")
            print(f"  Category: {mat.category}")
            print(f"{'='*50}")
            print(f"  Density:          {mat.density}")
            print(f"  Elastic Modulus:  {mat.elastic_modulus}")
            print(f"  Yield Strength:   {mat.yield_strength}")
            print(f"  Ultimate Strength:{mat.ultimate_strength}")
            if mat.poissons_ratio:
                print(f"  Poisson's Ratio:  {mat.poissons_ratio}")
            if mat.thermal_conductivity:
                print(f"  Thermal Cond.:    {mat.thermal_conductivity}")
            print()
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    elif args.command == "materials":
        from mechforge.core.materials import list_materials
        materials = list_materials()
        print(f"\nAvailable Materials ({len(materials)}):")
        print("-" * 40)
        for name in sorted(materials):
            print(f"  {name}")

    elif args.command == "info":
        from mechforge import __version__
        print(f"\nMechForge v{__version__}")
        print("Mechanical Engineering Computation Platform")
        print()
        print("Modules:")
        modules = [
            "core       — Units, materials (500+), constants",
            "structural — Beam, stress, fatigue, fracture",
            "machine    — Shaft, gears, bearings, bolts, springs",
            "fluids     — Pipe flow, pumps, compressible, external",
            "thermal    — Cycles, heat transfer, heat exchangers",
            "reports    — PDF/text engineering reports",
            "dynamics   — Vibration analysis (SDOF)",
            "controls   — PID tuning",
            "manufacturing — Machining calculations",
            "pressure   — Pressure vessel design",
            "energy     — Wind/solar power",
            "simulation — Basic FEA (truss)",
            "solvers    — Root-finding, ODE solvers",
        ]
        for m in modules:
            print(f"  • {m}")
        print()

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
