"""
MechForge Fluids Module.

Covers pipe flow, pump system design, compressible flow, and external
aerodynamics.
"""

from __future__ import annotations

from mechforge.fluids.pipe_flow import (
    PipeFlow,
    PipeResult,
    friction_factor,
    reynolds_number,
    pressure_drop,
    water_hammer,
)
from mechforge.fluids.pump_systems import PumpSystem, PumpResult
from mechforge.fluids.compressible import (
    isentropic_relations,
    normal_shock,
    fanno_flow,
    rayleigh_flow,
)
from mechforge.fluids.external_flow import drag_force, lift_force, boundary_layer

__all__ = [
    "PipeFlow",
    "PipeResult",
    "friction_factor",
    "reynolds_number",
    "pressure_drop",
    "water_hammer",
    "PumpSystem",
    "PumpResult",
    "isentropic_relations",
    "normal_shock",
    "fanno_flow",
    "rayleigh_flow",
    "drag_force",
    "lift_force",
    "boundary_layer",
]
