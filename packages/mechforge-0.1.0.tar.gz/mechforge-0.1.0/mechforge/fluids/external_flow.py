"""
External Flow — Drag, Lift, Boundary Layer Analysis.

External aerodynamics including drag/lift force calculation, boundary
layer parameters, and standard body drag coefficients.

References
----------
.. [1] Cengel & Cimbala, Fluid Mechanics, Chapters 11-12
.. [2] Schlichting, Boundary Layer Theory, 9th Ed.
.. [3] Anderson, Fundamentals of Aerodynamics, 6th Ed.

Examples
--------
>>> from mechforge.fluids.external_flow import drag_force, boundary_layer
>>> from mechforge.core.units import Q
>>> Fd = drag_force(
...     Cd=0.47, area=Q(0.01, 'm**2'),
...     velocity=Q(30, 'm/s'), density=Q(1.225, 'kg/m**3'),
... )
>>> print(f'Drag force: {Fd.to("N"):.2f}')
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pint

from mechforge.core.units import Q, ureg


# Standard drag coefficients for common shapes
DRAG_COEFFICIENTS = {
    "sphere": 0.47,
    "hemisphere_open": 1.42,
    "hemisphere_closed": 0.42,
    "disk": 1.17,
    "cylinder_long": 0.82,
    "cylinder_short": 1.15,
    "cube": 1.05,
    "cone_60": 0.50,
    "streamlined_body": 0.04,
    "flat_plate_normal": 1.28,
    "flat_plate_parallel": 0.001,
    "airfoil_typical": 0.02,
    "car_typical": 0.35,
    "truck": 0.90,
    "bicycle_rider": 0.90,
    "parachute": 1.40,
}


def drag_force(
    Cd: float,
    area: pint.Quantity,
    velocity: pint.Quantity,
    density: pint.Quantity = Q(1.225, "kg/m**3"),
) -> pint.Quantity:
    """Calculate aerodynamic drag force.

    .. math:: F_D = \\frac{1}{2} C_D \\rho V^2 A

    Parameters
    ----------
    Cd : float
        Drag coefficient.
    area : pint.Quantity
        Reference (frontal) area [m²].
    velocity : pint.Quantity
        Free-stream velocity [m/s].
    density : pint.Quantity
        Fluid density [kg/m³].

    Returns
    -------
    pint.Quantity
        Drag force [N].
    """
    A = area.to("m**2").magnitude
    V = velocity.to("m/s").magnitude
    rho = density.to("kg/m**3").magnitude
    Fd = 0.5 * Cd * rho * V**2 * A
    return Q(Fd, "N")


def lift_force(
    Cl: float,
    area: pint.Quantity,
    velocity: pint.Quantity,
    density: pint.Quantity = Q(1.225, "kg/m**3"),
) -> pint.Quantity:
    """Calculate aerodynamic lift force.

    .. math:: F_L = \\frac{1}{2} C_L \\rho V^2 A

    Parameters
    ----------
    Cl : float
        Lift coefficient.
    area : pint.Quantity
        Reference (planform) area [m²].
    velocity : pint.Quantity
        Free-stream velocity [m/s].
    density : pint.Quantity
        Fluid density [kg/m³].

    Returns
    -------
    pint.Quantity
        Lift force [N].
    """
    A = area.to("m**2").magnitude
    V = velocity.to("m/s").magnitude
    rho = density.to("kg/m**3").magnitude
    Fl = 0.5 * Cl * rho * V**2 * A
    return Q(Fl, "N")


@dataclass
class BoundaryLayerResult:
    """Boundary layer analysis results."""

    x: pint.Quantity
    Re_x: float
    regime: str  # 'laminar' or 'turbulent'
    delta: pint.Quantity  # BL thickness
    delta_star: pint.Quantity  # Displacement thickness
    theta: pint.Quantity  # Momentum thickness
    Cf: float  # Local skin friction coefficient
    tau_w: pint.Quantity  # Wall shear stress


def boundary_layer(
    x: pint.Quantity,
    velocity: pint.Quantity,
    density: pint.Quantity = Q(1.225, "kg/m**3"),
    viscosity: pint.Quantity = Q(1.81e-5, "Pa*s"),
    transition_Re: float = 5e5,
) -> BoundaryLayerResult:
    """Calculate flat plate boundary layer parameters.

    Parameters
    ----------
    x : pint.Quantity
        Distance from leading edge [m].
    velocity : pint.Quantity
        Free-stream velocity [m/s].
    density : pint.Quantity
        Fluid density [kg/m³].
    viscosity : pint.Quantity
        Dynamic viscosity [Pa·s].
    transition_Re : float
        Critical Reynolds number for transition.

    Returns
    -------
    BoundaryLayerResult
        Boundary layer parameters.

    Notes
    -----
    Laminar (Blasius):

    .. math:: \\delta = \\frac{5x}{\\sqrt{Re_x}}

    .. math:: C_f = \\frac{0.664}{\\sqrt{Re_x}}

    Turbulent (1/7th power law):

    .. math:: \\delta = \\frac{0.37x}{Re_x^{1/5}}

    .. math:: C_f = \\frac{0.0592}{Re_x^{1/5}}

    References
    ----------
    .. [1] Schlichting, Boundary Layer Theory, Chapter 2 & 21
    """
    x_val = x.to("m").magnitude
    V = velocity.to("m/s").magnitude
    rho = density.to("kg/m**3").magnitude
    mu = viscosity.to("Pa*s").magnitude

    Re_x = rho * V * x_val / mu if mu > 0 else 0

    if Re_x < transition_Re:
        # Laminar (Blasius solution)
        regime = "laminar"
        Re_sqrt = np.sqrt(Re_x) if Re_x > 0 else 1
        delta = 5.0 * x_val / Re_sqrt
        delta_star = 1.721 * x_val / Re_sqrt
        theta = 0.664 * x_val / Re_sqrt
        Cf = 0.664 / Re_sqrt
    else:
        # Turbulent (1/7th power law)
        regime = "turbulent"
        Re_fifth = Re_x**0.2 if Re_x > 0 else 1
        delta = 0.37 * x_val / Re_fifth
        delta_star = delta / 8
        theta = 7 * delta / 72
        Cf = 0.0592 / Re_fifth

    tau_w = Cf * 0.5 * rho * V**2

    return BoundaryLayerResult(
        x=Q(x_val, "m"),
        Re_x=Re_x,
        regime=regime,
        delta=Q(delta * 1000, "mm"),
        delta_star=Q(delta_star * 1000, "mm"),
        theta=Q(theta * 1000, "mm"),
        Cf=Cf,
        tau_w=Q(tau_w, "Pa"),
    )
