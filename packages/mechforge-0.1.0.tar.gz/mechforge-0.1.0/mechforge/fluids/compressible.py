"""
Compressible Flow — Isentropic, Normal Shocks, Fanno, Rayleigh.

Complete compressible gas dynamics including isentropic flow relations,
normal shock waves, Fanno (friction) flow, and Rayleigh (heat addition) flow.

References
----------
.. [1] Anderson, Modern Compressible Flow, 3rd Ed.
.. [2] Cengel & Cimbala, Fluid Mechanics, Chapters 17-18
.. [3] NACA Report 1135 — Equations, Tables & Charts for Compressible Flow

Examples
--------
>>> from mechforge.fluids.compressible import isentropic_relations
>>> result = isentropic_relations(Mach=2.0, gamma=1.4)
>>> print(f"P/P0 = {result['p_ratio']:.4f}")
"""

from __future__ import annotations

import numpy as np


def isentropic_relations(Mach: float, gamma: float = 1.4) -> dict:
    """Calculate isentropic flow property ratios.

    Parameters
    ----------
    Mach : float
        Mach number.
    gamma : float
        Ratio of specific heats. Default 1.4 (air).

    Returns
    -------
    dict
        Keys: 'M', 'T_ratio' (T/T0), 'p_ratio' (p/p0), 'rho_ratio' (ρ/ρ0),
        'A_ratio' (A/A*), 'v_ratio' (V/a*), 'F_ratio' (impulse).

    Notes
    -----
    .. math:: \\frac{T_0}{T} = 1 + \\frac{\\gamma - 1}{2} M^2

    .. math:: \\frac{p_0}{p} = \\left(1 + \\frac{\\gamma - 1}{2} M^2
              \\right)^{\\gamma/(\\gamma-1)}
    """
    M = Mach
    g = gamma
    gm1 = g - 1

    # Stagnation ratios
    factor = 1 + gm1 / 2 * M**2
    T_ratio = 1 / factor
    p_ratio = factor ** (-g / gm1)
    rho_ratio = factor ** (-1 / gm1)

    # Area ratio A/A*
    if M > 0:
        A_ratio = (1 / M) * ((2 / (g + 1)) * factor) ** ((g + 1) / (2 * gm1))
    else:
        A_ratio = float("inf")

    return {
        "M": M,
        "T_ratio": T_ratio,
        "p_ratio": p_ratio,
        "rho_ratio": rho_ratio,
        "A_ratio": A_ratio,
    }


def normal_shock(M1: float, gamma: float = 1.4) -> dict:
    """Calculate normal shock wave relations.

    Parameters
    ----------
    M1 : float
        Upstream (pre-shock) Mach number. Must be > 1.
    gamma : float
        Ratio of specific heats. Default 1.4.

    Returns
    -------
    dict
        Keys: 'M1', 'M2' (downstream Mach), 'p2_p1', 'T2_T1',
        'rho2_rho1', 'p02_p01' (stagnation pressure ratio).

    Notes
    -----
    .. math:: M_2^2 = \\frac{1 + \\frac{\\gamma-1}{2} M_1^2}
              {\\gamma M_1^2 - \\frac{\\gamma-1}{2}}

    References
    ----------
    .. [1] Anderson, Modern Compressible Flow, Chapter 3
    """
    g = gamma
    gm1 = g - 1
    M = M1

    # Downstream Mach
    M2_sq = (1 + gm1 / 2 * M**2) / (g * M**2 - gm1 / 2)
    M2 = np.sqrt(max(M2_sq, 0))

    # Pressure ratio
    p2_p1 = 1 + 2 * g / (g + 1) * (M**2 - 1)

    # Temperature ratio
    T2_T1 = p2_p1 * (2 + gm1 * M**2) / ((g + 1) * M**2)

    # Density ratio
    rho2_rho1 = (g + 1) * M**2 / (2 + gm1 * M**2)

    # Stagnation pressure ratio
    p02_p01 = (
        ((gm1 * M**2 + 2) / (g + 1)) ** (g / gm1)
        * ((g + 1) / (2 * g * M**2 - gm1)) ** (1 / gm1)
    )

    return {
        "M1": M1,
        "M2": M2,
        "p2_p1": p2_p1,
        "T2_T1": T2_T1,
        "rho2_rho1": rho2_rho1,
        "p02_p01": p02_p01,
    }


def fanno_flow(Mach: float, gamma: float = 1.4) -> dict:
    """Calculate Fanno flow (adiabatic with friction) relations.

    Parameters
    ----------
    Mach : float
        Mach number.
    gamma : float
        Ratio of specific heats.

    Returns
    -------
    dict
        Keys: 'M', 'T_Tstar', 'p_pstar', 'rho_rhostar',
        'V_Vstar', 'p0_p0star', 'fLstar_D'.

    Notes
    -----
    Fanno parameter:

    .. math:: \\frac{fL^*}{D} = \\frac{1-M^2}{\\gamma M^2}
              + \\frac{\\gamma+1}{2\\gamma}
              \\ln\\frac{(\\gamma+1)M^2}{2+( \\gamma-1)M^2}

    References
    ----------
    .. [1] Anderson, Modern Compressible Flow, Chapter 3
    """
    M = Mach
    g = gamma
    gm1 = g - 1
    gp1 = g + 1

    factor = 1 + gm1 / 2 * M**2

    T_Tstar = gp1 / (2 * factor)
    p_pstar = (1 / M) * np.sqrt(gp1 / (2 * factor)) if M > 0 else float("inf")
    V_Vstar = M * np.sqrt(gp1 / (2 * factor)) if factor > 0 else 0
    rho_rhostar = (1 / M) * np.sqrt(2 * factor / gp1) if M > 0 else float("inf")

    # Stagnation pressure ratio
    p0_p0star = (1 / M) * (2 * factor / gp1) ** (gp1 / (2 * gm1)) if M > 0 else float("inf")

    # Fanno parameter fL*/D
    if M > 0 and M != 1:
        fLstar_D = (1 - M**2) / (g * M**2) + gp1 / (2 * g) * np.log(
            gp1 * M**2 / (2 * factor)
        )
    else:
        fLstar_D = 0

    return {
        "M": M,
        "T_Tstar": T_Tstar,
        "p_pstar": p_pstar,
        "rho_rhostar": rho_rhostar,
        "V_Vstar": V_Vstar,
        "p0_p0star": p0_p0star,
        "fLstar_D": fLstar_D,
    }


def rayleigh_flow(Mach: float, gamma: float = 1.4) -> dict:
    """Calculate Rayleigh flow (frictionless with heat addition) relations.

    Parameters
    ----------
    Mach : float
        Mach number.
    gamma : float
        Ratio of specific heats.

    Returns
    -------
    dict
        Keys: 'M', 'T_Tstar', 'p_pstar', 'T0_T0star',
        'p0_p0star', 'V_Vstar'.

    References
    ----------
    .. [1] Anderson, Modern Compressible Flow, Chapter 3
    """
    M = Mach
    g = gamma
    gm1 = g - 1
    gp1 = g + 1

    factor = 1 + gm1 / 2 * M**2

    p_pstar = gp1 / (1 + g * M**2)

    T_Tstar = (gp1 * M / (1 + g * M**2)) ** 2 if (1 + g * M**2) > 0 else 0

    T0_T0star = (
        2 * gp1 * M**2 / (1 + g * M**2) ** 2 * factor
    ) if (1 + g * M**2) > 0 else 0

    p0_p0star = (
        gp1 / (1 + g * M**2) * (2 * factor / gp1) ** (g / gm1)
    )

    V_Vstar = gp1 * M**2 / (1 + g * M**2) if (1 + g * M**2) > 0 else 0

    return {
        "M": M,
        "T_Tstar": T_Tstar,
        "p_pstar": p_pstar,
        "T0_T0star": T0_T0star,
        "p0_p0star": p0_p0star,
        "V_Vstar": V_Vstar,
    }
