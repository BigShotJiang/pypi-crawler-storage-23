"""
Pump Systems — Pump Selection, System Curves, NPSH, Operating Point.

Centrifugal pump system design including system curve generation, pump
curve interpolation, NPSH analysis, and operating point determination.

References
----------
.. [1] Cengel & Cimbala, Fluid Mechanics, Chapter 14
.. [2] Karassik et al., Pump Handbook, 4th Ed.
.. [3] Hydraulic Institute Standards

Examples
--------
>>> from mechforge.fluids.pump_systems import PumpSystem
>>> from mechforge.core.units import Q
>>> ps = PumpSystem(
...     pipe_diameter=Q(150, 'mm'), pipe_length=Q(200, 'm'),
...     static_head=Q(30, 'm'), roughness=Q(0.045, 'mm'),
...     fluid_density=Q(998, 'kg/m**3'),
...     fluid_viscosity=Q(1.002e-3, 'Pa*s'),
... )
>>> result = ps.system_curve(Q(50, 'L/s'))
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np
import pint

from mechforge.core.units import Q, ureg
from mechforge.fluids.pipe_flow import friction_factor


@dataclass
class PumpResult:
    """Pump system analysis results.

    Attributes
    ----------
    flow_rates : list[pint.Quantity]
        Flow rate values for curve.
    system_heads : list[pint.Quantity]
        System head values [m].
    operating_point_Q : pint.Quantity, optional
        Operating flow rate [L/s].
    operating_point_H : pint.Quantity, optional
        Operating head [m].
    NPSHa : pint.Quantity, optional
        Available NPSH [m].
    power : pint.Quantity, optional
        Power required at operating point [kW].
    """

    flow_rates: list
    system_heads: list
    operating_point_Q: Optional[pint.Quantity] = None
    operating_point_H: Optional[pint.Quantity] = None
    NPSHa: Optional[pint.Quantity] = None
    power: Optional[pint.Quantity] = None

    def summary(self) -> str:
        """Return formatted summary."""
        lines = ["=== Pump System Analysis ==="]
        if self.operating_point_Q is not None:
            lines.append(f"  Operating Flow:  {self.operating_point_Q.to('L/s'):.2f}")
        if self.operating_point_H is not None:
            lines.append(f"  Operating Head:  {self.operating_point_H.to('m'):.2f}")
        if self.NPSHa is not None:
            lines.append(f"  NPSH available:  {self.NPSHa.to('m'):.2f}")
        if self.power is not None:
            lines.append(f"  Power Required:  {self.power.to('kW'):.2f}")
        return "\n".join(lines) + "\n"


class PumpSystem:
    """Centrifugal pump system analysis.

    Parameters
    ----------
    pipe_diameter : pint.Quantity
        Pipe inner diameter.
    pipe_length : pint.Quantity
        Total equivalent pipe length.
    static_head : pint.Quantity
        Static head difference [m].
    roughness : pint.Quantity
        Pipe roughness [mm].
    fluid_density : pint.Quantity
        Fluid density [kg/m³].
    fluid_viscosity : pint.Quantity
        Dynamic viscosity [Pa·s].
    K_minor : float
        Sum of minor loss coefficients. Default 5.0.
    pump_efficiency : float
        Pump efficiency (0-1). Default 0.75.
    """

    def __init__(
        self,
        pipe_diameter: pint.Quantity,
        pipe_length: pint.Quantity,
        static_head: pint.Quantity = Q(0, "m"),
        roughness: pint.Quantity = Q(0.045, "mm"),
        fluid_density: pint.Quantity = Q(998, "kg/m**3"),
        fluid_viscosity: pint.Quantity = Q(1.002e-3, "Pa*s"),
        K_minor: float = 5.0,
        pump_efficiency: float = 0.75,
    ) -> None:
        self.D = pipe_diameter.to("m").magnitude
        self.L = pipe_length.to("m").magnitude
        self.Hs = static_head.to("m").magnitude
        self.eps = roughness.to("m").magnitude
        self.rho = fluid_density.to("kg/m**3").magnitude
        self.mu = fluid_viscosity.to("Pa*s").magnitude
        self.K_minor = K_minor
        self.eta = pump_efficiency
        self.A = np.pi / 4 * self.D**2

    def system_head(self, flow_rate: pint.Quantity) -> pint.Quantity:
        """Calculate system head for a given flow rate.

        Parameters
        ----------
        flow_rate : pint.Quantity
            Volumetric flow rate.

        Returns
        -------
        pint.Quantity
            Required system head [m].
        """
        g = 9.81
        Qf = flow_rate.to("m**3/s").magnitude
        V = Qf / self.A if self.A > 0 else 0
        Re = self.rho * V * self.D / self.mu if self.mu > 0 else 0
        eD = self.eps / self.D if self.D > 0 else 0
        f = friction_factor(Re, eD) if Re > 0 else 0

        hf = f * (self.L / self.D) * (V**2 / (2 * g)) if self.D > 0 else 0
        hm = self.K_minor * V**2 / (2 * g)
        H_total = self.Hs + hf + hm

        return Q(H_total, "m")

    def system_curve(
        self,
        max_flow: pint.Quantity,
        n_points: int = 50,
    ) -> PumpResult:
        """Generate system curve data.

        Parameters
        ----------
        max_flow : pint.Quantity
            Maximum flow rate for curve.
        n_points : int
            Number of points.

        Returns
        -------
        PumpResult
            System curve data.
        """
        Qmax = max_flow.to("m**3/s").magnitude
        Q_vals = np.linspace(0, Qmax, n_points)

        heads = []
        for q in Q_vals:
            h = self.system_head(Q(q, "m**3/s"))
            heads.append(h)

        return PumpResult(
            flow_rates=[Q(q * 1000, "L/s") for q in Q_vals],
            system_heads=heads,
        )

    def find_operating_point(
        self,
        pump_Q: Sequence[pint.Quantity],
        pump_H: Sequence[pint.Quantity],
    ) -> PumpResult:
        """Find operating point where system and pump curves intersect.

        Parameters
        ----------
        pump_Q : list of pint.Quantity
            Pump curve flow rates.
        pump_H : list of pint.Quantity
            Pump curve heads.

        Returns
        -------
        PumpResult
            Results including operating point.
        """
        g = 9.81

        # Convert pump curve to SI
        pQ = np.array([q.to("m**3/s").magnitude for q in pump_Q])
        pH = np.array([h.to("m").magnitude for h in pump_H])

        # Calculate system heads at pump flow rates
        sH = []
        for q in pQ:
            h = self.system_head(Q(q, "m**3/s"))
            sH.append(h.magnitude)
        sH = np.array(sH)

        # Find intersection (where pump_H - system_H crosses zero)
        diff = pH - sH
        for i in range(len(diff) - 1):
            if diff[i] * diff[i + 1] <= 0:
                # Linear interpolation
                t = diff[i] / (diff[i] - diff[i + 1])
                Q_op = pQ[i] + t * (pQ[i + 1] - pQ[i])
                H_op = pH[i] + t * (pH[i + 1] - pH[i])

                power = self.rho * g * Q_op * H_op / self.eta

                return PumpResult(
                    flow_rates=[Q(q * 1000, "L/s") for q in pQ],
                    system_heads=[Q(h, "m") for h in sH],
                    operating_point_Q=Q(Q_op * 1000, "L/s"),
                    operating_point_H=Q(H_op, "m"),
                    power=Q(power / 1000, "kW"),
                )

        # No intersection found
        return PumpResult(
            flow_rates=[Q(q * 1000, "L/s") for q in pQ],
            system_heads=[Q(h, "m") for h in sH],
        )

    def npsh_available(
        self,
        atmospheric_pressure: pint.Quantity = Q(101325, "Pa"),
        vapor_pressure: pint.Quantity = Q(2339, "Pa"),
        suction_head: pint.Quantity = Q(3, "m"),
        suction_losses: pint.Quantity = Q(0.5, "m"),
    ) -> pint.Quantity:
        """Calculate Net Positive Suction Head Available.

        Parameters
        ----------
        atmospheric_pressure : pint.Quantity
            Atmospheric pressure [Pa].
        vapor_pressure : pint.Quantity
            Fluid vapor pressure at operating temperature [Pa].
        suction_head : pint.Quantity
            Suction-side elevation above fluid surface [m].
        suction_losses : pint.Quantity
            Friction losses in suction piping [m].

        Returns
        -------
        pint.Quantity
            NPSHa [m].

        Notes
        -----
        .. math:: NPSH_a = \\frac{p_{atm} - p_v}{\\rho g} - h_s - h_{f,s}
        """
        g = 9.81
        patm = atmospheric_pressure.to("Pa").magnitude
        pv = vapor_pressure.to("Pa").magnitude
        hs = suction_head.to("m").magnitude
        hfs = suction_losses.to("m").magnitude

        npsha = (patm - pv) / (self.rho * g) - hs - hfs
        return Q(npsha, "m")
