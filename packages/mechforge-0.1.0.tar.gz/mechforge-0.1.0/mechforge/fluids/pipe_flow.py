"""
Pipe Flow — Darcy-Weisbach, Moody Diagram, Minor Losses, Water Hammer.

Complete internal pipe flow analysis including friction factor
calculation (Colebrook-White & Swamee-Jain), Darcy-Weisbach pressure
drop, minor loss coefficients, and water hammer analysis.

References
----------
.. [1] Cengel & Cimbala, Fluid Mechanics, 4th Ed., Chapters 8-14
.. [2] Crane Technical Paper No. 410 — Flow of Fluids
.. [3] Moody, L.F. (1944), Trans. ASME, 66, 671-684
.. [4] Swamee & Jain (1976), J. Hydraulic Div., ASCE, 102(5), 657-664

Examples
--------
>>> from mechforge.fluids.pipe_flow import PipeFlow
>>> from mechforge.core.units import Q
>>> pipe = PipeFlow(
...     diameter=Q(100, 'mm'), length=Q(50, 'm'),
...     flow_rate=Q(10, 'L/s'), roughness=Q(0.045, 'mm'),
...     fluid_density=Q(998, 'kg/m**3'),
...     fluid_viscosity=Q(1.002e-3, 'Pa*s'),
... )
>>> result = pipe.analyze()
>>> print(f'Pressure drop: {result.pressure_drop.to("kPa"):.1f}')
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np
import pint

from mechforge.core.units import Q, ureg
from mechforge.core.exceptions import ConvergenceError, ValidationError


# ─── UTILITY FUNCTIONS ──────────────────────────────────────────────

def reynolds_number(
    velocity: pint.Quantity,
    diameter: pint.Quantity,
    density: pint.Quantity,
    viscosity: pint.Quantity,
) -> float:
    """Calculate Reynolds number.

    .. math:: Re = \\frac{\\rho V D}{\\mu}

    Parameters
    ----------
    velocity : pint.Quantity
        Flow velocity [m/s].
    diameter : pint.Quantity
        Pipe inner diameter [m].
    density : pint.Quantity
        Fluid density [kg/m³].
    viscosity : pint.Quantity
        Dynamic viscosity [Pa·s].

    Returns
    -------
    float
        Reynolds number (dimensionless).
    """
    V = velocity.to("m/s").magnitude
    D = diameter.to("m").magnitude
    rho = density.to("kg/m**3").magnitude
    mu = viscosity.to("Pa*s").magnitude
    return rho * V * D / mu


def friction_factor(
    Re: float,
    relative_roughness: float,
    method: str = "swamee_jain",
) -> float:
    """Calculate Darcy-Weisbach friction factor.

    Parameters
    ----------
    Re : float
        Reynolds number.
    relative_roughness : float
        ε/D ratio.
    method : str
        'colebrook' — iterative Colebrook-White equation.
        'swamee_jain' — explicit approximation (default).

    Returns
    -------
    float
        Darcy friction factor f.

    Notes
    -----
    Colebrook-White equation:

    .. math:: \\frac{1}{\\sqrt{f}} = -2 \\log\\left(
              \\frac{\\varepsilon/D}{3.7} + \\frac{2.51}{Re\\sqrt{f}}\\right)

    Swamee-Jain approximation:

    .. math:: f = \\frac{0.25}{\\left[\\log\\left(
              \\frac{\\varepsilon/D}{3.7} + \\frac{5.74}{Re^{0.9}}
              \\right)\\right]^2}

    References
    ----------
    .. [1] Colebrook (1939), J. ICE, 11(5), 133-156
    .. [2] Swamee & Jain (1976)
    """
    if Re < 2300:
        # Laminar flow
        return 64 / Re if Re > 0 else 0

    eD = relative_roughness

    if method == "swamee_jain":
        denom = np.log10(eD / 3.7 + 5.74 / Re**0.9)
        return 0.25 / denom**2

    elif method == "colebrook":
        # Iterative solution using fixed-point iteration
        f = 0.02  # Initial guess
        for _ in range(100):
            rhs = -2.0 * np.log10(eD / 3.7 + 2.51 / (Re * np.sqrt(f)))
            f_new = 1.0 / rhs**2
            if abs(f_new - f) < 1e-8:
                return f_new
            f = f_new
        raise ConvergenceError("Colebrook-White iteration did not converge")

    else:
        raise ValueError(f"Unknown method '{method}'. Use 'swamee_jain' or 'colebrook'.")


def pressure_drop(
    friction_factor_val: float,
    length: pint.Quantity,
    diameter: pint.Quantity,
    density: pint.Quantity,
    velocity: pint.Quantity,
) -> pint.Quantity:
    """Calculate Darcy-Weisbach pressure drop.

    .. math:: \\Delta p = f \\frac{L}{D} \\frac{\\rho V^2}{2}

    Parameters
    ----------
    friction_factor_val : float
        Darcy friction factor.
    length : pint.Quantity
        Pipe length [m].
    diameter : pint.Quantity
        Pipe inner diameter [m].
    density : pint.Quantity
        Fluid density [kg/m³].
    velocity : pint.Quantity
        Mean flow velocity [m/s].

    Returns
    -------
    pint.Quantity
        Pressure drop [Pa].
    """
    L = length.to("m").magnitude
    D = diameter.to("m").magnitude
    rho = density.to("kg/m**3").magnitude
    V = velocity.to("m/s").magnitude

    dp = friction_factor_val * (L / D) * (rho * V**2 / 2)
    return Q(dp, "Pa")


def water_hammer(
    velocity_change: pint.Quantity,
    density: pint.Quantity,
    bulk_modulus: pint.Quantity,
    diameter: pint.Quantity,
    wall_thickness: pint.Quantity,
    E_pipe: pint.Quantity,
) -> dict:
    """Calculate water hammer pressure rise.

    Parameters
    ----------
    velocity_change : pint.Quantity
        Change in velocity (e.g., from sudden valve closure) [m/s].
    density : pint.Quantity
        Fluid density [kg/m³].
    bulk_modulus : pint.Quantity
        Fluid bulk modulus [Pa].
    diameter : pint.Quantity
        Pipe inner diameter [m].
    wall_thickness : pint.Quantity
        Pipe wall thickness [m].
    E_pipe : pint.Quantity
        Pipe material elastic modulus [Pa].

    Returns
    -------
    dict
        {'wave_speed': Quantity, 'pressure_rise': Quantity}

    Notes
    -----
    Joukowsky equation:

    .. math:: \\Delta p = \\rho \\cdot a \\cdot \\Delta V

    Wave speed:

    .. math:: a = \\sqrt{\\frac{K/\\rho}{1 + (K D)/(E_p t)}}

    References
    ----------
    .. [1] Joukowsky (1898), J. Russian Chem. Soc.
    """
    dV = abs(velocity_change.to("m/s").magnitude)
    rho = density.to("kg/m**3").magnitude
    K = bulk_modulus.to("Pa").magnitude
    D = diameter.to("m").magnitude
    t = wall_thickness.to("m").magnitude
    Ep = E_pipe.to("Pa").magnitude

    # Wave speed
    a = np.sqrt((K / rho) / (1 + K * D / (Ep * t)))

    # Pressure rise (Joukowsky)
    dp = rho * a * dV

    return {
        "wave_speed": Q(a, "m/s"),
        "pressure_rise": Q(dp / 1e6, "MPa"),
    }


# ─── MINOR LOSS COEFFICIENTS ───────────────────────────────────────

# Standard K values for common fittings
MINOR_LOSS_K = {
    "elbow_90_standard": 0.9,
    "elbow_90_long_radius": 0.6,
    "elbow_45": 0.4,
    "tee_line": 0.2,
    "tee_branch": 1.0,
    "return_bend": 2.2,
    "gate_valve_full": 0.15,
    "gate_valve_half": 4.0,
    "globe_valve_full": 10.0,
    "check_valve_swing": 2.0,
    "check_valve_ball": 70.0,
    "butterfly_valve_full": 0.3,
    "entrance_sharp": 0.5,
    "entrance_well_rounded": 0.03,
    "entrance_reentrant": 0.8,
    "exit": 1.0,
    "sudden_expansion": 1.0,  # (1 - d²/D²)² applied separately
    "sudden_contraction": 0.5,  # (1 - d²/D²) applied separately
}


# ─── PIPE FLOW CLASS ───────────────────────────────────────────────

@dataclass
class PipeResult:
    """Pipe flow analysis results.

    Attributes
    ----------
    velocity : pint.Quantity
        Mean flow velocity [m/s].
    reynolds : float
        Reynolds number.
    flow_regime : str
        'laminar', 'transitional', or 'turbulent'.
    friction_factor : float
        Darcy friction factor.
    pressure_drop : pint.Quantity
        Total pressure drop [Pa].
    head_loss : pint.Quantity
        Total head loss [m].
    major_losses : pint.Quantity
        Friction (major) losses [Pa].
    minor_losses : pint.Quantity
        Fitting (minor) losses [Pa].
    power_required : pint.Quantity
        Pumping power required [W].
    """

    velocity: pint.Quantity
    reynolds: float
    flow_regime: str
    friction_factor: float
    pressure_drop: pint.Quantity
    head_loss: pint.Quantity
    major_losses: pint.Quantity
    minor_losses: pint.Quantity
    power_required: pint.Quantity

    def summary(self) -> str:
        """Return formatted summary."""
        return (
            f"=== Pipe Flow Analysis (Darcy-Weisbach) ===\n"
            f"  Velocity:           {self.velocity.to('m/s'):.3f}\n"
            f"  Reynolds Number:    {self.reynolds:.0f}\n"
            f"  Flow Regime:        {self.flow_regime}\n"
            f"  Friction Factor:    {self.friction_factor:.5f}\n"
            f"  Major Losses:       {self.major_losses.to('kPa'):.2f}\n"
            f"  Minor Losses:       {self.minor_losses.to('kPa'):.2f}\n"
            f"  Total Pressure Drop:{self.pressure_drop.to('kPa'):.2f}\n"
            f"  Head Loss:          {self.head_loss.to('m'):.3f}\n"
            f"  Pumping Power:      {self.power_required.to('W'):.1f}\n"
        )


class PipeFlow:
    """Complete pipe flow analysis.

    Parameters
    ----------
    diameter : pint.Quantity
        Pipe inner diameter [length].
    length : pint.Quantity
        Pipe length [length].
    flow_rate : pint.Quantity
        Volumetric flow rate [L/s or m³/s].
    roughness : pint.Quantity
        Surface roughness [length]. Default 0.045 mm (commercial steel).
    fluid_density : pint.Quantity
        Fluid density [kg/m³]. Default water at 20°C.
    fluid_viscosity : pint.Quantity
        Dynamic viscosity [Pa·s]. Default water at 20°C.
    fittings : dict[str, int], optional
        Dictionary of fitting names and counts, e.g. {'elbow_90_standard': 3}.
    elevation_change : pint.Quantity, optional
        Elevation change (positive = uphill) [m].
    """

    def __init__(
        self,
        diameter: pint.Quantity,
        length: pint.Quantity,
        flow_rate: pint.Quantity,
        roughness: pint.Quantity = Q(0.045, "mm"),
        fluid_density: pint.Quantity = Q(998, "kg/m**3"),
        fluid_viscosity: pint.Quantity = Q(1.002e-3, "Pa*s"),
        fittings: Optional[dict[str, int]] = None,
        elevation_change: Optional[pint.Quantity] = None,
    ) -> None:
        self.D = diameter.to("m").magnitude
        self.L = length.to("m").magnitude
        self.Qf = flow_rate.to("m**3/s").magnitude
        self.eps = roughness.to("m").magnitude
        self.rho = fluid_density.to("kg/m**3").magnitude
        self.mu = fluid_viscosity.to("Pa*s").magnitude
        self.fittings = fittings or {}
        self.dz = elevation_change.to("m").magnitude if elevation_change else 0

        # Derived
        self.A = np.pi / 4 * self.D**2
        self.V = self.Qf / self.A if self.A > 0 else 0

    def analyze(self) -> PipeResult:
        """Perform complete pipe flow analysis.

        Returns
        -------
        PipeResult
            Full analysis results including losses and power.
        """
        g = 9.81  # m/s²

        # Reynolds number
        Re = self.rho * self.V * self.D / self.mu if self.mu > 0 else 0

        # Flow regime
        if Re < 2300:
            regime = "laminar"
        elif Re < 4000:
            regime = "transitional"
        else:
            regime = "turbulent"

        # Friction factor
        eD = self.eps / self.D if self.D > 0 else 0
        f = friction_factor(Re, eD) if Re > 0 else 0

        # Major (friction) losses
        dp_major = f * (self.L / self.D) * (self.rho * self.V**2 / 2) if self.D > 0 else 0

        # Minor losses
        K_total = sum(
            MINOR_LOSS_K.get(name, 0) * count
            for name, count in self.fittings.items()
        )
        dp_minor = K_total * (self.rho * self.V**2 / 2)

        # Elevation
        dp_elev = self.rho * g * self.dz

        # Total
        dp_total = dp_major + dp_minor + dp_elev
        h_loss = dp_total / (self.rho * g) if self.rho > 0 else 0

        # Pumping power
        power = dp_total * self.Qf  # W

        return PipeResult(
            velocity=Q(self.V, "m/s"),
            reynolds=Re,
            flow_regime=regime,
            friction_factor=f,
            pressure_drop=Q(dp_total, "Pa"),
            head_loss=Q(h_loss, "m"),
            major_losses=Q(dp_major, "Pa"),
            minor_losses=Q(dp_minor, "Pa"),
            power_required=Q(abs(power), "W"),
        )
