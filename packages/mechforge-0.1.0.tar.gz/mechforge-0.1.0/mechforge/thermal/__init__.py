"""
MechForge Thermal Module.

Covers thermodynamic cycles, heat transfer analysis, and heat
exchanger design.
"""

from __future__ import annotations

from mechforge.thermal.cycles import (
    RankineCycle,
    BraytonCycle,
    OttoCycle,
    DieselCycle,
    CycleResult,
)
from mechforge.thermal.heat_transfer import (
    conduction_resistance,
    convection_resistance,
    radiation_heat_flux,
    fin_efficiency,
    overall_heat_transfer,
    HeatTransferResult,
)
from mechforge.thermal.heat_exchangers import (
    HeatExchanger,
    HeatExchangerResult,
)

__all__ = [
    "RankineCycle",
    "BraytonCycle",
    "OttoCycle",
    "DieselCycle",
    "CycleResult",
    "conduction_resistance",
    "convection_resistance",
    "radiation_heat_flux",
    "fin_efficiency",
    "overall_heat_transfer",
    "HeatTransferResult",
    "HeatExchanger",
    "HeatExchangerResult",
]
