"""
Heat Transfer — Conduction, Convection, Radiation, Fins.

Complete heat transfer analysis including multi-layer conduction,
convection correlations, radiation exchange, fin efficiency, and
overall heat transfer coefficient.

References
----------
.. [1] Incropera et al., Fundamentals of Heat and Mass Transfer, 8th Ed.
.. [2] Cengel, Heat Transfer: A Practical Approach, 6th Ed.
.. [3] Mills, Heat Transfer, 2nd Ed.

Examples
--------
>>> from mechforge.thermal.heat_transfer import conduction_resistance
>>> from mechforge.core.units import Q
>>> R = conduction_resistance(
...     thickness=Q(10, 'mm'), area=Q(1, 'm**2'),
...     conductivity=Q(50, 'W/(m*K)'),
... )
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np
import pint

from mechforge.core.units import Q, ureg


@dataclass
class HeatTransferResult:
    """Heat transfer analysis result."""

    heat_flux: pint.Quantity  # W/m² or W
    resistance: pint.Quantity  # K/W
    U: Optional[pint.Quantity] = None  # Overall HTC [W/(m²·K)]
    temperatures: Optional[dict] = None

    def summary(self) -> str:
        """Return formatted summary."""
        lines = [
            "=== Heat Transfer Analysis ===",
            f"  Heat Flux:    {self.heat_flux:.3f}",
            f"  Resistance:   {self.resistance:.5f}",
        ]
        if self.U is not None:
            lines.append(f"  Overall U:    {self.U:.2f}")
        return "\n".join(lines) + "\n"


# ─── RESISTANCE CALCULATIONS ────────────────────────────────────────

def conduction_resistance(
    thickness: pint.Quantity,
    area: pint.Quantity,
    conductivity: pint.Quantity,
    geometry: str = "plane",
    r_inner: Optional[pint.Quantity] = None,
    r_outer: Optional[pint.Quantity] = None,
    length: Optional[pint.Quantity] = None,
) -> pint.Quantity:
    """Calculate conduction thermal resistance.

    Parameters
    ----------
    thickness : pint.Quantity
        Wall thickness (for plane wall) [m].
    area : pint.Quantity
        Heat transfer area (for plane wall) [m²].
    conductivity : pint.Quantity
        Thermal conductivity [W/(m·K)].
    geometry : str
        'plane' (default), 'cylindrical', or 'spherical'.
    r_inner, r_outer : pint.Quantity
        Inner/outer radii for cylindrical/spherical.
    length : pint.Quantity
        Cylinder length for cylindrical geometry.

    Returns
    -------
    pint.Quantity
        Thermal resistance [K/W].

    Notes
    -----
    Plane wall: :math:`R = L/(kA)`

    Cylindrical: :math:`R = \\ln(r_o/r_i)/(2\\pi k L)`

    Spherical: :math:`R = (1/r_i - 1/r_o)/(4\\pi k)`
    """
    k = conductivity.to("W/(m*K)").magnitude

    if geometry == "plane":
        L = thickness.to("m").magnitude
        A = area.to("m**2").magnitude
        R = L / (k * A) if k * A > 0 else float("inf")

    elif geometry == "cylindrical":
        ri = r_inner.to("m").magnitude
        ro = r_outer.to("m").magnitude
        Lc = length.to("m").magnitude
        R = np.log(ro / ri) / (2 * np.pi * k * Lc) if k * Lc > 0 else float("inf")

    elif geometry == "spherical":
        ri = r_inner.to("m").magnitude
        ro = r_outer.to("m").magnitude
        R = (1 / ri - 1 / ro) / (4 * np.pi * k) if k > 0 else float("inf")

    else:
        raise ValueError(f"Unknown geometry '{geometry}'")

    return Q(R, "K/W")


def convection_resistance(
    h: pint.Quantity,
    area: pint.Quantity,
) -> pint.Quantity:
    """Calculate convection thermal resistance.

    Parameters
    ----------
    h : pint.Quantity
        Convection heat transfer coefficient [W/(m²·K)].
    area : pint.Quantity
        Surface area [m²].

    Returns
    -------
    pint.Quantity
        Thermal resistance [K/W].

    Notes
    -----
    .. math:: R_{conv} = \\frac{1}{hA}
    """
    h_val = h.to("W/(m**2*K)").magnitude
    A = area.to("m**2").magnitude
    R = 1 / (h_val * A) if h_val * A > 0 else float("inf")
    return Q(R, "K/W")


def radiation_heat_flux(
    T_surface: pint.Quantity,
    T_surround: pint.Quantity,
    emissivity: float = 1.0,
) -> pint.Quantity:
    """Calculate radiation heat flux.

    Parameters
    ----------
    T_surface : pint.Quantity
        Surface temperature [K].
    T_surround : pint.Quantity
        Surrounding temperature [K].
    emissivity : float
        Surface emissivity (0-1).

    Returns
    -------
    pint.Quantity
        Radiation heat flux [W/m²].

    Notes
    -----
    .. math:: q'' = \\varepsilon \\sigma (T_s^4 - T_{surr}^4)
    """
    sigma = 5.67e-8  # Stefan-Boltzmann constant
    Ts = T_surface.to("K").magnitude
    Tsurr = T_surround.to("K").magnitude
    q = emissivity * sigma * (Ts**4 - Tsurr**4)
    return Q(q, "W/m**2")


# ─── FIN ANALYSIS ────────────────────────────────────────────────────

def fin_efficiency(
    fin_type: str = "rectangular",
    length: pint.Quantity = Q(30, "mm"),
    thickness: pint.Quantity = Q(2, "mm"),
    h: pint.Quantity = Q(50, "W/(m**2*K)"),
    k: pint.Quantity = Q(200, "W/(m*K)"),
    diameter: Optional[pint.Quantity] = None,
) -> dict:
    """Calculate fin efficiency.

    Parameters
    ----------
    fin_type : str
        'rectangular', 'triangular', 'pin' (cylindrical pin fin).
    length : pint.Quantity
        Fin length from base to tip [m].
    thickness : pint.Quantity
        Fin thickness [m] (for rectangular).
    h : pint.Quantity
        Convection coefficient [W/(m²·K)].
    k : pint.Quantity
        Fin thermal conductivity [W/(m·K)].
    diameter : pint.Quantity, optional
        Pin fin diameter.

    Returns
    -------
    dict
        {'efficiency': float, 'mL': float, 'effectiveness': float}

    Notes
    -----
    Rectangular fin with insulated tip:

    .. math:: \\eta_f = \\frac{\\tanh(mL)}{mL}

    Where :math:`m = \\sqrt{2h/(kt)}`

    References
    ----------
    .. [1] Incropera, Chapter 3
    """
    L = length.to("m").magnitude
    h_val = h.to("W/(m**2*K)").magnitude
    k_val = k.to("W/(m*K)").magnitude

    if fin_type == "rectangular":
        t = thickness.to("m").magnitude
        P = 2 * (1 + t)  # Perimeter per unit width (approx 2 for thin fin)
        Ac = t  # Cross-section area per unit width
        m = np.sqrt(2 * h_val / (k_val * t))

    elif fin_type == "pin":
        d = diameter.to("m").magnitude if diameter else 0.005
        m = np.sqrt(4 * h_val / (k_val * d))

    elif fin_type == "triangular":
        t = thickness.to("m").magnitude
        m = np.sqrt(2 * h_val / (k_val * t))

    else:
        raise ValueError(f"Unknown fin type '{fin_type}'")

    mL = m * L
    if mL > 0:
        eta = np.tanh(mL) / mL
    else:
        eta = 1.0

    return {
        "efficiency": eta,
        "mL": mL,
        "m": m,
    }


# ─── OVERALL HEAT TRANSFER ──────────────────────────────────────────

def overall_heat_transfer(
    layers: Sequence[dict],
    h_inner: pint.Quantity,
    h_outer: pint.Quantity,
    area: pint.Quantity,
    T_hot: pint.Quantity,
    T_cold: pint.Quantity,
) -> HeatTransferResult:
    """Calculate overall heat transfer through composite wall.

    Parameters
    ----------
    layers : list of dict
        Each dict: {'thickness': Quantity, 'conductivity': Quantity}
    h_inner : pint.Quantity
        Inner convection coefficient.
    h_outer : pint.Quantity
        Outer convection coefficient.
    area : pint.Quantity
        Heat transfer area.
    T_hot : pint.Quantity
        Hot fluid temperature.
    T_cold : pint.Quantity
        Cold fluid temperature.

    Returns
    -------
    HeatTransferResult
        Overall heat transfer results.
    """
    A = area.to("m**2").magnitude

    # Convection resistances
    R_total = 1 / (h_inner.to("W/(m**2*K)").magnitude * A)
    R_total += 1 / (h_outer.to("W/(m**2*K)").magnitude * A)

    # Conduction resistances
    for layer in layers:
        L = layer["thickness"].to("m").magnitude
        k = layer["conductivity"].to("W/(m*K)").magnitude
        R_total += L / (k * A)

    # Overall HTC
    U = 1 / (R_total * A) if R_total * A > 0 else 0

    # Heat transfer
    dT = T_hot.to("K").magnitude - T_cold.to("K").magnitude
    Q_val = dT / R_total if R_total > 0 else 0

    return HeatTransferResult(
        heat_flux=Q(Q_val, "W"),
        resistance=Q(R_total, "K/W"),
        U=Q(U, "W/(m**2*K)"),
    )
