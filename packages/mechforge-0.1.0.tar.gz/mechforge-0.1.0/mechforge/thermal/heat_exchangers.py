"""
Heat Exchangers — LMTD, NTU-ε Methods, Shell & Tube, Plate.

Complete heat exchanger design and rating using both LMTD and
Effectiveness-NTU methods. Supports counterflow, parallel flow,
shell-and-tube, and crossflow configurations.

References
----------
.. [1] Incropera et al., Fundamentals of Heat and Mass Transfer, Ch. 11
.. [2] Shah & Sekulic, Fundamentals of Heat Exchanger Design
.. [3] TEMA Standards (Tubular Exchanger Manufacturers Association)
.. [4] Kays & London, Compact Heat Exchangers, 3rd Ed.

Examples
--------
>>> from mechforge.thermal.heat_exchangers import HeatExchanger
>>> from mechforge.core.units import Q
>>> hx = HeatExchanger(
...     type='counterflow',
...     Th_in=Q(150, 'degC'), Th_out=Q(90, 'degC'),
...     Tc_in=Q(20, 'degC'), Tc_out=Q(60, 'degC'),
...     U=Q(500, 'W/(m**2*K)'), Q_duty=Q(100, 'kW'),
... )
>>> result = hx.design_LMTD()
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pint

from mechforge.core.units import Q, ureg
from mechforge.core.exceptions import ValidationError


@dataclass
class HeatExchangerResult:
    """Heat exchanger analysis results.

    Attributes
    ----------
    method : str
        'LMTD' or 'NTU-epsilon'.
    area : pint.Quantity
        Required heat transfer area [m²].
    LMTD : pint.Quantity, optional
        Log mean temperature difference [K].
    effectiveness : float, optional
        Heat exchanger effectiveness (0-1).
    NTU : float, optional
        Number of transfer units.
    Q_duty : pint.Quantity
        Heat duty [W or kW].
    F_correction : float
        LMTD correction factor (1.0 for counter/parallel flow).
    """

    method: str
    area: pint.Quantity
    LMTD: Optional[pint.Quantity] = None
    effectiveness: Optional[float] = None
    NTU: Optional[float] = None
    Q_duty: Optional[pint.Quantity] = None
    F_correction: float = 1.0

    def summary(self) -> str:
        """Return formatted summary."""
        lines = [
            f"=== Heat Exchanger Design ({self.method}) ===",
            f"  Heat Duty:        {self.Q_duty.to('kW'):.2f}" if self.Q_duty else "",
            f"  Required Area:    {self.area.to('m**2'):.3f}",
        ]
        if self.LMTD is not None:
            lines.append(f"  LMTD:             {self.LMTD.to('K'):.2f}")
        if self.effectiveness is not None:
            lines.append(f"  Effectiveness:    {self.effectiveness:.3f}")
        if self.NTU is not None:
            lines.append(f"  NTU:              {self.NTU:.3f}")
        lines.append(f"  F Correction:     {self.F_correction:.3f}")
        return "\n".join([l for l in lines if l]) + "\n"


class HeatExchanger:
    """Heat exchanger design and rating.

    Parameters
    ----------
    type : str
        'counterflow', 'parallel', 'shell_tube_1_2', 'crossflow_mixed',
        'crossflow_unmixed'.
    Th_in : pint.Quantity
        Hot fluid inlet temperature.
    Th_out : pint.Quantity, optional
        Hot fluid outlet temperature.
    Tc_in : pint.Quantity
        Cold fluid inlet temperature.
    Tc_out : pint.Quantity, optional
        Cold fluid outlet temperature.
    U : pint.Quantity
        Overall heat transfer coefficient [W/(m²·K)].
    Q_duty : pint.Quantity, optional
        Heat duty [W or kW].
    mh_cp : pint.Quantity, optional
        Hot fluid capacity rate (ṁ·cp) [W/K].
    mc_cp : pint.Quantity, optional
        Cold fluid capacity rate (ṁ·cp) [W/K].
    """

    def __init__(
        self,
        type: str = "counterflow",
        Th_in: pint.Quantity = Q(150, "degC"),
        Th_out: Optional[pint.Quantity] = None,
        Tc_in: pint.Quantity = Q(20, "degC"),
        Tc_out: Optional[pint.Quantity] = None,
        U: pint.Quantity = Q(500, "W/(m**2*K)"),
        Q_duty: Optional[pint.Quantity] = None,
        mh_cp: Optional[pint.Quantity] = None,
        mc_cp: Optional[pint.Quantity] = None,
    ) -> None:
        self.type = type
        self.Th_in = Th_in.to("K").magnitude
        self.Th_out = Th_out.to("K").magnitude if Th_out is not None else None
        self.Tc_in = Tc_in.to("K").magnitude
        self.Tc_out = Tc_out.to("K").magnitude if Tc_out is not None else None
        self.U = U.to("W/(m**2*K)").magnitude
        self.Q = Q_duty.to("W").magnitude if Q_duty is not None else None
        self.Ch = mh_cp.to("W/K").magnitude if mh_cp is not None else None
        self.Cc = mc_cp.to("W/K").magnitude if mc_cp is not None else None

    def design_LMTD(self) -> HeatExchangerResult:
        """Design using LMTD method.

        Returns
        -------
        HeatExchangerResult
            Design results including required area.

        Notes
        -----
        .. math:: Q = U A F \\Delta T_{lm}

        For counterflow:

        .. math:: \\Delta T_{lm} = \\frac{\\Delta T_1 - \\Delta T_2}
                  {\\ln(\\Delta T_1 / \\Delta T_2)}
        """
        if self.Th_out is None or self.Tc_out is None:
            raise ValidationError("LMTD method requires all four temperatures.")

        # Temperature differences
        if self.type == "parallel":
            dT1 = self.Th_in - self.Tc_in
            dT2 = self.Th_out - self.Tc_out
        else:
            # Counterflow (and as basis for correction)
            dT1 = self.Th_in - self.Tc_out
            dT2 = self.Th_out - self.Tc_in

        # LMTD
        if abs(dT1 - dT2) < 0.01:
            LMTD = dT1  # Equal — avoid log(1)
        elif dT1 <= 0 or dT2 <= 0:
            raise ValidationError("Temperature cross detected — invalid HX design.")
        else:
            LMTD = (dT1 - dT2) / np.log(dT1 / dT2)

        # Correction factor F
        F = self._correction_factor()

        # Heat duty
        if self.Q is not None:
            Q_val = self.Q
        else:
            # Estimate from capacity rates
            if self.Ch is not None:
                Q_val = self.Ch * (self.Th_in - self.Th_out)
            elif self.Cc is not None:
                Q_val = self.Cc * (self.Tc_out - self.Tc_in)
            else:
                raise ValidationError("Need Q_duty or capacity rates.")

        # Required area
        A = Q_val / (self.U * F * LMTD) if self.U * F * LMTD > 0 else float("inf")

        return HeatExchangerResult(
            method="LMTD",
            area=Q(A, "m**2"),
            LMTD=Q(LMTD, "K"),
            Q_duty=Q(Q_val / 1000, "kW"),
            F_correction=F,
        )

    def design_NTU(self) -> HeatExchangerResult:
        """Design or rate using NTU-effectiveness method.

        Returns
        -------
        HeatExchangerResult
            Design results.

        Notes
        -----
        .. math:: \\varepsilon = \\frac{Q}{Q_{max}}
                  = \\frac{Q}{C_{min}(T_{h,in} - T_{c,in})}

        .. math:: NTU = \\frac{UA}{C_{min}}
        """
        if self.Ch is None or self.Cc is None:
            raise ValidationError("NTU method requires capacity rates (mh_cp, mc_cp).")

        Cmin = min(self.Ch, self.Cc)
        Cmax = max(self.Ch, self.Cc)
        Cr = Cmin / Cmax if Cmax > 0 else 0

        # Maximum heat transfer
        Q_max = Cmin * (self.Th_in - self.Tc_in)

        # Effectiveness
        if self.Q is not None:
            eps = self.Q / Q_max if Q_max > 0 else 0
        elif self.Th_out is not None:
            eps = self.Ch * (self.Th_in - self.Th_out) / Q_max if Q_max > 0 else 0
        elif self.Tc_out is not None:
            eps = self.Cc * (self.Tc_out - self.Tc_in) / Q_max if Q_max > 0 else 0
        else:
            raise ValidationError("Need Q_duty or outlet temperatures for NTU method.")

        # NTU from effectiveness
        NTU = self._NTU_from_effectiveness(eps, Cr)

        # Required area
        A = NTU * Cmin / self.U if self.U > 0 else float("inf")

        Q_val = eps * Q_max

        return HeatExchangerResult(
            method="NTU-epsilon",
            area=Q(A, "m**2"),
            effectiveness=eps,
            NTU=NTU,
            Q_duty=Q(Q_val / 1000, "kW"),
        )

    def _correction_factor(self) -> float:
        """LMTD correction factor F for multi-pass configurations."""
        if self.type in ("counterflow", "parallel"):
            return 1.0

        if self.Th_out is None or self.Tc_out is None:
            return 1.0

        # For shell-and-tube (1 shell pass, 2+ tube passes)
        R = (self.Th_in - self.Th_out) / (self.Tc_out - self.Tc_in) if (self.Tc_out - self.Tc_in) > 0 else 1
        P = (self.Tc_out - self.Tc_in) / (self.Th_in - self.Tc_in) if (self.Th_in - self.Tc_in) > 0 else 0

        if abs(R - 1) < 0.01:
            # Special case R = 1
            F = (P * np.sqrt(2)) / ((1 - P) * np.log((2 - P * (2 - np.sqrt(2))) / (2 - P * (2 + np.sqrt(2))))) if P < 1 else 0.5
            return max(F, 0.5)

        sqrt_term = np.sqrt(R**2 + 1)
        numer = sqrt_term * np.log((1 - P) / (1 - R * P)) if (1 - R * P) > 0 else 0
        denom = (R - 1) * np.log(
            (2 - P * (R + 1 - sqrt_term)) / (2 - P * (R + 1 + sqrt_term))
        ) if (R - 1) != 0 else 1

        F = numer / denom if denom != 0 else 1.0
        return max(min(F, 1.0), 0.5)

    def _NTU_from_effectiveness(self, eps: float, Cr: float) -> float:
        """Calculate NTU from effectiveness and capacity ratio."""
        if eps >= 1:
            return float("inf")
        if eps <= 0:
            return 0

        if self.type == "counterflow":
            if abs(Cr - 1) < 0.01:
                NTU = eps / (1 - eps)
            else:
                NTU = (1 / (Cr - 1)) * np.log((eps - 1) / (eps * Cr - 1))
        elif self.type == "parallel":
            NTU = -np.log(1 - eps * (1 + Cr)) / (1 + Cr) if (1 + Cr) > 0 else 0
        else:
            # Generic — use counterflow approximation
            if abs(Cr - 1) < 0.01:
                NTU = eps / (1 - eps)
            else:
                NTU = (1 / (Cr - 1)) * np.log((eps - 1) / (eps * Cr - 1))

        return abs(NTU)
