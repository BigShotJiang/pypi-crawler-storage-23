"""
Thermodynamic Cycles — Rankine, Brayton, Otto, Diesel.

Ideal and modified power & refrigeration cycle analysis with full
state-point tracking, efficiency calculations, and back-work ratio.

References
----------
.. [1] Cengel & Boles, Thermodynamics, 9th Ed.
.. [2] Moran et al., Fundamentals of Engineering Thermodynamics, 9th Ed.
.. [3] Smith, Van Ness & Abbott, Introduction to Chemical Engineering
       Thermodynamics, 8th Ed.

Examples
--------
>>> from mechforge.thermal.cycles import RankineCycle
>>> from mechforge.core.units import Q
>>> cycle = RankineCycle(
...     boiler_pressure=Q(10, 'MPa'),
...     condenser_pressure=Q(10, 'kPa'),
...     turbine_efficiency=0.85,
...     pump_efficiency=0.80,
... )
>>> result = cycle.analyze()
>>> print(f'Thermal efficiency: {result.efficiency*100:.1f}%')
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pint

from mechforge.core.units import Q, ureg


@dataclass
class CycleResult:
    """Thermodynamic cycle analysis results.

    Attributes
    ----------
    cycle_name : str
        Name of the cycle.
    efficiency : float
        Thermal efficiency (0-1).
    net_work : pint.Quantity
        Net work output per unit mass [kJ/kg].
    heat_input : pint.Quantity
        Heat input per unit mass [kJ/kg].
    heat_rejected : pint.Quantity
        Heat rejected per unit mass [kJ/kg].
    back_work_ratio : float
        Ratio of compressor/pump work to turbine/expansion work.
    mep : pint.Quantity, optional
        Mean effective pressure (for reciprocating cycles).
    specific_power : pint.Quantity, optional
        Specific power output [kW/(kg/s)].
    state_points : dict
        State points with temperature, pressure, and other properties.
    """

    cycle_name: str
    efficiency: float
    net_work: pint.Quantity
    heat_input: pint.Quantity
    heat_rejected: pint.Quantity
    back_work_ratio: float
    mep: Optional[pint.Quantity] = None
    specific_power: Optional[pint.Quantity] = None
    state_points: dict = field(default_factory=dict)

    def summary(self) -> str:
        """Return formatted summary."""
        lines = [
            f"=== {self.cycle_name} Cycle Analysis ===",
            f"  Thermal Efficiency: {self.efficiency * 100:.2f} %",
            f"  Net Work Output:    {self.net_work.to('kJ/kg'):.1f}",
            f"  Heat Input:         {self.heat_input.to('kJ/kg'):.1f}",
            f"  Heat Rejected:      {self.heat_rejected.to('kJ/kg'):.1f}",
            f"  Back-Work Ratio:    {self.back_work_ratio:.3f}",
        ]
        if self.mep is not None:
            lines.append(f"  Mean Eff. Pressure: {self.mep.to('kPa'):.1f}")
        if self.specific_power is not None:
            lines.append(f"  Specific Power:     {self.specific_power.to('kW*s/kg'):.1f}")
        return "\n".join(lines) + "\n"


class RankineCycle:
    """Ideal and real Rankine (steam power) cycle analysis.

    Parameters
    ----------
    boiler_pressure : pint.Quantity
        Boiler / turbine inlet pressure [Pa or MPa].
    condenser_pressure : pint.Quantity
        Condenser pressure [Pa or kPa].
    turbine_efficiency : float
        Isentropic turbine efficiency (0-1). Default 1.0 (ideal).
    pump_efficiency : float
        Isentropic pump efficiency (0-1). Default 1.0 (ideal).
    superheat_temp : pint.Quantity, optional
        Superheated steam temperature at turbine inlet [°C].
        If not given, uses saturated vapor at boiler pressure.

    Notes
    -----
    Uses approximate steam properties based on simplified correlations.
    For production use, integrate with CoolProp or IAPWS-IF97.

    Ideal Rankine cycle processes:
    1-2: Isentropic compression (pump)
    2-3: Constant pressure heat addition (boiler)
    3-4: Isentropic expansion (turbine)
    4-1: Constant pressure heat rejection (condenser)

    Thermal efficiency:

    .. math:: \\eta_{th} = 1 - \\frac{q_{out}}{q_{in}}
              = \\frac{w_{net}}{q_{in}}
    """

    def __init__(
        self,
        boiler_pressure: pint.Quantity = Q(10, "MPa"),
        condenser_pressure: pint.Quantity = Q(10, "kPa"),
        turbine_efficiency: float = 1.0,
        pump_efficiency: float = 1.0,
        superheat_temp: Optional[pint.Quantity] = None,
    ) -> None:
        self.p_boiler = boiler_pressure.to("kPa").magnitude  # kPa
        self.p_cond = condenser_pressure.to("kPa").magnitude
        self.eta_t = turbine_efficiency
        self.eta_p = pump_efficiency
        self.T_sh = superheat_temp.to("degC").magnitude if superheat_temp else None

    def analyze(self) -> CycleResult:
        """Analyze Rankine cycle.

        Returns
        -------
        CycleResult
            Cycle analysis results with efficiency and work values.
        """
        # Approximate steam properties using simplified correlations
        # (Antoine equation for saturation temperature)
        T_sat_boiler = self._sat_temp(self.p_boiler)  # °C
        T_sat_cond = self._sat_temp(self.p_cond)

        # Approximate enthalpies (kJ/kg) using simplified steam tables
        hf_cond = 4.18 * T_sat_cond  # Saturated liquid at condenser
        hfg_cond = 2500 - 2.4 * T_sat_cond  # Approx latent heat

        hf_boiler = 4.18 * T_sat_boiler
        hfg_boiler = 2500 - 2.4 * T_sat_boiler

        # State 1: Saturated liquid at condenser pressure
        h1 = hf_cond
        vf = 0.001  # Approx specific volume of liquid [m³/kg]

        # State 2: Compressed liquid (after pump)
        w_pump_ideal = vf * (self.p_boiler - self.p_cond)  # kJ/kg
        w_pump = w_pump_ideal / self.eta_p if self.eta_p > 0 else 0
        h2 = h1 + w_pump

        # State 3: Superheated or saturated vapor at boiler pressure
        if self.T_sh is not None:
            # Superheated: h ≈ hg + cp_steam * (T - T_sat)
            hg_boiler = hf_boiler + hfg_boiler
            h3 = hg_boiler + 2.0 * (self.T_sh - T_sat_boiler)
        else:
            h3 = hf_boiler + hfg_boiler  # Saturated vapor

        # State 4: Wet mixture at condenser pressure (after turbine)
        w_turbine_ideal = h3 - (hf_cond + 0.85 * hfg_cond)  # Rough ideal expansion
        w_turbine = w_turbine_ideal * self.eta_t
        h4 = h3 - w_turbine

        # Cycle calculations
        q_in = h3 - h2
        q_out = h4 - h1
        w_net = q_in - q_out

        efficiency = w_net / q_in if q_in > 0 else 0
        bwr = w_pump / w_turbine if w_turbine > 0 else 0

        return CycleResult(
            cycle_name="Rankine",
            efficiency=max(efficiency, 0),
            net_work=Q(w_net, "kJ/kg"),
            heat_input=Q(q_in, "kJ/kg"),
            heat_rejected=Q(abs(q_out), "kJ/kg"),
            back_work_ratio=bwr,
            state_points={
                "1": {"T": T_sat_cond, "p": self.p_cond, "h": h1},
                "2": {"T": T_sat_cond + 1, "p": self.p_boiler, "h": h2},
                "3": {"T": self.T_sh or T_sat_boiler, "p": self.p_boiler, "h": h3},
                "4": {"T": T_sat_cond, "p": self.p_cond, "h": h4},
            },
        )

    @staticmethod
    def _sat_temp(p_kPa: float) -> float:
        """Approximate saturation temperature from pressure (simplified)."""
        # Simplified Antoine equation for water
        if p_kPa <= 0:
            return 0
        return 100 * (p_kPa / 101.325) ** 0.25


class BraytonCycle:
    """Ideal and real Brayton (gas turbine) cycle analysis.

    Parameters
    ----------
    pressure_ratio : float
        Compressor pressure ratio.
    T_inlet : pint.Quantity
        Compressor inlet temperature [°C or K].
    T_max : pint.Quantity
        Turbine inlet temperature [°C or K].
    compressor_efficiency : float
        Isentropic compressor efficiency.
    turbine_efficiency : float
        Isentropic turbine efficiency.
    gamma : float
        Ratio of specific heats for working fluid.
    cp : float
        Specific heat at constant pressure [kJ/(kg·K)].
    regenerator : bool
        Whether cycle includes regeneration.
    regenerator_effectiveness : float
        Regenerator effectiveness (0-1).
    """

    def __init__(
        self,
        pressure_ratio: float = 10,
        T_inlet: pint.Quantity = Q(300, "K"),
        T_max: pint.Quantity = Q(1400, "K"),
        compressor_efficiency: float = 1.0,
        turbine_efficiency: float = 1.0,
        gamma: float = 1.4,
        cp: float = 1.005,
        regenerator: bool = False,
        regenerator_effectiveness: float = 0.80,
    ) -> None:
        self.rp = pressure_ratio
        self.T1 = T_inlet.to("K").magnitude
        self.T3 = T_max.to("K").magnitude
        self.eta_c = compressor_efficiency
        self.eta_t = turbine_efficiency
        self.gamma = gamma
        self.cp = cp  # kJ/(kg·K)
        self.regen = regenerator
        self.eps_regen = regenerator_effectiveness

    def analyze(self) -> CycleResult:
        """Analyze Brayton cycle."""
        g = self.gamma
        rp = self.rp
        T1 = self.T1
        T3 = self.T3
        cp = self.cp

        # Isentropic temperature ratio
        T2s_T1 = rp ** ((g - 1) / g)

        # State 2 (after compressor)
        T2s = T1 * T2s_T1  # Ideal
        T2 = T1 + (T2s - T1) / self.eta_c  # Real

        # State 4 (after turbine)
        T4s = T3 / T2s_T1  # Ideal
        T4 = T3 - self.eta_t * (T3 - T4s)  # Real

        # Work
        w_comp = cp * (T2 - T1)
        w_turb = cp * (T3 - T4)
        w_net = w_turb - w_comp

        # Heat input
        if self.regen:
            # With regenerator: preheated air from T2 towards T4
            T_preheat = T2 + self.eps_regen * (T4 - T2)
            q_in = cp * (T3 - T_preheat)
        else:
            q_in = cp * (T3 - T2)

        q_out = q_in - w_net
        efficiency = w_net / q_in if q_in > 0 else 0
        bwr = w_comp / w_turb if w_turb > 0 else 0

        return CycleResult(
            cycle_name="Brayton" + (" (Regenerative)" if self.regen else ""),
            efficiency=max(efficiency, 0),
            net_work=Q(w_net, "kJ/kg"),
            heat_input=Q(q_in, "kJ/kg"),
            heat_rejected=Q(abs(q_out), "kJ/kg"),
            back_work_ratio=bwr,
            state_points={
                "1": {"T": T1, "p_ratio": 1},
                "2": {"T": T2, "p_ratio": rp},
                "3": {"T": T3, "p_ratio": rp},
                "4": {"T": T4, "p_ratio": 1},
            },
        )


class OttoCycle:
    """Ideal Otto (spark-ignition) cycle analysis.

    Parameters
    ----------
    compression_ratio : float
        Volume compression ratio r = V1/V2.
    T_initial : pint.Quantity
        Initial temperature [K].
    p_initial : pint.Quantity
        Initial pressure [kPa].
    q_in : pint.Quantity
        Heat input per unit mass [kJ/kg].
    gamma : float
        Ratio of specific heats.
    cv : float
        Specific heat at constant volume [kJ/(kg·K)].
    """

    def __init__(
        self,
        compression_ratio: float = 8,
        T_initial: pint.Quantity = Q(300, "K"),
        p_initial: pint.Quantity = Q(100, "kPa"),
        q_in: pint.Quantity = Q(800, "kJ/kg"),
        gamma: float = 1.4,
        cv: float = 0.718,
    ) -> None:
        self.r = compression_ratio
        self.T1 = T_initial.to("K").magnitude
        self.p1 = p_initial.to("kPa").magnitude
        self.q_in = q_in.to("kJ/kg").magnitude
        self.gamma = gamma
        self.cv = cv

    def analyze(self) -> CycleResult:
        """Analyze Otto cycle."""
        r = self.r
        g = self.gamma
        cv = self.cv
        T1 = self.T1

        # Air-standard Otto cycle efficiency
        eta = 1 - 1 / r ** (g - 1)

        # State points
        T2 = T1 * r ** (g - 1)  # After isentropic compression
        T3 = T2 + self.q_in / cv  # After constant-V heat addition
        T4 = T3 / r ** (g - 1)  # After isentropic expansion

        w_net = self.q_in * eta
        q_out = self.q_in - w_net

        # Mean effective pressure
        R_air = 0.287  # kJ/(kg·K)
        v1 = R_air * T1 / self.p1  # m³/kg
        v2 = v1 / r
        mep = w_net / (v1 - v2) if (v1 - v2) > 0 else 0

        return CycleResult(
            cycle_name="Otto",
            efficiency=eta,
            net_work=Q(w_net, "kJ/kg"),
            heat_input=Q(self.q_in, "kJ/kg"),
            heat_rejected=Q(q_out, "kJ/kg"),
            back_work_ratio=0,
            mep=Q(mep, "kPa"),
            state_points={
                "1": {"T": T1, "p": self.p1},
                "2": {"T": T2},
                "3": {"T": T3},
                "4": {"T": T4},
            },
        )


class DieselCycle:
    """Ideal Diesel (compression-ignition) cycle analysis.

    Parameters
    ----------
    compression_ratio : float
        Volume compression ratio r = V1/V2.
    cutoff_ratio : float
        Cutoff ratio rc = V3/V2.
    T_initial : pint.Quantity
        Initial temperature [K].
    p_initial : pint.Quantity
        Initial pressure [kPa].
    gamma : float
        Ratio of specific heats.
    cv : float
        Specific heat at constant volume [kJ/(kg·K)].
    cp : float
        Specific heat at constant pressure [kJ/(kg·K)].
    """

    def __init__(
        self,
        compression_ratio: float = 18,
        cutoff_ratio: float = 2.0,
        T_initial: pint.Quantity = Q(300, "K"),
        p_initial: pint.Quantity = Q(100, "kPa"),
        gamma: float = 1.4,
        cv: float = 0.718,
        cp: float = 1.005,
    ) -> None:
        self.r = compression_ratio
        self.rc = cutoff_ratio
        self.T1 = T_initial.to("K").magnitude
        self.p1 = p_initial.to("kPa").magnitude
        self.gamma = gamma
        self.cv = cv
        self.cp = cp

    def analyze(self) -> CycleResult:
        """Analyze Diesel cycle."""
        r = self.r
        rc = self.rc
        g = self.gamma
        cv = self.cv
        cp = self.cp
        T1 = self.T1

        # Diesel cycle efficiency
        eta = 1 - (1 / r ** (g - 1)) * ((rc**g - 1) / (g * (rc - 1)))

        # State points
        T2 = T1 * r ** (g - 1)
        T3 = T2 * rc  # After const-P heat addition
        T4 = T3 * (rc / r) ** (g - 1)  # After isentropic expansion

        q_in = cp * (T3 - T2)
        q_out = cv * (T4 - T1)
        w_net = q_in - q_out

        # MEP
        R_air = 0.287
        v1 = R_air * T1 / self.p1
        v2 = v1 / r
        mep = w_net / (v1 - v2) if (v1 - v2) > 0 else 0

        return CycleResult(
            cycle_name="Diesel",
            efficiency=eta,
            net_work=Q(w_net, "kJ/kg"),
            heat_input=Q(q_in, "kJ/kg"),
            heat_rejected=Q(q_out, "kJ/kg"),
            back_work_ratio=0,
            mep=Q(mep, "kPa"),
            state_points={
                "1": {"T": T1, "p": self.p1},
                "2": {"T": T2},
                "3": {"T": T3},
                "4": {"T": T4},
            },
        )
