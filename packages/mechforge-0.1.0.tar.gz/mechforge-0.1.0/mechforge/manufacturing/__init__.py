"""
MechForge Manufacturing Module (Stub).

Machining parameters, cutting forces, tool life (Taylor's equation),
casting/injection molding analysis. Full implementation planned for v0.2.0.
"""

from __future__ import annotations

import numpy as np

from mechforge.core.units import Q


def taylor_tool_life(V: float, C: float = 100, n: float = 0.25) -> float:
    """Taylor's tool life equation.

    .. math:: VT^n = C

    Parameters
    ----------
    V : float
        Cutting speed [m/min].
    C : float
        Taylor constant.
    n : float
        Taylor exponent (0.1-0.5 typical).

    Returns
    -------
    float
        Tool life [min].
    """
    return (C / V) ** (1 / n) if V > 0 else float("inf")


def cutting_force(
    depth: float,
    feed: float,
    specific_cutting_force: float = 2000,
) -> float:
    """Estimate main cutting force.

    Parameters
    ----------
    depth : float
        Depth of cut [mm].
    feed : float
        Feed rate [mm/rev].
    specific_cutting_force : float
        Specific cutting force kc [N/mm²].

    Returns
    -------
    float
        Cutting force [N].
    """
    return specific_cutting_force * depth * feed


def material_removal_rate(
    depth: float,
    feed: float,
    speed: float,
) -> float:
    """Calculate material removal rate (MRR).

    Parameters
    ----------
    depth : float
        Depth of cut [mm].
    feed : float
        Feed rate [mm/rev].
    speed : float
        Cutting speed [m/min].

    Returns
    -------
    float
        MRR [cm³/min].
    """
    return depth * feed * speed * 1000 / 1000  # mm³/min -> cm³/min


def machining_time(
    length: float,
    feed: float,
    speed: float,
    diameter: float,
) -> float:
    """Calculate machining time for turning.

    Parameters
    ----------
    length : float
        Workpiece length [mm].
    feed : float
        Feed rate [mm/rev].
    speed : float
        Cutting speed [m/min].
    diameter : float
        Workpiece diameter [mm].

    Returns
    -------
    float
        Machining time [min].
    """
    N = 1000 * speed / (np.pi * diameter) if diameter > 0 else 0  # RPM
    return length / (feed * N) if feed * N > 0 else 0


__all__ = [
    "taylor_tool_life",
    "cutting_force",
    "material_removal_rate",
    "machining_time",
]
