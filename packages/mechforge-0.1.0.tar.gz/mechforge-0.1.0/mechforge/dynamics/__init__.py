"""
MechForge Dynamics Module (Stub).

Vibration analysis, modal analysis, rotor dynamics, and dynamic systems.
Full implementation planned for v0.2.0.
"""

from __future__ import annotations


def sdof_natural_frequency(k: float, m: float) -> float:
    """Single-DOF natural frequency.

    Parameters
    ----------
    k : float
        Spring stiffness [N/m].
    m : float
        Mass [kg].

    Returns
    -------
    float
        Natural frequency [Hz].
    """
    import numpy as np
    return np.sqrt(k / m) / (2 * np.pi)


def sdof_damped_frequency(k: float, m: float, c: float) -> float:
    """Single-DOF damped natural frequency.

    Parameters
    ----------
    k : float
        Spring stiffness [N/m].
    m : float
        Mass [kg].
    c : float
        Damping coefficient [N·s/m].

    Returns
    -------
    float
        Damped natural frequency [Hz].
    """
    import numpy as np
    omega_n = np.sqrt(k / m)
    zeta = c / (2 * np.sqrt(k * m))
    omega_d = omega_n * np.sqrt(1 - zeta**2) if zeta < 1 else 0
    return omega_d / (2 * np.pi)


def damping_ratio(c: float, k: float, m: float) -> float:
    """Calculate damping ratio.

    Parameters
    ----------
    c : float
        Damping coefficient [N·s/m].
    k : float
        Spring stiffness [N/m].
    m : float
        Mass [kg].

    Returns
    -------
    float
        Damping ratio ζ.
    """
    import numpy as np
    return c / (2 * np.sqrt(k * m))


def transmissibility(r: float, zeta: float) -> float:
    """Force transmissibility for SDOF system.

    Parameters
    ----------
    r : float
        Frequency ratio ω/ωn.
    zeta : float
        Damping ratio.

    Returns
    -------
    float
        Transmissibility ratio.
    """
    import numpy as np
    num = np.sqrt(1 + (2 * zeta * r)**2)
    den = np.sqrt((1 - r**2)**2 + (2 * zeta * r)**2)
    return num / den if den > 0 else float("inf")


__all__ = [
    "sdof_natural_frequency",
    "sdof_damped_frequency",
    "damping_ratio",
    "transmissibility",
]
