"""
MechForge Reports Module.

Auto-generates professional engineering reports in PDF and Word formats
from analysis results.
"""

from __future__ import annotations

from mechforge.reports.base import ReportGenerator
from mechforge.reports.pdf_report import generate_pdf_report

__all__ = [
    "ReportGenerator",
    "generate_pdf_report",
]
