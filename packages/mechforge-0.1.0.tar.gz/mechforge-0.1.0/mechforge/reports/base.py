"""
Report Generator Base — Framework for Professional Engineering Reports.

Provides the base report generation infrastructure for creating
structured engineering reports from MechForge analysis results.

Examples
--------
>>> from mechforge.reports.base import ReportGenerator
>>> report = ReportGenerator(title="Shaft Analysis Report")
>>> report.add_section("Introduction", "Analysis of main drive shaft...")
>>> report.add_result("Safety Factor", 2.5, unit="", status="PASS")
>>> report.to_text()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional, Sequence

import pint

from mechforge.core.units import Q


@dataclass
class ReportSection:
    """A section in the engineering report."""

    title: str
    content: str = ""
    subsections: list = field(default_factory=list)
    tables: list = field(default_factory=list)
    figures: list = field(default_factory=list)


@dataclass
class ReportResult:
    """A result entry for the report."""

    parameter: str
    value: Any
    unit: str = ""
    status: str = ""  # PASS, FAIL, WARNING
    reference: str = ""  # Standard reference


class ReportGenerator:
    """Professional engineering report generator.

    Parameters
    ----------
    title : str
        Report title.
    project : str
        Project name.
    author : str
        Author name.
    company : str
        Company/organization name.
    revision : str
        Document revision.
    standard : str
        Applicable standard (e.g., 'ASME B106.1M').
    """

    def __init__(
        self,
        title: str = "Engineering Analysis Report",
        project: str = "",
        author: str = "",
        company: str = "",
        revision: str = "A",
        standard: str = "",
    ) -> None:
        self.title = title
        self.project = project
        self.author = author
        self.company = company
        self.revision = revision
        self.standard = standard
        self.date = datetime.now().strftime("%Y-%m-%d")

        self.sections: list[ReportSection] = []
        self.results: list[ReportResult] = []
        self.inputs: list[dict] = []
        self.assumptions: list[str] = []
        self.conclusions: list[str] = []

    def add_section(self, title: str, content: str = "") -> ReportSection:
        """Add a section to the report.

        Parameters
        ----------
        title : str
            Section title.
        content : str
            Section content text.

        Returns
        -------
        ReportSection
            The created section.
        """
        section = ReportSection(title=title, content=content)
        self.sections.append(section)
        return section

    def add_result(
        self,
        parameter: str,
        value: Any,
        unit: str = "",
        status: str = "",
        reference: str = "",
    ) -> None:
        """Add a result entry.

        Parameters
        ----------
        parameter : str
            Parameter name.
        value : Any
            Computed value.
        unit : str
            Unit string.
        status : str
            'PASS', 'FAIL', or 'WARNING'.
        reference : str
            Standard reference.
        """
        if isinstance(value, pint.Quantity):
            unit = str(value.units)
            value = float(value.magnitude)

        self.results.append(
            ReportResult(
                parameter=parameter,
                value=value,
                unit=unit,
                status=status,
                reference=reference,
            )
        )

    def add_input(self, name: str, value: Any, unit: str = "") -> None:
        """Add an input parameter."""
        if isinstance(value, pint.Quantity):
            unit = str(value.units)
            value = float(value.magnitude)
        self.inputs.append({"name": name, "value": value, "unit": unit})

    def add_assumption(self, text: str) -> None:
        """Add an assumption to the report."""
        self.assumptions.append(text)

    def add_conclusion(self, text: str) -> None:
        """Add a conclusion to the report."""
        self.conclusions.append(text)

    def add_analysis_result(self, result_obj: Any) -> None:
        """Auto-populate report from a MechForge result object.

        Inspects the result object's fields and adds them as results.
        """
        for attr_name in dir(result_obj):
            if attr_name.startswith("_"):
                continue
            if callable(getattr(result_obj, attr_name)):
                continue

            value = getattr(result_obj, attr_name)
            if isinstance(value, pint.Quantity):
                self.add_result(
                    parameter=attr_name.replace("_", " ").title(),
                    value=value,
                )
            elif isinstance(value, (int, float)):
                self.add_result(parameter=attr_name.replace("_", " ").title(), value=value)

    def to_text(self) -> str:
        """Generate plain-text report.

        Returns
        -------
        str
            Complete formatted text report.
        """
        lines = []
        sep = "=" * 70

        # Header
        lines.append(sep)
        lines.append(f"  {self.title.upper()}")
        lines.append(sep)
        if self.project:
            lines.append(f"  Project:    {self.project}")
        if self.author:
            lines.append(f"  Author:     {self.author}")
        if self.company:
            lines.append(f"  Company:    {self.company}")
        lines.append(f"  Date:       {self.date}")
        lines.append(f"  Revision:   {self.revision}")
        if self.standard:
            lines.append(f"  Standard:   {self.standard}")
        lines.append(sep)
        lines.append("")

        # Inputs
        if self.inputs:
            lines.append("INPUT PARAMETERS")
            lines.append("-" * 50)
            for inp in self.inputs:
                unit_str = f" [{inp['unit']}]" if inp["unit"] else ""
                lines.append(f"  {inp['name']:<30s} {inp['value']}{unit_str}")
            lines.append("")

        # Assumptions
        if self.assumptions:
            lines.append("ASSUMPTIONS")
            lines.append("-" * 50)
            for i, a in enumerate(self.assumptions, 1):
                lines.append(f"  {i}. {a}")
            lines.append("")

        # Sections
        for section in self.sections:
            lines.append(section.title.upper())
            lines.append("-" * 50)
            if section.content:
                lines.append(f"  {section.content}")
            lines.append("")

        # Results
        if self.results:
            lines.append("RESULTS SUMMARY")
            lines.append("-" * 70)
            lines.append(
                f"  {'Parameter':<30s} {'Value':>12s} {'Unit':>10s} {'Status':>8s}"
            )
            lines.append("  " + "-" * 64)
            for r in self.results:
                val_str = f"{r.value:.4g}" if isinstance(r.value, float) else str(r.value)
                lines.append(
                    f"  {r.parameter:<30s} {val_str:>12s} {r.unit:>10s} {r.status:>8s}"
                )
            lines.append("")

        # Conclusions
        if self.conclusions:
            lines.append("CONCLUSIONS")
            lines.append("-" * 50)
            for c in self.conclusions:
                lines.append(f"  • {c}")
            lines.append("")

        lines.append(sep)
        lines.append("  END OF REPORT")
        lines.append(sep)

        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Export report data as dictionary (for JSON/API use).

        Returns
        -------
        dict
            Complete report data.
        """
        return {
            "title": self.title,
            "project": self.project,
            "author": self.author,
            "company": self.company,
            "date": self.date,
            "revision": self.revision,
            "standard": self.standard,
            "inputs": self.inputs,
            "assumptions": self.assumptions,
            "results": [
                {
                    "parameter": r.parameter,
                    "value": r.value,
                    "unit": r.unit,
                    "status": r.status,
                    "reference": r.reference,
                }
                for r in self.results
            ],
            "conclusions": self.conclusions,
        }
