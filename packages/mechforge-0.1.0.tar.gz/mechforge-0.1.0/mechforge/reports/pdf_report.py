"""
PDF Report Generation.

Generates professional PDF engineering reports using matplotlib for
layout when reportlab is not available.

Notes
-----
For full PDF support, install optional dependency:

    pip install mechforge[reports]  # includes reportlab, python-docx

This module provides a lightweight alternative using matplotlib.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from mechforge.reports.base import ReportGenerator


def generate_pdf_report(
    report: ReportGenerator,
    output_path: str = "report.pdf",
) -> str:
    """Generate a PDF report from a ReportGenerator object.

    Parameters
    ----------
    report : ReportGenerator
        Populated report generator.
    output_path : str
        Output file path for PDF.

    Returns
    -------
    str
        Path to generated PDF file.

    Notes
    -----
    Uses matplotlib as a fallback if reportlab is not available.
    For best results, install reportlab:

        pip install reportlab
    """
    try:
        return _generate_with_reportlab(report, output_path)
    except ImportError:
        return _generate_with_matplotlib(report, output_path)


def _generate_with_matplotlib(report: ReportGenerator, output_path: str) -> str:
    """Generate PDF using matplotlib (always available)."""
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages

    with PdfPages(output_path) as pdf:
        # Title page
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.axis("off")
        ax.text(0.5, 0.7, report.title, fontsize=20, fontweight="bold",
                ha="center", va="center", transform=ax.transAxes)
        if report.project:
            ax.text(0.5, 0.62, f"Project: {report.project}", fontsize=14,
                    ha="center", transform=ax.transAxes)
        info_lines = []
        if report.author:
            info_lines.append(f"Author: {report.author}")
        if report.company:
            info_lines.append(f"Company: {report.company}")
        info_lines.append(f"Date: {report.date}")
        info_lines.append(f"Revision: {report.revision}")
        if report.standard:
            info_lines.append(f"Standard: {report.standard}")
        ax.text(0.5, 0.45, "\n".join(info_lines), fontsize=11,
                ha="center", va="center", transform=ax.transAxes)
        pdf.savefig(fig)
        plt.close(fig)

        # Results page
        if report.results:
            fig, ax = plt.subplots(figsize=(8.5, 11))
            ax.axis("off")
            ax.text(0.05, 0.95, "Results Summary", fontsize=16, fontweight="bold",
                    transform=ax.transAxes, va="top")

            headers = ["Parameter", "Value", "Unit", "Status"]
            data = []
            for r in report.results:
                val_str = f"{r.value:.4g}" if isinstance(r.value, float) else str(r.value)
                data.append([r.parameter, val_str, r.unit, r.status])

            if data:
                table = ax.table(
                    cellText=data,
                    colLabels=headers,
                    loc="center",
                    cellLoc="center",
                )
                table.auto_set_font_size(False)
                table.set_fontsize(9)
                table.scale(1.0, 1.5)

                # Color status cells
                for i, r in enumerate(report.results):
                    cell = table[i + 1, 3]
                    if r.status == "PASS":
                        cell.set_facecolor("#d4edda")
                    elif r.status == "FAIL":
                        cell.set_facecolor("#f8d7da")
                    elif r.status == "WARNING":
                        cell.set_facecolor("#fff3cd")

            pdf.savefig(fig)
            plt.close(fig)

        # Text content page
        text = report.to_text()
        # Split into pages of ~50 lines
        lines = text.split("\n")
        page_size = 50
        for i in range(0, len(lines), page_size):
            page_lines = lines[i : i + page_size]
            fig, ax = plt.subplots(figsize=(8.5, 11))
            ax.axis("off")
            ax.text(
                0.05, 0.95, "\n".join(page_lines),
                fontsize=8, fontfamily="monospace",
                transform=ax.transAxes, va="top",
            )
            pdf.savefig(fig)
            plt.close(fig)

    return str(Path(output_path).resolve())


def _generate_with_reportlab(report: ReportGenerator, output_path: str) -> str:
    """Generate PDF using reportlab (professional quality)."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors

    doc = SimpleDocTemplate(output_path, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []

    # Title
    elements.append(Paragraph(report.title, styles["Title"]))
    elements.append(Spacer(1, 10 * mm))

    # Meta
    meta = []
    if report.project:
        meta.append(f"<b>Project:</b> {report.project}")
    if report.author:
        meta.append(f"<b>Author:</b> {report.author}")
    meta.append(f"<b>Date:</b> {report.date}")
    meta.append(f"<b>Revision:</b> {report.revision}")
    for m in meta:
        elements.append(Paragraph(m, styles["Normal"]))
    elements.append(Spacer(1, 10 * mm))

    # Inputs
    if report.inputs:
        elements.append(Paragraph("Input Parameters", styles["Heading2"]))
        data = [["Parameter", "Value", "Unit"]]
        for inp in report.inputs:
            data.append([inp["name"], str(inp["value"]), inp["unit"]])
        t = Table(data)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        elements.append(t)
        elements.append(Spacer(1, 5 * mm))

    # Results
    if report.results:
        elements.append(Paragraph("Results Summary", styles["Heading2"]))
        data = [["Parameter", "Value", "Unit", "Status"]]
        for r in report.results:
            val = f"{r.value:.4g}" if isinstance(r.value, float) else str(r.value)
            data.append([r.parameter, val, r.unit, r.status])
        t = Table(data)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        elements.append(t)

    # Conclusions
    if report.conclusions:
        elements.append(Spacer(1, 5 * mm))
        elements.append(Paragraph("Conclusions", styles["Heading2"]))
        for c in report.conclusions:
            elements.append(Paragraph(f"• {c}", styles["Normal"]))

    doc.build(elements)
    return str(Path(output_path).resolve())
