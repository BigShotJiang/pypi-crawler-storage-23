"""
Fracture Mechanics — Stress Intensity, Crack Growth, LEFM & EPFM.

Linear Elastic Fracture Mechanics (LEFM) calculations including stress
intensity factors, Paris law crack growth life, and critical crack lengths.

References
----------
.. [1] Anderson, T.L. Fracture Mechanics, 4th Ed.
.. [2] ASME BPVC Section XI — Rules for Inservice Inspection
.. [3] BS 7910 — Guide to Methods for Assessing Flaws
.. [4] Shigley's MED, 11th Ed., Chapter 5

Examples
--------
>>> from mechforge.structural.fracture import stress_intensity_factor
>>> K = stress_intensity_factor(
...     geometry='center_crack', sigma=100, a=5e-3, W=0.1
... )
>>> print(f'K_I = {K:.2f} MPa√m')
"""

from __future__ import annotations

import numpy as np

from mechforge.core.exceptions import ValidationError


def stress_intensity_factor(
    geometry: str,
    sigma: float,
    a: float,
    W: float | None = None,
    B: float | None = None,
    R: float | None = None,
) -> float:
    """Calculate Mode I stress intensity factor K_I.

    Parameters
    ----------
    geometry : str
        Crack geometry type:
        - 'center_crack': Central through crack in finite plate
        - 'edge_crack': Single edge crack in finite plate
        - 'double_edge_crack': Double edge cracks in finite plate
        - 'penny_crack': Penny-shaped (circular) embedded crack
        - 'semi_elliptical': Semi-elliptical surface crack
    sigma : float
        Applied far-field stress [MPa].
    a : float
        Crack half-length or depth [m].
    W : float, optional
        Plate width [m] (for finite-width correction).
    B : float, optional
        Plate thickness [m].
    R : float, optional
        Cylinder radius [m].

    Returns
    -------
    float
        Stress intensity factor K_I [MPa·√m].

    Notes
    -----
    The general form for stress intensity factor is:

    .. math:: K_I = \\sigma \\cdot \\sqrt{\\pi a} \\cdot F(a/W)

    Where F(a/W) is the geometry correction factor.

    References
    ----------
    .. [1] Anderson, Fracture Mechanics, 4th Ed., Chapter 2
    .. [2] Tada, Paris, & Irwin, Stress Analysis of Cracks Handbook

    Examples
    --------
    >>> K = stress_intensity_factor('center_crack', sigma=100, a=0.005, W=0.1)
    """
    if a <= 0:
        raise ValidationError("Crack length 'a' must be positive.")

    K_base = sigma * np.sqrt(np.pi * a)

    if geometry == "center_crack":
        # Finite-width correction (Feddersen)
        if W is not None:
            ratio = a / W
            F = np.sqrt(1 / np.cos(np.pi * ratio / 2))
        else:
            F = 1.0
        return float(K_base * F)

    elif geometry == "edge_crack":
        if W is not None:
            ratio = a / W
            F = (
                1.12
                - 0.231 * ratio
                + 10.55 * ratio**2
                - 21.72 * ratio**3
                + 30.39 * ratio**4
            )
        else:
            F = 1.12
        return float(K_base * F)

    elif geometry == "double_edge_crack":
        if W is not None:
            ratio = a / W
            F = (
                1.122
                - 0.561 * ratio
                - 0.085 * ratio**2
                + 0.180 * ratio**3
            ) / np.sqrt(1 - ratio)
        else:
            F = 1.122
        return float(K_base * F)

    elif geometry == "penny_crack":
        # Circular embedded crack (Sneddon solution)
        F = 2 / np.pi
        return float(K_base * F)

    elif geometry == "semi_elliptical":
        # Newman-Raju approximation for a/c = 1 (semicircular)
        F = 1.12 * (2 / np.pi)
        return float(K_base * F)

    raise ValidationError(f"Unknown geometry: {geometry}")


def paris_law_cycles(
    C: float,
    m: float,
    a_initial: float,
    a_final: float,
    sigma: float,
    geometry: str = "center_crack",
    W: float | None = None,
    n_steps: int = 1000,
) -> float:
    """Calculate crack growth life using Paris' Law.

    Parameters
    ----------
    C : float
        Paris law coefficient (units: m/cycle / (MPa√m)^m).
    m : float
        Paris law exponent (typically 2-4 for metals).
    a_initial : float
        Initial crack length [m].
    a_final : float
        Final (critical) crack length [m].
    sigma : float
        Applied stress range Δσ [MPa].
    geometry : str
        Crack geometry (passed to stress_intensity_factor).
    W : float, optional
        Plate width [m].
    n_steps : int
        Number of integration steps.

    Returns
    -------
    float
        Number of cycles to grow from a_initial to a_final.

    Notes
    -----
    Paris' Law:

    .. math:: \\frac{da}{dN} = C \\cdot (\\Delta K)^m

    Integration gives:

    .. math:: N = \\int_{a_i}^{a_f} \\frac{da}{C \\cdot (\\Delta K)^m}

    References
    ----------
    .. [1] Paris, P.C. & Erdogan, F. (1963). Trans. ASME, J. Basic Eng., 85, 528-534.

    Examples
    --------
    >>> N = paris_law_cycles(
    ...     C=3.6e-11, m=3.0, a_initial=1e-3, a_final=10e-3,
    ...     sigma=150, geometry='center_crack'
    ... )
    """
    if a_initial >= a_final:
        raise ValidationError("a_initial must be less than a_final.")
    if a_initial <= 0:
        raise ValidationError("a_initial must be positive.")

    a_values = np.linspace(a_initial, a_final, n_steps)
    da = np.diff(a_values)

    N_total = 0.0
    for i in range(len(da)):
        a = a_values[i]
        delta_K = stress_intensity_factor(geometry, sigma, a, W)
        if delta_K <= 0:
            continue
        da_dN = C * delta_K**m
        if da_dN > 0:
            N_total += da[i] / da_dN

    return float(N_total)


def critical_crack_length(
    K_IC: float,
    sigma: float,
    geometry: str = "center_crack",
    W: float | None = None,
) -> float:
    """Calculate critical crack length for unstable fracture.

    Parameters
    ----------
    K_IC : float
        Plane strain fracture toughness [MPa·√m].
    sigma : float
        Applied stress [MPa].
    geometry : str
        Crack geometry type.
    W : float, optional
        Plate width [m].

    Returns
    -------
    float
        Critical crack length [m].

    Notes
    -----
    For an infinite plate with center crack:

    .. math:: a_c = \\frac{1}{\\pi} \\left(\\frac{K_{IC}}{\\sigma}\\right)^2

    References
    ----------
    .. [1] Anderson, Fracture Mechanics, 4th Ed., Chapter 2

    Examples
    --------
    >>> a_c = critical_crack_length(K_IC=50, sigma=200)
    >>> print(f'{a_c*1000:.2f} mm')
    """
    if sigma <= 0:
        raise ValidationError("Applied stress must be positive.")
    if K_IC <= 0:
        raise ValidationError("Fracture toughness must be positive.")

    # Iterative solution for general geometry
    a_est = (1 / np.pi) * (K_IC / sigma) ** 2

    # Iterate with geometry correction
    for _ in range(20):
        K = stress_intensity_factor(geometry, sigma, a_est, W)
        if K <= 0:
            break
        a_new = a_est * (K_IC / K) ** 2
        if abs(a_new - a_est) / a_est < 1e-6:
            break
        a_est = a_new

    return float(a_est)
