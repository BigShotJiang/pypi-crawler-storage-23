"""
Beam Analysis — Euler-Bernoulli and Timoshenko Beam Theory.

Provides complete beam analysis: arbitrary cross-sections, distributed and
point loads, fixed/pin/roller/elastic supports, deflection/slope diagrams,
shear force and bending moment calculations.

References
----------
.. [1] Shigley's Mechanical Engineering Design, 11th Ed., Chapter 4
.. [2] Roark's Formulas for Stress and Strain, 9th Ed.
.. [3] AISC Steel Construction Manual, 15th Ed.

Examples
--------
>>> from mechforge.structural.beam import Beam, PointLoad, Support
>>> from mechforge.core.units import Q
>>> beam = Beam(length=Q(3, 'm'), E=Q(200, 'GPa'), I=Q(8.33e-6, 'm**4'))
>>> beam.add_support(Support(position=Q(0, 'm'), kind='pin'))
>>> beam.add_support(Support(position=Q(3, 'm'), kind='roller'))
>>> beam.add_load(PointLoad(position=Q(1.5, 'm'), magnitude=Q(-10, 'kN')))
>>> result = beam.analyze()
>>> print(f'Max deflection: {result.max_deflection.to("mm"):.3f}')
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional

import numpy as np
import pint

from mechforge.core.units import Q, ureg, ensure_quantity
from mechforge.core.validators import validate_positive, validate_quantity
from mechforge.core.exceptions import ValidationError, InsufficientDataError


@dataclass
class PointLoad:
    """A concentrated point load on a beam.

    Parameters
    ----------
    position : pint.Quantity
        Position along the beam from the left end [length].
    magnitude : pint.Quantity
        Force magnitude [force]. Negative = downward.
    angle : float
        Angle from vertical in degrees (0 = vertical). Default 0.
    """

    position: pint.Quantity
    magnitude: pint.Quantity
    angle: float = 0.0


@dataclass
class DistributedLoad:
    """A distributed (uniform or linearly varying) load on a beam.

    Parameters
    ----------
    start : pint.Quantity
        Start position along beam [length].
    end : pint.Quantity
        End position along beam [length].
    w_start : pint.Quantity
        Load intensity at start [force/length]. Negative = downward.
    w_end : pint.Quantity, optional
        Load intensity at end [force/length]. If None, uniform load = w_start.
    """

    start: pint.Quantity
    end: pint.Quantity
    w_start: pint.Quantity
    w_end: Optional[pint.Quantity] = None

    def __post_init__(self) -> None:
        if self.w_end is None:
            self.w_end = self.w_start


@dataclass
class Moment:
    """A concentrated moment (couple) on a beam.

    Parameters
    ----------
    position : pint.Quantity
        Position along the beam [length].
    magnitude : pint.Quantity
        Moment magnitude [force*length]. Positive = counterclockwise.
    """

    position: pint.Quantity
    magnitude: pint.Quantity


@dataclass
class Support:
    """A beam support.

    Parameters
    ----------
    position : pint.Quantity
        Position along beam from the left end [length].
    kind : str
        Support type: 'pin', 'roller', 'fixed', or 'elastic'.
    stiffness : pint.Quantity, optional
        Spring stiffness for elastic supports [force/length].
    """

    position: pint.Quantity
    kind: Literal["pin", "roller", "fixed", "elastic"] = "pin"
    stiffness: Optional[pint.Quantity] = None


@dataclass
class BeamResult:
    """Results from beam analysis.

    Attributes
    ----------
    x : np.ndarray
        Position array along beam [m].
    shear_force : np.ndarray
        Shear force diagram [N].
    bending_moment : np.ndarray
        Bending moment diagram [N·m].
    deflection : np.ndarray
        Deflection diagram [m].
    slope : np.ndarray
        Slope diagram [rad].
    reactions : dict
        Support reactions.
    max_deflection : pint.Quantity
        Maximum absolute deflection.
    max_moment : pint.Quantity
        Maximum absolute bending moment.
    max_shear : pint.Quantity
        Maximum absolute shear force.
    max_stress : pint.Quantity
        Maximum bending stress (M*c/I).
    """

    x: np.ndarray
    shear_force: np.ndarray
    bending_moment: np.ndarray
    deflection: np.ndarray
    slope: np.ndarray
    reactions: dict
    max_deflection: pint.Quantity
    max_moment: pint.Quantity
    max_shear: pint.Quantity
    max_stress: pint.Quantity

    def plot(
        self,
        show: bool = True,
        save: str | None = None,
        figsize: tuple[float, float] = (12, 10),
    ) -> None:
        """Plot shear, moment, and deflection diagrams.

        Parameters
        ----------
        show : bool
            Whether to display the plot.
        save : str, optional
            File path to save the figure.
        figsize : tuple
            Figure size in inches.
        """
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(3, 1, figsize=figsize, sharex=True)

        # Shear Force Diagram
        axes[0].fill_between(self.x, self.shear_force / 1000, alpha=0.3, color="blue")
        axes[0].plot(self.x, self.shear_force / 1000, "b-", linewidth=1.5)
        axes[0].axhline(y=0, color="k", linewidth=0.5)
        axes[0].set_ylabel("Shear Force (kN)")
        axes[0].set_title("Shear Force Diagram (SFD)")
        axes[0].grid(True, alpha=0.3)

        # Bending Moment Diagram
        axes[1].fill_between(self.x, self.bending_moment / 1000, alpha=0.3, color="red")
        axes[1].plot(self.x, self.bending_moment / 1000, "r-", linewidth=1.5)
        axes[1].axhline(y=0, color="k", linewidth=0.5)
        axes[1].set_ylabel("Bending Moment (kN·m)")
        axes[1].set_title("Bending Moment Diagram (BMD)")
        axes[1].grid(True, alpha=0.3)

        # Deflection Diagram
        axes[2].plot(self.x, self.deflection * 1000, "g-", linewidth=1.5)
        axes[2].axhline(y=0, color="k", linewidth=0.5)
        axes[2].set_ylabel("Deflection (mm)")
        axes[2].set_xlabel("Position along beam (m)")
        axes[2].set_title("Deflection Diagram")
        axes[2].grid(True, alpha=0.3)

        plt.tight_layout()

        if save:
            plt.savefig(save, dpi=150, bbox_inches="tight")
        if show:
            plt.show()
        plt.close()


class Beam:
    """Complete beam analysis using Euler-Bernoulli theory.

    Supports simply supported, cantilever, overhanging, and continuous
    beams with arbitrary loading.

    Parameters
    ----------
    length : pint.Quantity
        Total beam length [length].
    E : pint.Quantity
        Elastic modulus [pressure].
    I : pint.Quantity
        Second moment of area [length⁴].
    c : pint.Quantity, optional
        Distance from neutral axis to extreme fiber [length].
        Required for stress calculation.
    n_points : int
        Number of evaluation points along beam.

    Notes
    -----
    The beam uses the convention:
    - x: horizontal, left to right
    - y: vertical, positive upward
    - Positive moment: sagging (bottom in tension)

    References
    ----------
    .. [1] Shigley's MED, 11th Ed., Chapter 4
    .. [2] Roark's Formulas for Stress and Strain, 9th Ed.

    Examples
    --------
    >>> beam = Beam(length=Q(5, 'm'), E=Q(200, 'GPa'), I=Q(1e-4, 'm**4'))
    >>> beam.add_support(Support(position=Q(0, 'm'), kind='fixed'))
    >>> beam.add_load(PointLoad(position=Q(5, 'm'), magnitude=Q(-10, 'kN')))
    >>> result = beam.analyze()
    """

    def __init__(
        self,
        length: pint.Quantity,
        E: pint.Quantity,
        I: pint.Quantity,
        c: Optional[pint.Quantity] = None,
        n_points: int = 500,
    ) -> None:
        validate_quantity(length, "length")
        validate_positive(length, "length")
        validate_quantity(E, "E")
        validate_quantity(I, "I")

        self.length = length.to("m").magnitude
        self.E = E.to("Pa").magnitude
        self.I = I.to("m**4").magnitude
        self.EI = self.E * self.I
        self.c = c.to("m").magnitude if c is not None else None
        self.n_points = n_points

        self._point_loads: list[PointLoad] = []
        self._distributed_loads: list[DistributedLoad] = []
        self._moments: list[Moment] = []
        self._supports: list[Support] = []

    def add_load(self, load: PointLoad | DistributedLoad | Moment) -> None:
        """Add a load to the beam.

        Parameters
        ----------
        load : PointLoad, DistributedLoad, or Moment
            The load to add.
        """
        if isinstance(load, PointLoad):
            self._point_loads.append(load)
        elif isinstance(load, DistributedLoad):
            self._distributed_loads.append(load)
        elif isinstance(load, Moment):
            self._moments.append(load)
        else:
            raise ValidationError(f"Unknown load type: {type(load)}")

    def add_support(self, support: Support) -> None:
        """Add a support to the beam.

        Parameters
        ----------
        support : Support
            The support to add.
        """
        self._supports.append(support)

    def analyze(self) -> BeamResult:
        """Perform complete beam analysis.

        Solves for reactions, then computes shear force, bending moment,
        slope, and deflection diagrams using integration.

        Returns
        -------
        BeamResult
            Complete analysis results.

        Raises
        ------
        InsufficientDataError
            If the beam is improperly supported.
        """
        if len(self._supports) < 1:
            raise InsufficientDataError("Beam requires at least one support.")

        x = np.linspace(0, self.length, self.n_points)
        dx = x[1] - x[0]

        # Calculate reactions
        reactions = self._solve_reactions()

        # Build load function (including reactions)
        w = np.zeros_like(x)  # Distributed load intensity at each point

        # Add point loads as narrow distributions
        for pl in self._point_loads:
            pos = pl.position.to("m").magnitude
            mag = pl.magnitude.to("N").magnitude * np.cos(np.radians(pl.angle))
            idx = np.argmin(np.abs(x - pos))
            w[idx] += mag / dx

        # Add distributed loads
        for dl in self._distributed_loads:
            start = dl.start.to("m").magnitude
            end = dl.end.to("m").magnitude
            w_s = dl.w_start.to("N/m").magnitude
            w_e = dl.w_end.to("N/m").magnitude
            mask = (x >= start) & (x <= end)
            span = end - start
            if span > 0:
                w[mask] += w_s + (w_e - w_s) * (x[mask] - start) / span

        # Add reactions as point loads
        for name, reaction in reactions.items():
            pos = reaction["position"]
            force = reaction.get("force", 0)
            idx = np.argmin(np.abs(x - pos))
            w[idx] += force / dx

        # Integrate to get shear force: V = integral(w, dx)
        shear_force = np.cumsum(w) * dx

        # Add reaction moments for fixed supports
        bending_moment = np.cumsum(shear_force) * dx
        for name, reaction in reactions.items():
            if "moment" in reaction:
                pos = reaction["position"]
                mom = reaction["moment"]
                mask = x >= pos
                bending_moment[mask] += mom

        # Add applied moments
        for m in self._moments:
            pos = m.position.to("m").magnitude
            mag = m.magnitude.to("N*m").magnitude
            mask = x >= pos
            bending_moment[mask] += mag

        # Integrate for slope: θ = integral(M/(EI), dx) + C1
        slope = np.cumsum(bending_moment / self.EI) * dx

        # Integrate for deflection: y = integral(θ, dx) + C2
        deflection = np.cumsum(slope) * dx

        # Apply boundary conditions
        deflection, slope = self._apply_boundary_conditions(
            x, deflection, slope, reactions
        )

        # Calculate max values
        max_defl_idx = np.argmax(np.abs(deflection))
        max_mom_idx = np.argmax(np.abs(bending_moment))
        max_shear_idx = np.argmax(np.abs(shear_force))

        max_stress_val = 0.0
        if self.c is not None:
            max_stress_val = abs(bending_moment[max_mom_idx]) * self.c / self.I

        return BeamResult(
            x=x,
            shear_force=shear_force,
            bending_moment=bending_moment,
            deflection=deflection,
            slope=slope,
            reactions=reactions,
            max_deflection=Q(abs(deflection[max_defl_idx]), "m"),
            max_moment=Q(abs(bending_moment[max_mom_idx]), "N*m"),
            max_shear=Q(abs(shear_force[max_shear_idx]), "N"),
            max_stress=Q(max_stress_val, "Pa"),
        )

    def _solve_reactions(self) -> dict:
        """Solve for support reactions using equilibrium and compatibility.

        Returns
        -------
        dict
            Dictionary of reactions at each support.
        """
        reactions = {}

        # Calculate total applied loads
        total_force = 0.0
        total_moment_about_0 = 0.0

        for pl in self._point_loads:
            pos = pl.position.to("m").magnitude
            mag = pl.magnitude.to("N").magnitude * np.cos(np.radians(pl.angle))
            total_force += mag
            total_moment_about_0 += mag * pos

        for dl in self._distributed_loads:
            start = dl.start.to("m").magnitude
            end = dl.end.to("m").magnitude
            w_s = dl.w_start.to("N/m").magnitude
            w_e = dl.w_end.to("N/m").magnitude
            # Resultant force
            R = (w_s + w_e) / 2 * (end - start)
            # Centroid position
            if abs(w_s + w_e) > 1e-10:
                xc = start + (end - start) * (w_s + 2 * w_e) / (3 * (w_s + w_e))
            else:
                xc = (start + end) / 2
            total_force += R
            total_moment_about_0 += R * xc

        for m in self._moments:
            total_moment_about_0 += m.magnitude.to("N*m").magnitude

        supports = self._supports
        n_supports = len(supports)

        if n_supports == 1 and supports[0].kind == "fixed":
            # Cantilever beam
            pos = supports[0].position.to("m").magnitude
            Ry = -total_force
            M_fix = -(total_moment_about_0 - (-total_force) * pos)
            reactions["R1"] = {"position": pos, "force": Ry, "moment": M_fix}

        elif n_supports == 2:
            # Simply supported / overhanging
            p1 = supports[0].position.to("m").magnitude
            p2 = supports[1].position.to("m").magnitude

            if abs(p2 - p1) < 1e-10:
                raise InsufficientDataError("Two supports at the same location.")

            # Sum of moments about support 1
            R2 = -(total_moment_about_0 - total_force * p1) / (p2 - p1) + total_force * p1 / (p2 - p1)
            # Actually: ΣM about p1 = 0 => R2*(p2-p1) + total_moment_about_0 - total_force*0 ... 
            # Let's redo properly
            # ΣM_p1 = 0: R2*(p2-p1) + ΣF*positions - total_moment_from_p1 = 0
            moment_about_p1 = 0.0
            for pl in self._point_loads:
                pos = pl.position.to("m").magnitude
                mag = pl.magnitude.to("N").magnitude * np.cos(np.radians(pl.angle))
                moment_about_p1 += mag * (pos - p1)

            for dl in self._distributed_loads:
                start = dl.start.to("m").magnitude
                end = dl.end.to("m").magnitude
                w_s = dl.w_start.to("N/m").magnitude
                w_e = dl.w_end.to("N/m").magnitude
                R = (w_s + w_e) / 2 * (end - start)
                if abs(w_s + w_e) > 1e-10:
                    xc = start + (end - start) * (w_s + 2 * w_e) / (3 * (w_s + w_e))
                else:
                    xc = (start + end) / 2
                moment_about_p1 += R * (xc - p1)

            for m in self._moments:
                moment_about_p1 += m.magnitude.to("N*m").magnitude

            R2_force = -moment_about_p1 / (p2 - p1)
            R1_force = -total_force - R2_force

            reactions["R1"] = {"position": p1, "force": R1_force}
            reactions["R2"] = {"position": p2, "force": R2_force}

        else:
            # For more complex cases, use simple equilibrium
            # This is a simplified approach for common cases
            if n_supports >= 2:
                p1 = supports[0].position.to("m").magnitude
                p2 = supports[-1].position.to("m").magnitude

                moment_about_p1 = 0.0
                for pl in self._point_loads:
                    pos = pl.position.to("m").magnitude
                    mag = pl.magnitude.to("N").magnitude
                    moment_about_p1 += mag * (pos - p1)
                for dl in self._distributed_loads:
                    start = dl.start.to("m").magnitude
                    end = dl.end.to("m").magnitude
                    w_s = dl.w_start.to("N/m").magnitude
                    w_e = dl.w_end.to("N/m").magnitude
                    R = (w_s + w_e) / 2 * (end - start)
                    xc = (start + end) / 2
                    moment_about_p1 += R * (xc - p1)

                R2_force = -moment_about_p1 / (p2 - p1) if abs(p2 - p1) > 1e-10 else 0
                R1_force = -total_force - R2_force
                reactions["R1"] = {"position": p1, "force": R1_force}
                reactions["R2"] = {"position": p2, "force": R2_force}

        return reactions

    def _apply_boundary_conditions(
        self,
        x: np.ndarray,
        deflection: np.ndarray,
        slope: np.ndarray,
        reactions: dict,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Apply support boundary conditions to deflection and slope."""
        # Zero deflection at support locations
        support_positions = [s.position.to("m").magnitude for s in self._supports]

        if len(support_positions) >= 2:
            p1 = support_positions[0]
            p2 = support_positions[1]
            idx1 = np.argmin(np.abs(x - p1))
            idx2 = np.argmin(np.abs(x - p2))

            # Linear correction to zero deflection at supports
            d1 = deflection[idx1]
            d2 = deflection[idx2]

            correction = d1 + (d2 - d1) * (x - x[idx1]) / (x[idx2] - x[idx1] + 1e-30)
            deflection = deflection - correction

        elif len(support_positions) == 1:
            # Fixed support
            pos = support_positions[0]
            idx = np.argmin(np.abs(x - pos))
            deflection = deflection - deflection[idx]
            slope = slope - slope[idx]

        return deflection, slope
