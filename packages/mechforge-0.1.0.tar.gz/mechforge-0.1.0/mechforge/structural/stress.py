"""
Stress Analysis — Stress Transformation, Mohr's Circle, Failure Criteria.

Complete 2D/3D stress analysis including principal stress calculation,
Mohr's circle visualization, and failure theory evaluation (Von Mises,
Tresca, Maximum Shear).

References
----------
.. [1] Shigley's MED, 11th Ed., Chapters 3 & 5
.. [2] Boresi & Schmidt, Advanced Mechanics of Materials, 6th Ed.
.. [3] ASME BPVC Section VIII Division 2

Examples
--------
>>> from mechforge.structural.stress import StressState, von_mises
>>> state = StressState(sigma_x=100, sigma_y=-50, tau_xy=30)
>>> print(f"Von Mises: {von_mises(state):.1f} MPa")
>>> state.plot_mohrs_circle()
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class StressState:
    """2D or 3D state of stress at a point.

    Parameters
    ----------
    sigma_x : float
        Normal stress in x-direction [MPa].
    sigma_y : float
        Normal stress in y-direction [MPa].
    tau_xy : float
        Shear stress in xy-plane [MPa].
    sigma_z : float, optional
        Normal stress in z-direction [MPa] (3D).
    tau_xz : float, optional
        Shear stress in xz-plane [MPa] (3D).
    tau_yz : float, optional
        Shear stress in yz-plane [MPa] (3D).

    Notes
    -----
    Sign convention: positive normal stress = tension,
    positive shear = counterclockwise rotation.
    """

    sigma_x: float = 0.0
    sigma_y: float = 0.0
    tau_xy: float = 0.0
    sigma_z: float = 0.0
    tau_xz: float = 0.0
    tau_yz: float = 0.0

    @property
    def stress_tensor(self) -> np.ndarray:
        """Return the 3x3 Cauchy stress tensor.

        Returns
        -------
        np.ndarray
            3x3 symmetric stress tensor.
        """
        return np.array(
            [
                [self.sigma_x, self.tau_xy, self.tau_xz],
                [self.tau_xy, self.sigma_y, self.tau_yz],
                [self.tau_xz, self.tau_yz, self.sigma_z],
            ]
        )


def principal_stresses(state: StressState) -> tuple[float, float, float]:
    """Calculate principal stresses from a stress state.

    Finds the eigenvalues of the stress tensor, sorted σ₁ ≥ σ₂ ≥ σ₃.

    Parameters
    ----------
    state : StressState
        The state of stress.

    Returns
    -------
    tuple of float
        (σ₁, σ₂, σ₃) — principal stresses sorted descending.

    Notes
    -----
    For 2D stress:

    .. math:: \\sigma_{1,2} = \\frac{\\sigma_x + \\sigma_y}{2}
              \\pm \\sqrt{\\left(\\frac{\\sigma_x - \\sigma_y}{2}\\right)^2 + \\tau_{xy}^2}

    References
    ----------
    .. [1] Shigley's MED, 11th Ed., Eq. (3-13)

    Examples
    --------
    >>> s = StressState(sigma_x=100, sigma_y=-50, tau_xy=30)
    >>> s1, s2, s3 = principal_stresses(s)
    """
    eigenvalues = np.linalg.eigvalsh(state.stress_tensor)
    # Sort descending
    sorted_vals = np.sort(eigenvalues)[::-1]
    return float(sorted_vals[0]), float(sorted_vals[1]), float(sorted_vals[2])


def von_mises(state: StressState) -> float:
    """Calculate Von Mises equivalent stress.

    Parameters
    ----------
    state : StressState
        The state of stress.

    Returns
    -------
    float
        Von Mises stress [same units as input].

    Notes
    -----
    .. math:: \\sigma_{vm} = \\sqrt{\\frac{(\\sigma_1-\\sigma_2)^2 +
              (\\sigma_2-\\sigma_3)^2 + (\\sigma_3-\\sigma_1)^2}{2}}

    Also known as the distortion energy criterion or octahedral shear
    stress criterion.

    References
    ----------
    .. [1] Shigley's MED, 11th Ed., Eq. (5-13)

    Examples
    --------
    >>> s = StressState(sigma_x=100, sigma_y=-50, tau_xy=30)
    >>> print(f'{von_mises(s):.1f}')
    """
    s1, s2, s3 = principal_stresses(state)
    return float(
        np.sqrt(((s1 - s2) ** 2 + (s2 - s3) ** 2 + (s3 - s1) ** 2) / 2)
    )


def max_shear(state: StressState) -> float:
    """Calculate maximum shear stress (Tresca criterion).

    Parameters
    ----------
    state : StressState
        The state of stress.

    Returns
    -------
    float
        Maximum shear stress [same units as input].

    Notes
    -----
    .. math:: \\tau_{max} = \\frac{\\sigma_1 - \\sigma_3}{2}

    References
    ----------
    .. [1] Shigley's MED, 11th Ed., Eq. (3-14)
    """
    s1, s2, s3 = principal_stresses(state)
    return float((s1 - s3) / 2)


def stress_concentration_factor(
    geometry: str,
    D: float | None = None,
    d: float | None = None,
    r: float | None = None,
    h: float | None = None,
    t: float | None = None,
) -> float:
    """Calculate theoretical stress concentration factor Kt.

    Parameters
    ----------
    geometry : str
        Geometry type: 'shoulder_fillet', 'groove', 'hole_plate',
        'notch_bar'.
    D : float, optional
        Major diameter or width.
    d : float, optional
        Minor diameter or width.
    r : float, optional
        Fillet or notch radius.
    h : float, optional
        Groove or notch depth.
    t : float, optional
        Plate thickness.

    Returns
    -------
    float
        Stress concentration factor Kt.

    Notes
    -----
    Uses Peterson's stress concentration factors based on curve-fit
    polynomials.

    References
    ----------
    .. [1] Peterson's Stress Concentration Factors, 4th Ed.

    Examples
    --------
    >>> Kt = stress_concentration_factor('shoulder_fillet', D=50, d=40, r=5)
    """
    if geometry == "shoulder_fillet":
        if D is None or d is None or r is None:
            raise ValueError("shoulder_fillet requires D, d, r")
        ratio_rd = r / d
        ratio_Dd = D / d
        # Peterson's approximation for stepped shaft in bending
        if ratio_Dd <= 2.0:
            C1 = 0.947 + 1.206 * np.sqrt(ratio_Dd) - 0.131 * ratio_Dd
            C2 = 0.022 - 3.405 * np.sqrt(ratio_Dd) + 0.915 * ratio_Dd
            C3 = 0.869 + 1.777 * np.sqrt(ratio_Dd) - 0.555 * ratio_Dd
            C4 = -0.810 + 0.422 * np.sqrt(ratio_Dd) - 0.260 * ratio_Dd
            Kt = C1 + C2 * np.sqrt(ratio_rd) + C3 * ratio_rd + C4 * ratio_rd**1.5
            return float(max(1.0, Kt))
        return float(1.0 + 2.0 * np.sqrt((D - d) / (2 * r)))

    elif geometry == "hole_plate":
        if d is None or D is None:
            raise ValueError("hole_plate requires d (hole dia) and D (plate width)")
        ratio = d / D
        # Howland's formula for finite-width plate with central hole
        Kt = 3.0 - 3.13 * ratio + 3.66 * ratio**2 - 1.53 * ratio**3
        return float(max(1.0, Kt))

    elif geometry == "groove":
        if D is None or d is None or r is None:
            raise ValueError("groove requires D, d, r")
        ratio_rd = r / d
        ratio_Dd = D / d
        Kt = 1.0 + 2.0 * np.sqrt((D - d) / (2 * r))
        return float(max(1.0, min(Kt, 6.0)))

    elif geometry == "notch_bar":
        if r is None or d is None:
            raise ValueError("notch_bar requires r (notch radius) and d (bar dia)")
        Kt = 1.0 + 2.0 * np.sqrt(d / (2 * r)) if r > 0 else 1.0
        return float(max(1.0, Kt))

    raise ValueError(f"Unknown geometry type: {geometry}")


class MohrsCircle:
    """Mohr's Circle for 2D stress transformation.

    Parameters
    ----------
    state : StressState
        2D state of stress.

    Examples
    --------
    >>> circle = MohrsCircle(StressState(sigma_x=80, sigma_y=-40, tau_xy=25))
    >>> print(f"Center: {circle.center:.1f}, Radius: {circle.radius:.1f}")
    >>> circle.plot()
    """

    def __init__(self, state: StressState) -> None:
        self.state = state
        self.center = (state.sigma_x + state.sigma_y) / 2
        self.radius = np.sqrt(
            ((state.sigma_x - state.sigma_y) / 2) ** 2 + state.tau_xy**2
        )
        self.sigma_1 = self.center + self.radius
        self.sigma_2 = self.center - self.radius
        self.tau_max = self.radius
        self.theta_p = 0.5 * np.degrees(
            np.arctan2(2 * state.tau_xy, state.sigma_x - state.sigma_y)
        )

    def stress_at_angle(self, theta: float) -> tuple[float, float]:
        """Calculate stress components at an arbitrary angle.

        Parameters
        ----------
        theta : float
            Rotation angle in degrees from original x-axis.

        Returns
        -------
        tuple
            (sigma_n, tau_n) — normal and shear stress on rotated plane.

        Notes
        -----
        .. math::
            \\sigma_n = \\frac{\\sigma_x + \\sigma_y}{2} +
            \\frac{\\sigma_x - \\sigma_y}{2}\\cos 2\\theta + \\tau_{xy}\\sin 2\\theta

            \\tau_n = -\\frac{\\sigma_x - \\sigma_y}{2}\\sin 2\\theta +
            \\tau_{xy}\\cos 2\\theta
        """
        theta_rad = np.radians(theta)
        sx, sy, txy = self.state.sigma_x, self.state.sigma_y, self.state.tau_xy

        sigma_n = (
            (sx + sy) / 2
            + (sx - sy) / 2 * np.cos(2 * theta_rad)
            + txy * np.sin(2 * theta_rad)
        )
        tau_n = (
            -(sx - sy) / 2 * np.sin(2 * theta_rad)
            + txy * np.cos(2 * theta_rad)
        )
        return float(sigma_n), float(tau_n)

    def plot(self, show: bool = True, save: str | None = None) -> None:
        """Plot Mohr's Circle.

        Parameters
        ----------
        show : bool
            Whether to display the plot.
        save : str, optional
            File path to save the figure.
        """
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(8, 8))

        # Draw circle
        theta = np.linspace(0, 2 * np.pi, 200)
        cx = self.center + self.radius * np.cos(theta)
        cy = self.radius * np.sin(theta)
        ax.plot(cx, cy, "b-", linewidth=2)

        # Mark principal stresses
        ax.plot(self.sigma_1, 0, "ro", markersize=10, label=f"σ₁ = {self.sigma_1:.1f}")
        ax.plot(self.sigma_2, 0, "go", markersize=10, label=f"σ₂ = {self.sigma_2:.1f}")
        ax.plot(self.center, 0, "k+", markersize=12, markeredgewidth=2)

        # Mark original stress state
        ax.plot(
            self.state.sigma_x,
            self.state.tau_xy,
            "bs",
            markersize=10,
            label=f"X-face ({self.state.sigma_x:.1f}, {self.state.tau_xy:.1f})",
        )
        ax.plot(
            self.state.sigma_y,
            -self.state.tau_xy,
            "rs",
            markersize=10,
            label=f"Y-face ({self.state.sigma_y:.1f}, {-self.state.tau_xy:.1f})",
        )

        # Connect X and Y faces
        ax.plot(
            [self.state.sigma_x, self.state.sigma_y],
            [self.state.tau_xy, -self.state.tau_xy],
            "k--",
            alpha=0.5,
        )

        ax.axhline(y=0, color="k", linewidth=0.5)
        ax.axvline(x=0, color="k", linewidth=0.5)
        ax.set_xlabel("Normal Stress σ (MPa)")
        ax.set_ylabel("Shear Stress τ (MPa)")
        ax.set_title(
            f"Mohr's Circle — C = {self.center:.1f}, R = {self.radius:.1f}, "
            f"τ_max = {self.tau_max:.1f}"
        )
        ax.legend()
        ax.set_aspect("equal")
        ax.grid(True, alpha=0.3)

        if save:
            plt.savefig(save, dpi=150, bbox_inches="tight")
        if show:
            plt.show()
        plt.close()
