"""
MechForge Structural Analysis Module.

Complete linear and nonlinear structural analysis capabilities from simple
beam theory to stress analysis, fatigue, and fracture mechanics.

Complies with ASME, Eurocode, and AISC standards.
"""

from __future__ import annotations

from mechforge.structural.beam import Beam, BeamResult, PointLoad, DistributedLoad, Support
from mechforge.structural.stress import (
    StressState,
    MohrsCircle,
    stress_concentration_factor,
    von_mises,
    max_shear,
    principal_stresses,
)
from mechforge.structural.fatigue import FatigueAnalysis, FatigueResult
from mechforge.structural.fracture import (
    stress_intensity_factor,
    paris_law_cycles,
    critical_crack_length,
)

__all__ = [
    # Beam analysis
    "Beam",
    "BeamResult",
    "PointLoad",
    "DistributedLoad",
    "Support",
    # Stress analysis
    "StressState",
    "MohrsCircle",
    "stress_concentration_factor",
    "von_mises",
    "max_shear",
    "principal_stresses",
    # Fatigue
    "FatigueAnalysis",
    "FatigueResult",
    # Fracture mechanics
    "stress_intensity_factor",
    "paris_law_cycles",
    "critical_crack_length",
]
