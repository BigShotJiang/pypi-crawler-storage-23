"""
Fatigue Analysis — S-N Curves, Goodman/Gerber/Soderberg Diagrams, Miner's Rule.

Complete fatigue life prediction with surface finish, size, reliability,
and temperature correction factors per Shigley's approach.

References
----------
.. [1] Shigley's MED, 11th Ed., Chapter 6
.. [2] ASME FFS-1/API 579-1
.. [3] BS 7608 — Fatigue Design of Welded Steel Structures
.. [4] Norton, Machine Design, 6th Ed., Chapter 6

Examples
--------
>>> from mechforge.structural.fatigue import FatigueAnalysis
>>> from mechforge.core.materials import get_material
>>> fa = FatigueAnalysis(
...     material=get_material('AISI 4340'),
...     surface_finish='ground',
...     loading_type='bending',
...     reliability=0.99,
... )
>>> result = fa.predict_life(sigma_max=450, sigma_min=-200)
>>> print(f'Fatigue life: {result.cycles:.2e} cycles')
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional

import numpy as np

from mechforge.core.materials import Material
from mechforge.core.exceptions import ValidationError


# Surface finish factors (Shigley Table 6-2)
_SURFACE_FACTORS = {
    "ground": (1.58, -0.085),
    "machined": (4.51, -0.265),
    "cold_drawn": (4.51, -0.265),
    "hot_rolled": (57.7, -0.718),
    "as_forged": (272.0, -0.995),
    "polished": (1.0, 0.0),  # k_a = 1.0
    "mirror_polished": (1.0, 0.0),
}

# Reliability factors (Shigley Table 6-4)
_RELIABILITY_FACTORS = {
    0.50: 1.000,
    0.90: 0.897,
    0.95: 0.868,
    0.99: 0.814,
    0.999: 0.753,
    0.9999: 0.702,
    0.99999: 0.659,
}


@dataclass
class FatigueResult:
    """Results from fatigue analysis.

    Attributes
    ----------
    cycles : float
        Predicted fatigue life in cycles.
    safety_factor : float
        Fatigue safety factor.
    Se : float
        Corrected endurance limit [MPa].
    Se_prime : float
        Uncorrected endurance limit [MPa].
    sigma_a : float
        Alternating stress [MPa].
    sigma_m : float
        Mean stress [MPa].
    k_a : float
        Surface finish factor.
    k_b : float
        Size factor.
    k_c : float
        Loading type factor.
    k_d : float
        Temperature factor.
    k_e : float
        Reliability factor.
    criterion : str
        Failure criterion used.
    infinite_life : bool
        Whether the component has infinite life.
    """

    cycles: float
    safety_factor: float
    Se: float
    Se_prime: float
    sigma_a: float
    sigma_m: float
    k_a: float
    k_b: float
    k_c: float
    k_d: float
    k_e: float
    criterion: str
    infinite_life: bool


class FatigueAnalysis:
    """Complete fatigue life analysis per Shigley's approach.

    Parameters
    ----------
    material : Material
        Engineering material from the materials database.
    surface_finish : str
        Surface condition: 'polished', 'ground', 'machined', 'cold_drawn',
        'hot_rolled', 'as_forged'.
    loading_type : str
        Load type: 'bending', 'axial', or 'torsion'.
    diameter : float, optional
        Specimen diameter in mm for size factor. Default 7.62 (test specimen).
    temperature : float, optional
        Operating temperature in °C. Default 20.
    reliability : float, optional
        Required reliability (0-1). Default 0.50.
    Kt : float, optional
        Stress concentration factor. Default 1.0.
    q : float, optional
        Notch sensitivity (0-1). Default 1.0.

    Notes
    -----
    The corrected endurance limit is:

    .. math:: S_e = k_a \\cdot k_b \\cdot k_c \\cdot k_d \\cdot k_e \\cdot k_f \\cdot S_e'

    Where:
    - :math:`k_a` = surface factor
    - :math:`k_b` = size factor
    - :math:`k_c` = loading factor
    - :math:`k_d` = temperature factor
    - :math:`k_e` = reliability factor
    - :math:`k_f` = miscellaneous / fatigue stress concentration

    References
    ----------
    .. [1] Shigley's MED, 11th Ed., Chapter 6
    """

    def __init__(
        self,
        material: Material,
        surface_finish: str = "machined",
        loading_type: Literal["bending", "axial", "torsion"] = "bending",
        diameter: float = 7.62,
        temperature: float = 20.0,
        reliability: float = 0.50,
        Kt: float = 1.0,
        q: float = 1.0,
    ) -> None:
        self.material = material
        self.surface_finish = surface_finish
        self.loading_type = loading_type
        self.diameter = diameter
        self.temperature = temperature
        self.reliability = reliability
        self.Kt = Kt
        self.q = q

        # Get ultimate strength in MPa
        self.Sut = material.ultimate_strength.to("MPa").magnitude

        # Calculate correction factors
        self.k_a = self._calc_ka()
        self.k_b = self._calc_kb()
        self.k_c = self._calc_kc()
        self.k_d = self._calc_kd()
        self.k_e = self._calc_ke()
        self.Kf = 1 + q * (Kt - 1)  # Fatigue stress concentration factor

        # Uncorrected endurance limit
        if material.endurance_limit is not None:
            self.Se_prime = material.endurance_limit.to("MPa").magnitude
        else:
            # Approximate: Se' ≈ 0.5*Sut for Sut < 1400 MPa
            if self.Sut <= 1400:
                self.Se_prime = 0.5 * self.Sut
            else:
                self.Se_prime = 700  # Cap at 700 MPa

        # Corrected endurance limit
        self.Se = (
            self.k_a * self.k_b * self.k_c * self.k_d * self.k_e
            * self.Se_prime / self.Kf
        )

    def _calc_ka(self) -> float:
        """Surface finish factor (Shigley Eq. 6-18).

        .. math:: k_a = a \\cdot S_{ut}^b
        """
        if self.surface_finish in _SURFACE_FACTORS:
            a, b = _SURFACE_FACTORS[self.surface_finish]
            if b == 0:
                return 1.0
            return float(a * self.Sut**b)
        return 1.0

    def _calc_kb(self) -> float:
        """Size factor (Shigley Eq. 6-19, 6-20).

        For rotating round specimens:
        - 2.79 ≤ d ≤ 51 mm: kb = 1.24*d^(-0.107)
        - 51 < d ≤ 254 mm: kb = 1.51*d^(-0.157)
        """
        d = self.diameter  # mm
        if self.loading_type == "axial":
            return 1.0
        if d <= 2.79:
            return 1.0
        elif d <= 51:
            return float(1.24 * d**(-0.107))
        elif d <= 254:
            return float(1.51 * d**(-0.157))
        return 0.6

    def _calc_kc(self) -> float:
        """Loading type factor (Shigley Table 6-3)."""
        factors = {"bending": 1.0, "axial": 0.85, "torsion": 0.59}
        return factors.get(self.loading_type, 1.0)

    def _calc_kd(self) -> float:
        """Temperature factor (Shigley Eq. 6-26).

        For T ≤ 450°C: kd ≈ 1.0
        For T > 450°C: kd decreases
        """
        T = self.temperature  # °C
        if T <= 50:
            return 1.0
        elif T <= 450:
            return 1.0 - 0.0005 * (T - 50)
        elif T <= 550:
            return 0.8 - 0.001 * (T - 450)
        return 0.5

    def _calc_ke(self) -> float:
        """Reliability factor (Shigley Table 6-4)."""
        # Find closest reliability value
        closest = min(_RELIABILITY_FACTORS.keys(), key=lambda x: abs(x - self.reliability))
        return _RELIABILITY_FACTORS[closest]

    def predict_life(
        self,
        sigma_max: float,
        sigma_min: float,
        criterion: Literal["goodman", "gerber", "soderberg"] = "goodman",
    ) -> FatigueResult:
        """Predict fatigue life for given cyclic stress.

        Parameters
        ----------
        sigma_max : float
            Maximum stress in cycle [MPa].
        sigma_min : float
            Minimum stress in cycle [MPa].
        criterion : str
            Failure criterion: 'goodman', 'gerber', or 'soderberg'.

        Returns
        -------
        FatigueResult
            Complete fatigue analysis results.

        Notes
        -----
        Modified Goodman criterion:

        .. math:: \\frac{\\sigma_a}{S_e} + \\frac{\\sigma_m}{S_{ut}} = \\frac{1}{n}

        Gerber criterion:

        .. math:: \\frac{\\sigma_a}{S_e} + \\left(\\frac{\\sigma_m}{S_{ut}}\\right)^2
                  = \\frac{1}{n}

        Soderberg criterion:

        .. math:: \\frac{\\sigma_a}{S_e} + \\frac{\\sigma_m}{S_y} = \\frac{1}{n}

        References
        ----------
        .. [1] Shigley's MED, 11th Ed., Eqs. (6-39) to (6-47)
        """
        sigma_a = abs(sigma_max - sigma_min) / 2  # Alternating stress
        sigma_m = (sigma_max + sigma_min) / 2  # Mean stress

        Sy = self.material.yield_strength.to("MPa").magnitude

        # Safety factor calculation
        if criterion == "goodman":
            denom = sigma_a / self.Se + abs(sigma_m) / self.Sut
            n = 1.0 / denom if denom > 0 else float("inf")
        elif criterion == "gerber":
            if sigma_m == 0:
                n = self.Se / sigma_a if sigma_a > 0 else float("inf")
            else:
                A = (sigma_m / self.Sut) ** 2
                B = sigma_a / self.Se
                n = 1.0 / (B + A) if (B + A) > 0 else float("inf")
        elif criterion == "soderberg":
            denom = sigma_a / self.Se + abs(sigma_m) / Sy
            n = 1.0 / denom if denom > 0 else float("inf")
        else:
            raise ValidationError(f"Unknown criterion: {criterion}")

        # Fatigue life estimation using S-N curve
        infinite_life = sigma_a <= self.Se

        if infinite_life:
            cycles = float("inf")
        else:
            # S-N curve: S = a * N^b
            # At N=1e3, S ≈ 0.9*Sut (bending)
            # At N=1e6, S = Se
            f = 0.9  # Fraction of Sut at 1000 cycles
            S_1e3 = f * self.Sut
            a_sn = (S_1e3**2) / self.Se
            b_sn = -np.log10(S_1e3 / self.Se) / 3

            if b_sn != 0:
                cycles = 10 ** ((np.log10(sigma_a) - np.log10(a_sn)) / b_sn)
                cycles = max(1.0, min(cycles, 1e15))
            else:
                cycles = float("inf")

        return FatigueResult(
            cycles=cycles,
            safety_factor=n,
            Se=self.Se,
            Se_prime=self.Se_prime,
            sigma_a=sigma_a,
            sigma_m=sigma_m,
            k_a=self.k_a,
            k_b=self.k_b,
            k_c=self.k_c,
            k_d=self.k_d,
            k_e=self.k_e,
            criterion=criterion,
            infinite_life=infinite_life,
        )

    def miners_rule(
        self,
        stress_ranges: list[tuple[float, float]],
        cycle_counts: list[float],
    ) -> float:
        """Miner's rule cumulative damage calculation.

        Parameters
        ----------
        stress_ranges : list of tuple
            List of (sigma_max, sigma_min) pairs for each load level.
        cycle_counts : list of float
            Number of cycles at each load level.

        Returns
        -------
        float
            Cumulative damage ratio D (failure predicted when D ≥ 1).

        Notes
        -----
        .. math:: D = \\sum_{i=1}^{k} \\frac{n_i}{N_i}

        Where :math:`n_i` is the number of cycles at stress level i,
        and :math:`N_i` is the life at that stress level.

        References
        ----------
        .. [1] Miner, M.A. (1945). ASME J. Appl. Mech., 12(3), A159-A164.
        """
        if len(stress_ranges) != len(cycle_counts):
            raise ValidationError("stress_ranges and cycle_counts must have same length.")

        D = 0.0
        for (s_max, s_min), n in zip(stress_ranges, cycle_counts):
            result = self.predict_life(s_max, s_min)
            if result.cycles > 0 and not result.infinite_life:
                D += n / result.cycles
        return D

    def plot_goodman_diagram(
        self,
        sigma_a: float | None = None,
        sigma_m: float | None = None,
        show: bool = True,
        save: str | None = None,
    ) -> None:
        """Plot modified Goodman diagram.

        Parameters
        ----------
        sigma_a : float, optional
            Alternating stress to plot as operating point.
        sigma_m : float, optional
            Mean stress to plot as operating point.
        show : bool
            Whether to display the plot.
        save : str, optional
            File path to save the figure.
        """
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(10, 7))

        Sy = self.material.yield_strength.to("MPa").magnitude
        Se = self.Se
        Sut = self.Sut

        # Goodman line
        ax.plot([0, Sut], [Se, 0], "b-", linewidth=2, label="Modified Goodman")

        # Gerber curve
        sm = np.linspace(0, Sut, 100)
        sa_gerber = Se * (1 - (sm / Sut) ** 2)
        ax.plot(sm, sa_gerber, "r--", linewidth=1.5, label="Gerber")

        # Soderberg line
        ax.plot([0, Sy], [Se, 0], "g-.", linewidth=1.5, label="Soderberg")

        # Yield line
        ax.plot([0, Sy], [Sy, 0], "k:", linewidth=1, label="Yield line")

        # Operating point
        if sigma_a is not None and sigma_m is not None:
            ax.plot(sigma_m, sigma_a, "ko", markersize=12, label=f"Operating ({sigma_m:.0f}, {sigma_a:.0f})")
            # Load line from origin
            ax.plot([0, sigma_m * 2], [0, sigma_a * 2], "k--", alpha=0.3)

        ax.set_xlabel("Mean Stress σ_m (MPa)")
        ax.set_ylabel("Alternating Stress σ_a (MPa)")
        ax.set_title(f"Fatigue Diagram — {self.material.name} (Se = {Se:.0f} MPa)")
        ax.legend()
        ax.set_xlim(left=-Sut * 0.1)
        ax.set_ylim(bottom=0)
        ax.grid(True, alpha=0.3)

        if save:
            plt.savefig(save, dpi=150, bbox_inches="tight")
        if show:
            plt.show()
        plt.close()

    def plot_sn_curve(
        self,
        show: bool = True,
        save: str | None = None,
    ) -> None:
        """Plot S-N (Wöhler) curve.

        Parameters
        ----------
        show : bool
            Whether to display the plot.
        save : str, optional
            File path to save the figure.
        """
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(10, 7))

        f = 0.9
        S_1e3 = f * self.Sut
        a_sn = (S_1e3**2) / self.Se
        b_sn = -np.log10(S_1e3 / self.Se) / 3

        N = np.logspace(1, 9, 500)
        S = a_sn * N**b_sn
        S = np.clip(S, 0, self.Sut)

        # Cap at endurance limit
        S[N > 1e6] = self.Se

        ax.loglog(N, S, "b-", linewidth=2)
        ax.axhline(y=self.Se, color="r", linestyle="--", alpha=0.7, label=f"Se = {self.Se:.0f} MPa")
        ax.plot(1e3, S_1e3, "ro", markersize=8, label=f"S(10³) = {S_1e3:.0f} MPa")
        ax.plot(1e6, self.Se, "go", markersize=8, label=f"S(10⁶) = {self.Se:.0f} MPa")

        ax.set_xlabel("Cycles to Failure N")
        ax.set_ylabel("Alternating Stress S (MPa)")
        ax.set_title(f"S-N Curve — {self.material.name}")
        ax.legend()
        ax.grid(True, alpha=0.3, which="both")
        ax.set_xlim(1e1, 1e9)

        if save:
            plt.savefig(save, dpi=150, bbox_inches="tight")
        if show:
            plt.show()
        plt.close()
