"""
MechForge Visualization Module (Stub).

Engineering-specific plotting utilities: Mohr's circles, stress
distributions, Goodman diagrams, system curves, and results dashboards.

Requires matplotlib (included in base install).
"""

from __future__ import annotations

from typing import Optional, Sequence

import numpy as np


def plot_engineering_chart(
    x_data: Sequence[float],
    y_data: Sequence[float],
    title: str = "Engineering Chart",
    xlabel: str = "X",
    ylabel: str = "Y",
    grid: bool = True,
    style: str = "seaborn-v0_8-whitegrid",
    save_path: Optional[str] = None,
) -> None:
    """Create a styled engineering chart.

    Parameters
    ----------
    x_data, y_data : array-like
        Data to plot.
    title : str
        Chart title.
    xlabel, ylabel : str
        Axis labels.
    grid : bool
        Show grid lines.
    style : str
        Matplotlib style.
    save_path : str, optional
        Path to save figure.
    """
    import matplotlib.pyplot as plt

    try:
        plt.style.use(style)
    except OSError:
        pass

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(x_data, y_data, "b-", linewidth=2)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    if grid:
        ax.grid(True, alpha=0.3)
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


def plot_multi_series(
    x_data: Sequence[float],
    y_series: dict[str, Sequence[float]],
    title: str = "",
    xlabel: str = "X",
    ylabel: str = "Y",
    save_path: Optional[str] = None,
) -> None:
    """Plot multiple data series on one chart."""
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 6))
    for label, y in y_series.items():
        ax.plot(x_data, y, linewidth=2, label=label)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


__all__ = ["plot_engineering_chart", "plot_multi_series"]
