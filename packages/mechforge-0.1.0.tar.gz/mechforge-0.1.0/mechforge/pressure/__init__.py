"""
MechForge Pressure Vessel Module (Stub).

ASME BPVC-compliant pressure vessel design — thick/thin wall theory,
heads (elliptical, hemispherical, torispherical), nozzle reinforcement.
Full implementation planned for v0.2.0.
"""

from __future__ import annotations

import numpy as np
from mechforge.core.units import Q


def thin_wall_hoop_stress(
    pressure: float,
    radius: float,
    thickness: float,
) -> float:
    """Thin-wall hoop (circumferential) stress.

    .. math:: \\sigma_h = \\frac{pR}{t}

    Parameters
    ----------
    pressure : float
        Internal pressure [Pa].
    radius : float
        Mean radius [m].
    thickness : float
        Wall thickness [m].

    Returns
    -------
    float
        Hoop stress [Pa].
    """
    return pressure * radius / thickness if thickness > 0 else 0


def thin_wall_axial_stress(
    pressure: float,
    radius: float,
    thickness: float,
) -> float:
    """Thin-wall axial (longitudinal) stress.

    .. math:: \\sigma_a = \\frac{pR}{2t}

    Parameters
    ----------
    pressure : float
        Internal pressure [Pa].
    radius : float
        Mean radius [m].
    thickness : float
        Wall thickness [m].

    Returns
    -------
    float
        Axial stress [Pa].
    """
    return pressure * radius / (2 * thickness) if thickness > 0 else 0


def thick_wall_stress(
    pressure_inner: float,
    pressure_outer: float,
    r_inner: float,
    r_outer: float,
    r: float,
) -> dict:
    """Lamé equations for thick-walled cylinder.

    Parameters
    ----------
    pressure_inner : float
        Internal pressure [Pa].
    pressure_outer : float
        External pressure [Pa].
    r_inner : float
        Inner radius [m].
    r_outer : float
        Outer radius [m].
    r : float
        Radius at which to evaluate stresses [m].

    Returns
    -------
    dict
        {'sigma_r': radial, 'sigma_t': tangential} [Pa].
    """
    ri, ro = r_inner, r_outer
    pi, po = pressure_inner, pressure_outer

    A = (pi * ri**2 - po * ro**2) / (ro**2 - ri**2)
    B = (pi - po) * ri**2 * ro**2 / (ro**2 - ri**2)

    sigma_r = A - B / r**2
    sigma_t = A + B / r**2

    return {"sigma_r": sigma_r, "sigma_t": sigma_t}


def minimum_wall_thickness_asme(
    pressure: float,
    radius: float,
    allowable_stress: float,
    joint_efficiency: float = 1.0,
) -> float:
    """ASME BPVC minimum wall thickness for cylindrical shell.

    Parameters
    ----------
    pressure : float
        Design pressure [Pa].
    radius : float
        Inner radius [m].
    allowable_stress : float
        Allowable stress [Pa].
    joint_efficiency : float
        Weld joint efficiency (0-1).

    Returns
    -------
    float
        Minimum required wall thickness [m].
    """
    return pressure * radius / (allowable_stress * joint_efficiency - 0.6 * pressure)


__all__ = [
    "thin_wall_hoop_stress",
    "thin_wall_axial_stress",
    "thick_wall_stress",
    "minimum_wall_thickness_asme",
]
