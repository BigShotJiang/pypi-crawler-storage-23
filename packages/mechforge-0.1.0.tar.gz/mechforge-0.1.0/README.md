# MechForge 🔧⚙️

**Next-Generation Mechanical Engineering Python Platform**

*Structural Analysis • Thermodynamics • Fluid Mechanics • Machine Design • Dynamics • Controls • Materials • Manufacturing • AI/ML • Industry 4.0*

---

## Vision

To become the **NumPy/SciPy of mechanical engineering** — the foundational, trusted computational layer that every mechanical engineer, researcher, and industrial developer reaches for by default.

## Features

### Phase 1 — Foundation (Current)
- ✅ **Unit System** — Pint-based, every value carries units (SI, Imperial, mixed)
- ✅ **Materials Database** — 500+ engineering materials with full property sets
- ✅ **Structural Analysis** — Beam analysis, stress transformation, fatigue, fracture mechanics
- ✅ **Machine Design** — Shafts, gears, bearings, bolted joints, springs
- ✅ **Fluids** — Pipe flow, pump systems, compressible flow
- ✅ **Thermal** — Thermodynamic cycles, heat transfer, heat exchangers
- ✅ **Reports** — Auto-generated PDF/Word engineering reports

### Upcoming
- 🔜 Dynamics & Vibration
- 🔜 Controls (PID, state-space)
- 🔜 AI/ML (Predictive maintenance, optimization, anomaly detection)
- 🔜 Industry 4.0 (IoT, OPC-UA, MQTT, Digital Twins)
- 🔜 FEM Solver & Simplified CFD
- 🔜 Manufacturing (GD&T, DFM)

## Quick Start

```bash
pip install mechforge
```

```python
import mechforge as mf

# Every value carries units — no ambiguity
shaft = mf.machine.Shaft(
    length=mf.Q(500, 'mm'),
    torque=mf.Q(200, 'N*m'),
    material=mf.materials.get('AISI 4140'),
)

result = shaft.analyze()
print(result.max_shear_stress.to('MPa'))
print(result.safety_factor)
```

### Fatigue Analysis
```python
from mechforge.structural import FatigueAnalysis
from mechforge.materials import get_material

analysis = FatigueAnalysis(
    material=get_material('AISI 4340'),
    surface_finish='ground',
    loading_type='bending',
    reliability=0.99,
)
life = analysis.predict_life(sigma_max=450, sigma_min=-200)
print(f'Fatigue life: {life.cycles:.2e} cycles')
analysis.plot_goodman_diagram(save='goodman.pdf')
```

### Heat Exchanger
```python
from mechforge.thermal import HeatExchanger

hx = HeatExchanger(
    method='LMTD',
    hot_inlet=mf.Q(150, 'degC'), hot_outlet=mf.Q(90, 'degC'),
    cold_inlet=mf.Q(25, 'degC'), cold_outlet=mf.Q(70, 'degC'),
    U=mf.Q(500, 'W/(m**2*K)'),
    flow_type='counterflow',
)
result = hx.analyze()
print(f'Required area: {result.area.to("m**2"):.2f}')
```

## Standards Compliance

MechForge implements and references major engineering standards:

| Domain | Standards |
|--------|-----------|
| Shafts | ASME B106, DIN 743 |
| Gears | AGMA 2101-D04, ISO 6336 |
| Fasteners | VDI 2230, ASME B1.1 |
| Fatigue | ASME FFS-1, BS 7910 |
| Pressure Vessels | ASME BPVC VIII |
| Piping | ASME B31.1, B31.3 |

## Architecture

```
mechforge/
├── core/          # Units, constants, materials DB, exceptions
├── structural/    # FEA, beam analysis, stress/strain, fatigue
├── thermal/       # Heat transfer, thermodynamic cycles
├── fluids/        # Pipe networks, pump systems, compressible flow
├── machine/       # Gears, shafts, bearings, springs, bolts
├── dynamics/      # Vibration, modal analysis, rotor dynamics
├── manufacturing/ # GD&T, tolerance stack-up, DFM
├── materials/     # Material DB, selection, composites
├── controls/      # PID, state-space, transfer functions
├── pressure/      # ASME VIII vessels, B31.3 piping
├── energy/        # Turbomachinery, renewables
├── ai/            # Predictive, optimization, anomaly, NLP, vision
├── industry40/    # IoT, OPC-UA, MQTT, digital twins
├── simulation/    # FEM, CFD, MBD, Monte Carlo
├── solvers/       # Shared numerical solvers
├── viz/           # 2D/3D visualization
├── standards/     # Code lookups & compliance
├── reports/       # PDF, Word, HTML, Excel reports
├── database/      # SQLite, PostgreSQL, InfluxDB
├── api/           # FastAPI REST layer
└── cli/           # Command-line interface
```

## Development

```bash
git clone https://github.com/mechforge/mechforge.git
cd mechforge
pip install -e ".[dev]"
pytest
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License — Free for everyone.

---

**MechForge — Built by Engineers, for Engineers** 🏗️
