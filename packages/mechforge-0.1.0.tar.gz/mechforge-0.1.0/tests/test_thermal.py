"""Tests for MechForge thermal module."""

import pytest
import numpy as np


class TestCycles:
    """Test thermodynamic cycle analysis."""

    def test_otto_efficiency(self):
        from mechforge.thermal.cycles import OttoCycle
        otto = OttoCycle(compression_ratio=8)
        result = otto.analyze()
        expected = 1 - 1 / 8**0.4
        assert result.efficiency == pytest.approx(expected, rel=0.01)

    def test_diesel_efficiency(self):
        from mechforge.thermal.cycles import DieselCycle
        diesel = DieselCycle(compression_ratio=18, cutoff_ratio=2.0)
        result = diesel.analyze()
        assert 0.3 < result.efficiency < 0.8

    def test_brayton_efficiency(self):
        from mechforge.thermal.cycles import BraytonCycle
        brayton = BraytonCycle(pressure_ratio=10)
        result = brayton.analyze()
        expected = 1 - 1 / 10**(0.4 / 1.4)
        assert result.efficiency == pytest.approx(expected, rel=0.05)

    def test_brayton_regenerative(self):
        from mechforge.thermal.cycles import BraytonCycle
        b_no_regen = BraytonCycle(pressure_ratio=8, regenerator=False)
        b_regen = BraytonCycle(pressure_ratio=8, regenerator=True)
        r1 = b_no_regen.analyze()
        r2 = b_regen.analyze()
        assert r2.efficiency > r1.efficiency

    def test_rankine_cycle(self):
        from mechforge.thermal.cycles import RankineCycle
        from mechforge.core.units import Q
        rankine = RankineCycle(
            boiler_pressure=Q(10, "MPa"),
            condenser_pressure=Q(10, "kPa"),
        )
        result = rankine.analyze()
        assert result.efficiency > 0
        assert result.net_work.magnitude > 0

    def test_otto_result_summary(self):
        from mechforge.thermal.cycles import OttoCycle
        otto = OttoCycle()
        result = otto.analyze()
        summary = result.summary()
        assert "efficiency" in summary.lower() or "Otto" in summary


class TestHeatTransfer:
    """Test heat transfer calculations."""

    def test_conduction_plane(self):
        from mechforge.thermal.heat_transfer import conduction_resistance
        from mechforge.core.units import Q
        R = conduction_resistance(
            thickness=Q(0.1, "m"), area=Q(1, "m**2"),
            conductivity=Q(50, "W/(m*K)"),
        )
        expected = 0.1 / (50 * 1)
        assert R.magnitude == pytest.approx(expected, rel=0.01)

    def test_convection_resistance(self):
        from mechforge.thermal.heat_transfer import convection_resistance
        from mechforge.core.units import Q
        R = convection_resistance(h=Q(100, "W/(m**2*K)"), area=Q(2, "m**2"))
        expected = 1 / (100 * 2)
        assert R.magnitude == pytest.approx(expected, rel=0.01)

    def test_radiation_heat_flux(self):
        from mechforge.thermal.heat_transfer import radiation_heat_flux
        from mechforge.core.units import Q
        q = radiation_heat_flux(
            T_surface=Q(500, "K"), T_surround=Q(300, "K"), emissivity=0.9,
        )
        sigma = 5.67e-8
        expected = 0.9 * sigma * (500**4 - 300**4)
        assert q.magnitude == pytest.approx(expected, rel=0.01)

    def test_fin_efficiency_rectangular(self):
        from mechforge.thermal.heat_transfer import fin_efficiency
        from mechforge.core.units import Q
        result = fin_efficiency(
            fin_type="rectangular",
            length=Q(30, "mm"), thickness=Q(2, "mm"),
            h=Q(50, "W/(m**2*K)"), k=Q(200, "W/(m*K)"),
        )
        assert 0 < result["efficiency"] <= 1.0

    def test_overall_heat_transfer(self):
        from mechforge.thermal.heat_transfer import overall_heat_transfer
        from mechforge.core.units import Q
        result = overall_heat_transfer(
            layers=[{"thickness": Q(0.01, "m"), "conductivity": Q(50, "W/(m*K)")}],
            h_inner=Q(500, "W/(m**2*K)"),
            h_outer=Q(50, "W/(m**2*K)"),
            area=Q(1, "m**2"),
            T_hot=Q(400, "K"),
            T_cold=Q(300, "K"),
        )
        assert result.heat_flux.magnitude > 0
        assert result.resistance.magnitude > 0


class TestHeatExchangers:
    """Test heat exchanger design."""

    def test_lmtd_counterflow(self):
        from mechforge.thermal.heat_exchangers import HeatExchanger
        from mechforge.core.units import Q
        hx = HeatExchanger(
            type="counterflow",
            Th_in=Q(150, "degC"), Th_out=Q(90, "degC"),
            Tc_in=Q(20, "degC"), Tc_out=Q(60, "degC"),
            U=Q(500, "W/(m**2*K)"), Q_duty=Q(100, "kW"),
        )
        result = hx.design_LMTD()
        assert result.area.magnitude > 0
        assert result.LMTD.magnitude > 0
        assert result.F_correction == 1.0

    def test_ntu_method(self):
        from mechforge.thermal.heat_exchangers import HeatExchanger
        from mechforge.core.units import Q
        hx = HeatExchanger(
            type="counterflow",
            Th_in=Q(150, "degC"), Th_out=Q(90, "degC"),
            Tc_in=Q(20, "degC"), Tc_out=Q(60, "degC"),
            U=Q(500, "W/(m**2*K)"),
            mh_cp=Q(1667, "W/K"),
            mc_cp=Q(2500, "W/K"),
        )
        result = hx.design_NTU()
        assert result.effectiveness > 0
        assert result.NTU > 0
        assert result.area.magnitude > 0
