"""Tests for MechForge fluids module."""

import pytest
import numpy as np


class TestPipeFlow:
    """Test pipe flow calculations."""

    def test_reynolds_number(self):
        from mechforge.fluids.pipe_flow import reynolds_number
        from mechforge.core.units import Q
        Re = reynolds_number(
            velocity=Q(2, "m/s"), diameter=Q(0.1, "m"),
            density=Q(998, "kg/m**3"), viscosity=Q(1e-3, "Pa*s"),
        )
        assert Re == pytest.approx(199600, rel=0.01)

    def test_friction_factor_laminar(self):
        from mechforge.fluids.pipe_flow import friction_factor
        f = friction_factor(Re=1000, relative_roughness=0.001)
        assert f == pytest.approx(0.064, rel=0.01)

    def test_friction_factor_turbulent(self):
        from mechforge.fluids.pipe_flow import friction_factor
        f = friction_factor(Re=100000, relative_roughness=0.001)
        assert 0.01 < f < 0.05

    def test_colebrook_vs_swamee(self):
        from mechforge.fluids.pipe_flow import friction_factor
        f_sj = friction_factor(Re=50000, relative_roughness=0.001, method="swamee_jain")
        f_cb = friction_factor(Re=50000, relative_roughness=0.001, method="colebrook")
        assert f_sj == pytest.approx(f_cb, rel=0.05)

    def test_pipe_flow_analysis(self):
        from mechforge.fluids.pipe_flow import PipeFlow
        from mechforge.core.units import Q
        pipe = PipeFlow(
            diameter=Q(100, "mm"), length=Q(50, "m"),
            flow_rate=Q(10, "L/s"), roughness=Q(0.045, "mm"),
        )
        result = pipe.analyze()
        assert result.reynolds > 0
        assert result.pressure_drop.magnitude > 0
        assert result.velocity.to("m/s").magnitude > 0
        assert result.flow_regime in ("laminar", "transitional", "turbulent")

    def test_pipe_flow_with_fittings(self):
        from mechforge.fluids.pipe_flow import PipeFlow
        from mechforge.core.units import Q
        pipe = PipeFlow(
            diameter=Q(100, "mm"), length=Q(50, "m"),
            flow_rate=Q(10, "L/s"),
            fittings={"elbow_90_standard": 3, "gate_valve_full": 1},
        )
        result = pipe.analyze()
        assert result.minor_losses.magnitude > 0


class TestCompressible:
    """Test compressible flow relations."""

    def test_isentropic_mach_1(self):
        from mechforge.fluids.compressible import isentropic_relations
        result = isentropic_relations(Mach=1.0)
        assert result["A_ratio"] == pytest.approx(1.0, rel=0.01)

    def test_isentropic_pressure_ratio(self):
        from mechforge.fluids.compressible import isentropic_relations
        result = isentropic_relations(Mach=2.0)
        assert 0 < result["p_ratio"] < 1
        assert 0 < result["T_ratio"] < 1

    def test_normal_shock_mach_2(self):
        from mechforge.fluids.compressible import normal_shock
        result = normal_shock(M1=2.0)
        assert result["M2"] < 1.0
        assert result["p2_p1"] > 1.0

    def test_fanno_flow(self):
        from mechforge.fluids.compressible import fanno_flow
        result = fanno_flow(Mach=0.5)
        assert result["p_pstar"] > 1.0

    def test_rayleigh_flow(self):
        from mechforge.fluids.compressible import rayleigh_flow
        result = rayleigh_flow(Mach=0.5)
        assert "T_Tstar" in result


class TestExternalFlow:
    """Test external flow calculations."""

    def test_drag_force(self):
        from mechforge.fluids.external_flow import drag_force
        from mechforge.core.units import Q
        Fd = drag_force(
            Cd=0.47, area=Q(0.01, "m**2"),
            velocity=Q(30, "m/s"), density=Q(1.225, "kg/m**3"),
        )
        expected = 0.5 * 0.47 * 1.225 * 30**2 * 0.01
        assert Fd.to("N").magnitude == pytest.approx(expected, rel=0.01)

    def test_lift_force(self):
        from mechforge.fluids.external_flow import lift_force
        from mechforge.core.units import Q
        Fl = lift_force(Cl=1.2, area=Q(15, "m**2"), velocity=Q(60, "m/s"))
        assert Fl.to("N").magnitude > 0

    def test_boundary_layer_laminar(self):
        from mechforge.fluids.external_flow import boundary_layer
        from mechforge.core.units import Q
        bl = boundary_layer(
            x=Q(0.1, "m"), velocity=Q(5, "m/s"),
        )
        assert bl.regime == "laminar"
        assert bl.delta.magnitude > 0
