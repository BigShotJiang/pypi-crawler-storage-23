"""Tests for MechForge core module — units, materials, constants, validators."""

import pytest
import numpy as np


class TestUnits:
    """Test the Pint-based unit system."""

    def test_quantity_creation(self):
        from mechforge.core.units import Q, ureg
        q = Q(100, "MPa")
        assert q.magnitude == 100
        assert str(q.units) in ("megapascal", "MPa")

    def test_unit_conversion(self):
        from mechforge.core.units import Q
        q = Q(1, "m")
        assert q.to("mm").magnitude == pytest.approx(1000)

    def test_to_base_units(self):
        from mechforge.core.units import Q, to_base_units
        q = Q(100, "kPa")
        base = to_base_units(q)
        assert base.to("Pa").magnitude == pytest.approx(100000)

    def test_ensure_quantity(self):
        from mechforge.core.units import Q, ensure_quantity
        result = ensure_quantity(5.0, "m")
        assert result.magnitude == 5.0


class TestMaterials:
    """Test the materials database."""

    def test_get_material_aisi_1045(self):
        from mechforge.core.materials import get_material
        mat = get_material("AISI 1045")
        assert mat.name == "AISI 1045"
        assert mat.category == "steel"
        assert mat.density.magnitude > 0
        assert mat.elastic_modulus.magnitude > 0

    def test_get_material_case_insensitive(self):
        from mechforge.core.materials import get_material
        mat = get_material("aisi 1045")
        assert mat.name == "AISI 1045"

    def test_material_not_found(self):
        from mechforge.core.materials import get_material
        from mechforge.core.exceptions import MaterialNotFoundError
        with pytest.raises(MaterialNotFoundError):
            get_material("NonExistentMaterial12345")

    def test_list_materials(self):
        from mechforge.core.materials import list_materials
        mats = list_materials()
        assert len(mats) >= 100  # Should have 500+

    def test_list_materials_by_category(self):
        from mechforge.core.materials import list_materials
        steels = list_materials("steel")
        assert len(steels) > 10

    def test_material_has_required_properties(self):
        from mechforge.core.materials import get_material
        mat = get_material("AISI 4140")
        assert mat.yield_strength is not None
        assert mat.ultimate_strength is not None
        assert mat.shear_modulus is not None

    def test_aluminum_exists(self):
        from mechforge.core.materials import get_material
        mat = get_material("Aluminum 6061-T6")
        assert mat.category == "aluminum"

    def test_stainless_steel_exists(self):
        from mechforge.core.materials import get_material
        mat = get_material("Stainless 304")
        assert mat.category == "stainless_steel"


class TestConstants:
    """Test physical constants."""

    def test_gravity(self):
        from mechforge.core.constants import PhysicalConstants as PC
        assert PC.g.magnitude == pytest.approx(9.80665, rel=0.01)

    def test_gas_constant(self):
        from mechforge.core.constants import PhysicalConstants as PC
        assert PC.R.to("J/(mol*K)").magnitude == pytest.approx(8.314, rel=0.01)

    def test_stefan_boltzmann(self):
        from mechforge.core.constants import PhysicalConstants as PC
        assert PC.sigma_sb.magnitude == pytest.approx(5.67e-8, rel=0.01)


class TestValidators:
    """Test input validators."""

    def test_validate_positive(self):
        from mechforge.core.units import Q
        from mechforge.core.validators import validate_positive
        validate_positive(Q(5, "m"), "test")

    def test_validate_positive_fails(self):
        from mechforge.core.units import Q
        from mechforge.core.validators import validate_positive
        from mechforge.core.exceptions import ValidationError
        with pytest.raises(ValidationError):
            validate_positive(Q(-1, "m"), "test")

    def test_validate_non_negative(self):
        from mechforge.core.units import Q
        from mechforge.core.validators import validate_non_negative
        validate_non_negative(Q(0, "m"), "test")

    def test_validate_range(self):
        from mechforge.core.validators import validate_range
        validate_range(5, min_val=0, max_val=10, name="test")

    def test_validate_range_fails(self):
        from mechforge.core.validators import validate_range
        from mechforge.core.exceptions import ValidationError
        with pytest.raises(ValidationError):
            validate_range(15, min_val=0, max_val=10, name="test")


class TestExceptions:
    """Test exception hierarchy."""

    def test_base_exception(self):
        from mechforge.core.exceptions import MechForgeError
        assert issubclass(MechForgeError, Exception)

    def test_unit_error(self):
        from mechforge.core.exceptions import UnitError, MechForgeError
        assert issubclass(UnitError, MechForgeError)
