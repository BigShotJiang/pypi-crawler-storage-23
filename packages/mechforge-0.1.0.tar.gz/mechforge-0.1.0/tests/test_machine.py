"""Tests for MechForge machine design module."""

import pytest
import numpy as np


class TestShaft:
    """Test shaft analysis."""

    def test_shaft_creation(self):
        from mechforge.machine.shaft import Shaft
        from mechforge.core.units import Q
        from mechforge.core.materials import get_material
        shaft = Shaft(
            length=Q(500, "mm"),
            diameter=Q(50, "mm"),
            torque=Q(200, "N*m"),
            material=get_material("AISI 4140"),
        )
        result = shaft.analyze()
        assert result.safety_factor > 0
        assert result.max_shear_stress.magnitude > 0
        assert result.critical_speed.magnitude > 0

    def test_shaft_with_bending(self):
        from mechforge.machine.shaft import Shaft
        from mechforge.core.units import Q
        from mechforge.core.materials import get_material
        shaft = Shaft(
            length=Q(500, "mm"),
            diameter=Q(50, "mm"),
            torque=Q(200, "N*m"),
            bending_moment=Q(500, "N*m"),
            material=get_material("AISI 1045"),
        )
        result = shaft.analyze()
        assert result.von_mises_stress.magnitude > result.max_shear_stress.magnitude


class TestGears:
    """Test gear analysis."""

    def test_spur_gear(self):
        from mechforge.machine.gears import SpurGear
        from mechforge.core.units import Q
        gear = SpurGear(
            module=Q(3, "mm"), teeth=24, face_width=Q(30, "mm"),
            power=Q(10, "kW"), speed=Q(1500, "rpm"),
        )
        result = gear.analyze()
        assert result.bending_stress.magnitude > 0
        assert result.contact_stress.magnitude > 0
        assert result.bending_safety_factor > 0
        assert result.pitch_diameter.to("mm").magnitude == pytest.approx(72, rel=0.01)


class TestBearings:
    """Test bearing selection."""

    def test_bearing_analysis(self):
        from mechforge.machine.bearings import BearingSelection
        from mechforge.core.units import Q
        bearing = BearingSelection(
            type="deep_groove", bore=Q(40, "mm"),
            radial_load=Q(5, "kN"), speed=Q(3000, "rpm"),
            desired_life_hours=20000,
        )
        result = bearing.analyze()
        assert result.L10 > 0
        assert result.L10_hours > 0
        assert result.equivalent_load.magnitude > 0

    def test_bearing_with_axial_load(self):
        from mechforge.machine.bearings import BearingSelection
        from mechforge.core.units import Q
        bearing = BearingSelection(
            type="deep_groove", bore=Q(30, "mm"),
            radial_load=Q(3, "kN"), axial_load=Q(1, "kN"),
            speed=Q(1500, "rpm"),
        )
        result = bearing.analyze()
        assert result.equivalent_load.magnitude >= 3


class TestBolts:
    """Test bolted joint analysis."""

    def test_bolt_analysis(self):
        from mechforge.machine.bolts import BoltedJoint
        from mechforge.core.units import Q
        joint = BoltedJoint(
            bolt_diameter=Q(12, "mm"), grade="10.9",
            clamped_length=Q(30, "mm"),
            external_load=Q(15, "kN"),
        )
        result = joint.analyze()
        assert result.preload.magnitude > 0
        assert result.safety_factor_static > 0
        assert result.torque.magnitude > 0

    def test_invalid_grade(self):
        from mechforge.machine.bolts import BoltedJoint
        from mechforge.core.units import Q
        from mechforge.core.exceptions import ValidationError
        with pytest.raises((ValidationError, ValueError)):
            joint = BoltedJoint(bolt_diameter=Q(12, "mm"), grade="99.9")
            joint.analyze()


class TestSprings:
    """Test spring analysis."""

    def test_spring_analysis(self):
        from mechforge.machine.springs import HelicalSpring
        from mechforge.core.units import Q
        spring = HelicalSpring(
            wire_diameter=Q(3, "mm"), mean_coil_diameter=Q(25, "mm"),
            free_length=Q(60, "mm"), active_coils=8,
            material_Sut=Q(1700, "MPa"), material_G=Q(79.3, "GPa"),
        )
        result = spring.analyze(force=Q(100, "N"))
        assert result.spring_rate.magnitude > 0
        assert result.shear_stress.magnitude > 0
        assert result.spring_index == pytest.approx(25 / 3, rel=0.01)
        assert result.safety_factor > 0
