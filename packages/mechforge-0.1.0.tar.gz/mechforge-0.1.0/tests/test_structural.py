"""Tests for MechForge structural module — stress, fatigue, fracture."""

import pytest
import numpy as np


class TestStress:
    """Test stress analysis functions."""

    def test_von_mises_uniaxial(self):
        from mechforge.structural.stress import StressState, von_mises
        state = StressState(sigma_x=200)
        result = von_mises(state)
        assert result == pytest.approx(200, rel=0.01)

    def test_von_mises_pure_shear(self):
        from mechforge.structural.stress import StressState, von_mises
        state = StressState(tau_xy=100)
        result = von_mises(state)
        assert result == pytest.approx(np.sqrt(3) * 100, rel=0.01)

    def test_principal_stresses(self):
        from mechforge.structural.stress import StressState, principal_stresses
        state = StressState(sigma_x=100)
        s1, s2, s3 = principal_stresses(state)
        assert s1 == pytest.approx(100, rel=0.01)
        assert s2 == pytest.approx(0, abs=0.01)
        assert s3 == pytest.approx(0, abs=0.01)

    def test_max_shear(self):
        from mechforge.structural.stress import StressState, max_shear
        state = StressState(sigma_x=100)
        tau_max = max_shear(state)
        assert tau_max == pytest.approx(50, rel=0.01)

    def test_stress_state(self):
        from mechforge.structural.stress import StressState
        state = StressState(sigma_x=100, sigma_y=50, tau_xy=30)
        assert state.sigma_x == 100
        assert state.sigma_y == 50
        assert state.tau_xy == 30

    def test_mohrs_circle(self):
        from mechforge.structural.stress import StressState, MohrsCircle
        state = StressState(sigma_x=100, sigma_y=0, tau_xy=0)
        mc = MohrsCircle(state)
        assert mc.center == pytest.approx(50)
        assert mc.radius == pytest.approx(50)
        assert mc.sigma_1 == pytest.approx(100)
        assert mc.sigma_2 == pytest.approx(0)

    def test_scf_hole_plate(self):
        from mechforge.structural.stress import stress_concentration_factor
        Kt = stress_concentration_factor("hole_plate", d=10, D=100)
        assert 2.5 < Kt < 3.1


class TestFatigue:
    """Test fatigue analysis."""

    def test_fatigue_analysis_creation(self):
        from mechforge.structural.fatigue import FatigueAnalysis
        from mechforge.core.materials import get_material
        mat = get_material("AISI 4140")
        fa = FatigueAnalysis(material=mat)
        result = fa.predict_life(sigma_max=300, sigma_min=-100)
        assert result.safety_factor > 0

    def test_goodman_criterion(self):
        from mechforge.structural.fatigue import FatigueAnalysis
        from mechforge.core.materials import get_material
        mat = get_material("AISI 4140")
        fa = FatigueAnalysis(material=mat)
        result = fa.predict_life(sigma_max=200, sigma_min=0, criterion="goodman")
        assert result.safety_factor > 1.0

    def test_soderberg_more_conservative(self):
        from mechforge.structural.fatigue import FatigueAnalysis
        from mechforge.core.materials import get_material
        mat = get_material("AISI 4140")
        fa = FatigueAnalysis(material=mat)
        r_g = fa.predict_life(sigma_max=300, sigma_min=0, criterion="goodman")
        r_s = fa.predict_life(sigma_max=300, sigma_min=0, criterion="soderberg")
        assert r_s.safety_factor <= r_g.safety_factor + 0.01


class TestFracture:
    """Test fracture mechanics."""

    def test_center_crack_sif(self):
        from mechforge.structural.fracture import stress_intensity_factor
        K = stress_intensity_factor(
            geometry="center_crack", sigma=100, a=0.01
        )
        expected = 100 * np.sqrt(np.pi * 0.01)
        assert K == pytest.approx(expected, rel=0.1)

    def test_critical_crack_length(self):
        from mechforge.structural.fracture import critical_crack_length
        a_c = critical_crack_length(K_IC=50, sigma=200)
        assert a_c > 0

    def test_paris_law_cycles(self):
        from mechforge.structural.fracture import paris_law_cycles
        N = paris_law_cycles(
            C=1e-11, m=3.0, a_initial=0.001, a_final=0.01, sigma=100,
        )
        assert N > 0
