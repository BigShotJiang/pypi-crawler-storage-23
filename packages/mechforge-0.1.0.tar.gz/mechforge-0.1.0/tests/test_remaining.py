"""Tests for remaining MechForge modules (dynamics, controls, etc.)."""

import pytest
import numpy as np


class TestDynamics:
    """Test dynamics module."""

    def test_natural_frequency(self):
        from mechforge.dynamics import sdof_natural_frequency
        fn = sdof_natural_frequency(k=10000, m=1)
        expected = np.sqrt(10000 / 1) / (2 * np.pi)
        assert fn == pytest.approx(expected, rel=0.01)

    def test_damping_ratio(self):
        from mechforge.dynamics import damping_ratio
        zeta = damping_ratio(c=20, k=1000, m=1)
        assert 0 < zeta or zeta >= 0  # Just check it returns a number

    def test_transmissibility(self):
        from mechforge.dynamics import transmissibility
        T = transmissibility(r=0.5, zeta=0.1)
        assert T > 0


class TestControls:
    """Test controls module."""

    def test_ziegler_nichols_pid(self):
        from mechforge.controls import ziegler_nichols_tuning
        gains = ziegler_nichols_tuning(Ku=10, Tu=1.0, controller="PID")
        assert gains.Kp == pytest.approx(6.0)
        assert gains.Ki > 0
        assert gains.Kd > 0

    def test_ziegler_nichols_p(self):
        from mechforge.controls import ziegler_nichols_tuning
        gains = ziegler_nichols_tuning(Ku=10, Tu=1.0, controller="P")
        assert gains.Kp == pytest.approx(5.0)
        assert gains.Ki == 0


class TestManufacturing:
    """Test manufacturing module."""

    def test_taylor_tool_life(self):
        from mechforge.manufacturing import taylor_tool_life
        T = taylor_tool_life(V=100, C=100, n=0.25)
        assert T == pytest.approx(1.0)

    def test_cutting_force(self):
        from mechforge.manufacturing import cutting_force
        F = cutting_force(depth=2, feed=0.2, specific_cutting_force=2000)
        assert F == pytest.approx(800)


class TestPressure:
    """Test pressure vessel module."""

    def test_thin_wall_hoop(self):
        from mechforge.pressure import thin_wall_hoop_stress
        sigma = thin_wall_hoop_stress(pressure=1e6, radius=0.5, thickness=0.01)
        assert sigma == pytest.approx(50e6)

    def test_thin_wall_axial(self):
        from mechforge.pressure import thin_wall_axial_stress
        sigma = thin_wall_axial_stress(pressure=1e6, radius=0.5, thickness=0.01)
        assert sigma == pytest.approx(25e6)


class TestSolvers:
    """Test numerical solvers."""

    def test_bisection(self):
        from mechforge.solvers import bisection
        root = bisection(lambda x: x**2 - 4, 0, 3)
        assert root == pytest.approx(2.0, abs=1e-6)

    def test_newton_raphson(self):
        from mechforge.solvers import newton_raphson
        root = newton_raphson(lambda x: x**2 - 4, lambda x: 2 * x, x0=3)
        assert root == pytest.approx(2.0, abs=1e-6)

    def test_rk4_integration(self):
        from mechforge.solvers import runge_kutta_4
        # dy/dt = -y, y(0) = 1 → y(t) = e^(-t)
        t, y = runge_kutta_4(
            f=lambda t, y: [-y[0]],
            y0=np.array([1.0]),
            t_span=(0, 1),
            dt=0.01,
        )
        assert y[-1, 0] == pytest.approx(np.exp(-1), rel=0.01)


class TestSimulation:
    """Test simulation module."""

    def test_truss_element_stiffness(self):
        from mechforge.simulation import TrussElement
        elem = TrussElement(E=200e9, A=0.001, L=1.0, theta=0)
        K = elem.stiffness_matrix()
        assert K.shape == (4, 4)
        assert K[0, 0] > 0


class TestEnergy:
    """Test energy module."""

    def test_wind_power(self):
        from mechforge.energy import wind_power
        P = wind_power(wind_speed=10, rotor_diameter=50)
        assert P > 0

    def test_solar_output(self):
        from mechforge.energy import solar_panel_output
        P = solar_panel_output(irradiance=1000, area=1.6, efficiency=0.20)
        assert P > 0
