"""Tests for MechForge reports module."""

import pytest


class TestReportGenerator:
    """Test report generation."""

    def test_report_creation(self):
        from mechforge.reports.base import ReportGenerator
        report = ReportGenerator(title="Test Report", project="Test Project")
        assert report.title == "Test Report"

    def test_add_section(self):
        from mechforge.reports.base import ReportGenerator
        report = ReportGenerator()
        section = report.add_section("Analysis", "Sample content")
        assert section.title == "Analysis"
        assert len(report.sections) == 1

    def test_add_result(self):
        from mechforge.reports.base import ReportGenerator
        report = ReportGenerator()
        report.add_result("Safety Factor", 2.5, status="PASS")
        assert len(report.results) == 1

    def test_to_text(self):
        from mechforge.reports.base import ReportGenerator
        report = ReportGenerator(
            title="Test Report", author="Engineer",
            standard="ASME B106.1M",
        )
        report.add_result("Safety Factor", 2.5, status="PASS")
        report.add_conclusion("Design is adequate.")
        text = report.to_text()
        assert "TEST REPORT" in text or "Test Report" in text
        assert "Safety Factor" in text

    def test_to_dict(self):
        from mechforge.reports.base import ReportGenerator
        report = ReportGenerator(title="Test")
        report.add_result("x", 1.0)
        d = report.to_dict()
        assert d["title"] == "Test"
        assert len(d["results"]) == 1

    def test_add_analysis_result(self):
        from mechforge.reports.base import ReportGenerator
        from mechforge.machine.shaft import Shaft
        from mechforge.core.units import Q
        from mechforge.core.materials import get_material

        shaft = Shaft(
            length=Q(500, "mm"), diameter=Q(50, "mm"),
            torque=Q(200, "N*m"), material=get_material("AISI 4140"),
        )
        shaft_result = shaft.analyze()

        report = ReportGenerator(title="Shaft Report")
        report.add_analysis_result(shaft_result)
        assert len(report.results) > 0
