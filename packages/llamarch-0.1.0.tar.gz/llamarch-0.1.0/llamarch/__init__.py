# LLaMArch: Building Block Architectures for GenAI
