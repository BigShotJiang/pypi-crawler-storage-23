"""
miu_bot - A lightweight AI agent framework
"""

__version__ = "0.2.0"
__logo__ = "🐈"
