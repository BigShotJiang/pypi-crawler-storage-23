# Changelog

All notable changes to this project will be documented in this file.

# [9.6.0](https://github.com/qtsone/workflows-mcp/compare/v9.5.0...v9.6.0) (2026-03-05)


### Features

* complete recall and forget operations for Knowledge executor ([604be76](https://github.com/qtsone/workflows-mcp/commit/604be76c02ea9063b6ea0656e9cb3f5300e5f361))

# [9.5.0](https://github.com/qtsone/workflows-mcp/compare/v9.4.0...v9.5.0) (2026-03-04)


### Features

* **engine:** add Knowledge executor for workflow-native knowledge access ([0bd8ef8](https://github.com/qtsone/workflows-mcp/commit/0bd8ef8f8fe5277b4204dc3f1ea589e51af37047))

# [9.4.0](https://github.com/qtsone/workflows-mcp/compare/v9.3.0...v9.4.0) (2026-03-01)


### Bug Fixes

* enable iterations for for_each ([0082e3e](https://github.com/qtsone/workflows-mcp/commit/0082e3e58ff5c2329005ccfbbea2287dc1a38633))


### Features

* Add new test scripts for workflow execution analysis and unified variable resolution. ([8a7563e](https://github.com/qtsone/workflows-mcp/commit/8a7563e7bc5d8ca6b1969d7dea0e11b1437cba51))
* **engine:** emit on_block_transition events for for_each blocks ([1fe7bc7](https://github.com/qtsone/workflows-mcp/commit/1fe7bc7d7a34f0378f82f38f8fc38c0d01ebe1de))
* **engine:** enrich block transition events with inputs and parent references ([8370f0e](https://github.com/qtsone/workflows-mcp/commit/8370f0e40e939fd926533fa790007a3c6fb395b6))

# [9.3.0](https://github.com/qtsone/workflows-mcp/compare/v9.2.0...v9.3.0) (2026-02-24)


### Bug Fixes

* **workflows-mcp:** extract only declared outputs for Workflow block events ([dc4caef](https://github.com/qtsone/workflows-mcp/commit/dc4caef14e358ee97136fe960ba347aa6f088291))
* **workflows-mcp:** migrate Ollama executor to /api/chat with reliable structured output ([3fcb941](https://github.com/qtsone/workflows-mcp/commit/3fcb9417477bbb44c8e9d69ec295441dd5549c7a))


### Features

* **engine:** add generic extra_headers support for LLM providers ([bf3e6a5](https://github.com/qtsone/workflows-mcp/commit/bf3e6a5e3e73691ef086a75081a0aa1a4967c00c))

# [9.2.0](https://github.com/qtsone/workflows-mcp/compare/v9.1.0...v9.2.0) (2026-02-19)


### Features

* **engine:** add knowledge context prefetch schema and memory namespace ([658469e](https://github.com/qtsone/workflows-mcp/commit/658469e2e188485877e132753052db7f602ae62c))

# [9.1.0](https://github.com/qtsone/workflows-mcp/compare/v9.0.0...v9.1.0) (2026-02-19)


### Features

* **workflows-mcp:** add get_all() to ExecutionMemory and flush_memory_on_complete to WorkflowSchema ([d3ee9a1](https://github.com/qtsone/workflows-mcp/commit/d3ee9a167ae8ccb88c3dabd7e7366de2539ca741))

# [9.0.0](https://github.com/qtsone/workflows-mcp/compare/v8.1.0...v9.0.0) (2026-02-19)


* feat(engine)!: add strict output type parsing and coercion for dict and list ([6de95ef](https://github.com/qtsone/workflows-mcp/commit/6de95efd54ad27fdb02aa720a2e98fc2ee92b3ec))


### Bug Fixes

* **cortex:** update default threshold and key name in categorize phase ([9884a06](https://github.com/qtsone/workflows-mcp/commit/9884a06d209a37fef326ff9d2474f9a8501d7a28))
* **engine:** use safe composition model. ([90dd7cc](https://github.com/qtsone/workflows-mcp/commit/90dd7cc05ddd77a513f6e6c8aaaf5fd0f9ac0d9d))
* **pr-review:** resolve Jinja2 condition and template issues ([0935a90](https://github.com/qtsone/workflows-mcp/commit/0935a905024f3d8b9116f291d9fa3446cbdd9f29))
* **pr-review:** resolve Jinja2 condition and template issues ([93fa320](https://github.com/qtsone/workflows-mcp/commit/93fa320201b8d3eaa0243ab638d985605ca7e642))
* **workflows_mcp.engine.executors_file:** allow base_path to be None and default to current directory ([da9db50](https://github.com/qtsone/workflows-mcp/commit/da9db50bc1c87c0cca3960d6419aaa20443fa5b5))
* **workflows_mcp:** remove unnecessary tojson filter in yaml template ([a80d838](https://github.com/qtsone/workflows-mcp/commit/a80d838b71c3cf6ab468fa9c0bdcd32c757460e5))


### Features

* add embedding executor and safe accessor ([9b04dce](https://github.com/qtsone/workflows-mcp/commit/9b04dcea9edc2c7de24ba2b97ea19deec7f11187))
* add reload_workflows tool ([8d9a2df](https://github.com/qtsone/workflows-mcp/commit/8d9a2dfd4d51fa8a606696674db9c25c0a60b7a8))
* add test for git-pr-setup short GitHub and GitLab URLs and improve job queue test stability by using a slower workflow. ([9a533f7](https://github.com/qtsone/workflows-mcp/commit/9a533f7cdf4673940bca8a8246d868878c4421ac))
* add timeout configuration to investigation and pr-review workflows ([299ad91](https://github.com/qtsone/workflows-mcp/commit/299ad91da0f10e692183569edbb44f32a4a0074f))
* **agents/cortex:** aggregate and expose total token usage across all LLM calls ([c5f5c51](https://github.com/qtsone/workflows-mcp/commit/c5f5c51b18a6bafc76e46ec37695154c21c41909))
* **agents/cortex:** enhance cortex agent with surprisal and g-score integration ([2513ddd](https://github.com/qtsone/workflows-mcp/commit/2513dddfa5437d21d545db8e7278f655456e75c1))
* **agents:** add agent-pr-review with hierarchical state tracking ([e84950d](https://github.com/qtsone/workflows-mcp/commit/e84950d50eaeaf02f2da4c81e4464a464d39c606))
* **agents:** add iteration and memory management workflows ([a07ff12](https://github.com/qtsone/workflows-mcp/commit/a07ff125f767513fafe0146658d58bbeed5f8d5a))
* **agents:** implement CORTEX cognitive architecture ([1b2b582](https://github.com/qtsone/workflows-mcp/commit/1b2b5827abddb47ca37b36f5e8615b078d81b00f))
* **cortex, state-management, resolver:** add dict combine method and enhance cortex capabilities and state management ([373ef73](https://github.com/qtsone/workflows-mcp/commit/373ef73d3a852028090bd19b922e3ca0c05a72ca))
* **cortex:** add EVALUATE/REFINE loop to gather phase and renumber ACT ([f3ba393](https://github.com/qtsone/workflows-mcp/commit/f3ba393188a74a84b59714faca96b1cf565926a8))
* **cortex:** add llm call tracking and refactor phase task registration ([fab9b7e](https://github.com/qtsone/workflows-mcp/commit/fab9b7e0a97692bbd83ee0858182af255aff6f3c))
* **cortex:** add ripgrep search with fallback to grep in gather-search capability ([b5a4f77](https://github.com/qtsone/workflows-mcp/commit/b5a4f77e47c1c3d216ebe103c3297111c20081a5))
* **cortex:** optimize output by querying child syntheses from task tree ([b89c667](https://github.com/qtsone/workflows-mcp/commit/b89c667acf74a87ef0f88efac4746f4b046fb835))
* **cortex:** restructure agent phases and add atomic capabilities ([c861c20](https://github.com/qtsone/workflows-mcp/commit/c861c208624f50c3b9bc0066ebba5e5bf22399ea))
* **cortex:** revamp cognitive phases to v2 architecture ([5e59e8c](https://github.com/qtsone/workflows-mcp/commit/5e59e8cb217d30593a8e3e985a6f5536b14a7aaa))
* **engine/sql:** add sql executor with multi-backend support and connection pooling ([f314519](https://github.com/qtsone/workflows-mcp/commit/f31451979eb683e89a55f2bcc0e1ce92938dda90))
* **engine:** allow operations and inputs fields to accept JSON strings ([6668ad8](https://github.com/qtsone/workflows-mcp/commit/6668ad8428e3b93a0100b6c6226a4a2337441fc4))
* **engine:** enhance error handling and json parsing in execution and resolution ([c640d73](https://github.com/qtsone/workflows-mcp/commit/c640d73fd65c762ec3924579108e4ba104741170))
* enhance `read_files` block to accept `patterns` as a JSON string or array, with updated schema, documentation, and new tests, and add `.DS_Store` to gitignore. ([236c32f](https://github.com/qtsone/workflows-mcp/commit/236c32fa18ed319c904a421b2bde1f3bf993fb1e))
* **git:** add GitHub App authentication and post-review workflows ([89527c6](https://github.com/qtsone/workflows-mcp/commit/89527c6d54d7eb6648f65a00baf55d61b297bc6b))
* **git:** add workflow template to parse and checkout git PR/MR repositories ([f644b96](https://github.com/qtsone/workflows-mcp/commit/f644b96b08faa7ed7fac3f5cffd8b05f43dfb44e))
* **pr-review:** add task hierarchy visualization ([7613538](https://github.com/qtsone/workflows-mcp/commit/761353855856f6f455ee499ec70a72b904f52d9d))
* **pr-review:** implement memory storage and retrieval in PR review workflows ([a532f81](https://github.com/qtsone/workflows-mcp/commit/a532f813316db1f153513643b1f465536ed2ff72))
* **sql:** add model-based CRUD support with Active Record-style API ([de02905](https://github.com/qtsone/workflows-mcp/commit/de02905b1e8895d3ef3cac9933a95369895bb42a))
* **state-management:** add aggregate status helper outputs ([096904a](https://github.com/qtsone/workflows-mcp/commit/096904a5f62c92b0d6a594dc3ebc25b4cf2adf31))
* **state-management:** add depth attribute to tasks for hierarchical state management ([cc6d0a2](https://github.com/qtsone/workflows-mcp/commit/cc6d0a2f7ae61c30122075d8b028584d2a769541))
* **state-management:** add state management workflow with audit trail ([16cb8ee](https://github.com/qtsone/workflows-mcp/commit/16cb8ee572a44c0716d93650ac64664ed5727954))
* **state-visualize:** add agent-state-visualize workflow ([be817dc](https://github.com/qtsone/workflows-mcp/commit/be817dcfff3a60abbebb1d8a46fb8d7bfdd473e4))
* Update workflow execution functions and tests to return and handle `CallToolResult` objects, and simplify version script string manipulation. ([7039f87](https://github.com/qtsone/workflows-mcp/commit/7039f87b7f84d2c94dcebb64d5b5b3f5eb66e9d2))
* **workflows-mcp:** add ephemeral execution memory (SQLite) ([3b56617](https://github.com/qtsone/workflows-mcp/commit/3b566173501549215a3d862d6450594b7bdc6e90))
* **workflows:** Cleanup workflows and fix engine issues ([#37](https://github.com/qtsone/workflows-mcp/issues/37)) ([37db9e9](https://github.com/qtsone/workflows-mcp/commit/37db9e9ecc9c42134e633841e4178e8967ae1e74))


### BREAKING CHANGES

* The 'json' output type is deprecated and replaced by explicit 'dict' and 'list' types that enforce JSON parsing and type validation. Users must update output types in workflows and tests from 'json' to 'dict' or 'list' accordingly to avoid errors.

Replace legacy 'json' output type with explicit 'dict' and 'list' types that enforce JSON parsing with type validation. Modify output coercion to serialize dicts/lists as JSON strings for shell inputs. Update workflow runner to correctly extract block outputs. Adjust test workflows and snapshots to use 'dict' instead of 'json' for output types. This improves type safety and clarity in output handling.

# [8.1.0](https://github.com/qtsone/workflows-mcp/compare/v8.0.0...v8.1.0) (2026-02-19)


### Features

* **workflows-mcp:** add ephemeral execution memory (SQLite) ([42925f3](https://github.com/qtsone/workflows-mcp/commit/42925f3ce4892550cbea777c453bc22c2d5ddb86))

# [8.0.0](https://github.com/qtsone/workflows-mcp/compare/v7.1.0...v8.0.0) (2025-12-09)


* feat(resolver)!: handle missing secrets gracefully and add git-checkout template ([b8d0279](https://github.com/qtsone/workflows-mcp/commit/b8d027916e706e6742ff6b0e06d46f2985d6e807))
* refactor(git-commit)!: restructure git commit workflow with llm prompt files ([553229a](https://github.com/qtsone/workflows-mcp/commit/553229a92bad113766ffec7f356d6ae00d6d45a9))


### Bug Fixes

* **ci:** fix schema validation error for commit output ([a851403](https://github.com/qtsone/workflows-mcp/commit/a8514033abbd67c204a832764713e8e0bb0a43d6))
* **engine:** preserve for_each pause metadata and resume iterations ([2014ebf](https://github.com/qtsone/workflows-mcp/commit/2014ebf202c2ada521eec0e3f7ac0918e294ccf4))
* **engine:** serialize nested execution state in pause_metadata ([3154cb9](https://github.com/qtsone/workflows-mcp/commit/3154cb9c47aa6c99c214d9c37741b9a582979c1c))
* **git-auth:** use jinja for URL pattern matching in resolve_url ([38361e6](https://github.com/qtsone/workflows-mcp/commit/38361e6a27a784abcc013a0580d4494119c59d2a))
* **git-auth:** use POSIX-compatible shell syntax for credential discovery ([8aed833](https://github.com/qtsone/workflows-mcp/commit/8aed833d8ea2b09ab4a7010a0049cd0f6e292df7))
* **git-checkout:** add clone success condition to get_commit_sha/get_branch ([75db338](https://github.com/qtsone/workflows-mcp/commit/75db338a8ce2e8bddad7ec895d087f09b8a73a8d))
* **git-checkout:** create branch when ref doesn't exist ([e6b8fc7](https://github.com/qtsone/workflows-mcp/commit/e6b8fc7d2cc56e13489876eafa26bad62e8ec441))
* **git-commit:** add missing dependency from analyze_changes to stage_files ([8da6d5e](https://github.com/qtsone/workflows-mcp/commit/8da6d5e6da94f04a7a474c64290d2c2c0558dd21))
* **git:** correct has_changes detection and dependency handling ([32fe808](https://github.com/qtsone/workflows-mcp/commit/32fe808401e0cff6d8963870d6c10d07ffd3aa54))
* **test-git-checkout:** make summary dependencies optional ([203f126](https://github.com/qtsone/workflows-mcp/commit/203f12645d98219b0e6f181d9b258481a84b7f70))
* **tools:** Add consistent resume instructions to paused workflow messages ([0ee7766](https://github.com/qtsone/workflows-mcp/commit/0ee7766da475f13536a2a2c2420711667bff3670))
* **transform-design:** fix YAML serialization of nested lists in blocks ([300b0be](https://github.com/qtsone/workflows-mcp/commit/300b0bebb7243f33ac6bf3c19a583a71afc5b6a5))
* **workflow-creator:** prevent infinite recursion on empty LLM responses ([e4d07a0](https://github.com/qtsone/workflows-mcp/commit/e4d07a029616b721e72a6452d759b36d14c6b9cc))
* **workflow-creator:** resolve nested template issue in read_file calls ([9b9fd99](https://github.com/qtsone/workflows-mcp/commit/9b9fd99615345c66d34aefa27de72527a356e09e))
* **workflows:** allow 'tmp' in for_each and expose metadata.depth for templates ([901d142](https://github.com/qtsone/workflows-mcp/commit/901d142b093cb59bbee07058ba85c9094f012207))


### Features

* **agents:** add layer4 code-assistant-agent template ([72bbbb9](https://github.com/qtsone/workflows-mcp/commit/72bbbb90617a7360a9f496d0b370de237d06bbc4)), closes [hi#level](https://github.com/hi/issues/level)
* **auth:** introduce git-auth template and enhance git-checkout ([d9cebcc](https://github.com/qtsone/workflows-mcp/commit/d9cebcc33a8e6b21cb9afe80523b6aa8fe8a65a8))
* **engine:** add executor examples and make LLM schema OpenAI-compatible ([954f26b](https://github.com/qtsone/workflows-mcp/commit/954f26b98ba135aba0cdf2ccd15b56353b4f207f))
* **engine:** generate llm-compatible schema and support literal for_each ([fde69a8](https://github.com/qtsone/workflows-mcp/commit/fde69a87af51011b090ead4eb8dfc5bd23642829))
* **git:** update git-checkout workflow ([1996cfc](https://github.com/qtsone/workflows-mcp/commit/1996cfce932c8704cc9bf8bf61f8dde00afb7675))
* **inputs:** support {{tmp}} resolution in input defaults ([ff51efe](https://github.com/qtsone/workflows-mcp/commit/ff51efe80ca308f3fac4d243f0f29296f7dad14e))
* **llm:** add generated llm block reference, generator, and CI verification ([9c7b40b](https://github.com/qtsone/workflows-mcp/commit/9c7b40b34ed1ccfe9b8ac0718b0554a479f256af))
* **workflow-creator:** add complexity analysis, decomposition, and validation improvements ([4ad1f8a](https://github.com/qtsone/workflows-mcp/commit/4ad1f8a419774ea7961c115a2f4995d08f63987a))
* **workflow-creator:** add continue_on_error option to yaml configs ([7d0469d](https://github.com/qtsone/workflows-mcp/commit/7d0469d605e1221d09730e4b4c48ce409d18f0ac))
* **workflow-creator:** add support for tags in workflow creation ([d9d9da3](https://github.com/qtsone/workflows-mcp/commit/d9d9da348baec5af8f0e9b4cb11c55ded61bbeee))
* **workflow-creator:** improve workflow display with dynamic titles and explanations ([0e65e5a](https://github.com/qtsone/workflows-mcp/commit/0e65e5a5c8aef049fac9e41a37c4db6afda34cae))
* **workflow-creator:** update workflow-creator templates and bootstrap, add workspace input ([ed66fc3](https://github.com/qtsone/workflows-mcp/commit/ed66fc39e788014d4e8864f601f4633153368ba3))
* **workflow:** add workflow-creator agent templates and imagegen schema ([d3c8242](https://github.com/qtsone/workflows-mcp/commit/d3c8242fab0ffcdda26680ed530b946d38ed47af))
* **workflows_mcp:** add three-level nested workflow handling with pause/resume support ([be0d4ca](https://github.com/qtsone/workflows-mcp/commit/be0d4ca87d2e07e8030d9002e944e880c7834def))
* **workflows:** improve nested workflow pause/resume handling ([cdc973b](https://github.com/qtsone/workflows-mcp/commit/cdc973b8eb001bb8a5d34bda7be5d27d624dbec1))


### BREAKING CHANGES

* renamed input 'working_dir' to 'workspace', 'auto_commit' to 'auto', and 'commit_message' to 'message'; requires updating workflow configurations

split commit generation into system and user prompts, update input names (workspace, auto, message), improve documentation clarity
* What breaks and why:
- Workflows or callers that previously relied on SecretNotFoundError being raised by the UnifiedVariableResolver will no longer receive that exception; the resolver now substitutes an empty string and logs a warning. This changes error signaling semantics and may allow workflows that previously failed to continue with an empty secret value, potentially leading to downstream behavioural differences or silent misconfiguration.

Migration steps:
1. Audit workflows that depend on missing-secret errors to perform explicit failure handling. Update them to validate secret values where presence is required (for example, test for empty string and explicitly fail if needed).
2. If you need the old behavior (fail on missing secrets), modify your resolver usage to re-check secret_values after resolution and raise or abort when a secret value is empty, or adjust SecretProxy/providers to raise a different exception type for required secrets.
3. Search for code paths that assumed exception-based control flow from secret lookups and update to handle empty-string defaults explicitly.

Alternative approaches:
- Mark secrets as required at workflow/step level so missing secrets are detected earlier and surfaced as configuration errors.
- If you control the secret provider, configure it to return a distinct error type for required-secret failures so callers can still differentiate missing-secret vs. provider errors.

- unified_resolver: when a secret lookup returns SecretNotFoundError, log a warning and default the secret value to an empty string instead of re-raising. Other exceptions from secret providers are still propagated.
- templates: add a new comprehensive git-checkout workflow template (src/workflows_mcp/templates/git/git-checkout.yaml).
- tools: clarify the resume_workflow message to include the response parameter example.

These changes make workflows more resilient to optional/missing secrets and add a reusable git checkout template.

# [7.1.0](https://github.com/qtsone/workflows-mcp/compare/v7.0.0...v7.1.0) (2025-11-18)


### Features

* **ReadFiles:** simplify content output for single file reads ([25aa538](https://github.com/qtsone/workflows-mcp/commit/25aa538ffcdc7b22ec422e3f1b7dc887763c932c))
* **ReadFiles:** simplify content output for single file reads ([#33](https://github.com/qtsone/workflows-mcp/issues/33)) ([7430945](https://github.com/qtsone/workflows-mcp/commit/743094517b2e72505a21c445eae2aafe0381a44e))

# [7.0.0](https://github.com/qtsone/workflows-mcp/compare/v6.5.0...v7.0.0) (2025-11-17)


* feat(engine)!: introduce workflow-scoped tmp path and migrate templates ([4422538](https://github.com/qtsone/workflows-mcp/commit/4422538c271b725e2f2d4719b2fefda607cfa565))


### Bug Fixes

* **git-commit:** replace escape sequence handling in commit message template ([9b57b1a](https://github.com/qtsone/workflows-mcp/commit/9b57b1ac08da0e01d5cb0b5112d8a500dbd45fb7))
* **tests:** replace bash-specific substring syntax with POSIX-compatible printf ([edd966c](https://github.com/qtsone/workflows-mcp/commit/edd966c703b642ed767caaeafffccd09ed8514dc))


### Code Refactoring

* remove render template executor and related functionality ([3f7cd09](https://github.com/qtsone/workflows-mcp/commit/3f7cd0952ccda9f4cb34f41edc9f71bfc9166b92))


### Features

* **engine:** add comprehensive interpolation support for EditFile operations ([a29f325](https://github.com/qtsone/workflows-mcp/commit/a29f325a285d8510bb5af11ceee67b41aa9a3f28))
* **engine:** implement unified variable resolver with rule-based transformation pipeline ([befea5f](https://github.com/qtsone/workflows-mcp/commit/befea5f3587048e162cd67c5fd1dc8887e29ccff))
* **file operations:** add readfiles support with glob patterns and base path ([aad24e7](https://github.com/qtsone/workflows-mcp/commit/aad24e7f17204a2ac04678d29ae8f7f667762adb))
* **workflows-mcp:** Add profile fallback for portable LLM workflows ([85df48f](https://github.com/qtsone/workflows-mcp/commit/85df48f94fb2b6ec63712ed84e17566f17b331f7))


### Performance Improvements

* **ci:** improve ci pipeline efficiency ([67bd33c](https://github.com/qtsone/workflows-mcp/commit/67bd33c6212c407d6a53f3984ebc4dedbd2a62da))


### BREAKING CHANGES

* This changes runtime behavior that may break existing workflows:

What breaks and why:
- $SCRATCH usage removed/deprecated: templates and workflows that relied on the literal $SCRATCH path or shell environment substitution will no longer write/read to that path. The code now expects workflow templates to use the jinja variable {{tmp}} which is resolved to the execution scratch dir.
- Absolute path allowance tightened: previously some $SCRATCH-based handling allowed absolute output paths; executors now only permit absolute paths if the path is inside the configured scratch directory or the output schema explicitly sets unsafe=true. Absolute paths outside the scratch directory will be disallowed, which can change behavior for blocks that wrote to arbitrary absolute locations.
- Secrets materialization semantics changed: if secrets were pre-materialized as a plain dict in the jinja context, the resolver now merges existing values with newly fetched secrets instead of treating them the same as a SecretProxy. This can alter how secret values are looked up/overwritten.
- validate.py now recursively scans YAML (*.yaml, *.yml) which may surface additional validation errors for files that were previously ignored.

Migration steps for users:
1. Update all workflows and templates to replace any occurrences of $SCRATCH with {{tmp}} in commands, file paths, and CreateFile/ReadFiles inputs.
2. For scripts that relied on absolute paths previously allowed via $SCRATCH, either:
   - change to use paths under {{tmp}} (recommended), or
   - explicitly mark outputs as unsafe in the output schema (not recommended unless necessary).
3. Ensure any code that injected secrets into the jinja context provides a SecretProxy where possible; if an existing dict is used intentionally, verify merge semantics meet expectations.
4. Re-run validation (validate.py) and tests to catch any additional YAML files that now get scanned.

Alternative approaches if migration is not immediately possible:
- As a stopgap, workflows can set an environment variable SCRATCH inside block inputs to mimic prior behavior, or modify blocks to write to a path referenced by {{tmp}} by injecting the same value into the jinja context. However, migrating to {{tmp}} is the supported path forward.

Add a workflow-scoped jinja variable `{{tmp}}` (mapped to the execution scratch dir) and migrate templates/tests to use it; tighten Shell executor path handling; improve secret materialization; add a local LLM mock for tests and update snapshots. Key changes:
- expose "tmp" in workflow jinja context (workflow_runner)
- replace $SCRATCH usages in templates and tests with {{tmp}} and update schema examples
- ShellExecutor: treat raw paths as already-resolved values, allow absolute paths only when they reside inside the scratch dir or when output schema marks unsafe
- UnifiedVariableResolver: handle already-materialized secrets (dict) by merging with newly fetched secrets instead of overwriting
- add a local LLM mock and tests for LLM executor; add/update snapshots
- broaden validate.py to scan YAML recursively
- remove/replace several README/template docs and update many test workflows

These changes unify temporary-path handling, improve security around absolute paths, fix secret materialization issues, and make LLM-related tests hermetic.
* removes the RenderTemplate executor and all associated code, including schema validation, template rendering logic, and test workflows that depended on it. this change simplifies the file operation executors by removing the template rendering capability and updates existing workflows to use alternative approaches like Shell commands or CreateFile blocks. the RenderTemplate functionality was replaced with direct shell command execution and content rendering in templates, reducing complexity and removing the dependency on jinja2 templating for these use cases.
* **engine:** Replace legacy VariableResolver with new architecture that provides:
- Expression classification for optimal Jinja2 routing
- Rule-based transformation pipeline (security, syntax, namespace)
- Enhanced context with BlockProxy and SecretProxy
- SandboxedEnvironment for template rendering security
- Clean separation of concerns between rules and evaluation

Key components:
- UnifiedVariableResolver: Main resolver orchestrating transformation pipeline
- ExpressionClassifier: Routes expressions to appropriate evaluation methods
- TransformRule system: Modular, priority-based transformation rules
- BlockProxy: ADR-007 shortcuts and nested block access
- SecretProxy: Lazy secret loading with audit logging
- Security rules: Forbidden namespace blocking, secret tracking
- Syntax rules: Bracket notation normalization, special character handling

Updates:
- RenderTemplateExecutor uses SandboxedEnvironment instead of Environment
- BlockOrchestrator switches to UnifiedVariableResolver
- Legacy variables.py preserved as variables.py.bak
- Test workflows and snapshots reorganized for new resolver

# [6.5.0](https://github.com/qtsone/workflows-mcp/compare/v6.4.0...v6.5.0) (2025-11-12)


### Features

* **engine:** add comprehensive interpolation support for EditFile operations ([f3b890e](https://github.com/qtsone/workflows-mcp/commit/f3b890e0763462f635dc345b28e74df313038461))
* **engine:** add EditFile block for deterministic file editing ([029a188](https://github.com/qtsone/workflows-mcp/commit/029a188db281a13919ea83b547148fe9993e2d7c))
* **engine:** add EditFile block for deterministic file editing ([#28](https://github.com/qtsone/workflows-mcp/issues/28)) ([0b64c3a](https://github.com/qtsone/workflows-mcp/commit/0b64c3ad88a3308fdb89201f0f81985e5562fc75))
* **tests:** enhance variable resolution test suite with comprehensive validation ([bb048f2](https://github.com/qtsone/workflows-mcp/commit/bb048f280a3816b06c3f3b0e5c7a158cd3941de2))

# [6.4.0](https://github.com/qtsone/workflows-mcp/compare/v6.3.0...v6.4.0) (2025-11-12)


### Bug Fixes

* make job queue status filter test resilient to race conditions ([de50e10](https://github.com/qtsone/workflows-mcp/commit/de50e10bdef9601be0bf2a82b95cfdd8445c8dc4)), closes [#27](https://github.com/qtsone/workflows-mcp/issues/27)


### Features

* unified job architecture with async execution and queue support ([#27](https://github.com/qtsone/workflows-mcp/issues/27)) ([bca1d1c](https://github.com/qtsone/workflows-mcp/commit/bca1d1c4a81e684254fe3fb4d59fdb38be8bad5b))

# [6.3.0](https://github.com/qtsone/workflows-mcp/compare/v6.2.0...v6.3.0) (2025-11-10)


### Features

* **for_each:** add dynamic key interpolation and fractal execution s… ([#24](https://github.com/qtsone/workflows-mcp/issues/24)) ([3f404e5](https://github.com/qtsone/workflows-mcp/commit/3f404e5ddf7b01ee0fff6238b169ccf402edf5ac))
* **for_each:** add dynamic key interpolation and fractal execution support ([a938de6](https://github.com/qtsone/workflows-mcp/commit/a938de67a6e0e9855fa3c2fde91836f5eecc33fc))

# [6.2.0](https://github.com/qtsone/workflows-mcp/compare/v6.1.1...v6.2.0) (2025-11-08)


### Features

* **llm:** add profile-based configuration system ([d7acdb8](https://github.com/qtsone/workflows-mcp/commit/d7acdb80dc739068b3a0f7ae98b0d06fb4d95866))
* **llm:** add profile-based configuration system ([#23](https://github.com/qtsone/workflows-mcp/issues/23)) ([d0a124c](https://github.com/qtsone/workflows-mcp/commit/d0a124cfc05717b845377f62b768cc53ac125ffb))

## [6.1.1](https://github.com/qtsone/workflows-mcp/compare/v6.1.0...v6.1.1) (2025-11-07)


### Bug Fixes

* **schema:** resolve LLMProvider $ref by moving nested $defs to root level ([4b402f7](https://github.com/qtsone/workflows-mcp/commit/4b402f7c776cff6db3ef838774de58b7763b6919))
* **schema:** resolve LLMProvider $ref by moving nested $defs to root level ([#21](https://github.com/qtsone/workflows-mcp/issues/21)) ([5f13750](https://github.com/qtsone/workflows-mcp/commit/5f13750b12b70e2f40086cc72f9372d9ed16fa74))

# [6.1.0](https://github.com/qtsone/workflows-mcp/compare/v6.0.0...v6.1.0) (2025-11-07)


### Features

* **engine:** add interpolatable field support for dynamic type resolution ([652a1ce](https://github.com/qtsone/workflows-mcp/commit/652a1ce703c97bef4d4b9b344cc9697fe8e14dd0))
* **engine:** add interpolatable field support for dynamic type resolution ([#20](https://github.com/qtsone/workflows-mcp/issues/20)) ([c860c44](https://github.com/qtsone/workflows-mcp/commit/c860c44355282820cc1b88256987abb00b332996))

# [6.0.0](https://github.com/qtsone/workflows-mcp/compare/v5.0.0...v6.0.0) (2025-11-06)


* refactor(engine)!: replace _internal dict with strongly-typed ExecutionInternal model ([15df1b1](https://github.com/qtsone/workflows-mcp/commit/15df1b1b4605d1800d33efe32a55b8e3707b7fb2))


### Features

* **ADR-009:** add outcome field to distinguish operation failure from executor crash ([e3e2d45](https://github.com/qtsone/workflows-mcp/commit/e3e2d45176d2f83d86f5bc8a96b68d27c94cb765))
* **engine:** implement for_each type preservation and empty collection handling ([0e2f8ab](https://github.com/qtsone/workflows-mcp/commit/0e2f8abb9492498b9104c160cca1e8820cac49fe))


### BREAKING CHANGES

* HttpCallInput field names changed. Update workflows to use
'json' instead of 'body_json' and 'content' instead of 'body_text'.
* **ADR-009:** NodeMeta now includes 'outcome' field

ADR-009 Implementation - Phase 2: Outcome Field

Changes:
- Added 'outcome' field to NodeMeta with values: success, failure, crash, n/a
- Updated all NodeMeta factory methods to set appropriate outcome values
- Modified orchestrator.py to pass outcome="crash" for executor exceptions
- For_each parent aggregates outcome from children (crash > failure > success)
- Fixed resume_workflow status check from .is_failed() to .failed property
- Added model_validator to Execution for checkpoint deserialization

Key Outcomes:
- Operation failure: executor runs, operation fails (e.g., exit 1) - outcome="failure"
- Executor crash: executor crashes with exception - outcome="crash"
- Skipped blocks: never executed - outcome="n/a"
- Successful blocks: operation succeeded - outcome="success"

Test Status: 88/91 tests passing (96.7%)
- 2 resume_workflow tests failing (investigation ongoing - MCP server crash issue)
- 1 secrets-http-auth test failing (external httpbin.org 503 error)

Files Modified:
- src/workflows_mcp/engine/node_meta.py: Added outcome field, updated factories
- src/workflows_mcp/engine/orchestrator.py: Pass outcome="crash" for exceptions
- src/workflows_mcp/engine/workflow_runner.py: Fixed .is_failed() → .failed
- src/workflows_mcp/engine/execution.py: Added model_validator for checkpoint deserialization

See: docs/adr/ADR-009-FOR-EACH-ABSTRACTION.md

# [5.0.0](https://github.com/qtsone/workflows-mcp/compare/v4.4.0...v5.0.0) (2025-11-04)


### Code Refactoring

* unify int/float types to num and fix composition bug ([0537afc](https://github.com/qtsone/workflows-mcp/commit/0537afce73701e0d175dcaf5a0e0eaefa1c92e16))


### Features

* **LLMCall:** BREAKING CHANGE Add support for LLM Executor ([4d831fe](https://github.com/qtsone/workflows-mcp/commit/4d831fe59526d09898bb07abf7ed0a07309d6390))
* **LLMCall:** BREAKING CHANGE Add support for LLM Executor ([#18](https://github.com/qtsone/workflows-mcp/issues/18)) ([5a54cb9](https://github.com/qtsone/workflows-mcp/commit/5a54cb93508448a1fbdecbd793bf1a612c05066d))


### BREAKING CHANGES

* **LLMCall:** **
- Workflow YAML files using `type: int` or `type: float` should migrate
to `type: num`
* **
- Workflow YAML files using `type: int` or `type: float` should migrate to `type: num`

# [4.4.0](https://github.com/qtsone/workflows-mcp/compare/v4.3.0...v4.4.0) (2025-11-02)


### Bug Fixes

* **release:** use deploy key ([18e1fc9](https://github.com/qtsone/workflows-mcp/commit/18e1fc9f7d1ed43685561a002f9233f178cdcbb4))


### Features

* add comprehensive secrets management system ([31d2732](https://github.com/qtsone/workflows-mcp/commit/31d2732d30365283639c320891632c4f7e508865))
* add comprehensive secrets management system ([#17](https://github.com/qtsone/workflows-mcp/issues/17)) ([6927464](https://github.com/qtsone/workflows-mcp/commit/69274647653228b183258f251ba3ff83b200135a))
* **tests:** normalise snapshots ([91f4059](https://github.com/qtsone/workflows-mcp/commit/91f4059cf4b9578b6ad5c7420c6b009c4f175d96))

# [4.3.0](https://github.com/qtsone/workflows-mcp/compare/v4.2.0...v4.3.0) (2025-11-01)


### Features

* add HttpCall block executor for HTTP/REST API integration ([9ca2b70](https://github.com/qtsone/workflows-mcp/commit/9ca2b7002a85d38cdef5e94952509340bf34f940))
* add HttpCall block executor for HTTP/REST API integration ([#16](https://github.com/qtsone/workflows-mcp/issues/16)) ([76d1714](https://github.com/qtsone/workflows-mcp/commit/76d171483af915c4d468d4e14fec2710fc836231))

# [4.2.0](https://github.com/qtsone/workflows-mcp/compare/v4.1.0...v4.2.0) (2025-11-01)


### Bug Fixes

* **checkpointing:** properly handle checkpoint config for nested workflows ([b79740b](https://github.com/qtsone/workflows-mcp/commit/b79740b5b3990137ffbb6fcab75044323dff0e92))


### Features

* **workflows:** add process-todo-create-issues workflow template ([e932de3](https://github.com/qtsone/workflows-mcp/commit/e932de3b420a13a1907d64192095504602deb456))
* **workflows:** add process-todo-create-issues workflow template ([#11](https://github.com/qtsone/workflows-mcp/issues/11)) ([309564d](https://github.com/qtsone/workflows-mcp/commit/309564dd37b0259f2e04ed4d26d81385e981bfd8))

# [4.1.0](https://github.com/qtsone/workflows-mcp/compare/v4.0.3...v4.1.0) (2025-10-30)


### Bug Fixes

* **server:** improve graceful shutdown and fix naming convention ([86b66eb](https://github.com/qtsone/workflows-mcp/commit/86b66eb0bfa91d8bb7e04e70d7c322971e585897))


### Features

* **github:** add interactive issue creation workflow ([52da77f](https://github.com/qtsone/workflows-mcp/commit/52da77f2cd046f146a853d8d309733c07f432527))

## [4.0.3](https://github.com/qtsone/workflows-mcp/compare/v4.0.2...v4.0.3) (2025-10-27)


### Bug Fixes

* **git:** quote condition value to fix YAML syntax ([97ae68f](https://github.com/qtsone/workflows-mcp/commit/97ae68f144a06d6c0b0bc38552291ea0de113617))
* **git:** use env vars for safe commit message handling ([#6](https://github.com/qtsone/workflows-mcp/issues/6)) ([807e61c](https://github.com/qtsone/workflows-mcp/commit/807e61c1d27b3df97abf92d64925d85c099518bb))
* **git:** use env vars for safe message handling (GitHub Actions pattern) ([48297ea](https://github.com/qtsone/workflows-mcp/commit/48297eab62805de89c25159c330cbf86c7b8f2a0))
* **yaml:** quote all unquoted {{...}} variable references ([0e2b476](https://github.com/qtsone/workflows-mcp/commit/0e2b476ff71462a2609f18299bf43eed43c9461c))

## [4.0.2](https://github.com/qtsone/workflows-mcp/compare/v4.0.1...v4.0.2) (2025-10-27)


### Bug Fixes

* **git:** fix boolean expression syntax and shell expansion issues ([daa1d75](https://github.com/qtsone/workflows-mcp/commit/daa1d75427248a2a5550d0d0a63a1826781934ea))
* **git:** fix boolean expression syntax and shell expansion issues ([#4](https://github.com/qtsone/workflows-mcp/issues/4)) ([176c60d](https://github.com/qtsone/workflows-mcp/commit/176c60dae04fee2884ace06c82b7c10385cedcaa))

## [4.0.1](https://github.com/qtsone/workflows-mcp/compare/v4.0.0...v4.0.1) (2025-10-26)


### Bug Fixes

* remove EchoBlock in favor of Shell executor ([#1](https://github.com/qtsone/workflows-mcp/issues/1)) ([678d259](https://github.com/qtsone/workflows-mcp/commit/678d2597f28627eb79b3adec23c50bde0d629814))

# [4.0.0](https://github.com/qtsone/workflows-mcp/compare/v3.3.0...v4.0.0) (2025-10-26)


* chore!: migrate to AGPL-3.0 license ([3431aab](https://github.com/qtsone/workflows-mcp/commit/3431aab67acad56c7ee4f3f37fc7293a3e9749f2))


### BREAKING CHANGES

* License changed from GPL-3.0 to AGPL-3.0-or-later. This license change requires users to provide source code access when the software is used over a network. All existing functionality is preserved.
