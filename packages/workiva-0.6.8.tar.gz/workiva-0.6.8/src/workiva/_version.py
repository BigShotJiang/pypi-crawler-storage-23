"""Version constants for the Workiva SDK."""

__version__: str = "0.6.8"
__user_agent__: str = f"workiva-python-sdk/{__version__}"
