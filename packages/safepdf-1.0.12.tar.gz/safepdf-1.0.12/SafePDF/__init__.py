"""
SafePDF package initializer.

This file makes the `SafePDF` directory a proper Python package so
absolute imports like `from SafePDF.ui...` work consistently.
"""

__version__ = "1.0.12"

__all__ = []
