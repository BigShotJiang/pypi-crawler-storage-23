from jet_bridge_base import settings

VERSION = '1.12.13'
