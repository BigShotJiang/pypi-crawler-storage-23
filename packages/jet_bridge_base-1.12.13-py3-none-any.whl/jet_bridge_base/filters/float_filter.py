from jet_bridge_base.fields import FloatField
from jet_bridge_base.filters.filter import Filter


class FloatFilter(Filter):
    field_class = FloatField
