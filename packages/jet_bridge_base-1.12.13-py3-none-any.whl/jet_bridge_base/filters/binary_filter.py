from jet_bridge_base.fields import BinaryField
from jet_bridge_base.filters.filter import Filter


class BinaryFilter(Filter):
    field_class = BinaryField
