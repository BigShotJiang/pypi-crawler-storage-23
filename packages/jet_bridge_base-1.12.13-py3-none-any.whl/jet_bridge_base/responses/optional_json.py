from jet_bridge_base.responses.json import JSONResponse


class OptionalJSONResponse(JSONResponse):
    pass
