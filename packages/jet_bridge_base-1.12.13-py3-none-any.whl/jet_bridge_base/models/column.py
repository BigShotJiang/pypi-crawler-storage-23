
class Column(object):

    def __init__(self, name, data_type):
        self.name = name
        self.data_type = data_type
