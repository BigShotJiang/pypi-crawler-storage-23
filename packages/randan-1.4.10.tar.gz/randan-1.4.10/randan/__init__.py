from . import (
    descriptive_statistics,
    bivariate_association, 
    tree, 
    comparison_of_central_tendency,
    regression,
    clustering,
    dimension_reduction
)
