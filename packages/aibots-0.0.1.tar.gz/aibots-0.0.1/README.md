# AIBots

AI Bots - AI Agent Framework powered by [PraisonAI](https://github.com/MervinPraison/PraisonAI).

## Installation

```bash
pip install aibots
```

## Usage

```python
import aibots
print(aibots.__version__)
```

## License

MIT
