"""AIBots - AI Agent Framework powered by PraisonAI"""

__version__ = "0.0.1"
