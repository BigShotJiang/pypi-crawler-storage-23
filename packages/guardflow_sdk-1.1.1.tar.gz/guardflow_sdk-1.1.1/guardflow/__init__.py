"""
GuardFlow Python SDK

Official SDK for integrating GuardFlow AI prompt security into your Python applications.

Example:
    >>> from guardflow import GuardFlow
    >>>
    >>> gf = GuardFlow(api_key="gf_live_xxx")
    >>>
    >>> # Async usage
    >>> result = await gf.run("my-prompt", input="Hello")
    >>> print(result.output)
    >>>
    >>> # Sync usage
    >>> result = gf.run_sync("my-prompt", input="Hello")
    >>> print(result.output)
"""

__version__ = "1.1.1"

# Main client
from .client import GuardFlow, AsyncGuardFlow

# Exceptions
from .exceptions import (
    GuardFlowError,
    BlockedError,
    EscalatedError,
    RateLimitError,
    AuthError,
    TimeoutError,
    ValidationError,
    PromptNotFoundError,
    NetworkError,
    GuardFlowAPIError,
    is_retryable_error,
    create_error_from_response,
)

# Types
from .types import (
    # Configuration
    GuardFlowConfig,
    CacheConfig,
    # Run operations
    RunOptions,
    RunResult,
    # Batch operations
    BatchRunInput,
    BatchRunResult,
    BatchRunItemResult,
    BatchRunSummary,
    # Guardrails
    GuardrailViolation,
    GuardrailViolationType,
    ViolationSeverity,
    ViolationAction,
    # API types
    RunApiRequest,
    RunApiResponse,
    # Prompt types
    Prompt,
    PromptVersion,
    CreatePromptOptions,
    UpdatePromptOptions,
    CreateVersionOptions,
    DeployOptions,
    PromptDiff,
    ListOptions,
    PaginatedResponse,
    # Guardrail management types
    GuardrailPolicy,
    CreateGuardrailOptions,
    UpdateGuardrailOptions,
    GuardrailCheckOptions,
    GuardrailCheckResult,
    # Monitoring types
    MonitoringStats,
    RequestLog,
    ViolationLog,
    CostOverview,
    CostTrendPoint,
    # Evaluation types
    EvalResult,
    EvalTestResult,
    RunEvalOptions,
    # Test case types
    TestCase,
    CreateTestCaseOptions,
    UpdateTestCaseOptions,
    # Agent types
    Agent,
    CreateAgentOptions,
    UpdateAgentOptions,
    # Deployment types
    Deployment,
    DeploymentMetrics,
    StartCanaryOptions,
    PromoteDeploymentOptions,
)

# Resources
from .resources import (
    PromptsResource,
    GuardrailsResource,
    MonitoringResource,
    EvalsResource,
    TestCasesResource,
    AgentsResource,
    DeploymentsResource,
)

# Cache
from .cache import (
    Cache,
    CacheStats,
    create_prompt_cache_key,
    create_run_cache_key,
)

__all__ = [
    # Version
    "__version__",
    # Client
    "GuardFlow",
    "AsyncGuardFlow",
    # Exceptions
    "GuardFlowError",
    "BlockedError",
    "EscalatedError",
    "RateLimitError",
    "AuthError",
    "TimeoutError",
    "ValidationError",
    "PromptNotFoundError",
    "NetworkError",
    "GuardFlowAPIError",
    "is_retryable_error",
    "create_error_from_response",
    # Types - Configuration
    "GuardFlowConfig",
    "CacheConfig",
    # Types - Run operations
    "RunOptions",
    "RunResult",
    "BatchRunInput",
    "BatchRunResult",
    "BatchRunItemResult",
    "BatchRunSummary",
    # Types - Guardrail violations
    "GuardrailViolation",
    "GuardrailViolationType",
    "ViolationSeverity",
    "ViolationAction",
    # Types - API
    "RunApiRequest",
    "RunApiResponse",
    # Types - Prompts
    "Prompt",
    "PromptVersion",
    "CreatePromptOptions",
    "UpdatePromptOptions",
    "CreateVersionOptions",
    "DeployOptions",
    "PromptDiff",
    "ListOptions",
    "PaginatedResponse",
    # Types - Guardrail management
    "GuardrailPolicy",
    "CreateGuardrailOptions",
    "UpdateGuardrailOptions",
    "GuardrailCheckOptions",
    "GuardrailCheckResult",
    # Types - Monitoring
    "MonitoringStats",
    "RequestLog",
    "ViolationLog",
    "CostOverview",
    "CostTrendPoint",
    # Types - Evaluations
    "EvalResult",
    "EvalTestResult",
    "RunEvalOptions",
    # Types - Test cases
    "TestCase",
    "CreateTestCaseOptions",
    "UpdateTestCaseOptions",
    # Types - Agents
    "Agent",
    "CreateAgentOptions",
    "UpdateAgentOptions",
    # Types - Deployments
    "Deployment",
    "DeploymentMetrics",
    "StartCanaryOptions",
    "PromoteDeploymentOptions",
    # Resources
    "PromptsResource",
    "GuardrailsResource",
    "MonitoringResource",
    "EvalsResource",
    "TestCasesResource",
    "AgentsResource",
    "DeploymentsResource",
    # Cache
    "Cache",
    "CacheStats",
    "create_prompt_cache_key",
    "create_run_cache_key",
]
