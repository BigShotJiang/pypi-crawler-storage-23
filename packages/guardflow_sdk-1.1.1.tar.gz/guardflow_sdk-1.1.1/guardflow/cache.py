"""
GuardFlow SDK Cache
Thread-safe and async-safe in-memory cache with TTL support
"""

import asyncio
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Generic, Optional, TypeVar

T = TypeVar("T")


@dataclass
class CacheEntry(Generic[T]):
    """Cache entry with value and expiration time."""

    value: T
    expires_at: float


@dataclass
class CacheStats:
    """Cache statistics."""

    total: int
    valid: int
    expired: int


class Cache(Generic[T]):
    """
    Thread-safe in-memory cache with TTL support.
    Used for caching prompt versions and responses.
    """

    def __init__(
        self,
        default_ttl_seconds: float = 60.0,
        cleanup_interval_seconds: float = 30.0,
    ):
        """
        Create a new cache instance.

        Args:
            default_ttl_seconds: Default time-to-live in seconds.
            cleanup_interval_seconds: Interval for automatic cleanup (0 to disable).
        """
        self._store: Dict[str, CacheEntry[T]] = {}
        self._default_ttl = default_ttl_seconds
        self._lock = threading.RLock()
        self._async_lock: Optional[asyncio.Lock] = None
        self._cleanup_task: Optional[asyncio.Task] = None
        self._cleanup_interval = cleanup_interval_seconds
        self._running = False

    def _get_async_lock(self) -> asyncio.Lock:
        """Get or create async lock."""
        if self._async_lock is None:
            self._async_lock = asyncio.Lock()
        return self._async_lock

    def get(self, key: str) -> Optional[T]:
        """
        Get a value from the cache.
        Returns None if not found or expired.
        """
        with self._lock:
            entry = self._store.get(key)

            if entry is None:
                return None

            # Check if expired
            if time.time() > entry.expires_at:
                del self._store[key]
                return None

            return entry.value

    async def get_async(self, key: str) -> Optional[T]:
        """Async version of get."""
        async with self._get_async_lock():
            return self.get(key)

    def set(self, key: str, value: T, ttl_seconds: Optional[float] = None) -> None:
        """
        Set a value in the cache.

        Args:
            key: Cache key.
            value: Value to cache.
            ttl_seconds: Optional TTL override in seconds.
        """
        ttl = ttl_seconds if ttl_seconds is not None else self._default_ttl
        expires_at = time.time() + ttl

        with self._lock:
            self._store[key] = CacheEntry(value=value, expires_at=expires_at)

    async def set_async(
        self, key: str, value: T, ttl_seconds: Optional[float] = None
    ) -> None:
        """Async version of set."""
        async with self._get_async_lock():
            self.set(key, value, ttl_seconds)

    def has(self, key: str) -> bool:
        """Check if a key exists and is not expired."""
        return self.get(key) is not None

    async def has_async(self, key: str) -> bool:
        """Async version of has."""
        return await self.get_async(key) is not None

    def invalidate(self, key: str) -> bool:
        """Invalidate a specific cache entry."""
        with self._lock:
            if key in self._store:
                del self._store[key]
                return True
            return False

    async def invalidate_async(self, key: str) -> bool:
        """Async version of invalidate."""
        async with self._get_async_lock():
            return self.invalidate(key)

    def invalidate_by_prefix(self, prefix: str) -> int:
        """Invalidate all entries matching a prefix."""
        with self._lock:
            keys_to_delete = [k for k in self._store.keys() if k.startswith(prefix)]
            for key in keys_to_delete:
                del self._store[key]
            return len(keys_to_delete)

    async def invalidate_by_prefix_async(self, prefix: str) -> int:
        """Async version of invalidate_by_prefix."""
        async with self._get_async_lock():
            return self.invalidate_by_prefix(prefix)

    def clear(self) -> None:
        """Clear all cache entries."""
        with self._lock:
            self._store.clear()

    async def clear_async(self) -> None:
        """Async version of clear."""
        async with self._get_async_lock():
            self.clear()

    def size(self) -> int:
        """Get the number of entries in the cache (including expired)."""
        with self._lock:
            return len(self._store)

    def keys(self) -> list[str]:
        """Get all cache keys (including expired)."""
        with self._lock:
            return list(self._store.keys())

    def cleanup(self) -> int:
        """Remove all expired entries."""
        with self._lock:
            now = time.time()
            keys_to_delete = [
                key for key, entry in self._store.items() if now > entry.expires_at
            ]
            for key in keys_to_delete:
                del self._store[key]
            return len(keys_to_delete)

    async def cleanup_async(self) -> int:
        """Async version of cleanup."""
        async with self._get_async_lock():
            return self.cleanup()

    def get_or_set(
        self,
        key: str,
        factory: Callable[[], T],
        ttl_seconds: Optional[float] = None,
    ) -> T:
        """
        Get or set a value in the cache.
        If the key doesn't exist, call the factory function to create the value.
        """
        existing = self.get(key)
        if existing is not None:
            return existing

        value = factory()
        self.set(key, value, ttl_seconds)
        return value

    async def get_or_set_async(
        self,
        key: str,
        factory: Callable[[], T],
        ttl_seconds: Optional[float] = None,
    ) -> T:
        """Async version of get_or_set."""
        async with self._get_async_lock():
            existing = self.get(key)
            if existing is not None:
                return existing

            # Call factory (which might be async)
            if asyncio.iscoroutinefunction(factory):
                value = await factory()
            else:
                value = factory()

            self.set(key, value, ttl_seconds)
            return value

    def stats(self) -> CacheStats:
        """Get cache statistics."""
        with self._lock:
            now = time.time()
            expired = sum(1 for entry in self._store.values() if now > entry.expires_at)
            valid = len(self._store) - expired

            return CacheStats(
                total=len(self._store),
                valid=valid,
                expired=expired,
            )

    async def start_cleanup_task(self) -> None:
        """Start automatic cleanup task for async contexts."""
        if self._running or self._cleanup_interval <= 0:
            return

        self._running = True

        async def cleanup_loop():
            while self._running:
                await asyncio.sleep(self._cleanup_interval)
                if self._running:
                    await self.cleanup_async()

        self._cleanup_task = asyncio.create_task(cleanup_loop())

    async def stop_cleanup_task(self) -> None:
        """Stop automatic cleanup task."""
        self._running = False
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
            self._cleanup_task = None

    def destroy(self) -> None:
        """Clean up resources."""
        self._running = False
        self.clear()


def create_prompt_cache_key(prompt_name: str, version: Optional[int] = None) -> str:
    """Create a cache key for prompt requests."""
    if version:
        return f"prompt:{prompt_name}:v{version}"
    return f"prompt:{prompt_name}:latest"


def create_run_cache_key(
    prompt_name: str,
    input_text: str,
    variables: Optional[Dict[str, str]] = None,
) -> str:
    """Create a cache key for run results."""
    import hashlib

    variables_str = str(sorted(variables.items())) if variables else ""
    content = f"{input_text}:{variables_str}"
    hash_digest = hashlib.md5(content.encode()).hexdigest()[:12]
    return f"run:{prompt_name}:{hash_digest}"
