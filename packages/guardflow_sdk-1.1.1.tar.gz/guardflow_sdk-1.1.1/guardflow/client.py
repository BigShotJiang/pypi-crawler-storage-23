"""
GuardFlow SDK Client
Main client class for interacting with the GuardFlow API
"""

import asyncio
import logging
import time
import uuid
from typing import Any, Callable, Dict, List, Optional, Union

import httpx
from tenacity import (
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from .cache import Cache, create_prompt_cache_key
from .exceptions import (
    AuthError,
    BlockedError,
    EscalatedError,
    GuardFlowAPIError,
    GuardFlowError,
    NetworkError,
    RateLimitError,
    TimeoutError,
    ValidationError,
    create_error_from_response,
    is_retryable_error,
)
from .types import (
    BatchRunInput,
    BatchRunItemResult,
    BatchRunResult,
    BatchRunSummary,
    GuardFlowConfig,
    RunOptions,
    RunResult,
    GuardrailViolation,
)
from .resources import (
    PromptsResource,
    GuardrailsResource,
    MonitoringResource,
    EvalsResource,
    TestCasesResource,
    AgentsResource,
    DeploymentsResource,
)

logger = logging.getLogger("guardflow")

DEFAULT_BASE_URL = "https://api.guardflow.io"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_CACHE_TTL_SECONDS = 60


class GuardFlow:
    """
    GuardFlow SDK Client.

    Provides both async and sync methods for interacting with the GuardFlow API.

    Example:
        >>> from guardflow import GuardFlow
        >>>
        >>> gf = GuardFlow(api_key="gf_live_xxx")
        >>>
        >>> # Async usage
        >>> result = await gf.run("my-prompt", input="Hello")
        >>> print(result.output)
        >>>
        >>> # Sync usage
        >>> result = gf.run_sync("my-prompt", input="Hello")
        >>> print(result.output)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        debug: bool = False,
        cache_enabled: bool = True,
        cache_ttl_seconds: int = DEFAULT_CACHE_TTL_SECONDS,
        config: Optional[GuardFlowConfig] = None,
    ):
        """
        Initialize GuardFlow client.

        Args:
            api_key: Your GuardFlow API key (starts with gf_live_ or gf_test_).
            base_url: Base URL for the GuardFlow API.
            timeout: Request timeout in seconds.
            max_retries: Maximum number of retry attempts.
            debug: Enable debug logging.
            cache_enabled: Enable prompt caching.
            cache_ttl_seconds: Cache TTL in seconds.
            config: GuardFlowConfig object (alternative to individual params).
        """
        # Use config object if provided
        if config:
            api_key = config.api_key
            base_url = config.base_url
            timeout = config.timeout
            max_retries = config.max_retries
            debug = config.debug
            if config.cache:
                cache_enabled = config.cache.enabled
                cache_ttl_seconds = config.cache.ttl_seconds

        # Validate API key
        if not api_key:
            raise ValidationError("API key is required", {"api_key": "Required field"})

        if not api_key.startswith("gf_"):
            raise ValidationError(
                'Invalid API key format. Must start with "gf_"',
                {"api_key": 'Must start with "gf_"'},
            )

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._debug = debug

        # Setup cache
        self._cache_enabled = cache_enabled
        self._cache: Cache[RunResult] = Cache(default_ttl_seconds=cache_ttl_seconds)

        # HTTP clients (created lazily)
        self._async_client: Optional[httpx.AsyncClient] = None
        self._sync_client: Optional[httpx.Client] = None

        # Event callbacks
        self._on_blocked: List[Callable] = []
        self._on_escalated: List[Callable] = []
        self._on_error: List[Callable] = []
        self._on_complete: List[Callable] = []
        self._on_retry: List[Callable] = []

        # Resource instances (lazy initialization)
        self._prompts: Optional[PromptsResource] = None
        self._guardrails: Optional[GuardrailsResource] = None
        self._monitoring: Optional[MonitoringResource] = None
        self._evals: Optional[EvalsResource] = None
        self._test_cases: Optional[TestCasesResource] = None
        self._agents: Optional[AgentsResource] = None
        self._deployments: Optional[DeploymentsResource] = None

    def _log(self, *args: Any) -> None:
        """Log debug messages."""
        if self._debug:
            logger.debug(" ".join(str(a) for a in args))

    # Resource properties (lazy initialization)
    @property
    def prompts(self) -> PromptsResource:
        """Access prompts resource for CRUD operations."""
        if self._prompts is None:
            self._prompts = PromptsResource(self._request_async, self._request_sync)
        return self._prompts

    @property
    def guardrails(self) -> GuardrailsResource:
        """Access guardrails resource for policy management and checks."""
        if self._guardrails is None:
            self._guardrails = GuardrailsResource(self._request_async, self._request_sync)
        return self._guardrails

    @property
    def monitoring(self) -> MonitoringResource:
        """Access monitoring resource for stats, logs, and costs."""
        if self._monitoring is None:
            self._monitoring = MonitoringResource(self._request_async, self._request_sync)
        return self._monitoring

    @property
    def evals(self) -> EvalsResource:
        """Access evals resource for running evaluations."""
        if self._evals is None:
            self._evals = EvalsResource(self._request_async, self._request_sync)
        return self._evals

    @property
    def test_cases(self) -> TestCasesResource:
        """Access test cases resource for managing evaluation test cases."""
        if self._test_cases is None:
            self._test_cases = TestCasesResource(self._request_async, self._request_sync)
        return self._test_cases

    @property
    def agents(self) -> AgentsResource:
        """Access agents resource for managing AI agents."""
        if self._agents is None:
            self._agents = AgentsResource(self._request_async, self._request_sync)
        return self._agents

    @property
    def deployments(self) -> DeploymentsResource:
        """Access deployments resource for canary releases and rollbacks."""
        if self._deployments is None:
            self._deployments = DeploymentsResource(self._request_async, self._request_sync)
        return self._deployments

    def _generate_request_id(self) -> str:
        """Generate a unique request ID."""
        return f"gf_{int(time.time())}_{uuid.uuid4().hex[:8]}"

    async def _get_async_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=self._timeout,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "User-Agent": "guardflow-sdk-python/1.0.0",
                },
            )
        return self._async_client

    def _get_sync_client(self) -> httpx.Client:
        """Get or create sync HTTP client."""
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(
                base_url=self._base_url,
                timeout=self._timeout,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "User-Agent": "guardflow-sdk-python/1.0.0",
                },
            )
        return self._sync_client

    async def _request_async(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        prompt_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Make async HTTP request with retry logic."""
        request_id = self._generate_request_id()

        self._log(f"{method} {path}", json if json else "")

        @retry(
            retry=retry_if_exception(is_retryable_error),
            stop=stop_after_attempt(self._max_retries),
            wait=wait_exponential(multiplier=1, min=1, max=30),
            before_sleep=lambda retry_state: self._emit_retry(
                prompt_name, retry_state.attempt_number, self._max_retries
            ),
        )
        async def do_request() -> Dict[str, Any]:
            try:
                client = await self._get_async_client()
                response = await client.request(
                    method,
                    path,
                    json=json,
                    timeout=timeout or self._timeout,
                    headers={"X-Request-ID": request_id},
                )

                data = response.json()
                self._log("Response:", response.status_code, data)

                if response.status_code >= 400:
                    raise create_error_from_response(
                        response.status_code, data, request_id
                    )

                return data

            except httpx.TimeoutException:
                raise TimeoutError(timeout or self._timeout, request_id)
            except httpx.ConnectError as e:
                raise NetworkError(f"Connection error: {e}", e, request_id)
            except httpx.RequestError as e:
                raise NetworkError(f"Request error: {e}", e, request_id)

        return await do_request()

    def _request_sync(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        prompt_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Make sync HTTP request with retry logic."""
        request_id = self._generate_request_id()

        self._log(f"{method} {path}", json if json else "")

        last_error: Optional[Exception] = None

        for attempt in range(1, self._max_retries + 1):
            try:
                client = self._get_sync_client()
                response = client.request(
                    method,
                    path,
                    json=json,
                    timeout=timeout or self._timeout,
                    headers={"X-Request-ID": request_id},
                )

                data = response.json()
                self._log("Response:", response.status_code, data)

                if response.status_code >= 400:
                    raise create_error_from_response(
                        response.status_code, data, request_id
                    )

                return data

            except httpx.TimeoutException:
                last_error = TimeoutError(timeout or self._timeout, request_id)
            except httpx.ConnectError as e:
                last_error = NetworkError(f"Connection error: {e}", e, request_id)
            except httpx.RequestError as e:
                last_error = NetworkError(f"Request error: {e}", e, request_id)
            except GuardFlowError as e:
                if not is_retryable_error(e) or attempt >= self._max_retries:
                    raise
                last_error = e

            if last_error and is_retryable_error(last_error):
                self._emit_retry(prompt_name, attempt, self._max_retries)
                delay = min(2 ** (attempt - 1), 30)
                time.sleep(delay)
            elif last_error:
                raise last_error

        if last_error:
            raise last_error

        raise NetworkError("Unknown error", None, request_id)

    def _emit_retry(
        self,
        prompt_name: Optional[str],
        attempt: int,
        max_attempts: int,
    ) -> None:
        """Emit retry event."""
        for handler in self._on_retry:
            try:
                handler(prompt_name, attempt, max_attempts)
            except Exception:
                pass

    def _emit_blocked(
        self,
        prompt_name: str,
        violations: List[Dict[str, Any]],
        request_id: str,
    ) -> None:
        """Emit blocked event."""
        for handler in self._on_blocked:
            try:
                handler(prompt_name, violations, request_id)
            except Exception:
                pass

    def _emit_escalated(
        self,
        prompt_name: str,
        request_id: str,
        reason: Optional[str] = None,
    ) -> None:
        """Emit escalated event."""
        for handler in self._on_escalated:
            try:
                handler(prompt_name, request_id, reason)
            except Exception:
                pass

    def _emit_error(
        self,
        prompt_name: str,
        error: Exception,
        request_id: Optional[str] = None,
    ) -> None:
        """Emit error event."""
        for handler in self._on_error:
            try:
                handler(prompt_name, error, request_id)
            except Exception:
                pass

    def _emit_complete(self, prompt_name: str, result: RunResult) -> None:
        """Emit complete event."""
        for handler in self._on_complete:
            try:
                handler(prompt_name, result)
            except Exception:
                pass

    async def run(
        self,
        prompt: str,
        input: Optional[str] = None,
        variables: Optional[Dict[str, str]] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        industry: Optional[str] = None,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        force_refresh: bool = False,
        dry_run: bool = False,
        timeout: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> RunResult:
        """
        Run a prompt with the given input (async).

        Args:
            prompt: The prompt name to run.
            input: User input/message.
            variables: Template variables to inject.
            session_id: Session ID for conversation tracking.
            user_id: User ID for tracking.
            industry: Industry context ('fintech', 'healthcare', 'legal', 'hr', 'general').
            model: Override the default model.
            provider: Override the default provider.
            force_refresh: Bypass cache.
            dry_run: Validate only, no LLM call.
            timeout: Override client timeout.
            metadata: Additional metadata.

        Returns:
            RunResult with output and metadata.

        Raises:
            BlockedError: When response is blocked by guardrails.
            EscalatedError: When response needs human review.
            ValidationError: When input is invalid.
        """
        # Handle RunOptions object
        if isinstance(input, RunOptions):
            options = input
            input = options.input
            variables = options.variables
            session_id = options.session_id
            force_refresh = options.force_refresh
            dry_run = options.dry_run
            timeout = options.timeout
            metadata = options.metadata
        elif input is None:
            input = kwargs.get("input", "")

        # Validate input
        if not input or not input.strip():
            raise ValidationError("Input is required", {"input": "Required field"})

        # Check cache
        if self._cache_enabled and not dry_run and not force_refresh:
            cache_key = create_prompt_cache_key(prompt)
            cached = await self._cache.get_async(cache_key)
            if cached:
                self._log("Cache hit for prompt:", prompt)
                return RunResult(
                    **{**cached.model_dump(), "cached": True}
                )

        # Build request
        request_body: Dict[str, Any] = {
            "prompt": prompt,
            "input": input,
        }
        if variables:
            request_body["variables"] = variables
        if session_id:
            request_body["sessionId"] = session_id
        if user_id:
            request_body["userId"] = user_id
        if industry:
            request_body["industry"] = industry
        if model:
            request_body["model"] = model
        if provider:
            request_body["provider"] = provider
        if dry_run:
            request_body["dryRun"] = dry_run
        if metadata:
            request_body["metadata"] = metadata

        # Make request
        response = await self._request_async(
            "POST",
            "/v1/run",
            json=request_body,
            timeout=timeout,
            prompt_name=prompt,
        )

        # Handle response
        return self._process_response(prompt, response, dry_run)

    def run_sync(
        self,
        prompt: str,
        input: Optional[str] = None,
        variables: Optional[Dict[str, str]] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        industry: Optional[str] = None,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        force_refresh: bool = False,
        dry_run: bool = False,
        timeout: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> RunResult:
        """
        Run a prompt with the given input (sync).

        Same as run() but synchronous.
        """
        # Handle RunOptions object
        if isinstance(input, RunOptions):
            options = input
            input = options.input
            variables = options.variables
            session_id = options.session_id
            force_refresh = options.force_refresh
            dry_run = options.dry_run
            timeout = options.timeout
            metadata = options.metadata
        elif input is None:
            input = kwargs.get("input", "")

        # Validate input
        if not input or not input.strip():
            raise ValidationError("Input is required", {"input": "Required field"})

        # Check cache
        if self._cache_enabled and not dry_run and not force_refresh:
            cache_key = create_prompt_cache_key(prompt)
            cached = self._cache.get(cache_key)
            if cached:
                self._log("Cache hit for prompt:", prompt)
                return RunResult(
                    **{**cached.model_dump(), "cached": True}
                )

        # Build request
        request_body: Dict[str, Any] = {
            "prompt": prompt,
            "input": input,
        }
        if variables:
            request_body["variables"] = variables
        if session_id:
            request_body["sessionId"] = session_id
        if user_id:
            request_body["userId"] = user_id
        if industry:
            request_body["industry"] = industry
        if model:
            request_body["model"] = model
        if provider:
            request_body["provider"] = provider
        if dry_run:
            request_body["dryRun"] = dry_run
        if metadata:
            request_body["metadata"] = metadata

        # Make request
        response = self._request_sync(
            "POST",
            "/v1/run",
            json=request_body,
            timeout=timeout,
            prompt_name=prompt,
        )

        # Handle response
        return self._process_response(prompt, response, dry_run)

    def _process_response(
        self,
        prompt: str,
        response: Dict[str, Any],
        dry_run: bool,
    ) -> RunResult:
        """Process API response and return RunResult."""
        request_id = response.get("requestId", "")

        # Handle error response
        if not response.get("success") or response.get("error"):
            error = response.get("error", {})
            code = error.get("code")

            if code == "BLOCKED":
                violations = error.get("violations", [])
                self._emit_blocked(prompt, violations, request_id)
                raise BlockedError(violations, request_id)

            if code == "ESCALATED":
                self._emit_escalated(prompt, request_id, error.get("message"))
                raise EscalatedError(
                    error.get("message"),
                    error.get("violations"),
                    request_id,
                )

            raise GuardFlowAPIError(
                error.get("message", "Unknown error"),
                500,
                response,
                request_id,
            )

        # Parse result
        data = response.get("data", {})

        # Convert violations to GuardrailViolation objects
        violations_data = data.get("violations", [])
        violations = []
        for v in violations_data:
            try:
                violations.append(GuardrailViolation.model_validate(v))
            except Exception:
                # Skip invalid violations
                pass

        result = RunResult(
            output=data.get("output", ""),
            allowed=data.get("allowed", True),
            blocked=data.get("blocked", False),
            escalated=data.get("escalated", False),
            violations=violations,
            tokensUsed=data.get("tokensUsed", 0),
            tokensIn=data.get("tokensIn", 0),
            tokensOut=data.get("tokensOut", 0),
            latencyMs=data.get("latencyMs", 0),
            costUsd=data.get("costUsd", 0.0),
            promptVersion=data.get("promptVersion", 0),
            model=data.get("model", ""),
            provider=data.get("provider", ""),
            cached=False,
            requestId=request_id,
            metadata=data.get("metadata"),
        )

        # Handle blocked result
        if result.blocked:
            self._emit_blocked(prompt, violations_data, request_id)
            raise BlockedError(violations_data, request_id)

        # Handle escalated result
        if result.escalated:
            self._emit_escalated(prompt, request_id)
            raise EscalatedError(None, violations_data, request_id)

        # Cache result
        if self._cache_enabled and not dry_run:
            cache_key = create_prompt_cache_key(prompt)
            self._cache.set(cache_key, result)

        # Emit complete event
        self._emit_complete(prompt, result)

        return result

    async def run_batch(
        self,
        inputs: List[Union[BatchRunInput, Dict[str, Any]]],
    ) -> BatchRunResult:
        """
        Run multiple prompts in batch (async).

        Args:
            inputs: List of batch run inputs.

        Returns:
            BatchRunResult with individual results and summary.
        """
        results: List[BatchRunItemResult] = []

        async def process_input(
            item: Union[BatchRunInput, Dict[str, Any]]
        ) -> BatchRunItemResult:
            if isinstance(item, dict):
                prompt = item["prompt"]
                options = item.get("options", {})
                if isinstance(options, dict):
                    input_text = options.get("input", "")
                    variables = options.get("variables")
                    session_id = options.get("session_id")
                else:
                    input_text = options.input
                    variables = options.variables
                    session_id = options.session_id
            else:
                prompt = item.prompt
                input_text = item.options.input
                variables = item.options.variables
                session_id = item.options.session_id

            try:
                result = await self.run(
                    prompt,
                    input=input_text,
                    variables=variables,
                    session_id=session_id,
                )
                return BatchRunItemResult(
                    **result.model_dump(),
                    prompt=prompt,
                )
            except BlockedError as e:
                return BatchRunItemResult(
                    output="",
                    allowed=False,
                    blocked=True,
                    escalated=False,
                    violations=[],
                    tokensUsed=0,
                    tokensIn=0,
                    tokensOut=0,
                    latencyMs=0,
                    costUsd=0.0,
                    promptVersion=0,
                    model="",
                    provider="",
                    cached=False,
                    requestId=e.request_id or "",
                    prompt=prompt,
                )
            except EscalatedError as e:
                return BatchRunItemResult(
                    output="",
                    allowed=False,
                    blocked=False,
                    escalated=True,
                    violations=[],
                    tokensUsed=0,
                    tokensIn=0,
                    tokensOut=0,
                    latencyMs=0,
                    costUsd=0.0,
                    promptVersion=0,
                    model="",
                    provider="",
                    cached=False,
                    requestId=e.request_id or "",
                    prompt=prompt,
                )
            except Exception as e:
                return BatchRunItemResult(
                    output="",
                    allowed=False,
                    blocked=False,
                    escalated=False,
                    violations=[],
                    tokensUsed=0,
                    tokensIn=0,
                    tokensOut=0,
                    latencyMs=0,
                    costUsd=0.0,
                    promptVersion=0,
                    model="",
                    provider="",
                    cached=False,
                    requestId="",
                    prompt=prompt,
                    error=str(e),
                )

        # Process all inputs in parallel
        tasks = [process_input(item) for item in inputs]
        results = await asyncio.gather(*tasks)

        # Calculate summary
        summary = BatchRunSummary(
            total=len(results),
            allowed=sum(1 for r in results if r.allowed),
            blocked=sum(1 for r in results if r.blocked),
            escalated=sum(1 for r in results if r.escalated),
            failed=sum(1 for r in results if r.error),
            totalCostUsd=sum(r.cost_usd for r in results),
            avgLatencyMs=(
                sum(r.latency_ms for r in results) / len(results)
                if results
                else 0
            ),
            totalTokensUsed=sum(r.tokens_used for r in results),
        )

        return BatchRunResult(results=list(results), summary=summary)

    def run_batch_sync(
        self,
        inputs: List[Union[BatchRunInput, Dict[str, Any]]],
    ) -> BatchRunResult:
        """
        Run multiple prompts in batch (sync).

        Wraps run_batch with asyncio.run.
        """
        return asyncio.run(self.run_batch(inputs))

    def invalidate_cache(self, prompt_name: Optional[str] = None) -> None:
        """
        Invalidate cache for a prompt.

        Args:
            prompt_name: Optional prompt name. If not provided, clears all cache.
        """
        if prompt_name:
            cache_key = create_prompt_cache_key(prompt_name)
            self._cache.invalidate(cache_key)
            self._log("Cache invalidated for prompt:", prompt_name)
        else:
            self._cache.clear()
            self._log("Cache cleared")

    async def health(self) -> Dict[str, Any]:
        """Check API health (async)."""
        return await self._request_async("GET", "/v1/health")

    def health_sync(self) -> Dict[str, Any]:
        """Check API health (sync)."""
        return self._request_sync("GET", "/v1/health")

    # Event registration methods
    def on_blocked(self, handler: Callable) -> "GuardFlow":
        """Register blocked event handler."""
        self._on_blocked.append(handler)
        return self

    def on_escalated(self, handler: Callable) -> "GuardFlow":
        """Register escalated event handler."""
        self._on_escalated.append(handler)
        return self

    def on_error(self, handler: Callable) -> "GuardFlow":
        """Register error event handler."""
        self._on_error.append(handler)
        return self

    def on_complete(self, handler: Callable) -> "GuardFlow":
        """Register complete event handler."""
        self._on_complete.append(handler)
        return self

    def on_retry(self, handler: Callable) -> "GuardFlow":
        """Register retry event handler."""
        self._on_retry.append(handler)
        return self

    async def close(self) -> None:
        """Close HTTP clients."""
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.aclose()
            self._async_client = None

    def close_sync(self) -> None:
        """Close sync HTTP client."""
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()
            self._sync_client = None

    async def __aenter__(self) -> "GuardFlow":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def __enter__(self) -> "GuardFlow":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close_sync()


# Alias for backwards compatibility
AsyncGuardFlow = GuardFlow
