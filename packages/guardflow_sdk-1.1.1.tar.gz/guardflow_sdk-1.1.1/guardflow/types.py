"""
GuardFlow SDK Types
Pydantic v2 models for all SDK types
"""

from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union
from pydantic import BaseModel, Field, ConfigDict


# ============================================================================
# Enums
# ============================================================================


class GuardrailViolationType(str, Enum):
    """Types of guardrail violations."""

    # Core guardrails
    PII_DETECTION = "PII_DETECTION"
    PII_DETECTED = "PII_DETECTED"
    TOXICITY_CHECK = "TOXICITY_CHECK"
    TOXICITY_DETECTED = "TOXICITY_DETECTED"
    KEYWORD_FILTER = "KEYWORD_FILTER"
    PROHIBITED_KEYWORD = "PROHIBITED_KEYWORD"
    REGEX_PATTERN = "REGEX_PATTERN"
    PATTERN_MATCHED = "PATTERN_MATCHED"
    NUMERIC_THRESHOLD = "NUMERIC_THRESHOLD"
    THRESHOLD_EXCEEDED = "THRESHOLD_EXCEEDED"
    BUSINESS_RULE = "BUSINESS_RULE"
    PROHIBITED_CONTENT = "PROHIBITED_CONTENT"
    CUSTOM = "CUSTOM"
    CLASSIFIER_TRIGGERED = "CLASSIFIER_TRIGGERED"
    NSFW_CHECK = "NSFW_CHECK"
    NSFW_DETECTED = "NSFW_DETECTED"
    BIAS_CHECK = "BIAS_CHECK"
    BIAS_DETECTED = "BIAS_DETECTED"
    # Security guardrails
    SECRETS_DETECTION = "SECRETS_DETECTION"
    SECRETS_DETECTED = "SECRETS_DETECTED"
    PROMPT_INJECTION = "PROMPT_INJECTION"
    INJECTION_DETECTED = "INJECTION_DETECTED"
    JAILBREAK_DETECTION = "JAILBREAK_DETECTION"
    JAILBREAK_ATTEMPT = "JAILBREAK_ATTEMPT"
    SQL_INJECTION = "SQL_INJECTION"
    SQL_INJECTION_DETECTED = "SQL_INJECTION_DETECTED"
    # Content guardrails
    COMPETITOR_MENTION = "COMPETITOR_MENTION"
    COMPETITOR_MENTIONED = "COMPETITOR_MENTIONED"
    BAN_LIST = "BAN_LIST"
    GIBBERISH_DETECTION = "GIBBERISH_DETECTION"
    GIBBERISH_DETECTED = "GIBBERISH_DETECTED"
    TOPIC_RESTRICTION = "TOPIC_RESTRICTION"
    OFF_TOPIC = "OFF_TOPIC"
    LANGUAGE_MATCH = "LANGUAGE_MATCH"
    LANGUAGE_MISMATCH = "LANGUAGE_MISMATCH"
    MIXED_SCRIPTS = "MIXED_SCRIPTS"
    HOMOGLYPH_DETECTED = "HOMOGLYPH_DETECTED"
    QA_RELEVANCE = "QA_RELEVANCE"
    IRRELEVANT_RESPONSE = "IRRELEVANT_RESPONSE"
    CONTAINS_URL = "CONTAINS_URL"
    URL_DETECTED = "URL_DETECTED"
    # Output guardrails
    VALID_JSON_OUTPUT = "VALID_JSON_OUTPUT"
    INVALID_JSON = "INVALID_JSON"
    VALID_OPENAPI_SPEC = "VALID_OPENAPI_SPEC"
    INVALID_OPENAPI = "INVALID_OPENAPI"
    VALID_CSV = "VALID_CSV"
    INVALID_CSV = "INVALID_CSV"
    LENGTH_CHECK = "LENGTH_CHECK"
    LENGTH_VIOLATION = "LENGTH_VIOLATION"
    READING_LEVEL = "READING_LEVEL"
    READING_LEVEL_VIOLATION = "READING_LEVEL_VIOLATION"
    # Fraud/Scam guardrails
    FRAUD_DETECTION = "FRAUD_DETECTION"
    FRAUD_DETECTED = "FRAUD_DETECTED"
    INVESTMENT_SCAM = "INVESTMENT_SCAM"
    INVESTMENT_SCAM_DETECTED = "INVESTMENT_SCAM_DETECTED"
    # Fintech guardrails
    LARGE_TRANSACTION_ALERT = "LARGE_TRANSACTION_ALERT"
    LARGE_TRANSACTION = "LARGE_TRANSACTION"
    REGULATORY_DISCLAIMER = "REGULATORY_DISCLAIMER"
    MISSING_DISCLAIMER = "MISSING_DISCLAIMER"
    FINANCIAL_TONE = "FINANCIAL_TONE"
    UNPROFESSIONAL_FINANCIAL_TONE = "UNPROFESSIONAL_FINANCIAL_TONE"
    # New guardrails (Phase 2 - Guardrails AI parity)
    SENSITIVE_TOPIC = "SENSITIVE_TOPIC"
    SENSITIVE_TOPIC_DETECTED = "SENSITIVE_TOPIC_DETECTED"
    MENTIONS_DRUGS = "MENTIONS_DRUGS"
    DRUG_MENTION_DETECTED = "DRUG_MENTION_DETECTED"
    READING_TIME = "READING_TIME"
    READING_TIME_EXCEEDED = "READING_TIME_EXCEEDED"
    VALID_URL = "VALID_URL"
    INVALID_URL = "INVALID_URL"
    VALID_CHOICES = "VALID_CHOICES"
    INVALID_CHOICE = "INVALID_CHOICE"
    WEB_SANITIZATION = "WEB_SANITIZATION"
    XSS_DETECTED = "XSS_DETECTED"
    REDUNDANT_SENTENCES = "REDUNDANT_SENTENCES"
    REDUNDANT_CONTENT = "REDUNDANT_CONTENT"
    VALID_PYTHON = "VALID_PYTHON"
    INVALID_PYTHON = "INVALID_PYTHON"
    VALID_SQL = "VALID_SQL"
    INVALID_SQL = "INVALID_SQL"
    POLITENESS_CHECK = "POLITENESS_CHECK"
    IMPOLITE_CONTENT = "IMPOLITE_CONTENT"
    UNUSUAL_PROMPT = "UNUSUAL_PROMPT"
    UNUSUAL_PROMPT_DETECTED = "UNUSUAL_PROMPT_DETECTED"
    SIMILAR_TO_DOCUMENT = "SIMILAR_TO_DOCUMENT"
    LOW_SIMILARITY = "LOW_SIMILARITY"
    SQL_COLUMN_PRESENCE = "SQL_COLUMN_PRESENCE"
    MISSING_SQL_COLUMN = "MISSING_SQL_COLUMN"
    UPPERCASE_CHECK = "UPPERCASE_CHECK"
    LOWERCASE_CHECK = "LOWERCASE_CHECK"
    CASE_VIOLATION = "CASE_VIOLATION"
    ENDS_WITH_CHECK = "ENDS_WITH_CHECK"
    ONE_LINE_CHECK = "ONE_LINE_CHECK"
    TWO_WORDS_CHECK = "TWO_WORDS_CHECK"
    FORMAT_VIOLATION = "FORMAT_VIOLATION"
    VALID_RANGE = "VALID_RANGE"
    RANGE_VIOLATION = "RANGE_VIOLATION"
    PROFANITY_FREE = "PROFANITY_FREE"
    PROFANITY_DETECTED = "PROFANITY_DETECTED"
    ENDPOINT_REACHABLE = "ENDPOINT_REACHABLE"
    ENDPOINT_UNREACHABLE = "ENDPOINT_UNREACHABLE"
    QUOTES_PRICE = "QUOTES_PRICE"
    PRICE_FORMAT_VIOLATION = "PRICE_FORMAT_VIOLATION"
    # LLM-based validators (Phase 3)
    SALIENCY_CHECK = "SALIENCY_CHECK"
    SALIENCY_ISSUE = "SALIENCY_ISSUE"
    RESPONSE_EVALUATOR = "RESPONSE_EVALUATOR"
    POOR_RESPONSE_QUALITY = "POOR_RESPONSE_QUALITY"
    CONTEXT_RELEVANCY = "CONTEXT_RELEVANCY"
    LOW_CONTEXT_RELEVANCY = "LOW_CONTEXT_RELEVANCY"
    HALLUCINATION_CHECK = "HALLUCINATION_CHECK"
    HALLUCINATION_DETECTED = "HALLUCINATION_DETECTED"
    RAG_EVALUATOR = "RAG_EVALUATOR"
    RAG_QUALITY_ISSUE = "RAG_QUALITY_ISSUE"
    LLM_CRITIC = "LLM_CRITIC"
    LLM_CRITIC_ISSUE = "LLM_CRITIC_ISSUE"
    PROVENANCE_CHECK = "PROVENANCE_CHECK"
    PROVENANCE_ISSUE = "PROVENANCE_ISSUE"


class ViolationSeverity(str, Enum):
    """Severity levels for violations."""

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class ViolationAction(str, Enum):
    """Actions taken for violations."""

    ALLOW = "ALLOW"
    BLOCK = "BLOCK"
    ESCALATE_TO_HUMAN = "ESCALATE_TO_HUMAN"


# ============================================================================
# Configuration Models
# ============================================================================


class CacheConfig(BaseModel):
    """Cache configuration options."""

    model_config = ConfigDict(frozen=True)

    enabled: bool = Field(default=True, description="Enable prompt version caching")
    ttl_seconds: int = Field(default=60, description="Time-to-live for cached entries in seconds")


class GuardFlowConfig(BaseModel):
    """Configuration options for the GuardFlow client."""

    model_config = ConfigDict(frozen=True)

    api_key: str = Field(..., description="Your GuardFlow API key")
    base_url: str = Field(
        default="https://api.guardflow.io",
        description="Base URL for the GuardFlow API",
    )
    timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds",
    )
    max_retries: int = Field(
        default=3,
        description="Maximum number of retry attempts",
    )
    debug: bool = Field(
        default=False,
        description="Enable debug logging",
    )
    cache: Optional[CacheConfig] = Field(
        default=None,
        description="Cache configuration",
    )


# ============================================================================
# Run Options & Results
# ============================================================================


class RunOptions(BaseModel):
    """Options for running a prompt through GuardFlow."""

    model_config = ConfigDict(frozen=True)

    input: str = Field(..., description="The input text to process")
    variables: Optional[Dict[str, str]] = Field(
        default=None,
        description="Variables to substitute in the prompt template",
    )
    session_id: Optional[str] = Field(
        default=None,
        description="Session ID for conversation tracking",
    )
    force_refresh: bool = Field(
        default=False,
        description="Bypass cache and fetch fresh prompt version",
    )
    dry_run: bool = Field(
        default=False,
        description="Validate prompt without making LLM call",
    )
    debug: bool = Field(
        default=False,
        description="Enable debug mode for this request",
    )
    timeout: Optional[float] = Field(
        default=None,
        description="Override client timeout for this request",
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Additional metadata to attach to the request",
    )


class GuardrailViolation(BaseModel):
    """A guardrail violation detected during processing."""

    model_config = ConfigDict(frozen=True)

    policy_id: str = Field(..., alias="policyId", description="Unique identifier for the policy")
    policy_name: str = Field(..., alias="policyName", description="Human-readable policy name")
    type: GuardrailViolationType = Field(..., description="Type of violation detected")
    severity: ViolationSeverity = Field(..., description="Severity level of the violation")
    action: ViolationAction = Field(..., description="Action taken in response to violation")
    detail: str = Field(..., description="Detailed description of the violation")
    matched_content: Optional[str] = Field(
        default=None,
        alias="matchedContent",
        description="Matched content or pattern",
    )
    confidence: Optional[float] = Field(
        default=None,
        description="Confidence score (0-1)",
    )


class RunResult(BaseModel):
    """Result from running a prompt through GuardFlow."""

    model_config = ConfigDict(populate_by_name=True)

    output: str = Field(..., description="The generated output text")
    allowed: bool = Field(..., description="Whether the response was allowed through")
    blocked: bool = Field(..., description="Whether the response was blocked by guardrails")
    escalated: bool = Field(..., description="Whether the response was escalated for human review")
    violations: List[GuardrailViolation] = Field(
        default_factory=list,
        description="List of guardrail violations detected",
    )
    tokens_used: int = Field(..., alias="tokensUsed", description="Total tokens used")
    tokens_in: int = Field(..., alias="tokensIn", description="Input tokens consumed")
    tokens_out: int = Field(..., alias="tokensOut", description="Output tokens generated")
    latency_ms: int = Field(..., alias="latencyMs", description="Total latency in milliseconds")
    cost_usd: float = Field(..., alias="costUsd", description="Estimated cost in USD")
    prompt_version: int = Field(..., alias="promptVersion", description="Prompt version used")
    model: str = Field(..., description="LLM model used")
    provider: str = Field(..., description="LLM provider used")
    cached: bool = Field(default=False, description="Whether the result was served from cache")
    request_id: str = Field(..., alias="requestId", description="Unique request ID")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Raw response metadata",
    )


# ============================================================================
# Batch Processing Types
# ============================================================================


class BatchRunInput(BaseModel):
    """Input for batch processing."""

    model_config = ConfigDict(frozen=True)

    prompt: str = Field(..., description="Name of the prompt to run")
    options: RunOptions = Field(..., description="Run options for this input")


class BatchRunItemResult(RunResult):
    """Individual result in a batch operation."""

    prompt: str = Field(..., description="Prompt name for this result")
    error: Optional[str] = Field(
        default=None,
        description="Error message if this item failed",
    )


class BatchRunSummary(BaseModel):
    """Summary statistics for a batch run."""

    model_config = ConfigDict(frozen=True)

    total: int = Field(..., description="Total number of inputs processed")
    allowed: int = Field(..., description="Number of allowed responses")
    blocked: int = Field(..., description="Number of blocked responses")
    escalated: int = Field(..., description="Number of escalated responses")
    failed: int = Field(..., description="Number of failed requests")
    total_cost_usd: float = Field(
        ...,
        alias="totalCostUsd",
        description="Total cost in USD",
    )
    avg_latency_ms: float = Field(
        ...,
        alias="avgLatencyMs",
        description="Average latency in milliseconds",
    )
    total_tokens_used: int = Field(
        ...,
        alias="totalTokensUsed",
        description="Total tokens used",
    )


class BatchRunResult(BaseModel):
    """Result from a batch run operation."""

    model_config = ConfigDict(frozen=True)

    results: List[BatchRunItemResult] = Field(
        ...,
        description="Individual results for each input",
    )
    summary: BatchRunSummary = Field(..., description="Summary statistics")


# ============================================================================
# API Types
# ============================================================================


class RunApiRequest(BaseModel):
    """API request body for /v1/run."""

    model_config = ConfigDict(populate_by_name=True)

    prompt: str
    input: str
    variables: Optional[Dict[str, str]] = None
    session_id: Optional[str] = Field(default=None, alias="sessionId")
    dry_run: bool = Field(default=False, alias="dryRun")
    metadata: Optional[Dict[str, Any]] = None


class ApiErrorResponse(BaseModel):
    """API error response structure."""

    code: str
    message: str
    violations: Optional[List[Dict[str, Any]]] = None
    retry_after: Optional[int] = Field(default=None, alias="retryAfter")


class RunApiResponse(BaseModel):
    """API response body for /v1/run."""

    model_config = ConfigDict(populate_by_name=True)

    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[ApiErrorResponse] = None
    request_id: str = Field(..., alias="requestId")


# ============================================================================
# Prompt Management Types
# ============================================================================


class Prompt(BaseModel):
    """Prompt resource from the API."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    description: Optional[str] = None
    template: str
    model: str
    provider: str
    system_prompt: Optional[str] = Field(default=None, alias="systemPrompt")
    temperature: Optional[float] = None
    max_tokens: Optional[int] = Field(default=None, alias="maxTokens")
    current_version: int = Field(..., alias="currentVersion")
    is_active: bool = Field(..., alias="isActive")
    tags: Optional[List[str]] = None
    org_id: str = Field(..., alias="orgId")
    created_at: str = Field(..., alias="createdAt")
    updated_at: str = Field(..., alias="updatedAt")


class PromptVersion(BaseModel):
    """Prompt version resource."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    prompt_id: str = Field(..., alias="promptId")
    version: int
    template: str
    model: str
    provider: str
    system_prompt: Optional[str] = Field(default=None, alias="systemPrompt")
    temperature: Optional[float] = None
    max_tokens: Optional[int] = Field(default=None, alias="maxTokens")
    changelog: Optional[str] = None
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    created_at: str = Field(..., alias="createdAt")


class CreatePromptOptions(BaseModel):
    """Options for creating a prompt."""

    name: str
    template: str
    model: str
    provider: str
    description: Optional[str] = None
    system_prompt: Optional[str] = Field(default=None, alias="systemPrompt")
    temperature: Optional[float] = None
    max_tokens: Optional[int] = Field(default=None, alias="maxTokens")
    tags: Optional[List[str]] = None


class UpdatePromptOptions(BaseModel):
    """Options for updating a prompt."""

    name: Optional[str] = None
    description: Optional[str] = None
    template: Optional[str] = None
    model: Optional[str] = None
    provider: Optional[str] = None
    system_prompt: Optional[str] = Field(default=None, alias="systemPrompt")
    temperature: Optional[float] = None
    max_tokens: Optional[int] = Field(default=None, alias="maxTokens")
    tags: Optional[List[str]] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")


class CreateVersionOptions(BaseModel):
    """Options for creating a new prompt version."""

    template: str
    model: Optional[str] = None
    provider: Optional[str] = None
    system_prompt: Optional[str] = Field(default=None, alias="systemPrompt")
    temperature: Optional[float] = None
    max_tokens: Optional[int] = Field(default=None, alias="maxTokens")
    changelog: Optional[str] = None


class DeployOptions(BaseModel):
    """Options for deploying a prompt version."""

    version: int
    environment: Optional[str] = None


class PromptDiff(BaseModel):
    """Prompt diff result."""

    model_config = ConfigDict(populate_by_name=True)

    from_version: int = Field(..., alias="fromVersion")
    to_version: int = Field(..., alias="toVersion")
    changes: List[Dict[str, Any]]


class ListOptions(BaseModel):
    """List options for paginated requests."""

    page: Optional[int] = None
    limit: Optional[int] = None
    search: Optional[str] = None
    sort_by: Optional[str] = Field(default=None, alias="sortBy")
    sort_order: Optional[str] = Field(default=None, alias="sortOrder")


class PaginatedResponse(BaseModel):
    """Paginated response wrapper."""

    data: List[Any]
    total: int
    page: int
    limit: int
    total_pages: int = Field(..., alias="totalPages")


# ============================================================================
# Guardrail Management Types
# ============================================================================


class GuardrailPolicy(BaseModel):
    """Guardrail policy resource."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    description: Optional[str] = None
    type: GuardrailViolationType
    severity: ViolationSeverity
    action: ViolationAction
    is_active: bool = Field(..., alias="isActive")
    config: Dict[str, Any]
    org_id: str = Field(..., alias="orgId")
    created_at: str = Field(..., alias="createdAt")
    updated_at: str = Field(..., alias="updatedAt")


class CreateGuardrailOptions(BaseModel):
    """Options for creating a guardrail policy."""

    name: str
    type: GuardrailViolationType
    severity: ViolationSeverity
    action: ViolationAction
    description: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")


class UpdateGuardrailOptions(BaseModel):
    """Options for updating a guardrail policy."""

    name: Optional[str] = None
    description: Optional[str] = None
    severity: Optional[ViolationSeverity] = None
    action: Optional[ViolationAction] = None
    config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")


class GuardrailCheckOptions(BaseModel):
    """Options for checking text against guardrails."""

    text: str
    policies: Optional[List[str]] = None
    industry: Optional[str] = None
    context: Optional[Dict[str, Any]] = None


class GuardrailCheckResult(BaseModel):
    """Result of a guardrail check."""

    model_config = ConfigDict(populate_by_name=True)

    allowed: bool
    blocked: bool
    escalated: bool
    violations: List[GuardrailViolation]
    checked_policies: List[str] = Field(..., alias="checkedPolicies")
    processing_time_ms: int = Field(..., alias="processingTimeMs")
    request_id: str = Field(..., alias="requestId")


# ============================================================================
# Monitoring Types
# ============================================================================


class MonitoringStats(BaseModel):
    """Monitoring stats."""

    model_config = ConfigDict(populate_by_name=True)

    total_requests: int = Field(..., alias="totalRequests")
    allowed_requests: int = Field(..., alias="allowedRequests")
    blocked_requests: int = Field(..., alias="blockedRequests")
    escalated_requests: int = Field(..., alias="escalatedRequests")
    avg_latency_ms: float = Field(..., alias="avgLatencyMs")
    total_tokens_used: int = Field(..., alias="totalTokensUsed")
    total_cost_usd: float = Field(..., alias="totalCostUsd")
    period: Dict[str, str]


class RequestLog(BaseModel):
    """Request log entry."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    prompt_name: str = Field(..., alias="promptName")
    input: str
    output: Optional[str] = None
    status: str
    violations: List[GuardrailViolation]
    tokens_used: int = Field(..., alias="tokensUsed")
    latency_ms: int = Field(..., alias="latencyMs")
    cost_usd: float = Field(..., alias="costUsd")
    user_id: Optional[str] = Field(default=None, alias="userId")
    session_id: Optional[str] = Field(default=None, alias="sessionId")
    metadata: Optional[Dict[str, Any]] = None
    created_at: str = Field(..., alias="createdAt")


class ViolationLog(BaseModel):
    """Violation event log."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    policy_id: str = Field(..., alias="policyId")
    policy_name: str = Field(..., alias="policyName")
    type: GuardrailViolationType
    severity: ViolationSeverity
    action: ViolationAction
    detail: str
    matched_content: Optional[str] = Field(default=None, alias="matchedContent")
    request_id: str = Field(..., alias="requestId")
    created_at: str = Field(..., alias="createdAt")


class CostOverview(BaseModel):
    """Cost overview."""

    model_config = ConfigDict(populate_by_name=True)

    total_cost_usd: float = Field(..., alias="totalCostUsd")
    by_model: Dict[str, float] = Field(..., alias="byModel")
    by_prompt: Dict[str, float] = Field(..., alias="byPrompt")
    period: Dict[str, str]


class CostTrendPoint(BaseModel):
    """Cost trend data point."""

    model_config = ConfigDict(populate_by_name=True)

    date: str
    cost_usd: float = Field(..., alias="costUsd")
    requests: int
    tokens: int


# ============================================================================
# Evaluation Types
# ============================================================================


class EvalTestResult(BaseModel):
    """Individual test result in an evaluation."""

    model_config = ConfigDict(populate_by_name=True)

    test_case_id: str = Field(..., alias="testCaseId")
    input: str
    expected_output: Optional[str] = Field(default=None, alias="expectedOutput")
    actual_output: str = Field(..., alias="actualOutput")
    passed: bool
    score: Optional[float] = None
    latency_ms: int = Field(..., alias="latencyMs")
    violations: List[GuardrailViolation]


class EvalResult(BaseModel):
    """Evaluation run result."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    prompt_id: str = Field(..., alias="promptId")
    prompt_name: str = Field(..., alias="promptName")
    status: str
    total_tests: int = Field(..., alias="totalTests")
    passed_tests: int = Field(..., alias="passedTests")
    failed_tests: int = Field(..., alias="failedTests")
    accuracy: float
    avg_latency_ms: float = Field(..., alias="avgLatencyMs")
    results: List[EvalTestResult]
    started_at: str = Field(..., alias="startedAt")
    completed_at: Optional[str] = Field(default=None, alias="completedAt")


class RunEvalOptions(BaseModel):
    """Options for running an evaluation."""

    model_config = ConfigDict(populate_by_name=True)

    prompt_id: str = Field(..., alias="promptId")
    test_case_ids: Optional[List[str]] = Field(default=None, alias="testCaseIds")
    version: Optional[int] = None
    max_concurrency: Optional[int] = Field(default=None, alias="maxConcurrency")


# ============================================================================
# Test Case Types
# ============================================================================


class TestCase(BaseModel):
    """Test case resource."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    description: Optional[str] = None
    input: str
    expected_output: Optional[str] = Field(default=None, alias="expectedOutput")
    variables: Optional[Dict[str, str]] = None
    tags: Optional[List[str]] = None
    prompt_id: Optional[str] = Field(default=None, alias="promptId")
    org_id: str = Field(..., alias="orgId")
    created_at: str = Field(..., alias="createdAt")
    updated_at: str = Field(..., alias="updatedAt")


class CreateTestCaseOptions(BaseModel):
    """Options for creating a test case."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    input: str
    description: Optional[str] = None
    expected_output: Optional[str] = Field(default=None, alias="expectedOutput")
    variables: Optional[Dict[str, str]] = None
    tags: Optional[List[str]] = None
    prompt_id: Optional[str] = Field(default=None, alias="promptId")


class UpdateTestCaseOptions(BaseModel):
    """Options for updating a test case."""

    model_config = ConfigDict(populate_by_name=True)

    name: Optional[str] = None
    description: Optional[str] = None
    input: Optional[str] = None
    expected_output: Optional[str] = Field(default=None, alias="expectedOutput")
    variables: Optional[Dict[str, str]] = None
    tags: Optional[List[str]] = None


# ============================================================================
# Agent Types
# ============================================================================


class Agent(BaseModel):
    """Agent resource."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    description: Optional[str] = None
    prompt_ids: List[str] = Field(..., alias="promptIds")
    guardrail_policy_ids: List[str] = Field(..., alias="guardrailPolicyIds")
    config: Dict[str, Any]
    is_active: bool = Field(..., alias="isActive")
    deployed_version: Optional[int] = Field(default=None, alias="deployedVersion")
    org_id: str = Field(..., alias="orgId")
    created_at: str = Field(..., alias="createdAt")
    updated_at: str = Field(..., alias="updatedAt")


class CreateAgentOptions(BaseModel):
    """Options for creating an agent."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: Optional[str] = None
    prompt_ids: Optional[List[str]] = Field(default=None, alias="promptIds")
    guardrail_policy_ids: Optional[List[str]] = Field(default=None, alias="guardrailPolicyIds")
    config: Optional[Dict[str, Any]] = None


class UpdateAgentOptions(BaseModel):
    """Options for updating an agent."""

    model_config = ConfigDict(populate_by_name=True)

    name: Optional[str] = None
    description: Optional[str] = None
    prompt_ids: Optional[List[str]] = Field(default=None, alias="promptIds")
    guardrail_policy_ids: Optional[List[str]] = Field(default=None, alias="guardrailPolicyIds")
    config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = Field(default=None, alias="isActive")


# ============================================================================
# Deployment Types
# ============================================================================


class DeploymentMetrics(BaseModel):
    """Deployment metrics."""

    model_config = ConfigDict(populate_by_name=True)

    total_requests: int = Field(..., alias="totalRequests")
    success_rate: float = Field(..., alias="successRate")
    avg_latency_ms: float = Field(..., alias="avgLatencyMs")
    error_rate: float = Field(..., alias="errorRate")
    blocked_rate: float = Field(..., alias="blockedRate")
    canary_requests: Optional[int] = Field(default=None, alias="canaryRequests")
    baseline_requests: Optional[int] = Field(default=None, alias="baselineRequests")


class Deployment(BaseModel):
    """Deployment resource."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    prompt_id: str = Field(..., alias="promptId")
    prompt_name: str = Field(..., alias="promptName")
    version: int
    environment: str
    status: str
    canary_percentage: Optional[int] = Field(default=None, alias="canaryPercentage")
    metrics: Optional[DeploymentMetrics] = None
    created_by: Optional[str] = Field(default=None, alias="createdBy")
    created_at: str = Field(..., alias="createdAt")
    promoted_at: Optional[str] = Field(default=None, alias="promotedAt")
    rolled_back_at: Optional[str] = Field(default=None, alias="rolledBackAt")


class StartCanaryOptions(BaseModel):
    """Options for starting a canary deployment."""

    model_config = ConfigDict(populate_by_name=True)

    prompt_id: str = Field(..., alias="promptId")
    version: int
    percentage: Optional[int] = None
    environment: Optional[str] = None


class PromoteDeploymentOptions(BaseModel):
    """Options for promoting a deployment."""

    immediate: Optional[bool] = None
