"""
GuardFlow SDK Exceptions
Comprehensive error handling for all SDK operations
"""

from typing import Any, Dict, List, Optional


class GuardFlowError(Exception):
    """Base exception class for all GuardFlow errors."""

    def __init__(
        self,
        message: str,
        code: str,
        status: Optional[int] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.message = message
        self.code = code
        self.status = status
        self.request_id = request_id

    def __str__(self) -> str:
        parts = [f"GuardFlowError({self.code})"]
        if self.status:
            parts.append(f"[{self.status}]")
        parts.append(f": {self.message}")
        return "".join(parts)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"message={self.message!r}, "
            f"code={self.code!r}, "
            f"status={self.status!r}, "
            f"request_id={self.request_id!r})"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for logging/serialization."""
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "code": self.code,
            "status": self.status,
            "request_id": self.request_id,
        }


class BlockedError(GuardFlowError):
    """Exception raised when a response is blocked by guardrails."""

    def __init__(
        self,
        violations: List[Dict[str, Any]],
        request_id: Optional[str] = None,
    ):
        policy_names = ", ".join(v.get("policyName", "Unknown") for v in violations)
        message = f"Response blocked by guardrail: {policy_names}"
        super().__init__(message, "BLOCKED", 200, request_id)
        self.violations = violations

    def get_violations_by_severity(self, severity: str) -> List[Dict[str, Any]]:
        """Get violations filtered by severity."""
        return [v for v in self.violations if v.get("severity") == severity]

    def get_violations_by_type(self, violation_type: str) -> List[Dict[str, Any]]:
        """Get violations filtered by type."""
        return [v for v in self.violations if v.get("type") == violation_type]

    def has_critical_violation(self) -> bool:
        """Check if any violation has critical severity."""
        return any(v.get("severity") == "CRITICAL" for v in self.violations)

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        data = super().to_dict()
        data["violations"] = self.violations
        return data


class EscalatedError(GuardFlowError):
    """Exception raised when a response is escalated for human review."""

    def __init__(
        self,
        reason: Optional[str] = None,
        violations: Optional[List[Dict[str, Any]]] = None,
        request_id: Optional[str] = None,
    ):
        message = reason or "Response escalated for human review"
        super().__init__(message, "ESCALATED", 200, request_id)
        self.reason = reason
        self.violations = violations or []

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        data = super().to_dict()
        data["reason"] = self.reason
        data["violations"] = self.violations
        return data


class RateLimitError(GuardFlowError):
    """Exception raised when rate limit is exceeded."""

    def __init__(
        self,
        retry_after_seconds: int,
        request_id: Optional[str] = None,
    ):
        message = f"Rate limit exceeded. Retry after {retry_after_seconds} seconds"
        super().__init__(message, "RATE_LIMIT", 429, request_id)
        self.retry_after_seconds = retry_after_seconds

    @property
    def retry_after_ms(self) -> int:
        """Get retry after time in milliseconds."""
        return self.retry_after_seconds * 1000

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        data = super().to_dict()
        data["retry_after_seconds"] = self.retry_after_seconds
        return data


class AuthError(GuardFlowError):
    """Exception raised for authentication/authorization failures."""

    def __init__(
        self,
        message: str = "Invalid or expired API key",
        request_id: Optional[str] = None,
    ):
        super().__init__(message, "AUTH_ERROR", 401, request_id)


class TimeoutError(GuardFlowError):
    """Exception raised when a request times out."""

    def __init__(
        self,
        timeout_seconds: float,
        request_id: Optional[str] = None,
    ):
        message = f"Request timed out after {timeout_seconds}s"
        super().__init__(message, "TIMEOUT", None, request_id)
        self.timeout_seconds = timeout_seconds

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        data = super().to_dict()
        data["timeout_seconds"] = self.timeout_seconds
        return data


class ValidationError(GuardFlowError):
    """Exception raised for validation errors."""

    def __init__(
        self,
        message: str,
        field_errors: Optional[Dict[str, str]] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message, "VALIDATION_ERROR", 400, request_id)
        self.field_errors = field_errors or {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        data = super().to_dict()
        data["field_errors"] = self.field_errors
        return data


class PromptNotFoundError(GuardFlowError):
    """Exception raised when a prompt is not found."""

    def __init__(
        self,
        prompt_name: str,
        request_id: Optional[str] = None,
    ):
        message = f"Prompt not found: {prompt_name}"
        super().__init__(message, "PROMPT_NOT_FOUND", 404, request_id)
        self.prompt_name = prompt_name

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        data = super().to_dict()
        data["prompt_name"] = self.prompt_name
        return data


class NetworkError(GuardFlowError):
    """Exception raised for network-related issues."""

    def __init__(
        self,
        message: str,
        cause: Optional[Exception] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message, "NETWORK_ERROR", None, request_id)
        self.cause = cause

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        data = super().to_dict()
        if self.cause:
            data["cause"] = str(self.cause)
        return data


class GuardFlowAPIError(GuardFlowError):
    """Exception raised for general API errors."""

    def __init__(
        self,
        message: str,
        status: int,
        body: Any,
        request_id: Optional[str] = None,
    ):
        super().__init__(message, "API_ERROR", status, request_id)
        self.body = body

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary."""
        data = super().to_dict()
        data["body"] = self.body
        return data


def is_retryable_error(error: Exception) -> bool:
    """Check if an error is retryable."""
    if isinstance(error, RateLimitError):
        return True
    if isinstance(error, GuardFlowAPIError):
        return error.status in (500, 502, 503, 504)
    if isinstance(error, (NetworkError, TimeoutError)):
        return True
    return False


def create_error_from_response(
    status: int,
    body: Dict[str, Any],
    request_id: Optional[str] = None,
) -> GuardFlowError:
    """Create appropriate error from API response."""
    message = body.get("message") or body.get("error") or "Unknown error"
    code = body.get("code")

    if status == 401:
        return AuthError(message, request_id)

    if status == 404:
        if code == "PROMPT_NOT_FOUND":
            return PromptNotFoundError(body.get("promptName", "unknown"), request_id)
        return GuardFlowAPIError(message, status, body, request_id)

    if status == 429:
        retry_after = body.get("retryAfter", 60)
        return RateLimitError(retry_after, request_id)

    if status == 400:
        field_errors = body.get("fieldErrors", {})
        return ValidationError(message, field_errors, request_id)

    return GuardFlowAPIError(message, status, body, request_id)
