"""GuardFlow Guardrails Resource - Manage guardrail policies and run checks."""

from typing import Any, Callable, Coroutine, Dict, List, Optional

from ..types import (
    GuardrailPolicy,
    CreateGuardrailOptions,
    UpdateGuardrailOptions,
    GuardrailCheckOptions,
    GuardrailCheckResult,
    ViolationLog,
    ListOptions,
    PaginatedResponse,
)


class GuardrailsResource:
    """Guardrails resource for managing policies and running checks."""

    def __init__(
        self,
        request_async: Callable[..., Coroutine[Any, Any, Dict[str, Any]]],
        request_sync: Callable[..., Dict[str, Any]],
    ):
        self._request_async = request_async
        self._request_sync = request_sync

    async def check(self, options: GuardrailCheckOptions) -> GuardrailCheckResult:
        """Check text against guardrail policies."""
        data = await self._request_async(
            "POST",
            "/api/guardrails/check",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailCheckResult(**data)

    def check_sync(self, options: GuardrailCheckOptions) -> GuardrailCheckResult:
        """Check text against guardrail policies (sync)."""
        data = self._request_sync(
            "POST",
            "/api/guardrails/check",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailCheckResult(**data)

    async def list(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all guardrail policies."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
            if options.search:
                params["search"] = options.search

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/guardrails/policies?{query}" if query else "/api/guardrails/policies"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def list_sync(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all guardrail policies (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/guardrails/policies?{query}" if query else "/api/guardrails/policies"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    async def get(self, policy_id: str) -> GuardrailPolicy:
        """Get a guardrail policy by ID."""
        data = await self._request_async("GET", f"/api/guardrails/policies/{policy_id}")
        return GuardrailPolicy(**data)

    def get_sync(self, policy_id: str) -> GuardrailPolicy:
        """Get a guardrail policy by ID (sync)."""
        data = self._request_sync("GET", f"/api/guardrails/policies/{policy_id}")
        return GuardrailPolicy(**data)

    async def create(self, options: CreateGuardrailOptions) -> GuardrailPolicy:
        """Create a new guardrail policy."""
        data = await self._request_async(
            "POST",
            "/api/guardrails/policies",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailPolicy(**data)

    def create_sync(self, options: CreateGuardrailOptions) -> GuardrailPolicy:
        """Create a new guardrail policy (sync)."""
        data = self._request_sync(
            "POST",
            "/api/guardrails/policies",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailPolicy(**data)

    async def update(
        self, policy_id: str, options: UpdateGuardrailOptions
    ) -> GuardrailPolicy:
        """Update a guardrail policy."""
        data = await self._request_async(
            "PUT",
            f"/api/guardrails/policies/{policy_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailPolicy(**data)

    def update_sync(
        self, policy_id: str, options: UpdateGuardrailOptions
    ) -> GuardrailPolicy:
        """Update a guardrail policy (sync)."""
        data = self._request_sync(
            "PUT",
            f"/api/guardrails/policies/{policy_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailPolicy(**data)

    async def delete(self, policy_id: str) -> None:
        """Delete a guardrail policy."""
        await self._request_async("DELETE", f"/api/guardrails/policies/{policy_id}")

    def delete_sync(self, policy_id: str) -> None:
        """Delete a guardrail policy (sync)."""
        self._request_sync("DELETE", f"/api/guardrails/policies/{policy_id}")

    async def violations(
        self, options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """List violation events."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/guardrails/violations?{query}" if query else "/api/guardrails/violations"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)
