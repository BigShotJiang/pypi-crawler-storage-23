"""GuardFlow Prompts Resource - Manage prompts, versions, and deployments."""

from typing import Any, Callable, Dict, List, Optional, Coroutine

from ..types import (
    Prompt,
    PromptVersion,
    CreatePromptOptions,
    UpdatePromptOptions,
    CreateVersionOptions,
    DeployOptions,
    PromptDiff,
    ListOptions,
    PaginatedResponse,
)


class PromptsResource:
    """Prompts resource for managing prompts and versions."""

    def __init__(
        self,
        request_async: Callable[..., Coroutine[Any, Any, Dict[str, Any]]],
        request_sync: Callable[..., Dict[str, Any]],
    ):
        self._request_async = request_async
        self._request_sync = request_sync

    async def list(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all prompts."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
            if options.search:
                params["search"] = options.search
            if options.sort_by:
                params["sortBy"] = options.sort_by
            if options.sort_order:
                params["sortOrder"] = options.sort_order

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/prompts?{query}" if query else "/api/prompts"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def list_sync(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all prompts (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
            if options.search:
                params["search"] = options.search

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/prompts?{query}" if query else "/api/prompts"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    async def get(self, prompt_id: str) -> Prompt:
        """Get a prompt by ID."""
        data = await self._request_async("GET", f"/api/prompts/{prompt_id}")
        return Prompt(**data)

    def get_sync(self, prompt_id: str) -> Prompt:
        """Get a prompt by ID (sync)."""
        data = self._request_sync("GET", f"/api/prompts/{prompt_id}")
        return Prompt(**data)

    async def get_by_name(self, name: str) -> Prompt:
        """Get a prompt by name."""
        result = await self.list(ListOptions(search=name, limit=1))
        for p in result.data:
            prompt = Prompt(**p) if isinstance(p, dict) else p
            if prompt.name == name:
                return prompt
        raise ValueError(f"Prompt not found: {name}")

    async def create(self, options: CreatePromptOptions) -> Prompt:
        """Create a new prompt."""
        data = await self._request_async(
            "POST", "/api/prompts", json=options.model_dump(by_alias=True, exclude_none=True)
        )
        return Prompt(**data)

    def create_sync(self, options: CreatePromptOptions) -> Prompt:
        """Create a new prompt (sync)."""
        data = self._request_sync(
            "POST", "/api/prompts", json=options.model_dump(by_alias=True, exclude_none=True)
        )
        return Prompt(**data)

    async def update(self, prompt_id: str, options: UpdatePromptOptions) -> Prompt:
        """Update an existing prompt."""
        data = await self._request_async(
            "PUT",
            f"/api/prompts/{prompt_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Prompt(**data)

    def update_sync(self, prompt_id: str, options: UpdatePromptOptions) -> Prompt:
        """Update an existing prompt (sync)."""
        data = self._request_sync(
            "PUT",
            f"/api/prompts/{prompt_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Prompt(**data)

    async def delete(self, prompt_id: str) -> None:
        """Delete a prompt."""
        await self._request_async("DELETE", f"/api/prompts/{prompt_id}")

    def delete_sync(self, prompt_id: str) -> None:
        """Delete a prompt (sync)."""
        self._request_sync("DELETE", f"/api/prompts/{prompt_id}")

    async def get_versions(self, prompt_id: str) -> List[PromptVersion]:
        """List all versions of a prompt."""
        data = await self._request_async("GET", f"/api/prompts/{prompt_id}/versions")
        return [PromptVersion(**v) for v in data]

    def get_versions_sync(self, prompt_id: str) -> List[PromptVersion]:
        """List all versions of a prompt (sync)."""
        data = self._request_sync("GET", f"/api/prompts/{prompt_id}/versions")
        return [PromptVersion(**v) for v in data]

    async def get_version(self, prompt_id: str, version: int) -> PromptVersion:
        """Get a specific version of a prompt."""
        data = await self._request_async(
            "GET", f"/api/prompts/{prompt_id}/versions/{version}"
        )
        return PromptVersion(**data)

    async def create_version(
        self, prompt_id: str, options: CreateVersionOptions
    ) -> PromptVersion:
        """Create a new version of a prompt."""
        data = await self._request_async(
            "POST",
            f"/api/prompts/{prompt_id}/versions",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return PromptVersion(**data)

    async def deploy(self, prompt_id: str, options: DeployOptions) -> Prompt:
        """Deploy a specific version of a prompt."""
        data = await self._request_async(
            "POST",
            f"/api/prompts/{prompt_id}/deploy",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Prompt(**data)

    async def rollback(self, prompt_id: str, version: Optional[int] = None) -> Prompt:
        """Rollback to a previous version."""
        data = await self._request_async(
            "POST", f"/api/prompts/{prompt_id}/rollback", json={"version": version}
        )
        return Prompt(**data)

    async def diff(
        self, prompt_id: str, from_version: int, to_version: int
    ) -> PromptDiff:
        """Get diff between two versions."""
        data = await self._request_async(
            "GET", f"/api/prompts/{prompt_id}/diff?from={from_version}&to={to_version}"
        )
        return PromptDiff(**data)
