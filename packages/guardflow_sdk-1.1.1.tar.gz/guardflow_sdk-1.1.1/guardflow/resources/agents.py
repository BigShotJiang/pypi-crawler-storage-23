"""GuardFlow Agents Resource - Manage AI agents and their deployments."""

from typing import Any, Callable, Coroutine, Dict, List, Optional

from ..types import (
    Agent,
    CreateAgentOptions,
    UpdateAgentOptions,
    ListOptions,
    PaginatedResponse,
)


class AgentsResource:
    """Agents resource for managing AI agents."""

    def __init__(
        self,
        request_async: Callable[..., Coroutine[Any, Any, Dict[str, Any]]],
        request_sync: Callable[..., Dict[str, Any]],
    ):
        self._request_async = request_async
        self._request_sync = request_sync

    async def list(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all agents."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
            if options.search:
                params["search"] = options.search

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/agents?{query}" if query else "/api/agents"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def list_sync(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all agents (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/agents?{query}" if query else "/api/agents"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    async def get(self, agent_id: str) -> Agent:
        """Get an agent by ID."""
        data = await self._request_async("GET", f"/api/agents/{agent_id}")
        return Agent(**data)

    def get_sync(self, agent_id: str) -> Agent:
        """Get an agent by ID (sync)."""
        data = self._request_sync("GET", f"/api/agents/{agent_id}")
        return Agent(**data)

    async def create(self, options: CreateAgentOptions) -> Agent:
        """Create a new agent."""
        data = await self._request_async(
            "POST",
            "/api/agents",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Agent(**data)

    def create_sync(self, options: CreateAgentOptions) -> Agent:
        """Create a new agent (sync)."""
        data = self._request_sync(
            "POST",
            "/api/agents",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Agent(**data)

    async def update(self, agent_id: str, options: UpdateAgentOptions) -> Agent:
        """Update an agent."""
        data = await self._request_async(
            "PUT",
            f"/api/agents/{agent_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Agent(**data)

    def update_sync(self, agent_id: str, options: UpdateAgentOptions) -> Agent:
        """Update an agent (sync)."""
        data = self._request_sync(
            "PUT",
            f"/api/agents/{agent_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Agent(**data)

    async def delete(self, agent_id: str) -> None:
        """Delete an agent."""
        await self._request_async("DELETE", f"/api/agents/{agent_id}")

    def delete_sync(self, agent_id: str) -> None:
        """Delete an agent (sync)."""
        self._request_sync("DELETE", f"/api/agents/{agent_id}")

    async def deploy(
        self,
        agent_id: str,
        environment: Optional[str] = None,
    ) -> Agent:
        """Deploy an agent."""
        data = await self._request_async(
            "POST",
            f"/api/agents/{agent_id}/deploy",
            json={"environment": environment} if environment else None,
        )
        return Agent(**data)

    def deploy_sync(
        self,
        agent_id: str,
        environment: Optional[str] = None,
    ) -> Agent:
        """Deploy an agent (sync)."""
        data = self._request_sync(
            "POST",
            f"/api/agents/{agent_id}/deploy",
            json={"environment": environment} if environment else None,
        )
        return Agent(**data)

    async def add_prompts(self, agent_id: str, prompt_ids: List[str]) -> Agent:
        """Add prompts to an agent."""
        agent = await self.get(agent_id)
        new_prompt_ids = list(set(agent.prompt_ids + prompt_ids))
        return await self.update(
            agent_id, UpdateAgentOptions(prompt_ids=new_prompt_ids)
        )

    async def remove_prompts(self, agent_id: str, prompt_ids: List[str]) -> Agent:
        """Remove prompts from an agent."""
        agent = await self.get(agent_id)
        new_prompt_ids = [p for p in agent.prompt_ids if p not in prompt_ids]
        return await self.update(
            agent_id, UpdateAgentOptions(prompt_ids=new_prompt_ids)
        )

    async def add_guardrails(self, agent_id: str, policy_ids: List[str]) -> Agent:
        """Add guardrail policies to an agent."""
        agent = await self.get(agent_id)
        new_policy_ids = list(set(agent.guardrail_policy_ids + policy_ids))
        return await self.update(
            agent_id, UpdateAgentOptions(guardrail_policy_ids=new_policy_ids)
        )

    async def remove_guardrails(self, agent_id: str, policy_ids: List[str]) -> Agent:
        """Remove guardrail policies from an agent."""
        agent = await self.get(agent_id)
        new_policy_ids = [p for p in agent.guardrail_policy_ids if p not in policy_ids]
        return await self.update(
            agent_id, UpdateAgentOptions(guardrail_policy_ids=new_policy_ids)
        )

    async def activate(self, agent_id: str) -> Agent:
        """Activate an agent."""
        return await self.update(agent_id, UpdateAgentOptions(is_active=True))

    async def deactivate(self, agent_id: str) -> Agent:
        """Deactivate an agent."""
        return await self.update(agent_id, UpdateAgentOptions(is_active=False))
