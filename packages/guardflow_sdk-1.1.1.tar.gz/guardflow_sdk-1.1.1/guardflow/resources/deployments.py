"""GuardFlow Deployments Resource - Manage deployments and canary releases."""

import asyncio
from typing import Any, Callable, Coroutine, Dict, Optional

from ..types import (
    Deployment,
    DeploymentMetrics,
    StartCanaryOptions,
    PromoteDeploymentOptions,
    ListOptions,
    PaginatedResponse,
)


class DeploymentsResource:
    """Deployments resource for managing canary releases."""

    def __init__(
        self,
        request_async: Callable[..., Coroutine[Any, Any, Dict[str, Any]]],
        request_sync: Callable[..., Dict[str, Any]],
    ):
        self._request_async = request_async
        self._request_sync = request_sync

    async def list(
        self,
        options: Optional[ListOptions] = None,
        status: Optional[str] = None,
        prompt_id: Optional[str] = None,
    ) -> PaginatedResponse:
        """List all deployments."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
        if status:
            params["status"] = status
        if prompt_id:
            params["promptId"] = prompt_id

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/deployments?{query}" if query else "/api/deployments"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def list_sync(
        self,
        options: Optional[ListOptions] = None,
        status: Optional[str] = None,
        prompt_id: Optional[str] = None,
    ) -> PaginatedResponse:
        """List all deployments (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
        if status:
            params["status"] = status
        if prompt_id:
            params["promptId"] = prompt_id

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/deployments?{query}" if query else "/api/deployments"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    async def get(self, deployment_id: str) -> Deployment:
        """Get a deployment by ID."""
        data = await self._request_async("GET", f"/api/deployments/{deployment_id}")
        return Deployment(**data)

    def get_sync(self, deployment_id: str) -> Deployment:
        """Get a deployment by ID (sync)."""
        data = self._request_sync("GET", f"/api/deployments/{deployment_id}")
        return Deployment(**data)

    async def start_canary(self, options: StartCanaryOptions) -> Deployment:
        """Start a canary deployment."""
        data = await self._request_async(
            "POST",
            "/api/deployments/canary",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Deployment(**data)

    def start_canary_sync(self, options: StartCanaryOptions) -> Deployment:
        """Start a canary deployment (sync)."""
        data = self._request_sync(
            "POST",
            "/api/deployments/canary",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return Deployment(**data)

    async def promote(
        self,
        deployment_id: str,
        options: Optional[PromoteDeploymentOptions] = None,
    ) -> Deployment:
        """Promote a canary to full deployment."""
        data = await self._request_async(
            "PUT",
            f"/api/deployments/{deployment_id}/promote",
            json=options.model_dump(by_alias=True, exclude_none=True) if options else None,
        )
        return Deployment(**data)

    def promote_sync(
        self,
        deployment_id: str,
        options: Optional[PromoteDeploymentOptions] = None,
    ) -> Deployment:
        """Promote a canary to full deployment (sync)."""
        data = self._request_sync(
            "PUT",
            f"/api/deployments/{deployment_id}/promote",
            json=options.model_dump(by_alias=True, exclude_none=True) if options else None,
        )
        return Deployment(**data)

    async def rollback(self, deployment_id: str) -> Deployment:
        """Rollback a deployment."""
        data = await self._request_async(
            "PUT", f"/api/deployments/{deployment_id}/rollback"
        )
        return Deployment(**data)

    def rollback_sync(self, deployment_id: str) -> Deployment:
        """Rollback a deployment (sync)."""
        data = self._request_sync("PUT", f"/api/deployments/{deployment_id}/rollback")
        return Deployment(**data)

    async def metrics(self, deployment_id: str) -> DeploymentMetrics:
        """Get deployment metrics."""
        data = await self._request_async(
            "GET", f"/api/deployments/{deployment_id}/metrics"
        )
        return DeploymentMetrics(**data)

    def metrics_sync(self, deployment_id: str) -> DeploymentMetrics:
        """Get deployment metrics (sync)."""
        data = self._request_sync("GET", f"/api/deployments/{deployment_id}/metrics")
        return DeploymentMetrics(**data)

    async def increase_canary(
        self, deployment_id: str, percentage: int
    ) -> Deployment:
        """Increase canary percentage."""
        data = await self._request_async(
            "PUT",
            f"/api/deployments/{deployment_id}/canary",
            json={"percentage": percentage},
        )
        return Deployment(**data)

    async def wait_for_metrics(
        self,
        deployment_id: str,
        min_requests: int = 100,
        min_success_rate: float = 90.0,
        max_error_rate: float = 5.0,
        timeout_seconds: float = 3600.0,
        poll_interval_seconds: float = 30.0,
    ) -> DeploymentMetrics:
        """Wait for deployment metrics to meet criteria."""
        elapsed = 0.0
        while elapsed < timeout_seconds:
            metrics = await self.metrics(deployment_id)

            meets_requests = metrics.total_requests >= min_requests
            meets_success = metrics.success_rate >= min_success_rate
            meets_error = metrics.error_rate <= max_error_rate

            if meets_requests and meets_success and meets_error:
                return metrics

            await asyncio.sleep(poll_interval_seconds)
            elapsed += poll_interval_seconds

        raise TimeoutError(
            f"Deployment {deployment_id} did not meet criteria within {timeout_seconds}s"
        )

    async def list_canaries(
        self, options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """List active canary deployments."""
        return await self.list(options=options, status="canary")

    async def list_by_prompt(
        self, prompt_id: str, options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """List deployments for a specific prompt."""
        return await self.list(options=options, prompt_id=prompt_id)
