"""GuardFlow Evals Resource - Run and manage evaluations."""

import asyncio
from typing import Any, Callable, Coroutine, Dict, Optional

from ..types import (
    EvalResult,
    RunEvalOptions,
    ListOptions,
    PaginatedResponse,
)


class EvalsResource:
    """Evals resource for running and managing evaluations."""

    def __init__(
        self,
        request_async: Callable[..., Coroutine[Any, Any, Dict[str, Any]]],
        request_sync: Callable[..., Dict[str, Any]],
    ):
        self._request_async = request_async
        self._request_sync = request_sync

    async def run(self, options: RunEvalOptions) -> EvalResult:
        """Run an evaluation."""
        data = await self._request_async(
            "POST",
            "/api/evals/run",
            json=options.model_dump(by_alias=True, exclude_none=True),
            timeout=120.0,  # Evals can take longer
        )
        return EvalResult(**data)

    def run_sync(self, options: RunEvalOptions) -> EvalResult:
        """Run an evaluation (sync)."""
        data = self._request_sync(
            "POST",
            "/api/evals/run",
            json=options.model_dump(by_alias=True, exclude_none=True),
            timeout=120.0,
        )
        return EvalResult(**data)

    async def get(self, eval_id: str) -> EvalResult:
        """Get an evaluation result by ID."""
        data = await self._request_async("GET", f"/api/evals/{eval_id}")
        return EvalResult(**data)

    def get_sync(self, eval_id: str) -> EvalResult:
        """Get an evaluation result by ID (sync)."""
        data = self._request_sync("GET", f"/api/evals/{eval_id}")
        return EvalResult(**data)

    async def list(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all evaluations."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/evals?{query}" if query else "/api/evals"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def list_sync(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all evaluations (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/evals?{query}" if query else "/api/evals"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    async def list_by_prompt(
        self, prompt_id: str, options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """List evaluations for a specific prompt."""
        params = {"promptId": prompt_id}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        data = await self._request_async("GET", f"/api/evals?{query}")
        return PaginatedResponse(**data)

    async def wait_for_completion(
        self,
        eval_id: str,
        poll_interval_seconds: float = 2.0,
        timeout_seconds: float = 300.0,
    ) -> EvalResult:
        """Wait for an evaluation to complete."""
        elapsed = 0.0
        while elapsed < timeout_seconds:
            result = await self.get(eval_id)
            if result.status in ("completed", "failed"):
                return result
            await asyncio.sleep(poll_interval_seconds)
            elapsed += poll_interval_seconds

        raise TimeoutError(
            f"Evaluation {eval_id} did not complete within {timeout_seconds}s"
        )
