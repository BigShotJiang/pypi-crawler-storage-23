"""GuardFlow Test Cases Resource - Manage test cases for evaluations."""

from typing import Any, Callable, Coroutine, Dict, List, Optional

from ..types import (
    TestCase,
    CreateTestCaseOptions,
    UpdateTestCaseOptions,
    ListOptions,
    PaginatedResponse,
)


class TestCasesResource:
    """Test cases resource for managing evaluation test cases."""

    def __init__(
        self,
        request_async: Callable[..., Coroutine[Any, Any, Dict[str, Any]]],
        request_sync: Callable[..., Dict[str, Any]],
    ):
        self._request_async = request_async
        self._request_sync = request_sync

    async def list(
        self,
        options: Optional[ListOptions] = None,
        prompt_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> PaginatedResponse:
        """List all test cases."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
            if options.search:
                params["search"] = options.search
        if prompt_id:
            params["promptId"] = prompt_id
        if tags:
            params["tags"] = ",".join(tags)

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/test-cases?{query}" if query else "/api/test-cases"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def list_sync(
        self,
        options: Optional[ListOptions] = None,
        prompt_id: Optional[str] = None,
    ) -> PaginatedResponse:
        """List all test cases (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
        if prompt_id:
            params["promptId"] = prompt_id

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/test-cases?{query}" if query else "/api/test-cases"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    async def get(self, test_case_id: str) -> TestCase:
        """Get a test case by ID."""
        data = await self._request_async("GET", f"/api/test-cases/{test_case_id}")
        return TestCase(**data)

    def get_sync(self, test_case_id: str) -> TestCase:
        """Get a test case by ID (sync)."""
        data = self._request_sync("GET", f"/api/test-cases/{test_case_id}")
        return TestCase(**data)

    async def create(self, options: CreateTestCaseOptions) -> TestCase:
        """Create a new test case."""
        data = await self._request_async(
            "POST",
            "/api/test-cases",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return TestCase(**data)

    def create_sync(self, options: CreateTestCaseOptions) -> TestCase:
        """Create a new test case (sync)."""
        data = self._request_sync(
            "POST",
            "/api/test-cases",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return TestCase(**data)

    async def create_bulk(
        self, test_cases: List[CreateTestCaseOptions]
    ) -> List[TestCase]:
        """Create multiple test cases at once."""
        data = await self._request_async(
            "POST",
            "/api/test-cases/bulk",
            json={
                "testCases": [
                    tc.model_dump(by_alias=True, exclude_none=True) for tc in test_cases
                ]
            },
        )
        return [TestCase(**tc) for tc in data]

    async def update(
        self, test_case_id: str, options: UpdateTestCaseOptions
    ) -> TestCase:
        """Update a test case."""
        data = await self._request_async(
            "PUT",
            f"/api/test-cases/{test_case_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return TestCase(**data)

    def update_sync(
        self, test_case_id: str, options: UpdateTestCaseOptions
    ) -> TestCase:
        """Update a test case (sync)."""
        data = self._request_sync(
            "PUT",
            f"/api/test-cases/{test_case_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return TestCase(**data)

    async def delete(self, test_case_id: str) -> None:
        """Delete a test case."""
        await self._request_async("DELETE", f"/api/test-cases/{test_case_id}")

    def delete_sync(self, test_case_id: str) -> None:
        """Delete a test case (sync)."""
        self._request_sync("DELETE", f"/api/test-cases/{test_case_id}")

    async def delete_bulk(self, ids: List[str]) -> None:
        """Delete multiple test cases."""
        await self._request_async("DELETE", "/api/test-cases/bulk", json={"ids": ids})

    async def list_by_prompt(
        self, prompt_id: str, options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """List test cases by prompt."""
        return await self.list(options=options, prompt_id=prompt_id)

    async def list_by_tags(
        self, tags: List[str], options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """List test cases by tags."""
        return await self.list(options=options, tags=tags)
