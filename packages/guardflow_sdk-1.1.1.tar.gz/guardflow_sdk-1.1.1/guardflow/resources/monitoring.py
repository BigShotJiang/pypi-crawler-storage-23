"""GuardFlow Monitoring Resource - Access stats, logs, and cost data."""

from typing import Any, Callable, Coroutine, Dict, List, Optional

from ..types import (
    MonitoringStats,
    RequestLog,
    ViolationLog,
    CostOverview,
    CostTrendPoint,
    ListOptions,
    PaginatedResponse,
)


class MonitoringResource:
    """Monitoring resource for stats, logs, and cost tracking."""

    def __init__(
        self,
        request_async: Callable[..., Coroutine[Any, Any, Dict[str, Any]]],
        request_sync: Callable[..., Dict[str, Any]],
    ):
        self._request_async = request_async
        self._request_sync = request_sync

    async def stats(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        prompt_id: Optional[str] = None,
    ) -> MonitoringStats:
        """Get overall monitoring stats."""
        params = {}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        if prompt_id:
            params["promptId"] = prompt_id

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/stats?{query}" if query else "/api/monitoring/stats"
        data = await self._request_async("GET", path)
        return MonitoringStats(**data)

    def stats_sync(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        prompt_id: Optional[str] = None,
    ) -> MonitoringStats:
        """Get overall monitoring stats (sync)."""
        params = {}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        if prompt_id:
            params["promptId"] = prompt_id

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/stats?{query}" if query else "/api/monitoring/stats"
        data = self._request_sync("GET", path)
        return MonitoringStats(**data)

    async def logs(
        self,
        options: Optional[ListOptions] = None,
        status: Optional[str] = None,
        prompt_name: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> PaginatedResponse:
        """Get request logs."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
        if status:
            params["status"] = status
        if prompt_name:
            params["promptName"] = prompt_name
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/logs?{query}" if query else "/api/monitoring/logs"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def logs_sync(
        self,
        options: Optional[ListOptions] = None,
        status: Optional[str] = None,
        prompt_name: Optional[str] = None,
    ) -> PaginatedResponse:
        """Get request logs (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
        if status:
            params["status"] = status
        if prompt_name:
            params["promptName"] = prompt_name

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/logs?{query}" if query else "/api/monitoring/logs"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    async def violations(
        self, options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """Get violation events."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/violations?{query}" if query else "/api/monitoring/violations"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    async def activity(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """Get recent activity."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/activity?{query}" if query else "/api/monitoring/activity"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    async def summary(self) -> MonitoringStats:
        """Get dashboard summary."""
        data = await self._request_async("GET", "/api/monitoring/summary")
        return MonitoringStats(**data)

    async def costs(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> CostOverview:
        """Get cost overview."""
        params = {}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/costs?{query}" if query else "/api/monitoring/costs"
        data = await self._request_async("GET", path)
        return CostOverview(**data)

    def costs_sync(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> CostOverview:
        """Get cost overview (sync)."""
        params = {}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/costs?{query}" if query else "/api/monitoring/costs"
        data = self._request_sync("GET", path)
        return CostOverview(**data)

    async def cost_trend(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> List[CostTrendPoint]:
        """Get cost trend over time."""
        params = {}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/cost-trend?{query}" if query else "/api/monitoring/cost-trend"
        data = await self._request_async("GET", path)
        return [CostTrendPoint(**point) for point in data]

    async def counts(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> Dict[str, int]:
        """Get request counts."""
        params = {}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/monitoring/counts?{query}" if query else "/api/monitoring/counts"
        return await self._request_async("GET", path)
