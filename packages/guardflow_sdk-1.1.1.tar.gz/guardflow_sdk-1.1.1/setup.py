"""GuardFlow Python SDK setup."""

from setuptools import setup, find_packages
import os

# Read README for long description
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as fh:
        long_description = fh.read()
else:
    long_description = "Official Python SDK for GuardFlow - AI Prompt Security & Management"

setup(
    name="guardflow-sdk",
    version="1.1.1",
    author="GuardFlow",
    author_email="support@guardflow.io",
    description="Official Python SDK for GuardFlow - AI Prompt Security & Management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/guardflow/guardflow-sdk",
    project_urls={
        "Bug Tracker": "https://github.com/guardflow/guardflow-sdk/issues",
        "Documentation": "https://docs.guardflow.io",
        "Homepage": "https://guardflow.io",
        "Source": "https://github.com/guardflow/guardflow-sdk/tree/main/python-sdk",
    },
    packages=find_packages(exclude=["tests", "tests.*"]),
    package_data={
        "guardflow": ["py.typed"],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Typing :: Typed",
        "Framework :: AsyncIO",
    ],
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.26.0",
        "pydantic>=2.0.0",
        "tenacity>=8.0.0",
    ],
    extras_require={
        "fastapi": ["fastapi>=0.100.0", "starlette>=0.27.0"],
        "flask": ["flask>=2.0.0"],
        "django": ["django>=4.0.0"],
        "all": [
            "fastapi>=0.100.0",
            "starlette>=0.27.0",
            "flask>=2.0.0",
            "django>=4.0.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
            "ruff>=0.1.0",
            "respx>=0.20.0",
        ],
    },
    keywords=[
        "guardflow",
        "ai",
        "llm",
        "prompt",
        "security",
        "guardrails",
        "openai",
        "anthropic",
        "gpt",
        "claude",
        "sdk",
        "pii",
        "toxicity",
        "moderation",
    ],
)
