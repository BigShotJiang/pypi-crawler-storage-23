"""
GuardFlow SDK Client Tests
"""

import pytest
import respx
from httpx import Response

from guardflow import (
    GuardFlow,
    BlockedError,
    EscalatedError,
    RateLimitError,
    AuthError,
    ValidationError,
    GuardFlowAPIError,
)
from guardflow.types import RunResult


@pytest.fixture
def gf():
    """Create GuardFlow client for testing."""
    return GuardFlow(
        api_key="gf_test_xxx",
        base_url="https://api.guardflow.io",
        cache_enabled=False,
    )


class TestGuardFlowInit:
    """Test GuardFlow initialization."""

    def test_creates_with_valid_config(self):
        """Should create instance with valid config."""
        gf = GuardFlow(api_key="gf_test_xxx")
        assert gf is not None

    def test_raises_on_missing_api_key(self):
        """Should raise ValidationError when API key is missing."""
        with pytest.raises(ValidationError):
            GuardFlow(api_key="")

    def test_raises_on_invalid_api_key_format(self):
        """Should raise ValidationError when API key has wrong format."""
        with pytest.raises(ValidationError):
            GuardFlow(api_key="invalid_key")


class TestRun:
    """Test run method."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_run_result_on_success(self, gf):
        """Should return RunResult on successful run."""
        mock_response = {
            "success": True,
            "data": {
                "output": "Hello! How can I help you?",
                "allowed": True,
                "blocked": False,
                "escalated": False,
                "violations": [],
                "tokensUsed": 50,
                "tokensIn": 20,
                "tokensOut": 30,
                "latencyMs": 150,
                "costUsd": 0.001,
                "promptVersion": 1,
                "model": "gpt-4",
                "provider": "openai",
            },
            "requestId": "gf_123_abc",
        }

        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(200, json=mock_response)
        )

        result = await gf.run("test-prompt", input="Hello")

        assert result.output == "Hello! How can I help you?"
        assert result.allowed is True
        assert result.blocked is False
        assert result.tokens_used == 50

    @respx.mock
    @pytest.mark.asyncio
    async def test_raises_blocked_error_when_blocked(self, gf):
        """Should raise BlockedError when response is blocked."""
        mock_response = {
            "success": False,
            "error": {
                "code": "BLOCKED",
                "message": "Response blocked by guardrail",
                "violations": [
                    {
                        "policyId": "policy_123",
                        "policyName": "PII Detection",
                        "type": "PII_DETECTION",
                        "severity": "HIGH",
                        "action": "BLOCK",
                        "detail": "Email address detected",
                    }
                ],
            },
            "requestId": "gf_123_abc",
        }

        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(200, json=mock_response)
        )

        with pytest.raises(BlockedError) as exc_info:
            await gf.run("test-prompt", input="My email is test@example.com")

        assert len(exc_info.value.violations) == 1
        assert exc_info.value.code == "BLOCKED"

    @respx.mock
    @pytest.mark.asyncio
    async def test_raises_escalated_error_when_escalated(self, gf):
        """Should raise EscalatedError when response is escalated."""
        mock_response = {
            "success": False,
            "error": {
                "code": "ESCALATED",
                "message": "Request requires human review",
            },
            "requestId": "gf_123_abc",
        }

        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(200, json=mock_response)
        )

        with pytest.raises(EscalatedError):
            await gf.run("test-prompt", input="Complex request")

    @pytest.mark.asyncio
    async def test_raises_validation_error_on_empty_input(self, gf):
        """Should raise ValidationError when input is empty."""
        with pytest.raises(ValidationError):
            await gf.run("test-prompt", input="")


class TestRunSync:
    """Test run_sync method."""

    @respx.mock
    def test_returns_run_result_on_success(self, gf):
        """Should return RunResult on successful run."""
        mock_response = {
            "success": True,
            "data": {
                "output": "Success!",
                "allowed": True,
                "blocked": False,
                "escalated": False,
                "violations": [],
                "tokensUsed": 20,
                "tokensIn": 10,
                "tokensOut": 10,
                "latencyMs": 100,
                "costUsd": 0.0005,
                "promptVersion": 1,
                "model": "gpt-4",
                "provider": "openai",
            },
            "requestId": "gf_123",
        }

        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(200, json=mock_response)
        )

        result = gf.run_sync("test-prompt", input="Hello")

        assert result.output == "Success!"
        assert result.allowed is True


class TestRunBatch:
    """Test batch run methods."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_batch_result_with_summary(self, gf):
        """Should return BatchRunResult with correct summary."""
        mock_response = {
            "success": True,
            "data": {
                "output": "Translated",
                "allowed": True,
                "blocked": False,
                "escalated": False,
                "violations": [],
                "tokensUsed": 30,
                "tokensIn": 15,
                "tokensOut": 15,
                "latencyMs": 100,
                "costUsd": 0.001,
                "promptVersion": 1,
                "model": "gpt-4",
                "provider": "openai",
            },
            "requestId": "gf_123",
        }

        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(200, json=mock_response)
        )

        result = await gf.run_batch([
            {"prompt": "translator", "options": {"input": "Hello"}},
            {"prompt": "translator", "options": {"input": "World"}},
        ])

        assert len(result.results) == 2
        assert result.summary.total == 2
        assert result.summary.allowed == 2
        assert result.summary.blocked == 0


class TestErrorHandling:
    """Test error handling."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_handles_401_auth_errors(self, gf):
        """Should handle 401 authentication errors."""
        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(401, json={
                "error": "Invalid API key",
                "code": "AUTH_ERROR",
            })
        )

        with pytest.raises(AuthError):
            await gf.run("test-prompt", input="Hello")

    @respx.mock
    @pytest.mark.asyncio
    async def test_handles_429_rate_limit(self, gf):
        """Should handle 429 rate limit errors."""
        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(429, json={
                "error": "Rate limit exceeded",
                "code": "RATE_LIMIT",
                "retryAfter": 60,
            })
        )

        with pytest.raises(RateLimitError) as exc_info:
            await gf.run("test-prompt", input="Hello")

        assert exc_info.value.retry_after_seconds == 60


class TestEventCallbacks:
    """Test event callbacks."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_calls_blocked_callback(self, gf):
        """Should call blocked callback when blocked."""
        mock_response = {
            "success": False,
            "error": {
                "code": "BLOCKED",
                "message": "Blocked",
                "violations": [
                    {
                        "policyId": "p1",
                        "policyName": "Test",
                        "type": "TOXICITY_CHECK",
                        "severity": "HIGH",
                        "action": "BLOCK",
                        "detail": "Toxic",
                    }
                ],
            },
            "requestId": "gf_123",
        }

        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(200, json=mock_response)
        )

        blocked_called = []

        def on_blocked(prompt_name, violations, request_id):
            blocked_called.append((prompt_name, violations, request_id))

        gf.on_blocked(on_blocked)

        with pytest.raises(BlockedError):
            await gf.run("test-prompt", input="Bad content")

        assert len(blocked_called) == 1
        assert blocked_called[0][0] == "test-prompt"

    @respx.mock
    @pytest.mark.asyncio
    async def test_calls_complete_callback(self, gf):
        """Should call complete callback on success."""
        mock_response = {
            "success": True,
            "data": {
                "output": "OK",
                "allowed": True,
                "blocked": False,
                "escalated": False,
                "violations": [],
                "tokensUsed": 10,
                "tokensIn": 5,
                "tokensOut": 5,
                "latencyMs": 50,
                "costUsd": 0.0005,
                "promptVersion": 1,
                "model": "gpt-4",
                "provider": "openai",
            },
            "requestId": "gf_123",
        }

        respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(200, json=mock_response)
        )

        complete_called = []

        def on_complete(prompt_name, result):
            complete_called.append((prompt_name, result))

        gf.on_complete(on_complete)

        await gf.run("test-prompt", input="Hello")

        assert len(complete_called) == 1
        assert complete_called[0][0] == "test-prompt"


class TestCache:
    """Test caching behavior."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_caches_results(self):
        """Should cache results and serve from cache."""
        gf = GuardFlow(
            api_key="gf_test_xxx",
            base_url="https://api.guardflow.io",
            cache_enabled=True,
            cache_ttl_seconds=60,
        )

        mock_response = {
            "success": True,
            "data": {
                "output": "Cached response",
                "allowed": True,
                "blocked": False,
                "escalated": False,
                "violations": [],
                "tokensUsed": 10,
                "tokensIn": 5,
                "tokensOut": 5,
                "latencyMs": 50,
                "costUsd": 0.0005,
                "promptVersion": 1,
                "model": "gpt-4",
                "provider": "openai",
            },
            "requestId": "gf_123",
        }

        route = respx.post("https://api.guardflow.io/v1/run").mock(
            return_value=Response(200, json=mock_response)
        )

        # First call
        result1 = await gf.run("test-prompt", input="Hello")
        assert result1.cached is False

        # Second call should be from cache
        result2 = await gf.run("test-prompt", input="Hello")
        assert result2.cached is True

        # Should only have made one API call
        assert route.call_count == 1

    def test_invalidate_cache(self, gf):
        """Should invalidate cache without error."""
        gf.invalidate_cache("test-prompt")
        gf.invalidate_cache()  # Clear all


class TestHealth:
    """Test health check."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_health_status(self, gf):
        """Should return health status."""
        respx.get("https://api.guardflow.io/v1/health").mock(
            return_value=Response(200, json={
                "status": "ok",
                "service": "guardflow",
                "timestamp": "2024-01-01T00:00:00Z",
            })
        )

        health = await gf.health()

        assert health["status"] == "ok"
        assert health["service"] == "guardflow"


class TestContextManager:
    """Test context manager behavior."""

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """Should work as async context manager."""
        async with GuardFlow(api_key="gf_test_xxx") as gf:
            assert gf is not None

    def test_sync_context_manager(self):
        """Should work as sync context manager."""
        with GuardFlow(api_key="gf_test_xxx") as gf:
            assert gf is not None
