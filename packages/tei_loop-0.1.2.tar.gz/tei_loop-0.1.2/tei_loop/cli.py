"""
TEI CLI.

Commands:
    tei evaluate <agent_file> --query "..."    Run evaluation only (baseline)
    tei improve  <agent_file> --query "..."    Run full TEI loop
    tei compare  <agent_file> --query "..."    Run before/after comparison
    tei init                                    Generate .tei.yaml config
    tei report   <results.json>                 Pretty-print results
"""

from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import os
import sys
from pathlib import Path
from typing import Any, Callable


GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"


def _load_agent(agent_file: str) -> Callable:
    """Load agent function from a Python file. Looks for `agent`, `run`, or `main`."""
    path = Path(agent_file).resolve()
    if not path.exists():
        print(f"{RED}Error: File not found: {agent_file}{RESET}")
        sys.exit(1)

    spec = importlib.util.spec_from_file_location("agent_module", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    for name in ["agent", "run", "main", "invoke", "execute"]:
        fn = getattr(module, name, None)
        if callable(fn):
            return fn

    print(f"{RED}Error: No callable found in {agent_file}. "
          f"Define a function named 'agent', 'run', or 'main'.{RESET}")
    sys.exit(1)


def _print_result(result: Any) -> None:
    """Pretty-print a TEI result with colors."""
    print(f"\n{BOLD}{CYAN}{'=' * 60}{RESET}")
    print(f"{BOLD}TEI Loop Result{RESET}")
    print(f"{CYAN}{'=' * 60}{RESET}")

    print(f"  Mode:       {result.mode.value}")
    print(f"  Iterations: {result.total_iterations}")

    baseline_color = GREEN if result.baseline_score >= 0.7 else YELLOW if result.baseline_score >= 0.5 else RED
    final_color = GREEN if result.final_score >= 0.7 else YELLOW if result.final_score >= 0.5 else RED

    print(f"  Baseline:   {baseline_color}{result.baseline_score:.2f}{RESET}")
    print(f"  Final:      {final_color}{result.final_score:.2f}{RESET}")

    delta = result.improvement_delta
    delta_color = GREEN if delta > 0 else RED if delta < 0 else YELLOW
    print(f"  Delta:      {delta_color}{delta:+.2f}{RESET}")
    print(f"  Converged:  {result.converged}")
    print(f"  Duration:   {result.total_duration_ms:.0f}ms")
    print(f"  Cost:       ${result.total_cost_usd:.4f}")

    print(f"\n  {BOLD}Per-dimension scores:{RESET}")
    for dim_name, before in result.before_scores.items():
        after = result.after_scores.get(dim_name, before)
        delta_d = after - before
        dim_color = GREEN if after >= 0.7 else YELLOW if after >= 0.5 else RED
        print(f"    {dim_name}: {before:.2f} -> {dim_color}{after:.2f}{RESET} ({delta_d:+.2f})")

    if result.iterations and result.iterations[-1].failures:
        print(f"\n  {BOLD}{RED}Remaining failures:{RESET}")
        for f in result.iterations[-1].failures:
            print(f"    [{f.severity.value}] {f.dimension.value}: {f.description[:80]}")

    print(f"{CYAN}{'=' * 60}{RESET}\n")


def cmd_evaluate(args: argparse.Namespace) -> None:
    from .loop import TEILoop
    agent = _load_agent(args.agent_file)
    loop = TEILoop(agent=agent, verbose=args.verbose)
    result = asyncio.run(loop.evaluate_only(args.query))
    _print_result(result)
    if args.output:
        Path(args.output).write_text(result.model_dump_json(indent=2))


def cmd_improve(args: argparse.Namespace) -> None:
    from .loop import TEILoop
    agent = _load_agent(args.agent_file)
    loop = TEILoop(
        agent=agent,
        max_retries=args.max_retries,
        verbose=args.verbose,
    )
    result = asyncio.run(loop.run(args.query))
    _print_result(result)
    if args.output:
        Path(args.output).write_text(result.model_dump_json(indent=2))


def cmd_compare(args: argparse.Namespace) -> None:
    from .loop import TEILoop
    agent = _load_agent(args.agent_file)
    loop = TEILoop(agent=agent, verbose=args.verbose)
    results = asyncio.run(loop.compare(args.query))

    print(f"\n{BOLD}{CYAN}{'=' * 60}{RESET}")
    print(f"{BOLD}BASELINE (no improvement):{RESET}")
    _print_result(results["baseline"])

    print(f"{BOLD}WITH TEI (improved):{RESET}")
    _print_result(results["improved"])


def cmd_init(args: argparse.Namespace) -> None:
    config_content = """# TEI Loop Configuration
# See: https://github.com/ojavadli/tei-loop

mode: runtime          # runtime | development
max_retries: 3         # max improvement cycles per query (runtime mode)
max_dev_iterations: 50 # max iterations (development mode)
convergence_threshold: 0.02
parallel_eval: true

llm:
  provider: auto       # auto | openai | anthropic | google
  eval_model: auto     # smartest available (auto-detected)
  improve_model: auto  # cost-effective (auto-detected)
  temperature: 0.1

dimensions:
  target_alignment:
    enabled: true
    threshold: 0.7
    weight: 1.0
  reasoning_soundness:
    enabled: true
    threshold: 0.65
    weight: 1.0
  execution_accuracy:
    enabled: true
    threshold: 0.7
    weight: 1.0
  output_integrity:
    enabled: true
    threshold: 0.7
    weight: 1.0
"""
    path = Path(".tei.yaml")
    if path.exists() and not args.force:
        print(f"{YELLOW}.tei.yaml already exists. Use --force to overwrite.{RESET}")
        return
    path.write_text(config_content)
    print(f"{GREEN}Created .tei.yaml{RESET}")


def cmd_report(args: argparse.Namespace) -> None:
    from .models import TEIResult
    data = json.loads(Path(args.results_file).read_text())
    result = TEIResult(**data)
    _print_result(result)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tei",
        description="TEI Loop: Target -> Evaluate -> Improve",
    )
    sub = parser.add_subparsers(dest="command")

    p_eval = sub.add_parser("evaluate", help="Run evaluation only (baseline)")
    p_eval.add_argument("agent_file", help="Path to agent Python file")
    p_eval.add_argument("--query", "-q", required=True, help="Query to send to agent")
    p_eval.add_argument("--output", "-o", help="Save results to JSON file")
    p_eval.add_argument("--verbose", "-v", action="store_true")

    p_improve = sub.add_parser("improve", help="Run full TEI improvement loop")
    p_improve.add_argument("agent_file", help="Path to agent Python file")
    p_improve.add_argument("--query", "-q", required=True, help="Query to send to agent")
    p_improve.add_argument("--max-retries", type=int, default=3)
    p_improve.add_argument("--output", "-o", help="Save results to JSON file")
    p_improve.add_argument("--verbose", "-v", action="store_true")

    p_compare = sub.add_parser("compare", help="Run before/after comparison")
    p_compare.add_argument("agent_file", help="Path to agent Python file")
    p_compare.add_argument("--query", "-q", required=True, help="Query to send to agent")
    p_compare.add_argument("--verbose", "-v", action="store_true")

    p_init = sub.add_parser("init", help="Generate .tei.yaml config")
    p_init.add_argument("--force", action="store_true")

    p_report = sub.add_parser("report", help="Pretty-print saved results")
    p_report.add_argument("results_file", help="Path to JSON results file")

    args = parser.parse_args()

    commands = {
        "evaluate": cmd_evaluate,
        "improve": cmd_improve,
        "compare": cmd_compare,
        "init": cmd_init,
        "report": cmd_report,
    }

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
