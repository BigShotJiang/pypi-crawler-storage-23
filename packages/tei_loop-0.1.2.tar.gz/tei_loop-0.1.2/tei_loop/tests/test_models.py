"""Tests for TEI data models."""

import pytest
from tei_loop.models import (
    Assertion,
    AssertionVerdict,
    Dimension,
    DimensionScore,
    EvalResult,
    Failure,
    Fix,
    FixStrategyType,
    IterationResult,
    RunMode,
    Severity,
    TEIConfig,
    TEIResult,
    Trace,
    TraceStep,
)


def test_dimension_enum():
    assert len(Dimension) == 4
    assert Dimension.TARGET_ALIGNMENT.value == "target_alignment"
    assert Dimension.REASONING_SOUNDNESS.value == "reasoning_soundness"
    assert Dimension.EXECUTION_ACCURACY.value == "execution_accuracy"
    assert Dimension.OUTPUT_INTEGRITY.value == "output_integrity"


def test_trace_step_defaults():
    step = TraceStep(name="test")
    assert step.step_type == "generic"
    assert step.step_id
    assert step.timestamp > 0


def test_trace_creation():
    trace = Trace(
        agent_input="What is 2+2?",
        agent_output="4",
        steps=[TraceStep(name="compute")],
    )
    assert trace.trace_id
    assert trace.agent_input == "What is 2+2?"
    assert len(trace.steps) == 1


def test_dimension_score_never_100():
    ds = DimensionScore(dimension=Dimension.TARGET_ALIGNMENT, score=0.97)
    assert ds.score <= 0.97


def test_eval_result_summary():
    er = EvalResult(
        dimension_scores={
            Dimension.TARGET_ALIGNMENT: DimensionScore(
                dimension=Dimension.TARGET_ALIGNMENT, score=0.85, passed=True, threshold=0.7
            ),
            Dimension.OUTPUT_INTEGRITY: DimensionScore(
                dimension=Dimension.OUTPUT_INTEGRITY, score=0.55, passed=False, threshold=0.7
            ),
        },
        aggregate_score=0.70,
        all_passed=False,
    )
    assert not er.all_passed
    failures = er.get_failures()
    assert len(failures) == 1
    assert failures[0].dimension == Dimension.OUTPUT_INTEGRITY


def test_failure_creation():
    f = Failure(
        dimension=Dimension.REASONING_SOUNDNESS,
        severity=Severity.MAJOR,
        description="Contradictory reasoning about protein content",
        suggested_strategy=FixStrategyType.REASONING_REGENERATE,
    )
    assert f.failure_id
    assert f.severity == Severity.MAJOR


def test_fix_creation():
    fix = Fix(
        strategy=FixStrategyType.TARGET_REANCHOR,
        replacement_content="Focus on the original question about dessert preferences",
        rationale="Agent drifted to discussing general nutrition",
    )
    assert fix.fix_id
    assert not fix.applied


def test_tei_result_before_after():
    r = TEIResult(
        iterations=[
            IterationResult(
                iteration=0,
                eval_result=EvalResult(
                    dimension_scores={
                        Dimension.TARGET_ALIGNMENT: DimensionScore(
                            dimension=Dimension.TARGET_ALIGNMENT, score=0.55, threshold=0.7
                        ),
                    },
                    aggregate_score=0.55,
                ),
            ),
            IterationResult(
                iteration=1,
                eval_result=EvalResult(
                    dimension_scores={
                        Dimension.TARGET_ALIGNMENT: DimensionScore(
                            dimension=Dimension.TARGET_ALIGNMENT, score=0.82, threshold=0.7
                        ),
                    },
                    aggregate_score=0.82,
                ),
            ),
        ],
        baseline_score=0.55,
        final_score=0.82,
        improvement_delta=0.27,
    )
    assert r.before_scores["target_alignment"] == 0.55
    assert r.after_scores["target_alignment"] == 0.82
    assert "0.55" in r.summary()


def test_config_defaults():
    config = TEIConfig()
    assert config.mode == RunMode.RUNTIME
    assert config.max_retries == 3
    assert config.parallel_eval is True
    assert len(config.dimensions) == 4
    assert config.dimensions[Dimension.TARGET_ALIGNMENT].threshold == 0.7
