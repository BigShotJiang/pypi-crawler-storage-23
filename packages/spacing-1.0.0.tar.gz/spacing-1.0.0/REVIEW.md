# Code Review: Spacing Project

## Executive Summary

The spacing project is a well-architected Python blank line formatter with comprehensive test coverage (219 tests) and solid engineering fundamentals. The code demonstrates strong separation of concerns with a clean three-pass architecture (analyze → apply rules → reconstruct). Major strengths include thorough input validation, atomic file operations, and detailed error handling. However, there are **critical complexity issues** with deeply nested control flow (up to 7 levels) in several core functions, and the 692-line `rules.py` violates maintainability best practices. Code quality is generally high with no bare `except` clauses and proper use of specific exceptions.

**Major Themes:**
1. **Complexity**: Several functions have excessive nesting (6-7 levels) and high cyclomatic complexity
2. **Maintainability**: The `rules.py` module is very long (692 lines) and contains complex logic that could benefit from decomposition
3. **Architecture**: Well-designed separation of concerns with clean module boundaries
4. **Testing**: Comprehensive test suite with good coverage of edge cases

## Statistics

- **Files reviewed**: 12 source files + 18 test files
- **Lines of code**: ~3,000 source lines, ~4,700 test lines
- **Issues found**:
  - Critical: 2
  - Major: 4
  - Minor: 3
  - Enhancements: 2

---

## Critical Issues

### CRITICAL-001: Excessive Nesting in CLI Functions

**File**: `/Users/smethelg/src/spacing/src/spacing/cli.py:98-264`

**Current Code** (main function and _processFile):
```python
def _processFile(filepath, args):
  checkOnly = args.check or args.dry_run
  changeDetails = FileProcessor.processFile(...)
  changed = changeDetails if isinstance(changeDetails, bool) else changeDetails[0]

  if changed:
    if args.check or args.dry_run:
      if not args.quiet:
        print(...)
        if args.verbose and not isinstance(changeDetails, bool):
          _, details = changeDetails
          if details:
            if isinstance(details, tuple):  # 6+ levels deep
              summary, diff = details
```

**Problem**: The `_processFile` function has nesting depth of 7 levels, making it extremely difficult to follow control flow. The `main` function also has 7-level nesting with nested try-except blocks within loops within conditionals. This violates the flat control flow principle from CLAUDE.md.

**Impact**:
- Very difficult to understand and debug the processing logic
- High probability of introducing bugs during maintenance
- Makes adding new features error-prone
- Violates project's own coding standards (CLAUDE.md: "Flat control flow without deep nesting")

**Considerations for Fix**:
- Extract nested logic into dedicated helper functions (e.g., `_formatVerboseOutput`, `_handleFileProcessingError`)
- Use early returns/guard clauses to reduce nesting (e.g., `if not changed: return (False, 0)`)
- Consider using a Result/Either pattern for return values instead of tuple unpacking
- Break `main` into smaller functions: `_processExplicitPaths`, `_discoverAndProcessFiles`

---

### CRITICAL-002: Complex Logic in rules.py Functions

**File**: `/Users/smethelg/src/spacing/src/spacing/rules.py:320-410` and lines `412-537`

**Current Code** (_determineBlankLineForStatement):
```python
def _determineBlankLineForStatement(
    self, statements, currentIdx, stmt, startsNewScope,
    completedDefinitionBlock, completedControlBlock,
    returningFromNestedLevel, prevBlockType, prevStmtIdx, targetIndent,
):
  if startsNewScope:
    return False
  if completedDefinitionBlock:
    return self._needsBlankLineBetween(...) > 0
  if prevBlockType is not None:
    if prevBlockType != BlockType.COMMENT:
      # ... more nested logic
      return self._needsBlankLineBetween(...) > 0
    else:
      if stmt.indentLevel == 0 and stmt.blockType == BlockType.DEFINITION:
        hasBlankAfterComment = False
        for j in range(currentIdx - 1, -1, -1):  # Nested loop
          if statements[j].isBlank:
            hasBlankAfterComment = True
            break
          elif statements[j].isComment:
            break
        if hasBlankAfterComment:  # 6+ levels deep
          return self._needsBlankLineBetween(...) > 0
```

**Problem**:
- Function has 10 parameters (excessive cognitive load)
- Nesting depth of 6 levels
- Multiple responsibilities: checking scope, definition blocks, comments, and blank lines
- The `_applyRulesAtLevel` function has similar complexity (6 levels, 125 lines, many responsibilities)

**Impact**:
- Extremely difficult to reason about correctness
- High risk of introducing bugs (recent PEP 8 bug fix proves this)
- Nearly impossible to test all code paths
- Violates Single Responsibility Principle
- Makes future PEP compliance changes hazardous

**Considerations for Fix**:
- Split `_determineBlankLineForStatement` into smaller, focused functions:
  - `_determineBlankLineAfterComment` (handle comment-specific logic)
  - `_determineBlankLineAfterDocstring` (handle PEP 257)
  - `_determineBlankLineForDefinition` (handle PEP 8)
- Reduce parameter count using a context object or dataclass
- Extract the blank-line-after-comment detection logic (lines 374-397) into its own method
- Consider a strategy pattern for different blank line determination scenarios
- Break `_applyRulesAtLevel` into phases: setup, skip directive handling, comment handling, standard rule application

---

## Major Issues

### MAJOR-001: Large Module Violates Maintainability

**File**: `/Users/smethelg/src/spacing/src/spacing/rules.py:1-693`

**Current Code**: Single file with 692 lines containing:
- `BlankLineRuleEngine` class with 14 methods
- Complex interdependencies between methods
- Multiple concerns: skip directives, comment handling, scope detection, blank line calculation

**Problem**: The `rules.py` module exceeds reasonable file size limits and contains multiple responsibilities that could be separated. The class has too many private helper methods (11 private methods for a single public `applyRules` method).

**Impact**:
- Hard to navigate and understand the full rule engine
- Changes in one area risk breaking other areas
- Difficult for new contributors to understand
- Violates "Keep functions and methods short and focused" principle from CLAUDE.md

**Considerations for Fix**:
- Extract scope detection logic into `ScopeAnalyzer` class
- Extract comment handling into `CommentRuleHandler` class
- Extract definition/control block detection into separate helper class
- Keep `BlankLineRuleEngine` as coordinator that delegates to specialized handlers
- Consider separating PEP 8 vs PEP 257 rules into different strategies

---

### MAJOR-002: Missing Input Validation in Key Functions

**File**: `/Users/smethelg/src/spacing/src/spacing/rules.py:14-18`

**Current Code**:
```python
def applyRules(self, statements):
  """Return list indicating how many blank lines should exist before each statement"""
  if not statements:
    return []
  # ... proceeds without validating statements structure
```

**Problem**: The `applyRules` method does not validate that `statements` is actually a list of `Statement` objects. It silently assumes all elements have properties like `isBlank`, `indentLevel`, `blockType`, etc. Similar issues in `FileAnalyzer.analyzeFile` which doesn't validate that `lines` contains strings (though `MultilineParser.processLine` does have type checking).

**Impact**:
- Cryptic `AttributeError` instead of clear validation error if wrong type passed
- Difficult to debug issues when invalid data flows through the pipeline
- Violates defensive programming principles
- Makes the API less robust for future refactoring

**Considerations for Fix**:
- Add type validation at entry points: `if not isinstance(statements, list): raise TypeError(...)`
- Validate at least the first element: `if statements and not isinstance(statements[0], Statement):`
- Consider using `isinstance` checks or type guards
- Document preconditions in docstrings
- Balance between performance (no checking) and robustness (validate everything)

---

### MAJOR-003: Inconsistent Error Handling in File Operations

**File**: `/Users/smethelg/src/spacing/src/spacing/processor.py:85-121`

**Current Code**:
```python
try:
  with tempfile.NamedTemporaryFile(...) as f:
    tempFile = f.name
    f.writelines(newLines)
  os.replace(tempFile, filepath)
  # ... return success
except (OSError, IOError) as e:
  logger.error(f'Error writing {filepath}: {e}')
  # ... return False
finally:
  if tempFile:
    try:
      os.unlink(tempFile)  # Tries to delete after successful replace
    except FileNotFoundError:
      pass  # Expected when file was moved
```

**Problem**: The `finally` block attempts to delete `tempFile` even when `os.replace()` succeeds, which is unnecessary and logs spurious warnings. The `NamedTemporaryFile` with `delete=False` requires manual cleanup, but the cleanup logic expects `FileNotFoundError` as the success case (inverted logic).

**Impact**:
- Unnecessary system calls attempting to delete non-existent files
- Confusing code logic where exception handling indicates success
- Potential file descriptor leaks if cleanup fails silently
- Hard to understand the "happy path" vs error path

**Considerations for Fix**:
- Set `tempFile = None` after successful `os.replace()` to skip cleanup
- Use a flag like `replacedSuccessfully` to control cleanup logic
- Consider using `contextlib.ExitStack` for cleaner resource management
- Document why `delete=False` is needed (atomic rename across filesystems)
- Only attempt cleanup if the replace failed

---

### MAJOR-004: Potential Resource Leak in Recursive File Discovery

**File**: `/Users/smethelg/src/spacing/src/spacing/cli.py:231-242`

**Current Code**:
```python
elif path.is_dir():
  for pyFile in path.rglob('*.py'):
    try:
      resolvedFile = pyFile.resolve(strict=True)
      processed, changed, fileExitCode = processFileAndUpdateCounts(resolvedFile)
      # ... accumulate counts
    except (OSError, RuntimeError) as e:
      print(f'Warning: Skipping {pyFile}: {e}', file=sys.stderr)
      continue  # Continues processing other files
```

**Problem**: The `path.rglob('*.py')` returns a generator that may hold directory handles. If processing a deeply nested directory structure with many files, and `processFileAndUpdateCounts` raises an exception other than `OSError`/`RuntimeError`, the generator cleanup might not happen properly, potentially leaving file descriptors open.

**Impact**:
- Risk of "too many open files" errors on large codebases
- Unpredictable behavior when processing deep directory trees
- May exhaust file descriptors on some systems
- Error handling doesn't cover all exception types that might occur

**Considerations for Fix**:
- Materialize the generator into a list: `pyFiles = list(path.rglob('*.py'))`
- Use a broader exception handler or ensure generator cleanup: `try...finally` wrapper
- Consider limiting recursion depth for safety
- Add logging for how many files were discovered vs processed
- Handle keyboard interrupts gracefully to ensure cleanup

---

## Minor Issues

### MINOR-001: Inconsistent Naming Conventions

**Files**: Multiple files

**Issue**: The codebase uses `camelCase` for variables/functions (per standards), but some variables violate this:
- `src/spacing/rules.py:32`: `prev_non_blank_idx` (snake_case instead of camelCase)
- `src/spacing/rules.py:589`: `skipPrevIdx` vs `immediatePrevIdx` (inconsistent naming pattern)
- Variable `blankLineCounts` vs function parameter `blankLineCount` (singular/plural confusion)

**Impact**: Minor confusion when reading code, violates project's Python coding standards

---

### MINOR-002: Magic Numbers in Configuration

**File**: `/Users/smethelg/src/spacing/src/spacing/config.py:13-21`

**Current Code**:
```python
MAX_BLANK_LINES = 3
MIN_INDENT_WIDTH = 1
MAX_INDENT_WIDTH = 8
```

**Issue**: These magic numbers are defined but the rationale comments don't explain WHY these specific values were chosen (e.g., why exactly 8 for max indent width? What breaks above 8?).

**Impact**: Future maintainers might not understand constraints, potentially changing values unsafely

---

### MINOR-003: Incomplete Docstrings

**Files**: Multiple

**Examples**:
- `src/spacing/rules.py:78`: `_shouldNotAlterBlankLinesAfterComment` has no `:rtype:` annotation
- `src/spacing/rules.py:121`: `_findPreviousNonBlankAtLevel` missing param type annotations
- `src/spacing/analyzer.py:194`: `_processDirectives` has good docs but others don't

**Issue**: Inconsistent docstring quality across the codebase. Some functions have full reST documentation, others are missing return type annotations.

**Impact**: Harder for developers to understand function contracts, IDE autocomplete less helpful

---

## Enhancements

### ENHANCEMENT-001: Consider Adding Metrics/Telemetry

**Opportunity**: The tool processes files but doesn't collect metrics about what rules are most frequently applied, what types of files have the most violations, etc.

**Benefit**:
- Could help prioritize which rules to make configurable
- Identify which PEP violations are most common in user codebases
- Support data-driven development decisions

**Suggestions**:
- Add optional `--stats` flag to show rule application statistics
- Track which block type transitions are most common
- Log how many PEP 8 vs PEP 257 violations were fixed

---

### ENHANCEMENT-002: Performance Optimization Opportunity

**File**: `/Users/smethelg/src/spacing/src/spacing/rules.py:412-537`

**Opportunity**: The `_applyRulesAtLevel` function iterates through all statements multiple times:
1. Main loop (lines 426-525)
2. Recursive processing loop (lines 528-535)

Each iteration has multiple backward scans (e.g., `_hasCompletedDefinitionBlock` scans backward, `_isReturningFromNestedLevel` scans backward).

**Benefit**:
- Could precompute scope information in a single forward pass
- Cache results of backward scans to avoid repeated work
- Significant performance improvement on large files (1000+ lines)

**Suggestions**:
- Build a scope map in a preprocessing pass
- Cache "completed block" information per statement
- Consider memoization for frequently called helpers
- Profile on large files to identify actual bottlenecks first

---

## Positive Observations

The code demonstrates several excellent practices worth highlighting:

1. **Comprehensive Error Handling**: All file I/O operations have specific exception handlers with contextual error messages
2. **No Bare Except Clauses**: Every exception handler specifies exact exception types
3. **Atomic File Operations**: The tempfile + rename pattern prevents corruption
4. **Good Separation of Concerns**: Clear boundaries between parser, classifier, analyzer, rules, and processor
5. **Test Coverage**: 219 tests with good edge case coverage including PEP 8/257 compliance
6. **Configuration Validation**: Thorough validation of TOML config with helpful error messages
7. **Pre-compiled Regex Patterns**: Performance optimization applied correctly
8. **Input Validation**: `MultilineParser.processLine` validates string inputs
