"""Module entry point for ``python -m slop_guard``."""

from .server import main

if __name__ == "__main__":
    main()
