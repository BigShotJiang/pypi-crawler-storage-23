from .DRİVE import Control
from .DRİVE import give
from .DRİVE import info
from .DRİVE import delete
from .DRİVE import get
from .DoIP import IP
from .filesz import EasyDB
from .EasyWeb import Web, UI
from .adbfull import ADB
from .turkws import (
    baglan,
    gonder,
    baglantiyi_kes,
    odaya_katil,
    mesaj_geldiginde,
    baglaninca,
    kopunca,
    hata_olunca,
)