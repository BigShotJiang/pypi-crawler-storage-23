"""NHC MCP tool modules."""
