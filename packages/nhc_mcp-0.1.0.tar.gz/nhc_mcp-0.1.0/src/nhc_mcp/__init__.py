"""NHC MCP Server — National Hurricane Center Data for AI Assistants."""
