# Copyright 2026 Nova Code (https://www.novacode.nl)
# See LICENSE file for full licensing details.

import json
import unittest

from surveyjs import SurveyForm
from tests.utils import load_form, load_creator, readjson, readfile


class TestNestedQuestions(unittest.TestCase):

    def setUp(self):
        raise NotImplementedError("Nested question tests not implemented yet")

if __name__ == '__main__':
    unittest.main()
