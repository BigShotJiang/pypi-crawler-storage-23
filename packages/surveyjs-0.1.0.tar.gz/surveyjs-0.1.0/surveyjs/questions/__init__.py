# Copyright 2026 Nova Code (https://www.novacode.nl)
# See LICENSE file for full licensing details.
