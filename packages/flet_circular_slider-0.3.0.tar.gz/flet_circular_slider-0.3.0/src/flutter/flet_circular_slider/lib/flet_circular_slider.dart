library flet_circular_slider;

export "src/extension.dart" show Extension;
