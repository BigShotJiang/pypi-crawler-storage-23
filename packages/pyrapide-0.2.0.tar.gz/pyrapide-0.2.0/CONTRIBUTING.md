# Contributing to PyRapide

## Development Setup

```bash
git clone https://github.com/ShaneDolphin/pyrapide.git
cd PyRapide
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

Requires Python 3.11+.

## Test-First Workflow

PyRapide follows a strict test-first development process:

1. **Write tests first.** Create or update tests in `tests/` that describe the expected behavior.
2. **Confirm tests fail.** Run `pytest tests/ -v` and verify the new tests fail for the right reason.
3. **Implement.** Write the minimal code to make all tests pass.
4. **Confirm zero regressions.** Run the full suite — every existing test must still pass.
5. **Type check and lint.** Run `mypy pyrapide/ --ignore-missing-imports` and `ruff check pyrapide/`. Both must report zero errors.

## Running Tests

```bash
pytest tests/ -v
```

Tests use `pytest-asyncio` with `asyncio_mode = "auto"` — async test functions are detected and run automatically.

## Type Checking

```bash
mypy pyrapide/ --ignore-missing-imports
```

The project uses `strict = true` in mypy configuration. All new code must be fully typed.

## Linting

```bash
ruff check pyrapide/
```

To auto-fix simple issues:

```bash
ruff check pyrapide/ --fix
```

## Project Structure

- `pyrapide/` — Source code, organized into subpackages (core, types, patterns, architecture, constraints, executable, runtime, integrations, analysis, utils).
- `tests/` — Mirrors the source structure. Each subpackage has a corresponding test directory.
- `tests/scenarios/` — End-to-end integration tests that exercise multiple subsystems together.

## Docstring Conventions

Every public class and function must have a docstring with:

- A one-line summary.
- A description paragraph (when the summary alone is not sufficient).
- An `Example::` block with a usage snippet.

## Code Style

- Target Python 3.11+ features (type unions with `|`, `match` statements where appropriate).
- Use `from __future__ import annotations` for forward reference support.
- Prefer `frozenset` for immutable collections returned from query methods.
- Events are immutable Pydantic `frozen=True` models — never mutate them.
- Use `async def` for any function that might need to `await` in the future.
