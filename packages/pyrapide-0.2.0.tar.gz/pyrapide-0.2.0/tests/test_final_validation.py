"""Final comprehensive validation test suite for PyRapide.

Each test is self-contained and exercises multiple subsystems together.
"""

import asyncio
import time

import pytest

# ---------------------------------------------------------------------------
# Integration Tests
# ---------------------------------------------------------------------------


class TestIntegration:
    def test_full_import(self):
        """Import every public name from pyrapide. Assert none are None."""
        from pyrapide import __all__, __version__

        assert __version__ == "0.1.0"

        import pyrapide

        for name in __all__:
            obj = getattr(pyrapide, name, None)
            assert obj is not None, f"pyrapide.{name} is None"

    def test_event_lifecycle(self):
        """Create Event -> Poset -> Computation -> Serialize -> Deserialize -> Assert equality."""
        from pyrapide import Computation, Event, Poset

        e1 = Event(name="start", payload={"step": 1}, source="test")
        e2 = Event(name="middle", payload={"step": 2}, source="test")
        e3 = Event(name="end", payload={"step": 3}, source="test")

        # Poset
        poset = Poset()
        poset.add(e1)
        poset.add(e2, caused_by=[e1])
        poset.add(e3, caused_by=[e2])

        assert poset.is_ancestor(e1, e3)
        assert not poset.is_ancestor(e3, e1)

        # Computation
        comp = Computation(poset=poset)
        assert len(comp) == 3
        assert comp.root_events() == frozenset({e1})
        assert comp.leaf_events() == frozenset({e3})

        # Serialize roundtrip
        d = comp.to_dict()
        comp2 = Computation.from_dict(d)
        assert len(comp2) == 3

        # Event IDs preserved
        ids_original = {e.id for e in comp.events}
        ids_restored = {e.id for e in comp2.events}
        assert ids_original == ids_restored

    def test_interface_to_module_to_architecture(self):
        """Define interface -> module -> architecture -> instantiate -> assert."""
        from pyrapide import action, architecture, interface, module

        @interface
        class SvcInterface:
            @action
            async def create(self, data: dict) -> None: ...

            @action
            async def read(self, id: str) -> None: ...

            @action
            async def delete(self, id: str) -> None: ...

        assert "create" in SvcInterface._pyrapide_actions
        assert "read" in SvcInterface._pyrapide_actions
        assert "delete" in SvcInterface._pyrapide_actions

        @module(implements=SvcInterface)
        class SvcModule:
            pass

        assert SvcModule._pyrapide_is_module is True
        assert SvcModule._pyrapide_implements is SvcInterface

        @architecture
        class SvcArch:
            service: SvcInterface

        arch = SvcArch()
        assert hasattr(arch, "service")
        assert isinstance(arch.service, SvcInterface)
        assert "service" in arch.components
        info = SvcArch.get_architecture_info()
        assert "service" in info["components"]

    def test_pattern_matching_on_live_computation(self):
        """Build computation with 20 events, test 5 pattern types."""
        from pyrapide import Computation, Event, Pattern, Poset

        # Build a complex DAG:
        #   root -> a1 -> a2 -> a3 (chain A)
        #   root -> b1 -> b2 -> b3 (chain B)
        #   a2 -> merge <- b2       (diamond merge)
        #   independent: x1, x2, x3 (no causal links to above)
        #   root -> c1 -> c2 -> ... -> c10 (long chain)

        poset = Poset()
        root = Event(name="root", source="sys")
        poset.add(root)

        # Chain A
        a_events = []
        prev = root
        for i in range(1, 4):
            e = Event(name="chain_a", payload={"step": i}, source="A")
            poset.add(e, caused_by=[prev])
            a_events.append(e)
            prev = e

        # Chain B
        b_events = []
        prev = root
        for i in range(1, 4):
            e = Event(name="chain_b", payload={"step": i}, source="B")
            poset.add(e, caused_by=[prev])
            b_events.append(e)
            prev = e

        # Merge node
        merge = Event(name="merge", source="sys")
        poset.add(merge, caused_by=[a_events[1], b_events[1]])

        # Independent events
        indep = []
        for i in range(3):
            e = Event(name="independent", payload={"idx": i}, source="X")
            poset.add(e)
            indep.append(e)

        # Long chain C
        prev = root
        for i in range(10):
            e = Event(name="chain_c", payload={"step": i}, source="C")
            poset.add(e, caused_by=[prev])
            prev = e

        comp = Computation(poset=poset)
        # root(1) + chain_a(3) + chain_b(3) + merge(1) + indep(3) + chain_c(10) = 21
        assert len(comp) == 21

        # Pattern 1: Basic match
        p_root = Pattern.match("root")
        matches = p_root.match_in(poset)
        assert len(matches) == 1

        # Pattern 2: Sequence (root >> merge)
        p_seq = Pattern.match("root") >> Pattern.match("merge")
        matches = p_seq.match_in(poset)
        assert len(matches) >= 1

        # Pattern 3: Join (chain_a & chain_b share common ancestor root)
        p_join = Pattern.match("chain_a") & Pattern.match("chain_b")
        matches = p_join.match_in(poset)
        assert len(matches) >= 1

        # Pattern 4: Independence (independent events are causally unrelated to each other)
        p_idx0 = Pattern.match("independent", idx=0)
        p_idx1 = Pattern.match("independent", idx=1)
        p_ind = p_idx0 | p_idx1
        matches = p_ind.match_in(poset)
        assert len(matches) >= 1

        # Pattern 5: Guarded pattern (where predicate receives a PatternMatch)
        p_guarded = Pattern.match("chain_c").where(
            lambda m: any(e.payload.get("step", -1) > 5 for e in m.events)
        )
        matches = p_guarded.match_in(poset)
        assert len(matches) >= 4  # steps 6,7,8,9

    def test_constraint_enforcement_end_to_end(self):
        """must_match satisfied, never violated -> exactly one violation."""
        from pyrapide import (
            Computation,
            ConstraintMonitor,
            Event,
            Pattern,
            Poset,
            must_match,
            never,
        )

        poset = Poset()

        # Build: request -> response (satisfies must_match)
        #        also: forbidden_event (violates never)
        req = Event(name="request", source="client")
        resp = Event(name="response", source="server")
        forbidden = Event(name="forbidden", source="attacker")

        poset.add(req)
        poset.add(resp, caused_by=[req])
        poset.add(forbidden)

        comp = Computation(poset=poset)

        # must_match: request >> response should be satisfied
        c_must = must_match(
            Pattern.match("request") >> Pattern.match("response"),
            description="Every request must have a response",
        )

        # never: forbidden should be violated
        c_never = never(
            Pattern.match("forbidden"),
            description="No forbidden events allowed",
        )

        monitor = ConstraintMonitor()
        monitor.add_constraint(c_must)
        monitor.add_constraint(c_never)

        all_violations = []
        for event in comp.topological_order():
            violations = monitor.check(event)
            all_violations.extend(violations)

        # The never constraint should fire on the forbidden event
        assert len(all_violations) >= 1
        assert any("forbidden" in str(v).lower() or "forbidden" in v.description.lower()
                    for v in all_violations)

    async def test_engine_full_execution(self):
        """3-component architecture with connections and constraints via Engine."""
        from pyrapide import (
            Engine,
            Pattern,
            PatternMatch,
            action,
            architecture,
            connect,
            interface,
            module,
            when,
        )
        from pyrapide.executable import get_context

        @interface
        class Source:
            @action
            async def emit(self) -> None: ...

        @interface
        class Transform:
            @action
            async def process(self) -> None: ...

        @interface
        class Sink:
            @action
            async def store(self) -> None: ...

        @module(implements=Source)
        class SourceMod:
            async def start(self):
                ctx = get_context(self)
                for i in range(5):
                    ctx.generate_event("Source.emit", payload={"val": i})

        @module(implements=Transform)
        class TransformMod:
            @when(Pattern.match("Source.emit"))
            async def on_emit(self, match: PatternMatch):
                ctx = get_context(self)
                event = list(match.events)[0]
                val = event.payload.get("val", 0)
                ctx.generate_event(
                    "Transform.process",
                    payload={"val": val * 2},
                    caused_by=list(match.events),
                )

        @module(implements=Sink)
        class SinkMod:
            @when(Pattern.match("Transform.process"))
            async def on_process(self, match: PatternMatch):
                ctx = get_context(self)
                ctx.generate_event(
                    "Sink.store",
                    payload=list(match.events)[0].payload,
                    caused_by=list(match.events),
                )

        @architecture
        class Pipeline:
            source: Source
            transform: Transform
            sink: Sink

            def connections(self):
                return [
                    connect(Pattern.match("Source.emit"), "transform"),
                    connect(Pattern.match("Transform.process"), "sink"),
                ]

        arch = Pipeline()
        engine = Engine()
        engine.bind(arch, "source", SourceMod)
        engine.bind(arch, "transform", TransformMod)
        engine.bind(arch, "sink", SinkMod)

        comp = await engine.run(arch, timeout=5.0)

        # Should have source events + transform events + sink events
        assert len(comp) >= 10  # at least 5 source + 5 transform
        assert len(engine.violations) == 0

        # Verify causal links exist
        emit_events = [e for e in comp.events if e.name == "Source.emit"]
        process_events = [e for e in comp.events if e.name == "Transform.process"]
        store_events = [e for e in comp.events if e.name == "Sink.store"]

        assert len(emit_events) == 5
        assert len(process_events) >= 1
        assert len(store_events) >= 1

    async def test_streaming_processor_full(self):
        """3 sources, 50 events, pattern watches, constraints."""
        from pyrapide import (
            Event,
            InMemoryEventSource,
            Pattern,
            StreamProcessor,
            never,
        )

        src_a = InMemoryEventSource("alpha")
        src_b = InMemoryEventSource("beta")
        src_c = InMemoryEventSource("gamma")

        processor = StreamProcessor()
        processor.add_source("alpha", src_a)
        processor.add_source("beta", src_b)
        processor.add_source("gamma", src_c)

        # Pattern watch
        watch_hits = []
        processor.watch(
            Pattern.match("data"),
            lambda m: watch_hits.append(m),
        )

        # Constraint: no "bad" events
        processor.enforce(never(Pattern.match("bad"), description="No bad events"))

        violations = []
        processor.on_violation(lambda v: violations.append(v))

        # Feed 50 clean events
        async def feed():
            for i in range(20):
                await src_a.put(Event(name="data", payload={"i": i}, source="alpha"))
            for i in range(15):
                await src_b.put(Event(name="data", payload={"i": i}, source="beta"))
            for i in range(15):
                await src_c.put(Event(name="data", payload={"i": i}, source="gamma"))
            await src_a.close()
            await src_b.close()
            await src_c.close()

        await asyncio.gather(feed(), processor.run())

        assert processor.stats["event_count"] == 50
        assert len(watch_hits) == 50
        assert len(violations) == 0

    async def test_mcp_integration_full(self):
        """MCPEventAdapter -> StreamProcessor -> causal traceability."""
        from pyrapide import (
            MCPEventAdapter,
            MCPEventTypes,
            MCPPatterns,
            StreamProcessor,
        )
        from pyrapide.integrations.mcp import MockMCPClient

        client = MockMCPClient("test-server")
        adapter = MCPEventAdapter("test-server", client)

        processor = StreamProcessor()
        processor.add_source("test", adapter)

        match_count = []
        processor.watch(
            MCPPatterns.tool_call(),
            lambda m: match_count.append(m),
        )

        async def drive():
            await client.connect()
            await client.call_tool("search", {"q": "hello"})
            await client.call_tool("fetch", {"url": "http://example.com"})
            await client.read_resource("file:///data.txt")
            await client.disconnect()
            await client.close()

        await asyncio.gather(drive(), processor.run())

        assert processor.stats["event_count"] >= 6  # connect + 2*(call+result) + resource + disconnect
        assert len(match_count) == 2  # 2 tool calls

        # Verify we can find tool_call and tool_result events
        events = list(processor.computation.events)
        tool_calls = [e for e in events if e.name == MCPEventTypes.TOOL_CALL]
        tool_results = [e for e in events if e.name == MCPEventTypes.TOOL_RESULT]
        assert len(tool_calls) == 2
        assert len(tool_results) == 2

    def test_analysis_pipeline(self):
        """Build computation, run queries, generate visualizations."""
        from pyrapide import (
            Computation,
            Event,
            Poset,
            queries,
            visualization,
        )

        poset = Poset()

        # Build a diamond: root -> a, root -> b, a -> leaf, b -> leaf
        root = Event(name="root", source="sys")
        a = Event(name="branch_a", source="sys")
        b = Event(name="branch_b", source="sys")
        leaf = Event(name="leaf", source="sys")

        poset.add(root)
        poset.add(a, caused_by=[root])
        poset.add(b, caused_by=[root])
        poset.add(leaf, caused_by=[a, b])

        comp = Computation(poset=poset)

        # Queries
        cp = queries.critical_path(comp)
        assert len(cp) >= 2
        assert isinstance(cp, list)

        rc = queries.root_causes(comp, leaf)
        assert root in rc

        impact = queries.impact_set(comp, root)
        assert leaf in impact

        dist = queries.causal_distance(comp, root, leaf)
        assert dist is not None and dist >= 1

        ca = queries.common_ancestors(comp, a, b)
        assert root in ca

        bslice = queries.backward_slice(comp, leaf)
        assert len(bslice) >= 1

        fslice = queries.forward_slice(comp, root)
        assert len(fslice) >= 1

        par = queries.parallel_events(comp)
        assert any((a in pair and b in pair) for pair in par)

        bn = queries.bottleneck_events(comp)
        assert isinstance(bn, list)

        freq = queries.event_frequency(comp)
        assert isinstance(freq, dict)
        assert sum(freq.values()) == 4

        density = queries.causal_density(comp)
        assert isinstance(density, float)
        assert 0.0 <= density <= 1.0

        # Visualizations
        dot = visualization.to_dot(comp)
        assert "digraph" in dot

        mermaid = visualization.to_mermaid(comp)
        assert "graph TD" in mermaid

        json_out = visualization.to_json(comp)
        assert "events" in json_out
        assert "edges" in json_out
        assert json_out["metadata"]["event_count"] == 4

        ascii_out = visualization.to_ascii(comp)
        assert "root" in ascii_out

        summ = visualization.summary(comp)
        assert "4 events" in summ

    def test_prediction_pipeline(self):
        """Train CausalPredictor on 5 computations, predict from partial."""
        from pyrapide import CausalPredictor, Computation, Event, Poset

        # Build 5 similar computations: login -> browse -> purchase
        training = []
        for _ in range(5):
            p = Poset()
            login = Event(name="login", source="user")
            browse = Event(name="browse", source="user")
            purchase = Event(name="purchase", source="user")
            p.add(login)
            p.add(browse, caused_by=[login])
            p.add(purchase, caused_by=[browse])
            training.append(Computation(poset=p))

        predictor = CausalPredictor()
        for comp in training:
            predictor.learn(comp)

        # Predict from a partial computation (just login -> browse)
        partial = Poset()
        login = Event(name="login", source="user")
        browse = Event(name="browse", source="user")
        partial.add(login)
        partial.add(browse, caused_by=[login])
        partial_comp = Computation(poset=partial)

        predictions = predictor.predict(partial_comp)
        assert len(predictions) >= 1

        # Should predict purchase with high confidence
        purchase_preds = [p for p in predictions if p.event_name == "purchase"]
        assert len(purchase_preds) >= 1
        assert purchase_preds[0].confidence > 0.5

    def test_anomaly_pipeline(self):
        """Train AnomalyDetector on normal data, detect anomalies."""
        from pyrapide import AnomalyDetector, Computation, Event, Poset

        # Normal pattern: init -> process -> complete
        detector = AnomalyDetector()
        training_data = []
        for _ in range(10):
            p = Poset()
            init = Event(name="init", source="sys")
            process = Event(name="process", source="sys")
            complete = Event(name="complete", source="sys")
            p.add(init)
            p.add(process, caused_by=[init])
            p.add(complete, caused_by=[process])
            training_data.append(Computation(poset=p))
        detector.learn(training_data)

        # Anomalous: init -> unknown_event -> complete
        anom_p = Poset()
        init = Event(name="init", source="sys")
        unknown = Event(name="never_seen_before", source="sys")
        complete = Event(name="complete", source="sys")
        anom_p.add(init)
        anom_p.add(unknown, caused_by=[init])
        anom_p.add(complete, caused_by=[unknown])
        anom_comp = Computation(poset=anom_p)

        anomalies = detector.detect(anom_comp)
        assert len(anomalies) >= 1

        # Should flag the unseen event
        unseen = [a for a in anomalies if a.anomaly_type == "unseen_event"]
        assert len(unseen) >= 1
        assert unseen[0].severity >= 0.5

    def test_clock_integration(self):
        """RegularClock and SlavedClock with temporal/causal consistency."""
        from pyrapide import (
            ClockManager,
            Computation,
            Event,
            Poset,
            RegularClock,
            SlavedClock,
        )

        mgr = ClockManager()
        master = RegularClock("master", period=1.0)
        slave = SlavedClock("slave", parent=master, divisor=2)
        mgr.register(master)
        mgr.register(slave)

        poset = Poset()
        e1 = Event(name="first", source="sys")
        e2 = Event(name="second", source="sys")
        e3 = Event(name="third", source="sys")

        poset.add(e1)
        poset.add(e2, caused_by=[e1])
        poset.add(e3, caused_by=[e2])

        comp = Computation(poset=poset, clock_manager=mgr)

        # Stamp events with ticks between them for monotonic ordering
        mgr.stamp_event(e1, clock_name="master")
        master.auto_tick()
        mgr.stamp_event(e2, clock_name="master")
        master.auto_tick()
        mgr.stamp_event(e3, clock_name="master")

        # Master clock timestamps should be monotonically increasing
        t1 = master.start_time(e1)
        t2 = master.start_time(e2)
        t3 = master.start_time(e3)
        assert t1 is not None and t2 is not None and t3 is not None
        assert t1 < t2 < t3

        # Slave clock reads parent / divisor
        mgr.stamp_event(e1, clock_name="slave")
        mgr.stamp_event(e2, clock_name="slave")
        s1 = slave.start_time(e1)
        s2 = slave.start_time(e2)
        assert s1 is not None and s2 is not None
        # Slave reads are master_time / divisor, both stamped at same master time (2.0)
        # so s1 == s2 is acceptable (stamped at same master moment)
        assert s1 <= s2


# ---------------------------------------------------------------------------
# Stress Tests
# ---------------------------------------------------------------------------


class TestStress:
    def test_large_computation(self):
        """5000 events in a complex DAG. Operations complete in < 10s."""
        from pyrapide import Computation, Event, Poset, visualization

        poset = Poset()
        events: list[Event] = []

        start = time.monotonic()

        # Build 50 chains of 100 events each
        for chain in range(50):
            prev = None
            for step in range(100):
                e = Event(name=f"chain_{chain}", payload={"step": step}, source=f"c{chain}")
                if prev is not None:
                    poset.add(e, caused_by=[prev])
                else:
                    poset.add(e)
                events.append(e)
                prev = e

        assert len(poset) == 5000

        # Add some cross-chain diamonds (every 10th chain connects to the next)
        for chain in range(0, 49, 10):
            src_idx = chain * 100 + 50  # middle of chain
            tgt_idx = (chain + 1) * 100 + 50
            poset.add_causal_link(events[src_idx], events[tgt_idx])

        comp = Computation(poset=poset)

        # Poset operations
        assert poset.is_ancestor(events[0], events[99])  # first chain, start->end
        ancestors = poset.ancestors(events[99])
        assert len(ancestors) >= 99
        descendants = poset.descendants(events[0])
        assert len(descendants) >= 99

        # Serialization roundtrip
        d = comp.to_dict()
        comp2 = Computation.from_dict(d)
        assert len(comp2) == 5000

        # Visualization (truncated)
        dot = visualization.to_dot(comp, max_events=200)
        assert "digraph" in dot

        elapsed = time.monotonic() - start
        assert elapsed < 10.0, f"Large computation took {elapsed:.1f}s (limit: 10s)"

    def test_many_pattern_matches(self):
        """1000 events, pattern matching ~100. Completes in < 5s."""
        from pyrapide import Event, Pattern, Poset

        poset = Poset()

        # 100 "target" events and 900 "noise" events
        for i in range(100):
            poset.add(Event(name="target", payload={"i": i}, source="sys"))
        for i in range(900):
            poset.add(Event(name="noise", payload={"i": i}, source="sys"))

        start = time.monotonic()
        pattern = Pattern.match("target")
        matches = pattern.match_in(poset)
        elapsed = time.monotonic() - start

        assert len(matches) == 100
        assert elapsed < 5.0, f"Pattern matching took {elapsed:.1f}s (limit: 5s)"

    async def test_streaming_throughput(self):
        """Stream 1000 events. All processed in < 10s."""
        from pyrapide import Event, InMemoryEventSource, StreamProcessor

        src = InMemoryEventSource("fast")
        processor = StreamProcessor()
        processor.add_source("fast", src)

        async def feed():
            for i in range(1000):
                await src.put(Event(name="tick", payload={"i": i}, source="fast"))
            await src.close()

        start = time.monotonic()
        await asyncio.gather(feed(), processor.run())
        elapsed = time.monotonic() - start

        assert processor.stats["event_count"] == 1000
        assert elapsed < 10.0, f"Streaming took {elapsed:.1f}s (limit: 10s)"


# ---------------------------------------------------------------------------
# Regression Guards
# ---------------------------------------------------------------------------


class TestRegressionGuards:
    def test_empty_everything(self):
        """Empty computation, poset, pattern match. Nothing crashes."""
        from pyrapide import Computation, Pattern, Poset, visualization

        poset = Poset()
        assert len(poset) == 0
        assert poset.events == frozenset()
        assert poset.root_events() == frozenset()
        assert poset.leaf_events() == frozenset()

        comp = Computation()
        assert len(comp) == 0
        assert comp.topological_order() == []

        # Pattern match on empty poset
        pattern = Pattern.match("anything")
        matches = pattern.match_in(poset)
        assert matches == []

        # Visualization on empty
        ascii_out = visualization.to_ascii(comp)
        assert "empty" in ascii_out.lower()

        summ = visualization.summary(comp)
        assert "0 events" in summ

    def test_single_event_everything(self):
        """One event. All queries work. Visualization works."""
        from pyrapide import Computation, Event, Poset, queries, visualization

        e = Event(name="solo", source="sys")
        poset = Poset()
        poset.add(e)
        comp = Computation(poset=poset)

        assert len(comp) == 1
        assert comp.root_events() == frozenset({e})
        assert comp.leaf_events() == frozenset({e})

        # Queries
        cp = queries.critical_path(comp)
        assert len(cp) >= 1

        rc = queries.root_causes(comp, e)
        assert len(rc) == 0  # no ancestors for root

        impact = queries.impact_set(comp, e)
        assert len(impact) == 0  # no descendants

        freq = queries.event_frequency(comp)
        assert freq["solo"] == 1

        density = queries.causal_density(comp)
        assert density == 0.0

        # Visualization
        dot = visualization.to_dot(comp)
        assert "solo" in dot

        ascii_out = visualization.to_ascii(comp)
        assert "solo" in ascii_out

        summ = visualization.summary(comp)
        assert "1 events" in summ

    def test_no_causal_edges(self):
        """100 independent events. Poset works. Independence checks work."""
        from pyrapide import Computation, Event, Pattern, Poset, queries, visualization

        poset = Poset()
        events = []
        for i in range(100):
            e = Event(name=f"evt_{i}", source="sys")
            poset.add(e)
            events.append(e)

        assert len(poset) == 100

        comp = Computation(poset=poset)

        # All are roots and leaves
        assert len(comp.root_events()) == 100
        assert len(comp.leaf_events()) == 100

        # All pairs are independent
        assert poset.are_independent(events[0], events[1])
        assert poset.are_independent(events[50], events[99])

        # Parallel events should include all pairs
        par = queries.parallel_events(comp)
        assert len(par) > 0

        # Causal density should be 0
        density = queries.causal_density(comp)
        assert density == 0.0

        # Visualization works
        dot = visualization.to_dot(comp, max_events=100)
        assert "digraph" in dot

        ascii_out = visualization.to_ascii(comp)
        assert len(ascii_out) > 0
