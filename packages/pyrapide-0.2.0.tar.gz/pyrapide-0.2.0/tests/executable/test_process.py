import asyncio

import pytest

from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, PatternMatch
from pyrapide.executable.module import module, get_context
from pyrapide.executable.reactive import when, WhenRegistry
from pyrapide.executable.process import ProcessManager


class TestProcessManager:
    async def test_process_manager_add(self):
        """Add 3 processes to the manager."""
        manager = ProcessManager()

        async def p1():
            pass

        async def p2():
            pass

        async def p3():
            pass

        manager.add_process(p1())
        manager.add_process(p2())
        manager.add_process(p3())

        assert len(manager.processes) == 3

        # Run them so coroutines are properly awaited
        await manager.run_all()

    async def test_process_manager_run_all(self):
        """All registered processes run to completion."""
        results = []

        manager = ProcessManager()

        async def p1():
            results.append("p1")

        async def p2():
            results.append("p2")

        manager.add_process(p1())
        manager.add_process(p2())

        await manager.run_all()

        assert set(results) == {"p1", "p2"}


class TestSerialModule:
    async def test_serial_module_mutual_exclusion(self):
        """Two @when handlers on a serial module. Feed two events simultaneously.
        Assert only one handler runs at a time (sequential execution)."""
        execution_log = []

        @module(serial=True)
        class SerialMod:
            @when(Pattern.match("A"))
            async def on_a(self, match: PatternMatch):
                execution_log.append("a_start")
                await asyncio.sleep(0.05)
                execution_log.append("a_end")

            @when(Pattern.match("B"))
            async def on_b(self, match: PatternMatch):
                execution_log.append("b_start")
                await asyncio.sleep(0.05)
                execution_log.append("b_end")

        inst = SerialMod()
        ctx = get_context(inst)
        await ctx.run_start()

        registry = WhenRegistry.scan(inst)

        # Generate two events
        ctx.generate_event("A", payload={}, caused_by=[])
        ctx.generate_event("B", payload={}, caused_by=[])

        events = list(ctx.computation.events)
        event_a = [e for e in events if e.name == "A"][0]
        event_b = [e for e in events if e.name == "B"][0]

        # Fire both concurrently — serial module should serialize them
        await asyncio.gather(
            registry.fire_all(event_a, ctx),
            registry.fire_all(event_b, ctx),
        )

        # In serial mode, one handler finishes before the other starts
        # So the log should be [x_start, x_end, y_start, y_end]
        assert len(execution_log) == 4
        # Verify no interleaving: each start is followed by its own end
        assert execution_log[0].endswith("_start")
        assert execution_log[1].endswith("_end")
        assert execution_log[0][0] == execution_log[1][0]  # same handler prefix
        assert execution_log[2].endswith("_start")
        assert execution_log[3].endswith("_end")
        assert execution_log[2][0] == execution_log[3][0]

    async def test_concurrent_module_parallel(self):
        """Non-serial module. Both handlers can run concurrently."""
        execution_log = []

        @module()
        class ConcurrentMod:
            @when(Pattern.match("A"))
            async def on_a(self, match: PatternMatch):
                execution_log.append("a_start")
                await asyncio.sleep(0.05)
                execution_log.append("a_end")

            @when(Pattern.match("B"))
            async def on_b(self, match: PatternMatch):
                execution_log.append("b_start")
                await asyncio.sleep(0.05)
                execution_log.append("b_end")

        inst = ConcurrentMod()
        ctx = get_context(inst)
        await ctx.run_start()

        registry = WhenRegistry.scan(inst)

        ctx.generate_event("A", payload={}, caused_by=[])
        ctx.generate_event("B", payload={}, caused_by=[])

        events = list(ctx.computation.events)
        event_a = [e for e in events if e.name == "A"][0]
        event_b = [e for e in events if e.name == "B"][0]

        # Fire both concurrently — concurrent module runs them in parallel
        await asyncio.gather(
            registry.fire_all(event_a, ctx),
            registry.fire_all(event_b, ctx),
        )

        # In concurrent mode, handlers interleave: both start before either ends
        assert len(execution_log) == 4
        starts = [i for i, x in enumerate(execution_log) if x.endswith("_start")]
        ends = [i for i, x in enumerate(execution_log) if x.endswith("_end")]
        # Both starts should come before both ends
        assert max(starts) < min(ends)
