import pytest

from pyrapide.core.event import Event
from pyrapide.types.actions import action, provides, requires
from pyrapide.types.interface import interface
from pyrapide.executable.module import module, ModuleContext, get_context
from pyrapide.executable.exceptions import ConformanceError, ModuleStateError


# --- Test interfaces ---

@interface
class SenderInterface:
    @provides
    @action
    def send(self, msg: str) -> None:
        ...

    @requires
    def validate(self, msg: str) -> bool:
        ...


@interface
class SimpleInterface:
    @action
    def do_thing(self) -> None:
        ...


class TestModuleDecorator:
    def test_module_decorator(self):
        """Decorate a class. Assert _pyrapide_is_module is True."""

        @module()
        class MyModule:
            def run(self):
                pass

        assert getattr(MyModule, "_pyrapide_is_module", False) is True

    def test_module_implements(self):
        """@module(implements=MyInterface) stores the interface reference."""

        @module(implements=SimpleInterface)
        class ThingDoer:
            def do_thing(self) -> None:
                pass

        assert getattr(ThingDoer, "_pyrapide_implements", None) is SimpleInterface


class TestModuleConformance:
    def test_module_conformance_check(self):
        """Module missing a required method. Raises ConformanceError at decoration time."""

        with pytest.raises(ConformanceError, match="validate"):

            @module(implements=SenderInterface)
            class BadSender:
                def send(self, msg: str) -> None:
                    pass
                # Missing validate()

    def test_module_conformance_pass(self):
        """Module providing all required methods passes conformance."""

        @module(implements=SenderInterface)
        class GoodSender:
            def send(self, msg: str) -> None:
                pass

            def validate(self, msg: str) -> bool:
                return True

        assert GoodSender._pyrapide_is_module is True


class TestModuleLifecycle:
    async def test_module_lifecycle_states(self):
        """Create module, assert CREATED. Call start(), assert RUNNING. Call finish(), assert FINISHED."""

        @module()
        class LifecycleModule:
            async def start(self):
                pass

            async def finish(self):
                pass

        inst = LifecycleModule()
        ctx = get_context(inst)
        assert ctx.state == "CREATED"

        await ctx.run_start()
        assert ctx.state == "RUNNING"

        await ctx.run_finish()
        assert ctx.state == "FINISHED"

    async def test_module_start_hook(self):
        """Module with async start(). Assert it's called during lifecycle."""
        started = []

        @module()
        class StartModule:
            async def start(self):
                started.append(True)

        inst = StartModule()
        ctx = get_context(inst)
        await ctx.run_start()

        assert started == [True]
        assert ctx.state == "RUNNING"

    async def test_module_finish_hook(self):
        """Module with async finish(). Assert it's called."""
        finished = []

        @module()
        class FinishModule:
            async def start(self):
                pass

            async def finish(self):
                finished.append(True)

        inst = FinishModule()
        ctx = get_context(inst)
        await ctx.run_start()
        await ctx.run_finish()

        assert finished == [True]
        assert ctx.state == "FINISHED"

    async def test_module_finish_without_start_raises(self):
        """Cannot finish a module that hasn't started."""

        @module()
        class BadModule:
            pass

        inst = BadModule()
        ctx = get_context(inst)
        with pytest.raises(ModuleStateError):
            await ctx.run_finish()


class TestModuleEventGeneration:
    async def test_module_generate_event(self):
        """Module generates an event. Event appears in its context's computation."""

        @module()
        class EventModule:
            pass

        inst = EventModule()
        ctx = get_context(inst)
        await ctx.run_start()

        event = ctx.generate_event("EventModule.action", payload={"key": "value"})

        assert event.name == "EventModule.action"
        assert event.payload == {"key": "value"}
        assert event in ctx.computation.events
        assert event in ctx.module_events

    async def test_module_causal_chain(self):
        """Module generates e1, then e2. e2 is caused by e1."""

        @module()
        class ChainModule:
            pass

        inst = ChainModule()
        ctx = get_context(inst)
        await ctx.run_start()

        e1 = ctx.generate_event("ChainModule.first", payload={"step": 1})
        e2 = ctx.generate_event("ChainModule.second", payload={"step": 2})

        # e2 should be causally linked to e1
        assert ctx.computation.is_ancestor(e1, e2)
        assert len(ctx.module_events) == 2


class TestModuleContext:
    async def test_module_context(self):
        """Access module's context, verify computation and module_events."""

        @module()
        class CtxModule:
            pass

        inst = CtxModule()
        ctx = get_context(inst)

        assert ctx.computation is not None
        assert len(ctx.computation.events) == 0
        assert ctx.module_events == []
        assert ctx.causal_context == []

        await ctx.run_start()

        e1 = ctx.generate_event("CtxModule.event1", payload={})
        assert len(ctx.computation.events) == 1
        assert ctx.module_events == [e1]
        assert ctx.causal_context == [e1]

    async def test_module_context_source(self):
        """Generated events have the module class name as source."""

        @module()
        class SourceModule:
            pass

        inst = SourceModule()
        ctx = get_context(inst)
        await ctx.run_start()

        event = ctx.generate_event("SourceModule.ping", payload={})
        assert event.source == "SourceModule"
