import pytest

from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, PatternMatch, placeholder
from pyrapide.executable.module import module, get_context
from pyrapide.executable.reactive import when, ReactiveProcess, WhenRegistry


class TestWhenDecorator:
    def test_when_decorator(self):
        """Decorated method has _pyrapide_when_pattern attribute."""
        pattern = Pattern.match("Request")

        @module()
        class MyModule:
            @when(pattern)
            async def on_request(self, match: PatternMatch):
                pass

        assert hasattr(MyModule.on_request, "_pyrapide_when_pattern")
        assert MyModule.on_request._pyrapide_when_pattern is pattern


class TestWhenFiring:
    async def test_when_fires_on_match(self):
        """Module with @when(Pattern.match("Request")). Feed a "Request" event.
        Handler is called with the match."""
        received = []

        @module()
        class ReqHandler:
            @when(Pattern.match("Request"))
            async def on_request(self, match: PatternMatch):
                received.append(match)

        inst = ReqHandler()
        ctx = get_context(inst)
        await ctx.run_start()

        registry = WhenRegistry.scan(inst)

        req = Event(name="Request", payload={"id": "1"})
        ctx.generate_event(req.name, payload=dict(req.payload), caused_by=[])

        # Re-fetch the event from computation (generate_event creates a new one)
        recorded_event = list(ctx.computation.events)[0]

        await registry.fire_all(recorded_event, ctx)

        assert len(received) == 1
        assert received[0].events[0].name == "Request"

    async def test_when_no_fire_on_mismatch(self):
        """Feed a "Ping" event. Handler NOT called."""
        received = []

        @module()
        class PingHandler:
            @when(Pattern.match("Request"))
            async def on_request(self, match: PatternMatch):
                received.append(match)

        inst = PingHandler()
        ctx = get_context(inst)
        await ctx.run_start()

        registry = WhenRegistry.scan(inst)

        ctx.generate_event("Ping", payload={})
        recorded_event = list(ctx.computation.events)[0]

        await registry.fire_all(recorded_event, ctx)

        assert len(received) == 0

    async def test_when_multiple_handlers(self):
        """Two @when handlers for different patterns. Each fires independently."""
        req_received = []
        resp_received = []

        @module()
        class MultiHandler:
            @when(Pattern.match("Request"))
            async def on_request(self, match: PatternMatch):
                req_received.append(match)

            @when(Pattern.match("Response"))
            async def on_response(self, match: PatternMatch):
                resp_received.append(match)

        inst = MultiHandler()
        ctx = get_context(inst)
        await ctx.run_start()

        registry = WhenRegistry.scan(inst)

        ctx.generate_event("Request", payload={})
        req_event = list(ctx.computation.events)[0]
        await registry.fire_all(req_event, ctx)

        ctx.generate_event("Response", payload={})
        events = list(ctx.computation.events)
        resp_event = [e for e in events if e.name == "Response"][0]
        await registry.fire_all(resp_event, ctx)

        assert len(req_received) == 1
        assert len(resp_received) == 1

    async def test_when_causal_context(self):
        """Handler generates an event. That event is causally linked to the
        triggering matched event."""

        @module()
        class CausalHandler:
            @when(Pattern.match("Request"))
            async def on_request(self, match: PatternMatch):
                # Generate a response event inside the handler
                ctx = get_context(self)
                ctx.generate_event(
                    "Response",
                    payload={"status": "ok"},
                    caused_by=list(match.events),
                )

        inst = CausalHandler()
        ctx = get_context(inst)
        await ctx.run_start()

        registry = WhenRegistry.scan(inst)

        ctx.generate_event("Request", payload={}, caused_by=[])
        req_event = list(ctx.computation.events)[0]
        await registry.fire_all(req_event, ctx)

        # Now there should be two events: Request and Response
        events = list(ctx.computation.events)
        assert len(events) == 2
        resp_event = [e for e in events if e.name == "Response"][0]

        # Response is causally linked to Request
        assert ctx.computation.is_ancestor(req_event, resp_event)

    async def test_when_persistent(self):
        """Feed two "Request" events. Handler is called twice (once for each)."""
        received = []

        @module()
        class PersistentHandler:
            @when(Pattern.match("Request"))
            async def on_request(self, match: PatternMatch):
                received.append(match)

        inst = PersistentHandler()
        ctx = get_context(inst)
        await ctx.run_start()

        registry = WhenRegistry.scan(inst)

        # First request
        ctx.generate_event("Request", payload={"id": "1"}, caused_by=[])
        req1 = [e for e in ctx.computation.events if e.payload.get("id") == "1"][0]
        await registry.fire_all(req1, ctx)

        # Second request
        ctx.generate_event("Request", payload={"id": "2"}, caused_by=[])
        req2 = [e for e in ctx.computation.events if e.payload.get("id") == "2"][0]
        await registry.fire_all(req2, ctx)

        assert len(received) == 2

    async def test_when_with_placeholder(self):
        """@when(Pattern.match("Request", data=placeholder("d"))). Handler receives
        bindings with data."""
        received = []

        d = placeholder("d")

        @module()
        class PlaceholderHandler:
            @when(Pattern.match("Request", data=d))
            async def on_request(self, match: PatternMatch):
                received.append(match)

        inst = PlaceholderHandler()
        ctx = get_context(inst)
        await ctx.run_start()

        registry = WhenRegistry.scan(inst)

        ctx.generate_event("Request", payload={"data": "hello"}, caused_by=[])
        req_event = list(ctx.computation.events)[0]
        await registry.fire_all(req_event, ctx)

        assert len(received) == 1
        assert received[0].bindings["d"] == "hello"


class TestWhenRegistry:
    def test_when_registry_scan(self):
        """Scan a module class. Returns correct ReactiveProcess list."""

        @module()
        class ScanModule:
            @when(Pattern.match("A"))
            async def on_a(self, match: PatternMatch):
                pass

            @when(Pattern.match("B"))
            async def on_b(self, match: PatternMatch):
                pass

            async def not_reactive(self):
                pass

        inst = ScanModule()
        registry = WhenRegistry.scan(inst)

        assert len(registry.processes) == 2
        patterns = {p.pattern.event_name for p in registry.processes}
        assert patterns == {"A", "B"}
        assert all(isinstance(p, ReactiveProcess) for p in registry.processes)
