import pytest

from pyrapide.types.actions import action, provides, requires
from pyrapide.types.interface import interface
from pyrapide.architecture.bindings import bind, Binding


@interface
class LoggerInterface:
    @requires
    def log(self, msg: str) -> None:
        ...

    @requires
    def flush(self) -> None:
        ...


class TestBindings:
    def test_bind_module_to_interface(self):
        class FileLogger:
            def log(self, msg: str) -> None:
                pass

            def flush(self) -> None:
                pass

        iface = LoggerInterface()
        binding = bind(iface, FileLogger)
        assert isinstance(binding, Binding)
        assert binding.interface_instance is iface
        assert binding.module_class is FileLogger

    def test_binding_type_check(self):
        class PartialLogger:
            def log(self, msg: str) -> None:
                pass
            # Missing flush()

        iface = LoggerInterface()
        with pytest.raises(TypeError, match="does not conform"):
            bind(iface, PartialLogger)
