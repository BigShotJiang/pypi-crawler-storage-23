from pyrapide import Event, Computation
from pyrapide.patterns.base import Pattern, placeholder
from pyrapide.architecture.maps import ArchitectureMap


class TestArchitectureMap:
    def test_architecture_map_creation(self):
        amap = ArchitectureMap(
            domain="SourceArch",
            range="TargetArch",
            mapping_rules=[
                (Pattern.match("Send"), "Transmit"),
                (Pattern.match("Receive"), "Accept"),
            ],
        )
        assert amap.domain == "SourceArch"
        assert amap.range == "TargetArch"
        assert len(amap.mapping_rules) == 2

    def test_architecture_map_apply(self):
        amap = ArchitectureMap(
            domain="Source",
            range="Target",
            mapping_rules=[
                (Pattern.match("Send"), "Transmit"),
            ],
        )

        source_comp = Computation()
        e1 = Event(name="Send", payload={"data": "hello"}, source="client")
        e2 = Event(name="Other", payload={})
        source_comp.record(e1)
        source_comp.record(e2)

        target_comp = amap.apply(source_comp)
        # Should contain a mapped event for "Send" -> "Transmit"
        transmits = [e for e in target_comp.events if e.name == "Transmit"]
        assert len(transmits) == 1
        assert transmits[0].payload == {"data": "hello"}
        # "Other" has no mapping rule, so it's not in the target
        others = [e for e in target_comp.events if e.name == "Other"]
        assert len(others) == 0

    def test_map_preserves_causality(self):
        amap = ArchitectureMap(
            domain="Source",
            range="Target",
            mapping_rules=[
                (Pattern.match("Send"), "Transmit"),
                (Pattern.match("Ack"), "Confirm"),
            ],
        )

        source_comp = Computation()
        e1 = Event(name="Send")
        e2 = Event(name="Ack")
        source_comp.record(e1)
        source_comp.record(e2, caused_by=[e1])

        target_comp = amap.apply(source_comp)
        transmits = [e for e in target_comp.events if e.name == "Transmit"]
        confirms = [e for e in target_comp.events if e.name == "Confirm"]
        assert len(transmits) == 1
        assert len(confirms) == 1

        # The mapped Confirm should be causally after Transmit
        assert target_comp.is_ancestor(transmits[0], confirms[0])
