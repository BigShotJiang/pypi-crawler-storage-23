import asyncio

import pytest

from pyrapide import Event, Computation
from pyrapide.core.poset import Poset
from pyrapide.patterns.base import Pattern, PatternMatch, placeholder
from pyrapide.architecture.connections import (
    AgentConnection,
    BasicConnection,
    ConnectionManager,
    PipeConnection,
    agent,
    connect,
    pipe,
)


class TestConnectionCreation:
    def test_basic_connection_creation(self):
        conn = BasicConnection(
            source_pattern=Pattern.match("Request"),
            handler=lambda m, c: None,
        )
        assert conn.connection_type == "basic"
        assert conn.active is True

    def test_pipe_connection_creation(self):
        conn = PipeConnection(
            source_pattern=Pattern.match("Request"),
            handler=lambda m, c: None,
        )
        assert conn.connection_type == "pipe"

    def test_agent_connection_creation(self):
        conn = AgentConnection(
            source_pattern=Pattern.match("Request"),
            handler=lambda m, c: None,
        )
        assert conn.connection_type == "agent"


class TestConnectionManager:
    def test_connection_manager_add(self):
        mgr = ConnectionManager()
        for _ in range(3):
            mgr.add_connection(BasicConnection(
                source_pattern=Pattern.match("X"),
                handler=lambda m, c: None,
            ))
        assert len(mgr.connections) == 3


class TestBasicConnectionExecution:
    def test_basic_connection_fires(self):
        calls = []

        def handler(match: PatternMatch, comp: Computation):
            calls.append(match)

        conn = BasicConnection(
            source_pattern=Pattern.match("Request"),
            handler=handler,
        )
        mgr = ConnectionManager()
        mgr.add_connection(conn)

        comp = Computation()
        evt = Event(name="Request", payload={"path": "/api"})
        comp.record(evt)

        mgr.process_event(evt, comp)
        assert len(calls) == 1
        assert calls[0].events[0] is evt

    def test_basic_connection_no_match(self):
        calls = []

        def handler(match: PatternMatch, comp: Computation):
            calls.append(match)

        conn = BasicConnection(
            source_pattern=Pattern.match("Request"),
            handler=handler,
        )
        mgr = ConnectionManager()
        mgr.add_connection(conn)

        comp = Computation()
        evt = Event(name="Ping")
        comp.record(evt)

        mgr.process_event(evt, comp)
        assert len(calls) == 0


class TestPipeConnection:
    async def test_pipe_connection_ordering(self):
        order = []

        async def handler(match: PatternMatch, comp: Computation):
            order.append(match.events[0].payload["seq"])

        conn = PipeConnection(
            source_pattern=Pattern.match("Job"),
            handler=handler,
        )

        comp = Computation()
        events = []
        for i in range(3):
            e = Event(name="Job", payload={"seq": i})
            comp.record(e)
            events.append(e)

        await conn.start()
        for e in events:
            await conn.enqueue(e, comp)
        await conn.drain()
        await conn.stop()

        assert order == [0, 1, 2]


class TestAgentConnection:
    async def test_agent_connection_independence(self):
        results = []

        async def handler(match: PatternMatch, comp: Computation):
            results.append(match.events[0].payload["id"])

        conn = AgentConnection(
            source_pattern=Pattern.match("Task"),
            handler=handler,
        )

        comp = Computation()
        tasks = []
        for i in range(3):
            e = Event(name="Task", payload={"id": i})
            comp.record(e)
            tasks.append(e)

        agent_tasks = []
        for e in tasks:
            t = await conn.dispatch(e, comp)
            agent_tasks.append(t)

        await asyncio.gather(*agent_tasks)

        assert sorted(results) == [0, 1, 2]


class TestFactoryFunctions:
    def test_connect_factory(self):
        conn = connect(Pattern.match("X"), lambda m, c: None)
        assert isinstance(conn, BasicConnection)

    def test_pipe_factory(self):
        conn = pipe(Pattern.match("X"), lambda m, c: None)
        assert isinstance(conn, PipeConnection)

    def test_agent_factory(self):
        conn = agent(Pattern.match("X"), lambda m, c: None)
        assert isinstance(conn, AgentConnection)


class TestConnectionWithPlaceholders:
    def test_connection_with_placeholder_pattern(self):
        received_bindings = []

        def handler(match: PatternMatch, comp: Computation):
            received_bindings.append(dict(match.bindings))

        msg = placeholder("msg")
        conn = BasicConnection(
            source_pattern=Pattern.match("Send", message=msg),
            handler=handler,
        )
        mgr = ConnectionManager()
        mgr.add_connection(conn)

        comp = Computation()
        evt = Event(name="Send", payload={"message": "hello"})
        comp.record(evt)

        mgr.process_event(evt, comp)
        assert len(received_bindings) == 1
        assert received_bindings[0]["msg"] == "hello"
