import pytest

from pyrapide import Event
from pyrapide.architecture.communication import CommunicationScope, CommunicationContext


class TestCommunicationScope:
    def test_self_observation(self):
        scope = CommunicationScope()
        assert scope.can_observe("moduleA", "moduleA") is True

    def test_parent_observation(self):
        scope = CommunicationScope()
        scope.register_parent("arch", "client")
        scope.register_parent("arch", "server")
        assert scope.can_observe("arch", "client") is True
        assert scope.can_observe("arch", "server") is True

    def test_linked_observation(self):
        scope = CommunicationScope()
        scope.register_link("client", "server")
        assert scope.can_observe("client", "server") is True
        assert scope.can_observe("server", "client") is True

    def test_unlinked_no_observation(self):
        scope = CommunicationScope()
        assert scope.can_observe("moduleA", "moduleB") is False


class TestCommunicationContext:
    def test_causal_context_push_pop(self):
        ctx = CommunicationContext()
        e1 = Event(name="A")
        e2 = Event(name="B")
        ctx.push_cause(e1)
        ctx.push_cause(e2)
        assert len(ctx.current_causes) == 2
        popped = ctx.pop_cause()
        assert popped is e2
        assert len(ctx.current_causes) == 1
        assert ctx.current_causes[0] is e1

    def test_causal_context_fork(self):
        ctx = CommunicationContext()
        e1 = Event(name="A")
        ctx.push_cause(e1)

        forked = ctx.fork()
        # Forked context starts with the same causes
        assert len(forked.current_causes) == 1
        assert forked.current_causes[0] is e1

        # Modifications to forked context don't affect original
        e2 = Event(name="B")
        forked.push_cause(e2)
        assert len(forked.current_causes) == 2
        assert len(ctx.current_causes) == 1
