import pytest

from pyrapide.types.actions import action, provides
from pyrapide.types.interface import interface
from pyrapide.architecture.architecture import architecture


@interface
class ClientInterface:
    @action
    def send(self, msg: str) -> None:
        pass

    @provides
    def status(self) -> str:
        return "idle"


@interface
class ServerInterface:
    @action
    def receive(self, msg: str) -> None:
        pass

    @action
    def respond(self, msg: str) -> None:
        pass


class TestArchitectureDecorator:
    def test_architecture_decorator(self):
        @architecture
        class MyArch:
            client: ClientInterface
            server: ServerInterface

        assert MyArch._pyrapide_is_architecture is True

    def test_component_detection(self):
        @architecture
        class MyArch:
            client: ClientInterface
            server: ServerInterface

        info = MyArch.get_architecture_info()
        assert "client" in info["components"]
        assert "server" in info["components"]

    def test_component_instantiation(self):
        @architecture
        class MyArch:
            client: ClientInterface
            server: ServerInterface

        arch = MyArch()
        assert isinstance(arch.client, ClientInterface)
        assert isinstance(arch.server, ServerInterface)

    def test_component_access(self):
        @architecture
        class MyArch:
            client: ClientInterface
            server: ServerInterface

        arch = MyArch()
        assert arch.client.status() == "idle"

    def test_architecture_info(self):
        @architecture
        class MyArch:
            client: ClientInterface
            server: ServerInterface

        info = MyArch.get_architecture_info()
        assert info["component_types"]["client"] is ClientInterface
        assert info["component_types"]["server"] is ServerInterface
        assert info["is_architecture"] is True

    def test_architecture_with_connections_method(self):
        @architecture
        class MyArch:
            client: ClientInterface
            server: ServerInterface

            def connections(self):
                pass

        arch = MyArch()
        assert callable(arch.connections)

    def test_empty_architecture(self):
        @architecture
        class EmptyArch:
            pass

        info = EmptyArch.get_architecture_info()
        assert info["components"] == {}
        assert info["component_types"] == {}

    def test_architecture_with_non_interface_attributes(self):
        @architecture
        class MixedArch:
            client: ClientInterface
            timeout: int
            name: str

        info = MixedArch.get_architecture_info()
        assert "client" in info["components"]
        assert "timeout" not in info["components"]
        assert "name" not in info["components"]
